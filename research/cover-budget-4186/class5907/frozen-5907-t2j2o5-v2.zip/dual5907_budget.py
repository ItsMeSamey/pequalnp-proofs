"""Six-AND budget for a fixed three-OR dual prefix and final OR.

Masks are literal conjunctions of six raw atoms and up to three earlier OR
outputs. Yields all reduced, live recipes up to reordering independent gates.
This examines formal footprints, not functional decompositions of new values.
"""
from functools import lru_cache

RAW = 63
BUDGET = 6


def nontrivial(mask):
    return mask.bit_count() >= 2


def submasks(mask):
    part = mask
    while part:
        yield part
        part = (part - 1) & mask


def lambda_pool(final):
    pool = set()
    for side, opposite in (final, final[::-1]):
        if (opposite & RAW).bit_count() != 1:
            continue
        for s in submasks(side):
            count = (s & RAW).bit_count()
            if count >= 2 or (count == 1 and (s & ~RAW).bit_count() >= 2):
                pool.add(s)
    return pool


def footprint_lb(demands):
    multi = {s for s in demands if nontrivial(s)}
    lower = len(multi)
    # A footprint T requires |T|-1 conjunctions in its own ancestry.
    # Other required supports outside T have to be built separately.
    for t in multi:
        lower = max(lower, t.bit_count()-1 + sum(s & ~t != 0 for s in multi))
    return lower


@lru_cache(None)
def splits(s):
    proper = list(submasks(s))[1:]
    return tuple((a,b) for i,a in enumerate(proper) for b in proper[i+1:]
                 if a | b == s)


def filter_recipes(arms, budget=BUDGET, insist_deficit=False):
    if len(arms) != 4 or any(len(p) != 2 for p in arms):
        raise ValueError('expected three precursor pairs and the final pair')
    for i, pair in enumerate(arms):
        if any(type(s) != int or not (0 < s < 1 << (6+i)) for s in pair):
            raise ValueError('invalid or unavailable formal atom')
    aa,bb = arms[-1]
    left,right = aa & RAW, bb & RAW
    pool = lambda_pool((aa,bb))
    k = max(left.bit_count(),right.bit_count())
    centred_star = left & right == 0 and min(left.bit_count(),right.bit_count()) == 1
    if insist_deficit and (not centred_star or len(pool)<k):
        return
    roots = {s for p in arms for s in p if nontrivial(s)}
    recipes = {}

    def visit(pending):
        spent = len(recipes)
        if spent + footprint_lb(pending) > budget:
            return
        if insist_deficit and sum(s not in pool for s in set(recipes)|pending) > budget-k:
            return
        if not pending:
            if spent == budget:
                yield dict(recipes)
            return
        s = max(pending,key=lambda t:(t.bit_count(),t))
        rest = pending-{s}
        for a,b in splits(s):
            need = rest|{x for x in (a,b) if nontrivial(x)}
            if spent+1+len(need)>budget:
                continue
            recipes[s] = a,b
            yield from visit(need)
            del recipes[s]
    yield from visit(roots)


def primal_lambda(arms, recipes):
    """Score the qualifying binary raw ORs in the primal of this dual DAG.

    Assumes caller has checked the six mixed gates and three dirty gates.
    """
    seen = set()
    counted = set()
    def visit(s):
        if s in seen or s not in recipes:
            return
        seen.add(s)
        a,b = recipes[s]
        if a & RAW and b & RAW:
            counted.add(s)
        visit(a)
        visit(b)
    for x,y in (arms[-1],arms[-1][::-1]):
        if (y & RAW).bit_count()==1:
            visit(x)
    return len(counted)
