from two_top_two_dirty5907 import *
from dual5907_budget import footprint_lb,splits
from itertools import combinations_with_replacement as pairs
from collections import Counter,defaultdict
from functools import lru_cache
@lru_cache(None)
def recipes(roots,remaining):
 if not roots:return ((),)
 if footprint_lb(roots)>remaining:return ()
 s=max(roots,key=lambda t:(t.bit_count(),t))
 rest=set(roots)-{s};out=[]
 for a,b in splits(s):
  goal=tuple(sorted(rest|{u for u in (a,b) if u.bit_count()>1}))
  if len(goal)>remaining-1:continue
  for sub in recipes(goal,remaining-1):out.append(((s,a,b),)+sub)
 return tuple(out)
def score(arms,rec):
 m={s:(a,b) for s,a,b in rec};covered=set();lam=set();c=0
 def visit(s):
  if s in m:
   a,b=m[s]
   if a&63 and b&63:lam.add(s)
   visit(a);visit(b)
 for a,b in arms[2:]:
  c+=not(a&63 and b&63)
  for u in range(6):
   for v in range(6):
    if a>>u&1 and b>>v&1:covered.add(tuple(sorted((u,v))))
  if (a&63).bit_count()==1:visit(b)
  if (b&63).bit_count()==1:visit(a)
 assert covered<=set(edges)
 q=len(rec)-len(lam);uncovered=7-len(covered)
 return q,c,uncovered,4+c+q-uncovered
def rebuild(arms,rec):
 forms={s:(a,b) for s,a,b in rec};gs=[];w={1<<i:i for i in range(6)}
 def gate(op,a,b):gs.append((op,a,b));return 5+len(gs)
 def get(s):
  if s not in w:
   a,b=forms[s];w[s]=gate('O',get(a),get(b))
  return w[s]
 tops=[]
 for j,(a,b) in enumerate(arms):
  v=gate('A',get(a),get(b))
  if j<2:w[1<<(6+j)]=v
  else:tops.append(v)
 out=gate('O',*tops);return dict(n=6,edges=edges,gates=gs,output=out)
if __name__=='__main__':
 t=time.monotonic();counts=Counter();sc=Counter()
 for d,q in json.loads(Path(__file__).with_name('two-top-two-dirty-banks.json').read_text()):
  u=unions+[v|d for v in unions];v=u+[x|q for x in u]
  A=[(i,j) for i,j in pairs(range(1,64),2) if unions[i]&unions[j]==d]
  B=[(i,j) for i,j in pairs(range(1,128),2) if u[i]&u[j]==q]
  T=defaultdict(list)
  for i,j in pairs(range(1,256),2):
   k=v[i]&v[j]
   if k and k<=127:T[k].append((i,j))
  for x,y in pairs(T,2):
   if x|y!=127:continue
   for a in A:
    for b in B:
     for c in T[x]:
      for e in T[y]:
       arms=(a,b,c,e);counts['arm systems']+=1
       roots=tuple(sorted({i for p in arms for i in p if i.bit_count()>1}))
       counts['footprint_lb='+str(footprint_lb(roots))]+=1
       if footprint_lb(roots)>5:continue
       counts['budget lower bound passed']+=1
       for r in recipes(roots,5):
        counts['recipes']+=1
        vq,cent,un,score0=score(arms,r);sc[len(r),vq,cent,un,score0]+=1
        if len(r)<5 or score0!=4:
         hit=dict(arms=arms,desc=[len(r),vq,cent,un,score0],**rebuild(arms,r))
         print('HIT',hit,flush=True);Path(__file__).with_name('two-top-two-dirty-hit.json').write_text(json.dumps(hit));raise SystemExit
 print(dict(counts),sorted(sc.items()),round(time.monotonic()-t,2))
