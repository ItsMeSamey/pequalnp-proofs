"""Brute-force every formal top-arm pair on each previously omitted bank."""
from itertools import combinations_with_replacement
import json
from pathlib import Path
from two_top_two_dirty5907 import unions
D=Path(__file__).resolve().parent
current=set(map(tuple,json.loads((D/'two-top-two-dirty-banks.json').read_bytes())))
original=set(map(tuple,json.loads((D/'superseded-77.json').read_bytes())))
if not original<current:raise ValueError('unexpected bank relationship')
for d,q in current-original:
    stage=unions+[x|d for x in unions]
    arms=stage+[x|q for x in stage]
    clean={a&b for a,b in combinations_with_replacement(arms,2) if not (a&b)&~127}
    if not any(a|b==127 for a in clean for b in clean):
        raise ValueError((d,q))
print('direct 256-arm clean pair coverage checks:',len(current-original))
