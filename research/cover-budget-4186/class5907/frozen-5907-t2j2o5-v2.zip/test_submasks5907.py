from itertools import combinations
from two_top_two_dirty5907 import submasks
for mask in range(512):
    digits=[1<<k for k in range(9) if mask>>k&1]
    expected={sum(group) for count in range(len(digits)+1) for group in combinations(digits,count)}
    values=list(submasks(mask))
    if set(values)!=expected or len(values)!=len(set(values)) or len(values)!=2**len(digits):
        raise ValueError((mask,values))
if list(submasks(0))!=[0] or 31 not in submasks(63):
    raise ValueError('explicit regression')
print('actual helper verified for 512 masks, multiplicity and 31 under 63')
