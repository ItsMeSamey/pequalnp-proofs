# Class 5907 with two tops, two dirty ANDs and five prefix ORs

Run with Python 3 from this directory.

```sh
sha256sum -c SHA256SUMS
python two_top_two_dirty5907.py
python two_top_two_dirty_recipes5907.py
python replay_two_top_two_dirty5907.py
python direct_missing_banks5907.py
python test_submasks5907.py
python check_count_bindings.py
sha256sum -c SHA256SUMS
```

The first program writes the JSON list of 176 semantic banks. Its hash is bound before and after replay. The second prints the counts of fully expanded formal endpoint systems, including the histogram in counts.json. The third uses another coverage formulation and compares the actual sets of banks. Both coverage formulations share the row and canonicalization definitions. Python's standard library and the local modules in the manifest are the entire dependency set.

## Enumeration

The raw sources are six vertex bits. The program lists the seven true edge pairs first and then the eight remaining pairs in lexicographic order. These eight pairs are the maximal independent sets because each of the two parts is a triangle and every singleton extends to an independent pair. Thus these 15 rows determine whether a monotone output equals the graph function. In particular a gate is dirty exactly when it fires on at least one of the last eight rows.

Under the live least top-form normal form, schedule all dirty prefix gates before the two clean AND tops and join the two tops at the output. A mixed OR depending on a top cannot participate in a later AND under top form, and an OR-only path to the output would propagate its negative row. The first dirty AND therefore has arms that are raw unions. The second dirty AND may also use the first as an opaque source; each top arm may use both. The first AND is quotiented by the eight permutations independently swapping the two leaves of either triangle and exchanging the triangles. These actions and all source relabelings preserve gate count and graph truth. No structural conclusion is drawn solely by identifying signatures. All physical arm supports are recovered for every surviving bank, permitting equal pins.

For a clean top, split the eight negative rows into two sets according to which arm must be zero. An arm can use exactly the source atoms avoiding its forbidden rows. Adding all eligible atoms gives the largest possible positive signature. The second dirty atom cannot occur in both arms of a clean top, since it has a negative row. The first program combines all top obligations by positive-edge ownership, allowing either top to own a shared edge. The second coverage formulation chooses a side without the second dirty atom and enumerates its possible unions. It takes the largest compatible opposite arm and tests every pair of maximal resulting tops. The 176 surviving signatures are identifiers in the fixed 15-row convention.

## Footprint bound

Let D be the set of distinct nonsingleton formal support masks demanded at the eight AND operands. A mask names raw inputs and whole earlier dirty AND outputs. Define support by tracing ORs only and stopping at every raw input or AND output. It is a syntactic set, including a raw occurrence even if absorption makes its semantic contribution redundant. Each nonsingleton mask in D needs an OR producer, and distinct masks need distinct producers.

For each T in D, fix an OR-only realization cone for T. It has k distinct source vertices with k equal to the cardinality of T, and m OR vertices, counting shared vertices once. The underlying multigraph is connected and has at least k+m−1 edges; each of the m ORs has two incoming pin occurrences, so it has at most 2m edges. Hence m≥k−1, including for reconvergent cones and repeated pins. Every intermediate in this cone has support contained in T. Every other demanded support S that is not a subset of T therefore needs a different physical OR outside this cone. The total number of ORs is at least the maximum of |D| and all values |T|−1 + #{S in D that are not subsets of T}. The bound counts formal atoms only and assumes no disjointness of child supports. Universal inputs or semantic equivalences are never used for this budget cut.

Every one of the 1708 expanded systems requires at least six ORs by this bound. There is consequently no eligible instance on which to score structural lambda in this branch. The result is scoped to the specified six-vertex graph and normalized gate multiplicities.

## Superseded count

The original submask loop omitted 99 viable banks. This version tests each submask against a fixed bound. The second coverage formulation reproduces all 176 banks; direct_missing_banks5907.py separately checks all 99 omissions by direct formal top-pair enumeration. The old list is retained to reproduce the comparison. First missing bank (144,137) has formal arms (5,8), (33,66), (38,193), (12,16), producing top signatures 31 and 96.
