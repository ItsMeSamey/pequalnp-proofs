import ast,itertools,json,subprocess,sys
from pathlib import Path
from two_top_two_dirty5907 import edges
D=Path(__file__).resolve().parent
def run(name):
    return subprocess.check_output([sys.executable,str(D/name)],text=True,cwd=D).strip()
def require(test,reason):
    if not test:raise ValueError(reason)
data=json.loads((D/'inputs.json').read_bytes())
c=json.loads((D/'counts.json').read_bytes())
require(data['n']==6 and data['edges']==list(map(list,edges)),'graph')
require(data['edge_code']==sum(1<<i for i,p in enumerate(itertools.combinations(range(6),2)) if p in edges),'edge code')
require(data['required_counts']==dict(clean_top_AND=2,dirty_AND=2,dirty_OR=5,clean_output_OR=1),'class')
first=run('two_top_two_dirty5907.py').split()
require(list(map(int,first[:3]))==[c['canonical_first_signatures'],c['chronological_dirty_banks'],c['feasible_semantic_banks']],'semantic count binding')
text=run('two_top_two_dirty_recipes5907.py')
summary,remaining=text.split('}',1)
r=ast.literal_eval(summary+'}')
require(r.pop('arm systems')==c['arm_systems'],'arm count')
require(r.pop('budget lower bound passed',0)==c['systems_with_bound_at_most_five'],'budget count')
require(r=={'footprint_lb='+k:v for k,v in c['footprint_lower_bound_histogram'].items()},'histogram')
require(remaining.strip().startswith('[] '),'unexpected recipes')
print('graph, class, stage counts, and histogram match bound inputs')
