"""Second coverage formulation for every chronological two-dirty bank."""
from two_top_two_dirty5907 import raw, unions, first, P
from pathlib import Path
from itertools import combinations_with_replacement
import json

def direct(d):
    sources=raw+[d]
    operands=set(unions)|{x|d for x in unions}
    dirty2={a&b for a,b in combinations_with_replacement(operands,2)
            if (a&b)&~P}
    candidates=set()
    for b in operands:
        neg=b&~P
        a=0
        for x in sources:
            if not x&neg:a |= x
        candidates.add((a&b,b&P,neg))
    cover=[sum(1<<v for v in range(128) if (v|z)==P) for z in range(128)]
    wins=[]
    for q in dirty2:
        made=0
        for base,positive,neg in candidates:
            z=base if q&neg else base|(positive&q)
            if z==P or made&cover[z]:
                wins.append((d,q))
                break
            made |= 1<<z
    return wins,len(dirty2)
if __name__=='__main__':
    observed=set();total=0
    for d in first:
        result,n=direct(d);observed.update(result);total+=n
    expected=set(map(tuple,json.loads(Path(__file__).with_name('two-top-two-dirty-banks.json').read_text())))
    if observed!=expected:raise ValueError((len(observed-expected),len(expected-observed)))
    print('second coverage formulation agrees:',len(first),total,len(observed))
