"""Exact fifteen-row endpoint feasibility with arbitrary ORs for graph 5907."""
from itertools import combinations
from pathlib import Path
import json,time
P=127;N=255
edges=[(0,1),(0,2),(0,5),(1,5),(2,3),(2,4),(3,4)]
rows=edges+[r for r in combinations(range(6),2) if r not in edges]
raw=[sum(1<<i for i,r in enumerate(rows) if j in r) for j in range(6)]
unions=[0]
for v in raw:unions += [x|v for x in unions]
autos=[]
for l in (False,True):
 for r in (False,True):
  for flip in (False,True):
   p=[0,5 if l else 1,2,4 if r else 3,3 if r else 4,1 if l else 5]
   if flip:p=[[2,3,0,1,5,4][x] for x in p]
   order=[rows.index(tuple(sorted((p[a],p[b])))) for a,b in rows]
   autos.append([sum(1<<order[i] for i in range(15) if z>>i&1) for z in range(32768)])
first={a&b for a in unions for b in unions if (a&b)&~P}
first={z for z in first if z==min(m[z] for m in autos)}
def submasks(z):
 for part in range(z+1):
  if part & ~z == 0:yield part

def banks(d):
 u=set(unions)|{v|d for v in unions}
 ss=sorted({a&b for a in u for b in u if a&b&~P})
 full=(1<<len(ss))-1
 masks=[sum(1<<i for i,v in enumerate(ss) if v>>k&1) for k in range(15)]
 plus=[full]*128;avoid=[full]*256;strong=[0]*256
 for k in range(1,128):
  b=k&-k;plus[k]=plus[k^b]&masks[b.bit_length()-1]
 for k in range(256):
  if k:
   b=k&-k;avoid[k]=avoid[k^b]&(full^masks[7+b.bit_length()-1])
  for v in (*raw,d):
   if not ((v>>7)&k):strong[k]|=v&P
 can=[0]*128
 for n in range(256):
  a,b=strong[n],strong[N^n]
  base=a&b
  for owned in submasks(b):
   miss=owned&~base
   can[owned] |= (avoid[n]&plus[miss]) if miss else full
 winners=0
 for p in range(1,128,2):winners|=can[p]&can[P^p]
 return [v for i,v in enumerate(ss) if winners>>i&1],len(ss)
if __name__=='__main__':
 win=[];tested=0;t=time.monotonic()
 for d in sorted(first):
  vals,n=banks(d);tested+=n
  if vals:win.extend((d,q) for q in vals)
 out=Path(__file__).with_name('two-top-two-dirty-banks.json')
 out.write_text(json.dumps(win))
 print(len(first),tested,len(win),round(time.monotonic()-t,2))
