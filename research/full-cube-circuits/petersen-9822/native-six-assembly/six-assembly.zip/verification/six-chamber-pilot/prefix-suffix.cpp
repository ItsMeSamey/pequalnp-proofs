#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
using M=uint32_t;
constexpr M all=~M(0);
constexpr int mis[]={50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773};
constexpr int edges[]={6,24,17,33,66,132,264,528,160,640,576,320,288};
array<unsigned,10> present{};
bool edge(int u,int v){return find(begin(edges),end(edges),(1<<u)|(1<<v))!=end(edges);}
struct Cell{M row;unsigned target;};
struct Prefix{
 array<M,5> activation;array<M,10> rays;vector<M> names,chosen;unsigned atoms=0;
 int d,dneed,grants;array<int,8> label{};
 Prefix(array<M,5> a):activation(a){
  for(int j=0;j<5;j++){M hi=0;for(int w=0;w<32;w++)if(w>>j&1)hi|=M(1)<<w;
   rays[2*j]=a[j]&~hi;rays[2*j+1]=a[j]&hi;}
  set<unsigned> seen;for(int w=0;w<32;w++){unsigned s=0;for(M b:rays)s=s*2+(b>>w&1);
   if(seen.insert(s).second)atoms|=M(1)<<w;}
  set<M> w(a.begin(),a.end());w.erase(all);for(M b:rays)w.erase(b);names.assign(w.begin(),w.end());
 }
 bool extend(int k,unsigned used,unsigned direct,const array<Cell,16>&cells,int size){
  if(k==int(chosen.size())){
   for(int m:mis)if((unsigned(m)&direct)==direct&&popcount(unsigned(m)&~(used^direct))>=d)return true;
   return false;
  }
  for(int v=0;v<10;v++){unsigned bit=1u<<v;if(used&bit)continue;
   bool ok=true;for(int j=0;j<k;j++)if(edge(label[j],v)!=((chosen[j]|chosen[k])==all)){ok=false;break;}
   if(!ok)continue;
   unsigned dr=direct|(k<dneed?bit:0);if(k<dneed&&none_of(begin(mis),end(mis),[&](int m){return (unsigned(m)&dr)==dr&&popcount(unsigned(m))>=d;}))continue;
   array<Cell,16> child;int count=0;unsigned pos=present[v];
   for(int j=0;j<size&&ok;j++)for(int b=0;b<2;b++){
    auto c=cells[j];c.row&=b?chosen[k]:~chosen[k];c.target&=b?pos:~pos;
    if(popcount(c.target)>2*popcount(c.row)){ok=false;break;}
    if(c.target)child[count++]=c;
   }
   if(!ok)continue;label[k]=v;if(extend(k+1,used|bit,dr,child,count))return true;
  }
  return false;
 }
 bool checkPick(){
  // The minimum number of earlier names that must be raw is enough for this necessary test.
  int r=max(0,int(names.size())-grants);unsigned n=names.size();
  for(unsigned take=0;take<(1u<<n);take++)if(popcount(take)==r){
   auto original=chosen.size();for(unsigned j=0;j<n;j++)if(take>>j&1)chosen.push_back(names[j]);
   array<Cell,16> cells;cells[0]={atoms,65535};bool ok=extend(0,0,0,cells,1);chosen.resize(original);if(ok)return true;
  }
  return false;
 }
 bool choose(int from){
  if(int(chosen.size())==dneed)return checkPick();
  for(int j=from;j<5;j++)if(d!=2||activation[j]==all)for(int s=0;s<2;s++){
   auto a=rays[2*j+s];if(!a||any_of(chosen.begin(),chosen.end(),[&](M b){return !(a&b)||!(a&~b)||!(b&~a);}))continue;
   chosen.push_back(a);bool z=choose(j+1);chosen.pop_back();if(z)return true;
  }
  return false;
 }
 bool width()const{for(M w:names){bool found=false;for(M a:rays)for(M b:rays)if((a|b)==w)found=true;if(!found)return false;}return true;}
};
int main(int argc,char**argv){if(argc!=4)return 2;int start=stoi(argv[2]),stop=stoi(argv[3]);ifstream in(argv[1]);
 for(int v=0;v<10;v++)for(int i=0;i<16;i++)if(!(mis[i]>>v&1))present[v]|=1u<<i;
 {Prefix test({all,all,all,all,all});test.d=4;test.dneed=3;test.atoms=all;
 for(int v:{0,2,3,1,4})test.chosen.push_back(present[v]|(present[v]<<16));
 array<Cell,16> cells;cells[0]={all,65535};if(!test.extend(0,0,0,cells,1))return 4;
 test.chosen[4]=test.chosen[3];if(test.extend(0,0,0,cells,1))return 5;}
 int id,n,allowfull,fresh;array<M,5>a;
 while(in>>id>>n>>allowfull>>fresh){for(auto &m:a)if(!(in>>m))return 3;if(id<start||id>=stop)continue;
 Prefix p(a);int f=count(a.begin(),a.end(),all);cout<<id<<" "<<n;
 for(auto [d,q]:vector<pair<int,int>>{{2,0},{3,1},{4,2},{4,1},{4,0}}){p.d=d;p.dneed=d-1;p.grants=q;
 bool base=(d!=2||p.width())&&p.choose(0);
 int left=base?n:0;
 if(d==2&&base&&f<2)left=f==1?allowfull:0;
 if(base && fresh && (d!=2 || f>=2)){
  p.dneed=d;bool earlier=p.choose(0);p.dneed=d-1;
  p.grants=q-1;bool last=q>0&&p.choose(0);
  if(!earlier&&!last)left-=fresh;
 }
 cout<<" "<<left;}cout<<endl;}
}
