# Injective assignments on a shared five-switch prefix

prefix-exact.cpp tests a single assignment of distinct graph vertices to a tuple of chosen earlier direct rays and mandatory raw names. For every pair in the tuple it tests adjacency against whether their union is full. Extending the tuple splits every existing chamber according to that raw's truth. At every depth each resulting cell must have at least half as many previous-direction representatives as required distinct maximal independent sets. The two-to-one bound and the prefix invariant are proved in PREFIX.md. At a leaf the direct labels must extend to a size-d independent set avoiding the already assigned nondirect raw labels. Every physical assignment passes these tests. The implementation drops cells of zero demand since they cannot create positive demand in later refinements.

At most q previously named activations can have nonraw values, where q ≤ d−2 can also be set lower for restricted strata. It therefore suffices for a necessary condition to try all subsets of exactly max(0,number of names−q) names as raw. The checker initially seeks d−1 direct rays from distinct earlier switches. For two directs, both must be full. In the unconstrained d4 stratum at most three nonprimitive names can occur in the first five activations, so two grants can leave at most one mandatory name. This is why the first injective-assignment extension changes the d4 count only when the allowed grants are further restricted.

prefix-suffix.cpp also separates extensions whose final activation is fresh: it is nonfull and equals neither an earlier activation nor an earlier primitive. On such an extension, if the last switch is not direct, all d directs must be available in the prefix. If it is direct then its activation strictly contains its own raw and cannot be another raw by incomparability. The new distinct nonraw name consumes one grant, leaving at most q−1 for the earlier names. Either alternative must succeed. This test requires only the count of fresh rows in each prefix (and the count of full extensions for d2). The planted controls require a known positive assignment on three named direct labels plus two other raw masks, and reject a duplicated raw mask given distinct vertex labels.

| Quota | After joint prefix test | After fresh-suffix test |
|---|---:|---:|
| d2 | 2,369 | 1,370 |
| d3 | 18,220 | 8,841 |
| d4, up to two nonraw grants | 30,851 | 18,024 |
| d4, up to one nonraw grant | 7,673 | 2,218 |
| d4, no nonraw grants | 272 | 64 |

Counts are remaining rows from 41,719, not circuit witnesses. The 64-row list retains all six known hard profiles. The tests across quotas are separate. No per-profile proof tree was stored. The table input prefix-suffix.tsv has 782 rows, each specifying its ID, number of catalogue rows, full-last count, fresh-last count and five earlier masks on 32 points. Compile with a C++20 compiler. Invoke the executable with the corresponding TSV path, 0 and 782. The six-axis catalogue provenance and remaining physical proofs are separate.
