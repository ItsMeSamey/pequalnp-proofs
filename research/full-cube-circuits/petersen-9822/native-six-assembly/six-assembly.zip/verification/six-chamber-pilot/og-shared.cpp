#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;
using M=uint64_t;using H=__uint128_t;using Domain=array<vector<int>,10>;constexpr M F=~M(0);
constexpr int edges[]={6,24,17,33,66,132,264,528,160,640,576,320,288};
constexpr int mis[]={50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773};
M sign[6];unsigned polar[10];bool adj[10][10];struct Cell{M m;unsigned s;};
struct Profile{
 M universe=0;set<M> primitive,names;
 explicit Profile(array<M,6>a){
 set<int> seen;for(int i=0;i<64;i++){int s=0;for(int j=0;j<6;j++)if(a[j]>>i&1)s|=1<<(2*j+(i>>j&1));if(seen.insert(s).second)universe|=M(1)<<i;}
 for(int j=0;j<6;j++){primitive.insert(universe&a[j]&sign[j]);primitive.insert(universe&a[j]&~sign[j]);}
 for(M z:a)if((z&universe)!=universe&&!primitive.contains(z&universe))names.insert(z&universe);}
};
struct Shared{
 const Profile&p;vector<M> value;vector<H> own;vector<int> needed;H banks=0;bool impossible=false;
 Shared(const Profile& profile,M g,const vector<M>&extra={}):p(profile){
 set<M>base=p.primitive;base.insert(g);base.insert(extra.begin(),extra.end());
 set<M> helpers{0};for(M x:base)for(M y:base){M h=x|y;if(!base.contains(h)&&!p.names.contains(h)&&h!=p.universe)helpers.insert(h);}
 if(helpers.size()>128)abort();map<M,H> owned;
 int k=0;for(M h:helpers){H b=H(1)<<k++;banks|=b;auto sources=base;sources.insert(h);sources.insert(0);
 for(M x:sources)for(M y:sources){M z=x|y;if(z&&z!=p.universe&&z!=g&&z!=h&&find(extra.begin(),extra.end(),z)==extra.end())owned[z]|=b;}}
 for(auto [z,b]:owned){value.push_back(z);own.push_back(b);}
 for(M w:p.names)if(w!=g&&find(extra.begin(),extra.end(),w)==extra.end()){
 auto it=lower_bound(value.begin(),value.end(),w);if(it==value.end()||*it!=w){impossible=true;break;}needed.push_back(it-value.begin());}
 }
 bool fits(const vector<Cell>&c,int v,M a)const{for(auto [r,s]:c)if(popcount(r&a)<popcount(s&polar[v])||popcount(r&~a)<popcount(s&~polar[v]))return false;return true;}
 bool pairs(const vector<Cell>&c,int v,int w,M a,M b)const{
 if(a==b||((a|b)==p.universe)!=adj[v][w])return false;
 for(auto [r,s]:c){auto x=polar[v],y=polar[w];
 if(popcount(r&a&b)<popcount(s&x&y)||popcount(r&a&~b)<popcount(s&x&~y)||
 popcount(r&~a&b)<popcount(s&~x&y)||popcount(r&~a&~b)<popcount(s&~x&~y))return false;}return true;
 }
 bool prune(Domain&ds,const vector<Cell>&c,H&allowed)const{
 for(auto &d:ds){H support=0;for(int z:d)support|=own[z];allowed&=support;if(!allowed)return false;}
 for(int v=0;v<10;v++){erase_if(ds[v],[&](int z){return !(allowed&own[z])||!fits(c,v,value[z]);});if(ds[v].empty())return false;}
 return true;
 }
 bool arc(Domain ds,const vector<Cell>&c,H h)const{
 for(;;){size_t before=0,after=0;for(auto &d:ds)before+=d.size();auto old=h;
 if(!prune(ds,c,h))return false;
 for(int v=0;v<10;v++){erase_if(ds[v],[&](int x){
 H xbanks=own[x]&h;
 for(int w=0;w<10;w++)if(w!=v){H supported=0;
 for(int y:ds[w])if((own[y]&xbanks)&&pairs(c,v,w,value[x],value[y])){supported|=own[y];if((supported&xbanks)==xbanks)break;}
 xbanks&=supported;if(!xbanks)return true;}return false;});
 if(ds[v].empty())return false;after+=ds[v].size();}
 if(before==after&&old==h)return true;}
 }
 bool search(Domain ds,const vector<Cell>&c,H h,int direct,int assigned,unsigned outstanding)const{
 if(!prune(ds,c,h))return false;
 if(!(direct&~assigned)&&!outstanding)return arc(ds,c,h);
 vector<pair<int,int>> choices;unsigned best=10000;
 for(int v=0;v<10;v++)if(((direct&~assigned)>>v&1)&&ds[v].size()<best){
 best=ds[v].size();choices.clear();for(int x:ds[v])choices.emplace_back(v,x);}
 for(unsigned t=outstanding;t;t&=t-1){int x=needed[countr_zero(t)];vector<pair<int,int>>opts;
 for(int v=0;v<10;v++)if(!(assigned>>v&1)&&binary_search(ds[v].begin(),ds[v].end(),x))opts.emplace_back(v,x);
 if(opts.size()<best){best=opts.size();choices=opts;}}
 for(auto [v,x]:choices){M a=value[x];auto d=ds;d[v]={x};bool ok=true;
 for(int w=0;w<10&&ok;w++)if(w!=v){erase_if(d[w],[&](int y){return !(own[x]&h&own[y])||!pairs(c,v,w,a,value[y]);});ok=!d[w].empty();}
 if(!ok)continue;vector<Cell> next;for(auto [r,s]:c){if(s&polar[v])next.push_back({r&a,s&polar[v]});if(s&~polar[v])next.push_back({r&~a,s&~polar[v]});}
 unsigned left=outstanding;for(unsigned t=left;t;t&=t-1)if(needed[countr_zero(t)]==x)left&=~(t&-t);
 if(search(d,next,h&own[x],direct,assigned|(1<<v),left))return true;}
 return false;}
 bool solve(const array<M,10>*fixed=nullptr)const{if(impossible)return false;
 for(int d:mis)if(popcount(unsigned(d))==4){
 Domain ds;for(int v=0;v<10;v++)for(int x=0;x<int(value.size());x++)if((!fixed||(*fixed)[v]==value[x])&&bool(d>>v&1)==p.primitive.contains(value[x]))ds[v].push_back(x);
 if(search(ds,{{p.universe,65535}},banks,d,0,(1u<<needed.size())-1))return true;}
 return false;}
};
int main(int argc,char**argv){if(argc!=4)return 2;for(int j=0;j<6;j++)for(int i=0;i<64;i++)if(i>>j&1)sign[j]|=M(1)<<i;
 for(int v=0;v<10;v++){for(int i=0;i<16;i++)if(!(mis[i]>>v&1))polar[v]|=1<<i;
 for(int w=0;w<10;w++)adj[v][w]=find(begin(edges),end(edges),(1<<v)|(1<<w))!=end(edges);}
 {ifstream c("../../six17-cert/control4-1.txt");Profile p({});p.universe=F;p.primitive.clear();M x;array<M,3>h;array<M,10>obs;
 for(int i=0;i<12;i++){c>>x;p.primitive.insert(x);}for(M& z:h)c>>z;for(M& z:obs)c>>z;
 for(M g:h){p.names={g};if(Shared(p,g).solve(&obs))return 4;}
 bool positive=false;for(M g:h)for(M e:h)if(g!=e){p.names={g,e};if(Shared(p,g,{e}).solve(&obs))positive=true;}if(!positive)return 5;}
 ifstream in(argv[1]);int id,fresh,k=0;array<M,6>a;
 while(in>>id>>fresh){for(M&z:a)in>>z;if(k++<stoi(argv[2]))continue;if(k>stoi(argv[3]))break;
 Profile p(a);int survivors=0;for(M g:p.names)survivors+=Shared(p,g).solve();cout<<id<<" "<<fresh<<" "<<p.names.size()<<" "<<survivors<<endl;}}
