from pathlib import Path
import re
src=Path('../../six17-cert/six17-fast.cpp').read_text()
match=re.search(r'fast\(3,\{([^}]+)\},\{\}\);if\(!hit\)',src);assert match
raw=[int(t.strip().removesuffix('ull')) for t in match[1].split(',')]
full=(1<<64)-1
prim={sum(1<<s for s in range(64) if (s>>j&1)==v) for j in range(6) for v in range(2)}
edges={6,24,17,33,66,132,264,528,160,640,576,320,288}
assert sum(v in prim for v in raw)==3
for s in range(1024):
 value=0
 for j,r in enumerate(raw):
  if s>>j&1:value|=r
 assert (value==full)==any((s&e)==e for e in edges)
def pairs(t):return {a|b for a in t for b in t}
def ok(t):return set(raw)<=pairs(t)
found=None
for a in sorted(pairs(prim)):
 q=prim|{a}
 assert not ok(q)
 if found:continue
 for b in pairs(q):
  if ok(q|{b}):found=(a,b);break
assert found
print('1024 evaluations; three direct; one helper fails; two helpers pass:',*found)
