#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
using U=uint64_t;using B=__uint128_t;using Domains=array<B,10>;
constexpr U full=~U(0);
const int edges[]={6,24,17,33,66,132,264,528,160,640,576,320,288};
vector<int> maximal,direct;bool graph[1024],adj[10][10];int ones[10];U hi[6];
int first(B b){return U(b)?countr_zero(U(b)):64+countr_zero(U(b>>64));}
int card(B b){return popcount(U(b))+popcount(U(b>>64));}
struct Chamber{U patterns;unsigned witnesses;};
using Chambers=vector<Chamber>;
bool divide(const Chambers &cs,int v,U mask,Chambers &result){
 for(auto c:cs){auto s=unsigned(ones[v]);U a=c.patterns&mask,b=c.patterns&~mask;unsigned t=c.witnesses&s,u=c.witnesses&~s;
 if(popcount(a)<popcount(t)||popcount(b)<popcount(u))return false;
 if(t)result.push_back({a,t});if(u)result.push_back({b,u});}
 return true;
}
struct Problem{
 U universe=0;set<U> primitive,mandatory;vector<U> library;vector<int> targets;B prim=0;
 bool initialize(const array<U,6>&u,U g,U h,const vector<U>*control=nullptr){
  for(int x=0;x<64;x++){int y=0;for(int j=0;j<6;j++)if(u[j]>>x&1)y|=x&(1<<j);universe|=U(1)<<y;}
  for(int j=0;j<6;j++){primitive.insert(universe&u[j]&hi[j]);primitive.insert(universe&u[j]&~hi[j]);}
  for(U a:u){a&=universe;if(a!=universe&&!primitive.contains(a)&&a!=g&&a!=h)mandatory.insert(a);}
  set<U> inputs=primitive;inputs.insert(g);inputs.insert(h);
  if(control)for(U v:*control)inputs.insert(v);
  set<U> bank=inputs;for(U x:inputs)for(U y:inputs)bank.insert(x|y);
  bank.erase(0);bank.erase(universe);bank.erase(g);bank.erase(h);
  if(control)for(U v:*control)bank.erase(v);
  library.assign(bank.begin(),bank.end());if(library.size()>128)abort();
  for(int i=0;i<int(library.size());i++)if(primitive.contains(library[i]))prim|=B(1)<<i;
  for(U a:mandatory){auto i=lower_bound(library.begin(),library.end(),a);if(i==library.end()||*i!=a)return false;targets.push_back(i-library.begin());}
  return true;
 }
 bool extend(Domains ds,const Chambers &cs,int chosen,int D,unsigned need){
  B united=0;int best=-1,nb=999;vector<pair<int,int>>opts;
  for(int v=0;v<10;v++){
   B d=ds[v];for(B t=d;t;t&=t-1){int i=first(t);U a=library[i];
     for(auto c:cs)if(popcount(c.patterns&a)<popcount(c.witnesses&unsigned(ones[v]))||
       popcount(c.patterns&~a)<popcount(c.witnesses&~unsigned(ones[v]))){ds[v]&=~(B(1)<<i);break;}}
   if(!ds[v])return false;united|=ds[v];
   if((D&~chosen)>>v&1 && card(ds[v])<nb){nb=card(ds[v]);best=v;}
  }
  if(card(united)<10)return false;
  if(best>=0)for(B t=ds[best];t;t&=t-1)opts.emplace_back(best,first(t));
  for(unsigned t=need;t;t&=t-1){int i=targets[countr_zero(t)];B b=B(1)<<i;vector<pair<int,int>>p;
    for(int v=0;v<10;v++)if(!(chosen>>v&1)&&(ds[v]&b))p.emplace_back(v,i);
    if(p.empty())return false;if(int(p.size())<nb){nb=p.size();opts=p;}
  }
  if(opts.empty()){
    // No more witness choices: non-assigned raw values need a simultaneous binary support on all graph pairs.
    for(bool changed=true;changed;){changed=false;
     for(int v=0;v<10;v++)for(B x=ds[v];x;x&=x-1){int i=first(x);U a=library[i];bool valid=true;
      for(int w=0;w<10&&valid;w++)if(v!=w){
       bool ok=false;for(B y=ds[w];y&&!ok;y&=y-1){int j=first(y);U b=library[j];
        if(((a|b)==universe)!=adj[v][w]||i==j)continue;ok=true;
        for(auto c:cs){U r=c.patterns;unsigned m=c.witnesses,va=ones[v],vb=ones[w];
         if(popcount(r&a&b)<popcount(m&va&vb)||popcount(r&~a&b)<popcount(m&~va&vb)||
            popcount(r&a&~b)<popcount(m&va&~vb)||popcount(r&~a&~b)<popcount(m&~va&~vb)){ok=false;break;}}}
       valid=ok;}
      if(!valid){changed=true;ds[v]&=~(B(1)<<i);if(!ds[v])return false;}
     }}
    return true;
  }
  for(auto [v,i]:opts){auto b=ds;U a=library[i];b[v]=B(1)<<i;bool ok=true;
   for(int w=0;w<10&&ok;w++)if(v!=w){for(B t=b[w];t;t&=t-1){int j=first(t);if(i==j||((a|library[j])==universe)!=adj[v][w])b[w]&=~(B(1)<<j);}ok=bool(b[w]);}
   if(!ok)continue;Chambers next;if(!divide(cs,v,a,next))continue;
   unsigned rem=need;for(int k=0;k<int(targets.size());k++)if(targets[k]==i)rem&=~(1u<<k);
   if(extend(b,next,chosen|(1<<v),D,rem))return true;
  }
  return false;
 }
 bool solve(const array<U,10>*fixed=nullptr){for(int D:direct){Domains ds{};
  for(int v=0;v<10;v++)for(int i=0;i<int(library.size());i++)
   if((!fixed||library[i]==(*fixed)[v])&&bool(prim>>i&1)==bool(D>>v&1))ds[v]|=B(1)<<i;
  if(extend(ds,{{universe,65535}},0,D,(1u<<targets.size())-1))return true;}return false;}
};
int main(int argc,char**argv){
 if(argc!=4)return 2;for(int e:edges)for(int s=0;s<1024;s++)if((s&e)==e)graph[s]=true;
 for(int s=0;s<1024;s++)if(!graph[s]){bool max=true;for(int j=0;j<10;j++)if(!(s>>j&1)&&!graph[s|(1<<j)])max=false;
 if(max){if(popcount(unsigned(s))==4)direct.push_back(s);maximal.push_back(s);}}
 if(maximal.size()!=16||direct.size()!=13)return 3;
 for(int v=0;v<10;v++){for(int j=0;j<16;j++)if(!(maximal[j]>>v&1))ones[v]|=1<<j;
 for(int w=0;w<10;w++)adj[v][w]=graph[(1<<v)|(1<<w)];}
 for(int j=0;j<6;j++)for(int x=0;x<64;x++)if(x>>j&1)hi[j]|=U(1)<<x;
 {ifstream c("../../six17-cert/control4-1.txt");array<U,6>u{};array<U,10>raw{};for(U&a:u){U l,r;c>>l>>r;a=l|r;}
  U a,b,d;c>>a>>b>>d;for(U&x:raw)c>>x;Problem p;vector<U>ex{d};
  // Fixture masks are uncompressed. Restrict every literal and observable to the canonical direction representatives.
  U rep=0;for(int x=0;x<64;x++){int y=0;for(int j=0;j<6;j++)if(u[j]>>x&1)y|=x&(1<<j);rep|=U(1)<<y;}
  for(U& x:raw)x&=rep;a&=rep;b&=rep;ex[0]&=rep;
  if(!p.initialize(u,a,b,&ex)||!p.solve(&raw))return 4;
  Problem q;if(q.initialize(u,a,b)&&q.solve(&raw))return 5;
 }
 int id,fresh,k=0;array<U,6>u;ifstream in(argv[1]);while(in>>id>>fresh){for(U&a:u)in>>a;
 if(k++<stoi(argv[2]))continue;if(k>stoi(argv[3]))break;
 U rep=0;for(int x=0;x<64;x++){int y=0;for(int i=0;i<6;i++)if(u[i]>>x&1)y|=x&(1<<i);rep|=U(1)<<y;}
 set<U>b,w;for(int i=0;i<6;i++){b.insert(rep&u[i]&hi[i]);b.insert(rep&u[i]&~hi[i]);}
 for(U x:u)if((x&rep)!=rep&&!b.contains(x&rep))w.insert(x&rep);
 int total=0,live=0;for(U g:w){
 set<U> source=b;source.insert(g);set<U> opt{0};
 for(U lhs:source)for(U rhs:source){U v=lhs|rhs;if(v!=rep&&!source.contains(v)&&!w.contains(v))opt.insert(v);}
 bool hit=false;for(U h:opt){Problem p;if(p.initialize(u,g,h)&&p.solve()){hit=true;break;}}
 total++;if(hit)live++;
 }
 cout<<id<<" "<<fresh<<" "<<total<<" "<<live<<endl;
 }}
