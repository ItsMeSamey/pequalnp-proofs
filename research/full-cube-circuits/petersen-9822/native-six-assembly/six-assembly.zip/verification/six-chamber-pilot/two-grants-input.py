from pathlib import Path
from itertools import groupby
import gzip
M=2**64-1
r=[tuple(map(int,l.split()))for l in gzip.open('../../six17-cert/six-all.txt.gz','rt')]
ledger=[list(map(int,l.split())) for l in open('prefix-suffix.log')]
out=[];start=0
for n,(prefix,gg) in enumerate(groupby(r,key=lambda a:a[:5])):
 g=list(gg);left=ledger[n][4]
 rays=set()
 for j,a in enumerate(prefix):
  H=sum(1<<x for x in range(64) if x>>j&1)
  rays.update([a&H,a&~H])
 old=rays|set(prefix)|{M}
 for i,a in enumerate(g):
  if left and (left==len(g) or a[5] in old):
   out.append((start+i,int(a[5] not in old),*a))
 start+=len(g)
assert len(out)==18024
with open('/dev/shm/9822-two-grants-input.tsv','w') as f:
 for t in out:print(*t,file=f)
print(len(out),sum(x[1] for x in out))
