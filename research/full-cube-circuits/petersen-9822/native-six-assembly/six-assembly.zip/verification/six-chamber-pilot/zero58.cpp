#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
using M=uint64_t;
using R=array<M,16>;
const int edges[]={6,24,17,33,66,132,264,528,160,640,576,320,288};
int mis[16],pat[10],adj[10],nodes,anchors,deep;
M full,raw[10];
vector<M> prim,wide,names;
bool edge(int s){for(int e:edges)if((s&e)==e)return true;return false;}
bool put(int v,M x,int assigned,const R&r,R&nr){
 for(int j=0;j<10;j++)if(assigned>>j&1){
  M y=raw[j];if(!(x&~y)||!(y&~x)||((x|y)==full)!=bool(adj[v]>>j&1))return false;
 }
 for(int k=0;k<16;k++)nr[k]=r[k]&((mis[k]>>v&1)?~x:x);
 // Equal chambers have to provide one different trace per MIS.
 for(int k=0;k<16;k++){int n=0;for(M a:nr)n+=(a==nr[k]);if(n>popcount(nr[k]))return false;}
 return true;
}
bool dfs(int D,int used,int pending,const R&r){
 ++nodes;if(used==1023)return true;
 int best=100000;vector<pair<int,M>> opts;
 auto consider=[&](vector<pair<int,M>> b){if(int(b.size())<best){best=b.size();opts=move(b);}};
 R nr;for(int k=0;k<int(names.size());k++)if(pending>>k&1){
  vector<pair<int,M>> b;for(int v=0;v<10;v++)if(!((used|D)>>v&1)&&put(v,names[k],used,r,nr))b.emplace_back(v,names[k]);consider(move(b));}
 bool anchored=!(D&~used)&&!pending;
 if(anchored)++anchors;
 for(int v=0;v<10;v++)if(!(used>>v&1)&&((D>>v&1)||anchored)){
  vector<pair<int,M>> b;for(M x:(D>>v&1?prim:wide))if(put(v,x,used,r,nr))b.emplace_back(v,x);consider(move(b));}
 if(anchored&&!opts.empty())++deep;
 for(auto[v,x]:opts){if(!put(v,x,used,r,nr))abort();int p=pending;for(int k=0;k<int(names.size());k++)if(names[k]==x)p&=~(1<<k);
 raw[v]=x;if(dfs(D,used|(1<<v),p,nr))return true;}
 return false;
}
int main(){
 int m=0;for(int s=0;s<1024;s++)if(!edge(s)){bool maximal=true;for(int v=0;v<10;v++)if(!(s>>v&1)&&!edge(s|(1<<v)))maximal=false;if(maximal)mis[m++]=s;}
 if(m!=16)return 2;
 for(int v=0;v<10;v++)for(int w=0;w<10;w++)if(edge((1<<v)|(1<<w)))adj[v]|=1<<w;
 int id;while(cin>>id){array<M,6> a;for(M&u:a)if(!(cin>>u))return 3;
 set<int> traces;set<M>b,w;full=0;for(int s=0;s<64;s++){int t=0;for(int j=0;j<6;j++)if(a[j]>>s&1)t|=1<<(2*j+(s>>j&1));if(traces.insert(t).second)full|=M(1)<<s;}
 for(int j=0;j<6;j++){M h=0;for(int s=0;s<64;s++)if(s>>j&1)h|=M(1)<<s;b.insert(full&a[j]&h);b.insert(full&a[j]&~h);}
 b.erase(0);for(M u:a)if((u&full)!=full&&!b.count(u&full))w.insert(u&full);
 set<M>lib{0};for(int i=0;i<4;i++){auto prev=lib;for(M h:prev)for(M x:b)lib.insert(h|x);}
 bool valid=true;for(M u:w)if(!lib.count(u))valid=false;
 names.assign(w.begin(),w.end());prim.assign(b.begin(),b.end());for(M x:b)lib.erase(x);lib.erase(0);lib.erase(full);wide.assign(lib.begin(),lib.end());
 nodes=anchors=deep=0;bool hit=false;R rooms;rooms.fill(full);
 if(valid)for(int D:mis)if(popcount(unsigned(D))==4&&dfs(D,0,(1<<names.size())-1,rooms)){hit=true;break;}
 cout<<id<<" "<<nodes<<" "<<anchors<<" "<<deep<<" "<<hit<<endl;}
}
