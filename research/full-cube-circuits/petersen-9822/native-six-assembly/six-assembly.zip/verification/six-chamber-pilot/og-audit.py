from collections import Counter
from hashlib import sha256
from pathlib import Path
source=Path('/dev/shm/9822-one-grant-input.tsv')
pri=Path('og-shared-final.tsv')
alt=Path('og-independent-final.tsv')
assert sha256(source.read_bytes()).hexdigest()=='1f724533c52232db4f647fd8feacdfb2593af246ec73628eb6ff4671d6ba8285'
assert pri.read_bytes()==alt.read_bytes()
H=[sum(1<<w for w in range(64) if w>>j&1) for j in range(6)]
F=2**64-1
number=0;choices=0;options=0;fresh=0;previous=-1;hist=Counter()
for x,y in zip(source.read_text().splitlines(),pri.read_text().splitlines(),strict=True):
    i,flag,*u=map(int,x.split());i2,flag2,n,live=map(int,y.split())
    assert (i,flag)==(i2,flag2) and i>previous and live==0; previous=i
    b={v for j,m in enumerate(u) for v in (H[j]&m,~H[j]&m)}
    W=set(u)-b-{F};assert len(W)==n
    for g in W:
        base=b|{g}
        options+=len((({p|q for p in base for q in base}-base-W-{F})|{0}))
    number+=1;choices+=n;fresh+=flag;hist[n]+=1
print('profiles',number,'fresh',fresh,'grants',choices,'optional helper settings',options,'named counts',dict(sorted(hist.items())))
assert (number,choices,options,fresh)==(2218,4680,288559,1750)
print('identical ledger SHA-256',sha256(pri.read_bytes()).hexdigest())
