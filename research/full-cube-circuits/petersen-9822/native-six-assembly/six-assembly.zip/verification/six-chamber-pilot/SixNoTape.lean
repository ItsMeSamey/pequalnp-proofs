import Init

namespace Research.Graph9822.SixNoTape

abbrev Domain (V X : Type) := V → List X
abbrev State (V X : Type) := List (V × X)

def consistent {V X : Type} (raw : V → X) (st : State V X) : Prop :=
  ∀ p ∈ st, raw p.1 = p.2

/-- An empty surviving domain or impossible bank is a terminal rejection.
    Otherwise a fixed vertex order supplies all branches, without a proof stream. -/
def reject {V X : Type} (reduce : State V X → Domain V X → Domain V X)
    (dead : State V X → Domain V X → Bool) (st : State V X) (dom : Domain V X) :
    List V → Bool
  | [] => dead st (reduce st dom)
  | v :: vs =>
    let next := reduce st dom
    dead st next || (next v).all fun x => reject reduce dead ((v,x)::st) next vs

theorem reject_sound {V X : Type} (raw : V → X)
    (reduce : State V X → Domain V X → Domain V X)
    (dead : State V X → Domain V X → Bool)
    (keep : ∀ st dom, consistent raw st → (∀ u, raw u ∈ dom u) →
      ∀ u, raw u ∈ reduce st dom u)
    (noDead : ∀ st dom, consistent raw st → (∀ u, raw u ∈ dom u) →
      dead st dom = false)
    (vs : List V) (st : State V X) (dom : Domain V X)
    (hs : consistent raw st) (inside : ∀ u, raw u ∈ dom u)
    (bad : reject reduce dead st dom vs = true) : False := by
  induction vs generalizing st dom with
  | nil =>
    simpa [reject, noDead st (reduce st dom) hs (keep st dom hs inside)] using bad
  | cons v vs ih =>
    have live := keep st dom hs inside
    have allChoices : ((reduce st dom v).all fun x =>
        reject reduce dead ((v,x)::st) (reduce st dom) vs) = true := by
      simpa [reject, noDead st (reduce st dom) hs live] using bad
    have pick := List.all_eq_true.mp allChoices (raw v) (live v)
    apply ih ((v,raw v)::st) (reduce st dom) _ live pick
    intro p hp
    rcases List.mem_cons.mp hp with rfl | hp
    · rfl
    · exact hs p hp

end Research.Graph9822.SixNoTape
