import gzip
from collections import Counter
from itertools import groupby
from pathlib import Path
rows=[tuple(map(int,s.split())) for s in gzip.open('../../six17-cert/six-all.txt.gz','rt')]
groups=[list(map(int,s.split())) for s in Path('prefix-suffix.log').read_text().splitlines()]
full=2**64-1
for d,n in [(2,1370),(3,8841)]:
 selected=[]
 for g,(_,it) in zip(groups,groupby(enumerate(rows),key=lambda it:it[1][:5]),strict=True):
  block=list(it); a=block[0][1][:5]; assert len(block)==g[1]
  base={full,*a}
  for j,u in enumerate(a):
   sign=sum(1<<s for s in range(64) if s>>j&1)
   base.update((u&sign,u&~sign))
  old=[r for r in block if r[1][-1] in base]
  admissible=block if g[d]==len(block) else [r for r in old if d!=2 or a.count(full)>=2 or r[1][-1]==full]
  if g[d]==0:admissible=[]
  assert len(admissible)==g[d]
  selected.extend((i,int(r[-1] not in base),*r) for i,r in admissible)
 assert len(selected)==n
 assert selected==[tuple(map(int,s.split())) for s in Path(f'lowd{d}.in').read_text().splitlines()]
 ids=[t[0] for t in selected]; assert ids[-1]==41718
 for kind in ['priced','shared']:
  tab=Path(f'lowd{d}-{kind}-all.tsv')
  if not tab.exists():continue
  lines=[s.split() for s in tab.read_text().splitlines()]
  assert [int(x[0]) for x in lines]==ids
  assert lines[-1]==['41718','star']
  assert all(int(x[-1])==0 for x in lines[:-1])
 print(d,n)

for d in [2,3]:
 ids=[int(s.split()[0]) for s in Path(f'lowd{d}.in').read_text().splitlines()]
 archived={int(s.split()[0]):s.strip() for s in gzip.open(f'../../six17-cert/logs/size17-d{d}.ac.gz','rt') if s.split()[0].isdigit()}
 rank={v:i for i,v in enumerate(i for i,r in enumerate(rows) if r.count(full)==4)}
 hist={}
 for name in (['six-two-d2','six-two-d2b'] if d==2 else ['six-two-d3']):
  for line in gzip.open('../../six17-cert/logs/'+name+'.log.gz','rt'):
   t=line.split()
   if t[0].isdigit():hist[int(t[0])]=line.strip()
 assert set(hist)==set(range(96))
 result=Counter()
 for i in ids:
  if i==41718:result['star']+=1;continue
  s=archived[i]
  if s.endswith('prior-four-full'):
   assert hist[rank[i]].endswith('hits 0');result['four-full subcatalogue']+=1
  else:
   assert s.endswith('excluded') or s.endswith('hits 0') or 'impossible' in s,s
   result['global historical ledger']+=1
 print('archive',d,result)
