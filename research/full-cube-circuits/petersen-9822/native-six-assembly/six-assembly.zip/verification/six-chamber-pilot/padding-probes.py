from itertools import combinations
from pathlib import Path
import gzip
full=(1<<32)-1
half=[sum(1<<i for i in range(32) if (i>>j)&1) for j in range(5)]
def expand(a):return a+(a<<32)
def traces(a,n):
 return {tuple(None if not (m>>i)&1 else (i>>j)&1 for j,m in enumerate(a)) for i in range(1<<n)}
def rays(a,n):
 return {sum(1<<s for s in range(1<<n) if (m>>s)&1 and (s>>j)&1==v) for j,m in enumerate(a) for v in [0,1]}
for name,act in [('full',[full]*5),('conditional',[full,full^half[0],full,full,full]),('nonprimitive',[full,full,(full^half[0])|(full^half[1]),full,full])]:
 lift=[*map(expand,act),expand(full)]
 b5=rays(act,5);b6=rays(lift,6)
 assert b6=={*map(expand,b5),full,full<<32}
 old={x|y for x in b5 for y in b5}|b5
 assert all((expand(x) in b6)==(x in b5) for x in old)
 assert len(traces(lift,6))==2*len(traces(act,5))
 w5=set(act)-b5-{full};w6=set(lift)-b6-{expand(full)}
 assert set(map(expand,w5))==w6
 print(name,len(traces(act,5)),len(traces(lift,6)),len(old),len(w5))
edges={6,24,17,33,66,132,264,528,160,640,576,320,288}
assert min(s.bit_count() for s in range(1024) if all(s&e for e in edges))==6
assert not any(all(((1<<x)|(1<<y)) in edges for x in [a,b] for y in [c,d])
 for a,b in combinations(range(10),2) for c,d in combinations(set(range(10))-{a,b},2))
print('13 edges, no four-cycle, minimum vertex cover 6')
