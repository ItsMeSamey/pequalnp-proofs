"""Regenerate both grouped checker inputs from the exact compressed catalogue."""
from itertools import groupby
from pathlib import Path
import gzip
full=2**64-1
halves=[sum(1<<x for x in range(64) if x>>j&1) for j in range(5)]
rows=[tuple(map(int,l.split())) for l in gzip.open('../../six17-cert/six-all.txt.gz','rt')]
out0=[];out1=[]
for i,(prefix,g) in enumerate(groupby(rows,key=lambda a:a[:5])):
    group=list(g)
    rays={z for a,h in zip(prefix,halves) for z in (a&h,a&~h)}
    old=rays|set(prefix)|{full}
    assert all(a>>32==a&0xffffffff for a in prefix)
    for row in group:
        u=row[-1];value=0
        for ray in rays:
            if ray&~u==0:value|=ray
        assert u==full or value==u
    head=(i,len(group),sum(r[5]==full for r in group))
    suffix=sum(r[5] not in old for r in group)
    p=tuple(a&0xffffffff for a in prefix)
    out0.append(' '.join(map(str,head+p)))
    out1.append(' '.join(map(str,head+(suffix,)+p)))
for path,lines in [('prefix-groups.tsv',out0),('prefix-suffix.tsv',out1)]:
    assert Path(path).read_text()=='\n'.join(lines)+'\n'
print('verified',len(rows),'rows and',len(out1),'prefix records')
