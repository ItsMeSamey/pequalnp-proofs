from pathlib import Path
import sys,subprocess,tempfile
exe,d,key=sys.argv[1:]
source=Path(f'lowd{d}.in').read_text().splitlines()
out=Path(f'lowd{d}-{key}-all.tsv')
done={int(s.split()[0]) for s in out.read_text().splitlines()} if out.exists() else set()
if key=='priced' and d=='3':
 for p in sorted(Path('lowd3-rows').glob('*')):
  for s in p.read_text().splitlines():
   i=int(s.split()[0])
   if i not in done:
    with out.open('a') as f:print(s,file=f)
    done.add(i)
source=[s for s in source if int(s.split()[0]) not in done]
while source:
 if source[0].split()[0]=='41718':
  with out.open('a') as f:print('41718 star',file=f)
  source.pop(0);continue
 chunk=[s for s in source[:120] if s.split()[0]!='41718']
 with tempfile.NamedTemporaryFile('w+',dir='/dev/shm') as f:
  print(*chunk,sep='\n',file=f,flush=True)
  r=subprocess.run(['flock','-F','/workspace/scratch/pnp-native-search.lock','nice','-n','15','timeout','12s','prlimit','--as=167772160','--cpu=12',exe,f.name,d,'x'],stdout=subprocess.PIPE,text=True)
 rows=r.stdout.splitlines()
 assert all(a.split()[0]==b.split()[0] for a,b in zip(rows,chunk))
 if r.returncode not in [0,124,-9,137]:raise RuntimeError(r.returncode)
 with out.open('a') as f:
  for row in rows:print(row,file=f)
  if not rows:print(chunk[0].split()[0],'pending',file=f)
 del source[:max(1,len(rows))]
