"""Lossless six-mask catalogue transport. Integers and indices are little endian."""
from pathlib import Path
from itertools import groupby
import gzip, struct, hashlib
src=Path('../../six17-cert/six-all.txt.gz')
rows=[tuple(map(int,l.split())) for l in gzip.open(src,'rt')]
assert rows==sorted(rows) and len(rows)==41719
lex=sorted({m for r in rows for m in r});ids={m:i for i,m in enumerate(lex)}
ps=[(p,[r[-1] for r in g]) for p,g in groupby(rows,key=lambda r:r[:5])]
out=bytearray(struct.pack('<HH',len(lex),len(ps)))
for m in lex:out+=struct.pack('<Q',m)
for p,last in ps:
    out+=struct.pack('<6H',*(ids[m] for m in p),len(last))
    out+=struct.pack('<'+'H'*len(last),*(ids[m] for m in last))
raw=bytes(out);Path('six-prefix.bin.gz').write_bytes(gzip.compress(raw,mtime=0))
n,g=struct.unpack_from('<HH',raw);table=struct.unpack_from('<'+'Q'*n,raw,4)
v=4+8*n;decoded=[]
for _ in range(g):
    *head,count=struct.unpack_from('<6H',raw,v);v+=12
    for k in struct.unpack_from('<'+'H'*count,raw,v):decoded.append(tuple(table[i] for i in head+[k]))
    v+=2*count
assert v==len(raw) and decoded==rows
print('rows',len(rows),'prefixes',len(ps),'masks',len(lex),'bytes',len(raw),'gzip',Path('six-prefix.bin.gz').stat().st_size,'sha',hashlib.sha256(raw).hexdigest())
