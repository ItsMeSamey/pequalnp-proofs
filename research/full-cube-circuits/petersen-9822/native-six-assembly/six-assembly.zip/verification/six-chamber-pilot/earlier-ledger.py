from collections import Counter
from pathlib import Path
import gzip
base=Path('../../six17-cert/logs')
for name in ('size17-d2.ac','size17-d3.ac','size17-d4-one-complete.ac','size17-d4-two.ac','size17-d4-allraw.filter'):
    c=Counter()
    for row in gzip.open(base/(name+'.gz'),'rt'):
        w=row.split()
        if 'banks' in w:
            n=int(w[w.index('banks')+1]);v=int(w[w.index('visits')+1])
            c['visited' if v else 'bank_without_visit' if n else 'no_bank']+=1
        else:c[' '.join(w[1:]) if 'atoms' not in w else 'few_atoms']+=1
    print(name,c)
