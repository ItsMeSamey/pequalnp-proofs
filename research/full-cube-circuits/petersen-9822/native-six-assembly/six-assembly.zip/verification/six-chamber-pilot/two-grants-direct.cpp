#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
using M=uint64_t;
using B=__uint128_t;
constexpr M all=~M(0);
constexpr int edges[]={6,24,17,33,66,132,264,528,160,640,576,320,288};
constexpr int mis[]={50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773};
int activeId=-1;array<M,6> halves;int demand[10][10][4],adj[10],hot[10];vector<int> directSets;
int count128(B x){return popcount(M(x))+popcount(M(x>>64));}
int first(B x){return M(x)?countr_zero(M(x)):64+countr_zero(M(x>>64));}
struct Candidate{M raw;int support;};
struct Profile{
 vector<M>rays,ws;M reps=0;
 explicit Profile(const array<M,6>&u){
  set<unsigned> signature;
  for(int p=0;p<64;p++){unsigned t=0;for(int j=0;j<6;j++)if(u[j]>>p&1)t|=1u<<(2*j+(p>>j&1));if(signature.insert(t).second)reps|=M(1)<<p;}
  set<M> b,w;for(int j=0;j<6;j++){b.insert(reps&u[j]&halves[j]);b.insert(reps&u[j]&~halves[j]);}
  for(M a:u)if((a&reps)!=reps&&!b.contains(a&reps))w.insert(a&reps);
  rays.assign(b.begin(),b.end());ws.assign(w.begin(),w.end());
 }
 bool bank(int g,int h,int extra=-1,const array<M,10>* fixed=nullptr)const{
  vector<M>base=rays;base.push_back(ws[g]);base.push_back(ws[h]);if(extra>=0)base.push_back(ws[extra]);
  set<M>vals(base.begin(),base.end());for(M a:base)for(M b:base)vals.insert(a|b);
  // Granted nonraw masks may coincide with neither a raw target nor the full source.
  vals.erase(0);vals.erase(reps);vals.erase(ws[g]);vals.erase(ws[h]);if(extra>=0)vals.erase(ws[extra]);
  vector<M>lib(vals.begin(),vals.end());int n=lib.size();if(n>128)abort();
  B ray=0,required=0;array<B,10>dom{};array<B,128>neighbors{};
  for(int k=0;k<n;k++){M a=lib[k];B bit=B(1)<<k;if(binary_search(rays.begin(),rays.end(),a))ray|=bit;
   for(int v=0;v<10;v++)if((!fixed||a==(*fixed)[v])&&popcount(a)>=hot[v]&&popcount(reps&~a)>=16-hot[v])dom[v]|=bit;
   for(int j=0;j<k;j++)if((a|lib[j])==reps&&a!=lib[j]&&(a&lib[j])){neighbors[k]|=B(1)<<j;neighbors[j]|=bit;}
  }
  for(int i=0;i<int(ws.size());i++)if(i!=g&&i!=h&&i!=extra){auto it=lower_bound(lib.begin(),lib.end(),ws[i]);if(it==lib.end()||*it!=ws[i])return false;required|=B(1)<<(it-lib.begin());}
  auto viable=[&](array<B,10> D){
   for(bool changed=true;changed;){
    changed=false;B united=0;
    for(int v=0;v<10;v++){
     for(B x=D[v];x;x&=x-1){int k=first(x);B avail=neighbors[k];B choices[3]{};int deg=0;bool ok=true;
      for(unsigned t=adj[v];t;t&=t-1){int z=countr_zero(t);B y=D[z]&avail,pass=0;
       for(B it=y;it;it&=it-1){int j=first(it);M a=lib[k],b=lib[j];auto req=demand[v][z];
        if(popcount(a&b)>=req[0]&&popcount(a&~b)>=req[1]&&popcount(b&~a)>=req[2])pass|=B(1)<<j;}
       choices[deg++]=pass;if(!pass){ok=false;break;}
      }
      if(ok)for(int t=1;t<(1<<deg);t++){B possible=0;for(int i=0;i<deg;i++)if(t>>i&1)possible|=choices[i];if(count128(possible)<popcount(unsigned(t))){ok=false;break;}}
      if(!ok){D[v]&=~(B(1)<<k);changed=true;}
     }
     if(!D[v])return false;united|=D[v];
    }
    if((required&~united)||count128(united)<10)return false;
   }
   return true;
  };
  if(!viable(dom))return false;
  auto pairOK=[&](int v,int z,int i,int j){
     M a=lib[i],b=lib[j];auto t=demand[v][z];
     return (((a|b)==reps)==bool(adj[v]>>z&1))&&popcount(a&b)>=t[0]&&popcount(a&~b)>=t[1]&&popcount(b&~a)>=t[2]&&popcount(reps&~(a|b))>=t[3];};
  // A fixed subset of labels must preserve a whole direction for each maximal independent set.
  auto witnessed=[&](const array<B,10>&a,int fixed){
   for(int s:mis){M room=reps;for(unsigned bits=fixed;bits;bits&=bits-1){int i=countr_zero(bits);M m=lib[first(a[i])];room &= s>>i&1?~m:m;}if(!room)return false;}return true;};
  for(int d:directSets){auto D=dom;for(int i=0;i<10;i++)D[i]&=d>>i&1?ray:~ray;
   using Domains=array<B,10>;
   function<bool(Domains,int,int)> assignDirect=[&](Domains a,int assigned,int todo){
    if(!witnessed(a,assigned))return false;
    if(!todo){
      if(!viable(a))return false;
      if(!fixed){cerr<<activeId<<" "<<g<<" "<<h<<" "<<d<<" "<<assigned;
       for(int i=0;i<10;i++)if(assigned>>i&1)cerr<<" "<<i<<":"<<lib[first(a[i])];cerr<<endl;}
      return true;}
    int v=-1;for(unsigned t=todo;t;t&=t-1){int j=countr_zero(t);if(v<0||count128(a[j])<count128(a[v]))v=j;}
    for(B x=a[v];x;x&=x-1){int k=first(x);auto b=a;b[v]=B(1)<<k;bool ok=true;
     for(int z=0;z<10&&ok;z++)if(v!=z){for(B t=b[z];t;t&=t-1){int j=first(t);if(!pairOK(v,z,k,j))b[z]&=~(B(1)<<j);}ok=bool(b[z]);}
     if(ok&&assignDirect(b,assigned|(1<<v),todo^(1<<v)))return true;}
    return false;};
   function<bool(B,Domains,int)> anchored=[&](B remaining,Domains a,int assigned){
    if(!remaining)return assignDirect(a,assigned,d);
    int k=first(remaining);B bit=B(1)<<k;
    for(int v=0;v<10;v++)if(a[v]&bit){
     auto b=a;b[v]=bit;bool ok=true;
     for(int z=0;z<10&&ok;z++)if(v!=z){
      for(B t=b[z];t;t&=t-1){int j=first(t);if(!pairOK(v,z,k,j))b[z]&=~(B(1)<<j);}
      ok=bool(b[z]);}
     if(ok&&anchored(remaining^bit,b,assigned|(1<<v)))return true;
    }
    return false;
   };if(anchored(required,D,0))return true;
  }
  return false;
 }
};
int main(int argc,char**argv){
 if(argc!=4)return 2;for(int j=0;j<6;j++)for(int x=0;x<64;x++)if(x>>j&1)halves[j]|=M(1)<<x;
 for(int e:edges)for(int j=0;j<10;j++)if(e>>j&1)adj[j]|=e^(1<<j);
 for(int s:mis){if(popcount(unsigned(s))==4)directSets.push_back(s);
  for(int a=0;a<10;a++){hot[a]+=!(s>>a&1);for(int b=0;b<10;b++)demand[a][b][2*(s>>a&1)+(s>>b&1)]++;}}
 // Same observed receiver tuple: all three physical helpers succeed, dropping any one fails.
 {ifstream control("../../six17-cert/control4-1.txt");array<M,6> u{};Profile p(u);p.reps=all;p.rays.resize(12);p.ws.resize(3);
  for(M&z:p.rays)control>>z;sort(p.rays.begin(),p.rays.end());for(M&z:p.ws)control>>z;
  array<M,10>obs;for(M&z:obs)if(!(control>>z))return 4;
  if(!p.bank(0,1,2,&obs))return 5;
  for(int i=0;i<3;i++)for(int j=0;j<i;j++){auto q=p;q.ws={p.ws[i],p.ws[j]};if(q.bank(0,1,-1,&obs))return 6;}
 }
 ifstream in(argv[1]);int id,fresh,k=0;array<M,6>u;
 while(in>>id>>fresh){for(M&a:u)in>>a;if(k++<stoi(argv[2]))continue;if(k>stoi(argv[3]))break;
  activeId=id;Profile p(u);int total=0,live=0;for(int g=0;g<int(p.ws.size());g++)for(int h=0;h<g;h++){total++;live+=p.bank(g,h);}
  cout<<id<<" "<<fresh<<" "<<total<<" "<<live<<endl;
 }
}
