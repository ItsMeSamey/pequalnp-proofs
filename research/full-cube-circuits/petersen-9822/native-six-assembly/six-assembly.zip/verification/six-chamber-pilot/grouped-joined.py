"""Universal prefix cuts with one unresolved last selector; no learned tables."""
from itertools import combinations,permutations,groupby,product
from collections import Counter
import gzip
from functools import lru_cache
from pathlib import Path
F=(1<<64)-1;low=2**32-1
h=[sum(1<<s for s in range(32) if s>>j&1) for j in range(5)]
mis=(50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773)
E={6,24,17,33,66,132,264,528,160,640,576,320,288}
@lru_cache(None)
def labels(n,d=0):
    seen=set()
    for v in permutations(range(10),n):
        if d and not any(m.bit_count()>=d and all(m>>x&1 for x in v[:d-1]) for m in mis):continue
        rooms=[0]*(1<<n)
        for m in mis:rooms[sum((not m>>x&1)<<j for j,x in enumerate(v))]+=1
        graph=tuple((1<<a|1<<b) in E for a,b in combinations(v,2))
        seen.add((graph,tuple(rooms)))
    result={}
    for graph,rooms in seen:result.setdefault(graph,[]).append(rooms)
    return result
def process(p):
    rays=[z for u,t in zip(p,h) for z in (u&t,(low^t)&u)]
    seen=set();atoms=0
    for s in range(32):
        sig=tuple((b>>s)&1 for b in rays)
        if sig not in seen:atoms|=1<<s;seen.add(sig)
    W=sorted(set(p)-set(rays)-{low})
    def rawok(raw,d=0):
        graph=tuple((a|b)==low for a,b in combinations(raw,2))
        rooms=[atoms]
        for r in raw:rooms=[x&~r for x in rooms]+[x&r for x in rooms]
        caps=[2*x.bit_count() for x in rooms]
        return any(all(a<=b for a,b in zip(needs,caps)) for needs in labels(len(raw),d).get(graph,()))
    leaf2={a|b for a in rays for b in rays}
    debt=min((len(W)-len(r) for n in range(len(W)+1) for r in combinations(W,n) if rawok(r)), default=10)
    direct={}
    for d in [2,3,4]:
        viable=False
        for axes in combinations(range(5),d-1):
            if d==2 and any(p[i]!=low for i in axes):continue
            for signs in product(range(2),repeat=d-1):
                vs=tuple(rays[2*i+b] for i,b in zip(axes,signs))
                if rawok(vs,d) and sum(not rawok(vs+(w,),d) for w in W)<=d-2:viable=True;break
            if viable:break
        direct[d]=viable
    return debt,all(w in leaf2 for w in W),direct
src=Path('../../six17-cert/six-all.txt.gz')
rows=[tuple(map(int,l.split())) for l in gzip.open(src,'rt')]
counts=Counter()
labels0=labels
for p,g in groupby(rows,key=lambda a:a[:5]):
    g=list(g);assert all((u>>32)==(u&low) for u in p)
    cost,width,direct=process(tuple(u&low for u in p))
    counts['prefixes']+=1
    for d in (2,3,4):
        hit=0
        for u in g:
            if not direct[d] or cost>d-2 or (d==2 and (not width or u.count(F)<2)):hit+=1
        counts[d,'rows']+=hit
        counts[d,'whole groups']+=int(hit==len(g))
    counts['all W raw: rows']+=len(g)*bool(cost)
    counts['all W raw: groups']+=bool(cost)
print(counts)
