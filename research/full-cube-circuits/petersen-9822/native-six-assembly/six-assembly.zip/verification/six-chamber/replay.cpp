#include <algorithm>
#include <map>
#include <array>
#include <bit>
#include <bitset>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <iterator>
#include <set>
#include <stdexcept>
#include <vector>
using namespace std;using W=uint64_t;using Doms=array<bitset<1024>,10>;
struct Reader {vector<unsigned char>text;size_t p=0;int records=0;int get(){return text.at(p++);}};
const int E[]={6,24,17,33,66,132,264,528,160,640,576,320,288};
bool edge(unsigned x){return find(begin(E),end(E),x)!=end(E);}
array<W,10>want{};vector<unsigned>mis;
bool ind(unsigned x){for(int e:E)if((x&e)==(unsigned)e)return false;return true;}
bool proper(unsigned D){if(!ind(D))return false;for(unsigned t=D;t;t=(t-1)&D){
 int n=0;for(auto i:mis)n+=!(i&t);if(n>(64>>popcount(t)))return false;}return true;}
struct Cell{W a,b;};
struct Check{
 W full=0;vector<W>lib;bitset<1024>direct;
 vector<bitset<8192>> owners;vector<unsigned> mandatory;bitset<8192> banks;
 Check(const array<W,6>&U,int d){
 for(unsigned w=0;w<64;w++){unsigned low=0;for(int i=0;i<6;i++)if(U[i]>>w&1)low|=w&(1u<<i);
 for(int i=0;i<6;i++)if(((U[i]>>low)&1u)!=((U[i]>>w)&1u))throw runtime_error("bad canonicalize");full|=W(1)<<low;}
 set<W>rays;for(int i=0;i<6;i++){W h=0;for(int w=0;w<64;w++)if(w>>i&1)h|=W(1)<<w;
 rays.insert(full&U[i]&h);rays.insert(full&U[i]&~h);}
 vector<W>b(rays.begin(),rays.end());set<W>pool;
 for(unsigned t=1;t<(1u<<b.size());t++)if(popcount(t)<=d){W y=0;
 for(unsigned j=0;j<b.size();j++)if(t>>j&1)y|=b[j];if(y&&y!=full)pool.insert(y);}
 lib.assign(pool.begin(),pool.end());for(size_t j=0;j<lib.size();j++)direct.set(j,rays.contains(lib[j]));
 map<W,unsigned> index;for(unsigned i=0;i<lib.size();i++)index[lib[i]]=i;
 bool impossible=false;
 for(W w:U){w &= full;if(w!=full&&!rays.contains(w)){
 if(!index.contains(w)){impossible=true;continue;} mandatory.push_back(index[w]);}}
 owners.resize(lib.size());if(impossible)return;
 set<W> h1{0};for(W a:rays)for(W b:rays)h1.insert(a|b);
 set<std::pair<W,W>> histories;
 for(W x:h1){set<W> h2=h1;for(W v:rays)h2.insert(v|x);
 for(W y:h2)histories.insert(minmax(x,y));}
 unsigned num=0;
 for(auto [x,y]:histories){auto primitives=rays;primitives.insert(0);primitives.insert(x);primitives.insert(y);
 bitset<1024> possible;
 for(W a:primitives)for(W b:primitives)if(index.contains(a|b))possible.set(index[a|b]);
 bool needed=true;for(auto t:mandatory)if(!possible[t])needed=false;if(!needed)continue;
 if(num>=8192)throw runtime_error("too many banks");
 for(unsigned i=0;i<lib.size();i++)if(possible[i])owners[i].set(num);
 banks.set(num++);}
 }
 bool unary(const vector<Cell>&cs,int u,W x){
 for(auto c:cs)if(popcount(c.a&x)<popcount(c.b&want[u])||popcount(c.a&~x)<popcount(c.b&~want[u]))return false;return true;}
 bool pair(const vector<Cell>&cs,int u,int v,W x,W y){
 if(edge((1u<<u)|(1u<<v))&&(x|y)!=full)return false;
 for(auto c:cs)for(int s=0;s<4;s++)if(popcount(c.a&(s&1?x:~x)&(s&2?y:~y))<
 popcount(c.b&(s&1?want[u]:~want[u])&(s&2?want[v]:~want[v])))return false;return true;}
 void run(Reader&rd,unsigned open,Doms dom,const vector<Cell>&cs){
 for(int u=0;u<10;u++)for(size_t x=dom[u]._Find_first();x<lib.size();x=dom[u]._Find_next(x))
 if(!unary(cs,u,lib[x]))dom[u].reset(x);
 for(;;){int t=rd.get();
 if(t==120||t==121){
 auto allow=banks; for(auto &dv:dom){bitset<8192> z;for(auto i=dv._Find_first();i<lib.size();i=dv._Find_next(i))z|=owners[i];allow&=z;}
 for(auto j:mandatory){bool found=false;for(auto &dv:dom)if(dv[j])found=true;if(!found)allow.reset();}
 if(t==120){if(allow.any())throw runtime_error("bank still possible");return;}
 bool changed=false;for(auto &dv:dom)for(auto j=dv._Find_first();j<lib.size();j=dv._Find_next(j))if((allow&owners[j]).none()){dv.reset(j);changed=true;}
 if(!changed)throw runtime_error("empty progress");run(rd,open,dom,cs);return;
 }
 if(t==122){for(auto&dv:dom)if(dv.count()!=1)throw runtime_error("non-singleton");
 for(int i=0;i<16;i++){W r=full;for(int v=0;v<10;v++){W a=lib[dom[v]._Find_first()];r&=(want[v]>>i&1)?a:~a;}if(!r)return;}
 throw runtime_error("all MIS have witnesses");}
 if(t<10){if(dom[t].any())throw runtime_error("nonempty leaf");return;}
 if(t<20){int u=t-10;if(dom[u].count()==0)throw runtime_error("empty split");
 for(size_t x=dom[u]._Find_first();x<lib.size();x=dom[u]._Find_next(x)){auto ds=dom;ds[u].reset();ds[u].set(x);
 vector<Cell>cc;for(auto c:cs){cc.push_back({c.a&lib[x],c.b&want[u]});cc.push_back({c.a&~lib[x],c.b&~want[u]});}
 run(rd,open&~(1u<<u),ds,cc);}return;}
 int u=(t-20)/10,v=(t-20)%10;if(u>=10||u==v)throw runtime_error("invalid arc");
 for(size_t x=dom[u]._Find_first();x<lib.size();x=dom[u]._Find_next(x)){bool supported=false;
 for(size_t y=dom[v]._Find_first();y<lib.size();y=dom[v]._Find_next(y))
 if(pair(cs,u,v,lib[x],lib[y])){supported=true;break;}if(!supported)dom[u].reset(x);}
 }}
};
int main(int argc,char**argv){
 if(argc!=3)return 1;
 for(unsigned t=0;t<1024;t++)if(ind(t)){bool m=true;
 for(int i=0;i<10;i++)if(!(t>>i&1)&&ind(t|(1u<<i)))m=false;if(m)mis.push_back(t);}
 if(mis.size()!=16)return 2;
 for(int v=0;v<10;v++)for(unsigned i=0;i<mis.size();i++)if(!(mis[i]>>v&1))want[v]|=1u<<i;
 ifstream pr(argv[1]),tape(argv[2],ios::binary);int id;array<W,6>a;
 Reader r;r.text=vector<unsigned char>(istreambuf_iterator<char>(tape),{});
 while(pr>>id){for(W& w:a)if(!(pr>>w))return 3;
 Check c(a,4);for(unsigned D=0;D<1024;D++)if(popcount(D)==4&&proper(D)){
 auto word=[&](){int l=r.get();return l+256*r.get();};
 if(word()!=id||word()!=int(D))throw runtime_error("bad root");auto len=word();if(r.get()!=4)throw runtime_error("bad quota");
 auto end=r.p+len;Doms dom;for(int v=0;v<10;v++)for(unsigned j=0;j<c.lib.size();j++)if(c.direct[j]==bool(D>>v&1))dom[v].set(j);
 c.run(r,D,dom,{{c.full,65535}});if(r.p!=end)throw runtime_error("bad record length");r.records++;
 }cout<<id<<" verified "<<r.records<<" "<<r.p<<endl;}
 return r.p!=r.text.size();
 }
