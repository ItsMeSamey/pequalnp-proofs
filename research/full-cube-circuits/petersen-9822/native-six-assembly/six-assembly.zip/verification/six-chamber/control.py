from itertools import combinations
from pathlib import Path
import json
base=Path('../../six17-cert')
circuit=json.loads((base/'physical-18-1.json').read_text())
data=list(map(int,(base/'control4-1.txt').read_text().split()))
rays=set(data[:12]);helpers=set(data[12:15]);observations=data[15:]
full=2**64-1
edges=[6,24,17,33,66,132,264,528,160,640,576,320,288]
def pairs(xs):
    return xs|{x|y for x,y in combinations(xs,2)}
def admits(xs):
    return set(observations)<=pairs(xs)
assert len(circuit)==18 and sum(op=='and' for op,_,_ in circuit)==6
for s in range(1024):
    target=any(s&e==e for e in edges)
    v=[bool(s>>j&1) for j in range(10)]
    for op,a,b in circuit:v.append((v[a] or v[b]) if op=='or' else (v[a] and v[b]))
    assert target==v[-1]
    reached=0
    for j,r in enumerate(observations):
        if s>>j&1:reached|=r
    assert (reached==full)==target
assert sum(r in rays for r in observations)==4
used=rays.copy()
while helpers-used:
    ready=(helpers-used)&pairs(used)
    assert ready
    used|=ready
assert admits(used)
for a in pairs(rays)|{0}:
    for b in pairs(rays|{a})|{0}:
        assert not admits(rays|{a,b})
print('1024 physical and reverse evaluations; four direct; three helpers accepted, no two-helper bank accepted')
