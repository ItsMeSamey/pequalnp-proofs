#include <algorithm>
#include <array>
#include <bit>
#include <bitset>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
using Mask=uint64_t;
using Bank=bitset<1024>;
const int mis[]={50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773};
const int edges[]={6,24,17,33,66,132,264,528,160,640,576,320,288};
int needs[10][10][4]{};
bool edge(int a,int b){return find(begin(edges),end(edges),(1<<a)|(1<<b))!=end(edges);}
bool independent(int d){for(int e:edges)if((e&d)==e)return false;return true;}
bool possibleSet(int direct){
 if(!independent(direct))return false;
 for(int s=direct;s;s=(s-1)&direct){
  int count=0;for(int I:mis)count+=!(I&s);
  if(count>(64>>popcount((unsigned)s)))return false;
 }
 return true;
}
using Domains=array<Bank,10>;using Bytes=vector<unsigned char>;
struct Cell {Mask r;unsigned t;};
using Cells=vector<Cell>;
#include "banks.inc"
static Library* active;
static Mask universe;
struct Emitter {
 const vector<Mask>&lib;int n;const vector<Bank>&rel;unsigned presence[10]{};
 Emitter(const vector<Mask>&l,const vector<Bank>&r):lib(l),n(l.size()),rel(r){
 for(int v=0;v<10;v++)for(int i=0;i<16;i++)if(!(mis[i]>>v&1))presence[v]|=1u<<i;}
 Cells cut(const Cells&cells,int u,Mask a){
 Cells next;for(auto [r,t]:cells){if(r&a)next.push_back({r&a,t&presence[u]});
 if(r&~a)next.push_back({r&~a,t&~presence[u]});}return next;}
 bool fits(const Cells&cells,int u,Mask a){for(auto [r,t]:cells)
 if(popcount(r&a)<popcount(t&presence[u])||popcount(r&~a)<popcount(t&~presence[u]))return false;return true;}
 Bank supports(const Cells&cells,int u,int v,int x,const Bank&ys){
 Bank out=rel[(10*u+v)*n+x]&ys;if(cells.size()==1)return out;
 for(size_t j=out._Find_first();j<(size_t)n;j=out._Find_next(j))
 for(auto [r,t]:cells){Mask p=r&lib[x],q=r&~lib[x],b=lib[j];unsigned P=t&presence[u],Q=t&~presence[u],B=presence[v];
 if(popcount(p&b)<popcount(P&B)||popcount(p&~b)<popcount(P&~B)||
 popcount(q&b)<popcount(Q&B)||popcount(q&~b)<popcount(Q&~B)){out.reset(j);break;}}
 return out;}
 struct Move {int u,v;Bank lost;};
 bool propagate(Domains&dom,const Cells&cells,Bytes&buff){
 const auto orig=dom;vector<Move>log;bool changed=true;
 while(changed){changed=false;for(int u=0;u<10;u++)for(int v=0;v<10;v++)if(u!=v){
 Bank lost;for(size_t x=dom[u]._Find_first();x<(size_t)n;x=dom[u]._Find_next(x))
 if(supports(cells,u,v,x,dom[v]).none())lost.set(x);
 if(lost.none())continue;changed=true;dom[u]&=~lost;log.push_back({u,v,lost});
 if(dom[u].none()){
 Domains needed{};needed[u]=orig[u];Bytes rev;
 for(auto it=log.rbegin();it!=log.rend();++it){Bank choose=needed[it->u]&it->lost;
 if(choose.none())continue;rev.push_back(20+10*it->u+it->v);needed[it->u]&=~choose;
 for(size_t x=choose._Find_first();x<(size_t)n;x=choose._Find_next(x))
 needed[it->v]|=supports(cells,it->u,it->v,x,orig[it->v]);}
 buff.insert(buff.end(),rev.rbegin(),rev.rend());buff.push_back(u);return false;}
 }}
 for(auto&op:log)buff.push_back(20+10*op.u+op.v);return true;}
 bool tree(Domains dom,unsigned D,const Cells&cells,Bytes&out,bool root){
 for(int u=0;u<10;u++){for(size_t x=dom[u]._Find_first();x<(size_t)n;x=dom[u]._Find_next(x))
 if(!fits(cells,u,lib[x]))dom[u].reset(x);
 if(dom[u].none()){out.push_back(u);return true;}}
 if(root||!D)if(!propagate(dom,cells,out))return true;
 if(!D){
  auto allow=active->all;
  if(!active->meet(dom,allow)){out.push_back(120);return true;}
  Domains next=dom;
  for(int v=0;v<10;v++)for(size_t x=dom[v]._Find_first();x<(size_t)n;x=dom[v]._Find_next(x))
     if((active->owner[x]&allow).none())next[v].reset(x);
  if(next!=dom){out.push_back(121);return tree(next,0,cells,out,false);}
 }
 int u=-1;
 for(int v=0;v<10;v++)if((D ? (D>>v&1) : dom[v].count()>1)&&(u<0||dom[v].count()<dom[u].count()))u=v;
 if(u<0){
  for(unsigned i=0;i<16;++i){Mask room=universe;for(int v=0;v<10;v++){
    Mask m=lib[dom[v]._Find_first()];room &= (presence[v]>>i&1)?m:~m;}
    if(!room){out.push_back(122);return true;}}
  return false;
 }
 out.push_back(10+u);
 for(size_t x=dom[u]._Find_first();x<(size_t)n;x=dom[u]._Find_next(x)){
 auto next=dom;next[u].reset();next[u].set(x);
 if(!tree(next,D&~(1u<<u),cut(cells,u,lib[x]),out,false))return false;}
 return true;}
};

static ofstream *output;
struct Profile{array<Mask,6> a;};
void examine(int id,Profile p,int d){
 Mask reps=0;set<unsigned>seen;set<Mask>B;
 for(int w=0;w<64;w++){unsigned z=0;for(int j=0;j<6;j++)if(p.a[j]>>w&1)z|=1u<<(2*j+(w>>j&1));
 if(seen.insert(z).second)reps|=Mask(1)<<w;}
 for(int j=0;j<6;j++){Mask h=0;for(int w=0;w<64;w++)if(w>>j&1)h|=Mask(1)<<w;
 B.insert(reps&p.a[j]&h);B.insert(reps&p.a[j]&~h);}
 if(seen.size()<16){cout<<id<<' '<<d<<" atoms 0 0\n";return;}
 set<Mask>S{0};for(int k=0;k<d;k++){auto old=S;for(auto x:old)for(auto y:B)S.insert(x|y);}
 S.erase(0);S.erase(reps);
 vector<Mask>lib(S.begin(),S.end());int n=lib.size();if(n>1024)abort();
 array<Bank,10> init;Bank directBank;
 for(int q=0;q<n;q++){directBank[q]=B.count(lib[q]);for(int u=0;u<10;u++)
 if(popcount(reps&lib[q])>=needs[u][u][0]&&popcount(reps&~lib[q])>=needs[u][u][3])init[u].set(q);}
 vector<Bank>rel(100*n);
 for(int u=0;u<10;u++)for(int v=u+1;v<10;v++){
 bool E=edge(u,v);
 for(int x=0;x<n;x++)if(init[u][x])for(int y=0;y<n;y++)if(init[v][y]){
 Mask a=lib[x],b=lib[y];auto t=needs[u][v];if((E&&(a|b)!=reps)||popcount(a&b)<t[0]||popcount(a&~b)<t[1]||popcount(b&~a)<t[2]||popcount(reps&~(a|b))<t[3])continue;
 rel[(u*10+v)*n+x].set(y);rel[(v*10+u)*n+y].set(x);
 }}
 set<Mask> named;for(auto a:p.a){a &= reps;if(a!=reps&&!B.contains(a))named.insert(a);}
 Library banks(lib,B,named,d);active=&banks;universe=reps;
 int cases=0,ok=0;
 for(int D=0;D<1024;D++)if(popcount((unsigned)D)==d&&possibleSet(D)){
 cases++;auto dom=init;for(int u=0;u<10;u++)dom[u]&=(D>>u&1)?directBank:~directBank;
 Bytes proof;Emitter emit(lib,rel);
 if(!emit.tree(dom,D,{{reps,65535}},proof,true)){cerr<<"unexpected solution "<<id<<' '<<d<<' '<<D<<endl;abort();}
 auto &file=*output;
 if(proof.size()>65535)abort();
 for(unsigned value:{(unsigned)id,(unsigned)D,(unsigned)proof.size()}){file.put(value);file.put(value>>8);}
 file.put(d);file.write((const char*)proof.data(),proof.size());
 ok+=proof.size();}
 cout<<id<<' '<<d<<" arc "<<cases<<' '<<ok<<'\n';
}
int main(int argc,char**argv){
 if(argc!=3)return 2;
 ofstream tape(argv[2],ios::binary);output=&tape;
 ifstream in(argv[1]);int id;Profile p;while(in>>id){for(auto& a:p.a)in>>a;
 if(!in)return 3;
 static bool initialized=false;if(!initialized){for(int u=0;u<10;u++)for(int v=0;v<10;v++)for(int I:mis)needs[u][v][2*(I>>u&1)+(I>>v&1)]++;initialized=true;}
 examine(id,p,4);tape.flush();cout.flush();
 }}
