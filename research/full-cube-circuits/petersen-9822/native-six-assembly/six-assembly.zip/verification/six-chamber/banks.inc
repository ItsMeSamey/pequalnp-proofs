// Per helper bank, record which raw masks are available and which activations
// still require a raw recipient. Named non-raw activations are granted directly.
using Owners=bitset<8192>;
struct Library {
 const vector<Mask>& lib;
 vector<Mask> prim, named;
 vector<int> namedId;
 vector<Owners> owner,required;
 Owners all;
 int count=0;
 Library(const vector<Mask>& l,const set<Mask>& b,const set<Mask>& w,int d)
  :lib(l),prim(b.begin(),b.end()),named(w.begin(),w.end()),owner(l.size()),required(w.size()){
  for(Mask x:named)namedId.push_back(index(x));
  set<Mask> first;
  for(auto x:prim)for(auto y:prim)if(x<y)first.insert(x|y);
  for(unsigned q=0;q<1u;++q){
   int spare=d-2-popcount(q);if(spare<0)continue;
   vector<Mask> base=prim;for(unsigned i=0;i<named.size();i++)if(q>>i&1)base.push_back(named[i]);
   add(base,q);
   if(!spare)continue;
   set<Mask> h1=first;
   for(auto x:base)for(auto y:base)if(x<y)h1.insert(x|y);
   for(auto x:h1){
    auto next=base;next.push_back(x);add(next,q);
    if(spare<2)continue;
    set<Mask> second;for(auto v:first)if(v>=x)second.insert(v);
    for(auto v:base)second.insert(x|v);
    for(auto y:second)if(y!=x){next.push_back(y);add(next,q);next.pop_back();}
   }
  }
 }
 int index(Mask x)const{auto p=lower_bound(lib.begin(),lib.end(),x);return p!=lib.end()&&*p==x?int(p-lib.begin()):-1;}
 void add(const vector<Mask>& base,unsigned q){
  Bank possible;
  for(auto x:base){int id=index(x);if(id>=0)possible.set(id);}
  for(unsigned i=0;i<base.size();i++)for(unsigned j=0;j<i;j++){int id=index(base[i]|base[j]);if(id>=0)possible.set(id);}
  for(unsigned i=0;i<named.size();i++)if(!(q>>i&1)&&(namedId[i]<0||!possible[namedId[i]]))return;
  if(count>=int(all.size()))abort();
  for(auto id=possible._Find_first();id<lib.size();id=possible._Find_next(id))owner[id].set(count);
  for(unsigned i=0;i<named.size();i++)if(!(q>>i&1))required[i].set(count);
  all.set(count++);
 }
 bool meet(const array<Bank,10>& dom,Owners& allow)const{
  Bank raw;
  for(auto& dv:dom){
   raw|=dv;Owners any;
   for(auto x=dv._Find_first();x<lib.size();x=dv._Find_next(x)){
    any|=owner[x];if((any&allow)==allow)break;
   }
   allow&=any;if(allow.none())return false;
  }
  for(unsigned i=0;i<named.size();i++)if(namedId[i]<0||!raw[namedId[i]])allow&=~required[i];
  return allow.any();
 }
};
