import NineHotPhysical9822
import NineUpperChoice9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
def FreeBelow (pre post : List Gate) (i j : Nat) := ∀ x : Input, ∀ z : Bool,
  outerValue pre post i x z=true → outerValue pre post j x z=true

private theorem socket_value {gs : List Gate} {k : Nat} {q : Gate} (idx : gs[k]?=some q)
    (w : List Bool) (valid : ∀ i∈q.inputs,i<w.length+k) :
    (wiresFrom gs w).getD (w.length+k) false =
      q.op.eval (q.inputs.map (fun i => (wiresFrom gs w).getD i false)) := by
  obtain ⟨p,t,rfl,rfl⟩ := split_at gs k q idx
  let u := wiresFrom p w
  have len : u.length=w.length+p.length := length_wiresFrom _ _
  rw [wiresFrom_append]
  change (wiresFrom t (u++[_])).getD _ false = _
  rw [getD_wiresFrom _ _ _ (by simp [len]),getD_snoc_len _ _ _ _ len]
  congr 1
  apply List.map_congr_left
  intro i hi
  have lt : i<u.length := by rw [len]; exact valid _ hi
  change u.getD i false = (wiresFrom t (u++[_])).getD i false
  symm
  rw [getD_wiresFrom t _ _ (by simp;omega),getD_snoc_ne _ _ _ _ (by omega)]

theorem original_or_socket {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output)
    {k q i} (idx : C.gates[k]?=some q) (op : q.op=.or) (pin : i∈q.inputs) :
    FreeBelow pre post i (10+k) := by
  intro x z on
  let w := wiresFrom pre (List.ofFn x) ++ [z]
  have wl : w.length=10+pre.length+1 := by simp [w,length_wiresFrom]
  have valid := (red.clean k q idx).lt
  by_cases before : k<pre.length
  · have atPre : pre[k]?=some q := by simpa [r.split,List.getElem?_append_left before] using idx
    have same (j : Nat) (jb : j<10+pre.length) :
        outerValue pre post j x z = (wiresFrom pre (List.ofFn x)).getD j false := by
      unfold outerValue
      rw [getD_wiresFrom _ _ _ (by simp [length_wiresFrom];omega),getD_snoc_ne _ _ _ _ (by simp [length_wiresFrom];omega)]
    rw [same _ (by have := valid i pin; omega)] at on
    rw [same _ (by omega)]
    have ev := socket_value atPre (List.ofFn x) (by simpa only [List.length_ofFn] using valid)
    rw [List.length_ofFn] at ev
    rw [ev,op]
    simpa [GateOp.eval,List.any_map,Function.comp_def] using
      (show ∃ j∈q.inputs,(wiresFrom pre (List.ofFn x)).getD j false=true from ⟨i,pin,on⟩)
  · have ne : k≠pre.length := by
      rintro rfl
      have eq : g=q := by simpa [r.split] using idx
      have := r.inv; subst q; simp_all
    have atPost : post[k-(pre.length+1)]?=some q := by
      rw [r.split,show pre++g::post=(pre++[g])++post by simp,List.getElem?_append_right (by simp;omega)] at idx
      simpa using idx
    have pos : w.length+(k-(pre.length+1))=10+k := by omega
    have ev := socket_value atPost w (by rwa [pos])
    rw [pos] at ev
    change (wiresFrom post w).getD _ false=true
    rw [ev,op]
    simpa [GateOp.eval,List.any_map,Function.comp_def] using
      (show ∃ j∈q.inputs,(wiresFrom post w).getD j false=true from ⟨i,pin,on⟩)
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.original_or_socket
