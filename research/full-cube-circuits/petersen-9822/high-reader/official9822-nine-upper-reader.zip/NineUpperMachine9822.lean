import NineFreeSocket9822
import NineHotRelProgram9822
import NineUpperOnlyBudget9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr SignedClamp NonrawSupport
open LowHotElimination PEqualNP.Outside.L_meta_9822.Clean GuardTags
open Research.NineHotContacts Research.NineHotSites
theorem upper_sites_card {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (upper : outerValue pre post C.output (SignedClamp.singleton 9) true=true)
    (hot : innerValue pre g (SignedClamp.singleton 9)=true) :
    (liveSites C).card ≤ 2 := by
  rw [liveSites,card,r.split,physicalHot_append]
  let w := List.ofFn (SignedClamp.singleton 9)
  have off : g.op.eval (g.inputs.map fun j => (wiresFrom pre w).getD j false)=false := by
    rw [r.inv]; change (!(innerValue pre g (SignedClamp.singleton 9)))=false; simp [hot]
  have flag : CircuitCompiler.orFlag g=false := by simp [CircuitCompiler.orFlag,r.inv]
  change physicalHot pre w + (physicalHot post (wiresFrom pre w ++ [_]) + _) ≤ 2
  rw [off]
  simpa [flag,w] using physical_nine_hot_budget_at_upper r cand red seven upper

theorem upper_program {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output)
    (guardOn : innerValue pre g (SignedClamp.singleton 9)=true) (j : Nat) (bound : j<10+C.gates.length)
    (hot : (liveTable C).Hot j) :
    j=9 ∨ (liveTable C).MeetAt j ∨ (j∈liveSites C ∧ (liveTable C).RelJoin (FreeBelow pre post) j) := by
  by_cases raw : j<10
  · exact Or.inl (live_raw raw hot)
  let k := j-10
  have kj : 10+k=j := by dsimp [k]; omega
  have ks : k<C.gates.length := by omega
  let q := C.gates[k]'ks
  have atK : C.gates[k]?=some q := List.getElem?_eq_getElem ks
  have ev (x : Input) := vl_gate C.gates red.clean x k q atK
  rw [←kj] at hot ⊢
  have val : vl C.gates (SignedClamp.singleton 9) (10+k)=true := hot
  rcases red.shape atK with ⟨neg,_⟩|⟨op,u,v,ub,vb,_,ins⟩
  · have m : q∈C.gates := List.mem_iff_getElem?.mpr ⟨k,atK⟩
    rw [r.split] at m
    have eq : k=pre.length := by
      by_contra ne
      have positive : q∈pre ++ post := by
        by_cases before : k<pre.length
        · apply List.mem_append_left; apply List.mem_iff_getElem?.mpr
          exact ⟨k,by simpa [r.split,List.getElem?_append_left before] using atK⟩
        · apply List.mem_append_right; apply List.mem_iff_getElem?.mpr
          refine ⟨k-(pre.length+1),?_⟩
          rw [r.split,show pre++g::post=(pre++[g])++post by simp,List.getElem?_append_right (by simp; omega)] at atK
          simpa using atK
      rcases r.pos _ positive with e|e <;> simp_all
    obtain ⟨_,_,_,zz⟩ := guard_wire r red
    rw [eq,zz,guardOn] at val
    contradiction
  · rcases op with op|op
    · refine Or.inr (Or.inl ⟨u,ub,v,vb,?_,?_,?_⟩)
      · have := ev (SignedClamp.singleton 9); rw [op,ins] at this
        exact (show vl C.gates (SignedClamp.singleton 9) u=true ∧ _ from by simpa [this,GateOp.eval] using val).1
      · have := ev (SignedClamp.singleton 9); rw [op,ins] at this
        exact (show _ ∧ vl C.gates (SignedClamp.singleton 9) v=true from by simpa [this,GateOp.eval] using val).2
      · intro x; simpa [liveTable,op,ins,GateOp.eval] using ev x
    · exact Or.inr (Or.inr ⟨live_site_mem atK op hot,u,ub,v,vb,original_or_socket r red atK op (by simp [ins]),original_or_socket r red atK op (by simp [ins]),fun x => by
        simpa [liveTable,op,ins,GateOp.eval] using ev x⟩)

theorem hot_wire_injective {C : Circuit} (red : Reduced 10 C.gates C.output)
    {i j : Nat} (ib : i<10+C.gates.length) (jb : j<10+C.gates.length)
    (hot : (liveTable C).Hot j) (eq : (liveTable C).wire j=(liveTable C).wire i) : j=i := by
  have ih : (liveTable C).Hot i := (congrFun eq (liveTable C).test).symm.trans hot
  have forbid (a b : Nat) (alth : a<b) (nb : 10≤b) (blt : b<10+C.gates.length)
      (e : (liveTable C).wire b=(liveTable C).wire a) : False := by
    apply red.noAlias (b-10) (by omega) a (by omega)
    intro x
    rw [show 10+(b-10)=b by omega]
    exact congrFun e x
  by_cases ii : i<10 <;> by_cases jj : j<10
  · exact (live_raw jj hot).trans (live_raw ii ih).symm
  · exact False.elim (forbid i j (by omega) (by omega) jb eq)
  · exact False.elim (forbid j i (by omega) (by omega) ib eq.symm)
  · rcases lt_trichotomy j i with h|h|h
    · exact False.elim (forbid j i h (by omega) ib eq.symm)
    · exact h
    · exact False.elim (forbid i j h (by omega) jb eq)
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
