import PairPolarizedMask9822
import PhysicalReaderDebit9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
private theorem same_if_unique {α : Type} (p : α → Bool) (l : List α)
    (a b : α) (ha : a∈l) (hb : b∈l) (pa : p a=true) (pb : p b=true)
    (single : l.countP p ≤ 1) : a=b := by
  induction l with
  | nil => contradiction
  | cons q qs ih =>
    by_cases f : p q=true
    · rw [List.countP_cons_of_pos f] at single
      have no : ∀ c ∈ qs, p c ≠ true := by
        intro c hc hot
        have := List.countP_pos_iff.mpr ⟨c,hc,hot⟩
        omega
      have aq : a=q := (List.mem_cons.mp ha).resolve_right (fun h => no a h pa)
      have bq : b=q := (List.mem_cons.mp hb).resolve_right (fun h => no b h pb)
      exact aq.trans bq.symm
    · rw [List.countP_cons_of_neg f] at single
      apply ih _ _ single
      · exact (List.mem_cons.mp ha).resolve_left (fun e => f (e ▸ pa))
      · exact (List.mem_cons.mp hb).resolve_left (fun e => f (e ▸ pb))

theorem no_owner_operand {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (s t : Fin 10)
    (guard : ∀ v : Input, innerValue pre g v = (v s || v t))
    (unique : post.countP (ReaderDebit.reads (10+pre.length)) ≤ 1)
    (q : Gate) (mem : q∈post) (reader : 10+pre.length∈q.inputs) :
    s.val∉q.inputs ∧ t.val∉q.inputs := by
  have same (a : Gate) (ha : a∈post) (read : 10+pre.length∈a.inputs) : a=q :=
    same_if_unique _ _ _ _ ha mem (decide_eq_true read) (decide_eq_true reader) unique
  have swapped (v : Input) : innerValue pre g v = (v t || v s) := by rw [guard,Bool.or_comm]
  have pos := r.pos q (List.mem_append_right _ mem)
  constructor
  · intro used
    rcases pos with op|op
    · apply pair_polarized_mask_impossible r seven t s swapped _ cand
      intro a ha use
      rw [same a ha use]; exact Or.inr ⟨op,used⟩
    · apply pair_reader_mask_impossible r seven s t guard _ cand
      intro a ha use
      rw [same a ha use]; exact ⟨op,used⟩
  · intro used
    rcases pos with op|op
    · apply pair_polarized_mask_impossible r seven s t guard _ cand
      intro a ha use
      rw [same a ha use]; exact Or.inr ⟨op,used⟩
    · apply pair_reader_mask_impossible r seven t s swapped _ cand
      intro a ha use
      rw [same a ha use]; exact ⟨op,used⟩
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.no_owner_operand
