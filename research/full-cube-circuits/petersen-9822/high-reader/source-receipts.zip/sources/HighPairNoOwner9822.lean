import HighPhysicalReader9822
import PairNoOwnerReader9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem high_pair_no_owner_reader {C pre post g} (r : Roster C pre post g)
    (cand : Candidate C) (seven : 7 ≤ C.gates.countP countsAnd)
    (minimal : Reduced 10 C.gates C.output) (s t : Fin 10) (st : s≠t)
    (sl : 5 ≤ s.val) (su : s.val ≤ 8) (tl : 5 ≤ t.val) (tu : t.val ≤ 8)
    (hs : innerValue pre g (singleton s)=true) (ht : innerValue pre g (singleton t)=true)
    (q : Gate) (mem : q∈post) (reader : 10+pre.length∈q.inputs) :
    s.val∉q.inputs ∧ t.val∉q.inputs :=
  no_owner_operand r cand seven s t (high_pair_is_or r cand seven s t st sl su tl tu hs ht)
    (high_one_reader r cand seven s sl su hs minimal) q mem reader
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.high_pair_no_owner_reader
