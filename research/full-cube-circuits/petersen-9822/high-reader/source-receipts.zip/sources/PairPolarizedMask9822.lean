import PairReaderMask9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem polarized_suffix (gs : List Gate) (w u : List Bool) (z owner opposite : Nat)
    (mask : ∀ g∈gs,z∈g.inputs → (g.op=.or ∧ owner∈g.inputs) ∨ (g.op=.and ∧ opposite∈g.inputs))
    (size : w.length=u.length) (rz : z<w.length) (ri : owner<w.length)
    (oi : opposite<w.length) (coldL : w.getD opposite false=false) (coldR : u.getD opposite false=false)
    (left : w.getD owner false=true) (right : u.getD owner false=true)
    (away : ∀ j, j≠z → w.getD j false=u.getD j false) :
    ∀ j, j≠z → (wiresFrom gs w).getD j false=(wiresFrom gs u).getD j false := by
  induction gs generalizing w u with
  | nil => exact away
  | cons g gs ih =>
    let a := g.op.eval (g.inputs.map fun j => w.getD j false)
    let b := g.op.eval (g.inputs.map fun j => u.getD j false)
    have eq : a=b := by
      by_cases uses : z∈g.inputs
      · rcases mask g List.mem_cons_self uses with ⟨op,pin⟩|⟨op,pin⟩
        · have force (v : List Bool) (hot : v.getD owner false=true) :
              g.op.eval (g.inputs.map fun j => v.getD j false)=true := by
            simp only [op,GateOp.eval,List.any_map,Function.comp_def,id_eq,List.any_eq_true]
            exact ⟨owner,pin,hot⟩
          exact (force w left).trans (force u right).symm
        · have force (v : List Bool) (cold : v.getD opposite false=false) :
              g.op.eval (g.inputs.map fun j => v.getD j false)=false := by
            simp only [op,GateOp.eval,List.all_map,Function.comp_def,id_eq,List.all_eq_false]
            exact ⟨opposite,pin,fun yes => Bool.noConfusion (cold.symm.trans yes)⟩
          exact (force w coldL).trans (force u coldR).symm
      · apply congrArg g.op.eval
        exact List.map_congr_left fun j mem => away j (by rintro rfl; contradiction)
    apply ih (w++[a]) (u++[b]) (fun q hq => mask q (List.mem_cons_of_mem _ hq))
    · simp [size]
    · simp; omega
    · simp; omega
    · simp; omega
    · rwa [List.getD_append _ _ _ _ oi]
    · rwa [List.getD_append _ _ _ _ (by omega : opposite<u.length)]
    · rwa [List.getD_append _ _ _ _ ri]
    · rwa [List.getD_append _ _ _ _ (by omega : owner<u.length)]
    · intro j ne
      by_cases last : j=w.length
      · rw [last,getD_snoc_eq, size,getD_snoc_eq]; exact eq
      · rw [getD_snoc_ne _ _ _ _ last,getD_snoc_ne _ _ _ _ (by omega)]
        exact away j ne

theorem pair_polarized_mask_impossible {C pre post g} (r : Roster C pre post g)
    (seven : 7 ≤ C.gates.countP countsAnd) (s t : Fin 10)
    (guard : ∀ v : Input, innerValue pre g v = (v s || v t))
    (mask : ∀ q∈post,10+pre.length∈q.inputs → (q.op=.or ∧ s.val∈q.inputs) ∨ (q.op=.and ∧ t.val∈q.inputs)) :
    ¬Candidate C := by
  intro cand
  obtain ⟨v,vs,vt,negative,upper⟩ := pair_exclusive_leak r cand seven s t guard
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have lower := cut.computes v
  rw [guard,vs,vt,negative] at lower
  let w := wiresFrom pre (List.ofFn v)
  have len : w.length=10+pre.length := by simp [w,length_wiresFrom]
  have idx : s.val<w.length := by rw [len]; omega
  have raw : w.getD s.val false=true := by
    dsimp [w]
    rw [getD_wiresFrom _ _ _ (by simpa using s.isLt),getD_ofFn 10 v false s,vs]
  have negidx : t.val<w.length := by rw [len]; omega
  have cold : w.getD t.val false=false := by
    dsimp [w]
    rw [getD_wiresFrom _ _ _ (by simpa using t.isLt),getD_ofFn 10 v false t,vt]
  have eq := polarized_suffix post (w++[false]) (w++[true]) (10+pre.length) s.val t.val mask
    (by simp) (by simp [len]) (by simp;omega)
    (by simp;omega) (by rwa [List.getD_append _ _ _ _ negidx]) (by rwa [List.getD_append _ _ _ _ negidx])
    (by rwa [List.getD_append _ _ _ _ idx]) (by rwa [List.getD_append _ _ _ _ idx])
    (fun j ne => by rw [getD_snoc_ne _ _ _ _ (by omega),getD_snoc_ne _ _ _ _ (by omega)])
  have diff : C.output≠10+pre.length := by
    intro out
    have all := cut.computes (fun _ => true)
    rw [guard] at all
    let a := wiresFrom pre (List.ofFn (fun _ : Fin 10 => true))
    have la : a.length=10+pre.length := by simp [a,length_wiresFrom]
    change (wiresFrom post (a++[false])).getD C.output false=true at all
    rw [out,← la,getD_wiresFrom _ _ _ (by simp),getD_snoc_eq] at all
    contradiction
  have clash := eq C.output diff
  change (wiresFrom post (w++[false])).getD C.output false=false at lower
  change (wiresFrom post (w++[true])).getD C.output false=true at upper
  rw [lower,upper] at clash
  contradiction
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.pair_polarized_mask_impossible
