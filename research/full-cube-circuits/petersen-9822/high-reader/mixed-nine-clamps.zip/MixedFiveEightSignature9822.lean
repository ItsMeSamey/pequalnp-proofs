import MixedUpperSocket9822
import MixedOuterReaderRigidity9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport OuterNet FreeAndNet Research.OddOr
open Research.OddOr.Envelope Research.OddOr.Graph9822

theorem five_eight_signature {C pre mid tail g q} (r : Roster C pre (mid++q::tail) g)
    (cand : Candidate C) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10) (sector : s=5 ∨ s=8)
    (other : ∀ j : Fin 10, j≠s → j≠9 → innerValue pre g (SignedClamp.singleton j)=false)
    (op : q.op=.or) (hit : 10+pre.length∈q.inputs) :
    (∀ j,outerValue pre (mid++q::tail) C.output (SignedClamp.singleton j) true=true ↔ j=s ∨ j=9) ∧
    ∃ u : Net (Fin 10), (∀ x,u.eval x=outerValue pre (mid++q::tail) C.output x true) ∧
      u.cost=8 ∧ hits s u=1 ∧ hits 9 (pin s u)=1 := by
  refine ⟨?_,mixed_outer_reader_rigidity r cand seven s sector other op hit⟩
  let on := fun j => outerValue pre (mid++q::tail) C.output (SignedClamp.singleton j) true=true
  have cut := physical_cut_split cand r.split r.inv (fun a ha => r.pos a (List.mem_append_right _ ha))
  have only (j) (h : on j) : j=s ∨ j=9 := by
    by_contra! n
    have val := cut.computes (SignedClamp.singleton j)
    rw [other j n.1 n.2] at val
    have cold := val.trans (singleton_zero j)
    exact Bool.noConfusion (h.symm.trans cold)
  obtain ⟨j,nj,hj⟩ := second_upper_singleton r cand seven op hit s
  obtain ⟨k,nk,hk⟩ := second_upper_singleton r cand seven op hit 9
  have j9 := (only j hj).resolve_left nj
  have ks := (only k hk).resolve_right nk
  subst j; subst k
  intro i
  exact ⟨only i,fun h => h.elim (fun e => e.symm ▸ hk) (fun e => e.symm ▸ hj)⟩
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.five_eight_signature
