import AdjacentRows9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
/-- External inputs, H and z are fixed across the three nonempty owner rows. -/
abbrev Triple := Bool × Bool × Bool
def term (a b : Bool) : Triple := (!b,!a,true)
def mix (u v : Triple) (a b : Bool) : Triple :=
  ((a && u.1)||(b && v.1),(a && u.2.1)||(b && v.2.1),(a && u.2.2)||(b && v.2.2))
def serves (u v row : Triple) : Prop := ∃ a b : Bool,mix u v a b=row
instance (u v row : Triple) : Decidable (serves u v row) := by unfold serves; infer_instance
theorem no_two_terms : ∀ a b c d : Bool,
    serves (term a b) (term c d) (true,false,true) →
    serves (term a b) (term c d) (false,true,true) →
    serves (term a b) (term c d) (false,false,true) → False := by
  decide +kernel
end PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut.no_two_terms
