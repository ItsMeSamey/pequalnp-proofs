import AdjacentPhysicalTrace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean
def three (t : Trace Input) (e : Input) : Triple := (t e .left,t e .right,t e .both)
theorem sections : ∀ s t : Fin 10,(s,t)∈([(5,7),(5,8),(6,8)] : List (Fin 10×Fin 10)) →
    (∃ i : Fin 10,three (fun e row => edge (rowInput s t e row)) (SignedClamp.singleton i)=(true,false,true)) ∧
    (∃ i : Fin 10,three (fun e row => edge (rowInput s t e row)) (SignedClamp.singleton i)=(false,true,true)) ∧
    three (fun e row => edge (rowInput s t e row)) (fun _ => false)=(false,false,true) := by decide +kernel
theorem not_two_products (W O : Trace Input) (A B : Factors) (c d : Input → Bool) (f : Input → Unary)
    (bank : ∀ e r,W e r = (A.value r && c e || B.value r && d e))
    (out : ∀ e r,O e r=(f e).val (W e r)) (eS eT eB : Input)
    (left : three O eS=(true,false,true)) (right : three O eT=(false,true,true))
    (joint : three O eB=(false,false,true)) : False := by
  have hit (e : Input) (pat : Triple) (eq : three O e=pat)
      (n0 : pat≠(false,false,false)) (n1 : pat≠(true,true,true)) :
      serves (term A.s A.t) (term B.s B.t) pat := by
    cases u : f e with
    | bot => exact (n0 (eq.symm.trans (by simp [three,out,u,Unary.val]))).elim
    | top => exact (n1 (eq.symm.trans (by simp [three,out,u,Unary.val]))).elim
    | copy =>
      refine ⟨c e,d e,?_⟩
      rw [←eq]
      simp [mix,term,three,out,u,Unary.val,bank,Factors.value,Bool.and_comm]
  exact no_two_terms A.s A.t B.s B.t (hit eS _ left (by decide) (by decide))
    (hit eT _ right (by decide) (by decide)) (hit eB _ joint (by decide) (by decide))
end PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut.not_two_products
