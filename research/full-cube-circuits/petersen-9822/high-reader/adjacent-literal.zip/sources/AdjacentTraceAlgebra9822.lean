import AdjacentCutLogic9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
inductive Row | left | right | both deriving DecidableEq
structure Factors where
  s : Bool
  t : Bool
deriving DecidableEq
def Factors.value (u : Factors) : Row → Bool
  | .left => !u.t
  | .right => !u.s
  | .both => true
def Factors.none : Factors := ⟨false,false⟩
def Factors.join (a b : Factors) : Factors := ⟨a.s || b.s,a.t || b.t⟩
theorem Factors.join_value (a b : Factors) (r : Row) :
    (a.join b).value r=(a.value r && b.value r) := by cases r <;> simp [join,value,Bool.not_or]
inductive Unary | bot | copy | top deriving DecidableEq
def Unary.val : Unary → Bool → Bool | .bot,_ => false | .copy,v => v | .top,_ => true
def Unary.meet : Unary → Unary → Unary
  | .bot,_ | _,.bot => .bot | .copy,_ | _,.copy => .copy | _,_ => .top
def Unary.join : Unary → Unary → Unary
  | .top,_ | _,.top => .top | .copy,_ | _,.copy => .copy | _,_ => .bot
theorem Unary.meet_val (a b : Unary) (x : Bool) :
    (a.meet b).val x=(a.val x && b.val x) := by cases a <;> cases b <;> cases x <;> rfl
theorem Unary.join_val (a b : Unary) (x : Bool) :
    (a.join b).val x=(a.val x || b.val x) := by cases a <;> cases b <;> cases x <;> rfl
abbrev Trace (E : Type) := E → Row → Bool
def ProductTrace {E : Type} (A : Factors) (c : E → Bool) : Trace E :=
  fun e r => A.value r && c e
def Factored {E : Type} (bank : Trace E) (A : Factors) (v : Trace E) :=
  ∃ f : E → Unary,∀ e r,v e r=(A.value r && (f e).val (bank e r))
theorem external_factor {E} (bank : Trace E) (f : E → Bool) (a : Factors) :
    Factored bank a (ProductTrace a f) := by
  refine ⟨fun e => if f e then .top else .bot,?_⟩
  intro e r; cases h : f e <;> simp [ProductTrace,h,Unary.val]
theorem factors_and {E} (bank u v : Trace E) (a b : Factors)
    (x : Factored bank a u) (y : Factored bank b v) :
    Factored bank (a.join b) (fun e r => u e r && v e r) := by
  obtain ⟨f,hf⟩ := x
  obtain ⟨g,hg⟩ := y
  exact ⟨fun e => (f e).meet (g e),by intros; simp [hf,hg,Factors.join_value,Unary.meet_val,Bool.and_assoc,Bool.and_left_comm,Bool.and_comm]⟩
theorem factors_free_or {E} (bank u v : Trace E)
    (x : Factored bank Factors.none u) (y : Factored bank Factors.none v) :
    Factored bank Factors.none (fun e r => u e r || v e r) := by
  obtain ⟨f,hf⟩ := x
  obtain ⟨g,hg⟩ := y
  refine ⟨fun e => (f e).join (g e),?_⟩
  intro e r; cases r <;> simp [hf,hg,Factors.none,Factors.value,Unary.join_val]
theorem factors_bank {E} (bank : Trace E) : Factored bank Factors.none bank := by
  refine ⟨fun _ => .copy,?_⟩
  intro e r; cases r <;> simp [Factors.none,Factors.value,Unary.val]
end PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut.factors_and
