import AdjacentTraceExit9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean
theorem adjacent_literal_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t : Fin 10) (shape : (s,t)∈([(5,7),(5,8),(6,8)] : List (Fin 10×Fin 10)))
    (p tail : List Gate) (whole : C.gates=p++literalGate s t::tail)
    (unary : g.inputs=[10+p.length]) : False := by
  have st : s≠t := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  obtain ⟨k,q,site,qo,_,front⟩ := adjacent_frontier r cand red seven s t shape p tail whole unary
  let wire := traceWire C s t
  let Z := fun j => (foldZero C {s,t}).1.getD j (Sum.inl false)=Sum.inl false
  have law := trace_law r red s t st p tail whole unary k front
  have factors := tape_factor wire Z (10+k) law
  rcases red.clean k q site with ⟨bad,_⟩|⟨_,a,b,ha,hb,ins⟩
  · simp_all
  obtain ⟨A,_,_,ap⟩ := factors a
  obtain ⟨B,_,_,bp⟩ := factors b
  obtain ⟨c,ac⟩ := ap ha
  obtain ⟨d,bd⟩ := bp hb
  obtain ⟨F,nz,ff,_⟩ := factors C.output
  have outputOpen : ¬ Z C.output := by
    intro hz
    have a := frozen_value C cand {s,t} C.output false hz (fun _ => true)
    have b := (cand.2.2 (masked {s,t} (fun _ => true))).trans (positive_off_two s t)
    exact Bool.noConfusion (a.symm.trans b)
  have noF : F=Factors.none := by by_contra ne;exact outputOpen (nz ne)
  subst F
  obtain ⟨f,ofact⟩ := ff
  have bank (e : Input) (row : Row) : wire (10+k) e row=(A.value row && c e || B.value row && d e) := by
    change vl C.gates (rowInput s t e row) (10+k)=_
    rw [vl_gate _ red.clean _ k q site,qo,ins]
    change (wire a e row || (wire b e row || false))=_
    rw [ac,bd]
    simp [ProductTrace]
  have out (e : Input) (row : Row) : wire C.output e row=(f e).val (wire (10+k) e row) := by
    have unit : Factors.none.value row=true := by cases row <;> rfl
    simpa only [unit,Bool.true_and] using ofact e row
  have eq : wire C.output = fun e row => edge (rowInput s t e row) := by
    funext e row; exact cand.2.2 _
  obtain ⟨⟨i,left⟩,⟨j,right⟩,joint⟩ := sections s t shape
  exact not_two_products _ _ A B c d f bank out (SignedClamp.singleton i)
    (SignedClamp.singleton j) (fun _ => false) (by rw [eq];exact left) (by rw [eq];exact right) (by rw [eq];exact joint)
end PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut.adjacent_literal_impossible
