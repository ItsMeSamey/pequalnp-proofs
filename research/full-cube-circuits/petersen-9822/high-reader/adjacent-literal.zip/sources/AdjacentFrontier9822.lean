import AdjacentPhysicalDebit9822
import PairRisingGate9822
import GateSiteIdentity9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
theorem adjacent_frontier {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t : V) (shape : (s,t)∈([(5,7),(5,8),(6,8)] : List (V×V))) (p tail : List Gate)
    (whole : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length]) :
    ∃ (k : Nat) (q : Gate), C.gates[k]?=some q ∧ q.op=.or ∧ k≠p.length ∧ ∀ (i : Nat) (v : Gate), C.gates[i]?=some v →
      v.op=.or → (∃ j∈v.inputs,(foldZero C {s,t}).1.getD j (Sum.inl false)=Sum.inl false) →
      i=p.length ∨ i=k := by
  classical
  have st : s≠t := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  let F := foldZero C {s,t}
  have hs := literal_zero_status s t p tail whole
  obtain ⟨k,q,qs,qo,pin,nz,_⟩ := pair_rising_gate r cand red s t st p tail whole unary
  have kh : k≠p.length := by rintro rfl;exact nz hs
  refine ⟨k,q,qs,qo,kh,?_⟩
  intro i v vs vo vp
  by_contra! diff
  let h := literalGate s t
  have hsite : C.gates[p.length]?=some h := by simp [whole,h]
  have hq : h≠q := fun e => kh (gate_site_identity red q qs (e ▸ hsite))
  have hv : h≠v := fun e => diff.1 (gate_site_identity red v vs (e ▸ hsite))
  have qv : q≠v := fun e => diff.2 (gate_site_identity red v vs (e ▸ qs))
  let marked := fun a : Gate => decide (a.op=.or ∧ ∃ j∈a.inputs,F.1.getD j (Sum.inl false)=Sum.inl false)
  let A : Finset Gate := {h,q,v}
  have card : A.card=3 := by simp [A,hq,hv,qv]
  have sub : A⊆(C.gates.filter marked).toFinset := by
    intro a co
    simp only [A,Finset.mem_insert,Finset.mem_singleton] at co
    rcases co with e|e|e <;> subst a
    · exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨List.mem_iff_getElem?.mpr ⟨_,hsite⟩,
        decide_eq_true ⟨rfl,s.val,by simp [h,literalGate],raw_zero_status C {s,t} s (by simp)⟩⟩)
    · exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨List.mem_iff_getElem?.mpr ⟨_,qs⟩,decide_eq_true ⟨qo,pin⟩⟩)
    · exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨List.mem_iff_getElem?.mpr ⟨_,vs⟩,decide_eq_true ⟨vo,vp⟩⟩)
  have bound := (Finset.card_le_card sub).trans (List.toFinset_card_le _)
  rw [card,←List.countP_eq_length_filter] at bound
  apply three_or_folds_impossible C cand red.clean (or_cap r cand seven) s t shape marked bound
  · intro a _ m
    obtain ⟨op,j,jr,jp⟩ : a.op=.or ∧ ∃ j∈a.inputs,F.1.getD j (Sum.inl false)=Sum.inl false := of_decide_eq_true m
    exact ⟨op,j,jr,false,jp⟩
  · intro a m no
    have eq : a=g := by
      by_contra ne
      rw [r.split] at m
      have pos := r.pos a (by simpa [List.mem_append,ne] using m)
      rcases pos with e|e <;> simp_all
    subst a
    exact ⟨_,by simp [unary],false,hs⟩
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.adjacent_frontier
