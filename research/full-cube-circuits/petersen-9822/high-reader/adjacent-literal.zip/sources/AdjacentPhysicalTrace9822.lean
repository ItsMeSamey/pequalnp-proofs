import AdjacentTapeModel9822
import AdjacentFrontier9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean
def rowInput (s t : Fin 10) (e : Input) : Row → Input
  | .left => setOwners s t e true false
  | .right => setOwners s t e false true
  | .both => setOwners s t e true true
def traceWire (C : Circuit) (s t : Fin 10) (j : Nat) : Trace Input :=
  fun e row => vl C.gates (rowInput s t e row) j
theorem trace_law {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output)
    (s t : Fin 10) (st : s≠t) (p tail : List Gate)
    (whole : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length])
    (k : Nat) (front : ∀ i (v : Gate),C.gates[i]?=some v → v.op=.or →
      (∃ j∈v.inputs,(foldZero C {s,t}).1.getD j (Sum.inl false)=Sum.inl false) → i=p.length ∨ i=k) :
    ∀ i, Local (traceWire C s t) (fun j => (foldZero C {s,t}).1.getD j (Sum.inl false)=Sum.inl false) (10+k) i := by
  intro i
  by_cases raw : i<10
  · let v : Fin 10 := ⟨i,raw⟩
    have read (e : Input) (a : Row) : traceWire C s t i e a = rowInput s t e a v := vl_input _ _ _ raw
    by_cases es : v=s
    · apply Local.raw ⟨true,false⟩ (fun _ => true)
      · funext e a;rw [read,es];cases a <;> simp [rowInput,setOwners,ProductTrace,Factors.value]
      · intro _;exact raw_zero_status C {s,t} v (by simp [es])
    · by_cases et : v=t
      · apply Local.raw ⟨false,true⟩ (fun _ => true)
        · funext e a;rw [read,et];cases a <;> simp [rowInput,setOwners,ProductTrace,Factors.value,st.symm]
        · intro _;exact raw_zero_status C {s,t} v (by simp [et])
      · apply Local.raw Factors.none (fun e => e v)
        · funext e a;rw [read];cases a <;> simp [rowInput,setOwners,ProductTrace,Factors.value,Factors.none,es,et]
        · exact fun h => (h rfl).elim
  let j := i-10
  have eq : i=10+j := by dsimp [j];omega
  by_cases bound : j<C.gates.length
  · let q := C.gates[j]
    have site : C.gates[j]?=some q := List.getElem?_eq_getElem bound
    have values (e : Input) (a : Row) := pair_physical_values r red.clean s t p tail whole unary (rowInput s t e a)
    have liveH (e : Input) (a : Row) : (rowInput s t e a s || rowInput s t e a t)=true := by
      cases a <;> simp [rowInput,setOwners,st.symm]
    rw [eq]
    by_cases ea : j=k
    · exact .chosen (by omega)
    by_cases eh : j=p.length
    · apply Local.raw Factors.none (fun _ => true)
      · funext e a
        have h := (values e a).1.trans (liveH e a)
        cases a <;> simpa [traceWire,ProductTrace,Factors.value,Factors.none,eh] using h
      · exact fun h => (h rfl).elim
    rcases red.clean j q site with ⟨no,_⟩|⟨op,a,b,al,bl,ins⟩
    · have qg : q=g := by
        by_contra ne
        have mem := List.mem_iff_getElem?.mpr ⟨_,site⟩
        rw [r.split] at mem
        have pos := r.pos q (by simpa [List.mem_append,ne] using mem)
        rcases pos with e|e <;> simp_all
      have orig : C.gates[pre.length]?=some g := by simp [r.split]
      have ji := gate_site_identity red g (qg ▸ site) orig
      apply Local.raw Factors.none (fun _ => false)
      · funext e a
        have h := (values e a).2
        rw [liveH e a] at h
        cases a <;> simpa [traceWire,ProductTrace,Factors.value,Factors.none,ji] using h
      · exact fun h => (h rfl).elim
    · rcases op with ao|qo
      · apply Local.meet a b al bl
        · funext e row;unfold traceWire;rw [vl_gate _ red.clean _ _ q site,ao,ins];simp [GateOp.eval]
        · intro z
          apply next_zero red.clean {s,t} j q site ao
          rcases z with h|h
          · exact ⟨a,by simp [ins],h⟩
          · exact ⟨b,by simp [ins],h⟩
      · apply Local.join a b al bl
        · funext e row;unfold traceWire;rw [vl_gate _ red.clean _ _ q site,qo,ins];simp [GateOp.eval]
        · intro h;exact (front j q site qo ⟨a,by simp [ins],h⟩).elim eh ea
        · intro h;exact (front j q site qo ⟨b,by simp [ins],h⟩).elim eh ea
  · apply Local.raw Factors.none (fun _ => false)
    · funext e row
      have miss := List.getD_eq_default (wiresFrom C.gates (List.ofFn (rowInput s t e row))) false
        (n:=i) (by rw [length_wiresFrom,List.length_ofFn];omega)
      cases row <;> simpa [traceWire,vl,ProductTrace,Factors.value,Factors.none] using miss
    · exact fun h => (h rfl).elim
end PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut.trace_law
