import AdjacentTraceAlgebra9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
inductive Local {E : Type} (wire : Nat → Trace E) (zero : Nat → Prop) (front i : Nat) : Prop where
  | raw (A : Factors) (c : E → Bool) (val : wire i=ProductTrace A c)
      (tag : A≠Factors.none → zero i)
  | chosen (eq : i=front)
  | meet (a b : Nat) (ha : Nat.lt a i) (hb : Nat.lt b i)
      (val : wire i=fun e r => wire a e r && wire b e r) (close : zero a ∨ zero b → zero i)
  | join (a b : Nat) (ha : Nat.lt a i) (hb : Nat.lt b i)
      (val : wire i=fun e r => wire a e r || wire b e r) (ca : ¬zero a) (cb : ¬zero b)

theorem tape_factor {E : Type} (wire : Nat → Trace E) (zero : Nat → Prop) (front : Nat)
    (localLaw : ∀ i,Local wire zero front i) (i : Nat) :
    ∃ A : Factors,(A≠Factors.none → zero i) ∧ Factored (wire front) A (wire i) ∧
      (i<front → ∃ c : E → Bool,wire i=ProductTrace A c) := by
  classical
  induction i using Nat.strong_induction_on with
  | ind i prev =>
    cases localLaw i with
    | raw A c val tag => exact ⟨A,tag,by rw [val];exact external_factor _ _ _,fun _ => ⟨c,val⟩⟩
    | chosen eq =>
      subst i
      exact ⟨Factors.none,fun bad => (bad rfl).elim,factors_bank _,by omega⟩
    | meet a b ha hb val close =>
      obtain ⟨A,az,af,ap⟩ := prev a ha
      obtain ⟨B,bz,bf,bp⟩ := prev b hb
      refine ⟨A.join B,?_,?_,?_⟩
      · intro nz
        by_cases aa : A=Factors.none
        · have bb : B≠Factors.none := by rintro rfl;subst A;exact nz rfl
          exact close (Or.inr (bz bb))
        · exact close (Or.inl (az aa))
      · rw [val];exact factors_and _ _ _ _ _ af bf
      · intro early
        obtain ⟨f,hf⟩ := ap (Nat.lt_trans ha early)
        obtain ⟨g,hg⟩ := bp (Nat.lt_trans hb early)
        refine ⟨fun e => f e && g e,?_⟩
        funext e r
        simp [val,hf,hg,ProductTrace,Factors.join_value,Bool.and_assoc,Bool.and_left_comm,Bool.and_comm]
    | join a b ha hb val ca cb =>
      obtain ⟨A,az,af,ap⟩ := prev a ha
      obtain ⟨B,bz,bf,bp⟩ := prev b hb
      have fa : A=Factors.none := by by_contra h;exact ca (az h)
      have fb : B=Factors.none := by by_contra h;exact cb (bz h)
      subst A; subst B
      refine ⟨Factors.none,fun bad => (bad rfl).elim,?_,?_⟩
      · rw [val];exact factors_free_or _ _ _ af bf
      · intro early
        obtain ⟨f,hf⟩ := ap (Nat.lt_trans ha early)
        obtain ⟨g,hg⟩ := bp (Nat.lt_trans hb early)
        refine ⟨fun e => f e || g e,?_⟩
        funext e r
        cases r <;> simp [val,hf,hg,ProductTrace,Factors.none,Factors.value]
end PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut.tape_factor
