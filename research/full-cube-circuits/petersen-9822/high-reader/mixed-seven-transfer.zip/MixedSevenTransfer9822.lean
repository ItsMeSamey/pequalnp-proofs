import MixedOwnerSocket9822
import MixedSocketRebuild9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean FreeAndNet
theorem restrict_mixed_seven {C a b mid tail g H R}
    (r : Roster C (a++H::b) (mid++R::tail) g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (caseS : s=5 ∨ s=8)
    (upper : outerValue (a++H::b) (mid++R::tail) C.output (SignedClamp.singleton s) true=true)
    (v : Nat) (hop : H.op=.or) (hpins : H.inputs=[s.val,v] ∨ H.inputs=[v,s.val])
    (rop : R.op=.or) (rpin : 10+(a++H::b).length∈R.inputs) :
    let zid := 10+(a++H::b).length
    ((a++copy v::b)++(mid++copy zid::tail)).countP CircuitCompiler.orFlag≤7 ∧
    ∀ (x : Input),x s=false → ∀ z,
      outerValue (a++copy v::b) (mid++copy zid::tail) C.output x z =
      outerValue (a++H::b) (mid++R::tail) C.output x z := by
  dsimp only
  obtain ⟨D,pins,_,quiet⟩ := owner_socket r cand red seven s caseS upper rop rpin
  have cap := or_cap r cand (by omega)
  constructor
  · rw [r.split] at cap
    rw [List.countP_eq_length_filter]
    simp [copy,CircuitCompiler.orFlag,hop,rop,r.inv,List.filter_append] at cap ⊢
    omega
  · have site : C.gates[(a++H::b).length+(mid.length+1)]?=some R := by
      rw [r.split,List.getElem?_append_right (by omega)]
      simp
    have mem : D∈R.inputs := by rcases pins with p|p <;> simp [p]
    have lt := (red.clean _ _ site).lt D mem
    exact fun x off z => copy_socket_eval a b mid tail H R s v D hop hpins rop _ pins (by omega) quiet _ x off z
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.restrict_mixed_seven
