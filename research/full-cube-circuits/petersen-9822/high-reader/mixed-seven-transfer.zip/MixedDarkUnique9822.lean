import MixedAfterS9822
import MixedDarkCount9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp FreeAndNet Research.OddOr Research.OddOr.Graph9822
open PEqualNP.Outside.L_meta_9822.Clean Research.OddOr.Envelope

def maxOff (s : V) : Input := fun j => decide (j≠s)
theorem at_most_one_dark (s : V) (caseS : s=5 ∨ s=8) (gs : List Gate) (o : Nat)
    (ok : ∀ q∈gs,PositiveOp q ∧ q.inputs.length≤2)
    (cap : gs.countP CircuitCompiler.orFlag≤8)
    (cold : ∀ j : V, j≠s → j≠9 → vl gs (SignedClamp.singleton j) o=false)
    (edges : ∀ i j : V, i≠s → j≠s → f {i,j}=true → vl gs (inputOn {i,j}) o=true) :
    (flags gs (List.ofFn (maxOff s))).count true ≤ 1 := by
  let up := List.ofFn (maxOff s)
  let hs := simplifyProgram gs up
  let D : Circuit := ⟨hs,o⟩
  let u := CircuitCompiler.compile 10 D
  have hm : Monotone2 D := simpleProgram_ok gs up ok
  have read (v : Input) (off : v s=false) : u.eval v = vl gs v o := by
    have smaller : WireLE (List.ofFn v) up := packed_inputs_mono (by
      intro j hj
      by_cases eq : j=s
      · subst j; simp_all
      · simp [maxOff,eq])
    rw [show u.eval v=D.eval (List.ofFn v) from CircuitCompiler.compile_eval _ _ hm _]
    change (wiresFrom (simplifyProgram gs up) (List.ofFn v)).getD o false=_
    rw [simplifyProgram_eval gs (fun q m => (ok q m).1) _ _ smaller]
    rfl
  have lower := after_five_eight s caseS u (by
    intro j js jn
    have eq : inputOn {j}=SignedClamp.singleton j := by funext k; simp [inputOn,SignedClamp.singleton]
    change u.eval (inputOn {j}) = false
    rw [eq,read _ (by simp [SignedClamp.singleton,Ne.symm js])]
    exact cold _ js jn) (by
    intro i j hi hj e
    change u.eval (inputOn {i,j})=true
    rw [read _ (by simp [inputOn,Ne.symm hi,Ne.symm hj])]
    exact edges _ _ hi hj e)
  have bh := CircuitCompiler.compile_cost 10 D
  change u.cost ≤ (hs.filter CircuitCompiler.orFlag).length at bh
  rw [← List.countP_eq_length_filter] at bh
  have a : hs.countP CircuitCompiler.orFlag+(flags gs up).count true=gs.countP CircuitCompiler.orFlag :=
    flag_account gs up
  change (flags gs up).count true ≤ 1
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.at_most_one_dark
