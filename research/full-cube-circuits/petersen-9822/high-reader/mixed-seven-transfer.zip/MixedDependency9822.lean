import RisingOrFrontier9822
import PairRisingGate9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean

/-- Paths beginning at s whose intermediate gates are all AND. -/
inductive AndChild (gs : List Gate) (s : V) : Nat → Prop where
  | raw : AndChild gs s s.val
  | next {k q j} (site : gs[k]?=some q) (op : q.op=.and) (read : j∈q.inputs)
      (prev : AndChild gs s j) : AndChild gs s (10+k)

theorem AndChild.forces {gs : List Gate} {s : V} {j : Nat} (path : AndChild gs s j)
    (w : Nat → Bool) (raw : w s.val=false)
    (ands : ∀ k q, gs[k]?=some q → q.op=.and →
      w (10+k)=(q.inputs.map w).all id) : w j=false := by
  induction path with
  | raw => exact raw
  | next site op read prev ih =>
    rw [ands _ _ site op]
    cases h : (List.map w _).all id with
    | false => rfl
    | true =>
      have yes := List.all_eq_true.mp h _ (List.mem_map_of_mem read)
      simp_all

theorem AndChild.actual {C : Circuit} {s : V} {j : Nat} (cl : CleanL 10 C.gates)
    (path : AndChild C.gates s j) (x : Input) (off : x s=false) :
    vl C.gates x j=false := by
  apply path.forces (vl C.gates x) ((vl_input _ _ _ s.isLt).trans off)
  intro k q site op
  rw [vl_gate _ cl _ k q site,op]
  rfl

theorem rise_from_owner {C : Circuit} (cand : Candidate C) (cl : CleanL 10 C.gates)
    (s : V) (x y : Input) (apart : ∀ i, i≠s → x i=y i)
    (lo : edge x=false) (hi : edge y=true)
    (live : ∃ v : Input, v s=false ∧ edge v=true)
    (flat : ∀ k q,C.gates[k]?=some q → q.op=.not → ¬rises C.gates x y (10+k)) :
    ∃ k q,C.gates[k]?=some q ∧ q.op=.or ∧ rises C.gates x y (10+k) ∧
      ∃ j∈q.inputs,AndChild C.gates s j := by
  have rise : rises C.gates x y C.output :=
    ⟨(cand.2.2 x).trans lo,(cand.2.2 y).trans hi⟩
  have outside : ¬AndChild C.gates s C.output := by
    obtain ⟨v,hv,ev⟩ := live
    intro path
    exact Bool.noConfusion ((path.actual cl v hv).symm.trans ((cand.2.2 v).trans ev))
  have inp (j : Nat) (small : j<10) (up : rises C.gates x y j) : AndChild C.gates s j := by
    let i : V := ⟨j,small⟩
    by_cases eq : i=s
    · have h : j = s.val := congrArg Fin.val eq
      rw [h]; exact .raw
    · obtain ⟨a,b⟩ := up
      rw [vl_input _ _ _ small] at a b
      exact Bool.noConfusion (a.symm.trans ((apart i eq).trans b))
  obtain ⟨k,q,site,op,on,_,pin⟩ := rising_or_frontier C.gates cl x y (AndChild C.gates s)
    C.output rise outside inp (fun k q h op ⟨j,hj,p⟩ => .next h op hj p) flat
  exact ⟨k,q,site,op,on,pin⟩
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.rise_from_owner
