import MixedDependency9822
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds
theorem vl_legal_site {k : ℕ} (gs : List Gate) (u : Fin k → Bool) (p : ℕ)
    (g : Gate) (hp : gs[p]? = some g) (hlt : ∀ i∈g.inputs,i<k+p) :
    vl gs u (k + p) = g.op.eval (g.inputs.map (vl gs u)) := by
  obtain ⟨pre, post, rfl, rfl⟩ := split_at gs p g hp
  have hwl : (wiresFrom pre (List.ofFn u)).length = k + pre.length := by
    rw [length_wiresFrom]; simp
  have e : wiresFrom (pre ++ g :: post) (List.ofFn u)
      = wiresFrom post (wiresFrom pre (List.ofFn u) ++
        [g.op.eval (g.inputs.map fun i => (wiresFrom pre (List.ofFn u)).getD i false)]) := by
    rw [wiresFrom_append]; rfl
  have full : ∀ j, j < k + pre.length →
      (wiresFrom (pre ++ g :: post) (List.ofFn u)).getD j false
        = (wiresFrom pre (List.ofFn u)).getD j false := by
    intro j hj
    rw [e, getD_wiresFrom _ _ j (by simp [hwl]; omega), getD_snoc_ne _ _ _ _ (by omega)]
  have top : (wiresFrom (pre ++ g :: post) (List.ofFn u)).getD (k + pre.length) false
      = g.op.eval (g.inputs.map fun i => (wiresFrom pre (List.ofFn u)).getD i false) := by
    rw [e, getD_wiresFrom _ _ _ (by simp [hwl]), getD_snoc_len _ _ _ _ hwl]
  show (wiresFrom (pre ++ g :: post) (List.ofFn u)).getD (k + pre.length) false
    = g.op.eval (g.inputs.map fun j => (wiresFrom (pre ++ g :: post) (List.ofFn u)).getD j false)
  rw [top]
  congr 1
  apply List.map_congr_left
  intro a ha
  exact (full a (hlt a ha)).symm

end PEqualNP.Outside.L_meta_9822.Clean

namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean
theorem AndChild.across {gs hs : List Gate} {i : V} {j : Nat} (path : AndChild gs i j)
    (cl : CleanL 10 gs) (keep : ∀ (k : Nat) (q : Gate),gs[k]?=some q → q.op=.and → hs[k]?=some q)
    (x : Input) (off : x i=false) : vl hs x j=false := by
  apply path.forces (vl hs x) ((vl_input _ _ _ i.isLt).trans off)
  intro k q site op
  rw [vl_legal_site _ _ _ _ (keep k q site op) (cl k q site).lt,op]
  rfl
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
