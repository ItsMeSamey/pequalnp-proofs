import MixedAndFlag9822
import MixedNinePivot9822
import AllPairObservers9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport Deletion LowHotElimination PEqualNP.Outside.L_meta_9822.Clean

theorem socket_child_of_budget {C pre mid tail g rGate} (r : Roster C pre (mid++rGate::tail) g)
    (cand : Candidate C) (seven : 7≤C.gates.countP countsAnd) (cl : CleanL 10 C.gates) (s : Fin 10) (caseS : s=5 ∨ s=8)
    (hot : innerValue pre g (SignedClamp.singleton 9)=true)
    (hk : Nat) (H : Gate) (before : hk<pre.length) (hsite : pre[hk]?=some H)
    (hop : H.op=.or) (hread : s.val∈H.inputs) (hguard : g.inputs=[10+hk])
    (ro : rGate.op=.or) (D : Nat) (pins : rGate.inputs=[10+pre.length,D] ∨ rGate.inputs=[D,10+pre.length])
    (budget : (flags (hotReaderCircuit pre mid tail C.output).gates (List.ofFn (maxOff s))).count true≤1) :
    AndChild C.gates s D := by
  let hs := (hotReaderCircuit pre mid tail C.output).gates
  let ri := pre.length+1+mid.length
  have keep := preserved_and_sites r ro
  have originalH : C.gates[hk]?=some H := by simpa [r.split,List.getElem?_append,before] using hsite
  have shiftedH : hs[hk]?=some H := by simpa [hs,hotReaderCircuit,List.getElem?_append,before] using hsite
  have flagH := flag_of_child s cl keep _ _ originalH shiftedH hop ⟨_,hread,.raw⟩
  have rn : C.gates[ri]?=some rGate := by
    rw [r.split,List.getElem?_append_right (by dsimp [ri];omega)]
    simp [ri,show pre.length+1+mid.length-pre.length=mid.length+1 by omega]
  obtain ⟨k,q,site,op,rise,j,pin,path⟩ := mixed_pivot_frontier r cand cl s caseS hot
  have qn : k≠pre.length := by
    rintro rfl
    have e : g=q := by simpa [r.split] using site
    subst q; simp_all [r.inv]
  have notH : k≠hk := by
    rintro rfl
    have val := hot_at_nine r hot (pivot9 s) (nonadjacent_pivot s caseS).1
    have obs := visible r (10+k) (by omega) (pivot9 s)
    simp [innerValue,hguard] at val
    have high : vl C.gates (pivot9 s) (10+k)=true := obs.trans val
    exact Bool.noConfusion (rise.1.symm.trans high)
  have isR : k=ri := by
    by_contra nr
    have same : hs[k]?=some q := replace_pair_get pre mid tail g rGate q k (r.split ▸ site) qn nr
    have flagQ := flag_of_child s cl keep _ _ site same op ⟨j,pin,path⟩
    have two := two_flags _ notH flagQ flagH
    change (flags hs (List.ofFn (maxOff s))).count true≤1 at budget
    exact (by omega : ¬ (2 ≤ (flags hs (List.ofFn (maxOff s))).count true)) two
  subst k
  have gr : q=rGate := Option.some.inj (site.symm.trans rn)
  subst q
  have jz : j≠10+pre.length := by
    rintro rfl
    have negative := path.actual cl (fun _ => false) rfl
    have positive := actual_not_value r (fun _ => false)
    rw [cold_empty r cand seven] at positive
    exact Bool.noConfusion (negative.symm.trans positive)
  rcases pins with p|p <;> simp [p,jz] at pin <;> exact pin ▸ path
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.socket_child_of_budget
