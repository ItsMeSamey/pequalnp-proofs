import MixedSocketFlags9822
import MixedCandidateDark9822
import MixedFreeCut9822
import MixedGuardLayout9822
import AcceptedHighSpread9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport Deletion LowHotElimination PEqualNP.Outside.L_meta_9822.Clean

theorem owner_socket {C pre mid tail g R} (r : Roster C pre (mid++R::tail) g)
    (cand : Candidate C) (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (caseS : s=5 ∨ s=8)
    (upper : outerValue pre (mid++R::tail) C.output (SignedClamp.singleton s) true=true)
    (rop : R.op=.or) (rpin : 10+pre.length∈R.inputs) :
    ∃ D, (R.inputs=[10+pre.length,D] ∨ R.inputs=[D,10+pre.length]) ∧
      AndChild C.gates s D ∧ ∀ (x : Input),x s=false → ∀ z,outerValue pre (mid++R::tail) D x z=false := by
  have bounds : 5≤s.val ∧ s.val≤8 := by rcases caseS with rfl|rfl <;> decide
  have cut := physical_cut_split cand r.split r.inv (fun a ha => r.pos a (List.mem_append_right _ ha))
  have other := other_guard_cold r cand red seven s bounds.1 bounds.2 (hot_guard cut s upper)
  have hot := (full_upper_nine r cand red seven).2
  obtain ⟨hk,H,b,before,hsite,hop,hguard,hp,_⟩ :=
    mixed_guard_layout r cand red seven s bounds.1 bounds.2 upper
  have hread : s.val∈H.inputs := by rcases hp with p|p <;> simp [p]
  have budget := candidate_dark_budget r cand (by omega) s caseS other rop rpin
  have site : C.gates[pre.length+(mid.length+1)]?=some R := by
    rw [r.split,List.getElem?_append_right (by omega)]
    simp
  rcases red.clean _ _ site with ⟨n,_⟩|⟨_,a,b',_,_,ins⟩
  · simp_all
  · rw [ins] at rpin
    have pins : ∃ D,R.inputs=[10+pre.length,D] ∨ R.inputs=[D,10+pre.length] := by
      rcases List.mem_cons.mp rpin with h|h
      · exact ⟨_,Or.inl (h ▸ ins)⟩
      · have e : 10+pre.length=b' := by simpa using h
        exact ⟨_,Or.inr (e ▸ ins)⟩
    obtain ⟨D,p⟩ := pins
    have path := socket_child_of_budget r cand (by omega) red.clean s caseS hot hk H before hsite hop hread hguard rop D p budget
    exact ⟨D,p,path,fun x off z => formal_child r red.clean s D path x off z⟩
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.owner_socket
