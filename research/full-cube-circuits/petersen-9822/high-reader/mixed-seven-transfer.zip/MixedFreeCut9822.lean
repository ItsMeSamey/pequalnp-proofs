import MixedClampedSites9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport Deletion PEqualNP.Outside.L_meta_9822.Clean
def constGate (b : Bool) : Gate := if b then ⟨.and,[]⟩ else ⟨.or,[]⟩
def freeCut (pre post : List Gate) (z : Bool) := pre++constGate z::post

theorem freeCut_and {C pre post g} (r : Roster C pre post g) (z : Bool)
    (k : Nat) (q : Gate) (site : C.gates[k]?=some q) (op : q.op=.and) :
    (freeCut pre post z)[k]?=some q := by
  rw [r.split] at site
  by_cases lt : k<pre.length
  · simpa [freeCut,List.getElem?_append,lt] using site
  by_cases eq : k=pre.length
  · subst k
    have same : g=q := by simpa using site
    subst q; simp_all [r.inv]
  obtain ⟨j,ej⟩ : ∃j,k=pre.length+(j+1) := ⟨k-pre.length-1,by omega⟩
  subst k;simpa [freeCut,List.getElem?_append] using site

theorem formalWire (pre post : List Gate) (out : Nat) (x : Input) (z : Bool) :
    vl (freeCut pre post z) x out=outerValue pre post out x z := by
  unfold vl freeCut outerValue
  rw [wiresFrom_append]
  cases z <;> rfl

theorem formal_child {C pre post g} (r : Roster C pre post g) (cl : CleanL 10 C.gates)
    (s : Fin 10) (D : Nat) (path : AndChild C.gates s D) (x : Input) (off : x s=false) (z : Bool) :
    outerValue pre post D x z=false :=
  (formalWire pre post D x z).symm.trans (path.across cl (freeCut_and r z) x off)
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.formal_child
