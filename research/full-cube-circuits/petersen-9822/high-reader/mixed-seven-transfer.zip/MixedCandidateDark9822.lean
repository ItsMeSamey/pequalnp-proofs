import MixedDarkUnique9822
import MixedHotReaderNet9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp NonrawSupport OuterNet
open PEqualNP.Outside.L_meta_9822.Clean FreeAndNet Research.OddOr Research.OddOr.Graph9822
theorem candidate_dark_budget {C pre mid tail g q} (r : Roster C pre (mid++q::tail) g)
    (cand : Candidate C) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10) (caseS : s=5 ∨ s=8)
    (other : ∀j : Fin 10,j≠s → j≠9 → innerValue pre g (SignedClamp.singleton j)=false)
    (op : q.op=.or) (hit : 10+pre.length∈q.inputs) :
    (flags (hotReaderCircuit pre mid tail C.output).gates (List.ofFn (maxOff s))).count true≤1 := by
  let D := hotReaderCircuit pre mid tail C.output
  have mono : Monotone2 D := by
    intro a ha
    have before : ∀ a∈pre++(mid++q::tail), PositiveOp a ∧ a.inputs.length≤2 := by
      intro h hh
      exact ⟨r.pos h hh,(cand.1 h (by rw [r.split]; simp only [List.mem_append,List.mem_cons] at hh ⊢; tauto)).2⟩
    change a∈pre++topGate::(mid++topGate::tail) at ha
    simp only [List.mem_append,List.mem_cons] at ha
    have top : (topGate.op∈({GateOp.and,GateOp.or}:Set GateOp)) ∧ topGate.inputs.length≤2 := ⟨Or.inl rfl,by decide⟩
    rcases ha with h | rfl | h | rfl | h
    · exact before _ (by simp [h])
    · exact top
    · exact before _ (by simp [h])
    · exact top
    · exact before _ (by simp [h])
  have cap := or_cap r cand seven
  rw [r.split] at cap
  have capD : D.gates.countP CircuitCompiler.orFlag≤8 := by
    rw [List.countP_eq_length_filter]
    simp [D,hotReaderCircuit,topGate,CircuitCompiler.orFlag,op,r.inv,List.filter_append] at cap ⊢
    omega
  have cut := physical_cut_split cand r.split r.inv (fun a ha => r.pos a (List.mem_append_right _ ha))
  have read (x : Input) : vl D.gates x C.output = outerValue pre (mid++q::tail) C.output x true :=
    or_hot_reader_eval pre mid tail q op hit _ x
  apply at_most_one_dark s caseS D.gates C.output (fun g hg => mono g hg) capD
  · intro j js jn
    rw [read]
    have on := cut.computes (SignedClamp.singleton j)
    rw [other j js jn] at on
    exact on.trans (singleton_zero j)
  · intro i j _ _ e
    rw [read]
    exact positive_upper cut _ e
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.candidate_dark_budget
