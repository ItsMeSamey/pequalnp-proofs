import MixedFreeCut9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
def copy (j : Nat) : Gate := ⟨.and,[j,j]⟩
theorem copy_guard_bank (a b : List Gate) (H : Gate) (s : Fin 10) (v : Nat)
    (op : H.op=.or) (pins : H.inputs=[s.val,v] ∨ H.inputs=[v,s.val])
    (x : Input) (off : x s=false) :
    wiresFrom (a++copy v::b) (List.ofFn x) = wiresFrom (a++H::b) (List.ofFn x) := by
  let w := wiresFrom a (List.ofFn x)
  have cold : w.getD s.val false=false := (vl_input a x s s.isLt).trans off
  rw [wiresFrom_append,wiresFrom_append]
  change wiresFrom b (w ++ [(copy v).op.eval ((copy v).inputs.map fun j => w.getD j false)]) =
    wiresFrom b (w ++ [H.op.eval (H.inputs.map fun j => w.getD j false)])
  rcases pins with p|p <;> rw [p,op] <;> simp only [copy,GateOp.eval,List.map_cons,List.map_nil,
    List.all_cons,List.all_nil,List.any_cons,List.any_nil,id_eq,cold] <;> cases w.getD v false <;> rfl

theorem copy_socket_eval (a b mid tail : List Gate) (H R : Gate) (s : Fin 10) (v D : Nat)
    (hop : H.op=.or) (hpins : H.inputs=[s.val,v] ∨ H.inputs=[v,s.val])
    (rop : R.op=.or) (zid : Nat)
    (rpins : R.inputs=[zid,D] ∨ R.inputs=[D,zid])
    (well : D<10+(a++H::b).length+1+mid.length)
    (quiet : ∀ (x : Input),x s=false → ∀ z,
      outerValue (a++H::b) (mid++R::tail) D x z=false)
    (o : Nat) (x : Input) (off : x s=false) (z : Bool) :
    outerValue (a++copy v::b) (mid++copy zid::tail) o x z =
      outerValue (a++H::b) (mid++R::tail) o x z := by
  unfold outerValue
  rw [copy_guard_bank a b H s v hop hpins x off,wiresFrom_append mid (copy zid::tail),wiresFrom_append mid (R::tail)]
  let u := wiresFrom (a++H::b) (List.ofFn x)++[z]
  let w := wiresFrom mid u
  have len : w.length=10+(a++H::b).length+1+mid.length := by simp [w,u,length_wiresFrom,Nat.add_assoc]
  have quietD := quiet x off z
  unfold outerValue at quietD
  rw [wiresFrom_append] at quietD
  change (wiresFrom (R::tail) w).getD D false=false at quietD
  rw [getD_wiresFrom _ _ _ (by omega)] at quietD
  change (wiresFrom tail (w++[(copy zid).op.eval ((copy zid).inputs.map fun i => w.getD i false)])).getD o false =
    (wiresFrom tail (w++[R.op.eval (R.inputs.map fun i => w.getD i false)])).getD o false
  rcases rpins with p|p <;> rw [p,rop] <;> simp only [copy,GateOp.eval,List.map_cons,List.map_nil,
    List.all_cons,List.all_nil,List.any_cons,List.any_nil,id_eq,quietD] <;> cases w.getD zid false <;> rfl
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.copy_socket_eval
