import MixedDarkUnique9822
import MixedClampedSites9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp Deletion PEqualNP.Outside.L_meta_9822.Clean
theorem flag_of_child {gs hs : List Gate} (s : Fin 10) (cl : CleanL 10 gs)
    (keep : ∀ (k : Nat) (q : Gate),gs[k]?=some q → q.op=.and → hs[k]?=some q)
    (k : Nat) (q : Gate) (actual : gs[k]?=some q) (same : hs[k]?=some q)
    (op : q.op=.or) (pin : ∃ j∈q.inputs,AndChild gs s j) :
    (flags hs (List.ofFn (maxOff s)))[k]?=some true := by
  obtain ⟨j,mem,path⟩ := pin
  have off := path.across cl keep (maxOff s) (by simp [maxOff])
  obtain ⟨haveSite,_⟩ := List.getElem?_eq_some_iff.mp same
  have z := (final_is_prefix hs (maxOff s) k j (by omega) ((cl k q actual).lt j mem)).trans off
  rcases cl k q actual with ⟨no,_⟩|⟨_,a,b,_,_,ins⟩
  · simp_all
  · apply flagged_at _ _ same op ins
    rw [ins] at mem
    rcases List.mem_cons.mp mem with e|l
    · exact Or.inl (e ▸ z)
    · have e : j=b := by simpa using l
      exact Or.inr (e ▸ z)
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
