import MixedDependency9822
import NinePatchChoice9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport BoundedClamp PEqualNP.Outside.L_meta_9822.Clean
def pivot9 (s : V) : Input := pair 9 (if s=5 then 0 else 3)
theorem nonadjacent_pivot (s : V) (caseS : s=5 ∨ s=8) :
    (pivot9 s) 9=true ∧ edge (pivot9 s)=false ∧ edge (addRaw (pivot9 s) s)=true ∧
    (pair 9 4) s=false ∧ edge (pair 9 4)=true := by
  rcases caseS with rfl|rfl <;> decide +kernel

theorem not_unique_index {C pre post g} (r : Roster C pre post g) (k : Nat) (q : Gate)
    (site : C.gates[k]?=some q) (op : q.op=.not) : k=pre.length := by
  by_contra diff
  have m : q∈pre++post := by
    rw [r.split] at site
    by_cases less : k<pre.length
    · exact List.mem_append_left _ (List.mem_iff_getElem?.mpr ⟨k,by simpa [List.getElem?_append,less] using site⟩)
    · obtain ⟨a,ha⟩ : ∃ a,k=pre.length+(a+1) := ⟨k-pre.length-1,by omega⟩
      exact List.mem_append_right _ (List.mem_iff_getElem?.mpr ⟨a,by simpa [ha,List.getElem?_append] using site⟩)
  rcases r.pos q m with e|e <;> simp_all

theorem hot_at_nine {C pre post g} (r : Roster C pre post g) (hot : innerValue pre g (SignedClamp.singleton 9)=true)
    (x : Input) (on : x 9=true) : innerValue pre g x=true := by
  apply inner_mono_inputs (fun a ha => r.pos a (List.mem_append_left _ ha)) g _ hot
  intro i hi
  have e : i=9 := by simpa [SignedClamp.singleton] using hi
  exact e ▸ on

theorem mixed_pivot_frontier {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (cl : CleanL 10 C.gates) (s : V) (caseS : s=5 ∨ s=8)
    (hot : innerValue pre g (SignedClamp.singleton 9)=true) :
    ∃ k q,C.gates[k]?=some q ∧ q.op=.or ∧
      rises C.gates (pivot9 s) (addRaw (pivot9 s) s) (10+k) ∧
      ∃ j∈q.inputs,AndChild C.gates s j := by
  obtain ⟨on,lo,hi,off,edge⟩ := nonadjacent_pivot s caseS
  apply rise_from_owner cand cl s _ _ (fun j ne => by simp [addRaw,SignedClamp.singleton,ne]) lo hi
    ⟨pair 9 4,off,edge⟩
  intro k q site op rise
  have ix := not_unique_index r k q site op
  have after : addRaw (pivot9 s) s 9=true := by simp [addRaw,on]
  have zero := actual_not_value r (addRaw (pivot9 s) s)
  rw [hot_at_nine r hot _ after] at zero
  rw [ix] at rise
  exact Bool.noConfusion (rise.2.symm.trans zero)
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.mixed_pivot_frontier
