import MixedDarkProgram9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean
open FreeAndNet.CircuitCompiler
noncomputable section
def flags : List Gate → List Bool → List Bool
 | [],_ => []
 | q::qs,u => (orFlag q && !orFlag (simplifyDark q u)) :: flags qs (tick q u)

theorem or_preserved (q) (u) (on : orFlag (simplifyDark q u)=true) : orFlag q=true := by
  unfold simplifyDark at on
  split at on
  · split at on
    · rename_i eq
      simp [orFlag,eq]
    · exact on
  · exact on

theorem flag_account (gs : List Gate) (u : List Bool) :
    (simplifyProgram gs u).countP orFlag + (flags gs u).count true = gs.countP orFlag := by
  induction gs generalizing u with
  | nil => rfl
  | cons q qs ih =>
    have rest := ih (tick q u)
    have keep := or_preserved q u
    simp only [simplifyProgram,flags,List.countP_cons,List.count_cons]
    cases h : orFlag q <;> cases k : orFlag (simplifyDark q u)
    · simpa using rest
    · exact Bool.noConfusion (h.symm.trans (keep k))
    · simp; omega
    · simp; omega

theorem flagged_at (gs : List Gate) (u : List Bool) {k q} (site : gs[k]?=some q)
    (op : q.op=.or) {a b : Nat} (ins : q.inputs=[a,b])
    (zero : (wiresFrom (gs.take k) u).getD a false=false ∨
            (wiresFrom (gs.take k) u).getD b false=false) :
    (flags gs u)[k]?=some true := by
  induction gs generalizing k u with
  | nil => simp at site
  | cons t ts ih =>
    cases k with
    | zero =>
      have eq : t=q := by simpa using site
      subst t
      change some (orFlag q && !orFlag (simplifyDark q u)) = some true
      change u.getD a false=false ∨ u.getD b false=false at zero
      rcases zero with ha|hb
      · simp only [simplifyDark,ins,op,ite_true,ha]; simp [orFlag,op]
      · by_cases ha : u.getD a false=false
        · simp only [simplifyDark,ins,op,ite_true,ha]; simp [orFlag,op]
        · simp only [simplifyDark,ins,op,ite_true,if_neg ha,hb]; simp [orFlag,op]
    | succ k =>
      exact ih (tick t u) (by simpa using site) (by simpa [List.take_succ_cons,wiresFrom,tick] using zero)

theorem two_flags (l : List Bool) {a b : Nat} (diff : a≠b)
    (ha : l[a]?=some true) (hb : l[b]?=some true) : 2≤l.count true := by
  induction l generalizing a b with
  | nil => simp at ha
  | cons x xs ih =>
    cases a with
    | zero =>
      have h : x=true := by simpa using ha
      subst x
      cases b with
      | zero => contradiction
      | succ b =>
        have mem := List.mem_iff_getElem?.mpr ⟨b,(by simpa using hb : xs[b]?=some true)⟩
        have pos := List.count_pos_iff.mpr mem
        simp [List.count_cons]; omega
    | succ a =>
      cases b with
      | zero =>
        have h : x=true := by simpa using hb
        subst x
        have mem := List.mem_iff_getElem?.mpr ⟨a,(by simpa using ha : xs[a]?=some true)⟩
        have pos := List.count_pos_iff.mpr mem
        simp [List.count_cons]; omega
      | succ b =>
        have rest := ih (a:=a) (b:=b) (by omega) (by simpa using ha) (by simpa using hb)
        exact rest.trans (by rw [List.count_cons]; omega)
end
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
