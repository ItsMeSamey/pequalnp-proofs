import MixedHotReaderNet9822
import MixedSiteEval9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean

theorem replace_pair_get (pre mid tail : List Gate) (g q p : Gate) (k : Nat)
    (atOld : (pre++g::(mid++q::tail))[k]?=some p)
    (nz : k≠pre.length) (nr : k≠pre.length+1+mid.length) :
    (pre++topGate::(mid++topGate::tail))[k]?=some p := by
  by_cases lt : k<pre.length
  · simpa [List.getElem?_append,lt] using atOld
  obtain ⟨j,ej⟩ : ∃ j,k=pre.length+(j+1) := ⟨k-pre.length-1,by omega⟩
  subst k
  simp only [List.getElem?_append_right (by omega : pre.length≤pre.length+(j+1)),
    Nat.add_sub_cancel_left,List.getElem?_cons_succ] at atOld ⊢
  by_cases jm : j<mid.length
  · simpa [List.getElem?_append,jm] using atOld
  obtain ⟨l,el⟩ : ∃ l,j=mid.length+(l+1) := ⟨j-mid.length-1,by omega⟩
  subst j
  simpa [List.getElem?_append] using atOld

theorem preserved_and_sites {C pre mid tail g q} (r : Roster C pre (mid++q::tail) g)
    (op : q.op=.or) (k : Nat) (v : Gate) (site : C.gates[k]?=some v) (andOp : v.op=.and) :
    (hotReaderCircuit pre mid tail C.output).gates[k]?=some v := by
  have nz : k≠pre.length := by
    rintro rfl
    have eq : g=v := by simpa [r.split] using site
    subst v
    simp_all [r.inv]
  have nr : k≠pre.length+1+mid.length := by
    rintro rfl
    have eq : q=v := by
      rw [r.split,List.getElem?_append_right (by omega)] at site
      simpa [show pre.length+1+mid.length-pre.length=mid.length+1 by omega] using site
    subst v
    simp_all
  exact replace_pair_get pre mid tail g q v k (r.split ▸ site) nz nr

theorem final_is_prefix {n} (gs : List Gate) (x : Fin n → Bool) (k j : Nat) (hk : k≤gs.length)
    (lt : j<n+k) : (wiresFrom (gs.take k) (List.ofFn x)).getD j false=vl gs x j := by
  unfold vl
  conv_rhs => rw [←List.take_append_drop k gs,wiresFrom_append]
  symm
  apply getD_wiresFrom
  simpa [length_wiresFrom,List.length_take,Nat.min_eq_left hk] using lt

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
