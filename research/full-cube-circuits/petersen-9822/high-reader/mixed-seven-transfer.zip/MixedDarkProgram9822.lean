import MixedHotReaderNet9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean

open scoped Classical
noncomputable section
def simplifyDark (q : Gate) (u : List Bool) : Gate :=
  match q.inputs with
  | [a,b] => if q.op=.or then
      if u.getD a false=false then ⟨.and,[b]⟩ else if u.getD b false=false then ⟨.and,[a]⟩ else q
    else q
  | _ => q
def tick (q : Gate) (w : List Bool) := w ++ [q.op.eval (q.inputs.map fun i => w.getD i false)]
def simplifyProgram : List Gate → List Bool → List Gate
  | [],_ => []
  | q::qs,up => simplifyDark q up :: simplifyProgram qs (tick q up)

theorem simplifyDark_eval (q : Gate) (up w : List Bool)
    (h : ∀ i,w.getD i false=true → up.getD i false=true) :
    (simplifyDark q up).op.eval ((simplifyDark q up).inputs.map fun i => w.getD i false) =
      q.op.eval (q.inputs.map fun i => w.getD i false) := by
  have mono (i) (off : up.getD i false=false) : w.getD i false=false := by
    cases eq : w.getD i false with
    | false => rfl
    | true => exact Bool.noConfusion (off.symm.trans (h i eq))
  unfold simplifyDark
  split
  · rename_i a b ins
    split
    · rename_i op
      split
      · rename_i ha
        simp [ins,op,GateOp.eval]
        intro ww; exact Bool.noConfusion (ww.symm.trans (mono _ ha))
      · split
        · rename_i hb
          simp [ins,op,GateOp.eval]
          intro ww; exact Bool.noConfusion (ww.symm.trans (mono _ hb))
        · rfl
    · rfl
  · rfl

theorem simplifyProgram_eval (gs : List Gate) (pos : ∀q∈gs,PositiveOp q) (w up : List Bool)
    (le : WireLE w up) : wiresFrom (simplifyProgram gs up) w = wiresFrom gs w := by
  induction gs generalizing w up with
  | nil => rfl
  | cons q qs ih =>
    change wiresFrom (simplifyProgram qs (tick q up)) (tick (simplifyDark q up) w) =
      wiresFrom qs (tick q w)
    have eq : tick (simplifyDark q up) w=tick q w := by unfold tick; rw [simplifyDark_eval q up w le.2]
    rw [eq]
    apply ih (fun g m => pos _ (List.mem_cons_of_mem q m))
    exact phase_mono [q] (by simpa using pos q List.mem_cons_self) le

theorem simpleDark_ok (q : Gate) (up : List Bool) (ok : PositiveOp q ∧ q.inputs.length≤2) :
    PositiveOp (simplifyDark q up) ∧ (simplifyDark q up).inputs.length≤2 := by
  unfold simplifyDark
  split
  · split
    · split
      · exact ⟨Or.inl rfl,by change 1≤2; decide⟩
      · split
        · exact ⟨Or.inl rfl,by change 1≤2; decide⟩
        · exact ok
    · exact ok
  · exact ok

theorem simpleProgram_ok (gs : List Gate) (up : List Bool)
    (ok : ∀q∈gs,PositiveOp q ∧ q.inputs.length≤2) :
    ∀g∈simplifyProgram gs up,PositiveOp g ∧ g.inputs.length≤2 := by
  induction gs generalizing up with
  | nil => simp [simplifyProgram]
  | cons q qs ih =>
    intro g m
    rcases List.mem_cons.mp m with rfl|m
    · exact simpleDark_ok _ _ (ok _ List.mem_cons_self)
    · exact ih _ (fun t h => ok _ (List.mem_cons_of_mem _ h)) _ m

end
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
