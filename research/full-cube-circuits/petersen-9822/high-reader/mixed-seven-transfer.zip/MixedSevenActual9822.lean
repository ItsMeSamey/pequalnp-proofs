import MixedSevenTransfer9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean FreeAndNet
theorem mixed_seven_actual {C a b mid tail g H R}
    (r : Roster C (a++H::b) (mid++R::tail) g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (caseS : s=5 ∨ s=8)
    (upper : outerValue (a++H::b) (mid++R::tail) C.output (SignedClamp.singleton s) true=true)
    (v : Nat) (hop : H.op=.or) (hpins : H.inputs=[s.val,v] ∨ H.inputs=[v,s.val])
    (rop : R.op=.or) (rpin : 10+(a++H::b).length∈R.inputs) :
    let pre := a++copy v::b
    let post := mid++copy (10+(a++H::b).length)::tail
    (pre++post).countP CircuitCompiler.orFlag≤7 ∧
      ∀ x : Input,x s=false → outerValue pre post C.output x (!(innerValue pre g x))=edge x := by
  dsimp only
  obtain ⟨cost,equiv⟩ := restrict_mixed_seven r cand red seven s caseS upper v hop hpins rop rpin
  refine ⟨cost,?_⟩
  intro x off
  rw [equiv x off]
  have eq : innerValue (a++copy v::b) g x=innerValue (a++H::b) g x := by
    unfold innerValue
    rw [copy_guard_bank a b H s v hop hpins x off]
  rw [eq]
  exact (physical_cut_split cand r.split r.inv (fun q h => r.pos q (List.mem_append_right _ h))).computes x
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.mixed_seven_actual
