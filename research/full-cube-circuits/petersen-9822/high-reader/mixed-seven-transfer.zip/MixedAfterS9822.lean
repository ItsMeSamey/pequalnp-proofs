import MixedNineFaceFloors9822
namespace Research.OddOr.Envelope
open FreeAndNet Graph9822
theorem after_five_eight (s : V) (caseS : s=5 ∨ s=8) (u : Net V)
    (cold : ∀ j : V, j≠s → j≠9 → sees u {j}=false)
    (edges : ∀ i j : V, i≠s → j≠s → f {i,j}=true → sees u {i,j}=true) : 7≤u.cost := by
  have high : s∈([5,6,7,8]:List V) := by rcases caseS with rfl|rfl <;> decide
  have z : (0:V)≠s ∧ (4:V)≠s ∧ (9:V)≠s := by rcases caseS with rfl|rfl <;> decide
  have pay := positive_hit u (cold 4 z.2.1 (by decide)) (edges 9 4 z.2.2 z.2.1 (by decide +kernel))
    (avoids_output u (i:=9) (z:={0,4}) (by decide) (edges _ _ z.1 z.2.1 (by decide +kernel)))
  have neq {i : V} (hi : i∈outsideNine s) : i≠s ∧ i≠9 := by simpa [outsideNine] using hi
  have fit : Fits (fun i j => f {i,j}=true) (outsideNine s) (pin 9 u) := by
    constructor
    · intro i hi
      obtain ⟨is,ine⟩ := neq hi
      rw [pin_sees _ _ _ (by simp [Ne.symm ine])]
      exact cold i is ine
    · intro i hi j hj e
      obtain ⟨is,ine⟩ := neq hi
      obtain ⟨js,jn⟩ := neq hj
      rw [pin_sees _ _ _ (by simp [Ne.symm ine,Ne.symm jn])]
      exact edges _ _ is js e
  have low := mixed_face_floor s high _ fit
  have cap := pin_cost 9 u
  split at low <;> omega
end Research.OddOr.Envelope
#print axioms Research.OddOr.Envelope.after_five_eight
