import SignedClamp9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
def face2 (a b : Fin 10) (i j : Bool) : Input := fun k =>
  (i && singleton a k) || (j && singleton b k)
theorem rescued_three_face {H K} (cut : ComputesCut H K)
    (hm : ∀x y : Input,(∀k,x k=true → y k=true) → H x=true → H y=true)
    (km : ∀x y : Input,(∀k,x k=true → y k=true) → K x false=true → K y false=true)
    (a b : Fin 10) (edgeOn : edge (pair a b)=true) (missing : K (pair a b) false=false) :
    ∀i j z,K (face2 a b i j) z=(i && j && z) := by
  have hOff : H (pair a b)=false := by
    cases h : H (pair a b) with
    | false => rfl
    | true =>
      have impossible := cut.computes (pair a b)
      simp [h,missing,edgeOn] at impossible
  have sub (i j : Bool) : ∀k,face2 a b i j k=true → pair a b k=true := by
    intro k
    cases i <;> cases j <;> cases ha : singleton a k <;> cases hb : singleton b k <;> simp [face2,pair,ha,hb]
  have lo (i j : Bool) : K (face2 a b i j) false=false := by
    cases e : K (face2 a b i j) false with
    | false => rfl
    | true => exact Bool.noConfusion (missing.symm.trans (km _ _ (sub i j) e))
  have up (i j : Bool) : K (face2 a b i j) true=edge (face2 a b i j) := by
    have hh : H (face2 a b i j)=false := by
      cases e : H (face2 a b i j) with
      | false => rfl
      | true => exact Bool.noConfusion (hOff.symm.trans (hm _ _ (sub i j) e))
    simpa [hh] using cut.computes (face2 a b i j)
  intro i j z
  cases z with
  | false => simp [lo]
  | true =>
    rw [up]
    have ea : face2 a b true false=singleton a := by funext k;simp [face2]
    have eb : face2 a b false true=singleton b := by funext k;simp [face2]
    have ep : face2 a b true true=pair a b := by funext k;simp [face2,pair]
    cases i <;> cases j <;> simp [ea,eb,ep,edgeOn,singleton_zero]
    rfl
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.rescued_three_face
