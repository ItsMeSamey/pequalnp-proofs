import SignedOccupiedAxes9822
import AndAllFullPilot9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open Research.Graph9822Profiles Research.Graph9822Resolution
open Research.Graph9822.StarData (ends coverCost)
theorem obligated_six (D : Finset Vertex) (emptyEdges : Independent Dᶜ) : 6≤D.card := by
  classical
  have truth : ∀ i : Fin 13,onSet [(ends i).1.val,(ends i).2.val]=true := by decide +kernel
  have hit : ∀ i : Fin 13,(ends i).1∈D.toList ∨ (ends i).2∈D.toList := by
    intro i
    by_contra! no
    have a : (ends i).1∈Dᶜ := Finset.mem_compl.mpr (by simpa using no.1)
    have b : (ends i).2∈Dᶜ := Finset.mem_compl.mpr (by simpa using no.2)
    exact emptyEdges _ a _ b (truth i)
  simpa using coverCost D.toList hit

open Research.Graph9822Profiles.OuterLive
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.Outside.L_meta_9822.OuterDirections
theorem five_occupied_false {pre post : List PEqualNP.CircuitLowerBounds.Gate}
    {g : PEqualNP.CircuitLowerBounds.Gate} {out rout : Nat} {gs : List DirGate}
    (basis : asCircuit gs rout=outerCircuit 10 pre post out) (cut : ComputesCut (innerValue pre g) (outerValue pre post out))
    (positive : ∀ q∈pre,PositiveOp q) (cap : gs.countP Research.Graph9822Resolution.Gate.isAnd≤6)
    {bs lib : List Mask} {p : List (Axis × Mask)} {n : Nat} (scan : Scan bs lib p n)
    (member : ∀ v : Fin 11,{w | actualReceiver gs rout cap v.val w}∈lib)
    (D : Finset Vertex) (size : D.card=5) (ax : Vertex → Axis) (sign : Word)
    (signed : ∀ v∈D,∀ w,actualReceiver gs rout cap v.val w → w (ax v)=sign (ax v))
    (saturated : ∀ i U,(i,U)∈p → ∃ v∈D,{w | actualReceiver gs rout cap v.val w}=U∩side i (sign i)) : False := by
  have h := physical_exterior_independent basis cut positive cap scan (fun v => member ⟨v.val,by omega⟩)
    D (by omega) ax sign signed saturated (member 10)
  have six := obligated_six D h
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.five_occupied_false
