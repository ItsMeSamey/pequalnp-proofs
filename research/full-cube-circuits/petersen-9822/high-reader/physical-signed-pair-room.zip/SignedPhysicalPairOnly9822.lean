import SignedPairOnly9822
import SignedDirectPhysical9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.PairRoom
open PEqualNP.CircuitLowerBounds Research.Graph9822Profiles Research.Graph9822Profiles.OuterLive
open PEqualNP.Outside.L_meta_9822.Clean (outerCircuit)
open PEqualNP.Outside.L_meta_9822.OuterDirections Research.Graph9822Resolution
theorem physical_pair_only_false {pre post : List PEqualNP.CircuitLowerBounds.Gate} {g : PEqualNP.CircuitLowerBounds.Gate}
    {out rout : Nat} {gs : List DirGate} (basis : asCircuit gs rout=outerCircuit 10 pre post out)
    (cut : ComputesCut (innerValue pre g) (outerValue pre post out))
    (positive : ∀ q∈pre,PositiveOp q) (cap : gs.countP Research.Graph9822Resolution.Gate.isAnd≤6)
    (k : Fin 16) (four : (independentSets k).length=4) (B : V → Word → Prop)
    (opposite : ∀ i : V,i.val∉independentSets k → ∀ w,B i w → ¬actualReceiver gs rout cap i.val w)
    (paired : ∀ n : V,n.val∈independentSets k → ∃ a b : V,
      a.val∉independentSets k ∧ b.val∉independentSets k ∧
      ∀ w,actualReceiver gs rout cap n.val w ↔ B a w ∨ B b w) : False := by
  obtain ⟨rooms,_,obs⟩ := sixteen_room gs rout cap (auxBit pre g)
    (auxBit_antitone positive g) (fun xs h => onSet_outer_eval basis cut xs h)
  exact pair_only_false k four (fun i => actualReceiver gs rout cap i.val) B rooms obs opposite paired
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.PairRoom
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.PairRoom.physical_pair_only_false
