import SignedPairRoomData9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.PairRoom
open Research.Graph9822Profiles Research.Graph9822Resolution
theorem pair_only_false (k : Fin 16) (four : (independentSets k).length=4)
    (R B : V → Word → Prop) (rooms : Fin 16 → Word)
    (obs : ∀ j n, R n (rooms j) ↔ n.val∉independentSets j)
    (opposite : ∀ i : V,i.val∉independentSets k → ∀ w,B i w → ¬R i w)
    (paired : ∀ n : V,n.val∈independentSets k → ∃ a b : V,
      a.val∉independentSets k ∧ b.val∉independentSets k ∧ ∀ w,R n w ↔ B a w ∨ B b w) : False := by
  have fit (n a b : V) (ad : a.val∉independentSets k) (bd : b.val∉independentSets k)
      (pair : ∀ w,R n w ↔ B a w ∨ B b w) : Fit k n a b := by
    refine ⟨ad,bd,?_⟩
    intro j hn
    rcases (pair _).mp ((obs j n).mpr hn) with yes|yes
    · exact Or.inl (by by_contra h;exact opposite a ad _ yes ((obs j a).mpr h))
    · exact Or.inr (by by_contra h;exact opposite b bd _ yes ((obs j b).mpr h))
  rcases witness k four with ⟨n,nin,bad⟩|rfl
  · obtain ⟨a,b,ad,bd,pair⟩ := paired n nin
    exact bad a b (fit n a b ad bd pair)
  · have forced (n : V) (h : n=6 ∨ n=7) : ∀ w,R n w ↔ B 1 w ∨ B 2 w := by
      have nin : n.val∈independentSets 5 := by rcases h with rfl|rfl <;> decide
      obtain ⟨a,b,ad,bd,pair⟩ := paired n nin
      have p := fit n a b ad bd pair
      have e : (a=1 ∧ b=2) ∨ (a=2 ∧ b=1) := by
        rcases h with rfl|rfl
        · exact double6 a b p
        · exact double7 a b p
      rcases e with ⟨rfl,rfl⟩|⟨rfl,rfl⟩
      · exact pair
      · simpa [or_comm] using pair
    have six := (obs 4 6).mpr (by decide)
    have seven := (forced 7 (Or.inr rfl) _).mpr ((forced 6 (Or.inl rfl) _).mp six)
    exact (obs 4 7).mp seven (by decide)
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.PairRoom
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.PairRoom.pair_only_false
