import CompactSignedReceivers9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.PairRoom
open Research.Graph9822Resolution
abbrev V := Fin 10
abbrev Fit (k : Fin 16) (n a b : V) :=
  a.val∉independentSets k ∧ b.val∉independentSets k ∧
  ∀ j : Fin 16,n.val∉independentSets j → a.val∈independentSets j ∨ b.val∈independentSets j

theorem obstruct1 : ∀ a b : V,¬Fit 1 6 a b := by decide +kernel
theorem obstruct2 : ∀ a b : V,¬Fit 2 6 a b := by decide +kernel
theorem obstruct3 : ∀ a b : V,¬Fit 3 5 a b := by decide +kernel
theorem obstruct4 : ∀ a b : V,¬Fit 4 7 a b := by decide +kernel
theorem obstruct8 : ∀ a b : V,¬Fit 8 7 a b := by decide +kernel
theorem obstruct9 : ∀ a b : V,¬Fit 9 7 a b := by decide +kernel
theorem obstruct10 : ∀ a b : V,¬Fit 10 9 a b := by decide +kernel
theorem obstruct11 : ∀ a b : V,¬Fit 11 9 a b := by decide +kernel
theorem obstruct12 : ∀ a b : V,¬Fit 12 9 a b := by decide +kernel
theorem obstruct13 : ∀ a b : V,¬Fit 13 9 a b := by decide +kernel
theorem obstruct14 : ∀ a b : V,¬Fit 14 9 a b := by decide +kernel
theorem obstruct15 : ∀ a b : V,¬Fit 15 9 a b := by decide +kernel
theorem double6 : ∀ a b : V,Fit 5 6 a b → (a=1 ∧ b=2) ∨ (a=2 ∧ b=1) := by decide +kernel
theorem double7 : ∀ a b : V,Fit 5 7 a b → (a=1 ∧ b=2) ∨ (a=2 ∧ b=1) := by decide +kernel
theorem witness (k : Fin 16) (four : (independentSets k).length=4) :
   (∃ n : V,n.val∈independentSets k ∧ ∀ a b,¬Fit k n a b) ∨ k=5 := by
  fin_cases k
  · exact False.elim ((by decide : (independentSets 0).length≠4) four)
  · exact Or.inl ⟨6,by decide,obstruct1⟩
  · exact Or.inl ⟨6,by decide,obstruct2⟩
  · exact Or.inl ⟨5,by decide,obstruct3⟩
  · exact Or.inl ⟨7,by decide,obstruct4⟩
  · exact Or.inr rfl
  · exact False.elim ((by decide : (independentSets 6).length≠4) four)
  · exact False.elim ((by decide : (independentSets 7).length≠4) four)
  · exact Or.inl ⟨7,by decide,obstruct8⟩
  · exact Or.inl ⟨7,by decide,obstruct9⟩
  · exact Or.inl ⟨9,by decide,obstruct10⟩
  · exact Or.inl ⟨9,by decide,obstruct11⟩
  · exact Or.inl ⟨9,by decide,obstruct12⟩
  · exact Or.inl ⟨9,by decide,obstruct13⟩
  · exact Or.inl ⟨9,by decide,obstruct14⟩
  · exact Or.inl ⟨9,by decide,obstruct15⟩
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.PairRoom
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.PairRoom.witness
