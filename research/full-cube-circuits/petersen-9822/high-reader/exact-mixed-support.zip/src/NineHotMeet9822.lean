import NineHotContacts9822
namespace Research.NineHotContacts
def both : Signal → Signal → Signal
  | .raw,_ | _,.raw => .raw
  | .first,.first => .first
  | .second,.second => .second
  | _,_ => .meet

theorem read_both : ∀ (linked r p q : Bool) (s t : Signal),
    let a := r || p
    let b := (if linked then a else r) || q
    read r a b (both s t) = (read r a b s && read r a b t) := by
  intro linked r p q s t
  cases s <;> cases t <;> revert linked r p q <;> decide +kernel

/-- A table of actual wires with a single distinguished hot input. The
two issuing ORs need only be listed when actually encountered in the prefix. -/
structure Table (X : Type) where
  wire : Nat → X → Bool
  test : X
  raw : Nat
  hot : wire raw test = true

namespace Table
variable {X : Type} (w : Table X)
def Hot (i : Nat) := w.wire i w.test = true

/-- A physical OR defines raw9 ∨ cold before a second hot OR occurs. -/
theorem one_before {stop A p : Nat}
    (first : ∀ x, w.wire A x = (w.wire w.raw x || w.wire p x))
    (steps : ∀ j < stop, w.Hot j → j=w.raw ∨ j=A ∨
      ∃ u<j, ∃ v<j, w.Hot u ∧ w.Hot v ∧
        ∀ x, w.wire j x = (w.wire u x && w.wire v x))
    (j : Nat) (lt : j<stop) (hot : w.Hot j) :
    w.wire j = w.wire w.raw ∨ w.wire j = w.wire A := by
  induction j using Nat.strong_induction_on with
  | ind j ih =>
    rcases steps j lt hot with rfl|rfl|⟨u,uj,v,vj,uh,vh,ev⟩
    · exact Or.inl rfl
    · exact Or.inr rfl
    rcases ih u uj (by omega) uh with ru|au <;> rcases ih v vj (by omega) vh with rv|av
    · left; funext x; simp [ev,ru,rv]
    · left; funext x; rw [ev,ru,av,first]; cases w.wire w.raw x <;> simp
    · left; funext x; rw [ev,au,rv,first]; cases w.wire w.raw x <;> simp
    · right; funext x; simp [ev,au,av]

/-- Each surviving hot wire has one of the four functions. Statements range
over all actual inputs. A bound on available cold physical IDs travels
with the tags, so later hot ORs cannot supply a predecessor retroactively. -/
theorem two_after {stop A B p q : Nat} {linked : Bool}
    (first : ∀ x, w.wire A x = (w.wire w.raw x || w.wire p x))
    (second : ∀ x, w.wire B x = ((if linked then w.wire A x else w.wire w.raw x) || w.wire q x))
    (pa : p<A) (qb : q<B)
    (steps : ∀ j < stop, w.Hot j → j=w.raw ∨ j=A ∨ j=B ∨
      ∃ u<j, ∃ v<j, w.Hot u ∧ w.Hot v ∧
        ∀ x, w.wire j x = (w.wire u x && w.wire v x))
    (j : Nat) (lt : j<stop) (hot : w.Hot j) :
    ∃ s : Signal, (s=.first → p<j) ∧ (s=.second → q<j) ∧
      ∀ x, w.wire j x = read (w.wire w.raw x) (w.wire A x) (w.wire B x) s := by
  induction j using Nat.strong_induction_on with
  | ind j ih =>
    rcases steps j lt hot with rfl|rfl|rfl|⟨u,uj,v,vj,uh,vh,ev⟩
    · exact ⟨.raw,by simp,by simp,fun _ => rfl⟩
    · exact ⟨.first,fun _ => pa,by simp,fun _ => rfl⟩
    · exact ⟨.second,by simp,fun _ => qb,fun _ => rfl⟩
    obtain ⟨s,sp,sq,hs⟩ := ih u uj (by omega) uh
    obtain ⟨t,tp,tq,ht⟩ := ih v vj (by omega) vh
    refine ⟨both s t,?_,?_,?_⟩
    · cases s <;> cases t <;> simp_all [both] <;> omega
    · cases s <;> cases t <;> simp_all [both] <;> omega
    · intro x
      rw [ev,hs,ht,second,first]
      exact (read_both linked _ _ _ s t).symm
end Table
end Research.NineHotContacts
#print axioms Research.NineHotContacts.Table.two_after
