import NineHotMeet9822
namespace Research.NineHotContacts.Table
variable {X : Type} (w : Table X)
theorem contact {stop A B p q h j : Nat} {linked : Bool}
    (first : ∀ x, w.wire A x = (w.wire w.raw x || w.wire p x))
    (second : ∀ x, w.wire B x = ((if linked then w.wire A x else w.wire w.raw x) || w.wire q x))
    (pa : p<A) (qb : q<B) (pc : w.wire p w.test=false) (qc : w.wire q w.test=false)
    (steps : ∀ k < stop, w.Hot k → k=w.raw ∨ k=A ∨ k=B ∨
      ∃ u<k, ∃ v<k, w.Hot u ∧ w.Hot v ∧
        ∀ x, w.wire k x = (w.wire u x && w.wire v x))
    (hh : h<stop) (hh' : w.Hot h) (nonraw : w.wire h ≠ w.wire w.raw)
    (hj : j<stop) (hj' : w.Hot j) :
    (∀ x, (!w.wire h x && w.wire j x)=false) ∨
    ∃ k<j, w.wire k w.test=false ∧ ∀ x, (!w.wire h x && w.wire j x)=(!w.wire h x && w.wire k x) := by
  obtain ⟨sh,_,_,rh⟩ := w.two_after first second pa qb steps h hh hh'
  obtain ⟨sj,sjA,sjB,rj⟩ := w.two_after first second pa qb steps j hj hj'
  have guardRep : ∃ g : Guard, ∀ x, w.wire h x = guard (w.wire A x) (w.wire B x) g := by
    cases sh with
    | raw => exact False.elim (nonraw (funext rh))
    | first => exact ⟨.first,rh⟩
    | second => exact ⟨.second,rh⟩
    | meet => exact ⟨.meet,rh⟩
  obtain ⟨g,rg⟩ := guardRep
  have eq (x : X) : (!w.wire h x && w.wire j x) =
      (!w.wire h x && replacement (w.wire p x) (w.wire q x) (repair g sj)) := by
    rw [rg,rj,second,first]
    exact all_rows linked _ _ _ g sj
  cases hr : repair g sj with
  | zero => left; intro x; simpa [hr,replacement] using eq x
  | coldA =>
    have s : sj=.first := by cases g <;> cases sj <;> simp_all [repair]
    exact Or.inr ⟨p,sjA s,pc,fun x => by simpa [hr,replacement] using eq x⟩
  | coldB =>
    have s : sj=.second := by cases g <;> cases sj <;> simp_all [repair]
    exact Or.inr ⟨q,sjB s,qc,fun x => by simpa [hr,replacement] using eq x⟩
end Research.NineHotContacts.Table
#print axioms Research.NineHotContacts.Table.contact
