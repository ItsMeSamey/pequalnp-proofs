import UpperColdPhysical9822
import AllPairObservers9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds
open SignedClamp NonrawSupport LowHotElimination PEqualNP.Outside.L_meta_9822.Clean

theorem prefix_hot_wire {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7≤C.gates.countP countsAnd) (i : Fin 10)
    (hot : innerValue pre g (SignedClamp.singleton i)=true) :
    ∃ k : Nat,k<pre.length ∧ vl C.gates (SignedClamp.singleton i) (10+k)=true := by
  cases ins : g.inputs with
  | nil => simp [innerValue,ins] at hot
  | cons a more =>
    have read (x : Input) : innerValue pre g x=(wiresFrom pre (List.ofFn x)).getD a false := by
      simp [innerValue,ins]
    rw [read] at hot
    have upper : a<10+pre.length := by
      by_contra! large
      rw [List.getD_eq_default _ _ (by simp [length_wiresFrom]; omega)] at hot
      contradiction
    have lower : 10≤a := by
      by_contra! raw
      obtain ⟨x,off,_,on⟩ := independent_witness r cand seven ⟨a,raw⟩
      rw [read,getD_wiresFrom _ _ _ (by simpa using raw),getD_ofFn 10 x false ⟨a,raw⟩,off] at on
      contradiction
    refine ⟨a-10,by omega,?_⟩
    rw [show 10+(a-10)=a by omega,visible r a upper]
    exact hot

theorem first_hot_socket {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7≤C.gates.countP countsAnd) (red : Reduced 10 C.gates C.output) (i : Fin 10)
    (hot : innerValue pre g (SignedClamp.singleton i)=true) :
    ∃ k : Nat, ∃ q : Gate, ∃ b : Nat, k<pre.length ∧ pre[k]?=some q ∧
      q.op=.or ∧ b<10+k ∧ b≠i.val ∧ (q.inputs=[i.val,b] ∨ q.inputs=[b,i.val]) ∧
      vl C.gates (SignedClamp.singleton i) b=false ∧
      (∀ j, j<k → vl C.gates (SignedClamp.singleton i) (10+j)=false) := by
  classical
  let P := fun k : Nat => k<pre.length ∧ vl C.gates (SignedClamp.singleton i) (10+k)=true
  have ex : ∃ k,P k := prefix_hot_wire r cand seven i hot
  let k := Nat.find ex
  obtain ⟨kp,on⟩ := Nat.find_spec ex
  have before (j : Nat) (h : j<k) : vl C.gates (SignedClamp.singleton i) (10+j)=false := by
    cases e : vl C.gates (SignedClamp.singleton i) (10+j) with
    | false => rfl
    | true => exact False.elim ((Nat.find_min ex h) ⟨by omega,e⟩)
  have only (a : Nat) (bound : a<10+k) (yes : vl C.gates (SignedClamp.singleton i) a=true) : a=i.val := by
    by_cases raw : a<10
    · rw [vl_input _ _ _ raw] at yes
      have eq : (⟨a,raw⟩ : Fin 10)=i := by simpa [SignedClamp.singleton] using yes
      exact congrArg Fin.val eq
    · have no := before (a-10) (by omega)
      rw [show 10+(a-10)=a by omega,yes] at no
      contradiction
  let q := pre[k]'kp
  have idx : pre[k]?=some q := List.getElem?_eq_getElem kp
  have orig : C.gates[k]?=some q := by rw [r.split,List.getElem?_append_left kp]; exact idx
  have pos := r.pos q (List.mem_append_left _ (List.mem_iff_getElem?.mpr ⟨k,idx⟩))
  have out := vl_gate C.gates red.clean (SignedClamp.singleton i) k q orig
  change vl C.gates _ (10+k)=true at on
  rw [out] at on
  rcases red.clean k q orig with ⟨neg,_⟩|⟨_,a,b,ha,hb,ins⟩
  · rcases pos with pa|po <;> simp_all
  · have distinct : a≠b := by
      rintro rfl
      apply red.noAlias k (List.getElem?_eq_some_iff.mp orig).1 a ha
      intro x
      rw [vl_gate C.gates red.clean x k q orig,ins]
      rcases pos with op|op <;> simp [op,GateOp.eval]
    rcases pos with op|op
    · simp [op,ins,GateOp.eval] at on
      exact False.elim (distinct ((only _ ha on.1).trans (only _ hb on.2).symm))
    · simp [op,ins,GateOp.eval] at on
      rcases on with left|right
      · have eq := only _ ha left
        have ne : b≠i.val := fun bad => distinct (eq.trans bad.symm)
        refine ⟨k,q,b,kp,idx,op,hb,ne,Or.inl (eq ▸ ins),?_,before⟩
        cases e : vl C.gates (SignedClamp.singleton i) b
        · rfl
        · exact False.elim (ne (only _ hb e))
      · have eq := only _ hb right
        have ne : a≠i.val := fun bad => distinct (bad.trans eq.symm)
        refine ⟨k,q,a,kp,idx,op,ha,ne,Or.inr (eq ▸ ins),?_,before⟩
        cases e : vl C.gates (SignedClamp.singleton i) a
        · rfl
        · exact False.elim (ne (only _ ha e))
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.first_hot_socket
