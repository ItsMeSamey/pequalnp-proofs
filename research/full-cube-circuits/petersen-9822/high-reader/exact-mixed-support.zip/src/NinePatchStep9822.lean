import NinePatchChoice9822
namespace PEqualNP.Outside.L_meta_9822.Clean.NinePatch
open PEqualNP.CircuitLowerBounds
def replaced (F : Nat → Bool) (z : Nat) (bit : Bool) (i : Nat) := if i=z then bit else F i
theorem eval_step {q : Gate} {f : Nat → Nat} {F G : Nat → Bool} {z a b : Nat}
    (ins : q.inputs=[a,b]) (away : ∀ j,j≠z → G j=F j) (ands : z∈q.inputs → q.op=.and)
    (use : ∀ j,q.inputs=[z,j] ∨ q.inputs=[j,z] → (G z && G (f j))=(F z && F j)) :
    (patch z f q).op.eval ((patch z f q).inputs.map G)=q.op.eval (q.inputs.map F) := by
  by_cases az : a=z
  · subst a
    have op := ands (by simp [ins])
    simpa [patch,ins,op,GateOp.eval] using use b (Or.inl ins)
  by_cases bz : b=z
  · subst b
    have op := ands (by simp [ins])
    simpa [patch,ins,op,az,GateOp.eval,Bool.and_comm] using use a (Or.inr ins)
  · simp [patch,ins,az,bz,away a az,away b bz]
end PEqualNP.Outside.L_meta_9822.Clean.NinePatch
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds
open SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean NinePatch

theorem patch_bank {C pre post g} (r : Roster C pre post g) (x : Input) (c : Bool)
    (i : Nat) (lt : i < (wiresFrom pre (List.ofFn x) ++ [c]).length) :
    (wiresFrom pre (List.ofFn x) ++ [c]).getD i false = replaced (vl C.gates x) (10+pre.length) c i := by
  let w := wiresFrom pre (List.ofFn x)
  have len : w.length=10+pre.length := by simp [w,length_wiresFrom]
  change i<(w++[c]).length at lt
  change (w++[c]).getD i false=_
  by_cases eq : i=w.length
  · subst i; rw [getD_snoc_eq];simp [replaced,len]
  · have small : i<w.length := by simp at lt;omega
    rw [getD_snoc_ne _ _ _ _ eq]
    simp only [replaced,show i≠10+pre.length by omega,ite_false]
    unfold vl
    rw [r.split,wiresFrom_append,getD_wiresFrom _ _ _ small]

theorem post_gate_info {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output)
    {q : Gate} {k : Nat} (hq : post[k]?=some q) :
    C.gates[pre.length+(k+1)]?=some q ∧ ∃ a b, q.inputs=[a,b] ∧ a<10+(pre.length+(k+1)) ∧
      b<10+(pre.length+(k+1)) := by
  have found : C.gates[pre.length+(k+1)]?=some q := by
    rw [r.split,List.getElem?_append_right (by omega)];simpa using hq
  refine ⟨found,?_⟩
  have pos := r.pos q (List.mem_append_right _ (List.mem_iff_getElem?.mpr ⟨k,hq⟩))
  rcases red.clean _ q found with ⟨neg,_⟩|⟨_,a,b,ha,hb,ins⟩
  · rcases pos with pa|po <;> simp_all
  · exact ⟨a,b,ins,ha,hb⟩
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
