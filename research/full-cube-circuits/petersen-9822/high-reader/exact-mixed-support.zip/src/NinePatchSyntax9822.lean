import NineRebuiltOneRow9822
namespace PEqualNP.Outside.L_meta_9822.Clean.NinePatch
open PEqualNP.CircuitLowerBounds

def patch (z : Nat) (f : Nat → Nat) (q : Gate) : Gate :=
  ⟨q.op,match q.inputs with
  | [a,b] => if a=z then [a,f b] else if b=z then [f a,b] else [a,b]
  | ins => ins⟩

theorem patch_clean {m z : Nat} (f : Nat → Nat) (bound : ∀ j,f j≤j) {q : Gate}
    (ok : CleanGate m q) : CleanGate m (patch z f q) := by
  rcases ok with ⟨op,j,hj,ins⟩ | ⟨op,a,b,ha,hb,ins⟩
  · exact Or.inl ⟨op,j,hj,by simp [patch,ins]⟩
  · apply Or.inr
    refine ⟨op,?_⟩
    by_cases az : a=z
    · exact ⟨a,f b,ha,(bound b).trans_lt hb,by simp [patch,ins,az]⟩
    by_cases bz : b=z
    · exact ⟨f a,b,(bound a).trans_lt ha,hb,by simp [patch,ins,az,bz]⟩
    · exact ⟨a,b,ha,hb,by simp [patch,ins,az,bz]⟩

theorem patch_suffix_clean {n z : Nat} (p t : List Gate) (f : Nat → Nat)
    (bound : ∀ j,f j≤j) (legal : CleanL n (p++t)) : CleanL n (p++t.map (patch z f)) := by
  intro j q hq
  by_cases inside : j<p.length
  · rw [List.getElem?_append_left inside] at hq
    apply legal j q
    rwa [List.getElem?_append_left inside]
  · rw [List.getElem?_append_right (by omega),List.getElem?_map] at hq
    cases old : t[j-p.length]? with
    | none => simp [old] at hq
    | some a =>
      have eq : patch z f a=q := by simpa [old] using hq
      rw [←eq]
      apply patch_clean f bound (legal j a ?_)
      rw [List.getElem?_append_right (by omega),old]

theorem aligned_run (gs : List Gate) (w : List Bool) (F : Nat → Bool)
    (base : ∀ i,i<w.length → w.getD i false=F i)
    (legal : ∀ k q,gs[k]?=some q → ∀ j∈q.inputs,j<w.length+k)
    (steps : ∀ k q,gs[k]?=some q → q.op.eval (q.inputs.map F)=F (w.length+k)) :
    ∀ j,j<w.length+gs.length → (wiresFrom gs w).getD j false=F j := by
  induction gs generalizing w with
  | nil => simpa [wiresFrom] using base
  | cons g gs ih =>
    have eq : g.op.eval (g.inputs.map fun i => w.getD i false)=F w.length := by
      rw [show g.inputs.map (fun i => w.getD i false)=g.inputs.map F from
        List.map_congr_left (fun i hi => base i (by simpa using legal 0 g (by simp) i hi))]
      simpa using steps 0 g (by simp)
    intro j hj
    change (wiresFrom gs (w++[_])).getD j false=F j
    rw [eq]
    apply ih
    · intro i hi
      by_cases e : i=w.length
      · subst i;rw [getD_snoc_eq]
      · rw [getD_snoc_ne _ _ _ _ e];apply base;simp at hi;omega
    · intro k q hq i hi
      have h := legal (k+1) q (by simpa using hq) i hi
      simp;omega
    · intro k q hq
      have h := steps (k+1) q (by simpa using hq)
      simpa only [List.length_append,List.length_cons,List.length_nil,Nat.zero_add,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using h
    · simp at hj ⊢;omega
end PEqualNP.Outside.L_meta_9822.Clean.NinePatch
