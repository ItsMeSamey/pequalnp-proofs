import NineClampPrice9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardTags
open PEqualNP.CircuitLowerBounds FreeAndNet.CircuitCompiler

theorem zero_no_or_reader (gs : List Gate) (w : List Bool) (i : Nat)
    (lt : i<w.length) (hot : w.getD i false=true) (zero : physicalHot gs w=0)
    (q : Gate) (mem : q∈gs) (use : i∈q.inputs) : q.op ≠ .or := by
  induction gs generalizing w with
  | nil => contradiction
  | cons g gs ih =>
    let bit := g.op.eval (g.inputs.map fun k => w.getD k false)
    change physicalHot gs (w++[bit]) + (orFlag g && bit).toNat=0 at zero
    rcases List.mem_cons.mp mem with eq|later
    · subst q
      intro oq
      have high : bit=true := by
        change g.op.eval _=true
        rw [oq]
        exact List.any_eq_true.mpr ⟨_,List.mem_map.mpr ⟨i,use,rfl⟩,by simpa using hot⟩
      simp [high,oq,orFlag] at zero
    · exact ih (w++[bit]) (by simp;omega) (by rw [List.getD_append _ _ _ _ lt];exact hot) (by omega) later
end PEqualNP.Outside.L_meta_9822.Clean.GuardTags
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
open GuardTags

theorem nine_direct_and {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (other : ∀ j : Fin 10,j≠9 → innerValue pre g (SignedClamp.singleton j)=false)
    (q : Gate) (mem : q∈post) (uses : 10+pre.length∈q.inputs) : q.op=.and := by
  let w := wiresFrom pre (List.ofFn (fun _ : Fin 10 => false))
  have len : w.length=10+pre.length := by simp [w,length_wiresFrom]
  have cost := zero_upper_hot r cand red seven other
  have no := zero_no_or_reader post (w++[true]) (10+pre.length) (by simp [len])
    (by rw [←len,getD_snoc_eq]) cost q mem uses
  exact (r.pos q (List.mem_append_right _ mem)).resolve_right no
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.nine_direct_and
