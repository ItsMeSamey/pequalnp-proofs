import OR9822ColdRoot
import MixedPositive9822
namespace Research.OddOr.Envelope
open FreeAndNet Graph9822
def outsideNine (s : V) : Finset V := Finset.univ \ {s,9}

private def core5 : Cycle5.V ↪ V where
  toFun := fun i => ([0,4,3,8,5] : List V).get i
  inj' := by decide +kernel

private theorem base5 (t : Net V) (fit : Fits (fun i j => f {i,j} = true) (outsideNine 5) t) : 6 ≤ t.cost := by
  have peel : Peel (fun i j => f {i,j} = true) [0,4,3,8,6,1] {2,7} := by
    refine Peel.step (j := 4) (a := 2) (b := 7) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 3) (a := 2) (b := 7) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 8) (a := 2) (b := 7) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 6) (a := 2) (b := 7) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 1) (a := 2) (b := 7) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 2) (a := 2) (b := 7) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  have eq : ([0,4,3,8,6,1] : List V).toFinset ∪ {2,7} = outsideNine 5 := by decide +kernel
  rw [←eq] at fit
  obtain ⟨u,h,_⟩ := peel_cost peel t fit
  change u.cost + 6 ≤ t.cost at h
  omega
private theorem base8 (t : Net V) (fit : Fits (fun i j => f {i,j} = true) (outsideNine 8) t) : 6 ≤ t.cost := by
  have peel : Peel (fun i j => f {i,j} = true) [3,4,0,5,7,2] {1,6} := by
    refine Peel.step (j := 4) (a := 1) (b := 6) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 0) (a := 1) (b := 6) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 5) (a := 1) (b := 6) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 7) (a := 1) (b := 6) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 2) (a := 1) (b := 6) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 1) (a := 1) (b := 6) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  have eq : ([3,4,0,5,7,2] : List V).toFinset ∪ {1,6} = outsideNine 8 := by decide +kernel
  rw [←eq] at fit
  obtain ⟨u,h,_⟩ := peel_cost peel t fit
  change u.cost + 6 ≤ t.cost at h
  omega
private theorem base6 (t : Net V) (fit : Fits (fun i j => f {i,j} = true) (outsideNine 6) t) : 7 ≤ t.cost := by
  have peel : Peel (fun i j => f {i,j} = true) [1,2,7] {0,4,3,8,5} := by
    refine Peel.step (j := 2) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 7) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 5) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  have eq : ([1,2,7] : List V).toFinset ∪ {0,4,3,8,5} = outsideNine 6 := by decide +kernel
  rw [←eq] at fit
  exact section_to_pentagon core5 _ _ peel (by decide +kernel) (by decide +kernel) t fit
private theorem base7 (t : Net V) (fit : Fits (fun i j => f {i,j} = true) (outsideNine 7) t) : 7 ≤ t.cost := by
  have peel : Peel (fun i j => f {i,j} = true) [2,1,6] {0,4,3,8,5} := by
    refine Peel.step (j := 1) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 6) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 8) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  have eq : ([2,1,6] : List V).toFinset ∪ {0,4,3,8,5} = outsideNine 7 := by decide +kernel
  rw [←eq] at fit
  exact section_to_pentagon core5 _ _ peel (by decide +kernel) (by decide +kernel) t fit

theorem mixed_face_floor (s : V) (high : s∈([5,6,7,8] : List V)) (t : Net V)
    (fit : Fits (fun i j => f {i,j} = true) (outsideNine s) t) :
    (if s=6 ∨ s=7 then 7 else 6) ≤ t.cost := by
  simp only [List.mem_cons,List.not_mem_nil,or_false] at high
  rcases high with rfl|rfl|rfl|rfl
  · exact base5 t fit
  · exact base6 t fit
  · exact base7 t fit
  · exact base8 t fit

end Research.OddOr.Envelope
#print axioms Research.OddOr.Envelope.mixed_face_floor
