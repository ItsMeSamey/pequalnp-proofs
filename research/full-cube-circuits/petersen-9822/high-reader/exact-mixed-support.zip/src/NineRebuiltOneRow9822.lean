import NineRebuiltExclusion9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean

theorem rewritten_nine_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (other : ∀ j : Fin 10,j≠9 → innerValue pre g (SignedClamp.singleton j)=false)
    (post' : List Gate) (clean : CleanL 10 (pre++g::post')) (size : post'.length≤post.length)
    (andCount : post.countP countsAnd≤post'.countP countsAnd) (positive : ∀ q∈post', PositiveOp q)
    (same : ∀ x : Input, vl (pre++g::post') x C.output=vl C.gates x C.output)
    (coldNine : outerValue pre post' C.output (SignedClamp.singleton 9) true=false) : False := by
  apply rewritten_clamp_impossible r cand red seven post' clean size andCount positive same
  intro j
  by_cases isNine : j=9
  · exact isNine ▸ coldNine
  have off := other j isNine
  let x := SignedClamp.singleton j
  let w := wiresFrom pre (List.ofFn x)
  have bit : g.op.eval (g.inputs.map fun i => w.getD i false)=true := by
    rw [r.inv]
    change !(innerValue pre g x)=true
    rw [off];rfl
  have eq := (same x).trans (cand.2.2 x)
  change (wiresFrom (pre++g::post') (List.ofFn x)).getD C.output false=edge x at eq
  rw [wiresFrom_append] at eq
  change (wiresFrom post' (w++[_])).getD C.output false=edge x at eq
  rw [bit] at eq
  exact eq.trans (singleton_zero j)
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
