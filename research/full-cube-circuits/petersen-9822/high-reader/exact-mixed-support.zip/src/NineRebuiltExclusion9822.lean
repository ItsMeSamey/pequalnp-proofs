import UpperColdPhysical9822
import RetimingMinimum9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet Research.OddOr
open SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean

theorem rewritten_clamp_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (post' : List Gate) (clean : CleanL 10 (pre++g::post')) (size : post'.length≤post.length)
    (andCount : post.countP countsAnd≤post'.countP countsAnd)
    (positive : ∀ q∈post', PositiveOp q)
    (same : ∀ x : Input, vl (pre++g::post') x C.output=vl C.gates x C.output)
    (cold : ∀ j,outerValue pre post' C.output (SignedClamp.singleton j) true=false) : False := by
  let D : Circuit := ⟨pre++g::post',C.output⟩
  have legal : FanInTwo D := fun q hq => (clean_nok _ _ clean q hq).1
  have before : D.gates.length≤C.gates.length := by
    rw [r.split]; change (pre++g::post').length ≤ _
    simp; omega
  have reduced : Reduced 10 D.gates D.output := (red.retimed clean before same
    (show ∃ x y : Input, vl C.gates x C.output ≠ vl C.gates y C.output from by
      refine ⟨fun _ => false,fun _ => true,?_⟩
      have eval : ∀ x : Input,vl C.gates x C.output=edge x := cand.2.2
      rw [eval,eval]; decide +kernel)).1
  have candidate : Candidate D := ⟨legal,before.trans cand.2.1,fun x => (same x).trans (cand.2.2 x)⟩
  have roster : Roster D pre post' g := ⟨rfl,r.inv,fun q hq => by
    rcases List.mem_append.mp hq with hp|ht
    · exact r.pos q (List.mem_append_left _ hp)
    · exact positive q ht⟩
  have sufficient : 7≤D.gates.countP countsAnd := by
    change 7≤(pre++g::post').countP countsAnd
    rw [r.split] at seven
    simp only [List.countP_append,List.countP_cons] at seven ⊢
    omega
  exact upper_cold_impossible roster candidate sufficient reduced cold
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.rewritten_clamp_impossible
