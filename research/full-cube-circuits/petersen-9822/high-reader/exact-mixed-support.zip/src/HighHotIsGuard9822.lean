import HighOnlyHotWires9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
theorem high_hot_implies_guard {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    ∀i,vl C.gates (SignedClamp.singleton s) i=true →
      ∀x : Input,vl C.gates x i=true → innerValue pre g x=true := by
  let row := SignedClamp.singleton s
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have hot := hot_guard cut s upper
  obtain ⟨A,ap,sa,dom,only⟩ := only_socket_hot r cand red seven s sl su upper
  have site : C.gates[pre.length]?=some g := by simp [r.split]
  rcases red.clean pre.length g site with ⟨_,h,hb,pin⟩|⟨op,_⟩
  · have read (x : Input) : innerValue pre g x=vl C.gates x h := by
      rw [visible r h hb x]
      simp [innerValue,pin]
    have hA : h=A := by
      rcases only h ((read _).symm.trans hot) with e|e
      · obtain ⟨x,off,_,on⟩ := independent_witness r cand seven s
        rw [read,e,vl_input _ _ _ s.isLt,off] at on
        contradiction
      · exact e
    intro i hi x xi
    rw [read,hA]
    rcases only i hi with e|e
    · rw [e,vl_input _ _ _ s.isLt] at xi
      exact dom x xi
    · exact e ▸ xi
  · rcases op with a|o <;> simp_all [r.inv]
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.high_hot_implies_guard
