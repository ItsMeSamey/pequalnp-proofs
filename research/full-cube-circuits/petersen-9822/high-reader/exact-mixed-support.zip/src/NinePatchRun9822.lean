import NinePatchStep9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean NinePatch

theorem patched_run {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output)
    (f : Nat → Nat) (ch : NineChoice C pre post g f)
    (ands : ∀ q∈post,10+pre.length∈q.inputs → q.op=.and)
    (x : Input) (c : Bool)
    (compat : ∀ j,AtPartner post (10+pre.length) j →
      (c && vl C.gates x (f j)) = (vl C.gates x (10+pre.length) && vl C.gates x j))
    (pos : C.output<10+C.gates.length) (notOut : C.output ≠ 10+pre.length) :
    outerValue pre (post.map (patch (10+pre.length) f)) C.output x c = vl C.gates x C.output := by
  let z := 10+pre.length
  let old := vl C.gates x
  let G := replaced old z c
  let w := wiresFrom pre (List.ofFn x) ++ [c]
  have len : w.length=z+1 := by simp [w,z,length_wiresFrom]
  have go := aligned_run (post.map (patch z f)) w G (patch_bank r x c)
  have ports (k : Nat) (q : Gate) (hq : post[k]?=some q) :
      CleanGate (w.length+k) (patch z f q) := by
    obtain ⟨loc,_⟩ := post_gate_info r red hq
    have lt : w.length+k=10+(pre.length+(k+1)) := by dsimp [z] at len;omega
    rw [lt]
    exact patch_clean f ch.earlier (red.clean _ _ loc)
  have readAt (k : Nat) (q : Gate) (hq : (post.map (patch z f))[k]?=some q) :
      ∃ p,post[k]?=some p ∧ q=patch z f p := by
    rw [List.getElem?_map] at hq
    cases h : post[k]? with
    | none => simp [h] at hq
    | some p => exact ⟨p,rfl,(by simpa [h] using hq : patch z f p=q).symm⟩
  have legal (k : Nat) (q : Gate) (hq : (post.map (patch z f))[k]?=some q) :
      ∀ j∈q.inputs,j<w.length+k := by
    obtain ⟨p,h,rfl⟩ := readAt k q hq
    exact (ports k p h).lt
  have steps (k : Nat) (gate : Gate) (hg : (post.map (patch z f))[k]?=some gate) :
      gate.op.eval (gate.inputs.map G) = G (w.length+k) := by
    obtain ⟨q,hq,rfl⟩ := readAt k gate hg
    obtain ⟨loc,a,b,ins,_,_⟩ := post_gate_info r red hq
    have mem := List.mem_iff_getElem?.mpr ⟨k,hq⟩
    have eq := eval_step (f:=f) (F:=old) (G:=G) (z:=z) ins
      (fun j ne => by simp [G,replaced,ne]) (ands q mem) (by
        intro j order
        have active : AtPartner post z j := ⟨q,mem,order⟩
        have skip := ch.plain j active
        simpa [G,replaced,skip,old,z] using compat j active)
    rw [eq]
    have idx : w.length+k=10+(pre.length+(k+1)) := by dsimp [z] at len;omega
    have nz : w.length+k≠z := by omega
    change _ = (if w.length+k=z then c else old (w.length+k))
    rw [if_neg nz,idx]
    exact (vl_gate C.gates red.clean x _ q loc).symm
  have bound : C.output<w.length+(post.map (patch z f)).length := by
    rw [r.split] at pos
    simp only [List.length_append,List.length_cons] at pos
    simp only [List.length_map]
    dsimp [z] at len
    omega
  have result := go legal steps C.output bound
  simpa only [outerValue,G,replaced,notOut,ite_false,old,w,z] using result
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
