import NineDirectAnd9822
import NinePatchSyntax9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean

def AtPartner (t : List Gate) (z j : Nat) := ∃ q∈t,q.inputs=[z,j] ∨ q.inputs=[j,z]

theorem actual_not_value {C pre post g} (r : Roster C pre post g) (x : Input) :
    vl C.gates x (10+pre.length) = !(innerValue pre g x) := by
  unfold vl;rw [r.split,wiresFrom_append]
  let w := wiresFrom pre (List.ofFn x)
  have len : w.length=10+pre.length := by simp [w,length_wiresFrom]
  change (wiresFrom post (w++[_])).getD (10+pre.length) false=_
  rw [←len,getD_wiresFrom _ _ _ (by simp),getD_snoc_eq,r.inv]
  rfl

theorem contact_not_alias {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output)
    {j : Nat} (ct : AtPartner post (10+pre.length) j)
    (ands : ∀ q∈post,10+pre.length∈q.inputs → q.op=.and) :
    ¬ ∀ x : Input, (!(innerValue pre g x) && vl C.gates x j)= !(innerValue pre g x) := by
  intro same
  obtain ⟨q,mem,order⟩ := ct
  obtain ⟨k,atq⟩ := List.mem_iff_getElem?.mp mem
  have location : C.gates[pre.length+(k+1)]?=some q := by
    rw [r.split,List.getElem?_append_right (by omega)];simpa using atq
  have op := ands q mem (by rcases order with h|h <;> simp [h])
  apply red.noAlias (pre.length+(k+1)) (List.getElem?_eq_some_iff.mp location).1 (10+pre.length) (by omega)
  intro x
  rw [vl_gate _ red.clean x _ _ location,op,actual_not_value r]
  rcases order with h|h <;> rw [h] <;>
    simpa only [List.map_cons,List.map_nil,GateOp.eval,List.all_cons,List.all_nil,id_eq,Bool.and_true,Bool.true_and,actual_not_value r,Bool.and_comm] using same x

structure NineChoice (C : Circuit) (pre post : List Gate) (g : Gate) (f : Nat → Nat) : Prop where
  earlier : ∀ j, f j≤j
  plain : ∀ j, AtPartner post (10+pre.length) j → f j≠10+pre.length
  cold : ∀ j, AtPartner post (10+pre.length) j → vl C.gates (SignedClamp.singleton 9) (f j)=false
  agrees : ∀ j, AtPartner post (10+pre.length) j → ∀ x : Input,
    (!(innerValue pre g x) && vl C.gates x j) = (!(innerValue pre g x) && vl C.gates x (f j))

theorem choose_contacts {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output)
    (ands : ∀ q∈post,10+pre.length∈q.inputs → q.op=.and)
    (witness : ∀ j, AtPartner post (10+pre.length) j → vl C.gates (SignedClamp.singleton 9) j=true →
      ∃ k, k<j ∧ vl C.gates (SignedClamp.singleton 9) k=false ∧ ∀ x : Input,
        (!(innerValue pre g x) && vl C.gates x j)=(!(innerValue pre g x) && vl C.gates x k)) :
    ∃ f, NineChoice C pre post g f := by
  classical
  have all (j : Nat) : ∃ k, k≤j ∧ (AtPartner post (10+pre.length) j →
      vl C.gates (SignedClamp.singleton 9) k=false ∧ ∀ x : Input,
        (!(innerValue pre g x) && vl C.gates x j)=(!(innerValue pre g x) && vl C.gates x k)) := by
    by_cases ct : AtPartner post (10+pre.length) j
    · cases h : vl C.gates (SignedClamp.singleton 9) j with
      | false => exact ⟨j,le_rfl,fun _ => ⟨h,fun _ => rfl⟩⟩
      | true =>
        obtain ⟨k,lt,cold,eq⟩ := witness j ct h
        exact ⟨k,lt.le,fun _ => ⟨cold,eq⟩⟩
    · exact ⟨j,le_rfl,fun h => (ct h).elim⟩
  choose f le facts using all
  refine ⟨f,le,?_,fun j ct => (facts j ct).1,fun j ct => (facts j ct).2⟩
  intro j ct eq
  apply contact_not_alias r red ct ands
  intro x
  have h := (facts j ct).2 x
  rw [eq,actual_not_value r,Bool.and_self] at h
  exact h
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
