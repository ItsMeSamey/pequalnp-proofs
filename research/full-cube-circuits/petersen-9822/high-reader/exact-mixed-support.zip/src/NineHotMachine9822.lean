import PhysicalNormalBundle9822
import NineHotProgram9822
import NineHotSites9822
import NineHotMeet9822
import NineHotBudget9822
import NineFirstSocket9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr SignedClamp NonrawSupport
open LowHotElimination PEqualNP.Outside.L_meta_9822.Clean GuardTags
open Research.NineHotContacts Research.NineHotSites

def liveTable (C : Circuit) : Table Input where
  wire := fun i x => vl C.gates x i
  test := SignedClamp.singleton 9
  raw := 9
  hot := by rw [vl_input _ _ _ (by decide)]; rfl

def liveSites (C : Circuit) := sites C.gates (List.ofFn (SignedClamp.singleton 9))

theorem guard_wire {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output) :
    ∃ h<10+pre.length, (∀ x : Input,vl C.gates x h = innerValue pre g x) ∧
      ∀ x : Input, vl C.gates x (10+pre.length) = !(innerValue pre g x) := by
  have idx : C.gates[pre.length]?=some g := by rw [r.split]; simp
  rcases red.shape idx with ⟨_,h,hlt,ins⟩|⟨op,_⟩
  · have ev (x : Input) : vl C.gates x h = innerValue pre g x := by
      rw [visible r h hlt]; simp [innerValue,ins]
    refine ⟨h,hlt,ev,fun x => ?_⟩
    rw [vl_gate C.gates red.clean x _ g idx,ins,r.inv,←ev]
    rfl
  · rcases op with e|e <;> simp_all [r.inv]

theorem live_sites_card {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (other : ∀ j : Fin 10,j≠9 → innerValue pre g (SignedClamp.singleton j)=false)
    (hot : innerValue pre g (SignedClamp.singleton 9)=true) :
    (liveSites C).card ≤ 2 := by
  rw [liveSites,card,r.split,physicalHot_append]
  let w := List.ofFn (SignedClamp.singleton 9)
  have off : g.op.eval (g.inputs.map fun j => (wiresFrom pre w).getD j false)=false := by
    rw [r.inv]; change (!(innerValue pre g (SignedClamp.singleton 9)))=false; simp [hot]
  have flag : CircuitCompiler.orFlag g=false := by simp [CircuitCompiler.orFlag,r.inv]
  change physicalHot pre w + (physicalHot post (wiresFrom pre w ++ [_]) + _) ≤ 2
  rw [off]
  simpa [flag,w] using physical_nine_hot_budget r cand red seven other

theorem live_site_mem {C : Circuit} {k : Nat} {q : Gate} (atK : C.gates[k]?=some q)
    (op : q.op=.or) (hot : (liveTable C).Hot (10+k)) : 10+k∈liveSites C := by
  apply (by simpa [liveSites] using (mem (List.ofFn (SignedClamp.singleton 9)) atK
    (by simp [CircuitCompiler.orFlag,op]) (by simpa [Table.Hot,liveTable,vl] using hot)) : 10+k∈liveSites C)

theorem live_raw {C : Circuit} {j : Nat} (lt : j<10) (hot : (liveTable C).Hot j) : j=9 := by
  change vl C.gates (SignedClamp.singleton 9) j=true at hot
  rw [vl_input _ _ _ lt] at hot
  have h : (⟨j,lt⟩ : Fin 10)=9 := by simpa [SignedClamp.singleton] using hot
  exact congrArg Fin.val h

theorem live_program {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output)
    (guardOn : innerValue pre g (SignedClamp.singleton 9)=true) (j : Nat) (bound : j<10+C.gates.length)
    (hot : (liveTable C).Hot j) :
    j=9 ∨ (liveTable C).MeetAt j ∨ (j∈liveSites C ∧ (liveTable C).JoinAt j) := by
  by_cases raw : j<10
  · exact Or.inl (live_raw raw hot)
  let k := j-10
  have kj : 10+k=j := by dsimp [k]; omega
  have ks : k<C.gates.length := by omega
  let q := C.gates[k]'ks
  have atK : C.gates[k]?=some q := List.getElem?_eq_getElem ks
  have ev (x : Input) := vl_gate C.gates red.clean x k q atK
  rw [←kj] at hot ⊢
  have val : vl C.gates (SignedClamp.singleton 9) (10+k)=true := hot
  rcases red.shape atK with ⟨neg,_⟩|⟨op,u,v,ub,vb,_,ins⟩
  · have m : q∈C.gates := List.mem_iff_getElem?.mpr ⟨k,atK⟩
    rw [r.split] at m
    have eq : k=pre.length := by
      by_contra ne
      have positive : q∈pre ++ post := by
        by_cases before : k<pre.length
        · apply List.mem_append_left; apply List.mem_iff_getElem?.mpr
          exact ⟨k,by simpa [r.split,List.getElem?_append_left before] using atK⟩
        · apply List.mem_append_right; apply List.mem_iff_getElem?.mpr
          refine ⟨k-(pre.length+1),?_⟩
          rw [r.split,show pre++g::post=(pre++[g])++post by simp,List.getElem?_append_right (by simp; omega)] at atK
          simpa using atK
      rcases r.pos _ positive with e|e <;> simp_all
    obtain ⟨_,_,_,zz⟩ := guard_wire r red
    rw [eq,zz,guardOn] at val
    contradiction
  · rcases op with op|op
    · refine Or.inr (Or.inl ⟨u,ub,v,vb,?_,?_,?_⟩)
      · have := ev (SignedClamp.singleton 9); rw [op,ins] at this
        exact (show vl C.gates (SignedClamp.singleton 9) u=true ∧ _ from by simpa [this,GateOp.eval] using val).1
      · have := ev (SignedClamp.singleton 9); rw [op,ins] at this
        exact (show _ ∧ vl C.gates (SignedClamp.singleton 9) v=true from by simpa [this,GateOp.eval] using val).2
      · intro x; simpa [liveTable,op,ins,GateOp.eval] using ev x
    · exact Or.inr (Or.inr ⟨live_site_mem atK op hot,u,ub,v,vb,fun x => by
        simpa [liveTable,op,ins,GateOp.eval] using ev x⟩)
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
