import UpperColdPhysical9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp NonrawSupport OuterNet
open PEqualNP.Outside.L_meta_9822.Clean FreeAndNet
def topGate : Gate := ⟨.and,[]⟩
def hotReaderCircuit (pre mid tail : List Gate) (out : Nat) : Circuit :=
  ⟨pre ++ topGate :: (mid ++ topGate :: tail),out⟩

theorem or_hot_reader_eval (pre mid tail : List Gate) (q : Gate)
    (op : q.op=.or) (hit : 10+pre.length∈q.inputs) (out : Nat) (x : Input) :
    (hotReaderCircuit pre mid tail out).eval (List.ofFn x) =
      outerValue pre (mid++q::tail) out x true := by
  let w := wiresFrom pre (List.ofFn x)
  let v := wiresFrom mid (w++[true])
  have len : w.length = 10+pre.length := by simp [w,length_wiresFrom]
  have idx : v.getD (10+pre.length) false=true := by
    change (wiresFrom mid (w++[true])).getD _ false=true
    rw [getD_wiresFrom mid _ _ (by simp [len])]
    exact getD_snoc_len _ _ _ _ len
  have hq : q.op.eval (q.inputs.map fun i => v.getD i false)=true := by
    simp only [op,GateOp.eval,List.any_map,Function.comp_def,id_eq,List.any_eq_true]
    exact ⟨_,hit,idx⟩
  change (wiresFrom (pre ++ topGate :: (mid ++ topGate :: tail)) _).getD out false = _
  rw [wiresFrom_append]
  change (wiresFrom (mid ++ topGate :: tail) (w++[true])).getD out false =
    (wiresFrom (mid ++ q :: tail) (w++[true])).getD out false
  rw [wiresFrom_append,wiresFrom_append]
  change (wiresFrom tail (v++[true])).getD out false =
    (wiresFrom tail (v++[q.op.eval (q.inputs.map fun i => v.getD i false)])).getD out false
  rw [hq]

theorem or_reader_model {C pre mid tail g q} (r : Roster C pre (mid++q::tail) g)
    (cand : Candidate C) (seven : 7≤C.gates.countP countsAnd)
    (op : q.op=.or) (hit : 10+pre.length∈q.inputs) :
    ∃ t : Net (Fin 10), t.cost≤8 ∧ ∀ x, t.eval x=outerValue pre (mid++q::tail) C.output x true := by
  let D := hotReaderCircuit pre mid tail C.output
  have mono : Monotone2 D := by
    intro a ha
    have before : ∀ a∈pre++(mid++q::tail), PositiveOp a ∧ a.inputs.length≤2 := by
      intro h hh
      exact ⟨r.pos h hh,(cand.1 h (by rw [r.split]; simp only [List.mem_append,List.mem_cons] at hh ⊢; tauto)).2⟩
    change a∈pre++topGate::(mid++topGate::tail) at ha
    simp only [List.mem_append,List.mem_cons] at ha
    have top : (topGate.op∈({GateOp.and,GateOp.or}:Set GateOp)) ∧ topGate.inputs.length≤2 := ⟨Or.inl rfl,by decide⟩
    rcases ha with h | rfl | h | rfl | h
    · exact before _ (by simp [h])
    · exact top
    · exact before _ (by simp [h])
    · exact top
    · exact before _ (by simp [h])
  refine ⟨CircuitCompiler.compile 10 D,?_,fun x => (CircuitCompiler.compile_eval _ _ mono x).trans
    (or_hot_reader_eval pre mid tail q op hit _ x)⟩
  have cap := or_cap r cand seven
  have pay := CircuitCompiler.compile_cost 10 D
  rw [r.split] at cap
  simp [D,hotReaderCircuit,topGate,CircuitCompiler.orFlag,op,r.inv,List.filter_append] at cap pay
  dsimp [D,hotReaderCircuit,topGate]
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.or_reader_model
