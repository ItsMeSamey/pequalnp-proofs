import NineHotPhysical9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport
open LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
theorem hot_reader_replacement {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (other : ∀ i : Fin 10,i≠9 → innerValue pre g (SignedClamp.singleton i)=false)
    {q : Gate} (mem : q∈post) (andOp : q.op=.and) {j : Nat}
    (ins : q.inputs=[10+pre.length,j] ∨ q.inputs=[j,10+pre.length])
    (on : vl C.gates (SignedClamp.singleton 9) j=true) :
    ∃ k<j, vl C.gates (SignedClamp.singleton 9) k=false ∧ ∀ x : Input,
      (!innerValue pre g x && vl C.gates x j)=(!innerValue pre g x && vl C.gates x k) := by
  have memC : q∈C.gates := by rw [r.split]; exact List.mem_append_right _ (List.mem_cons_of_mem _ mem)
  obtain ⟨idx,qi⟩ := List.mem_iff_getElem?.mp memC
  have il := (List.getElem?_eq_some_iff.mp qi).1
  have ji : j∈q.inputs := by rcases ins with ins|ins <;> simp [ins]
  have jlt := (red.clean idx q qi).lt j ji
  rcases actual_hot_contact r cand red seven other j (by omega) on with zero|yes
  · exfalso
    apply red.noConstant idx il false
    obtain ⟨_,_,_,neg⟩ := guard_wire r red
    intro x
    rw [vl_gate C.gates red.clean x idx q qi,andOp]
    rcases ins with ins|ins <;> simpa [ins,GateOp.eval,neg,Bool.and_comm] using zero x
  · exact yes
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.hot_reader_replacement
