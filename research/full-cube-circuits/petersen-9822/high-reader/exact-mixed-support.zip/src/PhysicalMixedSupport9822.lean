import PhysicalNineSupports9822
import NinePhysicalExclusion9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet SignedClamp NonrawSupport
open PEqualNP.Outside.L_meta_9822.Clean

theorem exact_mixed_support {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7 ≤ C.gates.countP countsAnd) :
    C.gates.countP countsAnd = 7 ∧ (C.gates.filter CircuitCompiler.orFlag).length = 9 ∧
    outerValue pre post C.output (SignedClamp.singleton 9) true = true ∧
    ∃ i : Fin 10, 5 ≤ i.val ∧ i.val ≤ 8 ∧
       ∀ j : Fin 10, innerValue pre g (SignedClamp.singleton j) = true ↔ j = i ∨ j = 9 := by
  obtain ⟨a, o, upper, bare | mixed⟩ := remaining_nine_supports r cand red seven
  · obtain ⟨j, ne, hot⟩ := physical_hot_away_nine r cand red seven
    exact (ne ((bare j).mp hot)).elim
  · exact ⟨a, o, upper, mixed⟩
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.exact_mixed_support
