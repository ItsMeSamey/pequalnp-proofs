import SoleHotClampFloor9822
import MixedHotReaderNet9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport OuterNet FreeAndNet Research.OddOr
open Research.OddOr.Envelope Research.OddOr.Graph9822
theorem no_singleton_support_or_reader {C pre mid tail g q} (r : Roster C pre (mid++q::tail) g)
    (cand : Candidate C) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10)
    (other : ∀ j : Fin 10, j≠s → innerValue pre g (SignedClamp.singleton j)=false)
    (op : q.op=.or) (hit : 10+pre.length∈q.inputs) : False := by
  obtain ⟨u,cap,read⟩ := or_reader_model r cand seven op hit
  have cut := physical_cut_split cand r.split r.inv (fun a ha => r.pos a (List.mem_append_right _ ha))
  have cold (j : Fin 10) (sj : s≠j) : sees u {j}=false := by
    have eq : inputOn {j} = SignedClamp.singleton j := by funext k; simp [inputOn,SignedClamp.singleton]
    change u.eval (inputOn {j})=false
    rw [eq,read]
    have on := cut.computes (SignedClamp.singleton j)
    rw [other j (Ne.symm sj)] at on
    exact on.trans (singleton_zero j)
  have edges (i j : Fin 10) (e : f {i,j}=true) : sees u {i,j}=true := by
    change u.eval (inputOn {i,j})=true
    rw [read]
    exact positive_upper cut _ e
  have lower := sole_hot_clamp_floor s u cold edges
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.no_singleton_support_or_reader
