import MixedNineEnvelope9822
namespace Research.OddOr.Envelope
open FreeAndNet Graph9822

theorem sole_hot_clamp_floor (i : V) (t : Net V)
    (cold : ∀ j : V, i≠j → sees t {j}=false)
    (edges : ∀ a b : V, f {a,b}=true → sees t {a,b}=true) : 9 ≤ t.cost := by
  obtain ⟨j,edgej⟩ := data.neighbor i
  have ne : i≠j := by
    rintro rfl
    simp [data.singleton] at edgej
  obtain ⟨a,b,ha,hb,yes⟩ := data.avoiding i
  have used := positive_hit t (cold j ne) (edges _ _ edgej)
    (avoids_output t (i:=i) (z:={a,b}) (by simp [ha,hb]) (edges _ _ yes))
  have fit : ColdOff i (pin i t) := by
    refine ⟨fun j miss => ?_,fun a b ma mb yes => ?_⟩
    · rw [pin_sees _ _ _ (by simpa using miss)]
      exact cold _ miss
    · rw [pin_sees _ _ _ (by simp [ma,mb])]
      exact edges _ _ yes
  have floor := eight_off i _ fit
  have pay := pin_cost i t
  omega
end Research.OddOr.Envelope
#print axioms Research.OddOr.Envelope.sole_hot_clamp_floor
