import NineHotMachine9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr SignedClamp NonrawSupport
open LowHotElimination PEqualNP.Outside.L_meta_9822.Clean GuardTags
open Research.NineHotContacts

theorem actual_hot_contact {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (other : ∀ i : Fin 10,i≠9 → innerValue pre g (SignedClamp.singleton i)=false)
    (j : Nat) (hj : j<10+C.gates.length) (jon : vl C.gates (SignedClamp.singleton 9) j=true) :
    (∀ x : Input, (!innerValue pre g x && vl C.gates x j)=false) ∨
    ∃ k<j, vl C.gates (SignedClamp.singleton 9) k=false ∧ ∀ x : Input,
      (!innerValue pre g x && vl C.gates x j)=(!innerValue pre g x && vl C.gates x k) := by
  let t := liveTable C
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have guardOn := hot_guard cut 9 (upper_hot_nine r cand seven red other)
  obtain ⟨h,hb,read,_⟩ := guard_wire r red
  obtain ⟨m,q,p,mp,atM,op,pb,_,arm,pc,_⟩ := first_hot_socket r cand seven red 9 guardOn
  have idx : C.gates[m]?=some q := by rw [r.split,List.getElem?_append_left mp]; exact atM
  have ev (x : Input) := vl_gate C.gates red.clean x m q idx
  have f (x : Input) : t.wire (10+m) x = (t.wire t.raw x || t.wire p x) := by
    rcases arm with arm|arm <;> simpa [t,liveTable,op,arm,GateOp.eval,Bool.or_comm] using ev x
  have aHot : t.Hot (10+m) := by change t.wire _ t.test=true; rw [f,t.hot]; rfl
  have nonraw : t.wire h ≠ t.wire t.raw := by
    intro eq
    obtain ⟨v,off,_,on⟩ := independent_witness r cand seven 9
    have e := congrFun eq v
    change vl C.gates v h=vl C.gates v 9 at e
    rw [read,vl_input _ _ _ (by decide),on] at e
    exact Bool.noConfusion (e.trans off)
  have distinct (k : Nat) (ks : k<10+C.gates.length) (_ : t.JoinAt k)
      (hot : t.Hot k) (nr : k ≠ t.raw) (i : Nat) (ik : i<k) : t.wire k ≠ t.wire i := by
    have bound : 10≤k := by
      by_contra! lt; exact nr (live_raw lt hot)
    intro eq
    apply red.noAlias (k-10) (by omega) i (by omega)
    intro x
    rw [show 10+(k-10)=k by omega]
    exact congrFun eq x
  have hlt : h<10+C.gates.length := by rw [r.split]; simp; omega
  have hh : t.Hot h := (read _).trans guardOn
  have witness := t.program_contact f pb pc (live_site_mem idx op aHot)
    (live_sites_card r cand red seven other guardOn) (fun k ks hot => live_program r red guardOn k ks hot)
    distinct hlt hh nonraw hj jon
  change (∀ x : Input, (!vl C.gates x h && vl C.gates x j)=false) ∨ _ at witness
  simpa only [t,liveTable,read] using witness
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.actual_hot_contact
