import PhysicalHotSupports9822
import AcceptedHighSpread9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet SignedClamp NonrawSupport
open PEqualNP.Outside.L_meta_9822.Clean

theorem remaining_nine_supports {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7 ≤ C.gates.countP countsAnd) :
    C.gates.countP countsAnd = 7 ∧ (C.gates.filter CircuitCompiler.orFlag).length = 9 ∧
    outerValue pre post C.output (SignedClamp.singleton 9) true = true ∧
    ((∀ j : Fin 10, innerValue pre g (SignedClamp.singleton j) = true ↔ j = 9) ∨
     ∃ i : Fin 10, 5 ≤ i.val ∧ i.val ≤ 8 ∧
       ∀ j : Fin 10, innerValue pre g (SignedClamp.singleton j) = true ↔ j = i ∨ j = 9) := by
  obtain ⟨eq, ors, supp⟩ := remaining_hot_supports r cand red seven
  obtain ⟨upper, hot⟩ := full_upper_nine r cand red eq
  refine ⟨eq, ors, upper, ?_⟩
  rcases supp with nine | ⟨i, lo, hi, solo | pair⟩
  · exact Or.inl nine
  · have e := (solo 9).mp hot
    subst i
    exact ((by decide : ¬(9 : Fin 10).val ≤ 8) hi).elim
  · exact Or.inr ⟨i, lo, hi, pair⟩
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.remaining_nine_supports
