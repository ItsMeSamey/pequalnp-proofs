import PhysicalHotTrace9822
namespace Research.NineHotContacts
inductive Signal | raw | first | second | meet deriving DecidableEq, Repr
inductive Guard | first | second | meet deriving DecidableEq, Repr
def read (r a b : Bool) : Signal → Bool
  | .raw => r | .first => a | .second => b | .meet => a && b
def guard (a b : Bool) : Guard → Bool
  | .first => a | .second => b | .meet => a && b
inductive Repair | zero | coldA | coldB deriving DecidableEq, Repr
def repair (h : Guard) (t : Signal) : Repair :=
  match h,t with
  | .first,.second | .meet,.second => .coldB
  | .second,.first | .meet,.first => .coldA
  | _,_ => .zero
def replacement (p q : Bool) : Repair → Bool
  | .zero => false | .coldA => p | .coldB => q
theorem all_rows : ∀ (linked r p q : Bool) (h : Guard) (t : Signal),
    let a := r || p
    let b := (if linked then a else r) || q
    (!(guard a b h) && read r a b t) =
      (!(guard a b h) && replacement p q (repair h t)) := by
  intro linked r p q h t
  cases h <;> cases t <;> revert linked r p q <;> decide +kernel
end Research.NineHotContacts
#print axioms Research.NineHotContacts.all_rows
