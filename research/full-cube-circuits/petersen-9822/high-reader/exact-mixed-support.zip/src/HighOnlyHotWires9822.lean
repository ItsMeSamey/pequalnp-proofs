import AcceptedHighBudget9822
import PrivateQuiet9822
import AbsorbingAnd9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean GuardTags Research.NineHotSites
theorem only_socket_hot {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    ∃A : Nat, A<10+pre.length ∧ s.val<A ∧
      (∀x : Input,x s=true → vl C.gates x A=true) ∧
      ∀i,vl C.gates (SignedClamp.singleton s) i=true → i=s.val ∨ i=A := by
  classical
  let row := SignedClamp.singleton s
  let w := List.ofFn row
  have cut := physical_cut_split cand r.split r.inv (fun q h => r.pos q (List.mem_append_right _ h))
  have hs := hot_guard cut s upper
  obtain ⟨k,q,b,kp,site,o,_,_,pins,_,_⟩ := first_hot_socket r cand seven red s hs
  have atq : C.gates[k]?=some q := by rw [r.split,List.getElem?_append_left kp];exact site
  let A := 10+k
  have dom (x : Input) (raw : x s=true) : vl C.gates x A=true := by
    have rf : vl C.gates x s.val=true := (vl_input _ _ _ s.isLt).trans raw
    rw [show A=10+k from rfl,vl_gate _ red.clean _ _ _ atq]
    rcases pins with pi|pi <;> simp [pi,o,GateOp.eval,rf]
  have card : (sites C.gates w).card≤1 := (Research.NineHotSites.card _ _).le.trans (accepted_high_physical r cand red seven s sl su upper)
  have contains : A∈sites C.gates w := by
    have raw := dom row (by simp [row,SignedClamp.singleton])
    have bit : (wiresFrom C.gates w).getD (w.length+k) false=true := by simpa [w,List.length_ofFn,A,vl] using raw
    simpa [w,A] using (Research.NineHotSites.mem w atq (by simp [CircuitCompiler.orFlag,o]) bit)
  have onlyOR (l : Nat) (u : Gate) (atU : C.gates[l]?=some u) (op : u.op=.or) (val : vl C.gates row (10+l)=true) : 10+l=A := by
    have bit : (wiresFrom C.gates w).getD (w.length+l) false=true := by simpa [w,List.length_ofFn,vl] using val
    have hot : 10+l∈sites C.gates w := by simpa [w] using (Research.NineHotSites.mem w atU (by simp [CircuitCompiler.orFlag,op]) bit)
    exact Finset.card_le_one.mp card _ hot _ contains
  refine ⟨A,by dsimp [A];omega,by dsimp [A];omega,dom,?_⟩
  intro i
  induction i using Nat.strong_induction_on with
  | ind i prev =>
    intro on
    by_cases lt : i<10
    · have val := (vl_input C.gates row i lt).symm.trans on
      exact Or.inl (congrArg Fin.val (by simpa [row,SignedClamp.singleton] using val : (⟨i,lt⟩ : Fin 10)=s))
    let l := i-10
    have id : i=10+l := by dsimp [l];omega
    have range : l<C.gates.length := by
      by_contra! bad
      have eq : vl C.gates row i=false := List.getD_eq_default _ _ (by rw [length_wiresFrom,List.length_ofFn];omega)
      exact Bool.noConfusion (eq.symm.trans on)
    let u := C.gates[l]
    have atU : C.gates[l]?=some u := List.getElem?_eq_getElem range
    have up : vl C.gates row (10+l)=true := id ▸ on
    rcases red.clean l u atU with ⟨inv,_⟩|⟨h,a,b,al,bl,ins⟩
    · have here : l=pre.length := by
        by_contra unequal
        have m : u∈pre++post := by
          rw [r.split] at atU
          by_cases before : l<pre.length
          · apply List.mem_append_left; exact List.mem_iff_getElem?.mpr ⟨l,by simpa [List.getElem?_append,before] using atU⟩
          · apply List.mem_append_right
            obtain ⟨d,e⟩ : ∃d,l=pre.length+(d+1) := ⟨l-pre.length-1,by omega⟩
            exact List.mem_iff_getElem?.mpr ⟨d,by simpa [e,List.getElem?_append] using atU⟩
        rcases r.pos u m with e|e <;> simp_all
      have off : vl C.gates row (10+pre.length)=false := by
        unfold vl;rw [r.split,wiresFrom_append];let k := wiresFrom pre (List.ofFn row)
        have len : k.length=10+pre.length := by simp [k,length_wiresFrom]
        change (wiresFrom post (k++[_])).getD (10+pre.length) false=false
        rw [←len,getD_wiresFrom _ _ _ (by simp),getD_snoc_eq,r.inv]
        change (!(innerValue pre g row))=false
        rw [hs];rfl
      exact Bool.noConfusion (off.symm.trans (here ▸ up))
    · rcases h with aop|orp
      · have ab := Deletion.distinct_and_pins red l u atU aop a b ins
        have val := up
        rw [vl_gate _ red.clean _ _ _ atU,aop,ins] at val
        have both : vl C.gates row a=true ∧ vl C.gates row b=true := by simpa [GateOp.eval] using val
        have na := no_absorbing_product red u atU aop a b ab (by simp [ins]) (by simp [ins])
        have nb := no_absorbing_product red u atU aop b a ab.symm (by simp [ins]) (by simp [ins])
        have imp : ∀x : Input,vl C.gates x s.val=true → vl C.gates x A=true := fun x e => dom x ((vl_input _ _ _ s.isLt).symm.trans e)
        rcases prev a (by omega) both.1 with ha|ha <;> rcases prev b (by omega) both.2 with hb|hb
        · omega
        · exact (na (by simpa only [ha,hb] using imp)).elim
        · exact (nb (by simpa only [ha,hb] using imp)).elim
        · omega
      · exact Or.inr (id.trans (onlyOR l u atU orp up))
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.only_socket_hot
