import MixedNineFaceFloors9822

namespace Research.OddOr.Envelope
open FreeAndNet Graph9822
def partner (s : V) : V := if s=5 then 0 else if s=6 then 1 else if s=7 then 2 else 3

theorem mixed_nine_envelope (s : V) (high : s∈([5,6,7,8] : List V)) (t : Net V)
    (cold : ∀ i : V, i≠s → i≠9 → sees t {i} = false)
    (edges : ∀ i j : V, f {i,j} = true → sees t {i,j} = true) :
    (if s=6 ∨ s=7 then 9 else 8) ≤ t.cost := by
  have facts : ∀ a : V, a∈([5,6,7,8] : List V) →
      partner a≠a ∧ partner a≠9 ∧ a≠9 ∧ (4:V)≠a ∧ (0:V)≠a ∧ f {a,partner a}=true :=
    by decide +kernel
  obtain ⟨pd,pn,sn,fs,zs,se⟩ := facts _ high
  have live : sees t {0,4} = true := edges 0 4 (by decide +kernel)
  have hitS := positive_hit t (cold _ pd pn) (edges _ _ se)
    (avoids_output t (i:=s) (by simp [Ne.symm zs,Ne.symm fs]) live)
  let u := pin s t
  have keep (S : Finset V) (off : s∉S) : sees u S = sees t S := pin_sees _ _ _ off
  have hitN := positive_hit u (j:=4) (i:=9)
    ((keep _ (by simp [Ne.symm fs])).trans (cold 4 fs (by decide)))
    ((keep _ (by simp [sn,Ne.symm fs])).trans (edges 9 4 (by decide +kernel)))
    (avoids_output u (i:=9) (by decide) ((keep _ (by simp [Ne.symm zs,Ne.symm fs])).trans live))
  let w := pin 9 u
  have same (S : Finset V) (offS : s∉S) (offN : (9:V)∉S) : sees w S = sees t S :=
    (pin_sees 9 u S offN).trans (keep S offS)
  have neq {i : V} (hi : i∈outsideNine s) : i≠s ∧ i≠9 := by simpa [outsideNine] using hi
  have fit : Fits (fun i j => f {i,j} = true) (outsideNine s) w := by
    constructor
    · intro i hi
      obtain ⟨is,ine⟩ := neq hi
      rw [same _ (by simp [Ne.symm is]) (by simp [Ne.symm ine])]
      exact cold i is ine
    · intro i hi j hj e
      obtain ⟨is,ine⟩ := neq hi
      obtain ⟨js,jn⟩ := neq hj
      rw [same _ (by simp [Ne.symm is,Ne.symm js]) (by simp [Ne.symm ine,Ne.symm jn])]
      exact edges i j e
  have base := mixed_face_floor s high w fit
  have ds : u.cost + hits s t ≤ t.cost := pin_cost _ _
  have dn : w.cost + hits 9 u ≤ u.cost := pin_cost _ _
  split at base <;> rename_i h <;> simp [h] <;> omega

end Research.OddOr.Envelope
#print axioms Research.OddOr.Envelope.mixed_nine_envelope
