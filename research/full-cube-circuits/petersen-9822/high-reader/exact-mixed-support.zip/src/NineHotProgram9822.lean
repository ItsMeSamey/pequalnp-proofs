import NineHotRepair9822
namespace Research.NineHotContacts.Table
variable {X : Type} (w : Table X)
def MeetAt (j : Nat) := ∃ u<j, ∃ v<j, w.Hot u ∧ w.Hot v ∧
  ∀ x, w.wire j x = (w.wire u x && w.wire v x)
def JoinAt (j : Nat) := ∃ u<j, ∃ v<j,
  ∀ x, w.wire j x = (w.wire u x || w.wire v x)

theorem join_form {A B p : Nat} (first : ∀ x,w.wire A x=(w.wire w.raw x || w.wire p x))
    (before : ∀ j<B,w.Hot j → w.wire j=w.wire w.raw ∨ w.wire j=w.wire A)
    (on : w.Hot B) (join : w.JoinAt B)
    (distinct : ∀ k<B,w.wire B ≠ w.wire k) :
    ∃ q<B, w.wire q w.test=false ∧ ∃ linked : Bool, ∀ x,
      w.wire B x=((if linked then w.wire A x else w.wire w.raw x) || w.wire q x) := by
  obtain ⟨u,ub,v,vb,ev⟩ := join
  have orient (l k : Nat) (lb : l<B) (kb : k<B) (lh : w.Hot l)
      (e : ∀ x,w.wire B x=(w.wire l x || w.wire k x)) :
      ∃ q<B, w.wire q w.test=false ∧ ∃ linked : Bool, ∀ x,
        w.wire B x=((if linked then w.wire A x else w.wire w.raw x) || w.wire q x) := by
    by_cases kh : w.Hot k
    · exfalso
      rcases before l lb lh with lr|la <;> rcases before k kb kh with kr|ka
      · apply distinct l lb; funext x; simp [e,lr,kr]
      · apply distinct k kb; funext x; rw [e,lr,ka,first]; cases w.wire w.raw x <;> simp
      · apply distinct l lb; funext x; rw [e,la,kr,first]; cases w.wire w.raw x <;> simp
      · apply distinct l lb; funext x; simp [e,la,ka]
    · refine ⟨k,kb,by simpa [Hot] using kh,?_⟩
      rcases before l lb lh with lr|la
      · exact ⟨false,fun x => by simpa [lr] using e x⟩
      · exact ⟨true,fun x => by simpa [la] using e x⟩
  have choose : w.Hot u ∨ w.Hot v := by simpa [Hot,ev] using on
  rcases choose with uh|vh
  · exact orient u v ub vb uh ev
  · exact orient v u vb ub vh (fun x => (ev x).trans (Bool.or_comm _ _))

theorem only_two {S : Finset Nat} {A B j : Nat} (size : S.card≤2)
    (a : A∈S) (b : B∈S) (jmem : j∈S) (ab : A≠B) : j=A ∨ j=B := by
  by_contra! bad
  have sub : ({j,A,B} : Finset Nat) ⊆ S := by simpa [Finset.insert_subset_iff] using And.intro jmem (And.intro a b)
  have c := Finset.card_le_card sub
  simp [bad.1,bad.2,ab] at c
  omega

theorem program_contact {stop A p h j : Nat} {S : Finset Nat}
    (first : ∀ x,w.wire A x=(w.wire w.raw x || w.wire p x))
    (pa : p<A) (pc : w.wire p w.test=false) (a : A∈S) (size : S.card≤2)
    (prog : ∀ k<stop,w.Hot k → k=w.raw ∨ w.MeetAt k ∨ (k∈S ∧ w.JoinAt k))
    (distinct : ∀ k<stop,w.JoinAt k → w.Hot k → k≠w.raw → ∀ i<k,w.wire k ≠ w.wire i)
    (hh : h<stop) (hon : w.Hot h) (nonraw : w.wire h ≠ w.wire w.raw)
    (hj : j<stop) (jon : w.Hot j) :
    (∀ x, (!w.wire h x && w.wire j x)=false) ∨
    ∃ k<j, w.wire k w.test=false ∧ ∀ x, (!w.wire h x && w.wire j x)=(!w.wire h x && w.wire k x) := by
  classical
  by_cases ex : ∃ B<stop, B≠w.raw ∧ B≠A ∧ w.Hot B ∧ B∈S ∧ w.JoinAt B
  · obtain ⟨B,bs,br,ba,bh,bmem,bjoin⟩ := ex
    have before (k : Nat) (kb : k<B) (hot : w.Hot k) : k=w.raw ∨ k=A ∨ w.MeetAt k := by
      rcases prog k (by omega) hot with eq|m|⟨s,_⟩
      · exact Or.inl eq
      · exact Or.inr (Or.inr m)
      · rcases only_two size a bmem s ba.symm with e|e
        · exact Or.inr (Or.inl e)
        · omega
    obtain ⟨q,qb,qc,linked,second⟩ := w.join_form first
      (fun k kb hot => w.one_before first before k kb hot) bh bjoin (distinct B bs bjoin bh br)
    apply w.contact first second pa qb pc qc _ hh hon nonraw hj jon
    intro k ks hot
    rcases prog k ks hot with eq|m|⟨s,_⟩
    · exact Or.inl eq
    · exact Or.inr (Or.inr (Or.inr m))
    · rcases only_two size a bmem s ba.symm with e|e
      · exact Or.inr (Or.inl e)
      · exact Or.inr (Or.inr (Or.inl e))
  · apply w.contact first (B:=A) (linked:=false) (q:=p) first pa pa pc pc _ hh hon nonraw hj jon
    intro k ks hot
    rcases prog k ks hot with eq|m|⟨s,jo⟩
    · exact Or.inl eq
    · exact Or.inr (Or.inr (Or.inr m))
    · by_cases kr : k=w.raw
      · exact Or.inl kr
      · have ka : k=A := by by_contra ne; exact ex ⟨k,ks,kr,ne,hot,s,jo⟩
        exact Or.inr (Or.inl ka)
end Research.NineHotContacts.Table
#print axioms Research.NineHotContacts.Table.program_contact
