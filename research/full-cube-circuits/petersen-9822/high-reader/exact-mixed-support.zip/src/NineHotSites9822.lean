import CutHotTrace9822
namespace Research.NineHotSites
open PEqualNP.Outside.L_meta_9822.Clean PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean.GuardTags FreeAndNet.CircuitCompiler

def sites : List Gate → List Bool → Finset Nat
  | [],_ => ∅
  | g::gs,w =>
    let y := g.op.eval (g.inputs.map fun j => w.getD j false)
    let tail := sites gs (w++[y])
    if orFlag g && y then insert w.length tail else tail

theorem lower {gs w i} (h : i ∈ sites gs w) : w.length ≤ i := by
  induction gs generalizing w with
  | nil => simp [sites] at h
  | cons g gs ih =>
    simp only [sites] at h
    split at h
    · rcases Finset.mem_insert.mp h with rfl|ht
      · exact le_rfl
      · have l := ih ht; simp at l; omega
    · have l := ih h; simp at l; omega

theorem card (gs : List Gate) (w : List Bool) : (sites gs w).card = physicalHot gs w := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih =>
    simp only [sites,physicalHot]
    generalize g.op.eval (g.inputs.map fun j => w.getD j false) = y
    have fresh : w.length ∉ sites gs (w++[y]) := by
      intro h; have l := lower h; simp at l
    cases h : orFlag g && y <;> simp [h,fresh,ih]

theorem mem {gs : List Gate} (w : List Bool) {k : Nat} {q : Gate}
    (atK : gs[k]?=some q) (flag : orFlag q=true)
    (on : (wiresFrom gs w).getD (w.length+k) false=true) :
    w.length+k ∈ sites gs w := by
  induction gs generalizing w k with
  | nil => simp at atK
  | cons g gs ih =>
    let y := g.op.eval (g.inputs.map fun j => w.getD j false)
    change (wiresFrom gs (w++[y])).getD (w.length+k) false=true at on
    cases k with
    | zero =>
      have eq : g=q := by simpa using atK
      subst q
      simp only [Nat.add_zero] at on ⊢
      rw [getD_wiresFrom _ _ _ (by simp),getD_snoc_eq] at on
      change w.length ∈ if orFlag g && y then insert _ _ else _
      simp [flag,on]
    | succ k =>
      have hk : gs[k]?=some q := by simpa using atK
      have idx : (w++[y]).length+k=w.length+(k+1) := by simp; omega
      have ht := ih (w++[y]) hk (idx.symm ▸ on)
      rw [idx] at ht
      change _ ∈ if orFlag g && y then insert _ _ else _
      split
      · exact Finset.mem_insert_of_mem ht
      · exact ht
end Research.NineHotSites
#print axioms Research.NineHotSites.mem
