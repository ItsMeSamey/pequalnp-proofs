import SignedDirectCube9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open Research.Graph9822Profiles Research.Graph9822Resolution

theorem at_most_five {R : Nat → Word → Prop} {aux : List Nat → Bool} (rows : CatalogueRows R aux)
    (D : Finset Vertex) (axis : Vertex → Axis) (sign : Axis → Bool)
    (signed : ∀ v∈D,∀ w,R v.val w → w (axis v)=sign (axis v))
    (unique : Set.InjOn axis (↑D : Set Vertex)) (k : Axis) (b : Bool) (bound : ∀ w : Word,R 10 w → w k=b) :
    D.card≤5 := by
  classical
  let spare := D.filter (fun v => axis v=k)
  let rest := D.filter (fun v => axis v≠k ∨ (!b)≠sign (axis v))
  have one : spare.card≤1 := Finset.card_le_one.mpr (by
    intro u hu v hv
    obtain ⟨ud,ue⟩ := Finset.mem_filter.mp hu
    obtain ⟨vd,ve⟩ := Finset.mem_filter.mp hv
    exact unique ud vd (ue.trans ve.symm))
  have sub : D⊆spare∪rest := by
    intro x hx
    by_cases e : axis x=k
    · exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨hx,e⟩)
    · exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨hx,Or.inl e⟩)
  have four : rest.card≤4 := half_signed_card rows D axis sign signed k b bound
  have a := Finset.card_le_card sub
  have z := Finset.card_union_le spare rest
  omega

theorem direct_axes_distinct {R : Nat → Word → Prop} (D : Finset Vertex)
    (ax : Vertex → Axis) (choice : Vertex → Bool) (ray : Axis → Bool → Word → Prop)
    (actual : ∀ v∈D,∀ w,R v.val w ↔ ray (ax v) (choice v) w)
    (half : ∀ i c w,ray i c w → w i=c)
    (apart : ∀ u∈D,∀ v∈D,u≠v → ∃ w,R u.val w ∧ ¬R v.val w)
    (meet : ∀ u∈D,∀ v∈D,u≠v → ∃ w,R u.val w ∧ R v.val w) :
    Set.InjOn ax (↑D : Set Vertex) := by
  intro u hu v hv eq
  by_contra ne
  obtain ⟨w,a,b⟩ := meet u hu v hv ne
  have x := half _ _ w ((actual _ hu _).mp a)
  have y := half _ _ w ((actual _ hv _).mp b)
  rw [eq] at x
  have conf := x.symm.trans y
  obtain ⟨f,af,bf⟩ := apart u hu v hv ne
  apply bf
  apply (actual _ hv _).mpr
  simpa only [eq,conf] using (actual _ hu _).mp af
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.at_most_five
