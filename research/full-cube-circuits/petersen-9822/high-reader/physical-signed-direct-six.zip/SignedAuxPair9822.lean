import SignedAuxAncestors9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open Research.Graph9822Profiles Research.Graph9822Resolution
private def farPair (a b : Fin 10) : Finset (Fin 10) := Finset.univ.filter fun j =>
  onSet [a.val,j.val]=false ∧ onSet [b.val,j.val]=false
private theorem only_pair : ∀ a b : Fin 10,a≠b → 7≤(farPair a b).card →
   (a=0 ∧ b=3) ∨ (a=3 ∧ b=0) := by decide +kernel

theorem six_raw_pair_support {R : Nat → Word → Prop} {aux : List Nat → Bool}
    (rows : CatalogueRows R aux) (D : Finset (Fin 10)) (size : 6≤D.card)
    (P : List Nat) (small : ∀ i∈P,i<10) (inside : ∀ v∈D,v.val∈P)
    (pos : onSet P=true) (w : Word) (miss : ∀ i∈P,¬R i w)
    (a b : Fin 10) (ne : a≠b) (covers : ∀ t,R 10 t ↔ R a.val t ∨ R b.val t) :
    ((a=0 ∧ b=3) ∨ (a=3 ∧ b=0)) ∧
    (D={0,1,2,6,7,9} ∨ D={1,2,3,6,7,9}) := by
  classical
  obtain ⟨⟨_,zw⟩,neg⟩ := rows.missingPositive P small pos w miss
  obtain ⟨t,quiet,_⟩ := neg [] (by simp) (by decide +kernel)
  have sub (i : Fin 10) (h : i=a ∨ i=b) (v : Word) (y : R i.val v) : R 10 v := by
    rcases h with rfl|rfl
    · exact (covers v).mpr (Or.inl y)
    · exact (covers v).mpr (Or.inr y)
  obtain ⟨r,owner,hot⟩ : ∃ r : Fin 10,(r=a ∨ r=b) ∧ R r.val w := by
    rcases (covers w).mp zw with z|z
    · exact ⟨a,Or.inl rfl,z⟩
    · exact ⟨b,Or.inr rfl,z⟩
  have out : r∉D := fun d => miss _ (inside r d) hot
  have cold (i j : Fin 10) (h : i=a ∨ i=b) (mem : j∈insert r D) : onSet [i.val,j.val]=false := by
    cases e : onSet [i.val,j.val] with
    | false => rfl
    | true =>
      rcases Finset.mem_insert.mp mem with rfl|d
      · rcases rows.edge _ _ e t with y|y|z
        · exact False.elim (quiet (sub _ h _ y))
        · exact False.elim (quiet (sub _ owner _ y))
        · exact False.elim (quiet z)
      · exact False.elim (aux_ancestor_avoids rows P small pos w miss j i (inside j d) (sub _ h) e)
  have all : insert r D⊆farPair a b := fun j m => Finset.mem_filter.mpr
    ⟨Finset.mem_univ _,cold _ _ (Or.inl rfl) m,cold _ _ (Or.inr rfl) m⟩
  have length := Finset.card_le_card all
  rw [Finset.card_insert_of_notMem out] at length
  have pair := only_pair _ _ ne (by omega)
  refine ⟨pair,?_⟩
  have far : farPair a b={0,1,2,3,6,7,9} := by rcases pair with ⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide +kernel
  have incl : D ⊆ (farPair a b).erase r := by
    intro j m
    exact Finset.mem_erase.mpr ⟨fun e => out (e ▸ m),all (Finset.mem_insert_of_mem m)⟩
  rw [far] at incl
  have rr : r=0 ∨ r=3 := by rcases pair with ⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> tauto
  rcases rr with rfl|rfl
  · right
    rw [show ({0,1,2,3,6,7,9} : Finset (Fin 10)).erase 0={1,2,3,6,7,9} by decide] at incl
    exact Finset.eq_of_subset_of_card_le incl ((by decide : ({1,2,3,6,7,9} : Finset (Fin 10)).card=6) ▸ size)
  · left
    rw [show ({0,1,2,3,6,7,9} : Finset (Fin 10)).erase 3={0,1,2,6,7,9} by decide] at incl
    exact Finset.eq_of_subset_of_card_le incl ((by decide : ({0,1,2,6,7,9} : Finset (Fin 10)).card=6) ▸ size)
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.six_raw_pair_support
