import SignedDirectSix9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open PEqualNP.CircuitLowerBounds Research.Graph9822Profiles Research.Graph9822Profiles.OuterLive
open PEqualNP.Outside.L_meta_9822.Clean (outerCircuit)
open PEqualNP.Outside.L_meta_9822.OuterDirections Research.Graph9822Resolution
theorem physical_signed_half {pre post : List PEqualNP.CircuitLowerBounds.Gate} {g : PEqualNP.CircuitLowerBounds.Gate}
    {out rout : Nat} {gs : List DirGate} (basis : asCircuit gs rout=outerCircuit 10 pre post out)
    (cut : ComputesCut (innerValue pre g) (outerValue pre post out))
    (positive : ∀ q∈pre,PositiveOp q) (cap : gs.countP Research.Graph9822Resolution.Gate.isAnd≤6)
    (D : Finset Vertex) (ax : Vertex → Axis) (choice : Vertex → Bool) (ray : Axis → Bool → Word → Prop)
    (actual : ∀ v∈D,∀ w,actualReceiver gs rout cap v.val w ↔ ray (ax v) (choice v) w)
    (half : ∀ i c w,ray i c w → w i=c) (k : Axis) (b : Bool)
    (base : ∀ w,actualReceiver gs rout cap 10 w → w k=b) : D.card≤5 := by
  classical
  let R := actualReceiver gs rout cap
  obtain ⟨rooms,_,obs⟩ := sixteen_room gs rout cap (auxBit pre g)
    (auxBit_antitone positive g) (fun xs h => onSet_outer_eval basis cut xs h)
  have separate : ∀ u v : Vertex,u≠v → ∃ j : Fin 16,u.val∉independentSets j ∧ v.val∈independentSets j := by decide +kernel
  have together : ∀ u v : Vertex,∃ j : Fin 16,u.val∉independentSets j ∧ v.val∉independentSets j := by decide +kernel
  have inj : Set.InjOn ax (↑D : Set Vertex) := direct_axes_distinct D ax choice ray actual half
    (by
      intro u _ v _ ne
      obtain ⟨j,a,b⟩ := separate u v ne
      exact ⟨rooms j,(obs j u).mpr a,fun h => (obs j v).mp h b⟩)
    (by
      intro u _ v _ _
      obtain ⟨j,a,b⟩ := together u v
      exact ⟨rooms j,(obs j u).mpr a,(obs j v).mpr b⟩)
  let sign (i : Axis) := if h : ∃ v∈D, ax v=i then choice h.choose else false
  apply at_most_five (physicalCatalogueRows basis cut positive cap) D ax sign _ inj k b base
  intro v hv w hit
  have e : ∃ u∈D,ax u=ax v := ⟨v,hv,rfl⟩
  have same := inj e.choose_spec.1 hv e.choose_spec.2
  simpa [sign,dif_pos e,same] using half (ax v) (choice v) w ((actual _ hv _).mp hit)
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.physical_signed_half
