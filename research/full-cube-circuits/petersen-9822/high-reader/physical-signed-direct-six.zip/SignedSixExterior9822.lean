import SignedOccupiedAxes9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open Research.Graph9822Profiles Research.Graph9822Profiles.OuterLive Research.Graph9822Resolution
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.Outside.L_meta_9822.OuterDirections
private theorem cover_tags (D : Finset Vertex) (p : List (Axis × Mask)) (length : p.length≤D.card)
    (ax : Vertex → Axis) (A : Vertex → Mask)
    (distinct : Set.InjOn ax (↑D : Set Vertex)) (tag : ∀ v∈D,(ax v,A v)∈p) :
    ∀ i U,(i,U)∈p → ∃ v∈D,ax v=i ∧ A v=U := by
  classical
  let label := fun v => (ax v,A v)
  have inj : Set.InjOn label (↑D : Set Vertex) := fun x hx y hy eq => distinct hx hy (congrArg Prod.fst eq)
  have sub : D.image label⊆p.toFinset := by
    intro j h
    obtain ⟨v,mem,rfl⟩ := Finset.mem_image.mp h
    exact List.mem_toFinset.mpr (tag v mem)
  have eq : D.image label=p.toFinset := Finset.eq_of_subset_of_card_le sub (by
    rw [Finset.card_image_of_injOn inj]
    exact p.toFinset_card_le.trans length)
  intro i U iu
  have h : (i,U)∈D.image label := eq.symm ▸ List.mem_toFinset.mpr iu
  obtain ⟨v,vd,e⟩ := Finset.mem_image.mp h
  exact ⟨v,vd,congrArg Prod.fst e,congrArg Prod.snd e⟩

theorem six_exterior_independent {pre post : List PEqualNP.CircuitLowerBounds.Gate}
    {g : PEqualNP.CircuitLowerBounds.Gate} {out rout : Nat} {gs : List DirGate}
    (basis : asCircuit gs rout=outerCircuit 10 pre post out) (cut : ComputesCut (innerValue pre g) (outerValue pre post out))
    (positive : ∀ q∈pre,PositiveOp q) (cap : gs.countP Research.Graph9822Resolution.Gate.isAnd≤6)
    {bs lib : List Mask} {p : List (Axis × Mask)} {n : Nat} (scan : Scan bs lib p n)
    (length : p.length≤6) (member : ∀ v : Fin 11,{w | actualReceiver gs rout cap v.val w}∈lib)
    (D : Finset Vertex) (size : 6≤D.card) (ax : Vertex → Axis) (A : Vertex → Mask) (sign : Word)
    (distinct : Set.InjOn ax (↑D : Set Vertex)) (tag : ∀ v∈D,(ax v,A v)∈p)
    (direct : ∀ v∈D,{w | actualReceiver gs rout cap v.val w}=A v∩side (ax v) (sign (ax v))) :
    Independent Dᶜ := by
  apply physical_exterior_independent basis cut positive cap scan (fun v => member ⟨v.val,by omega⟩)
    D (by omega) ax sign _ _ (member 10)
  · intro v vd w hit
    have h : w∈A v∩side (ax v) (sign (ax v)) := direct v vd ▸ hit
    exact h.2
  · intro i U iu
    obtain ⟨v,vd,iv,av⟩ := cover_tags D p (length.trans size) ax A distinct tag i U iu
    exact ⟨v,vd,by simpa [iv,av] using direct v vd⟩
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.six_exterior_independent
