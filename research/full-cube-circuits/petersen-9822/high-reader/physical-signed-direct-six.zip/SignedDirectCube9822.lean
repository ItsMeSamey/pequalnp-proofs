import CompactSignedReceivers9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open Research.Graph9822Profiles Research.Graph9822Resolution
abbrev Vertex := Fin 10
def Independent (D : Finset Vertex) : Prop :=
  ∀ u∈D,∀ v∈D,onSet [u.val,v.val]≠true

/-- Direct masks may be proper subsets of their designated half. Every edge
among direct labels needs an endpoint whose designated sign agrees with an
axis forced by this zero subcube of the actual signed receiver. -/
theorem zero_cube {R : Nat → Word → Prop} {aux : List Nat → Bool} (rows : CatalogueRows R aux)
    (D : Finset Vertex) (axis : Vertex → Axis) (sign : Axis → Bool)
    (signed : ∀ v∈D,∀ w,R v.val w → w (axis v)=sign (axis v))
    (F : Finset Axis) (orientation : Axis → Bool)
    (quiet : ∀ w : Word,(∀ i∈F,w i=orientation i) → ¬R 10 w) :
    Independent (D.filter (fun v => axis v∉F ∨ orientation (axis v)≠sign (axis v))) := by
  let w : Word := fun i => if i∈F then orientation i else !(sign i)
  have noZ : ¬R 10 w := quiet w (fun i hi => by simp [w,hi])
  have missing (v : Vertex) (h : v∈D.filter (fun v => axis v∉F ∨ orientation (axis v)≠sign (axis v))) :
      ¬R v.val w := by
    obtain ⟨dv,avoid⟩ := Finset.mem_filter.mp h
    intro hit
    have eq := signed v dv w hit
    by_cases hf : axis v∈F
    · exact (avoid.resolve_left (fun nh => nh hf)) (by simpa [w,hf] using eq)
    · cases e : sign (axis v) <;> simp [w,hf,e] at eq
  intro a ha b hb ed
  exact (rows.edge a b ed w).elim (missing a ha) (fun h => h.elim (missing b hb) noZ)

theorem half_signed {R : Nat → Word → Prop} {aux : List Nat → Bool} (rows : CatalogueRows R aux)
    (D : Finset Vertex) (axis : Vertex → Axis) (sign : Axis → Bool)
    (signed : ∀ v∈D,∀ w,R v.val w → w (axis v)=sign (axis v))
    (k : Axis) (b : Bool) (bound : ∀ w : Word,R 10 w → w k=b) :
    Independent (D.filter (fun v => axis v≠k ∨ (!b)≠sign (axis v))) := by
  have h := zero_cube rows D axis sign signed {k} (fun _ => !b) (by
    intro w h hit
    have l := h k (Finset.mem_singleton_self k)
    have r := bound w hit
    cases b <;> simp_all)
  simpa using h

private theorem graph_cap (S : Finset Vertex) (h : Independent S) : S.card≤4 := by
  classical
  by_contra! more
  obtain ⟨T,sub,ct⟩ := Finset.exists_subset_card_eq (show 5≤S.card by omega)
  have adj : ∃ i∈T,∃ j∈T,onSet [i.val,j.val]=true := by
    have all : ∀ t : Finset Vertex,t.card=5 → ∃ i∈t,∃ j∈t,onSet [i.val,j.val]=true := by decide +kernel
    exact all T ct
  obtain ⟨i,hi,j,hj,e⟩ := adj
  exact h i (sub hi) j (sub hj) e

theorem half_signed_card {R : Nat → Word → Prop} {aux : List Nat → Bool} (rows : CatalogueRows R aux)
    (D : Finset Vertex) (axis : Vertex → Axis) (sign : Axis → Bool)
    (signed : ∀ v∈D,∀ w,R v.val w → w (axis v)=sign (axis v))
    (k : Axis) (b : Bool) (bound : ∀ w : Word,R 10 w → w k=b) :
    (D.filter (fun v => axis v≠k ∨ (!b)≠sign (axis v))).card≤4 :=
  graph_cap _ (half_signed rows D axis sign signed k b bound)
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.half_signed_card
