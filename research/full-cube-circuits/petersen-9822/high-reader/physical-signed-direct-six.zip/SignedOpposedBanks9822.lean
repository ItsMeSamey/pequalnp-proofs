import SignedRawDirect9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open Research.Graph9822Profiles Research.Graph9822Resolution
private theorem neighbor : ∀ r : Fin 10,∃ j : Fin 10,onSet [r.val,j.val]=true := by decide +kernel

/-- Every auxiliary ancestor is a direct raw whenever both classes have a
common omitted direction and the direct class contains an edge. -/
theorem no_exterior_ancestor {R : Nat → Word → Prop} {aux : List Nat → Bool}
    (rows : CatalogueRows R aux) (D : Finset Vertex) (P : List Nat)
    (small : ∀ i∈P,i<10) (inside : ∀ v∈D,v.val∈P) (pos : onSet P=true)
    (dark : Word) (miss : ∀ i∈P,¬R i dark)
    (bright : Word) (exterior : ∀ v : Vertex,v∉D → ¬R v.val bright)
    (r : Vertex) (sub : ∀ t,R r.val t → R 10 t) : r∈D := by
  by_contra absent
  obtain ⟨j,e⟩ := neighbor r
  have nj : j∉D := fun mem => aux_ancestor_avoids rows P small pos dark miss j r (inside j mem) sub e
  have cold : ∀ a∈[r.val,j.val],¬R a bright := by
    intro a m
    rcases (by simpa using m : a=r.val ∨ a=j.val) with rfl|rfl
    · exact exterior r absent
    · exact exterior j nj
  exact aux_ancestor_avoids rows [r.val,j.val] (by simp [r.isLt,j.isLt]) e bright cold j r (by simp) sub e

theorem raw_union_rejected {R : Nat → Word → Prop} {aux : List Nat → Bool}
    (rows : CatalogueRows R aux) (D X : Finset Vertex) (size : 5≤D.card)
    (ax : Vertex → Axis) (sign : Axis → Bool) (ray : ∀ v∈D,∀ w,R v.val w → w (ax v)=sign (ax v))
    (exterior : ∀ v : Vertex,v∉D → ¬R v.val sign)
    (z : ∀ w,R 10 w ↔ ∃ v∈X,R v.val w) : False := by
  obtain ⟨P,small,inside,pos,w,miss⟩ := direct_missing D size R ax sign ray
  obtain ⟨r,rx,rr⟩ := (z w).mp (rows.missingPositive P small pos w miss).1.2
  have rd := no_exterior_ancestor rows D P small inside pos w miss sign exterior r
    (fun t hit => (z t).mpr ⟨r,rx,hit⟩)
  exact miss r.val (inside r rd) rr
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.raw_union_rejected
