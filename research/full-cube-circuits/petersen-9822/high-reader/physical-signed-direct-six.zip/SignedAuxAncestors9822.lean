import CompactSignedReceivers9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open Research.Graph9822Profiles Research.Graph9822Resolution
/-- If a missed positive row contains v, no raw receiver wholly contained
in the actual auxiliary receiver can be adjacent to v. -/
theorem aux_ancestor_avoids {R : Nat → Word → Prop} {aux : List Nat → Bool}
    (rows : CatalogueRows R aux) (P : List Nat) (small : ∀ a∈P,a<10) (pos : onSet P=true)
    (w : Word) (miss : ∀ a∈P,¬R a w) (v r : Fin 10) (vin : v.val∈P)
    (sub : ∀ t,R r.val t → R 10 t) : onSet [r.val,v.val]≠true := by
  intro edge
  have singletonCold : ∀ j : Fin 10,onSet [j.val]=false := by decide +kernel
  obtain ⟨_,rooms⟩ := rows.missingPositive P small pos w miss
  obtain ⟨t,quiet,absent⟩ := rooms [v.val] (by simpa using vin) (singletonCold v)
  rcases rows.edge r v edge t with hr|hv|z
  · exact quiet (sub t hr)
  · exact absent v.val (by simp) hv
  · exact quiet z
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.aux_ancestor_avoids
