import AndAllFullPilot9822
import SignedAuxPair9822
import SignedRawUnion9822
import SignedDirectPhysical9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open Research.Graph9822Profiles Research.Graph9822Resolution
private def labels (D : Finset Vertex) : List Nat := ((List.finRange 10).filter fun i => i∈D).map Fin.val
private theorem positive_labels (D : Finset Vertex) (size : 5≤D.card) : onSet (labels D)=true := by
  classical
  by_contra off
  have all (x : Vertex) (hx : x∈D) : x.val∈labels D :=
    List.mem_map.mpr ⟨x,List.mem_filter.mpr ⟨List.mem_finRange _,by simpa using hx⟩,rfl⟩
  let N := (Dᶜ : Finset Vertex).toList
  have covered : ∀ e : Fin 13,(Research.Graph9822.StarData.ends e).1∈N ∨ (Research.Graph9822.StarData.ends e).2∈N := by
    intro e
    by_contra! no
    have h1 : (Research.Graph9822.StarData.ends e).1∈D := by simpa [N] using no.1
    have h2 : (Research.Graph9822.StarData.ends e).2∈D := by simpa [N] using no.2
    have p := all _ h1
    have q := all _ h2
    apply off
    unfold onSet PEqualNP.Outside.L_meta_9822.Sectors.edge
    simp only [Bool.or_eq_true,Bool.and_eq_true,decide_eq_true_eq]
    fin_cases e
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (⟨p,q⟩))))))))))))
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inr ⟨p,q⟩)))))))))))
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inr ⟨p,q⟩))))))))))
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inr ⟨p,q⟩)))))))))
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inr ⟨p,q⟩))))))))
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inr ⟨p,q⟩)))))))
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inr ⟨p,q⟩))))))
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inr ⟨p,q⟩)))))
    · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inr ⟨p,q⟩))))
    · exact Or.inl (Or.inl (Or.inl (Or.inr ⟨p,q⟩)))
    · exact Or.inl (Or.inl (Or.inr ⟨p,q⟩))
    · exact Or.inl (Or.inr ⟨p,q⟩)
    · exact Or.inr ⟨p,q⟩
  have six := Research.Graph9822.StarData.coverCost N covered
  have total : (Dᶜ : Finset Vertex).card+D.card=10 := by simpa using Finset.card_compl_add_card D
  change 6≤(Dᶜ : Finset Vertex).toList.length at six
  rw [Finset.length_toList] at six
  omega
theorem direct_missing (D : Finset Vertex) (size : 5≤D.card) (R : Nat → Word → Prop)
    (ax : Vertex → Axis) (sign : Axis → Bool) (ray : ∀ a∈D,∀ w,R a.val w → w (ax a)=sign (ax a)) :
    ∃ P : List Nat, (∀ i∈P,i<10) ∧ (∀ v∈D,v.val∈P) ∧ onSet P=true ∧ ∃w : Word,∀ i∈P,¬R i w := by
  refine ⟨labels D,?_,?_,positive_labels D size,fun i => !(sign i),?_⟩
  · intro j m
    obtain ⟨v,_,rfl⟩ := List.mem_map.mp m
    exact v.isLt
  · intro v h
    exact List.mem_map.mpr ⟨v,List.mem_filter.mpr ⟨List.mem_finRange _,by simpa using h⟩,rfl⟩
  · intro j m hit
    change j∈((List.finRange 10).filter (fun i => i∈D)).map Fin.val at m
    obtain ⟨v,mv,ev⟩ := List.mem_map.mp m
    subst j
    have vd : v∈D := by simpa using (List.mem_filter.mp mv).2
    have eq := ray v vd (fun i => !(sign i)) hit
    cases e : sign (ax v) <;> simp [e] at eq

theorem two_raw_terminal {R : Nat → Word → Prop} {aux : List Nat → Bool} (rows : CatalogueRows R aux)
    (D : Finset Vertex) (size : 6≤D.card)
    (ax : Vertex → Axis) (sign : Axis → Bool) (ray : ∀ v∈D,∀ w,R v.val w → w (ax v)=sign (ax v))
    (a b : Vertex) (ne : a≠b) (z : ∀ w,R 10 w ↔ R a.val w ∨ R b.val w) :
    ((a=0 ∧ b=3) ∨ (a=3 ∧ b=0)) ∧ (D={0,1,2,6,7,9} ∨ D={1,2,3,6,7,9}) := by
  obtain ⟨P,small,inside,pos,w,miss⟩ := direct_missing D (by omega) R ax sign ray
  exact six_raw_pair_support rows D size P small inside pos w miss a b ne z

theorem three_raw_terminal {R : Nat → Word → Prop} {aux : List Nat → Bool} (rows : CatalogueRows R aux)
    (D X : Finset Vertex) (size : 5≤D.card)
    (ax : Vertex → Axis) (sign : Axis → Bool) (ray : ∀ v∈D,∀ w,R v.val w → w (ax v)=sign (ax v))
    (z : ∀ w,R 10 w ↔ ∃ v∈X,R v.val w) (a b c : Vertex) (ha : a∈X) (hb : b∈X) (hc : c∈X)
    (ab : a≠b) (ac : a≠c) (bc : b≠c) : False := by
  obtain ⟨P,small,inside,pos,w,miss⟩ := direct_missing D size R ax sign ray
  exact impossible_three_raw_union rows D X size P small inside pos w miss z a b c ha hb hc ab ac bc
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.three_raw_terminal
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.two_raw_terminal
