import SignedFavorableBank9822
import SignedPhysicalBank9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open Research.Graph9822Profiles Research.Graph9822Profiles.OuterLive Research.Graph9822Resolution
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.Outside.L_meta_9822.OuterDirections
private theorem ray_tag {bs lib : List Mask} {p : List (Axis × Mask)} {n : Nat} (scan : Scan bs lib p n) :
    ∀ m∈bs,∃ i U c,(i,U)∈p ∧ m=U∩side i c := by
  induction scan with
  | start => simp
  | join _ _ _ ih => exact ih
  | @split bs lib p n U i h hu ih =>
    intro m hm
    rcases List.mem_cons.mp hm with rfl|tail
    · exact ⟨i,U,true,List.mem_cons_self,rfl⟩
    · rcases List.mem_cons.mp tail with rfl|old
      · exact ⟨i,U,false,List.mem_cons_self,rfl⟩
      · obtain ⟨j,F,c,mem,rfl⟩ := ih _ old
        exact ⟨j,F,c,List.mem_cons_of_mem _ mem,rfl⟩
theorem signed_occupied_terminal {pre post : List PEqualNP.CircuitLowerBounds.Gate}
    {g : PEqualNP.CircuitLowerBounds.Gate} {out rout : Nat} {gs : List DirGate}
    (basis : asCircuit gs rout=outerCircuit 10 pre post out) (cut : ComputesCut (innerValue pre g) (outerValue pre post out))
    (positive : ∀ q∈pre,PositiveOp q) (cap : gs.countP Research.Graph9822Resolution.Gate.isAnd≤6)
    {bs lib : List Mask} {p : List (Axis × Mask)} {n : Nat} (scan : Scan bs lib p n)
    (member : ∀ v : Vertex,{w | actualReceiver gs rout cap v.val w}∈lib)
    (D X : Finset Vertex) (size : 5≤D.card) (ax : Vertex → Axis) (sign : Word)
    (signed : ∀ v∈D,∀ w,actualReceiver gs rout cap v.val w → w (ax v)=sign (ax v))
    (saturated : ∀ i U,(i,U)∈p → ∃ v∈D,{w | actualReceiver gs rout cap v.val w}=U∩side i (sign i))
    (z : ∀ w,actualReceiver gs rout cap 10 w ↔ ∃ v∈X,actualReceiver gs rout cap v.val w) : False := by
  obtain ⟨rooms,_,obs⟩ := sixteen_room gs rout cap (auxBit pre g)
    (auxBit_antitone positive g) (fun xs h => onSet_outer_eval basis cut xs h)
  have proper : ∀ u : Vertex,∃ i : Fin 16,u.val∈independentSets i := by decide +kernel
  have separate : ∀ u v : Vertex,u≠v → ∃ j : Fin 16,u.val∉independentSets j ∧ v.val∈independentSets j := by decide +kernel
  apply bank_no_raw_union scan (physicalCatalogueRows basis cut positive cap) D X size ax sign signed member _ _ _ z
  · intro v
    obtain ⟨i,yes⟩ := proper v
    exact ⟨rooms i,fun h => (obs i v).mp h yes⟩
  · intro u v ne
    obtain ⟨j,a,b⟩ := separate u v ne
    exact ⟨rooms j,(obs j u).mpr a,fun h => (obs j v).mp h b⟩
  · intro m mem on
    obtain ⟨i,U,c,tag,rfl⟩ := ray_tag scan m mem
    have hc : sign i=c := on.2
    obtain ⟨v,dv,e⟩ := saturated i U tag
    exact ⟨v,dv,by simpa only [hc] using e.symm⟩
theorem physical_exterior_independent {pre post : List PEqualNP.CircuitLowerBounds.Gate}
    {g : PEqualNP.CircuitLowerBounds.Gate} {out rout : Nat} {gs : List DirGate}
    (basis : asCircuit gs rout=outerCircuit 10 pre post out) (cut : ComputesCut (innerValue pre g) (outerValue pre post out))
    (positive : ∀ q∈pre,PositiveOp q) (cap : gs.countP Research.Graph9822Resolution.Gate.isAnd≤6)
    {bs lib : List Mask} {p : List (Axis × Mask)} {n : Nat} (scan : Scan bs lib p n)
    (member : ∀ v : Vertex,{w | actualReceiver gs rout cap v.val w}∈lib)
    (D : Finset Vertex) (size : 5≤D.card) (ax : Vertex → Axis) (sign : Word)
    (signed : ∀ v∈D,∀ w,actualReceiver gs rout cap v.val w → w (ax v)=sign (ax v))
    (saturated : ∀ i U,(i,U)∈p → ∃ v∈D,{w | actualReceiver gs rout cap v.val w}=U∩side i (sign i))
    (zbank : {w | actualReceiver gs rout cap 10 w}∈lib) : Independent Dᶜ := by
  obtain ⟨rooms,_,obs⟩ := sixteen_room gs rout cap (auxBit pre g)
    (auxBit_antitone positive g) (fun xs h => onSet_outer_eval basis cut xs h)
  have proper : ∀ u : Vertex,∃ i : Fin 16,u.val∈independentSets i := by decide +kernel
  have separate : ∀ u v : Vertex,u≠v → ∃ j : Fin 16,u.val∉independentSets j ∧ v.val∈independentSets j := by decide +kernel
  apply exterior_independent scan (physicalCatalogueRows basis cut positive cap) D size ax sign signed member zbank
  · intro v
    obtain ⟨i,yes⟩ := proper v
    exact ⟨rooms i,fun h => (obs i v).mp h yes⟩
  · intro u v ne
    obtain ⟨j,a,b⟩ := separate u v ne
    exact ⟨rooms j,(obs j u).mpr a,fun h => (obs j v).mp h b⟩
  · intro m mem on
    obtain ⟨i,U,c,tag,rfl⟩ := ray_tag scan m mem
    have hc : sign i=c := on.2
    obtain ⟨v,dv,e⟩ := saturated i U tag
    exact ⟨v,dv,by simpa only [hc] using e.symm⟩
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.signed_occupied_terminal

#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.physical_exterior_independent
