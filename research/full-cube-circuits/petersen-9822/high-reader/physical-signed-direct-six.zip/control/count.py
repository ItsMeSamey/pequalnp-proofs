from itertools import combinations
from collections import Counter
edges = {(1,2),(3,4),(0,4),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(6,9),(6,8),(5,8)}
for size in (4,5,6):
    histogram = Counter()
    for chosen in combinations(range(10), size):
        histogram[sum(not any(a in chosen and b in chosen and v not in {a,b} for a,b in edges)
                      for v in chosen)] += 1
    print(size, sorted(histogram.items()))
survivors = [part for part in combinations(range(10),4) if not edges.intersection(combinations(part,2))]
assert len(survivors)==13
print('independent four-sets',survivors)
