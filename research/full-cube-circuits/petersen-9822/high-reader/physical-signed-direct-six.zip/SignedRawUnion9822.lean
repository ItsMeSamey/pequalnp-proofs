import SignedAuxAncestors9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open Research.Graph9822Profiles Research.Graph9822Resolution
private def outside3 (a b c : Fin 10) : Finset (Fin 10) := Finset.univ.filter fun j =>
  onSet [a.val,j.val]=false ∧ onSet [b.val,j.val]=false ∧ onSet [c.val,j.val]=false
private theorem outside_three : ∀ a b c : Fin 10,a≠b → a≠c → b≠c →
    (outside3 a b c).card≤5 := by decide +kernel

/-- A signed auxiliary made solely from raw masks cannot combine three
distinct raw masks if five or more jointly omitted raws include an edge. -/
theorem impossible_three_raw_union {R : Nat → Word → Prop} {aux : List Nat → Bool}
    (rows : CatalogueRows R aux) (D X : Finset (Fin 10)) (size : 5≤D.card)
    (P : List Nat) (small : ∀ i∈P,i<10) (inside : ∀ v∈D,v.val∈P)
    (pos : onSet P=true) (w : Word) (miss : ∀ i∈P,¬R i w)
    (covers : ∀ t,R 10 t ↔ ∃ r∈X,R r.val t)
    (a b c : Fin 10) (ax : a∈X) (bx : b∈X) (cx : c∈X)
    (ab : a≠b) (ac : a≠c) (bc : b≠c) : False := by
  classical
  have contained (i : Fin 10) (xi : i∈X) (t : Word) (hit : R i.val t) : R 10 t :=
    (covers t).mpr ⟨i,xi,hit⟩
  obtain ⟨⟨_,zw⟩,negative⟩ := rows.missingPositive P small pos w miss
  obtain ⟨y,zy,_⟩ := negative [] (by simp) (by decide +kernel)
  have cold (i : Fin 10) (xi : i∈X) (j : Fin 10) (mem : j∈D∪X) : onSet [i.val,j.val]=false := by
    cases e : onSet [i.val,j.val] with
    | false => rfl
    | true =>
      rcases Finset.mem_union.mp mem with jd|jx
      · exact False.elim (aux_ancestor_avoids rows P small pos w miss j i (inside j jd) (contained i xi) e)
      · rcases rows.edge i j e y with hi|hj|z
        · exact False.elim (zy (contained i xi y hi))
        · exact False.elim (zy (contained j jx y hj))
        · exact False.elim (zy z)
  have sub : D∪X⊆outside3 a b c := fun j hj => Finset.mem_filter.mpr
    ⟨Finset.mem_univ _,cold a ax j hj,cold b bx j hj,cold c cx j hj⟩
  have upper := (Finset.card_le_card sub).trans (outside_three a b c ab ac bc)
  have eq : D=D∪X := Finset.eq_of_subset_of_card_le Finset.subset_union_left (by omega)
  obtain ⟨r,rx,rw⟩ := (covers w).mp zw
  have rd : r∈D := by rw [eq];exact Finset.mem_union_right D rx
  exact miss _ (inside r rd) rw
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.impossible_three_raw_union
