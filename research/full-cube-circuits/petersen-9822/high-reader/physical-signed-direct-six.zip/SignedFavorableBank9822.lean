import SignedOpposedBanks9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open Research.Graph9822Profiles
private theorem leaf_witness (bs : List Mask) {m : Mask} (made : m∈bankPool bs)
    (w : Word) (on : w∈m) : ∃ p∈bs,w∈p ∧ p⊆m := by
  induction bs generalizing m with
  | nil => simp [bankPool] at made;subst m;exact False.elim on
  | cons p bs ih =>
    rcases List.mem_append.mp made with old|joined
    · obtain ⟨v,present,yes,le⟩ := ih old on
      exact ⟨v,List.mem_cons_of_mem _ present,yes,le⟩
    · obtain ⟨q,old,eq⟩ := List.mem_map.mp joined
      subst m
      rcases on with oq|op
      · obtain ⟨v,present,yes,le⟩ := ih old oq
        exact ⟨v,List.mem_cons_of_mem _ present,yes,fun j h => Or.inl (le h)⟩
      · exact ⟨p,List.mem_cons_self,op,fun j h => Or.inr h⟩

theorem favorable_missing {bs lib : List Mask} {p : List (Axis × Mask)} {n : Nat} (scan : Scan bs lib p n)
    (R : Nat → Word → Prop) (D : Finset Vertex) (sign : Word)
    (member : ∀ v : Vertex,{w | R v.val w}∈lib)
    (proper : ∀ v : Vertex,∃w,¬R v.val w)
    (different : ∀ u v : Vertex,u≠v → ∃w,R u.val w ∧ ¬R v.val w)
    (owned : ∀ b∈bs,sign∈b → ∃ v∈D, b={w | R v.val w}) :
    ∀ j : Vertex,j∉D → ¬R j.val sign := by
  intro j non hot
  rcases scan_pool scan _ (member j) with full|made
  · obtain ⟨w,miss⟩ := proper j
    exact miss (show w∈({w | R j.val w} : Mask) from full.symm ▸ Set.mem_univ w)
  · obtain ⟨b,src,on,le⟩ := leaf_witness bs made sign hot
    obtain ⟨u,ud,rfl⟩ := owned b src on
    have ne : u≠j := fun eq => non (eq ▸ ud)
    obtain ⟨w,yes,no⟩ := different u j ne
    exact no (le yes)

theorem bank_no_raw_union {bs lib : List Mask} {p : List (Axis × Mask)} {n : Nat} (scan : Scan bs lib p n)
    {R : Nat → Word → Prop} {aux : List Nat → Bool} (rows : CatalogueRows R aux)
    (D X : Finset Vertex) (size : 5≤D.card) (ax : Vertex → Axis) (sign : Word)
    (ray : ∀ v∈D,∀ w,R v.val w → w (ax v)=sign (ax v))
    (member : ∀ v : Vertex,{w | R v.val w}∈lib)
    (proper : ∀ v : Vertex,∃ w,¬R v.val w)
    (different : ∀ u v : Vertex,u≠v → ∃ w,R u.val w ∧ ¬R v.val w)
    (owned : ∀ b∈bs,sign∈b → ∃ v∈D,b={w | R v.val w})
    (z : ∀ w,R 10 w ↔ ∃ v∈X,R v.val w) : False :=
  raw_union_rejected rows D X size ax sign ray (favorable_missing scan R D sign member proper different owned) z
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.bank_no_raw_union
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open Research.Graph9822Profiles Research.Graph9822Resolution
theorem exterior_independent {bs lib : List Mask} {p : List (Axis × Mask)} {n : Nat} (scan : Scan bs lib p n)
    {R : Nat → Word → Prop} {aux : List Nat → Bool} (rows : CatalogueRows R aux)
    (D : Finset Vertex) (size : 5≤D.card) (ax : Vertex → Axis) (sign : Word)
    (ray : ∀ v∈D,∀ w,R v.val w → w (ax v)=sign (ax v))
    (member : ∀ v : Vertex,{w | R v.val w}∈lib)
    (zbank : {w | R 10 w}∈lib)
    (proper : ∀ v : Vertex,∃ w,¬R v.val w)
    (different : ∀ u v : Vertex,u≠v → ∃ w,R u.val w ∧ ¬R v.val w)
    (owned : ∀ b∈bs,sign∈b → ∃ v∈D,b={w | R v.val w}) : Independent Dᶜ := by
  classical
  obtain ⟨P,small,inside,pos,w,miss⟩ := direct_missing D size R ax sign ray
  obtain ⟨_,neg⟩ := rows.missingPositive P small pos w miss
  obtain ⟨t,quiet,_⟩ := neg [] (by simp) (by decide +kernel)
  have cold := favorable_missing scan R D sign member proper different owned
  intro u hu v hv ed
  have um : u∉D := Finset.mem_compl.mp hu
  have vm : v∉D := Finset.mem_compl.mp hv
  have hot : R 10 sign := ((rows.edge u v ed sign).resolve_left (cold u um)).resolve_left (cold v vm)
  rcases scan_pool scan _ zbank with full|made
  · exact quiet (show t∈({w | R 10 w} : Mask) from full.symm ▸ Set.mem_univ t)
  · obtain ⟨b,bmem,on,le⟩ := leaf_witness bs made sign hot
    obtain ⟨r,_,rfl⟩ := owned b bmem on
    have sub (x : Word) : R r.val x → R 10 x := fun hx => le hx
    obtain ⟨j,ej⟩ := (show ∀ r : Fin 10,∃ j : Fin 10,onSet [r.val,j.val]=true by decide +kernel) r
    by_cases jd : j∈D
    · exact aux_ancestor_avoids rows P small pos w miss j r (inside j jd) sub ej
    · let Q := [u.val,v.val,j.val]
      have positive : onSet Q=true := by
        have grow : ∀ a b c : Fin 10,onSet [a.val,b.val]=true → onSet [a.val,b.val,c.val]=true := by decide +kernel
        exact grow u v j ed
      have missing : ∀ a∈Q,¬R a sign := by
        intro a m
        rcases (by simpa [Q] using m : a=u.val ∨ a=v.val ∨ a=j.val) with rfl|rfl|rfl
        · exact cold u um
        · exact cold v vm
        · exact cold j jd
      exact aux_ancestor_avoids rows Q (by simp [Q,u.isLt,v.isLt,j.isLt]) positive sign missing j r (by simp [Q]) sub ej
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.exterior_independent
