import UpperColdPhysical9822
import OriginalHotBudget9822
import CutHotTrace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr
open SignedClamp NonrawSupport OuterNet LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
open GuardTags

theorem original_nine_hot_budget {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (other : ∀ j : Fin 10,j≠9 → innerValue pre g (SignedClamp.singleton j)=false) :
    hotCount (env (SignedClamp.singleton 9) false) (model pre post C.output) ≤ 2 := by
  have upper := upper_hot_nine r cand seven red other
  have existing := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have nine := hot_guard existing 9 upper
  let net := model pre post C.output
  let u := retire (openPin (9 : Fin 10)) net
  let k := specialize (close false) u
  have evalU (v : Input) (z : Bool) : u.eval (env v z) = outerValue pre post C.output (raise (9 : Fin 10) v) z := by
    change (retire _ _).eval _ = _
    rw [retire_eval,row_open,model_eval r cand]
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have affected (v : Input) (vs : v (9 : Fin 10)=true) : raise (9 : Fin 10) v=v := by
    funext j
    by_cases e : j=(9 : Fin 10) <;> simp [raise,e,vs]
  have zeroEval (v : Input) : u.eval (env v false)=edge (raise (9 : Fin 10) v) := by
    rw [evalU]
    have exactOn := cut.computes (raise (9 : Fin 10) v)
    have raised : innerValue pre g (raise 9 v)=true := by
      apply inner_mono_inputs (fun q hq => r.pos q (List.mem_append_left _ hq)) g _ nine
      intro j hj
      have eq : j=(9 : Fin 10) := by simpa [SignedClamp.singleton] using hj
      simp [raise,eq]
    simpa [raised] using exactOn
  have fit (S : Finset (Fin 10)) : sees k S = LowPositive.pos (9 : Fin 10) S := by
    let v : Input := fun j => decide (j∈S)
    change (specialize (close false) u).eval v = _
    rw [eval_specialize,close_eval,zeroEval]
    apply congrArg edge
    funext j
    by_cases e : j=(9 : Fin 10) <;> simp [raise,v,e]
  let v := SignedClamp.singleton 9
  have vs : v 9=true := by simp [v,SignedClamp.singleton]
  have up : u.eval (env v true)=true := by rw [evalU,affected v vs]; exact upper
  have down : u.eval (env v false)=false := by rw [zeroEval,affected v vs];exact singleton_zero 9
  have all : u.eval (env (fun _ => true) false) = true := by
    rw [zeroEval,affected _ rfl]
    rfl
  have noOut : ¬outUses (0 : Fin 11) u := by
    intro use
    have bad := outZeros u 0 use (env (fun _ => true) false) rfl
    rw [all] at bad
    exact Bool.noConfusion bad
  have hit : 0 < hits (0 : Fin 11) u := by
    by_contra! h
    have equal : u.eval (env v true)=u.eval (env v false) := by
      apply eval_congr_used
      intro j used
      exact Fin.cases (fun e => (e.elim (by omega) noOut).elim) (fun _ _ => rfl) j used
    rw [up,down] at equal
    exact Bool.noConfusion equal
  have charge := specialize_saves (0 : Fin 11) (close false) (by rfl) u
  change k.cost + hits (0 : Fin 11) u ≤ u.cost at charge
  have price := LowPositive.pin_price (9 : Fin 10) k fit
  have amount : LowPositive.pinPrice 9=6 := by decide +kernel
  have paid := retire_cost (openPin (9 : Fin 10)) net
  rw [open_floor] at paid
  change u.cost + hotCount (env (SignedClamp.singleton 9) false) net ≤ net.cost at paid
  have cap : net.cost ≤ 9 := (model_cost r).trans (or_cap r cand seven)
  change hotCount (env (SignedClamp.singleton 9) false) net ≤ 2
  omega

theorem physical_nine_hot_budget {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (other : ∀ j : Fin 10,j≠9 → innerValue pre g (SignedClamp.singleton j)=false) :
    physicalHot pre (List.ofFn (SignedClamp.singleton 9)) +
      physicalHot post (wiresFrom pre (List.ofFn (SignedClamp.singleton 9)) ++ [false]) ≤ 2 := by
  rw [←model_hot (r.split ▸ red) r.pos]
  exact original_nine_hot_budget r cand red seven other
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.physical_nine_hot_budget
