import ColdPhysicalExclusion9822
import UpperOffPrice9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport OuterNet FreeAndNet Research.OddOr
open PEqualNP.Outside.L_meta_9822.Clean
open Research.OddOr.Envelope
theorem coupled_upper_trace {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (cold : ∀ j,outerValue pre post C.output (SignedClamp.singleton j) true=false) :
    ∃ a : Nat, a < 10+pre.length ∧
      SameTrace (model pre post C.output) (model pre post a) ∧
      (∀ x z,(model pre post a).eval (env x z)=innerValue pre g x) ∧
      (∀ i : Fin 10, hits i.succ (model pre post C.output) ≤ 1 ∧
        ¬outUses i.succ (model pre post C.output) ∧ ¬outUses i.succ (model pre post a)) := by
  obtain ⟨v,_,_,hot⟩ := independent_witness r cand seven 0
  obtain ⟨a,bound,read⟩ := physical_guard_observer r cand hot
  refine ⟨a,bound,compile_trace _ _ _ _,read,?_⟩
  intro i
  refine ⟨upper_off_hits r cand seven i (fun j _ => cold j),cold_no_raw_output r cand i,?_⟩
  intro used
  obtain ⟨v,off,_,on⟩ := independent_witness r cand seven i
  have bad := outZeros _ _ used (env v false) (by simpa [env] using off)
  rw [read,on] at bad; contradiction
theorem upper_graph_contradiction {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (cold : ∀ j, outerValue pre post C.output (SignedClamp.singleton j) true=false)
    {a b t} (head : model pre post C.output = .gate a b t) (ap : 0 ∉ a) (bp : 0 ∉ b)
    (big : 2 ≤ (plainArm a ∪ plainArm b).card) : False := by
  classical
  have d := Graph9822.data
  have sep := obstruction_from_cofactors (neighborhood_three Graph9822.f d.cold d.singleton
    d.neighbor d.diff (crosses_of_walk _ d.walk d.spans d.steps)) d.edges d.hot d.cold d.meet
  obtain ⟨rx,hx,ry,hy,neq,rest,fb⟩ := sep _ _ big
  obtain ⟨x,_,rfl⟩ := List.mem_map.mp hx
  obtain ⟨y,_,rfl⟩ := List.mem_map.mp hy
  obtain ⟨idx,_,same,read,used⟩ := coupled_upper_trace r cand seven cold
  have tr := same
  rw [head] at tr
  have getTail {h : Net (Fin 11)} (s : SameTrace (.gate a b t) h) :
      ∃ u, h = .gate a b u := by cases s with | gate a b h => exact ⟨_,rfl⟩
  obtain ⟨u,hu⟩ := getTail tr
  have kEq (z : Bool) := paired_gate_eq a b t ap bp (fun i => head ▸ (used i).1)
    (fun i => head ▸ (used i).2.1) z rest fb
  have hEq := paired_gate_eq a b u ap bp (fun i => hu ▸ (trace_hits_eq same i.succ ▸ (used i).1))
    (fun i => hu ▸ (used i).2.2) true rest fb
  rw [←hu,read,read] at hEq
  have eq := kEq (!(innerValue pre g (inputOn x)))
  rw [←head,model_eval r cand,model_eval r cand] at eq
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  apply neq
  exact (cut.computes _).symm.trans (eq.trans (by rw [hEq,cut.computes]; rfl))

theorem upper_cold_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (reduced : Reduced 10 C.gates C.output)
    (cold : ∀ j,outerValue pre post C.output (SignedClamp.singleton j) true=false) : False := by
  obtain ⟨a,b,t,head,ap,bp⟩ := cold_first_plain r cand seven reduced
  exact upper_graph_contradiction r cand seven cold head ap bp
    (plain_big ap bp (upper_first_incomparable r cand seven cold head))

theorem upper_hot_nine {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (reduced : Reduced 10 C.gates C.output)
    (other : ∀ j : Fin 10, j≠9 → innerValue pre g (SignedClamp.singleton j)=false) :
    outerValue pre post C.output (SignedClamp.singleton 9) true=true := by
  cases e : outerValue pre post C.output (SignedClamp.singleton 9) true with
  | true => rfl
  | false =>
    exfalso; apply upper_cold_impossible r cand seven reduced
    intro j
    by_cases same : j=9
    · exact same ▸ e
    have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
    have yes := cut.computes (SignedClamp.singleton j)
    rw [other j same] at yes
    exact yes.trans (singleton_zero j)
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.upper_hot_nine
