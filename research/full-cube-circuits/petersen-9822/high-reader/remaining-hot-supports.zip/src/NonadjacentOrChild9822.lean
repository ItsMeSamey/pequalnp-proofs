import PairRisingGate9822
import ForcedOrStatus9822
import GateSiteIdentity9822
import NonadjacentPhysicalDebit9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
theorem no_or_child {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t : V) (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V))) (p tail : List Gate)
    (whole : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length])
    (ord : p.length<pre.length) (k l : Nat) (u v : Gate) (uk : C.gates[k]?=some u)
    (vl' : C.gates[l]?=some v) (uo : u.op=.or) (vo : v.op=.or)
    (upin : 10+pre.length∈u.inputs) (vp : 10+k∈v.inputs) : False := by
  classical
  let F := foldZero C {s,t}
  let marked := fun q : Gate => decide (q.op=.or ∧ ∃ j∈q.inputs,∃ b : Bool,F.1.getD j (Sum.inl false)=Sum.inl b)
  have st : s≠t := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  have us := neg_one_status s t p tail pre post g whole r.split unary r.inv ord
  have us' := next_one red.clean {s,t} k u uk uo ⟨_,upin,us⟩
  have vs' := next_one red.clean {s,t} l v vl' vo ⟨_,vp,us'⟩
  have hs := literal_zero_status s t p tail whole
  have hsite : C.gates[p.length]?=some (literalGate s t) := by simp [whole]
  obtain ⟨m,w,wm,wo,hit,wz,x,y,xf,xt,_,rise⟩ := pair_rising_gate r cand red s t st p tail whole unary
  have wone : F.1.getD (10+m) (Sum.inl false)≠Sum.inl true := by
    intro hot
    have ev := frozen_value C cand {s,t} _ true hot x
    have ex : masked {s,t} x=x := by
      funext i
      by_cases a : i=s <;> by_cases b : i=t <;> simp_all [masked]
    rw [ex] at ev
    exact Bool.noConfusion (rise.1.symm.trans ev)
  have ur := (red.clean k u uk).lt _ upin
  have vr := (red.clean l v vl').lt _ vp
  have same {i j : Nat} {a b : Gate} (ai : C.gates[i]?=some a) (bj : C.gates[j]?=some b)
      (e : a=b) : i=j := gate_site_identity red b (e ▸ ai) bj
  have hu : literalGate s t≠u := fun e => by have := same hsite uk e;omega
  have hv : literalGate s t≠v := fun e => by have := same hsite vl' e;omega
  have uv : u≠v := fun e => by have := same uk vl' e;omega
  have hw : literalGate s t≠w := fun e => wz ((same hsite wm e) ▸ hs)
  have uw : u≠w := fun e => wone ((same uk wm e) ▸ us')
  have vw : v≠w := fun e => wone ((same vl' wm e) ▸ vs')
  let A : Finset Gate := {literalGate s t,u,v,w}
  have card : A.card=4 := by simp [A,hu,hv,hw,uv,uw,vw]
  have lower : A⊆(C.gates.filter marked).toFinset := by
    intro q mem
    simp only [A,Finset.mem_insert,Finset.mem_singleton] at mem
    rcases mem with e|e|e|e <;> subst q
    · exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨List.mem_iff_getElem?.mpr ⟨_,hsite⟩,
        decide_eq_true ⟨rfl,s.val,by simp [literalGate],false,raw_zero_status C {s,t} s (by simp)⟩⟩)
    · exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨List.mem_iff_getElem?.mpr ⟨_,uk⟩,
        decide_eq_true ⟨uo,_,upin,true,us⟩⟩)
    · exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨List.mem_iff_getElem?.mpr ⟨_,vl'⟩,
        decide_eq_true ⟨vo,_,vp,true,us'⟩⟩)
    · obtain ⟨j,read,pin⟩ := hit
      exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨List.mem_iff_getElem?.mpr ⟨_,wm⟩,
        decide_eq_true ⟨wo,j,read,false,pin⟩⟩)
  have bound := (Finset.card_le_card lower).trans (List.toFinset_card_le _)
  rw [card,←List.countP_eq_length_filter] at bound
  apply four_or_folds_impossible C cand red.clean (or_cap r cand seven) s t shape marked bound
  · exact fun _ _ h => of_decide_eq_true h
  · intro q m no
    have eq : q=g := by
      by_contra ne
      rw [r.split] at m
      have pos := r.pos q (by simpa [List.mem_append,ne] using m)
      rcases pos with e|e <;> simp_all
    subst q
    exact ⟨10+p.length,by simp [unary],false,hs⟩
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.no_or_child
