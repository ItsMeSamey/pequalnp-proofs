import PairAndFace9822
import CleanCompile9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp
open PEqualNP.Outside.L_meta_9822.Clean
abbrev V := Fin 10
def masked (S : Finset V) (x : Input) : Input := fun j => if j∈S then false else x j
def assignments (S : Finset V) : List Stat :=
  List.ofFn fun i : V => if i∈S then Sum.inl false else Sum.inr i.val
def foldZero (C : Circuit) (S : Finset V) := elim 10 C.gates (assignments S,[])
theorem pin_inv (S : Finset V) (x : Input) :
    Inv 10 (List.ofFn x) (List.ofFn (masked S x)) (assignments S,[]) := by
  constructor
  · simp [assignments]
  · intro j
    by_cases h : j<10
    · let i : V := ⟨j,h⟩
      have old : (assignments S).getD j (Sum.inl false) =
          (if i∈S then Sum.inl false else Sum.inr i.val) := getD_ofFn 10 _ _ i
      have row := getD_ofFn 10 (masked S x) false i
      change _ ∧ ((assignments S).getD j (Sum.inl false)).val (List.ofFn x) = _
      rw [old,row]
      by_cases mem : i∈S
      · simp [mem,masked,Stat.val,Stat.Valid]
      · rw [if_neg mem]
        exact ⟨i.isLt,(getD_ofFn 10 x false i).trans (by simp [masked,mem])⟩
    · have a := List.getD_eq_default (assignments S) (Sum.inl false) (n:=j) (by simp [assignments]; omega)
      have b := List.getD_eq_default (List.ofFn (masked S x)) false (n:=j) (by simp; omega)
      change ((assignments S).getD j (Sum.inl false)).Valid 10 ∧ ((assignments S).getD j (Sum.inl false)).val (List.ofFn x) = (List.ofFn (masked S x)).getD j false
      rw [a,b]
      exact ⟨trivial,rfl⟩
theorem deleted_circuit (C : Circuit) (cand : Candidate C) (S : Finset V)
    (varied : ∃ x y : Input, edge (masked S x) ≠ edge (masked S y)) :
    ∃ o : Nat, let D : Circuit := ⟨(foldZero C S).2,o⟩
      FanInTwo D ∧ ∀ x : Input, D.eval (List.ofFn x) = edge (masked S x) := by
  let p := foldZero C S
  let out := p.1.getD C.output (Sum.inl false)
  have invariant (x : Input) : Inv 10 (List.ofFn x) (wiresFrom C.gates (List.ofFn (masked S x))) p :=
    inv_elim 10 _ (by simp) C.gates _ _ cand.1 (pin_inv S x)
  have read (x : Input) : out.val (wiresFrom p.2 (List.ofFn x)) = edge (masked S x) :=
    ((invariant x).2 C.output).2.trans (cand.2.2 (masked S x))
  have clean : CleanL 10 p.2 := clean_elim 10 (List.ofFn (fun _ : V => false)) (by simp)
    C.gates _ _ cand.1 (pin_inv S _) (by intro a g hg; simp at hg)
  cases ho : out with
  | inl b =>
    obtain ⟨x,y,ne⟩ := varied
    have hx := read x
    have hy := read y
    rw [ho] at hx hy
    exact (ne (hx.symm.trans hy)).elim
  | inr i =>
    refine ⟨i,fun g hg => (clean_nok _ _ clean g hg).1,?_⟩
    intro x
    have eq := read x
    rwa [ho] at eq
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.deleted_circuit
