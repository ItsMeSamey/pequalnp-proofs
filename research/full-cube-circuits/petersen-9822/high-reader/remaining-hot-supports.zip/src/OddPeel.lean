import Research.WegenerThreshold

namespace Research.OddOr
open FreeAndNet
variable {α : Type} [DecidableEq α]

def sees (t : Net α) (s : Finset α) := t.eval (fun i => decide (i ∈ s))
def kill (i j : α) : Product α := if j = i then none else some [j]
def pin (i : α) (t : Net α) := specialize (kill i) t

theorem pin_sees (i : α) (t : Net α) (s : Finset α) (hs : i ∉ s) :
    sees (pin i t) s = sees t s := by
  unfold sees pin
  rw [eval_specialize]
  congr 1
  funext j
  by_cases h : j = i
  · subst j; simp [kill,pval,hs]
  · simp [kill,h,pval]

theorem pin_cost (i : α) (t : Net α) : (pin i t).cost + hits i t ≤ t.cost :=
  specialize_saves i (kill i) (by simp [kill]) t

theorem avoids_output (t : Net α) {i : α} {z : Finset α} (hz : i ∉ z)
    (on : sees t z = true) : ¬ outUses i t := by
  intro bad
  have off := outZeros t i bad (fun j => decide (j ∈ z)) (by simp [hz])
  change sees t z = false at off
  simp_all

theorem positive_hit (t : Net α) {i j : α} (cold : sees t {j} = false)
    (hot : sees t {i,j} = true) (noOut : ¬ outUses i t) : 0 < hits i t := by
  by_contra! zero
  have eq : sees t {i,j} = sees t {j} := by
    apply eval_congr_used
    intro a used
    have ne : a ≠ i := by rintro rfl; rcases used with h | h <;> first | omega | contradiction
    simp [ne]
  simp_all

/-- A vertex deletion certificate. The newly added vertex has a neighbor in
the retained graph and the retained graph contains a positive pair. -/
inductive Peel (E : α → α → Prop) : List α → Finset α → Prop
  | done (core : Finset α) : Peel E [] core
  | step {i j a b : α} {xs : List α} {core : Finset α}
      (tail : Peel E xs core) (fresh : i ∉ xs.toFinset ∪ core)
      (hj : j ∈ xs.toFinset ∪ core) (ha : a ∈ xs.toFinset ∪ core)
      (hb : b ∈ xs.toFinset ∪ core) (edge : E i j) (live : E a b) :
      Peel E (i::xs) core

def Fits (E : α → α → Prop) (v : Finset α) (t : Net α) :=
  (∀ i ∈ v, sees t {i} = false) ∧
  (∀ i ∈ v, ∀ j ∈ v, E i j → sees t {i,j} = true)

theorem peel_cost {E : α → α → Prop} {xs : List α} {core : Finset α}
    (hc : Peel E xs core) (t : Net α) (h : Fits E (xs.toFinset ∪ core) t) :
    ∃ u : Net α, u.cost + xs.length ≤ t.cost ∧
      ∀ s ⊆ core, sees u s = sees t s := by
  induction hc generalizing t with
  | done core => exact ⟨t,by simp,by simp⟩
  | @step i j a b xs core _ fresh hj ha hb e l ih =>
    let v := xs.toFinset ∪ core
    have hv : (i::xs).toFinset ∪ core = insert i v := by simp [v]
    rw [hv] at h
    have diff {q : α} (hq : q ∈ v) : i ≠ q := fun eq => fresh (eq ▸ hq)
    have miss : i ∉ ({a,b} : Finset α) := by simp [diff ha,diff hb]
    have hit := positive_hit t (h.1 j (Finset.mem_insert_of_mem hj))
      (h.2 i (by simp) j (Finset.mem_insert_of_mem hj) e)
      (avoids_output t miss (h.2 a (Finset.mem_insert_of_mem ha) b (Finset.mem_insert_of_mem hb) l))
    have fit : Fits E v (pin i t) := by
      constructor
      · intro q hq
        rw [pin_sees _ _ _ (by simp [diff hq])]
        exact h.1 q (Finset.mem_insert_of_mem hq)
      · intro q hq r hr er
        rw [pin_sees _ _ _ (by simp [diff hq,diff hr])]
        exact h.2 q (Finset.mem_insert_of_mem hq) r (Finset.mem_insert_of_mem hr) er
    obtain ⟨u,hu,eq⟩ := ih (pin i t) fit
    refine ⟨u,?_,?_⟩
    · have debit := pin_cost i t
      simp only [List.length_cons]
      omega
    · intro s hs
      rw [eq s hs]
      apply pin_sees
      exact fun hi => fresh (Finset.mem_union_right _ (hs hi))
end Research.OddOr
