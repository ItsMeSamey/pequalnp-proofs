import GuardEmitter9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
open PEqualNP.CircuitLowerBounds GuardTags

theorem val_later (x : Stat) (w : List Bool) (gs : List Gate) (h : x.Valid w.length) :
    x.val (wiresFrom gs w) = x.val w := by
  cases x with
  | inl b => rfl
  | inr i => exact getD_wiresFrom _ _ _ h
theorem repair_later (w : List Bool) (g : List Gate) (r : Reg) (hr : r.2.Valid w.length) :
    meaning (wiresFrom g w) r = meaning w r := by
  unfold meaning; rw [val_later _ _ _ hr]

theorem seq_good (w : List Bool) (a : Block) (next : Stat → Block) (v : Bool)
    (h : Good (wiresFrom a.code w) (next a.result) v) :
    Good w (seq a next) v := by
  obtain ⟨valid,eq⟩ := h
  refine ⟨?_,?_⟩
  · simpa [seq,length_wiresFrom,Nat.add_assoc] using valid
  · simpa [seq,wiresFrom_append] using eq

theorem pair_good (w : List Bool) (z : Nat) (hz : z<w.length) (a b : Reg)
    (ha : a.2.Valid w.length) (hb : b.2.Valid w.length) :
    Good w (pairOr w.length z a b)
      (recover (w.getD z false) (meaning w a) || recover (w.getD z false) (meaning w b)) := by
  let pa := repair w.length z a
  let wa := wiresFrom pa.code w
  let pb := repair (w.length+pa.code.length) z b
  let wb := wiresFrom pb.code wa
  have la : wa.length = w.length+pa.code.length := length_wiresFrom _ _
  have lb : wb.length = w.length+pa.code.length+pb.code.length := by
    rw [show wb.length = wa.length+pb.code.length from length_wiresFrom _ _,la]
  have aa := repair_good w z hz a ha
  change Good w pa _ at aa
  have hav : pa.result.Valid wa.length := by rw [la]; exact aa.1
  have hab : pa.result.val wa = _ := aa.2
  have hwb : b.2.Valid wa.length := Stat.valid_mono (by omega) b.2 hb
  have bb := repair_good wa z (by omega) b hwb
  have same : meaning wa b = meaning w b := repair_later w pa.code b hb
  rw [same,getD_wiresFrom pa.code w z hz] at bb
  rw [la] at bb
  change Good wa pb _ at bb
  have hbb : pb.result.Valid wb.length := by rw [lb,← la]; exact bb.1
  have ha' : pa.result.Valid wb.length := Stat.valid_mono (by omega) pa.result hav
  have result := one_good .or (Or.inr rfl) wb pa.result pb.result ha' hbb
  have haeval : pa.result.val wb = _ := (val_later pa.result wa pb.code hav).trans hab
  have hbeval : pb.result.val wb = _ := bb.2
  rw [haeval,hbeval,lb] at result
  apply seq_good
  apply seq_good
  simpa [GateOp.eval] using result

def grouped (n z : Nat) (a b : Reg) : Block :=
  let p := one n .or a.2 b.2
  seq p fun x => one (n+p.code.length) .and (Sum.inr z) x

def actual (n z : Nat) (op : GateOp) (a b : Reg) : Bool × Block :=
  match op with
  | .and => (a.1 || b.1,one n .and a.2 b.2)
  | _ => (false, if a.1 && b.1 then grouped n z a b else pairOr n z a b)

theorem grouped_good (w : List Bool) (z : Nat) (hz : z<w.length) (a b : Reg)
    (ha : a.2.Valid w.length) (hb : b.2.Valid w.length) :
    Good w (grouped w.length z a b) ((w.getD z false) && (a.2.val w || b.2.val w)) := by
  let p := one w.length .or a.2 b.2
  let wp := wiresFrom p.code w
  have size : wp.length = w.length+p.code.length := length_wiresFrom _ _
  have h := one_good .or (Or.inr rfl) w a.2 b.2 ha hb
  change Good w p _ at h
  have valid : p.result.Valid wp.length := by rw [size]; exact h.1
  have ev : p.result.val wp = (a.2.val w || b.2.val w) := by simpa [GateOp.eval] using h.2
  have step := one_good .and (Or.inl rfl) wp (Sum.inr z) p.result (by change z < wp.length; omega) valid
  rw [size] at step
  apply seq_good
  change Good wp (one (w.length+p.code.length) .and (Sum.inr z) p.result) (wp.getD z false && (p.result.val wp && true)) at step
  rw [Bool.and_true,ev,getD_wiresFrom p.code w z hz] at step
  exact step
end PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter.pair_good
