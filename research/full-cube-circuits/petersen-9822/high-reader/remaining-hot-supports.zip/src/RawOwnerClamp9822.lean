import PhysicalAndCap9822
import PhysicalSignedClamp9822
import CleanCompile9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.RawOwnerClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open FreeAndNet Research.OddOr Research.OddOr.Graph9822
open PEqualNP.Outside.L_meta_9822.Clean
open SignedClamp

theorem deletion_floor (i : Fin 10) (t : Net V)
    (matchesOff : ∀ s, i ∉ s → sees t s = f s) : 9 ≤ t.cost := by
  fin_cases i
  · exact price0 _ matchesOff
  · exact price1 _ matchesOff
  · exact price2 _ matchesOff
  · exact price3 _ matchesOff
  · exact price4 Theta233.lower _ matchesOff
  · exact price5 Theta144.lower _ matchesOff
  · exact price6 Theta233.lower _ matchesOff
  · exact price7 Theta233.lower _ matchesOff
  · exact price8 Theta144.lower _ matchesOff
  · exact price9 Theta145.lower _ matchesOff

/-- A nine-OR zero-deletion bound plus one pivotal edge yields ten ORs for
any positive clamp whose zero face is unchanged and which covers the edges. -/
theorem clamp_lower (i : Fin 10) (t : Net V)
    (matchesOff : ∀ s, i ∉ s → sees t s = f s)
    (upper : ∀ s, f s = true → sees t s = true) : 10 ≤ t.cost := by
  obtain ⟨j,edgej⟩ := data.neighbor i
  have ne : i ≠ j := by
    rintro rfl
    simp [data.singleton] at edgej
  obtain ⟨x,y,hx,hy,on⟩ := data.avoiding i
  have noOut := avoids_output t (i := i) (z := {x,y}) (by simp [hx,hy]) (upper _ on)
  have hit := positive_hit t ((matchesOff {j} (by simpa using ne)).trans (data.singleton j))
      (upper _ edgej) noOut
  have low := deletion_floor i (pin i t) (fun s hs => (pin_sees i t s hs).trans (matchesOff s hs))
  have pay := pin_cost i t
  omega

def forceOne (pre post : List Gate) (out : Nat) : Circuit := ⟨pre ++ ⟨.and,[]⟩ :: post,out⟩

theorem physical_negative_transversal_ten (C : Circuit) (cand : Candidate C) (i : Fin 10)
    (pre post : List Gate) (g : Gate) (inv : g.op = .not)
    (split : C.gates = pre ++ g :: post)
    (positive : ∀ q ∈ pre ++ post, PositiveOp q)
    (transversal : ∀ v : Input, v i = false → edge v = false → innerValue pre g v = false) :
    10 ≤ (C.gates.filter CircuitCompiler.orFlag).length := by
  let D := forceOne pre post C.output
  have hm : Monotone2 D := by
    intro a ha
    change a ∈ pre ++ (⟨.and,[]⟩ : Gate) :: post at ha
    have ordinary (h : a ∈ pre ++ post) : a.op ∈ ({GateOp.and,GateOp.or} : Set GateOp) ∧
        a.inputs.length ≤ 2 := by
      have source : a ∈ C.gates := by
        rw [split]
        rcases List.mem_append.mp h with head | tail
        · exact List.mem_append_left _ head
        · exact List.mem_append_right _ (List.mem_cons_of_mem _ tail)
      exact ⟨positive a h,(cand.1 a source).2⟩
    rcases List.mem_append.mp ha with head | rest'
    · exact ordinary (List.mem_append_left _ head)
    · rcases List.mem_cons.mp rest' with rfl | tail
      · exact ⟨Or.inl rfl, by decide⟩
      · exact ordinary (List.mem_append_right _ tail)
  have cut := physical_cut_split (g := g) cand split inv
      (fun q hq => positive q (List.mem_append_right _ hq))
  let t := CircuitCompiler.compile 10 D
  have read (s : Finset V) : sees t s =
      outerValue pre post C.output (fun j => decide (j∈s)) true := by
    unfold sees
    rw [CircuitCompiler.compile_eval 10 D hm]
    change (wiresFrom (pre ++ (⟨.and,[]⟩ : Gate) :: post) _).getD _ _ = _
    rw [wiresFrom_append]
    rfl
  have cost := clamp_lower i t (by
    intro s hs
    rw [read]
    have e := cut.computes (fun j => decide (j∈s))
    cases out : f s with
    | true => exact positive_upper cut _ out
    | false =>
      rw [transversal _ (by simp [hs]) out] at e
      exact e.trans out) (by
    intro s he
    rw [read]
    exact positive_upper cut _ he)
  have budget := CircuitCompiler.compile_cost 10 D
  have same : (D.gates.filter CircuitCompiler.orFlag).length =
      (C.gates.filter CircuitCompiler.orFlag).length := by
    rw [split]
    simp [D,forceOne,CircuitCompiler.orFlag,inv]
  exact cost.trans (budget.trans_eq same)

theorem physical_compulsory_ten (C : Circuit) (cand : Candidate C) (i : Fin 10)
    (pre post : List Gate) (g : Gate) (inv : g.op = .not)
    (split : C.gates = pre ++ g :: post)
    (positive : ∀ q ∈ pre ++ post, PositiveOp q)
    (compulsory : ∀ v : Input, v i = false → innerValue pre g v = false) :
    10 ≤ (C.gates.filter CircuitCompiler.orFlag).length :=
  physical_negative_transversal_ten C cand i pre post g inv split positive
    (fun v off _ => compulsory v off)

theorem physical_raw_ten (C : Circuit) (cand : Candidate C) (i : Fin 10)
    (pre post : List Gate) (rest : List Nat)
    (split : C.gates = pre ++ (⟨.not,i.val :: rest⟩ : Gate) :: post)
    (positive : ∀ q ∈ pre ++ post, PositiveOp q) :
    10 ≤ (C.gates.filter CircuitCompiler.orFlag).length := by
  apply physical_compulsory_ten C cand i pre post _ rfl split positive
  intro v off
  change (wiresFrom pre (List.ofFn v)).getD i.val false = false
  rw [getD_wiresFrom _ _ _ (by simp)]
  exact (Clean.getD_ofFn 10 v false i).trans off

theorem excludes_raw_at_nine (C : Circuit) (i : Fin 10) (pre post : List Gate)
    (rest : List Nat) (split : C.gates = pre ++ (⟨.not,i.val :: rest⟩ : Gate) :: post)
    (positive : ∀ q ∈ pre ++ post, PositiveOp q)
    (budget : (C.gates.filter CircuitCompiler.orFlag).length ≤ 9) : ¬Candidate C := by
  intro candidate
  have lower := physical_raw_ten C candidate i pre post rest split positive
  omega

theorem raw_seven_and_impossible (C : Circuit) (i : Fin 10) (pre post : List Gate)
    (rest : List Nat) (split : C.gates = pre ++ (⟨.not,i.val :: rest⟩ : Gate) :: post)
    (positive : ∀ q ∈ pre ++ post, PositiveOp q)
    (seven : 7 ≤ C.gates.countP countsAnd) : ¬ Candidate C := by
  intro candidate
  have ten := physical_raw_ten C candidate i pre post rest split positive
  have head := priceDisjoint pre
  have tail := priceDisjoint post
  have cap : C.gates.length ≤ 17 := candidate.2.1
  rw [split] at cap ten seven
  simp [CircuitCompiler.orFlag,countsAnd] at cap ten seven head tail
  omega

end PEqualNP.Outside.L_meta_9822.Sectors.RawOwnerClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.RawOwnerClamp.physical_raw_ten

#print axioms PEqualNP.Outside.L_meta_9822.Sectors.RawOwnerClamp.excludes_raw_at_nine

#print axioms PEqualNP.Outside.L_meta_9822.Sectors.RawOwnerClamp.raw_seven_and_impossible
