import RisingOrFrontier9822
import PinStatusSignals9822
import PairSignalRelations9822
import AdjacentRows9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean AdjacentCut
theorem exclusive_positive : ∀ s t : V, s≠t → ∃ i : V,
    edge (setOwners s t (SignedClamp.singleton i) false false)=false ∧
    edge (setOwners s t (SignedClamp.singleton i) true false)=true := by decide +kernel
theorem positive_off_two : ∀ s t : V, edge (masked {s,t} (fun _ => true))=true := by decide +kernel
theorem pair_rising_gate {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (s t : V) (st : s≠t) (p tail : List Gate)
    (full : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length]) :
    ∃ k q,C.gates[k]?=some q ∧ q.op=.or ∧
      (∃ j∈q.inputs,(foldZero C {s,t}).1.getD j (Sum.inl false)=Sum.inl false) ∧
      (foldZero C {s,t}).1.getD (10+k) (Sum.inl false)≠Sum.inl false ∧
      ∃ x y : Input,x s=false ∧ x t=false ∧ y s=true ∧ rises C.gates x y (10+k) := by
  obtain ⟨i,lo,hi⟩ := exclusive_positive s t st
  let x := setOwners s t (SignedClamp.singleton i) false false
  let y := setOwners s t (SignedClamp.singleton i) true false
  let Z := fun j => (foldZero C {s,t}).1.getD j (Sum.inl false)=Sum.inl false
  have ups : rises C.gates x y C.output := ⟨(cand.2.2 x).trans lo,(cand.2.2 y).trans hi⟩
  have notZ : ¬ Z C.output := by
    intro hz
    have a := frozen_value C cand {s,t} C.output false hz (fun _ => true)
    have b := (cand.2.2 (masked {s,t} (fun _ => true))).trans (positive_off_two s t)
    exact Bool.noConfusion (a.symm.trans b)
  have raw (j : Nat) (lt : j<10) (up : rises C.gates x y j) : Z j := by
    let v : V := ⟨j,lt⟩
    by_cases e : v=s
    · exact raw_zero_status C {s,t} v (by simp [e])
    · obtain ⟨a,b⟩ := up
      rw [vl_input _ _ _ lt] at a b
      have eq : x ⟨j,lt⟩=y ⟨j,lt⟩ := by simp [x,y,setOwners,show (⟨j,lt⟩ : V)≠s from e]
      exact Bool.noConfusion (a.symm.trans (eq.trans b))
  have noInv (k : Nat) (q : Gate) (site : C.gates[k]?=some q) (op : q.op=.not) :
      ¬ rises C.gates x y (10+k) := by
    have idx : k=pre.length := by
      by_contra diff
      have pos : q∈pre++post := by
        rw [r.split] at site
        by_cases lt : k<pre.length
        · apply List.mem_append_left
          exact List.mem_iff_getElem?.mpr ⟨k,by simpa [List.getElem?_append,lt] using site⟩
        · apply List.mem_append_right
          obtain ⟨a,ha⟩ : ∃ a,k=pre.length+(a+1) := ⟨k-pre.length-1,by omega⟩
          exact List.mem_iff_getElem?.mpr ⟨a,by simpa [ha,List.getElem?_append] using site⟩
      rcases r.pos q pos with e|e <;> simp_all
    subst k
    have v := (pair_physical_values r red.clean s t p tail full unary y).2
    have ys : y s=true := by simp [y,setOwners]
    rw [ys] at v
    exact fun h => Bool.noConfusion (h.2.symm.trans v)
  obtain ⟨k,q,site,op,up,nz,pin⟩ := rising_or_frontier C.gates red.clean x y Z C.output ups notZ raw
    (fun k q h o => next_zero red.clean {s,t} k q h o) noInv
  exact ⟨k,q,site,op,pin,nz,x,y,by simp [x,setOwners],by simp [x,setOwners,st.symm],by simp [y,setOwners],up⟩
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.pair_rising_gate
