import OR9822Finish
import PhysicalSignedClamp9822
import MixedSignedFace9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.LowPositive
open FreeAndNet Research.OddOr PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open SignedClamp
abbrev V := Fin 10
def pos (i : V) (s : Finset V) := edge (fun j => decide (j=i ∨ j∈s))

/-- Ordered deletion with arbitrary pivot rows, including singleton disjuncts. -/
inductive Steps (f : Finset V → Bool) : List V → Finset V → Prop
  | done (core : Finset V) : Steps f [] core
  | step {i : V} {xs : List V} {core lo other : Finset V}
      (tail : Steps f xs core) (fresh : i ∉ xs.toFinset ∪ core)
      (small : lo ⊆ xs.toFinset ∪ core) (live : other ⊆ xs.toFinset ∪ core)
      (off : f lo = false) (on : f (insert i lo) = true) (rest : f other = true) :
      Steps f (i :: xs) core

theorem steps_cost {f xs core} (hs : Steps f xs core) (t : Net V)
    (h : ∀ s ⊆ xs.toFinset ∪ core, sees t s = f s) :
    ∃ u : Net V, u.cost + xs.length ≤ t.cost ∧ ∀ s ⊆ core, sees u s = f s := by
  induction hs generalizing t with
  | done core => exact ⟨t,by simp,by simpa using h⟩
  | @step i xs core lo other tail fresh small live off on rest ih =>
    have outside (s : Finset V) (sub : s ⊆ xs.toFinset ∪ core) : i ∉ s := fun hi => fresh (sub hi)
    have eq (s : Finset V) (sub : s ⊆ xs.toFinset ∪ core) : sees t s = f s := by
      apply h; intro z hz
      have hz' := sub hz
      simpa [Finset.mem_union,or_assoc] using Or.inr (a := z=i) hz'
    have plus : sees t (insert i lo) = true := by
      apply Eq.trans (h _ _) on
      intro x hx
      rcases Finset.mem_insert.mp hx with rfl | mem
      · simp
      · have m := small mem
        simpa [Finset.mem_union,or_assoc] using Or.inr (a := x=i) m
    have nonout := avoids_output t (outside other live) ((eq _ live).trans rest)
    have fired : 0 < hits i t := by
      by_contra! hz
      have same : sees t (insert i lo) = sees t lo := by
        apply eval_congr_used
        intro k use
        have diff : k ≠ i := by rintro rfl; exact use.elim (by omega) nonout
        simp [diff]
      rw [plus,(eq lo small).trans off] at same
      contradiction
    obtain ⟨u,bnd,fit⟩ := ih (pin i t) (fun s sub => (pin_sees i t s (outside s sub)).trans (eq s sub))
    refine ⟨u,?_,fit⟩
    have pay := pin_cost i t
    simp only [List.length_cons]
    omega

theorem apply_cycle {n k : Nat} (f : Finset V → Bool) (core : Finset V) (extras : List V)
    (e : Fin n ↪ V) (b : Finset (Fin n) → Bool) (peel : Steps f extras core)
    (into : ∀ s : Finset (Fin n), s.map e ⊆ core) (values : ∀ s : Finset (Fin n), f (s.map e) = b s)
    (cost : ∀ t, (∀ s, sees t s = b s) → k ≤ t.cost)
    (t : Net V) (exactOn : ∀ s, sees t s = f s) : k + extras.length ≤ t.cost := by
  obtain ⟨u,hu,fit⟩ := steps_cost peel t (fun s _ => exactOn s)
  have floor := cost (specialize (inverseRaw e) u) (fun s =>
    (reembed e u s).trans ((fit _ (into s)).trans (values s)))
  have debit := specialize_cost (inverseRaw e) u
  omega

def emb0 : Fin 5 ↪ V where
  toFun := fun j => ([1, 2, 7, 9, 6] : List V).get j
  inj' := by decide +kernel

theorem floor0 (t : Net V) (h : ∀ s, sees t s = pos 0 s) : 8 ≤ t.cost := by
  apply apply_cycle (pos 0) {1,2,6,7,9} [3,4,5,8] emb0 Cycle5.f _ (by decide +kernel) (by decide +kernel) Cycle5.lower t h
  refine Steps.step (lo := {8}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {6}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _

def emb1 : Fin 5 ↪ V where
  toFun := fun j => ([0, 4, 3, 8, 5] : List V).get j
  inj' := by decide +kernel

theorem floor1 (t : Net V) (h : ∀ s, sees t s = pos 1 s) : 8 ≤ t.cost := by
  apply apply_cycle (pos 1) {0,3,4,5,8} [2,6,7,9] emb1 Cycle5.f _ (by decide +kernel) (by decide +kernel) Cycle5.lower t h
  refine Steps.step (lo := ∅) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := ∅) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {5}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {4}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _

def emb2 : Fin 5 ↪ V where
  toFun := fun j => ([0, 4, 3, 8, 5] : List V).get j
  inj' := by decide +kernel

theorem floor2 (t : Net V) (h : ∀ s, sees t s = pos 2 s) : 8 ≤ t.cost := by
  apply apply_cycle (pos 2) {0,3,4,5,8} [1,6,7,9] emb2 Cycle5.f _ (by decide +kernel) (by decide +kernel) Cycle5.lower t h
  refine Steps.step (lo := ∅) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {8}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := ∅) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {4}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _

def emb3 : Fin 5 ↪ V where
  toFun := fun j => ([1, 2, 7, 9, 6] : List V).get j
  inj' := by decide +kernel

theorem floor3 (t : Net V) (h : ∀ s, sees t s = pos 3 s) : 8 ≤ t.cost := by
  apply apply_cycle (pos 3) {1,2,6,7,9} [0,4,5,8] emb3 Cycle5.f _ (by decide +kernel) (by decide +kernel) Cycle5.lower t h
  refine Steps.step (lo := {5}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {7}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _

def emb4 : Fin 6 ↪ V where
  toFun := fun j => ([1, 2, 7, 5, 8, 6] : List V).get j
  inj' := by decide +kernel

theorem floor4 (t : Net V) (h : ∀ s, sees t s = pos 4 s) : 8 ≤ t.cost := by
  apply apply_cycle (pos 4) {1,2,5,6,7,8} [0,3,9] emb4 Cycle6.f _ (by decide +kernel) (by decide +kernel) Cycle6.lower t h
  refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _

theorem any_low (i : V) (low : i.val ≤ 4) (t : Net V)
    (h : ∀ s, sees t s = pos i s) : 8 ≤ t.cost := by
  fin_cases i
  · exact floor0 _ h
  · exact floor1 _ h
  · exact floor2 _ h
  · exact floor3 _ h
  · exact floor4 _ h
  all_goals simp at low

end PEqualNP.Outside.L_meta_9822.Sectors.LowPositive
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowPositive.any_low
