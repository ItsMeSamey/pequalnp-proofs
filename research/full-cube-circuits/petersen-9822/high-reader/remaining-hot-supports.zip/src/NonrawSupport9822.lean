import RawOwnerClamp9822
import PhysicalClampInputs9822
import MixedSignedFace9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.NonrawSupport
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet
open PEqualNP.Outside.L_meta_9822.Clean SignedClamp RawOwnerClamp

structure Roster (C : Circuit) (pre post : List Gate) (g : Gate) : Prop where
  split : C.gates = pre ++ g :: post
  inv : g.op = .not
  pos : ∀ a ∈ pre ++ post, PositiveOp a

theorem or_cap {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) :
    (C.gates.filter CircuitCompiler.orFlag).length ≤ 9 := by
  have h := priceDisjoint pre
  have j := priceDisjoint post
  have cap : C.gates.length ≤ 17 := cand.2.1
  rw [r.split] at cap seven ⊢
  simp [countsAnd,CircuitCompiler.orFlag,r.inv] at cap seven h j ⊢
  omega

theorem independent_witness {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10) :
    ∃ v : Input, v i = false ∧ edge v = false ∧ innerValue pre g v = true := by
  have cap := or_cap r cand seven
  by_contra! no
  have low := physical_negative_transversal_ten C cand i pre post g r.inv r.split r.pos
    (fun v h m => by cases e : innerValue pre g v <;> simp_all)
  omega

/-- The constant-true guard loses the inverter without exceeding ten ORs,
which contradicts the independent eleven-OR lower bound for the graph. -/
theorem cold_empty {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) : innerValue pre g (fun _ => false) = false := by
  cases cold : innerValue pre g (fun _ => false) with
  | false => rfl
  | true =>
    have hot (v : Input) : innerValue pre g v = true := inner_mono_inputs
      (fun a ha => r.pos a (List.mem_append_left _ ha)) g
      (fun _ h => by contradiction) cold
    let D := MixedPositive.forceZero pre post C.output
    have mono : Monotone2 D := by
      intro a ha
      change a ∈ pre ++ (⟨.or,[]⟩ : Gate) :: post at ha
      have ordinary (h : a ∈ pre ++ post) : PositiveOp a ∧ a.inputs.length ≤ 2 := by
        have source : a ∈ C.gates := by
          rw [r.split]
          rcases List.mem_append.mp h with head | tail
          · exact List.mem_append_left _ head
          · exact List.mem_append_right _ (List.mem_cons_of_mem _ tail)
        exact ⟨r.pos a h,(cand.1 a source).2⟩
      rcases List.mem_append.mp ha with head | rest
      · exact ordinary (List.mem_append_left _ head)
      · rcases List.mem_cons.mp rest with rfl | tail
        · exact ⟨Or.inr rfl,by decide⟩
        · exact ordinary (List.mem_append_right _ tail)
    have cut := physical_cut_split cand r.split r.inv
      (fun a ha => r.pos a (List.mem_append_right _ ha))
    have compute (v : Input) : D.eval (List.ofFn v) = edge v := by
      have e := cut.computes v
      rw [hot] at e
      change (wiresFrom (pre ++ (⟨.or,[]⟩ : Gate) :: post) _).getD _ _ = _
      rw [wiresFrom_append]
      exact e
    have low := Research.OddOr.Graph9822.physical_eleven D mono compute
    have cap := or_cap r cand seven
    rw [r.split] at cap
    have one : CircuitCompiler.orFlag (⟨.or,[]⟩ : Gate) = true := rfl
    change 11 ≤ ((pre ++ (⟨.or,[]⟩ : Gate) :: post).filter CircuitCompiler.orFlag).length at low
    rw [List.filter_append,List.filter_cons_of_pos one,List.length_append,List.length_cons] at low
    simp [CircuitCompiler.orFlag,r.inv] at cap
    omega

/-- Any guard determined by at most two given input coordinates must be their
literal disjunction in a candidate. This allows arbitrary positive shared
prefixes, rather than assuming the guard itself is a single physical gate. -/
theorem two_support_is_or {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i j : Fin 10)
    (support : ∀ x y : Input, x i = y i → x j = y j →
      innerValue pre g x = innerValue pre g y) :
    i ≠ j ∧ ∀ v : Input, innerValue pre g v = (v i || v j) := by
  let H := innerValue pre g
  have empty : H (fun _ => false) = false := cold_empty r cand seven
  have cold (x : Input) (hi : x i = false) (hj : x j = false) : H x = false :=
    (support x (fun _ => false) hi hj).trans empty
  obtain ⟨x,xi,_,xh⟩ := independent_witness r cand seven i
  obtain ⟨y,yj,_,yh⟩ := independent_witness r cand seven j
  have xj : x j = true := by
    cases h : x j <;> first | rfl | exact False.elim (Bool.noConfusion ((cold x xi h).symm.trans xh))
  have yi : y i = true := by
    cases h : y i <;> first | rfl | exact False.elim (Bool.noConfusion ((cold y h yj).symm.trans yh))
  have diff : i ≠ j := by rintro rfl; simp_all
  refine ⟨diff,?_⟩
  intro v
  cases a : v i <;> cases b : v j
  · exact cold v a b
  · exact (support v x (a.trans xi.symm) (b.trans xj.symm)).trans xh
  · exact (support v y (a.trans yi.symm) (b.trans yj.symm)).trans yh
  · have single : H (singleton i) = true := (support (singleton i) y
        (by simp [SignedClamp.singleton,yi]) (by simp [SignedClamp.singleton,Ne.symm diff,yj])).trans yh
    apply inner_mono_inputs (fun k hk => r.pos k (List.mem_append_left _ hk)) g _ single
    intro k hk
    have ki : k = i := by simpa [SignedClamp.singleton] using hk
    simpa [ki] using a

end PEqualNP.Outside.L_meta_9822.Sectors.NonrawSupport
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.NonrawSupport.two_support_is_or
