import PhysicalSevenResidual9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean

theorem remaining_hot_supports {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7 ≤ C.gates.countP countsAnd) :
    C.gates.countP countsAnd = 7 ∧ (C.gates.filter CircuitCompiler.orFlag).length = 9 ∧
    ((∀ j : Fin 10, innerValue pre g (SignedClamp.singleton j) = true ↔ j = 9) ∨
    ∃ i : Fin 10, 5 ≤ i.val ∧ i.val ≤ 8 ∧
      ((∀ j : Fin 10, innerValue pre g (SignedClamp.singleton j) = true ↔ j = i) ∨
       (∀ j : Fin 10, innerValue pre g (SignedClamp.singleton j) = true ↔ j = i ∨ j = 9))) := by
  obtain ⟨eq, ors⟩ := exact_seven r cand red seven
  refine ⟨eq, ors, ?_⟩
  let hot := fun j : Fin 10 => innerValue pre g (SignedClamp.singleton j) = true
  have lo (j : Fin 10) (hj : hot j) : 5 ≤ j.val := by
    by_contra! low
    exact low_hot_impossible r seven j (by omega) hj cand
  by_cases h : ∃ i : Fin 10, i.val ≤ 8 ∧ hot i
  · obtain ⟨i,hi,ih⟩ := h
    have uniq (j : Fin 10) (jh : hot j) : j = i ∨ j = 9 := by
      by_cases nine : j = 9
      · exact Or.inr nine
      have jhi : j.val ≤ 8 := by
        have ne : j.val ≠ 9 := fun e => nine (Fin.ext e)
        omega
      left
      rcases lt_trichotomy j.val i.val with lt|same|gt
      · exact (no_two_high_singletons r cand red eq j i (lo j jh) lt hi jh ih).elim
      · exact Fin.ext same
      · exact (no_two_high_singletons r cand red eq i j (lo i ih) gt jhi ih jh).elim
    refine Or.inr ⟨i,lo i ih,hi,?_⟩
    by_cases bh : hot 9
    · right
      intro j
      refine ⟨uniq j,?_⟩
      rintro (rfl|rfl) <;> assumption
    · left
      intro j
      refine ⟨fun hj => (uniq j hj).resolve_right (fun e => bh (e ▸ hj)),?_⟩
      rintro rfl
      exact ih
  · have only9 (j : Fin 10) (hj : hot j) : j = 9 := by
      apply Fin.ext
      have upper : ¬ j.val ≤ 8 := fun le => h ⟨j,le,hj⟩
      change j.val = 9
      omega
    obtain ⟨j, _, hj⟩ := physical_high_hot r cand seven red
    have nine : hot 9 := only9 j hj ▸ hj
    left
    intro k
    exact ⟨only9 k, fun e => e ▸ nine⟩

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.remaining_hot_supports
