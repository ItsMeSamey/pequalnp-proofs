import OddPeel
namespace Research.OddOr
open FreeAndNet
variable {α : Type} [DecidableEq α]
abbrev Probe (α : Type) := Finset α × Bool
def Matches (t : Net α) (rows : List (Probe α)) :=
  ∀ row ∈ rows, sees t row.1 = row.2
def firstBit (a b s : Finset α) := decide (a ⊆ s ∨ b ⊆ s)
def Obstructs (rows : List (Probe α)) :=
  ∀ a b : Finset α, 2 ≤ (a ∪ b).card →
    ∃ x ∈ rows, ∃ y ∈ rows, x.2 ≠ y.2 ∧ x.1 \ (a ∪ b) = y.1 \ (a ∪ b) ∧
      firstBit a b x.1 = firstBit a b y.1

theorem double_hit {rows : List (Probe α)} (separation : Obstructs rows)
    (a b : List α) (tail : Net (Option α)) (h : Matches (.gate a b tail) rows)
    (noOut : ∀ i, ¬ outUses i (.gate a b tail))
    (big : 2 ≤ (a.toFinset ∪ b.toFinset).card) :
    ∃ i, 2 ≤ hits i (.gate a b tail) := by
  classical
  by_contra! small
  let u := a.toFinset ∪ b.toFinset
  have nh (i) (hi : i ∈ u) : hits (some i) tail = 0 ∧ ¬outUses (some i) tail := by
    have hm : i ∈ a ∨ i ∈ b := by simpa [u] using hi
    have lim := small i
    simp [hits,hm] at lim
    exact ⟨by omega,noOut i⟩
  obtain ⟨post,ex⟩ := gate_cut a b tail u rfl nh
  obtain ⟨x,hx,y,hy,neq,rest,first⟩ := separation a.toFinset b.toFinset big
  have part (s : Finset α) :
      decide (a.toFinset ⊆ s ∩ u ∨ b.toFinset ⊆ s ∩ u) = firstBit a.toFinset b.toFinset s := by
    have ha : a.toFinset ⊆ u := Finset.subset_union_left
    have hb : b.toFinset ⊆ u := Finset.subset_union_right
    simp [firstBit,Finset.subset_inter_iff,ha,hb]
  have ex' (s : Finset α) : sees (.gate a b tail) s = true ↔ post (firstBit a.toFinset b.toFinset s) (s \ u) := by
    simpa only [sees,part] using ex s
  have eq : sees (.gate a b tail) x.1 = sees (.gate a b tail) y.1 := by
    apply Bool.eq_iff_iff.mpr
    rw [ex',ex',first]
    change post _ (x.1 \ (a.toFinset ∪ b.toFinset)) ↔ post _ (y.1 \ (a.toFinset ∪ b.toFinset))
    rw [rest]
  exact neq ((h x hx).symm.trans (eq.trans (h y hy)))

theorem core_lower {rows : List (Probe α)} {k : Nat} (sep : Obstructs rows)
    (noOut : ∀ t : Net α, Matches t rows → ∀ i, ¬ outUses i t)
    (live : ∀ t : Net α, Matches t rows → ∃ i, 0 < hits i t)
    (price : ∀ t : Net α, Matches t rows → ∀ i, k ≤ (pin i t).cost)
    (t : Net α) (h : Matches t rows) : k+2 ≤ t.cost := by
  classical
  generalize eq : t.cost = c
  induction c using Nat.strong_induction_on generalizing t with
  | ind c ih =>
    cases t with
    | out p =>
      obtain ⟨i,hi⟩ := live _ h
      simp [hits] at hi
    | gate a b tail =>
      by_cases bnd : 2 ≤ (a.toFinset ∪ b.toFinset).card
      · obtain ⟨i,hi⟩ := double_hit sep a b tail h (noOut _ h) bnd
        have lo := price _ h i
        have db := pin_cost i (.gate a b tail)
        omega
      · obtain ⟨u,he,lt⟩ := delete_degenerate_first a b tail (Or.inr (Or.inr (by omega)))
        have hm : Matches u rows := by
          intro r hr
          exact (he _).trans (h r hr)
        exact (ih u.cost (by omega) u hm rfl).trans (by omega)
end Research.OddOr
