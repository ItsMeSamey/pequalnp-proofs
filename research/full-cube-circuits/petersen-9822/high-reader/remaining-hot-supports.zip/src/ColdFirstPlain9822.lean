import ColdPrefixOr9822
import ColdPlainCompiler9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr
open SignedClamp NonrawSupport OuterNet PEqualNP.Outside.L_meta_9822.Clean
open GuardTags

theorem cold_first_plain {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (reduced : Reduced 10 C.gates C.output) :
    ∃ a b : List (Fin 11), ∃ next, model pre post C.output=.gate a b next ∧ 0∉a ∧ 0∉b := by
  let w := List.ofFn (fun i : Fin 11 => [i])
  have keep : ∀ j (h : j<w.length), j≠0 → (0 : Fin 11) ∉ w[j] := by
    intro j h nz
    have table : ∀ k : Fin w.length, k.val ≠ 0 → (0 : Fin 11) ∉ w[k.val]'k.isLt := by
      dsimp only [w]
      decide +kernel
    exact table ⟨j,h⟩ nz
  obtain ⟨q,hq,yes⟩ := prefix_contains_or r cand seven
  have ex : ∃ g∈pre.map shift,CircuitCompiler.orFlag g=true :=
    ⟨shift q,List.mem_map.mpr ⟨q,hq,rfl⟩,yes⟩
  have clear : ∀ g∈pre.map shift, ∀ j∈g.inputs, j≠0 := by
    intro h hh j hj
    obtain ⟨g,_,rfl⟩ := List.mem_map.mp hh
    obtain ⟨k,_,rfl⟩ := List.mem_map.mp hj
    exact Nat.succ_ne_zero _
  have red : Reduced 10 (pre++g::post) C.output := r.split ▸ reduced
  have valid := reduced_cut_wiring red
  have head := prefix_plain (pre.map shift) (⟨.and,[0]⟩ :: post.map shift) (C.output+1)
    ex clear w (by simp [w]) keep (by simpa [w,cutCircuit] using valid)
  have input : w.map some = List.ofFn (fun i : Fin 11 => some [i]) := by simp [w,List.map_ofFn]
  rw [input] at head
  exact head
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.cold_first_plain
