import PairedFirst9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport OuterNet FreeAndNet Research.OddOr
open Research.OddOr.Envelope

private theorem sub_original {a b : List (Fin 11)} (ap : 0 ∉ a)
    (sub : plainArm a ⊆ plainArm b) : a.toFinset ⊆ b.toFinset := by
  intro j
  refine Fin.cases (by intro bad; exact (ap (by simpa using bad)).elim) (fun i hi => ?_) j
  have h : i ∈ plainArm a := by simpa [plainArm] using hi
  simpa [plainArm] using sub h

theorem plain_big {a b : List (Fin 11)} (ap : 0 ∉ a) (bp : 0 ∉ b)
    (inc : ¬ a.toFinset ⊆ b.toFinset ∧ ¬ b.toFinset ⊆ a.toFinset) :
    2 ≤ (plainArm a ∪ plainArm b).card := by
  classical
  have ab : ¬plainArm a ⊆ plainArm b := fun h => inc.1 (sub_original ap h)
  have ba : ¬plainArm b ⊆ plainArm a := fun h => inc.2 (sub_original bp h)
  obtain ⟨i,hi,hni⟩ := Finset.not_subset.mp ab
  obtain ⟨j,hj,_⟩ := Finset.not_subset.mp ba
  have ne : i ≠ j := fun e => hni (e ▸ hj)
  have sub : ({i,j} : Finset (Fin 10)) ⊆ plainArm a ∪ plainArm b := by
    intro k hk
    simp only [Finset.mem_insert,Finset.mem_singleton] at hk
    rcases hk with rfl|rfl
    · exact Finset.mem_union_left _ hi
    · exact Finset.mem_union_right _ hj
  simpa [ne] using Finset.card_le_card sub

theorem paired_graph_contradiction {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (cold : ∀ j, innerValue pre g (SignedClamp.singleton j)=false)
    {a b t} (head : model pre post C.output = .gate a b t) (ap : 0 ∉ a) (bp : 0 ∉ b)
    (big : 2 ≤ (plainArm a ∪ plainArm b).card) : False := by
  classical
  have d := Graph9822.data
  have sep := obstruction_from_cofactors (neighborhood_three Graph9822.f d.cold d.singleton
    d.neighbor d.diff (crosses_of_walk _ d.walk d.spans d.steps)) d.edges d.hot d.cold d.meet
  obtain ⟨rx,hx,ry,hy,neq,rest,fb⟩ := sep _ _ big
  obtain ⟨x,_,rfl⟩ := List.mem_map.mp hx
  obtain ⟨y,_,rfl⟩ := List.mem_map.mp hy
  obtain ⟨idx,_,same,read,used⟩ := coupled_cold_trace r cand seven cold
  have tr := same
  rw [head] at tr
  have getTail {h : Net (Fin 11)} (s : SameTrace (.gate a b t) h) :
      ∃ u, h = .gate a b u := by cases s with | gate a b h => exact ⟨_,rfl⟩
  obtain ⟨u,hu⟩ := getTail tr
  have kEq (z : Bool) := paired_gate_eq a b t ap bp (fun i => head ▸ (used i).1)
    (fun i => head ▸ (used i).2.1) z rest fb
  have hEq := paired_gate_eq a b u ap bp (fun i => hu ▸ (trace_hits_eq same i.succ ▸ (used i).1))
    (fun i => hu ▸ (used i).2.2) true rest fb
  rw [←hu,read,read] at hEq
  have eq := kEq (!(innerValue pre g (inputOn x)))
  rw [←head,model_eval r cand,model_eval r cand] at eq
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  apply neq
  exact (cut.computes _).symm.trans (eq.trans (by rw [hEq,cut.computes]; rfl))
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.paired_graph_contradiction
