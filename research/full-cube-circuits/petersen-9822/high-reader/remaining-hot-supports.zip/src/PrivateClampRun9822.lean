import PrivateClampTape9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean
theorem inv_append_const {y w : List Bool} {a : EAcc} (inv : Inv 10 y w a) (b : Bool) :
    Inv 10 y (w++[b]) (appendConst b a) := by
  refine ⟨by simp [appendConst,inv.1],?_⟩
  intro i
  by_cases e : i=a.1.length
  · subst i
    change ((a.1++[Sum.inl b]).getD a.1.length _).Valid _ ∧
      ((a.1++[Sum.inl b]).getD a.1.length _).val _=(w++[b]).getD a.1.length _
    rw [getD_snoc_eq,inv.1,getD_snoc_eq]
    exact ⟨trivial,rfl⟩
  · change ((a.1++[Sum.inl b]).getD i _).Valid _ ∧ ((a.1++[Sum.inl b]).getD i _).val _=(w++[b]).getD i _
    rw [getD_snoc_ne _ _ _ _ e,getD_snoc_ne _ _ _ _ (by rwa [←inv.1])]
    exact inv.2 i
theorem clamp_run (p mid post : List Gate)
    (ok : ∀ q∈p++mid++post,Ok q) (x : Input) :
    Inv 10 (List.ofFn x) (clampValues p mid post x) (clampOut p mid post) ∧
      CleanL 10 (clampOut p mid post).2 := by
  have ip : Inv 10 (List.ofFn x) (List.ofFn x) (assignments ∅,[]) := by
    simpa [masked] using pin_inv ∅ x
  have a : ∀q∈p,Ok q := fun q m => ok q (by simp [m])
  have b : ∀q∈mid,Ok q := fun q m => ok q (by simp [m])
  have c : ∀q∈post,Ok q := fun q m => ok q (by simp [m])
  have aI := inv_elim 10 _ (by simp) p _ _ a ip
  have aC := clean_elim 10 _ (by simp) p _ _ a ip (by intro i q h; simp at h)
  have bI := inv_elim 10 _ (by simp) mid _ _ b (inv_append_const aI false)
  have bC := clean_elim 10 _ (by simp) mid _ _ b (inv_append_const aI false) aC
  exact ⟨inv_elim 10 _ (by simp) post _ _ c (inv_append_const bI true),
         clean_elim 10 _ (by simp) post _ _ c (inv_append_const bI true) bC⟩
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.clamp_run
