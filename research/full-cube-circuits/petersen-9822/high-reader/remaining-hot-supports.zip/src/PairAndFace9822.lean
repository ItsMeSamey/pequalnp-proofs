import DualPhysical9822
import OuterZeroDebit9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.PairFace
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity LowPositive
open FreeAndNet Research.OddOr SignedClamp PEqualNP.Outside.L_meta_9822.Clean

theorem four_ands (D : Circuit) (mono : Monotone2 D) (a b : V)
    (shape : (a,b) ∈ ([(5,6),(6,7),(7,8)] : List (V×V)))
    (evaluates : ∀ s : Finset V, D.eval (List.ofFn fun i => decide (i∈s)) = neg a b s) :
    4 ≤ D.gates.countP countsAnd := by
  let C : Circuit := ⟨DualPhysical.phase 10 D.gates,DualPhysical.addr (10+D.gates.length) D.output⟩
  have hm : Monotone2 C := DualPhysical.phase_legal 10 D.gates mono
  let t := specialize (OuterNet.close true) (CircuitCompiler.compile 11 C)
  have exactOn (s : Finset V) : sees t s = cover a b s := by
    let x : Input := fun i => decide (i ∈ (Finset.univ \ s))
    let v : Input := fun i => decide (i∈s)
    have raw : List.ofFn (OuterNet.env v true) = true :: (List.ofFn x).map Bool.not := by
      rw [List.ofFn_succ]
      congr 1
      apply List.ext_getElem (by simp)
      intro i hi hj
      have bound : i<10 := by simpa using hi
      by_cases e : (⟨i,bound⟩ : V)∈s <;> simp [OuterNet.env,v,x,e]
    change (specialize (OuterNet.close true) _).eval v = _
    rw [eval_specialize,OuterNet.close_eval,CircuitCompiler.compile_eval _ _ hm]
    change (wiresFrom (DualPhysical.phase 10 D.gates) (List.ofFn (OuterNet.env v true))).getD _ false = _
    rw [raw]
    have ev := DualPhysical.phase_eval D.gates (List.ofFn x) (fun q hq => (mono q hq).1)
    simp only [List.length_ofFn] at ev
    rw [ev]
    have W := DualPhysical.read (wiresFrom D.gates (List.ofFn x)) D.output
    rw [length_wiresFrom,List.length_ofFn] at W
    rw [W]
    change (!(D.eval (List.ofFn x))) = (!(neg a b (Finset.univ \ s)))
    exact congrArg Bool.not (evaluates (Finset.univ \ s))
  have lower : 4 ≤ t.cost := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
    · exact cover56 t exactOn
    · exact cover67 t exactOn
    · exact cover78 t exactOn
  exact lower.trans ((specialize_cost _ _).trans ((CircuitCompiler.compile_cost 11 C).trans_eq
    (DualPhysical.price 10 D.gates)))
end PEqualNP.Outside.L_meta_9822.Sectors.PairFace
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.PairFace.four_ands
