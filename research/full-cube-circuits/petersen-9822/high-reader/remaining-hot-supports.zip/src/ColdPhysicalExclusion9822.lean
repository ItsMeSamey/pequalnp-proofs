import ColdFirstPlain9822
import ColdFirstArms9822
import PairedGraph9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport
open PEqualNP.Outside.L_meta_9822.Clean

theorem all_cold_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (reduced : Reduced 10 C.gates C.output)
    (cold : ∀ j, innerValue pre g (SignedClamp.singleton j)=false) : False := by
  obtain ⟨a,b,t,head,ap,bp⟩ := cold_first_plain r cand seven reduced
  exact paired_graph_contradiction r cand seven cold head ap bp
    (plain_big ap bp (cold_first_incomparable r cand seven cold head))

theorem physical_hot_singleton {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (reduced : Reduced 10 C.gates C.output) :
    ∃ j, innerValue pre g (SignedClamp.singleton j)=true := by
  by_contra! no
  apply all_cold_impossible r cand seven reduced
  intro j
  cases h : innerValue pre g (SignedClamp.singleton j) <;> simp_all
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.all_cold_impossible
