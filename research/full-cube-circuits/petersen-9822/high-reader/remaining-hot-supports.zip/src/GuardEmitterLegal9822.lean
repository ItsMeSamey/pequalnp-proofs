import GuardEmitterRun9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
open PEqualNP.CircuitLowerBounds
def Legal (p : Block) : Prop := ∀ g∈p.code, Ok g
theorem seq_ok (p : Block) (next : Stat → Block) (ha : Legal p) (hb : Legal (next p.result)) :
    Legal (seq p next) := by
  intro g hg
  exact (List.mem_append.mp hg).elim (ha g) (hb g)
theorem repair_ok (n z : Nat) (r : Reg) : Legal (repair n z r) := by
  unfold repair
  split
  · exact one_ok _ _ _ _
  · intro g hg; contradiction
theorem block_ok (n z : Nat) (rs : List Reg) (g : Gate) : Legal (block n z rs g).2 := by
  unfold block actual
  split
  · exact one_ok _ _ _ _
  · dsimp only
    split
    · apply seq_ok
      · apply one_ok
      · apply one_ok
    · apply seq_ok
      · apply repair_ok
      · apply seq_ok
        · apply repair_ok
        · apply one_ok
theorem go_ok (gs : List Gate) (n z : Nat) (rs : List Reg) :
    ∀ g∈(go n z rs gs).1, Ok g := by
  induction gs generalizing n rs with
  | nil => simp [go]
  | cons g gs ih =>
    intro q h
    rcases List.mem_append.mp h with a|b
    · exact block_ok n z rs g q a
    · exact ih _ _ q b
end PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter.go_ok
