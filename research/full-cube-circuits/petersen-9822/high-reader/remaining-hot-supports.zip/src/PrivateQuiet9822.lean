import PairSignalRelations9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem distinct_and_pins {n gs o} (red : Reduced n gs o) (k : Nat) (q : Gate)
    (site : gs[k]?=some q) (op : q.op=.and) (a b : Nat) (pins : q.inputs=[a,b]) : a≠b := by
  rintro rfl
  have m : a∈q.inputs := by simp [pins]
  apply red.noAlias k (reads_len ⟨q,site,m⟩) a ((red.clean k q site).lt a m)
  intro x
  rw [vl_gate _ red.clean _ k q site,op,pins]
  simp [GateOp.eval]
theorem quiet_except {C pre post g} (r : Roster C pre post g)
    (red : Reduced 10 C.gates C.output)
    (noOr : ∀q∈C.gates,q.op=.or → 10+pre.length∉q.inputs) :
    ∀ j,j≠10+pre.length → vl C.gates (fun _ => false : Input) j=false := by
  intro j
  induction j using Nat.strong_induction_on with
  | ind j prev =>
    intro diff
    by_cases lt : j<10
    · exact vl_input _ _ _ lt
    let k := j-10
    have id : j=10+k := by dsimp [k];omega
    by_cases range : k<C.gates.length
    · let q := C.gates[k]
      have site : C.gates[k]?=some q := List.getElem?_eq_getElem range
      have neq : k≠pre.length := by omega
      have ext : q∈pre++post := by
        rw [r.split] at site
        by_cases before : k<pre.length
        · apply List.mem_append_left; exact List.mem_iff_getElem?.mpr ⟨k,by simpa [List.getElem?_append,before] using site⟩
        · apply List.mem_append_right
          obtain ⟨m,eq⟩ : ∃ m,k=pre.length+(m+1) := ⟨k-pre.length-1,by omega⟩
          exact List.mem_iff_getElem?.mpr ⟨m,by simpa [eq,List.getElem?_append] using site⟩
      have pos := r.pos q ext
      rcases red.clean k q site with ⟨no,_⟩|⟨_,a,b,al,bl,pins⟩
      · rcases pos with h|h <;> simp_all
      rw [id,vl_gate _ red.clean _ k q site,pins]
      rcases pos with h|h
      · have neqAB := distinct_and_pins red k q site h a b pins
        by_cases aZ : a=10+pre.length
        · have bf := prev b (by omega) (by omega)
          simp [h,GateOp.eval,bf]
        · have af := prev a (by omega) aZ
          simp [h,GateOp.eval,af]
      · have never := noOr q (List.mem_iff_getElem?.mpr ⟨k,site⟩) h
        have af := prev a (by omega) (fun e => never (by simp [pins,e]))
        have bf := prev b (by omega) (fun e => never (by simp [pins,e]))
        simp [h,GateOp.eval,af,bf]
    · exact List.getD_eq_default _ _ (by rw [length_wiresFrom,List.length_ofFn];omega)
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.quiet_except
