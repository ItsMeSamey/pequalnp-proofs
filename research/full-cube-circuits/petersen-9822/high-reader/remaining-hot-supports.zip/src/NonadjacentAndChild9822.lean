import PairNonadjacentPorts9822
import ForcedOrStatus9822
import FourSiteCount9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
theorem and_child_mask {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s t : V) (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V)))
    (guard : ∀ x : Input,innerValue pre g x=(x s || x t)) (p tail : List Gate)
    (whole : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length])
    (ord : p.length<pre.length) (k : Nat) (u : Gate) (uk : C.gates[k]?=some u)
    (uo : u.op=.or) (upin : 10+pre.length∈u.inputs)
    (w : Gate) (mw : w∈C.gates) (wo : w.op=.and) (wp : 10+p.length∈w.inputs)
    (d : Gate) (md : d∈C.gates) (do' : d.op=.and) (dp : 10+k∈d.inputs) :
    s.val∈d.inputs ∨ t.val∈d.inputs ∨ 10+p.length∈d.inputs := by
  classical
  by_contra! no
  have ranges : s≠t ∧ 5≤s.val ∧ s.val≤8 ∧ 5≤t.val ∧ t.val≤8 := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  obtain ⟨st,sl,su,tl,tu⟩ := ranges
  obtain ⟨a,ma,b,mb,ab,ao,bo,ra,rb⟩ :=
    two_external_ands r cand red (by omega) s t st sl su tl tu guard p tail whole unary
  obtain ⟨j,wj⟩ := List.mem_iff_getElem?.mp mw
  have mask := (no_pair_and_overlap r red s t p tail whole unary ord w j wj wo).1 wp
  have aw : a≠w := fun e => mask.1 (e ▸ ra)
  have bw : b≠w := fun e => mask.2.1 (e ▸ rb)
  have ad : a≠d := fun e => no.1 (e ▸ ra)
  have bd : b≠d := fun e => no.2.1 (e ▸ rb)
  have wd : w≠d := fun e => no.2.2 (e ▸ wp)
  let F := foldZero C {s,t}
  let mark := fun q : Gate => decide (q.op=.and ∧ ∃ j∈q.inputs,∃ b : Bool,F.1.getD j (Sum.inl false)=Sum.inl b)
  have hs := literal_zero_status s t p tail whole
  have zu := neg_one_status s t p tail pre post g whole r.split unary r.inv ord
  have zz := next_one red.clean {s,t} k u uk uo ⟨_,upin,zu⟩
  have many := count_four_sites C.gates mark a b w d ab aw ad bw bd wd ma mb mw md
    (decide_eq_true ⟨ao,_,ra,false,raw_zero_status C {s,t} s (by simp)⟩)
    (decide_eq_true ⟨bo,_,rb,false,raw_zero_status C {s,t} t (by simp)⟩)
    (decide_eq_true ⟨wo,_,wp,false,hs⟩) (decide_eq_true ⟨do',_,dp,true,zz⟩)
  apply four_fold_impossible C cand red.clean (by omega) s t shape mark many
  · exact fun _ _ h => of_decide_eq_true h
  · intro q m qnot
    have eq : q=g := by
      by_contra ne
      rw [r.split] at m
      have pos := r.pos q (by simpa [List.mem_append,ne] using m)
      rcases pos with e|e <;> simp_all
    subst q
    exact ⟨10+p.length,by simp [unary],false,hs⟩
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.and_child_mask
