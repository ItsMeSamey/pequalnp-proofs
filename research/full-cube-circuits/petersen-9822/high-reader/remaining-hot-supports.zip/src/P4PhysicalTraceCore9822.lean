import P4PhysicalBank9822
namespace Research.Graph9822.P4Guard
open FreeAndNet

def good (B : List Mask) := !(B.contains goal && B.any hot)
def safe (B : List Mask) : Nat → Bool
  | 0 => good B
  | n+1 => good B && (joins B).all fun a => safe (extend B a) n
theorem next_models {env : Fin 8 → α → Bool} {B : List Mask} (h : Models env B)
    (closed : Closed B) (a b : List α) :
    ∃ m ∈ joins B, Models (fun i (x : Option α) =>
      x.elim (a.all (env i) || b.all (env i)) (env i)) (extend B m) := by
  obtain ⟨p,hp,ep⟩ := product_modeled closed h (some a)
  obtain ⟨q,hq,eq⟩ := product_modeled closed h (some b)
  refine ⟨p ||| q,?_,?_⟩
  · apply List.mem_eraseDups.mpr
    exact List.mem_flatMap.mpr ⟨p,hp,List.mem_map.mpr ⟨q,hq,rfl⟩⟩
  · intro x
    cases x with
    | none =>
      refine ⟨p ||| q,mem_extend.mpr (.inr ⟨255,closed.1,by
        apply BitVec.eq_of_getLsbD_eq
        intro i hi
        have ones := (by decide +kernel : ∀ k : Fin 8, (255 : Mask).getLsbD k.val = true) ⟨i,hi⟩
        change (255 : Mask).getLsbD i = true at ones
        rw [BitVec.getLsbD_and,ones,Bool.true_and]⟩),?_⟩
      intro i
      change (a.all (env i) || b.all (env i)) = (p ||| q).getLsbD i.val
      rw [BitVec.getLsbD_or,← ep i,← eq i]; rfl
    | some x =>
      obtain ⟨m,hm,e⟩ := h x
      exact ⟨m,mem_extend.mpr (.inl hm),e⟩

theorem masks_unique {a b : Mask} (h : ∀ i : Fin 8, a.getLsbD i.val = b.getLsbD i.val) :
    a = b := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  exact h ⟨i,hi⟩

theorem no_p4_sync {t w : Net α} (h : SameSites t w) {env : Fin 8 → α → Bool}
    {B : List Mask} {n : Nat} (model : Models env B) (closed : Closed B)
    (guard : safe B n = true) (cost : t.cost ≤ n)
    (out : ∀ i : Fin 8, t.eval (env i) = goal.getLsbD i.val)
    (warm : ∀ m : Mask, (∀ i : Fin 8, w.eval (env i) = m.getLsbD i.val) → hot m = true) : False := by
  induction h generalizing n B with
  | out p q =>
    obtain ⟨x,hx,ex⟩ := product_modeled closed model p
    obtain ⟨y,hy,ey⟩ := product_modeled closed model q
    have e : x=goal := masks_unique (fun i => (ex i).symm.trans (out i))
    subst x
    have g : good B = true := by
      cases n with
      | zero => exact guard
      | succ n => exact (Bool.and_eq_true_iff.mp guard).1
    have a := List.any_eq_true.mpr ⟨y,hy,warm y ey⟩
    simp [good,hx,a] at g
  | gate a b h ih =>
    cases n with
    | zero => simp [Net.cost] at cost
    | succ n =>
      obtain ⟨m,hm,models⟩ := next_models model closed a b
      exact ih models (closed_extend closed m)
        (List.all_eq_true.mp (Bool.and_eq_true_iff.mp guard).2 m hm)
        (by simpa [Net.cost] using cost) out warm

end Research.Graph9822.P4Guard
