import PinStatusSignals9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean ReaderDebit
theorem next_one {C : Circuit} (cl : CleanL 10 C.gates) (S : Finset V)
    (k : Nat) (q : Gate) (site : C.gates[k]?=some q) (op : q.op=.or)
    (used : ∃ j∈q.inputs,(foldZero C S).1.getD j (Sum.inl false)=Sum.inl true) :
    (foldZero C S).1.getD (10+k) (Sum.inl false) = Sum.inl true := by
  obtain ⟨m,hm⟩ := site_status cl S k q site
  obtain ⟨j,mem,pin⟩ := used
  rcases cl k q site with ⟨no,_⟩|⟨_,a,b,_,_,ins⟩
  · simp_all
  rw [ins] at mem
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  let atWire := fun j => (foldZero C S).1.getD j (Sum.inl false)
  rw [hm,op,ins]
  change (simpOr m [atWire a,atWire b]).2 = Sum.inl true
  change atWire j = Sum.inl true at pin
  rcases mem with e|e
  · subst j; rw [pin]; cases h : atWire b <;> rfl
  · subst j; rw [pin]; cases h : atWire a with
    | inl b => cases b <;> rfl
    | inr i => rfl
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.next_one
