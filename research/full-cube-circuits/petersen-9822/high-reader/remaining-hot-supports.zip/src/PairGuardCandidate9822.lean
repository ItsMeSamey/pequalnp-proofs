import PairGuardReplace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean

theorem literal_pair_candidate {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (s t : Fin 10) (st : s≠t) (eq : ∀ v : Input, innerValue pre g v = (v s || v t)) :
    ∃ (D : Circuit) (p q : List Gate) (old : Gate),
      pre = p ++ old :: q ∧
      Roster D (p ++ literalGate s t :: q) post g ∧
      g.inputs.head? = some (10+p.length) ∧ Candidate D ∧ D.size = C.size ∧
      D.gates.countP countsAnd + (countsAnd old).toNat = C.gates.countP countsAnd := by
  obtain ⟨p,old,q,split,idx,wires⟩ := replace_pair_guard pre g s t st eq
  let D : Circuit := ⟨(p ++ literalGate s t :: q) ++ g :: post,C.output⟩
  have orig := r.split
  rw [split] at orig
  have size : D.size = C.size := by
    change ((p ++ literalGate s t :: q) ++ g :: post).length = C.gates.length
    rw [orig]
    simp
  have lift (a : Gate) (h : a ∈ D.gates) : a = literalGate s t ∨ a ∈ C.gates := by
    change a ∈ (p ++ literalGate s t :: q) ++ g :: post at h
    rw [orig]
    simp only [List.mem_append,List.mem_cons] at h ⊢
    tauto
  have pos (a : Gate) (h : a ∈ (p ++ literalGate s t :: q) ++ post) : PositiveOp a := by
    by_cases e : a=literalGate s t
    · subst a; exact Or.inr rfl
    · apply r.pos
      rw [split]
      simp only [List.mem_append,List.mem_cons] at h ⊢
      tauto
  refine ⟨D,p,q,old,split,⟨rfl,r.inv,pos⟩,idx,⟨?_,size.trans_le cand.2.1,?_⟩,size,?_⟩
  · intro a ha
    rcases lift a ha with rfl | hold
    · exact ⟨by simp [literalGate],by simp [literalGate]⟩
    · exact cand.1 a hold
  · intro v
    change (wiresFrom ((p ++ literalGate s t :: q) ++ g :: post) (List.ofFn v)).getD _ false = _
    rw [wiresFrom_append,wires]
    have comp := cand.2.2 v
    change (wiresFrom C.gates (List.ofFn v)).getD _ false = _ at comp
    rwa [r.split,wiresFrom_append] at comp
  · change (((p ++ literalGate s t :: q) ++ g :: post).countP countsAnd) + _ = _
    rw [orig]
    have fresh : countsAnd (literalGate s t) = false := rfl
    cases e : countsAnd old <;> simp [List.countP_append,List.countP_cons,e,fresh] <;> omega

end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.literal_pair_candidate
