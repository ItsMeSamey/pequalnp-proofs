import PairRawSeparation9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean

theorem swap_suffix (gs : List Gate) (w u : List Bool) (s t : Nat)
    (both : ∀ q∈gs, s∈q.inputs ∨ t∈q.inputs →
      (q.op=.or ∨ q.op=.and) ∧ (q.inputs=[s,t] ∨ q.inputs=[t,s]))
    (size : w.length=u.length) (rs : s<w.length) (rt : t<w.length)
    (swapS : w.getD s false=u.getD t false) (swapT : w.getD t false=u.getD s false)
    (away : ∀ j, j≠s → j≠t → w.getD j false=u.getD j false) :
    ∀ j, j≠s → j≠t → (wiresFrom gs w).getD j false=(wiresFrom gs u).getD j false := by
  induction gs generalizing w u with
  | nil => exact away
  | cons g tail ih =>
    let a := g.op.eval (g.inputs.map fun j => w.getD j false)
    let b := g.op.eval (g.inputs.map fun j => u.getD j false)
    have eq : a=b := by
      by_cases hit : s∈g.inputs ∨ t∈g.inputs
      · obtain ⟨op,ins⟩ := both g List.mem_cons_self hit
        change w[s]?.getD false=u[t]?.getD false at swapS
        change w[t]?.getD false=u[s]?.getD false at swapT
        rcases op with op|op <;> rcases ins with ins|ins <;>
          simp [a,b,op,ins,GateOp.eval,swapS,swapT,Bool.or_comm,Bool.and_comm]
      · apply congrArg g.op.eval
        exact List.map_congr_left fun j mem => away j (fun e => hit (Or.inl (e ▸ mem)))
          (fun e => hit (Or.inr (e ▸ mem)))
    apply ih (w++[a]) (u++[b]) (fun q hq => both q (List.mem_cons_of_mem _ hq))
    · simp [size]
    · simp; omega
    · simp; omega
    · rwa [List.getD_append _ _ _ _ rs,List.getD_append _ _ _ _ (by omega : t<u.length)]
    · rwa [List.getD_append _ _ _ _ rt,List.getD_append _ _ _ _ (by omega : s<u.length)]
    · intro j ds dt
      by_cases last : j=w.length
      · rw [last,getD_snoc_eq,size,getD_snoc_eq]; exact eq
      · rw [getD_snoc_ne _ _ _ _ last,getD_snoc_ne _ _ _ _ (by omega)]
        exact away j ds dt

private theorem distinguish : ∀ s t : Fin 10, s≠t → ∃ j : Fin 10,
    j≠s ∧ j≠t ∧ edge (pair s j)≠edge (pair t j) := by decide +kernel
theorem asymmetric_owner {C : Circuit} (cand : Candidate C) (s t : Fin 10) (st : s≠t) :
    ∃ q∈C.gates, (s.val∈q.inputs ∨ t.val∈q.inputs) ∧
      ¬((q.op=.or ∨ q.op=.and) ∧ (q.inputs=[s.val,t.val] ∨ q.inputs=[t.val,s.val])) := by
  classical
  by_contra no
  have both : ∀ q∈C.gates, s.val∈q.inputs ∨ t.val∈q.inputs →
      (q.op=.or ∨ q.op=.and) ∧ (q.inputs=[s.val,t.val] ∨ q.inputs=[t.val,s.val]) := by
    intro q h read
    by_contra wrong
    exact no ⟨q,h,read,wrong⟩
  obtain ⟨j,js,jt,diff⟩ := distinguish s t st
  let x := pair s j
  let y := pair t j
  have off (i : Fin 10) : C.output≠i.val := by
    intro eq
    have h := cand.2.2 (SignedClamp.singleton i)
    change (wiresFrom C.gates (List.ofFn (SignedClamp.singleton i))).getD C.output false=edge (SignedClamp.singleton i) at h
    rw [eq,getD_wiresFrom _ _ _ (by simp),getD_ofFn 10 _ false i] at h
    have cold : ∀ i : Fin 10, edge (SignedClamp.singleton i)=false := by decide +kernel
    simp [cold,SignedClamp.singleton] at h
  have away : ∀ k : Nat, k≠s.val → k≠t.val → (List.ofFn x).getD k false=(List.ofFn y).getD k false := by
    intro k ks kt
    by_cases hk : k<10
    · let i : Fin 10 := ⟨k,hk⟩
      have ns : i≠s := fun h => ks (congrArg Fin.val h)
      have nt : i≠t := fun h => kt (congrArg Fin.val h)
      change (List.ofFn x).getD i.val false=(List.ofFn y).getD i.val false
      rw [getD_ofFn 10 x false i,getD_ofFn 10 y false i]
      simp [x,y,pair,SignedClamp.singleton,ns,nt]
    · rw [List.getD_eq_default _ _ (n:=k) (by simp;omega),
          List.getD_eq_default _ _ (n:=k) (by simp;omega)]
  have eq := swap_suffix C.gates (List.ofFn x) (List.ofFn y) s.val t.val
    both
    (by simp) (by simp) (by simp)
    (by rw [getD_ofFn 10 x false s,getD_ofFn 10 y false t];simp [x,y,pair,SignedClamp.singleton])
    (by rw [getD_ofFn 10 x false t,getD_ofFn 10 y false s];simp [x,y,pair,SignedClamp.singleton,st,Ne.symm st,Ne.symm js,Ne.symm jt])
    away C.output (off s) (off t)
  exact diff ((cand.2.2 x).symm.trans (eq.trans (cand.2.2 y)))
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.asymmetric_owner
