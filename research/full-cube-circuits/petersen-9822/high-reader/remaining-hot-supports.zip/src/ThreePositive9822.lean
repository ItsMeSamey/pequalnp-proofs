import GuardTrace9822

namespace Research.OddOr
open FreeAndNet

def ThreeImpl (a b c d : Bool) := a = true → b = true → c = true → d = true
def PairImpl (a b c d : Bool) := (a = true → b = true → d = true) ∧
  (a = true → c = true → d = true) ∧ (b = true → c = true → d = true)

private theorem all3 {α} (p : List α) {a b c d : α → Bool}
    (h : ∀ i, ThreeImpl (a i) (b i) (c i) (d i)) :
    ThreeImpl (p.all a) (p.all b) (p.all c) (p.all d) := by
  intro ha hb hc
  simp only [List.all_eq_true] at *
  exact fun i hi => h i (ha i hi) (hb i hi) (hc i hi)

private theorem all2 {α} (p : List α) {a b c d : α → Bool}
    (h : ∀ i, PairImpl (a i) (b i) (c i) (d i)) :
    PairImpl (p.all a) (p.all b) (p.all c) (p.all d) := by
  unfold PairImpl
  simp only [List.all_eq_true]
  exact ⟨fun ha hb i hi => (h i).1 (ha i hi) (hb i hi),
    fun ha hc i hi => (h i).2.1 (ha i hi) (hc i hi),
    fun hb hc i hi => (h i).2.2 (hb i hi) (hc i hi)⟩

private theorem triple_cost {α : Type} (t : Net α) (a b c d : α → Bool)
    (h : ∀ i, ThreeImpl (a i) (b i) (c i) (d i))
    (ha : t.eval a = true) (hb : t.eval b = true) (hc : t.eval c = true)
    (hd : t.eval d = false) : 2 ≤ hotCount a t + hotCount b t := by
  induction t with
  | out p =>
    cases p with
    | none => contradiction
    | some p => exact Bool.noConfusion (hd.symm.trans (all3 p h ha hb hc))
  | gate p q tail ih =>
    by_cases bit : ThreeImpl (p.all a || q.all a) (p.all b || q.all b)
        (p.all c || q.all c) (p.all d || q.all d)
    · have lower := ih _ _ _ _ (fun i => by cases i with
                                             | none => exact bit
                                             | some i => exact h i) ha hb hc hd
      simp only [hotCount]
      omega
    · have bits : (p.all a || q.all a) = true ∧ (p.all b || q.all b) = true := by
        unfold ThreeImpl at bit
        push_neg at bit
        exact ⟨bit.1,bit.2.1⟩
      simp only [hotCount,bits.1,bits.2,Bool.toNat_true]
      omega

theorem disjoint_three_cost {α : Type} (t : Net α) (a b c d : α → Bool)
    (h : ∀ i, PairImpl (a i) (b i) (c i) (d i))
    (ha : t.eval a = true) (hb : t.eval b = true) (hc : t.eval c = true)
    (hd : t.eval d = false) : 3 ≤ hotCount a t + hotCount b t := by
  induction t with
  | out p =>
    cases p with
    | none => contradiction
    | some p => exact Bool.noConfusion (hd.symm.trans ((all2 p h).1 ha hb))
  | gate p q tail ih =>
    let A := p.all a || q.all a
    let B := p.all b || q.all b
    let C := p.all c || q.all c
    let D := p.all d || q.all d
    by_cases bit : PairImpl A B C D
    · have lower := ih _ _ _ _ (fun i => by cases i with
                                             | none => exact bit
                                             | some i => exact h i) ha hb hc hd
      simp only [hotCount]
      omega
    · have combine : ∀ l m n o r s u v : Bool, PairImpl l m n o → PairImpl r s u v →
          ThreeImpl (l||r) (m||s) (n||u) (o||v) := by
          unfold PairImpl ThreeImpl
          decide
      have keep := combine _ _ _ _ _ _ _ _ (all2 p h) (all2 q h)
      have lower := triple_cost tail _ _ _ _ (fun i => by cases i with
                                                        | none => exact keep
                                                        | some i => exact fun x y _ => (h i).1 x y) ha hb hc hd
      have surcharge : ∀ A B C D : Bool, ¬PairImpl A B C D → 1 ≤ A.toNat+B.toNat := by
        unfold PairImpl
        decide
      have pay := surcharge A B C D bit
      dsimp [A,B] at pay
      simp only [hotCount]
      omega

end Research.OddOr
#print axioms Research.OddOr.disjoint_three_cost
