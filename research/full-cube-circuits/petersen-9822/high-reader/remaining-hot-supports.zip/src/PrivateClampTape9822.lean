import PrivateClampLedger9822
import PhysicalClampInputs9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean
theorem snoc_agree_off (w u : List Bool) (j : Nat) (v : Bool)
    (len : w.length=u.length) (eq : ∀ i, i≠j → w.getD i false=u.getD i false) :
    ∀ i,i≠j → (w++[v]).getD i false=(u++[v]).getD i false := by
  intro i diff
  by_cases h : i=w.length
  · rw [h,getD_snoc_eq,len,getD_snoc_eq]
  · rw [getD_snoc_ne _ _ _ _ h,getD_snoc_ne _ _ _ _ (by omega)]
    exact eq i diff
theorem ignore_wire (gs : List Gate) (j : Nat) (w u : List Bool)
    (no : ∀ q∈gs,j∉q.inputs) (len : w.length=u.length)
    (eq : ∀ i,i≠j → w.getD i false=u.getD i false) :
    ∀ i,i≠j → (wiresFrom gs w).getD i false=(wiresFrom gs u).getD i false := by
  induction gs generalizing w u with
  | nil => exact eq
  | cons q tail ih =>
    have val : q.op.eval (q.inputs.map fun i => w.getD i false)=q.op.eval (q.inputs.map fun i => u.getD i false) := by
      apply congrArg q.op.eval
      exact List.map_congr_left (fun i mem => eq i (fun e => no q (by simp) (e ▸ mem)))
    change ∀ i,i≠j → (wiresFrom tail (w++[_])).getD i false=(wiresFrom tail (u++[_])).getD i false
    rw [val]
    exact ih _ _ (fun a m => no a (by simp [m])) (by simp [len]) (snoc_agree_off _ _ _ _ len eq)
def clampValues (p mid post : List Gate) (x : Input) :=
  wiresFrom post ((wiresFrom mid ((wiresFrom p (List.ofFn x))++[false]))++[true])
theorem clamp_matches {p mid post : List Gate} {h : Gate} (i : Nat) (x : Input)
    (priv : ∀ q∈mid++post,10+p.length∉q.inputs) (away : i≠10+p.length) :
    (clampValues p mid post x).getD i false=outerValue (p++h::mid) post i x true := by
  let w := wiresFrom p (List.ofFn x)
  let j := 10+p.length
  have len : w.length=j := by simp [w,j,length_wiresFrom]
  let b := h.op.eval (h.inputs.map fun k => w.getD k false)
  have midEq := ignore_wire mid j (w++[false]) (w++[b])
    (fun g m => priv g (List.mem_append_left _ m)) (by simp) (by
      intro k ne
      rw [getD_snoc_ne _ _ _ _ (by omega),getD_snoc_ne _ _ _ _ (by omega)])
  have postEq := ignore_wire post j ((wiresFrom mid (w++[false]))++[true])
    ((wiresFrom mid (w++[b]))++[true]) (fun g m => priv g (List.mem_append_right _ m))
    (by simp [length_wiresFrom]) (snoc_agree_off _ _ j true (by simp [length_wiresFrom]) midEq)
  unfold outerValue
  rw [wiresFrom_append]
  exact postEq i away
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.clamp_matches
