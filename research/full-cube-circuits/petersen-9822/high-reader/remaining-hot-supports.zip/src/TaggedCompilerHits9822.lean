import PhysicalGuardTags9822
import OuterNet9822

namespace PEqualNP.Outside.L_meta_9822.Clean.GuardTags
open PEqualNP.CircuitLowerBounds FreeAndNet FreeAndNet.CircuitCompiler

/-- The inserted formal-source copy is a unary AND; only physical ORs must
have exactly two valid predecessors. -/
def TaggedWiring : Nat → List Gate → Prop
  | _, [] => True
  | n, g::gs =>
    (∀ j ∈ g.inputs, j<n) ∧
    (orFlag g = true → ∃ a b, g.inputs=[a,b]) ∧ TaggedWiring (n+1) gs

def markedTrace (out : Nat) : List Gate → List Bool → Nat × Bool
  | [], w => (0,w.getD out false)
  | g::gs,w =>
    let inputs := g.inputs.map (fun j => w.getD j false)
    let flag := inputs.any id
    let t := markedTrace out gs (w++[if orFlag g then false else flag])
    (t.1 + if orFlag g && flag then 1 else 0,t.2)

private theorem read_some {α : Type} (w : List (List α)) (j : Nat) (hj : j<w.length) :
    (w.map some).getD j none = some w[j] := by simp [List.getD_eq_getElem?_getD,hj]

private theorem read_mark {α : Type} [DecidableEq α] (w : List (List α)) (i : α)
    (j : Nat) (hj : j<w.length) :
    (w.map (fun p => decide (i ∈ p))).getD j false = decide (i ∈ w[j]) := by
  simp [List.getD_eq_getElem?_getD,hj]

private theorem product_marks {α : Type} [DecidableEq α] (w : List (List α)) (i : α)
    (ins : List Nat) (legal : ∀ j ∈ ins, j<w.length) :
    ∃ p, substProduct (fun j => (w.map some).getD j none) ins = some p ∧
      decide (i ∈ p) = (ins.map fun j => (w.map (fun q => decide (i ∈ q))).getD j false).any id := by
  induction ins with
  | nil => exact ⟨[],rfl,by simp⟩
  | cons j js ih =>
    have hj := legal j List.mem_cons_self
    obtain ⟨p,hp,hm⟩ := ih (fun k hk => legal k (List.mem_cons_of_mem j hk))
    refine ⟨w[j]++p,?_,?_⟩
    · simp only [substProduct,read_some w j hj,hp]
    · simp only [List.mem_append,List.map_cons,List.any_cons,id_eq,read_mark w i j hj]
      rw [← hm]
      by_cases x : i ∈ w[j] <;> simp [x]

theorem run_marks (out : Nat) (gs : List Gate) :
    ∀ {α : Type} [DecidableEq α] (w : List (List α)) (i : α)
      (_ : TaggedWiring w.length gs),
    let t := CircuitCompiler.run out gs (w.map some)
    let trace := markedTrace out gs (w.map (fun q => decide (i ∈ q)))
    trace.1 = hits i t ∧ (trace.2 = true ↔ outUses i t) := by
  induction gs with
  | nil =>
    intro α inst w i ok
    by_cases bound : out < w.length
    · simp only [markedTrace,CircuitCompiler.run,hits,outUses,read_some w out bound,read_mark w i out bound]; simp
    · have le := Nat.le_of_not_gt bound
      simp [markedTrace,CircuitCompiler.run,hits,outUses,List.getD_eq_getElem?_getD,
        List.getElem?_eq_none (by simpa using le : (w.map some).length ≤ out),
        List.getElem?_eq_none (by simpa using le :
          (w.map (fun q => decide (i ∈ q))).length ≤ out)]
  | cons g gs ih =>
    intro α inst w i ok
    obtain ⟨legal,binary,tail⟩ := ok
    cases hg : orFlag g with
    | false =>
      obtain ⟨p,hp,hm⟩ := product_marks w i g.inputs legal
      have recurResult := ih (w++[p]) i (by simpa using tail)
      simp only [markedTrace,CircuitCompiler.run,hg,ite_false,hp,Bool.false_and,
        Bool.false_eq_true,Nat.add_zero]
      simpa only [List.map_append,List.map_cons,List.map_nil,hm] using recurResult
    | true =>
      obtain ⟨a,b,ins⟩ := binary hg
      have ha := legal a (by simp [ins])
      have hb := legal b (by simp [ins])
      let u : List (List (Option α)) := (w.map (List.map some)) ++ [[none]]
      have recurResult := ih u (some i) (by simpa [u] using tail)
      have tags : u.map (fun q => decide (some i ∈ q)) =
          w.map (fun q => decide (i ∈ q)) ++ [false] := by
        simp [u,List.map_map,Function.comp_def]
      have values : u.map some = (w.map some).map liftP ++ [some [none]] := by
        simp [u,liftP,List.map_map,Function.comp_def]
      dsimp only at recurResult
      simp only [u,List.map_append,List.map_cons,List.map_nil,List.map_map,liftP,Function.comp_def] at recurResult
      simp at recurResult
      simp [markedTrace,CircuitCompiler.run,hg,ins,List.getD,read_some w a ha,
        read_some w b hb,orStep,hits,outUses,read_mark w i a ha,read_mark w i b hb,
        recurResult.1,recurResult.2] <;>
        simp [List.getElem?_eq_getElem ha,List.getElem?_eq_getElem hb,hits,outUses,liftP,Function.comp_def]

end PEqualNP.Outside.L_meta_9822.Clean.GuardTags
