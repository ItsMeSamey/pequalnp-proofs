import SignedClamp9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
open PEqualNP.CircuitLowerBounds SignedClamp
def setOwners (s t : Fin 10) (x : Input) (p q : Bool) : Input :=
  fun i => if i=s then p else if i=t then q else x i
theorem adjacent_rows : ∀ s t : Fin 10,
    (s,t) ∈ ([(5,7),(5,8),(6,8)] : List (Fin 10 × Fin 10)) →
    (∃ i : Fin 10,
       edge (setOwners s t (SignedClamp.singleton i) true false)=true ∧
       edge (setOwners s t (SignedClamp.singleton i) false true)=false ∧
       edge (setOwners s t (SignedClamp.singleton i) false false)=false) ∧
    (∃ i : Fin 10,
       edge (setOwners s t (SignedClamp.singleton i) true false)=false ∧
       edge (setOwners s t (SignedClamp.singleton i) false true)=true ∧
       edge (setOwners s t (SignedClamp.singleton i) false false)=false) ∧
    edge (setOwners s t (fun _ => false) true false)=false ∧
    edge (setOwners s t (fun _ => false) false true)=false ∧
    edge (setOwners s t (fun _ => false) true true)=true := by decide +kernel
end PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.AdjacentCut.adjacent_rows
