import OR9822Base
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Order.BigOperators.Group.Finset

/- BEGIN OR9822Debit.lean -/
namespace Research.OddOr
open FreeAndNet

/-- A physical witness may lie behind any number of endpoint-only OR gates. -/
inductive DoubleLoss : {α : Type} → (i : α) → Net α → Prop
  | here {α : Type} {i : α} (a b : List α) (t : Net (Option α)) (left : i ∈ a) (right : i ∈ b)
      (later : 0 < hits none t) : DoubleLoss i (.gate a b t)
  | tail {α : Type} {i : α} (a b : List α) (t : Net (Option α)) (inner : DoubleLoss (some i) t) :
      DoubleLoss i (.gate a b t)

theorem DoubleLoss.positive {α : Type} (i : α) (t : Net α) (cert : DoubleLoss i t) :
    0 < hits i t := by
  classical
  induction cert with
  | here a b t ha hb later => simp [hits,ha]
  | tail a b t inner ih =>
    simp only [hits]
    omega

theorem DoubleLoss.saves {α β : Type} (i : α) (t : Net α) (cert : DoubleLoss i t)
    (s : α → Product β) (dead : s i = none) : (specialize s t).cost + 2 ≤ t.cost := by
  classical
  induction cert generalizing β with
  | here a b t ha hb later =>
    have left := subst_none dead a ha
    have right := subst_none dead b hb
    simp only [specialize,left,right,Net.cost]
    have debit := specialize_saves (none : Option _) (fun z => z.elim (none : Product β) s) rfl t
    omega
  | tail a b t inner ih =>
    have pos := DoubleLoss.positive _ _ inner
    have one (q : Product β) :
        (specialize (fun z : Option _ => z.elim q s) t).cost + 1 ≤ t.cost := by
      have save := specialize_saves (some _) (fun z : Option _ => z.elim q s) dead t
      omega
    simp only [specialize,Net.cost]
    cases ha : substProduct s a <;> cases hb : substProduct s b
    · exact Nat.succ_le_succ (one none)
    · rename_i q
      exact Nat.succ_le_succ (one (some q))
    · rename_i p
      exact Nat.succ_le_succ (one (some p))
    · simp only [Net.cost]
      have h := ih (fun z => z.elim (some [none]) (fun j => liftP (s j))) (by simp [liftP,dead])
      omega

end Research.OddOr
/- END OR9822Debit.lean -/

/- BEGIN OR9822Minimum.lean -/

namespace Research.OddOr
open FreeAndNet
open scoped BigOperators

def traceScore {α ι : Type} [Fintype ι] (samples : ι → α → Bool) (t : Net α) : Nat :=
  ∑ j, hotCount (samples j) t

def extendEnv {α σ : Type} (a b : List α) (env : σ → α → Bool) : σ → Option α → Bool :=
  fun s z => z.elim (a.all (env s) || b.all (env s)) (env s)

theorem score_gate {α ι : Type} [Fintype ι] (samples : ι → α → Bool) (a b : List α)
    (t : Net (Option α)) : traceScore samples (.gate a b t) =
      traceScore (extendEnv a b samples) t + ∑ j, (a.all (samples j) || b.all (samples j)).toNat := by
  simp only [traceScore,hotCount,Finset.sum_add_distrib]
  rfl

def Improves {α ι : Type} [Fintype ι] (samples : ι → α → Bool) (u t : Net α) :=
  u.cost < t.cost ∨ (u.cost ≤ t.cost ∧ traceScore samples u < traceScore samples t)

theorem Improves.prepend {α ι : Type} [Fintype ι] (a b : List α) (samples : ι → α → Bool)
    (u t : Net (Option α)) (h : Improves (extendEnv a b samples) u t) :
    Improves samples (.gate a b u) (.gate a b t) := by
  rcases h with h | ⟨le,lt⟩
  · exact Or.inl (Nat.succ_lt_succ h)
  · exact Or.inr ⟨Nat.succ_le_succ le,by simpa [score_gate] using lt⟩

theorem move_improves {α ι : Type} [Fintype ι] (samples : ι → α → Bool)
    (i : α) (ep a b : List α) (t : Net (Option α))
    (he : ∀ j, ep.all (samples j) = false)
    (hg : ∀ j, (a.all (samples j) || b.all (samples j)) = samples j i)
    (cold : ∀ j, (Net.gate a b t).eval (samples j) = false)
    (live : ∃ j, samples j i = true) :
    Improves samples (postpone i ep t) (.gate a b t) := by
  classical
  refine Or.inr ⟨postpone_cost i ep t,?_⟩
  have eq : traceScore samples (.gate a b t) = traceScore samples (postpone i ep t) +
      ∑ j, (samples j i).toNat := by
    simp only [traceScore,← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro j _
    exact (move_semantic_hot i ep a b t (samples j) (he j) (hg j) (cold j)).symm
  obtain ⟨j,hj⟩ := live
  have h : 1 ≤ ∑ k, (samples k i).toNat := by
    simpa [hj] using (Finset.single_le_sum (f := fun k => (samples k i).toNat)
      (fun _ _ => Nat.zero_le _) (Finset.mem_univ j))
  omega

theorem exists_minimal_net {α ι : Type} [Fintype ι] (samples : ι → α → Bool)
    (P : Net α → Prop) (t : Net α) (ht : P t) :
    ∃ u : Net α, P u ∧ u.cost ≤ t.cost ∧ ∀ v : Net α, P v → ¬Improves samples v u := by
  classical
  let ok : Nat → Prop := fun k => ∃ v : Net α, P v ∧ v.cost = k
  have ex : ∃ k, ok k := ⟨t.cost,t,ht,rfl⟩
  obtain ⟨w,hw,ew⟩ := Nat.find_spec ex
  let cool : Nat → Prop := fun k => ∃ v : Net α, P v ∧ v.cost = Nat.find ex ∧ traceScore samples v = k
  have ey : ∃ k, cool k := ⟨_,w,hw,ew,rfl⟩
  obtain ⟨u,hu,eu,es⟩ := Nat.find_spec ey
  refine ⟨u,hu,eu.trans_le (Nat.find_min' ex ⟨t,ht,rfl⟩),?_⟩
  intro v hv improve
  have cheap : Nat.find ex ≤ v.cost := Nat.find_min' ex ⟨v,hv,rfl⟩
  rcases improve with h | ⟨le,lt⟩
  · omega
  · have same : v.cost = Nat.find ex := by omega
    have min := Nat.find_min' ey (show cool (traceScore samples v) from ⟨v,hv,same,rfl⟩)
    omega

end Research.OddOr
/- END OR9822Minimum.lean -/

/- BEGIN OR9822Scan.lean -/
namespace Research.OddOr.Theta
open FreeAndNet

def Escape {κ α ι : Type} [Fintype ι] (samples : ι → Row κ) (s : State κ α) (t : Net α) :=
  (∃ u : Net α, (∀ x : Row κ, u.eval (val x ∘ s.atom) = t.eval (val x ∘ s.atom)) ∧
    Improves (fun j => val (samples j) ∘ s.atom) u t) ∨
  (∃ i : κ, DoubleLoss (s.read i) t)

theorem escape_lift {κ α ι : Type} [DecidableEq κ] [Fintype ι]
    (samples : ι → Row κ) (s : State κ α) (a b : List α) (t : Net (Option α))
    (ha : (product s.atom a).support = ∅) (hb : (product s.atom b).support = ∅)
    (h : Escape samples (s.push ((product s.atom a).ep.sup (product s.atom b).ep)) t) :
    Escape samples s (.gate a b t) := by
  rcases h with ⟨u,sem,better⟩ | ⟨i,loss⟩
  · left
    refine ⟨.gate a b u,?_,?_⟩
    · intro x
      simpa only [Net.eval,push_env s a b ha hb] using sem x
    · apply Improves.prepend
      have eq : extendEnv a b (fun j => val (samples j) ∘ s.atom) =
          (fun j => val (samples j) ∘ (s.push ((product s.atom a).ep.sup (product s.atom b).ep)).atom) := by
        funext j
        exact push_env s a b ha hb (samples j)
      rwa [eq]
  · exact Or.inr ⟨i,DoubleLoss.tail a b t loss⟩

/-- Scan across endpoint-only ORs without changing the identity of an internal
raw, the response on any row, or the full prefix needed for a later debit. -/
theorem scan {κ α ι : Type} [DecidableEq κ] [Fintype ι]
    (samples : ι → Row κ) (f : Row κ → Bool)
    (atGate : ∀ {β : Type} (s : State κ β) (a b : List β) (t : Net (Option β)),
      ((product s.atom a).support ≠ ∅ ∨ (product s.atom b).support ≠ ∅) →
      (∀ i, hits (s.read i) (.gate a b t) ≤ 1 ∧ ¬ outUses (s.read i) (.gate a b t)) →
      (∀ x, (Net.gate a b t).eval (val x ∘ s.atom) = f x) → Escape samples s (.gate a b t))
    (s : State κ α) (t : Net α)
    (live : ∃ i, 0 < hits (s.read i) t)
    (limited : ∀ i, hits (s.read i) t ≤ 1 ∧ ¬ outUses (s.read i) t)
    (sem : ∀ x, t.eval (val x ∘ s.atom) = f x) : Escape samples s t := by
  classical
  induction t with
  | out p =>
    obtain ⟨i,hi⟩ := live
    simp [hits] at hi
  | gate a b t ih =>
    by_cases ha : (product s.atom a).support = ∅
    · by_cases hb : (product s.atom b).support = ∅
      · apply escape_lift samples s a b t ha hb
        let v := (product s.atom a).ep.sup (product s.atom b).ep
        have absent (i : κ) : s.read i ∉ a ∧ s.read i ∉ b := by
          have arg (l : List _) (h : (product s.atom l).support = ∅) : s.read i ∉ l := by
            intro mem
            have inside := (product_mem s.atom l i).2 ⟨s.read i, mem, (s.raw_iff _ _).2 rfl⟩
            simpa [h] using inside
          exact ⟨arg a ha,arg b hb⟩
        have eq (i : κ) : hits (s.read i) (.gate a b t) = hits ((s.push v).read i) t := by
          simp [hits,(absent i).1,(absent i).2,State.push]
        apply ih (s.push v)
        · obtain ⟨i,hi⟩ := live
          exact ⟨i,by rwa [← eq]⟩
        · intro i
          exact ⟨(eq i) ▸ (limited i).1,(limited i).2⟩
        · intro x
          have h := sem x
          rw [Net.eval,push_env s a b ha hb] at h
          exact h
      · exact atGate s a b t (Or.inr hb) limited sem
    · exact atGate s a b t (Or.inl ha) limited sem

end Research.OddOr.Theta
/- END OR9822Scan.lean -/

/- BEGIN OR9822Census.lean -/
namespace Research.OddOr.Theta
open FreeAndNet

def CutBit {κ} (a b : Term κ) (x : Row κ) := termVal x a || termVal x b

def VariesOnly {κ} (i : κ) (x y : Row κ) :=
  x.l = y.l ∧ x.r = y.r ∧ ∀ j, j ≠ i → x.raw j = y.raw j

def CoversPivots {κ : Type} [DecidableEq κ] (f : Row κ → Bool) (a b : Term κ) :=
  ∀ i ∈ a.support ∪ b.support, ∀ x y : Row κ, VariesOnly i x y →
    f x ≠ f y → CutBit a b x ≠ CutBit a b y

theorem raw_agree {κ α : Type} (s : State κ α) {i : κ} {x y : Row κ}
    (delta : VariesOnly i x y) (z : α) (hz : z ≠ s.read i) :
    (val x ∘ s.atom) z = (val y ∘ s.atom) z := by
  cases hh : s.atom z with
  | ep e => simp [Function.comp_apply,hh,val,delta.1,delta.2.1]
  | raw j =>
    have ne : j ≠ i := by
      rintro rfl
      exact hz ((s.raw_iff _ _).1 hh)
    simpa [Function.comp_apply,hh,val] using delta.2.2 j ne

theorem cutbit_eq {κ α : Type} [DecidableEq κ] (s : State κ α) (a b : List α) (x : Row κ) :
    (a.all (val x ∘ s.atom) || b.all (val x ∘ s.atom)) =
      CutBit (product s.atom a) (product s.atom b) x := by
  simp only [CutBit,product_val]

theorem raw_read {κ α : Type} [DecidableEq κ] (s : State κ α) (a : List α) (i : κ) :
    i ∈ (product s.atom a).support ↔ s.read i ∈ a := by
  rw [product_mem]
  constructor
  · rintro ⟨z,h,eq⟩
    exact ((s.raw_iff _ _).mp eq) ▸ h
  · intro h
    exact ⟨_,h,(s.raw_iff _ _).2 rfl⟩

theorem no_second_read {κ α : Type} [DecidableEq κ] (s : State κ α) (a b : List α)
    (t : Net (Option α)) (i : κ) (hi : i ∈ (product s.atom a).support ∪ (product s.atom b).support)
    (limited : hits (s.read i) (.gate a b t) ≤ 1 ∧ ¬outUses (s.read i) (.gate a b t)) :
    hits (some (s.read i)) t = 0 ∧ ¬outUses (some (s.read i)) t := by
  classical
  have hmem : s.read i ∈ a ∨ s.read i ∈ b := by simpa [raw_read] using hi
  have h := limited.1
  simp [hits,hmem] at h
  exact ⟨by omega,limited.2⟩

theorem covers_of_gate {κ α : Type} [DecidableEq κ] (f : Row κ → Bool) (s : State κ α)
    (a b : List α) (t : Net (Option α))
    (limited : ∀ i, hits (s.read i) (.gate a b t) ≤ 1 ∧ ¬outUses (s.read i) (.gate a b t))
    (sem : ∀ x, (Net.gate a b t).eval (val x ∘ s.atom) = f x) :
    CoversPivots f (product s.atom a) (product s.atom b) := by
  intro i hi x y delta different eq
  apply different
  rw [← sem x,← sem y,Net.eval,Net.eval]
  apply eval_congr_used
  intro z used
  cases z with
  | none => exact (cutbit_eq s a b x).trans (eq.trans (cutbit_eq s a b y).symm)
  | some j =>
    by_cases israw : j = s.read i
    · subst j
      obtain ⟨zero,no⟩ := no_second_read s a b t i hi (limited i)
      rcases used with live | live
      · omega
      · exact (no live).elim
    · exact raw_agree s delta j israw

end Research.OddOr.Theta
/- END OR9822Census.lean -/

