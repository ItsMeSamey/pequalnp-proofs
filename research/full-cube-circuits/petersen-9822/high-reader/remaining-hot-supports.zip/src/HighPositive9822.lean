import LowPositive9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowPositive
open Research.OddOr FreeAndNet
theorem floor5 (t : Net V) (h : ∀ s, sees t s = pos 5 s) : 7 ≤ t.cost := by
  have p : Steps (pos 5) [0, 3, 4, 7, 8, 9, 6] {1,2} := by
    refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {4}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {9}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {6}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {1}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost p t (fun s _ => h s)
  change u.cost + 7 ≤ t.cost at hp
  omega

theorem floor6 (t : Net V) (h : ∀ s, sees t s = pos 6 s) : 7 ≤ t.cost := by
  have p : Steps (pos 6) [1, 2, 7, 5, 0, 8, 9] {3,4} := by
    refine Steps.step (lo := ∅) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {7}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {5}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {0}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {4}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost p t (fun s _ => h s)
  change u.cost + 7 ≤ t.cost at hp
  omega

theorem floor7 (t : Net V) (h : ∀ s, sees t s = pos 7 s) : 7 ≤ t.cost := by
  have p : Steps (pos 7) [0, 1, 2, 5, 6, 8, 9] {3,4} := by
    refine Steps.step (lo := {4}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {6}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {8}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {3}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost p t (fun s _ => h s)
  change u.cost + 7 ≤ t.cost at hp
  omega

theorem floor8 (t : Net V) (h : ∀ s, sees t s = pos 8 s) : 7 ≤ t.cost := by
  have p : Steps (pos 8) [0, 3, 4, 5, 6, 9, 7] {1,2} := by
    refine Steps.step (lo := {4}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {9}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {7}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {2}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost p t (fun s _ => h s)
  change u.cost + 7 ≤ t.cost at hp
  omega

theorem floor9 (t : Net V) (h : ∀ s, sees t s = pos 9 s) : 6 ≤ t.cost := by
  have p : Steps (pos 9) [3, 4, 6, 7, 8, 5] {0,1,2} := by
    refine Steps.step (lo := {8}) (other := {0,1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {0,1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {0,1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := ∅) (other := {0,1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {5}) (other := {0,1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {0}) (other := {0,1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost p t (fun s _ => h s)
  change u.cost + 6 ≤ t.cost at hp
  omega

def pinPrice (i : V) := if i.val ≤ 4 then 8 else if i.val ≤ 8 then 7 else 6
theorem pin_price (i : V) (t : Net V) (h : ∀ s, sees t s = pos i s) : pinPrice i ≤ t.cost := by
  fin_cases i
  · exact floor0 _ h
  · exact floor1 _ h
  · exact floor2 _ h
  · exact floor3 _ h
  · exact floor4 _ h
  · exact floor5 _ h
  · exact floor6 _ h
  · exact floor7 _ h
  · exact floor8 _ h
  · exact floor9 _ h
end PEqualNP.Outside.L_meta_9822.Sectors.LowPositive
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowPositive.pin_price
