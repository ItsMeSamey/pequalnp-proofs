import TaggedCompilerHits9822

namespace PEqualNP.Outside.L_meta_9822.Clean.GuardTags
open PEqualNP.CircuitLowerBounds FreeAndNet FreeAndNet.CircuitCompiler
open PEqualNP.Outside.L_meta_9822.Sectors.OuterNet

theorem marked_shift (gs : List Gate) (out : Nat) (w : List Bool) (z : Bool) :
    markedTrace (out+1) (gs.map shift) (z::w) = markedTrace out gs w := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih =>
    have reads : (shift g).inputs.map (fun j => (z::w).getD j false) =
        g.inputs.map (fun j => w.getD j false) := by simp [shift,List.map_map,Function.comp_def,List.getD]
    have flag : orFlag (shift g) = orFlag g := rfl
    simp only [List.map_cons,markedTrace,reads,flag,List.cons_append,ih]

private theorem zero_read (w : List Bool) (cleared : ∀ b ∈ w, b=false) (j : Nat) :
    w.getD j false = false := by
  by_cases hi : j<w.length
  · simpa [List.getD_eq_getElem?_getD,hi] using cleared w[j] (List.getElem_mem _)
  · simp [List.getD_eq_getElem?_getD,List.getElem?_eq_none (Nat.le_of_not_gt hi)]

theorem cut_prefix_tags (pre post : List Gate) (out : Nat) (w : List Bool)
    (cleared : ∀ b ∈ w, b=false) :
    markedTrace (out+1)
      (pre.map shift ++ (⟨.and,[0]⟩ : Gate) :: post.map shift) (true::w) =
      markedTrace out post (List.replicate (w.length + pre.length) false ++ [true]) := by
  induction pre generalizing w with
  | nil =>
    have ew : w=List.replicate w.length false := by
      apply List.ext_getElem
      · simp
      · intro i hi _
        simpa only [List.getElem_replicate] using cleared w[i] (List.getElem_mem _)
    change ((markedTrace (out+1) (post.map shift) (true :: (w ++ [true]))).1 + 0,
      (markedTrace (out+1) (post.map shift) (true :: (w ++ [true]))).2) = _
    rw [marked_shift]
    simp only [Nat.add_zero,Prod.mk.eta,List.length_nil]
    exact congrArg (fun t => markedTrace out post (t++[true])) ew
  | cons g gs ih =>
    have reads : ((shift g).inputs.map (fun j => (true::w).getD j false)).any id = false := by
      simp [shift,List.map_map,Function.comp_def,List.getD]
      intro j _
      exact zero_read w cleared j
    have z : (if orFlag (shift g) then false else false) = false := by cases orFlag (shift g) <;> rfl
    have tail := ih (w++[false]) (by simp_all)
    simp only [List.map_cons,List.cons_append,markedTrace,reads,z,Bool.and_false,
      Bool.false_eq_true,if_false,Nat.add_zero,Prod.mk.eta] 
    simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using tail

end PEqualNP.Outside.L_meta_9822.Clean.GuardTags
