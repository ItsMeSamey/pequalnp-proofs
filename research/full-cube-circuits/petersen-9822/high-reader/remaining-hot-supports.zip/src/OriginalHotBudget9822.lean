import PairExclusiveLeak9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr
open SignedClamp NonrawSupport OuterNet
def raise (i : Fin 10) (v : Input) : Input := fun j => if j=i then true else v j
def openPin (i : Fin 10) (j : Fin 11) : Product (Fin 11) :=
  if j=i.succ then some [] else some [j]
theorem row_open (i : Fin 10) (v : Input) (z : Bool) :
    (fun j => pval (env v z) (openPin i j)) = env (raise i v) z := by
  funext j
  refine Fin.cases ?_ (fun k => ?_) j
  · have ne : (0 : Fin 11) ≠ i.succ := by intro h; have := congrArg Fin.val h; simp at this
    simp [openPin,env,pval,ne]
  · by_cases e : k=i <;> simp [openPin,env,pval,raise,e]
theorem open_floor (i : Fin 10) :
    floorRow (openPin i) = env (singleton i) false := by
  funext j
  refine Fin.cases ?_ (fun k => ?_) j
  · have ne : (0 : Fin 11) ≠ i.succ := by intro h; have := congrArg Fin.val h; simp at this
    simp [openPin,env,floorRow,pval,ne]
  · by_cases e : k=i <;> simp [openPin,env,pval,floorRow,SignedClamp.singleton,e]

theorem original_hot_cap {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (s t : Fin 10)
    (lo : 5 ≤ s.val) (hi : s.val ≤ 8)
    (guard : ∀ v : Input, innerValue pre g v = (v s || v t)) :
    hotCount (env (singleton s) false) (model pre post C.output) ≤ 1 := by
  let net := model pre post C.output
  let u := retire (openPin s) net
  let k := specialize (close false) u
  have evalU (v : Input) (z : Bool) : u.eval (env v z) = outerValue pre post C.output (raise s v) z := by
    change (retire _ _).eval _ = _
    rw [retire_eval,row_open,model_eval r cand]
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have affected (v : Input) (vs : v s=true) : raise s v=v := by
    funext j
    by_cases e : j=s <;> simp [raise,e,vs]
  have zeroEval (v : Input) : u.eval (env v false)=edge (raise s v) := by
    rw [evalU]
    have exactOn := cut.computes (raise s v)
    rw [guard] at exactOn
    simpa [raise] using exactOn
  have fit (S : Finset (Fin 10)) : sees k S = LowPositive.pos s S := by
    let v : Input := fun j => decide (j∈S)
    change (specialize (close false) u).eval v = _
    rw [eval_specialize,close_eval,zeroEval]
    apply congrArg edge
    funext j
    by_cases e : j=s <;> simp [raise,v,e]
  obtain ⟨v,vs,_,neg,upper⟩ := pair_exclusive_leak r cand seven s t guard
  have up : u.eval (env v true)=true := by rw [evalU,affected v vs,upper]
  have down : u.eval (env v false)=false := by rw [zeroEval,affected v vs,neg]
  have all : u.eval (env (fun _ => true) false) = true := by
    rw [zeroEval,affected _ rfl]
    rfl
  have noOut : ¬outUses (0 : Fin 11) u := by
    intro use
    have bad := outZeros u 0 use (env (fun _ => true) false) rfl
    rw [all] at bad
    contradiction
  have hit : 0 < hits (0 : Fin 11) u := by
    by_contra! h
    have equal : u.eval (env v true)=u.eval (env v false) := by
      apply eval_congr_used
      intro j used
      exact Fin.cases (fun e => (e.elim (by omega) noOut).elim) (fun _ _ => rfl) j used
    rw [up,down] at equal
    contradiction
  have charge := specialize_saves (0 : Fin 11) (close false) (by rfl) u
  change k.cost + hits (0 : Fin 11) u ≤ u.cost at charge
  have price := LowPositive.pin_price s k fit
  have amount : LowPositive.pinPrice s = 7 := by simp [LowPositive.pinPrice,show ¬ s.val≤4 by omega,hi]
  have paid := retire_cost (openPin s) net
  rw [open_floor] at paid
  change u.cost + hotCount (env (singleton s) false) net ≤ net.cost at paid
  have cap : net.cost ≤ 9 := (model_cost r).trans (or_cap r cand seven)
  change hotCount (env (singleton s) false) net ≤ 1
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.original_hot_cap
