import CleanMin9822
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds
theorem count_four_sites (gs : List Gate) (mark : Gate → Bool) (a b c d : Gate)
    (ab : a≠b) (ac : a≠c) (ad : a≠d) (bc : b≠c) (bd : b≠d) (cd : c≠d)
    (ma : a∈gs) (mb : b∈gs) (mc : c∈gs) (md : d∈gs)
    (pa : mark a=true) (pb : mark b=true) (pc : mark c=true) (pd : mark d=true) :
    4≤gs.countP mark := by
  classical
  let A : Finset Gate := {a,b,c,d}
  have card : A.card=4 := by simp [A,ab,ac,ad,bc,bd,cd]
  have sub : A⊆(gs.filter mark).toFinset := by
    intro i hi
    simp only [A,Finset.mem_insert,Finset.mem_singleton] at hi
    rcases hi with rfl|rfl|rfl|rfl <;> simp_all
  have lower := (Finset.card_le_card sub).trans (List.toFinset_card_le _)
  simpa only [card,←List.countP_eq_length_filter] using lower
end PEqualNP.Outside.L_meta_9822.Clean
#print axioms PEqualNP.Outside.L_meta_9822.Clean.count_four_sites
