import LowPositive9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.PairFace
open FreeAndNet Research.OddOr LowPositive
def neg (x y : V) (s : Finset V) := edge (fun j => decide (j ≠ x ∧ j ≠ y ∧ j∈s))
theorem floor56 (t : Net V) (h : ∀ s, sees t s = neg 5 6 s) : 6 ≤ t.cost := by
  have steps : Steps (neg 5 6) [1,2,7,8,3,9] {0,4} := by
    refine Steps.step (lo := {2}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {7}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {9}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {3}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {4}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {4}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost steps t (fun s _ => h s)
  change u.cost + 6 ≤ t.cost at hp
  omega
def emb57 : Fin 5 ↪ V where
  toFun := fun j => ([3,4,9,6,8] : List V).get j
  inj' := by decide +kernel
theorem floor57 (t : Net V) (h : ∀ s, sees t s = neg 5 7 s) : 7 ≤ t.cost := by
  apply apply_cycle (neg 5 7) {3,4,6,8,9} [0,2,1] emb57 Cycle5.f _ (by decide +kernel) (by decide +kernel) Cycle5.lower t h
  refine Steps.step (lo := {4}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {1}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {6}) (other := {3,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _
def emb58 : Fin 5 ↪ V where
  toFun := fun j => ([1,2,7,9,6] : List V).get j
  inj' := by decide +kernel
theorem floor58 (t : Net V) (h : ∀ s, sees t s = neg 5 8 s) : 7 ≤ t.cost := by
  apply apply_cycle (neg 5 8) {1,2,6,7,9} [0,3,4] emb58 Cycle5.f _ (by decide +kernel) (by decide +kernel) Cycle5.lower t h
  refine Steps.step (lo := {4}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {4}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {9}) (other := {1,2}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _
def emb67 : Fin 5 ↪ V where
  toFun := fun j => ([0,4,3,8,5] : List V).get j
  inj' := by decide +kernel
theorem floor67 (t : Net V) (h : ∀ s, sees t s = neg 6 7 s) : 6 ≤ t.cost := by
  apply apply_cycle (neg 6 7) {0,2,3,4,5,8} [1,9] emb67 Cycle5.f _ (by decide +kernel) (by decide +kernel) Cycle5.lower t h
  refine Steps.step (lo := {2}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {4}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _
def emb68 : Fin 5 ↪ V where
  toFun := fun j => ([0,4,9,7,5] : List V).get j
  inj' := by decide +kernel
theorem floor68 (t : Net V) (h : ∀ s, sees t s = neg 6 8 s) : 7 ≤ t.cost := by
  apply apply_cycle (neg 6 8) {0,4,5,7,9} [1,2,3] emb68 Cycle5.f _ (by decide +kernel) (by decide +kernel) Cycle5.lower t h
  refine Steps.step (lo := {2}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {7}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {4}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _
theorem floor78 (t : Net V) (h : ∀ s, sees t s = neg 7 8 s) : 6 ≤ t.cost := by
  have steps : Steps (neg 7 8) [2,1,3,5,6,9] {0,4} := by
    refine Steps.step (lo := {1}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {6}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {4}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {0}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {9}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {4}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost steps t (fun s _ => h s)
  change u.cost + 6 ≤ t.cost at hp
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.PairFace
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.PairFace.floor67
