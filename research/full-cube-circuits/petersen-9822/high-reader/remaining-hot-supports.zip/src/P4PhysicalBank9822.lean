import SynchronousPairNet9822
import P4GuardChamber9822
namespace Research.Graph9822.P4Guard
open FreeAndNet

/-- Pointwise representation of a signal on the eight local input rows. -/
def Models {α : Type} (env : Fin 8 → α → Bool) (B : List Mask) : Prop :=
  ∀ x, ∃ m ∈ B, ∀ i : Fin 8, (env i x) = m.getLsbD i.val

def Closed (B : List Mask) : Prop :=
  255 ∈ B ∧ 0 ∈ B ∧ ∀ x ∈ B, ∀ y ∈ B, x &&& y ∈ B

theorem product_modeled {env : Fin 8 → α → Bool} {B : List Mask}
    (closed : Closed B) (h : Models env B) (p : Product α) :
    ∃ m ∈ B, ∀ i : Fin 8, pval (env i) p = m.getLsbD i.val := by
  cases p with
  | none => exact ⟨0,closed.2.1,fun i => by simp [pval]⟩
  | some xs =>
    induction xs with
    | nil =>
      refine ⟨255,closed.1,?_⟩
      exact (by decide : ∀ i : Fin 8, true = (255 : Mask).getLsbD i.val)
    | cons x xs ih =>
      obtain ⟨a,ha,ea⟩ := h x
      obtain ⟨b,hb,eb⟩ := ih
      refine ⟨a &&& b,closed.2.2 _ ha _ hb,fun i => ?_⟩
      change (env i x && xs.all (env i)) = _
      have e : xs.all (env i) = b.getLsbD i.val := eb i
      rw [BitVec.getLsbD_and,ea i,e]

theorem mem_extend {B : List Mask} {x y : Mask} :
    x ∈ extend B y ↔ x ∈ B ∨ ∃ z ∈ B, z &&& y = x := by
  simp [extend]

theorem closed_extend {B : List Mask} (h : Closed B) (m : Mask) : Closed (extend B m) := by
  refine ⟨mem_extend.mpr (.inl h.1),mem_extend.mpr (.inl h.2.1),?_⟩
  intro x hx y hy
  rcases mem_extend.mp hx with hx | ⟨a,ha,rfl⟩ <;>
    rcases mem_extend.mp hy with hy | ⟨b,hb,rfl⟩
  · exact mem_extend.mpr (.inl (h.2.2 _ hx _ hy))
  · exact mem_extend.mpr (.inr ⟨_,h.2.2 _ hx _ hb,by
      apply BitVec.eq_of_getLsbD_eq
      intro i _
      simp only [BitVec.getLsbD_and]
      simp [Bool.and_assoc,Bool.and_comm,Bool.and_left_comm]⟩)
  · exact mem_extend.mpr (.inr ⟨_,h.2.2 _ ha _ hy,by
      apply BitVec.eq_of_getLsbD_eq
      intro i _
      simp only [BitVec.getLsbD_and]
      simp [Bool.and_assoc,Bool.and_comm,Bool.and_left_comm]⟩)
  · exact mem_extend.mpr (.inr ⟨_,h.2.2 _ ha _ hb,by
      apply BitVec.eq_of_getLsbD_eq
      intro i _
      simp only [BitVec.getLsbD_and]
      simp [Bool.and_assoc,Bool.and_comm,Bool.and_left_comm]⟩)

def closedCheck (B : List Mask) :=
  B.contains 255 && B.contains 0 && B.all fun x => B.all fun y => B.contains (x &&& y)
theorem closed_base : Closed base := by
  have h : closedCheck base = true := by decide +kernel
  simpa [closedCheck,Closed,List.all_eq_true,Bool.and_assoc] using h

end Research.Graph9822.P4Guard
