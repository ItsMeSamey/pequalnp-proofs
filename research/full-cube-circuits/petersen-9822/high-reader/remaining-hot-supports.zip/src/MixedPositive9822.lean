import OR9822Base
import Sector9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.MixedPositive
open FreeAndNet Research.OddOr PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

/-- With the empty row rejected, every independent singleton positive after the
first one charges a separate OR, irrespective of AND cost or shared wires. -/
theorem singleton_price {α : Type} [DecidableEq α] (xs : List α) (t : Net α)
    (nd : xs.Nodup) (off : sees t ∅ = false)
    (on : ∀ i ∈ xs, sees t {i} = true) : xs.length ≤ t.cost + 1 := by
  induction xs generalizing t with
  | nil => simp
  | cons i xs ih =>
    obtain ⟨fresh,tail⟩ := List.nodup_cons.mp nd
    cases xs with
    | nil => simp
    | cons j js =>
      have diff : i ≠ j := fun e => fresh (by simp [e])
      have nj : ¬ outUses i t := avoids_output t (z := {j}) (by simpa using diff)
        (on j (by simp))
      have pos : 0 < hits i t := by
        by_contra! hz
        have eq : sees t {i} = sees t ∅ := by
          apply eval_congr_used
          intro k use
          have ne : k ≠ i := by
            rintro rfl
            exact use.elim (by omega) nj
          simp [ne]
        rw [on i (by simp),off] at eq
        contradiction
      have bound := ih (pin i t) tail
        ((pin_sees i t ∅ (by simp)).trans off) (by
          intro k hk
          have ne : i ≠ k := fun e => fresh (by simpa [e] using hk)
          exact (pin_sees i t {k} (by simpa using ne)).trans
            (on k (List.mem_cons_of_mem _ hk)))
      have cost := pin_cost i t
      simp only [List.length_cons] at bound ⊢
      omega

/-- In both reflected minors the five independent flags represent the three
neighbors of 9 and the two remaining disjoint edges. -/
def wire (s : Fin 10) (i : Fin 10) : Product (Fin 5) :=
  if i=9 then some [] else if i=4 then some [0] else if i=6 then some [1]
  else if i=7 then some [2] else if i=1 ∨ i=2 then some [3]
  else if (s=5 ∧ (i=3 ∨ i=8)) ∨ (s=8 ∧ (i=0 ∨ i=5)) then some [4] else none

def row (s : Fin 10) (v : Fin 5 → Bool) : Fin 10 → Bool := fun i => pval v (wire s i)

theorem row_values : ∀ s : Fin 10, s=5 ∨ s=8 →
    edge (row s (fun _ => false)) = false ∧
    (∀ i : Fin 5, edge (row s (fun j => decide (j=i))) = true) ∧
    (∀ v : Fin 5 → Bool, row s v s = false ∧ row s v 9 = true) := by
  intro s hs
  rcases hs with rfl | rfl <;> refine ⟨by decide +kernel, by decide +kernel, ?_⟩ <;>
    intro v <;> exact ⟨rfl,rfl⟩

theorem specialized_positive_floor (s : Fin 10) (hs : s=5 ∨ s=8)
    (C : Circuit) (hm : Monotone2 C)
    (face : ∀ x : Fin 10 → Bool, x s = false → x 9 = true →
      C.eval (List.ofFn x) = edge x) :
    4 ≤ (specialize (wire s) (CircuitCompiler.compile 10 C)).cost := by
  let t := CircuitCompiler.compile 10 C
  let u := specialize (wire s) t
  obtain ⟨empty,hot,pins⟩ := row_values s hs
  have read (v : Fin 5 → Bool) : u.eval v = edge (row s v) := by
    rw [show u.eval v = t.eval (row s v) from eval_specialize _ _ _]
    exact (CircuitCompiler.compile_eval 10 C hm _).trans
      (face _ (pins v).1 (pins v).2)
  have off : sees u ∅ = false := by simpa [sees] using (read (fun _ => false)).trans empty
  have on (i : Fin 5) : sees u {i} = true := by
    simpa [sees] using (read (fun j => decide (j=i))).trans (hot i)
  have price := singleton_price ([0,1,2,3,4] : List (Fin 5)) u (by decide) off
    (fun i _ => on i)
  change 5 ≤ u.cost + 1 at price
  change 4 ≤ u.cost
  omega

theorem physical_positive_floor (s : Fin 10) (hs : s=5 ∨ s=8)
    (C : Circuit) (hm : Monotone2 C)
    (face : ∀ x : Fin 10 → Bool, x s = false → x 9 = true →
      C.eval (List.ofFn x) = edge x) :
    4 ≤ (C.gates.filter CircuitCompiler.orFlag).length :=
  ((specialized_positive_floor s hs C hm face).trans (specialize_cost _ _)).trans
    (CircuitCompiler.compile_cost 10 C)

end PEqualNP.Outside.L_meta_9822.Sectors.MixedPositive

#print axioms PEqualNP.Outside.L_meta_9822.Sectors.MixedPositive.physical_positive_floor
