import CleanMin9822
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds
def rises {n : Nat} (gs : List Gate) (x y : Fin n → Bool) (j : Nat) :=
  vl gs x j=false ∧ vl gs y j=true

theorem rising_or_frontier {n : Nat} (gs : List Gate) (cl : CleanL n gs)
    (x y : Fin n → Bool) (zero : Nat → Prop) (out : Nat) (up : rises gs x y out)
    (outside : ¬zero out) (raw : ∀ j, j<n → rises gs x y j → zero j)
    (andClose : ∀ k q, gs[k]?=some q → q.op=.and →
      (∃ j∈q.inputs,zero j) → zero (n+k))
    (noInv : ∀ k q, gs[k]?=some q → q.op=.not → ¬rises gs x y (n+k)) :
    ∃ k q,gs[k]?=some q ∧ q.op=.or ∧ rises gs x y (n+k) ∧ ¬zero (n+k) ∧
      ∃ j∈q.inputs,zero j := by
  classical
  by_contra no
  have prop : ∀ j, rises gs x y j → zero j := by
    intro j
    induction j using Nat.strong_induction_on with
    | ind j prev =>
      intro ch
      by_cases small : j<n
      · exact raw j small ch
      let k := j-n
      have eq : j=n+k := by dsimp [k];omega
      have inrange : k<gs.length := by
        by_contra! bad
        have cold := List.getD_eq_default (wiresFrom gs (List.ofFn y)) false (n:=j)
          (by rw [length_wiresFrom,List.length_ofFn];omega)
        exact Bool.noConfusion (ch.2.symm.trans cold)
      let q := gs[k]
      have atq : gs[k]?=some q := List.getElem?_eq_getElem inrange
      have site := cl k q atq
      rw [eq] at ch ⊢
      rcases site with ⟨op,_⟩ | ⟨op,a,b,ba,bb,ins⟩
      · exact (noInv k q atq op ch).elim
      have next : rises gs x y a ∨ rises gs x y b := by
        obtain ⟨cx,cy⟩ := ch
        rw [vl_gate _ cl _ k q atq,ins] at cx cy
        rcases op with op|op <;> simp [op,GateOp.eval,rises] at cx cy ⊢ <;> grind
      have pin : ∃ d∈q.inputs,zero d := by
        rcases next with z|z
        · exact ⟨a,by simp [ins],prev a (by omega) z⟩
        · exact ⟨b,by simp [ins],prev b (by omega) z⟩
      rcases op with op|op
      · exact andClose k q atq op pin
      · by_contra notZ
        exact no ⟨k,q,atq,op,ch,notZ,pin⟩
  exact outside (prop out up)
end PEqualNP.Outside.L_meta_9822.Clean
#print axioms PEqualNP.Outside.L_meta_9822.Clean.rising_or_frontier
