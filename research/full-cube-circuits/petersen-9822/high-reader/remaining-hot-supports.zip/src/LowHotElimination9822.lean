import OuterZeroDebit9822
import LowSignedFace9822
import PositiveRetire9822
import GuardTrace9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open FreeAndNet Research.OddOr PEqualNP.CircuitLowerBounds
open SignedClamp NonrawSupport OuterNet PEqualNP.Outside.L_meta_9822.Clean

/-- The physical guard is read strictly before the inverter. If it is hot,
its selected input index is genuine even for lists with out-of-bounds reads. -/
theorem guard_observer {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    {i : Fin 10} (hot : innerValue pre g (singleton i) = true) :
    ∃ a : Nat, ∀ v : Input, (specialize (close false) (model pre post a)).eval v =
      innerValue pre g v := by
  cases hg : g.inputs with
  | nil => simp [innerValue,hg] at hot
  | cons a tail =>
    refine ⟨a,?_⟩
    have bound : a < 10+pre.length := by
      by_contra! bad
      have miss : (wiresFrom pre (List.ofFn (singleton i))).getD a false = false :=
        List.getD_eq_default _ _ (by rw [length_wiresFrom]; simpa using bad)
      unfold innerValue at hot
      rw [hg] at hot
      change (wiresFrom pre (List.ofFn (singleton i))).getD a false = true at hot
      rw [miss] at hot
      contradiction
    intro v
    have hm : PEqualNP.MetaComplexity.Monotone2 (cutCircuit pre post a) := model_legal r cand
    rw [eval_specialize,close_eval]
    change (CircuitCompiler.compile 11 (cutCircuit pre post a)).eval _ = _
    rw [CircuitCompiler.compile_eval _ _ hm,cut_eval]
    unfold outerValue innerValue
    rw [hg]
    change (wiresFrom post (wiresFrom pre (List.ofFn v) ++ [false])).getD a false =
      (wiresFrom pre (List.ofFn v)).getD a false
    have room : a < (wiresFrom pre (List.ofFn v)).length := by
      rw [length_wiresFrom]; simpa using bound
    have room' : a < (wiresFrom pre (List.ofFn v) ++ [false]).length := by
      rw [List.length_append]
      exact Nat.lt_trans room (Nat.lt_succ_self _)
    rw [getD_wiresFrom _ _ _ room',getD_snoc_ne _ _ _ _ (Nat.ne_of_lt room)]

theorem low_hot_impossible {C pre post g} (r : Roster C pre post g)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10) (low : i.val ≤ 4)
    (hot : innerValue pre g (singleton i) = true) : ¬ Candidate C := by
  intro cand
  let u := specialize (close false) (model pre post C.output)
  obtain ⟨a,read⟩ := guard_observer r cand hot
  let b := specialize (close false) (model pre post a)
  have same : SameTrace u b := trace_specialize
    (compile_trace (C.output+1) (a+1) (cutCircuit pre post a).gates _) _
  obtain ⟨w,wi,_,hw⟩ := independent_witness r cand seven i
  have fire : 0 < hotCount (singleton i) b := by
    by_contra! h
    have inter := intersection_when_cold b (singleton i) w (fun _ => false) (by
      intro j hj hjw
      have eq : j=i := by simpa [SignedClamp.singleton] using hj
      rw [eq,wi] at hjw
      contradiction) (by omega) ((read _).trans hot) ((read _).trans hw)
    have cold := (read (fun _ => false)).trans (cold_empty r cand seven)
    change b.eval (fun _ => false) = false at cold
    rw [cold] at inter
    contradiction
  have sameHot := trace_count same (singleton i)
  have cap : u.cost ≤ 8 := zero_debit r cand seven
  let k := retire (LowPositive.setHigh i) u
  have base : floorRow (LowPositive.setHigh i) = singleton i := by
    funext j
    by_cases eq : j=i <;> simp [floorRow,LowPositive.setHigh,SignedClamp.singleton,eq,pval]
  have save := retire_cost (LowPositive.setHigh i) u
  rw [base] at save
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have exactOn (s : Finset (Fin 10)) : sees k s = LowPositive.pos i s := by
    let v : Input := fun j => decide (j=i ∨ j∈s)
    have on : innerValue pre g v = true := by
      apply inner_mono_inputs (fun q hq => r.pos q (List.mem_append_left _ hq)) g _ hot
      intro j hj
      have eq : j=i := by simpa [SignedClamp.singleton] using hj
      simp [v,eq]
    have actual := cut.computes v
    rw [on] at actual
    change (retire _ u).eval _ = _
    rw [retire_eval]
    have eq : (fun j => pval (fun z => decide (z∈s)) (LowPositive.setHigh i j)) = v :=
      funext (LowPositive.row_eval i s)
    rw [eq]
    change (specialize (close false) (model pre post C.output)).eval v = _
    rw [eval_specialize,close_eval,model_eval r cand]
    exact actual
  have price := LowPositive.any_low i low k exactOn
  change 8 ≤ (retire (LowPositive.setHigh i) u).cost at price
  omega

end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.low_hot_impossible
