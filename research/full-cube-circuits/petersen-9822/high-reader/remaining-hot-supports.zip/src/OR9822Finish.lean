import OR9822Cofactors
import OR9822Cycles
import Sector9822
import OR9822TablesA
import OR9822TablesB

/- BEGIN OR9822Graph.lean -/
namespace Research.OddOr
open FreeAndNet
namespace Graph9822
set_option maxRecDepth 16000
abbrev V := Fin 10
def f (s : Finset V) := PEqualNP.Outside.L_meta_9822.Sectors.edge (fun i => decide (i ∈ s))
def data : GraphRows f where
  walk := [0,4,3,8,5,7,2,1,6,9]
  spans := by decide +kernel
  steps := by decide +kernel
  cold := by decide +kernel
  singleton := by decide +kernel
  neighbor := by decide +kernel
  diff := by decide +kernel
  avoiding := by decide +kernel
  edges := fun j => if j = 0 then {0,4} else if j = 1 then {1,2} else {3,8}
  hot := by decide +kernel
  meet := by decide +kernel

def emb0 : Drop0.V ↪ V where
  toFun := fun v => ([1,2,3,4,5,6,7,8,9] : List V).get v
  inj' := by decide +kernel

theorem price0 (t : Net V) (h : ∀ s : Finset V, (0 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb0 9 Drop0.lower 0 [] {1,2,3,4,5,6,7,8,9} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact Peel.done _

def emb3 : Drop3.V ↪ V where
  toFun := fun v => ([0,1,2,4,5,6,7,8,9] : List V).get v
  inj' := by decide +kernel

theorem price3 (t : Net V) (h : ∀ s : Finset V, (3 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb3 9 Drop3.lower 3 [] {0,1,2,4,5,6,7,8,9} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact Peel.done _

def emb1 : Drop12.V ↪ V where
  toFun := fun v => ([0,3,4,5,6,7,8,9] : List V).get v
  inj' := by decide +kernel

theorem price1 (t : Net V) (h : ∀ s : Finset V, (1 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb1 8 Drop12.lower 1 [2] {0,3,4,5,6,7,8,9} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 7) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb2 : Drop12.V ↪ V where
  toFun := fun v => ([0,3,4,5,6,7,8,9] : List V).get v
  inj' := by decide +kernel

theorem price2 (t : Net V) (h : ∀ s : Finset V, (2 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb2 8 Drop12.lower 2 [1] {0,3,4,5,6,7,8,9} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 6) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb4 : Theta233.V ↪ V where
  toFun := fun v => ([6,7,9,1,2,8,5] : List V).get v
  inj' := by decide +kernel

theorem price4 (lower : ∀ t : Net Theta233.V, (∀ s, sees t s = Theta233.f s) → 7 ≤ t.cost) (t : Net V) (h : ∀ s : Finset V, (4 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb4 7 lower 4 [3,0] {6,7,9,1,2,8,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 8) (a := 6) (b := 9) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 5) (a := 6) (b := 9) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb5 : Theta144.V ↪ V where
  toFun := fun v => ([6,9,1,2,7,8,3,4] : List V).get v
  inj' := by decide +kernel

theorem price5 (lower : ∀ t : Net Theta144.V, (∀ s, sees t s = Theta144.f s) → 8 ≤ t.cost) (t : Net V) (h : ∀ s : Finset V, (5 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb5 8 lower 5 [0] {6,9,1,2,7,8,3,4} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 4) (a := 6) (b := 9) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb6 : Theta233.V ↪ V where
  toFun := fun v => ([4,5,0,3,8,9,7] : List V).get v
  inj' := by decide +kernel

theorem price6 (lower : ∀ t : Net Theta233.V, (∀ s, sees t s = Theta233.f s) → 7 ≤ t.cost) (t : Net V) (h : ∀ s : Finset V, (6 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb6 7 lower 6 [1,2] {4,5,0,3,8,9,7} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 2) (a := 4) (b := 0) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 7) (a := 4) (b := 0) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb7 : Theta233.V ↪ V where
  toFun := fun v => ([4,8,3,0,5,9,6] : List V).get v
  inj' := by decide +kernel

theorem price7 (lower : ∀ t : Net Theta233.V, (∀ s, sees t s = Theta233.f s) → 7 ≤ t.cost) (t : Net V) (h : ∀ s : Finset V, (7 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb7 7 lower 7 [2,1] {4,8,3,0,5,9,6} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 1) (a := 4) (b := 3) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 6) (a := 4) (b := 3) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb8 : Theta144.V ↪ V where
  toFun := fun v => ([7,9,2,1,6,5,0,4] : List V).get v
  inj' := by decide +kernel

theorem price8 (lower : ∀ t : Net Theta144.V, (∀ s, sees t s = Theta144.f s) → 8 ≤ t.cost) (t : Net V) (h : ∀ s : Finset V, (8 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb8 8 lower 8 [3] {7,9,2,1,6,5,0,4} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 4) (a := 7) (b := 9) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb9 : Theta145.V ↪ V where
  toFun := fun v => ([5,8,0,4,3,7,2,1,6] : List V).get v
  inj' := by decide +kernel

theorem price9 (lower : ∀ t : Net Theta145.V, (∀ s, sees t s = Theta145.f s) → 9 ≤ t.cost) (t : Net V) (h : ∀ s : Finset V, (9 : V) ∉ s → sees t s = f s) :
    9 ≤ t.cost := by
  refine induced_pin_price data.singleton emb9 9 lower 9 [] {5,8,0,4,3,7,2,1,6} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact Peel.done _

theorem lower_of_theta
    (hTheta233 : ∀ t : Net Theta233.V, (∀ s, sees t s = Theta233.f s) → 7 ≤ t.cost)
    (hTheta144 : ∀ t : Net Theta144.V, (∀ s, sees t s = Theta144.f s) → 8 ≤ t.cost)
    (hTheta145 : ∀ t : Net Theta145.V, (∀ s, sees t s = Theta145.f s) → 9 ≤ t.cost)
    (t : Net V) (h : ∀ s, sees t s = f s) : 11 ≤ t.cost := by
  refine graph_raise data 9 ?_ t h
  intro i
  fin_cases i
  · exact price0
  · exact price1
  · exact price2
  · exact price3
  · exact price4 hTheta233
  · exact price5 hTheta144
  · exact price6 hTheta233
  · exact price7 hTheta233
  · exact price8 hTheta144
  · exact price9 hTheta145

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

theorem physical_of_theta
    (h233 : ∀ t : Net Theta233.V, (∀ s, sees t s = Theta233.f s) → 7 ≤ t.cost)
    (h144 : ∀ t : Net Theta144.V, (∀ s, sees t s = Theta144.f s) → 8 ≤ t.cost)
    (h145 : ∀ t : Net Theta145.V, (∀ s, sees t s = Theta145.f s) → 9 ≤ t.cost)
    (C : Circuit) (mono : Monotone2 C)
    (computes : ∀ v : Fin 10 → Bool, C.eval (List.ofFn v) = PEqualNP.Outside.L_meta_9822.Sectors.edge v) :
    11 ≤ (C.gates.filter CircuitCompiler.orFlag).length := by
  apply Nat.le_trans _ (CircuitCompiler.compile_cost 10 C)
  apply lower_of_theta h233 h144 h145
  intro s
  exact (CircuitCompiler.compile_eval 10 C mono _).trans (computes _)

end Graph9822
end Research.OddOr
/- END OR9822Graph.lean -/

/- BEGIN OR9822Physical.lean -/

namespace Research.OddOr.Graph9822
open FreeAndNet PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

theorem physical_eleven (C : Circuit) (mono : Monotone2 C)
    (computes : ∀ x : Fin 10 → Bool, C.eval (List.ofFn x) = PEqualNP.Outside.L_meta_9822.Sectors.edge x) :
    11 ≤ (C.gates.filter CircuitCompiler.orFlag).length :=
  physical_of_theta Theta233.lower Theta144.lower Theta145.lower C mono computes

open PEqualNP.Outside.L_meta_9822.Sectors

theorem zero_not_candidate_eleven (C : Circuit) (candidate : Candidate C)
    (zero : C.gates.countP countsNot = 0) : 11 ≤ (C.gates.filter CircuitCompiler.orFlag).length := by
  apply physical_eleven C _ candidate.2.2
  intro g hg
  obtain ⟨ops,arity⟩ := candidate.1 g hg
  refine ⟨?_,arity⟩
  rcases ops with ha | ho | hn
  · exact Or.inl ha
  · exact Or.inr ho
  · change g.op = GateOp.not at hn
    exact False.elim ((List.countP_eq_zero.mp zero g hg) (by simp [countsNot,hn]))

#print axioms physical_eleven
#print axioms zero_not_candidate_eleven
end Research.OddOr.Graph9822
/- END OR9822Physical.lean -/

