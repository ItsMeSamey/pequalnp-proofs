import FinalPinDebit9822
namespace PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit
open PEqualNP.CircuitLowerBounds
theorem elim_append_state (n : Nat) (l r : List Gate) (acc : List Stat × List Gate) :
    elim n (l++r) acc=elim n r (elim n l acc) := by
  induction l generalizing acc with
  | nil => rfl
  | cons a l ih => exact ih (elimStep n acc a)
theorem stats_length (n : Nat) (gs : List Gate) (acc : List Stat × List Gate) :
    (elim n gs acc).1.length=acc.1.length+gs.length := by
  induction gs generalizing acc with
  | nil => simp [elim]
  | cons g gs ih =>
    change (elim n gs (elimStep n acc g)).1.length=_
    rw [ih]
    simp [elimStep,Nat.add_assoc,Nat.add_left_comm,Nat.add_comm]

theorem final_output_status (n : Nat) (l r : List Gate) (g : Gate) (acc : List Stat × List Gate) :
    let p := elim n l acc
    let whole := elim n (l++g::r) acc
    whole.1.getD (acc.1.length+l.length) (Sum.inl false) =
      (simplify g.op (n+p.2.length) (g.inputs.map fun j => p.1.getD j (Sum.inl false))).2 := by
  dsimp only
  rw [elim_append_state]
  let p := elim n l acc
  change (elim n r (elimStep n p g)).1.getD _ _ = _
  have len : p.1.length=acc.1.length+l.length := stats_length n l acc
  rw [←len,final_get n r (elimStep n p g) p.1.length
    (by change p.1.length<(p.1++[_]).length; simp)]
  exact getD_snoc_eq .. 

theorem final_inputs (n : Nat) (l r : List Gate) (g : Gate) (acc : List Stat × List Gate)
    (bound : ∀ j∈g.inputs, j<acc.1.length+l.length) :
    let p := elim n l acc
    let whole := elim n (l++g::r) acc
    g.inputs.map (fun j => p.1.getD j (Sum.inl false)) =
      g.inputs.map (fun j => whole.1.getD j (Sum.inl false)) := by
  dsimp only
  rw [elim_append_state]
  apply List.map_congr_left
  intro j hj
  exact (final_get n (g::r) (elim n l acc) j (by rw [stats_length];exact bound j hj)).symm
end PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit
#print axioms PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit.final_output_status
