import GuardEmitterInit9822
import GuardEmitterCost9822
import GuardEmitterLegal9822
import CleanMin9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity GuardTags
theorem minimum_readers {n : Nat} (before after : List Gate) (m out : Nat)
    (size : n+before.length=m+1) (minimum : Reduced n (before++after) out)
    (varied : ∃ x y : Fin n → Bool,vl (before++after) x out ≠ vl (before++after) y out)
    (ordinary : checked after)
    (trace : contacts out after (List.replicate m false ++ [true]) = (1,false)) :
    after.countP (ReaderDebit.reads m) ≤ 1 := by
  let rs := start m
  let p := go (m+1) m rs after
  have wt : m<rs.length := by simp [rs,start_length]
  have found : rs.getD m initReg = (true,top) := by
    simpa [rs,start] using getD_snoc_eq ((List.range m).map (fun i : Nat => ((false,Sum.inr i) : Reg))) (true,top) initReg
  have ledger := go_cost after (m+1) m m out rs wt found ordinary
  have marks : contacts out after (rs.map Prod.fst) = (1,false) := by rw [start_marks,trace]
  rw [marks] at ledger
  change p.1.length+after.countP (ReaderDebit.reads m) ≤ after.length+1 ∧
    (p.2.getD out initReg).1=false at ledger
  let pointer := (p.2.getD out initReg).2
  have equivalent (x : Fin n → Bool) :
      pointer.val (wiresFrom (before++p.1) (List.ofFn x)) = vl (before++after) x out := by
    let w := wiresFrom before (List.ofFn x)
    have len : w.length=m+1 := by simp [w,length_wiresFrom,size]
    have good : ValidRegs w.length rs := by rw [len]; exact start_valid m
    have runEq := (go_sound after w rs m (by omega) good ordinary).2
    rw [start_eval w m len] at runEq
    rw [len] at runEq
    change p.2.map (evalReg (wiresFrom p.1 w) m) = wiresFrom after w at runEq
    have read := congrArg (fun l : List Bool => l.getD out false) runEq
    have key := List.getD_map (l:=p.2) (d:=initReg) (n:=out) (evalReg (wiresFrom p.1 w) m)
    unfold vl
    rw [wiresFrom_append,wiresFrom_append]
    change pointer.val (wiresFrom p.1 w) = _
    have output := key.symm.trans read
    change (pointer.val (wiresFrom p.1 w) && (!(p.2.getD out initReg).1 || (wiresFrom p.1 w).getD m false)) = _ at output
    rw [ledger.2] at output
    simpa only [Bool.not_false,Bool.true_or,Bool.and_true] using output
  cases eq : pointer with
  | inl b =>
    obtain ⟨x,y,ne⟩ := varied
    have hx := equivalent x
    have hy := equivalent y
    rw [eq] at hx hy
    exact False.elim (ne (hx.symm.trans hy))
  | inr i =>
    let D : Circuit := ⟨before++p.1,i⟩
    have legal : FanInTwo D := by
      intro g hg
      rcases List.mem_append.mp hg with old|added
      · exact (clean_nok _ _ minimum.clean g (List.mem_append_left _ old)).1
      · exact go_ok after (m+1) m rs g added
    have le := minimum.noSmaller D legal (fun x => by
      have h := equivalent x
      rw [eq] at h
      exact h)
    change (before++after).length ≤ (before++p.1).length at le
    simp only [List.length_append] at le
    have count := ledger.1
    omega
end PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter.minimum_readers
