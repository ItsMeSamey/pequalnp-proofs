import P4PhysicalTraceCore9822
namespace Research.Graph9822.P4Guard
theorem s00 : safe (extend base 0) 1 = true := by decide +kernel
theorem s01 : safe (extend base 32) 1 = true := by decide +kernel
theorem s02 : safe (extend base 34) 1 = true := by decide +kernel
theorem s03 : safe (extend base 64) 1 = true := by decide +kernel
theorem s04 : safe (extend base 96) 1 = true := by decide +kernel
theorem s05 : safe (extend base 98) 1 = true := by decide +kernel
theorem s06 : safe (extend base 100) 1 = true := by decide +kernel
theorem s07 : safe (extend base 102) 1 = true := by decide +kernel
theorem s08 : safe (extend base 128) 1 = true := by decide +kernel
theorem s09 : safe (extend base 144) 1 = true := by decide +kernel
theorem s10 : safe (extend base 160) 1 = true := by decide +kernel
theorem s11 : safe (extend base 162) 1 = true := by decide +kernel
theorem s12 : safe (extend base 176) 1 = true := by decide +kernel
theorem s13 : safe (extend base 178) 1 = true := by decide +kernel
theorem s14 : safe (extend base 192) 1 = true := by decide +kernel
theorem s15 : safe (extend base 200) 1 = true := by decide +kernel
theorem s16 : safe (extend base 208) 1 = true := by decide +kernel
theorem s17 : safe (extend base 216) 1 = true := by decide +kernel
theorem s18 : safe (extend base 228) 1 = true := by decide +kernel
theorem s19 : safe (extend base 232) 1 = true := by decide +kernel
theorem s20 : safe (extend base 234) 1 = true := by decide +kernel
theorem s21 : safe (extend base 236) 1 = true := by decide +kernel
theorem s22 : safe (extend base 244) 1 = true := by decide +kernel
theorem s23 : safe (extend base 255) 1 = true := by decide +kernel
theorem safe_two : safe base 2 = true := by
  apply Bool.and_eq_true_iff.mpr
  refine ⟨by decide +kernel,List.all_eq_true.mpr ?_⟩
  intro a ha
  have casesA : a = 0 ∨ a = 32 ∨ a = 34 ∨ a = 64 ∨ a = 96 ∨ a = 98 ∨ a = 100 ∨ a = 102 ∨ a = 128 ∨ a = 144 ∨ a = 160 ∨ a = 162 ∨ a = 176 ∨ a = 178 ∨ a = 192 ∨ a = 200 ∨ a = 208 ∨ a = 216 ∨ a = 228 ∨ a = 232 ∨ a = 234 ∨ a = 236 ∨ a = 244 ∨ a = 255 := by
    have h : ∀ a : Mask, a ∈ joins base → a = 0 ∨ a = 32 ∨ a = 34 ∨ a = 64 ∨ a = 96 ∨ a = 98 ∨ a = 100 ∨ a = 102 ∨ a = 128 ∨ a = 144 ∨ a = 160 ∨ a = 162 ∨ a = 176 ∨ a = 178 ∨ a = 192 ∨ a = 200 ∨ a = 208 ∨ a = 216 ∨ a = 228 ∨ a = 232 ∨ a = 234 ∨ a = 236 ∨ a = 244 ∨ a = 255 := by decide +kernel
    exact h a ha
  rcases casesA with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact s00
  · exact s01
  · exact s02
  · exact s03
  · exact s04
  · exact s05
  · exact s06
  · exact s07
  · exact s08
  · exact s09
  · exact s10
  · exact s11
  · exact s12
  · exact s13
  · exact s14
  · exact s15
  · exact s16
  · exact s17
  · exact s18
  · exact s19
  · exact s20
  · exact s21
  · exact s22
  · exact s23
end Research.Graph9822.P4Guard
