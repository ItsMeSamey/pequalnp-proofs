import LowPositive9822
import NonrawSupport9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.LowPositive
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet Research.OddOr
open PEqualNP.Outside.L_meta_9822.Clean SignedClamp NonrawSupport

def setHigh (i k : V) : Product V := if k=i then some [] else some [k]

theorem row_eval (i : V) (s : Finset V) (j : V) :
    pval (fun k : V => decide (k∈s)) (setHigh i j) =
      decide (j=i ∨ j∈s) := by
  by_cases h : j=i <;> simp [setHigh,h,pval]

/-- Full physical SOLE-NOT gate list: a nonraw guard hot at any low singleton
forces the zero-clamped, positive-pin projection to pay at least eight ORs. -/
theorem low_guard_floor {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (i : V) (low : i.val ≤ 4) (hot : innerValue pre g (singleton i) = true) :
    8 ≤ (specialize (setHigh i) (CircuitCompiler.compile 10
      (MixedPositive.forceZero pre post C.output))).cost := by
  let D := MixedPositive.forceZero pre post C.output
  have mono : Monotone2 D := by
    intro a ha
    change a ∈ pre ++ (⟨.or,[]⟩ : Gate) :: post at ha
    have ordinary (h : a ∈ pre ++ post) : PositiveOp a ∧ a.inputs.length ≤ 2 := by
      have source : a ∈ C.gates := by
        rw [r.split]
        rcases List.mem_append.mp h with head | tail
        · exact List.mem_append_left _ head
        · exact List.mem_append_right _ (List.mem_cons_of_mem _ tail)
      exact ⟨r.pos a h,(cand.1 a source).2⟩
    rcases List.mem_append.mp ha with head | rest
    · exact ordinary (List.mem_append_left _ head)
    · rcases List.mem_cons.mp rest with rfl | tail
      · exact ⟨Or.inr rfl,by decide⟩
      · exact ordinary (List.mem_append_right _ tail)
  have cut := physical_cut_split cand r.split r.inv
    (fun a ha => r.pos a (List.mem_append_right _ ha))
  apply any_low i low
  intro s
  let u : Input := fun j => decide (j=i ∨ j∈s)
  have on : innerValue pre g u = true := by
    apply inner_mono_inputs (fun a ha => r.pos a (List.mem_append_left _ ha)) g _ hot
    intro k hk
    have eq : k=i := by simpa [SignedClamp.singleton] using hk
    simp [u,eq]
  have cmp := cut.computes u
  rw [on] at cmp
  unfold sees
  rw [eval_specialize]
  have same : (fun j => pval (fun k => decide (k∈s)) (setHigh i j)) = u :=
    funext (row_eval i s)
  rw [same,CircuitCompiler.compile_eval _ _ mono]
  change (wiresFrom (pre ++ (⟨.or,[]⟩ : Gate) :: post) _).getD _ _ = _
  rw [wiresFrom_append]
  exact cmp

end PEqualNP.Outside.L_meta_9822.Sectors.LowPositive
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowPositive.low_guard_floor
