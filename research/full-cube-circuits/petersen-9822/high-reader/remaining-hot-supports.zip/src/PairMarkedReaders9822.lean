import PairPinStates9822
import PairFourDebit9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp LowHotElimination
open scoped Classical
open PEqualNP.Outside.L_meta_9822.Clean ReaderDebit NonrawSupport
theorem four_signed_readers {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (cl : CleanL 10 C.gates) (seven : C.gates.countP countsAnd≤7)
    (s t : V) (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V))) (p tail : List Gate)
    (whole : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length])
    (order : p.length<pre.length) :
    C.gates.countP (fun q => decide (q.op=.and) && (q.inputs.any fun j =>
      decide (j=s.val ∨ j=t.val ∨ j=10+p.length ∨ j=10+pre.length))) ≤ 3 := by
  by_contra! many
  let S : Finset V := {s,t}
  have a := raw_zero_status C S s (by simp [S])
  have b := raw_zero_status C S t (by simp [S])
  have h := literal_zero_status s t p tail whole
  have z := neg_one_status s t p tail pre post g whole r.split unary r.inv order
  apply four_fold_impossible C cand cl seven s t shape _ (by exact many)
  · intro q _ marked
    simp only [Bool.and_eq_true_iff,decide_eq_true_eq,List.any_eq_true] at marked
    obtain ⟨op,j,inp,pin⟩ := marked
    refine ⟨op,j,inp,?_⟩
    rcases pin with e|e|e|e <;> subst j
    · exact ⟨false,a⟩
    · exact ⟨false,b⟩
    · exact ⟨false,h⟩
    · exact ⟨true,z⟩
  · intro q m no
    have eq : q=g := by
      by_contra ne
      rw [r.split] at m
      have pos := r.pos q (by simpa [List.mem_append,ne] using m)
      rcases pos with e|e <;> simp_all
    subst q
    exact ⟨10+p.length,by simp [unary],false,h⟩
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.four_signed_readers
