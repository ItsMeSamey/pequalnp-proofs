import OddCore
import Mathlib.Tactic.FinCases

/- BEGIN OR9822Obstruction.lean -/

namespace Research.OddOr
open FreeAndNet

variable {α : Type} [Fintype α] [DecidableEq α]

noncomputable def truthRows (f : Finset α → Bool) : List (Probe α) :=
  Finset.univ.toList.map (fun s => (s,f s))

theorem row_live (f : Finset α → Bool) (s : Finset α) : (s,f s) ∈ truthRows f := by
  simp [truthRows]

/-- A proper support with three distinct exterior cofactors cannot communicate
through one Boolean gate. The distinguishing exterior may depend on the pair. -/
def ThreeCofactors (f : Finset α → Bool) (u : Finset α) :=
  ∃ front : Fin 3 → Finset α, (∀ j, front j ⊆ u) ∧
    ∀ j k, j ≠ k → ∃ r : Finset α, Disjoint r u ∧ f (front j ∪ r) ≠ f (front k ∪ r)

private theorem bit_collision (b : Fin 3 → Bool) : ∃ j k, j ≠ k ∧ b j = b k := by
  by_cases h : b 0 = b 1
  · exact ⟨0,1,by decide,h⟩
  by_cases g : b 1 = b 2
  · exact ⟨1,2,by decide,g⟩
  refine ⟨0,2,by decide,?_⟩
  cases e : b 0 <;> cases d : b 1 <;> cases c : b 2 <;> simp_all

private theorem firstBit_add {a b s r : Finset α} (hr : Disjoint r (a ∪ b)) :
    firstBit a b (s ∪ r) = firstBit a b s := by
  have drop (q : Finset α) (hq : q ⊆ a ∪ b) : q ⊆ s ∪ r ↔ q ⊆ s := by
    refine ⟨?_,fun h => h.trans Finset.subset_union_left⟩
    intro h x hx
    rcases Finset.mem_union.mp (h hx) with hs | hrx
    · exact hs
    · exact (Finset.disjoint_left.mp hr hrx (hq hx)).elim
  simp only [firstBit,drop a Finset.subset_union_left,drop b Finset.subset_union_right]

theorem obstruct_of_three {f : Finset α → Bool} (a b : Finset α)
    (three : ThreeCofactors f (a ∪ b)) :
    ∃ x ∈ truthRows f, ∃ y ∈ truthRows f, x.2 ≠ y.2 ∧
      x.1 \ (a ∪ b) = y.1 \ (a ∪ b) ∧ firstBit a b x.1 = firstBit a b y.1 := by
  obtain ⟨front,sub,different⟩ := three
  obtain ⟨j,k,ne,eq⟩ := bit_collision (fun j => firstBit a b (front j))
  obtain ⟨r,hr,neq⟩ := different j k ne
  refine ⟨_,row_live f (front j ∪ r),_,row_live f (front k ∪ r),neq,?_,?_⟩
  · change (front j ∪ r) \ (a ∪ b) = (front k ∪ r) \ (a ∪ b)
    ext x
    by_cases hx : x ∈ a ∪ b
    · simp [Finset.mem_sdiff,hx]
    · have hj : x ∉ front j := fun h => hx (sub j h)
      have hk : x ∉ front k := fun h => hx (sub k h)
      simp [Finset.mem_sdiff,hj,hk]
  · simpa only [firstBit_add hr] using eq

/-- It is enough to give an exterior experiment distinguishing each of the
three unordered pairs of local settings. -/
theorem three_from_tests (f : Finset α → Bool) (u p q r e₀₁ e₀₂ e₁₂ : Finset α)
    (hp : p ⊆ u) (hq : q ⊆ u) (hr : r ⊆ u)
    (h₀₁ : Disjoint e₀₁ u ∧ f (p ∪ e₀₁) ≠ f (q ∪ e₀₁))
    (h₀₂ : Disjoint e₀₂ u ∧ f (p ∪ e₀₂) ≠ f (r ∪ e₀₂))
    (h₁₂ : Disjoint e₁₂ u ∧ f (q ∪ e₁₂) ≠ f (r ∪ e₁₂)) :
    ThreeCofactors f u := by
  let front : Fin 3 → Finset α := fun j => if j = 0 then p else if j = 1 then q else r
  refine ⟨front,?_,?_⟩
  · intro j
    fin_cases j <;> first | exact hp | exact hq | exact hr
  · intro j k ne
    fin_cases j <;> fin_cases k <;> first
      | exact (ne rfl).elim
      | exact ⟨e₀₁,h₀₁.1,h₀₁.2⟩
      | exact ⟨e₀₂,h₀₂.1,h₀₂.2⟩
      | exact ⟨e₁₂,h₁₂.1,h₁₂.2⟩
      | exact ⟨e₀₁,h₀₁.1,Ne.symm h₀₁.2⟩
      | exact ⟨e₀₂,h₀₂.1,Ne.symm h₀₂.2⟩
      | exact ⟨e₁₂,h₁₂.1,Ne.symm h₁₂.2⟩

/-- At the full support each conjunction covering two distinct minimal
positive supports also covers their negative intersection. -/
theorem obstruct_full_support {f : Finset α → Bool} (a b : Finset α)
    (full : a ∪ b = Finset.univ) (edges : Fin 3 → Finset α)
    (hot : ∀ j, f (edges j) = true) (cold : f ∅ = false)
    (meet : ∀ j k, j ≠ k → f (edges j ∩ edges k) = false) :
    ∃ x ∈ truthRows f, ∃ y ∈ truthRows f, x.2 ≠ y.2 ∧
      x.1 \ (a ∪ b) = y.1 \ (a ∪ b) ∧ firstBit a b x.1 = firstBit a b y.1 := by
  classical
  by_contra no
  have unique (x y : Finset α) (h : f x ≠ f y) : firstBit a b x ≠ firstBit a b y := by
    intro he
    exact no ⟨_,row_live f x,_,row_live f y,h,by ext z; simp [full,Finset.mem_sdiff],he⟩
  have empty : firstBit a b ∅ = false := by
    cases h : firstBit a b ∅ with
    | false => rfl
    | true =>
      have le : a ⊆ ∅ ∨ b ⊆ ∅ := of_decide_eq_true h
      have he : firstBit a b (edges 0) = true := by
        apply decide_eq_true
        exact le.imp (fun hl => hl.trans (Finset.empty_subset _)) (fun hl => hl.trans (Finset.empty_subset _))
      exact (unique ∅ (edges 0) (by simp [cold,hot]) (h.trans he.symm)).elim
  have has (j : Fin 3) : a ⊆ edges j ∨ b ⊆ edges j := by
    have ne := unique (edges j) ∅ (by simp [hot,cold])
    rw [empty] at ne
    cases he : firstBit a b (edges j) with
    | false => exact (ne he).elim
    | true => exact of_decide_eq_true he
  obtain ⟨j,k,jk,eq⟩ := bit_collision (fun j => decide (a ⊆ edges j))
  have yes : firstBit a b (edges j ∩ edges k) = true := by
    apply decide_eq_true
    by_cases ha : a ⊆ edges j
    · have hb : a ⊆ edges k := by simpa [ha] using eq.symm
      exact Or.inl (Finset.subset_inter ha hb)
    · have hb : ¬ a ⊆ edges k := by simpa [ha] using eq.symm
      exact Or.inr (Finset.subset_inter ((has j).resolve_left ha) ((has k).resolve_left hb))
  have hj : firstBit a b (edges j) = true := decide_eq_true (has j)
  exact unique (edges j) (edges j ∩ edges k) (by simp [hot,meet j k jk]) (hj.trans yes.symm)

theorem obstruction_from_cofactors {f : Finset α → Bool}
    (proper : ∀ u : Finset α, 2 ≤ u.card → u ≠ Finset.univ → ThreeCofactors f u)
    (edges : Fin 3 → Finset α) (hot : ∀ j, f (edges j) = true) (cold : f ∅ = false)
    (meet : ∀ j k, j ≠ k → f (edges j ∩ edges k) = false) :
    Obstructs (truthRows f) := by
  intro a b big
  by_cases full : a ∪ b = Finset.univ
  · exact obstruct_full_support a b full edges hot cold meet
  · exact obstruct_of_three a b (proper _ big full)

end Research.OddOr
/- END OR9822Obstruction.lean -/

/- BEGIN OR9822Neighborhood.lean -/

namespace Research.OddOr
variable {α : Type} [Fintype α] [DecidableEq α]

/-- Ordinary graph hypotheses suffice to generate the three cofactor rows at
every proper support with at least two vertices. -/
theorem neighborhood_three (f : Finset α → Bool)
    (cold : f ∅ = false) (coldOne : ∀ i, f {i} = false)
    (neighbor : ∀ i, ∃ j, f {i,j} = true)
    (diff : ∀ i j, i ≠ j → f {i,j} = false → ∃ w, f {i,w} ≠ f {j,w})
    (cross : ∀ u : Finset α, u.Nonempty → u ≠ Finset.univ →
      ∃ x ∈ u, ∃ y ∉ u, f {x,y} = true)
    (u : Finset α) (big : 2 ≤ u.card) (proper : u ≠ Finset.univ) :
    ThreeCofactors f u := by
  classical
  obtain ⟨p,hp,q,hq,ne⟩ := Finset.one_lt_card.mp big
  by_cases inside : ∃ x ∈ u, ∃ y ∈ u, f {x,y} = true
  · obtain ⟨x,hx,y,hy,hxy⟩ := inside
    obtain ⟨v,hv,w,hw,on⟩ := cross u ⟨p,hp⟩ proper
    apply three_from_tests f u ∅ {v} {x,y} {w} ∅ ∅
    · exact Finset.empty_subset _
    · simpa using hv
    · intro z hz
      rcases Finset.mem_insert.mp hz with rfl | hz
      · exact hx
      · simpa only [Finset.mem_singleton.mp hz] using hy
    · exact ⟨Finset.disjoint_singleton_left.mpr hw,by simpa [coldOne,on]⟩
    · simp [cold,hxy]
    · simp [coldOne,hxy]
  · have off (i : α) (hi : i ∈ u) (j : α) (hj : j ∈ u) : f {i,j} = false := by
      cases h : f {i,j} with
      | false => rfl
      | true => exact (inside ⟨i,hi,j,hj,h⟩).elim
    obtain ⟨a,ha⟩ := neighbor p
    obtain ⟨b,hb⟩ := neighbor q
    obtain ⟨w,hw⟩ := diff p q ne (off p hp q hq)
    have hna : a ∉ u := fun h => Bool.noConfusion (ha.symm.trans (off p hp a h))
    have hnb : b ∉ u := fun h => Bool.noConfusion (hb.symm.trans (off q hq b h))
    have hnw : w ∉ u := fun h => hw ((off p hp w h).trans (off q hq w h).symm)
    apply three_from_tests f u ∅ {p} {q} {a} {b} {w}
    · exact Finset.empty_subset _
    · simpa using hp
    · simpa using hq
    · exact ⟨Finset.disjoint_singleton_left.mpr hna,by simpa [coldOne,ha]⟩
    · exact ⟨Finset.disjoint_singleton_left.mpr hnb,by simpa [coldOne,hb]⟩
    · exact ⟨Finset.disjoint_singleton_left.mpr hnw,by simpa using hw⟩

/-- A certified spanning walk suffices for the cut-crossing premise. -/
theorem crosses_of_walk (f : Finset α → Bool) (walk : List α)
    (spans : ∀ j, j ∈ walk)
    (steps : walk.IsChain (fun x y => f {x,y} = true))
    (u : Finset α) (nonempty : u.Nonempty) (proper : u ≠ Finset.univ) :
    ∃ x ∈ u, ∃ y ∉ u, f {x,y} = true := by
  classical
  by_contra no
  have agree (x y : α) (on : f {x,y} = true) : x ∈ u ↔ y ∈ u := by
    constructor
    · intro hx
      by_contra hy
      exact no ⟨x,hx,y,hy,on⟩
    · intro hy
      by_contra hx
      exact no ⟨y,hy,x,hx,by simpa [Finset.pair_comm] using on⟩
  have same (l : List α) (hl : l.IsChain (fun x y => f {x,y} = true)) :
      ∀ x ∈ l, ∀ y ∈ l, x ∈ u ↔ y ∈ u := by
    induction l with
    | nil => simp
    | cons a l ih =>
      cases l with
      | nil => simp
      | cons b l =>
        have h := List.isChain_cons_cons.mp hl
        have tail := ih h.2
        intro x hx y hy
        rcases List.mem_cons.mp hx with ha | inx
        · subst x
          rcases List.mem_cons.mp hy with hb | iny
          · subst y; rfl
          · exact (agree _ _ h.1).trans (tail b List.mem_cons_self y iny)
        · rcases List.mem_cons.mp hy with hb | iny
          · subst y
            exact (tail x inx b List.mem_cons_self).trans (agree _ _ h.1).symm
          · exact tail x inx y iny
  obtain ⟨x,hx⟩ := nonempty
  apply proper
  exact Finset.eq_univ_of_forall (fun y => (same walk steps x (spans x) y (spans y)).mp hx)

end Research.OddOr
/- END OR9822Neighborhood.lean -/

/- BEGIN OR9822Core.lean -/
namespace Research.OddOr
open FreeAndNet

variable {α : Type} [Fintype α] [DecidableEq α]

structure GraphRows (f : Finset α → Bool) where
  walk : List α
  spans : ∀ i, i ∈ walk
  steps : walk.IsChain (fun x y => f {x,y} = true)
  cold : f ∅ = false
  singleton : ∀ i, f {i} = false
  neighbor : ∀ i, ∃ j, f {i,j} = true
  diff : ∀ i j, i ≠ j → f {i,j} = false → ∃ w, f {i,w} ≠ f {j,w}
  avoiding : ∀ i, ∃ x y, i ≠ x ∧ i ≠ y ∧ f {x,y} = true
  edges : Fin 3 → Finset α
  hot : ∀ j, f (edges j) = true
  meet : ∀ j k, j ≠ k → f (edges j ∩ edges k) = false

theorem graph_raise [Nonempty α] {f : Finset α → Bool} (g : GraphRows f)
    (k : Nat) (price : ∀ i : α, ∀ t : Net α, (∀ s : Finset α, i ∉ s → sees t s = f s) →
      k ≤ t.cost) (t : Net α) (exactOn : ∀ s : Finset α, sees t s = f s) :
    k + 2 ≤ t.cost := by
  classical
  have sep := obstruction_from_cofactors (neighborhood_three f g.cold g.singleton
    g.neighbor g.diff (crosses_of_walk f g.walk g.spans g.steps)) g.edges g.hot g.cold g.meet
  have reads (v : Net α) (h : Matches v (truthRows f)) (s : Finset α) : sees v s = f s :=
    h _ (row_live f s)
  have noOut (v : Net α) (h : Matches v (truthRows f)) (i : α) : ¬outUses i v := by
    obtain ⟨x,y,hx,hy,on⟩ := g.avoiding i
    exact avoids_output v (by simp [hx,hy] : i ∉ ({x,y} : Finset α)) ((reads v h _).trans on)
  refine core_lower sep noOut ?_ ?_ t ?_
  · intro v h
    let i : α := Classical.choice (inferInstance : Nonempty α)
    obtain ⟨j,on⟩ := g.neighbor i
    exact ⟨i,positive_hit v ((reads v h _).trans (g.singleton j))
      ((reads v h _).trans on) (noOut v h i)⟩
  · intro v h i
    apply price i
    intro s hs
    exact (pin_sees i v s hs).trans (reads v h s)
  · intro row hr
    obtain ⟨s,_,rfl⟩ := List.mem_map.mp hr
    exact exactOn s

/-- A path of paid deletions yields its length as an unconditional floor. -/
theorem price_from_peel {f : Finset α → Bool} (cold : ∀ i, f {i} = false)
    {i : α} {xs : List α} {core : Finset α}
    (peel : Peel (fun a b => f {a,b} = true) xs core)
    (off : i ∉ xs.toFinset ∪ core)
    (t : Net α) (h : ∀ s : Finset α, i ∉ s → sees t s = f s) : xs.length ≤ t.cost := by
  have neq {x : α} (hx : x ∈ xs.toFinset ∪ core) : i ≠ x := fun eq => off (eq ▸ hx)
  have fit : Fits (fun a b => f {a,b} = true) (xs.toFinset ∪ core) t := by
    constructor
    · intro j hj
      exact (h _ (by simp [neq hj])).trans (cold j)
    · intro x hx y hy on
      exact (h _ (by simp [neq hx,neq hy])).trans on
  obtain ⟨v,paid,_⟩ := peel_cost peel t fit
  omega

end Research.OddOr
/- END OR9822Core.lean -/

/- BEGIN OddPhysical.lean -/
namespace Research.OddOr
open FreeAndNet
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

noncomputable def inverseRaw {α β : Type} (e : β ↪ α) (i : α) : Product β := by
  classical
  exact if h : ∃ j, e j = i then some [h.choose] else none

theorem reembed {α β : Type} [DecidableEq α] [DecidableEq β] (e : β ↪ α)
    (t : Net α) (s : Finset β) : sees (specialize (inverseRaw e) t) s = sees t (s.map e) := by
  classical
  unfold sees
  rw [eval_specialize]
  congr 1
  funext i
  by_cases h : ∃ j, e j = i
  · have eq := h.choose_spec
    rw [←eq]
    have hinv : inverseRaw e (e h.choose) = some [h.choose] := by
      unfold inverseRaw
      split
      next h' => rw [e.injective h'.choose_spec]
      next no => exact (no ⟨_,rfl⟩).elim
    simp [hinv,pval]
  · have hm : i ∉ s.map e := by
      intro hx
      obtain ⟨j,_,eq⟩ := Finset.mem_map.mp hx
      exact h ⟨j,eq⟩
    simp [inverseRaw,h,pval,hm]

theorem physical_lift {n : Nat} {β : Type} [DecidableEq β]
    {E : Fin n → Fin n → Prop} {xs : List (Fin n)} {core : Finset (Fin n)}
    (e : β ↪ Fin n) (rows : List (Probe β)) (k : Nat)
    (cover : ∀ r ∈ rows, r.1.map e ⊆ core)
    (lower : ∀ t : Net β, Matches t rows → k ≤ t.cost)
    (peel : Peel E xs core) (C : Circuit) (hm : Monotone2 C)
    (cold : ∀ i ∈ xs.toFinset ∪ core,
      C.eval (List.ofFn (fun j => decide (j ∈ ({i} : Finset (Fin n))))) = false)
    (edge : ∀ i ∈ xs.toFinset ∪ core, ∀ j ∈ xs.toFinset ∪ core, E i j →
      C.eval (List.ofFn (fun z => decide (z ∈ ({i,j} : Finset (Fin n))))) = true)
    (observed : ∀ r ∈ rows, C.eval (List.ofFn (fun j => decide (j ∈ r.1.map e))) = r.2) :
    k + xs.length ≤ (C.gates.filter CircuitCompiler.orFlag).length := by
  classical
  let t := CircuitCompiler.compile n C
  have read (s : Finset (Fin n)) : sees t s = C.eval (List.ofFn (fun i => decide (i ∈ s))) :=
    CircuitCompiler.compile_eval n C hm _
  have fit : Fits E (xs.toFinset ∪ core) t :=
    ⟨fun i hi => (read _).trans (cold i hi),
     fun i hi j hj he => (read _).trans (edge i hi j hj he)⟩
  obtain ⟨u,hu,eq⟩ := peel_cost peel t fit
  have ok : Matches (specialize (inverseRaw e) u) rows := by
    intro r hr
    exact (reembed e u _).trans ((eq _ (cover r hr)).trans ((read _).trans (observed r hr)))
  have base := (lower _ ok).trans (specialize_cost (inverseRaw e) u)
  have cost := CircuitCompiler.compile_cost n C
  change t.cost ≤ _ at cost
  omega
end Research.OddOr
/- END OddPhysical.lean -/

