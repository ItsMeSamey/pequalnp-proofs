import OR9822Prefix
import OR9822Combinatorics

/- BEGIN OR9822Terminal.lean -/
namespace Research.OddOr.Theta
open FreeAndNet

inductive Survivor {κ : Type} (f : Row κ → Bool) (a b : Term κ) : Prop
  | left (h : ∀ x, CutBit a b x = termVal x a)
  | right (h : ∀ x, CutBit a b x = termVal x b)
  | short (i : κ) (ha : i ∈ a.support) (hb : i ∈ b.support)
  | direct (i : κ) (h : ∀ x, CutBit a b x = (x.raw i || (x.l && x.r)))
      (on : ∀ x : Row κ, (x.l && x.r) = true → f x = true)

theorem alias_escape {κ α ι : Type} [Fintype ι] (samples : ι → Row κ) (s : State κ α)
    (a b p : List α) (t : Net (Option α))
    (h : ∀ x, (a.all (val x ∘ s.atom) || b.all (val x ∘ s.atom)) = p.all (val x ∘ s.atom)) :
    Escape samples s (.gate a b t) := by
  let sub := fun z : Option α => z.elim (some p) (fun j => some [j])
  left
  refine ⟨specialize sub t,?_,Or.inl (Nat.lt_succ_of_le (specialize_cost sub t))⟩
  intro x
  rw [eval_specialize,Net.eval]
  congr 1
  funext z
  cases z <;> simp [sub,pval,h]

def SingletonData {κ ι : Type} (samples : ι → Row κ) (f : Row κ → Bool) :=
  (∀ j, ((samples j).l && (samples j).r) = false) ∧
  (∀ j, f (samples j) = false) ∧ (∀ i, ∃ j, (samples j).raw i = true)

theorem terminal_escape {κ α ι : Type} [DecidableEq κ] [Fintype ι]
    (samples : ι → Row κ) (f : Row κ → Bool) (singleton : SingletonData samples f)
    (pivots : ∀ i, ∃ x y : Row κ, VariesOnly i x y ∧ f x ≠ f y)
    (residual : ∀ i, ∃ z : Row κ, z.raw i = false ∧ f z = true)
    (classify : ∀ a b : Term κ, (a.support ≠ ∅ ∨ b.support ≠ ∅) →
      CoversPivots f a b → Survivor f a b)
    (s : State κ α) (a b : List α) (t : Net (Option α))
    (fresh : (product s.atom a).support ≠ ∅ ∨ (product s.atom b).support ≠ ∅)
    (limited : ∀ i, hits (s.read i) (.gate a b t) ≤ 1 ∧ ¬outUses (s.read i) (.gate a b t))
    (sem : ∀ x, (Net.gate a b t).eval (val x ∘ s.atom) = f x) :
    Escape samples s (.gate a b t) := by
  classical
  have cases' := classify _ _ fresh (covers_of_gate f s a b t limited sem)
  cases cases' with
  | left h => exact alias_escape samples s a b a t (fun x => (cutbit_eq s a b x).trans ((h x).trans (product_val _ _ _).symm))
  | right h => exact alias_escape samples s a b b t (fun x => (cutbit_eq s a b x).trans ((h x).trans (product_val _ _ _).symm))
  | short i ha hb =>
    right
    have ha' := (raw_read s a i).1 ha
    have hb' := (raw_read s b i).1 hb
    refine ⟨i,DoubleLoss.here a b t ha' hb' ?_⟩
    obtain ⟨x,y,delta,hxy⟩ := pivots i
    obtain ⟨z,hz,hon⟩ := residual i
    have raw_eq : s.atom (s.read i) = .raw i := (s.raw_iff _ _).2 rfl
    have killed (p : List α) (mem : s.read i ∈ p) : p.all (val z ∘ s.atom) = false := by
      cases hp : p.all (val z ∘ s.atom) with
      | false => rfl
      | true =>
        have h := List.all_eq_true.mp hp _ mem
        simp [Function.comp_apply,raw_eq,val,hz] at h
    apply downstream_hit t (s.read i) a b (val x ∘ s.atom) (val y ∘ s.atom) (val z ∘ s.atom)
    · exact no_second_read s a b t i (Finset.mem_union_left _ ha) (limited i)
    · exact raw_agree s delta
    · simpa only [sem] using hxy
    · simp [killed a ha',killed b hb']
    · exact (sem z).trans hon
  | direct i h on =>
    left
    let ep : List α := [s.left,s.right]
    have ev (x : Row κ) : ep.all (val x ∘ s.atom) = (x.l && x.r) := by
      simp [ep,Function.comp_apply,s.hleft,s.hright,val,Ep.eval]
    have read (x : Row κ) : (val x ∘ s.atom) (s.read i) = x.raw i := by
      simp [Function.comp_apply,(s.raw_iff _ _).2 rfl,val]
    have gate (x : Row κ) := (cutbit_eq s a b x).trans (h x)
    refine ⟨postpone (s.read i) ep t,?_,?_⟩
    · intro x
      apply move_semantic_gate
      · simpa only [read,ev] using gate x
      · intro he
        exact (sem x).trans (on x ((ev x).symm.trans he))
    · apply move_improves
      · intro j; rw [ev]; exact singleton.1 j
      · intro j; rw [gate,read,singleton.1]; simp
      · intro j; rw [sem]; exact singleton.2.1 j
      · obtain ⟨j,hj⟩ := singleton.2.2 i
        exact ⟨j,by simpa only [read] using hj⟩

end Research.OddOr.Theta
/- END OR9822Terminal.lean -/

/- BEGIN OR9822Sparse.lean -/
namespace Research.OddOr.Theta

variable {κ : Type} [DecidableEq κ]

def SparsePivot (f : Row κ → Bool) :=
  ∀ i j : κ, i ≠ j → ∃ x y : Row κ, VariesOnly i x y ∧ f x ≠ f y ∧
    x.raw j = false ∧ y.raw j = false

theorem term_killed (p : Term κ) (x : Row κ) {j : κ} (mem : j ∈ p.support)
    (off : x.raw j = false) : termVal x p = false := by
  have h : ¬ ∀ i ∈ p.support, x.raw i = true := by
    intro all
    simpa [off] using all j mem
  simp [termVal,h]

theorem term_fixed (p : Term κ) {i : κ} (notin : i ∉ p.support) (x y : Row κ)
    (delta : VariesOnly i x y) : termVal x p = termVal y p := by
  have eq (j : κ) (h : j ∈ p.support) : x.raw j = y.raw j :=
    delta.2.2 j (fun e => notin (e ▸ h))
  have same : (∀ j ∈ p.support, x.raw j = true) ↔ (∀ j ∈ p.support, y.raw j = true) := by
    constructor
    · intro h j hj
      rw [← eq j hj]
      exact h j hj
    · intro h j hj
      rw [eq j hj]
      exact h j hj
  simp only [termVal,same,delta.1,delta.2.1]

theorem disjoint_small (f : Row κ → Bool) (sp : SparsePivot f) (a b : Term κ)
    (dis : Disjoint a.support b.support) (cut : CoversPivots f a b) : a.support.card ≤ 1 := by
  by_contra! large
  obtain ⟨i,hi,j,hj,ne⟩ := Finset.one_lt_card.mp large
  obtain ⟨x,y,change,neq,offx,offy⟩ := sp i j ne
  have eq := term_fixed b (Finset.disjoint_left.mp dis hi) x y change
  exact cut i (Finset.mem_union_left _ hi) x y change neq (by
    simp only [CutBit,term_killed a x hj offx,term_killed a y hj offy,Bool.false_or,eq])

theorem flip_cut (a b : Term κ) (f : Row κ → Bool) (cut : CoversPivots f a b) : CoversPivots f b a := by
  simpa only [CoversPivots,Finset.union_comm,CutBit,Bool.or_comm] using cut

theorem classify_small (f : Row κ → Bool) (sp : SparsePivot f)
    (small : ∀ a b : Term κ, a.support.card ≤ 1 → b.support.card ≤ 1 →
      (a.support ≠ ∅ ∨ b.support ≠ ∅) → CoversPivots f a b → Survivor f a b) :
    ∀ a b : Term κ, (a.support ≠ ∅ ∨ b.support ≠ ∅) →
      CoversPivots f a b → Survivor f a b := by
  intro a b fresh cut
  by_cases dis : Disjoint a.support b.support
  · exact small a b (disjoint_small f sp a b dis cut)
      (disjoint_small f sp b a dis.symm (flip_cut a b f cut)) fresh cut
  · obtain ⟨i,ha,hb⟩ := Finset.not_disjoint_iff.mp dis
    exact .short i ha hb

end Research.OddOr.Theta
/- END OR9822Sparse.lean -/

/- BEGIN OR9822Tiny.lean -/
namespace Research.OddOr.Theta
variable {κ : Type} [DecidableEq κ]

abbrev Tiny (κ : Type) := Option κ × Ep

def body (p : Tiny κ) : Term κ := ⟨p.1.elim ∅ (fun i => {i}),p.2⟩
def tinyVal (p : Tiny κ) (x : Row κ) := p.1.elim true x.raw && p.2.eval x.l x.r

theorem body_val (p : Tiny κ) (x : Row κ) : termVal x (body p) = tinyVal p x := by
  obtain ⟨_ | i,e⟩ := p <;> simp [body,termVal,tinyVal]

theorem exists_tiny (t : Term κ) (h : t.support.card ≤ 1) : ∃ p : Tiny κ, body p = t := by
  obtain ⟨s,e⟩ := t
  change s.card ≤ 1 at h
  by_cases empty : s = ∅
  · subst s; exact ⟨(none,e),rfl⟩
  · obtain ⟨i,hi⟩ := Finset.card_eq_one.mp (by
      have := Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr empty)
      omega : s.card = 1)
    subst s
    exact ⟨(some i,e),rfl⟩

def Subsumed (p q : Tiny κ) : Prop :=
  (q.1 = none ∨ q.1 = p.1) ∧ ∀ l r : Bool, p.2.eval l r = true → q.2.eval l r = true

instance (p q : Tiny κ) : Decidable (Subsumed p q) := inferInstanceAs (Decidable (_ ∧ _))

theorem subsumed_true {p q : Tiny κ} (h : Subsumed p q) (x : Row κ)
    (yes : tinyVal p x = true) : tinyVal q x = true := by
  obtain ⟨raw,ep⟩ := Bool.and_eq_true_iff.mp yes
  apply Bool.and_eq_true_iff.mpr
  refine ⟨?_,h.2 _ _ ep⟩
  rcases h.1 with emp | eq
  · simp [emp]
  · rwa [eq]

def bump (i : κ) (x : Row κ) : Row κ :=
  {x with raw := fun j => if j = i then true else x.raw j}

theorem bump_varies (i : κ) (x : Row κ) : VariesOnly i x (bump i x) :=
  ⟨rfl,rfl,fun j hj => by simp [bump,hj]⟩

def DirectShape (p q : Tiny κ) (i : κ) :=
  (p = (some i,Ep.unit) ∧ q = (none,Ep.both)) ∨ (q = (some i,Ep.unit) ∧ p = (none,Ep.both))

instance (p q : Tiny κ) (i : κ) : Decidable (DirectShape p q i) := inferInstanceAs (Decidable (_ ∨ _))

def Checked (f : Row κ → Bool) (edge : Bool) (p q : Tiny κ) (i : κ) (x : Row κ) : Prop :=
  (p.1 = none ∧ q.1 = none) ∨ Subsumed p q ∨ Subsumed q p ∨
  (p.1 = some i ∧ q.1 = some i) ∨ (edge = true ∧ DirectShape p q i) ∨
  ((p.1 = some i ∨ q.1 = some i) ∧ f x ≠ f (bump i x) ∧
    (tinyVal p x || tinyVal q x) = (tinyVal p (bump i x) || tinyVal q (bump i x)))

instance (f : Row κ → Bool) (edge : Bool) (p q : Tiny κ) (i : κ) (x : Row κ) :
    Decidable (Checked f edge p q i x) := inferInstanceAs (Decidable (_ ∨ _))

theorem checked_sound {f : Row κ → Bool} {edge : Bool} (edgeOn : edge = true →
    ∀ x : Row κ, (x.l && x.r) = true → f x = true) (p q : Tiny κ) (i : κ) (x : Row κ)
    (h : Checked f edge p q i x) (fresh : (body p).support ≠ ∅ ∨ (body q).support ≠ ∅)
    (cover : CoversPivots f (body p) (body q)) : Survivor f (body p) (body q) := by
  rcases h with ⟨hp,hq⟩ | hp | hq | ⟨hp,hq⟩ | ⟨ed,h⟩ | ⟨mem,neq,eq⟩
  · simp [body,hp,hq] at fresh
  · apply Survivor.right
    intro z
    simp only [CutBit,body_val]
    cases he : tinyVal p z <;> simp [he,subsumed_true hp z]
  · apply Survivor.left
    intro z
    simp only [CutBit,body_val]
    cases he : tinyVal q z <;> simp [he,subsumed_true hq z]
  · exact .short i (by simp [body,hp]) (by simp [body,hq])
  · apply Survivor.direct i _ (edgeOn ed)
    intro z
    rcases h with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ <;> simp [CutBit,body_val,tinyVal,Ep.eval,Bool.or_comm]
  · exfalso
    refine cover i ?_ x (bump i x) (bump_varies i x) neq ?_
    · rcases mem with h | h
      · exact Finset.mem_union_left _ (by simp [body,h])
      · exact Finset.mem_union_right _ (by simp [body,h])
    · simpa only [CutBit,body_val] using eq

theorem small_from_checked {f : Row κ → Bool} {edge : Bool} (edgeOn : edge = true →
    ∀ x : Row κ, (x.l && x.r) = true → f x = true)
    (witness : ∀ p q : Tiny κ, ∃ i x, Checked f edge p q i x)
    (a b : Term κ) (ha : a.support.card ≤ 1) (hb : b.support.card ≤ 1)
    (fresh : a.support ≠ ∅ ∨ b.support ≠ ∅) (cov : CoversPivots f a b) : Survivor f a b := by
  obtain ⟨p,rfl⟩ := exists_tiny a ha
  obtain ⟨q,rfl⟩ := exists_tiny b hb
  obtain ⟨i,x,h⟩ := witness p q
  exact checked_sound edgeOn p q i x h fresh cov

end Research.OddOr.Theta
/- END OR9822Tiny.lean -/

/- BEGIN OR9822ThetaRoot.lean -/
namespace Research.OddOr.Theta
open FreeAndNet

def readFin (k : Nat) (i : Fin k) : Fin (k+2) := ⟨i.val+2,by omega⟩

def initial (k : Nat) : State (Fin k) (Fin (k+2)) where
  atom z := if h : z.val < 2 then (if z.val = 0 then .ep .left else .ep .right)
    else .raw ⟨z.val-2,by omega⟩
  read := readFin k
  raw_iff := by
    intro z i
    split
    · rename_i h
      split <;> simp only [reduceCtorEq,false_iff]
      all_goals intro eq; have := congrArg Fin.val eq; simp [readFin] at this; omega
    · simp only [Atom.raw.injEq,Fin.ext_iff,readFin]
      omega
  left := 0
  right := 1
  hleft := by simp
  hright := by simp

def fromRow {k : Nat} (x : Row (Fin k)) : Finset (Fin (k+2)) :=
  Finset.univ.filter (fun z => val x ((initial k).atom z) = true)

def toRow {k : Nat} (s : Finset (Fin (k+2))) : Row (Fin k) :=
  ⟨decide (0 ∈ s),decide (1 ∈ s),fun i => decide (readFin k i ∈ s)⟩

theorem toRow_env {k} (s : Finset (Fin (k+2))) (z : Fin (k+2)) :
    val (toRow s) ((initial k).atom z) = decide (z ∈ s) := by
  simp only [initial]
  split
  · rename_i h
    split
    · rename_i zero
      have eq : z = 0 := Fin.ext (by simpa using zero)
      subst z
      rfl
    · rename_i nz
      have eq : z = 1 := Fin.ext (by simp; omega)
      subst z
      rfl
  · rename_i hn
    change decide (readFin k ⟨z.val-2,by omega⟩ ∈ s) = decide (z ∈ s)
    congr 2
    exact Fin.ext (by simp [readFin]; omega)

theorem from_to {k} (s : Finset (Fin (k+2))) : fromRow (toRow s) = s := by
  ext z
  simp [fromRow,toRow_env]

theorem from_env {k} (x : Row (Fin k)) (z : Fin (k+2)) :
    decide (z ∈ fromRow x) = val x ((initial k).atom z) := by
  simp [fromRow]

def samples (k : Nat) (j : Fin (k+2)) := toRow {j}

theorem theta_lower {k : Nat} [Nonempty (Fin k)] (F : Finset (Fin (k+2)) → Bool)
    (G : GraphRows F) (f : Row (Fin k) → Bool) (evaluation : ∀ x, f x = F (fromRow x))
    (price : ∀ i : Fin k, ∀ t : Net (Fin (k+2)),
      (∀ s : Finset (Fin (k+2)), readFin k i ∉ s → sees t s = F s) → k ≤ t.cost)
    (single : SingletonData (samples k) f)
    (pivots : ∀ i, ∃ x y, VariesOnly i x y ∧ f x ≠ f y)
    (residual : ∀ i, ∃ z, z.raw i = false ∧ f z = true)
    (classify : ∀ a b : Term (Fin k), (a.support ≠ ∅ ∨ b.support ≠ ∅) →
      CoversPivots f a b → Survivor f a b)
    (t : Net (Fin (k+2))) (computes : ∀ s, sees t s = F s) : k+2 ≤ t.cost := by
  classical
  let s := initial k
  let inputs := fun j : Fin (k+2) => val (samples k j) ∘ s.atom
  obtain ⟨u,hu,le,minimal⟩ := exists_minimal_net inputs (fun u => ∀ z, sees u z = F z) t computes
  by_contra! small
  have exactRows (x : Row (Fin k)) : u.eval (val x ∘ s.atom) = f x := by
    have h := hu (fromRow x)
    simpa only [sees,from_env,← evaluation,Function.comp_def,s] using h
  have pinPrice (i : Fin k) : k ≤ (pin (s.read i) u).cost := by
    apply price i
    intro z hz
    exact (pin_sees _ _ _ hz).trans (hu z)
  have noOut (i : Fin k) : ¬outUses (s.read i) u := by
    obtain ⟨a,b,ha,hb,on⟩ := G.avoiding (s.read i)
    exact avoids_output u (by simp [ha,hb] : s.read i ∉ ({a,b} : Finset _)) ((hu _).trans on)
  have limited (i : Fin k) : hits (s.read i) u ≤ 1 ∧ ¬outUses (s.read i) u := by
    have h := pin_cost (s.read i) u
    have p := pinPrice i
    exact ⟨by omega,noOut i⟩
  have live : ∃ i, 0 < hits (s.read i) u := by
    let i : Fin k := Classical.choice (inferInstance : Nonempty (Fin k))
    obtain ⟨j,on⟩ := G.neighbor (s.read i)
    exact ⟨i,positive_hit u ((hu _).trans (G.singleton j)) ((hu _).trans on) (noOut i)⟩
  have bad := scan (samples k) f (terminal_escape (samples k) f single pivots residual classify)
    s u live limited exactRows
  rcases bad with ⟨v,same,better⟩ | ⟨i,loss⟩
  · apply minimal v _ better
    intro z
    have h := same (toRow z)
    simpa only [sees,Function.comp_def,s,toRow_env] using h.trans (exactRows (toRow z) |>.trans
      ((evaluation _).trans (congrArg F (from_to z))))
  · have two := loss.saves (s.read i) u (kill (s.read i)) (by simp [kill])
    have bound := pinPrice i
    change (pin (s.read i) u).cost + 2 ≤ u.cost at two
    omega

end Research.OddOr.Theta
/- END OR9822ThetaRoot.lean -/

