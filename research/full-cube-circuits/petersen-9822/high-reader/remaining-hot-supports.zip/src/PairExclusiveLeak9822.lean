import TwoHighGuard9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem pair_exclusive_leak {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (s t : Fin 10)
    (guard : ∀ v : Input, innerValue pre g v = (v s || v t)) :
    ∃ v : Input, v s=true ∧ v t=false ∧ edge v=false ∧ outerValue pre post C.output v true=true := by
  by_contra! no
  let raw : Gate := ⟨.not,[t.val]⟩
  let D : Circuit := ⟨pre ++ raw :: post,C.output⟩
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have agree (v : Input) : outerValue pre post C.output v (!(v t)) = edge v := by
    have h := cut.computes v
    rw [guard] at h
    cases sv : v s <;> cases tv : v t <;> simp [sv,tv] at h ⊢
    all_goals first
      | exact h
      | cases e : edge v with
        | false => simpa using no v sv tv e
        | true => exact cut.increasing v (h.trans e)
  have hc : Candidate D := by
    refine ⟨?_,?_,?_⟩
    · intro q hq
      change q ∈ pre ++ raw :: post at hq
      rcases List.mem_append.mp hq with h | h
      · exact cand.1 q (by rw [r.split]; exact List.mem_append_left _ h)
      · rcases List.mem_cons.mp h with rfl | hp
        · exact ⟨by simp [raw],by simp [raw]⟩
        · exact cand.1 q (by rw [r.split]; exact List.mem_append_right _ (List.mem_cons_of_mem _ hp))
    · have cap : C.gates.length ≤ 17 := cand.2.1
      rw [r.split] at cap
      simpa [D,Circuit.size] using cap
    · intro v
      change (wiresFrom (pre++raw::post) (List.ofFn v)).getD _ false = _
      rw [wiresFrom_append]
      have leaf : (wiresFrom pre (List.ofFn v)).getD t.val false = v t := by
        rw [getD_wiresFrom _ _ _ (by simpa using t.isLt),getD_ofFn 10 v false t]
      change (wiresFrom post (wiresFrom pre (List.ofFn v) ++ [!((wiresFrom pre (List.ofFn v)).getD t.val false)])).getD _ false = _
      rw [leaf]
      exact agree v
  have cost : D.gates.countP countsAnd = C.gates.countP countsAnd := by
    rw [r.split]
    simp [D,raw,List.countP_append,List.countP_cons,countsAnd,r.inv]
  exact RawOwnerClamp.raw_seven_and_impossible D t pre post [] rfl r.pos (cost.symm ▸ seven) hc
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.pair_exclusive_leak
