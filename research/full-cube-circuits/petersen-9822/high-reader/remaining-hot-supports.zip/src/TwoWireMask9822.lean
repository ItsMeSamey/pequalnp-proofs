import PairReaderMask9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean
theorem two_wire_mask (gs : List Gate) (a b : List Bool) (z r : Nat) (off : Finset Nat)
    (len : a.length=b.length)
    (only : ∀ (k : Nat) (q : Gate), gs[k]?=some q → z∈q.inputs → a.length+k=r)
    (mask : ∀ (k : Nat) (q : Gate), gs[k]?=some q → r∈q.inputs → q.op=.and ∧ ∃ i∈q.inputs,i∈off)
    (earlier : ∀ i∈off,i<a.length ∧ a.getD i false=false ∧ b.getD i false=false)
    (eqv : ∀ j,j≠z → j≠r → a.getD j false=b.getD j false) :
    ∀ j,j≠z → j≠r → (wiresFrom gs a).getD j false=(wiresFrom gs b).getD j false := by
  induction gs generalizing a b with
  | nil => exact eqv
  | cons g gs ih =>
    let x := g.op.eval (g.inputs.map fun j => a.getD j false)
    let y := g.op.eval (g.inputs.map fun j => b.getD j false)
    apply ih (a++[x]) (b++[y]) (by simp [len])
    · intro k q h zread
      have h' := only (k+1) q (by simpa using h) zread
      simp;omega
    · intro k q h rread
      exact mask (k+1) q (by simpa using h) rread
    · intro i inside
      obtain ⟨ra,l,r⟩ := earlier i inside
      refine ⟨by simp;omega,?_,?_⟩
      · rwa [List.getD_append _ _ _ _ ra]
      · rwa [List.getD_append _ _ _ _ (by omega : i<b.length)]
    · intro j nz nr
      by_cases last : j=a.length
      · rw [last,getD_snoc_eq,len,getD_snoc_eq]
        by_cases reads : r∈g.inputs
        · obtain ⟨op,i,mem,inside⟩ := mask 0 g (by simp) reads
          obtain ⟨_,u,v⟩ := earlier i inside
          have zero (w : List Bool) (cold : w.getD i false=false) :
              g.op.eval (g.inputs.map fun j => w.getD j false)=false := by
            simp only [op,GateOp.eval,List.all_map,Function.comp_def,id_eq,List.all_eq_false]
            exact ⟨i,mem,by rw [cold];decide⟩
          exact (zero a u).trans (zero b v).symm
        · apply congrArg g.op.eval
          apply List.map_congr_left
          intro h hh
          exact eqv h (by rintro rfl;have := only 0 g (by simp) hh;omega)
            (by rintro rfl;contradiction)
      · rw [getD_snoc_ne _ _ _ _ last,getD_snoc_ne _ _ _ _ (by omega)]
        exact eqv j nz nr
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.two_wire_mask
