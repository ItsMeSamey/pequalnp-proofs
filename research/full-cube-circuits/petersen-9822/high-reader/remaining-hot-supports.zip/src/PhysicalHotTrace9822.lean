import TaggedCompilerHits9822
import OR9822Base

namespace PEqualNP.Outside.L_meta_9822.Clean.GuardTags
open PEqualNP.CircuitLowerBounds FreeAndNet FreeAndNet.CircuitCompiler Research.OddOr

def physicalHot : List Gate → List Bool → Nat
  | [], _ => 0
  | g::gs,w =>
    let y := g.op.eval (g.inputs.map (fun i => w.getD i false))
    physicalHot gs (w++[y]) + (orFlag g && y).toNat

private theorem all_prod {α : Type} (w : List (List α)) (v : α → Bool)
    (ins : List Nat) (legal : ∀ j ∈ ins,j<w.length) :
    ∃ p, substProduct (fun j => (w.map some).getD j none) ins = some p ∧
      p.all v = (ins.map (fun j => (w.map (fun q => q.all v)).getD j false)).all id := by
  induction ins with
  | nil => exact ⟨[],rfl,rfl⟩
  | cons j js ih =>
    have hj := legal j List.mem_cons_self
    obtain ⟨p,hp,hm⟩ := ih (fun a ha => legal a (List.mem_cons_of_mem j ha))
    have read : (w.map some).getD j none = some w[j] := by simp [List.getD_eq_getElem?_getD,hj]
    have val : (w.map (fun q => q.all v)).getD j false = w[j].all v := by
      simp [List.getD_eq_getElem?_getD,hj]
    refine ⟨w[j]++p,?_,?_⟩
    · simp only [substProduct,read,hp]
    · simp only [List.all_append,hm,List.map_cons,List.all_cons,id_eq,val]

theorem run_hot (gs : List Gate) (out : Nat) :
    ∀ {α : Type} (w : List (List α)) (v : α → Bool) (_ : TaggedWiring w.length gs)
      (_ : ∀ g∈gs,g.op=.and ∨ g.op=.or),
      physicalHot gs (w.map (fun q => q.all v)) =
      hotCount v (CircuitCompiler.run out gs (w.map some)) := by
  induction gs with
  | nil => intros; rfl
  | cons g gs ih =>
    intro α w v ok pos
    obtain ⟨legal,binary,tail⟩ := ok
    have pp := fun q (hq : q∈gs) => pos q (List.mem_cons_of_mem g hq)
    rcases pos g List.mem_cons_self with op|op
    · obtain ⟨p,hp,hm⟩ := all_prod w v g.inputs legal
      have h := ih (w++[p]) v (by simpa using tail) pp
      have no : orFlag g = false := by simp [orFlag,op]
      simp only [physicalHot,CircuitCompiler.run,no,Bool.false_eq_true,ite_false,hp,Bool.false_and,
        Bool.toNat_false,Nat.add_zero,op,GateOp.eval]
      simpa only [List.map_append,List.map_cons,List.map_nil,hm] using h
    · have yes : orFlag g = true := by simp [orFlag,op]
      obtain ⟨a,b,ins⟩ := binary yes
      have ha := legal a (by simp [ins])
      have hb := legal b (by simp [ins])
      let y := w[a].all v || w[b].all v
      let v' : Option α → Bool := fun j => j.elim y v
      let u : List (List (Option α)) := w.map (List.map some) ++ [[none]]
      have h := ih u v' (by simp [u]; exact tail) pp
      have val : u.map (fun q => q.all v') = w.map (fun q => q.all v) ++ [y] := by
        simp [u,v',List.map_map,List.all_map,Function.comp_def]
      have dataEq : u.map some = (w.map some).map liftP ++ [some [none]] := by
        simp [u,liftP,List.map_map,Function.comp_def]
      rw [val,dataEq] at h
      simp [physicalHot,CircuitCompiler.run,yes,ins,op,GateOp.eval,
        List.getD_eq_getElem?_getD,List.getElem?_eq_getElem ha,List.getElem?_eq_getElem hb,
        orStep,hotCount,List.map_map,liftP,Function.comp_def,y,v'] at h ⊢
      omega

end PEqualNP.Outside.L_meta_9822.Clean.GuardTags
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardTags.run_hot
