import GuardEmitterMinimum9822
import TaggedModel9822
import TaggedCutWiring9822
import HighUniqueExit9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open FreeAndNet Research.OddOr SignedClamp NonrawSupport OuterNet
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean GuardTags
private theorem sameContacts (out : Nat) (gs : List Gate) (w : List Bool) :
    GuardEmitter.contacts out gs w = markedTrace out gs w := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih => simp only [GuardEmitter.contacts,markedTrace,ih]

theorem high_one_reader {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10) (lo : 5 ≤ i.val) (hi : i.val ≤ 8)
    (hot : innerValue pre g (singleton i)=true)
    (minimal : Reduced 10 C.gates C.output) :
    post.countP (ReaderDebit.reads (10+pre.length)) ≤ 1 := by
  let t := model pre post C.output
  have contact := (unique_exit r cand seven i lo hi hot).1
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have on : innerValue pre g (fun _ => true)=true := inner_mono_inputs
    (fun q hq => r.pos q (List.mem_append_left _ hq)) g (fun _ _ => rfl) hot
  have all := cut.computes (fun _ => true)
  rw [on] at all
  have yes : t.eval (env (fun _ => true) false)=true := (model_eval r cand _ _).trans all
  have unmarked : ¬outUses (0 : Fin 11) t := by
    intro used
    have impossible := outZeros t 0 used (env (fun _ => true) false) rfl
    rw [yes] at impossible
    contradiction
  have red : Reduced 10 (pre++g::post) C.output := r.split ▸ minimal
  have valid := reduced_cut_wiring (pre:=pre) (post:=post) (g:=g) (out:=C.output) red
  have trace := one_physical_contact pre post C.output valid contact unmarked
  have split : C.gates=(pre++[g])++post := by simpa using r.split
  have small := minimal
  rw [split] at small
  have varied : ∃ x y : Input,vl ((pre++[g])++post) x C.output ≠ vl ((pre++[g])++post) y C.output := by
    refine ⟨fun _ => false,fun _ => true,?_⟩
    rw [← split]
    change C.eval _ ≠ C.eval _
    rw [cand.2.2,cand.2.2]
    decide
  have ordinary : GuardEmitter.checked post := by
    intro gate mem
    have pos := r.pos gate (List.mem_append_right _ mem)
    have full : gate∈C.gates := by rw [split]; exact List.mem_append_right _ mem
    obtain ⟨p,hp⟩ := List.mem_iff_getElem?.mp full
    rcases minimal.clean p gate hp with ⟨hn,_⟩ | ⟨_,j,k,_,_,shape⟩
    · rcases pos with e|e <;> rw [e] at hn <;> contradiction
    · exact ⟨pos,j,k,shape⟩
  exact GuardEmitter.minimum_readers (pre++[g]) post (10+pre.length) C.output
    (by simp; omega) small varied ordinary ((sameContacts _ _ _).trans trace)
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.high_one_reader
