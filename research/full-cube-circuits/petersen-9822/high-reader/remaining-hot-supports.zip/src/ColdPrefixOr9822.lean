import ColdObserver9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet Research.OddOr
open SignedClamp NonrawSupport OuterNet PEqualNP.Outside.L_meta_9822.Clean

theorem prefix_contains_or {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) : ∃ q∈pre, CircuitCompiler.orFlag q=true := by
  obtain ⟨v,_,_,on⟩ := independent_witness r cand seven 0
  cases ins : g.inputs with
  | nil => simp [innerValue,ins] at on
  | cons a more =>
    let D : Circuit := ⟨pre,a⟩
    let h := CircuitCompiler.compile 10 D
    have legal : Monotone2 D := by
      intro q hq
      exact ⟨r.pos q (List.mem_append_left _ hq),
        (cand.1 q (r.split ▸ List.mem_append_left _ hq)).2⟩
    have read (x : Input) : h.eval x=innerValue pre g x := by
      rw [show h.eval x=D.eval (List.ofFn x) from CircuitCompiler.compile_eval _ _ legal x]
      simp [innerValue,ins,D]
      rfl
    by_contra! absent
    have none : pre.filter CircuitCompiler.orFlag=[] := List.filter_eq_nil_iff.mpr (by
      intro q hq
      simpa using absent q hq)
    have cap := CircuitCompiler.compile_cost 10 D
    change h.cost ≤ (pre.filter CircuitCompiler.orFlag).length at cap
    rw [none] at cap
    cases he : h with
    | gate a b t => simp [he,Net.cost] at cap
    | out p =>
      have yes := (read v).trans on
      have off := (read (fun _ => false)).trans (cold_empty r cand seven)
      cases p with
      | none => simp [he,Net.eval,pval] at yes
      | some xs =>
        cases xs with
        | nil => simp [he,Net.eval,pval] at off
        | cons i is =>
          obtain ⟨w,wi,_,wh⟩ := independent_witness r cand seven i
          have hot := (read w).trans wh
          simp [he,Net.eval,pval,wi] at hot
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.prefix_contains_or
