import ColdPhysicalCorrection9822
import OuterZeroDebit9822
import GuardTrace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds
open SignedClamp NonrawSupport OuterNet FreeAndNet Research.OddOr
open Research.OddOr.Envelope Research.OddOr.Graph9822

private theorem pin_open (i : Fin 10) (t : Net (Fin 11)) (x : Input) (zero : x i=false) :
    (specialize (close true) (pin i.succ t)).eval x = t.eval (env x true) := by
  unfold pin
  rw [eval_specialize,close_eval,eval_specialize]
  congr 1
  funext j
  by_cases eq : j=i.succ
  · subst j; simp [kill,pval,env,zero]
  · simp [kill,eq,pval]

theorem cold_raw_hits {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (cold : ∀ j, innerValue pre g (SignedClamp.singleton j)=false)
    (i : Fin 10) : hits i.succ (model pre post C.output) ≤ 1 := by
  let t := model pre post C.output
  let u := specialize (close true) (pin i.succ t)
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have read (s : Finset (Fin 10)) (no : i∉s) :
      sees u s = outerValue pre post C.output (inputOn s) true :=
    (pin_open i t (inputOn s) (by simp [inputOn,no])).trans (model_eval r cand _ _)
  have off : ColdOff i u := by
    constructor
    · intro j no
      rw [read _ (by simpa [eq_comm] using no)]
      have eq : inputOn {j}=SignedClamp.singleton j := by funext k; simp [inputOn,SignedClamp.singleton]
      rw [eq]
      have yes := cut.computes (SignedClamp.singleton j)
      rw [cold j] at yes
      exact yes.trans (singleton_zero j)
    · intro j k nj nk on
      rw [read _ (by simp [eq_comm,nj,nk])]
      exact positive_upper cut _ on
  have floor := eight_off i u off
  have upper : u.cost ≤ (pin i.succ t).cost := specialize_cost _ _
  have saving := pin_cost i.succ t
  have cap : t.cost ≤ 9 := (model_cost r).trans (or_cap r cand seven)
  change hits i.succ t ≤ 1
  omega

theorem cold_no_raw_output {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (i : Fin 10) : ¬outUses i.succ (model pre post C.output) := by
  obtain ⟨a,b,ha,hb,on⟩ := data.avoiding i
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  let x := inputOn {a,b}
  have yes := (model_eval r cand x true).trans (positive_upper cut _ on)
  intro used
  have bad := outZeros _ _ used (env x true) (by simp [env,x,inputOn,ha,hb])
  rw [yes] at bad
  contradiction
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.cold_raw_hits
