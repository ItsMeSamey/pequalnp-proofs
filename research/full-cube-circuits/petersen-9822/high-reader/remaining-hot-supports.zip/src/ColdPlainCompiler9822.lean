import TaggedCutWiring9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardTags
open PEqualNP.CircuitLowerBounds FreeAndNet FreeAndNet.CircuitCompiler

def PlainGate (t : Net (Fin 11)) :=
  ∃ a b : List (Fin 11), ∃ next, t=.gate a b next ∧ 0∉a ∧ 0∉b

private theorem readW (w : List (List (Fin 11))) (j : Nat) (lt : j<w.length) :
    (w.map some).getD j none = some w[j] := by simp [List.getD_eq_getElem?_getD,lt]

private theorem plainProduct (w : List (List (Fin 11))) (ins : List Nat)
    (legal : ∀ j∈ins,j<w.length) (ok : ∀ j (hj : j∈ins), (0 : Fin 11) ∉w[j]'(legal j hj)) :
    ∃ p, substProduct (fun j => (w.map some).getD j none) ins = some p ∧ 0∉p := by
  induction ins with
  | nil => exact ⟨[],rfl,by simp⟩
  | cons i is ih =>
    have lt := legal i List.mem_cons_self
    obtain ⟨p,hp,miss⟩ := ih (fun j hj => legal j (by simp [hj])) (fun j hj => ok j (by simp [hj]))
    exact ⟨w[i]++p,by simp only [substProduct,readW w i lt,hp],
      by simp [ok i List.mem_cons_self,miss]⟩

theorem prefix_plain (pre tail : List Gate) (o : Nat)
    (existsOr : ∃ g∈pre, orFlag g=true)
    (noZero : ∀ g∈pre, ∀ j∈g.inputs, j≠0) (w : List (List (Fin 11)))
    (nonempty : 0<w.length) (clean : ∀ j (h : j<w.length), j≠0 → (0 : Fin 11)∉w[j])
    (valid : TaggedWiring w.length (pre++tail)) :
    PlainGate (CircuitCompiler.run o (pre++tail) (w.map some)) := by
  induction pre generalizing w with
  | nil => simpa using existsOr
  | cons g gs ih =>
    obtain ⟨legal,binary,suffix⟩ := valid
    have pos (j : Nat) (hj : j∈g.inputs) := noZero g (by simp) j hj
    cases flag : orFlag g with
    | true =>
      obtain ⟨a,b,ins⟩ := binary flag
      have la := legal a (by simp [ins])
      have lb := legal b (by simp [ins])
      unfold PlainGate
      simp only [List.cons_append,CircuitCompiler.run,flag,ite_true,ins,List.getD_cons_zero,List.getD_cons_succ,readW w a la,readW w b lb,orStep]
      exact ⟨_,_,_,rfl,clean a la (pos a (by simp [ins])),clean b lb (pos b (by simp [ins]))⟩
    | false =>
      obtain ⟨p,read,off⟩ := plainProduct w g.inputs legal (fun j h => clean j _ (pos j h))
      have rest : ∃ q∈gs,orFlag q=true := by
        obtain ⟨q,hq,on⟩ := existsOr
        exact ⟨q,(List.mem_cons.mp hq).resolve_left (fun e => by subst q; rw [flag] at on; contradiction),on⟩
      have good : ∀ j (h : j<(w++[p]).length),j≠0 → (0 : Fin 11)∉(w++[p])[j] := by
        intro j bound nz
        by_cases h : j<w.length
        · rw [List.getElem_append_left h]
          exact clean _ _ nz
        · have eq : j=w.length := by simp at bound; omega
          subst j
          simpa using off
      have continued := ih rest (fun q hq => noZero q (by simp [hq])) (w++[p]) (by simp) good (by simpa using suffix)
      simpa only [List.cons_append,CircuitCompiler.run,flag,Bool.false_eq_true,ite_false,read,List.map_append,List.map_cons,List.map_nil] using continued
end PEqualNP.Outside.L_meta_9822.Clean.GuardTags
