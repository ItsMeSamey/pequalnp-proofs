import NonadjacentAndChild9822
import NonadjacentOrChild9822
import PairMaskedCut9822
import HighUniqueReader9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport Deletion
open PEqualNP.Outside.L_meta_9822.Clean
theorem public_nonadjacent_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s t : Fin 10) (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (Fin 10×Fin 10)))
    (guard : ∀ x : Input,innerValue pre g x=(x s || x t)) (p tail : List Gate)
    (whole : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length])
    (ord : p.length<pre.length) (w : Gate) (mw : w∈C.gates) (wo : w.op=.and)
    (wp : 10+p.length∈w.inputs) : False := by
  classical
  have ranges : 5≤s.val ∧ s.val≤8 := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  let z := 10+pre.length
  let read := ReaderDebit.reads z
  have cnt : post.countP read=1 :=
    high_unique_reader r cand (by omega) s ranges.1 ranges.2 (by simp [guard,SignedClamp.singleton]) red
  obtain ⟨u,um,uq⟩ := List.countP_pos_iff.mp (by omega : 0<post.countP read)
  obtain ⟨j,uj⟩ := List.mem_iff_getElem?.mp um
  have site (i : Nat) (q : Gate) (src : post[i]?=some q) : C.gates[pre.length+1+i]?=some q := by
    rw [r.split,List.getElem?_append_right (by omega)]
    simpa [show pre.length+1+i-pre.length=i+1 by omega] using src
  let k := pre.length+1+j
  have uk : C.gates[k]?=some u := site j u uj
  have up : z∈u.inputs := of_decide_eq_true uq
  have mu : u∈C.gates := List.mem_iff_getElem?.mpr ⟨_,uk⟩
  have pos := r.pos u (List.mem_append_right _ um)
  rcases pos with ua|uo
  · exact nonadjacent_ports r cand red seven s t shape guard p tail whole unary ord w u mw mu wp up wo ua
  have only (i : Nat) (q : Gate) (qi : post[i]?=some q) (qp : z∈q.inputs) : pre.length+1+i=k := by
    have qm := List.mem_iff_getElem?.mpr ⟨i,qi⟩
    have qe : q=u := by
      by_contra diff
      let A : Finset Gate := {q,u}
      have card : A.card=2 := by simp [A,diff]
      have sub : A⊆(post.filter read).toFinset := by
        intro a aa
        simp only [A,Finset.mem_insert,Finset.mem_singleton] at aa
        rcases aa with rfl|rfl
        · exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨qm,decide_eq_true qp⟩)
        · exact List.mem_toFinset.mpr (List.mem_filter.mpr ⟨um,uq⟩)
      have h := (Finset.card_le_card sub).trans (List.toFinset_card_le _)
      rw [card,←List.countP_eq_length_filter] at h
      omega
    exact gate_site_identity red u (qe ▸ site i q qi) uk
  have maskedReader (i : Nat) (q : Gate) (qi : post[i]?=some q) (qr : 10+k∈q.inputs) :
      q.op=.and ∧ ∃ a∈q.inputs,a∈({s.val,t.val,10+p.length} : Finset Nat) := by
    have qm := List.mem_iff_getElem?.mpr ⟨i,qi⟩
    have full := site i q qi
    have cm := List.mem_iff_getElem?.mpr ⟨_,full⟩
    rcases r.pos q (List.mem_append_right _ qm) with qa|qo
    · have hd := and_child_mask r cand red seven s t shape guard p tail whole unary ord k u uk uo up
        w mw wo wp q cm qa qr
      refine ⟨qa,?_⟩
      rcases hd with h|h|h
      · exact ⟨_,h,by simp⟩
      · exact ⟨_,h,by simp⟩
      · exact ⟨_,h,by simp⟩
    · exact (no_or_child r cand red (by omega) s t shape p tail whole unary ord k _ u q uk full uo qo up qr).elim
  let x : Input := fun _ => false
  have cold : vl C.gates x C.output=false := cand.2.2 x
  have zhot : vl C.gates x z=true := by
    have v := (pair_physical_values r red.clean s t p tail whole unary x).2
    simpa [x,z] using v
  have rhot : vl C.gates x (10+k)=true := by
    rw [vl_gate _ red.clean _ k u uk,uo]
    simp only [GateOp.eval,List.any_map,Function.comp_def,id_eq,List.any_eq_true]
    exact ⟨z,up,zhot⟩
  have nz : C.output≠z := by rintro e;rw [e,zhot] at cold; contradiction
  have nr : C.output≠10+k := by rintro e;rw [e,rhot] at cold; contradiction
  exact masked_cut_impossible r cand red s t p tail whole unary ord k nz nr only maskedReader
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.public_nonadjacent_impossible
