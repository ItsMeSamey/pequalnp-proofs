import CleanMin9822
import TwoHighGuard9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open FreeAndNet Research.OddOr PEqualNP.CircuitLowerBounds SignedClamp OuterNet NonrawSupport
open PEqualNP.Outside.L_meta_9822.Clean
theorem visible {C pre post g} (r : Roster C pre post g) (a : Nat) (bound : a<10+pre.length) (x : Input) :
    vl C.gates x a=(wiresFrom pre (List.ofFn x)).getD a false := by
  unfold vl
  rw [r.split,wiresFrom_append,getD_wiresFrom _ _ _ (by rw [length_wiresFrom,List.length_ofFn];exact bound)]
theorem observer_pair {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t : Fin 10) (st : s≠t) (sl : 5≤s.val) (su : s.val≤8) (tl : 5≤t.val) (tu : t.val≤8)
    (hs : innerValue pre g (SignedClamp.singleton s)=true) (ht : innerValue pre g (SignedClamp.singleton t)=true)
    (a : Nat) (ha : a<10+pre.length)
    (sa : vl C.gates (SignedClamp.singleton s) a=true) (ta : vl C.gates (SignedClamp.singleton t) a=true) :
    ∀ v : Input, vl C.gates v a=(v s || v t) := by
  let B := zeroNet pre post a
  have same : SameTrace (zeroNet pre post C.output) B := trace_specialize
    (compile_trace (C.output+1) (a+1) (cutCircuit pre post a).gates _) _
  have sc := (trace_count same (SignedClamp.singleton s)).symm.trans (high_exactly_one r cand seven s sl su hs)
  have tc := (trace_count same (SignedClamp.singleton t)).symm.trans (high_exactly_one r cand seven t tl tu ht)
  have read (v : Input) : B.eval v=vl C.gates v a := by
    rw [visible r a ha]
    change (specialize (close false) (model pre post a)).eval v = _
    rw [eval_specialize,close_eval]
    change (CircuitCompiler.compile 11 (cutCircuit pre post a)).eval _ = _
    have legal : PEqualNP.MetaComplexity.Monotone2 (cutCircuit pre post a) := model_legal r cand
    rw [CircuitCompiler.compile_eval _ _ legal,cut_eval]
    unfold outerValue
    let w := wiresFrom pre (List.ofFn v)
    have room : a<w.length := by simpa [w,length_wiresFrom] using ha
    rw [getD_wiresFrom _ _ _ (by change a<(w++[false]).length;simp;omega),
      getD_snoc_ne _ _ _ _ (Nat.ne_of_lt room)]
  have mono {x y : Input} (le : ∀ i,x i=true → y i=true) :
      vl C.gates x a=true → vl C.gates y a=true := by
    rw [visible r a ha,visible r a ha]
    exact (phase_mono pre (fun q hq => r.pos q (List.mem_append_left _ hq)) (packed_inputs_mono le)).2 a
  have cold : vl C.gates (fun _ : Fin 10 => false) a=false := by
    cases eq : vl C.gates (fun _ : Fin 10 => false) a with
    | false => rfl
    | true =>
      by_cases raw : a<10
      · rw [vl_input _ _ _ raw] at eq;contradiction
      · let k := a-10
        have hk : a=10+k := by dsimp [k];omega
        have len : k<C.gates.length := by rw [r.split];simp;omega
        exact (red.noConstant k len true (fun x => hk ▸ mono (by simp) eq)).elim
  intro v
  have rise (i : Fin 10) (on : v i=true) (h : vl C.gates (SignedClamp.singleton i) a=true) :
      vl C.gates v a=true := by
    apply mono _ h
    intro j sj
    have eq : j=i := by simpa [SignedClamp.singleton] using sj
    simpa [eq] using on
  cases vs : v s <;> cases vt : v t
  · change vl C.gates v a=false
    cases eq : vl C.gates v a with
    | false => rfl
    | true =>
      have pairs (i : Fin 10) : PairImpl (SignedClamp.singleton s i) (SignedClamp.singleton t i) (v i) false := by
        by_cases is : i=s
        · subst i;simp [PairImpl,SignedClamp.singleton,st,vs]
        · by_cases it : i=t
          · subst i;simp [PairImpl,SignedClamp.singleton,is,vt]
          · simp [PairImpl,SignedClamp.singleton,is,it]
      have bound := disjoint_three_cost B (SignedClamp.singleton s) (SignedClamp.singleton t) v (fun _ => false)
        pairs ((read _).trans sa) ((read _).trans ta) ((read _).trans eq) ((read _).trans cold)
      omega
  · exact rise t vt ta
  · exact rise s vs sa
  · exact rise s vs sa
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.observer_pair
