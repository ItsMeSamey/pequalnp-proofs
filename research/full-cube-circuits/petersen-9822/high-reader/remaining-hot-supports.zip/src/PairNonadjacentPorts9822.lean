import PairSignalRelations9822
import PairDistinctOwners9822
import PairMarkedReaders9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem nonadjacent_ports {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s t : Fin 10) (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (Fin 10 × Fin 10)))
    (guard : ∀ v : Input,innerValue pre g v=(v s || v t)) (p tail : List Gate)
    (whole : C.gates=p++literalGate s t::tail) (invpin : g.inputs=[10+p.length])
    (order : p.length<pre.length) (w z : Gate) (mw : w∈C.gates) (mz : z∈C.gates)
    (positive : 10+p.length∈w.inputs) (negative : 10+pre.length∈z.inputs)
    (wa : w.op=.and) (za : z.op=.and) : False := by
  classical
  have ranges : s≠t ∧ 5≤s.val ∧ s.val≤8 ∧ 5≤t.val ∧ t.val≤8 := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  obtain ⟨ds,sl,su,tl,tu⟩ := ranges
  obtain ⟨a,ma,b,mb,ab,aa,ba,sa,tb⟩ :=
    two_external_ands r cand red (by omega) s t ds sl su tl tu guard p tail whole invpin
  obtain ⟨kw,hw⟩ := List.mem_iff_getElem?.mp mw
  obtain ⟨kz,hz⟩ := List.mem_iff_getElem?.mp mz
  have W := (no_pair_and_overlap r red s t p tail whole invpin order w kw hw wa).1 positive
  have Z := (no_pair_and_overlap r red s t p tail whole invpin order z kz hz za).2 negative
  have aw : a≠w := fun e => W.1 (e ▸ sa)
  have az : a≠z := fun e => Z.1 (e ▸ sa)
  have bw : b≠w := fun e => W.2.1 (e ▸ tb)
  have bz : b≠z := fun e => Z.2 (e ▸ tb)
  have wz : w≠z := fun e => W.2.2 (e.symm ▸ negative)
  let hit := fun q : Gate => decide (q.op=.and) && (q.inputs.any fun j =>
      decide (j=s.val ∨ j=t.val ∨ j=10+p.length ∨ j=10+pre.length))
  let selected : Finset Gate := {a,b,w,z}
  have count : selected.card=4 := by simp [selected,ab,aw,az,bw,bz,wz]
  have lower : selected⊆(C.gates.filter hit).toFinset := by
    intro q h
    simp only [selected,Finset.mem_insert,Finset.mem_singleton] at h
    rcases h with rfl|rfl|rfl|rfl
    · simp [hit,aa,ma,List.any_eq_true]; exact ⟨_,sa,Or.inl rfl⟩
    · simp [hit,ba,mb,List.any_eq_true]; exact ⟨_,tb,Or.inr (Or.inl rfl)⟩
    · simp [hit,wa,mw,List.any_eq_true]; exact ⟨_,positive,Or.inr (Or.inr (Or.inl rfl))⟩
    · simp [hit,za,mz,List.any_eq_true]; exact ⟨_,negative,Or.inr (Or.inr (Or.inr rfl))⟩
  have lim := Deletion.four_signed_readers r cand red.clean (by omega) s t shape p tail whole invpin order
  have h := (Finset.card_le_card lower).trans (List.toFinset_card_le _)
  rw [←List.countP_eq_length_filter,count] at h
  change C.gates.countP hit≤3 at lim
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.nonadjacent_ports
