import OddPeel

/- BEGIN OR9822Rank.lean -/

namespace Research.OddOr
open FreeAndNet

/-- Number of physical OR outputs true on a single assignment. -/
def hotCount {α : Type} (v : α → Bool) : Net α → Nat
  | .out _ => 0
  | .gate a b t =>
    let h := a.all v || b.all v
    hotCount (fun z => z.elim h v) t + h.toNat

def rawMap {α β : Type} (f : α → β) : Net α → Net β
  | .out p => .out (p.map (List.map f))
  | .gate a b t => .gate (a.map f) (b.map f) (rawMap (Option.map f) t)

theorem rawMap_cost {α β} (f : α → β) (t : Net α) : (rawMap f t).cost = t.cost := by
  induction t generalizing β with
  | out => rfl
  | gate a b t ih => simp [rawMap,Net.cost,ih]

theorem rawMap_eval {α β} (f : α → β) (t : Net α) (v : β → Bool) :
    (rawMap f t).eval v = t.eval (v ∘ f) := by
  induction t generalizing β with
  | out p => cases p <;> simp [rawMap,Net.eval,pval,List.all_map]
  | gate a b t ih =>
    simp only [rawMap, Net.eval, ih,List.all_map]
    congr 1
    funext z
    cases z <;> rfl

theorem rawMap_hot {α β} (f : α → β) (t : Net α) (v : β → Bool) :
    hotCount v (rawMap f t) = hotCount (v ∘ f) t := by
  induction t generalizing β with
  | out => rfl
  | gate a b t ih =>
    simp only [rawMap, hotCount, ih,List.all_map]
    apply congrArg (fun n => n + _)
    congr 1
    funext z
    cases z <;> rfl

/-- Append a disjunct to the output while preserving all old shared gates. -/
def addOutput {α : Type} (p : List α) : Net α → Net α
  | .out none => .out (some p)
  | .out (some q) => .gate q p (.out (some [none]))
  | .gate a b t => .gate a b (addOutput (p.map some) t)

theorem addOutput_cost {α} (p : List α) (t : Net α) :
    (addOutput p t).cost ≤ t.cost + 1 := by
  induction t with
  | out q => cases q <;> simp [addOutput, Net.cost]
  | gate a b t ih =>
    have h := ih (p.map some)
    simp only [addOutput, Net.cost]
    omega

theorem addOutput_eval {α} (p : List α) (t : Net α) (v : α → Bool) :
    (addOutput p t).eval v = (t.eval v || p.all v) := by
  induction t with
  | out q => cases q <;> simp [addOutput,Net.eval,pval]
  | gate a b t ih => simp [addOutput,Net.eval,ih,List.all_map,Function.comp_def]

theorem addOutput_cold {α} (p : List α) (t : Net α) (v : α → Bool)
    (ht : t.eval v = false) (hp : p.all v = false) :
    hotCount v (addOutput p t) = hotCount v t := by
  induction t with
  | out q => cases q <;> simp_all [hotCount,addOutput,Net.eval,pval]
  | gate a b t ih =>
    simp only [Net.eval] at ht
    simp only [hotCount,addOutput]
    rw [ih (p.map some) _ ht (by simpa [List.all_map,Function.comp_def] using hp)]

def postpone {α} (i : α) (ep : List α) (t : Net (Option α)) :=
  addOutput ep (rawMap (fun z => z.getD i) t)

theorem postpone_cost {α} (i : α) (ep : List α) (t : Net (Option α)) :
    (postpone i ep t).cost ≤ (Net.gate [i] ep t).cost := by
  simpa [postpone,Net.cost,rawMap_cost] using addOutput_cost ep (rawMap (fun z : Option α => z.getD i) t)

theorem postpone_eval {α} (i : α) (ep : List α) (t : Net (Option α)) (v : α → Bool)
    (on : ep.all v = true → (Net.gate [i] ep t).eval v = true) :
    (postpone i ep t).eval v = (Net.gate [i] ep t).eval v := by
  rw [postpone,addOutput_eval,rawMap_eval]
  cases he : ep.all v with
  | true => simp [on he]
  | false =>
    simp only [Bool.or_false,Net.eval,List.all_cons,List.all_nil,Bool.and_true,he]
    congr 1
    funext z
    cases z <;> rfl

/-- On each singleton the new trace loses precisely the removed gate's bit. -/
theorem postpone_hot {α} (i : α) (ep : List α) (t : Net (Option α)) (v : α → Bool)
    (he : ep.all v = false) (cold : (Net.gate [i] ep t).eval v = false) :
    hotCount v (postpone i ep t) + (v i).toNat = hotCount v (.gate [i] ep t) := by
  have env : (v ∘ fun z : Option α => z.getD i) = (fun z : Option α => z.elim (v i) v) := by
    funext z
    cases z <;> rfl
  simp only [Net.eval,List.all_cons,List.all_nil,Bool.and_true,he,Bool.or_false] at cold
  rw [postpone,addOutput_cold _ _ _ (by rw [rawMap_eval,env]; exact cold) he,rawMap_hot,env]
  simp [hotCount,he]

/-- The two products can contain arbitrary earlier endpoint-only atoms. The
survivor check identifies the bit computed by their OR on reachable environments. -/
theorem move_semantic_gate {α} (i : α) (ep a b : List α) (t : Net (Option α))
    (v : α → Bool) (survivor : (a.all v || b.all v) = (v i || ep.all v))
    (on : ep.all v = true → (Net.gate a b t).eval v = true) :
    (postpone i ep t).eval v = (Net.gate a b t).eval v := by
  have eq : (Net.gate [i] ep t).eval v = (Net.gate a b t).eval v := by
    simp [Net.eval,survivor]
  exact (postpone_eval i ep t v (fun h => eq.trans (on h))).trans eq

theorem move_semantic_hot {α} (i : α) (ep a b : List α) (t : Net (Option α))
    (v : α → Bool) (he : ep.all v = false) (survivor : (a.all v || b.all v) = v i)
    (cold : (Net.gate a b t).eval v = false) :
    hotCount v (postpone i ep t) + (v i).toNat = hotCount v (.gate a b t) := by
  have eq : (Net.gate [i] ep t).eval v = (Net.gate a b t).eval v := by
    simp [Net.eval,survivor,he]
  rw [postpone_hot i ep t v he (eq.trans cold)]
  simp [hotCount,survivor,he]

end Research.OddOr
/- END OR9822Rank.lean -/

/- BEGIN OR9822Short.lean -/

namespace Research.OddOr
open FreeAndNet

/-- A pivot mediated exclusively by the OR bit must be read by a further OR
when the residual accepts an assignment on which that bit is zero. -/
theorem downstream_hit {α : Type} (t : Net (Option α)) (i : α)
    (a b : List α) (x y z : α → Bool)
    (noraw : hits (some i) t = 0 ∧ ¬outUses (some i) t)
    (agree : ∀ j, j ≠ i → x j = y j)
    (pivot : (Net.gate a b t).eval x ≠ (Net.gate a b t).eval y)
    (zero : (a.all z || b.all z) = false)
    (live : (Net.gate a b t).eval z = true) : 0 < hits none t := by
  classical
  have noOut : ¬ outUses none t := by
    intro bad
    have eq := outZeros t none bad (fun w : Option α => w.elim (a.all z || b.all z) z) zero
    change (Net.gate a b t).eval z = false at eq
    simp_all
  by_contra! nh
  apply pivot
  simp only [Net.eval]
  apply eval_congr_used
  intro w used
  cases w with
  | none =>
    rcases used with h | h
    · omega
    · exact (noOut h).elim
  | some j =>
    apply agree
    rintro rfl
    rcases used with h | h
    · have := noraw.1
      omega
    · exact noraw.2 h

theorem pin_both_saves_two {α : Type} [DecidableEq α] (t : Net (Option α))
    (i : α) (a b : List α) (ha : i ∈ a) (hb : i ∈ b)
    (more : 0 < hits none t) :
    (pin i (.gate a b t)).cost + 2 ≤ (Net.gate a b t).cost := by
  have dead : kill i i = none := by simp [kill]
  have left := subst_none dead a ha
  have right := subst_none dead b hb
  simp only [pin,specialize,left,right,Net.cost]
  have debit := specialize_saves (none : Option α)
    (fun z : Option α => z.elim (none : Product α) (kill i)) rfl t
  omega

end Research.OddOr
/- END OR9822Short.lean -/

/- BEGIN OR9822Terms.lean -/

namespace Research.OddOr.Theta
inductive Ep where | unit | left | right | both | either
deriving DecidableEq

instance : Fintype Ep where
  elems := {.unit,.left,.right,.both,.either}
  complete := by intro e; cases e <;> decide

def Ep.eval (l r : Bool) : Ep → Bool
  | .unit => true
  | .left => l
  | .right => r
  | .both => l && r
  | .either => l || r

def Ep.inf : Ep → Ep → Ep
  | .unit,b | b,.unit => b
  | .both,_ | _,.both => .both
  | .either,b | b,.either => b
  | .left,.left => .left
  | .right,.right => .right
  | _,_ => .both

def Ep.sup : Ep → Ep → Ep
  | .unit,_ | _,.unit => .unit
  | .either,_ | _,.either => .either
  | .both,b | b,.both => b
  | .left,.left => .left
  | .right,.right => .right
  | _,_ => .either

theorem ep_inf : ∀ (x y : Ep) (l r : Bool), (x.inf y).eval l r = (x.eval l r && y.eval l r) := by
  decide
theorem ep_sup : ∀ (x y : Ep) (l r : Bool), (x.sup y).eval l r = (x.eval l r || y.eval l r) := by
  decide

structure Row (κ : Type) where
  l : Bool
  r : Bool
  raw : κ → Bool

inductive Atom (κ : Type) where
  | raw (i : κ)
  | ep (v : Ep)

def val {κ} (x : Row κ) : Atom κ → Bool
  | .raw i => x.raw i
  | .ep e => e.eval x.l x.r

structure Term (κ : Type) where
  support : Finset κ
  ep : Ep

def product {κ α : Type} [DecidableEq κ] (atom : α → Atom κ) : List α → Term κ
  | [] => ⟨∅,.unit⟩
  | a :: l =>
    let q := product atom l
    match atom a with
    | .raw i => ⟨insert i q.support,q.ep⟩
    | .ep e => ⟨q.support,e.inf q.ep⟩

def termVal {κ : Type} (x : Row κ) (t : Term κ) : Bool :=
  decide (∀ i ∈ t.support, x.raw i = true) && t.ep.eval x.l x.r

theorem product_val {κ α : Type} [DecidableEq κ] (atom : α → Atom κ) (xs : List α) (x : Row κ) :
    xs.all (val x ∘ atom) = termVal x (product atom xs) := by
  induction xs with
  | nil => simp [product,termVal,Ep.eval]
  | cons a xs ih =>
    rw [List.all_cons,ih]
    cases h : atom a with
    | raw i =>
      simp [Function.comp_apply,h,val,product,termVal,Bool.and_assoc]
    | ep e =>
      simp [Function.comp_apply,h,val,product,termVal,ep_inf,Bool.and_left_comm]

theorem product_mem {κ α : Type} [DecidableEq κ] (atom : α → Atom κ) (l : List α) (i : κ) :
    i ∈ (product atom l).support ↔ ∃ z ∈ l, atom z = .raw i := by
  induction l with
  | nil => simp [product]
  | cons a l ih =>
    cases h : atom a with
    | raw k => simp [product,h,ih,eq_comm]
    | ep e => simp [product,h,ih]

theorem empty_eval {κ : Type} (x : Row κ) (p : Term κ) (h : p.support = ∅) :
    termVal x p = p.ep.eval x.l x.r := by simp [termVal,h]

/-- The raw index is kept even when earlier endpoint-only gates are available. -/
structure State (κ α : Type) where
  atom : α → Atom κ
  read : κ → α
  raw_iff : ∀ z i, atom z = .raw i ↔ z = read i
  left : α
  right : α
  hleft : atom left = .ep .left
  hright : atom right = .ep .right

def State.push {κ α : Type} (s : State κ α) (v : Ep) : State κ (Option α) where
  atom := fun z => z.elim (.ep v) s.atom
  read := fun i => some (s.read i)
  raw_iff := by intro z i; cases z <;> simp [s.raw_iff]
  left := some s.left
  right := some s.right
  hleft := s.hleft
  hright := s.hright

theorem push_env {κ α : Type} [DecidableEq κ] (s : State κ α) (a b : List α)
    (ha : (product s.atom a).support = ∅) (hb : (product s.atom b).support = ∅)
    (x : Row κ) :
    (fun z : Option α => z.elim (a.all (val x ∘ s.atom) || b.all (val x ∘ s.atom)) (val x ∘ s.atom)) =
      val x ∘ (s.push ((product s.atom a).ep.sup (product s.atom b).ep)).atom := by
  funext z
  cases z with
  | some j => rfl
  | none =>
    simp only [Option.elim_none,Function.comp_apply,State.push,val]
    rw [product_val,product_val,empty_eval _ _ ha,empty_eval _ _ hb,ep_sup]

end Research.OddOr.Theta
/- END OR9822Terms.lean -/

