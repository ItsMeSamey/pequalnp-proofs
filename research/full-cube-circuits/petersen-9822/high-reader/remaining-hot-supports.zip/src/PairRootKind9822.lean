import AllPairObservers9822
import PairGuardReplace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem pair_root_is_or {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t : Fin 10) (st : s≠t) (sl : 5≤s.val) (su : s.val≤8) (tl : 5≤t.val) (tu : t.val≤8)
    (hs : innerValue pre g (SignedClamp.singleton s)=true) (ht : innerValue pre g (SignedClamp.singleton t)=true)
    (p : Nat) (old : Gate) (site : C.gates[p]?=some old) (pp : p<pre.length)
    (index : g.inputs.head?=some (10+p)) : old.op=.or := by
  have inp : ∀ x : Input,vl C.gates x (10+p)=innerValue pre g x := by
    intro x
    rw [visible r (10+p) (by omega) x]
    cases e : g.inputs with
    | nil => simp [e] at index
    | cons a more =>
      have eq : a=10+p := by simpa [e] using index
      simp [innerValue,e,eq]
  have pos : PositiveOp old := by
    have sp := site
    rw [r.split,List.getElem?_append_left pp] at sp
    exact r.pos old (List.mem_append_left _ (List.mem_iff_getElem?.mpr ⟨_,sp⟩))
  rcases pos with h|h
  · rcases red.clean p old site with ⟨bad,_⟩|⟨_,a,b,ha,_,ins⟩
    · simp_all
    have on (i : Fin 10) (hot : innerValue pre g (SignedClamp.singleton i)=true) :
        vl C.gates (SignedClamp.singleton i) a=true := by
      have v := (inp (SignedClamp.singleton i)).trans hot
      rw [vl_gate _ red.clean _ p old site,h,ins] at v
      exact (by simpa [GateOp.eval] using v : vl C.gates (SignedClamp.singleton i) a=true ∧ _).1
    have eq := observer_pair r cand red seven s t st sl su tl tu hs ht a (by omega) (on s hs) (on t ht)
    have guard := high_pair_is_or r cand seven s t st sl su tl tu hs ht
    exact (red.noAlias p (List.getElem?_eq_some_iff.mp site).1 a ha
      (fun x => (inp x).trans ((guard x).trans (eq x).symm))).elim
  · exact h
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.pair_root_is_or
