import PrivateClampLedger9822
import P4PhysicalFace9822
import Pair67Protected9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp
open PEqualNP.Outside.L_meta_9822.Clean
open FreeAndNet Research.OddOr
theorem private_residual_impossible (s t : V)
    (casesH : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V)))
    (gs : List Gate) (o w : Nat) (clean : CleanL 10 gs)
    (pos : ∀ g∈gs,PositiveOp g) (cap : gs.countP (ofOp .or)≤6)
    (rep : ∀ x,vl gs x o=edge (masked {s,t} x))
    (cold : vl gs (fun _ : V => false) w=false)
    (warm : ∀ i : V,edge (pair s i)=true → i≠s → i≠t → vl gs (SignedClamp.singleton i) w=true) : False := by
  let net := fun j => CircuitCompiler.compile 10 ⟨gs,j⟩
  have mono (j) : Monotone2 ⟨gs,j⟩ := fun g hg =>
    ⟨pos g hg,(clean_nok 10 gs clean g hg).1.2⟩
  have ev (j) (v : Input) : (net j).eval v = vl gs v j :=
    CircuitCompiler.compile_eval 10 ⟨gs,j⟩ (mono j) v
  have sync : SameSites (net o) (net w) := CircuitCompiler.run_same_sites _ _ _ _
  have bound : (net o).cost ≤ 6 := by
    have pay := CircuitCompiler.compile_cost 10 (⟨gs,o⟩ : Circuit)
    have flag : CircuitCompiler.orFlag=ofOp .or := by
      funext q;cases q with | mk op ins => cases op <;> simp [CircuitCompiler.orFlag,ofOp]
    change (net o).cost ≤ (gs.filter CircuitCompiler.orFlag).length at pay
    rw [←List.countP_eq_length_filter,flag] at pay
    omega
  have hrep (S : Finset V) : sees (net o) S = PairFace.neg s t S := by
    unfold sees
    rw [ev,rep]
    unfold PairFace.neg
    congr 1
    funext j
    by_cases a : j=s <;> by_cases b : j=t <;> simp [masked,a,b]
  have c : sees (net w) ∅ = false := by simpa [sees,ev] using cold
  have heat (i : V) (a : edge (pair s i)=true) (b : i≠s) (d : i≠t) :
      sees (net w) {i} = true := by
    unfold sees
    rw [ev]
    have eq : (fun j : V => decide (j ∈ ({i} : Finset V))) = SignedClamp.singleton i := by
      funext j
      by_cases e : j = i <;> simp [SignedClamp.singleton,e]
    rw [eq]
    exact warm i a b d
  simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at casesH
  rcases casesH with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩
  · exact PairFace.protect56 _ _ sync bound hrep c (heat 0 (by decide) (by decide) (by decide))
      (heat 8 (by decide) (by decide) (by decide))
  · exact PairFace.protect67 _ _ sync bound hrep c (heat 1 (by decide) (by decide) (by decide))
      (heat 8 (by decide) (by decide) (by decide))
  · exact PairFace.protect78 _ _ sync bound hrep c (heat 2 (by decide) (by decide) (by decide))
      (heat 9 (by decide) (by decide) (by decide))

end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
