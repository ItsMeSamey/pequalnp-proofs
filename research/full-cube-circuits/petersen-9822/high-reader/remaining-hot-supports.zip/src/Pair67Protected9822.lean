import Pair67HotPrune9822
import Pair67PositiveFloor9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.PairFace
open FreeAndNet Research.OddOr LowPositive
theorem protect67 (t w : Net V) (sync : SameSites t w) (cap : t.cost ≤ 6)
    (rep : ∀ S, sees t S = neg 6 7 S)
    (cold : sees w ∅ = false) (left : sees w {1} = true) (right : sees w {8} = true) : False := by
  let p : V → Bool := fun i => decide (i = 1)
  let q : V → Bool := fun i => decide (i = 8)
  have h : orHot p w = true := by
    by_contra! hn
    have z := noHotMeet w p q (fun _ => false) (by simpa using hn)
      (by decide +kernel) (by simpa [sees,p] using left) (by simpa [sees,q] using right)
    exact Bool.noConfusion (cold.symm.trans (by simpa [sees] using z))
  have ht : orHot p t = true := (sync.hot_eq p).trans h
  let sub : V → Product V := fun i => if i = 1 then some [] else some [i]
  let net := specialize sub (hotPrune p t)
  have low := positive_isolated_floor net (by
    intro S
    change (specialize sub (hotPrune p t)).eval _ = _
    rw [eval_specialize]
    have ee : (fun i => pval (fun j => decide (j ∈ S)) (sub i)) =
        (fun j => decide (j ∈ insert (1 : V) S)) := by
      funext i
      by_cases e : i=1 <;> simp [sub,e,pval]
    rw [ee,hotPrune_correct]
    · exact rep _
    · intro i hi
      have e : i=1 := by simpa [p] using hi
      simp [e])
  have debit := hotPrune_cost t p
  have bound : net.cost ≤ (hotPrune p t).cost := specialize_cost _ _
  simp only [ht,ite_true] at debit
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.PairFace
