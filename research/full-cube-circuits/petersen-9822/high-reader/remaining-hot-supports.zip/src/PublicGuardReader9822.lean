import PairMaskedCut9822
import HotPhysicalOwners9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem public_guard_reader_and {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (guard : ∀ x : Input,innerValue pre g x=(x s || x t))
    (p tail : List Gate) (whole : C.gates=p++literalGate s t::tail) (w : Gate)
    (mem : w∈C.gates) (ord : PositiveOp w) (read : 10+p.length∈w.inputs) : w.op=.and := by
  rcases ord with a|o
  · exact a
  obtain ⟨k,wk⟩ := List.mem_iff_getElem?.mp mem
  have late := (red.clean k w wk).lt _ read
  have wm : w∈tail := by
    rw [whole,List.getElem?_append_right (by omega)] at wk
    obtain ⟨n,hn⟩ : ∃ n,k-p.length=n+1 := ⟨k-p.length-1,by omega⟩
    rw [hn] at wk
    exact List.mem_iff_getElem?.mpr ⟨n,wk⟩
  have zero := (only_guard_or r cand red seven s t sl su guard p tail whole).2
  exact ((List.countP_eq_zero.mp zero w wm) (by simp [readsOr,FreeAndNet.CircuitCompiler.orFlag,o,read])).elim
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.public_guard_reader_and
