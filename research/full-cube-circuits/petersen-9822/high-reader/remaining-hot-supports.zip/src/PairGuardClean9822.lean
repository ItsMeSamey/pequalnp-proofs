import PairGuardCandidate9822
import PairRootKind9822
import RetimingMinimum9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem clean_literal (p tail : List Gate) (old : Gate) (s t : Fin 10)
    (cl : CleanL 10 (p++old::tail)) : CleanL 10 (p++literalGate s t::tail) := by
  intro i q atq
  by_cases before : i<p.length
  · apply cl i q
    rwa [List.getElem?_append_left before] at atq ⊢
  by_cases here : i=p.length
  · subst i
    have eq : literalGate s t=q := by simpa using atq
    subst q
    exact Or.inr ⟨Or.inr rfl,_,_,by omega,by omega,rfl⟩
  · apply cl i q
    rw [List.getElem?_append_right (by omega)] at atq ⊢
    obtain ⟨n,hn⟩ : ∃ n,i-p.length=n+1 := ⟨i-p.length-1,by omega⟩
    simpa only [hn,List.getElem?_cons_succ] using atq

theorem normalized_hot_pair {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t : Fin 10) (st : s≠t) (sl : 5≤s.val) (su : s.val≤8) (tl : 5≤t.val) (tu : t.val≤8)
    (hs : innerValue pre g (SignedClamp.singleton s)=true) (ht : innerValue pre g (SignedClamp.singleton t)=true) :
    ∃ (D : Circuit) (p q : List Gate),
      Roster D (p++literalGate s t::q) post g ∧ Candidate D ∧ Reduced 10 D.gates D.output ∧
      D.gates.countP countsAnd=C.gates.countP countsAnd ∧ g.inputs=[10+p.length] ∧
      (∀ x : Input,innerValue (p++literalGate s t::q) g x=(x s || x t)) ∧
      (∀ w∈C.gates,w.op=.and → w∈D.gates) ∧
      (∀ w∈C.gates,10+p.length∈w.inputs → w∈D.gates) := by
  have guard := high_pair_is_or r cand seven s t st sl su tl tu hs ht
  obtain ⟨D,p,q,old,split,rd,idx,dc,size,debit⟩ := literal_pair_candidate r cand s t st guard
  have root : C.gates[p.length]?=some old := by
    rw [r.split,split,List.append_assoc];simp
  have pp : p.length<pre.length := by rw [split];simp
  have kind := pair_root_is_or r cand red seven s t st sl su tl tu hs ht p.length old root pp idx
  have same : D.gates.countP countsAnd=C.gates.countP countsAnd := by simpa [countsAnd,kind] using debit
  have clean : CleanL 10 D.gates := by
    have b := red.clean
    rw [r.split,split,List.append_assoc] at b
    rw [rd.split,List.append_assoc]
    exact clean_literal p _ old s t b
  have vals (x : Input) : vl D.gates x D.output=vl C.gates x C.output := (dc.2.2 x).trans (cand.2.2 x).symm
  have varies : ∃ x y : Input,vl C.gates x C.output≠vl C.gates y C.output := by
    refine ⟨fun _ => false,fun _ => true,?_⟩
    intro e; exact Bool.noConfusion ((cand.2.2 (fun _ => false)).symm.trans (e.trans (cand.2.2 (fun _ => true))))
  have dr := (red.retimed clean (Nat.le_of_eq size) vals varies).1
  have site : C.gates[pre.length]?=some g := by simp [r.split]
  have inp : g.inputs=[10+p.length] := by
    rcases red.clean pre.length g site with ⟨_,a,_,ha⟩|⟨hop,_⟩
    · rw [ha] at idx ⊢
      simpa using idx
    · rcases hop with h|h <;> simp_all [r.inv]
  refine ⟨D,p,q,rd,dc,dr,same,inp,?_,?_,?_⟩
  · intro x
    rw [show innerValue (p++literalGate s t::q) g x=(wiresFrom (p++literalGate s t::q) (List.ofFn x)).getD (10+p.length) false by
      simp [innerValue,inp],wiresFrom_append]
    let w := wiresFrom p (List.ofFn x)
    have len : w.length=10+p.length := by simp [w,length_wiresFrom]
    change (wiresFrom q (w++[_])).getD (10+p.length) false = _
    rw [←len,getD_wiresFrom _ _ _ (by simp),getD_snoc_eq]
    have raw (i : Fin 10) : w.getD i.val false=x i := by
      dsimp [w];rw [getD_wiresFrom _ _ _ (by simp),getD_ofFn 10 _ false i]
    change (w.getD s.val false || (w.getD t.val false || false)) = _
    rw [raw,raw,Bool.or_false]
  · intro w mem wo
    rw [r.split,split] at mem
    rw [rd.split]
    have ne : w≠old := by rintro rfl;simp_all
    simp only [List.mem_append,List.mem_cons,ne,false_or] at mem ⊢
    tauto
  · intro w mem read
    have ne : w≠old := by
      rintro rfl
      exact Nat.lt_irrefl _ ((red.clean p.length _ root).lt _ read)
    rw [r.split,split] at mem
    rw [rd.split]
    simp only [List.mem_append,List.mem_cons,ne,false_or] at mem ⊢
    tauto
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.normalized_hot_pair
