import PairRawSeparation9822
import HotPhysicalOwners9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem external_and_owner {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (minimal : Reduced 10 C.gates C.output) (seven : 7 ≤ C.gates.countP countsAnd)
    (s t : Fin 10) (st : s≠t) (lo : 5≤s.val) (hi : s.val≤8)
    (guard : ∀ v : Input, innerValue pre g v=(v s || v t))
    (p tail : List Gate) (physical : C.gates=p++literalGate s t::tail)
    (invpin : g.inputs=[10+p.length]) :
    ∃ q∈p++tail,q.op=.and ∧ s.val∈q.inputs := by
  obtain ⟨q,mem,read,other⟩ := pair_raw_separation cand s t st
  have notliteral : q≠literalGate s t := by
    rintro rfl
    exact other ⟨rfl,by simp [literalGate]⟩
  have ext : q∈p++tail := by
    rw [physical] at mem
    simpa [List.mem_append,notliteral] using mem
  have positive : PositiveOp q := by
    rw [r.split] at mem
    have neq : q≠g := by
      rintro rfl
      rw [invpin,List.mem_singleton] at read
      omega
    exact r.pos q (by simpa [List.mem_append,neq] using mem)
  have no := (only_guard_or r cand minimal seven s t lo hi guard p tail physical).1
  refine ⟨q,ext,?_,read⟩
  rcases positive with h|h
  · exact h
  · exact False.elim ((List.countP_eq_zero.mp no q ext) (by simp [readsOr,FreeAndNet.CircuitCompiler.orFlag,h,read]))
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.external_and_owner
