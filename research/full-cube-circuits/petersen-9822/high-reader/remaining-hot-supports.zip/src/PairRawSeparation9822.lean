import PairReaderMask9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
private theorem witnesses : ∀ (s t : Fin 10), s≠t → ∃ j : Fin 10,
    j≠s ∧ edge (pair t j)=false ∧ edge (addRaw (pair t j) s)=true := by decide +kernel

theorem pair_raw_separation {C : Circuit} (cand : Candidate C) (s t : Fin 10) (ne : s≠t) :
    ∃ q∈C.gates, s.val∈q.inputs ∧ ¬(q.op=.or ∧ t.val∈q.inputs) := by
  classical
  by_contra! mask
  obtain ⟨j,_,cold,hot⟩ := witnesses s t ne
  let x := pair t j
  let y := addRaw x s
  have away : ∀ k : Nat, k≠s.val → (List.ofFn x).getD k false=(List.ofFn y).getD k false := by
    intro k kd
    by_cases hk : k<10
    · let i : Fin 10 := ⟨k,hk⟩
      have neq : i≠s := fun eq => kd (congrArg Fin.val eq)
      change (List.ofFn x).getD i.val false = (List.ofFn y).getD i.val false
      rw [getD_ofFn 10 x false i,getD_ofFn 10 y false i]
      exact
        (show x i=y i by simp [y,addRaw,SignedClamp.singleton,neq])
    · rw [List.getD_eq_default _ _ (n:=k) (by simp;omega),
          List.getD_eq_default _ _ (n:=k) (by simp;omega)]
  have off : C.output≠s.val := by
    intro eq
    have h := cand.2.2 (SignedClamp.singleton s)
    change (wiresFrom C.gates (List.ofFn (SignedClamp.singleton s))).getD C.output false=edge (SignedClamp.singleton s) at h
    rw [eq,getD_wiresFrom _ _ _ (by simp),getD_ofFn 10 _ false s] at h
    have coldS : ∀ i : Fin 10, edge (SignedClamp.singleton i)=false := by decide +kernel
    simp [coldS,SignedClamp.singleton] at h
  have eq := masked_suffix C.gates (List.ofFn x) (List.ofFn y) s.val t.val mask
    (by simp) (by simp) (by simp)
    ((getD_ofFn 10 _ false t).trans (by simp [x,pair,SignedClamp.singleton]))
    ((getD_ofFn 10 _ false t).trans (by simp [y,x,addRaw,pair,SignedClamp.singleton])) away C.output off
  have p := (cand.2.2 x).symm.trans (eq.trans (cand.2.2 y))
  change edge (pair t j)=edge (addRaw (pair t j) s) at p
  rw [cold,hot] at p
  contradiction
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.pair_raw_separation
