import GuardEmitterRun9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity GuardTags
def start (m : Nat) : List Reg :=
  (List.range m).map (fun i => (false,Sum.inr i)) ++ [(true,top)]
theorem start_length (m : Nat) : (start m).length = m+1 := by simp [start]
theorem start_marks (m : Nat) : (start m).map Prod.fst = List.replicate m false ++ [true] := by
  simp [start,List.map_map,Function.comp_def]
theorem start_valid (m : Nat) : ValidRegs (m+1) (start m) := by
  intro r hr
  rcases List.mem_append.mp hr with old|last
  · obtain ⟨i,hi,rfl⟩ := List.mem_map.mp old
    change i<m+1
    have := List.mem_range.mp hi
    omega
  · have eq : r = (true,top) := by simpa using last
    rw [eq]; trivial
theorem start_eval (w : List Bool) (m : Nat) (len : w.length=m+1) :
    (start m).map (evalReg w m) = w := by
  apply List.ext_getElem (by simp [start_length,len])
  intro i hi hj
  by_cases e : i<m
  · simp [start,List.getElem_append_left,e,evalReg,meaning,recover,Stat.val,List.getD,hj]
  · have eq : i=m := by omega
    subst i
    simp [start,List.getElem_append_right,evalReg,meaning,recover,Stat.val,List.getD,hj]
end PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter.start_eval
