import PhysicalHotResidual9822
import AllHighPairsExcluded9822
import NineClampPrice9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr
open SignedClamp NonrawSupport OuterNet LowHotElimination PEqualNP.Outside.L_meta_9822.Clean

theorem exact_seven {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7 ≤ C.gates.countP countsAnd) :
    C.gates.countP countsAnd = 7 ∧ (C.gates.filter CircuitCompiler.orFlag).length = 9 := by
  have floor : 9 ≤ (model pre post C.output).cost := by
    by_cases h : ∃ i : Fin 10, i.val ≤ 8 ∧ innerValue pre g (SignedClamp.singleton i) = true
    · obtain ⟨i,hi,hot⟩ := h
      have lo : 5 ≤ i.val := by
        by_contra! low
        exact low_hot_impossible r seven i (by omega) hot cand
      exact (unique_exit r cand seven i lo hi hot).2.2.ge
    · have other (i : Fin 10) (ne : i ≠ 9) : innerValue pre g (SignedClamp.singleton i) = false := by
        have hi : i.val ≤ 8 := by
          have n : i.val ≠ 9 := fun e => ne (Fin.ext e)
          omega
        cases eq : innerValue pre g (SignedClamp.singleton i) <;> simp_all
      let t := model pre post C.output
      let u := retire (close true) t
      have ev (v : Input) : u.eval v = outerValue pre post C.output v true := by
        change (retire _ _).eval _ = _
        rw [retire_eval,close_eval,model_eval r cand]
      have cost := upper_nine_price r cand red seven other u ev
      have debit := retire_cost (close true) t
      change u.cost + _ ≤ t.cost at debit
      change 9 ≤ t.cost
      omega
  have lo := floor.trans (model_cost r)
  have eq := Nat.le_antisymm (or_cap r cand seven) lo
  refine ⟨?_,eq⟩
  have a := priceDisjoint pre
  have b := priceDisjoint post
  have cap : C.gates.length ≤ 17 := cand.2.1
  rw [r.split] at eq seven cap ⊢
  simp [countsAnd,CircuitCompiler.orFlag,r.inv] at a b eq seven cap ⊢
  omega

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.exact_seven
