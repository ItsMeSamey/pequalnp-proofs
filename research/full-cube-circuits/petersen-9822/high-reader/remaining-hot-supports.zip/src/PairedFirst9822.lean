import ColdObserver9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open SignedClamp NonrawSupport OuterNet FreeAndNet Research.OddOr
open Research.OddOr.Envelope

def plainArm (a : List (Fin 11)) : Finset (Fin 10) :=
  Finset.univ.filter (fun j => j.succ ∈ a)

theorem trace_hits_eq {α : Type} [DecidableEq α] {t u : Net α} (same : SameTrace t u)
    (i : α) : hits i t = hits i u := by
  induction same with
  | out => rfl
  | gate a b h ih => simp only [hits]; rw [ih (some i)]

private theorem arm_all (a : List (Fin 11)) (plain : (0 : Fin 11) ∉ a)
    (s : Finset (Fin 10)) (z : Bool) :
    a.all (env (inputOn s) z) = decide (plainArm a ⊆ s) := by
  apply Bool.eq_iff_iff.mpr
  simp only [List.all_eq_true,decide_eq_true_eq]
  constructor
  · intro h j hj
    have hj' : j.succ ∈ a := (Finset.mem_filter.mp hj).2
    simpa [env,inputOn] using h j.succ hj'
  · intro h j
    refine Fin.cases ?_ (fun i hi => ?_) j
    · intro bad; exact (plain bad).elim
    · have his := h (Finset.mem_filter.mpr ⟨Finset.mem_univ i,hi⟩)
      simpa [env,inputOn] using his

theorem paired_gate_eq (a b : List (Fin 11)) (t : Net (Option (Fin 11)))
    (ap : 0 ∉ a) (bp : 0 ∉ b)
    (lim : ∀ i : Fin 10, hits i.succ (.gate a b t) ≤ 1)
    (no : ∀ i : Fin 10, ¬outUses i.succ (.gate a b t))
    {x y : Finset (Fin 10)} (z : Bool)
    (rest : x \ (plainArm a ∪ plainArm b) = y \ (plainArm a ∪ plainArm b))
    (bit : firstBit (plainArm a) (plainArm b) x = firstBit (plainArm a) (plainArm b) y) :
    (Net.gate a b t).eval (env (inputOn x) z) = (Net.gate a b t).eval (env (inputOn y) z) := by
  rw [Net.eval,Net.eval]
  apply eval_congr_used
  intro j used
  cases j with
  | none => simpa [arm_all a ap,arm_all b bp,firstBit] using bit
  | some j =>
    revert used
    refine Fin.cases (fun _ => rfl) (fun i used => ?_) j
    by_cases h : i.succ ∈ a ∨ i.succ ∈ b
    · have bound := lim i
      simp [hits,h] at bound
      rcases used with hit | out
      · omega
      · exact (no i out).elim
    · have outside : i ∉ plainArm a ∪ plainArm b := by simpa [plainArm] using h
      have eq := Finset.ext_iff.mp rest i
      have iffmem : i ∈ x ↔ i ∈ y := by simpa [outside] using eq
      simp [env,inputOn,iffmem]

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
