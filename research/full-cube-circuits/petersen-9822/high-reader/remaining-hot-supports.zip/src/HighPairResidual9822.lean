import SemanticHighPair9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport AdjacentCut
open PEqualNP.Outside.L_meta_9822.Clean
theorem high_pair_residual {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s t : Fin 10) (sl : 5≤s.val) (st : s.val<t.val) (tu : t.val≤8)
    (hs : innerValue pre g (SignedClamp.singleton s)=true)
    (ht : innerValue pre g (SignedClamp.singleton t)=true) :
    (s,t)∈([(5,6),(6,7),(7,8)] : List (Fin 10×Fin 10)) ∧
    ∀ i, g.inputs.head?=some i → ∀ w∈C.gates, PositiveOp w → i∉w.inputs := by
  have split : ∀ a b : Fin 10, 5≤a.val → a.val<b.val → b.val≤8 →
      (a,b)∈([(5,7),(5,8),(6,8)] : List (Fin 10×Fin 10)) ∨
      (a,b)∈([(5,6),(6,7),(7,8)] : List (Fin 10×Fin 10)) := by decide
  obtain adj|nonadj := split s t sl st tu
  · exact (adjacent_hot_pair_impossible r cand red (by omega) s t adj hs ht).elim
  · refine ⟨nonadj, ?_⟩
    intro i pin w mem op read
    exact public_nonadjacent_hot_pair_impossible r cand red seven s t nonadj hs ht i pin w mem op read
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.high_pair_residual
