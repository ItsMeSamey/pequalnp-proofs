import OR9822Finish

namespace PEqualNP.Outside.L_meta_9822.Sectors
open PEqualNP.CircuitLowerBounds Research.OddOr FreeAndNet

def countsAnd (g : Gate) : Bool :=
  match g.op with | .and => true | _ => false

theorem priceDisjoint (gs : List Gate) :
    gs.countP countsAnd + (gs.filter CircuitCompiler.orFlag).length ≤ gs.length := by
  induction gs with
  | nil => decide
  | cons g gs ih =>
    obtain ⟨op, inputs⟩ := g
    cases op <;> simp [List.filter_cons, List.countP_cons, countsAnd, CircuitCompiler.orFlag] <;> omega

theorem zeroNotAtMostSixAnd (C : Circuit) (h : Candidate C) (hz : C.gates.countP countsNot = 0) :
    C.gates.countP countsAnd ≤ 6 := by
  have price := priceDisjoint C.gates
  have hOr := Graph9822.zero_not_candidate_eleven C h hz
  have cap : C.gates.length ≤ 17 := h.2.1
  omega

end PEqualNP.Outside.L_meta_9822.Sectors
