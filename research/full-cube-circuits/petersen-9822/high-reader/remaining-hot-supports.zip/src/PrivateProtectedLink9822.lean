import PrivateDoublePeel9822
import PrivateOuterPhysical9822
import PrivatePhysicalFaces9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp LowHotElimination NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
open scoped Classical
theorem private_protected_link {C p mid post g} (s t : V)
    (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V)))
    (r : Roster C (p++literalGate s t::mid) post g) (cand : Candidate C) (red : Reduced 10 C.gates C.output)
    (unary : g.inputs=[10+p.length]) (privateH : ∀q∈C.gates, PositiveOp q → 10+p.length∉q.inputs)
    (guard : ∀x : Input, innerValue (p++literalGate s t::mid) g x=(x s || x t))
    (seven : 7≤C.gates.countP countsAnd) (j : Nat)
    (off : (clampValues p mid post (fun _ => false)).getD j false=false)
    (on : ∀ i : V,edge (pair s i)=true → i≠s → i≠t →
      (clampValues p mid post (SignedClamp.singleton i)).getD j false=true) : False := by
  obtain ⟨J,cl,pos,cap,hot,cold,sites⟩ := private_outer s t r cand red unary privateH guard seven
    (fun _ => false) (by simp)
  have witness : ∃i : V,edge (pair s i)=true ∧ i≠s ∧ i≠t := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide +kernel
  obtain ⟨i0,e0,ns,nt⟩ := witness
  have ok (q : Gate) (m : q∈p++mid++post) := cand.1 q (by
    rw [r.split];simp only [List.mem_append,List.mem_cons] at m ⊢;tauto)
  have obs (x : Input) := ((clamp_run p mid post ok x).1.2 j).2
  obtain ⟨a,ae⟩ := observed_wire obs ⟨(fun _ => false),SignedClamp.singleton i0,by rw [off,on i0 e0 ns nt];decide⟩
  have az : vl J.gates (fun _ => false : Input) a=false := by rw [sites];exact (ae _).trans off
  have aw (i : V) (e : edge (pair s i)=true) (n : i≠s) (m : i≠t) : vl J.gates (SignedClamp.singleton i) a=true := by
    rw [sites];exact (ae _).trans (on i e n m)
  have neq : s≠t := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  obtain ⟨D,dc,dp,save,fit,observers⟩ := double_peel J cl pos s t neq hot cold
  have mz : masked {s,t} (fun _ => false)=(fun _ => false) := by funext k;simp [masked]
  have ms (i : V) (n : i≠s) (m : i≠t) : masked {s,t} (SignedClamp.singleton i)=SignedClamp.singleton i := by
    funext k
    by_cases h : k=s
    · subst k; simp [masked,SignedClamp.singleton,n.symm]
    · by_cases l : k=t
      · subst k; simp [masked,SignedClamp.singleton,m.symm]
      · simp [masked,h,l]
  obtain ⟨b,be⟩ := observers a ⟨(fun _ => false),SignedClamp.singleton i0,by rw [mz,ms i0 ns nt,az,aw i0 e0 ns nt];decide⟩
  exact private_residual_impossible s t shape D.gates D.output b dc dp (by omega) fit
    ((be _).trans (by simpa [mz] using az)) (fun i e n m => (be _).trans (by simpa [ms i n m] using aw i e n m))
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.private_protected_link
