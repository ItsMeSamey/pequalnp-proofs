import GuardEmitterRun9822
import OuterNet9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
open PEqualNP.CircuitLowerBounds FreeAndNet.CircuitCompiler
/-- Physical contact trace used by the construction's size accounting. -/
def contacts (out : Nat) : List Gate → List Bool → Nat × Bool
  | [], w => (0,w.getD out false)
  | g::gs,w =>
    let inputs := g.inputs.map (fun j => w.getD j false)
    let flag := inputs.any id
    let t := contacts out gs (w++[if FreeAndNet.CircuitCompiler.orFlag g then false else flag])
    (t.1 + if FreeAndNet.CircuitCompiler.orFlag g && flag then 1 else 0,t.2)
end PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
