import PhysicalHotTrace9822
import TaggedCutWiring9822

namespace PEqualNP.Outside.L_meta_9822.Clean.GuardTags
open PEqualNP.CircuitLowerBounds FreeAndNet FreeAndNet.CircuitCompiler Research.OddOr
open PEqualNP.Outside.L_meta_9822.Sectors.OuterNet PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open PEqualNP.Outside.L_meta_9822.Sectors

theorem physicalHot_append (a b : List Gate) (w : List Bool) :
    physicalHot (a++b) w = physicalHot a w + physicalHot b (wiresFrom a w) := by
  induction a generalizing w with
  | nil => simp [physicalHot,wiresFrom]
  | cons g gs ih =>
    simp only [List.cons_append,physicalHot,ih]
    change _ = _ + physicalHot b (wiresFrom gs _)
    dsimp only
    ac_rfl

theorem physicalHot_shift (gs : List Gate) (w : List Bool) (z : Bool) :
    physicalHot (gs.map shift) (z::w) = physicalHot gs w := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih =>
    have reads : (shift g).inputs.map (fun j => (z::w).getD j false) =
        g.inputs.map (fun j => w.getD j false) := by simp [shift,List.map_map,Function.comp_def,List.getD]
    simp only [List.map_cons,physicalHot,reads,List.cons_append]
    change physicalHot (List.map shift gs) (z :: _) + _ = _
    rw [ih]
    rfl

theorem model_hot {pre post : List Gate} {g : Gate} {out : Nat}
    (min : Reduced 10 (pre++g::post) out)
    (pp : ∀ q∈pre++post,q.op=.and ∨ q.op=.or) (x : Input) (z : Bool) :
    hotCount (env x z) (model pre post out) =
      physicalHot pre (List.ofFn x) +
      physicalHot post (wiresFrom pre (List.ofFn x) ++ [z]) := by
  let C := cutCircuit pre post out
  let w := List.ofFn (fun i : Fin 11 => [i])
  have pos : ∀ q∈C.gates,q.op=.and ∨ q.op=.or := by
    intro q hq
    rcases List.mem_append.mp hq with a|b
    · obtain ⟨p,hp,rfl⟩ := List.mem_map.mp a
      exact pp p (List.mem_append_left _ hp)
    · rcases List.mem_cons.mp b with rfl|b
      · exact Or.inl rfl
      · obtain ⟨p,hp,rfl⟩ := List.mem_map.mp b
        exact pp p (List.mem_append_right _ hp)
  have h := run_hot C.gates C.output w (env x z) (by simpa [w,C] using reduced_cut_wiring min) pos
  have init : w.map (fun q => q.all (env x z)) = z :: List.ofFn x := by
    change (List.ofFn (fun i : Fin 11 => [i])).map _ = _
    rw [List.map_ofFn,List.ofFn_succ]
    simp [env,Function.comp_def]
  have vals : w.map some = List.ofFn (fun i : Fin 11 => some [i]) := by simp [w]
  rw [init,vals] at h
  change hotCount (env x z) (compile 11 C) = _
  rw [show hotCount (env x z) (compile 11 C) = physicalHot C.gates (z::List.ofFn x) from h.symm]
  unfold C cutCircuit
  rw [physicalHot_append,physicalHot_shift,shifted_wires]
  cases z
  · change _ + (physicalHot (List.map shift post) (false :: (wiresFrom pre (List.ofFn x) ++ [false])) + 0) = _
    rw [physicalHot_shift,Nat.add_zero]
  · change _ + (physicalHot (List.map shift post) (true :: (wiresFrom pre (List.ofFn x) ++ [true])) + 0) = _
    rw [physicalHot_shift,Nat.add_zero]

end PEqualNP.Outside.L_meta_9822.Clean.GuardTags
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardTags.model_hot
