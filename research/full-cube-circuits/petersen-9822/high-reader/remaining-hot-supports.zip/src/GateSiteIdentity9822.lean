import CleanMin9822
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds
theorem gate_site_identity {n : Nat} {gs : List Gate} {out k l : Nat}
    (red : Reduced n gs out) (q : Gate) (ka : gs[k]?=some q) (la : gs[l]?=some q) : k=l := by
  have noOrder (i j : Nat) (ih : gs[i]?=some q) (jh : gs[j]?=some q) (ord : i<j) : False := by
    apply red.noAlias j (List.getElem?_eq_some_iff.mp jh).1 (n+i) (by omega)
    intro x
    rw [vl_gate _ red.clean _ _ q ih,vl_gate _ red.clean _ _ q jh]
  by_contra ne
  exact (lt_or_gt_of_ne ne).elim (noOrder k l ka la) (noOrder l k la ka)
end PEqualNP.Outside.L_meta_9822.Clean
#print axioms PEqualNP.Outside.L_meta_9822.Clean.gate_site_identity
