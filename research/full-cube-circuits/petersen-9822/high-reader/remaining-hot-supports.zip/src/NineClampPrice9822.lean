import NineHotBudget9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr Research.OddOr.Graph9822 Research.OddOr.Envelope
open SignedClamp NonrawSupport OuterNet LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
open GuardTags

theorem upper_nine_price {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (other : ∀ j : Fin 10,j≠9 → innerValue pre g (SignedClamp.singleton j)=false)
    (t : Net (Fin 10)) (ev : ∀ v : Input,t.eval v=outerValue pre post C.output v true) : 9≤t.cost := by
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have price : 8≤(pin 9 t).cost := by
    apply eight_off 9
    constructor
    · intro j ne
      rw [pin_sees _ _ _ (by simpa using ne)]
      change t.eval (inputOn {j})=false
      have eq : inputOn {j}=SignedClamp.singleton j := by funext k;simp [inputOn,SignedClamp.singleton]
      rw [eq,ev]
      have h := cut.computes (SignedClamp.singleton j)
      rw [other j ne.symm] at h
      exact h.trans (singleton_zero j)
    · intro j k nj nk on
      rw [pin_sees _ _ _ (by simp [nj,nk])]
      exact (ev _).trans (positive_upper cut _ on)
  have noOut : ¬outUses (9 : Fin 10) t := by
    obtain ⟨a,b,ha,hb,on⟩ := data.avoiding 9
    exact avoids_output t (by simp [ha,hb] : (9 : Fin 10)∉({a,b}: Finset _))
      ((ev _).trans (positive_upper cut _ on))
  have hi := (ev _).trans (upper_hot_nine r cand seven red other)
  have base := cut.computes (fun _ => false)
  rw [cold_empty r cand seven] at base
  have lo : t.eval (fun _ => false)=false := (ev _).trans base
  have hit : 0<hits 9 t := by
    by_contra! none
    have same : t.eval (SignedClamp.singleton 9)=t.eval (fun _ => false) := by
      apply eval_congr_used
      intro j used
      by_cases ne : j=(9 : Fin 10)
      · subst j; exact False.elim (used.elim (by omega) noOut)
      · simp [SignedClamp.singleton,ne]
    rw [hi,lo] at same;contradiction
  have saving := pin_cost (9 : Fin 10) t
  omega

theorem zero_upper_hot {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (other : ∀ j : Fin 10,j≠9 → innerValue pre g (SignedClamp.singleton j)=false) :
    physicalHot post (wiresFrom pre (List.ofFn (fun _ : Fin 10 => false)) ++ [true]) = 0 := by
  let t := model pre post C.output
  let u := retire (close true) t
  have ev (v : Input) : u.eval v=outerValue pre post C.output v true := by
    change (retire _ _).eval _=_
    rw [retire_eval,close_eval,model_eval r cand]
  have price := upper_nine_price r cand red seven other u ev
  have saving := retire_cost (close true) t
  have floor : floorRow (close true) = env (fun _ => false) true := close_eval _ _
  rw [floor] at saving
  change u.cost + hotCount (env (fun _ => false) true) (model pre post C.output) ≤ t.cost at saving
  have cap : t.cost≤9 := (model_cost r).trans (or_cap r cand seven)
  rw [model_hot (r.split ▸ red) r.pos] at saving
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
