import HighPhysicalReader9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open FreeAndNet Research.OddOr SignedClamp NonrawSupport OuterNet
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean
theorem high_unique_reader {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10) (lo : 5 ≤ i.val) (hi : i.val ≤ 8)
    (hot : innerValue pre g (singleton i)=true)
    (minimal : Reduced 10 C.gates C.output) :
    post.countP (ReaderDebit.reads (10+pre.length)) = 1 := by
  have bound := high_one_reader r cand seven i lo hi hot minimal
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have on : innerValue pre g (fun _ => true)=true := inner_mono_inputs
    (fun q hq => r.pos q (List.mem_append_left _ hq)) g (fun _ _ => rfl) hot
  have yes := cut.computes (fun _ => true)
  rw [on] at yes
  have diff : C.output ≠ 10+pre.length := by
    intro eq
    let w := wiresFrom pre (List.ofFn (fun _ : Fin 10 => true))
    have len : w.length=10+pre.length := by simp [w,length_wiresFrom]
    change (wiresFrom post (w++[false])).getD C.output false = true at yes
    rw [eq,← len,getD_wiresFrom _ _ _ (by simp),getD_snoc_eq] at yes
    contradiction
  have live := minimal.live pre.length (by rw [r.split]; simp)
  obtain ⟨q,hq⟩ := live.resolve_left diff
  have lt := reads_lt minimal.clean hq
  obtain ⟨a,pa,contains⟩ := hq
  rw [r.split,List.getElem?_append_right (by omega)] at pa
  obtain ⟨k,eq⟩ : ∃ k, q-pre.length = k+1 := ⟨q-pre.length-1,by omega⟩
  rw [eq] at pa
  change post[k]?=some a at pa
  have m := List.mem_iff_getElem?.mpr ⟨k,pa⟩
  have hit : ReaderDebit.reads (10+pre.length) a=true := decide_eq_true contains
  have pos : 0 < post.countP (ReaderDebit.reads (10+pre.length)) :=
    List.countP_pos_iff.mpr ⟨a,m,hit⟩
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.high_unique_reader
