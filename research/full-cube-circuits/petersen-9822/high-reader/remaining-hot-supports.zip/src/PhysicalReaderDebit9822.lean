import CleanCompile9822
namespace PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit
open PEqualNP.CircuitLowerBounds

def reads (j : Nat) (g : Gate) : Bool := decide (j ∈ g.inputs)

private theorem constant_operand (op : GateOp) (m : Nat) (xs : List Stat)
    (bound : xs.length ≤ 2) (b : Bool) (present : Sum.inl b ∈ xs) :
    (simplify op m xs).1 = none ∨ op = .not := by
  rcases xs with _ | ⟨a, _ | ⟨c, _ | ⟨d,tail⟩⟩⟩
  · simp at present
  · simp only [List.mem_singleton] at present
    subst a
    cases op <;> simp [simplify,simpAnd,simpOr,simpNot]
  · simp only [List.mem_cons,List.not_mem_nil,or_false] at present
    rcases present with he | he
    · subst a
      cases c <;> cases op <;> simp [simplify,simpAnd,simpOr,simpNot]
    · subst c
      cases a <;> cases op <;> simp [simplify,simpAnd,simpOr,simpNot]
  · simp at bound

/-- Count physical reader sites, including repeated uses in separate sites.
Two copies of an operand in the same gate incur just one debit. -/
theorem elim_readers (n j : Nat) (gs : List Gate) (acc : List Stat × List Gate)
    (valid : j < acc.1.length) (b : Bool) (pin : acc.1.getD j (Sum.inl false) = Sum.inl b)
    (ordinary : ∀ g ∈ gs, (g.op = .and ∨ g.op = .or) ∧ g.inputs.length ≤ 2) :
    (elim n gs acc).2.length + gs.countP (reads j) ≤ acc.2.length + gs.length := by
  induction gs generalizing acc with
  | nil => simp [elim]
  | cons g tail ih =>
    let next := elimStep n acc g
    have valid' : j < next.1.length := by
      change j < (acc.1 ++ [_]).length
      simp; omega
    have pin' : next.1.getD j (Sum.inl false) = Sum.inl b := by
      change (acc.1 ++ [_]).getD j (Sum.inl false) = Sum.inl b
      rw [List.getD_append _ _ _ _ valid,pin]
    have lower := ih next valid' pin' (fun a ha => ordinary a (List.mem_cons_of_mem _ ha))
    change (elim n tail next).2.length + _ ≤ _
    let ins := g.inputs.map fun i => acc.1.getD i (Sum.inl false)
    let emit := (simplify g.op (n+acc.2.length) ins).1
    have extra : next.2.length = acc.2.length + emit.toList.length := List.length_append ..
    cases hit : reads j g with
    | false =>
      have bound := toList_length_le emit
      rw [List.countP_cons_of_neg (by simp [hit]),List.length_cons]
      omega
    | true =>
      have mem : j∈g.inputs := of_decide_eq_true hit
      have keep : Sum.inl b ∈ ins := by
        exact List.mem_map.mpr ⟨j,mem,pin⟩
      obtain ⟨positive,size⟩ := ordinary g List.mem_cons_self
      have drop : emit = none := (constant_operand g.op _ ins (by simpa [ins] using size) b keep).resolve_right
        (by rcases positive with h|h <;> simp [h])
      have gone : next.2.length = acc.2.length := by simpa [drop] using extra
      rw [List.countP_cons_of_pos hit,List.length_cons]
      omega
end PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit
#print axioms PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit.elim_readers
