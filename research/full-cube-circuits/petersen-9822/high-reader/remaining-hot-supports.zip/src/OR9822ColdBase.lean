import OR9822ClampedWires
import OR9822Cycles

/- OR9822ColdSection -/
namespace Research.OddOr.Envelope
open FreeAndNet

theorem triangle_floor (t : Net (Fin 3)) (cold : ∀ j, sees t {j} = false)
    (hot : ∀ i j : Fin 3, i ≠ j → sees t {i,j} = true) : 2 ≤ t.cost := by
  have eval : Computes t := by
    intro s
    change sees t s = true ↔ 2 ≤ s.card
    constructor
    · intro on
      by_contra! small
      by_cases empty : s = ∅
      · subst s; rw [empty_cold t cold] at on; contradiction
      · obtain ⟨i,hi⟩ := Finset.card_eq_one.mp (by
          have := Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr empty)
          omega : s.card = 1)
        rw [hi,cold] at on
        contradiction
    · intro large
      obtain ⟨i,hi,j,hj,ne⟩ := Finset.one_lt_card.mp large
      exact sees_mono t (pair_in hi hj) (hot i j ne)
  simpa using threshold_two_or_lower t eval

theorem peel_trace {α β : Type} [DecidableEq α] [DecidableEq β] {E : α → α → Prop}
    {xs : List α} {core : Finset α} (peel : Peel E xs core) (e : β ↪ α)
    (inside : ∀ j, e j ∈ core) (t : Net α) (fit : Fits E (xs.toFinset ∪ core) t) :
    ∃ v : Net β, v.cost + xs.length ≤ t.cost ∧ ∀ s : Finset β, sees v s = sees t (s.map e) := by
  obtain ⟨u,paid,read⟩ := peel_cost peel t fit
  refine ⟨specialize (inverseRaw e) u,?_,?_⟩
  · have cost := specialize_cost (inverseRaw e) u
    omega
  · intro s
    apply (reembed e u s).trans
    apply read
    intro x hx
    obtain ⟨j,_,rfl⟩ := Finset.mem_map.mp hx
    exact inside j

def AcceptPairs {α : Type} [DecidableEq α] (f : Finset α → Bool) (t : Net α) :=
  (∀ i, sees t {i} = false) ∧ (∀ i j, f {i,j} = true → sees t {i,j} = true)

theorem chord_price (a b : Cycle5.V) (e : Fin 3 ↪ Cycle5.V)
    (xs : List Cycle5.V) (core : Finset Cycle5.V)
    (peel : Peel (fun x y => Cycle5.f {x,y} = true) xs core) (inside : ∀ j, e j ∈ core)
    (edges : ∀ i j : Fin 3, i ≠ j → Cycle5.f {e i,e j} = true ∨ ({e i,e j} : Finset _) = {a,b})
    (t : Net Cycle5.V) (fit : AcceptPairs Cycle5.f t) (chord : sees t {a,b} = true) :
    2 + xs.length ≤ t.cost := by
  obtain ⟨u,paid,read⟩ := peel_trace peel e inside t
    ⟨fun x _ => fit.1 x,fun x _ y _ on => fit.2 x y on⟩
  have lower := triangle_floor u (fun j => by simpa using (read {j}).trans (by simpa using fit.1 (e j)))
    (by
      intro i j ne
      rw [read]
      simp only [Finset.map_insert,Finset.map_singleton]
      rcases edges i j ne with orig | same
      · exact fit.2 _ _ orig
      · rwa [same])
  omega

end Research.OddOr.Envelope

/- OR9822ColdPentagon -/
namespace Research.OddOr.Envelope
open FreeAndNet
open Cycle5
set_option maxRecDepth 16000

private def tri02 : Fin 3 ↪ Cycle5.V where
  toFun := fun i => ([0,1,2] : List Cycle5.V).get i
  inj' := by decide +kernel

private theorem chord02 (t : Net Cycle5.V) (fit : AcceptPairs Cycle5.f t)
    (on : sees t {0,2} = true) : 4 ≤ t.cost := by
  refine chord_price 0 2 tri02 [4,3] {0,1,2} ?_ (by decide +kernel) (by decide +kernel) t fit on
  refine Peel.step (j := 0) (a := 0) (b := 1) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 2) (a := 0) (b := 1) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private def tri03 : Fin 3 ↪ Cycle5.V where
  toFun := fun i => ([0,4,3] : List Cycle5.V).get i
  inj' := by decide +kernel

private theorem chord03 (t : Net Cycle5.V) (fit : AcceptPairs Cycle5.f t)
    (on : sees t {0,3} = true) : 4 ≤ t.cost := by
  refine chord_price 0 3 tri03 [2,1] {0,4,3} ?_ (by decide +kernel) (by decide +kernel) t fit on
  refine Peel.step (j := 1) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 0) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private def tri13 : Fin 3 ↪ Cycle5.V where
  toFun := fun i => ([1,2,3] : List Cycle5.V).get i
  inj' := by decide +kernel

private theorem chord13 (t : Net Cycle5.V) (fit : AcceptPairs Cycle5.f t)
    (on : sees t {1,3} = true) : 4 ≤ t.cost := by
  refine chord_price 1 3 tri13 [4,0] {1,2,3} ?_ (by decide +kernel) (by decide +kernel) t fit on
  refine Peel.step (j := 0) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 1) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private def tri14 : Fin 3 ↪ Cycle5.V where
  toFun := fun i => ([1,0,4] : List Cycle5.V).get i
  inj' := by decide +kernel

private theorem chord14 (t : Net Cycle5.V) (fit : AcceptPairs Cycle5.f t)
    (on : sees t {1,4} = true) : 4 ≤ t.cost := by
  refine chord_price 1 4 tri14 [3,2] {1,0,4} ?_ (by decide +kernel) (by decide +kernel) t fit on
  refine Peel.step (j := 2) (a := 1) (b := 0) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 1) (a := 1) (b := 0) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private def tri24 : Fin 3 ↪ Cycle5.V where
  toFun := fun i => ([2,3,4] : List Cycle5.V).get i
  inj' := by decide +kernel

private theorem chord24 (t : Net Cycle5.V) (fit : AcceptPairs Cycle5.f t)
    (on : sees t {2,4} = true) : 4 ≤ t.cost := by
  refine chord_price 2 4 tri24 [1,0] {2,3,4} ?_ (by decide +kernel) (by decide +kernel) t fit on
  refine Peel.step (j := 0) (a := 2) (b := 3) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 4) (a := 2) (b := 3) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

theorem any_pentagon_floor (t : Net Cycle5.V) (fit : AcceptPairs Cycle5.f t) : 4 ≤ t.cost := by
  by_cases h02 : sees t {0,2} = true
  · exact chord02 t fit h02
  by_cases h03 : sees t {0,3} = true
  · exact chord03 t fit h03
  by_cases h13 : sees t {1,3} = true
  · exact chord13 t fit h13
  by_cases h14 : sees t {1,4} = true
  · exact chord14 t fit h14
  by_cases h24 : sees t {2,4} = true
  · exact chord24 t fit h24
  apply Cycle5.lower t
  intro s
  cases truth : Cycle5.f s with
  | true =>
    have positives : ∀ z : Finset Cycle5.V, Cycle5.f z = true → ∃ i ∈ z, ∃ j ∈ z, Cycle5.f {i,j} = true := by decide +kernel
    obtain ⟨i,hi,j,hj,ed⟩ := positives s truth
    exact sees_mono t (pair_in hi hj) (fit.2 i j ed)
  | false =>
    have neg : ∀ z : Finset Cycle5.V, Cycle5.f z = false → z = ∅ ∨ (∃ i, z = {i}) ∨ z = {0,2} ∨ z = {0,3} ∨ z = {1,3} ∨ z = {1,4} ∨ z = {2,4} := by decide +kernel
    rcases neg s truth with rfl | ⟨i,rfl⟩ | rfl | rfl | rfl | rfl | rfl
    · exact empty_cold t fit.1
    · exact fit.1 i
    · cases e : sees t {0,2} <;> simp_all
    · cases e : sees t {0,3} <;> simp_all
    · cases e : sees t {1,3} <;> simp_all
    · cases e : sees t {1,4} <;> simp_all
    · cases e : sees t {2,4} <;> simp_all

end Research.OddOr.Envelope
