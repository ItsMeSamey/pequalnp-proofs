import PairFace9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.PairFace
open FreeAndNet Research.OddOr LowPositive
def posIsolated (s : Finset V) := neg 6 7 (insert 1 s)

theorem positive_isolated_floor (t : Net V) (h : ∀ s, sees t s = posIsolated s) :
    6 ≤ t.cost := by
  apply apply_cycle posIsolated {0,3,4,5,8} [2,9] emb67 Cycle5.f _
    (by decide +kernel) (by decide +kernel) Cycle5.lower t h
  refine Steps.step (lo := ∅) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Steps.step (lo := {4}) (other := {0,4}) ?_ (by decide +kernel) (by decide +kernel)
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Steps.done _
end PEqualNP.Outside.L_meta_9822.Sectors.PairFace
