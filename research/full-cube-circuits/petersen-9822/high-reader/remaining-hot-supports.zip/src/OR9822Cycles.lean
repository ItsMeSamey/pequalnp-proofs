import OR9822Combinatorics

/- BEGIN OR9822Cycle5.lean -/
namespace Research.OddOr
open FreeAndNet
namespace Cycle5
set_option maxRecDepth 16000
abbrev V := Fin 5
def f (s : Finset V) : Bool :=
  (decide (0 ∈ s) && decide (1 ∈ s)) || (decide (1 ∈ s) && decide (2 ∈ s)) || (decide (2 ∈ s) && decide (3 ∈ s)) || (decide (3 ∈ s) && decide (4 ∈ s)) || (decide (4 ∈ s) && decide (0 ∈ s))

def data : GraphRows f where
  walk := [0,1,2,3,4]
  spans := by decide +kernel
  steps := by decide +kernel
  cold := by decide +kernel
  singleton := by decide +kernel
  neighbor := by decide +kernel
  diff := by decide +kernel
  avoiding := by decide +kernel
  edges := fun j => if j = 0 then {0,1} else if j = 1 then {1,2} else {2,3}
  hot := by decide +kernel
  meet := by decide +kernel

theorem lower (t : Net V) (h : ∀ s : Finset V, sees t s = f s) : 4 ≤ t.cost := by
  refine graph_raise data 2 ?_ t h
  intro i t ht
  fin_cases i
  · refine price_from_peel data.singleton (xs := [1,2]) (core := {3,4}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 2) (a := 3) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 3) (a := 3) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · refine price_from_peel data.singleton (xs := [2,3]) (core := {4,0}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 3) (a := 4) (b := 0) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 4) (a := 4) (b := 0) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · refine price_from_peel data.singleton (xs := [3,4]) (core := {0,1}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 4) (a := 0) (b := 1) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 0) (a := 0) (b := 1) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · refine price_from_peel data.singleton (xs := [4,0]) (core := {1,2}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 0) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 1) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · refine price_from_peel data.singleton (xs := [0,1]) (core := {2,3}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 1) (a := 2) (b := 3) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 2) (a := 2) (b := 3) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
end Cycle5
end Research.OddOr
/- END OR9822Cycle5.lean -/

/- BEGIN OR9822Cycle6.lean -/
namespace Research.OddOr
open FreeAndNet
namespace Cycle6
set_option maxRecDepth 16000
abbrev V := Fin 6
def f (s : Finset V) : Bool :=
  (decide (0 ∈ s) && decide (1 ∈ s)) || (decide (1 ∈ s) && decide (2 ∈ s)) || (decide (2 ∈ s) && decide (3 ∈ s)) || (decide (3 ∈ s) && decide (4 ∈ s)) || (decide (4 ∈ s) && decide (5 ∈ s)) || (decide (5 ∈ s) && decide (0 ∈ s))

def data : GraphRows f where
  walk := [0,1,2,3,4,5]
  spans := by decide +kernel
  steps := by decide +kernel
  cold := by decide +kernel
  singleton := by decide +kernel
  neighbor := by decide +kernel
  diff := by decide +kernel
  avoiding := by decide +kernel
  edges := fun j => if j = 0 then {0,1} else if j = 1 then {1,2} else {2,3}
  hot := by decide +kernel
  meet := by decide +kernel

theorem lower (t : Net V) (h : ∀ s : Finset V, sees t s = f s) : 5 ≤ t.cost := by
  refine graph_raise data 3 ?_ t h
  intro i t ht
  fin_cases i
  · refine price_from_peel data.singleton (xs := [1,2,3]) (core := {4,5}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 2) (a := 4) (b := 5) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 3) (a := 4) (b := 5) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 4) (a := 4) (b := 5) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · refine price_from_peel data.singleton (xs := [2,3,4]) (core := {5,0}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 3) (a := 5) (b := 0) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 4) (a := 5) (b := 0) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 5) (a := 5) (b := 0) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · refine price_from_peel data.singleton (xs := [3,4,5]) (core := {0,1}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 4) (a := 0) (b := 1) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 5) (a := 0) (b := 1) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 0) (a := 0) (b := 1) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · refine price_from_peel data.singleton (xs := [4,5,0]) (core := {1,2}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 5) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 0) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 1) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · refine price_from_peel data.singleton (xs := [5,0,1]) (core := {2,3}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 0) (a := 2) (b := 3) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 1) (a := 2) (b := 3) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 2) (a := 2) (b := 3) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · refine price_from_peel data.singleton (xs := [0,1,2]) (core := {3,4}) ?_ (by decide +kernel) t ht
    refine Peel.step (j := 1) (a := 3) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 2) (a := 3) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 3) (a := 3) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
end Cycle6
end Research.OddOr
/- END OR9822Cycle6.lean -/

/- BEGIN OR9822Slice.lean -/
namespace Research.OddOr
open FreeAndNet

variable {α β : Type} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]

/-- Peel down to an induced graph with a separately proved OR lower bound. -/
theorem induced_price {f : Finset α → Bool} {g : Finset β → Bool}
    (cold : ∀ x, f {x} = false) (e : β ↪ α)
    (k : Nat) (lower : ∀ t : Net β, (∀ s, sees t s = g s) → k ≤ t.cost)
    (xs : List α) (core : Finset α)
    (peel : Peel (fun x y => f {x,y} = true) xs core)
    (cover : ∀ j, e j ∈ core) (induced : ∀ s, f (s.map e) = g s)
    (t : Net α) (agrees : ∀ s ⊆ xs.toFinset ∪ core, sees t s = f s) :
    k + xs.length ≤ t.cost := by
  classical
  have fit : Fits (fun x y => f {x,y} = true) (xs.toFinset ∪ core) t := by
    constructor
    · intro x hx
      apply (agrees {x} (by simpa using hx)).trans (cold x)
    · intro x hx y hy he
      have subset : ({x,y} : Finset α) ⊆ xs.toFinset ∪ core := by
        intro z hz
        rcases Finset.mem_insert.mp hz with eq | hz
        · simpa only [eq] using hx
        · simpa only [Finset.mem_singleton.mp hz] using hy
      exact (agrees {x,y} subset).trans he
  obtain ⟨v,hv,eq⟩ := peel_cost peel t fit
  have slice (s : Finset β) : s.map e ⊆ core := by
    intro x hx
    obtain ⟨j,_,rfl⟩ := Finset.mem_map.mp hx
    exact cover j
  have bound := lower (specialize (inverseRaw e) v) (fun s =>
    (reembed e v s).trans ((eq _ (slice s)).trans
      ((agrees _ ((slice s).trans Finset.subset_union_right)).trans (induced s))))
  have deb := specialize_cost (inverseRaw e) v
  omega

theorem induced_pin_price {f : Finset α → Bool} {g : Finset β → Bool}
    (cold : ∀ x, f {x} = false) (e : β ↪ α)
    (k : Nat) (lower : ∀ t : Net β, (∀ s, sees t s = g s) → k ≤ t.cost)
    (i : α) (xs : List α) (core : Finset α)
    (peel : Peel (fun x y => f {x,y} = true) xs core)
    (cover : ∀ j, e j ∈ core) (induced : ∀ s, f (s.map e) = g s)
    (off : i ∉ xs.toFinset ∪ core)
    (t : Net α) (agrees : ∀ s : Finset α, i ∉ s → sees t s = f s) :
    k + xs.length ≤ t.cost :=
  induced_price cold e k lower xs core peel cover induced t
    (fun s hs => agrees s (fun mem => off (hs mem)))

end Research.OddOr
/- END OR9822Slice.lean -/

/- BEGIN OR9822Drop12.lean -/
namespace Research.OddOr
open FreeAndNet
namespace Drop12
set_option maxRecDepth 16000
abbrev V := Fin 8
def f (s : Finset V) : Bool :=
  (decide (1 ∈ s) && decide (2 ∈ s)) || (decide (0 ∈ s) && decide (2 ∈ s)) || (decide (0 ∈ s) && decide (3 ∈ s)) || (decide (1 ∈ s) && decide (6 ∈ s)) || (decide (2 ∈ s) && decide (7 ∈ s)) || (decide (3 ∈ s) && decide (5 ∈ s)) || (decide (5 ∈ s) && decide (7 ∈ s)) || (decide (4 ∈ s) && decide (7 ∈ s)) || (decide (4 ∈ s) && decide (6 ∈ s)) || (decide (3 ∈ s) && decide (6 ∈ s))

def data : GraphRows f where
  walk := [0,2,1,6,3,5,7,4]
  spans := by decide +kernel
  steps := by decide +kernel
  cold := by decide +kernel
  singleton := by decide +kernel
  neighbor := by decide +kernel
  diff := by decide +kernel
  avoiding := by decide +kernel
  edges := fun j => if j = 0 then {1,2} else if j = 1 then {0,2} else {0,3}
  hot := by decide +kernel
  meet := by decide +kernel

def emb0 : Cycle5.V ↪ V where
  toFun := fun v => ([1,2,7,4,6] : List V).get v
  inj' := by decide +kernel

theorem price0 (t : Net V) (h : ∀ s : Finset V, (0 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb0 4 Cycle5.lower 0 [5,3] {1,2,7,4,6} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 3) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 6) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb1 : Cycle5.V ↪ V where
  toFun := fun v => ([0,2,7,5,3] : List V).get v
  inj' := by decide +kernel

theorem price1 (t : Net V) (h : ∀ s : Finset V, (1 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb1 4 Cycle5.lower 1 [6,4] {0,2,7,5,3} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 3) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 7) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb2 : Cycle5.V ↪ V where
  toFun := fun v => ([3,5,7,4,6] : List V).get v
  inj' := by decide +kernel

theorem price2 (t : Net V) (h : ∀ s : Finset V, (2 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb2 4 Cycle5.lower 2 [1,0] {3,5,7,4,6} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 6) (a := 3) (b := 5) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 3) (a := 3) (b := 5) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb3 : Cycle5.V ↪ V where
  toFun := fun v => ([1,2,7,4,6] : List V).get v
  inj' := by decide +kernel

theorem price3 (t : Net V) (h : ∀ s : Finset V, (3 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb3 4 Cycle5.lower 3 [5,0] {1,2,7,4,6} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 7) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 2) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb4 : Cycle5.V ↪ V where
  toFun := fun v => ([0,2,1,6,3] : List V).get v
  inj' := by decide +kernel

theorem price4 (t : Net V) (h : ∀ s : Finset V, (4 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb4 4 Cycle5.lower 4 [7,5] {0,2,1,6,3} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 2) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 3) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb5 : Cycle5.V ↪ V where
  toFun := fun v => ([0,2,1,6,3] : List V).get v
  inj' := by decide +kernel

theorem price5 (t : Net V) (h : ∀ s : Finset V, (5 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb5 4 Cycle5.lower 5 [7,4] {0,2,1,6,3} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 2) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 6) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb6 : Cycle5.V ↪ V where
  toFun := fun v => ([0,2,7,5,3] : List V).get v
  inj' := by decide +kernel

theorem price6 (t : Net V) (h : ∀ s : Finset V, (6 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb6 4 Cycle5.lower 6 [4,1] {0,2,7,5,3} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 7) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 2) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

def emb7 : Cycle5.V ↪ V where
  toFun := fun v => ([0,2,1,6,3] : List V).get v
  inj' := by decide +kernel

theorem price7 (t : Net V) (h : ∀ s : Finset V, (7 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb7 4 Cycle5.lower 7 [5,4] {0,2,1,6,3} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  refine Peel.step (j := 3) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 6) (a := 0) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

theorem lower (t : Net V) (h : ∀ s : Finset V, sees t s = f s) : 8 ≤ t.cost := by
  refine graph_raise data 6 ?_ t h
  intro i
  fin_cases i
  · exact price0
  · exact price1
  · exact price2
  · exact price3
  · exact price4
  · exact price5
  · exact price6
  · exact price7
end Drop12
end Research.OddOr
/- END OR9822Drop12.lean -/

