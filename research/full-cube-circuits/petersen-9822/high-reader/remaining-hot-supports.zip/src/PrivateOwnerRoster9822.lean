import PrivateRightOwner9822
import PrivateExclusiveOwner9822
import PairNonadjacentPorts9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
open scoped Classical
theorem marked_three {L : List Gate} {hit : Gate→Bool} (cap : L.countP hit≤3)
    (a b c : Gate) (ab : a≠b) (ac : a≠c) (bc : b≠c)
    (ma : a∈L) (mb : b∈L) (mc : c∈L) (ha : hit a=true) (hb : hit b=true) (hc : hit c=true)
    (q : Gate) (qm : q∈L) (qh : hit q=true) : q=a ∨ q=b ∨ q=c := by
  classical
  by_contra! bad
  let chosen : Finset Gate := {q,a,b,c}
  have count : chosen.card=4 := by simp [chosen,bad.1,bad.2.1,bad.2.2,ab,ac,bc]
  have incl : chosen⊆(L.filter hit).toFinset := by
    intro j hj
    simp only [chosen,Finset.mem_insert,Finset.mem_singleton] at hj
    rcases hj with rfl|rfl|rfl|rfl <;> simp_all
  have lim := (Finset.card_le_card incl).trans (List.toFinset_card_le _)
  rw [count,←List.countP_eq_length_filter] at lim
  omega
theorem private_owner_roster {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s t : V) (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V)))
    (guard : ∀ v : Input,innerValue pre g v=(v s || v t)) (p tail : List Gate)
    (whole : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length]) (ord : p.length<pre.length)
    (priv : ∀q∈C.gates,PositiveOp q → 10+p.length∉q.inputs)
    (z : Gate) (zm : z∈C.gates) (za : z.op=.and) (zr : 10+pre.length∈z.inputs) :
    ∃k : Nat,∃a : Gate,C.gates[k]?=some a ∧ a.op=.and ∧ s.val∈a.inputs ∧
      ∀q∈p++tail,s.val∈q.inputs → q=a := by
  classical
  have range : s≠t ∧ 5≤s.val ∧ s.val≤8 ∧ 5≤t.val ∧ t.val≤8 := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  obtain ⟨ds,sl,su,tl,tu⟩ := range
  obtain ⟨k,a,ka,aa,sa,na⟩ := private_exclusive_owner r cand red (by omega) s t ds sl su guard p tail whole unary priv
  have swap (v : Input) : innerValue pre g v=(v t || v s) := by rw [guard,Bool.or_comm]
  obtain ⟨l,b,lb,ba,tb,nb⟩ := private_exclusive_right r cand red (by omega) t s ds.symm tl tu swap p tail whole unary priv
  have ma := List.mem_iff_getElem?.mpr ⟨k,ka⟩
  have mb := List.mem_iff_getElem?.mpr ⟨l,lb⟩
  obtain ⟨kz,zk⟩ := List.mem_iff_getElem?.mp zm
  have no := (no_pair_and_overlap r red s t p tail whole unary ord z kz zk za).2 zr
  let hit := fun q : Gate => decide (q.op=.and) && (q.inputs.any fun j =>
      decide (j=s.val ∨ j=t.val ∨ j=10+p.length ∨ j=10+pre.length))
  have cap := four_signed_readers r cand red.clean (by omega) s t shape p tail whole unary ord
  change C.gates.countP hit≤3 at cap
  have sh (q : Gate) (op : q.op=.and) (pin : s.val∈q.inputs) : hit q=true := by
    simp [hit,op,List.any_eq_true];exact ⟨_,pin,Or.inl rfl⟩
  have bh : hit b=true := by simp [hit,ba,List.any_eq_true];exact ⟨_,tb,Or.inr (Or.inl rfl)⟩
  have zh : hit z=true := by simp [hit,za,List.any_eq_true];exact ⟨_,zr,Or.inr (Or.inr (Or.inr rfl))⟩
  refine ⟨k,a,ka,aa,sa,?_⟩
  intro q ext pin
  have mq : q∈C.gates := by rw [whole];simp only [List.mem_append,List.mem_cons] at ext ⊢;tauto
  have ng : q≠g := by rintro rfl; rw [unary,List.mem_singleton] at pin;omega
  have pos := r.pos q (by rw [r.split] at mq;simpa [List.mem_append,ng] using mq)
  have andq : q.op=.and := pos.resolve_right
    (no_external_raw_or r cand red (by omega) s t s t sl su guard (Or.inl rfl) p tail whole q ext pin)
  obtain qa|qb|qz := marked_three cap a b z (fun e => nb (e ▸ sa))
    (fun e => no.1 (e ▸ sa)) (fun e => no.2 (e ▸ tb)) ma mb zm (sh a aa sa) bh zh q mq (sh q andq pin)
  · exact qa
  · exact (nb (qb ▸ pin)).elim
  · exact (no.1 (qz ▸ pin)).elim
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.private_owner_roster
