import ColdRawHits9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds
open SignedClamp NonrawSupport OuterNet FreeAndNet Research.OddOr
open PEqualNP.Outside.L_meta_9822.Clean
theorem physical_guard_observer {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    {row : Input} (hot : innerValue pre g row = true) :
    ∃ a : Nat, a < 10+pre.length ∧ ∀ v : Input, ∀ z : Bool, (model pre post a).eval (env v z) =
      innerValue pre g v := by
  cases hg : g.inputs with
  | nil => simp [innerValue,hg] at hot
  | cons a tail =>
    have bound : a < 10+pre.length := by
      by_contra! bad
      have miss : (wiresFrom pre (List.ofFn row)).getD a false = false :=
        List.getD_eq_default _ _ (by rw [length_wiresFrom]; simpa using bad)
      unfold innerValue at hot
      rw [hg] at hot
      change (wiresFrom pre (List.ofFn row)).getD a false = true at hot
      rw [miss] at hot
      contradiction
    refine ⟨a,bound,?_⟩
    intro v z
    have hm : PEqualNP.MetaComplexity.Monotone2 (cutCircuit pre post a) := model_legal r cand
    change (CircuitCompiler.compile 11 (cutCircuit pre post a)).eval _ = _
    rw [CircuitCompiler.compile_eval _ _ hm,cut_eval]
    unfold outerValue innerValue
    rw [hg]
    change (wiresFrom post (wiresFrom pre (List.ofFn v) ++ [z])).getD a false =
      (wiresFrom pre (List.ofFn v)).getD a false
    have room : a < (wiresFrom pre (List.ofFn v)).length := by
      rw [length_wiresFrom]; simpa using bound
    have room' : a < (wiresFrom pre (List.ofFn v) ++ [z]).length := by
      rw [List.length_append]
      exact Nat.lt_trans room (Nat.lt_succ_self _)
    rw [getD_wiresFrom _ _ _ room',getD_snoc_ne _ _ _ _ (Nat.ne_of_lt room)]


theorem coupled_cold_trace {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (cold : ∀ j,innerValue pre g (SignedClamp.singleton j)=false) :
    ∃ a : Nat, a < 10+pre.length ∧
      SameTrace (model pre post C.output) (model pre post a) ∧
      (∀ x z,(model pre post a).eval (env x z)=innerValue pre g x) ∧
      (∀ i : Fin 10, hits i.succ (model pre post C.output) ≤ 1 ∧
        ¬outUses i.succ (model pre post C.output) ∧ ¬outUses i.succ (model pre post a)) := by
  obtain ⟨v,_,_,hot⟩ := independent_witness r cand seven 0
  obtain ⟨a,bound,read⟩ := physical_guard_observer r cand hot
  refine ⟨a,bound,compile_trace _ _ _ _,read,?_⟩
  intro i
  refine ⟨cold_raw_hits r cand seven cold i,cold_no_raw_output r cand i,?_⟩
  intro used
  obtain ⟨v,off,_,on⟩ := independent_witness r cand seven i
  have bad := outZeros _ _ used (env v false) (by simpa [env] using off)
  rw [read,on] at bad; contradiction
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.coupled_cold_trace
