import AbsorbingAnd9822
import PairGuardReplace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem pair_physical_values {C pre post g} (r : Roster C pre post g)
    (cl : CleanL 10 C.gates) (s t : Fin 10) (p tail : List Gate)
    (physical : C.gates=p++literalGate s t::tail) (invpin : g.inputs=[10+p.length])
    (x : Input) :
    vl C.gates x (10+p.length)=(x s || x t) ∧
      vl C.gates x (10+pre.length)=(!(x s || x t)) := by
  have site : C.gates[p.length]?=some (literalGate s t) := by simp [physical]
  have inv : C.gates[pre.length]?=some g := by simp [r.split]
  have raw (i : Fin 10) : vl C.gates x i.val=x i := vl_input _ _ _ i.isLt
  have value : vl C.gates x (10+p.length)=(x s || x t) := by
    rw [vl_gate _ cl _ _ _ site]
    simp [literalGate,GateOp.eval,raw]
  refine ⟨value,?_⟩
  rw [vl_gate _ cl _ _ _ inv,r.inv,invpin]
  simp [GateOp.eval,value]

theorem no_pair_and_overlap {C pre post g} (r : Roster C pre post g)
    (red : Reduced 10 C.gates C.output) (s t : Fin 10) (p tail : List Gate)
    (physical : C.gates=p++literalGate s t::tail) (invpin : g.inputs=[10+p.length])
    (ord : p.length<pre.length) (q : Gate) (k : Nat) (site : C.gates[k]?=some q)
    (kind : q.op=.and) :
    (10+p.length∈q.inputs → s.val∉q.inputs ∧ t.val∉q.inputs ∧ 10+pre.length∉q.inputs) ∧
    (10+pre.length∈q.inputs → s.val∉q.inputs ∧ t.val∉q.inputs) := by
  have value := pair_physical_values r red.clean s t p tail physical invpin
  have raw (x : Input) (i : Fin 10) : vl C.gates x i.val=x i := vl_input _ _ _ i.isLt
  constructor
  · intro h
    refine ⟨fun sr => no_absorbing_product red q site kind _ _ (by omega) sr h ?_,
      fun tr => no_absorbing_product red q site kind _ _ (by omega) tr h ?_,
      fun zr => no_disjoint_product red q site kind _ _ (by omega) h zr ?_⟩
    · intro x hx; rw [raw] at hx; simp [(value x).1,hx]
    · intro x hx; rw [raw] at hx; simp [(value x).1,hx]
    · intro x hx; rw [(value x).1] at hx; simp [(value x).2,hx]
  · intro z
    refine ⟨fun sr => no_disjoint_product red q site kind _ _ (by omega) sr z ?_,
      fun tr => no_disjoint_product red q site kind _ _ (by omega) tr z ?_⟩
    · intro x hx; rw [raw] at hx; simp [(value x).2,hx]
    · intro x hx; rw [raw] at hx; simp [(value x).2,hx]
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.no_pair_and_overlap
