import OR9822Classification
import OR9822Cofactors

/- BEGIN OR9822Theta233Floor.lean -/
namespace Research.OddOr
open FreeAndNet Theta
namespace Theta233
abbrev I := Fin 5
def target (x : Row I) : Bool :=
  (x.l && (x.raw 0)) || ((x.raw 0) && x.r) || (x.l && (x.raw 1)) || ((x.raw 1) && (x.raw 2)) || ((x.raw 2) && x.r) || (x.l && (x.raw 3)) || ((x.raw 3) && (x.raw 4)) || ((x.raw 4) && x.r)

def low (bits : Nat) : Row I := ⟨bits.testBit 0,bits.testBit 1,fun i => bits.testBit (i.val+2)⟩
def index (p : Tiny I) : Nat :=
  p.1.elim 0 (fun i => i.val+1) * 5 + match p.2 with
  | .unit => 0 | .left => 1 | .right => 2 | .both => 3 | .either => 4

private def witnessCode (p q : Tiny I) : Nat :=
  match index p with
  | 0 => #[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0].getD (index q) 0
  | 1 => #[0,0,0,0,0,5,0,5,0,5,6,0,6,0,6,17,0,17,0,17,8,0,8,0,8,19,0,19,0,19].getD (index q) 0
  | 2 => #[0,0,0,0,0,10,10,0,0,10,16,16,0,0,16,12,12,0,0,12,18,18,0,0,18,14,14,0,0,14].getD (index q) 0
  | 3 => #[0,0,0,0,0,15,10,5,0,15,16,16,6,0,16,17,12,17,0,17,18,18,8,0,18,19,14,19,0,19].getD (index q) 0
  | 4 => #[0,0,0,0,0,5,0,0,0,0,6,0,0,0,0,12,0,0,0,0,8,0,0,0,0,14,0,0,0,0].getD (index q) 0
  | 5 => #[0,5,10,15,5,0,0,0,0,0,50,81,50,6,50,85,85,42,12,85,170,323,170,8,170,325,325,164,14,325].getD (index q) 0
  | 6 => #[0,0,10,10,0,0,0,0,0,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10].getD (index q) 0
  | 7 => #[0,5,0,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5].getD (index q) 0
  | 8 => #[0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5].getD (index q) 0
  | 9 => #[0,5,10,15,0,0,0,0,0,0,50,81,50,6,50,85,85,42,12,85,170,323,170,8,170,325,325,164,14,325].getD (index q) 0
  | 10 => #[0,6,16,16,6,101,10,5,5,50,1,1,1,1,1,81,86,42,12,86,241,323,8,8,323,326,326,54,14,326].getD (index q) 0
  | 11 => #[0,0,16,16,0,81,81,81,81,81,1,1,1,1,1,81,81,81,81,81,81,81,81,81,81,81,81,81,81,81].getD (index q) 0
  | 12 => #[0,6,0,6,0,6,6,6,6,6,1,1,1,1,1,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6].getD (index q) 0
  | 13 => #[0,0,0,0,0,6,6,6,6,6,1,1,1,1,1,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6].getD (index q) 0
  | 14 => #[0,6,16,16,0,81,81,81,81,81,1,1,1,1,1,81,81,81,81,81,81,81,81,81,81,81,81,81,81,81].getD (index q) 0
  | 15 => #[0,17,12,17,12,62,10,5,5,85,42,81,52,6,52,2,2,2,2,2,172,88,172,8,172,362,14,164,14,164].getD (index q) 0
  | 16 => #[0,0,12,12,0,12,12,12,12,12,12,12,12,12,12,2,2,2,2,2,12,12,12,12,12,12,12,12,12,12].getD (index q) 0
  | 17 => #[0,17,0,17,0,42,42,42,42,42,42,42,42,42,42,2,2,2,2,2,42,42,42,42,42,42,42,42,42,42].getD (index q) 0
  | 18 => #[0,0,0,0,0,12,12,12,12,12,12,12,12,12,12,2,2,2,2,2,12,12,12,12,12,12,12,12,12,12].getD (index q) 0
  | 19 => #[0,17,12,17,0,42,42,42,42,42,42,42,42,42,42,2,2,2,2,2,42,42,42,42,42,42,42,42,42,42].getD (index q) 0
  | 20 => #[0,8,18,18,8,343,10,5,5,170,363,81,6,6,81,88,88,42,12,88,3,3,3,3,3,323,328,164,14,328].getD (index q) 0
  | 21 => #[0,0,18,18,0,323,323,323,323,323,323,323,323,323,323,88,88,323,323,88,3,3,3,3,3,323,323,323,323,323].getD (index q) 0
  | 22 => #[0,8,0,8,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,3,3,3,3,3,8,8,8,8,8].getD (index q) 0
  | 23 => #[0,0,0,0,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,3,3,3,3,3,8,8,8,8,8].getD (index q) 0
  | 24 => #[0,8,18,18,0,323,323,323,323,323,323,323,323,323,323,88,88,323,323,88,3,3,3,3,3,323,323,323,323,323].getD (index q) 0
  | 25 => #[0,19,14,19,14,184,10,5,5,325,54,81,54,6,54,244,12,42,12,42,164,323,174,8,174,4,4,4,4,4].getD (index q) 0
  | 26 => #[0,0,14,14,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,4,4,4,4,4].getD (index q) 0
  | 27 => #[0,19,0,19,0,164,164,164,164,164,54,164,54,164,54,164,164,164,164,164,164,164,164,164,164,4,4,4,4,4].getD (index q) 0
  | 28 => #[0,0,0,0,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,4,4,4,4,4].getD (index q) 0
  | 29 => #[0,19,14,19,0,164,164,164,164,164,54,164,54,164,54,164,164,164,164,164,164,164,164,164,164,4,4,4,4,4].getD (index q) 0
  | _ => 0

private def pivotIndex (p q : Tiny I) : I := ⟨witnessCode p q % 5,Nat.mod_lt _ (by decide)⟩
private def pivotRow (p q : Tiny I) : Row I := low (witnessCode p q / 5)

set_option maxRecDepth 16000 in
private theorem cert0 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := (none,e)
    Checked target false p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert1 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 0),e)
    Checked target false p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert2 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 1),e)
    Checked target false p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert3 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 2),e)
    Checked target false p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert4 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 3),e)
    Checked target false p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert5 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 4),e)
    Checked target false p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

private theorem verified (p q : Tiny I) : ∃ i x, Checked target false p q i x := by
  refine ⟨pivotIndex p q,pivotRow p q,?_⟩
  obtain ⟨_ | i,e⟩ := p
  · exact cert0 e q
  · fin_cases i
    · exact cert1 e q
    · exact cert2 e q
    · exact cert3 e q
    · exact cert4 e q
    · exact cert5 e q

private def sparseLow (i j : I) : Row I :=
  low <| match i.val,j.val with
  | 0,0 => 1
  | 0,1 => 1
  | 0,2 => 1
  | 0,3 => 1
  | 0,4 => 1
  | 1,0 => 1
  | 1,1 => 1
  | 1,2 => 1
  | 1,3 => 1
  | 1,4 => 1
  | 2,0 => 8
  | 2,1 => 2
  | 2,2 => 8
  | 2,3 => 8
  | 2,4 => 8
  | 3,0 => 1
  | 3,1 => 1
  | 3,2 => 1
  | 3,3 => 1
  | 3,4 => 1
  | 4,0 => 32
  | 4,1 => 32
  | 4,2 => 32
  | 4,3 => 2
  | 4,4 => 32
  | _,_ => 0

private theorem sparseChecks : ∀ i j : I, i ≠ j →
    let x := sparseLow i j
    target x ≠ target (bump i x) ∧ x.raw j = false ∧ (bump i x).raw j = false := by decide +kernel

private theorem sparse : SparsePivot target := by
  intro i j ne
  exact ⟨sparseLow i j,bump i (sparseLow i j),bump_varies _ _,sparseChecks i j ne⟩

private theorem allPivots (i : I) : ∃ x y, VariesOnly i x y ∧ target x ≠ target y := by
  have other : ∀ z : I, ∃ j : I, z ≠ j := by decide
  obtain ⟨j,ne⟩ := other i
  obtain ⟨x,y,delta,diff,_,_⟩ := sparse i j ne
  exact ⟨x,y,delta,diff⟩

private def otherEdge (i : I) : Row I := low <| match i.val with
  | 0 => 9
  | 1 => 5
  | 2 => 5
  | 3 => 5
  | 4 => 5
  | _ => 0

private theorem residual (i : I) : ∃ z, z.raw i = false ∧ target z = true := by
  have h : ∀ i : I, (otherEdge i).raw i = false ∧ target (otherEdge i) = true := by decide
  exact ⟨_,h i⟩

private theorem census : ∀ a b : Term I, (a.support ≠ ∅ ∨ b.support ≠ ∅) →
    CoversPivots target a b → Survivor target a b := by
  apply classify_small target sparse
  apply small_from_checked _ verified
  intro h; cases h

theorem lower (t : Net V) (h : ∀ s, sees t s = f s) : 7 ≤ t.cost := by
  refine theta_lower f data target ?_ ?_ ?_ allPivots residual census t h
  · intro x
    simp [target,f,fromRow,initial,val,Ep.eval]
  · intro i
    fin_cases i
    · exact price2
    · exact price3
    · exact price4
    · exact price5
    · exact price6
  · constructor
    · decide
    · constructor <;> decide
end Theta233
end Research.OddOr
/- END OR9822Theta233Floor.lean -/

/- BEGIN OR9822Theta144Floor.lean -/
namespace Research.OddOr
open FreeAndNet Theta
namespace Theta144
abbrev I := Fin 6
def target (x : Row I) : Bool :=
  (x.l && x.r) || (x.l && (x.raw 0)) || ((x.raw 0) && (x.raw 1)) || ((x.raw 1) && (x.raw 2)) || ((x.raw 2) && x.r) || (x.l && (x.raw 3)) || ((x.raw 3) && (x.raw 4)) || ((x.raw 4) && (x.raw 5)) || ((x.raw 5) && x.r)

def low (bits : Nat) : Row I := ⟨bits.testBit 0,bits.testBit 1,fun i => bits.testBit (i.val+2)⟩
def index (p : Tiny I) : Nat :=
  p.1.elim 0 (fun i => i.val+1) * 5 + match p.2 with
  | .unit => 0 | .left => 1 | .right => 2 | .both => 3 | .either => 4

private def witnessCode (p q : Tiny I) : Nat :=
  match index p with
  | 0 => #[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0].getD (index q) 0
  | 1 => #[0,0,0,0,0,6,0,6,0,6,103,0,25,0,25,56,0,50,0,50,9,0,9,0,9,778,0,196,0,196,395,0,389,0,389].getD (index q) 0
  | 2 => #[0,0,0,0,0,60,48,0,0,48,37,25,0,0,25,14,14,0,0,14,399,387,0,0,387,208,196,0,0,196,17,17,0,0,17].getD (index q) 0
  | 3 => #[0,0,0,0,0,0,48,6,0,48,1,25,25,0,25,2,14,50,0,50,3,387,9,0,387,4,196,196,0,196,5,17,389,0,389].getD (index q) 0
  | 4 => #[0,0,0,0,0,6,0,0,0,0,37,0,0,0,0,14,0,0,0,0,9,0,0,0,0,208,0,0,0,0,17,0,0,0,0].getD (index q) 0
  | 5 => #[0,6,60,0,6,0,0,0,0,0,48,54,60,25,54,102,102,38,14,102,240,387,9,9,387,390,390,196,196,390,774,774,41,17,774].getD (index q) 0
  | 6 => #[0,0,48,48,0,0,0,0,0,0,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48].getD (index q) 0
  | 7 => #[0,6,0,6,0,0,0,0,0,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6].getD (index q) 0
  | 8 => #[0,0,0,0,0,0,0,0,0,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6].getD (index q) 0
  | 9 => #[0,6,48,48,0,0,0,0,0,0,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48].getD (index q) 0
  | 10 => #[0,103,37,1,37,25,48,37,6,37,1,1,1,1,1,97,103,50,14,103,217,57,9,9,57,409,196,196,196,196,793,17,65,17,65].getD (index q) 0
  | 11 => #[0,0,25,25,0,25,25,25,25,25,1,1,1,1,1,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25].getD (index q) 0
  | 12 => #[0,25,0,25,0,25,25,25,25,25,1,1,1,1,1,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25].getD (index q) 0
  | 13 => #[0,0,0,0,0,25,25,25,25,25,1,1,1,1,1,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25].getD (index q) 0
  | 14 => #[0,25,25,25,0,25,25,25,25,25,1,1,1,1,1,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25].getD (index q) 0
  | 15 => #[0,56,14,2,14,38,48,38,6,38,50,56,62,25,56,2,2,2,2,2,206,105,206,9,206,398,196,398,196,398,818,17,389,17,389].getD (index q) 0
  | 16 => #[0,0,14,14,0,14,14,14,14,14,14,14,14,14,14,2,2,2,2,2,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14].getD (index q) 0
  | 17 => #[0,50,0,50,0,38,50,38,50,38,50,50,50,50,50,2,2,2,2,2,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50].getD (index q) 0
  | 18 => #[0,0,0,0,0,14,14,14,14,14,14,14,14,14,14,2,2,2,2,2,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14].getD (index q) 0
  | 19 => #[0,50,14,50,0,38,50,38,50,38,50,50,50,50,50,2,2,2,2,2,50,50,50,50,50,50,50,50,50,50,50,50,50,50,50].getD (index q) 0
  | 20 => #[0,9,399,3,9,411,48,6,6,48,57,57,25,25,57,105,105,50,14,105,3,3,3,3,3,387,393,399,196,393,777,777,209,17,777].getD (index q) 0
  | 21 => #[0,0,387,387,0,387,387,387,387,387,57,57,387,387,57,105,105,387,387,105,3,3,3,3,3,387,387,387,387,387,387,387,387,387,387].getD (index q) 0
  | 22 => #[0,9,0,9,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,3,3,3,3,3,9,9,9,9,9,9,9,9,9,9].getD (index q) 0
  | 23 => #[0,0,0,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,3,3,3,3,3,9,9,9,9,9,9,9,9,9,9].getD (index q) 0
  | 24 => #[0,9,387,387,0,387,387,387,387,387,57,57,387,387,57,105,105,387,387,105,3,3,3,3,3,387,387,387,387,387,387,387,387,387,387].getD (index q) 0
  | 25 => #[0,778,208,4,208,220,48,6,6,48,244,25,25,25,25,292,14,50,14,50,196,387,208,9,208,4,4,4,4,4,772,778,389,17,778].getD (index q) 0
  | 26 => #[0,0,196,196,0,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,4,4,4,4,4,196,196,196,196,196].getD (index q) 0
  | 27 => #[0,196,0,196,0,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,4,4,4,4,4,196,196,196,196,196].getD (index q) 0
  | 28 => #[0,0,0,0,0,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,4,4,4,4,4,196,196,196,196,196].getD (index q) 0
  | 29 => #[0,196,196,196,0,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,196,4,4,4,4,4,196,196,196,196,196].getD (index q) 0
  | 30 => #[0,395,17,5,17,41,48,41,6,41,65,25,65,25,65,485,14,50,14,50,209,387,209,9,209,389,395,401,196,395,5,5,5,5,5].getD (index q) 0
  | 31 => #[0,0,17,17,0,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,5,5,5,5,5].getD (index q) 0
  | 32 => #[0,389,0,389,0,41,389,41,389,41,65,389,65,389,65,389,389,389,389,389,209,389,209,389,209,389,389,389,389,389,5,5,5,5,5].getD (index q) 0
  | 33 => #[0,0,0,0,0,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,5,5,5,5,5].getD (index q) 0
  | 34 => #[0,389,17,389,0,41,389,41,389,41,65,389,65,389,65,389,389,389,389,389,209,389,209,389,209,389,389,389,389,389,5,5,5,5,5].getD (index q) 0
  | _ => 0

private def pivotIndex (p q : Tiny I) : I := ⟨witnessCode p q % 6,Nat.mod_lt _ (by decide)⟩
private def pivotRow (p q : Tiny I) : Row I := low (witnessCode p q / 6)

set_option maxRecDepth 16000 in
private theorem cert0 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := (none,e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert1 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 0),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert2 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 1),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert3 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 2),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert4 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 3),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert5 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 4),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert6 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 5),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

private theorem verified (p q : Tiny I) : ∃ i x, Checked target true p q i x := by
  refine ⟨pivotIndex p q,pivotRow p q,?_⟩
  obtain ⟨_ | i,e⟩ := p
  · exact cert0 e q
  · fin_cases i
    · exact cert1 e q
    · exact cert2 e q
    · exact cert3 e q
    · exact cert4 e q
    · exact cert5 e q
    · exact cert6 e q

private def sparseLow (i j : I) : Row I :=
  low <| match i.val,j.val with
  | 0,0 => 1
  | 0,1 => 1
  | 0,2 => 1
  | 0,3 => 1
  | 0,4 => 1
  | 0,5 => 1
  | 1,0 => 16
  | 1,1 => 4
  | 1,2 => 4
  | 1,3 => 4
  | 1,4 => 4
  | 1,5 => 4
  | 2,0 => 8
  | 2,1 => 2
  | 2,2 => 8
  | 2,3 => 8
  | 2,4 => 8
  | 2,5 => 8
  | 3,0 => 1
  | 3,1 => 1
  | 3,2 => 1
  | 3,3 => 1
  | 3,4 => 1
  | 3,5 => 1
  | 4,0 => 32
  | 4,1 => 32
  | 4,2 => 32
  | 4,3 => 128
  | 4,4 => 32
  | 4,5 => 32
  | 5,0 => 64
  | 5,1 => 64
  | 5,2 => 64
  | 5,3 => 64
  | 5,4 => 2
  | 5,5 => 64
  | _,_ => 0

private theorem sparseChecks : ∀ i j : I, i ≠ j →
    let x := sparseLow i j
    target x ≠ target (bump i x) ∧ x.raw j = false ∧ (bump i x).raw j = false := by decide +kernel

private theorem sparse : SparsePivot target := by
  intro i j ne
  exact ⟨sparseLow i j,bump i (sparseLow i j),bump_varies _ _,sparseChecks i j ne⟩

private theorem allPivots (i : I) : ∃ x y, VariesOnly i x y ∧ target x ≠ target y := by
  have other : ∀ z : I, ∃ j : I, z ≠ j := by decide
  obtain ⟨j,ne⟩ := other i
  obtain ⟨x,y,delta,diff,_,_⟩ := sparse i j ne
  exact ⟨x,y,delta,diff⟩

private def otherEdge (i : I) : Row I := low <| match i.val with
  | 0 => 3
  | 1 => 3
  | 2 => 3
  | 3 => 3
  | 4 => 3
  | 5 => 3
  | _ => 0

private theorem residual (i : I) : ∃ z, z.raw i = false ∧ target z = true := by
  have h : ∀ i : I, (otherEdge i).raw i = false ∧ target (otherEdge i) = true := by decide
  exact ⟨_,h i⟩

private theorem census : ∀ a b : Term I, (a.support ≠ ∅ ∨ b.support ≠ ∅) →
    CoversPivots target a b → Survivor target a b := by
  apply classify_small target sparse
  apply small_from_checked _ verified
  intro _ x h
  simp [target,h]

theorem lower (t : Net V) (h : ∀ s, sees t s = f s) : 8 ≤ t.cost := by
  refine theta_lower f data target ?_ ?_ ?_ allPivots residual census t h
  · intro x
    simp [target,f,fromRow,initial,val,Ep.eval]
  · intro i
    fin_cases i
    · exact price2
    · exact price3
    · exact price4
    · exact price5
    · exact price6
    · exact price7
  · constructor
    · decide
    · constructor <;> decide
end Theta144
end Research.OddOr
/- END OR9822Theta144Floor.lean -/

