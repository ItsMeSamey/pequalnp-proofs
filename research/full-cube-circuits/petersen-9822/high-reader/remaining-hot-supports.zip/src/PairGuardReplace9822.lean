import TwoHighGuard9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean

def literalGate (s t : Fin 10) : Gate := ⟨.or,[s.val,t.val]⟩

/-- Replace the gate already occupying the guard's wire. The equality is
of all physical wires, including every earlier value with a secondary use. -/
theorem replace_pair_guard (pre : List Gate) (g : Gate) (s t : Fin 10) (st : s≠t)
    (exactGuard : ∀ v : Input, innerValue pre g v = (v s || v t)) :
    ∃ p old tail, pre = p ++ old :: tail ∧ g.inputs.head? = some (10+p.length) ∧
      ∀ v : Input, wiresFrom (p ++ literalGate s t :: tail) (List.ofFn v) =
        wiresFrom pre (List.ofFn v) := by
  have hs : innerValue pre g (singleton s) = true := by simp [exactGuard,SignedClamp.singleton]
  have ht : innerValue pre g (singleton t) = true := by simp [exactGuard,SignedClamp.singleton]
  cases hg : g.inputs with
  | nil => simp [innerValue,hg] at hs
  | cons idx more =>
    have read (v : Input) : (wiresFrom pre (List.ofFn v)).getD idx false = (v s || v t) := by
      simpa [innerValue,hg] using exactGuard v
    have upper : idx < 10+pre.length := by
      by_contra! bad
      have miss := List.getD_eq_default (wiresFrom pre (List.ofFn (singleton s))) false
        (n := idx) (by rw [length_wiresFrom]; simpa using bad)
      rw [read] at miss
      simp [SignedClamp.singleton] at miss
    have lower : 10 ≤ idx := by
      by_contra! h
      have raw (v : Input) : v ⟨idx,h⟩ = (v s || v t) := by
        have eq := read v
        rw [getD_wiresFrom _ _ _ (by simpa using h),getD_ofFn 10 v false ⟨idx,h⟩] at eq
        exact eq
      have rs := raw (singleton s)
      have rt := raw (singleton t)
      simp [SignedClamp.singleton] at rs rt
      exact st (rs.symm.trans rt)
    let k := idx-10
    have hk : k < pre.length := by dsimp [k]; omega
    obtain ⟨p,tail,split,len⟩ := split_at pre k pre[k] (List.getElem?_eq_getElem hk)
    refine ⟨p,pre[k],tail,split,?_,?_⟩
    · simp only [List.head?_cons,Option.some.injEq]
      dsimp [k] at len
      omega
    · intro v
      let w := wiresFrom p (List.ofFn v)
      let old := pre[k]
      let val := old.op.eval (old.inputs.map fun i => w.getD i false)
      have pos : idx = w.length := by
        dsimp [w]
        rw [length_wiresFrom,List.length_ofFn,len]
        dsimp [k]
        omega
      have eq := read v
      rw [split,wiresFrom_append] at eq
      change (wiresFrom tail (w ++ [val])).getD idx false = _ at eq
      rw [getD_wiresFrom _ _ _ (by simp [pos]),pos,getD_snoc_eq] at eq
      have raw (i : Fin 10) : w.getD i.val false = v i := by
        dsimp [w]
        rw [getD_wiresFrom _ _ _ (by simpa using i.isLt)]
        exact getD_ofFn 10 v false i
      conv_rhs => rw [split]
      rw [wiresFrom_append,wiresFrom_append]
      change wiresFrom tail (w ++ [(literalGate s t).op.eval ((literalGate s t).inputs.map
        fun i => w.getD i false)]) = wiresFrom tail (w ++ [val])
      rw [eq]
      have rs := raw s
      have rt := raw t
      simpa [literalGate, GateOp.eval, List.getD] using
        congrArg (fun b => wiresFrom tail (w ++ [b])) (congrArg₂ Bool.or rs rt)
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.replace_pair_guard
