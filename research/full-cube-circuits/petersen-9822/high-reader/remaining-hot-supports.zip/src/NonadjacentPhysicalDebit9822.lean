import PairPhysicalFace9822
import PhysicalDeletion9822
import FinalPinDebit9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp
open scoped Classical
open PEqualNP.Outside.L_meta_9822.Clean ReaderDebit
theorem four_or_folds_impossible (C : Circuit) (cand : Candidate C) (cl : CleanL 10 C.gates)
    (nine : (C.gates.filter FreeAndNet.CircuitCompiler.orFlag).length ≤ 9) (s t : V)
    (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V))) (marks : Gate → Bool)
    (four : 4≤C.gates.countP marks)
    (markpin : ∀ q∈C.gates,marks q=true → q.op=.or ∧ ∃ j∈q.inputs, ∃ b : Bool,
      (foldZero C {s,t}).1.getD j (Sum.inl false)=Sum.inl b)
    (notpin : ∀ q∈C.gates,q.op=.not → ∃ j∈q.inputs, ∃ b : Bool,
      (foldZero C {s,t}).1.getD j (Sum.inl false)=Sum.inl b) : False := by
  let S : Finset V := {s,t}
  let F := foldZero C S
  have legal : CleanL (assignments S).length C.gates := by simpa [assignments] using cl
  have cap := final_pin_debit 10 .or marks C.gates (assignments S,[]) legal markpin
  have deq : (fun q : Gate => decide (q.op=GateOp.or))=FreeAndNet.CircuitCompiler.orFlag := by
    funext q; cases q with | mk op ins => cases op <;> simp [FreeAndNet.CircuitCompiler.orFlag]
  rw [deq] at cap
  change F.2.countP FreeAndNet.CircuitCompiler.orFlag+C.gates.countP marks≤0+C.gates.countP FreeAndNet.CircuitCompiler.orFlag at cap
  let isN := fun q : Gate => decide (q.op=GateOp.not)
  have zero := final_pin_debit 10 .not isN C.gates (assignments S,[]) legal
    (fun q m h => ⟨of_decide_eq_true h,notpin q m (of_decide_eq_true h)⟩)
  change F.2.countP isN+C.gates.countP isN≤0+C.gates.countP isN at zero
  have noneN : F.2.countP isN=0 := by omega
  have varied : ∃ x y : Input, edge (masked S x)≠edge (masked S y) := by
    refine ⟨fun _ => false,fun _ => true,?_⟩
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide +kernel
  obtain ⟨o,leg,ev⟩ := deleted_circuit C cand S varied
  let D : Circuit := ⟨F.2,o⟩
  have mono : Monotone2 D := by
    intro q h
    obtain ⟨ops,sz⟩ := leg q h
    have nn : q.op≠.not := fun e => (List.countP_eq_zero.mp noneN q h) (by simp [isN,e])
    exact ⟨by simpa [nn] using ops,sz⟩
  let n := FreeAndNet.CircuitCompiler.compile 10 D
  have spec (X : Finset V) : Research.OddOr.sees n X=PairFace.neg s t X := by
    change n.eval _ = _
    rw [FreeAndNet.CircuitCompiler.compile_eval _ _ mono,show D.eval _ = _ from ev (fun i => decide (i∈X))]
    unfold masked PairFace.neg
    apply congrArg edge
    funext i
    by_cases hs : i=s <;> by_cases ht : i=t <;> simp [S,hs,ht]
  have need : 6 ≤ n.cost := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩
    · exact PairFace.floor56 n spec
    · exact PairFace.floor67 n spec
    · exact PairFace.floor78 n spec
  have ncost := FreeAndNet.CircuitCompiler.compile_cost 10 D
  rw [←List.countP_eq_length_filter] at nine ncost
  change n.cost≤F.2.countP FreeAndNet.CircuitCompiler.orFlag at ncost
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.four_or_folds_impossible
