import MixedPositive9822
import CleanWire9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.MixedPositive
open FreeAndNet PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean

def forceZero (pre post : List Gate) (out : Nat) : Circuit :=
  ⟨pre ++ ⟨.or,[]⟩ :: post, out⟩

/-- An executable physical cofactor test on the original one-inverter gate
list. It allows arbitrary positive reuse of the input of that inverter. -/
theorem excludes_three_surviving_ors {s : Fin 10} (hs : s=5 ∨ s=8)
    (C : Circuit) {pre post : List Gate} {g : Gate}
    (split : C.gates = pre ++ g :: post)
    (positive : ∀ a ∈ pre ++ post, a.op = .and ∨ a.op = .or)
    (coldNot : ∀ x : Fin 10 → Bool, x s = false → x 9 = true →
      g.op.eval (g.inputs.map fun j => (wiresFrom pre (List.ofFn x)).getD j false) = false)
    (bound : (specialize (wire s) (CircuitCompiler.compile 10
      (forceZero pre post C.output))).cost ≤ 3) : ¬ Candidate C := by
  intro cand
  have mono : Monotone2 (forceZero pre post C.output) := by
    intro a ha
    change a ∈ pre ++ (⟨.or,[]⟩ : Gate) :: post at ha
    have ordinary (h : a ∈ pre ++ post) : a.op ∈ ({GateOp.and,GateOp.or} : Set GateOp) ∧
        a.inputs.length ≤ 2 := by
      have source : a ∈ C.gates := by
        rw [split]
        rcases List.mem_append.mp h with head | tail
        · exact List.mem_append_left _ head
        · exact List.mem_append_right _ (List.mem_cons_of_mem _ tail)
      exact ⟨positive a h,(cand.1 a source).2⟩
    rcases List.mem_append.mp ha with head | rest
    · exact ordinary (List.mem_append_left _ head)
    · rcases List.mem_cons.mp rest with rfl | tail
      · exact ⟨Or.inr rfl,by decide⟩
      · exact ordinary (List.mem_append_right _ tail)
  have face (x : Fin 10 → Bool) (sx : x s = false) (nx : x 9 = true) :
      (forceZero pre post C.output).eval (List.ofFn x) = edge x := by
    apply Eq.trans _ (cand.2.2 x)
    change (wiresFrom (pre ++ (⟨.or,[]⟩ : Gate) :: post) (List.ofFn x)).getD C.output false =
      (wiresFrom C.gates (List.ofFn x)).getD C.output false
    rw [split,wiresFrom_append,wiresFrom_append]
    change (wiresFrom post (wiresFrom pre (List.ofFn x) ++ [false])).getD C.output false =
      (wiresFrom post (wiresFrom pre (List.ofFn x) ++
        [g.op.eval (g.inputs.map fun j => (wiresFrom pre (List.ofFn x)).getD j false)])).getD C.output false
    rw [coldNot x sx nx]
  have lower := specialized_positive_floor s hs _ mono face
  omega

private theorem list_all_monotone {α : Type} (v w : α → Bool)
    (le : ∀ i, v i = true → w i = true) (xs : List α) :
    xs.all v = true → xs.all w = true := by
  simp only [List.all_eq_true]
  exact fun h i mem => le i (h i mem)

private theorem net_monotone {α : Type} (t : Net α) (v w : α → Bool)
    (le : ∀ i, v i = true → w i = true) : t.eval v = true → t.eval w = true := by
  induction t with
  | out p =>
    cases p with
    | none => exact id
    | some xs => exact list_all_monotone v w le xs
  | gate a b tail ih =>
    apply ih
    intro z
    cases z with
    | some i => exact le i
    | none =>
      change (a.all v || b.all v) = true → (a.all w || b.all w) = true
      simp only [Bool.or_eq_true]
      exact Or.imp (list_all_monotone v w le a) (list_all_monotone v w le b)

/-- This version checks the inverter guard only on singleton 9; all premises
are graph-label tests, gate-list facts, or a numerical folded OR budget. -/
theorem excludes_hot_nine {s : Fin 10} (hs : s=5 ∨ s=8) (C : Circuit)
    (pre post : List Gate) (a : Nat)
    (split : C.gates = pre ++ (⟨.not,[a]⟩ : Gate) :: post)
    (positive : ∀ g ∈ pre ++ post, g.op = .and ∨ g.op = .or)
    (hot : (wiresFrom pre (List.ofFn (fun j : Fin 10 => decide (j=9)))).getD a false = true)
    (bound : (specialize (wire s) (CircuitCompiler.compile 10
      (forceZero pre post C.output))).cost ≤ 3) : ¬ Candidate C := by
  intro cand
  let P : Circuit := ⟨pre,a⟩
  have hm : Monotone2 P := by
    intro g hg
    have base : g ∈ pre := hg
    have full : g ∈ C.gates := by rw [split]; exact List.mem_append_left _ base
    exact ⟨positive g (List.mem_append_left _ base),(cand.1 g full).2⟩
  apply excludes_three_surviving_ors hs C split positive _ bound cand
  intro x _ nx
  have inc : ∀ j : Fin 10, decide (j=9) = true → x j = true := by
    intro j hj
    have eq : j=9 := of_decide_eq_true hj
    simpa [eq] using nx
  have eq (v : Fin 10 → Bool) : (CircuitCompiler.compile 10 P).eval v =
      (wiresFrom pre (List.ofFn v)).getD a false := CircuitCompiler.compile_eval 10 P hm v
  have uh := net_monotone (CircuitCompiler.compile 10 P) _ x inc
    ((eq _).trans hot)
  have value := (eq x).symm.trans uh
  change (!(wiresFrom pre (List.ofFn x)).getD a false) = false
  rw [value]
  rfl

end PEqualNP.Outside.L_meta_9822.Sectors.MixedPositive
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.MixedPositive.excludes_three_surviving_ors

#print axioms PEqualNP.Outside.L_meta_9822.Sectors.MixedPositive.excludes_hot_nine
