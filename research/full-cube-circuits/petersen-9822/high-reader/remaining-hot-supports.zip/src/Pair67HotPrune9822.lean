import SynchronousPairNet9822

namespace FreeAndNet
def nodeEnv (a b : List α) (p : α → Bool) (i : Option α) : Bool :=
  i.elim (a.all p || b.all p) p

def orHot (p : α → Bool) : Net α → Bool
  | .out _ => false
  | .gate a b tail => (a.all p || b.all p) || orHot (nodeEnv a b p) tail

def hotPrune (p : α → Bool) : Net α → Net α
  | .out v => .out v
  | .gate a b tail =>
    let u := hotPrune (nodeEnv a b p) tail
    if a.all p || b.all p then specialize (fun i => i.elim (some []) (fun j => some [j])) u
    else .gate a b u

theorem SameSites.hot_eq {t w : Net α} (h : SameSites t w) (p : α → Bool) :
    orHot p t = orHot p w := by
  induction h with
  | out => rfl
  | gate a b h ih => simp [orHot,ih]

theorem hotPrune_cost (t : Net α) (p : α → Bool) :
    (hotPrune p t).cost + (if orHot p t then 1 else 0) ≤ t.cost := by
  induction t with
  | out => simp [hotPrune,orHot,Net.cost]
  | gate a b tail ih =>
    have pay := ih (nodeEnv a b p)
    have bound := specialize_cost (fun i : Option _ => i.elim (some []) (fun j => some [j]))
      (hotPrune (nodeEnv a b p) tail)
    by_cases h : (a.all p || b.all p) = true
    · simp [hotPrune,orHot,h,Net.cost]; omega
    · simp [hotPrune,orHot,h,Net.cost]; omega

theorem hotPrune_correct (t : Net α) (p q : α → Bool)
    (above : ∀ i, p i = true → q i = true) : (hotPrune p t).eval q = t.eval q := by
  induction t with
  | out => rfl
  | gate a b tail ih =>
    have le (l : List _) (on : l.all p = true) : l.all q = true :=
      List.all_eq_true.mpr (fun i hi => above i (List.all_eq_true.mp on i hi))
    have mono : ∀ i, nodeEnv a b p i = true → nodeEnv a b q i = true := by
      intro i
      cases i with
      | some i => exact above i
      | none =>
        change (a.all p || b.all p) = true → (a.all q || b.all q) = true
        simp only [Bool.or_eq_true]
        exact Or.imp (le a) (le b)
    have agree := ih (nodeEnv a b p) (nodeEnv a b q) mono
    by_cases h : (a.all p || b.all p) = true
    · have hq := mono none h
      simp only [hotPrune,h,ite_true,eval_specialize,Net.eval]
      refine Eq.trans ?_ agree
      congr 1
      funext i
      cases i with
      | some i => simp [pval,nodeEnv]
      | none => simpa [nodeEnv,pval] using hq.symm
    · simp only [hotPrune,if_neg h,Net.eval]
      exact agree

theorem noHotMeet (t : Net α) (p q z : α → Bool) (cold : orHot p t = false)
    (meet : ∀ i, p i = true → q i = true → z i = true) :
    t.eval p = true → t.eval q = true → t.eval z = true := by
  induction t with
  | out v =>
    cases v with
    | none => simp [Net.eval,pval]
    | some l =>
      change l.all p = true → l.all q = true → l.all z = true
      intro hp hq
      exact List.all_eq_true.mpr (fun i hi => meet i (List.all_eq_true.mp hp i hi)
        (List.all_eq_true.mp hq i hi))
  | gate a b tail ih =>
    have gateCold : (a.all p || b.all p) = false := by
      simpa only [orHot,Bool.or_eq_false_iff] using (show
        (a.all p || b.all p) = false from (Bool.or_eq_false_iff.mp cold).1)
    apply ih (nodeEnv a b p) (nodeEnv a b q) (nodeEnv a b z) (Bool.or_eq_false_iff.mp cold).2
    intro i
    cases i with
    | none => simp [nodeEnv,gateCold]
    | some j => exact meet j

end FreeAndNet
