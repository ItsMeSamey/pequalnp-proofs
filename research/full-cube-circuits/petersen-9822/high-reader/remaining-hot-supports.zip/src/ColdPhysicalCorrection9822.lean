import OR9822ColdRoot
import NonrawSupport9822
import ColdTwinCorrection9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds
open SignedClamp NonrawSupport

private theorem input_pair (a b : Fin 10) : inputOn {a,b} = pair a b := by
  funext j
  simp [inputOn,pair,SignedClamp.singleton]

theorem cold_disjoint_corrections {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (cold : ∀ j, innerValue pre g (SignedClamp.singleton j)=false) :
    ∃ a b x y : Fin 10, a ≠ b ∧ x ≠ a ∧ x ≠ b ∧ y ≠ a ∧ y ≠ b ∧ x ≠ y ∧
      edge (pair a y) = false ∧ edge (pair b x) = false ∧
      innerValue pre g (pair a y) = true ∧ innerValue pre g (pair b x) = true := by
  have input_single (j : Fin 10) : inputOn {j} = SignedClamp.singleton j := by
    funext k; simp [inputOn,SignedClamp.singleton]
  have twins := physical_cold_guard_twins C cand pre post g r.inv r.split r.pos
    (fun j => (input_single j).symm ▸ cold j) (or_cap r cand seven)
  obtain ⟨a,b,ne,off,eq⟩ := twins
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have miss : outerValue pre post C.output (pair a b) true = false := by
    simpa only [input_pair] using off
  have same (z : Fin 10) : outerValue pre post C.output (pair a z) true =
      outerValue pre post C.output (pair b z) true := by simpa only [input_pair] using eq z
  obtain ⟨x,y,ay,bx,hot1,hot2,apart⟩ := twin_corrections cut a b ne miss same
  have noCommon (u : Fin 10) (h1 : u=a ∨ u=y) (h2 : u=b ∨ u=x) : False := by
    have on1 : pair a y u=true := by simpa [pair,SignedClamp.singleton] using h1
    have on2 : pair b x u=true := by simpa [pair,SignedClamp.singleton] using h2
    have bad := apart u on1
    rw [on2] at bad; contradiction
  have diag (u : Fin 10) : pair u u = SignedClamp.singleton u := by funext j; simp [pair]
  refine ⟨a,b,x,y,ne,(fun h => noCommon x (Or.inl h) (Or.inr rfl)),?_,?_,
    (fun h => noCommon y (Or.inr rfl) (Or.inl h)),(fun h => noCommon x (Or.inr h) (Or.inr rfl)),ay,bx,hot1,hot2⟩
  · intro e; subst x; rw [diag,cold] at hot2; contradiction
  · intro e; subst y; rw [diag,cold] at hot1; contradiction
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.cold_disjoint_corrections
