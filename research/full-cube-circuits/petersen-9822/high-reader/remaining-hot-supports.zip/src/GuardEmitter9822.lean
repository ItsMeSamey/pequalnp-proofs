import PhysicalGuardTags9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
open PEqualNP.CircuitLowerBounds GuardTags
abbrev Reg := Bool × Stat
abbrev top : Stat := Sum.inl true
abbrev zero : Stat := Sum.inl false
structure Block where
  code : List Gate
  result : Stat
def one (n : Nat) (op : GateOp) (a b : Stat) : Block :=
  let p := simplify op n [a,b]
  ⟨p.1.toList,p.2⟩
def pureReg (a : Stat) : Block := ⟨[],a⟩
def seq (a : Block) (next : Stat → Block) : Block :=
  let b := next a.result
  ⟨a.code ++ b.code,b.result⟩
def repair (n z : Nat) (r : Reg) : Block :=
  if r.1 then one n .and (Sum.inr z) r.2 else pureReg r.2
def pairOr (n z : Nat) (a b : Reg) : Block :=
  let pa := repair n z a
  seq pa fun x =>
    let pb := repair (n+pa.code.length) z b
    seq pb fun y => one (n+pa.code.length+pb.code.length) .or x y
def meaning (w : List Bool) (r : Reg) : Tagged := (r.1,r.2.val w)
def Good (w : List Bool) (p : Block) (val : Bool) : Prop :=
  p.result.Valid (w.length+p.code.length) ∧ p.result.val (wiresFrom p.code w) = val
theorem one_good (op : GateOp) (ok : op=.and ∨ op=.or) (w : List Bool) (a b : Stat)
    (ha : a.Valid w.length) (hb : b.Valid w.length) :
    Good w (one w.length op a b) (op.eval [a.val w,b.val w]) := by
  exact simplify_sound op (by tauto) w [a,b] (by simp) (by simpa using And.intro ha hb)
theorem one_cost (n : Nat) (op : GateOp) (a b : Stat) : (one n op a b).code.length ≤ 1 :=
  toList_length_le _
theorem and_top_left (n : Nat) (b : Stat) : (one n .and top b).code = [] := by
  cases b <;> rfl
theorem and_top_right (n : Nat) (a : Stat) : (one n .and a top).code = [] := by
  cases a <;> rfl
theorem one_ok (n : Nat) (op : GateOp) (a b : Stat) :
    ∀ g∈(one n op a b).code, Ok g := by
  intro g h
  exact simplify_ok op n [a,b] g (Option.mem_toList.mp h)
theorem repair_cost (n z : Nat) (r : Reg) :
    (repair n z r).code.length ≤ r.1.toNat := by
  obtain ⟨b,x⟩ := r
  cases b with
  | false => rfl
  | true => exact one_cost _ _ _ _
theorem pair_cost (n z : Nat) (a b : Reg) :
    (pairOr n z a b).code.length ≤ 1+a.1.toNat+b.1.toNat := by
  let pa := repair n z a
  let pb := repair (n+pa.code.length) z b
  have ha := repair_cost n z a
  have hb := repair_cost (n+pa.code.length) z b
  have hc := one_cost (n+pa.code.length+pb.code.length) .or pa.result pb.result
  change (pa.code ++ (pb.code ++ (one (n+pa.code.length+pb.code.length) .or pa.result pb.result).code)).length ≤ _
  simp only [List.length_append]
  change pa.code.length ≤ _ at ha
  change pb.code.length ≤ _ at hb
  omega
theorem repair_good (w : List Bool) (z : Nat) (hz : z<w.length) (r : Reg) (hr : r.2.Valid w.length) :
    Good w (repair w.length z r) (recover (w.getD z false) (meaning w r)) := by
  obtain ⟨b,x⟩ := r
  cases b with
  | false => exact ⟨by simpa [repair,pureReg] using hr, by simp [repair,pureReg,meaning,recover,wiresFrom]⟩
  | true =>
    have h := one_good .and (Or.inl rfl) w (Sum.inr z) x hz hr
    simpa [repair,GateOp.eval,meaning,recover,Stat.val,Bool.and_comm] using h
end PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter.repair_good
