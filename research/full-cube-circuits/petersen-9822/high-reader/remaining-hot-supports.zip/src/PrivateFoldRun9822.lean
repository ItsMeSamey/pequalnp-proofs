import PrivateClampRun9822
import PrivatePeelDebit9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean
open scoped Classical
theorem observed_wire {L : List Gate} {s : Stat} {v : Input → Bool}
    (ev : ∀ x : Input,s.val (wiresFrom L (List.ofFn x))=v x)
    (varies : ∃ x y,v x≠v y) : ∃ i : Nat,∀x : Input,vl L x i=v x := by
  cases s with
  | inl b =>
    obtain ⟨x,y,diff⟩ := varies
    exact (diff ((ev x).symm.trans (ev y))).elim
  | inr j => exact ⟨j,ev⟩
theorem fold_run (C : Circuit) (cl : CleanL 10 C.gates) (pos : ∀q∈C.gates,PositiveOp q)
    (S : Finset V) (varies : ∃x y : Input,vl C.gates (masked S x) C.output≠vl C.gates (masked S y) C.output) :
    ∃ o : Nat, let L := (foldZero C S).2
      CleanL 10 L ∧ (∀q∈L,PositiveOp q) ∧ (∀x : Input,vl L x o=vl C.gates (masked S x) C.output) ∧
      ∀ j, (∃x y : Input,vl C.gates (masked S x) j≠vl C.gates (masked S y) j) →
        ∃i,∀x : Input,vl L x i=vl C.gates (masked S x) j := by
  let F := foldZero C S
  have ok := fun q m => (clean_nok _ _ cl q m).1
  have inv (x : Input) := inv_elim 10 (List.ofFn x) (by simp) C.gates _ _ ok (pin_inv S x)
  have obs (j : Nat) (v : ∃ x y : Input, vl C.gates (masked S x) j≠vl C.gates (masked S y) j) :
      ∃ i,∀x : Input,vl F.2 x i=vl C.gates (masked S x) j :=
    observed_wire (s:=F.1.getD j (Sum.inl false)) (fun x => ((inv x).2 j).2) v
  obtain ⟨o,eo⟩ := obs C.output varies
  have clean := clean_elim 10 (List.ofFn (fun _ : V => false)) (by simp) C.gates _ _ ok (pin_inv S _) (by intro i q h; simp at h)
  refine ⟨o,clean,?_,eo,obs⟩
  have no : C.gates.countP (ofOp .not)=0 := by
    apply List.countP_eq_zero.mpr
    intro q m
    rcases pos q m with h|h <;> simp [ofOp,h]
  have bound := elim_kind_bound C.gates (assignments S,[]) .not
  change F.2.countP (ofOp .not)≤0+_ at bound
  rw [no] at bound
  intro q m
  have legal := (clean_nok _ _ clean q m).1.1
  rcases legal with h|h|h
  · exact Or.inl h
  · exact Or.inr h
  · exact ((List.countP_eq_zero.mp (by omega : F.2.countP (ofOp .not)=0) q m) (by simpa [ofOp] using h)).elim
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.fold_run
