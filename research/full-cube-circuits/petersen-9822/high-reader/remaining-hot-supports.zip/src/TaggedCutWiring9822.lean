import TaggedCompilerHits9822
import CleanMin9822

namespace PEqualNP.Outside.L_meta_9822.Clean.GuardTags
open PEqualNP.CircuitLowerBounds FreeAndNet.CircuitCompiler
open PEqualNP.Outside.L_meta_9822.Sectors.OuterNet

private theorem tailClean {n g gs} (h : CleanL n (g::gs)) : CleanL (n+1) gs := by
  intro i q hq
  have p := h (i+1) q (by simpa using hq)
  simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using p

private theorem shifted_head {n g} (h : CleanGate n g) :
    (∀ j ∈ (shift g).inputs, j<n+1) ∧
      (orFlag (shift g)=true → ∃ a b, (shift g).inputs=[a,b]) := by
  rcases h with ⟨op,j,hj,ins⟩ | ⟨op,j,k,hj,hk,ins⟩
  · simp [shift,ins,orFlag,op,hj]
  · rcases op with op|op <;> simp [shift,ins,orFlag,op,hj,hk]

private theorem shifted_wiring (gs : List Gate) (n : Nat) (h : CleanL n gs) :
    TaggedWiring (n+1) (gs.map shift) := by
  induction gs generalizing n with
  | nil => trivial
  | cons g gs ih =>
    have a := shifted_head (show CleanGate n g by simpa using h 0 g (by simp))
    exact ⟨a.1,a.2,ih (n+1) (tailClean h)⟩

private theorem cut_wiring_at (pre post : List Gate) (g : Gate) (n : Nat)
    (h : CleanL n (pre++g::post)) :
    TaggedWiring (n+1) (pre.map shift ++ (⟨.and,[0]⟩ : Gate)::post.map shift) := by
  induction pre generalizing n with
  | nil =>
    exact ⟨by simp,by simp [orFlag],shifted_wiring post (n+1) (tailClean h)⟩
  | cons q qs ih =>
    have a := shifted_head (show CleanGate n q by simpa using h 0 q (by simp))
    exact ⟨a.1,a.2,ih (n+1) (tailClean h)⟩

theorem reduced_cut_wiring {pre post : List Gate} {g : Gate} {out : Nat}
    (h : Reduced 10 (pre++g::post) out) :
    TaggedWiring 11 (cutCircuit pre post out).gates :=
  cut_wiring_at pre post g 10 h.clean

end PEqualNP.Outside.L_meta_9822.Clean.GuardTags
