import ColdPhysicalExclusion9822
import LowHotElimination9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport
open PEqualNP.Outside.L_meta_9822.Clean

theorem physical_high_hot {C pre post g} (r : Roster C pre post g)
    (cand : Candidate C) (seven : 7 ≤ C.gates.countP countsAnd)
    (reduced : Reduced 10 C.gates C.output) :
    ∃ j : Fin 10, 5 ≤ j.val ∧ innerValue pre g (SignedClamp.singleton j) = true := by
  obtain ⟨j, hot⟩ := physical_hot_singleton r cand seven reduced
  refine ⟨j, ?_, hot⟩
  by_contra! low
  exact LowHotElimination.low_hot_impossible r seven j (by omega) hot cand

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.physical_high_hot
