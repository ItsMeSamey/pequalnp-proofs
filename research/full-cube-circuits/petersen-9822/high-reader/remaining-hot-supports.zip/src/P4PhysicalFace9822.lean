import P4FacePeels9822
import P4PhysicalTrace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.PairFace
open FreeAndNet Research.OddOr Research.Graph9822.P4Guard
def rows (a b c d : Vtx) (i : Fin 8) : Finset Vtx :=
  ([∅,{a},{b},{c},{d},{a,b},{b,c},{c,d}] : List (Finset Vtx)).get i
def vars (a b c d : Vtx) (i : Fin 8) (j : Vtx) := decide (j ∈ rows a b c d i)

theorem face_core (t w : Net Vtx) (sync : SameSites t w) (cap : t.cost ≤ 6)
    (s z a b c d : Vtx) (xs : List Vtx) (len : xs.length = 4)
    (peel : Peel (rel s z) xs {a,b,c,d})
    (rep : ∀ S, sees t S = neg s z S)
    (model : Models (vars a b c d) base)
    (subset : ∀ i, rows a b c d i ⊆ {a,b,c,d})
    (table : ∀ i : Fin 8, neg s z (rows a b c d i) = goal.getLsbD i.val)
    (cold : sees w ∅ = false) (left : sees w {a} = true) (right : sees w {d} = true) : False := by
  obtain ⟨u,v,h,charge,ou,ov⟩ := peel_two_outputs peel t (pair_fit _ _ _ rep _) w sync
  have small : u.cost ≤ 2 := by omega
  apply no_p4_sync h model closed_base safe_two small
  · intro i
    change sees u (rows a b c d i) = _
    rw [ou _ (subset i),rep]
    exact table i
  · intro m eq
    have hz := eq 0
    have ha := eq 1
    have hd := eq 4
    change sees v ∅ = _ at hz
    change sees v {a} = _ at ha
    change sees v {d} = _ at hd
    rw [ov _ (by simp),cold] at hz
    rw [ov _ (by simp),left] at ha
    rw [ov _ (by simp),right] at hd
    exact (by decide +kernel : ∀ k : Mask, false = k.getLsbD 0 → true = k.getLsbD 1 →
      true = k.getLsbD 4 → hot k = true) m hz ha hd

theorem protect56 (t w : Net Vtx) (sync : SameSites t w) (cap : t.cost ≤ 6)
    (rep : ∀ S, sees t S = neg 5 6 S)
    (cold : sees w ∅ = false) (left : sees w {0} = true) (right : sees w {8} = true) : False := by
  apply face_core t w sync cap 5 6 0 4 3 8 _ rfl steps56 rep _ (by decide +kernel) (by decide +kernel) cold left right
  intro x
  fin_cases x <;> first
    | exact ⟨0,by decide +kernel,by decide +kernel⟩
    | exact ⟨34,by decide +kernel,by decide +kernel⟩
    | exact ⟨100,by decide +kernel,by decide +kernel⟩
    | exact ⟨200,by decide +kernel,by decide +kernel⟩
    | exact ⟨144,by decide +kernel,by decide +kernel⟩

theorem protect78 (t w : Net Vtx) (sync : SameSites t w) (cap : t.cost ≤ 6)
    (rep : ∀ S, sees t S = neg 7 8 S)
    (cold : sees w ∅ = false) (left : sees w {2} = true) (right : sees w {9} = true) : False := by
  apply face_core t w sync cap 7 8 2 1 6 9 _ rfl steps78 rep _ (by decide +kernel) (by decide +kernel) cold left right
  intro x
  fin_cases x <;> first
    | exact ⟨0,by decide +kernel,by decide +kernel⟩
    | exact ⟨34,by decide +kernel,by decide +kernel⟩
    | exact ⟨100,by decide +kernel,by decide +kernel⟩
    | exact ⟨200,by decide +kernel,by decide +kernel⟩
    | exact ⟨144,by decide +kernel,by decide +kernel⟩
end PEqualNP.Outside.L_meta_9822.Sectors.PairFace
