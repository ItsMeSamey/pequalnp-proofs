import PairCover9822
import OuterNet9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.DualPhysical
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet Research.OddOr
open SignedClamp PEqualNP.Outside.L_meta_9822.Clean

def addr (n i : Nat) := if i<n then i+1 else 0
def swapOp : GateOp → GateOp
  | .and => .or
  | .or => .and
  | _ => .not
def dual (n : Nat) (g : Gate) : Gate := ⟨swapOp g.op,g.inputs.map (addr n)⟩
def phase (n : Nat) : List Gate → List Gate
  | [] => []
  | g::gs => dual n g :: phase (n+1) gs

theorem read (w : List Bool) (i : Nat) :
    (true :: w.map Bool.not).getD (addr w.length i) false = !(w.getD i false) := by
  by_cases h : i < w.length
  · simp [addr,h,List.getD,List.getElem?_eq_getElem h]
  · rw [List.getD_eq_default w false (Nat.le_of_not_gt h)]
    simp [addr,h]
private theorem evalop (op : GateOp) (ordinary : op=.or ∨ op=.and) (l : List Bool) :
    (swapOp op).eval (l.map Bool.not) = !(op.eval l) := by
  rcases ordinary with rfl | rfl <;> induction l with
  | nil => rfl
  | cons b bs ih => cases b <;> simp_all [swapOp,GateOp.eval]
theorem phase_eval (gs : List Gate) (w : List Bool) (ordinary : ∀ g ∈ gs,PositiveOp g) :
    wiresFrom (phase w.length gs) (true :: w.map Bool.not) =
      true :: (wiresFrom gs w).map Bool.not := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih =>
    let p := g.op.eval (g.inputs.map fun i => w.getD i false)
    have wire : (dual w.length g).op.eval ((dual w.length g).inputs.map
          fun i => (true :: w.map Bool.not).getD i false) = !p := by
      unfold dual
      simp only [List.map_map,Function.comp_def,read]
      have v := evalop g.op (Or.symm (ordinary g List.mem_cons_self))
        (g.inputs.map fun i => w.getD i false)
      simpa [List.map_map,Function.comp_def,p] using v
    change wiresFrom (phase (w.length+1) gs) ((true :: w.map Bool.not) ++ [_]) =
      true :: (wiresFrom gs (w ++ [p])).map Bool.not
    rw [wire]
    have ev := ih (w ++ [p]) (fun a ha => ordinary a (List.mem_cons_of_mem _ ha))
    simpa using ev

theorem phase_legal (n : Nat) (gs : List Gate)
    (legal : ∀ g ∈ gs, PositiveOp g ∧ g.inputs.length ≤ 2) :
    ∀ g ∈ phase n gs, PositiveOp g ∧ g.inputs.length ≤ 2 := by
  induction gs generalizing n with
  | nil => simp [phase]
  | cons q qs ih =>
    intro a ha
    rcases List.mem_cons.mp ha with rfl | h
    · obtain ⟨hp,hn⟩ := legal q List.mem_cons_self
      refine ⟨?_,by simpa [dual] using hn⟩
      rcases hp with e | e <;> simp [PositiveOp,dual,swapOp,e]
    · exact ih (n+1) (fun g hg => legal g (List.mem_cons_of_mem _ hg)) a h

theorem price (n : Nat) (gs : List Gate) :
    ((phase n gs).filter CircuitCompiler.orFlag).length = gs.countP countsAnd := by
  induction gs generalizing n with
  | nil => rfl
  | cons q qs ih =>
    obtain ⟨op,ins⟩ := q
    cases op <;> simp [phase,dual,swapOp,CircuitCompiler.orFlag,countsAnd,List.countP_cons,List.filter_cons,ih]

end PEqualNP.Outside.L_meta_9822.Sectors.DualPhysical
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.DualPhysical.phase_eval
