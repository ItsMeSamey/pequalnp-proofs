import PairAndOwner9822
import PairSymmetricReads9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
private theorem both_pins {xs : List Nat} {i j : Nat} (len : xs.length≤2)
    (ne : i≠j) (a : i∈xs) (b : j∈xs) : xs=[i,j] ∨ xs=[j,i] := by
  rcases xs with _|⟨u,_|⟨v,_|⟨w,tail⟩⟩⟩ <;> simp_all <;> grind
theorem two_external_ands {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (minimal : Reduced 10 C.gates C.output) (seven : 7 ≤ C.gates.countP countsAnd)
    (s t : Fin 10) (st : s≠t) (sl : 5≤s.val) (su : s.val≤8)
    (tl : 5≤t.val) (tu : t.val≤8) (guard : ∀ v : Input, innerValue pre g v=(v s || v t))
    (p tail : List Gate) (physical : C.gates=p++literalGate s t::tail)
    (invpin : g.inputs=[10+p.length]) :
    ∃ a∈C.gates,∃ b∈C.gates,a≠b ∧ a.op=.and ∧ b.op=.and ∧
        s.val∈a.inputs ∧ t.val∈b.inputs := by
  have guards : ∀ v : Input, innerValue pre g v=(v t || v s) := by
    intro v; rw [guard,Bool.or_comm]
  obtain ⟨a,am,ao,ar⟩ := external_and_owner r cand minimal seven s t st sl su guard p tail physical invpin
  have sep (i j : Fin 10) (ij : i≠j) (il : (5 : Nat) ≤ Fin.val i) (iu : Fin.val i ≤ (8 : Nat))
      (gg : ∀ v : Input,innerValue pre g v=(v i || v j)) (owner : i=s ∨ i=t) :
      ∀ (q : Gate), q∈C.gates → i.val∈q.inputs → q≠literalGate s t → q.op=.and := by
    intro q mem pin neq
    have ext : q∈p++tail := by rw [physical] at mem; simpa [List.mem_append,neq] using mem
    have pos : PositiveOp q := by
      rw [r.split] at mem
      have ng : q≠g := by rintro rfl; rw [invpin,List.mem_singleton] at pin;omega
      exact r.pos q (by simpa [List.mem_append,ng] using mem)
    rcases pos with h|h
    · exact h
    · have cap := one_true_physical_or r cand minimal seven i j il iu gg
      let w := List.ofFn (SignedClamp.singleton i)
      let u := wiresFrom p w
      have ilt : i.val<u.length := by simp [u,w,length_wiresFrom];omega
      have ihot : u.getD i.val false=true := by
        dsimp [u];rw [getD_wiresFrom _ _ _ (by simp [w]),getD_ofFn 10 _ false i];simp [SignedClamp.singleton]
      have lit : (literalGate s t).op.eval ((literalGate s t).inputs.map fun k => u.getD k false)=true := by
        change (u.getD s.val false || (u.getD t.val false || false))=true
        rcases owner with e|e <;> subst i <;> rw [ihot] <;> simp
      rw [physical,GuardTags.physicalHot_append] at cap
      change GuardTags.physicalHot p w + (GuardTags.physicalHot tail (u++[_]) + (FreeAndNet.CircuitCompiler.orFlag _ && _).toNat) ≤ 1 at cap
      rw [lit] at cap
      change GuardTags.physicalHot p w + (GuardTags.physicalHot tail (u++[true]) + 1) ≤ 1 at cap
      have early := readers_hot p w i.val (by simp [w]) ((getD_ofFn 10 _ false i).trans (by simp [SignedClamp.singleton]))
      have late := readers_hot tail (u++[true]) i.val (by simp;omega)
        (by rwa [List.getD_append _ _ _ _ ilt])
      have hit : readsOr i.val q=true := by simp [readsOr,FreeAndNet.CircuitCompiler.orFlag,h,pin]
      have n := List.countP_pos_iff.mpr ⟨q,ext,hit⟩
      rw [List.countP_append] at n
      omega
  have ma : a∈C.gates := by rw [physical];simpa only [List.mem_append,List.mem_cons] using
      (show a∈p ∨ a=literalGate s t ∨ a∈tail from (List.mem_append.mp am).imp_right Or.inr)
  obtain ⟨b,mb,br,bn⟩ := pair_raw_separation cand t s st.symm
  have nb : b≠literalGate s t := by rintro rfl;exact bn ⟨rfl,by simp [literalGate]⟩
  have bo := sep t s st.symm tl tu guards (Or.inr rfl) b mb br nb
  by_cases eq : a=b
  · subst b
    have layout := both_pins (cand.1 a ma).2 (fun e => st (Fin.ext e)) ar br
    obtain ⟨q,mq,owner,asym⟩ := asymmetric_owner cand s t st
    have nq : q≠literalGate s t := by rintro rfl;exact asym ⟨Or.inl rfl,Or.inl rfl⟩
    have na : q≠a := by rintro rfl;exact asym ⟨Or.inr ao,layout⟩
    rcases owner with qr|qr
    · exact ⟨q,mq,a,ma,na,sep s t st sl su guard (Or.inl rfl) q mq qr nq,ao,qr,br⟩
    · exact ⟨a,ma,q,mq,na.symm,ao,sep t s st.symm tl tu guards (Or.inr rfl) q mq qr nq,ar,qr⟩
  · exact ⟨a,ma,b,mb,eq,ao,bo,ar,br⟩
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.two_external_ands
