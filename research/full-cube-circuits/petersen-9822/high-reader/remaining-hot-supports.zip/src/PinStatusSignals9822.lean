import PairPinStates9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean ReaderDebit
theorem frozen_value (C : Circuit) (cand : Candidate C) (S : Finset V) (i : Nat)
    (b : Bool) (pin : (foldZero C S).1.getD i (Sum.inl false)=Sum.inl b) (x : Input) :
    vl C.gates (masked S x) i=b := by
  have inv := inv_elim 10 (List.ofFn x) (by simp) C.gates _ _ cand.1 (pin_inv S x)
  have hr := (inv.2 i).2
  change ((foldZero C S).1.getD i _).val (wiresFrom (foldZero C S).2 (List.ofFn x)) = _ at hr
  rw [pin] at hr
  exact hr.symm

theorem site_status {C : Circuit} (cl : CleanL 10 C.gates) (S : Finset V)
    (k : Nat) (q : Gate) (site : C.gates[k]?=some q) :
    ∃ m, (foldZero C S).1.getD (10+k) (Sum.inl false)=
      (simplify q.op m (q.inputs.map fun j => (foldZero C S).1.getD j (Sum.inl false))).2 := by
  obtain ⟨p,r,sp,sz⟩ := split_at C.gates k q site
  let acc : List Stat × List Gate := (assignments S,[])
  have len : acc.1.length=10 := by simp [acc,assignments]
  have h := final_output_status 10 p r q acc
  have inp := final_inputs 10 p r q acc (by
    intro j hj
    have ij := (cl k q site).lt j hj
    omega)
  dsimp only at h inp
  rw [inp,len,←sp,sz] at h
  exact ⟨_,h⟩

theorem next_zero {C : Circuit} (cl : CleanL 10 C.gates) (S : Finset V)
    (k : Nat) (q : Gate) (site : C.gates[k]?=some q) (op : q.op=.and)
    (used : ∃ j∈q.inputs,(foldZero C S).1.getD j (Sum.inl false)=Sum.inl false) :
    (foldZero C S).1.getD (10+k) (Sum.inl false)=Sum.inl false := by
  obtain ⟨m,hm⟩ := site_status cl S k q site
  obtain ⟨j,mem,pin⟩ := used
  rcases cl k q site with ⟨no,_⟩|⟨_,a,b,_,_,ins⟩
  · simp_all
  rw [ins] at mem
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  let atWire := fun j => (foldZero C S).1.getD j (Sum.inl false)
  rw [hm,op,ins]
  change (simpAnd m [atWire a,atWire b]).2=Sum.inl false
  change atWire j=Sum.inl false at pin
  rcases mem with e|e
  · subst j; rw [pin]; cases h : atWire b <;> rfl
  · subst j; rw [pin]; cases h : atWire a with
    | inl b => cases b <;> rfl
    | inr i => rfl
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.next_zero
