import OR9822Base

namespace Research.OddOr
open FreeAndNet PEqualNP.CircuitLowerBounds

/-- Compiling a different observer of the same physical gate list preserves
all OR locations, with arbitrary differences allowed in the final product. -/
inductive SameTrace : {α : Type} → Net α → Net α → Prop
  | out {α : Type} (p q : Product α) : SameTrace (.out p) (.out q)
  | gate {α : Type} (a b : List α) {t u : Net (Option α)} (h : SameTrace t u) :
      SameTrace (.gate a b t) (.gate a b u)

theorem compile_trace (p q : Nat) (gs : List Gate) {α : Type} (w : List (Product α)) :
    SameTrace (CircuitCompiler.run p gs w) (CircuitCompiler.run q gs w) := by
  induction gs generalizing α with
  | nil => exact SameTrace.out _ _
  | cons g gs ih =>
    simp only [CircuitCompiler.run]
    split
    next h =>
      generalize w.getD (g.inputs.getD 0 w.length) none = a
      generalize w.getD (g.inputs.getD 1 w.length) none = b
      cases a <;> cases b <;> first | apply SameTrace.gate; apply ih | apply ih
    next h => apply ih

theorem trace_specialize {α β : Type} {t u : Net α} (h : SameTrace t u) (s : α → Product β) :
    SameTrace (specialize s t) (specialize s u) := by
  induction h generalizing β with
  | out => exact SameTrace.out _ _
  | gate a b h ih =>
    unfold specialize
    generalize substProduct s a = p
    generalize substProduct s b = q
    cases p <;> cases q <;> first | apply SameTrace.gate; apply ih | apply ih

theorem trace_count {α : Type} {t u : Net α} (h : SameTrace t u) (v : α → Bool) :
    hotCount v t = hotCount v u := by
  induction h with
  | out => rfl
  | gate a b h ih => simp only [hotCount,ih]

/-- On an assignment where no OR fires, acceptance is closed under
intersection with a second accepting assignment. -/
theorem intersection_when_cold {α : Type} (t : Net α) (a b c : α → Bool)
    (inf : ∀ i, a i = true → b i = true → c i = true)
    (cold : hotCount a t = 0) (left : t.eval a = true) (right : t.eval b = true) :
    t.eval c = true := by
  induction t with
  | out p =>
    cases p with
    | none => exact left
    | some xs =>
      change xs.all a = true at left
      change xs.all b = true at right
      change xs.all c = true
      simp only [List.all_eq_true] at left right ⊢
      exact fun i hi => inf i (left i hi) (right i hi)
  | gate p q tail ih =>
    have count := Nat.add_eq_zero.mp cold
    have hzero : (p.all a || q.all a) = false := by
      cases e : (p.all a || q.all a) <;> simp_all
    apply ih _ _ _ _ count.1 left right
    intro v
    cases v with
    | none => simp [hzero]
    | some i => exact inf i

end Research.OddOr
#print axioms Research.OddOr.intersection_when_cold
