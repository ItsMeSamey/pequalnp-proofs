import ColdObserver9822
import ColdFirstArms9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds
open SignedClamp NonrawSupport OuterNet FreeAndNet Research.OddOr
open Research.OddOr.Envelope Research.OddOr.Graph9822
private theorem upper_pin_open (i : Fin 10) (t : Net (Fin 11)) (x : Input) (zero : x i=false) :
    (specialize (close true) (pin i.succ t)).eval x = t.eval (env x true) := by
  unfold pin
  rw [eval_specialize,close_eval,eval_specialize]
  congr 1
  funext j
  by_cases eq : j=i.succ
  · subst j; simp [kill,pval,env,zero]
  · simp [kill,eq,pval]

theorem upper_off_hits {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10) (cold : ∀ j, i≠j → outerValue pre post C.output (SignedClamp.singleton j) true=false) : hits i.succ (model pre post C.output) ≤ 1 := by
  let t := model pre post C.output
  let u := specialize (close true) (pin i.succ t)
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have read (s : Finset (Fin 10)) (no : i∉s) :
      sees u s = outerValue pre post C.output (inputOn s) true :=
    (upper_pin_open i t (inputOn s) (by simp [inputOn,no])).trans (model_eval r cand _ _)
  have off : ColdOff i u := by
    constructor
    · intro j no
      rw [read _ (by simpa [eq_comm] using no)]
      have eq : inputOn {j}=SignedClamp.singleton j := by funext k; simp [inputOn,SignedClamp.singleton]
      rw [eq]; exact cold j no
    · intro j k nj nk on
      rw [read _ (by simp [eq_comm,nj,nk])]
      exact positive_upper cut _ on
  have floor := eight_off i u off
  have upper : u.cost ≤ (pin i.succ t).cost := specialize_cost _ _
  have saving := pin_cost i.succ t
  have cap : t.cost ≤ 9 := (model_cost r).trans (or_cap r cand seven)
  change hits i.succ t ≤ 1
  omega

theorem upper_price {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (cold : ∀ j,outerValue pre post C.output (SignedClamp.singleton j) true=false)
    (t : Net (Fin 11)) (exactOn : ∀ x : Input,t.eval (env x true)=outerValue pre post C.output x true) : 9 ≤ t.cost := by
  let u := specialize (close true) t
  have read (s : Finset (Fin 10)) : sees u s = outerValue pre post C.output (inputOn s) true := by
    change (specialize _ _).eval _ = _
    rw [eval_specialize,close_eval]
    exact exactOn _
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  apply (nine_if_cold u ?_ ?_).trans (specialize_cost _ _)
  · intro i
    rw [read]
    have eq : inputOn {i} = SignedClamp.singleton i := by funext j; simp [inputOn,SignedClamp.singleton]
    rw [eq]
    exact cold i
  · intro i j yes; rw [read]; exact positive_upper cut _ yes

theorem upper_first_incomparable {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (cold : ∀ j,outerValue pre post C.output (SignedClamp.singleton j) true=false)
    {a b : List (Fin 11)} {tail : Net (Option (Fin 11))}
    (head : model pre post C.output=.gate a b tail) :
    ¬ a.toFinset ⊆ b.toFinset ∧ ¬ b.toFinset ⊆ a.toFinset := by
  have cap := (model_cost r).trans (or_cap r cand seven)
  rw [head] at cap
  change tail.cost + 1 ≤ 9 at cap
  have impossible (p : List (Fin 11)) (absorbs : ∀ v : Fin 11 → Bool,(a.all v || b.all v)=p.all v) : False := by
    let sub : Option (Fin 11) → Product (Fin 11) := fun z => z.elim (some p) (fun j => some [j])
    let t := specialize sub tail
    have read (x : Input) : t.eval (env x true)=outerValue pre post C.output x true := by
      rw [← model_eval r cand,head]
      change (specialize sub tail).eval _ = _
      rw [eval_specialize,Net.eval]
      congr 1
      funext j
      cases j <;> simp [sub,pval,absorbs]
    have lower := upper_price r cand cold t read
    have bound : t.cost ≤ tail.cost := specialize_cost _ _
    omega
  have allSub (p q : List (Fin 11)) (sub : p.toFinset ⊆ q.toFinset) (v : Fin 11 → Bool) :
      q.all v=true → p.all v=true := by
    intro on
    exact List.all_eq_true.mpr (fun i hi => List.all_eq_true.mp on i (by simpa using sub (by simpa using hi)))
  constructor
  · intro sub
    apply impossible a
    intro v
    have h := allSub a b sub v
    cases ha : a.all v <;> cases hb : b.all v <;> simp_all
  · intro sub
    apply impossible b
    intro v
    have h := allSub b a sub v
    cases ha : a.all v <;> cases hb : b.all v <;> simp_all
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
