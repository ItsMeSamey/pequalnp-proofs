import GuardEmitterStep9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
open PEqualNP.CircuitLowerBounds GuardTags
def firstCharge (op : GateOp) (a b : Reg) : Nat :=
  match op with
  | .or => (a.1 || b.1).toNat
  | _ => 0
private theorem grouped_cost (n z : Nat) (a b : Reg) :
    (grouped n z a b).code.length ≤ 2 := by
  let p := one n .or a.2 b.2
  have h := one_cost n .or a.2 b.2
  have h' := one_cost (n+p.code.length) .and (Sum.inr z) p.result
  change (p.code ++ (one (n+p.code.length) .and (Sum.inr z) p.result).code).length ≤ _
  rw [List.length_append]
  change p.code.length ≤ _ at h
  omega
theorem site_cost (n z : Nat) (op : GateOp) (ok : op=.and ∨ op=.or) (a b : Reg) :
    (actual n z op a b).2.code.length ≤ 1 + firstCharge op a b := by
  rcases ok with rfl | rfl
  · exact one_cost _ _ _ _
  · obtain ⟨fa,x⟩ := a
    obtain ⟨fb,y⟩ := b
    cases fa <;> cases fb
    · exact pair_cost n z _ _
    · exact pair_cost n z _ _
    · exact pair_cost n z _ _
    · exact grouped_cost n z _ _
private theorem or_top_left (n : Nat) (v : Stat) :
    one n .or top v = pureReg top := by cases v <;> rfl
private theorem or_top_right (n : Nat) (v : Stat) :
    one n .or v top = pureReg top := by cases v with
    | inl b => cases b <;> rfl
    | inr i => rfl
theorem direct_cost (n z : Nat) (op : GateOp) (ok : op=.and ∨ op=.or)
    (a b : Reg) (src : a=(true,top) ∨ b=(true,top)) :
    (actual n z op a b).2.code.length ≤ firstCharge op a b := by
  rcases ok with rfl|rfl
  · rcases src with rfl|rfl
    · simp [firstCharge,actual,and_top_left]
    · simp [firstCharge,actual,and_top_right]
  · rcases src with rfl|rfl
    · obtain ⟨f,x⟩ := b
      cases f
      · exact one_cost _ _ _ _
      · cases x with
        | inl c => cases c <;> exact Nat.zero_le _
        | inr i => exact Nat.zero_le _
    · obtain ⟨f,x⟩ := a
      cases f
      · exact one_cost _ _ _ _
      · cases x with
        | inl c => cases c <;> exact Nat.zero_le _
        | inr i => exact Nat.zero_le _
theorem actual_good (op : GateOp) (ok : op=.and ∨ op=.or) (w : List Bool)
    (z : Nat) (hz : z<w.length) (a b : Reg) (ha : a.2.Valid w.length) (hb : b.2.Valid w.length) :
    Good w (actual w.length z op a b).2
      (emit (w.getD z false) op [meaning w a,meaning w b]).2 ∧
    (actual w.length z op a b).1 = (emit (w.getD z false) op [meaning w a,meaning w b]).1 := by
  rcases ok with rfl | rfl
  · refine ⟨?_,by simp [actual,emit,atAnd,meaning]⟩
    simpa [actual,emit,meaning,atAnd,GateOp.eval] using one_good .and (Or.inl rfl) w a.2 b.2 ha hb
  · obtain ⟨f,x⟩ := a
    obtain ⟨g,y⟩ := b
    cases f <;> cases g <;> refine ⟨?_,rfl⟩
    · simpa [actual,emit,atOR] using pair_good w z hz (false,x) (false,y) ha hb
    · simpa [actual,emit,atOR] using pair_good w z hz (false,x) (true,y) ha hb
    · simpa [actual,emit,atOR] using pair_good w z hz (true,x) (false,y) ha hb
    · have dist : ∀ a b z : Bool, (z && (a || b)) = ((a && z) || (b && z)) := by decide
      simpa [actual,emit,atOR,meaning,recover,dist] using grouped_good w z hz (true,x) (true,y) ha hb
end PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter.direct_cost
