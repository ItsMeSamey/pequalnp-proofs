import TwoWireMask9822
import PhysicalNormalBundle9822
import PairSignalRelations9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem masked_cut_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (s t : Fin 10) (p tail : List Gate)
    (physical : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length])
    (ord : p.length<pre.length) (rk : Nat)
    (nz : C.output≠10+pre.length) (nr : C.output≠10+rk)
    (only : ∀ (j : Nat) (q : Gate),post[j]?=some q → 10+pre.length∈q.inputs → pre.length+1+j=rk)
    (mask : ∀ (j : Nat) (q : Gate),post[j]?=some q → 10+rk∈q.inputs → q.op=.and ∧
      ∃ i∈q.inputs,i∈({s.val,t.val,10+p.length} : Finset Nat)) : False := by
  have nonconst : ∃ x y : Input, vl (pre++g::post) x C.output≠vl (pre++g::post) y C.output := by
    refine ⟨fun _ => false,fun _ => true,?_⟩
    rw [←r.split]
    exact fun e => Bool.noConfusion ((cand.2.2 (fun _ => false)).symm.trans
      (e.trans (cand.2.2 (fun _ => true))))
  obtain ⟨x,change,_⟩ := (r.split ▸ red).essentialCut nonconst false
  let w := wiresFrom pre (List.ofFn x)
  have len : w.length=10+pre.length := by simp [w,length_wiresFrom]
  have pair := pair_physical_values r red.clean s t p tail physical unary x
  have orig : vl (pre++g::post) x C.output =
      (wiresFrom post (w++[!(x s || x t)])).getD C.output false := by
    unfold vl
    rw [wiresFrom_append]
    change (wiresFrom post (w++[_])).getD _ _ = _
    congr 2
    have guard : w.getD (10+p.length) false=(x s||x t) := by
      have hv := pair.1
      unfold vl at hv
      rw [r.split,wiresFrom_append] at hv
      change (wiresFrom (g::post) w).getD (10+p.length) false = _ at hv
      rwa [getD_wiresFrom _ _ _ (by omega : 10+p.length<w.length)] at hv
    simp [r.inv,unary,GateOp.eval]
    exact guard
  rw [orig] at change
  change (wiresFrom post (w++[false])).getD C.output false≠_ at change
  cases sx : x s <;> cases tx : x t <;> simp only [sx,tx,Bool.false_or,Bool.true_or,Bool.not_true,Bool.not_false] at change
  all_goals try exact change rfl
  apply change
  apply two_wire_mask post (w++[false]) (w++[true]) (10+pre.length) (10+rk) {s.val,t.val,10+p.length}
  · simp
  · intro j q h pin
    have h' := only j q h pin
    simp;omega
  · exact mask
  · intro i mem
    have ri : i<w.length := by simp only [Finset.mem_insert,Finset.mem_singleton] at mem; rcases mem with rfl|rfl|rfl <;> omega
    have cold : w.getD i false=false := by
      simp only [Finset.mem_insert,Finset.mem_singleton] at mem
      have raw (v : Fin 10) : w.getD v.val false=x v := by
        dsimp [w]; rw [getD_wiresFrom _ _ _ (by simp),getD_ofFn 10 x false v]
      rcases mem with rfl|rfl|rfl
      · exact (raw s).trans sx
      · exact (raw t).trans tx
      · have h := pair.1
        unfold vl at h
        rw [r.split,wiresFrom_append] at h
        change (wiresFrom (g::post) w).getD _ _ = _ at h
        rw [getD_wiresFrom _ _ _ ri,sx,tx] at h
        exact h
    exact ⟨by simp;omega,by rwa [List.getD_append _ _ _ _ ri],by rwa [List.getD_append _ _ _ _ ri]⟩
  · intro i ne _
    rw [getD_snoc_ne _ _ _ _ (by omega),getD_snoc_ne _ _ _ _ (by omega)]
  · exact nz
  · exact nr
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.masked_cut_impossible
