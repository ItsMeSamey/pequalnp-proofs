import ColdRawHits9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr
open SignedClamp NonrawSupport OuterNet Research.OddOr.Graph9822 Research.OddOr.Envelope

theorem cold_upper_price {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (cold : ∀ j,innerValue pre g (SignedClamp.singleton j)=false)
    (t : Net (Fin 11)) (exactOn : ∀ x : Input,t.eval (env x true)=outerValue pre post C.output x true) : 9 ≤ t.cost := by
  let u := specialize (close true) t
  have read (s : Finset (Fin 10)) : sees u s = outerValue pre post C.output (inputOn s) true := by
    change (specialize _ _).eval _ = _
    rw [eval_specialize,close_eval]
    exact exactOn _
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  apply (nine_if_cold u ?_ ?_).trans (specialize_cost _ _)
  · intro i
    rw [read]
    have eq : inputOn {i} = SignedClamp.singleton i := by funext j; simp [inputOn,SignedClamp.singleton]
    rw [eq]
    have ok := cut.computes (SignedClamp.singleton i)
    rw [cold] at ok
    exact ok.trans (singleton_zero i)
  · intro i j yes; rw [read]; exact positive_upper cut _ yes

theorem cold_first_incomparable {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (cold : ∀ j,innerValue pre g (SignedClamp.singleton j)=false)
    {a b : List (Fin 11)} {tail : Net (Option (Fin 11))}
    (head : model pre post C.output=.gate a b tail) :
    ¬ a.toFinset ⊆ b.toFinset ∧ ¬ b.toFinset ⊆ a.toFinset := by
  have cap := (model_cost r).trans (or_cap r cand seven)
  rw [head] at cap
  change tail.cost + 1 ≤ 9 at cap
  have impossible (p : List (Fin 11)) (absorbs : ∀ v : Fin 11 → Bool,(a.all v || b.all v)=p.all v) : False := by
    let sub : Option (Fin 11) → Product (Fin 11) := fun z => z.elim (some p) (fun j => some [j])
    let t := specialize sub tail
    have read (x : Input) : t.eval (env x true)=outerValue pre post C.output x true := by
      rw [← model_eval r cand,head]
      change (specialize sub tail).eval _ = _
      rw [eval_specialize,Net.eval]
      congr 1
      funext j
      cases j <;> simp [sub,pval,absorbs]
    have lower := cold_upper_price r cand cold t read
    have bound : t.cost ≤ tail.cost := specialize_cost _ _
    omega
  have allSub (p q : List (Fin 11)) (sub : p.toFinset ⊆ q.toFinset) (v : Fin 11 → Bool) :
      q.all v=true → p.all v=true := by
    intro on
    exact List.all_eq_true.mpr (fun i hi => List.all_eq_true.mp on i (by simpa using sub (by simpa using hi)))
  constructor
  · intro sub
    apply impossible a
    intro v
    have h := allSub a b sub v
    cases ha : a.all v <;> cases hb : b.all v <;> simp_all
  · intro sub
    apply impossible b
    intro v
    have h := allSub b a sub v
    cases ha : a.all v <;> cases hb : b.all v <;> simp_all
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.cold_first_incomparable
