import Std

namespace Research.Graph9822.P4Guard

/-- Probe order: empty, four singletons a,b,c,d, then ab,bc,cd. -/
abbrev Mask := BitVec 8
def raws : List Mask := [34,100,200,144]
def goal : Mask := 224
def hot (m : Mask) : Bool := (m &&& 19) == 18
def extend (B : List Mask) (m : Mask) := (B ++ B.map (· &&& m)).eraseDups
def base : List Mask := raws.foldl extend [255,0]
def joins (B : List Mask) := (B.flatMap fun a => B.map (a ||| ·)).eraseDups

/-- In a meet-closed bank, a new conjunction with the second union b
cannot be singleton-hot unless b or an earlier nonconstant gate is so. -/
def badAt (a : Mask) : Bool :=
  let before := extend base a
  (joins before).any fun b =>
    (hot a || hot b) && (before.contains goal || before.any (fun c => (c &&& b) == goal))

theorem chamber_empty : (joins base).any badAt = false := by decide +kernel
theorem no_hot_history {a b c : Mask} (ha : a ∈ joins base)
    (hb : b ∈ joins (extend base a)) (hc : c ∈ extend base a)
    (out : c = goal ∨ c &&& b = goal) : hot a = false ∧ hot b = false := by
  have denied := List.any_eq_false.mp chamber_empty a ha
  have reject : badAt a = false := by cases h : badAt a <;> simp_all
  unfold badAt at reject
  have deniedB := List.any_eq_false.mp reject b hb
  have hg : ((extend base a).contains goal || (extend base a).any (fun f => (f &&& b) == goal)) = true := by
    cases out with
    | inl e => subst c; simp [hc]
    | inr e => simpa using (Or.inr ⟨c,hc,e⟩ : goal ∈ extend base a ∨ ∃ x ∈ extend base a, x &&& b = goal)
  change ¬ ((hot a || hot b) && _) = true at deniedB
  cases aa : hot a <;> cases bb : hot b <;> simp_all

end Research.Graph9822.P4Guard
