import PhysicalSignedClamp9822
import CleanCompile9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open PEqualNP.CircuitLowerBounds
open PEqualNP.Outside.L_meta_9822.Clean

theorem packed_inputs_mono {x y : Input} (h : ∀ j, x j = true → y j = true) :
    WireLE (List.ofFn x) (List.ofFn y) := by
  refine ⟨by simp, ?_⟩
  intro j
  by_cases small : j < 10
  · have hx : (List.ofFn x).getD j false = x ⟨j,small⟩ :=
      getD_ofFn 10 x false ⟨j,small⟩
    have hy : (List.ofFn y).getD j false = y ⟨j,small⟩ :=
      getD_ofFn 10 y false ⟨j,small⟩
    rw [hx,hy]
    exact h _
  · have hz : (List.ofFn x).getD j false = false :=
      List.getD_eq_default _ _ (by simp; omega)
    rw [hz]
    intro impossible
    contradiction

theorem outer_mono_inputs {pre tail : List Gate}
    (hp : ∀ g ∈ pre, PositiveOp g) (ht : ∀ g ∈ tail, PositiveOp g)
    (out : Nat) (z : Bool) :
    ∀ x y : Input, (∀ j, x j = true → y j = true) →
      outerValue pre tail out x z = true → outerValue pre tail out y z = true := by
  intro x y h
  exact (phase_mono tail ht (wireLE_snoc
    (phase_mono pre hp (packed_inputs_mono h)) (fun hh => hh))).2 out

theorem inner_mono_inputs {pre : List Gate} (hp : ∀ g ∈ pre, PositiveOp g)
    (g : Gate) {x y : Input} (h : ∀ j, x j = true → y j = true) :
    innerValue pre g x = true → innerValue pre g y = true := by
  cases hi : g.inputs with
  | nil => simp [innerValue,hi]
  | cons j js =>
    simpa [innerValue,hi] using (phase_mono pre hp (packed_inputs_mono h)).2 j

end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
