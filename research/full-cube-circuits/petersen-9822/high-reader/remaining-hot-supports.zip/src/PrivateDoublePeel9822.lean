import PrivateFoldRun9822
import PairRisingGate9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp AdjacentCut PEqualNP.Outside.L_meta_9822.Clean
open scoped Classical
theorem single_peel_witness (a b : V) (ne : a≠b) (f : Input→Bool)
    (hot : ∀x, x b=false → edge x=true → f x=true)
    (cold : ∀x, x a=false → x b=false → f x=edge x) :
    ∃x y : Input,(∀ i,i≠a → x i=y i) ∧ f x=false ∧ f y=true := by
  obtain ⟨i,h0,h1⟩ := exclusive_positive a b ne
  let x := setOwners a b (SignedClamp.singleton i) false false
  let y := setOwners a b (SignedClamp.singleton i) true false
  refine ⟨x,y,fun j h => by simp [x,y,setOwners,h],?_,?_⟩
  · exact (cold x (by simp [x,setOwners]) (by simp [x,setOwners,ne.symm])).trans h0
  · exact hot y (by simp [y,setOwners,ne.symm]) h1
theorem mask_eq {x : Input} (s : V) (off : x s=false) : masked {s} x=x := by
  funext i
  by_cases h : i=s
  · subst i; simp [masked,off]
  · simp [masked,h]
theorem mask_pair (s t : V) (x : Input) : masked {s} (masked {t} x)=masked {s,t} x := by
  funext i
  by_cases a : i=s <;> by_cases b : i=t <;> simp [masked,a,b]
theorem double_peel (C : Circuit) (cl : CleanL 10 C.gates) (pos : ∀q∈C.gates,PositiveOp q)
    (s t : V) (ne : s≠t) (hot : ∀x : Input,edge x=true → vl C.gates x C.output=true)
    (cold : ∀x : Input,x s=false → x t=false → vl C.gates x C.output=edge x) :
    ∃D : Circuit,CleanL 10 D.gates ∧ (∀q∈D.gates,PositiveOp q) ∧
      D.gates.countP (ofOp .or)+2≤C.gates.countP (ofOp .or) ∧
      (∀x : Input,vl D.gates x D.output=edge (masked {s,t} x)) ∧
      ∀ j,(∃x y : Input,vl C.gates (masked {s,t} x) j≠vl C.gates (masked {s,t} y) j) →
        ∃i,∀x : Input,vl D.gates x i=vl C.gates (masked {s,t} x) j := by
  let v : Input := masked {s,t} (fun _ => true)
  have vs : v s=false := by simp [v,masked]
  have vt : v t=false := by simp [v,masked]
  have on := hot v (positive_off_two s t)
  obtain ⟨x,y,eq,x0,y1⟩ := single_peel_witness s t ne _ (fun x _ => hot x) cold
  have d1 := monotone_physical_peel C cl pos s x y v eq ⟨x0,y1⟩ (by rwa [mask_eq s vs])
  have v0 : vl C.gates (fun _ => false) C.output=false := (cold _ rfl rfl).trans (by decide)
  have zero (a : V) : masked {a} (fun _ => false)=(fun _ => false) := mask_eq a rfl
  obtain ⟨o,cl1,pos1,ev1,obs1⟩ := fold_run C cl pos {s} ⟨_,v,by rw [zero,mask_eq s vs,v0,on];decide⟩
  let D : Circuit := ⟨(foldZero C {s}).2,o⟩
  have hg (x : Input) (hs : x s=false) (e : edge x=true) : vl D.gates x D.output=true :=
    (ev1 x).trans (by rw [mask_eq s hs];exact hot x e)
  have cg (x : Input) (ht : x t=false) (hs : x s=false) : vl D.gates x D.output=edge x :=
    (ev1 x).trans (by rw [mask_eq s hs];exact cold x hs ht)
  obtain ⟨u,w,eq2,u0,w1⟩ := single_peel_witness t s ne.symm _ hg cg
  have yO := hg v vs (positive_off_two s t)
  have xO := (cg (fun _ => false) rfl rfl).trans (by decide : edge (fun _ => false)=false)
  have d2 := monotone_physical_peel D cl1 pos1 t u w v eq2 ⟨u0,w1⟩ (by rwa [mask_eq t vt])
  obtain ⟨last,cl2,pos2,ev2,obs2⟩ := fold_run D cl1 pos1 {t} ⟨_,v,by rw [zero,mask_eq t vt,xO,yO];decide⟩
  refine ⟨⟨_,last⟩,cl2,pos2,?_,?_,?_⟩
  · change (foldZero D {t}).2.countP (ofOp .or)+2≤_
    change D.gates.countP (ofOp .or)+1≤C.gates.countP (ofOp .or) at d1
    change (foldZero D {t}).2.countP (ofOp .or)+1≤D.gates.countP (ofOp .or) at d2
    omega
  · intro z
    exact (ev2 z).trans ((ev1 _).trans (by rw [mask_pair]; exact cold _ (by simp [masked]) (by simp [masked])))
  · intro j var
    obtain ⟨a,b,diff⟩ := var
    obtain ⟨i,ei⟩ := obs1 j ⟨masked {t} a,masked {t} b,by simpa only [mask_pair] using diff⟩
    have back (z : Input) : vl D.gates (masked {t} z) i=vl C.gates (masked {s,t} z) j := by
      simpa only [mask_pair] using ei (masked {t} z)
    obtain ⟨k,ek⟩ := obs2 i ⟨a,b,by rw [back,back];exact diff⟩
    exact ⟨k,fun z => (ek z).trans (back z)⟩
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.double_peel
