import FinalPinDebit9822
import PhysicalDeletion9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean ReaderDebit
open scoped Classical
abbrev EAcc := List Stat × List Gate
def appendConst (b : Bool) (a : EAcc) : EAcc := (a.1++[Sum.inl b],a.2)
def clampPre (p mid : List Gate) : EAcc :=
  elim 10 mid (appendConst false (elim 10 p (assignments ∅,[])))
def clampOut (p mid post : List Gate) : EAcc :=
  elim 10 post (appendConst true (clampPre p mid))
noncomputable def ofOp (op : GateOp) (w : Gate) := decide (w.op=op)
theorem elim_kind_bound (gs : List Gate) (a : EAcc) (kind : GateOp) :
    (elim 10 gs a).2.countP (ofOp kind) ≤ a.2.countP (ofOp kind)+gs.countP (ofOp kind) := by
  induction gs generalizing a with
  | nil => simp [elim]
  | cons g rest ih =>
    let em := (simplify g.op (10+a.2.length) (g.inputs.map fun i => a.1.getD i (Sum.inl false))).1
    have bound := ih (elimStep 10 a g)
    have eq : (elimStep 10 a g).2.countP (ofOp kind)=a.2.countP (ofOp kind)+em.toList.countP (ofOp kind) :=
      List.countP_append ..
    change (elim 10 rest (elimStep 10 a g)).2.countP _ ≤ _+_ at bound ⊢
    by_cases o : g.op=kind
    · have one : ofOp kind g=true := by simp [ofOp,o]
      have small : em.toList.countP (ofOp kind)≤1 := (List.countP_le_length ..).trans (toList_length_le em)
      rw [List.countP_cons_of_pos one]
      omega
    · have no : ofOp kind g≠true := by simpa [ofOp] using o
      have empty : em.toList.countP (ofOp kind)=0 := by
        apply List.countP_eq_zero.mpr
        intro q mem hit
        have e := same_kind g.op (10+a.2.length) _ q (Option.mem_toList.mp mem)
        exact o (e.symm.trans (of_decide_eq_true hit))
      rw [List.countP_cons_of_neg no]
      omega
theorem clamp_ledger (p mid post : List Gate) (kind : GateOp) (mark : Gate → Bool)
    (clean : CleanL (appendConst true (clampPre p mid)).1.length post)
    (reads : ∀ q∈post, mark q=true → q.op=kind ∧ (clampPre p mid).1.length∈q.inputs) :
    (clampOut p mid post).2.countP (ofOp kind)+post.countP mark ≤
      p.countP (ofOp kind)+mid.countP (ofOp kind)+post.countP (ofOp kind) := by
  let a := clampPre p mid
  let k := a.1.length
  have hot : (clampOut p mid post).1.getD k (Sum.inl false)=Sum.inl true := by
    rw [clampOut,final_get 10 post (appendConst true a) k (by simp [k,appendConst])]
    exact getD_snoc_eq _ _ _
  have c := final_pin_debit 10 kind mark post (appendConst true a) clean (by
    intro q m flag
    obtain ⟨o,hit⟩ := reads q m flag
    exact ⟨o,k,hit,true,hot⟩)
  have b := elim_kind_bound mid (appendConst false (elim 10 p (assignments ∅,[]))) kind
  have d := elim_kind_bound p (assignments ∅,[]) kind
  change (clampOut p mid post).2.countP (ofOp kind)+post.countP mark ≤ a.2.countP (ofOp kind)+post.countP (ofOp kind) at c
  change a.2.countP (ofOp kind)≤(elim 10 p (assignments ∅,[])).2.countP (ofOp kind)+_ at b
  simp only [List.countP_nil,zero_add] at d
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.clamp_ledger
