import OR9822Classification
import OR9822Cofactors

/- BEGIN OR9822Theta145Floor.lean -/
namespace Research.OddOr
open FreeAndNet Theta
namespace Theta145
abbrev I := Fin 7
def target (x : Row I) : Bool :=
  (x.l && x.r) || (x.l && (x.raw 0)) || ((x.raw 0) && (x.raw 1)) || ((x.raw 1) && (x.raw 2)) || ((x.raw 2) && x.r) || (x.l && (x.raw 3)) || ((x.raw 3) && (x.raw 4)) || ((x.raw 4) && (x.raw 5)) || ((x.raw 5) && (x.raw 6)) || ((x.raw 6) && x.r)

def low (bits : Nat) : Row I := ⟨bits.testBit 0,bits.testBit 1,fun i => bits.testBit (i.val+2)⟩
def index (p : Tiny I) : Nat :=
  p.1.elim 0 (fun i => i.val+1) * 5 + match p.2 with
  | .unit => 0 | .left => 1 | .right => 2 | .both => 3 | .either => 4

private def witnessCode (p q : Tiny I) : Nat :=
  match index p with
  | 0 => #[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0].getD (index q) 0
  | 1 => #[0,0,0,0,0,7,0,7,0,7,120,0,29,0,29,65,0,58,0,58,10,0,10,0,10,907,0,228,0,228,460,0,453,0,453,909,0,902,0,902].getD (index q) 0
  | 2 => #[0,0,0,0,0,70,56,0,0,56,43,29,0,0,29,16,16,0,0,16,465,451,0,0,451,242,228,0,0,228,467,453,0,0,453,20,20,0,0,20].getD (index q) 0
  | 3 => #[0,0,0,0,0,0,56,7,0,56,1,29,29,0,29,2,16,58,0,58,3,451,10,0,451,4,228,228,0,228,5,453,453,0,453,6,20,902,0,902].getD (index q) 0
  | 4 => #[0,0,0,0,0,7,0,0,0,0,43,0,0,0,0,16,0,0,0,0,10,0,0,0,0,242,0,0,0,0,460,0,0,0,0,20,0,0,0,0].getD (index q) 0
  | 5 => #[0,7,70,0,7,0,0,0,0,0,56,63,70,29,63,119,119,44,16,119,280,451,10,10,451,455,455,228,228,455,903,903,453,453,903,1799,1799,48,20,1799].getD (index q) 0
  | 6 => #[0,0,56,56,0,0,0,0,0,0,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56].getD (index q) 0
  | 7 => #[0,7,0,7,0,0,0,0,0,0,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7].getD (index q) 0
  | 8 => #[0,0,0,0,0,0,0,0,0,0,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7].getD (index q) 0
  | 9 => #[0,7,56,56,0,0,0,0,0,0,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56,56].getD (index q) 0
  | 10 => #[0,120,43,1,43,29,56,43,7,43,1,1,1,1,1,113,120,58,16,120,253,66,10,10,66,477,228,228,228,228,925,453,453,453,453,1821,20,76,20,76].getD (index q) 0
  | 11 => #[0,0,29,29,0,29,29,29,29,29,1,1,1,1,1,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29].getD (index q) 0
  | 12 => #[0,29,0,29,0,29,29,29,29,29,1,1,1,1,1,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29].getD (index q) 0
  | 13 => #[0,0,0,0,0,29,29,29,29,29,1,1,1,1,1,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29].getD (index q) 0
  | 14 => #[0,29,29,29,0,29,29,29,29,29,1,1,1,1,1,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29,29].getD (index q) 0
  | 15 => #[0,65,16,2,16,44,56,44,7,44,58,65,72,29,65,2,2,2,2,2,240,122,240,10,240,464,228,464,228,464,912,453,912,453,912,1850,20,902,20,902].getD (index q) 0
  | 16 => #[0,0,16,16,0,16,16,16,16,16,16,16,16,16,16,2,2,2,2,2,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16].getD (index q) 0
  | 17 => #[0,58,0,58,0,44,58,44,58,44,58,58,58,58,58,2,2,2,2,2,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58].getD (index q) 0
  | 18 => #[0,0,0,0,0,16,16,16,16,16,16,16,16,16,16,2,2,2,2,2,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16].getD (index q) 0
  | 19 => #[0,58,16,58,0,44,58,44,58,44,58,58,58,58,58,2,2,2,2,2,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58,58].getD (index q) 0
  | 20 => #[0,10,465,3,10,479,56,7,7,56,66,66,29,29,66,122,122,58,16,122,3,3,3,3,3,451,458,465,228,458,906,906,453,453,906,1802,1802,244,20,1802].getD (index q) 0
  | 21 => #[0,0,451,451,0,451,451,451,451,451,66,66,451,451,66,122,122,451,451,122,3,3,3,3,3,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451].getD (index q) 0
  | 22 => #[0,10,0,10,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,3,3,3,3,3,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10].getD (index q) 0
  | 23 => #[0,0,0,0,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,3,3,3,3,3,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10].getD (index q) 0
  | 24 => #[0,10,451,451,0,451,451,451,451,451,66,66,451,451,66,122,122,451,451,122,3,3,3,3,3,451,451,451,451,451,451,451,451,451,451,451,451,451,451,451].getD (index q) 0
  | 25 => #[0,907,242,4,242,256,56,7,7,56,284,29,29,29,29,340,16,58,16,58,228,451,242,10,242,4,4,4,4,4,900,907,914,453,907,2020,20,468,20,468].getD (index q) 0
  | 26 => #[0,0,228,228,0,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,4,4,4,4,4,228,228,228,228,228,228,228,228,228,228].getD (index q) 0
  | 27 => #[0,228,0,228,0,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,4,4,4,4,4,228,228,228,228,228,228,228,228,228,228].getD (index q) 0
  | 28 => #[0,0,0,0,0,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,4,4,4,4,4,228,228,228,228,228,228,228,228,228,228].getD (index q) 0
  | 29 => #[0,228,228,228,0,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,228,4,4,4,4,4,228,228,228,228,228,228,228,228,228,228].getD (index q) 0
  | 30 => #[0,460,467,5,460,481,56,7,7,56,509,29,29,29,29,565,16,58,16,58,2021,451,10,10,451,453,460,467,228,460,5,5,5,5,5,1797,1804,902,20,1804].getD (index q) 0
  | 31 => #[0,0,453,453,0,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,5,5,5,5,5,453,453,453,453,453].getD (index q) 0
  | 32 => #[0,453,0,453,0,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,5,5,5,5,5,453,453,453,453,453].getD (index q) 0
  | 33 => #[0,0,0,0,0,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,5,5,5,5,5,453,453,453,453,453].getD (index q) 0
  | 34 => #[0,453,453,453,0,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,453,5,5,5,5,5,453,453,453,453,453].getD (index q) 0
  | 35 => #[0,909,20,6,20,48,56,48,7,48,76,29,76,29,76,1014,16,58,16,58,244,451,244,10,244,468,228,468,228,468,902,909,916,453,909,6,6,6,6,6].getD (index q) 0
  | 36 => #[0,0,20,20,0,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,6,6,6,6,6].getD (index q) 0
  | 37 => #[0,902,0,902,0,48,902,48,902,48,76,902,76,902,76,902,902,902,902,902,244,902,244,902,244,468,902,468,902,468,902,902,902,902,902,6,6,6,6,6].getD (index q) 0
  | 38 => #[0,0,0,0,0,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,6,6,6,6,6].getD (index q) 0
  | 39 => #[0,902,20,902,0,48,902,48,902,48,76,902,76,902,76,902,902,902,902,902,244,902,244,902,244,468,902,468,902,468,902,902,902,902,902,6,6,6,6,6].getD (index q) 0
  | _ => 0

private def pivotIndex (p q : Tiny I) : I := ⟨witnessCode p q % 7,Nat.mod_lt _ (by decide)⟩
private def pivotRow (p q : Tiny I) : Row I := low (witnessCode p q / 7)

set_option maxRecDepth 16000 in
private theorem cert0 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := (none,e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert1 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 0),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert2 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 1),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert3 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 2),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert4 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 3),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert5 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 4),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert6 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 5),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

set_option maxRecDepth 16000 in
private theorem cert7 : ∀ e : Ep, ∀ q : Tiny I,
    let p : Tiny I := ((some 6),e)
    Checked target true p q (pivotIndex p q) (pivotRow p q) := by decide +kernel

private theorem verified (p q : Tiny I) : ∃ i x, Checked target true p q i x := by
  refine ⟨pivotIndex p q,pivotRow p q,?_⟩
  obtain ⟨_ | i,e⟩ := p
  · exact cert0 e q
  · fin_cases i
    · exact cert1 e q
    · exact cert2 e q
    · exact cert3 e q
    · exact cert4 e q
    · exact cert5 e q
    · exact cert6 e q
    · exact cert7 e q

private def sparseLow (i j : I) : Row I :=
  low <| match i.val,j.val with
  | 0,0 => 1
  | 0,1 => 1
  | 0,2 => 1
  | 0,3 => 1
  | 0,4 => 1
  | 0,5 => 1
  | 0,6 => 1
  | 1,0 => 16
  | 1,1 => 4
  | 1,2 => 4
  | 1,3 => 4
  | 1,4 => 4
  | 1,5 => 4
  | 1,6 => 4
  | 2,0 => 8
  | 2,1 => 2
  | 2,2 => 8
  | 2,3 => 8
  | 2,4 => 8
  | 2,5 => 8
  | 2,6 => 8
  | 3,0 => 1
  | 3,1 => 1
  | 3,2 => 1
  | 3,3 => 1
  | 3,4 => 1
  | 3,5 => 1
  | 3,6 => 1
  | 4,0 => 32
  | 4,1 => 32
  | 4,2 => 32
  | 4,3 => 128
  | 4,4 => 32
  | 4,5 => 32
  | 4,6 => 32
  | 5,0 => 64
  | 5,1 => 64
  | 5,2 => 64
  | 5,3 => 64
  | 5,4 => 256
  | 5,5 => 64
  | 5,6 => 64
  | 6,0 => 128
  | 6,1 => 128
  | 6,2 => 128
  | 6,3 => 128
  | 6,4 => 128
  | 6,5 => 2
  | 6,6 => 128
  | _,_ => 0

private theorem sparseChecks : ∀ i j : I, i ≠ j →
    let x := sparseLow i j
    target x ≠ target (bump i x) ∧ x.raw j = false ∧ (bump i x).raw j = false := by decide +kernel

private theorem sparse : SparsePivot target := by
  intro i j ne
  exact ⟨sparseLow i j,bump i (sparseLow i j),bump_varies _ _,sparseChecks i j ne⟩

private theorem allPivots (i : I) : ∃ x y, VariesOnly i x y ∧ target x ≠ target y := by
  have other : ∀ z : I, ∃ j : I, z ≠ j := by decide
  obtain ⟨j,ne⟩ := other i
  obtain ⟨x,y,delta,diff,_,_⟩ := sparse i j ne
  exact ⟨x,y,delta,diff⟩

private def otherEdge (i : I) : Row I := low <| match i.val with
  | 0 => 3
  | 1 => 3
  | 2 => 3
  | 3 => 3
  | 4 => 3
  | 5 => 3
  | 6 => 3
  | _ => 0

private theorem residual (i : I) : ∃ z, z.raw i = false ∧ target z = true := by
  have h : ∀ i : I, (otherEdge i).raw i = false ∧ target (otherEdge i) = true := by decide
  exact ⟨_,h i⟩

private theorem census : ∀ a b : Term I, (a.support ≠ ∅ ∨ b.support ≠ ∅) →
    CoversPivots target a b → Survivor target a b := by
  apply classify_small target sparse
  apply small_from_checked _ verified
  intro _ x h
  simp [target,h]

theorem lower (t : Net V) (h : ∀ s, sees t s = f s) : 9 ≤ t.cost := by
  refine theta_lower f data target ?_ ?_ ?_ allPivots residual census t h
  · intro x
    simp [target,f,fromRow,initial,val,Ep.eval]
  · intro i
    fin_cases i
    · exact price2
    · exact price3
    · exact price4
    · exact price5
    · exact price6
    · exact price7
    · exact price8
  · constructor
    · decide
    · constructor <;> decide
end Theta145
end Research.OddOr
/- END OR9822Theta145Floor.lean -/

