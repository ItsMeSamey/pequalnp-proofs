import OriginalHotBudget9822
import CutHotTrace9822
import PairGuardReplace9822
import PairReaderMask9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr SignedClamp NonrawSupport OuterNet
open PEqualNP.Outside.L_meta_9822.Clean GuardTags
def readsOr (i : Nat) (a : Gate) := CircuitCompiler.orFlag a && decide (i∈a.inputs)
theorem readers_hot (gs : List Gate) (w : List Bool) (i : Nat) (inside : i<w.length)
    (hot : w.getD i false=true) : gs.countP (readsOr i) ≤ physicalHot gs w := by
  induction gs generalizing w with
  | nil => rfl
  | cons q tail ih =>
    let bit := q.op.eval (q.inputs.map fun j => w.getD j false)
    have lower := ih (w++[bit]) (by simp;omega) (by rwa [List.getD_append _ _ _ _ inside])
    change _ ≤ physicalHot tail (w++[bit]) + (CircuitCompiler.orFlag q && bit).toNat
    cases eq : readsOr i q with
    | false =>
      rw [List.countP_cons_of_neg (by simp [eq])]
      omega
    | true =>
      have both : CircuitCompiler.orFlag q=true ∧ i∈q.inputs := by simpa [readsOr] using eq
      obtain ⟨flag,mem⟩ := both
      have yes : q.op=.or := by
        obtain ⟨op,ins⟩ := q
        cases op <;> simp_all [CircuitCompiler.orFlag]
      have hbit : bit=true := by
        simp only [bit,yes,GateOp.eval,List.any_map,Function.comp_def,id_eq,List.any_eq_true]
        exact ⟨i,mem,hot⟩
      rw [List.countP_cons_of_pos eq,flag,hbit]
      rw [hbit] at lower
      change _ ≤ _ + 1
      omega

theorem one_true_physical_or {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (minimal : Reduced 10 C.gates C.output) (seven : 7 ≤ C.gates.countP countsAnd)
    (s t : Fin 10) (lo : 5 ≤ s.val) (hi : s.val ≤ 8)
    (guard : ∀ v : Input, innerValue pre g v=(v s || v t)) :
    physicalHot C.gates (List.ofFn (singleton s)) ≤ 1 := by
  let w := List.ofFn (singleton s)
  have lower := original_hot_cap r cand seven s t lo hi guard
  rw [model_hot (r.split ▸ minimal) r.pos] at lower
  have off : g.op.eval (g.inputs.map fun j => (wiresFrom pre w).getD j false)=false := by
    rw [r.inv]
    change (!(innerValue pre g (singleton s)))=false
    simp [guard,SignedClamp.singleton]
  rw [r.split,physicalHot_append]
  change physicalHot pre w + (physicalHot post (wiresFrom pre w ++ [_]) + _) ≤ 1
  rw [off]
  have flag : CircuitCompiler.orFlag g=false := by simp [CircuitCompiler.orFlag,r.inv]
  simpa only [flag,Bool.false_and,Bool.toNat_false,Nat.add_zero] using lower
theorem only_guard_or {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (minimal : Reduced 10 C.gates C.output) (seven : 7 ≤ C.gates.countP countsAnd)
    (s t : Fin 10) (lo : 5 ≤ s.val) (hi : s.val ≤ 8)
    (guard : ∀ v : Input, innerValue pre g v=(v s || v t)) (p tail : List Gate)
    (physical : C.gates=p++literalGate s t::tail) :
    (p++tail).countP (readsOr s.val) = 0 ∧ tail.countP (readsOr (10+p.length)) = 0 := by
  let w := List.ofFn (singleton s)
  let u := wiresFrom p w
  have len : u.length=10+p.length := by simp [u,w,length_wiresFrom]
  have raw : u.getD s.val false=true := by
    dsimp [u]; rw [getD_wiresFrom _ _ _ (by simp [w]),getD_ofFn 10 _ false s]
    simp [SignedClamp.singleton]
  have fire : (literalGate s t).op.eval ((literalGate s t).inputs.map fun j => u.getD j false)=true := by
    change (u.getD s.val false || (u.getD t.val false || false))=true
    rw [raw]; rfl
  have cap := one_true_physical_or r cand minimal seven s t lo hi guard
  rw [physical,physicalHot_append] at cap
  change physicalHot p w + (physicalHot tail (u++[_]) + (CircuitCompiler.orFlag (literalGate s t) && _).toNat) ≤ 1 at cap
  rw [fire] at cap
  change physicalHot p w + (physicalHot tail (u++[true]) + 1) ≤ 1 at cap
  have early := readers_hot p w s.val (by simp [w]) (by exact (getD_ofFn 10 _ false s).trans (by simp [SignedClamp.singleton]))
  have late := readers_hot tail (u++[true]) s.val (by simp;omega)
    (by rwa [List.getD_append _ _ _ _ (by omega : s.val<u.length)])
  have shared := readers_hot tail (u++[true]) (10+p.length) (by simp [len])
    (by rw [←len,getD_snoc_eq])
  rw [List.countP_append]
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.only_guard_or
