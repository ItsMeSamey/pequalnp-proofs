import GuardHotBudget9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open FreeAndNet Research.OddOr PEqualNP.CircuitLowerBounds
open Research.OddOr.Graph9822
open SignedClamp NonrawSupport OuterNet PEqualNP.Outside.L_meta_9822.Clean
private theorem trace_price {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10)
    (hot : innerValue pre g (SignedClamp.singleton i) = true) :
    LowPositive.pinPrice i + hotCount (SignedClamp.singleton i) (zeroNet pre post C.output) ≤ (zeroNet pre post C.output).cost := by
  let u := zeroNet pre post C.output
  let k := retire (LowPositive.setHigh i) u
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have exactOn (s : Finset (Fin 10)) : sees k s = LowPositive.pos i s := by
    let v : Input := fun j => decide (j=i ∨ j∈s)
    have on : innerValue pre g v = true := by
      apply inner_mono_inputs (fun q hq => r.pos q (List.mem_append_left _ hq)) g _ hot
      intro j hj
      have eq : j=i := by simpa [SignedClamp.singleton] using hj
      simp [v,eq]
    have actual := cut.computes v
    rw [on] at actual
    change (retire _ u).eval _ = _
    rw [retire_eval]
    have eq : (fun j => pval (fun z => decide (z∈s)) (LowPositive.setHigh i j)) = v :=
      funext (LowPositive.row_eval i s)
    rw [eq]
    change (specialize (close false) (model pre post C.output)).eval v = _
    rw [eval_specialize,close_eval,model_eval r cand]
    exact actual
  have price := LowPositive.pin_price i k exactOn
  have base : floorRow (LowPositive.setHigh i) = SignedClamp.singleton i := by
    funext j
    by_cases eq : j=i <;> simp [floorRow,LowPositive.setHigh,SignedClamp.singleton,eq,pval]
  have save := retire_cost (LowPositive.setHigh i) u
  rw [base] at save
  change LowPositive.pinPrice i ≤ (retire (LowPositive.setHigh i) u).cost at price
  change LowPositive.pinPrice i + hotCount (SignedClamp.singleton i) u ≤ u.cost
  omega


/-- The outer monotone circuit has exactly one OR site with a formal inverter
input inside its product arms. The specialization at zero retains eight ORs. -/
theorem unique_exit {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10) (lo : 5 ≤ i.val) (hi : i.val ≤ 8)
    (hot : innerValue pre g (singleton i) = true) :
    hits (0 : Fin 11) (model pre post C.output) = 1 ∧
    (zeroNet pre post C.output).cost = 8 ∧ (model pre post C.output).cost = 9 := by
  let t := model pre post C.output
  have cap : t.cost ≤ 9 := (model_cost r).trans (or_cap r cand seven)
  have cut := physical_cut_split cand r.split r.inv (fun a ha => r.pos a (List.mem_append_right _ ha))
  obtain ⟨x,_,_,witnessHot⟩ := independent_witness r cand seven 0
  have allHot : innerValue pre g (fun _ => true) = true :=
    inner_mono_inputs (fun a ha => r.pos a (List.mem_append_left _ ha)) g (fun _ _ => rfl) witnessHot
  have yes := cut.computes (fun _ => true)
  rw [allHot] at yes
  have witness : t.eval (env (fun _ => true) false) = true :=
    (model_eval r cand _ _).trans yes
  have noOut : ¬outUses (0 : Fin 11) t := by
    intro bad
    have no := outZeros t 0 bad (env (fun _ => true) false) rfl
    rw [witness] at no
    contradiction
  have hit : 0 < hits (0 : Fin 11) t := by
    by_contra! hz
    let u := specialize (close true) t
    have exactOutput (s : Finset V) : sees u s = f s := by
      let v : Input := fun j => decide (j∈s)
      have same : t.eval (env v true) = t.eval (env v (!(innerValue pre g v))) := by
        apply eval_congr_used
        intro j used
        exact Fin.cases (fun h => False.elim (h.elim (by omega) noOut))
          (fun _ _ => rfl) j used
      change (specialize (close true) t).eval v = _
      rw [eval_specialize,close_eval,same,model_eval r cand]
      exact cut.computes v
    have more := lower_of_theta Theta233.lower Theta144.lower Theta145.lower u exactOutput
    have sub : u.cost ≤ t.cost := specialize_cost _ _
    omega
  have debit := specialize_saves (0 : Fin 11) (close false) (by rfl) t
  have budget := trace_price r cand seven i hot
  have one := high_exactly_one r cand seven i lo hi hot
  have price : LowPositive.pinPrice i = 7 := by simp [LowPositive.pinPrice,show ¬ i.val ≤ 4 by omega,hi]
  change (zeroNet pre post C.output).cost + hits (0 : Fin 11) t ≤ t.cost at debit
  change hits (0 : Fin 11) t = 1 ∧ (zeroNet pre post C.output).cost = 8 ∧ t.cost = 9
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.unique_exit
