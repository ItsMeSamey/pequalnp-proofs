import PairDistinctOwners9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem no_external_raw_or {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (minimal : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t i j : Fin 10) (il : (5 : Nat)≤Fin.val i) (iu : Fin.val i≤(8 : Nat))
    (gg : ∀ v : Input,innerValue pre g v=(v i || v j)) (owner : i=s ∨ i=t)
    (p tail : List Gate) (physical : C.gates=p++literalGate s t::tail)
    (q : Gate) (ext : q∈p++tail) (pin : i.val∈q.inputs) (h : q.op=.or) : False := by
  have cap := one_true_physical_or r cand minimal seven i j il iu gg
  let w := List.ofFn (SignedClamp.singleton i)
  let u := wiresFrom p w
  have ilt : i.val<u.length := by simp [u,w,length_wiresFrom];omega
  have ihot : u.getD i.val false=true := by
    dsimp [u];rw [getD_wiresFrom _ _ _ (by simp [w]),getD_ofFn 10 _ false i];simp [SignedClamp.singleton]
  have lit : (literalGate s t).op.eval ((literalGate s t).inputs.map fun k => u.getD k false)=true := by
    change (u.getD s.val false || (u.getD t.val false || false))=true
    rcases owner with e|e <;> subst i <;> rw [ihot] <;> simp
  rw [physical,GuardTags.physicalHot_append] at cap
  change GuardTags.physicalHot p w + (GuardTags.physicalHot tail (u++[_]) + (FreeAndNet.CircuitCompiler.orFlag _ && _).toNat) ≤ 1 at cap
  rw [lit] at cap
  change GuardTags.physicalHot p w + (GuardTags.physicalHot tail (u++[true]) + 1) ≤ 1 at cap
  have early := readers_hot p w i.val (by simp [w]) ((getD_ofFn 10 _ false i).trans (by simp [SignedClamp.singleton]))
  have late := readers_hot tail (u++[true]) i.val (by simp;omega)
    (by rwa [List.getD_append _ _ _ _ ilt])
  have hit : readsOr i.val q=true := by simp [readsOr,FreeAndNet.CircuitCompiler.orFlag,h,pin]
  have n := List.countP_pos_iff.mpr ⟨q,ext,hit⟩
  rw [List.countP_append] at n
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
