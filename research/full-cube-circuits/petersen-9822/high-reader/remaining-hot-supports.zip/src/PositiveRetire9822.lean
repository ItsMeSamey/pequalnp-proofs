import OR9822Base

namespace Research.OddOr
open FreeAndNet

def floorRow {α β : Type} (s : α → Product β) (a : α) :=
  pval (fun _ => false) (s a)

private theorem floor_mono {β : Type} (p : Product β) (v : β → Bool) :
    pval (fun _ => false) p = true → pval v p = true := by
  cases p with
  | none => exact id
  | some a => cases a <;> simp [pval]

private theorem hot_stays {α β : Type} (s : α → Product β) (a b : List α) (v : β → Bool)
    (h : (a.all (floorRow s) || b.all (floorRow s)) = true) :
    (a.all (fun i => pval v (s i)) || b.all (fun i => pval v (s i))) = true := by
  simp only [Bool.or_eq_true,List.all_eq_true] at h ⊢
  exact h.imp (fun h i hi => floor_mono _ v (h i hi)) (fun h i hi => floor_mono _ v (h i hi))

/-- Substitute products and retire any OR which already evaluates to one on
the all-false row of the new inputs, as well as branches which vanish. -/
def retire {α β : Type} (s : α → Product β) : Net α → Net β
  | .out p => .out (p.bind (substProduct s))
  | .gate a b t =>
    if a.all (floorRow s) || b.all (floorRow s) then
      retire (fun z => z.elim (some []) s) t
    else
      match substProduct s a, substProduct s b with
      | none,p | p,none => retire (fun z => z.elim p s) t
      | some l,some r => .gate l r
          (retire (fun z => z.elim (some [none]) (fun i => liftP (s i))) t)

theorem retire_eval {α β : Type} (s : α → Product β) (t : Net α) (v : β → Bool) :
    (retire s t).eval v = t.eval (fun i => pval v (s i)) := by
  induction t generalizing β with
  | out p => cases p <;> first | rfl | exact pval_subst _ _ _
  | gate a b t ih =>
    unfold retire
    split
    next h =>
      rw [ih]
      simp only [Net.eval,hot_stays s a b v h]
      congr 1
      funext z
      cases z <;> rfl
    next _ =>
      simp only [Net.eval]
      rw [←pval_subst s a v,←pval_subst s b v]
      cases h : substProduct s a <;> cases k : substProduct s b <;>
        simp only [Net.eval,ih] <;> congr 1 <;> funext z <;> cases z <;>
        first | apply pval_lift | simp [pval]

private theorem floor_back {α β : Type} (s : α → Product β) (p : Product β)
    (h : pval (fun _ => false) p = false) :
    floorRow (fun z : Option α => z.elim p s) = (fun z => z.elim false (floorRow s)) := by
  funext z
  cases z with
  | none => exact h
  | some i => rfl

private theorem floor_lift {α β : Type} (s : α → Product β) :
    floorRow (fun z : Option α => z.elim (some [none]) (fun i => liftP (s i))) =
      (fun z : Option α => z.elim false (floorRow s)) := by
  funext z
  cases z with
  | none => rfl
  | some i =>
    change pval (fun _ => false) (liftP (s i)) = pval (fun _ => false) (s i)
    cases p : s i <;> simp [liftP,pval,List.all_map,Function.comp_def]

theorem retire_cost {α β : Type} (s : α → Product β) (t : Net α) :
    (retire s t).cost + hotCount (floorRow s) t ≤ t.cost := by
  induction t generalizing β with
  | out p => rfl
  | gate a b t ih =>
    unfold retire hotCount
    by_cases h : (a.all (floorRow s) || b.all (floorRow s)) = true
    · rw [if_pos h,h]
      have eq : floorRow (fun z : Option _ => z.elim (some []) s) =
          (fun z : Option _ => z.elim true (floorRow s)) := by
        funext z; cases z <;> rfl
      have sub := ih (fun z : Option _ => z.elim (some []) s)
      rw [eq] at sub
      simp only [Bool.toNat_true,Net.cost]
      omega
    · have zero : (a.all (floorRow s) || b.all (floorRow s)) = false := by simpa using h
      rw [if_neg h,zero]
      have pa := pval_subst s a (fun _ => false)
      have pb := pval_subst s b (fun _ => false)
      change pval _ (substProduct s a) = a.all (floorRow s) at pa
      change pval _ (substProduct s b) = b.all (floorRow s) at pb
      rw [←pa,←pb] at zero
      obtain ⟨hotA,hotB⟩ := Bool.or_eq_false_iff.mp zero
      have skip (p : Product _) (cold : pval (fun _ => false) p = false) := by
        have sub := ih (fun z : Option _ => z.elim p s)
        rw [floor_back s p cold] at sub
        exact sub
      cases l : substProduct s a <;> cases r : substProduct s b
      all_goals simp only [Bool.toNat_false,Nat.add_zero,Net.cost]
      · exact Nat.le_succ_of_le (skip none rfl)
      · exact Nat.le_succ_of_le (skip _ (r ▸ hotB))
      · exact Nat.le_succ_of_le (skip _ (l ▸ hotA))
      · have sub := ih (fun z : Option _ => z.elim (some [none]) (fun i => liftP (s i)))
        rw [floor_lift s] at sub
        omega

end Research.OddOr
#print axioms Research.OddOr.retire_cost
