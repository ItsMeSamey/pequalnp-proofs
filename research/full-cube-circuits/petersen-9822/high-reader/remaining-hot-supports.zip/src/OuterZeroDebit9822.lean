import OuterNet9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.OuterNet
open FreeAndNet Research.OddOr Research.OddOr.Graph9822
open SignedClamp NonrawSupport PEqualNP.CircuitLowerBounds

def close (b : Bool) : Fin 11 → Product (Fin 10) :=
  Fin.cases (if b then some [] else none) (fun i => some [i])

theorem close_eval (b : Bool) (v : Input) :
    (fun j => pval v (close b j)) = env v b := by
  funext j
  refine Fin.cases ?_ (fun i => ?_) j
  · cases b <;> rfl
  · simp [close,env,pval]

theorem zero_debit {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) :
    (specialize (close false) (model pre post C.output)).cost ≤ 8 := by
  let t := model pre post C.output
  have cap := (model_cost r).trans (or_cap r cand seven)
  change t.cost ≤ 9 at cap
  have cut := physical_cut_split cand r.split r.inv (fun a ha => r.pos a (List.mem_append_right _ ha))
  obtain ⟨x,_,_,hot⟩ := independent_witness r cand seven 0
  have allHot : innerValue pre g (fun _ => true) = true :=
    inner_mono_inputs (fun a ha => r.pos a (List.mem_append_left _ ha)) g (fun _ _ => rfl) hot
  have yes := cut.computes (fun _ => true)
  rw [allHot] at yes
  have witness : t.eval (env (fun _ => true) false) = true :=
    (model_eval r cand _ _).trans yes
  have noOut : ¬outUses (0 : Fin 11) t := by
    intro bad
    have no := outZeros t 0 bad (env (fun _ => true) false) rfl
    rw [witness] at no
    contradiction
  have hit : 0 < hits (0 : Fin 11) t := by
    by_contra! hz
    let u := specialize (close true) t
    have exactOutput (s : Finset V) : sees u s = f s := by
      let v : Input := fun j => decide (j∈s)
      have same : t.eval (env v true) = t.eval (env v (!(innerValue pre g v))) := by
        apply eval_congr_used
        intro j used
        exact Fin.cases (fun h => False.elim (h.elim (by omega) noOut))
          (fun _ _ => rfl) j used
      change (specialize (close true) t).eval v = _
      rw [eval_specialize,close_eval,same,model_eval r cand]
      exact cut.computes v
    have more := lower_of_theta Theta233.lower Theta144.lower Theta145.lower u exactOutput
    have sub : u.cost ≤ t.cost := specialize_cost _ _
    omega
  have debit := specialize_saves (0 : Fin 11) (close false) (by rfl) t
  change (specialize (close false) t).cost ≤ 8
  omega

end PEqualNP.Outside.L_meta_9822.Sectors.OuterNet
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.OuterNet.zero_debit
