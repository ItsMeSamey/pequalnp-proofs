import CleanMin9822
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds
theorem no_absorbing_product {n : Nat} {gs : List Gate} {out p : Nat}
    (reduced : Reduced n gs out) (g : Gate) (site : gs[p]?=some g) (op : g.op=.and)
    (a b : Nat) (ab : a≠b) (pa : a∈g.inputs) (pb : b∈g.inputs) :
    ¬ ∀ x : Fin n → Bool, vl gs x a=true → vl gs x b=true := by
  intro domination
  have cg := reduced.clean p g site
  have small := cg.nok.1.2
  have layout : g.inputs=[a,b] ∨ g.inputs=[b,a] := by
    generalize eq : g.inputs=xs at small pa pb ⊢
    rcases xs with _|⟨u,_|⟨v,_|⟨w,tail⟩⟩⟩ <;> simp_all <;> grind
  apply reduced.noAlias p (reads_len ⟨g,site,pa⟩) a (cg.lt a pa)
  intro x
  rw [vl_gate gs reduced.clean x p g site,op]
  rcases layout with h|h <;> rw [h] <;>
    cases ha : vl gs x a <;> simp [GateOp.eval,ha,domination x]
theorem no_disjoint_product {n : Nat} {gs : List Gate} {out p : Nat}
    (reduced : Reduced n gs out) (g : Gate) (site : gs[p]?=some g) (op : g.op=.and)
    (a b : Nat) (ab : a≠b) (pa : a∈g.inputs) (pb : b∈g.inputs) :
    ¬ ∀ x : Fin n → Bool, vl gs x a=true → vl gs x b=false := by
  intro disjoint
  have cg := reduced.clean p g site
  have small := cg.nok.1.2
  have layout : g.inputs=[a,b] ∨ g.inputs=[b,a] := by
    generalize eq : g.inputs=xs at small pa pb ⊢
    rcases xs with _|⟨u,_|⟨v,_|⟨w,tail⟩⟩⟩ <;> simp_all <;> grind
  apply reduced.noConstant p (reads_len ⟨g,site,pa⟩) false
  intro x
  rw [vl_gate gs reduced.clean x p g site,op]
  rcases layout with h|h <;> rw [h] <;>
    cases ha : vl gs x a <;> simp [GateOp.eval,ha,disjoint x]
end PEqualNP.Outside.L_meta_9822.Clean
#print axioms PEqualNP.Outside.L_meta_9822.Clean.no_absorbing_product
#print axioms PEqualNP.Outside.L_meta_9822.Clean.no_disjoint_product
