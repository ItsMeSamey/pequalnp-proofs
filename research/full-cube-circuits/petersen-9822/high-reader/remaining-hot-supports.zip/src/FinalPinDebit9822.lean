import MultiReaderDebit9822
namespace PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit
open PEqualNP.CircuitLowerBounds
open scoped Classical
theorem final_get (n : Nat) (gs : List Gate) (acc : List Stat × List Gate) (j : Nat)
    (h : j<acc.1.length) :
    (elim n gs acc).1.getD j (Sum.inl false)=acc.1.getD j (Sum.inl false) := by
  induction gs generalizing acc with
  | nil => rfl
  | cons g gs ih =>
    change (elim n gs (elimStep n acc g)).1.getD j _ = _
    rw [ih (elimStep n acc g) (by change j<(acc.1++[_]).length; simp;omega)]
    exact List.getD_append _ _ _ _ h

theorem same_kind (op : GateOp) (m : Nat) (ins : List Stat) :
    ∀ g∈(simplify op m ins).1, g.op=op := by
  intro g hg
  cases op <;> simp only [simplify] at hg
  · rcases ins with _ | ⟨a, _ | ⟨b, _ | ⟨c, l⟩⟩⟩ <;> (try cases a) <;> (try cases b) <;>
      simp [simpAnd] at hg; subst hg; rfl
  · rcases ins with _ | ⟨a, _ | ⟨b, _ | ⟨c, l⟩⟩⟩ <;> (try cases a) <;> (try cases b) <;>
      simp [simpOr] at hg; subst hg; rfl
  · rcases ins with _ | ⟨a, l⟩ <;> (try cases a) <;>
      simp [simpNot] at hg; subst hg; rfl
  · simp at hg
  · simp at hg

/-- Final statuses may include newly generated constants, including a folded guard
and its inverter. Every marked reader of the selected kind loses its own site. -/
theorem final_pin_debit (n : Nat) (kind : GateOp) (mark : Gate → Bool) (gs : List Gate)
    (acc : List Stat × List Gate) (clean : CleanL acc.1.length gs)
    (marked : ∀ q∈gs, mark q=true → q.op=kind ∧ ∃ j∈q.inputs, ∃ b : Bool,
      (elim n gs acc).1.getD j (Sum.inl false)=Sum.inl b) :
    (elim n gs acc).2.countP (fun q => decide (q.op=kind)) + gs.countP mark ≤
      acc.2.countP (fun q => decide (q.op=kind)) + gs.countP (fun q => decide (q.op=kind)) := by
  induction gs generalizing acc with
  | nil => simp [elim]
  | cons g tail ih =>
    let next := elimStep n acc g
    let xs := g.inputs.map fun j => acc.1.getD j (Sum.inl false)
    let emitted := (simplify g.op (n+acc.2.length) xs).1
    let ofKind := fun q : Gate => decide (q.op=kind)
    have cg := clean 0 g (by simp)
    have cleanTail : CleanL next.1.length tail := by
      intro i q hq
      have h := clean (i+1) q (by simpa using hq)
      change CleanGate ((acc.1++[_]).length+i) q
      convert h using 1 <;> simp <;> omega
    have bound := ih next cleanTail (fun q hq => marked q (List.mem_cons_of_mem _ hq))
    change (elim n tail next).2.countP ofKind + tail.countP mark ≤ next.2.countP ofKind + tail.countP ofKind at bound
    have cost : next.2.countP ofKind = acc.2.countP ofKind + emitted.toList.countP ofKind :=
      List.countP_append ..
    change (elim n tail next).2.countP ofKind + _ ≤ acc.2.countP ofKind + _
    cases hit : mark g with
    | true =>
      obtain ⟨op,j,mem,b,pin⟩ := marked g List.mem_cons_self hit
      have hj : j<acc.1.length := by simpa using cg.lt j mem
      have now := final_get n (g::tail) acc j hj
      have hok := (clean_nok _ _ clean g List.mem_cons_self)
      have gone : emitted=none := constant_fold _ _ _ (by simpa [xs] using hok.1.2)
        (fun v => by simpa [xs] using hok.2 v) b (List.mem_map.mpr ⟨j,mem,now.symm.trans pin⟩)
      have yes : ofKind g=true := by simp [ofKind,op]
      rw [List.countP_cons_of_pos hit,List.countP_cons_of_pos yes]
      simp [gone] at cost
      omega
    | false =>
      rw [List.countP_cons_of_neg (by simp [hit])]
      by_cases yes : ofKind g=true
      · rw [List.countP_cons_of_pos yes]
        have small : emitted.toList.countP ofKind≤1 :=
          (List.countP_le_length ..).trans (toList_length_le emitted)
        omega
      · rw [List.countP_cons_of_neg yes]
        have noneK : emitted.toList.countP ofKind=0 := by
          apply List.countP_eq_zero.mpr
          intro q hq same
          have eq := same_kind g.op (n+acc.2.length) xs q (Option.mem_toList.mp hq)
          exact yes (by simpa [ofKind,eq] using same)
        omega
end PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit
#print axioms PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit.final_pin_debit
