import PhysicalReaderDebit9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardTags
open PEqualNP.CircuitLowerBounds
/-- The first bit tracks an AND-only path from the distinguished source. The
second bit is the value with this literal stripped from this product. -/
abbrev Tagged := Bool × Bool
def recover (z : Bool) (p : Tagged) := p.2 && (!p.1 || z)
def atOR (z : Bool) (xs : List Tagged) : Tagged :=
  (false,xs.any (recover z))
def atAnd (xs : List Tagged) : Tagged := (xs.any Prod.fst,xs.all Prod.snd)

theorem and_sound (xs : List Tagged) (z : Bool) :
    recover z (atAnd xs) = xs.all (recover z) := by
  induction xs with
  | nil => simp [recover,atAnd]
  | cons p ps ih =>
    obtain ⟨flag,val⟩ := p
    cases z <;> cases flag <;> cases val <;>
      simp_all [recover,atAnd,List.any_cons,List.all_cons,Bool.not_or,Bool.and_comm,Bool.and_left_comm,Bool.and_assoc]

def emit (z : Bool) (op : GateOp) (xs : List Tagged) : Tagged :=
  match op with
  | .and => atAnd xs
  | _ => atOR z xs

theorem emit_sound (op : GateOp) (ok : op=.and ∨ op=.or) (z : Bool) (xs : List Tagged) :
    recover z (emit z op xs) = op.eval (xs.map (recover z)) := by
  rcases ok with rfl | rfl
  · simpa [emit,GateOp.eval] using and_sound xs z
  · simp [emit,recover,atOR,GateOp.eval]

def run (z : Bool) (gs : List Gate) (w : List Tagged) : List Tagged := gs.foldl
  (fun old g => old ++ [emit z g.op (g.inputs.map fun j => old.getD j (false,false))]) w

theorem run_sound (z : Bool) (gs : List Gate) (w : List Tagged)
    (ok : ∀ g ∈ gs,g.op=.and ∨ g.op=.or) :
    (run z gs w).map (recover z) = wiresFrom gs (w.map (recover z)) := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih =>
    unfold run
    simp only [List.foldl_cons]
    change (run z gs _).map (recover z) = wiresFrom gs ((w.map (recover z)) ++ [_])
    rw [ih _ (fun q hq => ok q (List.mem_cons_of_mem _ hq))]
    simp only [List.map_append,List.map_cons,List.map_nil,emit_sound _ (ok g List.mem_cons_self),List.map_map]
    congr 3
    apply congrArg g.op.eval
    apply List.map_congr_left
    intro i _
    exact (List.getD_map (d := (false,false)) (l := w) (n := i) (recover z)).symm

/-- A sole tagged disjunct can be repaired by a single AND with z. All positive
uses of its stripped value remain independently available. -/
theorem repair_one (z left right : Bool) :
    (atOR z [(true,left),(false,right)]).2 = ((left && z) || right) := by
  cases z <;> cases left <;> cases right <;> rfl
end PEqualNP.Outside.L_meta_9822.Clean.GuardTags
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardTags.run_sound
