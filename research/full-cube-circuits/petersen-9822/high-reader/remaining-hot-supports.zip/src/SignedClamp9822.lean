import Sector9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open PEqualNP.CircuitLowerBounds
abbrev Input := Fin 10 → Bool

def singleton (v : Fin 10) : Input := fun i => decide (i = v)
def pair (u v : Fin 10) : Input := fun i => singleton u i || singleton v i
def addRaw (x : Input) (v : Fin 10) : Input := fun i => x i || singleton v i

theorem singleton_zero : ∀ v, edge (singleton v) = false := by decide +kernel

theorem low_neighbor :
    ∀ v : Fin 10, ∃ w : Fin 10, w.val ≤ 4 ∧ edge (pair v w) = true := by decide +kernel

theorem two_neighbors :
    ∀ v : Fin 10, ∃ a b : Fin 10, a ≠ b ∧ edge (pair v a) = true ∧
      edge (pair v b) = true := by decide +kernel

/-- A nonadjacent twin candidate still has a distinguishing context after any
    one further vertex is forbidden; this is stronger than distinct neighborhoods. -/
theorem distinguishes_away :
    ∀ u v r : Fin 10, u ≠ v → edge (pair u v) = false →
      ∃ w : Fin 10, w ≠ u ∧ w ≠ v ∧ w ≠ r ∧ edge (pair u w) ≠ edge (pair v w) := by
  decide +kernel

theorem positive_twin_partner :
    ∀ u v : Fin 10, u ≠ v → edge (pair u v) = false →
      ∃ w : Fin 10, edge (pair u w) = false ∧
        edge (addRaw (pair u w) v) = true := by decide +kernel

structure ComputesCut (H : Input → Bool) (K : Input → Bool → Bool) : Prop where
  computes : ∀ x, K x (!(H x)) = edge x
  increasing : ∀ x, K x false = true → K x true = true

theorem ofCandidate {C : Circuit} (h : Candidate C)
    {H : Input → Bool} {K : Input → Bool → Bool}
    (cuts : ∀ x, K x (!(H x)) = C.eval (List.ofFn x))
    (inc : ∀ x, K x false = true → K x true = true) : ComputesCut H K :=
  ⟨fun x => (cuts x).trans (h.2.2 x), inc⟩

theorem positive_upper {H K} (h : ComputesCut H K) (x : Input)
    (hx : edge x = true) : K x true = true := by
  have e := (h.computes x).trans hx
  cases hh : H x with
  | false => simpa [hh] using e
  | true => apply h.increasing; simpa [hh] using e

theorem hot_guard {H K} (h : ComputesCut H K) (v : Fin 10)
    (hv : K (singleton v) true = true) : H (singleton v) = true := by
  cases e : H (singleton v) with
  | true => rfl
  | false =>
    have bad := h.computes (singleton v)
    simp [e, hv, singleton_zero] at bad

/-- Positive-clamp receiver containment expressed only on the necessary
    singleton/pair probes. -/
def CoveredByGuardInput (K : Input → Bool → Bool) (r : Fin 10) : Prop :=
  ∀ w, K (pair r w) true = K (singleton w) true

theorem covered_neighbor_hot {H K} (h : ComputesCut H K) {r : Fin 10}
    (cover : CoveredByGuardInput K r) {w : Fin 10} (adj : edge (pair r w) = true) :
    H (singleton w) = true :=
  hot_guard h w ((cover w).symm.trans (positive_upper h _ adj))

theorem no_covered_raw_of_low_cold {H K} (h : ComputesCut H K)
    (cold : ∀ w : Fin 10, w.val ≤ 4 → H (singleton w) = false) (r : Fin 10) :
    ¬ CoveredByGuardInput K r := by
  intro covered
  obtain ⟨w, hw, adj⟩ := low_neighbor r
  have e := covered_neighbor_hot h covered adj
  rw [cold w hw] at e
  contradiction

theorem no_covered_raw_for_raw_guard {K} (r i : Fin 10)
    (h : ComputesCut (fun x => x i) K) : ¬ CoveredByGuardInput K r := by
  intro covered
  obtain ⟨a, b, ne, ha, hb⟩ := two_neighbors r
  have ea := covered_neighbor_hot h covered ha
  have eb := covered_neighbor_hot h covered hb
  have ia : i = a := by simpa [singleton] using ea
  have ib : i = b := by simpa [singleton] using eb
  exact ne (ia.symm.trans ib)

theorem raw_guard_clamp_formula {K} (i : Fin 10) (h : ComputesCut (fun x => x i) K)
    (wide : ∀ x : Input, x i = true → K x true = true) :
    ∀ x, K x true = (x i || edge x) := by
  intro x
  cases e : x i with
  | false => simpa [e] using h.computes x
  | true => simp [e, wide x e]

theorem raw_guard_clamp_of_hot_singleton {K} (i : Fin 10)
    (h : ComputesCut (fun x => x i) K)
    (monoInputs : ∀ x y : Input, (∀ j, x j = true → y j = true) →
      K x true = true → K y true = true)
    (someHot : ∃ v, K (singleton v) true = true) :
    ∀ x, K x true = (x i || edge x) := by
  obtain ⟨v, hv⟩ := someHot
  have iv : i = v := by simpa [singleton] using hot_guard h v hv
  subst v
  apply raw_guard_clamp_formula i h
  intro x hx
  refine monoInputs (singleton i) x ?_ hv
  intro j hj
  have ji : j = i := by simpa [singleton] using hj
  simpa [ji] using hx

theorem raw_guard_twin_impossible {K} {u v r : Fin 10}
    (h : ComputesCut (fun x => x r) K) (different : u ≠ v)
    (awayU : r ≠ u) (awayV : r ≠ v) (nonedge : edge (pair u v) = false)
    (twins : ∀ w, K (pair u w) true = K (pair v w) true) : False := by
  obtain ⟨w, _, _, wr, separates⟩ := distinguishes_away u v r different nonedge
  have left : K (pair u w) true = edge (pair u w) := by
    simpa [pair, singleton, awayU, Ne.symm wr] using h.computes (pair u w)
  have right : K (pair v w) true = edge (pair v w) := by
    simpa [pair, singleton, awayV, Ne.symm wr] using h.computes (pair v w)
  exact separates (left.symm.trans ((twins w).trans right))

end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
