import PrivateMaskedRaw9822
import PrivateQuiet9822
import PrivateOwnerRoster9822
import PrivateOrReaderExcluded9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp LowHotElimination NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
theorem ghost_matches {p mid post : List Gate} {h : Gate} (out : Nat) (x : Input)
    (priv : ∀q∈mid++post, 10+p.length∉q.inputs) (away : out≠10+p.length) :
    vl (ghost p mid post) x out=outerValue (p++h::mid) post out x true := by
  unfold vl;rw [ghost_wires];exact clamp_matches out x priv away
theorem ghost_partner_warm (p mid post : List Gate) (s t : V) (j out : Nat)
    (js : j≠s.val) (os : out≠s.val)
    (touch : ∀q∈ghost p mid post,s.val∈q.inputs → q.op=.and ∧ j∈q.inputs)
    (hot : ∀x : Input,edge x=true → vl (ghost p mid post) x out=true)
    (cold : ∀x : Input,x s=false → x t=false → vl (ghost p mid post) x out=edge x) :
    ∀i : V, edge (pair s i)=true → i≠s → i≠t →
      (clampValues p mid post (SignedClamp.singleton i)).getD j false=true := by
  intro i edgei ns nt
  by_contra! off
  have low : vl (ghost p mid post) (SignedClamp.singleton i) out=false :=
    (cold _ (by simp [SignedClamp.singleton,ns.symm]) (by simp [SignedClamp.singleton,nt.symm])).trans (singleton_zero i)
  have hi := hot (pair s i) edgei
  have blocked := masked_single_raw (ghost p mid post) (List.ofFn (SignedClamp.singleton i)) (List.ofFn (pair s i))
    s.val j js touch (by simp) (by
      intro k diff
      by_cases lt : k<10
      · let a : V := ⟨k,lt⟩
        have ne : a≠s := fun e => diff (congrArg Fin.val e)
        rw [getD_ofFn 10 _ false a,getD_ofFn 10 _ false a]
        simp [pair,SignedClamp.singleton,ne]
      · rw [List.getD_eq_default _ _ (by simp;omega),List.getD_eq_default _ _ (by simp;omega)])
    (by rw [ghost_wires];simpa using off) out os
  exact Bool.noConfusion (low.symm.trans (blocked.trans hi))
theorem phase_at_actual {C p mid post g} (s t : V) (r : Roster C (p++literalGate s t::mid) post g)
    (guard : ∀x : Input,innerValue (p++literalGate s t::mid) g x=(x s || x t))
    (j : Nat) : outerValue (p++literalGate s t::mid) post j (fun _ => false) true=vl C.gates (fun _ => false : Input) j := by
  let x : Input := fun _ => false
  let pre := p++literalGate s t::mid
  have guard0 : innerValue pre g x=false := guard x
  unfold vl
  rw [r.split,wiresFrom_append]
  change (wiresFrom post (wiresFrom pre (List.ofFn x)++[true])).getD j false =
    (wiresFrom post (wiresFrom pre (List.ofFn x)++[g.op.eval (g.inputs.map fun i =>
      (wiresFrom pre (List.ofFn x)).getD i false)])).getD j false
  have value : g.op.eval (g.inputs.map fun i => (wiresFrom pre (List.ofFn x)).getD i false)=true := by
    rw [r.inv]
    change !(innerValue pre g x)=true
    rw [guard0];rfl
  rw [value]
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.ghost_partner_warm
