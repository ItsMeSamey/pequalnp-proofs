import OR9822Base
import RawOwnerClamp9822

/- OR9822NetOrder -/

namespace Research.OddOr.Envelope
open FreeAndNet

theorem eval_monotone {α : Type} (t : Net α) (v w : α → Bool)
    (inc : ∀ a, v a = true → w a = true) : t.eval v = true → t.eval w = true := by
  induction t with
  | out p =>
    cases p with
    | none => simp [Net.eval,pval]
    | some xs =>
      simp only [Net.eval,pval,Option.elim_some,List.all_eq_true]
      intro h a ha
      exact inc a (h a ha)
  | gate a b t ih =>
    apply ih
    intro z
    cases z with
    | some j => exact inc j
    | none =>
      have mono (l : List _) : l.all v = true → l.all w = true := by
        simp only [List.all_eq_true]
        exact fun h j hj => inc j (h j hj)
      simp only [Option.elim_none,Bool.or_eq_true]
      exact Or.imp (mono a) (mono b)

theorem sees_mono {α : Type} [DecidableEq α] (t : Net α) {a b : Finset α} (sub : a ⊆ b) :
    sees t a = true → sees t b = true := by
  apply eval_monotone
  intro j hj
  exact decide_eq_true (sub (of_decide_eq_true hj))

theorem empty_cold {α : Type} [DecidableEq α] [Nonempty α] (t : Net α)
    (cold : ∀ i, sees t {i} = false) : sees t ∅ = false := by
  classical
  let i : α := Classical.choice (inferInstance : Nonempty α)
  cases h : sees t ∅ with
  | false => rfl
  | true =>
    have r := sees_mono t (Finset.empty_subset {i}) h
    simp [cold] at r

theorem pair_in {α : Type} [DecidableEq α] {a b : α} {s : Finset α}
    (ha : a ∈ s) (hb : b ∈ s) : ({a,b} : Finset α) ⊆ s := by
  intro i hi
  rcases Finset.mem_insert.mp hi with eq | hi
  · simpa only [eq] using ha
  · simpa only [Finset.mem_singleton.mp hi] using hb

end Research.OddOr.Envelope

/- OR9822ForceOne -/

namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open FreeAndNet Research.OddOr Research.OddOr.Graph9822 
open PEqualNP.Outside.L_meta_9822.Clean SignedClamp RawOwnerClamp

def inputOn (s : Finset V) : Input := fun j => decide (j ∈ s)

/-- Keep exactly the old wiring and replace the unique NOT by a constant-one
AND at its physical slot. Every old outgoing use remains at the same index. -/
theorem force_one_net (C : Circuit) (cand : Candidate C) (pre post : List Gate)
    (g : Gate) (inv : g.op = .not) (split : C.gates = pre ++ g :: post)
    (positive : ∀ q ∈ pre ++ post, PositiveOp q) :
    ∃ t : Net V, t.cost ≤ (C.gates.filter CircuitCompiler.orFlag).length ∧
      (∀ s, sees t s = outerValue pre post C.output (inputOn s) true) ∧
      (∀ s, f s = true → sees t s = true) := by
  let D := forceOne pre post C.output
  have hm : Monotone2 D := by
    intro a ha
    change a ∈ pre ++ (⟨.and,[]⟩ : Gate) :: post at ha
    have ordinary (h : a ∈ pre ++ post) : a.op ∈ ({GateOp.and,GateOp.or} : Set GateOp) ∧
        a.inputs.length ≤ 2 := by
      have source : a ∈ C.gates := by
        rw [split]
        rcases List.mem_append.mp h with head | tail
        · exact List.mem_append_left _ head
        · exact List.mem_append_right _ (List.mem_cons_of_mem _ tail)
      exact ⟨positive a h,(cand.1 a source).2⟩
    rcases List.mem_append.mp ha with head | rest'
    · exact ordinary (List.mem_append_left _ head)
    · rcases List.mem_cons.mp rest' with rfl | tail
      · exact ⟨Or.inl rfl, by decide⟩
      · exact ordinary (List.mem_append_right _ tail)
  have cut := physical_cut_split (g := g) cand split inv
      (fun q hq => positive q (List.mem_append_right _ hq))
  let t := CircuitCompiler.compile 10 D
  have read (s : Finset V) : sees t s =
      outerValue pre post C.output (fun j => decide (j∈s)) true := by
    unfold sees
    rw [CircuitCompiler.compile_eval 10 D hm]
    change (wiresFrom (pre ++ (⟨.and,[]⟩ : Gate) :: post) _).getD _ _ = _
    rw [wiresFrom_append]
    rfl
  have budget := CircuitCompiler.compile_cost 10 D
  have same : (D.gates.filter CircuitCompiler.orFlag).length =
      (C.gates.filter CircuitCompiler.orFlag).length := by
    rw [split]
    simp [D,forceOne,CircuitCompiler.orFlag,inv]
  refine ⟨t,budget.trans_eq same,read,?_⟩
  intro s on
  rw [read]
  exact positive_upper cut _ on

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
