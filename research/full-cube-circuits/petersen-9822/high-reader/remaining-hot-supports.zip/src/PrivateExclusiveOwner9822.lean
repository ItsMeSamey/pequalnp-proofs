import RisingCutExit9822
import PairRisingGate9822
import PairAndOwner9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean AdjacentCut
theorem private_exclusive_owner {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t : V) (st : s≠t) (lo : 5≤s.val) (hi : s.val≤8)
    (guard : ∀ v : Input,innerValue pre g v=(v s || v t))
    (p tail : List Gate) (full : C.gates=p++literalGate s t::tail) (unary : g.inputs=[10+p.length])
    (priv : ∀ w∈C.gates,PositiveOp w → 10+p.length∉w.inputs) :
    ∃ (k : Nat) (q : Gate),C.gates[k]?=some q ∧ q.op=.and ∧ s.val∈q.inputs ∧ t.val∉q.inputs := by
  obtain ⟨i,low,high⟩ := exclusive_positive s t st
  let x := setOwners s t (SignedClamp.singleton i) false false
  let y := setOwners s t (SignedClamp.singleton i) true false
  let Z := fun j : Nat => j=s.val ∨ j=10+p.length
  have ups : rises C.gates x y C.output := ⟨(cand.2.2 x).trans low,(cand.2.2 y).trans high⟩
  have notZ : ¬Z C.output := by
    let u : Input := masked {s,t} (fun _ => true)
    have hs : u s=false := by simp [u,masked]
    have ht : u t=false := by simp [u,masked]
    have on : vl C.gates u C.output=true := (cand.2.2 u).trans (positive_off_two s t)
    rintro (e|e)
    · rw [e,vl_input _ _ _ s.isLt] at on
      exact Bool.noConfusion (hs.symm.trans on)
    · rw [e,(pair_physical_values r red.clean s t p tail full unary u).1,hs,ht] at on
      contradiction
  have raw (j : Nat) (lt : j<10) (up : rises C.gates x y j) : Z j := by
    by_cases e : (⟨j,lt⟩ : V)=s
    · exact Or.inl (congrArg Fin.val e)
    · obtain ⟨a,b⟩ := up
      rw [vl_input _ _ _ lt] at a b
      have eq : x ⟨j,lt⟩=y ⟨j,lt⟩ := by simp [x,y,setOwners,e]
      exact Bool.noConfusion (a.symm.trans (eq.trans b))
  have noInv (k : Nat) (q : Gate) (site : C.gates[k]?=some q) (op : q.op=.not) :
      ¬ rises C.gates x y (10+k) := by
    have idx : k=pre.length := by
      by_contra diff
      have pos : q∈pre++post := by
        rw [r.split] at site
        by_cases lt : k<pre.length
        · apply List.mem_append_left
          exact List.mem_iff_getElem?.mpr ⟨k,by simpa [List.getElem?_append,lt] using site⟩
        · apply List.mem_append_right
          obtain ⟨a,ha⟩ : ∃ a,k=pre.length+(a+1) := ⟨k-pre.length-1,by omega⟩
          exact List.mem_iff_getElem?.mpr ⟨a,by simpa [ha,List.getElem?_append] using site⟩
      rcases r.pos q pos with e|e <;> simp_all
    subst k
    have v := (pair_physical_values r red.clean s t p tail full unary y).2
    have ys : y s=true := by simp [y,setOwners]
    rw [ys] at v
    exact fun h => Bool.noConfusion (h.2.symm.trans v)
  obtain ⟨k,q,site,op,up,out,j,read,_,tag⟩ := rising_cut_exit C.gates red.clean x y Z C.output ups notZ raw noInv
  have mem := List.mem_iff_getElem?.mpr ⟨k,site⟩
  have sj : s.val∈q.inputs := by
    rcases tag with eq|eq
    · simpa [eq] using read
    · exact (priv q mem op (eq ▸ read)).elim
  have nk : k≠p.length := by intro e; exact out (Or.inr (by omega))
  have ext : q∈p++tail := by
    rw [full] at site
    by_cases lt : k<p.length
    · apply List.mem_append_left
      exact List.mem_iff_getElem?.mpr ⟨k,by simpa [List.getElem?_append,lt] using site⟩
    · apply List.mem_append_right
      obtain ⟨a,ha⟩ : ∃ a,k=p.length+(a+1) := ⟨k-p.length-1,by omega⟩
      exact List.mem_iff_getElem?.mpr ⟨a,by simpa [ha,List.getElem?_append] using site⟩
  have andq : q.op=.and := by
    rcases op with a|o
    · exact a
    · have zc := (only_guard_or r cand red seven s t lo hi guard p tail full).1
      exact ((List.countP_eq_zero.mp zc q ext) (by simp [readsOr,FreeAndNet.CircuitCompiler.orFlag,o,sj])).elim
  refine ⟨k,q,site,andq,sj,?_⟩
  intro tj
  have hot := up.2
  rw [vl_gate _ red.clean _ k q site,andq] at hot
  have off : vl C.gates y t.val=false := by rw [vl_input _ _ _ t.isLt]; simp [y,setOwners,st.symm]
  simp [GateOp.eval,List.all_eq_true] at hot
  specialize hot _ tj
  simp_all
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.private_exclusive_owner
