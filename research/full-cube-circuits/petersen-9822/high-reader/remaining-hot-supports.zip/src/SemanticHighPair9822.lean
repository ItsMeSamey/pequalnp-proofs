import PairGuardClean9822
import PublicGuardReader9822
import AdjacentLiteralExcluded9822
import PublicNonadjacent9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport AdjacentCut
open PEqualNP.Outside.L_meta_9822.Clean
theorem adjacent_hot_pair_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s t : Fin 10) (shape : (s,t)∈([(5,7),(5,8),(6,8)] : List (Fin 10×Fin 10)))
    (hs : innerValue pre g (SignedClamp.singleton s)=true) (ht : innerValue pre g (SignedClamp.singleton t)=true) : False := by
  have range : s≠t ∧ 5≤s.val ∧ s.val≤8 ∧ 5≤t.val ∧ t.val≤8 := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  obtain ⟨st,sl,su,tl,tu⟩ := range
  obtain ⟨D,p,q,rd,dc,dr,axes,idx,_,_⟩ := normalized_hot_pair r cand red seven s t st sl su tl tu hs ht
  exact adjacent_literal_impossible rd dc dr (by omega) s t shape p (q++g::post)
    (by simpa only [List.append_assoc,List.cons_append] using rd.split) idx
theorem public_nonadjacent_hot_pair_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s t : Fin 10) (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (Fin 10×Fin 10)))
    (hs : innerValue pre g (SignedClamp.singleton s)=true) (ht : innerValue pre g (SignedClamp.singleton t)=true)
    (i : Nat) (pin : g.inputs.head?=some i) (w : Gate) (mem : w∈C.gates)
    (op : PositiveOp w) (reader : i∈w.inputs) : False := by
  have range : s≠t ∧ 5≤s.val ∧ s.val≤8 ∧ 5≤t.val ∧ t.val≤8 := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  obtain ⟨st,sl,su,tl,tu⟩ := range
  obtain ⟨D,p,q,rd,dc,dr,axes,idx,guard,_,keep⟩ := normalized_hot_pair r cand red (by omega) s t st sl su tl tu hs ht
  rw [idx] at pin
  have e : 10+p.length=i := by simpa using pin
  have whole : D.gates=p++literalGate s t::(q++g::post) := by simpa only [List.append_assoc,List.cons_append] using rd.split
  have read : 10+p.length∈w.inputs := e.symm ▸ reader
  have dw := keep w mem read
  have kind := public_guard_reader_and rd dc dr (by omega) s t sl su guard p (q++g::post) whole w dw op read
  exact public_nonadjacent_impossible rd dc dr (axes.trans seven) s t shape guard p (q++g::post)
    whole idx (by simp) w dw kind read
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.adjacent_hot_pair_impossible
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.public_nonadjacent_hot_pair_impossible
