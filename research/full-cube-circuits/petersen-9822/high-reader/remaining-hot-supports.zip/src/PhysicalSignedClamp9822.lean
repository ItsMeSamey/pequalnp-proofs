import SignedClamp9822
import CleanSteps9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean

def PositiveOp (g : Gate) : Prop := g.op = .and ∨ g.op = .or

def WireLE (a b : List Bool) : Prop :=
  a.length = b.length ∧ ∀ j, a.getD j false = true → b.getD j false = true

theorem wireLE_snoc {a b : List Bool} {p q : Bool} (h : WireLE a b)
    (pq : p = true → q = true) : WireLE (a ++ [p]) (b ++ [q]) := by
  obtain ⟨hl, h⟩ := h
  refine ⟨by simp [hl], ?_⟩
  intro j
  by_cases e : j = a.length
  · rw [getD_snoc_len _ _ _ _ e.symm, getD_snoc_len _ _ _ _ (hl.symm.trans e.symm)]
    exact pq
  · rw [getD_snoc_ne _ _ _ _ e, getD_snoc_ne _ _ _ _ (fun k => e (k.trans hl.symm))]
    exact h j

private theorem opLE {a b : List Bool} (h : WireLE a b) (g : Gate) (ok : PositiveOp g) :
    g.op.eval (g.inputs.map fun j => a.getD j false) = true →
    g.op.eval (g.inputs.map fun j => b.getD j false) = true := by
  rcases ok with hAnd | hOr
  · simp only [hAnd, GateOp.eval, List.all_map, Function.comp_def, id_eq, List.all_eq_true]
    intro hA j hj
    exact h.2 j (hA j hj)
  · simp only [hOr, GateOp.eval, List.any_map, Function.comp_def, id_eq, List.any_eq_true]
    rintro ⟨j, hj, v⟩
    exact ⟨j, hj, h.2 j v⟩

theorem phase_mono (gs : List Gate) (ok : ∀ g ∈ gs, PositiveOp g) {a b : List Bool}
    (h : WireLE a b) : WireLE (wiresFrom gs a) (wiresFrom gs b) := by
  induction gs generalizing a b with
  | nil => exact h
  | cons g gs ih =>
    exact ih (fun q hq => ok q (List.mem_cons_of_mem g hq))
      (wireLE_snoc h (opLE h g (ok g List.mem_cons_self)))

theorem split_count_one (gs : List Gate) (hc : gs.countP countsNot = 1) :
    ∃ pre g tail, gs = pre ++ g :: tail ∧ g.op = .not ∧
      pre.countP countsNot = 0 ∧ tail.countP countsNot = 0 := by
  induction gs with
  | nil => simp at hc
  | cons a gs ih =>
    cases ha : countsNot a with
    | true =>
      have htail : gs.countP countsNot = 0 := by
        rw [List.countP_cons_of_pos (p := countsNot) ha] at hc
        omega
      have hn : a.op = .not := by
        cases a with
        | mk op ins => cases op <;> simp_all [countsNot]
      exact ⟨[], a, gs, rfl, hn, rfl, htail⟩
    | false =>
      have htail : gs.countP countsNot = 1 := by simpa [List.countP_cons, ha] using hc
      obtain ⟨p, g, t, eq, hn, hz, ht⟩ := ih htail
      exact ⟨a :: p, g, t, by simp [eq], hn, by simp [List.countP_cons,ha,hz], ht⟩

def innerValue (pre : List Gate) (g : Gate) (x : Input) : Bool :=
  (g.inputs.map fun j => (wiresFrom pre (List.ofFn x)).getD j false).headD false

def outerValue (pre tail : List Gate) (out : Nat) (x : Input) (z : Bool) : Bool :=
  (wiresFrom tail (wiresFrom pre (List.ofFn x) ++ [z])).getD out false

theorem physical_cut_split {C : Circuit} (cand : Candidate C)
    {pre tail : List Gate} {g : Gate} (decomp : C.gates = pre ++ g :: tail)
    (inv : g.op = .not) (pos : ∀ a ∈ tail, PositiveOp a) :
    ComputesCut (innerValue pre g) (outerValue pre tail C.output) := by
  apply ofCandidate cand
  · intro x
    change _ = (wiresFrom C.gates (List.ofFn x)).getD C.output false
    rw [decomp,wiresFrom_append]
    change _ = (wiresFrom tail (wiresFrom pre (List.ofFn x) ++
      [g.op.eval (g.inputs.map fun j => (wiresFrom pre (List.ofFn x)).getD j false)])).getD _ false
    rw [inv]
    rfl
  · intro x
    apply (phase_mono tail pos (wireLE_snoc (a := wiresFrom pre (List.ofFn x))
      (b := wiresFrom pre (List.ofFn x)) ⟨rfl, fun _ h => h⟩ (p:=false) (q:=true)
      (fun _ => rfl))).2 C.output

private theorem no_inverse {gs : List Gate} (n : gs.countP countsNot = 0)
    {g : Gate} (mem : g ∈ gs) : countsNot g = false := by
  induction gs with
  | nil => simp at mem
  | cons h t ih =>
    cases e : countsNot h with
    | true => simp [List.countP_cons,e] at n
    | false =>
      have nt : t.countP countsNot = 0 := by simpa [List.countP_cons,e] using n
      rcases List.mem_cons.mp mem with eq | inside
      · simpa [eq] using e
      · exact ih nt inside

theorem physical_cut_positive_lists {C : Circuit} (cand : Candidate C)
    (one : C.gates.countP countsNot = 1) :
    ∃ pre g tail, C.gates = pre ++ g :: tail ∧ g.op = .not ∧
      (∀ a ∈ pre, PositiveOp a) ∧ (∀ a ∈ tail, PositiveOp a) ∧
      ComputesCut (innerValue pre g) (outerValue pre tail C.output) := by
  obtain ⟨pre,g,tail,he,hn,hp,ht⟩ := split_count_one _ one
  have positive (a : Gate) (member : a ∈ C.gates) (no : countsNot a = false) :
      PositiveOp a := by
    have allowed := (cand.1 a member).1
    change a.op = .and ∨ a.op = .or ∨ a.op = .not at allowed
    rcases allowed with left | mid | right
    · exact Or.inl left
    · exact Or.inr mid
    · simp [countsNot,right] at no
  have ppre : ∀ a ∈ pre, PositiveOp a := by
    intro a ha
    exact positive a (by rw [he]; exact List.mem_append_left _ ha) (no_inverse hp ha)
  have ptail : ∀ a ∈ tail, PositiveOp a := by
    intro a ha
    exact positive a (by rw [he]; exact List.mem_append_right _ (List.mem_cons_of_mem _ ha)) (no_inverse ht ha)
  exact ⟨pre,g,tail,he,hn,ppre,ptail,physical_cut_split cand he hn ptail⟩

theorem physical_cut_of_one {C : Circuit} (cand : Candidate C)
    (one : C.gates.countP countsNot = 1) :
    ∃ pre g tail, C.gates = pre ++ g :: tail ∧ g.op = .not ∧
      ComputesCut (innerValue pre g) (outerValue pre tail C.output) := by
  obtain ⟨pre,g,tail,he,hn,_,_,h⟩ := physical_cut_positive_lists cand one
  exact ⟨pre,g,tail,he,hn,h⟩

end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
