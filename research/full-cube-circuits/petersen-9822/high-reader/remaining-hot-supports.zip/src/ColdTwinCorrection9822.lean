import SignedClamp9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp

private theorem private_neighbor :
    ∀ a b : Fin 10, a ≠ b → edge (pair a b) = false →
      ∃ x : Fin 10, x ≠ a ∧ x ≠ b ∧ edge (pair a x) = true ∧ edge (pair b x) = false := by
  decide +kernel

theorem twin_corrections {H K} (cut : ComputesCut H K) (a b : Fin 10)
    (ne : a ≠ b) (miss : K (pair a b) true = false)
    (twins : ∀ x, K (pair a x) true = K (pair b x) true) :
    ∃ x y : Fin 10, edge (pair a y) = false ∧ edge (pair b x) = false ∧
      H (pair a y) = true ∧ H (pair b x) = true ∧
      (∀ j, pair a y j = true → pair b x j = false) := by
  have nonedge : edge (pair a b) = false := by
    cases h : edge (pair a b) with
    | false => rfl
    | true => have bad := positive_upper cut _ h; rw [miss] at bad; contradiction
  have swap : pair b a = pair a b := by funext j; exact Bool.or_comm _ _
  obtain ⟨x,xa,xb,ax,bx⟩ := private_neighbor a b ne nonedge
  obtain ⟨y,yb,ya,byes,ay⟩ := private_neighbor b a ne.symm ((congrArg edge swap).trans nonedge)
  have force {z : Input} (no : edge z=false) (on : K z true=true) : H z=true := by
    cases h : H z with
    | true => rfl
    | false =>
      have actual := cut.computes z
      simp [h,no,on] at actual
  have xy : x ≠ y := by intro eq; subst y; rw [ay] at ax; contradiction
  refine ⟨x,y,ay,bx,force ay ((twins y).trans (positive_upper cut _ byes)),
    force bx ((twins x).symm.trans (positive_upper cut _ ax)),?_⟩
  intro j hj
  have two : j=a ∨ j=y := by simpa [pair,singleton] using hj
  rcases two with rfl|rfl
  · simp [pair,singleton,ne,xa.symm]
  · simp [pair,singleton,yb,xy.symm]

theorem twins_exclude_raw_factor {H K} (cut : ComputesCut H K) (a b : Fin 10)
    (ne : a ≠ b) (miss : K (pair a b) true = false)
    (twins : ∀ x, K (pair a x) true = K (pair b x) true)
    (r : Fin 10) (factor : ∀ z : Input, H z = true → z r = true) : False := by
  obtain ⟨x,y,_,_,ay,bx,apart⟩ := twin_corrections cut a b ne miss twins
  have zero := apart r (factor _ ay)
  rw [factor _ bx] at zero
  contradiction
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.twins_exclude_raw_factor
