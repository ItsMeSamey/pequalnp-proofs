import CleanMin9822

namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

theorem Reduced.retimed {n old out gates cursor} (base : Reduced n old out)
    (legal : CleanL n gates) (size : gates.length ≤ old.length)
    (value : ∀ x : Fin n → Bool, vl gates x cursor = vl old x out)
    (varies : ∃ x y : Fin n → Bool, vl old x out ≠ vl old y out) :
    Reduced n gates cursor ∧ gates.length = old.length := by
  have lower (gs : List Gate) (o : Nat) (hc : CleanL n gs)
      (eq : ∀ x : Fin n → Bool, vl gs x o = vl old x out) : old.length ≤ gs.length :=
    base.noSmaller ⟨gs,o⟩ (fun g hg => (clean_nok _ _ hc g hg).1) eq
  have same := Nat.le_antisymm size (lower gates cursor legal value)
  obtain ⟨x,y,ne⟩ := varies
  have nonconstant : ∃ x y : Fin n → Bool, vl gates x cursor ≠ vl gates y cursor :=
    ⟨x,y,by simpa only [value] using ne⟩
  have noDrop : ¬ ∃ gs o, CleanL n gs ∧ gs.length+1 ≤ gates.length ∧
      ∀ x : Fin n → Bool, vl gs x o = vl gates x cursor := by
    rintro ⟨gs,o,hc,short,h⟩
    have hmin := lower gs o hc (fun v => (h v).trans (value v))
    omega
  refine ⟨⟨legal,?_,?_,?_,?_⟩,same⟩
  · intro p hp
    by_contra bad
    push Not at bad
    exact noDrop (drop_dead n gates legal cursor p hp bad.1 bad.2 nonconstant)
  · intro p hp b h
    obtain ⟨g,hg⟩ : ∃ g, gates[p]? = some g := ⟨gates[p],List.getElem?_eq_getElem hp⟩
    obtain ⟨pre,post,rfl,rfl⟩ := split_at gates p g hg
    apply noDrop
    apply drop_core n pre g post legal cursor (Sum.inl b) _ nonconstant
    intro v
    exact ⟨trivial,(h v).symm⟩
  · intro p hp j hj eq
    exact noDrop (drop_alias n gates legal cursor p j hp hj eq nonconstant)
  · intro t h
    have eqf : (fun x => vl gates x cursor) = fun x : Fin n → Bool => vl old x out := funext value
    rw [eqf] at h
    rw [same]
    exact base.minimum t h

theorem noImprovingRetime {n bound : Nat} {f : (Fin n → Bool) → Bool}
    (score : List Gate → Nat → Nat) {old out} (base : Reduced n old out)
    (size : old.length ≤ bound) (computes : ∀ x, vl old x out = f x)
    (varies : ∃ x y, f x ≠ f y)
    (least : ∀ gs o, Reduced n gs o → gs.length ≤ bound → (∀ x, vl gs x o = f x) →
      score old out ≤ score gs o)
    {gates cursor} (legal : CleanL n gates) (cost : gates.length ≤ old.length)
    (agree : ∀ x : Fin n → Bool, vl gates x cursor = vl old x out)
    (decrease : score gates cursor < score old out) : False := by
  obtain ⟨x,y,ne⟩ := varies
  have rebuilt := (base.retimed legal cost agree ⟨x,y,by simpa only [computes] using ne⟩).1
  exact (Nat.not_lt_of_ge (least gates cursor rebuilt (cost.trans size)
    (fun v => (agree v).trans (computes v)))) decrease
end PEqualNP.Outside.L_meta_9822.Clean
#print axioms PEqualNP.Outside.L_meta_9822.Clean.noImprovingRetime
