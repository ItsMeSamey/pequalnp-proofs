import FinalStatus9822
import PhysicalDeletion9822
import PairGuardReplace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean ReaderDebit
theorem raw_zero_status (C : Circuit) (S : Finset V) (i : V) (hi : i∈S) :
    (foldZero C S).1.getD i.val (Sum.inl false)=Sum.inl false := by
  rw [foldZero,final_get 10 C.gates (assignments S,[]) i.val (by simp [assignments])]
  change (assignments S).getD i.val (Sum.inl false)=Sum.inl false
  unfold assignments
  rw [getD_ofFn 10 _ _ i]
  simp [hi]
theorem literal_zero_status {C : Circuit} (s t : V) (p tail : List Gate)
    (whole : C.gates=p++literalGate s t::tail) :
    (foldZero C {s,t}).1.getD (10+p.length) (Sum.inl false)=Sum.inl false := by
  let S : Finset V := {s,t}
  let acc : List Stat × List Gate := (assignments S,[])
  have len : acc.1.length=10 := by simp [acc,assignments]
  have h := final_output_status 10 p tail (literalGate s t) acc
  have inp := final_inputs 10 p tail (literalGate s t) acc (by
    intro j hj
    simp [literalGate] at hj
    rcases hj with rfl|rfl <;> omega)
  dsimp only at h inp
  rw [inp,len] at h
  have a := raw_zero_status C S s (by simp [S])
  have b := raw_zero_status C S t (by simp [S])
  change (elim 10 C.gates acc).1.getD s.val _ = _ at a
  change (elim 10 C.gates acc).1.getD t.val _ = _ at b
  rw [←whole] at h
  change (elim 10 C.gates acc).1.getD (10+p.length) _ = _
  rw [h]
  simp only [literalGate,List.map_cons,List.map_nil,a,b]
  rfl

theorem neg_one_status {C : Circuit} (s t : V) (p tail pre post : List Gate) (g : Gate)
    (whole : C.gates=p++literalGate s t::tail) (split : C.gates=pre++g::post)
    (unary : g.inputs=[10+p.length]) (op : g.op=.not) (order : p.length<pre.length) :
    (foldZero C {s,t}).1.getD (10+pre.length) (Sum.inl false)=Sum.inl true := by
  let acc : List Stat × List Gate := (assignments {s,t},[])
  have len : acc.1.length=10 := by simp [acc,assignments]
  have h := final_output_status 10 pre post g acc
  have inp := final_inputs 10 pre post g acc (by
    intro j hj; rw [unary,List.mem_singleton] at hj;omega)
  dsimp only at h inp
  rw [inp,len,←split] at h
  have value := literal_zero_status s t p tail whole
  change (elim 10 C.gates acc).1.getD (10+p.length) _ = _ at value
  change (elim 10 C.gates acc).1.getD (10+pre.length) _ = _
  rw [h]
  simp only [op,unary,List.map_cons,List.map_nil,value]
  rfl
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.neg_one_status
