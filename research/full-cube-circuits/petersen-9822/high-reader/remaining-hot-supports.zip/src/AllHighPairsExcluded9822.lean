import PrivateAndReaderExcluded9822
import SemanticHighPair9822
import HighPairResidual9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport Deletion PEqualNP.Outside.L_meta_9822.Clean
theorem nonadjacent_hot_pair_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s t : Fin 10) (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (Fin 10×Fin 10)))
    (hs : innerValue pre g (SignedClamp.singleton s)=true)
    (ht : innerValue pre g (SignedClamp.singleton t)=true) : False := by
  classical
  have ranges : s≠t ∧ 5≤s.val ∧ s.val≤8 ∧ 5≤t.val ∧ t.val≤8 := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  obtain ⟨ds,sl,su,tl,tu⟩ := ranges
  obtain ⟨D,p,q,rd,dc,dr,ax,idx,guard,_,_⟩ := normalized_hot_pair r cand red (by omega) s t ds sl su tl tu hs ht
  let l := p++literalGate s t::q
  have whole : D.gates=p++literalGate s t::(q++g::post) := by simpa [List.append_assoc] using rd.split
  have ord : p.length<l.length := by simp [l]
  by_cases publicH : ∃ w∈D.gates, PositiveOp w ∧ 10+p.length∈w.inputs
  · obtain ⟨w,m,pos,pin⟩ := publicH
    have kind := public_guard_reader_and rd dc dr (by omega) s t sl su guard p (q++g::post) whole w m pos pin
    exact public_nonadjacent_impossible rd dc dr (ax.trans seven) s t shape guard p (q++g::post)
      whole idx ord w m kind pin
  · have priv : ∀w∈D.gates,PositiveOp w → 10+p.length∉w.inputs := fun w m po pin => publicH ⟨w,m,po,pin⟩
    let z := 10+l.length
    let read := ReaderDebit.reads z
    have hsD : innerValue (p++literalGate s t::q) g (SignedClamp.singleton s)=true :=
      (guard _).trans (by simp [SignedClamp.singleton])
    have cnt : post.countP read=1 := high_unique_reader rd dc (by omega) s sl su hsD dr
    obtain ⟨w,m,pin⟩ := List.countP_pos_iff.mp (by omega : 0<post.countP read)
    have wp : z∈w.inputs := by simpa [read,ReaderDebit.reads] using pin
    have orig : w∈D.gates := by rw [rd.split];simp [m]
    rcases rd.pos w (List.mem_append_right _ m) with a|o
    · exact private_and_reader_impossible s t shape rd dc dr idx priv guard (ax.trans seven) w orig a wp
    · exact private_or_reader_impossible s t shape rd dc dr idx priv guard (by omega) w m o wp
theorem no_two_high_singletons {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s t : Fin 10) (sl : 5≤s.val) (st : s.val<t.val) (tu : t.val≤8)
    (hs : innerValue pre g (SignedClamp.singleton s)=true)
    (ht : innerValue pre g (SignedClamp.singleton t)=true) : False :=
  nonadjacent_hot_pair_impossible r cand red seven s t
    (high_pair_residual r cand red seven s t sl st tu hs ht).1 hs ht
end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.no_two_high_singletons
