import TaggedCutTrace9822

namespace PEqualNP.Outside.L_meta_9822.Clean.GuardTags
open PEqualNP.CircuitLowerBounds FreeAndNet FreeAndNet.CircuitCompiler
open PEqualNP.Outside.L_meta_9822.Sectors.OuterNet

theorem model_tags (pre post : List Gate) (out : Nat)
    (ok : TaggedWiring 11 (cutCircuit pre post out).gates) :
    let trace := markedTrace out post (List.replicate (10+pre.length) false ++ [true])
    trace.1 = hits (0 : Fin 11) (model pre post out) ∧
      (trace.2 = true ↔ outUses (0 : Fin 11) (model pre post out)) := by
  let w := List.ofFn (fun i : Fin 11 => [i])
  have h := run_marks (out+1) (cutCircuit pre post out).gates w (0 : Fin 11) (by simpa [w] using ok)
  have flags : w.map (fun q => decide ((0 : Fin 11) ∈ q)) =
      true :: List.replicate 10 false := by decide +kernel
  have inputs : w.map some = List.ofFn (fun i : Fin 11 => some [i]) := by simp [w,List.map_ofFn]
  dsimp only at h
  rw [inputs,flags] at h
  have step := cut_prefix_tags pre post out (List.replicate 10 false) (by simp)
  change markedTrace _ _ _ = _ at step
  simpa only [cutCircuit,step,List.length_replicate,model,compile] using h

theorem one_physical_contact (pre post : List Gate) (out : Nat)
    (ok : TaggedWiring 11 (cutCircuit pre post out).gates)
    (one : hits (0 : Fin 11) (model pre post out) = 1)
    (cold : ¬outUses (0 : Fin 11) (model pre post out)) :
    markedTrace out post (List.replicate (10+pre.length) false ++ [true]) = (1,false) := by
  have facts := model_tags pre post out ok
  apply Prod.ext
  · exact facts.1.trans one
  · cases h : (markedTrace out post (List.replicate (10+pre.length) false ++ [true])).2
    · rfl
    · exact False.elim (cold (facts.2.mp h))

end PEqualNP.Outside.L_meta_9822.Clean.GuardTags
