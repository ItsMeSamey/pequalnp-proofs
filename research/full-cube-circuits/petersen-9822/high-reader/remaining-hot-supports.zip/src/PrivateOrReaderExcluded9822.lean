import PrivateOuterPhysical9822
import PrivateDoublePeel9822
import PairPhysicalFace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp LowHotElimination NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
open scoped Classical
theorem double_or_floor (D : Circuit) (cl : CleanL 10 D.gates) (pos : ∀q∈D.gates,PositiveOp q)
    (s t : V) (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V)))
    (fit : ∀x : Input,vl D.gates x D.output=edge (masked {s,t} x)) : 6≤D.gates.countP (ofOp .or) := by
  let n := FreeAndNet.CircuitCompiler.compile 10 D
  have spec (X : Finset V) : Research.OddOr.sees n X=PairFace.neg s t X := by
    change n.eval _=_
    rw [FreeAndNet.CircuitCompiler.compile_eval _ _ (fun q m => ⟨pos q m,(clean_nok _ _ cl q m).1.2⟩)]
    change vl D.gates _ D.output=_
    rw [fit]
    unfold masked PairFace.neg
    apply congrArg edge
    funext i
    by_cases hs : i=s <;> by_cases ht : i=t <;> simp [hs,ht]
  have lower : 6≤n.cost := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩
    · exact PairFace.floor56 n spec
    · exact PairFace.floor67 n spec
    · exact PairFace.floor78 n spec
  have flag : FreeAndNet.CircuitCompiler.orFlag=ofOp .or := by
    funext q; cases q with | mk op ins => cases op <;> simp [FreeAndNet.CircuitCompiler.orFlag,ofOp]
  have cost := FreeAndNet.CircuitCompiler.compile_cost 10 D
  rw [←List.countP_eq_length_filter,flag] at cost
  exact lower.trans cost
theorem private_or_reader_impossible {C p mid post g} (s t : V)
    (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V)))
    (r : Roster C (p++literalGate s t::mid) post g) (cand : Candidate C) (red : Reduced 10 C.gates C.output)
    (unary : g.inputs=[10+p.length]) (privateH : ∀q∈C.gates, PositiveOp q → 10+p.length∉q.inputs)
    (guard : ∀x : Input, innerValue (p++literalGate s t::mid) g x=(x s || x t))
    (seven : 7≤C.gates.countP countsAnd) (q : Gate) (m : q∈post) (op : q.op=.or)
    (read : 10+(p++literalGate s t::mid).length∈q.inputs) : False := by
  classical
  let mark := fun w : Gate => decide (w=q)
  have readers (w : Gate) (_ : w∈post) (h : mark w=true) : w.op=.or ∧ 10+(p++literalGate s t::mid).length∈w.inputs := by
    have e : w=q := of_decide_eq_true h
    subst w; exact ⟨op,read⟩
  obtain ⟨J,cl,pos,cap,hot,cold,_⟩ := private_outer s t r cand red unary privateH guard seven mark readers
  have diff : s≠t := by
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at shape
    rcases shape with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> decide
  obtain ⟨D,dc,dp,save,fit,_⟩ := double_peel J cl pos s t diff hot cold
  have floor := double_or_floor D dc dp s t shape fit
  have positive : 0<post.countP mark := List.countP_pos_iff.mpr ⟨q,m,by simp [mark]⟩
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.private_or_reader_impossible
