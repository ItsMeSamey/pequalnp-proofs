import OR9822ColdBase
import OR9822Finish

/- OR9822ColdFaces -/
namespace Research.OddOr.Envelope
open FreeAndNet Graph9822
set_option maxRecDepth 16000

theorem section_to_pentagon (e : Cycle5.V ↪ V) (xs : List V) (core : Finset V)
    (peel : Peel (fun x y => f {x,y} = true) xs core)
    (cover : ∀ j, e j ∈ core)
    (embedEdges : ∀ i j, Cycle5.f {i,j} = true → f {e i,e j} = true)
    (t : Net V) (fit : Fits (fun x y => f {x,y} = true) (xs.toFinset ∪ core) t) :
    4 + xs.length ≤ t.cost := by
  obtain ⟨v,debit,read⟩ := peel_trace peel e cover t fit
  have mem (i : Cycle5.V) : e i ∈ xs.toFinset ∪ core := Finset.mem_union_right _ (cover i)
  have h := any_pentagon_floor v ⟨fun i => by
    simpa using (read {i}).trans (by simpa using fit.1 (e i) (mem i)),by
    intro i j on
    rw [read]
    simp only [Finset.map_insert,Finset.map_singleton]
    exact fit.2 (e i) (mem i) (e j) (mem j) (embedEdges i j on)⟩
  omega

def ColdOff (i : V) (t : Net V) :=
  (∀ j : V, i ≠ j → sees t {j} = false) ∧
    (∀ j k : V, i ≠ j → i ≠ k → f {j,k} = true → sees t {j,k} = true)

theorem fits_off {i : V} {t : Net V} (h : ColdOff i t) {u : Finset V} (miss : i ∉ u) :
    Fits (fun x y => f {x,y} = true) u t := by
  have ne (j : V) (mem : j ∈ u) : i ≠ j := fun eq => miss (eq ▸ mem)
  exact ⟨fun j hj => h.1 j (ne j hj),fun j hj k hk ed => h.2 j k (ne j hj) (ne k hk) ed⟩

private def embedA : Cycle5.V ↪ V where
  toFun := fun i => ([0,4,3,8,5] : List V).get i
  inj' := by decide +kernel

private def embedB : Cycle5.V ↪ V where
  toFun := fun i => ([1,2,7,9,6] : List V).get i
  inj' := by decide +kernel

private theorem cold0 (t : Net V) (off : ColdOff 0 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedB [8,5,3,4] {1,2,7,9,6} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 3) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 7) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 4) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 9) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private theorem cold1 (t : Net V) (off : ColdOff 1 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedA [9,2,7,6] {0,4,3,8,5} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 4) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 7) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 5) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 8) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private theorem cold2 (t : Net V) (off : ColdOff 2 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedA [9,7,1,6] {0,4,3,8,5} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 4) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 5) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 6) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 8) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private theorem cold3 (t : Net V) (off : ColdOff 3 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedB [8,5,0,4] {1,2,7,9,6} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 5) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 0) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 4) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 9) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private theorem cold4 (t : Net V) (off : ColdOff 4 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedB [3,8,0,5] {1,2,7,9,6} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 8) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 5) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 5) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 7) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private theorem cold5 (t : Net V) (off : ColdOff 5 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedB [8,3,0,4] {1,2,7,9,6} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 3) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 4) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 4) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 9) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private theorem cold6 (t : Net V) (off : ColdOff 6 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedA [9,1,2,7] {0,4,3,8,5} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 4) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 2) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 7) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 5) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private theorem cold7 (t : Net V) (off : ColdOff 7 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedA [9,2,1,6] {0,4,3,8,5} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 4) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 1) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 6) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 8) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private theorem cold8 (t : Net V) (off : ColdOff 8 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedB [5,3,0,4] {1,2,7,9,6} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 0) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 4) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 4) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 9) (a := 1) (b := 2) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

private theorem cold9 (t : Net V) (off : ColdOff 9 t) : 8 ≤ t.cost := by
  refine section_to_pentagon embedA [7,2,1,6] {0,4,3,8,5} ?_ (by decide +kernel) (by decide +kernel) t (fits_off off (by decide +kernel))
  refine Peel.step (j := 2) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 1) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 6) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  refine Peel.step (j := 8) (a := 0) (b := 4) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
  exact Peel.done _

theorem eight_off (i : V) (t : Net V) (off : ColdOff i t) : 8 ≤ t.cost := by
  fin_cases i
  · exact cold0 t off
  · exact cold1 t off
  · exact cold2 t off
  · exact cold3 t off
  · exact cold4 t off
  · exact cold5 t off
  · exact cold6 t off
  · exact cold7 t off
  · exact cold8 t off
  · exact cold9 t off

end Research.OddOr.Envelope
#print axioms Research.OddOr.Envelope.eight_off

/- OR9822ColdTwin -/
namespace Research.OddOr.Envelope
open FreeAndNet Graph9822

def Twins (h : Finset V → Bool) := ∃ a b : V, a ≠ b ∧ h {a,b} = false ∧ ∀ x, h {a,x} = h {b,x}

theorem twin_at_nine (t : Net V) (cold : ∀ i : V, sees t {i} = false)
    (edges : ∀ i j, f {i,j} = true → sees t {i,j} = true) (cap : t.cost ≤ 9) : Twins (sees t) := by
  classical
  by_contra absent
  let h := sees t
  have empty : h ∅ = false := empty_cold t cold
  let g : GraphRows h := {
    walk := data.walk
    spans := data.spans
    steps := data.steps.imp (fun i j on => edges i j on)
    cold := empty
    singleton := cold
    neighbor := fun i => (data.neighbor i).imp (fun j on => edges i j on)
    diff := by
      intro a b ne miss
      by_contra! all
      exact absent ⟨a,b,ne,miss,all⟩
    avoiding := by
      intro i
      obtain ⟨x,y,hx,hy,on⟩ := data.avoiding i
      exact ⟨x,y,hx,hy,edges x y on⟩
    edges := data.edges
    hot := by
      intro j
      fin_cases j
      · exact edges 0 4 (by decide)
      · exact edges 1 2 (by decide)
      · exact edges 3 8 (by decide)
    meet := by
      have dis : ∀ j k : Fin 3, j ≠ k → data.edges j ∩ data.edges k = ∅ := by decide +kernel
      intro j k ne
      rw [dis j k ne]
      exact empty }
  have lower : 10 ≤ t.cost := by
    refine graph_raise g 8 ?_ t (fun _ => rfl)
    intro i v agrees
    apply eight_off i v
    constructor
    · intro j ne
      exact (agrees _ (by simpa using ne)).trans (cold j)
    · intro j k nj nk on
      exact (agrees _ (by simp [nj,nk])).trans (edges j k on)
  omega

theorem nine_if_cold (t : Net V) (cold : ∀ i : V, sees t {i} = false)
    (edges : ∀ i j, f {i,j} = true → sees t {i,j} = true) : 9 ≤ t.cost := by
  let i : V := 0
  have lower : 8 ≤ (pin i t).cost := by
    apply eight_off
    constructor
    · intro j ne
      exact (pin_sees _ _ _ (by simpa using ne)).trans (cold j)
    · intro j k nj nk on
      exact (pin_sees _ _ _ (by simp [nj,nk])).trans (edges j k on)
  obtain ⟨j,on⟩ := data.neighbor i
  obtain ⟨a,b,ha,hb,other⟩ := data.avoiding i
  have saved := positive_hit t (cold j) (edges i j on)
    (avoids_output t (by simp [ha,hb] : i ∉ ({a,b} : Finset V)) (edges a b other))
  have cost := pin_cost i t
  omega

end Research.OddOr.Envelope

namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open FreeAndNet Research.OddOr Research.OddOr.Graph9822 Research.OddOr.Envelope
open SignedClamp

theorem physical_cold_clamp_twins (C : Circuit) (cand : Candidate C)
    (pre post : List Gate) (g : Gate) (inv : g.op = .not)
    (split : C.gates = pre ++ g :: post) (positive : ∀ q ∈ pre ++ post, PositiveOp q)
    (cold : ∀ j : V, outerValue pre post C.output (inputOn {j}) true = false)
    (cap : (C.gates.filter CircuitCompiler.orFlag).length ≤ 9) :
    Twins (fun s => outerValue pre post C.output (inputOn s) true) := by
  obtain ⟨t,cost,read,major⟩ := force_one_net C cand pre post g inv split positive
  have ht := twin_at_nine t (fun j => (read _).trans (cold j))
    (fun i j on => major {i,j} on) (cost.trans cap)
  simpa only [Twins,read] using ht

theorem physical_cold_guard_twins (C : Circuit) (cand : Candidate C)
    (pre post : List Gate) (g : Gate) (inv : g.op = .not)
    (split : C.gates = pre ++ g :: post) (positive : ∀ q ∈ pre ++ post, PositiveOp q)
    (cold : ∀ j : V, innerValue pre g (inputOn {j}) = false)
    (cap : (C.gates.filter CircuitCompiler.orFlag).length ≤ 9) :
    Twins (fun s => outerValue pre post C.output (inputOn s) true) := by
  refine physical_cold_clamp_twins C cand pre post g inv split positive ?_ cap
  intro j
  have cut := physical_cut_split cand split inv (fun q hq => positive q (List.mem_append_right _ hq))
  have h := cut.computes (inputOn {j})
  rw [cold j] at h
  exact h.trans (data.singleton j)

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.physical_cold_clamp_twins
