import SynchronousPairNet9822
namespace Research.OddOr
open FreeAndNet
variable {α : Type} [DecidableEq α]
theorem peel_two_outputs {E : α → α → Prop} {xs : List α} {core : Finset α}
    (hc : Peel E xs core) (t : Net α) (h : Fits E (xs.toFinset ∪ core) t) (w : Net α) (sync : SameSites t w) :
    ∃ u p : Net α, SameSites u p ∧ u.cost + xs.length ≤ t.cost ∧
      (∀ s ⊆ core, sees u s = sees t s) ∧ ∀ s ⊆ core, sees p s = sees w s := by
  induction hc generalizing t w with
  | done core => exact ⟨t,w,sync,by simp,by simp,by simp⟩
  | @step i j a b xs core _ fresh hj ha hb e l ih =>
    let v := xs.toFinset ∪ core
    have hv : (i::xs).toFinset ∪ core = insert i v := by simp [v]
    rw [hv] at h
    have diff {q : α} (hq : q ∈ v) : i ≠ q := fun eq => fresh (eq ▸ hq)
    have miss : i ∉ ({a,b} : Finset α) := by simp [diff ha,diff hb]
    have hit := positive_hit t (h.1 j (Finset.mem_insert_of_mem hj))
      (h.2 i (by simp) j (Finset.mem_insert_of_mem hj) e)
      (avoids_output t miss (h.2 a (Finset.mem_insert_of_mem ha) b (Finset.mem_insert_of_mem hb) l))
    have fit : Fits E v (pin i t) := by
      constructor
      · intro q hq
        rw [pin_sees _ _ _ (by simp [diff hq])]
        exact h.1 q (Finset.mem_insert_of_mem hq)
      · intro q hq r hr er
        rw [pin_sees _ _ _ (by simp [diff hq,diff hr])]
        exact h.2 q (Finset.mem_insert_of_mem hq) r (Finset.mem_insert_of_mem hr) er
    obtain ⟨u,p,sp,hu,eq,ep⟩ := ih (pin i t) fit (pin i w) (sync.specialized (kill i))
    refine ⟨u,p,sp,?_,?_,?_⟩
    · have debit := pin_cost i t
      simp only [List.length_cons]
      omega
    · intro s hs
      rw [eq s hs]
      apply pin_sees
      exact fun hi => fresh (Finset.mem_union_right _ (hs hi))
    · intro s hs
      rw [ep s hs]
      apply pin_sees
      exact fun hi => fresh (Finset.mem_union_right _ (hs hi))
end Research.OddOr
