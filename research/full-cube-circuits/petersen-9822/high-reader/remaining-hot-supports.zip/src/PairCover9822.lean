import PairFace9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.PairFace
open FreeAndNet Research.OddOr LowPositive
def cover (a b : V) (s : Finset V) := !(neg a b (Finset.univ \ s))
theorem cover56 (t : Net V) (h : ∀ s, sees t s = cover 5 6 s) : 4 ≤ t.cost := by
  have steps : Steps (cover 5 6) [0,1,3,7] {2,4,8,9} := by
    refine Steps.step (lo := {1,2,3,7,8,9}) (other := {1,2,3,4,7,8,9}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {3,4,7,8,9}) (other := {2,3,4,7,8,9}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {2,4,7,9}) (other := {2,4,7,8,9}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {2,4,8}) (other := {2,4,8,9}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost steps t (fun s _ => h s)
  change u.cost + 4 ≤ t.cost at hp
  omega
theorem cover67 (t : Net V) (h : ∀ s, sees t s = cover 6 7 s) : 4 ≤ t.cost := by
  have steps : Steps (cover 6 7) [1,9,0,3] {2,4,5,8} := by
    refine Steps.step (lo := {0,3,4,5,8,9}) (other := {0,2,3,4,5,8,9}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {0,2,3,5,8}) (other := {0,2,3,4,5,8}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {2,3,4,8}) (other := {2,3,4,5,8}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {2,4,5}) (other := {2,4,5,8}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost steps t (fun s _ => h s)
  change u.cost + 4 ≤ t.cost at hp
  omega
theorem cover78 (t : Net V) (h : ∀ s, sees t s = cover 7 8 s) : 4 ≤ t.cost := by
  have steps : Steps (cover 7 8) [2,3,0,6] {1,4,5,9} := by
    refine Steps.step (lo := {0,3,4,5,6,9}) (other := {0,1,3,4,5,6,9}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {0,1,5,6,9}) (other := {0,1,4,5,6,9}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {1,4,6,9}) (other := {1,4,5,6,9}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Steps.step (lo := {1,4,5}) (other := {1,4,5,9}) ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Steps.done _
  obtain ⟨u,hp,_⟩ := steps_cost steps t (fun s _ => h s)
  change u.cost + 4 ≤ t.cost at hp
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.PairFace
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.PairFace.cover56
