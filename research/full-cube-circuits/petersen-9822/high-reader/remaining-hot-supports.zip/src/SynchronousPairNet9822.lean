import OuterNet9822

namespace FreeAndNet

inductive SameSites : {α : Type} → Net α → Net α → Prop where
  | out (p q : Product α) : SameSites (.out p) (.out q)
  | gate (a b : List α) {t u : Net (Option α)} (h : SameSites t u) :
      SameSites (.gate a b t) (.gate a b u)

theorem SameSites.same_cost {t u : Net α} (h : SameSites t u) : t.cost = u.cost := by
  induction h with
  | out => rfl
  | gate a b h ih => simp [Net.cost,ih]

theorem SameSites.specialized {t u : Net α} (h : SameSites t u)
    (s : α → Product β) : SameSites (specialize s t) (specialize s u) := by
  induction h generalizing β with
  | out => exact .out _ _
  | gate a b h ih =>
    cases ha : substProduct s a <;> cases hb : substProduct s b <;>
      simp only [specialize,ha,hb]
    all_goals first | apply SameSites.gate; apply ih | apply ih

namespace CircuitCompiler
open PEqualNP.CircuitLowerBounds
theorem run_same_sites (i j : Nat) (gs : List Gate) (w : List (Product α)) :
    SameSites (run i gs w) (run j gs w) := by
  induction gs generalizing α with
  | nil => exact .out _ _
  | cons g gs ih =>
    simp only [run]
    split
    · generalize w.getD (g.inputs.getD 0 w.length) none = p
      generalize w.getD (g.inputs.getD 1 w.length) none = q
      cases p <;> cases q <;> simp only [orStep]
      all_goals first | apply SameSites.gate; apply ih | apply ih
    · apply ih
end CircuitCompiler
end FreeAndNet
