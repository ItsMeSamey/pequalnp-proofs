import RisingOrFrontier9822
import PinStatusSignals9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean ReaderDebit
open scoped Classical
theorem monotone_physical_peel (C : Circuit) (cl : CleanL 10 C.gates)
    (pos : ∀ q∈C.gates,PositiveOp q) (s : V) (x y v : Input)
    (same : ∀ i, i≠s → x i=y i) (up : rises C.gates x y C.output)
    (on : vl C.gates (masked {s} v) C.output=true) :
    (foldZero C {s}).2.countP (fun q => decide (q.op=GateOp.or)) +1 ≤
      C.gates.countP (fun q => decide (q.op=GateOp.or)) := by
  classical
  let Z := fun i => (foldZero C {s}).1.getD i (Sum.inl false)=Sum.inl false
  have raw (j : Nat) (lt : j<10) (rj : rises C.gates x y j) : Z j := by
    let i : V := ⟨j,lt⟩
    by_cases e : i=s
    · exact raw_zero_status C {s} i (by simp [e])
    · obtain ⟨hx,hy⟩ := rj
      rw [vl_input _ _ _ lt] at hx hy
      exact Bool.noConfusion (hx.symm.trans ((same i e).trans hy))
  have out : ¬Z C.output := by
    intro z
    have inv := inv_elim 10 (List.ofFn v) (by simp) C.gates _ _
      (fun q m => (clean_nok _ _ cl q m).1) (pin_inv {s} v)
    have eq := (inv.2 C.output).2
    change ((foldZero C {s}).1.getD C.output _).val _ = vl C.gates (masked {s} v) C.output at eq
    change (foldZero C {s}).1.getD C.output _=Sum.inl false at z
    rw [z,on] at eq
    contradiction
  obtain ⟨k,q,site,op,_,_,j,jm,pin⟩ := rising_or_frontier C.gates cl x y Z C.output up out raw
    (fun k b atb andb => next_zero cl {s} k b atb andb)
    (fun k b atb notb => by
      obtain a|o := pos b (List.mem_iff_getElem?.mpr ⟨k,atb⟩)
      all_goals simp_all)
  let mark := fun w : Gate => decide (w=q)
  have cap := final_pin_debit 10 .or mark C.gates (assignments {s},[]) (by simpa [assignments] using cl)
    (fun w _ hit => by
      have e : w=q := of_decide_eq_true hit
      subst w
      exact ⟨op,j,jm,false,pin⟩)
  change (foldZero C {s}).2.countP _+C.gates.countP mark≤0+C.gates.countP _ at cap
  have nz : 0<C.gates.countP mark := List.countP_pos_iff.mpr ⟨q,List.mem_iff_getElem?.mpr ⟨k,site⟩,by simp [mark]⟩
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.monotone_physical_peel
