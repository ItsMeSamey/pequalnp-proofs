import GuardEmitterLedger9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
open PEqualNP.CircuitLowerBounds GuardTags
abbrev initReg : Reg := (false,zero)
def checked (gs : List Gate) : Prop :=
  ∀ g∈gs, (g.op=.and ∨ g.op=.or) ∧ ∃ i j, g.inputs=[i,j]
def block (n z : Nat) (rs : List Reg) (g : Gate) : Bool × Block :=
  let a := rs.getD (g.inputs.getD 0 rs.length) initReg
  let b := rs.getD (g.inputs.getD 1 rs.length) initReg
  actual n z g.op a b
def go (n z : Nat) (rs : List Reg) : List Gate → List Gate × List Reg
  | [] => ([],rs)
  | g::gs =>
    let k := block n z rs g
    let later := go (n+k.2.code.length) z (rs ++ [(k.1,k.2.result)]) gs
    (k.2.code ++ later.1,later.2)
def ValidRegs (n : Nat) (rs : List Reg) : Prop := ∀ x∈rs, x.2.Valid n
def evalReg (w : List Bool) (z : Nat) (r : Reg) := recover (w.getD z false) (meaning w r)
theorem valid_read {n : Nat} {rs : List Reg} (valid : ValidRegs n rs) (i : Nat) :
    (rs.getD i initReg).2.Valid n := by
  by_cases hi : i<rs.length
  · have eq : rs.getD i initReg = rs[i] := by simp [List.getD,hi]
    rw [eq]; exact valid _ (List.getElem_mem _)
  · rw [List.getD_eq_default _ _ (by omega)]
    trivial
theorem eval_later (w : List Bool) (z : Nat) (hz : z<w.length) (gs : List Gate)
    (r : Reg) (h : r.2.Valid w.length) : evalReg (wiresFrom gs w) z r = evalReg w z r := by
  simp only [evalReg,getD_wiresFrom _ _ _ hz,repair_later w gs r h]
theorem block_sound (w : List Bool) (z : Nat) (hz : z<w.length) (rs : List Reg) (g : Gate)
    (valid : ValidRegs w.length rs) (ok : g.op=.and ∨ g.op=.or) (i j : Nat) (ins : g.inputs=[i,j]) :
    let k := block w.length z rs g
    let add := (k.1,k.2.result)
    add.2.Valid (w.length+k.2.code.length) ∧
    evalReg (wiresFrom k.2.code w) z add =
      g.op.eval (g.inputs.map fun i => (rs.map (evalReg w z)).getD i false) := by
  let a := rs.getD i initReg
  let b := rs.getD j initReg
  let k := actual w.length z g.op a b
  have e : block w.length z rs g = k := by simp [block,ins,k,a,b]
  rw [e]
  obtain ⟨h,flag⟩ := actual_good g.op ok w z hz a b (valid_read valid i) (valid_read valid j)
  refine ⟨h.1,?_⟩
  have keep := emit_sound g.op ok (w.getD z false) [meaning w a,meaning w b]
  change recover ((wiresFrom k.2.code w).getD z false) (k.1,k.2.result.val _) = _
  rw [getD_wiresFrom _ _ _ hz,h.2,flag]
  have read (j : Nat) : (rs.map (evalReg w z)).getD j false = evalReg w z (rs.getD j initReg) := by
    exact List.getD_map (d:=initReg) (l:=rs) (n:=j) (evalReg w z)
  rw [ins]
  change _ = g.op.eval [(rs.map (evalReg w z)).getD i false,(rs.map (evalReg w z)).getD j false]
  rw [read i, read j]
  exact keep
theorem go_sound (gs : List Gate) (w : List Bool) (rs : List Reg) (z : Nat)
    (hz : z<w.length) (valid : ValidRegs w.length rs) (ok : checked gs) :
    let p := go w.length z rs gs
    ValidRegs (w.length+p.1.length) p.2 ∧
    p.2.map (evalReg (wiresFrom p.1 w) z) = wiresFrom gs (rs.map (evalReg w z)) := by
  induction gs generalizing w rs with
  | nil => exact ⟨by simpa [go] using valid,rfl⟩
  | cons g gs ih =>
    let k := block w.length z rs g
    let regs := rs ++ [(k.1,k.2.result)]
    let w' := wiresFrom k.2.code w
    have size : w'.length=w.length+k.2.code.length := length_wiresFrom _ _
    obtain ⟨hop,i,j,ins⟩ := ok g List.mem_cons_self
    obtain ⟨v,e⟩ := block_sound w z hz rs g valid hop i j ins
    change k.2.result.Valid (w.length+k.2.code.length) at v
    have vs : ValidRegs w'.length regs := by
      intro x hx
      rcases List.mem_append.mp hx with old|new
      · exact Stat.valid_mono (by omega) x.2 (valid x old)
      · have eq : x=(k.1,k.2.result) := by simpa using new
        simpa [eq,size] using v
    have step : regs.map (evalReg w' z) =
        (rs.map (evalReg w z)) ++ [g.op.eval (g.inputs.map fun i => (rs.map (evalReg w z)).getD i false)] := by
      unfold regs
      rw [List.map_append]
      congr 1
      · exact List.map_congr_left fun x hx => eval_later w z hz k.2.code x (valid x hx)
      · simpa using e
    have recursed := ih w' regs (by omega) vs (fun q hq => ok q (List.mem_cons_of_mem _ hq))
    rw [step] at recursed
    dsimp only [go]
    change ValidRegs (w.length + (k.2.code ++ _).length) _ ∧ _ = _
    rw [List.length_append,← Nat.add_assoc,← size,wiresFrom_append]
    exact recursed
end PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter.go_sound
