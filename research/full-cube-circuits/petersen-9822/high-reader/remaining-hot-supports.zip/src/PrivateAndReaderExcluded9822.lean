import PrivatePartnerProof9822
import PrivateProtectedLink9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp LowHotElimination NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
open scoped Classical
theorem private_and_reader_impossible {C p mid post g} (s t : V)
    (shape : (s,t)∈([(5,6),(6,7),(7,8)] : List (V×V)))
    (r : Roster C (p++literalGate s t::mid) post g) (cand : Candidate C) (red : Reduced 10 C.gates C.output)
    (unary : g.inputs=[10+p.length]) (privateH : ∀q∈C.gates, PositiveOp q → 10+p.length∉q.inputs)
    (guard : ∀x : Input, innerValue (p++literalGate s t::mid) g x=(x s || x t))
    (seven : C.gates.countP countsAnd=7) (z : Gate) (zm : z∈C.gates) (za : z.op=.and)
    (zr : 10+(p++literalGate s t::mid).length∈z.inputs) : False := by
  let pre := p++literalGate s t::mid
  let tail := mid++g::post
  have ord : p.length<pre.length := by simp [pre]
  have whole : C.gates=p++literalGate s t::tail := by simpa [tail,List.append_assoc] using r.split
  have noOr (q : Gate) (m : q∈C.gates) (o : q.op=.or) (read : 10+pre.length∈q.inputs) : False := by
    obtain ⟨k,site⟩ := List.mem_iff_getElem?.mp m
    have before := (red.clean k q site).lt _ read
    obtain ⟨l,ll⟩ : ∃l,k=pre.length+(l+1) := ⟨k-pre.length-1,by omega⟩
    have postsite : post[l]?=some q := by
      rw [r.split] at site
      change (pre++g::post)[k]?=some q at site
      simpa [ll,List.getElem?_append] using site
    exact private_or_reader_impossible s t shape r cand red unary privateH guard (by omega) q
      (List.mem_iff_getElem?.mpr ⟨l,postsite⟩) o read
  obtain ⟨k,a,site,aa,sa,sole⟩ := private_owner_roster r cand red seven s t shape guard p tail whole unary ord privateH z zm za zr
  have ma := List.mem_iff_getElem?.mpr ⟨k,site⟩
  have partner : ∃j : Nat,j≠s.val ∧ j∈a.inputs := by
    rcases red.clean k a site with ⟨no,_⟩|⟨_,i,j,_,_,pins⟩
    · simp_all
    have ne := distinct_and_pins red k a site aa i j pins
    simp only [pins,List.mem_cons,List.not_mem_nil,or_false] at sa ⊢
    rcases sa with l|l
    · exact ⟨j,by omega,Or.inr rfl⟩
    · exact ⟨i,by omega,Or.inl rfl⟩
  obtain ⟨j,js,jm⟩ := partner
  have jh : j≠10+p.length := fun e => privateH a ma (Or.inl aa) (e ▸ jm)
  have jz : j≠10+pre.length := by
    intro e
    exact ((no_pair_and_overlap r red s t p tail whole unary ord a k site aa).2 (e ▸ jm)).1 sa
  have ignore (q : Gate) (m : q∈mid++post) : 10+p.length∉q.inputs := by
    have posmem : q∈pre++post := by simp only [pre,List.mem_append,List.mem_cons] at m ⊢;tauto
    have orig : q∈C.gates := by rw [r.split];simp only [pre,List.mem_append,List.mem_cons] at posmem ⊢;tauto
    exact privateH q orig (r.pos q posmem)
  have off := (clamp_matches (h:=literalGate s t) j (fun _=>false) ignore jh).trans
    ((phase_at_actual s t r guard j).trans (quiet_except r red noOr j jz))
  let v : Input := masked {s,t} (fun _ => true)
  have vs : v s=false := by simp [v,masked]
  have vt : v t=false := by simp [v,masked]
  have trueOut : vl C.gates v C.output=true := (cand.2.2 v).trans (positive_off_two s t)
  have oh : C.output≠10+p.length := by
    intro e
    rw [e,(pair_physical_values r red.clean s t p tail whole unary v).1,vs,vt] at trueOut
    contradiction
  have os : C.output≠s.val := by intro e;rw [e,vl_input _ _ _ s.isLt,vs] at trueOut;contradiction
  have cut := physical_cut_split cand r.split r.inv (fun q m => r.pos q (List.mem_append_right _ m))
  have gh (x : Input) (on : edge x=true) : vl (ghost p mid post) x C.output=true :=
    (ghost_matches (h:=literalGate s t) _ x ignore oh).trans (SignedClamp.positive_upper cut x on)
  have gc (x : Input) (h : x s=false) (l : x t=false) : vl (ghost p mid post) x C.output=edge x := by
    rw [ghost_matches (h:=literalGate s t) _ x ignore oh]
    have eq := cut.computes x
    simpa only [guard,h,l,Bool.false_or,Bool.not_false] using eq
  have touch (q : Gate) (m : q∈ghost p mid post) (pin : s.val∈q.inputs) : q.op=.and ∧ j∈q.inputs := by
    have ext : q∈p++tail := by
      simp only [ghost,List.mem_append,List.mem_cons] at m
      rcases m with m|m|m|m|m
      · exact List.mem_append_left _ m
      · subst q; simp at pin
      · simp [tail,m]
      · subst q; simp at pin
      · simp [tail,m]
    have qa := sole q ext pin
    exact qa.symm ▸ ⟨aa,jm⟩
  exact private_protected_link s t shape r cand red unary privateH guard (by omega) j off
    (ghost_partner_warm p mid post s t j C.output js os touch gh gc)
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.private_and_reader_impossible
