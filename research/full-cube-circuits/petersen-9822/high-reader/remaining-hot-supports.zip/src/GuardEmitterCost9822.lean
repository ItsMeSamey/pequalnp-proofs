import GuardEmitterRun9822
import GuardContactEquations9822
namespace PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
open PEqualNP.CircuitLowerBounds GuardTags FreeAndNet.CircuitCompiler
theorem go_cost (gs : List Gate) (n z source out : Nat) (rs : List Reg)
    (within : source<rs.length) (found : rs.getD source initReg=(true,top)) (ok : checked gs) :
    let m := contacts out gs (rs.map Prod.fst)
    let p := go n z rs gs
    p.1.length + gs.countP (ReaderDebit.reads source) ≤ gs.length+m.1 ∧
      (p.2.getD out initReg).1=m.2 := by
  induction gs generalizing n rs with
  | nil =>
    refine ⟨by simp [go],?_⟩
    exact (List.getD_map (d:=initReg) (l:=rs) (n:=out) Prod.fst).symm
  | cons g gs ih =>
    obtain ⟨hop,i,j,ins⟩ := ok g List.mem_cons_self
    let a := rs.getD i initReg
    let b := rs.getD j initReg
    let k := actual n z g.op a b
    let regs := rs ++ [(k.1,k.2.result)]
    have ke : block n z rs g=k := by simp [block,ins,k,a,b]
    have recur := ih (n+k.2.code.length) regs (by dsimp [regs]; simp; omega)
      (by change (rs ++ [_]).getD _ _ = _; rw [List.getD_append _ _ _ _ within,found])
      (fun q hq => ok q (List.mem_cons_of_mem _ hq))
    let bits := rs.map Prod.fst
    let charge := firstCharge g.op a b
    have val (idx : Nat) : bits.getD idx false = (rs.getD idx initReg).1 :=
      List.getD_map (d:=initReg) (l:=rs) (n:=idx) Prod.fst
    have trace :
        contacts out (g::gs) bits =
        ((contacts out gs (regs.map Prod.fst)).1 + charge,
          (contacts out gs (regs.map Prod.fst)).2) := by
      have readBits : g.inputs.map (fun j => bits.getD j false) = [a.1,b.1] := by
        rw [ins]
        change [bits.getD i false,bits.getD j false] = _
        rw [val i,val j]
      have grow : regs.map Prod.fst = bits ++ [k.1] := by simp [regs,bits]
      simp only [contacts,readBits,grow]
      rcases hop with h|h <;>
        simp [h,orFlag,k,actual,firstCharge,charge,Bool.toNat]
    change (go n z rs (g::gs)).1.length + _ ≤ _ ∧ _
    rw [show contacts out (g::gs) (rs.map Prod.fst) = _ from trace]
    simp only [go,ke,List.length_append,List.length_cons]
    change (k.2.code.length + (go _ z regs gs).1.length) + _ ≤ _ ∧ _
    refine ⟨?_,recur.2⟩
    have rem := recur.1
    have pay : k.2.code.length ≤ 1+charge := site_cost _ _ _ hop _ _
    cases hit : ReaderDebit.reads source g with
    | false =>
      rw [List.countP_cons_of_neg (by simp [hit])]
      omega
    | true =>
      have mem : source∈g.inputs := of_decide_eq_true hit
      have src : a=(true,top) ∨ b=(true,top) := by
        rw [ins] at mem
        simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
        rcases mem with rfl|rfl
        · exact Or.inl found
        · exact Or.inr found
      have save : k.2.code.length ≤ charge := direct_cost _ _ _ hop _ _ src
      rw [List.countP_cons_of_pos hit]
      omega
end PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter
#print axioms PEqualNP.Outside.L_meta_9822.Clean.GuardEmitter.go_cost
