import PhysicalReaderDebit9822
namespace PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit
open PEqualNP.CircuitLowerBounds
theorem constant_fold (op : GateOp) (m : Nat) (xs : List Stat)
    (bound : xs.length ≤ 2) (unary : op=.not → xs.length≤1) (b : Bool) (present : Sum.inl b ∈ xs) :
    (simplify op m xs).1 = none := by
  rcases xs with _ | ⟨a, _ | ⟨c, _ | ⟨d,tail⟩⟩⟩
  · simp at present
  · simp only [List.mem_singleton] at present
    subst a
    cases op <;> simp [simplify,simpAnd,simpOr,simpNot]
  · simp only [List.mem_cons,List.not_mem_nil,or_false] at present
    rcases present with he | he
    · subst a
      cases c <;> cases op <;> simp_all [simplify,simpAnd,simpOr,simpNot]
    · subst c
      cases a <;> cases op <;> simp_all [simplify,simpAnd,simpOr,simpNot]
  · simp at bound

def touches (pins : Finset Nat) (g : Gate) : Bool := g.inputs.any fun j => decide (j∈pins)

theorem elim_pins (n : Nat) (pins : Finset Nat) (gs : List Gate) (acc : List Stat × List Gate)
    (known : ∀ j∈pins, j < acc.1.length ∧ ∃ b : Bool, acc.1.getD j (Sum.inl false) = Sum.inl b)
    (ordinary : ∀ g ∈ gs, NOk g) :
    (elim n gs acc).2.length + gs.countP (touches pins) ≤ acc.2.length + gs.length := by
  induction gs generalizing acc with
  | nil => simp [elim]
  | cons g tail ih =>
    let next := elimStep n acc g
    have known' : ∀ j∈pins, j < next.1.length ∧ ∃ b : Bool, next.1.getD j (Sum.inl false) = Sum.inl b := by
      intro j hj
      obtain ⟨valid,b,pin⟩ := known j hj
      constructor
      · change j < (acc.1 ++ [_]).length
        simp; omega
      · refine ⟨b,?_⟩
        change (acc.1 ++ [_]).getD j (Sum.inl false) = Sum.inl b
        rwa [List.getD_append _ _ _ _ valid]
    have lower := ih next known' (fun a ha => ordinary a (List.mem_cons_of_mem _ ha))
    change (elim n tail next).2.length + _ ≤ _
    let ins := g.inputs.map fun i => acc.1.getD i (Sum.inl false)
    let emit := (simplify g.op (n+acc.2.length) ins).1
    have extra : next.2.length = acc.2.length + emit.toList.length := List.length_append ..
    cases hit : touches pins g with
    | false =>
      have bound := toList_length_le emit
      rw [List.countP_cons_of_neg (by simp [hit]),List.length_cons]
      omega
    | true =>
      have mem : ∃ j∈g.inputs,j∈pins := by simpa [touches,List.any_eq_true] using hit
      obtain ⟨j,mem,inside⟩ := mem
      obtain ⟨_,b,pin⟩ := known j inside
      have keep : Sum.inl b ∈ ins := by
        exact List.mem_map.mpr ⟨j,mem,pin⟩
      have ok := ordinary g List.mem_cons_self
      have drop : emit = none := constant_fold g.op _ ins (by simpa [ins] using ok.1.2)
        (fun h => by simpa [ins] using ok.2 h) b keep
      have gone : next.2.length = acc.2.length := by simpa [drop] using extra
      rw [List.countP_cons_of_pos hit,List.length_cons]
      omega
end PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit
#print axioms PEqualNP.Outside.L_meta_9822.Clean.ReaderDebit.elim_pins
