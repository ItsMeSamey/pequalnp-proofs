import GuardHotBudget9822
import ThreePositive9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open FreeAndNet Research.OddOr PEqualNP.CircuitLowerBounds
open SignedClamp NonrawSupport OuterNet PEqualNP.Outside.L_meta_9822.Clean

theorem high_pair_is_or {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (s t : Fin 10) (st : s ≠ t)
    (sl : 5 ≤ s.val) (su : s.val ≤ 8) (tl : 5 ≤ t.val) (tu : t.val ≤ 8)
    (hs : innerValue pre g (singleton s) = true) (ht : innerValue pre g (singleton t) = true) :
    ∀ v : Input, innerValue pre g v = (v s || v t) := by
  obtain ⟨a,read⟩ := guard_observer r cand hs
  let b := zeroNet pre post a
  have same : SameTrace (zeroNet pre post C.output) b := trace_specialize
    (compile_trace (C.output+1) (a+1) (cutCircuit pre post a).gates _) _
  have sc := (trace_count same (singleton s)).symm.trans (high_exactly_one r cand seven s sl su hs)
  have tc := (trace_count same (singleton t)).symm.trans (high_exactly_one r cand seven t tl tu ht)
  intro v
  have rise (i : Fin 10) (on : v i = true) (hot : innerValue pre g (singleton i) = true) :
      innerValue pre g v = true := by
    apply inner_mono_inputs (fun q hq => r.pos q (List.mem_append_left _ hq)) g _ hot
    intro j hj
    have eq : j=i := by simpa [SignedClamp.singleton] using hj
    simpa [eq] using on
  cases vs : v s <;> cases vt : v t
  · change innerValue pre g v = false
    cases hv : innerValue pre g v with
    | false => rfl
    | true =>
      have pairs (i : Fin 10) : PairImpl (singleton s i) (singleton t i) (v i) false := by
        by_cases is : i=s
        · subst i
          simp [PairImpl,SignedClamp.singleton,st,vs]
        · by_cases it : i=t
          · subst i
            simp [PairImpl,SignedClamp.singleton,is,vt]
          · simp [PairImpl,SignedClamp.singleton,is,it]
      have bound := disjoint_three_cost b (singleton s) (singleton t) v (fun _ => false) pairs
        ((read _).trans hs) ((read _).trans ht) ((read _).trans hv)
        ((read _).trans (cold_empty r cand seven))
      omega
  · exact rise t vt ht
  · exact rise s vs hs
  · exact rise s vs hs

end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.high_pair_is_or
