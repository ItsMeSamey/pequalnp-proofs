import PairFace9822
import PairGuardCandidate9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.PairFace
open FreeAndNet Research.OddOr LowPositive SignedClamp NonrawSupport OuterNet
open PEqualNP.CircuitLowerBounds

def twoZero (s t i : V) : Product V := if i=s ∨ i=t then none else some [i]
def folded (pre post : List Gate) (out : Nat) (s t : V) :=
  specialize (twoZero s t) (specialize (close true) (model pre post out))
def price (s t : V) : Nat :=
  if (s,t) ∈ ([(5,7),(5,8),(6,8)] : List (V × V)) then 7 else 6

theorem physical_floor {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (s t : V) (cases : (s,t) ∈ ([(5,6),(5,7),(5,8),(6,7),(6,8),(7,8)] : List (V × V)))
    (cold : ∀ v : Input, v s=false → v t=false → innerValue pre g v=false) :
    price s t ≤ (folded pre post C.output s t).cost := by
  let u := folded pre post C.output s t
  have fit (S : Finset V) : sees u S = neg s t S := by
    let v : Input := fun j => decide (j≠s ∧ j≠t ∧ j∈S)
    have eval : (fun j => pval (fun k => decide (k∈S)) (twoZero s t j)) = v := by
      funext j
      by_cases e : j=s <;> by_cases f : j=t <;> simp [twoZero,pval,v,e,f]
    have guard := cold v (by simp [v]) (by simp [v])
    have actual := (physical_cut_split cand r.split r.inv
      (fun a ha => r.pos a (List.mem_append_right _ ha))).computes v
    rw [guard] at actual
    change (specialize (twoZero s t) (specialize (close true) (model pre post C.output))).eval _ = _
    rw [eval_specialize,eval,eval_specialize,close_eval,model_eval r cand]
    exact actual
  change price s t ≤ u.cost
  simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at cases
  rcases cases with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
  · exact floor56 u fit
  · exact floor57 u fit
  · exact floor58 u fit
  · exact floor67 u fit
  · exact floor68 u fit
  · exact floor78 u fit
end PEqualNP.Outside.L_meta_9822.Sectors.PairFace
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.PairFace.physical_floor
