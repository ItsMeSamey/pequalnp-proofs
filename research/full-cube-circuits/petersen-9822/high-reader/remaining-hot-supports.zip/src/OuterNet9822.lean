import RawOwnerClamp9822
import NonrawSupport9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.OuterNet
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open FreeAndNet Research.OddOr PEqualNP.Outside.L_meta_9822.Clean
open SignedClamp NonrawSupport

def shift (a : Gate) : Gate := ⟨a.op,a.inputs.map Nat.succ⟩
def cutCircuit (pre post : List Gate) (out : Nat) : Circuit :=
  ⟨pre.map shift ++ ⟨.and,[0]⟩ :: post.map shift,out+1⟩
def env (x : Input) (z : Bool) : Fin 11 → Bool := Fin.cases z x

theorem shifted_wires (gs : List Gate) (z : Bool) (w : List Bool) :
    wiresFrom (gs.map shift) (z::w) = z :: wiresFrom gs w := by
  induction gs generalizing w with
  | nil => rfl
  | cons a rest ih =>
    change wiresFrom (rest.map shift) ((z::w) ++
      [a.op.eval ((a.inputs.map Nat.succ).map fun j => (z::w).getD j false)]) =
      z :: wiresFrom rest (w ++ [a.op.eval (a.inputs.map fun j => w.getD j false)])
    have eq : ((a.inputs.map Nat.succ).map fun j => (z::w).getD j false) =
        a.inputs.map fun j => w.getD j false := by simp [List.map_map,Function.comp_def,List.getD]
    rw [eq]
    apply ih

theorem cut_eval (pre post : List Gate) (out : Nat) (x : Input) (z : Bool) :
    (cutCircuit pre post out).eval (List.ofFn (env x z)) = outerValue pre post out x z := by
  have inputs : List.ofFn (env x z) = z :: List.ofFn x := by rw [List.ofFn_succ]; rfl
  change (wiresFrom (pre.map shift ++ (⟨.and,[0]⟩ : Gate) :: post.map shift) _).getD
      (out+1) false = _
  rw [inputs,wiresFrom_append,shifted_wires]
  cases z
  · change (wiresFrom (post.map shift) (false :: (wiresFrom pre (List.ofFn x) ++ [false]))).getD (out+1) false = _
    rw [shifted_wires]
    rfl
  · change (wiresFrom (post.map shift) (true :: (wiresFrom pre (List.ofFn x) ++ [true]))).getD (out+1) false = _
    rw [shifted_wires]
    rfl

def model (pre post : List Gate) (out : Nat) : Net (Fin 11) :=
  CircuitCompiler.compile 11 (cutCircuit pre post out)

theorem model_legal {C pre post g} (r : Roster C pre post g) (h : Candidate C) :
    Monotone2 (cutCircuit pre post C.output) := by
  intro a ha
  have ordinary (q : Gate) (hq : q ∈ pre ++ post) :
      PositiveOp q ∧ (shift q).inputs.length ≤ 2 := by
    have orig : q ∈ C.gates := by
      rw [r.split]
      rcases List.mem_append.mp hq with hp | ht
      · exact List.mem_append_left _ hp
      · exact List.mem_append_right _ (List.mem_cons_of_mem _ ht)
    exact ⟨r.pos q hq, by simpa [shift] using (h.1 q orig).2⟩
  rcases List.mem_append.mp ha with hp | ht
  · obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hp
    exact ordinary q (List.mem_append_left _ hq)
  · rcases List.mem_cons.mp ht with rfl | hp
    · exact ⟨Or.inl rfl,by decide⟩
    · obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hp
      exact ordinary q (List.mem_append_right _ hq)

theorem model_eval {C pre post g} (r : Roster C pre post g) (h : Candidate C) (x : Input) (z : Bool) :
    (model pre post C.output).eval (env x z) = outerValue pre post C.output x z :=
  (CircuitCompiler.compile_eval _ _ (model_legal r h) _).trans (cut_eval _ _ _ _ _)

theorem shift_cost (gs : List Gate) :
    ((gs.map shift).filter CircuitCompiler.orFlag).length =
      (gs.filter CircuitCompiler.orFlag).length := by
  induction gs with
  | nil => rfl
  | cons a gs ih =>
    cases a with
    | mk op ins => cases op <;> simp [shift,CircuitCompiler.orFlag,List.filter_cons] at ih ⊢ <;> omega

theorem model_cost {C pre post g} (r : Roster C pre post g) :
    (model pre post C.output).cost ≤ (C.gates.filter CircuitCompiler.orFlag).length := by
  apply (CircuitCompiler.compile_cost _ _).trans_eq
  rw [r.split]
  simp [cutCircuit, List.filter_append,shift_cost,CircuitCompiler.orFlag,r.inv]

end PEqualNP.Outside.L_meta_9822.Sectors.OuterNet
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.OuterNet.model_eval
