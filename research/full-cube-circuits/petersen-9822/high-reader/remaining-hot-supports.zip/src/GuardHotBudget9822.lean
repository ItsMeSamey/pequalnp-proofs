import LowHotElimination9822
import HighPositive9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
open FreeAndNet Research.OddOr PEqualNP.CircuitLowerBounds
open SignedClamp NonrawSupport OuterNet PEqualNP.Outside.L_meta_9822.Clean

abbrev zeroNet (pre post : List Gate) (out : Nat) :=
  specialize (close false) (model pre post out)

/-- Singleton traces of the cut residual have exact numerical bounds even if
the physical result shares every gate with the guard computation. -/
theorem singleton_budget {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10)
    (hot : innerValue pre g (SignedClamp.singleton i) = true) :
    LowPositive.pinPrice i + hotCount (SignedClamp.singleton i) (zeroNet pre post C.output) ≤ 8 := by
  let u := zeroNet pre post C.output
  let k := retire (LowPositive.setHigh i) u
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have exactOn (s : Finset (Fin 10)) : sees k s = LowPositive.pos i s := by
    let v : Input := fun j => decide (j=i ∨ j∈s)
    have on : innerValue pre g v = true := by
      apply inner_mono_inputs (fun q hq => r.pos q (List.mem_append_left _ hq)) g _ hot
      intro j hj
      have eq : j=i := by simpa [SignedClamp.singleton] using hj
      simp [v,eq]
    have actual := cut.computes v
    rw [on] at actual
    change (retire _ u).eval _ = _
    rw [retire_eval]
    have eq : (fun j => pval (fun z => decide (z∈s)) (LowPositive.setHigh i j)) = v :=
      funext (LowPositive.row_eval i s)
    rw [eq]
    change (specialize (close false) (model pre post C.output)).eval v = _
    rw [eval_specialize,close_eval,model_eval r cand]
    exact actual
  have price := LowPositive.pin_price i k exactOn
  have base : floorRow (LowPositive.setHigh i) = SignedClamp.singleton i := by
    funext j
    by_cases eq : j=i <;> simp [floorRow,LowPositive.setHigh,SignedClamp.singleton,eq,pval]
  have save := retire_cost (LowPositive.setHigh i) u
  rw [base] at save
  have cap : u.cost ≤ 8 := zero_debit r cand seven
  change LowPositive.pinPrice i ≤ (retire (LowPositive.setHigh i) u).cost at price
  change LowPositive.pinPrice i + hotCount (SignedClamp.singleton i) u ≤ 8
  omega

theorem plenty {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10)
    (hot : innerValue pre g (SignedClamp.singleton i) = true) :
    0 < hotCount (SignedClamp.singleton i) (zeroNet pre post C.output) := by
  let u := zeroNet pre post C.output
  obtain ⟨a,read⟩ := guard_observer r cand hot
  let b := specialize (close false) (model pre post a)
  have same : SameTrace u b := trace_specialize
    (compile_trace (C.output+1) (a+1) (cutCircuit pre post a).gates _) _
  obtain ⟨w,wi,_,hw⟩ := independent_witness r cand seven i
  have fire : 0 < hotCount (SignedClamp.singleton i) b := by
    by_contra! h
    have inter := intersection_when_cold b (SignedClamp.singleton i) w (fun _ => false) (by
      intro j hj hjw
      have eq : j=i := by simpa [SignedClamp.singleton] using hj
      rw [eq,wi] at hjw
      contradiction) (by omega) ((read _).trans hot) ((read _).trans hw)
    have cold := (read (fun _ => false)).trans (cold_empty r cand seven)
    change b.eval (fun _ => false) = false at cold
    rw [cold] at inter
    contradiction
  have sameHot := trace_count same (SignedClamp.singleton i)
  change 0 < hotCount (SignedClamp.singleton i) u
  omega

theorem high_exactly_one {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7 ≤ C.gates.countP countsAnd) (i : Fin 10)
    (lo : 5 ≤ i.val) (hi : i.val ≤ 8)
    (hot : innerValue pre g (SignedClamp.singleton i) = true) :
    hotCount (SignedClamp.singleton i) (zeroNet pre post C.output) = 1 := by
  have price := singleton_budget r cand seven i hot
  have positive := plenty r cand seven i hot
  have value : LowPositive.pinPrice i = 7 := by
    simp [LowPositive.pinPrice,show ¬ i.val ≤ 4 by omega,hi]
  omega

end PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.LowHotElimination.high_exactly_one
