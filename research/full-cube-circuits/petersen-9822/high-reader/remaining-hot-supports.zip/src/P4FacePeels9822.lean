import SynchronousPeel9822
import PairFace9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.PairFace
open FreeAndNet Research.OddOr
abbrev Vtx := Fin 10
def rel (s t i j : Vtx) := neg s t {i,j} = true
instance (s t i j : Vtx) : Decidable (rel s t i j) := inferInstanceAs (Decidable (neg s t {i,j} = true))

theorem steps56 : Peel (rel 5 6) [1,2,7,9] {0,4,3,8} := by
  apply Peel.step (j:=2) (a:=0) (b:=4) <;> try decide +kernel
  apply Peel.step (j:=7) (a:=0) (b:=4) <;> try decide +kernel
  apply Peel.step (j:=9) (a:=0) (b:=4) <;> try decide +kernel
  apply Peel.step (j:=4) (a:=0) (b:=4) <;> try decide +kernel
  exact Peel.done _

theorem steps78 : Peel (rel 7 8) [5,0,3,4] {2,1,6,9} := by
  apply Peel.step (j:=0) (a:=2) (b:=1) <;> try decide +kernel
  apply Peel.step (j:=4) (a:=2) (b:=1) <;> try decide +kernel
  apply Peel.step (j:=4) (a:=2) (b:=1) <;> try decide +kernel
  apply Peel.step (j:=9) (a:=2) (b:=1) <;> try decide +kernel
  exact Peel.done _

theorem pair_fit (s t : Vtx) (tgt : Net Vtx) (rep : ∀ z, sees tgt z = neg s t z)
    (D : Finset Vtx) : Fits (rel s t) D tgt := by
  constructor
  · intro i _
    rw [rep]
    exact (by decide +kernel : ∀ i s t : Vtx, neg s t {i} = false) i s t
  · intro i _ j _ h
    exact (rep _).trans h

end PEqualNP.Outside.L_meta_9822.Sectors.PairFace
