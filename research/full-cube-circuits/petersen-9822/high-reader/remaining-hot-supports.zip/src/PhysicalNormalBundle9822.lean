import CleanMin9822
import Sector9822

-- Normalize9822

namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

inductive Reaches (n : Nat) (gs : List Gate) : Nat → Nat → Prop
  | refl (w : Nat) : Reaches n gs w w
  | read {w q o} : Reads gs q w → Reaches n gs (n + q) o → Reaches n gs w o

theorem Reduced.reaches {n gs o} (hr : Reduced n gs o) (p : Nat)
    (hp : p < gs.length) : Reaches n gs (n+p) o := by
  rcases hr.live p hp with hout | ⟨q, hq⟩
  · rw [hout]; exact .refl _
  · have hlt := reads_lt hr.clean hq
    have hlen := reads_len hq
    exact .read hq (hr.reaches q hlen)
termination_by gs.length - p
decreasing_by omega

theorem Reduced.output_last {n gs o} (hr : Reduced n gs o) (h : 0 < gs.length) :
    o = n + (gs.length-1) := by
  rcases hr.live (gs.length-1) (by omega) with hout | ⟨q,hq⟩
  · exact hout
  · have := reads_lt hr.clean hq
    have := reads_len hq
    omega

theorem Reduced.shape {n gs o} (hr : Reduced n gs o) {p : Nat} {g : Gate}
    (hg : gs[p]? = some g) :
    (g.op = .not ∧ ∃ a, a < n+p ∧ g.inputs = [a]) ∨
    ((g.op = .and ∨ g.op = .or) ∧ ∃ a b, a < n+p ∧ b < n+p ∧ a ≠ b ∧ g.inputs = [a,b]) := by
  rcases hr.clean p g hg with hn | ⟨hop, a, b, ha, hb, hin⟩
  · exact Or.inl hn
  · refine Or.inr ⟨hop,a,b,ha,hb,?_,hin⟩
    intro eq
    subst b
    apply hr.noAlias p (List.getElem?_eq_some_iff.mp hg).1 a ha
    intro x
    rw [vl_gate gs hr.clean x p g hg, hin]
    rcases hop with hand | hor <;> simp [*, GateOp.eval]

def ports (gs : List Gate) : List ℕ := gs.flatMap Gate.inputs

lemma mem_ports {gs : List Gate} {w : ℕ} :
    w ∈ ports gs ↔ ∃ p, Reads gs p w := by
  simp only [ports, List.mem_flatMap, Reads]
  constructor
  · rintro ⟨g, hg, hw⟩
    obtain ⟨p, hp⟩ := List.mem_iff_getElem?.mp hg
    exact ⟨p,g,hp,hw⟩
  · rintro ⟨p,g,hp,hw⟩
    exact ⟨g,List.mem_iff_getElem?.mpr ⟨p,hp⟩,hw⟩

lemma agreement_without_read {n : Nat} {gs : List Gate} (hc : CleanL n gs) (u : Fin n)
    (hn : (u : ℕ) ∉ ports gs) (x y : Fin n → Bool) (hxy : ∀ v, v ≠ u → x v = y v) :
    ∀ w, w ≠ (u : ℕ) → vl gs x w = vl gs y w := by
  intro w
  induction w using Nat.strong_induction_on with
  | ind w ih =>
    intro hw
    by_cases hi : w < n
    · rw [vl_input gs x w hi, vl_input gs y w hi]
      exact hxy _ (fun e => hw (congrArg Fin.val e))
    by_cases hb : n + gs.length ≤ w
    · rw [vl_beyond gs x w hb, vl_beyond gs y w hb]
    let p := w - n
    have hp : p < gs.length := by dsimp [p]; omega
    have hwp : w = n + p := by dsimp [p]; omega
    have hg : gs[p]? = some gs[p] := List.getElem?_eq_getElem hp
    rw [hwp]
    apply vl_congr gs hc x y p _ hg
    intro t ht
    exact ih _ (by rw [hwp]; exact (hc p _ hg).lt t ht)
      (fun e => hn (mem_ports.mpr ⟨p,_,hg,e ▸ ht⟩))

end PEqualNP.Outside.L_meta_9822.Clean
#print axioms PEqualNP.Outside.L_meta_9822.Clean.Reduced.reaches
#print axioms PEqualNP.Outside.L_meta_9822.Clean.Reduced.shape

namespace PEqualNP.Outside.L_meta_9822.Sectors
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean


def active (xs : List (Fin 10)) (i : Fin 10) : Bool := xs.contains i

theorem inputWitness (i : Fin 10) :
    ∃ x y : Fin 10 → Bool, (∀ j, j ≠ i → x j = y j) ∧ edge x ≠ edge y := by
  have witnesses : ∀ u : Fin 10, ∃ v : Fin 10, edge (active [v]) ≠ edge (active [u,v]) := by
    decide +kernel
  obtain ⟨v,hv⟩ := witnesses i
  exact ⟨active [v],active [i,v],fun j hj => by simp [active,hj],hv⟩

theorem outputGate {gs : List Gate} {o : Nat} (h : ∀ x, vl gs x o = edge x) :
    10 ≤ o ∧ o < 10 + gs.length := by
  constructor
  · by_contra! ho
    let v : Fin 10 := ⟨o,ho⟩
    have hd : ∀ j : Fin 10, j ≠ j+1 := by decide +kernel
    obtain ⟨x,y,hxy,hn⟩ := inputWitness (v+1)
    apply hn
    rw [← h, ← h, vl_input gs x o ho, vl_input gs y o ho]
    exact hxy v (hd v)
  · by_contra! ho
    have ht := h (fun _ => true)
    rw [vl_beyond gs _ _ ho] at ht
    contradiction

theorem inputReaches {gs : List Gate} {o : Nat} (hr : Reduced 10 gs o)
    (h : ∀ x, vl gs x o = edge x) (i : Fin 10) : Reaches 10 gs i.val o := by
  have ho := (outputGate h).1
  have used : (i : Nat) ∈ ports gs := by
    by_contra hn
    obtain ⟨x,y,hxy,ne⟩ := inputWitness i
    apply ne
    rw [← h, ← h]
    exact agreement_without_read hr.clean i hn x y hxy o (by omega)
  obtain ⟨p,hp⟩ := mem_ports.mp used
  exact .read hp (hr.reaches p (reads_len hp))

/-- Every wire strictly before the output has at least one consumer. -/
theorem portSet {gs : List Gate} {o : Nat} (hr : Reduced 10 gs o)
    (h : ∀ x, vl gs x o = edge x) : (ports gs).toFinset = Finset.range o := by
  have hbound := outputGate h
  have last := hr.output_last (by omega)
  ext w
  simp only [List.mem_toFinset, Finset.mem_range]
  constructor
  · intro hw
    obtain ⟨q,hq⟩ := mem_ports.mp hw
    have := reads_lt hr.clean hq
    have := reads_len hq
    omega
  · intro hw
    by_cases hi : w < 10
    · let i : Fin 10 := ⟨w,hi⟩
      by_contra hn
      obtain ⟨x,y,hxy,ne⟩ := inputWitness i
      apply ne
      rw [← h, ← h]
      exact agreement_without_read hr.clean i hn x y hxy o (by change o ≠ w; omega)
    · let p := w-10
      have hp : w = 10+p := by dsimp [p]; omega
      rcases hr.live p (by omega) with hout | ⟨q,hq⟩
      · omega
      · exact mem_ports.mpr ⟨q,by rw [hp]; exact hq⟩

theorem portCount {gs : List Gate} (hc : CleanL 10 gs) :
    (ports gs).length + gs.countP countsNot = 2*gs.length := by
  have shape : ∀ g ∈ gs, g.inputs.length + (if countsNot g then 1 else 0) = 2 := by
    intro g hg
    obtain ⟨p,hp⟩ := List.mem_iff_getElem?.mp hg
    rcases hc p g hp with ⟨op,_,_,ins⟩ | ⟨op | op,_,_,_,_,ins⟩ <;>
      simp [countsNot,op,ins]
  clear hc
  induction gs with
  | nil => rfl
  | cons g gs ih =>
    have tail := ih (fun t ht => shape t (List.mem_cons_of_mem _ ht))
    have head := shape g List.mem_cons_self
    cases heq : countsNot g <;> simp [ports,List.countP_cons,heq] at head tail ⊢ <;> omega

theorem fanoutExcess {gs : List Gate} {o : Nat} (hr : Reduced 10 gs o)
    (h : ∀ x, vl gs x o = edge x) :
    ((ports gs).length - (ports gs).toFinset.card) + gs.countP countsNot + 9 = gs.length := by
  have bounds := outputGate h
  have last := hr.output_last (by omega)
  have count := portCount hr.clean
  have card : (ports gs).toFinset.card = o := by rw [portSet hr h, Finset.card_range]
  have leq := List.toFinset_card_le (ports gs)
  omega

lemma repeat_le_extra (l : List ℕ) :
    (l.toFinset.filter fun w => 2 ≤ l.count w).card ≤ l.length - l.toFinset.card := by
  classical
  have h := List.sum_toFinset_count_eq_length l
  have hle : ∑ w ∈ l.toFinset, (1 + if 2 ≤ l.count w then 1 else 0) ≤
      ∑ w ∈ l.toFinset, l.count w := by
    apply Finset.sum_le_sum
    intro w hw
    have hp : 0 < l.count w := List.count_pos_iff.mpr (List.mem_toFinset.mp hw)
    split_ifs <;> omega
  rw [h, Finset.sum_add_distrib] at hle
  rw [← Finset.sum_filter] at hle
  simp at hle
  omega

theorem repeatedBudget {gs : List Gate} {o : Nat} (hr : Reduced 10 gs o)
    (h : ∀ x, vl gs x o = edge x) (size : gs.length ≤ 17) :
    ((ports gs).toFinset.filter fun w => 2 ≤ (ports gs).count w).card +
      gs.countP countsNot ≤ 8 := by
  have := repeat_le_extra (ports gs)
  have := fanoutExcess hr h
  omega

theorem reducedCandidate (h : HasCircuitSize 10 edge 17) :
    ∃ C : Circuit, Candidate C ∧ Reduced 10 C.gates C.output := by
  have varied : ∃ x y, edge x ≠ edge y :=
    ⟨fun _ => false, fun _ => true, by decide⟩
  obtain ⟨gs,o,hr,bound,ev⟩ := reducedOf varied h
  refine ⟨⟨gs,o⟩,⟨?_,bound,ev⟩,hr⟩
  intro g hg
  obtain ⟨legal, fan⟩ := (clean_nok 10 gs hr.clean g hg).1
  exact ⟨by simpa only [Set.mem_insert_iff, Set.mem_singleton_iff] using legal, fan⟩

theorem ofReducedExclusions
    (monotone : ∀ C, Candidate C → Reduced 10 C.gates C.output →
      C.gates.countP countsNot = 0 → False)
    (one : ∀ C, Candidate C → Reduced 10 C.gates C.output →
      C.gates.countP countsNot = 1 → False)
    (many : ∀ C, Candidate C → Reduced 10 C.gates C.output →
      2 ≤ C.gates.countP countsNot → False) :
    ¬ HasCircuitSize 10 edge 17 := by
  intro h
  obtain ⟨C,hc,hr⟩ := reducedCandidate h
  by_cases hz : C.gates.countP countsNot = 0
  · exact monotone C hc hr hz
  by_cases ho : C.gates.countP countsNot = 1
  · exact one C hc hr ho
  exact many C hc hr (by omega)

end PEqualNP.Outside.L_meta_9822.Sectors
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.ofReducedExclusions

-- CleanClamp9822
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
/-- Replacing a paid gate by a constant must change the output of a minimum circuit. -/
def constGate (b : Bool) : Gate := ⟨if b then .and else .or, []⟩

theorem Reduced.clampChanges {n o} {pre post : List Gate} {g : Gate}
    (hr : Reduced n (pre ++ g :: post) o)
    (nonconst : ∃ x y : Fin n → Bool, vl (pre ++ g :: post) x o ≠ vl (pre ++ g :: post) y o)
    (b : Bool) :
    ∃ x : Fin n → Bool, vl (pre ++ constGate b :: post) x o ≠ vl (pre ++ g :: post) x o := by
  classical
  by_contra! eqv
  have varied : ∃ x y : Fin n → Bool,
      vl (pre ++ constGate b :: post) x o ≠ vl (pre ++ constGate b :: post) y o := by
    obtain ⟨x,y,h⟩ := nonconst
    exact ⟨x,y,by simpa only [eqv] using h⟩
  have legal : ∀ q ∈ pre ++ constGate b :: post, Ok q := by
    intro q hq
    rcases List.mem_append.mp hq with a | a
    · exact (clean_nok _ _ hr.clean q (List.mem_append_left _ a)).1
    · rcases List.mem_cons.mp a with rfl | h
      · cases b <;> simp [constGate,Ok]
      · exact (clean_nok _ _ hr.clean q (List.mem_append_right _ (List.mem_cons_of_mem _ h))).1
  have atGate (y : Fin n → Bool) : vl (pre ++ constGate b :: post) y (n + pre.length) = b := by
    unfold vl
    rw [wiresFrom_append]
    change (wiresFrom post (wiresFrom pre (List.ofFn y) ++ [_])).getD (n+pre.length) false = b
    have hl : (wiresFrom pre (List.ofFn y)).length = n + pre.length := by
      rw [length_wiresFrom]; simp
    rw [getD_wiresFrom _ _ _ (by simp [hl]), getD_snoc_len _ _ _ _ hl]
    cases b <;> rfl
  obtain ⟨ys,v,clean,bound,ev⟩ :=
    drop_core_legal n pre (constGate b) post legal o (Sum.inl b)
      (fun y => ⟨trivial,(atGate y).symm⟩) varied
  have opt := hr.noSmaller (⟨ys,v⟩ : Circuit) (fun q hq => (clean_nok _ _ clean q hq).1)
    (fun y => (ev y).trans (eqv y))
  change (pre ++ g :: post).length ≤ ys.length at opt
  simp only [List.length_append,List.length_cons] at bound opt
  omega

def clampOutput {n : Nat} (pre post : List Gate) (o : Nat)
    (x : Fin n → Bool) (b : Bool) : Bool :=
  (wiresFrom post (wiresFrom pre (List.ofFn x) ++ [b])).getD o false

theorem clampEval {n : Nat} (pre post : List Gate) (o : Nat) (x : Fin n → Bool) (b : Bool) :
    vl (pre ++ constGate b :: post) x o = clampOutput pre post o x b := by
  unfold vl clampOutput
  rw [wiresFrom_append]
  cases b <;> rfl

theorem Reduced.essentialCut {n o} {pre post : List Gate} {g : Gate}
    (hr : Reduced n (pre ++ g :: post) o)
    (nonconst : ∃ x y : Fin n → Bool, vl (pre ++ g :: post) x o ≠ vl (pre ++ g :: post) y o)
    (b : Bool) : ∃ x : Fin n → Bool,
      clampOutput pre post o x b ≠ vl (pre ++ g :: post) x o ∧
      clampOutput pre post o x false ≠ clampOutput pre post o x true := by
  obtain ⟨x,hx⟩ := hr.clampChanges nonconst b
  rw [clampEval] at hx
  refine ⟨x,hx,?_⟩
  let val := g.op.eval (g.inputs.map fun a => (wiresFrom pre (List.ofFn x)).getD a false)
  have raw : vl (pre ++ g :: post) x o = clampOutput pre post o x val := by
    unfold vl clampOutput
    rw [wiresFrom_append]
    rfl
  rw [raw] at hx
  cases b <;> cases hv : val <;> simp_all <;> exact Ne.symm hx

/-- The two wire functions at a reduced binary gate are incomparable by implication. -/
theorem Reduced.incomparablePins {n gs o} (hr : Reduced n gs o) {p a b : Nat} {g : Gate}
    (hg : gs[p]? = some g) (hop : g.op = .and ∨ g.op = .or) (hin : g.inputs = [a,b]) :
    (∃ x : Fin n → Bool, vl gs x a = true ∧ vl gs x b = false) ∧
    (∃ x : Fin n → Bool, vl gs x a = false ∧ vl gs x b = true) := by
  have hp := (List.getElem?_eq_some_iff.mp hg).1
  have ha := (hr.clean p g hg).lt a (by simp [hin])
  have hb := (hr.clean p g hg).lt b (by simp [hin])
  constructor <;> by_contra! hm
  · rcases hop with op | op
    · apply hr.noAlias p hp a ha
      intro x
      rw [vl_gate gs hr.clean x p g hg,op,hin]
      have h := hm x
      cases aa : vl gs x a <;> cases bb : vl gs x b <;> simp_all [GateOp.eval]
    · apply hr.noAlias p hp b hb
      intro x
      rw [vl_gate gs hr.clean x p g hg,op,hin]
      have h := hm x
      cases aa : vl gs x a <;> cases bb : vl gs x b <;> simp_all [GateOp.eval]
  · rcases hop with op | op
    · apply hr.noAlias p hp b hb
      intro x
      rw [vl_gate gs hr.clean x p g hg,op,hin]
      have h := hm x
      cases aa : vl gs x a <;> cases bb : vl gs x b <;> simp_all [GateOp.eval]
    · apply hr.noAlias p hp a ha
      intro x
      rw [vl_gate gs hr.clean x p g hg,op,hin]
      have h := hm x
      cases aa : vl gs x a <;> cases bb : vl gs x b <;> simp_all [GateOp.eval]

end PEqualNP.Outside.L_meta_9822.Clean
#print axioms PEqualNP.Outside.L_meta_9822.Clean.Reduced.essentialCut
