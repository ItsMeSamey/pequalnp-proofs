import MixedReaderPatch9822
namespace PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
open PEqualNP.CircuitLowerBounds
open NinePatch
theorem actual {n r d : Nat} {gs : List Gate} (cl : CleanL n gs) (hd : d≤r)
    (hot : Nat → Bool) (F : Nat → Bool) (w : List Bool) (len : w.length=n)
    (base : ∀i,i<n → w.getD i false=F i)
    (old : ∀k q, gs[k]?=some q → q.op.eval (q.inputs.map F)=F (n+k))
    (andRead : ∀q∈gs,r∈q.inputs → q.op=.and)
    (agree : ∀j,hot j=true → F j=true → F r=F d) :
    ∀j,j<n+gs.length → (wiresFrom (gs.map (gate r d hot)) w).getD j false=F j := by
  have orig {k : Nat} {b : Gate} (get : (gs.map (gate r d hot))[k]?=some b) :
      ∃a,gs[k]?=some a ∧ gate r d hot a=b := by
    rw [List.getElem?_map] at get
    cases e : gs[k]? with
    | none => simp [e] at get
    | some a => exact ⟨a,rfl,by simpa [e] using get⟩
  intro j bound
  apply aligned_run (gs.map (gate r d hot)) w F (by simpa [len] using base) ?_ ?_ j (by simpa [len] using bound)
  · intro k b get i mem
    obtain ⟨a,found,rfl⟩ := orig get
    simpa [len] using (clean hd hot (cl k a found)).lt i mem
  · intro k b get
    obtain ⟨a,found,rfl⟩ := orig get
    rw [len,←old k a found]
    rcases cl k a found with ⟨op,i,_,ins⟩|⟨_,i,j,_,_,ins⟩
    · simp [gate,ins]
    · exact step ins (andRead a (List.mem_iff_getElem?.mpr ⟨k,found⟩)) agree
end PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
