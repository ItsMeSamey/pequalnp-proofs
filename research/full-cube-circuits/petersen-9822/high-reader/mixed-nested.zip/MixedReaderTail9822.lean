import NineUpperMachine9822
import MixedReaderOverlay9822
import MixedReaderPrefix9822
import PairSignalRelations9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean MixedReaderPatch
theorem mixed_tail_cold {C pre mid tail g q} (ro : Roster C pre (mid++q::tail) g)
    (red : Reduced 10 C.gates C.output) (x : Input)
    (d : Nat) (F : Nat → Bool) (ff : F=vl C.gates x)
    (z t : Nat) (ze : z=10+pre.length) (te : t=z+1+mid.length)
    (w : List Bool) (wl : w.length=t+1)
    (base : ∀j,j<w.length → w.getD j false=overlay F z t j)
    (hd : d<t) (dz : d≠z) (cd : F d=false) (ct : F t=false)
    (no : ∀a∈tail,z∉a.inputs) (allAnd : ∀a∈tail,t∈a.inputs → a.op=.and)
    (io : C.output<10+C.gates.length) (oz : C.output≠z) (ot : C.output≠t) :
    (wiresFrom (tail.map (gate t d F)) w).getD C.output false=F C.output := by
  have idx (k : Nat) : w.length+k=10+(pre.length+1+mid.length+1+k) := by omega
  have orig {k : Nat} {a : Gate} (h : tail[k]?=some a) :
      C.gates[pre.length+1+mid.length+1+k]?=some a := by
    rw [ro.split,show pre++g::(mid++q::tail)=(pre++g::(mid++[q]))++tail by simp,
      List.getElem?_append_right (by simp;omega)]
    rw [show pre.length+1+mid.length+1+k-(pre++g::(mid++[q])).length=k by simp;omega]
    exact h
  have cl : CleanL w.length tail := by intro k a h;rw [idx];exact red.clean _ a (orig h)
  have step := replay_tail hd.le dz (by omega : d≠t) tail w F (overlay F z t) cd ct
    (by intro j h h';simp [overlay,h,h']) base cl
  have size : C.output<w.length+tail.length := by
    rw [ro.split] at io
    simp only [List.length_append,List.length_cons] at io
    omega
  have go := step (by
    intro k a h;have mem := List.mem_iff_getElem?.mpr ⟨k,h⟩
    rcases red.shape (orig h) with ⟨neg,_⟩|⟨_,l,b,_,_,diff,ins⟩
    · have pos := ro.pos a (List.mem_append_right _ (List.mem_append_right _ (List.mem_cons_of_mem _ mem)))
      rcases pos with e|e <;> simp_all
    · exact ⟨l,b,ins,no a mem,fun hit => ⟨allAnd a mem hit,diff⟩⟩) (by
    intro k a h
    have zz : w.length+k≠z := by omega
    have tt : w.length+k≠t := by omega
    rw [show overlay F z t (w.length+k)=F (w.length+k) by simp [overlay,zz,tt],ff,idx]
    exact (vl_gate C.gates red.clean x _ a (orig h)).symm) C.output size
  simpa [overlay,oz,ot] using go
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
