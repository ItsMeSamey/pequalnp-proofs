import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row48 : row 16783216 = true := by decide +kernel
theorem row49 : row 16783231 = true := by decide +kernel
theorem row50 : row 16908288 = true := by decide +kernel
end Research.LiteralC5.Table
