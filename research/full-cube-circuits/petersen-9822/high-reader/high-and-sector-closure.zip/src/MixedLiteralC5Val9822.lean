import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
abbrev val (s : List Nat) := s.foldl Nat.land live
end Research.LiteralC5.Table
