import PrivateFoldRun9822
import PairRisingGate9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds LowHotElimination SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
open scoped Classical
theorem private_upper_model {C p mid post g} (h : Gate) (ho : h.op=.or)
    (r : Roster C (p++h::mid) post g) (cand : Candidate C) (red : Reduced 10 C.gates C.output)
    (eo : C.output≠10+p.length) (privateH : ∀q∈C.gates, PositiveOp q → 10+p.length∉q.inputs)
    (seven : 7≤C.gates.countP countsAnd) (mark : Gate→Bool)
    (reader : ∀q∈post,mark q=true → q.op=.or ∧ 10+(p++h::mid).length∈q.inputs) :
    ∃ J : Circuit, CleanL 10 J.gates ∧ (∀q∈J.gates,PositiveOp q) ∧
      J.gates.countP (ofOp .or)+post.countP mark≤8 ∧
      (∀x : Input,vl J.gates x J.output=outerValue (p++h::mid) post C.output x true) := by
  let pre := p++h::mid
  let L := clampOut p mid post
  have mem (q : Gate) (m : q∈p++mid++post) : q∈pre++post := by
    simp only [pre,List.mem_append,List.mem_cons] at m ⊢
    tauto
  have positive (q : Gate) (m : q∈p++mid++post) := r.pos q (mem q m)
  have incl (q : Gate) (m : q∈pre++post) : q∈C.gates := by
    rw [r.split]
    simp only [pre,List.mem_append,List.mem_cons] at m ⊢
    tauto
  have ok (q : Gate) (m : q∈p++mid++post) := cand.1 q (incl q (mem q m))
  have ci := fun x => clamp_run p mid post ok x
  have pno (q : Gate) (m : q∈mid++post) : 10+p.length∉q.inputs := by
    have inall : q∈p++mid++post := by simp only [List.mem_append] at m ⊢;tauto
    exact privateH q (incl q (mem q inall)) (positive q inall)
  let F := outerValue pre post C.output
  have obs (x : Input) : (L.1.getD C.output (Sum.inl false)).val (wiresFrom L.2 (List.ofFn x))=F x true :=
    (((ci x).1.2 C.output).2).trans (clamp_matches (h:=h) _ _ pno eo)
  have cut := physical_cut_split cand r.split r.inv (fun q h => r.pos q (List.mem_append_right _ h))
  have hot (x : Input) (on : edge x=true) : F x true=true := SignedClamp.positive_upper cut x on
  have empty : F (fun _ => false) true=false := by
    have eq := cut.computes (fun _ => false)
    rw [cold_empty r cand seven] at eq
    exact eq.trans (by decide)
  obtain ⟨o,ov⟩ := observed_wire obs ⟨(fun _=>false),(fun _=>true),by rw [empty,hot _ (by decide)];decide⟩
  have sz : (clampPre p mid).1.length=10+pre.length := by
    simp [clampPre,ReaderDebit.stats_length,appendConst,assignments,pre];omega
  have cp : CleanL (appendConst true (clampPre p mid)).1.length post := by
    intro i q site
    have h := red.clean (pre.length+(i+1)) q (by
      rw [r.split]; change (pre++g::post)[pre.length+(i+1)]?=some q
      simpa [List.getElem?_append] using site)
    convert h using 1 <;> simp [appendConst,sz]; omega
  have orcharge := clamp_ledger p mid post .or mark cp (by simpa [sz,pre] using reader)
  have notcharge := clamp_ledger p mid post .not (fun _ => false) cp (by simp)
  have nn (gs : List Gate) (sub : ∀q∈gs,q∈p++mid++post) : gs.countP (ofOp .not)=0 := by
    apply List.countP_eq_zero.mpr
    intro q m
    rcases positive q (sub q m) with h|h <;> simp [ofOp,h]
  have noneN : L.2.countP (ofOp .not)=0 := by
    rw [nn p (by intro q m;simp [m]),nn mid (by intro q m;simp [m]),nn post (by intro q m;simp [m])] at notcharge
    change (clampOut p mid post).2.countP (ofOp .not)=0
    omega
  have cL := (ci (fun _=>false)).2
  refine ⟨⟨L.2,o⟩,cL,?_,?_,ov⟩
  · intro q m
    rcases (clean_nok _ _ cL q m).1.1 with a|b|n
    · exact Or.inl a
    · exact Or.inr b
    · exact ((List.countP_eq_zero.mp noneN q m) (by simpa [ofOp] using n)).elim
  · have nine := or_cap r cand seven
    have flag : FreeAndNet.CircuitCompiler.orFlag=ofOp .or := by
      funext q;cases q with | mk op ins => cases op <;> simp [FreeAndNet.CircuitCompiler.orFlag,ofOp]
    rw [←List.countP_eq_length_filter,flag,r.split] at nine
    simp only [List.countP_append,List.countP_cons] at nine
    have h1 : ofOp .or h=true := by simp [ofOp,ho]
    have h0 : ofOp .or g=false := by simp [ofOp,r.inv]
    simp [h1,h0] at nine
    change (clampOut p mid post).2.countP (ofOp .or)+post.countP mark≤8
    omega
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.Deletion.private_upper_model
