import HighHotIsGuard9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
theorem high_socket_is_guard {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    ∃k : Nat,∃q : Gate,∃b : Nat,k<pre.length ∧ pre[k]?=some q ∧ q.op=.or ∧ b<10+k ∧ b≠s.val ∧
      (q.inputs=[s.val,b] ∨ q.inputs=[b,s.val]) ∧ g.inputs=[10+k] := by
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have hot := hot_guard cut s upper
  obtain ⟨k,q,b,kp,site,o,bl,bs,pins,_,_⟩ := first_hot_socket r cand seven red s hot
  obtain ⟨A,_,_,_,only⟩ := only_socket_hot r cand red seven s sl su upper
  have full : C.gates[k]?=some q := by rw [r.split,List.getElem?_append_left kp];exact site
  have val : vl C.gates (SignedClamp.singleton s) (10+k)=true := by
    rw [vl_gate _ red.clean _ _ _ full]
    have sr : vl C.gates (SignedClamp.singleton s) s.val=true := (vl_input _ _ _ s.isLt).trans (by simp [SignedClamp.singleton])
    rcases pins with p|p <;> simp [p,o,GateOp.eval,sr]
  have atK : 10+k=A := (only (10+k) val).resolve_left (by omega)
  have atg : C.gates[pre.length]?=some g := by simp [r.split]
  rcases red.clean pre.length g atg with ⟨_,i,ilt,gi⟩|⟨op,_⟩
  · have read (x : Input) : innerValue pre g x=vl C.gates x i := by rw [visible r i ilt];simp [innerValue,gi]
    have id : i=A := by
      rcases only i ((read _).symm.trans hot) with is|is
      · obtain ⟨x,off,_,on⟩ := independent_witness r cand seven s
        rw [read,is,vl_input _ _ _ s.isLt,off] at on;contradiction
      · exact is
    exact ⟨k,q,b,kp,site,o,bl,bs,pins,by simpa [id,atK] using gi⟩
  · rcases op with a|o <;> simp_all [r.inv]
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.high_socket_is_guard
