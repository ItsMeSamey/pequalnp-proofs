import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row60 : row 18285098 = true := by decide +kernel
theorem row61 : row 18285644 = true := by decide +kernel
theorem row62 : row 18288640 = true := by decide +kernel
end Research.LiteralC5.Table
