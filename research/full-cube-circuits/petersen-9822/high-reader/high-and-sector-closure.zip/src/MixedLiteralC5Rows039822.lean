import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row9 : row 5896 = true := by decide +kernel
theorem row10 : row 5930 = true := by decide +kernel
theorem row11 : row 5952 = true := by decide +kernel
end Research.LiteralC5.Table
