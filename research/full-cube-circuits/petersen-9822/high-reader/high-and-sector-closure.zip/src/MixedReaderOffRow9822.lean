import MixedReaderPatch9822
namespace PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
open PEqualNP.CircuitLowerBounds
theorem off_step {r z d a b : Nat} {F G : Nat → Bool} {q : Gate}
    (ins : q.inputs=[a,b]) (nz : z∉q.inputs) (dz : d≠z) (dr : d≠r)
    (cold : F d=false) (rcold : F r=false)
    (away : ∀ j,j≠z → j≠r → G j=F j)
    (both : r∈q.inputs → q.op=.and ∧ a≠b) :
    (gate r d F q).op.eval ((gate r d F q).inputs.map G)=q.op.eval (q.inputs.map F) := by
  have az : a≠z := by intro e;apply nz;simp [ins,e]
  have bz : b≠z := by intro e;apply nz;simp [ins,e]
  have gd := (away d dz dr).trans cold
  by_cases ar : a=r
  · subst a
    obtain ⟨op,ab⟩ := both (by simp [ins])
    have gb := away b bz (Ne.symm ab)
    cases hb : F b <;> simp [gate,ins,op,GateOp.eval,hb,gb,gd,rcold,Ne.symm ab]
  by_cases br : b=r
  · subst b
    obtain ⟨op,ab⟩ := both (by simp [ins])
    have ga := away a az ar
    cases ha : F a <;> simp [gate,ins,op,GateOp.eval,ha,ga,gd,rcold,ar]
  · simp [gate,ins,ar,br,away a az ar,away b bz br]
end PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
