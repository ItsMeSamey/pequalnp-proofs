import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row45 : row 16783146 = true := by decide +kernel
theorem row46 : row 16783168 = true := by decide +kernel
theorem row47 : row 16783180 = true := by decide +kernel
end Research.LiteralC5.Table
