import NineUpperReader9822
import NineUpperChoiceExclusion9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean

theorem upper_only_nine_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (upper : outerValue pre post C.output (SignedClamp.singleton 9) true=true)
    (other : ∀ j : Fin 10,j≠9 → outerValue pre post C.output (SignedClamp.singleton j) true=false) :
    False := by
  have ands := nine_direct_and_at_upper r cand red seven upper other
  obtain ⟨f,ch,ord⟩ := choose_upper_contacts r red ands (by
    intro j ct on
    obtain ⟨q,mem,ins⟩ := ct
    have op := ands q mem (by rcases ins with h|h <;> simp [h])
    exact upper_reader_replacement r cand red seven upper mem op ins on)
  exact upper_nine_impossible_of_choices r cand red seven upper other f ch ord

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.upper_only_nine_impossible
