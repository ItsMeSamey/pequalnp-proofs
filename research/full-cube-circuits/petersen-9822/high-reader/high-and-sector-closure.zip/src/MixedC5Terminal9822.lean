import MixedC5TerminalBits9822
namespace Research.LiteralC5.Table
def Side (cs : List Nat) (t : Nat) := if t==0 then 0 else meetCover cs t (meetCover cs pos neg)
private theorem inspect {cs ws xs : List Nat} {t i : Nat}
    (wm : ∀ a∈ws,a∈cs) (xm : ∀ a∈xs,a∈cs)
    (wc : Below pos (ws.foldl Nat.land live)) (xc : Below t (xs.foldl Nat.land live))
    (h : (Side cs t).testBit i=true) :
    neg.testBit i=true ∧ (ws.foldl Nat.land live).testBit i=true ∧ (xs.foldl Nat.land live).testBit i=true := by
  unfold Side at h
  split at h
  · simp at h
  · obtain ⟨mid,ch⟩ := (cover_bits _ _ _ _).mp h
    obtain ⟨ni,wh⟩ := (cover_bits _ _ _ _).mp mid
    have liveBit : live.testBit i=true := by
      have e : neg &&& live=neg := by decide
      have eq := congrArg (fun v : Nat => v.testBit i) e
      simpa [ni] using eq
    refine ⟨ni,(fold_bits _ _ _).mpr ⟨liveBit,?_⟩,(fold_bits _ _ _).mpr ⟨liveBit,?_⟩⟩
    · intro a ha; apply wh a (wm a ha) (below_incl ?_)
      intro j jj; exact ((fold_bits _ _ _).mp (wc j jj)).2 a ha
    · intro a ha; apply ch a (xm a ha) (below_incl ?_)
      intro j jj; exact ((fold_bits _ _ _).mp (xc j jj)).2 a ha
private theorem ordered (cs ws ls rs : List Nat)
    (wm : ∀a∈ws,a∈cs) (lm : ∀a∈ls,a∈cs) (rm : ∀a∈rs,a∈cs)
    (positive : Below pos (ls.foldl Nat.land live ||| rs.foldl Nat.land live))
    (wc : Below pos (ws.foldl Nat.land live))
    (negative : ((ws.foldl Nat.land live &&& (ls.foldl Nat.land live ||| rs.foldl Nat.land live)) &&& neg)=0)
    (rh : (rs.foldl Nat.land live).testBit 17=true) : bad cs=true := by
  let a := cutSide (ls.foldl Nat.land live)
  apply List.any_eq_true.mpr
  refine ⟨a,cutSide_mem _,?_⟩
  change (Side cs a ||| Side cs (pos ^^^ a) == 0)=true
  apply beq_iff_eq.mpr
  apply Nat.eq_of_testBit_eq; intro i
  have n := congrArg (fun v : Nat => v.testBit i) negative
  simp only [Nat.testBit_and,Nat.testBit_or,Nat.zero_testBit] at n
  simp only [Nat.testBit_or,Nat.zero_testBit]
  cases l : (Side cs a).testBit i <;> cases r : (Side cs (pos ^^^ a)).testBit i
  · rfl
  · obtain ⟨hn,hw,hr⟩ := inspect wm rm wc (cutSide_right _ _ positive rh) r
    simp [hn,hw,hr] at n
  · obtain ⟨hn,hw,hl⟩ := inspect wm lm wc (cutSide_left _) l
    simp [hn,hw,hl] at n
  · obtain ⟨hn,hw,hl⟩ := inspect wm lm wc (cutSide_left _) l
    simp [hn,hw,hl] at n
theorem bad_of_output (cs ws ls rs : List Nat)
    (wm : ∀a∈ws,a∈cs) (lm : ∀a∈ls,a∈cs) (rm : ∀a∈rs,a∈cs)
    (positive : ((ws.foldl Nat.land live &&& (ls.foldl Nat.land live ||| rs.foldl Nat.land live)) &&& pos)=pos)
    (negative : ((ws.foldl Nat.land live &&& (ls.foldl Nat.land live ||| rs.foldl Nat.land live)) &&& neg)=0) :
    bad cs=true := by
  have both (i : Nat) (h : pos.testBit i=true) :
      (ws.foldl Nat.land live).testBit i=true ∧ (ls.foldl Nat.land live ||| rs.foldl Nat.land live).testBit i=true := by
    have eq := congrArg (fun v : Nat => v.testBit i) positive
    simpa [h] using eq
  have wh : Below pos (ws.foldl Nat.land live) := fun i h => (both i h).1
  have b : Below pos (ls.foldl Nat.land live ||| rs.foldl Nat.land live) := fun i h => (both i h).2
  by_cases rh : (rs.foldl Nat.land live).testBit 17=true
  · exact ordered cs ws ls rs wm lm rm b wh negative rh
  · have e := b 17 (by decide)
    have lh : (ls.foldl Nat.land live).testBit 17=true := by simpa [rh] using e
    exact ordered cs ws rs ls wm rm lm (by simpa [Nat.or_comm] using b) wh (by simpa [Nat.or_comm] using negative) lh
end Research.LiteralC5.Table
#print axioms Research.LiteralC5.Table.bad_of_output
