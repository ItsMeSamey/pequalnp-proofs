import HighAndSector9822
import MixedLiteralC5Lower9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds
open PEqualNP.Outside.L_meta_9822.Clean
theorem high_and_sector {C : Circuit} (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (one : C.gates.countP countsNot = 1)
    (high : 7 ≤ C.gates.countP countsAnd) : False :=
  high_and_sector_of_c5 Research.LiteralC5.lower cand red one high
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.high_and_sector
