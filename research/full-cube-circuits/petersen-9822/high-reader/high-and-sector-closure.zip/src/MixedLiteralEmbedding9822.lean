import MixedLiteralPeel9822
import MixedLiteralC5Defs9822
namespace Research.OddOr.LiteralNine
open FreeAndNet Research.OddOr.Graph9822
private def labels : Fin 5 → V := ![6,1,2,7,9]
private def assignment (x : Fin 5 → Bool) : Finset V := (Finset.univ.filter (fun i => x i)).image labels
private def m : Fin 11 → Product (Fin 6) := ![some [5],none,some [1],some [2],none,none,none,some [0],some [3],none,some [4]]
private theorem lift_ok : ∀ x : Fin 5 → Bool,∀ i : Fin 11,
    pval (Research.LiteralC5.lift x) (m i) = decide (i∈ext (assignment x)) := by decide +kernel
private theorem facts : ∀ x : Fin 5 → Bool,assignment x ⊆ ({1,2,7,9,6} : Finset V) ∧
    f (assignment x)=Research.LiteralC5.cycle x := by decide +kernel
theorem core_lower (lower : Research.LiteralC5.Lower) (u : Net (Fin 11)) (fit : Fits {1,2,7,9,6} u) :
    4≤u.cost := by
  apply (lower (specialize m u) ?_).trans (specialize_cost m u)
  intro x
  rw [eval_specialize]
  have eq := funext (lift_ok x)
  rw [eq]
  exact (fit _ (facts x).1).trans (facts x).2
theorem no_seven (lower : Research.LiteralC5.Lower) (s : V) (caseS : s=5 ∨ s=8)
    (t : Net (Fin 11)) (fit : Fits (Finset.univ.erase s) t) : 8≤t.cost := by
  have paid : ∃ u : Net (Fin 11),u.cost+4≤t.cost ∧ Fits {1,2,7,9,6} u := by
    rcases caseS with rfl|rfl
    · exact peel5 t fit
    · exact peel8 t fit
  obtain ⟨u,price,h⟩ := paid
  have low := core_lower lower u h
  omega
end Research.OddOr.LiteralNine
#print axioms Research.OddOr.LiteralNine.no_seven
