import NineUpperMachine9822
import MixedGuardLayout9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean GuardTags Research.NineHotSites
theorem two_sites_dominate {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    {A B : Nat} (ab : A≠B) (ha : A∈liveSites C) (hb : B∈liveSites C)
    (raw : ∀ x, vl C.gates x 9=true → innerValue pre g x=true)
    (left : ∀ x, vl C.gates x A=true → innerValue pre g x=true)
    (right : ∀ x, vl C.gates x B=true → innerValue pre g x=true)
    (j : Nat) (bound : j<10+C.gates.length) (on : (liveTable C).Hot j) :
    ∀ x, vl C.gates x j=true → innerValue pre g x=true := by
  obtain ⟨up,hot⟩ := full_upper_nine r cand red seven
  have cap := upper_sites_card r cand red (by omega) up hot
  induction j using Nat.strong_induction_on with
  | ind j ih =>
    rcases upper_program r red hot j bound on with rawj|meet|⟨mem,_⟩
    · subst j; exact raw
    · obtain ⟨u,ub,v,_,uh,_,ev⟩ := meet
      intro x hx
      apply ih u ub (by omega) uh x
      have hx' : (liveTable C).wire j x=true := hx
      rw [ev x] at hx'
      exact (Bool.and_eq_true_iff.mp hx').1
    · rcases Research.NineHotContacts.Table.only_two cap ha hb mem ab with eq|eq
      · subst j; exact left
      · subst j; exact right
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
