import NineDirectAnd9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr Research.OddOr.Graph9822 Research.OddOr.Envelope
open SignedClamp NonrawSupport OuterNet LowHotElimination PEqualNP.Outside.L_meta_9822.Clean GuardTags
theorem original_nine_hot_budget_at_upper {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (upper : outerValue pre post C.output (SignedClamp.singleton 9) true=true) :
    hotCount (env (SignedClamp.singleton 9) false) (model pre post C.output) ≤ 2 := by
  have existing := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have nine := hot_guard existing 9 upper
  let net := model pre post C.output
  let u := retire (openPin (9 : Fin 10)) net
  let k := specialize (close false) u
  have evalU (v : Input) (z : Bool) : u.eval (env v z) = outerValue pre post C.output (raise (9 : Fin 10) v) z := by
    change (retire _ _).eval _ = _
    rw [retire_eval,row_open,model_eval r cand]
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have affected (v : Input) (vs : v (9 : Fin 10)=true) : raise (9 : Fin 10) v=v := by
    funext j
    by_cases e : j=(9 : Fin 10) <;> simp [raise,e,vs]
  have zeroEval (v : Input) : u.eval (env v false)=edge (raise (9 : Fin 10) v) := by
    rw [evalU]
    have exactOn := cut.computes (raise (9 : Fin 10) v)
    have raised : innerValue pre g (raise 9 v)=true := by
      apply inner_mono_inputs (fun q hq => r.pos q (List.mem_append_left _ hq)) g _ nine
      intro j hj
      have eq : j=(9 : Fin 10) := by simpa [SignedClamp.singleton] using hj
      simp [raise,eq]
    simpa [raised] using exactOn
  have fit (S : Finset (Fin 10)) : sees k S = LowPositive.pos (9 : Fin 10) S := by
    let v : Input := fun j => decide (j∈S)
    change (specialize (close false) u).eval v = _
    rw [eval_specialize,close_eval,zeroEval]
    apply congrArg edge
    funext j
    by_cases e : j=(9 : Fin 10) <;> simp [raise,v,e]
  let v := SignedClamp.singleton 9
  have vs : v 9=true := by simp [v,SignedClamp.singleton]
  have up : u.eval (env v true)=true := by rw [evalU,affected v vs]; exact upper
  have down : u.eval (env v false)=false := by rw [zeroEval,affected v vs];exact singleton_zero 9
  have all : u.eval (env (fun _ => true) false) = true := by
    rw [zeroEval,affected _ rfl]
    rfl
  have noOut : ¬outUses (0 : Fin 11) u := by
    intro use
    have bad := outZeros u 0 use (env (fun _ => true) false) rfl
    rw [all] at bad
    exact Bool.noConfusion bad
  have hit : 0 < hits (0 : Fin 11) u := by
    by_contra! h
    have equal : u.eval (env v true)=u.eval (env v false) := by
      apply eval_congr_used
      intro j used
      exact Fin.cases (fun e => (e.elim (by omega) noOut).elim) (fun _ _ => rfl) j used
    rw [up,down] at equal
    exact Bool.noConfusion equal
  have charge := specialize_saves (0 : Fin 11) (close false) (by rfl) u
  change k.cost + hits (0 : Fin 11) u ≤ u.cost at charge
  have price := LowPositive.pin_price (9 : Fin 10) k fit
  have amount : LowPositive.pinPrice 9=6 := by decide +kernel
  have paid := retire_cost (openPin (9 : Fin 10)) net
  rw [open_floor] at paid
  change u.cost + hotCount (env (SignedClamp.singleton 9) false) net ≤ net.cost at paid
  have cap : net.cost ≤ 9 := (model_cost r).trans (or_cap r cand seven)
  change hotCount (env (SignedClamp.singleton 9) false) net ≤ 2
  omega

theorem physical_nine_hot_budget_at_upper {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (upper : outerValue pre post C.output (SignedClamp.singleton 9) true=true) :
    physicalHot pre (List.ofFn (SignedClamp.singleton 9)) +
      physicalHot post (wiresFrom pre (List.ofFn (SignedClamp.singleton 9)) ++ [false]) ≤ 2 := by
  rw [←model_hot (r.split ▸ red) r.pos]
  exact original_nine_hot_budget_at_upper r cand red seven upper
theorem upper_nine_price_at_upper {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (upper : outerValue pre post C.output (SignedClamp.singleton 9) true=true)
    (other : ∀ j : Fin 10,j≠9 → outerValue pre post C.output (SignedClamp.singleton j) true=false)
    (t : Net (Fin 10)) (ev : ∀ v : Input,t.eval v=outerValue pre post C.output v true) : 9≤t.cost := by
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have price : 8≤(pin 9 t).cost := by
    apply eight_off 9
    constructor
    · intro j ne
      rw [pin_sees _ _ _ (by simpa using ne)]
      change t.eval (inputOn {j})=false
      have eq : inputOn {j}=SignedClamp.singleton j := by funext k;simp [inputOn,SignedClamp.singleton]
      rw [eq,ev]
      exact other j ne.symm
    · intro j k nj nk on
      rw [pin_sees _ _ _ (by simp [nj,nk])]
      exact (ev _).trans (positive_upper cut _ on)
  have noOut : ¬outUses (9 : Fin 10) t := by
    obtain ⟨a,b,ha,hb,on⟩ := data.avoiding 9
    exact avoids_output t (by simp [ha,hb] : (9 : Fin 10)∉({a,b}: Finset _))
      ((ev _).trans (positive_upper cut _ on))
  have hi := (ev _).trans upper
  have base := cut.computes (fun _ => false)
  rw [cold_empty r cand seven] at base
  have lo : t.eval (fun _ => false)=false := (ev _).trans base
  have hit : 0<hits 9 t := by
    by_contra! none
    have same : t.eval (SignedClamp.singleton 9)=t.eval (fun _ => false) := by
      apply eval_congr_used
      intro j used
      by_cases ne : j=(9 : Fin 10)
      · subst j; exact False.elim (used.elim (by omega) noOut)
      · simp [SignedClamp.singleton,ne]
    rw [hi,lo] at same;contradiction
  have saving := pin_cost (9 : Fin 10) t
  omega

theorem zero_upper_hot_at_upper {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (upper : outerValue pre post C.output (SignedClamp.singleton 9) true=true)
    (other : ∀ j : Fin 10,j≠9 → outerValue pre post C.output (SignedClamp.singleton j) true=false) :
    physicalHot post (wiresFrom pre (List.ofFn (fun _ : Fin 10 => false)) ++ [true]) = 0 := by
  let t := model pre post C.output
  let u := retire (close true) t
  have ev (v : Input) : u.eval v=outerValue pre post C.output v true := by
    change (retire _ _).eval _=_
    rw [retire_eval,close_eval,model_eval r cand]
  have price := upper_nine_price_at_upper r cand red seven upper other u ev
  have saving := retire_cost (close true) t
  have floor : floorRow (close true) = env (fun _ => false) true := close_eval _ _
  rw [floor] at saving
  change u.cost + hotCount (env (fun _ => false) true) (model pre post C.output) ≤ t.cost at saving
  have cap : t.cost≤9 := (model_cost r).trans (or_cap r cand seven)
  rw [model_hot (r.split ▸ red) r.pos] at saving
  omega
theorem nine_direct_and_at_upper {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (upper : outerValue pre post C.output (SignedClamp.singleton 9) true=true)
    (other : ∀ j : Fin 10,j≠9 → outerValue pre post C.output (SignedClamp.singleton j) true=false)
    (q : Gate) (mem : q∈post) (uses : 10+pre.length∈q.inputs) : q.op=.and := by
  let w := wiresFrom pre (List.ofFn (fun _ : Fin 10 => false))
  have len : w.length=10+pre.length := by simp [w,length_wiresFrom]
  have cost := zero_upper_hot_at_upper r cand red seven upper other
  have no := zero_no_or_reader post (w++[true]) (10+pre.length) (by simp [len])
    (by rw [←len,getD_snoc_eq]) cost q mem uses
  exact (r.pos q (List.mem_append_right _ mem)).resolve_right no
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.nine_direct_and_at_upper
