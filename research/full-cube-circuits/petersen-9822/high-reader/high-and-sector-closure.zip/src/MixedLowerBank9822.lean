import MixedReaderOverlay9822
import NineUpperMachine9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean
theorem lower_reader_bank {C pre mid tail g q} (ro : Roster C pre (mid++q::tail) g)
    (x : Input) (hot : innerValue pre g x=true) :
    let lo := wiresFrom mid (wiresFrom pre (List.ofFn x)++[false])
    ∀ j,j<lo.length → lo.getD j false=vl C.gates x j := by
  let w := wiresFrom pre (List.ofFn x)
  let lo := wiresFrom mid (w++[false])
  have off : g.op.eval (g.inputs.map fun j => w.getD j false)=false := by
    rw [ro.inv];change (!(innerValue pre g x))=false;simp [hot]
  change ∀j,j<lo.length → lo.getD j false=_
  intro j jb
  unfold vl
  rw [ro.split,wiresFrom_append]
  change _=(wiresFrom (mid++q::tail) (w++[g.op.eval (g.inputs.map fun j => w.getD j false)])).getD j false
  rw [off,wiresFrom_append]
  exact (getD_wiresFrom (q::tail) lo j jb).symm
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
