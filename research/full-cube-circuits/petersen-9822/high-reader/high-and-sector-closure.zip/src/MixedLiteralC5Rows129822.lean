import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row36 : row 1315964 = true := by decide +kernel
theorem row37 : row 16777224 = true := by decide +kernel
theorem row38 : row 16777280 = true := by decide +kernel
end Research.LiteralC5.Table
