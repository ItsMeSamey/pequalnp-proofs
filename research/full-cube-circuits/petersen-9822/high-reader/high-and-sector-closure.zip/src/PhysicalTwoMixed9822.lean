import PhysicalMixedSupport9822
import UpperSingletonSectors9822
import NineUpperPhysicalExclusion9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet SignedClamp NonrawSupport
open PEqualNP.Outside.L_meta_9822.Clean

theorem two_mixed_cases {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7 ≤ C.gates.countP countsAnd) :
    C.gates.countP countsAnd = 7 ∧ (C.gates.filter CircuitCompiler.orFlag).length = 9 ∧
    ∃ s : Fin 10, (s=5 ∨ s=8) ∧ ∀ j : Fin 10,
      (innerValue pre g (SignedClamp.singleton j) = true ↔ j=s ∨ j=9) ∧
      (outerValue pre post C.output (SignedClamp.singleton j) true = true ↔ j=s ∨ j=9) := by
  obtain ⟨eq,ors,nine,i,lo,hi,supp⟩ := exact_mixed_support r cand red seven
  let K := fun j => outerValue pre post C.output (SignedClamp.singleton j) true
  have away : ∃ s : Fin 10, s ≠ 9 ∧ K s = true := by
    by_contra! neg
    apply upper_only_nine_impossible r cand red seven nine
    intro j ne
    cases e : K j <;> simp_all [K]
  obtain ⟨s, ne, hs⟩ := away
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have si := ((supp s).mp (hot_guard cut s hs)).resolve_right ne
  subst i
  obtain ⟨_, labels, _⟩ := upper_singleton_labels r cand red eq
  refine ⟨eq,ors,s,?_,fun j => ⟨supp j,?_,?_⟩⟩
  · rcases labels s hs with h|h|h
    · exact Or.inl h
    · exact Or.inr h
    · exact (ne h).elim
  · intro h
    exact (supp j).mp (hot_guard cut j h)
  · rintro (rfl|rfl) <;> assumption

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.two_mixed_cases
