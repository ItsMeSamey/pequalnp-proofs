import MixedReaderReplay9822
import PrivateClampTape9822
namespace PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
open PEqualNP.CircuitLowerBounds
open PEqualNP.Outside.L_meta_9822.Sectors.Deletion
def overlay (F : Nat → Bool) (z r j : Nat) : Bool := if j=z ∨ j=r then true else F j
theorem paired_bank (pre mid : List Gate) (x : Fin 10 → Bool) (F : Nat → Bool)
    (no : ∀q∈mid,10+pre.length∉q.inputs)
    (vals : ∀j,j<10+pre.length+1+mid.length →
      (wiresFrom mid (wiresFrom pre (List.ofFn x)++[false])).getD j false=F j) :
    let z := 10+pre.length
    let r := z+1+mid.length
    let w := wiresFrom mid (wiresFrom pre (List.ofFn x)++[true])++[true]
    ∀ j,j<w.length → w.getD j false=overlay F z r j := by
  let u := wiresFrom pre (List.ofFn x)
  let z := 10+pre.length
  let r := z+1+mid.length
  have ul : u.length=z := by simp [u,z,length_wiresFrom]
  let lo := wiresFrom mid (u++[false])
  let hi := wiresFrom mid (u++[true])
  have hl : hi.length=r := by simp [hi,r,ul,length_wiresFrom]
  have same := ignore_wire mid z (u++[true]) (u++[false]) no (by simp) (by
    intro j h;rw [getD_snoc_ne _ _ _ _ (by omega),getD_snoc_ne _ _ _ _ (by omega)])
  change ∀j,j<(hi++[true]).length → (hi++[true]).getD j false=overlay F z r j
  intro j bound
  by_cases jr : j=r
  · subst j;rw [←hl,getD_snoc_eq];simp [overlay]
  rw [getD_snoc_ne _ _ _ _ (by omega)]
  by_cases jz : j=z
  · subst j
    have atZ : hi.getD z false=true := by
      change (wiresFrom mid (u++[true])).getD z false=true
      rw [getD_wiresFrom _ _ _ (by simp [ul])]
      exact getD_snoc_len _ _ _ _ ul
    rw [show overlay F z r z=true by simp [overlay]];exact atZ
  · have small : j<r := by simp at bound;omega
    rw [show overlay F z r j=F j by simp [overlay,jz,jr]]
    exact (same j jz).trans (vals j small)
end PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
