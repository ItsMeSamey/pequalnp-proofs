import NinePatchChoice9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean
def UpperBelow (pre post : List Gate) (k j : Nat) := ∀ x : Input,
    outerValue pre post k x true=true → outerValue pre post j x true=true

theorem choose_upper_contacts {C pre post g} (r : Roster C pre post g) (red : Reduced 10 C.gates C.output)
    (ands : ∀ q∈post,10+pre.length∈q.inputs → q.op=.and)
    (witness : ∀ j, AtPartner post (10+pre.length) j → vl C.gates (SignedClamp.singleton 9) j=true →
      ∃ k<j, vl C.gates (SignedClamp.singleton 9) k=false ∧
        (∀ x : Input, (!(innerValue pre g x) && vl C.gates x j)=(!(innerValue pre g x) && vl C.gates x k)) ∧
        UpperBelow pre post k j) :
    ∃ f, NineChoice C pre post g f ∧ ∀ j,AtPartner post (10+pre.length) j → UpperBelow pre post (f j) j := by
  classical
  have all (j : Nat) : ∃ k, k≤j ∧ (AtPartner post (10+pre.length) j →
      vl C.gates (SignedClamp.singleton 9) k=false ∧
        (∀ x : Input, (!(innerValue pre g x) && vl C.gates x j)=(!(innerValue pre g x) && vl C.gates x k)) ∧
        UpperBelow pre post k j) := by
    by_cases ct : AtPartner post (10+pre.length) j
    · cases h : vl C.gates (SignedClamp.singleton 9) j with
      | false => exact ⟨j,le_rfl,fun _ => ⟨h,(fun _ => rfl),(fun _ h => h)⟩⟩
      | true =>
        obtain ⟨k,lt,ok⟩ := witness j ct h
        exact ⟨k,lt.le,fun _ => ok⟩
    · exact ⟨j,le_rfl,fun h => (ct h).elim⟩
  choose f le facts using all
  refine ⟨f,⟨le,?_,fun j ct => (facts j ct).1,fun j ct => (facts j ct).2.1⟩,
    fun j ct => (facts j ct).2.2⟩
  intro j ct eq
  apply contact_not_alias r red ct ands
  intro x
  have h := (facts j ct).2.1 x
  rw [eq,actual_not_value r,Bool.and_self] at h
  exact h
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
