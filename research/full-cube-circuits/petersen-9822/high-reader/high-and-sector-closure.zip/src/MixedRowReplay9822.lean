import MixedReaderTail9822
import MixedLowerBank9822
import MixedUpperTail9822
import MixedPartnerCold9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean MixedReaderPatch
theorem row_replay {C pre mid tail g q} (ro : Roster C pre (mid++q::tail) g)
    (red : Reduced 10 C.gates C.output) (d : Nat) (op : q.op=.or)
    (pin : 10+pre.length∈q.inputs)
    (hot : innerValue pre g (SignedClamp.singleton 9)=true)
    (no : ∀a∈mid++tail,10+pre.length∉a.inputs)
    (allAnd : ∀a∈C.gates,10+(pre++g::mid).length∈a.inputs → a.op=.and)
    (hd : d<10+(pre++g::mid).length) (dz : d≠10+pre.length)
    (cd : vl C.gates (SignedClamp.singleton 9) d=false)
    (ct : vl C.gates (SignedClamp.singleton 9) (10+(pre++g::mid).length)=false)
    (io : C.output<10+C.gates.length) (oz : C.output≠10+pre.length)
    (ot : C.output≠10+(pre++g::mid).length) :
    let x := SignedClamp.singleton 9
    let f := gate (10+(pre++g::mid).length) d (vl C.gates x)
    outerValue (pre.map f) ((mid++q::tail).map f) C.output x true=vl C.gates x C.output := by
  let x := SignedClamp.singleton (9 : Fin 10)
  let F := vl C.gates x
  let z := 10+pre.length
  let t := 10+(pre++g::mid).length
  let w := wiresFrom mid (wiresFrom pre (List.ofFn x)++[true])++[true]
  have te : t=z+1+mid.length := by simp [t,z];omega
  have wl : w.length=t+1 := by simp [w,t,length_wiresFrom];omega
  have vals := lower_reader_bank ro x hot
  have base := paired_bank pre mid x F (fun a m => no a (List.mem_append_left _ m)) (by
    intro j jb;apply vals j;simp [length_wiresFrom];omega)
  refine (upper_tail_value ro red op pin d F x).trans ?_
  apply mixed_tail_cold ro red x d F rfl z t rfl te w wl _ hd dz cd ct
    (fun a m => no a (List.mem_append_right _ m)) _ io oz ot
  · simpa only [te] using base
  · intro a m;apply allAnd
    rw [ro.split];simp [m]
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
