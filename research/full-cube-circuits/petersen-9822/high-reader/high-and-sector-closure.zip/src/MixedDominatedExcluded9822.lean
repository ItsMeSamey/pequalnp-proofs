import MixedRowReplay9822
import MixedPortFacts9822
import MixedPatchedNine9822
import AcceptedHighOrEntry9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean MixedReaderPatch
theorem dominated_mixed_impossible {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true)
    (dom : ∀j,j<10+C.gates.length → vl C.gates (SignedClamp.singleton 9) j=true →
      ∀x,vl C.gates x j=true → innerValue pre g x=true) : False := by
  obtain ⟨q,mem,op,pin⟩ := accepted_high_or_entry r cand red (by omega) s sl su upper
  obtain ⟨k,get⟩ := List.mem_iff_getElem?.mp mem
  obtain ⟨mid,tail,spl,_⟩ := split_at post _ q get
  subst post
  let row := SignedClamp.singleton (9 : Fin 10)
  let F := vl C.gates row
  let t := 10+(pre++g::mid).length
  have cut := physical_cut_split cand r.split r.inv (fun q h => r.pos q (List.mem_append_right _ h))
  have hot := hot_guard cut s upper
  obtain ⟨d,hd,dz,cd,ct,oz,ot,no,ev⟩ := mixed_port_facts r cand red seven s sl su hot op pin
  have ands := mixed_reader_children r cand red seven s sl su hot op pin
  have io : C.output<10+C.gates.length := by
    by_contra! beyond
    have on : vl C.gates (fun _ : Fin 10 => true) C.output=true := cand.2.2 _
    rw [vl_beyond _ _ _ beyond] at on;contradiction
  have high := patched_nine r cand red seven t d hd.le F ands (by
    intro x j warm on
    have jb : j<10+C.gates.length := by
      by_contra! beyond
      change vl C.gates row j=true at warm
      rw [vl_beyond _ _ _ beyond] at warm;contradiction
    have h := dom j jb warm x on
    rw [ev,actual_not_value r,h];rfl)
  have cold := row_replay r red d op pin (full_upper_nine r cand red seven).2 no ands hd dz cd ct io oz ot
  have off : vl C.gates row C.output=false := (cand.2.2 row).trans (singleton_zero 9)
  exact Bool.noConfusion (high.symm.trans (cold.trans off))
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
