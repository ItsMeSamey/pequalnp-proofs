import MixedNoCascade9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp LowHotElimination NonrawSupport
open PEqualNP.Outside.L_meta_9822.Clean
theorem mixed_reader_children {C pre p tail g u}
    (r : Roster C pre (p++u::tail) g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (hs : innerValue pre g (SignedClamp.singleton s)=true)
    (uo : u.op=.or) (up : 10+pre.length∈u.inputs) :
    ∀v∈C.gates,10+(pre++g::p).length∈v.inputs → v.op=.and := by
  let pref := pre++g::p
  have whole : C.gates=pref++u::tail := by simp [pref,r.split]
  intro v mem pin
  obtain ⟨k,get⟩ := List.mem_iff_getElem?.mp mem
  have later : pref.length<k := by have := (red.clean k v get).lt _ pin;dsimp [pref];omega
  have found : tail[k-(pref.length+1)]?=some v := by
    rw [whole,show pref++u::tail=(pref++[u])++tail by simp,List.getElem?_append_right (by simp;omega)] at get
    simpa using get
  obtain ⟨t,rest,spl,_⟩ := split_at tail _ v found
  have pos := r.pos v (List.mem_append_right _ (List.mem_append_right _ (List.mem_cons_of_mem _ (List.mem_iff_getElem?.mpr ⟨_,found⟩))))
  rcases pos with andv|orv
  · exact andv
  · subst tail
    exact False.elim (mixed_cascade_impossible r cand red seven s sl su hs uo orv up (by simpa using pin))
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
