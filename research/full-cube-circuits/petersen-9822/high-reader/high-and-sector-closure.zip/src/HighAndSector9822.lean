import PhysicalTwoMixed9822
import MixedHighPairImpossible9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport
open PEqualNP.Outside.L_meta_9822.Clean

theorem high_and_sector_of_c5 (lower : Research.LiteralC5.Lower)
    {C : Circuit} (cand : Candidate C) (red : Reduced 10 C.gates C.output)
    (one : C.gates.countP countsNot = 1) (high : 7 ≤ C.gates.countP countsAnd) : False := by
  obtain ⟨pre, g, post, split, inv, front, back, _⟩ := physical_cut_positive_lists cand one
  have r : Roster C pre post g := ⟨split, inv, fun a mem =>
    (List.mem_append.mp mem).elim (front a) (back a)⟩
  obtain ⟨eq, _, s, pair, inputs⟩ := two_mixed_cases r cand red high
  exact mixed_five_eight_impossible lower r cand red eq s pair ((inputs s).2.mpr (Or.inl rfl))

end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.high_and_sector_of_c5
