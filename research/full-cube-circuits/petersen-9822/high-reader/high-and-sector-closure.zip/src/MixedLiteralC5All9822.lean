import MixedLiteralC5Rows009822
import MixedLiteralC5Rows019822
import MixedLiteralC5Rows029822
import MixedLiteralC5Rows039822
import MixedLiteralC5Rows049822
import MixedLiteralC5Rows059822
import MixedLiteralC5Rows069822
import MixedLiteralC5Rows079822
import MixedLiteralC5Rows089822
import MixedLiteralC5Rows099822
import MixedLiteralC5Rows109822
import MixedLiteralC5Rows119822
import MixedLiteralC5Rows129822
import MixedLiteralC5Rows139822
import MixedLiteralC5Rows149822
import MixedLiteralC5Rows159822
import MixedLiteralC5Rows169822
import MixedLiteralC5Rows179822
import MixedLiteralC5Rows189822
import MixedLiteralC5Rows199822
import MixedLiteralC5Rows209822
import MixedLiteralC5Rows219822
import MixedLiteralC5Keys9822
namespace Research.LiteralC5.Table
theorem keysGood : keys.all row = true := by
  simp only [keys,List.all_cons,List.all_nil,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12,row13,row14,row15,row16,row17,row18,row19,row20,row21,row22,row23,row24,row25,row26,row27,row28,row29,row30,row31,row32,row33,row34,row35,row36,row37,row38,row39,row40,row41,row42,row43,row44,row45,row46,row47,row48,row49,row50,row51,row52,row53,row54,row55,row56,row57,row58,row59,row60,row61,row62,row63,row64,row65, Bool.true_and]
theorem checked {x : Nat} (hx : x ∈ extensions raws) : row x = true := by
  have hk := List.all_eq_true.mp keyCover _ hx
  have hy : x ∈ keys := by simpa using hk
  exact List.all_eq_true.mp keysGood _ hy
end Research.LiteralC5.Table
