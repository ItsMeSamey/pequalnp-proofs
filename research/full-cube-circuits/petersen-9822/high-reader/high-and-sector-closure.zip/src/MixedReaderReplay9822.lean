import MixedReaderOffRow9822
namespace PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
open PEqualNP.CircuitLowerBounds NinePatch
theorem replay_tail {r z d : Nat} (hd : d≤r) (dz : d≠z) (dr : d≠r)
    (tail : List Gate) (w : List Bool) (F G : Nat → Bool)
    (cold : F d=false) (rcold : F r=false) (away : ∀j,j≠z → j≠r → G j=F j)
    (base : ∀ j,j<w.length → w.getD j false=G j)
    (cl : CleanL w.length tail)
    (slots : ∀(k : Nat) (q : Gate),tail[k]?=some q → ∃a b,q.inputs=[a,b] ∧ z∉q.inputs ∧ (r∈q.inputs → q.op=.and ∧ a≠b))
    (target : ∀(k : Nat) (q : Gate),tail[k]?=some q → q.op.eval (q.inputs.map F)=G (w.length+k)) :
    ∀i,i<w.length+tail.length → (wiresFrom (tail.map (gate r d F)) w).getD i false=G i := by
  intro i hi
  apply aligned_run _ w G base _ _ i (by simpa using hi)
  · intro k q h j m
    rw [List.getElem?_map] at h
    cases e : tail[k]? with
    | none => simp [e] at h
    | some a =>
      have eq : gate r d F a=q := by simpa [e] using h
      exact (eq ▸ clean hd F (cl k a e)).lt j m
  · intro k q h
    rw [List.getElem?_map] at h
    cases e : tail[k]? with
    | none => simp [e] at h
    | some a =>
      have eq : gate r d F a=q := by simpa [e] using h
      obtain ⟨b,c,ins,without,both⟩ := slots k a e
      rw [←eq]
      exact (off_step ins without dz dr cold rcold away both).trans (target k a e)
end PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
