import MixedLiteralC5Table9822
import Mathlib.Data.List.Basic
namespace Research.LiteralC5.Table
def Below (a b : Nat) := ∀ i, a.testBit i=true → b.testBit i=true
theorem below_incl {a b : Nat} (h : Below a b) : incl a b=true := by
  apply beq_iff_eq.mpr
  apply Nat.eq_of_testBit_eq
  intro i; rw [Nat.testBit_and]
  cases e : a.testBit i <;> simp [e,h i]
theorem fold_bits (xs : List Nat) (v i : Nat) :
    (xs.foldl Nat.land v).testBit i=true ↔ v.testBit i=true ∧ ∀ a∈xs,a.testBit i=true := by
  induction xs generalizing v with
  | nil => simp
  | cons x xs ih =>
    rw [List.foldl_cons,ih]; simp [and_assoc]
theorem cover_bits (xs : List Nat) (t v i : Nat) :
    (meetCover xs t v).testBit i=true ↔ v.testBit i=true ∧ ∀ x∈xs,incl t x=true → x.testBit i=true := by
  unfold meetCover
  induction xs generalizing v with
  | nil => simp
  | cons x xs ih =>
    rw [List.foldl_cons,ih]
    by_cases h : incl t x=true <;> simp [h,and_assoc]
private def oneBit (l i : Nat) := if l.testBit i then 2^i else 0
private theorem and_one (l j : Nat) : l &&& 2^j = oneBit l j := by
  apply Nat.eq_of_testBit_eq
  intro i
  by_cases e : j=i
  · subst i; cases h : l.testBit j <;> simp [oneBit,h,Nat.testBit_two_pow]
  · cases h : l.testBit j <;> simp [oneBit,h,Nat.testBit_two_pow,e]
def cutSide (l : Nat) := l &&& 16781384
theorem cutSide_mem (l : Nat) : cutSide l∈splits := by
  have mask : (16781384 : Nat)=(2^3 ||| 2^6 ||| 2^12 ||| 2^24) := by decide
  have dist (a b : Nat) : l &&& (a ||| b) = ((l &&& a) ||| (l &&& b)) := by
    apply Nat.eq_of_testBit_eq; intro i
    simp only [Nat.testBit_and,Nat.testBit_or]
    cases l.testBit i <;> simp
  simp only [cutSide,mask,dist,and_one,oneBit]
  cases l.testBit 3 <;> cases l.testBit 6 <;> cases l.testBit 12 <;> cases l.testBit 24 <;> decide +kernel
theorem cutSide_left (l : Nat) : Below (cutSide l) l := by
  intro i h; exact (Bool.and_eq_true_iff.mp (by simpa only [cutSide,Nat.testBit_and] using h)).1
theorem cutSide_right (l r : Nat) (p : Below pos (l ||| r)) (hot : r.testBit 17=true) :
    Below (pos ^^^ cutSide l) r := by
  intro i hi
  have eq : pos=16781384 ||| 2^17 := by decide
  have pi := p i
  simp only [eq,cutSide,Nat.testBit_xor,Nat.testBit_and,Nat.testBit_or,Nat.testBit_two_pow] at hi pi
  by_cases h : 17=i
  · exact h ▸ hot
  · cases em : (16781384 : Nat).testBit i <;> cases el : l.testBit i <;> cases er : r.testBit i <;> simp_all
end Research.LiteralC5.Table
