import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row63 : row 18288752 = true := by decide +kernel
theorem row64 : row 18290432 = true := by decide +kernel
theorem row65 : row 18290559 = true := by decide +kernel
end Research.LiteralC5.Table
