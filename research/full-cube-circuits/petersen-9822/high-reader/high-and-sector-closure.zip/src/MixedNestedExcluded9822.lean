import MixedDominatedExcluded9822
import MixedNestedWires9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean
theorem mixed_high_literal_nine {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    ∃k : Nat,∃q : Gate,k<pre.length ∧ pre[k]?=some q ∧ q.op=.or ∧ g.inputs=[10+k] ∧
      (q.inputs=[s.val,9] ∨ q.inputs=[9,s.val]) := by
  obtain ⟨k,q,b,kp,qsite,qo,ig,qp,raw|⟨l,v,d,lk,vs,vo,be,vp⟩⟩ :=
    mixed_guard_layout r cand red seven s sl su upper
  · subst b;exact ⟨k,q,kp,qsite,qo,ig,qp⟩
  · subst b
    exact False.elim (dominated_mixed_impossible r cand red seven s sl su upper
      (nested_hot_implies_guard r cand red seven kp lk qsite vs qo vo ig qp vp))
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.mixed_high_literal_nine
