import MixedLiteralC5Last9822
import MixedLiteralC5All9822
import MixedLiteralC5Recipe9822
import MixedC5Terminal9822
import MixedLiteralC5Semantics9822
namespace Research.LiteralC5
open Table
private theorem twoSteps {ys zs : List Nat}
    (h : ys = raws ∨ ∃ g ∈ extensions raws, ys = g::raws)
    (k : zs = ys ∨ ∃ g ∈ extensions ys, zs = g::ys) : bad zs = false := by
  have nextOK (g : Nat) (hg : g ∈ extensions raws) :
      bad (g::raws) = false ∧ ∀ j ∈ extensions (g::raws), bad (j::g::raws) = false := by
    simpa [row,List.all_eq_true] using checked hg
  rcases h with eq|⟨g,hg,eq⟩ <;> subst ys
  · rcases k with eq|⟨j,hj,eq⟩ <;> subst zs
    · exact baseOK
    · exact (nextOK _ hj).1
  · rcases k with eq|⟨j,hj,eq⟩ <;> subst zs
    · exact (nextOK _ hg).1
    · exact (nextOK _ hg).2 _ hj
theorem numerical (a b : Fin 6 → Bool) (c d : Fin 7 → Bool) (e f : Fin 8 → Bool)
    (g : Fin 9 → Bool) : ¬ (∀ x, eval3 a b c d e f g x = cycle x) := by
  intro h
  obtain ⟨a,b,c,d,e,f,g,ha,hb,hc,hd,he,hf,hg,p,n⟩ := recipes_of_eval3 _ _ _ _ _ _ _ h
  obtain ⟨ys,hys,ry⟩ := normalizeGate (initial_rep raws) ha hb
  obtain ⟨zs,hzs,rz⟩ := normalizeGate ry hc hd
  obtain ⟨w,l,r,hw,hl,hr,ns⟩ := lastNarrow rz he hf hg
  obtain ⟨p',n'⟩ := preservesRows ns p n
  have badyes := bad_of_output zs w l r (fun _ h => hw h) (fun _ h => hl h)
    (fun _ h => hr h) p' n'
  rw [twoSteps hys hzs] at badyes
  contradiction
theorem lower : Lower := by
  intro t fit
  by_contra short
  obtain ⟨a,b,c,d,e,f,g,h⟩ := semantic_three t fit (by omega)
  exact numerical a b c d e f g h
end Research.LiteralC5
#print axioms Research.LiteralC5.lower
