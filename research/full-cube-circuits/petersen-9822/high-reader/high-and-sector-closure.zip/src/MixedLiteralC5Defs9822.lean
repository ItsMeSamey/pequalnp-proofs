import Research.WegenerThreshold

namespace Research.LiteralC5

def lift (x : Fin 5 → Bool) : Fin 6 → Bool := Fin.lastCases (!(x 4)) x

def cycle (x : Fin 5 → Bool) : Bool :=
  decide (∃ i : Fin 5, x i = true ∧ x (i+1) = true)

def Lower : Prop := ∀ t : FreeAndNet.Net (Fin 6),
  (∀ x : Fin 5 → Bool, t.eval (lift x) = cycle x) → 4 ≤ t.cost

end Research.LiteralC5
