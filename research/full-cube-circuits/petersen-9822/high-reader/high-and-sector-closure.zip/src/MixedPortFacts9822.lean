import MixedPartnerCold9822
import MixedLowerBank9822
import MixedReaderChildren9822
import NinePatchChoice9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean
theorem mixed_port_facts {C pre mid tail g q} (r : Roster C pre (mid++q::tail) g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (hs : innerValue pre g (SignedClamp.singleton s)=true)
    (op : q.op=.or) (hit : 10+pre.length∈q.inputs) :
    let z := 10+pre.length
    let t := 10+(pre++g::mid).length
    let row := SignedClamp.singleton 9
    ∃d<t,d≠z ∧ vl C.gates row d=false ∧ vl C.gates row t=false ∧ C.output≠z ∧ C.output≠t ∧
      (∀a∈mid++tail,z∉a.inputs) ∧
      ∀x : Input, vl C.gates x t=(vl C.gates x z || vl C.gates x d) := by
  let z := 10+pre.length
  let p := pre++g::mid
  let t := 10+p.length
  let row := SignedClamp.singleton (9 : Fin 10)
  have whole : C.gates=p++q::tail := by simp [p,r.split]
  have site : C.gates[p.length]?=some q := by simp [whole]
  obtain ⟨a,b,ab,bb,ne,ins⟩ : ∃a b,a<t ∧ b<t ∧ a≠b ∧ q.inputs=[a,b] := by
    rcases red.shape site with ⟨neg,_⟩|⟨_,a,b,ab,bb,ne,ins⟩
    · simp_all
    · exact ⟨a,b,ab,bb,ne,ins⟩
  obtain ⟨d,hd,dz,pins⟩ : ∃d<t,d≠z ∧ (q.inputs=[z,d] ∨ q.inputs=[d,z]) := by
    change z∈q.inputs at hit
    rw [ins] at hit
    rcases List.mem_cons.mp hit with e|e
    · subst a;exact ⟨b,bb,ne.symm,Or.inl ins⟩
    · have e' : z=b := by simpa using e
      subst b;exact ⟨a,ab,ne,Or.inr ins⟩
  have eq (x : Input) : vl C.gates x t=(vl C.gates x z || vl C.gates x d) := by
    rw [show t=10+p.length from rfl,vl_gate _ red.clean _ _ _ site]
    rcases pins with pi|pi <;> simp [pi,op,GateOp.eval,Bool.or_comm]
  have comp : ∀ x : Input,vl C.gates x C.output=edge x := cand.2.2
  have zero : vl C.gates (fun _ : Fin 10 => false) z=true := by
    rw [show z=10+pre.length from rfl,actual_not_value r,cold_empty r cand (by omega)];rfl
  have oz : C.output≠z := by intro h;have e := comp (fun _ => false);rw [h,zero] at e;contradiction
  have ot : C.output≠t := by intro h;have e := comp (fun _ => false);rw [h,eq,zero] at e;contradiction
  obtain ⟨up,hot⟩ := full_upper_nine r cand red seven
  have cut := physical_cut_split cand r.split r.inv (fun q h => r.pos q (List.mem_append_right _ h))
  have atRow := cut.computes row
  change innerValue pre g row=true at hot
  rw [hot] at atRow
  have diff : outerValue pre (mid++q::tail) C.output row false≠outerValue pre (mid++q::tail) C.output row true := by
    rw [up,show outerValue pre (mid++q::tail) C.output row false=false from atRow.trans (singleton_zero 9)]
    decide
  have cnt := high_unique_reader r cand (by omega) s sl su hs red
  have bank := lower_reader_bank r row hot
  have cd : vl C.gates row d=false := by
    rw [←bank d (by simp [length_wiresFrom];dsimp [t,p] at hd;simp at hd;omega)]
    exact changed_or_cold _ row op pins oz cnt diff
  refine ⟨d,hd,dz,cd,?_,oz,ot,only_reader_away hit cnt,eq⟩
  rw [eq,show z=10+pre.length from rfl,actual_not_value r,hot,cd];rfl
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
