import NineUpperOnlyBudget9822
import NinePatchOrder9822
import NineHotReader9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport PEqualNP.Outside.L_meta_9822.Clean NinePatch

private theorem upper_patch_count (z : Nat) (f : Nat → Nat) (t : List Gate) :
    (t.map (patch z f)).countP countsAnd=t.countP countsAnd := by
  induction t with
  | nil => rfl
  | cons q qs ih =>
    simp only [List.map_cons,List.countP_cons,ih]
    rfl

theorem upper_nine_impossible_of_choices {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (upper : outerValue pre post C.output (SignedClamp.singleton 9) true=true)
    (other : ∀ j : Fin 10,j≠9 → outerValue pre post C.output (SignedClamp.singleton j) true=false)
    (f : Nat → Nat) (ch : NineChoice C pre post g f)
    (ord : ∀ j,AtPartner post (10+pre.length) j → ∀ x : Input,
        outerValue pre post (f j) x true=true → outerValue pre post j x true=true) : False := by
  let z := 10+pre.length
  have ands := nine_direct_and_at_upper r cand red seven upper other
  have eval : ∀ x : Input,vl C.gates x C.output=edge x := cand.2.2
  have outBound : C.output<10+C.gates.length := by
    by_contra! no
    have on := eval (fun _ => true)
    rw [vl_beyond _ _ _ no] at on
    contradiction
  have notOut : C.output≠z := by
    intro eq
    have cold := eval (fun _ => false)
    rw [eq,actual_not_value r,cold_empty r cand seven] at cold
    contradiction
  have run := patched_run r red f ch ands
  let t := post.map (patch z f)
  have ok : CleanL 10 (pre++g::t) := by
    have before : CleanL 10 ((pre++[g])++post) := by simpa [r.split] using red.clean
    simpa [t,List.append_assoc] using patch_suffix_clean (z:=z) (pre++[g]) post f ch.earlier before
  apply rewritten_clamp_impossible r cand red seven t ok (by simp [t])
    (upper_patch_count z f post).ge (by
      intro q hq
      obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hq
      exact r.pos a (List.mem_append_right _ ha))
  · intro x
    have done := run x (!(innerValue pre g x)) (by
      intro j act
      rw [actual_not_value r]
      exact (ch.agrees j act x).symm) outBound notOut
    change (wiresFrom (pre++g::t) (List.ofFn x)).getD C.output false=_
    rw [wiresFrom_append]
    let w := wiresFrom pre (List.ofFn x)
    have bit : g.op.eval (g.inputs.map fun i => w.getD i false)= !(innerValue pre g x) := by rw [r.inv];rfl
    change (wiresFrom t (w++[_])).getD C.output false=_
    rw [bit];exact done
  · intro j
    by_cases isNine : j=9
    · subst j
      let x := SignedClamp.singleton 9
      have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
      have hot := hot_guard cut 9 upper
      have off : vl C.gates x z=false := (actual_not_value r x).trans (by rw [hot];rfl)
      have same := run x true (by
        intro j act
        have cold := ch.cold j act
        change (true && vl C.gates (SignedClamp.singleton 9) (f j))=(vl C.gates x z && _)
        rw [cold,off];rfl) outBound notOut
      exact same.trans ((eval x).trans (singleton_zero 9))
    · cases h : outerValue pre t C.output (SignedClamp.singleton j) true with
      | false => rfl
      | true =>
        have cmp := patched_upper_le r red f ch.earlier (SignedClamp.singleton j)
          (fun k ct => ord k ct _) C.output outBound h
        rw [other j isNine] at cmp
        contradiction
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.upper_nine_impossible_of_choices
