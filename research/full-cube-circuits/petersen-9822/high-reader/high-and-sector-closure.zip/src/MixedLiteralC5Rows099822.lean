import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row27 : row 267388 = true := by decide +kernel
theorem row28 : row 268108 = true := by decide +kernel
theorem row29 : row 394316 = true := by decide +kernel
end Research.LiteralC5.Table
