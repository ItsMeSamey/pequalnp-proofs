import Init
namespace Research.LiteralC5.Table
abbrev Col := Nat
def pos : Col := 16912456
def neg : Col := 1378103
def live : Col := 18290559
def raws : List Col := [131626,263244,1052784,16783104,18284544,6015]
def splits : List Col := [0,8,64,72,4096,4104,4160,4168,16777216,16777224,
  16777280,16777288,16781312,16781320,16781376,16781384]
def incl (a b : Col) := a &&& b == a
def meets (cols : List Col) : List Col :=
  cols.foldl (fun old x =>
    old.foldl (fun acc y =>
      let t := y &&& x
      if t &&& pos != 0 && !acc.contains t then t::acc else acc) old) [live]
def extensions (cols : List Col) : List Col :=
  let m := meets cols
  m.foldl (fun acc a => m.foldl (fun acc b =>
    if a < b && !incl (a &&& pos) b && !incl (b &&& pos) a then
      let u := a ||| b
      if acc.contains u then acc else u::acc
    else acc) acc) []
def meetCover (cols : List Col) (target initial : Col) :=
  cols.foldl (fun old x => if incl target x then old &&& x else old) initial
def bad (cols : List Col) : Bool :=
  let n := meetCover cols pos neg
  let side (a : Col) := if a == 0 then 0 else meetCover cols a n
  splits.any fun a => side a ||| side (pos ^^^ a) == 0
def row (a : Col) : Bool :=
  let c := a::raws
  !bad c && (extensions c).all fun b => !bad (b::c)
end Research.LiteralC5.Table
