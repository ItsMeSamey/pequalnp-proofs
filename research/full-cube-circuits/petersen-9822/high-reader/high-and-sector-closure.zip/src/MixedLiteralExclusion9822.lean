import MixedLiteralEmbedding9822
import MixedLiteralCompiler9822
open FreeAndNet Research.OddOr Research.OddOr.Graph9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp NonrawSupport OuterNet PEqualNP.Outside.L_meta_9822.Clean
theorem literal_guard_excluded (lower : Research.LiteralC5.Lower) {C a b mid tail g H R}
    (r : Roster C (a++H::b) (mid++R::tail) g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (caseS : s=5 ∨ s=8)
    (upper : outerValue (a++H::b) (mid++R::tail) C.output (SignedClamp.singleton s) true=true)
    (hop : H.op=.or) (hpins : H.inputs=[s.val,9] ∨ H.inputs=[9,s.val])
    (guard : g.inputs=[10+a.length])
    (rop : R.op=.or) (rpin : 10+(a++H::b).length∈R.inputs) : False := by
  let p := a++copy 9::b
  let z := 10+(a++H::b).length
  let t := mid++copy z::tail
  have donor : ∀ q∈(a++H::b)++(mid++R::tail),PositiveOp q ∧ q.inputs.length≤2 := by
    intro q h
    refine ⟨r.pos q h,(cand.1 q ?_).2⟩
    rw [r.split]
    simp only [List.mem_append,List.mem_cons] at h ⊢
    tauto
  have ready : ∀ q∈p++t,PositiveOp q ∧ q.inputs.length≤2 := by
    intro q mem
    simp only [p,t,List.mem_append,List.mem_cons] at mem
    have copied (j : Nat) : PositiveOp (copy j) ∧ (copy j).inputs.length≤2 := ⟨Or.inl rfl,by simp [copy]⟩
    rcases mem with (ha|rfl|hb)|(hm|rfl|ht)
    · exact donor q (by simp [ha])
    · exact copied _
    · exact donor q (by simp [hb])
    · exact donor q (by simp [hm])
    · exact copied _
    · exact donor q (by simp [ht])
  obtain ⟨cost,eq⟩ := mixed_seven_actual r cand red seven s caseS upper 9 hop hpins rop rpin
  have raw (x : Input) : innerValue p g x=x 9 := by
    unfold innerValue
    rw [guard]
    change vl p x (10+a.length)=x 9
    have idx : p[a.length]?=some (copy 9) := by simp [p]
    rw [vl_legal_site p x a.length (copy 9) idx (by intro j m; simp [copy] at m; omega)]
    have nine := vl_input p x 9 (by decide : 9<10)
    simp [copy,GateOp.eval,nine]
  have read : ∀ x : Input,x s=false → outerValue p t C.output x (!(x 9))=edge x := by
    intro x off
    rw [←raw x]
    exact eq x off
  obtain ⟨u,uc,fit⟩ := literal_model p t C.output s ready cost read
  have bad := LiteralNine.no_seven lower s caseS u fit
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.literal_guard_excluded
