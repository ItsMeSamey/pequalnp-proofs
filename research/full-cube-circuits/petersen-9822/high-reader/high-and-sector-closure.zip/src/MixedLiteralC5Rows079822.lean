import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row21 : row 135722 = true := by decide +kernel
theorem row22 : row 135802 = true := by decide +kernel
theorem row23 : row 136960 = true := by decide +kernel
end Research.LiteralC5.Table
