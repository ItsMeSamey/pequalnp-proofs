import MixedPositiveUse9822
import MixedReaderPrefix9822
import MixedHotReaderNet9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean MixedReaderPatch
theorem upper_tail_value {C pre mid tail g q} (ro : Roster C pre (mid++q::tail) g)
    (red : Reduced 10 C.gates C.output) (op : q.op=.or) (hit : 10+pre.length∈q.inputs)
    (d : Nat) (hot : Nat → Bool) (x : Input) :
    let t := 10+(pre++g::mid).length
    let f := gate t d hot
    let w := wiresFrom mid (wiresFrom pre (List.ofFn x)++[true])++[true]
    outerValue (pre.map f) ((mid++q::tail).map f) C.output x true=
      (wiresFrom (tail.map f) w).getD C.output false := by
  let t := 10+(pre++g::mid).length
  let f := gate t d hot
  have whole : C.gates=(pre++g::mid)++q::tail := by simp [ro.split]
  have keep := untouched_prefix (n:=10) (d:=d) (pre++g::mid) hot (whole ▸ red.clean)
  have abs (a : Gate) (m : a∈pre++g::mid) : t∉a.inputs := by
    obtain ⟨k,get⟩ := List.mem_iff_getElem?.mp m
    have kp : k<(pre++g::mid).length := List.getElem?_eq_some_iff.mp get |>.choose
    have old : C.gates[k]?=some a := by rw [whole,List.getElem?_append_left kp];exact get
    intro h
    exact (by dsimp [t] at *;have := (red.clean k a old).lt _ h;omega)
  have pp : pre.map f=pre := unchanged_map hot (fun a m => abs a (List.mem_append_left _ m))
  have mm : mid.map f=mid := unchanged_map hot (fun a m => abs a (List.mem_append_right _ (List.mem_cons_of_mem _ m)))
  have qsite : C.gates[(pre++g::mid).length]?=some q := by simp [whole]
  have qq : f q=q := unchanged hot (fun mem => (Nat.lt_irrefl t) ((red.clean _ q qsite).lt t mem))
  change outerValue (pre.map f) ((mid++q::tail).map f) _ _ _=_
  rw [pp,List.map_append,List.map_cons,mm,qq]
  have eq := (or_hot_reader_eval pre mid (tail.map f) q op hit C.output x).symm
  apply eq.trans
  change (wiresFrom (pre++topGate::(mid++topGate::tail.map f)) _).getD _ false=_
  rw [wiresFrom_append]
  change (wiresFrom (mid++topGate::tail.map f) (wiresFrom pre (List.ofFn x)++[true])).getD _ false=_
  rw [wiresFrom_append mid]
  rfl
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
