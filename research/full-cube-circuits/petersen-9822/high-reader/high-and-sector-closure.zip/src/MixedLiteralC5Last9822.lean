import MixedLiteralC5Narrow9822
namespace Research.LiteralC5.Table
theorem lastNarrow {xs old e f g : List Nat} (rep : Represents xs old) (he : e ⊆ old)
    (hf : f ⊆ old) (hg : g ⊆ (val e ||| val f)::old) :
    ∃ w l r : List Nat, w ⊆ xs ∧ l ⊆ xs ∧ r ⊆ xs ∧
    Narrow (val w &&& (val l ||| val r)) (val g) := by
  let c := val e ||| val f
  let w := g.filter (fun z => z != c)
  have hw : w ⊆ old := by
    intro z hz
    obtain ⟨orig,neq⟩ := List.mem_filter.mp hz
    exact (List.mem_cons.mp (hg orig)).resolve_left (by simpa [c] using neq)
  obtain ⟨w',hws,wn⟩ := narrowRecipe rep hw
  by_cases root : c ∈ g
  · obtain ⟨l,hl,ln⟩ := narrowRecipe rep he
    obtain ⟨r,hr,rn⟩ := narrowRecipe rep hf
    have cn := nar_or ln rn
    refine ⟨w',l,r,hws,hl,hr,?_⟩
    intro k
    have split : (val g).testBit k = true ↔ (val w).testBit k = true ∧ c.testBit k = true := by
      simp only [val,bit_fold]
      constructor
      · rintro ⟨base,all⟩
        exact ⟨⟨base,fun z hz => all z (List.mem_filter.mp hz).1⟩,all c root⟩
      · rintro ⟨⟨base,all⟩,hit⟩
        refine ⟨base,fun z hz => ?_⟩
        by_cases eq : z = c
        · simpa [eq] using hit
        · exact all z (List.mem_filter.mpr ⟨hz,by simpa using eq⟩)
    simp only [Nat.testBit_and,Bool.and_eq_true,split]
    exact ⟨And.imp (wn k).1 (cn k).1,fun p => And.imp ((wn k).2 p) ((cn k).2 p)⟩
  · have inc : g ⊆ old := fun z hz => (List.mem_cons.mp (hg hz)).resolve_left
        (fun eq => root (by simpa only [c,← eq] using hz))
    obtain ⟨q,hq,qn⟩ := narrowRecipe rep inc
    refine ⟨q,[],[],hq,by simp,by simp,?_⟩
    have eq : val q &&& (val [] ||| val []) = val q := by
      apply Nat.eq_of_testBit_eq; intro k
      apply Bool.eq_iff_iff.mpr
      simp [val,Nat.testBit_and,bit_fold,and_assoc,and_comm,and_left_comm]
    rw [eq]; exact qn
theorem preservesRows {a b : Nat} (h : Narrow a b) (p : b &&& pos = pos) (n : b &&& neg = 0) :
    a &&& pos = pos ∧ a &&& neg = 0 := by
  constructor
  · apply Nat.eq_of_testBit_eq; intro k; apply Bool.eq_iff_iff.mpr
    have hp := congrArg (fun z : Nat => z.testBit k) p
    simp only [Nat.testBit_and] at hp ⊢
    cases ps : pos.testBit k with
    | false => simp [ps]
    | true =>
      have bp : b.testBit k = true := by simpa [ps] using hp
      simp [ps,(h k).2 ps bp]
  · apply Nat.eq_of_testBit_eq; intro k
    have hn := congrArg (fun z : Nat => z.testBit k) n
    simp only [Nat.testBit_and] at hn ⊢
    have dif := (h k).1
    cases ha : a.testBit k <;> cases hb : b.testBit k <;> cases he : neg.testBit k <;> simp_all
end Research.LiteralC5.Table
