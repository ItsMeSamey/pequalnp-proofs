import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row0 : row 72 = true := by decide +kernel
theorem row1 : row 618 = true := by decide +kernel
theorem row2 : row 4104 = true := by decide +kernel
end Research.LiteralC5.Table
