import AcceptedHighSpread9822
import MixedOuterReaderRigidity9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport OuterNet LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean FreeAndNet Research.OddOr
theorem upper_middle_false {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (middle : s=6 ∨ s=7) : outerValue pre post C.output (SignedClamp.singleton s) true=false := by
  by_contra! non
  have upper : outerValue pre post C.output (SignedClamp.singleton s) true=true := by simpa using non
  have sl : 5≤s.val := by rcases middle with rfl|rfl <;> decide
  have su : s.val≤8 := by rcases middle with rfl|rfl <;> decide
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have others := other_guard_cold r cand red seven s sl su (hot_guard cut s upper)
  obtain ⟨q,m,op,pin⟩ := accepted_high_or_entry r cand red (by omega) s sl su upper
  obtain ⟨k,site⟩ := List.mem_iff_getElem?.mp m
  obtain ⟨left,right,full,_⟩ := split_at post k q site
  subst post
  exact no_mixed_middle_or_reader r cand (by omega) s middle others op pin
theorem upper_singleton_labels {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7) :
    let K := fun j => outerValue pre post C.output (SignedClamp.singleton j) true
    K 9=true ∧ (∀j,K j=true → j=5 ∨ j=8 ∨ j=9) ∧ ¬(K 5=true ∧ K 8=true) := by
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  refine ⟨(full_upper_nine r cand red seven).1,?_,?_⟩
  · intro j on
    have guard := hot_guard cut j on
    by_cases lo : j.val≤4
    · exact (low_hot_impossible r (by omega) j lo guard cand).elim
    have ne6 : j≠6 := by rintro rfl; exact Bool.noConfusion ((upper_middle_false r cand red seven 6 (Or.inl rfl)).symm.trans on)
    have ne7 : j≠7 := by rintro rfl; exact Bool.noConfusion ((upper_middle_false r cand red seven 7 (Or.inr rfl)).symm.trans on)
    have cases : ∀a : Fin 10,4<a.val → a≠6 → a≠7 → a=5 ∨ a=8 ∨ a=9 := by decide
    exact cases j (by omega) ne6 ne7
  · rintro ⟨h5,h8⟩
    exact no_two_high_singletons r cand red seven 5 8 (by decide) (by decide) (by decide)
      (hot_guard cut 5 h5) (hot_guard cut 8 h8)
theorem outer_mixed_exact_eight {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (outer : s=5 ∨ s=8) (on : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    ∃u : Net (Fin 10), (∀ x,u.eval x=outerValue pre post C.output x true) ∧
      u.cost=8 ∧ hits s u=1 ∧ hits 9 (pin s u)=1 := by
  have sl : 5≤s.val := by rcases outer with rfl|rfl <;> decide
  have su : s.val≤8 := by rcases outer with rfl|rfl <;> decide
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have other := other_guard_cold r cand red seven s sl su (hot_guard cut s on)
  obtain ⟨q,m,op,hit⟩ := accepted_high_or_entry r cand red (by omega) s sl su on
  obtain ⟨k,site⟩ := List.mem_iff_getElem?.mp m
  obtain ⟨left,right,full,_⟩ := split_at post k q site
  subst post
  exact mixed_outer_reader_rigidity r cand (by omega) s outer other op hit
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.upper_singleton_labels
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.outer_mixed_exact_eight
