import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row3 : row 4160 = true := by decide +kernel
theorem row4 : row 4216 = true := by decide +kernel
theorem row5 : row 4650 = true := by decide +kernel
end Research.LiteralC5.Table
