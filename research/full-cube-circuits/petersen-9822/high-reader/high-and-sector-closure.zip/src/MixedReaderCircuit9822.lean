import MixedReaderActual9822
import RetimingMinimum9822
namespace PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
open PEqualNP.CircuitLowerBounds
theorem clean_list {n r d : Nat} {gs : List Gate} (cl : CleanL n gs) (hd : d≤r) (hot : Nat → Bool) :
    CleanL n (gs.map (gate r d hot)) := by
  intro k q hq
  rw [List.getElem?_map] at hq
  cases e : gs[k]? with
  | none => simp [e] at hq
  | some a =>
    have eq : gate r d hot a=q := by simpa [e] using hq
    exact eq ▸ clean hd hot (cl k a e)
theorem actual_vl {n r d : Nat} {gs : List Gate} (cl : CleanL n gs) (hd : d≤r)
    (hot : Nat → Bool) (x : Fin n → Bool) (andRead : ∀q∈gs,r∈q.inputs → q.op=.and)
    (agree : ∀j,hot j=true → vl gs x j=true → vl gs x r=vl gs x d) (i : Nat) :
    vl (gs.map (gate r d hot)) x i=vl gs x i := by
  by_cases small : i<n+gs.length
  · apply actual cl hd hot (vl gs x) (List.ofFn x) (by simp) _ _ andRead agree i small
    · intro j h
      rw [vl_input _ _ _ h]
      exact getD_ofFn n x false ⟨j,h⟩
    · intro k q h;exact (vl_gate gs cl x k q h).symm
  · unfold vl
    rw [List.getD_eq_default _ _ (by simp [length_wiresFrom];omega),
      List.getD_eq_default _ _ (by simp [length_wiresFrom];omega)]
end PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
