import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row30 : row 394862 = true := by decide +kernel
theorem row31 : row 1052792 = true := by decide +kernel
theorem row32 : row 1053306 = true := by decide +kernel
end Research.LiteralC5.Table
