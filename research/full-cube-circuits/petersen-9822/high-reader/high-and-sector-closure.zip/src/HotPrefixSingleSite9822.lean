import HighSocketIsGuard9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination PEqualNP.Outside.L_meta_9822.Clean
theorem hot_prefix_one_site {C pre post g} (r : Roster C pre post g)
    (red : Reduced 10 C.gates C.output) (i : Fin 10) (A stop : Nat) (endP : stop≤pre.length)
    (dominates : ∀x : Input,x i=true → vl C.gates x A=true)
    (orSite : ∀ k q,k<stop → C.gates[k]?=some q → q.op=.or →
      vl C.gates (SignedClamp.singleton i) (10+k)=true → 10+k=A) :
    ∀b,b<10+stop → vl C.gates (SignedClamp.singleton i) b=true → b=i.val ∨ b=A := by
  intro b
  induction b using Nat.strong_induction_on with
  | ind b ih =>
    intro bound on
    by_cases raw : b<10
    · have eq := (vl_input _ _ _ raw).symm.trans on
      exact Or.inl (congrArg Fin.val (by simpa [SignedClamp.singleton] using eq : (⟨b,raw⟩ : Fin 10)=i))
    let k := b-10
    have id : b=10+k := by dsimp [k];omega
    have ks : k<stop := by omega
    have kp : k<pre.length := by omega
    let q := pre[k]
    have site : pre[k]?=some q := List.getElem?_eq_getElem kp
    have full : C.gates[k]?=some q := by rw [r.split,List.getElem?_append_left kp];exact site
    have pos := r.pos q (List.mem_append_left _ (List.mem_iff_getElem?.mpr ⟨k,site⟩))
    rcases pos with aa|oo
    · rcases red.clean k q full with ⟨bad,_⟩|⟨_,a,c,al,cl,ins⟩
      · simp_all
      have ac := Deletion.distinct_and_pins red k q full aa a c ins
      rw [id,vl_gate _ red.clean _ _ _ full,aa,ins] at on
      have warm : vl C.gates (SignedClamp.singleton i) a=true ∧ vl C.gates (SignedClamp.singleton i) c=true := by
        simpa [GateOp.eval] using on
      have na := no_absorbing_product red q full aa a c ac (by simp [ins]) (by simp [ins])
      have nc := no_absorbing_product red q full aa c a ac.symm (by simp [ins]) (by simp [ins])
      have imp : ∀x : Input,vl C.gates x i.val=true → vl C.gates x A=true :=
        fun x h => dominates x ((vl_input _ _ _ i.isLt).symm.trans h)
      rcases ih a (by omega) (by omega) warm.1 with l|l <;> rcases ih c (by omega) (by omega) warm.2 with m|m
      · omega
      · exact (na (by simpa only [l,m] using imp)).elim
      · exact (nc (by simpa only [l,m] using imp)).elim
      · omega
    · exact Or.inr (id.trans (orSite k q ks full oo (id ▸ on)))
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.hot_prefix_one_site
