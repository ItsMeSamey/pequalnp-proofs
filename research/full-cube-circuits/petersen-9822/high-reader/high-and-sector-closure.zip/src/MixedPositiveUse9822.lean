import UpperSingletonSectors9822
import MixedGuardLayout9822
import PrivateUpperModel9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean Research.OddOr.Envelope Research.OddOr.Graph9822
theorem mixed_upper_floor {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (hs : innerValue pre g (SignedClamp.singleton s)=true)
    (J : Circuit) (cl : CleanL 10 J.gates) (pos : ∀q∈J.gates,PositiveOp q)
    (rep : ∀x : Input,vl J.gates x J.output=outerValue pre post C.output x true) :
    8≤J.gates.countP (ofOp .or) := by
  let u := CircuitCompiler.compile 10 J
  have ev (x : Input) : u.eval x=outerValue pre post C.output x true :=
    (CircuitCompiler.compile_eval _ _ (fun q m => ⟨pos q m,(clean_nok _ _ cl q m).1.2⟩) x).trans (rep x)
  have other := other_guard_cold r cand red seven s sl su hs
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have high : s∈([5,6,7,8]:List (Fin 10)) := by
    have all : ∀ j : Fin 10,5≤j.val → j.val≤8 → j∈([5,6,7,8]:List (Fin 10)) := by decide
    exact all s sl su
  have cold (j : Fin 10) (js : j≠s) (jn : j≠9) : sees u {j}=false := by
    have eq : inputOn {j}=SignedClamp.singleton j := by funext i;simp [inputOn,SignedClamp.singleton]
    change u.eval (inputOn {j})=false
    rw [eq,ev]
    have on := cut.computes (SignedClamp.singleton j)
    rw [other j js jn] at on;exact on.trans (singleton_zero j)
  have edges (a b : Fin 10) (h : f {a,b}=true) : sees u {a,b}=true := by
    change u.eval (inputOn {a,b})=true
    rw [ev];exact positive_upper cut _ h
  have price := mixed_nine_envelope s high u cold edges
  have flag : CircuitCompiler.orFlag=ofOp .or := by
    funext q;cases q with | mk op ins => cases op <;> simp [CircuitCompiler.orFlag,ofOp]
  have cost := CircuitCompiler.compile_cost 10 J
  change u.cost≤_ at cost
  rw [←List.countP_eq_length_filter,flag] at cost
  split at price <;> omega
theorem mixed_positive_use {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    ∃i : Nat,g.inputs=[i] ∧ ∃w∈C.gates,w.op=.and ∧ i∈w.inputs := by
  classical
  let row := SignedClamp.singleton s
  have cut := physical_cut_split cand r.split r.inv (fun q h => r.pos q (List.mem_append_right _ h))
  have hot := hot_guard cut s upper
  obtain ⟨k,q,b,kp,site,qo,_,_,pins,unary⟩ := high_socket_is_guard r cand red (by omega) s sl su upper
  have dom (x : Input) : vl C.gates x (10+k)=innerValue pre g x := by
    rw [visible r (10+k) (by omega)];simp [innerValue,unary]
  have outdiff : C.output≠10+k := by
    intro e
    have z : vl C.gates row C.output=false := (cand.2.2 _).trans (singleton_zero s)
    rw [e,dom] at z
    exact Bool.noConfusion (z.symm.trans hot)
  have pub : ∃w∈C.gates,PositiveOp w ∧ 10+k∈w.inputs := by
    by_contra! no
    obtain ⟨u,m,op,pin⟩ := accepted_high_or_entry r cand red (by omega) s sl su upper
    obtain ⟨p,mid,fp,sz⟩ := split_at pre k q site
    subst pre
    let mark := fun w : Gate => decide (w=u)
    have readers (w : Gate) (_ : w∈post) (on : mark w=true) : w.op=.or ∧ 10+(p++q::mid).length∈w.inputs := by
      have e : w=u := of_decide_eq_true on
      exact e.symm ▸ ⟨op,pin⟩
    obtain ⟨J,cl,po,cap,rep⟩ := private_upper_model q qo r cand red (by omega)
      (fun w m h => by simpa only [sz] using no w m h) (by omega) mark readers
    have floor := mixed_upper_floor r cand red seven s sl su hot J cl po rep
    have nz : 0<post.countP mark := List.countP_pos_iff.mpr ⟨u,m,by simp [mark]⟩
    omega
  obtain ⟨w,m,op,pin⟩ := pub
  refine ⟨10+k,unary,w,m,?_,pin⟩
  rcases op with a|o
  · exact a
  · obtain ⟨j,atW⟩ := List.mem_iff_getElem?.mp m
    have late := (red.clean j w atW).lt _ pin
    have wr : vl C.gates row (10+j)=true := by
      rw [vl_gate _ red.clean _ _ _ atW]
      simp only [o,GateOp.eval,List.any_map,Function.comp_def,id_eq,List.any_eq_true]
      exact ⟨10+k,pin,(dom row).trans hot⟩
    obtain ⟨A,_,_,_,only⟩ := only_socket_hot r cand red (by omega) s sl su upper
    have ah : 10+k=A := (only _ ((dom row).trans hot)).resolve_left (by omega)
    rcases only _ wr with e|e <;> omega
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.mixed_positive_use
