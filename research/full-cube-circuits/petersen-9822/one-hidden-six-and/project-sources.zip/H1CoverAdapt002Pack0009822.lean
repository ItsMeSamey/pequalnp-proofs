import H1CoverAdapt002Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_2_1 : (stageRows 17 32 73736 4 [4,5,6,1,8,9,10,11,12,2,3,7] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_2_3 : (stageRows 17 32 73736 3 [6,1,9,10,11,12,2,3,7] [17,288]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_2_5 : (stageRows 17 32 73736 2 [1,10,11,2,3,7] [17,800,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_2_7 : (stageRows 17 32 73736 1 [10,3,7] [17,800,6208,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
end Research.H1Cover
