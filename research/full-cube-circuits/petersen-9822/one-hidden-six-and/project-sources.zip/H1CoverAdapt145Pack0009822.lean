import H1CoverAdapt145Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_145_1 : (stageRows 24 256 5242944 4 [3,4,5,2,8,9,10,11,12,1,6,7] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_145
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_145_2 : (stageRows 24 256 5242944 4 [3,5,2,8,9,10,11,12,1,6,7] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_145
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_145_4 : (stageRows 24 256 5242944 3 [4,2,8,9,10,11,1,6,7] [33,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_145
    · decide +kernel
    · decide +kernel
end Research.H1Cover
