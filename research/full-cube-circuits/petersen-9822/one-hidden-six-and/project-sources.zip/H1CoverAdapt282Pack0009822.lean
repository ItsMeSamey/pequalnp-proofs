import H1CoverAdapt282Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_282_1 : (stageRows 224 512 100664832 4 [1,2,5,6,3,7,10,11,12,8,9] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_282_3 : (stageRows 224 512 100664832 3 [2,4,3,7,10,11,12,8,9] [33,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_282_5 : (stageRows 224 512 100664832 2 [6,3,11,12,8,9] [33,134,1040]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
end Research.H1Cover
