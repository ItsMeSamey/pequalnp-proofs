import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_38 : ([1097,464,2433,1349,248] : List Nat).all (cliqueValid 284680 [0,5,1,2,6,4,7,3,8,9,10,11,12])=true := by decide +kernel
end Research.H1Cover
