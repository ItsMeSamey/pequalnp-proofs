import H1CoverAdapt022Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_22_6 : (stageRows 4 66 114689 3 [5,6,0,9,12,4,10,11] [134,264]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_22
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_22_7 : (stageRows 4 66 114689 3 [5,6,0,8,9,4,10,11] [134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_22
    · decide +kernel
    · decide +kernel
end Research.H1Cover
