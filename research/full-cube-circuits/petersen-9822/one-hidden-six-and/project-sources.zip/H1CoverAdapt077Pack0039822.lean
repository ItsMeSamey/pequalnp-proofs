import H1CoverAdapt077Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_77_9 : (stageRows 64 898 789520 1 [5,9,10] [17,134,4360,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
end Research.H1Cover
