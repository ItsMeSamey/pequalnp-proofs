import H1CoverAdapt013Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_1 : (stageRows 64 290 100368 4 [1,2,6,4,5,3,7,9,10,8,11,12] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_2 : (stageRows 64 290 100368 4 [1,2,6,5,3,7,9,10,8,11,12] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_3 : (stageRows 64 290 100368 4 [1,2,6,4,3,7,9,10,8,11,12] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_5 : (stageRows 64 290 100368 3 [6,3,7,9,10,8,11,12] [49,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
end Research.H1Cover
