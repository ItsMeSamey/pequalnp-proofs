import H1CoverAdapt135Data9822
import H1CoverAdapt135Pack0009822
import H1CoverAdapt135Pack0019822
import H1CoverAdapt135Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_15 : (stageRows 128 564 4719392 1 [1,2,7,9] [33,4360,3088,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_9 : (stageRows 128 564 4719392 2 [6,1,2,7,9] [33,4360,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4719392 (some 6)).all ([64,66,2112,4160,4416,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_135_10
  · exact adapt_135_11
  · exact adapt_135_12
  · exact adapt_135_13
  · exact adapt_135_14
  · exact adapt_135_15
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_7 : (stageRows 128 564 4719392 3 [4,6,1,2,10,11,7,9] [33,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4719392 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
  · exact adapt_135_8
  · apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
  · exact adapt_135_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_2 : (stageRows 128 564 4719392 4 [3,4,6,1,2,10,11,8,12,7,9] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4719392 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_135_3
  · exact adapt_135_4
  · exact adapt_135_5
  · exact adapt_135_6
  · exact adapt_135_7
end Research.H1Cover
