import H1CoverAdapt182Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_182_6 : (stageRows 128 804 6292256 3 [3,6,10,7,9,11,8,12] [49,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,10,7,9,11,8,12]) (ws:=[1128,2565,4628,1283,600])
    · exact clique_ok_182
    · decide +kernel
    · decide +kernel
end Research.H1Cover
