import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_12 : ([248,5154,2432,1128,4148] : List Nat).all (cliqueValid 100096 [0,1,6,2,5,3,4,7,11,12,8,10,9])=true := by decide +kernel
end Research.H1Cover
