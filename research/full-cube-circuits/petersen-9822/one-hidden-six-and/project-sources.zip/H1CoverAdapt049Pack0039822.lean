import H1CoverAdapt049Data9822
import H1CoverAdapt049Pack0009822
import H1CoverAdapt049Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_49_11 : (stageRows 144 520 393858 4 [4,2,3,6,12,1,10,11,8,9,7] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_49_0 : (stageRows 144 520 393858 5 [0,4,2,3,6,5,12,1,10,11,8,9,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 393858 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_49_1
  · exact adapt_49_2
  · exact adapt_49_11
end Research.H1Cover
