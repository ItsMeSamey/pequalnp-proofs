import H1CoverAdapt445Data9822
import H1CoverAdapt445Pack0009822
import H1CoverAdapt445Pack0019822
import H1CoverAdapt445Pack0029822
import H1CoverAdapt445Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_445_13 : (stageRows 68 770 353373201 2 [6,5,9] [3089,134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,8,12,4,9,10,11]) (ws:=[5156,464,1348,232,2432])
    · exact clique_ok_445
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_445_8 : (stageRows 68 770 353373201 3 [3,6,5,8,12,9] [3089,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 353373201 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_445_9
  · exact adapt_445_10
  · exact adapt_445_11
  · exact adapt_445_12
  · exact adapt_445_13
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_445_5 : (stageRows 68 770 353373201 4 [1,2,3,6,5,7,8,12,9] [3089]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 353373201 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,5,7,8,12,4,9,10,11]) (ws:=[5156,464,1348,232,2432])
    · exact clique_ok_445
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,5,7,8,12,4,9,10,11]) (ws:=[5156,464,1348,232,2432])
    · exact clique_ok_445
    · decide +kernel
    · decide +kernel
  · exact adapt_445_6
  · exact adapt_445_7
  · exact adapt_445_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_445_0 : (stageRows 68 770 353373201 5 [0,1,2,3,6,5,7,8,12,4,9,10,11] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 353373201 (some 0)).all ([1,17,33,49,3089] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_445_1
  · exact adapt_445_2
  · exact adapt_445_3
  · exact adapt_445_4
  · exact adapt_445_5
end Research.H1Cover
