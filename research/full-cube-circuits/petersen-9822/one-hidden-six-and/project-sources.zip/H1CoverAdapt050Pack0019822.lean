import H1CoverAdapt050Data9822
import H1CoverAdapt050Pack0009822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_7 : (stageRows 40 384 397632 2 [5,6,10,11,9,8] [17,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_8 : (stageRows 40 384 397632 2 [5,6,10,11,9] [17,134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_9 : (stageRows 40 384 397632 2 [5,6,10,11,9] [17,134,4364]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_3 : (stageRows 40 384 397632 3 [3,5,6,10,11,9,8,12] [17,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 397632 (some 3)).all ([8,12,264,4104,4360,4364] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_50_4
  · exact adapt_50_5
  · exact adapt_50_6
  · exact adapt_50_7
  · exact adapt_50_8
  · exact adapt_50_9
end Research.H1Cover
