import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_246 : ([2571,4628,2432,600,224] : List Nat).all (cliqueValid 33562913 [0,1,2,6,4,3,7,11,9,10,12,5,8])=true := by decide +kernel
end Research.H1Cover
