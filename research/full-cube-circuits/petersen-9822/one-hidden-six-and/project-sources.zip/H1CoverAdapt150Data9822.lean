import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_150 : ([1349,2433,2565,4225,1033] : List Nat).all (cliqueValid 5246988 [0,4,5,1,6,10,8,9,2,7,11,12,3])=true := by decide +kernel
end Research.H1Cover
