import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_10_f0_p0 : terminalCharge 32 145 73992 [17,800,6208,142,1024] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_10_f1_p0 : terminalCharge 32 145 73992 [17,800,6208,142,1040] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_10_f2_p0 : terminalCharge 32 145 73992 [17,800,6208,142,1152] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_10_f3_p0 : terminalCharge 32 145 73992 [17,800,6208,142,1536] []=true := by decide +kernel
end Research.H1Cover
