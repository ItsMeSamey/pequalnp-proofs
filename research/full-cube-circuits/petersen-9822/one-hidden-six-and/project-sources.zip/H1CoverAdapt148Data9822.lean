import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_148 : ([2571,5154,1345,4626,2433] : List Nat).all (cliqueValid 5244992 [0,3,4,5,2,8,9,10,11,12,1,6,7])=true := by decide +kernel
end Research.H1Cover
