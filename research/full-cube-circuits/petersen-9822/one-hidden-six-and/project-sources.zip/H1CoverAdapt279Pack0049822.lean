import H1CoverAdapt279Data9822
import H1CoverAdapt279Pack0029822
import H1CoverAdapt279Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_279_14 : (stageRows 48 513 100663436 1 [9] [33,3088,198,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_279_15 : (stageRows 48 513 100663436 1 [9] [33,3088,198,4364]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_279_11 : (stageRows 48 513 100663436 2 [3,8,9,12] [33,3088,198]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100663436 (some 3)).all ([8,12,140,264,268,4104,4108,4360,4364] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
  · exact adapt_279_12
  · exact adapt_279_13
  · exact adapt_279_14
  · exact adapt_279_15
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_279_5 : (stageRows 48 513 100663436 3 [1,6,3,8,9,12,7,2] [33,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100663436 (some 1)).all ([2,6,66,130,134,198] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_279_6
  · exact adapt_279_7
  · exact adapt_279_8
  · exact adapt_279_9
  · exact adapt_279_10
  · exact adapt_279_11
end Research.H1Cover
