import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_434 : ([2571,1348,2216,5154,1128] : List Nat).all (cliqueValid 352322577 [0,1,2,3,6,5,8,11,12,7,9,4,10])=true := by decide +kernel
end Research.H1Cover
