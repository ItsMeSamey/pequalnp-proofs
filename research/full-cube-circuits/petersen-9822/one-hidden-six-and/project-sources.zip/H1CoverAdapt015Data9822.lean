import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_15 : ([600,1283,5154,2565,1128] : List Nat).all (cliqueValid 101392 [0,1,6,2,4,5,3,9,7,10,8,11,12])=true := by decide +kernel
end Research.H1Cover
