import H1CoverAdapt025Data9822
import H1CoverAdapt025Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_11 : (stageRows 4 194 114721 2 [0,5,9,4,10] [134,4360,2112]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_12 : (stageRows 4 194 114721 2 [0,5,9,4,10,11] [134,4360,4160]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_13 : (stageRows 4 194 114721 2 [0,5,9,4,10] [134,4360,6208]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_8 : (stageRows 4 194 114721 3 [6,0,5,9,4,10,11] [134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 114721 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_25_9
  · exact adapt_25_10
  · exact adapt_25_11
  · exact adapt_25_12
  · exact adapt_25_13
end Research.H1Cover
