import H1CoverAdapt103Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_103_1 : (stageRows 144 516 1114784 4 [6,3,4,1,2,11,12,5,8,10,7,9] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_103_3 : (stageRows 144 516 1114784 3 [3,1,2,11,5,8,10,7,9] [17,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_103_6 : (stageRows 144 516 1114784 1 [10,7] [17,6208,808,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
end Research.H1Cover
