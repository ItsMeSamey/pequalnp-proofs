import H1CoverAdapt043Data9822
import H1CoverAdapt043Pack0009822
import H1CoverAdapt043Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_43_10 : (stageRows 80 521 312454 4 [3,6,1,2,4,8,9,12,11,10,7] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,5,6,1,2,4,8,9,12,11,10,7]) (ws:=[4626,2565,2307,5121,1345])
    · exact clique_ok_43
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_43_0 : (stageRows 80 521 312454 5 [0,3,5,6,1,2,4,8,9,12,11,10,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 312454 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_43_1
  · exact adapt_43_2
  · exact adapt_43_10
end Research.H1Cover
