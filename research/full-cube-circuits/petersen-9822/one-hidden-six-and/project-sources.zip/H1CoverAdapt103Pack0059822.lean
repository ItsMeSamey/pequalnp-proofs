import H1CoverAdapt103Data9822
import H1CoverAdapt103Pack0009822
import H1CoverAdapt103Pack0029822
import H1CoverAdapt103Pack0039822
import H1CoverAdapt103Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_103_0 : (stageRows 144 516 1114784 5 [0,6,3,4,1,2,11,12,5,8,10,7,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 1114784 (some 0)).all ([1,17,33,545] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · exact adapt_103_1
  · exact adapt_103_2
  · exact adapt_103_9
  · exact adapt_103_10
end Research.H1Cover
