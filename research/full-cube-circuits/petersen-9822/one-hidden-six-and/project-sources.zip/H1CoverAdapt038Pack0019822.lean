import H1CoverAdapt038Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_7 : (stageRows 96 257 284680 2 [4,3,8,9,10,12] [33,134,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_8 : (stageRows 96 257 284680 2 [4,3,8,9,10,11] [33,134,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_9 : (stageRows 96 257 284680 2 [4,3,8,9,10] [33,134,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_10 : (stageRows 96 257 284680 2 [4,3,8,9,10] [33,134,6210]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
end Research.H1Cover
