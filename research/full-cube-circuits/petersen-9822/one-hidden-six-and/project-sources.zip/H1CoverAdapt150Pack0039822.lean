import H1CoverAdapt150Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_11 : (stageRows 48 257 5246988 3 [1,6,8,9,2,7,11,12,3] [33,1040]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_13 : (stageRows 48 257 5246988 2 [6,8,9,7,12,3] [33,3088,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_14 : (stageRows 48 257 5246988 2 [6,8,9,7,12] [33,3088,14]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_15 : (stageRows 48 257 5246988 2 [8,9,2,7,12,3] [33,3088,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
end Research.H1Cover
