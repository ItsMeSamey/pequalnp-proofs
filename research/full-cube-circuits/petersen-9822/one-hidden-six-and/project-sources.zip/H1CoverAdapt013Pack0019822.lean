import H1CoverAdapt013Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_6 : (stageRows 64 290 100368 3 [2,3,7,9,10,8,11,12] [49,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_8 : (stageRows 64 290 100368 2 [3,9,10,8,11,12] [49,134,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_9 : (stageRows 64 290 100368 2 [3,9,10,8,11,12] [49,134,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_10 : (stageRows 64 290 100368 2 [3,9,10,8,12] [49,134,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
end Research.H1Cover
