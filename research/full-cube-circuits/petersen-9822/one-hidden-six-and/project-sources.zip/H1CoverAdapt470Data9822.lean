import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_470 : ([1349,585,5125,2433,4225] : List Nat).all (cliqueValid 402653378 [0,4,5,2,3,8,6,9,10,11,12,7,1])=true := by decide +kernel
end Research.H1Cover
