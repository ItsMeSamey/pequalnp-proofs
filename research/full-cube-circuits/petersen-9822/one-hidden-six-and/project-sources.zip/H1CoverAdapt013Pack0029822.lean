import H1CoverAdapt013Data9822
import H1CoverAdapt013Pack0009822
import H1CoverAdapt013Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_11 : (stageRows 64 290 100368 2 [3,9,10,8,11] [49,134,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_12 : (stageRows 64 290 100368 2 [3,9,10,8] [49,134,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_7 : (stageRows 64 290 100368 3 [6,3,9,10,8,11,12] [49,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100368 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_13_8
  · exact adapt_13_9
  · exact adapt_13_10
  · exact adapt_13_11
  · exact adapt_13_12
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_4 : (stageRows 64 290 100368 4 [1,2,6,3,7,9,10,8,11,12] [49]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100368 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
  · exact adapt_13_5
  · exact adapt_13_6
  · apply debitBound (order:=[0,1,2,6,4,5,3,7,9,10,8,11,12]) (ws:=[1349,600,5156,2563,1128])
    · exact clique_ok_13
    · decide +kernel
    · decide +kernel
  · exact adapt_13_7
end Research.H1Cover
