import H1CoverAdapt168Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_168_8 : (stageRows 208 528 5842566 3 [4,6,1,2,11,12,7,9,10] [33,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,8,11,12,7,9,10]) (ws:=[2433,4272,464,248,2059])
    · exact clique_ok_168
    · decide +kernel
    · decide +kernel
end Research.H1Cover
