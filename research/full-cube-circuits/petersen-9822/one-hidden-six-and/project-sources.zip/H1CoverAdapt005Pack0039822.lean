import H1CoverAdapt005Pack0029822
import H1CoverLastTerminal9822
import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_10_f4_p0 : terminalCharge 32 145 73992 [17,800,6208,142,1664] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_10_f5_p0 : terminalCharge 32 145 73992 [17,800,6208,142,3072] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_10_f6_p0 : terminalCharge 32 145 73992 [17,800,6208,142,3088] []=true := by decide +kernel
theorem adapt_5_10 : (stageRows 32 145 73992 1 [10] [17,800,6208,142]).all fixedPrice=true := by
  apply lastTerminal
  intro m hm
  have check : (finishing 73992 [10]).all ([1024,1040,1152,1536,1664,3072,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp check m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_5_10_f0_p0
  · exact adapt_5_10_f1_p0
  · exact adapt_5_10_f2_p0
  · exact adapt_5_10_f3_p0
  · exact adapt_5_10_f4_p0
  · exact adapt_5_10_f5_p0
  · exact adapt_5_10_f6_p0
end Research.H1Cover
