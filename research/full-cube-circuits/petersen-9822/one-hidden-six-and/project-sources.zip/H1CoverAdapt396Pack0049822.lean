import H1CoverAdapt396Data9822
import H1CoverAdapt396Pack0009822
import H1CoverAdapt396Pack0019822
import H1CoverAdapt396Pack0029822
import H1CoverAdapt396Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_396_15 : (stageRows 130 548 176169761 2 [6,4,11,10] [801,134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,11,12,5,10,8,9]) (ws:=[4628,2216,464,2570,600])
    · exact clique_ok_396
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_396_10 : (stageRows 130 548 176169761 3 [3,6,4,11,12,10] [801,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 176169761 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_396_11
  · exact adapt_396_12
  · exact adapt_396_13
  · exact adapt_396_14
  · exact adapt_396_15
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_396_5 : (stageRows 130 548 176169761 4 [1,2,3,6,4,7,11,12,10] [801]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 176169761 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_396_6
  · exact adapt_396_7
  · exact adapt_396_8
  · exact adapt_396_9
  · exact adapt_396_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_396_0 : (stageRows 130 548 176169761 5 [0,1,2,3,6,4,7,11,12,5,10,8,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 176169761 (some 0)).all ([1,17,33,49,801] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_396_1
  · exact adapt_396_2
  · exact adapt_396_3
  · exact adapt_396_4
  · exact adapt_396_5
end Research.H1Cover
