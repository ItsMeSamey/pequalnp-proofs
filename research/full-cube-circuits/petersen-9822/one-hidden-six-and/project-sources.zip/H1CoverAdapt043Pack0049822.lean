import H1CoverAdapt043Data9822
import H1CoverAdapt043Pack0009822
import H1CoverAdapt043Pack0019822
import H1CoverAdapt043Pack0029822
import H1CoverAdapt043Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_43_9 : (stageRows 80 521 312454 2 [6,1,2,11,10,7] [17,4360,800]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,5,6,1,2,4,8,9,12,11,10,7]) (ws:=[4626,2565,2307,5121,1345])
    · exact clique_ok_43
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_43_7 : (stageRows 80 521 312454 3 [5,6,1,2,9,11,10,7] [17,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 312454 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,5,6,1,2,4,8,9,12,11,10,7]) (ws:=[4626,2565,2307,5121,1345])
    · exact clique_ok_43
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,5,6,1,2,4,8,9,12,11,10,7]) (ws:=[4626,2565,2307,5121,1345])
    · exact clique_ok_43
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,5,6,1,2,4,8,9,12,11,10,7]) (ws:=[4626,2565,2307,5121,1345])
    · exact clique_ok_43
    · decide +kernel
    · decide +kernel
  · exact adapt_43_8
  · exact adapt_43_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_43_2 : (stageRows 80 521 312454 4 [3,5,6,1,2,8,9,12,11,10,7] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 312454 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_43_3
  · exact adapt_43_4
  · exact adapt_43_5
  · exact adapt_43_6
  · exact adapt_43_7
end Research.H1Cover
