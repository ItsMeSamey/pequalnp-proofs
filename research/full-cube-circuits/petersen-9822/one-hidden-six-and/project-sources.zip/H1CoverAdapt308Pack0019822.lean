import H1CoverAdapt308Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_3 : (stageRows 160 548 100774696 3 [6,3,7,10,11,5,12,8,9] [17,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_4 : (stageRows 160 548 100774696 3 [2,3,7,10,11,5,12,8,9] [17,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_6 : (stageRows 160 548 100774696 2 [3,10,11,5,12,8,9] [17,134,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_7 : (stageRows 160 548 100774696 2 [3,10,11,5,12,8,9] [17,134,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
end Research.H1Cover
