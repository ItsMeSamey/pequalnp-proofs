import H1CoverAdapt283Data9822
import H1CoverAdapt283Pack0009822
import H1CoverAdapt283Pack0019822
import H1CoverAdapt283Pack0029822
import H1CoverAdapt283Pack0039822
import H1CoverAdapt283Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_283_16 : (stageRows 240 512 100664960 1 [3,8,9] [33,134,3088,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_283
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_283_10 : (stageRows 240 512 100664960 2 [6,3,12,8,9] [33,134,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100664960 (some 6)).all ([64,66,194,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_283_11
  · exact adapt_283_12
  · exact adapt_283_13
  · exact adapt_283_14
  · exact adapt_283_15
  · exact adapt_283_16
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_283_8 : (stageRows 240 512 100664960 3 [4,6,3,10,11,12,8,9] [33,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100664960 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_283
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_283
    · decide +kernel
    · decide +kernel
  · exact adapt_283_9
  · apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_283
    · decide +kernel
    · decide +kernel
  · exact adapt_283_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_283_3 : (stageRows 240 512 100664960 4 [2,4,1,6,3,10,11,7,12,8,9] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100664960 (some 2)).all ([4,6,12,132,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_283_4
  · exact adapt_283_5
  · exact adapt_283_6
  · exact adapt_283_7
  · exact adapt_283_8
end Research.H1Cover
