import H1CoverAdapt025Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_5 : (stageRows 4 194 114721 3 [6,0,5,9,4,8,12,10,11] [134,12]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_6 : (stageRows 4 194 114721 3 [6,0,5,9,4,12,10,11] [134,264]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
end Research.H1Cover
