import H1CoverAdapt168Data9822
import H1CoverAdapt168Pack0009822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_168_6 : (stageRows 208 528 5842566 3 [5,6,1,2,11,7,9,10] [17,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,8,11,12,7,9,10]) (ws:=[2433,4272,464,248,2059])
    · exact clique_ok_168
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_168_1 : (stageRows 208 528 5842566 4 [3,5,6,1,2,8,11,12,7,9,10] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5842566 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_168_2
  · exact adapt_168_3
  · exact adapt_168_4
  · exact adapt_168_5
  · exact adapt_168_6
end Research.H1Cover
