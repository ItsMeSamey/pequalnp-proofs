import H1CoverAdapt246Data9822
import H1CoverAdapt246Pack0009822
import H1CoverAdapt246Pack0019822
import H1CoverAdapt246Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_246_0 : (stageRows 36 130 33562913 5 [0,1,2,6,4,3,7,11,9,10,12,5,8] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 33562913 (some 0)).all ([1,17,33,49,289] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_246_1
  · exact adapt_246_2
  · exact adapt_246_3
  · exact adapt_246_4
  · exact adapt_246_10
end Research.H1Cover
