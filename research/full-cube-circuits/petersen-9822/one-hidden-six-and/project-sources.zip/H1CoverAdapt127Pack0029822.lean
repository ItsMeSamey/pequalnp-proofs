import H1CoverAdapt127Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_11 : (stageRows 2 84 4202513 1 [10] [545,134,4360,2128]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
end Research.H1Cover
