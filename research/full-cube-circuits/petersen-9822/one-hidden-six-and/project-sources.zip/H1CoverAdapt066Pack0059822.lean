import H1CoverAdapt066Data9822
import H1CoverAdapt066Pack0009822
import H1CoverAdapt066Pack0039822
import H1CoverAdapt066Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_66_0 : (stageRows 104 272 604226 5 [0,4,5,3,2,8,9,10,1,7,11,12,6] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 604226 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_66_1
  · exact adapt_66_2
  · exact adapt_66_14
end Research.H1Cover
