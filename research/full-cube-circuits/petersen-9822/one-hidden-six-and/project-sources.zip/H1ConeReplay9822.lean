import H1ClippedZero9822
import H1ForwardComparison9822
namespace Research.H1Price
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet.CircuitCompiler
theorem justified_of_cone (cone : Nat → Prop) (erase : Nat → Bool) (hidden : Nat)
    (hot : Bool) (gs : List Gate) (k : Nat) (w : List Bool) (len : w.length=k)
    (old : zeroOn cone w) (shape : clipsCone cone erase hidden k gs)
    (hiddenOK : admissibleHot erase hidden hot k gs w) :
    justified erase hidden hot k gs w ∧ zeroOn cone (replay erase hidden hot k gs w) := by
  induction gs generalizing k w with
  | nil => exact ⟨trivial,old⟩
  | cons g gs ih =>
    have tail := ih (k+1) (w++[clipBit erase hidden k g w hot]) (by simp [len])
      (clip_zero_step len old shape.1) shape.2.2 hiddenOK.2
    exact ⟨⟨fun z => ⟨(shape.2.1 z).1,erased_false old (shape.2.1 z).1
      (shape.2.1 z).2.1 (shape.2.1 z).2.2⟩,hiddenOK.1,tail.1⟩,tail.2⟩

theorem positive_observed (erase : Nat → Bool) (hidden : Nat) (hot : Bool) (gs : List Gate)
    (k out : Nat) (w : List Bool) (len : w.length=k) (cone : Nat → Prop)
    (seed : zeroOn cone w) (outCone : cone out) (shape : clipsCone cone erase hidden k gs)
    (hiddenOK : admissibleHot erase hidden hot k gs w)
    (accept : (ordinary k gs w).getD out false = true) :
    true ∈ observed erase hidden hot k gs w := by
  by_contra empty
  obtain ⟨just,zero⟩ := justified_of_cone cone erase hidden hot gs k w len seed shape hiddenOK
  have same := cold_replay erase hidden hot k gs w just empty
  have outOff := zero out outCone
  rw [same,accept] at outOff
  contradiction
end Research.H1Price
#print axioms Research.H1Price.positive_observed
