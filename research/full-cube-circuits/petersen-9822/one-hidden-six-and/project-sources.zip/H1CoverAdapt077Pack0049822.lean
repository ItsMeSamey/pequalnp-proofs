import H1CoverAdapt077Data9822
import H1CoverAdapt077Pack0009822
import H1CoverAdapt077Pack0019822
import H1CoverAdapt077Pack0029822
import H1CoverAdapt077Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_77_10 : (stageRows 64 898 789520 1 [5,9,10] [17,134,4360,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_77_8 : (stageRows 64 898 789520 2 [6,5,11,9,10] [17,134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 789520 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
  · exact adapt_77_9
  · apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
  · exact adapt_77_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_77_3 : (stageRows 64 898 789520 3 [3,6,5,11,12,8,9,10] [17,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 789520 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_77_4
  · exact adapt_77_5
  · exact adapt_77_6
  · exact adapt_77_7
  · exact adapt_77_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_77_1 : (stageRows 64 898 789520 4 [1,2,3,6,5,7,11,12,8,9,10] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 789520 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
  · exact adapt_77_2
  · exact adapt_77_3
end Research.H1Cover
