import H1CoverAdapt158Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_4 : (stageRows 48 385 5771532 3 [6,1,10,11,9,2,7,8,12,3] [33,16]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_5 : (stageRows 48 385 5771532 3 [6,1,10,11,9,2,7,8,12,3] [33,17]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_6 : (stageRows 48 385 5771532 3 [6,1,11,9,2,7,8,12,3] [33,1040]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_7 : (stageRows 48 385 5771532 3 [6,1,10,9,2,7,8,12,3] [33,2064]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
end Research.H1Cover
