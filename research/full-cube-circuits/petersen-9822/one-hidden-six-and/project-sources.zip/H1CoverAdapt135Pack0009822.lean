import H1CoverAdapt135Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_1 : (stageRows 128 564 4719392 4 [3,5,6,1,2,10,11,8,12,7,9] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_3 : (stageRows 128 564 4719392 3 [4,6,1,2,10,11,8,12,7,9] [33,8]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_4 : (stageRows 128 564 4719392 3 [4,6,1,10,11,8,12,7,9] [33,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_5 : (stageRows 128 564 4719392 3 [4,6,1,2,10,11,12,7,9] [33,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
end Research.H1Cover
