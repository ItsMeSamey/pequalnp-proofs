import H1CoverAdapt470Data9822
import H1CoverAdapt470Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_12 : (stageRows 272 520 402653378 1 [10,11] [17,800,142,4162]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_13 : (stageRows 272 520 402653378 1 [10] [17,800,142,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_14 : (stageRows 272 520 402653378 1 [10] [17,800,142,6210]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_10 : (stageRows 272 520 402653378 2 [6,10,11,12] [17,800,142]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 402653378 (some 6)).all ([64,66,194,2112,2114,4160,4162,6208,6210] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
  · exact adapt_470_11
  · exact adapt_470_12
  · exact adapt_470_13
  · exact adapt_470_14
end Research.H1Cover
