import H1CoverAdapt081Data9822
import H1CoverAdapt081Pack0009822
import H1CoverAdapt081Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_81_9 : (stageRows 66 68 904209 2 [6,0,4,10,11] [134,4360,544]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_81
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_81_10 : (stageRows 66 68 904209 2 [6,0,4,10,11] [134,4360,800]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_81
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_81_8 : (stageRows 66 68 904209 3 [5,6,0,9,4,10,11] [134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 904209 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_81
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_81
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_81
    · decide +kernel
    · decide +kernel
  · exact adapt_81_9
  · exact adapt_81_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_81_3 : (stageRows 66 68 904209 4 [3,5,6,0,8,9,12,4,10,11] [134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 904209 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_81_4
  · exact adapt_81_5
  · exact adapt_81_6
  · exact adapt_81_7
  · exact adapt_81_8
end Research.H1Cover
