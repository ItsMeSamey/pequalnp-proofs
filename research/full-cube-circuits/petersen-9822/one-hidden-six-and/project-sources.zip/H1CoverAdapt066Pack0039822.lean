import H1CoverAdapt066Data9822
import H1CoverAdapt066Pack0009822
import H1CoverAdapt066Pack0019822
import H1CoverAdapt066Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_66_13 : (stageRows 104 272 604226 2 [2,10,1,7] [17,800,6216]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,3,2,8,9,10,1,7,11,12,6]) (ws:=[1283,2565,4225,577,2433])
    · exact clique_ok_66
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_66_7 : (stageRows 104 272 604226 3 [3,2,10,1,7,11,12,6] [17,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 604226 (some 3)).all ([8,12,264,4104,4360,6216] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_66_8
  · exact adapt_66_9
  · exact adapt_66_10
  · exact adapt_66_11
  · exact adapt_66_12
  · exact adapt_66_13
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_66_2 : (stageRows 104 272 604226 4 [5,3,2,8,9,10,1,7,11,12,6] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 604226 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_66_3
  · exact adapt_66_4
  · exact adapt_66_5
  · exact adapt_66_6
  · exact adapt_66_7
end Research.H1Cover
