import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_152 : ([2571,1345,5154,2433,585] : List Nat).all (cliqueValid 5249088 [0,3,4,5,2,10,11,1,6,8,9,12,7])=true := by decide +kernel
end Research.H1Cover
