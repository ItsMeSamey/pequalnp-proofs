import H1CoverAdapt090Data9822
import H1CoverAdapt090Pack0009822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_7 : (stageRows 104 320 908368 2 [5,9,6,10,11,12] [17,134,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_8 : (stageRows 104 320 908368 2 [5,8,9,6,10,11] [17,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_9 : (stageRows 104 320 908368 2 [5,9,6,10,11] [17,134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_4 : (stageRows 104 320 908368 3 [3,5,8,9,6,10,11,12] [17,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 908368 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_90_5
  · exact adapt_90_6
  · exact adapt_90_7
  · exact adapt_90_8
  · exact adapt_90_9
end Research.H1Cover
