import H1CoverAdapt389Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_389_6 : (stageRows 130 516 176161313 3 [2,3,4,8,11,12,7,10] [545,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
end Research.H1Cover
