import H1CoverAdapt279Data9822
import H1CoverAdapt279Pack0009822
import H1CoverAdapt279Pack0019822
import H1CoverAdapt279Pack0029822
import H1CoverAdapt279Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_279_3 : (stageRows 48 513 100663436 4 [4,1,6,11,3,8,9,10,12,7,2] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100663436 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
  · exact adapt_279_4
  · exact adapt_279_5
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_279_0 : (stageRows 48 513 100663436 5 [0,4,5,1,6,11,3,8,9,10,12,7,2] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100663436 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_279_1
  · exact adapt_279_2
  · exact adapt_279_3
end Research.H1Cover
