import H1CoverAdapt335Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_335_6 : (stageRows 104 768 125836352 2 [5,6,8,9,12,10,11] [17,134,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,4,5,1,6,8,7,9,12,10,11]) (ws:=[600,1283,248,4225,385])
    · exact clique_ok_335
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_335_7 : (stageRows 104 768 125836352 2 [5,6,9,12,10,11] [17,134,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,4,5,1,6,8,7,9,12,10,11]) (ws:=[600,1283,248,4225,385])
    · exact clique_ok_335
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_335_8 : (stageRows 104 768 125836352 2 [5,6,8,9,10,11] [17,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,4,5,1,6,8,7,9,12,10,11]) (ws:=[600,1283,248,4225,385])
    · exact clique_ok_335
    · decide +kernel
    · decide +kernel
end Research.H1Cover
