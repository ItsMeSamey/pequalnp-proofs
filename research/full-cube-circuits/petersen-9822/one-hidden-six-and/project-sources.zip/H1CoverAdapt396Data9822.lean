import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_396 : ([4628,2216,464,2570,600] : List Nat).all (cliqueValid 176169761 [0,1,2,3,6,4,7,11,12,5,10,8,9])=true := by decide +kernel
end Research.H1Cover
