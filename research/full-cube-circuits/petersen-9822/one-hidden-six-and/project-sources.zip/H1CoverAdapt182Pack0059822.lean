import H1CoverAdapt182Data9822
import H1CoverAdapt182Pack0009822
import H1CoverAdapt182Pack0019822
import H1CoverAdapt182Pack0029822
import H1CoverAdapt182Pack0039822
import H1CoverAdapt182Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_182_9 : (stageRows 128 804 6292256 3 [3,6,10,9,11,8,12] [49,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6292256 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_182_10
  · exact adapt_182_11
  · exact adapt_182_12
  · exact adapt_182_13
  · exact adapt_182_14
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_182_4 : (stageRows 128 804 6292256 4 [2,3,1,6,10,7,9,11,8,12] [49]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6292256 (some 2)).all ([4,6,12,132,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_182_5
  · exact adapt_182_6
  · exact adapt_182_7
  · exact adapt_182_8
  · exact adapt_182_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_182_0 : (stageRows 128 804 6292256 5 [0,2,3,1,4,5,6,10,7,9,11,8,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6292256 (some 0)).all ([1,17,33,49] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · exact adapt_182_1
  · exact adapt_182_2
  · exact adapt_182_3
  · exact adapt_182_4
end Research.H1Cover
