import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_128 : ([4626,2309,2565,2307,2433] : List Nat).all (cliqueValid 4203664 [0,3,5,6,1,2,8,12,4,9,11,7,10])=true := by decide +kernel
end Research.H1Cover
