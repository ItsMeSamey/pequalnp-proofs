import H1CoverAdapt292Data9822
import H1CoverAdapt292N0039822
import H1CoverAdapt292N0049822
import H1CoverAdapt292N0059822
import H1CoverAdapt292N0069822
import H1CoverAdapt292N0079822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_292_2 : (stageRows 48 521 100696206 4 [5,6,10,11,1,9,3,8,12,7,2] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100696206 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_292_3
  · exact adapt_292_4
  · exact adapt_292_5
  · exact adapt_292_6
  · exact adapt_292_7
end Research.H1Cover
