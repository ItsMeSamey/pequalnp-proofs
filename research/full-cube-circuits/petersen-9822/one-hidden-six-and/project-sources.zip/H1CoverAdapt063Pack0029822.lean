import H1CoverAdapt063Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_12 : (stageRows 64 786 592912 1 [1,2,7,10] [17,800,6208,8]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_13 : (stageRows 64 786 592912 1 [1,7,10] [17,800,6208,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_14 : (stageRows 64 786 592912 1 [1,2,7,10] [17,800,6208,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
end Research.H1Cover
