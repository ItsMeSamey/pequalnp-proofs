import H1CoverAdapt292Data9822
import H1CoverAdapt292N0129822
import H1CoverAdapt292N0139822
import H1CoverAdapt292N0149822
import H1CoverAdapt292N0159822
import H1CoverAdapt292N0169822
import H1CoverAdapt292N0179822
import H1CoverAdapt292N0189822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_292_11 : (stageRows 48 521 100696206 2 [10,1,3,7,2] [17,800,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100696206 (some 10)).all ([1024,1040,1152,1536,1664,3072,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_292_12
  · exact adapt_292_13
  · exact adapt_292_14
  · exact adapt_292_15
  · exact adapt_292_16
  · exact adapt_292_17
  · exact adapt_292_18
end Research.H1Cover
