import H1CoverAdapt131Data9822
import H1CoverAdapt131Pack0009822
import H1CoverAdapt131Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_131_5 : (stageRows 48 129 4718860 3 [1,5,10,2,7,9,8,3] [17,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_131_2 : (stageRows 48 129 4718860 4 [6,1,5,10,11,12,2,7,9,8,3] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4718860 (some 6)).all ([64,66,2112,4160,4424,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
  · exact adapt_131_3
  · exact adapt_131_4
  · exact adapt_131_5
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_131_7 : (stageRows 48 129 4718860 3 [6,1,10,11,12,2,7,9,8,3] [33,16]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_131_8 : (stageRows 48 129 4718860 3 [6,1,10,11,12,2,7,9,8,3] [33,17]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
end Research.H1Cover
