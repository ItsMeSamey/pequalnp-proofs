import H1CoverAdapt063Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_2 : (stageRows 64 786 592912 3 [6,3,1,2,8,9,11,12,7,10] [17,32]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_3 : (stageRows 64 786 592912 3 [6,3,1,2,8,9,11,12,7,10] [17,33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_4 : (stageRows 64 786 592912 3 [6,3,1,2,9,11,12,7,10] [17,288]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_5 : (stageRows 64 786 592912 3 [6,3,1,2,8,11,12,7,10] [17,544]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
end Research.H1Cover
