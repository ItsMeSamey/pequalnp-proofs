import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_103 : ([5156,2307,1283,2433,2309] : List Nat).all (cliqueValid 1114784 [0,6,3,4,1,2,11,12,5,8,10,7,9])=true := by decide +kernel
end Research.H1Cover
