import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_135 : ([5154,2433,1124,5125,248] : List Nat).all (cliqueValid 4719392 [0,3,4,5,6,1,2,10,11,8,12,7,9])=true := by decide +kernel
end Research.H1Cover
