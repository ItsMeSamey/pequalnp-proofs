import H1CoverAdapt081Data9822
import H1CoverAdapt081Pack0009822
import H1CoverAdapt081Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_81_0 : (stageRows 66 68 904209 5 [1,2,3,5,6,0,7,8,9,12,4,10,11] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 904209 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_81
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_81
    · decide +kernel
    · decide +kernel
  · exact adapt_81_1
  · exact adapt_81_2
  · exact adapt_81_3
end Research.H1Cover
