import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_496 : ([5156,538,2563,184,4628] : List Nat).all (cliqueValid 408944904 [0,1,2,4,5,6,7,9,10,3,11,8,12])=true := by decide +kernel
end Research.H1Cover
