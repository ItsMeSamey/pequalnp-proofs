import H1CoverAdapt335Data9822
import H1CoverAdapt335Pack0009822
import H1CoverAdapt335Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_335_9 : (stageRows 104 768 125836352 2 [5,6,9,10,11] [17,134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,4,5,1,6,8,7,9,12,10,11]) (ws:=[600,1283,248,4225,385])
    · exact clique_ok_335
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_335_4 : (stageRows 104 768 125836352 3 [3,5,6,8,9,12,10,11] [17,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 125836352 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_335_5
  · exact adapt_335_6
  · exact adapt_335_7
  · exact adapt_335_8
  · exact adapt_335_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_335_1 : (stageRows 104 768 125836352 4 [2,3,5,1,6,8,7,9,12,10,11] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 125836352 (some 2)).all ([4,6,12,132,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,2,3,4,5,1,6,8,7,9,12,10,11]) (ws:=[600,1283,248,4225,385])
    · exact clique_ok_335
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,2,3,4,5,1,6,8,7,9,12,10,11]) (ws:=[600,1283,248,4225,385])
    · exact clique_ok_335
    · decide +kernel
    · decide +kernel
  · exact adapt_335_2
  · exact adapt_335_3
  · exact adapt_335_4
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_335_10 : (stageRows 104 768 125836352 4 [2,3,4,1,6,8,7,9,12,10,11] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,4,5,1,6,8,7,9,12,10,11]) (ws:=[600,1283,248,4225,385])
    · exact clique_ok_335
    · decide +kernel
    · decide +kernel
end Research.H1Cover
