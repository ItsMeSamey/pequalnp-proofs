import H1CoverAdapt472Data9822
import H1CoverAdapt472Pack0009822
import H1CoverAdapt472Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_472_16 : (stageRows 336 512 402654336 4 [1,4,2,3,6,8,9,7,12,10,11] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_472
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_472_0 : (stageRows 336 512 402654336 5 [0,1,4,5,2,3,6,8,9,7,12,10,11] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 402654336 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_472_1
  · exact adapt_472_2
  · exact adapt_472_16
end Research.H1Cover
