import H1CoverAdapt013Data9822
import H1CoverAdapt013Pack0009822
import H1CoverAdapt013Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_13_0 : (stageRows 64 290 100368 5 [0,1,2,6,4,5,3,7,9,10,8,11,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100368 (some 0)).all ([1,17,33,49] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · exact adapt_13_1
  · exact adapt_13_2
  · exact adapt_13_3
  · exact adapt_13_4
end Research.H1Cover
