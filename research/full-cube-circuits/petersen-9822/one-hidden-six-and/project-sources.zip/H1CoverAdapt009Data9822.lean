import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_9 : ([1349,2569,4613,2433,1097] : List Nat).all (cliqueValid 78088 [0,4,5,6,1,8,9,2,3,10,11,12,7])=true := by decide +kernel
end Research.H1Cover
