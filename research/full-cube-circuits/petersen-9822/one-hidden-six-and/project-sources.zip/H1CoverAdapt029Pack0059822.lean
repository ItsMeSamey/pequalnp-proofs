import H1CoverAdapt029Data9822
import H1CoverAdapt029Pack0019822
import H1CoverAdapt029Pack0029822
import H1CoverAdapt029Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_0 : (stageRows 192 548 116512 5 [0,1,2,3,6,4,7,5,12,11,8,10,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 116512 (some 0)).all ([1,17,33,801] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
  · exact adapt_29_1
  · exact adapt_29_9
  · exact adapt_29_10
end Research.H1Cover
