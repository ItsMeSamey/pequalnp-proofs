import H1CoverAdapt090Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_1 : (stageRows 104 320 908368 4 [1,2,3,5,4,7,8,9,6,10,11,12] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_3 : (stageRows 104 320 908368 3 [2,3,5,8,9,6,10,11,12] [17,130]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_5 : (stageRows 104 320 908368 2 [5,8,9,6,10,11,12] [17,134,8]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_6 : (stageRows 104 320 908368 2 [5,8,9,6,10,11,12] [17,134,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
end Research.H1Cover
