import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_11_f4_p0 : terminalCharge 32 273 77832 [17,800,6208,142,1664] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_11_f5_p0 : terminalCharge 32 273 77832 [17,800,6208,142,3072] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_11_f6_p0 : terminalCharge 32 273 77832 [17,800,6208,142,3088] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_11_f7_p0 : terminalCharge 32 273 77832 [17,800,6208,142,7168] []=true := by decide +kernel
end Research.H1Cover
