import H1CoverAdapt148Data9822
import H1CoverAdapt148Pack0009822
import H1CoverAdapt148Pack0019822
import H1CoverAdapt148Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_3 : (stageRows 88 256 5244992 4 [3,4,2,8,9,10,11,12,1,6,7] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5244992 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
  · exact adapt_148_4
  · exact adapt_148_5
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_0 : (stageRows 88 256 5244992 5 [0,3,4,5,2,8,9,10,11,12,1,6,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5244992 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_148_1
  · exact adapt_148_2
  · exact adapt_148_3
end Research.H1Cover
