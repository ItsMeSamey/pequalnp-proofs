import H1CoverAdapt007Data9822
import H1CoverAdapt007Pack0009822
import H1CoverAdapt007Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_12 : (stageRows 32 273 77832 4 [4,6,1,8,9,2,3,10,11,12,7] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_0 : (stageRows 32 273 77832 5 [0,4,5,6,1,8,9,2,3,10,11,12,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 77832 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_7_1
  · exact adapt_7_2
  · exact adapt_7_12
end Research.H1Cover
