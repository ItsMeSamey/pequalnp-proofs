import H1CoverAdapt049Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_49_8 : (stageRows 144 520 393858 1 [10,9] [17,142,6208,288]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_49_9 : (stageRows 144 520 393858 1 [10] [17,142,6208,800]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
end Research.H1Cover
