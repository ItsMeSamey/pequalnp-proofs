import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_73 : ([1349,4272,1128,248,5156] : List Nat).all (cliqueValid 787232 [0,1,2,3,5,6,4,7,8,12,11,9,10])=true := by decide +kernel
end Research.H1Cover
