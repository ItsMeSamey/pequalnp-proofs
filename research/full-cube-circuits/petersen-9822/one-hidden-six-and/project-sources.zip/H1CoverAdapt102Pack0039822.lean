import H1CoverAdapt102Data9822
import H1CoverAdapt102Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_15 : (stageRows 4 146 1114145 1 [9] [1041,134,6208,296]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_16 : (stageRows 4 146 1114145 1 [5,9,8] [1041,134,6208,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_17 : (stageRows 4 146 1114145 1 [5,9] [1041,134,6208,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_11 : (stageRows 4 146 1114145 2 [3,5,9,8] [1041,134,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 1114145 (some 3)).all ([8,12,264,296,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_102_12
  · exact adapt_102_13
  · exact adapt_102_14
  · exact adapt_102_15
  · exact adapt_102_16
  · exact adapt_102_17
end Research.H1Cover
