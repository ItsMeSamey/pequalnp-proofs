import H1ClipWitness9822
namespace Research.H1Price
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet.CircuitCompiler

theorem env_in_run (xs : List (Finset Nat)) (ops : List Entry) :
    ∀ s ∈ xs, s ∈ run xs ops := by
  induction ops generalizing xs with
  | nil => exact fun _ h => h
  | cons e es ih =>
    intro s hs
    exact ih _ s (List.mem_append_left _ hs)

theorem run_append (xs : List (Finset Nat)) (a b : List Entry) :
    run xs (a++b) = run (run xs a) b := by
  induction a generalizing xs with
  | nil => rfl
  | cons e es ih => exact ih _

theorem transcript_append (erase : Nat → Bool) (hidden k : Nat) (a b : List Gate) :
    transcript erase hidden k (a++b) =
    transcript erase hidden k a ++ transcript erase hidden (k+a.length) b := by
  induction a generalizing k with
  | nil => simp [transcript]
  | cons e es ih => simp [transcript,ih,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm]

theorem original_port_in_run (erase : Nat → Bool) (hidden : Nat)
    (before tail : List Gate) (g : Gate) (j : Nat)
    (valid : j < (run inputScopes (transcript erase hidden 10 before)).length) :
    (run inputScopes (transcript erase hidden 10 before)).getD j ∅ ∈
      run inputScopes (transcript erase hidden 10 (before ++ g::tail)) := by
  rw [transcript_append, run_append]
  apply env_in_run
  rw [List.getD_eq_getElem?_getD,List.getElem?_eq_getElem valid,Option.getD_some]
  exact List.getElem_mem ..

end Research.H1Price
#print axioms Research.H1Price.original_port_in_run
