import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_127 : ([1349,4272,1128,4628,201] : List Nat).all (cliqueValid 4202513 [0,1,2,3,4,5,6,7,8,10,12,9,11])=true := by decide +kernel
end Research.H1Cover
