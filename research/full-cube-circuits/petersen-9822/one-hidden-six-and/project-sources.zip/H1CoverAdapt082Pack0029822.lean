import H1CoverAdapt082Data9822
import H1CoverAdapt082Pack0009822
import H1CoverAdapt082Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_82_9 : (stageRows 68 194 904241 2 [6,0,4,10,11] [134,4360,544]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_82
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_82_10 : (stageRows 68 194 904241 2 [6,0,4,10,11] [134,4360,800]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_82
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_82_8 : (stageRows 68 194 904241 3 [5,6,0,9,4,10,11] [134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 904241 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_82
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_82
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_82
    · decide +kernel
    · decide +kernel
  · exact adapt_82_9
  · exact adapt_82_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_82_3 : (stageRows 68 194 904241 4 [3,5,6,0,8,9,12,4,10,11] [134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 904241 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_82_4
  · exact adapt_82_5
  · exact adapt_82_6
  · exact adapt_82_7
  · exact adapt_82_8
end Research.H1Cover
