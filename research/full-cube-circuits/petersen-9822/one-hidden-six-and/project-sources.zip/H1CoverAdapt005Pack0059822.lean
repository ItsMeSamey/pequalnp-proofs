import H1CoverAdapt005Data9822
import H1CoverAdapt005Pack0009822
import H1CoverAdapt005Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_0 : (stageRows 32 145 73992 5 [0,4,5,6,1,8,9,10,11,12,2,3,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 73992 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_5_1
  · exact adapt_5_2
  · exact adapt_5_11
end Research.H1Cover
