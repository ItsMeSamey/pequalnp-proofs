import H1CoverAdapt025Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_1 : (stageRows 4 194 114721 4 [2,3,0,5,7,9,4,8,12,10,11] [66]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_2 : (stageRows 4 194 114721 4 [2,3,6,0,5,9,4,8,12,10,11] [130]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_4 : (stageRows 4 194 114721 3 [6,0,5,9,4,8,12,10,11] [134,8]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
end Research.H1Cover
