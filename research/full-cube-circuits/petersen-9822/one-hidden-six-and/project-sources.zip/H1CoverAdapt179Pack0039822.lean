import H1CoverAdapt179Data9822
import H1CoverAdapt179Pack0009822
import H1CoverAdapt179Pack0019822
import H1CoverAdapt179Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_179_14 : (stageRows 128 292 6291744 2 [6,9,10,11] [49,134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,9,10,11,8,12]) (ws:=[2571,1128,4628,1283,600])
    · exact clique_ok_179
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_179_9 : (stageRows 128 292 6291744 3 [3,6,9,10,11,8,12] [49,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6291744 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_179_10
  · exact adapt_179_11
  · exact adapt_179_12
  · exact adapt_179_13
  · exact adapt_179_14
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_179_4 : (stageRows 128 292 6291744 4 [1,2,3,6,7,9,10,11,8,12] [49]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6291744 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_179_5
  · exact adapt_179_6
  · exact adapt_179_7
  · exact adapt_179_8
  · exact adapt_179_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_179_0 : (stageRows 128 292 6291744 5 [0,1,2,3,4,5,6,7,9,10,11,8,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6291744 (some 0)).all ([1,17,33,49] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · exact adapt_179_1
  · exact adapt_179_2
  · exact adapt_179_3
  · exact adapt_179_4
end Research.H1Cover
