import H1CoverAdapt038Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_1 : (stageRows 96 257 284680 4 [5,1,2,6,7,3,8,9,10,11,12] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_3 : (stageRows 96 257 284680 3 [2,4,7,3,8,9,10,11,12] [33,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_5 : (stageRows 96 257 284680 2 [4,3,8,9,10,11,12] [33,134,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_6 : (stageRows 96 257 284680 2 [4,3,8,9,10,11,12] [33,134,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
end Research.H1Cover
