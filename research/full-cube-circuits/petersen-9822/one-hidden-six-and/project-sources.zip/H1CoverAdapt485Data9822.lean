import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_485 : ([1345,2565,4225,4613,1128] : List Nat).all (cliqueValid 404750534 [0,4,5,3,8,9,2,10,6,11,12,7,1])=true := by decide +kernel
end Research.H1Cover
