import H1CoverAdapt183Data9822
import H1CoverAdapt183Pack0009822
import H1CoverAdapt183Pack0019822
import H1CoverAdapt183Pack0029822
import H1CoverAdapt183Pack0039822
import H1CoverAdapt183Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_6 : (stageRows 192 768 6295040 3 [3,5,6,8,12,9] [3089,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6295040 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_183_7
  · exact adapt_183_8
  · exact adapt_183_9
  · exact adapt_183_10
  · exact adapt_183_11
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_3 : (stageRows 192 768 6295040 4 [2,3,1,5,6,7,8,12,9] [3089]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6295040 (some 2)).all ([4,6,12,132,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
  · exact adapt_183_4
  · exact adapt_183_5
  · exact adapt_183_6
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_0 : (stageRows 192 768 6295040 5 [0,2,3,1,4,5,6,7,8,12,9,11,10] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6295040 (some 0)).all ([1,17,33,3089] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
  · exact adapt_183_1
  · exact adapt_183_2
  · exact adapt_183_3
end Research.H1Cover
