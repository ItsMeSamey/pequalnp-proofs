import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_474 : ([600,2433,4628,2571,325] : List Nat).all (cliqueValid 402654848 [0,1,4,5,2,3,6,8,9,7,12,10,11])=true := by decide +kernel
end Research.H1Cover
