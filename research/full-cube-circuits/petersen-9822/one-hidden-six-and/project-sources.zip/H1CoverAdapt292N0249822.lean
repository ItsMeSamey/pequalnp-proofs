import H1CoverAdapt292Data9822
import H1CoverAdapt292N0259822
import H1CoverAdapt292N0269822
import H1CoverAdapt292N0279822
import H1CoverAdapt292N0289822
import H1CoverAdapt292N0299822
import H1CoverAdapt292N0309822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_292_24 : (stageRows 48 521 100696206 3 [6,1,9,3,8,12,7,2] [33,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100696206 (some 6)).all ([64,66,198,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_292_25
  · exact adapt_292_26
  · exact adapt_292_27
  · exact adapt_292_28
  · exact adapt_292_29
  · exact adapt_292_30
end Research.H1Cover
