import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_420 : ([1349,5156,2432,1128,152] : List Nat).all (cliqueValid 269486097 [0,1,2,3,5,6,7,8,9,10,12,4,11])=true := by decide +kernel
end Research.H1Cover
