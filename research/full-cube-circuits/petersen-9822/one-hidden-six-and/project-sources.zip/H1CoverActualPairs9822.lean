import H1CoverProductive9822
namespace Research.H1Cover

def orderPorts (p : Pair) : Pair := (min p.1 p.2,max p.1 p.2)

theorem productOrdered (h : Nat) (p : Pair) : product h (orderPorts p)=product h p := by
  rcases le_total p.1 p.2 with le|ge
  · simp [product,orderPorts,Nat.min_eq_left le,Nat.max_eq_right le]
  · simp [product,orderPorts,Nat.min_eq_right ge,Nat.max_eq_left ge,Nat.and_comm]

theorem usablePhysicalPairs (h : Nat) (xs : List Pair) (n : xs.length≤5)
    (fits : ∀ p∈xs,p.1<2048 ∧ p.2<2048 ∧ product h p<8192)
    (hot : ∀ i<13,∃ p∈xs,(product h p).testBit i=true)
    (port : Nat → Prop) (ports : ∀ p∈xs,port p.1 ∧ port p.2) :
    ∃ ys : List Pair, ys.length=5 ∧
      (∀ p∈ys,0<p.1 ∧ p.1≤p.2 ∧ p.2<2048 ∧ product h p≠0 ∧ product h p<8192) ∧
      (∀ i<13,∃ p∈ys,(product h p).testBit i=true) ∧ ∀ p∈ys,port p.1 ∧ port p.2 := by
  let ordered := xs.map orderPorts
  have sm (p) (hp : p∈ordered) : p.1≤p.2 ∧ p.2<2048 ∧ product h p<8192 := by
    obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hp
    obtain ⟨l,r,c⟩ := fits q hq
    rw [productOrdered]
    exact ⟨le_trans (min_le_left ..) (le_max_left ..),max_lt l r,c⟩
  have covered (i) (hi : i<13) : ∃ p∈ordered,(product h p).testBit i=true := by
    obtain ⟨q,hq,on⟩ := hot i hi
    exact ⟨orderPorts q,List.mem_map.mpr ⟨q,hq,rfl⟩,by simpa only [productOrdered] using on⟩
  obtain ⟨ys,five,old,shape,hits⟩ := productiveFive h ordered (by simpa [ordered] using n) sm covered
  refine ⟨ys,five,shape,hits,?_⟩
  intro p hp
  obtain ⟨q,hq,rfl⟩ := List.mem_map.mp (old p hp)
  rcases le_total q.1 q.2 with le|ge
  · simpa [orderPorts,Nat.min_eq_left le,Nat.max_eq_right le] using ports q hq
  · simpa [orderPorts,Nat.min_eq_right ge,Nat.max_eq_left ge] using (ports q hq).symm
end Research.H1Cover
