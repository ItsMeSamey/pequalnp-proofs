import H1CoverAdapt470Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_7 : (stageRows 272 520 402653378 2 [6,10,11,12,7,1] [17,800,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_8 : (stageRows 272 520 402653378 2 [3,6,10,11,12,1] [17,800,132]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_9 : (stageRows 272 520 402653378 2 [3,6,10,11,12] [17,800,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_11 : (stageRows 272 520 402653378 1 [10,11] [17,800,142,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
end Research.H1Cover
