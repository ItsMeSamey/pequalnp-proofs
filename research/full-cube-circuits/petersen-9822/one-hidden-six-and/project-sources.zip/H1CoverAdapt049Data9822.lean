import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_49 : ([5154,585,1349,2307,4613] : List Nat).all (cliqueValid 393858 [0,4,2,3,6,5,12,1,10,11,8,9,7])=true := by decide +kernel
end Research.H1Cover
