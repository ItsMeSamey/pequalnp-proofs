import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_335 : ([600,1283,248,4225,385] : List Nat).all (cliqueValid 125836352 [0,2,3,4,5,1,6,8,7,9,12,10,11])=true := by decide +kernel
end Research.H1Cover
