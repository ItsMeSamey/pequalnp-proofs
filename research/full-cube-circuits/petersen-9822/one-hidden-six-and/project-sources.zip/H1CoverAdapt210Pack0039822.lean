import H1CoverAdapt210Data9822
import H1CoverAdapt210Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_14 : (stageRows 130 196 7209777 1 [0,5,9] [134,4360,3088,4160]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_15 : (stageRows 130 196 7209777 1 [0,5,9] [134,4360,3088,6208]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_10 : (stageRows 130 196 7209777 2 [6,0,5,9] [134,4360,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7209777 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_210_11
  · exact adapt_210_12
  · exact adapt_210_13
  · exact adapt_210_14
  · exact adapt_210_15
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_8 : (stageRows 130 196 7209777 3 [4,6,0,10,11,5,9] [134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7209777 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
  · exact adapt_210_9
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
  · exact adapt_210_10
end Research.H1Cover
