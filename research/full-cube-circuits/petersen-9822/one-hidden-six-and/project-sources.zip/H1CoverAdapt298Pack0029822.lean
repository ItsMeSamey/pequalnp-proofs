import H1CoverAdapt298Data9822
import H1CoverAdapt298Pack0009822
import H1CoverAdapt298Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_298_2 : (stageRows 72 288 100763712 4 [1,2,5,3,7,9,10,6,8,11,12] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100763712 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_298
    · decide +kernel
    · decide +kernel
  · exact adapt_298_3
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_298
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_298
    · decide +kernel
    · decide +kernel
  · exact adapt_298_4
end Research.H1Cover
