import H1CoverAdapt198Data9822
import H1CoverAdapt198Pack0009822
import H1CoverAdapt198Pack0019822
import H1CoverAdapt198Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_4 : (stageRows 192 770 6426128 3 [3,6,4,12,8,11,9,10] [33,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6426128 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
  · exact adapt_198_5
  · apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
  · exact adapt_198_6
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_2 : (stageRows 192 770 6426128 4 [1,2,3,6,7,4,12,8,11,9,10] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6426128 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
  · exact adapt_198_3
  · apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
  · exact adapt_198_4
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_13 : (stageRows 192 770 6426128 3 [2,3,5,7,12,8,9] [3089,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_14 : (stageRows 192 770 6426128 3 [2,3,6,5,12,8,9] [3089,130]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
end Research.H1Cover
