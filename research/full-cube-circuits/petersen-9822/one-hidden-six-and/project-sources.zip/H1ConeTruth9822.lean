import H1ActualCollector9822
namespace Research.H1Price
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet.CircuitCompiler

def litFront (w : Nat → Bool) (f : Finset Nat) : Prop := ∃ i ∈ f, w i = true
def respectsOriginalOR (w : Nat → Bool) : Nat → List Gate → Prop
  | _,[] => True
  | k,g::gs => (orFlag g = true → w k =
      (w (g.inputs.getD 0 k) || w (g.inputs.getD 1 k))) ∧ respectsOriginalOR w (k+1) gs

theorem discover_truth (w : Nat → Bool) (gs : List Gate) (k : Nat) (f : Finset Nat)
    (ok : respectsOriginalOR w k gs) :
    litFront w (discover k gs f).1 ↔ litFront w f := by
  induction gs generalizing k with
  | nil => rfl
  | cons g gs ih =>
    obtain ⟨here,rest⟩ := ok
    apply Iff.trans _ (ih (k+1) rest)
    simp only [discover]
    split
    next cond =>
      have e := here cond.2
      constructor
      · rintro ⟨i,hi,v⟩
        simp only [Finset.mem_insert,Finset.mem_erase] at hi
        rcases hi with h|h|⟨_,h⟩
        · exact ⟨k,cond.1,by rw [e,Bool.or_eq_true]; exact Or.inl (h ▸ v)⟩
        · exact ⟨k,cond.1,by rw [e,Bool.or_eq_true]; exact Or.inr (h ▸ v)⟩
        · exact ⟨i,h,v⟩
      · rintro ⟨i,hi,v⟩
        by_cases eq : i=k
        · subst i
          rw [e,Bool.or_eq_true] at v
          rcases v with a|b
          · exact ⟨_,Finset.mem_insert_self ..,a⟩
          · exact ⟨_,Finset.mem_insert_of_mem (Finset.mem_insert_self ..),b⟩
        · exact ⟨_,Finset.mem_insert_of_mem (Finset.mem_insert_of_mem (Finset.mem_erase.mpr ⟨eq,hi⟩)),v⟩
    next => rfl

theorem output_eq_front (w : Nat → Bool) (gs : List Gate) (out : Nat)
    (h : respectsOriginalOR w 10 gs) :
    litFront w (discover 10 gs {out}).1 ↔ w out=true := by
  simpa [litFront] using discover_truth w gs 10 {out} h
end Research.H1Price
#print axioms Research.H1Price.output_eq_front
