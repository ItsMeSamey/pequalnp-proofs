import H1CoverAdapt037Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_37_9 : (stageRows 80 513 279684 1 [9,10] [33,198,4360,2064]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_37_10 : (stageRows 80 513 279684 1 [9] [33,198,4360,3088]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
end Research.H1Cover
