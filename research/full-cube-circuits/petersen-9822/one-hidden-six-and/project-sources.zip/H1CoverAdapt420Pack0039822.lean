import H1CoverAdapt420Data9822
import H1CoverAdapt420Pack0009822
import H1CoverAdapt420Pack0019822
import H1CoverAdapt420Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_420_7 : (stageRows 68 258 269486097 3 [3,6,8,9,10,12,11] [49,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,7,8,9,10,12,4,11]) (ws:=[1349,5156,2432,1128,152])
    · exact clique_ok_420
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_420_4 : (stageRows 68 258 269486097 4 [1,2,3,6,7,8,9,10,12,11] [49]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 269486097 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,5,6,7,8,9,10,12,4,11]) (ws:=[1349,5156,2432,1128,152])
    · exact clique_ok_420
    · decide +kernel
    · decide +kernel
  · exact adapt_420_5
  · exact adapt_420_6
  · apply debitBound (order:=[0,1,2,3,5,6,7,8,9,10,12,4,11]) (ws:=[1349,5156,2432,1128,152])
    · exact clique_ok_420
    · decide +kernel
    · decide +kernel
  · exact adapt_420_7
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_420_8 : (stageRows 68 258 269486097 4 [1,2,3,5,6,7,8,9,10,12] [2065]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,7,8,9,10,12,4,11]) (ws:=[1349,5156,2432,1128,152])
    · exact clique_ok_420
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_420_0 : (stageRows 68 258 269486097 5 [0,1,2,3,5,6,7,8,9,10,12,4,11] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 269486097 (some 0)).all ([1,17,33,49,2065] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_420_1
  · exact adapt_420_2
  · exact adapt_420_3
  · exact adapt_420_4
  · exact adapt_420_8
end Research.H1Cover
