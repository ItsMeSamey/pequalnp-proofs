import H1CoverAdapt145Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_145_6 : (stageRows 24 256 5242944 2 [2,9,10,1,6,7] [33,4360,2064]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_145
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_145_8 : (stageRows 24 256 5242944 1 [9,6,7] [33,4360,3088,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_145
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_145_9 : (stageRows 24 256 5242944 1 [9,7] [33,4360,3088,70]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_145
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_145_10 : (stageRows 24 256 5242944 1 [9,6] [33,4360,3088,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_145
    · decide +kernel
    · decide +kernel
end Research.H1Cover
