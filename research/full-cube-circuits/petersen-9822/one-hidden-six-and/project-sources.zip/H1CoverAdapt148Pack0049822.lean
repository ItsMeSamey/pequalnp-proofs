import H1CoverAdapt148Data9822
import H1CoverAdapt148Pack0019822
import H1CoverAdapt148Pack0029822
import H1CoverAdapt148Pack0039822
import H1CoverLastTerminal9822
import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_11_f6_p0 : terminalCharge 88 256 5244992 [33,4360,3088,198,1664] []=true := by decide +kernel
theorem adapt_148_11 : (stageRows 88 256 5244992 1 [9] [33,4360,3088,198]).all fixedPrice=true := by
  apply lastTerminal
  intro m hm
  have check : (finishing 5244992 [9]).all ([512,544,640,768,800,1536,1664] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp check m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_148_11_f0_p0
  · exact adapt_148_11_f1_p0
  · exact adapt_148_11_f2_p0
  · exact adapt_148_11_f3_p0
  · exact adapt_148_11_f4_p0
  · exact adapt_148_11_f5_p0
  · exact adapt_148_11_f6_p0
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_7 : (stageRows 88 256 5244992 2 [2,9,1,6,7] [33,4360,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5244992 (some 2)).all ([4,6,12,70,132,134,198] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
  · exact adapt_148_8
  · apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
  · exact adapt_148_9
  · apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
  · exact adapt_148_10
  · exact adapt_148_11
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_5 : (stageRows 88 256 5244992 3 [4,2,9,10,11,1,6,7] [33,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5244992 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
  · exact adapt_148_6
  · exact adapt_148_7
end Research.H1Cover
