import H1CoverAdapt050Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_2 : (stageRows 40 384 397632 3 [2,3,5,6,10,11,9,8,12] [17,130]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_4 : (stageRows 40 384 397632 2 [5,6,10,11,9,8,12] [17,134,8]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_5 : (stageRows 40 384 397632 2 [5,6,10,11,9,8,12] [17,134,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_6 : (stageRows 40 384 397632 2 [5,6,10,11,9,12] [17,134,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
end Research.H1Cover
