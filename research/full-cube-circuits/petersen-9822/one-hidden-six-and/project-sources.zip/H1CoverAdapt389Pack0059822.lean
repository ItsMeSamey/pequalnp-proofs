import H1CoverAdapt389Data9822
import H1CoverAdapt389Pack0029822
import H1CoverAdapt389Pack0039822
import H1CoverAdapt389Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_389_14 : (stageRows 130 516 176161313 1 [4,10] [545,134,4360,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_389_9 : (stageRows 130 516 176161313 2 [6,4,11,10] [545,134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 176161313 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_389_10
  · exact adapt_389_11
  · exact adapt_389_12
  · exact adapt_389_13
  · exact adapt_389_14
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_389_7 : (stageRows 130 516 176161313 3 [3,6,4,8,11,12,10] [545,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 176161313 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
  · exact adapt_389_8
  · apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
  · exact adapt_389_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_389_5 : (stageRows 130 516 176161313 4 [1,2,3,6,4,8,11,12,7,10] [545]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 176161313 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
  · exact adapt_389_6
  · apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
  · exact adapt_389_7
end Research.H1Cover
