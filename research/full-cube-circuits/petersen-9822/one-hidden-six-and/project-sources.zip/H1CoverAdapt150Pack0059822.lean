import H1CoverAdapt150Data9822
import H1CoverAdapt150Pack0009822
import H1CoverAdapt150Pack0029822
import H1CoverAdapt150Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_0 : (stageRows 48 257 5246988 5 [0,4,5,1,6,10,8,9,2,7,11,12,3] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5246988 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_150_1
  · exact adapt_150_2
  · exact adapt_150_10
end Research.H1Cover
