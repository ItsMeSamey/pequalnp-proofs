import H1CoverAdapt298Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_298_1 : (stageRows 72 288 100763712 4 [1,2,4,5,3,7,9,10,6,8,11,12] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_298
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_298_3 : (stageRows 72 288 100763712 3 [5,3,7,9,10,6,8,11,12] [17,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_298
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_298_5 : (stageRows 72 288 100763712 2 [3,9,10,6,8,11,12] [17,134,32]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_298
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_298_6 : (stageRows 72 288 100763712 2 [3,9,10,6,8,11,12] [17,134,33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_298
    · decide +kernel
    · decide +kernel
end Research.H1Cover
