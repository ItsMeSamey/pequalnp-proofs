import H1CoverAdapt485Data9822
import H1CoverAdapt485N0019822
import H1CoverAdapt485N0029822
import H1CoverAdapt485N0149822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_485_0 : (stageRows 272 521 404750534 5 [0,4,5,3,8,9,2,10,6,11,12,7,1] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 404750534 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_485_1
  · exact adapt_485_2
  · exact adapt_485_14
end Research.H1Cover
