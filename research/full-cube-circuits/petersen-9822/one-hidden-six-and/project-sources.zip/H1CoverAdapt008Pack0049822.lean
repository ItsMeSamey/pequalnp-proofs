import H1CoverAdapt008Data9822
import H1CoverAdapt008Pack0009822
import H1CoverAdapt008Pack0029822
import H1CoverAdapt008Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_17 : (stageRows 40 272 77890 2 [3,9,8,12] [33,3088,198]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_12 : (stageRows 40 272 77890 3 [2,3,9,1,7,8,12,6] [33,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 77890 (some 2)).all ([4,6,12,70,132,134,198] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · exact adapt_8_13
  · exact adapt_8_14
  · exact adapt_8_15
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · exact adapt_8_16
  · exact adapt_8_17
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_10 : (stageRows 40 272 77890 4 [4,2,3,9,10,11,1,7,8,12,6] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 77890 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · exact adapt_8_11
  · exact adapt_8_12
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_0 : (stageRows 40 272 77890 5 [0,4,5,2,3,9,10,11,1,7,8,12,6] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 77890 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_8_1
  · exact adapt_8_2
  · exact adapt_8_10
end Research.H1Cover
