import H1CoverAdapt128Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_128_4 : (stageRows 80 514 4203664 3 [6,1,2,8,4,9,11,7,10] [33,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_128_7 : (stageRows 80 514 4203664 1 [9,7] [33,4360,3152,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_128_8 : (stageRows 80 514 4203664 1 [9] [33,4360,3152,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
end Research.H1Cover
