import H1CoverAdapt002Data9822
import H1CoverAdapt002Pack0009822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_2_8 : (stageRows 17 32 73736 1 [10,7] [17,800,6208,14]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_2_9 : (stageRows 17 32 73736 1 [10,3] [17,800,6208,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_2_10 : (stageRows 17 32 73736 1 [10] [17,800,6208,142]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_2_6 : (stageRows 17 32 73736 2 [1,10,2,3,7] [17,800,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 73736 (some 1)).all ([2,6,14,66,130,134,142] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
  · exact adapt_2_7
  · exact adapt_2_8
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_2
    · decide +kernel
    · decide +kernel
  · exact adapt_2_9
  · exact adapt_2_10
end Research.H1Cover
