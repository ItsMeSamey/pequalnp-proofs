import H1CoverAdapt012Data9822
import H1CoverAdapt012N0019822
import H1CoverAdapt012N0029822
import H1CoverAdapt012N0069822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_12_0 : (stageRows 192 544 100096 5 [0,1,6,2,5,3,4,7,11,12,8,10,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100096 (some 0)).all ([1,17,33,801] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,6,2,5,3,4,7,11,12,8,10,9]) (ws:=[248,5154,2432,1128,4148])
    · exact clique_ok_12
    · decide +kernel
    · decide +kernel
  · exact adapt_12_1
  · exact adapt_12_2
  · exact adapt_12_6
end Research.H1Cover
