import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_131 : ([5156,2433,2565,1283,4613] : List Nat).all (cliqueValid 4718860 [0,4,6,1,5,10,11,12,2,7,9,8,3])=true := by decide +kernel
end Research.H1Cover
