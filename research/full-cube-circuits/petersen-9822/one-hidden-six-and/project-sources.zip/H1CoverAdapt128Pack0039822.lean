import H1CoverAdapt128Data9822
import H1CoverAdapt128Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_128_9 : (stageRows 80 514 4203664 1 [9] [33,4360,3152,1158]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_128_6 : (stageRows 80 514 4203664 2 [1,2,9,7] [33,4360,3152]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4203664 (some 1)).all ([2,6,66,130,134,1154,1158] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · exact adapt_128_7
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · exact adapt_128_8
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · exact adapt_128_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_128_5 : (stageRows 80 514 4203664 3 [6,1,2,4,9,11,7,10] [33,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4203664 (some 6)).all ([64,66,2112,3152,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · exact adapt_128_6
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_128_3 : (stageRows 80 514 4203664 4 [3,6,1,2,8,12,4,9,11,7,10] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4203664 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,5,6,1,2,8,12,4,9,11,7,10]) (ws:=[4626,2309,2565,2307,2433])
    · exact clique_ok_128
    · decide +kernel
    · decide +kernel
  · exact adapt_128_4
  · exact adapt_128_5
end Research.H1Cover
