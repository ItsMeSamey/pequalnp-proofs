import H1CoverAdapt063Data9822
import H1CoverAdapt063Pack0009822
import H1CoverAdapt063Pack0019822
import H1CoverAdapt063Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_6 : (stageRows 64 786 592912 3 [6,3,1,2,11,12,7,10] [17,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 592912 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_63_7
  · exact adapt_63_8
  · exact adapt_63_9
  · exact adapt_63_10
  · exact adapt_63_11
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_1 : (stageRows 64 786 592912 4 [5,6,3,1,2,8,9,11,12,7,10] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 592912 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_63_2
  · exact adapt_63_3
  · exact adapt_63_4
  · exact adapt_63_5
  · exact adapt_63_6
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_18 : (stageRows 64 786 592912 4 [4,6,3,1,2,8,9,11,12,7,10] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_0 : (stageRows 64 786 592912 5 [0,4,5,6,3,1,2,8,9,11,12,7,10] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 592912 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
  · exact adapt_63_1
  · exact adapt_63_18
end Research.H1Cover
