import H1CoverAdapt090Data9822
import H1CoverAdapt090Pack0009822
import H1CoverAdapt090Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_2 : (stageRows 104 320 908368 4 [1,2,3,5,7,8,9,6,10,11,12] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 908368 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
  · exact adapt_90_3
  · exact adapt_90_4
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_11 : (stageRows 104 320 908368 3 [2,3,4,7,8,9,6,10,11,12] [33,2]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_12 : (stageRows 104 320 908368 3 [3,4,7,8,9,6,10,11,12] [33,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_13 : (stageRows 104 320 908368 3 [2,3,4,7,8,9,10,11,12] [33,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,4,7,8,9,6,10,11,12]) (ws:=[2571,449,2216,1283,581])
    · exact clique_ok_90
    · decide +kernel
    · decide +kernel
end Research.H1Cover
