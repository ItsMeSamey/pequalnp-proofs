import H1ScopeClip9822
namespace Research.H1Price
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet.CircuitCompiler

def inputScopes := (List.range 10).map (fun i : Nat => ({i} : Finset Nat))
def seedScopes := (∅ : Finset Nat) :: {10} :: inputScopes
theorem clippedGraph (erase : Nat → Bool) (hidden : Nat) (gs : List Gate) :
    ∃ g : Finset (Finset Nat),
      g.card + saved erase 10 gs ≤ (gs.filter orFlag).length ∧
      ∀ m : Nat, vertices m ∈ run inputScopes (transcript erase hidden 10 gs) → ranked g m := by
  have base : Bank 0 seedScopes := Bank.base _ (by
    intro s hs
    simp [seedScopes,inputScopes] at hs
    rcases hs with rfl|rfl|⟨i,_,rfl⟩ <;> simp)
  have seed : inputScopes ⊆ seedScopes := fun i hi =>
    List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hi)
  obtain ⟨ys,b,all⟩ := programBank (transcript erase hidden 10 gs) base (List.Subset.refl seedScopes)
    (by simp [seedScopes]) seed (root_ok erase hidden 10 gs seedScopes (by simp [seedScopes]) (by simp [seedScopes]))
  obtain ⟨g,small,rank⟩ := bankRank b
  refine ⟨g,?_,fun m hm => rank m (all hm)⟩
  have eq := exact_debit erase hidden 10 gs
  omega

end Research.H1Price
#print axioms Research.H1Price.clippedGraph
