import H1CoverAdapt298Data9822
import H1CoverAdapt298Pack0009822
import H1CoverAdapt298Pack0029822
import H1CoverAdapt298Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_298_0 : (stageRows 72 288 100763712 5 [0,1,2,4,5,3,7,9,10,6,8,11,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100763712 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_298_1
  · exact adapt_298_2
  · exact adapt_298_10
end Research.H1Cover
