import H1CoverAdapt073Data9822
import H1CoverAdapt073Pack0009822
import H1CoverAdapt073Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_2 : (stageRows 128 612 787232 4 [1,2,3,6,4,7,8,12,11,9,10] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 787232 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
  · exact adapt_73_3
  · apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
  · exact adapt_73_4
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_0 : (stageRows 128 612 787232 5 [0,1,2,3,5,6,4,7,8,12,11,9,10] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 787232 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
  · exact adapt_73_1
  · exact adapt_73_2
end Research.H1Cover
