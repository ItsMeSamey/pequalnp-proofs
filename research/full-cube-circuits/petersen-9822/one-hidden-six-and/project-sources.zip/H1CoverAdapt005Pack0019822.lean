import H1CoverAdapt005Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_5 : (stageRows 32 145 73992 2 [1,10,11,2,3,7] [17,800,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_7 : (stageRows 32 145 73992 1 [10,3,7] [17,800,6208,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_8 : (stageRows 32 145 73992 1 [10,7] [17,800,6208,14]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_9 : (stageRows 32 145 73992 1 [10,3] [17,800,6208,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
end Research.H1Cover
