import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_81 : ([464,4626,248,4272,596] : List Nat).all (cliqueValid 904209 [1,2,3,5,6,0,7,8,9,12,4,10,11])=true := by decide +kernel
end Research.H1Cover
