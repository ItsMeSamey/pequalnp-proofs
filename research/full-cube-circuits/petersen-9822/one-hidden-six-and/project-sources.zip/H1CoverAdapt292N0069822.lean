import H1CoverAdapt292Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_292_6 : (stageRows 48 521 100696206 3 [6,10,11,1,3,8,12,7,2] [17,544]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,10,11,1,9,3,8,12,7,2]) (ws:=[2569,1283,4225,5154,4609])
    · exact clique_ok_292
    · decide +kernel
    · decide +kernel
end Research.H1Cover
