import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_292 : ([2569,1283,4225,5154,4609] : List Nat).all (cliqueValid 100696206 [0,4,5,6,10,11,1,9,3,8,12,7,2])=true := by decide +kernel
end Research.H1Cover
