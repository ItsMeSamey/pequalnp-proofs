import H1CoverAdapt073Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_7 : (stageRows 128 612 787232 1 [4,11,9,10] [33,134,4360,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_8 : (stageRows 128 612 787232 1 [4,11,9,10] [33,134,4360,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_9 : (stageRows 128 612 787232 1 [4,9,10] [33,134,4360,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
end Research.H1Cover
