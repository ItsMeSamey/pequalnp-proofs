import H1CoverAdapt037Data9822
import H1CoverAdapt037Pack0019822
import H1CoverAdapt037Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_37_11 : (stageRows 80 513 279684 1 [9] [33,198,4360,3216]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_37_8 : (stageRows 80 513 279684 2 [4,9,11,10] [33,198,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 279684 (some 4)).all ([16,17,1040,1168,2064,3088,3216] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · exact adapt_37_9
  · exact adapt_37_10
  · exact adapt_37_11
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_37_6 : (stageRows 80 513 279684 3 [3,4,12,8,9,11,10] [33,198]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 279684 (some 3)).all ([8,12,140,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · exact adapt_37_7
  · exact adapt_37_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_37_3 : (stageRows 80 513 279684 4 [1,3,6,4,12,2,8,9,11,10,7] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 279684 (some 1)).all ([2,6,66,130,134,198] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · exact adapt_37_4
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,1,3,6,4,12,2,8,9,11,10,7]) (ws:=[4628,1097,2571,2309,5123])
    · exact clique_ok_37
    · decide +kernel
    · decide +kernel
  · exact adapt_37_5
  · exact adapt_37_6
end Research.H1Cover
