import H1CoverAdapt022Data9822
import H1CoverAdapt022Pack0009822
import H1CoverAdapt022Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_22_8 : (stageRows 4 66 114689 3 [5,6,0,9,4,10,11] [134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_22
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_22_3 : (stageRows 4 66 114689 4 [3,5,6,0,8,9,12,4,10,11] [134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 114689 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_22_4
  · exact adapt_22_5
  · exact adapt_22_6
  · exact adapt_22_7
  · exact adapt_22_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_22_0 : (stageRows 4 66 114689 5 [1,2,3,5,6,0,7,8,9,12,4,10,11] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 114689 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_22
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,5,6,0,7,8,9,12,4,10,11]) (ws:=[464,4626,248,4272,596])
    · exact clique_ok_22
    · decide +kernel
    · decide +kernel
  · exact adapt_22_1
  · exact adapt_22_2
  · exact adapt_22_3
end Research.H1Cover
