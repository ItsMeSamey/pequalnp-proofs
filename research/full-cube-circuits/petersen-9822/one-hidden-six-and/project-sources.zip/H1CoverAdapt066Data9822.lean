import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_66 : ([1283,2565,4225,577,2433] : List Nat).all (cliqueValid 604226 [0,4,5,3,2,8,9,10,1,7,11,12,6])=true := by decide +kernel
end Research.H1Cover
