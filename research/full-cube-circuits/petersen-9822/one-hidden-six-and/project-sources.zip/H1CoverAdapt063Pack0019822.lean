import H1CoverAdapt063Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_7 : (stageRows 64 786 592912 2 [3,1,2,11,12,7,10] [17,800,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_8 : (stageRows 64 786 592912 2 [3,2,11,12,7,10] [17,800,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_9 : (stageRows 64 786 592912 2 [3,1,2,12,7,10] [17,800,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_10 : (stageRows 64 786 592912 2 [3,1,2,11,7,10] [17,800,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
end Research.H1Cover
