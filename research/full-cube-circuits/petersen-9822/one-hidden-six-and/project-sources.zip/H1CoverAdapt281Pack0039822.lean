import H1CoverAdapt281Data9822
import H1CoverAdapt281Pack0019822
import H1CoverAdapt281Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_15 : (stageRows 176 512 100663936 1 [3,8,9] [33,134,3088,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_281
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_16 : (stageRows 176 512 100663936 1 [3,8,9] [33,134,3088,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_281
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_10 : (stageRows 176 512 100663936 2 [6,3,12,8,9] [33,134,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100663936 (some 6)).all ([64,66,194,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_281_11
  · exact adapt_281_12
  · exact adapt_281_13
  · exact adapt_281_14
  · exact adapt_281_15
  · exact adapt_281_16
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_8 : (stageRows 176 512 100663936 3 [4,6,3,10,11,12,8,9] [33,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100663936 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_281
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_281
    · decide +kernel
    · decide +kernel
  · exact adapt_281_9
  · apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_281
    · decide +kernel
    · decide +kernel
  · exact adapt_281_10
end Research.H1Cover
