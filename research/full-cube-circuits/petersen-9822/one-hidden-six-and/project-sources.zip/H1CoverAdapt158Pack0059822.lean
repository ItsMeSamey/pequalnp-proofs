import H1CoverAdapt158Data9822
import H1CoverAdapt158Pack0009822
import H1CoverAdapt158Pack0019822
import H1CoverAdapt158Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_0 : (stageRows 48 385 5771532 5 [0,4,5,6,1,10,11,9,2,7,8,12,3] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5771532 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_158_1
  · exact adapt_158_2
  · exact adapt_158_3
end Research.H1Cover
