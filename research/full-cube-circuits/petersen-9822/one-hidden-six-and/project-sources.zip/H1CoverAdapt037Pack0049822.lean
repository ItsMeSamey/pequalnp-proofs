import H1CoverAdapt037Data9822
import H1CoverAdapt037Pack0009822
import H1CoverAdapt037Pack0019822
import H1CoverAdapt037Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_37_0 : (stageRows 80 513 279684 5 [0,5,1,3,6,4,12,2,8,9,11,10,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 279684 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_37_1
  · exact adapt_37_2
  · exact adapt_37_3
end Research.H1Cover
