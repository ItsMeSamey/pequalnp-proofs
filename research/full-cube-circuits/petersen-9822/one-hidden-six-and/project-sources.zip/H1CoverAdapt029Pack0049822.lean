import H1CoverAdapt029Data9822
import H1CoverAdapt029Pack0029822
import H1CoverAdapt029Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_17 : (stageRows 192 548 116512 2 [6,4,11,10] [801,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_18 : (stageRows 192 548 116512 2 [6,4,11,10] [801,134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_13 : (stageRows 192 548 116512 3 [3,6,4,12,11,10] [801,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 116512 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_29_14
  · exact adapt_29_15
  · exact adapt_29_16
  · exact adapt_29_17
  · exact adapt_29_18
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_10 : (stageRows 192 548 116512 4 [1,2,3,6,4,7,12,11,10] [801]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 116512 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
  · exact adapt_29_11
  · exact adapt_29_12
  · exact adapt_29_13
end Research.H1Cover
