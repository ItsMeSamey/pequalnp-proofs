import H1CoverAdapt216Data9822
import H1CoverAdapt216Pack0009822
import H1CoverAdapt216Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_9 : (stageRows 160 385 7213864 2 [5,10,11,3,9,8] [17,134,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_10 : (stageRows 160 385 7213864 2 [5,10,3,9,8] [17,134,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_5 : (stageRows 160 385 7213864 3 [6,5,10,11,3,9,8,12] [17,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7213864 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_216_6
  · exact adapt_216_7
  · exact adapt_216_8
  · exact adapt_216_9
  · exact adapt_216_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_2 : (stageRows 160 385 7213864 4 [1,2,6,5,7,10,11,3,9,8,12] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7213864 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
  · exact adapt_216_3
  · exact adapt_216_4
  · apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
  · exact adapt_216_5
end Research.H1Cover
