import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_11_f2_p0 : terminalCharge 88 256 5244992 [33,4360,3088,198,640] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_11_f3_p0 : terminalCharge 88 256 5244992 [33,4360,3088,198,768] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_11_f4_p0 : terminalCharge 88 256 5244992 [33,4360,3088,198,800] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_11_f5_p0 : terminalCharge 88 256 5244992 [33,4360,3088,198,1536] []=true := by decide +kernel
end Research.H1Cover
