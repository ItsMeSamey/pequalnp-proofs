import H1ActualCollector9822
namespace Research.H1Price
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet.CircuitCompiler

theorem persist_front (gs : List Gate) (k : Nat) (f : Finset Nat) {j : Nat} (hj : j ∈ f) :
    j ∈ (discover k gs f).1 ∨ j ∈ (discover k gs f).2 := by
  induction gs generalizing k with
  | nil => exact Or.inl hj
  | cons g gs ih =>
    have old := ih (k+1)
    simp only [discover]
    split
    next condition =>
      rcases old with a|b
      · by_cases eq : j=k
        · exact Or.inr (by simp [eq])
        · exact Or.inl (Finset.mem_insert_of_mem (Finset.mem_insert_of_mem (Finset.mem_erase.mpr ⟨eq,a⟩)))
      · exact Or.inr (List.mem_cons_of_mem _ b)
    next => exact old

def inCone (gs : List Gate) (k : Nat) (f : Finset Nat) (j : Nat) : Prop :=
  j ∈ (discover k gs f).1 ∨ j ∈ (discover k gs f).2

theorem cone_monotone (g : Gate) (gs : List Gate) (k : Nat) (f : Finset Nat) {j : Nat}
    (h : inCone gs (k+1) f j) : inCone (g::gs) k f j := by
  unfold inCone at h ⊢
  simp only [discover]
  split
  next =>
    rcases h with a|b
    · by_cases eq : j=k
      · exact Or.inr (by simp [eq])
      · exact Or.inl (Finset.mem_insert_of_mem (Finset.mem_insert_of_mem (Finset.mem_erase.mpr ⟨eq,a⟩)))
    · exact Or.inr (List.mem_cons_of_mem _ b)
  next => exact h

theorem erased_atLeast (gs : List Gate) (k : Nat) (f : Finset Nat) :
    ∀ j ∈ (discover k gs f).2, k ≤ j := by
  induction gs generalizing k with
  | nil => simp [discover]
  | cons g gs ih =>
    simp only [discover]
    split
    next =>
      intro j hj
      rcases List.mem_cons.mp hj with rfl|old
      · exact Nat.le_refl _
      · exact Nat.le_trans (Nat.le_succ _) (ih _ _ old)
    next =>
      intro j hj
      exact Nat.le_trans (Nat.le_succ _) (ih _ _ hj)

theorem erased_children (gs : List Gate) (k : Nat) (f : Finset Nat) :
    ∀ idx g, gs[idx]? = some g → k+idx ∈ (discover k gs f).2 →
    ∀ p : Fin 2, inCone gs k f (g.inputs.getD p.val (k+idx)) := by
  induction gs generalizing k with
  | nil => simp
  | cons g gs ih =>
    intro idx e he hi p
    cases idx with
    | zero =>
      have eq : g=e := by simpa using he
      subst e
      simp only [Nat.add_zero,discover] at hi ⊢
      unfold inCone
      simp only [discover]
      split
      next h => fin_cases p <;> simp
      next h =>
        simp only [if_neg h] at hi
        have low := erased_atLeast gs (k+1) f k hi
        omega
    | succ j =>
      apply cone_monotone
      rw [show k+(j+1) = k+1+j by omega]
      apply ih (k+1) j e (by simpa using he) _ p
      have ne : k+(j+1) ≠ k := by omega
      simp only [discover] at hi
      split at hi
      next => simpa [ne,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hi
      next => simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hi
end Research.H1Price
#print axioms Research.H1Price.erased_children
