import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_216 : ([1349,2185,464,2563,1035] : List Nat).all (cliqueValid 7213864 [0,1,2,4,6,5,7,10,11,3,9,8,12])=true := by decide +kernel
end Research.H1Cover
