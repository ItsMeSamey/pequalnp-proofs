import H1CoverAdapt005Data9822
import H1CoverAdapt005Pack0009822
import H1CoverAdapt005Pack0019822
import H1CoverAdapt005Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_6 : (stageRows 32 145 73992 2 [1,10,2,3,7] [17,800,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 73992 (some 1)).all ([2,6,14,66,130,134,142] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
  · exact adapt_5_7
  · exact adapt_5_8
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
  · exact adapt_5_9
  · exact adapt_5_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_4 : (stageRows 32 145 73992 3 [6,1,10,11,12,2,3,7] [17,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 73992 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
  · exact adapt_5_5
  · exact adapt_5_6
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_2 : (stageRows 32 145 73992 4 [5,6,1,8,9,10,11,12,2,3,7] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 73992 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
  · exact adapt_5_3
  · apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
  · exact adapt_5_4
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_11 : (stageRows 32 145 73992 4 [4,6,1,8,9,10,11,12,2,3,7] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
end Research.H1Cover
