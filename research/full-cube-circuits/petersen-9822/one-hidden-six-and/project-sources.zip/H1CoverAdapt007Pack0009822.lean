import H1CoverAdapt007Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_1 : (stageRows 32 273 77832 4 [4,5,6,1,8,9,2,3,10,11,12,7] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_3 : (stageRows 32 273 77832 3 [6,1,9,2,3,10,11,12,7] [17,288]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_5 : (stageRows 32 273 77832 2 [1,2,3,10,11,12,7] [17,800,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
end Research.H1Cover
