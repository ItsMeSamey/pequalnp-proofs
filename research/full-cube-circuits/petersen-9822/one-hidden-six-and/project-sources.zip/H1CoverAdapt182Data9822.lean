import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_182 : ([1128,2565,4628,1283,600] : List Nat).all (cliqueValid 6292256 [0,2,3,1,4,5,6,10,7,9,11,8,12])=true := by decide +kernel
end Research.H1Cover
