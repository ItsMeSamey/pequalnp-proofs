import H1CoverAdapt281Data9822
import H1CoverAdapt281Pack0009822
import H1CoverAdapt281Pack0019822
import H1CoverAdapt281Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_3 : (stageRows 176 512 100663936 4 [2,4,1,6,3,10,11,7,12,8,9] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100663936 (some 2)).all ([4,6,12,132,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_281_4
  · exact adapt_281_5
  · exact adapt_281_6
  · exact adapt_281_7
  · exact adapt_281_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_0 : (stageRows 176 512 100663936 5 [0,2,4,5,1,6,3,10,11,7,12,8,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100663936 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_281_1
  · exact adapt_281_2
  · exact adapt_281_3
end Research.H1Cover
