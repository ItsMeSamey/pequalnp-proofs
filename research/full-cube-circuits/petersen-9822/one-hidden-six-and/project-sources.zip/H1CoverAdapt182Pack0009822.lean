import H1CoverAdapt182Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_182_1 : (stageRows 128 804 6292256 4 [2,3,1,4,5,6,10,7,9,11,8,12] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,10,7,9,11,8,12]) (ws:=[1128,2565,4628,1283,600])
    · exact clique_ok_182
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_182_2 : (stageRows 128 804 6292256 4 [2,3,1,5,6,10,7,9,11,8,12] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,10,7,9,11,8,12]) (ws:=[1128,2565,4628,1283,600])
    · exact clique_ok_182
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_182_3 : (stageRows 128 804 6292256 4 [2,3,1,4,6,10,7,9,11,8,12] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,10,7,9,11,8,12]) (ws:=[1128,2565,4628,1283,600])
    · exact clique_ok_182
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_182_5 : (stageRows 128 804 6292256 3 [3,1,6,10,7,9,11,8,12] [49,4]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,10,7,9,11,8,12]) (ws:=[1128,2565,4628,1283,600])
    · exact clique_ok_182
    · decide +kernel
    · decide +kernel
end Research.H1Cover
