import H1CoverAdapt012Data9822
import H1CoverAdapt012N0039822
import H1CoverAdapt012N0049822
import H1CoverAdapt012N0059822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_12_2 : (stageRows 192 544 100096 4 [1,6,2,3,4,7,11,12,8,10,9] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100096 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,6,2,5,3,4,7,11,12,8,10,9]) (ws:=[248,5154,2432,1128,4148])
    · exact clique_ok_12
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,6,2,5,3,4,7,11,12,8,10,9]) (ws:=[248,5154,2432,1128,4148])
    · exact clique_ok_12
    · decide +kernel
    · decide +kernel
  · exact adapt_12_3
  · exact adapt_12_4
  · exact adapt_12_5
end Research.H1Cover
