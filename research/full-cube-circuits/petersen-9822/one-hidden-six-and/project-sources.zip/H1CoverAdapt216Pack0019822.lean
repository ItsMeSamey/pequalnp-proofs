import H1CoverAdapt216Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_4 : (stageRows 160 385 7213864 3 [2,5,7,10,11,3,9,8,12] [17,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_6 : (stageRows 160 385 7213864 2 [5,10,11,3,9,8,12] [17,134,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_7 : (stageRows 160 385 7213864 2 [5,10,11,3,9,8,12] [17,134,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_8 : (stageRows 160 385 7213864 2 [5,10,3,9,8,12] [17,134,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
end Research.H1Cover
