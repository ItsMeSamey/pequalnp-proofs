import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_168 : ([2433,4272,464,248,2059] : List Nat).all (cliqueValid 5842566 [0,3,4,5,6,1,2,8,11,12,7,9,10])=true := by decide +kernel
end Research.H1Cover
