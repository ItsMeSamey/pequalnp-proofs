import H1CoverAdapt168Data9822
import H1CoverAdapt168Pack0019822
import H1CoverAdapt168Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_168_9 : (stageRows 208 528 5842566 3 [4,6,1,2,11,7,9,10] [33,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,8,11,12,7,9,10]) (ws:=[2433,4272,464,248,2059])
    · exact clique_ok_168
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_168_7 : (stageRows 208 528 5842566 4 [3,4,6,1,2,8,11,12,7,9,10] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5842566 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,6,1,2,8,11,12,7,9,10]) (ws:=[2433,4272,464,248,2059])
    · exact clique_ok_168
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,6,1,2,8,11,12,7,9,10]) (ws:=[2433,4272,464,248,2059])
    · exact clique_ok_168
    · decide +kernel
    · decide +kernel
  · exact adapt_168_8
  · apply debitBound (order:=[0,3,4,5,6,1,2,8,11,12,7,9,10]) (ws:=[2433,4272,464,248,2059])
    · exact clique_ok_168
    · decide +kernel
    · decide +kernel
  · exact adapt_168_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_168_0 : (stageRows 208 528 5842566 5 [0,3,4,5,6,1,2,8,11,12,7,9,10] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5842566 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,6,1,2,8,11,12,7,9,10]) (ws:=[2433,4272,464,248,2059])
    · exact clique_ok_168
    · decide +kernel
    · decide +kernel
  · exact adapt_168_1
  · exact adapt_168_7
end Research.H1Cover
