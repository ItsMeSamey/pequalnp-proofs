import H1CoverAdapt207Data9822
import H1CoverAdapt207Pack0009822
import H1CoverAdapt207Pack0019822
import H1CoverAdapt207Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_3 : (stageRows 130 132 7209761 4 [3,4,6,0,10,11,12,5,8,9] [134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7209761 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_207_4
  · exact adapt_207_5
  · exact adapt_207_6
  · exact adapt_207_7
  · exact adapt_207_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_0 : (stageRows 130 132 7209761 5 [1,2,3,4,6,0,7,10,11,12,5,8,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7209761 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
  · exact adapt_207_1
  · exact adapt_207_2
  · exact adapt_207_3
end Research.H1Cover
