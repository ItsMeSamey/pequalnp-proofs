import H1CoverAdapt128Data9822
import H1CoverAdapt128Pack0009822
import H1CoverAdapt128Pack0019822
import H1CoverAdapt128Pack0039822
import H1CoverAdapt128Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_128_0 : (stageRows 80 514 4203664 5 [0,3,5,6,1,2,8,12,4,9,11,7,10] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4203664 (some 0)).all ([1,17,33,1041] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · exact adapt_128_1
  · exact adapt_128_2
  · exact adapt_128_3
  · exact adapt_128_10
end Research.H1Cover
