import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_120 : ([5156,1283,2309,4609,1349] : List Nat).all (cliqueValid 2491014 [0,4,6,3,1,2,5,10,11,12,8,9,7])=true := by decide +kernel
end Research.H1Cover
