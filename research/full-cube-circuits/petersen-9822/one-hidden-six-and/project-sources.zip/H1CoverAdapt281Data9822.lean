import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_281 : ([1128,2433,5154,1349,2059] : List Nat).all (cliqueValid 100663936 [0,2,4,5,1,6,3,10,11,7,12,8,9])=true := by decide +kernel
end Research.H1Cover
