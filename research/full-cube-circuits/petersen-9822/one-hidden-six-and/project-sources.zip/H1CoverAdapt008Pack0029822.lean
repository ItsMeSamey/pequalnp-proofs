import H1CoverAdapt008Data9822
import H1CoverAdapt008Pack0009822
import H1CoverAdapt008Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_2 : (stageRows 40 272 77890 4 [5,2,3,9,10,11,1,7,8,12,6] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 77890 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · exact adapt_8_3
  · exact adapt_8_4
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_11 : (stageRows 40 272 77890 3 [2,3,9,10,1,7,8,12,6] [33,2064]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_13 : (stageRows 40 272 77890 2 [3,9,7,8,12,6] [33,3088,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_14 : (stageRows 40 272 77890 2 [9,1,7,8,12,6] [33,3088,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
end Research.H1Cover
