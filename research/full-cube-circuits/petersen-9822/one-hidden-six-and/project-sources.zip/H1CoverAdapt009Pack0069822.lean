import H1CoverAdapt009Data9822
import H1CoverAdapt009Pack0009822
import H1CoverAdapt009Pack0019822
import H1CoverAdapt009Pack0029822
import H1CoverAdapt009Pack0059822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_4 : (stageRows 32 401 78088 3 [6,1,2,3,10,11,12,7] [17,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 78088 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_9_5
  · exact adapt_9_6
  · exact adapt_9_7
  · exact adapt_9_8
  · exact adapt_9_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_2 : (stageRows 32 401 78088 4 [5,6,1,8,9,2,3,10,11,12,7] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 78088 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_9
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_9
    · decide +kernel
    · decide +kernel
  · exact adapt_9_3
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_9
    · decide +kernel
    · decide +kernel
  · exact adapt_9_4
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_12 : (stageRows 32 401 78088 4 [4,6,1,8,9,2,3,10,11,12,7] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_9
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_0 : (stageRows 32 401 78088 5 [0,4,5,6,1,8,9,2,3,10,11,12,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 78088 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_9_1
  · exact adapt_9_2
  · exact adapt_9_12
end Research.H1Cover
