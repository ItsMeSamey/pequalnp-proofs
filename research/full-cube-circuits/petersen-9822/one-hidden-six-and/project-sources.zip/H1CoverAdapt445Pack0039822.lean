import H1CoverAdapt445Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_445_11 : (stageRows 68 770 353373201 2 [6,5,12,9] [3089,134,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,8,12,4,9,10,11]) (ws:=[5156,464,1348,232,2432])
    · exact clique_ok_445
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_445_12 : (stageRows 68 770 353373201 2 [6,5,8,9] [3089,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,8,12,4,9,10,11]) (ws:=[5156,464,1348,232,2432])
    · exact clique_ok_445
    · decide +kernel
    · decide +kernel
end Research.H1Cover
