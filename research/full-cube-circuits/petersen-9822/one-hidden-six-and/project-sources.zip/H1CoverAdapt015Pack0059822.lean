import H1CoverAdapt015Data9822
import H1CoverAdapt015Pack0009822
import H1CoverAdapt015Pack0019822
import H1CoverAdapt015Pack0029822
import H1CoverAdapt015Pack0039822
import H1CoverAdapt015Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_15_9 : (stageRows 64 802 101392 3 [6,3,9,10,8,11,12] [49,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 101392 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_15_10
  · exact adapt_15_11
  · exact adapt_15_12
  · exact adapt_15_13
  · exact adapt_15_14
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_15_4 : (stageRows 64 802 101392 4 [1,6,2,3,9,7,10,8,11,12] [49]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 101392 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_15_5
  · exact adapt_15_6
  · exact adapt_15_7
  · exact adapt_15_8
  · exact adapt_15_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_15_0 : (stageRows 64 802 101392 5 [0,1,6,2,4,5,3,9,7,10,8,11,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 101392 (some 0)).all ([1,17,33,49] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · exact adapt_15_1
  · exact adapt_15_2
  · exact adapt_15_3
  · exact adapt_15_4
end Research.H1Cover
