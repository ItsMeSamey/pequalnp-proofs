import H1CoverAdapt198Data9822
import H1CoverAdapt198Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_9 : (stageRows 192 770 6426128 1 [4,9,10] [33,134,4360,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_10 : (stageRows 192 770 6426128 1 [4,11,9,10] [33,134,4360,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_11 : (stageRows 192 770 6426128 1 [4,9,10] [33,134,4360,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_6 : (stageRows 192 770 6426128 2 [6,4,11,9,10] [33,134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6426128 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_198_7
  · exact adapt_198_8
  · exact adapt_198_9
  · exact adapt_198_10
  · exact adapt_198_11
end Research.H1Cover
