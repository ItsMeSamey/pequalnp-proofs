import H1CoverAdapt485Data9822
import H1CoverAdapt485N0039822
import H1CoverAdapt485N0049822
import H1CoverAdapt485N0059822
import H1CoverAdapt485N0069822
import H1CoverAdapt485N0079822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_485_2 : (stageRows 272 521 404750534 4 [5,3,8,9,2,10,6,11,12,7,1] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 404750534 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_485_3
  · exact adapt_485_4
  · exact adapt_485_5
  · exact adapt_485_6
  · exact adapt_485_7
end Research.H1Cover
