import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_279 : ([2571,1128,4611,2433,4225] : List Nat).all (cliqueValid 100663436 [0,4,5,1,6,11,3,8,9,10,12,7,2])=true := by decide +kernel
end Research.H1Cover
