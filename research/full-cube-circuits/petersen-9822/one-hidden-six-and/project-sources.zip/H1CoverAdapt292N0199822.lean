import H1CoverAdapt292Data9822
import H1CoverAdapt292N0209822
import H1CoverAdapt292N0219822
import H1CoverAdapt292N0229822
import H1CoverAdapt292N0239822
import H1CoverAdapt292N0249822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_292_19 : (stageRows 48 521 100696206 4 [4,6,10,11,1,9,3,8,12,7,2] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100696206 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_292_20
  · exact adapt_292_21
  · exact adapt_292_22
  · exact adapt_292_23
  · exact adapt_292_24
end Research.H1Cover
