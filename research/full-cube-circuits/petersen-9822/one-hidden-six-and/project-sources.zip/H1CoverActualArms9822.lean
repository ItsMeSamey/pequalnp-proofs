import H1CoverBound9822
namespace Research.H1Cover
open Research.Graph9822H2Check (rawNeg negative)
theorem hiddenSymm (a b : Nat) : hiddenSig b a=hiddenSig a b := by
  simp only [hiddenSig,Nat.and_comm]
theorem nonemptyArms {a b : Nat} (leak : negative (hiddenSig a b)≠0) : 0<a ∧ 0<b := by
  have none : rawNeg 0=0 := by decide +kernel
  rw [getNeg] at leak
  constructor
  · by_contra! zero
    have eq : a=0 := by omega
    simp [eq,none] at leak
  · by_contra! zero
    have eq : b=0 := by omega
    simp [eq,none] at leak
end Research.H1Cover
