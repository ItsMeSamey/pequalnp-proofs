import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_8 : ([2571,2433,1283,4225,577] : List Nat).all (cliqueValid 77890 [0,4,5,2,3,9,10,11,1,7,8,12,6])=true := by decide +kernel
end Research.H1Cover
