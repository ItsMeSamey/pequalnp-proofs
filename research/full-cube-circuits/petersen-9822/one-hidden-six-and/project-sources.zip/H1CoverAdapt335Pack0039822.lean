import H1CoverAdapt335Data9822
import H1CoverAdapt335Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_335_0 : (stageRows 104 768 125836352 5 [0,2,3,4,5,1,6,8,7,9,12,10,11] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 125836352 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · apply debitBound (order:=[0,2,3,4,5,1,6,8,7,9,12,10,11]) (ws:=[600,1283,248,4225,385])
    · exact clique_ok_335
    · decide +kernel
    · decide +kernel
  · exact adapt_335_1
  · exact adapt_335_10
end Research.H1Cover
