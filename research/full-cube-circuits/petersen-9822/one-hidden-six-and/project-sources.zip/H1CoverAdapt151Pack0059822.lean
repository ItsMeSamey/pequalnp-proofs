import H1CoverAdapt151Data9822
import H1CoverAdapt151Pack0009822
import H1CoverAdapt151Pack0019822
import H1CoverAdapt151Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_3 : (stageRows 56 256 5247040 4 [3,4,2,10,11,1,6,8,9,12,7] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5247040 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_151_4
  · exact adapt_151_5
  · exact adapt_151_6
  · exact adapt_151_7
  · exact adapt_151_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_0 : (stageRows 56 256 5247040 5 [0,3,4,5,2,10,11,1,6,8,9,12,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5247040 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_151_1
  · exact adapt_151_2
  · exact adapt_151_3
end Research.H1Cover
