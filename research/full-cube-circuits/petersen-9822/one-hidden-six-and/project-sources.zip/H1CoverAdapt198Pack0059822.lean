import H1CoverAdapt198Data9822
import H1CoverAdapt198Pack0009822
import H1CoverAdapt198Pack0039822
import H1CoverAdapt198Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_20 : (stageRows 192 770 6426128 2 [6,5,9] [3089,134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_15 : (stageRows 192 770 6426128 3 [3,6,5,12,8,9] [3089,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6426128 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_198_16
  · exact adapt_198_17
  · exact adapt_198_18
  · exact adapt_198_19
  · exact adapt_198_20
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_12 : (stageRows 192 770 6426128 4 [1,2,3,6,5,7,12,8,9] [3089]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6426128 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
  · exact adapt_198_13
  · exact adapt_198_14
  · exact adapt_198_15
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_0 : (stageRows 192 770 6426128 5 [0,1,2,3,6,5,7,4,12,8,11,9,10] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6426128 (some 0)).all ([1,17,33,3089] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
  · exact adapt_198_1
  · exact adapt_198_2
  · exact adapt_198_12
end Research.H1Cover
