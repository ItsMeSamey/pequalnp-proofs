import H1CoverAdapt187Data9822
import H1CoverAdapt187Pack0009822
import H1CoverAdapt187Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_187_9 : (stageRows 2 132 6422529 2 [6,0,11,5,9] [134,4360,1040]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_187
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_187_10 : (stageRows 2 132 6422529 2 [6,0,5,9] [134,4360,3088]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_187
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_187_8 : (stageRows 2 132 6422529 3 [4,6,0,10,11,5,9] [134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6422529 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_187
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_187
    · decide +kernel
    · decide +kernel
  · exact adapt_187_9
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_187
    · decide +kernel
    · decide +kernel
  · exact adapt_187_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_187_3 : (stageRows 2 132 6422529 4 [3,4,6,0,10,11,12,5,8,9] [134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6422529 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_187_4
  · exact adapt_187_5
  · exact adapt_187_6
  · exact adapt_187_7
  · exact adapt_187_8
end Research.H1Cover
