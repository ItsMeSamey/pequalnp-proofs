import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_13 : ([1349,600,5156,2563,1128] : List Nat).all (cliqueValid 100368 [0,1,2,6,4,5,3,7,9,10,8,11,12])=true := by decide +kernel
end Research.H1Cover
