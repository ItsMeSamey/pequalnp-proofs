import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_308 : ([1349,2433,1058,5123,216] : List Nat).all (cliqueValid 100774696 [0,1,2,4,6,3,7,10,11,5,12,8,9])=true := by decide +kernel
end Research.H1Cover
