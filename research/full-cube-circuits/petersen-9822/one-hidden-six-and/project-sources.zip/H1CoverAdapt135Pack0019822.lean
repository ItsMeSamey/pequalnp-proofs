import H1CoverAdapt135Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_6 : (stageRows 128 564 4719392 3 [4,6,1,2,10,11,8,7,9] [33,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_8 : (stageRows 128 564 4719392 2 [6,1,2,11,7,9] [33,4360,1040]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_10 : (stageRows 128 564 4719392 1 [1,2,7,9] [33,4360,3088,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
end Research.H1Cover
