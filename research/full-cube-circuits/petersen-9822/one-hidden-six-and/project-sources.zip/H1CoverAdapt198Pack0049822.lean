import H1CoverAdapt198Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_16 : (stageRows 192 770 6426128 2 [6,5,12,8,9] [3089,134,8]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_17 : (stageRows 192 770 6426128 2 [6,5,12,8,9] [3089,134,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_18 : (stageRows 192 770 6426128 2 [6,5,12,9] [3089,134,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_19 : (stageRows 192 770 6426128 2 [6,5,8,9] [3089,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
end Research.H1Cover
