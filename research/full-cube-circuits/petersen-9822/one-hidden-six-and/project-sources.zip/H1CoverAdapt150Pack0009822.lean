import H1CoverAdapt150Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_1 : (stageRows 48 257 5246988 4 [4,5,1,6,10,8,9,2,7,11,12,3] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_3 : (stageRows 48 257 5246988 3 [1,6,10,9,2,7,11,12,3] [17,288]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_5 : (stageRows 48 257 5246988 2 [6,10,7,11,12,3] [17,800,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
end Research.H1Cover
