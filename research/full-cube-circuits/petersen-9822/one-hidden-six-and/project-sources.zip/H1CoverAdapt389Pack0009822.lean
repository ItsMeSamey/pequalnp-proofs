import H1CoverAdapt389Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_389_1 : (stageRows 130 516 176161313 4 [1,2,3,6,4,8,11,12,7,10,5,9] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_389_2 : (stageRows 130 516 176161313 4 [1,2,3,6,8,11,12,7,10,5,9] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_389_3 : (stageRows 130 516 176161313 4 [1,2,3,6,4,8,11,12,7,10,9] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,8,11,12,7,10,5,9]) (ws:=[1349,4628,2433,2570,216])
    · exact clique_ok_389
    · decide +kernel
    · decide +kernel
end Research.H1Cover
