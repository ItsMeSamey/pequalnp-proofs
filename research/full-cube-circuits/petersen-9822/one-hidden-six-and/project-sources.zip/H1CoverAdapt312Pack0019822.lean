import H1CoverAdapt312Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_3 : (stageRows 104 288 100776264 3 [5,3,7,9,10,6,8,11,12] [17,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_5 : (stageRows 104 288 100776264 2 [3,9,10,6,8,11,12] [17,134,32]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_6 : (stageRows 104 288 100776264 2 [3,9,10,6,8,11,12] [17,134,33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
end Research.H1Cover
