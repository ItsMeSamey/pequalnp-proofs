import H1CoverAdapt145Data9822
import H1CoverAdapt145Pack0009822
import H1CoverAdapt145Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_145_0 : (stageRows 24 256 5242944 5 [0,3,4,5,2,8,9,10,11,12,1,6,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5242944 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_145_1
  · exact adapt_145_2
  · exact adapt_145_3
end Research.H1Cover
