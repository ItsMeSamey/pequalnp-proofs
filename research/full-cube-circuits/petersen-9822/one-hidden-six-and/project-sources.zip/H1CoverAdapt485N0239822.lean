import H1CoverAdapt485Data9822
import H1CoverAdapt485N0249822
import H1CoverAdapt485N0259822
import H1CoverAdapt485N0269822
import H1CoverAdapt485N0279822
import H1CoverAdapt485N0289822
import H1CoverAdapt485N0299822
import H1CoverAdapt485N0309822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_485_23 : (stageRows 272 521 404750534 2 [9,2,6,7,1] [33,3088,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 404750534 (some 9)).all ([512,544,640,768,800,1536,1664] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_485_24
  · exact adapt_485_25
  · exact adapt_485_26
  · exact adapt_485_27
  · exact adapt_485_28
  · exact adapt_485_29
  · exact adapt_485_30
end Research.H1Cover
