import H1CoverAdapt150Data9822
import H1CoverAdapt150Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_16 : (stageRows 48 257 5246988 2 [6,8,9,12,3] [33,3088,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_17 : (stageRows 48 257 5246988 2 [6,8,9,12] [33,3088,142]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_12 : (stageRows 48 257 5246988 3 [1,6,8,9,2,7,12,3] [33,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5246988 (some 1)).all ([2,6,14,66,130,134,142] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
  · exact adapt_150_13
  · exact adapt_150_14
  · exact adapt_150_15
  · apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
  · exact adapt_150_16
  · exact adapt_150_17
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_150_10 : (stageRows 48 257 5246988 4 [4,1,6,10,8,9,2,7,11,12,3] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5246988 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
  · exact adapt_150_11
  · apply debitBound (order:=[0,4,5,1,6,10,8,9,2,7,11,12,3]) (ws:=[1349,2433,2565,4225,1033])
    · exact clique_ok_150
    · decide +kernel
    · decide +kernel
  · exact adapt_150_12
end Research.H1Cover
