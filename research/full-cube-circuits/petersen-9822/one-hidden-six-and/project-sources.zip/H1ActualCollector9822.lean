import H1ScopeClip9822
namespace Research.H1Price
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet.CircuitCompiler

/-- Backward traversal through the cut's original OR readers. An exposed AND
remains in the frontier as a terminal. The trace explicitly records every
retired OR by original output address. -/
def discover : Nat → List Gate → Finset Nat → Finset Nat × List Nat
  | _, [], front => (front, [])
  | k, g::gs, front =>
    let (later, used) := discover (k+1) gs front
    if k ∈ later ∧ orFlag g = true then
      (insert (g.inputs.getD 0 k) (insert (g.inputs.getD 1 k) (later.erase k)), k::used)
    else (later, used)

theorem discover_growth (k : Nat) (gs : List Gate) (front : Finset Nat) :
    (discover k gs front).1.card ≤ front.card + (discover k gs front).2.length := by
  induction gs generalizing k with
  | nil => simp [discover]
  | cons g gs ih =>
    simp only [discover]
    split
    next h =>
      have he := Finset.card_erase_of_mem h.1
      have h1 := Finset.card_insert_le (g.inputs.getD 1 k) ((discover (k+1) gs front).1.erase k)
      have h2 := Finset.card_insert_le (g.inputs.getD 0 k)
        (insert (g.inputs.getD 1 k) ((discover (k+1) gs front).1.erase k))
      have pos := Finset.card_pos.mpr ⟨k,h.1⟩
      have h3 := ih (k+1)
      simp only [List.length_cons]
      omega
    next => exact ih (k+1)

theorem discover_saved (gs : List Gate) (k : Nat) (front : Finset Nat) (erase : Nat → Bool)
    (marked : ∀ j ∈ (discover k gs front).2, erase j = true) :
    (discover k gs front).2.length ≤ saved erase k gs := by
  induction gs generalizing k with
  | nil => simp [discover,saved]
  | cons g gs ih =>
    simp only [discover] at marked ⊢
    by_cases h : k ∈ (discover (k+1) gs front).1 ∧ orFlag g = true
    · simp only [if_pos h] at marked ⊢
     
      have mark := marked k List.mem_cons_self
      have step := ih (k+1) (fun j hj => marked j (List.mem_cons_of_mem _ hj))
      simp [saved,mark,h.2] <;> omega
    · simp only [if_neg h] at marked ⊢
      have step := ih (k+1) marked
      simp only [saved]
      omega

theorem four_original_collectors (gs : List Gate) (out : Nat)
    (exposed : 5 ≤ (discover 10 gs {out}).1.card) :
    4 ≤ saved (fun k => decide (k ∈ (discover 10 gs {out}).2)) 10 gs := by
  have g := discover_growth 10 gs {out}
  have s := discover_saved gs 10 {out} (fun k => decide (k ∈ (discover 10 gs {out}).2))
    (by simp)
  simp only [Finset.card_singleton] at g
  omega
end Research.H1Price
#print axioms Research.H1Price.four_original_collectors
