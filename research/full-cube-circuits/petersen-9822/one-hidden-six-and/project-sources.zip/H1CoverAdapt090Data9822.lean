import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_90 : ([2571,449,2216,1283,581] : List Nat).all (cliqueValid 908368 [0,1,2,3,5,4,7,8,9,6,10,11,12])=true := by decide +kernel
end Research.H1Cover
