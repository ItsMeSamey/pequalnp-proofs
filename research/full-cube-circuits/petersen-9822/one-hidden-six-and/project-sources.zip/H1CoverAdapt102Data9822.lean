import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_102 : ([2571,4272,600,5156,4628] : List Nat).all (cliqueValid 1114145 [0,1,2,6,3,4,5,7,9,11,12,8,10])=true := by decide +kernel
end Research.H1Cover
