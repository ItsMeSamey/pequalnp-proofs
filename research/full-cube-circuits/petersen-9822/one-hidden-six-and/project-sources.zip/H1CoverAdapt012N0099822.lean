import H1CoverAdapt012Data9822
import H1CoverAdapt012N0109822
import H1CoverAdapt012N0119822
import H1CoverAdapt012N0129822
import H1CoverAdapt012N0139822
import H1CoverAdapt012N0149822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_12_9 : (stageRows 192 544 100096 3 [6,3,4,11,12,10] [801,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100096 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_12_10
  · exact adapt_12_11
  · exact adapt_12_12
  · exact adapt_12_13
  · exact adapt_12_14
end Research.H1Cover
