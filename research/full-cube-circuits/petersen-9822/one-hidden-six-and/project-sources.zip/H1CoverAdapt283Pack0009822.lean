import H1CoverAdapt283Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_283_1 : (stageRows 240 512 100664960 4 [2,4,5,1,6,3,10,11,7,12,8,9] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_283
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_283_2 : (stageRows 240 512 100664960 4 [2,5,1,6,3,10,11,7,12,8,9] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_283
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_283_4 : (stageRows 240 512 100664960 3 [4,1,6,3,10,11,7,12,8,9] [33,4]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_283
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_283_5 : (stageRows 240 512 100664960 3 [4,6,3,10,11,7,12,8,9] [33,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_283
    · decide +kernel
    · decide +kernel
end Research.H1Cover
