import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_445 : ([5156,464,1348,232,2432] : List Nat).all (cliqueValid 353373201 [0,1,2,3,6,5,7,8,12,4,9,10,11])=true := by decide +kernel
end Research.H1Cover
