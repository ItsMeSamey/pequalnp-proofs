import H1CoverAdapt207Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_9 : (stageRows 130 132 7209761 2 [6,0,11,5,9] [134,4360,1040]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_11 : (stageRows 130 132 7209761 1 [0,5,9] [134,4360,3088,64]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_12 : (stageRows 130 132 7209761 1 [0,5,9] [134,4360,3088,66]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_13 : (stageRows 130 132 7209761 1 [0,5,9] [134,4360,3088,2112]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
end Research.H1Cover
