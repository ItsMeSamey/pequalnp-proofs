import H1CoverAdapt485Data9822
import H1CoverAdapt485N0209822
import H1CoverAdapt485N0219822
import H1CoverAdapt485N0229822
import H1CoverAdapt485N0239822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_485_19 : (stageRows 272 521 404750534 3 [3,8,9,2,6,12,7,1] [33,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 404750534 (some 3)).all ([8,12,142,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,3,8,9,2,10,6,11,12,7,1]) (ws:=[1345,2565,4225,4613,1128])
    · exact clique_ok_485
    · decide +kernel
    · decide +kernel
  · exact adapt_485_20
  · exact adapt_485_21
  · apply debitBound (order:=[0,4,5,3,8,9,2,10,6,11,12,7,1]) (ws:=[1345,2565,4225,4613,1128])
    · exact clique_ok_485
    · decide +kernel
    · decide +kernel
  · exact adapt_485_22
  · exact adapt_485_23
end Research.H1Cover
