import H1CoverAdapt282Data9822
import H1CoverAdapt282Pack0009822
import H1CoverAdapt282Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_282_0 : (stageRows 224 512 100664832 5 [0,1,2,4,5,6,3,7,10,11,12,8,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100664832 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
  · exact adapt_282_1
  · exact adapt_282_2
end Research.H1Cover
