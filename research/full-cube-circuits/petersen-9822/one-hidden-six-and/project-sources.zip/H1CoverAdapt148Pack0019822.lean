import H1CoverAdapt148Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_4 : (stageRows 88 256 5244992 3 [4,2,8,9,10,11,1,6,7] [33,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_6 : (stageRows 88 256 5244992 2 [2,9,10,1,6,7] [33,4360,2064]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_8 : (stageRows 88 256 5244992 1 [9,6,7] [33,4360,3088,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
end Research.H1Cover
