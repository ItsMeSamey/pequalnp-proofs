import H1CoverAdapt102Data9822
import H1CoverAdapt102Pack0009822
import H1CoverAdapt102Pack0019822
import H1CoverAdapt102Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_9 : (stageRows 4 146 1114145 3 [6,3,5,9,11,12,8] [1041,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 1114145 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
  · exact adapt_102_10
  · apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
  · exact adapt_102_11
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_4 : (stageRows 4 146 1114145 4 [1,2,6,3,5,7,9,11,12,8] [1041]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 1114145 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_102_5
  · exact adapt_102_6
  · exact adapt_102_7
  · exact adapt_102_8
  · exact adapt_102_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_0 : (stageRows 4 146 1114145 5 [0,1,2,6,3,4,5,7,9,11,12,8,10] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 1114145 (some 0)).all ([1,17,33,1041] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · exact adapt_102_1
  · exact adapt_102_2
  · exact adapt_102_3
  · exact adapt_102_4
end Research.H1Cover
