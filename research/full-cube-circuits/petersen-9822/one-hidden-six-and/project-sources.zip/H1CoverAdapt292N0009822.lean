import H1CoverAdapt292Data9822
import H1CoverAdapt292N0019822
import H1CoverAdapt292N0029822
import H1CoverAdapt292N0199822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_292_0 : (stageRows 48 521 100696206 5 [0,4,5,6,10,11,1,9,3,8,12,7,2] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100696206 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_292_1
  · exact adapt_292_2
  · exact adapt_292_19
end Research.H1Cover
