import H1CoverAdapt216Data9822
import H1CoverAdapt216Pack0009822
import H1CoverAdapt216Pack0029822
import H1CoverAdapt216Pack0039822
import H1CoverAdapt216Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_15 : (stageRows 160 385 7213864 2 [6,3,9,8,12] [33,134,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7213864 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_216_16
  · exact adapt_216_17
  · exact adapt_216_18
  · exact adapt_216_19
  · exact adapt_216_20
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_13 : (stageRows 160 385 7213864 3 [4,6,10,11,3,9,8,12] [33,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7213864 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
  · exact adapt_216_14
  · apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
  · exact adapt_216_15
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_11 : (stageRows 160 385 7213864 4 [1,2,4,6,7,10,11,3,9,8,12] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7213864 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
  · exact adapt_216_12
  · apply debitBound (order:=[0,1,2,4,6,5,7,10,11,3,9,8,12]) (ws:=[1349,2185,464,2563,1035])
    · exact clique_ok_216
    · decide +kernel
    · decide +kernel
  · exact adapt_216_13
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_216_0 : (stageRows 160 385 7213864 5 [0,1,2,4,6,5,7,10,11,3,9,8,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 7213864 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_216_1
  · exact adapt_216_2
  · exact adapt_216_11
end Research.H1Cover
