import H1CoverAdapt474Data9822
import H1CoverAdapt474Pack0009822
import H1CoverAdapt474Pack0019822
import H1CoverAdapt474Pack0029822
import H1CoverAdapt474Pack0039822
import H1CoverAdapt474Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_474_15 : (stageRows 464 512 402654848 1 [6,10,11] [17,134,800,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_474
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_474_9 : (stageRows 464 512 402654848 2 [3,6,12,10,11] [17,134,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 402654848 (some 3)).all ([8,12,140,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_474_10
  · exact adapt_474_11
  · exact adapt_474_12
  · exact adapt_474_13
  · exact adapt_474_14
  · exact adapt_474_15
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_474_7 : (stageRows 464 512 402654848 3 [5,3,6,8,9,12,10,11] [17,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 402654848 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_474
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_474
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_474
    · decide +kernel
    · decide +kernel
  · exact adapt_474_8
  · exact adapt_474_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_474_2 : (stageRows 464 512 402654848 4 [1,5,2,3,6,8,9,7,12,10,11] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 402654848 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_474_3
  · exact adapt_474_4
  · exact adapt_474_5
  · exact adapt_474_6
  · exact adapt_474_7
end Research.H1Cover
