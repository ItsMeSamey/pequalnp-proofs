import H1CoverAdapt283Data9822
import H1CoverAdapt283Pack0009822
import H1CoverAdapt283Pack0059822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_283_0 : (stageRows 240 512 100664960 5 [0,2,4,5,1,6,3,10,11,7,12,8,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100664960 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_283_1
  · exact adapt_283_2
  · exact adapt_283_3
end Research.H1Cover
