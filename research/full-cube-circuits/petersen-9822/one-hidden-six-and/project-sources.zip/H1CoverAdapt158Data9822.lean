import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_158 : ([2565,1283,4225,5154,2433] : List Nat).all (cliqueValid 5771532 [0,4,5,6,1,10,11,9,2,7,8,12,3])=true := by decide +kernel
end Research.H1Cover
