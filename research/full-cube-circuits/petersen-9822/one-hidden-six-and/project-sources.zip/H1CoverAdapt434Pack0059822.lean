import H1CoverAdapt434Data9822
import H1CoverAdapt434Pack0009822
import H1CoverAdapt434Pack0019822
import H1CoverAdapt434Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_0 : (stageRows 68 514 352322577 5 [0,1,2,3,6,5,8,11,12,7,9,4,10] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 352322577 (some 0)).all ([1,17,33,49,1041] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_434_1
  · exact adapt_434_2
  · exact adapt_434_3
  · exact adapt_434_4
  · exact adapt_434_5
end Research.H1Cover
