import H1CoverAdapt188Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_188_1 : (stageRows 2 196 6422545 4 [2,3,0,4,7,10,5,11,12,8,9] [66]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,4,7,10,5,11,12,8,9]) (ws:=[5154,464,600,248,4225])
    · exact clique_ok_188
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_188_2 : (stageRows 2 196 6422545 4 [2,3,6,0,4,10,5,11,12,8,9] [130]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,4,7,10,5,11,12,8,9]) (ws:=[5154,464,600,248,4225])
    · exact clique_ok_188
    · decide +kernel
    · decide +kernel
end Research.H1Cover
