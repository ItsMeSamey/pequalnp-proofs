import H1CoverAdapt127Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_1 : (stageRows 2 84 4202513 4 [1,2,3,4,5,6,7,8,10,12,9,11] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_2 : (stageRows 2 84 4202513 4 [1,2,3,5,6,7,8,10,12,9,11] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_3 : (stageRows 2 84 4202513 4 [1,2,3,4,6,7,8,10,12,9,11] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_5 : (stageRows 2 84 4202513 3 [3,4,6,7,8,10,12,11] [545,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
end Research.H1Cover
