import H1CoverAdapt210Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_6 : (stageRows 130 196 7209777 3 [4,6,0,10,11,12,5,9] [134,264]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_7 : (stageRows 130 196 7209777 3 [4,6,0,10,11,5,8,9] [134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
end Research.H1Cover
