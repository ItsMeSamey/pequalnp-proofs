import H1CoverAdapt246Data9822
import H1CoverAdapt246Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_246_8 : (stageRows 36 130 33562913 3 [2,6,3,11,9,10,12,8] [49,130]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,3,7,11,9,10,12,5,8]) (ws:=[2571,4628,2432,600,224])
    · exact clique_ok_246
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_246_9 : (stageRows 36 130 33562913 3 [6,3,11,9,10,12,8] [49,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,3,7,11,9,10,12,5,8]) (ws:=[2571,4628,2432,600,224])
    · exact clique_ok_246
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_246_4 : (stageRows 36 130 33562913 4 [1,2,6,3,7,11,9,10,12,8] [49]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 33562913 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_246_5
  · exact adapt_246_6
  · exact adapt_246_7
  · exact adapt_246_8
  · exact adapt_246_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_246_10 : (stageRows 36 130 33562913 4 [1,2,6,4,3,7,11,9,10,12] [289]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,3,7,11,9,10,12,5,8]) (ws:=[2571,4628,2432,600,224])
    · exact clique_ok_246
    · decide +kernel
    · decide +kernel
end Research.H1Cover
