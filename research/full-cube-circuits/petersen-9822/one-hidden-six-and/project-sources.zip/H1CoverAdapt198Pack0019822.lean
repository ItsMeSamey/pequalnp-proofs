import H1CoverAdapt198Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_5 : (stageRows 192 770 6426128 2 [6,4,12,11,9,10] [33,134,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_7 : (stageRows 192 770 6426128 1 [4,11,9,10] [33,134,4360,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_8 : (stageRows 192 770 6426128 1 [4,11,9,10] [33,134,4360,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
end Research.H1Cover
