import H1CoverAdapt131Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_131_1 : (stageRows 48 129 4718860 4 [4,6,1,5,10,11,12,2,7,9,8,3] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_131_3 : (stageRows 48 129 4718860 3 [1,5,10,11,2,7,9,8,3] [17,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
end Research.H1Cover
