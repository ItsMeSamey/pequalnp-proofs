import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_61 : ([4626,2433,1283,2565,5123] : List Nat).all (cliqueValid 591938 [0,5,3,2,4,8,9,12,1,7,10,11,6])=true := by decide +kernel
end Research.H1Cover
