import H1CoverAdapt061Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_6 : (stageRows 72 272 591938 3 [3,2,8,12,1,7,10,11,6] [17,544]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_8 : (stageRows 72 272 591938 2 [2,1,7,10,11,6] [17,800,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_9 : (stageRows 72 272 591938 2 [2,1,7,10,11,6] [17,800,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
end Research.H1Cover
