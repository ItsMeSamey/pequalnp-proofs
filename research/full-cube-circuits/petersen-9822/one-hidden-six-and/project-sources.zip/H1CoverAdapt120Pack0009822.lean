import H1CoverAdapt120Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_120_1 : (stageRows 144 521 2491014 4 [4,6,3,1,2,5,10,11,12,8,9,7] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_120_2 : (stageRows 144 521 2491014 4 [6,3,1,2,5,10,11,12,8,9,7] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
end Research.H1Cover
