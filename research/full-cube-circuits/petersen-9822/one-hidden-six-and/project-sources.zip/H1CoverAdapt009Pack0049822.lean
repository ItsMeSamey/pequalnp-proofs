import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_11_f2_p0 : terminalCharge 32 401 78088 [17,800,6208,142,1152] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_11_f3_p0 : terminalCharge 32 401 78088 [17,800,6208,142,1536] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_11_f4_p0 : terminalCharge 32 401 78088 [17,800,6208,142,1664] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_11_f5_p0 : terminalCharge 32 401 78088 [17,800,6208,142,3072] []=true := by decide +kernel
end Research.H1Cover
