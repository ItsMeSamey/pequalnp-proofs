import H1CoverAdapt131Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_131_9 : (stageRows 48 129 4718860 3 [6,1,11,12,2,7,9,8,3] [33,1040]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_131_10 : (stageRows 48 129 4718860 3 [6,1,10,12,2,7,9,8,3] [33,2064]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_131_12 : (stageRows 48 129 4718860 2 [1,2,7,9,8,3] [33,3088,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,1,5,10,11,12,2,7,9,8,3]) (ws:=[5156,2433,2565,1283,4613])
    · exact clique_ok_131
    · decide +kernel
    · decide +kernel
end Research.H1Cover
