import H1CoverAdapt120Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_120_5 : (stageRows 144 521 2491014 2 [3,1,2,12,8,9,7] [33,1040,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_120_6 : (stageRows 144 521 2491014 2 [3,1,2,8,9,7] [33,1040,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_120_4 : (stageRows 144 521 2491014 3 [6,3,1,2,11,12,8,9,7] [33,1040]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 2491014 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
  · exact adapt_120_5
  · apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
  · exact adapt_120_6
end Research.H1Cover
