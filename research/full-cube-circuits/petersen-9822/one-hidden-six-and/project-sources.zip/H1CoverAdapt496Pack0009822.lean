import H1CoverAdapt496Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_496_1 : (stageRows 129 288 408944904 4 [1,2,4,5,6,7,9,10,3,11,8,12] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,6,7,9,10,3,11,8,12]) (ws:=[5156,538,2563,184,4628])
    · exact clique_ok_496
    · decide +kernel
    · decide +kernel
end Research.H1Cover
