import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_198 : ([248,4611,2432,340,2216] : List Nat).all (cliqueValid 6426128 [0,1,2,3,6,5,7,4,12,8,11,9,10])=true := by decide +kernel
end Research.H1Cover
