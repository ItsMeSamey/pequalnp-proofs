import H1CoverAdapt308Data9822
import H1CoverAdapt308Pack0009822
import H1CoverAdapt308Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_13 : (stageRows 160 548 100774696 4 [1,2,4,6,3,7,10,11,12,8,9] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_0 : (stageRows 160 548 100774696 5 [0,1,2,4,6,3,7,10,11,5,12,8,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100774696 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_308_1
  · exact adapt_308_2
  · exact adapt_308_13
end Research.H1Cover
