import H1CoverAdapt061Data9822
import H1CoverAdapt061Pack0009822
import H1CoverAdapt061Pack0019822
import H1CoverAdapt061Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_7 : (stageRows 72 272 591938 3 [3,2,12,1,7,10,11,6] [17,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 591938 (some 3)).all ([8,12,264,4104,4360,6216] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
  · exact adapt_61_8
  · exact adapt_61_9
  · exact adapt_61_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_2 : (stageRows 72 272 591938 4 [5,3,2,8,9,12,1,7,10,11,6] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 591938 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_61_3
  · exact adapt_61_4
  · exact adapt_61_5
  · exact adapt_61_6
  · exact adapt_61_7
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_12 : (stageRows 72 272 591938 3 [2,4,8,9,1,7,10,11,6] [33,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
end Research.H1Cover
