import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_37 : ([4628,1097,2571,2309,5123] : List Nat).all (cliqueValid 279684 [0,5,1,3,6,4,12,2,8,9,11,10,7])=true := by decide +kernel
end Research.H1Cover
