import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_210 : ([5154,248,2185,4272,1124] : List Nat).all (cliqueValid 7209777 [1,2,3,4,6,0,7,10,11,12,5,8,9])=true := by decide +kernel
end Research.H1Cover
