import H1CoverAdapt073Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_1 : (stageRows 128 612 787232 4 [1,2,3,5,6,7,8,12,11,9,10] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_3 : (stageRows 128 612 787232 3 [2,3,4,7,8,12,11,9,10] [33,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
end Research.H1Cover
