import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_25 : ([4626,2216,1128,248,4225] : List Nat).all (cliqueValid 114721 [1,2,3,6,0,5,7,9,4,8,12,10,11])=true := by decide +kernel
end Research.H1Cover
