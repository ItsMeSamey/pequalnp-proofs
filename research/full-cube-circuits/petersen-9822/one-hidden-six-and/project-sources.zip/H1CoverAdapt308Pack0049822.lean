import H1CoverAdapt308Data9822
import H1CoverAdapt308Pack0019822
import H1CoverAdapt308Pack0029822
import H1CoverAdapt308Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_12 : (stageRows 160 548 100774696 1 [10] [17,134,6208,4904]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_10 : (stageRows 160 548 100774696 2 [3,10,5,8,9] [17,134,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100774696 (some 3)).all ([8,12,264,808,4104,4360,4904] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
  · exact adapt_308_11
  · apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
  · exact adapt_308_12
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_5 : (stageRows 160 548 100774696 3 [6,3,10,11,5,12,8,9] [17,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100774696 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_308_6
  · exact adapt_308_7
  · exact adapt_308_8
  · exact adapt_308_9
  · exact adapt_308_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_2 : (stageRows 160 548 100774696 4 [1,2,6,3,7,10,11,5,12,8,9] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100774696 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
  · exact adapt_308_3
  · exact adapt_308_4
  · apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
  · exact adapt_308_5
end Research.H1Cover
