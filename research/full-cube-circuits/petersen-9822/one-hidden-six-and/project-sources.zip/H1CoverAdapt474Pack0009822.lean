import H1CoverAdapt474Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_474_1 : (stageRows 464 512 402654848 4 [1,4,5,2,3,6,8,9,7,12,10,11] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_474
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_474_3 : (stageRows 464 512 402654848 3 [5,2,3,6,8,9,7,12,10,11] [17,2]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_474
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_474_4 : (stageRows 464 512 402654848 3 [5,3,6,8,9,7,12,10,11] [17,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_474
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_474_5 : (stageRows 464 512 402654848 3 [5,2,3,8,9,7,12,10,11] [17,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_474
    · decide +kernel
    · decide +kernel
end Research.H1Cover
