import H1CoverAdapt135Data9822
import H1CoverAdapt135Pack0009822
import H1CoverAdapt135Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_135_0 : (stageRows 128 564 4719392 5 [0,3,4,5,6,1,2,10,11,8,12,7,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4719392 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,6,1,2,10,11,8,12,7,9]) (ws:=[5154,2433,1124,5125,248])
    · exact clique_ok_135
    · decide +kernel
    · decide +kernel
  · exact adapt_135_1
  · exact adapt_135_2
end Research.H1Cover
