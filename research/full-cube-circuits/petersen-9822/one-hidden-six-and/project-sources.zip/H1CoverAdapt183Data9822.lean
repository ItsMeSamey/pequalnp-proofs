import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_183 : ([464,600,4272,248,2090] : List Nat).all (cliqueValid 6295040 [0,2,3,1,4,5,6,7,8,12,9,11,10])=true := by decide +kernel
end Research.H1Cover
