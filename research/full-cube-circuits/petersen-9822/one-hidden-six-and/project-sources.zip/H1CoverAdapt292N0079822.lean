import H1CoverAdapt292Data9822
import H1CoverAdapt292N0089822
import H1CoverAdapt292N0099822
import H1CoverAdapt292N0109822
import H1CoverAdapt292N0119822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_292_7 : (stageRows 48 521 100696206 3 [6,10,11,1,3,12,7,2] [17,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100696206 (some 6)).all ([64,66,198,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,6,10,11,1,9,3,8,12,7,2]) (ws:=[2569,1283,4225,5154,4609])
    · exact clique_ok_292
    · decide +kernel
    · decide +kernel
  · exact adapt_292_8
  · exact adapt_292_9
  · apply debitBound (order:=[0,4,5,6,10,11,1,9,3,8,12,7,2]) (ws:=[2569,1283,4225,5154,4609])
    · exact clique_ok_292
    · decide +kernel
    · decide +kernel
  · exact adapt_292_10
  · exact adapt_292_11
end Research.H1Cover
