import H1CoverAdapt187Data9822
import H1CoverAdapt187Pack0009822
import H1CoverAdapt187Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_187_0 : (stageRows 2 132 6422529 5 [1,2,3,4,6,0,7,10,11,12,5,8,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6422529 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_187
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_187
    · decide +kernel
    · decide +kernel
  · exact adapt_187_1
  · exact adapt_187_2
  · exact adapt_187_3
end Research.H1Cover
