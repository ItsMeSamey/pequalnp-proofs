import H1CoverAdapt396Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_396_4 : (stageRows 130 548 176169761 4 [1,2,3,6,7,11,12,10,8,9] [49]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,11,12,5,10,8,9]) (ws:=[4628,2216,464,2570,600])
    · exact clique_ok_396
    · decide +kernel
    · decide +kernel
end Research.H1Cover
