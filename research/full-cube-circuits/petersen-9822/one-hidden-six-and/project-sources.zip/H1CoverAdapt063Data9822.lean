import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_63 : ([4613,2433,523,248,4611] : List Nat).all (cliqueValid 592912 [0,4,5,6,3,1,2,8,9,11,12,7,10])=true := by decide +kernel
end Research.H1Cover
