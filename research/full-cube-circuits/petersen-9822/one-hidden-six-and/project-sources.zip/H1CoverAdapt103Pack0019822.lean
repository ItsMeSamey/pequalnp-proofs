import H1CoverAdapt103Data9822
import H1CoverAdapt103Pack0009822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_103_7 : (stageRows 144 516 1114784 1 [10] [17,6208,808,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_103_8 : (stageRows 144 516 1114784 1 [10] [17,6208,808,646]).all fixedPrice=true := by
    apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_103_5 : (stageRows 144 516 1114784 2 [1,2,10,7] [17,6208,808]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 1114784 (some 1)).all ([2,6,66,130,134,642,646] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · exact adapt_103_6
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · exact adapt_103_7
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · exact adapt_103_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_103_4 : (stageRows 144 516 1114784 3 [3,1,2,5,8,10,7,9] [17,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 1114784 (some 3)).all ([8,12,264,808,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · exact adapt_103_5
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
end Research.H1Cover
