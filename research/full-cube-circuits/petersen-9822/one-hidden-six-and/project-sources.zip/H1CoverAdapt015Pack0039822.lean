import H1CoverAdapt015Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_15_12 : (stageRows 64 802 101392 2 [3,9,10,8,12] [49,134,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,6,2,4,5,3,9,7,10,8,11,12]) (ws:=[600,1283,5154,2565,1128])
    · exact clique_ok_15
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_15_13 : (stageRows 64 802 101392 2 [3,9,10,8,11] [49,134,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,6,2,4,5,3,9,7,10,8,11,12]) (ws:=[600,1283,5154,2565,1128])
    · exact clique_ok_15
    · decide +kernel
    · decide +kernel
end Research.H1Cover
