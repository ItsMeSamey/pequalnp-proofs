import H1CoverAdapt485Data9822
import H1CoverAdapt485N0159822
import H1CoverAdapt485N0169822
import H1CoverAdapt485N0179822
import H1CoverAdapt485N0189822
import H1CoverAdapt485N0199822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_485_14 : (stageRows 272 521 404750534 4 [4,3,8,9,2,10,6,11,12,7,1] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 404750534 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_485_15
  · exact adapt_485_16
  · exact adapt_485_17
  · exact adapt_485_18
  · exact adapt_485_19
end Research.H1Cover
