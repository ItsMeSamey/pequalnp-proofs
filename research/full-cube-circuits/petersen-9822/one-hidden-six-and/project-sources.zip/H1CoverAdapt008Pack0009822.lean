import H1CoverAdapt008Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_1 : (stageRows 40 272 77890 4 [4,5,2,3,9,10,11,1,7,8,12,6] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_3 : (stageRows 40 272 77890 3 [2,3,10,11,1,7,8,12,6] [17,544]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_5 : (stageRows 40 272 77890 2 [3,10,11,7,12,6] [17,800,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_6 : (stageRows 40 272 77890 2 [10,11,1,7,12,6] [17,800,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
end Research.H1Cover
