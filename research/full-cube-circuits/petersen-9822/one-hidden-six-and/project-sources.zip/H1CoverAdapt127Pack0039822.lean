import H1CoverAdapt127Data9822
import H1CoverAdapt127Pack0009822
import H1CoverAdapt127Pack0019822
import H1CoverAdapt127Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_12 : (stageRows 2 84 4202513 1 [6] [545,134,4360,3088]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_9 : (stageRows 2 84 4202513 2 [4,6,10,11] [545,134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4202513 (some 4)).all ([16,17,1040,2064,2128,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
  · exact adapt_127_10
  · apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
  · exact adapt_127_11
  · exact adapt_127_12
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_7 : (stageRows 2 84 4202513 3 [3,4,6,8,10,12,11] [545,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4202513 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
  · exact adapt_127_8
  · apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
  · exact adapt_127_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_4 : (stageRows 2 84 4202513 4 [1,2,3,4,6,7,8,10,12,11] [545]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4202513 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
  · exact adapt_127_5
  · exact adapt_127_6
  · apply debitBound (order:=[0,1,2,3,4,5,6,7,8,10,12,9,11]) (ws:=[1349,4272,1128,4628,201])
    · exact clique_ok_127
    · decide +kernel
    · decide +kernel
  · exact adapt_127_7
end Research.H1Cover
