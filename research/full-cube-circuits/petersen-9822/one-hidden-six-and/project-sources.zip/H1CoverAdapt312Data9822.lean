import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_312 : ([5156,596,400,240,1283] : List Nat).all (cliqueValid 100776264 [0,1,2,4,5,3,7,9,10,6,8,11,12])=true := by decide +kernel
end Research.H1Cover
