import H1CoverAdapt158Data9822
import H1CoverAdapt158Pack0029822
import H1CoverAdapt158Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_13 : (stageRows 48 385 5771532 2 [1,9,2,7] [33,3088,4424]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_14 : (stageRows 48 385 5771532 2 [1,9,2,7,8,3] [33,3088,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_8 : (stageRows 48 385 5771532 3 [6,1,9,2,7,8,12,3] [33,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5771532 (some 6)).all ([64,66,2112,4160,4424,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_158_9
  · exact adapt_158_10
  · exact adapt_158_11
  · exact adapt_158_12
  · exact adapt_158_13
  · exact adapt_158_14
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_3 : (stageRows 48 385 5771532 4 [4,6,1,10,11,9,2,7,8,12,3] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5771532 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_158_4
  · exact adapt_158_5
  · exact adapt_158_6
  · exact adapt_158_7
  · exact adapt_158_8
end Research.H1Cover
