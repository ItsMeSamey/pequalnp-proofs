import H1CoverAdapt148Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_1 : (stageRows 88 256 5244992 4 [3,4,5,2,8,9,10,11,12,1,6,7] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_2 : (stageRows 88 256 5244992 4 [3,5,2,8,9,10,11,12,1,6,7] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
end Research.H1Cover
