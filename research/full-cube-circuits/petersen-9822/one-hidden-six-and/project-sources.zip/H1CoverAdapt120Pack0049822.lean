import H1CoverAdapt120Data9822
import H1CoverAdapt120Pack0009822
import H1CoverAdapt120Pack0019822
import H1CoverAdapt120Pack0029822
import H1CoverAdapt120Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_120_12 : (stageRows 144 521 2491014 2 [3,1,2,8,9,7] [33,3088,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_120_7 : (stageRows 144 521 2491014 3 [6,3,1,2,12,8,9,7] [33,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 2491014 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_120_8
  · exact adapt_120_9
  · exact adapt_120_10
  · exact adapt_120_11
  · exact adapt_120_12
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_120_3 : (stageRows 144 521 2491014 4 [4,6,3,1,2,10,11,12,8,9,7] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 2491014 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
  · exact adapt_120_4
  · apply debitBound (order:=[0,4,6,3,1,2,5,10,11,12,8,9,7]) (ws:=[5156,1283,2309,4609,1349])
    · exact clique_ok_120
    · decide +kernel
    · decide +kernel
  · exact adapt_120_7
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_120_0 : (stageRows 144 521 2491014 5 [0,4,6,3,1,2,5,10,11,12,8,9,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 2491014 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_120_1
  · exact adapt_120_2
  · exact adapt_120_3
end Research.H1Cover
