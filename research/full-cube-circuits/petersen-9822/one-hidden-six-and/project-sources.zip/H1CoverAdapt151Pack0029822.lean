import H1CoverAdapt151Data9822
import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_11 : (stageRows 56 256 5247040 1 [9,7] [33,4360,3088,70]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_12_f0_p0 : terminalCharge 56 256 5247040 [33,4360,3088,198,512] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_12_f1_p0 : terminalCharge 56 256 5247040 [33,4360,3088,198,544] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_12_f2_p0 : terminalCharge 56 256 5247040 [33,4360,3088,198,640] []=true := by decide +kernel
end Research.H1Cover
