import H1CoverAdapt148Data9822
import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_9 : (stageRows 88 256 5244992 1 [9,7] [33,4360,3088,70]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_10 : (stageRows 88 256 5244992 1 [9,6] [33,4360,3088,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,8,9,10,11,12,1,6,7]) (ws:=[2571,5154,1345,4626,2433])
    · exact clique_ok_148
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_11_f0_p0 : terminalCharge 88 256 5244992 [33,4360,3088,198,512] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_148_11_f1_p0 : terminalCharge 88 256 5244992 [33,4360,3088,198,544] []=true := by decide +kernel
end Research.H1Cover
