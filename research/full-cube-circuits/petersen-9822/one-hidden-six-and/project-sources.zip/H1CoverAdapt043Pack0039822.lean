import H1CoverAdapt043Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_43_8 : (stageRows 80 521 312454 2 [6,1,2,11,10,7] [17,4360,544]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,5,6,1,2,4,8,9,12,11,10,7]) (ws:=[4626,2565,2307,5121,1345])
    · exact clique_ok_43
    · decide +kernel
    · decide +kernel
end Research.H1Cover
