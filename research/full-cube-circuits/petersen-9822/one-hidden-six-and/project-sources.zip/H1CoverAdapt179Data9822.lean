import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_179 : ([2571,1128,4628,1283,600] : List Nat).all (cliqueValid 6291744 [0,1,2,3,4,5,6,7,9,10,11,8,12])=true := by decide +kernel
end Research.H1Cover
