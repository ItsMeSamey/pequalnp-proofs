import H1CoverAdapt434Data9822
import H1CoverAdapt434Pack0019822
import H1CoverAdapt434Pack0029822
import H1CoverAdapt434Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_14 : (stageRows 68 514 352322577 1 [5,9] [1041,134,4360,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_12 : (stageRows 68 514 352322577 2 [6,5,11,9] [1041,134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 352322577 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
  · exact adapt_434_13
  · apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
  · exact adapt_434_14
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_7 : (stageRows 68 514 352322577 3 [3,6,5,8,11,12,9] [1041,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 352322577 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_434_8
  · exact adapt_434_9
  · exact adapt_434_10
  · exact adapt_434_11
  · exact adapt_434_12
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_5 : (stageRows 68 514 352322577 4 [1,2,3,6,5,8,11,12,7,9] [1041]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 352322577 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
  · exact adapt_434_6
  · exact adapt_434_7
end Research.H1Cover
