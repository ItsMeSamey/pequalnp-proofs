import H1CoverAdapt279Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_279_2 : (stageRows 48 513 100663436 4 [5,1,6,11,3,8,9,10,12,7,2] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,1,6,11,3,8,9,10,12,7,2]) (ws:=[2571,1128,4611,2433,4225])
    · exact clique_ok_279
    · decide +kernel
    · decide +kernel
end Research.H1Cover
