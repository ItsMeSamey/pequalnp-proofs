import H1CoverAdapt061Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_1 : (stageRows 72 272 591938 4 [5,3,2,4,8,9,12,1,7,10,11,6] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_3 : (stageRows 72 272 591938 3 [3,2,8,9,12,1,7,10,11,6] [17,32]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_4 : (stageRows 72 272 591938 3 [3,2,8,9,12,1,7,10,11,6] [17,33]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_61_5 : (stageRows 72 272 591938 3 [3,2,9,12,1,7,10,11,6] [17,288]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,3,2,4,8,9,12,1,7,10,11,6]) (ws:=[4626,2433,1283,2565,5123])
    · exact clique_ok_61
    · decide +kernel
    · decide +kernel
end Research.H1Cover
