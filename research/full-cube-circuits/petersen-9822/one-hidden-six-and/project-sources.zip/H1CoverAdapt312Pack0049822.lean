import H1CoverAdapt312Data9822
import H1CoverAdapt312Pack0019822
import H1CoverAdapt312Pack0029822
import H1CoverAdapt312Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_13 : (stageRows 104 288 100776264 1 [10] [17,134,800,6472]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_9 : (stageRows 104 288 100776264 2 [3,10,6,11,12] [17,134,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100776264 (some 3)).all ([8,12,264,4104,4360,6216,6472] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
  · exact adapt_312_10
  · exact adapt_312_11
  · exact adapt_312_12
  · exact adapt_312_13
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_4 : (stageRows 104 288 100776264 3 [5,3,9,10,6,8,11,12] [17,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100776264 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_312_5
  · exact adapt_312_6
  · exact adapt_312_7
  · exact adapt_312_8
  · exact adapt_312_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_2 : (stageRows 104 288 100776264 4 [1,2,5,3,7,9,10,6,8,11,12] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100776264 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
  · exact adapt_312_3
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
  · exact adapt_312_4
end Research.H1Cover
