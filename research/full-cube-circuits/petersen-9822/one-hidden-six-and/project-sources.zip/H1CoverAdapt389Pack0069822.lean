import H1CoverAdapt389Data9822
import H1CoverAdapt389Pack0009822
import H1CoverAdapt389Pack0019822
import H1CoverAdapt389Pack0059822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_389_0 : (stageRows 130 516 176161313 5 [0,1,2,3,6,4,8,11,12,7,10,5,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 176161313 (some 0)).all ([1,17,33,49,545] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_389_1
  · exact adapt_389_2
  · exact adapt_389_3
  · exact adapt_389_4
  · exact adapt_389_5
end Research.H1Cover
