import H1CoverAdapt012Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_12_3 : (stageRows 192 544 100096 3 [2,3,4,7,11,12,8,10,9] [33,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,6,2,5,3,4,7,11,12,8,10,9]) (ws:=[248,5154,2432,1128,4148])
    · exact clique_ok_12
    · decide +kernel
    · decide +kernel
end Research.H1Cover
