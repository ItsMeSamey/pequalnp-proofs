import H1CoverAdapt008Data9822
import H1CoverAdapt008Pack0009822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_7 : (stageRows 40 272 77890 2 [3,10,11,7,12] [17,800,70]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_8 : (stageRows 40 272 77890 2 [3,10,11,12,6] [17,800,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_9 : (stageRows 40 272 77890 2 [3,10,11,12] [17,800,198]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_4 : (stageRows 40 272 77890 3 [2,3,10,11,1,7,12,6] [17,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 77890 (some 2)).all ([4,6,12,70,132,134,198] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · exact adapt_8_5
  · exact adapt_8_6
  · exact adapt_8_7
  · apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
  · exact adapt_8_8
  · exact adapt_8_9
end Research.H1Cover
