import H1CoverAdapt281Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_11 : (stageRows 176 512 100663936 1 [3,12,8,9] [33,134,3088,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_281
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_12 : (stageRows 176 512 100663936 1 [3,12,8,9] [33,134,3088,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_281
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_13 : (stageRows 176 512 100663936 1 [3,12,8,9] [33,134,3088,194]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_281
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_281_14 : (stageRows 176 512 100663936 1 [3,12,8,9] [33,134,3088,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,4,5,1,6,3,10,11,7,12,8,9]) (ws:=[1128,2433,5154,1349,2059])
    · exact clique_ok_281
    · decide +kernel
    · decide +kernel
end Research.H1Cover
