import H1CoverAdapt151Data9822
import H1CoverAdapt151Pack0019822
import H1CoverAdapt151Pack0029822
import H1CoverAdapt151Pack0039822
import H1CoverLastTerminal9822
import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_12_f7_p0 : terminalCharge 56 256 5247040 [33,4360,3088,198,4864] []=true := by decide +kernel
theorem adapt_151_12 : (stageRows 56 256 5247040 1 [9] [33,4360,3088,198]).all fixedPrice=true := by
  apply lastTerminal
  intro m hm
  have check : (finishing 5247040 [9]).all ([512,544,640,768,800,1536,1664,4864] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp check m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_151_12_f0_p0
  · exact adapt_151_12_f1_p0
  · exact adapt_151_12_f2_p0
  · exact adapt_151_12_f3_p0
  · exact adapt_151_12_f4_p0
  · exact adapt_151_12_f5_p0
  · exact adapt_151_12_f6_p0
  · exact adapt_151_12_f7_p0
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_10 : (stageRows 56 256 5247040 2 [2,1,6,9,7] [33,4360,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5247040 (some 2)).all ([4,6,12,70,132,134,198] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
  · exact adapt_151_11
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
  · exact adapt_151_12
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_8 : (stageRows 56 256 5247040 3 [4,2,10,11,1,6,9,7] [33,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5247040 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
  · exact adapt_151_9
  · exact adapt_151_10
end Research.H1Cover
