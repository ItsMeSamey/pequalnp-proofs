import H1CoverAdapt029Data9822
import H1CoverAdapt029Pack0009822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_7 : (stageRows 192 548 116512 2 [6,5,11,8,10,9] [17,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_8 : (stageRows 192 548 116512 2 [6,5,11,10,9] [17,134,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_3 : (stageRows 192 548 116512 3 [3,6,5,12,11,8,10,9] [17,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 116512 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_29_4
  · exact adapt_29_5
  · exact adapt_29_6
  · exact adapt_29_7
  · exact adapt_29_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_1 : (stageRows 192 548 116512 4 [1,2,3,6,7,5,12,11,8,10,9] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 116512 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
  · exact adapt_29_2
  · exact adapt_29_3
end Research.H1Cover
