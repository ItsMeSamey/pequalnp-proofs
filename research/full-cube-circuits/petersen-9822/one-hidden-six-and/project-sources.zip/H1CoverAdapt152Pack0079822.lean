import H1CoverAdapt152Data9822
import H1CoverAdapt152Pack0009822
import H1CoverAdapt152Pack0019822
import H1CoverAdapt152Pack0029822
import H1CoverAdapt152Pack0039822
import H1CoverAdapt152Pack0069822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_152_8 : (stageRows 120 256 5249088 3 [4,2,10,11,1,6,9,7] [33,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5249088 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_152
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_152
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_152
    · decide +kernel
    · decide +kernel
  · exact adapt_152_9
  · exact adapt_152_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_152_3 : (stageRows 120 256 5249088 4 [3,4,2,10,11,1,6,8,9,12,7] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5249088 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_152_4
  · exact adapt_152_5
  · exact adapt_152_6
  · exact adapt_152_7
  · exact adapt_152_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_152_0 : (stageRows 120 256 5249088 5 [0,3,4,5,2,10,11,1,6,8,9,12,7] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 5249088 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_152_1
  · exact adapt_152_2
  · exact adapt_152_3
end Research.H1Cover
