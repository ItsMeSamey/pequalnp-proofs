import H1CollectorChildren9822
import H1ReplayLogic9822
namespace Research.H1Price
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet.CircuitCompiler
def zeroOn (cone : Nat → Prop) (w : List Bool) : Prop := ∀ j, cone j → w.getD j false = false
theorem zero_snoc (cone : Nat → Prop) {w : List Bool} {b : Bool}
    (old : zeroOn cone w) (bit : cone w.length → b=false) : zeroOn cone (w++[b]) := by
  intro j hj
  rcases Nat.lt_trichotomy j w.length with sm|eq|big
  · rw [List.getD_append _ _ _ _ sm]
    exact old _ hj
  · subst j
    rw [List.getD_append_right _ _ _ _ (Nat.le_refl _)]
    simpa using bit hj
  · apply List.getD_eq_default
    simp; omega
theorem zero_seed (cone : Nat → Prop) (w : List Bool) (noRaw : ∀ j < w.length, ¬cone j) :
    zeroOn cone w := by
  intro j hj
  apply List.getD_eq_default
  by_contra fail
  exact noRaw j (by omega) hj
def clipsCone (cone : Nat → Prop) (erase : Nat → Bool) (hidden : Nat) :
    Nat → List Gate → Prop
 | _,[] => True
 | k,g::gs =>
   (cone k → erase k=true ∨ (orFlag g=false ∧ k≠hidden)) ∧
   (erase k=true → orFlag g=true ∧ cone (g.inputs.getD 0 k) ∧ cone (g.inputs.getD 1 k)) ∧
   clipsCone cone erase hidden (k+1) gs
theorem clip_zero_step {cone : Nat → Prop} {erase : Nat → Bool} {hidden k : Nat}
    {g : Gate} {w : List Bool} {hot : Bool}
    (len : w.length=k) (old : zeroOn cone w)
    (here : cone k → erase k=true ∨ (orFlag g=false ∧ k≠hidden)) :
    zeroOn cone (w++[clipBit erase hidden k g w hot]) := by
  apply zero_snoc _ old
  intro h
  rw [len] at h
  rcases here h with z|⟨o,ne⟩
  · simp [clipBit,z]
  · cases z : erase k <;> simp [clipBit,z,o,ne]
theorem erased_false {cone : Nat → Prop} {k : Nat} {g : Gate} {w : List Bool}
    (old : zeroOn cone w) (o : orFlag g=true)
    (l : cone (g.inputs.getD 0 k)) (r : cone (g.inputs.getD 1 k)) :
    operandValue k g w = false := by
  simp only [operandValue,if_pos o,old _ l,old _ r,Bool.false_or]
end Research.H1Price
#print axioms Research.H1Price.erased_false
