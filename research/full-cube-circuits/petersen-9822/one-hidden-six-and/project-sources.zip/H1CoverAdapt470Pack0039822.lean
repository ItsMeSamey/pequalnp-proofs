import H1CoverAdapt470Data9822
import H1CoverAdapt470Pack0009822
import H1CoverAdapt470Pack0019822
import H1CoverAdapt470Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_4 : (stageRows 272 520 402653378 3 [2,3,6,10,11,12,7,1] [17,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 402653378 (some 2)).all ([4,6,12,132,134,142] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_470_5
  · exact adapt_470_6
  · exact adapt_470_7
  · exact adapt_470_8
  · exact adapt_470_9
  · exact adapt_470_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_2 : (stageRows 272 520 402653378 4 [5,2,3,8,6,9,10,11,12,7,1] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 402653378 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
  · exact adapt_470_3
  · apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
  · exact adapt_470_4
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_15 : (stageRows 272 520 402653378 4 [4,2,3,8,6,9,10,11,12,7,1] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,8,6,9,10,11,12,7,1]) (ws:=[1349,585,5125,2433,4225])
    · exact clique_ok_470
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_470_0 : (stageRows 272 520 402653378 5 [0,4,5,2,3,8,6,9,10,11,12,7,1] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 402653378 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_470_1
  · exact adapt_470_2
  · exact adapt_470_15
end Research.H1Cover
