import H1CoverAdapt066Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_66_14 : (stageRows 104 272 604226 4 [4,3,2,8,9,10,1,7,11,12,6] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,3,2,8,9,10,1,7,11,12,6]) (ws:=[1283,2565,4225,577,2433])
    · exact clique_ok_66
    · decide +kernel
    · decide +kernel
end Research.H1Cover
