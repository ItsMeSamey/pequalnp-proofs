import H1CoverAdapt434Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_11 : (stageRows 68 514 352322577 2 [6,5,8,11,9] [1041,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_13 : (stageRows 68 514 352322577 1 [5,9] [1041,134,4360,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
end Research.H1Cover
