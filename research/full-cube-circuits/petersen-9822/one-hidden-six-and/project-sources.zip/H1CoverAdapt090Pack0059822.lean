import H1CoverAdapt090Data9822
import H1CoverAdapt090Pack0009822
import H1CoverAdapt090Pack0029822
import H1CoverAdapt090Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_90_0 : (stageRows 104 320 908368 5 [0,1,2,3,5,4,7,8,9,6,10,11,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 908368 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_90_1
  · exact adapt_90_2
  · exact adapt_90_10
end Research.H1Cover
