import H1CoverAdapt073Data9822
import H1CoverAdapt073Pack0019822
import H1CoverAdapt073Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_10 : (stageRows 128 612 787232 1 [4,11,9,10] [33,134,4360,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_11 : (stageRows 128 612 787232 1 [4,9,10] [33,134,4360,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_6 : (stageRows 128 612 787232 2 [6,4,11,9,10] [33,134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 787232 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_73_7
  · exact adapt_73_8
  · exact adapt_73_9
  · exact adapt_73_10
  · exact adapt_73_11
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_73_4 : (stageRows 128 612 787232 3 [3,6,4,8,12,11,9,10] [33,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 787232 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
  · exact adapt_73_5
  · apply debitBound (order:=[0,1,2,3,5,6,4,7,8,12,11,9,10]) (ws:=[1349,4272,1128,248,5156])
    · exact clique_ok_73
    · decide +kernel
    · decide +kernel
  · exact adapt_73_6
end Research.H1Cover
