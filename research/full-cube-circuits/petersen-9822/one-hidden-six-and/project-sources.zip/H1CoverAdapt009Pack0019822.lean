import H1CoverAdapt009Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_3 : (stageRows 32 401 78088 3 [6,1,9,2,3,10,11,12,7] [17,288]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_9
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_5 : (stageRows 32 401 78088 2 [1,2,3,10,11,12,7] [17,800,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_9
    · decide +kernel
    · decide +kernel
end Research.H1Cover
