import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_389 : ([1349,4628,2433,2570,216] : List Nat).all (cliqueValid 176161313 [0,1,2,3,6,4,8,11,12,7,10,5,9])=true := by decide +kernel
end Research.H1Cover
