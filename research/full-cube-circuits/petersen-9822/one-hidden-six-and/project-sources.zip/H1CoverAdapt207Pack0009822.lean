import H1CoverAdapt207Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_1 : (stageRows 130 132 7209761 4 [2,3,4,0,7,10,11,12,5,8,9] [66]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_2 : (stageRows 130 132 7209761 4 [2,3,4,6,0,10,11,12,5,8,9] [130]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_4 : (stageRows 130 132 7209761 3 [4,6,0,10,11,12,5,8,9] [134,8]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_207_5 : (stageRows 130 132 7209761 3 [4,6,0,10,11,12,5,8,9] [134,12]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_207
    · decide +kernel
    · decide +kernel
end Research.H1Cover
