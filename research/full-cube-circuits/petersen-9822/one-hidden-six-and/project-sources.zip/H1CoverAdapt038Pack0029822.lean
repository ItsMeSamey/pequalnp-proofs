import H1CoverAdapt038Data9822
import H1CoverAdapt038Pack0009822
import H1CoverAdapt038Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_4 : (stageRows 96 257 284680 3 [6,4,3,8,9,10,11,12] [33,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 284680 (some 6)).all ([64,66,2112,4160,6208,6210] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_38_5
  · exact adapt_38_6
  · exact adapt_38_7
  · exact adapt_38_8
  · exact adapt_38_9
  · exact adapt_38_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_11 : (stageRows 96 257 284680 3 [2,4,7,3,8,9,10] [33,6210]).all fixedPrice=true := by
    apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_2 : (stageRows 96 257 284680 4 [1,2,6,4,7,3,8,9,10,11,12] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 284680 (some 1)).all ([2,6,66,130,134,6210] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
  · exact adapt_38_3
  · apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
  · exact adapt_38_4
  · exact adapt_38_11
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_38_0 : (stageRows 96 257 284680 5 [0,5,1,2,6,4,7,3,8,9,10,11,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 284680 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · apply debitBound (order:=[0,5,1,2,6,4,7,3,8,9,10,11,12]) (ws:=[1097,464,2433,1349,248])
    · exact clique_ok_38
    · decide +kernel
    · decide +kernel
  · exact adapt_38_1
  · exact adapt_38_2
end Research.H1Cover
