import H1CoverAdapt009Data9822
import H1CoverPriceTerminal9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_10 : (stageRows 32 401 78088 1 [10,7] [17,800,6208,14]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_9
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_11_f0_p0 : terminalCharge 32 401 78088 [17,800,6208,142,1024] []=true := by decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_9_11_f1_p0 : terminalCharge 32 401 78088 [17,800,6208,142,1040] []=true := by decide +kernel
end Research.H1Cover
