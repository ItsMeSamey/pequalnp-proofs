import H1CoverAdapt050Data9822
import H1CoverAdapt050Pack0009822
import H1CoverAdapt050Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_1 : (stageRows 40 384 397632 4 [1,2,3,5,7,6,10,11,9,8,12] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 397632 (some 1)).all ([2,6,66,130,134,4162] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
  · exact adapt_50_2
  · exact adapt_50_3
  · apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_10 : (stageRows 40 384 397632 4 [4,1,2,3,7,6,10,11,9,8,12] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_50_0 : (stageRows 40 384 397632 5 [0,4,1,2,3,5,7,6,10,11,9,8,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 397632 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · apply debitBound (order:=[0,4,1,2,3,5,7,6,10,11,9,8,12]) (ws:=[2571,248,2433,585,2216])
    · exact clique_ok_50
    · decide +kernel
    · decide +kernel
  · exact adapt_50_1
  · exact adapt_50_10
end Research.H1Cover
