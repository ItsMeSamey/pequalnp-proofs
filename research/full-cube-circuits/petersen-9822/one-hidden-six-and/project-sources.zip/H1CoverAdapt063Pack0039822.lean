import H1CoverAdapt063Data9822
import H1CoverAdapt063Pack0029822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_15 : (stageRows 64 786 592912 1 [1,2,7,10] [17,800,6208,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_16 : (stageRows 64 786 592912 1 [1,2,7,10] [17,800,6208,4360]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_17 : (stageRows 64 786 592912 1 [1,2,7,10] [17,800,6208,6152]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,3,1,2,8,9,11,12,7,10]) (ws:=[4613,2433,523,248,4611])
    · exact clique_ok_63
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_63_11 : (stageRows 64 786 592912 2 [3,1,2,7,10] [17,800,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 592912 (some 3)).all ([8,12,264,4104,4360,6152] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_63_12
  · exact adapt_63_13
  · exact adapt_63_14
  · exact adapt_63_15
  · exact adapt_63_16
  · exact adapt_63_17
end Research.H1Cover
