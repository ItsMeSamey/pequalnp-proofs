import H1CoverAdapt049Data9822
import H1CoverAdapt049Pack0009822
import H1CoverAdapt049Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_49_10 : (stageRows 144 520 393858 1 [10] [17,142,6208,928]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_49_7 : (stageRows 144 520 393858 2 [5,10,8,9] [17,142,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 393858 (some 5)).all ([32,33,288,544,672,800,928] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · exact adapt_49_8
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · exact adapt_49_9
  · exact adapt_49_10
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_49_5 : (stageRows 144 520 393858 3 [6,5,12,10,11,8,9] [17,142]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 393858 (some 6)).all ([64,66,194,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · exact adapt_49_6
  · exact adapt_49_7
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_49_2 : (stageRows 144 520 393858 4 [2,3,6,5,12,1,10,11,8,9,7] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 393858 (some 2)).all ([4,6,12,132,134,142] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · exact adapt_49_3
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,2,3,6,5,12,1,10,11,8,9,7]) (ws:=[5154,585,1349,2307,4613])
    · exact clique_ok_49
    · decide +kernel
    · decide +kernel
  · exact adapt_49_4
  · exact adapt_49_5
end Research.H1Cover
