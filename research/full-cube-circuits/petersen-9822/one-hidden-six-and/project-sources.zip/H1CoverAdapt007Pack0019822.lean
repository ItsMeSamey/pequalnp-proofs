import H1CoverAdapt007Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_6 : (stageRows 32 273 77832 2 [2,3,10,11,12,7] [17,800,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_7 : (stageRows 32 273 77832 2 [1,2,3,10,12,7] [17,800,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_8 : (stageRows 32 273 77832 2 [1,2,3,10,11,7] [17,800,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_10 : (stageRows 32 273 77832 1 [10,7] [17,800,6208,14]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
end Research.H1Cover
