import H1CoverAdapt012Data9822
import H1CoverAdapt012N0159822
import H1CoverAdapt012N0169822
import H1CoverAdapt012N0179822
import H1CoverAdapt012N0189822
import H1CoverAdapt012N0199822
import H1CoverAdapt012N0209822
import H1CoverAdapt012N0219822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_12_14 : (stageRows 192 544 100096 2 [3,4,10] [801,134,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100096 (some 3)).all ([8,12,264,776,4104,4360,4872] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_12_15
  · exact adapt_12_16
  · exact adapt_12_17
  · exact adapt_12_18
  · exact adapt_12_19
  · exact adapt_12_20
  · exact adapt_12_21
end Research.H1Cover
