import H1CoverAdapt210Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_1 : (stageRows 130 196 7209777 4 [2,3,4,0,7,10,11,12,5,8,9] [66]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_2 : (stageRows 130 196 7209777 4 [2,3,4,6,0,10,11,12,5,8,9] [130]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_4 : (stageRows 130 196 7209777 3 [4,6,0,10,11,12,5,8,9] [134,8]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_210_5 : (stageRows 130 196 7209777 3 [4,6,0,10,11,12,5,8,9] [134,12]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,4,6,0,7,10,11,12,5,8,9]) (ws:=[5154,248,2185,4272,1124])
    · exact clique_ok_210
    · decide +kernel
    · decide +kernel
end Research.H1Cover
