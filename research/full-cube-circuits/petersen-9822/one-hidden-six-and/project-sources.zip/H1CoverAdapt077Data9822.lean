import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_77 : ([248,2571,4628,2216,600] : List Nat).all (cliqueValid 789520 [0,1,2,3,4,6,5,7,11,12,8,9,10])=true := by decide +kernel
end Research.H1Cover
