import H1CoverAdapt282Data9822
import H1CoverAdapt282Pack0009822
import H1CoverAdapt282Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_282_11 : (stageRows 224 512 100664832 1 [3,8,9] [33,134,3088,6208]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_282_6 : (stageRows 224 512 100664832 2 [6,3,12,8,9] [33,134,3088]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100664832 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_282_7
  · exact adapt_282_8
  · exact adapt_282_9
  · exact adapt_282_10
  · exact adapt_282_11
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_282_4 : (stageRows 224 512 100664832 3 [4,6,3,10,11,12,8,9] [33,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100664832 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
  · exact adapt_282_5
  · apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
  · exact adapt_282_6
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_282_2 : (stageRows 224 512 100664832 4 [1,2,4,6,3,7,10,11,12,8,9] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100664832 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
  · exact adapt_282_3
  · apply debitBound (order:=[0,1,2,4,5,6,3,7,10,11,12,8,9]) (ws:=[1128,2433,248,1349,5156])
    · exact clique_ok_282
    · decide +kernel
    · decide +kernel
  · exact adapt_282_4
end Research.H1Cover
