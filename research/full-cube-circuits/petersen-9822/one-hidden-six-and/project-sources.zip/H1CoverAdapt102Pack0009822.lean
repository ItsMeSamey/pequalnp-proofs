import H1CoverAdapt102Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_1 : (stageRows 4 146 1114145 4 [1,2,6,3,4,5,7,9,11,12,8,10] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_2 : (stageRows 4 146 1114145 4 [1,2,6,3,5,7,9,11,12,8,10] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_3 : (stageRows 4 146 1114145 4 [1,2,6,3,4,7,9,11,12,8,10] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_102_5 : (stageRows 4 146 1114145 3 [2,6,3,5,7,9,11,12,8] [1041,2]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,3,4,5,7,9,11,12,8,10]) (ws:=[2571,4272,600,5156,4628])
    · exact clique_ok_102
    · decide +kernel
    · decide +kernel
end Research.H1Cover
