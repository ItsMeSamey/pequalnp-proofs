import H1CoverAdapt246Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_246_3 : (stageRows 36 130 33562913 4 [1,2,6,4,3,7,11,9,10,12,8] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,3,7,11,9,10,12,5,8]) (ws:=[2571,4628,2432,600,224])
    · exact clique_ok_246
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_246_5 : (stageRows 36 130 33562913 3 [2,6,3,7,11,9,10,12,8] [49,2]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,3,7,11,9,10,12,5,8]) (ws:=[2571,4628,2432,600,224])
    · exact clique_ok_246
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_246_6 : (stageRows 36 130 33562913 3 [6,3,7,11,9,10,12,8] [49,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,3,7,11,9,10,12,5,8]) (ws:=[2571,4628,2432,600,224])
    · exact clique_ok_246
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_246_7 : (stageRows 36 130 33562913 3 [2,3,7,11,9,10,12,8] [49,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,6,4,3,7,11,9,10,12,5,8]) (ws:=[2571,4628,2432,600,224])
    · exact clique_ok_246
    · decide +kernel
    · decide +kernel
end Research.H1Cover
