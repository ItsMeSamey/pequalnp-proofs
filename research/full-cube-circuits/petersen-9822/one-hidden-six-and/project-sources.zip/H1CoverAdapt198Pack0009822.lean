import H1CoverAdapt198Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_1 : (stageRows 192 770 6426128 4 [1,2,3,6,5,7,12,8,11,9,10] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_198_3 : (stageRows 192 770 6426128 3 [2,3,7,4,12,8,11,9,10] [33,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,7,4,12,8,11,9,10]) (ws:=[248,4611,2432,340,2216])
    · exact clique_ok_198
    · decide +kernel
    · decide +kernel
end Research.H1Cover
