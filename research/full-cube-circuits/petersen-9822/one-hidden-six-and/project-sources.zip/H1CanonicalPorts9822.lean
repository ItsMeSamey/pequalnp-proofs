import H1OriginalFrontier9822
import H1CoverOriginalCircuitAt9822
namespace Research.H1Cover
open Research.H1Price
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity FreeAndNet.CircuitCompiler
open PEqualNP.Outside.L_meta_9822.Clean PEqualNP.Outside.L_meta_9822.Sectors

def originalPorts (C : Circuit) (hidden address : Nat) : PhysicalPorts :=
  let ws := clippedWires C.gates C.output hidden
  let g := C.gates.getD (address-10) ⟨.and,[]⟩
  (ws.getD (g.inputs.getD 0 0) ∅, ws.getD (g.inputs.getD 1 0) ∅)

noncomputable def originalPairs (C : Circuit) (hidden : Nat) :=
  (physicalFront C).toList.map (originalPorts C hidden)

theorem realPairs_count (C : Circuit) (hidden : Nat) :
    (originalPairs C hidden).length = (physicalFront C).card := by simp [originalPairs]

theorem scopeRunLength (env : List (Finset Nat)) (prog : List Entry) :
    (run env prog).length = env.length + prog.length := by
  induction prog generalizing env with
  | nil => simp [Research.H1Price.run]
  | cons a as ih => simp [Research.H1Price.run,ih] <;> omega

theorem scriptLength (erase : Nat → Bool) (hidden k : Nat) (gs : List Gate) :
    (transcript erase hidden k gs).length = gs.length := by
  induction gs generalizing k with
  | nil => rfl
  | cons a as ih => simp [transcript,ih]

theorem clippedLength (C : Circuit) (hidden : Nat) :
    (clippedWires C.gates C.output hidden).length=10+C.gates.length := by
  simp [clippedWires,scopeRunLength,inputScopes,scriptLength]

theorem port_hit (C : Circuit) (hidden i : Nat) (g : Gate) (hit : C.gates[i]? = some g)
    (l r : Nat) (ins : g.inputs=[l,r]) :
    originalPorts C hidden (10+i) =
      ((clippedWires C.gates C.output hidden).getD l ∅,
       (clippedWires C.gates C.output hidden).getD r ∅) := by
  simp [originalPorts,List.getD_eq_getElem?_getD,hit,ins]

theorem realPorts_mem (C : Circuit) (hidden i : Nat) (g : Gate) (hit : C.gates[i]? = some g)
    (l r : Nat) (ins : g.inputs=[l,r]) (hl : l < 10+i) (hr : r < 10+i) :
    (originalPorts C hidden (10+i)).1 ∈ clippedWires C.gates C.output hidden ∧
    (originalPorts C hidden (10+i)).2 ∈ clippedWires C.gates C.output hidden := by
  have hi : i < C.gates.length := by
    obtain ⟨hh,_⟩ := List.getElem?_eq_some_iff.mp hit
    exact hh
  rw [port_hit C hidden i g hit l r ins]
  have one (n : Nat) (hn : n < 10+i) :
      (clippedWires C.gates C.output hidden).getD n ∅ ∈ clippedWires C.gates C.output hidden := by
    have bd : n < (clippedWires C.gates C.output hidden).length := by rw [clippedLength];omega
    rw [List.getD_eq_getElem?_getD,List.getElem?_eq_getElem bd,Option.getD_some]
    exact List.getElem_mem ..
  exact ⟨one l hl,one r hr⟩
end Research.H1Cover
#print axioms Research.H1Cover.realPorts_mem
