import H1CoverAdapt308Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_11 : (stageRows 160 548 100774696 1 [10] [17,134,6208,808]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
end Research.H1Cover
