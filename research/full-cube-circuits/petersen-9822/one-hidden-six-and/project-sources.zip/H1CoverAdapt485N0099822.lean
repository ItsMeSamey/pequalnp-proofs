import H1CoverAdapt485Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_485_9 : (stageRows 272 521 404750534 2 [10,6,11,12,7,1] [17,800,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,3,8,9,2,10,6,11,12,7,1]) (ws:=[1345,2565,4225,4613,1128])
    · exact clique_ok_485
    · decide +kernel
    · decide +kernel
end Research.H1Cover
