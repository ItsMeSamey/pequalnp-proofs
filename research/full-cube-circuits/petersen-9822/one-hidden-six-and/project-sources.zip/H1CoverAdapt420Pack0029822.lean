import H1CoverAdapt420Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_420_5 : (stageRows 68 258 269486097 3 [3,6,7,8,9,10,12,11] [49,6]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,7,8,9,10,12,4,11]) (ws:=[1349,5156,2432,1128,152])
    · exact clique_ok_420
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_420_6 : (stageRows 68 258 269486097 3 [2,3,7,8,9,10,12,11] [49,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,5,6,7,8,9,10,12,4,11]) (ws:=[1349,5156,2432,1128,152])
    · exact clique_ok_420
    · decide +kernel
    · decide +kernel
end Research.H1Cover
