import H1CoverAdapt474Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_474_14 : (stageRows 464 512 402654848 1 [6,10,11] [17,134,800,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_474
    · decide +kernel
    · decide +kernel
end Research.H1Cover
