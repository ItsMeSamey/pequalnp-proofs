import H1CoverAdapt312Data9822
import H1CoverAdapt312Pack0009822
import H1CoverAdapt312Pack0049822
import H1CoverAdapt312Pack0059822
import H1CoverAdapt312Pack0069822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_22 : (stageRows 104 288 100776264 2 [3,9,6,8,12] [33,134,3088]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_17 : (stageRows 104 288 100776264 3 [4,3,9,10,6,8,11,12] [33,134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100776264 (some 4)).all ([16,17,1040,2064,3088] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_312_18
  · exact adapt_312_19
  · exact adapt_312_20
  · exact adapt_312_21
  · exact adapt_312_22
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_14 : (stageRows 104 288 100776264 4 [1,2,4,3,7,9,10,6,8,11,12] [33]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100776264 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
  · exact adapt_312_15
  · exact adapt_312_16
  · apply debitBound (order:=[0,1,2,4,5,3,7,9,10,6,8,11,12]) (ws:=[5156,596,400,240,1283])
    · exact clique_ok_312
    · decide +kernel
    · decide +kernel
  · exact adapt_312_17
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_312_0 : (stageRows 104 288 100776264 5 [0,1,2,4,5,3,7,9,10,6,8,11,12] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 100776264 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · exact adapt_312_1
  · exact adapt_312_2
  · exact adapt_312_14
end Research.H1Cover
