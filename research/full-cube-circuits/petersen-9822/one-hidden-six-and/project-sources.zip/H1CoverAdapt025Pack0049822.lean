import H1CoverAdapt025Data9822
import H1CoverAdapt025Pack0009822
import H1CoverAdapt025Pack0019822
import H1CoverAdapt025Pack0029822
import H1CoverAdapt025Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_3 : (stageRows 4 194 114721 4 [3,6,0,5,9,4,8,12,10,11] [134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 114721 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_25_4
  · exact adapt_25_5
  · exact adapt_25_6
  · exact adapt_25_7
  · exact adapt_25_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_25_0 : (stageRows 4 194 114721 5 [1,2,3,6,0,5,7,9,4,8,12,10,11] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 114721 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,6,0,5,7,9,4,8,12,10,11]) (ws:=[4626,2216,1128,248,4225])
    · exact clique_ok_25
    · decide +kernel
    · decide +kernel
  · exact adapt_25_1
  · exact adapt_25_2
  · exact adapt_25_3
end Research.H1Cover
