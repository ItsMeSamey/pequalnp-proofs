import H1CoverAdapt183Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_10 : (stageRows 192 768 6295040 2 [5,6,8,9] [3089,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_12 : (stageRows 192 768 6295040 1 [6] [3089,134,4360,544]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
end Research.H1Cover
