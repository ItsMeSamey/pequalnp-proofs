import H1CoverAdapt066Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_66_1 : (stageRows 104 272 604226 4 [4,5,3,2,8,9,10,1,7,11,12,6] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,3,2,8,9,10,1,7,11,12,6]) (ws:=[1283,2565,4225,577,2433])
    · exact clique_ok_66
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_66_3 : (stageRows 104 272 604226 3 [3,2,8,9,10,1,7,11,12,6] [17,32]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,3,2,8,9,10,1,7,11,12,6]) (ws:=[1283,2565,4225,577,2433])
    · exact clique_ok_66
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_66_4 : (stageRows 104 272 604226 3 [3,2,8,9,10,1,7,11,12,6] [17,33]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,3,2,8,9,10,1,7,11,12,6]) (ws:=[1283,2565,4225,577,2433])
    · exact clique_ok_66
    · decide +kernel
    · decide +kernel
end Research.H1Cover
