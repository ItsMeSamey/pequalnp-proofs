import H1CoverAdapt308Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_308_1 : (stageRows 160 548 100774696 4 [1,2,4,6,3,7,10,11,5,12,8,9] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,4,6,3,7,10,11,5,12,8,9]) (ws:=[1349,2433,1058,5123,216])
    · exact clique_ok_308
    · decide +kernel
    · decide +kernel
end Research.H1Cover
