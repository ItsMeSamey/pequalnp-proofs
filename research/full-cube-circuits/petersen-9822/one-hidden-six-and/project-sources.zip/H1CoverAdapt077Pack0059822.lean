import H1CoverAdapt077Data9822
import H1CoverAdapt077Pack0049822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_77_11 : (stageRows 64 898 789520 4 [1,2,3,4,6,7,11,12,8,9,10] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_77_0 : (stageRows 64 898 789520 5 [0,1,2,3,4,6,5,7,11,12,8,9,10] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 789520 (some 0)).all ([1,17,33] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl
  · apply debitBound (order:=[0,1,2,3,4,6,5,7,11,12,8,9,10]) (ws:=[248,2571,4628,2216,600])
    · exact clique_ok_77
    · decide +kernel
    · decide +kernel
  · exact adapt_77_1
  · exact adapt_77_11
end Research.H1Cover
