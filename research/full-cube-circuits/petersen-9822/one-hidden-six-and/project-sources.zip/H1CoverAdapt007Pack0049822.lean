import H1CoverAdapt007Data9822
import H1CoverAdapt007Pack0009822
import H1CoverAdapt007Pack0019822
import H1CoverAdapt007Pack0029822
import H1CoverAdapt007Pack0039822
import H1CoverLastTerminal9822
namespace Research.H1Cover
theorem adapt_7_11 : (stageRows 32 273 77832 1 [10] [17,800,6208,142]).all fixedPrice=true := by
  apply lastTerminal
  intro m hm
  have check : (finishing 77832 [10]).all ([1024,1040,1152,1536,1664,3072,3088,7168] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp check m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact adapt_7_11_f0_p0
  · exact adapt_7_11_f1_p0
  · exact adapt_7_11_f2_p0
  · exact adapt_7_11_f3_p0
  · exact adapt_7_11_f4_p0
  · exact adapt_7_11_f5_p0
  · exact adapt_7_11_f6_p0
  · exact adapt_7_11_f7_p0
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_9 : (stageRows 32 273 77832 2 [1,2,3,10,7] [17,800,6208]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 77832 (some 1)).all ([2,6,14,66,130,134,142] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
  · exact adapt_7_10
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
  · exact adapt_7_11
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_4 : (stageRows 32 273 77832 3 [6,1,2,3,10,11,12,7] [17,800]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 77832 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_7_5
  · exact adapt_7_6
  · exact adapt_7_7
  · exact adapt_7_8
  · exact adapt_7_9
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_7_2 : (stageRows 32 273 77832 4 [5,6,1,8,9,2,3,10,11,12,7] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 77832 (some 5)).all ([32,33,288,544,800] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
  · exact adapt_7_3
  · apply debitBound (order:=[0,4,5,6,1,8,9,2,3,10,11,12,7]) (ws:=[1349,2569,4613,2433,1097])
    · exact clique_ok_7
    · decide +kernel
    · decide +kernel
  · exact adapt_7_4
end Research.H1Cover
