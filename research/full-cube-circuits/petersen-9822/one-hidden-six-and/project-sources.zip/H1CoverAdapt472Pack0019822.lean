import H1CoverAdapt472Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_472_6 : (stageRows 336 512 402654336 3 [5,2,3,6,8,9,12,10,11] [17,130]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_472
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_472_8 : (stageRows 336 512 402654336 2 [3,6,8,12,10,11] [17,134,544]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_472
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_472_10 : (stageRows 336 512 402654336 1 [6,12,10,11] [17,134,800,8]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,4,5,2,3,6,8,9,7,12,10,11]) (ws:=[600,2433,4628,2571,325])
    · exact clique_ok_472
    · decide +kernel
    · decide +kernel
end Research.H1Cover
