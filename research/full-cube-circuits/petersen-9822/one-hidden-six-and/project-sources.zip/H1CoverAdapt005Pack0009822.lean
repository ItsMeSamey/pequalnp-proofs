import H1CoverAdapt005Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_1 : (stageRows 32 145 73992 4 [4,5,6,1,8,9,10,11,12,2,3,7] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_5_3 : (stageRows 32 145 73992 3 [6,1,9,10,11,12,2,3,7] [17,288]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,8,9,10,11,12,2,3,7]) (ws:=[1349,4613,2569,5125,2433])
    · exact clique_ok_5
    · decide +kernel
    · decide +kernel
end Research.H1Cover
