import H1CoverAdapt179Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_179_11 : (stageRows 128 292 6291744 2 [6,9,10,11,8,12] [49,134,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,9,10,11,8,12]) (ws:=[2571,1128,4628,1283,600])
    · exact clique_ok_179
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_179_12 : (stageRows 128 292 6291744 2 [6,9,10,11,12] [49,134,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,9,10,11,8,12]) (ws:=[2571,1128,4628,1283,600])
    · exact clique_ok_179
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_179_13 : (stageRows 128 292 6291744 2 [6,9,10,11,8] [49,134,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,4,5,6,7,9,10,11,8,12]) (ws:=[2571,1128,4628,1283,600])
    · exact clique_ok_179
    · decide +kernel
    · decide +kernel
end Research.H1Cover
