import H1CoverAdapt183Data9822
import H1CoverAdapt183Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_13 : (stageRows 192 768 6295040 1 [6] [3089,134,4360,800]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_14 : (stageRows 192 768 6295040 1 [6] [3089,134,4360,1568]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_15 : (stageRows 192 768 6295040 1 [6] [3089,134,4360,1824]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_11 : (stageRows 192 768 6295040 2 [5,6,9] [3089,134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6295040 (some 5)).all ([32,33,288,544,800,1568,1824] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
  · exact adapt_183_12
  · exact adapt_183_13
  · exact adapt_183_14
  · exact adapt_183_15
end Research.H1Cover
