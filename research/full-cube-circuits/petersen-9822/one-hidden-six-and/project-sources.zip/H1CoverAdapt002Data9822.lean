import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_2 : ([1349,4613,2569,5125,2433] : List Nat).all (cliqueValid 73736 [0,4,5,6,1,8,9,10,11,12,2,3,7])=true := by decide +kernel
end Research.H1Cover
