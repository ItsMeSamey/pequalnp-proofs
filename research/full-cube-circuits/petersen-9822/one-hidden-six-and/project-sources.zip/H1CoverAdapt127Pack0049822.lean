import H1CoverAdapt127Data9822
import H1CoverAdapt127Pack0009822
import H1CoverAdapt127Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_127_0 : (stageRows 2 84 4202513 5 [0,1,2,3,4,5,6,7,8,10,12,9,11] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 4202513 (some 0)).all ([1,17,33,545] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl
  · exact adapt_127_1
  · exact adapt_127_2
  · exact adapt_127_3
  · exact adapt_127_4
end Research.H1Cover
