import H1CoverAdapt188Data9822
import H1CoverAdapt188Pack0009822
import H1CoverAdapt188Pack0019822
import H1CoverAdapt188Pack0029822
import H1CoverAdapt188Pack0039822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_188_13 : (stageRows 2 196 6422545 2 [0,4,10,5,9] [134,4360,6208]).all fixedPrice=true := by
    apply debitBound (order:=[1,2,3,6,0,4,7,10,5,11,12,8,9]) (ws:=[5154,464,600,248,4225])
    · exact clique_ok_188
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_188_8 : (stageRows 2 196 6422545 3 [6,0,4,10,5,11,9] [134,4360]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6422545 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_188_9
  · exact adapt_188_10
  · exact adapt_188_11
  · exact adapt_188_12
  · exact adapt_188_13
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_188_3 : (stageRows 2 196 6422545 4 [3,6,0,4,10,5,11,12,8,9] [134]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6422545 (some 3)).all ([8,12,264,4104,4360] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · exact adapt_188_4
  · exact adapt_188_5
  · exact adapt_188_6
  · exact adapt_188_7
  · exact adapt_188_8
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_188_0 : (stageRows 2 196 6422545 5 [1,2,3,6,0,4,7,10,5,11,12,8,9] []).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 6422545 (some 1)).all ([2,6,66,130,134] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[1,2,3,6,0,4,7,10,5,11,12,8,9]) (ws:=[5154,464,600,248,4225])
    · exact clique_ok_188
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[1,2,3,6,0,4,7,10,5,11,12,8,9]) (ws:=[5154,464,600,248,4225])
    · exact clique_ok_188
    · decide +kernel
    · decide +kernel
  · exact adapt_188_1
  · exact adapt_188_2
  · exact adapt_188_3
end Research.H1Cover
