import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_50 : ([2571,248,2433,585,2216] : List Nat).all (cliqueValid 397632 [0,4,1,2,3,5,7,6,10,11,9,8,12])=true := by decide +kernel
end Research.H1Cover
