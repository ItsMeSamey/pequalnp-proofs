import H1CoverDebitRoot9822
namespace Research.H1Cover
theorem clique_ok_282 : ([1128,2433,248,1349,5156] : List Nat).all (cliqueValid 100664832 [0,1,2,4,5,6,3,7,10,11,12,8,9])=true := by decide +kernel
end Research.H1Cover
