import H1CoverAdapt434Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_1 : (stageRows 68 514 352322577 4 [1,2,3,6,5,8,11,12,7,9,4,10] [1]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_2 : (stageRows 68 514 352322577 4 [1,2,3,6,5,8,11,12,7,9,10] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_434_3 : (stageRows 68 514 352322577 4 [1,2,3,6,8,11,12,7,9,4,10] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,5,8,11,12,7,9,4,10]) (ws:=[2571,1348,2216,5154,1128])
    · exact clique_ok_434
    · decide +kernel
    · decide +kernel
end Research.H1Cover
