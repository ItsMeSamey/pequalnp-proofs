import H1CoverAdapt152Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_152_2 : (stageRows 120 256 5249088 4 [3,5,2,10,11,1,6,8,9,12,7] [17]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_152
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_152_4 : (stageRows 120 256 5249088 3 [4,2,10,11,1,6,8,9,12,7] [33,8]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_152
    · decide +kernel
    · decide +kernel
end Research.H1Cover
