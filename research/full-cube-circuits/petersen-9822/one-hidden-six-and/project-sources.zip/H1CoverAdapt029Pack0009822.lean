import H1CoverAdapt029Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_2 : (stageRows 192 548 116512 3 [2,3,6,5,12,11,8,10,9] [17,130]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_4 : (stageRows 192 548 116512 2 [6,5,12,11,8,10,9] [17,134,8]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_5 : (stageRows 192 548 116512 2 [6,5,12,11,8,10,9] [17,134,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_29_6 : (stageRows 192 548 116512 2 [6,5,12,11,10,9] [17,134,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,1,2,3,6,4,7,5,12,11,8,10,9]) (ws:=[248,5123,2432,2216,340])
    · exact clique_ok_29
    · decide +kernel
    · decide +kernel
end Research.H1Cover
