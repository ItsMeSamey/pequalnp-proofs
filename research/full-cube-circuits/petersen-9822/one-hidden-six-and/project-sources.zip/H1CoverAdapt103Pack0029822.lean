import H1CoverAdapt103Data9822
import H1CoverAdapt103Pack0009822
import H1CoverAdapt103Pack0019822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_103_2 : (stageRows 144 516 1114784 4 [6,3,1,2,11,12,5,8,10,7,9] [17]).all fixedPrice=true := by
  apply stageStep
  intro m hm
  have cert : (choicesAt 1114784 (some 6)).all ([64,66,2112,4160,6208] : List Nat).contains=true := by decide +kernel
  have mem := List.contains_iff_mem.mp (List.all_eq_true.mp cert m hm)
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · apply debitBound (order:=[0,6,3,4,1,2,11,12,5,8,10,7,9]) (ws:=[5156,2307,1283,2433,2309])
    · exact clique_ok_103
    · decide +kernel
    · decide +kernel
  · exact adapt_103_3
  · exact adapt_103_4
end Research.H1Cover
