import H1CoverAdapt158Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_9 : (stageRows 48 385 5771532 2 [1,9,2,7,8,12,3] [33,3088,64]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_10 : (stageRows 48 385 5771532 2 [9,2,7,8,12,3] [33,3088,66]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_11 : (stageRows 48 385 5771532 2 [1,9,2,7,8,12,3] [33,3088,2112]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_158_12 : (stageRows 48 385 5771532 2 [1,9,2,7,8,3] [33,3088,4160]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,6,1,10,11,9,2,7,8,12,3]) (ws:=[2565,1283,4225,5154,2433])
    · exact clique_ok_158
    · decide +kernel
    · decide +kernel
end Research.H1Cover
