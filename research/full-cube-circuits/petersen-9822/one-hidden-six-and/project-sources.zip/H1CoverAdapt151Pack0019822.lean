import H1CoverAdapt151Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_5 : (stageRows 56 256 5247040 3 [4,10,11,1,6,8,9,12,7] [33,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_6 : (stageRows 56 256 5247040 3 [4,2,10,11,1,6,9,12,7] [33,264]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_7 : (stageRows 56 256 5247040 3 [4,2,10,11,1,6,8,9,7] [33,4104]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_151_9 : (stageRows 56 256 5247040 2 [2,10,1,6,9,7] [33,4360,2064]).all fixedPrice=true := by
    apply debitBound (order:=[0,3,4,5,2,10,11,1,6,8,9,12,7]) (ws:=[2571,1345,5154,2433,585])
    · exact clique_ok_151
    · decide +kernel
    · decide +kernel
end Research.H1Cover
