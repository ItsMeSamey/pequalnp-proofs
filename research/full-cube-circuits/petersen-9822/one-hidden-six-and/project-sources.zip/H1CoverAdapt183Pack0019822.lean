import H1CoverAdapt183Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_2 : (stageRows 192 768 6295040 4 [2,3,1,4,6,7,8,12,9,11,10] [33]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_4 : (stageRows 192 768 6295040 3 [1,5,6,7,8,12,9] [3089,12]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_183_5 : (stageRows 192 768 6295040 3 [3,1,5,6,8,12,9] [3089,132]).all fixedPrice=true := by
    apply debitBound (order:=[0,2,3,1,4,5,6,7,8,12,9,11,10]) (ws:=[464,600,4272,248,2090])
    · exact clique_ok_183
    · decide +kernel
    · decide +kernel
end Research.H1Cover
