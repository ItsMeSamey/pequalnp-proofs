import H1CoverAdapt008Data9822
namespace Research.H1Cover
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_15 : (stageRows 40 272 77890 2 [3,9,7,8,12] [33,3088,70]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
set_option maxRecDepth 12000 in
set_option maxHeartbeats 4000000 in
theorem adapt_8_16 : (stageRows 40 272 77890 2 [3,9,8,12,6] [33,3088,134]).all fixedPrice=true := by
    apply debitBound (order:=[0,4,5,2,3,9,10,11,1,7,8,12,6]) (ws:=[2571,2433,1283,4225,577])
    · exact clique_ok_8
    · decide +kernel
    · decide +kernel
end Research.H1Cover
