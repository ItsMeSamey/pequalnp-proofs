from pathlib import Path
import json,re,ast,hashlib
d=json.load(open('h1joined-manifest.json'))['modules']; src=lambda n:Path(d[n]['source']).read_text()
g={int(k):ast.literal_eval(v) for k,v in re.findall(r'^  \| (\d+) => (\[.*\])',src('H1CoverPositive5989822'),re.M)}
rows={}
for m in d:
 if m.startswith('H1Cover'):
  for i,a,b,h,order in re.findall(r'theorem rail_(\d+) : \(directRows (\d+) (\d+) (\d+) (\[.*?\])\).all fixedPrice',src(m)):
   rows[int(i)]=(int(a),int(b),int(h),ast.literal_eval(order))
for m in d:
 if m.startswith("H1Cover"):
  for a,b,h,order in re.findall(r"theorem direct0 : \(directRows (\d+) (\d+) (\d+) (\[.*?\])\).all fixedPrice",src(m)):
   rows[0]=(int(a),int(b),int(h),ast.literal_eval(order))
seen=set()
for a,bs in g.items():
 m=f'H1CoverDirectDispatchA{a:04d}9822';s=src(m)
 ls=re.search(r'apply dispatchArm \d+ (\[.*?\])',s)
 if ls:assert bs==ast.literal_eval(ls[1])
 else:assert bs==[int(k) for k in re.findall(r'private theorem at_\d+_(\d+) : charged',s)]
 ids=list(map(int,re.findall(r'chargedAt rail_(\d+)',s)));assert len(ids)==len(bs)
 for i,b in zip(ids,bs):
  aa,bb,h,order=rows[i];assert (aa,bb)==(a,b) and all(0<=j<13 for j in order)
  assert (a,b) not in seen;seen.add((a,b))
assert len(seen)==598
print(len(g),len(seen))
