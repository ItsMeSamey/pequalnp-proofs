import H1CoverDispatchBlock09822
import H1CoverDispatchBlock19822
import H1CoverDispatchBlock29822
import H1CoverDispatchBlock39822
import H1CoverDispatchBlock49822
import H1CoverDispatchBlock59822
import H1CoverDispatchBlock69822
import H1CoverDispatchBlock79822
namespace Research.H1Cover
theorem allCharged {a b : Nat} (small : a<1024) (ok : b∈survivingB a) : charged a b := by
  let p := a/16
  let i : Fin 16 := ⟨a%16,by omega⟩
  have eq : 16*p+i.val=a := by dsimp [p,i];omega
  have pick : ∀ b∈survivingB (16*p+i.val),charged (16*p+i.val) b := by
    have range : p<64 := by dsimp [p];omega
    have choices : (0 ≤ p ∧ p<8) ∨ (8 ≤ p ∧ p<16) ∨ (16 ≤ p ∧ p<24) ∨ (24 ≤ p ∧ p<32) ∨ (32 ≤ p ∧ p<40) ∨ (40 ≤ p ∧ p<48) ∨ (48 ≤ p ∧ p<56) ∨ (56 ≤ p ∧ p<64) := by omega
    rcases choices with h|h|h|h|h|h|h|h
    · exact pages_0 p h.1 h.2 i
    · exact pages_1 p h.1 h.2 i
    · exact pages_2 p h.1 h.2 i
    · exact pages_3 p h.1 h.2 i
    · exact pages_4 p h.1 h.2 i
    · exact pages_5 p h.1 h.2 i
    · exact pages_6 p h.1 h.2 i
    · exact pages_7 p h.1 h.2 i
  rw [eq] at pick
  exact pick b ok
end Research.H1Cover
#print axioms Research.H1Cover.allCharged
