#define main unused_prefix_scan
#include "prefix_scan.cpp"
#undef main
#include <array>
#include <fstream>
#include <map>
#include <set>
int safeRaw[65536],neighbors[10];
using Seg=pair<int,int>;
struct Catalog {map<int,vector<Seg>> choices; vector<int> masks,tail; vector<array<int,5>> covers;};
Catalog catalog(U h){
 Catalog cat;set<Seg> seen;
 auto row=[&](int a){return raw[a&1023]|((a&1024)?h:0);};
 auto accept=[&](int a,int b){
   if(a>b)swap(a,b);if(!seen.insert({a,b}).second)return;
   U f=row(a)&row(b);if(f&&!(f>>13))cat.choices[f].push_back({a,b});};
 int safe=safeRaw[h>>13];
 for(int s=safe;s;s=(s-1)&safe)accept(1024,s);
 for(int c=0;c<10;c++){int bit=1<<c;
   for(int s=neighbors[c];s;s=(s-1)&neighbors[c]){
     accept(bit,s);accept(bit|1024,s);accept(bit,s|1024);
   }}
 for(auto &[m,choices]:cat.choices)cat.masks.push_back(m);
 sort(cat.masks.begin(),cat.masks.end(),[](int a,int b){return popcount(unsigned(a))!=popcount(unsigned(b)) ? popcount(unsigned(a))>popcount(unsigned(b)) : a<b;});
 int n=cat.masks.size();cat.tail.assign(n+1,0);
 for(int i=n-1;i>=0;i--)cat.tail[i]=cat.tail[i+1]|cat.masks[i];
 array<int,5> b;
 auto visit=[&](auto&&self,int start,int depth,int covered)->void{
   if(depth==5){if(covered==8191)cat.covers.push_back(b);return;}
   if(start+5-depth>n||(covered|cat.tail[start])!=8191)return;
   int remaining=popcount((unsigned)(8191^covered));
   for(int i=start;i+5-depth<=n;i++){
     int m=cat.masks[i];
     if(popcount(unsigned(m))*(5-depth)<remaining)break;
     if((m&~covered)==0)continue;
     b[depth]=m;
     self(self,i+1,depth+1,covered|m);
   }
 };
 visit(visit,0,0,0);return cat;
}
long long countCfg=0,maskCnt=0,tails=0;set<vector<int>> uniq;
bool priced(const vector<int>&s){
 vector<int> forced,remain,price;
 for(int x:s)if(popcount(unsigned(x))==2)forced.push_back(x);
 if(forced.size()>7)return false;
 for(int x:s)if(popcount(unsigned(x))>2){
   int cc[11];for(int i=0;i<11;i++)cc[i]=i;
   auto root=[&](int i){while(cc[i]!=i)i=cc[i];return i;};
   int rank=popcount(unsigned(x))-1;
   for(int e:forced)if(!(e&~x)){
     int i=root(countr_zero(unsigned(e))),j=root(31-countl_zero(unsigned(e)));
     if(i!=j){cc[i]=j;rank--;}
   }
   if(rank){remain.push_back(x);price.push_back(rank);}
 }
 int n=remain.size(),budget=7-forced.size();
 auto pack=[&](auto&&self,int pos,int selected,int total)->bool{
   if(total>budget)return true;
   for(int i=pos;i<n;i++){
     bool compatible=true;
     for(int j=0;j<i;j++)if(selected>>j&1 && popcount(unsigned(remain[i]&remain[j]))>1){compatible=false;break;}
     if(compatible&&self(self,i+1,selected|(1<<i),total+price[i]))return true;
   }return false;
 };
 return !pack(pack,0,0,0);
}
int main(int argc,char**argv){
 bool stream=argc==2&&string(argv[1])=="--stream";
 bool control=false;
 info();for(int n=0;n<65536;n++){int all=0;for(int k=0;k<16;k++)if(n>>k&1)all|=N[k];safeRaw[n]=1023^all;}
 for(int c=0;c<10;c++)for(int e:edges)if(e>>c&1)neighbors[c]|=e^(1<<c);
 ifstream in("six-one-prefix.tsv");ofstream out("six-one-support.tsv");int a,b;U h,last=~0u;Catalog cat;long long Hs=0;
 while(in>>a>>b>>h){
  if(h!=last){cat=catalog(h);last=h;Hs++;}
  for(auto cc:cat.covers){
   maskCnt++;vector<Seg> terms;
   auto extend=[&](auto&&self,int k)->void{
    if(k==5){countCfg++;
      auto ordered=terms;sort(ordered.begin(),ordered.end());
      vector<Seg> reference={{16,521},{32,129},{128,516},{104,256},{514,1088}};sort(reference.begin(),reference.end());
      if(a==4&&b==18&&ordered==reference)control=true;
      if(stream){cout<<a<<'\t'<<b<<'\t'<<h;for(auto [l,r]:ordered)cout<<'\t'<<l<<'\t'<<r;cout<<'\n';}
      vector<int>s={a,b};for(auto [l,r]:terms){s.push_back(l);s.push_back(r);}erase_if(s,[](int x){return popcount(unsigned(x))<2;});sort(s.begin(),s.end());s.erase(unique(s.begin(),s.end()),s.end());
      if(priced(s)){tails++;if(uniq.insert(s).second){out<<a<<'\t'<<b<<'\t'<<h;for(auto [l,r]:terms)out<<'\t'<<l<<'\t'<<r;out<<'\n';}}
      return;}
    for(auto s:cat.choices[cc[k]]){terms.push_back(s);self(self,k+1);terms.pop_back();}
   };extend(extend,0);
  }
 }
 cerr<<"H signatures "<<Hs<<" physical-mask covers "<<maskCnt<<" actual-source tuples "<<countCfg<<" coarse price <=7 "<<tails<<" distinct remaining support families "<<uniq.size()<<" positive control "<<control<<endl;
 if(!control||tails) return 2;
}
