# Original six-AND, one-hidden branch

Read six-one-proof.md and six-one-hidden-physical.md. This is a self-contained native numerical and mathematical packet, pending a Lean compilation.

From this directory compile with g++ -std=c++20 -O3 six_one_prefix.cpp -o /tmp/six1prefix and g++ -std=c++20 -O3 six_one_scopes.cpp -o /tmp/six1scopes. Run /tmp/six1prefix then /tmp/six1scopes. Run /tmp/six1scopes --stream | sha256sum to verify b2f3644aa3cb2b567146eee6ef06cf67e6a703f20a2484ad8bf96019813721a4. Independently run python3 audit/six_h1_price_audit.py. Its imports recompute the prefix and its own catalogue. The optional audit/six_h1_fixture.py requires python-sat. Imports were made relative to this packet. The independent numerical logic is unchanged.

The separate five-AND dependency is the unrestricted OR-count theorem for this same ten-raw graph. It is used when the network loses an AND during physical elimination. The five-AND structural replay handles h=0,1,2,3,4. Its separate strict RUP receipts and normalized physical-to-skeleton correspondence belong to that theorem's supplement. The other branch dependency is the six-AND all-exposed lower of twelve ORs proved in six-induced-support.md. Six-AND cost accounting retains original physical shared ORs throughout.
