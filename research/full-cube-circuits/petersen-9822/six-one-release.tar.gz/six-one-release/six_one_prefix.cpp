#define main unused_prefix_scan
#include "prefix_scan.cpp"
#undef main
#include <array>
#include <map>
#include <unordered_map>
#include <fstream>
constexpr int full=8191;
int safeRaw[65536],neighbors[10];
struct Grant {int c,mode,mask;};
struct ArmPair {int a,b;U h;};
vector<Grant> grants(U h){
 int he=h&full,safe=safeRaw[h>>13];
 vector<Grant> out;
 auto add=[&](int c,int mode,int m){if(m)out.push_back({c,mode,m});};
 add(-1,2,he&hot[safe]);
 for(int c=0;c<10;c++){
  add(c,0,hot[1<<c]);
  add(c,1,(hot[1<<c]|he)&hot[neighbors[c]&safe]);
 }
 return out;
}
int minCover(vector<int> v){
 vector<int> d(8192,99);d[0]=0;
 for(int t:v)for(int f=full;f>=0;--f)if(d[f]<5) d[f|t]=min(d[f|t],d[f]+1);
 return d[full];
}
int main(){
 info();for(int n=0;n<65536;n++){int all=0;for(int k=0;k<16;k++)if(n>>k&1)all|=N[k];safeRaw[n]=1023^all;}
 for(int c=0;c<10;c++)for(int e:edges)if(e>>c&1)neighbors[c]|=e^(1<<c);
 map<U,vector<ArmPair>> pairs;
 long long eligible=0;
 for(int a=1;a<1024;a++)for(int b=a;b<1024;b++){
   if(popcount((unsigned)(a&b))>1 || popcount((unsigned)a)+popcount((unsigned)b)>9)continue;
   U h=raw[a]&raw[b];if(!(h>>13))continue;eligible++;pairs[h].push_back({a,b,h});
 }
 ofstream candidates("six-one-prefix.tsv");
 long long covered=0,choices=0,cheap=0,old=0;map<unsigned,long long> common;
 vector<int> centerGrants;for(int c=0;c<1024;c++)if(popcount((unsigned)c)==5)centerGrants.push_back(hot[c]);
 for(auto &[h,inputs]:pairs){
  int he=h&full,base=he&hot[safeRaw[h>>13]];
  if(!any_of(centerGrants.begin(),centerGrants.end(),[&](int m){return (m|base)==full;}))continue;
  cheap++;
  auto g=grants(h);vector<int> maximal;
  for(auto x:g){if(any_of(g.begin(),g.end(),[&](Grant y){return x.mask!=y.mask&&(x.mask&~y.mask)==0;}))continue;
   if(find(maximal.begin(),maximal.end(),x.mask)==maximal.end())maximal.push_back(x.mask);}
  int d=minCover(maximal);
  if(d>5)continue;
  if(d<5)old++;
  covered++;choices+=inputs.size();
  for(auto p:inputs){common[popcount((unsigned)(p.a&p.b))]++;candidates<<p.a<<'\t'<<p.b<<'\t'<<h<<'\n';}
 }
 cout<<"original-six one-hidden five-terminals, raw-pairs "<<eligible<<" distinct-h "<<pairs.size()
 <<" cheap H "<<cheap<<" five-cover H "<<covered<<" physical H pairs "<<choices<<" fewer-than-five H "<<old
 <<" shared raw histogram "<<common[0]<<' '<<common[1]<<endl;
}
