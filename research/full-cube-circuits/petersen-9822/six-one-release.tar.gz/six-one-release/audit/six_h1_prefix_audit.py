from functools import lru_cache
from itertools import combinations
from pathlib import Path
E=[6,24,17,33,66,132,264,528,160,640,576,320,288]
N=[m for m in range(1024) if all(m&e!=e for e in E) and all(any((m|1<<i)&e==e for e in E) for i in range(10) if not m>>i&1)]
F=8191
T=[sum(1<<j for j,r in enumerate(E+N) if r&m) for m in range(1024)]
B=[sum(e^(1<<c) for e in E if e>>c&1) for c in range(10)]
@lru_cache(None)
def safe(n):return sum(1<<c for c in range(10) if not n&(T[1<<c]>>13))
raw5={T[sum(1<<i for i in c)]&F for c in combinations(range(10),5)}
possible={r for r in range(F+1) if any(not r&~s for s in raw5)}
@lru_cache(None)
def viable(h):
 g=h&F; ok=safe(h>>13); extra=g&T[ok]
 if F^extra not in possible:return False
 grants={extra}
 for c in range(10):
  star=T[1<<c]&F
  grants.update((star,(g|star)&T[B[c]&ok]))
 @lru_cache(None)
 def cover(rest,b):
  if not rest:return True
  if not b:return False
  return any(cover(rest&~m,b-1) for m in grants if m&(rest&-rest))
 return cover(F,5)
found=set()
for a in range(1,1024):
 for b in range(a,1024):
  if (a&b).bit_count()>1 or a.bit_count()+b.bit_count()>9:continue
  h=T[a]&T[b]
  if h>>13 and viable(h):found.add((a,b,h))
path=Path(__file__).resolve().parent.parent / 'six-one-prefix.tsv'
actual={tuple(map(int,l.split())) for l in path.read_text().splitlines()}
assert found==actual,(len(found),len(actual))
print('matched',len(found),'pairs',len({h for _,_,h in found}),'traces')
