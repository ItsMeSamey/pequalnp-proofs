import six_h1_prefix_audit as p
from itertools import combinations
from collections import Counter
def catalog(h):
 src=[p.T[1<<i] for i in range(10)]+[h]
 row=p.T+[v|h for v in p.T]
 masks={}
 for a in range(1,2048):
  if not row[a]&p.F:continue
  n=row[a]>>13
  ok=p.safe(n)|(1024 if not n&(h>>13) else 0)
  b=ok
  while b>=a:
   e=row[a]&row[b]&p.F
   if e:masks.setdefault(e,[]).append((a,b))
   b=(b-1)&ok
 return masks
def cover(masks):
 opts=[[v for v in masks if v>>i&1] for i in range(13)]
 covers=set()
 def go(rest,fam):
  if not rest:
   covers.add(tuple(sorted(fam)));return
  b=5-len(fam)
  if not b:return
  if b==1:
   for v in opts[(rest&-rest).bit_length()-1]:
    if not rest&~v:covers.add(tuple(sorted((*fam,v))))
   return
  eligible=[v for v in masks if (rest&v).bit_count()>=1]
  if sum(sorted(((v&rest).bit_count() for v in eligible),reverse=True)[:b])<rest.bit_count():return
  slot=min((xs for i,xs in enumerate(opts) if rest>>i&1),key=len)
  for v in slot: go(rest&~v,(*fam,v))
 go(p.F,())
 return covers
if __name__=='__main__':
 from math import prod
 by=Counter(h for a,b,h in p.found);tot=[0,0,0]
 for h,k in by.items():
  m=catalog(h); cs=cover(m)
  assert all(len(c)==5 for c in cs)
  tot[0]+=k*len(m);tot[1]+=k*len(cs);tot[2]+=k*sum(prod(len(m[v]) for v in c) for c in cs)
 print('feature masks, covers, physical fixtures',tot)
