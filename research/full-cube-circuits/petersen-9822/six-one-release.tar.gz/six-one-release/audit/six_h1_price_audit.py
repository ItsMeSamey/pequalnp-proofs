from six_h1_scopes_audit import p,catalog,cover
from collections import defaultdict,Counter
from itertools import product
import sys
from or_support_graph import support_graph
by=defaultdict(list)
for a,b,h in p.found:by[h].append((a,b))
tot=Counter(); regression=False
a0,b0=4,18
pairs0={(16,521),(32,129),(128,516),(104,256),(514,1088)}
for h,ab in by.items():
 ms=catalog(h)
 for c in cover(ms):
  for t in product(*(ms[v] for v in c)):
   for a,b in ab:
    scopes=[a,b]+[v for pair in t for v in pair]
    g=support_graph(scopes,7)
    tot[g is not None]+=1
    if (a,b)==(a0,b0) and set(t)==pairs0:regression=True
    if g is not None:print('seven-edge feasible',scopes,g,flush=True)
assert regression
print('priced',tot,'known signed example recovered')
