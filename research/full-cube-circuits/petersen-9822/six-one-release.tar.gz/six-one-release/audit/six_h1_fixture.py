from pysat.formula import CNF,IDPool
from pysat.solvers import Solver
from pysat.card import CardEnc
from itertools import combinations
import sys
from or_support_graph import support_graph
E=[6,24,17,33,66,132,264,528,160,640,576,320,288]
I=[m for m in range(1024) if not any(m&e==e for e in E) and all(any((m|1<<i)&e==e for e in E) for i in range(10) if not m>>i&1)]
p=IDPool();c=CNF()
def conjunction(xs):
 y=p.id()
 for x in xs:c.append([-y,x])
 c.append([y]+[-x for x in xs])
 return y
def disjunction(xs):return -conjunction([-x for x in xs])
def arms(k):return [[p.id() for _ in range(k)] for _ in range(2)]
H=arms(10);T=[arms(11) for _ in range(5)]
def ordinary(arm,m):return [v for i,v in enumerate(arm[:10]) if m>>i&1]
leak=[]
for m in E+I:
 h=conjunction([disjunction(ordinary(arm,m)) for arm in H])
 if m in I:leak.append(h)
 terms=[conjunction([disjunction(ordinary(arm,m)+[conjunction([h,arm[-1]])]) for arm in t]) for t in T]
 if m in E:c.append(terms)
 else:
  for u in terms:c.append([-u])
c.append(leak)
# Deliberately pin one arm and sample a restricted family, never infer universal UNSAT.
for i,u in enumerate(H[0]):c.append([u if i in [1,4] else -u])
c.extend(CardEnc.atmost([v for t in [H]+T for arm in t for v in arm],22,vpool=p).clauses)
with Solver(name='g4',bootstrap_with=c.clauses) as sl:
 ok=sl.solve(); print('restricted semantic example?',ok,flush=True)
 if ok:
  model=set(sl.get_model())
  masks=[sum(1<<i for i,x in enumerate(a) if x in model) for t in [H]+T for a in t]
  print(masks, support_graph(masks),flush=True)
