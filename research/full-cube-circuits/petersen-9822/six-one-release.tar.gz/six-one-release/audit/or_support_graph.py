"""Exact minimum induced-connectivity support up to a given budget of at most seven."""
from itertools import combinations

def connected(mask, edges):
    seen = mask & -mask
    while True:
        old = seen
        for edge in edges:
            if edge & mask == edge and edge & seen:
                seen |= edge
        if old == seen:
            return seen == mask

def local(p, scopes, budget):
    parts = [1<<i for i in range(p.bit_length()) if p>>i&1]
    n = len(parts)
    weights = {a|b:sum(m&(a|b)==a|b for m in scopes) for a,b in combinations(parts,2)}
    edges = sorted((e for e in weights if weights[e]),key=weights.get,reverse=True)
    tree = []
    for e in edges:
        hits = [h for h in parts if h&e]
        if len(hits)==2:
            for h in hits: parts.remove(h)
            parts.append(hits[0]|hits[1])
            tree.append(e)
    if sum(weights[e] for e in tree)==sum(m.bit_count()-1 for m in scopes):
        return tree
    must = [m for m in scopes if m.bit_count()==2]
    possible = [e for e in edges if e not in must]
    for size in range(max(n,len(must)),budget+1):
        for rest in combinations(possible,size-len(must)):
            chosen=must+list(rest)
            if all(connected(m,chosen) for m in scopes): return chosen
    return None

def support_graph(masks,budget=7):
    if not isinstance(budget,int) or not 0<=budget<=7: raise ValueError("invalid budget")
    ms=set(masks)
    if any(not isinstance(m,int) or not 0<=m<65536 for m in ms): raise ValueError("invalid mask")
    scopes=[m for m in ms if m.bit_count()>1]
    parts=[]
    for m in scopes:
        merged=m
        for p in parts[:]:
            if p&m:
                merged|=p
                parts.remove(p)
        parts.append(merged)
    base=sum(p.bit_count()-1 for p in parts)
    if base>budget: return None
    result=[]
    for p in parts:
        base-=p.bit_count()-1
        chosen=local(p,[m for m in scopes if m&p],budget-base-len(result))
        if chosen is None: return None
        result.extend(chosen)
    return result
