import And9822H3OriginalDemand
import And9822H4Closed
import OR9822PrefixMask
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822H2Check
private theorem negative_site : ∀ s : Fin 7, ∀ i : Fin 10, ∃ n : Fin 16,
    rawRow ⟨13+n.val,by omega⟩ = H4Geo.nm s i := by decide +kernel

private theorem positive_site (e : Nat)
    (win : Research.Graph9822.FourSaturation.accepts (H4Geo.raw e)=true) :
    ∃ p : Fin 13, rawRow ⟨p.val,by omega⟩=H4Geo.raw e := by
  have table : ∀ k : Fin 29, Research.Graph9822.FourSaturation.accepts (H4Geo.raw k.val)=true →
      ∃ p : Fin 13, rawRow ⟨p.val,by omega⟩=H4Geo.raw k.val := by decide +kernel
  by_cases small : e<29
  · exact table ⟨e,small⟩ win
  · have zero : H4Geo.raw e=0 := getElem!_neg H4Geo.masks e (by exact small)
    have loses : Research.Graph9822.FourSaturation.accepts 0=false := by decide
    rw [zero,loses] at win
    contradiction

theorem distinct_slots (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B]) :
    encode (firstCol H) ≠ encode (secondCol H Q) := by
  classical
  intro equal
  obtain ⟨slot,dem⟩ := original_demands c H Q R A B hh ht
  let X := armMask H.1
  let Y := armMask H.2
  obtain ⟨s,safe⟩ := H4Tree.choose (H4Geo.respect H4Geo.verified_layout.profile (H4Geo.key X Y))
  choose idx matchRow using negative_site s
  let pick : Fin 10 → Fin 7 := fun i => slot (idx i)
  have dup : ¬Function.Injective pick := by
    intro inj
    have imp := Fintype.card_le_of_injective pick inj
    simp at imp
  unfold Function.Injective at dup
  push_neg at dup
  obtain ⟨i,j,same,ne⟩ := dup
  obtain ⟨e,_,win,cover,trans⟩ := H4Geo.separator H4Geo.verified_layout X Y s i j ne safe
  obtain ⟨p,defp⟩ := positive_site e win
  have raw (v : Fin 10) (on : (rawRow ⟨p.val,by omega⟩).testBit v.val=true) :
      (rawRow ⟨13+(idx i).val,by omega⟩).testBit v.val=true ∨
      (rawRow ⟨13+(idx j).val,by omega⟩).testBit v.val=true := by
    rw [matchRow,matchRow]
    rw [defp] at on
    have bits := congrArg (fun m : Nat => m.testBit v.val) cover
    simpa [Nat.testBit_and,Nat.testBit_or,on] using bits
  have miss : ¬((positive (encode (firstCol H))).testBit p.val=true ∧
      (negative (encode (firstCol H))).testBit (idx i).val=false ∧
      (negative (encode (firstCol H))).testBit (idx j).val=false) := by
    rintro ⟨edge,ileft,jright⟩
    simp only [pos_col_bit,neg_col_bit,first_row,defp,matchRow] at edge ileft jright
    have found := trans edge
    rcases found with h|h
    · exact Bool.noConfusion (ileft.symm.trans h)
    · exact Bool.noConfusion (jright.symm.trans h)
  have force := dem (idx i) (idx j) same p raw miss
  rw [←equal] at force
  exact miss force
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.distinct_slots
