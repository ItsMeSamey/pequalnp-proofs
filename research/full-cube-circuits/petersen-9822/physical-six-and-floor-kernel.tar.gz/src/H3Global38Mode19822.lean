import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g38_1 : global3 5246988 true [37804, 19890, 50417, 891, 52003, 6859, 17819, 1011, 55435, 1914, 28779, 13219, 18289] = true := by decide +kernel
end Research.Graph9822Planes
