import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g15_1 : global3 786481 true [21356, 43111, 38384, 18812, 5990, 39111, 21969, 4583, 16871, 20853, 20966, 21731, 5351, 5603, 5927] = true := by decide +kernel
end Research.Graph9822Planes
