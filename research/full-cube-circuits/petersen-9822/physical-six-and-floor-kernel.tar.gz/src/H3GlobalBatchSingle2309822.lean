import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle230 : List ModeRow := [(378767441,[46620,35899,4335,57909,15414,10471,37023,4223],[46620,15414,7311])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle230 : batchSingle230.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
