import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle132 : List ModeRow := [(125975632,[3135,25045,15414,39197,7227,15375,19515],[15897,11319,25941,19515,13343])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle132 : batchSingle132.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
