import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle165 : List ModeRow := [(180888097,[54860,25367,14479,1017,21969,25799,5215,50387,4815],[54860,13847,43207,21969,5575])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle165 : batchSingle165.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
