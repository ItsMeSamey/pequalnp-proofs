import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle139 : List ModeRow := [(132128320,[16168,4719,3135,13107,5927,5497,6735,7283,10551,1823,3898,4415],[16168,7943,831,15792,1779,2871,6735,4719])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle139 : batchSingle139.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
