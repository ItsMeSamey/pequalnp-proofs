import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g47_0 : global3 6426128 false [62232, 639, 49463, 21913, 21647, 22339, 9139, 50965, 4926, 33639, 45763, 52253] = true := by decide +kernel
end Research.Graph9822Planes
