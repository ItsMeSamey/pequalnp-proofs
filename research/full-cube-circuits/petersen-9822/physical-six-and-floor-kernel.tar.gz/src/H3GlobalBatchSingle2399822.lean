import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle239 : List ModeRow := [(395447377,[48664,12519,36019,22293,15414,39317],[48664,15414,47239,7347])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle239 : batchSingle239.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
