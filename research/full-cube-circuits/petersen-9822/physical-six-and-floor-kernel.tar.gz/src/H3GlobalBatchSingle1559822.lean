import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle155 : List ModeRow := [(176277025,[22062,1529,25383,53279,50235,13491,13622,1439],[22062,53279,18206,1529,25383,1151])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle155 : batchSingle155.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
