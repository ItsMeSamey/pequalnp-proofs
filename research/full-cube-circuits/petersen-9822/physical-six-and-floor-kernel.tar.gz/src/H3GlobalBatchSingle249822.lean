import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle24 : List ModeRow := [(2491014,[37686,1529,31878,11110,12180,50515,13748,19890,983,3191],[37686,1529,19890,10551,16134,11110,13748,8691,1751])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle24 : batchSingle24.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
