import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle191 : List ModeRow := [(286015537,[39778,54609,1470,53303,7619,49502,4951,3198,7478],[39778,3198,21873,51507,49502])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle191 : batchSingle191.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
