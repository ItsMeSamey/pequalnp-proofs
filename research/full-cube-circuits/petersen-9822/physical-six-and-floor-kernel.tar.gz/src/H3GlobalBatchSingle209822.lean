import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle20 : List ModeRow := [(1123232,[11023,5575,15250,35483,59415,13710,43207,8543,2523,43783],[53391,2523,47623,11023,15250,35483,989,59415,35227])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle20 : batchSingle20.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
