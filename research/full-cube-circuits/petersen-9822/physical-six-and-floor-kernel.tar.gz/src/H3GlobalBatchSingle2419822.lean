import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle241 : List ModeRow := [(395545681,[46620,35899,4335,59445,10471,39197,1151,5369],[46620,59445,35899,5369,7311])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle241 : batchSingle241.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
