import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle1 : List ModeRow := [(100096,[45868,49311,12726,5081,41767,12414,4597,4815],[45868,16575,45199,12414,41767,4815,4597,12726,927])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle1 : batchSingle1.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
