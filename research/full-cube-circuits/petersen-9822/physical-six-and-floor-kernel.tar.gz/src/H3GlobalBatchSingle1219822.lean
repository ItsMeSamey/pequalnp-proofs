import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle121 : List ModeRow := [(106716556,[54054,5369,4018,12702,54736,20966,13622],[29410,13622,16017,1785])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle121 : batchSingle121.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
