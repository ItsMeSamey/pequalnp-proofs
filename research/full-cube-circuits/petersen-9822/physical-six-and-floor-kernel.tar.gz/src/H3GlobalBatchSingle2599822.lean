import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle259 : List ModeRow := [(404750534,[62244,52502,15414,58503,22310,59683,55046,50595,25879,30086],[62244,52502,59683,55046,59669,50641,9399,25011])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle259 : batchSingle259.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
