import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle250 : List ModeRow := [(403446528,[55908,49439,14515,21958,26679,43111,47119,14646,6267],[55908,49439,14515,43111,21958,6267,47119])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle250 : batchSingle250.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
