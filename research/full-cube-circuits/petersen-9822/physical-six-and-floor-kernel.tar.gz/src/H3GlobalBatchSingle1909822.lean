import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle190 : List ModeRow := [(285229352,[39694,19890,927,27399,11295,49439,1779],[39694,19890,35483,27399,11295,9999,1779,2491])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle190 : batchSingle190.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
