import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle18 : List ModeRow := [(997698,[3135,57685,6883,831,5617,7478,863,1655,1885],[41337,639,38129,1885,3450,6759])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle18 : batchSingle18.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
