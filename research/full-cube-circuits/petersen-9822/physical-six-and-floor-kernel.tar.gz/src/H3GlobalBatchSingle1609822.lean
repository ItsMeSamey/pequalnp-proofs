import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle160 : List ModeRow := [(177078833,[54392,14535,1470,24919,7478,17207,19571,53335,5564,7283],[54392,47239,1655,5564,11319,7478])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle160 : batchSingle160.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
