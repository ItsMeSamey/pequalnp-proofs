import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle123 : List ModeRow := [(107077152,[45838,23875,20924,25383,16575,24954,4703,5049,43783],[45838,831,12879,12399])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle123 : batchSingle123.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
