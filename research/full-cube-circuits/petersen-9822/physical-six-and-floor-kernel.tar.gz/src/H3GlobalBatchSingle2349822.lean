import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle234 : List ModeRow := [(386928928,[64040,5534,54673,53279,15638,21902,52251,5561],[64040,15638,21902,15507,53279,52251,54673])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle234 : batchSingle234.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
