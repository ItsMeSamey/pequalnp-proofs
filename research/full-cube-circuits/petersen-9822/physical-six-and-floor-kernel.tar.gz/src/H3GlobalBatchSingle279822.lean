import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle27 : List ModeRow := [(3080838,[37244,52267,10639,43811,3870,751,1151,7478,15502,49502],[37244,43811,1854,15502,887,3870,52267])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle27 : batchSingle27.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
