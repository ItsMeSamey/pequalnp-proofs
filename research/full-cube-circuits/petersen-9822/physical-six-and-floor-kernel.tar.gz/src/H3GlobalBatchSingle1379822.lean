import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle137 : List ModeRow := [(126754112,[15928,50517,12399,19515,37181,15431,14415,21845],[15928,26919,21873,14415,12399,21845,1151])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle137 : batchSingle137.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
