import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle135 : List ModeRow := [(126434370,[16200,51441,5663,2671,31920,54481,27187,21621,4719],[16200,15375,19515,4223,31920])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle135 : batchSingle135.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
