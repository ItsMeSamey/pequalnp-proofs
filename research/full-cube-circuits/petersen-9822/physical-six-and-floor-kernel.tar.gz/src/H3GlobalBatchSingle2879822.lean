import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle287 : List ModeRow := [(428888872,[21902,11443,59655,52874,26006,38159],[52874,11698,44167,25871,10639])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle287 : batchSingle287.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
