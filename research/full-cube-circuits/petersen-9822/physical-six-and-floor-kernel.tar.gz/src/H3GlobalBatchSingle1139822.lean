import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle113 : List ModeRow := [(104898702,[45861,20246,25045,5917,11047,7347,5927,4018],[45861,7731,20246,24323,18867,4018])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle113 : batchSingle113.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
