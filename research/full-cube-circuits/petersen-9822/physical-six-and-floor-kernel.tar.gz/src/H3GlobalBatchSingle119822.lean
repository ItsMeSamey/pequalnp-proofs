import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle11 : List ModeRow := [(444034,[33598,3315,33239,5620,10551,2919,1530,255],[33598,1655,36150,3315,447,1017,255])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle11 : batchSingle11.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
