import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle114 : List ModeRow := [(105178270,[45607,1977,11319,13071,24989,10471,4511,9403,21607,5307,8511],[45607,5183,21607])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle114 : batchSingle114.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
