import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle286 : List ModeRow := [(428759880,[53279,11574,21748,52344,49495,3507],[52344,7347,11574,3507])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle286 : batchSingle286.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
