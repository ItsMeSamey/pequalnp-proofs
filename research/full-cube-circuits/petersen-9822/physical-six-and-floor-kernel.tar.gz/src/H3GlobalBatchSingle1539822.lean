import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle153 : List ModeRow := [(176161313,[22316,50267,43207,13406,62486,24330,29459,1823,4447,5974,5497],[22316,64518,4571,50331,13406,29459,43207,5497,24330,13343,1823])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle153 : batchSingle153.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
