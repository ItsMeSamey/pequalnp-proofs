import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle272 : List ModeRow := [(409085584,[49463,21955,45731,17877,17015,49949,17394,33687,37479,1017],[49949,49649,45731,951,16871,4347])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle272 : batchSingle272.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
