import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle181 : List ModeRow := [(269486097,[58028,5587,54550,39111,33687,55431,50270,5022,38102,54357,38099,10695,20695],[58028,38802,26951,21969,55622,38039,33687,5918,17815,38099,54357])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle181 : batchSingle181.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
