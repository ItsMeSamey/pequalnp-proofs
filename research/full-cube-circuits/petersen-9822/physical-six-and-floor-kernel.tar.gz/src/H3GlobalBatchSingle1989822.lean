import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle198 : List ModeRow := [(303839537,[14242,53477,26895,58407,5355,21958,27075,13597,14479],[53477,5355,26895,10471,14242])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle198 : batchSingle198.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
