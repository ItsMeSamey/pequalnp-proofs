import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle127 : List ModeRow := [(108428956,[13234,9039,3315,12575,21287,18867,5617,9063,24887,49943],[13234])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle127 : batchSingle127.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
