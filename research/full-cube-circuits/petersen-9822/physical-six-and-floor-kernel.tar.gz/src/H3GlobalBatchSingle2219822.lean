import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle221 : List ModeRow := [(353960977,[47944,21969,51994,751,27089,927,6867],[47944,27089,43151,50965,21969,2847])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle221 : batchSingle221.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
