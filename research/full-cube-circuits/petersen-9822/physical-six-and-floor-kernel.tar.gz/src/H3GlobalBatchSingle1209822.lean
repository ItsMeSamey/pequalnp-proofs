import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle120 : List ModeRow := [(106200220,[21287,3259,8911,21745,58119,24989,2995,8319,15011,1215],[29347,15011])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle120 : batchSingle120.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
