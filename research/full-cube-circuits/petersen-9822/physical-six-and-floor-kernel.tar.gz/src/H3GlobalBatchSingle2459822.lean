import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle245 : List ModeRow := [(402965698,[49966,17657,21958,35555,41623,17658,19998,1151,18591,53790],[49966,50343,52278,50897,41623,255])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle245 : batchSingle245.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
