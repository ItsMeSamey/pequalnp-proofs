import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle273 : List ModeRow := [(409179920,[54044,13710,41767,27677,20924,9139],[54044,27677,57623])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle273 : batchSingle273.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
