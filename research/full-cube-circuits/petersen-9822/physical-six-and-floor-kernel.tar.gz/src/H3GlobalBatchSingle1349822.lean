import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle134 : List ModeRow := [(126254168,[15928,53587,831,14415,19515,5927,21817,12399],[7227,10551])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle134 : batchSingle134.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
