import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g71_0 : global3 33562913 false [29481, 9623, 29756, 47623, 21775, 21969, 39067, 25879, 13715, 29835, 25751, 17878, 29977] = true := by decide +kernel
end Research.Graph9822Planes
