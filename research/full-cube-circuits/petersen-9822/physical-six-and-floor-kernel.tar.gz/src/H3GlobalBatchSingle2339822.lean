import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle233 : List ModeRow := [(385925262,[53790,43175,19770,7230,12967,47630],[47630,43063,12967,20921])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle233 : batchSingle233.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
