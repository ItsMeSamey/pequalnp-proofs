import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle172 : List ModeRow := [(243385889,[25383,7311,13746,25659,4703,30222,13491,17471,13622],[30222,25659,13622,12399])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle172 : batchSingle172.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
