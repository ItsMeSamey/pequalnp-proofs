import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g40_1 : global3 5771532 true [19192, 41699, 57812, 2010, 52530, 49786, 28913, 17898, 55435, 3954] = true := by decide +kernel
end Research.Graph9822Planes
