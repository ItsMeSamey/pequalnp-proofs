import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle14 : List ModeRow := [(604226,[7230,9835,13853,14563,53351,46289,2655,15414,1785,12922,5735,14367],[9835,37975,14507,28943,15414,2655,12922,1785,49395,2671,46289])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle14 : batchSingle14.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
