import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle174 : List ModeRow := [(244417185,[30252,1017,43207,26394,1529,5279,22279,8991,13343,60423],[30252,17567,1017,12999,24330,1529,8991])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle174 : batchSingle174.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
