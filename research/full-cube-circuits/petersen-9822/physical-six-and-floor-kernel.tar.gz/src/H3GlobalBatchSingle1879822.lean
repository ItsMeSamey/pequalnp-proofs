import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle187 : List ModeRow := [(273688593,[11023,49625,10471,27043,41639,1886,34011,10695,989,8543],[41639,49625,11023,34011,5534,35501])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle187 : batchSingle187.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
