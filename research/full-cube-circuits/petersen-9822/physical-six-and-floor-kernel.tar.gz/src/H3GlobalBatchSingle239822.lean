import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle23 : List ModeRow := [(1900593,[17852,5859,17262,21969,1017,39055,6120,5231,22310,1771],[6120,4335,17852,17262,1771,21969,5927,1529])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle23 : batchSingle23.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
