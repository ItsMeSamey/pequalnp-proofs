import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle278 : List ModeRow := [(409781446,[54054,3870,1017,51507,18236,27427,255,13142],[54054,18236,51507,27427])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle278 : batchSingle278.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
