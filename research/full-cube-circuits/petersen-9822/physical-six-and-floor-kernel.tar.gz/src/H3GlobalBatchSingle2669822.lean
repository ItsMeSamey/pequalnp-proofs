import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle266 : List ModeRow := [(405864646,[53676,11023,27075,7566,9399,41367,11549,21902,2767,24911],[53676,59683,11549,7230,2767])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle266 : batchSingle266.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
