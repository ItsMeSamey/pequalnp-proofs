import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle105 : List ModeRow := [(101828256,[13198,1511,4851,2895,12967,1017,10695,16575,735,8443,831,9127],[13198,4287,41191,10695,1017,735])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle105 : batchSingle105.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
