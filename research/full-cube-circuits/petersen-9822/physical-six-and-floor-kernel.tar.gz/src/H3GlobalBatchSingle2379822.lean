import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle237 : List ModeRow := [(390390943,[45607,2491,14607,10471,5021,6379,11319,12743],[45607])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle237 : batchSingle237.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
