import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle141 : List ModeRow := [(132239200,[14094,3699,11047,4511,15666,3135,3195],[14094])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle141 : batchSingle141.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
