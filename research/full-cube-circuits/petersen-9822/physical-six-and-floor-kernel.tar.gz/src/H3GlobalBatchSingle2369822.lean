import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle236 : List ModeRow := [(386945320,[47882,19890,21895,3315,47267,13718,37151],[47882,47267,21662,26903,23875])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle236 : batchSingle236.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
