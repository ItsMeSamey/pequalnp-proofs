import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle151 : List ModeRow := [(145621041,[25976,39111,37334,3699,17207,49495,3255,7478],[25976,3507,39111,37334])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle151 : batchSingle151.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
