import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle169 : List ModeRow := [(207720481,[29484,50207,43783,5564,14226,53519,5497,8991],[29484,50970,58119,13343,5974,5497])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle169 : batchSingle169.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
