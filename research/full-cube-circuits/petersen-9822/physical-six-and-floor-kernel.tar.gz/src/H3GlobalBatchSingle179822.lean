import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle17 : List ModeRow := [(923968,[3898,57685,14415,4415,3195,7478,9589,1375],[6780,57685,13373,3195,7478,15431,3870,9589,1151])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle17 : batchSingle17.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
