import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle183 : List ModeRow := [(269881696,[35899,42452,14479,8511,37564,7602,3135,1439,12519],[37564,35899,42452,7602,1399,8511])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle183 : batchSingle183.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
