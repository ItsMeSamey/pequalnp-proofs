import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle21 : List ModeRow := [(1164960,[45838,763,10695,4541,12414,9127,831,4335,12967,507],[5038,10695,4815,4511,12414,831,45838,447])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle21 : batchSingle21.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
