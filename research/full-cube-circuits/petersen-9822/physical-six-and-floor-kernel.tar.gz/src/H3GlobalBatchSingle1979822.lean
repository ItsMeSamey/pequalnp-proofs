import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle197 : List ModeRow := [(303052817,[11023,50642,45477,30098,10471,4319,5339,13710],[45477,5339,50642,11023,4319,10471,13710])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle197 : batchSingle197.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
