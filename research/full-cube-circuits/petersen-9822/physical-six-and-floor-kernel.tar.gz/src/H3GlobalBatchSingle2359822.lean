import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle235 : List ModeRow := [(386939921,[14734,51666,47521,59415,22739,11023,26951,31122,6494],[47521,10447,14430,18591,26951,51666,10455])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle235 : batchSingle235.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
