import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle258 : List ModeRow := [(404750406,[62248,7223,30114,54673,47239,41367,59669,21923,5527],[62248,59669,54659,7223,30114,47239,54673,16823])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle258 : batchSingle258.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
