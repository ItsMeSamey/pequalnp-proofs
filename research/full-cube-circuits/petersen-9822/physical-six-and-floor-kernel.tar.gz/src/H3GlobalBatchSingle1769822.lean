import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle176 : List ModeRow := [(246907567,[28988,42197,4783,22293,9783,13455,21745,12943,5183,6065],[28988])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle176 : batchSingle176.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
