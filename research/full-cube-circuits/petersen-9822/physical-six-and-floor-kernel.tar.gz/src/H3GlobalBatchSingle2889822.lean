import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle288 : List ModeRow := [(428988200,[52750,1529,51495,38159,4018,1275,47175,3135,21902,36019],[52750,21902,36019,35047])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle288 : batchSingle288.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
