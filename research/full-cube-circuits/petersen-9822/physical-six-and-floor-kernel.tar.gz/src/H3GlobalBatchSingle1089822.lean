import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle108 : List ModeRow := [(103187086,[13116,51315,12180,21852,14391,4823,59445],[13116,59445,5590,4601,6855,8691,7286])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle108 : batchSingle108.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
