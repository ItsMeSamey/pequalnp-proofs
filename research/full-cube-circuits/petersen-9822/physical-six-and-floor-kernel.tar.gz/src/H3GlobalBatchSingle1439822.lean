import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle143 : List ModeRow := [(132267600,[3898,39197,3911,27677,15792,16152,22293,10551,1779,4719],[16152,22293,6255])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle143 : batchSingle143.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
