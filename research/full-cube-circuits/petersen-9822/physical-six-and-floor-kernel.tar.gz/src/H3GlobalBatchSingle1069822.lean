import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle106 : List ModeRow := [(103154316,[13116,59443,6379,45402,19515,10867,43811,5587,3259,21859],[13116,14769,15666,14539,5587,10867])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle106 : batchSingle106.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
