import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle264 : List ModeRow := [(405342406,[53612,11319,19742,43087,21820,59683,15630,383],[53612,59683,3198,1343,19742])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle264 : batchSingle264.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
