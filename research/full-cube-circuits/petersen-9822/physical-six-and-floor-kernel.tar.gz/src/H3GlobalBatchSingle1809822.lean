import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle180 : List ModeRow := [(260882993,[30246,3322,20695,11047,12631,17207,3287],[30246,19571,2871,5617])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle180 : batchSingle180.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
