import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle253 : List ModeRow := [(403706656,[21902,47251,26895,61834,29078,51231,31122,54407,14494,37782],[61834,54407,26895,29078,14494,51231,14479,37782])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle253 : batchSingle253.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
