import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle192 : List ModeRow := [(286282024,[27022,33750,11443,59655,51866,26006],[51866,11698,26951,47267,50567,9503])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle192 : batchSingle192.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
