import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle118 : List ModeRow := [(105943182,[22310,43797,27078,45988,7734,5015,47239,7602,12695],[45988,7734,15750,6941,7602,47239])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle118 : batchSingle118.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
