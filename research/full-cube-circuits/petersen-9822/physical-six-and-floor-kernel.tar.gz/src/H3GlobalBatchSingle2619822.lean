import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle261 : List ModeRow := [(405062854,[49966,50417,22342,43315,33487,1530,19742,19727],[49966,17846,19727,16631,17881,33007])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle261 : batchSingle261.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
