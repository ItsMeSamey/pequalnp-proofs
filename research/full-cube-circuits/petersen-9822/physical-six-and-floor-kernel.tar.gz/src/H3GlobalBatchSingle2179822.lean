import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle217 : List ModeRow := [(353125425,[52275,45402,5617,47714,15411,11574,2519,1470],[47714,52275,54609,5617])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle217 : batchSingle217.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
