import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle265 : List ModeRow := [(405736134,[49502,11059,50417,20924,8815,10527,7478,57720],[57720,49502,50417,2671])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle265 : batchSingle265.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
