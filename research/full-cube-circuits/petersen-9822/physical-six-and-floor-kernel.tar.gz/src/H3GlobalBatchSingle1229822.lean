import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle122 : List ModeRow := [(106962432,[45880,4719,24887,53713,22339,29106,49215,61455,21287,29011,49978,8823],[45880,21287,12879,49978,29011,31152,12351,53713])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle122 : batchSingle122.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
