import H3GlobalPages9822
import H3Global15Mode09822
import H3Global15Mode19822
namespace Research.Graph9822Planes
def batchSingle15 : List ModeRow := [(786481,[21356,43111,21969,18215,5990,39111,21820,20966,5617,21731,4583,16871,20853,22310,5351,17767,21859],[21356,43111,38384,18812,5990,39111,21969,4583,16871,20853,20966,21731,5351,5603,5927])]
theorem paidBatchSingle15 : batchSingle15.all rowOK = true := by
  change ((global3 _ false _ && global3 _ true _) && true) = true
  exact Bool.and_eq_true_iff.mpr ⟨Bool.and_eq_true_iff.mpr ⟨g15_0,g15_1⟩,rfl⟩
end Research.Graph9822Planes
