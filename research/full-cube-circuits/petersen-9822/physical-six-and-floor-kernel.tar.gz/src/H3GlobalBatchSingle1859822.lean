import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle185 : List ModeRow := [(270272561,[53988,21937,51014,21969,6128,50145,54566,27399],[53988,38115,50145,27106,33255,27399,6128,18215])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle185 : batchSingle185.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
