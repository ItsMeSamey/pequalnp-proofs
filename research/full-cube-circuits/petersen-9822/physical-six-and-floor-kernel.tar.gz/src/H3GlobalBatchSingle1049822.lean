import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle104 : List ModeRow := [(101810848,[13228,51231,10695,4601,12999,14430,43783,21703,4541],[13228,43207,14367,35738,4601,43783,4541,14430,479])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle104 : batchSingle104.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
