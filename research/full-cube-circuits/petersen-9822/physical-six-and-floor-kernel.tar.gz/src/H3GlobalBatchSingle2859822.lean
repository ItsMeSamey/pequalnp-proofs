import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle285 : List ModeRow := [(428628744,[52778,21958,12399,26919,11443,13583,1343],[52778,43111,21958,13583,3507])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle285 : batchSingle285.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
