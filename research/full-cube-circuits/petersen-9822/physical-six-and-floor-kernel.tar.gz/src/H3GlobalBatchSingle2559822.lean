import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle255 : List ModeRow := [(404099936,[53436,19515,12519,43175,14770,4511,57558,3135],[53436,19515,43175,9399,14770])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle255 : batchSingle255.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
