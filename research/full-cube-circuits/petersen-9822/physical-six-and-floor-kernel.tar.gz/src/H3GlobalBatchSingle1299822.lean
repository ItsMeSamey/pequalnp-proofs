import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle129 : List ModeRow := [(117498145,[19515,15111,25045,3570,20767,3259,447,26931],[15111,11319,3570,20767])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle129 : batchSingle129.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
