import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle117 : List ModeRow := [(105694606,[13086,20969,10471,7478,17199,12523,8679,14535,12519,510,21287],[29286,13086,10471,5097])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle117 : batchSingle117.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
