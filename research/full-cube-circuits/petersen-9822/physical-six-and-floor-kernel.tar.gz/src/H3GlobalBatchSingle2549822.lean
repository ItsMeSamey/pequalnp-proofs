import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle254 : List ModeRow := [(403822368,[21902,57399,16890,10575,41191,12726,53902,45235,57639],[53902,57399,10575,21902,4347,57639])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle254 : batchSingle254.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
