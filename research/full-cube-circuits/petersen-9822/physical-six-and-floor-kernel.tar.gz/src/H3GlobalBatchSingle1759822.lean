import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle175 : List ModeRow := [(245530766,[30476,3255,16829,9111,60437,19635,22293,7223,6823],[30476,60437,10551,14226,14503,4823])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle175 : batchSingle175.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
