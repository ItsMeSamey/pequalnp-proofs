import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle12 : List ModeRow := [(512320,[37438,5593,26919,3231,12575,1275,5558,10478],[37438,1151,49502,4415,10478,11319,4335,5183])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle12 : batchSingle12.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
