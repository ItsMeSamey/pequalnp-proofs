import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle195 : List ModeRow := [(295063912,[36410,45522,15431,38297,38062,43111,1343,47143],[36410,43175,5561,45522])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle195 : batchSingle195.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
