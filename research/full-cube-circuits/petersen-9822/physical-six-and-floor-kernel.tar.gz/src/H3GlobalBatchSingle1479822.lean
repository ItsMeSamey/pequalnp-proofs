import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle147 : List ModeRow := [(140625953,[21294,5811,33687,17786,49959,18206,21814,4511,4895],[21294,18206,33687,49959,4895])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle147 : batchSingle147.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
