import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle100 : List ModeRow := [(101288002,[45900,11319,20669,42197,751,7395,5351],[45900,12399,15502,3706,20669,255,10471])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle100 : batchSingle100.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
