import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle166 : List ModeRow := [(180888353,[54860,43207,13343,1017,25799,927,50387],[54860,13847,21969,43207,25799,5279])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle166 : batchSingle166.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
