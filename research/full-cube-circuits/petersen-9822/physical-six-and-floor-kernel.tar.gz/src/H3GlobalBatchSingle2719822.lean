import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle271 : List ModeRow := [(409077264,[54042,751,52253,20921,4919,20918,17255,12979,1017,21955],[54042,52253,12979,16871,20918,17255,1017])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle271 : batchSingle271.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
