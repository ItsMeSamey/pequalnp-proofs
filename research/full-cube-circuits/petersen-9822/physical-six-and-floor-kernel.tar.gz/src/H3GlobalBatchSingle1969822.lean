import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle196 : List ModeRow := [(303051041,[27399,38043,30098,53669,33687,18386,13343,13971,58391],[53669,38043,11023,18386,21745,33687,27399])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle196 : batchSingle196.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
