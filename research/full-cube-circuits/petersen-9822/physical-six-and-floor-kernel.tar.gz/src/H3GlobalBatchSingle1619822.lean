import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle161 : List ModeRow := [(177275553,[22188,43207,1017,13343,18330,64518,25679,17183,975],[22188,5617,64518,17183,24330,43207,13343])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle161 : batchSingle161.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
