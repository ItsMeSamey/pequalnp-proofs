import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle16 : List ModeRow := [(809224,[17726,39111,34666,50521,18791,28943,19766,3315],[34666,19890,18791,50641,28943,25885,3135,39111])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle16 : batchSingle16.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
