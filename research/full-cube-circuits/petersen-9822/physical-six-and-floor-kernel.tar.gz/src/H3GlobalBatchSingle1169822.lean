import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle116 : List ModeRow := [(105506336,[45646,5049,8663,20711,831,8443,41191,14479],[45646,12351,751])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle116 : batchSingle116.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
