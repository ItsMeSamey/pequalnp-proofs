import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle130 : List ModeRow := [(125836352,[32296,4719,19515,10807,21625,15922,12351,22309,5335],[32296,15375,52757,15417,10807,21625,15922,2671,4719,16003])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle130 : batchSingle130.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
