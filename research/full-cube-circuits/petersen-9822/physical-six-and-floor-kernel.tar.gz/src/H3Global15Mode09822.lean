import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g15_0 : global3 786481 false [21356, 43111, 21969, 18215, 5990, 39111, 21820, 20966, 5617, 21731, 4583, 16871, 20853, 22310, 5351, 17767, 21859] = true := by decide +kernel
end Research.Graph9822Planes
