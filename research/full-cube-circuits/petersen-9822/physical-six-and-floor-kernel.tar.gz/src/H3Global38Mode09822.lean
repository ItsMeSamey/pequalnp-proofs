import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g38_0 : global3 5246988 false [19890, 37804, 50417, 891, 52003, 6859, 17819, 28779, 1914, 1011, 17905, 55435] = true := by decide +kernel
end Research.Graph9822Planes
