import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle214 : List ModeRow := [(336693265,[45724,26951,30098,58397,4319,13343,41191,29974],[45724,26951,58397,41191,29974,5279])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle214 : batchSingle214.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
