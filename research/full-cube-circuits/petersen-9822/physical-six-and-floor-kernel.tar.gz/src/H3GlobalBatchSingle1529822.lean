import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle152 : List ModeRow := [(174072097,[54027,26005,14479,58391,5049,39619,21955,47623,13343,49649],[54027,26005,21955,13197,1823,38099,13343])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle152 : batchSingle152.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
