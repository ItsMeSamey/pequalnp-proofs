import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle107 : List ModeRow := [(103171724,[13114,4815,8663,1529,9063,19515,12967,863,1779],[13114,13622,14769,1779])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle107 : batchSingle107.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
