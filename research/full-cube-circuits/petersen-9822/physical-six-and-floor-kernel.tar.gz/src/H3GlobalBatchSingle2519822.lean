import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle251 : List ModeRow := [(403577664,[53372,11319,47119,49495,19515,43111,14646,1151],[53372,19515,43111,47119,1151,2423])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle251 : batchSingle251.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
