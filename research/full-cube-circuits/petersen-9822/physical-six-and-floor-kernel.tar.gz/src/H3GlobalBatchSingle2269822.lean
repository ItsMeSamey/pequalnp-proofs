import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle226 : List ModeRow := [(357575825,[11038,43689,751,11079,52114,27089,22683,31122,10471],[43689,10695,52114,27089,11023])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle226 : batchSingle226.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
