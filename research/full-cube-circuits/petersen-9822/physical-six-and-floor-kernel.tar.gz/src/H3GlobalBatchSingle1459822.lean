import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle145 : List ModeRow := [(132726338,[3898,47273,16200,10551,38353,1823,4719,5927,1779,15792],[16200])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle145 : batchSingle145.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
