import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle154 : List ModeRow := [(176169761,[54287,27399,13467,29974,50331,26005,13343,17695],[54287,26005,23691,27399,29837,13343,5575,13467,29719])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle154 : batchSingle154.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
