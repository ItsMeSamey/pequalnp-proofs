import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle13 : List ModeRow := [(591938,[15414,53868,12979,14479,27165,46289,5358,3706,1599,14899],[53868,11319,12979,14479,5369,46289,4734,27165,5358,15414,3706,14899])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle13 : batchSingle13.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
