import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle19 : List ModeRow := [(1114784,[13228,51231,43207,4601,8543,35738,43783,14430,863,4541],[13228,51231,4601,43207,35738,4511,43783,14430,4541,983])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle19 : batchSingle19.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
