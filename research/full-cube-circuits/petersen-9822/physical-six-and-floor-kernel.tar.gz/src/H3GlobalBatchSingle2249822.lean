import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle224 : List ModeRow := [(356525201,[43817,2910,10471,2009,64784,22979,51994,57375,6867,10335],[43817,10471,64784,927,44124,2767,19410,22979])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle224 : batchSingle224.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
