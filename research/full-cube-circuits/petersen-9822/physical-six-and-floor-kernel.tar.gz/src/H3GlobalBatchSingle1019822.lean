import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle101 : List ModeRow := [(101457152,[1854,45255,46440,49463,54449,13746,20839,50235,13622,12575],[46440,12575,50235,13746,20839,54449])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle101 : batchSingle101.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
