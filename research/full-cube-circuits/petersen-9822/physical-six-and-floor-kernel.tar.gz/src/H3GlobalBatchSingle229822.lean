import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle22 : List ModeRow := [(1173408,[831,13710,45731,57399,763,11023,1511,9127,507,41191,53391],[53391,751,13710,447,11023,255])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle22 : batchSingle22.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
