import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle193 : List ModeRow := [(286541841,[39722,20894,3315,33687,5558,21937,19511,18867],[39722,19511,39111,21937,3315,5558,18867,3891])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle193 : batchSingle193.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
