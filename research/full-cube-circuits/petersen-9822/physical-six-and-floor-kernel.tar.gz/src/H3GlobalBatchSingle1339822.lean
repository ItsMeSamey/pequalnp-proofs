import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle133 : List ModeRow := [(126061648,[39197,11319,5369,14479,10471,19515,15900,4335,15431],[15900,11319,39197,5369,7311])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle133 : batchSingle133.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
