import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g40_0 : global3 5771532 false [4018, 52042, 57812, 50417, 19192, 17898, 3787, 22683, 2010, 52530] = true := by decide +kernel
end Research.Graph9822Planes
