import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle125 : List ModeRow := [(107407006,[13110,50235,10471,12575,8443,5927,4601,10551,2919],[13110])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle125 : batchSingle125.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
