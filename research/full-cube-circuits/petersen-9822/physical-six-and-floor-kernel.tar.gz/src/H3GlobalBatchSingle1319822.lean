import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle131 : List ModeRow := [(125963344,[48664,27399,4335,19515,14479,22293,7858,39197],[48664,27399,5369,7858,13851,7311,1215])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle131 : batchSingle131.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
