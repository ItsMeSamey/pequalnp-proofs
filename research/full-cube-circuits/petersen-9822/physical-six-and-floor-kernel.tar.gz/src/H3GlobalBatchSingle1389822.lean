import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle138 : List ModeRow := [(126770504,[3390,45339,15970,21849,31011,19515,21859,7478,54673,5407],[15970,54673,10551])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle138 : batchSingle138.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
