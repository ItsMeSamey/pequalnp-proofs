import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g71_1 : global3 33562913 true [29481, 21535, 47623, 17878, 21969, 13715, 4511, 13343, 21775, 39067, 26005, 21787, 29835, 5564] = true := by decide +kernel
end Research.Graph9822Planes
