import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle171 : List ModeRow := [(243368481,[30252,1823,43207,58395,5624,5711,5497,8991,50207],[30252,58395,5974,5497,8991,24330])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle171 : batchSingle171.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
