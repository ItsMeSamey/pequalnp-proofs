import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle189 : List ModeRow := [(275908625,[41912,21955,9054,21814,1779,10695,49495],[41912,49495,5246,54407,21938,6375,503])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle189 : batchSingle189.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
