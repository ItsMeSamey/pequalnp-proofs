import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle186 : List ModeRow := [(270338097,[53880,39055,21969,50986,1017,54566,4839,1839,50517],[53880,37099,50517,5927,49593,50986,1017])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle186 : batchSingle186.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
