import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle128 : List ModeRow := [(109283408,[46620,19515,4511,10471,26679,5369,4223],[46620,19515,14087,14479,4223,5369,26679])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle128 : batchSingle128.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
