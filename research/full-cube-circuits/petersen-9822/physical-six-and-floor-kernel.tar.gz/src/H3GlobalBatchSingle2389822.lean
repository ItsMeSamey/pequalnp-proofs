import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle238 : List ModeRow := [(391412893,[47651,49395,4829,831,47119,26679,6207,22631,37151],[47651])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle238 : batchSingle238.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
