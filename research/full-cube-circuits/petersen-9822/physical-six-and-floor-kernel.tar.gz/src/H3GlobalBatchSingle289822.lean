import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle28 : List ModeRow := [(3605158,[37308,52267,8991,43811,7566,7602,49566,3135,8511],[37308,7602,52267,958,2959,43811,43151])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle28 : batchSingle28.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
