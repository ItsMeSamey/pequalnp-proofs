import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle124 : List ModeRow := [(107101712,[45849,24887,37603,22339,8823,25045,29106,12903],[45849,24887,25941,29106,4719])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle124 : batchSingle124.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
