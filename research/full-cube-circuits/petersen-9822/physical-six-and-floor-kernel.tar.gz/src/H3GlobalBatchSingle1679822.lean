import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle167 : List ModeRow := [(182461217,[30474,6799,57623,27399,21916,50207,9111,50970,5279],[22279,21916,27399,50970,5279])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle167 : batchSingle167.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
