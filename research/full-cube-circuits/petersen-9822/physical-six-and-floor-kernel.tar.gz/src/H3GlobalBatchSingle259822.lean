import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle25 : List ModeRow := [(2508420,[4926,45395,2919,19515,1529,39463,1275,1495],[4926,19515,35175,7478,45395,1275])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle25 : batchSingle25.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
