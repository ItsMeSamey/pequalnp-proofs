import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle164 : List ModeRow := [(179816103,[20798,1779,16855,19239,12702,5558,1275],[5558])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle164 : batchSingle164.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
