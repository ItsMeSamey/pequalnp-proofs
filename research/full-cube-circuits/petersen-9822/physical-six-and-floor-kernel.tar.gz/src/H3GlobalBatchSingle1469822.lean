import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle146 : List ModeRow := [(132857426,[3898,47273,21969,15192,2671,4719,10551,3911],[15192])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle146 : batchSingle146.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
