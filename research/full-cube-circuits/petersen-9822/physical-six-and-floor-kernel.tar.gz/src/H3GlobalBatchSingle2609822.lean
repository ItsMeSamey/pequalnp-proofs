import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle260 : List ModeRow := [(404828358,[53549,11319,22286,33183,47651,54449,50610,26919],[53549,50610,11319,47651,22286,54449,26919])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle260 : batchSingle260.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
