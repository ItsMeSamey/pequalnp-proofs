import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle279 : List ModeRow := [(410715664,[4926,21969,52253,54104,16871,49463,1017,16799,17015],[54104,52253,4926])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle279 : batchSingle279.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
