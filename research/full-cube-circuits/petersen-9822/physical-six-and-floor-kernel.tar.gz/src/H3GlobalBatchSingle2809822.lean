import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle280 : List ModeRow := [(414320657,[50588,7347,25031,37782,3191,21686,503],[50588,7602,3191,25031,21686,3315])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle280 : batchSingle280.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
