import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle281 : List ModeRow := [(425738536,[56074,1779,19890,9999,47623,33567,22961,24863],[56074,24863,47623,10895,11295,1779,11023])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle281 : batchSingle281.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
