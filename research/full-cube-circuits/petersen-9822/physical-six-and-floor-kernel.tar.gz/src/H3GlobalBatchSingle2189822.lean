import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle218 : List ModeRow := [(353373201,[48016,26951,51994,14995,59670,44241,21969,10647,60549],[48016,27022,44241,50965,32144,21969,51994,26775])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle218 : batchSingle218.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
