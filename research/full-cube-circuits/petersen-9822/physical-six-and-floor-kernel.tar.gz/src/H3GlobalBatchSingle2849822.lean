import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle284 : List ModeRow := [(427923208,[52780,17881,4018,49215,17695,17852,52263,18743,36019,17838],[52780,17695,35023,17838,36019,18743])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle284 : batchSingle284.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
