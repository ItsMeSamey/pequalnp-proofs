import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle136 : List ModeRow := [(126565458,[3135,21969,14415,47273,27187,4719,15960,19515,26963],[15960,7227,7199,639])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle136 : batchSingle136.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
