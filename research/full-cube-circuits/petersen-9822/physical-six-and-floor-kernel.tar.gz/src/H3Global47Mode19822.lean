import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g47_1 : global3 6426128 true [62232, 9139, 18261, 21647, 4926, 49463, 33687, 52253, 45763] = true := by decide +kernel
end Research.Graph9822Planes
