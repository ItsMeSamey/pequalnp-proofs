import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle10 : List ModeRow := [(397632,[37692,11319,49628,3315,13710,1375,5564],[37692,11319,49628,13710,3315,38012,5564])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle10 : batchSingle10.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
