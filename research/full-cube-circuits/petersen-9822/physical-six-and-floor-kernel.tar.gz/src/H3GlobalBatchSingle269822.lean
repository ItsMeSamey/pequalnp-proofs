import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle26 : List ModeRow := [(2541190,[37182,43811,3870,23694,751,1779,2519,1530,1439,2919,17846,33119],[37182,17846,2919,1151,43811,951,1463])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle26 : batchSingle26.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
