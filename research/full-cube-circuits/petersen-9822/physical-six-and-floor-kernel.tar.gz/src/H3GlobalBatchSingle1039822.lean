import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle103 : List ModeRow := [(101810318,[29100,7230,59669,14479,21678,45462,4511,43207],[29100,14479,45462,59669])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle103 : batchSingle103.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
