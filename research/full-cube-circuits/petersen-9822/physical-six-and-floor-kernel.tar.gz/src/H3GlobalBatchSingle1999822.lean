import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle199 : List ModeRow := [(311560273,[13494,43207,38556,3639,45207,21745,36019,15414,4343],[38556,15538,21745,10471,45207,13494,36019])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle199 : batchSingle199.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
