import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle0 : List ModeRow := [(77890,[11319,37677,13710,6883,49341,46289,14479,751,30771,10471,1151],[37677,3195,14479,751,46289,11319,13710,6883,30771,49341,10478])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle0 : batchSingle0.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
