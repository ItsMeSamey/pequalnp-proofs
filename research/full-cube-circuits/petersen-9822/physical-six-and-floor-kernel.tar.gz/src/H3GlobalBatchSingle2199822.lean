import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle219 : List ModeRow := [(353471505,[59932,5593,21916,15250,52253,14663,43335,4319],[59932,14479,21916,7059])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle219 : batchSingle219.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
