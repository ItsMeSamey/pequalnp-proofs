import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle173 : List ModeRow := [(244154929,[30252,52267,10471,29475,15778,5497,25397,3183],[30252,52267,12399,15778,5497,25397])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle173 : batchSingle173.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
