import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle162 : List ModeRow := [(177284001,[1823,43207,22185,13005,50387,25679,1529,11023,13343,17819],[22185,58391,12495,17819,13005,47747,16855,1529])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle162 : batchSingle162.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
