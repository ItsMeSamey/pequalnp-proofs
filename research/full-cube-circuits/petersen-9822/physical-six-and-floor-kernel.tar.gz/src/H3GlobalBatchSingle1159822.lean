import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle115 : List ModeRow := [(105415054,[45924,7602,60165,31878,4854,22310,7286,3926],[45924,31878,3926,7602,7478])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle115 : batchSingle115.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
