import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle200 : List ModeRow := [(311572561,[35899,41175,14439,45178,1501,11023,10471,15538],[38069,11023,45178,41175,35899,1501,10471,1247])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle200 : batchSingle200.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
