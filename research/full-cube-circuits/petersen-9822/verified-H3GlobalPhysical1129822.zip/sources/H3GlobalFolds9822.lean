import H3GlobalPlanes9822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes
theorem or_fold {α : Type} (xs : List α) (f : α → Nat) (acc j : Nat) :
    (xs.foldl (fun w i => w ||| f i) acc).testBit j = true ↔
      acc.testBit j=true ∨ ∃ i∈xs, (f i).testBit j=true := by
  induction xs generalizing acc with
  | nil => simp
  | cons a xs ih =>
    rw [List.foldl_cons,ih,Nat.testBit_or,Bool.or_eq_true_iff]
    simp only [List.mem_cons]
    aesop
theorem and_fold {α : Type} (xs : List α) (f : α → Nat) (acc j : Nat)
    (start : acc.testBit j=true) (all : ∀ i∈xs, (f i).testBit j=true) :
    (xs.foldl (fun w i => w &&& f i) acc).testBit j=true := by
  induction xs generalizing acc with
  | nil => exact start
  | cons a xs ih =>
    apply ih
    · simpa [Nat.testBit_and,start] using all a (by simp)
    · intro i mem
      exact all i (by simp [mem])
theorem ones_at (j : Fin 59049) : ones.testBit j.val=true := by
  rw [ones,Nat.shiftLeft_eq,Nat.one_mul,Nat.testBit_two_pow_sub_one]
  exact decide_eq_true j.isLt
theorem pTable_get (h : Nat) (u : Bool) (r : Fin 29) :
    (pTable h u)[r.val]! = qWord h u r.val := by fin_cases r <;> rfl
def Represents (ps : Array Nat) (j q : Nat) : Prop :=
  ∀ r : Fin 29, ps[r.val]!.testBit j = q.testBit r.val
end Research.Graph9822GlobalH3
