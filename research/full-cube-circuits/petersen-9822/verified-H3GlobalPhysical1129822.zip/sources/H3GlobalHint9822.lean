import H3GlobalFolds9822
import H3GlobalRequests9822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes Research.Graph9822H2Check Research.Graph9822DemandThree
private theorem productive {α : Type} (xs : List α) (enabled : α → Bool) (f : α → Nat) (acc lane : Nat)
    (ok : acc.testBit lane=true) (all : ∀ i∈xs, enabled i=true → (f i).testBit lane=true) :
    (xs.foldl (fun w i => if enabled i then w &&& f i else w) acc).testBit lane=true := by
  induction xs generalizing acc with
  | nil => exact ok
  | cons i xs ih =>
    apply ih
    · cases b : enabled i <;> simp [b,ok,Nat.testBit_and,all i (by simp)]
    · intro k mem
      exact all k (by simp [mem])
theorem clause {h q w : Nat} {ps : Array Nat} {lane : Fin 59049}
    (a : ActualFacts h q) (rep : Represents ps lane.val q) (ok : hintOK h w=true) :
    (hintWord h ps w).testBit lane.val=true := by
  obtain ⟨i,j,mem,live⟩ := requested_pair a ok
  apply (or_fold ..).2
  refine Or.inr ⟨(i.val,j.val),mem,?_⟩
  let n := needPos h i.val j.val
  have cold (k : Fin 16) (eq : k=i ∨ k=j) : ps[13+k.val]!.testBit lane.val=false := by
    have hot : (demand n (twoNeg i.val j.val)).testBit (13+k.val)=true := by
      unfold demand
      rw [Nat.testBit_or,Bool.or_eq_true_iff]
      apply Or.inr
      rw [Nat.testBit_shiftLeft]
      have ge : 13+k.val ≥ 13 := by omega
      simp only [ge,decide_true,Bool.true_and,show 13+k.val-13=k.val by omega]
      unfold twoNeg
      rw [Nat.testBit_or,Bool.or_eq_true_iff]
      rcases eq with rfl|rfl
      · exact Or.inl (by simp [Nat.shiftLeft_eq,Nat.testBit_two_pow])
      · exact Or.inr (by simp [Nat.shiftLeft_eq,Nat.testBit_two_pow])
    have qq := held_bit live hot (by omega)
    exact (rep ⟨13+k.val,by omega⟩).trans (by simpa using qq)
  apply productive
  · simp [Nat.testBit_xor,Nat.testBit_or,ones_at,cold i (Or.inl rfl),cold j (Or.inr rfl)]
  · intro k km on
    have bound := List.mem_range.mp km
    have hot : (demand n (twoNeg i.val j.val)).testBit k=true := by
      change (needPos h i.val j.val ||| _).testBit k=true
      simp [Nat.testBit_or,on]
    exact (rep ⟨k,by omega⟩).trans (by simpa [bound] using held_bit live hot (by omega))
end Research.Graph9822GlobalH3
#print axioms Research.Graph9822GlobalH3.clause
