import H3GlobalPlanes9822
import H3FirstAdmission9822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes Research.Graph9822FirstAdmission
theorem cells8 : ∀ j : Fin 16, allInside[16*8+j.val]! = cell 8 j.val ∧ cell 8 j.val < 8192 := by decide +kernel
theorem cells9 : ∀ j : Fin 16, allInside[16*9+j.val]! = cell 9 j.val ∧ cell 9 j.val < 8192 := by decide +kernel
theorem cells10 : ∀ j : Fin 16, allInside[16*10+j.val]! = cell 10 j.val ∧ cell 10 j.val < 8192 := by decide +kernel
theorem cells11 : ∀ j : Fin 16, allInside[16*11+j.val]! = cell 11 j.val ∧ cell 11 j.val < 8192 := by decide +kernel
end Research.Graph9822GlobalH3
