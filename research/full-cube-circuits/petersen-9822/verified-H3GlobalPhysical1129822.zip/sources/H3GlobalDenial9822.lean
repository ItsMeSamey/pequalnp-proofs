import H3GlobalHint9822
import H3GlobalActive9822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes
theorem impossible {h q : Nat} {u : Bool} {lane : Fin 59049} {hints : List Nat}
    (a : ActualFacts h q) (rep : Represents (pTable h u) lane.val q)
    (closed : global3 h u hints=true) : False := by
  obtain ⟨val,zero⟩ := Bool.and_eq_true_iff.mp closed
  have eq := beq_iff_eq.mp zero
  have hit := and_fold hints (hintWord h (pTable h u)) _ lane.val (active a rep)
    (fun w m => clause a rep (List.all_eq_true.mp val _ m))
  rw [eq] at hit
  simp at hit
end Research.Graph9822GlobalH3
#print axioms Research.Graph9822GlobalH3.impossible
