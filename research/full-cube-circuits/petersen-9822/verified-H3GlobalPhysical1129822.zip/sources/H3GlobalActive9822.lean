import H3GlobalFolds9822
import H3GlobalBitFacts9822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes Research.Graph9822H2Check Research.Graph9822.H3Directions
private theorem outside_code {h q x : Nat} (a : ActualFacts h q) (mem : x∈h::excludedQs h) :
    q≠x ∧ x<2^29 := by
  rcases List.mem_cons.mp mem with rfl|mem
  · exact ⟨a.distinct.symm,a.hSmall⟩
  have no := a.noExcept
  by_cases one : h=786481
  · subst h
    simp only [excludedQs,if_pos,List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl <;>
      constructor <;> first | decide | (intro eq; subst q; apply no; decide)
  · by_cases two : h=26106184
    · subst h
      simp [excludedQs] at mem
      subst x
      exact ⟨fun eq => no (by rw [eq]; decide),by decide⟩
    · simp [excludedQs,one,two] at mem
private theorem src_bit : ∀ (i : Fin 13) (v : Fin 10),
    srcRows[i.val]!.testBit v.val = (rawPos (bit v.val)).testBit i.val := by decide +kernel

theorem active {h q : Nat} {ps : Array Nat} {j : Fin 59049} (a : ActualFacts h q)
    (rep : Represents ps j.val q) : (initial3 h ps).testBit j.val=true := by
  apply and_fold
  · apply and_fold
    · obtain ⟨i,hot⟩ := negative_witness a
      apply (or_fold ..).2
      exact Or.inr ⟨i.val,List.mem_range.mpr i.isLt,(rep ⟨13+i.val,by omega⟩).trans hot⟩
    · intro v vm
      obtain ⟨i,hot,off⟩ := uncovered_witness a ⟨v,List.mem_range.mp vm⟩
      apply (or_fold ..).2
      refine Or.inr ⟨i.val,List.mem_range.mpr i.isLt,?_⟩
      have cold := (src_bit i ⟨v,List.mem_range.mp vm⟩).trans off
      simpa [cold] using (rep ⟨i.val,by omega⟩).trans hot
  · intro x mem
    obtain ⟨ne,sm⟩ := outside_code a mem
    obtain ⟨r,diff⟩ := diff_witness a.qSmall sm ne
    apply (or_fold ..).2
    refine Or.inr ⟨r.val,List.mem_range.mpr r.isLt,?_⟩
    have rv := rep r
    cases b : x.testBit r.val <;> cases c : q.testBit r.val <;>
      simp_all [Nat.testBit_xor,ones_at]
end Research.Graph9822GlobalH3
#print axioms Research.Graph9822GlobalH3.active
