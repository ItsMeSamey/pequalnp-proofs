import H3GlobalPlanes9822
namespace Research.Graph9822Planes
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem g112_1 : global3 104318638 true [12732] = true := by decide +kernel
end Research.Graph9822Planes
