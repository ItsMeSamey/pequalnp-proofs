import H23TernaryPlanes9822
namespace Research.Graph9822Planes
def pTable (h : Nat) (u : Bool) : Array Nat := #[qWord h u 0,qWord h u 1,qWord h u 2,qWord h u 3,qWord h u 4,qWord h u 5,qWord h u 6,qWord h u 7,qWord h u 8,qWord h u 9,qWord h u 10,qWord h u 11,qWord h u 12,qWord h u 13,qWord h u 14,qWord h u 15,qWord h u 16,qWord h u 17,qWord h u 18,qWord h u 19,qWord h u 20,qWord h u 21,qWord h u 22,qWord h u 23,qWord h u 24,qWord h u 25,qWord h u 26,qWord h u 27,qWord h u 28]
def foldOr (is : List Nat) (f : Nat → Nat) := is.foldl (fun w i => w ||| f i) 0
def diffWord (ps : Array Nat) (q : Nat) :=
  foldOr (List.range 29) (fun i => if q.testBit i then ones ^^^ ps[i]! else ps[i]!)
def leaksWord (ps : Array Nat) := foldOr (List.range 16) (fun i => ps[13+i]!)
def starMask (ps : Array Nat) (v : Nat) :=
  foldOr (List.range 13) (fun i => if srcRows[i]!.testBit v then 0 else ps[i]!)
def excludedQs (h : Nat) : List Nat :=
  if h=786481 then [5047856,788144,26106200,788016,26106184,26106216]
  else if h=26106184 then [786481] else []
def initial3 (h : Nat) (ps : Array Nat) :=
  let leaky := leaksWord ps
  let nonstars := (List.range 10).foldl (fun w v => w &&& starMask ps v) leaky
  (h::excludedQs h).foldl (fun w q => w &&& diffWord ps q) nonstars
def twoNeg (i j : Nat) := (1 <<< i) ||| (1 <<< j)
def allInside : Array Nat := #[0,31,19,17,270,286,272,4097,4364,4352,142,143,130,131,4236,4237,31,0,8,14,49,32,38,2118,2161,2167,1041,1024,1049,1032,3153,3136,19,8,0,2,313,296,290,6210,6521,6515,1049,1032,1041,1024,7257,7240,17,14,2,0,319,302,288,6144,6461,6449,1183,1166,1171,1154,7325,7308,270,49,313,319,0,16,22,103,64,70,512,545,776,809,576,609,286,32,296,302,16,0,6,2150,2128,2134,1552,1568,1816,1832,3664,3680,272,38,290,288,22,6,0,2080,2068,2064,1686,1702,1938,1954,3732,3748,4097,2118,6210,6144,103,2150,2080,0,37,33,199,198,4291,4290,133,132,4364,2161,6521,6461,64,2128,2068,37,0,4,576,609,4936,4969,512,545,4352,2167,6515,6449,70,2134,2064,33,4,0,710,743,5058,5091,644,677,142,1041,1049,1183,512,1552,1686,199,576,710,0,1,8,9,64,65,143,1024,1032,1166,545,1568,1702,198,609,743,1,0,9,8,65,64,130,1049,1041,1171,776,1816,1938,4291,4936,5058,8,9,0,1,4168,4169,131,1032,1024,1154,809,1832,1954,4290,4969,5091,9,8,1,0,4169,4168,4236,3153,7257,7325,576,3664,3732,133,512,644,64,65,4168,4169,0,1,4237,3136,7240,7308,609,3680,3748,132,545,677,65,64,4169,4168,1,0]
def needPos (h i j : Nat) :=
  let full := allInside[16*i+j]!
  if (h >>> 13) &&& twoNeg i j == 0 then full &&& (8191 ^^^ (h &&& 8191)) else full
def meetsPositive (ps : Array Nat) (t initial : Nat) :=
  (List.range 13).foldl (fun w e => if t.testBit e then w &&& ps[e]! else w) initial
def pair3 (h : Nat) (ps : Array Nat) (i j : Nat) :=
  meetsPositive ps (needPos h i j) (ones ^^^ (ps[13+i]! ||| ps[13+j]!))

def slots (hint : Nat) := (List.range 16).filter hint.testBit
def ijs (hint : Nat) : List (Nat × Nat) := do
  let i ← slots hint
  let j ← slots hint
  guard (i<j)
  return (i,j)
def hintOK (h hint : Nat) :=
  (slots hint).length == 8 && (ijs hint).all (fun (i,j) => needPos h i j != 0)
def hintWord (h : Nat) (ps : Array Nat) (hint : Nat) :=
  (ijs hint).foldl (fun w (i,j) => w ||| pair3 h ps i j) 0
def global3 (h : Nat) (use : Bool) (hints : List Nat) :=
  let ps := pTable h use
  hints.all (hintOK h) &&
    (hints.foldl (fun w hint => w &&& hintWord h ps hint) (initial3 h ps) == 0)
end Research.Graph9822Planes
