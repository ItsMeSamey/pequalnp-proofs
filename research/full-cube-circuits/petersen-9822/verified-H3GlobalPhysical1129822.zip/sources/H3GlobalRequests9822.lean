import H3GlobalCells09822
import H3GlobalCells19822
import H3GlobalCells29822
import H3GlobalCells39822
import H3GlobalPlanes9822
import OR9822H2DemandOrder
import H3GlobalBitFacts9822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes Research.Graph9822H2Check Research.Graph9822DemandThree
open Research.Graph9822FirstAdmission (cell)
private theorem bothCells (i j : Fin 16) : allInside[16*i.val+j.val]! = cell i.val j.val ∧ cell i.val j.val < 8192 := by
  fin_cases i
  · exact cells0 j
  · exact cells1 j
  · exact cells2 j
  · exact cells3 j
  · exact cells4 j
  · exact cells5 j
  · exact cells6 j
  · exact cells7 j
  · exact cells8 j
  · exact cells9 j
  · exact cells10 j
  · exact cells11 j
  · exact cells12 j
  · exact cells13 j
  · exact cells14 j
  · exact cells15 j
private theorem cells (i j : Fin 16) : allInside[16*i.val+j.val]! = cell i.val j.val := (bothCells i j).1
private theorem cell_small (i j : Fin 16) : cell i.val j.val < 8192 := (bothCells i j).2
theorem req_eq (h : Nat) (i j : Fin 16) :
    pairRequest h i.val j.val = demand (needPos h i.val j.val) (twoNeg i.val j.val) := by
  have masks : twoNeg i.val j.val = (bit i.val ||| bit j.val) := by simp [twoNeg,bit,Nat.shiftLeft_eq]
  change demand (cell i.val j.val &&& (8191 ^^^ (if negative h &&& (bit i.val ||| bit j.val) == 0 then positive h else 0))) _ = _
  rw [needPos,cells,masks]
  change demand _ _ = demand (if negative h &&& (bit i.val ||| bit j.val) == 0 then _ else _) _
  by_cases z : (negative h &&& (bit i.val ||| bit j.val) == 0)=true
  · simp only [z,if_true,positive]
  · have maskEq : cell i.val j.val &&& 8191 = cell i.val j.val := by
      change cell i.val j.val &&& (2^13-1) = _
      rw [Nat.and_two_pow_sub_one_eq_mod,Nat.mod_eq_of_lt (cell_small i j)]
    simp [z,maskEq]
theorem need_small (h : Nat) (i j : Fin 16) : needPos h i.val j.val < 8192 := by
  rw [needPos,cells]
  split
  · exact lt_of_le_of_lt Nat.and_le_left (cell_small i j)
  · exact cell_small i j
private def rs (h w : Nat) : List Nat := do
  let i ← slots w
  let j ← slots w
  guard (i<j)
  return pairRequest h i j
private theorem rs_elim {h w r : Nat} (m : r∈rs h w) :
    ∃ (i j : Fin 16), (i.val,j.val)∈ijs w ∧ r=pairRequest h i.val j.val := by
  simp only [rs,List.bind_eq_flatMap,List.mem_flatMap] at m
  obtain ⟨i,im,j,jm,endm⟩ := m
  by_cases lt : i<j
  · have eq : r=pairRequest h i j := by simpa [lt] using endm
    refine ⟨⟨i,List.mem_range.mp (List.mem_filter.mp im).1⟩,⟨j,List.mem_range.mp (List.mem_filter.mp jm).1⟩,?_,eq⟩
    simp only [ijs,List.bind_eq_flatMap,List.mem_flatMap]
    exact ⟨i,im,j,jm,by simp [lt]⟩
  · simp [lt] at endm
    obtain ⟨⟨x,absurd⟩,_⟩ := endm
    exact (List.not_mem_nil absurd).elim
theorem requested_pair {h q w : Nat} (a : ActualFacts h q) (valid : hintOK h w=true) :
    ∃ i j : Fin 16, (i.val,j.val)∈ijs w ∧ holds q (demand (needPos h i.val j.val) (twoNeg i.val j.val)) := by
  obtain ⟨len,all⟩ := Bool.and_eq_true_iff.mp valid
  have guardOK : (rs h w).all (fun r => positive r != 0)=true := by
    apply List.all_eq_true.mpr
    intro r rm
    obtain ⟨i,j,im,rfl⟩ := rs_elim rm
    have need := List.all_eq_true.mp all (i.val,j.val) im
    rw [req_eq]
    have low : positive (demand (needPos h i.val j.val) (twoNeg i.val j.val))=needPos h i.val j.val :=
      SeedCache.demand_positive (need_small h i j)
    simpa only [low] using need
  have validRs : requests h w=some (rs h w) := by
    change (do guard ((slots w).length==8); let ds:=rs h w; guard (ds.all (fun r => positive r != 0)); pure ds : Option _) = _
    simp [len,guardOK]
  obtain ⟨r,rm,live⟩ := a.witness validRs
  obtain ⟨i,j,mem,rfl⟩ := rs_elim rm
  exact ⟨i,j,mem,req_eq h i j ▸ live⟩
end Research.Graph9822GlobalH3
