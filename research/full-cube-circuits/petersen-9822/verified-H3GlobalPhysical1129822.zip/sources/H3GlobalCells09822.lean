import H3GlobalPlanes9822
import H3FirstAdmission9822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes Research.Graph9822FirstAdmission
theorem cells0 : ∀ j : Fin 16, allInside[16*0+j.val]! = cell 0 j.val ∧ cell 0 j.val < 8192 := by decide +kernel
theorem cells1 : ∀ j : Fin 16, allInside[16*1+j.val]! = cell 1 j.val ∧ cell 1 j.val < 8192 := by decide +kernel
theorem cells2 : ∀ j : Fin 16, allInside[16*2+j.val]! = cell 2 j.val ∧ cell 2 j.val < 8192 := by decide +kernel
theorem cells3 : ∀ j : Fin 16, allInside[16*3+j.val]! = cell 3 j.val ∧ cell 3 j.val < 8192 := by decide +kernel
end Research.Graph9822GlobalH3
