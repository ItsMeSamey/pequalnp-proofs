import H3GlobalActual9822
import H3Global112Mode09822
import H3Global112Mode19822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
theorem reject112 (c : MaximumFive) (H Q R A B : Product)
    (hh : (hiddenFirst c.toFiveProgram).1=[H,Q,R]) (ht : (hiddenFirst c.toFiveProgram).2=[A,B])
    (key : encode (firstCol H)=104318638) : False := by
  apply root_impossible c H Q R A B hh ht
  intro u
  rw [key]
  cases u
  · exact ⟨_,g112_0⟩
  · exact ⟨_,g112_1⟩
end Research.Graph9822GlobalH3
#print axioms Research.Graph9822GlobalH3.reject112
