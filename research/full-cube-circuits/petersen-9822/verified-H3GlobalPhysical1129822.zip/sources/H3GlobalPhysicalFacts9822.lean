import And9822H3HeldRequest
import And9822H3SecondHidden
import And9822H3AllExceptions
import And9822H3DistinctSlots
namespace Research.Graph9822GlobalH3
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822DemandThree Research.Graph9822H2Check Research.Graph9822.H3Directions

structure ActualFacts (h q : Nat) : Prop where
  hSmall : h < 2^29
  qSmall : q < 2^29
  hiddenQ : Research.Graph9822FirstAdmission.hidden q = true
  distinct : h ≠ q
  noExcept : (h,q) ∉ exceptions
  witness : ∀ {w ds}, requests h w = some ds → ∃ s ∈ ds, holds q s

theorem actual_facts (c : MaximumFive) (H Q R A B : Product)
    (hh : (hiddenFirst c.toFiveProgram).1 = [H,Q,R])
    (ht : (hiddenFirst c.toFiveProgram).2 = [A,B]) :
    ActualFacts (encode (firstCol H)) (encode (secondCol H Q)) :=
  ⟨encode_bound _,encode_bound _,original_second_hidden c H Q [R] hh,
   distinct_slots c.toFiveProgram H Q R A B hh ht,
   original_not_exception c.toFiveProgram H Q R A B hh ht,
   fun ok => held_request c.toFiveProgram H Q R A B hh ht ok⟩

end Research.Graph9822GlobalH3
#print axioms Research.Graph9822GlobalH3.actual_facts
