import H3GlobalPhysicalFacts9822
import OR9822H2MaskLogic
namespace Research.Graph9822GlobalH3
open Research.Graph9822H2Check
theorem low_eq {q n i : Nat} (small : q < 2^n) (hi : n ≤ i) : q.testBit i = false :=
  Nat.testBit_lt_two_pow (lt_of_lt_of_le small (Nat.pow_le_pow_right (by decide) hi))
theorem diff_witness {q n : Nat} (qsmall : q < 2^29) (nsmall : n < 2^29)
    (ne : q ≠ n) : ∃ k : Fin 29, q.testBit k.val ≠ n.testBit k.val := by
  by_contra! no
  apply ne
  apply Nat.eq_of_testBit_eq
  intro k
  by_cases sm : k<29
  · exact no ⟨k,sm⟩
  · rw [low_eq qsmall (by omega : 29≤k),low_eq nsmall (by omega : 29≤k)]
theorem negative_witness {h q : Nat} (a : ActualFacts h q) :
    ∃ i : Fin 16, q.testBit (13+i.val)=true := by
  have hot : negative q ≠ 0 := bne_iff_ne.mp (Bool.and_eq_true_iff.mp a.hiddenQ).1
  by_contra! no
  apply hot
  apply Nat.eq_of_testBit_eq
  intro k
  by_cases l : k<16
  · have off := no (⟨k,l⟩ : Fin 16)
    simpa [negative,Nat.testBit_shiftRight,Nat.add_comm] using off
  · have off := low_eq a.qSmall (by omega : 29≤13+k)
    simpa [negative,Nat.testBit_shiftRight,Nat.add_comm] using off
theorem uncovered_witness {h q : Nat} (a : ActualFacts h q) (v : Fin 10) :
    ∃ i : Fin 13, q.testBit i.val=true ∧ (rawPos (bit v.val)).testBit i.val=false := by
  have inStars : rawPos (bit v.val) ∈ Research.Graph9822FirstAdmission.stars :=
    List.mem_map.mpr ⟨v.val,List.mem_range.mpr v.isLt,rfl⟩
  have miss := List.all_eq_true.mp (Bool.and_eq_true_iff.mp a.hiddenQ).2 _ inStars
  by_contra! no
  have incl : sub (positive q) (rawPos (bit v.val))=true := by
    apply (subset_bits ..).2
    intro k yes
    have both : q.testBit k=true ∧ k<13 := by
      change (q &&& (2^13-1)).testBit k=true at yes
      rw [Nat.testBit_and,Nat.testBit_two_pow_sub_one] at yes
      exact ⟨(Bool.and_eq_true_iff.mp yes).1,of_decide_eq_true (Bool.and_eq_true_iff.mp yes).2⟩
    have hn := no ⟨k,both.2⟩ both.1
    cases b : (rawPos (bit v.val)).testBit k <;> simp_all
  simp [incl] at miss
theorem held_bit {q s k : Nat} (ok : holds q s) (on : s.testBit k=true) (l : k<29) :
    q.testBit k = decide (k<13) := by
  have live := (subset_bits ..).1 ok k on
  change (q ^^^ ((2^16-1) <<< 13)).testBit k = true at live
  rw [Nat.testBit_xor,Nat.testBit_shiftLeft,Nat.testBit_two_pow_sub_one] at live
  by_cases low : k<13
  · simpa [show ¬ k≥13 by omega,low] using live
  · have high : k≥13 := by omega
    have index : k-13<16 := by omega
    simpa [high,index,low] using live
end Research.Graph9822GlobalH3
