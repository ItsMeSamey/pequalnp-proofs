import H3GlobalPlanes9822
import H3FirstAdmission9822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes Research.Graph9822FirstAdmission
theorem cells12 : ∀ j : Fin 16, allInside[16*12+j.val]! = cell 12 j.val ∧ cell 12 j.val < 8192 := by decide +kernel
theorem cells13 : ∀ j : Fin 16, allInside[16*13+j.val]! = cell 13 j.val ∧ cell 13 j.val < 8192 := by decide +kernel
theorem cells14 : ∀ j : Fin 16, allInside[16*14+j.val]! = cell 14 j.val ∧ cell 14 j.val < 8192 := by decide +kernel
theorem cells15 : ∀ j : Fin 16, allInside[16*15+j.val]! = cell 15 j.val ∧ cell 15 j.val < 8192 := by decide +kernel
end Research.Graph9822GlobalH3
