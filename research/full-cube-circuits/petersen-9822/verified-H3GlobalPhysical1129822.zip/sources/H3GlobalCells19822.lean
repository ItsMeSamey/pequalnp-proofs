import H3GlobalPlanes9822
import H3FirstAdmission9822
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes Research.Graph9822FirstAdmission
theorem cells4 : ∀ j : Fin 16, allInside[16*4+j.val]! = cell 4 j.val ∧ cell 4 j.val < 8192 := by decide +kernel
theorem cells5 : ∀ j : Fin 16, allInside[16*5+j.val]! = cell 5 j.val ∧ cell 5 j.val < 8192 := by decide +kernel
theorem cells6 : ∀ j : Fin 16, allInside[16*6+j.val]! = cell 6 j.val ∧ cell 6 j.val < 8192 := by decide +kernel
theorem cells7 : ∀ j : Fin 16, allInside[16*7+j.val]! = cell 7 j.val ∧ cell 7 j.val < 8192 := by decide +kernel
end Research.Graph9822GlobalH3
