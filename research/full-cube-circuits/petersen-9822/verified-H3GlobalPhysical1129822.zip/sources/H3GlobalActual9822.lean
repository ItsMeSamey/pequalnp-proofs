import H3GlobalDenial9822
import H23TernaryPhysical9822
import H23AxisTrit9822
import And9822H3FrozenRoot
namespace Research.Graph9822GlobalH3
open Research.Graph9822Planes Research.Graph9822Ternary
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822.H3Directions Research.Graph9822FirstAdmission

theorem root_impossible (c : MaximumFive) (H Q R A B : Product)
    (hh : (hiddenFirst c.toFiveProgram).1=[H,Q,R]) (ht : (hiddenFirst c.toFiveProgram).2=[A,B])
    (checked : ∀ u : Bool, ∃ hints, global3 (encode (firstCol H)) u hints=true) : False := by
  have apart := (hidden_first_shape c.toFiveProgram).2.1 Q (by simp [hh])
  obtain ⟨lane,u,trace⟩ := physicalQLane H Q apart
    (fun j v lt => by simpa [trit,Bool.beq_eq_decide_eq] using axis_trit ⟨v,lt⟩ (1:Fin 3) j)
    (fun j v lt => by simpa [trit,Bool.beq_eq_decide_eq] using axis_trit ⟨v,lt⟩ (2:Fin 3) j)
  obtain ⟨hints,empty⟩ := checked u
  apply impossible (actual_facts c H Q R A B hh ht) (lane:=lane) (u:=u) (hints:=hints) _ empty
  intro r
  rw [pTable_get]
  exact trace r

theorem no_three (checked : ∀ {k h : Nat}, roots[k]? = some h →
    ∀ u : Bool, ∃ hints, global3 h u hints=true) (c : MaximumFive) :
    (hiddenFirst c.toFiveProgram).1.length≠3 := by
  intro count
  have size := (hidden_first_sizes c.toFiveProgram).1
  have two : (hiddenFirst c.toFiveProgram).2.length=2 := by omega
  obtain ⟨H,Q,R,hh⟩ := List.length_eq_three.mp count
  obtain ⟨A,B,ht⟩ := List.length_eq_two.mp two
  obtain ⟨k,root⟩ := frozen_root c H Q R A B hh ht
  exact root_impossible c H Q R A B hh ht (checked root)
end Research.Graph9822GlobalH3
#print axioms Research.Graph9822GlobalH3.no_three
