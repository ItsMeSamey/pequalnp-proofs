"""Conjoin universal witness clauses over the raw disjoint source-pair cube."""
from replay_h3_demands import *
from functools import reduce
from operator import or_,and_
from collections import Counter
WIDTH=3**10;FULL=(1<<WIDTH)-1
def stripe(v,d):
 m=3**v
 return ((FULL//((1<<(3*m))-1))*((1<<m)-1))<<(d*m)
A=[stripe(v,1) for v in range(10)];B=[stripe(v,2) for v in range(10)]
def bits(m):
 while m:
  v=m&-m;yield v.bit_length()-1;m-=v
def OR(xs):return reduce(or_,xs,0)
def AND(xs):return reduce(and_,xs,FULL)
rows=E+N
sa=[OR(A[v] for v in bits(row)) for row in rows]
sb=[OR(B[v] for v in bits(row)) for row in rows]
plain=[a&b for a,b in zip(sa,sb)]
def columns(h,use):return [sb[i] if use and h>>i&1 else plain[i] for i in range(29)]
def compare(cols,x):return AND(col if x>>i&1 else FULL^col for i,col in enumerate(cols))
def hidden(cols):return OR(cols[13:])&AND(OR(cols[i] for i in range(13) if not E[i]>>v&1) for v in range(10))
def demand(cols,s):return AND(cols[i] for i in bits(s&8191)) & (FULL^OR(cols[13+i] for i in bits(s>>13)))
def maskReqs(h):
 out={};hp=h&8191;hn=h>>13
 for i,j in combinations(range(16),2):
  f=1<<i|1<<j;t=contained[N[i]|N[j]]&~(hp if not f&hn else 0);out[i,j]=t|(f<<13)
 return out
def choose(active,tests):
 picks=[]
 while active:
  code=min(tests,key=lambda k:(active&tests[k]).bit_count());nxt=active&tests[code]
  assert nxt!=active,(active.bit_count(),len(picks))
  active=nxt;picks.append(code)
 return picks
def h3():
 blob=zlib.decompress((here/'h3-demands.zlib').read_bytes());p=6;log=[];before=0;hist=Counter()
 for h in read_roots():
  H,n=struct.unpack_from('<IH',blob,p);p+=6;ws=struct.unpack_from('<'+'H'*n,blob,p);p+=2*n
  assert H==h
  opts=sorted(set(ws)-{0});requests=maskReqs(h)
  assert all(w.bit_count()==8 and all(requests[ij]&8191 for ij in combinations(bits(w),2)) for w in opts)
  rec=[]
  for use in [False,True]:
   cs=columns(h,use);active=hidden(cs)&~compare(cs,h)
   for H,Q in possible:
    if H==h:active&=~compare(cs,Q)
   before+=active.bit_count()
   env={ij:demand(cs,s) for ij,s in requests.items()}
   tests={w:OR(env[i,j] for i,j in combinations(bits(w),2)) for w in opts}
   assert not (active&AND(tests.values())),(h,use)
   pick=choose(active,tests);hist[len(pick)]+=1;rec.append(pick)
  log.append([h,rec])
 assert p==len(blob)
 (here/'h3-global-clauses.json').write_text(json.dumps(log,separators=(',',':'))+'\n')
 print('H3 complete',before,hist,'selected',sum(i*n for i,n in hist.items()),'bytes',len((here/'h3-global-clauses.json').read_bytes()),flush=True)
if __name__=='__main__':h3()
