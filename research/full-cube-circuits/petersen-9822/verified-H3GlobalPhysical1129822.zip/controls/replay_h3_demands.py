"""Independent finite packet replay, using covers and optimized grids, never enumerating all Q to pick a hint."""
from pathlib import Path
from itertools import combinations
from functools import cache
import zlib,struct,sys,json
here=Path(__file__).resolve().parent
E=[6,24,17,33,66,132,264,528,160,640,576,320,288]
contained=[sum(1<<i for i,e in enumerate(E) if e&s==e) for s in range(1024)]
N=[s for s in range(1024) if not contained[s] and all(contained[s|1<<i] for i in range(10) if not s>>i&1)]
def sig(s,rows):return sum(1<<i for i,row in enumerate(rows) if s&row)
EP=[sig(s,E) for s in range(1024)];NN=[sig(s,N) for s in range(1024)]
stars=[EP[1<<v] for v in range(10)]
possible={(786481,q) for q in [5047856,788144,26106200,788016,26106184,26106216]}|{(26106184,786481)}
@cache
def covers(t):
 return tuple(b for b in range(1024) if not t&~EP[b] and all(t&~EP[b^(1<<v)] for v in range(10) if b>>v&1))
@cache
def free(f):return sum(1<<v for v in range(10) if not (f&NN[1<<v]))
def submasks(m):
 b=m
 while True:
  yield b
  if not b:return
  b=(b-1)&m
def novel(h,e,n):
 return n and all(e&~star for star in stars) and (e|n<<13)!=h and (h,e|n<<13) not in possible
def replay(h,words,observe=None):
 words=iter(words);hp=h&8191;hn=h>>13
 @cache
 def feasible(s):
  t=s&8191;f=s>>13
  return any(not t&~(EP[free(f&NN[b])&~b] | (0 if hn&f&NN[b] else hp)) for b in covers(t))
 def assert_terminal(s):
  t=s&8191;f=s>>13
  for attach in (False,True):
   Hpos=hp if attach else 0;Hneg=hn if attach else 0
   for b in covers(t):
    for a in covers(t&~Hpos):
     if a&b or f&NN[b]&(NN[a]|Hneg):continue
     Amax=free(f&NN[b])&~b
     Bmax=free(f&(NN[a]|Hneg))&~a
     ubpos=(EP[Amax]|Hpos)&EP[Bmax];ubneg=(NN[Amax]|Hneg)&NN[Bmax]
     if not ubneg or any(not ubpos&~star for star in stars):continue
     for ax in submasks(Amax&~a):
      A=a|ax
      for bx in submasks(Bmax&~(b|A)):
       B=b|bx;e=(EP[A]|Hpos)&EP[B];n=(NN[A]|Hneg)&NN[B]
       assert t&~e or f&n or not novel(h,e,n)
 seen=set();counts=[0,0,0]
 def walk(s):
  if s in seen:return
  # Mark on return as in the Lean forest engine, all child edges checked strict.
  ok=feasible(s)
  if observe is not None:observe(h,s,ok)
  if not ok:counts[0]+=1
  else:
   hint=next(words)
   if hint==0:
    assert_terminal(s);counts[1]+=1
   else:
    assert hint.bit_count()==8;counts[2]+=1
    rs=set()
    for i,j in combinations([k for k in range(16) if hint>>k&1],2):
     f=1<<i|1<<j;t=contained[N[i]|N[j]] & ~(hp if not hn&f else 0)
     assert t and (s|(t|f<<13))!=s
     rs.add(s|t|f<<13)
    for c in sorted(x for x in rs if all(y==x or y&x!=y for y in rs)):walk(c)
  seen.add(s)
 walk(0)
 assert next(words,None) is None
 return counts
def read_roots():
 b=zlib.decompress((here/'h3-rectangles.zlib').read_bytes());p=6;roots=[]
 for _ in range(335):
  h,=struct.unpack_from('<I',b,p);p+=4;roots.append(h)
  for k in range(2):n,=struct.unpack_from('<H',b,p);p+=2+2*n
 assert p==len(b)
 return roots
if __name__=='__main__':
 roots=read_roots();folder=Path('/dev/shm/9822-static-fixed/h3-demands')
 for k in map(int,sys.argv[1:]):
  b=(folder/f'{k:03}.bin').read_bytes();print(k,*replay(roots[k],struct.unpack('<'+'H'*(len(b)//2),b)),flush=True)
