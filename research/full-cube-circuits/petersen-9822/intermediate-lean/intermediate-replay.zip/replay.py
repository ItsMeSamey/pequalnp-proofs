"""Verify the frozen intermediate package or rebuild a checkpoint of its modules with a single Lean process at a time."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
LOCAL_PATHS = Path("/workspace/scratch/official24202/numeric/pinned.path")
LOCAL_LEAN = Path("/home/agent/.elan/toolchains/leanprover--lean4---v4.36.0/bin/lean")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true", help="validate bytes and the import graph without launching Lean")
    parser.add_argument("--lean", help="path to the pinned Lean 4.36.0 executable")
    parser.add_argument("--libraries", help="colon-separated Lean library paths for the pinned Mathlib checkout and its dependencies")
    parser.add_argument("--output", type=Path, help="new or empty directory for objects and replay logs")
    parser.add_argument("--max-modules", type=int, default=3, help="number of new modules this checkpoint may compile (default 3)")
    args = parser.parse_args()
    if args.max_modules < 1:
        raise SystemExit("--max-modules must be positive")
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        if digest(ROOT / name) != expected:
            raise SystemExit(f"Frozen file digest mismatch for {name}")
    closure = json.loads((ROOT / "closure.json").read_text())
    done = set()
    for module in closure["order"]:
        source = ROOT / "src" / (module.replace(".", "/") + ".lean")
        info = closure["modules"][module]
        imports = re.findall(r"^(?:public )?import ([\w.]+)\s*$", source.read_text(), re.M)
        if imports != info["imports"] or digest(source) != info["source_sha256"]:
            raise SystemExit(f"Source or import mismatch for {module}")
        if any(imp not in done and imp not in closure["external_imports"] for imp in imports):
            raise SystemExit(f"Unresolved import before {module}")
        done.add(module)
    if done != set(closure["modules"]):
        raise SystemExit("Build order omits frozen modules")
    def parsed_axioms(content):
        vals = {a: [x.strip() for x in b.split(",") if x.strip()] for a,b in
                re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",content)}
        vals.update({a: [] for a in re.findall(r"'([^']+)' does not depend on any axioms",content)})
        return vals
    for name, report in closure["printed_axioms"].items():
        if parsed_axioms((ROOT / "receipts" / (name + ".log")).read_text()) != report:
            raise SystemExit(f"Historical axiom receipt mismatch for {name}")
        if any(set(ax) - set(closure["approved_axioms"]) for ax in report.values()):
            raise SystemExit(f"Unexpected printed axiom in {name}")
    expected_output = [
        f"'{name}' depends on axioms: [{', '.join(closure['approved_axioms'])}]"
        for name in closure["theorems"]
    ]
    if (ROOT / "receipts/OR9822Finish.log").read_text().splitlines() != expected_output:
        raise SystemExit("Final historical axiom receipt mismatch")
    print(f"Verified {len(done)} source modules and their recorded axiom receipt.", flush=True)
    if args.verify_only:
        return
    libraries = args.libraries or os.environ.get("OR9822_LIBRARIES")
    if not libraries and LOCAL_PATHS.is_file():
        libraries = LOCAL_PATHS.read_text().strip()
    if not libraries:
        raise SystemExit("Supply --libraries for the Mathlib installation in lake-manifest.json.")
    library_paths = [Path(s) for s in libraries.split(os.pathsep) if s]
    library_paths = [p for p in library_paths if not (p / "PEqualNP").exists() and not (p / "OR9822Finish.olean").exists() and not (p / "OddCore.olean").exists() and not (p / "Research/WegenerThreshold.olean").exists()]
    for name, info in closure["external_imports"].items():
        rel = name.replace(".", "/") + ".olean"
        obj = next((p / rel for p in library_paths if (p / rel).is_file()), None)
        if obj is None or digest(obj) != info["object_sha256"]:
            raise SystemExit(f"Missing or different pinned Mathlib object for {name}")
    lean = args.lean or (str(LOCAL_LEAN) if LOCAL_LEAN.is_file() else shutil.which("lean"))
    if not lean:
        raise SystemExit("Supply --lean for the pinned toolchain.")
    lean = Path(lean).resolve()
    version = subprocess.check_output([lean, "--version"], text=True)
    if "version 4.36.0" not in version:
        raise SystemExit(f"Unexpected compiler version {version.strip()}")
    out = (args.output or Path(tempfile.mkdtemp(prefix="or9822-replay-"))).resolve()
    state = out / "checkpoint.json"
    closure_hash = digest(ROOT / "closure.json")
    if out.exists() and any(out.iterdir()) and not state.is_file():
        raise SystemExit(f"Replay output directory has unrelated contents: {out}")
    out.mkdir(parents=True, exist_ok=True)
    logs = out / "logs"
    logs.mkdir(exist_ok=True)
    env = dict(os.environ, LEAN_PATH=os.pathsep.join(str(p) for p in [out, *library_paths]))
    saved = json.loads(state.read_text()) if state.is_file() else {"closure": closure_hash, "objects": {}}
    if saved["closure"] != closure_hash:
        raise SystemExit("Checkpoint belongs to a different source closure")
    replay_hashes = saved["objects"]
    if list(replay_hashes) != closure["order"][:len(replay_hashes)]:
        raise SystemExit("Checkpoint is not a prefix of the dependency order")
    for name, oldhash in replay_hashes.items():
        obj = out / (name.replace(".", "/") + ".olean")
        if not obj.is_file() or digest(obj) != oldhash:
            raise SystemExit(f"Previously accepted object changed for {name}")
    def record():
        temp = state.with_suffix(".tmp")
        temp.write_text(json.dumps(saved,indent=2) + "\n")
        temp.replace(state)
    record()
    batch = closure["order"][len(replay_hashes):len(replay_hashes)+args.max_modules]
    for name in batch:
        rel = name.replace(".", "/")
        src = ROOT / "src" / (rel + ".lean")
        obj = out / (rel + ".olean")
        obj.parent.mkdir(parents=True, exist_ok=True)
        result = subprocess.run([lean, "-j1", "--root=" + str(ROOT / "src"), "-o", obj, src],
                                env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (logs / (name + ".log")).write_text(result.stdout)
        if result.returncode:
            raise SystemExit(f"{name} failed. See {logs / (name + '.log')}")
        if name in closure["printed_axioms"] and parsed_axioms(result.stdout) != closure["printed_axioms"][name]:
            raise SystemExit(f"Rebuilt axiom report differs for {name}")
        replay_hashes[name] = digest(obj)
        record()
        print(f"Accepted {name}", flush=True)
    if len(replay_hashes) < len(closure["order"]):
        print(f"Checkpoint {len(replay_hashes)}/{len(closure['order'])} accepted in {out}")
        return
    if (logs / "OR9822Finish.log").read_text().splitlines() != expected_output:
        raise SystemExit("Rebuilt final axiom receipt differs")
    (out / "replay-object-digests.json").write_text(json.dumps(replay_hashes, indent=2) + "\n")
    print(f"Accepted the full intermediate closure with its recorded axiom reports. Replay artifacts are in {out}")


if __name__ == "__main__":
    main()
