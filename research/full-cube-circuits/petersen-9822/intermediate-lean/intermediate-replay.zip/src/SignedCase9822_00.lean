import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem case00 : ¬ Placement [0, 1, 2] 48 :=
  reject_sound (lookup := frozen) (by decide +kernel)
end Petersen9822
