import Std

namespace Research.Graph9822.ProfileZero
abbrev Word := Fin 64
abbrev Axis := Fin 6
def activation (i : Axis) : Nat :=
  (#[18446744073709551615,6148914691236517205,1229782938247303441,72340172838076673,281479271743489,1229782938247303441] : Array (Nat))[i.val]'(by simpa using i.isLt)
def branch (i : Axis) (sign : Bool) (p : Word) : Bool :=
  (activation i).testBit p.val && (p.val.testBit i.val == sign)
def index (p : Word) : Fin 10 :=
  (#[0,1,2,1,3,1,2,1,4,1,2,1,3,1,2,1,5,1,2,1,3,1,2,1,4,1,2,1,3,1,2,1,6,1,2,1,7,1,2,1,8,1,2,1,7,1,2,1,9,1,2,1,7,1,2,1,8,1,2,1,7,1,2,1] : Array (Fin 10))[p.val]'(by simpa using p.isLt)
def rep (j : Fin 10) : Word :=
  (#[0,1,2,4,8,16,32,36,40,48] : Array (Word))[j.val]'(by simpa using j.isLt)

theorem same_trace : ∀ (p : Word) (i : Axis) (b : Bool),
    branch i b p = branch i b (rep (index p)) := by decide +kernel

inductive Built : (Word → Bool) → Prop where
  | empty : Built (fun _ => false)
  | full : Built (fun _ => true)
  | primitive (i : Axis) (b : Bool) : Built (branch i b)
  | join {f g : Word → Bool} : Built f → Built g → Built (fun p => f p || g p)

theorem built_factors {f : Word → Bool} (h : Built f) (p : Word) :
    f p = f (rep (index p)) := by
  induction h with
  | empty => rfl
  | full => rfl
  | primitive i b => exact same_trace p i b
  | join _ _ ih jh => dsimp only; rw [ih,jh]
end Research.Graph9822.ProfileZero
