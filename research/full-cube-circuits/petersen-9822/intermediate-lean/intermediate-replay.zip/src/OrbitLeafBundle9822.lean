import SixStdCoverage
namespace Research.Graph9822Orbit

def fact : Nat → Nat
  | 0 => 1
  | n+1 => (n+1) * fact n

/-- Unrank the permutation in lexical, zero-based order. The ordinary six-axis
case never reads out of range when the map code is below 64 * 720. -/
def unrank : Nat → List Nat → Nat → List Nat
  | 0, _, _ => []
  | n+1, left, k =>
    let i := k / fact n
    (left[i]?.getD 0) :: unrank n (left.eraseIdx i) (k % fact n)

def codePerm (code : Nat) := unrank 6 (List.range 6) (code/64)
def codeFlip (code : Nat) := code%64

def imageRow (src : List Nat) (code : Nat) : List Nat :=
  let to := codePerm code
  let f := codeFlip code
  let moved := (List.range 64).map (wordMap to f)
  (List.range 6).map fun j =>
    let m := src[to.idxOf j]?.getD 0
    ((List.range 64).zip moved).foldl
      (fun a p => if m.testBit p.1 then a ||| (1 <<< p.2) else a) 0

/-- Empty or malformed transport data yields no acceptance. A caller supplies
the predicate which has already been shown to exclude each accepted image. -/
def leafCheck (certified : List Nat → Bool) (src : List Nat) (code : Nat) : Bool :=
  let dst := imageRow src code
  decide (code < 46080) && rowCheck src dst (codePerm code) (codeFlip code) && certified dst

theorem leaf_bits {certified src code} (h : leafCheck certified src code)
    (i w : Nat) (hi : i<6) (hw : w<64) :
    certified (imageRow src code) = true ∧
    (src[i]?.getD 0).testBit w =
      ((imageRow src code)[(codePerm code)[i]?.getD 0]?.getD 0).testBit
        (wordMap (codePerm code) (codeFlip code) w) := by
  obtain ⟨head,cert⟩ := Bool.and_eq_true_iff.mp h
  exact ⟨cert, checked_bits (Bool.and_eq_true_iff.mp head).2 i w hi hw⟩

end Research.Graph9822Orbit
#print axioms Research.Graph9822Orbit.leaf_bits
namespace Research.Graph9822Chrono

abbrev M := BitVec 64

def half (axis : Nat) : M :=
  (List.range 64).foldl (fun m i => if i.testBit axis then m ||| (1 <<< i) else m) 0

/-- Enumerate all distinct unions of already available primitive masks. -/
def closure (bank : List M) : List M :=
  bank.foldl (fun old b => (old ++ old.map (fun x => x ||| b)).eraseDups) [0]

def poleFlip (m : M) (j : Nat) : M :=
  let h := half j
  ((m &&& ~~~h) <<< (2^j)) ||| ((m &&& h) >>> (2^j))

def flip (m : M) (flags : Nat) : M :=
  (List.range 6).foldl (fun a j => if flags.testBit j then poleFlip a j else a) m

def atomCount (bank : List M) : Nat :=
  (((List.range 64).map (fun p => bank.map (fun b => b.getLsbD p))).eraseDups).length

/-- This specification expands six levels of sign-stabilized chronological profiles.
At each leaf the caller supplies an explicit orbit witnessing row. Splitting a
computation by a prior does not change the quantified children at any node. -/
def checkLeaves (leaf : List M → Bool) : Nat → List M → List M → List M → List Nat → Bool
  | 0, profile, bank, _, _ => decide (atomCount bank < 10) || leaf profile.reverse
  | fuel+1, profile, bank, names, stabilizer =>
    let h := half profile.length
    let choices := (((BitVec.allOnes 64)::closure bank).eraseDups).mergeSort (fun x y => decide (x.toNat ≤ y.toNat))
    choices.all fun u =>
      let fresh := u != BitVec.allOnes 64 && !bank.contains u && !names.contains u
      let skip := u==0 || (fresh && decide (4 ≤ names.length)) ||
        stabilizer.any (fun s => decide ((flip u s).toNat < u.toNat))
      skip || checkLeaves leaf fuel (u::profile) ((u &&& h)::(u &&& ~~~h)::bank)
        (if fresh then u::names else names) (stabilizer.filter (fun s => flip u s == u))

def covered (leaf : List M → Bool) : Bool :=
  checkLeaves leaf 6 [] [] [] (List.range 64)

end Research.Graph9822Chrono
namespace Research.Graph9822Orbit
open Research.Graph9822Chrono

/-- The chronological keys at the last step, in the same unsigned order as
the input stream. The depth-five frontier is independently certified. -/
def finalRows (prior branches names : List M) (stabilizer : List Nat) : List (List Nat) :=
  let h := half 5
  let choices := (((BitVec.allOnes 64)::closure branches).eraseDups).mergeSort
    (fun x y => decide (x.toNat ≤ y.toNat))
  (choices.filter fun u =>
    let fresh := u != BitVec.allOnes 64 && !branches.contains u && !names.contains u
    u != 0 && !(fresh && decide (4 ≤ names.length)) &&
      !(stabilizer.any fun s => decide ((flip u s).toNat < u.toNat)) &&
      decide (10 ≤ atomCount ((u &&& h)::(u &&& ~~~h)::branches))).map
    (fun u => (u::prior).reverse.map BitVec.toNat)

/-- The end condition checks equal lengths, so a missing transport cannot be
silently dropped by a list zip. -/
def checkRows (certified : List Nat → Bool) :
    List (List Nat) → List Nat → Bool
  | [], [] => true
  | row :: rows, code :: codes => leafCheck certified row code && checkRows certified rows codes
  | _, _ => false

theorem checked_rows {certified rows codes} (h : checkRows certified rows codes) :
    ∀ row ∈ rows, ∃ code ∈ codes, leafCheck certified row code = true := by
  induction rows generalizing codes with
  | nil => simp
  | cons x xs ih =>
    cases codes with
    | nil => simp [checkRows] at h
    | cons c cs =>
      obtain ⟨head,tail⟩ := Bool.and_eq_true_iff.mp h
      intro row hr
      rcases List.mem_cons.mp hr with rfl | hm
      · exact ⟨c,by simp,head⟩
      · obtain ⟨d,hd,works⟩ := ih tail row hm
        exact ⟨d,by simp [hd],works⟩

end Research.Graph9822Orbit
#print axioms Research.Graph9822Orbit.checked_rows
