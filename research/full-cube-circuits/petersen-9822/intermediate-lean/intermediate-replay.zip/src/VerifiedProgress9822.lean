import And9822ProfileZero
import CleanMin9822
import OR9822Cycles
import RowCheckBundle9822
import Sector9822
import SignedCensusBundle9822
import UpperWitnessBundle9822

-- VerifiedAxioms9822
#print axioms Research.Graph9822.FourSaturation.full_graph_of_rows
#print axioms PEqualNP.Outside.L_meta_9822.SignedRowControl.decoyOnProbes
#print axioms PEqualNP.Outside.L_meta_9822.Receivers.distinctDirectAxes
#print axioms Petersen9822.reject_sound
#print axioms Research.Graph9822Steps.upper
#print axioms PEqualNP.Outside.L_meta_9822.Clean.reducedOfTieBreak

-- TenPhysical9822
namespace PEqualNP.Outside.L_meta_9822.Sectors
open Research.OddOr FreeAndNet PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

private def graphSet (s : Finset (Fin 10)) := edge (fun i => decide (i ∈ s))
private def rem : Research.OddOr.Drop12.V ↪ Fin 10 where
  toFun := fun v => ([0,3,4,5,6,7,8,9] : List (Fin 10)).get v
  inj' := by decide +kernel

set_option maxRecDepth 16000 in
theorem tenPhysicalOrs (C : Circuit) (mono : Monotone2 C)
    (computes : ∀ x : Fin 10 → Bool, C.eval (List.ofFn x) = edge x) :
    10 ≤ (C.gates.filter CircuitCompiler.orFlag).length := by
  apply Nat.le_trans _ (CircuitCompiler.compile_cost 10 C)
  refine induced_price (f := graphSet) (by decide +kernel) rem 8 Drop12.lower
    [1,2] {0,3,4,5,6,7,8,9} ?_ (by decide +kernel) (by decide +kernel) _ ?_
  · refine Peel.step (j := 6) (a := 0) (b := 4) ?_ (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    refine Peel.step (j := 7) (a := 0) (b := 4) ?_ (by decide +kernel)
      (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
    exact Peel.done _
  · intro s _
    exact (CircuitCompiler.compile_eval 10 C mono _).trans (computes _)

end PEqualNP.Outside.L_meta_9822.Sectors
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.tenPhysicalOrs

-- And9822ProfileZeroExclusion
namespace Research.Graph9822.ProfileZero
theorem exclusion (raw : Fin 10 → Word → Bool) (built : ∀ v, Built (raw v))
    (witness : Fin 16 → Word)
    (distinct : ∀ i j : Fin 16, i ≠ j → ∃ v, raw v (witness i) ≠ raw v (witness j)) : False := by
  let f : Fin 16 → Fin 10 := fun i => index (witness i)
  have inj : ∀ {i j : Fin 16}, f i = f j → i = j := by
    intro i j he
    apply Classical.byContradiction
    intro hne
    obtain ⟨v,hv⟩ := distinct i j hne
    apply hv
    exact (built_factors (built v) _).trans
      ((congrArg (fun z => raw v (rep z)) he).trans (built_factors (built v) _).symm)
  have nd : ((List.finRange 16).map f).Nodup :=
    List.pairwise_map.mpr ((List.nodup_finRange 16).imp (fun h e => h (inj e)))
  have bound := nd.length_le_of_subset (l₂ := List.finRange 10) (fun {x} _ => List.mem_finRange x)
  have bad : 16 ≤ 10 := by simpa using bound
  omega
end Research.Graph9822.ProfileZero
#print axioms Research.Graph9822.ProfileZero.exclusion
