import OrbitLeafBundle9822
namespace Research.Graph9822Orbit
set_option maxRecDepth 100000
set_option maxHeartbeats 0
-- Real transport of chronological leaf 50 to representative 42.
theorem checked_sample : leafCheck (fun row => row == [18446744073709551615, 6148914691236517205, 1229782938247303441, 72340172838076673, 1157442765409226768, 4991489586732815701]) [18446744073709551615, 6148914691236517205, 1229782938247303441, 72340172838076673, 1157442765409226768, 6076855997670184021] 132 = true := by decide +kernel
end Research.Graph9822Orbit
#print axioms Research.Graph9822Orbit.checked_sample
