import Std
namespace Research.Graph9822Orbit

/-- The six integers in a witness record send input axes to representative axes. -/
def wordMap (to : List Nat) (flips word : Nat) : Nat :=
  (List.range 6).foldl (fun acc i =>
    acc ^^^ (if word.testBit i then (1 <<< (to[i]?.getD 0)) else 0)) flips

def rowCheck (src dst to : List Nat) (flips : Nat) : Bool :=
  decide (src.length=6 ∧ dst.length=6 ∧ to.length=6 ∧ flips<64) &&
  (List.range 6).all (fun axis => to.contains axis) &&
  (List.range 6).all (fun axis =>
    (List.range 64).all fun w =>
      (src[axis]?.getD 0).testBit w ==
        (dst[to[axis]?.getD 0]?.getD 0).testBit (wordMap to flips w))

theorem checked_bits {src dst to : List Nat} {flips : Nat} (h : rowCheck src dst to flips)
    (i w : Nat) (hi : i<6) (hw : w<64) :
    (src[i]?.getD 0).testBit w =
      (dst[to[i]?.getD 0]?.getD 0).testBit (wordMap to flips w) := by
  obtain ⟨_, checked⟩ := Bool.and_eq_true_iff.mp h
  have hr := List.all_eq_true.mp checked i (List.mem_range.mpr hi)
  have hy := List.all_eq_true.mp hr w (List.mem_range.mpr hw)
  simpa using hy

end Research.Graph9822Orbit
#print axioms Research.Graph9822Orbit.checked_bits

namespace Research.Graph9822Resolution

/-- Each live wire has one or more incoming backwards contributions. A binary
union tree joins k positive contributions using k−1 gates. -/
theorem cost_of_live_wires (occ : List Nat) (live : ∀ k ∈ occ, 0 < k) :
    (occ.map (fun k => k-1)).sum + occ.length = occ.sum := by
  induction occ with
  | nil => simp
  | cons a as ih =>
    have ha : 0<a := live a (by simp)
    have ht := ih (fun k hk => live k (by simp [hk]))
    simp only [List.map_cons, List.sum_cons, List.length_cons]
    omega

theorem size17_reverse_budget (g : Nat) (occ : List Nat)
    (cap : g≤17) (wireCount : occ.length=10+g)
    (pinCount : occ.sum=2*g+1) (live : ∀ k ∈ occ, 0<k) :
    (occ.map (fun k => k-1)).sum ≤ 8 := by
  have h := cost_of_live_wires occ live
  omega

end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.size17_reverse_budget

namespace Research.Graph9822Pins

/-- Preserve both port occurrences even when the operands coincide. -/
def portList (gs : List (Nat×Nat)) (out : Nat) : List Nat :=
  out :: gs.flatMap (fun (a,b) => [a,b])

theorem port_length (gs : List (Nat×Nat)) (out : Nat) :
    (portList gs out).length = 2*gs.length+1 := by
  have h : (gs.flatMap fun (a,b) => [a,b]).length = 2*gs.length := by
    induction gs with
    | nil => simp
    | cons ab gs ih =>
      obtain ⟨a,b⟩ := ab
      simp [List.flatMap_cons,ih]
      omega
  simp [portList,h]

/-- A frequency partition over all valid wire indices counts each port once. -/
theorem count_partition (n : Nat) (pins : List Nat) (ok : ∀ j ∈ pins, j<n) :
    ((List.range n).map (fun j => pins.count j)).sum = pins.length := by
  induction n generalizing pins with
  | zero =>
    cases pins with
    | nil => rfl
    | cons a tail => have := ok a (by simp); omega
  | succ n ih =>
    let rest := pins.filter (fun j => j≠n)
    have small : ∀ j∈rest, j<n := by
      intro j h
      obtain ⟨mem,ne⟩ := List.mem_filter.mp h
      have := ok j mem
      simp at ne
      omega
    have same (a : Nat) (ha : a<n) : rest.count a=pins.count a := by
      simp [rest,List.count_filter,show a≠n by omega]
    have lo : (List.range n).map (fun j => pins.count j) =
        (List.range n).map (fun j => rest.count j) := by
      apply List.map_congr_left
      intro a ha
      exact (same _ (List.mem_range.mp ha)).symm
    have split : rest.length + pins.count n = pins.length := by
      change (pins.filter (fun j => decide (j≠n))).length + pins.count n = pins.length
      clear lo same small ok
      induction pins with
      | nil => simp
      | cons a tail h =>
        by_cases eq : a=n <;> simp_all [List.count_cons,beq_iff_eq]
        all_goals omega
    simp only [List.range_succ,List.map_append,List.map_cons,List.map_nil,List.sum_append,
      List.sum_cons,List.sum_nil,Nat.add_zero]
    rw [lo,ih rest small,split]

end Research.Graph9822Pins
#print axioms Research.Graph9822Pins.port_length
#print axioms Research.Graph9822Pins.count_partition
