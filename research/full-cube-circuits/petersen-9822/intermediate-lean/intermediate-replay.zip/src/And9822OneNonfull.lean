import Mathlib.Data.Fintype.EquivFin
import Mathlib.Logic.Equiv.Basic
import Mathlib.GroupTheory.Perm.Basic
import Mathlib.Data.Set.Basic

namespace Research.Graph9822.OneNonfull
abbrev Axis := Fin 6
abbrev Word := Axis → Bool

def live (L : Finset (Axis × Bool)) (w : Word) : Prop :=
  ∃ t ∈ L, w t.1 = t.2

/-- An individual direction outside W fixes the sign of every surviving literal. -/
theorem signs (L : Finset (Axis × Bool)) (off : Word) (miss : ¬live L off) (w : Word) :
    live L w ↔ ∃ i ∈ L.image Prod.fst, w i = !(off i) := by
  constructor
  · rintro ⟨⟨i,b⟩,hb,hw⟩
    have diff : off i ≠ b := fun e => miss ⟨(i,b),hb,e⟩
    refine ⟨i,Finset.mem_image.mpr ⟨(i,b),hb,rfl⟩,?_⟩
    change w i = b at hw
    rw [hw]
    cases b <;> cases h : off i <;> simp_all
  · rintro ⟨i,hi,hw⟩
    obtain ⟨⟨j,b⟩,hm,e⟩ := Finset.mem_image.mp hi
    change j=i at e
    subst j
    have diff : off i ≠ b := fun e => miss ⟨(i,b),hm,e⟩
    refine ⟨(i,b),hm,?_⟩
    change w i = b
    rw [hw]
    cases b <;> cases h : off i <;> simp_all

/-- Relabel any set of selected axes onto its initial segment, simultaneously
moving the excluded conditional axis to the last position. -/
theorem arrange (S : Finset Axis) (owner : Axis) (missing : owner ∉ S) :
    S.card ≤ 5 ∧ ∃ p : Equiv.Perm Axis, p owner = 5 ∧
      ∀ i, i ∈ S ↔ (p i).val < S.card := by
  classical
  have small : S.card < 6 := by
    have h := Fintype.card_subtype_lt (p:=fun i : Axis => i ∈ S) missing
    simpa using h
  let q := fun i : Axis => i.val < S.card
  have eq : Fintype.card {i : Axis // i ∈ S} = Fintype.card {i : Axis // q i} := by
    rw [Fintype.card_fin_lt_of_le (Nat.le_of_lt small)]
    exact Fintype.card_coe S
  let left := Fintype.equivOfCardEq eq
  let right := Fintype.equivOfCardEq (Fintype.card_compl_eq_card_compl _ _ eq)
  let e := Equiv.subtypeCongr left right
  have side (i : Axis) : i ∈ S ↔ q (e i) := by
    by_cases hi : i ∈ S
    · have he : e i = (left ⟨i,hi⟩).val := by simp [e,Equiv.subtypeCongr,hi]
      rw [he]
      exact iff_of_true hi (left ⟨i,hi⟩).property
    · have he : e i = (right ⟨i,hi⟩).val := by simp [e,Equiv.subtypeCongr,hi]
      rw [he]
      exact iff_of_false hi (right ⟨i,hi⟩).property
  let last : Axis := 5
  have lo : ¬q (e owner) := fun h => missing ((side owner).mpr h)
  have ll : ¬q last := by change ¬5 < S.card; omega
  refine ⟨by omega,e.trans (Equiv.swap (e owner) last),by simp [last],?_⟩
  intro i
  rw [side]
  change q (e i) ↔ q (Equiv.swap (e owner) last (e i))
  by_cases ho : e i = e owner
  · simp [ho,lo,ll]
  by_cases hl : e i = last
  · simp [hl,lo,ll]
  rw [Equiv.swap_apply_of_ne_of_ne ho hl]

theorem canonical (L : Finset (Axis × Bool)) (owner : Axis)
    (fresh : owner ∉ L.image Prod.fst) (off : Word) (miss : ¬live L off) :
    ∃ k ≤ 5, ∃ p : Equiv.Perm Axis, p owner = 5 ∧
      ∃ flip : Word, ∀ w : Word, live L w ↔
        ∃ j : Axis, j.val < k ∧ xor (w (p.symm j)) (flip j) = true := by
  obtain ⟨bound,p,hp,side⟩ := arrange (L.image Prod.fst) owner fresh
  refine ⟨_,bound,p,hp,fun j => off (p.symm j),?_⟩
  intro w
  rw [signs L off miss]
  constructor
  · rintro ⟨i,hi,hw⟩
    refine ⟨p i,(side i).mp hi,?_⟩
    simp only [Equiv.symm_apply_apply]
    rw [hw]
    cases off i <;> rfl
  · rintro ⟨j,hj,hw⟩
    refine ⟨p.symm j,(side _).mpr (by simpa using hj),?_⟩
    cases h₁ : w (p.symm j) <;> cases h₂ : off (p.symm j) <;> simp_all

end Research.Graph9822.OneNonfull
#print axioms Research.Graph9822.OneNonfull.canonical
