import Std
namespace Research.Graph9822FiveOrbit
def fact : Nat → Nat
  | 0 => 1
  | n+1 => (n+1)*fact n
def unrank : Nat → List Nat → Nat → List Nat
  | 0,_,_ => []
  | n+1, xs, rank =>
    let i := rank / fact n
    (xs[i]?.getD 0) :: unrank n (xs.eraseIdx i) (rank % fact n)
def permList (rank : Nat) := unrank 5 [0,1,2,3,4] rank
def dest (rank i : Nat) := (permList rank)[i]?.getD 0
def origin (rank i : Nat) := (permList rank).idxOf i
def bits5 (w : Nat → Bool) : Nat :=
  (if w 0 then 1 else 0) + (if w 1 then 2 else 0) + (if w 2 then 4 else 0) +
  (if w 3 then 8 else 0) + (if w 4 then 16 else 0)
def wordImage (code w : Nat) : Nat :=
  bits5 fun j => xor (w.testBit (origin (code/32) j)) ((code%32).testBit j)
def rowCheck (src dst : List Nat) (code : Nat) : Bool :=
  decide (src.length=5 ∧ dst.length=5 ∧ code<3840) &&
  (List.range 5).all fun i => (List.range 32).all fun w =>
    (src[i]?.getD 0).testBit w == (dst[dest (code/32) i]?.getD 0).testBit (wordImage code w)

theorem checked_bits {src dst code} (h : rowCheck src dst code = true)
    (i w : Nat) (hi : i<5) (hw : w<32) :
    (src[i]?.getD 0).testBit w = (dst[dest (code/32) i]?.getD 0).testBit (wordImage code w) := by
  have hs := List.all_eq_true.mp (Bool.and_eq_true_iff.mp h).2 i (List.mem_range.mpr hi)
  simpa using List.all_eq_true.mp hs w (List.mem_range.mpr hw)

theorem checked_code {src dst code} (h : rowCheck src dst code = true) : code<3840 := by
  have t : src.length=5 ∧ dst.length=5 ∧ code<3840 := of_decide_eq_true (Bool.and_eq_true_iff.mp h).1
  exact t.2.2
structure Record where
  rep : Nat
  code : Nat
  deriving Repr, DecidableEq
def recordAt (data : ByteArray) (n : Nat) : Option Record := do
  let a ← data[4*n]?
  let b ← data[4*n+1]?
  let c ← data[4*n+2]?
  let d ← data[4*n+3]?
  return ⟨a.toNat + 256*b.toNat,c.toNat + 256*d.toNat⟩
def verifyAt (srcs reps : Array (List Nat)) (data : ByteArray) (n : Nat) : Bool :=
  (do
    let src ← srcs[n]?
    let recd ← recordAt data n
    let dst ← reps[recd.rep]?
    return rowCheck src dst recd.code : Option Bool).getD false

theorem verifyAt_sound {srcs reps data n} (h : verifyAt srcs reps data n = true) :
    ∃ src r dst, srcs[n]? = some src ∧ recordAt data n = some r ∧ reps[r.rep]? = some dst ∧
      rowCheck src dst r.code = true := by
  cases hs : srcs[n]? with
  | none => simp [verifyAt,hs] at h
  | some src =>
    cases hr : recordAt data n with
    | none => simp [verifyAt,hs,hr] at h
    | some r =>
      cases hd : reps[r.rep]? with
      | none => simp [verifyAt,hs,hr,hd] at h
      | some dst =>
        refine ⟨src,r,dst,?_,?_,?_,?_⟩
        · simp [hs]
        · simp [hr]
        · simp [hd]
        · simpa [verifyAt,hs,hr,hd] using h
end Research.Graph9822FiveOrbit
