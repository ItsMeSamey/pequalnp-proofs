import H5GeoClosed9822
import OR9822ArmMask
namespace Research.Graph9822.H5Geo
open Research.Graph9822.FreeOR Research.Graph9822Resolution

def operand (raw : Arm) (ps : List Product) (m : Nat) :=
  readArm (fullWire m) raw || ps.any (productBit (fullWire m))

theorem physical_misses (i j : Fin 16) (lt : i<j) (raw : Arm) (ps : List Product)
    (leak : ∀ p∈ps,∃ k : Fin 16,productBit (fullWire (mis k)) p=true)
    (reject : ∀ k : Fin 16,k≠i → k≠j → operand raw ps (mis k)=false) :
    ∃ e : Fin 13,operand raw ps (edge e)=false := by
  let T := {p : Product // p∈ps}
  let l (t : T) := armMask t.val.1
  let r (t : T) := armMask t.val.2
  have eval (t : T) (m : Nat) : product (l t) (r t) m=productBit (fullWire m) t.val := by
    simp [l,r,product,productBit,read_arm_mask]
  have off (k : Fin 16) (ki : k≠i) (kj : k≠j) :
      readArm (fullWire (mis k)) raw=false ∧ ∀ p∈ps,productBit (fullWire (mis k)) p=false := by
    simpa [operand,List.any_eq_false] using reject k ki kj
  obtain ⟨e,a,b⟩ := misses_edge i j lt (armMask raw) l r
    (fun t => by obtain ⟨k,hit⟩ := leak t.val t.property; exact ⟨k,(eval t _).trans hit⟩)
    (fun k ki kj => (read_arm_mask raw _).symm.trans (off k ki kj).1)
    (fun k ki kj t => (eval t _).trans ((off k ki kj).2 t.val t.property))
  have er := (read_arm_mask raw _).trans a
  have ep (p : Product) (mem : p∈ps) := (eval ⟨p,mem⟩ (edge e)).symm.trans (b ⟨p,mem⟩)
  refine ⟨e,?_⟩
  unfold operand
  rw [er,Bool.false_or]
  exact List.any_eq_false.mpr (fun p mem => Bool.eq_false_iff.mp (ep p mem))
end Research.Graph9822.H5Geo
#print axioms Research.Graph9822.H5Geo.physical_misses
