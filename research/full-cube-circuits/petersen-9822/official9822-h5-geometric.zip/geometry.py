from collections import Counter
from itertools import combinations, product
edges = [6,24,17,33,66,132,264,528,160,640,576,320,288]
negative = [50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773]
def vertices(row):
    return [v for v in range(10) if row >> v & 1]
sites = [sum(1 << k for k,n in enumerate(negative) if n >> v & 1) for v in range(10)]
def coverable(i,j,e):
    others = 65535 - (1 << i) - (1 << j)
    for leak in (negative[i],negative[j]):
        for x,y in product(vertices(leak), repeat=2):
            for a,b in product(vertices(e), repeat=2):
                if not ((sites[a] | sites[x]) & (sites[b] | sites[y]) & others):
                    return True
    return False
witness = [0]*256
hist = Counter()
for i,j in combinations(range(16),2):
    live = [coverable(i,j,e) for e in edges]
    hist[sum(live)] += 1
    witness[16*i+j] = live.index(False)
assert hist == {0:105,6:2,7:8,8:5}
print('Coverage histogram:', sorted(hist.items()))
print('Selected edge histogram:', Counter(witness[16*i+j] for i,j in combinations(range(16),2)))
if __name__ == '__main__':
    with open('H5GeoData9822.lean','w') as out:
        out.write('import OR9822H2RawMask\nnamespace Research.Graph9822.H5Geo\n')
        out.write('def firstMiss : Array Nat := #['+','.join(map(str,witness))+']\n')
        out.write('def signatures : Array Nat := #['+','.join(map(str,sites))+']\n')
        out.write('end Research.Graph9822.H5Geo\n')
