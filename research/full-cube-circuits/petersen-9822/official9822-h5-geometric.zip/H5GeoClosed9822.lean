import H5GeoLedger9822
import H5GeoSound9822
namespace Research.Graph9822.H5Geo
open Research.Graph9822OneHidden (meets)
open Research.Graph9822H2Check (meets_iff_exists)

private theorem every_raw : ∀ (i j : Fin 16), i<j → ∀ v : Fin 10,
    ∃ k : Fin 16,k≠i ∧ k≠j ∧ (mis k).testBit v.val=true := by decide +kernel

theorem misses_edge {T : Type} (i j : Fin 16) (lt : i<j) (raw : Nat) (left right : T→Nat)
    (leak : ∀ t, ∃ n : Fin 16, product (left t) (right t) (mis n)=true)
    (rejectRaw : ∀ k : Fin 16,k≠i → k≠j → meets raw (mis k)=false)
    (reject : ∀ k : Fin 16,k≠i → k≠j → ∀ t,product (left t) (right t) (mis k)=false) :
    ∃ e : Fin 13, meets raw (edge e)=false ∧ ∀ t,product (left t) (right t) (edge e)=false := by
  let e := pick i j
  refine ⟨e,?_,?_⟩
  · apply Bool.eq_false_iff.mpr
    intro hot
    obtain ⟨v,rv,ev⟩ := meets_iff_exists.mp hot
    have bound : v<10 := by
      by_contra! hi
      have no := Nat.testBit_lt_two_pow (lt_of_lt_of_le (small_edge e)
        (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) hi))
      simp [no] at ev
    obtain ⟨k,ki,kj,vk⟩ := every_raw i j lt ⟨v,bound⟩
    have bad := meets_iff_exists.mpr ⟨v,rv,vk⟩
    rw [rejectRaw k ki kj] at bad
    contradiction
  · intro t
    apply Bool.eq_false_iff.mpr
    intro positive
    obtain ⟨n,on⟩ := leak t
    have rulesAt : rules i j (mis n) (edge e)=true := by
      by_cases first : n=i
      · simpa [first,e] using (for_pair ledger i j lt).1
      by_cases second : n=j
      · simpa [second,e] using (for_pair ledger i j lt).2
      rw [reject n first second t] at on
      contradiction
    obtain ⟨k,ki,kj,forbiddenHot⟩ := expansion i j lt n e _ _ rulesAt on positive
    rw [reject k ki kj t] at forbiddenHot
    contradiction

end Research.Graph9822.H5Geo
#print axioms Research.Graph9822.H5Geo.misses_edge
