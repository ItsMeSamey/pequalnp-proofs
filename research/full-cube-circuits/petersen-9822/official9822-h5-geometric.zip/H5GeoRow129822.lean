import H5GeoCheck9822
namespace Research.Graph9822.H5Geo
set_option maxRecDepth 2048 in
set_option maxHeartbeats 1000000 in
theorem row12 : checked 12=true := by decide +kernel
end Research.Graph9822.H5Geo
