import H5GeoCheck9822
namespace Research.Graph9822.H5Geo
open Research.Graph9822OneHidden (meets)
open Research.Graph9822H2Check (meets_iff_exists)

def product (a b m : Nat) := meets a m && meets b m

private theorem hit (a m : Nat) (small : m<1024) (on : meets a m=true) :
    ∃ v : Fin 10, a.testBit v.val=true ∧ m.testBit v.val=true := by
  obtain ⟨k,ak,mk⟩ := (meets_iff_exists.mp on)
  have lt : k<10 := by
    by_contra! hi
    have no := Nat.testBit_lt_two_pow (lt_of_lt_of_le small
      (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) hi))
    simp [no] at mk
  exact ⟨⟨k,lt⟩,ak,mk⟩

private theorem transfer (i j : Fin 16) (lt : i<j) (a x b y : Fin 10)
    (cross : crossing i j a.val x.val b.val y.val ≠ 0) :
    ∃ k : Fin 16, k≠i ∧ k≠j ∧
      ((mis k).testBit a.val=true ∨ (mis k).testBit x.val=true) ∧
      ((mis k).testBit b.val=true ∨ (mis k).testBit y.val=true) := by
  obtain ⟨z,hz⟩ : ∃ z,(crossing i j a.val x.val b.val y.val).testBit z=true := by
    by_contra! off
    apply cross
    apply Nat.eq_of_testBit_eq
    simpa using off
  simp only [crossing,Nat.testBit_and,Nat.testBit_or,Bool.and_eq_true,Bool.or_eq_true] at hz
  have bound : z<16 := by
    by_contra! large
    have no := Nat.testBit_lt_two_pow (lt_of_lt_of_le (inside i j)
      (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) large))
    simp [no] at hz
  let k : Fin 16 := ⟨z,bound⟩
  obtain ⟨ki,kj⟩ := retained i j k lt hz.2
  refine ⟨k,ki,kj,?_,?_⟩
  · simpa only [←coordinates a k,←coordinates x k] using hz.1.1
  · simpa only [←coordinates b k,←coordinates y k] using hz.1.2

theorem expansion (i j : Fin 16) (lt : i<j) (s : Fin 16) (e : Fin 13) (a b : Nat)
    (ok : rules i j (mis s) (edge e)=true)
    (leak : product a b (mis s)=true) (hot : product a b (edge e)=true) :
    ∃ k : Fin 16,k≠i ∧ k≠j ∧ product a b (mis k)=true := by
  have h1 := Bool.and_eq_true_iff.mp hot
  have h2 := Bool.and_eq_true_iff.mp leak
  obtain ⟨v,av,ve⟩ := hit _ _ (small_edge e) h1.1
  obtain ⟨w,bw,we⟩ := hit _ _ (small_edge e) h1.2
  obtain ⟨x,ax,xs⟩ := hit _ _ (small_mis s) h2.1
  obtain ⟨y,byb,ys⟩ := hit _ _ (small_mis s) h2.2
  have mem (m : Nat) (u : Fin 10) (on : m.testBit u.val=true) : u.val∈vertices m :=
    List.mem_filter.mpr ⟨List.mem_range.mpr u.isLt,on⟩
  have xx := List.all_eq_true.mp ok x.val (mem _ _ xs)
  have yy := List.all_eq_true.mp xx y.val (mem _ _ ys)
  have vv := List.all_eq_true.mp yy v.val (mem _ _ ve)
  have ww := List.all_eq_true.mp vv w.val (mem _ _ we)
  obtain ⟨k,ki,kj,ha,hb⟩ := transfer i j lt v x w y (bne_iff_ne.mp ww)
  refine ⟨k,ki,kj,Bool.and_eq_true_iff.mpr ⟨?_,?_⟩⟩
  · exact meets_iff_exists.mpr (ha.elim (fun h => ⟨v.val,av,h⟩) (fun h => ⟨x.val,ax,h⟩))
  · exact meets_iff_exists.mpr (hb.elim (fun h => ⟨w.val,bw,h⟩) (fun h => ⟨y.val,byb,h⟩))

end Research.Graph9822.H5Geo
#print axioms Research.Graph9822.H5Geo.expansion
