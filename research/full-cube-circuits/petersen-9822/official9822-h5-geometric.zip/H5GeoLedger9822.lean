import H5GeoRow009822
import H5GeoRow019822
import H5GeoRow029822
import H5GeoRow039822
import H5GeoRow049822
import H5GeoRow059822
import H5GeoRow069822
import H5GeoRow079822
import H5GeoRow089822
import H5GeoRow099822
import H5GeoRow109822
import H5GeoRow119822
import H5GeoRow129822
import H5GeoRow139822
import H5GeoRow149822
import H5GeoRow159822
namespace Research.Graph9822.H5Geo
theorem ledger (i : Fin 16) : checked i=true := by
  fin_cases i
  · exact row00
  · exact row01
  · exact row02
  · exact row03
  · exact row04
  · exact row05
  · exact row06
  · exact row07
  · exact row08
  · exact row09
  · exact row10
  · exact row11
  · exact row12
  · exact row13
  · exact row14
  · exact row15
end Research.Graph9822.H5Geo
