import H5GeoData9822
namespace Research.Graph9822.H5Geo
open Research.Graph9822OneHidden (edges)
open Research.Graph9822.FourSaturation (witnesses)
def edge (e : Fin 13) := edges[e.val]!
def mis (n : Fin 16) := witnesses[n.val]!
def site (p : Nat) := signatures[p]!
def forbidden (i j : Fin 16) := 65535 ^^^ ((2^i.val) ||| (2^j.val))
def pick (i j : Fin 16) : Fin 13 := Fin.ofNat 13 firstMiss[16*i.val+j.val]!
def vertices (m : Nat) := (List.range 10).filter m.testBit
def crossing (i j : Fin 16) (a x b y : Nat) : Nat :=
  ((site a ||| site x) &&& (site b ||| site y)) &&& forbidden i j
def rules (i j : Fin 16) (m e : Nat) : Bool :=
  let vs := vertices m
  let es := vertices e
  vs.all fun x => vs.all fun y => es.all fun a => es.all fun b =>
    crossing i j a x b y != 0

def checked (i : Fin 16) : Bool :=
  (List.finRange 16).all fun j => !(decide (i<j)) ||
    (rules i j (mis i) (edge (pick i j)) && rules i j (mis j) (edge (pick i j)))

theorem for_pair (all : ∀ i,checked i=true) (i j : Fin 16) (lt : i<j) :
    rules i j (mis i) (edge (pick i j))=true ∧
    rules i j (mis j) (edge (pick i j))=true := by
  have ok := List.all_eq_true.mp (all i) j (List.mem_finRange j)
  simpa [lt] using ok

theorem coordinates : ∀ (v : Fin 10) (n : Fin 16),
    (site v.val).testBit n.val=(mis n).testBit v.val := by decide +kernel
theorem inside : ∀ (i j : Fin 16), forbidden i j<65536 := by decide +kernel
theorem retained : ∀ (i j k : Fin 16), i<j → (forbidden i j).testBit k.val = true →
    k≠i ∧ k≠j := by decide +kernel
theorem small_mis : ∀ n : Fin 16,mis n<1024 := by decide +kernel
theorem small_edge : ∀ e : Fin 13,edge e<1024 := by decide +kernel
end Research.Graph9822.H5Geo
