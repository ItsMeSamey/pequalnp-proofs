from pathlib import Path
import hashlib,json,sys
here=Path(__file__).resolve().parent
dst=Path(sys.argv[1]);dst.mkdir(parents=True,exist_ok=True)
modules=['CoverScanPilot9822']
for p in sorted((here/'stages').glob('PackedScan9822_*.lean')):
 index=p.stem.rsplit('_',1)[1]
 body=p.read_text().replace('import PackedNodeCommon9822','import CoverLookup9822\nimport SignedNode')
 if index=='000':
  assert body==(dst.parent/'CoverScanPilot9822.lean').read_text()
 else:
  mod='CoverScan'+index
  (dst/(mod+'.lean')).write_text(body)
  modules.append(mod)
(dst/'CoverScansAll9822.lean').write_text(''.join('import '+m+'\n' for m in modules))
body=(here/'PackedPathReuse9822.lean').read_text().replace('import PackedLookup','import CoverLookup9822').replace('import PackedScans9822','import CoverScansAll9822')
(dst/'CoverPathAll9822.lean').write_text(body)
print(' '.join(modules[1:]+['CoverScansAll9822','CoverPathAll9822']))
