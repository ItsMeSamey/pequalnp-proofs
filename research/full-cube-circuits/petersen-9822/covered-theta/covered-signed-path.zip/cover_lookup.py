"""Synthesize a proof-carrying witness search; the frozen historical lookup is untouched."""
from verify_path import entries,names,scans,legal,closes,here
from collections import defaultdict
from pathlib import Path
import sys
dest=Path(sys.argv[1])
zs=list(names.values())
demand=set()
fallback=set()
for (j,t),nxt in scans.items():
 for s in range(1024):
  if legal(j,t,s):
   (fallback if s|t in nxt else demand).add((j,s,t))
assert len(demand)==973
allp=demand|fallback
valid={p:{i for i,z in enumerate(zs) if closes(z,*p)} for p in allp}
def group(p):
 j,s,t=p
 return j
blocks=defaultdict(set)
for p in demand:blocks[group(p)].add(p)
plans={}
for k,b in sorted(blocks.items()):
 rest=set(b);row=[]
 while rest:
  i=max(range(len(zs)), key=lambda i:sum(i in valid[p] for p in rest))
  covered={p for p in rest if i in valid[p]};assert covered
  row.append(i);rest-=covered
 plans[k]=row
used=sorted(set(v for a in plans.values() for v in a))
remap={v:i for i,v in enumerate(used)}
def literal(w):return '⟨'+','.join([str(w[0]).lower(),*map(str,w[1:])])+'⟩'
out=['import SignedCensusBundle9822','namespace Petersen9822','private def book : Array Witness := #[',',\n'.join(literal(zs[i]) for i in used)+']','private def hints : Nat → List Nat']
for j,xs in plans.items():out.append('  | '+str(j)+' => ['+','.join(str(remap[i]) for i in xs)+']')
out+=['  | _ => []','def frozen : Lookup := fun j s t =>','  (hints j).findSome? fun i => do','    let z ← book[i]?','    if z.check (ownerBit j) s t (later t s) then some z else none','end Petersen9822']
p=dest/'CoverLookup9822.lean';p.write_text('\n'.join(out)+'\n')
cost=[];hits=0
for pnt in allp:
 a=plans.get(group(pnt),[]);h=next((n for n,i in enumerate(a,1) if i in valid[pnt]),None)
 if pnt in demand:assert h is not None
 hits+=h is not None
 cost.append(len(a) if h is None else h)
print('demand,fall,ids,tests,num,mean,max,bytes',len(demand),len(fallback),len(used),sum(cost),len(cost),sum(cost)/len(cost),max(cost),p.stat().st_size,[(j,len(x))for j,x in plans.items()],hits)
from verify_path import roots,edge
newscan={};visited=set()
def shrink(js,t):
 key=(tuple(js),t)
 if key in visited:return
 visited.add(key)
 if not js:
  assert edge(1023^t)
  return
 j=js[0]
 ix=(j,t)
 if ix not in newscan:
  newscan[ix]=sorted({t|s for s in range(1024) if legal(j,t,s) and not any(i in valid[(j,s,t)] for i in plans[j])})
  assert set(newscan[ix])<=set(scans[ix])
 for u in newscan[ix]:shrink(js[1:],u)
for js,t in roots:shrink(js,t)
print('pruned scans/states/next',len(newscan),len(visited),sum(map(len,newscan.values())),sum(map(len,scans.values())))
