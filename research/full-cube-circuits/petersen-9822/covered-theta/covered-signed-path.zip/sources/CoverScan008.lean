import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g8 : nodeCheck frozen 2 400 [402] = true := by decide +kernel
theorem g9 : nodeCheck frozen 2 408 [410] = true := by decide +kernel
theorem g10 : nodeCheck frozen 2 416 [418] = true := by decide +kernel
theorem g11 : nodeCheck frozen 2 560 [562] = true := by decide +kernel
theorem g12 : nodeCheck frozen 2 561 [563] = true := by decide +kernel
theorem g13 : nodeCheck frozen 2 784 [786] = true := by decide +kernel
theorem g14 : nodeCheck frozen 2 792 [794] = true := by decide +kernel
theorem g15 : nodeCheck frozen 2 800 [802] = true := by decide +kernel
end Petersen9822.PackedCertificate
