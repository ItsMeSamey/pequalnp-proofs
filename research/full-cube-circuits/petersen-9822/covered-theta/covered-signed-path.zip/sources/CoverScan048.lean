import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g48 : nodeCheck frozen 1 57 [57] = true := by decide +kernel
theorem g49 : nodeCheck frozen 1 58 [58,59,122,123,314,315,570,571,826,827] = true := by decide +kernel
theorem g50 : nodeCheck frozen 1 59 [59,123,315,571,827] = true := by decide +kernel
theorem g51 : nodeCheck frozen 1 112 [112,113] = true := by decide +kernel
theorem g52 : nodeCheck frozen 1 113 [113] = true := by decide +kernel
theorem g53 : nodeCheck frozen 1 114 [114,115,122,123,370,371,626,627,634,635,882,883] = true := by decide +kernel
theorem g54 : nodeCheck frozen 1 115 [115,123,371,627,635,883] = true := by decide +kernel
theorem g55 : nodeCheck frozen 1 176 [176,177] = true := by decide +kernel
end Petersen9822.PackedCertificate
