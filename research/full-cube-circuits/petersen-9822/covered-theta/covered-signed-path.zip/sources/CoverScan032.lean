import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g32 : nodeCheck frozen 0 177 [177] = true := by decide +kernel
theorem g33 : nodeCheck frozen 0 272 [272,280] = true := by decide +kernel
theorem g34 : nodeCheck frozen 0 352 [352] = true := by decide +kernel
theorem g35 : nodeCheck frozen 0 400 [400,408] = true := by decide +kernel
theorem g36 : nodeCheck frozen 0 408 [408] = true := by decide +kernel
theorem g37 : nodeCheck frozen 0 416 [416] = true := by decide +kernel
theorem g38 : nodeCheck frozen 0 560 [560,561] = true := by decide +kernel
theorem g39 : nodeCheck frozen 0 561 [561] = true := by decide +kernel
end Petersen9822.PackedCertificate
