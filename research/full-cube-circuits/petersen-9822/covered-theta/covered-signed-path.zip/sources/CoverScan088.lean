import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g88 : nodeCheck frozen 1 402 [402,403,410,411,434,442,466,474,914,922] = true := by decide +kernel
theorem g89 : nodeCheck frozen 1 408 [408] = true := by decide +kernel
theorem g90 : nodeCheck frozen 1 410 [410,411,442,474,922] = true := by decide +kernel
theorem g91 : nodeCheck frozen 1 416 [416] = true := by decide +kernel
theorem g92 : nodeCheck frozen 1 418 [418,419,426,427,434,482,483,490,491,930,931,938] = true := by decide +kernel
theorem g93 : nodeCheck frozen 1 560 [560,561] = true := by decide +kernel
theorem g94 : nodeCheck frozen 1 561 [561] = true := by decide +kernel
theorem g95 : nodeCheck frozen 1 562 [562,563,570,571,626,627,634,635,818,819] = true := by decide +kernel
end Petersen9822.PackedCertificate
