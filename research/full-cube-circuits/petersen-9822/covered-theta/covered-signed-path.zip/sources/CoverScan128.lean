import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g128 : nodeCheck frozen 0 336 [336,344] = true := by decide +kernel
theorem g129 : nodeCheck frozen 0 344 [344] = true := by decide +kernel
end Petersen9822.PackedCertificate
