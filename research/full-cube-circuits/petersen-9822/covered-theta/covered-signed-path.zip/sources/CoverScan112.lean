import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g112 : nodeCheck frozen 2 273 [275] = true := by decide +kernel
theorem g113 : nodeCheck frozen 2 280 [282] = true := by decide +kernel
theorem g114 : nodeCheck frozen 2 281 [283] = true := by decide +kernel
theorem g115 : nodeCheck frozen 2 288 [290] = true := by decide +kernel
theorem g116 : nodeCheck frozen 2 289 [291] = true := by decide +kernel
theorem g117 : nodeCheck frozen 2 296 [298] = true := by decide +kernel
theorem g118 : nodeCheck frozen 0 273 [273,281] = true := by decide +kernel
theorem g119 : nodeCheck frozen 0 280 [280] = true := by decide +kernel
end Petersen9822.PackedCertificate
