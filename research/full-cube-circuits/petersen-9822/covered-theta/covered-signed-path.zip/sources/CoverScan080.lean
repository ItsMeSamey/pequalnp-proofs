import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g80 : nodeCheck frozen 1 315 [315,379,827] = true := by decide +kernel
theorem g81 : nodeCheck frozen 1 336 [336,344] = true := by decide +kernel
theorem g82 : nodeCheck frozen 1 338 [338,339,346,347,370,378,850,851,858,859,882,890] = true := by decide +kernel
theorem g83 : nodeCheck frozen 1 344 [344] = true := by decide +kernel
theorem g84 : nodeCheck frozen 1 346 [346,347,378,858,859,890] = true := by decide +kernel
theorem g85 : nodeCheck frozen 1 352 [352] = true := by decide +kernel
theorem g86 : nodeCheck frozen 1 354 [354,355,362,363,370,866,867,874,875] = true := by decide +kernel
theorem g87 : nodeCheck frozen 1 400 [400,408] = true := by decide +kernel
end Petersen9822.PackedCertificate
