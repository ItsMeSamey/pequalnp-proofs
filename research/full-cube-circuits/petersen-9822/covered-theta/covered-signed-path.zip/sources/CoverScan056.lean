import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g56 : nodeCheck frozen 1 177 [177] = true := by decide +kernel
theorem g57 : nodeCheck frozen 1 178 [178,179,186,187,242,243,434,435,690,691,698,699] = true := by decide +kernel
theorem g58 : nodeCheck frozen 1 179 [179,187,243,435,691,699] = true := by decide +kernel
theorem g59 : nodeCheck frozen 1 272 [272,280] = true := by decide +kernel
theorem g60 : nodeCheck frozen 1 273 [273,281] = true := by decide +kernel
theorem g61 : nodeCheck frozen 1 274 [274,282] = true := by decide +kernel
theorem g62 : nodeCheck frozen 1 275 [275,283,307,315,339,347,371,379,787,795,819,827] = true := by decide +kernel
theorem g63 : nodeCheck frozen 1 280 [280] = true := by decide +kernel
end Petersen9822.PackedCertificate
