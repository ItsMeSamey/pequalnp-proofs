import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g104 : nodeCheck frozen 2 49 [51] = true := by decide +kernel
theorem g105 : nodeCheck frozen 2 56 [58] = true := by decide +kernel
theorem g106 : nodeCheck frozen 2 57 [59] = true := by decide +kernel
theorem g107 : nodeCheck frozen 2 112 [114] = true := by decide +kernel
theorem g108 : nodeCheck frozen 2 113 [115] = true := by decide +kernel
theorem g109 : nodeCheck frozen 2 176 [178] = true := by decide +kernel
theorem g110 : nodeCheck frozen 2 177 [179] = true := by decide +kernel
theorem g111 : nodeCheck frozen 2 272 [274] = true := by decide +kernel
end Petersen9822.PackedCertificate
