import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g40 : nodeCheck frozen 0 784 [784,792] = true := by decide +kernel
theorem g41 : nodeCheck frozen 0 792 [792] = true := by decide +kernel
theorem g42 : nodeCheck frozen 0 800 [800] = true := by decide +kernel
theorem g43 : nodeCheck frozen 1 48 [48,49] = true := by decide +kernel
theorem g44 : nodeCheck frozen 1 49 [49] = true := by decide +kernel
theorem g45 : nodeCheck frozen 1 50 [50,51] = true := by decide +kernel
theorem g46 : nodeCheck frozen 1 51 [51] = true := by decide +kernel
theorem g47 : nodeCheck frozen 1 56 [56,57] = true := by decide +kernel
end Petersen9822.PackedCertificate
