import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g16 : nodeCheck frozen 3 48 [48,49,56,57,112,176,304,560] = true := by decide +kernel
theorem g17 : nodeCheck frozen 3 49 [49,57,113,177,305,561] = true := by decide +kernel
theorem g18 : nodeCheck frozen 3 50 [50,51,58,59,114,178,306,562] = true := by decide +kernel
theorem g19 : nodeCheck frozen 3 51 [51,59,115,179,307,563] = true := by decide +kernel
theorem g20 : nodeCheck frozen 3 272 [272,273,280,281,304,336,400,784] = true := by decide +kernel
theorem g21 : nodeCheck frozen 3 274 [274,275,282,283,306,338,346,402,786] = true := by decide +kernel
theorem g22 : nodeCheck frozen 3 280 [280,281,312,344,408,792] = true := by decide +kernel
theorem g23 : nodeCheck frozen 3 282 [282,283,314,346,410,794] = true := by decide +kernel
end Petersen9822.PackedCertificate
