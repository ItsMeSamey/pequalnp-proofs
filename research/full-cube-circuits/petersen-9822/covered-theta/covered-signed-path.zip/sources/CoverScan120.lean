import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g120 : nodeCheck frozen 0 281 [281] = true := by decide +kernel
theorem g121 : nodeCheck frozen 0 288 [288] = true := by decide +kernel
theorem g122 : nodeCheck frozen 0 289 [289] = true := by decide +kernel
theorem g123 : nodeCheck frozen 0 296 [296] = true := by decide +kernel
theorem g124 : nodeCheck frozen 0 304 [304,305,312,313] = true := by decide +kernel
theorem g125 : nodeCheck frozen 0 305 [305,313] = true := by decide +kernel
theorem g126 : nodeCheck frozen 0 312 [312,313] = true := by decide +kernel
theorem g127 : nodeCheck frozen 0 313 [313] = true := by decide +kernel
end Petersen9822.PackedCertificate
