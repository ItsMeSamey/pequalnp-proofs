import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g96 : nodeCheck frozen 1 563 [563,571,627,635,819] = true := by decide +kernel
theorem g97 : nodeCheck frozen 1 784 [784,792] = true := by decide +kernel
theorem g98 : nodeCheck frozen 1 786 [786,787,794,795,818,826,850,851,858,859,882,890] = true := by decide +kernel
theorem g99 : nodeCheck frozen 1 792 [792] = true := by decide +kernel
theorem g100 : nodeCheck frozen 1 794 [794,795,826,858,859,890] = true := by decide +kernel
theorem g101 : nodeCheck frozen 1 800 [800] = true := by decide +kernel
theorem g102 : nodeCheck frozen 1 802 [802,803,810,811,818,866,867,874,875,882] = true := by decide +kernel
theorem g103 : nodeCheck frozen 2 48 [50] = true := by decide +kernel
end Petersen9822.PackedCertificate
