import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g24 : nodeCheck frozen 3 288 [288,289,296,304,352,416,800] = true := by decide +kernel
theorem g25 : nodeCheck frozen 3 290 [290,291,298,306,354,418,802] = true := by decide +kernel
theorem g26 : nodeCheck frozen 0 49 [49] = true := by decide +kernel
theorem g27 : nodeCheck frozen 0 56 [56,57] = true := by decide +kernel
theorem g28 : nodeCheck frozen 0 57 [57] = true := by decide +kernel
theorem g29 : nodeCheck frozen 0 112 [112,113] = true := by decide +kernel
theorem g30 : nodeCheck frozen 0 113 [113] = true := by decide +kernel
theorem g31 : nodeCheck frozen 0 176 [176,177] = true := by decide +kernel
end Petersen9822.PackedCertificate
