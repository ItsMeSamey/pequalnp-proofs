import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g72 : nodeCheck frozen 1 298 [298,299,314,362,363,378,810,811] = true := by decide +kernel
theorem g73 : nodeCheck frozen 1 304 [304,305,312,313] = true := by decide +kernel
theorem g74 : nodeCheck frozen 1 305 [305,313] = true := by decide +kernel
theorem g75 : nodeCheck frozen 1 306 [306,307,314,315,370,371,378,379,818,819,826,827] = true := by decide +kernel
theorem g76 : nodeCheck frozen 1 307 [307,315,371,379,819,827] = true := by decide +kernel
theorem g77 : nodeCheck frozen 1 312 [312,313] = true := by decide +kernel
theorem g78 : nodeCheck frozen 1 313 [313] = true := by decide +kernel
theorem g79 : nodeCheck frozen 1 314 [314,315,378,379,826,827] = true := by decide +kernel
end Petersen9822.PackedCertificate
