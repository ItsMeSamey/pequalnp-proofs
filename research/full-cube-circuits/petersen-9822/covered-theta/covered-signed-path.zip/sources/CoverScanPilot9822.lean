import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g0 : nodeCheck frozen 0 48 [48,49] = true := by decide +kernel
theorem g1 : nodeCheck frozen 2 304 [306] = true := by decide +kernel
theorem g2 : nodeCheck frozen 2 305 [307] = true := by decide +kernel
theorem g3 : nodeCheck frozen 2 312 [314] = true := by decide +kernel
theorem g4 : nodeCheck frozen 2 313 [315] = true := by decide +kernel
theorem g5 : nodeCheck frozen 2 336 [338] = true := by decide +kernel
theorem g6 : nodeCheck frozen 2 344 [346] = true := by decide +kernel
theorem g7 : nodeCheck frozen 2 352 [354] = true := by decide +kernel
end Petersen9822.PackedCertificate
