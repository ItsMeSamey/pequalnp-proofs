import CoverLookup9822
import SignedNode
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822.PackedCertificate
theorem g64 : nodeCheck frozen 1 281 [281] = true := by decide +kernel
theorem g65 : nodeCheck frozen 1 282 [282] = true := by decide +kernel
theorem g66 : nodeCheck frozen 1 283 [283,315,347,379,795,827] = true := by decide +kernel
theorem g67 : nodeCheck frozen 1 288 [288] = true := by decide +kernel
theorem g68 : nodeCheck frozen 1 289 [289] = true := by decide +kernel
theorem g69 : nodeCheck frozen 1 290 [290] = true := by decide +kernel
theorem g70 : nodeCheck frozen 1 291 [291,299,307,355,363,371,803,811] = true := by decide +kernel
theorem g71 : nodeCheck frozen 1 296 [296] = true := by decide +kernel
end Petersen9822.PackedCertificate
