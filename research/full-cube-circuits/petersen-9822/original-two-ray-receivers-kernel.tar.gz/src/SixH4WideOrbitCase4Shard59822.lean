import SixH4WideOrbitCase4Data9822
namespace Research.Graph9822.TwoDirect.Orbit01
open PEqualNP.Library.LRAT
set_option maxRecDepth 50000
set_option maxHeartbeats 0
def block4x40 := rules4Part40.zip numericPart40
theorem good4x40 : block4x40.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x40 : block4x40.map Prod.snd = numericPart40 := List.map_snd_zip (by decide +kernel)
def block4x41 := rules4Part41.zip numericPart41
theorem good4x41 : block4x41.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x41 : block4x41.map Prod.snd = numericPart41 := List.map_snd_zip (by decide +kernel)
def block4x42 := rules4Part42.zip numericPart42
theorem good4x42 : block4x42.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x42 : block4x42.map Prod.snd = numericPart42 := List.map_snd_zip (by decide +kernel)
end Research.Graph9822.TwoDirect.Orbit01
