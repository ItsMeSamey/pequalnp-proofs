import And9822Four
import SixH4DirectLiteral9822
namespace Research.SixH4.PairPartition
open Research.SixH4.DirectLiteral Research.Graph9822Resolution
abbrev V := Fin 10
def adj (x y : V) := onSet [x.val,y.val] = true
instance (x y : V) : Decidable (adj x y) := inferInstanceAs (Decidable (_ = true))
def kept : List (V × V) := [(0, 1), (0, 2), (0, 3), (0, 6), (1, 3), (1, 4), (1, 5), (1, 7), (2, 3), (2, 4), (2, 6), (2, 8), (3, 7), (4, 5), (4, 8)]
def blocked : List (V × V × V × Fin 16) := [(0, 7, 5, 7), (0, 8, 5, 6), (0, 9, 4, 2), (1, 8, 6, 11), (1, 9, 6, 7), (2, 5, 7, 10), (2, 9, 7, 0), (3, 5, 8, 6), (3, 6, 8, 0), (3, 9, 4, 8), (4, 6, 9, 4), (4, 7, 9, 1), (5, 6, 8, 4), (5, 9, 7, 1), (6, 7, 9, 0), (7, 8, 5, 1), (8, 9, 6, 0)]
theorem partition : ∀ x y : V, x < y → ¬ adj x y → (x,y) ∈ kept ∨
    ∃ e ∈ blocked, e.1=x ∧ e.2.1=y := by decide +kernel
theorem certified : ∀ e ∈ blocked, adj e.1 e.2.2.1 ∧ adj e.2.1 e.2.2.1 ∧
    e.1.val ∉ independentSets e.2.2.2 ∧ e.2.1.val ∉ independentSets e.2.2.2 ∧
    e.2.2.1.val ∉ independentSets e.2.2.2 := by
  simp only [blocked,List.forall_mem_cons,List.not_mem_nil,IsEmpty.forall_iff,implies_true,and_true]
  repeat' apply And.intro
  all_goals decide +kernel

theorem survive {x y : V} (ord : x < y) (nonedge : ¬ adj x y)
    (R : V → Set Word) (i j : Fin 6) (s t : Bool)
    (rx : R x ⊆ side i s) (ry : R y ⊆ side j t)
    (common : ∀ z, adj x z → adj y z → R z ⊆ side i (!s) ∪ side j (!t))
    (rooms : ∀ u : Fin 16, ∃ q : Word, ∀ v : V, q ∈ R v ↔ v.val ∉ independentSets u) :
    (x,y) ∈ kept := by
  rcases partition x y ord nonedge with good|⟨⟨a,b,z,u⟩,hb,rfl,rfl⟩
  · exact good
  obtain ⟨az,bz,an,bn,zn⟩ := certified _ hb
  obtain ⟨q,hq⟩ := rooms u
  have qa : q i = s := rx ((hq a).2 an)
  have qb : q j = t := ry ((hq b).2 bn)
  rcases common z az bz ((hq z).2 zn) with h|h
  · change q i = !s at h
    cases s <;> simp_all
  · change q j = !t at h
    cases t <;> simp_all
end Research.SixH4.PairPartition
#print axioms Research.SixH4.PairPartition.survive
