import Mathlib.Data.Set.Basic
namespace Research.SixH4.DirectLiteral
abbrev Word := Fin 6 → Bool
def side (i : Fin 6) (s : Bool) : Set Word := {q | q i = s}
def ray (A : Fin 6 → Set Word) (i : Fin 6) (s : Bool) := A i ∩ side i s
theorem side_rigid {i j : Fin 6} {s t : Bool} (h : side i s ⊆ side j t) :
    i = j ∧ s = t := by
  have eq : i = j := by
    by_contra ne
    let q : Word := fun k => if k = i then s else !t
    have yes : q ∈ side i s := by simp [q,side]
    have bad := h yes
    cases t <;> simp [q,side,Ne.symm ne] at bad
  subst j
  exact ⟨rfl,h (show (fun _ : Fin 6 => s) ∈ side i s from rfl)⟩
theorem fallback_equal {A : Fin 6 → Set Word} {i j k : Fin 6} {s t u : Bool}
    (one : side k u ⊆ ray A i s) (two : side k u ⊆ ray A j t) :
    ray A i s = ray A j t := by
  obtain ⟨rfl,rfl⟩ := side_rigid (fun _ h => (one h).2)
  obtain ⟨rfl,rfl⟩ := side_rigid (fun _ h => (two h).2)
  rfl
end Research.SixH4.DirectLiteral
