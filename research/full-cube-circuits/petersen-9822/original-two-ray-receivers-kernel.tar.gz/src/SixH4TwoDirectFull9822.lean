import SixH4TwoDirectBank9822
import SixH4TwoDirectPair9822
import SixH4FreshCausal9822
import SixH4DirectFull9822
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822Profiles.Fresh Graph9822.StarData
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
private theorem independent_axes {P : Axis6 → Mask6} (R : Fin 10 → Mask6) {u v : Fin 10}
    (separate : R u ≠ R v) (intersects : ∃ q, q ∈ R u ∧ q ∈ R v)
    (cover : adj u v = true → ∀ q, q ∈ R u ∨ q ∈ R v)
    {i j : Axis6} {s t : Bool} (hu : R u = ray P i s) (hv : R v = ray P j t) :
    i ≠ j ∧ adj u v = false := by
  have distinct : i ≠ j := by
    intro he
    subst j
    by_cases e : s=t
    · exact separate (hu.trans ((congrArg (ray P i) e).trans hv.symm))
    obtain ⟨q,qu,qv⟩ := intersects
    rw [hu] at qu
    rw [hv] at qv
    exact e (qu.2.symm.trans qv.2)
  refine ⟨distinct,?_⟩
  cases h : adj u v with
  | false => rfl
  | true =>
    let q : Word6 := fun k => if k=i then !s else !t
    rcases cover h q with qu | qv
    · rw [hu] at qu
      have e : q i = s := qu.2
      cases s <;> simp [q] at e
    · rw [hv] at qv
      have e : q j = t := qv.2
      cases t <;> simp [q,Ne.symm distinct] at e

theorem two_direct_full {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (ok : ∀ a ∈ p, a.2 = P a.1) (named : ∀ i, (i,P i) ∈ p)
    (unique : (p.map Prod.fst).Nodup) (R : Fin 10 → Mask6) (returned : ∀ v, R v ∈ l)
    (proper : ∀ v, ∃ q, q ∉ R v) (inc : ∀ u v, u ≠ v → ¬ R u ⊆ R v)
    (overlap : ∀ u v, u ≠ v → ∃ q, q ∈ R u ∧ q ∈ R v)
    (cover : ∀ u v, adj u v = true → ∀ q, q ∈ R u ∨ q ∈ R v)
    (budget : n ≤ 8) (d : ((Finset.univ : Finset (Fin 10)).filter
      (fun v => RayValue P (R v))).card = 2) {x : Fin 10} {i : Axis6} {s : Bool}
    (direct : R x = ray P i s) : P i = Set.univ := by
  classical
  have sep {a c : Fin 10} (ne : a ≠ c) : R a ≠ R c := fun e => inc a c ne (by rw [e])
  have graph : ∀ v : Fin 10, ∃ y z : Fin 10, v ≠ y ∧ v ≠ z ∧ y ≠ z ∧
      adj v y = true ∧ adj v z = true := by decide +kernel
  obtain ⟨y,z,xy,xz,yz,ey,ez⟩ := graph x
  obtain ⟨q,hq,_⟩ := overlap x y xy
  have live : q ∈ P i := ((direct ▸ hq) : q ∈ ray P i s).1
  have split := straddles (switch_stable scan unique (i,P i) (named i)) s ⟨q,live⟩
  have noRaw := Research.SixH4.DirectLiteral.activation_not_raw P R x i s direct inc split
  obtain ⟨names,_⟩ := two_direct_bank scan P ok R returned proper inc budget d
  have prim : Primitive P (P i) := by
    rcases names (P i) (List.mem_map.mpr ⟨(i,P i),named i,rfl⟩) with good | ⟨v,e⟩
    · exact good
    · exact False.elim (noRaw v e.symm)
  have all {v : Fin 10} (edge : adj x v = true) : ray P i s ∪ R v = Set.univ := by
    apply Set.eq_univ_of_forall
    intro q
    rw [←direct]
    exact cover x v edge q
  have fall {v : Fin 10} (ne : x ≠ v) (edge : adj x v = true) :
      ∃ k t, R v = ray P i (!s) ∪ ray P k t := by
    have nd : ¬RayValue P (R v) := by
      rintro ⟨j,t,hv⟩
      have no := (independent_axes R (sep ne) (overlap _ _ ne) (cover _ _) direct hv).2
      simp_all
    obtain ⟨a,st,c,t,distinct,recipe⟩ := two_nonsibling scan P ok R returned proper inc budget d v nd
    exact Research.SixH4.DirectLiteral.forced_fallback P i s distinct recipe (all edge)
  apply Research.SixH4.DirectLiteral.direct_full P i s _ (R y) (R z) (sep yz)
    (all ey) (all ez) (fall xy ey) (fall xz ez)
  intro nt
  exact prim.resolve_left nt
end
end Research.Graph9822.ArbitraryScan
