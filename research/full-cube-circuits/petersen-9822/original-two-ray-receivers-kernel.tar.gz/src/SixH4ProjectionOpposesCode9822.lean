import SixH4ProjectionOptions9822
namespace Research.SixH4.DirectLiteral
open Research.SixH4.PairPartition Research.Graph9822.TwoDirect

theorem normalized_mem (a b : Lit) (L : V → List Lit) (v : V) (k : Nat) :
    k ∈ normalized a b L v.val ↔ ∃ t ∈ L v, code a b t = k := by
  simp only [normalized,dif_pos v.isLt,mem_sortTwo,List.mem_map]

theorem opposed (a b : Lit) (A : Fin 6 → Set Word) (L : V → List Lit)
    (coherent : ∀ v, consistent (L v))
    (cover : ∀ u v, adj u v → ∀ q, receives A (L u) q ∨ receives A (L v) q) :
    ∀ i j, i < j → j < 10 → edge i j = true →
      opposes (normalized a b L i) (normalized a b L j) = true := by
  intro i j ij hj e
  let u : V := ⟨i,by omega⟩
  let v : V := ⟨j,hj⟩
  obtain ⟨k,s,hu,hv⟩ := edge_opposing (coherent u) (coherent v) (cover u v ((adj_code u v).2 e))
  rw [opposes,List.any_eq_true]
  refine ⟨code a b (k,s),(normalized_mem a b L u _).2 ⟨_,hu,rfl⟩,?_⟩
  apply List.contains_iff_mem.mpr
  exact (normalized_mem a b L v _).2 ⟨mate (k,s),hv,code_mate a b (k,s)⟩

theorem raw_rows_of_membership (a b : Lit) (L : V → List Lit)
    (ray : Nat → Nat → Bool) (hit : Lit → Nat → Bool)
    (decode : ∀ t m, ray (code a b t) m = hit t m)
    (truth : ∀ v : V, ∀ m ∈ rooms, (L v).any (fun t => hit t m) = rawBit v.val m) :
    ∀ v, v < 10 → ∀ m ∈ rooms, (normalized a b L v).any (fun k => ray k m) = rawBit v m := by
  intro n hn m hm
  let v : V := ⟨n,hn⟩
  rw [← truth v m hm]
  apply Bool.eq_iff_iff.mpr
  simp only [List.any_eq_true]
  constructor
  · rintro ⟨k,hk,h⟩
    obtain ⟨t,ht,rfl⟩ := (normalized_mem a b L v k).1 hk
    exact ⟨t,ht,(decode t m) ▸ h⟩
  · rintro ⟨t,ht,h⟩
    exact ⟨_,(normalized_mem a b L v _).2 ⟨t,ht,rfl⟩,(decode t m).symm ▸ h⟩
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.opposed
