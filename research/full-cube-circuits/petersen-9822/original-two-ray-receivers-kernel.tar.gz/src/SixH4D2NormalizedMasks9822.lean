import SixH4ProjectionOptions9822
namespace Research.SixH4.DirectLiteral
noncomputable section
def codeMask (P : Fin 6 → Set Word) (a b : Lit) (k : Nat) : Set Word :=
  {w | ∃ c : Lit,code a b c=k ∧ w∈ray P c.1 c.2}
theorem mask_at (P : Fin 6 → Set Word) (a b : Lit) (ne : a.1≠b.1) (c : Lit) :
    codeMask P a b (code a b c)=ray P c.1 c.2 := by
  ext w
  constructor
  · rintro ⟨d,h,hd⟩
    exact (code_injective ne h) ▸ hd
  · exact fun h=>⟨c,rfl,h⟩

theorem numeric_desc (P : Fin 6 → Set Word) (a b : Lit) (ne : a.1≠b.1)
    (L : Fin 10 → List Lit) (v : Fin 10) (w : Word) :
    receives P (L v) w ↔ ∃ k∈normalized a b L v.val,w∈codeMask P a b k := by
  classical
  simp only [normalized,dif_pos v.isLt,mem_sortTwo]
  constructor
  · rintro ⟨c,h,inray⟩
    exact ⟨code a b c,List.mem_map.mpr ⟨c,h,rfl⟩,by rwa [mask_at P a b ne]⟩
  · rintro ⟨k,h,hit⟩
    obtain ⟨c,hc,rfl⟩ := List.mem_map.mp h
    exact ⟨c,hc,by rwa [mask_at P a b ne] at hit⟩

theorem slots : ∀ a b : Lit,a.1≠b.1 → ∀ j : Fin 6,∃ c : Lit,
    code a b c=2*j.val ∧ code a b (mate c)=2*j.val+1 := by decide +kernel

theorem slot_semantics (P : Fin 6 → Set Word) (a b : Lit) (ne : a.1≠b.1)
    (j : Fin 6) : ∃ c : Lit,axisCode a b c.1=j.val ∧
    (∀ w,w∈codeMask P a b (2*j.val) ∨ w∈codeMask P a b (2*j.val+1) ↔ w∈P c.1) ∧
    (∀ w,w∈codeMask P a b (2*j.val) → w∉codeMask P a b (2*j.val+1)) := by
  obtain ⟨c,ev,od⟩ := slots a b ne j
  refine ⟨c,?_,?_,?_⟩
  · have h := code_axis a b c
    rw [ev] at h
    omega
  · rw [←od,←ev,mask_at P a b ne,mask_at P a b ne]
    intro w
    change ((w∈P c.1 ∧ w c.1=c.2) ∨ (w∈P c.1 ∧ w c.1= !c.2)) ↔ _
    cases c.2 <;> cases w c.1 <;> simp
  · rw [←od,←ev,mask_at P a b ne,mask_at P a b ne]
    intro w he ho
    have bad : c.2= !c.2 := he.2.symm.trans ho.2
    revert bad
    cases c.2 <;> decide
end
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.slot_semantics
