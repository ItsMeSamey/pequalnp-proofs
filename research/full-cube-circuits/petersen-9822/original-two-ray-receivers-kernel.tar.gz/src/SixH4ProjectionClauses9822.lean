import SixH4ProjectedModel9822
namespace Research.Graph9822.TwoDirect
inductive Atom
  | ray (k m : Nat)
  | raw (v : Nat) (t : Arm)
  | origin (j o : Nat)
  deriving DecidableEq, Repr, Inhabited
abbrev Lit := Atom × Bool
abbrev Clause := List Lit
def Atom.val (p : Projection x y) : Atom → Bool
  | .ray k m => p.ray k m
  | .raw v t => decide (p.raw v = t)
  | .origin j o => decide (p.origin j = o)
def Sat (p : Projection x y) (c : Clause) := ∃ l ∈ c, l.1.val p = l.2
def pos (a : Atom) : Lit := (a,true)
def neg (a : Atom) : Lit := (a,false)
inductive Rule
  | rawSome (v : Nat)
  | rawOn (v m : Nat) (t : Arm)
  | rawOff (v m : Nat) (t : Arm) (k : Nat)
  | root (k m : Nat)
  | cross (u v : Nat) (a b : Arm)
  | disj (j m : Nat)
  | originSome (j : Nat)
  | act (j o m mode : Nat)
  deriving Inhabited, Repr

def rootBit (x y k m : Nat) :=
  match k with
  | 0 => rawBit x m
  | 1 => !(rawBit x m)
  | 2 => rawBit y m
  | _ => !(rawBit y m)
def Rule.ok (x y : Nat) : Rule → Bool
  | .rawSome v => decide (v < 10)
  | .rawOn v m _ => decide (v < 10) && rooms.contains m && rawBit v m
  | .rawOff v m t k => decide (v < 10) && rooms.contains m && !(rawBit v m) && t.contains k
  | .root k m => decide (k < 4) && rooms.contains m
  | .cross u v a b => decide (u < v) && decide (v < 10) && edge u v && !(opposes a b)
  | .disj j m => decide (2 ≤ j) && decide (j < 6) && rooms.contains m
  | .originSome j => decide (2 ≤ j) && decide (j < 4)
  | .act j o m mode => decide (2 ≤ j) && decide (j < 4) && rooms.contains m &&
      decide (mode < 3) && (decide (o < 12) || (decide (mode = 2) == rawBit (o-12) m))
def Rule.clause (x y : Nat) : Rule → Clause
  | .rawSome v => (options x y v).map (fun t => pos (.raw v t))
  | .rawOn v m t => neg (.raw v t) :: t.map (fun k => pos (.ray k m))
  | .rawOff v m t k => [neg (.raw v t),neg (.ray k m)]
  | .root k m => [(.ray k m, rootBit x y k m)]
  | .cross u v a b => [neg (.raw u a),neg (.raw v b)]
  | .disj j m => [neg (.ray (2*j) m),neg (.ray (2*j+1) m)]
  | .originSome j => (origins x y j).map (fun o => pos (.origin j o))
  | .act j o m mode =>
    let s := neg (.origin j o)
    if mode < 2 then
      [s,neg (.ray (2*j+mode) m)] ++ (if o < 12 then [pos (.ray o m)] else [])
    else [s,pos (.ray (2*j) m),pos (.ray (2*j+1) m)] ++ (if o < 12 then [neg (.ray o m)] else [])
theorem Rule.sound (p : Projection x y) (r : Rule) (hr : r.ok x y = true) : Sat p (r.clause x y) := by
  cases r with
  | rawSome v =>
    exact ⟨_,List.mem_map.mpr ⟨p.raw v,p.selected v (of_decide_eq_true hr),rfl⟩,by simp [pos,Atom.val]⟩
  | originSome j =>
    simp only [Rule.ok,Bool.and_eq_true,decide_eq_true_eq] at hr
    exact ⟨_,List.mem_map.mpr ⟨p.origin j,p.named j hr.1 hr.2,rfl⟩,by simp [pos,Atom.val]⟩
  | rawOn v m t =>
    simp only [Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at hr
    by_cases h : p.raw v = t
    · have hrow := p.rawRows v hr.1.1 m hr.1.2
      rw [h,hr.2] at hrow
      obtain ⟨k,hk,hval⟩ := List.any_eq_true.mp hrow
      exact ⟨_,List.mem_cons_of_mem _ (List.mem_map.mpr ⟨k,hk,rfl⟩),hval⟩
    · exact ⟨_,List.mem_cons_self,by simp [neg,Atom.val,h]⟩
  | rawOff v m t k =>
    simp only [Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem,Bool.not_eq_true'] at hr
    by_cases h : p.raw v = t
    · have hrow := p.rawRows v hr.1.1.1 m hr.1.1.2
      rw [h,hr.1.2] at hrow
      have hf : p.ray k m = false := by
        cases hb : p.ray k m
        · rfl
        · have : (t.any (fun a => p.ray a m)) = true := List.any_eq_true.mpr ⟨k,hr.2,hb⟩
          simp_all
      exact ⟨neg (.ray k m),by simp [Rule.clause],hf⟩
    · exact ⟨_,List.mem_cons_self,by simp [neg,Atom.val,h]⟩
  | root k m =>
    simp only [Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at hr
    refine ⟨_,List.mem_cons_self,?_⟩
    have h := hr.1
    have hm := hr.2
    match k with
    | 0 => exact p.side0 m hm
    | 1 => exact p.side1 m hm
    | 2 => exact p.side2 m hm
    | 3 => exact p.side3 m hm
    | n+4 => omega
  | cross u v a b =>
    simp only [Rule.ok,Bool.and_eq_true,decide_eq_true_eq,Bool.not_eq_true'] at hr
    have h := p.opposed u v hr.1.1.1 hr.1.1.2 hr.1.2
    simp [Sat, Rule.clause,neg,Atom.val]
    by_cases h1 : p.raw u = a <;> by_cases h2 : p.raw v = b <;> simp_all
  | disj j m =>
    simp only [Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at hr
    have h := p.disjoint j hr.1.1 hr.1.2 m hr.2
    simp [Sat, Rule.clause,neg,Atom.val]
    cases ha : p.ray (2*j) m <;> cases hb : p.ray (2*j+1) m <;> simp_all
  | act j o m mode =>
    simp only [Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at hr
    have h := p.activation j hr.1.1.1.1 hr.1.1.1.2 m hr.1.1.2
    have lim := hr.1.2
    by_cases ho : p.origin j = o
    · rw [ho] at h
      have hm : mode = 0 ∨ mode = 1 ∨ mode = 2 := by omega
      rcases hm with rfl|rfl|rfl <;> by_cases isRay : o < 12 <;>
        cases ha : p.ray (2*j) m <;> cases hb : p.ray (2*j+1) m <;>
        simp_all [Sat,Rule.clause,pos,neg,Atom.val]
    · refine ⟨neg (.origin j o),?_,by simp [neg,Atom.val,ho]⟩
      simp only [Rule.clause]
      split <;> simp
end Research.Graph9822.TwoDirect
