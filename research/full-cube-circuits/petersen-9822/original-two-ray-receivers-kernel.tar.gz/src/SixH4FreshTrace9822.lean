import And9822CommonScan
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
noncomputable section
local instance : DecidableEq Mask := Classical.decEq _
def hits (N : Finset Mask) (l : List Mask) : Finset Mask := N ∩ l.toFinset
theorem hit_cons (N : Finset Mask) (a : Mask) (l : List Mask) :
    hits N (a::l) = if a ∈ N then insert a (hits N l) else hits N l := by
  classical
  by_cases ha : a ∈ N <;> ext x <;> by_cases e : x = a <;> simp_all [hits]
inductive Paid (N : Finset Mask) : List Mask → List Mask → List (Axis × Mask) → Nat → Prop where
  | start : Paid N [] [Set.univ] [] 0
  | join {b l p n x y} (h : Paid N b l p n) (hx : x ∈ l) (hy : y ∈ l)
      (used : x ∪ y ∈ N) (fresh : x ∪ y ∉ l) :
      Paid N b ((x ∪ y)::l) p (n+1)
  | split {b l p n u i} (h : Paid N b l p n) (hu : u ∈ l) :
      Paid N ((u ∩ side i true)::(u ∩ side i false)::b)
          ((u ∩ side i true)::(u ∩ side i false)::l) ((i,u)::p) n
theorem exact_count {b l p n} (h : Scan b l p n) (N : Finset Mask)
    (top : Set.univ ∉ N)
    (none : ∀ t ∈ p, ∀ s, t.2 ∩ side t.1 s ∉ N) :
    (hits N l).card ≤ n ∧ ((hits N l).card = n → Paid N b l p n) := by
  classical
  induction h with
  | start =>
    simp [hit_cons,top,hits,Paid.start]
  | @join b l p n x y h hx hy ih =>
    obtain ⟨bound,build⟩ := ih none
    by_cases used : x ∪ y ∈ N
    · by_cases prev : x ∪ y ∈ l
      · have old : x ∪ y ∈ hits N l := by simp [hits,used,prev]
        rw [hit_cons,if_pos used,Finset.insert_eq_of_mem old]
        exact ⟨by omega,by omega⟩
      · have unseen : x ∪ y ∉ hits N l := by simp [hits,prev]
        rw [hit_cons,if_pos used,Finset.card_insert_of_notMem unseen]
        exact ⟨by omega,fun eq => .join (build (by omega)) hx hy used prev⟩
    · rw [hit_cons,if_neg used]
      exact ⟨by omega,by omega⟩
  | @split b l p n u i h hu ih =>
    have a := none (i,u) (by simp) true
    have c := none (i,u) (by simp) false
    obtain ⟨bound,build⟩ := ih (fun t ht s => none t (List.mem_cons_of_mem _ ht) s)
    rw [hit_cons,if_neg a,hit_cons,if_neg c]
    exact ⟨bound,fun eq => .split (build eq) hu⟩
end
end Research.Graph9822Profiles.Fresh
