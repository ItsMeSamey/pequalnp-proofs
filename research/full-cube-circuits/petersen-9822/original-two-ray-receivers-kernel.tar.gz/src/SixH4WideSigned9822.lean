import SixH4WideSignedData9822
namespace Research.Graph9822.TwoDirect.Signed
theorem invol (b : Shift) (k : Nat) : lbl b (lbl b k) = k := by
  by_cases h : k<12
  · exact (bounds b ⟨k,h⟩).2.1
  · simp [lbl,h]
theorem ordered_mem (a : Nat) (t : Arm) : a ∈ ordered t ↔ a ∈ t := by
  cases t with
  | nil => rfl
  | cons x xs =>
    cases xs with
    | nil => rfl
    | cons y ys =>
      cases ys with
      | nil => by_cases h : x ≤ y <;> simp [ordered,h,or_comm]
      | cons z zs => rfl
theorem any_move (b : Shift) (t : Arm) (f : Nat → Bool) :
    (move b t).any (fun k => f (lbl b k)) = t.any f := by
  apply Bool.eq_iff_iff.mpr
  constructor
  · intro hl
    obtain ⟨k,hk,hf⟩ := List.any_eq_true.mp hl
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp ((ordered_mem _ _).mp hk)
    exact List.any_eq_true.mpr ⟨a,ha,by simpa [invol] using hf⟩
  · intro hr
    obtain ⟨a,ha,hf⟩ := List.any_eq_true.mp hr
    exact List.any_eq_true.mpr ⟨lbl b a,(ordered_mem _ _).mpr (List.mem_map.mpr ⟨a,ha,rfl⟩),
      by simpa [invol] using hf⟩
theorem opposed_move (b : Shift) (u : Fin 10) (a c : Arm) (hu : a ∈ options 0 1 u)
    (op : opposes a c = true) : opposes (move b a) (move b c) = true := by
  obtain ⟨k,hk,hc⟩ := List.any_eq_true.mp op
  have bound := armBounds u a hu k hk
  apply List.any_eq_true.mpr
  refine ⟨lbl b k,(ordered_mem _ _).mpr (List.mem_map.mpr ⟨k,hk,rfl⟩),?_⟩
  apply List.contains_iff_mem.mpr
  apply (ordered_mem _ _).mpr
  exact List.mem_map.mpr ⟨_,List.contains_iff_mem.mp hc,(bounds b ⟨k,bound⟩).2.2⟩
theorem origin_value (b : Shift) (o m : Nat) (r : Nat → Nat → Bool) :
    (if originCode b o=22 then true else if originCode b o<12 then
      r (lbl b (originCode b o)) m else rawBit (originCode b o-12) m) =
    (if o=22 then true else if o<12 then r o m else rawBit (o-12) m) := by
  by_cases low : o<12
  · have h : lbl b o < 12 := (bounds b ⟨o,low⟩).1
    have ne : lbl b o ≠ 22 := by omega
    have on : o ≠ 22 := by omega
    simp [originCode,low,h,ne,on,invol]
  · simp [originCode,low]
def reindex (b : Shift) (p : WideProjection 0 1) : WideProjection 0 1 where
  ray k m := p.ray (lbl b k) m
  raw v := move b (p.raw v)
  origin j := originCode b (p.origin (axis b j))
  selected v hv := legal b ⟨v,hv⟩ _ (p.selected v hv)
  rawRows v hv m hm := (any_move b (p.raw v) (fun k => p.ray k m)).trans (p.rawRows v hv m hm)
  opposed u v uv hv adj := opposed_move b ⟨u,by omega⟩ _ _ (p.selected u (by omega)) (p.opposed u v uv hv adj)
  side0 m hm := by rw [(rootLabels b).1]; exact p.side0 m hm
  side1 m hm := by rw [(rootLabels b).2.1]; exact p.side1 m hm
  side2 m hm := by rw [(rootLabels b).2.2.1]; exact p.side2 m hm
  side3 m hm := by rw [(rootLabels b).2.2.2]; exact p.side3 m hm
  disjoint j ge hi m hm := by
    obtain ⟨lo,up,hs⟩ := axisBounds b ⟨j,hi⟩ ge
    have h := p.disjoint _ lo up m hm
    rcases hs with ⟨hs,ht⟩ | ⟨hs,ht⟩
    · simpa only [hs,ht] using h
    · simpa only [hs,ht,Bool.and_comm] using h
  named j ge hi := by
    obtain ⟨lo,up,_⟩ := axisBounds b ⟨j,hi⟩ ge
    exact named b ⟨j,hi⟩ ge _ (p.named _ lo up)
  activation j ge hi m hm := by
    obtain ⟨lo,up,hs⟩ := axisBounds b ⟨j,hi⟩ ge
    have h := p.activation _ lo up m hm
    rw [origin_value]
    rcases hs with ⟨hs,ht⟩ | ⟨hs,ht⟩
    · simpa only [hs,ht] using h
    · simpa only [hs,ht,Bool.or_comm] using h
theorem normalize (p : WideProjection 0 1) : ∃ q : WideProjection 0 1, q.raw 4 = [1,4] := by
  obtain ⟨b,h⟩ := fixedChoice _ (p.selected 4 (by decide))
  exact ⟨reindex b p,by change move b (p.raw 4) = [1,4]; rw [h]; exact normalArm b⟩
end Research.Graph9822.TwoDirect.Signed
