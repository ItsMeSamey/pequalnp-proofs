import SixH4ProjectionCode9822
import SixH4ProjectionForced9822
namespace Research.SixH4.DirectLiteral
open Research.SixH4.PairPartition Research.Graph9822.TwoDirect

def sortTwo : List Nat → List Nat
  | [x,y] => if x ≤ y then [x,y] else [y,x]
  | xs => xs

theorem mem_sortTwo (k : Nat) (xs : List Nat) : k ∈ sortTwo xs ↔ k ∈ xs := by
  cases xs with
  | nil => rfl
  | cons x xs =>
    cases xs with
    | nil => rfl
    | cons y xs =>
      cases xs with
      | nil => by_cases h : x ≤ y <;> simp [sortTwo,h,or_comm]
      | cons z zs => rfl

def normalized (a b : Lit) (L : V → List Lit) (v : Nat) : Arm :=
  if h : v < 10 then sortTwo ((L ⟨v,h⟩).map (code a b)) else []

def shape : Bool → Bool → List Arm
  | true,true => [[1,3]]
  | true,false => hidden.map (fun k => [1,k])
  | false,true => hidden.map (fun k => [3,k])
  | false,false => hidden.flatMap fun a =>
      (hidden.filter (fun b => decide (a < b) && !(a/2 == b/2))).map (fun b => [a,b])

theorem select_shape : ∀ (p q : Bool) (c d : Fin 12),
    c.val/2 ≠ d.val/2 → 0 ∉ [c.val,d.val] → 2 ∉ [c.val,d.val] →
    (1 ∈ [c.val,d.val] ↔ p=true) → (3 ∈ [c.val,d.val] ↔ q=true) →
    sortTwo [c.val,d.val] ∈ shape p q := by
  intro p q
  cases p <;> cases q <;> decide +kernel
theorem adj_code : ∀ i j : V, adj i j ↔ edge i.val j.val=true := by decide +kernel

theorem selected (a b : Lit) (L : V → List Lit) (x y : V)
    (ne : x ≠ y) (axes : a.1 ≠ b.1) (lx : L x=[a]) (ly : L y=[b])
    (pair : ∀ v, v ≠ x → v ≠ y → ∃ c d : Lit, c.1 ≠ d.1 ∧ L v=[c,d])
    (rule : ∀ v, v ≠ x → v ≠ y →
      a ∉ L v ∧ b ∉ L v ∧ (mate a ∈ L v ↔ adj v x) ∧ (mate b ∈ L v ↔ adj v y)) :
    ∀ v, v<10 → normalized a b L v ∈ options x.val y.val v := by
  intro n hn
  let v : V := ⟨n,hn⟩
  obtain ⟨ca,cb⟩ := code_root a b axes
  by_cases vx : v=x
  · have eq : n=x.val := congrArg Fin.val vx
    subst n
    simp [normalized,options,lx,sortTwo,ca,x.isLt]
  by_cases vy : v=y
  · have eq : n=y.val := congrArg Fin.val vy
    subst n
    have diff : y.val ≠ x.val := fun e => ne (Fin.ext e.symm)
    simp [normalized,options,ly,sortTwo,cb,y.isLt,diff]
  have nx : n ≠ x.val := fun e => vx (Fin.ext e)
  have ny : n ≠ y.val := fun e => vy (Fin.ext e)
  obtain ⟨c,d,cd,l⟩ := pair v vx vy
  obtain ⟨na,nb,oa,ob⟩ := rule v vx vy
  have rm (u : Lit) : code a b u ∈ [code a b c,code a b d] ↔ u ∈ L v := by
    rw [l]
    simp [(code_injective axes).eq_iff]
  have non0 := (rm a).not.mpr na
  have non2 := (rm b).not.mpr nb
  rw [ca] at non0
  rw [cb] at non2
  have on1 := (rm (mate a)).trans (oa.trans (adj_code v x))
  have on3 := (rm (mate b)).trans (ob.trans (adj_code v y))
  rw [code_mate,ca] at on1
  rw [code_mate,cb] at on3
  have diff : code a b c / 2 ≠ code a b d / 2 := by
    rw [code_axis,code_axis]; exact axis_different a b axes _ _ cd
  have ok := select_shape (edge n x.val) (edge n y.val) ⟨_,code_bound a b axes c⟩
    ⟨_,code_bound a b axes d⟩ diff non0 non2 on1 on3
  simp only [normalized,dif_pos hn]
  change sortTwo ((L v).map (code a b)) ∈ _
  rw [l]
  cases ex : edge n x.val <;> cases ey : edge n y.val <;>
    simpa [options,nx,ny,shape,ex,ey] using ok
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.selected
