import SixWideOriginalProjection9822
import SixH4WideProjectionAll9822
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822 Research.Graph9822.ArbitraryScan
open Research.SixH4.DirectLiteral Research.SixH4.PairPartition Research.Graph9822.TwoDirect
open PEqualNP.Outside.L_meta_9822.Sectors
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
theorem original_d2_excluded (gs : List DGate) (out : Nat) (size : gs.length≤17)
    (ok : WellWired gs 10) (ob : out<10+gs.length) (six : gs.countP Gate.isAnd=6)
    (computes : ∀ x : Fin 10 → Bool,(asCircuit gs out).eval (List.ofFn x)=edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le six.le)
    let p := ((gateEvents axis gs 10 ++ rawEvents 10).foldl paddedStep (initial out)).switches
    let R := tenR axis gs out
    let P := field p
    ((Finset.univ : Finset (Fin 10)).filter (fun v=>RayValue P (R v))).card=2 →
      False := by
  intro axis p R P d
  obtain ⟨x,y,_,_,_,keep,model⟩ := original_wide_projection gs out size ok ob six computes d
  exact wideClosedKept keep model
end
end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.original_d2_excluded
