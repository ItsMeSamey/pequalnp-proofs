import And9822ScanGrammar
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
def setBit (i : Axis) (s : Bool) (q : Word) : Word := fun j => if j = i then s else q j
def Stable (m : Mask) (i : Axis) : Prop := ∀ q s, q ∈ m → setBit i s q ∈ m
theorem unissued {b l p n} (scan : Scan b l p n) {i : Axis}
    (unused : i ∉ p.map Prod.fst) : ∀ m ∈ l, Stable m i := by
  induction scan with
  | start => simp [Stable]
  | @join b l p n x y h hx hy ih =>
    intro m hm
    rcases List.mem_cons.mp hm with rfl | rest
    · intro q s hq
      exact hq.elim (fun z => Or.inl (ih unused x hx q s z)) (fun z => Or.inr (ih unused y hy q s z))
    · exact ih unused m rest
  | @split b l p n u j h hu ih =>
    have old : i ∉ p.map Prod.fst := fun e => unused (by simp [e])
    have diff : j ≠ i := by intro e; subst i; exact unused (by simp)
    have arm (t : Bool) : Stable (u ∩ side j t) i := by
      intro q s z
      refine ⟨ih old u hu q s z.1,?_⟩
      simpa [side,setBit,diff] using z.2
    intro m hm
    rcases List.mem_cons.mp hm with rfl | rest
    · exact arm true
    rcases List.mem_cons.mp rest with rfl | rest
    · exact arm false
    exact ih old m rest
theorem switch_stable {b l p n} (scan : Scan b l p n) (unique : (p.map Prod.fst).Nodup) :
    ∀ t ∈ p, Stable t.2 t.1 := by
  induction scan with
  | start => simp
  | join h hx hy ih => exact ih unique
  | @split b l p n u i h hu ih =>
    obtain ⟨fresh,nodup⟩ := List.nodup_cons.mp unique
    intro t ht
    rcases List.mem_cons.mp ht with rfl | old
    · exact unissued h fresh u hu
    · exact ih nodup t old
theorem straddles {m : Mask} {i : Axis} (stable : Stable m i) (s : Bool) (live : ∃ q, q ∈ m) :
    ∃ q ∈ m, q ∉ side i s := by
  obtain ⟨q,h⟩ := live
  exact ⟨setBit i (!s) q,stable q (!s) h,by cases s <;> simp [setBit,side]⟩
end Research.Graph9822Profiles.Fresh
