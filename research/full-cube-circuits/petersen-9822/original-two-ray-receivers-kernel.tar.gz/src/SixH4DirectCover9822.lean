import SixH4DirectLiteral9822
namespace Research.SixH4.DirectLiteral
theorem half_forces {i j k : Fin 6} {s t u : Bool} (distinct : j ≠ k)
    (cover : side i s ⊆ side j t ∪ side k u) :
    (j = i ∧ t = s) ∨ (k = i ∧ u = s) := by
  by_contra bad
  let q : Word := fun a => if a = i then s else if a = j then !t else !u
  have qi : q ∈ side i s := by simp [q,side]
  rcases cover qi with left | right
  · by_cases eq : j = i
    · have same : s = t := by simpa [q,side,eq] using left
      exact bad (Or.inl ⟨eq,same.symm⟩)
    · cases t <;> simp [q,side,eq] at left
  · by_cases eq : k = i
    · have same : s = u := by simpa [q,side,eq] using right
      exact bad (Or.inr ⟨eq,same.symm⟩)
    · cases u <;> simp [q,side,eq,Ne.symm distinct] at right

theorem activation_not_raw (P : Fin 6 → Set Word) (R : Fin 10 → Set Word)
    (x : Fin 10) (i : Fin 6) (s : Bool) (direct : R x = ray P i s)
    (anti : ∀ a b, a ≠ b → ¬ R a ⊆ R b)
    (split : ∃ q ∈ P i, q ∉ side i s) : ∀ v, P i ≠ R v := by
  intro v same
  have sub : R x ⊆ R v := by rw [direct,← same]; exact fun _ h => h.1
  by_cases eq : x = v
  · subst v
    obtain ⟨q,h,nq⟩ := split
    have hx : q ∈ R x := same ▸ h
    rw [direct] at hx
    exact nq hx.2
  · exact anti x v eq sub
end Research.SixH4.DirectLiteral
