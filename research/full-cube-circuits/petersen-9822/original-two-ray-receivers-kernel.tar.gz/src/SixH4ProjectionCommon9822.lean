import SixH4ProjectionOpposed9822
namespace Research.SixH4.DirectLiteral
def opposite (a : Lit) : Lit := (a.1,!a.2)
theorem opposed_single {a : Lit} {L : List Lit} (h : opposing [a] L) : opposite a ∈ L := by
  obtain ⟨i,s,ha,hs⟩ := h
  obtain rfl := List.mem_singleton.mp ha
  exact hs

theorem two_exhaust {a b c d e : Lit} (ha : a ∈ [c,d]) (hb : b ∈ [c,d])
    (ne : a ≠ b) (he : e ∈ [c,d]) : e = a ∨ e = b := by
  simp only [List.mem_cons,List.mem_singleton] at ha hb he
  grind

theorem common_neighbor {A : Fin 6 → Set Word} {a b c d : Lit}
    (roots : a.1 ≠ b.1) (other : c.1 ≠ d.1)
    (ac : ∀ q, receives A [a] q ∨ receives A [c,d] q)
    (bc : ∀ q, receives A [b] q ∨ receives A [c,d] q) :
    {q | receives A [c,d] q} ⊆ side a.1 (!a.2) ∪ side b.1 (!b.2) := by
  have ma := opposed_single (edge_opposing (single_consistent a) (pair_consistent c d other) ac)
  have mb := opposed_single (edge_opposing (single_consistent b) (pair_consistent c d other) bc)
  have ne : opposite a ≠ opposite b := fun eq => roots (show (opposite a).1 = (opposite b).1 from congrArg Prod.fst eq)
  rintro q ⟨e,he,hit⟩
  rcases two_exhaust ma mb ne he with eq|eq
  · subst e
    exact Or.inl hit.2
  · subst e
    exact Or.inr hit.2
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.common_neighbor
