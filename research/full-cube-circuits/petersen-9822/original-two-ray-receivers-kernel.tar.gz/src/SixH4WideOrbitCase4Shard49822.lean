import SixH4WideOrbitCase4Data9822
namespace Research.Graph9822.TwoDirect.Orbit01
open PEqualNP.Library.LRAT
set_option maxRecDepth 50000
set_option maxHeartbeats 0
def block4x32 := rules4Part32.zip numericPart32
theorem good4x32 : block4x32.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x32 : block4x32.map Prod.snd = numericPart32 := List.map_snd_zip (by decide +kernel)
def block4x33 := rules4Part33.zip numericPart33
theorem good4x33 : block4x33.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x33 : block4x33.map Prod.snd = numericPart33 := List.map_snd_zip (by decide +kernel)
def block4x34 := rules4Part34.zip numericPart34
theorem good4x34 : block4x34.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x34 : block4x34.map Prod.snd = numericPart34 := List.map_snd_zip (by decide +kernel)
def block4x35 := rules4Part35.zip numericPart35
theorem good4x35 : block4x35.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x35 : block4x35.map Prod.snd = numericPart35 := List.map_snd_zip (by decide +kernel)
def block4x36 := rules4Part36.zip numericPart36
theorem good4x36 : block4x36.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x36 : block4x36.map Prod.snd = numericPart36 := List.map_snd_zip (by decide +kernel)
def block4x37 := rules4Part37.zip numericPart37
theorem good4x37 : block4x37.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x37 : block4x37.map Prod.snd = numericPart37 := List.map_snd_zip (by decide +kernel)
def block4x38 := rules4Part38.zip numericPart38
theorem good4x38 : block4x38.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x38 : block4x38.map Prod.snd = numericPart38 := List.map_snd_zip (by decide +kernel)
def block4x39 := rules4Part39.zip numericPart39
theorem good4x39 : block4x39.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x39 : block4x39.map Prod.snd = numericPart39 := List.map_snd_zip (by decide +kernel)
end Research.Graph9822.TwoDirect.Orbit01
