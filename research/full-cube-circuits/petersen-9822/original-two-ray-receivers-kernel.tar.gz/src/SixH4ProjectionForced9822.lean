import SixH4ProjectionRoster9822
namespace Research.SixH4.DirectLiteral
open Research.SixH4.PairPartition Research.Graph9822Resolution

theorem shares_room : ∀ x v : V, ¬ adj v x → ∃ u : Fin 16,
    v.val ∈ independentSets u ∧ x.val ∈ independentSets u := by decide +kernel

theorem root_membership (A : Fin 6 → Set Word) (L : V → List Lit)
    {x v : V} {a : Lit} (lx : L x = [a]) (full : A a.1 = Set.univ)
    (coherent : consistent (L v))
    (cover : adj v x → ∀ q, receives A (L x) q ∨ receives A (L v) q)
    (anti : ¬ ({q | receives A (L x) q} : Set Word) ⊆ {q | receives A (L v) q})
    (rooms : ∀ u : Fin 16, ∃ q : Word, ∀ z : V,
      receives A (L z) q ↔ z.val ∉ independentSets u) :
    a ∉ L v ∧ (opposite a ∈ L v ↔ adj v x) := by
  constructor
  · intro mem
    apply anti
    rintro q ⟨b,h,hit⟩
    rw [lx,List.mem_singleton] at h
    exact ⟨a,mem,h ▸ hit⟩
  · constructor
    · intro mem
      by_contra no
      obtain ⟨u,hv,hx⟩ := shares_room x v no
      obtain ⟨q,hq⟩ := rooms u
      have active : q ∈ A a.1 := by rw [full]; trivial
      by_cases yes : q a.1 = a.2
      · exact (hq x).1 ⟨a,by simp [lx],active,yes⟩ hx
      · have yes' : q a.1 = !a.2 := by
          cases eq : a.2 <;> cases ev : q a.1 <;> simp_all
        exact (hq v).1 ⟨opposite a,mem,active,yes'⟩ hv
    · intro e
      have c := cover e
      rw [lx] at c
      exact opposed_single (edge_opposing (single_consistent a) coherent c)
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.root_membership
