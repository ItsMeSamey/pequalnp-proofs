import SixH4RupChecker9822
namespace Research.Graph9822.TwoDirect
abbrev Arm := List Nat
def edges : List Nat := [6,24,17,33,66,132,264,528,160,640,576,320,288]
def rooms : List Nat := [50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773]
def edge (u v : Nat) : Bool := edges.contains (2^u ||| 2^v)
def rawBit (v m : Nat) : Bool := !(m.testBit v)
def hidden := (List.range 8).map (· + 4)
def options (x y v : Nat) : List Arm :=
  if v = x then [[0]] else if v = y then [[2]] else
  match edge v x, edge v y with
  | true, true => [[1,3]]
  | true, false => hidden.map (fun k => [1,k])
  | false, true => hidden.map (fun k => [3,k])
  | false, false => hidden.flatMap fun a =>
      (hidden.filter (fun b => decide (a < b) && !(a/2 == b/2))).map (fun b => [a,b])
def opposes (a b : Arm) : Bool := a.any fun k => b.contains (k ^^^ 1)
def origins (x y j : Nat) : List Nat :=
  ((List.range 12).filter (fun k => !(k/2 == j))) ++
    (((List.range 10).filter (fun v => !(v == x) && !(v == y))).map (· + 12))
structure Projection (x y : Nat) where
  ray : Nat → Nat → Bool
  raw : Nat → Arm
  origin : Nat → Nat
  selected : ∀ v, v < 10 → raw v ∈ options x y v
  rawRows : ∀ v, v < 10 → ∀ m ∈ rooms, ((raw v).any (fun k => ray k m)) = rawBit v m
  opposed : ∀ u v, u < v → v < 10 → edge u v = true → opposes (raw u) (raw v) = true
  side0 : ∀ m ∈ rooms, ray 0 m = rawBit x m
  side1 : ∀ m ∈ rooms, ray 1 m = !(rawBit x m)
  side2 : ∀ m ∈ rooms, ray 2 m = rawBit y m
  side3 : ∀ m ∈ rooms, ray 3 m = !(rawBit y m)
  disjoint : ∀ j, 2 ≤ j → j < 6 → ∀ m ∈ rooms,
    (ray (2*j) m && ray (2*j+1) m) = false
  named : ∀ j, 2 ≤ j → j < 4 → origin j ∈ origins x y j
  activation : ∀ j, 2 ≤ j → j < 4 → ∀ m ∈ rooms,
    (ray (2*j) m || ray (2*j+1) m) =
      if origin j < 12 then ray (origin j) m else rawBit (origin j-12) m
end Research.Graph9822.TwoDirect
