import SixH4D2NormalizedMasks9822
namespace Research.SixH4.DirectLiteral
open Research.Graph9822.TwoDirect
noncomputable section

theorem wide_origins_from_masks (P : Fin 6 → Set Word) (R : Fin 10 → Set Word)
    (a b : Lit) (ne : a.1≠b.1) (x y : Fin 10)
    (src : ∀ i,2≤axisCode a b i → axisCode a b i<6 →
      P i=Set.univ ∨ (∃ d : Lit,d.1≠i ∧ P i=ray P d.1 d.2) ∨ (∃ v,v≠x ∧ v≠y ∧ P i=R v)) :
    ∃ source : Nat → Nat,∀ j,2≤j → j<6 →
      (source j=22 ∨ source j∈origins x.val y.val j) ∧
      (source j≠22 → 12≤source j → source j-12<10) ∧
      ∀ w,(w∈codeMask P a b (2*j) ∨ w∈codeMask P a b (2*j+1)) ↔
        if source j=22 then True else if source j<12 then w∈codeMask P a b (source j)
        else ∃ v : Fin 10,v.val=source j-12 ∧ w∈R v := by
  classical
  have pick (j : Nat) (lo : 2≤j) (hi : j<6) :
      ∃ k,(k=22 ∨ k∈origins x.val y.val j) ∧ (k≠22 → 12≤k → k-12<10) ∧
        ∀ w,(w∈codeMask P a b (2*j) ∨ w∈codeMask P a b (2*j+1)) ↔
          if k=22 then True else if k<12 then w∈codeMask P a b k else ∃ v : Fin 10,v.val=k-12 ∧ w∈R v := by
    obtain ⟨c,eq,sem,_⟩ := slot_semantics P a b ne ⟨j,by omega⟩
    change axisCode a b c.1=j at eq
    rcases src c.1 (eq ▸ lo) (eq ▸ hi) with full|⟨d,dis,rayEq⟩|⟨v,vx,vy,rawEq⟩
    · refine ⟨22,Or.inl rfl,by simp,fun w=>?_⟩
      simp [sem w,full]
    · let k := code a b d
      have low : k<12 := code_bound a b ne d
      have diff : k/2≠j := by
        rw [show k/2=axisCode a b d.1 from code_axis a b d,←eq]
        exact axis_different a b ne _ _ dis
      refine ⟨k,Or.inr (List.mem_append_left _ (by simp [low,diff])),by omega,fun w=>?_⟩
      rw [if_neg (by omega : k≠22),if_pos low,mask_at P a b ne,←rayEq]
      exact sem w
    · have vx' : v.val≠x.val := fun h=>vx (Fin.ext h)
      have vy' : v.val≠y.val := fun h=>vy (Fin.ext h)
      refine ⟨v.val+12,Or.inr (List.mem_append_right _ (List.mem_map.mpr ⟨v.val,by simp [v.isLt,vx',vy'],rfl⟩)),
        by simp [v.isLt],fun w=>?_⟩
      simp only [show v.val+12≠22 by have := v.isLt; omega,if_false,show ¬v.val+12<12 by omega,if_false,Nat.add_sub_cancel]
      rw [sem w,rawEq]
      constructor
      · exact fun h=>⟨v,rfl,h⟩
      · rintro ⟨t,ht,hm⟩
        exact (Fin.ext ht : t=v) ▸ hm
  let f (j : Nat) := if h : 2≤j ∧ j<6 then (pick j h.1 h.2).choose else 0
  exact ⟨f,fun j lo hi=>by simpa [f,lo,hi] using (pick j lo hi).choose_spec⟩

end
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.wide_origins_from_masks
