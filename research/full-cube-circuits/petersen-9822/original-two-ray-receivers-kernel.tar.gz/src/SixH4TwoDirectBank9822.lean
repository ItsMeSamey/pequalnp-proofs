import And9822CommonScan
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822.CommonBank
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
theorem two_direct_bank {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (respects : ∀ s ∈ p, s.2 = P s.1) (R : Fin 10 → Mask6) (returned : ∀ v, R v ∈ l)
    (proper : ∀ v, ∃ q, q ∉ R v) (inc : ∀ u v, u ≠ v → ¬ R u ⊆ R v)
    (budget : n ≤ 8) (d : ((Finset.univ : Finset (Fin 10)).filter
      (fun v => RayValue P (R v))).card = 2) :
    (∀ m ∈ p.map Prod.snd, Primitive P m ∨ ∃ v, R v = m) ∧
    (∀ v, RayValue P (R v) ∨ PairOf (RayValue P) (R v)) := by
  classical
  obtain ⟨raw,grants,hs,rawDef,gDef,_,price,pairs⟩ :=
    common_from_scan scan P respects R returned proper inc budget
  have inj : Function.Injective R := by
    intro u v eq
    by_contra ne
    exact inc u v ne (by rw [eq])
  have spare := spare_count inj rawDef price
  rw [d] at spare
  have hnil : hs = [] := List.length_eq_zero_iff.mp (by omega)
  have gnil : grants = ∅ := Finset.card_eq_zero.mp (by omega)
  constructor
  · intro m hm
    by_cases prim : Primitive P m
    · exact Or.inl prim
    · right
      by_cases hr : m ∈ raw
      · obtain ⟨v,eq,_⟩ := (rawDef m).mp hr
        exact ⟨v,eq⟩
      · have bad := (gDef m).mpr ⟨hm,prim,hr⟩
        simp [gnil] at bad
  · intro v
    simpa [Source,hnil,gnil,PairOf] using pairs v
end
end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.two_direct_bank
