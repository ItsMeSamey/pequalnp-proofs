import SixH4ProjectedModel9822
import SixH4D2ReceiverFacts9822
noncomputable section
namespace Research.Graph9822.TwoDirect
open Research.Graph9822Profiles Research.Graph9822Profiles.OuterLive
open PEqualNP.Outside.L_meta_9822.Receivers
open FourSaturation
local instance (p : Prop) : Decidable p := Classical.propDecidable p
theorem projection_sample {R : Fin 10 → Mask} (real : ExactReceivers (fun v q => q ∈ R v)) :
    ∃ choose : Nat → Word,∀ m∈rooms,∀ v : Fin 10,choose m∈R v ↔ rawBit v.val m=true := by
  classical
  have members : ∀ m∈rooms,m∈witnesses := fun _ hm=>hm
  have picked (m : Nat) (h : m∈rooms) := real.realize m (members m h)
  let q (m : Nat) := if hm : m∈rooms then (picked m hm).choose else (fun _=>false : Word)
  refine ⟨q,fun m hm v=>?_⟩
  simpa [q,hm,rawBit] using (picked m hm).choose_spec v

theorem projection_rows {R : Fin 10 → Mask} {A : Nat → Mask}
    {raw : Nat → Arm} {q : Nat → Word}
    (rows : ∀ m∈rooms,∀ v : Fin 10,q m∈R v ↔ rawBit v.val m=true)
    (descs : ∀ v : Fin 10, ∀ w : Word,w∈R v ↔ ∃ k∈raw v.val,w∈A k) :
    ∀ v, v<10 → ∀ m∈rooms, ((raw v).any (fun k => decide (q m∈A k)))=rawBit v m := by
  classical
  intro v h m hm
  apply Bool.eq_iff_iff.mpr
  rw [List.any_eq_true]
  simp only [decide_eq_true_eq]
  exact (descs ⟨v,h⟩ (q m)).symm.trans (rows m hm ⟨v,h⟩)
theorem projection_of_masks {x y : Fin 10} {R : Fin 10 → Mask} (A : Nat → Mask)
    (real : ExactReceivers (fun v w => w∈R v)) (raw : Nat → Arm) (origin : Nat → Nat)
    (selected : ∀ v,v<10 → raw v∈options x.val y.val v)
    (descs : ∀ v : Fin 10,∀ w : Word,w∈R v ↔ ∃ k∈raw v.val,w∈A k)
    (opposed : ∀ u v,u<v → v<10 → edge u v=true → opposes (raw u) (raw v)=true)
    (left0 : A 0=R x) (left1 : ∀ w,w∈A 1 ↔ w∉R x)
    (right0 : A 2=R y) (right1 : ∀ w,w∈A 3 ↔ w∉R y)
    (dis : ∀ j,2≤j → j<6 → ∀ w,w∈A (2*j) → w∉A (2*j+1))
    (named : ∀ j,2≤j → j<4 → origin j ∈ origins x.val y.val j)
    (below : ∀ j,2≤j → j<4 → 12≤origin j → origin j-12<10)
    (active : ∀ j,2≤j → j<4 → ∀ w,
      (w∈A (2*j) ∨ w∈A (2*j+1)) ↔
        if origin j<12 then w∈A (origin j) else ∃ v : Fin 10,v.val=origin j-12 ∧ w∈R v) :
    Nonempty (Projection x.val y.val) := by
  classical
  obtain ⟨q,rows⟩ := projection_sample real
  let ray (k m : Nat) := decide (q m∈A k)
  refine ⟨⟨ray,raw,origin,selected,projection_rows rows descs,opposed,?_,?_,?_,?_,?_,named,?_⟩⟩
  · intro m hm
    exact Bool.eq_iff_iff.mpr (by simpa [ray,left0] using rows m hm x)
  · intro m hm
    apply Bool.eq_iff_iff.mpr
    simp [ray,left1,rows m hm x]
  · intro m hm
    exact Bool.eq_iff_iff.mpr (by simpa [ray,right0] using rows m hm y)
  · intro m hm
    apply Bool.eq_iff_iff.mpr
    simp [ray,right1,rows m hm y]
  · intro j hj hk m _
    have h := dis j hj hk (q m)
    by_cases l : q m∈A (2*j) <;> simp_all [ray]
  · intro j hj hk m hm
    apply Bool.eq_iff_iff.mpr
    simp only [Bool.or_eq_true,ray,decide_eq_true_eq]
    rw [active j hj hk (q m)]
    split
    · simp [ray]
    · rename_i far
      have lim := below j hj hk (by omega)
      let v : Fin 10 := ⟨origin j-12,lim⟩
      have eq : (∃ t : Fin 10,t.val=origin j-12 ∧ q m∈R t) ↔ q m∈R v := by
        constructor
        · rintro ⟨t,ht,hq⟩
          simpa [show t=v from Fin.ext ht] using hq
        · exact fun h=>⟨v,rfl,h⟩
      simpa [v] using eq.trans (rows m hm v)

end Research.Graph9822.TwoDirect
#print axioms Research.Graph9822.TwoDirect.projection_of_masks
