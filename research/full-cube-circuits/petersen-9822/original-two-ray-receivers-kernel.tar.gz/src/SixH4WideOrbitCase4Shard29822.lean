import SixH4WideOrbitCase4Data9822
namespace Research.Graph9822.TwoDirect.Orbit01
open PEqualNP.Library.LRAT
set_option maxRecDepth 50000
set_option maxHeartbeats 0
def block4x16 := rules4Part16.zip numericPart16
theorem good4x16 : block4x16.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x16 : block4x16.map Prod.snd = numericPart16 := List.map_snd_zip (by decide +kernel)
def block4x17 := rules4Part17.zip numericPart17
theorem good4x17 : block4x17.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x17 : block4x17.map Prod.snd = numericPart17 := List.map_snd_zip (by decide +kernel)
def block4x18 := rules4Part18.zip numericPart18
theorem good4x18 : block4x18.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x18 : block4x18.map Prod.snd = numericPart18 := List.map_snd_zip (by decide +kernel)
def block4x19 := rules4Part19.zip numericPart19
theorem good4x19 : block4x19.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x19 : block4x19.map Prod.snd = numericPart19 := List.map_snd_zip (by decide +kernel)
def block4x20 := rules4Part20.zip numericPart20
theorem good4x20 : block4x20.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x20 : block4x20.map Prod.snd = numericPart20 := List.map_snd_zip (by decide +kernel)
def block4x21 := rules4Part21.zip numericPart21
theorem good4x21 : block4x21.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x21 : block4x21.map Prod.snd = numericPart21 := List.map_snd_zip (by decide +kernel)
def block4x22 := rules4Part22.zip numericPart22
theorem good4x22 : block4x22.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x22 : block4x22.map Prod.snd = numericPart22 := List.map_snd_zip (by decide +kernel)
def block4x23 := rules4Part23.zip numericPart23
theorem good4x23 : block4x23.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x23 : block4x23.map Prod.snd = numericPart23 := List.map_snd_zip (by decide +kernel)
end Research.Graph9822.TwoDirect.Orbit01
