import SixH4WideOrbitCase4Shard09822
import SixH4WideOrbitCase4Shard19822
import SixH4WideOrbitCase4Shard29822
import SixH4WideOrbitCase4Shard39822
import SixH4WideOrbitCase4Shard49822
import SixH4WideOrbitCase4Shard59822
namespace Research.Graph9822.TwoDirect.Orbit01
open PEqualNP.Library.LRAT
set_option maxRecDepth 50000
set_option maxHeartbeats 0
private def rows4 := [block4x0,block4x1,block4x2,block4x3,block4x4,block4x5,block4x6,block4x7,block4x8,block4x9,block4x10,block4x11,block4x12,block4x13,block4x14,block4x15,block4x16,block4x17,block4x18,block4x19,block4x20,block4x21,block4x22,block4x23,block4x24,block4x25,block4x26,block4x27,block4x28,block4x29,block4x30,block4x31,block4x32,block4x33,block4x34,block4x35,block4x36,block4x37,block4x38,block4x39,block4x40,block4x41,block4x42].flatten
theorem branch4 (bad : ¬ FormulaSat core) (p : WideProjection 0 1) (g : p.raw 4 = [1,4]) : False := by
  apply guardFromChecked 0 1 4 [1,4] atoms4.toArray rows4 _ _ p g
  · simp only [rows4,List.all_flatten,List.all_cons,List.all_nil,good4x0,good4x1,good4x2,good4x3,good4x4,good4x5,good4x6,good4x7,good4x8,good4x9,good4x10,good4x11,good4x12,good4x13,good4x14,good4x15,good4x16,good4x17,good4x18,good4x19,good4x20,good4x21,good4x22,good4x23,good4x24,good4x25,good4x26,good4x27,good4x28,good4x29,good4x30,good4x31,good4x32,good4x33,good4x34,good4x35,good4x36,good4x37,good4x38,good4x39,good4x40,good4x41,good4x42,Bool.true_and]
  · rw [show rows4.map Prod.snd = core by
          simpa only [rows4,List.map_flatten,List.map_cons,List.map_nil,eq4x0,eq4x1,eq4x2,eq4x3,eq4x4,eq4x5,eq4x6,eq4x7,eq4x8,eq4x9,eq4x10,eq4x11,eq4x12,eq4x13,eq4x14,eq4x15,eq4x16,eq4x17,eq4x18,eq4x19,eq4x20,eq4x21,eq4x22,eq4x23,eq4x24,eq4x25,eq4x26,eq4x27,eq4x28,eq4x29,eq4x30,eq4x31,eq4x32,eq4x33,eq4x34,eq4x35,eq4x36,eq4x37,eq4x38,eq4x39,eq4x40,eq4x41,eq4x42] using partsEq]
    exact bad
end Research.Graph9822.TwoDirect.Orbit01
