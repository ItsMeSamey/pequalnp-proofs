import SixH4WideOrbitCase4Data9822
namespace Research.Graph9822.TwoDirect.Orbit01
open PEqualNP.Library.LRAT
set_option maxRecDepth 50000
set_option maxHeartbeats 0
def block4x8 := rules4Part8.zip numericPart8
theorem good4x8 : block4x8.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x8 : block4x8.map Prod.snd = numericPart8 := List.map_snd_zip (by decide +kernel)
def block4x9 := rules4Part9.zip numericPart9
theorem good4x9 : block4x9.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x9 : block4x9.map Prod.snd = numericPart9 := List.map_snd_zip (by decide +kernel)
def block4x10 := rules4Part10.zip numericPart10
theorem good4x10 : block4x10.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x10 : block4x10.map Prod.snd = numericPart10 := List.map_snd_zip (by decide +kernel)
def block4x11 := rules4Part11.zip numericPart11
theorem good4x11 : block4x11.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x11 : block4x11.map Prod.snd = numericPart11 := List.map_snd_zip (by decide +kernel)
def block4x12 := rules4Part12.zip numericPart12
theorem good4x12 : block4x12.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x12 : block4x12.map Prod.snd = numericPart12 := List.map_snd_zip (by decide +kernel)
def block4x13 := rules4Part13.zip numericPart13
theorem good4x13 : block4x13.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x13 : block4x13.map Prod.snd = numericPart13 := List.map_snd_zip (by decide +kernel)
def block4x14 := rules4Part14.zip numericPart14
theorem good4x14 : block4x14.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x14 : block4x14.map Prod.snd = numericPart14 := List.map_snd_zip (by decide +kernel)
def block4x15 := rules4Part15.zip numericPart15
theorem good4x15 : block4x15.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x15 : block4x15.map Prod.snd = numericPart15 := List.map_snd_zip (by decide +kernel)
end Research.Graph9822.TwoDirect.Orbit01
