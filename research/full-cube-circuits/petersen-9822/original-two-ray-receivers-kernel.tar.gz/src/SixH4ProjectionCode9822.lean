import SixH4ProjectionOpposed9822
import SixH4ProjectedModel9822
namespace Research.SixH4.DirectLiteral
def axisCode (a b : Lit) (i : Fin 6) : Nat :=
  if i=a.1 then 0 else if i=b.1 then 1 else
    2 + ((List.range i.val).filter (fun k => !(k == a.1.val) && !(k == b.1.val))).length
def code (a b c : Lit) : Nat :=
  2 * axisCode a b c.1 + (if c.2 == (if c.1=a.1 then a.2 else if c.1=b.1 then b.2 else false)
    then 0 else 1)
def mate (a : Lit) : Lit := (a.1,!a.2)
theorem code_root : ∀ a b : Lit, a.1 ≠ b.1 →
    code a b a=0 ∧ code a b b=2 := by
  simp only [Lit,Prod.forall]
  decide +kernel
theorem axis_different : ∀ a b : Lit, a.1 ≠ b.1 → ∀ c d : Fin 6, c ≠ d →
    axisCode a b c ≠ axisCode a b d := by
  simp only [Lit,Prod.forall]
  decide +kernel
theorem code_axis : ∀ a b c : Lit, code a b c / 2 = axisCode a b c.1 := by
  simp only [Lit,Prod.forall]
  decide +kernel
theorem code_bound : ∀ a b : Lit, a.1 ≠ b.1 → ∀ c : Lit, code a b c < 12 := by
  simp only [Lit,Prod.forall]
  decide +kernel
theorem code_mate : ∀ a b c : Lit, code a b (mate c)=code a b c ^^^ 1 := by
  simp only [Lit,Prod.forall]
  decide +kernel
theorem code_polarity : ∀ (a b : Lit) (i : Fin 6), code a b (i,false) ≠ code a b (i,true) := by
  simp only [Lit,Prod.forall]
  decide +kernel
theorem code_injective {a b : Lit} (ne : a.1 ≠ b.1) : Function.Injective (code a b) := by
  rintro ⟨i,s⟩ ⟨j,t⟩ eq
  have e := congrArg (fun k : Nat => k/2) eq
  rw [code_axis,code_axis] at e
  have ij : i=j := by by_contra h; exact axis_different a b ne i j h e
  subst j
  cases s <;> cases t
  · rfl
  · exact False.elim (code_polarity a b i eq)
  · exact False.elim (code_polarity a b i eq.symm)
  · rfl
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.code_injective
