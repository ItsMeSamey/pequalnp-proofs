import SixH4ProjectionCommon9822
import SixH4ProjectionPairs9822
namespace Research.SixH4.PairPartition
open Research.SixH4.DirectLiteral Research.Graph9822Resolution
theorem roster (A : Fin 6 → Set Word) (L : V → List Lit) {x y : V}
    {a b : Lit} (ord : x < y) (nonedge : ¬ adj x y)
    (lx : L x = [a]) (ly : L y = [b]) (rootaxes : a.1 ≠ b.1)
    (pairs : ∀ z, z ≠ x → z ≠ y → ∃ c d : Lit, c.1 ≠ d.1 ∧ L z = [c,d])
    (edges : ∀ i j, adj i j → ∀ q, receives A (L i) q ∨ receives A (L j) q)
    (rooms : ∀ u : Fin 16, ∃ q : Word, ∀ v : V,
      receives A (L v) q ↔ v.val ∉ independentSets u) : (x,y) ∈ kept := by
  have irrefl : ∀ v : V, ¬ adj v v := by decide +kernel
  apply survive ord nonedge (fun v => {q | receives A (L v) q}) a.1 b.1 a.2 b.2
  · rintro q ⟨c,h,hit⟩
    rw [lx,List.mem_singleton] at h
    subst c
    exact hit.2
  · rintro q ⟨c,h,hit⟩
    rw [ly,List.mem_singleton] at h
    subst c
    exact hit.2
  · intro z xz yz
    obtain ⟨c,d,cd,lz⟩ := pairs z (fun eq => irrefl x (eq ▸ xz))
      (fun eq => irrefl y (eq ▸ yz))
    have one := edges x z xz
    have two := edges y z yz
    rw [lx,lz] at one
    rw [ly,lz] at two
    rw [lz]
    exact common_neighbor rootaxes cd one two
  · exact rooms
end Research.SixH4.PairPartition
#print axioms Research.SixH4.PairPartition.roster
