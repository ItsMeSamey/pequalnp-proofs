import SixH4ProjectionSymmetry9822
import SixH4WideProjectedModel9822
namespace Research.Graph9822.TwoDirect.Symmetry
theorem wide_origins_map : ∀ j : Fin 6, 2≤j.val → ∀ o∈wideOrigins 2 3 j.val,
    moveOrigin o∈wideOrigins 0 1 j.val := by decide +kernel
theorem wide_transfer_origin : ∀ j : Fin 6, 2≤j.val → ∀ o∈wideOrigins 2 3 j.val,
    o ≠ 22 → moveOrigin o ≠ 22 ∧
    (if o<12 then moveOrigin o<12 ∧ label (moveOrigin o)=o else
      12≤moveOrigin o ∧ moveOrigin o-12<10 ∧ vertex (moveOrigin o-12)=o-12) := by decide +kernel
def wide_transport (p : WideProjection 2 3) : WideProjection 0 1 where
  ray k m := p.ray (label k) (moveRoom m)
  raw v := moveArm (p.raw (vertex v))
  origin j := moveOrigin (p.origin j)
  selected v hv := legal_arm ⟨v,hv⟩ _ (p.selected _ (legal_vertex ⟨v,hv⟩))
  rawRows v hv m hm := (any_transfer _ _).trans ((p.rawRows _ (legal_vertex ⟨v,hv⟩) _
    (row_maps m hm).1).trans ((row_maps m hm).2 ⟨v,hv⟩))
  opposed u v uv hv e := by
    let U : Fin 10 := ⟨u,by omega⟩
    let V : Fin 10 := ⟨v,hv⟩
    apply opposed_transfer U V uv e _ (p.selected _ (legal_vertex U)) _ (p.selected _ (legal_vertex V))
    rcases edge_transfer U V uv e with ⟨lt,adj⟩ | ⟨lt,adj⟩
    · exact Or.inl (p.opposed _ _ lt (legal_vertex V) adj)
    · exact Or.inr (p.opposed _ _ lt (legal_vertex U) adj)
  side0 m hm := (p.side2 _ (row_maps m hm).1).trans ((row_maps m hm).2 0)
  side1 m hm := (p.side3 _ (row_maps m hm).1).trans (congrArg Bool.not ((row_maps m hm).2 0))
  side2 m hm := (p.side0 _ (row_maps m hm).1).trans ((row_maps m hm).2 1)
  side3 m hm := (p.side1 _ (row_maps m hm).1).trans (congrArg Bool.not ((row_maps m hm).2 1))
  disjoint j lo hi m hm := by
    have ge : ¬ 2*j<4 := by omega
    have gt : ¬ 2*j+1<4 := by omega
    simpa [label,ge,gt] using p.disjoint j lo hi (moveRoom m) (row_maps m hm).1
  named j lo hi := wide_origins_map ⟨j,hi⟩ lo _ (p.named j lo hi)
  activation j lo hi m hm := by
    have ge : ¬ 2*j<4 := by omega
    have gt : ¬ 2*j+1<4 := by omega
    rw [show label (2*j)=2*j by simp [label,ge],show label (2*j+1)=2*j+1 by simp [label,gt]]
    rw [p.activation j lo hi (moveRoom m) (row_maps m hm).1]
    by_cases top : p.origin j=22
    · rw [if_pos top,if_pos (show moveOrigin (p.origin j)=22 by rw [top]; decide)]
    have pair := wide_transfer_origin ⟨j,hi⟩ lo _ (p.named j lo hi) top
    rw [if_neg top,if_neg pair.1]
    have o := pair.2
    by_cases low : p.origin j<12
    · simp only [low,if_true] at o ⊢
      rw [if_pos o.1,o.2]
    · simp only [low,if_false] at o ⊢
      rw [if_neg (by omega : ¬ moveOrigin (p.origin j)<12)]
      let v : Fin 10 := ⟨_,o.2.1⟩
      exact (show vertex v.val=p.origin j-12 from o.2.2) ▸ (row_maps m hm).2 v
end Research.Graph9822.TwoDirect.Symmetry
