import SixH4ProjectedModel9822
set_option maxHeartbeats 3000000
namespace Research.Graph9822.TwoDirect.Symmetry
def vertex (v : Nat) := [3,2,1,0,4,8,7,6,5,9][v]?.getD v
def label (k : Nat) := if k < 4 then k ^^^ 2 else k
def moveRoom (m : Nat) := (List.range 10).foldl (fun z v =>
  if m.testBit v then z ||| 2^(vertex v) else z) 0
def moveArm (a : Arm) : Arm :=
  if a=[1,3] then [1,3] else a.map label
def moveOrigin (n : Nat) := if n<12 then label n else 12+vertex (n-12)
theorem row_maps : ∀ m∈rooms,moveRoom m∈rooms ∧ ∀ v : Fin 10,
    rawBit (vertex v.val) (moveRoom m) = rawBit v.val m := by decide +kernel
theorem legal_vertex : ∀ v : Fin 10, vertex v.val < 10 := by decide +kernel
theorem legal_arm : ∀ v : Fin 10,∀ a∈options 2 3 (vertex v.val),
    moveArm a ∈ options 0 1 v.val := by decide +kernel
theorem mapped_origin : ∀ j : Fin 4, 2≤j.val → ∀ s∈origins 2 3 j.val,
    moveOrigin s ∈ origins 0 1 j.val := by decide +kernel
theorem opposed_transfer : ∀ u v : Fin 10,u<v → edge u.val v.val=true →
    ∀ a ∈ options 2 3 (vertex u.val),∀ b ∈ options 2 3 (vertex v.val),
      (opposes a b=true ∨ opposes b a=true) → opposes (moveArm a) (moveArm b)=true := by
  decide +kernel
theorem edge_transfer : ∀ u v : Fin 10,u<v → edge u.val v.val=true →
    (vertex u.val < vertex v.val ∧ edge (vertex u.val) (vertex v.val)=true) ∨
    (vertex v.val < vertex u.val ∧ edge (vertex v.val) (vertex u.val)=true) := by decide +kernel
end Research.Graph9822.TwoDirect.Symmetry
