import SixH4WideOrbitCase4Data9822
namespace Research.Graph9822.TwoDirect.Orbit01
open PEqualNP.Library.LRAT
set_option maxRecDepth 50000
set_option maxHeartbeats 0
def block4x24 := rules4Part24.zip numericPart24
theorem good4x24 : block4x24.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x24 : block4x24.map Prod.snd = numericPart24 := List.map_snd_zip (by decide +kernel)
def block4x25 := rules4Part25.zip numericPart25
theorem good4x25 : block4x25.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x25 : block4x25.map Prod.snd = numericPart25 := List.map_snd_zip (by decide +kernel)
def block4x26 := rules4Part26.zip numericPart26
theorem good4x26 : block4x26.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x26 : block4x26.map Prod.snd = numericPart26 := List.map_snd_zip (by decide +kernel)
def block4x27 := rules4Part27.zip numericPart27
theorem good4x27 : block4x27.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x27 : block4x27.map Prod.snd = numericPart27 := List.map_snd_zip (by decide +kernel)
def block4x28 := rules4Part28.zip numericPart28
theorem good4x28 : block4x28.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x28 : block4x28.map Prod.snd = numericPart28 := List.map_snd_zip (by decide +kernel)
def block4x29 := rules4Part29.zip numericPart29
theorem good4x29 : block4x29.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x29 : block4x29.map Prod.snd = numericPart29 := List.map_snd_zip (by decide +kernel)
def block4x30 := rules4Part30.zip numericPart30
theorem good4x30 : block4x30.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x30 : block4x30.map Prod.snd = numericPart30 := List.map_snd_zip (by decide +kernel)
def block4x31 := rules4Part31.zip numericPart31
theorem good4x31 : block4x31.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x31 : block4x31.map Prod.snd = numericPart31 := List.map_snd_zip (by decide +kernel)
end Research.Graph9822.TwoDirect.Orbit01
