import SixH4WideOrbitCase49822
import SixH4WideOrbitStep39822
import SixH4WideSigned9822
namespace Research.Graph9822.TwoDirect.WS01
theorem closed : ¬ Nonempty (WideProjection 0 1) := by
  rintro ⟨p⟩
  obtain ⟨q,g⟩ := Signed.normalize p
  exact Orbit01.branch4 Orbit01.unsat q g
end Research.Graph9822.TwoDirect.WS01
