import SixH4FreshTrace9822
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
def Origin (p : List (Axis × Mask)) (m : Mask) : Prop :=
  ∃ i u, (i,u) ∈ p ∧ ∃ s, m = u ∩ side i s
theorem origin_extend {p : List (Axis × Mask)} {m : Mask} (t : Axis × Mask)
    (h : Origin p m) : Origin (t::p) m := by
  obtain ⟨i,u,mem,s,eq⟩ := h
  exact ⟨i,u,List.mem_cons_of_mem _ mem,s,eq⟩
theorem paid_sources {N b l p n} (h : Paid N b l p n) :
    (∀ m ∈ l, m = Set.univ ∨ m ∈ N ∨ Origin p m) ∧
    (∀ t ∈ p, t.2 ∈ l) := by
  induction h with
  | start => simp
  | @join b l p n x y h hx hy used fresh ih =>
    constructor
    · intro m hm
      rcases List.mem_cons.mp hm with rfl | old
      · exact Or.inr (Or.inl used)
      · exact ih.1 m old
    · exact fun t ht => List.mem_cons_of_mem _ (ih.2 t ht)
  | @split b l p n u i h hu ih =>
    constructor
    · intro m hm
      rcases List.mem_cons.mp hm with rfl | tail
      · exact Or.inr (Or.inr ⟨i,u,by simp,true,rfl⟩)
      rcases List.mem_cons.mp tail with rfl | tail
      · exact Or.inr (Or.inr ⟨i,u,by simp,false,rfl⟩)
      rcases ih.1 m tail with top | used | org
      · exact Or.inl top
      · exact Or.inr (Or.inl used)
      · exact Or.inr (Or.inr (origin_extend _ org))
    · intro t ht
      rcases List.mem_cons.mp ht with rfl | old
      · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hu)
      · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (ih.2 t old))
end Research.Graph9822Profiles.Fresh
