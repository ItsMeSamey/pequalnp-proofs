import SixH4WideProjectedModel9822
namespace Research.Graph9822.TwoDirect.Signed
abbrev Shift := Fin 8
def target (b : Shift) := 4+b.val
def axis (b : Shift) (j : Nat) :=
  if j=2 then target b / 2 else if j = target b / 2 then 2 else j
def lbl (b : Shift) (k : Nat) :=
  if k<12 then
    if k/2=2 ∨ k/2=target b/2 then 2 * axis b (k/2) + ((k%2) ^^^ (target b % 2)) else k
  else k
def ordered : Arm → Arm
  | [a,b] => if a ≤ b then [a,b] else [b,a]
  | t => t
def move (b : Shift) (t : Arm) := ordered (t.map (lbl b))
def originCode (b : Shift) (o : Nat) := if o<12 then lbl b o else o

theorem bounds : ∀ b : Shift, ∀ k : Fin 12, lbl b k < 12 ∧ lbl b (lbl b k) = k.val ∧
    lbl b (k.val ^^^ 1) = (lbl b k ^^^ 1) := by decide +kernel
theorem rootLabels : ∀ b : Shift, lbl b 0=0 ∧ lbl b 1=1 ∧ lbl b 2=2 ∧ lbl b 3=3 := by decide +kernel
theorem axisBounds : ∀ b : Shift, ∀ j : Fin 6, 2 ≤ j.val →
    2 ≤ axis b j ∧ axis b j < 6 ∧
      ((lbl b (2*j.val) = 2*axis b j ∧ lbl b (2*j.val+1) = 2*axis b j+1) ∨
       (lbl b (2*j.val) = 2*axis b j+1 ∧ lbl b (2*j.val+1) = 2*axis b j)) := by decide +kernel
theorem armBounds : ∀ v : Fin 10, ∀ t ∈ options 0 1 v, ∀ a ∈ t, a < 12 := by decide +kernel
theorem legal : ∀ b : Shift, ∀ v : Fin 10, ∀ t ∈ options 0 1 v, move b t ∈ options 0 1 v := by decide +kernel
theorem named : ∀ b : Shift, ∀ j : Fin 6, 2 ≤ j.val →
    ∀ o ∈ wideOrigins 0 1 (axis b j), originCode b o ∈ wideOrigins 0 1 j := by decide +kernel
theorem normalArm : ∀ b : Shift, move b [1,target b] = [1,4] := by decide +kernel
theorem fixedChoice : ∀ t ∈ options 0 1 4, ∃ b : Shift, t = [1,target b] := by decide +kernel
end Research.Graph9822.TwoDirect.Signed
