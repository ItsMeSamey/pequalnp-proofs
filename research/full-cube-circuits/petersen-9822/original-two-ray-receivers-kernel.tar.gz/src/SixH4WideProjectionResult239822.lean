import SixH4WideProjectionResult019822
import SixWideProjectionSymmetry9822
namespace Research.Graph9822.TwoDirect.WS23
theorem closed : ¬ Nonempty (WideProjection 2 3) := by
  rintro ⟨p⟩
  exact WS01.closed ⟨Symmetry.wide_transport p⟩
end Research.Graph9822.TwoDirect.WS23
