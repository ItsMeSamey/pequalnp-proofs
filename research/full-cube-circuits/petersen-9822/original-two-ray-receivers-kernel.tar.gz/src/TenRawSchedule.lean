import MonoCleanExtract
import CutGroupLedger
namespace Research.Graph9822Profiles.OuterLive
open PEqualNP.Outside.L_meta_9822.Sectors
open Research.Graph9822Resolution

def mate (k : Fin 10) : Fin 10 := (![4,2,1,4,0,0,1,2,3,4] : Fin 10 → Fin 10) k

theorem edge_change : ∀ k : Fin 10,
    edge (fun j => j == mate k) ≠ edge (fun j => j == k || j == mate k) := by decide +kernel

theorem well_of_dWell (ds : List DGate) (n : Nat) (h : dWell ds n) : WellWired ds n := by
  induction ds generalizing n with
  | nil => trivial
  | cons d ds ih => exact ⟨h.1,h.2.1,ih _ h.2.2⟩

theorem ten_essential (ds : List DGate) (o : Nat)
    (he : ∀ x : Fin 10→Bool, eval ds 10 (wiresFrom (List.ofFn x)) o = edge x) :
    ∀ k < 10, ∃ u v : DWire, (∀ j, j ≠ k → u j = v j) ∧ eval ds 10 u o ≠ eval ds 10 v o := by
  intro k hk
  let x : Fin 10 := ⟨k,hk⟩
  let u : Fin 10 → Bool := fun j => j == mate x
  let v : Fin 10 → Bool := fun j => j == x || j == mate x
  refine ⟨wiresFrom (List.ofFn u), wiresFrom (List.ofFn v), ?_, ?_⟩
  · intro j hj
    by_cases hlt : j<10
    · have ne : (⟨j,hlt⟩ : Fin 10) ≠ x := fun e => hj (congrArg Fin.val e)
      unfold wiresFrom
      rw [PEqualNP.Outside.L_meta_9822.Clean.getD_ofFn 10 u false ⟨j,hlt⟩,
          PEqualNP.Outside.L_meta_9822.Clean.getD_ofFn 10 v false ⟨j,hlt⟩]
      simp [u,v,ne]
    · simp [wiresFrom,List.getD_eq_getElem?_getD,List.getElem?_ofFn,hlt]
  · rw [he,he]
    exact edge_change x

theorem ten_eight_actual (axis : Nat → Axis) (gs : List DGate) (out : Nat)
    (size : gs.length ≤ 17) (ok : WellWired gs 10) (outBound : out < 10+gs.length)
    (essential : ∀ k < 10, ∃ u v : DWire, (∀ j, j ≠ k → u j = v j) ∧
      Research.Graph9822Resolution.eval gs 10 u out ≠ Research.Graph9822Resolution.eval gs 10 v out) :
    let es := gateEvents axis gs 10 ++ rawEvents 10
    let live := activeEvents es (initial out)
    Profile (live.foldl next (initial out)).branches (live.foldl next (initial out)).switches ∧
    (live.foldl next (initial out)).cost ≤ 8 := by
  let gates := gateEvents axis gs 10
  let acts := activeEvents gates (initial out)
  have qlive : ∀ k < 10, (back axis gs 10 (initial out)).q k ≠ [] := by
    intro k hk
    obtain ⟨u,v,off,hit⟩ := essential k hk
    exact back_essential axis gs 10 out k u v off hit
  have act : activeEvents (gates++rawEvents 10) (initial out) = acts++rawEvents 10 := by
    rw [active_append]
    dsimp only [gates]
    rw [gates_fold,raw_all _ _ qlive]
  have cnt : (acts.map gateWeight).sum = acts.length := all_active_gates _ _ (gate_lengths gs 10 axis).2
  have lim : acts.length ≤ gs.length := (active_length_le _ _).trans_eq (gate_lengths gs 10 axis).1
  have rc := raw_statistics 10
  have total : (activeEvents (gates++rawEvents 10) (initial out)).length =
      10 + ((activeEvents (gates++rawEvents 10) (initial out)).map gateWeight).sum := by
    simp [act,rc.1,rc.2,cnt,Nat.add_comm]
  have exactCost := scheduled_cost (prepend_schedule axis gs 10 ok _ (raw_schedule 10)) out outBound 10 total
  have low : ((activeEvents (gates++rawEvents 10) (initial out)).map gateWeight).sum ≤ 17 := by
    simpa [act,rc.2,cnt] using lim.trans size
  exact ⟨extracted_profile _ _,by change _ ≤ 8; dsimp only [gates] at low; omega⟩


theorem positive_out_in_range (C : PEqualNP.CircuitLowerBounds.Circuit) (hc : Candidate C) :
    C.output < 10+C.gates.length := by
  by_contra h
  have ge : 10+C.gates.length ≤ C.output := by omega
  have trueOn := hc.2.2 (fun _ => true)
  change (PEqualNP.Outside.L_meta_9822.Clean.wiresFrom C.gates
    (List.ofFn (fun _ : Fin 10 => true))).getD C.output false = edge (fun _ => true) at trueOn
  have len := PEqualNP.Outside.L_meta_9822.Clean.length_wiresFrom C.gates
    (List.ofFn (fun _ : Fin 10 => true))
  simp only [List.length_ofFn] at len
  rw [List.getD_eq_default _ _ (by omega)] at trueOn
  simp [edge] at trueOn

/-- Construct physical gate events and settle every live receiver for a clean
zero-NOT candidate. The output bound follows separately from positivity. -/
theorem clean_candidate_profile (C : PEqualNP.CircuitLowerBounds.Circuit) (hc : Candidate C)
    (clean : PEqualNP.Outside.L_meta_9822.Clean.CleanL 10 C.gates)
    (hz : C.gates.countP countsNot=0)
    (axis : Nat → Axis) :
    ∃ ds : List DGate, ds.length ≤ 17 ∧
      (∀ x : Fin 10 → Bool, eval ds 10 (wiresFrom (List.ofFn x)) C.output = edge x) ∧
      let es := gateEvents axis ds 10 ++ rawEvents 10
      let active := activeEvents es (initial C.output)
      Profile (active.foldl next (initial C.output)).branches
        (active.foldl next (initial C.output)).switches ∧
          (active.foldl next (initial C.output)).cost ≤ 8 := by
  have outBound := positive_out_in_range C hc
  have no : ∀ g ∈ C.gates, g.op ≠ .not := by
    intro g hg eq
    have h := List.countP_eq_zero.mp hz g hg
    simp [countsNot,eq] at h
  obtain ⟨ds,hg,well⟩ := clean_as_binary C.gates 10 clean no
  have hcirc : asCircuit ds C.output = C := by cases C; simp_all [asCircuit]
  have len : ds.length=C.gates.length := by simpa using congrArg List.length hg
  have budget : ds.length ≤ 17 := by rw [len]; exact hc.2.1
  have he : ∀ x : Fin 10 → Bool, eval ds 10 (wiresFrom (List.ofFn x)) C.output = edge x := by
    intro x
    have h := hc.2.2 x
    rw [←hcirc,physical_eval,List.length_ofFn] at h
    simpa [hcirc] using h
  exact ⟨ds,budget,he,ten_eight_actual axis ds C.output budget (well_of_dWell _ _ well)
    (by simpa [len] using outBound) (ten_essential ds C.output he)⟩

end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.ten_eight_actual
#print axioms Research.Graph9822Profiles.OuterLive.clean_candidate_profile
