import SixH4TenReturn9822
import ReceiverFacts9822

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822
open PEqualNP.Outside.L_meta_9822.Sectors
open PEqualNP.Outside.L_meta_9822.Receivers

private theorem missing_pair : ∀ u v : Fin 10, rawEdge u v = false →
    FourSaturation.witnesses.any (fun m => m.testBit u.val && m.testBit v.val) = true := by
  decide +kernel

theorem physical_receiver_facts (gs : List DGate) (out : Nat) (cap : gs.countP Gate.isAnd ≤ 6)
    (h : ∀ x : Fin 10 → Bool, eval gs 10 (wiresFrom (List.ofFn x)) out = edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le cap)
    let R := tenR axis gs out
    ExactReceivers (fun v q => q ∈ R v) ∧
    (∀ u v, u ≠ v → ∃ q, q ∈ R u ∧ q ∉ R v) ∧
    (∀ u v, ∃ q, q ∈ R u ∧ q ∈ R v) ∧
    (∀ u v, rawEdge u v=true ↔ ∀ q, q ∈ R u ∨ q ∈ R v) := by
  intro axis R
  have er : ExactReceivers (fun v q => q ∈ R v) := ⟨ten_realizes gs out cap h⟩
  refine ⟨er,indispensable er,overlap er,fun u v => ⟨ten_cover_h4 axis gs out h u v,?_⟩⟩
  intro cover
  cases hv : rawEdge u v with
  | true => rfl
  | false =>
    obtain ⟨m,hm,bits⟩ := List.any_eq_true.mp (missing_pair u v hv)
    obtain ⟨a,ha⟩ := er.realize m hm
    have both := Bool.and_eq_true_iff.mp bits
    rcases cover a with hu|hw
    · have bad := (ha u).mp hu
      simp [both.1] at bad
    · have bad := (ha v).mp hw
      simp [both.2] at bad

theorem six_names {p : List (Axis × Mask)}
    (tags : p.map Prod.fst=((List.range 6).map (Fin.ofNat 6)).reverse) :
    (p.map Prod.fst).Nodup ∧ ∀ i : Axis, ∃ m, (i,m)∈p := by
  constructor
  · rw [tags]
    decide +kernel
  · intro i
    have alltags : ∀ j : Axis,j∈((List.range 6).map (Fin.ofNat 6)).reverse := by decide +kernel
    have contained : i∈p.map Prod.fst := tags ▸ alltags i
    obtain ⟨⟨j,m⟩,hm,eq⟩ := List.mem_map.mp contained
    exact ⟨m,eq ▸ hm⟩

end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.physical_receiver_facts
#print axioms Research.Graph9822Profiles.OuterLive.six_names
