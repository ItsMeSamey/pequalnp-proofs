import SixH4ProjectedModel9822
namespace Research.Graph9822.TwoDirect
def wideOrigins (x y j : Nat) := 22 :: origins x y j
structure WideProjection (x y : Nat) where
  ray : Nat → Nat → Bool
  raw : Nat → Arm
  origin : Nat → Nat
  selected : ∀ v, v < 10 → raw v ∈ options x y v
  rawRows : ∀ v, v < 10 → ∀ m ∈ rooms, ((raw v).any (fun k => ray k m)) = rawBit v m
  opposed : ∀ u v, u < v → v < 10 → edge u v = true → opposes (raw u) (raw v) = true
  side0 : ∀ m ∈ rooms, ray 0 m = rawBit x m
  side1 : ∀ m ∈ rooms, ray 1 m = !(rawBit x m)
  side2 : ∀ m ∈ rooms, ray 2 m = rawBit y m
  side3 : ∀ m ∈ rooms, ray 3 m = !(rawBit y m)
  disjoint : ∀ j, 2 ≤ j → j < 6 → ∀ m ∈ rooms,
    (ray (2*j) m && ray (2*j+1) m) = false
  named : ∀ j, 2 ≤ j → j < 6 → origin j ∈ wideOrigins x y j
  activation : ∀ j, 2 ≤ j → j < 6 → ∀ m ∈ rooms,
    (ray (2*j) m || ray (2*j+1) m) =
      if origin j = 22 then true else if origin j < 12 then ray (origin j) m else rawBit (origin j-12) m
end Research.Graph9822.TwoDirect
