import SixH4ProjectionSymmetryData9822
namespace Research.Graph9822.TwoDirect.Symmetry
theorem label_twice (k : Nat) : label (label k)=k := by
  by_cases h : k<4
  · exact (show ∀ t : Fin 4, label (label t.val)=t.val by decide +kernel) ⟨k,h⟩
  · simp [label,h]
theorem any_transfer (a : Arm) (r : Nat → Bool) :
    (moveArm a).any (fun k=>r (label k))=a.any r := by
  by_cases h : a=[1,3]
  · subst a
    have a1 : label 1=3 := by decide
    have a3 : label 3=1 := by decide
    simp [moveArm,List.any_cons,a1,a3,Bool.or_comm]
  · simp [moveArm,h,List.any_map,Function.comp_def,label_twice]
theorem origin_transfer : ∀ j : Fin 4, 2 ≤ j.val → ∀ o ∈ origins 2 3 j.val,
    (if o<12 then moveOrigin o<12 ∧ label (moveOrigin o)=o else
      12≤moveOrigin o ∧ moveOrigin o-12<10 ∧ vertex (moveOrigin o-12)=o-12) := by decide +kernel
def transport (p : Projection 2 3) : Projection 0 1 where
  ray k m := p.ray (label k) (moveRoom m)
  raw v := moveArm (p.raw (vertex v))
  origin j := moveOrigin (p.origin j)
  selected v hv := legal_arm ⟨v,hv⟩ _ (p.selected _ (legal_vertex ⟨v,hv⟩))
  rawRows v hv m hm := (any_transfer _ _).trans ((p.rawRows _ (legal_vertex ⟨v,hv⟩) _
    (row_maps m hm).1).trans ((row_maps m hm).2 ⟨v,hv⟩))
  opposed u v uv hv e := by
    let U : Fin 10 := ⟨u,by omega⟩
    let V : Fin 10 := ⟨v,hv⟩
    apply opposed_transfer U V uv e _ (p.selected _ (legal_vertex U)) _ (p.selected _ (legal_vertex V))
    rcases edge_transfer U V uv e with ⟨lt,adj⟩ | ⟨lt,adj⟩
    · exact Or.inl (p.opposed _ _ lt (legal_vertex V) adj)
    · exact Or.inr (p.opposed _ _ lt (legal_vertex U) adj)
  side0 m hm := (p.side2 _ (row_maps m hm).1).trans ((row_maps m hm).2 0)
  side1 m hm := (p.side3 _ (row_maps m hm).1).trans (congrArg Bool.not ((row_maps m hm).2 0))
  side2 m hm := (p.side0 _ (row_maps m hm).1).trans ((row_maps m hm).2 1)
  side3 m hm := (p.side1 _ (row_maps m hm).1).trans (congrArg Bool.not ((row_maps m hm).2 1))
  disjoint j lo hi m hm := by
    have ge : ¬ 2*j<4 := by omega
    have gt : ¬ 2*j+1<4 := by omega
    simpa [label,ge,gt] using p.disjoint j lo hi (moveRoom m) (row_maps m hm).1
  named j lo hi := mapped_origin ⟨j,hi⟩ lo _ (p.named j lo hi)
  activation j lo hi m hm := by
    have ge : ¬ 2*j<4 := by omega
    have gt : ¬ 2*j+1<4 := by omega
    rw [show label (2*j)=2*j by simp [label,ge],show label (2*j+1)=2*j+1 by simp [label,gt]]
    rw [p.activation j lo hi (moveRoom m) (row_maps m hm).1]
    have o := origin_transfer ⟨j,hi⟩ lo _ (p.named j lo hi)
    by_cases low : p.origin j<12
    · simp only [low,if_true] at o ⊢
      rw [if_pos o.1,o.2]
    · simp only [low,if_false] at o ⊢
      rw [if_neg (by omega : ¬ moveOrigin (p.origin j)<12)]
      let v : Fin 10 := ⟨_,o.2.1⟩
      exact (show vertex v.val=p.origin j-12 from o.2.2) ▸ (row_maps m hm).2 v
end Research.Graph9822.TwoDirect.Symmetry
