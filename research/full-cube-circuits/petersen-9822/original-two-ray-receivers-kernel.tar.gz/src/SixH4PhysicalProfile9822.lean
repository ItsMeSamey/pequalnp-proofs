import SixH4PhysicalFields9822
import PhysicalResolution
import And9822Four
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822
open PEqualNP.Outside.L_meta_9822.Sectors
open TraceCount (Generated sampleMask activation)

theorem raw_sample_rooms (gs : List DGate) (out : Nat) (cap : gs.countP Gate.isAnd≤6)
    (h : ∀ x : Fin 10 → Bool,eval gs 10 (wiresFrom (List.ofFn x)) out=edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le cap)
    ∀ i : Fin 16,∃ d : Fin 64,∀ v : Fin 10,
      sampleMask (tenR axis gs out v) d=true ↔ v.val∉independentSets i := by
  classical
  intro axis i
  have facts : ∀ u : Fin 16,FourSaturation.witnesses.getD u.val 0∈FourSaturation.witnesses ∧
      ∀ v : Fin 10,(FourSaturation.witnesses.getD u.val 0).testBit v.val=false ↔
        v.val∉independentSets u := by decide +kernel
  obtain ⟨q,hq⟩ := ten_realizes gs out cap h _ (facts i).1
  obtain ⟨d,hd⟩ := TraceCount.sample_onto q
  refine ⟨d,?_⟩
  intro v
  rw [sampleMask,decide_eq_true_eq,hd]
  exact (hq v).trans ((facts i).2 v)

theorem actual_profile (gs : List DGate) (out : Nat) (size : gs.length≤17)
    (ok : WellWired gs 10) (ob : out<10+gs.length) (cap : gs.countP Gate.isAnd≤6)
    (computes : ∀ x : Fin 10 → Bool,(asCircuit gs out).eval (List.ofFn x)=edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le cap)
    let es := gateEvents axis gs 10 ++ rawEvents 10
    let st := (activeEvents es (initial out)).foldl next (initial out)
    let T := fieldsProfile st.switches
    let R := tenR axis gs out
    (∀ s∈st.switches,sampleMask s.2=activation T s.1) ∧
    Profile st.branches st.switches ∧ st.cost≤8 ∧
    (∃ l,Scan st.branches l st.switches st.cost ∧ ∀ v,R v∈l) ∧
    (∀ v,Generated T (sampleMask (R v))) ∧
    (∀ i : Fin 16,∃ d : Fin 64,∀ v : Fin 10,sampleMask (R v) d=true ↔ v.val∉independentSets i) := by
  intro axis es st T R
  have h : ∀ x : Fin 10 → Bool,eval gs 10 (wiresFrom (List.ofFn x)) out=edge x := by
    intro x; simpa only [physical_eval,List.length_ofFn] using computes x
  have nd := active_chrono_unique gs out cap
  have codes : ∀ s∈st.switches,sampleMask s.2=activation T s.1 := every_code _ nd
  obtain ⟨l,scan,ret⟩ := ten_scan_returned_h4 axis gs out h
  obtain ⟨grammar,budget⟩ := ten_eight_actual axis gs out size ok ob (ten_essential gs out h)
  exact ⟨codes,grammar,budget,⟨l,scan,ret⟩,fun v=>TraceCount.scan_samples scan T codes _ (ret v),
    raw_sample_rooms gs out cap h⟩

theorem padded_profile_rows (gs : List DGate) (out : Nat) (size : gs.length≤17)
    (ok : WellWired gs 10) (ob : out<10+gs.length) (cap : gs.countP Gate.isAnd≤6)
    (computes : ∀ x : Fin 10 → Bool,(asCircuit gs out).eval (List.ofFn x)=edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le cap)
    let es := gateEvents axis gs 10 ++ rawEvents 10
    let st := es.foldl paddedStep (initial out)
    let T := fieldsProfile st.switches
    let R := tenR axis gs out
    st.switches.map Prod.fst=((List.range (gs.countP Gate.isAnd)).map (Fin.ofNat 6)).reverse ∧
    (∀ s∈st.switches,sampleMask s.2=activation T s.1) ∧
    Profile st.branches st.switches ∧ st.cost≤8 ∧
    (∃ l,Scan st.branches l st.switches st.cost ∧ ∀ v,R v∈l) ∧
    (∀ v,Generated T (sampleMask (R v))) ∧
    (∀ i : Fin 16,∃ d : Fin 64,∀ v : Fin 10,sampleMask (R v) d=true ↔ v.val∉independentSets i) := by
  intro axis es st T R
  have h : ∀ x : Fin 10 → Bool,eval gs 10 (wiresFrom (List.ofFn x)) out=edge x := by
    intro x; simpa only [physical_eval,List.length_ofFn] using computes x
  have live : ∀ a<10,(back axis gs 10 (initial out)).q a≠[] := by
    intro a ha
    obtain ⟨u,v,off,hit⟩ := ten_essential gs out h a ha
    exact back_essential axis gs 10 out a u v off hit
  obtain ⟨good,tags,raws,cost⟩ := signed_padded_bank gs 10 out ((switchAddrs_length gs 10).trans_le cap) live
  have nd : (st.switches.map Prod.fst).Nodup := by rw [tags]; exact chrono_unique _ cap
  have codes := every_code st.switches nd
  obtain ⟨l,scan,_,returned⟩ := good
  have ret (v : Fin 10) : R v∈l := by
    apply returned
    rw [raws]
    apply List.mem_map.mpr
    refine ⟨v.val,List.mem_range.mpr v.isLt,?_⟩
    ext w
    exact (back_receiver_exact axis w gs 10 v.val out v.isLt).symm
  have budget := (ten_eight_actual axis gs out size ok ob (ten_essential gs out h)).2
  exact ⟨tags,codes,scan_profile scan,cost.trans_le budget,⟨l,scan,ret⟩,
    fun v=>TraceCount.scan_samples scan T codes _ (ret v),raw_sample_rooms gs out cap h⟩

end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.actual_profile
#print axioms Research.Graph9822Profiles.OuterLive.padded_profile_rows
