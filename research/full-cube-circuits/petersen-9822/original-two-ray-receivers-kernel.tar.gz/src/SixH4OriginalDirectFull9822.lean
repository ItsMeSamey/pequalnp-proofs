import SixH4D2ReceiverFacts9822
import SixH4PhysicalProfile9822
import SixH4TwoDirectFull9822
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822
open Research.Graph9822.ArbitraryScan Research.Graph9822.CommonBank
open PEqualNP.Outside.L_meta_9822.Sectors
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
theorem physical_d2_full_and_pairs (gs : List DGate) (out : Nat) (size : gs.length≤17)
    (ok : WellWired gs 10) (ob : out<10+gs.length) (six : gs.countP Gate.isAnd=6)
    (computes : ∀ x : Fin 10 → Bool,(asCircuit gs out).eval (List.ofFn x)=edge x) :
    let cap := six.le
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le cap)
    let p := ((gateEvents axis gs 10 ++ rawEvents 10).foldl paddedStep (initial out)).switches
    let R := tenR axis gs out
    let P := field p
    ((Finset.univ : Finset (Fin 10)).filter (fun v => RayValue P (R v))).card=2 →
    (∀ v, ¬RayValue P (R v) → Fresh.DistinctPair P (R v)) ∧
    (∀ v i s, R v = ray P i s → P i = Set.univ) := by
  intro cap axis p R P d
  obtain ⟨tags,_,_,budget,⟨l,scan,ret⟩,_,_⟩ := padded_profile_rows gs out size ok ob cap computes
  have tags6 : p.map Prod.fst=((List.range 6).map (Fin.ofNat 6)).reverse :=
    tags.trans (congrArg (fun n=>((List.range n).map (Fin.ofNat 6)).reverse) six)
  have names := six_names tags6
  have h : ∀ x : Fin 10 → Bool,eval gs 10 (wiresFrom (List.ofFn x)) out=edge x := by
    intro x
    simpa only [physical_eval,List.length_ofFn] using computes x
  obtain ⟨_,sep,both,covers⟩ := physical_receiver_facts gs out cap h
  have proper (v : Fin 10) : ∃ q,q∉R v := by
    let u : Fin 10 := if v=0 then 1 else 0
    have ne : u≠v := by
      dsimp [u]
      by_cases h0 : v = 0
      · simp [h0]
      · simpa [h0] using Ne.symm h0
    obtain ⟨q,_,hv⟩ := sep u v ne
    exact ⟨q,hv⟩
  have inc (u v : Fin 10) (ne : u≠v) : ¬ R u ⊆ R v := by
    obtain ⟨q,hu,hv⟩ := sep u v ne
    exact fun sub => hv (sub hu)
  have respects (s) (hs : s∈p) : s.2=P s.1 := (field_at p names.1 s hs).symm
  have named (i : Axis) : (i,P i) ∈ p := by
    obtain ⟨m,hm⟩ := names.2 i
    have eq : m = P i := respects (i,m) hm
    simpa [←eq] using hm
  have matchEdge : ∀ u v : Fin 10, Research.Graph9822.StarData.adj u v = rawEdge u v := by
    decide +kernel
  refine ⟨two_nonsibling scan P respects R ret proper inc budget d,?_⟩
  intro v i s direct
  exact two_direct_full scan P respects named names.1 R ret proper inc (fun a c _ => both a c)
    (fun a c e => (covers a c).mp ((matchEdge a c) ▸ e)) budget d direct
end
end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.physical_d2_full_and_pairs
