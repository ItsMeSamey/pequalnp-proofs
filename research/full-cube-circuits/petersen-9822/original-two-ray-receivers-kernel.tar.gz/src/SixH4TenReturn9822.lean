import TenPhysicalRooms9822
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822
open PEqualNP.Outside.L_meta_9822.Sectors

def rawEdge (u v : Fin 10) := edge (fun k=>decide (k.val ∈ [u.val,v.val]))

theorem ten_cover_h4 (axis : Nat → Axis) (gs : List DGate) (out : Nat)
    (h : ∀ x : Fin 10 → Bool, eval gs 10 (wiresFrom (List.ofFn x)) out = edge x) :
    ∀ u v, rawEdge u v = true → ∀ q, q ∈ tenR axis gs out u ∨ q ∈ tenR axis gs out v := by
  intro u v huv q
  have lim : ∀ j∈[u.val,v.val], j < 10 := by
    intro j hj
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hj
    rcases hj with rfl | rfl <;> first | exact u.isLt | exact v.isLt
  have acc : eval gs 10 (inputSet [u.val,v.val]) out = true := by
    rw [rawset_wire _ lim,h]; exact huv
  have ht := (accepts_iff_reaches gs 10 _ out).mp acc (fun j => q (axis j))
  rw [tenR,tenR,back_receiver_exact _ _ _ _ _ _ u.isLt,back_receiver_exact _ _ _ _ _ _ v.isLt]
  change resolve gs 10 (fun j=>q (axis j)) (fun j=>decide (j=u.val)) out=true ∨
    resolve gs 10 (fun j=>q (axis j)) (fun j=>decide (j=v.val)) out=true
  simpa using ht

theorem ten_scan_returned_h4 (axis : Nat → Axis) (gs : List DGate) (out : Nat)
    (h : ∀ x : Fin 10 → Bool, eval gs 10 (wiresFrom (List.ofFn x)) out = edge x) :
    let state := (activeEvents (gateEvents axis gs 10 ++ rawEvents 10) (initial out)).foldl next (initial out)
    ∃ l, Scan state.branches l state.switches state.cost ∧ ∀ v, tenR axis gs out v ∈ l := by
  intro state
  have live : ∀ k < 10, (back axis gs 10 (initial out)).q k ≠ [] := by
    intro k hk
    obtain ⟨u,v,off,hit⟩ := ten_essential gs out h k hk
    exact back_essential axis gs 10 out k u v off hit
  obtain ⟨l,scan,_,ret⟩ := extracted_good (gateEvents axis gs 10 ++ rawEvents 10) out
  refine ⟨l,scan,fun v => ret _ ?_⟩
  rw [receiver_list_exact _ _ _ _ live]
  apply List.mem_map.mpr
  refine ⟨v.val,List.mem_range.mpr v.isLt,?_⟩
  ext w
  exact (back_receiver_exact axis w gs 10 v.val out v.isLt).symm

end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.ten_scan_returned_h4
