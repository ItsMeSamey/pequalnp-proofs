import SixH4ProjectionCheck9822
import SixH4WideProjectionClauses9822
namespace Research.Graph9822.TwoDirect
open PEqualNP.Library.LRAT
def wideSupported (x y : Nat) (vars : Array Atom) (rc : Rule × List Nat) : Bool :=
  rc.1.wideOK x y && (rc.1.wideClause x y).all (fun l => (rc.2.map (decodeLit vars)).contains l)
theorem wideFromChecked (x y : Nat) (vars : Array Atom) (data : List (Rule × List Nat))
    (good : data.all (wideSupported x y vars) = true)
    (bad : ¬ FormulaSat (data.map Prod.snd)) : ¬ Nonempty (WideProjection x y) := by
  rintro ⟨p⟩
  apply bad
  refine ⟨fun v => (vars[v]?.getD default).wideVal p,?_⟩
  intro c hc
  obtain ⟨⟨r,cl⟩,hr,rfl⟩ := List.mem_map.mp hc
  have hh := List.all_eq_true.mp good _ hr
  obtain ⟨ok,sub⟩ := Bool.and_eq_true_iff.mp hh
  obtain ⟨l,hl,eval⟩ := r.wideSound p ok
  have hmem := List.contains_iff_mem.mp (List.all_eq_true.mp sub l hl)
  obtain ⟨n,hn,eq⟩ := List.mem_map.mp hmem
  subst l
  exact ⟨n,hn,by simpa [litVal,decodeLit] using eval⟩
end Research.Graph9822.TwoDirect
