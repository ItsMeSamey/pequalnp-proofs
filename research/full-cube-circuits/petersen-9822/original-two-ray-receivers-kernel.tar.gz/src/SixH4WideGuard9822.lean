import SixH4WideProjectionCheck9822
namespace Research.Graph9822.TwoDirect
open PEqualNP.Library.LRAT
def guardSupported (x y v : Nat) (arm : Arm) (vars : Array Atom)
    (rc : Option Rule × List Nat) : Bool :=
  match rc.1 with
  | some rule => wideSupported x y vars (rule,rc.2)
  | none => (rc.2.map (decodeLit vars)).contains (pos (.raw v arm))
theorem guardFromChecked (x y v : Nat) (arm : Arm) (vars : Array Atom)
    (data : List (Option Rule × List Nat))
    (good : data.all (guardSupported x y v arm vars) = true)
    (bad : ¬ FormulaSat (data.map Prod.snd)) (p : WideProjection x y) (guard : p.raw v = arm) : False := by
  apply bad
  refine ⟨fun j => (vars[j]?.getD default).wideVal p,?_⟩
  intro c hc
  obtain ⟨⟨r,cl⟩,hr,rfl⟩ := List.mem_map.mp hc
  have h := List.all_eq_true.mp good _ hr
  have sem : ∃ l ∈ cl.map (decodeLit vars), l.1.wideVal p = l.2 := by
    cases r with
    | none =>
      exact ⟨pos (.raw v arm),List.contains_iff_mem.mp h,by simp [pos,Atom.wideVal,guard]⟩
    | some rule =>
      obtain ⟨ok,sub⟩ := Bool.and_eq_true_iff.mp h
      obtain ⟨l,hl,hv⟩ := rule.wideSound p ok
      exact ⟨l,List.contains_iff_mem.mp (List.all_eq_true.mp sub l hl),hv⟩
  obtain ⟨l,hl,hv⟩ := sem
  obtain ⟨n,hn,eq⟩ := List.mem_map.mp hl
  subst l
  exact ⟨n,hn,by simpa [litVal,decodeLit] using hv⟩
end Research.Graph9822.TwoDirect
