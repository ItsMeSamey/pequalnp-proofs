import SixH4ProjectionClauses9822
namespace Research.Graph9822.TwoDirect
open PEqualNP.Library.LRAT
def decodeLit (vars : Array Atom) (n : Nat) : Lit :=
  (vars[n/2]?.getD default, n%2 == 0)
def supported (x y : Nat) (vars : Array Atom) (rc : Rule × List Nat) : Bool :=
  rc.1.ok x y && (rc.1.clause x y).all (fun l => (rc.2.map (decodeLit vars)).contains l)
theorem fromChecked (x y : Nat) (vars : Array Atom) (data : List (Rule × List Nat))
    (good : data.all (supported x y vars) = true)
    (bad : ¬ FormulaSat (data.map Prod.snd)) : ¬ Nonempty (Projection x y) := by
  rintro ⟨p⟩
  apply bad
  refine ⟨fun v => (vars[v]?.getD default).val p,?_⟩
  intro c hc
  obtain ⟨⟨r,cl⟩,hr,rfl⟩ := List.mem_map.mp hc
  have hh := List.all_eq_true.mp good _ hr
  obtain ⟨ok,sub⟩ := Bool.and_eq_true_iff.mp hh
  obtain ⟨l,hl,eval⟩ := r.sound p ok
  have hmem := List.contains_iff_mem.mp (List.all_eq_true.mp sub l hl)
  obtain ⟨n,hn,eq⟩ := List.mem_map.mp hmem
  subst l
  exact ⟨n,hn,by simpa [litVal,decodeLit] using eval⟩
end Research.Graph9822.TwoDirect
