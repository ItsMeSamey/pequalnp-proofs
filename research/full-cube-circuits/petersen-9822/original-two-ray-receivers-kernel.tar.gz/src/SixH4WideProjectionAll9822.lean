import SixH4WideProjectionResult019822
import SixH4ProjectionPair029822
import SixH4WideOnly039822
import SixH4ProjectionPair069822
import SixH4ProjectionPair139822
import SixH4ProjectionPair149822
import SixH4ProjectionPair159822
import SixH4ProjectionPair179822
import SixH4WideProjectionResult239822
import SixH4ProjectionPair249822
import SixH4ProjectionPair269822
import SixH4ProjectionPair289822
import SixH4ProjectionPair379822
import SixH4ProjectionPair459822
import SixH4ProjectionPair489822
import SixH4ProjectionPairs9822
namespace Research.Graph9822.TwoDirect
open Research.SixH4.PairPartition
theorem wideClosedKept {x y : Fin 10} (h : (x,y) ∈ kept) : ¬ Nonempty (WideProjection x.val y.val) := by
  simp only [kept,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at h
  rcases h with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
  · exact WS01.closed
  · exact P02.wideClosed
  · exact P03.wideClosed
  · exact P06.wideClosed
  · exact P13.wideClosed
  · exact P14.wideClosed
  · exact P15.wideClosed
  · exact P17.wideClosed
  · exact WS23.closed
  · exact P24.wideClosed
  · exact P26.wideClosed
  · exact P28.wideClosed
  · exact P37.wideClosed
  · exact P45.wideClosed
  · exact P48.wideClosed
end Research.Graph9822.TwoDirect
#print axioms Research.Graph9822.TwoDirect.wideClosedKept
