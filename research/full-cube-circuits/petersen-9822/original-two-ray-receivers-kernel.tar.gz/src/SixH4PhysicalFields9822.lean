import SignedChronologicalAxes9822
import SixH4TenReturn9822
import And9822ScanPinched
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822
open TraceCount (activation sampleMask)
def packFields (f : Fin 64 → Bool) : BitVec 64 :=
  (BitVec.ofBoolListLE (List.ofFn f)).cast (by simp)
theorem packFields_bit (f : Fin 64 → Bool) (w : Fin 64) :
    (packFields f).getLsbD w.val=f w := by
  unfold packFields
  rw [BitVec.getLsbD_cast,BitVec.getLsbD_ofBoolListLE,List.getD_eq_getElem?_getD,List.getElem?_ofFn,dif_pos w.isLt]
  rfl

def field : List (Axis × Mask) → Axis → Mask
  | [],_=>∅
  | a::p,j=>if a.1=j then a.2 else field p j

theorem field_at (p : List (Axis × Mask)) (unique : (p.map Prod.fst).Nodup)
    (s : Axis × Mask) (inside : s∈p) : field p s.1=s.2 := by
  induction p with
  | nil => simp at inside
  | cons a p ih =>
    obtain ⟨free,nd⟩ := List.nodup_cons.mp unique
    rcases List.mem_cons.mp inside with rfl|ht
    · simp [field]
    · have ne : a.1≠s.1 := by
        intro eq
        exact free (List.mem_map.mpr ⟨s,ht,eq.symm⟩)
      simp [field,ne,ih nd ht]

noncomputable def fieldsProfile (p : List (Axis × Mask)) : TraceCount.Profile :=
  fun j=>(packFields (sampleMask (field p j))).toNat

theorem fields_code (p : List (Axis × Mask)) (j : Axis) :
    sampleMask (field p j)=activation (fieldsProfile p) j := by
  funext d
  exact (packFields_bit (sampleMask (field p j)) d).symm

theorem every_code (p : List (Axis × Mask)) (nd : (p.map Prod.fst).Nodup)
    (s : Axis × Mask) (h : s∈p) : sampleMask s.2=activation (fieldsProfile p) s.1 := by
  rw [←fields_code,field_at p nd s h]

theorem chrono_unique (k : Nat) (small : k≤6) :
    (((List.range k).map (Fin.ofNat 6)).reverse).Nodup := by
  interval_cases k <;> decide

theorem tags_real (events : List Event) (st : ReverseState) :
    ((events.foldl next st).switches.map Prod.fst)=
      (events.flatMap axisTags).reverse ++ st.switches.map Prod.fst := by
  induction events generalizing st with
  | nil => simp
  | cons e es ih =>
    simp only [List.foldl_cons,ih,List.flatMap_cons,List.reverse_append,List.append_assoc]
    congr 1
    cases e <;> simp [next,axisTags]

theorem active_sub (es : List Event) (st : ReverseState) : (activeEvents es st).Sublist es := by
  induction es generalizing st with
  | nil => exact .slnil
  | cons e es ih =>
    simp only [activeEvents]
    split
    · exact (ih st).cons e
    · exact (ih (next st e)).cons₂ e

theorem active_chrono_unique (gs : List DGate) (out : Nat) (cap : gs.countP Gate.isAnd≤6) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le cap)
    let es := gateEvents axis gs 10 ++ rawEvents 10
    let st := (activeEvents es (initial out)).foldl next (initial out)
    (st.switches.map Prod.fst).Nodup := by
  intro axis es st
  have rawtags (i : Nat) : (rawEvents i).flatMap axisTags=[] := by
    induction i with
    | zero => rfl
    | succ i ih => simpa [rawEvents,axisTags] using ih
  have full : (es.flatMap axisTags).reverse =
       ((List.range (gs.countP Gate.isAnd)).map (Fin.ofNat 6)).reverse := by
    simp [es,axis,List.flatMap_append,signed_gate_tags,rawtags]
  have sub := ((active_sub es (initial out)).flatMap axisTags).reverse
  change (((activeEvents es (initial out)).foldl next (initial out)).switches.map Prod.fst).Nodup
  rw [tags_real]
  simp only [initial,List.map_nil,List.append_nil]
  apply List.Nodup.sublist sub
  rw [full]
  exact chrono_unique _ cap

end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.active_chrono_unique
