import TenRawSchedule
import CutGroupRoom
import FourSaturationData
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution
open PEqualNP.Outside.L_meta_9822.Sectors
open Research.Graph9822

def rawBase (m : Nat) : List Nat := (List.range 10).filter m.testBit
theorem inputSet_spec (xs : List Nat) (j : Nat) :
    inputSet xs j = decide (j ∈ xs) := by
  induction xs with
  | nil => simp [inputSet]
  | cons a xs ih => simp [inputSet,wireUnion,ih,List.mem_cons]

theorem rawset_wire (xs : List Nat) (h : ∀ j∈xs, j < 10) :
    inputSet xs = wiresFrom (List.ofFn fun k : Fin 10 => decide (k.val ∈ xs)) := by
  funext j
  rw [inputSet_spec]
  by_cases hj : j < 10
  · exact (PEqualNP.Outside.L_meta_9822.Clean.getD_ofFn 10 (fun k : Fin 10 => decide (k.val ∈ xs)) false ⟨j,hj⟩).symm
  · have no : j ∉ xs := fun hit => hj (h j hit)
    simp [wiresFrom,List.getD_eq_getElem?_getD,List.getElem?_ofFn,hj,no]

theorem base_probes : FourSaturation.witnesses.all (fun m =>
    !(edge (fun k => decide (k.val ∈ rawBase m))) &&
    (List.finRange 10).all fun a =>
      decide (a.val ∈ rawBase m) || edge (fun k => decide (k.val ∈ a.val::rawBase m))) = true := by
  decide +kernel

def tenR (axis : Nat → Axis) (gs : List DGate) (out : Nat) (v : Fin 10) : Mask :=
  collect ((back axis gs 10 (initial out)).q v.val)

theorem ten_realizes (gs : List DGate) (out : Nat) (cap : gs.countP Gate.isAnd ≤ 6)
    (h : ∀ x : Fin 10 → Bool, eval gs 10 (wiresFrom (List.ofFn x)) out = edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le cap)
    ∀ m ∈ FourSaturation.witnesses, ∃ w : Word,
      ∀ v : Fin 10, w ∈ tenR axis gs out v ↔ m.testBit v.val=false := by
  intro axis m hm
  have facts := Bool.and_eq_true_iff.mp (List.all_eq_true.mp base_probes m hm)
  have lim : ∀ j∈rawBase m, j < 10 := fun j hj =>
    List.mem_range.mp (List.mem_filter.mp hj).1
  obtain ⟨w,hw⟩ := physical_room_row gs 10 out cap (fun a => a < 10) (rawBase m)
    (fun _ => rawBase m) (by rw [rawset_wire _ lim,h]; simpa using facts.1)
    (by intro a ha hn
        have t := List.all_eq_true.mp facts.2 (⟨a,ha⟩ : Fin 10) (by simp)
        rw [rawset_wire _ (by intro j hj; rcases List.mem_cons.mp hj with rfl|hh; exact ha; exact lim j hh),h]
        simpa [hn] using t)
    (by simp)
  exact ⟨w,fun v => by simpa [tenR,rawBase,v.isLt] using hw v.val v.isLt v.isLt⟩
end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.ten_realizes
