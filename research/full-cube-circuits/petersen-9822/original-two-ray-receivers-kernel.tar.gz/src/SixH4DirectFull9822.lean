import SixH4DirectCover9822
namespace Research.SixH4.DirectLiteral
theorem forced_fallback (P : Fin 6 → Set Word) (i : Fin 6) (s : Bool)
    {r : Set Word} {a b : Fin 6} {t u : Bool} (diff : a ≠ b)
    (recipe : r = ray P a t ∪ ray P b u)
    (covers : ray P i s ∪ r = Set.univ) :
    ∃ k z, r = ray P i (!s) ∪ ray P k z := by
  have sidecov : side i (!s) ⊆ side a t ∪ side b u := by
    intro q h
    have all : q ∈ ray P i s ∪ r := covers.symm ▸ Set.mem_univ q
    rcases all with primary | other
    · have p := primary.2
      change q i = s at p
      change q i = !s at h
      cases s <;> simp_all
    · rw [recipe] at other
      exact other.elim (fun z => Or.inl z.2) (fun z => Or.inr z.2)
  rcases half_forces diff sidecov with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
  · exact ⟨b,u,recipe⟩
  · exact ⟨a,t,recipe.trans (Set.union_comm _ _)⟩

theorem direct_full (P : Fin 6 → Set Word) (i : Fin 6) (s : Bool)
    (unlessFull : P i ≠ Set.univ → ∃ k u, P i = ray P k u)
    (r₁ r₂ : Set Word) (distinct : r₁ ≠ r₂)
    (c₁ : ray P i s ∪ r₁ = Set.univ) (c₂ : ray P i s ∪ r₂ = Set.univ)
    (f₁ : ∃ j t, r₁ = ray P i (!s) ∪ ray P j t)
    (f₂ : ∃ j t, r₂ = ray P i (!s) ∪ ray P j t) : P i = Set.univ := by
  by_contra small
  obtain ⟨k,u,narrow⟩ := unlessFull small
  have force {r : Set Word} {j : Fin 6} {t : Bool}
      (c : ray P i s ∪ r = Set.univ) (f : r = ray P i (!s) ∪ ray P j t) :
      side k (!u) ⊆ ray P j t := by
    intro q h
    have no : q ∉ P i := by
      intro yes
      rw [narrow] at yes
      have p := yes.2
      change q k = u at p
      change q k = !u at h
      cases u <;> simp_all
    have all : q ∈ ray P i s ∪ r := c.symm ▸ Set.mem_univ q
    rcases all with a | b
    · exact False.elim (no a.1)
    · rw [f] at b
      exact b.elim (fun z => False.elim (no z.1)) id
  obtain ⟨j,t,f⟩ := f₁
  obtain ⟨l,v,g⟩ := f₂
  exact distinct (by rw [f,g,fallback_equal (force c₁ f) (force c₂ g)])
end Research.SixH4.DirectLiteral
