import SixH4ProjectionOpposed9822
import SixH4TwoDirectPair9822
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822Profiles.Fresh
abbrev DLit := Research.SixH4.DirectLiteral.Lit
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
structure RootLabels (P : Axis6 → Mask6) (R : Fin 10 → Mask6) where
  x : Fin 10
  y : Fin 10
  lt : x < y
  a : DLit
  b : DLit
  axes : a.1 ≠ b.1
  L : Fin 10 → List DLit
  xlab : L x=[a]
  ylab : L y=[b]
  pair : ∀ v, v ≠ x → v ≠ y → ∃ c d : DLit, c.1 ≠ d.1 ∧ L v=[c,d]
  meaning : ∀ v q, q ∈ R v ↔ Research.SixH4.DirectLiteral.receives P (L v) q
  rx : R x=ray P a.1 a.2
  ry : R y=ray P b.1 b.2
theorem root_labels (P : Axis6 → Mask6) (R : Fin 10 → Mask6)
    (d : ((Finset.univ : Finset (Fin 10)).filter (fun v => RayValue P (R v))).card=2)
    (other : ∀ v, ¬ RayValue P (R v) → DistinctPair P (R v))
    (separate : Function.Injective R) (overlap : ∀ v w, ∃ q, q ∈ R v ∧ q ∈ R w) :
    Nonempty (RootLabels P R) := by
  classical
  obtain ⟨u,v,ne,eq⟩ := Finset.card_eq_two.mp d
  have roots : ∃ x y : Fin 10, x<y ∧ (∀ k, RayValue P (R k) ↔ k=x ∨ k=y) := by
    have both (k : Fin 10) : RayValue P (R k) ↔ k=u ∨ k=v := by
      have e := Finset.ext_iff.mp eq k
      simpa using e
    rcases lt_or_gt_of_ne ne with l|l
    · exact ⟨u,v,l,both⟩
    · exact ⟨v,u,l,fun k => (both k).trans or_comm⟩
  obtain ⟨x,y,lt,hr⟩ := roots
  obtain ⟨i,s,rx⟩ := (hr x).mpr (Or.inl rfl)
  obtain ⟨j,t,ry⟩ := (hr y).mpr (Or.inr rfl)
  have ij : i ≠ j := by
    intro e
    subst j
    obtain ⟨q,h,k⟩ := overlap x y
    rw [rx] at h
    rw [ry] at k
    have st := h.2.symm.trans k.2
    exact lt.ne (separate (rx.trans ((congrArg (ray P i) st).trans ry.symm)))
  have desc (v : Fin 10) (hx : v ≠ x) (hy : v ≠ y) :
      ∃ c d : DLit, c.1 ≠ d.1 ∧ R v=ray P c.1 c.2 ∪ ray P d.1 d.2 := by
    obtain ⟨a,as',b,bs,ne,m⟩ := other v (fun h => ((hr v).mp h).elim hx hy)
    exact ⟨(a,as'),(b,bs),ne,m⟩
  let L (v : Fin 10) : List DLit :=
    if hx : v=x then [(i,s)] else if hy : v=y then [(j,t)] else
    [(desc v hx hy).choose,(desc v hx hy).choose_spec.choose]
  refine ⟨⟨x,y,lt,(i,s),(j,t),ij,L,by simp [L],by simp [L,lt.ne.symm],?_,?_,rx,ry⟩⟩
  · intro v hx hy
    exact ⟨_,_,(desc v hx hy).choose_spec.choose_spec.1,by simp [L,hx,hy]⟩
  · intro v q
    by_cases hx : v=x
    · subst v
      simp [L,Research.SixH4.DirectLiteral.receives,rx,ray,Research.SixH4.DirectLiteral.ray,side,Research.SixH4.DirectLiteral.side]
    by_cases hy : v=y
    · subst v
      simp [L,hx,Research.SixH4.DirectLiteral.receives,ry,ray,Research.SixH4.DirectLiteral.ray,side,Research.SixH4.DirectLiteral.side]
    rw [(desc v hx hy).choose_spec.choose_spec.2]
    simp [L,hx,hy,Research.SixH4.DirectLiteral.receives,ray,Research.SixH4.DirectLiteral.ray,side,Research.SixH4.DirectLiteral.side]
end
end Research.Graph9822.ArbitraryScan
