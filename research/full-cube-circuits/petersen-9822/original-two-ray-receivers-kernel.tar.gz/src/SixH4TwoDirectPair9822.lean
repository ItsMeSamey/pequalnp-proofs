import SixH4FreshPair9822
import And9822CommonScan
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822Profiles.Fresh Graph9822.CommonBank
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
theorem two_nonsibling {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (ok : ∀ a ∈ p, a.2 = P a.1) (R : Fin 10 → Mask6) (returned : ∀ v, R v ∈ l)
    (proper : ∀ v, ∃ q, q ∉ R v) (inc : ∀ u v, u ≠ v → ¬ R u ⊆ R v)
    (budget : n ≤ 8) (d : ((Finset.univ : Finset (Fin 10)).filter
      (fun v => RayValue P (R v))).card = 2) :
    ∀ v, ¬RayValue P (R v) → DistinctPair P (R v) := by
  classical
  let ND := (Finset.univ : Finset (Fin 10)).filter (fun v => ¬ RayValue P (R v))
  let N := ND.image R
  have inj : Function.Injective R := by
    intro a c eq
    by_contra ne
    exact inc a c ne (by rw [eq])
  have defN (m : Mask6) : m ∈ N ↔ ∃ v, R v = m ∧ ¬RayValue P m := by
    simp only [N,ND,Finset.mem_image,Finset.mem_filter,Finset.mem_univ,true_and]
    constructor
    · rintro ⟨v,h,rfl⟩; exact ⟨v,rfl,h⟩
    · rintro ⟨v,rfl,h⟩; exact ⟨v,h,rfl⟩
  have sum := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset (Fin 10)))
    (fun v => RayValue P (R v))
  change _ + ND.card = _ at sum
  rw [d,Finset.card_univ,Fintype.card_fin] at sum
  have card : N.card = 8 := by rw [Finset.card_image_of_injective _ inj]; omega
  have coverage : hits N l = N := by
    ext m
    constructor
    · exact fun h => (Finset.mem_inter.mp h).1
    · intro h
      obtain ⟨v,eq,_⟩ := (defN m).mp h
      exact Finset.mem_inter.mpr ⟨h,List.mem_toFinset.mpr (eq ▸ returned v)⟩
  have top : Set.univ ∉ N := by
    intro h
    obtain ⟨v,eq,_⟩ := (defN _).mp h
    obtain ⟨q,miss⟩ := proper v
    exact miss (by rw [eq]; trivial)
  have none (i : Axis) (s : Bool) : P i ∩ side i s ∉ N := by
    intro h
    exact ((defN _).mp h).choose_spec.2 ⟨i,s,rfl⟩
  have ant : ∀ a ∈ N, ∀ c ∈ N, a ⊆ c → a = c := by
    intro a ha c hc sub
    obtain ⟨v,rfl,_⟩ := (defN a).mp ha
    obtain ⟨u,rfl,_⟩ := (defN c).mp hc
    by_cases eq : v = u
    · rw [eq]
    · exact False.elim (inc v u eq sub)
  obtain ⟨lb,mk⟩ := exact_count scan N top (fun t ht s => by rw [ok t ht]; exact none _ _)
  have paid := mk (by rw [coverage,card] at lb ⊢; omega)
  intro v hn
  exact paid_pair paid P ok ant top none (R v) (returned v) ((defN _).mpr ⟨v,rfl,hn⟩)
end
end Research.Graph9822.ArbitraryScan
