import SixH4OriginalDirectFull9822
import SixH4FreshPositive9822
import SixH4D2OriginalBank9822
import SixH4DirectRoots9822
import SixH4TwoDirectOrigins9822
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822 Research.Graph9822.ArbitraryScan
open PEqualNP.Outside.L_meta_9822.Sectors PEqualNP.Outside.L_meta_9822.Receivers
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
structure D2Data (P : Axis → Mask) (R : Fin 10 → Mask) where
  labels : RootLabels P R
  full : ∀ v i s, R v = ray P i s → P i = Set.univ
  origins : ∀ i, P i=Set.univ ∨ (∃ k s, k≠i ∧ P i=ray P k s) ∨
    (∃ v, ¬RayValue P (R v) ∧ P i=R v)
  real : ExactReceivers (fun v q=>q∈R v)
  cover : ∀ u v, rawEdge u v=true → ∀ q, q∈R u ∨ q∈R v
theorem original_d2_data (gs : List DGate) (out : Nat) (size : gs.length≤17)
    (ok : WellWired gs 10) (ob : out<10+gs.length) (six : gs.countP Gate.isAnd=6)
    (computes : ∀ x : Fin 10 → Bool,(asCircuit gs out).eval (List.ofFn x)=edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le six.le)
    let p := ((gateEvents axis gs 10 ++ rawEvents 10).foldl paddedStep (initial out)).switches
    let R := tenR axis gs out
    let P := field p
    ((Finset.univ : Finset (Fin 10)).filter (fun v=>RayValue P (R v))).card=2 →
      Nonempty (D2Data P R) := by
  classical
  intro axis p R P d
  obtain ⟨names,origin,_⟩ := physical_d2_bank gs out size ok ob six computes d
  obtain ⟨pair,full⟩ := physical_d2_full_and_pairs gs out size ok ob six computes d
  obtain ⟨_,_,_,_,⟨l,scan,_⟩,_,_⟩ := padded_profile_rows gs out size ok ob six.le computes
  have h : ∀ x : Fin 10 → Bool,eval gs 10 (wiresFrom (List.ofFn x)) out=edge x := by
    intro x
    simpa only [physical_eval,List.length_ofFn] using computes x
  obtain ⟨real,sep,both,cover⟩ := physical_receiver_facts gs out six.le h
  have inj : Function.Injective R := by
    intro v u eq
    by_contra ne
    obtain ⟨q,yes,no⟩ := sep v u ne
    apply no
    change q ∈ R u
    rw [←eq]
    exact yes
  obtain ⟨labels⟩ := root_labels P R d pair inj both
  refine ⟨⟨labels,full,?_,real,fun u v e => (cover u v).mp e⟩⟩
  intro i
  by_cases top : P i=Set.univ
  · exact Or.inl top
  right
  obtain ⟨m,mem⟩ := names.2 i
  have eq : P i=m := field_at p names.1 (i,m) mem
  have site : (i,P i) ∈ p := eq.symm ▸ mem
  exact different_origin (Fresh.switch_stable scan names.1 (i,P i) site)
    ((Fresh.scan_positive scan names.1).2 (i,P i) site) top (origin i)
end
end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.original_d2_data
