import SixH4FreshCausal9822
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
theorem scan_positive {b l p n} (scan : Scan b l p n) (unique : (p.map Prod.fst).Nodup) :
    (∀ m ∈ l, m.Nonempty) ∧ (∀ t ∈ p, t.2.Nonempty) := by
  induction scan with
  | start => simp
  | @join b l p n x y h hx hy ih =>
    have prev := ih unique
    refine ⟨?_,prev.2⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl | old
    · obtain ⟨q,hq⟩ := prev.1 x hx
      exact ⟨q,Or.inl hq⟩
    · exact prev.1 m old
  | @split b l p n u i h hu ih =>
    obtain ⟨unused,nodup⟩ := List.nodup_cons.mp unique
    have prev := ih nodup
    have stable := unissued h unused u hu
    obtain ⟨q,hq⟩ := prev.1 u hu
    have arm (s : Bool) : (u ∩ side i s).Nonempty :=
      ⟨setBit i s q,stable q s hq,by simp [setBit,side]⟩
    constructor
    · intro m hm
      rcases List.mem_cons.mp hm with rfl | rest
      · exact arm true
      rcases List.mem_cons.mp rest with rfl | rest
      · exact arm false
      exact prev.1 m rest
    · intro t ht
      rcases List.mem_cons.mp ht with rfl | old
      · exact ⟨q,hq⟩
      · exact prev.2 t old
end Research.Graph9822Profiles.Fresh
