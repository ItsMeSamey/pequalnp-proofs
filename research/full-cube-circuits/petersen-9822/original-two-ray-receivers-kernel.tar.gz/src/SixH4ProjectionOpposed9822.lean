import SixH4DirectLiteral9822
namespace Research.SixH4.DirectLiteral
abbrev Lit := Fin 6 × Bool
def consistent (L : List Lit) := ∀ i, ¬ ((i,false) ∈ L ∧ (i,true) ∈ L)
def opposing (L K : List Lit) := ∃ i s, (i,s) ∈ L ∧ (i,!s) ∈ K
def receives (A : Fin 6 → Set Word) (L : List Lit) (q : Word) :=
  ∃ t ∈ L, q ∈ ray A t.1 t.2

theorem single_consistent (a : Lit) : consistent [a] := by
  rintro i ⟨h,k⟩
  simp only [List.mem_singleton] at h k
  have eq := congrArg Prod.snd (h.trans k.symm)
  contradiction

theorem pair_consistent (a b : Lit) (axes : a.1 ≠ b.1) : consistent [a,b] := by
  rintro i ⟨h,k⟩
  have unpack (v : Lit) : v ∈ [a,b] ↔ v=a ∨ v=b := by simp
  rcases (unpack _).1 h with h|h <;> rcases (unpack _).1 k with k|k
  · have e := congrArg Prod.snd (h.trans k.symm)
    contradiction
  · have ha : i = a.1 := congrArg Prod.fst h
    have hb : i = b.1 := congrArg Prod.fst k
    exact axes (ha.symm.trans hb)
  · have ha : i = a.1 := congrArg Prod.fst k
    have hb : i = b.1 := congrArg Prod.fst h
    exact axes (ha.symm.trans hb)
  · have e := congrArg Prod.snd (h.trans k.symm)
    contradiction

theorem edge_opposing {A : Fin 6 → Set Word} {L K : List Lit}
    (hl : consistent L) (hk : consistent K)
    (cover : ∀ q, receives A L q ∨ receives A K q) : opposing L K := by
  classical
  by_contra bad
  have both : consistent (L ++ K) := by
    rintro i ⟨f,t⟩
    rw [List.mem_append] at f t
    rcases f with f|f <;> rcases t with t|t
    · exact hl i ⟨f,t⟩
    · exact bad ⟨i,false,f,t⟩
    · exact bad ⟨i,true,t,f⟩
    · exact hk i ⟨f,t⟩
  let q : Word := fun i => decide ((i,false) ∈ L ++ K)
  have misses (a : Lit) (ha : a ∈ L ++ K) : q ∉ ray A a.1 a.2 := by
    rintro ⟨_,sideHit⟩
    obtain ⟨i,s⟩ := a
    change decide ((i,false) ∈ L ++ K) = s at sideHit
    cases s with
    | false => simpa [ha] using sideHit
    | true => exact both i ⟨of_decide_eq_true sideHit,ha⟩
  rcases cover q with ⟨a,ha,hit⟩|⟨a,ha,hit⟩
  · exact misses a (List.mem_append.mpr (Or.inl ha)) hit
  · exact misses a (List.mem_append.mpr (Or.inr ha)) hit
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.edge_opposing
