import SixH4FreshCausal9822
import SixH4TwoDirectBank9822
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822Profiles.Fresh
theorem different_origin {P : Axis6 → Mask6} {R : Fin 10 → Mask6} {j : Axis6}
    (stable : Stable (P j) j) (live : ∃ q, q ∈ P j) (hidden : P j ≠ Set.univ)
    (source : Primitive P (P j) ∨ ∃ v, R v = P j) :
    (∃ k s, k ≠ j ∧ P j = ray P k s) ∨ (∃ v, ¬ RayValue P (R v) ∧ P j = R v) := by
  classical
  have distinct {k s} (eq : P j = ray P k s) : k ≠ j := by
    intro same
    subst k
    obtain ⟨q,yes,miss⟩ := straddles stable s live
    exact miss (((eq ▸ yes) : q ∈ ray P j s).2)
  rcases source with (top | ⟨k,s,eq⟩) | ⟨v,eq⟩
  · exact False.elim (hidden top)
  · exact Or.inl ⟨k,s,distinct eq,eq⟩
  · by_cases direct : RayValue P (R v)
    · obtain ⟨k,s,h⟩ := direct
      exact Or.inl ⟨k,s,distinct (eq.symm.trans h),eq.symm.trans h⟩
    · exact Or.inr ⟨v,direct,eq.symm⟩
end Research.Graph9822.ArbitraryScan
