import SixH4WideOrbitCase4Data9822
namespace Research.Graph9822.TwoDirect.Orbit01
open PEqualNP.Library.LRAT
set_option maxRecDepth 50000
set_option maxHeartbeats 0
def block4x0 := rules4Part0.zip numericPart0
theorem good4x0 : block4x0.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x0 : block4x0.map Prod.snd = numericPart0 := List.map_snd_zip (by decide +kernel)
def block4x1 := rules4Part1.zip numericPart1
theorem good4x1 : block4x1.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x1 : block4x1.map Prod.snd = numericPart1 := List.map_snd_zip (by decide +kernel)
def block4x2 := rules4Part2.zip numericPart2
theorem good4x2 : block4x2.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x2 : block4x2.map Prod.snd = numericPart2 := List.map_snd_zip (by decide +kernel)
def block4x3 := rules4Part3.zip numericPart3
theorem good4x3 : block4x3.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x3 : block4x3.map Prod.snd = numericPart3 := List.map_snd_zip (by decide +kernel)
def block4x4 := rules4Part4.zip numericPart4
theorem good4x4 : block4x4.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x4 : block4x4.map Prod.snd = numericPart4 := List.map_snd_zip (by decide +kernel)
def block4x5 := rules4Part5.zip numericPart5
theorem good4x5 : block4x5.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x5 : block4x5.map Prod.snd = numericPart5 := List.map_snd_zip (by decide +kernel)
def block4x6 := rules4Part6.zip numericPart6
theorem good4x6 : block4x6.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x6 : block4x6.map Prod.snd = numericPart6 := List.map_snd_zip (by decide +kernel)
def block4x7 := rules4Part7.zip numericPart7
theorem good4x7 : block4x7.all (guardSupported 0 1 4 [1,4] atoms4.toArray) = true := by decide +kernel
theorem eq4x7 : block4x7.map Prod.snd = numericPart7 := List.map_snd_zip (by decide +kernel)
end Research.Graph9822.TwoDirect.Orbit01
