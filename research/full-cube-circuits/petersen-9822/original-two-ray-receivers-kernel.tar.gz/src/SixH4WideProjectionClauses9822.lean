import SixH4ProjectionClauses9822
import SixH4WideProjectedModel9822
namespace Research.Graph9822.TwoDirect
def Atom.wideVal (p : WideProjection x y) : Atom → Bool
  | .ray k m => p.ray k m
  | .raw v t => decide (p.raw v = t)
  | .origin j o => decide (p.origin j = o)
def WideSat (p : WideProjection x y) (c : Clause) := ∃ l ∈ c, l.1.wideVal p = l.2
def Rule.wideOK (x y : Nat) : Rule → Bool
  | .originSome j => decide (2 ≤ j) && decide (j < 6)
  | .act j o m mode => decide (2 ≤ j) && decide (j < 6) && rooms.contains m &&
      decide (mode < 3) && (if o = 22 then decide (mode = 2) else
          decide (o < 12) || (decide (mode = 2) == rawBit (o-12) m))
  | r => r.ok x y
def Rule.wideClause (x y : Nat) : Rule → Clause
  | .originSome j => (wideOrigins x y j).map (fun o => pos (.origin j o))
  | r => r.clause x y
theorem Rule.wideSound (p : WideProjection x y) (r : Rule) (hr : r.wideOK x y = true) : WideSat p (r.wideClause x y) := by
  cases r with
  | rawSome v =>
    exact ⟨_,List.mem_map.mpr ⟨p.raw v,p.selected v (of_decide_eq_true hr),rfl⟩,by simp [pos,Atom.wideVal]⟩
  | originSome j =>
    simp only [Rule.wideOK,Rule.ok,Bool.and_eq_true,decide_eq_true_eq] at hr
    exact ⟨_,List.mem_map.mpr ⟨p.origin j,p.named j hr.1 hr.2,rfl⟩,by simp [pos,Atom.wideVal]⟩
  | rawOn v m t =>
    simp only [Rule.wideOK,Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at hr
    by_cases h : p.raw v = t
    · have hrow := p.rawRows v hr.1.1 m hr.1.2
      rw [h,hr.2] at hrow
      obtain ⟨k,hk,hval⟩ := List.any_eq_true.mp hrow
      exact ⟨_,List.mem_cons_of_mem _ (List.mem_map.mpr ⟨k,hk,rfl⟩),hval⟩
    · exact ⟨_,List.mem_cons_self,by simp [neg,Atom.wideVal,h]⟩
  | rawOff v m t k =>
    simp only [Rule.wideOK,Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem,Bool.not_eq_true'] at hr
    by_cases h : p.raw v = t
    · have hrow := p.rawRows v hr.1.1.1 m hr.1.1.2
      rw [h,hr.1.2] at hrow
      have hf : p.ray k m = false := by
        cases hb : p.ray k m
        · rfl
        · have : (t.any (fun a => p.ray a m)) = true := List.any_eq_true.mpr ⟨k,hr.2,hb⟩
          simp_all
      exact ⟨neg (.ray k m),by simp [Rule.wideClause,Rule.clause],hf⟩
    · exact ⟨_,List.mem_cons_self,by simp [neg,Atom.wideVal,h]⟩
  | root k m =>
    simp only [Rule.wideOK,Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at hr
    refine ⟨_,List.mem_cons_self,?_⟩
    have h := hr.1
    have hm := hr.2
    match k with
    | 0 => exact p.side0 m hm
    | 1 => exact p.side1 m hm
    | 2 => exact p.side2 m hm
    | 3 => exact p.side3 m hm
    | n+4 => omega
  | cross u v a b =>
    simp only [Rule.wideOK,Rule.ok,Bool.and_eq_true,decide_eq_true_eq,Bool.not_eq_true'] at hr
    have h := p.opposed u v hr.1.1.1 hr.1.1.2 hr.1.2
    simp [WideSat, Rule.wideClause,Rule.clause,neg,Atom.wideVal]
    by_cases h1 : p.raw u = a <;> by_cases h2 : p.raw v = b <;> simp_all
  | disj j m =>
    simp only [Rule.wideOK,Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at hr
    have h := p.disjoint j hr.1.1 hr.1.2 m hr.2
    simp [WideSat, Rule.wideClause,Rule.clause,neg,Atom.wideVal]
    cases ha : p.ray (2*j) m <;> cases hb : p.ray (2*j+1) m <;> simp_all
  | act j o m mode =>
    simp only [Rule.wideOK,Rule.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at hr
    have h := p.activation j hr.1.1.1.1 hr.1.1.1.2 m hr.1.1.2
    have lim := hr.1.2
    by_cases ho : p.origin j = o
    · rw [ho] at h
      by_cases isFull : o = 22
      · subst o
        have hm : mode = 2 := by simpa [isFull] using hr.2
        subst mode
        cases ha : p.ray (2*j) m <;> cases hb : p.ray (2*j+1) m <;>
          simp_all [WideSat,Rule.wideClause,Rule.clause,pos,neg,Atom.wideVal]
      simp only [isFull,if_false] at h hr
      have hm : mode = 0 ∨ mode = 1 ∨ mode = 2 := by omega
      rcases hm with rfl|rfl|rfl <;> by_cases isRay : o < 12 <;>
        cases ha : p.ray (2*j) m <;> cases hb : p.ray (2*j+1) m <;>
        simp_all [WideSat,Rule.wideClause,Rule.clause,pos,neg,Atom.wideVal]
    · refine ⟨neg (.origin j o),?_,by simp [neg,Atom.wideVal,ho]⟩
      simp only [Rule.wideClause,Rule.clause]
      split <;> simp
end Research.Graph9822.TwoDirect
