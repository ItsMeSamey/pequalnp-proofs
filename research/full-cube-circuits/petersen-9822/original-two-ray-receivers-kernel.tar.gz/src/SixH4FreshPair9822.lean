import SixH4FreshSources9822
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
def DistinctPair (P : Axis → Mask) (m : Mask) : Prop :=
  ∃ i s j t, i ≠ j ∧ m = (P i ∩ side i s) ∪ (P j ∩ side j t)
theorem paid_pair {N b l p n} (h : Paid N b l p n) (P : Axis → Mask)
    (ok : ∀ a ∈ p, a.2 = P a.1)
    (anti : ∀ a ∈ N, ∀ d ∈ N, a ⊆ d → a = d)
    (top : Set.univ ∉ N) (no : ∀ i s, P i ∩ side i s ∉ N) :
    ∀ m ∈ l, m ∈ N → DistinctPair P m := by
  induction h with
  | start => simp [top]
  | @split b l p n u i h hu ih =>
    have ui := ok (i,u) (by simp)
    change u = P i at ui
    intro m hm hn
    rcases List.mem_cons.mp hm with rfl | tail
    · exact False.elim (no i true (ui ▸ hn))
    rcases List.mem_cons.mp tail with rfl | tail
    · exact False.elim (no i false (ui ▸ hn))
    exact ih (fun a ha => ok a (List.mem_cons_of_mem _ ha)) m tail hn
  | @join b l p n x y h hx hy used fresh ih =>
    intro m hm hn
    rcases List.mem_cons.mp hm with rfl | old
    · have src := paid_sources h
      have operand (a : Mask) (ha : a ∈ l) (sub : a ⊆ x ∪ y) : Origin p a := by
        rcases src.1 a ha with full | raw | org
        · have e : x ∪ y = Set.univ := Set.eq_univ_of_forall (fun q => sub (by rw [full]; exact Set.mem_univ q))
          exact False.elim (top (e ▸ used))
        · exact False.elim (fresh ((anti a raw _ used sub) ▸ ha))
        · exact org
      obtain ⟨i,a,ha,s,ex⟩ := operand x hx (fun _ z => Or.inl z)
      obtain ⟨j,d,hd,t,ey⟩ := operand y hy (fun _ z => Or.inr z)
      have ai := ok (i,a) ha
      have dj := ok (j,d) hd
      change a = P i at ai
      change d = P j at dj
      refine ⟨i,s,j,t,?_,by rw [ex,ey,ai,dj]⟩
      intro eq
      subst j
      rw [dj,←ai] at ey
      have prior := src.2 (i,a) ha
      change a ∈ l at prior
      by_cases same : s = t
      · subst t
        apply fresh
        simpa [ex,ey] using hx
      · have united : x ∪ y = a := by
          rw [ex,ey]
          ext q
          change ((q ∈ a ∧ q i = s) ∨ (q ∈ a ∧ q i = t)) ↔ q ∈ a
          cases s <;> cases t <;> cases q i <;> simp_all
        exact fresh (united.symm ▸ prior)
    · exact ih ok m old hn
end Research.Graph9822Profiles.Fresh
