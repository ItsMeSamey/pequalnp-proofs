import SixH4OriginalD2Data9822
import SixH4ProjectionSelection9822
import SixWideD2MaskProjection9822
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822 Research.Graph9822.ArbitraryScan
open Research.SixH4.DirectLiteral Research.SixH4.PairPartition Research.Graph9822.TwoDirect
open PEqualNP.Outside.L_meta_9822.Sectors
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
theorem wide_of_data {P : Axis → Mask} {R : Fin 10 → Mask} (data : D2Data P R) :
    (data.labels.x,data.labels.y)∈kept ∧ Nonempty (WideProjection data.labels.x.val data.labels.y.val) := by
  classical
  let labels := data.labels
  have fa := data.full _ _ _ labels.rx
  have fb := data.full _ _ _ labels.ry
  have real := data.real
  have cov : ∀ u v, Research.SixH4.PairPartition.adj u v → ∀ q, q∈R u ∨ q∈R v := data.cover
  have bits : ∀ u : Fin 16, ∃ m ∈ Research.Graph9822.FourSaturation.witnesses,
      ∀ v : Fin 10, m.testBit v.val=false ↔ v.val∉independentSets u := by
    decide +kernel
  have rooms (u : Fin 16) : ∃ q,∀ v, receives P (labels.L v) q ↔ v.val∉independentSets u := by
    obtain ⟨m,hm,truth⟩ := bits u
    obtain ⟨q,hq⟩ := real.realize m hm
    exact (show ∃ q,∀ v, receives P (labels.L v) q ↔ v.val∉independentSets u from
      ⟨q,fun v => (labels.meaning _ _).symm.trans ((hq v).trans (truth v))⟩)
  have cover (i j : Fin 10) (e : Research.SixH4.PairPartition.adj i j) (q) :=
    (cov i j e q).imp (labels.meaning i q).mp (labels.meaning j q).mp
  obtain ⟨kept',sel,opp⟩ := selection labels.a labels.b P labels.L labels.lt labels.axes
    labels.xlab labels.ylab fa fb labels.pair cover rooms
  refine ⟨kept',wide_projection_from_literals P R _ _ labels.axes _ _ labels.L real
    labels.meaning sel opp fa fb labels.rx labels.ry ?_⟩
  intro i _ _
  rcases data.origins i with top | ray' | raw
  · exact Or.inl top
  · obtain ⟨k,s,ne,eq⟩ := ray'
    exact Or.inr (Or.inl ⟨(k,s),ne,eq⟩)
  · obtain ⟨v,nd,eq⟩ := raw
    exact Or.inr (Or.inr ⟨v,(fun h=>nd (h.symm ▸ ⟨_,_,labels.rx⟩)),
      (fun h=>nd (h.symm ▸ ⟨_,_,labels.ry⟩)),eq⟩)
theorem original_wide_projection (gs : List DGate) (out : Nat) (size : gs.length≤17)
    (ok : WellWired gs 10) (ob : out<10+gs.length) (six : gs.countP Gate.isAnd=6)
    (computes : ∀ x : Fin 10 → Bool,(asCircuit gs out).eval (List.ofFn x)=edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le six.le)
    let p := ((gateEvents axis gs 10 ++ rawEvents 10).foldl paddedStep (initial out)).switches
    let R := tenR axis gs out
    let P := field p
    ((Finset.univ : Finset (Fin 10)).filter (fun v=>RayValue P (R v))).card=2 →
      ∃ x y : Fin 10,x<y ∧ RayValue P (R x) ∧ RayValue P (R y) ∧
        (x,y)∈kept ∧ Nonempty (WideProjection x.val y.val) := by
  intro axis p R P d
  obtain ⟨data⟩ := original_d2_data gs out size ok ob six computes d
  exact ⟨data.labels.x,data.labels.y,data.labels.lt,⟨_,_,data.labels.rx⟩,⟨_,_,data.labels.ry⟩,wide_of_data data⟩
end
end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.original_wide_projection
