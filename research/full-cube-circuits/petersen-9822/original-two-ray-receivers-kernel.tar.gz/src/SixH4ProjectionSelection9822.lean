import SixH4ProjectionOpposesCode9822
namespace Research.SixH4.DirectLiteral
open Research.SixH4.PairPartition Research.Graph9822Resolution Research.Graph9822.TwoDirect
theorem separated_rooms : ∀ x v : V, x ≠ v → ∃ u : Fin 16,
    v.val ∈ independentSets u ∧ x.val ∉ independentSets u := by decide +kernel

theorem selection (a b : Lit) (A : Fin 6 → Set Word) (L : V → List Lit)
    {x y : V} (ord : x < y) (axes : a.1 ≠ b.1)
    (lx : L x=[a]) (ly : L y=[b]) (fx : A a.1=Set.univ) (fy : A b.1=Set.univ)
    (pair : ∀ v, v ≠ x → v ≠ y → ∃ c d : Lit, c.1 ≠ d.1 ∧ L v=[c,d])
    (cover : ∀ i j, adj i j → ∀ q, receives A (L i) q ∨ receives A (L j) q)
    (witness : ∀ u : Fin 16, ∃ q : Word, ∀ z : V,
      receives A (L z) q ↔ z.val ∉ independentSets u) :
    (x,y) ∈ kept ∧
    (∀ n, n<10 → normalized a b L n ∈ options x.val y.val n) ∧
    (∀ i j, i<j → j<10 → edge i j=true →
      opposes (normalized a b L i) (normalized a b L j)=true) := by
  have coherent (v : V) : consistent (L v) := by
    by_cases eq : v=x
    · rw [eq,lx]; exact single_consistent a
    by_cases eq' : v=y
    · rw [eq',ly]; exact single_consistent b
    obtain ⟨c,d,cd,l⟩ := pair v eq eq'
    rw [l]; exact pair_consistent c d cd
  have nonedge : ¬ adj x y := by
    intro e
    have ce := cover x y e
    rw [lx,ly] at ce
    have h := opposed_single (edge_opposing (single_consistent a) (single_consistent b) ce)
    have eq : opposite a = b := List.mem_singleton.mp h
    exact axes (show (opposite a).1 = b.1 from congrArg Prod.fst eq)
  have anti (r v : V) (ne : r ≠ v) :
      ¬ ({q | receives A (L r) q} : Set Word) ⊆ {q | receives A (L v) q} := by
    intro sub
    obtain ⟨u,vr,rr⟩ := separated_rooms r v ne
    obtain ⟨q,hq⟩ := witness u
    exact (hq v).1 (sub ((hq r).2 rr)) vr
  refine ⟨roster A L ord nonedge lx ly axes pair cover witness,?_,
    opposed a b A L coherent cover⟩
  apply selected a b L x y (ne_of_lt ord) axes lx ly pair
  intro v nx ny
  have symm_adj : ∀ i j : V, adj i j → adj j i := by decide +kernel
  have rx := root_membership A L lx fx (coherent v)
    (fun e=>cover x v (symm_adj _ _ e)) (anti x v nx.symm) witness
  have ry := root_membership A L ly fy (coherent v)
    (fun e=>cover y v (symm_adj _ _ e)) (anti y v ny.symm) witness
  exact ⟨rx.1,ry.1,rx.2,ry.2⟩
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.selection
