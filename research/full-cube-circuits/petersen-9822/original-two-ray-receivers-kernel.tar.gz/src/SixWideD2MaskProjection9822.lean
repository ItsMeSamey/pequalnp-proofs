import SixWideD2NormalizedOrigins9822
import SixWideD2ProjectionRows9822
namespace Research.SixH4.DirectLiteral
open Research.Graph9822.TwoDirect PEqualNP.Outside.L_meta_9822.Receivers
noncomputable section
private theorem wide_mate_full {P : Fin 6 → Set Word} (c : Lit) (full : P c.1=Set.univ)
    (w : Word) : w∈ray P (mate c).1 (mate c).2 ↔ w∉ray P c.1 c.2 := by
  change (w∈P c.1 ∧ w c.1= !c.2) ↔ ¬(w∈P c.1 ∧ w c.1=c.2)
  rw [full]
  cases c.2 <;> cases w c.1 <;> simp

theorem wide_projection_from_literals (P : Fin 6 → Set Word) (R : Fin 10 → Set Word)
    (a b : Lit) (ne : a.1≠b.1) (x y : Fin 10) (L : Fin 10 → List Lit)
    (real : ExactReceivers (fun v w => w∈R v)) (desc : ∀ v w,w∈R v ↔ receives P (L v) w)
    (sel : ∀ v,v<10 → normalized a b L v∈options x.val y.val v)
    (opp : ∀ u v,u<v → v<10 → edge u v=true →
       opposes (normalized a b L u) (normalized a b L v)=true)
    (fa : P a.1=Set.univ) (fb : P b.1=Set.univ)
    (rx : R x=ray P a.1 a.2) (ry : R y=ray P b.1 b.2)
    (src : ∀ i,2≤axisCode a b i → axisCode a b i<6 →
      P i=Set.univ ∨ (∃ d : Lit,d.1≠i ∧ P i=ray P d.1 d.2) ∨ (∃ v,v≠x ∧ v≠y ∧ P i=R v)) :
    Nonempty (WideProjection x.val y.val) := by
  obtain ⟨source,hs⟩ := wide_origins_from_masks P R a b ne x y src
  obtain ⟨ca,cb⟩ := code_root a b ne
  have ma : code a b (mate a)=1 := by rw [code_mate,ca]; decide
  have mb : code a b (mate b)=3 := by rw [code_mate,cb]; decide
  apply wide_projection_of_masks (codeMask P a b) real (normalized a b L) source sel
    (fun v w=>(desc v w).trans (numeric_desc P a b ne L v w)) opp
  · rw [←ca,mask_at P a b ne,rx]
  · intro w
    rw [←ma,mask_at P a b ne,rx]
    exact wide_mate_full a fa w
  · rw [←cb,mask_at P a b ne,ry]
  · intro w
    rw [←mb,mask_at P a b ne,ry]
    exact wide_mate_full b fb w
  · intro j _ hi
    obtain ⟨_,_,_,dis⟩ := slot_semantics P a b ne ⟨j,hi⟩
    exact dis
  · intro j lo hi
    simpa [wideOrigins] using (hs j lo hi).1
  · exact fun j lo hi=>(hs j lo hi).2.1
  · exact fun j lo hi=>(hs j lo hi).2.2
end
end Research.SixH4.DirectLiteral
#print axioms Research.SixH4.DirectLiteral.wide_projection_from_literals
