"""Enumerate first-H sources only within necessary four-center demands."""
from itertools import combinations,product
from collections import Counter
from replay_h2 import E,hits,neg,free,covers,trace,union
V=range(10)
N=[union(e^(1<<v) for e in E if e>>v&1) for v in V]
counts=Counter()
def submasks(s):
    original=s
    while s:
        yield s
        s=(s-1)&original
for C in combinations(V,4):
    T=8191^union(hits[1<<v] for v in C)
    assert T
    sols=set()
    counts['centers']+=1
    for x in covers(T):
        F=neg[x]
        for a0,b0 in combinations(covers(T),2):
            counts['seed_trials']+=1
            if a0&b0 or F&neg[a0]&neg[b0]:continue
            counts['seeds']+=1
            optionsA=free[F&neg[b0]] & ~(a0|b0)
            optionsB=free[F&neg[a0]] & ~(a0|b0)
            for da,db in product([0,*submasks(optionsA)],[0,*submasks(optionsB)]):
                counts['extensions']+=1
                a,b=a0|da,b0|db
                if a&b or F&neg[a]&neg[b]:continue
                sols.add(trace[a]&trace[b])
    if sols: counts['C_unfiltered']+=1
    for h in sols:
        he=h&8191
        hn=h>>13
        assert hn and all(he&~hits[1<<v] for v in V)
        counts['C_H']+=1
        safe=free[hn]
        assert all((he&hits[safe]|union(hits[1<<u] for u in C if u!=v))!=8191 for v in C)
        def grants(v):
            star=hits[1<<v]
            mask={star,(star|he)&hits[N[v]&safe]}
            return [m for m in mask if all(m==n or m&~n for n in mask)]
        for masks in product(*(grants(v) for v in C)):
            counts['grants']+=1
            assert union(masks)!=8191
    counts['H_before_filter']+=len(sols)
print(counts)
