"""Independent per-center census. The Lean proof checks all grants, including dominated choices."""
import itertools, json
from pathlib import Path
from functools import reduce, cache
from operator import or_
from collections import Counter

edges=[(1,2),(3,4),(0,4),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(6,9),(6,8),(5,8)]
def mask(indices):
    return reduce(or_,(1<<i for i in indices),0)
def setbits(v):
    return (i for i in range(v.bit_length()) if v>>i&1)
edge=[mask(e) for e in edges]
mis=[x for x in range(1024) if all(x&e!=e for e in edge)
     and all(any((x|1<<v)&e==e for e in edge) for v in setbits(1023^x))]
pos=[mask(i for i,e in enumerate(edge) if x&e) for x in range(1024)]
neg=[mask(i for i,e in enumerate(mis) if x&e) for x in range(1024)]
@cache
def shores(t):
    keep={0}
    for i in setbits(t):
        choices={a|1<<v for a in keep for v in edges[i]}
        keep={x for x in choices if not any(x!=y and x&y==y for y in choices)}
    return sorted(keep)
@cache
def free(f):
    return mask(v for v in range(10) if not neg[1<<v]&f)
def subsets(m):
    for n in range(1<<m.bit_count()):
        yield mask(v for i,v in enumerate(setbits(m)) if n>>i&1)
neighbors=[mask(set(e).difference([v]).pop() for e in edges if v in e) for v in range(10)]
out=[]
for center in itertools.combinations(range(10),4):
    t=8191^pos[mask(center)]
    assert t
    arms=shores(t); totals=Counter(centers=1)
    pairs=set()
    for xx in arms:
        f=neg[xx]
        for a,b in itertools.combinations(arms,2):
            totals['trials']+=1
            if a&b or f&neg[a]&neg[b]:continue
            totals['seeds']+=1
            avoid=1023^(a|b)
            for dx,dy in itertools.product(subsets(avoid&free(f&neg[b])),subsets(avoid&free(f&neg[a]))):
                totals['extensions']+=1
                u,v=a|dx,b|dy
                if not u&v and not f&neg[u]&neg[v]:
                    pairs.add((pos[u]&pos[v],neg[u]&neg[v]))
    for he,hn in pairs:
        assert hn and all(he&~pos[1<<v] for v in range(10))
        extra=he&pos[free(hn)]
        assert all((extra|pos[mask(set(center)-{v})])!=8191 for v in center)
        fields=[]
        for v in center:
            s=pos[1<<v]; long=(s|he)&pos[neighbors[v]&free(hn)]; fields.append([s,long])
        totals['full_grants']+=16
        assert all(reduce(or_,p)!=8191 for p in itertools.product(*fields))
        totals['maximal_grants']+=sum(1 for _ in itertools.product(*[
            [v for v in set(pair) if not any(v!=u and v&u==v for u in pair)] for pair in fields]))
    totals['hidden_traces']+=len(pairs)
    out.append(dict(center=center,**totals))
counts=Counter()
for row in out: counts.update({k:v for k,v in row.items() if k!='center'})
assert counts==dict(centers=210,trials=8123,seeds=41,extensions=87,hidden_traces=87,full_grants=1392,maximal_grants=239), counts
Path(__file__).with_name('centers.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
print(dict(counts))
