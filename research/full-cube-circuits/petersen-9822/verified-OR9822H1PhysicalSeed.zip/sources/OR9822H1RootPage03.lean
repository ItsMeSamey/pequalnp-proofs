import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers03 : List (List Nat) := [[0,1,5,9],[0,1,6,7],[0,1,6,8],[0,1,6,9],[0,1,7,8],[0,1,7,9],[0,1,8,9]]
theorem checked03 : centers03.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
