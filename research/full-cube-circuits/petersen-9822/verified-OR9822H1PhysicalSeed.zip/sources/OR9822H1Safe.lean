import OR9822H2RawMono
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check Research.Graph9822OneHidden
theorem sub_free_safe {x f : Nat} (sm : sub x (freeRaw f)=true) : meets (rawNeg x) f=false := by
  apply (empty_overlap ..).2
  intro n hot
  by_cases nl : n<16
  · have h := hot
    rw [raw_neg_bit x ⟨n,nl⟩] at h
    obtain ⟨i,xi,ni⟩ := meets_iff_exists.mp h
    obtain ⟨il,cold⟩ := (freeRaw_member ..).1 ((subset_bits ..).1 sm i xi)
    have sing := singleton_raw_neg ⟨i,il⟩ ⟨n,nl⟩
    have nh : (rawNeg (bit i)).testBit n=true := sing.trans ni
    cases e : f.testBit n
    · rfl
    · have wrong := (empty_overlap ..).1 cold n e; simp_all
  · change (edgeMask _ Research.Graph9822.FourSaturation.witnesses).testBit n=true at hot
    rw [test_edgeMask,List.getElem?_eq_none (by change 16≤n; omega)] at hot
    contradiction
end Research.Graph9822H1Check
