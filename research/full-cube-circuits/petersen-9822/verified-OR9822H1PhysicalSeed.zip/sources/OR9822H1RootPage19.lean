import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers19 : List (List Nat) := [[1,5,7,8],[1,5,7,9],[1,5,8,9],[1,6,7,8],[1,6,7,9],[1,6,8,9],[1,7,8,9]]
theorem checked19 : centers19.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
