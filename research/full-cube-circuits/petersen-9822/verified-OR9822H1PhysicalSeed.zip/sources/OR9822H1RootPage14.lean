import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers14 : List (List Nat) := [[1,2,5,9],[1,2,6,7],[1,2,6,8],[1,2,6,9],[1,2,7,8],[1,2,7,9],[1,2,8,9]]
theorem checked14 : centers14.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
