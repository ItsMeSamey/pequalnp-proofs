import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers22 : List (List Nat) := [[2,3,8,9],[2,4,5,6],[2,4,5,7],[2,4,5,8],[2,4,5,9],[2,4,6,7],[2,4,6,8]]
theorem checked22 : centers22.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
