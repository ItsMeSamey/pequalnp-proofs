import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers02 : List (List Nat) := [[0,1,4,6],[0,1,4,7],[0,1,4,8],[0,1,4,9],[0,1,5,6],[0,1,5,7],[0,1,5,8]]
theorem checked02 : centers02.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
