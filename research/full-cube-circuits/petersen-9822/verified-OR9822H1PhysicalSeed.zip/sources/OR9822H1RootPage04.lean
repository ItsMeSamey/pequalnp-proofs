import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers04 : List (List Nat) := [[0,2,3,4],[0,2,3,5],[0,2,3,6],[0,2,3,7],[0,2,3,8],[0,2,3,9],[0,2,4,5]]
theorem checked04 : centers04.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
