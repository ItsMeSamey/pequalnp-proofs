import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers17 : List (List Nat) := [[1,3,8,9],[1,4,5,6],[1,4,5,7],[1,4,5,8],[1,4,5,9],[1,4,6,7],[1,4,6,8]]
theorem checked17 : centers17.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
