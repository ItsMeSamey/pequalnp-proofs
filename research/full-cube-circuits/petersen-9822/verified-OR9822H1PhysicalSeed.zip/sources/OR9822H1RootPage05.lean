import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers05 : List (List Nat) := [[0,2,4,6],[0,2,4,7],[0,2,4,8],[0,2,4,9],[0,2,5,6],[0,2,5,7],[0,2,5,8]]
theorem checked05 : centers05.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
