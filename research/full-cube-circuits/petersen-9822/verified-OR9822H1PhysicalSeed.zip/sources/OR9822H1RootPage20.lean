import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers20 : List (List Nat) := [[2,3,4,5],[2,3,4,6],[2,3,4,7],[2,3,4,8],[2,3,4,9],[2,3,5,6],[2,3,5,7]]
theorem checked20 : centers20.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
