import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers23 : List (List Nat) := [[2,4,6,9],[2,4,7,8],[2,4,7,9],[2,4,8,9],[2,5,6,7],[2,5,6,8],[2,5,6,9]]
theorem checked23 : centers23.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
