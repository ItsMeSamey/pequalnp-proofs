import OR9822H1Extras
import OR9822H2RawMono
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
private theorem monotoneNeg {a b : Nat} (s : sub a b=true) : sub (rawNeg a) (rawNeg b)=true :=
  raw_trace_mono Research.Graph9822.FourSaturation.witnesses s
private theorem rightCold {a b f a₀ b₀ : Nat} (sa : sub a₀ a=true) (sb : sub b₀ b=true)
    (safe : meets f (rawNeg a &&& rawNeg b)=false) :
    meets f (rawNeg a₀ &&& rawNeg b₀)=false := by
  apply (empty_overlap ..).2
  intro i fi
  have no := (empty_overlap ..).1 safe i fi
  rw [Nat.testBit_and] at no ⊢
  cases ha : (rawNeg a₀).testBit i <;> cases hb : (rawNeg b₀).testBit i <;> simp_all
  have ea := (subset_bits ..).1 (monotoneNeg sa) i ha
  have eb := (subset_bits ..).1 (monotoneNeg sb) i hb
  simp_all
private theorem padArm {a b a₀ b₀ f : Nat} (bound : a<1024)
    (sa : sub a₀ a=true) (sb : sub b₀ b=true) (dis : meets a b=false)
    (safe : meets f (rawNeg a &&& rawNeg b)=false) :
    let rest := 1023 ^^^ (a₀ ||| b₀)
    ∃ x∈extras (rest &&& freeRaw (f &&& rawNeg b₀)),a₀ ||| x=a := by
  intro rest
  have fits : meets (f &&& rawNeg b₀) (rawNeg a)=false := by
    apply (empty_overlap ..).2
    intro i h
    obtain ⟨fi,bi⟩ := Bool.and_eq_true_iff.mp (by simpa only [Nat.testBit_and] using h)
    have bi' := (subset_bits ..).1 (monotoneNeg sb) i bi
    have hi := (empty_overlap ..).1 safe i fi
    simpa [bi'] using hi
  let x := a &&& rest
  have xb : x<1024 := lt_of_le_of_lt Nat.and_le_left bound
  have inFree := left_in_free bound fits
  have incl : sub x (rest &&& freeRaw (f &&& rawNeg b₀))=true := by
    apply (subset_bits ..).2; intro i xi
    obtain ⟨ai,ri⟩ := Bool.and_eq_true_iff.mp (by simpa only [x,Nat.testBit_and] using xi)
    simp [ri,(subset_bits ..).1 inFree i ai]
  refine ⟨x,extras_complete xb incl,?_⟩
  have allBits : sub a 1023=true := beq_iff_eq.mpr (Nat.and_two_pow_sub_one_of_lt_two_pow (n:=10) bound)
  apply Nat.eq_of_testBit_eq; intro i
  have aBit := (subset_bits ..).1 sa i
  have bBit := (subset_bits ..).1 sb i
  have apart := (empty_overlap ..).1 dis i
  have full := (subset_bits ..).1 allBits i
  simp only [x,rest,Nat.testBit_and,Nat.testBit_xor,Nat.testBit_or]
  cases ha : a.testBit i <;> cases hp : a₀.testBit i <;> cases hq : b₀.testBit i <;> simp_all

theorem seed_gives_reject {c : List Nat} {a b a₀ b₀ f : Nat}
    (ab : a<1024) (bb : b<1024) (sa : sub a₀ a=true) (sb : sub b₀ b=true)
    (dis : meets a b=false) (safe : meets f (rawNeg a &&& rawNeg b)=false)
    (checked : seedCheck c f a₀ b₀=true) :
    rejects c (demand (rawPos a &&& rawPos b) (rawNeg a &&& rawNeg b))=true := by
  have apart : meets a₀ b₀=false := by
    apply (empty_overlap ..).2; intro i ai
    have no := (empty_overlap ..).1 dis i ((subset_bits ..).1 sa i ai)
    cases e : b₀.testBit i
    · rfl
    · have := (subset_bits ..).1 sb i e; simp_all
  have sc := rightCold sa sb safe
  obtain ⟨x,hx,ax⟩ := padArm ab sa sb dis safe
  have dr : meets b a=false := by simpa [meets,Nat.and_comm] using dis
  have sr : meets f (rawNeg b &&& rawNeg a)=false := by rw [Nat.and_comm (rawNeg b)]; exact safe
  obtain ⟨y,hy,by'⟩ := padArm bb sb sa dr sr
  rw [Nat.or_comm b₀ a₀] at hy
  unfold seedCheck at checked
  simp only [apart,sc,Bool.false_or,Bool.false_eq_true,ite_false,List.all_eq_true] at checked
  have row := checked x hx y hy
  simpa only [ax,by',dis,safe,Bool.false_or] using row
end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.seed_gives_reject
