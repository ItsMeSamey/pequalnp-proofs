import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers10 : List (List Nat) := [[0,4,6,9],[0,4,7,8],[0,4,7,9],[0,4,8,9],[0,5,6,7],[0,5,6,8],[0,5,6,9]]
theorem checked10 : centers10.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
