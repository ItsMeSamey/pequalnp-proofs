import OR9822H1Pilot
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check
open Research.Graph9822OneHidden (edges)
def fastMin (xs : List Nat) :=
  let ys := xs.eraseDups
  ys.filter fun x => !(ys.any fun y => x != y && sub y x)
def enumerate : List (List Nat) → List Nat
  | [] => [0]
  | e::es => fastMin ((enumerate es).flatMap fun a => e.map fun v => a ||| v)
def candidates (t : Nat) := enumerate ((es.filter t.testBit).map (fun i =>
  (vs.filter edges[i]!.testBit).map bit))

theorem enumerate_mem (es : List (List Nat)) (x : Nat) :
    x∈enumerate es ↔ x∈shoreEnum es := by
  induction es generalizing x with
  | nil => rfl
  | cons e es ih =>
    have children (y : Nat) : y∈(enumerate es).flatMap (fun a => e.map fun v => a ||| v) ↔
        y∈(shoreEnum es).flatMap (fun a => e.map fun v => a ||| v) := by
      simp only [List.mem_flatMap,ih]
    simp only [enumerate,shoreEnum,fastMin,minimal,List.mem_mergeSort,List.mem_filter,
      List.mem_eraseDups,Bool.not_eq_true',List.any_eq_false,List.mem_flatMap,ih]
end Research.Graph9822H1Check
