import OR9822H1RootPage00
import OR9822H1RootPage01
import OR9822H1RootPage02
import OR9822H1RootPage03
import OR9822H1RootPage04
import OR9822H1RootPage05
namespace Research.Graph9822H1Check
def batch0 : List (List Nat) := centers00 ++ centers01 ++ centers02 ++ centers03 ++ centers04 ++ centers05
theorem bcheck0 : batch0.all (atCenters candidates)=true := by simp [batch0,checked00,checked01,checked02,checked03,checked04,checked05]
end Research.Graph9822H1Check
