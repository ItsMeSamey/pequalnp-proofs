import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers11 : List (List Nat) := [[0,5,7,8],[0,5,7,9],[0,5,8,9],[0,6,7,8],[0,6,7,9],[0,6,8,9],[0,7,8,9]]
theorem checked11 : centers11.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
