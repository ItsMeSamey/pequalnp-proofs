import OR9822H1RootPage24
import OR9822H1RootPage25
import OR9822H1RootPage26
import OR9822H1RootPage27
import OR9822H1RootPage28
import OR9822H1RootPage29
namespace Research.Graph9822H1Check
def batch4 : List (List Nat) := centers24 ++ centers25 ++ centers26 ++ centers27 ++ centers28 ++ centers29
theorem bcheck4 : batch4.all (atCenters candidates)=true := by simp [batch4,checked24,checked25,checked26,checked27,checked28,checked29]
end Research.Graph9822H1Check
