import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers12 : List (List Nat) := [[1,2,3,4],[1,2,3,5],[1,2,3,6],[1,2,3,7],[1,2,3,8],[1,2,3,9],[1,2,4,5]]
theorem checked12 : centers12.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
