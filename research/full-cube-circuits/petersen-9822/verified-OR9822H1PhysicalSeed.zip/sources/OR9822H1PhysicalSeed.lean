import OR9822H1Fast
import OR9822H1Subshore
import OR9822H1SeedFit
import OR9822H1Safe
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
def need (c : List Nat) := 8191 ^^^ rawPos (vertexMask c)
theorem physical_seed_reject {c : List Nat} {a b : Nat} (checked : atCenters candidates c=true)
    (ab : a<1024) (bb : b<1024) (dis : meets a b=false)
    (ca : sub (need c) (rawPos a)=true) (cb : sub (need c) (rawPos b)=true)
    (cs : sub (need c) (rawPos (freeRaw (rawNeg a &&& rawNeg b)))=true) :
    rejects c (demand (rawPos a &&& rawPos b) (rawNeg a &&& rawNeg b))=true := by
  have checks : need c != 0 && (candidates (need c)).all (fun x =>
      (candidates (need c)).all (fun u => (candidates (need c)).all (fun v =>
        !decide (u<v) || seedCheck c (rawNeg x) u v)))=true := checked
  obtain ⟨nonzero,all⟩ := Bool.and_eq_true_iff.mp checks
  have mks {v : Nat} (sv : sub (need c) (rawPos v)=true) :
      ∃ x∈candidates (need c),sub x v=true ∧ sub (need c) (rawPos x)=true := by
    obtain ⟨x,xm,xv,xs⟩ := raw_has_seed sv
    exact ⟨x,(enumerate_mem ..).2 xm,xv,xs⟩
  obtain ⟨x,xm,xs,_⟩ := mks cs
  obtain ⟨u,um,ua,uh⟩ := mks ca
  obtain ⟨v,vm,vb,_⟩ := mks cb
  have safe := sub_free_safe xs
  have sep : u≠v := by
    rintro rfl
    have eq : u=0 := by
      apply Nat.eq_of_testBit_eq; intro i
      cases ub : u.testBit i
      · simp
      · have pa := (subset_bits ..).1 ua i ub
        have pb := (subset_bits ..).1 vb i ub
        have no := (empty_overlap ..).1 dis i pa
        simp_all
    have r0 : rawPos 0=0 := by decide +kernel
    rw [eq,r0] at uh
    simp [sub] at uh
    simp [uh] at nonzero
  have rows := List.all_eq_true.mp all _ xm
  rcases lt_or_gt_of_ne sep with lt|gt
  · have ch := List.all_eq_true.mp (List.all_eq_true.mp rows _ um) _ vm
    exact seed_gives_reject ab bb ua vb dis safe (by simpa [lt] using ch)
  · have ch := List.all_eq_true.mp (List.all_eq_true.mp rows _ vm) _ um
    have db : meets b a=false := by simpa [meets,Nat.and_comm] using dis
    have sf : meets (rawNeg x) (rawNeg b &&& rawNeg a)=false := by rw [Nat.and_comm (rawNeg b)]; exact safe
    have out := seed_gives_reject bb ab vb ua db sf (by simpa [gt] using ch)
    simpa only [Nat.and_comm (rawPos b) (rawPos a),Nat.and_comm (rawNeg b) (rawNeg a)] using out
end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.physical_seed_reject
