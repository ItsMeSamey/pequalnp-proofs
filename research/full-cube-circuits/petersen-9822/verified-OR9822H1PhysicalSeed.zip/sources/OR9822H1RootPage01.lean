import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers01 : List (List Nat) := [[0,1,3,4],[0,1,3,5],[0,1,3,6],[0,1,3,7],[0,1,3,8],[0,1,3,9],[0,1,4,5]]
theorem checked01 : centers01.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
