import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers09 : List (List Nat) := [[0,3,8,9],[0,4,5,6],[0,4,5,7],[0,4,5,8],[0,4,5,9],[0,4,6,7],[0,4,6,8]]
theorem checked09 : centers09.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
