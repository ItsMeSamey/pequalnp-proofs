import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers00 : List (List Nat) := [[0,1,2,3],[0,1,2,4],[0,1,2,5],[0,1,2,6],[0,1,2,7],[0,1,2,8],[0,1,2,9]]
theorem checked00 : centers00.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
