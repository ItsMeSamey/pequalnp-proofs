import OR9822H2Checker

namespace Research.Graph9822H1Check
open Research.Graph9822H2Check
open Research.Graph9822OneHidden (edges meets)

def vertexMask (vertices : List Nat) := vertices.foldl (fun acc v => acc ||| bit v) 0
def neighbor (v : Nat) := edges.foldl (fun acc e =>
  if e.testBit v then acc ||| (e ^^^ bit v) else acc) 0

def extras (allowed : Nat) : List Nat := vs.foldl (fun xs v =>
  if allowed.testBit v then xs ++ xs.map (fun x => x ||| bit v) else xs) [0]

def termGrants (h v : Nat) : List Nat :=
  let star := rawPos (bit v)
  let long := neighbor v &&& freeRaw (negative h)
  [star,(star ||| positive h) &&& rawPos long]

def rejects (c : List Nat) (h : Nat) : Bool :=
  let extra := positive h &&& rawPos (freeRaw (negative h))
  let allNeeded := c.all fun v => extra ||| rawPos (vertexMask (c.erase v)) != 8191
  let footprints := c.foldl (fun xs v =>
    xs.flatMap (fun x => (termGrants h v).map (fun y => x ||| y))) [0]
  allNeeded && footprints.all (· != 8191)

def seedCheck (c : List Nat) (f a b : Nat) : Bool :=
  if meets a b || meets f (rawNeg a &&& rawNeg b) then true else
  let rest := 1023 ^^^ (a ||| b)
  let left := rest &&& freeRaw (f &&& rawNeg b)
  let right := rest &&& freeRaw (f &&& rawNeg a)
  (extras left).all (fun x => (extras right).all fun y =>
    let u := a ||| x
    let v := b ||| y
    meets u v || meets f (rawNeg u &&& rawNeg v) ||
      rejects c (demand (rawPos u &&& rawPos v) (rawNeg u &&& rawNeg v)))

/-- Numeric check for a fixed four-center set. The argument supplies the shared
minimal-shore enumerator, whose coverage theorem is used in the semantic caller. -/
def atCenters (shores : Nat → List Nat) (c : List Nat) : Bool :=
  let t := 8191 ^^^ rawPos (vertexMask c)
  let arms := shores t
  t != 0 && arms.all (fun x => arms.all fun a => arms.all fun b =>
    !decide (a<b) || seedCheck c (rawNeg x) a b)

end Research.Graph9822H1Check
