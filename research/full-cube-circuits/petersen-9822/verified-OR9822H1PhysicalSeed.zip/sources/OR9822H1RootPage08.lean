import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers08 : List (List Nat) := [[0,3,5,8],[0,3,5,9],[0,3,6,7],[0,3,6,8],[0,3,6,9],[0,3,7,8],[0,3,7,9]]
theorem checked08 : centers08.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
