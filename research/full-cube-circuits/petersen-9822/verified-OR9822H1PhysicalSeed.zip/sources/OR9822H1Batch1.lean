import OR9822H1RootPage06
import OR9822H1RootPage07
import OR9822H1RootPage08
import OR9822H1RootPage09
import OR9822H1RootPage10
import OR9822H1RootPage11
namespace Research.Graph9822H1Check
def batch1 : List (List Nat) := centers06 ++ centers07 ++ centers08 ++ centers09 ++ centers10 ++ centers11
theorem bcheck1 : batch1.all (atCenters candidates)=true := by simp [batch1,checked06,checked07,checked08,checked09,checked10,checked11]
end Research.Graph9822H1Check
