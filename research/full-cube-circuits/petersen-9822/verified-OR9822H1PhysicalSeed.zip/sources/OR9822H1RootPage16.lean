import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers16 : List (List Nat) := [[1,3,5,8],[1,3,5,9],[1,3,6,7],[1,3,6,8],[1,3,6,9],[1,3,7,8],[1,3,7,9]]
theorem checked16 : centers16.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
