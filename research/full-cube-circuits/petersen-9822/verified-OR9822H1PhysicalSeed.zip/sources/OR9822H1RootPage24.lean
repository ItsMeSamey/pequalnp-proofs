import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers24 : List (List Nat) := [[2,5,7,8],[2,5,7,9],[2,5,8,9],[2,6,7,8],[2,6,7,9],[2,6,8,9],[2,7,8,9]]
theorem checked24 : centers24.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
