import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers06 : List (List Nat) := [[0,2,5,9],[0,2,6,7],[0,2,6,8],[0,2,6,9],[0,2,7,8],[0,2,7,9],[0,2,8,9]]
theorem checked06 : centers06.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
