import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers29 : List (List Nat) := [[4,6,8,9],[4,7,8,9],[5,6,7,8],[5,6,7,9],[5,6,8,9],[5,7,8,9],[6,7,8,9]]
theorem checked29 : centers29.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
