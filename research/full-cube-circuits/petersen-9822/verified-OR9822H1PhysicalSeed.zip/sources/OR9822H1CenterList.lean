import OR9822H1Fast
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check
def centerList : List (List Nat) :=
  vs.flatMap fun a => vs.flatMap fun b => vs.flatMap fun c =>
    vs.filterMap fun d => if a<b ∧ b<c ∧ c<d then some [a,b,c,d] else none

theorem center_member {c : List Nat} (len : c.length=4) (ord : c.Pairwise (·<·))
    (bound : ∀ v∈c,v<10) : c∈centerList := by
  match c with
  | [a,b,c,d] =>
    have mem (i : Nat) (h : i∈[a,b,c,d]) : i∈vs := List.mem_range.mpr (bound _ h)
    have o₁ := List.pairwise_cons.mp ord
    have o₂ := List.pairwise_cons.mp o₁.2
    have o₃ := List.pairwise_cons.mp o₂.2
    have ab : a<b := o₁.1 b (by simp)
    have bc : b<c := o₂.1 c (by simp)
    have cd : c<d := o₃.1 d (by simp)
    unfold centerList
    apply List.mem_flatMap.mpr; refine ⟨a,mem _ (by simp),?_⟩
    apply List.mem_flatMap.mpr; refine ⟨b,mem _ (by simp),?_⟩
    apply List.mem_flatMap.mpr; refine ⟨c,mem _ (by simp),?_⟩
    exact List.mem_filterMap.mpr ⟨d,mem _ (by simp),by simp [ab,bc,cd]⟩
  | [] | [_] | [_,_] | [_,_,_] | _::_::_::_::_::_ => simp_all <;> omega
end Research.Graph9822H1Check
