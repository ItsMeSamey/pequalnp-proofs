import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers26 : List (List Nat) := [[3,4,7,8],[3,4,7,9],[3,4,8,9],[3,5,6,7],[3,5,6,8],[3,5,6,9],[3,5,7,8]]
theorem checked26 : centers26.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
