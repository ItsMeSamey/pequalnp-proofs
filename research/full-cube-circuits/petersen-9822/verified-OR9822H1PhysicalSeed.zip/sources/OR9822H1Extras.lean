import OR9822H1Seeds
import OR9822H2MaskLogic
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check
def fill (a : Nat) (v : Nat) := if a.testBit v then bit v else 0
private theorem fill_bit (a v i : Nat) : (fill a v).testBit i=true ↔ v=i ∧ a.testBit i=true := by
  by_cases eq : v=i
  · subst i; cases h : a.testBit v <;> simp [fill,h,bit,Nat.testBit_two_pow]
  · cases h : a.testBit v <;> simp [fill,h,bit,Nat.testBit_two_pow,eq]
private def built (a : Nat) (xs : List Nat) (z : Nat) :=
  xs.foldl (fun acc i => acc ||| fill a i) z
private theorem built_bit (a : Nat) (xs : List Nat) (z i : Nat) :
    (built a xs z).testBit i=true ↔ z.testBit i=true ∨ i∈xs ∧ a.testBit i=true := by
  induction xs generalizing z with
  | nil => simp [built]
  | cons x xs ih =>
    change (built a xs (z ||| fill a x)).testBit i=true ↔ _
    rw [ih,Nat.testBit_or,Bool.or_eq_true,fill_bit]
    simp only [List.mem_cons]
    grind
private theorem built_mem (x allow : Nat) (small : sub x allow=true)
    (vs : List Nat) (pool : List Nat) (z : Nat) (hz : z∈pool) :
    built x vs z ∈ vs.foldl (fun xs i => if allow.testBit i then xs ++ xs.map (fun a => a ||| bit i) else xs) pool := by
  induction vs generalizing z pool with
  | nil => exact hz
  | cons i vs ih =>
    apply ih
    by_cases sel : x.testBit i = true
    · have en := (subset_bits ..).1 small i sel
      simp [fill,sel,en]; exact Or.inr ⟨z,hz,rfl⟩
    · cases en : allow.testBit i <;> simp [fill,sel,en,hz]
theorem extras_complete {x allow : Nat} (bound : x<1024) (small : sub x allow=true) : x∈extras allow := by
  have eq : built x vs 0=x := by
    apply Nat.eq_of_testBit_eq; intro i; apply Bool.eq_iff_iff.mpr
    rw [built_bit]; simp only [Nat.zero_testBit,Bool.false_eq_true,false_or]
    constructor
    · exact And.right
    · intro h
      have lt : i<10 := by
        by_contra! large
        have z : x.testBit i=false := Nat.testBit_lt_two_pow (lt_of_lt_of_le bound
          (show 1024≤2^i from Nat.pow_le_pow_right (by decide : 0<2) large))
        simp [z] at h
      exact ⟨List.mem_range.mpr lt,h⟩
  exact eq ▸ built_mem x allow small vs [0] 0 (by simp)
end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.extras_complete
