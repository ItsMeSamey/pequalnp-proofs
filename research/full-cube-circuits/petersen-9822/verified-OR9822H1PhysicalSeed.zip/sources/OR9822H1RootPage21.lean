import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers21 : List (List Nat) := [[2,3,5,8],[2,3,5,9],[2,3,6,7],[2,3,6,8],[2,3,6,9],[2,3,7,8],[2,3,7,9]]
theorem checked21 : centers21.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
