import OR9822H1Seeds
import H2FastShore9822
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check
open Research.Graph9822OneHidden (edges)
def h1Shores (t : Nat) := shoreEnum ((es.filter t.testBit).map (fun i =>
  (vs.filter edges[i]!.testBit).map bit))
end Research.Graph9822H1Check
