import OR9822H1Pilot
import H2MinimalWitness9822
import OR9822H2RawMask
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check
open Research.Graph9822OneHidden (edges)
theorem raw_has_seed {t b : Nat} (hit : sub t (rawPos b)=true) :
    ∃ m∈h1Shores t,sub m b=true ∧ sub t (rawPos m)=true := by
  let esList := (es.filter t.testBit).map (fun i => (vs.filter edges[i]!.testBit).map bit)
  have endsFit : ∀ i : Fin 13,edges[i.val]!<1024 := by decide +kernel
  have tr (a : Nat) : HitsAll esList a ↔ ∀ i : Fin 13, t.testBit i.val=true → (rawPos a).testBit i.val=true := by
    constructor
    · intro h i ti
      have hi : i.val∈es.filter t.testBit := List.mem_filter.mpr ⟨List.mem_range.mpr i.isLt,ti⟩
      obtain ⟨v,vm,subV⟩ := h _ (List.mem_map.mpr ⟨i.val,hi,rfl⟩)
      obtain ⟨j,ji,rfl⟩ := List.mem_map.mp vm
      rw [raw_pos_bit a i]
      apply meets_iff_exists.mpr
      exact ⟨j,(subset_bits ..).1 subV j (by simp [bit,Nat.testBit_two_pow]),(List.mem_filter.mp ji).2⟩
    · intro h e mem
      obtain ⟨i,im,rfl⟩ := List.mem_map.mp mem
      obtain ⟨rng,sel⟩ := List.mem_filter.mp im
      let k : Fin 13 := ⟨i,List.mem_range.mp rng⟩
      have hp := h k sel
      rw [raw_pos_bit a k] at hp
      obtain ⟨j,ja,je⟩ := meets_iff_exists.mp hp
      have jl : j<10 := by
        by_contra! large
        have z : edges[k.val]!.testBit j=false := Nat.testBit_lt_two_pow (lt_of_lt_of_le (endsFit k)
          (show 1024≤2^j from Nat.pow_le_pow_right (by decide : 0<2) large))
        exact Bool.noConfusion (je.symm.trans z)
      refine ⟨bit j,List.mem_map.mpr ⟨j,List.mem_filter.mpr ⟨List.mem_range.mpr jl,je⟩,rfl⟩,?_⟩
      apply (subset_bits ..).2
      intro n set
      have eq : j=n := by simpa [bit,Nat.testBit_two_pow] using set
      exact eq ▸ ja
  obtain ⟨m,mem,sm,hm,_⟩ := minimalShoreBelow ((tr b).2 (fun i ti => (subset_bits ..).1 hit i ti))
  refine ⟨m,mem,sm,(subset_bits ..).2 ?_⟩
  intro i ti
  by_cases il : i<13
  · exact (tr m).1 hm ⟨i,il⟩ ti
  · have hb := (subset_bits ..).1 hit i ti
    change (Research.Graph9822OneHidden.edgeMask _ edges).testBit i=true at hb
    have out : edges.length ≤ i := Nat.le_of_not_gt il
    rw [test_edgeMask,List.getElem?_eq_none out] at hb
    contradiction
end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.raw_has_seed
