import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers13 : List (List Nat) := [[1,2,4,6],[1,2,4,7],[1,2,4,8],[1,2,4,9],[1,2,5,6],[1,2,5,7],[1,2,5,8]]
theorem checked13 : centers13.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
