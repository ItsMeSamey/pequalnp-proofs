import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers25 : List (List Nat) := [[3,4,5,6],[3,4,5,7],[3,4,5,8],[3,4,5,9],[3,4,6,7],[3,4,6,8],[3,4,6,9]]
theorem checked25 : centers25.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
