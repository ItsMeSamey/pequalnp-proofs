import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers27 : List (List Nat) := [[3,5,7,9],[3,5,8,9],[3,6,7,8],[3,6,7,9],[3,6,8,9],[3,7,8,9],[4,5,6,7]]
theorem checked27 : centers27.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
