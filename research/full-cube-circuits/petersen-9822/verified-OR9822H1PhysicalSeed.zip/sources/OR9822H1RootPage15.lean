import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers15 : List (List Nat) := [[1,3,4,5],[1,3,4,6],[1,3,4,7],[1,3,4,8],[1,3,4,9],[1,3,5,6],[1,3,5,7]]
theorem checked15 : centers15.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
