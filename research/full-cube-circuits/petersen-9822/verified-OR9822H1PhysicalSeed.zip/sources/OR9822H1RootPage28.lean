import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers28 : List (List Nat) := [[4,5,6,8],[4,5,6,9],[4,5,7,8],[4,5,7,9],[4,5,8,9],[4,6,7,8],[4,6,7,9]]
theorem checked28 : centers28.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
