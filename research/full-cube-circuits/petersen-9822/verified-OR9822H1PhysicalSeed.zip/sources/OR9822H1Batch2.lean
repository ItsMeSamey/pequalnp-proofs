import OR9822H1RootPage12
import OR9822H1RootPage13
import OR9822H1RootPage14
import OR9822H1RootPage15
import OR9822H1RootPage16
import OR9822H1RootPage17
namespace Research.Graph9822H1Check
def batch2 : List (List Nat) := centers12 ++ centers13 ++ centers14 ++ centers15 ++ centers16 ++ centers17
theorem bcheck2 : batch2.all (atCenters candidates)=true := by simp [batch2,checked12,checked13,checked14,checked15,checked16,checked17]
end Research.Graph9822H1Check
