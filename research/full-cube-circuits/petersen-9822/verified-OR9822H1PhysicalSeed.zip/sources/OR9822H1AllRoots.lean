import OR9822H1CenterList
import OR9822H1Batch0
import OR9822H1Batch1
import OR9822H1Batch2
import OR9822H1Batch3
import OR9822H1Batch4
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
theorem all_roots {c : List Nat} (len : c.length=4) (ord : c.Pairwise (·<·))
    (bound : ∀ v∈c,v<10) : atCenters candidates c=true := by
  have mem := center_member len ord bound
  have eq : centerList=batch0++batch1++batch2++batch3++batch4 := by decide +kernel
  rw [eq] at mem
  have all : (batch0++batch1++batch2++batch3++batch4).all (atCenters candidates)=true := by
    simp [bcheck0,bcheck1,bcheck2,bcheck3,bcheck4]
  exact List.all_eq_true.mp all _ mem
end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.all_roots
