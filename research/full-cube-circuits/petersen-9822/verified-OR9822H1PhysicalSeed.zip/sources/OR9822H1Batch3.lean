import OR9822H1RootPage18
import OR9822H1RootPage19
import OR9822H1RootPage20
import OR9822H1RootPage21
import OR9822H1RootPage22
import OR9822H1RootPage23
namespace Research.Graph9822H1Check
def batch3 : List (List Nat) := centers18 ++ centers19 ++ centers20 ++ centers21 ++ centers22 ++ centers23
theorem bcheck3 : batch3.all (atCenters candidates)=true := by simp [batch3,checked18,checked19,checked20,checked21,checked22,checked23]
end Research.Graph9822H1Check
