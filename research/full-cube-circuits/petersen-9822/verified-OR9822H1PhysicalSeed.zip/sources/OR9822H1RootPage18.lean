import OR9822H1Fast
namespace Research.Graph9822H1Check
set_option maxRecDepth 40000
set_option maxHeartbeats 4000000
def centers18 : List (List Nat) := [[1,4,6,9],[1,4,7,8],[1,4,7,9],[1,4,8,9],[1,5,6,7],[1,5,6,8],[1,5,6,9]]
theorem checked18 : centers18.all (atCenters candidates)=true := by decide +kernel
end Research.Graph9822H1Check
