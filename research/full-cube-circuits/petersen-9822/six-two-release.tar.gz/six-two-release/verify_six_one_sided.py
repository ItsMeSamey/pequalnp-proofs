"""Validate original hidden operands and terminal semantics before pricing a row."""
from or_order_bound import increment
from functools import lru_cache
TARGET_EDGES=(6,24,17,33,66,132,264,528,160,640,576,320,288)
RAW_BITS=tuple(sum(1<<x for x in range(1024) if x>>i&1) for i in range(10))
TARGET=sum(1<<x for x in range(1024) if any(x&e==e for e in TARGET_EDGES))

@lru_cache(1024)
def raw(mask):
    ans=0
    for i,val in enumerate(RAW_BITS):
        if mask>>i&1:ans|=val
    return ans

def verify(scopes):
    if len(scopes)!=12 or any(type(s) is not int or not 0<s<4096 for s in scopes):
        raise ValueError('invalid original masks')
    a,b,c,d,*arms=scopes
    if (a|b)>=1024 or (c|d)>=2048 or not ((c^d)&1024):
        raise ValueError('expected H on exactly one original Q operand')
    h=raw(a)&raw(b)
    q=(raw(c&1023)|(h if c&1024 else 0)) & (raw(d&1023)|(h if d&1024 else 0))
    def value(mask):
        return raw(mask&1023)|(h if mask&1024 else 0)|(q if mask&2048 else 0)
    actual=0
    for l,r in zip(arms[::2],arms[1::2]):
        actual|=value(l)&value(r)
    if actual!=TARGET:
        raise ValueError('source row fails original truth table')
    intervals=[(s,s) for s in scopes]
    price=sum(increment(intervals,(1<<i)-1,i) for i in range(12))
    return price

if __name__=='__main__':
    import sys
    from collections import Counter
    strong=Counter(); weak=Counter()
    for row in sys.stdin:
        scopes=list(map(int,row.split()))
        strong[verify(scopes)]+=1
        price=0
        for i,s in enumerate(scopes):
            loss=sum(n*(n-1)//2 for t in scopes[:i] if (n:=(s&t).bit_count())>1)
            price+=max(0,s.bit_count()-1-loss)
        weak[price]+=1
    print(dict(sorted(strong.items())),dict(sorted(weak.items())))
