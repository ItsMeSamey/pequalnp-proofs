from itertools import combinations
from pysat.solvers import Solver
from pysat.formula import IDPool,CNF
E=[6,24,17,33,66,132,264,528,160,640,576,320,288]
N=[i for i in range(1024) if not any(i&e==e for e in E) and all(any((i|1<<v)&e==e for e in E) for v in range(10) if not i>>v&1)]
def fixture(mode):
 p=IDPool(); f=CNF(); c=p.id(); f.append([c])
 def meet(xs):
  y=p.id()
  for x in xs:f.append([-y,x])
  f.append([y]+[-x for x in xs]);return y
 def join(xs):return -meet([-x for x in xs])
 G=[[[p.id() for _ in range(k)] for _ in range(2)] for k in [10,11,12,12,12,12]]
 for i,a in enumerate(G[1]):f.append([a[10] if i<mode else -a[10]])
 leaks=[[],[]]
 for x in E+N:
  prev=[]
  for j,t in enumerate(G):
   inp=[c if x>>v&1 else -c for v in range(10)]+prev
   if j>=2:inp=inp[:12]
   prev.append(meet([join([meet([s,v]) for s,v in zip(a,inp)]) for a in t]))
  if x in E:f.append(prev[2:])
  else:
   for u in prev[2:]:f.append([-u])
   for j in range(2):leaks[j].append(prev[j])
 for a in leaks:f.append(a)
 with Solver(name='g4',bootstrap_with=f.clauses) as sl:
  if not sl.solve():return
  model=set(sl.get_model()); masks=[tuple(sum(1<<i for i,x in enumerate(a) if x in model) for a in t) for t in G]
  good=lambda x,a,b:bool(x&a and x&b)
  for x in range(1024):
   h=good(x,*masks[0]);q=good(x|h<<10,*masks[1]);ex=x|h<<10|q<<11
   assert any(good(ex,*t) for t in masks[2:])==any(x&e==e for e in E)
  print(mode,masks,flush=True)
if __name__=='__main__':
 import sys
 fixture(int(sys.argv[1]))
