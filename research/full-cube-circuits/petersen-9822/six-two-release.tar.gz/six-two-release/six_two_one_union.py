"""Canonical actual Q operands, keeping the first hidden feature chronological."""
from pathlib import Path
def signatures(path):
    for line in Path(path).read_text().splitlines():
        h, a, b, q = map(int, line.split())
        if bool(a & 1024) != bool(b & 1024):
            yield h, min(a,b), max(a,b), q
if __name__ == "__main__":
    mixed = set(signatures("six-two-one-mixed.tsv"))
    sole = set(signatures("six-two-soleQ-prefix.tsv"))
    union = mixed | sole
    with open("six-two-one-all.tsv", "w") as out:
        for row in sorted(union):
            print(*row, sep="\t", file=out)
    print(len(mixed), len(sole), len(mixed & sole), len(union))
