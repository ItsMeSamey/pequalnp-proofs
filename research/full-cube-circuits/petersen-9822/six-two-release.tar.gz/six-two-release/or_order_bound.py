"""Order certificates for interval support lower bounds on <=12 physical scopes."""
from functools import lru_cache

def increment(intervals, previous, index):
    lo,hi=intervals[index]
    parts=[1<<v for v in range(hi.bit_length()) if hi>>v&1]
    while previous:
        bit=previous&-previous
        previous^=bit
        shared=hi&intervals[bit.bit_length()-1][1]
        if shared.bit_count()<2: continue
        hits=[p for p in parts if p&shared]
        if len(hits)>1:
            parts=[p for p in parts if not p&shared]+[sum(hits)]
    return max(0,sum(bool(p&lo) for p in parts)-1)

def certificate(intervals, target):
    original=tuple(intervals)
    if len(original)>12 or any(not (0<=lo<=hi<65536) or lo&~hi for lo,hi in original):
        raise ValueError("invalid interval family")
    ids=[i for i,(lo,hi) in enumerate(original) if lo.bit_count()>1]
    intervals=[original[i] for i in ids]
    @lru_cache(None)
    def solve(mask):
        best=(0,())
        remaining=mask
        while remaining:
            bit=remaining&-remaining
            remaining^=bit
            i=bit.bit_length()-1
            old=mask^bit
            value,order=solve(old)
            cand=(value+increment(intervals,old,i),order+(i,))
            if cand[0]>best[0]:best=cand
            if best[0]>=target:break
        return best
    value,order=solve((1<<len(intervals))-1)
    return value,tuple(ids[i] for i in order)
