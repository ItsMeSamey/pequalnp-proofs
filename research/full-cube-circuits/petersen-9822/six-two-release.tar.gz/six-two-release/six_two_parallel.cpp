#define main unused_prefix_scan
#include "prefix_scan.cpp"
#undef main
#include <array>
#include <map>
#include <set>
#include <fstream>
int safeRaw[65536], centersOK[8192];
struct Feature {U h;int he,hn,base;};
bool terminalFour(Feature a,Feature b,bool allowCross){
 int grants[100],g=0;
 for(int c=-1;c<10;c++){
  int rawBit=c<0?0:(1<<c);
  for(int hu=0;hu<3;hu++)for(int qu=0;qu<3;qu++){
   if(!allowCross && ((hu==1&&qu==2)||(hu==2&&qu==1)))continue;
   int ln=(raw[rawBit]>>13)|(hu==1?a.hn:0)|(qu==1?b.hn:0);
   int rightNeg=(hu==2?a.hn:0)|(qu==2?b.hn:0);
   if(ln&rightNeg)continue;
   int lp=hot[rawBit]|(hu==1?a.he:0)|(qu==1?b.he:0);
   int rp=hot[safeRaw[ln]]|(hu==2?a.he:0)|(qu==2?b.he:0);
   int m=lp&rp;
   if(m==0)continue;
   bool skip=false;for(int j=0;j<g;){if((m&~grants[j])==0){skip=true;break;}if((grants[j]&~m)==0)grants[j]=grants[--g];else j++;}
   if(!skip)grants[g++]=m;
  }
 }
 int bins[13][100],cnt[13]={};for(int i=0;i<13;i++)for(int j=0;j<g;j++)if(grants[j]>>i&1)bins[i][cnt[i]++]=grants[j];
 auto dfs=[&](auto&&self,int rem,int k)->bool{
  if(!rem)return true;if(!k)return false;
  int pivot=-1;for(int i=0;i<13;i++)if(rem>>i&1&&(pivot<0||cnt[i]<cnt[pivot]))pivot=i;
  for(int j=0;j<cnt[pivot];j++)if(self(self,rem&~bins[pivot][j],k-1))return true;
  return false;
 };
 return dfs(dfs,8191,4);
}
#ifndef SIX2_LIBRARY
int main(int argc,char**argv){
 info();for(int n=0;n<65536;n++){int v=1023;for(int i=0;i<16;i++)if(n>>i&1)v&=~N[i];safeRaw[n]=v;}
 for(int e=0;e<8192;e++)for(int c=0;c<1024;c++)if(popcount(unsigned(c))==4&&(e&~hot[c])==0){centersOK[e]=1;break;}
 unordered_set<U> ors(raw,raw+1024);map<U,vector<pair<int,int>>> by;
 for(int a=1;a<1024;a++)for(int b=a;b<1024;b++){
   int cost=popcount(unsigned(a|b))-1-(a&b?0:1);
   if(cost>8)continue;U h=raw[a]&raw[b];
   if(!(h&8191)||!(h>>13)||(h>>13)==65535||ors.count(h))continue;
   by[h].push_back({a,b});
 }
 vector<Feature> feats;map<int,long long> bc;vector<vector<int>> negIndex(65536);
 for(auto &[h,v]:by){Feature f{h,int(h&8191),int(h>>13),int(h&hot[safeRaw[h>>13]])};negIndex[f.hn].push_back(feats.size());feats.push_back(f);bc[f.base]++;}
 long long noCross=0;
 for(auto [a,na]:bc)for(auto [b,nb]:bc)if(a<=b&&centersOK[8191^(a|b)])noCross+=a==b?na*(na-1)/2:na*nb;
 long long disjCount=0,cross=0;
 for(int i=0;i<(int)feats.size();i++){
  auto a=feats[i];
  for(int n=65535^a.hn;n;n=(n-1)&(65535^a.hn))for(int j:negIndex[n])if(j>i){
    auto b=feats[j];disjCount++;if(!centersOK[8191^(a.base|b.base)]&&centersOK[8191^(a.base|b.base|(a.he&b.he))])cross++;
  }
 }
 map<pair<int,int>,vector<int>> byRole;
 for(int i=0;i<(int)feats.size();i++)byRole[{safeRaw[feats[i].hn],feats[i].base}].push_back(i);
 long long rolePairs=0,roleAccepted=0,rawSignatures=0,withCross=0,extra4=0,stored=0;
 ofstream result("six-two-parallel.tsv");
 auto record=[&](int i,int j){
   if(i>j)swap(i,j); rawSignatures++;
   if(stored++<200000)result<<feats[i].h<<'\t'<<feats[j].h<<'\n';
 };
 for(auto x=byRole.begin();x!=byRole.end();++x)for(auto y=x;y!=byRole.end();++y){
   auto [sx,bx]=x->first;auto [sy,by]=y->first;
   if(!bx||!by||!centersOK[8191^(bx|by)])continue;
   auto f=feats[x->second[0]],g=feats[y->second[0]];
   rolePairs++;
   if(!terminalFour(f,g,false))continue;
   roleAccepted++;
   for(int i:x->second)for(int j:y->second)if(x!=y||i<j){
     if(feats[i].hn&feats[j].hn)record(i,j);
   }
 }
 for(int i=0;i<(int)feats.size();i++){
   auto a=feats[i];for(int n=65535^a.hn;n;n=(n-1)&(65535^a.hn))for(int j:negIndex[n])if(j>i){
    auto b=feats[j];if(!centersOK[8191^(a.base|b.base|(a.he&b.he))])continue;
    withCross++;if(terminalFour(a,b,true)){extra4++;record(i,j);}
   }
 }
 cout<<"roles "<<byRole.size()<<" no-cross role pairs tried "<<rolePairs<<" accepted "<<roleAccepted
 <<" disjoint signature covers tried "<<withCross<<" accepted "<<extra4<<" total pass signature pairs "<<rawSignatures<<endl;
 cout<<"signatures "<<feats.size()<<" no-cross granted "<<noCross<<" disjoint-negative pairs "<<disjCount<<" additional crossed "<<cross<<endl;
}

#endif
