#define SIX2_LIBRARY
#include "six_two_parallel.cpp"
#include <unordered_map>
using Seg=pair<int,int>;
int main(){
 info();for(int n=0;n<65536;n++){int v=1023;for(int i=0;i<16;i++)if(n>>i&1)v&=~N[i];safeRaw[n]=v;}
 unordered_set<U> ors(raw,raw+1024);map<U,vector<Seg>> by;
 for(int a=1;a<1024;a++)for(int b=a;b<1024;b++){
  int cost=popcount(unsigned(a|b))-1-(a&b?0:1);U h=raw[a]&raw[b];
  if(cost<=8&&(h&8191)&&(h>>13)&&(h>>13)!=65535&&!ors.count(h))by[h].push_back({a,b});
 }
 vector<Feature> fs;for(auto &[h,v]:by)fs.push_back({h,int(h&8191),int(h>>13),int(h&hot[safeRaw[h>>13]])});
 int n=fs.size(),words=(n+63)/64;
 vector<vector<uint64_t>> allowed(29,vector<uint64_t>(words));
 for(int i=0;i<n;i++)for(int k=0;k<29;k++)if(((fs[i].h>>k)^int(k>=13))&1)allowed[k][i/64]|=uint64_t(1)<<(i%64);
 unordered_map<U,vector<int>> index;
 auto matching=[&](U s)->const vector<int>&{
  auto [it,add]=index.try_emplace(s);auto &out=it->second;if(!add)return out;
  for(int w=0;w<words;w++){uint64_t bits=~uint64_t(0);for(U j=s;j;j&=j-1)bits&=allowed[countr_zero(j)][w];while(bits){int i=w*64+countr_zero(bits);if(i<n)out.push_back(i);bits&=bits-1;}}
  return out;
 };
 ifstream in("six-two-soleQ-demands.tsv");U s;long long seedChecks=0,one=0,both=0;
 set<U> oneH,bothH;set<tuple<U,int,int,U>> physical; long long rawFive=0;
 while(in>>s){
  int t=s&8191,f=s>>13;
  for(int b=1;b<1024;b++)if(!(t&~hot[b])){
   int bad=f&(raw[b]>>13),amax=safeRaw[bad];
   for(int a=amax;;a=(a-1)&amax){
    int more=t&~hot[a];if(more){
     U d=U(more)|(U(bad)<<13);auto &hh=matching(d);one+=hh.size();oneH.insert(d);seedChecks++;
     for(int i:hh){U h=fs[i].h,q=(raw[a]|h)&raw[b];if(q>>13 && (q>>13)!=65535 && q!=h && !ors.count(q))physical.insert({h,a|1024,b,q});}
    }
    if(!a)break;
   }
  }
  for(int b=1;b<1024;b++){
   int amax=safeRaw[f&(raw[b]>>13)];
   for(int a=amax;;a=(a-1)&amax){
    if(a>=b){int more=t&~(hot[a]&hot[b]);if(more){U d=U(more)|(U(f)<<13);auto &hh=matching(d);both+=hh.size();bothH.insert(d);for(int i:hh){U h=fs[i].h,q=(raw[a]&raw[b])|h;if(q>>13 && (q>>13)!=65535 && q!=h && !ors.count(q))physical.insert({h,a|1024,b|1024,q});}}}
    if(!a)break;
   }
  }
 }
 ofstream tuples("six-two-soleQ-prefix.tsv");for(auto [h,a,b,q]:physical)tuples<<h<<'\t'<<a<<'\t'<<b<<'\t'<<q<<'\n';
 cout<<"unique physical H-trace/Q-source pairs "<<physical.size()<<"\n";
 cout<<"Q-only four-terminal requests; exact-one prefilter entries "<<one<<" two-H-arms prefilter entries "<<both<<" distinct first-H demand keys "<<oneH.size()<<'/'<<bothH.size()<<" keys cached "<<index.size()<<" one seed lookups "<<seedChecks<<endl;
}
