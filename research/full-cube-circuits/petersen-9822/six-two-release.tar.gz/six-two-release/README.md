# Original graph 9822, six AND gates and two hidden products

Run `python3 replay.py` with Python 3 and a C++20 compiler. It reconstructs all prefixes in a temporary directory, streams every physical family through independent support pricing, and checks counts and SHA-256 digests. This is a native supplement. The physical reduction uses collector isolation and the separate five-AND exclusion. The optional fixture search uses python-sat. The replay itself uses the standard library.

Four exposed products require three collector ORs. At most eight of the eleven physical ORs can generate input scopes. The ten raw labels occupy bits 0–9, H bit 10 and Q bit 11. The first four masks name the two original hidden products' operands. The last eight masks name the four terminal operand pairs. The induced-support bound preserves fanout. See six-induced-support.md.

|Construction of Q|Physical prefixes|Four-footprint covers|Physical scope tuples|Stream SHA-256|
|---|---:|---:|---:|---|
|Independent of H|13,308|34,454|196,694|80db7b0863c28f60f77b8b2308e537f355e3ba564ad52cc8dfb695f993f8a2f9|
|H on both operands|4,983|11,454|94,856|64927f667c7ca15a72d2ef823189f64d30b52712d7eb1f426eb6c69b53b1240d|
|H on one operand|28,042|82,147|380,860|5d9d2a56db7b559fffa2e3e951b8a1292d340f621308a83b1752529351664bdc|

Each terminal has an empty or singleton raw shore after orienting its baseline raw star. Two distinct raws on both shores would require a square. The classifier tries H and Q on either side, including opposite sides whenever their negative footprints are disjoint. It enumerates every compatible subset of the opposite raw shore, preserving redundant memberships during physical pricing.

For independent H and Q the classification uses exact positive and negative truth masks. When Q reads H on both arms, Q equals H OR the product of its raw shores. This identity supplies necessary four-terminal grant conditions. Both original attached operands are restored before pricing. A safe raw product yields a Q-dominating case handled by the Q-only seed generator.

For one-sided Q=(A OR H) AND B, every H/Q-facing terminal requires B to be cold wherever H is hot on negatives. Its H-and-Q positive contribution equals H-and-B and is already available to the H/raw grant. The edges remaining after four raw centers and all H/raw grants must therefore receive Q/raw coverage. The producer checks all raw A,B on the 210 H signatures allowing empty residuals, and covers nonempty residuals through minimal vertex covers and safe negative exclusions. H signatures with no raw grant reduce to Q-only terminal sufficiency. The 27,618 mixed and 4,529 Q-only one-sided prefixes yield 27,792 distinct keys.

Every support family exceeds the eight-edge budget. Two one-sided rows survive initial coarse pricing and have exact support optimum ten. Scope-count and digest replay are separate from kernel verification of the physical reduction.
