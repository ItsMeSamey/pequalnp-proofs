from itertools import combinations_with_replacement
from replay_h2 import E,hits,neg,free,union,minimal
neighbors=[union(e^(1<<v) for e in E if e>>v&1) for v in range(10)]
def roots():
 possible=set()
 for safe in set(free[1:]):
  modes={(0,safe)}
  for c in range(10):
   v=1<<c
   modes.add((hits[v],0))
   s=neighbors[c]&safe
   if s:modes.add((hits[v]&hits[s],s))
  for four in combinations_with_replacement(modes,4):
   base=union(x for x,_ in four)
   w=union(y for _,y in four)
   t=8191^base
   if not(t&~hits[w]):possible.add(t|(neg[w]<<13))
 return minimal(possible)
if __name__=='__main__':
 r=roots()
 print('one-direct-hidden demands',len(r),'safe types',len(set(free[1:])),*[hex(s) for s in r[:5]])
