#define SIX2_LIBRARY
#include "six_two_parallel.cpp"
#include <unordered_map>
struct Group {vector<Feature> fs;};
int main(){
 info();for(int n=0;n<65536;n++){int v=1023;for(int i=0;i<16;i++)if(n>>i&1)v&=~N[i];safeRaw[n]=v;}
 unordered_set<U> sig,ors(raw,raw+1024);map<int,Group> groups;
 for(int a=1;a<1024;a++)for(int b=a;b<1024;b++){
  U h=raw[a]&raw[b];if(popcount(unsigned(a|b))-1-(a&b?0:1)>8||!(h&8191)||!(h>>13)||(h>>13)==65535||ors.count(h)||!sig.insert(h).second)continue;
  Feature f{h,int(h&8191),int(h>>13),int(h&hot[safeRaw[h>>13]])};
  groups[f.base].fs.push_back(f);
 }
 vector<int> centers;for(int c=0;c<1024;c++)if(popcount(unsigned(c))==4)centers.push_back(hot[c]);
 vector<int> covers[8192];for(int e=0;e<8192;e++)for(int x=0;x<1024;x++)if(!(e&~hot[x])){
  bool ok=true;for(int y=x;y;y&=y-1)if(!(e&~hot[x^(y&-y)]))ok=false;
  if(ok)covers[e].push_back(x);
 }
 long long zeroBase=0,fullBase=0,tested=0,keyCnt=0,rawSets=0,matches=0,maxGroup=0;
 for(int e=0;e<8192;e++)for(int c:centers)if(!(e&~c)){centersOK[e]=1;break;}
 int allowedPos[65536];for(int n=0;n<65536;n++)allowedPos[n]=hot[safeRaw[65535^n]];
 ofstream output("six-two-one-mixed.tsv");
 long long eligible=0,records=0;
 for(auto &[base,g]:groups){
  auto &fs=g.fs;
  if(!base){zeroBase+=fs.size();continue;}
  unordered_map<uint64_t,bool> verdict;unordered_set<uint64_t> found;
  auto check=[&](const Feature &x,int a,int b){
   U q=(raw[a]|x.h)&raw[b];int qe=q&8191,qn=q>>13;
   if(!qe||!qn||qn==65535)return;
   int allowed=allowedPos[qn]|((x.hn&~qn)?0:x.he);
   if(!(qe&~allowed))return;
   int safe=safeRaw[qn],bq=qe&hot[safe];
   if(!centersOK[8191^(base|bq)])return;
   bool cross=(x.hn&qn)==0;
   if(!cross && !(bq&~base) && !(safe&~safeRaw[x.hn]))return;
   int roleA=base|(safeRaw[x.hn]<<13),roleB=bq|(safe<<13);
   uint64_t key=min(roleA,roleB)|(uint64_t(max(roleA,roleB))<<23)|
     (uint64_t(cross?((x.he&qe)|8192):0)<<46);
   auto [it,newKey]=verdict.try_emplace(key,false);
   if(newKey)it->second=terminalFour(x,{q,qe,qn,bq},true);
   if(it->second){eligible++;found.insert((uint64_t(x.h)<<20)|(U(a)<<10)|U(b));}
  };
  auto writeFound=[&](){
   vector<uint64_t> order(found.begin(),found.end());sort(order.begin(),order.end());
   for(auto z:order){U h=z>>20;int a=(z>>10)&1023,b=z&1023;output<<h<<'\t'<<(a|1024)<<'\t'<<b<<'\t'<<((raw[a]|h)&raw[b])<<'\n';}records+=found.size();
  };
  if(any_of(centers.begin(),centers.end(),[&](int c){return (base|c)==8191;})){
   for(auto &x:fs)for(int b=1;b<1024;b++)for(int a=0;a<1024;a++)check(x,a,b);
   fullBase+=fs.size();writeFound();continue;
  }
  vector<U> roots;
  for(int cm:centers){int t=8191^(cm|base);for(int x:covers[t]){
   U s=t|(U(raw[x]>>13)<<13);
   bool omit=false;for(int i=0;i<(int)roots.size();){U z=roots[i];if((s&z)==z){omit=true;break;}if((s&z)==s){roots[i]=roots.back();roots.pop_back();}else i++;}
   if(!omit)roots.push_back(s);
  }}
  int words=(fs.size()+63)/64;vector<vector<uint64_t>> allowed(29,vector<uint64_t>(words));
  for(int i=0;i<(int)fs.size();i++)for(int k=0;k<29;k++)if(((fs[i].h>>k)^int(k>=13))&1)allowed[k][i/64]|=uint64_t(1)<<(i%64);
  unordered_map<U,vector<int>> index;
  auto matching=[&](U s)->const vector<int>&{
   auto [it,ok]=index.try_emplace(s);auto &out=it->second;if(!ok)return out;
   for(int w=0;w<words;w++){uint64_t z=(w==words-1&&fs.size()%64 ? (uint64_t(1)<<(fs.size()%64))-1 : ~uint64_t(0));for(U j=s;j;j&=j-1)z&=allowed[countr_zero(j)][w];while(z){out.push_back(64*w+countr_zero(z));z&=z-1;}}
   return out;
  };
  long long sub=0;
  for(U s:roots){int t=s&8191,f=s>>13;
   for(int b=1;b<1024;b++)if(!(t&~hot[b])){
    int bad=f&(raw[b]>>13),amax=safeRaw[bad];
    for(int a=amax;;a=(a-1)&amax){
     U d=(t&~hot[a])|(U(bad)<<13);const auto &match=matching(d);sub+=match.size();for(int i:match)check(fs[i],a,b);rawSets++;
     if(!a)break;
    }
   }
  }
  writeFound();maxGroup=max(maxGroup,sub);matches+=sub;tested+=fs.size();keyCnt+=roots.size();
 }
 cout<<"distinct mixed physical Q+first H trace survivors "<<records<<" raw duplicate passes "<<eligible<<endl;
 cout<<"zero Hbase "<<zeroBase<<" base-alone-four-centers H "<<fullBase<<" other H "<<tested<<" minimal roots "<<keyCnt<<" shore lookups "<<rawSets<<" matched H/Q count with duplicates "<<matches<<" peak group "<<maxGroup<<endl;
}
