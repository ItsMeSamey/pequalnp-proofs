"""Regenerate and price the three exact original-scope streams. Python 3 and C++20."""
from hashlib import sha256
from pathlib import Path
from subprocess import run, Popen, PIPE
from tempfile import TemporaryDirectory
from sys import executable
from six_two_qdemands import roots
from verify_six_nested import verify as both
from verify_six_one_sided import verify as one
from verify_six_h2_order import classify
src = Path(__file__).resolve().parent
cases = [
    ("scopes", [], 196694, "80db7b0863c28f60f77b8b2308e537f355e3ba564ad52cc8dfb695f993f8a2f9", lambda s: classify(s)[1]),
    ("nested_scopes", ["both"], 94856, "64927f667c7ca15a72d2ef823189f64d30b52712d7eb1f426eb6c69b53b1240d", both),
    ("nested_scopes", ["six-two-one-all.tsv"], 380860, "5d9d2a56db7b559fffa2e3e951b8a1292d340f621308a83b1752529351664bdc", one),
]
with TemporaryDirectory() as name:
    work = Path(name)
    for prog in ["parallel", "sole", "one_mixed", "scopes", "nested_scopes"]:
        run(["g++","-std=c++20","-O3",src/("six_two_"+prog+".cpp"),"-o",work/prog],check=True)
    seeds = roots()
    if len(seeds) != 413:
        raise ValueError("Q-only seed count")
    (work/"six-two-soleQ-demands.tsv").write_text("".join(f"{x}\n" for x in seeds))
    for prog in ["parallel","sole","one_mixed"]:
        run([work/prog],cwd=work,check=True)
    run([executable,src/"six_two_one_union.py"],cwd=work,check=True)
    for prog,args,count,digest,price in cases:
        h = sha256()
        rows = 0
        with Popen([work/prog,*args,"--stream"],cwd=work,stdout=PIPE) as proc:
            for line in proc.stdout:
                h.update(line)
                rows += 1
                if price(list(map(int,line.split()))) <= 8:
                    raise ValueError((args,rows,line))
        if proc.returncode or rows != count or h.hexdigest() != digest:
            raise ValueError((args,rows,h.hexdigest(),proc.returncode))
        print(args, rows, digest, flush=True)
