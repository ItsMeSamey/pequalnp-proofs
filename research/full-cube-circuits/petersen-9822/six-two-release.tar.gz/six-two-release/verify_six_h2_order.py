"""Certify printed twelve-scope parallel h2 records with support graph budgets eight."""
import sys
from collections import Counter
from or_order_bound import increment,certificate

def classify(scopes):
    if len(scopes)!=12 or any(not 0<m<4096 for m in scopes):
        raise ValueError("expected twelve nonempty masks on twelve primitive labels")
    intervals=[(m,m) for m in scopes]
    ids=list(range(12))
    orders=[('forward',ids),('reverse',ids[::-1]),('small',sorted(ids,key=lambda i:scopes[i].bit_count())),('large',sorted(ids,key=lambda i:-scopes[i].bit_count()))]
    for name,order in orders:
        value=prior=0
        for i in order:
            value+=increment(intervals,prior,i)
            prior|=1<<i
        if value>=9:return name,value
    value,_=certificate(intervals,9)
    return ('searched' if value>=9 else 'unresolved'),value

if __name__=='__main__':
    print(dict(sorted(Counter(classify(list(map(int,r.split()))) for r in sys.stdin).items())))
