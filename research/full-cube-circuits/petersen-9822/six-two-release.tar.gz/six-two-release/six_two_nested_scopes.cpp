#define SIX2_SCOPE_LIBRARY
#include "six_two_scopes.cpp"
#include <tuple>
using Tup=tuple<U,int,int,U>;
int main(int argc,char**argv){
 if(argc<2)return 1;
 bool stream=argc>2&&string(argv[2])=="--stream";
 info();for(int n=0;n<65536;n++){int v=1023;for(int i=0;i<16;i++)if(n>>i&1)v&=~N[i];safeRaw[n]=v;}
 auto feat=[](U z){return Feature{z,int(z&8191),int(z>>13),int(z&hot[safeRaw[z>>13]])};};
 map<U,vector<Seg>> by;
 for(int a=1;a<1024;a++)for(int b=a;b<1024;b++)if(popcount(unsigned(a|b))-1-(a&b?0:1)<=8)by[raw[a]&raw[b]].push_back({a,b});
 U h,q;int a,b;set<Tup> candidates;ifstream only("six-two-soleQ-prefix.tsv");
 if(string(argv[1])=="both"){
  while(only>>h>>a>>b>>q)if((a&b&1024)&&!((raw[a&1023]&raw[b&1023])>>13))candidates.insert({h,min(a,b),max(a,b),q});
  ifstream par("six-two-parallel.tsv");U x,y;
  while(par>>x>>y)for(auto [f,p]:vector<pair<U,U>>{{x,y},{y,x}}){
   U g=f|p;if((g>>13)==65535)continue;
   for(auto [l,r]:by[p])if(popcount(unsigned(l|r))<=8)candidates.insert({f,l|1024,r|1024,g});
  }
 }else if(string(argv[1])=="sole"){
  while(only>>h>>a>>b>>q)if((a&1024)&&!(b&1024))candidates.insert({h,min(a,b),max(a,b),q});
 }else{
  ifstream custom(argv[1]);while(custom>>h>>a>>b>>q)candidates.insert({h,min(a,b),max(a,b),q});
 }
 long long tested=0,kept=0,prefixes=0,covers=0,all=0,pass=0;
 set<vector<int>> unmatched;ofstream residual(string(argv[1])+".residual.tsv");
 bool control=false;map<pair<U,U>,bool> passes;
 for(auto [f,l,r,g]:candidates){
  auto pair=make_pair(f,g);bool keep;
  if(!passes.count(pair))passes[pair]=terminalFour(feat(f),feat(g),true);
  if(!passes[pair])continue;
  kept++;auto cat=fullCatalog(feat(f),feat(g));
  for(auto hp:by[f]){
   prefixes++;covers+=cat.covers.size();
   for(auto masks:cat.covers){
    array<Seg,4> ts;
    auto expand=[&](auto&&self,int d)->void{
     if(d<4){for(auto p:cat.choices[masks[d]]){ts[d]=p;self(self,d+1);}return;}
     all++;auto sorted=ts;sort(sorted.begin(),sorted.end());
     if(hp==Seg{40,320}&&l==1232&&r==1600){
      vector<Seg>want={{4,130},{770,2048},{32,129},{9,16}};sort(want.begin(),want.end());
      if(equal(sorted.begin(),sorted.end(),want.begin()))control=true;
     }
     if(stream){cout<<hp.first<<'\t'<<hp.second<<'\t'<<l<<'\t'<<r;for(auto [x,y]:sorted)cout<<'\t'<<x<<'\t'<<y;cout<<'\n';}
     vector<int>s={hp.first,hp.second,l,r};for(auto [x,y]:sorted){s.push_back(x);s.push_back(y);}
     erase_if(s,[](int z){return popcount(unsigned(z))<2;});sort(s.begin(),s.end());s.erase(unique(s.begin(),s.end()),s.end());
     if(priced(s)){pass++;if(unmatched.insert(s).second){for(int z:s)residual<<z<<' ';residual<<'\n';}}
    };expand(expand,0);
   }
  }
 }
 cerr<<argv[1]<<" first H trace + actual Q candidates "<<candidates.size()<<" pass terminal grants "<<kept<<" full physical prefixes "<<prefixes<<" covers "<<covers<<" scope tuples "<<all<<" coarse remaining "<<pass<<" unique "<<unmatched.size()<<" both control "<<control<<endl;
}
