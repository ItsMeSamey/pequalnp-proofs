#define SIX2_LIBRARY
#include "six_two_parallel.cpp"
using Seg=pair<int,int>;
struct AllScopes { map<int,vector<Seg>> choices; vector<array<int,4>> covers; };
AllScopes fullCatalog(Feature a,Feature b) {
 AllScopes cat;set<Seg> seen;
 for(int c=-1;c<10;c++){
  int bit=c<0?0:(1<<c);
  for(int hu=0;hu<3;hu++)for(int qu=0;qu<3;qu++){
   int ls=bit|(hu==1?1024:0)|(qu==1?2048:0), rs=(hu==2?1024:0)|(qu==2?2048:0);
   if(!ls)continue;
   int ln=(raw[bit]>>13)|(hu==1?a.hn:0)|(qu==1?b.hn:0);
   int rn=(hu==2?a.hn:0)|(qu==2?b.hn:0);
   if(ln&rn)continue;
   int lp=hot[bit]|(hu==1?a.he:0)|(qu==1?b.he:0);
   int rp=(hu==2?a.he:0)|(qu==2?b.he:0),allow=safeRaw[ln];
   for(int r=allow;;r=(r-1)&allow){
    Seg pair=minmax(ls,r|rs);int m=lp&(rp|hot[r]);
    if(m&&seen.insert(pair).second)cat.choices[m].push_back(pair);
    if(!r)break;
   }
  }
 }
 vector<int> ms;for(auto &[m,z]:cat.choices)ms.push_back(m);
 sort(ms.begin(),ms.end(),[](int a,int b){int pa=popcount(unsigned(a)),pb=popcount(unsigned(b));return pa==pb?a<b:pa>pb;});
 int n=ms.size();vector<int> tail(n+1,0);for(int i=n-1;i>=0;i--)tail[i]=tail[i+1]|ms[i];
 array<int,4> row;
 auto visit=[&](auto&&self,int k,int start,int got)->void{
  if(got==8191){if(k!=4)abort();cat.covers.push_back(row);return;}
  if(k==4 || start+4-k>n || (got|tail[start])!=8191)return;
  int need=popcount(unsigned(8191^got));
  for(int i=start;i+4-k<=n;i++){
   int m=ms[i];if(popcount(unsigned(m))*(4-k)<need)break;
   if(!(m&~got))continue;row[k]=m;self(self,k+1,i+1,got|m);
  }
 };visit(visit,0,0,0);return cat;
}
bool priced(const vector<int>&s){
 vector<int> forced,remain,price;
 for(int x:s)if(popcount(unsigned(x))==2)forced.push_back(x);
 if(forced.size()>8)return false;
 for(int x:s)if(popcount(unsigned(x))>2){
   int cc[12];for(int i=0;i<12;i++)cc[i]=i;
   auto root=[&](int i){while(cc[i]!=i)i=cc[i];return i;};
   int rank=popcount(unsigned(x))-1;
   for(int e:forced)if(!(e&~x)){
     int i=root(countr_zero(unsigned(e))),j=root(31-countl_zero(unsigned(e)));
     if(i!=j){cc[i]=j;rank--;}
   }
   if(rank){remain.push_back(x);price.push_back(rank);}
 }
 int n=remain.size(),budget=8-forced.size();
 auto pack=[&](auto&&self,int pos,int selected,int total)->bool{
   if(total>budget)return true;
   for(int i=pos;i<n;i++){
     bool compatible=true;
     for(int j=0;j<i;j++)if(selected>>j&1 && popcount(unsigned(remain[i]&remain[j]))>1){compatible=false;break;}
     if(compatible&&self(self,i+1,selected|(1<<i),total+price[i]))return true;
   }return false;
 };
 return !pack(pack,0,0,0);
}
#ifndef SIX2_SCOPE_LIBRARY
int main(int argc,char**argv){
 info();for(int n=0;n<65536;n++){int v=1023;for(int i=0;i<16;i++)if(n>>i&1)v&=~N[i];safeRaw[n]=v;}
 map<U,vector<Seg>> by;
 for(int x=1;x<1024;x++)for(int y=x;y<1024;y++)if(popcount(unsigned(x|y))-1-(x&y?0:1)<=8)by[raw[x]&raw[y]].push_back({x,y});
 ifstream in("six-two-parallel.tsv");ofstream out("six-two-parallel-residual.tsv");
 bool stream=argc>1&&string(argv[1])=="--stream";
 U h,q;int idx=0,start=(!stream&&argc>1)?atoi(argv[1]):0,stop=(!stream&&argc>2)?atoi(argv[2]):999999;
 long long priors=0,covers=0,all=0,pass=0,emitted=0;set<vector<int>> uniq;bool fixture=false;
 while(in>>h>>q){
  int id=idx++;if(id<start||id>=stop)continue;
  auto feat=[&](U z){return Feature{z,int(z&8191),int(z>>13),int(z&hot[safeRaw[z>>13]])};};
  auto cat=fullCatalog(feat(h),feat(q));
  for(Seg hp:by[h])for(Seg qp:by[q]){
   priors++;covers+=cat.covers.size();
   for(auto masks:cat.covers){
    array<Seg,4> terms;
    auto expand=[&](auto&&self,int d)->void{
     if(d==4){
      all++;if(stream){auto sorted=terms;sort(sorted.begin(),sorted.end());cout<<hp.first<<'\t'<<hp.second<<'\t'<<qp.first<<'\t'<<qp.second;for(auto [l,r]:sorted)cout<<'\t'<<l<<'\t'<<r;cout<<'\n';}vector<int>s={hp.first,hp.second,qp.first,qp.second};
      for(auto [l,r]:terms){s.push_back(l);s.push_back(r);}
      if(hp==Seg{68,130}&&qp==Seg{72,288}){
       auto remap=[](int m){return (m&1023)|((m&1024)<<1)|((m&2048)>>1);};
       set<Seg> control,seenTerms;for(auto [l,r]:terms)seenTerms.insert(minmax(remap(l),remap(r)));
       for(auto x:vector<Seg>{{208,512},{1056,385},{16,521},{2048,774}})control.insert(minmax(x.first,x.second));
       if(control==seenTerms)fixture=true;
      }
      erase_if(s,[](int x){return popcount(unsigned(x))<2;});sort(s.begin(),s.end());s.erase(std::unique(s.begin(),s.end()),s.end());
      if(priced(s)){pass++;if(uniq.insert(s).second&&emitted<100000){emitted++;out<<hp.first<<'\t'<<hp.second<<'\t'<<qp.first<<'\t'<<qp.second;for(auto [l,r]:terms)out<<'\t'<<l<<'\t'<<r;out<<'\n';}}
      return;
     }
     for(auto s:cat.choices[masks[d]]){terms[d]=s;self(self,d+1);}
    };expand(expand,0);
   }
  }
 }
 cerr<<"parallel signature range "<<start<<".."<<min(stop,idx)<<" original-prefix pairs "<<priors<<" covered 4-mask families "<<covers<<" exact-source tuples "<<all
 <<" coarse remain "<<pass<<" distinct remaining "<<uniq.size()<<" stored "<<emitted<<" control "<<fixture<<endl;
}

#endif
