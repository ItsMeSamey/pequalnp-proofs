#include <algorithm>
#include <bit>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <unordered_set>
#include <vector>
using namespace std;using U=uint32_t;
int edges[13]={6,24,17,33,66,132,264,528,160,640,576,320,288};
int N[16],ins[1024],hot[1024],joinE[16][16],adj[16];U raw[1024];
bool clique(unsigned s,int k){
 if(!k)return true;
 while(popcount(s)>=k){int i=countr_zero(s);s&=s-1;if(clique(s&adj[i],k-1))return true;}
 return false;
}
void incompat(U h,U q){
 int he=h&8191,qe=q&8191;unsigned hn=h>>13,qn=q>>13;
 for(int i=0;i<16;i++){int x=0;
  for(int j=i+1;j<16;j++){unsigned pair=(1<<i)|(1<<j);int use=((hn&pair)?0:he)|((qn&pair)?0:qe);if(joinE[i][j]&~use)x|=1<<j;}adj[i]=x;
 }
}
void info(){
 int k=0;
 for(int s=0;s<1024;s++)for(int i=0;i<13;i++){if(s&edges[i])hot[s]|=1<<i;if((s&edges[i])==edges[i])ins[s]|=1<<i;}
 for(int s=0;s<1024;s++)if(!ins[s]){bool m=true;for(int i=0;i<10;i++)if(!(s>>i&1)&&!ins[s|(1<<i)])m=false;if(m)N[k++]=s;}
 if(k!=16)abort();
 for(int i=0;i<16;i++)for(int j=0;j<16;j++)joinE[i][j]=ins[N[i]|N[j]];
 for(int s=0;s<1024;s++){raw[s]=hot[s];for(int i=0;i<16;i++)if(s&N[i])raw[s]|=1u<<(13+i);}
}
bool hidden(U z){if(!(z>>13))return false;for(int i=0;i<10;i++)if(!((z&8191)&~hot[1<<i]))return false;return true;}
int main(int argc,char**argv){
 int h=argc>3?atoi(argv[3]):3;int firstCap=h==2?15:13;int secondCap=h==2?8:7;
 info();unordered_set<U> hs;
 for(int a=1;a<1024;a++)for(int b=(1023^a);b;b=(b-1)&(1023^a))if(a>b){U h=raw[a]&raw[b];if(hidden(h))hs.insert(h);}
 vector<U> hf;for(auto h:hs){incompat(h,0);if(!clique(65535,firstCap+1))hf.push_back(h);}
 sort(hf.begin(),hf.end());cout<<"first "<<hf.size()<<endl;
 int begin=argc>1?atoi(argv[1]):0,end=argc>2?min((int)hf.size(),atoi(argv[2])):hf.size();
 long long total=0,surv=0;int aliveH=0;
 for(int k=begin;k<end;k++){
  U h=hf[k];unordered_set<U> qs;
  for(int a=0;a<1024;a++){int allowed=1023^a;for(int b=allowed;b;b=(b-1)&allowed){
   U q0=raw[a]&raw[b],q1=(raw[a]|h)&raw[b];if(hidden(q0))qs.insert(q0);if(hidden(q1))qs.insert(q1);
  }}
  bool found=false;for(U q:qs){if(q==h)continue;total++;incompat(h,q);
   if(!clique(65535,secondCap+1)){surv++;found=true;if(surv<=100)cout<<"survivor "<<k<<' '<<h<<' '<<q<<endl;}}
  aliveH+=found;
 }cout<<"tested "<<total<<" no eight-clique "<<surv<<" first H surviving "<<aliveH<<endl;
}
