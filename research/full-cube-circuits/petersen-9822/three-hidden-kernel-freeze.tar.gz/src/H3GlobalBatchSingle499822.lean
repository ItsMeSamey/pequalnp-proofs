import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle49 : List ModeRow := [(6522640,[45852,16575,58119,27677,21916,12351,9127],[45852,16575,9127,22293,27677,43573])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle49 : batchSingle49.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
