import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle303 : List ModeRow := [(445778001,[54812,10471,15414,53399,19635,21692],[54812,15538,10471,53399,13494])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle303 : batchSingle303.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
