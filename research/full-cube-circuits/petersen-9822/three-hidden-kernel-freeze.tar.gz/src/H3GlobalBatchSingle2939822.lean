import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle293 : List ModeRow := [(433706796,[50766,4018,14479,51751,54497,21902,11923],[50766])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle293 : batchSingle293.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
