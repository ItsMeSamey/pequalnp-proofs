import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle31 : List ModeRow := [(4514966,[37671,3259,23310,17850,11047,11319,13079,4018,16703,18867],[37671,3135,23310,11047,17850,4018])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle31 : batchSingle31.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
