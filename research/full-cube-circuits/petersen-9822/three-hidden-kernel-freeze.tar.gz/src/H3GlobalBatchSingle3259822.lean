import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle325 : List ModeRow := [(505840334,[61748,6983,53489,21852,51315,49621,9111,20924,4957],[61748])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle325 : batchSingle325.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
