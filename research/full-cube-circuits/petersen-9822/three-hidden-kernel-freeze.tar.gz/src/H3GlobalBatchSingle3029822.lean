import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle302 : List ModeRow := [(445657889,[50970,14479,21937,29974,54437,11023,58391,47747,13343,38043],[54437,50970,27399,38043,13343,5911])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle302 : batchSingle302.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
