import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle301 : List ModeRow := [(445646865,[54444,45402,15507,43207,21902,52371,29862,3863],[54444,15762,45402,52371,10471,15383,29862])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle301 : batchSingle301.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
