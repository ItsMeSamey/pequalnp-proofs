import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle305 : List ModeRow := [(446824646,[55064,10551,52275,45223,21937,45339,3639,4919],[55064,21938,52275,49593,41639])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle305 : batchSingle305.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
