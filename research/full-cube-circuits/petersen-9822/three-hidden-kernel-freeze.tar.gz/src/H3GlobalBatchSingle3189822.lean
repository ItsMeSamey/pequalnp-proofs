import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle318 : List ModeRow := [(493618225,[60200,8935,7409,9070,2033,21937,27057,52010,10951],[60200,8935,22979,5617,7409])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle318 : batchSingle318.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
