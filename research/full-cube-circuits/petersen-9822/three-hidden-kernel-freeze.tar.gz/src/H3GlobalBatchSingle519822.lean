import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle51 : List ModeRow := [(6707208,[37690,20291,6255,19890,49495,2919,3315,12575],[37690,887,19890,49275,39463,831,35103,20291])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle51 : batchSingle51.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
