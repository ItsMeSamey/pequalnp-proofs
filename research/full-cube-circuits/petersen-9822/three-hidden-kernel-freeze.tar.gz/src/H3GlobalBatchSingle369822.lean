import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle36 : List ModeRow := [(4988977,[11047,21969,34027,35437,4974,39055,5231,751,943,6823],[35437,21969,10471,4974,16889,39055,22310,751,34027,5231])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle36 : batchSingle36.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
