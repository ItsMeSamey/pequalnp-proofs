import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle6 : List ModeRow := [(284680,[37678,19890,13071,19239,3315,18719],[37678,19890,19239,3315,13071,34939,831,35103])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle6 : batchSingle6.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
