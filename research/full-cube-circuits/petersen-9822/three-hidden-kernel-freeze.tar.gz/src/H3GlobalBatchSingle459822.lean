import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle45 : List ModeRow := [(6410016,[54030,12979,21932,43783,12351,17019],[54030,831,12399,43783,13234,21866])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle45 : batchSingle45.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
