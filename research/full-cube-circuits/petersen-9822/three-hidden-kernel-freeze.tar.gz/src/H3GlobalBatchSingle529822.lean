import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle52 : List ModeRow := [(6743702,[37686,24323,2287,19230,12695,20977,11047,2803,863,16890],[37686,831,887])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle52 : batchSingle52.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
