import H3GlobalPages9822
import H3Global38Mode09822
import H3Global38Mode19822
namespace Research.Graph9822Planes
def batchSingle38 : List ModeRow := [(5246988,[19890,37804,50417,891,52003,6859,17819,28779,1914,1011,17905,55435],[37804,19890,50417,891,52003,6859,17819,1011,55435,1914,28779,13219,18289])]
theorem paidBatchSingle38 : batchSingle38.all rowOK = true := by
  change ((global3 _ false _ && global3 _ true _) && true) = true
  exact Bool.and_eq_true_iff.mpr ⟨Bool.and_eq_true_iff.mpr ⟨g38_0,g38_1⟩,rfl⟩
end Research.Graph9822Planes
