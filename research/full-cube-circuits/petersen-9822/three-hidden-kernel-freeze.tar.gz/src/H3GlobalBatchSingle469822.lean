import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle46 : List ModeRow := [(6424080,[62232,759,16829,21976,21647,831,16823,21955,639,751,52253],[62232,9139,21647,21976,52253,751,17877,639])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle46 : batchSingle46.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
