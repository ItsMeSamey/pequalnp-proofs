import H3GlobalPages9822
import H3Global47Mode09822
import H3Global47Mode19822
namespace Research.Graph9822Planes
def batchSingle47 : List ModeRow := [(6426128,[62232,639,49463,21913,21647,22339,9139,50965,4926,33639,45763,52253],[62232,9139,18261,21647,4926,49463,33687,52253,45763])]
theorem paidBatchSingle47 : batchSingle47.all rowOK = true := by
  change ((global3 _ false _ && global3 _ true _) && true) = true
  exact Bool.and_eq_true_iff.mpr ⟨Bool.and_eq_true_iff.mpr ⟨g47_0,g47_1⟩,rfl⟩
end Research.Graph9822Planes
