import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle5 : List ModeRow := [(279684,[37438,17623,5369,35431,20767,1151,1275,61523,3231,23606,1343,18791],[37438,18791,19515,61523,17726,1275,35431,3135,3231,23606,17623])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle5 : batchSingle5.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
