import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle327 : List ModeRow := [(506560718,[61740,7566,31121,21678,43063,6927,14479,14621],[61740,7566,14621,14479])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle327 : batchSingle327.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
