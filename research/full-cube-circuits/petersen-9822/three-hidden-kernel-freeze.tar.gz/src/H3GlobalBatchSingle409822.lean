import H3GlobalPages9822
import H3Global40Mode09822
import H3Global40Mode19822
namespace Research.Graph9822Planes
def batchSingle40 : List ModeRow := [(5771532,[4018,52042,57812,50417,19192,17898,3787,22683,2010,52530],[19192,41699,57812,2010,52530,49786,28913,17898,55435,3954])]
theorem paidBatchSingle40 : batchSingle40.all rowOK = true := by
  change ((global3 _ false _ && global3 _ true _) && true) = true
  exact Bool.and_eq_true_iff.mpr ⟨Bool.and_eq_true_iff.mpr ⟨g40_0,g40_1⟩,rfl⟩
end Research.Graph9822Planes
