import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle32 : List ModeRow := [(4718860,[52530,45928,49339,51089,18289,3706,55435,1003,1914,2875],[45928,19890,35531,51089,49339,1914,50417,1003,2875,3195,18289,52530,55435])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle32 : batchSingle32.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
