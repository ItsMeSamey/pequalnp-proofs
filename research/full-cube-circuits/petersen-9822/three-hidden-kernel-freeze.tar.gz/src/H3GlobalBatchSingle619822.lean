import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle61 : List ModeRow := [(25581640,[7738,49499,14887,1823,6735,10583,5497,10855,3195,383,831],[7738,3195,10551,17246,3359,10855,1913])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle61 : batchSingle61.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
