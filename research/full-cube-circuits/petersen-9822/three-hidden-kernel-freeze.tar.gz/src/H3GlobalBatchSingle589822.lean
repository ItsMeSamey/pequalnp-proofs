import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle58 : List ModeRow := [(7483024,[4926,17877,33487,49463,21955,1017,37479,639,17394,45969,49935,759,16829],[45969,1017,951,17877,49215,20667,975])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle58 : batchSingle58.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
