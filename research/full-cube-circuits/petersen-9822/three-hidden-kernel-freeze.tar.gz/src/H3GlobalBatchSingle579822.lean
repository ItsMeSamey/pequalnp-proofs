import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle57 : List ModeRow := [(7343744,[4926,53713,16871,49950,21420,4815,16829,639,999,16823],[21420,33687,4223,16871,49950,9139,53713,16823])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle57 : batchSingle57.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
