import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle39 : List ModeRow := [(5254288,[17183,21916,5339,50327,45969,50965,16855,21969,18386,983,1751],[45969,1751,49935,21916,17877,5339,30098,5215,18386])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle39 : batchSingle39.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
