import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle4 : List ModeRow := [(116512,[61966,763,9127,16575,5582,12967,41767,4223,507,4511],[61966,16575,5582,12979,41767,4511,4223])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle4 : batchSingle4.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
