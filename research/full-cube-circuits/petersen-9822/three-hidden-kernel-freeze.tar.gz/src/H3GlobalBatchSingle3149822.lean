import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle314 : List ModeRow := [(492840081,[60200,751,22979,2847,49625,41863,2767,6867,26655,11155,27022,51994],[60200,14995,41863,44124])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle314 : batchSingle314.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
