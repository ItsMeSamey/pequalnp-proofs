import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle30 : List ModeRow := [(4203664,[49965,14226,21955,4335,17877,54030,21916,18386,33687,33703,5215],[49965,14226,4815,21969,54030,5339,21916,33703,5215,18386,927])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle30 : batchSingle30.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
