import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle313 : List ModeRow := [(492831761,[60200,8935,10590,27022,51994,6867,43921,32144],[60200,15250,27022,44124,8935,6097,10951])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle313 : batchSingle313.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
