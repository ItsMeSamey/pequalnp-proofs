import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle60 : List ModeRow := [(25579848,[36410,8543,26919,5593,12958,5558,10478,5407,383],[36410,7475,3135,5558,15431,3706,10471,26919])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle60 : batchSingle60.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
