import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle33 : List ModeRow := [(4818688,[53868,8663,831,45199,5081,12726,4815,41191],[53868,927,12351,45490,41191,45366,831,12979,45199])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle33 : batchSingle33.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
