import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle320 : List ModeRow := [(497943601,[59704,3911,41427,15411,52275,10471,49495,57399,1470],[59704,887,43207,1470])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle320 : batchSingle320.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
