import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle55 : List ModeRow := [(7013904,[45912,52253,21969,4287,887,16823,751,16829,639,759],[45912,1017,17877,52253,639,16823,4335])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle55 : batchSingle55.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
