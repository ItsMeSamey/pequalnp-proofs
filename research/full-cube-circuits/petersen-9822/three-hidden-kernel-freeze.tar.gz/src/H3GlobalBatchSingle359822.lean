import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle35 : List ModeRow := [(4835104,[53838,12979,43095,1017,5575,12967,447,763,41191,831,507,2519],[53838,751,12351,14802,5575,831,41191,12967,447,763])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle35 : batchSingle35.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
