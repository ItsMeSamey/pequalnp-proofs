import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle43 : List ModeRow := [(6295040,[54060,12979,49950,20921,16871,1017,4926,45731,49463],[54060,9139,49950,20921,53713,4926,33687,35685,45731,49463,16871])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle43 : batchSingle43.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
