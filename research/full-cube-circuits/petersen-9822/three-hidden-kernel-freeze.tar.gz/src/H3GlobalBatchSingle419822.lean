import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle41 : List ModeRow := [(5869836,[19766,34540,39055,894,17653,35047,1785,12399],[34540,2767,19890,49719,19766,703,35047])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle41 : batchSingle41.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
