import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle299 : List ModeRow := [(444610576,[63016,11031,52251,12399,22279,15638,7199],[63016,22279,47119,45402,19487,21895,11031])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle299 : batchSingle299.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
