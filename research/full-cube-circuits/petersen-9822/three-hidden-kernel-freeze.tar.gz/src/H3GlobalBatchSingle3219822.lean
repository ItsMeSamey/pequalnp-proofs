import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle321 : List ModeRow := [(498207761,[1470,60696,52295,3763,26375,45459],[60696,1971,10471,958])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle321 : batchSingle321.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
