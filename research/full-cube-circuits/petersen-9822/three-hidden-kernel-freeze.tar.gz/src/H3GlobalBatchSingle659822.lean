import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle65 : List ModeRow := [(26179914,[3643,49619,6735,1017,39139,17246,14887,1823,5603,383],[3643,49649])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle65 : batchSingle65.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
