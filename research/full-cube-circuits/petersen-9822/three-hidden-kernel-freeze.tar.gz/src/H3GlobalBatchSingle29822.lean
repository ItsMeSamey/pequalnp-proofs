import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle2 : List ModeRow := [(108416,[41773,8663,37603,12732,16575,4223,41191,20667,507],[41773,255,45199,12414,989,8631,12732,509,37603,4319,4597])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle2 : batchSingle2.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
