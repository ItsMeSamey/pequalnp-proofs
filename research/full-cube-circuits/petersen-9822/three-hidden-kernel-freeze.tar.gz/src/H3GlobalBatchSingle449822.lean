import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle44 : List ModeRow := [(6409760,[54030,12979,25383,16829,17019,21866,4985,45607,4223],[54030,831,43783,12399,4985])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle44 : batchSingle44.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
