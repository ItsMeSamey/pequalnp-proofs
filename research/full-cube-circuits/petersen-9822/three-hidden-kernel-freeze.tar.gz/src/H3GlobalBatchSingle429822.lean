import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle42 : List ModeRow := [(6052108,[4018,51727,21222,35047,29070,19766,3315,2767,17639],[21222,3315,51727,703,2299,52881,3702,24791])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle42 : batchSingle42.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
