import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle64 : List ModeRow := [(26179658,[3643,49619,6735,1017,14887,17246,39139,1895,1823],[3643,49649])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle64 : batchSingle64.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
