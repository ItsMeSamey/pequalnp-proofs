import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle50 : List ModeRow := [(6524688,[45852,49215,58119,13710,27677,43573,21916,12351],[45852,831,57623,13455,21916,27677])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle50 : batchSingle50.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
