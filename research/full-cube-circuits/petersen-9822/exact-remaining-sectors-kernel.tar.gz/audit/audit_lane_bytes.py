"""Compare all 29 q rows with direct ordered source pairs, independent of producer."""
import hashlib,json,re
from pathlib import Path
from itertools import combinations
root=Path('/workspace/scratch/official9822-lean')
src=(root/'H23TernaryPlanes9822.lean').read_text()
g=(root/'H3GlobalPlanes9822.lean').read_text()
def nums(t,k):return list(map(int,re.findall(r'\d+',t.split('def '+k,1)[1].split('#[',1)[1].split(']',1)[0])))
pairs=[(1,2),(3,4),(0,4),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(6,9),(6,8),(5,8)]
E=[1<<v|1<<w for v,w in pairs]
neg=[n for n in range(1024) if all(n&e!=e for e in E) and all(any((n|1<<v)&e==e for e in E) for v in range(10) if not n>>v&1)]
rows=E+neg;assert nums(src,'srcRows')==rows
assert nums(g,'allInside')==[sum(1<<e for e,edge in enumerate(E) if edge&(a|b)==edge) for a in neg for b in neg]
width=59049;size=(width+7)//8;ones=(1<<width)-1
assert re.search(r'def width : Nat := 59049\b',src)
def bitplane(v,d):
 k=3**v;return ones//((1<<(3*k))-1)*((1<<k)-1)<<(d*k)
axis=[[bitplane(v,d) for v in range(10)] for d in (1,2)]
words=[]
for r in rows:
 left,right=[__import__('functools').reduce(int.__or__,[s[v] for v in range(10) if r>>v&1],0) for s in axis]
 words.append((left&right,right))
buf=[[bytearray(size),bytearray(size)] for _ in rows]
powers=[sum(3**v for v in range(10) if a>>v&1) for a in range(1024)]
flags=[tuple(i for i,r in enumerate(rows) if raw&r) for raw in range(1024)]
seen=bytearray(width)
for a in range(1024):
 space=1023^a;b=space
 while True:
  j=powers[a]+2*powers[b]
  assert j<width and not seen[j];seen[j]=1
  index=j//8;one=1<<(j%8)
  for i in flags[b]:
   buf[i][1][index]|=one
   if a&rows[i]:buf[i][0][index]|=one
  if b==0:break
  b=(b-1)&space
assert all(seen)
for i in range(len(rows)):
 for j in range(2):
  assert words[i][j].to_bytes(size,'little')==buf[i][j]
  assert buf[i][j][-1]>>1==0
report={'lanes':width,'rows':len(rows),'row_branches_per_lane':2,'bits_checked':width*len(rows)*2,'limbs64':(width+63)//64,'valid_bits_last_limb':width%64,'stream_sha256':hashlib.sha256(b''.join(b for pair in buf for b in pair)).hexdigest(),'source_hashes':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ('H23TernaryPlanes9822.lean','H3GlobalPlanes9822.lean')}}
Path(__file__).with_name('lane-bytes.json').write_text(json.dumps(report,indent=2)+'\n')
print(report)
