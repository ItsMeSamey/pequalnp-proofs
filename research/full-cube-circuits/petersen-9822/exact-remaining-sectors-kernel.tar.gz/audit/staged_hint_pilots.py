"""Read four emitted Lean theorem literals and independently replay their scalar semantics."""
import ast,json,re
from pathlib import Path
from itertools import combinations
exec(Path(__file__).with_name('ternary_crosscheck.py').read_text().split('bind()\nfor h')[0])
D=Path('/dev/shm/9822-static-fixed/h3lean')
plan=json.loads((P/'h3-global-clauses.json').read_text())
ex={(786481,q) for q in (5047856,788144,26106200,788016,26106184,26106216)}|{(26106184,786481)}
records={}
for k in (112,294):
 for mode in range(2):
  name=f'H3Global{k}Mode{mode}9822'
  src=(D/(name+'.lean')).read_text()
  m=re.search(r'global3 (\d+) (false|true) (\[[0-9, ]*\]) = true',src)
  h=int(m[1]);attach=m[2]=='true';hints=ast.literal_eval(m[3])
  assert (h,attach,hints)==(plan[k][0],bool(mode),plan[k][1][mode])
  rows=[]
  for hinted in hints:
   ds=[]
   for i,j in combinations([r for r in range(16) if hinted>>r&1],2):
    mask=(1<<i)|(1<<j);joined=N[i]|N[j]
    need=sum(1<<r for r,e in enumerate(E) if e&joined==e)
    if not mask&(h>>13):need&=~h
    assert need;ds.append((need,mask))
   assert len(ds)==28;rows.append(ds)
  count=[0]*(1+len(hints));memo={}
  for a in range(1024):
   b=1023^a
   while True:
    q=(raw[a]|(h if attach else 0))&raw[b]
    if q not in memo:
     n=q>>13;p=q&8191;steps=0
     if n and h!=q and (h,q) not in ex and all(p&~raw[1<<v] for v in range(10)):
      steps=1
      for opts in rows:
       if not any((p&t)==t and not n&f for t,f in opts):break
       steps+=1
     memo[q]=steps
    for j in range(memo[q]):count[j]+=1
    if not b:break
    b=(b-1)&(1023^a)
  assert count[-1]==0
  records[name]=count
print(records)
Path(__file__).with_name('staged-pilot-counts.json').write_text(json.dumps(records,indent=2)+'\n')
