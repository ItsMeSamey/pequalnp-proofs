import CompactPriorSelected38Cell03
-- CompactPriorFace100
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem row11_13 : CutRow book 11 13 11 := (joinRow (joinRow (joinRow row11_13_seg13 row11_13_seg16) row11_13_seg19) row11_13_seg22)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace101
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem combine11_0_13 : CutRow book 11 0 13 := @joinRow book 11 0 1 12 row11_0 row11_1
theorem combine11_0_24 : CutRow book 11 0 24 := @joinRow book 11 0 13 11 combine11_0_13 row11_13
theorem band11 : CutRow book 11 0 24 := combine11_0_24
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace102
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
set_option maxRecDepth 16000 in
theorem row10_0 : CutRow book 10 0 1 := bandCut 9 false (by decide +kernel)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
