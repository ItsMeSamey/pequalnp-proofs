import H3FirstBroadSurvivor9822
import H3FirstBroadRootBound9822
import H3FirstBroadLookup9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822FirstAdmission
attribute [local irreducible] words roots check leakingWord nonstarWord certifiedCuts
theorem checked_identifies {x y h : Nat} {k : Fin 1024} (verified : Checked x y)
    (hid : hidden h = true) (adm : firstAdmitted h = true) (hbd : h < 2^29)
    (valid : domain.testBit k.val=true)
    (reflects : ∀ i < 29, ((words x y)[i]!).testBit k.val=h.testBit i) :
    ∃ i : Nat, roots[i]? = some h := by
  obtain ⟨ds,rs,pcheck,dsbd,rsbd⟩ := verified
  obtain ⟨leak,hot,cuts⟩ := survivor (ws:=words x y) (k:=k) (h:=h) (ds:=ds) reflects hid adm hbd dsbd
  obtain ⟨i,_,eq⟩ := identified (a:=x) (b:=y) (h:=h) (k:=k) (drops:=ds) (ids:=rs)
    pcheck valid leak hot cuts hbd reflects (fun j hj => bounded_root j (rsbd j hj))
  exact ⟨i,eq⟩
end Research.Graph9822FirstBroad
