import And9822StablePartition
import OR9822RetireHidden
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
abbrev Rename := Nat → Option Nat
def copyProduct (f : Rename) (p : Product) : Product := (p.1.filterMap f,p.2.filterMap f)
def compileSlots (ex : Nat → Bool) : List Product → Nat → Nat → Rename → List Product × List Product
  | [],_,_,_ => ([],[])
  | p::ps,k,n,f =>
    let cp := copyProduct f p
    if ex k then
      let rest := compileSlots ex ps (k+1) n (Function.update f k none)
      (rest.1,cp::rest.2)
    else
      let rest := compileSlots ex ps (k+1) (n+1) (Function.update f k (some n))
      (cp::rest.1,rest.2)
def Routes (n : Nat) (f : Rename) := ∀ i j, f i=some j → j<n
def Mirrors (v w : Wire) (f : Rename) := ∀ i, v i=((f i).map w).getD false

theorem mapped_arm (v w : Wire) (f : Rename) (h : Mirrors v w f) (a : Arm) :
    readArm w (a.filterMap f) = readArm v a := by
  induction a with
  | nil => rfl
  | cons i a ih =>
    change (readArm w ((i::a).filterMap f)) = (v i || readArm v a)
    cases e : f i with
    | none => simp only [List.filterMap_cons,e,Option.map_none,Option.getD_none,h i,ih,Bool.false_or]
    | some j =>
      simp only [List.filterMap_cons,e]
      change (w j || readArm w (a.filterMap f)) = _
      simp [h i,e,ih]

theorem scope_drop {n : Nat} {f : Rename} (bd : Routes n f) (k) :
    Routes n (Function.update f k none) := by
  intro i j hj
  by_cases e : i=k
  · simp [e] at hj
  · exact bd i j (by simpa [e] using hj)

theorem scope_add {n : Nat} {f : Rename} (bd : Routes n f) (k) :
    Routes (n+1) (Function.update f k (some n)) := by
  intro i j hj
  by_cases e : i=k
  · simp [e] at hj
    omega
  · exact Nat.lt_succ_of_lt (bd i j (by simpa [e] using hj))

theorem mapped_product (v w : Wire) (f : Rename) (h : Mirrors v w f) (p : Product) :
    productBit w (copyProduct f p) = productBit v p := by
  simp [productBit,copyProduct,mapped_arm v w f h]

theorem copy_stale (ps : List Product) (n) (w : Wire) (f : Rename) (bd : Routes n f) (p) :
    productBit (run ps n w) (copyProduct f p) = productBit w (copyProduct f p) := by
  have keep (a : Arm) : readArm (run ps n w) (a.filterMap f) = readArm w (a.filterMap f) := by
    apply read_below
    intro j hj
    obtain ⟨i,_,e⟩ := List.mem_filterMap.mp hj
    exact stale_value ps (bd i j e) w
  simp [productBit,copyProduct,keep]

end Research.Graph9822.FreeOR
