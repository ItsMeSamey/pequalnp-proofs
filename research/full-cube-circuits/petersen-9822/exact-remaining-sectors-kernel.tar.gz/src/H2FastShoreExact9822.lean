import H2FastShore9822
namespace Research.Graph9822H2Check

def HitsAll (edges : List (List Nat)) (b : Nat) : Prop :=
  ∀ e ∈ edges, ∃ v ∈ e, sub v b = true

private theorem joinLeft (a b : Nat) : sub a (a ||| b) = true := by
  apply beq_iff_eq.mpr
  apply Nat.eq_of_testBit_eq
  intro i
  simp only [Nat.testBit_and,Nat.testBit_or]
  cases a.testBit i <;> simp

theorem shoreEnum_hits {edges : List (List Nat)} {c : Nat} (mem : c ∈ shoreEnum edges) :
    HitsAll edges c := by
  induction edges generalizing c with
  | nil => simp [HitsAll]
  | cons e rest ih =>
    have m := (List.mem_filter.mp (List.mem_mergeSort.mp mem)).1
    obtain ⟨a,ha,hm⟩ := List.mem_flatMap.mp (List.mem_eraseDups.mp m)
    obtain ⟨v,hv,rfl⟩ := List.mem_map.mp hm
    intro s hs
    rcases List.mem_cons.mp hs with rfl | h
    · exact ⟨v,hv,by simpa [Nat.or_comm] using joinLeft v a⟩
    · obtain ⟨w,hw,small⟩ := ih ha s h
      exact ⟨w,hw,sub_trans small (joinLeft a v)⟩

theorem minimal_in_shoreEnum {edges : List (List Nat)} {b : Nat}
    (hits : HitsAll edges b)
    (minimum : ∀ c, HitsAll edges c → sub c b = true → c = b) :
    b ∈ shoreEnum edges := by
  obtain ⟨c,mem,sub⟩ := shoreEnum_complete edges b hits
  exact minimum c (shoreEnum_hits mem) sub ▸ mem

end Research.Graph9822H2Check
