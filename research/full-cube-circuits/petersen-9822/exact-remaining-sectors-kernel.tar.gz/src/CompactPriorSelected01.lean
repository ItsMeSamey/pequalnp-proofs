import CompactPriorSelected00
-- CompactPriorC504
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h29_4 : Face true 29 4 :=
  mixedLower (g:=B29_4.book) (i:=0) (hints:=8964)
    (before_sound B29_4.entries B29_4.prior) B29_4.geometry B29_4.checked
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
theorem h156_4 : Face true 156 4 := carry_of (swaps:=[114,98,32,66,50,80,16]) (by decide +kernel) h29_4
theorem h540_4 : Face true 540 4 := carry_of (swaps:=[146,130,114,98,67,32,80,16]) (by decide +kernel) h29_4
theorem h652_4 : Face true 652 4 := carry_of (swaps:=[146,130,115,98,48,66,80,16]) (by decide +kernel) h29_4
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorC505
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h660_4 : Face true 660 4 := carry_of (swaps:=[147,131,116,66,99,32,80,16]) (by decide +kernel) h29_4
theorem h664_4 : Face true 664 4 := carry_of (swaps:=[147,50,130,115,48,98,80,16]) (by decide +kernel) h29_4

end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorC506
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B668_7
def entries : List (Nat × Nat) := [(156,4),(540,4),(652,4),(660,4),(664,4)]
theorem prior : Known true entries := (consFace h156_4 (consFace h540_4 (consFace h652_4 (consFace h660_4 (consFace h664_4 (known_down baseKnown))))))
def samples : Nat → Bits × Bits := (fun i => (if i<8 then tableBits #[(padColumn 45 0x0,padColumn 45 0x0),(padColumn 45 0x0,padColumn 45 0x0),(padColumn 45 0x1e1e3e3c33,padColumn 45 0x2742a3c2411),(padColumn 45 0x1ff81fc0f,padColumn 45 0xc8355819806),(padColumn 45 0x1e1e077c4cc,padColumn 45 0x112ca2664448),(padColumn 45 0x0,padColumn 45 0x0),(padColumn 45 0x0,padColumn 45 0x0),(padColumn 45 0x1e1e01cecb30,padColumn 45 0x150ac542c920)] i else tableBits #[(padColumn 45 0x0,padColumn 45 0x0),(padColumn 45 0x1fe001f933c0,padColumn 45 0xad118993280)] i))
def cols : List ColumnInfo := [(4,0,664,0,4),(8,0,660,0,4),(16,0,652,0,4),(128,0,540,0,4),(512,0,156,0,4)]
def data6 : Nat → Nat := (fun i => tableWord #[0x1f,0x29c05] i)
def data5 : Nat → Nat := (fun i => tableWord #[0x3f420,0x0,0x3f440,0x101] i)
def data4 : Nat → Nat := (fun i => tableWord #[0x5dca1440,0x0] i)
def levels : Nat → Packing
  | 4 => (1,2,3,0,0,0,0,data4)
  | 5 => (2,1,3,0,0,0,0,data5)
  | 6 => (1,0,3,0,0,0,0,data6)
  | _ => (0,0,0,0,0,0,0,fun _ => 0)
def index : Nat → Nat → Option (Nat × Nat)
  | 5 => fun v => (if v=5239425270783651293 then some (0,0) else none)
  | 6 => fun h => smallSlot h 5 16 2 4 (fun i => ((fun i => tableWord #[0x50050] i) (i/16) >>> (4*(i%16))) % 16) (fun i => ((fun i => tableWord #[0x2085400000025800000051505ca6e9199d0d] i) (i/16) >>> (9*(i%16))) % 512)
  | _ => fun _ => none
def book : Forest := ⟨668,6,samples,cols,[[],[115,148],[50,116],[50,66,146,114],[66,151],[66,147,114,50],[114,50,67,148],[114,147],[146,67],[146,115,66,67]],levels,index⟩
end B668_7
end PEqualNP.Outside.L_meta_9825.Engine
