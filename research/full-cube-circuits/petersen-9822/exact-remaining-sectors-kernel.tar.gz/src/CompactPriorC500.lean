import CompactPriorEngine20
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B29_4
def entries : List (Nat × Nat) := []
theorem prior : Known true entries := (known_down baseKnown)
def samples : Nat → Bits × Bits := (fun i => (if i<8 then tableBits #[(padColumn 20 0xe0ef0,padColumn 20 0xabad0),(padColumn 20 0x0,padColumn 20 0x0),(padColumn 20 0x7dc3,padColumn 20 0x75d81),(padColumn 20 0x1f3cf,padColumn 20 0x8a246),(padColumn 20 0xf8f3c,padColumn 20 0x54528),(padColumn 20 0x0,padColumn 20 0x0),(padColumn 20 0x0,padColumn 20 0x0),(padColumn 20 0x0,padColumn 20 0x0)] i else tableBits #[(padColumn 20 0x0,padColumn 20 0x0),(padColumn 20 0x0,padColumn 20 0x0)] i))
def cols : List ColumnInfo := []
def data3 : Nat → Nat := (fun i => tableWord #[0xf,0x0] i)
def levels : Nat → Packing
  | 3 => (1,0,1,0,0,0,0,data3)
  | _ => (0,0,0,0,0,0,0,fun _ => 0)
def index : Nat → Nat → Option (Nat × Nat)
  | _ => fun _ => none
def book : Forest := ⟨29,3,samples,cols,[[],[32,67]],levels,index⟩
end B29_4
end PEqualNP.Outside.L_meta_9825.Engine
