import And9822H4Geo
namespace Research.Graph9822.H4Geo
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
def block (q : Fin 20) (r : Fin 12) : OrId := ⟨q.val*12+r.val,by omega⟩
def RowFact (j : OrId) := positivesP j ∧ ∀ k : Fin 20,profileOK k j=true
end Research.Graph9822.H4Geo
