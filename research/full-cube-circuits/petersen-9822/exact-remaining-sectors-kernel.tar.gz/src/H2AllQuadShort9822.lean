import H2QuadGeometryTransfer9822
import H2QuadKeyGroup09822
import H2QuadKeyGroup19822
import H2QuadKeyGroup29822
import H2QuadKeyGroup39822
import H2QuadKeyGroup49822
import H2QuadKeyGroup59822
import H2QuadKeyGroup69822
import H2QuadKeyGroup79822
namespace Research.Graph9822H2Check
theorem allOriginalPairs : originalKeys.all (fun p => pairDom p.1 p.2)=true := by
  have eq : originalKeys = keys0 ++ keys1 ++ keys2 ++ keys3 ++ keys4 ++ keys5 ++ keys6 ++ keys7 := rfl
  simp only [eq,List.all_append,paidKeys0,paidKeys1,paidKeys2,paidKeys3,paidKeys4,paidKeys5,paidKeys6,paidKeys7,Bool.and_self]
theorem all_quad_short (c : Nat) (small : c<50) : quadGood (quadTable[c]!)=true ∧
    ∀ i∈quadTable[c]!,∀ k∈quadTable[c]!,i<k → pairDom i k=true :=
  geometryFromPaidKeys allOriginalPairs c small
end Research.Graph9822H2Check
#print axioms Research.Graph9822H2Check.all_quad_short
