import CompactPriorSelected33
-- CompactPriorFace88
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B759_12
set_option maxRecDepth 16000 in
theorem row9_0 : CutRow book 9 0 2 := bandCut 8 false (by decide +kernel)
end B759_12
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace89
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B759_12
set_option maxRecDepth 16000 in
theorem row9_2 : CutRow book 9 2 1 := bandCut 9 false (by decide +kernel)
end B759_12
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace90
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B759_12
theorem combine9_0_3 : CutRow book 9 0 3 := @joinRow book 9 0 2 1 row9_0 row9_2
theorem band9 : CutRow book 9 0 3 := combine9_0_3
theorem checked : mixedTables book 11 := by
  intro k hk
  interval_cases k
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact band9
  · exact band10
  · exact band11
end B759_12
end PEqualNP.Outside.L_meta_9825.Engine
