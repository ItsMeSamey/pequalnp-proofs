import And9822CollectorShape
import OR9822NoHidden
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FourSaturation
theorem no_hidden_actual (c : FiveProgram) (empty : (hiddenFirst c).1=[]) : False := by
  let ts := (hiddenFirst c).2
  have five := (hidden_first_sizes c).1
  rw [empty] at five
  have size : ts.length=5 := by simpa [ts] using five
  let term (i : Fin 5) := ts[i.val]'(by omega)
  have mem (i : Fin 5) : term i ∈ ts := List.getElem_mem ..
  have allTerm (p) (hp : p∈ts) : ∃ i : Fin 5, term i=p := by
    obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hp
    exact ⟨⟨i,by omega⟩,eq⟩
  have observed (m : Fin 1024) :
      ts.any (productBit (fullWire m.val))=accepts m.val := by
    simpa only [ts,empty,run] using hidden_first_correct c m
  apply no_hidden_five term
  · intro i j hit
    have b := (hidden_first_shape c).2.2 _ (mem i)
    rw [empty] at b
    exact hit.elim (b.2.1 j) (b.2.2 j)
  · intro e he
    have pos : ∀ e ∈ edges, edgeMask e<1024 ∧ accepts (edgeMask e)=true := by decide
    obtain ⟨lt,yes⟩ := pos e he
    have on := (observed ⟨edgeMask e,lt⟩).trans yes
    obtain ⟨p,hp,hit⟩ := List.any_eq_true.mp on
    obtain ⟨i,rfl⟩ := allTerm p hp
    exact ⟨i,hit⟩
  · intro i n
    have neg : ∀ n : Fin 16, witnesses[n.val]!<1024 ∧ accepts (witnesses[n.val]!) = false := by decide
    obtain ⟨lt,no⟩ := neg n
    have off := (observed ⟨witnesses[n.val]!,lt⟩).trans no
    apply Bool.eq_false_iff.mpr
    intro yes
    have bad := List.any_eq_true.mpr ⟨term i,mem i,yes⟩
    change ts.any (productBit (fullWire witnesses[n.val]!))=true at bad
    rw [off] at bad
    contradiction
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.no_hidden_actual
