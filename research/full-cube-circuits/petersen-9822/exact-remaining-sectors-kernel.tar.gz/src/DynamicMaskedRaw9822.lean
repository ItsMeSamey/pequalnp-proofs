import PrivateMaskedRaw9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean
theorem masked_dynamic_raw (gs : List Gate) (w u : List Bool) (s : Nat)
    (read : ∀q∈gs,s∈q.inputs → q.op=.and ∧ ∃j∈q.inputs,j≠s ∧ (wiresFrom gs w).getD j false=false)
    (len : w.length=u.length) (eqv : ∀i,i≠s → w.getD i false=u.getD i false)
    :
    ∀i,i≠s → (wiresFrom gs w).getD i false=(wiresFrom gs u).getD i false := by
  induction gs generalizing w u with
  | nil => exact eqv
  | cons q rest ih =>
    have same : q.op.eval (q.inputs.map fun i => w.getD i false)=q.op.eval (q.inputs.map fun i => u.getD i false) := by
      by_cases has : s∈q.inputs
      · obtain ⟨andq,j,pin,js,cold⟩ := read q (by simp) has
        have wj : w.getD j false=false := by
          by_cases small : j<w.length
          · simpa only [getD_wiresFrom _ _ _ small] using cold
          · exact List.getD_eq_default _ _ (by omega)
        have uj := (eqv j js).symm.trans wj
        have zero (v : List Bool) (j0 : v.getD j false=false) :
            q.op.eval (q.inputs.map fun i => v.getD i false)=false := by
          simp only [andq,GateOp.eval,List.all_map,Function.comp_def,id_eq,List.all_eq_false]
          exact ⟨j,pin,by rw [j0];decide⟩
        exact (zero w wj).trans (zero u uj).symm
      · apply congrArg q.op.eval
        exact List.map_congr_left fun k hk => eqv k (fun e => has (e ▸ hk))
    apply ih _ _ (fun b bm => read b (List.mem_cons_of_mem _ bm)) (by simp [len])
    · dsimp only
      rw [same]
      exact snoc_agree_off _ _ _ _ len eqv
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
