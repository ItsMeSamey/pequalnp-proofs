import And9822FreeOR
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution

/-- Hidden registers retain their value. An exposed register contributes to the
output accumulator and is reset to false when erasure is enabled. -/
def collect (erase : Bool) (exposed : Nat → Bool) : List Product → Nat → Wire → Bool → Bool
  | [],_,_,seen => seen
  | p::ps,k,w,seen =>
    let bit := productBit w p
    collect erase exposed ps (k+1)
      (Function.update w k (if erase && exposed k then false else bit))
      (seen || (exposed k && bit))

private theorem already_seen (erase : Bool) (exposed : Nat → Bool) (ps : List Product)
    (k : Nat) (w : Wire) : collect erase exposed ps k w true = true := by
  induction ps generalizing k w with
  | nil => rfl
  | cons p ps ih => simp [collect,ih]

theorem erase_exposed (exposed : Nat → Bool) (ps : List Product) (k : Nat)
    (w : Wire) (seen : Bool) :
    collect true exposed ps k w seen = collect false exposed ps k w seen := by
  induction ps generalizing k w seen with
  | nil => rfl
  | cons p ps ih =>
    cases he : exposed k <;> cases hb : productBit w p <;>
      simp [collect,he,hb,already_seen,ih]

theorem collect_exact (ps : List Product) (k : Nat) (w : Wire) (exposed : Nat → Bool)
    (seen : Bool) : collect false exposed ps k w seen =
      (seen || ((List.range' k ps.length).any (fun j => exposed j && run ps k w j))) := by
  induction ps generalizing k w seen with
  | nil => simp [collect]
  | cons p ps ih =>
    let w' := Function.update w k (productBit w p)
    have keep (ts : List Product) (n : Nat) (v : Wire) (j : Nat) (lt : j<n) :
        run ts n v j = v j := by
      induction ts generalizing n v with
      | nil => rfl
      | cons q ts ih =>
        rw [run,ih (n+1) _ (by omega),Function.update_of_ne (Nat.ne_of_lt lt)]
    simp only [collect,Bool.false_and,if_false,Bool.false_eq_true,List.length_cons,run]
    rw [ih]
    simp [List.range',List.any_cons,keep ps (k+1) _ k (by omega),Bool.or_assoc,Nat.add_comm]

end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.erase_exposed
