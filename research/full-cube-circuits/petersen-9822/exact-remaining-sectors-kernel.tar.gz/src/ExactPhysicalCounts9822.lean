import Not9822PhysicalMany
namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.Outside.L_meta_9822.Clean PEqualNP.Outside.L_meta_9822.Sectors

theorem candidateCounts
    (c5 : Lower true (varsX 668) (graphGoal 668) 7)
    (seven : Lower true (varsX 701) (graphGoal 701) 11)
    (nine : Lower true (varsX 1015) (graphGoal 1015) 14)
    {gs o} (hr : Reduced 10 gs o) (ev : ∀ x, vl gs x o = Sectors.edge x)
    (size : gs.length ≤ 17) :
    (gs.countP countsNot = 1 → gs.countP bin = 16 ∧ gs.length = 17) ∧
    (gs.countP countsNot = 0 → gs.countP bin = gs.length ∧ (gs.length = 16 ∨ gs.length = 17)) := by
  have pred : (fun g => decide (¬ countsNot g = true)) = bin := by
    funext g
    cases g with
    | mk op ins => cases op <;> rfl
  have split := List.length_eq_countP_add_countP (l := gs) countsNot
  rw [pred] at split
  have floor := reducedBinarySixteen c5 seven nine hr ev
  constructor <;> intro h <;> omega

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.candidateCounts
