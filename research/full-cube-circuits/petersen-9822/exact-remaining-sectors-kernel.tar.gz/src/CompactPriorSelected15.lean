import CompactPriorSelected14
-- CompactPriorFace31
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B255_11
theorem combine8_0_9 : CutRow book 8 0 9 := @joinRow book 8 0 4 5 row8_0 row8_4
theorem band8 : CutRow book 8 0 9 := combine8_0_9
theorem checked : mixedTables book 10 := by
  intro k hk
  interval_cases k
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact band8
  · exact band9
  · exact band10
end B255_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace32
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h255_11 : Face true 255 11 :=
  mixedLower (g:=B255_11.book) (i:=0) (hints:=553656612)
    (before_sound B255_11.entries B255_11.prior) B255_11.geometry B255_11.checked
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
theorem h593_4 : Face true 593 4 := carry_of (swaps:=[147,131,50,114,99,82]) (by decide +kernel) h29_4
theorem h599_7 : Face true 599 7 := carry_of (swaps:=[147,131,67,116,66,99,82,16]) (by decide +kernel) h63_7
theorem h606_8 : Face true 606 8 := carry_of (swaps:=[151,135,101,66,16]) (by decide +kernel) h189_8
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace33
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h657_4 : Face true 657 4 := carry_of (swaps:=[147,131,114,99,82]) (by decide +kernel) h29_4
theorem h679_7 : Face true 679 7 := carry_of (swaps:=[145,129,49,99,48,114,81,64]) (by decide +kernel) h190_7
theorem h685_7 : Face true 685 7 := carry_of (swaps:=[145,129,97,83,114,16,64]) (by decide +kernel) h190_7
theorem h689_7 : Face true 689 7 := carry_of (swaps:=[116,83,16,32]) (by decide +kernel) h668_7
end PEqualNP.Outside.L_meta_9825.Engine
