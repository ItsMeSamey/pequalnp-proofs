import And9822H4Geo
namespace Research.Graph9822.H4Geo
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
private theorem a0 : static_pairP 48 := by unfold static_pairP; decide +kernel
private theorem a1 : static_pairP 49 := by unfold static_pairP; decide +kernel
private theorem a2 : static_pairP 50 := by unfold static_pairP; decide +kernel
private theorem a3 : static_pairP 51 := by unfold static_pairP; decide +kernel
private theorem a4 : static_pairP 52 := by unfold static_pairP; decide +kernel
private theorem a5 : static_pairP 53 := by unfold static_pairP; decide +kernel
private theorem a6 : static_pairP 54 := by unfold static_pairP; decide +kernel
private theorem a7 : static_pairP 55 := by unfold static_pairP; decide +kernel
private theorem a8 : static_pairP 56 := by unfold static_pairP; decide +kernel
private theorem a9 : static_pairP 57 := by unfold static_pairP; decide +kernel
private theorem a10 : static_pairP 58 := by unfold static_pairP; decide +kernel
private theorem a11 : static_pairP 59 := by unfold static_pairP; decide +kernel
theorem pairs4 : ∀ r : Fin 12, static_pairP ⟨4*12+r.val,by omega⟩ := Fin.cases a0 (Fin.cases a1 (Fin.cases a2 (Fin.cases a3 (Fin.cases a4 (Fin.cases a5 (Fin.cases a6 (Fin.cases a7 (Fin.cases a8 (Fin.cases a9 (Fin.cases a10 (Fin.cases a11 (fun h=>Fin.elim0 h))))))))))))
end Research.Graph9822.H4Geo
