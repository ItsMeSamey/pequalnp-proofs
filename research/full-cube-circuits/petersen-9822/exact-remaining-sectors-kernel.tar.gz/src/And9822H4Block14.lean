import And9822H4BlockDefs
namespace Research.Graph9822.H4Geo
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
private theorem a0 : RowFact (block 14 0) := by unfold RowFact positivesP; decide +kernel
private theorem a1 : RowFact (block 14 1) := by unfold RowFact positivesP; decide +kernel
private theorem a2 : RowFact (block 14 2) := by unfold RowFact positivesP; decide +kernel
private theorem a3 : RowFact (block 14 3) := by unfold RowFact positivesP; decide +kernel
private theorem a4 : RowFact (block 14 4) := by unfold RowFact positivesP; decide +kernel
private theorem a5 : RowFact (block 14 5) := by unfold RowFact positivesP; decide +kernel
private theorem a6 : RowFact (block 14 6) := by unfold RowFact positivesP; decide +kernel
private theorem a7 : RowFact (block 14 7) := by unfold RowFact positivesP; decide +kernel
private theorem a8 : RowFact (block 14 8) := by unfold RowFact positivesP; decide +kernel
private theorem a9 : RowFact (block 14 9) := by unfold RowFact positivesP; decide +kernel
private theorem a10 : RowFact (block 14 10) := by unfold RowFact positivesP; decide +kernel
private theorem a11 : RowFact (block 14 11) := by unfold RowFact positivesP; decide +kernel
theorem block14 : ∀ j,RowFact (block 14 j) := Fin.cases a0 (Fin.cases a1 (Fin.cases a2 (Fin.cases a3 (Fin.cases a4 (Fin.cases a5 (Fin.cases a6 (Fin.cases a7 (Fin.cases a8 (Fin.cases a9 (Fin.cases a10 (Fin.cases a11 (fun h=>Fin.elim0 h))))))))))))
end Research.Graph9822.H4Geo
