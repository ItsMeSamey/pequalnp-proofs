import H3FirstAdmission9822
import OR9822H2PhysicalLeaks
import OR9822RawColumnCode
import OR9822ParetoRows
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR
open Research.Graph9822FirstAdmission (stars hidden)
open Research.Graph9822Resolution Research.Graph9822.FeatureRun Research.Graph9822H2Check
open Research.Graph9822.FourSaturation

private theorem misses_raw : ∀ (v : Fin 10) e, e∈edges → v.val≠e.1 → v.val≠e.2 →
    ∃ k : Fin 13, rawRow ⟨k.val,by omega⟩ = edgeMask e ∧
      (rawPos (bit v.val)).testBit k.val=false := by
  intro v e mem
  have finite : ∀ (w : Fin 10), ∀ g∈edges, w.val≠g.1 → w.val≠g.2 →
      ∃ k : Fin 13, rawRow ⟨k.val,by omega⟩ = edgeMask g ∧
        (rawPos (bit w.val)).testBit k.val=false := by decide +kernel
  exact finite v e mem

theorem original_hidden (C : MaximumFive) (p : Product) (rest : List Product)
    (hp : (hiddenFirst C.toFiveProgram).1=p::rest) :
    hidden (encode (firstCol p))=true := by
  have witness := compact_hidden_witness C [] rest p hp
  obtain ⟨m,hm,on⟩ := witness.1
  obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hm
  let n : Fin 16 := ⟨i,by simpa [witnesses] using hi⟩
  have fired : (negative (encode (firstCol p))).testBit n.val=true := by
    rw [neg_col_bit, first_on_row]
    have ni : rawRow ⟨13+n.val,by omega⟩=witnesses[i]! := by simp [rawRow,n]
    rw [ni,getElem!_pos witnesses i hi,eq]
    exact on
  simp only [Research.Graph9822FirstAdmission.hidden,Bool.and_eq_true]
  constructor
  · apply bne_iff_ne.mpr
    intro off; simp [off] at fired
  · apply List.all_eq_true.mpr
    intro mask mem
    obtain ⟨u,hu,rfl⟩ := List.mem_map.mp mem
    let v : Fin 10 := ⟨u,List.mem_range.mp hu⟩
    change (!sub (positive (encode (firstCol p))) (rawPos (bit v.val)))=true
    simp only [Bool.not_eq_true']

    obtain ⟨e,he,fire,nl,nr⟩ := witness.2 v
    obtain ⟨k,mask,cold⟩ := misses_raw v e he nl nr
    have hot : (positive (encode (firstCol p))).testBit k.val=true := by
      rw [pos_col_bit,first_on_row,mask]
      exact fire
    apply Bool.eq_false_iff.mpr
    intro incl
    have impossible := (subset_bits ..).1 incl k.val hot
    exact Bool.noConfusion (impossible.symm.trans cold)
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.original_hidden
