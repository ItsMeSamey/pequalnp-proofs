import And9822H3RequestList
import And9822H3Omissions
import H3FirstAdmission9822
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822FirstAdmission Research.Graph9822H2Check
open Research.Graph9822OneHidden (edges inside contains)
private theorem cellRaw (i j : Fin 16) (e : Fin 13)
    (h : (cell i.val j.val).testBit e.val=true) : (nm i ||| nm j) &&& pm e=pm e := by
  have hi : e.val<edges.length := e.isLt
  have pe : pm e=edges[e.val]! := by simp [pm,rawRow,e.isLt]
  have nn (k : Fin 16) : nm k=Research.Graph9822.FourSaturation.witnesses[k.val]! := by
    simp [nm,rawRow]
  simpa [pe,nn,cell,inside,contains,test_edgeMask,List.getElem?_eq_getElem hi,getElem!_pos edges e.val hi] using h

open Research.Graph9822DemandThree

theorem held_request (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B])
    {hint : Nat} {ds : List Nat} (ok : requests (encode (firstCol H)) hint=some ds) :
    ∃ r∈ds, holds (encode (secondCol H Q)) r := by
  obtain ⟨slot,eval⟩ := original_demands c H Q R A B hh ht
  apply all_request _ _ slot _ ok
  intro i j same need
  apply holds_pair i j need
  intro e cellhot miss
  apply eval i j same e _ miss
  intro v hp
  have sub := cellRaw i j e cellhot
  have bits := congrArg (fun m : Nat => m.testBit v.val) sub
  change (pm e).testBit v.val=true at hp
  change (nm i).testBit v.val=true ∨ (nm j).testBit v.val=true
  simpa [Nat.testBit_and,Nat.testBit_or,hp] using bits
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.held_request
