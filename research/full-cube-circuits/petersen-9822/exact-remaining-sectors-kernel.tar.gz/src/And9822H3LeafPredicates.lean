import H3DemandNumeric9822
import H3FirstAdmission9822
namespace Research.Graph9822.H3Directions
open Research.Graph9822H2Check Research.Graph9822DemandThree
def exceptions : List (Nat × Nat) := [(786481,5047856), (786481,788144), (786481,26106200), (786481,788016), (786481,26106184), (786481,26106216), (26106184,786481)]
theorem really_hidden {q : Nat} (hot : Graph9822FirstAdmission.hidden q=true) :
    notHidden (positive q) (negative q)=false := by
  obtain ⟨pos,all⟩ := Bool.and_eq_true_iff.mp hot
  have n : negative q ≠ 0 := bne_iff_ne.mp pos
  have zero : (negative q == 0)=false := beq_eq_false_iff_ne.mpr n
  simp only [notHidden,zero,Bool.false_or,List.any_eq_false]
  intro v mem
  have m : rawPos (bit v)∈Graph9822FirstAdmission.stars := List.mem_map.mpr ⟨v,mem,rfl⟩
  simpa using List.all_eq_true.mp all _ m

theorem outside {h q : Nat} (ne : h≠q) (avoid : (h,q)∉exceptions) : exPair h q=false := by
  simp only [exceptions,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at avoid
  simp [exPair,ne,List.contains_iff_mem] <;> grind

end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.outside
