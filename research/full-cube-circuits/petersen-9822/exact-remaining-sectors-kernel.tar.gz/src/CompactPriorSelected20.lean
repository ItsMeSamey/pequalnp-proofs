import CompactPriorSelected19
-- CompactPriorFace46
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace47
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
set_option maxRecDepth 16000 in
theorem row10_0 : CutRow book 10 0 1 := bandCut 7 false (by decide +kernel)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace48
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem band10 : CutRow book 10 0 1 := row10_0
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
