import H2SymbolicPattern9822
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden

structure SymNegative where
  hf : Nat
  qf : Nat
  shared : Bool
  deriving DecidableEq

def SymNegative.zero : SymNegative := ⟨0,0,false⟩
def SymNegative.join (a b : SymNegative) : SymNegative :=
  ⟨a.hf ||| b.hf,a.qf ||| b.qf,a.shared || b.shared⟩
def SymNegative.eval (p : SymNegative) (h : Nat) :=
  p.qf ||| (if p.shared then negative h else 0)

def symbolicCell (u v : Nat) : Option SymNegative :=
  if u = 11 then
    if v = 11 then none else if v = 10 then some ⟨0,0,true⟩ else some ⟨0,cachedNeg 0 v,false⟩
  else if v = 11 then
    if u = 10 then some ⟨0,0,true⟩ else some ⟨0,cachedNeg 0 u,false⟩
  else if u = 10 then some ⟨if v = 10 then 65535 else cachedNeg 0 v,0,false⟩
  else if v = 10 then some ⟨cachedNeg 0 u,0,false⟩
  else if meets (cachedNeg 0 u) (cachedNeg 0 v) then none else some SymNegative.zero

def cellSafe (h u v : Nat) : Bool :=
  if u == 11 then v != 11 else v == 11 || !meets (cachedNeg h u) (cachedNeg h v)

def cellForbid (h u v : Nat) :=
  if u == 11 then cachedNeg h v else if v == 11 then cachedNeg h u else 0

private theorem rawSame {u : Nat} (h : Nat) (ne : u ≠ 10) : cachedNeg h u = cachedNeg 0 u := by
  simp [cachedNeg,fixedNeg,ne]

private theorem hiddenCol (h : Nat) : cachedNeg h 10 = negative h := by
  simp [cachedNeg,fixedNeg]

theorem symbolicCell_covers {h u v : Nat} (ok : cellSafe h u v = true) :
    ∃ p, symbolicCell u v = some p ∧ p.hf &&& negative h = 0 ∧
      p.eval h = cellForbid h u v := by
  by_cases uq : u=11 <;> by_cases vq : v=11 <;> by_cases uh : u=10 <;> by_cases vh : v=10 <;>
    simp_all [cellSafe,cellForbid,symbolicCell,SymNegative.zero,SymNegative.eval,
      rawSame,hiddenCol,meets,Nat.and_comm]

def symbolicCells : List (Nat × Nat) → Option SymNegative
  | [] => some .zero
  | (u,v)::xs => do
    let a ← symbolicCell u v
    let b ← symbolicCells xs
    return a.join b

private theorem forbidFold (h init : Nat) (xs : List (Nat × Nat)) :
    xs.foldl (fun f (u,v) => f ||| cellForbid h u v) init =
      init ||| xs.foldr (fun (u,v) f => cellForbid h u v ||| f) 0 := by
  induction xs generalizing init with
  | nil => simp
  | cons x xs ih => rcases x with ⟨u,v⟩; simp [ih,Nat.or_assoc]

theorem symbolicCells_cover (h : Nat) (xs : List (Nat × Nat))
    (safe : xs.all (fun (u,v) => cellSafe h u v) = true) :
    ∃ p, symbolicCells xs = some p ∧ p.hf &&& negative h = 0 ∧
      p.eval h = xs.foldl (fun f (u,v) => f ||| cellForbid h u v) 0 := by
  rw [forbidFold,Nat.zero_or]
  induction xs with
  | nil => exact ⟨.zero,rfl,by simp [SymNegative.zero],by simp [SymNegative.zero,SymNegative.eval]⟩
  | cons x xs ih =>
    rcases x with ⟨u,v⟩
    obtain ⟨here,rest⟩ := Bool.and_eq_true_iff.mp safe
    obtain ⟨a,ha,fa,qa⟩ := symbolicCell_covers here
    obtain ⟨b,hb,fb,qb⟩ := ih rest
    refine ⟨a.join b,by simp [symbolicCells,ha,hb],?_,?_⟩
    · simp [SymNegative.join,Nat.and_or_distrib_right,fa,fb]
    · change (a.join b).eval h = cellForbid h u v ||| _
      rw [← qa,← qb]
      cases ha : a.shared <;> cases hb : b.shared <;>
        simp [SymNegative.join,SymNegative.eval,ha,hb,Nat.or_assoc,Nat.or_left_comm,Nat.or_comm]

end Research.Graph9822H2Check
