import H23TernaryPlanes9822
import Mathlib.Tactic.Ring
namespace Research.Graph9822Planes
def repUnits (b : Nat) : Nat → Nat
  | 0 => 0
  | n+1 => b*repUnits b n+1
theorem rep_mul (b n : Nat) (bp : 0<b) :
    (b-1)*repUnits b n+1=b^n := by
  induction n with
  | zero => simp [repUnits]
  | succ n ih =>
    rw [repUnits,Nat.pow_succ']
    rw [←ih]
    have eq : b-1+1=b := by omega
    calc
      (b-1)*(b*repUnits b n+1)+1 = b*((b-1)*repUnits b n)+(b-1+1) := by ring
      _ = b*((b-1)*repUnits b n+1) := by rw [eq];ring
theorem geom_div (t n : Nat) (tpos : 0<t) :
    (2^(t*n)-1)/(2^t-1)=repUnits (2^t) n := by
  have pos : 1<2^t := Nat.one_lt_two_pow (by omega)
  have eq := rep_mul (2^t) n (by omega)
  rw [←Nat.pow_mul] at eq
  have diff : 2^(t*n)-1=(2^t-1)*repUnits (2^t) n := by omega
  rw [diff,Nat.mul_div_cancel_left _ (by omega : 0<2^t-1)]
theorem period_bit (t n b j : Nat) (tpos : 0<t) (small : b<2^t) (bound : j<t*n) :
    (repUnits (2^t) n*b).testBit j = b.testBit (j%t) := by
  induction n generalizing j with
  | zero => simp at bound
  | succ n ih =>
    have step : repUnits (2^t) (n+1)*b=2^t*(repUnits (2^t) n*b)+b := by rw [repUnits];ring
    rw [step,Nat.testBit_two_pow_mul_add _ small]
    by_cases lo : j<t
    · simp [lo,Nat.mod_eq_of_lt lo]
    · have jb : j-t<t*n := by rw [Nat.mul_succ] at bound;omega
      have restore : j-t+t=j := by omega
      have eq : (j-t)%t=j%t := by conv_rhs => rw [←restore,Nat.add_mod_right]
      simp [lo,ih (j-t) jb,eq]
end Research.Graph9822Planes
