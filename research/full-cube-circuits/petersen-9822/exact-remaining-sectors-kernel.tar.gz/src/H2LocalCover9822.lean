import OR9822H2StepSound
import OR9822H2MaskLogic
namespace Research.Graph9822H2Check

def coversChildren (h s : Nat) (quad cs : List Nat) (bad : Nat → Bool) : Bool :=
  quad.all fun i => quad.all fun j =>
    !(decide (i < j)) || (rescue h i j).all (fun r =>
      bad (s ||| r) || cs.any (fun c => sub c (s ||| r)))

theorem local_rescue {h s q : Nat} {quad cs : List Nat} {bad : Nat → Bool}
    (valid : coversChildren h s quad cs bad = true)
    (noWitness : ∀ t, bad t = true → ¬holds q t)
    (found : ∃ i ∈ quad, ∃ j ∈ quad, i < j ∧ ∃ r ∈ rescue h i j, holds q r)
    (here : holds q s) : ∃ c ∈ cs, holds q c := by
  obtain ⟨i,hi,j,hj,lt,r,mem,live⟩ := found
  have checks := List.all_eq_true.mp (List.all_eq_true.mp valid i hi) j hj
  have all : (rescue h i j).all (fun r =>
      bad (s ||| r) || cs.any (fun c => sub c (s ||| r))) = true := by
    simpa [lt] using checks
  have hsr : holds q (s ||| r) := join_subset here live
  rcases Bool.or_eq_true_iff.mp (List.all_eq_true.mp all r mem) with denied | covered
  · exact (noWitness _ denied hsr).elim
  · obtain ⟨c,hc,small⟩ := List.any_eq_true.mp covered
    exact ⟨c,hc,weaker_holds small hsr⟩

end Research.Graph9822H2Check
