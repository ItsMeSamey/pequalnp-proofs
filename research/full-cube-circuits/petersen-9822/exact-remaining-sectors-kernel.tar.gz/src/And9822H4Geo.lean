import And9822H4Tree
import FourSaturationData
namespace Research.Graph9822.H4Geo
open Research.Graph9822.H4Tree
open Research.Graph9822.FourSaturation (accepts)
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
def masks : Array Nat := #[6,24,17,33,66,132,264,528,160,640,576,320,288,50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773]
def selectors : Array (List Nat) := #[[1,2,4,5,10,11,12,13,14,15],[0,1,2,3,4,8,9,10,12,14],[0,5,6,7,8,10,11,12,13,15],[1,2,3,5,6,8,9,11,13,14],[0,1,3,4,5,6,7,9,10,11],[1,2,3,4,7,8,9,11,13,15],[0,1,3,5,6,8,11,12,14,15]]
def pairs : Array (Nat × Nat × List Nat) := #[(0,1,[0,1,2,3,4]),(0,2,[0,1,4]),(0,3,[0,4]),(0,4,[1,2,3,8]),(0,5,[1,2,3,4,8]),(0,6,[4,8]),(0,7,[0,12]),(0,8,[2,3,8,12]),(0,9,[8,12]),(0,10,[1,2,3,7]),(0,11,[0,1,2,3,7]),(0,12,[1,7]),(0,13,[0,1,7]),(0,14,[2,3,7,12]),(0,15,[0,2,3,7,12]),(1,2,[3]),(1,3,[1,2,3]),(1,4,[0,4,5]),(1,5,[5]),(1,6,[1,2,5]),(1,7,[1,2,6,11]),(1,8,[0,4,5,6,11]),(1,9,[0,1,2,4,5,6,11]),(1,10,[0,4,10]),(1,11,[10]),(1,12,[0,3,4,10]),(1,13,[3,10]),(1,14,[0,4,6,10,11]),(1,15,[6,10,11]),(2,3,[1]),(2,4,[0,3,4,5,8]),(2,5,[3,5,8]),(2,6,[1,5,8]),(2,7,[1,6,11,12]),(2,8,[0,3,4,5,6,8,11,12]),(2,9,[0,1,4,5,6,8,11,12]),(2,10,[0,3,4,10]),(2,11,[3,10]),(2,12,[0,4,10]),(2,13,[10]),(2,14,[0,3,4,6,10,11,12]),(2,15,[3,6,10,11,12]),(3,4,[0,1,2,3,4,5,8]),(3,5,[1,2,3,5,8]),(3,6,[5,8]),(3,7,[11,12]),(3,8,[0,2,3,4,5,8,11,12]),(3,9,[0,4,5,8,11,12]),(3,10,[0,1,2,3,4,7,10]),(3,11,[1,2,3,7,10]),(3,12,[0,1,4,7,10]),(3,13,[1,7,10]),(3,14,[0,2,3,4,7,10,11,12]),(3,15,[2,3,7,10,11,12]),(4,5,[4]),(4,6,[1,2,4]),(4,7,[0,1,2,5,6]),(4,8,[6]),(4,9,[1,2,6]),(4,10,[9]),(4,11,[0,5,9]),(4,12,[3,8,9]),(4,13,[0,3,5,8,9]),(4,14,[6,9]),(4,15,[0,5,6,9]),(5,6,[1,2]),(5,7,[1,2,5,6,11]),(5,8,[4,6,11]),(5,9,[1,2,4,6,11]),(5,10,[4,9,10]),(5,11,[5,9,10]),(5,12,[3,4,8,9,10]),(5,13,[3,5,8,9,10]),(5,14,[4,6,9,10,11]),(5,15,[5,6,9,10,11]),(6,7,[5,11]),(6,8,[2,4,11]),(6,9,[4,11]),(6,10,[1,2,4,7,9,10]),(6,11,[1,2,5,7,9,10]),(6,12,[1,4,7,8,9,10]),(6,13,[1,5,7,8,9,10]),(6,14,[2,4,7,9,10,11]),(6,15,[2,5,7,9,10,11]),(7,8,[0,2,5]),(7,9,[0,5]),(7,10,[0,1,2,6,7]),(7,11,[1,2,6,7]),(7,12,[0,1,6,7,12]),(7,13,[1,6,7,12]),(7,14,[0,2,7]),(7,15,[2,7]),(8,9,[2]),(8,10,[6,9]),(8,11,[0,5,6,9]),(8,12,[3,6,8,9,12]),(8,13,[0,3,5,6,8,9,12]),(8,14,[9]),(8,15,[0,5,9]),(9,10,[1,2,6,7,9]),(9,11,[0,1,2,5,6,7,9]),(9,12,[1,6,7,8,9,12]),(9,13,[0,1,5,6,7,8,9,12]),(9,14,[2,7,9]),(9,15,[0,2,5,7,9]),(10,11,[0]),(10,12,[3]),(10,13,[0,3]),(10,14,[6]),(10,15,[0,6]),(11,12,[0,3]),(11,13,[3]),(11,14,[0,6]),(11,15,[6]),(12,13,[0]),(12,14,[3,6,12]),(12,15,[0,3,6,12]),(13,14,[0,3,6,12]),(13,15,[3,6,12]),(14,15,[0])]
def chosen (s : Fin 7) (i : Fin 10) := (selectors[s.val]!)[i.val]!
def nm (s : Fin 7) (i : Fin 10) := masks[13+chosen s i]!
abbrev OrId := Fin 240
def pairNumber (s : Fin 7) (i j : Fin 10) : Fin 120 :=
  let lo := min (chosen s i) (chosen s j)
  let hi := max (chosen s i) (chosen s j)
  ⟨(lo*(31-lo)/2+hi-lo-1)%120,Nat.mod_lt _ (by decide)⟩
def first (p : Fin 120) : OrId := ⟨p.val,by omega⟩
def second (p : Fin 120) : OrId := ⟨120+p.val,by omega⟩
def sideL (i : OrId) : Nat :=
  let p := pairs[i.val%120]!
  masks[13+(if i.val<120 then p.1 else p.2.1)]!
def sideR (i : OrId) : Nat :=
  let p := pairs[i.val%120]!
  masks[13+(if i.val<120 then p.2.1 else p.1)]!
def possible (i : OrId) := (pairs[i.val%120]!).2.2
def raw (i : Nat) := masks[i]!
def req (i : OrId) (k : Fin 20) := (force[i.val]!).1.testBit k.val
def ban (i : OrId) (k : Fin 20) := (force[i.val]!).2.testBit k.val
def outside (i : OrId) (k : Fin 20) := if k.val<10 then sideR i else sideL i
def en (i : OrId) (k : Fin 20) :=
  ((possible i).find? (fun e=> (raw e &&& (1023 ^^^ outside i k)) == 2^(k.val%10))).getD 0
def Obeys (key : Fin 20→Bool) (i : OrId) :=
  ∀ k : Fin 20,(req i k=true → key k=true) ∧ (ban i k=true → key k=false)
def profileOK (k : Fin 20) (i : OrId) : Bool :=
  ((zeroOK[k.val]!).testBit i.val == !req i k) &&
  ((oneOK[k.val]!).testBit i.val == !ban i k) &&
  (ban i k == (outside i k).testBit (k.val%10)) &&
  (!req i k || ((possible i).contains (en i k) &&
     ((raw (en i k) &&& (1023 ^^^ outside i k)) == 2^(k.val%10))))
def negSiteP (s : Fin 7) : Prop := ∀ i : Fin 10,nm s i<1024 ∧ accepts (nm s i)=false
def static_pairP (p : Fin 120) : Prop := 
  sideL (first p)=sideR (second p) ∧ sideR (first p)=sideL (second p) ∧
  possible (first p)=possible (second p) ∧ (possible (first p)).head!∈possible (first p)
def selectedPairP (s : Fin 7) : Prop := ∀ i j : Fin 10,i≠j →
  let p := pairNumber s i j
  (choices[s.val]!).testBit (first p).val=true ∧ (choices[s.val]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm s i ∧ sideR (first p)=nm s j) ∨
   (sideL (first p)=nm s j ∧ sideR (first p)=nm s i))
def positivesP (i : OrId) : Prop :=  (possible i).all (fun e=>
    decide (raw e<1024) && accepts (raw e) && ((raw e &&& (sideL i ||| sideR i))==raw e))=true
end Research.Graph9822.H4Geo
