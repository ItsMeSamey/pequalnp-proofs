import CompactPriorSelected26Cell00
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row7_12_seg15 : CutRow book 7 15 1 := bandCut 7 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
