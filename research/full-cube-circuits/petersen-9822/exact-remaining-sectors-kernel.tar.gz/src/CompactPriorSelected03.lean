import CompactPriorSelected02
-- CompactPriorC510
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B668_7
set_option maxRecDepth 16000 in
theorem row5_0 : CutRow book 5 0 2 := bandCut 6 false (by decide +kernel)
end B668_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorC511
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B668_7
theorem band5 : CutRow book 5 0 2 := row5_0
end B668_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorC512
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B668_7
set_option maxRecDepth 16000 in
theorem row4_0 : CutRow book 4 0 1 := bandCut 5 false (by decide +kernel)
end B668_7
end PEqualNP.Outside.L_meta_9825.Engine
