import And9822ReifyTerminal
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
def normalizedFive (c : FiveProgram) : FiveProgram := by
  let hs := (hiddenFirst c).1
  let ts := (hiddenFirst c).2
  let outs := List.range' (10+hs.length) ts.length
  have size := (hidden_first_sizes c).1
  have ord := (hidden_first_shape c).1
  have dh := (hidden_first_shape c).2.1
  have dt := (hidden_first_shape c).2.2
  refine ⟨hs++ts,outs,by simpa [hs,ts] using size,?_,?_,?_⟩
  · apply (chronological_iff ..).mpr
    constructor
    · apply (ordered_append ..).mpr
      exact ⟨((chronological_iff ..).mp ord).1,terminal_ordered ts _ _ (Nat.le_refl _) (fun p hp => (dt p hp).2)⟩
    · intro i hi
      obtain ⟨j,hj,eq⟩ := List.mem_range'.mp hi
      simp only [List.length_append]
      omega
  · intro p hp
    exact (List.mem_append.mp hp).elim (dh p) (fun hm => (dt p hm).1)
  · intro m
    rw [join_runs,terminal_eval ts (10+hs.length) _ (Nat.le_refl _) (fun p hp => (dt p hp).2)]
    exact hidden_first_correct c m
theorem normalizedFive_size (c : FiveProgram) :
    collectorSize (normalizedFive c).out=collectorSize c.out := by
  obtain ⟨size,num⟩ := hidden_first_sizes c
  have test : ∀ h : Fin 6, collectorSize (List.range' (10+h.val) (5-h.val))=5-h.val := by decide
  have h := test ⟨(hiddenFirst c).1.length,by omega⟩
  have eq : 5-(hiddenFirst c).1.length=(hiddenFirst c).2.length := by omega
  rw [eq] at h
  exact h.trans num
def normalizedMaximum (c : MaximumFive) : MaximumFive :=
  ⟨normalizedFive c.toFiveProgram,fun p => (c.maximal p).trans
    (normalizedFive_size c.toFiveProgram).symm.le⟩
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.normalizedFive_size
