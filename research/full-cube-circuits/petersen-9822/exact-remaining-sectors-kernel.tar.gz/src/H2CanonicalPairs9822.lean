import H2SymbolicSource9822
import H2PackedPairs9822
namespace Research.Graph9822H2Check

def unpackPattern (w : Nat) : SymPattern := ⟨w &&& 8191, (w >>> 13) &&& 65535,
  (w >>> 29) &&& 8191, (w >>> 42) &&& 65535, w.testBit 58⟩

def canonicalPair (i j : Nat) : List SymPattern :=
  let k := 13*i+j
  let start := pairStart[k]?.getD 0
  let finish := pairStart[k+1]?.getD 0
  (List.range (finish-start)).map (fun n => unpackPattern (pairWords[start+n]?.getD 0))

theorem canonical_project (h i j : Nat) :
    projectedBasis h (canonicalPair i j) = packedPair h i j := by
  simp [canonicalPair,projectedBasis,packedPair,List.filterMap_map,Function.comp_def,
    unpackPattern,SymPattern.project,wordDemand]

def pairDom (i j : Nat) :=
  (universalPatterns i j).all fun p => (canonicalPair i j).any (fun c => c.below p)

theorem packedPairCarried {h i j q r : Nat} (ok : pairDom i j = true)
    (mem : r ∈ rescue h i j) (live : holds q r) : ∃ w ∈ packedPair h i j, holds q w := by
  rw [← canonical_project]
  apply canonicalPair_carries _ mem live
  intro p hp
  exact List.any_eq_true.mp (List.all_eq_true.mp ok p hp)

end Research.Graph9822H2Check
