import OR9822RawColumnCode
import OR9822H2MaskLogic

namespace Research.Graph9822FirstAdmission
open Research.Graph9822H2Check Research.Graph9822OneHidden
open Research.Graph9822.FourSaturation (witnesses)
open Research.Graph9822.FeatureRun (rawCode)

abbrev Row := Fin 16
abbrev Pair := Row × Row
def cell (i j : Nat) := inside (witnesses[i]! ||| witnesses[j]!)
def compatible (h i j : Nat) : Bool :=
  sub (cell i j) (positive h) && !(negative h).testBit i && !(negative h).testBit j

theorem compatible_of {h : Nat} (i j : Row) (lt : i < j)
    (cover : ∀ e : Fin 13, (cell i.val j.val).testBit e.val = true →
      (positive h).testBit e.val = true ∧ (negative h).testBit i.val = false ∧
      (negative h).testBit j.val = false) : compatible h i.val j.val = true := by
  have ex : ∀ a b : Row, a < b → ∃ e : Fin 13, (cell a.val b.val).testBit e.val = true := by decide +kernel
  have bound : ∀ a b : Row, cell a.val b.val < 8192 := by decide +kernel
  obtain ⟨e,he⟩ := ex i j lt
  obtain ⟨_,ci,cj⟩ := cover e he
  have inc : sub (cell i.val j.val) (positive h) = true := by
    apply (subset_bits ..).2
    intro k hk
    by_cases small : k < 13
    · exact (cover ⟨k,small⟩ hk).1
    · have off : (cell i.val j.val).testBit k = false := Nat.testBit_lt_two_pow
        (lt_of_lt_of_le (bound i j) (Nat.pow_le_pow_right (by decide : 0 < (2:Nat)) (by omega : 13 ≤ k)))
      simp [off] at hk
  simp [compatible,inc,ci,cj]

def rowPairs : List Pair :=
  (List.finRange 16).flatMap fun i => ((List.finRange 16).filter (fun j => i < j)).map (i, ·)
theorem mem_rowPairs (i j : Row) : (i,j) ∈ rowPairs ↔ i < j := by simp [rowPairs]
def apart (p q : Pair) : Bool := p.1 != q.1 && p.1 != q.2 && p.2 != q.1 && p.2 != q.2
def pairCells := rowPairs.map (fun p => (p,cell p.1.val p.2.val))
def livePairs (h : Nat) : List Pair :=
  (pairCells.filter (fun z => sub z.2 (positive h) &&
    !(negative h).testBit z.1.1.val && !(negative h).testBit z.1.2.val)).map Prod.fst
def firstAdmitted (h : Nat) : Bool :=
  let ps := livePairs h
  rowPairs.all fun dropped => ps.any (apart · dropped)
theorem firstAdmitted_of {h : Nat}
    (cover : ∀ a b : Row, a < b → ∃ i j : Row, i < j ∧ i ≠ a ∧ i ≠ b ∧
      j ≠ a ∧ j ≠ b ∧ compatible h i.val j.val = true) : firstAdmitted h = true := by
  apply List.all_eq_true.mpr
  intro ⟨a,b⟩ hab
  obtain ⟨i,j,ij,ia,ib,ja,jb,hit⟩ := cover a b ((mem_rowPairs a b).mp hab)
  apply List.any_eq_true.mpr
  refine ⟨(i,j),?_,by simp [apart,ia,ib,ja,jb]⟩
  apply List.mem_map.mpr
  refine ⟨((i,j),cell i.val j.val), List.mem_filter.mpr ⟨?_,hit⟩,rfl⟩
  exact List.mem_map.mpr ⟨(i,j),(mem_rowPairs i j).mpr ij,rfl⟩
def stars := vs.map fun v => rawPos (bit v)
def hidden (h : Nat) : Bool := negative h != 0 && stars.all (fun p => !sub (positive h) p)
-- Generated roots
def roots : Array Nat := #[
  77890,100096,108416,116256,116512,279684,284680,312454,389186,393858,397632,444034,
  512320,591938,604226,786481,809224,923968,997698,1114784,1123232,1164960,1173408,1900593,
  2491014,2508420,2541190,3080838,3605158,3655334,4203664,4514966,4718860,4818688,4834848,4835104,
  4988977,5031046,5246988,5254288,5771532,5869836,6052108,6295040,6409760,6410016,6424080,6426128,
  6432400,6522640,6524688,6707208,6743702,6884864,6895682,7013904,7015952,7343744,7483024,7737356,
  25579848,25581640,25678152,26106184,26179658,26179914,31347020,31349068,31445324,31873096,32471114,33562913,
  33568784,33677601,33847320,34349361,34677025,35463473,38281505,38543665,42076240,42088528,42344737,42678354,
  42860593,59144280,67993649,69042225,72196145,73629969,84721713,100663436,100678672,100696078,100696206,100779552,
  100942988,100957208,100975758,101286030,101288002,101457152,101473544,101810318,101810848,101828256,103154316,103171724,
  103187086,103204494,103776910,104301230,104318638,104898702,105178270,105415054,105506336,105694606,105943182,106192012,
  106200220,106716556,106962432,107077152,107101712,107407006,108420748,108428956,109283408,117498145,125836352,125963344,
  125975632,126061648,126254168,126434370,126565458,126754112,126770504,132128320,132238944,132239200,132243040,132267600,
  132353872,132726338,132857426,140625953,141295665,141303857,142409777,145621041,174072097,176161313,176169761,176277025,
  176285473,176562977,176947761,176956209,177078833,177275553,177284001,179765927,179816103,180888097,180888353,182461217,
  207720465,207720481,208506929,243368481,243385889,244154929,244417185,245530766,246907567,248095265,249664033,260104993,
  260882993,269486097,269488416,269881696,270075921,270272561,270338097,273688593,274475057,275908625,285229352,286015537,
  286282024,286541841,291000620,295063912,303051041,303052817,303839537,311560273,311572561,312150099,312346737,312359281,
  312412275,312424819,318791977,319578425,319844649,320633145,323510573,323772733,324827453,329152889,336693265,352322577,
  353109041,353125425,353373201,353471505,353651729,353960977,353963025,354159665,356525201,356836503,357575825,358745617,
  359065239,359796241,378767441,385884449,385900841,385925262,386928928,386939921,386945320,390390943,391412893,395447377,
  395459665,395545681,396037203,402653378,402757376,402965698,403047106,403097282,403125186,403175362,403446528,403577664,
  403651522,403706656,403822368,404099936,404173794,404223970,404750406,404750534,404828358,405062854,405144262,405194438,
  405342406,405736134,405864646,406258406,406308582,408953030,408954000,409077264,409085584,409179920,409265366,409396950,
  409469126,409469196,409781446,410715664,414320657,425738536,427823880,427836200,427923208,428628744,428759880,428888872,
  428988200,429282152,433591052,433607468,433690380,433706796,434127656,434229032,434341656,434343704,434345752,444610576,
  444741712,445646865,445657889,445778001,446116835,446824646,448201447,459301161,461398825,462451497,466117421,467690281,
  488685766,492831761,492840081,492934161,492963345,493151447,493618225,494470161,497943601,498207761,505446478,505446606,
  505726158,505840334,506038478,506560718,509649102,510165454,513966286,522240206,528515086,530579526,530612302]
-- End generated roots

def locate (h : Nat) : Nat → Nat → Nat → Nat
  | 0, lo, _ => lo
  | k+1, lo, hi =>
    if lo < hi then
      let mid := (lo + hi) / 2
      if roots[mid]! < h then locate h k (mid+1) hi else locate h k lo mid
    else lo

def rootIndex (h : Nat) := locate h 9 0 roots.size
def listed (h : Nat) : Bool := roots[rootIndex h]? == some h
def rawTable := ((List.range 1024).map rawCode).toArray
theorem rawTable_get (i : Fin 1024) : rawTable[i.val]! = rawCode i.val := by
  simp [rawTable,i.isLt]

def pass (a b : Nat) : Bool :=
  if a ≤ b ∧ a &&& b = 0 then
    let h := rawTable[a]! &&& rawTable[b]!
    !hidden h || listed h || !firstAdmitted h
  else true

def rowOK (a : Nat) := (List.range 1024).all (pass a)

theorem listed_of_rows {a b : Fin 1024}
    (verified : ∀ i : Fin 1024, rowOK i.val = true)
    (disj : a.val &&& b.val = 0)
    (hid : hidden (rawCode a.val &&& rawCode b.val) = true)
    (adm : firstAdmitted (rawCode a.val &&& rawCode b.val) = true) :
    roots[rootIndex (rawCode a.val &&& rawCode b.val)]? = some (rawCode a.val &&& rawCode b.val) := by
  have go (x y : Fin 1024) (ord : x.val ≤ y.val) (dj : x.val &&& y.val = 0)
      (hd : hidden (rawCode x.val &&& rawCode y.val) = true)
      (ad : firstAdmitted (rawCode x.val &&& rawCode y.val) = true) :
      listed (rawCode x.val &&& rawCode y.val) = true := by
    have ok := List.all_eq_true.mp (verified x) y.val (List.mem_range.mpr y.isLt)
    simpa [pass,ord,dj,rawTable_get,hd,ad] using ok
  by_cases ord : a.val ≤ b.val
  · exact beq_iff_eq.mp (go a b ord disj hid adm)
  · apply beq_iff_eq.mp
    rw [Nat.and_comm (rawCode a.val)]
    apply go b a (by omega)
    · simpa only [Nat.and_comm] using disj
    · simpa only [Nat.and_comm] using hid
    · simpa only [Nat.and_comm] using adm

end Research.Graph9822FirstAdmission
