import CompactPriorSelected10
-- CompactPriorFace19
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B190_7
theorem band6 : CutRow book 6 0 1 := row6_0
end B190_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace20
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B190_7
set_option maxRecDepth 16000 in
theorem row5_0 : CutRow book 5 0 1 := bandCut 6 false (by decide +kernel)
end B190_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace21
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B190_7
theorem band5 : CutRow book 5 0 1 := row5_0
theorem checked : mixedTables book 6 := by
  intro k hk
  interval_cases k
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact band5
  · exact band6
end B190_7
end PEqualNP.Outside.L_meta_9825.Engine
