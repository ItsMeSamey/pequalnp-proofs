import CleanMin9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean

structure Lit where
  wire : Nat
  neg : Bool

def Lit.read (r : Lit) (v : Nat → Bool) : Bool :=
  if r.neg then !(v r.wire) else v r.wire

def Lit.flip (r : Lit) : Lit := ⟨r.wire,!r.neg⟩

@[simp] theorem Lit.read_flip (r : Lit) (v : Nat → Bool) :
    r.flip.read v = !(r.read v) := by
  cases r with
  | mk w b => cases b <;> simp [Lit.flip,Lit.read]

structure Site where
  isOr : Bool
  left : Lit
  right : Lit
  outNeg : Bool := false

def Site.op (g : Site) (a b : Bool) : Bool :=
  let l := if g.left.neg then !a else a
  let r := if g.right.neg then !b else b
  let z := if g.isOr then l || r else l && r
  if g.outNeg then !z else z

inductive Net (n : Nat) : Nat → Type
  | empty : Net n 0
  | snoc {k} (pre : Net n k) (g : Site)
      (leftBack : g.left.wire < n+k) (rightBack : g.right.wire < n+k) : Net n (k+1)

def Net.get {n k} : Net n k → Nat → Option Site
  | .empty, _ => none
  | .snoc (k := j) pre g _ _, w => if w = n+j then some g else pre.get w

def Net.eval {n k} : Net n k → (Nat → Bool) → Nat → Bool
  | .empty, env, w => env w
  | .snoc (k := j) pre g _ _, env, w =>
    if w = n+j then g.op (pre.eval env g.left.wire) (pre.eval env g.right.wire)
    else pre.eval env w

theorem Net.get_spec {n k} (net : Net n k) {w g} (h : net.get w = some g) :
    n ≤ w ∧ w < n+k ∧ g.left.wire < w ∧ g.right.wire < w := by
  induction net with
  | empty => cases h
  | @snoc k pre new l r ih =>
    by_cases eq : w = n+k
    · subst w
      simp [Net.get] at h
      subst g
      exact ⟨by omega,by omega,l,r⟩
    · simp [Net.get,eq] at h
      obtain ⟨lo,hi,hl,hr⟩ := ih h
      exact ⟨lo,by omega,hl,hr⟩

theorem Net.present {n k} (net : Net n k) {w} (lo : n ≤ w) (hi : w < n+k) :
    ∃ g, net.get w = some g := by
  induction net with
  | empty => omega
  | @snoc k pre g l r ih =>
    by_cases eq : w = n+k
    · exact ⟨g,by simp [Net.get,eq]⟩
    · obtain ⟨v,hv⟩ := ih (by omega)
      exact ⟨v,by simpa [Net.get,eq] using hv⟩

theorem Net.eval_raw {n k} (net : Net n k) (env : Nat → Bool) {i : Nat} (hi : i < n) :
    net.eval env i = env i := by
  induction net with
  | empty => rfl
  | @snoc k pre g l r ih => simpa [Net.eval,show i ≠ n+k by omega] using ih

theorem Net.eval_gate {n k} (net : Net n k) (env : Nat → Bool) {w g}
    (hg : net.get w = some g) :
    net.eval env w = g.op (net.eval env g.left.wire) (net.eval env g.right.wire) := by
  induction net with
  | empty => cases hg
  | @snoc k pre last hl hr ih =>
    by_cases eq : w = n+k
    · subst w
      simp [Net.get] at hg
      subst g
      simp [Net.eval,Nat.ne_of_lt hl,Nat.ne_of_lt hr]
    · have hg' : pre.get w = some g := by simpa [Net.get,eq] using hg
      obtain ⟨_,hi,l,r⟩ := pre.get_spec hg'
      simpa [Net.eval,eq,show g.left.wire ≠ n+k by omega,
        show g.right.wire ≠ n+k by omega] using ih hg'

def bin (g : Gate) : Bool := match g.op with | .not => false | _ => true

def inputEnv {n} (x : Fin n → Bool) (i : Nat) := (List.ofFn x).getD i false

/-- Each physical wire keeps its own signed reference. Arbitrarily many later
    readers may consult that same reference. -/
structure Realizes {n} (gs : List Gate) (p k : Nat) (net : Net n k) (ref : Nat → Lit) : Prop where
  bound : ∀ w, w < n+p → (ref w).wire < n+k
  semantic : ∀ w, w < n+p → ∀ x : Fin n → Bool, (ref w).read (net.eval (inputEnv x)) = vl gs x w

end PEqualNP.Outside.L_meta_9822.Compact
