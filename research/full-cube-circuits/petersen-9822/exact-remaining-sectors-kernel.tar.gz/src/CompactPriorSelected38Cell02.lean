import CompactPriorSelected38Cell01
namespace PEqualNP.Outside.L_meta_9825.Engine.B767_14
set_option maxRecDepth 16000 in
theorem row11_13_seg19 : CutRow book 11 19 3 := bandCut 11 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B767_14
