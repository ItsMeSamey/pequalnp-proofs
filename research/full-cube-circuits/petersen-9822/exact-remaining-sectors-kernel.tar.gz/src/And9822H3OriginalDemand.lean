import And9822H3PackedDirections
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822DemandThree Research.Graph9822H2Check

theorem original_demands (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B]) :
    ∃ slot : Fin 16 → Fin 7, ∀ i j : Fin 16, slot i=slot j → ∀ e : Fin 13,
      (∀ v : Fin 10, (rawRow ⟨e.val,by omega⟩).testBit v.val=true →
        (rawRow ⟨13+i.val,by omega⟩).testBit v.val=true ∨
        (rawRow ⟨13+j.val,by omega⟩).testBit v.val=true) →
      ¬((positive (encode (firstCol H))).testBit e.val=true ∧
        (negative (encode (firstCol H))).testBit i.val=false ∧
        (negative (encode (firstCol H))).testBit j.val=false) →
      (positive (encode (secondCol H Q))).testBit e.val=true ∧
        (negative (encode (secondCol H Q))).testBit i.val=false ∧
        (negative (encode (secondCol H Q))).testBit j.val=false := by
  obtain ⟨slot,hot,cold⟩ := official_seven c H Q R A B hh ht
  refine ⟨slot,?_⟩
  intro i j same e raw miss
  simp only [pos_col_bit,neg_col_bit] at miss ⊢
  let pp (t : Fin 13) : Fin 29 := ⟨t.val,by omega⟩
  let nn (t : Fin 16) : Fin 29 := ⟨13+t.val,by omega⟩
  have result := missing_requires_q
    (fun (p : Fin 13) (v : Fin 10) => (rawRow (pp p)).testBit (v : Fin 10).val=true)
    (fun (n : Fin 16) (v : Fin 10) => (rawRow (nn n)).testBit (v : Fin 10).val=true)
    (fun p => firstCol H (pp p)=true) (fun p => secondCol H Q (pp p)=true)
    (fun n => firstCol H (nn n)=true) (fun n => secondCol H Q (nn n)=true)
    (fun d f => reads R A B d (source f)) slot hot cold same (p:=e) raw
    (by simpa [pp,nn] using miss)
  simpa [pp,nn] using result
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.original_demands
