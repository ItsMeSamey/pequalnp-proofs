import And9822Footprint
namespace Research.Graph9822.Footprint
def stepRow (i : Nat) (a : Trace → Bool) (w : Dir) (r : Trace) : Trace :=
  if a r then (i,w i)::r else r
theorem step_mem (i a w r S) (mem : r ∈ S) : stepRow i a w r ∈ next i a S := by
  cases h : a r
  · simp [stepRow,h,next,mem]
  · have hy : r ∈ S.filter (fun r => a r = true) := Finset.mem_filter.mpr ⟨mem,h⟩
    cases b : w i
    · apply Finset.mem_union_right _
      apply Finset.mem_union_left _
      simpa [stepRow,h,b] using Finset.mem_image_of_mem (fun r : Trace => (i,false)::r) hy
    · apply Finset.mem_union_right _
      apply Finset.mem_union_right _
      simpa [stepRow,h,b] using Finset.mem_image_of_mem (fun r : Trace => (i,true)::r) hy
theorem preserve {S : Finset Trace} (rep : ∀ w, ∃ r ∈ S, Fits w r) (i a) :
    ∀ w, ∃ r ∈ next i a S, Fits w r := by
  intro w
  obtain ⟨r,mem,ok⟩ := rep w
  refine ⟨stepRow i a w r,step_mem i a w r S mem,?_⟩
  intro t ht
  cases h : a r
  · exact ok t (by simpa [stepRow,h] using ht)
  · rcases List.mem_cons.mp (show t ∈ (i,w i)::r by simpa [stepRow,h] using ht) with rfl | old
    · rfl
    · exact ok _ old

def start : Finset Trace := {[]}
def full (_ : Trace) := true
def first := next 0 full start
theorem four_one (a b c : Channel) :
    (next 3 (active c) (next 2 (active b) (next 1 (active a) first))).card ≤ 9 := by
  have rep : ∀ w, ∃ r ∈ start, Fits w r := fun w => ⟨[],by simp [start],by simp [Fits]⟩
  have h1 : first.card ≤ 2 := by have := bound 0 full start; simpa [first,start,full] using this
  have p1 := preserve rep 0 full
  have h2 := conditional_bound 1 a first p1
  have p2 := preserve p1 1 (active a)
  have h3 := conditional_bound 2 b (next 1 (active a) first) p2
  have h4 := conditional_bound 3 c _ (preserve p2 2 (active b))
  change (next 3 (active c) (next 2 (active b) (next 1 (active a) first))).card+1 ≤ 2*(next 2 (active b) (next 1 (active a) first)).card at h4
  omega
def twoFull := next 1 full first
def threeFull := next 2 full twoFull
private theorem repStart : ∀ w, ∃ r ∈ start, Fits w r :=
  fun w => ⟨[],by simp [start],by simp [Fits]⟩
private theorem two_bound : twoFull.card ≤ 4 := by
  have h1 : first.card ≤ 2 := by have := bound 0 full start; simpa [first,start,full] using this
  have h2 := bound 1 full first
  change twoFull.card + _ ≤ _ at h2
  omega
theorem four_two (b c : Channel) :
    (next 3 (active c) (next 2 (active b) twoFull)).card ≤ 13 := by
  have hp : ∀ w, ∃ r ∈ twoFull, Fits w r := preserve (preserve repStart 0 full) 1 full
  have h3 := conditional_bound 2 b twoFull hp
  have h4 := conditional_bound 3 c _ (preserve hp 2 (active b))
  have := two_bound
  omega
theorem four_three (c : Channel) : (next 3 (active c) threeFull).card ≤ 15 := by
  have hp : ∀ w, ∃ r ∈ twoFull, Fits w r := preserve (preserve repStart 0 full) 1 full
  have h3 := bound 2 full twoFull
  change threeFull.card + _ ≤ _ at h3
  have h4 := conditional_bound 3 c threeFull (preserve hp 2 full)
  have := two_bound
  omega
end Research.Graph9822.Footprint
#print axioms Research.Graph9822.Footprint.four_one
