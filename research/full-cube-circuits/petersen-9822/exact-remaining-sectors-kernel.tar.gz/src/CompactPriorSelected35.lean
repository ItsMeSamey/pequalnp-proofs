import CompactPriorSelected34
-- CompactPriorFace91
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h759_12 : Face true 759 12 :=
  mixedLower (g:=B759_12.book) (i:=0) (hints:=275431555364)
    (before_sound B759_12.entries B759_12.prior) B759_12.geometry B759_12.checked
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace92
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
def entries : List (Nat × Nat) := [(6,1),(14,2),(29,4),(30,4),(57,4),(63,7),(78,4),(95,7),(166,4),(177,4),(183,7),(189,8),(198,4),(231,7),(255,11),(561,4),(582,4),(593,4),(599,7),(606,8),(627,7),(633,7),(639,11),(668,7),(673,4),(689,7),(701,11),(706,4),(710,7),(734,11),(739,7),(743,10),(755,10),(759,12)]
theorem prior : Known true entries := (consFace h6_1 (consFace h14_2 (consFace h29_4 (consFace h30_4 (consFace h57_4 (consFace h63_7 (consFace h78_4 (consFace h95_7 (consFace h166_4 (consFace h177_4 (consFace h183_7 (consFace h189_8 (consFace h198_4 (consFace h231_7 (consFace h255_11 (consFace h561_4 (consFace h582_4 (consFace h593_4 (consFace h599_7 (consFace h606_8 (consFace h627_7 (consFace h633_7 (consFace h639_11 (consFace h668_7 (consFace h673_4 (consFace h689_7 (consFace h701_11 (consFace h706_4 (consFace h710_7 (consFace h734_11 (consFace h739_7 (consFace h743_10 (consFace h755_10 (consFace h759_12 (known_down baseKnown)))))))))))))))))))))))))))))))))))
def samples : Nat → Bits × Bits := (fun i => (if i<8 then tableBits #[(padColumn 320 0xf07fc210421ffe1043e0000000000000001fffffc00000000060c00000600fffffe0080600c003c0,padColumn 320 0xf07fc000000ffe0001e00c0300200806006d2b55400803006060c00000600ed56940080600c00140),(padColumn 320 0xff87c4208420822fffe0000000000001ffe00000000000ffe0030060601ffc0180603001ffc00c03,padColumn 320 0xff87c0000000000fffe0100c00c0300955200600c0300465a0030060601aa8018060300155800401),(padColumn 320 0x10887e013ff17ff084200000000007fe000000000007ffffe18000019fe00006018007ffffc0300f,padColumn 320 0x3e003ff07ff0000060100100c5a2008018030042599a418000019b400006018004acaa401006),(padColumn 320 0xfff8084fc84f84413fe0000000000000000000003fffff00060c018000003018001ffffe0100003c,padColumn 320 0xfff8000fc00f80003fe1806006010010030060042a9da600860c018000003018001aab5201000018),(padColumn 320 0x2110bff201f209ffc8400000001ff800000001fffff800000000061fe180c0007ffff8080600c0f0,padColumn 320 0x3ff001f001ffc0020080181a50600c0080aa956008030000061d4180c00016a55008060040a0),(padColumn 320 0x42213ffffe0411fffe800000ffe00000001ffe000000000018003fe6020303ff8200c03018030300,padColumn 320 0x3ffffe0001fffe0c0100ab4600803012d4080180300c180035460203012a8200c03018010200),(padColumn 320 0x84023ffffffffe02111ffc0000000001ffe00000000000001ff018080c1ffc600c0300c020300c00,padColumn 320 0x3ffffffffe000016a60060080300aac300300600c010155018080c0554600c0300c020100800),(padColumn 320 0xffffd08410802084200003ffffe007fe0000000000000000001ffff01fec0080300c0100400f3000,padColumn 320 0xffffc00000000000001002a554b0025cc00400c018010020001a8ab004ac0080300c010040062000)] i else tableBits #[(padColumn 320 0x0,padColumn 320 0x0),(padColumn 320 0x844210821084108001fffff001ff80000000000000000001fffe01ff010030040100601803cc000,padColumn 320 0x9595a8005ac0100180100200600c00aa56002b01003004010060180288000)] i))
def cols : List ColumnInfo := [(8,0,759,0,12),(128,0,639,0,11),(512,0,255,0,11),(33,0,734,0,11),(66,0,701,0,11),(12,0,755,0,10),(24,0,743,0,10),(129,32,606,0,8),(514,64,189,0,8),(578,0,189,0,8),(20,8,739,0,7),(28,0,739,0,7),(134,0,633,0,7),(140,0,627,0,7),(168,0,599,0,7),(536,0,231,0,7),(584,0,183,0,7),(672,0,95,0,7),(704,0,63,0,7),(57,0,710,0,7),(76,2,689,0,7),(78,0,689,0,7),(99,0,668,0,7),(52,9,706,0,4),(60,1,706,0,4),(92,2,673,0,4),(94,0,673,0,4),(170,4,593,0,4),(185,0,582,0,4),(202,4,561,0,4),(553,16,198,0,4),(585,16,166,0,4),(590,0,177,0,4),(646,64,57,0,4),(657,32,78,0,4),(689,0,78,0,4),(705,32,30,0,4),(708,2,57,0,4),(710,0,57,0,4),(738,0,29,0,4),(216,544,6,1,2),(240,513,14,0,2)]
def data13 : Nat → Nat := (fun i => tableWord #[0x1ff,0x421460c407] i)
def data12 : Nat → Nat := (fun i => tableWord #[0x3ff482,0x2e0c20b0e20607,0x3ff4e2,0x85180c40a3219408,0x3ff502,0xa0c60a2219407,0x3ff507,0x25022818c0a1c408] i)
def data11 : Nat → Nat := bookData 2 2 3 (fun i => ((fun i => tableWord #[0x5075024e2482] i) (i/16) >>> (12*(i%16))) % 4096) (fun i => ((fun i => tableWord #[0x3ffefffef7fffddf7] i) (i/16) >>> (11*(i%16))) % 2048) (fun i => ((fun i => tableWord #[0x504aa93d141e9a44bd2756922941e5a509d244a9425408ba4e8d236293a14089a460,0x522be93db492ca4f6524b272594a2aa495] i) (i/16) >>> (17*(i%16))) % 131072) (fun i => (if i<16 then (if i<8 then tableWord #[0x506c1c20bc3c407,0xb15c442c3861e1d08,0x410d120bc485c31b1f09,0x15c1c2c3c40b06,0x1241c4c30b05,0xd2605c48142c31d08,0x4212810dc685c425c31d0a,0x4612c3c41f0d06] i else tableWord #[0x1342c4c30d05,0xc609122641c485c31d09,0x828512c4c3462607,0x1d82c685c441c32008,0x13c445c31b1206,0x410b121d0d42c3c48609,0x860a0d0b1b1f06,0x1d1f81420d0f1285c4c3460b] i) else tableWord #[0x21c30b260d1b06,0xd12261b04,0x23261d1f418246c4c3850a,0xf0b46c31d05,0x410d12261d05,0x12c3462604,0xc3121541261b06,0xd12c645c32606] i))
def data10 : Nat → Nat := bookData 3 5 5 (fun i => ((fun i => tableWord #[0x522507d27502d245025075025245024e4502d284e2d244e25284e25244e25024e2d27482d23482507482502482527482,0xd22507] i) (i/16) >>> (24*(i%16))) % 16777216) (fun i => ((fun i => tableWord #[0xbffff7dffe7fd7fb7fbf7f7bdf7bfb9ffff3dfbefbfeb9f7,0xeff] i) (i/16) >>> (12*(i%16))) % 4096) (fun i => ((fun i => tableWord #[0x54829151ce352738d41ce3d4828350ce0d42183508c054928b49c61d4408748c8152718541c414e408750c00,0x5442b951cadd2763350d2b9492a941d8a1492a9510a95482a351d67d4751f510a7d4349b508c6d4741749065,0x5246bd5120cd4879941dc3949689525a25442c351d4f] i) (i/16) >>> (22*(i%16))) % 4194304) (fun i => (if i<32 then (if i<16 then (if i<8 then tableWord #[0xa0f0f880a04,0x361f02,0x1d1487c421b05,0x483e1b03,0x4c3e1b03,0x4c1b02,0x161b02,0x5054361f04] i else tableWord #[0x2c3e1b03,0x34161e03,0x543a1e03,0x2839412064361f06,0xc8e1864361f05,0x38361f03,0x2c361f03,0x120603c1d04] i) else (if i<24 then tableWord #[0x3c2602,0x4c1b02,0x8c1a1b03,0x1a1b02,0x3c2602,0x1a1b02,0x90981a1b04,0x3c2602] i else tableWord #[0x7c181e03,0xe080b048382606,0x440743fc3a3614422208,0x3c2602,0x70c141d03,0x3a2602,0x1205c3c2604,0x5054361f04] i)) else tableWord #[0xe187c222604,0x461f02,0x201a02,0x3a1f02,0x8074341f04,0x4c1d02,0x3c4c2303,0x3a2602] i))
def data9 : Nat → Nat := (fun i => tableWord #[0x1e6b5074e4502482,0x280981f03,0x15f7d63549507482,0x0,0x157fd67549507482,0x2701] i)
def levels : Nat → Packing
  | 9 => (3,4,6,0,0,0,0,data9)
  | 10 => (40,3,6,0,0,0,0,data10)
  | 11 => (24,2,6,0,0,0,0,data11)
  | 12 => (4,1,6,0,0,0,0,data12)
  | 13 => (1,0,6,0,0,0,0,data13)
  | _ => (0,0,0,0,0,0,0,fun _ => 0)
def index : Nat → Nat → Option (Nat × Nat)
  | 10 => fun v => (if v=9173731893560143937 then some (1,0) else (if v=9817994258469878493 then some (0,0) else (if v=11282382653361050149 then some (2,0) else (if v=13146079884629819533 then some (2,1) else none))))
  | 11 => fun h => smallSlot h 24 76 6 1 (fun i => ((fun i => tableWord #[0x40400a000000006040010000000,0x22c0010604004] i) (i/16) >>> (7*(i%16))) % 128) (fun i => ((fun i => tableWord #[0xf0021e0a08400000b7094001026542068d88,0xc2dc564299002180740042903000229280004800,0x634000000019f96000a443887003819109c09ba7,0x30cd3e9a0000085d8900000000008141100000,0x84ea1219a5d3b1f00000003c30039b] i) (i/16) >>> (10*(i%16))) % 1024)
  | 12 => fun h => smallSlot h 25 92 5 1 (fun i => ((fun i => tableWord #[0x8000000000000000800400000,0x2000000000000] i) (i/16) >>> (7*(i%16))) % 128) (fun i => ((fun i => tableWord #[0xac0000003aa004528d0200,0xa403d4a00088028400005180000,0xda380050f981469000000026b600000,0x7122c00004981c0190000000000000025400,0x4125e00002140000000031d67000000009,0x157] i) (i/16) >>> (9*(i%16))) % 512)
  | 13 => fun h => smallSlot h 3 11 3 1 (fun i => ((fun i => tableWord #[0x0] i) (i/16) >>> (4*(i%16))) % 16) (fun i => ((fun i => tableWord #[0x480310002da30128064] i) (i/16) >>> (7*(i%16))) % 128)
  | _ => fun _ => none
def book : Forest := ⟨767,13,samples,cols,[[],[16,66,101,151]],levels,index⟩
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace93
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
