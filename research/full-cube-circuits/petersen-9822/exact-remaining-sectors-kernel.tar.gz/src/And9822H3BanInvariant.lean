import H3TailPermute9822
namespace Research.H3Tail
def armValue (a : Arms) (k : Fin 6) : Nat :=
  #[a.a,a.b,a.c,a.d,a.e,a.f][k.val]!
def usesArm (d : Fin 7) (k : Fin 6) : Bool :=
  let masks : Array Nat := #[5,25,41,22,38,26,42]
  masks[d.val]!.testBit k.val

private theorem value_add (a : Arms) (d : Fin 7) (b : Nat) (k : Fin 6) :
    armValue (add a d.val b) k =
    if usesArm d k then armValue a k ||| b else armValue a k := by
  fin_cases d <;> fin_cases k <;> rfl

private theorem blocked_arm (a : Arms) (d : Fin 7) (k : Fin 6)
    (use : usesArm d k=true) (j : Nat) (b : (block a d.val).testBit j=true) :
    (armValue a k).testBit j=true := by
  fin_cases d <;> fin_cases k <;> first
    | contradiction
    | simp_all [usesArm,armValue,block,Nat.testBit_and] <;> tauto

def Clean (read : Fin 6 → Nat → Prop) (a : Arms) : Prop :=
  ∀ k j, read k j → (armValue a k).testBit j=false

theorem clean_zero (read : Fin 6 → Nat → Prop) : Clean read ⟨0,0,0,0,0,0⟩ := by
  intro k j _
  fin_cases k <;> simp [armValue]

theorem clean_add (read : Fin 6 → Nat → Prop) {a : Arms} (old : Clean read a) (d : Fin 7) (ban : Nat)
    (off : ∀ k j, usesArm d k=true → read k j → ban.testBit j=false) :
    Clean read (add a d.val ban) := by
  intro k j h
  rw [value_add]
  cases use : usesArm d k
  · simpa using old k j h
  · simp [Nat.testBit_or,old k j h,off k j use h]

theorem no_obstruction (read : Fin 6 → Nat → Prop) {edges : Array Nat} {a : Arms}
    (clean : Clean read a)
    (complete : ∀ d : Fin 7, ∀ i : Fin 13, ∀ m, edges[i.val]?=some m →
      ∃ k j, usesArm d k=true ∧ read k j ∧ m.testBit j=true) :
    ¬Obstructed edges a := by
  rintro ⟨d,hd,i,hi,m,atEdge,blocked⟩
  obtain ⟨k,j,used,rd,hot⟩ := complete ⟨d,hd⟩ ⟨i,hi⟩ m atEdge
  have clash := blocked_arm a ⟨d,hd⟩ k used j (blocked j hot)
  rw [clean k j rd] at clash
  contradiction

end Research.H3Tail
#print axioms Research.H3Tail.no_obstruction
