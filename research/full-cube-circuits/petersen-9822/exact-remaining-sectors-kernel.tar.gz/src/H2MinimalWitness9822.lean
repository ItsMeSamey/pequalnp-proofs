import H2FastShoreExact9822
namespace Research.Graph9822H2Check

theorem minimalShoreBelow {edges : List (List Nat)} {b : Nat} (hits : HitsAll edges b) :
    ∃ m ∈ shoreEnum edges, sub m b = true ∧ HitsAll edges m ∧
      ∀ c, HitsAll edges c → sub c m = true → c = m := by
  classical
  have ex : ∃ m, HitsAll edges m ∧ sub m b = true := ⟨b,hits,by simp [sub]⟩
  let m := Nat.find ex
  obtain ⟨hm,small⟩ := Nat.find_spec ex
  have least : ∀ c, HitsAll edges c → sub c m = true → c = m := by
    intro c hc sc
    have low : m ≤ c := Nat.find_min' ex ⟨hc,sub_trans sc small⟩
    have eq : c &&& m = c := by simpa [sub] using sc
    exact Nat.le_antisymm (eq ▸ Nat.and_le_right) low
  exact ⟨m,minimal_in_shoreEnum hm least,small,hm,least⟩

end Research.Graph9822H2Check
