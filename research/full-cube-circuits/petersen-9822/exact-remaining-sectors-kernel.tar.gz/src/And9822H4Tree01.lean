import And9822H4Tree00
namespace Research.Graph9822.H4Tree
theorem t50 {p : Bad} (legal : Respects p) (ok : Within p 27606985387212471963622116895219261330356596688897860774639506089312256) : Success p :=
  fork legal ok 17 (by decide +kernel) (by decide +kernel) (t48 legal) (t49 legal)
theorem t51 {p : Bad} (legal : Respects p) (ok : Within p 107839786725099539788229919000317344197471876053450726420429452345600) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t52 {p : Bad} (legal : Respects p) (ok : Within p 215679573393705163957979711126112583586074793047606481491221851144192) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t53 {p : Bad} (legal : Respects p) (ok : Within p 323519360062310788127729503251907822974677671356136008893880659345664) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t51 legal) (t52 legal)
theorem t54 {p : Bad} (legal : Respects p) (ok : Within p 323519360005816872509249376377385718165808673762330537468745943613696) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t55 {p : Bad} (legal : Respects p) (ok : Within p 323519360062310788127729503251907822974677671507251736486516587757824) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t53 legal) (t54 legal)
theorem t56 {p : Bad} (legal : Respects p) (ok : Within p 27930504747224565937866752952360482837945612990239551712450348163531008) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t50 legal) (t55 legal)
theorem t57 {p : Bad} (legal : Respects p) (ok : Within p 27930511329192578408807828126126053546805614587962639073807052281225344) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t58 {p : Bad} (legal : Respects p) (ok : Within p 27930511329242795222690921572237213067357775388178953627954516271833472) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t56 legal) (t57 legal)
theorem t59 {p : Bad} (legal : Respects p) (ok : Within p 911449035418377074548935517004089435596293420786369403218381366662406528) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t47 legal) (t58 legal)
theorem t60 {p : Bad} (legal : Respects p) (ok : Within p 914899911882781471097108669141687401991404175411551866172920448342729088) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t32 legal) (t59 legal)
theorem t61 {p : Bad} (legal : Respects p) (ok : Within p 201651893250027892657635385210273743449443171587094661300224) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t62 {p : Bad} (legal : Respects p) (ok : Within p 3450873173395281893717377931182068869191437085288583798093078241214464) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t63 {p : Bad} (legal : Respects p) (ok : Within p 3450873173600072337834368502562381348810822786469202575973657075515424) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t64 {p : Bad} (legal : Respects p) (ok : Within p 3450873173600072337834368502605937491776702909792514525724923406581792) : Success p :=
  fork legal ok 16 (by decide +kernel) (by decide +kernel) (t62 legal) (t63 legal)
theorem t65 {p : Bad} (legal : Respects p) (ok : Within p 3450873173395281893717377931138512726225556961965271857384332992708608) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t66 {p : Bad} (legal : Respects p) (ok : Within p 3450873173600072337834368502605937491776702909792514534767444489142304) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t64 legal) (t65 legal)
theorem t67 {p : Bad} (legal : Respects p) (ok : Within p 3450873173600072337835099253424602943235804752208872676277822211227680) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t61 legal) (t66 legal)
theorem t68 {p : Bad} (legal : Respects p) (ok : Within p 262853635169317256985623682096821031174286152268924288499744) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t69 {p : Bad} (legal : Respects p) (ok : Within p 3450873173658135528887426050490083995400475666557819464156708864262176) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t67 legal) (t68 legal)
theorem t70 {p : Bad} (legal : Respects p) (ok : Within p 3310643888870702352490035379881953692357456257239006380933775392) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t71 {p : Bad} (legal : Respects p) (ok : Within p 3450876484050940330173580559153366848966759524953624343821374137303072) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t69 legal) (t70 legal)
theorem t72 {p : Bad} (legal : Respects p) (ok : Within p 1725438238935174516984235006008998958011264336202276358252355641163876) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t73 {p : Bad} (legal : Respects p) (ok : Within p 1725438309335224392496264346901069182010477611199327839924625111793728) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t74 {p : Bad} (legal : Respects p) (ok : Within p 1725438309335224392496629777888040332203065883243188712894669564952644) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t75 {p : Bad} (legal : Respects p) (ok : Within p 1725438309335224392496629778236489475930106879540050391305508184145988) : Success p :=
  fork legal ok 16 (by decide +kernel) (by decide +kernel) (t73 legal) (t74 legal)
theorem t76 {p : Bad} (legal : Respects p) (ok : Within p 1725438316068200641415768232545853105998230069111839417938141713023076) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t72 legal) (t75 legal)
theorem t77 {p : Bad} (legal : Respects p) (ok : Within p 5176314793386164722670210337389856324896866404493674735126882321449060) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t71 legal) (t76 legal)
theorem t78 {p : Bad} (legal : Respects p) (ok : Within p 51422017416311072843888531210010667734419480171581796773789696) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t79 {p : Bad} (legal : Respects p) (ok : Within p 51422017416287688817517012191455888283802771862276635038318592) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t80 {p : Bad} (legal : Respects p) (ok : Within p 51422017416311072844062755781874188227712727988601260607537152) : Success p :=
  fork legal ok 16 (by decide +kernel) (by decide +kernel) (t78 legal) (t79 legal)
theorem t81 {p : Bad} (legal : Respects p) (ok : Within p 23384026545743590458864763117260620094024678637568) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t82 {p : Bad} (legal : Respects p) (ok : Within p 200867255766214046589914300359320211050432968156661254455296) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t83 {p : Bad} (legal : Respects p) (ok : Within p 200867255789598073135657890777620154960389094481286823673856) : Success p :=
  fork legal ok 16 (by decide +kernel) (by decide +kernel) (t81 legal) (t82 legal)
theorem t84 {p : Bad} (legal : Respects p) (ok : Within p 51622884672077286890478445510329423126262608645969058918825984) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t80 legal) (t83 legal)
theorem t85 {p : Bad} (legal : Respects p) (ok : Within p 51422017416287688817342787619592367800219890125657879192010752) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t86 {p : Bad} (legal : Respects p) (ok : Within p 51622884672077286890478445510329423135972974726369766906265600) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t84 legal) (t85 legal)
theorem t87 {p : Bad} (legal : Respects p) (ok : Within p 201651893296065194233558827133687339799927515945156965564416) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t88 {p : Bad} (legal : Respects p) (ok : Within p 201651893249297130688597334485857854385147322991986371198976) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t89 {p : Bad} (legal : Respects p) (ok : Within p 201651893296065205383931426398998910567786652269337718554624) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t87 legal) (t88 legal)
theorem t90 {p : Bad} (legal : Respects p) (ok : Within p 51422017416544913139486817381907548003451882418496553088974848) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t91 {p : Bad} (legal : Respects p) (ok : Within p 51623669309794210259025042117128094287069170605164358707183616) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t89 legal) (t90 legal)
theorem t92 {p : Bad} (legal : Respects p) (ok : Within p 51422017416287688817342786954917203280748274732912327891353600) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t93 {p : Bad} (legal : Respects p) (ok : Within p 51623669309794210259025042117128094287106949537027315868893184) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t91 legal) (t92 legal)
theorem t94 {p : Bad} (legal : Respects p) (ok : Within p 51623669309794210259025042781803258806578564929772867169550336) : Success p :=
  fork legal ok 9 (by decide +kernel) (by decide +kernel) (t86 legal) (t93 legal)
theorem t95 {p : Bad} (legal : Respects p) (ok : Within p 253437982566237235839869997962009531550132619084633903202304) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t96 {p : Bad} (legal : Respects p) (ok : Within p 51675455399111150375326688044544722054511409362189695454543872) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t94 legal) (t95 legal)
theorem t97 {p : Bad} (legal : Respects p) (ok : Within p 200867255579415868394333701980734136964957911574850608070656) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t98 {p : Bad} (legal : Respects p) (ok : Within p 46768052394588895978666343914334870894238006018048) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t99 {p : Bad} (legal : Respects p) (ok : Within p 51422017416311075698035466813690483631435113203431734853500928) : Success p :=
  leaf ok 1 (by decide +kernel)
end Research.Graph9822.H4Tree
