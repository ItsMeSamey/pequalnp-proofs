import CompactPriorSelected23Cell05
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row8_52_seg58 : CutRow book 8 58 3 := bandCut 8 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
