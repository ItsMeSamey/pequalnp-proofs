import CompactTracks9822
import PhysicalNormalBundle9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean
theorem trackedPrefix {n gs o} (hr : Reduced n gs o) :
    ∀ p, p ≤ gs.length → ∃ (k : Nat) (net : Net n k) (ref : Nat → Lit),
      k = (gs.take p).countP bin ∧ Realizes gs p k net ref ∧ Tracks gs p k net ref := by
  have hc := hr.clean
  intro p
  induction p with
  | zero =>
    intro _
    refine ⟨0,.empty,fun w => ⟨w,false⟩,by simp,⟨?_,?_⟩,?_⟩
    · intro w hw; simpa using hw
    · intro w hw x
      have h : w < n := by simpa using hw
      change inputEnv x w = vl gs x w
      rw [vl_input gs x w h]
      simp [inputEnv,List.getD_eq_getElem?_getD,h]
    · constructor
      · intro w h; rfl
      · intro w g h; cases h
      · intro j h; omega
      · intro w g h; cases h
  | succ p ih =>
    intro hp
    obtain ⟨k,net,ref,hk,old,tr⟩ := ih (by omega)
    have hlt : p < gs.length := by omega
    let g := gs[p]
    have hg : gs[p]? = some g := List.getElem?_eq_getElem hlt
    have hs : gs.take (p+1) = gs.take p ++ [g] := List.take_succ_eq_append_getElem hlt
    rcases hc p g hg with ⟨hop,a,ha,hin⟩ | ⟨hop,a,b,ha,hb,hin⟩
    · exact ⟨k,net,_,by simp [hs,hk,bin,hop],old.negGate hc hg a ha hop hin,tr.negGate hc hg ha hin⟩
    · rcases hop with op | op
      · refine ⟨k+1,_,_,by simp [hs,hk,bin,op],old.joinGate hc hg a b ha hb false op hin,
          Tracks.joinGate hr tr old hg a b ha hb false (Or.inl op) hin⟩
      · refine ⟨k+1,_,_,by simp [hs,hk,bin,op],old.joinGate hc hg a b ha hb true op hin,
          Tracks.joinGate hr tr old hg a b ha hb true (Or.inr op) hin⟩


inductive Route {n k} (net : Net n k) : Nat → Nat → Prop where
  | done (a) : Route net a a
  | step {a b o} : net.Edge a b → Route net b o → Route net a o

theorem Route.le {n k} {net : Net n k} {a b} (h : Route net a b) : a ≤ b := by
  induction h with
  | done => exact le_rfl
  | step e _ ih => exact (Net.edge_lt e).le.trans ih

theorem Tracks.project {n gs k net ref} (tr : @Tracks n gs gs.length k net ref)
    {a b} (h : Reaches n gs a b) : Route net (ref a).wire (ref b).wire := by
  induction h with
  | refl => exact .done _
  | @read w q o hq _ ih =>
    rcases tr.follows q (reads_len hq) w hq with eq | ed
    · rw [eq]; exact ih
    · exact .step ed ih

theorem Tracks.live {n gs o k net ref} (hr : Reduced n gs o)
    (tr : @Tracks n gs gs.length k net ref) {w g} (hw : net.get w = some g) :
    Route net w (ref o).wire := by
  obtain ⟨p,hp,eq⟩ := tr.covers w g hw
  rw [← eq]
  exact tr.project (hr.reaches p hp)

theorem Tracks.output_last {n gs o k net ref} (hr : Reduced n gs o) (ho : o < n+gs.length)
    (real : @Realizes n gs gs.length k net ref) (tr : Tracks gs gs.length k net ref)
    (pos : 0 < k) : (ref o).wire = n+k-1 := by
  obtain ⟨g,hg⟩ := net.present (w := n+k-1) (by omega) (by omega)
  have lower := (tr.live hr hg).le
  have upper := real.bound o ho
  omega

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.trackedPrefix
