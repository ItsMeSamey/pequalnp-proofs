import CompactPriorSelected29Cell01
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row7_112_seg118 : CutRow book 7 118 1 := bandCut 8 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
