import And9822FirstSwitchTail
import And9822DirectionBound

namespace Research.Graph9822Resolution.FirstSwitchRows
open Research.Graph9822Resolution

/-- Every selection is represented by exactly the MIS with its output support. -/
theorem modes (gs : List Gate) (i out : Nat) (w : V → Wire)
    (count : gs.countP Gate.isAnd = 4) (sel : Row → Wire)
    (obs : ∀ r v, resolve gs i (sel r) (w v) out = !(has r v)) :
    ∀ s : Wire, ∃ r, directions gs i (sel r) = directions gs i s := by
  let enc (s : Wire) : Fin 16 := ⟨bitsValue (directions gs i s), by
    simpa [directions_length,count] using bitsValue_lt (directions gs i s)⟩
  have eqd {s t} (e : enc s = enc t) : directions gs i s = directions gs i t :=
    bitsValue_inj _ _ (by simp [directions_length]) (congrArg Fin.val e)
  have hinj : Function.Injective (fun r => enc (sel r)) := by
    intro r t e
    by_contra ne
    obtain ⟨v,hr,ht⟩ := antichain _ _ ne
    have equal := congrFun (resolve_congr_directions gs i (sel r) (sel t) (w v) (eqd e)) out
    simp [obs,hr,ht] at equal
  have onto := (Finite.injective_iff_surjective).mp hinj
  intro s
  obtain ⟨r,h⟩ := onto (enc s)
  exact ⟨r,eqd h⟩

theorem directions_after (gs : List Gate) (i k : Nat) (s : Wire) (b : Bool) (h : k < i) :
    directions gs i (Function.update s k b) = directions gs i s := by
  induction gs generalizing i with
  | nil => rfl
  | cons g tail ih =>
    simp [directions,Function.update_of_ne (Nat.ne_of_gt h),ih (i+1) (by omega)]

theorem switch_impossible (gs : List Gate) (i out : Nat) (w : V → Wire)
    (count : gs.countP Gate.isAnd = 4) (sel : Row → Wire)
    (obs : ∀ r v, resolve gs i (sel r) (w v) out = !(has r v)) : False := by
  classical
  induction gs generalizing i w with
  | nil => simp at count
  | cons g tail ih =>
    cases hg : g.isAnd with
    | false =>
      apply ih (i+1) (fun v => Function.update (w v) i (w v g.left || w v g.right))
        (by simpa [List.countP_cons,hg] using count)
      intro r v
      simpa [resolve,resolved,hg] using obs r v
    | true =>
      let flip (r : Row) := Function.update (sel r) i (!(sel r i))
      have all := modes (g::tail) i out w count sel obs
      choose mate hd using fun r => all (flip r)
      have bits (r : Row) : sel (mate r) i = !(sel r i) ∧
          directions tail (i+1) (sel (mate r)) = directions tail (i+1) (sel r) := by
        simpa [directions,hg,flip,directions_after] using hd r
      have diff (r : Row) : mate r ≠ r := by
        intro eq
        have h := (bits r).1
        rw [eq] at h
        cases sel r i <;> simp_all
      let base (r : Row) (v : V) := resolve tail (i+1) (sel r) (Function.update (w v) i false) out
      let live (r : Row) := resolve tail (i+1) (sel r) (pulse i) out
      apply no_tail_pair mate diff (fun v => w v g.left) (fun v => w v g.right)
        (fun r => sel r i) live base
      · intro r v
        rw [← obs]
        simpa [resolve,resolved,hg,base,live] using
          mux_tail tail (i+1) i out (sel r) (w v) (if sel r i then w v g.left else w v g.right)
      · intro r v
        rw [← obs]
        simp only [resolve,resolved,hg,if_true,(bits r).1]
        rw [resolve_congr_directions tail (i+1) _ (sel r) _ (bits r).2]
        rw [mux_tail]
        cases h : sel r i <;> simp [h,base,live]
end Research.Graph9822Resolution.FirstSwitchRows
#print axioms Research.Graph9822Resolution.FirstSwitchRows.switch_impossible
