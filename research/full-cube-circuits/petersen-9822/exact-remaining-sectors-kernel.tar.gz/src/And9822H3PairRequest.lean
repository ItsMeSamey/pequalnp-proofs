import H3DemandSteps9822
import And9822H3OriginalDemand
import And9822H3PhysicalAdmission
import OR9822H2PackedRow
namespace Research.Graph9822.H3Directions
open Research.Graph9822H2Check Research.Graph9822DemandThree Research.Graph9822FirstAdmission
def forbidden (i j : Fin 16) := bit i.val ||| bit j.val
def needPos (h : Nat) (i j : Fin 16) :=
  cell i.val j.val &&& (8191 ^^^ (if negative h &&& forbidden i j == 0 then positive h else 0))

private theorem forbid_bit (i j : Fin 16) (k : Nat) :
    (forbidden i j).testBit k=true ↔ i.val=k ∨ j.val=k := by
  simp [forbidden,bit,Nat.testBit_two_pow]

private theorem forbid_bound (i j : Fin 16) : forbidden i j<65536 := by
  have h : ∀ i j : Fin 16, forbidden i j<65536 := by decide +kernel
  exact h i j

private theorem need_bound (h : Nat) (i j : Fin 16) : needPos h i j<8192 := by
  have all : ∀ i j : Fin 16,cell i.val j.val<8192 := by decide +kernel
  exact lt_of_le_of_lt (Nat.and_le_left ..) (all i j)

private theorem need_info (h : Nat) (i j : Fin 16) (e : Fin 13)
    (on : (needPos h i j).testBit e.val=true) :
    (cell i.val j.val).testBit e.val=true ∧
    ¬((positive h).testBit e.val=true ∧ (negative h).testBit i.val=false ∧ (negative h).testBit j.val=false) := by
  have bits := Bool.and_eq_true_iff.mp (show (_ && _)=true by simpa only [needPos,Nat.testBit_and] using on)
  refine ⟨bits.1,?_⟩
  rintro ⟨hp,ni,nj⟩
  have off : negative h &&& forbidden i j=0 := by
    apply Nat.eq_of_testBit_eq
    intro k
    by_cases fk : (forbidden i j).testBit k=true
    · rcases (forbid_bit i j k).mp fk with rfl|rfl <;> simp [ni,nj]
    · simp [Bool.eq_false_iff.mpr fk]
  have ones : (8191 : Nat).testBit e.val=true := by
    change (2^13-1 : Nat).testBit e.val=true
    rw [Nat.testBit_two_pow_sub_one]; simp [e.isLt]
  simpa [off,Nat.testBit_xor,ones,hp] using bits.2

theorem holds_pair {h q : Nat} (i j : Fin 16) (need : needPos h i j≠0)
    (deliver : ∀ e : Fin 13, (cell i.val j.val).testBit e.val=true →
      ¬((positive h).testBit e.val=true ∧ (negative h).testBit i.val=false ∧ (negative h).testBit j.val=false) →
      (positive q).testBit e.val=true ∧ (negative q).testBit i.val=false ∧ (negative q).testBit j.val=false) :
    holds q (pairRequest h i.val j.val) := by
  change holds q (needPos h i j ||| (forbidden i j <<< 13))
  have req (e : Fin 13) (bit : (needPos h i j).testBit e.val=true) :=
    deliver e (need_info h i j e bit).1 (need_info h i j e bit).2
  have low (k : Nat) (hk : (needPos h i j).testBit k=true) : k<13 := by
    by_contra! hi
    have no := Nat.testBit_lt_two_pow (lt_of_lt_of_le (need_bound h i j)
      (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) hi))
    simp [no] at hk
  obtain ⟨k,hk⟩ : ∃ k,(needPos h i j).testBit k=true := by
    by_contra! empty
    apply need
    apply Nat.eq_of_testBit_eq
    simpa using empty
  have cold := (req ⟨k,low k hk⟩ hk).2
  apply join_subset
  · apply (subset_bits ..).2
    intro t hit
    have live := positive_at (low t hit) (req ⟨t,low t hit⟩ hit).1
    apply (subset_bits ..).1 live t
    simp [bit,Nat.testBit_two_pow]
  · apply negative_shore (forbid_bound i j)
    intro t hit
    rcases (forbid_bit i j t.val).mp hit with lt|rt
    · exact lt ▸ cold.1
    · exact rt ▸ cold.2

theorem nonempty_need {h : Nat} {i j : Fin 16}
    (hot : positive (pairRequest h i.val j.val)≠0) : needPos h i j≠0 := by
  intro off
  apply hot
  change (needPos h i j ||| (forbidden i j <<< 13)) &&& 8191=0
  rw [off,Nat.zero_or]
  apply Nat.eq_of_testBit_eq
  intro k
  by_cases lt : k<13
  · simp [Nat.testBit_shiftLeft,show ¬k≥13 by omega]
  · have no : (8191:Nat).testBit k=false := Nat.testBit_lt_two_pow (lt_of_lt_of_le
      (by decide : 8191<2^13) (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) (by omega : 13≤k)))
    simp [no]
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.holds_pair
