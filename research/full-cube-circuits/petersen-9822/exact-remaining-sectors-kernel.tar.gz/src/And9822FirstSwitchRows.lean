import And9822Four

namespace Research.Graph9822Resolution
namespace FirstSwitchRows

abbrev V := Fin 10
abbrev Row := Fin 16

def has (r : Row) (x : V) : Bool := decide (x.val ∈ independentSets r)
def apart (x y : V) : Bool := (List.finRange 16).all fun r => !(has r x && has r y)

/-- Whenever two physical arms cannot occur together on a negative input,
their union lies in a closed neighborhood.  'apart' is the graph determined
directly by the actual independent-set table. -/
theorem no_square : ∀ x y z w : V, x ≠ y → z ≠ w →
    apart x z = true → apart x w = true → apart y z = true → apart y w = false := by
  decide +kernel

theorem stranded : ∀ x : V, ∃ r : Row, ∀ s : Row, s ≠ r →
    ∃ v : V, v ≠ x ∧ apart x v = false ∧ has r v ≠ has s v := by
  decide +kernel

theorem no_paired_arms (left right : V → Prop) (mate : Row → Row)
    (different : ∀ r, mate r ≠ r)
    (cross : ∀ x y, left x → right y → apart x y = true)
    (leftUsed : ∃ x, left x) (rightUsed : ∃ y, right y)
    (moves : ∀ r v, has r v ≠ has (mate r) v → left v ∨ right v) : False := by
  classical
  obtain ⟨x,hx⟩ := leftUsed
  obtain ⟨y,hy⟩ := rightUsed
  have sym (a b : V) : apart a b = apart b a := by
    have all : ∀ a b : V, apart a b = apart b a := by decide +kernel
    exact all a b
  by_cases one : ∀ z, left z → z = x
  · obtain ⟨r,hr⟩ := stranded x
    obtain ⟨v,hv,hoff,change⟩ := hr _ (different r)
    rcases moves r v change with l | t
    · exact hv (one _ l)
    · simp [cross _ _ hx t] at hoff
  · push_neg at one
    obtain ⟨z,hz,zx⟩ := one
    have only (v : V) (hv : right v) : v = y := by
      by_contra ne
      have f := no_square z x v y zx ne (cross _ _ hz hv) (cross _ _ hz hy) (cross _ _ hx hv)
      simp [cross _ _ hx hy] at f
    obtain ⟨r,hr⟩ := stranded y
    obtain ⟨v,hv,hoff,change⟩ := hr _ (different r)
    rcases moves r v change with l | t
    · rw [sym,cross _ _ l hy] at hoff
      cases hoff
    · exact hv (only _ t)

end FirstSwitchRows
end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.FirstSwitchRows.no_paired_arms
