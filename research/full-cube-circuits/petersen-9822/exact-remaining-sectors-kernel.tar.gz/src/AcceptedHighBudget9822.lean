import NineHotBudget9822
import NineFirstSocket9822
import NineHotSites9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr
open SignedClamp NonrawSupport OuterNet LowHotElimination PEqualNP.Outside.L_meta_9822.Clean GuardTags
theorem accepted_high_budget {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (seven : 7≤C.gates.countP countsAnd) (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8)
    (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    hotCount (env (SignedClamp.singleton s) false) (model pre post C.output) ≤ 1 := by
  have existing := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have hs := hot_guard existing s upper
  let net := model pre post C.output
  let u := retire (openPin s) net
  let k := specialize (close false) u
  have evalU (v : Input) (z : Bool) : u.eval (env v z) = outerValue pre post C.output (raise s v) z := by
    change (retire _ _).eval _ = _
    rw [retire_eval,row_open,model_eval r cand]
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have affected (v : Input) (vs : v s=true) : raise s v=v := by
    funext j
    by_cases e : j=s <;> simp [raise,e,vs]
  have zeroEval (v : Input) : u.eval (env v false)=edge (raise s v) := by
    rw [evalU]
    have exactOn := cut.computes (raise s v)
    have raised : innerValue pre g (raise s v)=true := by
      apply inner_mono_inputs (fun q hq => r.pos q (List.mem_append_left _ hq)) g _ hs
      intro j hj
      have eq : j=s := by simpa [SignedClamp.singleton] using hj
      simp [raise,eq]
    simpa [raised] using exactOn
  have fit (S : Finset (Fin 10)) : sees k S = LowPositive.pos s S := by
    let v : Input := fun j => decide (j∈S)
    change (specialize (close false) u).eval v = _
    rw [eval_specialize,close_eval,zeroEval]
    apply congrArg edge
    funext j
    by_cases e : j=s <;> simp [raise,v,e]
  let v := SignedClamp.singleton s
  have vs : v s=true := by simp [v,SignedClamp.singleton]
  have up : u.eval (env v true)=true := by rw [evalU,affected v vs]; exact upper
  have down : u.eval (env v false)=false := by rw [zeroEval,affected v vs];exact singleton_zero s
  have all : u.eval (env (fun _ => true) false) = true := by
    rw [zeroEval,affected _ rfl]
    rfl
  have noOut : ¬outUses (0 : Fin 11) u := by
    intro use
    have bad := outZeros u 0 use (env (fun _ => true) false) rfl
    rw [all] at bad
    exact Bool.noConfusion bad
  have hit : 0 < hits (0 : Fin 11) u := by
    by_contra! h
    have equal : u.eval (env v true)=u.eval (env v false) := by
      apply eval_congr_used
      intro j used
      exact Fin.cases (fun e => (e.elim (by omega) noOut).elim) (fun _ _ => rfl) j used
    rw [up,down] at equal
    exact Bool.noConfusion equal
  have charge := specialize_saves (0 : Fin 11) (close false) (by rfl) u
  change k.cost + hits (0 : Fin 11) u ≤ u.cost at charge
  have price := LowPositive.pin_price s k fit
  have amount : LowPositive.pinPrice s=7 := by simp [LowPositive.pinPrice,show ¬s.val≤4 by omega,su]
  have paid := retire_cost (openPin s) net
  rw [open_floor] at paid
  change u.cost + hotCount (env (SignedClamp.singleton s) false) net ≤ net.cost at paid
  have cap : net.cost ≤ 9 := (model_cost r).trans (or_cap r cand seven)
  change hotCount (env (SignedClamp.singleton s) false) net ≤ 1
  omega

theorem accepted_high_physical {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8)
    (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    physicalHot C.gates (List.ofFn (SignedClamp.singleton s))≤1 := by
  have cap := accepted_high_budget r cand seven s sl su upper
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have hs := hot_guard cut s upper
  rw [model_hot (r.split ▸ red) r.pos] at cap
  let w := List.ofFn (SignedClamp.singleton s)
  have off : g.op.eval (g.inputs.map fun j => (wiresFrom pre w).getD j false)=false := by
    rw [r.inv]
    change (!(innerValue pre g (SignedClamp.singleton s)))=false
    rw [hs];rfl
  rw [r.split,physicalHot_append]
  change physicalHot pre w + (physicalHot post (wiresFrom pre w ++ [_]) + _) ≤ 1
  rw [off]
  have flag : CircuitCompiler.orFlag g=false := by simp [CircuitCompiler.orFlag,r.inv]
  simpa only [flag,Bool.false_and,Bool.toNat_false,Nat.add_zero] using cap
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.accepted_high_physical
