import And9822H4Geo
namespace Research.Graph9822.H4Geo
open Research.Graph9822.H4Tree
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
theorem negative5 : negSiteP 5 := by unfold negSiteP; decide +kernel
private theorem row0 : ∀ k : Fin 10, 0≠k → let p := pairNumber 5 0 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 0 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 0)) := by decide +kernel
private theorem row1 : ∀ k : Fin 10, 1≠k → let p := pairNumber 5 1 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 1 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 1)) := by decide +kernel
private theorem row2 : ∀ k : Fin 10, 2≠k → let p := pairNumber 5 2 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 2 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 2)) := by decide +kernel
private theorem row3 : ∀ k : Fin 10, 3≠k → let p := pairNumber 5 3 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 3 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 3)) := by decide +kernel
private theorem row4 : ∀ k : Fin 10, 4≠k → let p := pairNumber 5 4 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 4 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 4)) := by decide +kernel
private theorem row5 : ∀ k : Fin 10, 5≠k → let p := pairNumber 5 5 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 5 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 5)) := by decide +kernel
private theorem row6 : ∀ k : Fin 10, 6≠k → let p := pairNumber 5 6 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 6 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 6)) := by decide +kernel
private theorem row7 : ∀ k : Fin 10, 7≠k → let p := pairNumber 5 7 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 7 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 7)) := by decide +kernel
private theorem row8 : ∀ k : Fin 10, 8≠k → let p := pairNumber 5 8 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 8 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 8)) := by decide +kernel
private theorem row9 : ∀ k : Fin 10, 9≠k → let p := pairNumber 5 9 k
  (choices[5]!).testBit (first p).val=true ∧ (choices[5]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 5 9 ∧ sideR (first p)=nm 5 k) ∨
   (sideL (first p)=nm 5 k ∧ sideR (first p)=nm 5 9)) := by decide +kernel
theorem selected5 : selectedPairP 5 := Fin.cases row0 (Fin.cases row1 (Fin.cases row2 (Fin.cases row3 (Fin.cases row4 (Fin.cases row5 (Fin.cases row6 (Fin.cases row7 (Fin.cases row8 (Fin.cases row9 (fun h=>Fin.elim0 h))))))))))
end Research.Graph9822.H4Geo
