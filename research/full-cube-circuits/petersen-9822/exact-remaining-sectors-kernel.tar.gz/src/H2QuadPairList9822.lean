import H2PortableQuads9822
namespace Research.Graph9822H2Check
def originalKeys : List (Nat × Nat) := [(0,1), (0,2), (0,3), (0,6), (0,7), (0,8), (0,9), (0,10), (0,11), (0,12), (1,3), (1,4), (1,5), (1,8), (1,9), (1,10), (1,11), (1,12), (2,4), (2,5), (2,6), (2,8), (2,9), (2,10), (2,11), (2,12), (3,4), (3,5), (3,6), (3,7), (3,9), (3,10), (3,11), (4,5), (4,6), (4,7), (4,8), (4,9), (4,12), (5,6), (5,7), (5,10), (5,11), (5,12), (6,7), (6,8), (6,9), (6,10), (7,8), (7,11), (7,12), (8,10), (8,11), (9,11), (9,12), (10,12)]
def keyGeometry (q : List Nat) : Bool :=
  quadGood q && q.all (fun i => q.all (fun j => !(i<j) || originalKeys.contains (i,j)))
theorem key_coverage : (List.range 50).all (fun k => keyGeometry (quadTable[k]!))=true := by decide +kernel
end Research.Graph9822H2Check
