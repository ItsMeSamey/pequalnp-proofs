import CompactNet9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean

def extend (ref : Nat → Lit) (atWire : Nat) (r : Lit) (i : Nat) : Lit :=
  if i = atWire then r else ref i

private theorem liftOld {n k} (net : Net n k) (g : Site) (l r)
    (a : Lit) (ha : a.wire < n+k) (env : Nat → Bool) :
    a.read ((net.snoc g l r).eval env) = a.read (net.eval env) := by
  simp [Lit.read,Net.eval,Nat.ne_of_lt ha]

theorem Realizes.negGate {n gs p k} {net : Net n k} {ref : Nat → Lit}
    (old : Realizes gs p k net ref) (hc : CleanL n gs) {g : Gate} (hg : gs[p]? = some g)
    (a : Nat) (ha : a < n+p) (hop : g.op = .not) (hin : g.inputs = [a]) :
    Realizes gs (p+1) k net (extend ref (n+p) (ref a).flip) := by
  constructor
  · intro w hw
    by_cases eq : w = n+p
    · subst w; simpa [extend,Lit.flip] using old.bound a ha
    · simpa [extend,eq] using old.bound w (by omega)
  · intro w hw x
    by_cases eq : w = n+p
    · subst w
      rw [vl_gate gs hc x p g hg,hop,hin]
      simp [extend, old.semantic a ha x, GateOp.eval]
    · simpa [extend,eq] using old.semantic w (by omega) x

abbrev join (isOr : Bool) (l r : Lit) : Site := ⟨isOr,l,r,false⟩

theorem Realizes.joinGate {n gs p k} {net : Net n k} {ref : Nat → Lit}
    (old : Realizes gs p k net ref) (hc : CleanL n gs) {g : Gate} (hg : gs[p]? = some g)
    (a b : Nat) (ha : a < n+p) (hb : b < n+p) (isOr : Bool)
    (hop : g.op = if isOr then GateOp.or else GateOp.and) (hin : g.inputs = [a,b]) :
    Realizes gs (p+1) (k+1)
      (net.snoc (join isOr (ref a) (ref b)) (old.bound a ha) (old.bound b hb))
      (extend ref (n+p) ⟨n+k,false⟩) := by
  constructor
  · intro w hw
    by_cases eq : w = n+p
    · subst w; simp [extend]
    · simp [extend,eq]; have := old.bound w (by omega); omega
  · intro w hw x
    by_cases eq : w = n+p
    · subst w
      have h1 := old.semantic a ha x
      have h2 := old.semantic b hb x
      rw [vl_gate gs hc x p g hg,hin,hop]
      cases isOr <;>
        simp [extend,Net.eval,join,Site.op,Lit.read,GateOp.eval,← h1,← h2]
    · simp only [extend,if_neg eq]
      rw [liftOld _ _ _ _ _ (old.bound w (by omega))]
      exact old.semantic w (by omega) x

theorem realizesPrefix {n gs} (hc : CleanL n gs) :
    ∀ p, p ≤ gs.length → ∃ (k : Nat) (net : Net n k) (ref : Nat → Lit),
      k = (gs.take p).countP bin ∧ Realizes gs p k net ref := by
  intro p
  induction p with
  | zero =>
    intro _
    refine ⟨0,.empty,fun w => ⟨w,false⟩,by simp,⟨?_,?_⟩⟩
    · intro w hw; simpa using hw
    · intro w hw x
      have h : w < n := by simpa using hw
      change inputEnv x w = vl gs x w
      rw [vl_input gs x w h]
      simp [inputEnv,List.getD_eq_getElem?_getD,h]
  | succ p ih =>
    intro hp
    obtain ⟨k,net,ref,hk,old⟩ := ih (by omega)
    have hlt : p < gs.length := by omega
    let g := gs[p]
    have hg : gs[p]? = some g := List.getElem?_eq_getElem hlt
    have hs : gs.take (p+1) = gs.take p ++ [g] := List.take_succ_eq_append_getElem hlt
    rcases hc p g hg with ⟨hop,a,ha,hin⟩ | ⟨hop,a,b,ha,hb,hin⟩
    · exact ⟨k,net,_,by simp [hs,hk,bin,hop],old.negGate hc hg a ha hop hin⟩
    · rcases hop with op | op
      · refine ⟨k+1,_,_,by simp [hs,hk,bin,op],old.joinGate hc hg a b ha hb false op hin⟩
      · refine ⟨k+1,_,_,by simp [hs,hk,bin,op],old.joinGate hc hg a b ha hb true op hin⟩

theorem compactOfReduced {n gs o} (hr : Reduced n gs o) (ho : o < n + gs.length) :
    ∃ (net : Net n (gs.countP bin)) (ref : Nat → Lit),
      Realizes gs gs.length (gs.countP bin) net ref ∧ (ref o).wire < n + gs.countP bin ∧
      ∀ x : Fin n → Bool, (ref o).read (net.eval (inputEnv x)) = vl gs x o := by
  obtain ⟨k,net,ref,hk,h⟩ := realizesPrefix hr.clean gs.length le_rfl
  rw [List.take_length] at hk
  subst k
  exact ⟨net,ref,h,h.bound o ho,h.semantic o ho⟩

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.compactOfReduced
