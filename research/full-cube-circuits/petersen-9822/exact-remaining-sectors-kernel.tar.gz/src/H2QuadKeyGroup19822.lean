import H2QuadPairList9822
import H2ShortDomTransport9822
import H2ShortDom00109822
import H2PairDom00119822
import H2ShortDom00129822
import H2ShortDom01039822
import H2ShortDom01049822
import H2ShortDom01059822
import H2ShortDom01089822
namespace Research.Graph9822H2Check
def keys1 : List (Nat × Nat) := [(0,10), (0,11), (0,12), (1,3), (1,4), (1,5), (1,8)]
theorem paidKeys1 : keys1.all (fun p => pairDom p.1 p.2)=true := by
  simp only [keys1,List.all_cons,List.all_nil,Bool.and_eq_true_iff]
  exact ⟨dom_of_short (by decide) short_dom_0_10, dom0_11, dom_of_short (by decide) short_dom_0_12, dom_of_short (by decide) short_dom_1_3, dom_of_short (by decide) short_dom_1_4, dom_of_short (by decide) short_dom_1_5, dom_of_short (by decide) short_dom_1_8, True.intro⟩
end Research.Graph9822H2Check
