import H3FirstBroadLogic9822
namespace Research.Graph9822FirstBroad

def pack (step : Nat) (xs : List Nat) := xs.foldr (fun x z => (z <<< step) ||| x) 0

theorem pack_bit {step : Nat} (xs : List Nat) (bound : ∀ x ∈ xs, x < 2^step)
    (i j : Nat) (inside : j < step) :
    (pack step xs).testBit (step*i+j) = (xs[i]?.getD 0).testBit j := by
  induction xs generalizing i with
  | nil => simp [pack]
  | cons x xs ih =>
    have xsmall := bound x (by simp)
    have tail : ∀ y ∈ xs, y < 2^step := fun y mem => bound y (by simp [mem])
    cases i with
    | zero =>
      have no : ¬ j ≥ step := by omega
      simp [pack,Nat.testBit_shiftLeft,no]
    | succ i =>
      have hi : step ≤ step * (i+1) + j := by rw [Nat.mul_succ]; omega
      have sub : step * (i+1) + j - step = step*i+j := by rw [Nat.mul_succ]; omega
      have off : x.testBit (step*(i+1)+j) = false := Nat.testBit_lt_two_pow
        (lt_of_lt_of_le xsmall (Nat.pow_le_pow_right (by decide : 0 < (2:Nat)) hi))
      simpa [pack,Nat.testBit_or,Nat.testBit_shiftLeft,hi,sub,off] using ih tail i

theorem low32_on (p : Nat → Bool) (j : Fin 32) : (low32 p).testBit j.val=p j.val := by
  let xs := (List.range 32).map (fun i => if p i then 1 else 0)
  have small : ∀ x ∈ xs, x < 2^1 := by
    intro x mem
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp mem
    split <;> decide
  have z := pack_bit xs small j.val 0 (by decide)
  have rep : low32 p = pack 1 xs := by simp [low32,pack,xs,List.foldr_map]
  rw [rep]
  cases value : p j.val <;> simpa [xs,j.isLt,value,List.getElem?_eq_getElem,apply_ite] using z

theorem high_on (f : Nat → Nat) (bd : ∀ i<32, f i < 2^32) (a b : Fin 32) :
    (high f).testBit (32*a.val+b.val) = (f a.val).testBit b.val := by
  let xs := (List.range 32).map f
  have small : ∀ x ∈ xs, x < 2^32 := by
    intro x mem
    obtain ⟨i,hm,rfl⟩ := List.mem_map.mp mem
    exact bd i (List.mem_range.mp hm)
  have z := pack_bit xs small a.val b.val b.isLt
  have rep : high f = pack 32 xs := by simp [high,pack,xs,List.foldr_map]
  rw [rep]
  simpa [xs,a.isLt,List.getElem?_eq_getElem] using z

theorem low32_bound (p : Nat → Bool) : low32 p < 2^32 := by
  have step (xs : List Nat) :
      xs.foldr (fun i z => (z <<< 1) ||| (if p i then 1 else 0)) 0 < 2^xs.length := by
    induction xs with
    | nil => simp
    | cons i xs ih =>
      simp only [List.length_cons,List.foldr_cons]
      apply Nat.or_lt_two_pow
      · let t := xs.foldr (fun i z => (z <<< 1) ||| (if p i then 1 else 0)) 0
        change t <<< 1 < 2^(xs.length+1)
        change t < 2^xs.length at ih
        simp only [Nat.shiftLeft_eq,Nat.pow_succ,Nat.pow_zero,one_mul]; omega
      · have pow := Nat.one_le_pow xs.length 2 (by decide)
        split <;> simp only [Nat.pow_succ] <;> omega
  simpa [low32] using step (List.range 32)

theorem domain_on (a b : Fin 32) (disj : a.val &&& b.val = 0) :
    domain.testBit (32*a.val+b.val) = true := by
  rw [domain,high_on _ (fun i _ => low32_bound _) a b,low32_on]
  simp [disj]

end Research.Graph9822FirstBroad
