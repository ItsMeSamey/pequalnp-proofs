import And9822H4Tree03
namespace Research.Graph9822.H4Tree
theorem t200 {p : Bad} (legal : Respects p) (ok : Within p 210624583349565899666085026187855414173915595902725278221113229568) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t201 {p : Bad} (legal : Respects p) (ok : Within p 6582018278707805362258503370925005346304204242862967817320268168) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t202 {p : Bad} (legal : Respects p) (ok : Within p 217206601628273705027629905712427439579690657160863445693683990920) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t200 legal) (t201 legal)
theorem t203 {p : Bad} (legal : Respects p) (ok : Within p 23390449596262479263486877931180453070975904251904) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t204 {p : Bad} (legal : Respects p) (ok : Within p 217206601628273728417365791016267791365792798732692231384362647944) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t202 legal) (t203 legal)
theorem t205 {p : Bad} (legal : Respects p) (ok : Within p 49087771183810098459022995644465343361379204723520831488) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t206 {p : Bad} (legal : Respects p) (ok : Within p 421249166747884313724538894074600374998284761045057274523800305664) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t207 {p : Bad} (legal : Respects p) (ok : Within p 421249166674276637277324169809357635468494055301654480232539750400) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t208 {p : Bad} (legal : Respects p) (ok : Within p 24663600110810398947127447046691875714244793173723316224) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t209 {p : Bad} (legal : Respects p) (ok : Within p 421249166698892346902482509681809176322330512429374129240555913216) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t207 legal) (t208 legal)
theorem t210 {p : Bad} (legal : Respects p) (ok : Within p 421249166747932204210190953149276281191140406305173807538710249472) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t206 legal) (t209 legal)
theorem t211 {p : Bad} (legal : Respects p) (ok : Within p 421249166747932227600640549071473177757079874022252271082846289920) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t205 legal) (t210 legal)
theorem t212 {p : Bad} (legal : Respects p) (ok : Within p 638455768327166075319848300698076967688123311162066360624918561160) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t204 legal) (t211 legal)
theorem t213 {p : Bad} (legal : Respects p) (ok : Within p 638455768240627944356128042832251995933359544305170489179646198152) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t214 {p : Bad} (legal : Respects p) (ok : Within p 75460750945815324794216184812057367393135172838363829895176) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t215 {p : Bad} (legal : Respects p) (ok : Within p 638455843701378890171452837048436807990726937440343327543476093320) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t213 legal) (t214 legal)
theorem t216 {p : Bad} (legal : Respects p) (ok : Within p 638455843750466661355262935512776715618331944293338002400676413832) : Success p :=
  fork legal ok 16 (by decide +kernel) (by decide +kernel) (t212 legal) (t215 legal)
theorem t217 {p : Bad} (legal : Respects p) (ok : Within p 49039857308422154426106016569585683484423963583379931136) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t218 {p : Bad} (legal : Respects p) (ok : Within p 289433237876875061926841145395416585507120952576471434526768) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t219 {p : Bad} (legal : Respects p) (ok : Within p 289482277734183484081267251411986171190605376540054814457904) : Success p :=
  fork legal ok 16 (by decide +kernel) (by decide +kernel) (t217 legal) (t218 legal)
theorem t220 {p : Bad} (legal : Respects p) (ok : Within p 214058977148147534141455500997340319053611661773497599787127) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t221 {p : Bad} (legal : Respects p) (ok : Within p 51422017416311078553227750512902068444388604255227629640089671) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t222 {p : Bad} (legal : Respects p) (ok : Within p 210507804158226759925099497740676666105652974714887) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t223 {p : Bad} (legal : Respects p) (ok : Within p 51422017416498196621501013714842302778488951399017980866068551) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t221 legal) (t222 legal)
theorem t224 {p : Bad} (legal : Respects p) (ok : Within p 51636076393646343977236507627594657965256816879604586418012279) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t220 legal) (t223 legal)
theorem t225 {p : Bad} (legal : Respects p) (ok : Within p 51711499694232380105582280966254288949679556775558035680526455) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t219 legal) (t224 legal)
theorem t226 {p : Bad} (legal : Respects p) (ok : Within p 638507479777820427001795843589379220542323629125963776818308710911) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t216 legal) (t225 legal)
theorem t227 {p : Bad} (legal : Respects p) (ok : Within p 13483264342689962309417817481917465333698606902207344234320088793344) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t228 {p : Bad} (legal : Respects p) (ok : Within p 12022312468695449399731227989758100090864594304630784) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t229 {p : Bad} (legal : Respects p) (ok : Within p 13483264342689974331730286177324329769061479352374513272985422397696) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t227 legal) (t228 legal)
theorem t230 {p : Bad} (legal : Respects p) (ok : Within p 3297738167714768918557454338781523139797457600423350057165652000) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t231 {p : Bad} (legal : Respects p) (ok : Within p 13483271071743034666252065009290591447679877414099549738430420222240) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t229 legal) (t230 legal)
theorem t232 {p : Bad} (legal : Respects p) (ok : Within p 2935134880049806495396365096172886747971118432256) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t233 {p : Bad} (legal : Respects p) (ok : Within p 13483271071743034666264196614678592106668872844839870447089673568544) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t231 legal) (t232 legal)
theorem t234 {p : Bad} (legal : Respects p) (ok : Within p 40439939635500187981537951942189215378411248573847190735172315119904) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t235 {p : Bad} (legal : Respects p) (ok : Within p 40443230644614842415946862169949735881921643400462898328443736293664) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t233 legal) (t234 legal)
theorem t236 {p : Bad} (legal : Respects p) (ok : Within p 13479973333575319920723242743017080455323270461616384546370867953920) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t237 {p : Bad} (legal : Respects p) (ok : Within p 51622884672032003175161596434957479839345143405044512176734212) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t238 {p : Bad} (legal : Respects p) (ok : Within p 1677743751840233365706926767372948709217345528033057662042112000) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t239 {p : Bad} (legal : Respects p) (ok : Within p 1729366636512263884544487949609629888439282443963160336162357252) : Success p :=
  fork legal ok 14 (by decide +kernel) (by decide +kernel) (t237 legal) (t238 legal)
theorem t240 {p : Bad} (legal : Respects p) (ok : Within p 1722637583445637575380983362989726309903839388267016876604784640) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t241 {p : Bad} (legal : Respects p) (ok : Within p 1729366636512263884544487949609629888439320222895023293324066820) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t239 legal) (t240 legal)
theorem t242 {p : Bad} (legal : Respects p) (ok : Within p 1729366636505972097159815329251404928301901113303482321602609248) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t243 {p : Bad} (legal : Respects p) (ok : Within p 1729366636512263884544487949609629888439320222895023293324066916) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t241 legal) (t242 legal)
theorem t244 {p : Bad} (legal : Respects p) (ok : Within p 1535718517351612832018715703127656766747835367426) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t245 {p : Bad} (legal : Respects p) (ok : Within p 1729366636512263935925404887024185606537615123076848203102945382) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t243 legal) (t244 legal)
theorem t246 {p : Bad} (legal : Respects p) (ok : Within p 13481702700211832161269432959838834110146617571622203236576357515622) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t236 legal) (t245 legal)
theorem t247 {p : Bad} (legal : Respects p) (ok : Within p 40444953282198294345361008742870498388909782953860938711201841414502) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t235 legal) (t246 legal)
theorem t248 {p : Bad} (legal : Respects p) (ok : Within p 41083409088874628811918955997203811778887076019415927177181631873535) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t226 legal) (t247 legal)
theorem t249 {p : Bad} (legal : Respects p) (ok : Within p 1733673493893543615985079657111707535313996379724642800624621125996937215) : Success p :=
  fork legal ok 9 (by decide +kernel) (by decide +kernel) (t199 legal) (t248 legal)
end Research.Graph9822.H4Tree
