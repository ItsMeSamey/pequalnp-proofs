import H2QuadPairList9822
import H2CanonicalPairs9822
namespace Research.Graph9822H2Check
theorem geometryFromPaidKeys (paid : originalKeys.all (fun p => pairDom p.1 p.2)=true) (c : Nat) (small : c<50) : quadGood (quadTable[c]!)=true ∧
    ∀ i∈quadTable[c]!,∀ k∈quadTable[c]!,i<k → pairDom i k=true := by
  obtain ⟨good,coverage⟩ := Bool.and_eq_true_iff.mp
    (List.all_eq_true.mp key_coverage c (List.mem_range.mpr small))
  refine ⟨good,?_⟩
  intro i im j jm lt
  have relation := List.all_eq_true.mp (List.all_eq_true.mp coverage i im) j jm
  have inside : (i,j)∈originalKeys := List.contains_iff_mem.mp (by simpa [lt] using relation)
  exact List.all_eq_true.mp paid (i,j) inside
end Research.Graph9822H2Check
#print axioms Research.Graph9822H2Check.geometryFromPaidKeys
