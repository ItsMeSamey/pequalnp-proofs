import And9822H4Tape
import And9822CollectorShape

namespace Research.Graph9822.ReverseChannel
open Research.Graph9822.FreeOR Research.Graph9822.Footprint
open Research.Graph9822Resolution
open Research.Graph9822.FourSaturation

/-- With the collector physically last on the compact tape, all four original
    negative rays are simultaneously realized in the canonical environment. -/
theorem four_physical (c : FiveProgram) (H a b d t : Product)
    (hidden : (hiddenFirst c).1=[H,a,b,d]) (term : (hiddenFirst c).2=[t]) :
    let p := program a b d t
    let v := fun m : Fin 1024 => run [H,a,b,d,t] 10 (fullWire m.val)
    (∀ m, v m 14 = accepts m.val) ∧
    (∀ m i, i<4 → v m (slot i) = productBit (v m) (p i)) ∧
    (∀ i j, j∈(p i).1 → j∉(p i).2) ∧
    (∀ i, i<4 → ∀ side j, j∈arm (p i) side →
      j<11 ∨ ∃ k, i<k ∧ k<4 ∧ j=slot k) := by
  obtain ⟨chron,apart,bounds⟩ := hidden_first_shape c
  rw [hidden] at chron apart bounds
  rw [term] at bounds
  obtain ⟨ta,tb⟩ := bounds t (by simp)
  have order : Chronological 10 [H,a,b,d,t] [] := by
    exact ⟨chron.1,chron.2.1,chron.2.2.1,chron.2.2.2.1,
      chron.2.2.2.2.1,chron.2.2.2.2.2.1,
      chron.2.2.2.2.2.2.1,chron.2.2.2.2.2.2.2.1,
      tb.1,tb.2,by simp [Chronological]⟩
  constructor
  · intro m
    have eq := hidden_first_correct c m
    rw [hidden,term] at eq
    simpa [run,Function.update] using eq
  constructor
  · intro m i hi
    interval_cases i <;> first
    | exact placed [H,a,b,d,t] 10 (fullWire _) (i:=4) order rfl
    | exact placed [H,a,b,d,t] 10 (fullWire _) (i:=3) order rfl
    | exact placed [H,a,b,d,t] 10 (fullWire _) (i:=2) order rfl
    | exact placed [H,a,b,d,t] 10 (fullWire _) (i:=1) order rfl
  constructor
  · intro i
    by_cases small : i<4
    · interval_cases i <;> first | exact ta | exact apart _ (by simp [program])
    · obtain ⟨k,rfl⟩ := Nat.exists_eq_add_of_le (by omega : 4 ≤ i)
      simp [program,Nat.add_comm]
  · intro i hi side j hj
    have limit : j<14-i := by
      interval_cases i <;> cases side <;>
        first | exact tb.1 j hj | exact tb.2 j hj
              | exact chron.2.2.2.2.2.2.1 j hj | exact chron.2.2.2.2.2.2.2.1 j hj
              | exact chron.2.2.2.2.1 j hj | exact chron.2.2.2.2.2.1 j hj
              | exact chron.2.2.1 j hj | exact chron.2.2.2.1 j hj
    by_cases small : j<11
    · exact Or.inl small
    · exact Or.inr ⟨14-j,by omega,by omega,by unfold slot; omega⟩
/-- Each negative mask obtains an input-independent false subcube on the original
    ten raw wires plus the physical output of H. Its trace lives in the same
    at-most-nine set for all masks of this collector. -/
theorem physical_cubes (c : FiveProgram) (H a b d t : Product)
    (hidden : (hiddenFirst c).1=[H,a,b,d]) (term : (hiddenFirst c).2=[t]) :
    let p := program a b d t
    let v := fun m : Fin 1024 => run [H,a,b,d,t] 10 (fullWire m.val)
    let tr := fun m : Fin 1024 => row p slot (dir (v m) p) 4
    let blocked := fun r j => j<11 ∧ demand p r j
    (Finset.univ.image tr).card ≤ 9 ∧
    (∀ m, accepts m.val=false → ∀ j, blocked (tr m) j → v m j=false) ∧
    (∀ m z, (∀ j, blocked (tr m) j → v z j=false) → accepts z.val=false) := by
  dsimp only
  obtain ⟨output,ev,sep,scope⟩ := four_physical c H a b d t hidden term
  let p := program a b d t
  let v := fun m : Fin 1024 => run [H,a,b,d,t] 10 (fullWire m.val)
  constructor
  · apply le_trans _ (four_one (channel p (slot 1)) (channel p (slot 2)) (channel p (slot 3)))
    apply Finset.card_le_card
    intro r hr
    obtain ⟨m,_,rfl⟩ := Finset.mem_image.mp hr
    rw [row_four]
    exact trace4_mem _ _ _ _
  constructor
  · rintro m cold j ⟨_,z,mz,read⟩
    exact all_false p slot (v m) 4 sep (ev m) ((output m).trans cold) z mz j read
  · intro m z zero
    rw [←output z]
    apply replay p slot (dir (v m) p) (v z) 4 (by decide) (fun j=>j<11) sep (ev z) scope
    intro u mu j read jl
    exact zero j ⟨jl,u,mu,read⟩
theorem leaf_values (H a b d t : Product) (m : Fin 1024) :
    let v := run [H,a,b,d,t] 10 (fullWire m.val)
    (∀ j<10, v j=fullWire m.val j) ∧ v 10=productBit (fullWire m.val) H := by
  constructor
  · intro j small
    exact stale_value _ small _
  · change run [a,b,d,t] 11 (Function.update (fullWire m.val) 10 _) 10 = _
    rw [stale_value _ (by decide : 10<11)]
    simp
/-- A common trace for two rejected masks rules out every accepted mask whose
    eleven physical leaf bits are covered coordinatewise by those two masks. -/
theorem forbid_cover (c : FiveProgram) (H a b d t : Product)
    (hh : (hiddenFirst c).1=[H,a,b,d]) (ht : (hiddenFirst c).2=[t])
    (x y z : Fin 1024) (cx : accepts x.val=false) (cy : accepts y.val=false)
    (hz : accepts z.val=true) :
    let p := program a b d t
    let v := fun m : Fin 1024 => run [H,a,b,d,t] 10 (fullWire m.val)
    let tr := fun m : Fin 1024 => row p slot (dir (v m) p) 4
    (∀ j<11, v z j=true → v x j=true ∨ v y j=true) → tr x ≠ tr y := by
  dsimp only
  intro cover same
  obtain ⟨_,cold,rerun⟩ := physical_cubes c H a b d t hh ht
  have rejected := rerun x z (by
    intro j blocked
    have sx := cold x cx j blocked
    have sy := cold y cy j ⟨blocked.1,by
      change demand _ (row _ _ _ 4) j
      rw [←same]
      exact blocked.2⟩
    change run [H,a,b,d,t] 10 (fullWire z.val) j=false
    cases bit : run [H,a,b,d,t] 10 (fullWire z.val) j with
    | false => rfl
    | true =>
      rcases cover j blocked.1 bit with left | right
      · exact Bool.noConfusion (sx.symm.trans left)
      · exact Bool.noConfusion (sy.symm.trans right))
  exact Bool.noConfusion (hz.symm.trans rejected)
theorem no_ten (c : FiveProgram) (H a b d t : Product)
    (hh : (hiddenFirst c).1=[H,a,b,d]) (ht : (hiddenFirst c).2=[t])
    (sel : Fin 10 → Fin 1024) (neg : ∀ i, accepts (sel i).val=false)
    (separate : ∀ i j, i≠j → ∃ z : Fin 1024, accepts z.val=true ∧
      ∀ k<11, run [H,a,b,d,t] 10 (fullWire z.val) k=true →
        run [H,a,b,d,t] 10 (fullWire (sel i).val) k=true ∨
        run [H,a,b,d,t] 10 (fullWire (sel j).val) k=true) : False := by
  let tr := fun m : Fin 1024 => row (program a b d t) slot
    (dir (run [H,a,b,d,t] 10 (fullWire m.val)) (program a b d t)) 4
  have inj : Function.Injective (fun i => tr (sel i)) := by
    intro i j same
    by_contra ne
    obtain ⟨z,pos,covered⟩ := separate i j ne
    exact forbid_cover c H a b d t hh ht _ _ z (neg i) (neg j) pos covered same
  have small := (physical_cubes c H a b d t hh ht).1
  have sub : Finset.univ.image (fun i => tr (sel i)) ⊆ Finset.univ.image tr := by
    intro r hr
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hr
    exact Finset.mem_image_of_mem _ (Finset.mem_univ _)
  have upper := (Finset.card_le_card sub).trans small
  rw [Finset.card_image_of_injective _ inj] at upper
  simpa using upper
/-- Numeric callers inspect the first product on raw masks; later products
    disappear from all pairwise cover checks. -/
theorem raw_no_ten (c : FiveProgram) (H a b d t : Product)
    (hh : (hiddenFirst c).1=[H,a,b,d]) (ht : (hiddenFirst c).2=[t])
    (sel : Fin 10 → Fin 1024) (neg : ∀ i, accepts (sel i).val=false)
    (separate : ∀ i j, i≠j → ∃ z : Fin 1024, accepts z.val=true ∧
      (∀ k<10, fullWire z.val k=true →
        fullWire (sel i).val k=true ∨ fullWire (sel j).val k=true) ∧
      (productBit (fullWire z.val) H=true →
        productBit (fullWire (sel i).val) H=true ∨ productBit (fullWire (sel j).val) H=true)) :
    False := by
  apply no_ten c H a b d t hh ht sel neg
  intro i j ne
  obtain ⟨z,pos,raw,first⟩ := separate i j ne
  refine ⟨z,pos,?_⟩
  intro k hk
  by_cases small : k<10
  · simpa only [(leaf_values H a b d t z).1 k small,
      (leaf_values H a b d t (sel i)).1 k small,
      (leaf_values H a b d t (sel j)).1 k small] using raw k small
  · have eq : k=10 := by omega
    subst k
    simpa only [(leaf_values H a b d t z).2,(leaf_values H a b d t (sel i)).2,
      (leaf_values H a b d t (sel j)).2] using first
end Research.Graph9822.ReverseChannel
