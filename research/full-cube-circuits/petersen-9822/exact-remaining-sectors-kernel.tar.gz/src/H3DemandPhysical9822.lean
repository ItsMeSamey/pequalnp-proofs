import PEqualNP.Defs
namespace Research.Graph9822DemandThree

def fires {V : Type} (raw : V → Prop) (h q : Prop) : V ⊕ Bool → Prop
  | .inl v => raw v
  | .inr false => h
  | .inr true => q

theorem missing_requires_q {V P N D : Type}
    (pos : P → V → Prop) (neg : N → V → Prop) (hp qp : P → Prop) (hn qn : N → Prop)
    (reads : D → V ⊕ Bool → Prop) (slot : N → D)
    (complete : ∀ d p, ∃ f, reads d f ∧ fires (pos p) (hp p) (qp p) f)
    (cold : ∀ n f, reads (slot n) f → ¬ fires (neg n) (hn n) (qn n) f)
    {i j : N} (equal : slot i = slot j) {p : P}
    (coveredRaw : ∀ v, pos p v → neg i v ∨ neg j v)
    (missing : ¬ (hp p ∧ ¬hn i ∧ ¬hn j)) :
    qp p ∧ ¬qn i ∧ ¬qn j := by
  obtain ⟨f,read,hot⟩ := complete (slot i) p
  have readj : reads (slot j) f := equal ▸ read
  have ci := cold i f read
  have cj := cold j f readj
  cases f with
  | inl v =>
    rcases coveredRaw v hot with x | x
    · exact (ci x).elim
    · exact (cj x).elim
  | inr tag =>
    cases tag with
    | false => exact (missing ⟨hot,ci,cj⟩).elim
    | true => exact ⟨hot,ci,cj⟩

theorem eight_collide (slot : Fin 8 → Fin 7) : ∃ i j, i < j ∧ slot i = slot j := by
  classical
  by_contra no
  have injective : Function.Injective slot := by
    intro i j eq
    rcases lt_trichotomy i j with lt | same | gt
    · exact (no ⟨i,j,lt,eq⟩).elim
    · exact same
    · exact (no ⟨j,i,gt,eq.symm⟩).elim
  have impossible := Fintype.card_le_of_injective slot injective
  simpa using impossible

end Research.Graph9822DemandThree
