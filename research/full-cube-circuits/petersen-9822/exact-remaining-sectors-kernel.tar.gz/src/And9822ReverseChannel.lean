import And9822FreeORDefs
import And9822FootprintFour

namespace Research.Graph9822.ReverseChannel
open Research.Graph9822.FreeOR Research.Graph9822.Footprint
open Research.Graph9822Resolution

def arm (p : Product) (b : Bool) := if b then p.2 else p.1

/-- A consumer has at most one polarity at which it demands a particular producer. -/
def hit (p : Product) (j : Nat) : Option Bool :=
  if j ∈ p.1 then some false else if j ∈ p.2 then some true else none

theorem hit_iff (p : Product) (j : Nat) (sep : ∀ v ∈ p.1, v ∉ p.2) (b : Bool) :
    hit p j = some b ↔ j ∈ arm p b := by
  by_cases l : j ∈ p.1
  · have r := sep j l
    cases b <;> simp [hit,arm,l,r]
  · by_cases r : j ∈ p.2 <;> cases b <;> simp [hit,arm,l,r]

def channel (prod : Nat → Product) (j : Nat) : Channel := fun i => hit (prod i) j

def demand (prod : Nat → Product) (tr : Trace) (j : Nat) :=
  ∃ t ∈ tr, j ∈ arm (prod t.1) t.2

theorem active_iff (prod : Nat → Product) (sep : ∀ i v, v ∈ (prod i).1 → v ∉ (prod i).2)
    (j : Nat) (tr : Trace) : active (channel prod j) tr = true ↔ demand prod tr j := by
  simp only [active,channel,List.any_eq_true,beq_iff_eq,demand]
  constructor
  · rintro ⟨t,m,h⟩
    exact ⟨t,m,(hit_iff _ _ (sep _) _).mp h⟩
  · rintro ⟨t,m,h⟩
    exact ⟨t,m,(hit_iff _ _ (sep _) _).mpr h⟩

/-- Each individual false product selects a genuinely false arm in its original
    physical environment. Choices for inactive products are harmless. -/
def dir (values : Wire) (prod : Nat → Product) : Dir :=
  fun i => readArm values (prod i).1

theorem false_ray (values : Wire) (prod : Nat → Product) (i : Nat)
    (h : productBit values (prod i) = false) :
    ∀ j ∈ arm (prod i) (dir values prod i), values j = false := by
  have zz : readArm values (arm (prod i) (dir values prod i)) = false := by
    cases l : readArm values (prod i).1 <;> simp_all [productBit,arm,dir]
  simpa [readArm,List.any_eq_false] using zz

def trace4 (a b c : Channel) (w : Dir) :=
  stepRow 3 (active c) w (stepRow 2 (active b) w
    (stepRow 1 (active a) w (stepRow 0 full w [])))

theorem trace4_mem (a b c : Channel) (w : Dir) :
    trace4 a b c w ∈ next 3 (active c) (next 2 (active b) (next 1 (active a) first)) :=
  step_mem _ _ _ _ _ (step_mem _ _ _ _ _ (step_mem _ _ _ _ _
    (step_mem _ _ _ _ _ (by simp [start]))))

theorem witness_bound {ι : Type} [DecidableEq ι] (rows : Finset ι)
    (a b c : Channel) (w : ι → Dir)
    (different : Set.InjOn (fun i => trace4 a b c (w i)) ↑rows) : rows.card ≤ 9 := by
  classical
  calc
    rows.card = (rows.image (fun i => trace4 a b c (w i))).card :=
      (Finset.card_image_of_injOn different).symm
    _ ≤ _ := Finset.card_le_card (by
      intro r hr
      obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hr
      exact trace4_mem a b c (w i))
    _ ≤ 9 := four_one a b c
end Research.Graph9822.ReverseChannel
