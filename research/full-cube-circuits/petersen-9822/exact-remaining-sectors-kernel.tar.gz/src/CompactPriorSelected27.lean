import CompactPriorSelected27Cell11
-- CompactPriorFace67
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_40 : CutRow book 7 40 12 := (joinRow (joinRow (joinRow row7_40_seg40 row7_40_seg43) row7_40_seg46) row7_40_seg49)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace68
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_52 : CutRow book 7 52 12 := (joinRow (joinRow (joinRow row7_52_seg52 row7_52_seg55) row7_52_seg58) row7_52_seg61)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace69
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_64 : CutRow book 7 64 12 := (joinRow (joinRow (joinRow row7_64_seg64 row7_64_seg67) row7_64_seg70) row7_64_seg73)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
