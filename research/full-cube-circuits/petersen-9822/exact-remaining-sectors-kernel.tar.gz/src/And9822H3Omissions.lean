import And9822H3FirstCollision
import OR9822RawColumnCode
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution
open Research.Graph9822.FourSaturation Research.Graph9822.FeatureRun
private def skipRows (a b : Fin 16) (i : Fin 14) : Fin 16 :=
  ⟨if i.val<a.val then i.val else if i.val+1<b.val then i.val+1 else i.val+2, by split <;> (try split) <;> omega⟩
private theorem omit_avoids (a b : Fin 16) (ab : a<b) (i : Fin 14) :
    skipRows a b i≠a ∧ skipRows a b i≠b := by
  change a.val<b.val at ab
  have h : (skipRows a b i).val ≠ a.val ∧ (skipRows a b i).val ≠ b.val := by
    unfold skipRows; dsimp only; split <;> (try split) <;> omega
  exact ⟨fun e => h.1 (congrArg Fin.val e),fun e => h.2 (congrArg Fin.val e)⟩
private theorem omit_strict (a b : Fin 16) {i j : Fin 14} (lt : i<j) : skipRows a b i<skipRows a b j := by
  change i.val<j.val at lt
  change (skipRows a b i).val<(skipRows a b j).val
  unfold skipRows; dsimp only; split <;> (try split) <;> (try split) <;> (try split) <;> omega

def pm (i : Fin 13) := rawRow ⟨i.val,by omega⟩
def nm (i : Fin 16) := rawRow ⟨13+i.val,by omega⟩

theorem omitted_physical (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B])
    (skip : Fin 7) (unused : ¬reads R A B skip 11) (a b : Fin 16) (ab : a<b) :
    ∃ i j : Fin 16, i<j ∧ i≠a ∧ i≠b ∧ j≠a ∧ j≠b ∧
      ∀ e : Fin 13, (nm i ||| nm j) &&& pm e = pm e →
      (encode (firstCol H)).testBit e.val=true ∧
      (encode (firstCol H)).testBit (13+i.val)=false ∧
      (encode (firstCol H)).testBit (13+j.val)=false := by
  let n (i : Fin 14) : Fin 1024 :=
    ⟨nm (skipRows a b i),(row_extrema ⟨13+(skipRows a b i).val,by omega⟩).1⟩
  have hn (i : Fin 14) : accepts (n i).val=false := by
    have h := (row_extrema ⟨13+(skipRows a b i).val,by omega⟩).2
    simpa [n,nm] using h
  obtain ⟨i,j,ij,compat⟩ := first_collision c H Q R A B hh ht skip unused n hn
  refine ⟨_,_,omit_strict a b ij,(omit_avoids a b ab i).1,(omit_avoids a b ab i).2,
    (omit_avoids a b ab j).1,(omit_avoids a b ab j).2,?_⟩
  intro e sub
  let r : Fin 29 := ⟨e.val,by omega⟩
  let m : Fin 1024 := ⟨pm e,(row_extrema r).1⟩
  have on : accepts m.val=true := by simpa [m,pm,r,e.isLt] using (row_extrema r).2
  have cov (k : Nat) (lt : k<10) (bit : fullWire m.val k=true) :
      fullWire (n i).val k=true ∨ fullWire (n j).val k=true := by
    have eb : (pm e).testBit k=true := by simpa [fullWire,lt,m] using bit
    have bits := congrArg (fun x : Nat => x.testBit k) sub
    simpa [Nat.testBit_and,Nat.testBit_or,eb,fullWire,lt,n] using bits
  obtain ⟨x,y,z⟩ := compat m on cov
  have original (t : Fin 29) : (encode (firstCol H)).testBit t.val=
      productBit (fullWire (rawRow t)) H := by rw [encode_bit,actual_input]; rfl
  exact ⟨(original r).trans x,(original ⟨_,by omega⟩).trans y,(original ⟨_,by omega⟩).trans z⟩
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.omitted_physical
