import H3FirstBroadPhysical9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822H2Check Research.Graph9822FirstAdmission
open Research.Graph9822.FeatureRun (rawCode rawCode_high)
theorem split_disjoint (a b : Fin 1024) (disj : a.val &&& b.val=0) :
    (lower a).val &&& (lower b).val=0 ∧ (upper a).val &&& (upper b).val=0 := by
  have lowEq (x : Nat) : x%32=x &&& (2^5-1) := (Nat.and_two_pow_sub_one_eq_mod x 5).symm
  have dj : (lower a).val &&& (lower b).val=0 := by
    change a.val%32 &&& b.val%32=0
    rw [lowEq,lowEq]
    calc
      _ = (a.val &&& b.val) &&& ((2^5-1) &&& (2^5-1)) := by ac_rfl
      _ = 0 := by simp [disj]
  have hj : (upper a).val &&& (upper b).val=0 := by
    have z (x : Nat) : x/32=x >>> 5 := (Nat.shiftRight_eq_div_pow x 5).symm
    change a.val/32 &&& b.val/32=0
    rw [z,z,←Nat.shiftRight_and_distrib,disj]; decide
  exact ⟨dj,hj⟩

theorem raw_meet_bound (a b : Fin 1024) : rawCode a.val &&& rawCode b.val < 2^29 := by
  by_contra! no
  obtain ⟨j,high,hot⟩ := Nat.exists_ge_and_testBit_of_ge_two_pow no
  simp [Nat.testBit_and,rawCode_high _ _ high] at hot
end Research.Graph9822FirstBroad
