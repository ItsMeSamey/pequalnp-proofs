import CompactPriorSelected25Cell00
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row8_107_seg110 : CutRow book 8 110 3 := bandCut 9 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
