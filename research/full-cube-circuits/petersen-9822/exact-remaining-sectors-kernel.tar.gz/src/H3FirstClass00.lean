import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class000 : runPacket packets[0]! = true := by decide +kernel
theorem class001 : runPacket packets[1]! = true := by decide +kernel
theorem class002 : runPacket packets[2]! = true := by decide +kernel
theorem class003 : runPacket packets[3]! = true := by decide +kernel
end Research.Graph9822FirstBroad
