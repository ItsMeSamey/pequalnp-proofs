import H2LocalCover9822
namespace Research.Graph9822H2Check

structure LocalNode where
  s : Nat
  code : Nat
  children : List Nat
  root : Bool
deriving DecidableEq

def closeTable : List LocalNode → List Nat → List Nat
  | [],known => known
  | r::rest,known =>
    closeTable rest (if r.children.all known.contains then r.s::known else known)

def tableRoots (rows : List LocalNode) := (rows.filter (fun r => r.root)).map LocalNode.s

theorem closeTable_sound (P : Nat → Prop) (rows : List LocalNode) (known : List Nat)
    (initial : ∀ s ∈ known, P s)
    (checkedRow : ∀ r ∈ rows, (∀ c ∈ r.children, P c) → P r.s) :
    ∀ s ∈ closeTable rows known, P s := by
  induction rows generalizing known with
  | nil => exact initial
  | cons r rows ih =>
    have rest := fun a ha => checkedRow a (List.mem_cons_of_mem r ha)
    simp only [closeTable]
    by_cases seen : r.children.all known.contains = true
    · simp only [seen,if_true]
      apply ih (r.s::known) _ rest
      intro s mem
      rcases List.mem_cons.mp mem with rfl | hin
      · apply checkedRow r (by simp)
        intro c hc
        exact initial c (List.contains_iff_mem.mp (List.all_eq_true.mp seen c hc))
      · exact initial s hin
    · simp only [show r.children.all known.contains = false from Bool.eq_false_iff.mpr seen, Bool.false_eq_true,if_false]
      exact ih known initial rest

theorem frozenTable_sound (P : Nat → Prop) (rows : List LocalNode)
    (checkedRow : ∀ r ∈ rows, (∀ c ∈ r.children, P c) → P r.s)
    (coverage : (tableRoots rows).all (closeTable rows []).contains = true) :
    ∀ r ∈ tableRoots rows, P r := by
  intro r hr
  exact closeTable_sound P rows [] (by simp) checkedRow r
    (List.contains_iff_mem.mp (List.all_eq_true.mp coverage r hr))

end Research.Graph9822H2Check
