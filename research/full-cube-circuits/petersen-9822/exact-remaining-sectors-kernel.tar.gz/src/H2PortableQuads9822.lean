import H2FastStep9822
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden

def quadGood (q : List Nat) := match q with
  | [a,b,c,d] => decide (a<b ∧ b<c ∧ c<d ∧ d<13) &&
    ((vs.filter (q.foldl (fun m e => m ||| edges[e]!) 0).testBit).length == 8)
  | _ => false

theorem quadGood_mem {q : List Nat} (ok : quadGood q = true) : q ∈ matchings := by
  match q with
  | [a,b,c,d] =>
    obtain ⟨inc,eight⟩ := Bool.and_eq_true_iff.mp ok
    obtain ⟨ab,bc,cd,last⟩ := of_decide_eq_true inc
    unfold matchings
    refine List.mem_flatMap.mpr ⟨a,List.mem_range.mpr (by omega),?_⟩
    refine List.mem_flatMap.mpr ⟨b,List.mem_range.mpr (by omega),?_⟩
    refine List.mem_flatMap.mpr ⟨c,List.mem_range.mpr (by omega),?_⟩
    refine List.mem_flatMap.mpr ⟨d,List.mem_range.mpr last,?_⟩
    have width := beq_iff_eq.mp eight
    simp at width
    simp [ab,bc,cd,width,guard]
  | [] | [_] | [_,_] | [_,_,_] | _::_::_::_::_::_ => simp [quadGood] at ok

set_option maxRecDepth 10000 in
set_option maxHeartbeats 5000000 in
theorem tableWell : quadTable.toList.all quadGood = true := by decide +kernel

theorem portableQuad {code : Nat} {q : List Nat} (found : quadTable[code]? = some q) :
    ∃ n : Nat, matchings[n]? = some q := by
  have mem : q ∈ quadTable.toList := List.mem_iff_getElem?.mpr ⟨code,by simpa using found⟩
  exact List.mem_iff_getElem?.mp (quadGood_mem (List.all_eq_true.mp tableWell q mem))

end Research.Graph9822H2Check
