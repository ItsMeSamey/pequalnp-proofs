import And9822ThreeRoots
import And9822H4Tape
import And9822CollectorShape
namespace Research.Graph9822.H2Trace
open Research.Graph9822.FreeOR Research.Graph9822.Footprint
open Research.Graph9822Resolution Research.Graph9822.FourSaturation
open Research.Graph9822.ReverseChannel (arm dir demand channel placed)
def prod (q a b c : Product) : Nat → Product
  | 0 => a
  | 1 => b
  | 2 => c
  | 3 => q
  | _ => ([],[])
def slot (i : Nat) := 14-i
def env (h q a b c : Product) (m : Fin 1024) (j : Nat) : Bool :=
  let w := run [h,q] 10 (fullWire m.val)
  if j<12 then w j else productBit w (prod q a b c (14-j))
def tr (h q a b c : Product) (m : Fin 1024) :=
  ThreeRoots.row (prod q a b c) slot (dir (env h q a b c m) (prod q a b c)) 4
theorem leaf (h q a b c : Product) (m : Fin 1024) :
    (∀ j<10, env h q a b c m j = fullWire m.val j) ∧
      env h q a b c m 10=productBit (fullWire m.val) h := by
  constructor
  · intro j hj
    simpa only [env,if_pos (show j<12 by omega)] using stale_value [h,q] hj (fullWire m.val)
  · simp [env,run,Function.update]
private theorem read_eq {p : Product} {u v : Wire} (bd : Below 12 p)
    (same : ∀ j<12,u j=v j) : productBit u p=productBit v p := by
  unfold productBit
  rw [read_below (fun j hj => same j (bd.1 j hj)),read_below (fun j hj => same j (bd.2 j hj))]
theorem cubes (C : FiveProgram) (h q a b c : Product)
    (hh : (hiddenFirst C).1=[h,q]) (ht : (hiddenFirst C).2=[a,b,c]) :
    let p := prod q a b c
    let v := env h q a b c
    let masks := tr h q a b c
    (Finset.univ.image masks).card ≤ 15 ∧
    (∀ m, accepts m.val=false → ∀ j, j<11 → demand p (masks m) j → v m j=false) ∧
    (∀ m z, (∀ j, j<11 → demand p (masks m) j → v z j=false) → accepts z.val=false) := by
  obtain ⟨order,hs,ts⟩ := hidden_first_shape C
  rw [hh] at order hs ts
  rw [ht] at ts
  have qa := hs q (by simp)
  have aa := ts a (by simp)
  have ba := ts b (by simp)
  have ca := ts c (by simp)
  let p := prod q a b c
  let v := env h q a b c
  have qb : Below 11 q := ⟨order.2.2.1,order.2.2.2.1⟩
  have qwide : Below 12 q := ⟨fun j m => Nat.lt_succ_of_lt (qb.1 j m),fun j m => Nat.lt_succ_of_lt (qb.2 j m)⟩
  have bd (i : Nat) (lt : i<4) : Below 12 (p i) := by
    interval_cases i <;> first | exact aa.2 | exact ba.2 | exact ca.2 | exact qwide
  have eqv (m : Fin 1024) (i : Nat) (lt : i<4) :
      productBit (v m) (p i)=productBit (run [h,q] 10 (fullWire m.val)) (p i) :=
    read_eq (bd i lt) (fun j hj => by simp [v,env,hj])
  have ev (m : Fin 1024) (i : Nat) (lt : i<4) : v m (slot i)=productBit (v m) (p i) := by
    rw [eqv m i lt]
    interval_cases i
    · rfl
    · rfl
    · rfl
    · exact placed [h,q] 10 (fullWire _) (i:=1) order rfl
  have sep (i : Nat) : Apart (p i) := by
    by_cases lt : i<4
    · interval_cases i <;> first | exact aa.1 | exact ba.1 | exact ca.1 | exact qa
    · obtain ⟨k,rfl⟩ := Nat.exists_eq_add_of_le (by omega : 4 ≤ i)
      simp [p,prod,Nat.add_comm,Apart]
  have scope (i : Nat) (lt : i<4) (b' : Bool) (j : Nat) (read : j ∈ arm (p i) b') :
      j<11 ∨ ∃ k, i<k ∧ k<4 ∧ j=slot k := by
    have all : j<12 := by cases b' <;> first | exact (bd i lt).1 j read | exact (bd i lt).2 j read
    by_cases small : j<11
    · exact Or.inl small
    · have neq : i≠3 := by
        rintro rfl
        cases b' <;> first | exact small (qb.1 j read) | exact small (qb.2 j read)
      exact Or.inr ⟨3,by omega,by decide,by unfold slot; omega⟩
  have out (m : Fin 1024) : (v m 14 || v m 13 || v m 12)=accepts m.val := by
    have x := hidden_first_correct C m
    rw [hh,ht] at x
    simpa [v,env,prod,Bool.or_assoc] using x
  constructor
  · apply le_trans _ (four_three (channel p (slot 3)))
    apply Finset.card_le_card
    intro r hr
    obtain ⟨m,_,rfl⟩ := Finset.mem_image.mp hr
    exact ThreeRoots.row_four_mem _ _ _
  constructor
  · rintro m cold j _ ⟨t,mt,jt⟩
    have off := (out m).trans cold
    have roots (i : Nat) (lt : i<3) (_ : i<4) : v m (slot i)=false := by
      simp only [Bool.or_eq_false_iff] at off
      interval_cases i <;> first | exact off.1.1 | exact off.1.2 | exact off.2
    exact ThreeRoots.all_false p slot (v m) 4 sep (ev m) roots t mt j jt
  · intro m z blocked
    have atRoot := ThreeRoots.replay p slot (dir (v m) p) (v z) 4 (by decide)
      (fun j=> j<11) sep (ev z) scope (fun t mt j read jl => blocked j jl ⟨t,mt,read⟩)
    rw [←out z]
    have x : v z 14 = false := atRoot 0 (by decide) (by decide)
    have y : v z 13 = false := atRoot 1 (by decide) (by decide)
    have u : v z 12 = false := atRoot 2 (by decide) (by decide)
    simp [x,y,u]
end Research.Graph9822.H2Trace
