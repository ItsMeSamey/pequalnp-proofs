import And9822H3PairRequest
namespace Research.Graph9822.H3Directions
open Research.Graph9822H2Check Research.Graph9822DemandThree Research.Graph9822FirstAdmission
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun

private def reqs (h : Nat) (xs : List Nat) := do
  let i ← xs
  let j ← xs
  guard (i<j)
  return pairRequest h i j

private theorem pair_mem (h : Nat) (xs : List Nat) {i j : Nat}
    (a : i∈xs) (b : j∈xs) (lt : i<j) : pairRequest h i j∈reqs h xs := by
  simp only [reqs,List.bind_eq_flatMap,List.mem_flatMap]
  exact ⟨i,a,j,b,by simp [lt]⟩

private theorem split_req {h hint : Nat} {ds : List Nat} (ok : requests h hint=some ds) :
    let xs := (List.range 16).filter hint.testBit
    xs.length=8 ∧ ds=reqs h xs ∧ ∀ r∈ds,positive r≠0 := by
  let xs := (List.range 16).filter hint.testBit
  change (do guard (xs.length==8); let rs := reqs h xs; guard (rs.all (fun r => positive r != 0)); pure rs : Option _) = some ds at ok
  by_cases len : xs.length=8
  · by_cases yes : (reqs h xs).all (fun r => positive r != 0)=true
    · have eq : reqs h xs=ds := by simpa [len,yes] using ok
      exact ⟨len,eq.symm,fun r mem => bne_iff_ne.mp (List.all_eq_true.mp yes r (eq.symm ▸ mem))⟩
    · exfalso
      simp [len,yes] at ok
  · exfalso
    simp [len] at ok

theorem all_request (h q : Nat) (slot : Fin 16 → Fin 7)
    (physical : ∀ i j : Fin 16, slot i=slot j → needPos h i j≠0 → holds q (pairRequest h i.val j.val))
    {hint : Nat} {ds : List Nat} (ok : requests h hint=some ds) :
    ∃ r∈ds, holds q r := by
  let xs := (List.range 16).filter hint.testBit
  obtain ⟨len,eq,cost⟩ := split_req ok
  change xs.length=8 at len
  let idx (k : Fin 8) : Fin xs.length := ⟨k.val,by rw [len]; exact k.isLt⟩
  have member (k : Fin 8) : xs.get (idx k)∈xs := List.get_mem _ _
  let row (k : Fin 8) : Fin 16 := ⟨xs.get (idx k),List.mem_range.mp (List.mem_filter.mp (member k)).1⟩
  obtain ⟨i,j,ij,same⟩ := eight_collide (fun k => slot (row k))
  have nd : xs.Nodup := (List.nodup_range).filter _
  have ne : row i ≠ row j := by
    intro equal
    have g : xs.get (idx i)=xs.get (idx j) := congrArg Fin.val equal
    apply (Nat.ne_of_lt ij)
    exact (List.Nodup.getElem_inj_iff nd (hi:=(idx i).isLt) (hj:=(idx j).isLt)).mp g
  have select (u v : Fin 8) (lt : row u<row v) (same : slot (row u)=slot (row v)) :
      ∃ r∈ds,holds q r := by
    have mem : pairRequest h (row u).val (row v).val ∈ ds := by
      rw [eq]
      exact pair_mem h xs (member u) (member v) lt
    exact ⟨_,mem,physical _ _ same (nonempty_need (cost _ mem))⟩
  rcases lt_or_gt_of_ne ne with a|b
  · exact select i j a same
  · exact select j i b same.symm
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.all_request
