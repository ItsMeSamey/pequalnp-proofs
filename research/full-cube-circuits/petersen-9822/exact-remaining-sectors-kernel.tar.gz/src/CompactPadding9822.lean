import CompactIndexed9822

namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean PEqualNP.Outside.L_meta_9822.Sectors

/-- At a signed AND/OR output, recombining the output with an existing signed
    input of that gate preserves the output truth table. -/
def repeatSite (last : Nat) (g : Site) : Site :=
  ⟨g.isOr,⟨last,g.outNeg⟩,g.left,g.outNeg⟩

theorem repeat_op (last : Nat) (g : Site) (a b : Bool) :
    (repeatSite last g).op (g.op a b) a = g.op a b := by
  cases g with
  | mk k l r z =>
    cases l with
    | mk li ln =>
      cases r with
      | mk ri rn =>
        cases k <;> cases ln <;> cases rn <;> cases z <;> cases a <;> cases b <;> rfl

private theorem keep_edge {n k} (net : Net n k) (s : Site) (hl hr) {a b}
    (e : net.Edge a b) : (net.snoc s hl hr).Edge a b := by
  obtain ⟨v,hv,h⟩ := e
  have before := (net.get_spec hv).2.1
  exact ⟨v,by simpa [Net.get,Nat.ne_of_lt before] using hv,h⟩

private theorem keep_route {n k} (net : Net n k) (s : Site) (hl hr) {a b}
    (r : Route net a b) : Route (net.snoc s hl hr) a b := by
  induction r with
  | done => exact .done _
  | step e _ ih => exact .step (keep_edge net s hl hr e) ih

private theorem Route.append {n k} {net : Net n k} {a b c}
    (p : Route net a b) (q : Route net b c) : Route net a c := by
  induction p with
  | done => exact q
  | step e _ ih => exact .step e (ih q)

theorem padOne {n k f} (net : Net n k) (h : SignedDag net f) (pos : 0 < k) :
    ∃ result : Net n (k+1), SignedDag result f := by
  let last := n+k-1
  have hl : last < n+k := by dsimp [last]; omega
  obtain ⟨g,hg⟩ := net.present (w := last) (by dsimp [last]; omega) hl
  have back := (net.get_spec hg).2.2.1
  let s := repeatSite last g
  have sa : s.left.wire < n+k := hl
  have sb : s.right.wire < n+k := back.trans hl
  let next := net.snoc s sa sb
  have out : n+(k+1)-1 = n+k := by omega
  have endEdge : next.Edge last (n+k) := ⟨s,by simp [next,Net.get],Or.inl rfl⟩
  refine ⟨next,?_,?_,?_⟩
  · intro w v hv
    by_cases eq : w = n+k
    · subst w; simp [next,Net.get] at hv
      subst v; exact Ne.symm (Nat.ne_of_lt back)
    · exact h.proper w v (by simpa [next,Net.get,eq] using hv)
  · intro w v hv
    rw [out]
    by_cases eq : w = n+k
    · subst w; exact .done _
    · have old : net.get w = some v := by simpa [next,Net.get,eq] using hv
      exact (keep_route net s sa sb (h.live w v old)).append (.step endEdge (.done _))
  · intro x
    rw [out]
    change (net.snoc s sa sb).eval (inputEnv x) (n+k) = _
    rw [Net.eval,if_pos rfl]
    change (repeatSite last g).op (net.eval (inputEnv x) last) (net.eval (inputEnv x) g.left.wire) = f x
    rw [net.eval_gate _ hg,repeat_op,← net.eval_gate _ hg]
    exact h.computes x

theorem padTo {n k f} (net : Net n k) (h : SignedDag net f) (pos : 0 < k) (m : Nat) (hm : k ≤ m) :
    ∃ result : Net n m, SignedDag result f := by
  induction m,hm using Nat.le_induction with
  | base => exact ⟨net,h⟩
  | succ t ht ih =>
    obtain ⟨pre,hp⟩ := ih
    exact padOne pre hp (by omega)

theorem hasBinary {gs o} (hr : Reduced 10 gs o) (ev : ∀ x, vl gs x o = edge x) : 0 < gs.countP bin := by
  by_contra! zero
  have eq : gs.countP bin = 0 := by omega
  have core := compactOfReduced hr (outputGate ev).2
  rw [eq] at core
  obtain ⟨net,ref,_,bound,represented⟩ := core
  cases net
  let r := ref o
  have valid : r.wire < 10 := by simpa [r] using bound
  let i : Fin 10 := ⟨r.wire,valid⟩
  have cert (x : Fin 10 → Bool) :
      (if r.neg then !(x i) else x i) = edge x := by
    have hx := (represented x).trans (ev x)
    change (if r.neg then !(inputEnv x r.wire) else inputEnv x r.wire) = edge x at hx
    have atRaw : inputEnv x r.wire = x i := Clean.getD_ofFn 10 x false i
    rwa [atRaw] at hx
  cases sign : r.neg with
  | true =>
    have bad := cert (fun _ => false)
    simp [sign,edge] at bad
  | false =>
    let x : Fin 10 → Bool := fun v => v == i
    have no : edge x = false := (show ∀ j : Fin 10, edge (fun v => v == j) = false by decide +kernel) i
    have bad := cert x
    simp [x,sign,no] at bad

/-- The padded core supports consumers whose hypotheses are exactly its signed
    paths and operations. Its newly appended sites may be semantic aliases. -/
theorem coreWithoutFloor {gs o} (hr : Reduced 10 gs o) (ev : ∀ x, vl gs x o = edge x)
    (size : gs.length ≤ 17) (many : 2 ≤ gs.countP countsNot) :
    ∃ d : Petersen9822.DagCut.Indexed, Nonempty (Petersen9822.DagCut.FifteenCore d 24) := by
  have pred : (fun g => decide (¬ countsNot g = true)) = bin := by
    funext g
    cases g with
    | mk op ins => cases op <;> rfl
  have split := List.length_eq_countP_add_countP (l := gs) countsNot
  rw [pred] at split
  have pos := hasBinary hr ev
  obtain ⟨net,h⟩ := signedDagOf hr (outputGate ev).2 pos
  rw [show (fun x => vl gs x o) = edge from funext ev] at h
  obtain ⟨padded,ok⟩ := padTo net h pos 15 (by omega)
  exact ⟨padded.indexed,coreOfNet padded ok⟩

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.coreWithoutFloor
