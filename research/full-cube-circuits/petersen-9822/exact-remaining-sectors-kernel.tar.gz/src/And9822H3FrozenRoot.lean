import H3FirstBroadEndpoint9822
import And9822H3Unused
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822FirstAdmission

theorem frozen_root (c : MaximumFive) (H Q R A B : Product)
    (hh : (hiddenFirst c.toFiveProgram).1=[H,Q,R]) (ht : (hiddenFirst c.toFiveProgram).2=[A,B]) :
    ∃ i : Nat, roots[i]?=some (encode (firstCol H)) := by
  obtain ⟨_,ha,ta⟩ := hidden_first_shape c.toFiveProgram
  obtain ⟨d,skip⟩ := unused_slot R A B (ha R (by simp [hh])) (ta A (by simp [ht])).1 (ta B (by simp [ht])).1
  have admit := original_admitted c.toFiveProgram H Q R A B hh ht d skip
  have hid := original_hidden c H [Q,R] hh
  rw [first_code] at admit hid ⊢
  exact Graph9822FirstBroad.admitted_reaches ⟨armMask H.1,armMask_lt H.1⟩ ⟨armMask H.2,armMask_lt H.2⟩
    (disjoint_arm_masks H.1 H.2 (ha H (by simp [hh]))) hid admit
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.frozen_root
