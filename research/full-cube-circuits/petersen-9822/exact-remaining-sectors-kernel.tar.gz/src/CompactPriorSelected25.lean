import CompactPriorSelected25Cell06
-- CompactPriorFace61
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_107 : CutRow book 8 107 7 := (joinRow (joinRow row8_107_seg107 row8_107_seg110) row8_107_seg113)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace62
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem combine8_0_16 : CutRow book 8 0 16 := @joinRow book 8 0 4 12 row8_0 row8_4
theorem combine8_16_24 : CutRow book 8 16 24 := @joinRow book 8 16 12 12 row8_16 row8_28
theorem combine8_40_24 : CutRow book 8 40 24 := @joinRow book 8 40 12 12 row8_40 row8_52
theorem combine8_64_19 : CutRow book 8 64 19 := @joinRow book 8 64 7 12 row8_64 row8_71
theorem combine8_83_24 : CutRow book 8 83 24 := @joinRow book 8 83 12 12 row8_83 row8_95
theorem combine8_0_40 : CutRow book 8 0 40 := @joinRow book 8 0 16 24 combine8_0_16 combine8_16_24
theorem combine8_40_43 : CutRow book 8 40 43 := @joinRow book 8 40 24 19 combine8_40_24 combine8_64_19
theorem combine8_83_31 : CutRow book 8 83 31 := @joinRow book 8 83 24 7 combine8_83_24 row8_107
theorem combine8_0_83 : CutRow book 8 0 83 := @joinRow book 8 0 40 43 combine8_0_40 combine8_40_43
theorem combine8_0_114 : CutRow book 8 0 114 := @joinRow book 8 0 83 31 combine8_0_83 combine8_83_31
theorem band8 : CutRow book 8 0 114 := combine8_0_114
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace63
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_0 : CutRow book 7 0 12 := (joinRow (joinRow (joinRow row7_0_seg0 row7_0_seg3) row7_0_seg6) row7_0_seg9)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
