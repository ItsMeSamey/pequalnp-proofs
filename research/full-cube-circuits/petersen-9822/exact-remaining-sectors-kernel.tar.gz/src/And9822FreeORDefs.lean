import Resolution
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
abbrev Arm := List Nat
abbrev Product := Arm × Arm
abbrev Env := Nat → Arm
def readArm (w : Wire) (a : Arm) := a.any w
def productBit (w : Wire) (p : Product) := readArm w p.1 && readArm w p.2
def run : List Product → Nat → Wire → Wire
  | [],_,w => w
  | p::ps,k,w => run ps (k+1) (Function.update w k (productBit w p))
def flatten : List Gate → Nat → Nat → Env → Nat → List Product × Arm
  | [],_,_,env,out => ([],env out)
  | g::gs,i,k,env,out =>
    let a := env g.left
    let b := env g.right
    if g.isAnd then
      let q := flatten gs (i+1) (k+1) (Function.update env i [k]) out
      ((a,b)::q.1,q.2)
    else flatten gs (i+1) k (Function.update env i (a++b)) out
def Bounded (k : Nat) (env : Env) := ∀ j, ∀ t ∈ env j, t < k
def Chronological : Nat → List Product → Arm → Prop
  | k,[],out => ∀ t ∈ out,t<k
  | k,p::ps,out => (∀ t ∈ p.1,t<k) ∧ (∀ t ∈ p.2,t<k) ∧ Chronological (k+1) ps out
end Research.Graph9822.FreeOR
