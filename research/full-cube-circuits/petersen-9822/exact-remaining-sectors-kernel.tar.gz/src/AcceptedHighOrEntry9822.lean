import HighHotIsGuard9822
import DynamicMaskedRaw9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination Deletion PEqualNP.Outside.L_meta_9822.Clean
theorem accepted_high_or_entry {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    ∃q∈post,q.op=.or ∧ 10+pre.length∈q.inputs := by
  classical
  by_contra! no
  let z := 10+pre.length
  let row := SignedClamp.singleton s
  let w := wiresFrom pre (List.ofFn row)
  have len : w.length=z := by simp [w,z,length_wiresFrom]
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have hrow := hot_guard cut s upper
  have actual (x : Input) (i : Nat) : vl C.gates x i=outerValue pre post i x (!(innerValue pre g x)) := by
    unfold vl outerValue
    rw [r.split,wiresFrom_append]
    change (wiresFrom post (wiresFrom pre (List.ofFn x)++[g.op.eval _])).getD i false=_
    rw [r.inv];rfl
  have zv (x : Input) : vl C.gates x z=(!(innerValue pre g x)) := by
    rw [actual]
    let v := wiresFrom pre (List.ofFn x)
    have sz : v.length=z := by simp [v,z,length_wiresFrom]
    change (wiresFrom post (v++[_])).getD z false=_
    rw [←sz,getD_wiresFrom _ _ _ (by simp),getD_snoc_eq]
  have oz : C.output≠z := by
    intro eq
    have off : vl C.gates (fun _=>false : Input) C.output=false := (cand.2.2 _).trans (by decide)
    rw [eq,zv,cold_empty r cand seven] at off
    contradiction
  have block (q : Gate) (mem : q∈post) (pin : z∈q.inputs) : q.op=.and ∧
      ∃b∈q.inputs,b≠z ∧ (wiresFrom post (w++[false])).getD b false=false := by
    have kind : q.op=.and := (r.pos q (List.mem_append_right _ mem)).resolve_right (fun o => no q mem o pin)
    obtain ⟨i,si⟩ := List.mem_iff_getElem?.mp mem
    have site : C.gates[pre.length+(i+1)]?=some q := by rw [r.split];simpa [List.getElem?_append] using si
    rcases red.clean _ q site with ⟨bad,_⟩|⟨_,a,b,_,_,ins⟩
    · simp_all
    have diff := distinct_and_pins red _ q site kind a b ins
    have other : ∃j∈q.inputs,j≠z := by
      simp only [ins,List.mem_cons,List.not_mem_nil,or_false] at pin ⊢
      rcases pin with e|e
      · exact ⟨b,Or.inr rfl,by omega⟩
      · exact ⟨a,Or.inl rfl,by omega⟩
    obtain ⟨j,jm,jd⟩ := other
    refine ⟨kind,j,jm,jd,?_⟩
    by_contra! hot
    have original : vl C.gates row j=true := by
      rw [actual,show innerValue pre g row=true from hrow]
      simpa [outerValue,w] using hot
    have imp := high_hot_implies_guard r cand red seven s sl su upper j original
    apply no_disjoint_product red q site kind j z jd jm pin
    intro x yes
    rw [zv,imp x yes];rfl
  have same := masked_dynamic_raw post (w++[false]) (w++[true]) z block (by simp)
    (fun i ne => by rw [getD_snoc_ne _ _ _ _ (by omega),getD_snoc_ne _ _ _ _ (by omega)]) C.output oz
  have low := cut.computes row
  rw [show innerValue pre g row=true from hrow] at low
  exact Bool.noConfusion (((low.trans (singleton_zero s)).symm).trans (same.trans upper))
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.accepted_high_or_entry
