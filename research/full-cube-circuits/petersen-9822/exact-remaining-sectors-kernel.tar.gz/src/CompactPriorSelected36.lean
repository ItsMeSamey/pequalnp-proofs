import CompactPriorSelected36Cell01
-- CompactPriorFace94
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
set_option maxRecDepth 16000 in
theorem row13_0 : CutRow book 13 0 1 := bandCut 9 false (by decide +kernel)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace95
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem band13 : CutRow book 13 0 1 := row13_0
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace96
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem row12_0 : CutRow book 12 0 4 := (joinRow row12_0_seg0 row12_0_seg3)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
