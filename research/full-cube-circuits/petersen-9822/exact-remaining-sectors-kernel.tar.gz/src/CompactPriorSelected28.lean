import CompactPriorSelected28Cell11
-- CompactPriorFace70
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_76 : CutRow book 7 76 12 := (joinRow (joinRow (joinRow row7_76_seg76 row7_76_seg79) row7_76_seg82) row7_76_seg85)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace71
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_88 : CutRow book 7 88 12 := (joinRow (joinRow (joinRow row7_88_seg88 row7_88_seg91) row7_88_seg94) row7_88_seg97)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace72
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_100 : CutRow book 7 100 12 := (joinRow (joinRow (joinRow row7_100_seg100 row7_100_seg103) row7_100_seg106) row7_100_seg109)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
