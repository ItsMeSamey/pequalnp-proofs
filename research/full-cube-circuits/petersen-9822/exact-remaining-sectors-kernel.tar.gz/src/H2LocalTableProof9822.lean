import H2LocalDag9822
import H2FixedWitness9822
namespace Research.Graph9822H2Check

def validNode (h : Nat) (bad : Nat → Bool) (quadAt : Nat → Option (List Nat)) (r : LocalNode) :=
  if r.code == 255 then negative r.s == 65535
  else (quadAt r.code).any (fun quad => coversChildren h r.s quad r.children bad)

theorem fixedTable {h q : Nat} {bad : Nat → Bool} {quadAt : Nat → Option (List Nat)}
    (rows : List LocalNode) (leak : ∃ n : Fin 16, (negative q).testBit n = true)
    (reject : ∀ s, bad s = true → ¬holds q s)
    (resolve : ∀ (k : Nat) (quad : List Nat), quadAt k = some quad →
      ∃ i ∈ quad, ∃ j ∈ quad, i < j ∧ ∃ r ∈ rescue h i j, holds q r)
    (checks : rows.all (validNode h bad quadAt) = true)
    (complete : (tableRoots rows).all (closeTable rows []).contains = true) :
    ∀ s ∈ tableRoots rows, ¬holds q s := by
  refine frozenTable_sound (fun s => ¬holds q s) rows ?_ complete
  intro r mem children live
  have ok := List.all_eq_true.mp checks r mem
  by_cases endCode : r.code = 255
  · have allCold : negative r.s = 65535 := by simpa [validNode,endCode] using ok
    exact liveStateLeaks live leak allCold
  · cases found : quadAt r.code with
    | none => simp [validNode,endCode,found] at ok
    | some quad =>
      have check : coversChildren h r.s quad r.children bad = true := by
        simpa [validNode,endCode,found] using ok
      obtain ⟨c,hc,sat⟩ := local_rescue check reject (resolve r.code quad found) live
      exact children c hc sat
end Research.Graph9822H2Check
