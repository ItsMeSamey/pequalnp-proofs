import H2CanonicalPairs9822
namespace Research.Graph9822H2Check
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem dom0_2 : pairDom 0 2 = true := by decide +kernel
end Research.Graph9822H2Check
