import And9822H3PackedDirections
import H3TailGroups9822
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822DemandThree Research.H3TailGroups

theorem bit_source (H Q : Product) (r : Fin 29) (f : Fin 10 ⊕ Bool) :
    (signature (encode (firstCol H)) (encode (secondCol H Q)) r.val (rawRow r)).testBit (source f)=true ↔
    feathot H Q r f := by
  have low (v : Fin 10) : (source (.inl v))<10 := v.isLt
  have off (k : Nat) (ge : 10≤k) : (rawRow r).testBit k=false :=
    Nat.testBit_lt_two_pow (lt_of_lt_of_le (raw_row_small r)
      (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) ge))
  have hb (v : Nat) : ((v >>> r.val) &&& 1).testBit 0 = v.testBit r.val := by
    simp [Nat.testBit_and,Nat.testBit_shiftRight]
  have hh (x : Nat) : (x%2).testBit 1=false := Nat.testBit_lt_two_pow (Nat.mod_lt _ (by decide : 0<2))
  cases f with
  | inl v =>
    have lo := v.isLt
    simp [source,signature,feathot,fires,Nat.testBit_or,Nat.testBit_shiftLeft,
      show ¬v.val≥10 by omega,show ¬v.val≥11 by omega]
  | inr b =>
    cases b <;> simp [source,signature,feathot,fires,Nat.testBit_or,Nat.testBit_shiftLeft,
      Nat.testBit_and,Nat.testBit_shiftRight,off,encode_bit,hb,hh]
theorem source_range (j : Nat) (lt : j<12) : ∃ f,source f=j := by
  by_cases raw : j<10
  · exact ⟨.inl ⟨j,raw⟩,rfl⟩
  · rcases (show j=10 ∨ j=11 by omega) with rfl|rfl
    · exact ⟨.inr false,rfl⟩
    · exact ⟨.inr true,rfl⟩
theorem source_lt (f : Fin 10 ⊕ Bool) : source f<12 := by
  cases f with
  | inl v => change v.val<12; omega
  | inr b => cases b <;> decide
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.bit_source
