import And9822H4Pairs00
import And9822H4Pairs01
import And9822H4Pairs02
import And9822H4Pairs03
import And9822H4Pairs04
import And9822H4Pairs05
import And9822H4Pairs06
import And9822H4Pairs07
import And9822H4Pairs08
import And9822H4Pairs09
namespace Research.Graph9822.H4Geo
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
def indexP (q : Fin 10) (r : Fin 12) : Fin 120 := ⟨q.val*12+r.val,by omega⟩
theorem allStatic (p : Fin 120) : static_pairP p := by
  have all : ∀ q r,static_pairP (indexP q r) := Fin.cases pairs0 (Fin.cases pairs1 (Fin.cases pairs2 (Fin.cases pairs3 (Fin.cases pairs4 (Fin.cases pairs5 (Fin.cases pairs6 (Fin.cases pairs7 (Fin.cases pairs8 (Fin.cases pairs9 (fun h=>Fin.elim0 h))))))))))
  let q : Fin 10 := ⟨p.val/12,by omega⟩
  let r : Fin 12 := ⟨p.val%12,by omega⟩
  have e : indexP q r=p := Fin.ext (by dsimp [indexP,q,r]; omega)
  exact e ▸ all q r
end Research.Graph9822.H4Geo
