import CompactPriorSelected08
-- CompactPriorFace13
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B189_8
set_option maxRecDepth 16000 in
theorem row5_0 : CutRow book 5 0 1 := bandCut 6 false (by decide +kernel)
end B189_8
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace14
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B189_8
theorem band5 : CutRow book 5 0 1 := row5_0
theorem checked : mixedTables book 7 := by
  intro k hk
  interval_cases k
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact band5
  · exact band6
  · exact band7
end B189_8
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace15
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h189_8 : Face true 189 8 :=
  mixedLower (g:=B189_8.book) (i:=0) (hints:=536879876)
    (before_sound B189_8.entries B189_8.prior) B189_8.geometry B189_8.checked
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
theorem h198_4 : Face true 198 4 := carry_of (swaps:=[114,96,82,50,64,16]) (by decide +kernel) h29_4
theorem h231_7 : Face true 231 7 := carry_of (swaps:=[83,82,114,99,66,16]) (by decide +kernel) h63_7
theorem h183_7 : Face true 183 7 := carry_of (swaps:=[115,84,99]) (by decide +kernel) h63_7

end PEqualNP.Outside.L_meta_9825.Engine
