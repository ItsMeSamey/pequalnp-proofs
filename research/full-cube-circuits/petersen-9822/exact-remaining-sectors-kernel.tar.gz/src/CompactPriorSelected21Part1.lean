import CompactPriorSelected21Part0
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem band9 : CutRow book 9 0 12 := row9_0
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
