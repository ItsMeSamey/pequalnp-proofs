import H2SymbolicCases9822
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden

def universalLabels (i : Nat) := vs.filter (fun v => edges[i]!.testBit v) ++ [10,11]

private theorem labelUniversal {h i a : Nat} (mem : a ∈ labels h i) :
    a ∈ universalLabels i ∧ (a=10 → (positive h).testBit i=true) := by
  by_cases pos : (positive h).testBit i = true
  · simp [labels,universalLabels,pos] at mem ⊢
    aesop
  · have raw : 10 ∉ vs.filter (fun v => edges[i]!.testBit v) := by simp [vs]
    simp [labels,pos] at mem
    constructor
    · simp [universalLabels]; aesop
    · intro eq
      subst a
      simp [vs] at mem

def labelMask (tag i j a b c d : Nat) :=
  (if a == tag || c == tag then bit i else 0) |||
  (if b == tag || d == tag then bit j else 0)

def symbolicSource (i j a b c d : Nat) : Option SymPattern := do
  let p ← symbolicCells [(a,c),(a,d),(b,c),(b,d)]
  return ⟨labelMask 10 i j a b c d,p.hf,labelMask 11 i j a b c d,p.qf,p.shared⟩

def universalPatterns (i j : Nat) : List SymPattern := do
  let a ← universalLabels i
  let b ← universalLabels j
  let c ← universalLabels i
  let d ← universalLabels j
  (symbolicSource i j a b c d).toList

private theorem positiveLabels {h i j a b c d : Nat}
    (aOn : a=10 → (positive h).testBit i=true) (bOn : b=10 → (positive h).testBit j=true)
    (cOn : c=10 → (positive h).testBit i=true) (dOn : d=10 → (positive h).testBit j=true) :
    sub (labelMask 10 i j a b c d) (positive h)=true := by
  apply (subset_bits ..).2
  intro k hot
  simp only [labelMask,Nat.testBit_or,Bool.or_eq_true] at hot
  rcases hot with left | right
  · split at left
    next cond =>
      have eq : i=k := by simpa [bit,Nat.testBit_two_pow] using left
      subst k
      rcases cond with ac | cc
      · exact aOn (beq_iff_eq.mp ac)
      · exact cOn (beq_iff_eq.mp cc)
    next => simp at left
  · split at right
    next cond =>
      have eq : j=k := by simpa [bit,Nat.testBit_two_pow] using right
      subst k
      rcases cond with bc | dc
      · exact bOn (beq_iff_eq.mp bc)
      · exact dOn (beq_iff_eq.mp dc)
    next => simp at right

theorem sourceProjects {h i j a b c d r : Nat}
    (aOn : a=10 → (positive h).testBit i=true) (bOn : b=10 → (positive h).testBit j=true)
    (cOn : c=10 → (positive h).testBit i=true) (dOn : d=10 → (positive h).testBit j=true)
    (actual : cachedPairDemand h i j a b c d = some r) :
    ∃ p, symbolicSource i j a b c d = some p ∧ p.project h = some r := by
  let pairs := [(a,c),(a,d),(b,c),(b,d)]
  by_cases ok : pairs.all (fun (u,v) => cellSafe h u v) = true
  · obtain ⟨p,out,clear,read⟩ := symbolicCells_cover h pairs ok
    change (do
      guard (pairs.all (fun (u,v) => cellSafe h u v))
      return demand (labelMask 11 i j a b c d) (pairs.foldl (fun f (u,v) => f ||| cellForbid h u v) 0)) = some r at actual
    simp [ok] at actual
    have out' : symbolicCells [(a,c),(a,d),(b,c),(b,d)] = some p := out
    refine ⟨⟨labelMask 10 i j a b c d,p.hf,labelMask 11 i j a b c d,p.qf,p.shared⟩,
      by simp [symbolicSource,out'],?_⟩
    have hp := positiveLabels aOn bOn cOn dOn
    simp [SymPattern.project,hp,clear]
    exact (congrArg (demand (labelMask 11 i j a b c d)) read).trans actual
  · change (do
      guard (pairs.all (fun (u,v) => cellSafe h u v))
      return demand (labelMask 11 i j a b c d) (pairs.foldl (fun f (u,v) => f ||| cellForbid h u v) 0)) = some r at actual
    simp [Bool.eq_false_iff.mpr ok] at actual

theorem rescueProjects {h i j r : Nat} (mem : r∈rescue h i j) :
    ∃ p∈universalPatterns i j, p.project h=some r := by
  have src := allRescues_contains mem
  simp only [allRescues,List.bind_eq_flatMap,List.mem_flatMap] at src
  obtain ⟨a,ha,b,hb,c,hc,d,hd,hit⟩ := src
  cases res : cachedPairDemand h i j a b c d with
  | none => simp [res] at hit
  | some n =>
    have eq : r=n := by simpa [res] using hit
    subst n
    obtain ⟨ua,pa⟩ := labelUniversal ha
    obtain ⟨ub,pb⟩ := labelUniversal hb
    obtain ⟨uc,pc⟩ := labelUniversal hc
    obtain ⟨ud,pd⟩ := labelUniversal hd
    obtain ⟨p,one,proj⟩ := sourceProjects pa pb pc pd res
    refine ⟨p,?_,proj⟩
    simp only [universalPatterns,List.bind_eq_flatMap,List.mem_flatMap]
    exact ⟨a,ua,b,ub,c,uc,d,ud,by simp [one]⟩

theorem canonicalPair_carries {h i j q r : Nat} {cs : List SymPattern}
    (dominates : ∀ p∈universalPatterns i j, ∃ c∈cs, c.below p=true)
    (mem : r ∈ rescue h i j) (live : holds q r) : ∃ w∈projectedBasis h cs, holds q w := by
  obtain ⟨p,source,read⟩ := rescueProjects mem
  exact projectedDominance (dominates p source) read live

end Research.Graph9822H2Check
