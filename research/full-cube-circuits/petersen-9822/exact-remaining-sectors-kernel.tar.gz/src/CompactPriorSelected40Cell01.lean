import CompactPriorSelected40Cell00
namespace PEqualNP.Outside.L_meta_9825.Engine.B767_14
set_option maxRecDepth 16000 in
theorem row10_34_seg37 : CutRow book 10 37 3 := bandCut 11 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B767_14
