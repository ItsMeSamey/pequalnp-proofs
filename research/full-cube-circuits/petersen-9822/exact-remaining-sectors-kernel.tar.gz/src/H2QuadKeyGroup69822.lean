import H2QuadPairList9822
import H2ShortDomTransport9822
import H2ShortDom05119822
import H2ShortDom05129822
import H2ShortDom06079822
import H2ShortDom06089822
import H2ShortDom06099822
import H2ShortDom06109822
import H2ShortDom07089822
namespace Research.Graph9822H2Check
def keys6 : List (Nat × Nat) := [(5,11), (5,12), (6,7), (6,8), (6,9), (6,10), (7,8)]
theorem paidKeys6 : keys6.all (fun p => pairDom p.1 p.2)=true := by
  simp only [keys6,List.all_cons,List.all_nil,Bool.and_eq_true_iff]
  exact ⟨dom_of_short (by decide) short_dom_5_11, dom_of_short (by decide) short_dom_5_12, dom_of_short (by decide) short_dom_6_7, dom_of_short (by decide) short_dom_6_8, dom_of_short (by decide) short_dom_6_9, dom_of_short (by decide) short_dom_6_10, dom_of_short (by decide) short_dom_7_8, True.intro⟩
end Research.Graph9822H2Check
