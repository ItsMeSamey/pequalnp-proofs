import And9822CollectorPlanSound
import And9822CollectorOutput
import OR9822FeatureRun
import OR9822FiveMinimum
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822.FourSaturation
def rawMap : Rename := fun i => if i < 10 then some i else none
def hiddenFirst (c : FiveProgram) := compileSlots (exposed c) c.products 10 10 rawMap
theorem counted (ex : Nat → Bool) (ps : List Product) (k n) (f : Rename) :
    let plan := compileSlots ex ps k n f
    plan.1.length+plan.2.length=ps.length ∧
      plan.2.length=((List.range' k ps.length).filter ex).length := by
  induction ps generalizing k n f with
  | nil => simp [compileSlots]
  | cons p ps ih =>
    cases e : ex k
    · obtain ⟨total,term⟩ := ih (k+1) (n+1) (Function.update f k (some n))
      simp [compileSlots,e,List.range',term] at *
      omega
    · obtain ⟨total,term⟩ := ih (k+1) n (Function.update f k none)
      simp [compileSlots,e,List.range',term] at *
      omega
theorem hidden_first_sizes (c : FiveProgram) :
    (hiddenFirst c).1.length+(hiddenFirst c).2.length=5 ∧
    (hiddenFirst c).2.length=collectorSize c.out := by
  have h := counted (exposed c) c.products 10 10 rawMap
  change _ ∧ _ = ((List.range' 10 5).filter (exposed c)).length
  simpa only [hiddenFirst,c.count] using h
theorem hidden_first_correct (c : FiveProgram) (m : Fin 1024) :
    (hiddenFirst c).2.any (productBit (run (hiddenFirst c).1 10 (fullWire m.val)))=accepts m.val := by
  have eq : Mirrors (fullWire m.val) (fullWire m.val) rawMap := by
    intro i
    by_cases h : i<10 <;> simp [rawMap,fullWire,h]
  have bd : Routes 10 rawMap := by
    intro i j h
    by_cases lt : i<10 <;> simp [rawMap,lt] at h <;> omega
  have z (j) (h : exposed c j=true) : fullWire m.val j=false :=
    by simp [fullWire,Nat.not_lt_of_ge (out_no_raw c (List.contains_iff_mem.mp h))]
  have a := compile_sound (exposed c) c.products 10 10 rawMap bd _ _ eq false
  have b := stable_partition (exposed c) c.products 10 c.out c.ordered (fullWire m.val) false z
  have same := a.symm.trans b
  simpa [hiddenFirst] using (show _ = accepts m.val from same.trans (by simpa using collected c m))
theorem row_extrema : ∀ i : Fin 29, rawRow i < 1024 ∧
    accepts (rawRow i) = decide (i.val < 13) := by decide
theorem hidden_first_rows (c : FiveProgram) (i : Fin 29) :
    (hiddenFirst c).2.any (productBit (run (hiddenFirst c).1 10 (fullWire (rawRow i)))) =
      decide (i.val<13) :=
  (hidden_first_correct c ⟨rawRow i,(row_extrema i).1⟩).trans (row_extrema i).2
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.hidden_first_rows
