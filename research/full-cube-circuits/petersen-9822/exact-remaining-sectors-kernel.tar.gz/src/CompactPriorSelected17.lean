import CompactPriorSelected16
-- CompactPriorFace37
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B695_10
set_option maxRecDepth 16000 in
theorem row9_0 : CutRow book 9 0 1 := bandCut 7 false (by decide +kernel)
end B695_10
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace38
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B695_10
theorem band9 : CutRow book 9 0 1 := row9_0
end B695_10
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace39
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B695_10
set_option maxRecDepth 16000 in
theorem row8_0 : CutRow book 8 0 8 := bandCut 8 true (by decide +kernel)
end B695_10
end PEqualNP.Outside.L_meta_9825.Engine
