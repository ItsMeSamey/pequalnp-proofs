import And9822CollectorCases
namespace Research.Graph9822.FreeOR
def OneToOne (f : Rename) := ∀ i j v, f i=some v → f j=some v → i=j
def Apart (p : Product) := ∀ v ∈ p.1, v ∉ p.2
def Below (n : Nat) (p : Product) := (∀ j ∈ p.1,j<n) ∧ (∀ j ∈ p.2,j<n)
private theorem copy_below {n f} (bd : Routes n f) (p : Product) : Below n (copyProduct f p) := by
  constructor <;> intro j hj <;> obtain ⟨i,_,hi⟩ := List.mem_filterMap.mp hj <;> exact bd i j hi
private theorem copy_apart {f} (inj : OneToOne f) {p} (a : Apart p) : Apart (copyProduct f p) := by
  intro v hl hr
  obtain ⟨i,li,ei⟩ := List.mem_filterMap.mp hl
  obtain ⟨j,rj,ej⟩ := List.mem_filterMap.mp hr
  exact a i li (inj i j v ei ej ▸ rj)
private theorem inj_next {f n} (bd : Routes n f) (inj : OneToOne f) (k) (b : Bool) :
    OneToOne (Function.update f k (if b then some n else none)) := by
  intro i j v hi hj
  by_cases e : i=k <;> by_cases e' : j=k
  · exact e.trans e'.symm
  · cases b <;> simp [e] at hi
    have := bd j v (by simpa [e'] using hj)
    omega
  · cases b <;> simp [e'] at hj
    have := bd i v (by simpa [e] using hi)
    omega
  · exact inj i j v (by simpa [e] using hi) (by simpa [e'] using hj)

theorem compile_shape (ex : Nat → Bool) (ps : List Product) (k n) (f : Rename)
    (bd : Routes n f) (inj : OneToOne f) (apart : ∀ p ∈ ps, Apart p) :
    let q := compileSlots ex ps k n f
    Chronological n q.1 [] ∧ (∀ p ∈ q.1, Apart p) ∧
      (∀ p ∈ q.2, Apart p ∧ Below (n+q.1.length) p) := by
  induction ps generalizing k n f with
  | nil => simp [compileSlots,Chronological]
  | cons p ps ih =>
    have ap := copy_apart inj (apart p List.mem_cons_self)
    have under := copy_below bd p
    have rest : ∀ t ∈ ps, Apart t := fun t mem => apart t (List.mem_cons_of_mem _ mem)
    cases e : ex k
    · obtain ⟨order,dis,term⟩ := ih (k+1) (n+1) _ (scope_add bd k) (inj_next bd inj k true) rest
      simp only [compileSlots,e,Bool.false_eq_true,ite_false,List.length_cons]
      refine ⟨⟨under.1,under.2,order⟩,?_,?_⟩
      · intro t h
        exact (List.mem_cons.mp h).elim (fun eq => eq.symm ▸ ap) (dis t)
      · intro t ht
        simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using term t ht
    · obtain ⟨order,dis,term⟩ := ih (k+1) n _ (scope_drop bd k) (inj_next bd inj k false) rest
      simp only [compileSlots,e,ite_true]
      refine ⟨order,dis,?_⟩
      intro t ht
      rcases List.mem_cons.mp ht with rfl | old
      · exact ⟨ap,fun x hx => by have := under.1 x hx; omega,fun x hx => by have := under.2 x hx; omega⟩
      · exact term t old

theorem hidden_first_shape (c : FiveProgram) :
    Chronological 10 (hiddenFirst c).1 [] ∧
    (∀ p ∈ (hiddenFirst c).1, Apart p) ∧
    (∀ p ∈ (hiddenFirst c).2, Apart p ∧ Below (10+(hiddenFirst c).1.length) p) := by
  apply compile_shape
  · intro i j h
    by_cases lt : i<10 <;> simp [rawMap,lt] at h <;> omega
  · intro i j v hi hj
    by_cases li : i<10 <;> by_cases lj : j<10 <;> simp [rawMap,li,lj] at hi hj <;> omega
  · exact c.disjoint
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.compile_shape
