import And9822H4Select0
import And9822H4Select1
import And9822H4Select2
import And9822H4Select3
import And9822H4Select4
import And9822H4Select5
import And9822H4Select6
namespace Research.Graph9822.H4Geo
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
theorem allNeg : ∀ s,negSiteP s := Fin.cases negative0 (Fin.cases negative1 (Fin.cases negative2 (Fin.cases negative3 (Fin.cases negative4 (Fin.cases negative5 (Fin.cases negative6 (fun h=>Fin.elim0 h)))))))
theorem allSel : ∀ s,selectedPairP s := Fin.cases selected0 (Fin.cases selected1 (Fin.cases selected2 (Fin.cases selected3 (Fin.cases selected4 (Fin.cases selected5 (Fin.cases selected6 (fun h=>Fin.elim0 h)))))))
end Research.Graph9822.H4Geo
