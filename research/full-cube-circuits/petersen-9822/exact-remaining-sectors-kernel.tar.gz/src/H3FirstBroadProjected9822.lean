import H3FirstBroadLogic9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822H2Check
theorem projected {ws : Array Nat} {k : Fin 1024} {h : Nat}
    (reflects : ∀ i<29, (ws[i]!).testBit k.val=h.testBit i) :
    (∀ i<13, (ws[i]!).testBit k.val=(positive h).testBit i) ∧
    (∀ i<16, (ws[13+i]!).testBit k.val=(negative h).testBit i) := by
  constructor
  · intro i hi
    rw [reflects i (by omega)]
    have m : (8191:Nat).testBit i=true := by
      change (2^13-1:Nat).testBit i=true
      rw [Nat.testBit_two_pow_sub_one]
      exact decide_eq_true hi
    simp [positive,Nat.testBit_and,m]
  · intro i hi
    rw [reflects _ (by omega)]
    simp [negative,Nat.testBit_shiftRight,Nat.add_comm]
end Research.Graph9822FirstBroad
