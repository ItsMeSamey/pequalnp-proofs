import PEqualNP.Defs
namespace Research.Graph9822Planes
def width : Nat := 59049
def ones : Nat := (1 <<< width) - 1
def axis (v digit : Nat) : Nat :=
  let k := 3^v
  ((ones / ((1 <<< (3*k))-1)) * ((1 <<< k)-1)) <<< (digit*k)
def srcRows : Array Nat := #[6,24,17,33,66,132,264,528,160,640,576,320,288,
  50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773]
def rWord (digit raw : Nat) :=
  (List.range 10).foldr (fun v w => if raw.testBit v then axis v digit ||| w else w) 0
def qWord (h : Nat) (use : Bool) (r : Nat) :=
  let b := rWord 2 srcRows[r]!
  if use && h.testBit r then b else rWord 1 srcRows[r]! &&& b
end Research.Graph9822Planes
