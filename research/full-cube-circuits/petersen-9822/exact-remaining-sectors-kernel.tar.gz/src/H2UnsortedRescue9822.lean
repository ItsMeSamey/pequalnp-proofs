import H2CachedPairs9822
import OR9822H2StepSound
namespace Research.Graph9822H2Check

def allRescues (h i j : Nat) : List Nat := do
  let a ← labels h i
  let b ← labels h j
  let c ← labels h i
  let d ← labels h j
  (cachedPairDemand h i j a b c d).toList

theorem allRescues_contains {h i j r : Nat} (mem : r ∈ rescue h i j) :
    r ∈ allRescues h i j := by
  rw [← cachedRescue_eq] at mem
  exact List.mem_eraseDups.mp (List.mem_filter.mp (List.mem_mergeSort.mp mem)).1

def pairCovered (h i j : Nat) (candidates : List Nat) : Bool :=
  (allRescues h i j).all (fun r => candidates.any (fun c => sub c r))

theorem coveredRescue {h i j r q : Nat} {candidates : List Nat}
    (ok : pairCovered h i j candidates = true) (mem : r ∈ rescue h i j)
    (live : holds q r) : ∃ c ∈ candidates, holds q c := by
  have val := List.all_eq_true.mp ok r (allRescues_contains mem)
  obtain ⟨c,hc,small⟩ := List.any_eq_true.mp val
  exact ⟨c,hc,weaker_holds small live⟩

end Research.Graph9822H2Check
