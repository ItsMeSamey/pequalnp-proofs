import CompactPriorSelected38Cell00
namespace PEqualNP.Outside.L_meta_9825.Engine.B767_14
set_option maxRecDepth 16000 in
theorem row11_13_seg16 : CutRow book 11 16 3 := bandCut 11 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B767_14
