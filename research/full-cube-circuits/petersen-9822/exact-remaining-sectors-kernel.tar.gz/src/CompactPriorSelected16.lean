import CompactPriorSelected15
-- CompactPriorFace34
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h561_4 : Face true 561 4 := carry_of (swaps:=[146,130,114,32,48,99,82,64]) (by decide +kernel) h29_4
theorem h646_4 : Face true 646 4 := carry_of (swaps:=[146,130,115,98,83,66,16]) (by decide +kernel) h29_4
theorem h663_7 : Face true 663 7 := carry_of (swaps:=[147,131,116,66,99,32,80,16]) (by decide +kernel) h63_7
theorem h694_7 : Face true 694 7 := carry_of (swaps:=[151,114,130,81,98,50,65]) (by decide +kernel) h190_7

end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace35
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B695_10
def entries : List (Nat × Nat) := [(165,4),(166,4),(183,7),(561,4),(646,4),(660,4),(663,7),(679,7),(689,7),(694,7)]
theorem prior : Known true entries := (consFace h165_4 (consFace h166_4 (consFace h183_7 (consFace h561_4 (consFace h646_4 (consFace h660_4 (consFace h663_7 (consFace h679_7 (consFace h689_7 (consFace h694_7 (known_down baseKnown)))))))))))
def samples : Nat → Bits × Bits := (fun i => (if i<8 then tableBits #[(padColumn 146 0x47fc7c440000001fffe0030000ffff80c03c,padColumn 146 0x3fc3c001810106cb4a0330000ed6500c014),(padColumn 146 0xbc7ffcbc00000000001ffc18300181ffc003,padColumn 146 0x3c3ffc3c60606080606d5c18300181da8001),(padColumn 146 0x3cbc487c800000fe0001ff000cfc6067fc0c3,padColumn 146 0x3c3c003c080818d218192a000ce8606254042),(padColumn 146 0x0,padColumn 146 0x0),(padColumn 146 0x1108bcbfc000ff0001fe00067f3007f83030c,padColumn 146 0x3c3fd030aa3020b40c066a3001a830108),(padColumn 146 0x3fd1113fc07f0001fe00000fb043f880c0c30,padColumn 146 0x3fc0003fe05a60413420300d30412880c0420),(padColumn 146 0x0,padColumn 146 0x0),(padColumn 146 0x22223fd13fff00fe000000ffc0fc830103cc0,padColumn 146 0x3fc012a5802c40c040a2c014830101880)] i else tableBits #[(padColumn 146 0x0,padColumn 146 0x0),(padColumn 146 0x3fffe2223f80ff00000000f87f83040603300,padColumn 146 0x3fffc0002d405581810180581583040602200)] i))
def cols : List ColumnInfo := [(1,0,694,0,7),(16,0,679,0,7),(32,0,663,0,7),(512,0,183,0,7),(4,2,689,0,7),(6,0,689,0,7),(35,0,660,0,4),(48,1,646,0,4),(134,0,561,0,4),(513,16,166,0,4),(529,0,166,0,4),(530,0,165,0,4)]
def data9 : Nat → Nat := (fun i => tableWord #[0x7f,0x40123506] i)
def data8 : Nat → Nat := (fun i => (if i<8 then tableWord #[0xff460,0xa552a04,0xff480,0x50e603,0xff4a0,0x282582a706,0xff4c0,0x140d4ea05] i else tableWord #[0xff4a4,0x282424f506,0xff4c4,0x5043454e907,0xffca0,0x242ace807,0xffca4,0x810a93a84808] i))
def data7 : Nat → Nat := bookData 2 3 3 (fun i => ((fun i => tableWord #[0xca44c44a4ca04c04a0] i) (i/16) >>> (12*(i%16))) % 4096) (fun i => ((fun i => tableWord #[0x1efdfdfeef6f] i) (i/16) >>> (9*(i%16))) % 512) (fun i => ((fun i => tableWord #[0x139954e64b3954ce64d39934c48e3159ce64138cace3273900] i) (i/16) >>> (18*(i%16))) % 262144) (fun i => (if i<8 then tableWord #[0xd3502,0xd3502,0x801,0x0,0x84a02,0xb01,0x0,0x0] i else tableWord #[0x3401,0x0,0x0] i))
def levels : Nat → Packing
  | 7 => (11,2,4,0,0,0,0,data7)
  | 8 => (8,1,4,0,0,0,0,data8)
  | 9 => (1,0,4,0,0,0,0,data9)
  | _ => (0,0,0,0,0,0,0,fun _ => 0)
def index : Nat → Nat → Option (Nat × Nat)
  | 8 => fun h => smallSlot h 6 20 4 1 (fun i => ((fun i => tableWord #[0x18100] i) (i/16) >>> (5*(i%16))) % 32) (fun i => ((fun i => tableWord #[0x2529a38400817588000007008a000016,0x2286008b] i) (i/16) >>> (8*(i%16))) % 256)
  | 9 => fun h => smallSlot h 7 22 4 1 (fun i => ((fun i => tableWord #[0x86020403] i) (i/16) >>> (5*(i%16))) % 32) (fun i => ((fun i => tableWord #[0xc16288c35300000038d4a5b207a655d7,0x400000000] i) (i/16) >>> (8*(i%16))) % 256)
  | _ => fun _ => none
def book : Forest := ⟨695,9,samples,cols,[[],[64,149]],levels,index⟩
end B695_10
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace36
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B695_10
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B695_10
end PEqualNP.Outside.L_meta_9825.Engine
