import And9822H4Original
import And9822H4AllSelect
import And9822H4AllStatic
import And9822H4AllRows
namespace Research.Graph9822.H4Geo
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
theorem verified_layout : Layout :=
  ⟨allNeg,allStatic,allSel,fun i=>(allRows i).1,fun k i=>(allRows i).2 k⟩
open Research.Graph9822.FreeOR Research.Graph9822.Footprint
theorem no_four (c : FiveProgram) (H a b d t : Product)
    (hh : (hiddenFirst c).1=[H,a,b,d]) (ht : (hiddenFirst c).2=[t]) : False :=
  raw_contradiction verified_layout c H a b d t hh ht
#print axioms no_four
end Research.Graph9822.H4Geo
