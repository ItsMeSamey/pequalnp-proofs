import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class016 : runPacket packets[16]! = true := by decide +kernel
theorem class017 : runPacket packets[17]! = true := by decide +kernel
theorem class018 : runPacket packets[18]! = true := by decide +kernel
theorem class019 : runPacket packets[19]! = true := by decide +kernel
end Research.Graph9822FirstBroad
