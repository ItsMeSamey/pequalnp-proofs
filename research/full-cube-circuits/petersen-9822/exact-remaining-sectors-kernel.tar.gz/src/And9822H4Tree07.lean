import And9822H4Tree06
namespace Research.Graph9822.H4Tree
theorem t350 {p : Bad} (legal : Respects p) (ok : Within p 77484543821981485761396372175462762818212015929009472522485860) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t351 {p : Bad} (legal : Respects p) (ok : Within p 77484543821981485761396372175463079730862091433103920407838820) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t349 legal) (t350 legal)
theorem t352 {p : Bad} (legal : Respects p) (ok : Within p 77484543821981485761396893232837590825969465051385438069653860) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t342 legal) (t351 legal)
theorem t353 {p : Bad} (legal : Respects p) (ok : Within p 77133026124431533226014701489750632928823164721488346849738752) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t354 {p : Bad} (legal : Respects p) (ok : Within p 10633823966279383753589781674884858176) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t355 {p : Bad} (legal : Respects p) (ok : Within p 77133026124431533226014701489750632928879935080813539491840320) : Success p :=
  fork legal ok 18 (by decide +kernel) (by decide +kernel) (t353 legal) (t354 legal)
theorem t356 {p : Bad} (legal : Respects p) (ok : Within p 77484543821981485761396893232837590826026207236191361881932132) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t352 legal) (t355 legal)
theorem t357 {p : Bad} (legal : Respects p) (ok : Within p 81844091690530563419406350632148742588880178446336) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t358 {p : Bad} (legal : Respects p) (ok : Within p 63802943797676179644749820154235322368) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t359 {p : Bad} (legal : Respects p) (ok : Within p 81844091690594366363204026811793492409034413768704) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t357 legal) (t358 legal)
theorem t360 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446110771385977391604630310914893300289765376) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t361 {p : Bad} (legal : Respects p) (ok : Within p 7975367974709646500724246780139536384) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t362 {p : Bad} (legal : Respects p) (ok : Within p 7975367974748180863650651267257073664) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t363 {p : Bad} (legal : Respects p) (ok : Within p 7975367974748332126952055685580324864) : Success p :=
  fork legal ok 17 (by decide +kernel) (by decide +kernel) (t361 legal) (t362 legal)
theorem t364 {p : Bad} (legal : Respects p) (ok : Within p 93045959704944111103266494219624120320) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t365 {p : Bad} (legal : Respects p) (ok : Within p 93045959704982947992795707543522377728) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t363 legal) (t364 legal)
theorem t366 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446110779361345366314276811639280852279492608) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t360 legal) (t365 legal)
theorem t367 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446110780690573362099192869010528649523757056) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t368 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446110780690573362099193016584481239336484864) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t366 legal) (t367 legal)
theorem t369 {p : Bad} (legal : Respects p) (ok : Within p 158178131498404998320286005912785649664) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t370 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446110844493517159775164360700185872083451904) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t368 legal) (t369 legal)
theorem t371 {p : Bad} (legal : Respects p) (ok : Within p 50216813964937537801375056936566125853214734092528655073280) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t359 legal) (t370 legal)
theorem t372 {p : Bad} (legal : Respects p) (ok : Within p 77484543821981485761397051410969089269861712199315777788641636) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t356 legal) (t371 legal)
theorem t373 {p : Bad} (legal : Respects p) (ok : Within p 51622884672077286889956153947726483192544127942479811046277124) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t374 {p : Bad} (legal : Respects p) (ok : Within p 188894659352177793827072) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t375 {p : Bad} (legal : Respects p) (ok : Within p 51622884671820062601785532216459848606063550107172568981045344) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t376 {p : Bad} (legal : Respects p) (ok : Within p 51622884671820062601785532216459848606214665834624397627883872) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t374 legal) (t375 legal)
theorem t377 {p : Bad} (legal : Respects p) (ok : Within p 51622884672077286889956153947726483192544127942517203031556452) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t373 legal) (t376 legal)
theorem t378 {p : Bad} (legal : Respects p) (ok : Within p 6582018229284824168619876730229432446035811686318826786767528064) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t379 {p : Bad} (legal : Respects p) (ok : Within p 6633641113956901455509832884177158929228355814261341790775828964) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t377 legal) (t378 legal)
theorem t380 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446111162179008152370048060361603254876897280) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t381 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446110686315385661370014445071241442347712768) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t382 {p : Bad} (legal : Respects p) (ok : Within p 38836741955261850777026816) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t383 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446110686315385661370165560798835159534141696) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t381 legal) (t382 legal)
theorem t384 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446111162179008152370048060361762739897499904) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t380 legal) (t383 legal)
theorem t385 {p : Bad} (legal : Respects p) (ok : Within p 6582018229284824168619876730229412162397939401915505284799799424) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t386 {p : Bad} (legal : Respects p) (ok : Within p 6582068446098707262065987892408420314767987462277266908005802368) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t384 legal) (t385 legal)
theorem t387 {p : Bad} (legal : Respects p) (ok : Within p 251084069415467230553431576928306656644094217796157861527584) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t388 {p : Bad} (legal : Respects p) (ok : Within p 6582269313354239635850430637669962960093302737651489757110215072) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t386 legal) (t387 legal)
theorem t389 {p : Bad} (legal : Respects p) (ok : Within p 6633691330770784548955943663538504296799764215003007651353223652) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t379 legal) (t388 legal)
theorem t390 {p : Bad} (legal : Respects p) (ok : Within p 6659502773106805654381273781640401536562956250921931991313637860) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t372 legal) (t389 legal)
theorem t391 {p : Bad} (legal : Respects p) (ok : Within p 883477452282476249281294387775046356777888778168632666826409421026451940) : Success p :=
  fork legal ok 19 (by decide +kernel) (by decide +kernel) (t337 legal) (t390 legal)
theorem t392 {p : Bad} (legal : Respects p) (ok : Within p 1766847064778384329583297500742918515827483896875618958121606201292619775) : Success p :=
  fork legal ok 3 (by decide +kernel) (by decide +kernel) (t250 legal) (t391 legal)
theorem choose {p : Bad} (legal : Respects p) : Success p := by
  apply t392 legal
  have sat : ∀ i : Fin 240, (1766847064778384329583297500742918515827483896875618958121606201292619775 : Nat).testBit i.val=true := by decide +kernel
  exact fun i _=>sat i
#print axioms choose
end Research.Graph9822.H4Tree
