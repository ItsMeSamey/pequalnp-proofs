import H2PhysicalForest9822
import OR9822H2StepSound
import OR9822H2MaskLogic

namespace Research.Graph9822H2Check
open Research.H3RegionEngine

private theorem allNegativeBits : ∀ n : Fin 16,
    (65535 : Nat).testBit n = true ∧
    ((65535 : Nat) <<< 13).testBit (13+n.val) = true := by decide +kernel

theorem liveStateLeaks {q s : Nat} (live : holds q s)
    (leak : ∃ n : Fin 16, (negative q).testBit n = true) : negative s ≠ 65535 := by
  obtain ⟨n, hq⟩ := leak
  intro full
  have hs : (negative s).testBit n = true := by rw [full]; exact (allNegativeBits n).1
  have bs : s.testBit (13+n.val) = true := by
    simpa [negative,Nat.testBit_shiftRight,Nat.add_comm] using hs
  have bq : q.testBit (13+n.val) = true := by
    simpa [negative,Nat.testBit_shiftRight,Nat.add_comm] using hq
  have bg := (subset_bits s (grants q)).1 live _ bs
  rw [grants,Nat.testBit_xor,bq,(allNegativeBits n).2] at bg
  contradiction

theorem packetExcludesFixedWitness {h q fuel : Nat} {keys hints : List Nat}
    (leak : ∃ n : Fin 16, (negative q).testBit n = true)
    (possible : ∀ s, holds q s → feasible h s = true)
    (resolve : ∀ (code : Nat) (quad : List Nat), matchings[code]? = some quad →
      ∃ i ∈ quad, ∃ j ∈ quad, i < j ∧ ∃ r ∈ rescue h i j, holds q r)
    (accepted : forest (packetRules h) fuel keys hints = true) :
    ∀ s ∈ keys, ¬holds q s := by
  apply packetSound h fuel (fun s => ¬holds q s) keys hints _ accepted
  intro s code children run excluded live
  have branch := step_preserves_witness (q := q) run (liveStateLeaks live leak) (by
    intro quad lookup
    obtain ⟨i,hi,j,hj,lt,r,hr,sat⟩ := resolve code quad lookup
    have joint : holds q (s ||| r) := join_subset live sat
    exact ⟨i,hi,j,hj,lt,r,hr,possible _ joint,joint⟩)
  obtain ⟨k,mem,sat⟩ := branch
  exact excluded k mem sat

theorem initialPacketsExcludeFixedWitness {h q : Nat}
    (leak : ∃ n : Fin 16, (negative q).testBit n = true)
    (possible : ∀ s, holds q s → feasible h s = true)
    (resolve : ∀ (code : Nat) (quad : List Nat), matchings[code]? = some quad →
      ∃ i ∈ quad, ∃ j ∈ quad, i < j ∧ ∃ r ∈ rescue h i j, holds q r)
    (root : ∃ s ∈ initial h, holds q s)
    (packets : ∀ s ∈ initial h, ∃ fuel keys hints,
      s ∈ keys ∧ forest (packetRules h) fuel keys hints = true) : False := by
  obtain ⟨s,mem,sat⟩ := root
  obtain ⟨fuel,keys,hints,inside,accepted⟩ := packets s mem
  exact packetExcludesFixedWitness leak possible resolve accepted s inside sat

end Research.Graph9822H2Check
