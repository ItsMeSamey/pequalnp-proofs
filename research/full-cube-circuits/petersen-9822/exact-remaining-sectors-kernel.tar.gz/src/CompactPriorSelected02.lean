import CompactPriorSelected01
-- CompactPriorC507
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B668_7
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B668_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorC508
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B668_7
set_option maxRecDepth 16000 in
theorem row6_0 : CutRow book 6 0 1 := bandCut 5 false (by decide +kernel)
end B668_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorC509
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B668_7
theorem band6 : CutRow book 6 0 1 := row6_0
end B668_7
end PEqualNP.Outside.L_meta_9825.Engine
