import And9822ReifyMaximum
import OR9822MaximumRepair
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FourSaturation
theorem compact_hidden_witness (c : MaximumFive) (pre post : List Product) (p : Product)
    (split : (hiddenFirst c.toFiveProgram).1=pre++p::post) :
    (∃ m ∈ witnesses, productBit (run pre 10 (fullWire m)) p=true) ∧
    ∀ v : Fin 10, ∃ e ∈ edges, productBit (run pre 10 (fullWire (edgeMask e))) p=true ∧
      v.val≠e.1 ∧ v.val≠e.2 := by
  let z := normalizedMaximum c
  let ts := (hiddenFirst c.toFiveProgram).2
  have dec : z.products=pre++p::(post++ts) := by
    change (hiddenFirst c.toFiveProgram).1 ++ ts = _
    rw [split,List.append_assoc]
    rfl
  have missing : 10+pre.length ∉ z.out := by
    change 10+pre.length ∉ List.range' (10+(hiddenFirst c.toFiveProgram).1.length) ts.length
    intro mem
    obtain ⟨j,_,eq⟩ := List.mem_range'.mp mem
    rw [split,List.length_append,List.length_cons] at eq
    omega
  exact ⟨hidden_leaks z pre _ p dec _ rfl missing,
    fun v => hidden_not_star z pre _ p dec _ rfl missing v⟩
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.compact_hidden_witness
