import CompactPriorSelected24Cell11
-- CompactPriorFace58
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_71 : CutRow book 8 71 12 := (joinRow (joinRow (joinRow row8_71_seg71 row8_71_seg74) row8_71_seg77) row8_71_seg80)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace59
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_83 : CutRow book 8 83 12 := (joinRow (joinRow (joinRow row8_83_seg83 row8_83_seg86) row8_83_seg89) row8_83_seg92)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace60
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_95 : CutRow book 8 95 12 := (joinRow (joinRow (joinRow row8_95_seg95 row8_95_seg98) row8_95_seg101) row8_95_seg104)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
