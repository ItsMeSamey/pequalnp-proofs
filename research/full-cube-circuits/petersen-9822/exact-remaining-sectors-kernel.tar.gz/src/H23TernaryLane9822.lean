import OR9822H2RawMask
namespace Research.Graph9822Ternary
open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)

def trit (j v : Nat) := (j / 3^v) % 3

def packDigits : Nat → (Nat → Nat) → Nat
  | 0, _ => 0
  | n+1, d => d 0 + 3*packDigits n (fun v => d (v+1))

theorem packBound (n : Nat) (d : Nat → Nat) (small : ∀ v, d v<3) :
    packDigits n d < 3^n := by
  induction n generalizing d with
  | zero => simp [packDigits]
  | succ n ih =>
    have tail := ih (fun v => d (v+1)) (fun v => small (v+1))
    have head := small 0
    rw [packDigits,Nat.pow_succ]
    omega

theorem packAt (n : Nat) (d : Nat → Nat) (small : ∀ v, d v<3) (v : Nat) (lt : v<n) :
    trit (packDigits n d) v = d v := by
  induction n generalizing d v with
  | zero => omega
  | succ n ih =>
    have head := small 0
    cases v with
    | zero =>
      simp only [packDigits,trit,Nat.pow_zero,Nat.div_one]
      omega
    | succ v =>
      have drop : (d 0 + 3*packDigits n (fun k => d (k+1)))/3 =
          packDigits n (fun k => d (k+1)) := by omega
      simpa only [packDigits,trit,Nat.pow_succ',←Nat.div_div_eq_div_mul,drop] using
        (show trit (packDigits n (fun k => d (k+1))) v = d (v+1) from
          ih _ (fun k => small (k+1)) v (by omega))

def sourceTrit (A B v : Nat) := if A.testBit v then 1 else if B.testBit v then 2 else 0

private theorem sourceSmall (A B v : Nat) : sourceTrit A B v < 3 := by
  unfold sourceTrit
  split <;> first | decide | split <;> decide

def ternaryLane (A B : Nat) : Fin 59049 :=
  ⟨packDigits 10 (sourceTrit A B),packBound 10 _ (sourceSmall A B)⟩

theorem laneBits (A B : Nat) (apart : meets A B = false) (v : Nat) (lt : v<10) :
    (trit (ternaryLane A B).val v == 1) = A.testBit v ∧
    (trit (ternaryLane A B).val v == 2) = B.testBit v := by
  change (trit (packDigits 10 (sourceTrit A B)) v == 1) = _ ∧
    (trit (packDigits 10 (sourceTrit A B)) v == 2) = _
  rw [packAt _ _ (sourceSmall A B) v lt]
  cases av : A.testBit v with
  | true => simp [sourceTrit,av,(empty_overlap ..).1 apart v av]
  | false => cases bv : B.testBit v <;> simp [sourceTrit,av,bv]

end Research.Graph9822Ternary
