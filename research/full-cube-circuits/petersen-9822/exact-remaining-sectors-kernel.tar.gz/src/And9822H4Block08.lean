import And9822H4BlockDefs
namespace Research.Graph9822.H4Geo
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
private theorem a0 : RowFact (block 8 0) := by unfold RowFact positivesP; decide +kernel
private theorem a1 : RowFact (block 8 1) := by unfold RowFact positivesP; decide +kernel
private theorem a2 : RowFact (block 8 2) := by unfold RowFact positivesP; decide +kernel
private theorem a3 : RowFact (block 8 3) := by unfold RowFact positivesP; decide +kernel
private theorem a4 : RowFact (block 8 4) := by unfold RowFact positivesP; decide +kernel
private theorem a5 : RowFact (block 8 5) := by unfold RowFact positivesP; decide +kernel
private theorem a6 : RowFact (block 8 6) := by unfold RowFact positivesP; decide +kernel
private theorem a7 : RowFact (block 8 7) := by unfold RowFact positivesP; decide +kernel
private theorem a8 : RowFact (block 8 8) := by unfold RowFact positivesP; decide +kernel
private theorem a9 : RowFact (block 8 9) := by unfold RowFact positivesP; decide +kernel
private theorem a10 : RowFact (block 8 10) := by unfold RowFact positivesP; decide +kernel
private theorem a11 : RowFact (block 8 11) := by unfold RowFact positivesP; decide +kernel
theorem block8 : ∀ j,RowFact (block 8 j) := Fin.cases a0 (Fin.cases a1 (Fin.cases a2 (Fin.cases a3 (Fin.cases a4 (Fin.cases a5 (Fin.cases a6 (Fin.cases a7 (Fin.cases a8 (Fin.cases a9 (Fin.cases a10 (Fin.cases a11 (fun h=>Fin.elim0 h))))))))))))
end Research.Graph9822.H4Geo
