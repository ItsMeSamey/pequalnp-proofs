import H3FirstBroadSplit9822
import H3FirstBroadColumn9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822H2Check Research.Graph9822FirstAdmission
open Research.Graph9822.FeatureRun (rawCode rawCode_high)
attribute [local irreducible] roots words rawCode check packets prefixIndex
theorem sorted_reaches (checks : ∀ i : Fin 122, runPacket packets[i.val]! = true) (a b : Fin 1024) (order : (lower a).val ≤ (lower b).val)
    (disj : a.val &&& b.val=0)
    (hid : hidden (rawCode a.val &&& rawCode b.val)=true)
    (adm : firstAdmitted (rawCode a.val &&& rawCode b.val)=true) :
    ∃ i : Nat, roots[i]? = some (rawCode a.val &&& rawCode b.val) := by
  obtain ⟨dj,hj⟩ := split_disjoint a b disj
  exact checked_identifies (x:=(lower a).val) (y:=(lower b).val)
    (h:=rawCode a.val &&& rawCode b.val) (k:=lane a b)
    (checked_prefix checks (lower a) (lower b) order dj) hid adm (raw_meet_bound a b)
    (domain_on (upper a) (upper b) hj) (fun i hi => words_physical a b ⟨i,hi⟩)

theorem admitted_of_packets (checks : ∀ i : Fin 122, runPacket packets[i.val]! = true) (a b : Fin 1024) (disj : a.val &&& b.val=0)
    (hid : hidden (rawCode a.val &&& rawCode b.val)=true)
    (adm : firstAdmitted (rawCode a.val &&& rawCode b.val)=true) :
    ∃ i : Nat, roots[i]? = some (rawCode a.val &&& rawCode b.val) := by
  by_cases ord : (lower a).val ≤ (lower b).val
  · exact sorted_reaches checks a b ord disj hid adm
  · rw [Nat.and_comm (rawCode a.val)]
    apply sorted_reaches checks b a (by omega)
    · simpa only [Nat.and_comm] using disj
    · simpa only [Nat.and_comm] using hid
    · simpa only [Nat.and_comm] using adm
end Research.Graph9822FirstBroad
