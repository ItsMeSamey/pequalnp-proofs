import And9822H3OriginalHidden
import And9822H3PhysicalAdmission
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822FirstAdmission

set_option maxRecDepth 4096 in
theorem original_root (c : MaximumFive) (H Q R A B : Product)
    (hh : (hiddenFirst c.toFiveProgram).1=[H,Q,R]) (ht : (hiddenFirst c.toFiveProgram).2=[A,B])
    (unused : ∃ d,¬reads R A B d 11) (checked : ∀ i : Fin 1024,rowOK i.val=true) :
    roots[rootIndex (encode (firstCol H))]? = some (encode (firstCol H)) := by
  obtain ⟨d,skip⟩ := unused
  have admit := original_admitted c.toFiveProgram H Q R A B hh ht d skip
  have hid := original_hidden c H [Q,R] hh
  have apart := (hidden_first_shape c.toFiveProgram).2.1 H (by simp [hh])
  rw [first_code] at admit hid ⊢
  exact listed_of_rows (a:=⟨armMask H.1,armMask_lt H.1⟩) (b:=⟨armMask H.2,armMask_lt H.2⟩)
    checked (disjoint_arm_masks H.1 H.2 apart) hid admit
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.original_root
