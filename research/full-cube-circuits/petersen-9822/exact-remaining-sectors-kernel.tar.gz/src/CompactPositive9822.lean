import CompactTree9822
import CompactWitness9822
import CompactRows9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open Petersen9822 Petersen9822.DagCut Petersen9822.FirstSite
open PEqualNP.Outside.L_meta_9822.Clean PEqualNP.Outside.L_meta_9822.Sectors

structure PhysicalDiagram (d : Indexed) : Prop where
  raw : ∀ v, v < 10 → d.get v = none
  present : ∀ v, 10 ≤ v → v < 25 → ∃ g, d.get v = some g
  extent : ∀ v g, d.get v = some g → 10 ≤ v ∧ v < 25

structure PhysicalCore (d : Indexed) : Prop where
  diagram : PhysicalDiagram d
  finalWire : ∀ a b, d.edge a b → a ≠ 24
  live : ∀ v, 10 ≤ v → v < 25 → ∃ xs, Path d.edge 24 v xs
  properSockets : ∀ n g, d.get n = some g → g.left ≠ g.right
  signed : ∀ n g, d.get n = some g → ∃ s : Site, g = s.asGate
  computes : ∀ row, edgeHit row = (d.tree 24).term.eval row.testBit

theorem physicalDiagram (net : Net 10 15) : PhysicalDiagram net.indexed := by
  constructor
  · intro v hv
    cases hs : net.get v with
    | none => simp [Net.indexed,hs]
    | some g => have := (net.get_spec hs).1; omega
  · intro v lo hi
    obtain ⟨s,hs⟩ := net.present lo hi
    exact ⟨s.asGate,Option.map_eq_some_iff.mpr ⟨s,hs,rfl⟩⟩
  · intro v g hg
    obtain ⟨s,hs,_⟩ := Option.map_eq_some_iff.mp hg
    exact ⟨(net.get_spec hs).1,(net.get_spec hs).2.1⟩

theorem physicalCore (net : Net 10 15) (h : SignedDag net edge) :
    PhysicalCore net.indexed := by
  let diagram := physicalDiagram net
  refine ⟨diagram,?_,?_,?_,?_,?_⟩
  · intro a b ed eq
    have hlt := net.indexed.chrono ed
    obtain ⟨g,hg,_⟩ := ed
    have hi := (diagram.extent b g hg).2
    omega
  · intro w lo hi
    obtain ⟨s,hs⟩ := net.present lo hi
    exact (h.live w s hs).asPath
  · intro w g hg
    obtain ⟨s,hs,eq⟩ := Option.map_eq_some_iff.mp hg
    subst g
    exact h.proper w s hs
  · intro w g hg
    obtain ⟨s,hs,eq⟩ := Option.map_eq_some_iff.mp hg
    subst g
    exact ⟨s,rfl⟩
  · intro row
    let x : Fin 10 → Bool := fun v => row.testBit v.val
    rw [rowEdge]
    change edge x = (net.indexed.tree 24).term.eval row.testBit
    rw [net.indexed_eval _ _ (by decide)]
    have ev := h.computes x
    change net.eval (inputEnv x) 24 = edge x at ev
    rw [← ev]
    apply net.eval_congr _ 24 (by decide)
    intro i hi
    exact PEqualNP.Outside.L_meta_9822.Clean.getD_ofFn 10 x false ⟨i,hi⟩

theorem physicalCoreOfWitness {gs o} (w : PhysicalWitness (n := 10) gs o 15)
    (ev : ∀ x, vl gs x o = edge x) :
    PhysicalCore (w.net.seal (w.ref o).neg).indexed := by
  have cert := w.signed
  rw [show (fun x => vl gs x o) = edge from funext ev] at cert
  exact physicalCore _ cert

theorem joinedPhysical {gs o} (hr : Reduced 10 gs o) (ev : ∀ x, vl gs x o = edge x)
    (count : gs.countP bin = 15) :
    ∃ w : PhysicalWitness (n := 10) gs o 15,
      PhysicalCore (w.net.seal (w.ref o).neg).indexed := by
  have witness := physicalWitness hr (outputGate ev).2 (by omega)
  rw [count] at witness
  obtain ⟨w⟩ := witness
  exact ⟨w,physicalCoreOfWitness w ev⟩

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.joinedPhysical
