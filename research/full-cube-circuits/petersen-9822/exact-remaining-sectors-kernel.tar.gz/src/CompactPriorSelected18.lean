import CompactPriorSelected17
-- CompactPriorFace40
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B695_10
theorem band8 : CutRow book 8 0 8 := row8_0
end B695_10
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace41
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B695_10
set_option maxRecDepth 16000 in
theorem row7_0 : CutRow book 7 0 3 := bandCut 7 false (by decide +kernel)
end B695_10
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace42
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B695_10
set_option maxRecDepth 16000 in
theorem row7_3 : CutRow book 7 3 8 := bandCut 8 true (by decide +kernel)
end B695_10
end PEqualNP.Outside.L_meta_9825.Engine
