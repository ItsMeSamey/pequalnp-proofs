import CompactPriorC500
-- CompactPriorC501
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B29_4
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B29_4
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorC502
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B29_4
set_option maxRecDepth 16000 in
theorem row3_0 : CutRow book 3 0 1 := bandCut 4 false (by decide +kernel)
end B29_4
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorC503
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B29_4
theorem band3 : CutRow book 3 0 1 := row3_0
theorem checked : mixedTables book 3 := by
  intro k hk
  interval_cases k
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact band3
end B29_4
end PEqualNP.Outside.L_meta_9825.Engine
