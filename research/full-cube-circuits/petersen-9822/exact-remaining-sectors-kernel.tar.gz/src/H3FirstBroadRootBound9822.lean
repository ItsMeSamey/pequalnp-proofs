import H3FirstAdmission9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822FirstAdmission (roots)

set_option maxRecDepth 4096 in
theorem roots_size : roots.size=335 := by decide +kernel
theorem root_values : roots.toList.all (fun h => h < 2^29) = true := by decide +kernel
attribute [local irreducible] roots
theorem bounded_root (i : Nat) (lt : i<335) : roots[i]!<2^29 ∧ i<roots.size := by
  have bd : i < roots.size := roots_size.symm ▸ lt
  have mem : roots[i]! ∈ roots.toList := by
    rw [getElem!_pos roots i bd]
    exact Array.getElem_mem_toList bd
  exact ⟨of_decide_eq_true (List.all_eq_true.mp root_values _ mem),bd⟩
end Research.Graph9822FirstBroad
