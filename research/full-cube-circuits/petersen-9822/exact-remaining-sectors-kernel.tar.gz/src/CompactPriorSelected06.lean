import CompactPriorSelected05
-- CompactPriorFace04
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B63_7
theorem band6 : CutRow book 6 0 1 := row6_0
theorem checked : mixedTables book 6 := by
  intro k hk
  interval_cases k
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact band6
end B63_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace05
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h63_7 : Face true 63 7 :=
  mixedLower (g:=B63_7.book) (i:=0) (hints:=8484)
    (before_sound B63_7.entries B63_7.prior) B63_7.geometry B63_7.checked
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
theorem h78_4 : Face true 78 4 := carry_of (swaps:=[98,82,66,48,16]) (by decide +kernel) h29_4
theorem h95_7 : Face true 95 7 := carry_of (swaps:=[101,66,16]) (by decide +kernel) h63_7
theorem h165_4 : Face true 165 4 := carry_of (swaps:=[115,67,100,83]) (by decide +kernel) h29_4
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace06
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h166_4 : Face true 166 4 := carry_of (swaps:=[115,50,98,83,66,16]) (by decide +kernel) h29_4
theorem h172_4 : Face true 172 4 := carry_of (swaps:=[115,50,98,48,66,80,16]) (by decide +kernel) h29_4
theorem h177_4 : Face true 177 4 := carry_of (swaps:=[114,50,99,82,64]) (by decide +kernel) h29_4

end PEqualNP.Outside.L_meta_9825.Engine
