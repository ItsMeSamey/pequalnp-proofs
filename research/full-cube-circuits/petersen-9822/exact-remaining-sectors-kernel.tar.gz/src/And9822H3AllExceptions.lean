import And9822H3LeafPredicates
import H3TailException09822
import H3TailException19822
import H3TailException29822
import H3TailException39822
import H3TailException49822
import H3TailException59822
import H3TailException69822
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun


theorem original_not_exception (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B]) :
    (encode (firstCol H),encode (secondCol H Q))∉exceptions := by
  intro member
  simp only [exceptions,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at member
  rcases member with m|m|m|m|m|m|m
  · exact Research.H3TailGroups.Case0.impossible c H Q R A B hh ht m.1 m.2
  · exact Research.H3TailGroups.Case1.impossible c H Q R A B hh ht m.1 m.2
  · exact Research.H3TailGroups.Case2.impossible c H Q R A B hh ht m.1 m.2
  · exact Research.H3TailGroups.Case3.impossible c H Q R A B hh ht m.1 m.2
  · exact Research.H3TailGroups.Case4.impossible c H Q R A B hh ht m.1 m.2
  · exact Research.H3TailGroups.Case5.impossible c H Q R A B hh ht m.1 m.2
  · exact Research.H3TailGroups.Case6.impossible c H Q R A B hh ht m.1 m.2
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.original_not_exception
