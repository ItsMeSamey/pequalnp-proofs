import And9822H4Tree02
namespace Research.Graph9822.H4Tree
theorem t150 {p : Bad} (legal : Respects p) (ok : Within p 50364460250358744090856982551727288847971992908000296700424) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t151 {p : Bad} (legal : Respects p) (ok : Within p 1294077440073595361956318076503906549679698518438881707385563054606856) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t149 legal) (t150 legal)
theorem t152 {p : Bad} (legal : Respects p) (ok : Within p 15097570133654722936895999722423806767448213506225091114120612117744136) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t146 legal) (t151 legal)
theorem t153 {p : Bad} (legal : Respects p) (ok : Within p 13803492693782190989877884395165254928246856423878472739784526894465056) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t154 {p : Bad} (legal : Respects p) (ok : Within p 13803492693581323734298754689933308773980682798317036274583284465270784) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t155 {p : Bad} (legal : Respects p) (ok : Within p 441358715781509077504065442733251180753365296324966088720) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t156 {p : Bad} (legal : Respects p) (ok : Within p 13803492693581765093014524067405424838764426435097029674229012914765840) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t154 legal) (t155 legal)
theorem t157 {p : Bad} (legal : Respects p) (ok : Within p 13803492693782632348593665904242758993689589675059226105080851860553776) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t153 legal) (t156 legal)
theorem t158 {p : Bad} (legal : Respects p) (ok : Within p 251819667275082857205443583501338805052231212583597788626992) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t159 {p : Bad} (legal : Respects p) (ok : Within p 13803492693832947242191374767240380243284988626175796547966772166262832) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t157 legal) (t158 legal)
theorem t160 {p : Bad} (legal : Respects p) (ok : Within p 6901746346992068561112129856484847786357048826106047324860201706722359) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t161 {p : Bad} (legal : Respects p) (ok : Within p 6901746346790563787645263488029290624131223337625317040081285150670855) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t162 {p : Bad} (legal : Respects p) (ok : Within p 210507625752265171686472425496700198010642828891143) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t163 {p : Bad} (legal : Respects p) (ok : Within p 6901746346790563787645263488029290624137581397667086753173167052690439) : Success p :=
  fork legal ok 19 (by decide +kernel) (by decide +kernel) (t161 legal) (t162 legal)
theorem t164 {p : Bad} (legal : Respects p) (ok : Within p 6901746346992068561322637482237112958043521251602747522870844535608375) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t160 legal) (t163 legal)
theorem t165 {p : Bad} (legal : Respects p) (ok : Within p 6901746346790563787434755862277025452457467035234470817290979062584320) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t166 {p : Bad} (legal : Respects p) (ok : Within p 6901746346992068561322637482237112958043521254625062071907417472373815) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t164 legal) (t165 legal)
theorem t167 {p : Bad} (legal : Respects p) (ok : Within p 20705239040623511029836638255269670867422570026865197850176512155718711) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t159 legal) (t166 legal)
theorem t168 {p : Bad} (legal : Respects p) (ok : Within p 21999316480646742458337939760332488700402000784293633315024245029346879) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t152 legal) (t167 legal)
theorem t169 {p : Bad} (legal : Respects p) (ok : Within p 905422855503279153951098547569011264463108073096215689824577546879008767) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t135 legal) (t168 legal)
theorem t170 {p : Bad} (legal : Respects p) (ok : Within p 23384026197336981987129026580445251011493668847872) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t171 {p : Bad} (legal : Respects p) (ok : Within p 496925736968920592695349190136340974428708650049999138144236607350243328) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t172 {p : Bad} (legal : Respects p) (ok : Within p 55213970774324510299501430924414051025146416873770938085520562106400768) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t173 {p : Bad} (legal : Respects p) (ok : Within p 496925736968920592695372574162538268875399909007322598672551102270930944) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t171 legal) (t172 legal)
theorem t174 {p : Bad} (legal : Respects p) (ok : Within p 496925736968920592695372574162538268875399913959271650473422172048064768) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t170 legal) (t173 legal)
theorem t175 {p : Bad} (legal : Respects p) (ok : Within p 496925736968920592695302439924541991400980934762720960785148563863635968) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t176 {p : Bad} (legal : Respects p) (ok : Within p 496925736968920592695372592003134427699900963111643522154700195026176256) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t174 legal) (t175 legal)
theorem t177 {p : Bad} (legal : Respects p) (ok : Within p 47852207853248777249454594090682288384) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t178 {p : Bad} (legal : Respects p) (ok : Within p 165641912323023747712317234140759940520564811788676230843148449504823296) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t179 {p : Bad} (legal : Respects p) (ok : Within p 165641912323023747712317234140759940520564816779273129939930248827111680) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t177 legal) (t178 legal)
theorem t180 {p : Bad} (legal : Respects p) (ok : Within p 607353678517619830108211779245677611642008081720148519390033825843120384) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t176 legal) (t179 legal)
theorem t181 {p : Bad} (legal : Respects p) (ok : Within p 441711766194947600093052797360899022057953121452853392491973302655385632) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t182 {p : Bad} (legal : Respects p) (ok : Within p 441711766194596082395824387317335016957529963833305499496052146839748608) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t183 {p : Bad} (legal : Respects p) (ok : Within p 441711766194947600093052809492504410058612111067254152457623899171979296) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t181 legal) (t182 legal)
theorem t184 {p : Bad} (legal : Respects p) (ok : Within p 220855883097599342081210748269528932370749455097425282826535048818196484) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t185 {p : Bad} (legal : Respects p) (ok : Within p 77133026124454917252211474879067063878389204229888551015153668) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t186 {p : Bad} (legal : Respects p) (ok : Within p 220855883097298041198216202769392725580779950487232867825211391254462468) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t187 {p : Bad} (legal : Respects p) (ok : Within p 304015176527911102344542605943012324348209636835332) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t188 {p : Bad} (legal : Respects p) (ok : Within p 220855883097298041198216202769392725580780029715395382089548984798412804) : Success p :=
  fork legal ok 19 (by decide +kernel) (by decide +kernel) (t186 legal) (t187 legal)
theorem t189 {p : Bad} (legal : Respects p) (ok : Within p 220855883174431067322647735995406906013155834636461125791123040892878852) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t185 legal) (t188 legal)
theorem t190 {p : Bad} (legal : Respects p) (ok : Within p 220855883174732368205946296672071023905469802624434038852457314549497860) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t184 legal) (t189 legal)
theorem t191 {p : Bad} (legal : Respects p) (ok : Within p 220855883174431067322343720818878994910811371258718406662975381961703424) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t192 {p : Bad} (legal : Respects p) (ok : Within p 220855883174732368205946296672071023905469802624471817784320271711207428) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t190 legal) (t191 legal)
theorem t193 {p : Bad} (legal : Respects p) (ok : Within p 77434327007730093902678298324689772909076435694771286912794720) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t194 {p : Bad} (legal : Respects p) (ok : Within p 220855883174732368205946296672071023905469802624471817784320271711207524) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t192 legal) (t193 legal)
theorem t195 {p : Bad} (legal : Respects p) (ok : Within p 220855883097298041197912261809744835188354451973304059960120705770590210) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t196 {p : Bad} (legal : Respects p) (ok : Within p 220855883174732368205946348052987961320030591327585482522980426652323942) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t194 legal) (t195 legal)
theorem t197 {p : Bad} (legal : Respects p) (ok : Within p 662567649369378667415700596868828253486328734406866721919270052167684198) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t183 legal) (t196 legal)
theorem t198 {p : Bad} (legal : Respects p) (ok : Within p 828209561692352198314134737563477507691507889854811033015626996532648294) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t180 legal) (t197 legal)
theorem t199 {p : Bad} (legal : Respects p) (ok : Within p 1733632417143958250779272841283899516088777791084779975562227931255177215) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t169 legal) (t198 legal)
end Research.Graph9822.H4Tree
