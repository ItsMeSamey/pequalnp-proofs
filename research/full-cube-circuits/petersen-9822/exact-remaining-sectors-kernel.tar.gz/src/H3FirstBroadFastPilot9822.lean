import H3FirstBroadFast9822
namespace Research.Graph9822FirstBroad
theorem fastPilot : fastCheck 2 4 [9, 24, 87, 3, 20, 65, 17, 106, 108, 16, 42] [15, 71, 73, 75, 86, 89, 147, 148, 152, 153, 154, 155, 156, 158, 159, 167, 168, 169, 170, 171, 172, 173, 178, 181, 185, 189, 196, 197, 198, 214, 215, 216, 218, 219, 223, 227, 229, 231, 235, 301, 302, 313, 315, 316, 318] = true := by decide +kernel
end Research.Graph9822FirstBroad
