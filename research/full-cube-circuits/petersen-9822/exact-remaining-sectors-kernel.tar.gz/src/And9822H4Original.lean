import And9822H4GeoSound
import And9822H4Tree07
import And9822H4Physical
namespace Research.Graph9822.H4Geo
open Research.Graph9822.FreeOR Research.Graph9822.FourSaturation Research.Graph9822.ReverseChannel
open Research.Graph9822OneHidden (meets)
open Research.Graph9822.H4Tree
structure Layout : Prop where
  neg : ∀ s, negSiteP s
  pair : ∀ p,static_pairP p
  selection : ∀ s,selectedPairP s
  edges : ∀ i,positivesP i
  profile : Profile

theorem separator (L : Layout) (A B : Nat) (s : Fin 7) (i j : Fin 10) (ne : i≠j)
    (safe : ∀ q : OrId,(choices[s.val]!).testBit q.val=true → ¬Obeys (key A B) q) :
    ∃ e,raw e<1024 ∧ accepts (raw e)=true ∧ raw e &&& (nm s i ||| nm s j)=raw e ∧
      (hot A B (raw e)=true → hot A B (nm s i)=true ∨ hot A B (nm s j)=true) := by
  classical
  let p := pairNumber s i j
  obtain ⟨c1,c2,order⟩ := L.selection s i j ne
  obtain ⟨swapL,swapR,same,head⟩ := L.pair p
  let l := sideL (first p)
  let r := sideR (first p)
  have uni : l ||| r = nm s i ||| nm s j := by
    rcases order with ⟨x,y⟩|⟨x,y⟩
    · exact congrArg₂ Nat.lor x y
    · exact (congrArg₂ Nat.lor x y).trans (Nat.or_comm _ _)
  have send : ∃ e∈possible (first p),hot A B (raw e)=true → hot A B l=true ∨ hot A B r=true := by
    by_contra! no
    have all (e) (mem : e∈possible (first p)) : hot A B (raw e)=true := (no e mem).1
    obtain ⟨_,nl,nr⟩ := no _ head
    have he : meets A (raw (possible (first p)).head!)=true ∧ meets B (raw (possible (first p)).head!)=true := by simpa only [hot,Bool.and_eq_true] using all _ head
    have cov := (geo L.edges _ _ head).2.2
    have ah := hit_union cov he.1
    have bh := hit_union cov he.2
    change meets A l=true ∨ meets A r=true at ah
    change meets B l=true ∨ meets B r=true at bh
    have avoid : (meets A r=false ∧ meets B l=false) ∨ (meets A l=false ∧ meets B r=false) := by
      cases xa : meets A l <;> cases xb : meets B l <;> cases ya : meets A r <;> cases yb : meets B r <;> simp_all [hot,l,r]
    rcases avoid with ⟨ar,bl⟩|⟨al,br⟩
    · exact (safe (first p) c1) (oriented L.edges L.profile A B (first p) ar bl all)
    · apply (safe (second p) c2)
      apply oriented L.edges L.profile
      · simpa [←swapL] using al
      · simpa [←swapR] using br
      · simpa [←same] using all
  obtain ⟨e,mem,tag⟩ := send
  obtain ⟨sz,pos,sub⟩ := geo L.edges _ _ mem
  refine ⟨e,sz,pos,?_,?_⟩
  · simpa [←uni,l,r] using sub
  · intro he
    rcases order with ⟨x,y⟩|⟨x,y⟩
    · change l=nm s i at x
      change r=nm s j at y
      simpa only [x,y] using tag he
    · change l=nm s j at x
      change r=nm s i at y
      simpa only [x,y] using (tag he).symm

theorem raw_contradiction (L : Layout) (c : FiveProgram) (H a b d t : Product)
    (hh : (hiddenFirst c).1=[H,a,b,d]) (ht : (hiddenFirst c).2=[t]) : False := by
  let A := armMask H.1
  let B := armMask H.2
  obtain ⟨s,h⟩ := H4Tree.choose (respect L.profile (key A B))
  apply raw_no_ten c H a b d t hh ht (fun i=>⟨nm s i,(L.neg s i).1⟩) (fun i=>(L.neg s i).2)
  intro i j ne
  obtain ⟨e,sz,pos,sub,transfer⟩ := separator L A B s i j ne h
  refine ⟨⟨raw e,sz⟩,pos,?_,?_⟩
  · intro u bound hit
    have k := congrArg (fun n : Nat=>n.testBit u) sub
    have yes : (raw e).testBit u=true := by simpa [fullWire,bound] using hit
    have cover : (nm s i).testBit u=true ∨ (nm s j).testBit u=true := by
      simpa [Nat.testBit_and,Nat.testBit_or,yes] using k
    simpa [fullWire,bound] using cover
  · simpa only [productBit,read_arm_mask,hot,A,B] using transfer
end Research.Graph9822.H4Geo
