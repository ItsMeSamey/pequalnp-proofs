import H3FirstBroadProjected9822
import H3FirstBroadHidden9822
import H3FirstBroadCuts9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822FirstAdmission
attribute [local irreducible] certifiedCuts leakingWord nonstarWord
theorem survivor {ws : Array Nat} {k : Fin 1024} {h : Nat} {ds : List Nat}
    (reflects : ∀ i<29, (ws[i]!).testBit k.val=h.testBit i) (hd : hidden h=true)
    (ad : firstAdmitted h=true) (hbd : h<2^29) (dbd : ∀ d∈ds,d<120) :
    (leakingWord ws).testBit k.val=true ∧ (nonstarWord ws).testBit k.val=true ∧
    (certifiedCuts ws ds).testBit k.val=true := by
  obtain ⟨p,n⟩ := projected (ws:=ws) (k:=k) (h:=h) reflects
  obtain ⟨a,b⟩ := hidden_words (ws:=ws) (k:=k) (h:=h) hd hbd p n
  exact ⟨a,b,usable_cut (ws:=ws) (k:=k) (h:=h) (ds:=ds) ad dbd p n⟩
end Research.Graph9822FirstBroad
