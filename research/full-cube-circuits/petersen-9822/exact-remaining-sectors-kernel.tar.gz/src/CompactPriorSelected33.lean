import CompactPriorSelected32
-- CompactPriorFace85
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B759_12
theorem band11 : CutRow book 11 0 1 := row11_0
end B759_12
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace86
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B759_12
set_option maxRecDepth 16000 in
theorem row10_0 : CutRow book 10 0 3 := bandCut 9 false (by decide +kernel)
end B759_12
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace87
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B759_12
theorem band10 : CutRow book 10 0 3 := row10_0
end B759_12
end PEqualNP.Outside.L_meta_9825.Engine
