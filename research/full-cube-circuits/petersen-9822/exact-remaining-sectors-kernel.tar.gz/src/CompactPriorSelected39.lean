import CompactPriorSelected39Cell10
-- CompactPriorFace103
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem row10_1 : CutRow book 10 1 12 := (joinRow (joinRow (joinRow row10_1_seg1 row10_1_seg4) row10_1_seg7) row10_1_seg10)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace104
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem row10_13 : CutRow book 10 13 12 := (joinRow (joinRow (joinRow row10_13_seg13 row10_13_seg16) row10_13_seg19) row10_13_seg22)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace105
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem row10_25 : CutRow book 10 25 9 := (joinRow (joinRow row10_25_seg25 row10_25_seg28) row10_25_seg31)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
