import CompactPriorSelected11
-- CompactPriorFace22
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h190_7 : Face true 190 7 :=
  mixedLower (g:=B190_7.book) (i:=0) (hints:=544416032)
    (before_sound B190_7.entries B190_7.prior) B190_7.geometry B190_7.checked
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
theorem h222_7 : Face true 222 7 := carry_of (swaps:=[101,113]) (by decide +kernel) h190_7
theorem h238_7 : Face true 238 7 := carry_of (swaps:=[84,100,49,113]) (by decide +kernel) h190_7

end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace23
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B255_11
def entries : List (Nat × Nat) := [(29,4),(30,4),(57,4),(63,7),(78,4),(95,7),(166,4),(177,4),(183,7),(189,8),(190,7),(198,4),(222,7),(231,7),(238,7)]
theorem prior : Known true entries := (consFace h29_4 (consFace h30_4 (consFace h57_4 (consFace h63_7 (consFace h78_4 (consFace h95_7 (consFace h166_4 (consFace h177_4 (consFace h183_7 (consFace h189_8 (consFace h190_7 (consFace h198_4 (consFace h222_7 (consFace h231_7 (consFace h238_7 (known_down baseKnown))))))))))))))))
def samples : Nat → Bits × Bits := (fun i => (if i<8 then tableBits #[(padColumn 248 0xf8787c3f888447fe210f80000001ffffe0000000000c03ffffc02060303c0,padColumn 248 0x78783c3f800003fe0007802030074aaaa0080c06000c03d55280206030140),(padColumn 248 0x1088fffc7910888425fff80000ffe0000000003fe0603ff0180c0c01ff0c03,padColumn 248 0x7ffc7800000001fff80c0455201806030125a0602aa0180c0c01560401),(padColumn 248 0x211108448f813fcbfe210801ff00000000007fffe01fc000603001ffff300f,padColumn 248 0x7803fc3fe000010d10080601804165a40168000603000aca91006),(padColumn 248 0x47f813ff8227d13c484ff8000000000001ffffc0018000c18003fffe04003c,padColumn 248 0x7f803ff8007c03c000ff8600803018020a9e980818000c18002ab52040018),(padColumn 248 0xfa227c8917fa03d09ff2100000000007ffff80000603030007fffe081800f0,padColumn 248 0xf8007c0007f803c01ff00180300c0205555602030603030002d554081800a0),(padColumn 248 0x8444211227fffc211fffa7fe00001ff8000000001fe40c0ff840303060c300,padColumn 248 0x7fffc001fff82b440300b5040180c0c15440c02a8403030604200),(padColumn 248 0xffffc22047ffffffe084400000ffe0000000000018183ff60180c0c0800c00,padColumn 248 0xffff800007ffffffe000060180aacc0180603010181815560180c0c0800800),(padColumn 248 0xfffffffffc442202110807ffff000000000000001ffff0080603010100f000,padColumn 248 0xfffffffff80000000000054b2ec01006018040200aa970080603010100a000)] i else tableBits #[(padColumn 248 0x0,padColumn 248 0x0),(padColumn 248 0x0,padColumn 248 0x0)] i))
def cols : List ColumnInfo := [(2,64,189,0,8),(66,0,189,0,8),(17,0,238,0,7),(24,0,231,0,7),(33,0,222,0,7),(65,0,190,0,7),(72,0,183,0,7),(160,0,95,0,7),(192,0,63,0,7),(41,16,198,0,4),(56,1,198,0,4),(57,0,198,0,4),(73,16,166,0,4),(78,0,177,0,4),(89,0,166,0,4),(176,1,78,0,4),(177,0,78,0,4),(193,32,30,0,4),(198,0,57,0,4),(225,0,30,0,4),(226,0,29,0,4)]
def data10 : Nat → Nat := (fun i => tableWord #[0xff,0x220ce106] i)
def data9 : Nat → Nat := (fun i => (if i<16 then (if i<8 then tableWord #[0x1ff440,0x2a014f04,0x1ff460,0xe038f04,0x1ff462,0xf44c40d05,0x1ff482,0x115200cc05] i else tableWord #[0x1ff4a3,0x202d103,0x1ff4e3,0xa48c80f18707,0x1ff4a4,0x53202d105,0x1ff862,0x83d14930cd08] i) else tableWord #[0x1ff882,0x321224d06,0x1ffc40,0x31c529206] i))
def data8 : Nat → Nat := (fun i => (if i<16 then (if i<8 then tableWord #[0x2efd04460,0x306102,0x2f7d03482,0x306102,0x2fed004a4,0x306102,0x2ef504c40,0x1201] i else tableWord #[0x3f7862460,0x18e02,0x3f74e3462,0x1401,0x2ff507462,0x0,0x2ffd07482,0x0] i) else tableWord #[0x2ffd024e3,0x6001] i))
def levels : Nat → Packing
  | 8 => (9,2,5,0,0,0,0,data8)
  | 9 => (10,1,5,0,0,0,0,data9)
  | 10 => (1,0,5,0,0,0,0,data10)
  | _ => (0,0,0,0,0,0,0,fun _ => 0)
def index : Nat → Nat → Option (Nat × Nat)
  | 9 => fun h => smallSlot h 5 17 4 1 (fun i => ((fun i => tableWord #[0x380c4] i) (i/16) >>> (5*(i%16))) % 32) (fun i => ((fun i => tableWord #[0xe502d4612369a708e6e4760000000000,0x0] i) (i/16) >>> (8*(i%16))) % 256)
  | 10 => fun h => smallSlot h 8 25 4 1 (fun i => ((fun i => tableWord #[0x10400180c1] i) (i/16) >>> (5*(i%16))) % 32) (fun i => ((fun i => tableWord #[0xd800000000e15265440043e92600a2,0x338a008708191594] i) (i/16) >>> (8*(i%16))) % 256)
  | _ => fun _ => none
def book : Forest := ⟨255,10,samples,cols,[[],[115,84]],levels,index⟩
end B255_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace24
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B255_11
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B255_11
end PEqualNP.Outside.L_meta_9825.Engine
