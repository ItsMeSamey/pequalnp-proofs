import CompactPriorSelected21Part1
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
set_option maxRecDepth 16000 in
theorem row8_0 : CutRow book 8 0 4 := bandCut 7 false (by decide +kernel)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
