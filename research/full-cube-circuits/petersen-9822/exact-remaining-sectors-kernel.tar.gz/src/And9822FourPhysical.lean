import And9822Four
import PhysicalResolution

namespace Research.Graph9822Resolution
open PEqualNP.Outside.L_meta_9822.Sectors

theorem inputSet_apply (xs : List Nat) (j : Nat) :
    inputSet xs j = decide (j ∈ xs) := by
  induction xs with
  | nil => simp [inputSet]
  | cons a tail ih => simp [inputSet,wireUnion,ih]

theorem lower_four_physical (gs : List Gate) (out : Nat)
    (computes : ∀ x : Fin 10 → Bool, (asCircuit gs out).eval (List.ofFn x) = edge x) :
    4 ≤ gs.countP Gate.isAnd := by
  apply four_le
  intro xs hb
  let x : Fin 10 → Bool := fun i => decide (i.val ∈ xs)
  have hw : wiresFrom (List.ofFn x) = inputSet xs := by
    funext j
    rw [inputSet_apply]
    by_cases hj : j < 10
    · unfold wiresFrom
      rw [List.getD_eq_getElem?_getD,List.getElem?_ofFn,dif_pos hj]
      rfl
    · have no : j ∉ xs := fun hm => hj (hb j hm)
      simp [wiresFrom,List.getD_eq_getElem?_getD,List.getElem?_ofFn,hj,no]
  have h := computes x
  rw [physical_eval,List.length_ofFn,hw] at h
  exact h

end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.lower_four_physical
