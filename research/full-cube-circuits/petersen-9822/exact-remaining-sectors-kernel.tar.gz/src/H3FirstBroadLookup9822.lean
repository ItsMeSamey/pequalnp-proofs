import H3FirstBroadPackets9822
import H3FirstBroadStaticProof9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822FirstAdmission (roots)

def Checked (x y : Nat) : Prop :=
  ∃ ds rs : List Nat, check x y ds rs = true ∧ (∀ j ∈ ds, j < 120) ∧ (∀ i ∈ rs, i < 335)

attribute [local irreducible] check fastCheck packets prefixIndex

theorem checked_record (p : Packet) (ok : runPacket p = true)
    (bounds : ((p.2.2.1.all fun d => d < 120) && (p.2.2.2.all fun i => i < 335)) = true) :
    Checked p.1 p.2.1 := by
  simp only [Bool.and_eq_true] at bounds
  exact ⟨p.2.2.1,p.2.2.2,(fast_eq p.1 p.2.1 p.2.2.1 p.2.2.2).trans ok,
    fun d mem => of_decide_eq_true (List.all_eq_true.mp bounds.1 d mem),
    fun i mem => of_decide_eq_true (List.all_eq_true.mp bounds.2 i mem)⟩

theorem checked_prefix (checks : ∀ i : Fin 122, runPacket packets[i.val]! = true)
    (a b : Fin 32) (ord : a.val ≤ b.val) (disj : a.val &&& b.val = 0) : Checked a.val b.val := by
  obtain ⟨lt,x,y⟩ := prefix_exact a b ord disj
  let i : Fin 122 := ⟨prefixIndex a.val b.val,lt⟩
  have v := checked_record (packets[i.val]!) (checks i) (packetBounds i)
  change (packets[i.val]!).1=a.val at x
  change (packets[i.val]!).2.1=b.val at y
  rw [x,y] at v
  exact v

end Research.Graph9822FirstBroad
