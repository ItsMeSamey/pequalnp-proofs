import CompactPriorSelected40
-- CompactPriorFace109
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
set_option maxRecDepth 16000 in
theorem row9_1 : CutRow book 9 1 2 := bandCut 10 false (by decide +kernel)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace110
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem combine9_0_3 : CutRow book 9 0 3 := @joinRow book 9 0 1 2 row9_0 row9_1
theorem band9 : CutRow book 9 0 3 := combine9_0_3
theorem checked : mixedTables book 13 := by
  intro k hk
  interval_cases k
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact band9
  · exact band10
  · exact band11
  · exact band12
  · exact band13
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace111
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h767_14 : Face true 767 14 :=
  mixedLower (g:=B767_14.book) (i:=0) (hints:=275431563556)
    (before_sound B767_14.entries B767_14.prior) B767_14.geometry B767_14.checked
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
theorem h1015_14 : Face true 1015 14 := carry_of (swaps:=[100,131,82,16]) (by decide +kernel) h767_14
end PEqualNP.Outside.L_meta_9825.Engine
