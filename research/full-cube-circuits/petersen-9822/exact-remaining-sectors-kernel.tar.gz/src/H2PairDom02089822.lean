import H2CanonicalPairs9822
namespace Research.Graph9822H2Check
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem dom2_8 : pairDom 2 8 = true := by decide +kernel
end Research.Graph9822H2Check
