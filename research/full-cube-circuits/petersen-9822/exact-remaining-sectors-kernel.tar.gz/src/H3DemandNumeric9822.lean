import H3DemandSteps9822
import H2FastStep9822
namespace Research.Graph9822DemandThree
open Research.Graph9822H2Check Research.Graph9822OneHidden

def exPair (h q : Nat) : Bool :=
  h == q || (h == 786481 && [5047856,788144,26106200,788016,26106184,26106216].contains q) ||
    (h == 26106184 && q == 786481)

def notHidden (p n : Nat) : Bool :=
  n == 0 || vs.any (fun v => sub p (rawPos (bit v)))

def subsets (s : Nat) : List Nat :=
  vs.foldl (fun xs i => if s.testBit i then xs ++ xs.map (· ||| bit i) else xs) [0]

def seedSafe (h s : Nat) (useH : Bool) (a b : Nat) : Bool := Id.run do
  let hp := if useH then positive h else 0
  let hn := if useH then negative h else 0
  let t := positive s
  let f := negative s
  if meets a b || meets f ((rawNeg a ||| hn) &&& rawNeg b) then return true
  let am := freeRaw (f &&& rawNeg b) &&& (1023 ^^^ b)
  let bm := freeRaw (f &&& (rawNeg a ||| hn)) &&& (1023 ^^^ a)
  if notHidden ((rawPos am ||| hp) &&& rawPos bm) ((rawNeg am ||| hn) &&& rawNeg bm) then return true
  return (subsets (am &&& (1023 ^^^ a))).all fun ax =>
    let av := a ||| ax
    (subsets (bm &&& (1023 ^^^ (av ||| b)))).all fun bx =>
      let bv := b ||| bx
      let p := (rawPos av ||| hp) &&& rawPos bv
      let n := (rawNeg av ||| hn) &&& rawNeg bv
      !sub t p || meets f n || notHidden p n || exPair h (demand p n)

def terminal (h s : Nat) : Bool :=
  [false,true].all fun useH =>
    let hp := if useH then positive h else 0
    (fastCovers (positive s)).all fun b =>
      (fastCovers (positive s &&& (8191 ^^^ hp))).all fun a => seedSafe h s useH a b

def check (h : Nat) (hints : List Nat) : Bool :=
  Research.H3RegionEngine.accepts (rules h (fastFeasible h) (terminal h)) 31 0 hints
end Research.Graph9822DemandThree
