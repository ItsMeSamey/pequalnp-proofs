import CompactPriorSelected39Cell05
namespace PEqualNP.Outside.L_meta_9825.Engine.B767_14
set_option maxRecDepth 16000 in
theorem row10_13_seg19 : CutRow book 10 19 3 := bandCut 10 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B767_14
