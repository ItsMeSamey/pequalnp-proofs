import H3FirstBroadReflect9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822H2Check Research.Graph9822FirstAdmission Research.Graph9822OneHidden

theorem bitBound {x j n : Nat} (bd : x<2^n) (hot : x.testBit j=true) : j<n := by
  by_contra! no
  have off := Nat.testBit_lt_two_pow (lt_of_lt_of_le bd (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) no))
  simp [off] at hot

theorem star_bit : ∀ w : Fin 10, ∀ j : Fin 13, (rawPos (bit w.val)).testBit j.val =
    (edges[j.val]!).testBit w.val := by decide +kernel

theorem hidden_words {ws : Array Nat} {k : Fin 1024} {h : Nat}
    (hd : hidden h=true) (hbd : h < 2^29)
    (pos : ∀ i<13, (ws[i]!).testBit k.val=(positive h).testBit i)
    (neg : ∀ i<16, (ws[13+i]!).testBit k.val=(negative h).testBit i) :
    (leakingWord ws).testBit k.val=true ∧ (nonstarWord ws).testBit k.val=true := by
  simp only [Research.Graph9822FirstAdmission.hidden,Bool.and_eq_true] at hd
  obtain ⟨leak,miss⟩ := hd
  constructor
  · obtain ⟨i,hi⟩ := Nat.exists_testBit_of_ne_zero (bne_iff_ne.mp leak)
    have negbd : negative h < 2^16 := by
      simp only [negative,Nat.shiftRight_eq_div_pow]; omega
    have bi := bitBound negbd hi
    exact sums_of_mem _ _ (List.mem_range.mpr bi) ((neg i bi).trans hi)
  · apply prods_of_all
    intro es mem
    obtain ⟨v,vm,rfl⟩ := List.mem_map.mp mem
    have bad := List.all_eq_true.mp miss (rawPos (bit v)) (List.mem_map.mpr ⟨v,vm,rfl⟩)
    have nh : ¬∀ j, (positive h).testBit j=true → (rawPos (bit v)).testBit j=true := by
      intro hh
      have s := (subset_bits ..).2 hh
      simp [s] at bad
    push_neg at nh
    obtain ⟨i,hot,cold⟩ := nh
    have bound : positive h < 2^13 := Nat.and_lt_two_pow h (by decide : 8191 < 2^13)
    have bi := bitBound bound hot
    have eq := star_bit ⟨v,List.mem_range.mp vm⟩ ⟨i,bi⟩
    apply sums_of_mem (x:=i)
    · apply List.mem_filter.mpr
      refine ⟨List.mem_range.mpr bi,?_⟩
      have off : (edges[i]!).testBit v=false := by
        rw [←eq]
        simpa using cold
      change (!(edges[i]!).testBit v) = true
      rw [off]
      decide
    · exact (pos i bi).trans hot

end Research.Graph9822FirstBroad
