import CompactPriorSelected07
-- CompactPriorFace10
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B189_8
theorem band7 : CutRow book 7 0 1 := row7_0
end B189_8
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace11
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B189_8
set_option maxRecDepth 16000 in
theorem row6_0 : CutRow book 6 0 2 := bandCut 7 false (by decide +kernel)
end B189_8
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace12
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B189_8
theorem band6 : CutRow book 6 0 2 := row6_0
end B189_8
end PEqualNP.Outside.L_meta_9825.Engine
