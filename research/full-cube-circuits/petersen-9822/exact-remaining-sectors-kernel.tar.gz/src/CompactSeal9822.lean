import CompactLive9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean

abbrev Site.seal (s : Site) (negative : Bool) : Site :=
  {s with outNeg := if negative then !s.outNeg else s.outNeg}

theorem Site.seal_op (s : Site) (negative a b : Bool) :
    (s.seal negative).op a b = if negative then !(s.op a b) else s.op a b := by
  cases negative <;> cases h : s.outNeg <;> simp [Site.seal,Site.op,h]

def Net.seal {n k} (net : Net n k) (negative : Bool) : Net n k :=
  match net with
  | .empty => .empty
  | .snoc pre s l r => pre.snoc (s.seal negative) l r

theorem Net.seal_get {n k} (net : Net n k) (neg : Bool) (w : Nat) :
    (net.seal neg).get w =
      (net.get w).map (fun g => if w+1 = n+k then g.seal neg else g) := by
  cases net with
  | empty => rfl
  | @snoc j pre g l r =>
    by_cases eq : w = n+j
    · subst w; simp [Net.get,Net.seal,Nat.add_assoc]
    · have hi : w+1 ≠ n+(j+1) := by omega
      simp [Net.get,Net.seal,eq,hi]

theorem Net.seal_last {n k} (net : Net n k) (h : 0 < k) (env : Nat → Bool) (b : Bool) :
    (net.seal b).eval env (n+k-1) = if b then !(net.eval env (n+k-1)) else net.eval env (n+k-1) := by
  cases net with
  | empty => omega
  | @snoc j pre g l r =>
    have last : n+(j+1)-1 = n+j := by omega
    simp [last,Net.seal,Net.eval,Site.seal_op]

theorem Net.seal_edge {n k} (net : Net n k) (b : Bool) (a w : Nat) :
    (net.seal b).Edge a w ↔ net.Edge a w := by
  unfold Net.Edge
  rw [net.seal_get]
  cases e : net.get w with
  | none => simp
  | some s =>
    by_cases h : w+1 = n+k <;> simp [h,Site.seal]

theorem Net.seal_proper {n k} {net : Net n k} (h : net.Proper) (b : Bool) : (net.seal b).Proper := by
  intro w g hg
  rw [net.seal_get] at hg
  cases hs : net.get w with
  | none => simp [hs] at hg
  | some s =>
    have ne := h w s hs
    by_cases eq : w+1 = n+k <;> simp [hs,eq] at hg <;> subst g <;> exact ne

theorem Route.seal {n k} {net : Net n k} {w o} (h : Route net w o) (b : Bool) :
    Route (net.seal b) w o := by
  induction h with
  | done => exact .done _
  | step e _ ih => exact .step ((net.seal_edge b _ _).mpr e) ih

theorem Net.eval_congr {n k} (net : Net n k) {x y : Nat → Bool}
    (h : ∀ i < n, x i = y i) (w : Nat) (hw : w < n+k) : net.eval x w = net.eval y w := by
  induction w using Nat.strong_induction_on with
  | ind w ih =>
    by_cases raw : w < n
    · rw [net.eval_raw x raw,net.eval_raw y raw,h w raw]
    · obtain ⟨g,hg⟩ := net.present (by omega : n ≤ w) hw
      have bounds := net.get_spec hg
      rw [net.eval_gate x hg,net.eval_gate y hg,ih _ bounds.2.2.1 (by omega),ih _ bounds.2.2.2 (by omega)]

structure SignedDag {n k} (net : Net n k) (f : (Fin n → Bool) → Bool) : Prop where
  proper : net.Proper
  live : ∀ w g, net.get w = some g → Route net w (n+k-1)
  computes : ∀ x, net.eval (inputEnv x) (n+k-1) = f x

theorem signedDagOf {n gs o} (hr : Reduced n gs o) (ho : o < n+gs.length)
    (hk : 0 < gs.countP bin) : ∃ net : Net n (gs.countP bin), SignedDag net (fun x => vl gs x o) := by
  obtain ⟨k,net,ref,count,real,tr⟩ := trackedPrefix hr gs.length le_rfl
  rw [List.take_length] at count
  subst k
  have last := tr.output_last hr ho real hk
  refine ⟨net.seal (ref o).neg, Net.seal_proper tr.proper _, ?_,?_⟩
  · intro w g hg
    rw [net.seal_get] at hg
    cases h : net.get w with
    | none => simp [h] at hg
    | some s =>
      rw [← last]
      exact (tr.live hr h).seal _
  · intro x
    rw [net.seal_last hk, ← real.semantic o ho x]
    simp [Lit.read,last]

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.signedDagOf
