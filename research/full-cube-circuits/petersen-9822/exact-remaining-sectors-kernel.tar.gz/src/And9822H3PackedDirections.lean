import And9822H3Directions
import OR9822TwoSlotValue
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822.FourSaturation Research.Graph9822DemandThree

def source : Fin 10 ⊕ Bool → Nat
  | .inl v => v.val
  | .inr false => 10
  | .inr true => 11

def feathot (H Q : Product) (r : Fin 29) :=
  fires (fun v : Fin 10 => (rawRow r).testBit v.val=true)
    (firstCol H r=true) (secondCol H Q r=true)

private theorem feature_eq (H Q R : Product) (r : Fin 29) (f : Fin 10 ⊕ Bool) :
    run [H,Q,R] 10 (fullWire (rawRow r)) (source f)=true ↔ feathot H Q r f := by
  have lt : source f<12 := by
    cases f with
    | inl v => change v.val<12; omega
    | inr b => cases b <;> decide
  have last : run [H,Q,R] 10 (fullWire (rawRow r)) (source f) =
      run [H,Q] 10 (fullWire (rawRow r)) (source f) := by
    simp [run,Function.update_of_ne (show source f≠12 by omega)]
  rw [last,after_two]
  cases f with
  | inl v =>
    have l := v.isLt
    simp [feathot,fires,source,rawBank,show v.val≠10 by omega,show v.val≠11 by omega]
  | inr b => cases b <;> simp [feathot,fires,source]

theorem official_seven (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B]) :
    ∃ slot : Fin 16 → Fin 7,
    (∀ d (p : Fin 13), ∃ f, reads R A B d (source f) ∧ feathot H Q ⟨p.val,by omega⟩ f) ∧
    (∀ (n : Fin 16) f, reads R A B (slot n) (source f) → ¬feathot H Q ⟨13+n.val,by omega⟩ f) := by
  classical
  obtain ⟨hot,cold⟩ := physical c H Q R A B hh ht
  let nr (n : Fin 16) : Fin 29 := ⟨13+n.val,by omega⟩
  have hn (n : Fin 16) : accepts (rawRow (nr n))=false := by simpa [nr] using (row_extrema (nr n)).2
  choose slot quiet using fun n => cold ⟨_,(row_extrema (nr n)).1⟩ (hn n)
  refine ⟨slot,?_,?_⟩
  · intro d p
    let r : Fin 29 := ⟨p.val,by omega⟩
    have hp : accepts (rawRow r)=true := by simpa [r,p.isLt] using (row_extrema r).2
    obtain ⟨j,hj,v⟩ := hot d ⟨_,(row_extrema r).1⟩ hp
    have band := hj.1
    have id : ∃ f, source f=j := by
      by_cases k : j<10
      · exact ⟨.inl ⟨j,k⟩,rfl⟩
      · rcases (show j=10 ∨ j=11 by omega) with rfl|rfl
        · exact ⟨.inr false,rfl⟩
        · exact ⟨.inr true,rfl⟩
    obtain ⟨f,rfl⟩ := id
    exact ⟨f,hj,(feature_eq H Q R r f).mp v⟩
  · intro n f read h
    exact Bool.noConfusion ((quiet n _ read).symm.trans ((feature_eq H Q R (nr n) f).mpr h))
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.official_seven
