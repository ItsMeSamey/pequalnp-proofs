import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class020 : runPacket packets[20]! = true := by decide +kernel
theorem class021 : runPacket packets[21]! = true := by decide +kernel
theorem class022 : runPacket packets[22]! = true := by decide +kernel
theorem class023 : runPacket packets[23]! = true := by decide +kernel
end Research.Graph9822FirstBroad
