import H3FirstBroadFast9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822OneHidden (meets edges)
open Research.Graph9822.FourSaturation (witnesses)
theorem xval0 : high (fun i => if meets i 0 then stripe else 0) = x0 := by decide +kernel
theorem yval0 : high (fun _ => low32 (fun j => meets j 0)) = y0 := by decide +kernel
theorem xval1 : high (fun i => if meets i 1 then stripe else 0) = x1 := by decide +kernel
theorem yval1 : high (fun _ => low32 (fun j => meets j 1)) = y1 := by decide +kernel
theorem xval2 : high (fun i => if meets i 2 then stripe else 0) = x2 := by decide +kernel
theorem yval2 : high (fun _ => low32 (fun j => meets j 2)) = y2 := by decide +kernel
theorem xval3 : high (fun i => if meets i 3 then stripe else 0) = x3 := by decide +kernel
theorem yval3 : high (fun _ => low32 (fun j => meets j 3)) = y3 := by decide +kernel
theorem xval4 : high (fun i => if meets i 4 then stripe else 0) = x4 := by decide +kernel
theorem yval4 : high (fun _ => low32 (fun j => meets j 4)) = y4 := by decide +kernel
theorem xval5 : high (fun i => if meets i 5 then stripe else 0) = x5 := by decide +kernel
theorem yval5 : high (fun _ => low32 (fun j => meets j 5)) = y5 := by decide +kernel
theorem xval6 : high (fun i => if meets i 6 then stripe else 0) = x6 := by decide +kernel
theorem yval6 : high (fun _ => low32 (fun j => meets j 6)) = y6 := by decide +kernel
theorem xval8 : high (fun i => if meets i 8 then stripe else 0) = x8 := by decide +kernel
theorem yval8 : high (fun _ => low32 (fun j => meets j 8)) = y8 := by decide +kernel
theorem xval9 : high (fun i => if meets i 9 then stripe else 0) = x9 := by decide +kernel
theorem yval9 : high (fun _ => low32 (fun j => meets j 9)) = y9 := by decide +kernel
theorem xval10 : high (fun i => if meets i 10 then stripe else 0) = x10 := by decide +kernel
theorem yval10 : high (fun _ => low32 (fun j => meets j 10)) = y10 := by decide +kernel
theorem xval12 : high (fun i => if meets i 12 then stripe else 0) = x12 := by decide +kernel
theorem yval12 : high (fun _ => low32 (fun j => meets j 12)) = y12 := by decide +kernel
theorem xval16 : high (fun i => if meets i 16 then stripe else 0) = x16 := by decide +kernel
theorem yval16 : high (fun _ => low32 (fun j => meets j 16)) = y16 := by decide +kernel
theorem xval17 : high (fun i => if meets i 17 then stripe else 0) = x17 := by decide +kernel
theorem yval17 : high (fun _ => low32 (fun j => meets j 17)) = y17 := by decide +kernel
theorem xval18 : high (fun i => if meets i 18 then stripe else 0) = x18 := by decide +kernel
theorem yval18 : high (fun _ => low32 (fun j => meets j 18)) = y18 := by decide +kernel
theorem xval20 : high (fun i => if meets i 20 then stripe else 0) = x20 := by decide +kernel
theorem yval20 : high (fun _ => low32 (fun j => meets j 20)) = y20 := by decide +kernel
theorem xval24 : high (fun i => if meets i 24 then stripe else 0) = x24 := by decide +kernel
theorem yval24 : high (fun _ => low32 (fun j => meets j 24)) = y24 := by decide +kernel
theorem domain_value : domain = domain0 := by decide +kernel
theorem high_value : highData = highData0 := by
  change [(6,high (fun i => if meets i 0 then stripe else 0), high (fun _ => low32 (fun j => meets j 0))),
    (24,high (fun i => if meets i 0 then stripe else 0), high (fun _ => low32 (fun j => meets j 0))),
    (17,high (fun i => if meets i 0 then stripe else 0), high (fun _ => low32 (fun j => meets j 0))),
    (33,high (fun i => if meets i 1 then stripe else 0), high (fun _ => low32 (fun j => meets j 1))),
    (66,high (fun i => if meets i 2 then stripe else 0), high (fun _ => low32 (fun j => meets j 2))),
    (132,high (fun i => if meets i 4 then stripe else 0), high (fun _ => low32 (fun j => meets j 4))),
    (264,high (fun i => if meets i 8 then stripe else 0), high (fun _ => low32 (fun j => meets j 8))),
    (528,high (fun i => if meets i 16 then stripe else 0), high (fun _ => low32 (fun j => meets j 16))),
    (160,high (fun i => if meets i 5 then stripe else 0), high (fun _ => low32 (fun j => meets j 5))),
    (640,high (fun i => if meets i 20 then stripe else 0), high (fun _ => low32 (fun j => meets j 20))),
    (576,high (fun i => if meets i 18 then stripe else 0), high (fun _ => low32 (fun j => meets j 18))),
    (320,high (fun i => if meets i 10 then stripe else 0), high (fun _ => low32 (fun j => meets j 10))),
    (288,high (fun i => if meets i 9 then stripe else 0), high (fun _ => low32 (fun j => meets j 9))),
    (50,high (fun i => if meets i 1 then stripe else 0), high (fun _ => low32 (fun j => meets j 1))),
    (77,high (fun i => if meets i 2 then stripe else 0), high (fun _ => low32 (fun j => meets j 2))),
    (108,high (fun i => if meets i 3 then stripe else 0), high (fun _ => low32 (fun j => meets j 3))),
    (116,high (fun i => if meets i 3 then stripe else 0), high (fun _ => low32 (fun j => meets j 3))),
    (139,high (fun i => if meets i 4 then stripe else 0), high (fun _ => low32 (fun j => meets j 4))),
    (201,high (fun i => if meets i 6 then stripe else 0), high (fun _ => low32 (fun j => meets j 6))),
    (208,high (fun i => if meets i 6 then stripe else 0), high (fun _ => low32 (fun j => meets j 6))),
    (276,high (fun i => if meets i 8 then stripe else 0), high (fun _ => low32 (fun j => meets j 8))),
    (387,high (fun i => if meets i 12 then stripe else 0), high (fun _ => low32 (fun j => meets j 12))),
    (402,high (fun i => if meets i 12 then stripe else 0), high (fun _ => low32 (fun j => meets j 12))),
    (523,high (fun i => if meets i 16 then stripe else 0), high (fun _ => low32 (fun j => meets j 16))),
    (525,high (fun i => if meets i 16 then stripe else 0), high (fun _ => low32 (fun j => meets j 16))),
    (554,high (fun i => if meets i 17 then stripe else 0), high (fun _ => low32 (fun j => meets j 17))),
    (556,high (fun i => if meets i 17 then stripe else 0), high (fun _ => low32 (fun j => meets j 17))),
    (771,high (fun i => if meets i 24 then stripe else 0), high (fun _ => low32 (fun j => meets j 24))),
    (773,high (fun i => if meets i 24 then stripe else 0), high (fun _ => low32 (fun j => meets j 24)))] = _
  simp only [xval0,yval0,xval1,yval1,xval2,yval2,xval3,yval3,xval4,yval4,xval5,yval5,xval6,yval6,xval8,yval8,xval9,yval9,xval10,yval10,xval12,yval12,xval16,yval16,xval17,yval17,xval18,yval18,xval20,yval20,xval24,yval24]
  rfl
theorem fast_eq (a b : Nat) (ds rs : List Nat) : check a b ds rs = fastCheck a b ds rs := by
  simp only [check,fastCheck,words,fastWords,high_value,domain_value,geometry_value,extreme_value]
end Research.Graph9822FirstBroad
