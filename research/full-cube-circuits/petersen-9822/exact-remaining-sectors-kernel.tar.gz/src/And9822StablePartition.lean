import And9822Expose
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
def hiddenRun (ex : Nat → Bool) : List Product → Nat → Wire → Wire
  | [],_,w => w
  | p::ps,k,w => hiddenRun ex ps (k+1) (if ex k then w else Function.update w k (productBit w p))
def terminals (ex : Nat → Bool) : List Product → Nat → List Product
  | [],_ => []
  | p::ps,k => if ex k then p::terminals ex ps (k+1) else terminals ex ps (k+1)
theorem hidden_stale (ex : Nat → Bool) (ps : List Product) (k j : Nat) (lt : j<k) (w : Wire) :
    hiddenRun ex ps k w j = w j := by
  induction ps generalizing k w with
  | nil => rfl
  | cons p ps ih =>
    rw [hiddenRun,ih (k+1) (by omega)]
    cases h : ex k <;> simp [h,Function.update_of_ne (Nat.ne_of_lt lt)]
theorem read_below {a : Arm} {v w : Wire} (same : ∀ j ∈ a, v j=w j) : readArm v a=readArm w a := by
  apply Bool.eq_iff_iff.mpr
  simp only [readArm,List.any_eq_true]
  exact ⟨fun ⟨j,h,b⟩ => ⟨j,h,(same j h) ▸ b⟩,fun ⟨j,h,b⟩ => ⟨j,h,(same j h).symm ▸ b⟩⟩
theorem stable_partition (ex : Nat → Bool) (ps : List Product) (k : Nat) (out : Arm)
    (ord : Chronological k ps out) (w : Wire) (seen : Bool)
    (zero : ∀ j, ex j=true → w j=false) :
    collect true ex ps k w seen = (seen || (terminals ex ps k).any (productBit (hiddenRun ex ps k w))) := by
  induction ps generalizing k w seen with
  | nil => simp [collect,terminals]
  | cons p ps ih =>
    obtain ⟨left,right,tail⟩ := ord
    cases e : ex k
    · let z := Function.update w k (productBit w p)
      have zeros : ∀ j, ex j=true → z j=false := by
        intro j ej
        have ne : j ≠ k := fun h => by subst j; simp [e] at ej
        simpa [z,ne] using zero j ej
      simpa [collect,terminals,hiddenRun,e,z] using ih (k+1) tail z seen zeros
    · have unchanged : Function.update w k false=w := by
        funext j
        by_cases h : j=k <;> simp [h,zero k e]
      have bit : productBit (hiddenRun ex ps (k+1) w) p = productBit w p := by
        unfold productBit
        have sl (a : Arm) (ha : ∀ j ∈ a, j<k) :
            readArm (hiddenRun ex ps (k+1) w) a = readArm w a :=
          read_below (fun j h => hidden_stale ex ps (k+1) j (by have := ha j h; omega) w)
        rw [sl p.1 left,sl p.2 right]
      simp only [collect,e,Bool.true_and,ite_true,unchanged,terminals,hiddenRun,List.any_cons]
      rw [ih (k+1) tail w _ zero,bit,Bool.or_assoc]
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.stable_partition
