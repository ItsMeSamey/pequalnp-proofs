import H3FirstBroadStatic9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822H2Check Research.Graph9822OneHidden
open Research.Graph9822FirstAdmission (roots)
def fastWords (a b : Nat) : Array Nat := (highData0.map fun (r,x,y) =>
  (if meets a r then full else x) &&& (if meets b r then full else y)).toArray

def fastCheck (a b : Nat) (drops ids : List Nat) : Bool := Id.run do
  let ws := fastWords a b
  let hot := sums ((List.range 16).map fun i => ws[13+i]!)
  let nonstar := prods ((extremes0).map fun es => sums (es.map (fun i => ws[i]!)))
  let pairs := geometry0.map fun (p,es,i,j) =>
    (p, prods (es.map fun k => ws[k]!) &&& (full ^^^ (ws[13+i]! ||| ws[13+j]!)))
  let cuts := prods (drops.map fun o =>
    let excluded := pairs[o]!.1
    sums ((pairs.filter fun z => z.1 &&& excluded == 0).map Prod.snd))
  let allowed := sums (ids.map fun i =>
    let h := roots[i]!
    prods ((List.range 29).map fun j => if h.testBit j then ws[j]! else full ^^^ ws[j]!))
  return sub (domain0 &&& hot &&& nonstar &&& cuts) allowed
end Research.Graph9822FirstBroad
