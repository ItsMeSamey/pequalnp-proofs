import H3FirstBroadLogic9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822H2Check Research.Graph9822OneHidden
open Research.Graph9822FirstAdmission

def liveWord (ws : Array Nat) (z : Nat × List Nat × Nat × Nat) :=
  (z.1, prods (z.2.1.map fun j => ws[j]!) &&&
    (full ^^^ (ws[13+z.2.2.1]! ||| ws[13+z.2.2.2]!)))

def pairWord (ws : Array Nat) (p : Pair) :=
  liveWord ws (bit p.1.val ||| bit p.2.val,
    selected (cell p.1.val p.2.val).testBit 13,p.1.val,p.2.val)

def certifiedCuts (ws : Array Nat) (drops : List Nat) := prods (drops.map fun o =>
  let ps := geom.map (liveWord ws)
  sums ((ps.filter (fun z => z.1 &&& ps[o]!.1 == 0)).map Prod.snd))

def leakingWord (ws : Array Nat) := sums ((List.range 16).map fun i => ws[13+i]!)
def nonstarWord (ws : Array Nat) := prods ((far 13).map fun es => sums (es.map (fun i => ws[i]!)))
def outputWord (ws : Array Nat) (ids : List Nat) := sums (ids.map fun i => matchWord ws roots[i]!)

theorem check_unfold (a b : Nat) (drops ids : List Nat) :
    check a b drops ids = sub (domain &&& leakingWord (words a b) &&& nonstarWord (words a b) &&&
      certifiedCuts (words a b) drops) (outputWord (words a b) ids) := rfl

theorem identified {a b h : Nat} {k : Fin 1024} {drops ids : List Nat}
    (verified : check a b drops ids = true)
    (valid : domain.testBit k.val = true)
    (leak : (leakingWord (words a b)).testBit k.val = true)
    (star : (nonstarWord (words a b)).testBit k.val = true)
    (cuts : (certifiedCuts (words a b) drops).testBit k.val = true)
    (hbd : h < 2^29)
    (agrees : ∀ i < 29, ((words a b)[i]!).testBit k.val = h.testBit i)
    (safe : ∀ i ∈ ids, roots[i]! < 2^29 ∧ i < roots.size) :
    ∃ i ∈ ids, roots[i]? = some h := by
  rw [check_unfold] at verified
  have good := (subset_bits ..).1 verified k.val
    (by simp [Nat.testBit_and,valid,leak,star,cuts])
  obtain ⟨m,hm,hit⟩ := (sums_on _ _).1 good
  obtain ⟨i,hi,e⟩ := List.mem_map.mp hm
  subst m
  have eq := matchWord_exact hbd (safe i hi).1 agrees hit
  refine ⟨i,hi,?_⟩
  rw [eq]
  simp [Array.getElem?_eq_getElem,(safe i hi).2]

theorem comp_hits_pair {ws : Array Nat} {h : Nat} {p : Pair} {k : Fin 1024}
    (yes : compatible h p.1.val p.2.val = true)
    (pos : ∀ i < 13, (ws[i]!).testBit k.val = (positive h).testBit i)
    (neg : ∀ i < 16, (ws[13+i]!).testBit k.val = (negative h).testBit i) :
    (pairWord ws p).2.testBit k.val = true := by
  simp only [compatible,Bool.and_eq_true,Bool.not_eq_true'] at yes
  have pp := yes.1.1
  have on : (prods ((selected (cell p.1.val p.2.val).testBit 13).map fun j => ws[j]!)).testBit k.val=true := by
    apply prods_of_all
    intro x hx
    obtain ⟨mem,live⟩ := List.mem_filter.mp hx
    rw [pos x (List.mem_range.mp mem)]
    exact (subset_bits ..).1 pp x live
  simp [pairWord,liveWord,on,Nat.testBit_and,Nat.testBit_xor,Nat.testBit_or,full_on,
    neg p.1.val p.1.isLt,neg p.2.val p.2.isLt,yes.1.2,yes.2]

end Research.Graph9822FirstBroad
