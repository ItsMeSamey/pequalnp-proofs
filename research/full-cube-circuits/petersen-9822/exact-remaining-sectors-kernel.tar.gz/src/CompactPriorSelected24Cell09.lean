import CompactPriorSelected24Cell08
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row8_95_seg98 : CutRow book 8 98 3 := bandCut 9 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
