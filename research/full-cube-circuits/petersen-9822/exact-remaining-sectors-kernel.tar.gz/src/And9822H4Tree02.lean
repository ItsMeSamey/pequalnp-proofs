import And9822H4Tree01
namespace Research.Graph9822.H4Tree
theorem t100 {p : Bad} (legal : Respects p) (ok : Within p 51422017416474762454168835234569415274413367452138062915567616) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t101 {p : Bad} (legal : Respects p) (ok : Within p 51422017416498149334861515093180436348308766879442830601748480) : Success p :=
  fork legal ok 16 (by decide +kernel) (by decide +kernel) (t99 legal) (t100 legal)
theorem t102 {p : Bad} (legal : Respects p) (ok : Within p 51422017416544917387256103989159102692223101750337068607766528) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t98 legal) (t101 legal)
theorem t103 {p : Bad} (legal : Respects p) (ok : Within p 51422017416545191418813103530697858177032604264060409492832256) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t104 {p : Bad} (legal : Respects p) (ok : Within p 51422017416545191418813103533456265883129236053403254095118336) : Success p :=
  fork legal ok 9 (by decide +kernel) (by decide +kernel) (t102 legal) (t103 legal)
theorem t105 {p : Bad} (legal : Respects p) (ok : Within p 51622884672077565203255848794998911208444511427626103199531008) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t97 legal) (t104 legal)
theorem t106 {p : Bad} (legal : Respects p) (ok : Within p 51422017416287688817342786957675610986849628888738042205962240) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t107 {p : Bad} (legal : Respects p) (ok : Within p 51622884672077565203255848794998911208487012725971930073563136) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t105 legal) (t106 legal)
theorem t108 {p : Bad} (legal : Respects p) (ok : Within p 251084069415467230553431576928306656644094217778561380515840) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t109 {p : Bad} (legal : Respects p) (ok : Within p 51673101485960658649366535110384572539815831569527642349666304) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t107 legal) (t108 legal)
theorem t110 {p : Bad} (legal : Respects p) (ok : Within p 4981608370848688787609915249398962519607063843079936601707544576) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t111 {p : Bad} (legal : Respects p) (ok : Within p 5033281472334649167945981706844411878075014277842086935106977792) : Success p :=
  fork legal ok 14 (by decide +kernel) (by decide +kernel) (t109 legal) (t110 legal)
theorem t112 {p : Bad} (legal : Respects p) (ok : Within p 5033283826247799937985241937443507241661575252442126297162088448) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t96 legal) (t111 legal)
theorem t113 {p : Bad} (legal : Respects p) (ok : Within p 5176314793386164740980181163171485749087844060628665212753714170085476) : Success p :=
  fork legal ok 15 (by decide +kernel) (by decide +kernel) (t77 legal) (t112 legal)
theorem t114 {p : Bad} (legal : Respects p) (ok : Within p 916625350198849671744791449165859743554487293112471497692993851497046500) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t60 legal) (t113 legal)
theorem t115 {p : Bad} (legal : Respects p) (ok : Within p 6582018278372595352429975189252407966552334338518924245950540680) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t116 {p : Bad} (legal : Respects p) (ok : Within p 883423532389192164791648750371459263230653931616309712631309633679524096) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t117 {p : Bad} (legal : Respects p) (ok : Within p 883423532389192164791648750371459257913741948437809479061929000553154560) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t118 {p : Bad} (legal : Respects p) (ok : Within p 6582018278372571961980379224520205234596642910590991754250431112) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t119 {p : Bad} (legal : Respects p) (ok : Within p 883423538971210443164220712351838482433947183034452389651794854896741000) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t117 legal) (t118 legal)
theorem t120 {p : Bad} (legal : Respects p) (ok : Within p 883423538971210443164220712351838487750859166212952623222301387929955208) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t116 legal) (t119 legal)
theorem t121 {p : Bad} (legal : Respects p) (ok : Within p 883423532389192164791648750371459305765960097600194657806012484029524480) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t122 {p : Bad} (legal : Respects p) (ok : Within p 883423538971210443164220712351838530286165330997734271060991280781732744) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t120 legal) (t121 legal)
theorem t123 {p : Bad} (legal : Respects p) (ok : Within p 883423538971210443164244102801434452483061899425775787827990930072284040) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t115 legal) (t122 legal)
theorem t124 {p : Bad} (legal : Respects p) (ok : Within p 51422017416287688817342787619531518085818489310303275045617764) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t125 {p : Bad} (legal : Respects p) (ok : Within p 51422017416311072843540082066222777043141949838617769966305280) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t126 {p : Bad} (legal : Respects p) (ok : Within p 51422017416311072843540082066222777043141949838617769966305380) : Success p :=
  fork legal ok 15 (by decide +kernel) (by decide +kernel) (t124 legal) (t125 legal)
theorem t127 {p : Bad} (legal : Respects p) (ok : Within p 6422614617841433779567394856031982018038337538) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t128 {p : Bad} (legal : Respects p) (ok : Within p 51422017416311079266154699243042241805428812361345883688669286) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t126 legal) (t127 legal)
theorem t129 {p : Bad} (legal : Respects p) (ok : Within p 51422066456168386975382176618938922915518039988451180256711799) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t130 {p : Bad} (legal : Respects p) (ok : Within p 51422066456168386975382177283553237720626033497705084572685431) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t128 legal) (t129 legal)
theorem t131 {p : Bad} (legal : Respects p) (ok : Within p 51422017416287688817342787619551802984033719601161468985234496) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t132 {p : Bad} (legal : Respects p) (ok : Within p 51422066456168386975382177283553237733357533547378781462746231) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t130 legal) (t131 legal)
theorem t133 {p : Bad} (legal : Respects p) (ok : Within p 49039857307708443467467104868809893875799678298154336304) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t134 {p : Bad} (legal : Respects p) (ok : Within p 51422066456168386975382177283553237733357533547405169741812855) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t132 legal) (t133 legal)
theorem t135 {p : Bad} (legal : Respects p) (ok : Within p 883423539022632460580531791618777240102613699921197928808718152369209343) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t123 legal) (t134 legal)
theorem t136 {p : Bad} (legal : Respects p) (ok : Within p 14234851840255538003192894626577061183856308563536991278994086325911552) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t137 {p : Bad} (legal : Respects p) (ok : Within p 14234851840255537811630952018341294171429861011732120984301327014166528) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t138 {p : Bad} (legal : Respects p) (ok : Within p 431359146674410236738056267589948819836384110067887345661783645880320) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t139 {p : Bad} (legal : Respects p) (ok : Within p 14234851840255537811654336044538588618121119969055581512615821934854144) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t137 legal) (t138 legal)
theorem t140 {p : Bad} (legal : Respects p) (ok : Within p 14234851840255538003216278652774695912914498362844229464958212207804416) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t136 legal) (t139 legal)
theorem t141 {p : Bad} (legal : Respects p) (ok : Within p 14234851840255538003146126574182855108136586608181780801840656416768000) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t142 {p : Bad} (legal : Respects p) (ok : Within p 14234851840255538003216278652774738448210363480152162386784141178830848) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t140 legal) (t141 legal)
theorem t143 {p : Bad} (legal : Respects p) (ok : Within p 14234851840255538003146144414778631114974849704782256186685318655641600) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t144 {p : Bad} (legal : Respects p) (ok : Within p 14234851840255538003216296493370897272711412632524034068062164156942336) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t142 legal) (t143 legal)
theorem t145 {p : Bad} (legal : Respects p) (ok : Within p 49470941848498340941010922222423146894133287677570583048) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t146 {p : Bad} (legal : Respects p) (ok : Within p 14234851840255587474087975072523413301396022975557278638694973248113160) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t144 legal) (t145 legal)
theorem t147 {p : Bad} (legal : Respects p) (ok : Within p 1294077440023230901705959332413522772297006271536055570679613773318144) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t148 {p : Bad} (legal : Respects p) (ok : Within p 1294077440073447524027110170287718975223957947375133604017345449166848) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t149 {p : Bad} (legal : Respects p) (ok : Within p 1294077440073447715589052778524209087682667602864874414252918235465728) : Success p :=
  fork legal ok 17 (by decide +kernel) (by decide +kernel) (t147 legal) (t148 legal)
end Research.Graph9822.H4Tree
