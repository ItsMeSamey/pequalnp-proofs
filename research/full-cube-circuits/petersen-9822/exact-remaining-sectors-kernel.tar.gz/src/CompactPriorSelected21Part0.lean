import CompactPriorSelected21Part0Cell03
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row9_0 : CutRow book 9 0 12 := (joinRow (joinRow (joinRow row9_0_seg0 row9_0_seg3) row9_0_seg6) row9_0_seg9)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
