import And9822H4Geo
namespace Research.Graph9822.H4Geo
open Research.Graph9822.H4Tree
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
theorem negative0 : negSiteP 0 := by unfold negSiteP; decide +kernel
private theorem row0 : ∀ k : Fin 10, 0≠k → let p := pairNumber 0 0 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 0 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 0)) := by decide +kernel
private theorem row1 : ∀ k : Fin 10, 1≠k → let p := pairNumber 0 1 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 1 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 1)) := by decide +kernel
private theorem row2 : ∀ k : Fin 10, 2≠k → let p := pairNumber 0 2 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 2 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 2)) := by decide +kernel
private theorem row3 : ∀ k : Fin 10, 3≠k → let p := pairNumber 0 3 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 3 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 3)) := by decide +kernel
private theorem row4 : ∀ k : Fin 10, 4≠k → let p := pairNumber 0 4 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 4 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 4)) := by decide +kernel
private theorem row5 : ∀ k : Fin 10, 5≠k → let p := pairNumber 0 5 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 5 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 5)) := by decide +kernel
private theorem row6 : ∀ k : Fin 10, 6≠k → let p := pairNumber 0 6 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 6 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 6)) := by decide +kernel
private theorem row7 : ∀ k : Fin 10, 7≠k → let p := pairNumber 0 7 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 7 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 7)) := by decide +kernel
private theorem row8 : ∀ k : Fin 10, 8≠k → let p := pairNumber 0 8 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 8 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 8)) := by decide +kernel
private theorem row9 : ∀ k : Fin 10, 9≠k → let p := pairNumber 0 9 k
  (choices[0]!).testBit (first p).val=true ∧ (choices[0]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 0 9 ∧ sideR (first p)=nm 0 k) ∨
   (sideL (first p)=nm 0 k ∧ sideR (first p)=nm 0 9)) := by decide +kernel
theorem selected0 : selectedPairP 0 := Fin.cases row0 (Fin.cases row1 (Fin.cases row2 (Fin.cases row3 (Fin.cases row4 (Fin.cases row5 (Fin.cases row6 (Fin.cases row7 (Fin.cases row8 (Fin.cases row9 (fun h=>Fin.elim0 h))))))))))
end Research.Graph9822.H4Geo
