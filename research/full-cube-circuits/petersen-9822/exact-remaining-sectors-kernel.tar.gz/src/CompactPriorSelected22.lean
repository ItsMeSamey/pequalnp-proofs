import CompactPriorSelected22Cell11
-- CompactPriorFace52
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_4 : CutRow book 8 4 12 := (joinRow (joinRow (joinRow row8_4_seg4 row8_4_seg7) row8_4_seg10) row8_4_seg13)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace53
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_16 : CutRow book 8 16 12 := (joinRow (joinRow (joinRow row8_16_seg16 row8_16_seg19) row8_16_seg22) row8_16_seg25)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace54
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_28 : CutRow book 8 28 12 := (joinRow (joinRow (joinRow row8_28_seg28 row8_28_seg31) row8_28_seg34) row8_28_seg37)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
