import CompactPriorSelected24Cell05
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row8_83_seg89 : CutRow book 8 89 3 := bandCut 9 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
