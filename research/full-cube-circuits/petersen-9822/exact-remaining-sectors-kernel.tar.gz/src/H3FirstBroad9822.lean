import H3FirstAdmission9822

namespace Research.Graph9822FirstBroad
open Research.Graph9822H2Check Research.Graph9822OneHidden
open Research.Graph9822FirstAdmission (roots rowPairs cell)
open Research.Graph9822.FourSaturation (witnesses)

def full : Nat := 2^1024-1
def stripe : Nat := 2^32-1
def low32 (p : Nat → Bool) := (List.range 32).foldr (fun i z => (z <<< 1) ||| (if p i then 1 else 0)) 0
def high (f : Nat → Nat) := (List.range 32).foldr (fun i z => (z <<< 32) ||| f i) 0
def domain := high (fun i => low32 (fun j => i &&& j == 0))
def rawRows := edges ++ witnesses
def sums (xs : List Nat) := xs.foldr (· ||| ·) 0
def prods (xs : List Nat) := xs.foldr (· &&& ·) full
def selected (p : Nat → Bool) (n : Nat) := (List.range n).filter p
def geom := rowPairs.map fun p => (bit p.1.val ||| bit p.2.val,
  selected (cell p.1.val p.2.val).testBit 13,p.1.val,p.2.val)
def far (m : Nat) := vs.map fun v => selected (fun e => !(edges[e]!).testBit v) m
def highData := rawRows.map fun r =>
  (r,high (fun i => if meets i (r >>> 5) then stripe else 0),
   high (fun _ => low32 (fun j => meets j (r >>> 5))))
def words (a b : Nat) : Array Nat := (highData.map fun (r,x,y) =>
  (if meets a r then full else x) &&& (if meets b r then full else y)).toArray

def check (a b : Nat) (drops ids : List Nat) : Bool := Id.run do
  let ws := words a b
  let hot := sums ((List.range 16).map fun i => ws[13+i]!)
  let nonstar := prods ((far 13).map fun es => sums (es.map (fun i => ws[i]!)))
  let pairs := geom.map fun (p,es,i,j) =>
    (p, prods (es.map fun k => ws[k]!) &&& (full ^^^ (ws[13+i]! ||| ws[13+j]!)))
  let cuts := prods (drops.map fun o =>
    let excluded := pairs[o]!.1
    sums ((pairs.filter fun z => z.1 &&& excluded == 0).map Prod.snd))
  let allowed := sums (ids.map fun i =>
    let h := roots[i]!
    prods ((List.range 29).map fun j => if h.testBit j then ws[j]! else full ^^^ ws[j]!))
  return sub (domain &&& hot &&& nonstar &&& cuts) allowed
end Research.Graph9822FirstBroad
