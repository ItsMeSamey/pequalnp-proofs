import CompactPriorSelected30
-- CompactPriorFace79
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h743_10 : Face true 743 10 := carry_of (swaps:=[100,82,16]) (by decide +kernel) h695_10
theorem h582_4 : Face true 582 4 := carry_of (swaps:=[146,130,50,115,98,83,32,64,16]) (by decide +kernel) h29_4
theorem h627_7 : Face true 627 7 := carry_of (swaps:=[147,131,115,98]) (by decide +kernel) h63_7
theorem h633_7 : Face true 633 7 := carry_of (swaps:=[151,135,84,66,98,16,48]) (by decide +kernel) h190_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace80
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h639_11 : Face true 639 11 := carry_of (swaps:=[151,135,101,66,16]) (by decide +kernel) h255_11
theorem h706_4 : Face true 706 4 := carry_of (swaps:=[147,50,67,130,116,99,82,16]) (by decide +kernel) h29_4
theorem h739_7 : Face true 739 7 := carry_of (swaps:=[148,32,132,115,98,80,16]) (by decide +kernel) h63_7
theorem h755_10 : Face true 755 10 := carry_of (swaps:=[151,84,98,50]) (by decide +kernel) h695_10
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace81
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h594_4 : Face true 594 4 := carry_of (swaps:=[147,131,67,116,66,99,82,16]) (by decide +kernel) h29_4

end PEqualNP.Outside.L_meta_9825.Engine
