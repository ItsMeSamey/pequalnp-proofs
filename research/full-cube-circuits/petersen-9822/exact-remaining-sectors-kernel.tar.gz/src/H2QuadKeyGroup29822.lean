import H2QuadPairList9822
import H2PairDom01099822
import H2ShortDomTransport9822
import H2ShortDom01109822
import H2PairDom01119822
import H2ShortDom01129822
import H2ShortDom02049822
import H2ShortDom02059822
import H2PairDom02069822
namespace Research.Graph9822H2Check
def keys2 : List (Nat × Nat) := [(1,9), (1,10), (1,11), (1,12), (2,4), (2,5), (2,6)]
theorem paidKeys2 : keys2.all (fun p => pairDom p.1 p.2)=true := by
  simp only [keys2,List.all_cons,List.all_nil,Bool.and_eq_true_iff]
  exact ⟨dom1_9, dom_of_short (by decide) short_dom_1_10, dom1_11, dom_of_short (by decide) short_dom_1_12, dom_of_short (by decide) short_dom_2_4, dom_of_short (by decide) short_dom_2_5, dom2_6, True.intro⟩
end Research.Graph9822H2Check
