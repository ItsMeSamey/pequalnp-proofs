import And9822FourPhysical
import And9822FirstSwitchModes

namespace Research.Graph9822Resolution
open PEqualNP.Outside.L_meta_9822.Sectors
open FirstSwitchRows

theorem lower_five_physical (gs : List Gate) (out : Nat)
    (computes : ∀ x : Fin 10 → Bool, (asCircuit gs out).eval (List.ofFn x) = edge x) :
    5 ≤ gs.countP Gate.isAnd := by
  have lower := lower_four_physical gs out computes
  by_contra hn
  have exactly : gs.countP Gate.isAnd = 4 := by omega
  have evalOn (xs : List Nat) (hb : ∀ j ∈ xs, j < 10) :
      eval gs 10 (inputSet xs) out = onSet xs := by
    let x : Fin 10 → Bool := fun i => decide (i.val ∈ xs)
    have hw : wiresFrom (List.ofFn x) = inputSet xs := by
      funext j
      rw [inputSet_apply]
      by_cases hj : j < 10
      · unfold wiresFrom
        rw [List.getD_eq_getElem?_getD,List.getElem?_ofFn,dif_pos hj]
        rfl
      · have no : j ∉ xs := fun hm => hj (hb j hm)
        simp [wiresFrom,List.getD_eq_getElem?_getD,List.getElem?_ofFn,hj,no]
    have h := computes x
    rw [physical_eval,List.length_ofFn,hw] at h
    exact h
  have bounded : ∀ u : Fin 16, (independentSets u).all (· < 10) = true := by decide +kernel
  have small (u : Fin 16) : ∀ j ∈ independentSets u, j < 10 := by
    simpa using List.all_eq_true.mp (bounded u)
  choose sel obs using fun r => maximal_witness gs 10 (independentSets r) out
    ((evalOn _ (small r)).trans (reject_sets r))
    (fun a ha hm => (evalOn _ (by simpa using And.intro ha (small r))).trans
      (maximal_sets r ⟨a,ha⟩ hm))
  apply switch_impossible gs 10 out (fun v j => decide (j = v.val)) exactly sel
  intro r v
  have hh := obs r v.val v.isLt
  cases e : resolve gs 10 (sel r) (fun j => decide (j = v.val)) out <;>
    by_cases h : v.val ∈ independentSets r <;> simp_all [has]
end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.lower_five_physical
