import H2UnsortedRescue9822
import H2LocalTableProof9822
namespace Research.Graph9822H2Check

def fastPairChecks (s : Nat) (cs : List Nat) (bad : Nat → Bool)
    (basis : Nat → Nat → List Nat) (q : List Nat) :=
  q.all fun i => q.all fun j =>
    !(decide (i < j)) || (basis i j).all (fun r =>
      bad (s ||| r) || cs.any (fun c => sub c (s ||| r)))

theorem basisChild {h s q : Nat} {quad cs : List Nat} {bad : Nat → Bool}
    {basis : Nat → Nat → List Nat}
    (covered : ∀ i ∈ quad, ∀ j ∈ quad, i < j → pairCovered h i j (basis i j) = true)
    (checked : fastPairChecks s cs bad basis quad = true)
    (reject : ∀ t, bad t = true → ¬holds q t)
    (resolved : ∃ i ∈ quad, ∃ j ∈ quad, i < j ∧ ∃ r ∈ rescue h i j, holds q r)
    (parent : holds q s) : ∃ c ∈ cs, holds q c := by
  obtain ⟨i,hi,j,hj,lt,r,hr,live⟩ := resolved
  obtain ⟨w,hw,carried⟩ := coveredRescue (covered i hi j hj lt) hr live
  have pairOk := List.all_eq_true.mp (List.all_eq_true.mp checked i hi) j hj
  have all : (basis i j).all (fun x => bad (s ||| x) || cs.any (fun c => sub c (s ||| x))) = true := by
    simpa [lt] using pairOk
  have join := join_subset parent carried
  rcases Bool.or_eq_true_iff.mp (List.all_eq_true.mp all w hw) with no | yes
  · exact False.elim (reject _ no join)
  · obtain ⟨c,hc,small⟩ := List.any_eq_true.mp yes
    exact ⟨c,hc,weaker_holds small join⟩

end Research.Graph9822H2Check
