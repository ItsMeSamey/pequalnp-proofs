import CompactSeal9822
import Not9822Bundle03Sockets
namespace PEqualNP.Outside.L_meta_9822.Compact
open Petersen9822 Petersen9822.DagCut Petersen9822.FirstSite
def Site.asGate (s : Site) : Petersen9822.DagCut.Gate := ⟨s.left.wire,s.right.wire,s.op⟩

def Net.indexed {n k} (net : Net n k) : Indexed where
  get w := (net.get w).map Site.asGate
  back := by
    intro w g hg
    obtain ⟨s,hs,eq⟩ := Option.map_eq_some_iff.mp hg
    subst g
    exact (net.get_spec hs).2.2

theorem Net.indexed_edge {n k} (net : Net n k) (a b : Nat) :
    net.indexed.edge a b ↔ net.Edge a b := by
  constructor
  · rintro ⟨g,hg,h⟩
    obtain ⟨s,hs,eq⟩ := Option.map_eq_some_iff.mp hg
    subst g
    exact ⟨s,hs,h⟩
  · rintro ⟨s,hs,h⟩
    exact ⟨s.asGate,Option.map_eq_some_iff.mpr ⟨s,hs,rfl⟩,h⟩

theorem Net.indexed_eval {n k} (net : Net n k) (env : Nat → Bool) (w : Nat) (hw : w < n+k) :
    (net.indexed.tree w).term.eval env = net.eval env w := by
  induction w using Nat.strong_induction_on with
  | ind w ih =>
    by_cases raw : w < n
    · have absent : net.get w = none := by
        cases eq : net.get w with
        | none => rfl
        | some g => have := (net.get_spec eq).1; omega
      have no : net.indexed.get w = none := by simp [indexed,absent]
      rw [net.indexed.tree_none no,net.eval_raw env raw]; rfl
    · obtain ⟨s,hs⟩ := net.present (by omega : n ≤ w) hw
      have yes : net.indexed.get w = some s.asGate := Option.map_eq_some_iff.mpr ⟨s,hs,rfl⟩
      have bd := (net.get_spec hs).2.2
      rw [net.indexed.tree_some yes,net.eval_gate env hs]
      simp only [Tree.term,Term.eval,Site.asGate]
      rw [ih _ bd.1 (by omega),ih _ bd.2 (by omega)]

theorem Route.asPath {n k} {net : Net n k} {w o} (h : Route net w o) :
    ∃ xs, Path net.indexed.edge o w xs := by
  induction h with
  | done => exact ⟨[],.stop⟩
  | step e tail ih =>
    obtain ⟨xs,hx⟩ := ih
    have lt := Net.edge_lt e
    have le := tail.le
    exact ⟨_ , .step (by omega) ((net.indexed_edge _ _).mpr e) hx⟩

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.Net.indexed_eval
