import H2PairBasis9822
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden

structure SymPattern where
  hp : Nat
  hf : Nat
  qt : Nat
  qf : Nat
  shared : Bool
  deriving DecidableEq

def SymPattern.project (p : SymPattern) (h : Nat) : Option Nat := do
  guard (sub p.hp (positive h) && (p.hf &&& negative h == 0))
  return demand p.qt (p.qf ||| (if p.shared then negative h else 0))

def SymPattern.below (c p : SymPattern) : Bool :=
  sub c.hp p.hp && sub c.hf p.hf && sub c.qt p.qt && sub c.qf p.qf && (!c.shared || p.shared)

private theorem subDemand {t u f g : Nat} (pos : sub t u=true) (neg : sub f g=true) :
    sub (demand t f) (demand u g)=true := by
  apply (subset_bits ..).2
  intro k hk
  simp only [demand,Nat.testBit_or,Bool.or_eq_true,Nat.testBit_shiftLeft,Bool.and_eq_true] at hk ⊢
  rcases hk with a | ⟨hi,bit⟩
  · exact Or.inl ((subset_bits ..).1 pos k a)
  · exact Or.inr ⟨hi,(subset_bits ..).1 neg _ bit⟩

theorem weakerProjection {c p : SymPattern} {h r : Nat} (small : c.below p = true)
    (read : p.project h = some r) : ∃ t, c.project h = some t ∧ sub t r = true := by
  simp only [SymPattern.below,Bool.and_eq_true] at small
  obtain ⟨⟨⟨⟨hp,hf⟩,qt⟩,qf⟩,share⟩ := small
  by_cases allow : sub p.hp (positive h) && (p.hf &&& negative h == 0)
  · obtain ⟨ph,pn⟩ := Bool.and_eq_true_iff.mp allow
    have ch := sub_trans hp ph
    have cn : c.hf &&& negative h = 0 := by
      apply Nat.eq_of_testBit_eq
      intro k
      have eq := congrArg (fun x : Nat => x.testBit k) (beq_iff_eq.mp pn)
      simp only [Nat.testBit_and,Nat.zero_testBit] at eq ⊢
      cases e : c.hf.testBit k with
      | false => simp
      | true =>
        have yes := (subset_bits ..).1 hf k e
        simpa [yes] using eq
    simp [SymPattern.project,allow] at read
    subst r
    refine ⟨demand c.qt (c.qf ||| (if c.shared then negative h else 0)),
      by simp [SymPattern.project,ch,cn],subDemand qt ?_⟩
    apply (subset_bits ..).2
    intro k bit
    rw [Nat.testBit_or,Bool.or_eq_true] at bit ⊢
    rcases bit with base | extra
    · exact Or.inl ((subset_bits ..).1 qf k base)
    · right
      cases ec : c.shared with
      | false => simp [ec] at extra
      | true =>
        have ep : p.shared = true := by simpa [ec] using share
        simpa [ep] using (show (negative h).testBit k=true by simpa [ec] using extra)
  · simp [SymPattern.project,allow] at read

def projectedBasis (h : Nat) (ps : List SymPattern) := ps.filterMap (fun p => p.project h)

theorem projectedDominance {h q r : Nat} {p : SymPattern} {cs : List SymPattern}
    (weak : ∃ c ∈ cs, c.below p=true) (read : p.project h=some r) (live : holds q r) :
    ∃ w ∈ projectedBasis h cs, holds q w := by
  obtain ⟨c,mem,small⟩ := weak
  obtain ⟨w,out,le⟩ := weakerProjection small read
  exact ⟨w,List.mem_filterMap.mpr ⟨c,mem,out⟩,weaker_holds le live⟩

end Research.Graph9822H2Check
