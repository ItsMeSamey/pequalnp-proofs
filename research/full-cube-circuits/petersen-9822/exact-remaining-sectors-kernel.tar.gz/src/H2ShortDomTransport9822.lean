import H2ShortDomCheck9822
import OR9822CanonicalShort
import OR9822ShortWordsAll
namespace Research.Graph9822H2Check
open Research.Graph9822ProfileArithmetic.Laws (allWords)
theorem dom_of_short {i j : Nat} (bound : 13*i+j<169) (paid : shortDominated i j=true) :
    pairDom i j=true := by
  simpa only [pairDom, canonical_short (allWords _ bound),List.any_map,Function.comp_def,shortDominated] using paid
end Research.Graph9822H2Check
