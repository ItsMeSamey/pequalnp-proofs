import And9822H4Tape
import And9822CollectorShape
import H3DemandPhysical9822
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822.ReverseChannel Research.Graph9822Resolution
open Research.Graph9822.FourSaturation
/-- The true side is the only one allowed to read the last intermediate. -/
def side (p : Product) (b : Bool) : List Nat :=
  arm p (if 12 ∈ p.1 then !b else b)

def code : Bool → Bool → Bool → Fin 7
  | false,false,_ => 0
  | false,true,false => 1
  | false,true,true => 2
  | true,false,false => 3
  | true,false,true => 4
  | true,true,false => 5
  | true,true,true => 6

def sides (d : Fin 7) : Bool × Bool × Bool :=
  (decide (3 ≤ d.val), decide (d.val = 1 ∨ d.val = 2 ∨ 5 ≤ d.val),
   decide (d.val = 2 ∨ d.val = 4 ∨ d.val = 6))

def reads (R A B : Product) (d : Fin 7) (j : Nat) : Prop :=
  j<12 ∧ (j∈side A (sides d).1 ∨ j∈side B (sides d).2.1 ∨
    (12∈side A (sides d).1 ∨ 12∈side B (sides d).2.1) ∧ j∈arm R (sides d).2.2)

private theorem no_last (p : Product) (dis : Apart p) : 12 ∉ side p false := by
  by_cases l : 12 ∈ p.1 <;> simp [side,arm,l,dis 12] at *

private theorem cold_side (p : Product) (v : Wire) (h : productBit v p=false) :
    ∃ b, ∀ j∈side p b, v j=false := by
  have hh := false_ray v (fun _ => p) 0 h
  by_cases l : 12 ∈ p.1
  · exact ⟨!(dir v (fun _ => p) 0), by simpa [side,l] using hh⟩
  · exact ⟨dir v (fun _ => p) 0, by simpa [side,l] using hh⟩

private theorem hot_arm (p : Product) (v : Wire) (h : productBit v p=true) (b : Bool) :
    ∃ j∈arm p b, v j=true := by
  have hh : readArm v p.1=true ∧ readArm v p.2=true := by simpa [productBit] using h
  cases b
  · simpa [arm,readArm] using hh.1
  · simpa [arm,readArm] using hh.2

private theorem hot_cover (R A B : Product) (v : Wire)
    (ar : Apart A) (br : Apart B) (ra : Below 12 R) (aa : Below 13 A) (ba : Below 13 B)
    (z : v 12=productBit v R) (hot : productBit v A=true ∨ productBit v B=true)
    (d : Fin 7) : ∃ j, reads R A B d j ∧ v j=true := by
  have aux (p : Product) (b : Bool) (dis : Apart p) (bd : Below 13 p)
      (lift : ∀ j, j∈side p b → j∈side A (sides d).1 ∨ j∈side B (sides d).2.1)
      (hp : productBit v p=true) : ∃ j, reads R A B d j ∧ v j=true := by
    obtain ⟨j,hj,hv⟩ := hot_arm p v hp (if 12 ∈ p.1 then !b else b)
    change j ∈ side p b at hj
    have small : j<13 := by
      have bounded (t : Bool) (hmem : j ∈ arm p t) : j<13 := by
        cases t
        · exact bd.1 j hmem
        · exact bd.2 j hmem
      exact bounded _ hj
    by_cases lt : j<12
    · rcases lift j hj with x|x
      · exact ⟨j,⟨lt,Or.inl x⟩,hv⟩
      · exact ⟨j,⟨lt,Or.inr (Or.inl x)⟩,hv⟩
    · have eq : j=12 := by omega
      subst j
      obtain ⟨k,hk,kv⟩ := hot_arm R v (z.symm.trans hv) (sides d).2.2
      have kl : k<12 := by unfold arm at hk; split at hk <;> first | exact ra.1 k hk | exact ra.2 k hk
      exact ⟨k,⟨kl,Or.inr (Or.inr ⟨lift 12 hj,hk⟩)⟩,kv⟩
  rcases hot with h|h
  · exact aux A _ ar aa (fun _ x => Or.inl x) h
  · exact aux B _ br ba (fun _ x => Or.inr x) h

private theorem cold_cover (R A B : Product) (v : Wire) (ar : Apart A) (br : Apart B)
    (z : v 12=productBit v R) (a : productBit v A=false) (b : productBit v B=false) :
    ∃ d : Fin 7, ∀ j, reads R A B d j → v j=false := by
  obtain ⟨i,ai⟩ := cold_side A v a
  obtain ⟨k,bk⟩ := cold_side B v b
  let c := dir v (fun _ => R) 0
  have last (h : 12∈side A i ∨ 12∈side B k) : ∀ j ∈ arm R c, v j=false := by
    apply false_ray v (fun _ => R) 0
    rw [←z]
    exact h.elim (ai 12) (bk 12)
  refine ⟨code i k c,?_⟩
  intro j hj
  rcases hj.2 with ha|hb|⟨hr,hj⟩
  · apply ai j
    cases i <;> cases k <;> cases hc : c <;> simpa [hc,code,sides] using ha
  · apply bk j
    cases i <;> cases k <;> cases hc : c <;> simpa [hc,code,sides] using hb
  · cases i <;> cases k <;> cases hc : c
    all_goals first
      | exact False.elim (hr.elim (no_last A ar) (no_last B br))
      | exact last (by simpa [code,sides,hc] using hr) j (by simpa [code,sides,hc] using hj)

theorem physical (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B]) :
    let v := fun m : Fin 1024 => run [H,Q,R] 10 (fullWire m.val)
    (∀ d (m : Fin 1024), accepts m.val=true → ∃ j, reads R A B d j ∧ v m j=true) ∧
    (∀ m : Fin 1024, accepts m.val=false → ∃ d, ∀ j, reads R A B d j → v m j=false) := by
  dsimp only
  obtain ⟨ord,_,bd⟩ := hidden_first_shape c
  rw [hh] at ord bd
  rw [ht] at bd
  obtain ⟨ar,aa⟩ := bd A (by simp)
  obtain ⟨br,ba⟩ := bd B (by simp)
  have ra : Below 12 R := ⟨ord.2.2.2.2.1,ord.2.2.2.2.2.1⟩
  have z (m : Fin 1024) := placed [H,Q,R] 10 (fullWire m.val) (i:=2) ord (p:=R) rfl
  constructor
  · intro d m h
    have e := hidden_first_correct c m
    rw [hh,ht,h] at e
    exact hot_cover R A B _ ar br ra aa ba (z m) (by simpa using e) d
  · intro m h
    have e := hidden_first_correct c m
    rw [hh,ht,h] at e
    have ab : productBit (run [H,Q,R] 10 (fullWire m.val)) A=false ∧
        productBit (run [H,Q,R] 10 (fullWire m.val)) B=false := by simpa using e
    exact cold_cover R A B _ ar br (z m) ab.1 ab.2
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.physical
