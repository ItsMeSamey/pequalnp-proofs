import CompactPriorSelected26Cell09
-- CompactPriorFace64
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_12 : CutRow book 7 12 4 := (joinRow row7_12_seg12 row7_12_seg15)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace65
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_16 : CutRow book 7 16 12 := (joinRow (joinRow (joinRow row7_16_seg16 row7_16_seg19) row7_16_seg22) row7_16_seg25)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace66
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_28 : CutRow book 7 28 12 := (joinRow (joinRow (joinRow row7_28_seg28 row7_28_seg31) row7_28_seg34) row7_28_seg37)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
