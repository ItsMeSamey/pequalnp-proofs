import H2FastInitial9822
import H2LocalRootCover9822
namespace Research.Graph9822H2Check

def seedPool (h : Nat) : List Nat := do
  let c ← centers
  let t := 8191 ^^^ (rawPos c ||| (positive h &&& rawPos (freeRaw (negative h))))
  let use ← [false,true]
  let x ← fastCovers (if use then t &&& (8191 ^^^ positive h) else t)
  return demand t (rawNeg x ||| (if use then negative h else 0))

private theorem fromGuard {s x : Nat} {b : Bool}
    (mem : s ∈ (do guard b; return x : List Nat)) : s ∈ [x] := by
  cases b <;> simp_all [guard]

theorem retainedSeed {s h : Nat} (kept : s ∈ fastInitial h) : s ∈ seedPool h := by
  have entry := List.mem_eraseDups.mp (List.mem_filter.mp (List.mem_mergeSort.mp kept)).1
  obtain ⟨c,hc,row⟩ := List.mem_flatMap.mp entry
  obtain ⟨u,hu,rest⟩ := List.mem_flatMap.mp row
  obtain ⟨x,hx,final⟩ := List.mem_flatMap.mp rest
  exact List.mem_flatMap.mpr ⟨c,hc,List.mem_flatMap.mpr ⟨u,hu,
    List.mem_flatMap.mpr ⟨x,hx,fromGuard final⟩⟩⟩

theorem allFrozenRoots {s h q : Nat} {roots : List Nat} {bad : Nat → Bool}
    (coverage : (seedPool h).all (rootCovered bad roots) = true)
    (safe : ∀ t, bad t = true → ¬holds q t)
    (root : s ∈ fastInitial h) (live : holds q s) : ∃ r ∈ roots, holds q r :=
  seeded_root (List.all_eq_true.mp coverage s (retainedSeed root)) safe live

end Research.Graph9822H2Check
