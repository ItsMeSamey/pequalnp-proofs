import And9822ReverseChannel
namespace Research.Graph9822.ThreeRoots
open Research.Graph9822.ReverseChannel
open Research.Graph9822.FreeOR Research.Graph9822.Footprint
open Research.Graph9822Resolution

def activation (p : Nat → Product) (wire : Nat → Nat) (k : Nat) : Trace → Bool :=
  if k<3 then full else active (channel p (wire k))

def row (p : Nat → Product) (wire : Nat → Nat) (w : Dir) : Nat → Trace
  | 0 => []
  | k+1 => stepRow k (activation p wire k) w (row p wire w k)

private theorem snoc (p wire w k t) : t ∈ row p wire w (k+1) ↔
    (activation p wire k (row p wire w k) = true ∧ t=(k,w k)) ∨ t ∈ row p wire w k := by
  cases e : activation p wire k (row p wire w k) <;> simp [row,stepRow,e]

private theorem interval (p wire w n t) (ht : t ∈ row p wire w n) :
    t.1 < n ∧ t.2 = w t.1 := by
  induction n with
  | zero => simp [row] at ht
  | succ k ih =>
    rcases (snoc _ _ _ _ _).mp ht with ⟨_,rfl⟩ | old
    · exact ⟨Nat.lt_succ_self _,rfl⟩
    · exact ⟨Nat.lt_succ_of_lt (ih old).1,(ih old).2⟩

private theorem row_prefix (p wire w k n t) (kn : k ≤ n) (tk : t.1 < k) :
    t ∈ row p wire w n ↔ t ∈ row p wire w k := by
  induction n, kn using Nat.le_induction with
  | base => rfl
  | succ n kn ih =>
    rw [snoc,←ih]
    constructor
    · rintro (⟨_,rfl⟩ | old)
      · simp at tk; omega
      · exact old
    · exact Or.inr

theorem forward_closed (p : Nat → Product) (wire : Nat → Nat) (w : Dir)
    (sep : ∀ i v, v ∈ (p i).1 → v ∉ (p i).2)
    {n k : Nat} {t : Nat × Bool} (tm : t ∈ row p wire w n)
    (before : t.1 < k) (kn : k<n) (use : wire k ∈ arm (p t.1) t.2) :
    (k,w k) ∈ row p wire w n := by
  have old := (row_prefix _ _ _ _ _ _ (Nat.le_of_lt kn) before).mp tm
  have act := (active_iff p sep (wire k) _).mpr ⟨t,old,use⟩
  have on : activation p wire k (row p wire w k)=true := by
    by_cases small : k<3
    · simp [activation,small,full]
    · simpa [activation,small] using act
  apply (row_prefix _ _ _ (k+1) n _ (by omega) (Nat.lt_succ_self k)).mpr
  exact (snoc _ _ _ _ _).mpr (Or.inl ⟨on,rfl⟩)

theorem root_mem (p wire w n i) (hi : i<3) (hn : i<n) : (i,w i) ∈ row p wire w n := by
  apply (row_prefix _ _ _ (i+1) n _ (by omega) (Nat.lt_succ_self i)).mpr
  apply (snoc _ _ _ _ _).mpr
  exact Or.inl ⟨by simp [activation,hi,full],rfl⟩

theorem row_four_mem (p wire w) :
    row p wire w 4 ∈ next 3 (active (channel p (wire 3))) threeFull :=
  step_mem _ _ _ _ _ (step_mem _ _ _ _ _ (step_mem _ _ _ _ _
    (step_mem _ _ _ _ _ (by simp [start,row]))))

/-- Reverse traversal of an actual negative evaluation. -/
theorem all_false (p : Nat → Product) (wire : Nat → Nat) (v : Wire) (n : Nat)
    (sep : ∀ i x, x ∈ (p i).1 → x ∉ (p i).2)
    (eval : ∀ i<n, v (wire i) = productBit v (p i)) (root : ∀ i, i<3 → i<n → v (wire i)=false) :
    ∀ t ∈ row p wire (dir v p) n, ∀ x ∈ arm (p t.1) t.2, v x=false := by
  let w := dir v p
  have scan : ∀ k, k ≤ n → ∀ t ∈ row p wire w k, ∀ x ∈ arm (p t.1) t.2, v x=false := by
    intro k
    induction k with
    | zero => simp [row]
    | succ k ih =>
      intro kn t tm
      rcases (snoc _ _ _ _ _).mp tm with ⟨on,rfl⟩ | old
      · apply false_ray
        rw [←eval k (by omega)]
        by_cases kz : k<3
        · exact root k kz (by omega)
        · have act : active (channel p (wire k)) (row p wire w k)=true := by
            simpa [activation,kz] using on
          obtain ⟨t,tm,read⟩ := (active_iff p sep _ _).mp act
          exact ih (by omega) t tm _ read
      · exact ih (by omega) t old
  exact scan n (Nat.le_refl n)

/-- Forward reevaluation in any assignment satisfying the raw blockers. -/
theorem replay (p : Nat → Product) (wire : Nat → Nat) (w : Dir) (v : Wire) (n : Nat)
    (hn : 0<n) (leaf : Nat → Prop)
    (sep : ∀ i x, x ∈ (p i).1 → x ∉ (p i).2)
    (eval : ∀ i<n, v (wire i) = productBit v (p i))
    (sources : ∀ i<n, ∀ b x, x ∈ arm (p i) b →
      leaf x ∨ ∃ k, i<k ∧ k<n ∧ x=wire k)
    (blocked : ∀ t ∈ row p wire w n, ∀ x ∈ arm (p t.1) t.2, leaf x → v x=false) :
    ∀ i, i<3 → i<n → v (wire i)=false := by
  have scan : ∀ m i, n-i=m → i<n → (i,w i)∈row p wire w n → v (wire i)=false := by
    intro m
    induction m using Nat.strong_induction_on with
    | ind m ih =>
      intro i mi il mem
      have ray : readArm v (arm (p i) (w i))=false := by
        apply List.any_eq_false.mpr
        intro x read
        rcases sources i il (w i) x read with raw | ⟨k,ik,kn,rfl⟩
        · simp [blocked _ mem _ read raw]
        · simp [ih (n-k) (by omega) k rfl kn (forward_closed _ _ _ sep mem ik kn read)]
      rw [eval i il]
      cases side : w i <;> simp_all [arm,productBit]
  intro i hi lt
  exact scan (n-i) i rfl lt (root_mem _ _ _ _ i hi lt)

end Research.Graph9822.ThreeRoots
