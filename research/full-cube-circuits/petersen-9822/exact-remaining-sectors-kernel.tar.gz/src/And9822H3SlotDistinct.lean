import And9822H3TailArms
import And9822H3PackedDirections
namespace Research.Graph9822.H3Directions
open Research.Graph9822Resolution
/-- A seven-class physical partition distinguishes the supports themselves. -/
theorem support_distinct {F N P : Type} (read : Fin 7 → F → Prop)
    (pos : P → F → Prop) (neg : N → F → Prop)
    (group slot : N → Fin 7) (all : Function.Surjective group)
    (perm : Fin 7 ≃ Fin 7) (aligned : ∀ n,slot n=perm (group n))
    (hot : ∀ d p, ∃ f, read d f ∧ pos p f)
    (cold : ∀ n f, read (slot n) f → ¬neg n f)
    (apart : ∀ i j, (∀ p,∃ f,pos p f ∧ ¬neg i f ∧ ¬neg j f) → group i=group j)
    (a b : Fin 7) (ne : a≠b) : ¬(∀ f,read a f ↔ read b f) := by
  intro same
  obtain ⟨i,hi⟩ := all (perm.symm a)
  obtain ⟨j,hj⟩ := all (perm.symm b)
  have ai : slot i=a := by rw [aligned,hi,perm.apply_symm_apply]
  have bj : slot j=b := by rw [aligned,hj,perm.apply_symm_apply]
  have eq := apart i j (by
    intro p
    obtain ⟨f,hf,hp⟩ := hot a p
    exact ⟨f,hp,cold i f (ai.symm ▸ hf), cold j f (bj.symm ▸ (same f).mp hf)⟩)
  exact ne (by rw [←ai,←bj,aligned,aligned,eq])
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.support_distinct
