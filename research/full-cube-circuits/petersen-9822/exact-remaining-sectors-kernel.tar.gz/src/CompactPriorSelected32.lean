import CompactPriorSelected31
-- CompactPriorFace82
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B759_12
def entries : List (Nat × Nat) := [(165,4),(166,4),(177,4),(183,7),(198,4),(231,7),(582,4),(593,4),(594,4),(599,7),(627,7),(689,7),(695,10),(710,7),(727,10),(743,10),(755,10)]
theorem prior : Known true entries := (consFace h165_4 (consFace h166_4 (consFace h177_4 (consFace h183_7 (consFace h198_4 (consFace h231_7 (consFace h582_4 (consFace h593_4 (consFace h594_4 (consFace h599_7 (consFace h627_7 (consFace h689_7 (consFace h695_10 (consFace h710_7 (consFace h727_10 (consFace h743_10 (consFace h755_10 (known_down baseKnown))))))))))))))))))
def samples : Nat → Bits × Bits := (fun i => (if i<8 then tableBits #[(padColumn 244 0x87ff0fc3f1111f8840000000000000fffff0003180000301fffff00c003c,padColumn 244 0x3ff07c1f0000f8000606010080c03696a500c3180000301dab4a00c0014),(padColumn 244 0x17c3f107ff2222097c00000000003ff00000ffc06030300ff80c03ffc00c3,padColumn 244 0x7c1f003ff0000007c08180603012a900c0365406030300d500c03aa80041),(padColumn 244 0xf8be120841f0ffff88000000007fc0000000ffcc0000cff000300cffc0303,padColumn 244 0xf83e000000f0ffff803020080c5a4040300c9a8c0000cda000300c5540102),(padColumn 244 0x0,padColumn 244 0x0),(padColumn 244 0x21042f93e2ff0f17fc000000ff80000003ff000000cff0c06003ff0300c0c,padColumn 244 0xf83e0ff0f07fc404030d5060180415a030000cea0c06000b50300408),(padColumn 244 0xffc8442084fff027fc0001ff0000000ffc00003007f3010187fc100c03030,padColumn 244 0xffc0000000fff007fd80815a3008060968100c3006a301018254100c01020),(padColumn 244 0x42108ffd08fffff813fe000000003ff00000003f8304060ff8c06010300c0,padColumn 244 0xffc00fffff802d300c0403015618060102a83040602a8c0601010080),(padColumn 244 0x84210fffff4444422001ffff007fc00000000000fff80ff6010180200f300,padColumn 244 0xfffff00000002014aa58025980201802000d15802560101802006200)] i else tableBits #[(padColumn 244 0x0,padColumn 244 0x0),(padColumn 244 0xfffff8421088888443fffe00ff8000000000003ffc0ff808060200c03cc00,padColumn 244 0xfffff00000000000012cb5002ac0200c0200c0152c015808060200c028800)] i))
def cols : List ColumnInfo := [(4,0,755,0,10),(16,0,743,0,10),(32,0,727,0,10),(64,0,695,0,10),(132,0,627,0,7),(160,0,599,0,7),(528,0,231,0,7),(576,0,183,0,7),(48,1,710,0,7),(49,0,710,0,7),(68,2,689,0,7),(70,0,689,0,7),(145,32,582,0,4),(162,4,593,0,4),(165,0,594,0,4),(177,0,582,0,4),(560,1,198,0,4),(577,16,166,0,4),(580,2,177,0,4),(594,0,165,0,4)]
def data11 : Nat → Nat := (fun i => tableWord #[0xff,0x89001a92b08] i)
def data10 : Nat → Nat := (fun i => tableWord #[0x1ff0e6,0x518a22a2d32443c70b,0x1ff4e6,0xaa38288a1147a6b0a,0x1ff8e6,0x263a84a0e1e1ac50a] i)
def data9 : Nat → Nat := (fun i => tableWord #[0x2fb5020e6,0x11241471305,0x33fce68e6,0x8920a1c71306,0x2ff5078e6,0x811243068706] i)
def levels : Nat → Packing
  | 9 => (3,2,5,0,0,0,0,data9)
  | 10 => (3,1,5,0,0,0,0,data10)
  | 11 => (1,0,5,0,0,0,0,data11)
  | _ => (0,0,0,0,0,0,0,fun _ => 0)
def index : Nat → Nat → Option (Nat × Nat)
  | 10 => fun h => smallSlot h 3 11 2 2 (fun i => ((fun i => tableWord #[0x0] i) (i/16) >>> (4*(i%16))) % 16) (fun i => ((fun i => tableWord #[0x546ae9e6f4000] i) (i/16) >>> (7*(i%16))) % 128)
  | 11 => fun v => (if v=8846553226619420952 then some (2,0) else (if v=9083563835880407257 then some (1,0) else (if v=9967659315218139993 then some (2,1) else (if v=10268309250932263832 then some (0,0) else none))))
  | _ => fun _ => none
def book : Forest := ⟨759,11,samples,cols,[[],[98,84,151],[16,66,101,151],[16,82,100]],levels,index⟩
end B759_12
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace83
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B759_12
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B759_12
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace84
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B759_12
set_option maxRecDepth 16000 in
theorem row11_0 : CutRow book 11 0 1 := bandCut 8 false (by decide +kernel)
end B759_12
end PEqualNP.Outside.L_meta_9825.Engine
