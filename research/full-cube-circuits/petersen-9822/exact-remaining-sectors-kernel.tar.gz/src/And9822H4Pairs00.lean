import And9822H4Geo
namespace Research.Graph9822.H4Geo
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
private theorem a0 : static_pairP 0 := by unfold static_pairP; decide +kernel
private theorem a1 : static_pairP 1 := by unfold static_pairP; decide +kernel
private theorem a2 : static_pairP 2 := by unfold static_pairP; decide +kernel
private theorem a3 : static_pairP 3 := by unfold static_pairP; decide +kernel
private theorem a4 : static_pairP 4 := by unfold static_pairP; decide +kernel
private theorem a5 : static_pairP 5 := by unfold static_pairP; decide +kernel
private theorem a6 : static_pairP 6 := by unfold static_pairP; decide +kernel
private theorem a7 : static_pairP 7 := by unfold static_pairP; decide +kernel
private theorem a8 : static_pairP 8 := by unfold static_pairP; decide +kernel
private theorem a9 : static_pairP 9 := by unfold static_pairP; decide +kernel
private theorem a10 : static_pairP 10 := by unfold static_pairP; decide +kernel
private theorem a11 : static_pairP 11 := by unfold static_pairP; decide +kernel
theorem pairs0 : ∀ r : Fin 12, static_pairP ⟨0*12+r.val,by omega⟩ := Fin.cases a0 (Fin.cases a1 (Fin.cases a2 (Fin.cases a3 (Fin.cases a4 (Fin.cases a5 (Fin.cases a6 (Fin.cases a7 (Fin.cases a8 (Fin.cases a9 (Fin.cases a10 (Fin.cases a11 (fun h=>Fin.elim0 h))))))))))))
end Research.Graph9822.H4Geo
