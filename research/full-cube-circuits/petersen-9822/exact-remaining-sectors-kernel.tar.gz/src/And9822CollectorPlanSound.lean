import And9822CollectorPlan
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
theorem mirror_drop {v w : Wire} {f : Rename} (eq : Mirrors v w f) (k) :
    Mirrors (Function.update v k false) w (Function.update f k none) := by
  intro i
  by_cases e : i=k <;> simp [e,eq i]

theorem mirror_add {v w : Wire} {f : Rename} (eq : Mirrors v w f) (k n)
    (bd : Routes n f) (b : Bool) :
    Mirrors (Function.update v k b) (Function.update w n b) (Function.update f k (some n)) := by
  intro i
  by_cases e : i=k
  · simp [e]
  · cases h : f i with
    | none => simp [e,h,eq i]
    | some j =>
      have ne := Nat.ne_of_lt (bd i j h)
      simp [e,h,eq i,ne]

theorem compile_sound (ex : Nat → Bool) (ps : List Product) (k n : Nat) (f : Rename)
    (bd : Routes n f) (v w : Wire) (eq : Mirrors v w f) (seen : Bool) :
    let plan := compileSlots ex ps k n f
    collect true ex ps k v seen =
      (seen || plan.2.any (productBit (run plan.1 n w))) := by
  induction ps generalizing k n f v w seen with
  | nil => simp [compileSlots,collect]
  | cons p ps ih =>
    cases e : ex k
    · have bit := mapped_product v w f eq p
      have h := ih (k+1) (n+1) (Function.update f k (some n)) (scope_add bd k)
        (Function.update v k (productBit v p)) (Function.update w n (productBit v p))
        (mirror_add eq k n bd _) seen
      simpa [compileSlots,collect,e,run,bit] using h
    · let f' := Function.update f k none
      let tail := compileSlots ex ps (k+1) n f'
      have h := ih (k+1) n f' (scope_drop bd k) (Function.update v k false) w
        (mirror_drop eq k) (seen || productBit v p)
      have bit : productBit (run tail.1 n w) (copyProduct f p) = productBit v p :=
        (copy_stale tail.1 n w f bd p).trans (mapped_product v w f eq p)
      change collect true ex (p::ps) k v seen = _
      simp only [collect,e,Bool.true_and,ite_true,compileSlots,List.any_cons]
      change collect true ex ps (k+1) (Function.update v k false) (seen || productBit v p) =
        (seen || (productBit (run tail.1 n w) (copyProduct f p) || tail.2.any _))
      rw [h,bit,Bool.or_assoc]

end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.compile_sound
