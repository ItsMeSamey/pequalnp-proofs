import And9822H4Tree04
namespace Research.Graph9822.H4Tree
theorem t250 {p : Bad} (legal : Respects p) (ok : Within p 1766834228294150684015937109622719718959039395772050294806405878880075775) : Success p :=
  fork legal ok 13 (by decide +kernel) (by decide +kernel) (t114 legal) (t249 legal)
theorem t251 {p : Bad} (legal : Respects p) (ok : Within p 210624583337117436703267904044934017714763043233600714158653833216) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t252 {p : Bad} (legal : Respects p) (ok : Within p 883423532389192164791648750371459265889109923185990342711331192399986688) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t253 {p : Bad} (legal : Respects p) (ok : Within p 631876963887431638168059258200959450315846920793923339565727219712) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t254 {p : Bad} (legal : Respects p) (ok : Within p 883424164266156052223286918430717458873192264284730272984142666373529600) : Success p :=
  fork legal ok 9 (by decide +kernel) (by decide +kernel) (t252 legal) (t253 legal)
theorem t255 {p : Bad} (legal : Respects p) (ok : Within p 3264092902401073997202870322833794003607449088211476488912896) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t256 {p : Bad} (legal : Respects p) (ok : Within p 883424164266206269037170011876828230259169655850674957671350236591685632) : Success p :=
  fork legal ok 8 (by decide +kernel) (by decide +kernel) (t254 legal) (t255 legal)
theorem t257 {p : Bad} (legal : Respects p) (ok : Within p 883423532389192164791648750371467900554170541960815099614309043446743040) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t258 {p : Bad} (legal : Respects p) (ok : Within p 883424164266206269037170011876828613076832441906446353967783597330923520) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t256 legal) (t257 legal)
theorem t259 {p : Bad} (legal : Respects p) (ok : Within p 883424164266206269040233319308674185593387365315819683176982432477872128) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t251 legal) (t258 legal)
theorem t260 {p : Bad} (legal : Respects p) (ok : Within p 40443227932906896502485868186136399362649340768338589236921759236096) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t261 {p : Bad} (legal : Respects p) (ok : Within p 883464607490875083031271423747811496335698511149150220944707548271411200) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t259 legal) (t260 legal)
theorem t262 {p : Bad} (legal : Respects p) (ok : Within p 51622884676567019919836305559399414835146194875018219410685956) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t263 {p : Bad} (legal : Respects p) (ok : Within p 53229822716079052877327494973415009101005910620958542809530400) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t264 {p : Bad} (legal : Respects p) (ok : Within p 53229822720826010195378267651740577437668397868801012245987364) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t262 legal) (t263 legal)
theorem t265 {p : Bad} (legal : Respects p) (ok : Within p 5071898202192438057179317853951794464210703199144536367431712) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t266 {p : Bad} (legal : Respects p) (ok : Within p 56493915623227084192572878151808563974041622699939906673704996) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t264 legal) (t265 legal)
theorem t267 {p : Bad} (legal : Respects p) (ok : Within p 5039307490006249807472962625066676617738192522450781335739498532) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t268 {p : Bad} (legal : Respects p) (ok : Within p 5039307490006249807472962625731290615630650458902684865879670820) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t266 legal) (t267 legal)
theorem t269 {p : Bad} (legal : Respects p) (ok : Within p 883464609222250392100710745875262069927374822484519374532010587045036068) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t261 legal) (t268 legal)
theorem t270 {p : Bad} (legal : Respects p) (ok : Within p 10709112270728082127959336754872320) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t271 {p : Bad} (legal : Respects p) (ok : Within p 23384026197294447015777510981887399212839017119744) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t272 {p : Bad} (legal : Respects p) (ok : Within p 23384026197294457400371228051542656273831675559936) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t270 legal) (t271 legal)
theorem t273 {p : Bad} (legal : Respects p) (ok : Within p 10709112270765861059822293916581888) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t274 {p : Bad} (legal : Respects p) (ok : Within p 23384026197294457400371228089321588136788837269504) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t272 legal) (t273 legal)
theorem t275 {p : Bad} (legal : Respects p) (ok : Within p 10709112270765861059857478288670976) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t276 {p : Bad} (legal : Respects p) (ok : Within p 23384026197294457400371228089321588171973209358592) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t274 legal) (t275 legal)
theorem t277 {p : Bad} (legal : Respects p) (ok : Within p 23384026197336992371717791890090940503976407203840) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t278 {p : Bad} (legal : Respects p) (ok : Within p 23384026197336992696236345548517811402320503636224) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t276 legal) (t277 legal)
theorem t279 {p : Bad} (legal : Respects p) (ok : Within p 10709112270728229701911935558090752) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t280 {p : Bad} (legal : Respects p) (ok : Within p 23384026197336992696236345548517811402329630441728) : Success p :=
  fork legal ok 14 (by decide +kernel) (by decide +kernel) (t278 legal) (t279 legal)
theorem t281 {p : Bad} (legal : Respects p) (ok : Within p 3383980122131063242231073577677608717135116238765905661961359589632) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t282 {p : Bad} (legal : Respects p) (ok : Within p 3383980122131063242231073577677619426247386966847889506110038606080) : Success p :=
  fork legal ok 9 (by decide +kernel) (by decide +kernel) (t280 legal) (t281 legal)
theorem t283 {p : Bad} (legal : Respects p) (ok : Within p 4213520107090616998213298829616316712116365877630443448187174846720) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t284 {p : Bad} (legal : Respects p) (ok : Within p 4226684143549186646550538583076786225268498492785213999020395004160) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t282 legal) (t283 legal)
theorem t285 {p : Bad} (legal : Respects p) (ok : Within p 324518553658426870915940577444096) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t286 {p : Bad} (legal : Respects p) (ok : Within p 3383160583728488140651167725984356255937217691855768756869113315584) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t287 {p : Bad} (legal : Respects p) (ok : Within p 3383160583728488140651167725984356580455771350282495540025133891840) : Success p :=
  fork legal ok 9 (by decide +kernel) (by decide +kernel) (t285 legal) (t286 legal)
theorem t288 {p : Bad} (legal : Respects p) (ok : Within p 4212495684087398115392409965665505638837974083183607174074504577280) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t289 {p : Bad} (legal : Respects p) (ok : Within p 4225659720545967763729649719125964767396389628535546711325389881600) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t287 legal) (t288 legal)
theorem t290 {p : Bad} (legal : Respects p) (ok : Within p 6766317953580887763321784368044533021846088874132890230676252524544) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t291 {p : Bad} (legal : Respects p) (ok : Within p 7980560271568181328352777276334538752) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t292 {p : Bad} (legal : Respects p) (ok : Within p 7980560271568030065051513629861478400) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t293 {p : Bad} (legal : Respects p) (ok : Within p 7980560271568181328352918048184729600) : Success p :=
  fork legal ok 17 (by decide +kernel) (by decide +kernel) (t291 legal) (t292 legal)
theorem t294 {p : Bad} (legal : Respects p) (ok : Within p 6766314739704799245341233284128318515198734941399998504549627199488) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t295 {p : Bad} (legal : Respects p) (ok : Within p 6766314739704799245341233284128323707495593476227627035045956419584) : Success p :=
  fork legal ok 9 (by decide +kernel) (by decide +kernel) (t293 legal) (t294 legal)
theorem t296 {p : Bad} (legal : Respects p) (ok : Within p 5495033726871700753411966917695273697280) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t297 {p : Bad} (legal : Respects p) (ok : Within p 6766314739704799245341233284170859003360710784160548860974927446016) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t295 legal) (t296 legal)
theorem t298 {p : Bad} (legal : Respects p) (ok : Within p 6766317953580887763321784368095043685685915828566536444157079060480) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t290 legal) (t297 legal)
theorem t299 {p : Bad} (legal : Respects p) (ok : Within p 8424987350829685583309131076477620316605053731276383897801502228480) : Success p :=
  leaf ok 0 (by decide +kernel)
end Research.Graph9822.H4Tree
