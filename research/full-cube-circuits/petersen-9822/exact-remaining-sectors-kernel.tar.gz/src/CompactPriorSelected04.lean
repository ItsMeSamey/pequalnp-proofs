import CompactPriorSelected03
-- CompactPriorC513
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B668_7
theorem band4 : CutRow book 4 0 1 := row4_0
theorem checked : mixedTables book 6 := by
  intro k hk
  interval_cases k
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact band4
  · exact band5
  · exact band6
end B668_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorC514
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h668_7 : Face true 668 7 :=
  mixedLower (g:=B668_7.book) (i:=0) (hints:=275414983424)
    (before_sound B668_7.entries B668_7.prior) B668_7.geometry B668_7.checked
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace00
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h6_1 : Face true 6 1 := countFace 288 (by decide +kernel) (by decide +kernel) (by decide +kernel)
theorem h14_2 : Face true 14 2 := countFace 8480 (by decide +kernel) (by decide +kernel) (by decide +kernel)
theorem h30_4 : Face true 30 4 := carry_of (swaps:=[66,16]) (by decide +kernel) h29_4
theorem h57_4 : Face true 57 4 := carry_of (swaps:=[82,48]) (by decide +kernel) h29_4

end PEqualNP.Outside.L_meta_9825.Engine
