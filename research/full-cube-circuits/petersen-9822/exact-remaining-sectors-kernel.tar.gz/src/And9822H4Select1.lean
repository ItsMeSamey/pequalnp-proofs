import And9822H4Geo
namespace Research.Graph9822.H4Geo
open Research.Graph9822.H4Tree
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
theorem negative1 : negSiteP 1 := by unfold negSiteP; decide +kernel
private theorem row0 : ∀ k : Fin 10, 0≠k → let p := pairNumber 1 0 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 0 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 0)) := by decide +kernel
private theorem row1 : ∀ k : Fin 10, 1≠k → let p := pairNumber 1 1 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 1 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 1)) := by decide +kernel
private theorem row2 : ∀ k : Fin 10, 2≠k → let p := pairNumber 1 2 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 2 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 2)) := by decide +kernel
private theorem row3 : ∀ k : Fin 10, 3≠k → let p := pairNumber 1 3 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 3 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 3)) := by decide +kernel
private theorem row4 : ∀ k : Fin 10, 4≠k → let p := pairNumber 1 4 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 4 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 4)) := by decide +kernel
private theorem row5 : ∀ k : Fin 10, 5≠k → let p := pairNumber 1 5 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 5 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 5)) := by decide +kernel
private theorem row6 : ∀ k : Fin 10, 6≠k → let p := pairNumber 1 6 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 6 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 6)) := by decide +kernel
private theorem row7 : ∀ k : Fin 10, 7≠k → let p := pairNumber 1 7 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 7 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 7)) := by decide +kernel
private theorem row8 : ∀ k : Fin 10, 8≠k → let p := pairNumber 1 8 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 8 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 8)) := by decide +kernel
private theorem row9 : ∀ k : Fin 10, 9≠k → let p := pairNumber 1 9 k
  (choices[1]!).testBit (first p).val=true ∧ (choices[1]!).testBit (second p).val=true ∧
  ((sideL (first p)=nm 1 9 ∧ sideR (first p)=nm 1 k) ∨
   (sideL (first p)=nm 1 k ∧ sideR (first p)=nm 1 9)) := by decide +kernel
theorem selected1 : selectedPairP 1 := Fin.cases row0 (Fin.cases row1 (Fin.cases row2 (Fin.cases row3 (Fin.cases row4 (Fin.cases row5 (Fin.cases row6 (Fin.cases row7 (Fin.cases row8 (Fin.cases row9 (fun h=>Fin.elim0 h))))))))))
end Research.Graph9822.H4Geo
