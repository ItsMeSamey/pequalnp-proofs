import H2FastStep9822
import H2MinimalWitness9822
import OR9822H2RawMask
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden

theorem endData : ∀ i : Fin 13, edges[i.val]! < 1024 ∧
    ∀ k : Fin 10, edges[i.val]!.testBit k.val = (ends[i.val]!).contains (bit k.val) := by
  decide +kernel

theorem rawShoreProjection (t b : Nat) (coversRows : sub t (rawPos b) = true) :
    HitsAll ((es.filter t.testBit).map (fun i => ends[i]!)) b := by
  intro e he
  obtain ⟨i,hm,rfl⟩ := List.mem_map.mp he
  obtain ⟨hi,chosen⟩ := List.mem_filter.mp hm
  have lt : i < 13 := List.mem_range.mp hi
  have raw := (subset_bits ..).1 coversRows i chosen
  rw [raw_pos_bit b ⟨i,lt⟩] at raw
  obtain ⟨k,kb,ke⟩ := meets_iff_exists.mp raw
  have data := endData ⟨i,lt⟩
  have bound : k < 10 := by
    by_contra far
    have zero := Nat.testBit_lt_two_pow (lt_of_lt_of_le (show edges[i]! < 2^10 from data.1)
      (Nat.pow_le_pow_right (by decide) (by omega : 10 ≤ k)))
    change edges[i]!.testBit k = true at ke
    rw [zero] at ke
    contradiction
  refine ⟨bit k,List.contains_iff_mem.mp (?_),?_⟩
  · rw [← data.2 ⟨k,bound⟩]
    exact ke
  · apply (subset_bits ..).2
    intro j sel
    have eq : k = j := by simpa [bit,Nat.testBit_two_pow] using sel
    exact eq ▸ kb

theorem originalCover_has_fastSubshore (t b : Nat) (actual : sub t (rawPos b) = true) :
    ∃ m ∈ fastCovers t, sub m b = true ∧
      HitsAll ((es.filter t.testBit).map (fun i => ends[i]!)) m := by
  obtain ⟨m,mem,small,hits,_⟩ := minimalShoreBelow (rawShoreProjection t b actual)
  exact ⟨m,mem,small,hits⟩

end Research.Graph9822H2Check
