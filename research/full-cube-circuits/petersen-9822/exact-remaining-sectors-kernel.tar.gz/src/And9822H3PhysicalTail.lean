import And9822H3BanRun
import And9822H3SlotDistinct
import H3TailPhysicalGroups9822
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822.ReverseChannel Research.Graph9822Resolution
open Research.Graph9822.FeatureRun Research.H3Tail

def armReads (R A B : Product) (k : Fin 6) (j : Nat) : Prop :=
  j<12 ∧ j∈(#[side A false,side A true,side B false,side B true,arm R false,arm R true] : Array (List Nat))[k.val]!

theorem split_arms (R A B : Product) (aa : Apart A) (ba : Apart B)
    (a : 12∈side A true) (b : 12∈side B true) (d : Fin 7) (j : Nat) :
    reads R A B d j ↔ ∃ k, usesArm d k=true ∧ armReads R A B k j := by
  rw [tail_reads R A B aa ba a b]
  fin_cases d <;> simp [Fin.exists_fin_succ,usesArm,armReads,sides] <;> tauto

theorem no_exception (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B])
    (group : Fin 16 → Fin 7) (surj : Function.Surjective group)
    (classes : ∀ i j, (∀ p : Fin 13, ∃ f, feathot H Q ⟨p.val,by omega⟩ f ∧
      ¬feathot H Q ⟨13+(i : Fin 16).val,by omega⟩ f ∧
      ¬feathot H Q ⟨13+(j : Fin 16).val,by omega⟩ f) → group i=group j)
    (edges bans : Array Nat) (order : List (Fin 7)) (tape : List Nat)
    (accepted : Research.H3Tail.accepts edges bans (order.map Fin.val) tape=true)
    (all : order.Perm (List.finRange 7)) (bs : 7≤bans.size)
    (row : ∀ (p : Fin 13) m, edges[p.val]?=some m → ∀ f,
       feathot H Q ⟨p.val,by omega⟩ f → m.testBit (source f)=true)
    (ban : ∀ (g : Fin 7) (j : Nat), j<12 → bans[g.val]!.testBit j=true →
      ∃ n : Fin 16, group n=g ∧ ∃ f,source f=j ∧ feathot H Q ⟨13+n.val,by omega⟩ f) : False := by
  obtain ⟨slot,hot,cold⟩ := official_seven c H Q R A B hh ht
  obtain ⟨perm,aligned⟩ := physicalGroups _ _ _ group slot surj hot cold classes
  have diff := support_distinct _ _ _ group slot surj perm aligned hot cold classes
  have ar := ((hidden_first_shape c).2.2 A (by simp [ht])).1
  have br := ((hidden_first_shape c).2.2 B (by simp [ht])).1
  obtain ⟨a,b⟩ := both_read R A B ar br (fun i j ne same => diff i j ne (fun f => same (source f)))
  have split := split_arms R A B ar br a b
  apply excludes_clean_layout (armReads R A B) edges bans order tape accepted all perm.symm bs
  · intro d k j use read
    apply Bool.eq_false_iff.mpr
    intro lit
    obtain ⟨n,ng,f,eq,fire⟩ := ban _ j read.1 lit
    have sd : slot n=d := by rw [aligned,ng,perm.apply_symm_apply]
    apply cold n f _ fire
    rw [sd,eq]
    exact (split d j).mpr ⟨k,use,read⟩
  · intro d p m lookup
    obtain ⟨f,read,fire⟩ := hot d p
    obtain ⟨k,use,armread⟩ := (split d (source f)).mp read
    exact ⟨k,source f,use,armread,row p m lookup f fire⟩
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.no_exception
