import And9822H3Directions
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822.ReverseChannel Research.Graph9822Resolution
open Research.Graph9822.FourSaturation

def firstReads (Q R A B : Product) (t : Fin 7 × Bool) (j : Nat) : Prop :=
  j<11 ∧ (reads R A B t.1 j ∨ (reads R A B t.1 11 ∧ j∈arm Q t.2))

theorem first_physical (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B])
    (skip : Fin 7) (unused : ¬reads R A B skip 11) :
    let v := fun m : Fin 1024 => run [H,Q,R] 10 (fullWire m.val)
    let dirs := (Finset.univ : Finset (Fin 7 × Bool)).erase (skip,true)
    dirs.card=13 ∧
    (∀ t ∈ dirs, ∀ (m : Fin 1024), accepts m.val=true →
      ∃ j, firstReads Q R A B t j ∧ v m j=true) ∧
    (∀ m : Fin 1024, accepts m.val=false → ∃ t∈dirs, ∀ j,
      firstReads Q R A B t j → v m j=false) := by
  dsimp only
  obtain ⟨hot,cold⟩ := physical c H Q R A B hh ht
  obtain ⟨ord,_,_⟩ := hidden_first_shape c
  rw [hh] at ord
  have bd : Below 11 Q := ⟨ord.2.2.1,ord.2.2.2.1⟩
  let v := fun m : Fin 1024 => run [H,Q,R] 10 (fullWire m.val)
  have z (m : Fin 1024) : v m 11 = productBit (v m) Q :=
    placed [H,Q,R] 10 (fullWire m.val) (i:=1) ord (p:=Q) rfl
  constructor
  · rw [Finset.card_erase_of_mem (Finset.mem_univ _)]
    decide
  constructor
  · intro t _ m hp
    obtain ⟨j,hj,hv⟩ := hot t.1 m hp
    by_cases small : j<11
    · exact ⟨j,⟨small,Or.inl hj⟩,hv⟩
    · have h12 := hj.1
      have eq : j=11 := by omega
      subst j
      have prod : productBit (v m) Q=true := (z m).symm.trans hv
      have both : readArm (v m) Q.1=true ∧ readArm (v m) Q.2=true := by simpa [productBit] using prod
      have armhot : readArm (v m) (arm Q t.2)=true := by
        unfold arm; split <;> first | exact both.1 | exact both.2
      obtain ⟨k,hk,kv⟩ := List.any_eq_true.mp armhot
      have lt : k<11 := by unfold arm at hk; split at hk <;> first | exact bd.1 k hk | exact bd.2 k hk
      exact ⟨k,⟨lt,Or.inr ⟨hj,hk⟩⟩,kv⟩
  · intro m hn
    obtain ⟨d,cd⟩ := cold m hn
    by_cases demand : reads R A B d 11
    · let b := dir (v m) (fun _ => Q) 0
      have ne : d ≠ skip := fun e => unused (e ▸ demand)
      refine ⟨(d,b),by simp [ne],?_⟩
      intro j hj
      rcases hj.2 with old|⟨_,read⟩
      · exact cd j old
      · exact false_ray (v m) (fun _ => Q) 0 ((z m).symm.trans (cd 11 demand)) j read
    · refine ⟨(d,false),by simp,?_⟩
      intro j hj
      exact hj.2.elim (cd j) (fun h => (demand h.1).elim)

end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.first_physical
