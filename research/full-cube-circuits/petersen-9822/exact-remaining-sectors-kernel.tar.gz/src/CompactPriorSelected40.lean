import CompactPriorSelected40Cell01
-- CompactPriorFace106
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem row10_34 : CutRow book 10 34 6 := (joinRow row10_34_seg34 row10_34_seg37)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace107
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem combine10_0_13 : CutRow book 10 0 13 := @joinRow book 10 0 1 12 row10_0 row10_1
theorem combine10_13_21 : CutRow book 10 13 21 := @joinRow book 10 13 12 9 row10_13 row10_25
theorem combine10_0_34 : CutRow book 10 0 34 := @joinRow book 10 0 13 21 combine10_0_13 combine10_13_21
theorem combine10_0_40 : CutRow book 10 0 40 := @joinRow book 10 0 34 6 combine10_0_34 row10_34
theorem band10 : CutRow book 10 0 40 := combine10_0_40
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace108
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
set_option maxRecDepth 16000 in
theorem row9_0 : CutRow book 9 0 1 := bandCut 9 false (by decide +kernel)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
