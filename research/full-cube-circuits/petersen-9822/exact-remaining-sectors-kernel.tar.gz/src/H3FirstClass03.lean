import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class012 : runPacket packets[12]! = true := by decide +kernel
theorem class013 : runPacket packets[13]! = true := by decide +kernel
theorem class014 : runPacket packets[14]! = true := by decide +kernel
theorem class015 : runPacket packets[15]! = true := by decide +kernel
end Research.Graph9822FirstBroad
