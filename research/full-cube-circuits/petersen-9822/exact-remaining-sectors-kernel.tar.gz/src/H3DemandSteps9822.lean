import H2Forest9822
import OR9822H2StepSound
import OR9822H2MaskLogic
import OR9822H2RawMask
namespace Research.Graph9822DemandThree
open Research.Graph9822H2Check Research.Graph9822OneHidden
open Research.Graph9822.FourSaturation (witnesses)

def pairRequest (h i j : Nat) : Nat :=
  let forbid := bit i ||| bit j
  let covered := if negative h &&& forbid == 0 then positive h else 0
  let all := inside (witnesses[i]! ||| witnesses[j]!)
  demand (all &&& (8191 ^^^ covered)) forbid

def requests (h hint : Nat) : Option (List Nat) := do
  let rows := (List.range 16).filter hint.testBit
  guard (rows.length == 8)
  let ds := do
    let i ← rows
    let j ← rows
    guard (i < j)
    return pairRequest h i j
  guard (ds.all (fun r => positive r != 0))
  return ds

def rules (h : Nat) (feas leaf : Nat → Bool) : Research.H3RegionEngine.Rules Nat :=
  ⟨fun s => !feas s,fun s code => do
    if code == 0 then
      guard (leaf s)
      return []
    let ds ← requests h code
    let cs := minimal (ds.map (fun d => s ||| d))
    guard (!cs.contains s)
    return cs⟩

theorem rescue_mem {q s : Nat} {ds : List Nat} (present : holds q s)
    (hit : ∃ r ∈ ds, holds q r) :
    ∃ k ∈ minimal (ds.map (fun d => s ||| d)), holds q k := by
  obtain ⟨r,mem,hot⟩ := hit
  obtain ⟨k,hk,small⟩ := minimal_weakens
    (List.mem_map.mpr ⟨r,mem,rfl⟩ : s ||| r ∈ ds.map (fun d => s ||| d))
  exact ⟨k,hk,weaker_holds small (join_subset present hot)⟩

end Research.Graph9822DemandThree
