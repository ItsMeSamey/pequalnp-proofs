import And9822H3BanInvariant
namespace Research.H3Tail

theorem clean_run (reads : Fin 6 → Nat → Prop) (bans : Array Nat) (assignment : Fin 7 ≃ Fin 7)
    (bs : 7≤bans.size) (ban : ∀ d k j, usesArm d k=true → reads k j →
      bans[(assignment d).val]!.testBit j=false) (slots : List (Fin 7))
    (start : Arms) (clean : Clean reads start) :
    ∃ final, applyLayout bans (slots.map Fin.val) (slots.map (fun d => (assignment d).val)) start=some final ∧
      Clean reads final := by
  induction slots generalizing start with
  | nil => exact ⟨start,rfl,clean⟩
  | cons d ds ih =>
    have idx : (assignment d).val<bans.size := lt_of_lt_of_le (assignment d).isLt bs
    let b := bans[(assignment d).val]!
    have look : bans[(assignment d).val]?=some b := by simp [b,idx]
    obtain ⟨a,run,good⟩ := ih (add start d.val b) (clean_add reads clean d b (ban d))
    exact ⟨a,by simpa [applyLayout,look] using run,good⟩

theorem assigned_perm (slots : List (Fin 7)) (assignment : Fin 7 ≃ Fin 7)
    (all : slots.Perm (List.finRange 7)) :
    (slots.map (fun d => (assignment d).val)).Perm (List.range 7) := by
  have unique : (slots.map (fun d => (assignment d).val)).Nodup := by
    apply List.Nodup.map
    · exact Fin.val_injective.comp assignment.injective
    · exact all.nodup_iff.mpr (List.nodup_finRange 7)
  apply (List.perm_ext_iff_of_nodup unique List.nodup_range).2
  intro n
  constructor
  · intro m
    obtain ⟨d,_,rfl⟩ := List.mem_map.mp m
    exact List.mem_range.mpr (assignment d).isLt
  · intro m
    let e : Fin 7 := ⟨n,List.mem_range.mp m⟩
    exact List.mem_map.mpr ⟨assignment.symm e,all.mem_iff.mpr (List.mem_finRange _),
      by simp [e]⟩

theorem excludes_clean_layout (reads : Fin 6 → Nat → Prop) (edges bans : Array Nat)
    (slots : List (Fin 7)) (tape : List Nat) (ok : accepts edges bans (slots.map Fin.val) tape=true)
    (all : slots.Perm (List.finRange 7)) (assignment : Fin 7 ≃ Fin 7) (bs : 7≤bans.size)
    (ban : ∀ d k j,usesArm d k=true → reads k j → bans[(assignment d).val]!.testBit j=false)
    (hot : ∀ d : Fin 7, ∀ i : Fin 13, ∀ m, edges[i.val]?=some m →
      ∃ k j, usesArm d k=true ∧ reads k j ∧ m.testBit j=true) : False := by
  obtain ⟨final,run,clean⟩ := clean_run reads bans assignment bs ban slots _ (clean_zero reads)
  exact no_obstruction reads clean hot (accepted_perm _ _ _ final ok (assigned_perm slots assignment all) run)
end Research.H3Tail
#print axioms Research.H3Tail.excludes_clean_layout
