import H2Forest9822
import OR9822H2Checker
namespace Research.Graph9822H2Check
open Research.H3RegionEngine

def packetRules (h : Nat) : Rules Nat :=
  ⟨fun _ => false, step h⟩

theorem packetSound (h fuel : Nat) (P : Nat → Prop) (keys hints : List Nat)
    (localSound : ∀ s code children, step h s code = some children →
      (∀ c ∈ children, P c) → P s)
    (accepted : forest (packetRules h) fuel keys hints = true) :
    ∀ s ∈ keys, P s :=
  forestSound (packetRules h) P (by simp [packetRules]) localSound accepted

end Research.Graph9822H2Check
