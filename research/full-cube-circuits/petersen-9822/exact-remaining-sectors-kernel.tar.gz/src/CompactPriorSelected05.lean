import CompactPriorSelected04
-- CompactPriorFace01
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B63_7
def entries : List (Nat × Nat) := [(29,4),(30,4),(57,4)]
theorem prior : Known true entries := (consFace h29_4 (consFace h30_4 (consFace h57_4 (known_down baseKnown))))
def samples : Nat → Bits × Bits := (fun i => (if i<8 then tableBits #[(padColumn 82 0x93fffe00003ff8460fc0,padColumn 82 0x1caaa0860ea50460d40),(padColumn 82 0x17fc000001fc31981fc03,padColumn 82 0x7fc186308b4319815801),(padColumn 82 0x3a4400007ffcc603ffc0f,padColumn 82 0x380061843348c602ca406),(padColumn 82 0x24fc001ffe03007fe103c,padColumn 82 0xfd8209cc13005521018),(padColumn 82 0x3f8807ff80000ffc860f0,padColumn 82 0x3f02055610600aa8860a0),(padColumn 82 0x3ff3f8000003f86318300,padColumn 82 0x3fe354186181586318200),(padColumn 82 0x0,padColumn 82 0x0),(padColumn 82 0x0,padColumn 82 0x0)] i else tableBits #[(padColumn 82 0x0,padColumn 82 0x0),(padColumn 82 0x0,padColumn 82 0x0)] i))
def cols : List ColumnInfo := [(1,32,30,0,4),(4,2,57,0,4),(34,0,29,0,4)]
def data6 : Nat → Nat := (fun i => tableWord #[0x3f,0x603] i)
def levels : Nat → Packing
  | 6 => (1,0,2,0,0,0,0,data6)
  | _ => (0,0,0,0,0,0,0,fun _ => 0)
def index : Nat → Nat → Option (Nat × Nat)
  | _ => fun _ => none
def book : Forest := ⟨63,6,samples,cols,[[],[32,81,67]],levels,index⟩
end B63_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace02
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B63_7
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B63_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace03
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B63_7
set_option maxRecDepth 16000 in
theorem row6_0 : CutRow book 6 0 1 := bandCut 6 false (by decide +kernel)
end B63_7
end PEqualNP.Outside.L_meta_9825.Engine
