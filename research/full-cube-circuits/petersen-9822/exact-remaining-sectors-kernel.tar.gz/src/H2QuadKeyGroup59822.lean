import H2QuadPairList9822
import H2ShortDomTransport9822
import H2ShortDom04079822
import H2ShortDom04089822
import H2ShortDom04099822
import H2ShortDom04129822
import H2ShortDom05069822
import H2ShortDom05079822
import H2ShortDom05109822
namespace Research.Graph9822H2Check
def keys5 : List (Nat × Nat) := [(4,7), (4,8), (4,9), (4,12), (5,6), (5,7), (5,10)]
theorem paidKeys5 : keys5.all (fun p => pairDom p.1 p.2)=true := by
  simp only [keys5,List.all_cons,List.all_nil,Bool.and_eq_true_iff]
  exact ⟨dom_of_short (by decide) short_dom_4_7, dom_of_short (by decide) short_dom_4_8, dom_of_short (by decide) short_dom_4_9, dom_of_short (by decide) short_dom_4_12, dom_of_short (by decide) short_dom_5_6, dom_of_short (by decide) short_dom_5_7, dom_of_short (by decide) short_dom_5_10, True.intro⟩
end Research.Graph9822H2Check
