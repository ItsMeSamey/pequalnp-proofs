import And9822H4Geo
import OR9822ArmMask
namespace Research.Graph9822.H4Geo
open Research.Graph9822OneHidden (meets)
open Research.Graph9822H2Check (meets_iff_exists)
open Research.Graph9822.H4Tree
def Profile := ∀ k : Fin 20,∀ i : OrId, profileOK k i=true
def key (A B : Nat) (k : Fin 20) := (if k.val<10 then A else B).testBit (k.val%10)
def hot (A B m : Nat) := meets A m && meets B m

theorem geo (valid : ∀ i,positivesP i) (i : OrId) (e : Nat) (mem : e∈possible i) :
    raw e<1024 ∧ Research.Graph9822.FourSaturation.accepts (raw e)=true ∧
    raw e &&& (sideL i ||| sideR i)=raw e := by
  have h := List.all_eq_true.mp (valid i) e mem
  simpa only [Bool.and_eq_true,decide_eq_true_eq,beq_iff_eq,and_assoc] using h

theorem facts (passed : Profile) (k : Fin 20) (i : OrId) :
    ((zeroOK[k.val]!).testBit i.val = !req i k) ∧
    ((oneOK[k.val]!).testBit i.val = !ban i k) ∧
    (ban i k = (outside i k).testBit (k.val%10)) ∧
    (req i k=true → en i k∈possible i ∧ raw (en i k) &&& (1023 ^^^ outside i k) = 2^(k.val%10)) := by
  have h := passed k i
  simp only [profileOK,Bool.and_eq_true,beq_iff_eq,Bool.or_eq_true,Bool.not_eq_true',
    List.contains_iff_mem] at h
  exact ⟨h.1.1.1,h.1.1.2,h.1.2,fun yes=>h.2.resolve_left (by simp [yes])⟩

theorem respect (pass : Profile) (f : Fin 20→Bool) : Respects (Obeys f) := by
  intro k
  cases h : f k with
  | false =>
    left
    intro i ok
    rw [(facts pass k i).1]
    cases e : req i k with
    | false => rfl
    | true => exact False.elim (by have := (ok k).1 e; simp_all)
  | true =>
    right
    intro i ok
    rw [(facts pass k i).2.1]
    cases e : ban i k with
    | false => rfl
    | true => exact False.elim (by have := (ok k).2 e; simp_all)

theorem forced_bit {x e m v : Nat} (low : meets x m=false) (hi : meets x e=true)
    (eb : e<1024) (cut : e &&& (1023 ^^^ m)=2^v) : x.testBit v=true := by
  obtain ⟨u,xu,eu⟩ := meets_iff_exists.mp hi
  have small : u<10 := by
    by_contra! ge
    have cold := Nat.testBit_lt_two_pow (lt_of_lt_of_le eb
      (show 1024 ≤ 2^u from Nat.pow_le_pow_right (by decide : 0<2) ge))
    simp_all
  have mu : m.testBit u=false := Bool.eq_false_iff.mpr (fun yes=>by
    have := meets_iff_exists.mpr ⟨u,xu,yes⟩
    simp_all)
  have mask : (1023:Nat).testBit u=true := by
    change (2^10-1 : Nat).testBit u=true
    rw [Nat.testBit_two_pow_sub_one]
    exact decide_eq_true small
  have e2 := congrArg (fun a : Nat=>a.testBit u) cut
  have vu : v=u := by simpa [Nat.testBit_and,Nat.testBit_xor,Nat.testBit_two_pow,eu,mu,mask] using e2.symm
  simpa [vu] using xu

theorem oriented (valid : ∀ i,positivesP i) (pass : Profile) (A B : Nat) (i : OrId)
    (coldA : meets A (sideR i)=false) (coldB : meets B (sideL i)=false)
    (all : ∀ e∈possible i,hot A B (raw e)=true) : Obeys (key A B) i := by
  intro k
  obtain ⟨_,_,banEq,need⟩ := facts pass k i
  constructor
  · intro r
    obtain ⟨mem,cut⟩ := need r
    have h : meets A (raw (en i k))=true ∧ meets B (raw (en i k))=true := by simpa only [hot,Bool.and_eq_true] using all _ mem
    by_cases small : k.val<10
    · exact (show key A B k=A.testBit (k.val%10) by simp [key,small]).trans
        (forced_bit coldA h.1 (geo valid i _ mem).1 (by simpa [outside,small] using cut))
    · exact (show key A B k=B.testBit (k.val%10) by simp [key,small]).trans
        (forced_bit coldB h.2 (geo valid i _ mem).1 (by simpa [outside,small] using cut))
  · intro r
    rw [banEq] at r
    apply Bool.eq_false_iff.mpr
    intro on
    by_cases small : k.val<10
    · have yes := meets_iff_exists.mpr ⟨k.val%10,(by simpa [key,small] using on : A.testBit (k.val%10)=true),
          (by simpa [outside,small] using r : (sideR i).testBit (k.val%10)=true)⟩
      simp_all
    · have yes := meets_iff_exists.mpr ⟨k.val%10,(by simpa [key,small] using on : B.testBit (k.val%10)=true),
          (by simpa [outside,small] using r : (sideL i).testBit (k.val%10)=true)⟩
      simp_all

theorem hit_union {e l r x : Nat} (sub : e &&& (l ||| r)=e) (hi : meets x e=true) :
    meets x l=true ∨ meets x r=true := by
  obtain ⟨u,hx,he⟩ := meets_iff_exists.mp hi
  have eq := congrArg (fun v : Nat=>v.testBit u) sub
  have hr : l.testBit u=true ∨ r.testBit u=true := by simpa [Nat.testBit_and,Nat.testBit_or,he] using eq
  exact hr.imp (fun h=>meets_iff_exists.mpr ⟨u,hx,h⟩) (fun h=>meets_iff_exists.mpr ⟨u,hx,h⟩)

end Research.Graph9822.H4Geo
