import OR9822H2Antichain
namespace Research.Graph9822H2Check

def shoreEnum : List (List Nat) → List Nat
  | [] => [0]
  | edge :: rest => minimal ((shoreEnum rest).flatMap fun c => edge.map fun v => c ||| v)

theorem shoreEnum_complete (edges : List (List Nat)) (b : Nat)
    (hit : ∀ e ∈ edges, ∃ v ∈ e, sub v b = true) :
    ∃ c ∈ shoreEnum edges, sub c b = true := by
  induction edges with
  | nil => exact ⟨0,by simp [shoreEnum],by simp [sub]⟩
  | cons e edges ih =>
    obtain ⟨v,hv,sv⟩ := hit e (by simp)
    obtain ⟨c,hc,sc⟩ := ih (fun a ha => hit a (by simp [ha]))
    have member : c ||| v ∈ ((shoreEnum edges).flatMap fun k => e.map fun w => k ||| w) :=
      List.mem_flatMap.mpr ⟨c,hc,List.mem_map.mpr ⟨v,hv,rfl⟩⟩
    obtain ⟨k,hk,small⟩ := minimal_weakens member
    refine ⟨k,hk,sub_trans small ?_⟩
    have ec : c &&& b = c := by simpa [sub] using sc
    have ev : v &&& b = v := by simpa [sub] using sv
    simp [sub,Nat.and_or_distrib_right,ec,ev]

end Research.Graph9822H2Check
