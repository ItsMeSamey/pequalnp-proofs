import H3FirstBroadSource9822
import H3FirstBroadAll9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822FirstAdmission
open Research.Graph9822.FeatureRun (rawCode)
theorem admitted_reaches (a b : Fin 1024) (disj : a.val &&& b.val=0)
    (hid : hidden (rawCode a.val &&& rawCode b.val)=true)
    (adm : firstAdmitted (rawCode a.val &&& rawCode b.val)=true) :
    ∃ i : Nat, roots[i]? = some (rawCode a.val &&& rawCode b.val) :=
  admitted_of_packets allPackets a b disj hid adm
end Research.Graph9822FirstBroad
