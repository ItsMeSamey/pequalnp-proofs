import And9822StablePartition
import OR9822FiveMinimum
import OR9822RetireHidden
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
open Research.Graph9822.FourSaturation
theorem out_lt {ps k out} (ord : Chronological k ps out) (j : Nat) (mem : j ∈ out) :
    j < k + ps.length := by
  induction ps generalizing k with
  | nil => simpa using ord j mem
  | cons p ps ih =>
    have h := ih ord.2.2
    simp only [List.length_cons]
    omega
theorem out_no_raw (c : FiveProgram) {j : Nat} (mem : j ∈ c.out) : 10 ≤ j := by
  by_contra! small
  let v : Fin 10 := ⟨j,small⟩
  let mask (u : Fin 10) : Fin 1024 := ⟨2^u.val % 1024,Nat.mod_lt _ (by decide)⟩
  have facts : ∀ u : Fin 10, fullWire (mask u).val u.val=true ∧ accepts (mask u).val=false := by decide
  let m := mask v
  obtain ⟨hot,cold⟩ := facts v
  have h := c.correct m
  rw [cold] at h
  have bit : run c.products 10 (fullWire m.val) j = true := (stale_value _ small _).trans hot
  have on : readArm (run c.products 10 (fullWire m.val)) c.out = true :=
    List.any_eq_true.mpr ⟨j,mem,bit⟩
  simp [h] at on
def exposed (c : FiveProgram) (k : Nat) : Bool := c.out.contains k
theorem collected (c : FiveProgram) (m : Fin 1024) :
    (terminals (exposed c) c.products 10).any
       (productBit (hiddenRun (exposed c) c.products 10 (fullWire m.val))) = accepts m.val := by
  have zero (j : Nat) (h : exposed c j=true) : fullWire m.val j=false := by
    have mem : j∈c.out := List.contains_iff_mem.mp h
    simp [fullWire,Nat.not_lt_of_ge (out_no_raw c mem)]
  have lhs := stable_partition (exposed c) c.products 10 c.out c.ordered (fullWire m.val) false zero
  rw [erase_exposed,collect_exact] at lhs
  simp only [Bool.false_or] at lhs
  rw [←lhs,←c.correct m]
  apply Bool.eq_iff_iff.mpr
  simp only [readArm,List.any_eq_true,Bool.and_eq_true,exposed,List.contains_iff_mem]
  constructor
  · rintro ⟨j,_,hj,on⟩
    exact ⟨j,hj,on⟩
  · rintro ⟨j,hj,on⟩
    have lo := out_no_raw c hj
    have hi := out_lt c.ordered j hj
    refine ⟨j,?_,hj,on⟩
    apply List.mem_range'.mpr
    exact ⟨j-10,by omega,by omega⟩
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.collected
