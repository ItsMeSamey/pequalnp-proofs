import CompactPriorSelected37Cell03
-- CompactPriorFace97
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem band12 : CutRow book 12 0 4 := row12_0
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace98
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
set_option maxRecDepth 16000 in
theorem row11_0 : CutRow book 11 0 1 := bandCut 9 false (by decide +kernel)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace99
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B767_14
theorem row11_1 : CutRow book 11 1 12 := (joinRow (joinRow (joinRow row11_1_seg1 row11_1_seg4) row11_1_seg7) row11_1_seg10)
end B767_14
end PEqualNP.Outside.L_meta_9825.Engine
