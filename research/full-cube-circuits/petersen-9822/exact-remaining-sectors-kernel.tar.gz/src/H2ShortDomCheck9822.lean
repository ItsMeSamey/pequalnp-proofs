import H2CanonicalPairs9822
import OR9822ProfileShortWords
namespace Research.Graph9822H2Check
open Research.Graph9822ProfileArithmetic.Laws (shortWords)
def shortDominated (i j : Nat) : Bool :=
  (universalPatterns i j).all fun p => (shortWords (13*i+j)).any fun w => (unpackPattern w).below p
end Research.Graph9822H2Check
