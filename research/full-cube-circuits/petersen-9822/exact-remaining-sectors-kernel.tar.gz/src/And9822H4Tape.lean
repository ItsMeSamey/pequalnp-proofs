import And9822TraceSaturation
import And9822StablePartition
import OR9822RetireHidden

namespace Research.Graph9822.ReverseChannel
open Research.Graph9822.FreeOR Research.Graph9822.Footprint
open Research.Graph9822Resolution

private theorem stable {p : Product} {v u : Wire} {k : Nat} (bd : (∀ j ∈ p.1, j<k) ∧ (∀ j ∈ p.2,j<k))
    (eq : ∀ j<k, v j=u j) : productBit v p=productBit u p := by
  unfold productBit
  rw [read_below (fun j hj => eq j (bd.1 j hj)),read_below (fun j hj => eq j (bd.2 j hj))]

theorem placed (ps : List Product) (k : Nat) (w : Wire) {p : Product} {i : Nat}
    (ord : Chronological k ps []) (atSlot : ps[i]?=some p) :
    let v := run ps k w
    v (k+i) = productBit v p := by
  induction ps generalizing k w i with
  | nil => simp at atSlot
  | cons q qs ih =>
    cases i with
    | zero =>
      simp at atSlot
      subst p
      let w' := Function.update w k (productBit w q)
      change run qs (k+1) w' k = productBit (run qs (k+1) w') q
      calc
        _ = w' k := stale_value qs (by omega : k<k+1) w'
        _ = productBit w q := Function.update_self ..
        _ = _ := by
          apply Eq.symm
          apply stable (k:=k) ⟨ord.1,ord.2.1⟩
          intro j hj
          exact (stale_value qs (show j<k+1 by omega) w').trans
            (Function.update_of_ne (Nat.ne_of_lt hj) _ _)
    | succ i =>
      simp at atSlot
      simpa [run,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using
        ih (k+1) (Function.update w k (productBit w q)) ord.2.2 atSlot

def program (a b d t : Product) : Nat → Product
  | 0 => t
  | 1 => d
  | 2 => b
  | 3 => a
  | _ => ([],[])

def slot (i : Nat) := 14-i

end Research.Graph9822.ReverseChannel
