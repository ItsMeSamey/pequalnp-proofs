import CompactPositive9822
import SignedPhysicalCore9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open Petersen9822 Petersen9822.DagCut Petersen9822.Potential Petersen9822.FirstSite
open PEqualNP.Outside.L_meta_9822.Clean PEqualNP.Outside.L_meta_9822.Sectors

def Site.asOp (s : Site) : SignedOp := ⟨s.isOr,s.left.neg,s.right.neg,s.outNeg⟩

theorem coreOfNet (net : Net 10 15) (h : SignedDag net edge) :
    Nonempty (FifteenCore net.indexed 24) := by
  have c := physicalCore net h
  refine ⟨⟨⟨c.diagram.raw,c.diagram.present,c.diagram.extent⟩,
    by decide,by decide,c.finalWire,c.live,c.properSockets,
    (fun w => ((net.get w).getD ⟨false,⟨0,false⟩,⟨0,false⟩,false⟩).asOp),?_,c.computes⟩⟩
  intro w g hg a b
  obtain ⟨s,hs,eq⟩ := Option.map_eq_some_iff.mp hg
  subst g
  rw [hs]
  rfl

theorem coreOfWitness {gs o} (w : PhysicalWitness (n := 10) gs o 15)
    (ev : ∀ x, vl gs x o = edge x) :
    Nonempty (FifteenCore (w.net.seal (w.ref o).neg).indexed 24) := by
  have cert := w.signed
  rw [show (fun x => vl gs x o) = edge from funext ev] at cert
  exact coreOfNet _ cert

theorem joinedCoreOfReduced {gs o} (hr : Reduced 10 gs o) (ev : ∀ x, vl gs x o = edge x)
    (count : gs.countP bin = 15) :
    ∃ w : PhysicalWitness (n := 10) gs o 15,
      Nonempty (FifteenCore (w.net.seal (w.ref o).neg).indexed 24) := by
  have witness := physicalWitness hr (outputGate ev).2 (by omega)
  rw [count] at witness
  obtain ⟨w⟩ := witness
  exact ⟨w,coreOfWitness w ev⟩

theorem coreOfReduced {gs o} (hr : Reduced 10 gs o) (ev : ∀ x, vl gs x o = edge x)
    (count : gs.countP bin = 15) : ∃ d : Indexed, Nonempty (FifteenCore d 24) := by
  obtain ⟨w,core⟩ := joinedCoreOfReduced hr ev count
  exact ⟨_,core⟩

theorem coreOfMany {gs o} (hr : Reduced 10 gs o) (ev : ∀ x, vl gs x o = edge x)
    (size : gs.length ≤ 17) (many : 2 ≤ gs.countP countsNot) (floor : 15 ≤ gs.countP bin) :
    gs.countP countsNot = 2 ∧ gs.length = 17 ∧ ∃ d : Indexed, Nonempty (FifteenCore d 24) := by
  have pred : (fun g => decide (¬ countsNot g = true)) = bin := by
    funext g
    cases g with
    | mk op ins => cases op <;> rfl
  have split := List.length_eq_countP_add_countP (l := gs) countsNot
  rw [pred] at split
  exact ⟨by omega,by omega,coreOfReduced hr ev (by omega)⟩

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.coreOfReduced
