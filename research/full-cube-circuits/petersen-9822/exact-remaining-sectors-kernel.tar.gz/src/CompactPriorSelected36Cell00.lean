import CompactPriorSelected35
namespace PEqualNP.Outside.L_meta_9825.Engine.B767_14
set_option maxRecDepth 16000 in
theorem row12_0_seg0 : CutRow book 12 0 3 := bandCut 10 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B767_14
