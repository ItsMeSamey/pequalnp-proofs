import CompactPriorSelected38Cell02
namespace PEqualNP.Outside.L_meta_9825.Engine.B767_14
set_option maxRecDepth 16000 in
theorem row11_13_seg22 : CutRow book 11 22 2 := bandCut 11 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B767_14
