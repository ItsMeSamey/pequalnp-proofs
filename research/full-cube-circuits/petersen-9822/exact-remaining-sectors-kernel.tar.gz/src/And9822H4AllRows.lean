import And9822H4Block00
import And9822H4Block01
import And9822H4Block02
import And9822H4Block03
import And9822H4Block04
import And9822H4Block05
import And9822H4Block06
import And9822H4Block07
import And9822H4Block08
import And9822H4Block09
import And9822H4Block10
import And9822H4Block11
import And9822H4Block12
import And9822H4Block13
import And9822H4Block14
import And9822H4Block15
import And9822H4Block16
import And9822H4Block17
import And9822H4Block18
import And9822H4Block19
namespace Research.Graph9822.H4Geo
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000
theorem allRows (j : OrId) : RowFact j := by
  have all : ∀ q r, RowFact (block q r) := Fin.cases block0 (Fin.cases block1 (Fin.cases block2 (Fin.cases block3 (Fin.cases block4 (Fin.cases block5 (Fin.cases block6 (Fin.cases block7 (Fin.cases block8 (Fin.cases block9 (Fin.cases block10 (Fin.cases block11 (Fin.cases block12 (Fin.cases block13 (Fin.cases block14 (Fin.cases block15 (Fin.cases block16 (Fin.cases block17 (Fin.cases block18 (Fin.cases block19 (fun h=>Fin.elim0 h))))))))))))))))))))
  let q : Fin 20 := ⟨j.val/12,by omega⟩
  let r : Fin 12 := ⟨j.val%12,by omega⟩
  have e : block q r=j := Fin.ext (by dsimp [block,q,r]; omega)
  exact e ▸ all q r
end Research.Graph9822.H4Geo
