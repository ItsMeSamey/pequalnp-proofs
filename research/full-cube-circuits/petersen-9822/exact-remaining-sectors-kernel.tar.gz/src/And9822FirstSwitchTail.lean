import And9822FirstSwitchRows
import ResolveUnion

namespace Research.Graph9822Resolution.FirstSwitchRows
open Research.Graph9822Resolution

def pulse (k : Nat) : Wire := fun j => decide (j = k)

theorem decompose (w : Wire) (k : Nat) (b : Bool) :
    Function.update w k b =
      wireUnion (Function.update w k false) (if b then pulse k else fun _ => false) := by
  funext j
  by_cases eq : j = k
  · subst j
    cases b <;> simp [wireUnion,pulse]
  · cases b <;> simp [wireUnion,pulse,eq,Function.update_of_ne eq]

theorem mux_tail (gs : List Gate) (i k out : Nat) (s w : Wire) (b : Bool) :
    resolve gs i s (Function.update w k b) out =
      (resolve gs i s (Function.update w k false) out ||
         (b && resolve gs i s (pulse k) out)) := by
  rw [decompose w k b,resolve_union]
  cases b <;> simp [wireUnion,resolve_empty]

theorem antichain : ∀ r s : Row, r ≠ s → ∃ v : V, has r v = true ∧ has s v = false := by
  decide +kernel

/-- At the first switch the two arms are fixed singleton-input profiles.
All later selections are fixed separately on each paired resolution. -/
theorem no_tail_pair (mate : Row → Row) (diff : ∀ r, mate r ≠ r)
    (a b : V → Bool) (side live : Row → Bool) (base : Row → V → Bool)
    (first : ∀ r v, (!(has r v)) = (base r v || ((if side r then a v else b v) && live r)))
    (second : ∀ r v, (!(has (mate r) v)) = (base r v || ((if side r then b v else a v) && live r))) :
    False := by
  have hot (r : Row) : live r = true := by
    obtain ⟨v,hv,hm⟩ := antichain r _ (diff r).symm
    have x := first r v
    have y := second r v
    cases hl : live r with
    | true => rfl
    | false =>
      cases eq : base r v <;> simp [hv,hm,hl,eq] at x y
  have used (r : Row) : (∃ v, a v = true) ∧ (∃ v, b v = true) := by
    obtain ⟨v,hv,hm⟩ := antichain r _ (diff r).symm
    obtain ⟨w,hw,hr⟩ := antichain _ r (diff r)
    have f := first r v
    have g := second r v
    have f' := first r w
    have g' := second r w
    cases hs : side r <;> simp [hv,hm,hw,hr,hs,hot] at f g f' g' <;> aesop
  refine no_paired_arms (fun v => a v = true) (fun v => b v = true) mate diff ?_ (used 0).1 (used 0).2 ?_
  · intro x y hx hy
    apply List.all_eq_true.mpr
    intro r _
    have f := first r x
    have g := first r y
    cases hs : side r <;> simp [hs,hx,hy,hot] at f g ⊢ <;>
      cases h : has r x <;> cases h' : has r y <;> simp_all
  · intro r v neq
    have f := first r v
    have g := second r v
    by_contra! hn
    cases a v <;> cases b v <;> cases side r <;> cases has r v <;> cases has (mate r) v <;> simp_all
end Research.Graph9822Resolution.FirstSwitchRows
#print axioms Research.Graph9822Resolution.FirstSwitchRows.no_tail_pair
