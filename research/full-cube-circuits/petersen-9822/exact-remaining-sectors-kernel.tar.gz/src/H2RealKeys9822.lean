import OR9822ProfileAllKeys
namespace Research.Graph9822H2Check
open Research.Graph9822H2Eligibility
theorem realKeysExclude (j h : Nat) (found : keys[j]?=some h) (q : Nat) :
    ¬ViableTwo h q := realProfileKeysExclude j h found q
end Research.Graph9822H2Check
#print axioms Research.Graph9822H2Check.realKeysExclude
