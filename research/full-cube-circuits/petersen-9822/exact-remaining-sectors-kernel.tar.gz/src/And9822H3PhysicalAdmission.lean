import And9822H3Omissions
import H3FirstAdmission9822
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822FirstAdmission Research.Graph9822H2Check
open Research.Graph9822OneHidden (edges inside contains)
private theorem cell_bit (i j : Fin 16) (e : Fin 13)
    (h : (cell i.val j.val).testBit e.val=true) : (nm i ||| nm j) &&& pm e=pm e := by
  have hi : e.val<edges.length := e.isLt
  have pe : pm e=edges[e.val]! := by simp [pm,rawRow,e.isLt]
  have nn (k : Fin 16) : nm k=Research.Graph9822.FourSaturation.witnesses[k.val]! := by
    simp [nm,rawRow]
  simpa [pe,nn,cell,inside,contains,test_edgeMask,List.getElem?_eq_getElem hi,getElem!_pos edges e.val hi] using h

theorem original_admitted (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B])
    (skip : Fin 7) (unused : ¬reads R A B skip 11) : firstAdmitted (encode (firstCol H))=true := by
  apply firstAdmitted_of
  intro a b ab
  obtain ⟨i,j,ij,ia,ib,ja,jb,band⟩ := omitted_physical c H Q R A B hh ht skip unused a b ab
  refine ⟨i,j,ij,ia,ib,ja,jb,compatible_of i j ij ?_⟩
  intro e hot
  obtain ⟨x,y,z⟩ := band e (cell_bit i j e hot)
  rw [pos_col_bit,neg_col_bit,neg_col_bit]
  exact ⟨(encode_bit _ ⟨e.val,by omega⟩).symm.trans x,
    (encode_bit _ ⟨13+i.val,by omega⟩).symm.trans y,
    (encode_bit _ ⟨13+j.val,by omega⟩).symm.trans z⟩
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.original_admitted
