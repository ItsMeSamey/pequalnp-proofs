import H2FastStep9822
namespace Research.Graph9822H2Check
def centers : List Nat := do
  let x ← vs
  let y ← vs
  guard (x < y)
  let z ← vs
  guard (y < z)
  return bit x ||| bit y ||| bit z

def fastInitial (h : Nat) := minimal (do
  let c ← centers
  let base := positive h &&& rawPos (freeRaw (negative h))
  let t := 8191 ^^^ (rawPos c ||| base)
  let use ← [false,true]
  let x ← fastCovers (if use then t &&& (8191 ^^^ positive h) else t)
  let s := demand t (rawNeg x ||| (if use then negative h else 0))
  guard (fastFeasible h s)
  return s)

end Research.Graph9822H2Check
