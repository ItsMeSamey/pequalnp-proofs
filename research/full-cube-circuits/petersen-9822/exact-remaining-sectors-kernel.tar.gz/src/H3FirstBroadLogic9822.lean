import H3FirstBroad9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822H2Check Research.Graph9822FirstAdmission Research.Graph9822OneHidden

theorem full_on (k : Fin 1024) : full.testBit k.val = true := by
  simp [full,Nat.testBit_two_pow_sub_one,k.isLt]

theorem sums_on (xs : List Nat) (k : Nat) :
    (sums xs).testBit k = true ↔ ∃ x ∈ xs, x.testBit k = true := by
  induction xs with
  | nil => simp [sums]
  | cons a xs ih => simpa [sums,Nat.testBit_or] using
      (show (a.testBit k = true ∨ (sums xs).testBit k = true) ↔
        (a.testBit k = true ∨ ∃ x ∈ xs, x.testBit k = true) by rw [ih])

theorem prods_on (xs : List Nat) (k : Fin 1024) :
    (prods xs).testBit k.val = true ↔ ∀ x ∈ xs, x.testBit k.val = true := by
  induction xs with
  | nil => simp [prods,full_on]
  | cons a xs ih => simpa [prods,Nat.testBit_and] using
      (show (a.testBit k.val = true ∧ (prods xs).testBit k.val = true) ↔
        (a.testBit k.val = true ∧ ∀ x ∈ xs, x.testBit k.val = true) by rw [ih])

theorem sums_of_mem {xs : List α} (f : α → Nat) (k : Nat) {x : α}
    (mem : x ∈ xs) (on : (f x).testBit k=true) : (sums (xs.map f)).testBit k=true :=
  (sums_on ..).2 ⟨_,List.mem_map.mpr ⟨x,mem,rfl⟩,on⟩

theorem prods_of_all {xs : List α} (f : α → Nat) (k : Fin 1024)
    (on : ∀ x ∈ xs, (f x).testBit k.val=true) : (prods (xs.map f)).testBit k.val=true := by
  apply (prods_on ..).2
  intro z hz
  obtain ⟨x,hx,rfl⟩ := List.mem_map.mp hz
  exact on x hx

def matchWord (ws : Array Nat) (h : Nat) := prods ((List.range 29).map fun j =>
  if h.testBit j then ws[j]! else full ^^^ ws[j]!)

theorem matchWord_exact {ws : Array Nat} {k : Fin 1024} {h c : Nat}
    (hbd : h < 2^29) (cbd : c < 2^29)
    (reflects : ∀ j < 29, (ws[j]!).testBit k.val = h.testBit j)
    (on : (matchWord ws c).testBit k.val = true) : h = c := by
  apply Nat.eq_of_testBit_eq
  intro j
  by_cases lt : j < 29
  · let f (v : Nat) := if c.testBit v then ws[v]! else full ^^^ ws[v]!
    have hv := (prods_on _ k).1 on (f j) (List.mem_map.mpr ⟨j,List.mem_range.mpr lt,rfl⟩)
    cases v : c.testBit j <;> simpa [f,v,Nat.testBit_xor,full_on,reflects j lt] using hv
  · have hi : 2^29 ≤ 2^j := Nat.pow_le_pow_right (by decide : 0 < (2:Nat)) (by omega)
    rw [Nat.testBit_lt_two_pow (lt_of_lt_of_le hbd hi),Nat.testBit_lt_two_pow (lt_of_lt_of_le cbd hi)]

end Research.Graph9822FirstBroad
