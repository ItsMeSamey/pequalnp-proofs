import CompactPriorSelected25Cell05
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row7_0_seg9 : CutRow book 7 9 3 := bandCut 7 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
