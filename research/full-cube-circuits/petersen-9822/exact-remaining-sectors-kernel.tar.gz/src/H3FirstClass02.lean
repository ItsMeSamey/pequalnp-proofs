import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class008 : runPacket packets[8]! = true := by decide +kernel
theorem class009 : runPacket packets[9]! = true := by decide +kernel
theorem class010 : runPacket packets[10]! = true := by decide +kernel
theorem class011 : runPacket packets[11]! = true := by decide +kernel
end Research.Graph9822FirstBroad
