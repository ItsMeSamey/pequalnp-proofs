import H2QuadPairList9822
import H2ShortDomTransport9822
import H2ShortDom03069822
import H2ShortDom03079822
import H2ShortDom03099822
import H2ShortDom03109822
import H2ShortDom03119822
import H2ShortDom04059822
import H2ShortDom04069822
namespace Research.Graph9822H2Check
def keys4 : List (Nat × Nat) := [(3,6), (3,7), (3,9), (3,10), (3,11), (4,5), (4,6)]
theorem paidKeys4 : keys4.all (fun p => pairDom p.1 p.2)=true := by
  simp only [keys4,List.all_cons,List.all_nil,Bool.and_eq_true_iff]
  exact ⟨dom_of_short (by decide) short_dom_3_6, dom_of_short (by decide) short_dom_3_7, dom_of_short (by decide) short_dom_3_9, dom_of_short (by decide) short_dom_3_10, dom_of_short (by decide) short_dom_3_11, dom_of_short (by decide) short_dom_4_5, dom_of_short (by decide) short_dom_4_6, True.intro⟩
end Research.Graph9822H2Check
