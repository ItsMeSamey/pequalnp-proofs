import And9822H2PhysicalTrace
namespace Research.Graph9822.H2Trace
open Research.Graph9822.FreeOR Research.Graph9822.FeatureRun Research.Graph9822.FourSaturation
open Research.Graph9822.ReverseChannel (demand)
def neg (i : Fin 16) : Fin 1024 :=
  let r : Fin 29 := ⟨13+i.val,by omega⟩
  ⟨rawRow r,(row_extrema r).1⟩
def edge (i : Fin 13) : Fin 1024 :=
  let r : Fin 29 := ⟨i.val,by omega⟩
  ⟨rawRow r,(row_extrema r).1⟩
def covers (i j : Fin 16) (e : Fin 13) : Prop :=
  ∀ k : Fin 10, fullWire (edge e).val k=true →
    fullWire (neg i).val k=true ∨ fullWire (neg j).val k=true
instance (i j e) : Decidable (covers i j e) := by unfold covers; infer_instance
set_option maxRecDepth 8192 in
set_option maxHeartbeats 8000000 in
private theorem covers_some : ∀ i j : Fin 16, i<j → ∃ e, covers i j e := by
  decide +kernel
private theorem neg_false : ∀ i, accepts (neg i).val=false := by decide
private theorem edge_true : ∀ i, accepts (edge i).val=true := by decide

theorem occupied (C : FiveProgram) (h q a b c : Product)
    (hh : (hiddenFirst C).1=[h,q]) (ht : (hiddenFirst C).2=[a,b,c]) :
    ∃ i j : Fin 16, i<j ∧
      productBit (fullWire (neg i).val) h=false ∧ productBit (fullWire (neg j).val) h=false ∧
      ∀ e : Fin 13, covers i j e → productBit (fullWire (edge e).val) h=true := by
  classical
  let M := tr h q a b c
  let V := env h q a b c
  obtain ⟨cap,cold,rerun⟩ := cubes C h q a b c hh ht
  have pairs : ∃ i j : Fin 16, i<j ∧ M (neg i)=M (neg j) := by
    by_contra! bad
    have inj : Function.Injective (fun i => M (neg i)) := by
      intro i j eq
      rcases lt_trichotomy i j with lt | eq' | gt
      · exact False.elim (bad i j lt eq)
      · exact eq'
      · exact False.elim (bad j i gt eq.symm)
    have sub : Finset.univ.image (fun i => M (neg i)) ⊆ Finset.univ.image M := by
      intro r hr
      obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hr
      exact Finset.mem_image_of_mem _ (Finset.mem_univ _)
    have small := (Finset.card_le_card sub).trans cap
    rw [Finset.card_image_of_injective _ inj] at small
    simpa using small
  obtain ⟨i,j,lt,same⟩ := pairs
  let hot (m : Fin 1024) := productBit (fullWire m.val) h
  have obstruction (e : Fin 13) (cov : covers i j e) :
      ¬ (hot (edge e)=true → hot (neg i)=true ∨ hot (neg j)=true) := by
    intro hc
    have rejected := rerun (neg i) (edge e) (by
      intro k kl rd
      have left := cold (neg i) (neg_false i) k kl rd
      have right := cold (neg j) (neg_false j) k kl (by
        change demand _ (M (neg j)) k
        rw [←same]; exact rd)
      change V (edge e) k=false
      cases ek : V (edge e) k with
      | false => rfl
      | true =>
        have poss : V (neg i) k=true ∨ V (neg j) k=true := by
          by_cases raw : k<10
          · have ie := (leaf h q a b c (edge e)).1 k raw
            have il := (leaf h q a b c (neg i)).1 k raw
            have ir := (leaf h q a b c (neg j)).1 k raw
            exact (cov ⟨k,raw⟩ (ie.symm.trans ek)).imp (fun v=>il.trans v) (fun v=>ir.trans v)
          · have z : k=10 := by omega
            subst k
            have ie := (leaf h q a b c (edge e)).2
            exact (hc (ie.symm.trans ek)).imp (fun v=>(leaf h q a b c (neg i)).2.trans v)
              (fun v=>(leaf h q a b c (neg j)).2.trans v)
        rcases poss with l|r
        · exact Bool.noConfusion (left.symm.trans l)
        · exact Bool.noConfusion (right.symm.trans r))
    exact Bool.noConfusion ((edge_true e).symm.trans rejected)
  obtain ⟨e,covered⟩ := covers_some i j lt
  have clash := obstruction e covered
  refine ⟨i,j,lt,?_,?_,?_⟩
  · cases val : hot (neg i) with
    | false => exact val
    | true => exact False.elim (clash (fun _=> Or.inl val))
  · cases val : hot (neg j) with
    | false => exact val
    | true => exact False.elim (clash (fun _=> Or.inr val))
  · intro v cov
    cases val : hot (edge v) with
    | false => exact False.elim (obstruction v cov (fun eq=> Bool.noConfusion (val.symm.trans eq)))
    | true => exact val
end Research.Graph9822.H2Trace
#print axioms Research.Graph9822.H2Trace.occupied
