import CompactPriorSelected06
-- CompactPriorFace07
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B189_8
def entries : List (Nat × Nat) := [(29,4),(57,4),(156,4),(165,4),(172,4),(177,4)]
theorem prior : Known true entries := (consFace h29_4 (consFace h57_4 (consFace h156_4 (consFace h165_4 (consFace h172_4 (consFace h177_4 (known_down baseKnown)))))))
def samples : Nat → Bits × Bits := (fun i => (if i<8 then tableBits #[(padColumn 84 0xe4003ffc00007ff8430f0,padColumn 84 0xe010e55410c07a9043050),(padColumn 84 0x0,padColumn 84 0x0),(padColumn 84 0x3c0fc0000fc3e3183f303,padColumn 84 0x1c2a430c2343431816101),(padColumn 84 0xe8000003ffcc0c07ff00f,padColumn 84 0xe0c10c115c8c0c0569006),(padColumn 84 0x5c0000fff03180ffc403c,padColumn 84 0x1f0610aaa131806a84028),(padColumn 84 0x9ff03f00003e1f2198cc0,padColumn 84 0x1d681a20c62a052198480),(padColumn 84 0x0,padColumn 84 0x0),(padColumn 84 0xf3ffc000003ff0c620f00,padColumn 84 0xe295a0c30814b0c620a00)] i else tableBits #[(padColumn 84 0x0,padColumn 84 0x0),(padColumn 84 0x0,padColumn 84 0x0)] i))
def cols : List ColumnInfo := [(12,0,177,0,4),(17,0,172,0,4),(24,0,165,0,4),(33,0,156,0,4),(132,0,57,0,4),(160,0,29,0,4)]
def data7 : Nat → Nat := (fun i => tableWord #[0x3f,0x171506] i)
def data6 : Nat → Nat := (fun i => tableWord #[0x7f420,0x0,0x7f440,0x201] i)
def data5 : Nat → Nat := (fun i => tableWord #[0xb7cc3440,0x0] i)
def levels : Nat → Packing
  | 5 => (1,2,3,0,0,0,0,data5)
  | 6 => (2,1,3,0,0,0,0,data6)
  | 7 => (1,0,3,0,0,0,0,data7)
  | _ => (0,0,0,0,0,0,0,fun _ => 0)
def index : Nat → Nat → Option (Nat × Nat)
  | 6 => fun v => (if v=7502621870530246385 then some (0,0) else none)
  | 7 => fun h => smallSlot h 4 14 2 4 (fun i => ((fun i => tableWord #[0x2000] i) (i/16) >>> (4*(i%16))) % 16) (fun i => ((fun i => tableWord #[0xa200000010346416663cd6000009cca] i) (i/16) >>> (9*(i%16))) % 512)
  | _ => fun _ => none
def book : Forest := ⟨189,7,samples,cols,[[],[115,84],[32,67,117],[32,83,116],[48,82],[48,82,112,66],[64,114,50,48,80],[64,114,83],[80,50,116],[80,50,66,32,114],[112,66],[112,66,48,82]],levels,index⟩
end B189_8
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace08
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B189_8
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B189_8
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace09
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B189_8
set_option maxRecDepth 16000 in
theorem row7_0 : CutRow book 7 0 1 := bandCut 6 false (by decide +kernel)
end B189_8
end PEqualNP.Outside.L_meta_9825.Engine
