import H2ShortDomCheck9822
namespace Research.Graph9822H2Check
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem short_dom_3_7 : shortDominated 3 7=true := by decide +kernel
end Research.Graph9822H2Check
