import H2LocalCover9822
namespace Research.Graph9822H2Check

def rootCovered (bad : Nat → Bool) (roots : List Nat) (s : Nat) : Bool :=
  bad s || roots.any (fun r => sub r s)

theorem seeded_root {q s : Nat} {roots : List Nat} {bad : Nat → Bool}
    (check : rootCovered bad roots s = true) (noWitness : ∀ t, bad t = true → ¬holds q t)
    (live : holds q s) : ∃ r ∈ roots, holds q r := by
  rcases Bool.or_eq_true_iff.mp check with no | yes
  · exact (noWitness s no live).elim
  · obtain ⟨r,mem,sub⟩ := List.any_eq_true.mp yes
    exact ⟨r,mem,weaker_holds sub live⟩

end Research.Graph9822H2Check
