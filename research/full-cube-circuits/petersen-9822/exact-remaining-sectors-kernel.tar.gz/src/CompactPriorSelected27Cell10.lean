import CompactPriorSelected27Cell09
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row7_64_seg70 : CutRow book 7 70 3 := bandCut 8 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
