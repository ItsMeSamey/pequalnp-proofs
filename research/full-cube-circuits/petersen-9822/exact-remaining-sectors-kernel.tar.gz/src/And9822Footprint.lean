import Mathlib.Data.Finset.Card
namespace Research.Graph9822.Footprint
abbrev Dir := Nat → Bool
abbrev Trace := List (Nat × Bool)
abbrev Channel := Nat → Option Bool
def active (c : Channel) (r : Trace) := r.any (fun t => c t.1 == some t.2)
def Fits (w : Dir) (r : Trace) := ∀ t ∈ r, w t.1=t.2
def avoid (c : Channel) : Dir := fun i => !(c i).getD false
theorem inactive (c : Channel) {r} (hc : Fits (avoid c) r) : active c r = false := by
  cases e : active c r
  · rfl
  · obtain ⟨⟨i,b⟩,mem,hit⟩ := List.any_eq_true.mp e
    have eq := hc (i,b) mem
    cases h : c i with
    | none => simp [h] at hit
    | some v => cases v <;> cases b <;> simp_all [avoid]
def next (i : Nat) (a : Trace → Bool) (S : Finset Trace) : Finset Trace :=
  (S.filter fun r => !(a r)) ∪
    ((S.filter (fun r => a r = true)).image (fun r => (i,false)::r) ∪ (S.filter (fun r => a r = true)).image (fun r => (i,true)::r))
theorem bound (i : Nat) (a : Trace → Bool) (S : Finset Trace) :
    (next i a S).card + (S.filter fun r => !(a r)).card ≤ 2*S.card := by
  let Y := S.filter (fun r => a r = true)
  let N := S.filter fun r => !(a r)
  have total : Y.card + N.card = S.card := by
    simpa [Y,N] using Finset.card_filter_add_card_filter_not (s:=S) (fun r => a r=true)
  let L := Y.image (fun r => (i,false)::r)
  let R := Y.image (fun r => (i,true)::r)
  have one := Finset.card_union_le N (L ∪ R)
  have two := Finset.card_union_le L R
  have left : L.card ≤ Y.card := Finset.card_image_le
  have right : R.card ≤ Y.card := Finset.card_image_le
  change (N ∪ (L ∪ R)).card + N.card ≤ _
  omega
theorem conditional_bound (i : Nat) (c : Channel) (S : Finset Trace)
    (rep : ∀ w, ∃ r ∈ S, Fits w r) : (next i (active c) S).card + 1 ≤ 2*S.card := by
  obtain ⟨r,mem,ok⟩ := rep (avoid c)
  have h : r ∈ S.filter (fun t => !(active c t)) := Finset.mem_filter.mpr
    ⟨mem,by simp [inactive c ok]⟩
  have pos := Finset.card_pos.mpr (show (S.filter fun t => !(active c t)).Nonempty from ⟨r,h⟩)
  have hb := bound i (active c) S
  omega
end Research.Graph9822.Footprint
#print axioms Research.Graph9822.Footprint.conditional_bound
