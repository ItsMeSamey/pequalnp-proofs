import And9822FreeORDefs
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
set_option maxHeartbeats 160000
theorem flatten_count (gs : List Gate) (i k : Nat) (env : Env) (out : Nat) :
    (flatten gs i k env out).1.length = gs.countP Gate.isAnd := by
  induction gs generalizing i k env with
  | nil => rfl
  | cons g gs ih =>
    cases h : g.isAnd <;> simp only [flatten,h,Bool.false_eq_true,if_false,if_true,List.length_cons,List.countP_cons,ih] <;> simp [h]
theorem flatten_spec (gs : List Gate) (i k : Nat) (env : Env) (out : Nat) (bound : Bounded k env) :
    let q := flatten gs i k env out
    Chronological k q.1 q.2 ∧ ∀ w : Wire,
      readArm (run q.1 k w) q.2 = eval gs i (fun j => readArm w (env j)) out := by
  induction gs generalizing i k env with
  | nil => exact ⟨bound out,fun _ => rfl⟩
  | cons g gs ih =>
    cases op : g.isAnd
    · let env' := Function.update env i (env g.left ++ env g.right)
      have bd : Bounded k env' := by
        intro j t ht
        by_cases e : j=i
        · subst j
          simp [env'] at ht
          exact ht.elim (bound g.left t) (bound g.right t)
        · exact bound j t (by simpa [env',e] using ht)
      obtain ⟨ordered,sound⟩ := ih (i+1) k env' bd
      simp only [flatten,op,Bool.false_eq_true,if_false]
      refine ⟨ordered,fun w => ?_⟩
      rw [sound]
      have eq : (fun j => readArm w (env' j)) = Function.update (fun j => readArm w (env j)) i
          (step g (readArm w (env g.left)) (readArm w (env g.right))) := by
        funext j
        by_cases e : j=i <;> simp [env',e,step,op,readArm]
      exact congrArg (fun v => eval gs (i+1) v out) eq
    · let env' := Function.update env i [k]
      have bd : Bounded (k+1) env' := by
        intro j t ht
        by_cases e : j=i
        · subst j
          simp [env'] at ht
          omega
        · have prior := bound j t (by simpa [env',e] using ht)
          omega
      obtain ⟨ordered,sound⟩ := ih (i+1) (k+1) env' bd
      simp only [flatten,op,if_true]
      refine ⟨⟨bound _,bound _,ordered⟩,fun w => ?_⟩
      simp only [run]
      rw [sound]
      apply congrArg (fun v => eval gs (i+1) v out)
      funext j
      by_cases e : j=i
      · subst j
        simp [env',step,op,readArm,productBit]
      · simp only [Function.update_of_ne e,env']
        unfold readArm
        apply Bool.eq_iff_iff.mpr
        simp only [List.any_eq_true]
        constructor
        · rintro ⟨x,hx,hv⟩
          exact ⟨x,hx,by simpa [Function.update_of_ne (Nat.ne_of_lt (bound j x hx))] using hv⟩
        · rintro ⟨x,hx,hv⟩
          exact ⟨x,hx,by simpa [Function.update_of_ne (Nat.ne_of_lt (bound j x hx))] using hv⟩
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.flatten_spec
