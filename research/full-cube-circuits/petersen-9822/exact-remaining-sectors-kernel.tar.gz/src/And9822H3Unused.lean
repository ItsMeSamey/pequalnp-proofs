import And9822H3OriginalRoot
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822.ReverseChannel Research.Graph9822Resolution
open Research.Graph9822.FeatureRun Research.Graph9822FirstAdmission

theorem unused_slot (R A B : Product) (ra : Apart R) (aa : Apart A) (ba : Apart B) :
    ∃ d,¬reads R A B d 11 := by
  have ordinary (p : Product) (apart : Apart p) : ∃ t,11∉arm p t := by
    by_cases l : 11∈p.1
    · exact ⟨true,apart 11 l⟩
    · exact ⟨false,l⟩
  have oriented (p : Product) (sep : Apart p) : ∃ b,11∉side p b := by
    obtain ⟨t,avoid⟩ := ordinary p sep
    by_cases l : 12∈p.1
    · exact ⟨!t,by simpa [side,l] using avoid⟩
    · exact ⟨t,by simpa [side,l] using avoid⟩
  have noLast (p : Product) (sep : Apart p) : 12∉side p false := by
    by_cases l : 12∈p.1 <;> simp [side,arm,l,sep 12] at *
  obtain ⟨a,x⟩ := oriented A aa
  obtain ⟨b,y⟩ := oriented B ba
  obtain ⟨t,z⟩ := ordinary R ra
  refine ⟨code a b t,?_⟩
  cases a <;> cases b <;> cases t <;>
    simp [reads,sides,code,x,y,z,noLast A aa,noLast B ba]

theorem listed_original (c : MaximumFive) (H Q R A B : Product)
    (hh : (hiddenFirst c.toFiveProgram).1=[H,Q,R]) (ht : (hiddenFirst c.toFiveProgram).2=[A,B])
    (checked : ∀ i : Fin 1024,rowOK i.val=true) :
    roots[rootIndex (encode (firstCol H))]? = some (encode (firstCol H)) := by
  obtain ⟨_,ha,ta⟩ := hidden_first_shape c.toFiveProgram
  apply original_root c H Q R A B hh ht _ checked
  exact unused_slot _ _ _ (ha R (by simp [hh])) (ta A (by simp [ht])).1 (ta B (by simp [ht])).1
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.listed_original
