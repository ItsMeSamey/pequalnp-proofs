import OR9822H2Checker
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden
def negColumns : Array Nat := #[52530, 22289, 43150, 15414, 713, 12301, 110, 880, 50048, 64512]
def cachedNeg (h u : Nat) : Nat :=
  if u < 10 then negColumns[u]! else fixedNeg h u
theorem cachedNeg_eq (h u : Nat) : cachedNeg h u = fixedNeg h u := by
  by_cases small : u < 10
  · have finite : u = 0 ∨ u = 1 ∨ u = 2 ∨ u = 3 ∨ u = 4 ∨ u = 5 ∨ u = 6 ∨ u = 7 ∨ u = 8 ∨ u = 9 := by omega
    rcases finite with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> rfl
  · simp [cachedNeg,small]
def cachedPairDemand (h i j a b c d : Nat) : Option Nat := do
  let pairs := [(a,c),(a,d),(b,c),(b,d)]
  guard (pairs.all fun (u,v) =>
    if u == 11 then v != 11 else v == 11 || !meets (cachedNeg h u) (cachedNeg h v))
  let forbidden := pairs.foldl (fun f (u,v) =>
    f ||| (if u == 11 then cachedNeg h v else if v == 11 then cachedNeg h u else 0)) 0
  let t := (if a == 11 || c == 11 then bit i else 0) |||
           (if b == 11 || d == 11 then bit j else 0)
  return demand t forbidden

def cachedRescue (h i j : Nat) := minimal (do
  let a ← labels h i
  let b ← labels h j
  let c ← labels h i
  let d ← labels h j
  (cachedPairDemand h i j a b c d).toList)


theorem cachedPairDemand_eq (h i j a b c d : Nat) :
    cachedPairDemand h i j a b c d = pairDemand h i j a b c d := by
  simp only [cachedPairDemand,pairDemand,cachedNeg_eq]
theorem cachedRescue_eq (h i j : Nat) : cachedRescue h i j = rescue h i j := by
  simp only [cachedRescue,rescue,cachedPairDemand_eq]
end Research.Graph9822H2Check
