import H3RegionEngine9822
namespace Research.H3RegionEngine

def forest [DecidableEq α] (r : Rules α) (fuel : Nat) (keys : List α) (hints : List Nat) : Bool :=
  match runList (walk r fuel) keys ⟨[],hints⟩ with
  | some t => t.hints.isEmpty
  | none => false

theorem forestSound [DecidableEq α] (r : Rules α) (P : α → Prop)
    (dead : ∀ k, r.dead k = true → P k)
    (step : ∀ k h cs, r.step k h = some cs → (∀ c ∈ cs, P c) → P k)
    {fuel keys hints} (ok : forest r fuel keys hints = true) : ∀ k ∈ keys, P k := by
  have run : ∀ ks (s t : State α), Good P s →
      runList (walk r fuel) ks s = some t → (∀ k ∈ ks, P k) ∧ Good P t := by
    intro ks
    induction ks with
    | nil =>
      intro s t hg h
      have eq : s = t := Option.some.inj h
      subst t
      exact ⟨by simp,hg⟩
    | cons k ks ih =>
      intro s t hg h
      cases e : walk r fuel k s with
      | none => simp [runList,e] at h
      | some u =>
        have hk := walkSound r P dead step fuel k s u hg e
        have tail := ih u t hk.2 (by simpa [runList,e] using h)
        exact ⟨by simpa using And.intro hk.1 tail.1,tail.2⟩
  cases e : runList (walk r fuel) keys ⟨[],hints⟩ with
  | none => simp [forest,e] at ok
  | some t => exact (run keys _ t (by intro k h; simp at h) e).1

end Research.H3RegionEngine
