import H23TernaryRows9822
import H23TernaryPlanes9822
import OR9822H2NestedPhysical
namespace Research.Graph9822Planes
open Research.Graph9822Ternary Research.Graph9822H2Check Research.Graph9822.FeatureRun
open Research.Graph9822OneHidden (meets)

theorem srcMatches : ∀ r : Fin 29, srcRows[r.val]! = rawRow r := by decide +kernel

theorem physicalQWord {h q A B : Nat} {u : Bool} (physical : NestedBits h q A B u)
    (apart : meets A B=false)
    (aBits : ∀ v<10, (axis v 1).testBit (ternaryLane A B).val =
      (trit (ternaryLane A B).val v == 1))
    (bBits : ∀ v<10, (axis v 2).testBit (ternaryLane A B).val =
      (trit (ternaryLane A B).val v == 2)) (r : Fin 29) :
    (qWord h u r.val).testBit (ternaryLane A B).val = q.testBit r.val := by
  unfold qWord
  rw [srcMatches r]
  exact rowQAt physical apart (fun v => axis v 1) (fun v => axis v 2) aBits bBits r

theorem physicalQLane (H Q : Research.Graph9822.FreeOR.Product) (apart : Research.Graph9822.FreeOR.Apart Q)
    (aBits : ∀ (j : Fin 59049) v, v<10 → (axis v 1).testBit j.val = (trit j.val v == 1))
    (bBits : ∀ (j : Fin 59049) v, v<10 → (axis v 2).testBit j.val = (trit j.val v == 2)) :
    ∃ (j : Fin 59049) (u : Bool), ∀ r : Fin 29,
      (qWord (encode (firstCol H)) u r.val).testBit j.val = (encode (secondCol H Q)).testBit r.val := by
  obtain ⟨A,B,u,sem,_,dis⟩ := physical_nested_bits H Q apart
  exact ⟨ternaryLane A B,u,physicalQWord sem dis (aBits _) (bBits _)⟩

end Research.Graph9822Planes
