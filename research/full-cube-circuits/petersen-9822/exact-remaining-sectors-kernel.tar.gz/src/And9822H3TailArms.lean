import And9822H3Directions
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822.ReverseChannel Research.Graph9822Resolution

/-- If two distinct physical directions always have different feature supports,
both terminal products really read the last hidden output on their true side. -/
theorem both_read (R A B : Product) (aa : Apart A) (ba : Apart B)
    (distinct : ∀ i j : Fin 7, i≠j → ¬(∀ f, reads R A B i f ↔ reads R A B j f)) :
    12∈side A true ∧ 12∈side B true := by
  have unused (p : Product) (sep : Apart p) : 12∉side p false := by
    by_cases l : 12∈p.1 <;> simp [side,arm,l,sep 12] at *
  constructor
  · by_contra h
    apply distinct 3 4 (by decide)
    intro f
    change (_ ∧ (_ ∨ _ ∨ (12∈side A true ∨ 12∈side B false) ∧ _)) ↔
      (_ ∧ (_ ∨ _ ∨ (12∈side A true ∨ 12∈side B false) ∧ _))
    simp [sides,h,unused B ba]
  · by_contra h
    apply distinct 1 2 (by decide)
    intro f
    change (_ ∧ (_ ∨ _ ∨ (12∈side A false ∨ 12∈side B true) ∧ _)) ↔
      (_ ∧ (_ ∨ _ ∨ (12∈side A false ∨ 12∈side B true) ∧ _))
    simp [sides,h,unused A aa]

theorem tail_reads (R A B : Product) (aa : Apart A) (ba : Apart B)
    (activeA : 12∈side A true) (activeB : 12∈side B true) (d : Fin 7) (j : Nat) :
    reads R A B d j ↔ j<12 ∧ (j∈side A (sides d).1 ∨ j∈side B (sides d).2.1 ∨
      d≠0 ∧ j∈arm R (sides d).2.2) := by
  have neg (p : Product) (sep : Apart p) : 12∉side p false := by
    by_cases l : 12∈p.1 <;> simp [side,arm,l,sep 12] at *
  fin_cases d <;> simp [reads,sides,activeA,activeB,neg A aa,neg B ba]
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.tail_reads
