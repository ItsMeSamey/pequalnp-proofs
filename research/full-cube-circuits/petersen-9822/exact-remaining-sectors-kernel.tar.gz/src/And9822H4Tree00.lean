import And9822H4Tree
namespace Research.Graph9822.H4Tree
theorem t0 {p : Bad} (legal : Respects p) (ok : Within p 210624583337880668665094514136345777473658732882858158354331599104) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t1 {p : Bad} (legal : Respects p) (ok : Within p 3558712960063887517934626615724439529911070749386650418110754417803520) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t2 {p : Bad} (legal : Respects p) (ok : Within p 3558719542082116802712027183206240583573795507901632936138324509204608) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t3 {p : Bad} (legal : Respects p) (ok : Within p 3558719542082116802758795235601169759323234361012017367409930490880384) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t1 legal) (t2 legal)
theorem t4 {p : Bad} (legal : Respects p) (ok : Within p 3558930166665454683379961526901711477892167324218157652786301118718336) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t0 legal) (t3 legal)
theorem t5 {p : Bad} (legal : Respects p) (ok : Within p 108050411251943504814300087671675632212133582391330564546399823724800) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t6 {p : Bad} (legal : Respects p) (ok : Within p 210624583337880621166269348245663765350808258098202358857164914688) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t7 {p : Bad} (legal : Respects p) (ok : Within p 107846368686834908993918412002525468800764023725224453851119225938048) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t8 {p : Bad} (legal : Respects p) (ok : Within p 108056993270172789615084681350771132566114831983322656209976390852736) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t6 legal) (t7 legal)
theorem t9 {p : Bad} (legal : Respects p) (ok : Within p 108056993270172789638468707548405861624294727808025490994860241461632) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t5 legal) (t8 legal)
theorem t10 {p : Bad} (legal : Respects p) (ok : Within p 3558930166665454683403345553447455068310467277838479859511634658599296) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t4 legal) (t9 legal)
theorem t11 {p : Bad} (legal : Respects p) (ok : Within p 24016125678089299080935582749693879329588958554226688) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t12 {p : Bad} (legal : Respects p) (ok : Within p 22649194342257664128122213870658492154511360) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t13 {p : Bad} (legal : Respects p) (ok : Within p 3450873173395281893717378020385049663313929651431456888686524265136128) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t14 {p : Bad} (legal : Respects p) (ok : Within p 3450873173395281893717378043034244005571593779553670759345016419647488) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t12 legal) (t13 legal)
theorem t15 {p : Bad} (legal : Respects p) (ok : Within p 3450873173395281917662620757168026138074729275962186097274458122223616) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t16 {p : Bad} (legal : Respects p) (ok : Within p 3450873173395281917662620869063757417420766093550585008277662631723008) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t14 legal) (t15 legal)
theorem t17 {p : Bad} (legal : Respects p) (ok : Within p 3450873173395281917733503698474348744249509925245257656557454086897664) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t11 legal) (t16 legal)
theorem t18 {p : Bad} (legal : Respects p) (ok : Within p 3558930166665454707348588379477011015455504699432960940826980788478336) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t10 legal) (t17 legal)
theorem t19 {p : Bad} (legal : Respects p) (ok : Within p 47681490918260992750594223812854909963487145918720) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t20 {p : Bad} (legal : Respects p) (ok : Within p 23386880693020141059071650815973087796824480153856) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t21 {p : Bad} (legal : Respects p) (ok : Within p 71068371610940851361615297750755635614081639022848) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t19 legal) (t20 legal)
theorem t22 {p : Bad} (legal : Respects p) (ok : Within p 47681490917920710302543646934782547781522963857408) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t23 {p : Bad} (legal : Respects p) (ok : Within p 23386880692679858611021073895399427304767686180864) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t24 {p : Bad} (legal : Respects p) (ok : Within p 71068371610600568913564720830181975086290650038272) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t22 legal) (t23 legal)
theorem t25 {p : Bad} (legal : Respects p) (ok : Within p 42537892013546771324945130817234927616) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t26 {p : Bad} (legal : Respects p) (ok : Within p 71068371610643104209429838334093105951859720355840) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t24 legal) (t25 legal)
theorem t27 {p : Bad} (legal : Respects p) (ok : Within p 188894659349970180636672) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t28 {p : Bad} (legal : Respects p) (ok : Within p 71068371610643104209429838334093105987044092444672) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t26 legal) (t27 legal)
theorem t29 {p : Bad} (legal : Respects p) (ok : Within p 71068371610983386657480415212165468133274079494400) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t21 legal) (t28 legal)
theorem t30 {p : Bad} (legal : Respects p) (ok : Within p 13483264342689974282955523526408041808267626399001794090768355328000) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t31 {p : Bad} (legal : Respects p) (ok : Within p 13483264342689974353107602118674199544830554329674334817584037265664) : Success p :=
  fork legal ok 14 (by decide +kernel) (by decide +kernel) (t29 legal) (t30 legal)
theorem t32 {p : Bad} (legal : Respects p) (ok : Within p 3572413431008144681630813152184753605804670483415604593407371421720960) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t18 legal) (t31 legal)
theorem t33 {p : Bad} (legal : Respects p) (ok : Within p 210624635123969938106385301782065146694008066729819769861344329984) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t34 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446111026597833711908206891205719534449197312) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t35 {p : Bad} (legal : Respects p) (ok : Within p 13479986189079673969255711890265731072184482626220040304324769742848) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t36 {p : Bad} (legal : Respects p) (ok : Within p 13479986239296487852349158001292328824766752418502258485061000102144) : Success p :=
  fork legal ok 14 (by decide +kernel) (by decide +kernel) (t34 legal) (t35 legal)
theorem t37 {p : Bad} (legal : Respects p) (ok : Within p 13690610824203643907362097192047796218878490692949860074186114072832) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t33 legal) (t36 legal)
theorem t38 {p : Bad} (legal : Respects p) (ok : Within p 911111818878429838065402969724487216800487107108156756150105659733704704) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t39 {p : Bad} (legal : Respects p) (ok : Within p 911084437669688721244922350676792823392323423682596407889676385923366912) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t40 {p : Bad} (legal : Respects p) (ok : Within p 911111818865522547622014107403849880115928326179709779382637412621615104) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t41 {p : Bad} (legal : Respects p) (ok : Within p 883504833478360292472275083954719909845839162640453512821098684503687168) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t42 {p : Bad} (legal : Respects p) (ok : Within p 53919893334302812084874896062897619694301439154264763842066900975616) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t43 {p : Bad} (legal : Respects p) (ok : Within p 883504833478360292472275083954719909845839162640453512821239421992042496) : Success p :=
  fork legal ok 18 (by decide +kernel) (by decide +kernel) (t41 legal) (t42 legal)
theorem t44 {p : Bad} (legal : Respects p) (ok : Within p 911111818865522547622014107403849880115928326179709779382778150109970432) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t40 legal) (t43 legal)
theorem t45 {p : Bad} (legal : Respects p) (ok : Within p 911111818865522547645959350229879436063073363596395360505150500040212480) : Success p :=
  fork legal ok 17 (by decide +kernel) (by decide +kernel) (t39 legal) (t44 legal)
theorem t46 {p : Bad} (legal : Respects p) (ok : Within p 911111818878429838089348212550516778064544127664505828887847263193661440) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t38 legal) (t45 legal)
theorem t47 {p : Bad} (legal : Respects p) (ok : Within p 911125509476346751289866712327071483859292242087088310365224686154285312) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t37 legal) (t46 legal)
theorem t48 {p : Bad} (legal : Respects p) (ok : Within p 27606985387162255149739023449108575014970935318883415703415660222611456) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t49 {p : Bad} (legal : Respects p) (ok : Within p 27606985387212471963622116895218878512693810632975348750754316703236096) : Success p :=
  leaf ok 3 (by decide +kernel)
end Research.Graph9822.H4Tree
