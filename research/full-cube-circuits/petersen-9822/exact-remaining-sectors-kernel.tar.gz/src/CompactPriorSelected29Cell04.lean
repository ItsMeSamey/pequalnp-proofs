import CompactPriorSelected29Cell03
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row6_0_seg3 : CutRow book 6 3 3 := bandCut 7 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
