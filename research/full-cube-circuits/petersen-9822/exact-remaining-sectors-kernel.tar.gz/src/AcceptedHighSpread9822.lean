import AcceptedHighOrEntry9822
import AllHighPairsExcluded9822
import SoleHotReaderCandidate9822
import MixedNineCandidate9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport OuterNet LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean FreeAndNet Research.OddOr Research.OddOr.Graph9822 Research.OddOr.Envelope

theorem other_guard_cold {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (hs : innerValue pre g (SignedClamp.singleton s)=true) :
    ∀j : Fin 10,j≠s → j≠9 → innerValue pre g (SignedClamp.singleton j)=false := by
  intro j ne nine
  by_contra! non
  have hj : innerValue pre g (SignedClamp.singleton j)=true := by simpa using non
  by_cases lo : j.val≤4
  · exact low_hot_impossible r (by omega) j lo hj cand
  have n9 : j.val≠9 := fun e => nine (Fin.ext e)
  have ns : j.val≠s.val := fun e => ne (Fin.ext e)
  by_cases less : j.val<s.val
  · exact no_two_high_singletons r cand red seven j s (by omega) less su hj hs
  · exact no_two_high_singletons r cand red seven s j sl (by omega) (by omega) hs hj

theorem high_model_eight {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    ∃u : Net (Fin 10),u.cost≤8 ∧ ∀ x,u.eval x=outerValue pre post C.output x true := by
  obtain ⟨q,m,op,pin⟩ := accepted_high_or_entry r cand red seven s sl su upper
  obtain ⟨i,site⟩ := List.mem_iff_getElem?.mp m
  obtain ⟨mid,tail,full,_⟩ := split_at post i q site
  subst post
  exact or_reader_model r cand seven op pin

theorem full_upper_nine {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7) :
    outerValue pre post C.output (SignedClamp.singleton 9) true=true ∧
      innerValue pre g (SignedClamp.singleton 9)=true := by
  classical
  let K := fun j => outerValue pre post C.output (SignedClamp.singleton j) true
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  suffices hot : K 9=true from ⟨hot,hot_guard cut 9 hot⟩
  by_contra! no
  have n9 : K 9=false := by simpa using no
  have witness : ∃s,K s=true := by
    by_contra! none
    exact upper_cold_impossible r cand (by omega) red (fun j => by simpa [K] using none j)
  obtain ⟨s,pos⟩ := witness
  have hs := hot_guard cut s pos
  have low : 5≤s.val := by
    by_contra! short
    exact low_hot_impossible r (by omega) s (by omega) hs cand
  have sn : s.val≠9 := by intro e; have eq : s=9 := Fin.ext e; exact Bool.noConfusion (n9.symm.trans (eq ▸ pos))
  have high : s.val≤8 := by omega
  obtain ⟨u,cap,read⟩ := high_model_eight r cand red (by omega) s low high pos
  have cold := other_guard_cold r cand red seven s low high hs
  have coldU (j : Fin 10) (diff : s≠j) : sees u {j}=false := by
    have eq : inputOn {j}=SignedClamp.singleton j := by funext i;simp [inputOn,SignedClamp.singleton]
    change u.eval (inputOn {j})=false
    rw [eq,read]
    by_cases n : j=9
    · exact n ▸ n9
    · have h := cut.computes (SignedClamp.singleton j)
      rw [cold j diff.symm n] at h
      exact h.trans (singleton_zero j)
  have ep (a b : Fin 10) (h : f {a,b}=true) : sees u {a,b}=true := by
    change u.eval (inputOn {a,b})=true
    rw [read];exact positive_upper cut _ h
  have need := sole_hot_clamp_floor s u coldU ep
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.full_upper_nine
