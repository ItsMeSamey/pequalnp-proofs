import CompactPriorSelected13
-- CompactPriorFace28
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B255_11
theorem band9 : CutRow book 9 0 10 := row9_0
end B255_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace29
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B255_11
set_option maxRecDepth 16000 in
theorem row8_0 : CutRow book 8 0 4 := bandCut 8 false (by decide +kernel)
end B255_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace30
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B255_11
set_option maxRecDepth 16000 in
theorem row8_4 : CutRow book 8 4 5 := bandCut 9 false (by decide +kernel)
end B255_11
end PEqualNP.Outside.L_meta_9825.Engine
