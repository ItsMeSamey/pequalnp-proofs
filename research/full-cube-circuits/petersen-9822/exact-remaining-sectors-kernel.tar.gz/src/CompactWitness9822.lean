import CompactSeal9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_9822.Clean

/-- Keep the exact original compact net, its physical wire labels, and the
    same net after its last site's output polarity is absorbed. -/
structure PhysicalWitness {n} (gs : List Gate) (o k : Nat) where
  net : Net n k
  ref : Nat → Lit
  semantics : Realizes gs gs.length k net ref
  tracks : Tracks gs gs.length k net ref
  last : (ref o).wire = n+k-1
  signed : SignedDag (net.seal (ref o).neg) (fun x => vl gs x o)

theorem physicalWitness {n gs o} (hr : Reduced n gs o) (ho : o < n+gs.length)
    (hk : 0 < gs.countP bin) : Nonempty (PhysicalWitness (n := n) gs o (gs.countP bin)) := by
  obtain ⟨k,net,ref,count,real,tr⟩ := trackedPrefix hr gs.length le_rfl
  rw [List.take_length] at count
  subst k
  have last := tr.output_last hr ho real hk
  refine ⟨⟨net,ref,real,tr,last,Net.seal_proper tr.proper _,?_,?_⟩⟩
  · intro w g hg
    rw [net.seal_get] at hg
    cases h : net.get w with
    | none => simp [h] at hg
    | some s =>
      rw [← last]
      exact (tr.live hr h).seal _
  · intro x
    rw [net.seal_last hk, ← real.semantic o ho x]
    simp [Lit.read,last]

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.physicalWitness
