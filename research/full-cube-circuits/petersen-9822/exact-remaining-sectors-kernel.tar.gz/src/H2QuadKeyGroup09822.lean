import H2QuadPairList9822
import H2PairDom00019822
import H2PairDom00029822
import H2ShortDomTransport9822
import H2ShortDom00039822
import H2PairDom00069822
import H2ShortDom00079822
import H2PairDom00089822
import H2PairDom00099822
namespace Research.Graph9822H2Check
def keys0 : List (Nat × Nat) := [(0,1), (0,2), (0,3), (0,6), (0,7), (0,8), (0,9)]
theorem paidKeys0 : keys0.all (fun p => pairDom p.1 p.2)=true := by
  simp only [keys0,List.all_cons,List.all_nil,Bool.and_eq_true_iff]
  exact ⟨dom0_1, dom0_2, dom_of_short (by decide) short_dom_0_3, dom0_6, dom_of_short (by decide) short_dom_0_7, dom0_8, dom0_9, True.intro⟩
end Research.Graph9822H2Check
