import And9822H3PhysicalTail
import And9822H3TailBit
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.H3TailGroups (signature)

def posMask (h q : Nat) (i : Fin 13) := signature h q i.val (rawRow ⟨i.val,by omega⟩)
def negMask (h q : Nat) (i : Fin 16) := signature h q (13+i.val) (rawRow ⟨13+i.val,by omega⟩)

theorem no_exception_data (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B])
    (h q : Nat) (he : encode (firstCol H)=h) (qe : encode (secondCol H Q)=q)
    (group : Fin 16 → Fin 7) (surj : Function.Surjective group)
    (separate : ∀ i j : Fin 16, group i≠group j →
      ∃ e : Fin 13, posMask h q e &&& (negMask h q i ||| negMask h q j)=posMask h q e)
    (edges bans : Array Nat) (order : List (Fin 7)) (tape : List Nat)
    (accepted : Research.H3Tail.accepts edges bans (order.map Fin.val) tape=true)
    (all : order.Perm (List.finRange 7)) (bs : 7≤bans.size)
    (row : ∀ (p : Fin 13),edges[p.val]?=some (posMask h q p))
    (banned : ∀ (g : Fin 7) (j : Fin 12), bans[g.val]!.testBit j.val=true →
      ∃ n : Fin 16, group n=g ∧ (negMask h q n).testBit j.val=true) : False := by
  subst h
  subst q
  apply no_exception c H Q R A B hh ht group surj _ edges bans order tape accepted all bs _ _
  · intro i j covers
    by_contra ne
    obtain ⟨e,eq⟩ := separate i j ne
    obtain ⟨f,p,ni,nj⟩ := covers e
    have hot := (bit_source H Q ⟨e.val,by omega⟩ f).mpr p
    have ci := Bool.eq_false_iff.mpr (fun x => ni ((bit_source H Q ⟨13+i.val,by omega⟩ f).mp x))
    have cj := Bool.eq_false_iff.mpr (fun x => nj ((bit_source H Q ⟨13+j.val,by omega⟩ f).mp x))
    have bits := congrArg (fun x : Nat => x.testBit (source f)) eq
    change (posMask _ _ e).testBit (source f)=true at hot
    change (negMask _ _ i).testBit (source f)=false at ci
    change (negMask _ _ j).testBit (source f)=false at cj
    simp [Nat.testBit_or,Nat.testBit_and,hot,ci,cj] at bits
  · intro p m lookup f fire
    have eq := Option.some.inj ((row p).symm.trans lookup)
    subst m
    exact (bit_source H Q _ f).mpr fire
  · intro g j lt bit
    obtain ⟨n,gn,neg⟩ := banned g ⟨j,lt⟩ bit
    obtain ⟨f,eq⟩ := source_range j lt
    exact ⟨n,gn,f,eq,(bit_source H Q _ f).mp (eq.symm ▸ neg)⟩
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.no_exception_data
