import CompactPriorSelected29Cell06
-- CompactPriorFace73
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row7_112 : CutRow book 7 112 7 := (joinRow (joinRow row7_112_seg112 row7_112_seg115) row7_112_seg118)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace74
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem combine7_0_16 : CutRow book 7 0 16 := @joinRow book 7 0 12 4 row7_0 row7_12
theorem combine7_16_24 : CutRow book 7 16 24 := @joinRow book 7 16 12 12 row7_16 row7_28
theorem combine7_40_24 : CutRow book 7 40 24 := @joinRow book 7 40 12 12 row7_40 row7_52
theorem combine7_64_24 : CutRow book 7 64 24 := @joinRow book 7 64 12 12 row7_64 row7_76
theorem combine7_88_24 : CutRow book 7 88 24 := @joinRow book 7 88 12 12 row7_88 row7_100
theorem combine7_0_40 : CutRow book 7 0 40 := @joinRow book 7 0 16 24 combine7_0_16 combine7_16_24
theorem combine7_40_48 : CutRow book 7 40 48 := @joinRow book 7 40 24 24 combine7_40_24 combine7_64_24
theorem combine7_88_31 : CutRow book 7 88 31 := @joinRow book 7 88 24 7 combine7_88_24 row7_112
theorem combine7_0_88 : CutRow book 7 0 88 := @joinRow book 7 0 40 48 combine7_0_40 combine7_40_48
theorem combine7_0_119 : CutRow book 7 0 119 := @joinRow book 7 0 88 31 combine7_0_88 combine7_88_31
theorem band7 : CutRow book 7 0 119 := combine7_0_119
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace75
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row6_0 : CutRow book 6 0 12 := (joinRow (joinRow (joinRow row6_0_seg0 row6_0_seg3) row6_0_seg6) row6_0_seg9)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
