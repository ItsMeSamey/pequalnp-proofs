import H3FirstBroadReflect9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822H2Check Research.Graph9822FirstAdmission

theorem apart_mask (p q : Pair) (sep : apart p q=true) :
    (bit p.1.val ||| bit p.2.val) &&& (bit q.1.val ||| bit q.2.val) = 0 := by
  apply Nat.eq_of_testBit_eq
  intro k
  simp only [apart,Bool.and_eq_true,bne_iff_ne] at sep
  have a : p.1.val ≠ q.1.val := fun eq => sep.1.1.1 (Fin.ext eq)
  have b : p.1.val ≠ q.2.val := fun eq => sep.1.1.2 (Fin.ext eq)
  have c : p.2.val ≠ q.1.val := fun eq => sep.1.2 (Fin.ext eq)
  have d : p.2.val ≠ q.2.val := fun eq => sep.2 (Fin.ext eq)
  by_cases h : k=p.1.val <;> by_cases l : k=p.2.val <;>
    simp_all [bit,Nat.testBit_and,Nat.testBit_or,Nat.testBit_two_pow,eq_comm]

theorem livePair_mem {h : Nat} {p : Pair} (mem : p ∈ livePairs h) :
    p ∈ rowPairs ∧ compatible h p.1.val p.2.val = true := by
  obtain ⟨z,hz,rfl⟩ := List.mem_map.mp mem
  obtain ⟨g,ok⟩ := List.mem_filter.mp hz
  obtain ⟨p,hh,rfl⟩ := List.mem_map.mp g
  exact ⟨hh,ok⟩

theorem usable_cut {ws : Array Nat} {k : Fin 1024} {h : Nat} {ds : List Nat}
    (ad : firstAdmitted h=true) (bd : ∀ d ∈ ds, d<120)
    (pos : ∀ i<13, (ws[i]!).testBit k.val=(positive h).testBit i)
    (neg : ∀ i<16, (ws[13+i]!).testBit k.val=(negative h).testBit i) :
    (certifiedCuts ws ds).testBit k.val=true := by
  apply prods_of_all
  intro o om
  have bl : o < rowPairs.length := by have := bd o om; change o<120; assumption
  let q := rowPairs[o]
  obtain ⟨p,mem,sep⟩ := List.any_eq_true.mp (List.all_eq_true.mp ad q (List.getElem_mem bl))
  obtain ⟨pr,yes⟩ := livePair_mem mem
  let ps := geom.map (liveWord ws)
  have ps_eq : ps = rowPairs.map (pairWord ws) := by simp [ps,geom,pairWord,List.map_map,Function.comp_def]
  have access : ps[o]!.1 = bit q.1.val ||| bit q.2.val := by
    rw [ps_eq]; simp [bl,q,pairWord,liveWord]
  apply sums_of_mem (x:=pairWord ws p)
  · apply List.mem_filter.mpr
    refine ⟨?_,?_⟩
    · change pairWord ws p ∈ ps
      rw [ps_eq]
      exact List.mem_map.mpr ⟨p,pr,rfl⟩
    · change ((pairWord ws p).1 &&& ps[o]!.1 == 0) = true
      rw [access]
      exact beq_iff_eq.mpr (apart_mask p q sep)
  · exact comp_hits_pair yes pos neg

end Research.Graph9822FirstBroad
