import H23AxisPeriods9822
import H23TernaryLane9822
namespace Research.Graph9822Planes
private theorem block_bit (k d j : Nat) (hk : 0<k) :
    ((2^k-1)*2^(d*k)).testBit j=decide (j/k=d) := by
  rw [Nat.testBit_mul_two_pow,Nat.testBit_two_pow_sub_one]
  apply Bool.eq_iff_iff.mpr
  simp only [Bool.and_eq_true,decide_eq_true_eq]
  rw [Nat.div_eq_iff hk]
  omega
theorem axis_trit (v : Fin 10) (d : Fin 3) (j : Fin 59049) :
    (axis v.val d.val).testBit j.val = decide ((j.val / 3^v.val)%3=d.val) := by
  let k := 3^v.val
  let n := 3^(9-v.val)
  have hk : 0<k := Nat.pow_pos (by decide)
  have ht : 0<3*k := by omega
  have size : 3*k*n=width := by
    change 3*3^v.val*3^(9-v.val)=59049
    rw [←Nat.pow_succ',←Nat.pow_add,show v.val+1+(9-v.val)=10 by omega]
  have lim : j.val<3*k*n := by rw [size];exact j.isLt
  have nd : d.val+1≤3 := d.isLt
  have le := Nat.mul_le_mul_right k nd
  have eb : k+d.val*k≤3*k := by rw [Nat.succ_mul] at le;omega
  have small : (2^k-1)*2^(d.val*k)<2^(3*k) := calc
    _ < 2^k*2^(d.val*k) := Nat.mul_lt_mul_of_pos_right (by have := Nat.two_pow_pos k;omega) (Nat.two_pow_pos _)
    _ = 2^(k+d.val*k) := (Nat.pow_add ..).symm
    _ ≤ 2^(3*k) := Nat.pow_le_pow_right (by decide) eb
  change ((((1 <<< width)-1)/((1 <<< (3*k))-1)*((1 <<< k)-1)) <<< (d.val*k)).testBit j.val=_
  simp only [Nat.shiftLeft_eq,Nat.one_mul]
  rw [←size,geom_div (3*k) n ht,Nat.mul_assoc]
  rw [period_bit _ _ _ _ ht small lim,block_bit _ _ _ hk,Nat.mod_mul_left_div_self]
end Research.Graph9822Planes
#print axioms Research.Graph9822Planes.axis_trit
