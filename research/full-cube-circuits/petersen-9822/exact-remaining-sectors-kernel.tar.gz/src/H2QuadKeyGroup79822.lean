import H2QuadPairList9822
import H2ShortDomTransport9822
import H2ShortDom07119822
import H2ShortDom07129822
import H2ShortDom08109822
import H2ShortDom08119822
import H2ShortDom09119822
import H2ShortDom09129822
import H2ShortDom10129822
namespace Research.Graph9822H2Check
def keys7 : List (Nat × Nat) := [(7,11), (7,12), (8,10), (8,11), (9,11), (9,12), (10,12)]
theorem paidKeys7 : keys7.all (fun p => pairDom p.1 p.2)=true := by
  simp only [keys7,List.all_cons,List.all_nil,Bool.and_eq_true_iff]
  exact ⟨dom_of_short (by decide) short_dom_7_11, dom_of_short (by decide) short_dom_7_12, dom_of_short (by decide) short_dom_8_10, dom_of_short (by decide) short_dom_8_11, dom_of_short (by decide) short_dom_9_11, dom_of_short (by decide) short_dom_9_12, dom_of_short (by decide) short_dom_10_12, True.intro⟩
end Research.Graph9822H2Check
