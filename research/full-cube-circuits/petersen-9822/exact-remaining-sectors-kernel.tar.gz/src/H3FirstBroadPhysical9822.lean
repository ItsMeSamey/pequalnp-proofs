import H3FirstBroadPacking9822
namespace Research.Graph9822FirstBroad
open Research.Graph9822OneHidden (meets)
open Research.Graph9822.FeatureRun (rawRow rawCode rawCodeBit)

theorem meet_split (m r : Nat) :
    meets m r = (meets (m%32) r || meets (m/32) (r >>> 5)) := by
  have low (x : Nat) : x%32=x &&& (2^5-1) := (Nat.and_two_pow_sub_one_eq_mod x 5).symm
  have l : m%32 &&& r = (m &&& r)%32 := by rw [low,low]; ac_rfl
  have u : m/32 &&& r >>> 5 = (m &&& r)/32 := by
    have z (x : Nat) : x/32=x >>> 5 := (Nat.shiftRight_eq_div_pow x 5).symm
    rw [z m,z (m &&& r),Nat.shiftRight_and_distrib]
  apply Bool.eq_iff_iff.mpr
  simp only [meets,l,u,bne_iff_ne,Bool.or_eq_true]
  omega

def upper (m : Fin 1024) : Fin 32 := ⟨m.val/32,by omega⟩
def lower (m : Fin 1024) : Fin 32 := ⟨m.val%32,Nat.mod_lt _ (by decide)⟩
def lane (a b : Fin 1024) : Fin 1024 := ⟨32*(upper a).val+(upper b).val,by
  have := (upper a).isLt; have := (upper b).isLt; omega⟩

def field (a b r : Nat) : Nat :=
  (if meets a r then full else high (fun x => if meets x (r >>> 5) then stripe else 0)) &&&
  (if meets b r then full else high (fun _ => low32 (fun y => meets y (r >>> 5))))

theorem field_spec (a b : Fin 1024) (r : Nat) :
    (field (lower a).val (lower b).val r).testBit (lane a b).val =
      (meets a.val r && meets b.val r) := by
  have xpos : (high (fun x => if meets x (r >>> 5) then stripe else 0)).testBit (lane a b).val =
      meets (upper a).val (r >>> 5) := by
    change (high _).testBit (32*(upper a).val+(upper b).val)=_
    rw [high_on _ (fun i _ => by split <;> decide) (upper a) (upper b)]
    have sb : stripe.testBit (upper b).val=true := by
      rw [stripe,Nat.testBit_two_pow_sub_one]; simp [(upper b).isLt]
    cases t : meets (upper a).val (r >>> 5) <;> simp [sb]
  have ypos : (high (fun _ => low32 (fun y => meets y (r >>> 5)))).testBit (lane a b).val =
      meets (upper b).val (r >>> 5) := by
    change (high _).testBit (32*(upper a).val+(upper b).val)=_
    rw [high_on _ (fun _ _ => low32_bound _) (upper a) (upper b),low32_on]
  rw [meet_split a.val r,meet_split b.val r]
  change (field (lower a).val (lower b).val r).testBit (lane a b).val =
    ((meets (lower a).val r || meets (upper a).val (r >>> 5)) &&
     (meets (lower b).val r || meets (upper b).val (r >>> 5)))
  cases pa : meets (lower a).val r <;> cases pb : meets (lower b).val r <;>
    simp [field,pa,pb,full_on,xpos,ypos,Nat.testBit_and]

theorem words_physical (a b : Fin 1024) (i : Fin 29) :
    ((words (lower a).val (lower b).val)[i.val]!).testBit (lane a b).val =
      (rawCode a.val &&& rawCode b.val).testBit i.val := by
  have form (x y : Nat) : words x y = (rawRows.map (field x y)).toArray := by
    simp [words,highData,field,List.map_map,Function.comp_def]
  have bound : i.val < rawRows.length := i.isLt
  have index : rawRows[i.val]=rawRow i := by
    have finite : ∀ j : Fin 29, rawRows[j.val]! = rawRow j := by decide +kernel
    simpa [bound] using finite i
  rw [form]
  simp only [getElem!_pos ((rawRows.map (field (lower a).val (lower b).val)).toArray) i.val (by simpa using bound),
    List.getElem_toArray,List.getElem_map,index,field_spec,Nat.testBit_and,rawCodeBit]

end Research.Graph9822FirstBroad
