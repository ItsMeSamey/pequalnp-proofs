import CompactPriorSelected29
-- CompactPriorFace76
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
set_option maxRecDepth 16000 in
theorem row6_12 : CutRow book 6 12 2 := bandCut 7 false (by decide +kernel)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace77
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem combine6_0_14 : CutRow book 6 0 14 := @joinRow book 6 0 12 2 row6_0 row6_12
theorem band6 : CutRow book 6 0 14 := combine6_0_14
theorem checked : mixedTables book 10 := by
  intro k hk
  interval_cases k
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact mixedEmpty _ _ _
  · exact band6
  · exact band7
  · exact band8
  · exact band9
  · exact band10
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace78
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
theorem h701_11 : Face true 701 11 :=
  mixedLower (g:=B701_11.book) (i:=0) (hints:=275414786820)
    (before_sound B701_11.entries B701_11.prior) B701_11.geometry B701_11.checked
    (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)
theorem h710_7 : Face true 710 7 := carry_of (swaps:=[116,100,84,49,33]) (by decide +kernel) h668_7
theorem h727_10 : Face true 727 10 := carry_of (swaps:=[151,101,66,16]) (by decide +kernel) h695_10
theorem h734_11 : Face true 734 11 := carry_of (swaps:=[151,101,66,16]) (by decide +kernel) h701_11
end PEqualNP.Outside.L_meta_9825.Engine
