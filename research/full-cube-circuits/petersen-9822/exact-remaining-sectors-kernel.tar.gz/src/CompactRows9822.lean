import Sector9822
import SignedCensusBundle9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open Petersen9822 PEqualNP.Outside.L_meta_9822.Sectors
theorem edgeMod (row : Nat) : edgeHit (row % 1024) = edgeHit row := by
  have small (mask : Nat) (h : mask < 1024) : sub mask (row%1024) = sub mask row := by
    unfold sub
    have lo := Nat.mod_eq_of_lt h
    have bound : mask &&& row < 1024 := lt_of_le_of_lt Nat.and_le_left h
    have he := @Nat.and_mod_two_pow mask row 10
    change (mask &&& row) % 1024 = (mask % 1024) &&& (row % 1024) at he
    rw [lo,Nat.mod_eq_of_lt bound] at he
    rw [← he]
  unfold edgeHit
  simp [small]

set_option maxRecDepth 8000 in
theorem rowEdge (row : Nat) : edgeHit row = edge (fun i => row.testBit i.val) := by
  have finite : ∀ r : Fin 1024, edgeHit r.val = edge (fun i => r.val.testBit i.val) := by
    decide +kernel
  rw [← edgeMod row]
  have e := finite ⟨row%1024,Nat.mod_lt _ (by decide)⟩
  change edgeHit (row%1024) = edge (fun i => (row%2^10).testBit i.val) at e
  apply e.trans
  apply congrArg edge
  funext i
  rw [Nat.testBit_mod_two_pow]
  simp [i.isLt]

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.rowEdge
