import CompactPriorSelected12
-- CompactPriorFace25
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B255_11
set_option maxRecDepth 16000 in
theorem row10_0 : CutRow book 10 0 1 := bandCut 8 false (by decide +kernel)
end B255_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace26
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B255_11
theorem band10 : CutRow book 10 0 1 := row10_0
end B255_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace27
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B255_11
set_option maxRecDepth 16000 in
theorem row9_0 : CutRow book 9 0 10 := bandCut 9 true (by decide +kernel)
end B255_11
end PEqualNP.Outside.L_meta_9825.Engine
