import CompactPriorSelected25Cell04
namespace PEqualNP.Outside.L_meta_9825.Engine.B701_11
set_option maxRecDepth 16000 in
theorem row7_0_seg6 : CutRow book 7 6 3 := bandCut 7 false (by decide +kernel)
end PEqualNP.Outside.L_meta_9825.Engine.B701_11
