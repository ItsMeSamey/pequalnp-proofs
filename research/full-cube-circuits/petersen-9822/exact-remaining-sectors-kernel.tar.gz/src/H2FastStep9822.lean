import H2FastShore9822
import H2PhysicalForest9822
namespace Research.Graph9822H2Check
def ends : Array (List Nat) := #[[2, 4], [8, 16], [1, 16], [1, 32], [2, 64], [4, 128], [8, 256], [16, 512], [32, 128], [128, 512], [64, 512], [64, 256], [32, 256]]
def quadTable : Array (List Nat) := #[[0, 1, 3, 9], [0, 1, 3, 10], [0, 1, 3, 11], [0, 1, 8, 10], [0, 1, 8, 11], [0, 1, 9, 11], [0, 1, 9, 12], [0, 1, 10, 12], [0, 2, 6, 8], [0, 2, 6, 9], [0, 2, 6, 10], [0, 2, 8, 10], [0, 2, 8, 11], [0, 2, 9, 11], [0, 2, 9, 12], [0, 2, 10, 12], [0, 3, 6, 7], [0, 3, 6, 9], [0, 3, 6, 10], [0, 3, 7, 11], [0, 3, 9, 11], [0, 6, 7, 8], [0, 6, 8, 10], [0, 7, 8, 11], [1, 3, 4, 5], [1, 3, 4, 9], [1, 3, 5, 10], [1, 3, 5, 11], [1, 3, 9, 11], [1, 4, 5, 12], [1, 4, 9, 12], [1, 5, 10, 12], [2, 4, 5, 6], [2, 4, 5, 12], [2, 4, 6, 8], [2, 4, 6, 9], [2, 4, 9, 12], [2, 5, 6, 10], [2, 5, 10, 12], [2, 6, 8, 10], [3, 4, 5, 6], [3, 4, 5, 7], [3, 4, 6, 7], [3, 4, 6, 9], [3, 5, 6, 7], [3, 5, 6, 10], [3, 5, 7, 11], [4, 5, 6, 7], [4, 5, 7, 12], [4, 6, 7, 8]]
def fastCovers (t : Nat) := shoreEnum ((es.filter t.testBit).map (fun i => ends[i]!))

def fastFeasible (h s : Nat) : Bool :=
  let t := positive s
  let f := negative s
  (fastCovers t).any fun b =>
    let forbidden := f &&& rawNeg b
    let a := freeRaw forbidden &&& (1023 ^^^ b)
    sub t (rawPos a ||| (if Research.Graph9822OneHidden.meets (negative h) forbidden then 0 else positive h))

def fastStep (h s code : Nat) : Option (List Nat) := do
  if code == 255 then
    guard (negative s == 65535)
    return []
  let quad ← quadTable[code]?
  let children := minimal (do
    let i ← quad
    let j ← quad
    guard (i < j)
    let r ← rescue h i j
    guard (fastFeasible h (s ||| r))
    return s ||| r)
  guard (!children.contains s)
  return children
end Research.Graph9822H2Check
