import H23TernaryLane9822
import OR9822H2NestedSaturation
import OR9822TwoSlotValue
namespace Research.Graph9822Ternary
open Research.Graph9822H2Check Research.Graph9822.FeatureRun
open Research.Graph9822OneHidden (meets)

def rowWord (axis : Nat → Nat) (row : Nat) :=
  (List.range 10).foldr (fun v tail => if row.testBit v then axis v ||| tail else tail) 0

private theorem foldHits (axis : Nat → Nat) (row j : Nat) (vs : List Nat) :
    (vs.foldr (fun v tail => if row.testBit v then axis v ||| tail else tail) 0).testBit j=true ↔
      ∃ v∈vs, row.testBit v=true ∧ (axis v).testBit j=true := by
  induction vs with
  | nil => simp
  | cons v vs ih =>
    cases on : row.testBit v <;> simp [on,Nat.testBit_or,ih]

theorem rowWordAt {axis : Nat → Nat} {j mask : Nat} (r : Fin 29)
    (bits : ∀ v<10, (axis v).testBit j=mask.testBit v) :
    (rowWord axis (rawRow r)).testBit j=meets mask (rawRow r) := by
  apply Bool.eq_iff_iff.mpr
  rw [rowWord,foldHits,meets_iff_exists]
  constructor
  · rintro ⟨v,mem,on,lit⟩
    exact ⟨v,(bits v (List.mem_range.mp mem)).symm.trans lit,on⟩
  · rintro ⟨v,inside,on⟩
    have lt : v<10 := by
      by_contra! far
      have off : (rawRow r).testBit v=false := Nat.testBit_lt_two_pow
        (lt_of_lt_of_le (raw_row_small r) (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) far))
      simp [off] at on
    exact ⟨v,List.mem_range.mpr lt,on,(bits v lt).trans inside⟩

private theorem posLow (m : Nat) (i : Nat) (lt : i<13) : (positive m).testBit i=m.testBit i := by
  have full : (8191 : Nat).testBit i=true := by
    change (2^13-1 : Nat).testBit i=true
    rw [Nat.testBit_two_pow_sub_one]
    exact decide_eq_true lt
  simp [positive,Nat.testBit_and,full]

theorem nestedRow {h q A B : Nat} {u : Bool} (physical : NestedBits h q A B u) (r : Fin 29) :
    q.testBit r.val = ((meets A (rawRow r) || (u && h.testBit r.val)) && meets B (rawRow r)) := by
  by_cases early : r.val<13
  · have row := physical.pos ⟨r.val,early⟩
    rw [raw_pos_bit A ⟨r.val,early⟩,raw_pos_bit B ⟨r.val,early⟩] at row
    simpa only [posLow _ _ early,rawRow,early,ite_true] using row
  · let n : Fin 16 := ⟨r.val-13,by omega⟩
    have row := physical.neg n
    have add : 13+(r.val-13)=r.val := by omega
    rw [raw_neg_bit A n,raw_neg_bit B n] at row
    simpa only [negative,Nat.testBit_shiftRight,n,add,rawRow,early,ite_false] using row

theorem rowQAt {h q A B : Nat} {u : Bool} (physical : NestedBits h q A B u)
    (apart : meets A B=false) (axisA axisB : Nat → Nat)
    (aBits : ∀ v<10, (axisA v).testBit (ternaryLane A B).val =
      (trit (ternaryLane A B).val v == 1))
    (bBits : ∀ v<10, (axisB v).testBit (ternaryLane A B).val =
      (trit (ternaryLane A B).val v == 2)) (r : Fin 29) :
    (if u && h.testBit r.val then rowWord axisB (rawRow r)
      else rowWord axisA (rawRow r) &&& rowWord axisB (rawRow r)).testBit
      (ternaryLane A B).val = q.testBit r.val := by
  have a := rowWordAt r (fun v hv => (aBits v hv).trans (laneBits A B apart v hv).1)
  have b := rowWordAt r (fun v hv => (bBits v hv).trans (laneBits A B apart v hv).2)
  rw [nestedRow physical r]
  cases on : u && h.testBit r.val <;> simp [on,Nat.testBit_and,a,b]

end Research.Graph9822Ternary
