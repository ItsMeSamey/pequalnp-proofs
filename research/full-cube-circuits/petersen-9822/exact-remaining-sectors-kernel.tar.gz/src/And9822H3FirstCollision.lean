import And9822H3FirstDirections
namespace Research.Graph9822.H3Directions
open Research.Graph9822.FreeOR Research.Graph9822.ReverseChannel Research.Graph9822Resolution
open Research.Graph9822.FourSaturation

theorem first_collision (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B])
    (skip : Fin 7) (unused : ¬reads R A B skip 11) (n : Fin 14 → Fin 1024)
    (neg : ∀ i, accepts (n i).val=false) :
    ∃ i j : Fin 14, i<j ∧ ∀ m : Fin 1024, accepts m.val=true →
      (∀ k<10, fullWire m.val k=true →
          fullWire (n i).val k=true ∨ fullWire (n j).val k=true) →
      productBit (fullWire m.val) H=true ∧
        productBit (fullWire (n i).val) H=false ∧ productBit (fullWire (n j).val) H=false := by
  classical
  let v (m : Fin 1024) := run [H,Q,R] 10 (fullWire m.val)
  let dirs := (Finset.univ : Finset (Fin 7 × Bool)).erase (skip,true)
  obtain ⟨size,pos,cold⟩ := first_physical c H Q R A B hh ht skip unused
  choose slot mem quiet using fun i => cold (n i) (neg i)
  let pick : Fin 14 → ↥dirs := fun i => ⟨slot i,mem i⟩
  have bad : ¬Function.Injective pick := by
    intro inj
    have le := Fintype.card_le_of_injective pick inj
    simp only [Fintype.card_fin, Fintype.card_coe] at le
    change dirs.card=13 at size
    omega
  unfold Function.Injective at bad
  push_neg at bad
  obtain ⟨i,j,eq,ne⟩ := bad
  have pair : ∃ i j : Fin 14, i<j ∧ slot i=slot j := by
    rcases lt_or_gt_of_ne ne with lt|gt
    · exact ⟨i,j,lt,congrArg Subtype.val eq⟩
    · exact ⟨j,i,gt,congrArg Subtype.val eq.symm⟩
  obtain ⟨u,w,lt,same⟩ := pair
  refine ⟨u,w,lt,?_⟩
  intro m live cov
  obtain ⟨k,hk,fire⟩ := pos _ (mem u) m live
  have cu := quiet u k hk
  have cw := quiet w k (same ▸ hk)
  have raw (a : Fin 1024) (h : k<10) : v a k=fullWire a.val k := stale_value _ h _
  by_cases small : k<10
  · have h := cov k small ((raw m small).symm.trans fire)
    rcases h with h|h
    · exact Bool.noConfusion (cu.symm.trans ((raw (n u) small).trans h))
    · exact Bool.noConfusion (cw.symm.trans ((raw (n w) small).trans h))
  · have bound := hk.1
    have eqk : k=10 := by omega
    subst k
    have prev (a : Fin 1024) : v a 10=productBit (fullWire a.val) H := by
      change run [Q,R] 11 _ 10=_
      rw [stale_value _ (by decide : 10<11) _,Function.update_self]
    exact ⟨(prev m).symm.trans fire,(prev (n u)).symm.trans cu,(prev (n w)).symm.trans cw⟩
end Research.Graph9822.H3Directions
#print axioms Research.Graph9822.H3Directions.first_collision
