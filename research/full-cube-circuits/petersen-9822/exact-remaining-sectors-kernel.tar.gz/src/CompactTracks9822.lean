import CompactCompile9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean

def Net.Edge {n k} (net : Net n k) (a b : Nat) : Prop :=
  ∃ g, net.get b = some g ∧ (g.left.wire = a ∨ g.right.wire = a)

theorem Net.edge_lt {n k} {net : Net n k} {a b} (h : net.Edge a b) : a < b := by
  obtain ⟨g,hg,h | h⟩ := h
  · exact h ▸ (net.get_spec hg).2.2.1
  · exact h ▸ (net.get_spec hg).2.2.2

def Net.Proper {n k} (net : Net n k) : Prop := ∀ w g, net.get w = some g → g.left.wire ≠ g.right.wire

structure Tracks {n} (gs : List Gate) (p k : Nat) (net : Net n k) (ref : Nat → Lit) : Prop where
  raw : ∀ w, w < n → ref w = ⟨w,false⟩
  covers : ∀ w g, net.get w = some g → ∃ j < p, (ref (n+j)).wire = w
  follows : ∀ j < p, ∀ w, Reads gs j w →
    (ref w).wire = (ref (n+j)).wire ∨ net.Edge (ref w).wire (ref (n+j)).wire
  proper : net.Proper

theorem Tracks.extend {n gs p k t} {net : Net n k} {net' : Net n t} {ref ref' : Nat → Lit}
    (tr : Tracks gs p k net ref) (hc : CleanL n gs)
    (past : ∀ w, w < n+p → ref' w = ref w)
    (old : ∀ w g, net.get w = some g → net'.get w = some g)
    (new : ∀ w g, net'.get w = some g → net.get w = some g ∨ (ref' (n+p)).wire = w)
    (step : ∀ w, Reads gs p w →
      (ref' w).wire = (ref' (n+p)).wire ∨ net'.Edge (ref' w).wire (ref' (n+p)).wire)
    (good : net'.Proper) : Tracks gs (p+1) t net' ref' := by
  constructor
  · intro w hw
    rw [past w (by omega)]
    exact tr.raw w hw
  · intro w g hg
    rcases new w g hg with h | h
    · obtain ⟨j,hj,eq⟩ := tr.covers w g h
      exact ⟨j,by omega,by rw [past _ (by omega),eq]⟩
    · exact ⟨p,by omega,h⟩
  · intro j hj w hw
    by_cases e : j = p
    · subst j; exact step w hw
    · have hlt : j < p := by omega
      have hr := reads_lt hc hw
      rw [past w (by omega),past (n+j) (by omega)]
      rcases tr.follows j hlt w hw with he | ⟨g,hg,hs⟩
      · exact Or.inl he
      · exact Or.inr ⟨g,old _ g hg,hs⟩
  · exact good

private theorem pinsDistinct {n gs o p k} (hr : Reduced n gs o)
    {net : Net n k} {ref : Nat → Lit} (real : Realizes gs p k net ref)
    {g : Gate} (hg : gs[p]? = some g) {a b} (hin : g.inputs = [a,b])
    (hop : g.op = GateOp.and ∨ g.op = GateOp.or) (ha : a < n+p) (hb : b < n+p) :
    (ref a).wire ≠ (ref b).wire := by
  intro eq
  have hp := (List.getElem?_eq_some_iff.mp hg).1
  have pin (x : Fin n → Bool) := real.semantic a ha x
  have pin' (x : Fin n → Bool) := real.semantic b hb x
  by_cases same : (ref a).neg = (ref b).neg
  · apply hr.noAlias p hp a ha
    intro x
    have hv : vl gs x a = vl gs x b := by
      rw [← pin x,← pin' x]
      simp only [Lit.read,eq,same]
    rw [vl_gate gs hr.clean x p g hg,hin]
    rcases hop with h | h <;> simp [h,GateOp.eval,hv]
  · have opposite (x : Fin n → Bool) : vl gs x b = !(vl gs x a) := by
      rw [← pin x,← pin' x]
      cases h1 : (ref a).neg <;> cases h2 : (ref b).neg <;> simp_all [Lit.read]
    rcases hop with h | h
    · apply hr.noConstant p hp false
      intro x
      rw [vl_gate gs hr.clean x p g hg,hin,h]
      simp [GateOp.eval,opposite]
    · apply hr.noConstant p hp true
      intro x
      rw [vl_gate gs hr.clean x p g hg,hin,h]
      simp [GateOp.eval,opposite]

theorem Tracks.negGate {n gs p k} {net : Net n k} {ref : Nat → Lit} (tr : Tracks gs p k net ref)
    (hc : CleanL n gs) {g : Gate} (hg : gs[p]? = some g) {a} (ha : a < n+p) (hin : g.inputs = [a]) :
    Tracks gs (p+1) k net (Compact.extend ref (n+p) (ref a).flip) := by
  apply tr.extend hc (fun w hw => by simp [Compact.extend,Nat.ne_of_lt hw]) (fun _ _ h => h)
    (fun _ _ h => Or.inl h) _ tr.proper
  rintro w ⟨g',hg',hw⟩
  have eq := Option.some.inj (hg'.symm.trans hg)
  subst g'
  rw [hin, List.mem_singleton] at hw
  subst w
  exact Or.inl (by simp [Compact.extend,Nat.ne_of_lt ha,Lit.flip])

theorem Tracks.joinGate {n gs o p k} (hr : Reduced n gs o)
    {net : Net n k} {ref : Nat → Lit} (tr : Tracks gs p k net ref) (real : Realizes gs p k net ref)
    {g : Gate} (hg : gs[p]? = some g) (a b : Nat) (ha : a < n+p) (hb : b < n+p)
    (isOr : Bool) (hop : g.op = GateOp.and ∨ g.op = GateOp.or) (hin : g.inputs = [a,b]) :
    Tracks gs (p+1) (k+1)
      (net.snoc (join isOr (ref a) (ref b)) (real.bound a ha) (real.bound b hb))
      (Compact.extend ref (n+p) ⟨n+k,false⟩) := by
  apply tr.extend hr.clean (fun w hw => by simp [Compact.extend,Nat.ne_of_lt hw])
  · intro w v hv
    have old := (net.get_spec hv).2.1
    simpa [Net.get,Nat.ne_of_lt old] using hv
  · intro w v hv
    by_cases eq : w = n+k
    · exact Or.inr (by simp [Compact.extend,eq])
    · exact Or.inl (by simpa [Net.get,eq] using hv)
  · rintro w ⟨g',hg',hw⟩
    have eq := Option.some.inj (hg'.symm.trans hg)
    subst g'
    rw [hin] at hw
    simp at hw
    rcases hw with aw | bw
    · subst w; apply Or.inr
      simp [Compact.extend,Nat.ne_of_lt ha,Net.Edge,Net.get,join]
    · subst w; apply Or.inr
      simp [Compact.extend,Nat.ne_of_lt hb,Net.Edge,Net.get,join]
  · intro w v hv
    by_cases eq : w = n+k
    · subst w
      simp [Net.get] at hv
      subst v
      exact pinsDistinct hr real hg hin hop ha hb
    · exact tr.proper w v (by simpa [Net.get,eq] using hv)

end PEqualNP.Outside.L_meta_9822.Compact
