import CompactPriorSelected09
-- CompactPriorFace16
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B190_7
def entries : List (Nat × Nat) := [(30,4),(156,4),(166,4)]
theorem prior : Known true entries := (consFace h30_4 (consFace h156_4 (consFace h166_4 (known_down baseKnown))))
def samples : Nat → Bits × Bits := (fun i => (if i<8 then tableBits #[(padColumn 80 0x0,padColumn 80 0x0),(padColumn 80 0xfcfe000001f86030fc03,padColumn 80 0xfc7e0c20c3586030d401),(padColumn 80 0x279203e03ff81c0ffccf,padColumn 80 0x38012810ca018052846),(padColumn 80 0x5d2e001ffe0183ff043c,padColumn 80 0x1c0e604a720982aa0418),(padColumn 80 0xebf4001fc0060ff11830,padColumn 80 0xe3f1819584360d511820),(padColumn 80 0x93fffc000007f0c66300,padColumn 80 0x3feb60618c550c66100),(padColumn 80 0x0,padColumn 80 0x0),(padColumn 80 0xfe49ffe00007ff0883c0,padColumn 80 0xfc0149782102a7088280)] i else tableBits #[(padColumn 80 0x0,padColumn 80 0x0),(padColumn 80 0x0,padColumn 80 0x0)] i))
def cols : List ColumnInfo := [(8,16,166,0,4),(24,0,166,0,4),(34,0,156,0,4),(128,32,30,0,4),(160,0,30,0,4)]
def data6 : Nat → Nat := (fun i => tableWord #[0x3f,0x4cc05] i)
def data5 : Nat → Nat := (fun i => tableWord #[0x7ec20,0x0] i)
def levels : Nat → Packing
  | 5 => (1,1,3,0,0,0,0,data5)
  | 6 => (1,0,3,0,0,0,0,data6)
  | _ => (0,0,0,0,0,0,0,fun _ => 0)
def index : Nat → Nat → Option (Nat × Nat)
  | 6 => fun v => (if v=7689521405595769300 then some (0,0) else none)
  | _ => fun _ => none
def book : Forest := ⟨190,6,samples,cols,[[],[115,84]],levels,index⟩
end B190_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace17
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B190_7
theorem geometry : graphValid book (boundsBefore entries) = true := by decide +kernel
end B190_7
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace18
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B190_7
set_option maxRecDepth 16000 in
theorem row6_0 : CutRow book 6 0 1 := bandCut 6 false (by decide +kernel)
end B190_7
end PEqualNP.Outside.L_meta_9825.Engine
