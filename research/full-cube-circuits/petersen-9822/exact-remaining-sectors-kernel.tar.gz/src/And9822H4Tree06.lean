import And9822H4Tree05
namespace Research.Graph9822.H4Tree
theorem t300 {p : Bad} (legal : Respects p) (ok : Within p 8451315423746824879983610583398543116981636040101723658701087703040) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t298 legal) (t299 legal)
theorem t301 {p : Bad} (legal : Respects p) (ok : Within p 12676971126947681996237571447619277031471519363092892407300488691968) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t289 legal) (t300 legal)
theorem t302 {p : Bad} (legal : Respects p) (ok : Within p 12677999567296011526534149166411526398452458419392212121082930987264) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t284 legal) (t301 legal)
theorem t303 {p : Bad} (legal : Respects p) (ok : Within p 2993155353253689186865740254472602881316343043325952) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t304 {p : Bad} (legal : Respects p) (ok : Within p 827573092793379991904110477566083334016004197055252092281684000) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t305 {p : Bad} (legal : Respects p) (ok : Within p 827573092796373147257364166742564480553407144679507442666569760) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t303 legal) (t304 legal)
theorem t306 {p : Bad} (legal : Respects p) (ok : Within p 1034466365995466434071705208415224858545421898707561809454891040) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t307 {p : Bad} (legal : Respects p) (ok : Within p 1034466365995466434071705208425609452262491553964622802113331232) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t305 legal) (t306 legal)
theorem t308 {p : Bad} (legal : Respects p) (ok : Within p 412983077376080462517108396767259658181585736128049197720010852) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t309 {p : Bad} (legal : Respects p) (ok : Within p 516228846720112270159484143181608905821488499662845948582690916) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t310 {p : Bad} (legal : Respects p) (ok : Within p 516228846720112270159484143182257942928805353116412260623843428) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t308 legal) (t309 legal)
theorem t311 {p : Bad} (legal : Respects p) (ok : Within p 1548686540160254966386761898992440941938144116409289627254980708) : Success p :=
  fork legal ok 12 (by decide +kernel) (by decide +kernel) (t307 legal) (t310 legal)
theorem t312 {p : Bad} (legal : Respects p) (ok : Within p 12678515796142731603728269354613038619506951201664923734201754780004) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t302 legal) (t311 legal)
theorem t313 {p : Bad} (legal : Respects p) (ok : Within p 883477287732020517160690172278128100419731754139712264401427876426613092) : Success p :=
  fork legal ok 18 (by decide +kernel) (by decide +kernel) (t269 legal) (t312 legal)
theorem t314 {p : Bad} (legal : Respects p) (ok : Within p 3063307431848677593153076973041327161806435840425984) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t315 {p : Bad} (legal : Respects p) (ok : Within p 3423472231506769170703413384310941570990396513818848999582608654592) : Success p :=
  leaf ok 3 (by decide +kernel)
theorem t316 {p : Bad} (legal : Respects p) (ok : Within p 822752278660603021077484591610982251437785795702091675514961920) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t317 {p : Bad} (legal : Respects p) (ok : Within p 3423472231506769170703413384310941570990396664934576451411255492864) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t315 legal) (t316 legal)
theorem t318 {p : Bad} (legal : Respects p) (ok : Within p 3423472231506772234010845232988534724067369517367078943061287371008) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t314 legal) (t317 legal)
theorem t319 {p : Bad} (legal : Respects p) (ok : Within p 59238164063563417517578890572438463553193074309926796730577191040) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t320 {p : Bad} (legal : Respects p) (ok : Within p 3430054249736057058179465109718764126087300536387476988429005226368) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t318 legal) (t319 legal)
theorem t321 {p : Bad} (legal : Respects p) (ok : Within p 3422652743321010968756333097392371959013941423534076965516082151680) : Success p :=
  leaf ok 5 (by decide +kernel)
theorem t322 {p : Bad} (legal : Respects p) (ok : Within p 59238164063563417517578890572106156554246769783837119051183685760) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t323 {p : Bad} (legal : Respects p) (ok : Within p 3429234761550295792924952974122601361033872366996611284969476587904) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t321 legal) (t322 legal)
theorem t324 {p : Bad} (legal : Respects p) (ok : Within p 50216813883093446116266414511966447000010980714731400069120) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t325 {p : Bad} (legal : Respects p) (ok : Within p 6845302222549119536438668994049244322214229374370864014440766898176) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t326 {p : Bad} (legal : Respects p) (ok : Within p 6845298958456217135364671799438744254227693152261760468164013981696) : Success p :=
  leaf ok 6 (by decide +kernel)
theorem t327 {p : Bad} (legal : Respects p) (ok : Within p 6845302222549119536438668994049244322214229525486591607058441699328) : Success p :=
  fork legal ok 6 (by decide +kernel) (by decide +kernel) (t325 legal) (t326 legal)
theorem t328 {p : Bad} (legal : Respects p) (ok : Within p 6845302222549119536438668999629343448519306359936773646115328229376) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t324 legal) (t327 legal)
theorem t329 {p : Bad} (legal : Respects p) (ok : Within p 105312291668557186697918027683836585818387628255639717503888785408) : Success p :=
  leaf ok 4 (by decide +kernel)
theorem t330 {p : Bad} (legal : Respects p) (ok : Within p 6845302222549119536438668999629343448519325778307751276465191124992) : Success p :=
  fork legal ok 4 (by decide +kernel) (by decide +kernel) (t328 legal) (t329 legal)
theorem t331 {p : Bad} (legal : Respects p) (ok : Within p 10274533720006512928289624779141444741566661772079531422540239995264) : Success p :=
  fork legal ok 11 (by decide +kernel) (by decide +kernel) (t323 legal) (t330 legal)
theorem t332 {p : Bad} (legal : Respects p) (ok : Within p 10275356472285176594618134109305572278741508780088715261222255067520) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t320 legal) (t331 legal)
theorem t333 {p : Bad} (legal : Respects p) (ok : Within p 51673101490450113365946991210171078274054856198533358708326404) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t334 {p : Bad} (legal : Respects p) (ok : Within p 1290622333609384658490748992142265625164797087439716661069873248) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t335 {p : Bad} (legal : Respects p) (ok : Within p 1290622333614131615808799764820591193501459574687559130506330212) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t333 legal) (t334 legal)
theorem t336 {p : Bad} (legal : Respects p) (ok : Within p 10275821078247224658831436384295765264773626858429387842776318607844) : Success p :=
  fork legal ok 1 (by decide +kernel) (by decide +kernel) (t332 legal) (t335 legal)
theorem t337 {p : Bad} (legal : Respects p) (ok : Within p 883477452282476249281294387775046356777857875456896514160704137836691940) : Success p :=
  fork legal ok 10 (by decide +kernel) (by decide +kernel) (t313 legal) (t336 legal)
theorem t338 {p : Bad} (legal : Respects p) (ok : Within p 50216813929861498505275208768179245975740044317487211217152) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t339 {p : Bad} (legal : Respects p) (ok : Within p 70152078592223622440856266758882711598141009821696) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t340 {p : Bad} (legal : Respects p) (ok : Within p 50216813953245524702909937826517598087701699286637842792704) : Success p :=
  fork legal ok 7 (by decide +kernel) (by decide +kernel) (t338 legal) (t339 legal)
theorem t341 {p : Bad} (legal : Respects p) (ok : Within p 50216813964937537801737936179420320743303308281294579368192) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t342 {p : Bad} (legal : Respects p) (ok : Within p 50216813964937537801737936179578777068341204443706597900544) : Success p :=
  fork legal ok 0 (by decide +kernel) (by decide +kernel) (t340 legal) (t341 legal)
theorem t343 {p : Bad} (legal : Respects p) (ok : Within p 51622884672077286889955771130064014049233894044082038674292740) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t344 {p : Bad} (legal : Respects p) (ok : Within p 23384026197294446691258957323478975058569167110148) : Success p :=
  leaf ok 2 (by decide +kernel)
theorem t345 {p : Bad} (legal : Respects p) (ok : Within p 51622884672077286889955771130064014049233912490826112383844356) : Success p :=
  fork legal ok 18 (by decide +kernel) (by decide +kernel) (t343 legal) (t344 legal)
theorem t346 {p : Bad} (legal : Respects p) (ok : Within p 51622884671820062601785532216460165518675846679366667719409760) : Success p :=
  leaf ok 1 (by decide +kernel)
theorem t347 {p : Bad} (legal : Respects p) (ok : Within p 51622884672077286889955771130064014049233912490826112383844452) : Success p :=
  fork legal ok 5 (by decide +kernel) (by decide +kernel) (t345 legal) (t346 legal)
theorem t348 {p : Bad} (legal : Respects p) (ok : Within p 251084069415467230553431576928306656644094217796157861527584) : Success p :=
  leaf ok 0 (by decide +kernel)
theorem t349 {p : Bad} (legal : Respects p) (ok : Within p 51673101485960380336066457445449675380562731334399421140959332) : Success p :=
  fork legal ok 2 (by decide +kernel) (by decide +kernel) (t347 legal) (t348 legal)
end Research.Graph9822.H4Tree
