import And9822CollectorShape
import OR9822Chronological
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
theorem join_runs (a b : List Product) (k : Nat) (w : Wire) :
    run (a++b) k w = run b (k+a.length) (run a k w) := by
  induction a generalizing k w with
  | nil => simp [run]
  | cons p ps ih =>
    simp only [List.cons_append,List.length_cons,run,ih]
    rw [show k + 1 + ps.length = k + (ps.length + 1) by omega]

theorem terminal_eval (ps : List Product) (n k : Nat) (le : n≤k)
    (prior : ∀ p ∈ ps, Below n p) (w : Wire) :
    readArm (run ps k w) (List.range' k ps.length) = ps.any (productBit w) := by
  induction ps generalizing k w with
  | nil => simp [readArm]
  | cons p ps ih =>
    let w' := Function.update w k (productBit w p)
    have h := ih (k+1) (by omega) (fun q mem => prior q (List.mem_cons_of_mem _ mem)) w'
    have diff (q : Product) (mem : q ∈ ps) : productBit w' q=productBit w q := by
      have bd := prior q (List.mem_cons_of_mem _ mem)
      have go (a : Arm) (ha : ∀ j ∈ a, j<n) : readArm w' a=readArm w a := by
        apply read_below
        intro j hj
        have ne : j≠k := by have := ha j hj; omega
        exact Function.update_of_ne ne ..
      simp only [productBit,go q.1 bd.1,go q.2 bd.2]
    have same : ps.any (productBit w')=ps.any (productBit w) := by
      apply Bool.eq_iff_iff.mpr
      simp only [List.any_eq_true]
      exact ⟨fun ⟨q,m,b⟩ => ⟨q,m,(diff q m) ▸ b⟩,fun ⟨q,m,b⟩ => ⟨q,m,(diff q m).symm ▸ b⟩⟩
    change (readArm (run ps (k+1) w') (k::List.range' (k+1) ps.length)) = _
    change (run ps (k+1) w' k || readArm _ _) = _
    rw [stale_value _ (by omega),h,same]
    simp [w']
theorem terminal_ordered (ps : List Product) (n k : Nat) (le : n≤k)
    (prior : ∀ p ∈ ps, Below n p) : OrderedAt k ps := by
  induction ps generalizing k with
  | nil => trivial
  | cons p ps ih =>
    have bp := prior p List.mem_cons_self
    exact ⟨⟨fun i hi => Nat.lt_of_lt_of_le (bp.1 i hi) le,
      fun i hi => Nat.lt_of_lt_of_le (bp.2 i hi) le⟩,
      ih (k+1) (by omega) (fun q mem => prior q (List.mem_cons_of_mem _ mem))⟩
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.terminal_eval
