import CompactPriorSelected23Cell10
-- CompactPriorFace55
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_40 : CutRow book 8 40 12 := (joinRow (joinRow (joinRow row8_40_seg40 row8_40_seg43) row8_40_seg46) row8_40_seg49)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace56
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_52 : CutRow book 8 52 12 := (joinRow (joinRow (joinRow row8_52_seg52 row8_52_seg55) row8_52_seg58) row8_52_seg61)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
-- CompactPriorFace57
namespace PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.CircuitLowerBounds
namespace B701_11
theorem row8_64 : CutRow book 8 64 7 := (joinRow (joinRow row8_64_seg64 row8_64_seg67) row8_64_seg70)
end B701_11
end PEqualNP.Outside.L_meta_9825.Engine
