import H2QuadPairList9822
import H2PairDom02089822
import H2ShortDomTransport9822
import H2ShortDom02099822
import H2ShortDom02109822
import H2ShortDom02119822
import H2ShortDom02129822
import H2ShortDom03049822
import H2ShortDom03059822
namespace Research.Graph9822H2Check
def keys3 : List (Nat × Nat) := [(2,8), (2,9), (2,10), (2,11), (2,12), (3,4), (3,5)]
theorem paidKeys3 : keys3.all (fun p => pairDom p.1 p.2)=true := by
  simp only [keys3,List.all_cons,List.all_nil,Bool.and_eq_true_iff]
  exact ⟨dom2_8, dom_of_short (by decide) short_dom_2_9, dom_of_short (by decide) short_dom_2_10, dom_of_short (by decide) short_dom_2_11, dom_of_short (by decide) short_dom_2_12, dom_of_short (by decide) short_dom_3_4, dom_of_short (by decide) short_dom_3_5, True.intro⟩
end Research.Graph9822H2Check
