import CompactPriorSelected41
import Not9822PhysicalMany

namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.Outside.L_meta_9822.Clean PEqualNP.Outside.L_meta_9822.Sectors

theorem physicalBinaryFloor {gs o} (hr : Reduced 10 gs o)
    (ev : ∀ x, vl gs x o = Sectors.edge x) : 16 ≤ gs.countP Compact.bin :=
  reducedBinarySixteen h668_7 h701_11 h1015_14 hr ev

theorem physicalManyExcluded {gs o} (hr : Reduced 10 gs o)
    (ev : ∀ x, vl gs x o = Sectors.edge x) (size : gs.length ≤ 17)
    (many : 2 ≤ gs.countP countsNot) : False :=
  reducedManyImpossible h668_7 h701_11 h1015_14 hr ev size many

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.physicalBinaryFloor
#print axioms PEqualNP.Outside.L_meta_9822.Compact.physicalManyExcluded
