import SixH3BuildTape21567
import SixH3Physical21567Sockets9822

namespace Research.SixH3Bank.PricedTape
open PEqualNP.CircuitLowerBounds
open Research.Graph9822Orbit Research.Graph9822Orbit.H4Transport
open Research.Graph9822Profiles.OuterLive Research.Graph9822Profiles.OuterLive.PhysicalSocket
open Research.Graph9822Resolution (asGate)
open Research.Graph9822Resolution.SocketPaths (chosen)
open Research.Graph9822.TraceCount (Axis)

def destAxis (i : Fin 12) : Axis := ⟨i.val/2,by have := i.isLt; omega⟩
def destSide (i : Fin 12) := decide (i.val%2=1)

noncomputable def axisPerm {src dst p s} (chk : rowCheck src dst p s=true) : Axis ≃ Axis :=
  Equiv.ofBijective (reAxis (route_of_check chk)) ⟨Finite.injective_iff_surjective.mpr
    (axis_surjective chk _),axis_surjective chk _⟩

noncomputable def sourceAxis {src dst p s} (chk : rowCheck src dst p s=true) (i : Fin 12) :=
  (axisPerm chk).symm (destAxis i)

noncomputable def sourceSide {src dst p s} (chk : rowCheck src dst p s=true) (i : Fin 12) :=
  xor (destSide i) (s.testBit (axis p (sourceAxis chk i)))

theorem move_reads {src dst p s} (chk : rowCheck src dst p s=true)
    (users : Research.Graph9822.TraceCount.Sockets21567.Users) (i : Fin 12) :
    Socket21567.move (route_of_check chk) users (destAxis i) (destSide i) ↔
      users (sourceAxis chk i) (sourceSide chk i) := by
  have axisEq : reAxis (route_of_check chk) (sourceAxis chk i)=destAxis i :=
    (axisPerm chk).apply_symm_apply _
  constructor
  · rintro ⟨j,b,m,eq,sign⟩
    have orig : j=sourceAxis chk i := (axisPerm chk).injective (eq.trans axisEq.symm)
    subst j
    have same : b=sourceSide chk i := by
      unfold sourceSide
      cases z : s.testBit (axis p (sourceAxis chk i)) <;> cases b <;> simp_all
    exact same ▸ m
  · intro m
    refine ⟨_,_,m,axisEq,?_⟩
    unfold sourceSide
    cases s.testBit (axis p (sourceAxis chk i)) <;> simp

private theorem prefix_lt {D : Circuit} (gs : List DGate) (mapped : gs.map asGate=D.gates)
    {cap j} (z : Site gs cap j) : z.pre.length<D.gates.length := by
  rw [←mapped,List.length_map,z.split,List.length_append,List.length_cons]
  omega

def siteAddress {D : Circuit} (gs : List DGate) (mapped : gs.map asGate=D.gates)
    {cap j} (z : Site gs cap j) (side : Bool) : Address D :=
  ⟨⟨z.pre.length,prefix_lt gs mapped z⟩,!side⟩

theorem siteAddress_read {D : Circuit} (chart : Chart D) (gs : List DGate) (mapped : gs.map asGate=D.gates)
    {cap j} (z : Site gs cap j) (side : Bool) :
    atAddress chart (siteAddress gs mapped z side) =
      (chartWires D chart.h chart.q chart.s).getD (chosen z.gate side) ∅ := by
  have idx : D.gates[z.pre.length]?=some (asGate z.gate) := by
    rw [←mapped,List.getElem?_map]
    have entry : gs[z.pre.length]?=some z.gate := by
      rw [z.split,List.getElem?_append_right (Nat.le_refl _)]
      simp
    rw [entry]; rfl
  rw [List.getElem?_eq_getElem (prefix_lt gs mapped z)] at idx
  have gateEq := Option.some.inj idx
  cases side <;> simp [siteAddress,atAddress,arm,gateEq,asGate,chosen]

noncomputable def originalAddr {D : Circuit} (gs : List DGate) (mapped : gs.map asGate=D.gates)
    (six : gs.countP Research.Graph9822Resolution.Gate.isAnd=6) {src dst p s}
    (chk : rowCheck src dst p s=true) (i : Fin 12) : Address D :=
  siteAddress gs mapped (locate gs six (sourceAxis chk i)) (sourceSide chk i)

theorem signed_read {D : Circuit} (chart : Chart D) (gs : List DGate) (mapped : gs.map asGate=D.gates)
    (six : gs.countP Research.Graph9822Resolution.Gate.isAnd=6) {src dst p s}
    (chk : rowCheck src dst p s=true) (i : Fin 12) :
    atAddress chart (originalAddr gs mapped six chk i) =
      (chartWires D chart.h chart.q chart.s).getD
        (chosen (locate gs six (sourceAxis chk i)).gate (sourceSide chk i)) ∅ :=
  siteAddress_read ..

end Research.SixH3Bank.PricedTape
#print axioms Research.SixH3Bank.PricedTape.signed_read
