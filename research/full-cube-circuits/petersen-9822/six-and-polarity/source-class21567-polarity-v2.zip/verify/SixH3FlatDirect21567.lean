import SixH3FlatTape21567
namespace Research.Graph9822.FlatFactors21567.TapeAdapter
open Research.Graph9822.SixH3BV21567 (Tape part incidence direct)
def tag (z : BitVec 12) : Bool :=
  (z == 1) || (z == 2) || (z == 4) || (z == 5) || (z == 8) || (z == 9) || (z == 12) || (z == 13) || (z == 16) || (z == 32) || (z == 64) || (z == 80) || (z == 128) || (z == 144) || (z == 192) || (z == 208) || (z == 256) || (z == 512) || (z == 1024) || (z == 2048)
theorem direct_eq (w : Tape) (v : Nat) : direct w v = tag (incidence w v) := rfl

def joined (x0 x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 : BitVec 1) : BitVec 12 :=
  x11 ++ x10 ++ x9 ++ x8 ++ x7 ++ x6 ++ x5 ++ x4 ++ x3 ++ x2 ++ x1 ++ x0
def vertexBits (t : Flat) (v : Nat) := joined
  ((BitVec.ofFin t.r2).extractLsb' v 1) ((BitVec.ofFin t.j).extractLsb' v 1) ((BitVec.ofFin t.la).extractLsb' v 1) ((BitVec.ofFin t.lb).extractLsb' v 1) ((BitVec.ofFin t.r0).extractLsb' v 1) ((BitVec.ofFin t.g).extractLsb' v 1) ((BitVec.ofFin t.ka).extractLsb' v 1) ((BitVec.ofFin t.kb).extractLsb' v 1) ((BitVec.ofFin t.r1).extractLsb' v 1) ((BitVec.ofFin t.q).extractLsb' v 1) ((BitVec.ofFin t.ha).extractLsb' v 1) ((BitVec.ofFin t.hb).extractLsb' v 1)
theorem incidence_encode (t : Flat) (v : Nat) :
    incidence (encode t) v = vertexBits t v := by
  simp only [incidence,vertexBits,joined,port0,port1,port2,port3,port4,port5,port6,port7,port8,port9,port10,port11]

def literal (j : Fin 12) : BitVec 64 :=
  (#[6148914691236517205,12297829382473034410,1229782938247303441,4919131752989213764,1085102592571150095,17361641481138401520,4222189076152335,1080880403494997760,281470681808895,18446462603027742720,252706815,1085367505901322240] : Array (BitVec 64))[j.val]?.getD 0

/-- Ordinary union of the twelve canonical signed direction masks. -/
def reachedMask (z : BitVec 12) : BitVec 64 :=
  (if z.getLsbD 0 then 6148914691236517205 else 0) |||
  (if z.getLsbD 1 then 12297829382473034410 else 0) |||
  (if z.getLsbD 2 then 1229782938247303441 else 0) |||
  (if z.getLsbD 3 then 4919131752989213764 else 0) |||
  (if z.getLsbD 4 then 1085102592571150095 else 0) |||
  (if z.getLsbD 5 then 17361641481138401520 else 0) |||
  (if z.getLsbD 6 then 4222189076152335 else 0) |||
  (if z.getLsbD 7 then 1080880403494997760 else 0) |||
  (if z.getLsbD 8 then 281470681808895 else 0) |||
  (if z.getLsbD 9 then 18446462603027742720 else 0) |||
  (if z.getLsbD 10 then 252706815 else 0) |||
  (if z.getLsbD 11 then 1085367505901322240 else 0)

private theorem direct_table (z : BitVec 12) :
    tag z = ((reachedMask z == 6148914691236517205) || (reachedMask z == 12297829382473034410) || (reachedMask z == 1229782938247303441) || (reachedMask z == 4919131752989213764) || (reachedMask z == 1085102592571150095) || (reachedMask z == 17361641481138401520) || (reachedMask z == 4222189076152335) || (reachedMask z == 1080880403494997760) || (reachedMask z == 281470681808895) || (reachedMask z == 18446462603027742720) || (reachedMask z == 252706815) || (reachedMask z == 1085367505901322240)) := by
  unfold tag reachedMask
  bv_decide

private theorem on_literal (j : Fin 12) :
    literal j = 6148914691236517205 ∨ literal j = 12297829382473034410 ∨ literal j = 1229782938247303441 ∨ literal j = 4919131752989213764 ∨ literal j = 1085102592571150095 ∨ literal j = 17361641481138401520 ∨ literal j = 4222189076152335 ∨ literal j = 1080880403494997760 ∨ literal j = 281470681808895 ∨ literal j = 18446462603027742720 ∨ literal j = 252706815 ∨ literal j = 1085367505901322240 := by
  have all : ∀ i : Fin 12, literal i = 6148914691236517205 ∨ literal i = 12297829382473034410 ∨ literal i = 1229782938247303441 ∨ literal i = 4919131752989213764 ∨ literal i = 1085102592571150095 ∨ literal i = 17361641481138401520 ∨ literal i = 4222189076152335 ∨ literal i = 1080880403494997760 ∨ literal i = 281470681808895 ∨ literal i = 18446462603027742720 ∨ literal i = 252706815 ∨ literal i = 1085367505901322240 := by decide
  exact all j

theorem direct_from_receiver (t : Flat) (v : Nat) (j : Fin 12)
    (same : ∀ i : Fin 64, (reachedMask (vertexBits t v)).getLsbD i.val = (literal j).getLsbD i.val) :
    direct (encode t) v = true := by
  have eq : reachedMask (vertexBits t v) = literal j :=
    BitVec.eq_of_getLsbD_eq_iff.mpr (fun i hi => same ⟨i,hi⟩)
  rw [direct_eq,incidence_encode,direct_table,eq]
  rcases on_literal j with h|h|h|h|h|h|h|h|h|h|h|h <;> simp [h]

private theorem signed_tags (x0 x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 : BitVec 1) (left middle right : Bool) :
    tag (joined x0 x1 (if left then x2 else x3) (if left then x3 else x2) x4 x5 (if middle then x6 else x7) (if middle then x7 else x6) x8 x9 (if right then x10 else x11) (if right then x11 else x10)) =
    tag (joined x0 x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11) := by
  unfold tag joined
  bv_decide

theorem normalize_direct (t : Flat) (v : Nat) : direct (encode (normalize t)) v = direct (encode t) v := by
  rw [direct_eq,direct_eq,incidence_encode,incidence_encode]
  have same := signed_tags ((BitVec.ofFin t.r2).extractLsb' v 1) ((BitVec.ofFin t.j).extractLsb' v 1) ((BitVec.ofFin t.la).extractLsb' v 1) ((BitVec.ofFin t.lb).extractLsb' v 1) ((BitVec.ofFin t.r0).extractLsb' v 1) ((BitVec.ofFin t.g).extractLsb' v 1) ((BitVec.ofFin t.ka).extractLsb' v 1) ((BitVec.ofFin t.kb).extractLsb' v 1) ((BitVec.ofFin t.r1).extractLsb' v 1) ((BitVec.ofFin t.q).extractLsb' v 1) ((BitVec.ofFin t.ha).extractLsb' v 1) ((BitVec.ofFin t.hb).extractLsb' v 1)
    (decide (t.la≤t.lb)) (decide (t.ka≤t.kb)) (decide (t.ha≤t.hb))
  by_cases left : t.la≤t.lb <;> by_cases middle : t.ka≤t.kb <;> by_cases right : t.ha≤t.hb <;>
    simpa [vertexBits,normalize,pair,left,middle,right] using same

theorem sorted_direct_from_receiver (t : Flat) (v : Nat) (j : Fin 12)
    (same : ∀ i : Fin 64, (reachedMask (vertexBits t v)).getLsbD i.val = (literal j).getLsbD i.val) :
    direct (encode (normalize t)) v = true :=
  (normalize_direct t v).trans (direct_from_receiver t v j same)
end Research.Graph9822.FlatFactors21567.TapeAdapter
#print axioms Research.Graph9822.FlatFactors21567.TapeAdapter.sorted_direct_from_receiver
