import SixH3FlatMoveDirect21567
import SixH3FlatRawLocations21567
import SixH3FlatPaidScope21567
import SixH3SignedAddresses21567
import SixH3ActualRawSocket9822
namespace Research.Graph9822.FlatFactors21567.TapeAdapter.PaidRows
open Research.SixH3Bank Research.SixH3Bank.PricedTape Research.SixH2Front
open Research.Graph9822Resolution Research.Graph9822Resolution.FullCut (Path)
open Research.Graph9822Resolution.SocketPaths (chosen)
open Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles.OuterLive.PhysicalSocket
open Research.Graph9822Orbit Research.Graph9822Orbit.H4Transport
open Research.Graph9822.TraceCount (branch)
open PEqualNP.CircuitLowerBounds (Circuit)
open PEqualNP.Outside.L_meta_9822.Clean PEqualNP.Outside.L_meta_9822.Sectors

theorem raw_occurs {D : Circuit} (C : Chart D) (gs : List DGate) (mapped : gs.map asGate=D.gates)
    (six : gs.countP Gate.isAnd=6) (well : dWell gs 10) (valid : D.output<10+D.gates.length)
    (prior : Prior 10 D.gates) (noRaw : ∀ j∈front D,10≤j) (v : Fin 10) {src dst p s}
    (chk : rowCheck src dst p s=true) (j : Fin 12) :
    (rawAt (decode (physicalTape C (originalAddr gs mapped six chk))) j).val.testBit v.val=true ↔
      Socket21567.move (route_of_check chk) (rawUsers gs six.le v) (axisOf j) (signOf j) := by
  have sig : signOf j=destSide j := (by decide +kernel : ∀ k : Fin 12,signOf k=destSide k) j
  rw [show axisOf j=destAxis j from rfl,sig,move_reads,address_raw,
    SixH2Rows.pack_bit 10 _ v.isLt,decide_eq_true_eq,signed_read]
  let z := locate gs six (sourceAxis chk j)
  let b := sourceSide chk j
  change v.val∈(chartWires D C.h C.q C.s).getD (chosen z.gate b) ∅ ↔ _
  constructor
  · intro m
    exact ⟨z.pre,z.gate,z.post,z.split,z.on,z.tag,
      (TagReplay.raw_socket C gs z.pre z.post z.gate z.split mapped well valid prior noRaw v b).mp m⟩
  · rintro ⟨pre,g,post,sp,on,ax,path⟩
    let q : Site gs six.le (sourceAxis chk j) := ⟨pre,g,post,sp,on,ax⟩
    have eq : g=z.gate := TagReplay.same_site_gate q z
    rw [←eq]
    exact (TagReplay.raw_socket C gs pre post g sp mapped well valid prior noRaw v b).mpr path

theorem original_direct {D : Circuit} (C : Chart D) (gs : List DGate) (mapped : gs.map asGate=D.gates)
    (six : gs.countP Gate.isAnd=6) (well : dWell gs 10) (valid : D.output<10+D.gates.length)
    (prior : Prior 10 D.gates) (noRaw : ∀ j∈front D,10≤j)
    (red : Reduced 10 (gs.map asGate) D.output)
    (ok : ∀ x : Fin 10→Bool,(asCircuit gs D.output).eval (List.ofFn x)=edge x)
    (v : Fin 10) (no : ¬Path gs 10 v.val D.output) {p s}
    (chk : rowCheck (codes gs D.output six.le) Socket21567.row p s=true)
    (i : Fin 6) (b : Bool)
    (src : ∀ d : Fin 64, Research.Graph9822MaskCode.direction d.val∈tenR (chartAxis gs six.le) gs D.output v ↔
      branch (profile (codes gs D.output six.le)) i b d=true) :
    SixH3BV21567.direct (encode (normalize (decode (physicalTape C (originalAddr gs mapped six chk))))) v.val=true := by
  apply sorted_direct_of_move chk (route_of_check chk) (rawUsers gs six.le v) i b
  · intro d
    exact (raw_union gs D.output six.le red ok v no d).symm.trans (src d)
  · exact raw_occurs C gs mapped six well valid prior noRaw v chk
end Research.Graph9822.FlatFactors21567.TapeAdapter.PaidRows
#print axioms Research.Graph9822.FlatFactors21567.TapeAdapter.PaidRows.original_direct
