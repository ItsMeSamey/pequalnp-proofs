#!/usr/bin/env python3
"""Exhaust original inputs and direction words for two fixed physical controls."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
ROUTE = (0, 4, 2, 1, 3, 5)
ROW = [2**64-1, 6148914691236517205, 2**64-1, 1085102592571150095,
       2**64-1, 1085367506154029055]
EDGES = [(1,2),(3,4),(0,4),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(6,9),(6,8),(5,8)]
TAGS = {1,2,4,5,8,9,12,13,16,32,64,80,128,144,192,208,256,512,1024,2048}
LITERALS = [sum(1 << w for w in range(64) if ROW[j//2] >> w & 1
                and (w >> (j//2) & 1) == j%2) for j in range(12)]


def permute(word):
    return sum((word >> k & 1) << dest for k, dest in enumerate(ROUTE))


def check(filename):
    path = BASE / filename
    nodes = dict(enumerate(json.loads(path.read_text()), 10))
    axes = sorted((i for i,(op,_,_) in nodes.items() if op=='and'), reverse=True)
    assert len(nodes)==19 and len(axes)==6
    scopes = [1<<i for i in range(10)]
    ports = [0]*12
    for i,(op,left,right) in nodes.items():
        assert left<i and right<i and op in ('and','or')
        if op=='or':
            scopes.append(scopes[left] | scopes[right])
        else:
            k = ROUTE[axes.index(i)]
            # Lean picks left on true. XOR 63 sends left to canonical false.
            ports[2*k:2*k+2] = [scopes[left], scopes[right]]
            scopes.append(1<<(10+k))
    assert scopes[-1] == sum(1<<(10+k) for k in (0,2,4))
    marker_ports = [[j for j,port in enumerate(ports) if port>>(10+k)&1] for k in (1,3,5)]
    assert marker_ports == [[0],[4],[4,8]]
    raw = [p & 1023 for p in ports]
    sorted_raw = raw.copy()
    flip = 0
    for k in (1,3,5):
        if raw[2*k] > raw[2*k+1]:
            sorted_raw[2*k:2*k+2] = raw[2*k:2*k+2][::-1]
            flip |= 1<<k
    for x in range(1024):
        val = [bool(x>>v&1) for v in range(10)]
        for op,l,r in nodes.values():
            val.append(val[l] and val[r] if op=='and' else val[l] or val[r])
        s,j,l,v,r,g,c,d,u,q,a,b = (bool(p&x) for p in sorted_raw)
        flat = ((s or (l and v)) and j) or ((r or (a and b) or (c and d)) and g) or ((u or (a and b)) and q)
        assert flat == val[-1] == any((x>>i&1) and (x>>j&1) for i,j in EDGES)
    def reaches(w, lean):
        seen = {max(nodes)}
        for i,(op,l,r) in reversed(nodes.items()):
            if i in seen:
                if op=='or':
                    seen.update((l,r))
                else:
                    bit = w >> axes.index(i) & 1
                    seen.add(l if bit==int(lean) else r)
        return seen
    tags = [sum((p>>v&1)<<j for j,p in enumerate(sorted_raw)) for v in range(10)]
    receivers = [0]*10
    for w in range(64):
        actual = reaches(w,True)
        assert actual == reaches(w^63,False)
        z = permute(w)^63
        assert z==permute(w^63)
        zs = z^flip
        for k,i in enumerate(axes):
            assert (i in actual)==bool(ROW[ROUTE[k]]>>z&1)==bool(ROW[ROUTE[k]]>>zs&1)
        for v in range(10):
            reached = any(tag>>zs&1 and tags[v]>>j&1 for j,tag in enumerate(LITERALS))
            assert (v in actual)==reached
            receivers[v] |= int(v in actual)<<zs
    direct = [v for v in range(10) if tags[v] in TAGS]
    assert direct == [v for v in range(10) if receivers[v] in LITERALS]
    return dict(file=filename,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                original_area=len(nodes),original_axes=axes,route=ROUTE,native_xor=0,lean_xor=63,
                sorted_hidden_xor=flip,raw_ports=raw,sorted_ports=sorted_raw,
                sorted_incidence_tags=tags,direct_vertices=direct,marker_ports_LKH=marker_ports,
                checked_inputs=1024,checked_directions=64,checked_raw_direction_entries=640)


if __name__ == '__main__':
    print(json.dumps([check(f) for f in ('essential-two-user.json',
          'nonpinched-32-32-48-64-64-64.json')], indent=2))
