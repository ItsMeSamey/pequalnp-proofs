import SixH3FlatSockets21567
import SixH3SignedSockets215679822
namespace Research.Graph9822.FlatFactors21567.TapeAdapter
open Research.Graph9822.TraceCount
open Research.Graph9822.TraceCount.Sockets21567 (Users table)
open Research.Graph9822Orbit Research.Graph9822Orbit.H4Transport
open Research.Graph9822Orbit.H4Transport.Socket21567 (move row row_table)
open Research.Graph9822.SixH3BV21567 (direct)

private theorem socket_eta : ∀ (i : Axis) (s : Bool),
    axisOf (socketOf i s)=i ∧ signOf (socketOf i s)=s := by decide +kernel

theorem sorted_direct_of_move {src p s} (chk : rowCheck src row p s=true)
    (r : Route p s) (u : Users) (i : Axis) (b : Bool) (t : Flat) (v : Nat)
    (source : ∀ w : Word, (∃ j a, u j a ∧ branch (profile src) j a w=true) ↔
      branch (profile src) i b w=true)
    (bits : ∀ j, (rawAt t j).val.testBit v=true ↔ move r u (axisOf j) (signOf j)) :
    direct (encode (normalize t)) v=true := by
  apply sorted_direct_of_socket t v (reAxis r i) (xor b (s.testBit (axis p i)))
  intro w
  obtain ⟨z,rfl⟩ := dest_surjective r w
  rw [←row_table,←branch_move chk r i b z,←source z]
  constructor
  · rintro ⟨j,mem,hit⟩
    obtain ⟨k,a,raw,ax,side⟩ := (bits j).mp mem
    rw [←ax,←side,←branch_move chk r k a z] at hit
    exact ⟨k,a,raw,hit⟩
  · rintro ⟨k,a,raw,hit⟩
    let y := reAxis r k
    let c := xor a (s.testBit (axis p k))
    obtain ⟨e,f⟩ := socket_eta y c
    refine ⟨socketOf y c,(bits _).mpr ⟨k,a,raw,e.symm,f.symm⟩,?_⟩
    rw [e,f]
    exact (branch_move chk r k a z).symm.trans hit
end Research.Graph9822.FlatFactors21567.TapeAdapter
#print axioms Research.Graph9822.FlatFactors21567.TapeAdapter.sorted_direct_of_move
