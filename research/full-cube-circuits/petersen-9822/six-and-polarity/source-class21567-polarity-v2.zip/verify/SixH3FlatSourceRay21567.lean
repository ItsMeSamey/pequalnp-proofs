import SixH3FlatRawLocations21567
namespace Research.Graph9822Profiles.OuterLive.PhysicalSocket
open Research.Graph9822Resolution
open Research.Graph9822MaskCode (direction)
open Research.Graph9822Orbit.H4Transport (profile)
open Research.Graph9822.TraceCount (sampleMask branch)
open Research.Graph9822Profiles
open PEqualNP.Outside.L_meta_9822.Clean

theorem source_ray (gs : List DGate) (out : Nat) (cap : gs.countP Gate.isAnd≤6)
    (v : Fin 10) (i : Axis) (b : Bool)
    (direct : tenR (chartAxis gs cap) gs out v=
      field (((gateEvents (chartAxis gs cap) gs 10 ++ rawEvents 10).foldl paddedStep (initial out)).switches) i ∩ side i b)
    (d : Fin 64) :
    direction d.val∈tenR (chartAxis gs cap) gs out v ↔ branch (profile (codes gs out cap)) i b d=true := by
  rw [direct,decode]
  let rows := ((gateEvents (chartAxis gs cap) gs 10 ++ rawEvents 10).foldl paddedStep (initial out)).switches
  have a := congrFun (fields_code rows i) d
  change decide (direction d.val∈field rows i)=(fields gs out cap i).testBit d.val at a
  change (direction d.val∈field rows i ∩ side i b) ↔
    ((fields gs out cap i).testBit d.val && (d.val.testBit i.val == b))=true
  rw [←a,Bool.and_eq_true_iff,decide_eq_true_eq,beq_iff_eq]
  rfl
end Research.Graph9822Profiles.OuterLive.PhysicalSocket
#print axioms Research.Graph9822Profiles.OuterLive.PhysicalSocket.source_ray
