"""Independent checks on original gate lists, with the selector polarity used by Lean."""
from pathlib import Path
import json, re
root=Path(__file__).resolve().parents[1]
row=tuple(map(int,(root/'profile21567.txt').read_text().split()[-6:]))
perm=(0,4,2,1,3,5)
R=[sum(1<<w for w in range(64) if (row[i]>>w)&1 and (w>>i)&1==b) for i in range(6) for b in [0,1]]
def move(w,sign):
 return sum((w>>i&1)<<j for i,j in enumerate(perm))^sign
def merge(z):
 return __import__('functools').reduce(int.__or__,(r for i,r in enumerate(R) if z>>i&1),0)
accepted={z for z in range(4096) if merge(z) in R}
src=(root/'verify/SixH3FlatDirect21567.lean').read_text()
decl={int(z) for z in re.findall(r'\(z == (\d+)\)',src.split('theorem direct_eq')[0])}
assert accepted==decl
for z in range(4096):
 for f in range(8):
  swaps=z
  for j in range(3):
   if f>>j&1:
    k=[2,6,10][j]
    swaps^=3<<k if ((swaps>>k)^(swaps>>(k+1)))&1 else 0
  assert (z in accepted)==(swaps in accepted)
print('tag count',len(accepted),'tested all 4096 x eight operand orders')
for name in ['essential-two-user.json','nonpinched-32-32-48-64-64-64.json']:
 g=json.loads((root/name).read_text());out=len(g)+9
 axes=sorted((10+j for j,(op,*_) in enumerate(g) if op=='and'),reverse=True)
 raw=[1<<i for i in range(10)];ports=[0]*12
 for j,(op,left,right) in enumerate(g,10):
  if op=='or':raw.append(raw[left]|raw[right]);continue
  raw.append(0)
  k=axes.index(j)
  for sourceBit in [0,1]:
   canonical=2*perm[k]+(sourceBit^1)
   ports[canonical]=raw[left if sourceBit else right]
 semantic=[0]*10;fields=[0]*6
 for w in range(64):
  seen={out};z=move(w,63)
  for j in range(out,9,-1):
   if j not in seen:continue
   op,a,b=g[j-10]
   if op=='or':seen.update([a,b]);continue
   k=axes.index(j);fields[perm[k]]|=1<<z;seen.add(a if w>>k&1 else b)
  for i in range(10):
   if i in seen:semantic[i]|=1<<z
 assert tuple(fields)==row
 incidence=[sum((x>>v&1)<<k for k,x in enumerate(ports)) for v in range(10)]
 assert [merge(z) for z in incidence]==semantic
 direct=[v for v,z in enumerate(incidence) if z in accepted]
 assert (len(direct)==4) if name=='essential-two-user.json' else (len(direct) in [2,3,4])
 print(name,'source axis',axes,'raw ports',ports,'receivers',semantic,'direct vertices',direct)
