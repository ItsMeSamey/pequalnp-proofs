import H2FastInitial9822
import OR9822H2NestedSaturation
import OR9822H1Safe
import OR9822H1GrantFold
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)

def residual2 (h c : Nat) := 8191 ^^^ (rawPos c ||| (positive h &&& rawPos (freeRaw (negative h))))

theorem centers_3 {x y z : Nat} (xy : x<y) (yz : y<z) (bound : z<10) :
    bit x ||| bit y ||| bit z ∈ centers := by
  simp only [centers,List.bind_eq_flatMap,List.mem_flatMap]
  refine ⟨x,List.mem_range.mpr (by omega),y,List.mem_range.mpr (by omega),?_⟩
  simp [xy]
  exact ⟨z,List.mem_range.mpr bound,by simp [yz]⟩

theorem initial_from_mode {h q c : Nat} (cent : c∈centers) (bound : negative h<65536)
    (pos : sub (residual2 h c) (positive q)=true)
    (mode : sub (residual2 h c) (rawPos (freeRaw (negative q)))=true ∨
      (meets (negative h) (negative q)=false ∧
        sub (residual2 h c &&& (8191 ^^^ positive h)) (rawPos (freeRaw (negative q)))=true))
    (possible : ∀ s, holds q s → fastFeasible h s=true) :
    ∃ s∈fastInitial h,holds q s := by
  obtain ⟨use,cover,safe⟩ : ∃ use : Bool,
      sub (if use then residual2 h c &&& (8191 ^^^ positive h) else residual2 h c)
        (rawPos (freeRaw (negative q)))=true ∧
      (use=true → meets (negative h) (negative q)=false) := by
    rcases mode with u|⟨v,w⟩
    · exact ⟨false,u,by simp⟩
    · exact ⟨true,w,fun _ => v⟩
  obtain ⟨x,xm,xq,_⟩ := fast_cover_below cover
  have xn := Graph9822H1Check.sub_free_safe xq
  have negRawBound : rawNeg x<65536 := Graph9822H1Check.mask_lt1 _ _
  have raw := negative_shore (q:=q) negRawBound (fun n ff => (empty_overlap ..).1 xn n.val ff)
  have pLive : holds q (residual2 h c) := by
    apply (subset_bits ..).2
    intro i on
    have pe := (subset_bits ..).1 pos i on
    have both := Bool.and_eq_true_iff.mp (by simpa only [positive,Nat.testBit_and] using pe)
    have lo : i<13 := by
      by_contra! out
      have z : (8191:Nat).testBit i=false := Nat.testBit_lt_two_pow
        (lt_of_lt_of_le (by decide : 8191<2^13) (Nat.pow_le_pow_right (by decide) out))
      exact Bool.noConfusion (both.2.symm.trans z)
    change (q ^^^ ((65535 : Nat) <<< 13)).testBit i=true
    rw [Nat.testBit_xor,Nat.testBit_shiftLeft]
    simp [show ¬i≥13 by omega,both.1]
  let state := demand (residual2 h c) (rawNeg x ||| (if use then negative h else 0))
  have live : holds q state := by
    cases eu : use
    · simpa [holds,state,eu,demand] using join_subset pLive raw
    · have ih := negative_shore (q:=q) bound (fun n ff => (empty_overlap ..).1 (safe eu) n.val ff)
      simpa [holds,state,eu,demand,Nat.shiftLeft_or_distrib] using join_subset pLive (join_subset raw ih)
  have fea := possible state live
  let pool : List Nat := do
    let v ← centers
    let t := residual2 h v
    let u ← [false,true]
    let a ← fastCovers (if u then t &&& (8191 ^^^ positive h) else t)
    let s := demand t (rawNeg a ||| (if u then negative h else 0))
    guard (fastFeasible h s)
    return s
  have mem : state∈pool := by
    simp only [pool,List.bind_eq_flatMap,List.mem_flatMap]
    refine ⟨c,cent,use,by cases use <;> simp,x,xm,?_⟩
    change ∃ u ∈ (guard (fastFeasible h state=true) : List Unit), state∈(pure state : List Nat)
    simp [fea]
  obtain ⟨k,hk,le⟩ := minimal_weakens mem
  exact ⟨k,hk,weaker_holds le live⟩
end Research.Graph9822H2Check
#print axioms Research.Graph9822H2Check.initial_from_mode
