import OR9822H2EligibleBlock14
import OR9822H2EligibleBlock15
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet07 : List (Nat × Nat × Nat) := [(201,525,1568),(201,554,1816),(201,556,1832),(201,771,3664),(201,773,3680),(208,276,2080),(208,387,2068),(208,402,2064),(208,523,1686),(208,525,1702)]
theorem certified07 {x : Nat × Nat × Nat} (mem : x∈rowSet07) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet07,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested070⟩
  · exact ⟨_,tested071⟩
  · exact ⟨_,tested072⟩
  · exact ⟨_,tested073⟩
  · exact ⟨_,tested074⟩
  · exact ⟨_,tested075⟩
  · exact ⟨_,tested076⟩
  · exact ⟨_,tested077⟩
  · exact ⟨_,tested078⟩
  · exact ⟨_,tested079⟩
end Research.Graph9822H2Eligibility
