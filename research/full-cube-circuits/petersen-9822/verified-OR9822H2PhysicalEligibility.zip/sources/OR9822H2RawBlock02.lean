import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility

open Research.Graph9822H2Check
theorem raw08 : ∀ i : Fin 64, code (512+i.val)=demand (rawPos (512+i.val)) (rawNeg (512+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw09 : ∀ i : Fin 64, code (576+i.val)=demand (rawPos (576+i.val)) (rawNeg (576+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw10 : ∀ i : Fin 64, code (640+i.val)=demand (rawPos (640+i.val)) (rawNeg (640+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw11 : ∀ i : Fin 64, code (704+i.val)=demand (rawPos (704+i.val)) (rawNeg (704+i.val)) := by decide +kernel
end Research.Graph9822H2Eligibility
