import OR9822H2EligiblePackedCore
import OR9822H2RawPage00
namespace Research.Graph9822H2Eligibility

open Research.Graph9822H2Check
theorem raw01 : ∀ i : Fin 64, code (64+i.val)=demand (rawPos (64+i.val)) (rawNeg (64+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw02 : ∀ i : Fin 64, code (128+i.val)=demand (rawPos (128+i.val)) (rawNeg (128+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw03 : ∀ i : Fin 64, code (192+i.val)=demand (rawPos (192+i.val)) (rawNeg (192+i.val)) := by decide +kernel
end Research.Graph9822H2Eligibility
