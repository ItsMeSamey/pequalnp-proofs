import OR9822H2RealBlock00
import OR9822H2RealBlock01
import OR9822H2RealBlock02
import OR9822H2RealBlock03
import OR9822H2RealBlock04
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
theorem seed_eq {j : Nat} (bound : j<1035) : let p:=source j; p.1<1024 ∧ p.2<1024 ∧ Graph9822OneHidden.meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by
  by_cases b0 : j<64
  · have eq : 0+(j-0)=j := by omega
    simpa only [eq] using (real00 ⟨j-0,by omega⟩)
  by_cases b1 : j<128
  · have eq : 64+(j-64)=j := by omega
    simpa only [eq] using (real01 ⟨j-64,by omega⟩)
  by_cases b2 : j<192
  · have eq : 128+(j-128)=j := by omega
    simpa only [eq] using (real02 ⟨j-128,by omega⟩)
  by_cases b3 : j<256
  · have eq : 192+(j-192)=j := by omega
    simpa only [eq] using (real03 ⟨j-192,by omega⟩)
  by_cases b4 : j<320
  · have eq : 256+(j-256)=j := by omega
    simpa only [eq] using (real04 ⟨j-256,by omega⟩)
  by_cases b5 : j<384
  · have eq : 320+(j-320)=j := by omega
    simpa only [eq] using (real05 ⟨j-320,by omega⟩)
  by_cases b6 : j<448
  · have eq : 384+(j-384)=j := by omega
    simpa only [eq] using (real06 ⟨j-384,by omega⟩)
  by_cases b7 : j<512
  · have eq : 448+(j-448)=j := by omega
    simpa only [eq] using (real07 ⟨j-448,by omega⟩)
  by_cases b8 : j<576
  · have eq : 512+(j-512)=j := by omega
    simpa only [eq] using (real08 ⟨j-512,by omega⟩)
  by_cases b9 : j<640
  · have eq : 576+(j-576)=j := by omega
    simpa only [eq] using (real09 ⟨j-576,by omega⟩)
  by_cases b10 : j<704
  · have eq : 640+(j-640)=j := by omega
    simpa only [eq] using (real10 ⟨j-640,by omega⟩)
  by_cases b11 : j<768
  · have eq : 704+(j-704)=j := by omega
    simpa only [eq] using (real11 ⟨j-704,by omega⟩)
  by_cases b12 : j<832
  · have eq : 768+(j-768)=j := by omega
    simpa only [eq] using (real12 ⟨j-768,by omega⟩)
  by_cases b13 : j<896
  · have eq : 832+(j-832)=j := by omega
    simpa only [eq] using (real13 ⟨j-832,by omega⟩)
  by_cases b14 : j<960
  · have eq : 896+(j-896)=j := by omega
    simpa only [eq] using (real14 ⟨j-896,by omega⟩)
  by_cases b15 : j<1024
  · have eq : 960+(j-960)=j := by omega
    simpa only [eq] using (real15 ⟨j-960,by omega⟩)
  by_cases b16 : j<1035
  · have eq : 1024+(j-1024)=j := by omega
    simpa only [eq] using (real16 ⟨j-1024,by omega⟩)
  omega
end Research.Graph9822H2Eligibility
