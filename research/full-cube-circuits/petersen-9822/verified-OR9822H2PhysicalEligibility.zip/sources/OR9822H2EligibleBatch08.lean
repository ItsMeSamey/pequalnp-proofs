import OR9822H2EligibleBlock16
import OR9822H2EligibleBlock17
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet08 : List (Nat × Nat × Nat) := [(208,554,1938),(208,556,1954),(208,771,3732),(208,773,3748),(276,387,37),(276,402,33),(276,523,199),(276,525,198),(276,554,4291),(276,556,4290)]
theorem certified08 {x : Nat × Nat × Nat} (mem : x∈rowSet08) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet08,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested080⟩
  · exact ⟨_,tested081⟩
  · exact ⟨_,tested082⟩
  · exact ⟨_,tested083⟩
  · exact ⟨_,tested084⟩
  · exact ⟨_,tested085⟩
  · exact ⟨_,tested086⟩
  · exact ⟨_,tested087⟩
  · exact ⟨_,tested088⟩
  · exact ⟨_,tested089⟩
end Research.Graph9822H2Eligibility
