import OR9822H2EligibleGeometry
import OR9822H2AllRegions
import OR9822H2AllRaw
import OR9822H2AllReal
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check Research.Graph9822OneHidden

theorem pareto_member {a b : Nat} (aa : a<1024) (bb : b<1024) (dis : meets a b=false)
    (leak : negative (code a &&& code b)≠0)
    (star : ∀ v : Fin 10,sub (positive (code a &&& code b)) (positive (code (bit v.val)))=false)
    (i j : Fin 16) (ord : i<j)
    (ci : meets a (mis i)=false ∨ meets b (mis i)=false)
    (cj : meets a (mis j)=false ∨ meets b (mis j)=false)
    (hit : sub (inside (mis i) (mis j)) (positive (code a &&& code b))=true) :
    ∃ idx k : Nat, keys[idx]?=some k ∧ sub (k ^^^ 8191) ((code a &&& code b) ^^^ 8191)=true := by
  obtain ⟨hints,run⟩ := regions_audited (region_for i j ord)
  rcases ci with left|right
  · have row := has_row aa bb dis left cj hit
    obtain ⟨tag,v⟩ := verdict_at run row
    exact certified_key v leak star
  · have swap : meets b a=false := by simpa [meets,Nat.and_comm] using dis
    have hit' : sub (inside (mis i) (mis j)) (positive (code b &&& code a))=true := by
      simpa [Nat.and_comm] using hit
    have row := has_row bb aa swap right cj.symm hit'
    obtain ⟨tag,v⟩ := verdict_at run row
    rw [Nat.and_comm (code b) (code a)] at v
    exact certified_key v leak star

theorem key_has_physical {idx k : Nat} (read : keys[idx]?=some k) :
    ∃ a b : Nat, a<1024 ∧ b<1024 ∧ meets a b=false ∧ k=code a &&& code b := by
  have lt : idx<1035 := by
    by_contra! bad
    have off : keys.size ≤ idx := by simpa [keys] using bad
    rw [Array.getElem?_eq_none off] at read
    contradiction
  obtain ⟨al,bl,sep,rec⟩ := seed_eq lt
  have val : seedCode idx=k := by simpa [keys_read,seedAt,lt] using read
  exact ⟨_,_,al,bl,sep,val.symm.trans rec⟩
end Research.Graph9822H2Eligibility
#print axioms Research.Graph9822H2Eligibility.pareto_member
#print axioms Research.Graph9822H2Eligibility.key_has_physical
