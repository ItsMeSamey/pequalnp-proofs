import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility

open Research.Graph9822H2Check
theorem raw04 : ∀ i : Fin 64, code (256+i.val)=demand (rawPos (256+i.val)) (rawNeg (256+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw05 : ∀ i : Fin 64, code (320+i.val)=demand (rawPos (320+i.val)) (rawNeg (320+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw06 : ∀ i : Fin 64, code (384+i.val)=demand (rawPos (384+i.val)) (rawNeg (384+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw07 : ∀ i : Fin 64, code (448+i.val)=demand (rawPos (448+i.val)) (rawNeg (448+i.val)) := by decide +kernel
end Research.Graph9822H2Eligibility
