import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
theorem raw00 : ∀ i : Fin 64, code (0+i.val)=demand (rawPos (0+i.val)) (rawNeg (0+i.val)) := by decide +kernel
end Research.Graph9822H2Eligibility
