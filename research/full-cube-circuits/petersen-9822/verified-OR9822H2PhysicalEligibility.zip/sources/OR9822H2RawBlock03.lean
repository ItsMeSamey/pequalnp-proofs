import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility

open Research.Graph9822H2Check
theorem raw12 : ∀ i : Fin 64, code (768+i.val)=demand (rawPos (768+i.val)) (rawNeg (768+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw13 : ∀ i : Fin 64, code (832+i.val)=demand (rawPos (832+i.val)) (rawNeg (832+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw14 : ∀ i : Fin 64, code (896+i.val)=demand (rawPos (896+i.val)) (rawNeg (896+i.val)) := by decide +kernel

open Research.Graph9822H2Check
theorem raw15 : ∀ i : Fin 64, code (960+i.val)=demand (rawPos (960+i.val)) (rawNeg (960+i.val)) := by decide +kernel
end Research.Graph9822H2Eligibility
