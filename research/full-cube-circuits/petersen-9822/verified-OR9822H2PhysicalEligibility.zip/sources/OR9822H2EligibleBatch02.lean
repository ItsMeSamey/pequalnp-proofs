import OR9822H2EligibleBlock04
import OR9822H2EligibleBlock05
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet02 : List (Nat × Nat × Nat) := [(77,276,2118),(77,387,2161),(77,402,2167),(77,523,1041),(77,525,1024),(77,554,1049),(77,556,1032),(77,771,3153),(77,773,3136),(108,116,2)]
theorem certified02 {x : Nat × Nat × Nat} (mem : x∈rowSet02) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet02,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested020⟩
  · exact ⟨_,tested021⟩
  · exact ⟨_,tested022⟩
  · exact ⟨_,tested023⟩
  · exact ⟨_,tested024⟩
  · exact ⟨_,tested025⟩
  · exact ⟨_,tested026⟩
  · exact ⟨_,tested027⟩
  · exact ⟨_,tested028⟩
  · exact ⟨_,tested029⟩
end Research.Graph9822H2Eligibility
