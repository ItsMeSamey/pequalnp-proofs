import OR9822H2EligibleBlock22
import OR9822H2EligibleBlock23
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet11 : List (Nat × Nat × Nat) := [(525,554,9),(525,556,8),(525,771,65),(525,773,64),(554,556,1),(554,771,4168),(554,773,4169),(556,771,4169),(556,773,4168),(771,773,1)]
theorem certified11 {x : Nat × Nat × Nat} (mem : x∈rowSet11) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet11,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested110⟩
  · exact ⟨_,tested111⟩
  · exact ⟨_,tested112⟩
  · exact ⟨_,tested113⟩
  · exact ⟨_,tested114⟩
  · exact ⟨_,tested115⟩
  · exact ⟨_,tested116⟩
  · exact ⟨_,tested117⟩
  · exact ⟨_,tested118⟩
  · exact ⟨_,tested119⟩
end Research.Graph9822H2Eligibility
