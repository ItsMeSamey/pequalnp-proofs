import OR9822H2EligibleBlock18
import OR9822H2EligibleBlock19
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet09 : List (Nat × Nat × Nat) := [(276,771,133),(276,773,132),(387,402,4),(387,523,576),(387,525,609),(387,554,4936),(387,556,4969),(387,771,512),(387,773,545),(402,523,710)]
theorem certified09 {x : Nat × Nat × Nat} (mem : x∈rowSet09) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet09,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested090⟩
  · exact ⟨_,tested091⟩
  · exact ⟨_,tested092⟩
  · exact ⟨_,tested093⟩
  · exact ⟨_,tested094⟩
  · exact ⟨_,tested095⟩
  · exact ⟨_,tested096⟩
  · exact ⟨_,tested097⟩
  · exact ⟨_,tested098⟩
  · exact ⟨_,tested099⟩
end Research.Graph9822H2Eligibility
