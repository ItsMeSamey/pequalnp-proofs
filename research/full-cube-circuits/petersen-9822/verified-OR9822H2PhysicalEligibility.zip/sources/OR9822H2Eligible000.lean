import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility
def hints000 : List Nat := [422,423,961,962,995,998,995,998,438,966,1041,1041,438,440,1042,1045,438,1042,422,423,961,962,438,966,438,440,438]
theorem tested000 : audit (domain 50 77 31) hints000 = true := by decide +kernel
end Research.Graph9822H2Eligibility
