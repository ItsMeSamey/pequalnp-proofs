import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real04 : ∀ i : Fin 64, let j:Nat:=256+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real05 : ∀ i : Fin 64, let j:Nat:=320+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real06 : ∀ i : Fin 64, let j:Nat:=384+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real07 : ∀ i : Fin 64, let j:Nat:=448+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel
end Research.Graph9822H2Eligibility
