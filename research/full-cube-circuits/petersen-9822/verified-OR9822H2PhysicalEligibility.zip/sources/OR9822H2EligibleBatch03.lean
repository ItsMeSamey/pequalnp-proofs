import OR9822H2EligibleBlock06
import OR9822H2EligibleBlock07
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet03 : List (Nat × Nat × Nat) := [(108,139,313),(108,201,296),(108,208,290),(108,276,6210),(108,387,6521),(108,402,6515),(108,523,1049),(108,525,1032),(108,554,1041),(108,556,1024)]
theorem certified03 {x : Nat × Nat × Nat} (mem : x∈rowSet03) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet03,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested030⟩
  · exact ⟨_,tested031⟩
  · exact ⟨_,tested032⟩
  · exact ⟨_,tested033⟩
  · exact ⟨_,tested034⟩
  · exact ⟨_,tested035⟩
  · exact ⟨_,tested036⟩
  · exact ⟨_,tested037⟩
  · exact ⟨_,tested038⟩
  · exact ⟨_,tested039⟩
end Research.Graph9822H2Eligibility
