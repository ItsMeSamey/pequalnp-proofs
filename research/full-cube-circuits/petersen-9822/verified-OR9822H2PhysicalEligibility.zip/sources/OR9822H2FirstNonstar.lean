import OR9822H2PhysicalLeaks
import OR9822RawColumnCode
import OR9822ParetoRows
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FeatureRun Research.Graph9822H2Check
open Research.Graph9822.FourSaturation

private theorem misses_raw : ∀ (v : Fin 10) e, e∈edges → v.val≠e.1 → v.val≠e.2 →
    ∃ k : Fin 13, rawRow ⟨k.val,by omega⟩ = edgeMask e ∧
      (positive (rawCode (bit v.val))).testBit k.val=false := by
  intro v e mem
  have finite : ∀ (w : Fin 10), ∀ g∈edges, w.val≠g.1 → w.val≠g.2 →
      ∃ k : Fin 13, rawRow ⟨k.val,by omega⟩ = edgeMask g ∧
        (positive (rawCode (bit w.val))).testBit k.val=false := by decide +kernel
  exact finite v e mem

theorem actual_nonstar (C : MaximumFive) (p q : Product)
    (hp : (hiddenFirst C.toFiveProgram).1=[p,q]) :
    negative (encode (firstCol p))≠0 ∧
      ∀ v : Fin 10, sub (positive (encode (firstCol p))) (positive (rawCode (bit v.val)))=false := by
  obtain ⟨n,on⟩ := (physical_leaks2 C p q hp).1
  constructor
  · change (negative (encode (firstCol p))).testBit n.val=true at on
    intro off; simp [off] at on
  · intro v
    obtain ⟨e,he,fire,nl,nr⟩ := (compact_hidden_witness C [] [q] p hp).2 v
    obtain ⟨k,mask,cold⟩ := misses_raw v e he nl nr
    have hot : (positive (encode (firstCol p))).testBit k.val=true := by
      rw [pos_col_bit,first_on_row,mask]
      exact fire
    apply Bool.eq_false_iff.mpr
    intro incl
    have impossible := (subset_bits ..).1 incl k.val hot
    exact Bool.noConfusion (impossible.symm.trans cold)
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.actual_nonstar
