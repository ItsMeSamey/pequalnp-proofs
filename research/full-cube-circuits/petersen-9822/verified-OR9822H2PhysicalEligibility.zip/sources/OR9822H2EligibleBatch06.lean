import OR9822H2EligibleBlock12
import OR9822H2EligibleBlock13
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet06 : List (Nat × Nat × Nat) := [(139,525,545),(139,554,776),(139,556,809),(139,771,576),(139,773,609),(201,208,6),(201,276,2150),(201,387,2128),(201,402,2134),(201,523,1552)]
theorem certified06 {x : Nat × Nat × Nat} (mem : x∈rowSet06) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet06,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested060⟩
  · exact ⟨_,tested061⟩
  · exact ⟨_,tested062⟩
  · exact ⟨_,tested063⟩
  · exact ⟨_,tested064⟩
  · exact ⟨_,tested065⟩
  · exact ⟨_,tested066⟩
  · exact ⟨_,tested067⟩
  · exact ⟨_,tested068⟩
  · exact ⟨_,tested069⟩
end Research.Graph9822H2Eligibility
