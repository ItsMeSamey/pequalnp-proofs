import OR9822H2EligibleBlock20
import OR9822H2EligibleBlock21
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet10 : List (Nat × Nat × Nat) := [(402,525,743),(402,554,5058),(402,556,5091),(402,771,644),(402,773,677),(523,525,1),(523,554,8),(523,556,9),(523,771,64),(523,773,65)]
theorem certified10 {x : Nat × Nat × Nat} (mem : x∈rowSet10) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet10,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested100⟩
  · exact ⟨_,tested101⟩
  · exact ⟨_,tested102⟩
  · exact ⟨_,tested103⟩
  · exact ⟨_,tested104⟩
  · exact ⟨_,tested105⟩
  · exact ⟨_,tested106⟩
  · exact ⟨_,tested107⟩
  · exact ⟨_,tested108⟩
  · exact ⟨_,tested109⟩
end Research.Graph9822H2Eligibility
