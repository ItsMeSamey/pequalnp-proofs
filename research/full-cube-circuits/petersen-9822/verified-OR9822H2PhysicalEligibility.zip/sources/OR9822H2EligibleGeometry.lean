import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
open Research.Graph9822H1Check (extras_complete)
open Research.Graph9822OneHidden (meets)

private theorem below_diff {x y : Nat} (low : x<1024) (dis : meets x y=false) :
    sub x (1023 ^^^ y)=true := by
  have bound : sub x 1023=true := beq_iff_eq.mpr (Nat.and_two_pow_sub_one_of_lt_two_pow (n:=10) low)
  apply (subset_bits ..).2
  intro n nx
  simp [(subset_bits ..).1 bound n nx,(empty_overlap ..).1 dis n nx]

theorem has_row {i j req a b : Nat} (aa : a<1024) (bb : b<1024)
    (dis : meets a b=false) (left : meets a i=false)
    (right : meets a j=false ∨ meets b j=false)
    (hit : sub req (positive (code a &&& code b))=true) :
    (a,b) ∈ domain i j req := by
  have ab := extras_complete aa (below_diff aa left)
  have ca : sub req (positive (code a))=true := by
    apply (subset_bits ..).2;intro k hk
    have hot := (subset_bits ..).1 hit k hk
    simp only [positive,Nat.testBit_and,Bool.and_eq_true] at hot ⊢
    exact ⟨hot.1.1,hot.2⟩
  have cb : sub req (positive (code b))=true := by
    apply (subset_bits ..).2;intro k hk
    have hot := (subset_bits ..).1 hit k hk
    simp only [positive,Nat.testBit_and,Bool.and_eq_true] at hot ⊢
    exact ⟨hot.1.2,hot.2⟩
  have ba : meets b a=false := by simpa [meets,Nat.and_comm] using dis
  have bm : sub b ((1023 ^^^ a) &&& (if meets a j then 1023 ^^^ j else 1023))=true := by
    apply (subset_bits ..).2;intro k kb
    have cold := (subset_bits ..).1 (below_diff bb ba) k kb
    have bound : sub b 1023=true := beq_iff_eq.mpr (Nat.and_two_pow_sub_one_of_lt_two_pow (n:=10) bb)
    cases ja : meets a j
    · simp [ja,cold,(subset_bits ..).1 bound k kb]
    · have jb : meets b j=false := right.resolve_left (by simp [ja])
      simp [ja,cold,(subset_bits ..).1 (below_diff bb jb) k kb]
  have be := extras_complete bb bm
  simp only [domain,List.bind_eq_flatMap,List.mem_flatMap]
  refine ⟨a,ab,?_⟩
  simp [ca]
  exact ⟨be,by simp [cb]⟩
end Research.Graph9822H2Eligibility
