import OR9822H1SeedFit
import OR9822H2DemandBits
import H2FastStep9822
import H2MinimalWitness9822
import OR9822H1Subshore

namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
structure NestedBits (h q a b : Nat) (use : Bool) : Prop where
  pos : ∀ e : Fin 13, (positive q).testBit e.val =
    (((rawPos a).testBit e.val || (use && (positive h).testBit e.val)) && (rawPos b).testBit e.val)
  neg : ∀ n : Fin 16, (negative q).testBit n.val =
    (((rawNeg a).testBit n.val || (use && (negative h).testBit n.val)) && (rawNeg b).testBit n.val)

private theorem initialPosBound (s : Nat) : positive s<8192 :=
  lt_of_le_of_lt Nat.and_le_right (by decide)

theorem fast_cover_below {t b : Nat} (cover : sub t (rawPos b)=true) :
    ∃ m ∈ fastCovers t, sub m b=true ∧ sub t (rawPos m)=true := by
  obtain ⟨m,mem,le,cov⟩ := Graph9822H1Check.raw_has_seed cover
  have data : ∀ i : Fin 13, (vs.filter Graph9822OneHidden.edges[i.val]!.testBit).map bit = ends[i.val]! := by decide +kernel
  have eq : Graph9822H1Check.h1Shores t=fastCovers t := by
    unfold Graph9822H1Check.h1Shores fastCovers
    congr 1
    apply List.map_congr_left
    intro i hi
    exact data ⟨i,List.mem_range.mp (List.mem_filter.mp hi).1⟩
  exact ⟨m,eq ▸ mem,le,cov⟩

theorem nested_fast_feasible {h q a b s : Nat} {use : Bool}
    (rows : NestedBits h q a b use) (ab : a<1024) (apart : meets a b=false)
    (live : holds q s) : fastFeasible h s=true := by
  have posLow (i : Nat) (hi : (positive s).testBit i=true) : i<13 := by
    by_contra! far
    have z := Nat.testBit_lt_two_pow (lt_of_lt_of_le (initialPosBound s)
      (show 8192≤2^i from Nat.pow_le_pow_right (by decide : 0<2) far))
    exact Bool.noConfusion (hi.symm.trans z)
  have cov : sub (positive s) (rawPos b)=true := by
    apply (subset_bits ..).2
    intro i hi
    have hot := true_on_demand live ⟨i,posLow i hi⟩ hi
    rw [rows.pos] at hot
    exact (Bool.and_eq_true_iff.mp hot).2
  obtain ⟨m,hm,sm,_⟩ := fast_cover_below cov
  let f := negative s &&& rawNeg m
  have bits {i : Nat} (fi : f.testBit i=true) :
      (rawNeg a).testBit i=false ∧ (use && (negative h).testBit i)=false := by
    obtain ⟨si,mi⟩ := Bool.and_eq_true_iff.mp (by simpa only [f,Nat.testBit_and] using fi)
    have mono := raw_trace_mono Research.Graph9822.FourSaturation.witnesses sm
    have bi := (subset_bits ..).1 mono i mi
    change (rawNeg b).testBit i=true at bi
    by_cases lt : i<16
    · have no := false_on_demand live ⟨i,lt⟩ si
      rw [rows.neg] at no
      simpa [bi] using no
    · change (Graph9822OneHidden.edgeMask _ Research.Graph9822.FourSaturation.witnesses).testBit i=true at mi
      have out : Research.Graph9822.FourSaturation.witnesses.length ≤ i := Nat.le_of_not_gt lt
      rw [test_edgeMask,List.getElem?_eq_none out] at mi
      contradiction
  have free := left_in_free ab ((empty_overlap ..).2 (fun _ sel => (bits sel).1))
  have incl : sub a (freeRaw f &&& (1023 ^^^ m))=true := by
    have low : sub a 1023=true := beq_iff_eq.mpr (Nat.and_two_pow_sub_one_of_lt_two_pow (n:=10) ab)
    apply (subset_bits ..).2
    intro i ai
    have notB := (empty_overlap ..).1 apart i ai
    have notM : m.testBit i=false := Bool.eq_false_iff.mpr (fun yes =>
      Bool.noConfusion (notB.symm.trans ((subset_bits ..).1 sm i yes)))
    simp [(subset_bits ..).1 free i ai,(subset_bits ..).1 low i ai,notM]
  apply List.any_eq_true.mpr
  refine ⟨m,hm,(subset_bits ..).2 ?_⟩
  intro i hi
  have hot := true_on_demand live ⟨i,posLow i hi⟩ hi
  rw [rows.pos] at hot
  have left : (rawPos a).testBit i=true ∨ (use && (positive h).testBit i)=true := by
    simpa only [Bool.or_eq_true] using (Bool.and_eq_true_iff.mp hot).1
  rcases left with ai | hu
  · have mono := raw_trace_mono Graph9822OneHidden.edges incl
    have hit := (subset_bits ..).1 mono i ai
    rw [Nat.testBit_or]
    rw [Bool.or_eq_true]
    left
    simpa only [rawPos,Graph9822OneHidden.accepts,f] using hit
  · obtain ⟨on,hh⟩ := Bool.and_eq_true_iff.mp hu
    have clear : meets (negative h) f=false := (empty_overlap ..).2 (by
      intro j hj
      apply Bool.eq_false_iff.mpr
      intro fj
      have no := (bits fj).2
      simp [on,hj] at no)
    change (_ ||| (if meets (negative h) f then 0 else positive h)).testBit i=true
    simp [clear,hh]
end Research.Graph9822H2Check
#print axioms Research.Graph9822H2Check.nested_fast_feasible
