import OR9822H2EligibleBlock10
import OR9822H2EligibleBlock11
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet05 : List (Nat × Nat × Nat) := [(116,554,1171),(116,556,1154),(116,771,7325),(116,773,7308),(139,201,16),(139,208,22),(139,276,103),(139,387,64),(139,402,70),(139,523,512)]
theorem certified05 {x : Nat × Nat × Nat} (mem : x∈rowSet05) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet05,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested050⟩
  · exact ⟨_,tested051⟩
  · exact ⟨_,tested052⟩
  · exact ⟨_,tested053⟩
  · exact ⟨_,tested054⟩
  · exact ⟨_,tested055⟩
  · exact ⟨_,tested056⟩
  · exact ⟨_,tested057⟩
  · exact ⟨_,tested058⟩
  · exact ⟨_,tested059⟩
end Research.Graph9822H2Eligibility
