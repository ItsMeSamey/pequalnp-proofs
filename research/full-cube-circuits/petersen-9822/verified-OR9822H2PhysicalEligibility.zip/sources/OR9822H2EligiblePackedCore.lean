import OR9822H2EligiblePackedData
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
open Research.Graph9822H1Check (extras)
open Research.Graph9822OneHidden (meets)

def domain (i j r : Nat) : List (Nat × Nat) := do
  let a ← extras (1023 ^^^ i)
  guard (sub r (positive (code a)))
  let allow := (1023 ^^^ a) &&& (if meets a j then 1023 ^^^ j else 1023)
  let b ← extras allow
  guard (sub r (positive (code b)))
  return (a,b)

def verdict (h tag : Nat) : Bool :=
  if tag=0 then negative h == 0
  else if tag≤10 then sub (positive h) (positive (code (bit (tag-1))))
  else match seedAt (tag-11) with
    | none => false
    | some k => sub (k ^^^ 8191) (h ^^^ 8191)

def audit : List (Nat × Nat) → List Nat → Bool
  | [],[] => true
  | (a,b)::xs,z::zs => verdict (code a &&& code b) z && audit xs zs
  | _,_ => false

theorem verdict_at {xs : List (Nat × Nat)} {zs : List Nat} (ok : audit xs zs=true)
    {a b : Nat} (mem : (a,b)∈xs) : ∃tag, verdict (code a &&& code b) tag=true := by
  induction xs generalizing zs with
  | nil => simp at mem
  | cons row xs ih =>
    rcases row with ⟨i,j⟩
    cases zs with
    | nil => simp [audit] at ok
    | cons z zs =>
      obtain ⟨head,tail⟩ := Bool.and_eq_true_iff.mp ok
      rcases List.mem_cons.mp mem with eq|rest
      · cases eq;exact ⟨z,head⟩
      · exact ih tail rest

theorem certified_key {h tag : Nat} (ok : verdict h tag=true) (leak : negative h≠0)
    (star : ∀ v : Fin 10, sub (positive h) (positive (code (bit v.val)))=false) :
    ∃ i k : Nat, keys[i]?=some k ∧ sub (k ^^^ 8191) (h ^^^ 8191)=true := by
  by_cases z : tag=0
  · simp [verdict,z,leak] at ok
  by_cases small : tag≤10
  · have v : tag-1<10 := by omega
    simp [verdict,z,small,star ⟨_,v⟩] at ok
  · cases rd : seedAt (tag-11) with
    | none => simp [verdict,z,small,rd] at ok
    | some k => exact ⟨_,k,(keys_read _).trans rd,by simpa [verdict,z,small,rd] using ok⟩

end Research.Graph9822H2Eligibility
