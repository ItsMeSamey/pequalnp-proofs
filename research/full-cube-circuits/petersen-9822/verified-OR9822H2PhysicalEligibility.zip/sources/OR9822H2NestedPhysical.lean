import OR9822H2NestedSaturation
import And9822CollectorShape
import OR9822ArmMask
import OR9822TwoSlotValue
namespace Research.Graph9822.FeatureRun
open Research.Graph9822.FreeOR Research.Graph9822Resolution
open Research.Graph9822H2Check Research.Graph9822OneHidden

private theorem single_read (p : Product) (xs : Arm) (i : Fin 29) :
    readColumn (Function.update rawBank 10 (firstCol p)) xs i =
      (meets (armMask xs) (rawRow i) || (xs.contains 10 && firstCol p i)) := by
  have actual := actual_input i
  rw [← read_arm_mask]
  apply Bool.eq_iff_iff.mpr
  simp only [readColumn,readArm,List.any_eq_true,Bool.or_eq_true,Bool.and_eq_true,List.contains_iff_mem]
  constructor
  · rintro ⟨j,mem,hot⟩
    by_cases ev : j=10
    · subst j; exact Or.inr ⟨mem,by simpa using hot⟩
    · exact Or.inl ⟨j,mem,by simpa [actual,Function.update_of_ne ev] using hot⟩
  · rintro (⟨j,mem,hot⟩|⟨mem,hot⟩)
    · have ex : j≠10 := by rintro rfl; simp [fullWire] at hot
      exact ⟨j,mem,by simpa [actual,Function.update_of_ne ex] using hot⟩
    · exact ⟨10,mem,by simpa using hot⟩

private theorem orient (p : Product) (l r : Arm) (order : Bool) (pure : 10∉r) :
    NestedBits (encode (firstCol p))
      (encode (secondCol p (if order then (r,l) else (l,r))))
      (armMask l) (armMask r) (l.contains 10) := by
  have eq (i : Fin 29) :
      secondCol p (if order then (r,l) else (l,r)) i =
      ((meets (armMask l) (rawRow i) || (l.contains 10 && firstCol p i)) &&
      meets (armMask r) (rawRow i)) := by
    cases order <;> simp [secondCol,productColumn,single_read,pure,Bool.and_comm]
  constructor
  · intro e
    rw [pos_col_bit,pos_col_bit,raw_pos_bit,raw_pos_bit,eq]
    simp [rawRow,e.isLt]
  · intro n
    rw [neg_col_bit,neg_col_bit,raw_neg_bit,raw_neg_bit,eq]
    have out : ¬13+n.val<13 := by omega
    simp [rawRow,out]

theorem physical_nested_bits (p q : Product) (apart : Apart q) :
    ∃ a b use, NestedBits (encode (firstCol p)) (encode (secondCol p q)) a b use ∧
      a<1024 ∧ meets a b=false := by
  rcases q with ⟨l,r⟩
  by_cases on : 10∈r
  · have off : 10∉l := fun mem => apart 10 mem on
    exact ⟨_,_,_,orient p r l true off,armMask_lt _,
      by simp [meets,disjoint_arm_masks r l (fun v vr vl => apart v vl vr)]⟩
  · exact ⟨_,_,_,orient p l r false on,armMask_lt _,
      by simp [meets,disjoint_arm_masks l r apart]⟩

theorem physical_fast_feasible (p q : Product) (apart : Apart q) {s : Nat}
    (live : holds (encode (secondCol p q)) s) :
    fastFeasible (encode (firstCol p)) s=true := by
  obtain ⟨_,_,_,rows,small,dis⟩ := physical_nested_bits p q apart
  exact nested_fast_feasible rows small dis live

end Research.Graph9822.FeatureRun
#print axioms Research.Graph9822.FeatureRun.physical_fast_feasible
