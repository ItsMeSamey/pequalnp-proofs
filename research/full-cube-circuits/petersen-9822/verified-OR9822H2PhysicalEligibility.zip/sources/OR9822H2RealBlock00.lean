import OR9822H2EligiblePackedCore
import OR9822H2RealPage00
namespace Research.Graph9822H2Eligibility

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real01 : ∀ i : Fin 64, let j:Nat:=64+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real02 : ∀ i : Fin 64, let j:Nat:=128+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real03 : ∀ i : Fin 64, let j:Nat:=192+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel
end Research.Graph9822H2Eligibility
