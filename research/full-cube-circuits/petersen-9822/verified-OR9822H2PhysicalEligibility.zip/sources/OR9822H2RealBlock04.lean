import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real16 : ∀ i : Fin 11, let j:Nat:=1024+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel
end Research.Graph9822H2Eligibility
