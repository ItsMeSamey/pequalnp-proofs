import OR9822H2EligibleBlock02
import OR9822H2EligibleBlock03
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet01 : List (Nat × Nat × Nat) := [(50,525,143),(50,554,130),(50,556,131),(50,771,4236),(50,773,4237),(77,108,8),(77,116,14),(77,139,49),(77,201,32),(77,208,38)]
theorem certified01 {x : Nat × Nat × Nat} (mem : x∈rowSet01) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet01,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested010⟩
  · exact ⟨_,tested011⟩
  · exact ⟨_,tested012⟩
  · exact ⟨_,tested013⟩
  · exact ⟨_,tested014⟩
  · exact ⟨_,tested015⟩
  · exact ⟨_,tested016⟩
  · exact ⟨_,tested017⟩
  · exact ⟨_,tested018⟩
  · exact ⟨_,tested019⟩
end Research.Graph9822H2Eligibility
