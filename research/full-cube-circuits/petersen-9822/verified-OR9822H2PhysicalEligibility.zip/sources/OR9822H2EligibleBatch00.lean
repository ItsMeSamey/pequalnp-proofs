import OR9822H2EligibleBlock00
import OR9822H2EligibleBlock01
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet00 : List (Nat × Nat × Nat) := [(50,77,31),(50,108,19),(50,116,17),(50,139,270),(50,201,286),(50,208,272),(50,276,4097),(50,387,4364),(50,402,4352),(50,523,142)]
theorem certified00 {x : Nat × Nat × Nat} (mem : x∈rowSet00) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet00,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested000⟩
  · exact ⟨_,tested001⟩
  · exact ⟨_,tested002⟩
  · exact ⟨_,tested003⟩
  · exact ⟨_,tested004⟩
  · exact ⟨_,tested005⟩
  · exact ⟨_,tested006⟩
  · exact ⟨_,tested007⟩
  · exact ⟨_,tested008⟩
  · exact ⟨_,tested009⟩
end Research.Graph9822H2Eligibility
