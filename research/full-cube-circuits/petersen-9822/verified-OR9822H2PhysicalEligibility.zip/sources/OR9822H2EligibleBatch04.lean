import OR9822H2EligibleBlock08
import OR9822H2EligibleBlock09
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def rowSet04 : List (Nat × Nat × Nat) := [(108,771,7257),(108,773,7240),(116,139,319),(116,201,302),(116,208,288),(116,276,6144),(116,387,6461),(116,402,6449),(116,523,1183),(116,525,1166)]
theorem certified04 {x : Nat × Nat × Nat} (mem : x∈rowSet04) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [rowSet04,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨_,tested040⟩
  · exact ⟨_,tested041⟩
  · exact ⟨_,tested042⟩
  · exact ⟨_,tested043⟩
  · exact ⟨_,tested044⟩
  · exact ⟨_,tested045⟩
  · exact ⟨_,tested046⟩
  · exact ⟨_,tested047⟩
  · exact ⟨_,tested048⟩
  · exact ⟨_,tested049⟩
end Research.Graph9822H2Eligibility
