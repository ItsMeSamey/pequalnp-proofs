import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility

def hints100 : List Nat := [840,959,842,960,841,843,846,962,847]
theorem tested100 : audit (domain 402 525 743) hints100 = true := by decide +kernel

def hints101 : List Nat := [663,741,663,741,665,743,665,743,697,697,698,698,680,755,683,757,705,707,673,749,673,749,703,703,689,761,709]
theorem tested101 : audit (domain 402 554 5058) hints101 = true := by decide +kernel

def hints102 : List Nat := [819,860,821,861,841,843,833,865,847]
theorem tested102 : audit (domain 402 556 5091) hints102 = true := by decide +kernel

def hints103 : List Nat := [40,40,40,40,155,155,155,155,41,41,41,41,156,156,156,156,45,45,159,159,47,47,160,160,40,40,157,157,42,42,158,158,45,159,47,160,43,43,43,43,44,44,44,44,46,46,48,48,43,43,44,44,46,48,40,40,40,40,155,155,155,155,45,45,159,159,40,40,157,157,45,159,43,43,43,43,46,46,43,43,46]
theorem tested103 : audit (domain 402 771 644) hints103 = true := by decide +kernel

def hints104 : List Nat := [346,346,420,420,348,348,421,421,346,420,348,421,347,347,349,349,347,349,351,351,423,423,351,423,352,352,352]
theorem tested104 : audit (domain 402 773 677) hints104 = true := by decide +kernel
end Research.Graph9822H2Eligibility
