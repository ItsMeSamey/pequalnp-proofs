import OR9822H2EligibleBatch00
import OR9822H2EligibleBatch01
import OR9822H2EligibleBatch02
import OR9822H2EligibleBatch03
import OR9822H2EligibleBatch04
import OR9822H2EligibleBatch05
import OR9822H2EligibleBatch06
import OR9822H2EligibleBatch07
import OR9822H2EligibleBatch08
import OR9822H2EligibleBatch09
import OR9822H2EligibleBatch10
import OR9822H2EligibleBatch11
namespace Research.Graph9822H2Eligibility
open Research.Graph9822H2Check
def regions : List (Nat × Nat × Nat) := (rowSet00 ++ (rowSet01 ++ (rowSet02 ++ (rowSet03 ++ (rowSet04 ++ (rowSet05 ++ (rowSet06 ++ (rowSet07 ++ (rowSet08 ++ (rowSet09 ++ (rowSet10 ++ rowSet11)))))))))))
theorem regions_audited {x : Nat × Nat × Nat} (mem : x∈regions) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by
  simp only [regions,List.mem_append] at mem
  rcases mem with h|h|h|h|h|h|h|h|h|h|h|h
  · exact certified00 h
  · exact certified01 h
  · exact certified02 h
  · exact certified03 h
  · exact certified04 h
  · exact certified05 h
  · exact certified06 h
  · exact certified07 h
  · exact certified08 h
  · exact certified09 h
  · exact certified10 h
  · exact certified11 h
def inside (a b : Nat) := Graph9822OneHidden.edgeMask (fun e => sub e (a ||| b)) Graph9822OneHidden.edges
def mis (i : Fin 16) := Research.Graph9822.FourSaturation.witnesses[i.val]!
theorem region_for : ∀ i j : Fin 16, i<j → (mis i,mis j,inside (mis i) (mis j))∈regions  := by
  have table : (List.finRange 16).all (fun i => (List.finRange 16).all fun j =>
    !(decide (i<j)) || regions.contains (mis i,mis j,inside (mis i) (mis j)))=true := by decide +kernel
  intro i j lt
  have row := List.all_eq_true.mp table i (List.mem_finRange i)
  have cell := List.all_eq_true.mp row j (List.mem_finRange j)
  exact List.contains_iff_mem.mp (by simpa [lt] using cell)
end Research.Graph9822H2Eligibility
