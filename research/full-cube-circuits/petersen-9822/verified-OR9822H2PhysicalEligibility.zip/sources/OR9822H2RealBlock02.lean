import OR9822H2EligiblePackedCore
namespace Research.Graph9822H2Eligibility

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real08 : ∀ i : Fin 64, let j:Nat:=512+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real09 : ∀ i : Fin 64, let j:Nat:=576+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real10 : ∀ i : Fin 64, let j:Nat:=640+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel

open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
theorem real11 : ∀ i : Fin 64, let j:Nat:=704+i.val; let p:=source j; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ seedCode j=code p.1 &&& code p.2 := by decide +kernel
end Research.Graph9822H2Eligibility
