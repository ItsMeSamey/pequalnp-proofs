from pathlib import Path
import json
d=Path('/workspace/scratch/official9822-lean')
def put(m,x): (d/(m+'.lean')).write_text(x)
for k in range(16):
 start=k*64
 s='import OR9822H2EligibleCore\nnamespace Research.Graph9822H2Eligibility\nopen Research.Graph9822H2Check\n'
 s+=f'theorem raw{k:02} : ∀ i : Fin 64, code ({start}+i.val)=demand (rawPos ({start}+i.val)) (rawNeg ({start}+i.val)) := by decide +kernel\n'
 s+='end Research.Graph9822H2Eligibility\n'
 put(f'OR9822H2RawPage{k:02}',s)
for k in range(17):
 start=k*64;l=min(64,1035-start)
 s='import OR9822H2EligibleCore\nnamespace Research.Graph9822H2Eligibility\nopen Research.Graph9822H2Check\nopen Research.Graph9822OneHidden (meets)\n'
 s+=f'theorem real{k:02} : ∀ i : Fin {l}, let j:Nat:={start}+i.val; let p:=sources[j]!; p.1<1024 ∧ p.2<1024 ∧ meets p.1 p.2=false ∧ keys[j]?=some (code p.1 &&& code p.2) := by decide +kernel\n'
 s+='end Research.Graph9822H2Eligibility\n'
 put(f'OR9822H2RealPage{k:02}',s)
