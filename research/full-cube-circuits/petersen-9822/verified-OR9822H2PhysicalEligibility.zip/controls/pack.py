from pathlib import Path
import json,sys
s=Path('/workspace/scratch'); d=s/'official9822-lean'
sys.path.insert(0,str(s/'official9822-or-equality'))
import replay_h2 as r
keys=[x[0] for x in json.loads(Path('/dev/shm/9822-static-fixed/h2-forest.json').read_text())]
shore={}
for a in range(1,1024):
 b=1023^a
 while b:
  shore.setdefault(r.trace[a]&r.trace[b],(a,b));b=(b-1)&(1023^a)
out='import OR9822H1Extras\nnamespace Research.Graph9822H2Eligibility\n'
def make(key,data,w):
 global out
 chunks=[sum(x << (j*w) for j,x in enumerate(data[k:k+32])) for k in range(0,len(data),32)]
 out+=f'def {key}Block : Nat → Nat\n'+''.join(f'  | {n} => {ch}\n' for n,ch in enumerate(chunks))+'  | _ => 0\n'
 out+=f'def {key} (i : Nat) := ({key}Block (i/32) >>> ({w}*(i%32))) &&& {2**w-1}\n'
make('code',r.trace,29);make('seedCode',keys,29);make('sourceCode',[a+(b<<10) for a,b in map(shore.__getitem__,keys)],20)
out+='''def seedAt (i : Nat) : Option Nat := if i<1035 then some (seedCode i) else none
def keys := Array.ofFn (fun i : Fin 1035 => seedCode i.val)
def source (i : Nat) := (sourceCode i &&& 1023, sourceCode i >>> 10)
theorem keys_read (i : Nat) : keys[i]?=seedAt i := by simp [keys,seedAt,Array.getElem?_ofFn]
end Research.Graph9822H2Eligibility
'''
(d/'OR9822H2EligiblePackedData.lean').write_text(out)
core=(d/'OR9822H2EligibleCore.lean').read_text().replace('import OR9822H2EligibleData','import OR9822H2EligiblePackedData').replace('def code (a : Nat) := rawCodes[a]?.getD 0\n','').replace('match keys[tag-11]? with','match seedAt (tag-11) with').replace('cases rd : keys[tag-11]? with','cases rd : seedAt (tag-11) with').replace('exact ⟨_,k,rd,by','exact ⟨_,k,(keys_read _).trans rd,by')
(d/'OR9822H2EligiblePackedCore.lean').write_text(core)
for p in [*d.glob('OR9822H2Eligible[0-9][0-9][0-9].lean'),d/'OR9822H2EligibleGeometry.lean',*d.glob('OR9822H2RawPage*.lean'),*d.glob('OR9822H2RealPage*.lean'),d/'OR9822H2AllReal.lean']:
 text=p.read_text().replace('import OR9822H2EligibleCore','import OR9822H2EligiblePackedCore').replace('sources[j]!','source j').replace('keys[j]?=some (code p.1 &&& code p.2)','seedCode j=code p.1 &&& code p.2')
 p.write_text(text)
