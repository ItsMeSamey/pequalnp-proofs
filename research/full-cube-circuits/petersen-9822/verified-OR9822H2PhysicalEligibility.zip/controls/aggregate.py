from pathlib import Path
import sys,itertools,json
here=Path('/workspace/scratch/official9822-h2-eligibility')
out=Path('/workspace/scratch/official9822-lean')
sys.path.insert(0,'/workspace/scratch/official9822-or-equality')
import replay_h2 as r
pairs=[(r.N[i],r.N[j],req) for (i,j,req,_) in json.loads((here/'pairs.json').read_text())]
def write(m,s): (out/(m+'.lean')).write_text(s)
def triple(x):return '('+','.join(map(str,x))+')'
ns='namespace Research.Graph9822H2Eligibility\nopen Research.Graph9822H2Check\n'
end='end Research.Graph9822H2Eligibility\n'
for p in range(12):
 k=p*10
 imports=''.join(f'import OR9822H2Eligible{i:03}\n' for i in range(k,k+10))
 data='['+','.join(triple(x) for x in pairs[k:k+10])+']'
 s=imports+ns+f'def rowSet{p:02} : List (Nat × Nat × Nat) := '+data+'\n'
 s+=f'theorem certified{p:02} {{x : Nat × Nat × Nat}} (mem : x∈rowSet{p:02}) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by\n'
 s+=f'  simp only [rowSet{p:02},List.mem_cons,List.not_mem_nil,or_false] at mem\n  rcases mem with '+' | '.join(['rfl']*10)+'\n'
 s+=''.join(f'  · exact ⟨_,tested{i:03}⟩\n' for i in range(k,k+10))
 write(f'OR9822H2EligibleBatch{p:02}',s+end)
s=''.join(f'import OR9822H2EligibleBatch{p:02}\n' for p in range(12))+ns
s+='def regions : List (Nat × Nat × Nat) := '+' ++ '.join(f'rowSet{p:02}' for p in range(12))+'\n'
s+='theorem regions_audited {x : Nat × Nat × Nat} (mem : x∈regions) : ∃ hints, audit (domain x.1 x.2.1 x.2.2) hints=true := by\n  simp only [regions,List.mem_append] at mem\n  rcases mem with '+'|'.join(['h']*12)+'\n'+''.join(f'  · exact certified{p:02} h\n' for p in range(12))
s+='''def inside (a b : Nat) := Graph9822OneHidden.edgeMask (fun e => sub e (a ||| b)) Graph9822OneHidden.edges
def mis (i : Fin 16) := Research.Graph9822.FourSaturation.witnesses[i.val]!
theorem region_for : ∀ i j : Fin 16, i<j → (mis i,mis j,inside (mis i) (mis j))∈regions := by decide +kernel
'''
write('OR9822H2AllRegions',s+end)
def group(name,n,prefix,size,body):
 s=''.join(f'import OR9822H2{prefix}Page{i:02}\n' for i in range(size))+ns
 s+=body+':= by\n'
 for k in range(size):
  lo=k*64;hi=min(lo+64,n)
  s+=f'  by_cases b{k} : j<{hi}\n  · have eq : {lo}+(j-{lo})=j := by omega\n    simpa only [eq] using ({name}{k:02} ⟨j-{lo},by omega⟩)\n'
 s+='  omega\n'
 write('OR9822H2All'+prefix,s+end)
group('raw',1024,'Raw',16,'theorem code_eq {j : Nat} (bound : j<1024) : code j=demand (rawPos j) (rawNeg j) ')
group('real',1035,'Real',17,'theorem seed_eq {j : Nat} (bound : j<1035) : let p:=sources[j]!; p.1<1024 ∧ p.2<1024 ∧ Graph9822OneHidden.meets p.1 p.2=false ∧ keys[j]?=some (code p.1 &&& code p.2) ')
