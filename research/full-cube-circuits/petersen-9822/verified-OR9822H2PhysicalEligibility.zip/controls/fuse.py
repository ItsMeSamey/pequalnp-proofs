from pathlib import Path
root=Path('/workspace/scratch/official9822-lean')
ns='namespace Research.Graph9822H2Eligibility'
end='end Research.Graph9822H2Eligibility'
def body(p):return p.read_text().split(ns,1)[1].rsplit(end,1)[0]
def fuse(name,numbers,page,keep):
 s='import OR9822H2EligiblePackedCore\n'
 s+=''.join('import '+page(i)+'\n' for i in numbers if i in keep)+ns+'\n'
 s+=''.join(body(root/(page(i)+'.lean')) for i in numbers if i not in keep)
 (root/(name+'.lean')).write_text(s+end+'\n')
for g in range(12):
 group=f'OR9822H2EligibleBatch{g:02}'
 p=root/(group+'.lean');old=p.read_text().split(ns,1)[1]
 s=''
 for t in range(2):
  name=f'OR9822H2EligibleBlock{g*2+t:02}';s+='import '+name+'\n'
  fuse(name,range(g*10+t*5,g*10+t*5+5),lambda i:f'OR9822H2Eligible{i:03}',{0,2})
 p.write_text(s+ns+old)
for n,kind in [(16,'Raw'),(17,'Real')]:
 s=''
 for g in range((n+3)//4):
  name=f'OR9822H2{kind}Block{g:02}';s+='import '+name+'\n'
  fuse(name,range(g*4,min(g*4+4,n)),lambda i: f'OR9822H2{kind}Page{i:02}',{0})
 p=root/('OR9822H2All'+kind+'.lean');p.write_text(s+ns+p.read_text().split(ns,1)[1])
