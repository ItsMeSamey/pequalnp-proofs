import collections
import itertools
import json
import sys
from pathlib import Path

scratch=Path('/workspace/scratch')
common=scratch/'official9822-lean'
sys.path.insert(0,str(scratch/'official9822-or-equality'))
import replay_h2 as r
forest=json.loads(Path('/dev/shm/9822-static-fixed/h2-forest.json').read_bytes())
seeds=[x[0] for x in forest]
assert len(set(seeds))==len(seeds)==1035
shore={}
for a in range(1,1024):
    b=1023^a
    while b:
        shore.setdefault(r.trace[a]&r.trace[b],(a,b))
        b=(b-1)&(1023^a)
def vec(xs): return '['+','.join(map(str,xs))+']'
def emit(name,s): (common/(name+'.lean')).write_text(s)
buf='import OR9822H1Extras\nnamespace Research.Graph9822H2Eligibility\nopen Research.Graph9822H2Check\n'
buf+='def keys : Array Nat := #'+vec(seeds)+'\n'
buf+='def sources : Array (Nat × Nat) := #['+','.join('('+str(shore[k][0])+','+str(shore[k][1])+')' for k in seeds)+']\n'
buf+='def rawCodes : Array Nat := #'+vec(r.trace)+'\n'
buf+='end Research.Graph9822H2Eligibility\n'
emit('OR9822H2EligibleData',buf)
def subs(k):return [v for v in range(1024) if not v&~k]
tag={}
for h in shore:
    he=h&8191;hn=h>>13
    if not hn:z=0
    elif (v:=next((v for v in range(10) if not he&~r.hits[1<<v]),None)) is not None:z=v+1
    else:
        z=next((11+i for i,k in enumerate(seeds) if (k^8191)&~(h^8191)==0),None)
    tag[h]=z
freq=collections.Counter(); names=[]; rows=[]
for k,((i,j),(req,_)) in enumerate(zip(itertools.combinations(range(16),2),r.pairs)):
    I,J=r.N[i],r.N[j]
    xs=[]
    for a in subs(1023^I):
        if req&~r.hits[a]:continue
        limit=(1023^a)&((1023^J) if a&J else 1023)
        for b in subs(limit):
            if req&~r.hits[b]:continue
            z=tag[r.trace[a]&r.trace[b]]
            assert z is not None
            xs.append(z);freq['rows']+=1
    rows.append((i,j,req,len(xs)))
    s='import OR9822H2EligibleCore\nnamespace Research.Graph9822H2Eligibility\n'
    s+=f'def hints{k:03} : List Nat := '+vec(xs)+'\n'
    s+=f'theorem tested{k:03} : audit (domain {I} {J} {req}) hints{k:03} = true := by decide +kernel\n'
    s+='end Research.Graph9822H2Eligibility\n'
    emit(f'OR9822H2Eligible{k:03}',s)
print(dict(freq),len(tag),len(rows))
Path(__file__).with_name('pairs.json').write_text(json.dumps(rows)+'\n')
