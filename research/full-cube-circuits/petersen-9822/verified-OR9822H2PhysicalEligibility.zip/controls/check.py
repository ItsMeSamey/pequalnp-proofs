"""Cross-check every direct unordered disjoint shore pair against the MIS-pair classifier."""
import collections
import hashlib
import json
from pathlib import Path
from itertools import combinations
from functools import reduce
from operator import or_

root=Path('/workspace/scratch')
edge=[6,24,17,33,66,132,264,528,160,640,576,320,288]
def sub(a,b):return a&b==a
def mask(x):return sum(1<<i for i,v in enumerate(x) if v)
neg=[s for s in range(1024) if not any(sub(e,s) for e in edge) and
    all(any(sub(e,s|1<<i) for e in edge) for i in range(10) if not s>>i&1)]
def trace(s):return mask(e&s for e in edge) | mask(n&s for n in neg)<<13
def hot_rows(u):return mask(sub(e,u) for e in edge)
def subsets(s):
 b=s
 while True:
  yield b
  if not b:break
  b=(b-1)&s
T=list(map(trace,range(1024)))
pack=Path('/dev/shm/9822-static-fixed/h2-forest.json');K=[k for k,_,_ in json.loads(pack.read_bytes())]
pairs=list(combinations(neg,2))
S=set()
for x,y in pairs:
 need=hot_rows(x|y)
 for a in subsets(1023^x):
  if not sub(need,T[a]):continue
  for b in subsets((1023^a)&(1023^y if a&y else 1023)):
   if sub(need,T[b]):S.add(tuple(sorted((a,b))))
seen=set();hs=set()
for a in range(1,1024):
 for b in subsets(1023^a):
  if b<=a:continue
  h=T[a]&T[b];valid=any(not(h>>(i+13)&1 or h>>(j+13)&1) and sub(hot_rows(x|y),h)
    for (i,x),(j,y) in combinations(enumerate(neg),2))
  if valid:seen.add((a,b))
  if valid and h>>13 and all(not sub(h&8191,T[1<<i]) for i in range(10)):hs.add(h)
assert seen==S and len(hs)==5464 and set(K)<=hs
assert all(any(sub(k^8191,h^8191) for k in K) for h in hs)
print(json.dumps({'forest_sha256':hashlib.sha256(pack.read_bytes()).hexdigest(),'distinct_raw_pairs_with_witness':len(S),'distinct_eligible_H':len(hs),'covered_by_real_forest_keys':len(K)},sort_keys=True))
