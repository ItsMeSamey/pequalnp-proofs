from source import selected,arch
from pathlib import Path
root=Path('/workspace/scratch/official9822-lean')
imports='\n'.join(f'import And9822One{p:03d}' if p!=67 else 'import And9822Five67Archive\nimport And9822Five67All' for p in selected)
def ns(p):return f'R{p}' if p!=67 else 'Representative67'
def rec(p):return ns(p)+('.records' if p!=67 else '.archived')
s=imports+'''
namespace Research.Graph9822.FiveChamber.OneStop.Family
open Catalogue Research.Graph9822ProfilesK5
structure Entry where
  id : Nat
  activation : List Nat
  records : List (Nat × Nat × Vertex)
def index : List Entry := [
'''+',\n'.join(f'  ⟨{p},{ns(p)}.activation,{rec(p)}⟩' for p in selected)+''']

def NoPhysical (u : List Nat) : Prop :=
  ∀ {b l p n}, (scan : Scan b l p n) → Tags u p →
    ∀ R : Vertex → Mask, (∀ v,R v∈l) →
    (∀ i : Fin 16, ∃ x : Word,∀ v,x∈R v ↔ wanted i v=true) → n≤8 → False
def Tapes (z : Entry) : Prop :=
  ∀ r ∈ z.records,
    verifyTape (meet wanted adjacent (atoms z.activation)) 256 []
      (initial (rays z.activation (atoms z.activation)) (library (rays z.activation (atoms z.activation))
          (mask (atoms z.activation)) r.1) r.2.1) [r.2.2.val]=some []
private theorem keep67 (r : Nat × Nat × Vertex) (hr : r∈Representative67.archived) :
    verifyTape (meet wanted adjacent (atoms Representative67.activation)) 256 []
      (initial (rays Representative67.activation (atoms Representative67.activation))
        (library (rays Representative67.activation (atoms Representative67.activation))
        (mask (atoms Representative67.activation)) r.1) r.2.1) [r.2.2.val]=some [] :=
  beq_iff_eq.mp (Representative67.all_archived r hr)
theorem complete (z : Entry) (hz : z∈index) : NoPhysical z.activation ∧ Tapes z := by
  simp only [index,List.mem_cons,List.not_mem_nil,or_false] at hz
  rcases hz with '''+' | '.join(['rfl']*len(selected))+'\n'+''.join(f'  · exact ⟨@{ns(p)}.excluded,{ns(p)}.tapes⟩\n' if p!=67 else '  · exact ⟨@Representative67.physical_all_roots,keep67⟩\n' for p in selected)+'''
theorem size : index.length=21 ∧ (index.map fun e => e.records.length).sum=1281 := by decide
def headers : List (Nat × Nat) := '''+'['+','.join(f'({d},{D})' for d,D,t in arch[67])+']\n'+'''theorem original_headers : ∀ z∈index, (z.records.map fun r => (r.1,r.2.1))=headers := by decide
end Research.Graph9822.FiveChamber.OneStop.Family
#print axioms Research.Graph9822.FiveChamber.OneStop.Family.complete
#print axioms Research.Graph9822.FiveChamber.OneStop.Family.original_headers
'''
s=s.replace('(scan : Scan b l p n) →','Scan b l p n →')
(root/'And9822Five21.lean').write_text(s)
