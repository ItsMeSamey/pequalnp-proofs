import And9822FiveOneCore
import And9822Five67Physical
namespace Research.Graph9822.FiveChamber.OneStop
open Catalogue
open Research.Graph9822ProfilesK5
abbrev NumWord := Representative67.NWord
abbrev word := Representative67.toWord

def Chart (u : List Nat) (a : Numbers) : Prop :=
  (∀ w : NumWord, canonical u w.val ∈ a.ws) ∧
  ∀ i : Axis, ∀ c : Bool, ∃ r ∈ a.rays, ∀ w : NumWord, r.testBit (canonical u w.val) =
    (raysAt u w.val i.val && (word w i == c))
instance (u : List Nat) (a : Numbers) : Decidable (Chart u a) := by unfold Chart; infer_instance

def Tags (u : List Nat) (p : List (Axis × Mask)) : Prop :=
  ∀ t∈p,∀ w : NumWord, word w ∈ t.2 ↔ raysAt u w.val t.1.val=true
def Represents (u : List Nat) (m : Mask) (k : Nat) : Prop :=
  ∀ w : NumWord, word w∈m ↔ k.testBit (canonical u w.val)=true

private theorem fold_or (ls : List Nat) (x : Nat) :
    ls.foldl Nat.lor x=x ||| ls.foldl Nat.lor 0 := by
  induction ls generalizing x with
  | nil => simp
  | cons r l ih =>
    change l.foldl Nat.lor (x ||| r) = x ||| l.foldl Nat.lor (0 ||| r)
    rw [ih (x ||| r),ih (0 ||| r)]; simp [Nat.or_assoc]

theorem store {u : List Nat} {a : Numbers} (chart : Chart u a) {b l p n}
    (scan : Scan b l p n) (tags : Tags u p) :
    (∀ m∈b, ∃ r ∈ a.rays, Represents u m r) ∧
    (∀ m∈l, m=Set.univ ∨ ∃ ls : List Nat, ls⊆a.rays ∧ Represents u m (ls.foldl Nat.lor 0)) := by
  induction scan with
  | start => simp
  | @join b l p n x y h hx hy ih =>
    obtain ⟨branch,all⟩ := ih tags
    refine ⟨branch,?_⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl|hm
    · rcases all x hx with xf|⟨xs,xin,xval⟩
      · left; simp [xf]
      rcases all y hy with yf|⟨ys,yin,yval⟩
      · left; simp [yf]
      right
      refine ⟨xs++ys,List.append_subset.mpr ⟨xin,yin⟩,?_⟩
      intro w
      rw [List.foldl_append,fold_or ys,Nat.testBit_or,Bool.or_eq_true]
      exact or_congr (xval w) (yval w)
    · exact all m hm
  | @split b l p n x i h hx ih =>
    have ht := tags (i,x) (by simp)
    obtain ⟨branch,all⟩ := ih (fun r hr => tags r (List.mem_cons_of_mem _ hr))
    have rep (c : Bool) : ∃ r∈a.rays, Represents u (x ∩ side i c) r := by
      obtain ⟨r,hr,hits⟩ := chart.2 i c
      refine ⟨r,hr,fun w => ?_⟩
      change (word w∈x ∧ word w i=c) ↔ _
      rw [hits]; simp [ht]
    have one {m : Mask} (v : ∃ r∈a.rays, Represents u m r) :
        ∃ ls : List Nat, ls⊆a.rays ∧ Represents u m (ls.foldl Nat.lor 0) := by
      obtain ⟨r,hr,hm⟩ := v
      exact ⟨[r],by simpa,by simpa using hm⟩
    refine ⟨?_,?_⟩
    · intro m hm
      rcases List.mem_cons.mp hm with rfl|hm
      · exact rep true
      rcases List.mem_cons.mp hm with rfl|hm
      · exact rep false
      exact branch m hm
    · intro m hm
      rcases List.mem_cons.mp hm with rfl|hm
      · exact Or.inr (one (rep true))
      rcases List.mem_cons.mp hm with rfl|hm
      · exact Or.inr (one (rep false))
      exact all m hm

end Research.Graph9822.FiveChamber.OneStop
#print axioms Research.Graph9822.FiveChamber.OneStop.store
