import And9822FiveOneSelection
namespace Research.Graph9822.FiveChamber.OneStop
open Catalogue
open Research.Graph9822ProfilesK5
private theorem join_sources {b l p n} (scan : Scan b l p n) :
    ∃ js : List Mask, js.length=n ∧ ∀ m∈l, m∈b ∨ m=Set.univ ∨ m∈js := by
  induction scan with
  | start => exact ⟨[],rfl,by simp⟩
  | @join _ _ _ _ x y _ _ _ ih =>
    obtain ⟨js,len,all⟩ := ih
    refine ⟨(x ∪ y)::js,by simp [len],?_⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl|hm
    · exact Or.inr (Or.inr (List.mem_cons_self ..))
    rcases all m hm with hb|full|hj
    · exact Or.inl hb
    · exact Or.inr (Or.inl full)
    · exact Or.inr (Or.inr (List.mem_cons_of_mem _ hj))
  | split _ _ ih =>
    obtain ⟨js,len,all⟩ := ih
    refine ⟨js,len,?_⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl | hm
    · exact Or.inl (List.mem_cons_self ..)
    rcases List.mem_cons.mp hm with rfl | hm
    · exact Or.inl (List.mem_cons_of_mem _ (List.mem_cons_self ..))
    rcases all m hm with hb|hr
    · exact Or.inl (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hb))
    · exact Or.inr hr

theorem bounded_single {b l p n} (scan : Scan b l p n)
    (R : Vertex → Mask) (returned : ∀ v,R v∈l)
    (realize : ∀ i : Fin 16, ∃ x : Word, ∀ v,x∈R v ↔ wanted i v=true)
    (only : Vertex) (unique : ∀ v,R v∈b → v=only) (budget : n≤8) : False := by
  classical
  obtain ⟨js,len,all⟩ := join_sources scan
  have miss : ∀ v : Vertex, ∃ i : Fin 16, wanted i v = false := by decide
  have diff : ∀ u v : Vertex,u≠v → ∃ i : Fin 16,wanted i u ≠ wanted i v := by decide
  have inj : Function.Injective R := by
    intro u v eq
    by_contra ne
    obtain ⟨i,h⟩ := diff u v ne
    obtain ⟨x,hx⟩ := realize i
    exact h (Bool.eq_iff_iff.mpr (by rw [←hx u,←hx v,eq]))
  have nonfull (v : Vertex) : R v≠Set.univ := by
    obtain ⟨i,hi⟩ := miss v
    obtain ⟨x,hx⟩ := realize i
    intro full
    have bad := (hx v).mp (full ▸ Set.mem_univ x)
    simp [hi] at bad
  let u := only
  have hu (v : Vertex) (ne : v≠u) : R v∉b := fun hb => ne (unique v hb)
  let others := (List.finRange 10).filter (fun v => v != u)
  have nd : (others.map R).Nodup := List.pairwise_map.mpr ((List.nodup_finRange 10).filter (fun v => v != u) |>.imp
    (fun h eq => h (inj eq)))
  have bound : (others.map R).length ≤ js.length := by
    apply (show (others.map R).Nodup from nd).length_le_of_subset
    intro m hm
    obtain ⟨v,hv,rfl⟩ := List.mem_map.mp hm
    have ne : v≠u := by simpa [others] using hv
    exact ((all _ (returned v)).resolve_left (hu v ne)).resolve_left (nonfull v)
  have nine : ∀ u : Vertex, ((List.finRange 10).filter (fun v => v != u)).length=9 := by decide
  simp [others,nine,len] at bound
  omega

inductive Rule where
 | unavailable (v : Vertex)
 | single (v : Vertex)

def CheckedRule (a : Numbers) : Rule → Prop
 | .unavailable v => (v,true)∈a.stops ∧ (v,false)∈a.stops
 | .single v => ∀ j : Vertex,j≠v → (j,true)∈a.stops

instance (a : Numbers) (r : Rule) : Decidable (CheckedRule a r) := by cases r <;> unfold CheckedRule <;> infer_instance

theorem physical {u : List Nat} {a : Numbers} (chart : Chart u a) (ok : OK a)
    (nonempty : 0<a.pool.size) (rule : Rule) (good : CheckedRule a rule)
    {b l p n} (scan : Scan b l p n) (tags : Tags u p)
    (R : Vertex → Mask) (returned : ∀ v,R v∈l)
    (realize : ∀ i : Fin 16, ∃ x : Word, ∀ v,x∈R v ↔ wanted i v=true) (budget : n≤8) : False := by
  obtain ⟨ix,feasible⟩ := actual_can chart ok nonempty scan tags R returned realize
  have allow (v : Vertex) : (v,a.rays.contains a.pool[(ix v).val]!)∉a.stops :=
    fun h => ok.2.2 (ix v) _ h rfl (feasible v).1
  cases rule with
  | unavailable v =>
    rcases good with ⟨yes,no⟩
    cases h : a.rays.contains a.pool[(ix v).val]! with
    | true => exact allow v (h ▸ yes)
    | false => exact allow v (h ▸ no)
  | single v =>
    apply bounded_single scan R returned realize v _ budget
    intro j h
    by_contra ne
    have membership : a.rays.contains a.pool[(ix j).val]! = true := List.contains_iff_mem.mpr ((feasible j).2 h)
    exact allow j (membership ▸ good j ne)

end Research.Graph9822.FiveChamber.OneStop
#print axioms Research.Graph9822.FiveChamber.OneStop.physical
