import And9822One046
import And9822One066
import And9822Five67Archive
import And9822Five67All
import And9822One088
import And9822One102
import And9822One109
import And9822One129
import And9822One199
import And9822One224
import And9822One250
import And9822One253
import And9822One254
import And9822One264
import And9822One290
import And9822One304
import And9822One308
import And9822One329
import And9822One331
import And9822One335
import And9822One376
import And9822One413
namespace Research.Graph9822.FiveChamber.OneStop.Family
open Catalogue Research.Graph9822ProfilesK5
structure Entry where
  id : Nat
  activation : List Nat
  records : List (Nat × Nat × Vertex)
def index : List Entry := [
  ⟨46,R46.activation,R46.records⟩,
  ⟨66,R66.activation,R66.records⟩,
  ⟨67,Representative67.activation,Representative67.archived⟩,
  ⟨88,R88.activation,R88.records⟩,
  ⟨102,R102.activation,R102.records⟩,
  ⟨109,R109.activation,R109.records⟩,
  ⟨129,R129.activation,R129.records⟩,
  ⟨199,R199.activation,R199.records⟩,
  ⟨224,R224.activation,R224.records⟩,
  ⟨250,R250.activation,R250.records⟩,
  ⟨253,R253.activation,R253.records⟩,
  ⟨254,R254.activation,R254.records⟩,
  ⟨264,R264.activation,R264.records⟩,
  ⟨290,R290.activation,R290.records⟩,
  ⟨304,R304.activation,R304.records⟩,
  ⟨308,R308.activation,R308.records⟩,
  ⟨329,R329.activation,R329.records⟩,
  ⟨331,R331.activation,R331.records⟩,
  ⟨335,R335.activation,R335.records⟩,
  ⟨376,R376.activation,R376.records⟩,
  ⟨413,R413.activation,R413.records⟩]

def NoPhysical (u : List Nat) : Prop :=
  ∀ {b l p n}, Scan b l p n → Tags u p →
    ∀ R : Vertex → Mask, (∀ v,R v∈l) →
    (∀ i : Fin 16, ∃ x : Word,∀ v,x∈R v ↔ wanted i v=true) → n≤8 → False
def Tapes (z : Entry) : Prop :=
  ∀ r ∈ z.records,
    verifyTape (meet wanted adjacent (atoms z.activation)) 256 []
      (initial (rays z.activation (atoms z.activation)) (library (rays z.activation (atoms z.activation))
          (mask (atoms z.activation)) r.1) r.2.1) [r.2.2.val]=some []
private theorem keep67 (r : Nat × Nat × Vertex) (hr : r∈Representative67.archived) :
    verifyTape (meet wanted adjacent (atoms Representative67.activation)) 256 []
      (initial (rays Representative67.activation (atoms Representative67.activation))
        (library (rays Representative67.activation (atoms Representative67.activation))
        (mask (atoms Representative67.activation)) r.1) r.2.1) [r.2.2.val]=some [] :=
  beq_iff_eq.mp (Representative67.all_archived r hr)
theorem complete (z : Entry) (hz : z∈index) : NoPhysical z.activation ∧ Tapes z := by
  simp only [index,List.mem_cons,List.not_mem_nil,or_false] at hz
  rcases hz with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact ⟨@R46.excluded,R46.tapes⟩
  · exact ⟨@R66.excluded,R66.tapes⟩
  · exact ⟨@Representative67.physical_all_roots,keep67⟩
  · exact ⟨@R88.excluded,R88.tapes⟩
  · exact ⟨@R102.excluded,R102.tapes⟩
  · exact ⟨@R109.excluded,R109.tapes⟩
  · exact ⟨@R129.excluded,R129.tapes⟩
  · exact ⟨@R199.excluded,R199.tapes⟩
  · exact ⟨@R224.excluded,R224.tapes⟩
  · exact ⟨@R250.excluded,R250.tapes⟩
  · exact ⟨@R253.excluded,R253.tapes⟩
  · exact ⟨@R254.excluded,R254.tapes⟩
  · exact ⟨@R264.excluded,R264.tapes⟩
  · exact ⟨@R290.excluded,R290.tapes⟩
  · exact ⟨@R304.excluded,R304.tapes⟩
  · exact ⟨@R308.excluded,R308.tapes⟩
  · exact ⟨@R329.excluded,R329.tapes⟩
  · exact ⟨@R331.excluded,R331.tapes⟩
  · exact ⟨@R335.excluded,R335.tapes⟩
  · exact ⟨@R376.excluded,R376.tapes⟩
  · exact ⟨@R413.excluded,R413.tapes⟩

theorem size : index.length=21 ∧ (index.map fun e => e.records.length).sum=1281 := by decide
def headers : List (Nat × Nat) := [(2,3),(2,5),(2,9),(2,10),(2,12),(2,18),(2,20),(2,34),(2,36),(2,40),(2,48),(2,65),(2,68),(2,72),(2,80),(2,96),(2,129),(2,130),(2,136),(2,144),(2,192),(2,257),(2,258),(2,260),(2,272),(2,384),(2,513),(2,514),(2,516),(2,520),(2,544),(2,768),(3,11),(3,13),(3,42),(3,44),(3,50),(3,69),(3,73),(3,76),(3,131),(3,137),(3,138),(3,193),(3,200),(3,259),(3,261),(3,276),(3,515),(3,517),(3,522),(3,524),(3,546),(3,552),(3,769),(3,772),(4,77),(4,139),(4,201),(4,554),(4,773)]
theorem original_headers : ∀ z∈index, (z.records.map fun r => (r.1,r.2.1))=headers := by decide
end Research.Graph9822.FiveChamber.OneStop.Family
#print axioms Research.Graph9822.FiveChamber.OneStop.Family.complete
#print axioms Research.Graph9822.FiveChamber.OneStop.Family.original_headers
