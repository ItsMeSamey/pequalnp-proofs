import And9822FiveOneCore
namespace Research.Graph9822.FiveChamber.OneStop

structure Packet where
  ws : List Nat
  rays : List Nat
  stops : List (Vertex × Bool)
  n : Nat
  words : Nat
  jumps : Nat

def field (pack width i : Nat) : Nat := (pack >>> (width*i)) % (2^width)
def Packet.word (p : Packet) (i : Nat) := field p.words 32 i
def Packet.jump (p : Packet) (q : Nat) := field p.jumps 8 q

def Packet.decode (p : Packet) : Numbers where
  ws := p.ws
  rays := p.rays
  stops := p.stops
  pool := Array.ofFn (fun i : Fin p.n => p.word i.val)
  transition := Array.ofFn (fun i : Fin (p.n*p.rays.length) => p.jump i.val)

private theorem read_word (p : Packet) (i : Nat) (hi : i<p.n) :
    p.decode.pool[i]! = p.word i := by
  simp [Packet.decode,hi]
private theorem read_jump (p : Packet) (q : Nat) (hq : q<p.n*p.rays.length) :
    p.decode.transition[q]! = p.jump q := by
  simp [Packet.decode,hq]

def jumpCheck (p : Packet) (i : Nat) : Bool :=
  (p.rays.zipIdx).all fun r =>
    let j := p.jump (i*p.rays.length+r.2)
    decide (j<p.n) && (p.word j == (p.word i ||| r.1))
def slotCheck (p : Packet) (i : Nat) : Bool :=
  p.stops.all fun s => (p.rays.contains (p.word i) != s.2) || decide (¬ Can p.ws s.1 (p.word i))

theorem verified (p : Packet) (ne : 0<p.n) (first : p.word 0=0)
    (jumps : ∀ i : Fin p.n, jumpCheck p i.val=true)
    (slots : ∀ i : Fin p.n, slotCheck p i.val=true) : OK p.decode := by
  have size : p.decode.pool.size=p.n := by simp [Packet.decode]
  refine ⟨(read_word p 0 ne).trans first,?_,?_⟩
  · intro i j
    have hi : i.val<p.n := size ▸ i.isLt
    have hj : j.val<p.rays.length := j.isLt
    have hq : i.val*p.rays.length+j.val<p.n*p.rays.length := by
      calc _ < (i.val+1)*p.rays.length := by simp [Nat.add_mul]; omega
           _ ≤ _ := Nat.mul_le_mul_right _ hi
    have mem : (p.rays[j.val]!,j.val) ∈ p.rays.zipIdx := by
      apply List.mk_mem_zipIdx_iff_getElem?.mpr; simp [hj]
    have h := List.all_eq_true.mp (jumps ⟨i.val,hi⟩) _ mem
    simp only [Bool.and_eq_true_iff,decide_eq_true_eq,beq_iff_eq] at h
    change p.decode.transition[i.val*p.rays.length+j.val]! < p.decode.pool.size ∧ _
    refine ⟨?_,?_⟩
    · calc p.decode.transition[i.val*p.rays.length+j.val]! = p.jump (i.val*p.rays.length+j.val) := read_jump _ _ hq
           _ < p.n := h.1
           _ = p.decode.pool.size := size.symm
    · change p.decode.pool[p.decode.transition[i.val*p.rays.length+j.val]!]! = p.decode.pool[i.val]! ||| p.rays[j.val]!
      rw [read_jump _ _ hq,read_word _ _ h.1,read_word _ _ hi]; exact h.2
  · intro i s hs equal
    have hi : i.val<p.n := size ▸ i.isLt
    have h := List.all_eq_true.mp (slots ⟨i.val,hi⟩) s hs
    rw [read_word _ _ hi] at equal ⊢
    change p.rays.contains (p.word i.val)=s.2 at equal
    rw [equal] at h
    change ¬Can p.ws s.1 (p.word i.val)
    simpa using h

end Research.Graph9822.FiveChamber.OneStop
#print axioms Research.Graph9822.FiveChamber.OneStop.verified
