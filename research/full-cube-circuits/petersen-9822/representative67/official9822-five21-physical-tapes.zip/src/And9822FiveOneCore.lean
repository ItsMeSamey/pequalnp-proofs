import FiveCatalogueCore
import Mathlib.Data.List.Basic
namespace Research.Graph9822.FiveChamber.OneStop
open Catalogue

def pos (v : Vertex) : Nat := ((List.finRange 16).filter (fun i => wanted i v)).length
def neg (v : Vertex) : Nat := ((List.finRange 16).filter (fun i => !(wanted i v))).length
def pc (ws : List Nat) (k : Nat) : Nat := (ws.filter (fun w => k.testBit w)).length
def Can (ws : List Nat) (v : Vertex) (k : Nat) : Prop :=
  pos v ≤ pc ws k ∧ neg v ≤ ws.length - pc ws k
instance (ws : List Nat) (v : Vertex) (k : Nat) : Decidable (Can ws v k) := by
  unfold Can; infer_instance

private theorem neg_count (ws : List Nat) (k : Nat) :
    (ws.filter fun w => !(k.testBit w)).length = ws.length - pc ws k := by
  have eq := List.length_eq_countP_add_countP (fun w => k.testBit w) (l:=ws)
  simp only [List.countP_eq_length_filter,Function.comp_def] at eq
  unfold pc
  induction ws with
  | nil => simp
  | cons a l ih =>
    cases ha : k.testBit a <;> simp [List.filter_cons,ha] at * <;> omega

theorem can_of_meet {ws : List Nat} {v : Vertex} {k : Nat}
    (h : meet wanted adjacent ws [] v v k k=true) : Can ws v k := by
  have cap := (Bool.and_eq_true_iff.mp h).2
  have any : ∀ (v : Vertex) (b : Bool), ∃ t : Fin 16, wanted t v=b := by decide
  obtain ⟨y,hy⟩ := any v true
  obtain ⟨n,hn⟩ := any v false
  have a := of_decide_eq_true (List.all_eq_true.mp cap y (List.mem_finRange y))
  have b := of_decide_eq_true (List.all_eq_true.mp cap n (List.mem_finRange n))
  refine ⟨?_,?_⟩
  · simpa [pos,pc,expected,signature,hy] using a
  · rw [←neg_count]; simpa [neg,expected,signature,hn] using b

theorem can_of_rows {ws : List Nat} (v : Vertex) (k : Nat) (f : Fin 16 → Nat)
    (inj : Function.Injective f) (mem : ∀ i,f i∈ws)
    (hits : ∀ i,k.testBit (f i)=wanted i v) : Can ws v k := by
  refine ⟨?_,?_⟩
  · apply PairFilter.filtered_capacity _ _ f _ _ (List.nodup_finRange _) (fun i j h => inj h)
    intro i _ hi; exact ⟨mem i,by simpa [hits] using hi⟩
  · rw [←neg_count]
    apply PairFilter.filtered_capacity _ _ f _ _ (List.nodup_finRange _) (fun i j h => inj h)
    intro i _ hi; exact ⟨mem i,by simpa [hits] using hi⟩

structure Numbers where
  ws : List Nat
  rays : List Nat
  pool : Array Nat
  transition : Array Nat
  stops : List (Vertex × Bool)

def OK (a : Numbers) : Prop :=
  a.pool[0]! = 0 ∧
  (∀ i : Fin a.pool.size, ∀ j : Fin a.rays.length,
   a.transition[i.val*a.rays.length+j.val]! < a.pool.size ∧
   a.pool[a.transition[i.val*a.rays.length+j.val]!]! = (a.pool[i.val]! ||| a.rays[j.val]!)) ∧
  (∀ i : Fin a.pool.size, ∀ s ∈ a.stops,
    (a.rays.contains a.pool[i.val]!)=s.2 → ¬Can a.ws s.1 a.pool[i.val]!)
instance (a : Numbers) : Decidable (OK a) := by unfold OK; infer_instance

theorem fold_in (a : Numbers) (ok : OK a) (nonempty : 0<a.pool.size)
    (ls : List Nat) (sub : ls ⊆ a.rays) : ∃ i : Fin a.pool.size, a.pool[i.val]! = ls.foldl Nat.lor 0 := by
  have aux (l : List Nat) (incl : l ⊆ a.rays) (i : Fin a.pool.size) :
      ∃ h : Fin a.pool.size,a.pool[h.val]! = l.foldl Nat.lor a.pool[i.val]! := by
    induction l generalizing i with
    | nil => exact ⟨i,rfl⟩
    | cons r l ih =>
      have hr := incl (List.mem_cons_self ..)
      let j : Fin a.rays.length := ⟨a.rays.idxOf r,List.idxOf_lt_length_iff.mpr hr⟩
      have read : a.rays[j.val]! = r := by
        change a.rays[a.rays.idxOf r]! = r
        simp [List.getElem!_eq_getElem?_getD,List.getElem?_idxOf hr]
      obtain ⟨lt,eq⟩ := ok.2.1 i j
      obtain ⟨z,hz⟩ := ih (fun _ h => incl (List.mem_cons_of_mem _ h)) ⟨_,lt⟩
      refine ⟨z,?_⟩
      change a.pool[z.val]! = l.foldl Nat.lor (a.pool[i.val]! ||| r)
      rw [←read,←eq]; exact hz
  simpa [ok.1] using aux ls sub ⟨0,nonempty⟩

theorem lib_in (a : Numbers) (ok : OK a) (nonempty : 0<a.pool.size)
    (d k : Nat) (hk : k ∈ library a.rays (mask a.ws) d) :
    ∃ i : Fin a.pool.size, a.pool[i.val]! = k := by
  simp only [library,List.mem_mergeSort,List.mem_eraseDups,List.mem_filter,List.mem_map] at hk
  obtain ⟨⟨t,_,rfl⟩,_⟩ := hk
  apply fold_in a ok nonempty
  intro r hr
  obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hr
  have hz := (List.mem_filter.mp hj).1
  exact (List.mem_zipIdx_iff_getElem?.mp hz) |> fun h => List.mem_of_getElem? h

theorem native_stop {a : Numbers} (ok : OK a) (nonempty : 0<a.pool.size)
    (d D : Nat) (v : Vertex) (h : (v,D.testBit v.val) ∈ a.stops) :
    verifyTape (meet wanted adjacent a.ws) 256 []
      (initial a.rays (library a.rays (mask a.ws) d) D) [v.val] = some [] := by
  let dom := initial a.rays (library a.rays (mask a.ws) d) D
  have empty : localDomain (meet wanted adjacent a.ws) [] dom v=[] := by
    rw [localDomain,materialize_eq]
    apply List.eq_nil_iff_forall_not_mem.mpr
    intro k hk
    obtain ⟨hd,pass⟩ := List.mem_filter.mp hk
    obtain ⟨hl,hdirect⟩ := List.mem_filter.mp hd
    obtain ⟨i,hi⟩ := lib_in a ok nonempty d k hl
    apply ok.2.2 i _ h
    · rw [hi]; exact beq_iff_eq.mp hdirect
    · rw [hi]; exact can_of_meet pass
  have id : atVertex v.val=v := Fin.ext (Nat.mod_eq_of_lt v.isLt)
  change verifyTape _ 256 [] dom [v.val]=some []
  simp [verifyTape,decode,v.isLt,id,empty]
end Research.Graph9822.FiveChamber.OneStop
#print axioms Research.Graph9822.FiveChamber.OneStop.native_stop
