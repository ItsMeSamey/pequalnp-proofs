import And9822FiveOnePhysical
namespace Research.Graph9822.FiveChamber.OneStop
open Catalogue
open Research.Graph9822ProfilesK5
private theorem onto (x : Word) : ∃ w : NumWord, word w=x := by
  let k := BitVec.ofBoolListLE (List.ofFn x)
  have bound : k.toNat<32 := by simpa [k] using k.isLt
  refine ⟨⟨k.toNat,bound⟩,?_⟩
  funext i
  change k.getLsbD i.val=x i
  unfold k
  rw [BitVec.getLsbD_ofBoolListLE,List.getD_eq_getElem?_getD,List.getElem?_ofFn,dif_pos i.isLt]
  rfl

theorem actual_can {u : List Nat} {a : Numbers} (chart : Chart u a) (ok : OK a)
    (nonempty : 0<a.pool.size) {b l p n} (scan : Scan b l p n) (tags : Tags u p)
    (R : Vertex → Mask) (returned : ∀ v,R v∈l)
    (realize : ∀ i : Fin 16, ∃ x : Word, ∀ v,x∈R v ↔ wanted i v=true) :
    ∃ ix : Vertex → Fin a.pool.size, ∀ v,
      Can a.ws v a.pool[(ix v).val]! ∧ (R v∈b → a.pool[(ix v).val]! ∈ a.rays) := by
  classical
  obtain ⟨branch,all⟩ := store chart scan tags
  have miss : ∀ v : Vertex, ∃ i : Fin 16,wanted i v=false := by decide
  have chosen (v : Vertex) : ∃ ix : Fin a.pool.size,Represents u (R v) a.pool[ix.val]! ∧
      (R v∈b → a.pool[ix.val]!∈a.rays) := by
    by_cases hb : R v∈b
    · obtain ⟨r,hr,h⟩ := branch _ hb
      obtain ⟨z,hz⟩ := fold_in a ok nonempty [r] (by simpa)
      have eq : a.pool[z.val]! = r := by simpa using hz
      exact ⟨z,eq ▸ h,fun _ => eq ▸ hr⟩
    rcases all _ (returned v) with hf|⟨ls,sub,h⟩
    · obtain ⟨i,hi⟩ := miss v
      obtain ⟨x,hx⟩ := realize i
      have bad := (hx v).mp (hf ▸ Set.mem_univ x)
      simp [hi] at bad
    · obtain ⟨z,hz⟩ := fold_in a ok nonempty ls sub
      exact ⟨z,hz ▸ h,fun h => False.elim (hb h)⟩
  choose ix val direct using chosen
  have row (i : Fin 16) : ∃ z ∈ a.ws, ∀ v,a.pool[(ix v).val]!.testBit z=wanted i v := by
    obtain ⟨x,hx⟩ := realize i
    obtain ⟨w,rfl⟩ := onto x
    exact ⟨canonical u w.val,chart.1 w,fun v => Bool.eq_iff_iff.mpr (((val v w).symm).trans (hx v))⟩
  choose f fm hit using row
  have distinguish : ∀ i j : Fin 16,i≠j → ∃ v : Vertex,wanted i v≠wanted j v := by decide
  have inj : Function.Injective f := by
    intro i j eq
    by_contra h
    obtain ⟨v,ne⟩ := distinguish i j h
    exact ne (by rw [←hit i v,←hit j v,eq])
  exact ⟨ix,fun v => ⟨can_of_rows v _ f inj fm (fun i => hit i v),direct v⟩⟩
end Research.Graph9822.FiveChamber.OneStop
#print axioms Research.Graph9822.FiveChamber.OneStop.actual_can
