from pathlib import Path
import json
from source import *
edges=[6,24,17,33,66,132,264,528,160,640,576,320,288]
independent=[m for m in range(1024) if all(m&e!=e for e in edges)]
actual_mis=[m for m in independent if all(m>>v&1 or m | 1<<v not in independent for v in range(10))]
assert actual_mis==mis
headers=[(d,D) for d in (2,3,4) for D in independent if D.bit_count()==d and all(
  sum(not(I&t) for I in mis)<=32>>t.bit_count() for t in range(1024) if t&D==t)]
assert len(headers)==61
def run():
 out=[]
 for p in selected:
  us=cat[p];ws,rs=geometry(us);full=sum(1<<w for w in ws)
  assert [(d,D) for d,D,s in arch[p]]==headers
  libs={d:sorted({(lambda x: __import__('functools').reduce(int.__or__,x,0))(s) for r in range(d+1) for s in combinations(rs,r)}-{0,full}) for d in (2,3,4)}
  U={0}
  for r in rs:U|={x|r for x in U}
  records=[]
  for d,D,s in arch[p]:
   v,=s
   need=sum(not(I>>v&1) for I in mis)
   direct=bool(D>>v&1)
   domain=[x for x in libs[d] if (x in rs)==direct]
   fits=lambda x: need<=x.bit_count() and 16-need<=(full^x).bit_count()
   assert not any(map(fits,domain))
   assert not any(fits(x) for x in U-{0,full} if (x in rs)==direct)
   records.append([d,D,v,len(domain)])
  pos=[sum(not(I>>v&1) for I in mis) for v in range(10)]
  candidates=lambda v,vals:[k for k in vals if pos[v]<=k.bit_count()<=len(ws)-16+pos[v]]
  dead=[v for v in range(10) if not candidates(v,U)]
  direct=[v for v in range(10) if candidates(v,rs)]
  assert dead or len(direct)<=1 or p==67
  out.append(dict(profile=p,activation=us,atoms=ws,rays=rs,roots=records,impossible_all_union_receiver=dead,possible_direct_receivers=direct))
 return out
out=run()
print(json.dumps(dict(framed_sha256=sha256(fr).hexdigest(),sorted_tape_sha256=sha256(b''.join(s for p in sorted(arch) for _,_,s in arch[p])).hexdigest(),profiles=out),separators=(',',':')))
