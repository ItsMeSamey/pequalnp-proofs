from pathlib import Path
from struct import unpack_from
from collections import defaultdict,Counter
from itertools import product,combinations
from hashlib import sha256
base=Path(__file__).resolve().parent
framed=base/'inputs/chambers-framed.bin'
if not framed.exists(): framed=Path('/dev/shm/five9822-chamber-proof.bin')
profiles=base/'inputs/canonfive.out'
if not profiles.exists(): profiles=Path('/workspace/scratch/official9822/calculus/canonfive.out')
fr=framed.read_bytes(); pos=0; arch=defaultdict(list)
while pos<len(fr):
 p,D,n,d=unpack_from('<HHHB',fr,pos); pos+=7
 arch[p].append((d,D,fr[pos:pos+n]));pos+=n
for rows in arch.values(): rows.sort()
cat=[list(map(int,x.split())) for x in profiles.read_text().splitlines()]
selected=sorted(p for p,rows in arch.items() if all(len(t)==1 and t[0]<10 for d,D,t in rows))
mis=[50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773]
def geometry(P):
 ws=[w for w in range(32) if sum(1<<j for j in range(5) if w>>j&1 and P[j]>>w&1)==w]
 rays=[sum(1<<w for w in ws if P[j//2]>>w&1 and w>>(j//2)&1==j%2) for j in range(10)]
 return ws,rays
if __name__=='__main__':
 print(selected)
 for p in selected:
  ws,rs=geometry(cat[p]); M=sum(1<<w for w in ws); sol=[]
  for u,v in combinations(range(10),2):
   if any(all(sum(int(bool(I>>u&1))==a and int(bool(I>>v&1))==b for I in mis) <= ((M&(M^x if a else x)&(M^y if b else y)).bit_count()) for a,b in product([0,1],repeat=2)) for x,y in product(rs,repeat=2)):sol.append((u,v))
  print(p,len(ws),len(sol),Counter((d, (D>>t[0])&1) for d,D,t in arch[p]))
