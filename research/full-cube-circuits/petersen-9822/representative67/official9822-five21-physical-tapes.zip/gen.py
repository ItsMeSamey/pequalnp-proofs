from source import *
from pathlib import Path
root=Path('/workspace/scratch/official9822-lean')
def ls(seq):
 return '['+','.join(map(str,seq))+']'
def pack(xs,n):return hex(sum(x<<(n*i) for i,x in enumerate(xs)))
def render(p):
 ns=f'R{p}'
 us=cat[p];ws,rs=geometry(us)
 U={0}
 for r in rs: U|={k|r for k in U}
 U=sorted(U); idx={k:i for i,k in enumerate(U)}
 records=arch[p];flags={(t[0],bool(D>>t[0]&1)) for d,D,t in records}
 pos=[sum(not(I>>v&1) for I in mis) for v in range(10)]
 def fits(v,k):return pos[v]<=k.bit_count()<=len(ws)-16+pos[v]
 impossible=[v for v in range(10) if not any(fits(v,k) for k in U)]
 directs=[v for v in range(10) if any(fits(v,k) for k in rs)]
 if impossible:
  dead=impossible[0];flags|={(dead,False),(dead,True)};rule=f'.unavailable {dead}'
 else:
  assert len(directs)<=1
  only=next(iter(directs),0);flags|={(v,True) for v in range(10) if v!=only};rule=f'.single {only}'
 flags=sorted(flags)
 f=root/f'And9822One{p:03d}.lean'
 f.write_text(f'''import And9822FiveOnePacket
import And9822FiveOneBound
namespace Research.Graph9822.FiveChamber.OneStop.{ns}
open Catalogue
set_option maxRecDepth 100000
set_option maxHeartbeats 3000000
def activation : List Nat := {ls(us)}
def packet : Packet where
  ws := {ls(ws)}
  rays := {ls(rs)}
  n := {len(U)}
  words := {pack(U,32)}
  jumps := {pack([idx[k|r] for k in U for r in rs],8)}
  stops := {ls([f'({v},{str(b).lower()})' for v,b in flags])}

def num := packet.decode
private theorem jumps : ∀ i : Fin packet.n, jumpCheck packet i.val=true := by decide +kernel
private theorem sizes : ∀ i : Fin packet.n, slotCheck packet i.val=true := by decide +kernel
theorem checked : OK num := verified packet (by decide) (by decide) jumps sizes
theorem poolNE : 0<num.pool.size := by simp [num,Packet.decode]; decide
theorem native_values : atoms activation=num.ws ∧ rays activation num.ws=num.rays := by decide +kernel

theorem chartOK : Chart activation num := by decide +kernel
def excluded := @physical activation num chartOK checked poolNE ({rule}) (by decide)
def records : List (Nat × Nat × Vertex) := {ls([f'({d},{D},{t[0]})' for d,D,t in records])}
private theorem headers : ∀ r∈records, (r.2.2,r.2.1.testBit r.2.2.val) ∈ num.stops := by decide
theorem tapes (r : Nat × Nat × Vertex) (hr : r∈records) :
    verifyTape (meet wanted adjacent (atoms activation)) 256 []
      (initial (rays activation (atoms activation))
        (library (rays activation (atoms activation)) (mask (atoms activation)) r.1) r.2.1)
      [r.2.2.val] = some [] := by
  rw [native_values.1,native_values.2]
  exact native_stop checked poolNE _ _ _ (headers r hr)
end Research.Graph9822.FiveChamber.OneStop.{ns}
#print axioms Research.Graph9822.FiveChamber.OneStop.{ns}.tapes
#print axioms Research.Graph9822.FiveChamber.OneStop.{ns}.excluded
''')
 return rule
if __name__=='__main__':
 for p in selected:
  if p!=67:print(p,render(p))
