from pathlib import Path
import json,hashlib
root=Path('/workspace/scratch/official9822-lean')
base=Path(__file__).resolve().parent
src=base/'canonfive.out'
if not src.exists():src=Path('/workspace/scratch/official9822/calculus/canonfive.out')
cat=[list(map(int,l.split())) for l in src.read_text().splitlines()]
assert len(cat)==617
def pack(xs,bits):return hex(sum(x<<(bits*i) for i,x in enumerate(xs)))
def ls(xs):return '['+','.join(map(str,xs))+']'
cols='\n'.join(f'def column{i} : Nat := {pack([u[i] for u in cat],32)}' for i in range(5))
s='''import And9822FiveThin
namespace Research.Graph9822.FiveChamber.Thin
'''+cols+'''
def catalogue (i : Nat) : List Nat :=
  [column0,column1,column2,column3,column4].map (fun c => (c >>> (32*i)) % 4294967296)
end Research.Graph9822.FiveChamber.Thin
'''
(root/'And9822FiveThinCatalog.lean').write_text(s)
rows=[]
for i,u in enumerate(cat):
 rep=[sum(1<<j for j in range(5) if (u[j]>>w)&(w>>j)&1) for w in range(32)]
 ws=[w for w in range(32) if rep[w]==w]
 assert all(x in ws for x in rep)
 for w in range(32):
  assert all((u[j]>>w&1)==(u[j]>>rep[w]&1) and (not (u[j]>>w&1) or (w>>j&1)==(rep[w]>>j&1)) for j in range(5))
 if len(ws)<16:rows.append((i,u,ws,rep))
assert len(rows)==221
(base/'lookup.json').write_text(json.dumps(dict(catalogue_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rows=[dict(ordinal=i,activation=u,points=ws,wordToPoint=rep)for i,u,ws,rep in rows]),separators=(',',':'))+'\n')
pages=[]
for j in range(0,len(rows),10):
 group=rows[j:j+10];pg=j//10;name=f'And9822ThinPage{pg:02}';pages.append(name)
 s='''import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin.Page'''+str(pg)+'''
set_option maxRecDepth 100000
set_option maxHeartbeats 3000000
def entries : List Row := ['''+',\n'.join(f'⟨{i},{ls(u)},{ls(ws)},{pack(rep,5)}⟩' for i,u,ws,rep in group)+''']
theorem checked : ∀ r∈entries, OK r ∧ catalogue r.id=r.u := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Page'''+str(pg)+f'\n#print axioms Research.Graph9822.FiveChamber.Thin.Page{pg}.checked\n'
 (root/(name+'.lean')).write_text(s)
names='['+','.join(f'Page{i}.entries' for i in range(len(pages)))+']'
s='\n'.join('import '+x for x in pages)+'''
namespace Research.Graph9822.FiveChamber.Thin.Family
open Research.Graph9822ProfilesK5 Catalogue OneStop
def allRows : List Row := '''+names+'''.flatten
private theorem checked (r : Row) (h : r ∈ allRows) : Thin.OK r ∧ catalogue r.id=r.u := by
  obtain ⟨xs,hm,hr⟩ := List.mem_flatten.mp h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
  rcases hm with '''+' | '.join('rfl' for _ in pages)+'\n'+''.join(f'  · exact Page{i}.checked _ hr\n' for i in range(len(pages)))+'''
theorem lookup (id : Nat) (mem : id ∈ allRows.map Row.id) :
    (∀ {b l p n}, Scan b l p n → Tags (catalogue id) p →
      ∀ R : Vertex → Mask, (∀ v,R v∈l) →
      (∀ i : Fin 16, ∃ x : Word,∀ v,x∈R v ↔ wanted i v=true) → False) ∧
      (∀ tape,runProfile (catalogue id) tape=some tape) := by
  obtain ⟨r,hr,rfl⟩ := List.mem_map.mp mem
  obtain ⟨ok,eq⟩ := checked _ hr
  rw [eq]
  exact ⟨@physical r ok,skip ok⟩
set_option maxRecDepth 100000 in
theorem count : allRows.length=221 ∧ (allRows.map Row.id).Nodup := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Family
#print axioms Research.Graph9822.FiveChamber.Thin.Family.lookup
'''
(root/'And9822Five221.lean').write_text(s)
