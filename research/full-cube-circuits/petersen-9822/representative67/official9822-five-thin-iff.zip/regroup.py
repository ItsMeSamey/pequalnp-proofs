from pathlib import Path
import json
root=Path('/workspace/scratch/official9822-lean')
th=[r['ordinal']for r in json.loads((Path(__file__).parent/'lookup.json').read_text())['rows']]
(root/'And9822ThinAppend.lean').write_text('''import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin
def CheckedEntries (l : List Row) : Prop := ∀ r∈l,OK r ∧ catalogue r.id = r.u
theorem checkedAppend {xs ys : List Row} (a : CheckedEntries xs) (b : CheckedEntries ys) :
    CheckedEntries (xs++ys) := by
  intro r hr
  exact (List.mem_append.mp hr).elim (a r) (b r)
end Research.Graph9822.FiveChamber.Thin
#print axioms Research.Graph9822.FiveChamber.Thin.checkedAppend
''')
def nested(items,op):
 if len(items)==1:return items[0]
 return op(items[0],nested(items[1:],op))
groups=[]
for start in range(0,23,4):
 ps=list(range(start,min(start+4,23)));g=start//4;groups.append(g)
 imports='\n'.join(f'import And9822ThinPage{i:02}'for i in ps)
 ns=f'Research.Graph9822.FiveChamber.Thin.G{g}'
 (root/f'And9822ThinGroup{g}.lean').write_text('import And9822ThinAppend\n'+imports+f'\nnamespace {ns}\ndef rows : List Row := '+nested([f'Page{i}.entries'for i in ps],lambda a,b:f'({a}++{b})')+'\ntheorem checked : CheckedEntries rows := '+nested([f'Page{i}.checked'for i in ps],lambda a,b:f'(checkedAppend {a} {b})')+f'\nend {ns}\n#print axioms {ns}.checked\n')
s='\n'.join(f'import And9822ThinGroup{i}'for i in groups)+'''
namespace Research.Graph9822.FiveChamber.Thin.Family
open Research.Graph9822ProfilesK5 Catalogue OneStop
def allRows : List Row := '''+nested([f'G{i}.rows'for i in groups],lambda a,b:f'({a}++{b})')+'\ntheorem checked : CheckedEntries allRows := '+nested([f'G{i}.checked'for i in groups],lambda a,b:f'(checkedAppend {a} {b})')+'''
theorem lookup (id : Nat) (mem : id ∈ allRows.map Row.id) :
    (∀ {b l p n}, Scan b l p n → Tags (catalogue id) p →
      ∀ R : Vertex → Mask, (∀ v,R v∈l) →
      (∀ i : Fin 16, ∃ x : Word,∀ v,x∈R v ↔ wanted i v=true) → False) ∧
      (∀ tape,runProfile (catalogue id) tape=some tape) := by
  obtain ⟨r,hr,rfl⟩ := List.mem_map.mp mem
  obtain ⟨ok,eq⟩ := checked _ hr
  rw [eq]
  exact ⟨@physical r ok,skip ok⟩
end Research.Graph9822.FiveChamber.Thin.Family
#print axioms Research.Graph9822.FiveChamber.Thin.Family.lookup
'''
(root/'And9822Five221.lean').write_text(s)
s='''import And9822Five221
import Mathlib.Data.List.Pairwise
namespace Research.Graph9822.FiveChamber.Thin.Family
def ids : List Nat := '''+str(th)+'''
theorem idList : allRows.map Row.id=ids := by decide +kernel
theorem count : allRows.length=221 ∧ (allRows.map Row.id).Nodup := by
  refine ⟨?_,?_⟩
  · have h := congrArg List.length idList
    simpa [ids] using h
  · rw [idList]
    have chain : ids.IsChain (·<·) := by decide
    exact (List.isChain_iff_pairwise.mp chain).imp (fun h => Nat.ne_of_lt h)
end Research.Graph9822.FiveChamber.Thin.Family
#print axioms Research.Graph9822.FiveChamber.Thin.Family.count
'''
(root/'And9822ThinCount.lean').write_text(s)
p=root/'And9822Five242.lean';s=p.read_text().replace('import And9822Five221','import And9822ThinCount');a=s.index('set_option maxRecDepth');b=s.index('end Research',a);s=s[:a]+'''theorem distinct : (directIDs++atomIDs).length=242 ∧ (directIDs++atomIDs).Nodup := by
  have eq : atomIDs = Thin.Family.ids := Thin.Family.idList
  have hd : directIDs.length=21 ∧ directIDs.Nodup := by decide
  have ha := Thin.Family.count
  have na : atomIDs.Nodup := ha.2
  have ca : atomIDs.length=221 := by simpa [atomIDs] using ha.1
  refine ⟨by simp [hd.1,ca],?_⟩
  apply List.nodup_append.mpr
  refine ⟨hd.2,na,?_⟩
  rw [eq]
  decide
'''+s[b:];p.write_text(s)
p=root/'And9822FiveThinIff.lean';s=p.read_text();a=s.index('    obtain ⟨ls,hm,hmem');b=s.index('  · intro h\n    rcases exhaust',a);s=s[:a]+'''    obtain ⟨ok,align⟩ := checked _ hr
    rw [←e, align]
    exact ok.2.1
'''+s[b:];p.write_text(s)
