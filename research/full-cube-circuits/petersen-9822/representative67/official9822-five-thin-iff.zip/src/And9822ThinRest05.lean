import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin.Rest5
open Catalogue
def ids : List Nat := [471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520]
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
theorem lower : ∀ i∈ids,16≤(atoms (catalogue i)).length := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Rest5
#print axioms Research.Graph9822.FiveChamber.Thin.Rest5.lower
