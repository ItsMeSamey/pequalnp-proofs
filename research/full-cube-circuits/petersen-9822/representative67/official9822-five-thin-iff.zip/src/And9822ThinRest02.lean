import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin.Rest2
open Catalogue
def ids : List Nat := [318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 364, 365, 366, 367, 368]
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
theorem lower : ∀ i∈ids,16≤(atoms (catalogue i)).length := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Rest2
#print axioms Research.Graph9822.FiveChamber.Thin.Rest2.lower
