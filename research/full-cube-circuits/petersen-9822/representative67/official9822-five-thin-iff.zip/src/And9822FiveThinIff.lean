import And9822ThinCount
import And9822ThinRest00
import And9822ThinRest01
import And9822ThinRest02
import And9822ThinRest03
import And9822ThinRest04
import And9822ThinRest05
import And9822ThinRest06
import And9822ThinRest07
namespace Research.Graph9822.FiveChamber.Thin.Family
open Catalogue
def complement : List Nat := [Rest0.ids,Rest1.ids,Rest2.ids,Rest3.ids,Rest4.ids,Rest5.ids,Rest6.ids,Rest7.ids].flatten
private theorem lower (i : Nat) (h:i∈complement) : 16≤(atoms (catalogue i)).length := by
  obtain ⟨ls,hm,hi⟩ := List.mem_flatten.mp h
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
  rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact Rest0.lower _ hi
  · exact Rest1.lower _ hi
  · exact Rest2.lower _ hi
  · exact Rest3.lower _ hi
  · exact Rest4.lower _ hi
  · exact Rest5.lower _ hi
  · exact Rest6.lower _ hi
  · exact Rest7.lower _ hi

private def weave : Nat → Nat → List Nat → List Nat → List Nat
  | 0,_,_,_ => []
  | n+1,bits,xs,ys =>
    if bits.testBit 0 then
      match xs with
      | [] => []
      | x::rest => x::weave n (bits>>>1) rest ys
    else
      match ys with
      | [] => []
      | y::rest => y::weave n (bits>>>1) xs rest

private theorem from_weave (n bits v : Nat) (xs ys : List Nat) (h : v ∈ weave n bits xs ys) :
    v∈xs ∨ v∈ys := by
  induction n generalizing bits xs ys with
  | zero => simp [weave] at h
  | succ n ih =>
    cases hb : bits.testBit 0 with
    | true =>
      cases xs with
      | nil => simp [weave,hb] at h
      | cons x rest =>
        simp only [weave,hb,ite_true,List.mem_cons] at h
        rcases h with eq|mem
        · exact Or.inl (List.mem_cons.mpr (Or.inl eq))
        · exact (ih _ _ _ mem).imp (List.mem_cons_of_mem _) id
    | false =>
      cases ys with
      | nil => simp [weave,hb] at h
      | cons y rest =>
        simp only [weave,hb,Bool.false_eq_true,ite_false,List.mem_cons] at h
        rcases h with eq|mem
        · exact Or.inr (List.mem_cons.mpr (Or.inl eq))
        · exact (ih _ _ _ mem).imp id (List.mem_cons_of_mem _)

private def bits : Nat := 0x110000000000008000000000000889000400a2ef882fffff8022b177fffffdffffffffffdfffe020116ffff11ffffbfffffffffff
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
private theorem coverage : weave 617 bits ids complement=List.range 617 := by decide +kernel
private theorem exhaust (i : Fin 617) : i.val ∈ allRows.map Row.id ∨ i.val∈complement := by
  rw [idList]
  apply from_weave 617 bits
  rw [coverage]; exact List.mem_range.mpr i.isLt

theorem iff_short (i : Fin 617) :
    i.val ∈ allRows.map Row.id ↔ (atoms (catalogue i.val)).length<16 := by
  constructor
  · intro h
    obtain ⟨r,hr,e⟩ := List.mem_map.mp h
    obtain ⟨ok,align⟩ := checked _ hr
    rw [←e, align]
    exact ok.2.1
  · intro h
    rcases exhaust i with yes|hc
    · exact yes
    · exact False.elim ((Nat.not_lt.mpr (lower _ hc)) h)
end Research.Graph9822.FiveChamber.Thin.Family
#print axioms Research.Graph9822.FiveChamber.Thin.Family.iff_short
