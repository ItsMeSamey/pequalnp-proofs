import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin.Rest0
open Catalogue
def ids : List Nat := [46, 65, 66, 67, 69, 70, 71, 88, 91, 93, 94, 95, 97, 98, 99, 100, 101, 102, 103, 104, 106, 107, 108, 109, 110, 111, 112, 129, 173, 199, 203, 205, 206, 207, 210, 212, 214, 215, 216, 218, 219, 220, 221, 222, 223, 224, 225, 226, 248, 250]
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
theorem lower : ∀ i∈ids,16≤(atoms (catalogue i)).length := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Rest0
#print axioms Research.Graph9822.FiveChamber.Thin.Rest0.lower
