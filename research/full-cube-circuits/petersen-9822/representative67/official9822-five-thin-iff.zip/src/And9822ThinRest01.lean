import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin.Rest1
open Catalogue
def ids : List Nat := [251, 252, 253, 254, 256, 257, 258, 264, 268, 270, 271, 272, 274, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 301, 302, 304, 305, 306, 308, 309, 310, 312, 313, 314, 315, 316, 317]
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
theorem lower : ∀ i∈ids,16≤(atoms (catalogue i)).length := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Rest1
#print axioms Research.Graph9822.FiveChamber.Thin.Rest1.lower
