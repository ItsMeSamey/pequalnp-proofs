import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin.Rest6
open Catalogue
def ids : List Nat := [521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570]
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
theorem lower : ∀ i∈ids,16≤(atoms (catalogue i)).length := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Rest6
#print axioms Research.Graph9822.FiveChamber.Thin.Rest6.lower
