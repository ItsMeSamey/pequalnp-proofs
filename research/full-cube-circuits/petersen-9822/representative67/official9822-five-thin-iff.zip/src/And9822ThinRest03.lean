import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin.Rest3
open Catalogue
def ids : List Nat := [369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 413, 414, 415, 417, 418, 419, 420]
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
theorem lower : ∀ i∈ids,16≤(atoms (catalogue i)).length := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Rest3
#print axioms Research.Graph9822.FiveChamber.Thin.Rest3.lower
