from pathlib import Path
import hashlib,json
base=Path(__file__).resolve().parent
p=base/'canonfive.out'
if not p.exists():p=Path('/workspace/scratch/official9822/calculus/canonfive.out')
cat=[list(map(int,s.split())) for s in p.read_text().splitlines()]
freeze=json.loads((base/'lookup.json').read_text())
assert len(cat)==617 and hashlib.sha256(p.read_bytes()).hexdigest()==freeze['catalogue_sha256']
expected=[]
for i,u in enumerate(cat):
 projected=[sum((1<<j) for j in range(5) if u[j]>>w&1 and w>>j&1) for w in range(32)]
 atoms=[w for w in range(32) if projected[w]==w]
 if len(atoms)>=16:continue
 for w,r in enumerate(projected):
  assert r in atoms
  for j,activation in enumerate(u):
   for b in (0,1):
    assert ((activation>>w&1) and w>>j&1==b)==((activation>>r&1) and r>>j&1==b)
 expected.append(dict(ordinal=i,activation=u,points=atoms,wordToPoint=projected))
assert expected==freeze['rows'] and len(expected)==221
immediate={46,66,67,88,102,109,129,199,224,250,253,254,264,290,304,308,329,331,335,376,413}
assert not immediate.intersection(r['ordinal'] for r in expected)
print('221 short; 396 nonshort; 242 covered by the two disjoint families; 375 other profiles.')
