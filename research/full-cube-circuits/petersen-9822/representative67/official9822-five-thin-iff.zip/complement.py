from pathlib import Path
import json
data=json.loads((Path(__file__).parent/'lookup.json').read_text())
thin={r['ordinal'] for r in data['rows']}
rest=sorted(set(range(617))-thin)
root=Path('/workspace/scratch/official9822-lean')
pgs=[]
for i in range(0,len(rest),50):
 n=i//50; name=f'And9822ThinRest{n:02}';pgs.append(name)
 s=f'''import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin.Rest{n}
open Catalogue
def ids : List Nat := {rest[i:i+50]}
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
theorem lower : ∀ i∈ids,16≤(atoms (catalogue i)).length := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Rest{n}
#print axioms Research.Graph9822.FiveChamber.Thin.Rest{n}.lower
'''
 (root/(name+'.lean')).write_text(s)
head='\n'.join('import '+name for name in ['And9822Five221']+pgs)
s=head+'\nnamespace Research.Graph9822.FiveChamber.Thin.Family\nopen Catalogue\ndef complement : List Nat := ['+','.join('Rest'+str(i)+'.ids' for i in range(len(pgs)))+'].flatten\nprivate theorem lower (i : Nat) (h:i∈complement) : 16≤(atoms (catalogue i)).length := by\n  obtain ⟨ls,hm,hi⟩ := List.mem_flatten.mp h\n  simp only [List.mem_cons,List.not_mem_nil,or_false] at hm\n  rcases hm with '+' | '.join('rfl' for _ in pgs)+'\n'+''.join(f'  · exact Rest{i}.lower _ hi\n' for i in range(len(pgs)))+'''
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
private theorem exhaust : ∀ i : Fin 617, i.val ∈ allRows.map Row.id ∨ i.val∈complement := by decide +kernel

theorem iff_short (i : Fin 617) :
    i.val ∈ allRows.map Row.id ↔ (atoms (catalogue i.val)).length<16 := by
  constructor
  · intro h
    obtain ⟨r,hr,e⟩ := List.mem_map.mp h
    obtain ⟨ls,hm,hmem⟩ := List.mem_flatten.mp hr
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hm
    rw [←e]
    rcases hm with '''+' | '.join(['rfl']*23)+'\n'+''.join(f'    · obtain ⟨ok,he⟩ := Page{i}.checked r hmem; rw [he]; exact ok.2.1\n' for i in range(23))+'''  · intro h
    rcases exhaust i with yes|hc
    · exact yes
    · exact False.elim ((Nat.not_lt.mpr (lower _ hc)) h)
end Research.Graph9822.FiveChamber.Thin.Family
#print axioms Research.Graph9822.FiveChamber.Thin.Family.iff_short
'''
(root/'And9822FiveThinIff.lean').write_text(s)
