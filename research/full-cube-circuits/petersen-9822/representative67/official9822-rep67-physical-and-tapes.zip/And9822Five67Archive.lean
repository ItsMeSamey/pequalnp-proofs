import And9822Five67Nine
namespace Research.Graph9822.FiveChamber.Representative67
open Catalogue
def archived : List (Nat × Nat × Vertex) := [(2,3,1),
  (2,5,2),
  (2,9,9),
  (2,10,1),
  (2,12,2),
  (2,18,1),
  (2,20,2),
  (2,34,1),
  (2,36,2),
  (2,40,5),
  (2,48,4),
  (2,65,6),
  (2,68,2),
  (2,72,6),
  (2,80,4),
  (2,96,5),
  (2,129,7),
  (2,130,1),
  (2,136,7),
  (2,144,4),
  (2,192,6),
  (2,257,8),
  (2,258,1),
  (2,260,2),
  (2,272,4),
  (2,384,7),
  (2,513,9),
  (2,514,1),
  (2,516,2),
  (2,520,9),
  (2,544,5),
  (2,768,8),
  (3,11,1),
  (3,13,2),
  (3,42,1),
  (3,44,2),
  (3,50,1),
  (3,69,2),
  (3,73,6),
  (3,76,2),
  (3,131,1),
  (3,137,7),
  (3,138,1),
  (3,193,6),
  (3,200,6),
  (3,259,1),
  (3,261,2),
  (3,276,2),
  (3,515,1),
  (3,517,2),
  (3,522,1),
  (3,524,2),
  (3,546,1),
  (3,552,5),
  (3,769,8),
  (3,772,2),
  (4,77,2),
  (4,139,1),
  (4,201,6),
  (4,554,1),
  (4,773,2)]

theorem degrees : ((archived.filter (fun z => z.1==2)).map (fun z => z.2.1))=ids2 ∧
    ((archived.filter (fun z => z.1==3)).map (fun z => z.2.1))=ids3 ∧
    ((archived.filter (fun z => z.1==4)).map (fun z => z.2.1))=ids4 := by decide

private theorem headers : ∀ z ∈ archived,
    (z.1=2 ∧ z.2.1=9 ∧ z.2.2=9) ∨
    (z.2.1.testBit z.2.2.val=true ∧ z.2.2≠0 ∧ z.2.2≠3) := by decide

theorem all_archived (z : Nat × Nat × Vertex) (hz : z ∈ archived) :
    rootCheck z.1 z.2.1 [z.2.2.val]=true := by
  rcases headers z hz with ⟨d,D,v⟩|⟨h,ne⟩
  · simpa [d,D,v] using nine_stop
  · exact direct_stop _ _ _ h ne

end Research.Graph9822.FiveChamber.Representative67
#print axioms Research.Graph9822.FiveChamber.Representative67.all_archived
