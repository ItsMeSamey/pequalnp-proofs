"""Recompute direct-mask eligibility independently and bind the original 61 records."""
from pathlib import Path
import re
import json
import hashlib
from itertools import combinations

root = Path(__file__).resolve().parent / 'original-records'
if not root.is_dir():
    root = Path('/workspace/scratch/official9822/algebra/five/catalogue-split')
edges = [6, 24, 17, 33, 66, 132, 264, 528, 160, 640, 576, 320, 288]
independent = [m for m in range(1024) if all(m & e != e for e in edges)]
mis = [m for m in independent if all(m >> v & 1 or m | 1 << v not in independent for v in range(10))]
assert mis == [50,77,108,116,139,201,208,276,387,402,523,525,554,556,771,773]
def eligible(D):
    return all(sum(not (x & t) for x in mis) <= 32 >> t.bit_count()
               for t in range(1024) if t & D == t)
expected = [(d,D) for d in (2,3,4) for D in independent if D.bit_count()==d and eligible(D)]
records = []
for i in range(61):
    path = root / f'FiveRoot{i}.lean'
    data = path.read_bytes()
    m = re.search(rb'rootCheck (\d+) (\d+) \[(\d+)\] = true',data)
    assert m
    d,D,u = map(int,m.groups())
    records.append(dict(d=d,D=D,stop=u,source=path.name,sha256=hashlib.sha256(data).hexdigest()))
assert expected == [(r['d'],r['D']) for r in records]
assert [sum(r['d']==d for r in records) for d in [2,3,4]] == [32,24,5]
assert [(r['D'],r['stop']) for r in records if not (r['D'] >> r['stop'] & 1)] == [(9,9)]
activation = [2**32 - 1] + [0x55555555] * 4
def canonical(word):
    return sum(1 << j for j, act in enumerate(activation) if (act >> word) & (word >> j) & 1)
atoms = [w for w in range(32) if canonical(w) == w]
full = sum(1 << w for w in atoms)
rays = [sum(1 << w for w in atoms if (activation[r//2] >> w & 1) and (w >> (r//2) & 1) == r%2)
        for r in range(10)]
def library(d):
    masks = set()
    for r in range(d + 1):
        for group in combinations(rays,r):
            value = 0
            for x in group:
                value |= x
            if value not in (0,full):
                masks.add(value)
    return sorted(masks)
libraries = {d: library(d) for d in (2,3,4)}
for record in records:
    v,d,D = record['stop'],record['d'],record['D']
    local = [k for k in libraries[d] if (k in rays) == bool(D >> v & 1)]
    need = sum(not (label >> v & 1) for label in mis)
    surviving = [k for k in local if k.bit_count() >= need and (full ^ k).bit_count() >= 16-need]
    assert not surviving
    record.update(domain=len(local),present=need,absent=16-need,surviving=0)
print(json.dumps(dict(originalMIS=mis,degreeCounts=[32,24,5],records=records),indent=2))
