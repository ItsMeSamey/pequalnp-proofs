import And9822Five67ActualRoot
namespace Research.Graph9822.FiveChamber.Representative67
open Catalogue
open Research.Graph9822ProfilesK5

private theorem axis_index : ∀ (i : Axis) (c : Bool), ∃ j : Fin 10,
    j.val / 2=i.val ∧ j.val.testBit 0=c := by decide

private theorem branch_label {b l p n} (scan : Scan b l p n) (tags : Tags p) :
    ∀ m ∈ b, ∃ j : Fin 10, ∀ w : NWord, toWord w ∈ m ↔
      raysAt activation w.val (j.val/2) = true ∧ w.val.testBit (j.val/2) = j.val.testBit 0 := by
  induction scan with
  | start => simp
  | join _ _ _ ih => exact ih tags
  | @split b l p n u i h hu ih =>
    have ht := tags (i,u) (by simp)
    have ray (c : Bool) : ∃ j : Fin 10, ∀ w : NWord, toWord w ∈ u ∩ side i c ↔
        raysAt activation w.val (j.val/2) = true ∧ w.val.testBit (j.val/2) = j.val.testBit 0 := by
      obtain ⟨j,hj,hc⟩ := axis_index i c
      refine ⟨j,fun w => ?_⟩
      change (toWord w ∈ u ∧ w.val.testBit i.val = c) ↔ _
      rw [hj,hc]; exact and_congr_left (fun _ => ht w)
    intro m hm
    rcases List.mem_cons.mp hm with rfl|hm
    · exact ray true
    rcases List.mem_cons.mp hm with rfl|hm
    · exact ray false
    exact ih (fun a ha => tags a (List.mem_cons_of_mem _ ha)) m hm

def labelsWhere (u v : Vertex) (a b : Bool) :=
  ((List.finRange 16).filter (fun t => (wanted t u == a) && (wanted t v == b))).length

def atomsWhere (j k : Fin 10) (a b : Bool) :=
  (ws.filter (fun w => ((rindex j).testBit w == a) && ((rindex k).testBit w == b))).length

def fitsPair (u v : Vertex) (j k : Fin 10) : Prop :=
  ∀ a b : Bool, labelsWhere u v a b ≤ atomsWhere j k a b

instance (u v : Vertex) (j k : Fin 10) : Decidable (fitsPair u v j k) := by
  unfold fitsPair; infer_instance

theorem unary_only (v : Vertex) (j : Fin 10) (ok : fitsPair v v j j) :
    v=0 ∨ v=3 := by
  have all : ∀ v : Vertex, ∀ j : Fin 10, fitsPair v v j j → v=0 ∨ v=3 := by decide +kernel
  exact all v j ok

theorem pair03_impossible (j k : Fin 10) : ¬fitsPair 0 3 j k := by
  have all : ∀ j k : Fin 10, ¬fitsPair 0 3 j k := by decide +kernel
  exact all j k

theorem labels_fit {b l p n} (scan : Scan b l p n) (tags : Tags p)
    (R : Vertex → Mask) (returned : ∀ v,R v ∈ l)
    (realize : ∀ i : Fin 16, ∃ x : Word, ∀ v, x∈R v ↔ wanted i v=true)
    (u v : Vertex) (hu : R u∈b) (hv : R v∈b) :
    ∃ j k : Fin 10, fitsPair u u j j ∧ fitsPair v v k k ∧ fitsPair u v j k := by
  classical
  obtain ⟨f,mem,hit⟩ := physical_selection scan tags R returned realize
  have compat (s : Vertex) (hs : R s ∈ b) : ∃ j : Fin 10, ∀ t : Fin 16,
      (rindex j).testBit (f t).val=wanted t s := by
    obtain ⟨j,hj⟩ := branch_label scan tags _ hs
    refine ⟨j,fun t => ?_⟩
    have canonid : canonical activation (f t).val = (f t).val :=
      beq_iff_eq.mp (List.mem_filter.mp (mem t)).2
    apply Bool.eq_iff_iff.mpr
    rw [←canonid,single_bit]
    simpa using (hj (f t)).symm.trans (hit t s)
  obtain ⟨j,hj⟩ := compat u hu
  obtain ⟨k,hk⟩ := compat v hv
  have lift (u v : Vertex) (j k : Fin 10)
      (h1 : ∀ t : Fin 16,(rindex j).testBit (f t).val=wanted t u)
      (h2 : ∀ t : Fin 16,(rindex k).testBit (f t).val=wanted t v) : fitsPair u v j k := by
    intro a b
    apply PairFilter.filtered_capacity _ _ (fun t : Fin 16 => (f t).val) _ _
      (List.nodup_finRange _) (fun i j eq => f.injective (Fin.ext eq))
    intro t _ ht
    exact ⟨mem t,by simpa [h1,h2] using ht⟩
  exact ⟨j,k,lift u u j j hj hj,lift v v k k hk hk,lift u v j k hj hk⟩
end Research.Graph9822.FiveChamber.Representative67
#print axioms Research.Graph9822.FiveChamber.Representative67.labels_fit
