import FiveRepresentativeData
namespace Research.Graph9822.FiveChamber.Representative67
set_option maxHeartbeats 0 in
set_option maxRecDepth 100000 in
theorem root0 : rootCheck 2 3 [1] = true := by decide +kernel
end Research.Graph9822.FiveChamber.Representative67
