import FiveRepresentativeData
namespace Research.Graph9822.FiveChamber.Representative67
set_option maxHeartbeats 0 in
set_option maxRecDepth 100000 in
theorem root19 : rootCheck 2 144 [4] = true := by decide +kernel
end Research.Graph9822.FiveChamber.Representative67
