import And9822Five67Pairs
namespace Research.Graph9822.FiveChamber.Representative67
open Catalogue
open Research.Graph9822ProfilesK5

private theorem join_sources {b l p n} (scan : Scan b l p n) :
    ∃ js : List Mask, js.length=n ∧ ∀ m∈l, m∈b ∨ m=Set.univ ∨ m∈js := by
  induction scan with
  | start => exact ⟨[],rfl,by simp⟩
  | @join _ _ _ _ x y _ _ _ ih =>
    obtain ⟨js,len,all⟩ := ih
    refine ⟨(x ∪ y)::js,by simp [len],?_⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl|hm
    · exact Or.inr (Or.inr (List.mem_cons_self ..))
    rcases all m hm with hb|full|hj
    · exact Or.inl hb
    · exact Or.inr (Or.inl full)
    · exact Or.inr (Or.inr (List.mem_cons_of_mem _ hj))
  | split _ _ ih =>
    obtain ⟨js,len,all⟩ := ih
    refine ⟨js,len,?_⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl | hm
    · exact Or.inl (List.mem_cons_self ..)
    rcases List.mem_cons.mp hm with rfl | hm
    · exact Or.inl (List.mem_cons_of_mem _ (List.mem_cons_self ..))
    rcases all m hm with hb|hr
    · exact Or.inl (List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hb))
    · exact Or.inr hr

theorem no_two_direct {b l p n} (scan : Scan b l p n) (tags : Tags p)
    (R : Vertex → Mask) (returned : ∀ v,R v∈l)
    (realize : ∀ i : Fin 16, ∃ x : Word, ∀ v,x∈R v ↔ wanted i v=true)
    {u v : Vertex} (hu : R u∈b) (hv : R v∈b) : u=v := by
  by_contra ne
  obtain ⟨j,k,hj,hk,_⟩ := labels_fit scan tags R returned realize u v hu hv
  obtain u0|u3 := unary_only _ _ hj <;> obtain v0|v3 := unary_only _ _ hk
  · exact ne (u0.trans v0.symm)
  · obtain ⟨a,b,_,_,pair⟩ := labels_fit scan tags R returned realize 0 3 (u0 ▸ hu) (v3 ▸ hv)
    exact pair03_impossible a b pair
  · obtain ⟨a,b,_,_,pair⟩ := labels_fit scan tags R returned realize 0 3 (v0 ▸ hv) (u3 ▸ hu)
    exact pair03_impossible a b pair
  · exact ne (u3.trans v3.symm)

theorem physical_all_roots {b l p n} (scan : Scan b l p n) (tags : Tags p)
    (R : Vertex → Mask) (returned : ∀ v,R v∈l)
    (realize : ∀ i : Fin 16, ∃ x : Word, ∀ v,x∈R v ↔ wanted i v=true)
    (budget : n≤8) : False := by
  classical
  obtain ⟨js,len,all⟩ := join_sources scan
  have miss : ∀ v : Vertex, ∃ i : Fin 16, wanted i v = false := by decide
  have diff : ∀ u v : Vertex,u≠v → ∃ i : Fin 16,wanted i u ≠ wanted i v := by decide
  have inj : Function.Injective R := by
    intro u v eq
    by_contra ne
    obtain ⟨i,h⟩ := diff u v ne
    obtain ⟨x,hx⟩ := realize i
    exact h (Bool.eq_iff_iff.mpr (by rw [←hx u,←hx v,eq]))
  have nonfull (v : Vertex) : R v≠Set.univ := by
    obtain ⟨i,hi⟩ := miss v
    obtain ⟨x,hx⟩ := realize i
    intro full
    have bad := (hx v).mp (full ▸ Set.mem_univ x)
    simp [hi] at bad
  have one : ∃ u : Vertex, ∀ v : Vertex, v≠u → R v ∉ b := by
    by_cases h : ∃ u : Vertex, R u∈b
    · obtain ⟨u,hu⟩ := h
      exact ⟨u,fun v ne hv => ne (no_two_direct scan tags R returned realize hv hu)⟩
    · exact ⟨0,fun v _ hv => h ⟨v,hv⟩⟩
  obtain ⟨u,hu⟩ := one
  let others := (List.finRange 10).filter (fun v => v != u)
  have nd : (others.map R).Nodup := List.pairwise_map.mpr ((List.nodup_finRange 10).filter (fun v => v != u) |>.imp
    (fun h eq => h (inj eq)))
  have bound : (others.map R).length ≤ js.length := by
    apply (show (others.map R).Nodup from nd).length_le_of_subset
    intro m hm
    obtain ⟨v,hv,rfl⟩ := List.mem_map.mp hm
    have ne : v≠u := by simpa [others] using hv
    exact ((all _ (returned v)).resolve_left (hu v ne)).resolve_left (nonfull v)
  have nine : ∀ u : Vertex, ((List.finRange 10).filter (fun v => v != u)).length=9 := by decide
  simp [others,nine,len] at bound
  omega

end Research.Graph9822.FiveChamber.Representative67
#print axioms Research.Graph9822.FiveChamber.Representative67.physical_all_roots
