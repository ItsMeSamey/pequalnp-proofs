import And9822Five67Pairs
namespace Research.Graph9822.FiveChamber.Representative67
open Catalogue

theorem stop_at (dom : Domain) (v : Vertex)
    (fail : ∀ k ∈ dom v, meet wanted adjacent ws [] v v k k=false) :
    verifyTape (meet wanted adjacent ws) 256 [] dom [v.val] = some [] := by
  have empty : localDomain (meet wanted adjacent ws) [] dom v = [] := by
    rw [localDomain,materialize_eq]
    apply List.eq_nil_iff_forall_not_mem.mpr
    intro k hk
    obtain ⟨hin,pass⟩ := List.mem_filter.mp hk
    simp [fail k hin] at pass
  have id : atVertex v.val=v := Fin.ext (Nat.mod_eq_of_lt v.isLt)
  simp [verifyTape,decode,v.isLt,id,empty]

private theorem sameUnary (v : Vertex) (j : Fin 10)
    (pass : meet wanted adjacent ws [] v v (rindex j) (rindex j) = true) : fitsPair v v j j := by
  have cap := (Bool.and_eq_true_iff.mp pass).2
  intro a b
  by_cases ab : a=b
  · subst b
    have any : ∀ (v : Vertex) (a : Bool), ∃ t : Fin 16, wanted t v=a := by decide
    obtain ⟨t,ht⟩ := any v a
    have bound := of_decide_eq_true (List.all_eq_true.mp cap t (List.mem_finRange t))
    simpa [labelsWhere,atomsWhere,signature,expected,ht] using bound
  · have f (x : Bool) : ((x==a) && (x==b))=false := by
      cases x <;> cases a <;> cases b <;> simp_all
    simp [labelsWhere,atomsWhere,f]

theorem direct_stop (v : Vertex) (d D : Nat) (bit : D.testBit v.val=true)
    (hv : v≠0 ∧ v≠3) : rootCheck d D [v.val]=true := by
  apply beq_iff_eq.mpr
  apply stop_at
  intro k hk
  obtain ⟨_,h⟩ := List.mem_filter.mp hk
  have mem : k∈primitive := by simpa [bit] using h
  have listing : primitive=(List.finRange 10).map rindex := by decide
  rw [listing] at mem
  obtain ⟨j,_,rfl⟩ := List.mem_map.mp mem
  cases he : meet wanted adjacent ws [] v v (rindex j) (rindex j) with
  | false => rfl
  | true => exact False.elim ((unary_only v j (sameUnary v j he)).elim hv.1 hv.2)

end Research.Graph9822.FiveChamber.Representative67
#print axioms Research.Graph9822.FiveChamber.Representative67.direct_stop
