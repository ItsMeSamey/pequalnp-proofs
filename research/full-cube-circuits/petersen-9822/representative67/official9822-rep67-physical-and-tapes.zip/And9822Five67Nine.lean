import And9822Five67Opcodes
namespace Research.Graph9822.FiveChamber.Representative67
open Catalogue
private def pool : List Nat := [0, 2, 21845, 21847, 5570645, 5570647, 5592405, 84215045, 84215047, 84235605, 89458005, 286331153, 286331155, 286348629, 290787669, 353703189, 1145324612, 1145324614, 1145328981, 1146438741, 1162167621, 1347440720, 1347440722, 1347442005, 1347768405, 1364283729, 1414812756, 1426085120, 1426085122, 1426085205, 1426412805, 1427199249, 1430541636, 1431328080, 1431633920, 1431633922, 1431634005, 1431635205, 1431638289, 1431651396, 1431654480, 1431655680, 1431655765, 1431655767]
private theorem poolVerified :
  ((List.range 1024).filter (fun k => decide (count 10 k ≤ 2))).all (fun k => pool.contains (packed k))=true := by
  decide +kernel

private theorem libraryIn (k : Nat) (hk : k∈library primitive (mask ws) 2) : k∈pool := by
  simp only [library,List.mem_mergeSort,List.mem_eraseDups,List.mem_filter,List.mem_map] at hk
  obtain ⟨⟨t,ht,rfl⟩,_⟩ := hk
  exact List.contains_iff_mem.mp (List.all_eq_true.mp poolVerified t (List.mem_filter.mpr ht))

private theorem failedPool : pool.all (fun k => !(meet wanted adjacent ws [] 9 9 k k)) = true := by
  decide +kernel

theorem nine_stop : rootCheck 2 9 [9]=true := by
  apply beq_iff_eq.mpr
  apply stop_at _ 9
  intro k hk
  have failed := List.all_eq_true.mp failedPool k (libraryIn k (List.mem_filter.mp hk).1)
  simpa using failed

end Research.Graph9822.FiveChamber.Representative67
#print axioms Research.Graph9822.FiveChamber.Representative67.nine_stop
