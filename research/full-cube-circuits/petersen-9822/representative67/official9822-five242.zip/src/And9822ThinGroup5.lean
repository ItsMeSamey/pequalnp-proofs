import And9822ThinAppend
import And9822ThinPage20
import And9822ThinPage21
import And9822ThinPage22
namespace Research.Graph9822.FiveChamber.Thin.G5
def rows : List Row := (Page20.entries++(Page21.entries++Page22.entries))
theorem checked : CheckedEntries rows := (checkedAppend Page20.checked (checkedAppend Page21.checked Page22.checked))
end Research.Graph9822.FiveChamber.Thin.G5
#print axioms Research.Graph9822.FiveChamber.Thin.G5.checked
