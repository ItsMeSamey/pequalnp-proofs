import And9822FiveOnePhysical
namespace Research.Graph9822.FiveChamber.Thin
open Catalogue OneStop
open Research.Graph9822ProfilesK5

structure Row where
  id : Nat
  u : List Nat
  points : List NumWord
  look : Nat

def Row.point (r : Row) (w : NumWord) : NumWord :=
  ⟨(r.look >>> (5*w.val)) % 32, Nat.mod_lt _ (by decide)⟩
def sideBit (u : List Nat) (w : NumWord) (i : Axis) (b : Bool) : Bool :=
  raysAt u w.val i.val && (word w i==b)
def OK (r : Row) : Prop :=
  r.points.length<16 ∧ (atoms r.u).length<16 ∧ ∀ w : NumWord,
    r.point w ∈ r.points ∧ ∀ i : Axis, ∀ b : Bool, sideBit r.u (r.point w) i b = sideBit r.u w i b
instance (r : Row) : Decidable (OK r) := by unfold OK; infer_instance

private theorem store {r : Row} (ok : OK r) {b l p n} (scan : Scan b l p n) (tags : Tags r.u p) :
    ∀ m∈l,∀ w : NumWord,word (r.point w) ∈ m ↔ word w ∈ m := by
  induction scan with
  | start => simp
  | join _ hx hy ih =>
    intro m hm
    rcases List.mem_cons.mp hm with rfl|hm
    · exact fun w => or_congr (ih tags _ hx w) (ih tags _ hy w)
    · exact ih tags _ hm
  | @split b l p n x i h hx ih =>
    have ht := tags (i,x) (by simp)
    have hside (c : Bool) (w : NumWord) : word (r.point w) ∈ x ∩ side i c ↔ word w∈x ∩ side i c := by
      change (word (r.point w) ∈ x ∧ word (r.point w) i=c) ↔ (word w∈x ∧ word w i=c)
      have hh := congrArg (· = true) ((ok.2.2 w).2 i c)
      simpa [sideBit,←ht] using Iff.of_eq hh
    intro m hm
    rcases List.mem_cons.mp hm with rfl|hm
    · exact hside true
    rcases List.mem_cons.mp hm with rfl|hm
    · exact hside false
    exact ih (fun a ha => tags a (List.mem_cons_of_mem _ ha)) _ hm

private theorem onto (x : Word) : ∃ w : NumWord, word w=x := by
  let k := BitVec.ofBoolListLE (List.ofFn x)
  have bound : k.toNat<32 := by simpa [k] using k.isLt
  refine ⟨⟨k.toNat,bound⟩,?_⟩
  funext i
  change k.getLsbD i.val=x i
  unfold k
  rw [BitVec.getLsbD_ofBoolListLE,List.getD_eq_getElem?_getD,List.getElem?_ofFn,dif_pos i.isLt]
  rfl

theorem physical {r : Row} (ok : OK r) {b l p n} (scan : Scan b l p n) (tags : Tags r.u p)
    (R : Vertex → Mask) (ret : ∀ v,R v∈l)
    (realize : ∀ i : Fin 16, ∃ x : Word, ∀ v,x∈R v ↔ wanted i v=true) : False := by
  classical
  have rows (i : Fin 16) : ∃ w∈r.points,∀ v,word w ∈ R v ↔ wanted i v=true := by
    obtain ⟨x,hx⟩ := realize i
    obtain ⟨w,rfl⟩ := onto x
    exact ⟨r.point w,(ok.2.2 w).1,fun v => (store ok scan tags _ (ret v) w).trans (hx v)⟩
  choose f mem hit using rows
  have distinguish : ∀ i j : Fin 16,i≠j → ∃ v : Vertex,wanted i v≠wanted j v := by decide
  have inj : Function.Injective f := by
    intro i j eq
    by_contra ne
    obtain ⟨v,hh⟩ := distinguish i j ne
    exact hh (Bool.eq_iff_iff.mpr (by rw [←hit i v,←hit j v,eq]))
  have nd : ((List.finRange 16).map f).Nodup :=
    List.pairwise_map.mpr ((List.nodup_finRange 16).imp (fun h e => h (inj e)))
  have ub := nd.length_le_of_subset (l₂:=r.points) (by
    intro x hx; obtain ⟨i,_,rfl⟩ := List.mem_map.mp hx; exact mem i)
  have lt := ok.1
  simp at ub
  omega

theorem skip {r : Row} (ok : OK r) (tape : Tape) : runProfile r.u tape=some tape := by
  simp [runProfile,ok.2.1]

end Research.Graph9822.FiveChamber.Thin
#print axioms Research.Graph9822.FiveChamber.Thin.physical
