import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin
def CheckedEntries (l : List Row) : Prop := ∀ r∈l,OK r ∧ catalogue r.id = r.u
theorem checkedAppend {xs ys : List Row} (a : CheckedEntries xs) (b : CheckedEntries ys) :
    CheckedEntries (xs++ys) := by
  intro r hr
  exact (List.mem_append.mp hr).elim (a r) (b r)
end Research.Graph9822.FiveChamber.Thin
#print axioms Research.Graph9822.FiveChamber.Thin.checkedAppend
