import And9822FiveThinCatalog
namespace Research.Graph9822.FiveChamber.Thin.Page22
set_option maxRecDepth 100000
set_option maxHeartbeats 3000000
def entries : List Row := [⟨416,[4294967295,4294967295,2004318071,117901063,1886417008],[0,1,2,3,4,5,6,8,9,10,20,21,22],0x1dab41a9281dab418820198a41a928198a418820⟩]
theorem checked : ∀ r∈entries, OK r ∧ catalogue r.id=r.u := by decide +kernel
end Research.Graph9822.FiveChamber.Thin.Page22
#print axioms Research.Graph9822.FiveChamber.Thin.Page22.checked
