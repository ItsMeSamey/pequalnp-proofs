import And9822ThinAppend
import And9822ThinPage08
import And9822ThinPage09
import And9822ThinPage10
import And9822ThinPage11
namespace Research.Graph9822.FiveChamber.Thin.G2
def rows : List Row := (Page8.entries++(Page9.entries++(Page10.entries++Page11.entries)))
theorem checked : CheckedEntries rows := (checkedAppend Page8.checked (checkedAppend Page9.checked (checkedAppend Page10.checked Page11.checked)))
end Research.Graph9822.FiveChamber.Thin.G2
#print axioms Research.Graph9822.FiveChamber.Thin.G2.checked
