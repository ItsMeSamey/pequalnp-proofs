import And9822ThinAppend
import And9822ThinPage12
import And9822ThinPage13
import And9822ThinPage14
import And9822ThinPage15
namespace Research.Graph9822.FiveChamber.Thin.G3
def rows : List Row := (Page12.entries++(Page13.entries++(Page14.entries++Page15.entries)))
theorem checked : CheckedEntries rows := (checkedAppend Page12.checked (checkedAppend Page13.checked (checkedAppend Page14.checked Page15.checked)))
end Research.Graph9822.FiveChamber.Thin.G3
#print axioms Research.Graph9822.FiveChamber.Thin.G3.checked
