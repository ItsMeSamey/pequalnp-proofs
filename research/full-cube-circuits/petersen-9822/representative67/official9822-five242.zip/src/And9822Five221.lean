import And9822ThinGroup0
import And9822ThinGroup1
import And9822ThinGroup2
import And9822ThinGroup3
import And9822ThinGroup4
import And9822ThinGroup5
namespace Research.Graph9822.FiveChamber.Thin.Family
open Research.Graph9822ProfilesK5 Catalogue OneStop
def allRows : List Row := (G0.rows++(G1.rows++(G2.rows++(G3.rows++(G4.rows++G5.rows)))))
theorem checked : CheckedEntries allRows := (checkedAppend G0.checked (checkedAppend G1.checked (checkedAppend G2.checked (checkedAppend G3.checked (checkedAppend G4.checked G5.checked)))))
theorem lookup (id : Nat) (mem : id ∈ allRows.map Row.id) :
    (∀ {b l p n}, Scan b l p n → Tags (catalogue id) p →
      ∀ R : Vertex → Mask, (∀ v,R v∈l) →
      (∀ i : Fin 16, ∃ x : Word,∀ v,x∈R v ↔ wanted i v=true) → False) ∧
      (∀ tape,runProfile (catalogue id) tape=some tape) := by
  obtain ⟨r,hr,rfl⟩ := List.mem_map.mp mem
  obtain ⟨ok,eq⟩ := checked _ hr
  rw [eq]
  exact ⟨@physical r ok,skip ok⟩
end Research.Graph9822.FiveChamber.Thin.Family
#print axioms Research.Graph9822.FiveChamber.Thin.Family.lookup
