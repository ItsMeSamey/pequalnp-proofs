import And9822ThinAppend
import And9822ThinPage16
import And9822ThinPage17
import And9822ThinPage18
import And9822ThinPage19
namespace Research.Graph9822.FiveChamber.Thin.G4
def rows : List Row := (Page16.entries++(Page17.entries++(Page18.entries++Page19.entries)))
theorem checked : CheckedEntries rows := (checkedAppend Page16.checked (checkedAppend Page17.checked (checkedAppend Page18.checked Page19.checked)))
end Research.Graph9822.FiveChamber.Thin.G4
#print axioms Research.Graph9822.FiveChamber.Thin.G4.checked
