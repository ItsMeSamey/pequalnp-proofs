import And9822ThinAppend
import And9822ThinPage04
import And9822ThinPage05
import And9822ThinPage06
import And9822ThinPage07
namespace Research.Graph9822.FiveChamber.Thin.G1
def rows : List Row := (Page4.entries++(Page5.entries++(Page6.entries++Page7.entries)))
theorem checked : CheckedEntries rows := (checkedAppend Page4.checked (checkedAppend Page5.checked (checkedAppend Page6.checked Page7.checked)))
end Research.Graph9822.FiveChamber.Thin.G1
#print axioms Research.Graph9822.FiveChamber.Thin.G1.checked
