import And9822ThinAppend
import And9822ThinPage00
import And9822ThinPage01
import And9822ThinPage02
import And9822ThinPage03
namespace Research.Graph9822.FiveChamber.Thin.G0
def rows : List Row := (Page0.entries++(Page1.entries++(Page2.entries++Page3.entries)))
theorem checked : CheckedEntries rows := (checkedAppend Page0.checked (checkedAppend Page1.checked (checkedAppend Page2.checked Page3.checked)))
end Research.Graph9822.FiveChamber.Thin.G0
#print axioms Research.Graph9822.FiveChamber.Thin.G0.checked
