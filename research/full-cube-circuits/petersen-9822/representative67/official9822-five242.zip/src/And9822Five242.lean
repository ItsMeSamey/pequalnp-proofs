import And9822ThinCount
import And9822Five21
set_option maxRecDepth 100000
set_option maxHeartbeats 3000000
namespace Research.Graph9822.FiveChamber.Lookup242
open OneStop Thin
def directIDs := OneStop.Family.index.map OneStop.Family.Entry.id
def atomIDs := Thin.Family.allRows.map Thin.Row.id
private theorem sameCatalogue : ∀ e ∈ OneStop.Family.index,
    Thin.catalogue e.id = e.activation := by decide +kernel

theorem noPhysical (id : Nat) (mem : id ∈ directIDs++atomIDs) : OneStop.Family.NoPhysical (Thin.catalogue id) := by
  rcases List.mem_append.mp mem with direct|atom
  · obtain ⟨e,he,rfl⟩ := List.mem_map.mp direct
    rw [sameCatalogue e he]
    exact (OneStop.Family.complete e he).1
  · intro b l p n scan tags R ret realize _
    exact (Thin.Family.lookup id atom).1 scan tags R ret realize

theorem distinct : (directIDs++atomIDs).length=242 ∧ (directIDs++atomIDs).Nodup := by
  have eq : atomIDs = Thin.Family.ids := Thin.Family.idList
  have hd : directIDs.length=21 ∧ directIDs.Nodup := by decide
  have ha := Thin.Family.count
  have na : atomIDs.Nodup := ha.2
  have ca : atomIDs.length=221 := by simpa [atomIDs] using ha.1
  refine ⟨by simp [hd.1,ca],?_⟩
  apply List.nodup_append.mpr
  refine ⟨hd.2,na,?_⟩
  rw [eq]
  decide
end Research.Graph9822.FiveChamber.Lookup242
#print axioms Research.Graph9822.FiveChamber.Lookup242.noPhysical
