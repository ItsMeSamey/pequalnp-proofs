import MixedLiteralC5Val9822
import Research.WegenerThreshold
namespace Research.LiteralC5.Table

private theorem preserved {α β : Type} {z : β} (f : β → α → β)
    (P : β → Prop) (hz : P z) (step : ∀ a b, P a → P (f a b)) (xs : List α) :
    P (xs.foldl f z) := by
  induction xs generalizing z with
  | nil => exact hz
  | cons x xs ih => exact ih (step z x hz)

def store (ys : List Nat) (y : Nat) := if ys.contains y then ys else y::ys
private theorem old_store {r : Nat} {ys : List Nat} (h : r ∈ ys) (v : Nat) :
    r ∈ store ys v := by unfold store; split <;> simp_all
private theorem new_store (ys : List Nat) (v : Nat) : v ∈ store ys v := by
  unfold store; split <;> simp_all

def inc (x : Nat) (acc : List Nat) (y : Nat) :=
  if y &&& x &&& pos != 0 then store acc (y &&& x) else acc

private theorem old_inc {r : Nat} {a : List Nat} (h : r ∈ a) (x y : Nat) :
    r ∈ inc x a y := by unfold inc; split; exact old_store h _; exact h

theorem present_inc {z x : Nat} (ys acc : List Nat) (hz : z ∈ ys)
    (hp : (z &&& x) &&& pos != 0) :
    z &&& x ∈ ys.foldl (inc x) acc := by
  induction ys generalizing acc with
  | nil => simp at hz
  | cons y ys ih =>
    rcases List.mem_cons.mp hz with eq|inTail
    · subst y
      have init : z &&& x ∈ inc x acc z := by simp [inc,hp,new_store]
      exact preserved (inc x) (fun a => z &&& x ∈ a) init (fun a b h => old_inc h x b) ys
    · exact ih _ inTail

theorem bit_fold (s : List Nat) (h k : Nat) :
    (s.foldl Nat.land h).testBit k = true ↔ h.testBit k = true ∧
    ∀ a ∈ s, a.testBit k = true := by
  induction s generalizing h with
  | nil => simp
  | cons a s ih => simp [List.foldl,ih,Nat.testBit_and,and_assoc]

theorem val_eq {s t : List Nat} (h : ∀ i, i ∈ s ↔ i ∈ t) : val s = val t := by
  apply Nat.eq_of_testBit_eq
  intro k
  apply Bool.eq_iff_iff.mpr
  simp only [val,bit_fold]
  constructor <;> rintro ⟨base,all⟩
  · exact ⟨base,fun a ha => all a ((h a).mpr ha)⟩
  · exact ⟨base,fun a ha => all a ((h a).mp ha)⟩

def grow (old : List Nat) (x : Nat) := old.foldl (inc x) old
private theorem grow_keep {s : List Nat} {v : Nat} (hv : v ∈ s) (x : Nat) :
    v ∈ grow s x := preserved (inc x) (fun a => v ∈ a) hv (fun a b h => old_inc h x b) s
private theorem nonzero_left (a b : Nat) (h : (a &&& b) &&& pos ≠ 0) :
    a &&& pos ≠ 0 := by
  intro hz
  have eq : (a &&& b) &&& pos = (a &&& pos) &&& b := by ac_rfl
  simp [eq,hz] at h
private theorem selected_reachable (xs pool : List Nat) (pick : Nat → Bool) (v : Nat)
    (hv : v ∈ pool) (hp : ((xs.filter pick).foldl Nat.land v) &&& pos ≠ 0) :
    (xs.filter pick).foldl Nat.land v ∈ xs.foldl grow pool := by
  induction xs generalizing pool v with
  | nil => exact hv
  | cons a xs ih =>
    cases hh : pick a with
    | false => simp [hh] at hp ⊢; exact ih _ _ (grow_keep hv a) hp
    | true =>
      simp [hh] at hp ⊢
      have positive : (v &&& a) &&& pos ≠ 0 := by
        intro hz
        have aux (l : List Nat) (b : Nat) (hb : b &&& pos = 0) :
            l.foldl Nat.land b &&& pos = 0 := by
          induction l generalizing b with
          | nil => exact hb
          | cons k l ind => exact ind _ (not_not.mp (fun hn => nonzero_left b k hn hb))
        exact hp (aux _ _ hz)
      apply ih _ _ _ hp
      exact present_inc _ _ hv (by simpa using positive)
theorem mem_meets {xs s : List Nat} (hs : ∀ a ∈ s, a ∈ xs)
    (hp : val s &&& pos ≠ 0) : val s ∈ meets xs := by
  let pick (a : Nat) := s.contains a
  have eq : val s = val (xs.filter pick) := by
    apply val_eq
    intro a
    simp [pick]
    exact hs a
  rw [eq] at hp ⊢
  have reach := selected_reachable xs [live] pick live (by simp) hp
  have form : grow = (fun (old : List Nat) (x : Nat) => old.foldl (fun acc y =>
       let t := y &&& x
       if t &&& pos != 0 && !acc.contains t then t::acc else acc) old) := by
    funext old x
    unfold grow
    congr 1
    funext acc y
    unfold inc store
    split <;> (try split) <;> simp_all
  rw [form] at reach
  exact reach
end Research.LiteralC5.Table
