import MixedNineDominance9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean GuardTags Research.NineHotSites
theorem nested_hot_implies_guard {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    {k l d s : Nat} {q v : Gate} (kp : k<pre.length) (lk : l<k)
    (qsite : pre[k]?=some q) (vsite : pre[l]?=some v) (qo : q.op=.or) (vo : v.op=.or)
    (ig : g.inputs=[10+k]) (qp : q.inputs=[s,10+l] ∨ q.inputs=[10+l,s])
    (vp : v.inputs=[9,d] ∨ v.inputs=[d,9]) (j : Nat) (jb : j<10+C.gates.length)
    (hot : (liveTable C).Hot j) : ∀x,vl C.gates x j=true → innerValue pre g x=true := by
  have qfull : C.gates[k]?=some q := by rw [r.split,List.getElem?_append_left kp];exact qsite
  have vfull : C.gates[l]?=some v := by rw [r.split,List.getElem?_append_left (by omega : l<pre.length)];exact vsite
  have last (x : Input) : vl C.gates x (10+k)=innerValue pre g x := by
    rw [visible r (10+k) (by omega)];simp [innerValue,ig]
  have first (x : Input) (h : vl C.gates x 9=true) : vl C.gates x (10+l)=true := by
    rw [vl_gate _ red.clean _ _ _ vfull]
    rcases vp with p|p <;> simp [vo,p,GateOp.eval,h]
  have second (x : Input) (h : vl C.gates x (10+l)=true) : vl C.gates x (10+k)=true := by
    rw [vl_gate _ red.clean _ _ _ qfull]
    rcases qp with p|p <;> simp [qo,p,GateOp.eval,h]
  have nine : vl C.gates (SignedClamp.singleton 9) 9=true := by
    rw [vl_input _ _ _ (by decide : 9<10)];rfl
  apply two_sites_dominate r cand red seven (by omega : 10+l≠10+k)
    (live_site_mem vfull vo (first _ nine)) (live_site_mem qfull qo (second _ (first _ nine)))
    _ _ _ j jb hot
  · intro x h;rw [←last];exact second _ (first _ h)
  · intro x h;rw [←last];exact second _ h
  · intro x h;rwa [←last]
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
