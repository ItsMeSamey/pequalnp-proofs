import OR9822HeadGrant
import H2CanonicalPairs9822
namespace Research.Graph9822GlobalH2
open Research.Graph9822H2Check Research.Graph9822H2Check.SeedCache
open Research.Graph9822OneHidden (meets)

structure SignedOrder (q Q : Nat) : Prop where
  pos : ∀ i : Fin 13,(positive q).testBit i.val=true → (positive Q).testBit i.val=true
  neg : ∀ n : Fin 16,(negative Q).testBit n.val=true → (negative q).testBit n.val=true

theorem nested_order {h H q Q a b : Nat} {u : Bool} (old : NestedBits h q a b u)
    (new : NestedBits H Q a b u) (ep : sub (positive h) (positive H)=true)
    (nb : sub (negative H) (negative h)=true) : SignedOrder q Q := by
  constructor
  · intro i hot
    rw [old.pos] at hot
    rw [new.pos]
    have increase := (subset_bits ..).1 ep i.val
    cases u <;> cases aq : (rawPos a).testBit i.val <;> cases bq : (rawPos b).testBit i.val <;> simp_all
  · intro n hot
    rw [new.neg] at hot
    rw [old.neg]
    have decrease := (subset_bits ..).1 nb n.val
    cases u <;> cases aq : (rawNeg a).testBit n.val <;> cases bq : (rawNeg b).testBit n.val <;> simp_all

theorem lift_demand {q Q t f g : Nat} (ord : SignedOrder q Q) (low : t<8192) (bounded : g<65536)
    (smaller : sub g f=true) (held : holds q (demand t f)) : holds Q (demand t g) := by
  apply join_subset
  · apply held_positive_mask low
    apply (subset_bits ..).2
    intro i hot
    have lo : i<13 := by
      by_contra! high
      have off := Nat.testBit_lt_two_pow (lt_of_lt_of_le low (show 8192≤2^i from Nat.pow_le_pow_right (by decide : 0<(2:Nat)) high))
      exact Bool.noConfusion (hot.symm.trans off)
    exact ord.pos ⟨i,lo⟩ (true_on_demand held ⟨i,lo⟩ (by simpa only [demand_positive low] using hot))
  · apply negative_shore bounded
    intro n on
    apply Bool.eq_false_iff.mpr
    intro new
    have old := ord.neg n new
    have cold := false_on_demand held n (by simpa only [demand_negative low] using (subset_bits ..).1 smaller n.val on)
    exact Bool.noConfusion (old.symm.trans cold)
end Research.Graph9822GlobalH2
