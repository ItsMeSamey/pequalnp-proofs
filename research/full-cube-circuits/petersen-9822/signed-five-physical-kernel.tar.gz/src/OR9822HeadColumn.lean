import OR9822HeadShape
namespace Research.Graph9822H2Check.SeedCache
def madePos (h a b : Nat) (u : Bool) := (rawPos a ||| added (positive h) u) &&& rawPos b
def madeNeg (h a b : Nat) (u : Bool) := (rawNeg a ||| added (negative h) u) &&& rawNeg b
def made (h a b : Nat) (u : Bool) := demand (madePos h a b u) (madeNeg h a b u)
theorem made_small (h a b : Nat) (u : Bool) : madePos h a b u<8192 :=
  lt_of_le_of_lt Nat.and_le_right (Graph9822H1Check.mask_lt1 _ _)
theorem made_bits (h a b : Nat) (u : Bool) : NestedBits h (made h a b u) a b u := by
  constructor
  · intro i
    rw [made,demand_positive (made_small ..)]
    cases u <;> simp [madePos,added,Nat.testBit_and,Nat.testBit_or]
  · intro i
    rw [made,demand_negative (made_small ..)]
    cases u <;> simp [madeNeg,added,Nat.testBit_and,Nat.testBit_or]

theorem made_covers {h a b t : Nat} {u : Bool} (lt : t<8192)
    (rb : sub t (rawPos b)=true) (la : sub (required t (positive h) u) (rawPos a)=true) :
    sub t (positive (made h a b u))=true := by
  rw [made,demand_positive (made_small ..)]
  apply (subset_bits ..).2
  intro i on
  have right := (subset_bits ..).1 rb i on
  have left := (subset_bits ..).1 la i
  have low : i<13 := by
    by_contra! hi
    have off := Nat.testBit_lt_two_pow (lt_of_lt_of_le lt (show 8192≤2^i from Nat.pow_le_pow_right (by decide : 0<(2:Nat)) hi))
    exact Bool.noConfusion (on.symm.trans off)
  have mask : (8191:Nat).testBit i=true := by
    change (2^13-1 : Nat).testBit i=true
    rw [Nat.testBit_two_pow_sub_one]; exact decide_eq_true low
  cases u <;> cases m : (positive h).testBit i <;> simp_all [madePos,required,added]
end Research.Graph9822H2Check.SeedCache
