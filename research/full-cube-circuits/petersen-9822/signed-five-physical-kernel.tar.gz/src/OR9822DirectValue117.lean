import OR9822ProfileDirectData
namespace Research.Graph9822ProfileArithmetic.Direct
set_option maxHeartbeats 18000000 in
set_option maxRecDepth 16000 in
theorem value117 : doneMode 117=true := by decide +kernel
end Research.Graph9822ProfileArithmetic.Direct
