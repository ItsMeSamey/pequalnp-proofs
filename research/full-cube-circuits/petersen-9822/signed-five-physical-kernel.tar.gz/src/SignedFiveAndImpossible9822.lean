import SignedFiveFactorClose9822
import SignedFourNoModel9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean

theorem original_one_not_no_five {C : Circuit} (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (one : C.gates.countP countsNot=1)
    (low : C.gates.countP (fun q => match q.op with | .and => true | _ => false)≤5) : False :=
  candidate_no_five_via_factor Research.SignedFactorFour.no_four cand red one low

end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.original_one_not_no_five
