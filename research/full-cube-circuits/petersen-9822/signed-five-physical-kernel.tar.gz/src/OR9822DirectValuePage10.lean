import OR9822DirectValue196
import OR9822DirectValue197
import OR9822DirectValue198
import OR9822DirectValue199
import OR9822DirectValue200
import OR9822DirectValue201
import OR9822DirectValue202
import OR9822DirectValue203
import OR9822DirectValue204
import OR9822DirectValue205
namespace Research.Graph9822ProfileArithmetic.Direct
theorem valuePage10 (j : Nat) (lo : 196≤j) (hi : j<206) : doneMode j=true := by
  by_cases e196 : j=196
  · subst j
    exact value196
  by_cases e197 : j=197
  · subst j
    exact value197
  by_cases e198 : j=198
  · subst j
    exact value198
  by_cases e199 : j=199
  · subst j
    exact value199
  by_cases e200 : j=200
  · subst j
    exact value200
  by_cases e201 : j=201
  · subst j
    exact value201
  by_cases e202 : j=202
  · subst j
    exact value202
  by_cases e203 : j=203
  · subst j
    exact value203
  by_cases e204 : j=204
  · subst j
    exact value204
  have e : j=205 := by omega
  subst j
  exact value205
end Research.Graph9822ProfileArithmetic.Direct
