import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle66 : List ModeRow := [(31347020,[3770,27207,12399,52688,17246,10855,6303,5351,10807],[3770,52688,10855])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle66 : batchSingle66.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
