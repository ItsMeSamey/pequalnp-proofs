import OR9822ProfileDirectData
namespace Research.Graph9822ProfileArithmetic.Direct
set_option maxHeartbeats 18000000 in
set_option maxRecDepth 16000 in
theorem charge159 : inputs 159=true := by decide +kernel
end Research.Graph9822ProfileArithmetic.Direct
