import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle29 : List ModeRow := [(3655334,[37182,3869,43559,7566,1530,1909,5246,49559,12702],[37182,1530,43811,831])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle29 : batchSingle29.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
