import SignedFourFiniteRows9822
namespace Research.SignedFactorFour
set_option maxRecDepth 12000
set_option maxHeartbeats 4000000
def r100 : Row := ([1,2,6,8], [0,9])
private theorem ok100 : rowGood r100=true := by decide +kernel
def r101 : Row := ([1,2,6,9], [0,3])
private theorem ok101 : rowGood r101=true := by decide +kernel
def r102 : Row := ([1,2,7,8], [0,9])
private theorem ok102 : rowGood r102=true := by decide +kernel
def r103 : Row := ([1,2,7,9], [0,3])
private theorem ok103 : rowGood r103=true := by decide +kernel
def r104 : Row := ([1,2,8,9], [0,5])
private theorem ok104 : rowGood r104=true := by decide +kernel
def page20 : List Row := [r100,r101,r102,r103,r104]
theorem paid20 : page20.all rowGood=true := by simp [page20,ok100,ok101,ok102,ok103,ok104]
end Research.SignedFactorFour
