import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle300 : List ModeRow := [(444741712,[54812,26679,12399,19515,43111,47119,37151,21625],[54812,11319,43111,19515,21685])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle300 : batchSingle300.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
