import OR9822DirectCharge176
import OR9822DirectCharge177
import OR9822DirectCharge178
import OR9822DirectCharge179
import OR9822DirectCharge180
import OR9822DirectCharge181
import OR9822DirectCharge182
import OR9822DirectCharge183
import OR9822DirectCharge184
import OR9822DirectCharge185
namespace Research.Graph9822ProfileArithmetic.Direct
theorem chargePage8 (j : Nat) (lo : 176≤j) (hi : j<186) : inputs j=true := by
  by_cases e176 : j=176
  · subst j
    exact charge176
  by_cases e177 : j=177
  · subst j
    exact charge177
  by_cases e178 : j=178
  · subst j
    exact charge178
  by_cases e179 : j=179
  · subst j
    exact charge179
  by_cases e180 : j=180
  · subst j
    exact charge180
  by_cases e181 : j=181
  · subst j
    exact charge181
  by_cases e182 : j=182
  · subst j
    exact charge182
  by_cases e183 : j=183
  · subst j
    exact charge183
  by_cases e184 : j=184
  · subst j
    exact charge184
  have e : j=185 := by omega
  subst j
  exact charge185
end Research.Graph9822ProfileArithmetic.Direct
