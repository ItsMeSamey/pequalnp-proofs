import OR9822DirectCharge156
import OR9822DirectCharge157
import OR9822DirectCharge158
import OR9822DirectCharge159
import OR9822DirectCharge160
import OR9822DirectCharge161
import OR9822DirectCharge162
import OR9822DirectCharge163
import OR9822DirectCharge164
import OR9822DirectCharge165
namespace Research.Graph9822ProfileArithmetic.Direct
theorem chargePage6 (j : Nat) (lo : 156≤j) (hi : j<166) : inputs j=true := by
  by_cases e156 : j=156
  · subst j
    exact charge156
  by_cases e157 : j=157
  · subst j
    exact charge157
  by_cases e158 : j=158
  · subst j
    exact charge158
  by_cases e159 : j=159
  · subst j
    exact charge159
  by_cases e160 : j=160
  · subst j
    exact charge160
  by_cases e161 : j=161
  · subst j
    exact charge161
  by_cases e162 : j=162
  · subst j
    exact charge162
  by_cases e163 : j=163
  · subst j
    exact charge163
  by_cases e164 : j=164
  · subst j
    exact charge164
  have e : j=165 := by omega
  subst j
  exact charge165
end Research.Graph9822ProfileArithmetic.Direct
