import SignedRoots9822All
import Mathlib.Data.List.Permutation
namespace Petersen9822.DagCut

def rawRepeats (r : Nat) := (List.range 10).countP r.testBit

set_option maxRecDepth 16000 in
set_option maxHeartbeats 0 in
theorem threeMasks : ∀ r : Fin 1024, sub r.val 304 = true → 2 ≤ rawRepeats r.val →
    r.val ∈ ([48,272,288,304] : List Nat) := by decide +kernel

set_option maxRecDepth 16000 in
set_option maxHeartbeats 0 in
theorem fourMasks : ∀ r : Fin 1024, sub r.val 304 = true → 2 ≤ rawRepeats r.val →
    rawRepeats r.val ≤ 2 → r.val ∈ ([48,272,288] : List Nat) := by decide +kernel

theorem normalized_of_order {js : List Nat} {r : Nat} (hr : r < 1024)
    (in458 : sub r 304 = true) (two : 2 ≤ rawRepeats r)
    (order : js.idxOf 0 < js.idxOf 2)
    (shape : js.Perm [0,1,2] ∨ js.Perm [0,1,2,3] ∧ rawRepeats r ≤ 2) :
    (js,r) ∈ normalizedRoots := by
  rcases shape with h | ⟨h,four⟩
  · have masks := threeMasks ⟨r,hr⟩ in458 two
    have orders := List.mem_permutations'.mpr h
    have all : (([0,1,2] : List Nat).permutations').all (fun s =>
        ([48,272,288,304] : List Nat).all (fun m =>
          decide (s.idxOf 0 < s.idxOf 2 → (s,m) ∈ normalizedRoots))) = true := by decide +kernel
    exact of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp all _ orders) _ masks) order
  · have masks := fourMasks ⟨r,hr⟩ in458 two four
    have orders := List.mem_permutations'.mpr h
    have all : (([0,1,2,3] : List Nat).permutations').all (fun s =>
        ([48,272,288] : List Nat).all (fun m =>
          decide (s.idxOf 0 < s.idxOf 2 → (s,m) ∈ normalizedRoots))) = true := by decide +kernel
    exact of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp all _ orders) _ masks) order

theorem orderedPlacementExcluded {js : List Nat} {r : Nat} (hr : r < 1024)
    (in458 : sub r 304 = true) (two : 2 ≤ rawRepeats r)
    (order : js.idxOf 0 < js.idxOf 2)
    (shape : js.Perm [0,1,2] ∨ js.Perm [0,1,2,3] ∧ rawRepeats r ≤ 2) :
    ¬ Placement js r :=
  no_normalized_placement (normalized_of_order hr in458 two order shape)
end Petersen9822.DagCut
#print axioms Petersen9822.DagCut.orderedPlacementExcluded
