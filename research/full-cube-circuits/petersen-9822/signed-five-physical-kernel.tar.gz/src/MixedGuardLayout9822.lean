import HotPrefixSingleSite9822
import FullNineBudget9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet SignedClamp NonrawSupport LowHotElimination
open PEqualNP.Outside.L_meta_9822.Clean GuardTags Research.NineHotSites
theorem mixed_guard_layout {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (upper : outerValue pre post C.output (SignedClamp.singleton s) true=true) :
    ∃k : Nat,∃q : Gate,∃b : Nat,k<pre.length ∧ pre[k]?=some q ∧ q.op=.or ∧ g.inputs=[10+k] ∧
      (q.inputs=[s.val,b] ∨ q.inputs=[b,s.val]) ∧
      (b=9 ∨ ∃l : Nat,∃v : Gate,∃d : Nat,l<k ∧ pre[l]?=some v ∧ v.op=.or ∧ b=10+l ∧
        (v.inputs=[9,d] ∨ v.inputs=[d,9])) := by
  classical
  let row := SignedClamp.singleton (9 : Fin 10)
  let w := List.ofFn row
  obtain ⟨k,q,b,kp,qsite,qo,bk,_,pins,ig⟩ := high_socket_is_guard r cand red (by omega) s sl su upper
  have qfull : C.gates[k]?=some q := by rw [r.split,List.getElem?_append_left kp];exact qsite
  have hot9 := (full_upper_nine r cand red seven).2
  have Aon : vl C.gates row (10+k)=true := by
    rw [visible r (10+k) (by omega)]
    simpa [row,innerValue,ig] using hot9
  have ne : s≠9 := by rintro rfl;exact (by decide : ¬(9 : Fin 10).val≤8) su
  have s0 : vl C.gates row s.val=false := (vl_input _ _ _ s.isLt).trans (by simp [row,SignedClamp.singleton,ne])
  have bOn : vl C.gates row b=true := by
    have h := Aon
    rw [vl_gate _ red.clean _ _ _ qfull] at h
    rcases pins with pi|pi <;> simpa [pi,qo,GateOp.eval,s0] using h
  refine ⟨k,q,b,kp,qsite,qo,ig,pins,?_⟩
  by_cases raw : b<10
  · left
    have eq := (vl_input _ _ _ raw).symm.trans bOn
    exact congrArg Fin.val (by simpa [row,SignedClamp.singleton] using eq : (⟨b,raw⟩ : Fin 10)=9)
  · right
    obtain ⟨l,v,d,lp,vsite,vo,_,_,vpins,_,before⟩ := first_hot_socket r cand (by omega) red 9 hot9
    have lk : l<k := by
      by_contra! late
      have z := before (b-10) (by omega)
      rw [show 10+(b-10)=b by omega,bOn] at z;contradiction
    have vfull : C.gates[l]?=some v := by rw [r.split,List.getElem?_append_left lp];exact vsite
    have dom (x : Input) (on : x 9=true) : vl C.gates x (10+l)=true := by
      have has : vl C.gates x 9=true := (vl_input _ _ _ (by decide : 9<10)).trans on
      rw [vl_gate _ red.clean _ _ _ vfull]
      rcases vpins with vp|vp <;> simp [vp,vo,GateOp.eval,has]
    have physical := full_physical_nine_budget r cand red seven
    have card : (sites pre w).card≤2 := by
      rw [Research.NineHotSites.card]
      change physicalHot pre w + _ ≤ 2 at physical
      omega
    have tagged (i : Nat) (u : Gate) (ip : i<pre.length) (atU : pre[i]?=some u) (op : u.op=.or)
        (on : vl C.gates row (10+i)=true) : 10+i∈sites pre w := by
      rw [visible r (10+i) (by omega)] at on
      have bit : (wiresFrom pre w).getD (w.length+i) false=true := by simpa [w] using on
      simpa [w] using (Research.NineHotSites.mem w atU (by simp [CircuitCompiler.orFlag,op]) bit)
    have first := tagged l v lp vsite vo (dom row (by simp [row,SignedClamp.singleton]))
    have last := tagged k q kp qsite qo Aon
    have one (i : Nat) (a : Gate) (ik : i<k) (site : C.gates[i]?=some a) (op : a.op=.or)
        (on : vl C.gates row (10+i)=true) : 10+i=10+l := by
      by_contra diff
      have ip : i<pre.length := by omega
      rw [r.split,List.getElem?_append_left ip] at site
      have third := tagged i a ip site op on
      let chosen : Finset Nat := {10+i,10+l,10+k}
      have size : chosen.card=3 := by
        have h₁ : 10+i∉({10+l,10+k} : Finset Nat) := by simp only [Finset.mem_insert,Finset.mem_singleton];omega
        have h₂ : 10+l∉({10+k} : Finset Nat) := by simp only [Finset.mem_singleton];omega
        rw [show chosen=insert (10+i) (insert (10+l) {10+k}) by rfl,Finset.card_insert_of_notMem h₁,Finset.card_insert_of_notMem h₂,Finset.card_singleton]
      have sub : chosen⊆sites pre w := by
        intro a m
        simp only [chosen,Finset.mem_insert,Finset.mem_singleton] at m
        rcases m with rfl|rfl|rfl <;> assumption
      have lim := Finset.card_le_card sub
      omega
    have matchB := hot_prefix_one_site r red 9 (10+l) k (by omega) dom one b bk bOn
    exact ⟨l,v,d,lk,vsite,vo,matchB.resolve_left (by omega),vpins⟩
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.mixed_guard_layout
