import OR9822ShortProjection
namespace Research.Graph9822ProfileArithmetic.Laws
def clipped (k : Nat) : List Nat :=
  let a := pairStart[k]?.getD 0
  let b := pairStart[k+1]?.getD 0
  (pairWords.toList.drop a).take (b-a)
def clipOK (k : Nat) := decide (pairStart[k+1]?.getD 0 ≤ pairWords.size) &&
  (clipped k == shortWords k)
private theorem range_slice (xs : Array Nat) (a b : Nat) (small : b≤xs.size) :
    (List.range (b-a)).map (fun j => xs[a+j]?.getD 0)=(xs.toList.drop a).take (b-a) := by
  apply List.ext_getElem
  · simp only [List.length_map,List.length_range,List.length_take,List.length_drop,Array.length_toList]
    omega
  · intro i li ri
    have hi : i<b-a := by simpa only [List.length_map,List.length_range] using li
    have bound : a+i<xs.size := by omega
    simp only [List.getElem_map,List.getElem_range,List.getElem_take,List.getElem_drop,Array.getElem_toList,
      getElem?_pos xs (a+i) bound,Option.getD_some]
theorem clip_sound {k : Nat} (ok : clipOK k=true) : binaryWords k=shortWords k := by
  obtain ⟨bound,eq⟩ := Bool.and_eq_true_iff.mp ok
  exact (range_slice pairWords _ _ (of_decide_eq_true bound)).trans (beq_iff_eq.mp eq)
end Research.Graph9822ProfileArithmetic.Laws
