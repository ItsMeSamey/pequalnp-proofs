import MixedPositiveUse9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp NonrawSupport OuterNet
open PEqualNP.Outside.L_meta_9822.Clean FreeAndNet
theorem or_cascade_model {C pre p t tail g u v}
    (r : Roster C pre (p++u::(t++v::tail)) g) (cand : Candidate C)
    (seven : 7≤C.gates.countP countsAnd) (uo : u.op=.or) (vo : v.op=.or)
    (up : 10+pre.length∈u.inputs) (vp : 10+(pre++topGate::p).length∈v.inputs) :
    ∃ n : Net (Fin 10), n.cost≤7 ∧ ∀x,n.eval x=outerValue pre (p++u::(t++v::tail)) C.output x true := by
  let pref := pre++topGate::p
  let D := hotReaderCircuit pref t tail C.output
  have mono : Monotone2 D := by
    intro a ha
    change a∈(pre++topGate::p)++topGate::(t++topGate::tail) at ha
    have old (ha : a∈pre++(p++u::(t++v::tail))) :
        PositiveOp a ∧ a.inputs.length≤2 :=
      ⟨r.pos a ha,(cand.1 a (by rw [r.split];simp only [List.mem_append,List.mem_cons] at *;tauto)).2⟩
    have top : PositiveOp topGate ∧ topGate.inputs.length≤2 := ⟨Or.inl rfl,by decide⟩
    simp only [List.mem_append,List.mem_cons] at ha
    rcases ha with (h|h|h)|h|h|h|h <;> first | subst a;exact top | exact old (by simp [h])
  refine ⟨CircuitCompiler.compile 10 D,?_,?_⟩
  · have cap := or_cap r cand seven
    have pay := CircuitCompiler.compile_cost 10 D
    rw [r.split] at cap
    simp [D,pref,hotReaderCircuit,topGate,CircuitCompiler.orFlag,uo,vo,r.inv,List.filter_append] at cap pay ⊢
    omega
  · intro x
    rw [CircuitCompiler.compile_eval _ _ mono x,show D=hotReaderCircuit pref t tail C.output by rfl,
      or_hot_reader_eval pref t tail v vo vp]
    have eq := or_hot_reader_eval pre p (t++v::tail) u uo up C.output x
    apply Eq.trans _ eq
    change (wiresFrom (t++v::tail) (wiresFrom pref (List.ofFn x)++[true])).getD _ false=_
    change _=(wiresFrom (pre++topGate::(p++topGate::(t++v::tail))) (List.ofFn x)).getD _ false
    rw [show pre++topGate::(p++topGate::(t++v::tail))=pref++topGate::(t++v::tail) by simp [pref]]
    rw [wiresFrom_append pref]
    rfl
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
