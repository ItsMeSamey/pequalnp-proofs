import CompactSignedReceivers9822
import CutGroupConnection
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open PEqualNP.CircuitLowerBounds
open PEqualNP.Outside.L_meta_9822.Clean
open Research.Graph9822Profiles Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution (asCircuit)

theorem physical_bank_rooms {pre post : List PEqualNP.CircuitLowerBounds.Gate}
    {g : PEqualNP.CircuitLowerBounds.Gate} {out : Nat}
    (minimal : Reduced 10 (pre++g::post) out)
    (nc : ∃ x y : Input, vl (pre++g::post) x out ≠ vl (pre++g::post) y out)
    (pp : ∀ q ∈ pre, PositiveOp q) (pt : ∀ q ∈ post, PositiveOp q)
    (cut : ComputesCut (innerValue pre g) (outerValue pre post out))
    (size : pre.length + post.length ≤ 16) (bound : out < 10+(pre++g::post).length)
    (cap : ((outerCircuit 10 pre post out).gates.map readDir).countP Research.Graph9822Resolution.Gate.isAnd ≤ 6) :
    let C := outerCircuit 10 pre post out
    let gs := C.gates.map readDir
    let R := actualReceiver gs C.output cap
    ∃ (branches lib : List Mask) (switches : List (Axis × Mask)) (cost : Nat),
      Scan branches lib switches cost ∧ cost ≤ 6 ∧
      (∀ a : Fin 11, {w | R a.val w} ∈ lib) ∧ CatalogueRows R (auxBit pre g) := by
  let C := outerCircuit 10 pre post out
  let gs := C.gates.map readDir
  let axis := switchAxis (switchAddrs gs 11) ((switchAddrs_length gs 11).trans_le cap)
  let es := gateEvents axis gs 11 ++ rawEvents 11
  let s := (activeEvents es (initial C.output)).foldl next (initial C.output)
  have same : asCircuit gs C.output = C := physical_outer_basis minimal.clean pp pt
  have ess := all_eleven_wire_witnesses same minimal nc pp cut
  have live : ∀ j < 11, (back axis gs 11 (initial C.output)).q j ≠ [] := by
    intro j hj
    obtain ⟨u,v,off,hit⟩ := ess j hj
    exact back_essential axis gs 11 C.output j u v off hit
  obtain ⟨lib,scan,_,inlib⟩ := extracted_good es C.output
  refine ⟨s.branches,lib,s.switches,s.cost,scan,
    (actual_six_join_profile axis minimal nc pp pt cut size bound).2,?_,
    physicalCatalogueRows same cut pp cap⟩
  intro a
  apply inlib
  rw [receiver_list_exact axis gs 11 C.output live]
  apply List.mem_map.mpr
  refine ⟨a.val,List.mem_range.mpr a.isLt,?_⟩
  ext w
  exact (back_receiver_exact axis w gs 11 a.val C.output a.isLt).symm

end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.physical_bank_rooms
