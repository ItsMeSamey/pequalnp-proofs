import SignedFourFiniteRows9822
namespace Research.SignedFactorFour
set_option maxRecDepth 12000
set_option maxHeartbeats 4000000
def r30 : Row := ([0,2,3,6], [7,8])
private theorem ok30 : rowGood r30=true := by decide +kernel
def r31 : Row := ([0,2,3,7], [5,6])
private theorem ok31 : rowGood r31=true := by decide +kernel
def r32 : Row := ([0,2,3,8], [6,9])
private theorem ok32 : rowGood r32=true := by decide +kernel
def r33 : Row := ([0,2,3,9], [5,6])
private theorem ok33 : rowGood r33=true := by decide +kernel
def r34 : Row := ([0,2,4,5], [8,9])
private theorem ok34 : rowGood r34=true := by decide +kernel
def page6 : List Row := [r30,r31,r32,r33,r34]
theorem paid6 : page6.all rowGood=true := by simp [page6,ok30,ok31,ok32,ok33,ok34]
end Research.SignedFactorFour
