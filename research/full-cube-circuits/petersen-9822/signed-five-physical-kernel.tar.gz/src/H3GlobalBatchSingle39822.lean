import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle3 : List ModeRow := [(116256,[61966,763,9127,4223,41191,13710,831,4567,507],[61966,16575,22087,41191,13710,4223,831,763])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle3 : batchSingle3.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
