import OR9822CenterCuts
import OR9822HullPacket
namespace Research.Graph9822GlobalH2
open Research.Graph9822H2Check Research.Graph9822LiteH2.Hull
def knownCut (m : Nat) := (List.range 71).any (fun i => centerObstructions[i]! == m)
def lawfulHull (j : Nat) := witness[j]!.all knownCut
theorem actual_cut {m : Nat} (known : knownCut m=true)
    (ok : ∀ i : Fin 71,obstacle centerObstructions[i.val]! = true) : obstacle m=true := by
  obtain ⟨i,hi,eq⟩ := List.any_eq_true.mp known
  rw [←beq_iff_eq.mp eq]
  exact ok ⟨i,List.mem_range.mp hi⟩
end Research.Graph9822GlobalH2
