import H3GlobalBatchSingle2289822
import H3GlobalBatchSingle2299822
import H3GlobalBatchSingle2309822
import H3GlobalBatchSingle2319822
import H3GlobalBatchSingle2329822
import H3GlobalBatchSingle2339822
import H3GlobalBatchSingle2349822
import H3GlobalBatchSingle2359822
import H3GlobalBatchSingle2369822
import H3GlobalBatchSingle2379822
import H3GlobalBatchSingle2389822
import H3GlobalBatchSingle2399822
namespace Research.Graph9822Planes
def rootsPage228 : List Nat := (batchSingle228.map Prod.fst) ++ ((batchSingle229.map Prod.fst) ++ ((batchSingle230.map Prod.fst) ++ ((batchSingle231.map Prod.fst) ++ ((batchSingle232.map Prod.fst) ++ ((batchSingle233.map Prod.fst) ++ ((batchSingle234.map Prod.fst) ++ ((batchSingle235.map Prod.fst) ++ ((batchSingle236.map Prod.fst) ++ ((batchSingle237.map Prod.fst) ++ ((batchSingle238.map Prod.fst) ++ ((batchSingle239.map Prod.fst))))))))))))
theorem allPage228 : PaidKeys rootsPage228 := paid_append (page_paid paidBatchSingle228) (paid_append (page_paid paidBatchSingle229) (paid_append (page_paid paidBatchSingle230) (paid_append (page_paid paidBatchSingle231) (paid_append (page_paid paidBatchSingle232) (paid_append (page_paid paidBatchSingle233) (paid_append (page_paid paidBatchSingle234) (paid_append (page_paid paidBatchSingle235) (paid_append (page_paid paidBatchSingle236) (paid_append (page_paid paidBatchSingle237) (paid_append (page_paid paidBatchSingle238) (page_paid paidBatchSingle239)))))))))))
end Research.Graph9822Planes
