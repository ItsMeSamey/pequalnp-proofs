import SignedFourFiniteRows9822
namespace Research.SignedFactorFour
set_option maxRecDepth 12000
set_option maxHeartbeats 4000000
def r65 : Row := ([0,4,5,7], [1,6])
private theorem ok65 : rowGood r65=true := by decide +kernel
def r66 : Row := ([0,4,5,8], [1,6])
private theorem ok66 : rowGood r66=true := by decide +kernel
def r67 : Row := ([0,4,5,9], [1,7])
private theorem ok67 : rowGood r67=true := by decide +kernel
def r68 : Row := ([0,4,6,7], [1,8])
private theorem ok68 : rowGood r68=true := by decide +kernel
def r69 : Row := ([0,4,6,8], [2,7])
private theorem ok69 : rowGood r69=true := by decide +kernel
def page13 : List Row := [r65,r66,r67,r68,r69]
theorem paid13 : page13.all rowGood=true := by simp [page13,ok65,ok66,ok67,ok68,ok69]
end Research.SignedFactorFour
