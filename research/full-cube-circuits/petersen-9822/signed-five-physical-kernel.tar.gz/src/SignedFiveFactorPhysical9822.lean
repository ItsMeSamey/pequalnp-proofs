import SignedFourFactorLayout9822
import SignedChronologicalAxes9822
import SignedPhysicalBank9822
import SignedSixteenAtomPrice9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean
open Research.Graph9822Profiles Research.Graph9822Profiles.OuterLive Research.Graph9822Profiles.FactorFour
open Research.Graph9822Resolution (asCircuit independentSets)
theorem physical_scan_factor {pre post : List Gate} {g : Gate} {out rout : Nat} {gs : List DirGate}
    (basis : asCircuit gs rout=outerCircuit 10 pre post out)
    (cut : ComputesCut (innerValue pre g) (outerValue pre post out)) (pp : ∀ q∈pre,PositiveOp q)
    (cap : gs.countP Research.Graph9822Resolution.Gate.isAnd≤6)
    {bs lib : List Mask} {p : List (Axis × Mask)} {n : Nat} (scan : Scan bs lib p n)
    (short : p.length≤5) (budget : n≤6) (taps : ∀ a : Fin 11,{w | actualReceiver gs rout cap a.val w}∈lib) :
    ∃ (D : Finset V) (four : D.card=4) (six : Dᶜ.card=6),
      Model4 (D.orderEmbOfFin four) (Dᶜ.orderEmbOfFin six) := by
  classical
  obtain ⟨row,_,obs⟩ := sixteen_room gs rout cap (auxBit pre g)
    (auxBit_antitone pp g) (fun xs h => onSet_outer_eval basis cut xs h)
  let R (v : V) : Mask := {w | actualReceiver gs rout cap v.val w}
  have inLib (v : V) : R v∈lib := taps ⟨v.val,by omega⟩
  obtain ⟨proper,anti,ri,co⟩ := seen_bounds R row obs
  let D := Finset.univ.filter (fun v : V => R v∈bs)
  have dm (v) : v∈D ↔ R v∈bs := by simp [D]
  have low : 4≤D.card := by
    obtain ⟨ps,len,orig⟩ := SixteenAtom.paid_registers scan
    have cnt : Dᶜ.card ≤ ps.toFinset.card := by
      apply Finset.card_le_card_of_injOn R
      · intro v hv
        rcases orig _ (inLib v) with full|direct|paid
        · exact False.elim (proper v full)
        · exact False.elim (Finset.mem_compl.mp hv ((dm v).mpr direct))
        · exact List.mem_toFinset.mpr paid
      · exact ri.injOn
    rw [Finset.card_compl] at cnt
    have small := ps.toFinset_card_le
    change 10-D.card≤ps.toFinset.card at cnt
    omega
  have high : ¬5≤D.card := by
    intro h
    obtain ⟨E,sub,count⟩ := Finset.exists_subset_card_eq h
    have cheap (v) (hv : v∈E) : R v∈bs := (dm v).mp (sub hv)
    obtain ⟨ax,sg,owned,sat⟩ := saturate_five scan short E count R cheap ri co
    exact five_occupied_false basis cut pp cap scan taps E count ax sg owned sat
  have four : D.card=4 := by omega
  have six : Dᶜ.card=6 := by rw [Finset.card_compl,four];decide
  refine ⟨D,four,six,scan_layout scan short budget R inLib row obs
    (D.orderEmbOfFin four) (D.orderEmbOfFin four).injective ?_
    (Dᶜ.orderEmbOfFin six) (Dᶜ.orderEmbOfFin six).injective ?_⟩
  · exact fun i => (dm _).mp (D.orderEmbOfFin_mem four i)
  · intro i h
    exact Finset.mem_compl.mp (Dᶜ.orderEmbOfFin_mem six i) ((dm _).mpr h)
theorem physical_five_factor {pre post : List Gate} {g : Gate} {out : Nat}
    (minimal : Reduced 10 (pre++g::post) out)
    (nc : ∃ x y : Input, vl (pre++g::post) x out ≠ vl (pre++g::post) y out)
    (pp : ∀ q∈pre,PositiveOp q) (pt : ∀ q∈post,PositiveOp q)
    (cut : ComputesCut (innerValue pre g) (outerValue pre post out))
    (size : pre.length+post.length≤16) (bound : out<10+(pre++g::post).length)
    (five : ((outerCircuit 10 pre post out).gates.map readDir).countP Research.Graph9822Resolution.Gate.isAnd≤5) :
    ∃ (D : Finset V) (four : D.card=4) (six : Dᶜ.card=6),
      Model4 (D.orderEmbOfFin four) (Dᶜ.orderEmbOfFin six) := by
  let C := outerCircuit 10 pre post out
  let gs := C.gates.map readDir
  have cap : gs.countP Research.Graph9822Resolution.Gate.isAnd≤6 := five.trans (by decide)
  let axis := switchAxis (switchAddrs gs 11) ((switchAddrs_length gs 11).trans_le cap)
  let es := gateEvents axis gs 11 ++ rawEvents 11
  let s := es.foldl paddedStep (initial C.output)
  have same : asCircuit gs C.output = C := physical_outer_basis minimal.clean pp pt
  have ess := all_eleven_wire_witnesses same minimal nc pp cut
  have live : ∀ j < 11,(back axis gs 11 (initial C.output)).q j ≠ [] := by
    intro j hj
    obtain ⟨u,v,off,hit⟩ := ess j hj
    exact back_essential axis gs 11 C.output j u v off hit
  obtain ⟨good,tags,recs,price⟩ := signed_padded_bank gs 11 C.output _ live
  obtain ⟨lib,scan,_,inlib⟩ := good
  apply physical_scan_factor same cut pp cap scan
  · have eq := congrArg List.length tags
    simp only [List.length_map,List.length_reverse,List.length_range] at eq
    exact eq.le.trans five
  · exact price.trans_le (actual_six_join_profile axis minimal nc pp pt cut size bound).2
  · intro a
    apply inlib
    rw [recs]
    apply List.mem_map.mpr
    exact ⟨a.val,List.mem_range.mpr a.isLt,by
      ext w
      exact (back_receiver_exact axis w gs 11 a.val C.output a.isLt).symm⟩
end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.DirectCube.physical_five_factor
