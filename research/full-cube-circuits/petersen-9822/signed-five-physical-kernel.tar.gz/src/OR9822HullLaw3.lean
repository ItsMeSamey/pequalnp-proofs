import OR9822HullLegal
namespace Research.Graph9822GlobalH2
set_option maxRecDepth 20000 in
set_option maxHeartbeats 7000000 in
theorem hullLaw3 : (List.range' 48 16).all lawfulHull=true := by decide +kernel
end Research.Graph9822GlobalH2
