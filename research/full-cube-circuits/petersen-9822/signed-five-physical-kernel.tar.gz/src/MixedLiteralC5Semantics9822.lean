import MixedLiteralC5Eval9822
namespace Research.LiteralC5
open FreeAndNet
inductive Slots : Nat → Nat → Type where
  | out {n} (s : Fin n → Bool) : Slots n 0
  | gate {n k} (a b : Fin n → Bool) (tail : Slots (n+1) k) : Slots n (k+1)
def Slots.run {n k} (p : Slots n k) (v : Fin n → Bool) : Bool :=
  match p with
  | .out s => prod s v
  | .gate a b t => t.run (step a b v)
def select {α : Type} {n : Nat} (enc : α → Fin n) (a : List α) (i : Fin n) :=
  decide (i∈a.map enc)
theorem select_prod {α : Type} {n : Nat} (enc : α → Fin n) (a : List α) (v : Fin n → Bool) :
    prod (select enc a) v = a.all (fun j => v (enc j)) := by
  apply Bool.eq_iff_iff.mpr
  simp only [prod,List.all_eq_true]
  constructor
  · intro h j mem
    have on := h (enc j) (by simp)
    have yes : enc j ∈ a.map enc := List.mem_map.mpr ⟨j,mem,rfl⟩
    simpa [select,yes] using on
  · intro h i _
    by_cases mem : i∈a.map enc
    · obtain ⟨j,hj,rfl⟩ := List.mem_map.mp mem
      simp [select,mem,h j hj]
    · simp [select,mem]
def nextEnc {α : Type} {n : Nat} (enc : α → Fin n) : Option α → Fin (n+1)
  | none => Fin.last n
  | some j => (enc j).castSucc
theorem next_values {α : Type} {n : Nat} (enc : α → Fin n) (a b : List α) (v : Fin n → Bool) (j : Option α) :
    step (select enc a) (select enc b) v (nextEnc enc j) =
      j.elim (a.all (fun i => v (enc i)) || b.all (fun i => v (enc i))) (fun i => v (enc i)) := by
  cases j <;> simp [step,nextEnc,select_prod]
theorem padded_output {α : Type} {n : Nat} (enc : α → Fin n) (k : Nat) (a : List α) :
    ∃ p : Slots n k, ∀ v, p.run v = a.all (fun i => v (enc i)) := by
  induction k generalizing n with
  | zero =>
    refine ⟨.out (select enc a),?_⟩
    intro v; change prod (select enc a) v = _; exact select_prod enc a v
  | succ k ih =>
    obtain ⟨p,ev⟩ := ih (fun j => (enc j).castSucc)
    refine ⟨.gate (fun _ => false) (fun _ => false) p,fun v => ?_⟩
    rw [Slots.run,ev]
    simp [step]
theorem encode_slots {α : Type} {n : Nat} (k : Nat) (t : Net α) (enc : α → Fin n)
    (bound : t.cost ≤ k) (hot : ∃ x, t.eval x=true) :
    ∃ p : Slots n k, ∀ v, p.run v = t.eval (fun i => v (enc i)) := by
  induction k generalizing α n with
  | zero =>
    cases t with
    | out a =>
      cases a with
      | none => obtain ⟨x,h⟩ := hot; cases h
      | some a => exact padded_output enc 0 a
    | gate a b t => simp [Net.cost] at bound
  | succ k ih =>
    cases t with
    | out a =>
      cases a with
      | none => obtain ⟨x,h⟩ := hot; cases h
      | some a => exact padded_output enc (k+1) a
    | gate a b t =>
      obtain ⟨v,hv⟩ := hot
      have tailHot : ∃ y,t.eval y=true := ⟨_,hv⟩
      obtain ⟨p,eval⟩ := ih t (nextEnc enc) (by simpa [Net.cost] using bound) tailHot
      refine ⟨.gate (select enc a) (select enc b) p,fun v => ?_⟩
      rw [Slots.run,eval,Net.eval]
      apply congrArg (fun y => t.eval y)
      funext j; exact next_values enc a b v j
theorem semantic_three (t : Net (Fin 6)) (fit : ∀ x, t.eval (lift x) = cycle x)
    (small : t.cost≤3) :
    ∃ a b c d e f g, ∀ x, eval3 a b c d e f g x=cycle x := by
  have h : t.eval (lift (fun _ => true))=true := (fit _).trans (by decide +kernel)
  obtain ⟨p,ev⟩ := encode_slots 3 t id small ⟨_,h⟩
  cases p with | gate a b t1 =>
   cases t1 with | gate c d t2 =>
    cases t2 with | gate e f t3 =>
     cases t3 with | out g =>
      exact ⟨a,b,c,d,e,f,g,fun x => (ev (lift x)).trans (fit x)⟩
end Research.LiteralC5
#print axioms Research.LiteralC5.semantic_three
