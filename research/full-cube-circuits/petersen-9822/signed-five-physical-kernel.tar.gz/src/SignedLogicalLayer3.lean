import SignedScans
import SignedLogicalLayer2

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_48_012 : ¬ Placement [0, 1, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_12
    · exact node_49_12
theorem node_48_021 : ¬ Placement [0, 2, 1] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_21
    · exact node_49_21
theorem node_48_102 : ¬ Placement [1, 0, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_1_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_02
    · exact node_49_02
theorem node_272_012 : ¬ Placement [0, 1, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_12
    · exact node_280_12
theorem node_272_021 : ¬ Placement [0, 2, 1] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_21
    · exact node_280_21
theorem node_272_102 : ¬ Placement [1, 0, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_1_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_02
    · exact node_280_02
theorem node_288_012 : ¬ Placement [0, 1, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_12
theorem node_288_021 : ¬ Placement [0, 2, 1] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_21
theorem node_288_102 : ¬ Placement [1, 0, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_1_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_02
theorem node_304_012 : ¬ Placement [0, 1, 2] 304 := by
  apply node_sound (lookup := frozen) (next := [304, 305, 312, 313])
  · exact scan_0_304
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl
    · exact node_304_12
    · exact node_305_12
    · exact node_312_12
    · exact node_313_12
theorem node_304_021 : ¬ Placement [0, 2, 1] 304 := by
  apply node_sound (lookup := frozen) (next := [304, 305, 312, 313])
  · exact scan_0_304
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl
    · exact node_304_21
    · exact node_305_21
    · exact node_312_21
    · exact node_313_21
theorem node_304_102 : ¬ Placement [1, 0, 2] 304 := by
  apply node_sound (lookup := frozen) (next := [304, 305, 312, 313])
  · exact scan_1_304
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl
    · exact node_304_02
    · exact node_305_02
    · exact node_312_02
    · exact node_313_02
theorem node_48_123 : ¬ Placement [1, 2, 3] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_1_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_23
    · exact node_49_23
theorem node_49_123 : ¬ Placement [1, 2, 3] 49 := by
  apply node_sound (lookup := frozen) (next := [49])
  · exact scan_1_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_49_23
theorem node_48_132 : ¬ Placement [1, 3, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_1_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_32
    · exact node_49_32
theorem node_49_132 : ¬ Placement [1, 3, 2] 49 := by
  apply node_sound (lookup := frozen) (next := [49])
  · exact scan_1_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_49_32
theorem node_48_213 : ¬ Placement [2, 1, 3] 48 := by
  apply node_sound (lookup := frozen) (next := [50])
  · exact scan_2_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_50_13
theorem node_49_213 : ¬ Placement [2, 1, 3] 49 := by
  apply node_sound (lookup := frozen) (next := [51])
  · exact scan_2_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_51_13
theorem node_48_231 : ¬ Placement [2, 3, 1] 48 := by
  apply node_sound (lookup := frozen) (next := [50])
  · exact scan_2_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_50_31
theorem node_49_231 : ¬ Placement [2, 3, 1] 49 := by
  apply node_sound (lookup := frozen) (next := [51])
  · exact scan_2_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_51_31
theorem node_48_312 : ¬ Placement [3, 1, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49, 56, 57, 112, 176, 304, 560])
  · exact scan_3_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_48_12
    · exact node_49_12
    · exact node_56_12
    · exact node_57_12
    · exact node_112_12
    · exact node_176_12
    · exact node_304_12
    · exact node_560_12
theorem node_49_312 : ¬ Placement [3, 1, 2] 49 := by
  apply node_sound (lookup := frozen) (next := [49, 57, 113, 177, 305, 561])
  · exact scan_3_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_49_12
    · exact node_57_12
    · exact node_113_12
    · exact node_177_12
    · exact node_305_12
    · exact node_561_12
theorem node_48_321 : ¬ Placement [3, 2, 1] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49, 56, 57, 112, 176, 304, 560])
  · exact scan_3_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_48_21
    · exact node_49_21
    · exact node_56_21
    · exact node_57_21
    · exact node_112_21
    · exact node_176_21
    · exact node_304_21
    · exact node_560_21
theorem node_49_321 : ¬ Placement [3, 2, 1] 49 := by
  apply node_sound (lookup := frozen) (next := [49, 57, 113, 177, 305, 561])
  · exact scan_3_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_49_21
    · exact node_57_21
    · exact node_113_21
    · exact node_177_21
    · exact node_305_21
    · exact node_561_21
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_48_023 : ¬ Placement [0, 2, 3] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_23
    · exact node_49_23
theorem node_49_023 : ¬ Placement [0, 2, 3] 49 := by
  apply node_sound (lookup := frozen) (next := [49])
  · exact scan_0_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_49_23
theorem node_48_032 : ¬ Placement [0, 3, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_32
    · exact node_49_32
theorem node_49_032 : ¬ Placement [0, 3, 2] 49 := by
  apply node_sound (lookup := frozen) (next := [49])
  · exact scan_0_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_49_32
theorem node_48_302 : ¬ Placement [3, 0, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49, 56, 57, 112, 176, 304, 560])
  · exact scan_3_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_48_02
    · exact node_49_02
    · exact node_56_02
    · exact node_57_02
    · exact node_112_02
    · exact node_176_02
    · exact node_304_02
    · exact node_560_02
theorem node_49_302 : ¬ Placement [3, 0, 2] 49 := by
  apply node_sound (lookup := frozen) (next := [49, 57, 113, 177, 305, 561])
  · exact scan_3_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_49_02
    · exact node_57_02
    · exact node_113_02
    · exact node_177_02
    · exact node_305_02
    · exact node_561_02
theorem node_49_012 : ¬ Placement [0, 1, 2] 49 := by
  apply node_sound (lookup := frozen) (next := [49])
  · exact scan_0_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_49_12
theorem node_56_012 : ¬ Placement [0, 1, 2] 56 := by
  apply node_sound (lookup := frozen) (next := [56, 57])
  · exact scan_0_56
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_56_12
    · exact node_57_12
theorem node_57_012 : ¬ Placement [0, 1, 2] 57 := by
  apply node_sound (lookup := frozen) (next := [57])
  · exact scan_0_57
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_57_12
theorem node_112_012 : ¬ Placement [0, 1, 2] 112 := by
  apply node_sound (lookup := frozen) (next := [112, 113])
  · exact scan_0_112
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_112_12
    · exact node_113_12
theorem node_176_012 : ¬ Placement [0, 1, 2] 176 := by
  apply node_sound (lookup := frozen) (next := [176, 177])
  · exact scan_0_176
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_176_12
    · exact node_177_12
theorem node_560_012 : ¬ Placement [0, 1, 2] 560 := by
  apply node_sound (lookup := frozen) (next := [560, 561])
  · exact scan_0_560
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_560_12
    · exact node_561_12
theorem node_49_021 : ¬ Placement [0, 2, 1] 49 := by
  apply node_sound (lookup := frozen) (next := [49])
  · exact scan_0_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_49_21
theorem node_56_021 : ¬ Placement [0, 2, 1] 56 := by
  apply node_sound (lookup := frozen) (next := [56, 57])
  · exact scan_0_56
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_56_21
    · exact node_57_21
theorem node_57_021 : ¬ Placement [0, 2, 1] 57 := by
  apply node_sound (lookup := frozen) (next := [57])
  · exact scan_0_57
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_57_21
theorem node_112_021 : ¬ Placement [0, 2, 1] 112 := by
  apply node_sound (lookup := frozen) (next := [112, 113])
  · exact scan_0_112
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_112_21
    · exact node_113_21
theorem node_176_021 : ¬ Placement [0, 2, 1] 176 := by
  apply node_sound (lookup := frozen) (next := [176, 177])
  · exact scan_0_176
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_176_21
    · exact node_177_21
theorem node_560_021 : ¬ Placement [0, 2, 1] 560 := by
  apply node_sound (lookup := frozen) (next := [560, 561])
  · exact scan_0_560
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_560_21
    · exact node_561_21
theorem node_49_102 : ¬ Placement [1, 0, 2] 49 := by
  apply node_sound (lookup := frozen) (next := [49])
  · exact scan_1_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_49_02
theorem node_56_102 : ¬ Placement [1, 0, 2] 56 := by
  apply node_sound (lookup := frozen) (next := [56, 57])
  · exact scan_1_56
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_56_02
    · exact node_57_02
theorem node_57_102 : ¬ Placement [1, 0, 2] 57 := by
  apply node_sound (lookup := frozen) (next := [57])
  · exact scan_1_57
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_57_02
theorem node_112_102 : ¬ Placement [1, 0, 2] 112 := by
  apply node_sound (lookup := frozen) (next := [112, 113])
  · exact scan_1_112
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_112_02
    · exact node_113_02
theorem node_176_102 : ¬ Placement [1, 0, 2] 176 := by
  apply node_sound (lookup := frozen) (next := [176, 177])
  · exact scan_1_176
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_176_02
    · exact node_177_02
theorem node_560_102 : ¬ Placement [1, 0, 2] 560 := by
  apply node_sound (lookup := frozen) (next := [560, 561])
  · exact scan_1_560
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_560_02
    · exact node_561_02
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_272_123 : ¬ Placement [1, 2, 3] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_1_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_23
    · exact node_280_23
theorem node_280_123 : ¬ Placement [1, 2, 3] 280 := by
  apply node_sound (lookup := frozen) (next := [280])
  · exact scan_1_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_280_23
theorem node_272_132 : ¬ Placement [1, 3, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_1_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_32
    · exact node_280_32
theorem node_280_132 : ¬ Placement [1, 3, 2] 280 := by
  apply node_sound (lookup := frozen) (next := [280])
  · exact scan_1_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_280_32
theorem node_272_213 : ¬ Placement [2, 1, 3] 272 := by
  apply node_sound (lookup := frozen) (next := [274])
  · exact scan_2_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_274_13
theorem node_280_213 : ¬ Placement [2, 1, 3] 280 := by
  apply node_sound (lookup := frozen) (next := [282])
  · exact scan_2_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_282_13
theorem node_272_231 : ¬ Placement [2, 3, 1] 272 := by
  apply node_sound (lookup := frozen) (next := [274])
  · exact scan_2_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_274_31
theorem node_280_231 : ¬ Placement [2, 3, 1] 280 := by
  apply node_sound (lookup := frozen) (next := [282])
  · exact scan_2_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_282_31
theorem node_272_312 : ¬ Placement [3, 1, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 273, 280, 281, 304, 336, 400, 784])
  · exact scan_3_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_272_12
    · exact node_273_12
    · exact node_280_12
    · exact node_281_12
    · exact node_304_12
    · exact node_336_12
    · exact node_400_12
    · exact node_784_12
theorem node_280_312 : ¬ Placement [3, 1, 2] 280 := by
  apply node_sound (lookup := frozen) (next := [280, 281, 312, 344, 408, 792])
  · exact scan_3_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_280_12
    · exact node_281_12
    · exact node_312_12
    · exact node_344_12
    · exact node_408_12
    · exact node_792_12
theorem node_272_321 : ¬ Placement [3, 2, 1] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 273, 280, 281, 304, 336, 400, 784])
  · exact scan_3_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_272_21
    · exact node_273_21
    · exact node_280_21
    · exact node_281_21
    · exact node_304_21
    · exact node_336_21
    · exact node_400_21
    · exact node_784_21
theorem node_280_321 : ¬ Placement [3, 2, 1] 280 := by
  apply node_sound (lookup := frozen) (next := [280, 281, 312, 344, 408, 792])
  · exact scan_3_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_280_21
    · exact node_281_21
    · exact node_312_21
    · exact node_344_21
    · exact node_408_21
    · exact node_792_21
theorem node_272_023 : ¬ Placement [0, 2, 3] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_23
    · exact node_280_23
theorem node_280_023 : ¬ Placement [0, 2, 3] 280 := by
  apply node_sound (lookup := frozen) (next := [280])
  · exact scan_0_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_280_23
theorem node_272_032 : ¬ Placement [0, 3, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_32
    · exact node_280_32
theorem node_280_032 : ¬ Placement [0, 3, 2] 280 := by
  apply node_sound (lookup := frozen) (next := [280])
  · exact scan_0_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_280_32
theorem node_272_302 : ¬ Placement [3, 0, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 273, 280, 281, 304, 336, 400, 784])
  · exact scan_3_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_272_02
    · exact node_273_02
    · exact node_280_02
    · exact node_281_02
    · exact node_304_02
    · exact node_336_02
    · exact node_400_02
    · exact node_784_02
theorem node_280_302 : ¬ Placement [3, 0, 2] 280 := by
  apply node_sound (lookup := frozen) (next := [280, 281, 312, 344, 408, 792])
  · exact scan_3_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_280_02
    · exact node_281_02
    · exact node_312_02
    · exact node_344_02
    · exact node_408_02
    · exact node_792_02
theorem node_273_012 : ¬ Placement [0, 1, 2] 273 := by
  apply node_sound (lookup := frozen) (next := [273, 281])
  · exact scan_0_273
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_273_12
    · exact node_281_12
theorem node_280_012 : ¬ Placement [0, 1, 2] 280 := by
  apply node_sound (lookup := frozen) (next := [280])
  · exact scan_0_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_280_12
theorem node_281_012 : ¬ Placement [0, 1, 2] 281 := by
  apply node_sound (lookup := frozen) (next := [281])
  · exact scan_0_281
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_281_12
theorem node_336_012 : ¬ Placement [0, 1, 2] 336 := by
  apply node_sound (lookup := frozen) (next := [336, 344])
  · exact scan_0_336
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_336_12
    · exact node_344_12
theorem node_400_012 : ¬ Placement [0, 1, 2] 400 := by
  apply node_sound (lookup := frozen) (next := [400, 408])
  · exact scan_0_400
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_400_12
    · exact node_408_12
theorem node_784_012 : ¬ Placement [0, 1, 2] 784 := by
  apply node_sound (lookup := frozen) (next := [784, 792])
  · exact scan_0_784
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_784_12
    · exact node_792_12
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_273_021 : ¬ Placement [0, 2, 1] 273 := by
  apply node_sound (lookup := frozen) (next := [273, 281])
  · exact scan_0_273
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_273_21
    · exact node_281_21
theorem node_280_021 : ¬ Placement [0, 2, 1] 280 := by
  apply node_sound (lookup := frozen) (next := [280])
  · exact scan_0_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_280_21
theorem node_281_021 : ¬ Placement [0, 2, 1] 281 := by
  apply node_sound (lookup := frozen) (next := [281])
  · exact scan_0_281
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_281_21
theorem node_336_021 : ¬ Placement [0, 2, 1] 336 := by
  apply node_sound (lookup := frozen) (next := [336, 344])
  · exact scan_0_336
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_336_21
    · exact node_344_21
theorem node_400_021 : ¬ Placement [0, 2, 1] 400 := by
  apply node_sound (lookup := frozen) (next := [400, 408])
  · exact scan_0_400
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_400_21
    · exact node_408_21
theorem node_784_021 : ¬ Placement [0, 2, 1] 784 := by
  apply node_sound (lookup := frozen) (next := [784, 792])
  · exact scan_0_784
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_784_21
    · exact node_792_21
theorem node_273_102 : ¬ Placement [1, 0, 2] 273 := by
  apply node_sound (lookup := frozen) (next := [273, 281])
  · exact scan_1_273
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_273_02
    · exact node_281_02
theorem node_280_102 : ¬ Placement [1, 0, 2] 280 := by
  apply node_sound (lookup := frozen) (next := [280])
  · exact scan_1_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_280_02
theorem node_281_102 : ¬ Placement [1, 0, 2] 281 := by
  apply node_sound (lookup := frozen) (next := [281])
  · exact scan_1_281
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_281_02
theorem node_336_102 : ¬ Placement [1, 0, 2] 336 := by
  apply node_sound (lookup := frozen) (next := [336, 344])
  · exact scan_1_336
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_336_02
    · exact node_344_02
theorem node_400_102 : ¬ Placement [1, 0, 2] 400 := by
  apply node_sound (lookup := frozen) (next := [400, 408])
  · exact scan_1_400
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_400_02
    · exact node_408_02
theorem node_784_102 : ¬ Placement [1, 0, 2] 784 := by
  apply node_sound (lookup := frozen) (next := [784, 792])
  · exact scan_1_784
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_784_02
    · exact node_792_02
theorem node_288_123 : ¬ Placement [1, 2, 3] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_1_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_23
theorem node_288_132 : ¬ Placement [1, 3, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_1_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_32
theorem node_288_213 : ¬ Placement [2, 1, 3] 288 := by
  apply node_sound (lookup := frozen) (next := [290])
  · exact scan_2_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_290_13
theorem node_288_231 : ¬ Placement [2, 3, 1] 288 := by
  apply node_sound (lookup := frozen) (next := [290])
  · exact scan_2_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_290_31
theorem node_288_312 : ¬ Placement [3, 1, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288, 289, 296, 304, 352, 416, 800])
  · exact scan_3_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_288_12
    · exact node_289_12
    · exact node_296_12
    · exact node_304_12
    · exact node_352_12
    · exact node_416_12
    · exact node_800_12
theorem node_288_321 : ¬ Placement [3, 2, 1] 288 := by
  apply node_sound (lookup := frozen) (next := [288, 289, 296, 304, 352, 416, 800])
  · exact scan_3_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_288_21
    · exact node_289_21
    · exact node_296_21
    · exact node_304_21
    · exact node_352_21
    · exact node_416_21
    · exact node_800_21
theorem node_288_023 : ¬ Placement [0, 2, 3] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_23
theorem node_288_032 : ¬ Placement [0, 3, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_32
theorem node_288_302 : ¬ Placement [3, 0, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288, 289, 296, 304, 352, 416, 800])
  · exact scan_3_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_288_02
    · exact node_289_02
    · exact node_296_02
    · exact node_304_02
    · exact node_352_02
    · exact node_416_02
    · exact node_800_02
theorem node_289_012 : ¬ Placement [0, 1, 2] 289 := by
  apply node_sound (lookup := frozen) (next := [289])
  · exact scan_0_289
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_289_12
theorem node_296_012 : ¬ Placement [0, 1, 2] 296 := by
  apply node_sound (lookup := frozen) (next := [296])
  · exact scan_0_296
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_296_12
theorem node_352_012 : ¬ Placement [0, 1, 2] 352 := by
  apply node_sound (lookup := frozen) (next := [352])
  · exact scan_0_352
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_352_12
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_416_012 : ¬ Placement [0, 1, 2] 416 := by
  apply node_sound (lookup := frozen) (next := [416])
  · exact scan_0_416
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_416_12
theorem node_800_012 : ¬ Placement [0, 1, 2] 800 := by
  apply node_sound (lookup := frozen) (next := [800])
  · exact scan_0_800
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_800_12
theorem node_289_021 : ¬ Placement [0, 2, 1] 289 := by
  apply node_sound (lookup := frozen) (next := [289])
  · exact scan_0_289
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_289_21
theorem node_296_021 : ¬ Placement [0, 2, 1] 296 := by
  apply node_sound (lookup := frozen) (next := [296])
  · exact scan_0_296
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_296_21
theorem node_352_021 : ¬ Placement [0, 2, 1] 352 := by
  apply node_sound (lookup := frozen) (next := [352])
  · exact scan_0_352
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_352_21
theorem node_416_021 : ¬ Placement [0, 2, 1] 416 := by
  apply node_sound (lookup := frozen) (next := [416])
  · exact scan_0_416
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_416_21
theorem node_800_021 : ¬ Placement [0, 2, 1] 800 := by
  apply node_sound (lookup := frozen) (next := [800])
  · exact scan_0_800
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_800_21
theorem node_289_102 : ¬ Placement [1, 0, 2] 289 := by
  apply node_sound (lookup := frozen) (next := [289])
  · exact scan_1_289
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_289_02
theorem node_296_102 : ¬ Placement [1, 0, 2] 296 := by
  apply node_sound (lookup := frozen) (next := [296])
  · exact scan_1_296
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_296_02
theorem node_352_102 : ¬ Placement [1, 0, 2] 352 := by
  apply node_sound (lookup := frozen) (next := [352])
  · exact scan_1_352
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_352_02
theorem node_416_102 : ¬ Placement [1, 0, 2] 416 := by
  apply node_sound (lookup := frozen) (next := [416])
  · exact scan_1_416
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_416_02
theorem node_800_102 : ¬ Placement [1, 0, 2] 800 := by
  apply node_sound (lookup := frozen) (next := [800])
  · exact scan_1_800
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_800_02
end Petersen9822
