import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle316 : List ModeRow := [(492963345,[60184,8935,22961,11079,51322,6835,26679,59697,5105,41875],[60184,8935,51322,10471])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle316 : batchSingle316.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
