import H3SinglePage2889822
import H3GlobalRootIndex9822
namespace Research.Graph9822Planes
theorem frozenPaid288 : PaidKeys frozen288 := by
  have e : rootsPage288 = frozen288 := by decide +kernel
  rw [← e]
  exact allPage288
end Research.Graph9822Planes
