import MixedLiteralC5Defs9822
namespace Research.LiteralC5

def prod {n : Nat} (s v : Fin n → Bool) :=
  (List.finRange n).all fun i => !(s i) || v i

def step {n : Nat} (a b v : Fin n → Bool) : Fin (n+1) → Bool :=
  Fin.lastCases (prod a v || prod b v) v

def eval3 (a b : Fin 6 → Bool) (c d : Fin 7 → Bool) (e f : Fin 8 → Bool)
    (g : Fin 9 → Bool) (x : Fin 5 → Bool) :=
  prod g (step e f (step c d (step a b (lift x))))

end Research.LiteralC5
