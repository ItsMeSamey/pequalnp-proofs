import H3SinglePage1689822
import H3GlobalRootIndex9822
namespace Research.Graph9822Planes
theorem frozenPaid168 : PaidKeys frozen168 := by
  have e : rootsPage168 = frozen168 := by decide +kernel
  rw [← e]
  exact allPage168
end Research.Graph9822Planes
