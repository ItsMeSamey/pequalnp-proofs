import MixedReaderCircuit9822
import AcceptedHighSpread9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity SignedClamp NonrawSupport
open PEqualNP.Outside.L_meta_9822.Clean
theorem patched_nine {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (v d : Nat) (hd : d≤v) (hot : Nat → Bool)
    (allAnd : ∀q∈C.gates,v∈q.inputs → q.op=.and)
    (agree : ∀x : Input,∀j,hot j=true → vl C.gates x j=true → vl C.gates x v=vl C.gates x d) :
    let f := MixedReaderPatch.gate v d hot
    outerValue (pre.map f) (post.map f) C.output (SignedClamp.singleton 9) true=true := by
  let f := MixedReaderPatch.gate v d hot
  let T : Circuit := ⟨C.gates.map f,C.output⟩
  have cl : CleanL 10 T.gates := MixedReaderPatch.clean_list red.clean hd hot
  have eval (x : Input) : vl T.gates x C.output=vl C.gates x C.output :=
    MixedReaderPatch.actual_vl red.clean hd hot x allAnd (agree x) _
  have size : T.gates.length=C.gates.length := List.length_map _
  have rep : Candidate T := ⟨fun q h => (clean_nok _ _ cl q h).1,size.le.trans cand.2.1,
    fun x => (eval x).trans (cand.2.2 x)⟩
  have mr := (red.retimed cl size.le eval (by
    refine ⟨fun _ => false,fun _ => true,?_⟩
    have eq : ∀x : Input,vl C.gates x C.output=edge x := cand.2.2
    rw [eq,eq];decide +kernel)).1
  have nr : Roster T (pre.map f) (post.map f) (f g) := ⟨by simp [T,r.split],r.inv,by
    intro q h
    rw [←List.map_append] at h
    obtain ⟨a,mem,rfl⟩ := List.mem_map.mp h
    exact r.pos a mem⟩
  have count : T.gates.countP countsAnd=7 := by
    change (C.gates.map f).countP countsAnd=7
    rw [List.countP_map,show countsAnd ∘ f=countsAnd by funext q; rfl]
    exact seven
  exact (full_upper_nine nr rep mr count).1
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
