import CutGroupRows
import CutGroupRoom

namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open PEqualNP.CircuitLowerBounds
open PEqualNP.Outside.L_meta_9822.Clean (outerCircuit)
open PEqualNP.Outside.L_meta_9822.OuterDirections
open Research.Graph9822Profiles Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution (asCircuit onSet)

abbrev actualReceiver (gs : List DirGate) (rout : Nat)
    (cap : gs.countP Research.Graph9822Resolution.Gate.isAnd ≤ 6) (a : Nat) (w : Word) : Prop :=
  w ∈ collect ((back (switchAxis (switchAddrs gs 11) ((switchAddrs_length gs 11).trans_le cap))
    gs 11 (initial rout)).q a)

theorem auxAntitoneSubset {pre : List Gate} (positive : ∀ q ∈ pre, PositiveOp q)
    (g : Gate) {xs ys : List Nat} (subset : ∀ a ∈ xs, a ∈ ys) :
    auxBit pre g ys = true → auxBit pre g xs = true := by
  have le : ∀ i, setRow xs i = true → setRow ys i = true := by
    intro i hi
    simp only [setRow,decide_eq_true_eq] at hi ⊢
    exact subset _ hi
  have mono := inner_mono_inputs positive g le
  unfold auxBit
  cases h1 : innerValue pre g (setRow xs) <;> cases h2 : innerValue pre g (setRow ys) <;> simp_all

structure CatalogueRows (R : Nat → Word → Prop) (aux : List Nat → Bool) : Prop where
  edge : ∀ u v : Fin 10, onSet [u.val,v.val] = true →
    ∀ w, R u.val w ∨ R v.val w ∨ R 10 w
  hotEdge : ∀ u v : Fin 10, onSet [u.val,v.val] = true →
    (∀ w, R v.val w ∨ R 10 w) → aux [v.val] = false ∧
      ∀ w, R u.val w ∨ R v.val w
  missingPositive : ∀ S : List Nat, (∀ a ∈ S, a < 10) → onSet S = true →
    ∀ w, (∀ a ∈ S, ¬ R a w) →
      (aux S = true ∧ R 10 w) ∧ ∀ A : List Nat, (∀ a ∈ A, a ∈ S) →
        onSet A = false → ∃ t, ¬ R 10 t ∧ ∀ a ∈ A, ¬ R a t

/-- The masks are read directly out of the reverse traversal of the actual
    cut circuit; address 10 is the original inverter's auxiliary input. -/
theorem physicalCatalogueRows {pre post : List Gate} {g : Gate} {out rout : Nat}
    {gs : List DirGate} (same : asCircuit gs rout = outerCircuit 10 pre post out)
    (cut : ComputesCut (innerValue pre g) (outerValue pre post out))
    (positive : ∀ q ∈ pre, PositiveOp q)
    (cap : gs.countP Research.Graph9822Resolution.Gate.isAnd ≤ 6) :
    CatalogueRows (actualReceiver gs rout cap) (auxBit pre g) := by
  classical
  let R := actualReceiver gs rout cap
  have row (xs : List Nat) (sm : ∀ a ∈ xs, a < 10) :
      onSet xs = true ↔ ∀ w, (∃ a ∈ xs, R a w) ∨ (auxBit pre g xs = true ∧ R 10 w) :=
    actual_signed_guard_row gs rout cap xs sm _ (onSet_outer_eval same cut xs sm)
  have pairSmall (u v : Fin 10) : ∀ a ∈ [u.val,v.val], a < 10 := by
    intro a h
    rcases (by simpa using h : a=u.val ∨ a=v.val) with rfl | rfl
    · exact u.isLt
    · exact v.isLt
  have split (u v : Fin 10) (w : Word)
      (h : ∃ a ∈ [u.val,v.val], R a w) : R u.val w ∨ R v.val w := by
    obtain ⟨a,ha,h⟩ := h
    rcases (by simpa using ha : a=u.val ∨ a=v.val) with rfl | rfl
    · exact Or.inl h
    · exact Or.inr h
  constructor
  · intro u v adjacent w
    rcases (row _ (pairSmall u v)).mp adjacent w with raw | z
    · exact (split u v w raw).elim Or.inl (fun h => Or.inr (Or.inl h))
    · exact Or.inr (Or.inr z.2)
  · intro u v adjacent cover
    have single : auxBit pre g [v.val] = false := by
      by_contra! yes
      have z : auxBit pre g [v.val] = true := by cases h : auxBit pre g [v.val] <;> simp_all
      have impossible := (row [v.val] (by simpa using v.isLt)).mpr (by
        intro w
        rcases cover w with raw | guard
        · exact Or.inl ⟨v.val,by simp,raw⟩
        · exact Or.inr ⟨z,guard⟩)
      have miss := (show ∀ j : Fin 10, onSet [j.val] = false by decide +kernel) v
      simp_all
    refine ⟨single,?_⟩
    intro w
    rcases (row _ (pairSmall u v)).mp adjacent w with raw | z
    · exact split u v w raw
    · have wrong := auxBit_antitone positive g [v.val] u.val z.1
      simp_all
  · intro S sm pos w miss
    have z : auxBit pre g S = true ∧ R 10 w := by
      rcases (row S sm).mp pos w with ⟨a,ha,hit⟩ | yes
      · exact False.elim (miss a ha hit)
      · exact yes
    refine ⟨z,?_⟩
    intro A sub independent
    have smA : ∀ a ∈ A, a<10 := fun a ha => sm a (sub a ha)
    have za := auxAntitoneSubset positive g sub z.1
    have fail : ¬ ∀ t, (∃ a ∈ A, R a t) ∨ (auxBit pre g A = true ∧ R 10 t) := by
      intro all
      have := (row A smA).mpr all
      simp_all
    push_neg at fail
    obtain ⟨t,raw,guard⟩ := fail
    exact ⟨t,guard za,raw⟩

end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.physicalCatalogueRows
