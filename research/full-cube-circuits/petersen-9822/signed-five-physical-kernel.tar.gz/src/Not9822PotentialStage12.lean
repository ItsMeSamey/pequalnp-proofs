import Not9822PotentialStage11
import Not9822NamedChronology
import SignedOrderClosure9822

-- Not9822DirectedRoster
namespace Petersen9822.DagCut
open Petersen9822.Potential
open Petersen9822.FirstSite

private theorem liveBefore {d : Indexed} {out k : Nat} {xs} (p : Path d.edge out k xs) :
    k ≤ out := by
  induction p with
  | stop => exact Nat.le_refl _
  | step _ e _ ih => exact Nat.le_trans (Nat.le_of_lt (d.chrono e)) ih

theorem placementRoster {d : Indexed} {out : Nat} (c : FifteenCore d out)
    (a : RealGuard d out 1) (b : RealGuard d out 2) (sites : List (Nat × Nat))
    (ord : Ordered sites) (late : assigned d out (fork d) 2 = out)
    (ids : ∀ v : Slot, v ∈ innerForks d ↔ ∃ e ∈ sites, e.1 = v.val)
    (bound : ∀ e ∈ sites, e.1 < 25)
    (aa : ∀ e ∈ sites, e.2 = 0 → e.1 = a.site)
    (bb : ∀ e ∈ sites, e.2 = 1 → e.1 = b.site)
    (qq : ∀ e ∈ sites, assigned d out (fork d) 1 = e.1 ↔ e.2 = 2) :
    Placement (sites.map Prod.snd) (pack (fork d)) := by
  have known (e) (h : e ∈ sites) : 10 ≤ e.1 ∧ e.1 < 25 ∧ fork d e.1 = true := by
    let v := slot e.1
    have eq : v.val = e.1 := slot_val _ (by have := bound e h; omega)
    have hm := (ids v).mpr ⟨e,h,eq.symm⟩
    simpa only [eq] using mem_innerFork.mp hm
  apply placementFromNames c a b sites ord _ (fun e h => (known e h).1)
    (fun e h => (known e h).2.2) _ aa bb qq late
  · intro e h
    obtain ⟨lo,hi,hot⟩ := known e h
    obtain ⟨xs,p⟩ := c.live _ lo hi
    exact lt_of_le_of_ne (liveBefore p) (actual_fork_range c hot).2
  · intro k lo _ hot
    have hi := (actual_fork_range c hot).1
    have eq := slot_val k (by omega)
    obtain ⟨e,he,val⟩ := (ids (slot k)).mp (mem_innerFork.mpr (by rw [eq]; exact ⟨lo,hi,hot⟩))
    exact ⟨e,he,val.trans eq⟩

end Petersen9822.DagCut

-- Not9822DirectedPhysical
namespace Petersen9822.DagCut
open Petersen9822.Potential

theorem directedPhysical (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) {d : Indexed} {out : Nat} (c : FifteenCore d out)
    (a : RealGuard d out 1) (b : RealGuard d out 2) (ab : a.site ≠ b.site)
    (zero : fork d 0 = false) (three : fork d 3 = false)
    (early : assigned d out (fork d) 1 ≠ out) (late : assigned d out (fork d) 2 = out) : False := by
  classical
  let q := assigned d out (fork d) 1
  have aq : a.site < q := a.beforeOwner c (by decide)
  have qb : q ≠ b.site := b.excludesNeighbor c (by decide) 1 192 (by decide)
  have q25 := (internal_owner c (by decide : 1 < 10) early).2
  change q < 25 at q25
  have a25 := Nat.lt_trans a.beforeOut c.upperOut
  have b25 := Nat.lt_trans b.beforeOut c.upperOut
  have av := slot_val a.site (by omega)
  have bv := slot_val b.site (by omega)
  have qv := slot_val q (by omega)
  have support := repeatSupport c5Prior c a b ab zero three
  have repeats : 2 ≤ rawRepeats (pack (fork d)) := by
    unfold rawRepeats
    rw [repeatedCard]
    exact at_least_two_repeated d c.diagram out c.lowerOut c.computes c.properSockets c.op c.signed
  rcases physical_roster c a b ab early with shape | ⟨w,hot,wa,wb,wq,shape⟩
  · change innerForks d = {slot a.site,slot b.site,slot q} at shape
    obtain ⟨sites,ord,mem,perm,order⟩ := threeChronology _ _ _ aq ab qb.symm
    apply no_normalized_placement (normalized_of_order (pack_lt _) support repeats order (Or.inl perm))
    apply placementRoster c a b sites ord late
    · intro v
      simp_rw [mem]
      simp [shape,Fin.ext_iff,av,bv,qv,eq_comm]
    all_goals
      intro e he
      have h := (mem e).mp he
      simp only [List.mem_cons,List.not_mem_nil,or_false] at h
      rcases h with rfl | rfl | rfl <;> simp_all [q] <;> omega
  · change innerForks d = {slot a.site,slot b.site,slot q,w} at shape
    change w ≠ slot q at wq
    have eqN {n : Nat} (vn : (slot n).val = n) (hn : w ≠ slot n) : n ≠ w.val := by
      intro h
      exact hn (Fin.ext (h.symm.trans vn.symm))
    have aw := eqN av wa
    have bw := eqN bv wb
    have qw := eqN qv wq
    have w25 := (mem_innerFork.mp hot).2.1
    obtain ⟨sites,ord,mem,perm,order⟩ := fourChronology _ _ _ _ aq ab aw qb.symm bw qw
    have four : (innerForks d).card = 4 := by
      rw [shape]
      have na : slot a.site ≠ slot b.site := fun h => ab (by simpa [av,bv] using congrArg Fin.val h)
      have nq : slot a.site ≠ slot q := fun h => (Nat.ne_of_lt aq) (by simpa [av,qv] using congrArg Fin.val h)
      have nb : slot b.site ≠ slot q := fun h => qb.symm (by simpa [bv,qv] using congrArg Fin.val h)
      have noA : slot a.site ∉ ({slot b.site,slot q,w} : Finset Slot) := by simp [na,nq,wa.symm]
      have noB : slot b.site ∉ ({slot q,w} : Finset Slot) := by simp [nb,wb.symm]
      have noQ : slot q ∉ ({w} : Finset Slot) := by simp [wq.symm]
      rw [Finset.card_insert_of_notMem noA,Finset.card_insert_of_notMem noB,Finset.card_insert_of_notMem noQ]
      rfl
    have cap := combined_excess d c.diagram out c.upperOut c.finalWire c.live c.computes
    have upper : rawRepeats (pack (fork d)) ≤ 2 := by unfold rawRepeats; rw [repeatedCard]; omega
    apply no_normalized_placement (normalized_of_order (pack_lt _) support repeats order (Or.inr ⟨perm,upper⟩))
    apply placementRoster c a b sites ord late
    · intro v
      simp_rw [mem]
      simp [shape,Fin.ext_iff,av,bv,qv,eq_comm]
    all_goals
      intro e he
      have h := (mem e).mp he
      simp only [List.mem_cons,List.not_mem_nil,or_false] at h
      rcases h with rfl | rfl | rfl | rfl <;> simp_all [q] <;> omega

end Petersen9822.DagCut
