import SignedPhysicalCore9822
import Not9822ProjectedPivots
import Not9822Bundle08Neighbors

-- Not9822PivotDefaults
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

theorem evaluate_open (d : Indexed) (out cut row : Nat) :
    wireValue d out row =
      ((d.tree out).openWire cut).eval (ports row (wireValue d cut row)) := by
  rw [wireValue,← Tree.replaceSite _ _ _ (d.coherent cut out),Term.eval_bind]
  apply Term.congr
  intro v _
  cases v <;> rfl

theorem no_raw_before {d : Indexed} {out cut v : Nat} {shared : Nat → Bool}
    (sink : ∀ i j, d.edge i j → i ≠ out)
    (func : ∀ a, shared a = false → ∀ j k, d.edge a j → d.edge a k → j=k)
    (site : shared cut = true) (live : ∃ xs, Path d.edge out cut xs)
    (late : cut < assigned d out shared v) : ¬ (d.tree cut).term.uses v := by
  intro used
  have tail : Path d.edge out (d.tree cut).id live.choose := by simpa using live.choose_spec
  obtain ⟨xs,h,hit⟩ := Tree.rawPath (d.tree_valid cut) tail sink used
  have firstLe := first_le_shared (fun _ _ e => d.chrono e) h
    (show cut ∈ v :: xs by simpa using hit) site
  have eq := (assigned_live (shared:=shared) (show ∃ ys, Path d.edge out v ys from ⟨xs,h⟩)).trans
    (owner_eq func _ h)
  rw [eq] at late
  omega

theorem independent_flip {d : Indexed} {k v : Nat} (absent : ¬ (d.tree k).term.uses v) (row : Nat) :
    wireValue d k row = wireValue d k (row ||| 2^v) := by
  apply Term.congr
  intro i hi
  have ne : v ≠ i := by intro eq; subst i; exact absent hi
  simp [Nat.testBit_two_pow,ne]

theorem guard_pivot {d : Indexed} {cut out v p : Nat} {block : Bool}
    (guard : PrivateSockets d cut (2^v) block)
    (outCold : (2^v : Nat).testBit out = false)
    (absent : ¬ (d.tree cut).term.uses v)
    (compute : ∀ row, edgeHit row = wireValue d out row)
    (pivotal : edgeHit p ≠ edgeHit (p ||| 2^v)) :
    wireValue d cut p = !block ∧ wireValue d cut (p ||| 2^v) = !block := by
  have eq := independent_flip absent p
  have pass : wireValue d cut p ≠ block := by
    intro h
    apply pivotal
    rw [compute,compute,evaluate_open d out cut p,evaluate_open d out cut (p ||| 2^v),←eq,h]
    simpa only [Nat.zero_or] using (d.private_entries out cut _ block guard outCold).blocks 0 p
  have hh : wireValue d cut p = !block := by
    cases h : wireValue d cut p <;> cases block <;> simp_all
  exact ⟨hh,eq.symm.trans hh⟩

theorem owner_pivot {d : Indexed} {out cut v p : Nat} {shared : Nat → Bool}
    (sink : ∀ i j, d.edge i j → i ≠ out)
    (func : ∀ a, shared a = false → ∀ j k, d.edge a j → d.edge a k → j=k)
    (live : ∃ xs, Path d.edge out v xs) (here : assigned d out shared v = cut)
    (compute : ∀ row, edgeHit row = wireValue d out row)
    (pivotal : edgeHit p ≠ edgeHit (p ||| 2^v)) :
    wireValue d cut p ≠ wireValue d cut (p ||| 2^v) := by
  intro eq
  apply pivotal
  rw [compute,compute,evaluate_open d out cut p,evaluate_open d out cut (p ||| 2^v),←eq]
  apply Term.congr
  intro k hk
  cases k with
  | none => rfl
  | some k =>
    have own : owner d.edge out shared v live = cut := (assigned_live live).symm.trans here
    have ne : v ≠ k := by intro z; subst k; exact d.owner_hidden sink func live own hk
    simp [ports,Nat.testBit_two_pow,ne]

theorem rigid_pivot {d : Indexed} {cut p v : Nat} {pol : Bool → Bool}
    (rigid : Passes pol (gateSignal d cut p v))
    (diff : wireValue d cut p ≠ wireValue d cut (p ||| 2^v)) :
    wireValue d cut p = pol false ∧ wireValue d cut (p ||| 2^v) = pol true := by
  have ne : gateSignal d cut p v false ≠ gateSignal d cut p v true := by
    simpa [gateSignal,wireValue,toggle] using diff
  have steady := rigid.resolve_right ne
  exact ⟨by simpa [gateSignal,wireValue,toggle] using steady false,
    by simpa [gateSignal,wireValue,toggle] using steady true⟩

end Petersen9822.DagCut

-- Not9822PentagonDefaults
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

structure OwnerDefaults (d : Indexed) (out raw guard cut : Nat) where
  pass : Bool
  pol : Bool → Bool
  pivot : ∀ p, p.testBit raw = false → edgeHit p ≠ edgeHit (p ||| 2^raw) →
    wireValue d guard p = pass ∧ wireValue d guard (p ||| 2^raw) = pass ∧
      wireValue d cut p = pol false ∧ wireValue d cut (p ||| 2^raw) = pol true

noncomputable def ownerDefaults {d : Indexed} {out raw guard cut : Nat} {shared : Nat → Bool}
    {block : Bool} (g : PrivateSockets d guard (2^raw) block)
    (outCold : (2^raw : Nat).testBit out = false)
    (guardFree : ¬ (d.tree guard).term.uses raw)
    (sink : ∀ i j, d.edge i j → i ≠ out)
    (func : ∀ a, shared a = false → ∀ j k, d.edge a j → d.edge a k → j=k)
    (distinct : ∀ n op, d.get n = some op → op.left ≠ op.right)
    (live : ∃ xs, Path d.edge out raw xs) (here : assigned d out shared raw = cut)
    (signed : (d.tree cut).signed)
    (compute : ∀ row, edgeHit row = wireValue d out row) : OwnerDefaults d out raw guard cut := by
  let pp := privateSignalPolarity func distinct live here signed
  refine ⟨!block,pp.choose,?_⟩
  intro p h0 pivot
  obtain ⟨p0,p1⟩ := guard_pivot g outCold guardFree compute pivot
  have q := rigid_pivot (pp.choose_spec p h0) (owner_pivot sink func live here compute pivot)
  exact ⟨p0,p1,q⟩

theorem fourDefaults {d : Indexed} {out i j pi pj qi qj : Nat}
    (ij : (i,j) ∈ ([(1,2),(2,1)] : List (Nat × Nat)))
    (late : OwnerDefaults d out i pi qi) (early : OwnerDefaults d out j pj qj)
    (pBefore : ¬ (d.tree pj).term.uses i) (qBefore : ¬ (d.tree qj).term.uses i)
    (r : Fin 1024) (onA : sub r.val 313 = true) (negative : edgeHit (r.val ||| 2^j) = false) :
    wireValue d pi (r.val ||| 2^j) = late.pass ∧
    wireValue d qi (r.val ||| 2^j) = late.pol false ∧
    wireValue d pj (r.val ||| 2^j) = early.pass ∧
    wireValue d qj (r.val ||| 2^j) = early.pol true := by
  obtain ⟨fi,fj,negOther,positive⟩ := projectionPivots _ ij r onA negative
  have swap : r.val ||| 2^j ||| 2^i = r.val ||| 2^i ||| 2^j := by
    rw [Nat.or_assoc,Nat.or_comm (2^j),←Nat.or_assoc]
  have ip := late.pivot _ fi (by rw [negative,swap,positive]; decide)
  have jp := early.pivot _ fj (by rw [negOther,positive]; decide)
  have eqP := independent_flip pBefore (r.val ||| 2^j)
  have eqQ := independent_flip qBefore (r.val ||| 2^j)
  rw [swap] at eqP eqQ
  exact ⟨ip.1,ip.2.2.1,eqP.trans jp.2.1,eqQ.trans jp.2.2.2⟩

end Petersen9822.DagCut
