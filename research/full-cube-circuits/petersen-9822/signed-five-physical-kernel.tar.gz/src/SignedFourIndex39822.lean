import SignedFourGroup219822
import SignedFourGroup229822
import SignedFourGroup239822
import SignedFourGroup249822
import SignedFourGroup259822
import SignedFourGroup269822
import SignedFourGroup279822
namespace Research.SignedFactorFour
def bucket3 : List Row := page21 ++ page22 ++ page23 ++ page24 ++ page25 ++ page26 ++ page27
theorem bucketPaid3 : bucket3.all rowGood=true := by simp [bucket3,paid21,paid22,paid23,paid24,paid25,paid26,paid27]
end Research.SignedFactorFour
