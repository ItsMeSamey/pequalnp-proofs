import SignedFourFiniteRows9822
namespace Research.SignedFactorFour
set_option maxRecDepth 12000
set_option maxHeartbeats 4000000
def r170 : Row := ([2,5,8,9], [0,1])
private theorem ok170 : rowGood r170=true := by decide +kernel
def r171 : Row := ([2,6,7,8], [0,4])
private theorem ok171 : rowGood r171=true := by decide +kernel
def r172 : Row := ([2,6,7,9], [0,3])
private theorem ok172 : rowGood r172=true := by decide +kernel
def r173 : Row := ([2,6,8,9], [0,7])
private theorem ok173 : rowGood r173=true := by decide +kernel
def r174 : Row := ([2,7,8,9], [0,6])
private theorem ok174 : rowGood r174=true := by decide +kernel
def page34 : List Row := [r170,r171,r172,r173,r174]
theorem paid34 : page34.all rowGood=true := by simp [page34,ok170,ok171,ok172,ok173,ok174]
end Research.SignedFactorFour
