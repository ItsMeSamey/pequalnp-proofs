import NinePatchSyntax9822
namespace PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
open PEqualNP.CircuitLowerBounds

def gate (r d : Nat) (hot : Nat → Bool) (q : Gate) : Gate :=
  ⟨q.op,match q.inputs with
    | [a,b] => if a=r ∧ hot b=true then [d,b]
      else if b=r ∧ hot a=true then [a,d] else [a,b]
    | xs => xs⟩

theorem clean {r d m : Nat} (hd : d≤r) (hot : Nat → Bool) {q : Gate}
    (h : CleanGate m q) : CleanGate m (gate r d hot q) := by
  rcases h with ⟨op,j,jb,ins⟩|⟨op,a,b,ab,bb,ins⟩
  · exact Or.inl ⟨op,j,jb,by simp [gate,ins]⟩
  · apply Or.inr
    refine ⟨op,?_⟩
    by_cases left : a=r ∧ hot b=true
    · exact ⟨d,b,by omega,bb,by simp [gate,ins,left]⟩
    by_cases right : b=r ∧ hot a=true
    · exact ⟨a,d,ab,by omega,by simp only [gate,ins,if_neg left,if_pos right]⟩
    · exact ⟨a,b,ab,bb,by simp only [gate,ins,if_neg left,if_neg right]⟩

theorem step {r d a b : Nat} {hot F : Nat → Bool} {q : Gate} (ins : q.inputs=[a,b])
    (andRead : r∈q.inputs → q.op=.and)
    (agree : ∀ j,hot j=true → F j=true → F r=F d) :
    (gate r d hot q).op.eval ((gate r d hot q).inputs.map F)=q.op.eval (q.inputs.map F) := by
  by_cases left : a=r ∧ hot b=true
  · have op := andRead (by simp [ins,left.1])
    simp only [gate,ins,if_pos left,op]
    cases h : F b
    · simp [GateOp.eval,h]
    · simp [GateOp.eval,h,left.1,agree b left.2 h]
  by_cases right : b=r ∧ hot a=true
  · have op := andRead (by simp [ins,right.1])
    simp only [gate,ins,if_neg left,if_pos right,op]
    cases h : F a
    · simp [GateOp.eval,h]
    · simp [GateOp.eval,h,right.1,agree a right.2 h]
  · simp only [gate,ins,if_neg left,if_neg right]
end PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
