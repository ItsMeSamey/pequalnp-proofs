import SignedFourFiniteRows9822
namespace Research.SignedFactorFour
set_option maxRecDepth 12000
set_option maxHeartbeats 4000000
def r155 : Row := ([2,4,5,6], [3,7])
private theorem ok155 : rowGood r155=true := by decide +kernel
def r156 : Row := ([2,4,5,7], [6,8])
private theorem ok156 : rowGood r156=true := by decide +kernel
def r157 : Row := ([2,4,5,8], [6,9])
private theorem ok157 : rowGood r157=true := by decide +kernel
def r158 : Row := ([2,4,5,9], [6,8])
private theorem ok158 : rowGood r158=true := by decide +kernel
def r159 : Row := ([2,4,6,7], [5,8])
private theorem ok159 : rowGood r159=true := by decide +kernel
def page31 : List Row := [r155,r156,r157,r158,r159]
theorem paid31 : page31.all rowGood=true := by simp [page31,ok155,ok156,ok157,ok158,ok159]
end Research.SignedFactorFour
