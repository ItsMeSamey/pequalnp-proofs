import H3GlobalBatchSingle3129822
import H3GlobalBatchSingle3139822
import H3GlobalBatchSingle3149822
import H3GlobalBatchSingle3159822
import H3GlobalBatchSingle3169822
import H3GlobalBatchSingle3179822
import H3GlobalBatchSingle3189822
import H3GlobalBatchSingle3199822
import H3GlobalBatchSingle3209822
import H3GlobalBatchSingle3219822
import H3GlobalBatchSingle3229822
import H3GlobalBatchSingle3239822
namespace Research.Graph9822Planes
def rootsPage312 : List Nat := (batchSingle312.map Prod.fst) ++ ((batchSingle313.map Prod.fst) ++ ((batchSingle314.map Prod.fst) ++ ((batchSingle315.map Prod.fst) ++ ((batchSingle316.map Prod.fst) ++ ((batchSingle317.map Prod.fst) ++ ((batchSingle318.map Prod.fst) ++ ((batchSingle319.map Prod.fst) ++ ((batchSingle320.map Prod.fst) ++ ((batchSingle321.map Prod.fst) ++ ((batchSingle322.map Prod.fst) ++ ((batchSingle323.map Prod.fst))))))))))))
theorem allPage312 : PaidKeys rootsPage312 := paid_append (page_paid paidBatchSingle312) (paid_append (page_paid paidBatchSingle313) (paid_append (page_paid paidBatchSingle314) (paid_append (page_paid paidBatchSingle315) (paid_append (page_paid paidBatchSingle316) (paid_append (page_paid paidBatchSingle317) (paid_append (page_paid paidBatchSingle318) (paid_append (page_paid paidBatchSingle319) (paid_append (page_paid paidBatchSingle320) (paid_append (page_paid paidBatchSingle321) (paid_append (page_paid paidBatchSingle322) (page_paid paidBatchSingle323)))))))))))
end Research.Graph9822Planes
