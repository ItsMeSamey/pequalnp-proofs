import PhysicalRemainingSectors9822
import HighAndSectorClosed9822

namespace PEqualNP.Outside.L_meta_9822.Sectors
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_9822.Clean
theorem remaining_low_sectors
    (zero : ∀ C, Candidate C → Reduced 10 C.gates C.output →
      C.gates.countP countsNot = 0 →
      (C.gates.countP countsAnd = 5 ∨ C.gates.countP countsAnd = 6) → False)
    (one : ∀ C, Candidate C → Reduced 10 C.gates C.output →
      C.gates.countP countsNot = 1 → C.gates.countP Compact.bin = 16 →
      C.size = 17 → C.gates.countP countsAnd ≤ 6 → False) :
    ¬ HasCircuitSize 10 edge 17 := by
  apply remainingSectors zero
  intro C cand red inv bin size
  by_cases low : C.gates.countP countsAnd ≤ 6
  · exact one C cand red inv bin size low
  · exact BoundedClamp.high_and_sector cand red inv (by omega)
end PEqualNP.Outside.L_meta_9822.Sectors
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.remaining_low_sectors
