import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle88 : List ModeRow := [(72196145,[43559,21969,13005,5231,14479,943,25045,5917],[41581,13359,29990,751])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle88 : batchSingle88.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
