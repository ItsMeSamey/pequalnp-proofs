import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row6 : row 4730 = true := by decide +kernel
theorem row7 : row 5196 = true := by decide +kernel
theorem row8 : row 5244 = true := by decide +kernel
end Research.LiteralC5.Table
