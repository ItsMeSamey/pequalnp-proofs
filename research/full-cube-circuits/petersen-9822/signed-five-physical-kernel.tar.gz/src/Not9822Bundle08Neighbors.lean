import Not9822Bundle07Lca

-- Not9822Neighbor
namespace Petersen9822.DagCut

/-- A unary private path upstream of one guard has one global polarity over
    all background assignments. Pair views may have arbitrary downstream decoders. -/
def InDirection (polarity : Bool) (msg : Bool → Bool) : Prop :=
  if polarity then msg false ≤ msg true else msg true ≤ msg false

structure PairView (f : Bool → Bool → Bool) (pass : Bool) where
  msg : Bool → Bool
  outer : Bool → Bool → Bool
  sound : ∀ a b, f a b = outer (msg a) b
  pivotal : ∀ a, f a false ≠ f a true → msg a = pass

theorem adjacentCannotFeedGuard (pass polarity : Bool)
    (atAnd : PairView (fun a b => a && b) pass)
    (atOr : PairView (fun a b => a || b) pass)
    (dirAnd : InDirection polarity atAnd.msg) (dirOr : InDirection polarity atOr.msg) :
    False := by
  have pivotAnd := atAnd.pivotal true (by decide)
  have pivotOr := atOr.pivotal false (by decide)
  have neAnd : atAnd.msg false ≠ atAnd.msg true := by
    intro h
    have hf := atAnd.sound false true
    have ht := atAnd.sound true true
    rw [h] at hf
    simp_all
  have neOr : atOr.msg false ≠ atOr.msg true := by
    intro h
    have hf := atOr.sound false false
    have ht := atOr.sound true false
    rw [h] at hf
    simp_all
  have noDecrease : ¬(true ≤ false) := by decide
  cases polarity <;> cases pass <;> cases ha : atAnd.msg false <;>
    cases hb : atAnd.msg true <;> cases hc : atOr.msg false <;>
    cases hd : atOr.msg true <;> simp_all [InDirection,noDecrease]
  all_goals exact (by decide : ¬ ((true : Bool) ≤ false)) (by assumption)

end Petersen9822.DagCut

-- Not9822GuardOrder
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

private theorem start_le_first {d : Indexed} {out a : Nat} {shared : Nat → Bool}
    {xs : List Nat} (p : Path d.edge out a xs) : a ≤ first shared out a xs := by
  have h := first_on_path (shared := shared) p
  rcases List.mem_cons.mp h with eq | h
  · exact Nat.le_of_eq eq.symm
  · exact Nat.le_of_lt (all_after (fun _ _ e => d.chrono e) p _ h)

theorem guard_before_owner {d : Indexed} {cut out ownerMask v : Nat} {block : Bool}
    {shared : Nat → Bool} (sockets : PrivateSockets d cut ownerMask block)
    (raw : ownerMask.testBit v = true) (notShared : shared v = false)
    (notOut : v ≠ out) (beforeOut : cut < out) :
    cut < assigned d out shared v := by
  classical
  by_cases lives : ∃ xs, Path d.edge out v xs
  · rw [assigned_live lives]
    suffices allPaths : ∀ xs, Path d.edge out v xs → cut < first shared out v xs from
      allPaths lives.choose lives.choose_spec
    intro xs p
    cases p with
    | stop => exact False.elim (notOut rfl)
    | @step _ n tail _ e pt =>
      obtain ⟨g,hg,left | right⟩ := e
      · have raw' : ownerMask.testBit g.left = true := by simpa only [left] using raw
        obtain ⟨eq,_⟩ := sockets.left n g hg raw'
        have gt := (d.back n g hg).2
        rw [eq] at gt
        simpa [first,notShared] using Nat.lt_of_lt_of_le gt (start_le_first (shared := shared) pt)
      · have raw' : ownerMask.testBit g.right = true := by simpa only [right] using raw
        obtain ⟨eq,_⟩ := sockets.right n g hg raw'
        have gt := (d.back n g hg).1
        rw [eq] at gt
        simpa [first,notShared] using Nat.lt_of_lt_of_le gt (start_le_first (shared := shared) pt)
  · simpa [assigned,lives] using beforeOut

end Petersen9822.DagCut

-- Not9822GuardViews
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

def toggle (a : Bool) (m : Nat) := if a then m else 0

private theorem toggleSub (a : Bool) (m : Nat) : sub (toggle a m) m = true := by
  cases a <;> simp [toggle,sub]

def gateSignal (d : Indexed) (cut p v : Nat) (a : Bool) : Bool :=
  (d.tree cut).term.eval (p ||| toggle a (2^v)).testBit

def guardView {d : Indexed} {out cut v i : Nat} {shared : Nat → Bool} {block : Bool}
    (bins : SiteBins d out cut shared (2^v) (2^i))
    (privateEntry : PrivateSockets d cut (2^i) block) (outCold : (2^i : Nat).testBit out = false)
    (computes : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit)
    (p : Nat) : PairView (sectionBit p (2^v) (2^i)) (!block) := by
  let C := bins.channel p computes
  refine { msg := gateSignal d cut p v,
           outer := fun b y => C.dec b (toggle y (2^i)), sound := ?_, pivotal := ?_ }
  · intro a b
    exact C.correct _ _ (toggleSub a _) (toggleSub b _)
  · intro a hp
    by_cases hb : gateSignal d cut p v a = block
    · exfalso
      apply hp
      change val p (toggle a (2^v)) 0 = val p (toggle a (2^v)) (2^i)
      rw [C.correct _ _ (toggleSub a _) (by simp [sub]),C.correct _ _ (toggleSub a _) (by simp [sub])]
      change C.dec (gateSignal d cut p v a) 0 = C.dec (gateSignal d cut p v a) (2^i)
      rw [hb]
      change ((d.tree out).openWire (d.tree cut).id).eval (ports (p ||| 0) block) =
        ((d.tree out).openWire (d.tree cut).id).eval (ports (p ||| (2^i)) block)
      simpa only [d.tree_id,Nat.zero_or] using (d.private_entries out cut _ block privateEntry outCold).blocks p 0
    · cases block <;> cases he : gateSignal d cut p v a <;> simp_all

theorem passesDirection (pol : Bool → Bool) : ∃ dir, ∀ msg, Passes pol msg → InDirection dir msg := by
  refine ⟨decide (pol false ≤ pol true), ?_⟩
  intro msg h
  rcases h with h | h
  · cases hf : pol false <;> cases ht : pol true <;> simp [InDirection,h,hf,ht]
  · cases hf : pol false <;> cases ht : pol true <;> simp [InDirection,h,hf,ht]

theorem excludeNeighbor {d : Indexed} {out cut v i : Nat} {shared : Nat → Bool} {block : Bool}
    (bins : SiteBins d out cut shared (2^v) (2^i))
    (privateEntry : PrivateSockets d cut (2^i) block) (outCold : (2^i : Nat).testBit out = false)
    (computes : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit)
    (p : Nat) (hA : ∀ a b, sectionBit 0 (2^v) (2^i) a b = (a && b))
    (hO : ∀ a b, sectionBit p (2^v) (2^i) a b = (a || b))
    (pol : Bool → Bool) (h0 : Passes pol (gateSignal d cut 0 v))
    (hp : Passes pol (gateSignal d cut p v)) : False := by
  let A := guardView bins privateEntry outCold computes 0
  let O := guardView bins privateEntry outCold computes p
  let andView : PairView (fun a b => a && b) (!block) := {
    msg := A.msg, outer := A.outer,
    sound := fun a b => (hA a b).symm.trans (A.sound a b),
    pivotal := fun a h => A.pivotal a (by simpa only [hA] using h) }
  let orView : PairView (fun a b => a || b) (!block) := {
    msg := O.msg, outer := O.outer,
    sound := fun a b => (hO a b).symm.trans (O.sound a b),
    pivotal := fun a h => O.pivotal a (by simpa only [hO] using h) }
  obtain ⟨dir,correct⟩ := passesDirection pol
  exact adjacentCannotFeedGuard (!block) dir andView orView (correct _ h0) (correct _ hp)

end Petersen9822.DagCut

-- Not9822NeighborLeg
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

def setRaw (v p : Nat) (a : Bool) (i : Nat) := if i=v then a else p.testBit i

private theorem quietRaw (t : Tree) (v : Nat) (h : t.rawCt v = 0) (p : Nat) (a : Bool) :
    t.term.eval (setRaw v p a) = t.term.eval p.testBit := by
  induction t with
  | raw n =>
    have ne : n ≠ v := by intro e; simp [Tree.rawCt,e] at h
    simp [Tree.term,Term.eval,setRaw,ne]
  | gate n op l r il ir =>
    have eq : l.rawCt v + r.rawCt v = 0 := h
    simp [Tree.term,Term.eval,il (by omega),ir (by omega)]

private theorem unaryPolarity (t : Tree) (v : Nat) (signed : t.signed) (count : t.rawCt v ≤ 1) :
    ∃ pol, ∀ p, Passes pol (fun a => t.term.eval (setRaw v p a)) := by
  induction t with
  | raw n =>
    by_cases eq : n = v
    · exact ⟨id,fun _ => Or.inl (fun a => by simp [Tree.term,Term.eval,setRaw,eq])⟩
    · exact ⟨id,fun _ => Or.inr (by simp [Tree.term,Term.eval,setRaw,eq])⟩
  | gate n op l r il ir =>
    obtain ⟨⟨sl⟩,⟨sr⟩,ls,rs⟩ := signed
    change l.rawCt v + r.rawCt v ≤ 1 at count
    by_cases hr : r.rawCt v = 0
    · obtain ⟨pol,runs⟩ := il ls (by omega)
      refine ⟨fun x => sl.pol (pol x), fun p => ?_⟩
      have hh := (runs p).comp (sl.sections (r.term.eval p.testBit))
      simpa only [Tree.term,Term.eval,quietRaw r v hr] using hh
    · have hl : l.rawCt v = 0 := by omega
      obtain ⟨pol,runs⟩ := ir rs (by omega)
      refine ⟨fun x => sr.pol (pol x), fun p => ?_⟩
      have hh := (runs p).comp (sr.sections (l.term.eval p.testBit))
      simpa only [Tree.term,Term.eval,quietRaw l v hl] using hh

theorem privateSignalPolarity {d : Indexed} {out cut v : Nat} {shared : Nat → Bool}
    (func : ∀ a, shared a = false → ∀ j k, d.edge a j → d.edge a k → j=k)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (live : ∃ xs, Path d.edge out v xs) (atCut : assigned d out shared v = cut)
    (signed : (d.tree cut).signed) :
    ∃ pol, ∀ p, p.testBit v = false → Passes pol (gateSignal d cut p v) := by
  rw [assigned_live live] at atCut
  have count := owner_occ_once func distinct v live
  rw [atCut] at count
  obtain ⟨pol,runs⟩ := unaryPolarity (d.tree cut) v signed ((Tree.rawCt_le _ _).trans count)
  refine ⟨pol,fun p hp => ?_⟩
  have eq : gateSignal d cut p v = (fun a => (d.tree cut).term.eval (setRaw v p a)) := by
    funext a
    apply Term.congr
    intro i _
    by_cases hi : i = v
    · subst i
      cases a <;> simp [setRaw,toggle,Nat.testBit_two_pow,hp]
    · cases a <;> simp [setRaw,toggle,Nat.testBit_two_pow,hi,Ne.symm hi]
  rw [eq]
  exact runs p

end Petersen9822.DagCut

-- Not9822NeighborSites
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

def neighborCases : List (Nat × Nat × Nat) := [(6,1,260),(7,2,34),(1,2,192),(2,1,192)]

private theorem neighborRows : ∀ e ∈ neighborCases,
    e.2.2.testBit e.1 = false ∧
    (∀ a b, sectionBit 0 (2^e.1) (2^e.2.1) a b = (a && b)) ∧
    (∀ a b, sectionBit e.2.2 (2^e.1) (2^e.2.1) a b = (a || b)) := by decide +kernel

theorem neighborGuardUnreachable {d : Indexed} {out cut v i p : Nat} {shared : Nat → Bool}
    {block : Bool} (which : (v,i,p) ∈ neighborCases)
    (sink : ∀ a b, d.edge a b → a ≠ out)
    (func : ∀ a, shared a = false → ∀ j k, d.edge a j → d.edge a k → j = k)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (gateShared : shared cut = true) (gateLive : ∃ xs, Path d.edge out cut xs)
    (gateBefore : cut < out) (signed : (d.tree cut).signed)
    (rawOwner : shared i = false) (rawNotOut : i ≠ out)
    (privateEntry : PrivateSockets d cut (2^i) block)
    (compute : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit) :
    assigned d out shared v ≠ cut := by
  classical
  intro here
  have outCold : (2^i : Nat).testBit out = false := by simp [Nat.testBit_two_pow,rawNotOut]
  have ownLater : cut < assigned d out shared i :=
    guard_before_owner privateEntry (Nat.testBit_two_pow_self (n := i)) rawOwner rawNotOut gateBefore
  have bins : SiteBins d out cut shared (2^v) (2^i) := by
    refine ⟨sink,func,gateShared,gateLive,?_,?_⟩
    · intro k hk live
      have he : v = k := by simpa [Nat.testBit_two_pow] using hk
      subst k
      simpa only [←assigned_live live] using here
    · intro k hk live
      have he : i = k := by simpa [Nat.testBit_two_pow] using hk
      subst k
      simpa only [←assigned_live live] using ownLater
  by_cases live : ∃ xs, Path d.edge out v xs
  · obtain ⟨pol,rigid⟩ := privateSignalPolarity func distinct live here signed
    obtain ⟨cold,ha,ho⟩ := neighborRows _ which
    exact excludeNeighbor bins privateEntry outCold compute p ha ho pol (rigid 0 (by simp)) (rigid p cold)
  · have eq : assigned d out shared v = out := by simp [assigned,live]
    omega

end Petersen9822.DagCut
