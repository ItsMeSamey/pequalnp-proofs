import Not9822ReflectCore
import SignedPhysicalGuards9822
namespace Petersen9822.DagCut

def reflectGuard {d : Indexed} {out i : Nat} (c : FifteenCore d out) (g : RealGuard d out i)
    (low : i < 10) : RealGuard (reflected d c.diagram) out (mirror i) where
  site := g.site
  block := g.block
  sockets := mirror_private c.diagram g.internal low g.sockets
  shared := by
    have eq := mirror_fork d c.diagram g.site
    simpa [mirror_high g.internal,g.shared] using eq
  internal := g.internal
  beforeOut := g.beforeOut
  soleRaw := (mirror_fork _ _ _).trans g.soleRaw

theorem reflectLate {d : Indexed} {out i : Nat} (c : FifteenCore d out)
    (live : ∃ xs, Petersen9822.FirstSite.Path d.edge out i xs) :
    assigned (reflected d c.diagram) out (fork (reflected d c.diagram)) (mirror i) = out ↔
      assigned d out (fork d) i = out := by
  have eq := mirror_assigned c.diagram live
  rw [mirror_high c.lowerOut] at eq
  rw [eq]
  conv_lhs => rhs; rw [←mirror_high c.lowerOut]
  exact mirror_inj

end Petersen9822.DagCut
