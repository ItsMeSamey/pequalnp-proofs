import OR9822DirectAlignment
namespace Research.Graph9822GlobalH2.ProfileCheck
set_option maxRecDepth 12000 in
theorem head7 : (List.range' 84 12).all alignHead=true := by decide +kernel
end Research.Graph9822GlobalH2.ProfileCheck
