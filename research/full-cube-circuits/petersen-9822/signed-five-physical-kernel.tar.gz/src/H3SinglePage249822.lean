import H3GlobalBatchSingle249822
import H3GlobalBatchSingle259822
import H3GlobalBatchSingle269822
import H3GlobalBatchSingle279822
import H3GlobalBatchSingle289822
import H3GlobalBatchSingle299822
import H3GlobalBatchSingle309822
import H3GlobalBatchSingle319822
import H3GlobalBatchSingle329822
import H3GlobalBatchSingle339822
import H3GlobalBatchSingle349822
import H3GlobalBatchSingle359822
namespace Research.Graph9822Planes
def rootsPage24 : List Nat := (batchSingle24.map Prod.fst) ++ ((batchSingle25.map Prod.fst) ++ ((batchSingle26.map Prod.fst) ++ ((batchSingle27.map Prod.fst) ++ ((batchSingle28.map Prod.fst) ++ ((batchSingle29.map Prod.fst) ++ ((batchSingle30.map Prod.fst) ++ ((batchSingle31.map Prod.fst) ++ ((batchSingle32.map Prod.fst) ++ ((batchSingle33.map Prod.fst) ++ ((batchSingle34.map Prod.fst) ++ ((batchSingle35.map Prod.fst))))))))))))
theorem allPage24 : PaidKeys rootsPage24 := paid_append (page_paid paidBatchSingle24) (paid_append (page_paid paidBatchSingle25) (paid_append (page_paid paidBatchSingle26) (paid_append (page_paid paidBatchSingle27) (paid_append (page_paid paidBatchSingle28) (paid_append (page_paid paidBatchSingle29) (paid_append (page_paid paidBatchSingle30) (paid_append (page_paid paidBatchSingle31) (paid_append (page_paid paidBatchSingle32) (paid_append (page_paid paidBatchSingle33) (paid_append (page_paid paidBatchSingle34) (page_paid paidBatchSingle35)))))))))))
end Research.Graph9822Planes
