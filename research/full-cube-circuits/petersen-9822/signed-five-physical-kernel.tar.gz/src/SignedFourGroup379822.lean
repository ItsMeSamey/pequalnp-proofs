import SignedFourFiniteRows9822
namespace Research.SignedFactorFour
set_option maxRecDepth 12000
set_option maxHeartbeats 4000000
def r185 : Row := ([3,5,6,7], [0,1])
private theorem ok185 : rowGood r185=true := by decide +kernel
def r186 : Row := ([3,5,6,8], [0,1])
private theorem ok186 : rowGood r186=true := by decide +kernel
def r187 : Row := ([3,5,6,9], [0,1])
private theorem ok187 : rowGood r187=true := by decide +kernel
def r188 : Row := ([3,5,7,8], [0,1])
private theorem ok188 : rowGood r188=true := by decide +kernel
def r189 : Row := ([3,5,7,9], [0,1])
private theorem ok189 : rowGood r189=true := by decide +kernel
def page37 : List Row := [r185,r186,r187,r188,r189]
theorem paid37 : page37.all rowGood=true := by simp [page37,ok185,ok186,ok187,ok188,ok189]
end Research.SignedFactorFour
