import OR9822ProfileCosts
namespace Research.Graph9822GlobalH2.ProfileCheck
set_option maxRecDepth 30000 in
set_option maxHeartbeats 18000000 in
theorem fit31 : (List.range' 992 32).all fit=true := by decide +kernel
end Research.Graph9822GlobalH2.ProfileCheck
