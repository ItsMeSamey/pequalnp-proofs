import MonoCleanExtract
import And9822FivePhysical
import PhysicalAndCap9822

namespace PEqualNP.Outside.L_meta_9822.Sectors
open PEqualNP.CircuitLowerBounds Research.Graph9822Resolution
open PEqualNP.Outside.L_meta_9822.Clean

private theorem count_asGate (ds : List Research.Graph9822Resolution.Gate) : (ds.map asGate).countP countsAnd = ds.countP Research.Graph9822Resolution.Gate.isAnd := by
    induction ds with
    | nil => rfl
    | cons g gs ih =>
      cases g with
      | mk k a b => cases k <;> simp_all [List.countP_cons, asGate, countsAnd]

theorem fiveOrSix (C : Circuit) (h : Candidate C) (hc : CleanL 10 C.gates)
    (zero : C.gates.countP countsNot = 0) :
    C.gates.countP countsAnd = 5 ∨ C.gates.countP countsAnd = 6 := by
  have no : ∀ g ∈ C.gates, g.op ≠ .not := by
    intro g hg he
    have hn := List.countP_eq_zero.mp zero g hg
    simp [countsNot, he] at hn
  obtain ⟨ds, eq, _⟩ := clean_as_binary C.gates 10 hc no
  have circ : asCircuit ds C.output = C := by cases C; simp_all [asCircuit]
  have lo := lower_five_physical ds C.output (by rw [circ]; exact h.2.2)
  have cnt := count_asGate ds
  rw [eq] at cnt
  have hi := zeroNotAtMostSixAnd C h zero
  omega

end PEqualNP.Outside.L_meta_9822.Sectors
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.fiveOrSix
