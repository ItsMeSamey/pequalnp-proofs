import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row39 : row 16777770 = true := by decide +kernel
theorem row40 : row 16778316 = true := by decide +kernel
theorem row41 : row 16781312 = true := by decide +kernel
end Research.LiteralC5.Table
