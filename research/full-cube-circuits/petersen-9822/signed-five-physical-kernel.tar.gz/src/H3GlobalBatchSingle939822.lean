import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle93 : List ModeRow := [(100696078,[61996,7223,59445,47239,21909,15761,20887,12967,21685,5593,7453],[61996,29845,47239,10551,59445,5593,12967,57523,3255,7453])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle93 : batchSingle93.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
