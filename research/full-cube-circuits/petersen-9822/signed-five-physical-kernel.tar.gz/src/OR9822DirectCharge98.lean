import OR9822ProfileDirectData
namespace Research.Graph9822ProfileArithmetic.Direct
set_option maxHeartbeats 18000000 in
set_option maxRecDepth 16000 in
theorem charge98 : inputs 98=true := by decide +kernel
end Research.Graph9822ProfileArithmetic.Direct
