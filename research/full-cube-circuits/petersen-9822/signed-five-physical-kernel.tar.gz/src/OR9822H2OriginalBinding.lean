import OR9822H2FinalTransport
import OR9822H2RealizedKeys
import OR9822H2OriginalAdmission
namespace Research.Graph9822.FreeOR
open Research.Graph9822H2Check Research.Graph9822H2Eligibility

theorem exclude_original_two (c : MaximumFive) (p q : Product)
    (hp : (hiddenFirst c.toFiveProgram).1=[p,q])
    (exclude : ∀ j h : Nat, keys[j]?=some h → ∀ t : Nat, ¬ViableTwo h t) : False :=
  no_two_from_seed c p q hp (admit_original_two c p q hp) key_reified exclude
end Research.Graph9822.FreeOR
