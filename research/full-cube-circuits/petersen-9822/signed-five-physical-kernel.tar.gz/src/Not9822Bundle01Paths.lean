import SignedCensusBundle9822
import PEqualNP.Defs.MetaComplexity

-- Not9822DagCut
namespace Petersen9822.DagCut

/-- Unfolded signed binary DAG. Arbitrary truth tables allow a complement at either socket. -/
inductive Term (α : Type) where
  | var (v : α)
  | lit (b : Bool)
  | gate (op : Bool → Bool → Bool) (a b : Term α)

def Term.eval (env : α → Bool) : Term α → Bool
  | .var v => env v
  | .lit b => b
  | .gate op a b => op (a.eval env) (b.eval env)

def Term.uses (e : Term α) (v : α) : Prop :=
  match e with
  | .var w => w = v
  | .lit _ => False
  | .gate _ a b => a.uses v ∨ b.uses v

theorem Term.congr {e : Term α} {f g : α → Bool} (h : ∀ v, e.uses v → f v = g v) :
    e.eval f = e.eval g := by
  induction e with
  | var v => exact h v rfl
  | lit _ => rfl
  | gate op a b ia ib =>
    change op (a.eval f) (b.eval f) = op (a.eval g) (b.eval g)
    rw [ia (fun v hv => h v (Or.inl hv)), ib (fun v hv => h v (Or.inr hv))]

def Term.bind (f : α → Term β) : Term α → Term β
  | .var v => f v
  | .lit b => .lit b
  | .gate op a b => .gate op (a.bind f) (b.bind f)

theorem Term.eval_bind (e : Term α) (f : α → Term β) (g : β → Bool) :
    (e.bind f).eval g = e.eval (fun v => (f v).eval g) := by
  induction e <;> simp [Term.bind, Term.eval, *]

private theorem sub_cold {x m : Nat} (h : sub x m = true) {i : Nat} (hm : m.testBit i = false) :
    x.testBit i = false := by
  have e : x &&& m = x := by simpa [sub] using h
  have he := congrArg (fun a : Nat => a.testBit i) e
  simpa [hm] using he.symm

def ports (row : Nat) (bit : Bool) : Option Nat → Bool
  | none => bit
  | some v => row.testBit v

def plug (input : Term Nat) : Option Nat → Term Nat
  | none => input
  | some v => .var v

/-- The input cone of the selected gate has no future raw, and opening the
    selected wire removes every current-bin raw from the output cone. -/
def oneBitOfCut (p S U : Nat) (input : Term Nat) (tail : Term (Option Nat))
    (before : ∀ v, input.uses v → U.testBit v = false)
    (afterCut : ∀ v, tail.uses (some v) → S.testBit v = false)
    (computes : ∀ s u, sub s S = true → sub u U = true →
      val p s u = (tail.bind (plug input)).eval ((p ||| s ||| u).testBit)) :
    OneBitAt p S U where
  enc s := input.eval (p ||| s).testBit
  dec bit u := tail.eval (ports (p ||| u) bit)
  correct := by
    intro s u hs hu
    rw [computes s u hs hu, Term.eval_bind]
    apply Term.congr
    intro v hv
    cases v with
    | none =>
      change input.eval (p ||| s ||| u).testBit = input.eval (p ||| s).testBit
      apply Term.congr
      intro i hi
      simp [sub_cold hu (before i hi)]
    | some v =>
      change (p ||| s ||| u).testBit v = (p ||| u).testBit v
      simp [sub_cold hs (afterCut v hv)]

end Petersen9822.DagCut

-- Not9822FirstSite

namespace Petersen9822.FirstSite

/-- Vertices include the ten raw wires. Each adjacency is a physical downstream
    socket occurrence. The sink is the selected output. -/
inductive Path (edge : Nat → Nat → Prop) (sink : Nat) : Nat → List Nat → Prop where
  | stop : Path edge sink sink []
  | step {a b rest} : a ≠ sink → edge a b → Path edge sink b rest →
      Path edge sink a (b :: rest)

def first (shared : Nat → Bool) (sink : Nat) (a : Nat) : List Nat → Nat
  | [] => if shared a then a else sink
  | b :: rest => if shared a then a else first shared sink b rest

theorem first_unique {edge : Nat → Nat → Prop} {sink : Nat} {shared : Nat → Bool}
    (functional : ∀ a, shared a = false → ∀ b c, edge a b → edge a c → b = c)
    {a : Nat} {xs ys : List Nat} (p : Path edge sink a xs) (q : Path edge sink a ys) :
    first shared sink a xs = first shared sink a ys := by
  induction p generalizing ys with
  | stop =>
    cases q with
    | stop => rfl
    | step hn _ _ => exact False.elim (hn rfl)
  | @step a b rest hn he tail ih =>
    cases q with
    | stop => exact False.elim (hn rfl)
    | @step _ c rs _ hq tq =>
      cases h : shared a with
      | true => simp [first,h]
      | false =>
        have eq := functional a h b c he hq
        subst c
        simpa [first,h] using ih tq

theorem first_is_site {edge : Nat → Nat → Prop} {sink : Nat} {shared : Nat → Bool}
    {a : Nat} {xs : List Nat} (p : Path edge sink a xs) :
    first shared sink a xs = sink ∨ shared (first shared sink a xs) = true := by
  induction p with
  | stop => simp [first]
  | @step a b rest hn he tail ih =>
    cases ha : shared a <;> simp_all [first]

theorem first_on_path {edge : Nat → Nat → Prop} {sink : Nat} {shared : Nat → Bool}
    {a : Nat} {xs : List Nat} (p : Path edge sink a xs) :
    first shared sink a xs ∈ a :: xs := by
  induction p with
  | stop => simp [first]
  | @step a b rest hn he tail ih =>
    cases ha : shared a with
    | true => simp [first,ha]
    | false => exact List.mem_cons_of_mem _ (by simpa [first,ha] using ih)

theorem all_after {edge : Nat → Nat → Prop} {sink : Nat}
    (chrono : ∀ a b, edge a b → a < b)
    {a : Nat} {xs : List Nat} (p : Path edge sink a xs) :
    ∀ v ∈ xs, a < v := by
  induction p with
  | stop => simp
  | @step a b rest _ he _ ih =>
    intro v hv
    rcases List.mem_cons.mp hv with rfl | h
    · exact chrono a _ he
    · exact Nat.lt_trans (chrono a b he) (ih _ h)

/-- A future-classified raw cannot occur in the cone of an earlier shared site. -/
theorem first_le_shared {edge : Nat → Nat → Prop} {sink : Nat} {shared : Nat → Bool}
    (chrono : ∀ a b, edge a b → a < b) {a gate : Nat} {xs : List Nat}
    (p : Path edge sink a xs) (hit : gate ∈ a :: xs) (sg : shared gate = true) :
    first shared sink a xs ≤ gate := by
  induction p with
  | stop => simp_all [first]
  | @step a b rest hn he tail ih =>
    rcases List.mem_cons.mp hit with h | h
    · subst gate
      simp [first,sg]
    · cases ha : shared a with
      | false => simpa [first,ha] using ih h
      | true =>
        simpa [first,ha] using Nat.le_of_lt (all_after chrono (Path.step hn he tail) _ h)

noncomputable def owner (edge : Nat → Nat → Prop) (sink : Nat) (shared : Nat → Bool)
    (a : Nat) (live : ∃ xs, Path edge sink a xs) : Nat :=
  first shared sink a live.choose

theorem owner_eq {edge : Nat → Nat → Prop} {sink : Nat} {shared : Nat → Bool}
    (functional : ∀ a, shared a = false → ∀ b c, edge a b → edge a c → b = c)
    {a : Nat} (live : ∃ xs, Path edge sink a xs) {xs : List Nat} (p : Path edge sink a xs) :
    owner edge sink shared a live = first shared sink a xs :=
  first_unique functional live.choose_spec p

end Petersen9822.FirstSite
