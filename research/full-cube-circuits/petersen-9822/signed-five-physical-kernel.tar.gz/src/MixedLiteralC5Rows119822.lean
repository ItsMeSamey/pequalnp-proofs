import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row33 : row 1053820 = true := by decide +kernel
theorem row34 : row 1183856 = true := by decide +kernel
theorem row35 : row 1184378 = true := by decide +kernel
end Research.LiteralC5.Table
