import Not9822PotentialStage03

-- Not9822ControlledDebit
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor

structure ControlledStep {n : Nat} (orig cut : Fin n → Wire Row) (rewire : Fin n → Fin n)
    (g : Pins n) : Prop where
  op : ∃ b l r o,
    orig g.id = signed o (combine b (signed l (orig g.left)) (signed r (orig g.right))) ∧
    cut g.id = signed o (combine b (signed l (cut (rewire g.left))) (signed r (cut (rewire g.right))))

private def applySign (s x : Bool) := if s then !x else x

private theorem step_relation {n : Nat} {orig cut : Fin n → Wire Row} {rewire : Fin n → Fin n}
    {g : Pins n} (h : ControlledStep orig cut rewire g) (row : Row) :
    SignedEquation (fun v => orig v row) (fun v => cut v row) rewire g := by
  obtain ⟨b,l,r,o,hO,hC⟩ := h.op
  refine ⟨fun x y => applySign o (if b then applySign l x || applySign r y
    else applySign l x && applySign r y), ?_, ?_⟩
  · dsimp only; rw [hO]; cases b <;> cases l <;> cases r <;> cases o <;> rfl
  · dsimp only; rw [hC]; cases b <;> cases l <;> cases r <;> cases o <;> rfl

theorem controlled_pentagon (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) {n : Nat} (orig cut : Fin n → Wire Row)
    (gs : List (Pins n)) (out : Fin n) (S T : Finset (Fin n))
    (order : Chrono S gs T) (result : out ∈ T)
    (k : Fin n → Kind) (pick default : Fin n → Bool) (rewire : Fin n → Fin n)
    (extra : List (Fin n × Fin n))
    (safe : ∀ v, rewire v = v ∨ rewire v ∈ S)
    (same : ∀ v, pick v = false → rewire v = v)
    (fixed : ∀ v, pick v = true → k (rewire v) = .fixed ∧ cut (rewire v) = fun _ => default v)
    (listed : ∀ v, (extra.map Prod.fst).count v = if pick v then 1 else 0)
    (selectedGate : ∀ v, pick v = true → k v = .gate ∧ v ∈ T)
    (freshUnique : (extra.map Prod.snd).Nodup)
    (fresh : ∀ v ∈ extra.map Prod.snd, v ∉ gs.flatMap pins ++ [out] ∧ pick v = false ∧ k v = .gate)
    (ids : ((monitored gs out rewire extra).1.map Pins.id).Nodup)
    (kinds : ∀ v, k v = .gate ↔ v ∈ (monitored gs out rewire extra).1.map Pins.id)
    (const : ∀ v, k v = .fixed → Constant (cut v))
    (ops : ∀ g ∈ gs, ControlledStep orig cut rewire g)
    (alarmEq : ∀ g ∈ (alarmGates (rewire out) extra).1, ∀ row,
      cut g.id row = (cut g.left row || (cut g.right row != default g.right)))
    (raw : ∀ v ∈ S, orig v = cut v)
    (source : ∀ v ∈ S, Available true ((varsX 313).map observe) (cut v))
    (computes : orig out = observe pentagon)
    (neg : ∀ row, orig out row = false → ∀ v, pick v = true → orig v row = default v) :
    8 ≤ ∑ v, if pick v then 0 else charge (k v) ((gs.flatMap pins ++ [out]).count v) := by
  classical
  have covered (v : Fin n) : pick v = true ↔ v ∈ extra.map Prod.fst := by
    rw [←List.count_pos_iff,listed]
    cases pick v <;> decide
  obtain ⟨V,plan,last⟩ := monitored_schedule order result rewire safe extra
    (fun e he => (selectedGate _ ((covered e.1).mpr (List.mem_map_of_mem he))).2)
  have valid (g : Pins n) (hg : g ∈ (monitored gs out rewire extra).1) : Realizes cut g := by
    rcases List.mem_append.mp hg with routedGate | appended
    · obtain ⟨g0,mem,rfl⟩ := List.mem_map.mp routedGate
      obtain ⟨b,l,r,o,_,h⟩ := (ops g0 mem).op
      exact ⟨b,l,r,o,h⟩
    · refine ⟨true,false,default g.right,false,funext (fun row => ?_)⟩
      rw [alarmEq _ appended row]
      cases h : default g.right <;> cases z : cut g.right row <;> simp [signed,combine,inv,h,z]
  have computesPentagon : cut (monitored gs out rewire extra).2 = observe pentagon := by
    rw [←computes]
    funext row
    have monitorEq := alarm_correct order result (fun v => orig v row) (fun v => cut v row)
      rewire pick default extra covered (fun g hg => step_relation (ops g hg) row)
      (fun v hv => congrFun (raw v hv) row) same (fun v hv => congrFun (fixed v hv).2 row)
      (fun v hv => (selectedGate v hv).2) (neg row)
    exact (alarm_eval (fun v => cut v row) default (rewire out) extra
      (fun g hg => alarmEq g hg row)).trans monitorEq
  have debit := pentagon_debit c5Prior cut _ k _ S V plan last valid source computesPentagon ids kinds const
  rw [monitor_charge k pick gs out rewire extra same (fun v h => (fixed v h).1) listed
    (fun v h => (selectedGate v h).1) freshUnique fresh] at debit
  exact debit

end Petersen9822.Potential

-- Not9822Populate
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine

def SignedOp.apply {R : Type} (o : SignedOp) (a b : Wire R) : Wire R :=
  signed o.outNeg (combine o.isOr (signed o.leftNeg a) (signed o.rightNeg b))

theorem populate {n : Nat} {R : Type} (op : Fin n → SignedOp) (start : Fin n → Wire R)
    {gs : List (Pins n)} {S T : Finset (Fin n)} (schedule : Chrono S gs T)
    (once : (gs.map Pins.id).Nodup) (fresh : ∀ g ∈ gs, g.id ∉ S) :
    ∃ result : Fin n → Wire R, (∀ v ∈ S, result v = start v) ∧
      ∀ g ∈ gs, result g.id = (op g.id).apply (result g.left) (result g.right) := by
  classical
  induction schedule generalizing start with
  | done => exact ⟨start,fun _ _ => rfl,by simp⟩
  | @step S T g gs hl hr tail ih =>
    obtain ⟨uniq,later⟩ := List.nodup_cons.mp once
    let next := Function.update start g.id ((op g.id).apply (start g.left) (start g.right))
    have r := ih next later (by
      intro q hq hmem
      rcases Finset.mem_insert.mp hmem with eq | old
      · exact uniq (eq ▸ List.mem_map_of_mem (f:=Pins.id) hq)
      · exact fresh q (List.mem_cons_of_mem _ hq) old)
    obtain ⟨result,agrees,output⟩ := r
    have preserve (v : Fin n) (hv : v ∈ S) : result v = start v := by
      have ne : v ≠ g.id := by intro eq; exact fresh g List.mem_cons_self (eq ▸ hv)
      simpa [next,ne] using agrees v (Finset.mem_insert_of_mem hv)
    refine ⟨result,preserve,?_⟩
    intro q hq
    rcases List.mem_cons.mp hq with eqg | hq
    · subst q
      have eq := agrees g.id (Finset.mem_insert_self _ _)
      simpa [next,preserve _ hl,preserve _ hr] using eq
    · exact output q hq

theorem build_control_values {n : Nat} (orig : Fin n → Wire Row) (origOp newOp : Fin n → SignedOp)
    (gs : List (Pins n)) (out : Fin n) (S T : Finset (Fin n))
    (order : Chrono S gs T) (result : out ∈ T)
    (rewire : Fin n → Fin n) (extra : List (Fin n × Fin n))
    (safe : ∀ v, rewire v = v ∨ rewire v ∈ S) (watched : ∀ e ∈ extra, e.1 ∈ T)
    (ids : ((monitored gs out rewire extra).1.map Pins.id).Nodup)
    (fresh : ∀ g ∈ (monitored gs out rewire extra).1, g.id ∉ S)
    (original : ∀ g ∈ gs, orig g.id = (origOp g.id).apply (orig g.left) (orig g.right))
    (oldOps : ∀ g ∈ gs, newOp g.id = origOp g.id) (default : Fin n → Bool)
    (alarmOps : ∀ g ∈ (alarmGates (rewire out) extra).1,
      newOp g.id = ⟨true,false,default g.right,false⟩) :
    ∃ cut : Fin n → Wire Row, (∀ v ∈ S, cut v = orig v) ∧
      (∀ g ∈ gs, ControlledStep orig cut rewire g) ∧
      ∀ g ∈ (alarmGates (rewire out) extra).1, ∀ row,
        cut g.id row = (cut g.left row || (cut g.right row != default g.right)) := by
  obtain ⟨V,plan,_⟩ := monitored_schedule order result rewire safe extra watched
  obtain ⟨cut,base,writes⟩ := populate newOp orig plan ids fresh
  refine ⟨cut,base,?_,?_⟩
  · intro g hg
    have mem : routed rewire g ∈ (monitored gs out rewire extra).1 :=
      List.mem_append_left _ (List.mem_map_of_mem hg)
    have eq := writes _ mem
    change cut g.id = (newOp g.id).apply (cut (rewire g.left)) (cut (rewire g.right)) at eq
    rw [oldOps g hg] at eq
    exact ⟨(origOp g.id).isOr,(origOp g.id).leftNeg,(origOp g.id).rightNeg,(origOp g.id).outNeg,
      original g hg,eq⟩
  · intro g hg row
    have mem : g ∈ (monitored gs out rewire extra).1 := List.mem_append_right _ hg
    have eq := writes g mem
    rw [alarmOps g hg] at eq
    rw [eq]
    cases hh : default g.right <;> cases hb : cut g.right row <;>
      simp [SignedOp.apply,signed,combine,inv,hh,hb]

end Petersen9822.Potential

-- Not9822Layout
namespace Petersen9822.Potential

abbrev Slot := Fin 32
def seed : Finset Slot := Finset.univ.filter (fun v => v.val < 10 ∨ v.val = 25 ∨ v.val = 26)

def gateSlot (i : Fin 15) : Slot := ⟨10+i.val,by omega⟩
def rawSlot (i : Fin 10) : Slot := ⟨i.val,by omega⟩
def alarmSlot (i : Fin 4) : Slot := ⟨27+i.val,by omega⟩
def initialKind (v : Slot) : Kind := if v.val < 10 then .raw else if v.val < 25 then .gate else .fixed
def C5 (v : Slot) : Bool := (313 : Nat).testBit v.val
def withAlarms (newIds : List Slot) (v : Slot) : Kind :=
  if v ∈ newIds then .gate else onFace (initialKind) C5 v

def outside : Finset Slot := {1,2,6,7,9}
theorem outside_card : outside.card = 5 := by decide +kernel
theorem outside_roles : ∀ v ∈ outside, initialKind v = .raw ∧ C5 v = false := by decide +kernel
theorem initial_gate_count : (∑ v : Slot, if initialKind v = .gate then 1 else 0) = 15 := by decide +kernel
theorem seed_legal : ∀ v : Slot, v.val < 10 → v ∈ seed := by decide +kernel
theorem gate_slots : (List.ofFn gateSlot).Nodup := by decide +kernel
theorem ids_match_kind : ∀ v : Slot, initialKind v = .gate ↔ v ∈ List.ofFn gateSlot := by decide +kernel

def fixedSlot (b : Bool) : Slot := if b then 26 else 25
def routeToFixed (pick default : Slot → Bool) (v : Slot) := if pick v then fixedSlot (default v) else v

theorem fixed_in_seed (b : Bool) : fixedSlot b ∈ seed := by cases b <;> decide +kernel
theorem route_safe (pick default : Slot → Bool) (v : Slot) :
    routeToFixed pick default v = v ∨ routeToFixed pick default v ∈ seed := by
  cases h : pick v <;> simp [routeToFixed,h,fixed_in_seed]

def window {n : Nat} (atIndex : Nat → Pins n) (start : Nat) : Nat → List (Pins n)
  | 0 => []
  | len+1 => atIndex start :: window atIndex (start+1) len

theorem window_plan {n : Nat} (atIndex : Nat → Pins n) (start len : Nat) (base : Finset (Fin n))
    (below : ∀ v : Fin n, v.val < start → v ∈ base)
    (loc : ∀ j, start ≤ j → j < start+len → (atIndex j).id.val = j ∧
      (atIndex j).left.val < j ∧ (atIndex j).right.val < j) :
    ∃ final, Chrono base (window atIndex start len) final ∧ ∀ v : Fin n, v.val < start+len → v ∈ final := by
  induction len generalizing start base with
  | zero => exact ⟨base,.done _,by simpa using below⟩
  | succ len ih =>
    obtain ⟨idEq, hl, hr⟩ := loc start (Nat.le_refl _) (by omega)
    let next := insert (atIndex start).id base
    have more (v : Fin n) (hv : v.val < start+1) : v ∈ next := by
      by_cases old : v.val < start
      · exact Finset.mem_insert_of_mem (below _ old)
      · have eq : v = (atIndex start).id := Fin.ext (by omega)
        simp [next,eq]
    obtain ⟨final,tail,endBound⟩ := ih (start+1) next more
      (fun j lo hi => loc j (by omega) (by omega))
    exact ⟨final,.step (below _ hl) (below _ hr) tail,fun v hv => endBound v (by omega)⟩

theorem window_length {n} (f : Nat → Pins n) (s k : Nat) : (window f s k).length = k := by
  induction k generalizing s with
  | zero => rfl
  | succ k ih => simp [window,ih]

theorem map_window {n} (f : Nat → Pins n) (s k : Nat) (h : ∀ j, s ≤ j → j < s+k → (f j).id.val = j) :
    ((window f s k).map (fun g => g.id.val)) = List.range' s k := by
  induction k generalizing s with
  | zero => rfl
  | succ k ih =>
    rw [window,List.map_cons,h s (by omega) (by omega),
      ih (s+1) (fun j lo hi => h j (by omega) (by omega))]
    rfl

end Petersen9822.Potential
