import SignedLogicalLayer4
namespace Petersen9822
inductive RootClosure : List (List Nat × Nat) → Prop where
  | nil : RootClosure []
  | cons {js r rest} : (¬ Placement js r) → RootClosure rest → RootClosure ((js,r)::rest)

theorem RootClosure.for_member {roots : List (List Nat × Nat)} (h : RootClosure roots)
    {js : List Nat} {r : Nat} (hm : (js,r) ∈ roots) : ¬ Placement js r := by
  induction h with
  | nil => simp at hm
  | cons no tail ih =>
    rcases List.mem_cons.mp hm with eq | mem
    · cases eq
      exact no
    · exact ih mem

def normalizedRoots : List (List Nat × Nat) := [([0, 1, 2],48), ([0, 2, 1],48), ([1, 0, 2],48), ([0, 1, 2],272), ([0, 2, 1],272), ([1, 0, 2],272), ([0, 1, 2],288), ([0, 2, 1],288), ([1, 0, 2],288), ([0, 1, 2],304), ([0, 2, 1],304), ([1, 0, 2],304), ([0, 1, 2, 3],48), ([0, 1, 3, 2],48), ([0, 2, 1, 3],48), ([0, 2, 3, 1],48), ([0, 3, 1, 2],48), ([0, 3, 2, 1],48), ([1, 0, 2, 3],48), ([1, 0, 3, 2],48), ([1, 3, 0, 2],48), ([3, 0, 1, 2],48), ([3, 0, 2, 1],48), ([3, 1, 0, 2],48), ([0, 1, 2, 3],272), ([0, 1, 3, 2],272), ([0, 2, 1, 3],272), ([0, 2, 3, 1],272), ([0, 3, 1, 2],272), ([0, 3, 2, 1],272), ([1, 0, 2, 3],272), ([1, 0, 3, 2],272), ([1, 3, 0, 2],272), ([3, 0, 1, 2],272), ([3, 0, 2, 1],272), ([3, 1, 0, 2],272), ([0, 1, 2, 3],288), ([0, 1, 3, 2],288), ([0, 2, 1, 3],288), ([0, 2, 3, 1],288), ([0, 3, 1, 2],288), ([0, 3, 2, 1],288), ([1, 0, 2, 3],288), ([1, 0, 3, 2],288), ([1, 3, 0, 2],288), ([3, 0, 1, 2],288), ([3, 0, 2, 1],288), ([3, 1, 0, 2],288)]
theorem normalizedClosed : RootClosure normalizedRoots :=
  .cons node_48_012 (.cons node_48_021 (.cons node_48_102 (.cons node_272_012 (.cons node_272_021 (.cons node_272_102 (.cons node_288_012 (.cons node_288_021 (.cons node_288_102 (.cons node_304_012 (.cons node_304_021 (.cons node_304_102 (.cons node_48_0123 (.cons node_48_0132 (.cons node_48_0213 (.cons node_48_0231 (.cons node_48_0312 (.cons node_48_0321 (.cons node_48_1023 (.cons node_48_1032 (.cons node_48_1302 (.cons node_48_3012 (.cons node_48_3021 (.cons node_48_3102 (.cons node_272_0123 (.cons node_272_0132 (.cons node_272_0213 (.cons node_272_0231 (.cons node_272_0312 (.cons node_272_0321 (.cons node_272_1023 (.cons node_272_1032 (.cons node_272_1302 (.cons node_272_3012 (.cons node_272_3021 (.cons node_272_3102 (.cons node_288_0123 (.cons node_288_0132 (.cons node_288_0213 (.cons node_288_0231 (.cons node_288_0312 (.cons node_288_0321 (.cons node_288_1023 (.cons node_288_1032 (.cons node_288_1302 (.cons node_288_3012 (.cons node_288_3021 (.cons node_288_3102 (.nil))))))))))))))))))))))))))))))))))))))))))))))))
theorem no_normalized_placement {js : List Nat} {r : Nat}
    (mem : (js,r) ∈ normalizedRoots) : ¬ Placement js r :=
  normalizedClosed.for_member mem
end Petersen9822
#print axioms Petersen9822.no_normalized_placement
