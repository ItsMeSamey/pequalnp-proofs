import OR9822H2PairShrink
import OR9822H2DemandOrder
namespace Research.Graph9822H2Check.SeedCache
open Research.Graph9822OneHidden (meets)

def required (t e : Nat) (use : Bool) := if use then t &&& (8191 ^^^ e) else t
def added (n : Nat) (use : Bool) := if use then n else 0
structure SeedShape (e n t : Nat) : Prop where
  paths : ∃ a b x : Nat,∃ attach root : Bool,
    meets a b=false ∧ x<1024 ∧ sub t (rawPos b)=true ∧
    sub (required t e attach) (rawPos a)=true ∧
    sub (required t e root) (rawPos x)=true ∧
    meets (rawNeg x ||| added n root) ((rawNeg a ||| added n attach) &&& rawNeg b)=false

theorem required_le {w t e e' : Nat} (small : w<8192) (wt : sub w t=true)
    (better : sub (w &&& e) e'=true) (use : Bool) :
    sub (required w e' use) (required t e use)=true := by
  cases use with
  | false => exact wt
  | true =>
    apply (subset_bits ..).2
    intro i on
    change (w &&& (8191 ^^^ e')).testBit i=true at on
    rw [Nat.testBit_and,Bool.and_eq_true] at on
    have wBit := on.1
    have tBit := (subset_bits ..).1 wt i wBit
    have he := (subset_bits ..).1 better i
    have idx : i<13 := by
      by_contra! high
      have off := Nat.testBit_lt_two_pow (lt_of_lt_of_le small
        (show 8192≤2^i from Nat.pow_le_pow_right (by decide : 0<(2:Nat)) high))
      exact Bool.noConfusion (wBit.symm.trans off)
    have mask : (8191:Nat).testBit i=true := by
      change (2^13-1 : Nat).testBit i=true
      rw [Nat.testBit_two_pow_sub_one]
      simp [idx]
    cases a : e.testBit i <;> cases b : e'.testBit i <;> simp_all [required]

theorem shape_below {w t e n e' n' : Nat} (small : w<8192)
    (wt : sub w t=true) (ep : sub (w &&& e) e'=true)
    (nb : sub n' n=true) (actual : SeedShape e n t) : SeedShape e' n' w := by
  obtain ⟨a,b,x,u,v,dis,sz,rb,la,cx,cold⟩ := actual.paths
  refine ⟨a,b,x,u,v,dis,sz,sub_trans wt rb,sub_trans (required_le small wt ep u) la,
    sub_trans (required_le small wt ep v) cx,?_⟩
  apply (empty_overlap ..).2
  intro i on
  have dn := (subset_bits ..).1 nb i
  have no := (empty_overlap ..).1 cold i
  cases u <;> cases v <;> simp only [added,ite_true,ite_false,Nat.testBit_or,Nat.testBit_and,
    Nat.zero_testBit,Bool.or_false,Bool.or_eq_true,Bool.and_eq_true] at on no ⊢ <;> grind

end Research.Graph9822H2Check.SeedCache
