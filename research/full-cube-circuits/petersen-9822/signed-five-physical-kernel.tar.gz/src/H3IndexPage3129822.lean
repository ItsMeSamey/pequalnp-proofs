import H3SinglePage3129822
import H3GlobalRootIndex9822
namespace Research.Graph9822Planes
theorem frozenPaid312 : PaidKeys frozen312 := by
  have e : rootsPage312 = frozen312 := by decide +kernel
  rw [← e]
  exact allPage312
end Research.Graph9822Planes
