import H3SinglePage609822
import H3GlobalRootIndex9822
namespace Research.Graph9822Planes
theorem frozenPaid60 : PaidKeys frozen60 := by
  have e : rootsPage60 = frozen60 := by decide +kernel
  rw [← e]
  exact allPage60
end Research.Graph9822Planes
