import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle53 : List ModeRow := [(6884864,[4926,53713,45928,49311,53558,17199,16871,16829],[45928,863,49463,4601,4815,16871,16799,45731,1017,21955])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle53 : batchSingle53.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
