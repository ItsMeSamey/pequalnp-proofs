import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle37 : List ModeRow := [(5031046,[37734,3870,17877,18867,20291,1017,27427,1530,13142],[37734,3198,831,27427,447,20291,3135])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle37 : batchSingle37.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
