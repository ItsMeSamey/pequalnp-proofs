import OR9822H1CoverageBits
import OR9822H1GrantFold
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check Research.Graph9822OneHidden Research.Graph9822.FreeOR Research.Graph9822TwoHidden

theorem vertex_member1 {v : Nat} {c : List Nat} (h : v∈c) : (vertexMask c).testBit v=true := by
  apply (assembled_bit1 c 0 bit v).mpr
  exact Or.inr ⟨v,h,by simp [bit,Nat.testBit_two_pow]⟩

def extra1 (p : Product) := positive (packed1 p) &&& rawPos (freeRaw (negative (packed1 p)))
def extra_loose1 (p : Product) (e : Fin 13) (hidden : HPos1 p e)
    (safe : ∃ v,hasPos1 e v ∧ safepoint (HNeg1 p) v) : (extra1 p).testBit e.val=true := by
  obtain ⟨v,hot,ok⟩ := safe
  simp [extra1,(packed1_pos p e).mpr hidden,raw_hit1 (safe_free1 p v ok) hot]

theorem generous1 {p : Product} {term : Fin 4 → Product} {center : Fin 4 → Option V1}
    (grants : ∀ k,Grant1 (rawArms1 (term k)) (HNeg1 p) hasPos1 (HPos1 p) (center k))
    (cover : ∀ e,∃ k,(rawArms1 (term k)).accepts (fun l e => oneRow (hasPos1 e) (HPos1 p e) l) e)
    (c : List Nat) (contains : ∀ k v,center k=some v → v.val∈c) :
    ∀ e : Fin 13,(extra1 p ||| rawPos (vertexMask c)).testBit e.val=true := by
  intro e
  obtain ⟨k,hit⟩ := cover e
  rcases (grants k).loose e hit with ⟨v,eq,on⟩|⟨on,safe⟩
  · simp [raw_hit1 (vertex_member1 (contains k v eq)) on]
  · simp [extra_loose1 p e on safe]

theorem indispensable1 {p : Product} {term : Fin 4 → Product} {center : Fin 4 → Option V1}
    (grants : ∀ k,Grant1 (rawArms1 (term k)) (HNeg1 p) hasPos1 (HPos1 p) (center k))
    (cover : ∀ e,∃ k,(rawArms1 (term k)).accepts (fun l e => oneRow (hasPos1 e) (HPos1 p e) l) e)
    (c : List Nat) (contains : ∀ k v,center k=some v → v.val∈c)
    (reject : rejects c (packed1 p)=true) :
    ∀ v : V1,v.val∈c → ∃ k,center k=some v := by
  classical
  intro v hv
  by_contra! none
  have keep (k) (w : V1) (eq : center k=some w) : w.val∈c.erase v.val := by
    have ne : w.val≠v.val := by
      intro same
      have id : w=v := Fin.ext same
      exact none k (id ▸ eq)
    exact (List.mem_erase_of_ne ne).mpr (contains k w eq)
  have all := generous1 grants cover (c.erase v.val) keep
  have full := low13_full (low13_or (low13_andr _ (low13_raw _)) (low13_raw _)) all
  have missing := List.all_eq_true.mp (Bool.and_eq_true_iff.mp reject).1 v.val hv
  change (extra1 p ||| rawPos (vertexMask (c.erase v.val)) != 8191)=true at missing
  simp at missing
  exact missing full
end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.indispensable1
