import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle8 : List ModeRow := [(389186,[49711,24791,5369,15011,1275,5550,5903,735,11319,12967,10471],[49711,5183,10471,5903,255,1151])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle8 : batchSingle8.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
