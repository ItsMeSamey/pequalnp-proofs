import MixedLiteralC5Eval9822
import MixedLiteralC5Val9822
namespace Research.LiteralC5.Table

def recipe {n : Nat} (v : Fin n → Nat) (s : Fin n → Bool) : List Nat :=
  ((List.finRange n).filter s).map v
def addCol {n : Nat} (v : Fin n → Nat) (a b : Fin n → Bool) : Fin (n+1) → Nat :=
  Fin.lastCases (val (recipe v a) ||| val (recipe v b)) v

private theorem fold_bit (l : List Nat) (z i : Nat) :
    (l.foldl Nat.land z).testBit i = (z.testBit i && l.all (fun c => c.testBit i)) := by
  induction l generalizing z with
  | nil => simp
  | cons h t ih => simp [ih,Nat.testBit_and,Bool.and_assoc]

theorem recipe_bit {n} (v : Fin n → Nat) (s : Fin n → Bool) (i : Nat)
    (on : live.testBit i=true) :
    (val (recipe v s)).testBit i = prod s (fun j => (v j).testBit i) := by
  rw [val,fold_bit,on,Bool.true_and]
  apply Bool.eq_iff_iff.mpr
  simp [recipe,prod,List.all_eq_true]

theorem add_bit {n} (v : Fin n → Nat) (a b : Fin n → Bool) (i : Nat)
    (on : live.testBit i=true) (j : Fin (n+1)) :
    (addCol v a b j).testBit i = step a b (fun k => (v k).testBit i) j := by
  refine Fin.lastCases ?_ (fun k => ?_) j
  · simp [addCol,step,Nat.testBit_or,recipe_bit, on]
  · simp [addCol,step]

private def rawCol (i : Fin 6) : Nat := raws[i.val]!
private def rowX (r : Nat) (i : Fin 5) := r.testBit i.val

private theorem raw_cases : ∀ i : Fin 6, rawCol i ∈ raws := by decide +kernel
private theorem rows : ∀ r : Fin 32,
    (pos.testBit r.val=true → live.testBit r.val=true ∧ cycle (rowX r.val)=true) ∧
    (neg.testBit r.val=true → live.testBit r.val=true ∧ cycle (rowX r.val)=false) ∧
    (live.testBit r.val=true → ∀ j, (rawCol j).testBit r.val=lift (rowX r.val) j) := by
  decide +kernel

private theorem recipe_sub {n} {l : List Nat} {v : Fin n → Nat}
    (h : ∀ i, v i ∈ l) (s : Fin n → Bool) : recipe v s ⊆ l := by
  intro x hx
  obtain ⟨i,_,rfl⟩ := List.mem_map.mp hx
  exact h i

private theorem add_mem {n} {l : List Nat} {v : Fin n → Nat}
    (h : ∀ i, v i∈l) (a b : Fin n → Bool) (j : Fin (n+1)) :
    addCol v a b j ∈ (val (recipe v a) ||| val (recipe v b)) :: l := by
  refine Fin.lastCases ?_ (fun k => ?_) j
  · simp [addCol]
  · simp [addCol,h]

theorem recipes_of_eval3 (a b : Fin 6 → Bool) (c d : Fin 7 → Bool) (e f : Fin 8 → Bool)
    (g : Fin 9 → Bool) (fit : ∀ x,eval3 a b c d e f g x=cycle x) :
    ∃ A B C D E F G : List Nat, A⊆raws ∧ B⊆raws ∧
      C⊆(val A ||| val B)::raws ∧ D⊆(val A ||| val B)::raws ∧
      E⊆(val C ||| val D)::(val A ||| val B)::raws ∧
      F⊆(val C ||| val D)::(val A ||| val B)::raws ∧
      G⊆(val E ||| val F)::(val C ||| val D)::(val A ||| val B)::raws ∧
      (val G &&& pos)=pos ∧ (val G &&& neg)=0 := by
  let v := addCol rawCol a b
  let w := addCol v c d
  let t := addCol w e f
  refine ⟨recipe rawCol a,recipe rawCol b,recipe v c,recipe v d,recipe w e,recipe w f,
    recipe t g,recipe_sub raw_cases _,recipe_sub raw_cases _,
    recipe_sub (add_mem raw_cases a b) _,recipe_sub (add_mem raw_cases a b) _,
    recipe_sub (add_mem (add_mem raw_cases a b) c d) _,
    recipe_sub (add_mem (add_mem raw_cases a b) c d) _,
    recipe_sub (add_mem (add_mem (add_mem raw_cases a b) c d) e f) _,?_⟩
  have output (r : Fin 32) (on : live.testBit r.val=true) :
      (val (recipe t g)).testBit r.val = cycle (rowX r.val) := by
    have raw := funext ((rows r).2.2 on)
    have va : (fun i => (v i).testBit r.val)=step a b (lift (rowX r.val)) := by
      rw [←raw]; exact funext (add_bit rawCol a b r.val on)
    have wa := funext (add_bit v c d r.val on)
    have ta := funext (add_bit w e f r.val on)
    rw [recipe_bit _ _ _ on,ta,wa,va]
    exact fit _
  have small (mask : Nat) (bd : mask < (2 : Nat) ^ 32) (i : Nat) (hi : 32 ≤ i) :
      mask.testBit i=false := Nat.testBit_eq_false_of_lt (lt_of_lt_of_le bd (Nat.pow_le_pow_right (by decide) hi))
  constructor
  · apply Nat.eq_of_testBit_eq
    intro i
    rw [Nat.testBit_and]
    cases hp : pos.testBit i with
    | false => simp
    | true =>
      have lt : i<32 := by by_contra! hi; simp [small pos (by decide) i hi] at hp
      obtain ⟨on,yes⟩ := (rows ⟨i,lt⟩).1 hp
      simpa using (output ⟨i,lt⟩ on).trans yes
  · apply Nat.eq_of_testBit_eq
    intro i
    rw [Nat.testBit_and]
    cases hn : neg.testBit i with
    | false => simp
    | true =>
      have lt : i<32 := by by_contra! hi; simp [small neg (by decide) i hi] at hn
      obtain ⟨on,no⟩ := (rows ⟨i,lt⟩).2.1 hn
      simpa using (output ⟨i,lt⟩ on).trans no

end Research.LiteralC5.Table
#print axioms Research.LiteralC5.Table.recipes_of_eval3
