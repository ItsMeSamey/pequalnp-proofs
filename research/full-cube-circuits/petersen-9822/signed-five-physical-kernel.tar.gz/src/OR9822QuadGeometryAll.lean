import H2AllQuadShort9822
namespace Research.Graph9822H2Check

theorem all_quads (c : Nat) (small : c<50) : quadGood (quadTable[c]!)=true ∧
    ∀ i∈quadTable[c]!,∀ k∈quadTable[c]!,i<k → pairDom i k=true :=
  all_quad_short c small

end Research.Graph9822H2Check
#print axioms Research.Graph9822H2Check.all_quads
