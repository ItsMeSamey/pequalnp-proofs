import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle97 : List ModeRow := [(100957208,[45859,3315,28943,17471,25045,39139,25655,4447,18867],[45859,13367,39139,28943,21817,18867])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle97 : batchSingle97.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
