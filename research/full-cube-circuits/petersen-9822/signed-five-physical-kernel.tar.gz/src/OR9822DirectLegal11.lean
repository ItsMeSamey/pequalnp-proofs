import OR9822DirectCuts
namespace Research.Graph9822ProfileArithmetic.Direct
set_option maxRecDepth 10000 in
theorem legal11 : (List.range' 176 16).all cutsLegal=true := by decide +kernel
end Research.Graph9822ProfileArithmetic.Direct
