import Not9822CommonGuardTruth
namespace Petersen9822.DagCut

structure ReaderAt (d : Indexed) (raw partner : Nat) where
  id : Nat
  g : Gate
  read : d.get id = some g
  inputs : (g.left = raw ∧ g.right = partner) ∨ (g.right = raw ∧ g.left = partner)

theorem ReaderAt.after {d raw p} (a : ReaderAt d raw p) : p < a.id := by
  have bound := d.back a.id a.g a.read
  rcases a.inputs with h | h <;> omega

theorem readerAtOfGuard {d out raw} (c : FifteenCore d out) (a : RealGuard d out raw) (low : raw < 10) :
    Nonempty (ReaderAt d raw a.site) := by
  obtain ⟨xs,hp⟩ := d.live_raw out ⟨raw,low⟩ c.finalWire c.computes
  have liveRead {v xs} (p : Petersen9822.FirstSite.Path d.edge out v xs) (ne : v ≠ out) :
      ∃ j, d.edge v j := by
    cases p with
    | stop => exact False.elim (ne rfl)
    | step _ e _ => exact ⟨_,e⟩
  obtain ⟨j,g,h,side⟩ := liveRead hp (by have := c.lowerOut; change raw ≠ out; omega)
  refine ⟨⟨j,g,h,?_⟩⟩
  rcases side with l | r
  · exact Or.inl ⟨l,(a.sockets.left _ _ h (by rw [l]; exact Nat.testBit_two_pow_self)).1⟩
  · exact Or.inr ⟨r,(a.sockets.right _ _ h (by rw [r]; exact Nat.testBit_two_pow_self)).1⟩

def bypassEval (site readA readB : Nat) (pass : Bool) (row : Nat) : Tree → Bool
  | .raw n => row.testBit n
  | .gate n op l r =>
    let x := bypassEval site readA readB pass row l
    let y := bypassEval site readA readB pass row r
    if n = readA ∨ n = readB then
      op (if l.id = site then pass else x) (if r.id = site then pass else y)
    else op x y

def bypassValue (d : Indexed) (site readA readB : Nat) (pass : Bool) (n row : Nat) :=
  bypassEval site readA readB pass row (d.tree n)

theorem bypassAgree {d : Indexed} {site ra rb : Nat} {pass : Bool} {row : Nat} (n : Nat)
    (agree : wireValue d site row = pass ∨ n < ra ∧ n < rb) :
    bypassValue d site ra rb pass n row = wireValue d n row := by
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    cases hg : d.get n with
    | none => simp [bypassValue,wireValue,d.tree_none hg,bypassEval,Tree.term,Term.eval]
    | some g =>
      obtain ⟨l,r⟩ := d.back n g hg
      have desc (k : Nat) (lo : k < n) := ih k lo (agree.imp_right (fun h => ⟨Nat.lt_trans lo h.1,Nat.lt_trans lo h.2⟩))
      have x := desc g.left l
      have y := desc g.right r
      unfold bypassValue wireValue at x y ⊢
      simp only [d.tree_some hg,bypassEval,d.tree_id,Tree.term,Term.eval,x,y]
      by_cases mark : n = ra ∨ n = rb
      · have fixed := agree.resolve_right (by rcases mark with rfl | rfl <;> omega)
        have lift (k : Nat) : (if k = site then pass else (d.tree k).term.eval row.testBit) =
            (d.tree k).term.eval row.testBit := by
          by_cases eq : k = site <;> simp [eq,←fixed,wireValue]
        simp [mark,lift]
      · simp [mark]

theorem bypassOutput {d out} (c : FifteenCore d out) (a : RealGuard d out 1) (b : RealGuard d out 2)
    (same : a.site = b.site) (A : ReaderAt d 1 a.site) (B : ReaderAt d 2 a.site) (row : Nat) :
    edgeHit row = ((bypassValue d a.site A.id B.id (!a.block) out row) ||
      decide (bypassValue d a.site A.id B.id (!a.block) a.site row = a.block)) := by
  have keep := bypassAgree (d:=d) (site:=a.site) (pass:=!a.block) (row:=row) a.site (Or.inr ⟨A.after,B.after⟩)
  rw [keep]
  by_cases h : wireValue d a.site row = a.block
  · simp [h,commonBlockForcesOutput c a b same row h]
  · have pass : wireValue d a.site row = !a.block := by
      cases eq : wireValue d a.site row <;> cases hb : a.block <;> simp_all
    rw [bypassAgree out (Or.inl pass),←c.computes]
    simp [h]

end Petersen9822.DagCut
