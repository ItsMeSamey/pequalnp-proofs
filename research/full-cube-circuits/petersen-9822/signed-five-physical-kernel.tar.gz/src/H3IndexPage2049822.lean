import H3SinglePage2049822
import H3GlobalRootIndex9822
namespace Research.Graph9822Planes
theorem frozenPaid204 : PaidKeys frozen204 := by
  have e : rootsPage204 = frozen204 := by decide +kernel
  rw [← e]
  exact allPage204
end Research.Graph9822Planes
