import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle312 : List ModeRow := [(488685766,[60172,5438,41367,10415,19770,16799,32130,11443,22926,17849],[60172,43063,22926,5438,16799])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle312 : batchSingle312.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
