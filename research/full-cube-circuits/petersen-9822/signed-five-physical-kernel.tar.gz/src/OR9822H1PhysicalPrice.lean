import OR9822H1LooseCover
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check Research.Graph9822OneHidden Research.Graph9822.FreeOR
theorem packed1_negative_eq (p : Product) :
    negative (packed1 p)=rawNeg (armMask p.1) &&& rawNeg (armMask p.2) := by
  apply Nat.eq_of_testBit_eq
  intro i
  have off : (rawPos (armMask p.1) &&& rawPos (armMask p.2)).testBit (13+i)=false :=
    Nat.testBit_lt_two_pow (lt_of_lt_of_le
      (show rawPos (armMask p.1) &&& rawPos (armMask p.2)<8192 from
        lt_of_le_of_lt Nat.and_le_left (mask_lt1 _ _))
      (show 8192≤2^(13+i) from Nat.pow_le_pow_right (by decide : 0 < (2 : Nat)) (by omega : 13≤13+i)))
  have offL := low13_raw (armMask p.1) (i+13) (by omega)
  simp [negative,packed1,demand,Nat.testBit_shiftLeft,offL,Nat.add_comm]

theorem physical_prices1 (p : Product) (c : List Nat)
    (all : ∀ e : Fin 13,(extra1 p ||| rawPos (vertexMask c)).testBit e.val=true) :
    let t := 8191 ^^^ rawPos (vertexMask c)
    sub t (rawPos (armMask p.1))=true ∧ sub t (rawPos (armMask p.2))=true ∧
    sub t (rawPos (freeRaw (rawNeg (armMask p.1) &&& rawNeg (armMask p.2))))=true := by
  let t := 8191 ^^^ rawPos (vertexMask c)
  have needed (i : Nat) (hit : t.testBit i=true) : (extra1 p).testBit i=true := by
    by_cases hi : i<13
    · have mask : (8191:Nat).testBit i=true := by change (2^13-1:Nat).testBit i=true;rw [Nat.testBit_two_pow_sub_one];simp [hi]
      have off : (rawPos (vertexMask c)).testBit i=false := by
        cases b : (rawPos (vertexMask c)).testBit i <;> simp_all [t,mask]
      simpa [off] using all ⟨i,hi⟩
    · have off := low13_raw (vertexMask c) i (by omega)
      have mask : (8191:Nat).testBit i=false := by change (2^13-1:Nat).testBit i=false;rw [Nat.testBit_two_pow_sub_one];simp [hi]
      simp [t,mask,off] at hit
  have both (i : Nat) (hit : t.testBit i=true) :
      (rawPos (armMask p.1)).testBit i=true ∧ (rawPos (armMask p.2)).testBit i=true ∧
      (rawPos (freeRaw (negative (packed1 p)))).testBit i=true := by
    have z := needed i hit
    by_cases hi : i<13
    · change ((positive (packed1 p) &&& rawPos (freeRaw (negative (packed1 p)))).testBit i)=true at z
      rw [Nat.testBit_and,Bool.and_eq_true_iff] at z
      obtain ⟨pbit,fb⟩ := z
      have sem := (packed1_pos p ⟨i,hi⟩).mp pbit
      change (readArm (fullWire _) p.1 && readArm (fullWire _) p.2)=true at sem
      rw [read_arm_mask,read_arm_mask] at sem
      obtain ⟨l,r⟩ := Bool.and_eq_true_iff.mp sem
      exact ⟨(raw_pos_bit _ ⟨i,hi⟩).trans l,(raw_pos_bit _ ⟨i,hi⟩).trans r,fb⟩
    · have zero := low13_andr (positive (packed1 p)) (low13_raw (freeRaw (negative (packed1 p)))) i (by omega)
      change (extra1 p).testBit i=false at zero
      simp [zero] at z
  exact ⟨(subset_bits ..).mpr (fun i h => (both i h).1),
    (subset_bits ..).mpr (fun i h => (both i h).2.1),
    (subset_bits ..).mpr (fun i h => packed1_negative_eq p ▸ (both i h).2.2)⟩
end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.physical_prices1
