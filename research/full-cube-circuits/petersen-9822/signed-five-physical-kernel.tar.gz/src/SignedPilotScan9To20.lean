import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_0_273 : nodeCheck frozen 0 273 [273, 281] = true := by decide +kernel
theorem scan_0_280 : nodeCheck frozen 0 280 [280] = true := by decide +kernel
theorem scan_0_281 : nodeCheck frozen 0 281 [281] = true := by decide +kernel
theorem scan_0_288 : nodeCheck frozen 0 288 [288] = true := by decide +kernel
theorem scan_0_289 : nodeCheck frozen 0 289 [289] = true := by decide +kernel
theorem scan_0_296 : nodeCheck frozen 0 296 [296] = true := by decide +kernel
theorem scan_0_304 : nodeCheck frozen 0 304 [304, 305, 312, 313] = true := by decide +kernel
theorem scan_0_305 : nodeCheck frozen 0 305 [305, 313] = true := by decide +kernel
theorem scan_0_312 : nodeCheck frozen 0 312 [312, 313] = true := by decide +kernel
theorem scan_0_313 : nodeCheck frozen 0 313 [313] = true := by decide +kernel
theorem scan_0_336 : nodeCheck frozen 0 336 [336, 344] = true := by decide +kernel
theorem scan_0_344 : nodeCheck frozen 0 344 [344] = true := by decide +kernel
end Petersen9822
