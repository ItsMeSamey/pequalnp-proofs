import Not9822PotentialStage09
import Not9822GuardRolesCore

-- Not9822RepeatMask
namespace Petersen9822.Potential
open Petersen9822.DagCut
open Petersen9822.FirstSite
open PEqualNP.Outside.L_meta_9825.Engine

theorem three_monitor_off (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) (d : Indexed) (valid : Fifteen d) (out owner : Nat) (bound : out < 25)
    (which : owner ∈ ([1,2] : List Nat)) (ops : Nat → SignedOp)
    (signed : ∀ n g, d.get n = some g → ∀ a b, g.op a b = (ops n).bit a b)
    (compute : ∀ row, edgeHit row = wireValue d out row)
    (sink : ∀ a b, d.edge a b → a ≠ out)
    (live : ∀ v, 10 ≤ v → v < 25 → ∃ xs, Path d.edge out v xs)
    (watch : List Slot) (size : watch.length = 3) (unique : watch.Nodup)
    (real : ∀ v ∈ watch, v ∈ List.ofFn gateSlot ∧ fork d v.val = true) (default : Slot → Bool)
    (stable : ∀ row : Row, edgeHit (projectRow owner row) = false → ∀ v ∈ watch,
      wireValue d v.val (projectRow owner row) = default v) :
    ∀ v ∈ outside, fork d v.val = false := by
  classical
  have budget := monitored_floor c5Prior d valid out owner bound which ops signed compute 3 watch size unique
    (fun v h => (real v h).1) default stable
  have ideal : (fun s : Slot => watch.contains s) = fun s => decide (s ∈ watch.toFinset) := by
    funext s; simp
  rw [ideal] at budget
  have one := three_force_unique_off d valid out bound sink compute live watch.toFinset
    (by simpa [List.toFinset_card_of_nodup unique] using size)
    (fun v hv => real v (List.mem_toFinset.mp hv)) budget
  intro v hv
  cases h : fork d v.val
  · rfl
  · have two := fork_uses d valid out v.val h
    rw [slot_fin,one v hv] at two
    omega

private theorem tenCases : ∀ i : Fin 10,
    i.val = 0 ∨ i.val = 3 ∨ rawSlot i ∈ outside ∨ (304 : Nat).testBit i.val = true := by decide +kernel

theorem repeatedWithin458 (d : Indexed) (z : fork d 0 = false) (t : fork d 3 = false)
    (off : ∀ v ∈ outside, fork d v.val = false) : sub (pack (fork d)) 304 = true := by
  unfold sub
  apply beq_iff_eq.mpr
  apply Nat.eq_of_testBit_eq
  intro v
  rw [Nat.testBit_and,pack_bit]
  by_cases hv : v < 10
  · let i : Fin 10 := ⟨v,hv⟩
    rcases tenCases i with h|h|h|h
    · change v = 0 at h; subst v; simp [z]
    · change v = 3 at h; subst v; simp [t]
    · have no := off (rawSlot i) h
      change fork d v = false at no
      simp [no]
    · change (304 : Nat).testBit v = true at h; simp [h]
  · simp [hv]

theorem repeatedCard (d : Indexed) :
    (List.range 10).countP (pack (fork d)).testBit = (rawForks d).card := by
  classical
  let rawList : List Slot := List.ofFn rawSlot
  have nd : rawList.Nodup := by decide +kernel
  have set : rawList.toFinset = rawSlots := by decide +kernel
  have vals : rawList.map Fin.val = List.range 10 := by decide +kernel
  have eq : (rawList.map Fin.val).countP (pack (fork d)).testBit =
      rawList.countP (fun v => fork d v.val) := by
    rw [List.countP_map]
    apply List.countP_congr
    intro v hv
    have bound : ∀ v ∈ rawList, v.val < 10 := by decide +kernel
    simp [Function.comp_def,pack_bit,bound _ hv]
  rw [vals] at eq
  rw [eq]
  have card := nd.card_eq_countP (P := fun v => fork d v.val = true)
  have boolEq (b : Bool) : decide (b = true) = b := by cases b <;> rfl
  simpa only [set,rawForks,boolEq] using card.symm

end Petersen9822.Potential

-- Not9822OneOwnerOutput
namespace Petersen9822.DagCut
open Petersen9822.Potential
open Petersen9822.FirstSite

private theorem conflict_ordered (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) {d : Indexed} {out i j : Nat} (c : FifteenCore d out)
    (gi : RealGuard d out i) (gj : RealGuard d out j)
    (hi : i < 10) (hj : j < 10) (ij : (i,j) ∈ ([(1,2),(2,1)] : List (Nat × Nat)))
    (ci : assigned d out (fork d) i ≠ out) (cj : assigned d out (fork d) j ≠ out)
    (lt : assigned d out (fork d) j < assigned d out (fork d) i)
    (apart : gi.site ≠ gj.site) (cross : gi.site ≠ assigned d out (fork d) j) : False := by
  let qi := assigned d out (fork d) i
  let qj := assigned d out (fork d) j
  have pi : gi.site < qi := gi.beforeOwner c hi
  have pj : gj.site < qj := gj.beforeOwner c hj
  have before : qj < qi := lt
  obtain ⟨hotI,topI⟩ := internal_owner c hi ci
  obtain ⟨hotJ,topJ⟩ := internal_owner c hj cj
  change fork d qi = true at hotI
  change fork d qj = true at hotJ
  change qi < 25 at topI
  change qj < 25 at topJ
  have intsI := gi.internal
  have intsJ := gj.internal
  have li : ∃ xs, Path d.edge out gj.site xs := c.live _ intsJ (Nat.lt_trans gj.beforeOut c.upperOut)
  have lj : ∃ xs, Path d.edge out qj xs := c.live _ (by omega) topJ
  have pBefore := no_raw_before c.finalWire (fork_unique d) gj.shared li (Nat.lt_trans pj before)
  have qBefore := no_raw_before c.finalWire (fork_unique d) hotJ lj before
  apply no_four_defaults c5Prior d c.diagram out i j gi.site gj.site qi qj c.upperOut ij c.op c.signed
    c.computes c.finalWire c.live (gi.defaults c hi) (gj.defaults c hj) pBefore qBefore
  · change gi.site ≠ qj at cross
    simp [List.nodup_cons,Nat.ne_of_lt pi,apart,cross,
      (Nat.ne_of_lt (Nat.lt_trans pj before)).symm,(Nat.ne_of_lt before).symm,Nat.ne_of_lt pj]
  · intro n hn
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hn
    rcases hn with rfl|rfl|rfl|rfl
    · exact ⟨intsI,Nat.lt_trans gi.beforeOut c.upperOut,gi.shared⟩
    · exact ⟨by omega,topI,hotI⟩
    · exact ⟨intsJ,Nat.lt_trans gj.beforeOut c.upperOut,gj.shared⟩
    · exact ⟨by omega,topJ,hotJ⟩

theorem oneOwnerAtOutput (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) {d : Indexed} {out : Nat} (c : FifteenCore d out)
    (g1 : RealGuard d out 1) (g2 : RealGuard d out 2) (apart : g1.site ≠ g2.site) :
    assigned d out (fork d) 1 = out ∨ assigned d out (fork d) 2 = out := by
  by_contra! hn
  have separ := ownersSeparate d out (fork d) c.finalWire (fork_unique d) c.properSockets
    (fun n g h => by
      exact signedSocketOf (c.op n) g.op (c.signed n g h)) c.computes
  rcases lt_or_gt_of_ne separ with l | r
  · exact conflict_ordered c5Prior c g2 g1 (by decide) (by decide) (by decide) hn.2 hn.1 l apart.symm
      (g2.excludesNeighbor c (by decide) 1 192 (by decide)).symm
  · exact conflict_ordered c5Prior c g1 g2 (by decide) (by decide) (by decide) hn.1 hn.2 r apart
      (g1.excludesNeighbor c (by decide) 2 192 (by decide)).symm

end Petersen9822.DagCut
