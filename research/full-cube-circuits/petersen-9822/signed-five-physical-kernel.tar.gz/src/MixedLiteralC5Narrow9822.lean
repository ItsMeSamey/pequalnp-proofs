import MixedLiteralC5Extend9822
namespace Research.LiteralC5.Table

/-- On a true edge the column is unchanged; negative observations may disappear. -/
def Narrow (small old : Nat) : Prop :=
  ∀ k, (small.testBit k = true → old.testBit k = true) ∧
       (pos.testBit k = true → old.testBit k = true → small.testBit k = true)
private theorem self (z : Nat) : Narrow z z := fun _ => ⟨id,fun _ => id⟩

theorem nar_or {a b c d : Nat} (h : Narrow a c) (j : Narrow b d) :
    Narrow (a ||| b) (c ||| d) := by
  intro k
  simp only [Nat.testBit_or,Bool.or_eq_true]
  exact ⟨Or.imp (h k).1 (j k).1,fun p => Or.imp ((h k).2 p) ((j k).2 p)⟩

theorem nar_trans {a b c : Nat} (h : Narrow a b) (j : Narrow b c) : Narrow a c :=
  fun i => ⟨(j i).1 ∘ (h i).1, fun hp => (h i).2 hp ∘ (j i).2 hp⟩

def Represents (s old : List Nat) := ∀ a ∈ old, ∃ l : List Nat, l ⊆ s ∧ Narrow (val l) a

theorem narrowRecipe {s old : List Nat} (rep : Represents s old) {l : List Nat}
    (hl : l ⊆ old) : ∃ q : List Nat, q ⊆ s ∧ Narrow (val q) (val l) := by
  induction l with
  | nil => exact ⟨[],by simp,self _⟩
  | cons a l ih =>
    obtain ⟨u,hu,au⟩ := rep a (hl (by simp))
    obtain ⟨v,hv,av⟩ := ih (fun _ x => hl (by simp [x]))
    refine ⟨u++v,?_,?_⟩
    · simpa using And.intro hu hv
    · intro k
      have au := au k
      have av := av k
      simp only [val,bit_fold,List.mem_append,List.mem_cons] at au av ⊢
      constructor
      · intro he
        obtain ⟨ba,ha⟩ := he
        have h1 := au.1 ⟨ba,fun x hx => ha x (Or.inl hx)⟩
        have h2 := av.1 ⟨ba,fun x hx => ha x (Or.inr hx)⟩
        exact ⟨ba,fun x h => h.elim (fun eq => eq ▸ h1) (h2.2 x)⟩
      · rintro hp ⟨ba,h⟩
        have h1 := au.2 hp (h a (Or.inl rfl))
        have h2 := av.2 hp ⟨ba,fun x hx => h x (Or.inr hx)⟩
        exact ⟨ba,fun x hx => hx.elim (h1.2 x) (h2.2 x)⟩
private theorem pos_live (k : Nat) (h : pos.testBit k = true) : live.testBit k = true := by
  have eq : pos &&& live = pos := by decide
  have e := congrArg (fun n : Nat => n.testBit k) eq
  simpa [Nat.testBit_and,h] using e
theorem nar_single (a : Nat) : Narrow (val [a]) a := by
  intro k
  change ((live &&& a).testBit k = true → _) ∧ (_ → _ → (live &&& a).testBit k = true)
  simp only [Nat.testBit_and,Bool.and_eq_true]
  exact ⟨And.right,fun hp ha => ⟨pos_live k hp,ha⟩⟩
theorem initial_rep (xs : List Nat) : Represents xs xs :=
  fun a ha => ⟨[a],by simpa using ha,nar_single a⟩

theorem dominated {a b : Nat} (h : incl (a &&& pos) b = true) :
    Narrow b (a ||| b) := by
  have hh : a &&& pos &&& b = a &&& pos := by simpa [incl] using h
  intro k
  have atK := congrArg (fun n : Nat => n.testBit k) hh
  simp only [Nat.testBit_and] at atK
  simp only [Nat.testBit_or,Bool.or_eq_true]
  refine ⟨Or.inr,fun hp he => he.elim (fun ha => ?_) id⟩
  simpa [ha,hp] using atK

theorem normalizeGate {xs old left right : List Nat} (rep : Represents xs old)
    (hl : left ⊆ old) (hr : right ⊆ old) :
    ∃ ys : List Nat, (ys = xs ∨ ∃ g ∈ extensions xs, ys = g::xs) ∧
      Represents ys ((val left ||| val right)::old) := by
  obtain ⟨p,hp,np⟩ := narrowRecipe rep hl
  obtain ⟨q,hq,nq⟩ := narrowRecipe rep hr
  have both := nar_or np nq
  have reuse (l : List Nat) (inc : l ⊆ xs) (hpq : Narrow (val l) (val p ||| val q)) :
      Represents xs ((val left ||| val right)::old) := by
    intro v hv
    rcases List.mem_cons.mp hv with h | h
    · subst v; exact ⟨l,inc,nar_trans hpq both⟩
    · exact rep _ h
  cases ac : incl (val p &&& pos) (val q) with
  | true => exact ⟨xs,Or.inl rfl,reuse q hq (dominated ac)⟩
  | false =>
    cases bc : incl (val q &&& pos) (val p) with
    | true =>
      have nh := dominated bc
      rw [Nat.or_comm] at nh
      exact ⟨xs,Or.inl rfl,reuse p hp nh⟩
    | false =>
      have nonzero (v w : Nat) (n : incl (v &&& pos) w = false) : v &&& pos ≠ 0 := by
        intro h; simp [incl,h] at n
      let g := val p ||| val q
      have eg : g ∈ extensions xs := ext_either (mem_meets hp (nonzero _ _ ac))
        (mem_meets hq (nonzero _ _ bc)) ac bc
      refine ⟨g::xs, Or.inr ⟨g,eg,rfl⟩,?_⟩
      intro v hv
      rcases List.mem_cons.mp hv with h | h
      · subst v; exact ⟨[g],by simp,nar_trans (nar_single g) both⟩
      · obtain ⟨r,hr,nr⟩ := rep v h
        exact ⟨r,fun _ h => List.mem_cons_of_mem _ (hr h),nr⟩
end Research.LiteralC5.Table
