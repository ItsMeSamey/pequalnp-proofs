import Not9822GuardRolesCore
namespace Petersen9822.DagCut

theorem RealGuard.absent {d out i} (c : FifteenCore d out) (g : RealGuard d out i) (low : i < 10) :
    ¬ (d.tree g.site).term.uses i :=
  no_raw_before c.finalWire (fork_unique d) g.shared
    (c.live g.site g.internal (Nat.lt_trans g.beforeOut c.upperOut)) (g.beforeOwner c low)

theorem RealGuard.passesAtPivot {d out i} (c : FifteenCore d out) (g : RealGuard d out i)
    (low : i < 10) {r} (pivot : edgeHit r ≠ edgeHit (r ||| 2^i)) :
    wireValue d g.site r = !g.block ∧ wireValue d g.site (r ||| 2^i) = !g.block :=
  guard_pivot g.sockets (by simp [Nat.testBit_two_pow,show i ≠ out by have := c.lowerOut; omega])
    (g.absent c low) c.computes pivot

theorem commonBlock {d out} (c : FifteenCore d out) (a : RealGuard d out 1)
    (b : RealGuard d out 2) (same : a.site = b.site) : a.block = b.block := by
  have aa := (a.passesAtPivot c (by decide) (r:=4) (by decide)).2
  have bb := (b.passesAtPivot c (by decide) (r:=2) (by decide)).2
  change wireValue d a.site 6 = !a.block at aa
  change wireValue d b.site 6 = !b.block at bb
  rw [same] at aa
  simpa using congrArg Bool.not (aa.symm.trans bb)

theorem RealGuard.blockedFlip {d out i} (c : FifteenCore d out) (g : RealGuard d out i)
    (low : i < 10) (r : Nat) (blocked : wireValue d g.site r = g.block) :
    edgeHit r = edgeHit (r ||| 2^i) := by
  by_contra ne
  have opposite := (g.passesAtPivot c low ne).1
  rw [blocked] at opposite
  cases h : g.block <;> simp [h] at opposite

theorem commonBlockForcesOutput {d out} (c : FifteenCore d out) (a : RealGuard d out 1)
    (b : RealGuard d out 2) (same : a.site = b.site) (r : Nat)
    (blocked : wireValue d a.site r = a.block) : edgeHit r = true := by
  have ca := a.blockedFlip c (by decide) r blocked
  have inv := independent_flip (a.absent c (by decide)) r
  have bblock : wireValue d b.site (r ||| 2^1) = b.block :=
    by rw [←same,←inv,blocked,commonBlock c a b same]
  have cb := b.blockedFlip c (by decide) _ bblock
  rw [ca,cb]
  have mandatory : sub 6 (r ||| 2^1 ||| 2^2) = true := by
    unfold sub
    apply beq_iff_eq.mpr
    change 6 &&& (r ||| 2 ||| 4) = 6
    rw [Nat.or_assoc]
    change 6 &&& (r ||| 6) = 6
    apply Nat.eq_of_testBit_eq
    intro i
    simp only [Nat.testBit_and,Nat.testBit_or]
    cases (6 : Nat).testBit i <;> simp
  unfold edgeHit
  exact List.any_eq_true.mpr ⟨6,by decide,mandatory⟩

end Petersen9822.DagCut
