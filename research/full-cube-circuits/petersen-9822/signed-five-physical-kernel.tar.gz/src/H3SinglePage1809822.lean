import H3GlobalBatchSingle1809822
import H3GlobalBatchSingle1819822
import H3GlobalBatchSingle1829822
import H3GlobalBatchSingle1839822
import H3GlobalBatchSingle1849822
import H3GlobalBatchSingle1859822
import H3GlobalBatchSingle1869822
import H3GlobalBatchSingle1879822
import H3GlobalBatchSingle1889822
import H3GlobalBatchSingle1899822
import H3GlobalBatchSingle1909822
import H3GlobalBatchSingle1919822
namespace Research.Graph9822Planes
def rootsPage180 : List Nat := (batchSingle180.map Prod.fst) ++ ((batchSingle181.map Prod.fst) ++ ((batchSingle182.map Prod.fst) ++ ((batchSingle183.map Prod.fst) ++ ((batchSingle184.map Prod.fst) ++ ((batchSingle185.map Prod.fst) ++ ((batchSingle186.map Prod.fst) ++ ((batchSingle187.map Prod.fst) ++ ((batchSingle188.map Prod.fst) ++ ((batchSingle189.map Prod.fst) ++ ((batchSingle190.map Prod.fst) ++ ((batchSingle191.map Prod.fst))))))))))))
theorem allPage180 : PaidKeys rootsPage180 := paid_append (page_paid paidBatchSingle180) (paid_append (page_paid paidBatchSingle181) (paid_append (page_paid paidBatchSingle182) (paid_append (page_paid paidBatchSingle183) (paid_append (page_paid paidBatchSingle184) (paid_append (page_paid paidBatchSingle185) (paid_append (page_paid paidBatchSingle186) (paid_append (page_paid paidBatchSingle187) (paid_append (page_paid paidBatchSingle188) (paid_append (page_paid paidBatchSingle189) (paid_append (page_paid paidBatchSingle190) (page_paid paidBatchSingle191)))))))))))
end Research.Graph9822Planes
