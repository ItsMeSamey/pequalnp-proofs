import MixedCascade9822
import MixedGuardLayout9822
import PrivateUpperModel9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds FreeAndNet Research.OddOr SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean Research.OddOr.Envelope Research.OddOr.Graph9822
theorem mixed_cost_floor {C pre post g} (r : Roster C pre post g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (hs : innerValue pre g (SignedClamp.singleton s)=true)
    (u : Net (Fin 10)) (ev : ∀x,u.eval x=outerValue pre post C.output x true) : 8≤u.cost := by
  have other := other_guard_cold r cand red seven s sl su hs
  have cut := physical_cut_split cand r.split r.inv (fun q hq => r.pos q (List.mem_append_right _ hq))
  have high : s∈([5,6,7,8]:List (Fin 10)) := by
    have all : ∀ j : Fin 10,5≤j.val → j.val≤8 → j∈([5,6,7,8]:List (Fin 10)) := by decide
    exact all s sl su
  have cold (j : Fin 10) (js : j≠s) (jn : j≠9) : sees u {j}=false := by
    have eq : inputOn {j}=SignedClamp.singleton j := by funext i;simp [inputOn,SignedClamp.singleton]
    change u.eval (inputOn {j})=false
    rw [eq,ev]
    have on := cut.computes (SignedClamp.singleton j)
    rw [other j js jn] at on;exact on.trans (singleton_zero j)
  have edges (a b : Fin 10) (h : f {a,b}=true) : sees u {a,b}=true := by
    change u.eval (inputOn {a,b})=true
    rw [ev];exact positive_upper cut _ h
  have price := mixed_nine_envelope s high u cold edges
  split at price <;> omega
theorem mixed_cascade_impossible {C pre p t tail g u v}
    (r : Roster C pre (p++u::(t++v::tail)) g) (cand : Candidate C)
    (red : Reduced 10 C.gates C.output) (seven : C.gates.countP countsAnd=7)
    (s : Fin 10) (sl : 5≤s.val) (su : s.val≤8) (hs : innerValue pre g (SignedClamp.singleton s)=true)
    (uo : u.op=.or) (vo : v.op=.or)
    (up : 10+pre.length∈u.inputs) (vp : 10+(pre++topGate::p).length∈v.inputs) : False := by
  obtain ⟨n,pay,rep⟩ := or_cascade_model r cand (by omega) uo vo up vp
  have := mixed_cost_floor r cand red seven s sl su hs n rep
  omega
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
