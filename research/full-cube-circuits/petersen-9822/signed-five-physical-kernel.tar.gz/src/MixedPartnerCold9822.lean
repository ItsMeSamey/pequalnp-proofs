import MixedReaderCold9822
import HighUniqueReader9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport LowHotElimination Deletion
open PEqualNP.Outside.L_meta_9822.Clean
theorem only_reader_away {p t : List Gate} {q : Gate} {z : Nat} (hit : z∈q.inputs)
    (cnt : (p++q::t).countP (ReaderDebit.reads z)=1) :
    ∀a∈p++t,z∉a.inputs := by
  have aq : ReaderDebit.reads z q=true := by simp [ReaderDebit.reads,hit]
  simp [List.countP_append,aq] at cnt
  intro a mem ha
  have pos : ReaderDebit.reads z a=true := by simp [ReaderDebit.reads,ha]
  rcases List.mem_append.mp mem with mb|mb
  · exact (List.countP_eq_zero.mp (by omega : p.countP (ReaderDebit.reads z)=0) a mb) pos
  · exact (List.countP_eq_zero.mp (by omega : t.countP (ReaderDebit.reads z)=0) a mb) pos

theorem changed_or_cold {pre mid tail : List Gate} {q : Gate} (out : Nat) (x : Input)
    (op : q.op=.or) {d : Nat} (pins : q.inputs=[10+pre.length,d] ∨ q.inputs=[d,10+pre.length])
    (away : out≠10+pre.length) (cnt : (mid++q::tail).countP (ReaderDebit.reads (10+pre.length))=1)
    (diff : outerValue pre (mid++q::tail) out x false≠outerValue pre (mid++q::tail) out x true) :
    let w := wiresFrom pre (List.ofFn x)
    (wiresFrom mid (w++[false])).getD d false=false := by
  let w := wiresFrom pre (List.ofFn x)
  have len : w.length=10+pre.length := by simp [w,length_wiresFrom]
  have hit : 10+pre.length∈q.inputs := by rcases pins with h|h <;> simp [h]
  have ch := unique_reader_changes mid tail q w out (by rw [len];exact only_reader_away hit cnt) (by rwa [len]) diff
  have up : (wiresFrom mid (w++[true])).getD (10+pre.length) false=true := by
    rw [getD_wiresFrom _ _ _ (by simp [len])]
    exact getD_snoc_len _ _ _ _ len
  change (wiresFrom mid (w++[false])).getD d false=false
  by_contra! hot
  have on : (wiresFrom mid (w++[false])).getD d false=true := by cases e : (wiresFrom mid (w++[false])).getD d false <;> simp_all
  apply ch
  have yes (L : List Bool) (j : Nat) (m : j∈q.inputs) (val : L.getD j false=true) :
      q.op.eval (q.inputs.map fun k => L.getD k false)=true := by
    simp only [op,GateOp.eval,List.any_map,Function.comp_def,id_eq,List.any_eq_true]
    exact ⟨j,m,val⟩
  have pin : d∈q.inputs := by rcases pins with h|h <;> simp [h]
  exact (yes _ d pin on).trans (yes _ _ hit up).symm
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
