import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row42 : row 16781424 = true := by decide +kernel
theorem row43 : row 16783104 = true := by decide +kernel
theorem row44 : row 16783112 = true := by decide +kernel
end Research.LiteralC5.Table
