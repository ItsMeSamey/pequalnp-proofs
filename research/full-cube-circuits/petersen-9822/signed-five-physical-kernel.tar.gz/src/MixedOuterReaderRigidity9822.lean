import MixedNineHitCharge9822
import MixedHotReaderNet9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
open PEqualNP.CircuitLowerBounds SignedClamp NonrawSupport OuterNet FreeAndNet Research.OddOr
open Research.OddOr.Envelope Research.OddOr.Graph9822
theorem mixed_outer_reader_rigidity {C pre mid tail g q} (r : Roster C pre (mid++q::tail) g)
    (cand : Candidate C) (seven : 7≤C.gates.countP countsAnd)
    (s : Fin 10) (sector : s=5 ∨ s=8)
    (other : ∀ j : Fin 10, j≠s → j≠9 → innerValue pre g (SignedClamp.singleton j)=false)
    (op : q.op=.or) (hit : 10+pre.length∈q.inputs) :
    ∃ u : Net (Fin 10), (∀ x,u.eval x=outerValue pre (mid++q::tail) C.output x true) ∧
      u.cost=8 ∧ hits s u = 1 ∧ hits 9 (pin s u) = 1 := by
  obtain ⟨u,cap,read⟩ := or_reader_model r cand seven op hit
  have cut := physical_cut_split cand r.split r.inv (fun a ha => r.pos a (List.mem_append_right _ ha))
  have high : s∈([5,6,7,8]:List (Fin 10)) := by rcases sector with rfl|rfl <;> decide
  have cold (j : Fin 10) (js : j≠s) (jn : j≠9) : sees u {j}=false := by
    have eq : inputOn {j} = SignedClamp.singleton j := by funext k; simp [inputOn,SignedClamp.singleton]
    change u.eval (inputOn {j})=false
    rw [eq,read]
    have on := cut.computes (SignedClamp.singleton j)
    rw [other j js jn] at on
    exact on.trans (singleton_zero j)
  have edges (i j : Fin 10) (e : f {i,j}=true) : sees u {i,j}=true := by
    change u.eval (inputOn {i,j})=true
    rw [read]
    exact positive_upper cut _ e
  obtain ⟨hs,hn,charge⟩ := mixed_nine_debit s high u cold edges
  have no : ¬ (s=6 ∨ s=7) := by rcases sector with rfl|rfl <;> decide
  simp [no] at charge
  exact ⟨u,read,by omega,by omega,by omega⟩
end PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.BoundedClamp.mixed_outer_reader_rigidity
