import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle75 : List ModeRow := [(34349361,[45417,5550,10471,14479,29990,34927,12525,5917,13422],[45417,21731,5917,10471,12525,34927,4597,13359])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle75 : batchSingle75.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
