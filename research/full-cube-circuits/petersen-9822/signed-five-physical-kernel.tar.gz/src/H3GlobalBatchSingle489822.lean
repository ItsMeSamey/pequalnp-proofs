import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle48 : List ModeRow := [(6432400,[49950,4347,16829,951,37479,33703,17877,863,17394,639],[33597,21955,863,33239,53596,951,751,17877])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle48 : batchSingle48.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
