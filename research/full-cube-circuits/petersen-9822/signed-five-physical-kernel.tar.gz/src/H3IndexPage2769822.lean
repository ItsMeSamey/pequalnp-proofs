import H3SinglePage2769822
import H3GlobalRootIndex9822
namespace Research.Graph9822Planes
theorem frozenPaid276 : PaidKeys frozen276 := by
  have e : rootsPage276 = frozen276 := by decide +kernel
  rw [← e]
  exact allPage276
end Research.Graph9822Planes
