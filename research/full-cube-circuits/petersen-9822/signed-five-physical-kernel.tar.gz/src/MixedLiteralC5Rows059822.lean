import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row15 : row 131626 = true := by decide +kernel
theorem row16 : row 131690 = true := by decide +kernel
theorem row17 : row 132172 = true := by decide +kernel
end Research.LiteralC5.Table
