import PrivateClampTape9822
namespace PEqualNP.Outside.L_meta_9822.Sectors.Deletion
open PEqualNP.CircuitLowerBounds SignedClamp PEqualNP.Outside.L_meta_9822.Clean
theorem unique_reader_changes (mid tail : List Gate) (q : Gate) (w : List Bool) (i : Nat)
    (no : ∀b∈mid++tail,w.length∉b.inputs) (neq : i≠w.length)
    (diff : (wiresFrom (mid++q::tail) (w++[false])).getD i false ≠
            (wiresFrom (mid++q::tail) (w++[true])).getD i false) :
    let lo := wiresFrom mid (w++[false])
    let hi := wiresFrom mid (w++[true])
    q.op.eval (q.inputs.map fun j => lo.getD j false) ≠ q.op.eval (q.inputs.map fun j => hi.getD j false) := by
  let lo := wiresFrom mid (w++[false])
  let hi := wiresFrom mid (w++[true])
  have len : lo.length=hi.length := by simp [lo,hi,length_wiresFrom]
  have eq := ignore_wire mid w.length (w++[false]) (w++[true])
    (fun b m => no b (List.mem_append_left _ m)) (by simp) (by
      intro j h;rw [getD_snoc_ne _ _ _ _ h,getD_snoc_ne _ _ _ _ h])
  change q.op.eval (q.inputs.map fun j => lo.getD j false)≠q.op.eval (q.inputs.map fun j => hi.getD j false)
  intro ev
  apply diff
  rw [wiresFrom_append,wiresFrom_append]
  change (wiresFrom tail (lo++[q.op.eval (q.inputs.map fun j => lo.getD j false)])).getD i false=
    (wiresFrom tail (hi++[q.op.eval (q.inputs.map fun j => hi.getD j false)])).getD i false
  change q.op.eval (q.inputs.map fun j => lo.getD j false)=q.op.eval (q.inputs.map fun j => hi.getD j false) at ev
  rw [ev]
  exact ignore_wire tail _ _ _ (fun b m => no b (List.mem_append_right _ m))
    (by simp [len]) (snoc_agree_off _ _ _ _ len eq) i neq
end PEqualNP.Outside.L_meta_9822.Sectors.Deletion
