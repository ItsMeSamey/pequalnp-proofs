import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle74 : List ModeRow := [(33847320,[5438,39139,21775,19511,37675,7478,2399,3315],[37675,19511,39139,5438,23875,18867,21775])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle74 : batchSingle74.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
