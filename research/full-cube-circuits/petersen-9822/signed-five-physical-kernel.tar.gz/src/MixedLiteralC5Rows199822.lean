import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row57 : row 17831792 = true := by decide +kernel
theorem row58 : row 18284552 = true := by decide +kernel
theorem row59 : row 18284608 = true := by decide +kernel
end Research.LiteralC5.Table
