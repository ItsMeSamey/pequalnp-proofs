import OR9822HullPage00
import OR9822HullPage01
import OR9822HullPage02
import OR9822HullPage03
import OR9822HullPage04
import OR9822HullPage05
import OR9822HullPage06
import OR9822HullPage07
import OR9822HullPage08
import OR9822HullPage09
import OR9822HullPage10
import OR9822HullPage11
import OR9822HullPage12
import OR9822HullPage13
import OR9822HullPage14
import OR9822HullPage15
import OR9822HullPage16
import OR9822HullPage17
import OR9822HullPage18
import OR9822HullPage19
import OR9822HullPage20
import OR9822HullPage21
import OR9822HullPage22
import OR9822HullPage23
namespace Research.Graph9822LiteH2.Hull
theorem allPaidhull (j : Nat) (hj : j<96) : paidHull j=true := by
  by_cases bound0 : j<4
  · exact List.all_eq_true.mp hullPage0 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound4 : j<8
  · exact List.all_eq_true.mp hullPage1 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound8 : j<12
  · exact List.all_eq_true.mp hullPage2 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound12 : j<16
  · exact List.all_eq_true.mp hullPage3 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound16 : j<20
  · exact List.all_eq_true.mp hullPage4 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound20 : j<24
  · exact List.all_eq_true.mp hullPage5 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound24 : j<28
  · exact List.all_eq_true.mp hullPage6 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound28 : j<32
  · exact List.all_eq_true.mp hullPage7 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound32 : j<36
  · exact List.all_eq_true.mp hullPage8 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound36 : j<40
  · exact List.all_eq_true.mp hullPage9 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound40 : j<44
  · exact List.all_eq_true.mp hullPage10 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound44 : j<48
  · exact List.all_eq_true.mp hullPage11 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound48 : j<52
  · exact List.all_eq_true.mp hullPage12 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound52 : j<56
  · exact List.all_eq_true.mp hullPage13 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound56 : j<60
  · exact List.all_eq_true.mp hullPage14 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound60 : j<64
  · exact List.all_eq_true.mp hullPage15 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound64 : j<68
  · exact List.all_eq_true.mp hullPage16 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound68 : j<72
  · exact List.all_eq_true.mp hullPage17 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound72 : j<76
  · exact List.all_eq_true.mp hullPage18 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound76 : j<80
  · exact List.all_eq_true.mp hullPage19 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound80 : j<84
  · exact List.all_eq_true.mp hullPage20 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound84 : j<88
  · exact List.all_eq_true.mp hullPage21 j (by simp only [List.mem_range'_1]; omega)
  by_cases bound88 : j<92
  · exact List.all_eq_true.mp hullPage22 j (by simp only [List.mem_range'_1]; omega)
  exact List.all_eq_true.mp hullPage23 j (by simp only [List.mem_range'_1]; omega)
end Research.Graph9822LiteH2.Hull
