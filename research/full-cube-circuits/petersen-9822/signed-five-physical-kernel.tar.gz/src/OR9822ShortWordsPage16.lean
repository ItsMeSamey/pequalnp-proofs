import OR9822ShortClip
namespace Research.Graph9822ProfileArithmetic.Laws
set_option maxRecDepth 30000 in
set_option maxHeartbeats 18000000 in
private theorem checked : (List.range' 50 8).all clipOK=true := by decide +kernel
theorem words16 : (List.range' 50 8).all (fun k => binaryWords k == shortWords k)=true := by
  apply List.all_eq_true.mpr
  intro k mem
  exact beq_iff_eq.mpr (clip_sound (List.all_eq_true.mp checked k mem))
end Research.Graph9822ProfileArithmetic.Laws
