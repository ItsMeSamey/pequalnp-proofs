import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle291 : List ModeRow := [(433607468,[52810,21958,14479,10931,59911,54287,11923,1785,15375],[52810,21958,14479,10931])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle291 : batchSingle291.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
