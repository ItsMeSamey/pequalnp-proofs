import OR9822ShortProjection
namespace Research.Graph9822ProfileArithmetic.Laws
set_option maxRecDepth 16000 in
set_option maxHeartbeats 18000000 in
theorem words4 : (List.range' 11 5).all (fun k => binaryWords k == shortWords k)=true := by decide +kernel
end Research.Graph9822ProfileArithmetic.Laws
