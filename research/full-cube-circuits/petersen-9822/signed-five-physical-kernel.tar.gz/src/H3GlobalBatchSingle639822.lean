import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle63 : List ModeRow := [(26106184,[3390,13014,51555,38233,15431,3706,5351,10583,894,5479],[3706,51555,3135,7478,11367,14535])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle63 : batchSingle63.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
