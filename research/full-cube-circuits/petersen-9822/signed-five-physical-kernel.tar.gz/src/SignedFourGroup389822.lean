import SignedFourFiniteRows9822
namespace Research.SignedFactorFour
set_option maxRecDepth 12000
set_option maxHeartbeats 4000000
def r190 : Row := ([3,5,8,9], [0,1])
private theorem ok190 : rowGood r190=true := by decide +kernel
def r191 : Row := ([3,6,7,8], [0,1])
private theorem ok191 : rowGood r191=true := by decide +kernel
def r192 : Row := ([3,6,7,9], [0,1])
private theorem ok192 : rowGood r192=true := by decide +kernel
def r193 : Row := ([3,6,8,9], [0,1])
private theorem ok193 : rowGood r193=true := by decide +kernel
def r194 : Row := ([3,7,8,9], [0,1])
private theorem ok194 : rowGood r194=true := by decide +kernel
def page38 : List Row := [r190,r191,r192,r193,r194]
theorem paid38 : page38.all rowGood=true := by simp [page38,ok190,ok191,ok192,ok193,ok194]
end Research.SignedFactorFour
