import OR9822H2MaskLogic
namespace Research.Graph9822H2Check.SeedCache

theorem root_below_demand {r t f extra : Nat} (bound : negative r < 65536)
    (pos : sub (positive r) t=true)
    (cold : sub (negative r &&& (65535 ^^^ extra)) f = true) :
    sub r (demand t (f ||| extra))=true := by
  apply (subset_bits ..).2
  intro i on
  by_cases lo : i<13
  · have mask : (8191:Nat).testBit i=true := by
      change (2^13-1 : Nat).testBit i=true
      rw [Nat.testBit_two_pow_sub_one];simp [lo]
    have hi : t.testBit i=true := (subset_bits ..).1 pos i (by simp [positive,mask,on])
    simp [demand,hi]
  · let k := i-13
    have idx : 13+k=i := by dsimp [k];omega
    have negbit : (negative r).testBit k=true := by simpa only [negative,Nat.testBit_shiftRight,idx] using on
    have kb : k<16 := by
      by_contra! far
      have off := Nat.testBit_lt_two_pow (lt_of_lt_of_le bound
        (show 65536≤2^k from Nat.pow_le_pow_right (by decide : 0<(2:Nat)) far))
      exact Bool.noConfusion (negbit.symm.trans off)
    have mask : (65535:Nat).testBit k=true := by
      change (2^16-1 : Nat).testBit k=true
      rw [Nat.testBit_two_pow_sub_one];simp [kb]
    have enough : (f ||| extra).testBit k=true := by
      cases e : extra.testBit k
      · have yes := (subset_bits ..).1 cold k (by simp [negbit,mask,e])
        simp [yes]
      · simp [e]
    have ge : i≥13 := by omega
    have shifted : ((f ||| extra) <<< 13).testBit i=true := by
      simpa only [Nat.testBit_shiftLeft,ge,decide_true,Bool.true_and] using enough
    simp [demand,shifted]

theorem demand_positive {t f : Nat} (low : t<8192) : positive (demand t f)=t := by
  apply Nat.eq_of_testBit_eq
  intro i
  by_cases small : i<13
  · have mask : (8191:Nat).testBit i = true := by
      change (2^13-1 : Nat).testBit i=true
      rw [Nat.testBit_two_pow_sub_one];simp [small]
    simp only [positive,demand,Nat.testBit_and,Nat.testBit_or,Nat.testBit_shiftLeft,
      show ¬i≥13 by omega,decide_false,Bool.false_and,Bool.or_false,mask,Bool.and_true]
  · have hi : 13 ≤ i := by omega
    have p := Nat.pow_le_pow_right (by decide : 0<(2:Nat)) hi
    have off : t.testBit i=false := Nat.testBit_lt_two_pow (lt_of_lt_of_le low p)
    have m : (8191:Nat).testBit i=false := Nat.testBit_lt_two_pow (lt_of_lt_of_le (by decide : 8191<8192) p)
    simp [positive,m,off]

theorem demand_negative {t f : Nat} (low : t<8192) : negative (demand t f)=f := by
  apply Nat.eq_of_testBit_eq
  intro i
  have off : t.testBit (13+i)=false := Nat.testBit_lt_two_pow (lt_of_lt_of_le low
    (show 8192≤2^(13+i) from Nat.pow_le_pow_right (by decide : 0<(2:Nat)) (by omega : 13 ≤ 13+i)))
  simp only [negative,demand,Nat.testBit_shiftRight,Nat.testBit_or,Nat.testBit_shiftLeft,off,
    Bool.false_or,show 13+i≥13 by omega,decide_true,Bool.true_and,show 13+i-13=i by omega]

end Research.Graph9822H2Check.SeedCache
