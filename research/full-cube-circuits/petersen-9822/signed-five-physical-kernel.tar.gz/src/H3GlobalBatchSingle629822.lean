import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle62 : List ModeRow := [(25678152,[3646,5593,12958,49463,1275,7495,5558,26919,2463,5550,1375],[3646,49502,11319,1529,2463])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle62 : batchSingle62.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
