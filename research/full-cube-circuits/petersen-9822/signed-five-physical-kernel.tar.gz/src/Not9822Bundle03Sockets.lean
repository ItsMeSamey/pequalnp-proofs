import Not9822Bundle02Trees

-- Not9822PrivateEntries
namespace Petersen9822.DagCut

inductive PrivateEntries (owner : Nat) (blocking : Bool) : Term (Option Nat) → Prop where
  | hole : PrivateEntries owner blocking (.var none)
  | raw (v : Nat) : owner.testBit v = false → PrivateEntries owner blocking (.var (some v))
  | lit (b : Bool) : PrivateEntries owner blocking (.lit b)
  | gate {a b} (op : Bool → Bool → Bool) :
      PrivateEntries owner blocking a → PrivateEntries owner blocking b →
      PrivateEntries owner blocking (.gate op a b)
  | left (v : Nat) (op : Bool → Bool → Bool) : op blocking false = op blocking true →
      PrivateEntries owner blocking (.gate op (.var none) (.var (some v)))
  | right (v : Nat) (op : Bool → Bool → Bool) : op false blocking = op true blocking →
      PrivateEntries owner blocking (.gate op (.var (some v)) (.var none))

theorem PrivateEntries.blocks {owner : Nat} {blocking : Bool} {tail : Term (Option Nat)}
    (h : PrivateEntries owner blocking tail) (p u : Nat) :
    tail.eval (ports (p ||| u) blocking) = tail.eval (ports (p ||| (u ||| owner)) blocking) := by
  induction h with
  | hole => rfl
  | raw v h => simp [Term.eval,ports,h]
  | lit => rfl
  | gate op _ _ ia ib => simp only [Term.eval,ia,ib]
  | left v op h =>
    change op blocking ((p ||| u).testBit v) = op blocking ((p ||| (u ||| owner)).testBit v)
    cases (p ||| u).testBit v <;> cases (p ||| (u ||| owner)).testBit v <;> simp_all
  | right v op h =>
    change op ((p ||| u).testBit v) blocking = op ((p ||| (u ||| owner)).testBit v) blocking
    cases (p ||| u).testBit v <;> cases (p ||| (u ||| owner)).testBit v <;> simp_all

def guardedCut (p S U owner : Nat) (block : Bool) (input : Term Nat) (tail : Term (Option Nat))
    (before : ∀ v, input.uses v → U.testBit v = false)
    (afterCut : ∀ v, tail.uses (some v) → S.testBit v = false)
    (privateEntries : PrivateEntries owner block tail)
    (computes : ∀ s u, sub s S = true → sub u U = true →
      val p s u = (tail.bind (plug input)).eval ((p ||| s ||| u).testBit)) :
    GuardAt p S U owner := by
  let C := oneBitOfCut p S U input tail before afterCut computes
  refine { toOneBitAt := C, blocking := !block, pivotal := ?_ }
  intro s u hs hu huo hp
  by_cases hb : C.enc s = block
  · exfalso
    apply hp
    rw [C.correct _ _ hs hu, C.correct _ _ hs huo, hb]
    exact privateEntries.blocks p u
  · cases block <;> cases he : C.enc s <;> simp_all

end Petersen9822.DagCut

-- Not9822Indexed
namespace Petersen9822.DagCut

structure Indexed where
  get : Nat → Option Gate
  back : ∀ n g, get n = some g → g.left < n ∧ g.right < n

def Indexed.edge (d : Indexed) (a b : Nat) : Prop :=
  ∃ g, d.get b = some g ∧ (g.left = a ∨ g.right = a)

theorem Indexed.chrono (d : Indexed) {a b : Nat} (h : d.edge a b) : a < b := by
  obtain ⟨g,hg,h | h⟩ := h
  · exact h ▸ (d.back b g hg).1
  · exact h ▸ (d.back b g hg).2

def Indexed.tree (d : Indexed) (n : Nat) : Tree :=
  match h : d.get n with
  | none => .raw n
  | some g => .gate n g.op (d.tree g.left) (d.tree g.right)
termination_by n
decreasing_by all_goals first | exact (d.back _ _ h).1 | exact (d.back _ _ h).2

@[simp] theorem Indexed.tree_id (d : Indexed) (n : Nat) : (d.tree n).id = n := by
  rw [Indexed.tree]
  split <;> rfl

theorem Indexed.tree_valid (d : Indexed) (n : Nat) : (d.tree n).valid d.edge := by
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    rw [Indexed.tree]
    split
    next => trivial
    next g hg =>
      refine ⟨?_,?_,ih _ (d.back _ _ hg).1,ih _ (d.back _ _ hg).2⟩
      · exact ⟨g,hg,Or.inl (d.tree_id _).symm⟩
      · exact ⟨g,hg,Or.inr (d.tree_id _).symm⟩

theorem Indexed.tree_none (d : Indexed) {n : Nat} (hg : d.get n = none) :
    d.tree n = .raw n := by rw [Indexed.tree]; split <;> simp_all
theorem Indexed.tree_some (d : Indexed) {n : Nat} {g : Gate} (hg : d.get n = some g) :
    d.tree n = .gate n g.op (d.tree g.left) (d.tree g.right) := by
  rw [Indexed.tree]; split <;> simp_all

theorem Indexed.coherent (d : Indexed) (cut n : Nat) :
    (d.tree n).atSite cut (d.tree cut).term := by
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    cases hg : d.get n with
    | none =>
      rw [d.tree_none hg]
      intro eq
      subst cut
      rw [d.tree_none hg]
      rfl
    | some g =>
      rw [d.tree_some hg]
      refine ⟨?_,ih _ (d.back _ _ hg).1,ih _ (d.back _ _ hg).2⟩
      intro eq
      subst cut
      rw [d.tree_some hg]
      rfl

theorem Indexed.open_self (d : Indexed) (cut : Nat) :
    (d.tree cut).openWire cut = .var none := by
  rw [Tree.openWire.eq_def]
  simp only [d.tree_id,if_true]

/-- Socket-local characterization of all owner reads in the signed DAG. -/
structure PrivateSockets (d : Indexed) (cut owner : Nat) (block : Bool) : Prop where
  cutCold : owner.testBit cut = false
  raw : ∀ v, owner.testBit v = true → d.get v = none
  left : ∀ n g, d.get n = some g → owner.testBit g.left = true →
    g.right = cut ∧ g.op false block = g.op true block
  right : ∀ n g, d.get n = some g → owner.testBit g.right = true →
    g.left = cut ∧ g.op block false = g.op block true

theorem Indexed.private_entries (d : Indexed) (n cut owner : Nat) (block : Bool)
    (sockets : PrivateSockets d cut owner block) (cold : owner.testBit n = false) :
    PrivateEntries owner block ((d.tree n).openWire cut) := by
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    by_cases eq : n = cut
    · subst n
      rw [d.open_self]
      exact .hole
    · cases hg : d.get n with
      | none =>
        have e : d.tree n = .raw n := d.tree_none hg
        rw [e]
        simpa [Tree.openWire, Tree.id,eq] using (PrivateEntries.raw (owner:=owner) (blocking:=block) n cold)
      | some g =>
        have e : d.tree n = .gate n g.op (d.tree g.left) (d.tree g.right) := d.tree_some hg
        rw [e]
        rw [Tree.openWire.eq_def]
        change PrivateEntries owner block (if n = cut then .var none else
          .gate g.op ((d.tree g.left).openWire cut) ((d.tree g.right).openWire cut))
        rw [if_neg eq]
        have leaf (v : Nat) (hot : owner.testBit v = true) :
            (d.tree v).openWire cut = .var (some v) := by
          have ne : v ≠ cut := by intro q; rw [q,sockets.cutCold] at hot; contradiction
          have ev : d.tree v = .raw v := d.tree_none (sockets.raw v hot)
          simp [ev,Tree.openWire,Tree.id,ne]
        cases hl : owner.testBit g.left with
        | true =>
          obtain ⟨hr,hh⟩ := sockets.left n g hg hl
          rw [leaf _ hl,hr,d.open_self]
          exact .right _ _ hh
        | false =>
          cases hr : owner.testBit g.right with
          | true =>
            obtain ⟨he,hh⟩ := sockets.right n g hg hr
            rw [leaf _ hr,he,d.open_self]
            exact .left _ _ hh
          | false =>
            exact .gate _ (ih _ (d.back _ _ hg).1 hl) (ih _ (d.back _ _ hg).2 hr)

end Petersen9822.DagCut

-- Not9822Admissible
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

structure SiteBins (d : Indexed) (out cut : Nat) (shared : Nat → Bool) (S U : Nat) : Prop where
  finalWire : ∀ a b, d.edge a b → a ≠ out
  deterministic : ∀ a, shared a = false → ∀ b c, d.edge a b → d.edge a c → b = c
  sharedGate : shared cut = true
  liveGate : ∃ xs, Path d.edge out cut xs
  current : ∀ v, S.testBit v = true → ∀ live : ∃ xs, Path d.edge out v xs,
    owner d.edge out shared v live = cut
  future : ∀ v, U.testBit v = true → ∀ live : ∃ xs, Path d.edge out v xs,
    cut < owner d.edge out shared v live

def SiteBins.channel {d out cut shared S U} (h : SiteBins d out cut shared S U)
    (p : Nat) (computes : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit) :
    OneBitAt p S U :=
  oneBitOfOwners d.edge shared (d.tree out) (d.tree cut) p S U
    (d.tree_valid _) (d.tree_valid _) (fun _ _ he => d.chrono he)
    (by simpa using h.finalWire) h.deterministic (by simpa using h.sharedGate)
    (by simpa using h.liveGate) (by simpa using d.coherent cut out)
    (by simpa using h.current) (by simpa using h.future)
    (fun s u _ _ => computes (p ||| s ||| u))

theorem SiteBins.admissible {d out cut shared S U} (h : SiteBins d out cut shared S U)
    (ownerMask prior : Nat)
    (sockets : ownerMask ≠ 0 → ∃ block, PrivateSockets d cut ownerMask block)
    (outCold : ownerMask.testBit out = false)
    (computes : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit) :
    admissible ownerMask S prior U := by
  refine ⟨fun p _ => ⟨h.channel p computes⟩, ?_⟩
  intro ho p _
  obtain ⟨block,privateSocket⟩ := sockets ho
  let C := h.channel p computes
  have guarded := d.private_entries out cut ownerMask block privateSocket outCold
  refine ⟨{ toOneBitAt := C, blocking := !block, pivotal := ?_ }⟩
  intro s u hs hu huo hp
  by_cases hb : C.enc s = block
  · exfalso
    apply hp
    rw [C.correct _ _ hs hu, C.correct _ _ hs huo, hb]
    change ((d.tree out).openWire (d.tree cut).id).eval (ports (p ||| u) block) =
      ((d.tree out).openWire (d.tree cut).id).eval (ports (p ||| (u ||| ownerMask)) block)
    simpa only [d.tree_id] using guarded.blocks p u
  · cases block <;> cases he : C.enc s <;> simp_all

end Petersen9822.DagCut
