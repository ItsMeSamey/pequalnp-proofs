import MixedReaderCircuit9822
namespace PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
open PEqualNP.CircuitLowerBounds
theorem unchanged {q : Gate} {r d : Nat} (hot : Nat → Bool) (absent : r∉q.inputs) :
    gate r d hot q=q := by
  cases q with
  | mk op ins =>
    cases ins with
    | nil => rfl
    | cons a tail =>
      cases tail with
      | nil => rfl
      | cons b rest =>
        cases rest with
        | cons => rfl
        | nil =>
          have an : a≠r := by intro e; apply absent;simp [e]
          have bn : b≠r := by intro e; apply absent;simp [e]
          simp [gate,an,bn]
theorem unchanged_map {gs : List Gate} {r d : Nat} (hot : Nat → Bool)
    (absent : ∀q∈gs,r∉q.inputs) : gs.map (gate r d hot)=gs := by
  induction gs with
  | nil => rfl
  | cons q t ih =>
    rw [List.map_cons,unchanged hot (absent q (by simp)),ih (fun a m => absent a (by simp [m]))]
theorem untouched_prefix {n d : Nat} (p : List Gate) {gs : List Gate} (hot : Nat → Bool)
    (cl : CleanL n (p++gs)) : p.map (gate (n+p.length) d hot)=p := by
  apply unchanged_map hot
  intro q m read
  obtain ⟨k,get⟩ := List.mem_iff_getElem?.mp m
  have kp : k<p.length := List.getElem?_eq_some_iff.mp get |>.choose
  have whole : (p++gs)[k]?=some q := by rw [List.getElem?_append_left kp];exact get
  have lt := (cl k q whole).lt _ read
  omega
end PEqualNP.Outside.L_meta_9822.Clean.MixedReaderPatch
