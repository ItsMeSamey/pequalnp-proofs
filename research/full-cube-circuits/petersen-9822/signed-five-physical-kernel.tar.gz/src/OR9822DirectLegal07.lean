import OR9822DirectCuts
namespace Research.Graph9822ProfileArithmetic.Direct
set_option maxRecDepth 10000 in
theorem legal7 : (List.range' 112 16).all cutsLegal=true := by decide +kernel
end Research.Graph9822ProfileArithmetic.Direct
