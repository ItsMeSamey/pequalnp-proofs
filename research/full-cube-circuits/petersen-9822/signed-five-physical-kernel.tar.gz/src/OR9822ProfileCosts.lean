import OR9822H2EligiblePackedData
import OR9822ProfileBank
import OR9822LiteTransfer
import OR9822FastBase
namespace Research.Graph9822GlobalH2.ProfileCheck
open Research.Graph9822H2Check Research.Graph9822H2Eligibility
open Research.Graph9822LiteH2.Profile
def fit (j : Nat) :=
  let h := seedCode j
  let p := owner j
  let H := first p
  let B := base p
  decide (p<107) && (if p=106 then (h==H) && (fastBase h==B)
    else decide (negative H<65536) && sub (positive h) (positive H) &&
      sub (negative H) (negative h) && sub (fastBase h) B)
def validTag (H tag : Nat) := decide (tag &&& 63<50) &&
  cheaperRow H (quadTable[tag &&& 63]!) (row tag)
def lawful (k : Nat) := (cutIds (program k &&& 255)).all (fun i => decide (i<71)) &&
  (taggedRows k).all (validTag (first (k/2)))
attribute [local irreducible] first program taggedRows cutIds row positiveCut
theorem lawful_fields {k : Nat} (ok : lawful k=true)
    (cutsOK : ∀ i,i<71 → obstacle (positiveCut i)=true)
    (quadsOK : ∀ c,c<50 → quadGood (quadTable[c]!)=true ∧
      ∀ i∈quadTable[c]!,∀ j∈quadTable[c]!,i<j → pairDom i j=true) :
    (∀ m∈cutsFor k,obstacle m=true) ∧
    (∀ rs∈groupsFor k,∃ quad,quadGood quad=true ∧
      (∀ i∈quad,∀ j∈quad,i<j → pairDom i j=true) ∧ cheaperRow (first (k/2)) quad rs=true) := by
  obtain ⟨cut,group⟩ := Bool.and_eq_true_iff.mp ok
  constructor
  · intro m mem
    obtain ⟨i,hm,rfl⟩ := List.mem_map.mp mem
    exact cutsOK i (of_decide_eq_true (List.all_eq_true.mp cut i hm))
  · intro rs mem
    obtain ⟨tag,hm,rfl⟩ := List.mem_map.mp mem
    have ck := Bool.and_eq_true_iff.mp (List.all_eq_true.mp group tag hm)
    have quad := quadsOK _ (of_decide_eq_true ck.1)
    exact ⟨_,quad.1,quad.2,ck.2⟩
end Research.Graph9822GlobalH2.ProfileCheck
