import H3GlobalBatchSingle3009822
import H3GlobalBatchSingle3019822
import H3GlobalBatchSingle3029822
import H3GlobalBatchSingle3039822
import H3GlobalBatchSingle3049822
import H3GlobalBatchSingle3059822
import H3GlobalBatchSingle3069822
import H3GlobalBatchSingle3079822
import H3GlobalBatchSingle3089822
import H3GlobalBatchSingle3099822
import H3GlobalBatchSingle3109822
import H3GlobalBatchSingle3119822
namespace Research.Graph9822Planes
def rootsPage300 : List Nat := (batchSingle300.map Prod.fst) ++ ((batchSingle301.map Prod.fst) ++ ((batchSingle302.map Prod.fst) ++ ((batchSingle303.map Prod.fst) ++ ((batchSingle304.map Prod.fst) ++ ((batchSingle305.map Prod.fst) ++ ((batchSingle306.map Prod.fst) ++ ((batchSingle307.map Prod.fst) ++ ((batchSingle308.map Prod.fst) ++ ((batchSingle309.map Prod.fst) ++ ((batchSingle310.map Prod.fst) ++ ((batchSingle311.map Prod.fst))))))))))))
theorem allPage300 : PaidKeys rootsPage300 := paid_append (page_paid paidBatchSingle300) (paid_append (page_paid paidBatchSingle301) (paid_append (page_paid paidBatchSingle302) (paid_append (page_paid paidBatchSingle303) (paid_append (page_paid paidBatchSingle304) (paid_append (page_paid paidBatchSingle305) (paid_append (page_paid paidBatchSingle306) (paid_append (page_paid paidBatchSingle307) (paid_append (page_paid paidBatchSingle308) (paid_append (page_paid paidBatchSingle309) (paid_append (page_paid paidBatchSingle310) (page_paid paidBatchSingle311)))))))))))
end Research.Graph9822Planes
