import OR9822CenterCuts
namespace Research.Graph9822H2Check
set_option maxRecDepth 10000 in
theorem centerCuts07 : (List.range' 56 8).all (fun j => obstacle centerObstructions[j]!)=true := by decide +kernel
end Research.Graph9822H2Check
