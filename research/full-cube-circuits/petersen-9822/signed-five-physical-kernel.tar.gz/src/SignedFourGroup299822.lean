import SignedFourFiniteRows9822
namespace Research.SignedFactorFour
set_option maxRecDepth 12000
set_option maxHeartbeats 4000000
def r145 : Row := ([2,3,5,6], [4,7])
private theorem ok145 : rowGood r145=true := by decide +kernel
def r146 : Row := ([2,3,5,7], [0,6])
private theorem ok146 : rowGood r146=true := by decide +kernel
def r147 : Row := ([2,3,5,8], [0,1])
private theorem ok147 : rowGood r147=true := by decide +kernel
def r148 : Row := ([2,3,5,9], [0,1])
private theorem ok148 : rowGood r148=true := by decide +kernel
def r149 : Row := ([2,3,6,7], [0,1,5])
private theorem ok149 : rowGood r149=true := by decide +kernel
def page29 : List Row := [r145,r146,r147,r148,r149]
theorem paid29 : page29.all rowGood=true := by simp [page29,ok145,ok146,ok147,ok148,ok149]
end Research.SignedFactorFour
