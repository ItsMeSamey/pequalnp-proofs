import H3GlobalLedger9822
namespace Research.Graph9822Planes
abbrev ModeRow := Nat × List Nat × List Nat
def rowOK (r : ModeRow) := global3 r.1 false r.2.1 && global3 r.1 true r.2.2
theorem row_paid {r : ModeRow} (proof : rowOK r = true) : PaidMode r.1 := by
  have both := Bool.and_eq_true_iff.mp proof
  exact paid_both both.1 both.2
theorem page_paid {rs : List ModeRow} (p : rs.all rowOK = true) : PaidKeys (rs.map Prod.fst) := by
  induction rs with
  | nil => trivial
  | cons r rs ih =>
    have both := Bool.and_eq_true_iff.mp p
    exact ⟨row_paid both.1, ih both.2⟩
end Research.Graph9822Planes
