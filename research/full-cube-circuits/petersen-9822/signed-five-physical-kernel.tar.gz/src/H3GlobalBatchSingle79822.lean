import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle7 : List ModeRow := [(312454,[17726,59683,23694,255,17695,1530,18798,3198,17846,17822,503],[37182,51495,3198,17726,17767,17846,18798,503,17695,3135])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle7 : batchSingle7.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
