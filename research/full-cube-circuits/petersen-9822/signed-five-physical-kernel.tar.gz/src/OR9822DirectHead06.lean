import OR9822DirectAlignment
namespace Research.Graph9822GlobalH2.ProfileCheck
set_option maxRecDepth 12000 in
theorem head6 : (List.range' 72 12).all alignHead=true := by decide +kernel
end Research.Graph9822GlobalH2.ProfileCheck
