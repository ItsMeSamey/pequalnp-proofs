import OR9822CenterCuts
namespace Research.Graph9822H2Check
set_option maxRecDepth 10000 in
theorem centerCuts03 : (List.range' 24 8).all (fun j => obstacle centerObstructions[j]!)=true := by decide +kernel
end Research.Graph9822H2Check
