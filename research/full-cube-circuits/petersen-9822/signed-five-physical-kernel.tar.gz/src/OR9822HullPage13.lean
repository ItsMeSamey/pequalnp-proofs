import OR9822HullPacket
namespace Research.Graph9822LiteH2.Hull
set_option maxRecDepth 30000 in
set_option maxHeartbeats 14000000 in
theorem hullPage13 : (List.range' 52 4).all paidHull=true := by decide +kernel
end Research.Graph9822LiteH2.Hull
