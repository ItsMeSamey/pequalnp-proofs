import MixedLiteralC5Table9822
namespace Research.LiteralC5.Table
theorem row18 : row 132718 = true := by decide +kernel
theorem row19 : row 135168 = true := by decide +kernel
theorem row20 : row 135280 = true := by decide +kernel
end Research.LiteralC5.Table
