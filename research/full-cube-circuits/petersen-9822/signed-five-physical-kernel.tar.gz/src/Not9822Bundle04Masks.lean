import Not9822Bundle03Sockets

-- Not9822Mask
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

def pack (f : Nat → Bool) : Nat :=
  (BitVec.ofBoolListLE (List.ofFn (fun v : Fin 10 => f v.val))).toNat

theorem pack_lt (f : Nat → Bool) : pack f < 1024 := by
  simpa [pack] using (BitVec.ofBoolListLE (List.ofFn (fun v : Fin 10 => f v.val))).isLt

theorem pack_bit (f : Nat → Bool) (i : Nat) :
    (pack f).testBit i = (decide (i < 10) && f i) := by
  change (BitVec.ofBoolListLE _).getLsbD i = _
  rw [BitVec.getLsbD_ofBoolListLE]
  rw [List.getD_eq_getElem?_getD,List.getElem?_ofFn]
  by_cases h : i < 10 <;> simp [h]


noncomputable def assigned (d : Indexed) (out : Nat) (shared : Nat → Bool) (v : Nat) : Nat := by
  classical
  exact if h : ∃ xs, Path d.edge out v xs then owner d.edge out shared v h else out

theorem assigned_live {d : Indexed} {out : Nat} {shared : Nat → Bool} {v : Nat}
    (live : ∃ xs, Path d.edge out v xs) : assigned d out shared v = owner d.edge out shared v live := by
  classical simp [assigned,live]

def priorMask (rep : Nat → Bool) (own : Nat → Nat) (cut : Nat) : Nat :=
  pack (fun v => rep v || decide (own v < cut))

def siteMask (rep : Nat → Bool) (own : Nat → Nat) (cut : Nat) : Nat :=
  pack (fun v => !rep v && decide (own v = cut))

theorem cubeBit (v : Nat) : (1023 : Nat).testBit v = decide (v < 10) :=
  Nat.testBit_two_pow_sub_one 10 v

theorem futureBit (rep : Nat → Bool) (own : Nat → Nat) (cut v : Nat) :
    (later (priorMask rep own cut) (siteMask rep own cut)).testBit v =
      (decide (v < 10) && !rep v && decide (cut < own v)) := by
  simp only [later,Nat.testBit_xor,Nat.testBit_or,cubeBit,priorMask,siteMask,pack_bit]
  by_cases bound : v < 10
  · rcases lt_trichotomy (own v) cut with lo | eq | hi
    · have ne := Nat.ne_of_lt lo
      have no := Nat.not_lt_of_ge (Nat.le_of_lt lo)
      cases h : rep v <;> simp [bound,h,lo,ne,no]
    · cases h : rep v <;> simp [bound,h,eq]
    · have ne := Nat.ne_of_gt hi
      have no := Nat.not_lt_of_ge (Nat.le_of_lt hi)
      cases h : rep v <;> simp [bound,h,hi,ne,no]
  · simp [bound]


theorem concreteBins (d : Indexed) (out cut : Nat) (shared rep : Nat → Bool)
    (finalWire : ∀ a b, d.edge a b → a ≠ out)
    (det : ∀ a, shared a = false → ∀ b c, d.edge a b → d.edge a c → b = c)
    (hc : shared cut = true) (live : ∃ xs, Path d.edge out cut xs) :
    SiteBins d out cut shared (siteMask rep (assigned d out shared) cut)
      (later (priorMask rep (assigned d out shared) cut) (siteMask rep (assigned d out shared) cut)) := by
  refine ⟨finalWire,det,hc,live,?_,?_⟩
  · intro v hv path
    simp [siteMask,pack_bit] at hv
    rw [←assigned_live path]
    exact hv.2.2
  · intro v hv path
    rw [futureBit] at hv
    simp at hv
    rw [←assigned_live path]
    exact hv.2

end Petersen9822.DagCut

-- Not9822BinLegal
namespace Petersen9822.DagCut

theorem subSingleton (n m : Nat) : sub (2^n) m = m.testBit n := by
  cases h : m.testBit n with
  | false =>
    have hn : (2^n) &&& m ≠ 2^n := by
      intro he
      have := congrArg (fun k : Nat => k.testBit n) he
      simp [Nat.testBit_two_pow,h] at this
    simp [sub,hn]
  | true =>
    have he : (2^n) &&& m = 2^n := by
      apply Nat.eq_of_testBit_eq
      intro i
      by_cases e : n = i
      · subst i
        simp [Nat.testBit_two_pow,h]
      · simp [Nat.testBit_two_pow,e]
    simp [sub,he]

theorem binDisjoint (rep : Nat → Bool) (own : Nat → Nat) (cut : Nat) :
    sub (siteMask rep own cut) (1023 ^^^ priorMask rep own cut) = true := by
  unfold sub
  apply beq_iff_eq.mpr
  apply Nat.eq_of_testBit_eq
  intro v
  simp only [Nat.testBit_and,Nat.testBit_xor,siteMask,priorMask,cubeBit,pack_bit]
  by_cases bound : v < 10 <;> cases h : rep v <;> rcases lt_trichotomy (own v) cut with h'|h'|h' <;>
    simp_all <;> omega

theorem binLegal (j cut : Nat) (rep : Nat → Bool) (own : Nat → Nat)
    (two : own 2 ≠ cut ∨ rep 2 = true)
    (one : (!rep 1 && decide (own 1 = cut)) = decide (j = 2))
    (six : j = 0 → own 6 ≠ cut ∨ rep 6 = true)
    (seven : j = 1 → own 7 ≠ cut ∨ rep 7 = true)
    (indep : edgeHit (siteMask rep own cut) = false) :
    legal j (priorMask rep own cut) (siteMask rep own cut) = true := by
  let s := siteMask rep own cut
  have rawBit (i : Nat) (hi : i < 10) : s.testBit i = (!rep i && decide (own i = cut)) := by
    simp [s,siteMask,pack_bit,hi]
  have no (i : Nat) (hi : i < 10) (h : own i ≠ cut ∨ rep i = true) :
      sub (2^i) s = false := by
    rw [subSingleton,rawBit i hi]
    rcases h with h | h <;> simp [h]
  have h2 : sub 4 s = false := no 2 (by decide) two
  have h1 : sub 2 s = decide (j = 2) := (subSingleton 1 s).trans ((rawBit 1 (by decide)).trans one)
  have hn : (decide (j < 2) && sub (64 <<< j) s) = false := by
    by_cases h : j < 2
    · have eq : j = 0 ∨ j = 1 := by omega
      rcases eq with rfl | rfl
      · exact no 6 (by decide) (six rfl)
      · exact no 7 (by decide) (seven rfl)
    · simp [h]
  change legal j (priorMask rep own cut) s = true
  have dis : sub s (1023 ^^^ priorMask rep own cut) = true := binDisjoint rep own cut
  simp only [legal,dis,h2,h1,hn,show edgeHit s = false from indep]
  simp

theorem advancePrior (rep : Nat → Bool) (own : Nat → Nat) (cut next : Nat)
    (lt : cut < next)
    (gap : ∀ v, v < 10 → rep v = false → cut < own v → next ≤ own v) :
    priorMask rep own cut ||| siteMask rep own cut = priorMask rep own next := by
  apply Nat.eq_of_testBit_eq
  intro v
  simp only [Nat.testBit_or,priorMask,siteMask,pack_bit]
  by_cases h : v < 10
  · cases hr : rep v with
    | true => simp [h]
    | false =>
      simp only [h,decide_true,Bool.true_and,Bool.false_or,Bool.not_false,hr]
      rcases lt_trichotomy (own v) cut with lt'|eq|gt
      · simp [lt',Nat.lt_trans lt' lt]
      · simp [eq,lt]
      · have hnext := gap v h hr gt
        simp [Nat.not_lt_of_ge hnext,Nat.ne_of_gt gt,Nat.not_lt_of_ge (Nat.le_of_lt gt)]
  · simp [h]

end Petersen9822.DagCut
