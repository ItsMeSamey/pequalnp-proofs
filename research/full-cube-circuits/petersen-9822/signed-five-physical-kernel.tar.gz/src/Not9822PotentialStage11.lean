import Not9822PotentialStage10

-- Not9822ThreeControl
namespace Petersen9822.DagCut
open Petersen9822.Potential
open Petersen9822.FirstSite
open PEqualNP.Outside.L_meta_9825.Engine

private theorem reaches_le {d : Indexed} {out a : Nat} {xs : List Nat}
    (p : Path d.edge out a xs) : ∀ v ∈ a :: xs, v ≤ out := by
  induction p with
  | stop => simp
  | @step a b xs _ e _ ih =>
    intro v hv
    rcases List.mem_cons.mp hv with rfl | h
    · exact Nat.le_trans (Nat.le_of_lt (d.chrono e)) (ih b List.mem_cons_self)
    · exact ih v h

theorem assigned_le_out (d : Indexed) (out : Nat) (shared : Nat → Bool) (v : Nat) :
    assigned d out shared v ≤ out := by
  classical
  by_cases live : ∃ xs, Path d.edge out v xs
  · rw [assigned_live live]
    exact reaches_le live.choose_spec _ (first_on_path live.choose_spec)
  · simp [assigned,live]

private theorem case_off (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) {d : Indexed} {out i j : Nat} (c : FifteenCore d out)
    (gi : RealGuard d out i) (gj : RealGuard d out j) (hi : i < 10) (hj : j < 10)
    (ij : (i,j) ∈ ([(1,2),(2,1)] : List (Nat × Nat)))
    (jAllowed : j ∈ ([1,2] : List Nat)) (oi : assigned d out (fork d) i = out)
    (oj : assigned d out (fork d) j ≠ out)
    (apart : gi.site ≠ gj.site) (cross : gi.site ≠ assigned d out (fork d) j) :
    ∀ v ∈ outside, fork d v.val = false := by
  classical
  let qj := assigned d out (fork d) j
  have lt : qj < out := lt_of_le_of_ne (assigned_le_out d out (fork d) j) oj
  have late := gi.defaults c hi
  have early := gj.defaults c hj
  have pg := gj.beforeOwner c hj
  change gj.site < qj at pg
  have il := gi.internal
  have jl := gj.internal
  obtain ⟨jqHigh,top⟩ := internal_owner c hj oj
  change fork d qj = true at jqHigh
  change qj < 25 at top
  have liveP := c.live gj.site jl (Nat.lt_trans gj.beforeOut c.upperOut)
  have liveQ := c.live qj (by omega) top
  have nextP : gj.site < assigned d out (fork d) i := by rw [oi]; exact Nat.lt_trans pg lt
  have nextQ : qj < assigned d out (fork d) i := by simpa only [oi] using lt
  have pBefore := no_raw_before c.finalWire (fork_unique d) gj.shared liveP nextP
  have qBefore := no_raw_before c.finalWire (fork_unique d) jqHigh liveQ nextQ
  let watch := [slot gi.site,slot gj.site,slot qj]
  let defVal := fun v : Slot => if v.val = gi.site then late.pass
    else if v.val = gj.site then early.pass else early.pol true
  have bound1 := Nat.lt_trans gi.beforeOut c.upperOut
  have bound2 := Nat.lt_trans gj.beforeOut c.upperOut
  have vg1 := slot_val gi.site (show gi.site < 32 by omega)
  have vg2 := slot_val gj.site (show gj.site < 32 by omega)
  have vq := slot_val qj (show qj < 32 by omega)
  change gi.site ≠ qj at cross
  have qdiff : qj ≠ gi.site := cross.symm
  have uniq : watch.Nodup := by
    change [slot gi.site,slot gj.site,slot qj].Nodup
    simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,not_or,List.nodup_nil,and_true]
    exact ⟨⟨fun e => apart (by simpa [vg1,vg2] using congrArg Fin.val e),
      fun e => cross (by simpa [vg1,vq] using congrArg Fin.val e)⟩,
      ⟨fun e => (Nat.ne_of_lt pg) (by simpa [vg2,vq] using congrArg Fin.val e),fun h => h⟩⟩
  refine three_monitor_off c5Prior d c.diagram out j c.upperOut jAllowed c.op c.signed c.computes c.finalWire
    c.live watch rfl uniq ?_ defVal ?_
  · intro v hv
    simp only [watch,List.mem_cons,List.not_mem_nil,or_false] at hv
    rcases hv with rfl|rfl|rfl
    · rw [vg1]; exact ⟨(ids_match_kind _).mp (by simp [initialKind,vg1,bound1,Nat.not_lt_of_ge il]),gi.shared⟩
    · rw [vg2]; exact ⟨(ids_match_kind _).mp (by simp [initialKind,vg2,bound2,Nat.not_lt_of_ge jl]),gj.shared⟩
    · rw [vq]; exact ⟨(ids_match_kind _).mp (by simp [initialKind,vq,top,show ¬qj < 10 by omega]),jqHigh⟩
  · intro row neg v hv
    let a : Fin 1024 := ⟨row.val &&& 313,Nat.lt_of_le_of_lt Nat.and_le_left row.isLt⟩
    have sa : sub a.val 313 = true := by simp [a,sub,Nat.and_assoc]
    obtain ⟨g₁,_,g₂,f⟩ := fourDefaults ij late early pBefore qBefore a sa neg
    simp only [watch,List.mem_cons,List.not_mem_nil,or_false] at hv
    rcases hv with rfl|rfl|rfl <;>
      simp_all [defVal,projectRow,a,Ne.symm apart,qdiff,Nat.ne_of_gt pg]
    exact f

theorem repeatSupport (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) {d : Indexed} {out : Nat} (c : FifteenCore d out)
    (g1 : RealGuard d out 1) (g2 : RealGuard d out 2) (apart : g1.site ≠ g2.site)
    (zero : fork d 0 = false) (three : fork d 3 = false) : sub (pack (fork d)) 304 = true := by
  apply repeatedWithin458 d zero three
  have different := ownersSeparate d out (fork d) c.finalWire (fork_unique d) c.properSockets
    (fun n g h => signedSocketOf (c.op n) g.op (c.signed n g h)) c.computes
  rcases oneOwnerAtOutput c5Prior c g1 g2 apart with left | right
  · apply case_off c5Prior c g1 g2 (by decide) (by decide) (by decide) (by decide) left _ apart
      (g1.excludesNeighbor c (by decide) 2 192 (by decide)).symm
    omega
  · apply case_off c5Prior c g2 g1 (by decide) (by decide) (by decide) (by decide) right _ apart.symm
      (g2.excludesNeighbor c (by decide) 1 192 (by decide)).symm
    omega

end Petersen9822.DagCut

-- Not9822PhysicalRoster
namespace Petersen9822.DagCut
open Petersen9822.Potential
open Petersen9822.FirstSite

theorem actual_fork_range {d : Indexed} {out k} (c : FifteenCore d out)
    (hk : fork d k = true) : k < 25 ∧ k ≠ out := by
  classical
  obtain ⟨j,_,hj,_,_⟩ := of_decide_eq_true hk
  have before := d.chrono hj
  have nonsink := c.finalWire _ _ hj
  obtain ⟨g,ok,_⟩ := hj
  exact ⟨Nat.lt_trans before (c.diagram.extent j g ok).2,nonsink⟩

theorem mem_innerFork {d : Indexed} {v : Slot} :
    v ∈ innerForks d ↔ 10 ≤ v.val ∧ v.val < 25 ∧ fork d v.val = true := by
  classical
  have ids : ∀ i : Slot, i ∈ List.ofFn gateSlot ↔ 10 ≤ i.val ∧ i.val < 25 := by decide +kernel
  simp only [innerForks,Finset.mem_filter,List.mem_toFinset,ids,and_assoc]

theorem physical_roster {d : Indexed} {out : Nat} (c : FifteenCore d out)
    (a : RealGuard d out 1) (b : RealGuard d out 2) (apart : a.site ≠ b.site)
    (early : assigned d out (fork d) 1 ≠ out) :
    let q := assigned d out (fork d) 1
    innerForks d = {slot a.site,slot b.site,slot q} ∨
      ∃ w ∈ innerForks d, w ≠ slot a.site ∧ w ≠ slot b.site ∧ w ≠ slot q ∧
        innerForks d = {slot a.site,slot b.site,slot q,w} := by
  classical
  let q := assigned d out (fork d) 1
  change innerForks d = {slot a.site,slot b.site,slot q} ∨ _
  have aq : a.site < q := a.beforeOwner c (by decide)
  have qb : q ≠ b.site := b.excludesNeighbor c (by decide) 1 192 (by decide)
  obtain ⟨qhot,q25⟩ := internal_owner c (by decide : 1 < 10) early
  change fork d q = true at qhot
  change q < 25 at q25
  have a25 := Nat.lt_trans a.beforeOut c.upperOut
  have b25 := Nat.lt_trans b.beforeOut c.upperOut
  have av := slot_val a.site (by omega)
  have bv := slot_val b.site (by omega)
  have qv := slot_val q (by omega)
  have neq {x y : Nat} (hx : (slot x).val = x) (hy : (slot y).val = y) (h : x ≠ y) :
      slot x ≠ slot y := fun eq => h (by simpa only [hx,hy] using congrArg Fin.val eq)
  have budget := combined_excess d c.diagram out c.upperOut c.finalWire c.live c.computes
  have repeats := at_least_two_repeated d c.diagram out c.lowerOut c.computes c.properSockets c.op c.signed
  apply forkRoster
  · exact mem_innerFork.mpr (by rw [av]; exact ⟨a.internal,a25,a.shared⟩)
  · exact mem_innerFork.mpr (by rw [bv]; exact ⟨b.internal,b25,b.shared⟩)
  · exact mem_innerFork.mpr (by rw [qv]; exact ⟨Nat.le_trans a.internal (Nat.le_of_lt aq),q25,qhot⟩)
  · exact neq av bv apart
  · exact neq av qv (Nat.ne_of_lt aq)
  · exact neq bv qv qb.symm
  · omega

end Petersen9822.DagCut
