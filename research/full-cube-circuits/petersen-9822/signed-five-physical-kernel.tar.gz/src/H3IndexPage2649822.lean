import H3SinglePage2649822
import H3GlobalRootIndex9822
namespace Research.Graph9822Planes
theorem frozenPaid264 : PaidKeys frozen264 := by
  have e : rootsPage264 = frozen264 := by decide +kernel
  rw [← e]
  exact allPage264
end Research.Graph9822Planes
