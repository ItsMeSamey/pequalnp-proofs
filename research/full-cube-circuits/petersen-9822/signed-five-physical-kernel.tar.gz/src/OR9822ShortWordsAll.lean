import OR9822ShortWordsPage00
import OR9822ShortWordsPage01
import OR9822ShortWordsPage02
import OR9822ShortWordsPage03
import OR9822ShortWordsPage04
import OR9822ShortWordsPage05
import OR9822ShortWordsPage06
import OR9822ShortWordsPage07
import OR9822ShortWordsPage08
import OR9822ShortWordsPage09
import OR9822ShortWordsPage10
import OR9822ShortWordsPage11
import OR9822ShortWordsPage12
import OR9822ShortWordsPage13
import OR9822ShortWordsPage14
import OR9822ShortWordsPage15
import OR9822ShortWordsPage16
import OR9822ShortWordsPage17
import OR9822ShortWordsPage18
import OR9822ShortWordsPage19
import OR9822ShortWordsPage20
import OR9822ShortWordsPage21
import OR9822ShortWordsPage22
import OR9822ShortWordsPage23
import OR9822ShortWordsPage24
import OR9822ShortWordsPage25
import OR9822ShortWordsPage26
import OR9822ShortWordsPage27
namespace Research.Graph9822ProfileArithmetic.Laws
theorem allWords (k : Nat) (lo : k<169) : binaryWords k=shortWords k := by
  by_cases b0 : k<3
  · exact beq_iff_eq.mp (List.all_eq_true.mp words0 k (by simp only [List.mem_range'_1]; omega))
  by_cases b1 : k<7
  · exact beq_iff_eq.mp (List.all_eq_true.mp words1 k (by simp only [List.mem_range'_1]; omega))
  by_cases b2 : k<9
  · exact beq_iff_eq.mp (List.all_eq_true.mp words2 k (by simp only [List.mem_range'_1]; omega))
  by_cases b3 : k<11
  · exact beq_iff_eq.mp (List.all_eq_true.mp words3 k (by simp only [List.mem_range'_1]; omega))
  by_cases b4 : k<16
  · exact beq_iff_eq.mp (List.all_eq_true.mp words4 k (by simp only [List.mem_range'_1]; omega))
  by_cases b5 : k<18
  · exact beq_iff_eq.mp (List.all_eq_true.mp words5 k (by simp only [List.mem_range'_1]; omega))
  by_cases b6 : k<22
  · exact beq_iff_eq.mp (List.all_eq_true.mp words6 k (by simp only [List.mem_range'_1]; omega))
  by_cases b7 : k<24
  · exact beq_iff_eq.mp (List.all_eq_true.mp words7 k (by simp only [List.mem_range'_1]; omega))
  by_cases b8 : k<30
  · exact beq_iff_eq.mp (List.all_eq_true.mp words8 k (by simp only [List.mem_range'_1]; omega))
  by_cases b9 : k<32
  · exact beq_iff_eq.mp (List.all_eq_true.mp words9 k (by simp only [List.mem_range'_1]; omega))
  by_cases b10 : k<35
  · exact beq_iff_eq.mp (List.all_eq_true.mp words10 k (by simp only [List.mem_range'_1]; omega))
  by_cases b11 : k<37
  · exact beq_iff_eq.mp (List.all_eq_true.mp words11 k (by simp only [List.mem_range'_1]; omega))
  by_cases b12 : k<43
  · exact beq_iff_eq.mp (List.all_eq_true.mp words12 k (by simp only [List.mem_range'_1]; omega))
  by_cases b13 : k<45
  · exact beq_iff_eq.mp (List.all_eq_true.mp words13 k (by simp only [List.mem_range'_1]; omega))
  by_cases b14 : k<48
  · exact beq_iff_eq.mp (List.all_eq_true.mp words14 k (by simp only [List.mem_range'_1]; omega))
  by_cases b15 : k<50
  · exact beq_iff_eq.mp (List.all_eq_true.mp words15 k (by simp only [List.mem_range'_1]; omega))
  by_cases b16 : k<58
  · exact beq_iff_eq.mp (List.all_eq_true.mp words16 k (by simp only [List.mem_range'_1]; omega))
  by_cases b17 : k<60
  · exact beq_iff_eq.mp (List.all_eq_true.mp words17 k (by simp only [List.mem_range'_1]; omega))
  by_cases b18 : k<64
  · exact beq_iff_eq.mp (List.all_eq_true.mp words18 k (by simp only [List.mem_range'_1]; omega))
  by_cases b19 : k<72
  · exact beq_iff_eq.mp (List.all_eq_true.mp words19 k (by simp only [List.mem_range'_1]; omega))
  by_cases b20 : k<76
  · exact beq_iff_eq.mp (List.all_eq_true.mp words20 k (by simp only [List.mem_range'_1]; omega))
  by_cases b21 : k<85
  · exact beq_iff_eq.mp (List.all_eq_true.mp words21 k (by simp only [List.mem_range'_1]; omega))
  by_cases b22 : k<87
  · exact beq_iff_eq.mp (List.all_eq_true.mp words22 k (by simp only [List.mem_range'_1]; omega))
  by_cases b23 : k<99
  · exact beq_iff_eq.mp (List.all_eq_true.mp words23 k (by simp only [List.mem_range'_1]; omega))
  by_cases b24 : k<103
  · exact beq_iff_eq.mp (List.all_eq_true.mp words24 k (by simp only [List.mem_range'_1]; omega))
  by_cases b25 : k<115
  · exact beq_iff_eq.mp (List.all_eq_true.mp words25 k (by simp only [List.mem_range'_1]; omega))
  by_cases b26 : k<129
  · exact beq_iff_eq.mp (List.all_eq_true.mp words26 k (by simp only [List.mem_range'_1]; omega))
  exact beq_iff_eq.mp (List.all_eq_true.mp words27 k (by simp only [List.mem_range'_1]; omega))
end Research.Graph9822ProfileArithmetic.Laws
