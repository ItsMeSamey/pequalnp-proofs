import H3GlobalPages9822
namespace Research.Graph9822Planes
def batchSingle98 : List ModeRow := [(100975758,[28974,4815,31121,24759,14535,12523,28958,510,21095,10471,5246,20887],[28974,12726,5246,12967,24759])]
set_option maxRecDepth 16000 in
set_option maxHeartbeats 8000000 in
theorem paidBatchSingle98 : batchSingle98.all rowOK = true := by decide +kernel
end Research.Graph9822Planes
