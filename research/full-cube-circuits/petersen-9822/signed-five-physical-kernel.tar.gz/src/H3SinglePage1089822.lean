import H3GlobalBatchSingle1089822
import H3GlobalBatchSingle1099822
import H3GlobalBatchSingle1109822
import H3GlobalBatchSingle1119822
import H3GlobalBatchSingle1129822
import H3GlobalBatchSingle1139822
import H3GlobalBatchSingle1149822
import H3GlobalBatchSingle1159822
import H3GlobalBatchSingle1169822
import H3GlobalBatchSingle1179822
import H3GlobalBatchSingle1189822
import H3GlobalBatchSingle1199822
namespace Research.Graph9822Planes
def rootsPage108 : List Nat := (batchSingle108.map Prod.fst) ++ ((batchSingle109.map Prod.fst) ++ ((batchSingle110.map Prod.fst) ++ ((batchSingle111.map Prod.fst) ++ ((batchSingle112.map Prod.fst) ++ ((batchSingle113.map Prod.fst) ++ ((batchSingle114.map Prod.fst) ++ ((batchSingle115.map Prod.fst) ++ ((batchSingle116.map Prod.fst) ++ ((batchSingle117.map Prod.fst) ++ ((batchSingle118.map Prod.fst) ++ ((batchSingle119.map Prod.fst))))))))))))
theorem allPage108 : PaidKeys rootsPage108 := paid_append (page_paid paidBatchSingle108) (paid_append (page_paid paidBatchSingle109) (paid_append (page_paid paidBatchSingle110) (paid_append (page_paid paidBatchSingle111) (paid_append (page_paid paidBatchSingle112) (paid_append (page_paid paidBatchSingle113) (paid_append (page_paid paidBatchSingle114) (paid_append (page_paid paidBatchSingle115) (paid_append (page_paid paidBatchSingle116) (paid_append (page_paid paidBatchSingle117) (paid_append (page_paid paidBatchSingle118) (page_paid paidBatchSingle119)))))))))))
end Research.Graph9822Planes
