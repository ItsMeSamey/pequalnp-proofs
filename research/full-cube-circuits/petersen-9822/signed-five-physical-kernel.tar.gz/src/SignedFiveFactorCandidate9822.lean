import SignedFiveFactorPhysical9822
import CleanDelete9822

namespace PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean
open Research.Graph9822Profiles

open Research.Graph9822Profiles.FactorFour
theorem candidate_five_factor {C : Circuit} (cand : Candidate C)
    (minimal : Reduced 10 C.gates C.output) (one : C.gates.countP countsNot=1)
    (low : C.gates.countP (fun q => match q.op with | .and => true | _ => false) ≤ 5) :
    ∃ (D : Finset V) (four : D.card=4) (six : Dᶜ.card=6),
      Model4 (D.orderEmbOfFin four) (Dᶜ.orderEmbOfFin six) := by
  obtain ⟨pre,g,post,split,inv,pp,pt,cut⟩ := physical_cut_positive_lists cand one
  let isA : GateOp → Bool := fun op => match op with | .and => true | _ => false
  have cap : ((outerCircuit 10 pre post C.output).gates.map readDir).countP
      Research.Graph9822Resolution.Gate.isAnd ≤ 5 := by
    rw [List.countP_map]
    change (outerCircuit 10 pre post C.output).gates.countP (fun q => isA q.op) ≤ 5
    rw [outerCount]
    change C.gates.countP (fun q => isA q.op) ≤ 5 at low
    simpa [split,List.countP_append,List.countP_cons,inv,isA] using low
  have eq (x : Input) : vl C.gates x C.output = edge x := cand.2.2 x
  have nc : ∃ x y : Input,vl C.gates x C.output ≠ vl C.gates y C.output := by
    refine ⟨fun _ => false,fun _ => true,?_⟩
    rw [eq,eq]
    decide
  have bound : C.output < 10+C.gates.length := by
    by_contra! no
    have on := eq (fun _ => true)
    rw [vl_beyond _ _ _ no] at on
    contradiction
  have sz := cand.2.1
  change C.gates.length ≤ 17 at sz
  rw [split,List.length_append,List.length_cons] at sz
  have size : pre.length+post.length ≤ 16 := by omega
  rw [split] at minimal nc bound
  exact DirectCube.physical_five_factor minimal nc pp pt cut size bound cap

end PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.SignedClamp.candidate_five_factor
