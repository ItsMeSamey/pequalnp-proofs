from pathlib import Path
import sys,struct,zlib,json,inspect,hashlib
dst=Path(__file__).resolve().parent
pkg=dst if (dst/'replay_h3_demands.py').exists() else dst.parent/'official9822-packaging'
sys.path.insert(0,str(pkg))
import replay_h3_demands as core
src=inspect.getsource(core.replay).replace('assert_terminal(s);counts[1]+=1','out.append((h,s));counts[1]+=1')
scope=dict(core.__dict__,out=[]);exec(src,scope)
data=(pkg/'h3-demands.zlib').read_bytes();b=zlib.decompress(data);assert b[:6]==b'H3D1'+struct.pack('<H',335)
o=6;counts=[0,0,0]
for k in core.read_roots():
 h,n=struct.unpack_from('<IH',b,o);o+=6;assert h==k
 words=struct.unpack_from('<'+'H'*n,b,o);o+=2*n
 for i,total in enumerate(scope['replay'](h,words)):counts[i]+=total
assert o==len(b) and counts==[203180,876,10731]
assert len(scope['out'])==len(set(scope['out']))==876
(dst/'leaves.json').write_text(json.dumps(scope['out'],separators=(',',':'))+'\n')
print(counts,hashlib.sha256(data).hexdigest(),flush=True)
indexed = json.loads((pkg/'h3-terminal-members.json').read_text())
assert len(indexed) == 335
assert sum(not states for _,states in indexed) == 19
pairs = [(h,s) for h,states in indexed for s in states]
assert len(pairs) == 876 and all(0 <= s < 2**29 for _,s in pairs)
assert set(pairs) == set(scope['out'])
print('All 876 pairs match the root-indexed schedule.')
