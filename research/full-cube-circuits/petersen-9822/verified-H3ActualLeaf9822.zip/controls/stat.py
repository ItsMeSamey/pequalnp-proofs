import sys,json
from pathlib import Path
d=Path(__file__).parent
sys.path.insert(0,str(d if (d/'replay_h3_demands.py').exists() else d.parent/'official9822-packaging'))
from replay_h3_demands import *
rows=json.loads((d/'leaves.json').read_text()); stats=[]
for h,s in rows:
 t=s&8191;f=s>>13;c=n=x=0
 for attach in [False,True]:
  hp=h&8191 if attach else 0;hn=h>>13 if attach else 0
  for b in covers(t):
   for a in covers(t&~hp):
    c+=1
    if a&b or f&(NN[a]|hn)&NN[b]:continue
    A=free(f&NN[b])&~b;B=free(f&(NN[a]|hn))&~a
    ep=(EP[A]|hp)&EP[B];nn=(NN[A]|hn)&NN[B]
    if not nn or any(not ep&~star for star in stars):continue
    n+=1
    for ax in submasks(A&~a):
     av=ax|a
     for bx in submasks(B&~(b|av)):
      bv=bx|b;x+=1;q=(EP[av]|hp)&EP[bv];neg=(NN[av]|hn)&NN[bv]
      assert t&~q or f&neg or not novel(h,q,neg)
 stats.append((c,n,x))
(d/'metrics.json').write_text(json.dumps(stats,separators=(',',':'))+'\n')
print('totals',[sum(col) for col in zip(*stats)],'max', [max(col) for col in zip(*stats)])
print('hardest',max(enumerate(stats),key=lambda r:r[1][0]+r[1][2]))
