import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

scratch = Path('/workspace/scratch')
base = scratch / 'official9822-lean'
here = Path(__file__).resolve().parent
objects = Path('/dev/shm/official9822-new-objects')
roots = sys.argv[1:] or ['H3ActualLeaf9822']
records = {}
members = {}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def visit(name):
    if name in records:
        return
    source = base / f'{name}.lean'
    obj = objects / f'{name}.olean'
    s, o = digest(source.read_bytes()), digest(obj.read_bytes())
    for log in sorted((base / 'receipts').glob(f'*/{name}.log'), reverse=True):
        table = log.parent / 'digests.txt'
        inputs = log.with_suffix('.inputs.json')
        if table.exists() and o in table.read_text() and s in table.read_text() and inputs.exists():
            cfg = json.loads(inputs.read_text())
            if cfg['source'] == s:
                break
    else:
        raise ValueError(f'Missing matching receipt {name}')
    records[name] = dict(source=s, object=o, imports=cfg['imports'], run=log.parent.name, log=digest(log.read_bytes()))
    members['sources/'+source.name] = source.read_bytes()
    for receipt in (log, inputs, table):
        members[f'receipts/{name}/{receipt.name}'] = receipt.read_bytes()
    for path, want in cfg['imports'].items():
        module = Path(path).stem
        if (module.startswith('H3Leaf') or module in ['H3DemandNumeric9822','H3TerminalAt9822','H3TerminalMember9822']) and (base / (module+'.lean')).exists():
            visit(module)
            assert records[module]['object']==want
for root in roots:
    visit(root)
members['manifest.json'] = json.dumps(dict(roots=roots,modules=records),sort_keys=True,indent=2).encode()
pkg=scratch/'official9822-packaging'
for file in [here/'README.md',here/'original-replay.log',here/'extract.py',here/'stat.py',here/'pages.py',here/'metrics.json',here/'leaves.json',
             pkg/'h3-terminal-members.json',pkg/'h3-demands.zlib',pkg/'h3-rectangles.zlib',
             pkg/'replay_h3_demands.py',pkg/'verify_frozen_h3_demands.py',Path(__file__)]:
    members['controls/'+file.name] = file.read_bytes()
dest=here/('verified-'+roots[0]+'.zip')
with zipfile.ZipFile(dest, 'w') as z:
    for name,data in sorted(members.items()):
        z.writestr(zipfile.ZipInfo(name),data,compress_type=zipfile.ZIP_DEFLATED)
print(len(records),dest,digest(dest.read_bytes()))
