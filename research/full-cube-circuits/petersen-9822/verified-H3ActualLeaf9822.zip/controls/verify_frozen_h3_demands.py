"""Replay the durable 335 original first-feature packets and enforce exact EOF."""
from replay_h3_demands import *
import hashlib
b=zlib.decompress((here/'h3-demands.zlib').read_bytes());assert b[:6]==b'H3D1'+struct.pack('<H',335)
roots=read_roots();offset=6;tot=[0]*3;hints=[];lengths=[]
for i,h in enumerate(roots):
    H,n=struct.unpack_from('<IH',b,offset);offset+=6;assert H==h
    words=struct.unpack_from('<'+'H'*n,b,offset);offset+=2*n
    counts=replay(h,words);tot=[a+c for a,c in zip(tot,counts)]
    hints.extend(words);lengths.append(n)
assert offset==len(b) and tot==[203180,876,10731]
rank={x:i for i,x in enumerate([0]+sorted(sum(1<<k for k in vs) for vs in combinations(range(16),8)))}
def pack_words(bits,items):
    out=[];w=p=0
    for x in items:
        w|=x<<p;p+=bits
        if p>=63:out.append(w%(1<<63));w>>=63;p-=63
    if p:out.append(w)
    return out
def src(a):return len('['+','.join(map(str,a))+']')
print(dict(dead=tot[0],rare=tot[1],cliques=tot[2],hints=len(hints),distinct=len(set(hints)),min=min(lengths),max=max(lengths),literal16=src(pack_words(16,hints)),rank14=src(pack_words(14,[rank[x] for x in hints])),lengths=src(lengths),roots=src(roots),sha256=hashlib.sha256((here/'h3-demands.zlib').read_bytes()).hexdigest()))
