from pathlib import Path
import json
d=Path(__file__).resolve().parent;out=d.parent/'official9822-lean';rows=sorted(json.loads((d/'leaves.json').read_text()));N=12
batch=lambda i:f'H3LeafGroup{i:02}9822'
txt=lambda group:'['+','.join(f'({h},{s})' for h,s in group)+']'
ns='namespace Research.Graph9822H3Leaf\n'
end='end Research.Graph9822H3Leaf\n'
for i in range(0,len(rows),N):
 k=i//N
 src='import H3LeafCheck9822\n'+ns+f'def gs{k:02} : List (Nat × Nat) := '+txt(rows[i:i+N])+f'\ntheorem pass{k:02} : gs{k:02}.all (fun (h,s) => leafCheck h s)=true := by decide +kernel\n'+end
 (out/(batch(k)+'.lean')).write_text(src)
for k in range(10):
 ids=range(k*8,min(73,k*8+8));src=''.join('import '+batch(i)+'\n' for i in ids)+ns
 src+=f'def bag{k} : List (Nat × Nat) := '+' ++ '.join(f'gs{i:02}' for i in ids)+'\n'
 src+=f'theorem bagOK{k} : bag{k}.all (fun (h,s) => leafCheck h s)=true := by simp [bag{k},'+','.join(f'pass{i:02}' for i in ids)+']\n'
 (out/f'H3LeafBag{k}9822.lean').write_text(src+end)
s=''.join(f'import H3LeafBag{k}9822\n' for k in range(10))+ns
s+='def scheduled : List (Nat × Nat) := '+' ++ '.join(f'bag{k}' for k in range(10))+'\n'
s+='theorem checked_schedule : scheduled.all (fun (h,s) => leafCheck h s)=true := by simp [scheduled,'+','.join(f'bagOK{k}' for k in range(10))+']\n'
s+='''theorem all_terminal {h s : Nat} (entry : (h,s) ∈ scheduled) :
    Graph9822DemandThree.terminal h s=true :=
  terminal_of_check (List.all_eq_true.mp checked_schedule (h,s) entry)
end Research.Graph9822H3Leaf
#print axioms Research.Graph9822H3Leaf.all_terminal
'''
(out/'H3LeafSchedule9822.lean').write_text(s)
