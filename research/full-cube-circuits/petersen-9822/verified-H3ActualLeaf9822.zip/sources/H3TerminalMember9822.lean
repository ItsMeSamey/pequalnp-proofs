import H3TerminalAt9822
namespace Research.Graph9822DemandThree
attribute [local irreducible] leafKeys
set_option maxRecDepth 4000

theorem hasLeaf_mem (key fuel lo hi : Nat) (ok : hasLeaf key fuel lo hi = true) :
    key ∈ leafKeys.toList := by
  induction fuel generalizing lo hi with
  | zero =>
    change false = true at ok
    exact Bool.noConfusion ok
  | succ f ih =>
    let mid := (lo+hi)/2
    change (if lo >= hi then false else
      match leafKeys[mid]? with
      | none => false
      | some p => if p=key then true else if p<key then
          hasLeaf key f (mid+1) hi else hasLeaf key f lo mid) = true at ok
    split at ok
    next => exact Bool.noConfusion ok
    next =>
      split at ok
      next => exact Bool.noConfusion ok
      next p entry =>
        split at ok
        next eq =>
          subst p
          exact List.mem_iff_getElem?.mpr ⟨mid,by simpa using entry⟩
        next =>
          split at ok <;> exact ih _ _ ok

theorem terminalAt_mem {h s : Nat} (ok : terminalAt h s = true) :
    s < 2^29 ∧ ((h <<< 29) ||| s) ∈ leafKeys.toList := by
  have both := Bool.and_eq_true_iff.mp ok
  exact ⟨of_decide_eq_true both.1,hasLeaf_mem _ _ _ _ both.2⟩

end Research.Graph9822DemandThree
