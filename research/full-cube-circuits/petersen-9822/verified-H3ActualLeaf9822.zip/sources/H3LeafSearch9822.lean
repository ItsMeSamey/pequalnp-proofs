import H3TerminalMember9822
namespace Research.Graph9822H3Leaf
open Research.Graph9822DemandThree
attribute [local irreducible] leafKeys
def decode (k : Nat) : Nat × Nat := (k >>> 29,k % 2^29)
theorem decoded_marked {h s : Nat} (marked : terminalAt h s=true) :
    (h,s)∈leafKeys.toList.map decode := by
  obtain ⟨small,mem⟩ := terminalAt_mem marked
  have eq : decode ((h <<< 29) ||| s)=(h,s) := by
    rw [←Nat.shiftLeft_add_eq_or_of_lt small]
    unfold decode
    rw [Nat.shiftLeft_eq,Nat.shiftRight_eq_div_pow]
    congr 1 <;> omega
  exact List.mem_map.mpr ⟨_,mem,eq⟩
end Research.Graph9822H3Leaf
