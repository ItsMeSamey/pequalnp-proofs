import H3LeafSchedule9822
import H3LeafSearch9822
namespace Research.Graph9822H3Leaf
open Research.Graph9822DemandThree
set_option maxRecDepth 20000 in
theorem table_binding : leafKeys.toList.map decode=scheduled := by decide +kernel

theorem actual_terminal {h s : Nat} (marked : terminalAt h s=true) :
    terminal h s=true := all_terminal (table_binding ▸ decoded_marked marked)
end Research.Graph9822H3Leaf
#print axioms Research.Graph9822H3Leaf.actual_terminal
