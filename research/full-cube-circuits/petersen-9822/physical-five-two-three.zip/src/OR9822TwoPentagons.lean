import OR9822H2Centers
namespace Research.Graph9822TwoHidden
open Research.Graph9822.FourSaturation

private def pentagon (a b c d e : Bool) : Bool :=
  (a||b) && (b||c) && (c||d) && (d||e) && (e||a)

private theorem pentagon_three : ∀ a b c d e : Bool, pentagon a b c d e = true →
    3 ≤ ([a,b,c,d,e].filter id).length := by decide

def outer5 : List (Fin 10) := [0,4,3,8,5]
def inner5 : List (Fin 10) := [1,2,7,9,6]

private theorem ten_disjoint : (outer5++inner5).Nodup := by decide

/-- The two disjoint original pentagons each require three centers. -/
theorem six_centers (cs : List (Fin 10))
    (covers : ∀ e ∈ edges, ∃ c ∈ cs, c.val=e.1 ∨ c.val=e.2) : 6 ≤ cs.length := by
  let seen (i : Fin 10) := cs.contains i
  have touched (a b : Fin 10) (edge : (a.val,b.val) ∈ edges ∨ (b.val,a.val) ∈ edges) :
      seen a || seen b := by
    rcases edge with e | e
    · obtain ⟨c,hc,ce|ce⟩ := covers _ e
      · have eq : c=a := Fin.ext ce; subst c; simp [seen,hc]
      · have eq : c=b := Fin.ext ce; subst c; simp [seen,hc]
    · obtain ⟨c,hc,ce|ce⟩ := covers _ e
      · have eq : c=b := Fin.ext ce; subst c; simp [seen,hc]
      · have eq : c=a := Fin.ext ce; subst c; simp [seen,hc]
  have cycle (a b c d e : Fin 10)
      (ab : seen a || seen b) (bc : seen b || seen c) (cd : seen c || seen d)
      (de : seen d || seen e) (ea : seen e || seen a) :
      3 ≤ ([a,b,c,d,e].filter seen).length := by
    have h := pentagon_three (seen a) (seen b) (seen c) (seen d) (seen e) (by simp [pentagon,ab,bc,cd,de,ea])
    change 3 ≤ (([a,b,c,d,e].map seen).filter id).length at h
    simpa only [List.filter_map,List.length_map,Function.id_comp] using h
  have ho : 3 ≤ (outer5.filter seen).length := cycle _ _ _ _ _
    (touched 0 4 (by decide)) (touched 4 3 (by decide)) (touched 3 8 (by decide))
    (touched 8 5 (by decide)) (touched 5 0 (by decide))
  have hi : 3 ≤ (inner5.filter seen).length := cycle _ _ _ _ _
    (touched 1 2 (by decide)) (touched 2 7 (by decide)) (touched 7 9 (by decide))
    (touched 9 6 (by decide)) (touched 6 1 (by decide))
  have nd := ten_disjoint.filter seen
  have subset : (outer5++inner5).filter seen ⊆ cs := fun _ h =>
    List.contains_iff_mem.mp (List.mem_filter.mp h).2
  have bound := nd.length_le_of_subset subset
  simp only [List.filter_append,List.length_append] at bound
  omega

end Research.Graph9822TwoHidden
