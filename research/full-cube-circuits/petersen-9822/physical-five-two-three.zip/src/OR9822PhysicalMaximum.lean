import OR9822FivePadClass
import OR9822FiveMinimum
import And9822FreeOR
import PhysicalResolution
import Sector9822
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FourSaturation
open PEqualNP.Outside.L_meta_9822.Sectors

private def row (m : Nat) (v : Fin 10) : Bool := m.testBit v.val

private theorem raw_wire (m : Nat) : wiresFrom (List.ofFn (row m)) = fullWire m := by
  funext j
  unfold wiresFrom
  rw [List.getD_eq_getElem?_getD,List.getElem?_ofFn]
  by_cases lt : j < 10 <;> simp [lt,fullWire,row]

private theorem same_target (m : Nat) : edge (row m) = accepts m := by
  simp only [edge,row,accepts,edges,List.any_cons,List.any_nil,Bool.or_false]
  ac_rfl

theorem physical_maximum (gs : List Gate) (out : Nat) (count : gs.countP Gate.isAnd ≤ 5)
    (computes : ∀ x : Fin 10 → Bool, (asCircuit gs out).eval (List.ofFn x) = edge x) :
    Nonempty MaximumFive := by
  let z := flatten gs 10 10 rawEnv out
  apply exists_maximum
  refine fixedFive z.1 z.2 ?_ ?_
  · change (flatten gs 10 10 rawEnv out).1.length ≤ 5; rw [flatten_count]; exact count
  · intro m
    have eq := (flatten_spec gs 10 10 rawEnv out rawEnv_bounded).2 (fullWire m.val)
    rw [rawEnv_read] at eq
    have phys := computes (row m.val)
    rw [physical_eval,List.length_ofFn,raw_wire,same_target] at phys
    exact eq.trans phys

end Research.Graph9822.FreeOR
