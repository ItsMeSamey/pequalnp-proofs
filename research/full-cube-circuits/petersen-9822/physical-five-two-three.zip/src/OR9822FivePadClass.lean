import OR9822FiveMinimum
import OR9822SourceOrder
import OR9822Chronological

namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution

def rawEnv (j : Nat) : Arm := if j<10 then [j] else []

theorem rawEnv_bounded : Bounded 10 rawEnv := by
  intro j t ht
  by_cases lo : j<10 <;> simp [rawEnv,lo] at ht
  omega

theorem rawEnv_read (m : Nat) : (fun j => readArm (fullWire m) (rawEnv j)) = fullWire m := by
  funext j
  by_cases lo : j<10 <;> simp [rawEnv,lo,fullWire,readArm]

def blanks (n : Nat) : List Product := List.replicate n ([],[])

theorem blank_order (n k : Nat) : OrderedAt k (blanks n) := by
  induction n generalizing k with
  | zero => trivial
  | succ n ih => exact ⟨by simp [ValidInputs],ih _⟩

private theorem preserve (ts : List Product) (k i : Nat) (hi : i<k) (w : Wire) :
    run ts k w i = w i := by
  induction ts generalizing k w with
  | nil => rfl
  | cons q qs ih =>
    rw [run,ih _ (by omega),Function.update_of_ne (Nat.ne_of_lt hi)]

private theorem cat (p s : List Product) (k : Nat) (w : Wire) :
    run (p++s) k w = run s (k+p.length) (run p k w) := by
  induction p generalizing k w with
  | nil => simp [run]
  | cons q qs ih =>
    simp only [List.cons_append,run,ih,List.length_cons]
    rw [show k + 1 + qs.length = k + (qs.length+1) by omega]

/-- Input is any universally correct chronological physical register program with at most five ANDs.
Factoring and padding both take place inside the original full-cube class. -/
def fixedFive (ps : List Product) (out : Arm) (len : ps.length ≤ 5)
    (sound : ∀ m : Fin 1024, readArm (run ps 10 (fullWire m.val)) out =
      Research.Graph9822.FourSaturation.accepts m.val) : FiveProgram := by
  let z := factored ps 10 rawEnv out
  obtain ⟨size,apart⟩ := factored_shape ps 10 rawEnv out
  have sl : z.1.length ≤ 5 := by change (factored ps 10 rawEnv out).1.length ≤ 5; rw [size]; exact len
  let n := 5-z.1.length
  have ord : Chronological 10 z.1 z.2 := factored_order ps 10 rawEnv out rawEnv_bounded
  obtain ⟨steps,bound⟩ := (chronological_iff ..).mp ord
  refine ⟨z.1++blanks n,z.2,?_,?_,?_,?_⟩
  · simp [blanks,n]; omega
  · apply (chronological_iff ..).mpr
    refine ⟨(ordered_append ..).mpr ⟨steps,blank_order ..⟩,?_⟩
    intro i hi
    have h := bound i hi
    simp; omega
  · intro p hp i hi
    rcases List.mem_append.mp hp with before | after
    · exact apart p before i hi
    · have empty : p = ([],[]) := (List.mem_replicate.mp after).2
      simp [empty] at hi
  · intro m
    rw [cat]
    have eq : readArm (run (blanks n) (10+z.1.length) (run z.1 10 (fullWire m.val))) z.2 =
        readArm (run z.1 10 (fullWire m.val)) z.2 := by
      apply Bool.eq_iff_iff.mpr
      simp only [readArm,List.any_eq_true]
      constructor <;> rintro ⟨i,hi,hot⟩ <;>
        exact ⟨i,hi,by simpa [preserve _ _ _ (bound i hi)] using hot⟩
    rw [eq]
    have h := factored_spec ps 10 rawEnv out rawEnv_bounded (fullWire m.val)
    rw [rawEnv_read] at h
    exact h.trans (sound m)

end Research.Graph9822.FreeOR
