import OR9822H1PhysicalPrice
import OR9822H1Padding
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check Research.Graph9822OneHidden Research.Graph9822.FreeOR Research.Graph9822TwoHidden
theorem h1_physical_exclusion (net : MaximumFive) (p : Product)
    (atH : (hiddenFirst net.toFiveProgram).1=[p])
    (leak : ∃ n,HNeg1 p n)
    (cert : ∀ c : List Nat,c.length=4 → c.Pairwise (·<·) → (∀ j∈c,j<10) →
       (let t := 8191 ^^^ rawPos (vertexMask c)
        sub t (rawPos (armMask p.1))=true ∧ sub t (rawPos (armMask p.2))=true ∧
        sub t (rawPos (freeRaw (rawNeg (armMask p.1) &&& rawNeg (armMask p.2))))=true) →
       rejects c (packed1 p)=true) : False := by
  classical
  obtain ⟨term,owner,_,grants,cover⟩ := physicalGrants1 net.toFiveProgram p atH leak
  obtain ⟨t,card,includes⟩ := fill_centers1 (fun k => (owner k).getD 0)
  let ns : Finset Nat := t.image Fin.val
  let c : List Nat := ns.sort
  have len : c.length=4 := by simp [c,ns,Finset.card_image_of_injective _ Fin.val_injective,card]
  have ord : c.Pairwise (·<·) := ns.sortedLT_sort.pairwise
  have memiff (v : V1) : v.val∈c ↔ v∈t := by
    simp only [c,Finset.mem_sort,ns,Finset.mem_image]
    constructor
    · rintro ⟨a,ha,eq⟩
      exact (Fin.ext eq : a=v) ▸ ha
    · exact fun h => ⟨v,h,rfl⟩
  have small (v : Nat) (h : v∈c) : v<10 := by
    have hv : v∈ns := by simpa [c] using h
    obtain ⟨w,_,rfl⟩ := Finset.mem_image.mp hv
    exact w.isLt
  have contains (k) (v : V1) (h : owner k=some v) : v.val∈c :=
    (memiff v).mpr (by simpa [h] using includes k)
  have loose := generous1 grants cover c contains
  have reject := cert c len ord small (physical_prices1 p c loose)
  have needed := indispensable1 grants cover c contains reject
  obtain ⟨f,hf,onto⟩ := full_centers1 t card owner (fun v h => needed v ((memiff v).mpr h))
  have tight (v : V1) (h : v∈t) :
      ∃ m∈termGrants (packed1 p) v.val,∀ e,(rawArms1 (term (f v h))).accepts
          (fun l e => oneRow (hasPos1 e) (HPos1 p e) l) e → m.testBit e.val=true := by
    have gr := grants (f v h)
    rw [hf] at gr
    exact term_firm1 p _ v gr
  choose cost allowed fires using tight
  let chosen (v : Nat) : Nat := if hv : v<10 then
    if ht : (⟨v,hv⟩ : V1)∈t then cost ⟨v,hv⟩ ht else 0 else 0
  apply forbids_firm1 reject chosen
  · intro v hv
    have lt := small v hv
    have ht := (memiff ⟨v,lt⟩).mp hv
    simpa [chosen,lt,ht] using allowed ⟨v,lt⟩ ht
  · intro e
    obtain ⟨k,on⟩ := cover e
    obtain ⟨v,h,eq⟩ := onto k
    subst k
    exact ⟨v.val,(memiff v).mpr h,by simpa [chosen,v.isLt,h] using fires v h e on⟩
end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.h1_physical_exclusion
