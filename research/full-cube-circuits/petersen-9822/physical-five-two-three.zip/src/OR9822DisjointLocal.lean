import And9822FreeORDefs
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution

def commonSources (a b : Arm) : Arm := a.filter b.contains
def privateSources (a b : Arm) : Arm := a.filter (fun i => !b.contains i)

theorem private_apart (a b : Arm) (v : Nat) (hv : v ∈ privateSources a b) :
    v ∉ privateSources b a := by
  simp [privateSources] at hv ⊢
  simp [hv]

theorem factor_value (w : Wire) (a b : Arm) :
    productBit w (a,b) =
      (readArm w (commonSources a b) ||
        productBit w (privateSources a b,privateSources b a)) := by
  apply Bool.eq_iff_iff.mpr
  simp only [productBit,readArm,Bool.and_eq_true,Bool.or_eq_true,
    List.any_eq_true,commonSources,privateSources,List.mem_filter,List.contains_iff_mem,
    Bool.not_eq_true',Bool.eq_false_iff,List.contains_iff_mem]
  constructor
  · rintro ⟨⟨u,ua,uw⟩,⟨v,vb,vw⟩⟩
    by_cases ub : u ∈ b
    · exact Or.inl ⟨u,⟨ua,ub⟩,uw⟩
    · by_cases va : v ∈ a
      · exact Or.inl ⟨v,⟨va,vb⟩,vw⟩
      · exact Or.inr ⟨⟨u,⟨ua,fun h => ub (List.contains_iff_mem.mp h)⟩,uw⟩,⟨v,⟨vb,fun h => va (List.contains_iff_mem.mp h)⟩,vw⟩⟩
  · rintro (⟨v,⟨va,vb⟩,vw⟩ | ⟨⟨u,⟨ua,_⟩,uw⟩,⟨v,⟨vb,_⟩,vw⟩⟩)
    · exact ⟨⟨v,va,vw⟩,⟨v,vb,vw⟩⟩
    · exact ⟨⟨u,ua,uw⟩,⟨v,vb,vw⟩⟩

end Research.Graph9822.FreeOR
