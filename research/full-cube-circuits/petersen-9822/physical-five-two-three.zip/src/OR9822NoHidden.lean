import OR9822TwoPentagons
import OR9822FiveMinimum
import RowCover
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FourSaturation Research.Graph9822TwoHidden

private def onlyRaw (p : Product) : Arms (Source (Fin 10)) := {
  left := fun s => match s with | .raw v => v.val ∈ p.1 | _ => False
  right := fun s => match s with | .raw v => v.val ∈ p.2 | _ => False }

private theorem positive_raw : ∀ e ∈ edges, ∀ v : Fin 10,
    fullWire (edgeMask e) v.val = true → v.val=e.1 ∨ v.val=e.2 := by decide +kernel

theorem no_hidden_five (terms : Fin 5 → Product)
    (bounded : ∀ t i, i ∈ (terms t).1 ∨ i ∈ (terms t).2 → i < 10)
    (cover : ∀ e ∈ edges, ∃ t, productBit (fullWire (edgeMask e)) (terms t) = true)
    (safe : ∀ t (n : Fin 16), productBit (fullWire witnesses[n.val]!) (terms t) = false) : False := by
  classical
  have centers (t : Fin 5) : ∃ c : Fin 10, ∀ u v : Fin 10,
      u.val ∈ (terms t).1 → v.val ∈ (terms t).2 → c=u ∨ c=v := by
    apply raw_center (onlyRaw (terms t)) (fun _ => False) (fun _ => False)
    intro n h
    obtain ⟨⟨u,lu,hu⟩,⟨v,rv,hv⟩⟩ := h
    cases u with
    | first | second => exact lu
    | raw u =>
      cases v with
      | first | second => exact rv
      | raw v =>
        have a : fullWire witnesses[n.val]! u.val = true := by simpa [sourceRow,negRaw,fullWire,u.isLt] using hu
        have b : fullWire witnesses[n.val]! v.val = true := by simpa [sourceRow,negRaw,fullWire,v.isLt] using hv
        have both : productBit (fullWire witnesses[n.val]!) (terms t) = true :=
          by simp only [productBit,readArm,Bool.and_eq_true,List.any_eq_true]; exact ⟨⟨u.val,lu,a⟩,⟨v.val,rv,b⟩⟩
        rw [safe t n] at both; contradiction
  choose c hc using centers
  have six := six_centers (List.ofFn c) (by
    intro e he
    obtain ⟨t,hit⟩ := cover e he
    simp only [productBit,readArm,Bool.and_eq_true,List.any_eq_true] at hit
    obtain ⟨l,r⟩ := hit
    obtain ⟨u,hu,eu⟩ := l
    obtain ⟨v,hv,ev⟩ := r
    let a : Fin 10 := ⟨u,bounded t u (Or.inl hu)⟩
    let b : Fin 10 := ⟨v,bounded t v (Or.inr hv)⟩
    refine ⟨c t,List.mem_ofFn.mpr ⟨t,rfl⟩,?_⟩
    rcases hc t a b hu hv with h | h
    · rw [h]; exact positive_raw e he a eu
    · rw [h]; exact positive_raw e he b ev)
  simp at six

end Research.Graph9822.FreeOR
