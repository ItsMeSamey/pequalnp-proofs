import OR9822SourceFactor
namespace Research.Graph9822.FreeOR

theorem factored_order (ps : List Product) (k : Nat) (env : Env) (out : Arm)
    (bd : Bounded k env) : Chronological k (factored ps k env out).1 (factored ps k env out).2 := by
  have expandLt {m : Nat} {f : Env} (hf : Bounded m f) (a : Arm) (i : Nat)
      (hi : i ∈ expand f a) : i < m := by
    obtain ⟨j,_,hj⟩ := List.mem_flatMap.mp hi
    exact hf j i hj
  induction ps generalizing k env with
  | nil => exact expandLt bd out
  | cons p ps ih =>
    let a := expand env p.1
    let b := expand env p.2
    let next := Function.update env k (k :: commonSources a b)
    have nextBd : Bounded (k+1) next := by
      intro j i hi
      by_cases eq : j=k
      · subst j
        rcases (by simpa [next,commonSources] using hi : i = k ∨ i ∈ a ∧ i ∈ b) with rfl | ha
        · omega
        · exact Nat.lt_succ_of_lt (expandLt bd _ _ ha.1)
      · exact Nat.lt_succ_of_lt (bd _ _ (by simpa [next,eq] using hi))
    exact ⟨fun i hi => expandLt bd p.1 i (List.mem_filter.mp hi).1,
      fun i hi => expandLt bd p.2 i (List.mem_filter.mp hi).1,ih (k+1) next nextBd⟩

end Research.Graph9822.FreeOR
