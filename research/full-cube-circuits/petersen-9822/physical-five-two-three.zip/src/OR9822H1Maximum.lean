import OR9822H1ClosePhysical
import OR9822H1PhysicalSeed
import And9822NormalizedWitness
import OR9822H1AllRoots
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check Research.Graph9822OneHidden Research.Graph9822.FreeOR

theorem no_one_hidden (c : MaximumFive) (p : Product)
    (one : (hiddenFirst c.toFiveProgram).1=[p]) : False := by
  obtain ⟨m,hm,on⟩ := (compact_hidden_witness c [] [] p one).1
  obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hm
  have leak : ∃ n,HNeg1 p n := by
    refine ⟨⟨i,by simpa [Research.Graph9822.FourSaturation.witnesses] using hi⟩,?_⟩
    change hidden1 p (Research.Graph9822.FourSaturation.witnesses[i]!)=true
    rw [getElem!_pos Research.Graph9822.FourSaturation.witnesses i hi,eq]
    exact on
  apply h1_physical_exclusion c p one leak
  intro roots len ord bound price
  have ap := (hidden_first_shape c.toFiveProgram).2.1 p (by simp [one])
  have ds := disjoint_arm_masks _ _ ap
  exact physical_seed_reject (all_roots len ord bound) (armMask_lt _) (armMask_lt _)
    (by simp [meets,ds]) price.1 price.2.1 price.2.2

theorem no_four_terminals (c : MaximumFive) : collectorSize c.out ≠ 4 := by
  intro eq
  obtain ⟨sz,term⟩ := hidden_first_sizes c.toFiveProgram
  have len : (hiddenFirst c.toFiveProgram).1.length=1 := by omega
  obtain ⟨p,h⟩ := List.length_eq_one_iff.mp len
  exact no_one_hidden c p h

end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.no_one_hidden
