import And9822NoHiddenPhysical
import And9822H4Closed
import OR9822H1Maximum
import OR9822PhysicalMaximum

namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
open PEqualNP.Outside.L_meta_9822.Sectors

theorem hidden_two_or_three (c : MaximumFive) :
    (hiddenFirst c.toFiveProgram).1.length = 2 ∨
    (hiddenFirst c.toFiveProgram).1.length = 3 := by
  let z := hiddenFirst c.toFiveProgram
  have size : z.1.length + z.2.length = 5 := (hidden_first_sizes c.toFiveProgram).1
  have nonempty : z.2.length ≠ 0 := by
    intro h
    have empty := List.length_eq_zero_iff.mp h
    have row := hidden_first_rows c.toFiveProgram 0
    change z.2.any _ = true at row
    simp [empty] at row
  have h0 : z.1.length ≠ 0 := fun e => no_hidden_actual c.toFiveProgram (List.length_eq_zero_iff.mp e)
  have h1 : z.1.length ≠ 1 := by
    intro e
    obtain ⟨p,h⟩ := List.length_eq_one_iff.mp e
    exact Research.Graph9822H1Check.no_one_hidden c p h
  have h4 : z.1.length ≠ 4 := by
    intro e
    obtain ⟨a,b,d,f,h⟩ := List.length_eq_four.mp e
    obtain ⟨t,k⟩ := List.length_eq_one_iff.mp (show z.2.length = 1 by omega)
    exact Research.Graph9822.H4Geo.no_four c.toFiveProgram a b d f t h k
  change z.1.length = 2 ∨ z.1.length = 3
  omega

theorem physical_five_two_three (gs : List Gate) (out : Nat) (count : gs.countP Gate.isAnd ≤ 5)
    (computes : ∀ x : Fin 10 → Bool, (asCircuit gs out).eval (List.ofFn x) = edge x) :
    ∃ c : MaximumFive, (hiddenFirst c.toFiveProgram).1.length = 2 ∨
      (hiddenFirst c.toFiveProgram).1.length = 3 := by
  obtain ⟨c⟩ := physical_maximum gs out count computes
  exact ⟨c,hidden_two_or_three c⟩
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.physical_five_two_three
