import OR9822DisjointLocal
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution

def expand (env : Env) (a : Arm) : Arm := a.flatMap env

def factored : List Product → Nat → Env → Arm → List Product × Arm
  | [],_,env,out => ([],expand env out)
  | p::ps,k,env,out =>
    let a := expand env p.1
    let b := expand env p.2
    let q := (privateSources a b,privateSources b a)
    let next := Function.update env k (k :: commonSources a b)
    let rest := factored ps (k+1) next out
    (q :: rest.1, rest.2)

theorem expand_read (w : Wire) (env : Env) (a : Arm) :
    readArm w (expand env a) = readArm (fun i => readArm w (env i)) a := by
  simp [expand,readArm,List.any_flatMap]

theorem factored_shape (ps : List Product) (k : Nat) (env : Env) (out : Arm) :
    (factored ps k env out).1.length = ps.length ∧
    ∀ p ∈ (factored ps k env out).1, ∀ i ∈ p.1, i ∉ p.2 := by
  induction ps generalizing k env with
  | nil => simp [factored]
  | cons p ps ih =>
    simp only [factored,List.length_cons,List.mem_cons]
    obtain ⟨len,rest⟩ := ih (k+1) (Function.update env k
      (k :: commonSources (expand env p.1) (expand env p.2)))
    refine ⟨by rw [len],?_⟩
    intro r hr i hi
    rcases hr with rfl | later
    · exact private_apart _ _ _ hi
    · exact rest _ later i hi

private theorem expand_bounded {k : Nat} {env : Env} (bd : Bounded k env)
    (a : Arm) : ∀ i ∈ expand env a, i < k := by
  intro i hi
  obtain ⟨j,_,hj⟩ := List.mem_flatMap.mp hi
  exact bd j i hj

theorem factored_spec (ps : List Product) (k : Nat) (env : Env) (out : Arm)
    (bd : Bounded k env) (w : Wire) :
    let res := factored ps k env out
    readArm (run res.1 k w) res.2 =
      readArm (run ps k (fun j => readArm w (env j))) out := by
  induction ps generalizing k env w with
  | nil => exact expand_read w env out
  | cons p ps ih =>
    let a := expand env p.1
    let b := expand env p.2
    let q : Product := (privateSources a b,privateSources b a)
    let next := Function.update env k (k :: commonSources a b)
    let w' := Function.update w k (productBit w q)
    have commonLt : ∀ i ∈ commonSources a b, i < k := by
      intro i hi
      exact expand_bounded bd p.1 i (List.mem_filter.mp hi).1
    have nextBd : Bounded (k+1) next := by
      intro j i hi
      by_cases e : j = k
      · subst j
        simp only [next,Function.update_self,List.mem_cons] at hi
        rcases hi with rfl | prior
        · omega
        · exact Nat.lt_succ_of_lt (commonLt i prior)
      · have h := bd j i (by simpa [next,e] using hi)
        omega
    have unchanged (c : Arm) (bound : ∀ i ∈ c, i < k) : readArm w' c = readArm w c := by
      apply Bool.eq_iff_iff.mpr
      simp only [readArm,List.any_eq_true]
      constructor <;> rintro ⟨i,hi,hot⟩ <;>
        exact ⟨i,hi,by simpa [w',Function.update_of_ne (Nat.ne_of_lt (bound i hi))] using hot⟩
    have agree : (fun j => readArm w' (next j)) =
        Function.update (fun j => readArm w (env j)) k (productBit (fun j => readArm w (env j)) p) := by
      funext j
      by_cases e : j = k
      · subst j
        simp only [next,Function.update_self]
        change (w' k || readArm w' (commonSources a b)) = _
        rw [unchanged _ commonLt,Bool.or_comm]
        have value := factor_value w a b
        simp only [productBit] at value ⊢
        simpa [w',q,a,b,expand_read,productBit] using value.symm
      · simpa [next,e] using unchanged (env j) (bd j)
    change readArm (run (factored ps (k+1) next out).1 (k+1) w') (factored ps (k+1) next out).2 = _
    rw [ih (k+1) next nextBd w',agree]
    rfl

end Research.Graph9822.FreeOR
