import OR9822Cycles

namespace Research.OddOr

variable {α : Type} [DecidableEq α] (E : α → α → Prop) [DecidableRel E] (core : Finset α)

def peelCheck : List α → List (α × α × α) → Bool
  | [], [] => true
  | i :: xs, (j,a,b) :: ws =>
    decide (i ∉ xs.toFinset ∪ core ∧ j ∈ xs.toFinset ∪ core ∧
      a ∈ xs.toFinset ∪ core ∧ b ∈ xs.toFinset ∪ core ∧ E i j ∧ E a b) &&
      peelCheck xs ws
  | _, _ => false

theorem checkedPeel {xs : List α} (ws : List (α × α × α))
    (h : peelCheck E core xs ws = true) : Peel E xs core := by
  induction xs generalizing ws with
  | nil => exact Peel.done _
  | cons i xs ih =>
    cases ws with
    | nil => simp [peelCheck] at h
    | cons w ws =>
      rcases w with ⟨j,a,b⟩
      simp only [peelCheck, Bool.and_eq_true, decide_eq_true_eq] at h
      obtain ⟨⟨fresh,hj,ha,hb,edge,live⟩,tail⟩ := h
      exact Peel.step (ih ws tail) fresh hj ha hb edge live

end Research.OddOr
