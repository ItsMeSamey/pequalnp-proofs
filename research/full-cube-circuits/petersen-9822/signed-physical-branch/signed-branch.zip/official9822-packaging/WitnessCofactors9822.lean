import PeelWitness9822

/- BEGIN OR9822Drop0.lean -/
namespace Research.OddOr
open FreeAndNet
namespace Drop0
set_option maxRecDepth 16000
abbrev V := Fin 9
def f (s : Finset V) : Bool :=
  (decide (0 ∈ s) && decide (1 ∈ s)) || (decide (2 ∈ s) && decide (3 ∈ s)) || (decide (0 ∈ s) && decide (5 ∈ s)) || (decide (1 ∈ s) && decide (6 ∈ s)) || (decide (2 ∈ s) && decide (7 ∈ s)) || (decide (3 ∈ s) && decide (8 ∈ s)) || (decide (4 ∈ s) && decide (6 ∈ s)) || (decide (6 ∈ s) && decide (8 ∈ s)) || (decide (5 ∈ s) && decide (8 ∈ s)) || (decide (5 ∈ s) && decide (7 ∈ s)) || (decide (4 ∈ s) && decide (7 ∈ s))

def data : GraphRows f where
  walk := [0,1,6,4,7,2,3,8,5]
  spans := by decide +kernel
  steps := by decide +kernel
  cold := by decide +kernel
  singleton := by decide +kernel
  neighbor := by decide +kernel
  diff := by decide +kernel
  avoiding := by decide +kernel
  edges := fun j => if j = 0 then {0,1} else if j = 1 then {2,3} else {0,5}
  hot := by decide +kernel
  meet := by decide +kernel

def emb0 : Cycle5.V ↪ V where
  toFun := fun v => ([2,3,8,5,7] : List V).get v
  inj' := by decide +kernel

theorem price0 (t : Net V) (h : ∀ s : Finset V, (0 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb0 4 Cycle5.lower 0 [1,6,4] {2,3,8,5,7} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(6,2,3),(4,2,3),(7,2,3)] (by decide +kernel)

def emb1 : Cycle5.V ↪ V where
  toFun := fun v => ([2,3,8,5,7] : List V).get v
  inj' := by decide +kernel

theorem price1 (t : Net V) (h : ∀ s : Finset V, (1 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb1 4 Cycle5.lower 1 [6,4,0] {2,3,8,5,7} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(4,2,3),(7,2,3),(5,2,3)] (by decide +kernel)

def emb2 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,6,8,5] : List V).get v
  inj' := by decide +kernel

theorem price2 (t : Net V) (h : ∀ s : Finset V, (2 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb2 4 Cycle5.lower 2 [7,4,3] {0,1,6,8,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(4,0,1),(6,0,1),(8,0,1)] (by decide +kernel)

def emb3 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,6,8,5] : List V).get v
  inj' := by decide +kernel

theorem price3 (t : Net V) (h : ∀ s : Finset V, (3 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb3 4 Cycle5.lower 3 [2,7,4] {0,1,6,8,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(7,0,1),(4,0,1),(6,0,1)] (by decide +kernel)

def emb4 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,6,8,5] : List V).get v
  inj' := by decide +kernel

theorem price4 (t : Net V) (h : ∀ s : Finset V, (4 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb4 4 Cycle5.lower 4 [7,2,3] {0,1,6,8,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(2,0,1),(3,0,1),(8,0,1)] (by decide +kernel)

def emb5 : Cycle6.V ↪ V where
  toFun := fun v => ([2,3,8,6,4,7] : List V).get v
  inj' := by decide +kernel

theorem price5 (t : Net V) (h : ∀ s : Finset V, (5 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb5 5 Cycle6.lower 5 [0,1] {2,3,8,6,4,7} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(1,2,3),(6,2,3)] (by decide +kernel)

def emb6 : Cycle5.V ↪ V where
  toFun := fun v => ([2,3,8,5,7] : List V).get v
  inj' := by decide +kernel

theorem price6 (t : Net V) (h : ∀ s : Finset V, (6 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb6 4 Cycle5.lower 6 [4,1,0] {2,3,8,5,7} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(7,2,3),(0,2,3),(5,2,3)] (by decide +kernel)

def emb7 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,6,8,5] : List V).get v
  inj' := by decide +kernel

theorem price7 (t : Net V) (h : ∀ s : Finset V, (7 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb7 4 Cycle5.lower 7 [4,2,3] {0,1,6,8,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(6,0,1),(3,0,1),(8,0,1)] (by decide +kernel)

def emb8 : Cycle6.V ↪ V where
  toFun := fun v => ([0,1,6,4,7,5] : List V).get v
  inj' := by decide +kernel

theorem price8 (t : Net V) (h : ∀ s : Finset V, (8 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb8 5 Cycle6.lower 8 [3,2] {0,1,6,4,7,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(2,0,1),(7,0,1)] (by decide +kernel)

theorem lower (t : Net V) (h : ∀ s : Finset V, sees t s = f s) : 9 ≤ t.cost := by
  refine graph_raise data 7 ?_ t h
  intro i
  fin_cases i
  · exact price0
  · exact price1
  · exact price2
  · exact price3
  · exact price4
  · exact price5
  · exact price6
  · exact price7
  · exact price8
end Drop0
end Research.OddOr
/- END OR9822Drop0.lean -/

/- BEGIN OR9822Drop3.lean -/
namespace Research.OddOr
open FreeAndNet
namespace Drop3
set_option maxRecDepth 16000
abbrev V := Fin 9
def f (s : Finset V) : Bool :=
  (decide (1 ∈ s) && decide (2 ∈ s)) || (decide (0 ∈ s) && decide (3 ∈ s)) || (decide (0 ∈ s) && decide (4 ∈ s)) || (decide (1 ∈ s) && decide (5 ∈ s)) || (decide (2 ∈ s) && decide (6 ∈ s)) || (decide (3 ∈ s) && decide (8 ∈ s)) || (decide (4 ∈ s) && decide (6 ∈ s)) || (decide (6 ∈ s) && decide (8 ∈ s)) || (decide (5 ∈ s) && decide (8 ∈ s)) || (decide (5 ∈ s) && decide (7 ∈ s)) || (decide (4 ∈ s) && decide (7 ∈ s))

def data : GraphRows f where
  walk := [0,3,8,5,1,2,6,4,7]
  spans := by decide +kernel
  steps := by decide +kernel
  cold := by decide +kernel
  singleton := by decide +kernel
  neighbor := by decide +kernel
  diff := by decide +kernel
  avoiding := by decide +kernel
  edges := fun j => if j = 0 then {1,2} else if j = 1 then {0,3} else {0,4}
  hot := by decide +kernel
  meet := by decide +kernel

def emb0 : Cycle5.V ↪ V where
  toFun := fun v => ([1,2,6,8,5] : List V).get v
  inj' := by decide +kernel

theorem price0 (t : Net V) (h : ∀ s : Finset V, (0 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb0 4 Cycle5.lower 0 [7,4,3] {1,2,6,8,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(4,1,2),(6,1,2),(8,1,2)] (by decide +kernel)

def emb1 : Cycle5.V ↪ V where
  toFun := fun v => ([0,3,8,6,4] : List V).get v
  inj' := by decide +kernel

theorem price1 (t : Net V) (h : ∀ s : Finset V, (1 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb1 4 Cycle5.lower 1 [7,5,2] {0,3,8,6,4} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(4,0,3),(8,0,3),(6,0,3)] (by decide +kernel)

def emb2 : Cycle5.V ↪ V where
  toFun := fun v => ([0,3,8,6,4] : List V).get v
  inj' := by decide +kernel

theorem price2 (t : Net V) (h : ∀ s : Finset V, (2 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb2 4 Cycle5.lower 2 [7,1,5] {0,3,8,6,4} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(4,0,3),(5,0,3),(8,0,3)] (by decide +kernel)

def emb3 : Cycle5.V ↪ V where
  toFun := fun v => ([1,2,6,8,5] : List V).get v
  inj' := by decide +kernel

theorem price3 (t : Net V) (h : ∀ s : Finset V, (3 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb3 4 Cycle5.lower 3 [7,0,4] {1,2,6,8,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(4,1,2),(4,1,2),(6,1,2)] (by decide +kernel)

def emb4 : Cycle5.V ↪ V where
  toFun := fun v => ([1,2,6,8,5] : List V).get v
  inj' := by decide +kernel

theorem price4 (t : Net V) (h : ∀ s : Finset V, (4 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb4 4 Cycle5.lower 4 [7,0,3] {1,2,6,8,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(5,1,2),(3,1,2),(8,1,2)] (by decide +kernel)

def emb5 : Cycle5.V ↪ V where
  toFun := fun v => ([0,3,8,6,4] : List V).get v
  inj' := by decide +kernel

theorem price5 (t : Net V) (h : ∀ s : Finset V, (5 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb5 4 Cycle5.lower 5 [7,1,2] {0,3,8,6,4} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(4,0,3),(2,0,3),(6,0,3)] (by decide +kernel)

def emb6 : Cycle6.V ↪ V where
  toFun := fun v => ([0,3,8,5,7,4] : List V).get v
  inj' := by decide +kernel

theorem price6 (t : Net V) (h : ∀ s : Finset V, (6 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb6 5 Cycle6.lower 6 [2,1] {0,3,8,5,7,4} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(1,0,3),(5,0,3)] (by decide +kernel)

def emb7 : Cycle5.V ↪ V where
  toFun := fun v => ([0,3,8,6,4] : List V).get v
  inj' := by decide +kernel

theorem price7 (t : Net V) (h : ∀ s : Finset V, (7 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb7 4 Cycle5.lower 7 [5,1,2] {0,3,8,6,4} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(1,0,3),(2,0,3),(6,0,3)] (by decide +kernel)

def emb8 : Cycle6.V ↪ V where
  toFun := fun v => ([1,2,6,4,7,5] : List V).get v
  inj' := by decide +kernel

theorem price8 (t : Net V) (h : ∀ s : Finset V, (8 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb8 5 Cycle6.lower 8 [3,0] {1,2,6,4,7,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(0,1,2),(4,1,2)] (by decide +kernel)

theorem lower (t : Net V) (h : ∀ s : Finset V, sees t s = f s) : 9 ≤ t.cost := by
  refine graph_raise data 7 ?_ t h
  intro i
  fin_cases i
  · exact price0
  · exact price1
  · exact price2
  · exact price3
  · exact price4
  · exact price5
  · exact price6
  · exact price7
  · exact price8
end Drop3
end Research.OddOr
/- END OR9822Drop3.lean -/

/- BEGIN OR9822Theta233.lean -/
namespace Research.OddOr
open FreeAndNet
namespace Theta233
set_option maxRecDepth 16000
abbrev V := Fin 7
def f (s : Finset V) : Bool :=
  (decide (0 ∈ s) && decide (2 ∈ s)) || (decide (2 ∈ s) && decide (1 ∈ s)) || (decide (0 ∈ s) && decide (3 ∈ s)) || (decide (3 ∈ s) && decide (4 ∈ s)) || (decide (4 ∈ s) && decide (1 ∈ s)) || (decide (0 ∈ s) && decide (5 ∈ s)) || (decide (5 ∈ s) && decide (6 ∈ s)) || (decide (6 ∈ s) && decide (1 ∈ s))

def data : GraphRows f where
  walk := [2,0,3,4,1,6,5]
  spans := by decide +kernel
  steps := by decide +kernel
  cold := by decide +kernel
  singleton := by decide +kernel
  neighbor := by decide +kernel
  diff := by decide +kernel
  avoiding := by decide +kernel
  edges := fun j => if j = 0 then {0,2} else if j = 1 then {2,1} else {0,3}
  hot := by decide +kernel
  meet := by decide +kernel

def emb2 : Cycle6.V ↪ V where
  toFun := fun v => ([0,3,4,1,6,5] : List V).get v
  inj' := by decide +kernel

theorem price2 (t : Net V) (h : ∀ s : Finset V, (2 : V) ∉ s → sees t s = f s) :
    5 ≤ t.cost := by
  refine induced_pin_price data.singleton emb2 5 Cycle6.lower 2 [] {0,3,4,1,6,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact Peel.done _

def emb3 : Cycle5.V ↪ V where
  toFun := fun v => ([0,2,1,6,5] : List V).get v
  inj' := by decide +kernel

theorem price3 (t : Net V) (h : ∀ s : Finset V, (3 : V) ∉ s → sees t s = f s) :
    5 ≤ t.cost := by
  refine induced_pin_price data.singleton emb3 4 Cycle5.lower 3 [4] {0,2,1,6,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(1,0,2)] (by decide +kernel)

def emb4 : Cycle5.V ↪ V where
  toFun := fun v => ([0,2,1,6,5] : List V).get v
  inj' := by decide +kernel

theorem price4 (t : Net V) (h : ∀ s : Finset V, (4 : V) ∉ s → sees t s = f s) :
    5 ≤ t.cost := by
  refine induced_pin_price data.singleton emb4 4 Cycle5.lower 4 [3] {0,2,1,6,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(0,0,2)] (by decide +kernel)

def emb5 : Cycle5.V ↪ V where
  toFun := fun v => ([0,2,1,4,3] : List V).get v
  inj' := by decide +kernel

theorem price5 (t : Net V) (h : ∀ s : Finset V, (5 : V) ∉ s → sees t s = f s) :
    5 ≤ t.cost := by
  refine induced_pin_price data.singleton emb5 4 Cycle5.lower 5 [6] {0,2,1,4,3} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(1,0,2)] (by decide +kernel)

def emb6 : Cycle5.V ↪ V where
  toFun := fun v => ([0,2,1,4,3] : List V).get v
  inj' := by decide +kernel

theorem price6 (t : Net V) (h : ∀ s : Finset V, (6 : V) ∉ s → sees t s = f s) :
    5 ≤ t.cost := by
  refine induced_pin_price data.singleton emb6 4 Cycle5.lower 6 [5] {0,2,1,4,3} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(0,0,2)] (by decide +kernel)

end Theta233
end Research.OddOr
/- END OR9822Theta233.lean -/

/- BEGIN OR9822Theta144.lean -/
namespace Research.OddOr
open FreeAndNet
namespace Theta144
set_option maxRecDepth 16000
abbrev V := Fin 8
def f (s : Finset V) : Bool :=
  (decide (0 ∈ s) && decide (1 ∈ s)) || (decide (0 ∈ s) && decide (2 ∈ s)) || (decide (2 ∈ s) && decide (3 ∈ s)) || (decide (3 ∈ s) && decide (4 ∈ s)) || (decide (4 ∈ s) && decide (1 ∈ s)) || (decide (0 ∈ s) && decide (5 ∈ s)) || (decide (5 ∈ s) && decide (6 ∈ s)) || (decide (6 ∈ s) && decide (7 ∈ s)) || (decide (7 ∈ s) && decide (1 ∈ s))

def data : GraphRows f where
  walk := [0,2,3,4,1,7,6,5]
  spans := by decide +kernel
  steps := by decide +kernel
  cold := by decide +kernel
  singleton := by decide +kernel
  neighbor := by decide +kernel
  diff := by decide +kernel
  avoiding := by decide +kernel
  edges := fun j => if j = 0 then {0,1} else if j = 1 then {0,2} else {2,3}
  hot := by decide +kernel
  meet := by decide +kernel

def emb2 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,7,6,5] : List V).get v
  inj' := by decide +kernel

theorem price2 (t : Net V) (h : ∀ s : Finset V, (2 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb2 4 Cycle5.lower 2 [3,4] {0,1,7,6,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(4,0,1),(1,0,1)] (by decide +kernel)

def emb3 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,7,6,5] : List V).get v
  inj' := by decide +kernel

theorem price3 (t : Net V) (h : ∀ s : Finset V, (3 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb3 4 Cycle5.lower 3 [4,2] {0,1,7,6,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(1,0,1),(0,0,1)] (by decide +kernel)

def emb4 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,7,6,5] : List V).get v
  inj' := by decide +kernel

theorem price4 (t : Net V) (h : ∀ s : Finset V, (4 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb4 4 Cycle5.lower 4 [3,2] {0,1,7,6,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(2,0,1),(0,0,1)] (by decide +kernel)

def emb5 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,4,3,2] : List V).get v
  inj' := by decide +kernel

theorem price5 (t : Net V) (h : ∀ s : Finset V, (5 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb5 4 Cycle5.lower 5 [6,7] {0,1,4,3,2} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(7,0,1),(1,0,1)] (by decide +kernel)

def emb6 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,4,3,2] : List V).get v
  inj' := by decide +kernel

theorem price6 (t : Net V) (h : ∀ s : Finset V, (6 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb6 4 Cycle5.lower 6 [7,5] {0,1,4,3,2} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(1,0,1),(0,0,1)] (by decide +kernel)

def emb7 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,4,3,2] : List V).get v
  inj' := by decide +kernel

theorem price7 (t : Net V) (h : ∀ s : Finset V, (7 : V) ∉ s → sees t s = f s) :
    6 ≤ t.cost := by
  refine induced_pin_price data.singleton emb7 4 Cycle5.lower 7 [6,5] {0,1,4,3,2} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(5,0,1),(0,0,1)] (by decide +kernel)

end Theta144
end Research.OddOr
/- END OR9822Theta144.lean -/

/- BEGIN OR9822Theta145.lean -/
namespace Research.OddOr
open FreeAndNet
namespace Theta145
set_option maxRecDepth 16000
abbrev V := Fin 9
def f (s : Finset V) : Bool :=
  (decide (0 ∈ s) && decide (1 ∈ s)) || (decide (0 ∈ s) && decide (2 ∈ s)) || (decide (2 ∈ s) && decide (3 ∈ s)) || (decide (3 ∈ s) && decide (4 ∈ s)) || (decide (4 ∈ s) && decide (1 ∈ s)) || (decide (0 ∈ s) && decide (5 ∈ s)) || (decide (5 ∈ s) && decide (6 ∈ s)) || (decide (6 ∈ s) && decide (7 ∈ s)) || (decide (7 ∈ s) && decide (8 ∈ s)) || (decide (8 ∈ s) && decide (1 ∈ s))

def data : GraphRows f where
  walk := [0,2,3,4,1,8,7,6,5]
  spans := by decide +kernel
  steps := by decide +kernel
  cold := by decide +kernel
  singleton := by decide +kernel
  neighbor := by decide +kernel
  diff := by decide +kernel
  avoiding := by decide +kernel
  edges := fun j => if j = 0 then {0,1} else if j = 1 then {0,2} else {2,3}
  hot := by decide +kernel
  meet := by decide +kernel

def emb2 : Cycle6.V ↪ V where
  toFun := fun v => ([0,1,8,7,6,5] : List V).get v
  inj' := by decide +kernel

theorem price2 (t : Net V) (h : ∀ s : Finset V, (2 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb2 5 Cycle6.lower 2 [3,4] {0,1,8,7,6,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(4,0,1),(1,0,1)] (by decide +kernel)

def emb3 : Cycle6.V ↪ V where
  toFun := fun v => ([0,1,8,7,6,5] : List V).get v
  inj' := by decide +kernel

theorem price3 (t : Net V) (h : ∀ s : Finset V, (3 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb3 5 Cycle6.lower 3 [4,2] {0,1,8,7,6,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(1,0,1),(0,0,1)] (by decide +kernel)

def emb4 : Cycle6.V ↪ V where
  toFun := fun v => ([0,1,8,7,6,5] : List V).get v
  inj' := by decide +kernel

theorem price4 (t : Net V) (h : ∀ s : Finset V, (4 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb4 5 Cycle6.lower 4 [3,2] {0,1,8,7,6,5} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(2,0,1),(0,0,1)] (by decide +kernel)

def emb5 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,4,3,2] : List V).get v
  inj' := by decide +kernel

theorem price5 (t : Net V) (h : ∀ s : Finset V, (5 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb5 4 Cycle5.lower 5 [6,7,8] {0,1,4,3,2} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(7,0,1),(8,0,1),(1,0,1)] (by decide +kernel)

def emb6 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,4,3,2] : List V).get v
  inj' := by decide +kernel

theorem price6 (t : Net V) (h : ∀ s : Finset V, (6 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb6 4 Cycle5.lower 6 [7,8,5] {0,1,4,3,2} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(8,0,1),(1,0,1),(0,0,1)] (by decide +kernel)

def emb7 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,4,3,2] : List V).get v
  inj' := by decide +kernel

theorem price7 (t : Net V) (h : ∀ s : Finset V, (7 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb7 4 Cycle5.lower 7 [8,6,5] {0,1,4,3,2} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(1,0,1),(5,0,1),(0,0,1)] (by decide +kernel)

def emb8 : Cycle5.V ↪ V where
  toFun := fun v => ([0,1,4,3,2] : List V).get v
  inj' := by decide +kernel

theorem price8 (t : Net V) (h : ∀ s : Finset V, (8 : V) ∉ s → sees t s = f s) :
    7 ≤ t.cost := by
  refine induced_pin_price data.singleton emb8 4 Cycle5.lower 8 [7,6,5] {0,1,4,3,2} ?_ (by decide +kernel) (by decide +kernel) (by decide +kernel) t h
  exact checkedPeel _ _ [(6,0,1),(5,0,1),(0,0,1)] (by decide +kernel)

end Theta145
end Research.OddOr
/- END OR9822Theta145.lean -/

