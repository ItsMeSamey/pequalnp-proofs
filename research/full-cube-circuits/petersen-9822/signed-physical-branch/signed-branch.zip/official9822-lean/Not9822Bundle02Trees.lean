import Not9822Bundle01Paths

-- Not9822DagSplice

namespace Petersen9822.DagCut

structure Gate where
  left : Nat
  right : Nat
  op : Bool → Bool → Bool

def outputTerm (g : Gate) (w : Nat → Term α) : Term α :=
  .gate g.op (w g.left) (w g.right)

/-- The bank agrees with the chronological wire numbering, retaining old wires
    for arbitrary fanout. Gate i writes location i. -/
def run (gs : List Gate) (i : Nat) (w : Nat → Term α) : Nat → Term α :=
  match gs with
  | [] => w
  | g :: rest => run rest (i+1) (Function.update w i (outputTerm g w))

theorem run_bind (gs : List Gate) (i : Nat) (w : Nat → Term α) (f : α → Term β) (j : Nat) :
    ((run gs i w) j).bind f = run gs i (fun k => (w k).bind f) j := by
  induction gs generalizing i w with
  | nil => rfl
  | cons g gs ih =>
    have bank : (fun k => ((Function.update w i (outputTerm g w)) k).bind f) =
        Function.update (fun k => (w k).bind f) i (outputTerm g (fun k => (w k).bind f)) := by
      funext k
      by_cases h : k = i
      · subst k
        simp [outputTerm, Term.bind]
      · simp [Function.update_of_ne h]
    simpa only [run, bank] using ih (i+1) (Function.update w i (outputTerm g w))

def markRaw (v : Nat) : Term (Option Nat) := .var (some v)
def marked (w : Nat → Term Nat) (i : Nat) : Nat → Term (Option Nat) :=
  Function.update (fun k => (w k).bind markRaw) i (.var none)

theorem Term.bind_markRaw (e : Term Nat) (inp : Term Nat) :
    (e.bind markRaw).bind (plug inp) = e := by
  induction e <;> simp [Term.bind, markRaw, plug, *]

theorem reopen (gs : List Gate) (i : Nat) (w : Nat → Term Nat) (g : Gate) (j : Nat) :
    ((run gs (i+1) (marked w i)) j).bind (plug (outputTerm g w)) =
      run (g :: gs) i w j := by
  have bank : (fun k => (marked w i k).bind (plug (outputTerm g w))) =
      Function.update w i (outputTerm g w) := by
    funext k
    by_cases h : k = i
    · subst k
      simp [marked, Term.bind, plug]
    · simp [marked, Function.update_of_ne h, Term.bind_markRaw]
  rw [run_bind, bank]
  rfl

def oneBitOfDag (gs : List Gate) (i : Nat) (w : Nat → Term Nat) (g : Gate) (j p S U : Nat)
    (noFuture : ∀ v, (outputTerm g w).uses v → U.testBit v = false)
    (noBypass : ∀ v, (run gs (i+1) (marked w i) j).uses (some v) → S.testBit v = false)
    (computes : ∀ s u, sub s S = true → sub u U = true →
      val p s u = (run (g :: gs) i w j).eval (p ||| s ||| u).testBit) :
    OneBitAt p S U :=
  oneBitOfCut p S U (outputTerm g w) (run gs (i+1) (marked w i) j) noFuture noBypass
    (by simpa only [reopen] using computes)

end Petersen9822.DagCut

-- Not9822TreePaths
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

inductive Tree where
  | raw (wire : Nat)
  | gate (wire : Nat) (op : Bool → Bool → Bool) (l r : Tree)

def Tree.id : Tree → Nat
  | .raw n | .gate n _ _ _ => n

def Tree.term : Tree → Term Nat
  | .raw n => .var n
  | .gate _ op l r => .gate op l.term r.term

def Tree.openWire (e : Tree) (cut : Nat) : Term (Option Nat) :=
  if e.id = cut then .var none else
  match e with
  | .raw n => .var (some n)
  | .gate _ op l r => .gate op (l.openWire cut) (r.openWire cut)

/-- Every tree edge comes from the same underlying indexed DAG. -/
def Tree.valid (edge : Nat → Nat → Prop) : Tree → Prop
  | .raw _ => True
  | .gate i _ l r => edge l.id i ∧ edge r.id i ∧ l.valid edge ∧ r.valid edge

theorem Tree.rawPath {e : Tree} {edge : Nat → Nat → Prop} {sink v : Nat} {tail : List Nat}
    (valid : e.valid edge) (toSink : Path edge sink e.id tail)
    (belowSink : ∀ a b, edge a b → a ≠ sink) (h : e.term.uses v) :
    ∃ path, Path edge sink v path ∧ e.id ∈ v :: path := by
  have extend : ∀ (t : Tree) (ht : t.valid edge) (v : Nat) (h : t.term.uses v)
      (xs : List Nat) (hp : Path edge sink t.id xs),
      ∃ ys, Path edge sink v ys ∧ ∀ z ∈ t.id :: xs, z ∈ v :: ys := by
    intro t
    induction t with
    | raw n =>
      intro _ v hv xs hp
      change n = v at hv
      subst n
      exact ⟨xs,hp,fun _ h => h⟩
    | gate k op a b ia ib =>
      rintro ⟨ea,eb,va,vb⟩ v hv xs hp
      rcases hv with h | h
      · obtain ⟨ys,hy,inc⟩ := ia va v h (k :: xs) (.step (belowSink _ _ ea) ea hp)
        exact ⟨ys,hy,fun z hz => inc z (List.mem_cons_of_mem _ hz)⟩
      · obtain ⟨ys,hy,inc⟩ := ib vb v h (k :: xs) (.step (belowSink _ _ eb) eb hp)
        exact ⟨ys,hy,fun z hz => inc z (List.mem_cons_of_mem _ hz)⟩
  obtain ⟨ys,hy,inc⟩ := extend e valid v h tail toSink
  exact ⟨ys,hy,inc e.id List.mem_cons_self⟩

theorem Tree.bypassPath {e : Tree} {edge : Nat → Nat → Prop} {sink cut v : Nat}
    {tail : List Nat} (valid : e.valid edge) (toSink : Path edge sink e.id tail)
    (belowSink : ∀ a b, edge a b → a ≠ sink) (outside : cut ∉ tail)
    (h : (e.openWire cut).uses (some v)) :
    ∃ path, Path edge sink v path ∧ cut ∉ v :: path := by
  induction e generalizing tail with
  | raw n =>
    by_cases hn : n = cut
    · simp [Tree.openWire,Tree.id,hn,Term.uses] at h
    · have eq : n = v := by simpa [Tree.openWire,Tree.id,hn,Term.uses] using h
      subst v
      exact ⟨tail,toSink,by simp [Ne.symm hn,outside]⟩
  | gate i op l r il ir =>
    by_cases hi : i = cut
    · simp [Tree.openWire,Tree.id,hi,Term.uses] at h
    · have hm : (l.openWire cut).uses (some v) ∨ (r.openWire cut).uses (some v) := by
        simpa [Tree.openWire,Tree.id,hi,Term.uses] using h
      obtain ⟨el,er,vl,vr⟩ := valid
      have away : cut ∉ i :: tail := by simp [Ne.symm hi,outside]
      rcases hm with hl | hr
      · exact il vl (.step (belowSink _ _ el) el toSink) away hl
      · exact ir vr (.step (belowSink _ _ er) er toSink) away hr

end Petersen9822.DagCut

-- Not9822OwnerCut
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

def Tree.atSite (cut : Nat) (value : Term Nat) : Tree → Prop
  | .raw n => n = cut → Term.var n = value
  | .gate id op a b =>
      (id = cut → Term.gate op a.term b.term = value) ∧ a.atSite cut value ∧ b.atSite cut value

theorem Tree.replaceSite (e : Tree) (cut : Nat) (input : Term Nat)
    (h : e.atSite cut input) : (e.openWire cut).bind (plug input) = e.term := by
  induction e with
  | raw n =>
    by_cases hn : n = cut
    · simpa [Tree.openWire,Tree.id,hn,Term.bind,plug,Tree.term] using (h hn).symm
    · simp [Tree.openWire,Tree.id,hn,Term.bind,plug,Tree.term]
  | gate i op a b ia ib =>
    obtain ⟨hi,ha,hb⟩ := h
    by_cases hc : i = cut
    · simpa [Tree.openWire,Tree.id,hc,Term.bind,plug,Tree.term] using (hi hc).symm
    · simp [Tree.openWire,Tree.id,hc,Term.bind,Tree.term,ia ha,ib hb]

/-- The two semantic row-cut obligations follow from the first shared site of
    each live raw in the current and future bins. -/
def oneBitOfOwners (edge : Nat → Nat → Prop) (shared : Nat → Bool)
    (output input : Tree) (p S U : Nat)
    (validOut : output.valid edge) (validInput : input.valid edge)
    (chronological : ∀ a b, edge a b → a < b)
    (sink : ∀ a b, edge a b → a ≠ output.id)
    (oneSuccessor : ∀ a, shared a = false → ∀ b c, edge a b → edge a c → b = c)
    (isShared : shared input.id = true)
    (liveSite : ∃ xs, Path edge output.id input.id xs)
    (sameWire : output.atSite input.id input.term)
    (bin : ∀ v, S.testBit v = true → ∀ live : ∃ xs, Path edge output.id v xs,
      owner edge output.id shared v live = input.id)
    (future : ∀ v, U.testBit v = true → ∀ live : ∃ xs, Path edge output.id v xs,
      input.id < owner edge output.id shared v live)
    (computes : ∀ s u, sub s S = true → sub u U = true →
      val p s u = output.term.eval (p ||| s ||| u).testBit) : OneBitAt p S U := by
  refine oneBitOfCut p S U input.term (output.openWire input.id) ?_ ?_ ?_
  · intro v hv
    cases h : U.testBit v with
    | false => rfl
    | true =>
      obtain ⟨xs,hp,hit⟩ := Tree.rawPath validInput liveSite.choose_spec sink hv
      have later := future v h ⟨xs,hp⟩
      rw [owner_eq oneSuccessor _ hp] at later
      exact False.elim ((Nat.not_lt_of_ge (first_le_shared chronological hp hit isShared)) later)
  · intro v hv
    cases h : S.testBit v with
    | false => rfl
    | true =>
      obtain ⟨xs,hp,avoid⟩ := Tree.bypassPath validOut Path.stop sink (by simp) hv
      have here := bin v h ⟨xs,hp⟩
      rw [owner_eq oneSuccessor _ hp] at here
      exact False.elim (avoid (here ▸ first_on_path hp))
  · intro s u hs hu
    rw [Tree.replaceSite _ _ _ sameWire]
    exact computes s u hs hu

end Petersen9822.DagCut
