import Not9822ProjectedPair1
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
set_option maxRecDepth 10000 in
theorem fixedInput4 (r : Row) : observe (inputs.getD 4 zero) r = r.val.testBit 4 := by
  change ((0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000 : Nat).testBit r.val = r.val.testBit 4)
  exact (by decide +kernel : ∀ t : Fin 1024, (0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000 : Nat).testBit t.val = t.val.testBit 4) r

set_option maxRecDepth 10000 in
theorem fixedInput5 (r : Row) : observe (inputs.getD 5 zero) r = r.val.testBit 5 := by
  change ((0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000 : Nat).testBit r.val = r.val.testBit 5)
  exact (by decide +kernel : ∀ t : Fin 1024, (0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000 : Nat).testBit t.val = t.val.testBit 5) r


end Petersen9822.Potential
