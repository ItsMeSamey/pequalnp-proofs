import SignedPhysicalGuards9822

-- Not9822Potential
namespace Petersen9822.Potential

inductive Kind where
  | raw
  | gate
  | fixed
  deriving DecidableEq

def charge : Kind → Nat → Nat
  | .raw, d => d
  | .gate, d => d-1
  | .fixed, _ => 0

theorem charge_mono (kind : Kind) {a b : Nat} (le : a ≤ b) : charge kind a ≤ charge kind b := by
  cases kind <;> simp [charge] <;> omega

theorem charge_grow (kind : Kind) {a b r : Nat} (le : b ≤ a+r) :
    charge kind b ≤ charge kind a + r := by
  cases kind <;> simp [charge] <;> omega

def total {n : Nat} (k : Fin n → Kind) (uses : Fin n → Nat) : Nat :=
  ∑ v, charge (k v) (uses v)

/-- After an alias deletion its predecessor has lost at least one old socket
    and gains at most the former fanout of the alias. -/
theorem alias_potential {n : Nat} (k : Fin n → Kind) (before after : Fin n → Nat)
    (g p : Fin n) (distinct : g ≠ p) (internal : k g = .gate) (gone : after g = 0)
    (redirect : after p ≤ before p + (before g - 1))
    (others : ∀ v, v ≠ g → v ≠ p → after v ≤ before v) :
    total k after ≤ total k before := by
  classical
  let rest := (Finset.univ.erase g).erase p
  have member : p ∈ Finset.univ.erase g := by simp [Ne.symm distinct]
  have split (u : Fin n → Nat) : total k u =
      (∑ v ∈ rest, charge (k v) (u v)) + charge (k p) (u p) + charge (k g) (u g) := by
    unfold total
    rw [←Finset.sum_erase_add _ _ (Finset.mem_univ g)]
    rw [←Finset.sum_erase_add _ _ member]
  have rem : (∑ v ∈ rest, charge (k v) (after v)) ≤ ∑ v ∈ rest, charge (k v) (before v) := by
    apply Finset.sum_le_sum
    intro v hv
    have h := Finset.mem_erase.mp hv
    exact charge_mono _ (others v (Finset.mem_erase.mp h.2).1 h.1)
  have pred := charge_grow (k p) redirect
  rw [split,split,internal,gone]
  rw [show charge .gate 0 = 0 from rfl,show charge .gate (before g) = before g - 1 from rfl]
  omega

theorem fixed_potential {n : Nat} (k : Fin n → Kind) (g : Fin n)
    (before after : Fin n → Nat) (others : ∀ v, v ≠ g → after v ≤ before v) :
    total (Function.update k g .fixed) after ≤ total k before := by
  apply Finset.sum_le_sum
  intro v _
  by_cases h : v = g
  · subst v; simp [charge]
  · rw [Function.update_of_ne h]
    exact charge_mono _ (others _ h)

/-- Count the distinguished output as a use, so every live gate contributes
    exactly one socket fewer than its fanout. -/
theorem live_count {n b : Nat} (k : Fin n → Kind) (uses : Fin n → Nat)
    (gates : ∑ v, (if k v = .gate then 1 else 0) = b)
    (noFixed : ∀ v, k v = .fixed → uses v = 0)
    (live : ∀ v, k v = .gate → 0 < uses v)
    (sockets : (∑ v, uses v) = 2*b + 1) : total k uses = b+1 := by
  have each (v : Fin n) : uses v = charge (k v) (uses v) + (if k v = .gate then 1 else 0) := by
    cases h : k v with
    | raw => simp [charge]
    | gate => have pos := live v h; simp [charge]; omega
    | fixed => simp [charge,noFixed v h]
  have sum := Finset.sum_congr (s₁ := (Finset.univ : Finset (Fin n))) rfl
    (fun v _ => each v)
  rw [Finset.sum_add_distrib,gates,sockets] at sum
  change _ = total k uses + b at sum
  omega

end Petersen9822.Potential

-- Not9822SemanticDebit
namespace Petersen9822.Potential

/-- A live nonconstant output with two nonconstant parents costs one signed
    gate. A single nonconstant parent yields a signed alias. Dead nonconstant
    gates may be counted and require no special pruning. -/
theorem semantic_debit {n : Nat} (kind : Fin n → Kind) (active : Fin n → Bool)
    (full kept : Fin n → Nat) (paid : Nat)
    (subset : ∀ v, kept v ≤ full v)
    (onlyActive : ∀ v, active v = false → kept v = 0)
    (fixedCold : ∀ v, kind v = .fixed → kept v = 0)
    (balance : (∑ v, kept v) = (∑ v, if active v = true ∧ kind v = .gate then 1 else 0) + paid + 1) :
    paid + 1 ≤ total kind full := by
  classical
  have loc (v : Fin n) : kept v ≤ charge (kind v) (full v) +
      (if active v = true ∧ kind v = .gate then 1 else 0) := by
    have held := subset v
    cases hk : kind v with
    | raw => simp [charge]; omega
    | fixed => simp [charge,fixedCold v hk]
    | gate =>
      cases ha : active v with
      | true => simp [charge]; omega
      | false => simp [charge,onlyActive v ha]
  have h := Finset.sum_le_sum (s := (Finset.univ : Finset (Fin n))) (fun v _ => loc v)
  rw [Finset.sum_add_distrib,balance] at h
  change _ ≤ total kind full + _ at h
  omega

structure Pins (n : Nat) where
  id : Fin n
  left : Fin n
  right : Fin n

def retained {n : Nat} (active : Fin n → Bool) (g : Pins n) : List (Fin n) :=
  if active g.id then [g.left,g.right].filter active else []

def paidAt {n : Nat} (active : Fin n → Bool) (g : Pins n) :=
  active g.id && active g.left && active g.right

theorem socket_balance {n : Nat} (gs : List (Pins n)) (active : Fin n → Bool)
    (parent : ∀ g ∈ gs, active g.id = true → active g.left = true ∨ active g.right = true)
    (out : Fin n) :
    ((gs.flatMap (retained active)) ++ [out]).length =
      gs.countP (fun g => active g.id) + gs.countP (paidAt active) + 1 := by
  induction gs with
  | nil => simp
  | cons g gs ih =>
    have localH := parent g List.mem_cons_self
    have rest := ih (fun x hx => parent x (List.mem_cons_of_mem _ hx))
    simp only [List.length_append,List.length_cons,List.length_nil] at rest ⊢
    simp only [List.flatMap_cons,List.length_append,List.countP_cons]
    cases hi : active g.id <;> cases hl : active g.left <;> cases hr : active g.right <;>
      simp_all [retained,paidAt] <;> omega

end Petersen9822.Potential

-- Not9822PentagonSurplus
namespace Petersen9822.Potential

def onFace {n : Nat} (k : Fin n → Kind) (A : Fin n → Bool) (v : Fin n) :=
  if k v = .raw ∧ A v = false then Kind.fixed else k v

def retainedCharge {n : Nat} (k : Fin n → Kind) (A pick : Fin n → Bool)
    (uses : Fin n → Nat) (v : Fin n) :=
  if pick v then 0 else charge (onFace k A v) (uses v)

def lostCharge {n : Nat} (k : Fin n → Kind) (A pick : Fin n → Bool)
    (uses : Fin n → Nat) (v : Fin n) :=
  if pick v = true ∨ (k v = .raw ∧ A v = false) then charge (k v) (uses v) else 0

theorem splitFace {n : Nat} (k : Fin n → Kind) (A pick : Fin n → Bool) (uses : Fin n → Nat) :
    total k uses = (∑ v, retainedCharge k A pick uses v) + ∑ v, lostCharge k A pick uses v := by
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro v _
  cases h : k v <;> cases ha : A v <;> cases hp : pick v <;> simp [retainedCharge,lostCharge,onFace,h,ha,hp,charge]

theorem lostAtMostEight {n : Nat} (k : Fin n → Kind) (A pick : Fin n → Bool) (uses : Fin n → Nat)
    (cap : total k uses ≤ 16) (floor : 8 ≤ ∑ v, retainedCharge k A pick uses v) :
    (∑ v, lostCharge k A pick uses v) ≤ 8 := by
  rw [splitFace k A pick uses] at cap
  omega

private theorem card_le_loss {n : Nat} (lost : Fin n → Nat) (S : Finset (Fin n))
    (positive : ∀ x ∈ S, 1 ≤ lost x) : S.card ≤ ∑ v, lost v := by
  calc
    S.card = ∑ _ ∈ S, 1 := by simp
    _ ≤ ∑ v ∈ S, lost v := Finset.sum_le_sum positive
    _ ≤ ∑ v, lost v := Finset.sum_le_univ_sum_of_nonneg (fun x => Nat.zero_le _)

theorem controlled_at_most_three {n : Nat} (k : Fin n → Kind) (A pick : Fin n → Bool) (uses : Fin n → Nat)
    (cap : total k uses ≤ 16) (floor : 8 ≤ ∑ v, retainedCharge k A pick uses v)
    (off monitored : Finset (Fin n)) (five : off.card = 5)
    (raw : ∀ v ∈ off, k v = .raw ∧ A v = false ∧ 1 ≤ uses v)
    (control : ∀ v ∈ monitored, k v = .gate ∧ pick v = true ∧ 2 ≤ uses v) :
    monitored.card ≤ 3 := by
  classical
  have dis : Disjoint off monitored := by
    apply Finset.disjoint_left.mpr
    intro v hv hc
    have a := (raw v hv).1
    have b := (control v hc).1
    simp_all
  have pos (v : Fin n) (hv : v ∈ off ∪ monitored) : 1 ≤ lostCharge k A pick uses v := by
    rcases Finset.mem_union.mp hv with hr | hg
    · obtain ⟨r,a,u⟩ := raw _ hr
      simpa [lostCharge,r,a,charge] using u
    · obtain ⟨g,p,u⟩ := control _ hg
      simp [lostCharge,g,p,charge]; omega
  have size := card_le_loss _ _ pos
  rw [Finset.card_union_of_disjoint dis,five] at size
  have upper := lostAtMostEight k A pick uses cap floor
  omega

theorem saturated_losses {n : Nat} (lost : Fin n → Nat) (S : Finset (Fin n))
    (cap : (∑ v, lost v) ≤ 8) (card : S.card = 8) (one : ∀ v ∈ S, 1 ≤ lost v) :
    ∀ v ∈ S, lost v = 1 := by
  classical
  intro v hv
  let rest := S.erase v
  have restBound : rest.card ≤ ∑ i ∈ rest, lost i := by
    calc
      rest.card = ∑ _ ∈ rest, 1 := by simp
      _ ≤ _ := Finset.sum_le_sum (fun i hi => one i (Finset.mem_erase.mp hi).2)
  have remCard := Finset.card_erase_add_one hv
  have split := Finset.sum_erase_add S lost hv
  have ub : (∑ i ∈ S, lost i) ≤ ∑ i, lost i :=
    Finset.sum_le_univ_sum_of_nonneg (fun i => Nat.zero_le _)
  have lo := one v hv
  change (S.erase v).card ≤ ∑ i ∈ S.erase v, lost i at restBound
  omega

end Petersen9822.Potential
