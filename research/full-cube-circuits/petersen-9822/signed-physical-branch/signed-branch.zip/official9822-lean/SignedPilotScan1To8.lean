import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_0_49 : nodeCheck frozen 0 49 [49] = true := by decide +kernel
theorem scan_0_56 : nodeCheck frozen 0 56 [56, 57] = true := by decide +kernel
theorem scan_0_57 : nodeCheck frozen 0 57 [57] = true := by decide +kernel
theorem scan_0_112 : nodeCheck frozen 0 112 [112, 113] = true := by decide +kernel
theorem scan_0_113 : nodeCheck frozen 0 113 [113] = true := by decide +kernel
theorem scan_0_176 : nodeCheck frozen 0 176 [176, 177] = true := by decide +kernel
theorem scan_0_177 : nodeCheck frozen 0 177 [177] = true := by decide +kernel
theorem scan_0_272 : nodeCheck frozen 0 272 [272, 280] = true := by decide +kernel
end Petersen9822
