import Not9822ProjectedPair2
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
set_option maxRecDepth 10000 in
theorem fixedInput6 (r : Row) : observe (inputs.getD 6 zero) r = r.val.testBit 6 := by
  change ((0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000 : Nat).testBit r.val = r.val.testBit 6)
  exact (by decide +kernel : ∀ t : Fin 1024, (0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000 : Nat).testBit t.val = t.val.testBit 6) r

set_option maxRecDepth 10000 in
theorem fixedInput7 (r : Row) : observe (inputs.getD 7 zero) r = r.val.testBit 7 := by
  change ((0xffffffffffffffffffffffffffffffff00000000000000000000000000000000ffffffffffffffffffffffffffffffff00000000000000000000000000000000ffffffffffffffffffffffffffffffff00000000000000000000000000000000ffffffffffffffffffffffffffffffff00000000000000000000000000000000 : Nat).testBit r.val = r.val.testBit 7)
  exact (by decide +kernel : ∀ t : Fin 1024, (0xffffffffffffffffffffffffffffffff00000000000000000000000000000000ffffffffffffffffffffffffffffffff00000000000000000000000000000000ffffffffffffffffffffffffffffffff00000000000000000000000000000000ffffffffffffffffffffffffffffffff00000000000000000000000000000000 : Nat).testBit t.val = t.val.testBit 7) r


end Petersen9822.Potential
