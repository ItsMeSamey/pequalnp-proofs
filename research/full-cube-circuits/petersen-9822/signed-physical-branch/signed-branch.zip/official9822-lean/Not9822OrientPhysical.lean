import Not9822ReflectRoles
import Not9822Bundle07Lca
namespace Petersen9822.DagCut

/-- Apply the same directed exclusion after transporting every physical socket
and both private guards when raw 1 is the late owner. -/
theorem orientPhysical
    (directed : ∀ {d out} (c : FifteenCore d out) (a : RealGuard d out 1) (b : RealGuard d out 2),
      a.site ≠ b.site → fork d 0 = false → fork d 3 = false →
      assigned d out (fork d) 1 ≠ out → assigned d out (fork d) 2 = out → False)
    {d out} (c : FifteenCore d out) (a : RealGuard d out 1) (b : RealGuard d out 2)
    (ab : a.site ≠ b.site) (zero : fork d 0 = false) (three : fork d 3 = false)
    (distinct : assigned d out (fork d) 1 ≠ assigned d out (fork d) 2)
    (late : assigned d out (fork d) 1 = out ∨ assigned d out (fork d) 2 = out) : False := by
  rcases late with l | r
  · have live1 := d.live_raw out ⟨1,by decide⟩ c.finalWire c.computes
    have live2 := d.live_raw out ⟨2,by decide⟩ c.finalWire c.computes
    apply directed (reflectCore c) (reflectGuard c b (by decide)) (reflectGuard c a (by decide)) ab.symm
    · exact (mirror_fork d c.diagram 3).trans three
    · exact (mirror_fork d c.diagram 0).trans zero
    · intro h
      exact distinct (l.trans ((reflectLate c live2).mp h).symm)
    · exact (reflectLate c live1).mpr l
  · exact directed c a b ab zero three (fun h => distinct (h.trans r.symm)) r

end Petersen9822.DagCut
