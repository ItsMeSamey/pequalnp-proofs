import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_2_57 : nodeCheck frozen 2 57 [59] = true := by decide +kernel
theorem scan_2_112 : nodeCheck frozen 2 112 [114] = true := by decide +kernel
theorem scan_2_113 : nodeCheck frozen 2 113 [115] = true := by decide +kernel
theorem scan_2_176 : nodeCheck frozen 2 176 [178] = true := by decide +kernel
theorem scan_2_177 : nodeCheck frozen 2 177 [179] = true := by decide +kernel
theorem scan_2_272 : nodeCheck frozen 2 272 [274] = true := by decide +kernel
theorem scan_2_273 : nodeCheck frozen 2 273 [275] = true := by decide +kernel
theorem scan_2_280 : nodeCheck frozen 2 280 [282] = true := by decide +kernel
theorem scan_2_281 : nodeCheck frozen 2 281 [283] = true := by decide +kernel
theorem scan_2_288 : nodeCheck frozen 2 288 [290] = true := by decide +kernel
theorem scan_2_289 : nodeCheck frozen 2 289 [291] = true := by decide +kernel
theorem scan_2_296 : nodeCheck frozen 2 296 [298] = true := by decide +kernel
end Petersen9822
