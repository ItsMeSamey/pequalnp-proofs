import Not9822PinCharts
import Not9822SaveThree
namespace Petersen9822.DagCut
open Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Petersen9822.FirstSite

theorem pinNotConstant {d out i b} (c : FifteenCore d out) (chart : PinChart i b) :
    ¬ Constant (onMoved d chart.moves out) := by
  intro h
  have eq := moved_output c (map_correct (u:=true) chart.mapOK).1
  rw [eq] at h
  have impossible := chart.floor 0 _ Reach.start (Or.inr (Or.inl h))
  omega

theorem readerBounds {d out i n} (c : FifteenCore d out) (e : d.edge i n) : 10 ≤ n ∧ n < 25 := by
  obtain ⟨g,h,_⟩ := e
  exact c.diagram.extent n g h

theorem downstreamOf {d out n} (c : FifteenCore d out) (lo : 10 ≤ n) (hi : n < 25) (ne : n ≠ out) :
    ∃ j, d.edge n j := by
  obtain ⟨xs,p⟩ := c.live n lo hi
  cases p with
  | stop => exact False.elim (ne rfl)
  | step _ e _ => exact ⟨_,e⟩

theorem gateControl (f : SignedOp) :
    (∃ b, f.bit b false = f.bit b true) ∧ (∃ b, f.bit false b = f.bit true b) := by
  cases f with
  | mk k l r z => cases k <;> cases l <;> cases r <;> cases z <;> decide

theorem pinControlsReader {d out i n} (c : FifteenCore d out) (charts : ∀ b, PinChart i b)
    (low : i < 10) (read : d.edge i n) :
    ∃ b, Constant (onMoved d (charts b).moves n) := by
  obtain ⟨g,eq,side⟩ := read
  rcases side with l | r
  · obtain ⟨b,block⟩ := (gateControl (c.op n)).1
    refine ⟨b,(c.op n).bit b false,?_⟩
    rw [moved_gate c _ eq,l,(charts b).pinRaw c low]
    funext row
    rw [op_eval]
    cases onMoved d (charts b).moves g.right row <;> first | rfl | exact block.symm
  · obtain ⟨b,block⟩ := (gateControl (c.op n)).2
    refine ⟨b,(c.op n).bit false b,?_⟩
    rw [moved_gate c _ eq,r,(charts b).pinRaw c low]
    funext row
    rw [op_eval]
    cases onMoved d (charts b).moves g.left row <;> first | rfl | exact block.symm

theorem rawHasReader {d out i} (c : FifteenCore d out) (low : i < 10) : ∃ n, d.edge i n := by
  obtain ⟨xs,h⟩ := d.live_raw out ⟨i,low⟩ c.finalWire c.computes
  have general {v xs} (p : Path d.edge out v xs) (ne : v ≠ out) : ∃ j, d.edge v j := by
    cases p with
    | stop => exact False.elim (ne rfl)
    | step _ e _ => exact ⟨_,e⟩
  exact general h (by change i ≠ out; have := c.lowerOut; omega)

theorem noTwoOrderedReaders {d out i a n} (c : FifteenCore d out) (charts : ∀ b, PinChart i b)
    (low : i < 10) (early : d.edge i a) (late : d.edge i n) (order : a < n) : False := by
  obtain ⟨b,constant⟩ := pinControlsReader c charts low late
  let chart := charts b
  have pin : Constant (onMoved d chart.moves i) := ⟨b,chart.pinRaw c low⟩
  have alive : n ≠ out := by intro eq; subst n; exact pinNotConstant c chart constant
  have ba := readerBounds c early
  have bn := readerBounds c late
  obtain ⟨j,after⟩ := downstreamOf c bn.1 bn.2 alive
  have bj := readerBounds c after
  have strict := d.chrono after
  obtain ⟨k,bank,budget,run,ready⟩ := saveThree (onMoved d chart.moves) (chart.base.map observe) a n j
    ba.1 bn.1 ba.2 bn.2 bj.1 bj.2 (by omega) (by omega) (by omega) (moved_inputs c chart.mapOK)
    (by
      intro v hit
      rcases hit with rfl | rfl | rfl
      · exact unaryOfConstantOperand c _ pin early
      · exact unaryOfConstantOperand c _ pin late
      · exact unaryOfConstantOperand c _ constant after)
    (by
      intro v lo hi _ _ _
      obtain ⟨g,h⟩ := c.diagram.present v lo hi
      have less := d.back v g h
      exact ⟨g.left,less.1,g.right,less.2,c.op v,moved_gate c _ h⟩)
  have hit := ready out c.upperOut
  rw [moved_output c (map_correct (u:=true) chart.mapOK).1] at hit
  have lower := chart.floor k bank run hit
  omega

theorem protectedSole {d out i} (c : FifteenCore d out) (charts : ∀ b, PinChart i b) (low : i < 10) :
    fork d i = false := by
  classical
  cases hot : fork d i with
  | false => rfl
  | true =>
    obtain ⟨a,n,early,late,ne⟩ := of_decide_eq_true hot
    rcases lt_or_gt_of_ne ne with l | r
    · exact False.elim (noTwoOrderedReaders c charts low early late l)
    · exact False.elim (noTwoOrderedReaders c charts low late early r)

end Petersen9822.DagCut
