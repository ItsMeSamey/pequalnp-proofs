import Not9822ProjectedRows1
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor
private theorem block16 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((512+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (512+k.val) := by decide +kernel
private theorem block17 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((544+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (544+k.val) := by decide +kernel
private theorem block18 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((576+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (576+k.val) := by decide +kernel
private theorem block19 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((608+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (608+k.val) := by decide +kernel
private theorem block20 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((640+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (640+k.val) := by decide +kernel
private theorem block21 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((672+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (672+k.val) := by decide +kernel
private theorem block22 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((704+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (704+k.val) := by decide +kernel
private theorem block23 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((736+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (736+k.val) := by decide +kernel
theorem region2 (h : Nat) (lo : 16 ≤ h) (hi : h < 24) (j : Bool) (k : Fin 32) :
    edgeHit (((32*h+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (32*h+k.val) := by
  have casesH : h = 16 ∨ h = 17 ∨ h = 18 ∨ h = 19 ∨ h = 20 ∨ h = 21 ∨ h = 22 ∨ h = 23 := by omega
  rcases casesH with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact block16 j k
  · exact block17 j k
  · exact block18 j k
  · exact block19 j k
  · exact block20 j k
  · exact block21 j k
  · exact block22 j k
  · exact block23 j k

end Petersen9822.Potential
