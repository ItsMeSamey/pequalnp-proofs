import Not9822PinControl
import Not9822GuardBypass
import Not9822ExtractGuard
namespace Petersen9822.DagCut
open Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine

theorem companionFork {d out i p} (c : FifteenCore d out) (charts : ∀ b, PinChart i b)
    (low : i < 10) (internal : 10 ≤ p) (reader : ReaderAt d i p) : fork d p = true := by
  classical
  cases hot : fork d p with
  | true => rfl
  | false =>
    let n := reader.id
    have iRead : d.edge i n := ⟨reader.g,reader.read,reader.inputs.elim (fun h => Or.inl h.1) (fun h => Or.inr h.1)⟩
    have pRead : d.edge p n := ⟨reader.g,reader.read,reader.inputs.elim (fun h => Or.inr h.2) (fun h => Or.inl h.2)⟩
    have pn := d.chrono pRead
    have nr := readerBounds c iRead
    obtain ⟨b,constant⟩ := pinControlsReader c charts low iRead
    let chart := charts b
    have notOut : n ≠ out := by intro eq; rw [eq] at constant; exact pinNotConstant c chart constant
    obtain ⟨h,after⟩ := downstreamOf c nr.1 nr.2 notOut
    have hh := readerBounds c after
    have nh := d.chrono after
    have exclusive (j : Nat) (e : d.edge p j) : j = n := fork_unique d p hot j n e pRead
    let w := fun j => if j = p then (fun _ : Row => false) else onMoved d chart.moves j
    have faithful (j : Nat) (ne : j ≠ p) : w j = onMoved d chart.moves j := if_neg ne
    have ordinary {j : Nat} {g : Gate} (read : d.get j = some g) (jp : j ≠ p) (jn : j ≠ n) :
        w j = (c.op j).apply (w g.left) (w g.right) := by
      have left : g.left ≠ p := fun eq => jn (exclusive j ⟨g,read,Or.inl eq⟩)
      have right : g.right ≠ p := fun eq => jn (exclusive j ⟨g,read,Or.inr eq⟩)
      rw [faithful _ jp,faithful _ left,faithful _ right,moved_gate c _ read]
    obtain ⟨bit,cb⟩ := constant
    have fixedReader : w n = fun _ => bit := (faithful n (by omega)).trans cb
    have hUnary : ∃ j < h, ∃ f : Bool → Bool, w h = fun r => f (w j r) := by
      obtain ⟨g,rd,side⟩ := after
      have less := d.back h g rd
      have form := ordinary rd (by omega) (by omega)
      rcases side with l | r
      · refine ⟨g.right,less.2,fun y => (c.op h).bit bit y,?_⟩
        rw [form,l,fixedReader]; funext row; exact op_eval _ _ _ row
      · refine ⟨g.left,less.1,fun x => (c.op h).bit x bit,?_⟩
        rw [form,r,fixedReader]; funext row; exact op_eval _ _ _ row
    obtain ⟨k,bank,budget,run,ready⟩ := saveThree w (chart.base.map observe) p n h internal nr.1
      (by omega) nr.2 hh.1 hh.2 (by omega) (by omega) (by omega)
      (fun j lo => by rw [faithful j (by omega)]; exact moved_inputs c chart.mapOK j lo)
      (by
        intro j marked
        rcases marked with eq | eq | eq
        · subst j; exact ⟨0,by omega,fun _ => false,by simp [w]⟩
        · subst j; exact ⟨0,by omega,fun _ => bit,fixedReader⟩
        · subst j; exact hUnary)
      (by
        intro j lo hi jp jn _
        obtain ⟨g,rd⟩ := c.diagram.present j lo hi
        have less := d.back j g rd
        exact ⟨g.left,less.1,g.right,less.2,c.op j,ordinary rd jp jn⟩)
    have hit := ready out c.upperOut
    rw [faithful out (Ne.symm (c.finalWire p n pRead)),moved_output c (map_correct (u:=true) chart.mapOK).1] at hit
    have lower := chart.floor k bank run hit
    omega

theorem protectedGuard {d out i} (c : FifteenCore d out) (charts : ∀ b, PinChart i b) (low : i < 10) :
    Nonempty (RealGuard d out i) := by
  have sole := protectedSole c charts low
  obtain ⟨n,g,read,side⟩ := rawHasReader c low
  have controls (op : SignedOp) := gateControl op
  obtain ⟨⟨br,hr⟩,⟨bl,hl⟩⟩ := controls (c.op n)
  rcases side with l | r
  · have internal : 10 ≤ g.right := by
      by_contra! hw
      have h := rawPair_left_fork d c.diagram out c.lowerOut c.computes n g read (by simpa only [l] using low) hw
        (c.properSockets n g read) bl (by simpa only [c.signed n g read] using hl)
      rw [l,sole] at h; contradiction
    have hot := companionFork c charts low internal ⟨n,g,read,Or.inl ⟨l,rfl⟩⟩
    obtain ⟨guard,_⟩ := guardFromReader c low sole g read (Or.inl ⟨l,hot⟩)
    exact ⟨guard⟩
  · have internal : 10 ≤ g.left := by
      by_contra! hw
      have h := rawPair_right_fork d c.diagram out c.lowerOut c.computes n g read hw (by simpa only [r] using low)
        (Ne.symm (c.properSockets n g read)) br (by simpa only [c.signed n g read] using hr)
      rw [r,sole] at h; contradiction
    have hot := companionFork c charts low internal ⟨n,g,read,Or.inr ⟨r,rfl⟩⟩
    obtain ⟨guard,_⟩ := guardFromReader c low sole g read (Or.inr ⟨r,hot⟩)
    exact ⟨guard⟩

end Petersen9822.DagCut
