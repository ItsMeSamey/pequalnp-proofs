import Not9822Bundle04Masks

-- Not9822Placement
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

def firstId (out : Nat) : List (Nat × Nat) → Nat
  | [] => out
  | x :: _ => x.1

abbrev Ordered (l : List (Nat × Nat)) := l.Pairwise (fun a b => a.1 < b.1)

private theorem head_le {l : List (Nat × Nat)} (ord : Ordered l) (out : Nat) :
    ∀ e ∈ l, firstId out l ≤ e.1 := by
  cases l with
  | nil => simp
  | cons a as =>
    intro e he
    rcases List.mem_cons.mp he with rfl | h
    · exact Nat.le_refl _
    · exact Nat.le_of_lt ((List.pairwise_cons.mp ord).1 _ h)

private theorem head_le_out {l : List (Nat × Nat)} {out : Nat} (h : ∀ e ∈ l, e.1 < out) :
    firstId out l ≤ out := by
  cases l with
  | nil => exact Nat.le_refl _
  | cons e es => exact Nat.le_of_lt (h e List.mem_cons_self)

structure LabelFacts (d : Indexed) (out : Nat) (shared rep : Nat → Bool) (e : Nat × Nat) : Prop where
  sharedGate : shared e.1 = true
  live : ∃ path, Path d.edge out e.1 path
  ownerTwo : assigned d out shared 2 ≠ e.1 ∨ rep 2 = true
  ownerOne : (!rep 1 && decide (assigned d out shared 1 = e.1)) = decide (e.2 = 2)
  neighborSix : e.2 = 0 → assigned d out shared 6 ≠ e.1 ∨ rep 6 = true
  neighborSeven : e.2 = 1 → assigned d out shared 7 ≠ e.1 ∨ rep 7 = true
  independent : edgeHit (siteMask rep (assigned d out shared) e.1) = false
  guard : ownerBit e.2 ≠ 0 → ∃ block, PrivateSockets d e.1 (ownerBit e.2) block
  outputCold : (ownerBit e.2).testBit out = false

theorem placementOfSites (d : Indexed) (out : Nat) (shared rep : Nat → Bool)
    (sites : List (Nat × Nat)) (ord : Ordered sites) (early : ∀ e ∈ sites, e.1 < out)
    (finalWire : ∀ a b, d.edge a b → a ≠ out)
    (det : ∀ a, shared a = false → ∀ b c, d.edge a b → d.edge a c → b = c)
    (computes : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit)
    (facts : ∀ e ∈ sites, LabelFacts d out shared rep e)
    (covered : ∀ v, v < 10 → rep v = false →
      assigned d out shared v = out ∨ ∃ e ∈ sites, e.1 = assigned d out shared v)
    (lastIndependent : edgeHit (siteMask rep (assigned d out shared) out) = false) :
    Placement (sites.map Prod.snd) (pack rep) := by
  let own := assigned d out shared
  have upper (v : Nat) (hv : v < 10) (hr : rep v = false) : own v ≤ out := by
    rcases covered v hv hr with h | ⟨e,he,eq⟩
    · exact Nat.le_of_eq h
    · apply Nat.le_of_lt
      change assigned d out shared v < out
      rw [← eq]
      exact early e he
  have start : priorMask rep own (firstId out sites) = pack rep := by
    apply Nat.eq_of_testBit_eq
    intro v
    simp only [priorMask, pack_bit]
    by_cases hv : v < 10
    · cases hr : rep v with
      | true => simp
      | false =>
        have le : firstId out sites ≤ own v := by
          rcases covered v hv hr with h | ⟨e,he,eq⟩
          · rw [show own v = out from h]; exact head_le_out early
          · rw [←show e.1 = own v from eq]; exact head_le ord out e he
        simp [Nat.not_lt_of_ge le]
    · simp [hv]
  rw [←start]
  have build (xs : List (Nat × Nat)) (sorted : Ordered xs) (included : ∀ e ∈ xs, e ∈ sites)
      (still : ∀ v, v < 10 → rep v = false → firstId out xs ≤ own v →
        own v = out ∨ ∃ e ∈ xs, e.1 = own v) :
      Placement (xs.map Prod.snd) (priorMask rep own (firstId out xs)) := by
    induction xs with
    | nil =>
      apply Placement.nil
      have eq : later (priorMask rep own out) 0 = siteMask rep own out := by
        apply Nat.eq_of_testBit_eq
        intro v
        simp only [later,Nat.or_zero,Nat.testBit_xor,cubeBit,priorMask,siteMask,pack_bit]
        by_cases hv : v < 10
        · cases hr : rep v with
          | true => simp [hv]
          | false =>
            rcases lt_or_eq_of_le (upper v hv hr) with lt | eq
            · simp [hv,lt,Nat.ne_of_lt lt]
            · simp [hv,eq]
        · simp [hv]
      change edgeHit (later (priorMask rep own out) 0) = false
      rw [eq]
      exact lastIndependent
    | cons e es ih =>
      obtain ⟨ltTail,ordTail⟩ := List.pairwise_cons.mp sorted
      have subTail := fun z (hz : z ∈ es) => included z (List.mem_cons_of_mem _ hz)
      have here := facts e (included e List.mem_cons_self)
      have lt : e.1 < firstId out es := by
        cases es with
        | nil => exact early _ (included e List.mem_cons_self)
        | cons n ns => exact ltTail n List.mem_cons_self
      have remaining (v : Nat) (hv : v < 10) (hr : rep v = false) (gt : e.1 < own v) :
          own v = out ∨ ∃ z ∈ es, z.1 = own v := by
        rcases still v hv hr (Nat.le_of_lt gt) with eq | ⟨z,hz,eq⟩
        · exact Or.inl eq
        · rcases List.mem_cons.mp hz with rfl | hz
          · omega
          · exact Or.inr ⟨z,hz,eq⟩
      have gap (v : Nat) (hv : v < 10) (hr : rep v = false) (gt : e.1 < own v) :
          firstId out es ≤ own v := by
        rcases remaining v hv hr gt with eq | ⟨z,hz,eq⟩
        · rw [eq]
          exact head_le_out (fun z hz => early z (subTail z hz))
        · rw [←eq]
          exact head_le ordTail out _ hz
      let s := siteMask rep own e.1
      have legal := binLegal e.2 e.1 rep own here.ownerTwo here.ownerOne
        here.neighborSix here.neighborSeven here.independent
      have bins := concreteBins d out e.1 shared rep finalWire det here.sharedGate here.live
      apply Placement.cons (s := s) (pack_lt _) legal
        (bins.admissible _ _ here.guard here.outputCold computes)
      change Placement (List.map Prod.snd es) (priorMask rep own e.1 ||| s)
      rw [show priorMask rep own e.1 ||| s = priorMask rep own (firstId out es)
        from advancePrior rep own _ _ lt gap]
      exact ih ordTail subTail (fun v hv hr h => remaining v hv hr (Nat.lt_of_lt_of_le lt h))
  exact build sites ord (fun _ h => h) (fun v hv hr _ => covered v hv hr)

end Petersen9822.DagCut

-- Not9822Covered
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

/-- Every vertex strictly after the raw leaf in a downstream path is a gate. -/
private theorem path_internal {d : Indexed} {out v : Nat} {xs : List Nat}
    (raws : ∀ a b, d.edge a b → 10 ≤ b)
    (h : Path d.edge out v xs) : ∀ z ∈ xs, 10 ≤ z := by
  induction h with
  | stop => simp
  | @step a b xs _ he _ ih =>
    intro z hz
    rcases List.mem_cons.mp hz with rfl | hz
    · exact raws a _ he
    · exact ih _ hz

noncomputable def fork (d : Indexed) (v : Nat) : Bool := by
  classical
  exact decide (∃ b c, d.edge v b ∧ d.edge v c ∧ b ≠ c)

theorem fork_unique (d : Indexed) : ∀ a, fork d a = false →
    ∀ b c, d.edge a b → d.edge a c → b = c := by
  classical
  intro a h b c hb hc
  by_contra hn
  have yes : fork d a = true := by simpa [fork] using
    (show ∃ b c, d.edge a b ∧ d.edge a c ∧ b ≠ c from ⟨b,c,hb,hc,hn⟩)
  simp_all

theorem coverOfShared (d : Indexed) (out : Nat) (shared rep : Nat → Bool)
    (sites : List (Nat × Nat))
    (raws : ∀ a b, d.edge a b → 10 ≤ b)
    (rawRep : ∀ v, v < 10 → rep v = false → shared v = false)
    (enumerates : ∀ k, 10 ≤ k → k ≠ out → shared k = true →
      ∃ e ∈ sites, e.1 = k)
    (v : Nat) (hv : v < 10) (hr : rep v = false) :
    assigned d out shared v = out ∨ ∃ e ∈ sites, e.1 = assigned d out shared v := by
  classical
  by_cases live : ∃ xs, Path d.edge out v xs
  · rw [assigned_live live]
    let xs := live.choose
    have hp : Path d.edge out v xs := live.choose_spec
    change first shared out v xs = out ∨ _
    by_cases ho : first shared out v xs = out
    · exact Or.inl ho
    · have hs := (first_is_site (shared := shared) hp).resolve_left ho
      have on := first_on_path (shared := shared) hp
      have tail : first shared out v xs ∈ xs := by
        rcases List.mem_cons.mp on with eq | h
        · rw [eq,rawRep v hv hr] at hs; contradiction
        · exact h
      exact Or.inr (enumerates _ (path_internal raws hp _ tail) ho hs)
  · exact Or.inl (by simp [assigned,live])

end Petersen9822.DagCut
