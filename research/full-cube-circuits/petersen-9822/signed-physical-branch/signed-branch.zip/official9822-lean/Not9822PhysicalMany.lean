import Not9822NoFifteenCore
import CompactPadding9822
namespace PEqualNP.Outside.L_meta_9822.Compact
open PEqualNP.Outside.L_meta_9825.Engine
open PEqualNP.Outside.L_meta_9822.Clean PEqualNP.Outside.L_meta_9822.Sectors

theorem reducedBinarySixteen
    (c5 : Lower true (varsX 668) (graphGoal 668) 7)
    (seven : Lower true (varsX 701) (graphGoal 701) 11)
    (nine : Lower true (varsX 1015) (graphGoal 1015) 14)
    {gs o} (hr : Reduced 10 gs o) (ev : ∀ x, vl gs x o = Sectors.edge x) :
    16 ≤ gs.countP Compact.bin := by
  by_contra! small
  have pos := hasBinary hr ev
  obtain ⟨net,h⟩ := signedDagOf hr (outputGate ev).2 pos
  rw [show (fun x => vl gs x o) = Sectors.edge from funext ev] at h
  obtain ⟨padded,ok⟩ := padTo net h pos 15 (by omega)
  obtain ⟨core⟩ := coreOfNet padded ok
  exact Petersen9822.DagCut.noFifteenCore c5 seven nine core

theorem reducedManyImpossible
    (c5 : Lower true (varsX 668) (graphGoal 668) 7)
    (seven : Lower true (varsX 701) (graphGoal 701) 11)
    (nine : Lower true (varsX 1015) (graphGoal 1015) 14)
    {gs o} (hr : Reduced 10 gs o) (ev : ∀ x, vl gs x o = Sectors.edge x)
    (size : gs.length ≤ 17) (many : 2 ≤ gs.countP countsNot) : False := by
  obtain ⟨_,⟨core⟩⟩ := coreWithoutFloor hr ev size many
  exact Petersen9822.DagCut.noFifteenCore c5 seven nine core

end PEqualNP.Outside.L_meta_9822.Compact
#print axioms PEqualNP.Outside.L_meta_9822.Compact.reducedManyImpossible
