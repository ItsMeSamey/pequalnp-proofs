import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_3_290 : nodeCheck frozen 3 290 [290, 291, 298, 306, 354, 418, 802] = true := by decide +kernel
end Petersen9822
