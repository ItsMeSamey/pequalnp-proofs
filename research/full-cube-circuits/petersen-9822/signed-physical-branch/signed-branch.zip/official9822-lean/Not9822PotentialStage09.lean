import Not9822PotentialStage08
import Not9822RawPairReaders

-- Not9822RepeatBudget
namespace Petersen9822.Potential
open Petersen9822.DagCut
open Petersen9822.FirstSite
open PEqualNP.Outside.L_meta_9825.Engine

def rawSlots : Finset Slot := Finset.univ.filter (fun v => v.val < 10)
noncomputable def rawForks (d : Indexed) : Finset Slot := rawSlots.filter (fun v => fork d v.val)
noncomputable def innerForks (d : Indexed) : Finset Slot :=
  (List.ofFn gateSlot).toFinset.filter (fun v => fork d v.val)

theorem combined_excess (d : Indexed) (valid : Fifteen d) (out : Nat) (bound : out < 25)
    (sink : ∀ a b, d.edge a b → a ≠ out)
    (live : ∀ v, 10 ≤ v → v < 25 → ∃ xs, Path d.edge out v xs)
    (compute : ∀ row, edgeHit row = wireValue d out row) :
    (rawForks d).card + (innerForks d).card ≤ 6 := by
  classical
  have cover (v : Slot) :
      (if v ∈ rawSlots then 1 else 0) + (if v ∈ rawForks d then 1 else 0) +
      (if v ∈ innerForks d then 1 else 0) ≤ charge (initialKind v) (originalUses d out v) := by
    simp only [rawForks,innerForks,rawSlots,Finset.mem_filter,Finset.mem_univ,true_and,List.mem_toFinset] 
    by_cases raw : v.val < 10
    · have kind : initialKind v = .raw := by simp [initialKind,raw]
      have notGate : v ∉ List.ofFn gateSlot := fun h => by
        have := (ids_match_kind v).mpr h
        simp_all
      by_cases rep : fork d v.val = true
      · have val := fork_uses d valid out v.val rep
        simpa [-List.ofFn_succ,raw,kind,rep,notGate,charge,slot_fin] using val
      · have val := raw_live_use d valid out ⟨v.val,raw⟩ sink compute
        change 1 ≤ originalUses d out v at val
        simpa [-List.ofFn_succ,raw,kind,rep,notGate,charge] using val
    · by_cases isGate : v ∈ List.ofFn gateSlot
      · have kind := (ids_match_kind v).mpr isGate
        by_cases rep : fork d v.val = true
        · have val := fork_uses d valid out v.val rep
          rw [slot_fin] at val
          simp [-List.ofFn_succ,raw,kind,isGate,rep,charge]
          omega
        · simp [-List.ofFn_succ,raw,kind,isGate,rep]
      · simp [-List.ofFn_succ,raw,isGate]
  have all := Finset.sum_le_sum (s := (Finset.univ : Finset Slot)) (fun v _ => cover v)
  have card (S : Finset Slot) : (∑ v : Slot, if v ∈ S then 1 else 0) = S.card := by simp
  rw [Finset.sum_add_distrib,Finset.sum_add_distrib,card,card,card] at all
  change _ ≤ total initialKind (originalUses d out) at all
  rw [original_charge d valid out bound live] at all
  have ten : rawSlots.card = 10 := by decide +kernel
  omega

theorem at_least_two_repeated (d : Indexed) (valid : Fifteen d) (out : Nat) (hi : 10 ≤ out)
    (compute : ∀ row, edgeHit row = wireValue d out row)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (ops : Nat → SignedOp) (signed : ∀ n g, d.get n = some g → ∀ a b, g.op a b = (ops n).bit a b) :
    2 ≤ (rawForks d).card := by
  classical
  obtain ⟨g,hg⟩ := valid.present 10 (by decide) (by decide)
  have diff := distinct _ _ hg
  obtain ⟨l,r⟩ := first_forks d valid out hi compute g hg diff (ops 10) (signed _ _ hg)
  obtain ⟨ll,rr⟩ := d.back _ _ hg
  have lf := slot_val g.left (by omega)
  have rf := slot_val g.right (by omega)
  have ne : slot g.left ≠ slot g.right := by
    intro eq
    exact diff (by simpa only [lf,rf] using congrArg Fin.val eq)
  have sub : ({slot g.left,slot g.right} : Finset Slot) ⊆ rawForks d := by
    intro v hv
    simp only [Finset.mem_insert,Finset.mem_singleton] at hv
    rcases hv with rfl | rfl
    · simp [rawForks,rawSlots,lf,ll,l]
    · simp [rawForks,rawSlots,rf,rr,r]
  simpa [ne] using Finset.card_le_card sub

theorem three_force_unique_off (d : Indexed) (valid : Fifteen d) (out : Nat) (bound : out < 25)
    (sink : ∀ a b, d.edge a b → a ≠ out) (compute : ∀ row, edgeHit row = wireValue d out row)
    (live : ∀ v, 10 ≤ v → v < 25 → ∃ xs, Path d.edge out v xs)
    (M : Finset Slot) (three : M.card = 3)
    (real : ∀ v ∈ M, v ∈ List.ofFn gateSlot ∧ fork d v.val = true)
    (floor : 8 ≤ ∑ v, retainedCharge initialKind C5 (fun s => decide (s ∈ M)) (originalUses d out) v) :
    ∀ v ∈ outside, originalUses d out v = 1 := by
  classical
  let lost := lostCharge initialKind C5 (fun s => decide (s ∈ M)) (originalUses d out)
  have cap := lostAtMostEight initialKind C5 _ _ (Nat.le_of_eq (original_charge d valid out bound live)) floor
  have dis : Disjoint outside M := by
    apply Finset.disjoint_left.mpr
    intro v hv hm
    have hr := (outside_roles _ hv).1
    have hg := (ids_match_kind v).mpr (real _ hm).1
    simp_all
  have card : (outside ∪ M).card = 8 := by rw [Finset.card_union_of_disjoint dis,outside_card,three]
  have pos (v : Slot) (hv : v ∈ outside ∪ M) : 1 ≤ lost v := by
    rcases Finset.mem_union.mp hv with hv | hm
    · obtain ⟨hr,hc⟩ := outside_roles v hv
      have hi : ∀ x ∈ outside, x.val < 10 := by decide +kernel
      have u := raw_live_use d valid out ⟨v.val,hi _ hv⟩ sink compute
      change 1 ≤ originalUses d out v at u
      simpa [lost,lostCharge,hr,hc,charge] using u
    · obtain ⟨old,forked⟩ := real v hm
      have u := fork_uses d valid out v.val forked
      rw [slot_fin] at u
      simp [lost,lostCharge,hm,(ids_match_kind _).mpr old,charge]
      omega
  intro v hv
  obtain ⟨hr,hc⟩ := outside_roles v hv
  simpa [lost,lostCharge,hr,hc,charge] using
    saturated_losses lost _ cap card pos v (Finset.mem_union_left _ hv)

end Petersen9822.Potential
