import Not9822ProjectedRows2
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor
private theorem block24 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((768+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (768+k.val) := by decide +kernel
private theorem block25 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((800+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (800+k.val) := by decide +kernel
private theorem block26 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((832+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (832+k.val) := by decide +kernel
private theorem block27 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((864+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (864+k.val) := by decide +kernel
private theorem block28 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((896+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (896+k.val) := by decide +kernel
private theorem block29 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((928+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (928+k.val) := by decide +kernel
private theorem block30 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((960+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (960+k.val) := by decide +kernel
private theorem block31 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((992+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (992+k.val) := by decide +kernel
theorem region3 (h : Nat) (lo : 24 ≤ h) (hi : h < 32) (j : Bool) (k : Fin 32) :
    edgeHit (((32*h+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (32*h+k.val) := by
  have casesH : h = 24 ∨ h = 25 ∨ h = 26 ∨ h = 27 ∨ h = 28 ∨ h = 29 ∨ h = 30 ∨ h = 31 := by omega
  rcases casesH with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact block24 j k
  · exact block25 j k
  · exact block26 j k
  · exact block27 j k
  · exact block28 j k
  · exact block29 j k
  · exact block30 j k
  · exact block31 j k

end Petersen9822.Potential
