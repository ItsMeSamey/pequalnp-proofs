import SignedScans
import SignedLogicalLayer3

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_48_0123 : ¬ Placement [0, 1, 2, 3] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_123
    · exact node_49_123
theorem node_48_0132 : ¬ Placement [0, 1, 3, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_132
    · exact node_49_132
theorem node_48_0213 : ¬ Placement [0, 2, 1, 3] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_213
    · exact node_49_213
theorem node_48_0231 : ¬ Placement [0, 2, 3, 1] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_231
    · exact node_49_231
theorem node_48_0312 : ¬ Placement [0, 3, 1, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_312
    · exact node_49_312
theorem node_48_0321 : ¬ Placement [0, 3, 2, 1] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_321
    · exact node_49_321
theorem node_48_1023 : ¬ Placement [1, 0, 2, 3] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_1_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_023
    · exact node_49_023
theorem node_48_1032 : ¬ Placement [1, 0, 3, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_1_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_032
    · exact node_49_032
theorem node_48_1302 : ¬ Placement [1, 3, 0, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_1_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_302
    · exact node_49_302
theorem node_48_3012 : ¬ Placement [3, 0, 1, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49, 56, 57, 112, 176, 304, 560])
  · exact scan_3_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_48_012
    · exact node_49_012
    · exact node_56_012
    · exact node_57_012
    · exact node_112_012
    · exact node_176_012
    · exact node_304_012
    · exact node_560_012
theorem node_48_3021 : ¬ Placement [3, 0, 2, 1] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49, 56, 57, 112, 176, 304, 560])
  · exact scan_3_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_48_021
    · exact node_49_021
    · exact node_56_021
    · exact node_57_021
    · exact node_112_021
    · exact node_176_021
    · exact node_304_021
    · exact node_560_021
theorem node_48_3102 : ¬ Placement [3, 1, 0, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49, 56, 57, 112, 176, 304, 560])
  · exact scan_3_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_48_102
    · exact node_49_102
    · exact node_56_102
    · exact node_57_102
    · exact node_112_102
    · exact node_176_102
    · exact node_304_102
    · exact node_560_102
theorem node_272_0123 : ¬ Placement [0, 1, 2, 3] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_123
    · exact node_280_123
theorem node_272_0132 : ¬ Placement [0, 1, 3, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_132
    · exact node_280_132
theorem node_272_0213 : ¬ Placement [0, 2, 1, 3] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_213
    · exact node_280_213
theorem node_272_0231 : ¬ Placement [0, 2, 3, 1] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_231
    · exact node_280_231
theorem node_272_0312 : ¬ Placement [0, 3, 1, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_312
    · exact node_280_312
theorem node_272_0321 : ¬ Placement [0, 3, 2, 1] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_321
    · exact node_280_321
theorem node_272_1023 : ¬ Placement [1, 0, 2, 3] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_1_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_023
    · exact node_280_023
theorem node_272_1032 : ¬ Placement [1, 0, 3, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_1_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_032
    · exact node_280_032
theorem node_272_1302 : ¬ Placement [1, 3, 0, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_1_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_302
    · exact node_280_302
theorem node_272_3012 : ¬ Placement [3, 0, 1, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 273, 280, 281, 304, 336, 400, 784])
  · exact scan_3_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_272_012
    · exact node_273_012
    · exact node_280_012
    · exact node_281_012
    · exact node_304_012
    · exact node_336_012
    · exact node_400_012
    · exact node_784_012
theorem node_272_3021 : ¬ Placement [3, 0, 2, 1] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 273, 280, 281, 304, 336, 400, 784])
  · exact scan_3_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_272_021
    · exact node_273_021
    · exact node_280_021
    · exact node_281_021
    · exact node_304_021
    · exact node_336_021
    · exact node_400_021
    · exact node_784_021
theorem node_272_3102 : ¬ Placement [3, 1, 0, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 273, 280, 281, 304, 336, 400, 784])
  · exact scan_3_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_272_102
    · exact node_273_102
    · exact node_280_102
    · exact node_281_102
    · exact node_304_102
    · exact node_336_102
    · exact node_400_102
    · exact node_784_102
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_288_0123 : ¬ Placement [0, 1, 2, 3] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_123
theorem node_288_0132 : ¬ Placement [0, 1, 3, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_132
theorem node_288_0213 : ¬ Placement [0, 2, 1, 3] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_213
theorem node_288_0231 : ¬ Placement [0, 2, 3, 1] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_231
theorem node_288_0312 : ¬ Placement [0, 3, 1, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_312
theorem node_288_0321 : ¬ Placement [0, 3, 2, 1] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_321
theorem node_288_1023 : ¬ Placement [1, 0, 2, 3] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_1_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_023
theorem node_288_1032 : ¬ Placement [1, 0, 3, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_1_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_032
theorem node_288_1302 : ¬ Placement [1, 3, 0, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_1_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_302
theorem node_288_3012 : ¬ Placement [3, 0, 1, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288, 289, 296, 304, 352, 416, 800])
  · exact scan_3_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_288_012
    · exact node_289_012
    · exact node_296_012
    · exact node_304_012
    · exact node_352_012
    · exact node_416_012
    · exact node_800_012
theorem node_288_3021 : ¬ Placement [3, 0, 2, 1] 288 := by
  apply node_sound (lookup := frozen) (next := [288, 289, 296, 304, 352, 416, 800])
  · exact scan_3_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_288_021
    · exact node_289_021
    · exact node_296_021
    · exact node_304_021
    · exact node_352_021
    · exact node_416_021
    · exact node_800_021
theorem node_288_3102 : ¬ Placement [3, 1, 0, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288, 289, 296, 304, 352, 416, 800])
  · exact scan_3_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_288_102
    · exact node_289_102
    · exact node_296_102
    · exact node_304_102
    · exact node_352_102
    · exact node_416_102
    · exact node_800_102
end Petersen9822
