import Not9822ProjectedBits
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor
private theorem block0 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((0+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (0+k.val) := by decide +kernel
private theorem block1 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((32+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (32+k.val) := by decide +kernel
private theorem block2 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((64+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (64+k.val) := by decide +kernel
private theorem block3 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((96+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (96+k.val) := by decide +kernel
private theorem block4 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((128+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (128+k.val) := by decide +kernel
private theorem block5 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((160+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (160+k.val) := by decide +kernel
private theorem block6 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((192+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (192+k.val) := by decide +kernel
private theorem block7 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((224+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (224+k.val) := by decide +kernel
theorem region0 (h : Nat) (lo : 0 ≤ h) (hi : h < 8) (j : Bool) (k : Fin 32) :
    edgeHit (((32*h+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (32*h+k.val) := by
  have casesH : h = 0 ∨ h = 1 ∨ h = 2 ∨ h = 3 ∨ h = 4 ∨ h = 5 ∨ h = 6 ∨ h = 7 := by omega
  rcases casesH with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact block0 j k
  · exact block1 j k
  · exact block2 j k
  · exact block3 j k
  · exact block4 j k
  · exact block5 j k
  · exact block6 j k
  · exact block7 j k

end Petersen9822.Potential
