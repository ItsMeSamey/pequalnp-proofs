import Not9822PotentialStage08A
-- Not9822InitialFork
namespace Petersen9822.DagCut
open Petersen9822.Potential

private def fixPair (i j : Fin 10) (b : Bool) (k : Option (Fin 10)) : Nat :=
  (if b then 2^j.val else 0) ||| (match k with | none => 0 | some v => if v=i ∨ v=j then 0 else 2^v.val)

set_option maxRecDepth 16000 in
set_option maxHeartbeats 0 in
private theorem pivotRows : ∀ i j : Fin 10, i ≠ j → ∀ b : Bool, ∃ k : Option (Fin 10),
    (fixPair i j b k).testBit j.val = b ∧
      edgeHit (fixPair i j b k) ≠ edgeHit (fixPair i j b k ||| 2^i.val) := by decide +kernel

private theorem two_sides (op : Potential.SignedOp) :
    (∃ b, op.bit false b = op.bit true b) ∧ (∃ b, op.bit b false = op.bit b true) := by
  cases op with
  | mk k l r o => cases k <;> cases l <;> cases r <;> cases o <;> decide

theorem rawPair_left_fork (d : Indexed) (valid : Fifteen d) (out : Nat) (outNonraw : 10 ≤ out)
    (compute : ∀ row, edgeHit row = wireValue d out row)
    (kGate : Nat) (g : Gate) (atGate : d.get kGate = some g) (leftRaw : g.left < 10) (rightRaw : g.right < 10) (distinct : g.left ≠ g.right) (b : Bool)
    (blocks : g.op false b = g.op true b) : fork d g.left = true := by
  cases h : fork d g.left with
  | true => rfl
  | false =>
    have il := leftRaw
    have jl := rightRaw
    let i : Fin 10 := ⟨g.left,il⟩
    let j : Fin 10 := ⟨g.right,jl⟩
    obtain ⟨k,hb,pivot⟩ := pivotRows i j (fun eq => distinct (congrArg Fin.val eq)) b
    have eq : d.tree g.right = .raw g.right := d.tree_none (valid.raw _ jl)
    have guard : PrivateSockets d g.right (2^g.left) b := by
      refine ⟨by simp [Nat.testBit_two_pow,distinct],?_,?_,?_⟩
      · intro v hv
        have hz : g.left = v := by simpa [Nat.testBit_two_pow] using hv
        subst v; exact valid.raw _ il
      · intro n x hg read
        have hz : g.left = x.left := by simpa [Nat.testBit_two_pow] using read
        have hn := fork_unique d g.left h n kGate ⟨x,hg,Or.inl hz.symm⟩ ⟨g,atGate,Or.inl rfl⟩
        subst n
        have he := Option.some.inj (hg.symm.trans atGate)
        subst x
        exact ⟨rfl,blocks⟩
      · intro n x hg read
        have hz : g.left = x.right := by simpa [Nat.testBit_two_pow] using read
        have hn := fork_unique d g.left h n kGate ⟨x,hg,Or.inr hz.symm⟩ ⟨g,atGate,Or.inl rfl⟩
        subst n
        have he := Option.some.inj (hg.symm.trans atGate)
        subst x
        contradiction
    have absent : ¬ (d.tree g.right).term.uses g.left := by simp [eq,Tree.term,Term.uses,Ne.symm distinct]
    have cold : (2^g.left : Nat).testBit out = false := by simp [Nat.testBit_two_pow,show g.left ≠ out by omega]
    have pass := (guard_pivot guard cold absent compute pivot).1
    change (fixPair i j b k).testBit g.right = b at hb
    simp [wireValue,eq,Tree.term,Term.eval,hb] at pass

theorem rawPair_right_fork (d : Indexed) (valid : Fifteen d) (out : Nat) (outNonraw : 10 ≤ out)
    (compute : ∀ row, edgeHit row = wireValue d out row)
    (kGate : Nat) (g : Gate) (atGate : d.get kGate = some g) (leftRaw : g.left < 10) (rightRaw : g.right < 10) (distinct : g.right ≠ g.left) (b : Bool)
    (blocks : g.op b false = g.op b true) : fork d g.right = true := by
  cases h : fork d g.right with
  | true => rfl
  | false =>
    have jl := leftRaw
    have il := rightRaw
    let i : Fin 10 := ⟨g.right,il⟩
    let j : Fin 10 := ⟨g.left,jl⟩
    obtain ⟨k,hb,pivot⟩ := pivotRows i j (fun eq => distinct (congrArg Fin.val eq)) b
    have eq : d.tree g.left = .raw g.left := d.tree_none (valid.raw _ jl)
    have guard : PrivateSockets d g.left (2^g.right) b := by
      refine ⟨by simp [Nat.testBit_two_pow,distinct],?_,?_,?_⟩
      · intro v hv
        have hz : g.right = v := by simpa [Nat.testBit_two_pow] using hv
        subst v; exact valid.raw _ il
      · intro n x hg read
        have hz : g.right = x.left := by simpa [Nat.testBit_two_pow] using read
        have hn := fork_unique d g.right h n kGate ⟨x,hg,Or.inl hz.symm⟩ ⟨g,atGate,Or.inr rfl⟩
        subst n
        have he := Option.some.inj (hg.symm.trans atGate)
        subst x
        contradiction
      · intro n x hg read
        have hz : g.right = x.right := by simpa [Nat.testBit_two_pow] using read
        have hn := fork_unique d g.right h n kGate ⟨x,hg,Or.inr hz.symm⟩ ⟨g,atGate,Or.inr rfl⟩
        subst n
        have he := Option.some.inj (hg.symm.trans atGate)
        subst x
        exact ⟨rfl,blocks⟩
    have absent : ¬ (d.tree g.left).term.uses g.right := by simp [eq,Tree.term,Term.uses,Ne.symm distinct]
    have cold : (2^g.right : Nat).testBit out = false := by simp [Nat.testBit_two_pow,show g.right ≠ out by omega]
    have pass := (guard_pivot guard cold absent compute pivot).1
    change (fixPair i j b k).testBit g.left = b at hb
    simp [wireValue,eq,Tree.term,Term.eval,hb] at pass

theorem first_forks (d : Indexed) (valid : Fifteen d) (out : Nat) (outNonraw : 10 ≤ out)
    (compute : ∀ row, edgeHit row = wireValue d out row) (g : Gate) (atTen : d.get 10 = some g)
    (distinct : g.left ≠ g.right) (op : Potential.SignedOp)
    (real : ∀ a b, g.op a b = op.bit a b) :
    fork d g.left = true ∧ fork d g.right = true := by
  obtain ⟨lr,rr⟩ := d.back 10 g atTen
  obtain ⟨⟨a,ha⟩,⟨b,hb⟩⟩ := two_sides op
  exact ⟨rawPair_left_fork d valid out outNonraw compute 10 g atTen lr rr distinct a (by simpa only [real] using ha),
    rawPair_right_fork d valid out outNonraw compute 10 g atTen lr rr (Ne.symm distinct) b (by simpa only [real] using hb)⟩

end Petersen9822.DagCut

