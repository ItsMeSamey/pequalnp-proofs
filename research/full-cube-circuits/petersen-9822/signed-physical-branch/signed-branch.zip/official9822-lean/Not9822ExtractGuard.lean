import Not9822GuardOfPin
import Not9822RawPairReaders
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

private theorem path_le_sink {d : Indexed} {out v xs} (p : Path d.edge out v xs) : v ≤ out := by
  induction p with
  | stop => exact Nat.le_refl _
  | step _ e _ ih => exact Nat.le_trans (Nat.le_of_lt (d.chrono e)) ih

/-- A sole raw reader whose companion is forked supplies a guard, with no extra
polarity, depth, gate-ID bound, or raw/nonraw hypothesis on the companion. -/
theorem guardFromReader {d : Indexed} {out raw read : Nat} (c : FifteenCore d out)
    (low : raw < 10) (unique : fork d raw = false) (g : Gate) (eq : d.get read = some g)
    (forked : (g.left = raw ∧ fork d g.right = true) ∨ (g.right = raw ∧ fork d g.left = true)) :
    ∃ guard : RealGuard d out raw,
      (g.left = raw ∧ guard.site = g.right) ∨ (g.right = raw ∧ guard.site = g.left) := by
  have controls (op : Petersen9822.Potential.SignedOp) :
      (∃ b, op.bit false b = op.bit true b) ∧ (∃ b, op.bit b false = op.bit b true) := by
    cases op with
    | mk k l r o => cases k <;> cases l <;> cases r <;> cases o <;> decide
  obtain ⟨⟨bl,hl⟩,⟨br,hr⟩⟩ := controls (c.op read)
  have lh : g.op false bl = g.op true bl := by simpa only [c.signed read g eq] using hl
  have rh : g.op br false = g.op br true := by simpa only [c.signed read g eq] using hr
  obtain ⟨lo,hi⟩ := c.diagram.extent read g eq
  obtain ⟨xs,p⟩ := c.live read lo hi
  obtain ⟨gl,gr⟩ := d.back read g eq
  have bound := path_le_sink p
  rcases forked with ⟨rfl,hot⟩ | ⟨rfl,hot⟩
  · have internal : 10 ≤ g.right := by
      by_contra! other
      have dup := rawPair_left_fork d c.diagram out c.lowerOut c.computes read g eq low other
        (c.properSockets read g eq) bl lh
      simp [unique] at dup
    exact ⟨guardOfPin c low internal (by omega) unique hot g eq bl (Or.inl ⟨rfl,rfl,lh⟩),Or.inl ⟨rfl,rfl⟩⟩
  · have internal : 10 ≤ g.left := by
      by_contra! other
      have dup := rawPair_right_fork d c.diagram out c.lowerOut c.computes read g eq other low
        (Ne.symm (c.properSockets read g eq)) br rh
      simp [unique] at dup
    exact ⟨guardOfPin c low internal (by omega) unique hot g eq br (Or.inr ⟨rfl,rfl,rh⟩),Or.inr ⟨rfl,rfl⟩⟩

end Petersen9822.DagCut
