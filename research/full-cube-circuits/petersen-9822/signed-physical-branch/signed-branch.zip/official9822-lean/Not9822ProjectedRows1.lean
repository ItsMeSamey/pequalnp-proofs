import Not9822ProjectedRows0
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor
private theorem block8 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((256+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (256+k.val) := by decide +kernel
private theorem block9 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((288+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (288+k.val) := by decide +kernel
private theorem block10 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((320+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (320+k.val) := by decide +kernel
private theorem block11 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((352+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (352+k.val) := by decide +kernel
private theorem block12 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((384+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (384+k.val) := by decide +kernel
private theorem block13 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((416+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (416+k.val) := by decide +kernel
private theorem block14 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((448+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (448+k.val) := by decide +kernel
private theorem block15 : ∀ j : Bool, ∀ k : Fin 32,
    edgeHit (((480+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (480+k.val) := by decide +kernel
theorem region1 (h : Nat) (lo : 8 ≤ h) (hi : h < 16) (j : Bool) (k : Fin 32) :
    edgeHit (((32*h+k.val) &&& 313) ||| (if j then 2 else 4)) = pentagonBits.testBit (32*h+k.val) := by
  have casesH : h = 8 ∨ h = 9 ∨ h = 10 ∨ h = 11 ∨ h = 12 ∨ h = 13 ∨ h = 14 ∨ h = 15 := by omega
  rcases casesH with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact block8 j k
  · exact block9 j k
  · exact block10 j k
  · exact block11 j k
  · exact block12 j k
  · exact block13 j k
  · exact block14 j k
  · exact block15 j k

end Petersen9822.Potential
