import Not9822PotentialStage12
import Not9822OrientPhysical

namespace Petersen9822.DagCut
open PEqualNP.Outside.L_meta_9825.Engine

theorem noGuardedFifteenCore (c5Prior : Lower true (varsX 668) (graphGoal 668) 7)
    {d out} (c : FifteenCore d out) (a : RealGuard d out 1) (b : RealGuard d out 2)
    (ab : a.site ≠ b.site) (zero : fork d 0 = false) (three : fork d 3 = false) : False := by
  apply orientPhysical (fun c a b => directedPhysical c5Prior c a b) c a b ab zero three
  · exact ownersSeparate d out (fork d) c.finalWire (fork_unique d) c.properSockets
      (fun n g hg => signedSocketOf _ _ (c.signed n g hg)) c.computes
  · exact oneOwnerAtOutput c5Prior c a b ab

end Petersen9822.DagCut
