import Not9822GuardBypass
import Not9822ReaderSaving
namespace Petersen9822.DagCut
open Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822

private theorem patchedUnary {d : Indexed} {raw site ra rb} (p : Bool) (reader : ReaderAt d raw site)
    (mark : reader.id = ra ∨ reader.id = rb) (apart : raw ≠ site) :
    ∃ j < reader.id, ∃ f : Bool → Bool, ∀ r : Row,
      bypassValue d site ra rb p reader.id r.val = f (bypassValue d site ra rb p j r.val) := by
  have less := d.back reader.id reader.g reader.read
  rcases reader.inputs with ⟨l,s⟩ | ⟨s,l⟩
  · refine ⟨raw,by omega,fun x => reader.g.op x p,?_⟩
    intro r
    simp [bypassValue,d.tree_some reader.read,bypassEval,mark,l,s,apart]
  · refine ⟨raw,by omega,fun x => reader.g.op p x,?_⟩
    intro r
    simp [bypassValue,d.tree_some reader.read,bypassEval,mark,l,s,apart]

private theorem inputAgrees (r : Row) : observe target r = edgeHit r.val := by
  have sampleEq : sample r = fun i : Fin 10 => r.val.testBit i.val :=
    funext (fun i => input_bits i r)
  change bit r target = _
  rw [onRows,sampleEq]
  exact (PEqualNP.Outside.L_meta_9822.Compact.rowEdge r.val).symm

set_option maxRecDepth 4000 in
set_option exponentiation.threshold 1024 in
theorem guardSitesDistinct (floor : Lower true inputs target 15) {d out} (c : FifteenCore d out)
    (a : RealGuard d out 1) (b : RealGuard d out 2) : a.site ≠ b.site := by
  intro same
  obtain ⟨A⟩ := readerAtOfGuard c a (by decide)
  obtain ⟨B0⟩ := readerAtOfGuard c b (by decide)
  let B : ReaderAt d 2 a.site := same.symm ▸ B0
  have ids : A.id ≠ B.id := by
    intro eq
    have ra := A.read
    rw [eq] at ra
    have gates : A.g = B.g := Option.some.inj (ra.symm.trans B.read)
    have ua := A.inputs
    rw [gates] at ua
    have hi := a.internal
    rcases ua with h | h <;> rcases B.inputs with k | k <;> omega
  let w := fun n (r : Row) => bypassValue d a.site A.id B.id (!a.block) n r.val
  have ab := c.diagram.extent _ _ A.read
  have bb := c.diagram.extent _ _ B.read
  obtain ⟨k,bank,budget,run,ready⟩ := saveTwo w (inputs.map observe) A.id B.id ab.1 bb.1 ab.2 bb.2 ids
    (by
      intro i lo
      have eq : w i = observe (inputs.getD i zero) := by
        funext r
        exact (show w i r = r.val.testBit i from by simp [w,bypassValue,d.tree_none (c.diagram.raw i lo),bypassEval]).trans
          (input_bits ⟨i,lo⟩ r).symm
      rw [eq]
      have member (i : Fin 10) : inputs.getD i.val zero ∈ inputs := (by decide : ∀ j : Fin 10, inputs.getD j.val zero ∈ inputs) i
      exact Or.inl (List.mem_map_of_mem (member ⟨i,lo⟩)))
    (by
      intro n marked
      have sg := a.internal
      rcases marked with rfl | rfl
      · obtain ⟨j,jh,f,eq⟩ := patchedUnary (!a.block) A (Or.inl rfl : A.id = A.id ∨ A.id = B.id) (by omega)
        exact ⟨j,jh,f,funext eq⟩
      · obtain ⟨j,jh,f,eq⟩ := patchedUnary (!a.block) B (Or.inr rfl : B.id = A.id ∨ B.id = B.id) (by omega)
        exact ⟨j,jh,f,funext eq⟩)
    (by
      intro n lo hi na nb
      obtain ⟨g,read⟩ := c.diagram.present n lo hi
      obtain ⟨l,r⟩ := d.back n g read
      refine ⟨g.left,l,g.right,r,c.op n,?_⟩
      funext row
      rw [op_eval]
      simp [w,bypassValue,d.tree_some read,bypassEval,na,nb,c.signed n g read])
  let alarm := fun r : Row => decide (w a.site r = a.block)
  have bnd := Nat.lt_trans a.beforeOut c.upperOut
  have ok := unaryAvailable (fun h => decide (h = a.block)) (ready a.site bnd)
  have runLast := Reach.two true run (ready out c.upperOut) ok
  have restore : observe target = combine true (w out) alarm := by
    funext r
    exact (inputAgrees r).trans (bypassOutput c a b same A B r.val)
  have hit : Available true (combine true (w out) alarm :: bank) (observe target) := by
    rw [restore]; exact Or.inl List.mem_cons_self
  have impossible := floor (k+1) _ runLast hit
  omega

end Petersen9822.DagCut
