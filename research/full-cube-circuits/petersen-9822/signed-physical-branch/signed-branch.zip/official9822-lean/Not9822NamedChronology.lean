import Not9822Bundle05Sites
namespace Petersen9822.DagCut

private abbrev threeRoster (a b q : Nat) := ∃ sites : List (Nat × Nat), Ordered sites ∧
  (∀ e, e ∈ sites ↔ e ∈ [(a,0), (b,1), (q,2)]) ∧
  (sites.map Prod.snd).Perm [0,1,2] ∧ (sites.map Prod.snd).idxOf 0 < (sites.map Prod.snd).idxOf 2

private theorem threeCase012 (a b q : Nat) (h : a < b ∧ b < q) : threeRoster a b q := by
  refine ⟨[(a,0), (b,1), (q,2)], ?_, ?_, by change ([0,1,2] : List Nat).Perm [0,1,2]; decide, by change ([0,1,2] : List Nat).idxOf 0 < ([0,1,2] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem threeCase021 (a b q : Nat) (h : a < q ∧ q < b) : threeRoster a b q := by
  refine ⟨[(a,0), (q,2), (b,1)], ?_, ?_, by change ([0,2,1] : List Nat).Perm [0,1,2]; decide, by change ([0,2,1] : List Nat).idxOf 0 < ([0,2,1] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem threeCase102 (a b q : Nat) (h : b < a ∧ a < q) : threeRoster a b q := by
  refine ⟨[(b,1), (a,0), (q,2)], ?_, ?_, by change ([1,0,2] : List Nat).Perm [0,1,2]; decide, by change ([1,0,2] : List Nat).idxOf 0 < ([1,0,2] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

theorem threeChronology (a b q : Nat) (aq : a < q)
    (ab : a ≠ b)
    (bq : b ≠ q)
    : threeRoster a b q := by
  by_cases h01 : a < b
  · by_cases h12 : b < q
    · apply threeCase012; omega
    · apply threeCase021; omega
  · apply threeCase102; omega

private abbrev fourRoster (a b q w : Nat) := ∃ sites : List (Nat × Nat), Ordered sites ∧
  (∀ e, e ∈ sites ↔ e ∈ [(a,0), (b,1), (q,2), (w,3)]) ∧
  (sites.map Prod.snd).Perm [0,1,2,3] ∧ (sites.map Prod.snd).idxOf 0 < (sites.map Prod.snd).idxOf 2

private theorem fourCase0123 (a b q w : Nat) (h : a < b ∧ b < q ∧ q < w) : fourRoster a b q w := by
  refine ⟨[(a,0), (b,1), (q,2), (w,3)], ?_, ?_, by change ([0,1,2,3] : List Nat).Perm [0,1,2,3]; decide, by change ([0,1,2,3] : List Nat).idxOf 0 < ([0,1,2,3] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase0132 (a b q w : Nat) (h : a < b ∧ b < w ∧ w < q) : fourRoster a b q w := by
  refine ⟨[(a,0), (b,1), (w,3), (q,2)], ?_, ?_, by change ([0,1,3,2] : List Nat).Perm [0,1,2,3]; decide, by change ([0,1,3,2] : List Nat).idxOf 0 < ([0,1,3,2] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase0213 (a b q w : Nat) (h : a < q ∧ q < b ∧ b < w) : fourRoster a b q w := by
  refine ⟨[(a,0), (q,2), (b,1), (w,3)], ?_, ?_, by change ([0,2,1,3] : List Nat).Perm [0,1,2,3]; decide, by change ([0,2,1,3] : List Nat).idxOf 0 < ([0,2,1,3] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase0231 (a b q w : Nat) (h : a < q ∧ q < w ∧ w < b) : fourRoster a b q w := by
  refine ⟨[(a,0), (q,2), (w,3), (b,1)], ?_, ?_, by change ([0,2,3,1] : List Nat).Perm [0,1,2,3]; decide, by change ([0,2,3,1] : List Nat).idxOf 0 < ([0,2,3,1] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase0312 (a b q w : Nat) (h : a < w ∧ w < b ∧ b < q) : fourRoster a b q w := by
  refine ⟨[(a,0), (w,3), (b,1), (q,2)], ?_, ?_, by change ([0,3,1,2] : List Nat).Perm [0,1,2,3]; decide, by change ([0,3,1,2] : List Nat).idxOf 0 < ([0,3,1,2] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase0321 (a b q w : Nat) (h : a < w ∧ w < q ∧ q < b) : fourRoster a b q w := by
  refine ⟨[(a,0), (w,3), (q,2), (b,1)], ?_, ?_, by change ([0,3,2,1] : List Nat).Perm [0,1,2,3]; decide, by change ([0,3,2,1] : List Nat).idxOf 0 < ([0,3,2,1] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase1023 (a b q w : Nat) (h : b < a ∧ a < q ∧ q < w) : fourRoster a b q w := by
  refine ⟨[(b,1), (a,0), (q,2), (w,3)], ?_, ?_, by change ([1,0,2,3] : List Nat).Perm [0,1,2,3]; decide, by change ([1,0,2,3] : List Nat).idxOf 0 < ([1,0,2,3] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase1032 (a b q w : Nat) (h : b < a ∧ a < w ∧ w < q) : fourRoster a b q w := by
  refine ⟨[(b,1), (a,0), (w,3), (q,2)], ?_, ?_, by change ([1,0,3,2] : List Nat).Perm [0,1,2,3]; decide, by change ([1,0,3,2] : List Nat).idxOf 0 < ([1,0,3,2] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase1302 (a b q w : Nat) (h : b < w ∧ w < a ∧ a < q) : fourRoster a b q w := by
  refine ⟨[(b,1), (w,3), (a,0), (q,2)], ?_, ?_, by change ([1,3,0,2] : List Nat).Perm [0,1,2,3]; decide, by change ([1,3,0,2] : List Nat).idxOf 0 < ([1,3,0,2] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase3012 (a b q w : Nat) (h : w < a ∧ a < b ∧ b < q) : fourRoster a b q w := by
  refine ⟨[(w,3), (a,0), (b,1), (q,2)], ?_, ?_, by change ([3,0,1,2] : List Nat).Perm [0,1,2,3]; decide, by change ([3,0,1,2] : List Nat).idxOf 0 < ([3,0,1,2] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase3021 (a b q w : Nat) (h : w < a ∧ a < q ∧ q < b) : fourRoster a b q w := by
  refine ⟨[(w,3), (a,0), (q,2), (b,1)], ?_, ?_, by change ([3,0,2,1] : List Nat).Perm [0,1,2,3]; decide, by change ([3,0,2,1] : List Nat).idxOf 0 < ([3,0,2,1] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

private theorem fourCase3102 (a b q w : Nat) (h : w < b ∧ b < a ∧ a < q) : fourRoster a b q w := by
  refine ⟨[(w,3), (b,1), (a,0), (q,2)], ?_, ?_, by change ([3,1,0,2] : List Nat).Perm [0,1,2,3]; decide, by change ([3,1,0,2] : List Nat).idxOf 0 < ([3,1,0,2] : List Nat).idxOf 2; decide⟩
  · simp [Ordered,List.pairwise_cons] <;> omega
  · intro e; simp [or_comm,or_left_comm,or_assoc]

theorem fourChronology (a b q w : Nat) (aq : a < q)
    (ab : a ≠ b)
    (aw : a ≠ w)
    (bq : b ≠ q)
    (bw : b ≠ w)
    (qw : q ≠ w)
    : fourRoster a b q w := by
  by_cases h13 : b < w
  · by_cases h01 : a < b
    · by_cases h12 : b < q
      · by_cases h23 : q < w
        · apply fourCase0123; omega
        · apply fourCase0132; omega
      · apply fourCase0213; omega
    · by_cases h03 : a < w
      · by_cases h23 : q < w
        · apply fourCase1023; omega
        · apply fourCase1032; omega
      · apply fourCase1302; omega
  · by_cases h03 : a < w
    · by_cases h12 : b < q
      · apply fourCase0312; omega
      · by_cases h23 : q < w
        · apply fourCase0231; omega
        · apply fourCase0321; omega
    · by_cases h01 : a < b
      · by_cases h12 : b < q
        · apply fourCase3012; omega
        · apply fourCase3021; omega
      · apply fourCase3102; omega

end Petersen9822.DagCut
