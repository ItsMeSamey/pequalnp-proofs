import Not9822CompanionFork
import Not9822ProtectedOuter
import Not9822NoCommonGuard
import Not9822SignedGuardExclusion
namespace Petersen9822.DagCut
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822

theorem noFifteenCore
    (c5 : Lower true (varsX 668) (graphGoal 668) 7)
    (seven : Lower true (varsX 701) (graphGoal 701) 11)
    (nine : Lower true (varsX 1015) (graphGoal 1015) 14)
    {d out} (c : FifteenCore d out) : False := by
  obtain ⟨a⟩ := protectedGuard c (pinChart1 seven) (by decide)
  obtain ⟨b⟩ := protectedGuard c (pinChart2 seven) (by decide)
  obtain ⟨zero,three⟩ := rawZeroThreeSole c nine
  exact noGuardedFifteenCore c5 c a b (guardSitesDistinct (liftAtThree nine) c a b) zero three

end Petersen9822.DagCut
#print axioms Petersen9822.DagCut.noFifteenCore
