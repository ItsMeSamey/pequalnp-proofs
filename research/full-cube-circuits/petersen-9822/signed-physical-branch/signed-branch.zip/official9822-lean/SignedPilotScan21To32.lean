import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_0_352 : nodeCheck frozen 0 352 [352] = true := by decide +kernel
theorem scan_0_400 : nodeCheck frozen 0 400 [400, 408] = true := by decide +kernel
theorem scan_0_408 : nodeCheck frozen 0 408 [408] = true := by decide +kernel
theorem scan_0_416 : nodeCheck frozen 0 416 [416] = true := by decide +kernel
theorem scan_0_560 : nodeCheck frozen 0 560 [560, 561] = true := by decide +kernel
theorem scan_0_561 : nodeCheck frozen 0 561 [561] = true := by decide +kernel
theorem scan_0_784 : nodeCheck frozen 0 784 [784, 792] = true := by decide +kernel
theorem scan_0_792 : nodeCheck frozen 0 792 [792] = true := by decide +kernel
theorem scan_0_800 : nodeCheck frozen 0 800 [800] = true := by decide +kernel
theorem scan_1_48 : nodeCheck frozen 1 48 [48, 49] = true := by decide +kernel
theorem scan_1_49 : nodeCheck frozen 1 49 [49] = true := by decide +kernel
theorem scan_1_50 : nodeCheck frozen 1 50 [50, 51] = true := by decide +kernel
end Petersen9822
