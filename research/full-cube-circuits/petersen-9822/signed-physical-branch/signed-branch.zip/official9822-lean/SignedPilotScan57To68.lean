import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_1_291 : nodeCheck frozen 1 291 [291, 299, 307, 355, 363, 371, 803, 811] = true := by decide +kernel
theorem scan_1_296 : nodeCheck frozen 1 296 [296] = true := by decide +kernel
theorem scan_1_298 : nodeCheck frozen 1 298 [298, 299, 314, 362, 363, 378, 810, 811] = true := by decide +kernel
theorem scan_1_304 : nodeCheck frozen 1 304 [304, 305, 312, 313] = true := by decide +kernel
theorem scan_1_305 : nodeCheck frozen 1 305 [305, 313] = true := by decide +kernel
theorem scan_1_306 : nodeCheck frozen 1 306 [306, 307, 314, 315, 370, 371, 378, 379, 818, 819, 826, 827] = true := by decide +kernel
theorem scan_1_307 : nodeCheck frozen 1 307 [307, 315, 371, 379, 819, 827] = true := by decide +kernel
theorem scan_1_312 : nodeCheck frozen 1 312 [312, 313] = true := by decide +kernel
theorem scan_1_313 : nodeCheck frozen 1 313 [313] = true := by decide +kernel
theorem scan_1_314 : nodeCheck frozen 1 314 [314, 315, 378, 379, 826, 827] = true := by decide +kernel
theorem scan_1_315 : nodeCheck frozen 1 315 [315, 379, 827] = true := by decide +kernel
theorem scan_1_336 : nodeCheck frozen 1 336 [336, 344] = true := by decide +kernel
end Petersen9822
