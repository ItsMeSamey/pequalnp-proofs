import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_1_338 : nodeCheck frozen 1 338 [338, 339, 346, 347, 370, 378, 850, 851, 858, 859, 882, 890] = true := by decide +kernel
theorem scan_1_344 : nodeCheck frozen 1 344 [344] = true := by decide +kernel
theorem scan_1_346 : nodeCheck frozen 1 346 [346, 347, 378, 858, 859, 890] = true := by decide +kernel
theorem scan_1_352 : nodeCheck frozen 1 352 [352] = true := by decide +kernel
theorem scan_1_354 : nodeCheck frozen 1 354 [354, 355, 362, 363, 370, 866, 867, 874, 875] = true := by decide +kernel
theorem scan_1_400 : nodeCheck frozen 1 400 [400, 408] = true := by decide +kernel
theorem scan_1_402 : nodeCheck frozen 1 402 [402, 403, 410, 411, 434, 442, 466, 474, 914, 922] = true := by decide +kernel
theorem scan_1_408 : nodeCheck frozen 1 408 [408] = true := by decide +kernel
theorem scan_1_410 : nodeCheck frozen 1 410 [410, 411, 442, 474, 922] = true := by decide +kernel
theorem scan_1_416 : nodeCheck frozen 1 416 [416] = true := by decide +kernel
theorem scan_1_418 : nodeCheck frozen 1 418 [418, 419, 426, 427, 434, 482, 483, 490, 491, 930, 931, 938] = true := by decide +kernel
theorem scan_1_560 : nodeCheck frozen 1 560 [560, 561] = true := by decide +kernel
end Petersen9822
