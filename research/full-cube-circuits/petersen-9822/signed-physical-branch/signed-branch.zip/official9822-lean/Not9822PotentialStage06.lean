import Not9822ProjectedFinish

-- Not9822LayoutFacts
namespace Petersen9822.Potential

def freshIds (count : Fin 5) : List Slot := ([27,28,29,30] : List Slot).take count.val
def layoutSeed (count : Fin 5) : Finset Slot :=
  Finset.univ.filter (fun v => initialKind v ≠ .gate ∧ v ∉ freshIds count)

set_option maxRecDepth 4000 in
theorem layoutFacts : ∀ count : Fin 5,
    (freshIds count).length = count.val ∧ (freshIds count).Nodup ∧
    ((List.ofFn gateSlot) ++ freshIds count).Nodup ∧
    (∀ v : Slot, withAlarms (freshIds count) v = .gate ↔
      v ∈ (List.ofFn gateSlot) ++ freshIds count) ∧
    (∀ v : Slot, withAlarms (freshIds count) v = .fixed → v ∈ layoutSeed count) ∧
    (∀ v ∈ (List.ofFn gateSlot) ++ freshIds count, v ∉ layoutSeed count) ∧
    (∀ v ∈ freshIds count, 25 ≤ v.val ∧ withAlarms (freshIds count) v = .gate) ∧
    (∀ b : Bool, fixedSlot b ∈ layoutSeed count ∧ withAlarms (freshIds count) (fixedSlot b) = .fixed) ∧
    (∀ v ∈ List.ofFn gateSlot, withAlarms (freshIds count) v = .gate ∧ v.val < 25) ∧
    (∀ v : Slot, v.val < 10 → v ∈ layoutSeed count) := by
  intro count
  have casesC : ∀ k : Fin 5, k = 0 ∨ k = 1 ∨ k = 2 ∨ k = 3 ∨ k = 4 := by decide
  rcases casesC count with rfl | rfl | rfl | rfl | rfl <;>
    repeat' apply And.intro
  all_goals decide +kernel

theorem Chrono.outputs {n : Nat} {S T : Finset (Fin n)} {gs : List (Pins n)}
    (schedule : Chrono S gs T) : ∀ g ∈ gs, g.id ∈ T := by
  induction schedule with
  | done => simp
  | step _ _ tail ih =>
    intro g hg
    rcases List.mem_cons.mp hg with rfl | h
    · exact tail.grows (Finset.mem_insert_self _ _)
    · exact ih g h

theorem old_uses_low (gs : List (Pins 32)) (out : Slot)
    (ids : gs.map Pins.id = List.ofFn gateSlot) (lowOut : out.val < 25)
    (back : ∀ g ∈ gs, g.left.val < g.id.val ∧ g.right.val < g.id.val) :
    ∀ v ∈ gs.flatMap pins ++ [out], v.val < 25 := by
  intro v hv
  rcases List.mem_append.mp hv with hg | hx
  · obtain ⟨g,hg,h⟩ := List.mem_flatMap.mp hg
    have hi : g.id ∈ List.ofFn gateSlot := ids ▸ List.mem_map_of_mem (f:=Pins.id) hg
    have bound : ∀ k ∈ List.ofFn gateSlot, k.val < 25 := by decide +kernel
    have hl := back g hg
    have top := bound g.id hi
    simp [pins] at h
    rcases h with rfl | rfl <;> omega
  · have eq : v = out := List.mem_singleton.mp hx
    simpa [eq] using lowOut

theorem face_charge_eq (count : Fin 5) (pick : Slot → Bool) (uses : Slot → Nat)
    (low : ∀ v, 25 ≤ v.val → uses v = 0) :
    (∑ v, if pick v then 0 else charge (withAlarms (freshIds count) v) (uses v)) =
      ∑ v, retainedCharge initialKind C5 pick uses v := by
  apply Finset.sum_congr rfl
  intro v _
  by_cases added : v ∈ freshIds count
  · have high := (layoutFacts count).2.2.2.2.2.2.1 v added
    cases hk : onFace initialKind C5 v <;> simp [withAlarms,retainedCharge,added,hk,low v high.1,charge]
  · simp [withAlarms,retainedCharge,added]

end Petersen9822.Potential

-- Not9822ProjectBudget
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor

theorem project_budget (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) (count : Fin 5) (watch : List Slot) (size : watch.length = count.val)
    (unique : watch.Nodup) (oldWatch : ∀ v ∈ watch, v ∈ List.ofFn gateSlot)
    (default : Slot → Bool) (orig : Slot → Wire Row) (op : Slot → SignedOp)
    (gs : List (Pins 32)) (out : Slot) (ids : gs.map Pins.id = List.ofFn gateSlot)
    (T : Finset Slot) (order : Chrono (layoutSeed count) gs T) (result : out ∈ T)
    (lowOut : out.val < 25) (back : ∀ g ∈ gs, g.left.val < g.id.val ∧ g.right.val < g.id.val)
    (ops : ∀ g ∈ gs, orig g.id = (op g.id).apply (orig g.left) (orig g.right))
    (base : ∀ v ∈ layoutSeed count, Available true ((varsX 313).map observe) (orig v))
    (fixed : ∀ v, withAlarms (freshIds count) v = .fixed → Constant (orig v))
    (literals : ∀ b : Bool, orig (fixedSlot b) = fun _ => b)
    (computes : orig out = observe pentagon)
    (negative : ∀ row, orig out row = false → ∀ v ∈ watch, orig v row = default v) :
    8 ≤ ∑ v, retainedCharge initialKind C5 (fun s => watch.contains s)
      (fun s => (gs.flatMap pins ++ [out]).count s) v := by
  classical
  obtain ⟨freshLen,freshNodup,allIds,types,fixedBase,noClash,freshProp,constantProp,oldProp,_⟩ :=
    layoutFacts count
  let pick := fun v => watch.contains v
  let route := routeToFixed pick default
  let extra := watch.zip (freshIds count)
  have first : extra.map Prod.fst = watch := List.map_fst_zip (by omega)
  have second : extra.map Prod.snd = freshIds count := List.map_snd_zip (by omega)
  have inside (v : Slot) : pick v = true ↔ v ∈ watch := by simp [pick]
  have same (v : Slot) (h : pick v = false) : route v = v := by simp [route,routeToFixed,h]
  have safe (v : Slot) : route v = v ∨ route v ∈ layoutSeed count := by
    cases h : pick v with
    | false => exact Or.inl (same v h)
    | true => exact Or.inr (by simpa [route,routeToFixed,h] using (constantProp (default v)).1)
  have gateInT (v : Slot) (hv : v ∈ watch) : v ∈ T := by
    have hm := oldWatch v hv
    rw [←ids] at hm
    obtain ⟨g,hg,rfl⟩ := List.mem_map.mp hm
    exact order.outputs _ hg
  have selected (v : Slot) (h : pick v = true) :
      withAlarms (freshIds count) v = .gate ∧ v ∈ T :=
    ⟨(oldProp _ (oldWatch _ ((inside _).mp h))).1,gateInT _ ((inside _).mp h)⟩
  have counted (v : Slot) : (extra.map Prod.fst).count v = if pick v then 1 else 0 := by
    rw [first]
    by_cases h : v ∈ watch
    · simp [(inside _).mpr h,List.count_eq_one_of_mem unique h]
    · simp [pick,h,List.count_eq_zero.mpr h]
  have currentIds := monitoredIds gs out route extra
  rw [ids,second] at currentIds
  let newOp := monitorOp op default extra
  have oldOp (g : Pins 32) (hg : g ∈ gs) : newOp g.id = op g.id := by
    apply monitor_op_old
    rw [second]
    intro bad
    have lo := (oldProp _ (ids ▸ List.mem_map_of_mem (f:=Pins.id) hg)).2
    have hi := (freshProp _ bad).1
    omega
  have idUnique : ((monitored gs out route extra).1.map Pins.id).Nodup := currentIds ▸ allIds
  have newUnique : (extra.map Prod.snd).Nodup := second ▸ freshNodup
  obtain ⟨cut,read,step,alarm⟩ := build_control_values orig op newOp gs out _ T order result route extra safe
    (fun e he => gateInT e.1 (first ▸ List.mem_map_of_mem (f:=Prod.fst) he)) idUnique
    (fun g hg => noClash _ (currentIds ▸ List.mem_map_of_mem (f:=Pins.id) hg))
    ops oldOp default (monitor_op_alarm op default extra _ newUnique)
  have low := old_uses_low gs out ids lowOut back
  have cost := controlled_pentagon c5Prior orig cut gs out _ T order result (withAlarms (freshIds count))
    pick default route extra safe same (by
      intro v hv
      have lit := constantProp (default v)
      simp only [route,routeToFixed,hv,if_true]
      exact ⟨lit.2,(read _ lit.1).trans (literals _)⟩)
    counted selected newUnique (by
      intro v hv
      rw [second] at hv
      obtain ⟨hi,gate⟩ := freshProp _ hv
      have no : v ∉ watch := fun mem => Nat.not_lt_of_ge hi (oldProp _ (oldWatch _ mem)).2
      exact ⟨fun mem => Nat.not_lt_of_ge hi (low _ mem),by simp [pick,no],gate⟩)
    idUnique (fun v => by simpa only [currentIds] using types v)
    (fun v h => by rw [read v (fixedBase v h)]; exact fixed v h)
    step alarm (fun v hv => (read v hv).symm)
    (fun v hv => by rw [read v hv]; exact base v hv) computes
    (fun row neg v hp => negative row neg v ((inside v).mp hp))
  rw [face_charge_eq count pick _ (fun v hi => List.count_eq_zero.mpr
    (fun mem => Nat.not_lt_of_ge hi (low _ mem)))] at cost
  exact cost

end Petersen9822.Potential

-- Not9822Roster
namespace Petersen9822.Potential
open Petersen9822.DagCut
open Petersen9822.FirstSite

def slot (n : Nat) : Slot := Fin.ofNat 32 n
theorem slot_val (n : Nat) (h : n < 32) : (slot n).val = n := Nat.mod_eq_of_lt h
@[simp] theorem slot_fin (v : Slot) : slot v.val = v := Fin.ext (slot_val _ v.isLt)

def Gate.toPins (n : Nat) (g : DagCut.Gate) : Pins 32 := ⟨slot n,slot g.left,slot g.right⟩
def pinsAt (d : Indexed) (n : Nat) := Gate.toPins n ((d.get n).getD ⟨0,0,fun _ _ => false⟩)
def body (d : Indexed) := window (pinsAt d) 10 15

theorem window_mem {n : Nat} {f : Nat → Pins n} (s len : Nat) (g : Pins n) :
    g ∈ window f s len ↔ ∃ j, s ≤ j ∧ j < s+len ∧ f j = g := by
  induction len generalizing s with
  | zero => simp [window]; intro x lo hi; omega
  | succ len ih =>
    rw [window,List.mem_cons,ih]
    constructor
    · rintro (eq | ⟨j,lo,hi,eq⟩)
      · exact ⟨s,by omega,by omega,eq.symm⟩
      · exact ⟨j,by omega,by omega,eq⟩
    · rintro ⟨j,lo,hi,eq⟩
      by_cases h : j = s
      · subst j; exact Or.inl eq.symm
      · exact Or.inr ⟨j,by omega,by omega,eq⟩

theorem body_ids (d : Indexed) : (body d).map Pins.id = List.ofFn gateSlot := by
  have generic (s len : Nat) : (window (pinsAt d) s len).map Pins.id = (List.range' s len).map slot := by
    induction len generalizing s with
    | zero => rfl
    | succ len ih =>
      change slot s :: (window (pinsAt d) (s+1) len).map Pins.id =
        slot s :: (List.range' (s+1) len).map slot
      rw [ih]
  exact (generic 10 15).trans (by decide +kernel)

theorem body_back (d : Indexed) (valid : Fifteen d) :
    ∀ g ∈ body d, g.left.val < g.id.val ∧ g.right.val < g.id.val := by
  intro g hg
  obtain ⟨j,lo,hi,rfl⟩ := (window_mem 10 15 g).mp hg
  obtain ⟨w,hw⟩ := valid.present j lo hi
  obtain ⟨l,r⟩ := d.back j w hw
  simp [pinsAt,hw,Gate.toPins,slot_val _ (show j<32 by omega),
    slot_val _ (show w.left<32 by omega),slot_val _ (show w.right<32 by omega),l,r]

theorem body_order (d : Indexed) (valid : Fifteen d) (count : Fin 5) :
    ∃ T, Chrono (layoutSeed count) (body d) T ∧ ∀ v : Slot, v.val < 25 → v ∈ T := by
  apply window_plan _ 10 15
  · intro v hv
    obtain ⟨_,_,_,_,_,_,_,_,_,seed⟩ := layoutFacts count
    exact seed v hv
  · intro j lo hi
    have mem := (window_mem (f:=pinsAt d) 10 15 (pinsAt d j)).mpr ⟨j,lo,hi,rfl⟩
    have id : (pinsAt d j).id.val = j := slot_val j (by omega)
    exact ⟨id,by simpa only [id] using body_back d valid _ mem⟩

theorem body_pin (d : Indexed) (valid : Fifteen d) {v j : Nat} (e : d.edge v j) :
    ∃ g ∈ body d, g.id = slot j ∧ slot v ∈ pins g := by
  obtain ⟨g,h,side⟩ := e
  obtain ⟨lo,hi⟩ := valid.extent j g h
  refine ⟨pinsAt d j,(window_mem _ _ _).mpr ⟨j,lo,hi,rfl⟩,rfl,?_⟩
  rcases side with eq | eq <;> simp [pinsAt,h,Gate.toPins,pins,eq]

theorem body_source_exists (d : Indexed) (valid : Fifteen d) {out v : Nat}
    (path : ∃ xs, Path d.edge out v xs) : slot v ∈ (body d).flatMap pins ++ [slot out] := by
  obtain ⟨xs,p⟩ := path
  cases p with
  | stop => simp
  | step _ edge _ =>
    obtain ⟨g,hg,_,hp⟩ := body_pin d valid edge
    exact List.mem_append_left _ (List.mem_flatMap.mpr ⟨g,hg,hp⟩)

end Petersen9822.Potential
