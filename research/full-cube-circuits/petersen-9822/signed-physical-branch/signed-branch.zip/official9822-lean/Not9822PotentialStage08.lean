import Not9822PotentialStage07
import Not9822PotentialStage08A

-- Not9822LimitedMonitors
namespace Petersen9822.Potential
open Petersen9822.DagCut
open Petersen9822.FirstSite
open PEqualNP.Outside.L_meta_9825.Engine

theorem at_most_three_monitors (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) (d : Indexed) (valid : Fifteen d) (out owner : Nat) (bound : out < 25)
    (which : owner ∈ ([1,2] : List Nat)) (ops : Nat → SignedOp)
    (signed : ∀ n g, d.get n = some g → ∀ a b, g.op a b = (ops n).bit a b)
    (compute : ∀ row, edgeHit row = wireValue d out row)
    (sink : ∀ a b, d.edge a b → a ≠ out)
    (live : ∀ v, 10 ≤ v → v < 25 → ∃ xs, Path d.edge out v xs)
    (count : Fin 5) (watch : List Slot) (size : watch.length = count.val)
    (unique : watch.Nodup) (old : ∀ v ∈ watch, v ∈ List.ofFn gateSlot)
    (isFork : ∀ v ∈ watch, fork d v.val = true) (default : Slot → Bool)
    (stable : ∀ row : Row, edgeHit (projectRow owner row) = false → ∀ v ∈ watch,
      wireValue d v.val (projectRow owner row) = default v) :
    watch.length ≤ 3 := by
  have cap := original_charge d valid out bound live
  have floor := monitored_floor c5Prior d valid out owner bound which ops signed compute count watch size unique old default stable
  have limit := controlled_at_most_three initialKind C5 (fun v => watch.contains v) (originalUses d out)
    (Nat.le_of_eq cap) floor outside watch.toFinset outside_card (by
      intro v hv
      obtain ⟨kind,cold⟩ := outside_roles v hv
      have h : ∀ x ∈ outside, x.val < 10 := by decide +kernel
      let a : Fin 10 := ⟨v.val,h _ hv⟩
      exact ⟨kind,cold,raw_live_use d valid out a sink compute⟩) (by
      intro v hv
      have hm := List.mem_toFinset.mp hv
      have h2 := fork_uses d valid out v.val (isFork _ hm)
      exact ⟨(ids_match_kind v).mpr (old v hm),by simpa using hm,by simpa only [slot_fin] using h2⟩)
  simpa only [List.toFinset_card_of_nodup unique] using limit

theorem no_four_defaults (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) (d : Indexed) (valid : Fifteen d) (out i j pi pj qi qj : Nat) (bound : out < 25)
    (ij : (i,j) ∈ ([(1,2),(2,1)] : List (Nat × Nat))) (ops : Nat → SignedOp)
    (signed : ∀ n g, d.get n = some g → ∀ a b, g.op a b = (ops n).bit a b)
    (compute : ∀ row, edgeHit row = wireValue d out row)
    (sink : ∀ a b, d.edge a b → a ≠ out)
    (live : ∀ v, 10 ≤ v → v < 25 → ∃ xs, Path d.edge out v xs)
    (late : OwnerDefaults d out i pi qi) (early : OwnerDefaults d out j pj qj)
    (pBefore : ¬ (d.tree pj).term.uses i) (qBefore : ¬ (d.tree qj).term.uses i)
    (distinct : [pi,qi,pj,qj].Nodup)
    (forks : ∀ n ∈ [pi,qi,pj,qj], 10 ≤ n ∧ n < 25 ∧ fork d n = true) : False := by
  classical
  let watch := [slot pi,slot qi,slot pj,slot qj]
  let default := fun v : Slot => if v.val = pi then late.pass else if v.val = qi then late.pol false
    else if v.val = pj then early.pass else early.pol true
  have range (v : Nat) (hv : v ∈ [pi,qi,pj,qj]) : (slot v).val = v :=
    slot_val _ (Nat.lt_trans (forks v hv).2.1 (by decide))
  have ip := range pi (by simp)
  have iq := range qi (by simp)
  have jp := range pj (by simp)
  have jq := range qj (by simp)
  have vals (v : Slot) (hv : v ∈ watch) : v.val ∈ [pi,qi,pj,qj] := by
    simp only [watch,List.mem_cons,List.not_mem_nil,or_false] at hv
    rcases hv with rfl | rfl | rfl | rfl <;> simp [ip,iq,jp,jq]
  have uniq : watch.Nodup := by
    have inj (a b : Nat) (ha : a ∈ [pi,qi,pj,qj]) (hb : b ∈ [pi,qi,pj,qj]) (eq : slot a = slot b) : a = b := by
      simpa only [range a ha,range b hb] using congrArg Fin.val eq
    change (List.map slot [pi,qi,pj,qj]).Nodup
    exact distinct.map_on (fun a ha b hb eq => inj a b ha hb eq)
  have which : j ∈ ([1,2] : List Nat) := by
    have options : (i,j) = (1,2) ∨ (i,j) = (2,1) := by simpa only [List.mem_cons,List.not_mem_nil,or_false] using ij
    rcases options with h | h
    · have h2 : j = 2 := congrArg Prod.snd h; simp [h2]
    · have h1 : j = 1 := congrArg Prod.snd h; simp [h1]
  have le := at_most_three_monitors c5Prior d valid out j bound which ops signed compute sink live 4 watch rfl uniq
    (fun v hv => (ids_match_kind _).mp (by
      obtain ⟨lo,hi,_⟩ := forks _ (vals v hv)
      simp [initialKind,hi,Nat.not_lt_of_ge lo]))
    (fun v hv => (forks _ (vals v hv)).2.2) default (by
      intro row neg v hv
      let a : Fin 1024 := ⟨row.val &&& 313,Nat.lt_of_le_of_lt Nat.and_le_left row.isLt⟩
      have subA : sub a.val 313 = true := by simp [a,sub,Nat.and_assoc]
      obtain ⟨g₁,q₁,g₂,q₂⟩ := fourDefaults ij late early pBefore qBefore a subA neg
      have ne_qi_pi : qi ≠ pi := by intro eq; subst qi; simp at distinct
      have ne_pj_pi : pj ≠ pi := by intro eq; subst pj; simp at distinct
      have ne_pj_qi : pj ≠ qi := by intro eq; subst pj; simp at distinct
      have ne_qj_pi : qj ≠ pi := by intro eq; subst qj; simp at distinct
      have ne_qj_qi : qj ≠ qi := by intro eq; subst qj; simp at distinct
      have ne_qj_pj : qj ≠ pj := by intro eq; subst qj; simp at distinct
      simp only [watch,List.mem_cons,List.not_mem_nil,or_false] at hv
      rcases hv with rfl | rfl | rfl | rfl <;> simp_all [default,projectRow,a])
  change 4 ≤ 3 at le
  omega

end Petersen9822.Potential
