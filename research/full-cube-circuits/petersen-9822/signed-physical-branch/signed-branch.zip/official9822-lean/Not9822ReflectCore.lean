import Not9822ReflectTruth
namespace Petersen9822.DagCut
open Petersen9822.Potential
open Petersen9822.FirstSite

theorem mirror_read {d : Indexed} {valid : Fifteen d} {n : Nat} {g : Gate}
    (h : (reflected d valid).get n = some g) : ∃ k, d.get n = some k ∧ mirrorGate k = g := by
  change (d.get n).map mirrorGate = some g at h
  cases hk : d.get n with
  | none => simp [hk] at h
  | some k => exact ⟨k,rfl,by simpa [hk] using h⟩

def reflectCore {d : Indexed} {out : Nat} (c : FifteenCore d out) :
    FifteenCore (reflected d c.diagram) out where
  diagram := {
    raw := fun v hv => by change (d.get v).map mirrorGate = none; rw [c.diagram.raw v hv]; rfl
    present := fun v lo hi => by
      obtain ⟨g,hg⟩ := c.diagram.present v lo hi
      exact ⟨mirrorGate g,by change (d.get v).map _ = _; rw [hg]; rfl⟩
    extent := fun n g h => by
      obtain ⟨k,hk,_⟩ := mirror_read h
      exact c.diagram.extent n k hk }
  lowerOut := c.lowerOut
  upperOut := c.upperOut
  finalWire := by
    intro a b e eq
    subst a
    apply c.finalWire out (mirror b) _ rfl
    apply (mirror_edge d c.diagram out (mirror b)).mp
    simpa [mirror_high c.lowerOut] using e
  live := by
    intro v lo hi
    obtain ⟨xs,p⟩ := c.live v lo hi
    exact ⟨_,by simpa [mirror_high c.lowerOut,mirror_high lo] using mirror_path c.diagram p⟩
  properSockets := by
    intro n g h
    obtain ⟨k,hk,rfl⟩ := mirror_read h
    exact fun eq => c.properSockets n k hk (mirror_inj.mp eq)
  op := c.op
  signed := by
    intro n g h
    obtain ⟨k,hk,rfl⟩ := mirror_read h
    exact c.signed n k hk
  computes := by
    intro row
    have eval := mirror_wire c.diagram out c.upperOut row
    rw [mirror_high c.lowerOut] at eval
    exact (mirror_row_edge row).symm.trans ((c.computes _).trans eval.symm)

theorem mirror_private {d : Indexed} (valid : Fifteen d) {cut i : Nat} (ci : 10 ≤ cut)
    (ri : i < 10) {block : Bool} (s : PrivateSockets d cut (2^i) block) :
    PrivateSockets (reflected d valid) cut (2^(mirror i)) block := by
  have mi := mirror_lt (Nat.le_refl 10) ri
  refine ⟨by simp [Nat.testBit_two_pow,show mirror i ≠ cut by omega],?_,?_,?_⟩
  · intro v hv
    have eq : mirror i = v := by simpa [Nat.testBit_two_pow] using hv
    subst v
    change (d.get (mirror i)).map _ = none
    rw [valid.raw _ mi]; rfl
  · intro n g h hv
    obtain ⟨k,hk,rfl⟩ := mirror_read h
    have eq : mirror i = mirror k.left := by simpa [mirrorGate,Nat.testBit_two_pow] using hv
    have e := mirror_inj.mp eq
    obtain ⟨right,constant⟩ := s.left n k hk (by simp [Nat.testBit_two_pow,e])
    exact ⟨by simp [mirrorGate,right,mirror_high ci],constant⟩
  · intro n g h hv
    obtain ⟨k,hk,rfl⟩ := mirror_read h
    have eq : mirror i = mirror k.right := by simpa [mirrorGate,Nat.testBit_two_pow] using hv
    have e := mirror_inj.mp eq
    obtain ⟨left,constant⟩ := s.right n k hk (by simp [Nat.testBit_two_pow,e])
    exact ⟨by simp [mirrorGate,left,mirror_high ci],constant⟩

end Petersen9822.DagCut
