import Not9822PotentialStage01
import Trial

-- Not9822PentagonFace
namespace Research.Signed9822.Cofactor
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822

def pentagon : Sig := movedWord (fixRows 710 0) target

theorem pentagonPinOne : movedWord (fixRows 708 2) target = pentagon := by decide +kernel
theorem pentagonPinTwo : movedWord (fixRows 706 4) target = pentagon := by decide +kernel

theorem pentagon_floor (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) : Lower true (varsX 313) pentagon 7 := by
  let ms := ([32,33,67,117,118,152] : List Nat).map swapRows
  have ok : checkMap ms (varsX 313) pentagon (varsX 668) (graphGoal 668) = true := by decide +kernel
  exact lower_map ok (proper_of _ (by decide +kernel)) (by decide +kernel) (by decide +kernel)
    (proper_of _ (by decide +kernel)) c5Prior

end Research.Signed9822.Cofactor

-- Not9822SemanticReach
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine

def signed {R : Type} (neg : Bool) (w : Wire R) : Wire R := if neg then inv w else w

private theorem signAvail {R : Type} {bank : List (Wire R)} {w : Wire R}
    (s : Bool) (h : Available true bank w) : Available true bank (signed s w) := by
  cases s
  · exact h
  · exact avail_inv rfl h

private theorem signConst {R : Type} {w : Wire R} (s : Bool) (h : Constant w) :
    Constant (signed s w) := by
  cases s
  · exact h
  · exact inv_constant h

structure Realizes {n : Nat} {R : Type} (w : Fin n → Wire R) (g : Pins n) : Prop where
  signedOp : ∃ op l r o, w g.id = signed o (combine op (signed l (w g.left)) (signed r (w g.right)))

inductive Chrono {n : Nat} : Finset (Fin n) → List (Pins n) → Finset (Fin n) → Prop where
  | done (S) : Chrono S [] S
  | step {S T g gs} : g.left ∈ S → g.right ∈ S → Chrono (insert g.id S) gs T → Chrono S (g :: gs) T

theorem realized_parent {n : Nat} {R : Type} (w : Fin n → Wire R) (g : Pins n)
    (eqn : Realizes w g) (active : Fin n → Bool)
    (cold : ∀ v, active v = false ↔ Constant (w v)) (hot : active g.id = true) :
    active g.left = true ∨ active g.right = true := by
  cases hl : active g.left <;> cases hr : active g.right <;> try simp
  obtain ⟨op,l,r,o,eq⟩ := eqn.signedOp
  have hc := signConst o (both_constant op (signConst l ((cold _).mp hl)) (signConst r ((cold _).mp hr)))
  have no := (cold g.id).mpr (by rw [eq]; exact hc)
  simp_all

theorem realize_program {n : Nat} {R : Type} (w : Fin n → Wire R) (active : Fin n → Bool)
    (cold : ∀ v, active v = false ↔ Constant (w v)) (roots : List (Wire R))
    {S T : Finset (Fin n)} {gs : List (Pins n)} (schedule : Chrono S gs T)
    (valid : ∀ g ∈ gs, Realizes w g)
    (p : Nat) (bank : List (Wire R)) (run : Reach true roots p bank)
    (available : ∀ v ∈ S, Available true bank (w v)) :
    ∃ b, Reach true roots (p + gs.countP (paidAt active)) b ∧ ∀ v ∈ T, Available true b (w v) := by
  induction schedule generalizing p bank with
  | done => exact ⟨bank,run,available⟩
  | @step S T g gs hl hr tail ih =>
    obtain ⟨op,l,r,o,eq⟩ := (valid g List.mem_cons_self).signedOp
    let a := signed l (w g.left)
    let b := signed r (w g.right)
    have ha := signAvail l (available g.left hl)
    have hb := signAvail r (available g.right hr)
    have nextValid := fun z (hz : z ∈ gs) => valid z (List.mem_cons_of_mem _ hz)
    cases hpaid : paidAt active g with
    | true =>
      let z := combine op a b
      have step : Reach true roots (p+1) (z :: bank) := Reach.two op run ha hb
      have supplies : ∀ v ∈ insert g.id S, Available true (z :: bank) (w v) := by
        intro v hv
        rcases Finset.mem_insert.mp hv with rfl | hv
        · rw [eq]; exact signAvail o (Or.inl List.mem_cons_self)
        · exact available_cons _ (available v hv)
      obtain ⟨endBank,good,haveW⟩ := ih nextValid (p+1) (z::bank) step supplies
      exact ⟨endBank,by simpa [List.countP_cons,hpaid,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using good,haveW⟩
    | false =>
      have free : Available true bank (w g.id) := by
        cases h : active g.id with
        | false => exact Or.inr (Or.inl ((cold _).mp h))
        | true =>
          have const : Constant a ∨ Constant b := by
            cases hL : active g.left with
            | false => exact Or.inl (signConst l ((cold _).mp hL))
            | true =>
              have hR : active g.right = false := by simpa [paidAt,h,hL] using hpaid
              exact Or.inr (signConst r ((cold _).mp hR))
          rw [eq]; exact signAvail o (from_constant op const ha hb)
      have supplies : ∀ v ∈ insert g.id S, Available true bank (w v) := by
        intro v hv
        rcases Finset.mem_insert.mp hv with rfl | hv
        · exact free
        · exact available v hv
      simpa [List.countP_cons,hpaid] using ih nextValid p bank run supplies

end Petersen9822.Potential

-- Not9822KeptCount
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine

theorem counts_length {n : Nat} (xs : List (Fin n)) : (∑ i, xs.count i) = xs.length := by
  classical
  induction xs with
  | nil => simp
  | cons x xs ih =>
    simp only [List.count_cons,List.length_cons]
    simp_rw [show ∀ i : Fin n, (if x == i then 1 else 0) = (if i = x then 1 else 0) by
      intro i; by_cases eq : i=x
      · subst i; simp
      · simp [eq,Ne.symm eq]]
    rw [Finset.sum_add_distrib,ih]
    simp

def pins {n : Nat} (g : Pins n) := [g.left,g.right]

private theorem retained_sub {n : Nat} (active : Fin n → Bool) (g : Pins n) :
    (retained active g).Sublist (pins g) := by
  cases h : active g.id <;> simp [retained,pins,h]

private theorem all_sub {n : Nat} (active : Fin n → Bool) (gs : List (Pins n)) :
    (gs.flatMap (retained active)).Sublist (gs.flatMap pins) := by
  induction gs with
  | nil => exact .slnil
  | cons g gs ih => exact (retained_sub active g).append ih

private theorem retained_hot {n : Nat} {active : Fin n → Bool} {g : Pins n} {v : Fin n}
    (hv : v ∈ retained active g) : active v = true := by
  cases h : active g.id
  · simp [retained,h] at hv
  · exact (List.mem_filter.mp (by simpa [retained,h] using hv : v ∈ [g.left,g.right].filter active)).2

theorem pin_debit {n : Nat} (kind : Fin n → Kind) (active : Fin n → Bool)
    (gs : List (Pins n)) (out : Fin n) (hot : active out = true)
    (ids : (gs.map Pins.id).Nodup)
    (gates : ∀ v, kind v = .gate ↔ v ∈ gs.map Pins.id)
    (fixedCold : ∀ v, kind v = .fixed → active v = false)
    (parent : ∀ g ∈ gs, active g.id = true → active g.left = true ∨ active g.right = true) :
    gs.countP (paidAt active) + 1 ≤ total kind (fun v => (gs.flatMap pins ++ [out]).count v) := by
  classical
  let kept := gs.flatMap (retained active) ++ [out]
  have cold (v : Fin n) (h : active v = false) : kept.count v = 0 := by
    apply List.count_eq_zero.mpr
    intro hv
    rcases List.mem_append.mp hv with old | last
    · obtain ⟨g,_,hmem⟩ := List.mem_flatMap.mp old
      have := retained_hot hmem
      simp_all
    · simp only [List.mem_singleton] at last
      subst v; simp_all
  have bound (v : Fin n) := List.Sublist.count_le v ((all_sub active gs).append_right [out])
  apply semantic_debit kind active _ (fun v => kept.count v) _ bound cold (fun v h => cold v (fixedCold v h))
  have count_eq (v : Fin n) : ((gs.map Pins.id).filter active).count v =
      (if active v = true ∧ kind v = .gate then 1 else 0) := by
    by_cases hv : active v = true ∧ kind v = .gate
    · have mem := List.mem_filter.mpr ⟨(gates v).mp hv.2,hv.1⟩
      simp [hv,List.count_eq_one_of_mem (ids.filter active) mem]
    · have no : v ∉ (gs.map Pins.id).filter active := by
        intro hm
        obtain ⟨a,b⟩ := List.mem_filter.mp hm
        exact hv ⟨b,(gates v).mpr a⟩
      simp [hv,List.count_eq_zero.mpr no]
  rw [counts_length,←Finset.sum_congr rfl (fun v _ => count_eq v),counts_length]
  simpa only [kept,←List.countP_eq_length_filter,List.countP_map,Function.comp_def] using socket_balance gs active parent out

end Petersen9822.Potential

-- Not9822PentagonDebit
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor

theorem pentagon_debit (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) {n : Nat} (w : Fin n → Wire Row) (gs : List (Pins n))
    (kind : Fin n → Kind) (out : Fin n)
    (S T : Finset (Fin n)) (plan : Chrono S gs T) (result : out ∈ T)
    (valid : ∀ g ∈ gs, Realizes w g)
    (source : ∀ v ∈ S, Available true ((varsX 313).map observe) (w v))
    (computesPentagon : w out = observe pentagon)
    (ids : (gs.map Pins.id).Nodup)
    (kinds : ∀ v, kind v = .gate ↔ v ∈ gs.map Pins.id)
    (fixed : ∀ v, kind v = .fixed → Constant (w v)) :
    8 ≤ total kind (fun v => (gs.flatMap pins ++ [out]).count v) := by
  classical
  let active := fun v => decide (¬ Constant (w v))
  have cold (v : Fin n) : active v = false ↔ Constant (w v) := by simp [active]
  have outHot : active out = true := by
    simp only [active,decide_eq_true_eq,computesPentagon]
    exact observe_proper (proper_of _ (by decide +kernel : properB pentagon = true))
  have deb := pin_debit kind active gs out outHot ids kinds
    (fun v h => (cold v).mpr (fixed v h))
    (fun g hg => realized_parent w g (valid g hg) active cold)
  obtain ⟨bank,run,seen⟩ := realize_program w active cold ((varsX 313).map observe)
    plan valid 0 _ Reach.start source
  have available := seen out result
  rw [computesPentagon] at available
  have floor := pentagon_floor c5Prior _ _ run available
  omega

end Petersen9822.Potential
