import SignedCensusBundle9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_50_ : ¬ Placement [] 50 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 50 0) ≠ false) h
theorem node_51_ : ¬ Placement [] 51 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 51 0) ≠ false) h
theorem node_274_ : ¬ Placement [] 274 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 274 0) ≠ false) h
theorem node_282_ : ¬ Placement [] 282 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 282 0) ≠ false) h
theorem node_290_ : ¬ Placement [] 290 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 290 0) ≠ false) h
theorem node_306_ : ¬ Placement [] 306 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 306 0) ≠ false) h
theorem node_307_ : ¬ Placement [] 307 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 307 0) ≠ false) h
theorem node_314_ : ¬ Placement [] 314 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 314 0) ≠ false) h
theorem node_315_ : ¬ Placement [] 315 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 315 0) ≠ false) h
theorem node_370_ : ¬ Placement [] 370 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 370 0) ≠ false) h
theorem node_371_ : ¬ Placement [] 371 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 371 0) ≠ false) h
theorem node_378_ : ¬ Placement [] 378 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 378 0) ≠ false) h
theorem node_379_ : ¬ Placement [] 379 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 379 0) ≠ false) h
theorem node_818_ : ¬ Placement [] 818 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 818 0) ≠ false) h
theorem node_819_ : ¬ Placement [] 819 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 819 0) ≠ false) h
theorem node_826_ : ¬ Placement [] 826 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 826 0) ≠ false) h
theorem node_827_ : ¬ Placement [] 827 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 827 0) ≠ false) h
theorem node_58_ : ¬ Placement [] 58 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 58 0) ≠ false) h
theorem node_59_ : ¬ Placement [] 59 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 59 0) ≠ false) h
theorem node_114_ : ¬ Placement [] 114 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 114 0) ≠ false) h
theorem node_178_ : ¬ Placement [] 178 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 178 0) ≠ false) h
theorem node_562_ : ¬ Placement [] 562 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 562 0) ≠ false) h
theorem node_115_ : ¬ Placement [] 115 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 115 0) ≠ false) h
theorem node_179_ : ¬ Placement [] 179 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 179 0) ≠ false) h
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_563_ : ¬ Placement [] 563 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 563 0) ≠ false) h
theorem node_122_ : ¬ Placement [] 122 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 122 0) ≠ false) h
theorem node_123_ : ¬ Placement [] 123 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 123 0) ≠ false) h
theorem node_570_ : ¬ Placement [] 570 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 570 0) ≠ false) h
theorem node_571_ : ¬ Placement [] 571 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 571 0) ≠ false) h
theorem node_626_ : ¬ Placement [] 626 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 626 0) ≠ false) h
theorem node_627_ : ¬ Placement [] 627 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 627 0) ≠ false) h
theorem node_634_ : ¬ Placement [] 634 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 634 0) ≠ false) h
theorem node_635_ : ¬ Placement [] 635 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 635 0) ≠ false) h
theorem node_882_ : ¬ Placement [] 882 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 882 0) ≠ false) h
theorem node_883_ : ¬ Placement [] 883 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 883 0) ≠ false) h
theorem node_186_ : ¬ Placement [] 186 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 186 0) ≠ false) h
theorem node_187_ : ¬ Placement [] 187 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 187 0) ≠ false) h
theorem node_242_ : ¬ Placement [] 242 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 242 0) ≠ false) h
theorem node_243_ : ¬ Placement [] 243 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 243 0) ≠ false) h
theorem node_434_ : ¬ Placement [] 434 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 434 0) ≠ false) h
theorem node_435_ : ¬ Placement [] 435 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 435 0) ≠ false) h
theorem node_690_ : ¬ Placement [] 690 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 690 0) ≠ false) h
theorem node_691_ : ¬ Placement [] 691 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 691 0) ≠ false) h
theorem node_698_ : ¬ Placement [] 698 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 698 0) ≠ false) h
theorem node_699_ : ¬ Placement [] 699 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 699 0) ≠ false) h
theorem node_275_ : ¬ Placement [] 275 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 275 0) ≠ false) h
theorem node_283_ : ¬ Placement [] 283 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 283 0) ≠ false) h
theorem node_338_ : ¬ Placement [] 338 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 338 0) ≠ false) h
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_346_ : ¬ Placement [] 346 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 346 0) ≠ false) h
theorem node_402_ : ¬ Placement [] 402 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 402 0) ≠ false) h
theorem node_786_ : ¬ Placement [] 786 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 786 0) ≠ false) h
theorem node_410_ : ¬ Placement [] 410 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 410 0) ≠ false) h
theorem node_794_ : ¬ Placement [] 794 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 794 0) ≠ false) h
theorem node_339_ : ¬ Placement [] 339 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 339 0) ≠ false) h
theorem node_347_ : ¬ Placement [] 347 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 347 0) ≠ false) h
theorem node_787_ : ¬ Placement [] 787 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 787 0) ≠ false) h
theorem node_795_ : ¬ Placement [] 795 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 795 0) ≠ false) h
theorem node_850_ : ¬ Placement [] 850 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 850 0) ≠ false) h
theorem node_851_ : ¬ Placement [] 851 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 851 0) ≠ false) h
theorem node_858_ : ¬ Placement [] 858 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 858 0) ≠ false) h
theorem node_859_ : ¬ Placement [] 859 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 859 0) ≠ false) h
theorem node_890_ : ¬ Placement [] 890 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 890 0) ≠ false) h
theorem node_403_ : ¬ Placement [] 403 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 403 0) ≠ false) h
theorem node_411_ : ¬ Placement [] 411 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 411 0) ≠ false) h
theorem node_442_ : ¬ Placement [] 442 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 442 0) ≠ false) h
theorem node_466_ : ¬ Placement [] 466 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 466 0) ≠ false) h
theorem node_474_ : ¬ Placement [] 474 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 474 0) ≠ false) h
theorem node_914_ : ¬ Placement [] 914 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 914 0) ≠ false) h
theorem node_922_ : ¬ Placement [] 922 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 922 0) ≠ false) h
theorem node_291_ : ¬ Placement [] 291 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 291 0) ≠ false) h
theorem node_298_ : ¬ Placement [] 298 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 298 0) ≠ false) h
theorem node_354_ : ¬ Placement [] 354 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 354 0) ≠ false) h
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_418_ : ¬ Placement [] 418 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 418 0) ≠ false) h
theorem node_802_ : ¬ Placement [] 802 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 802 0) ≠ false) h
theorem node_299_ : ¬ Placement [] 299 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 299 0) ≠ false) h
theorem node_355_ : ¬ Placement [] 355 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 355 0) ≠ false) h
theorem node_363_ : ¬ Placement [] 363 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 363 0) ≠ false) h
theorem node_803_ : ¬ Placement [] 803 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 803 0) ≠ false) h
theorem node_811_ : ¬ Placement [] 811 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 811 0) ≠ false) h
theorem node_362_ : ¬ Placement [] 362 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 362 0) ≠ false) h
theorem node_810_ : ¬ Placement [] 810 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 810 0) ≠ false) h
theorem node_866_ : ¬ Placement [] 866 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 866 0) ≠ false) h
theorem node_867_ : ¬ Placement [] 867 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 867 0) ≠ false) h
theorem node_874_ : ¬ Placement [] 874 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 874 0) ≠ false) h
theorem node_875_ : ¬ Placement [] 875 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 875 0) ≠ false) h
theorem node_419_ : ¬ Placement [] 419 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 419 0) ≠ false) h
theorem node_426_ : ¬ Placement [] 426 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 426 0) ≠ false) h
theorem node_427_ : ¬ Placement [] 427 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 427 0) ≠ false) h
theorem node_482_ : ¬ Placement [] 482 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 482 0) ≠ false) h
theorem node_483_ : ¬ Placement [] 483 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 483 0) ≠ false) h
theorem node_490_ : ¬ Placement [] 490 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 490 0) ≠ false) h
theorem node_491_ : ¬ Placement [] 491 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 491 0) ≠ false) h
theorem node_930_ : ¬ Placement [] 930 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 930 0) ≠ false) h
theorem node_931_ : ¬ Placement [] 931 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 931 0) ≠ false) h
theorem node_938_ : ¬ Placement [] 938 := by intro p; cases p with | nil h => exact (by decide : edgeHit (later 938 0) ≠ false) h
end Petersen9822
