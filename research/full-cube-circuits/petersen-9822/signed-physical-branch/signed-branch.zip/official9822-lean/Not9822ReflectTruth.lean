import Not9822ReflectIndexed
import CompactRows9822
namespace Petersen9822.DagCut
open Petersen9822.Potential
open Petersen9822.FirstSite
open PEqualNP.Outside.L_meta_9822.Compact

def mirrorRow (row : Nat) := pack (fun i => row.testBit (mirror i))

theorem mirror_row_edge (row : Nat) : edgeHit (mirrorRow row) = edgeHit row := by
  rw [rowEdge,rowEdge]
  unfold PEqualNP.Outside.L_meta_9822.Sectors.edge
  simp only [mirrorRow,pack_bit]
  change (row.testBit 2 && row.testBit 1 || (row.testBit 0 && row.testBit 4) ||
    (row.testBit 3 && row.testBit 4) || (row.testBit 3 && row.testBit 8) ||
    (row.testBit 2 && row.testBit 7) || (row.testBit 1 && row.testBit 6) ||
    (row.testBit 0 && row.testBit 5) || (row.testBit 4 && row.testBit 9) ||
    (row.testBit 8 && row.testBit 6) || (row.testBit 6 && row.testBit 9) ||
    (row.testBit 7 && row.testBit 9) || (row.testBit 7 && row.testBit 5) ||
    (row.testBit 8 && row.testBit 5)) = _
  ac_rfl

theorem mirror_wire {d : Indexed} (valid : Fifteen d) (n : Nat) (bound : n < 25) (row : Nat) :
    wireValue (reflected d valid) (mirror n) row = wireValue d n (mirrorRow row) := by
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    cases hg : d.get n with
    | none =>
      have raw : n < 10 := by
        by_contra! hi
        obtain ⟨g,eq⟩ := valid.present n hi bound
        simp [hg] at eq
      have get := mirror_get d valid n
      rw [hg] at get
      simp only [wireValue,(reflected d valid).tree_none get,d.tree_none hg,Tree.term,Term.eval,
        mirrorRow,pack_bit,raw,decide_true,Bool.true_and]
    | some g =>
      have get := mirror_get d valid n
      rw [hg] at get
      have back := d.back n g hg
      have l := ih g.left back.1 (Nat.lt_trans back.1 bound)
      have r := ih g.right back.2 (Nat.lt_trans back.2 bound)
      unfold wireValue at *
      rw [(reflected d valid).tree_some get,d.tree_some hg]
      exact congrArg₂ g.op l r

theorem mirror_first (d : Indexed) (valid : Fifteen d) (out v : Nat) (xs : List Nat) :
    first (fork (reflected d valid)) (mirror out) (mirror v) (xs.map mirror) =
      mirror (first (fork d) out v xs) := by
  induction xs generalizing v with
  | nil => cases h : fork d v <;> simp [first,mirror_fork,h]
  | cons a xs ih => cases h : fork d v <;> simp [first,mirror_fork,h,ih]

theorem mirror_assigned {d : Indexed} (valid : Fifteen d) {out v : Nat}
    (p : ∃ xs, Path d.edge out v xs) :
    assigned (reflected d valid) (mirror out) (fork (reflected d valid)) (mirror v) =
      mirror (assigned d out (fork d) v) := by
  obtain ⟨xs,h⟩ := p
  have hp := mirror_path valid h
  rw [assigned_live ⟨_,hp⟩,assigned_live ⟨_,h⟩,owner_eq (fork_unique _) _ hp,
    owner_eq (fork_unique _) _ h,mirror_first]

end Petersen9822.DagCut
