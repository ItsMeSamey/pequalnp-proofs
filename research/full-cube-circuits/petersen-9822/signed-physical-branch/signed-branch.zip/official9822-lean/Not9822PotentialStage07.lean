import Not9822PotentialStage06
import Not9822Bundle07Lca

-- Not9822RosterCost
namespace Petersen9822.Potential
open Petersen9822.DagCut
open Petersen9822.FirstSite

def originalUses (d : Indexed) (out : Nat) (v : Slot) :=
  ((body d).flatMap pins ++ [slot out]).count v

private theorem twice {n : Nat} (gs : List (Pins n)) (v : Fin n) {a b : Pins n}
    (ha : a ∈ gs) (hb : b ∈ gs) (ne : a ≠ b) (pa : v ∈ pins a) (pb : v ∈ pins b) :
    2 ≤ (gs.flatMap pins).count v := by
  have one (xs : List (Pins n)) (g : Pins n) (mem : g ∈ xs) (read : v ∈ pins g) :
      0 < (xs.flatMap pins).count v := List.count_pos_iff.mpr (List.mem_flatMap.mpr ⟨g,mem,read⟩)
  induction gs with
  | nil => simp at ha
  | cons g gs ih =>
    simp only [List.flatMap_cons,List.count_append]
    rcases List.mem_cons.mp ha with ea | ma <;> rcases List.mem_cons.mp hb with eb | mb
    · exact False.elim (ne (ea.trans eb.symm))
    · subst g; have := List.count_pos_iff.mpr pa; have := one gs b mb pb; omega
    · subst g; have := List.count_pos_iff.mpr pb; have := one gs a ma pa; omega
    · have := ih ma mb; omega

theorem fork_uses (d : Indexed) (valid : Fifteen d) (out v : Nat) (hot : fork d v = true) :
    2 ≤ originalUses d out (slot v) := by
  classical
  obtain ⟨b,c,eb,ec,diff⟩ := of_decide_eq_true hot
  obtain ⟨g,hg,gb,pa⟩ := body_pin d valid eb
  obtain ⟨h,hh,hc,pb⟩ := body_pin d valid ec
  have word (i : Nat) (hi : d.edge v i) : i < 32 := by
    obtain ⟨op,ok,_⟩ := hi
    have := (valid.extent _ _ ok).2
    omega
  have distinct : g ≠ h := by
    intro eq
    have ids := gb.symm.trans ((congrArg Pins.id eq).trans hc)
    have q := congrArg Fin.val ids
    exact diff (by simpa only [slot_val _ (word _ eb),slot_val _ (word _ ec)] using q)
  have h2 := twice (body d) (slot v) hg hh distinct pa pb
  simp only [originalUses,List.count_append]
  omega

theorem raw_live_use (d : Indexed) (valid : Fifteen d) (out : Nat) (a : Fin 10)
    (sink : ∀ i j, d.edge i j → i ≠ out)
    (compute : ∀ row, edgeHit row = wireValue d out row) : 1 ≤ originalUses d out (rawSlot a) := by
  have h := body_source_exists d valid (d.live_raw out a sink compute)
  have eq : slot a.val = rawSlot a := Fin.ext (slot_val _ (by omega))
  rw [eq] at h
  exact List.count_pos_iff.mpr h

theorem original_charge (d : Indexed) (valid : Fifteen d) (out : Nat) (outBound : out < 25)
    (live : ∀ v, 10 ≤ v → v < 25 → ∃ xs, Path d.edge out v xs) :
    total initialKind (originalUses d out) = 16 := by
  have lowOut : (slot out).val < 25 := by rw [slot_val out (by omega)]; exact outBound
  have low := old_uses_low (body d) (slot out) (body_ids d) lowOut (body_back d valid)
  apply live_count initialKind (originalUses d out) initial_gate_count
  · intro v hf
    have high : 25 ≤ v.val := by
      by_contra h
      by_cases hr : v.val < 10 <;> simp [initialKind,hr,show v.val < 25 by omega] at hf
    exact List.count_eq_zero.mpr (fun hm => Nat.not_lt_of_ge high (low _ hm))
  · intro v hg
    have bounds : ∀ s : Slot, initialKind s = .gate → 10 ≤ s.val ∧ s.val < 25 := by decide +kernel
    obtain ⟨lo,hi⟩ := bounds v hg
    have z := body_source_exists d valid (live _ lo hi)
    rw [slot_fin] at z
    exact List.count_pos_iff.mpr z
  · rw [show (∑ v, originalUses d out v) =
        ((body d).flatMap pins ++ [slot out]).length from counts_length _]
    have count (gs : List (Pins 32)) : (gs.flatMap pins).length = 2*gs.length := by
      induction gs with
      | nil => rfl
      | cons g gs ih => simp [pins,ih]; omega
    simp [count,body,window_length]

end Petersen9822.Potential

-- Not9822MonitoredFloor
namespace Petersen9822.Potential
open Petersen9822.DagCut
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor

theorem op_eval (o : SignedOp) (a b : Wire Row) (r : Row) :
    o.apply a b r = o.bit (a r) (b r) := by
  cases o with
  | mk op l rneg neg => cases op <;> cases l <;> cases rneg <;> cases neg <;> rfl

theorem original_ops (d : Indexed) (valid : Fifteen d) (owner : Nat) (ops : Nat → SignedOp)
    (signed : ∀ n g, d.get n = some g → ∀ a b, g.op a b = (ops n).bit a b) :
    ∀ g ∈ body d, originalTable d owner g.id =
      (ops g.id.val).apply (originalTable d owner g.left) (originalTable d owner g.right) := by
  intro g hg
  obtain ⟨j,lo,hi,rfl⟩ := (window_mem 10 15 g).mp hg
  obtain ⟨op,h⟩ := valid.present _ lo hi
  obtain ⟨hl,hr⟩ := d.back _ _ h
  have idEq : (pinsAt d j).id = slot j := rfl
  have lEq : (pinsAt d j).left = slot op.left := by simp [pinsAt,Gate.toPins,h]
  have rEq : (pinsAt d j).right = slot op.right := by simp [pinsAt,Gate.toPins,h]
  have table (k : Nat) (hk : k < 25) (r : Row) :
      originalTable d owner (slot k) r = wireValue d k (projectRow owner r) := by
    simp [originalTable,slot_val k (by omega),hk]
  rw [idEq,lEq,rEq,slot_val j (by omega)]
  funext row
  rw [op_eval,table j (by omega),table op.left (by omega),table op.right (by omega)]
  simp only [wireValue,d.tree_some h,Tree.term,Term.eval,signed _ _ h]

private theorem projected_fixed (d : Indexed) (valid : Fifteen d) (owner : Nat) (count : Fin 5) (v : Slot)
    (h : withAlarms (freshIds count) v = .fixed) : Constant (originalTable d owner v) := by
  by_cases low : v.val < 25
  · have off : ∀ k : Fin 5, ∀ t : Slot, t.val < 25 → withAlarms (freshIds k) t = .fixed →
        t.val < 10 ∧ (313 : Nat).testBit t.val = false := by decide +kernel
    obtain ⟨raw,off⟩ := off count v low h
    have eq : d.tree v.val = .raw v.val := d.tree_none (valid.raw _ raw)
    exact ⟨decide (owner = v.val),by funext row; simp [originalTable,low,wireValue,eq,Tree.term,
      Term.eval,projectRow,Nat.testBit_two_pow,off]⟩
  · exact ⟨decide (v.val = 26),by simp [originalTable,low]⟩

theorem monitored_floor (c5Prior : PEqualNP.Outside.L_meta_9825.Engine.Lower true (PEqualNP.Outside.L_meta_9825.Engine.varsX 668) (PEqualNP.Outside.L_meta_9825.Engine.graphGoal 668) 7) (d : Indexed) (valid : Fifteen d) (out owner : Nat) (bound : out < 25)
    (which : owner ∈ ([1,2] : List Nat)) (ops : Nat → SignedOp)
    (signed : ∀ n g, d.get n = some g → ∀ a b, g.op a b = (ops n).bit a b)
    (compute : ∀ row, edgeHit row = wireValue d out row)
    (count : Fin 5) (watch : List Slot) (size : watch.length = count.val)
    (unique : watch.Nodup) (old : ∀ v ∈ watch, v ∈ List.ofFn gateSlot)
    (default : Slot → Bool)
    (stable : ∀ row : Row, edgeHit (projectRow owner row) = false → ∀ v ∈ watch,
      wireValue d v.val (projectRow owner row) = default v) :
    8 ≤ ∑ v, retainedCharge initialKind C5 (fun s => watch.contains s) (originalUses d out) v := by
  obtain ⟨T,plan,complete⟩ := body_order d valid count
  have vo : (slot out).val = out := slot_val _ (by omega)
  have lo : (slot out).val < 25 := by simpa [vo] using bound
  have computesPentagon : originalTable d owner (slot out) = observe pentagon := by
    funext row
    simp [originalTable,vo,bound,←compute,projected_output owner which row]
  refine project_budget c5Prior count watch size unique old default (originalTable d owner) (fun v => ops v.val)
    (body d) (slot out) (body_ids d) T plan (complete _ lo) lo (body_back d valid)
    (original_ops d valid owner ops signed) ?_ (projected_fixed d valid owner count)
    (table_fixed d owner) computesPentagon ?_
  · intro v hv
    by_cases low : v.val < 25
    · have initial : ∀ k : Fin 5, ∀ t : Slot, t ∈ layoutSeed k → t.val < 25 → t ∈ seed := by decide +kernel
      exact table_raws d owner which valid.raw v (initial count v hv low)
    · exact Or.inr (Or.inl ⟨decide (v.val = 26),by simp [originalTable,low]⟩)
  · intro row neg v hv
    have hn : edgeHit (projectRow owner row) = false := by
      simpa only [originalTable,vo,bound,if_true,←compute] using neg
    have oldBound := (layoutFacts count).2.2.2.2.2.2.2.2.1 v (old _ hv)
    simpa [originalTable,oldBound.2] using stable row hn v hv

end Petersen9822.Potential
