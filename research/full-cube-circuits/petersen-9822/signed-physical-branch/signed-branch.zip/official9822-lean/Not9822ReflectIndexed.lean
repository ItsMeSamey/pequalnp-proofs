import SignedPhysicalCore9822
import Not9822Bundle05Sites
namespace Petersen9822.DagCut
open Petersen9822.FirstSite
open Petersen9822.Potential

def mirror : Nat → Nat
  | 0 => 3 | 1 => 2 | 2 => 1 | 3 => 0 | 5 => 8 | 6 => 7 | 7 => 6 | 8 => 5 | n => n

theorem mirror_high {n : Nat} (h : 10 ≤ n) : mirror n = n := by
  unfold mirror; split <;> omega

@[simp] theorem mirror_mirror (n : Nat) : mirror (mirror n) = n := by
  by_cases h : n < 10
  · exact (by decide : ∀ i : Fin 10, mirror (mirror i.val) = i.val) ⟨n,h⟩
  · simp [mirror_high (Nat.le_of_not_gt h)]

theorem mirror_inj {u v : Nat} : mirror u = mirror v ↔ u = v := by
  constructor
  · intro h; simpa using congrArg mirror h
  · rintro rfl; rfl

theorem mirror_lt {v n : Nat} (hn : 10 ≤ n) (hv : v < n) : mirror v < n := by
  by_cases h : v < 10
  · exact Nat.lt_of_lt_of_le ((by decide : ∀ i : Fin 10, mirror i.val < 10) ⟨v,h⟩) hn
  · simpa [mirror_high (Nat.le_of_not_gt h)] using hv

def mirrorGate (g : Gate) : Gate := ⟨mirror g.left,mirror g.right,g.op⟩

def reflected (d : Indexed) (valid : Fifteen d) : Indexed where
  get n := (d.get n).map mirrorGate
  back := by
    intro n g ok
    cases h : d.get n with
    | none => simp [h] at ok
    | some k =>
      simp only [h,Option.map_some,Option.some.injEq] at ok
      subst g
      have low := (valid.extent n k h).1
      exact ⟨mirror_lt low (d.back n k h).1,mirror_lt low (d.back n k h).2⟩

theorem mirror_get (d : Indexed) (valid : Fifteen d) (n : Nat) :
    (reflected d valid).get (mirror n) = (d.get n).map mirrorGate := by
  change (d.get (mirror n)).map _ = _
  by_cases h : 10 ≤ n
  · rw [mirror_high h]
  · have lo : n < 10 := by omega
    rw [valid.raw _ (mirror_lt (Nat.le_refl 10) lo),valid.raw _ lo]

theorem mirror_edge (d : Indexed) (valid : Fifteen d) (a b : Nat) :
    (reflected d valid).edge (mirror a) (mirror b) ↔ d.edge a b := by
  unfold Indexed.edge; rw [mirror_get]
  cases h : d.get b with
  | none => simp
  | some k => simp [mirrorGate,mirror_inj]

theorem mirror_fork (d : Indexed) (valid : Fifteen d) (v : Nat) :
    fork (reflected d valid) (mirror v) = fork d v := by
  classical
  unfold fork
  apply Bool.eq_iff_iff.mpr
  simp only [decide_eq_true_eq]
  constructor
  · rintro ⟨a,b,ha,hb,ne⟩
    exact ⟨mirror a,mirror b,(mirror_edge d valid v _).mp (by simpa using ha),
      (mirror_edge d valid v _).mp (by simpa using hb),fun eq => ne (mirror_inj.mp eq)⟩
  · rintro ⟨a,b,ha,hb,ne⟩
    exact ⟨mirror a,mirror b,(mirror_edge d valid v a).mpr ha,(mirror_edge d valid v b).mpr hb,
      fun eq => ne (mirror_inj.mp eq)⟩

theorem mirror_path {d : Indexed} (valid : Fifteen d) {out v xs} (p : Path d.edge out v xs) :
    Path (reflected d valid).edge (mirror out) (mirror v) (xs.map mirror) := by
  induction p with
  | stop => exact .stop
  | step hn e _ ih => exact .step (fun h => hn (mirror_inj.mp h)) ((mirror_edge _ _ _ _).mpr e) ih

end Petersen9822.DagCut
