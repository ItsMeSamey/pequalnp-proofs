import Not9822PotentialStage07
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine

theorem unaryAvailable {R : Type} (f : Bool → Bool) {x : Wire R} {bank : List (Wire R)}
    (ready : Available true bank x) : Available true bank (fun r => f (x r)) := by
  cases hf : f false <;> cases ht : f true
  · exact Or.inr (Or.inl ⟨false,by funext r; cases x r <;> assumption⟩)
  · have eq : (fun r => f (x r)) = x := by funext r; cases x r <;> assumption
    rwa [eq]
  · have eq : (fun r => f (x r)) = inv x := by funext r; unfold inv; cases x r <;> assumption
    rw [eq]; exact avail_inv rfl ready
  · exact Or.inr (Or.inl ⟨true,by funext r; cases x r <;> assumption⟩)

private theorem signedReady {R : Type} (sg : Bool) {x : Wire R} {bank : List (Wire R)}
    (ready : Available true bank x) : Available true bank (signed sg x) := by
  cases sg
  · exact ready
  · exact avail_inv rfl ready

theorem paidSignedStep {R : Type} (op : SignedOp) {roots bank : List (Wire R)} {x y : Wire R}
    {k} (run : Reach true roots k bank) (hx : Available true bank x) (hy : Available true bank y) :
    ∃ b, Reach true roots (k+1) b ∧ Available true b (op.apply x y) ∧
      ∀ v, Available true bank v → Available true b v := by
  let l := signed op.leftNeg x
  let r := signed op.rightNeg y
  let z := combine op.isOr l r
  refine ⟨z::bank,Reach.two op.isOr run (signedReady _ hx) (signedReady _ hy),?_,fun _ h => available_cons _ h⟩
  exact signedReady op.outNeg (Or.inl List.mem_cons_self : Available true (z::bank) z)

theorem saveTwo {R : Type} (w : Nat → Wire R) (roots : List (Wire R)) (A B : Nat)
    (aLo : 10 ≤ A) (bLo : 10 ≤ B) (aHi : A < 25) (bHi : B < 25) (ne : A ≠ B)
    (input : ∀ i, i < 10 → Available true roots (w i))
    (free : ∀ n, n = A ∨ n = B → ∃ j < n, ∃ f : Bool → Bool, w n = fun r => f (w j r))
    (paid : ∀ n, 10 ≤ n → n < 25 → n ≠ A → n ≠ B →
      ∃ j < n, ∃ k < n, ∃ op : SignedOp, w n = op.apply (w j) (w k)) :
    ∃ k b, k ≤ 13 ∧ Reach true roots k b ∧ ∀ i, i < 25 → Available true b (w i) := by
  have progress (len : Nat) (hi : len ≤ 15) :
      ∃ k b, k+(if A < 10+len then 1 else 0)+(if B < 10+len then 1 else 0) ≤ len ∧
        Reach true roots k b ∧ ∀ i, i < 10+len → Available true b (w i) := by
    induction len with
    | zero => exact ⟨0,roots,by simp [Nat.not_lt_of_ge aLo,Nat.not_lt_of_ge bLo],Reach.start,input⟩
    | succ t ih =>
      obtain ⟨k,b,count,run,seen⟩ := ih (by omega)
      let n := 10+t
      by_cases special : n = A ∨ n = B
      · obtain ⟨j,early,f,eq⟩ := free n special
        refine ⟨k,b,?_,run,?_⟩
        · dsimp [n] at special
          split_ifs at * <;> omega
        · intro i lim
          by_cases last : i = n
          · rw [last,eq]; exact unaryAvailable f (seen j early)
          · exact seen i (by dsimp [n] at last; omega)
      · obtain ⟨j,hj,l,hl,op,eq⟩ := paid n (by dsimp [n]; omega) (by dsimp [n]; omega)
          (fun e => special (Or.inl e)) (fun e => special (Or.inr e))
        obtain ⟨next,rNext,ready,grows⟩ := paidSignedStep op run (seen j hj) (seen l hl)
        refine ⟨k+1,next,?_,rNext,?_⟩
        · dsimp [n] at special
          split_ifs at * <;> omega
        · intro i lim
          by_cases last : i = n
          · simpa only [last,eq] using ready
          · exact grows _ (seen i (by dsimp [n] at last; omega))
  obtain ⟨k,b,count,run,seen⟩ := progress 15 (by decide)
  exact ⟨k,b,by simp [aHi,bHi] at count; omega,run,seen⟩

end Petersen9822.Potential
