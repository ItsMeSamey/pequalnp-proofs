import Not9822PotentialStage08A
import SignedPhysicalGuards9822
import Not9822Bundle09Conclusion

-- Not9822ForkOwners
namespace Petersen9822.DagCut
open Petersen9822.Potential
open Petersen9822.FirstSite

theorem signedSocketOf (o : Potential.SignedOp) (f : Bool → Bool → Bool)
    (eq : ∀ a b, f a b = o.bit a b) : Nonempty (Socket f) ∧ Nonempty (Socket (fun x y => f y x)) := by
  have first : f = signedOp (!o.isOr) o.leftNeg o.rightNeg o.outNeg := by
    funext a b; rw [eq]; cases o with
    | mk k l r z => cases k <;> rfl
  have second : (fun x y => f y x) = signedOp (!o.isOr) o.rightNeg o.leftNeg o.outNeg := by
    funext a b; rw [eq]; cases o with
    | mk k l r z => cases k <;> cases l <;> cases r <;> cases z <;> cases a <;> cases b <;> rfl
  constructor
  · rw [first]; exact ⟨signedSocket _ _ _ _⟩
  · rw [second]; exact ⟨signedSocket _ _ _ _⟩

theorem FifteenCore.signedGate {d out} (c : FifteenCore d out) (n : Nat) : (d.tree n).signed :=
  d.tree_signed (fun i g hg => signedSocketOf (c.op i) g.op (c.signed i g hg)) n

theorem RealGuard.beforeOwner {d out i} (c : FifteenCore d out) (g : RealGuard d out i) (h : i < 10) :
    g.site < assigned d out (fork d) i :=
  guard_before_owner g.sockets Nat.testBit_two_pow_self g.soleRaw (by have := c.lowerOut; omega) g.beforeOut

noncomputable def RealGuard.defaults {d out i} (c : FifteenCore d out) (g : RealGuard d out i) (h : i < 10) :
    OwnerDefaults d out i g.site (assigned d out (fork d) i) := by
  let live := d.live_raw out ⟨i,h⟩ c.finalWire c.computes
  have guardLive := c.live g.site g.internal (Nat.lt_trans g.beforeOut c.upperOut)
  have absent := no_raw_before c.finalWire (fork_unique d) g.shared guardLive (g.beforeOwner c h)
  exact ownerDefaults g.sockets (by simp [Nat.testBit_two_pow,show i ≠ out by have := c.lowerOut; omega])
    absent c.finalWire (fork_unique d) c.properSockets live rfl (c.signedGate _) c.computes

theorem RealGuard.excludesNeighbor {d out i} (c : FifteenCore d out) (g : RealGuard d out i)
    (h : i < 10) (v p : Nat) (chart : (v,i,p) ∈ neighborCases) :
    assigned d out (fork d) v ≠ g.site := by
  exact neighborGuardUnreachable chart c.finalWire (fork_unique d) c.properSockets g.shared
    (c.live _ g.internal (Nat.lt_trans g.beforeOut c.upperOut)) g.beforeOut (c.signedGate _) g.soleRaw
    (by have := c.lowerOut; omega) g.sockets c.computes

theorem internal_owner {d out v} (c : FifteenCore d out) (h : v < 10)
    (ne : assigned d out (fork d) v ≠ out) :
    fork d (assigned d out (fork d) v) = true ∧ assigned d out (fork d) v < 25 := by
  classical
  let live := d.live_raw out ⟨v,h⟩ c.finalWire c.computes
  have eq := assigned_live (shared := fork d) live
  have cases' := first_is_site (shared := fork d) live.choose_spec
  change owner d.edge out (fork d) v live = out ∨ fork d (owner d.edge out (fork d) v live) = true at cases'
  rw [←eq] at cases'
  have hot := cases'.resolve_left ne
  obtain ⟨a,_,e,_,_⟩ := of_decide_eq_true hot
  have lt := d.chrono e
  obtain ⟨g,hg,_⟩ := e
  exact ⟨hot,Nat.lt_trans lt (c.diagram.extent a g hg).2⟩

end Petersen9822.DagCut

-- Not9822ForkRoster

namespace Petersen9822.Potential

theorem forkRoster {α : Type} [DecidableEq α] (S : Finset α) (a b q : α)
    (ha : a ∈ S) (hb : b ∈ S) (hq : q ∈ S)
    (ab : a ≠ b) (aq : a ≠ q) (bq : b ≠ q) (cap : S.card ≤ 4) :
    S = {a,b,q} ∨ ∃ w ∈ S, w ≠ a ∧ w ≠ b ∧ w ≠ q ∧ S = {a,b,q,w} := by
  classical
  let T : Finset α := {a,b,q}
  have sub : T ⊆ S := by
    intro x hx
    simp only [T,Finset.mem_insert,Finset.mem_singleton] at hx
    rcases hx with rfl | rfl | rfl <;> assumption
  by_cases eq : S = T
  · exact Or.inl eq
  · have extra : ∃ w ∈ S, w ∉ T := by
      by_contra! h
      exact eq (Finset.Subset.antisymm h sub)
    obtain ⟨w,hw,off⟩ := extra
    have wa : w ≠ a := fun h => off (by simp [T,h])
    have wb : w ≠ b := fun h => off (by simp [T,h])
    have wq : w ≠ q := fun h => off (by simp [T,h])
    let U : Finset α := {a,b,q,w}
    have subU : U ⊆ S := by
      intro x hx
      simp only [U,Finset.mem_insert,Finset.mem_singleton] at hx
      rcases hx with rfl | rfl | rfl | rfl <;> assumption
    have size : U.card = 4 := by simp [U,ab,aq,bq,Ne.symm wa,Ne.symm wb,Ne.symm wq]
    exact Or.inr ⟨w,hw,wa,wb,wq,(Finset.eq_of_subset_of_card_le subU (by omega)).symm⟩

end Petersen9822.Potential

-- Not9822OrderedPlacement
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

theorem placementFromNames {d : Indexed} {out : Nat} (c : FifteenCore d out)
    (a : RealGuard d out 1) (b : RealGuard d out 2) (sites : List (Nat × Nat))
    (ord : Ordered sites) (early : ∀ e ∈ sites, e.1 < out)
    (lower : ∀ e ∈ sites, 10 ≤ e.1) (hot : ∀ e ∈ sites, fork d e.1 = true)
    (cover : ∀ k, 10 ≤ k → k ≠ out → fork d k = true → ∃ e ∈ sites, e.1 = k)
    (labelA : ∀ e ∈ sites, e.2 = 0 → e.1 = a.site)
    (labelB : ∀ e ∈ sites, e.2 = 1 → e.1 = b.site)
    (labelQ : ∀ e ∈ sites, assigned d out (fork d) 1 = e.1 ↔ e.2 = 2)
    (late : assigned d out (fork d) 2 = out) :
    Placement (sites.map Prod.snd) (pack (fork d)) := by
  apply guardedPlacement d out (fork d) sites ord early c.lowerOut c.finalWire c.computes
    (fun _ _ ⟨g,h,_⟩ => (c.diagram.extent _ g h).1) c.properSockets
    (fun n g h => signedSocketOf _ _ (c.signed n g h))
    (fun _ _ h => h) a.soleRaw b.soleRaw cover
    (fun e he => ⟨hot e he,c.live _ (lower e he) (Nat.lt_trans (early e he) c.upperOut)⟩)
    labelQ late
  intro e he nonzero
  have options : e.2 = 0 ∨ e.2 = 1 := by
    by_contra! h
    exact nonzero (by simp [ownerBit,show ¬e.2 < 2 by omega])
  rcases options with h | h
  · rw [labelA e he h,h]; exact ⟨a.block,a.sockets⟩
  · rw [labelB e he h,h]; exact ⟨b.block,b.sockets⟩

end Petersen9822.DagCut

