import Not9822PotentialStage04

-- Not9822AlarmLabels
namespace Petersen9822.Potential

theorem alarmIds {n : Nat} (prev : Fin n) (extra : List (Fin n × Fin n)) :
    (alarmGates prev extra).1.map Pins.id = extra.map Prod.snd := by
  induction extra generalizing prev with
  | nil => rfl
  | cons e es ih => cases e; simp [alarmGates,ih]

theorem monitoredIds {n : Nat} (gs : List (Pins n)) (out : Fin n) (route : Fin n → Fin n)
    (extra : List (Fin n × Fin n)) : (monitored gs out route extra).1.map Pins.id =
      gs.map Pins.id ++ extra.map Prod.snd := by
  simp [monitored,List.map_map,routed,alarmIds]

theorem alarmLabel {n : Nat} (prev : Fin n) (extra : List (Fin n × Fin n)) (g : Pins n)
    (hg : g ∈ (alarmGates prev extra).1) : (g.right,g.id) ∈ extra := by
  induction extra generalizing prev with
  | nil => simp [alarmGates] at hg
  | cons e es ih =>
    obtain ⟨w,i⟩ := e
    rcases List.mem_cons.mp hg with eq | tail
    · subst g
      exact List.mem_cons_self
    · exact List.mem_cons_of_mem _ (ih i tail)

private theorem uniqueLabel {n : Nat} (es : List (Fin n × Fin n)) (unique : (es.map Prod.snd).Nodup)
    {a b i : Fin n} (ha : (a,i) ∈ es) (hb : (b,i) ∈ es) : a = b := by
  induction es with
  | nil => simp at ha
  | cons e es ih =>
    obtain ⟨head,tail⟩ := List.nodup_cons.mp unique
    rcases List.mem_cons.mp ha with h | h <;> rcases List.mem_cons.mp hb with k | k
    · exact congrArg Prod.fst (h.trans k.symm)
    · rw [←h] at head
      exact False.elim (head (show i ∈ es.map Prod.snd from List.mem_map.mpr ⟨(b,i),k,rfl⟩))
    · rw [←k] at head
      exact False.elim (head (show i ∈ es.map Prod.snd from List.mem_map.mpr ⟨(a,i),h,rfl⟩))
    · exact ih tail h k

noncomputable def monitorOp {n : Nat} (oldOp : Fin n → SignedOp) (default : Fin n → Bool)
    (extra : List (Fin n × Fin n)) (v : Fin n) : SignedOp := by
  classical
  exact if h : ∃ a, (a,v) ∈ extra then ⟨true,false,default h.choose,false⟩ else oldOp v

theorem monitor_op_old {n : Nat} (oldOp : Fin n → SignedOp) (default : Fin n → Bool)
    (extra : List (Fin n × Fin n)) (v : Fin n) (fresh : v ∉ extra.map Prod.snd) :
    monitorOp oldOp default extra v = oldOp v := by
  have no : ¬∃ a, (a,v) ∈ extra := by rintro ⟨a,h⟩; exact fresh (List.mem_map_of_mem (f:=Prod.snd) h)
  simp [monitorOp,no]

theorem monitor_op_alarm {n : Nat} (oldOp : Fin n → SignedOp) (default : Fin n → Bool)
    (extra : List (Fin n × Fin n)) (prev : Fin n) (unique : (extra.map Prod.snd).Nodup) :
    ∀ g ∈ (alarmGates prev extra).1, monitorOp oldOp default extra g.id =
      ⟨true,false,default g.right,false⟩ := by
  intro g hg
  have z := alarmLabel prev extra g hg
  have yes : ∃ a, (a,g.id) ∈ extra := ⟨_,z⟩
  have eq := uniqueLabel extra unique yes.choose_spec z
  simp [monitorOp,yes,eq]

end Petersen9822.Potential

