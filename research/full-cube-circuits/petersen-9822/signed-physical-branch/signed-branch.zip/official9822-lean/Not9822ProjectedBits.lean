import Not9822ProjectedPair4
import Not9822PotentialStage05
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor
open Petersen9822.DagCut

def projectRow (owner : Nat) (r : Row) := (r.val &&& 313) ||| 2^owner

theorem input_bits (i : Fin 10) (r : Row) : observe (inputs.getD i.val zero) r = r.val.testBit i.val := by
  have casesI : ∀ k : Fin 10, k.val = 0 ∨ k.val = 1 ∨ k.val = 2 ∨ k.val = 3 ∨ k.val = 4 ∨ k.val = 5 ∨ k.val = 6 ∨ k.val = 7 ∨ k.val = 8 ∨ k.val = 9 := by decide
  rcases casesI i with h | h | h | h | h | h | h | h | h | h
  · rw [h]; exact fixedInput0 r
  · rw [h]; exact fixedInput1 r
  · rw [h]; exact fixedInput2 r
  · rw [h]; exact fixedInput3 r
  · rw [h]; exact fixedInput4 r
  · rw [h]; exact fixedInput5 r
  · rw [h]; exact fixedInput6 r
  · rw [h]; exact fixedInput7 r
  · rw [h]; exact fixedInput8 r
  · rw [h]; exact fixedInput9 r

theorem c5_pool : ∀ i : Fin 10, (313 : Nat).testBit i.val = true →
    inputs.getD i.val zero ∈ varsX 313 := by decide +kernel

def pentagonBits : Nat := 0xffffffffffaaff00ffffffffffaaff00ffffffffffaaff00ffffffffffaaff00ffaaaaaaffaa0000ffaaaaaaffaa0000ffaaaaaaffaa0000ffaaaaaaffaa0000ffffffffffaaff00ffffffffffaaff00ffffffffffaaff00ffffffffffaaff00ffaaaaaaffaa0000ffaaaaaaffaa0000ffaaaaaaffaa0000ffaaaaaaffaa0000

set_option maxRecDepth 4000 in
set_option exponentiation.threshold 1024 in
theorem observeC5 (r : Row) : observe pentagon r = pentagonBits.testBit r.val := by
  have eq : pentagon = (0xffffffffffaaff00ffffffffffaaff00ffffffffffaaff00ffffffffffaaff00ffaaaaaaffaa0000ffaaaaaaffaa0000ffaaaaaaffaa0000ffaaaaaaffaa0000ffffffffffaaff00ffffffffffaaff00ffffffffffaaff00ffffffffffaaff00ffaaaaaaffaa0000ffaaaaaaffaa0000ffaaaaaaffaa0000ffaaaaaaffaa0000 : Sig) := by decide +kernel
  rw [eq]; rfl

end Petersen9822.Potential
