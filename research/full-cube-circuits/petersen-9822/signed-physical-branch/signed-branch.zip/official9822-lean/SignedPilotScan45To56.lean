import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_1_179 : nodeCheck frozen 1 179 [179, 187, 243, 435, 691, 699] = true := by decide +kernel
theorem scan_1_272 : nodeCheck frozen 1 272 [272, 280] = true := by decide +kernel
theorem scan_1_273 : nodeCheck frozen 1 273 [273, 281] = true := by decide +kernel
theorem scan_1_274 : nodeCheck frozen 1 274 [274, 282] = true := by decide +kernel
theorem scan_1_275 : nodeCheck frozen 1 275 [275, 283, 307, 315, 339, 347, 371, 379, 787, 795, 819, 827] = true := by decide +kernel
theorem scan_1_280 : nodeCheck frozen 1 280 [280] = true := by decide +kernel
theorem scan_1_281 : nodeCheck frozen 1 281 [281] = true := by decide +kernel
theorem scan_1_282 : nodeCheck frozen 1 282 [282] = true := by decide +kernel
theorem scan_1_283 : nodeCheck frozen 1 283 [283, 315, 347, 379, 795, 827] = true := by decide +kernel
theorem scan_1_288 : nodeCheck frozen 1 288 [288] = true := by decide +kernel
theorem scan_1_289 : nodeCheck frozen 1 289 [289] = true := by decide +kernel
theorem scan_1_290 : nodeCheck frozen 1 290 [290] = true := by decide +kernel
end Petersen9822
