import SignedScans
import SignedLogicalLayer0

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_48_2 : ¬ Placement [2] 48 := by
  apply node_sound (lookup := frozen) (next := [50])
  · exact scan_2_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_50_
theorem node_49_2 : ¬ Placement [2] 49 := by
  apply node_sound (lookup := frozen) (next := [51])
  · exact scan_2_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_51_
theorem node_50_1 : ¬ Placement [1] 50 := by
  apply node_sound (lookup := frozen) (next := [50, 51])
  · exact scan_1_50
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_50_
    · exact node_51_
theorem node_51_1 : ¬ Placement [1] 51 := by
  apply node_sound (lookup := frozen) (next := [51])
  · exact scan_1_51
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_51_
theorem node_272_2 : ¬ Placement [2] 272 := by
  apply node_sound (lookup := frozen) (next := [274])
  · exact scan_2_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_274_
theorem node_280_2 : ¬ Placement [2] 280 := by
  apply node_sound (lookup := frozen) (next := [282])
  · exact scan_2_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_282_
theorem node_274_1 : ¬ Placement [1] 274 := by
  apply node_sound (lookup := frozen) (next := [274, 282])
  · exact scan_1_274
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_274_
    · exact node_282_
theorem node_282_1 : ¬ Placement [1] 282 := by
  apply node_sound (lookup := frozen) (next := [282])
  · exact scan_1_282
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_282_
theorem node_288_2 : ¬ Placement [2] 288 := by
  apply node_sound (lookup := frozen) (next := [290])
  · exact scan_2_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_290_
theorem node_290_1 : ¬ Placement [1] 290 := by
  apply node_sound (lookup := frozen) (next := [290])
  · exact scan_1_290
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_290_
theorem node_304_2 : ¬ Placement [2] 304 := by
  apply node_sound (lookup := frozen) (next := [306])
  · exact scan_2_304
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_306_
theorem node_305_2 : ¬ Placement [2] 305 := by
  apply node_sound (lookup := frozen) (next := [307])
  · exact scan_2_305
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_307_
theorem node_312_2 : ¬ Placement [2] 312 := by
  apply node_sound (lookup := frozen) (next := [314])
  · exact scan_2_312
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_314_
theorem node_313_2 : ¬ Placement [2] 313 := by
  apply node_sound (lookup := frozen) (next := [315])
  · exact scan_2_313
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_315_
theorem node_306_1 : ¬ Placement [1] 306 := by
  apply node_sound (lookup := frozen) (next := [306, 307, 314, 315, 370, 371, 378, 379, 818, 819, 826, 827])
  · exact scan_1_306
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_306_
    · exact node_307_
    · exact node_314_
    · exact node_315_
    · exact node_370_
    · exact node_371_
    · exact node_378_
    · exact node_379_
    · exact node_818_
    · exact node_819_
    · exact node_826_
    · exact node_827_
theorem node_307_1 : ¬ Placement [1] 307 := by
  apply node_sound (lookup := frozen) (next := [307, 315, 371, 379, 819, 827])
  · exact scan_1_307
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_307_
    · exact node_315_
    · exact node_371_
    · exact node_379_
    · exact node_819_
    · exact node_827_
theorem node_314_1 : ¬ Placement [1] 314 := by
  apply node_sound (lookup := frozen) (next := [314, 315, 378, 379, 826, 827])
  · exact scan_1_314
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_314_
    · exact node_315_
    · exact node_378_
    · exact node_379_
    · exact node_826_
    · exact node_827_
theorem node_315_1 : ¬ Placement [1] 315 := by
  apply node_sound (lookup := frozen) (next := [315, 379, 827])
  · exact scan_1_315
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl
    · exact node_315_
    · exact node_379_
    · exact node_827_
theorem node_50_3 : ¬ Placement [3] 50 := by
  apply node_sound (lookup := frozen) (next := [50, 51, 58, 59, 114, 178, 306, 562])
  · exact scan_3_50
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_50_
    · exact node_51_
    · exact node_58_
    · exact node_59_
    · exact node_114_
    · exact node_178_
    · exact node_306_
    · exact node_562_
theorem node_51_3 : ¬ Placement [3] 51 := by
  apply node_sound (lookup := frozen) (next := [51, 59, 115, 179, 307, 563])
  · exact scan_3_51
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_51_
    · exact node_59_
    · exact node_115_
    · exact node_179_
    · exact node_307_
    · exact node_563_
theorem node_56_2 : ¬ Placement [2] 56 := by
  apply node_sound (lookup := frozen) (next := [58])
  · exact scan_2_56
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_58_
theorem node_57_2 : ¬ Placement [2] 57 := by
  apply node_sound (lookup := frozen) (next := [59])
  · exact scan_2_57
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_59_
theorem node_112_2 : ¬ Placement [2] 112 := by
  apply node_sound (lookup := frozen) (next := [114])
  · exact scan_2_112
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_114_
theorem node_176_2 : ¬ Placement [2] 176 := by
  apply node_sound (lookup := frozen) (next := [178])
  · exact scan_2_176
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_178_
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_560_2 : ¬ Placement [2] 560 := by
  apply node_sound (lookup := frozen) (next := [562])
  · exact scan_2_560
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_562_
theorem node_113_2 : ¬ Placement [2] 113 := by
  apply node_sound (lookup := frozen) (next := [115])
  · exact scan_2_113
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_115_
theorem node_177_2 : ¬ Placement [2] 177 := by
  apply node_sound (lookup := frozen) (next := [179])
  · exact scan_2_177
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_179_
theorem node_561_2 : ¬ Placement [2] 561 := by
  apply node_sound (lookup := frozen) (next := [563])
  · exact scan_2_561
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_563_
theorem node_58_1 : ¬ Placement [1] 58 := by
  apply node_sound (lookup := frozen) (next := [58, 59, 122, 123, 314, 315, 570, 571, 826, 827])
  · exact scan_1_58
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_58_
    · exact node_59_
    · exact node_122_
    · exact node_123_
    · exact node_314_
    · exact node_315_
    · exact node_570_
    · exact node_571_
    · exact node_826_
    · exact node_827_
theorem node_59_1 : ¬ Placement [1] 59 := by
  apply node_sound (lookup := frozen) (next := [59, 123, 315, 571, 827])
  · exact scan_1_59
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl
    · exact node_59_
    · exact node_123_
    · exact node_315_
    · exact node_571_
    · exact node_827_
theorem node_114_1 : ¬ Placement [1] 114 := by
  apply node_sound (lookup := frozen) (next := [114, 115, 122, 123, 370, 371, 626, 627, 634, 635, 882, 883])
  · exact scan_1_114
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_114_
    · exact node_115_
    · exact node_122_
    · exact node_123_
    · exact node_370_
    · exact node_371_
    · exact node_626_
    · exact node_627_
    · exact node_634_
    · exact node_635_
    · exact node_882_
    · exact node_883_
theorem node_178_1 : ¬ Placement [1] 178 := by
  apply node_sound (lookup := frozen) (next := [178, 179, 186, 187, 242, 243, 434, 435, 690, 691, 698, 699])
  · exact scan_1_178
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_178_
    · exact node_179_
    · exact node_186_
    · exact node_187_
    · exact node_242_
    · exact node_243_
    · exact node_434_
    · exact node_435_
    · exact node_690_
    · exact node_691_
    · exact node_698_
    · exact node_699_
theorem node_562_1 : ¬ Placement [1] 562 := by
  apply node_sound (lookup := frozen) (next := [562, 563, 570, 571, 626, 627, 634, 635, 818, 819])
  · exact scan_1_562
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_562_
    · exact node_563_
    · exact node_570_
    · exact node_571_
    · exact node_626_
    · exact node_627_
    · exact node_634_
    · exact node_635_
    · exact node_818_
    · exact node_819_
theorem node_115_1 : ¬ Placement [1] 115 := by
  apply node_sound (lookup := frozen) (next := [115, 123, 371, 627, 635, 883])
  · exact scan_1_115
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_115_
    · exact node_123_
    · exact node_371_
    · exact node_627_
    · exact node_635_
    · exact node_883_
theorem node_179_1 : ¬ Placement [1] 179 := by
  apply node_sound (lookup := frozen) (next := [179, 187, 243, 435, 691, 699])
  · exact scan_1_179
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_179_
    · exact node_187_
    · exact node_243_
    · exact node_435_
    · exact node_691_
    · exact node_699_
theorem node_563_1 : ¬ Placement [1] 563 := by
  apply node_sound (lookup := frozen) (next := [563, 571, 627, 635, 819])
  · exact scan_1_563
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl
    · exact node_563_
    · exact node_571_
    · exact node_627_
    · exact node_635_
    · exact node_819_
theorem node_274_3 : ¬ Placement [3] 274 := by
  apply node_sound (lookup := frozen) (next := [274, 275, 282, 283, 306, 338, 346, 402, 786])
  · exact scan_3_274
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_274_
    · exact node_275_
    · exact node_282_
    · exact node_283_
    · exact node_306_
    · exact node_338_
    · exact node_346_
    · exact node_402_
    · exact node_786_
theorem node_282_3 : ¬ Placement [3] 282 := by
  apply node_sound (lookup := frozen) (next := [282, 283, 314, 346, 410, 794])
  · exact scan_3_282
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_282_
    · exact node_283_
    · exact node_314_
    · exact node_346_
    · exact node_410_
    · exact node_794_
theorem node_273_2 : ¬ Placement [2] 273 := by
  apply node_sound (lookup := frozen) (next := [275])
  · exact scan_2_273
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_275_
theorem node_281_2 : ¬ Placement [2] 281 := by
  apply node_sound (lookup := frozen) (next := [283])
  · exact scan_2_281
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_283_
theorem node_336_2 : ¬ Placement [2] 336 := by
  apply node_sound (lookup := frozen) (next := [338])
  · exact scan_2_336
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_338_
theorem node_400_2 : ¬ Placement [2] 400 := by
  apply node_sound (lookup := frozen) (next := [402])
  · exact scan_2_400
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_402_
theorem node_784_2 : ¬ Placement [2] 784 := by
  apply node_sound (lookup := frozen) (next := [786])
  · exact scan_2_784
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_786_
theorem node_344_2 : ¬ Placement [2] 344 := by
  apply node_sound (lookup := frozen) (next := [346])
  · exact scan_2_344
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_346_
theorem node_408_2 : ¬ Placement [2] 408 := by
  apply node_sound (lookup := frozen) (next := [410])
  · exact scan_2_408
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_410_
theorem node_792_2 : ¬ Placement [2] 792 := by
  apply node_sound (lookup := frozen) (next := [794])
  · exact scan_2_792
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_794_
theorem node_275_1 : ¬ Placement [1] 275 := by
  apply node_sound (lookup := frozen) (next := [275, 283, 307, 315, 339, 347, 371, 379, 787, 795, 819, 827])
  · exact scan_1_275
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_275_
    · exact node_283_
    · exact node_307_
    · exact node_315_
    · exact node_339_
    · exact node_347_
    · exact node_371_
    · exact node_379_
    · exact node_787_
    · exact node_795_
    · exact node_819_
    · exact node_827_
theorem node_283_1 : ¬ Placement [1] 283 := by
  apply node_sound (lookup := frozen) (next := [283, 315, 347, 379, 795, 827])
  · exact scan_1_283
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_283_
    · exact node_315_
    · exact node_347_
    · exact node_379_
    · exact node_795_
    · exact node_827_
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_338_1 : ¬ Placement [1] 338 := by
  apply node_sound (lookup := frozen) (next := [338, 339, 346, 347, 370, 378, 850, 851, 858, 859, 882, 890])
  · exact scan_1_338
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_338_
    · exact node_339_
    · exact node_346_
    · exact node_347_
    · exact node_370_
    · exact node_378_
    · exact node_850_
    · exact node_851_
    · exact node_858_
    · exact node_859_
    · exact node_882_
    · exact node_890_
theorem node_346_1 : ¬ Placement [1] 346 := by
  apply node_sound (lookup := frozen) (next := [346, 347, 378, 858, 859, 890])
  · exact scan_1_346
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_346_
    · exact node_347_
    · exact node_378_
    · exact node_858_
    · exact node_859_
    · exact node_890_
theorem node_402_1 : ¬ Placement [1] 402 := by
  apply node_sound (lookup := frozen) (next := [402, 403, 410, 411, 434, 442, 466, 474, 914, 922])
  · exact scan_1_402
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_402_
    · exact node_403_
    · exact node_410_
    · exact node_411_
    · exact node_434_
    · exact node_442_
    · exact node_466_
    · exact node_474_
    · exact node_914_
    · exact node_922_
theorem node_786_1 : ¬ Placement [1] 786 := by
  apply node_sound (lookup := frozen) (next := [786, 787, 794, 795, 818, 826, 850, 851, 858, 859, 882, 890])
  · exact scan_1_786
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_786_
    · exact node_787_
    · exact node_794_
    · exact node_795_
    · exact node_818_
    · exact node_826_
    · exact node_850_
    · exact node_851_
    · exact node_858_
    · exact node_859_
    · exact node_882_
    · exact node_890_
theorem node_410_1 : ¬ Placement [1] 410 := by
  apply node_sound (lookup := frozen) (next := [410, 411, 442, 474, 922])
  · exact scan_1_410
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl
    · exact node_410_
    · exact node_411_
    · exact node_442_
    · exact node_474_
    · exact node_922_
theorem node_794_1 : ¬ Placement [1] 794 := by
  apply node_sound (lookup := frozen) (next := [794, 795, 826, 858, 859, 890])
  · exact scan_1_794
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_794_
    · exact node_795_
    · exact node_826_
    · exact node_858_
    · exact node_859_
    · exact node_890_
theorem node_290_3 : ¬ Placement [3] 290 := by
  apply node_sound (lookup := frozen) (next := [290, 291, 298, 306, 354, 418, 802])
  · exact scan_3_290
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_290_
    · exact node_291_
    · exact node_298_
    · exact node_306_
    · exact node_354_
    · exact node_418_
    · exact node_802_
theorem node_289_2 : ¬ Placement [2] 289 := by
  apply node_sound (lookup := frozen) (next := [291])
  · exact scan_2_289
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_291_
theorem node_296_2 : ¬ Placement [2] 296 := by
  apply node_sound (lookup := frozen) (next := [298])
  · exact scan_2_296
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_298_
theorem node_352_2 : ¬ Placement [2] 352 := by
  apply node_sound (lookup := frozen) (next := [354])
  · exact scan_2_352
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_354_
theorem node_416_2 : ¬ Placement [2] 416 := by
  apply node_sound (lookup := frozen) (next := [418])
  · exact scan_2_416
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_418_
theorem node_800_2 : ¬ Placement [2] 800 := by
  apply node_sound (lookup := frozen) (next := [802])
  · exact scan_2_800
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_802_
theorem node_291_1 : ¬ Placement [1] 291 := by
  apply node_sound (lookup := frozen) (next := [291, 299, 307, 355, 363, 371, 803, 811])
  · exact scan_1_291
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_291_
    · exact node_299_
    · exact node_307_
    · exact node_355_
    · exact node_363_
    · exact node_371_
    · exact node_803_
    · exact node_811_
theorem node_298_1 : ¬ Placement [1] 298 := by
  apply node_sound (lookup := frozen) (next := [298, 299, 314, 362, 363, 378, 810, 811])
  · exact scan_1_298
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_298_
    · exact node_299_
    · exact node_314_
    · exact node_362_
    · exact node_363_
    · exact node_378_
    · exact node_810_
    · exact node_811_
theorem node_354_1 : ¬ Placement [1] 354 := by
  apply node_sound (lookup := frozen) (next := [354, 355, 362, 363, 370, 866, 867, 874, 875])
  · exact scan_1_354
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_354_
    · exact node_355_
    · exact node_362_
    · exact node_363_
    · exact node_370_
    · exact node_866_
    · exact node_867_
    · exact node_874_
    · exact node_875_
theorem node_418_1 : ¬ Placement [1] 418 := by
  apply node_sound (lookup := frozen) (next := [418, 419, 426, 427, 434, 482, 483, 490, 491, 930, 931, 938])
  · exact scan_1_418
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_418_
    · exact node_419_
    · exact node_426_
    · exact node_427_
    · exact node_434_
    · exact node_482_
    · exact node_483_
    · exact node_490_
    · exact node_491_
    · exact node_930_
    · exact node_931_
    · exact node_938_
theorem node_802_1 : ¬ Placement [1] 802 := by
  apply node_sound (lookup := frozen) (next := [802, 803, 810, 811, 818, 866, 867, 874, 875, 882])
  · exact scan_1_802
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_802_
    · exact node_803_
    · exact node_810_
    · exact node_811_
    · exact node_818_
    · exact node_866_
    · exact node_867_
    · exact node_874_
    · exact node_875_
    · exact node_882_
end Petersen9822
