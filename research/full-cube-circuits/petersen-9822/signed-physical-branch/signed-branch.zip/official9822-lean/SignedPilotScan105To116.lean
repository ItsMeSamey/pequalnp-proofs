import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_2_304 : nodeCheck frozen 2 304 [306] = true := by decide +kernel
theorem scan_2_305 : nodeCheck frozen 2 305 [307] = true := by decide +kernel
theorem scan_2_312 : nodeCheck frozen 2 312 [314] = true := by decide +kernel
theorem scan_2_313 : nodeCheck frozen 2 313 [315] = true := by decide +kernel
theorem scan_2_336 : nodeCheck frozen 2 336 [338] = true := by decide +kernel
theorem scan_2_344 : nodeCheck frozen 2 344 [346] = true := by decide +kernel
theorem scan_2_352 : nodeCheck frozen 2 352 [354] = true := by decide +kernel
theorem scan_2_400 : nodeCheck frozen 2 400 [402] = true := by decide +kernel
theorem scan_2_408 : nodeCheck frozen 2 408 [410] = true := by decide +kernel
theorem scan_2_416 : nodeCheck frozen 2 416 [418] = true := by decide +kernel
theorem scan_2_560 : nodeCheck frozen 2 560 [562] = true := by decide +kernel
theorem scan_2_561 : nodeCheck frozen 2 561 [563] = true := by decide +kernel
end Petersen9822
