import Not9822PinnedWires
import Not9822ReflectCore
namespace Petersen9822.DagCut
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822

theorem rawThreeSole {d out} (c : FifteenCore d out)
    (floor : Lower true (varsX 1015) (graphGoal 1015) 14) : fork d 3 = false := by
  let moves := fixRows 8 0
  have ok : checkMap moves inputs target (varsX 1015) (graphGoal 1015) = true := by decide +kernel
  apply soleOnFourteen c moves _ _ ok floor
  rw [moved_raw c moves ⟨3,by decide⟩,←moved_eq_rename]
  have hz : movedWord moves (inputs.getD 3 zero) = zero := by decide +kernel
  rw [hz]
  exact ⟨false,funext (fun r => bit_zero r)⟩

theorem rawZeroThreeSole {d out} (c : FifteenCore d out)
    (floor : Lower true (varsX 1015) (graphGoal 1015) 14) : fork d 0 = false ∧ fork d 3 = false :=
  ⟨(mirror_fork d c.diagram 0).symm.trans (rawThreeSole (reflectCore c) floor),rawThreeSole c floor⟩

end Petersen9822.DagCut
