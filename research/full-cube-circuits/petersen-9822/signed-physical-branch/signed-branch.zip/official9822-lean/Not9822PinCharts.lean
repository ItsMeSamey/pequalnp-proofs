import Not9822PinnedWires
namespace Petersen9822.DagCut
open PEqualNP.Outside.L_meta_9825.Engine Research.Signed9822

structure PinChart (i : Nat) (b : Bool) where
  moves : List Move
  base : List Sig
  goal : Sig
  mapOK : checkMap moves inputs target base goal = true
  value : movedWord moves (inputs.getD i zero) = if b then one else zero
  floor : Lower true base goal 13

theorem PinChart.pinRaw {d out i b} (c : FifteenCore d out) (chart : PinChart i b)
    (low : i < 10) : onMoved d chart.moves i = (fun _ => b) := by
  rw [moved_raw c chart.moves ⟨i,low⟩,←moved_eq_rename,chart.value]
  cases b
  · exact funext bit_zero
  · exact funext bit_one

def pin1Neg : Sig := movedWord (fixRows 2 0) target
theorem pin1Neg_floor (prior : Lower true (varsX 701) (graphGoal 701) 11) : Lower true (varsX 1021) pin1Neg 13 := by
  let ms := ([98, 147, 135] : List Nat).map swapRows ++ fixRows 128 4
  let xs : List (Sig × Row × Row) := [(inputs.getD 2 zero, 128, 132), (inputs.getD 7 zero, 4, 132)]
  have h : checkLift ms pin1Neg (varsX 1021) (varsX 701) (graphGoal 701) xs = true := by decide +kernel
  have hL := lift_ok h (proper_of _ (by decide +kernel)) (proper_of _ (by decide +kernel)) prior
  have card : (xs.map Prod.fst).toFinset.card = 2 := by decide +kernel
  simpa only [card] using hL

def pin1Pos : Sig := movedWord (fixRows 0 2) target
theorem pin1Pos_floor (prior : Lower true (varsX 701) (graphGoal 701) 11) : Lower true (varsX 1021) pin1Pos 13 := by
  let ms := ([144, 98, 147, 117, 134, 135] : List Nat).map swapRows ++ fixRows 68 0
  let xs : List (Sig × Row × Row) := [(inputs.getD 2 zero, 0, 4), (inputs.getD 6 zero, 0, 64)]
  have h : checkLift ms pin1Pos (varsX 1021) (varsX 701) (graphGoal 701) xs = true := by decide +kernel
  have hL := lift_ok h (proper_of _ (by decide +kernel)) (proper_of _ (by decide +kernel)) prior
  have card : (xs.map Prod.fst).toFinset.card = 2 := by decide +kernel
  simpa only [card] using hL

def pin2Neg : Sig := movedWord (fixRows 4 0) target
theorem pin2Neg_floor (prior : Lower true (varsX 701) (graphGoal 701) 11) : Lower true (varsX 1019) pin2Neg 13 := by
  let ms := ([144, 98, 147, 117, 134, 135] : List Nat).map swapRows ++ fixRows 64 2
  let xs : List (Sig × Row × Row) := [(inputs.getD 1 zero, 64, 66), (inputs.getD 6 zero, 2, 66)]
  have h : checkLift ms pin2Neg (varsX 1019) (varsX 701) (graphGoal 701) xs = true := by decide +kernel
  have hL := lift_ok h (proper_of _ (by decide +kernel)) (proper_of _ (by decide +kernel)) prior
  have card : (xs.map Prod.fst).toFinset.card = 2 := by decide +kernel
  simpa only [card] using hL

def pin2Pos : Sig := movedWord (fixRows 0 4) target
theorem pin2Pos_floor (prior : Lower true (varsX 701) (graphGoal 701) 11) : Lower true (varsX 1019) pin2Pos 13 := by
  let ms := ([98, 147, 135] : List Nat).map swapRows ++ fixRows 130 0
  let xs : List (Sig × Row × Row) := [(inputs.getD 1 zero, 0, 2), (inputs.getD 7 zero, 0, 128)]
  have h : checkLift ms pin2Pos (varsX 1019) (varsX 701) (graphGoal 701) xs = true := by decide +kernel
  have hL := lift_ok h (proper_of _ (by decide +kernel)) (proper_of _ (by decide +kernel)) prior
  have card : (xs.map Prod.fst).toFinset.card = 2 := by decide +kernel
  simpa only [card] using hL

def pinChart1 (prior : Lower true (varsX 701) (graphGoal 701) 11) : ∀ b, PinChart 1 b
  | false => ⟨fixRows 2 0,varsX 1021,pin1Neg,by decide +kernel,by decide +kernel,pin1Neg_floor prior⟩
  | true => ⟨fixRows 0 2,varsX 1021,pin1Pos,by decide +kernel,by decide +kernel,pin1Pos_floor prior⟩
def pinChart2 (prior : Lower true (varsX 701) (graphGoal 701) 11) : ∀ b, PinChart 2 b
  | false => ⟨fixRows 4 0,varsX 1019,pin2Neg,by decide +kernel,by decide +kernel,pin2Neg_floor prior⟩
  | true => ⟨fixRows 0 4,varsX 1019,pin2Pos,by decide +kernel,by decide +kernel,pin2Pos_floor prior⟩

end Petersen9822.DagCut
