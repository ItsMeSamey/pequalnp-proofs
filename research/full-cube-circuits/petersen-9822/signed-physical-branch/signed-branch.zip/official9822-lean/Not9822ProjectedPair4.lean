import Not9822ProjectedPair3
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
set_option maxRecDepth 10000 in
theorem fixedInput8 (r : Row) : observe (inputs.getD 8 zero) r = r.val.testBit 8 := by
  change ((0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000000000000000 : Nat).testBit r.val = r.val.testBit 8)
  exact (by decide +kernel : ∀ t : Fin 1024, (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000000000000000 : Nat).testBit t.val = t.val.testBit 8) r

set_option maxRecDepth 10000 in
theorem fixedInput9 (r : Row) : observe (inputs.getD 9 zero) r = r.val.testBit 9 := by
  change ((0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : Nat).testBit r.val = r.val.testBit 9)
  exact (by decide +kernel : ∀ t : Fin 1024, (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 : Nat).testBit t.val = t.val.testBit 9) r


end Petersen9822.Potential
