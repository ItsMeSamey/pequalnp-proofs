import SignedPhysicalGuards9822
namespace Petersen9822.DagCut

def guardOfPin {d : Indexed} {out raw read partner : Nat} (c : FifteenCore d out)
    (low : raw < 10) (internal : 10 ≤ partner) (before : partner < out)
    (unique : fork d raw = false) (hot : fork d partner = true)
    (g : Gate) (eq : d.get read = some g) (block : Bool)
    (pin : (g.left = raw ∧ g.right = partner ∧ g.op false block = g.op true block) ∨
      (g.right = raw ∧ g.left = partner ∧ g.op block false = g.op block true)) :
    RealGuard d out raw := by
  have readEdge : d.edge raw read := ⟨g,eq,pin.elim (fun h => Or.inl h.1) (fun h => Or.inr h.1)⟩
  refine ⟨partner,block,?_,hot,internal,before,unique⟩
  refine ⟨by simp [Nat.testBit_two_pow,show raw ≠ partner by omega],?_,?_,?_⟩
  · intro v hv
    have ev : raw = v := by simpa [Nat.testBit_two_pow] using hv
    exact c.diagram.raw v (ev ▸ low)
  · intro n k hk hb
    have ev : raw = k.left := by simpa [Nat.testBit_two_pow] using hb
    have same := fork_unique d raw unique n read ⟨k,hk,Or.inl ev.symm⟩ readEdge
    subst n
    have ek := Option.some.inj (hk.symm.trans eq)
    subst k
    rcases pin with h | h
    · exact h.2
    · exact False.elim (c.properSockets _ _ eq (ev.symm.trans h.1.symm))
  · intro n k hk hb
    have ev : raw = k.right := by simpa [Nat.testBit_two_pow] using hb
    have same := fork_unique d raw unique n read ⟨k,hk,Or.inr ev.symm⟩ readEdge
    subst n
    have ek := Option.some.inj (hk.symm.trans eq)
    subst k
    rcases pin with h | h
    · exact False.elim (c.properSockets _ _ eq (h.1.trans ev))
    · exact h.2

end Petersen9822.DagCut
