import Not9822PotentialStage02

-- Not9822AlarmPins
namespace Petersen9822.Potential

/-- Each pair is the watched producer and the fresh OR accumulator. The
    OR's signed second socket detects disagreement with the producer default. -/
def alarmGates {n : Nat} (prev : Fin n) : List (Fin n × Fin n) → List (Pins n) × Fin n
  | [] => ([],prev)
  | (watched,next) :: rest =>
    let suffix := alarmGates next rest
    (⟨next,prev,watched⟩ :: suffix.1,suffix.2)

theorem alarm_counts {n : Nat} (prev v : Fin n) (extra : List (Fin n × Fin n)) :
    ((alarmGates prev extra).1.flatMap pins ++ [(alarmGates prev extra).2]).count v =
      [prev].count v + (extra.map Prod.fst).count v + (extra.map Prod.snd).count v := by
  induction extra generalizing prev with
  | nil => simp [alarmGates]
  | cons e es ih =>
    obtain ⟨watched,next⟩ := e
    have h := ih next
    simp only [alarmGates,List.flatMap_cons,pins,List.cons_append,List.nil_append,List.map_cons,
      List.count_cons,List.count_append,List.count_nil] at h ⊢
    omega

def routed {n : Nat} (rewire : Fin n → Fin n) (g : Pins n) : Pins n :=
  ⟨g.id,rewire g.left,rewire g.right⟩

def monitored {n : Nat} (gs : List (Pins n)) (out : Fin n) (rewire : Fin n → Fin n)
    (extra : List (Fin n × Fin n)) : List (Pins n) × Fin n :=
  let a := alarmGates (rewire out) extra
  (gs.map (routed rewire) ++ a.1,a.2)

theorem counted_route {n : Nat} (gs : List (Pins n)) (rewire : Fin n → Fin n) :
    (gs.map (routed rewire)).flatMap pins = (gs.flatMap pins).map rewire := by
  induction gs with
  | nil => rfl
  | cons g gs ih =>
    simp only [List.map_cons,List.flatMap_cons,List.map_append,ih,pins,routed,List.map_cons,List.map_nil]

theorem monitored_counts {n : Nat} (gs : List (Pins n)) (out v : Fin n) (rewire : Fin n → Fin n)
    (extra : List (Fin n × Fin n)) :
    ((monitored gs out rewire extra).1.flatMap pins ++ [(monitored gs out rewire extra).2]).count v =
      ((gs.flatMap pins ++ [out]).map rewire).count v +
      (extra.map Prod.fst).count v + (extra.map Prod.snd).count v := by
  have h := alarm_counts (rewire out) v extra
  simp only [monitored,List.flatMap_append,List.count_append,counted_route,List.map_append,
    List.map_cons,List.map_nil] at h ⊢
  omega

private theorem count_redirect {n : Nat} (k : Fin n → Kind) (pick : Fin n → Bool)
    (rewire : Fin n → Fin n) (same : ∀ v, pick v = false → rewire v = v)
    (fixed : ∀ v, pick v = true → k (rewire v) = .fixed)
    (xs : List (Fin n)) (v : Fin n) (real : k v ≠ .fixed) :
    (xs.map rewire).count v = if pick v then 0 else xs.count v := by
  induction xs with
  | nil => cases pick v <;> rfl
  | cons x xs ih =>
    cases px : pick x with
    | false =>
      have eq := same x px
      by_cases xv : x = v
      · subst v; simp [eq,px,ih]
      · cases pv : pick v <;> simp [eq,xv,ih,pv,List.count_cons_of_ne]
    | true =>
      have ne : rewire x ≠ v := by intro e; exact real (e ▸ fixed x px)
      by_cases eq : x = v
      · subst v; simp [ne,ih,px,List.count_cons_of_ne]
      · cases pv : pick v <;> simp [ne,eq,ih,pv,List.count_cons_of_ne]

theorem monitor_charge {n : Nat} (k : Fin n → Kind) (pick : Fin n → Bool)
    (gs : List (Pins n)) (out : Fin n) (rewire : Fin n → Fin n) (extra : List (Fin n × Fin n))
    (same : ∀ v, pick v = false → rewire v = v)
    (fixed : ∀ v, pick v = true → k (rewire v) = .fixed)
    (watched : ∀ v, (extra.map Prod.fst).count v = if pick v then 1 else 0)
    (selectedGate : ∀ v, pick v = true → k v = .gate)
    (unique : (extra.map Prod.snd).Nodup)
    (fresh : ∀ v ∈ extra.map Prod.snd, v ∉ gs.flatMap pins ++ [out] ∧ pick v = false ∧ k v = .gate) :
    total k (fun v => ((monitored gs out rewire extra).1.flatMap pins ++ [(monitored gs out rewire extra).2]).count v) =
    ∑ v, if pick v then 0 else charge (k v) ((gs.flatMap pins ++ [out]).count v) := by
  classical
  apply Finset.sum_congr rfl
  intro v _
  dsimp only
  rw [monitored_counts,watched]
  by_cases free : k v = .fixed
  · cases pp : pick v <;> simp [free,charge]
  rw [count_redirect k pick rewire same fixed _ v free]
  by_cases added : v ∈ extra.map Prod.snd
  · obtain ⟨empty,pp,gate⟩ := fresh v added
    simp [List.count_eq_one_of_mem unique added,List.count_eq_zero.mpr empty,pp,gate,charge]
  · cases pp : pick v with
    | false => simp [pp,List.count_eq_zero.mpr added]
    | true => simp [pp,List.count_eq_zero.mpr added,selectedGate v pp,charge]

end Petersen9822.Potential

-- Not9822RoutedTruth
namespace Petersen9822.Potential

def SignedEquation {n : Nat} (orig cut : Fin n → Bool) (rewire : Fin n → Fin n) (g : Pins n) : Prop :=
  ∃ op : Bool → Bool → Bool, orig g.id = op (orig g.left) (orig g.right) ∧
    cut g.id = op (cut (rewire g.left)) (cut (rewire g.right))

theorem agree_routed {n : Nat} {S T : Finset (Fin n)} {gs : List (Pins n)}
    (schedule : Chrono S gs T) (orig cut : Fin n → Bool) (rewire : Fin n → Fin n)
    (pick default : Fin n → Bool) (eqns : ∀ g ∈ gs, SignedEquation orig cut rewire g)
    (roots : ∀ v ∈ S, orig v = cut v)
    (same : ∀ v, pick v = false → rewire v = v)
    (fixed : ∀ v, pick v = true → cut (rewire v) = default v)
    (stable : (∀ v, pick v = true → orig v = default v) ∨
      (∀ v, pick v = true → cut v = default v)) :
    ∀ v ∈ T, orig v = cut v := by
  induction schedule with
  | done => exact roots
  | @step S T g gs hl hr tail ih =>
    obtain ⟨op,original,routed⟩ := eqns g List.mem_cons_self
    have read (v : Fin n) (hv : v ∈ S) : orig v = cut (rewire v) := by
      cases h : pick v with
      | false => rw [same v h]; exact roots v hv
      | true =>
        rw [fixed v h]
        rcases stable with origDefault | cutDefault
        · exact origDefault v h
        · exact (roots v hv).trans (cutDefault v h)
    apply ih (fun x hx => eqns x (List.mem_cons_of_mem _ hx))
    intro v hv
    rcases Finset.mem_insert.mp hv with rfl | hv
    · rw [original,routed,read _ hl,read _ hr]
    · exact roots _ hv

def alarm {n : Nat} (cut : Fin n → Bool) (default : Fin n → Bool) (extra : List (Fin n × Fin n)) :=
  extra.any (fun e => cut e.1 != default e.1)

theorem alarm_correct {n : Nat} {S T : Finset (Fin n)} {gs : List (Pins n)} {out : Fin n}
    (schedule : Chrono S gs T) (hout : out ∈ T)
    (orig cut : Fin n → Bool) (rewire : Fin n → Fin n) (pick default : Fin n → Bool)
    (extra : List (Fin n × Fin n)) (covered : ∀ v, pick v = true ↔ v ∈ extra.map Prod.fst)
    (eqns : ∀ g ∈ gs, SignedEquation orig cut rewire g)
    (roots : ∀ v ∈ S, orig v = cut v)
    (same : ∀ v, pick v = false → rewire v = v)
    (fixed : ∀ v, pick v = true → cut (rewire v) = default v)
    (watches : ∀ v, pick v = true → v ∈ T)
    (neg : orig out = false → ∀ v, pick v = true → orig v = default v) :
    (cut (rewire out) || alarm cut default extra) = orig out := by
  have readOut (agree : orig out = cut out) (holds : pick out = true → orig out = default out) :
      cut (rewire out) = orig out := by
    cases h : pick out with
    | false => rw [same out h]; exact agree.symm
    | true => rw [fixed out h,holds h]
  cases h : orig out with
  | false =>
    have stable := neg h
    have agree := agree_routed schedule orig cut rewire pick default eqns roots same fixed (Or.inl stable)
    have a : alarm cut default extra = false := by
      apply Bool.eq_false_iff.mpr
      intro hot
      obtain ⟨e,he,ne⟩ := List.any_eq_true.mp hot
      have sel := (covered e.1).mpr (List.mem_map_of_mem he)
      have eq := ((agree _ (watches _ sel)).symm.trans (stable _ sel))
      simp [eq] at ne
    rw [a,readOut (agree _ hout) (stable out),h]
    rfl
  | true =>
    cases ha : alarm cut default extra with
    | true => simp
    | false =>
      have stable (v : Fin n) (hv : pick v = true) : cut v = default v := by
        obtain ⟨e,he,eq⟩ := List.mem_map.mp ((covered v).mp hv)
        by_contra ne
        have bad : alarm cut default extra = true := List.any_eq_true.mpr
          ⟨e,he,by simpa [eq] using ne⟩
        simp_all
      have agree := agree_routed schedule orig cut rewire pick default eqns roots same fixed (Or.inr stable)
      have eq := readOut (agree _ hout) (fun sel => (agree _ hout).trans (stable _ sel))
      simp [eq,h]

end Petersen9822.Potential

-- Not9822AlarmSchedule
namespace Petersen9822.Potential

theorem Chrono.grows {n : Nat} {S T : Finset (Fin n)} {gs : List (Pins n)}
    (h : Chrono S gs T) : S ⊆ T := by
  induction h with
  | done => exact fun _ a => a
  | step _ _ _ ih => exact fun _ ha => ih (Finset.mem_insert_of_mem ha)

theorem Chrono.append {n : Nat} {S T V : Finset (Fin n)} {a b : List (Pins n)}
    (first : Chrono S a T) (later : Chrono T b V) : Chrono S (a ++ b) V := by
  induction first with
  | done => exact later
  | step l r _ ih => exact .step l r (ih later)

theorem Chrono.route {n : Nat} {S T : Finset (Fin n)} {gs : List (Pins n)}
    (h : Chrono S gs T) (rewire : Fin n → Fin n)
    (safe : ∀ v, rewire v = v ∨ rewire v ∈ S) : Chrono S (gs.map (routed rewire)) T := by
  induction h with
  | done => exact .done _
  | @step S T g gs hl hr tail ih =>
    have read (v : Fin n) (hv : v ∈ S) : rewire v ∈ S := by
      rcases safe v with eq | built
      · simpa [eq] using hv
      · exact built
    exact .step (read _ hl) (read _ hr) (ih (fun v =>
      (safe v).imp_right (fun h => Finset.mem_insert_of_mem h)))

theorem alarm_schedule {n : Nat} (T : Finset (Fin n)) (prev : Fin n) (extra : List (Fin n × Fin n))
    (start : prev ∈ T) (watched : ∀ e ∈ extra, e.1 ∈ T) :
    ∃ final, Chrono T (alarmGates prev extra).1 final ∧ (alarmGates prev extra).2 ∈ final := by
  induction extra generalizing T prev with
  | nil => exact ⟨T,.done T,start⟩
  | cons e es ih =>
    obtain ⟨z,k⟩ := e
    obtain ⟨final,tail,last⟩ := ih (insert k T) k (Finset.mem_insert_self _ _)
      (fun e he => Finset.mem_insert_of_mem (watched e (List.mem_cons_of_mem _ he)))
    exact ⟨final,.step start (watched _ List.mem_cons_self) tail,last⟩

theorem monitored_schedule {n : Nat} {S T : Finset (Fin n)} {gs : List (Pins n)} {out : Fin n}
    (h : Chrono S gs T) (result : out ∈ T) (rewire : Fin n → Fin n)
    (safe : ∀ v, rewire v = v ∨ rewire v ∈ S) (extra : List (Fin n × Fin n))
    (watched : ∀ e ∈ extra, e.1 ∈ T) :
    ∃ V, Chrono S (monitored gs out rewire extra).1 V ∧ (monitored gs out rewire extra).2 ∈ V := by
  have initial : rewire out ∈ T := by
    rcases safe out with eq | built
    · simpa [eq] using result
    · exact h.grows built
  obtain ⟨V,tail,last⟩ := alarm_schedule T (rewire out) extra initial watched
  exact ⟨V,(h.route rewire safe).append tail,last⟩

theorem alarm_eval {n : Nat} (value : Fin n → Bool) (default : Fin n → Bool) (prev : Fin n)
    (extra : List (Fin n × Fin n))
    (eqns : ∀ g ∈ (alarmGates prev extra).1,
      value g.id = (value g.left || (value g.right != default g.right))) :
    value (alarmGates prev extra).2 = (value prev || alarm value default extra) := by
  induction extra generalizing prev with
  | nil => simp [alarm,alarmGates]
  | cons e es ih =>
    obtain ⟨z,k⟩ := e
    have eq : value k = (value prev || (value z != default z)) :=
      eqns ⟨k,prev,z⟩ List.mem_cons_self
    have tail := ih k (fun g hg => eqns g (List.mem_cons_of_mem _ hg))
    simpa [alarmGates,alarm,eq,Bool.or_assoc] using tail

end Petersen9822.Potential
