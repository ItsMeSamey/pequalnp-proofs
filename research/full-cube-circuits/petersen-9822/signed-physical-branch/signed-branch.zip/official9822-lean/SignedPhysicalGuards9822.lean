import SignedPhysicalCore9822
import Not9822Bundle05Sites
namespace Petersen9822.DagCut
structure RealGuard (d : Indexed) (out raw : Nat) where
  site : Nat
  block : Bool
  sockets : PrivateSockets d site (2^raw) block
  shared : fork d site = true
  internal : 10 ≤ site
  beforeOut : site < out
  soleRaw : fork d raw = false

end Petersen9822.DagCut
