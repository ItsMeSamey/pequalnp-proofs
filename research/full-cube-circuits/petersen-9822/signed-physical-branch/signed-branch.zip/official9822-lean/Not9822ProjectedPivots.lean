import CompactRows9822
namespace Petersen9822.DagCut
open PEqualNP.Outside.L_meta_9822.Compact

private theorem outside_off {r : Nat} (h : sub r 313 = true) (i : Nat)
    (cold : (313 : Nat).testBit i = false) : r.testBit i = false := by
  have eq : r &&& 313 = r := beq_iff_eq.mp h
  have atBit := congrArg (fun n : Nat => n.testBit i) eq
  simpa [Nat.testBit_and,cold] using atBit.symm

theorem projectionPivots : ∀ ij ∈ ([(1,2),(2,1)] : List (Nat × Nat)), ∀ r : Fin 1024,
    sub r.val 313 = true → edgeHit (r.val ||| 2^ij.2) = false →
      (r.val ||| 2^ij.2).testBit ij.1 = false ∧ (r.val ||| 2^ij.1).testBit ij.2 = false ∧
      edgeHit (r.val ||| 2^ij.1) = false ∧
      edgeHit (r.val ||| 2^ij.1 ||| 2^ij.2) = true := by
  intro ij hij r hr
  have m1 := outside_off hr 1 (by decide)
  have m2 := outside_off hr 2 (by decide)
  have m6 := outside_off hr 6 (by decide)
  have m7 := outside_off hr 7 (by decide)
  have bit2 (i : Nat) : (2 : Nat).testBit i = decide (1 = i) := by
    change (2^1 : Nat).testBit i = _; rw [Nat.testBit_two_pow]
  have bit4 (i : Nat) : (4 : Nat).testBit i = decide (2 = i) := by
    change (2^2 : Nat).testBit i = _; rw [Nat.testBit_two_pow]
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hij
  rcases hij with rfl | rfl <;>
    simp [rowEdge,PEqualNP.Outside.L_meta_9822.Sectors.edge,Nat.testBit_two_pow,
      Nat.testBit_or,m1,m2,m6,m7,bit2,bit4] <;> tauto

end Petersen9822.DagCut
