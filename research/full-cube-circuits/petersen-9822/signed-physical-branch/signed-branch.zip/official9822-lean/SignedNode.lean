import SignedCensusBundle9822
namespace Petersen9822

def nodeCheck (lookup : Lookup) (j t : Nat) (next : List Nat) : Bool :=
  (List.range 1024).all fun s =>
    !legal j t s || (match lookup j s t with
      | some z => z.check (ownerBit j) s t (later t s)
      | none => false) || next.contains (t ||| s)

theorem node_sound {lookup : Lookup} {j t : Nat} {js next : List Nat}
    (h : nodeCheck lookup j t next = true)
    (all : ∀ k ∈ next, ¬ Placement js k) : ¬ Placement (j::js) t := by
  intro candidate
  cases candidate with
  | @cons _ _ _ s hs hl ha tail =>
    have hc := (List.all_eq_true.mp h) s (List.mem_range.mpr hs)
    simp only [hl, Bool.not_true, Bool.false_or, Bool.or_eq_true] at hc
    rcases hc with closed | child
    · split at closed
      next z hz => exact z.sound closed ha
      next => exact Bool.noConfusion closed
    · exact all _ (List.contains_iff_mem.mp child) tail
end Petersen9822
