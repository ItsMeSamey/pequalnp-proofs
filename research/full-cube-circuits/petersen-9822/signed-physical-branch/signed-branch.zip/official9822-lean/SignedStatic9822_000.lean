import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_0_48 : nodeCheck frozen 0 48 [48, 49] = true := by decide +kernel
end Petersen9822
