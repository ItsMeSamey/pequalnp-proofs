import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_1_561 : nodeCheck frozen 1 561 [561] = true := by decide +kernel
theorem scan_1_562 : nodeCheck frozen 1 562 [562, 563, 570, 571, 626, 627, 634, 635, 818, 819] = true := by decide +kernel
theorem scan_1_563 : nodeCheck frozen 1 563 [563, 571, 627, 635, 819] = true := by decide +kernel
theorem scan_1_784 : nodeCheck frozen 1 784 [784, 792] = true := by decide +kernel
theorem scan_1_786 : nodeCheck frozen 1 786 [786, 787, 794, 795, 818, 826, 850, 851, 858, 859, 882, 890] = true := by decide +kernel
theorem scan_1_792 : nodeCheck frozen 1 792 [792] = true := by decide +kernel
theorem scan_1_794 : nodeCheck frozen 1 794 [794, 795, 826, 858, 859, 890] = true := by decide +kernel
theorem scan_1_800 : nodeCheck frozen 1 800 [800] = true := by decide +kernel
theorem scan_1_802 : nodeCheck frozen 1 802 [802, 803, 810, 811, 818, 866, 867, 874, 875, 882] = true := by decide +kernel
theorem scan_2_48 : nodeCheck frozen 2 48 [50] = true := by decide +kernel
theorem scan_2_49 : nodeCheck frozen 2 49 [51] = true := by decide +kernel
theorem scan_2_56 : nodeCheck frozen 2 56 [58] = true := by decide +kernel
end Petersen9822
