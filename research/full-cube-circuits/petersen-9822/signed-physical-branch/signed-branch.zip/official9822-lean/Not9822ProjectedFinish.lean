import Not9822ProjectedRows3
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822.Cofactor
open Petersen9822.DagCut
theorem projected_output (owner : Nat) (which : owner ∈ ([1,2] : List Nat)) (r : Row) :
    Petersen9822.edgeHit (projectRow owner r) = observe pentagon r := by
  let h := r.val / 32
  let k : Fin 32 := ⟨r.val % 32, Nat.mod_lt _ (by decide)⟩
  have sum : 32*h+k.val = r.val := Nat.div_add_mod r.val 32
  have bound : h < 32 := by dsimp [h]; have := r.isLt; omega
  have choose (j : Bool) : edgeHit (((32*h+k.val) &&& 313) ||| (if j then 2 else 4)) =
      pentagonBits.testBit (32*h+k.val) := by
    by_cases h0 : h < 8
    · exact region0 h (by omega) h0 j k
    by_cases h1 : h < 16
    · exact region1 h (by omega) h1 j k
    by_cases h2 : h < 24
    · exact region2 h (by omega) h2 j k
    exact region3 h (by omega) bound j k
  rw [observeC5]
  simp only [List.mem_cons,List.not_mem_nil,or_false] at which
  rcases which with rfl | rfl
  · simpa [projectRow,sum] using choose true
  · simpa [projectRow,sum] using choose false
private theorem owners_outside : ∀ owner ∈ ([1,2] : List Nat), (313 : Nat).testBit owner = false := by
  decide +kernel

theorem projected_raw (owner : Nat) (which : owner ∈ ([1,2] : List Nat)) (i : Fin 10) :
    Available true ((varsX 313).map observe) (fun r => (projectRow owner r).testBit i.val) := by
  cases h : (313 : Nat).testBit i.val with
  | true =>
    have ne : owner ≠ i.val := by
      intro eq
      have no := owners_outside owner which
      rw [eq,h] at no
      contradiction
    have eq : (fun r : Row => (projectRow owner r).testBit i.val) = observe (inputs.getD i.val zero) := by
      funext r
      rw [input_bits i r]
      simp [projectRow,Nat.testBit_two_pow,ne,h]
    rw [eq]
    exact Or.inl (List.mem_map_of_mem (c5_pool i h))
  | false =>
    exact Or.inr (Or.inl ⟨decide (owner=i.val),by funext r; simp [projectRow,Nat.testBit_two_pow,h]⟩)

def originalTable (d : Indexed) (owner : Nat) (v : Slot) : Wire Row :=
  if v.val < 25 then fun r => wireValue d v.val (projectRow owner r)
  else fun _ => decide (v.val = 26)

theorem table_fixed (d : Indexed) (owner : Nat) (b : Bool) :
    originalTable d owner (fixedSlot b) = fun _ => b := by
  cases b <;> rfl

theorem table_raws (d : Indexed) (owner : Nat) (which : owner ∈ ([1,2] : List Nat))
    (raw : ∀ v, v < 10 → d.get v = none) :
    ∀ v ∈ seed, Available true ((varsX 313).map observe) (originalTable d owner v) := by
  intro v hv
  have h : v.val < 10 ∨ v.val = 25 ∨ v.val = 26 := (Finset.mem_filter.mp hv).2
  rcases h with h | h | h
  · have eq : d.tree v.val = .raw v.val := d.tree_none (raw v.val h)
    simpa [originalTable,show v.val < 25 by omega,wireValue,eq,Tree.term,Term.eval] using
      projected_raw owner which ⟨v.val,h⟩
  · exact Or.inr (Or.inl ⟨false,by simp [originalTable,h]⟩)
  · exact Or.inr (Or.inl ⟨true,by simp [originalTable,h]⟩)

end Petersen9822.Potential
