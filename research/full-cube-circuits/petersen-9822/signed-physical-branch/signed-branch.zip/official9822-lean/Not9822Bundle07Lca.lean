import Not9822Bundle06Occurrences

-- Not9822LCAProfile
namespace Petersen9822.DagCut

inductive Profile where
  | quiet (f : Nat → Bool)
  | left (l : PrivateLeg)
  | right (r : PrivateLeg)
  | pair (l r : PrivateLeg) (join : Bool → Bool → Bool) (tail : Nat → Bool → Bool)

def Profile.na : Profile → Nat
  | .left _ | .pair _ _ _ _ => 1
  | _ => 0
def Profile.nb : Profile → Nat
  | .right _ | .pair _ _ _ _ => 1
  | _ => 0
def Profile.eval : Profile → Nat → Bool → Bool → Bool
  | .quiet f,p,_,_ => f p
  | .left l,p,x,_ => l.eval p x
  | .right l,p,_,y => l.eval p y
  | .pair l r g t,p,x,y => t p (g (l.eval p x) (r.eval p y))

def Profile.merge (op : Bool → Bool → Bool)
    (sl : Socket op) (sr : Socket (fun x y => op y x)) : Profile → Profile → Option Profile
  | .quiet f,.quiet g => some (.quiet (fun p => op (f p) (g p)))
  | .left l,.quiet g => some (.left (.step op sl g l))
  | .right r,.quiet g => some (.right (.step op sl g r))
  | .quiet g,.left l => some (.left (.step (fun x y => op y x) sr g l))
  | .quiet g,.right r => some (.right (.step (fun x y => op y x) sr g r))
  | .left l,.right r => some (.pair l r op (fun _ b => b))
  | .right r,.left l => some (.pair l r (fun x y => op y x) (fun _ b => b))
  | .pair l r h t,.quiet f => some (.pair l r h (fun p b => op (t p b) (f p)))
  | .quiet f,.pair l r h t => some (.pair l r h (fun p b => op (f p) (t p b)))
  | _,_ => none

theorem Profile.merge_spec (op) (sl : Socket op) (sr : Socket (fun x y => op y x))
    (l r : Profile) (ha : l.na + r.na ≤ 1) (hb : l.nb + r.nb ≤ 1) :
    ∃ w : Profile, w.na = l.na + r.na ∧ w.nb = l.nb + r.nb ∧
      ∀ p x y, w.eval p x y = op (l.eval p x y) (r.eval p x y) := by
  refine ⟨(Profile.merge op sl sr l r).getD (.quiet (fun _ => false)), ?_⟩
  cases l <;> cases r <;>
    simp_all [Profile.merge, Profile.na, Profile.nb, Profile.eval, PrivateLeg.eval]

def Tree.rawCt (v : Nat) : Tree → Nat
  | .raw n => if n=v then 1 else 0
  | .gate _ _ l r => l.rawCt v + r.rawCt v

theorem Tree.rawCt_le (t : Tree) (v : Nat) : t.rawCt v ≤ t.occ v := by
  induction t with
  | raw n => rfl
  | gate n op l r ih jh =>
    simp only [Tree.rawCt,Tree.occ]
    omega

def Tree.signed : Tree → Prop
  | .raw _ => True
  | .gate _ op l r => Nonempty (Socket op) ∧ Nonempty (Socket (fun x y => op y x)) ∧ l.signed ∧ r.signed

def override (a b p : Nat) (x y : Bool) (v : Nat) : Bool :=
  if v=a then x else if v=b then y else p.testBit v

theorem Tree.profile (t : Tree) (a b : Nat) (ab : a≠b) (sg : t.signed)
    (ha : t.rawCt a ≤ 1) (hb : t.rawCt b ≤ 1) :
    ∃ w : Profile, w.na = t.rawCt a ∧ w.nb = t.rawCt b ∧
      ∀ p x y, w.eval p x y = t.term.eval (override a b p x y) := by
  induction t with
  | raw v =>
    by_cases va : v=a
    · subst v
      exact ⟨.left .raw,by simp [Profile.na,Tree.rawCt],by simp [Profile.nb,Tree.rawCt,ab],
        fun _ _ _ => by simp [Profile.eval,PrivateLeg.eval,Tree.term,Term.eval,override]⟩
    by_cases vb : v=b
    · subst v
      exact ⟨.right .raw,by simp [Profile.na,Tree.rawCt,va],by simp [Profile.nb,Tree.rawCt],
        fun _ _ _ => by simp [Profile.eval,PrivateLeg.eval,Tree.term,Term.eval,override,va]⟩
    exact ⟨.quiet (fun p => p.testBit v),by simp [Profile.na,Tree.rawCt,va],
      by simp [Profile.nb,Tree.rawCt,vb],fun _ _ _ => by simp [Profile.eval,Tree.term,Term.eval,override,va,vb]⟩
  | gate n op l r il ir =>
    obtain ⟨⟨sl⟩,⟨sr⟩,ls,rs⟩ := sg
    change l.rawCt a + r.rawCt a ≤ 1 at ha
    change l.rawCt b + r.rawCt b ≤ 1 at hb
    obtain ⟨lp,la,lb,lv⟩ := il ls (by omega) (by omega)
    obtain ⟨rp,ra,rb,rv⟩ := ir rs (by omega) (by omega)
    obtain ⟨w,wa,wb,we⟩ := Profile.merge_spec op sl sr lp rp (by omega) (by omega)
    exact ⟨w,by simpa [Tree.rawCt,la,ra] using wa,by simpa [Tree.rawCt,lb,rb] using wb,
      fun p x y => by simp only [we,lv,rv,Tree.term,Term.eval]⟩
end Petersen9822.DagCut

-- Not9822OwnerLCA
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

def Profile.channel (v : Profile) {a b : Nat} (post : Nat → Bool → Bool)
    (h : ∀ p, p &&& (a ||| b) = 0 → ∀ x y, sectionBit p a b x y = post p (v.eval p x y)) :
    SharedLCA a b := by
  cases v with
  | quiet f =>
    apply sharedLCA_of_legs .raw .raw (fun _ _ => false) (fun p _ => post p (f p))
    exact h
  | left l => exact sharedLCA_of_legs l .raw (fun x _ => x) post h
  | right r => exact sharedLCA_of_legs .raw r (fun _ y => y) post h
  | pair l r gate tail =>
    exact sharedLCA_of_legs l r gate (fun p z => post p (tail p z)) h

private theorem override_bits {a b p : Nat} (ab : a≠b)
    (dj : p &&& (2^a ||| 2^b) = 0) (x y : Bool) :
    (p ||| (if x then 2^a else 0) ||| (if y then 2^b else 0)).testBit =
      override a b p x y := by
  have pa := congrArg (fun n : Nat => n.testBit a) dj
  have pb := congrArg (fun n : Nat => n.testBit b) dj
  simp [Nat.testBit_two_pow,ab,Ne.symm ab] at pa pb
  funext v
  by_cases av : v = a
  · subst v
    cases x <;> cases y <;> simp_all [override,Nat.testBit_two_pow,Ne.symm ab]
  · by_cases bv : v = b
    · subst v
      cases x <;> cases y <;> simp_all [override,Nat.testBit_two_pow,Ne.symm ab]
    · cases x <;> cases y <;> simp [override,Nat.testBit_two_pow,av,bv,Ne.symm av,Ne.symm bv]


theorem Indexed.owner_hidden (d : Indexed) {out : Nat} {shared : Nat → Bool}
    (finalWire : ∀ a b, d.edge a b → a ≠ out)
    (func : ∀ a, shared a = false → ∀ j k, d.edge a j → d.edge a k → j=k)
    {v cut : Nat} (live : ∃ xs, Path d.edge out v xs)
    (own : owner d.edge out shared v live = cut) :
    ¬ ((d.tree out).openWire cut).uses (some v) := by
  intro uses
  obtain ⟨xs,hp,avoid⟩ := Tree.bypassPath (d.tree_valid out)
    (by simpa using (Path.stop : Path d.edge out out [])) finalWire (by simp) uses
  rw [owner_eq func _ hp] at own
  exact avoid (own ▸ first_on_path hp)

theorem Indexed.same_owner_LCA (d : Indexed) {out cut a b : Nat} {shared : Nat → Bool}
    (ab : a≠b) (finalWire : ∀ i j, d.edge i j → i ≠ out)
    (func : ∀ v, shared v = false → ∀ j k, d.edge v j → d.edge v k → j=k)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (signed : (d.tree cut).signed)
    (liveA : ∃ xs, Path d.edge out a xs) (liveB : ∃ xs, Path d.edge out b xs)
    (oa : owner d.edge out shared a liveA = cut)
    (ob : owner d.edge out shared b liveB = cut)
    (computes : ∀ row : Nat, edgeHit row = (d.tree out).term.eval row.testBit) :
    Nonempty (SharedLCA (2^a) (2^b)) := by
  have ca := owner_occ_once func distinct a liveA
  have cb := owner_occ_once func distinct b liveB
  rw [oa] at ca
  rw [ob] at cb
  obtain ⟨v,_,_,ev⟩ := (d.tree cut).profile a b ab signed
    ((Tree.rawCt_le _ _).trans ca) ((Tree.rawCt_le _ _).trans cb)
  let ext := (d.tree out).openWire cut
  let post := fun (p : Nat) (z : Bool) => ext.eval (ports p z)
  refine ⟨v.channel post ?_⟩
  intro p dj x y
  let row := p ||| (if x then 2^a else 0) ||| (if y then 2^b else 0)
  change edgeHit row = ext.eval (ports p (v.eval p x y))
  rw [computes, ← Tree.replaceSite (d.tree out) cut (d.tree cut).term (d.coherent cut out),
    Term.eval_bind, override_bits ab dj,ev]
  apply Term.congr
  intro k used
  cases k with
  | none => rfl
  | some k =>
    have ka : k≠a := by intro h; subst k; exact d.owner_hidden finalWire func liveA oa used
    have kb : k≠b := by intro h; subst k; exact d.owner_hidden finalWire func liveB ob used
    simp [ports,plug,Term.eval,override,ka,kb]

theorem Indexed.tree_signed (d : Indexed)
    (hs : ∀ n g, d.get n = some g →
      Nonempty (Socket g.op) ∧ Nonempty (Socket (fun x y => g.op y x))) (n : Nat) :
    (d.tree n).signed := by
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    rw [Indexed.tree]
    split
    next => trivial
    next g hg =>
      exact ⟨(hs _ _ hg).1,(hs _ _ hg).2,ih _ (d.back _ _ hg).1,ih _ (d.back _ _ hg).2⟩

private theorem chart_indices : ∀ e ∈ edgeChart, ∃ a b : Fin 10,
    a.val ≠ b.val ∧ 2^a.val = e.1 ∧ 2^b.val = e.2.1 := by decide +kernel

theorem Indexed.bin_independent (d : Indexed) {out cut : Nat} {shared : Nat → Bool} (s : Fin 1024)
    (finalWire : ∀ i j, d.edge i j → i ≠ out)
    (func : ∀ v, shared v = false → ∀ j k, d.edge v j → d.edge v k → j=k)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (signed : (d.tree cut).signed)
    (owns : ∀ a : Fin 10, sub (2^a.val) s.val = true →
      ∃ live : ∃ xs, Path d.edge out a.val xs, owner d.edge out shared a.val live = cut)
    (computes : ∀ row : Nat, edgeHit row = (d.tree out).term.eval row.testBit) :
    edgeHit s.val = false := by
  apply Petersen9822.bin_independent
  intro e mem he hf
  obtain ⟨a,b,ab,ea,eb⟩ := chart_indices e mem
  rw [← ea] at he
  rw [← eb] at hf
  obtain ⟨la,oa⟩ := owns a he
  obtain ⟨lb,ob⟩ := owns b hf
  rw [← ea,← eb]
  exact d.same_owner_LCA ab finalWire func distinct signed la lb oa ob computes
end Petersen9822.DagCut

-- Not9822LiveRaw
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

private theorem rawEdges : ∀ a : Fin 10, ∃ b : Fin 10,
    edgeHit (2^b.val) ≠ edgeHit ((2^b.val) ||| (2^a.val)) := by decide +kernel

theorem Indexed.live_raw (d : Indexed) (out : Nat) (a : Fin 10)
    (sink : ∀ i j, d.edge i j → i ≠ out)
    (computes : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit) :
    ∃ xs, Path d.edge out a.val xs := by
  obtain ⟨b,hb⟩ := rawEdges a
  have occurs : (d.tree out).term.uses a.val := by
    by_contra absent
    apply hb
    rw [computes,computes]
    apply Term.congr
    intro v hit
    have ne : a.val ≠ v := by intro eq; subst v; exact absent hit
    simp [Nat.testBit_two_pow,ne]
  obtain ⟨path,h,_⟩ := Tree.rawPath (d.tree_valid out)
    (show Path d.edge out (d.tree out).id [] by simpa using (Path.stop (edge:=d.edge) (sink:=out))) sink occurs
  exact ⟨path,h⟩

theorem Indexed.ownerBinIndependent (d : Indexed) (out cut : Nat) (shared rep : Nat → Bool)
    (sink : ∀ i j, d.edge i j → i ≠ out)
    (func : ∀ v, shared v = false → ∀ j k, d.edge v j → d.edge v k → j=k)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (signed : (d.tree cut).signed)
    (computes : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit) :
    edgeHit (siteMask rep (assigned d out shared) cut) = false := by
  let m : Fin 1024 := ⟨siteMask rep (assigned d out shared) cut, pack_lt _⟩
  refine d.bin_independent (cut := cut) (shared := shared) m sink func distinct signed ?_ computes
  intro a ha
  have hr : assigned d out shared a.val = cut := by
    rw [subSingleton] at ha
    exact of_decide_eq_true (Bool.and_eq_true_iff.mp
      (show (!rep a.val && decide (assigned d out shared a.val = cut)) = true by
        simpa [m,siteMask,pack_bit,a.isLt] using ha)).2
  let live := d.live_raw out a sink computes
  exact ⟨live,(assigned_live live).symm.trans hr⟩

end Petersen9822.DagCut
