import Not9822Bundle05Sites

-- SignedLCAGraph
namespace Petersen9822
def sectionBit (p a b : Nat) (x y : Bool) : Bool :=
  edgeHit (p ||| (if x then a else 0) ||| (if y then b else 0))

def Passes (pol actual : Bool → Bool) : Prop :=
  (∀ x, actual x = pol x) ∨ actual false = actual true

structure SharedLCA (a b : Nat) where
  left : Bool → Bool
  right : Bool → Bool
  join : Bool → Bool → Bool
  sections : ∀ p, p &&& (a ||| b) = 0 →
    ∃ l r : Bool → Bool, ∃ last : Bool → Bool,
      Passes left l ∧ Passes right r ∧
      ∀ x y, sectionBit p a b x y = last (join (l x) (r y))

private theorem active_section {p a b : Nat} (h : SharedLCA a b)
    (disj : p &&& (a ||| b) = 0)
    (hx : ∃ y, sectionBit p a b false y ≠ sectionBit p a b true y)
    (hy : ∃ x, sectionBit p a b x false ≠ sectionBit p a b x true) :
    ∃ last : Bool → Bool, ∀ x y, sectionBit p a b x y = last (h.join (h.left x) (h.right y)) := by
  obtain ⟨l,r,last,hl,hr,val⟩ := h.sections p disj
  obtain ⟨y,vy⟩ := hx
  obtain ⟨x,vx⟩ := hy
  have nl : l false ≠ l true := by
    intro eq
    exact vy (by rw [val, val, eq])
  have nr : r false ≠ r true := by
    intro eq
    exact vx (by rw [val, val, eq])
  have li := hl.resolve_right nl
  have ri := hr.resolve_right nr
  exact ⟨last,fun x y => by rw [val,li,ri]⟩
private theorem three_codes {a b c : Bool} (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) : False := by
  cases a <;> cases b <;> cases c <;> simp_all
theorem and_or_no_shared {a b p : Nat} (disj : p &&& (a ||| b) = 0)
    (andsec : ∀ x y, sectionBit 0 a b x y = (x && y))
    (orsec : ∀ x y, sectionBit p a b x y = (x || y)) : ¬ Nonempty (SharedLCA a b) := by
  rintro ⟨h⟩
  obtain ⟨postA,A⟩ := active_section h (p:=0) (by simp)
    ⟨true,by simp [andsec]⟩ ⟨true,by simp [andsec]⟩
  obtain ⟨postO,O⟩ := active_section h disj
    ⟨false,by simp [orsec]⟩ ⟨false,by simp [orsec]⟩
  let g := fun x y => h.join (h.left x) (h.right y)
  have af : ∀ x y, (x && y) = postA (g x y) := fun x y => (andsec x y).symm.trans (A x y)
  have ofn : ∀ x y, (x || y) = postO (g x y) := fun x y => (orsec x y).symm.trans (O x y)
  apply three_codes (a:=g false false) (b:=g false true) (c:=g true true)
  · intro e
    have ne := congrArg postO e
    rw [← ofn, ← ofn] at ne
    contradiction
  · intro e
    have ne := congrArg postA e
    rw [← af, ← af] at ne
    contradiction
  · intro e
    have ne := congrArg postA e
    rw [← af, ← af] at ne
    contradiction

def edgeChart : List (Nat × Nat × Nat) := [(2,4,192), (8,16,257), (1,16,40), (1,32,144), (2,64,260), (4,128,34), (8,256,48), (16,512,65), (32,128,5), (128,512,20), (64,512,18), (64,256,10), (32,256,9)]

private theorem chart_sections : ∀ e ∈ edgeChart,
    e.2.2 &&& (e.1 ||| e.2.1) = 0 ∧
    (∀ x y, sectionBit 0 e.1 e.2.1 x y = (x && y)) ∧
    (∀ x y, sectionBit e.2.2 e.1 e.2.1 x y = (x || y)) := by decide +kernel

private theorem chart_hit : ∀ s : Fin 1024,
    edgeHit s.val = edgeChart.any (fun e => sub e.1 s.val && sub e.2.1 s.val) := by
  decide +kernel

theorem bin_independent (s : Fin 1024)
    (owners : ∀ e ∈ edgeChart, sub e.1 s.val = true → sub e.2.1 s.val = true →
      Nonempty (SharedLCA e.1 e.2.1)) : edgeHit s.val = false := by
  cases he : edgeHit s.val with
  | false => rfl
  | true =>
    have ht : edgeChart.any (fun e => sub e.1 s.val && sub e.2.1 s.val) = true :=
      (chart_hit s).symm.trans he
    obtain ⟨e,mem,hh⟩ := List.any_eq_true.mp ht
    obtain ⟨a,b⟩ := Bool.and_eq_true_iff.mp hh
    obtain ⟨dj,hs,ht⟩ := chart_sections e mem
    exact False.elim (and_or_no_shared dj hs ht (owners e mem a b))
end Petersen9822

-- SignedLCALeg
namespace Petersen9822

private theorem same_values {f : Bool → Bool} (h : f false = f true) (x y : Bool) :
    f x = f y := by cases x <;> cases y <;> simp_all

theorem Passes.comp {p q a b : Bool → Bool} (ha : Passes p a) (hb : Passes q b) :
    Passes (fun x => q (p x)) (fun x => b (a x)) := by
  rcases ha with h | h
  · rcases hb with k | k
    · exact Or.inl (fun x => (k (a x)).trans (congrArg q (h x)))
    · exact Or.inr (same_values k _ _)
  · exact Or.inr (congrArg b h)

structure Socket (op : Bool → Bool → Bool) where
  pol : Bool → Bool
  sections : ∀ held, Passes pol (fun v => op v held)

def flip (x : Bool) : Bool := !x
def signedOp (andGate negA negB negOut : Bool) (x y : Bool) : Bool :=
  let a := if negA then !x else x
  let b := if negB then !y else y
  let h := if andGate then a && b else a || b
  if negOut then !h else h

def signedSocket (ag na nb no : Bool) : Socket (signedOp ag na nb no) where
  pol := fun x => if na == no then x else !x
  sections := by
    intro held
    unfold Passes
    cases ag <;> cases na <;> cases nb <;> cases no <;> cases held <;>
      decide

def signedRightSocket (ag na nb no : Bool) : Socket (fun x y => signedOp ag na nb no y x) where
  pol := fun x => if nb == no then x else !x
  sections := by
    intro held
    unfold Passes
    cases ag <;> cases na <;> cases nb <;> cases no <;> cases held <;> decide

/-- Each companion cone is supplied only its frozen exterior data. -/
inductive PrivateLeg where
  | raw
  | step (op : Bool → Bool → Bool) (sock : Socket op)
      (side : Nat → Bool) (rest : PrivateLeg)
def PrivateLeg.eval : PrivateLeg → Nat → Bool → Bool
  | .raw,_,x => x
  | .step op _ side rest,p,x => op (rest.eval p x) (side p)
def PrivateLeg.polarity : PrivateLeg → Bool → Bool
  | .raw,x => x
  | .step _ sock _ rest,x => sock.pol (rest.polarity x)
theorem PrivateLeg.rigid (l : PrivateLeg) (p : Nat) : Passes l.polarity (l.eval p) := by
  induction l with
  | raw => exact Or.inl (fun _ => rfl)
  | step op sock side rest ih => exact ih.comp (sock.sections (side p))

/-- A unary exterior reader may itself represent arbitrary shared downstream logic. -/
def sharedLCA_of_legs {a b : Nat} (l r : PrivateLeg)
    (gate : Bool → Bool → Bool) (tail : Nat → Bool → Bool)
    (compute : ∀ p, p &&& (a ||| b) = 0 → ∀ x y,
      sectionBit p a b x y = tail p (gate (l.eval p x) (r.eval p y))) : SharedLCA a b where
  left := l.polarity
  right := r.polarity
  join := gate
  sections := fun p hp => ⟨l.eval p,r.eval p,tail p,l.rigid p,r.rigid p,compute p hp⟩
end Petersen9822

-- Not9822PrivateOccurrence
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

def Tree.occ (v : Nat) : Tree → Nat
  | .raw n => if n = v then 1 else 0
  | .gate n _ l r => (if n = v then 1 else 0) + (l.occ v + r.occ v)

theorem Indexed.occ_above (d : Indexed) (n v : Nat) (lt : n < v) :
    (d.tree n).occ v = 0 := by
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    rw [Indexed.tree]
    split
    next => simp [Tree.occ,Nat.ne_of_lt lt]
    next g hg =>
      obtain ⟨hl,hr⟩ := d.back n g hg
      simp [Tree.occ,Nat.ne_of_lt lt,ih _ hl (Nat.lt_trans hl lt),ih _ hr (Nat.lt_trans hr lt)]

theorem Indexed.occ_self (d : Indexed) (n : Nat) : (d.tree n).occ n = 1 := by
  rw [Indexed.tree]
  split
  next => simp [Tree.occ]
  next g hg =>
    obtain ⟨hl,hr⟩ := d.back n g hg
    simp [Tree.occ,d.occ_above _ _ hl,d.occ_above _ _ hr]

/-- Moving one private socket downstream can charge every unfolded occurrence
    to the successor. Only the original root itself may be uncharged. -/
theorem Indexed.occ_debit (d : Indexed) {v w : Nat}
    (one : ∀ n, d.edge v n → n = w)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (n : Nat) :
    (d.tree n).occ v ≤ (d.tree n).occ w + (if n = v then 1 else 0) := by
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    rw [Indexed.tree]
    split
    next => simp only [Tree.occ]; omega
    next g hg =>
      obtain ⟨hl,hr⟩ := d.back n g hg
      have l := ih _ hl
      have r := ih _ hr
      have spl := distinct n g hg
      have toL : g.left = v → n = w := fun ez => one n ⟨g,hg,Or.inl ez⟩
      have toR : g.right = v → n = w := fun ez => one n ⟨g,hg,Or.inr ez⟩
      simp only [Tree.occ]
      split at l <;> split at r <;> split_ifs <;> omega

inductive PrivateRoute (d : Indexed) : Nat → Nat → Prop where
  | stop (n : Nat) : PrivateRoute d n n
  | step {v w c : Nat} : d.edge v w → (∀ n, d.edge v n → n = w) →
      PrivateRoute d w c → PrivateRoute d v c

theorem PrivateRoute.mono {d v c} (r : PrivateRoute d v c) : v ≤ c := by
  induction r with
  | stop => rfl
  | step e _ _ ih => exact Nat.le_trans (Nat.le_of_lt (d.chrono e)) ih

theorem PrivateRoute.once {d v c} (r : PrivateRoute d v c)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right) : (d.tree c).occ v ≤ 1 := by
  induction r with
  | stop n => rw [d.occ_self]
  | @step v w c e unique tail ih =>
    have lt := Nat.lt_of_lt_of_le (d.chrono e) tail.mono
    have h := d.occ_debit unique distinct c
    rw [if_neg (Nat.ne_of_gt lt), Nat.add_zero] at h
    exact h.trans ih

theorem privateRoute_of_path {d : Indexed} {out : Nat} {shared : Nat → Bool}
    (func : ∀ v, shared v = false → ∀ j k, d.edge v j → d.edge v k → j=k)
    {v : Nat} {xs : List Nat} (h : Path d.edge out v xs) :
    PrivateRoute d v (first shared out v xs) := by
  induction h with
  | stop => simp [first]; exact .stop _
  | @step v w xs _ e tail ih =>
    cases hv : shared v with
    | true => simpa [first,hv] using PrivateRoute.stop (d:=d) v
    | false =>
      simpa [first,hv] using PrivateRoute.step e (fun _ he => func v hv _ _ he e) ih

theorem owner_occ_once {d : Indexed} {out : Nat} {shared : Nat → Bool}
    (func : ∀ a, shared a = false → ∀ j k, d.edge a j → d.edge a k → j=k)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (v : Nat) (live : ∃ xs, Path d.edge out v xs) :
    (d.tree (owner d.edge out shared v live)).occ v ≤ 1 :=
  (privateRoute_of_path func live.choose_spec).once distinct
end Petersen9822.DagCut
