import SignedScans
import SignedLogicalLayer1

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_48_12 : ¬ Placement [1, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_1_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_2
    · exact node_49_2
theorem node_49_12 : ¬ Placement [1, 2] 49 := by
  apply node_sound (lookup := frozen) (next := [49])
  · exact scan_1_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_49_2
theorem node_48_21 : ¬ Placement [2, 1] 48 := by
  apply node_sound (lookup := frozen) (next := [50])
  · exact scan_2_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_50_1
theorem node_49_21 : ¬ Placement [2, 1] 49 := by
  apply node_sound (lookup := frozen) (next := [51])
  · exact scan_2_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_51_1
theorem node_48_02 : ¬ Placement [0, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49])
  · exact scan_0_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_48_2
    · exact node_49_2
theorem node_49_02 : ¬ Placement [0, 2] 49 := by
  apply node_sound (lookup := frozen) (next := [49])
  · exact scan_0_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_49_2
theorem node_272_12 : ¬ Placement [1, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_1_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_2
    · exact node_280_2
theorem node_280_12 : ¬ Placement [1, 2] 280 := by
  apply node_sound (lookup := frozen) (next := [280])
  · exact scan_1_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_280_2
theorem node_272_21 : ¬ Placement [2, 1] 272 := by
  apply node_sound (lookup := frozen) (next := [274])
  · exact scan_2_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_274_1
theorem node_280_21 : ¬ Placement [2, 1] 280 := by
  apply node_sound (lookup := frozen) (next := [282])
  · exact scan_2_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_282_1
theorem node_272_02 : ¬ Placement [0, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 280])
  · exact scan_0_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_272_2
    · exact node_280_2
theorem node_280_02 : ¬ Placement [0, 2] 280 := by
  apply node_sound (lookup := frozen) (next := [280])
  · exact scan_0_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_280_2
theorem node_288_12 : ¬ Placement [1, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_1_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_2
theorem node_288_21 : ¬ Placement [2, 1] 288 := by
  apply node_sound (lookup := frozen) (next := [290])
  · exact scan_2_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_290_1
theorem node_288_02 : ¬ Placement [0, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288])
  · exact scan_0_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_288_2
theorem node_304_12 : ¬ Placement [1, 2] 304 := by
  apply node_sound (lookup := frozen) (next := [304, 305, 312, 313])
  · exact scan_1_304
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl
    · exact node_304_2
    · exact node_305_2
    · exact node_312_2
    · exact node_313_2
theorem node_305_12 : ¬ Placement [1, 2] 305 := by
  apply node_sound (lookup := frozen) (next := [305, 313])
  · exact scan_1_305
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_305_2
    · exact node_313_2
theorem node_312_12 : ¬ Placement [1, 2] 312 := by
  apply node_sound (lookup := frozen) (next := [312, 313])
  · exact scan_1_312
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_312_2
    · exact node_313_2
theorem node_313_12 : ¬ Placement [1, 2] 313 := by
  apply node_sound (lookup := frozen) (next := [313])
  · exact scan_1_313
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_313_2
theorem node_304_21 : ¬ Placement [2, 1] 304 := by
  apply node_sound (lookup := frozen) (next := [306])
  · exact scan_2_304
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_306_1
theorem node_305_21 : ¬ Placement [2, 1] 305 := by
  apply node_sound (lookup := frozen) (next := [307])
  · exact scan_2_305
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_307_1
theorem node_312_21 : ¬ Placement [2, 1] 312 := by
  apply node_sound (lookup := frozen) (next := [314])
  · exact scan_2_312
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_314_1
theorem node_313_21 : ¬ Placement [2, 1] 313 := by
  apply node_sound (lookup := frozen) (next := [315])
  · exact scan_2_313
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_315_1
theorem node_304_02 : ¬ Placement [0, 2] 304 := by
  apply node_sound (lookup := frozen) (next := [304, 305, 312, 313])
  · exact scan_0_304
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl
    · exact node_304_2
    · exact node_305_2
    · exact node_312_2
    · exact node_313_2
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_305_02 : ¬ Placement [0, 2] 305 := by
  apply node_sound (lookup := frozen) (next := [305, 313])
  · exact scan_0_305
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_305_2
    · exact node_313_2
theorem node_312_02 : ¬ Placement [0, 2] 312 := by
  apply node_sound (lookup := frozen) (next := [312, 313])
  · exact scan_0_312
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_312_2
    · exact node_313_2
theorem node_313_02 : ¬ Placement [0, 2] 313 := by
  apply node_sound (lookup := frozen) (next := [313])
  · exact scan_0_313
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_313_2
theorem node_48_23 : ¬ Placement [2, 3] 48 := by
  apply node_sound (lookup := frozen) (next := [50])
  · exact scan_2_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_50_3
theorem node_49_23 : ¬ Placement [2, 3] 49 := by
  apply node_sound (lookup := frozen) (next := [51])
  · exact scan_2_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_51_3
theorem node_48_32 : ¬ Placement [3, 2] 48 := by
  apply node_sound (lookup := frozen) (next := [48, 49, 56, 57, 112, 176, 304, 560])
  · exact scan_3_48
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_48_2
    · exact node_49_2
    · exact node_56_2
    · exact node_57_2
    · exact node_112_2
    · exact node_176_2
    · exact node_304_2
    · exact node_560_2
theorem node_49_32 : ¬ Placement [3, 2] 49 := by
  apply node_sound (lookup := frozen) (next := [49, 57, 113, 177, 305, 561])
  · exact scan_3_49
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_49_2
    · exact node_57_2
    · exact node_113_2
    · exact node_177_2
    · exact node_305_2
    · exact node_561_2
theorem node_50_13 : ¬ Placement [1, 3] 50 := by
  apply node_sound (lookup := frozen) (next := [50, 51])
  · exact scan_1_50
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_50_3
    · exact node_51_3
theorem node_51_13 : ¬ Placement [1, 3] 51 := by
  apply node_sound (lookup := frozen) (next := [51])
  · exact scan_1_51
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_51_3
theorem node_50_31 : ¬ Placement [3, 1] 50 := by
  apply node_sound (lookup := frozen) (next := [50, 51, 58, 59, 114, 178, 306, 562])
  · exact scan_3_50
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_50_1
    · exact node_51_1
    · exact node_58_1
    · exact node_59_1
    · exact node_114_1
    · exact node_178_1
    · exact node_306_1
    · exact node_562_1
theorem node_51_31 : ¬ Placement [3, 1] 51 := by
  apply node_sound (lookup := frozen) (next := [51, 59, 115, 179, 307, 563])
  · exact scan_3_51
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_51_1
    · exact node_59_1
    · exact node_115_1
    · exact node_179_1
    · exact node_307_1
    · exact node_563_1
theorem node_56_12 : ¬ Placement [1, 2] 56 := by
  apply node_sound (lookup := frozen) (next := [56, 57])
  · exact scan_1_56
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_56_2
    · exact node_57_2
theorem node_57_12 : ¬ Placement [1, 2] 57 := by
  apply node_sound (lookup := frozen) (next := [57])
  · exact scan_1_57
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_57_2
theorem node_112_12 : ¬ Placement [1, 2] 112 := by
  apply node_sound (lookup := frozen) (next := [112, 113])
  · exact scan_1_112
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_112_2
    · exact node_113_2
theorem node_176_12 : ¬ Placement [1, 2] 176 := by
  apply node_sound (lookup := frozen) (next := [176, 177])
  · exact scan_1_176
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_176_2
    · exact node_177_2
theorem node_560_12 : ¬ Placement [1, 2] 560 := by
  apply node_sound (lookup := frozen) (next := [560, 561])
  · exact scan_1_560
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_560_2
    · exact node_561_2
theorem node_113_12 : ¬ Placement [1, 2] 113 := by
  apply node_sound (lookup := frozen) (next := [113])
  · exact scan_1_113
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_113_2
theorem node_177_12 : ¬ Placement [1, 2] 177 := by
  apply node_sound (lookup := frozen) (next := [177])
  · exact scan_1_177
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_177_2
theorem node_561_12 : ¬ Placement [1, 2] 561 := by
  apply node_sound (lookup := frozen) (next := [561])
  · exact scan_1_561
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_561_2
theorem node_56_21 : ¬ Placement [2, 1] 56 := by
  apply node_sound (lookup := frozen) (next := [58])
  · exact scan_2_56
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_58_1
theorem node_57_21 : ¬ Placement [2, 1] 57 := by
  apply node_sound (lookup := frozen) (next := [59])
  · exact scan_2_57
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_59_1
theorem node_112_21 : ¬ Placement [2, 1] 112 := by
  apply node_sound (lookup := frozen) (next := [114])
  · exact scan_2_112
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_114_1
theorem node_176_21 : ¬ Placement [2, 1] 176 := by
  apply node_sound (lookup := frozen) (next := [178])
  · exact scan_2_176
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_178_1
theorem node_560_21 : ¬ Placement [2, 1] 560 := by
  apply node_sound (lookup := frozen) (next := [562])
  · exact scan_2_560
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_562_1
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_113_21 : ¬ Placement [2, 1] 113 := by
  apply node_sound (lookup := frozen) (next := [115])
  · exact scan_2_113
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_115_1
theorem node_177_21 : ¬ Placement [2, 1] 177 := by
  apply node_sound (lookup := frozen) (next := [179])
  · exact scan_2_177
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_179_1
theorem node_561_21 : ¬ Placement [2, 1] 561 := by
  apply node_sound (lookup := frozen) (next := [563])
  · exact scan_2_561
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_563_1
theorem node_56_02 : ¬ Placement [0, 2] 56 := by
  apply node_sound (lookup := frozen) (next := [56, 57])
  · exact scan_0_56
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_56_2
    · exact node_57_2
theorem node_57_02 : ¬ Placement [0, 2] 57 := by
  apply node_sound (lookup := frozen) (next := [57])
  · exact scan_0_57
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_57_2
theorem node_112_02 : ¬ Placement [0, 2] 112 := by
  apply node_sound (lookup := frozen) (next := [112, 113])
  · exact scan_0_112
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_112_2
    · exact node_113_2
theorem node_176_02 : ¬ Placement [0, 2] 176 := by
  apply node_sound (lookup := frozen) (next := [176, 177])
  · exact scan_0_176
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_176_2
    · exact node_177_2
theorem node_560_02 : ¬ Placement [0, 2] 560 := by
  apply node_sound (lookup := frozen) (next := [560, 561])
  · exact scan_0_560
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_560_2
    · exact node_561_2
theorem node_113_02 : ¬ Placement [0, 2] 113 := by
  apply node_sound (lookup := frozen) (next := [113])
  · exact scan_0_113
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_113_2
theorem node_177_02 : ¬ Placement [0, 2] 177 := by
  apply node_sound (lookup := frozen) (next := [177])
  · exact scan_0_177
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_177_2
theorem node_561_02 : ¬ Placement [0, 2] 561 := by
  apply node_sound (lookup := frozen) (next := [561])
  · exact scan_0_561
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_561_2
theorem node_272_23 : ¬ Placement [2, 3] 272 := by
  apply node_sound (lookup := frozen) (next := [274])
  · exact scan_2_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_274_3
theorem node_280_23 : ¬ Placement [2, 3] 280 := by
  apply node_sound (lookup := frozen) (next := [282])
  · exact scan_2_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_282_3
theorem node_272_32 : ¬ Placement [3, 2] 272 := by
  apply node_sound (lookup := frozen) (next := [272, 273, 280, 281, 304, 336, 400, 784])
  · exact scan_3_272
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_272_2
    · exact node_273_2
    · exact node_280_2
    · exact node_281_2
    · exact node_304_2
    · exact node_336_2
    · exact node_400_2
    · exact node_784_2
theorem node_280_32 : ¬ Placement [3, 2] 280 := by
  apply node_sound (lookup := frozen) (next := [280, 281, 312, 344, 408, 792])
  · exact scan_3_280
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_280_2
    · exact node_281_2
    · exact node_312_2
    · exact node_344_2
    · exact node_408_2
    · exact node_792_2
theorem node_274_13 : ¬ Placement [1, 3] 274 := by
  apply node_sound (lookup := frozen) (next := [274, 282])
  · exact scan_1_274
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_274_3
    · exact node_282_3
theorem node_282_13 : ¬ Placement [1, 3] 282 := by
  apply node_sound (lookup := frozen) (next := [282])
  · exact scan_1_282
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_282_3
theorem node_274_31 : ¬ Placement [3, 1] 274 := by
  apply node_sound (lookup := frozen) (next := [274, 275, 282, 283, 306, 338, 346, 402, 786])
  · exact scan_3_274
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_274_1
    · exact node_275_1
    · exact node_282_1
    · exact node_283_1
    · exact node_306_1
    · exact node_338_1
    · exact node_346_1
    · exact node_402_1
    · exact node_786_1
theorem node_282_31 : ¬ Placement [3, 1] 282 := by
  apply node_sound (lookup := frozen) (next := [282, 283, 314, 346, 410, 794])
  · exact scan_3_282
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_282_1
    · exact node_283_1
    · exact node_314_1
    · exact node_346_1
    · exact node_410_1
    · exact node_794_1
theorem node_273_12 : ¬ Placement [1, 2] 273 := by
  apply node_sound (lookup := frozen) (next := [273, 281])
  · exact scan_1_273
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_273_2
    · exact node_281_2
theorem node_281_12 : ¬ Placement [1, 2] 281 := by
  apply node_sound (lookup := frozen) (next := [281])
  · exact scan_1_281
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_281_2
theorem node_336_12 : ¬ Placement [1, 2] 336 := by
  apply node_sound (lookup := frozen) (next := [336, 344])
  · exact scan_1_336
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_336_2
    · exact node_344_2
theorem node_400_12 : ¬ Placement [1, 2] 400 := by
  apply node_sound (lookup := frozen) (next := [400, 408])
  · exact scan_1_400
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_400_2
    · exact node_408_2
theorem node_784_12 : ¬ Placement [1, 2] 784 := by
  apply node_sound (lookup := frozen) (next := [784, 792])
  · exact scan_1_784
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_784_2
    · exact node_792_2
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_344_12 : ¬ Placement [1, 2] 344 := by
  apply node_sound (lookup := frozen) (next := [344])
  · exact scan_1_344
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_344_2
theorem node_408_12 : ¬ Placement [1, 2] 408 := by
  apply node_sound (lookup := frozen) (next := [408])
  · exact scan_1_408
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_408_2
theorem node_792_12 : ¬ Placement [1, 2] 792 := by
  apply node_sound (lookup := frozen) (next := [792])
  · exact scan_1_792
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_792_2
theorem node_273_21 : ¬ Placement [2, 1] 273 := by
  apply node_sound (lookup := frozen) (next := [275])
  · exact scan_2_273
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_275_1
theorem node_281_21 : ¬ Placement [2, 1] 281 := by
  apply node_sound (lookup := frozen) (next := [283])
  · exact scan_2_281
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_283_1
theorem node_336_21 : ¬ Placement [2, 1] 336 := by
  apply node_sound (lookup := frozen) (next := [338])
  · exact scan_2_336
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_338_1
theorem node_400_21 : ¬ Placement [2, 1] 400 := by
  apply node_sound (lookup := frozen) (next := [402])
  · exact scan_2_400
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_402_1
theorem node_784_21 : ¬ Placement [2, 1] 784 := by
  apply node_sound (lookup := frozen) (next := [786])
  · exact scan_2_784
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_786_1
theorem node_344_21 : ¬ Placement [2, 1] 344 := by
  apply node_sound (lookup := frozen) (next := [346])
  · exact scan_2_344
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_346_1
theorem node_408_21 : ¬ Placement [2, 1] 408 := by
  apply node_sound (lookup := frozen) (next := [410])
  · exact scan_2_408
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_410_1
theorem node_792_21 : ¬ Placement [2, 1] 792 := by
  apply node_sound (lookup := frozen) (next := [794])
  · exact scan_2_792
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_794_1
theorem node_273_02 : ¬ Placement [0, 2] 273 := by
  apply node_sound (lookup := frozen) (next := [273, 281])
  · exact scan_0_273
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_273_2
    · exact node_281_2
theorem node_281_02 : ¬ Placement [0, 2] 281 := by
  apply node_sound (lookup := frozen) (next := [281])
  · exact scan_0_281
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_281_2
theorem node_336_02 : ¬ Placement [0, 2] 336 := by
  apply node_sound (lookup := frozen) (next := [336, 344])
  · exact scan_0_336
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_336_2
    · exact node_344_2
theorem node_400_02 : ¬ Placement [0, 2] 400 := by
  apply node_sound (lookup := frozen) (next := [400, 408])
  · exact scan_0_400
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_400_2
    · exact node_408_2
theorem node_784_02 : ¬ Placement [0, 2] 784 := by
  apply node_sound (lookup := frozen) (next := [784, 792])
  · exact scan_0_784
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl
    · exact node_784_2
    · exact node_792_2
theorem node_344_02 : ¬ Placement [0, 2] 344 := by
  apply node_sound (lookup := frozen) (next := [344])
  · exact scan_0_344
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_344_2
theorem node_408_02 : ¬ Placement [0, 2] 408 := by
  apply node_sound (lookup := frozen) (next := [408])
  · exact scan_0_408
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_408_2
theorem node_792_02 : ¬ Placement [0, 2] 792 := by
  apply node_sound (lookup := frozen) (next := [792])
  · exact scan_0_792
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_792_2
theorem node_288_23 : ¬ Placement [2, 3] 288 := by
  apply node_sound (lookup := frozen) (next := [290])
  · exact scan_2_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_290_3
theorem node_288_32 : ¬ Placement [3, 2] 288 := by
  apply node_sound (lookup := frozen) (next := [288, 289, 296, 304, 352, 416, 800])
  · exact scan_3_288
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_288_2
    · exact node_289_2
    · exact node_296_2
    · exact node_304_2
    · exact node_352_2
    · exact node_416_2
    · exact node_800_2
theorem node_290_13 : ¬ Placement [1, 3] 290 := by
  apply node_sound (lookup := frozen) (next := [290])
  · exact scan_1_290
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_290_3
theorem node_290_31 : ¬ Placement [3, 1] 290 := by
  apply node_sound (lookup := frozen) (next := [290, 291, 298, 306, 354, 418, 802])
  · exact scan_3_290
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact node_290_1
    · exact node_291_1
    · exact node_298_1
    · exact node_306_1
    · exact node_354_1
    · exact node_418_1
    · exact node_802_1
theorem node_289_12 : ¬ Placement [1, 2] 289 := by
  apply node_sound (lookup := frozen) (next := [289])
  · exact scan_1_289
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_289_2
end Petersen9822

set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem node_296_12 : ¬ Placement [1, 2] 296 := by
  apply node_sound (lookup := frozen) (next := [296])
  · exact scan_1_296
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_296_2
theorem node_352_12 : ¬ Placement [1, 2] 352 := by
  apply node_sound (lookup := frozen) (next := [352])
  · exact scan_1_352
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_352_2
theorem node_416_12 : ¬ Placement [1, 2] 416 := by
  apply node_sound (lookup := frozen) (next := [416])
  · exact scan_1_416
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_416_2
theorem node_800_12 : ¬ Placement [1, 2] 800 := by
  apply node_sound (lookup := frozen) (next := [800])
  · exact scan_1_800
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_800_2
theorem node_289_21 : ¬ Placement [2, 1] 289 := by
  apply node_sound (lookup := frozen) (next := [291])
  · exact scan_2_289
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_291_1
theorem node_296_21 : ¬ Placement [2, 1] 296 := by
  apply node_sound (lookup := frozen) (next := [298])
  · exact scan_2_296
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_298_1
theorem node_352_21 : ¬ Placement [2, 1] 352 := by
  apply node_sound (lookup := frozen) (next := [354])
  · exact scan_2_352
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_354_1
theorem node_416_21 : ¬ Placement [2, 1] 416 := by
  apply node_sound (lookup := frozen) (next := [418])
  · exact scan_2_416
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_418_1
theorem node_800_21 : ¬ Placement [2, 1] 800 := by
  apply node_sound (lookup := frozen) (next := [802])
  · exact scan_2_800
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_802_1
theorem node_289_02 : ¬ Placement [0, 2] 289 := by
  apply node_sound (lookup := frozen) (next := [289])
  · exact scan_0_289
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_289_2
theorem node_296_02 : ¬ Placement [0, 2] 296 := by
  apply node_sound (lookup := frozen) (next := [296])
  · exact scan_0_296
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_296_2
theorem node_352_02 : ¬ Placement [0, 2] 352 := by
  apply node_sound (lookup := frozen) (next := [352])
  · exact scan_0_352
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_352_2
theorem node_416_02 : ¬ Placement [0, 2] 416 := by
  apply node_sound (lookup := frozen) (next := [416])
  · exact scan_0_416
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_416_2
theorem node_800_02 : ¬ Placement [0, 2] 800 := by
  apply node_sound (lookup := frozen) (next := [800])
  · exact scan_0_800
  · intro k hm
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    subst k
    exact node_800_2
end Petersen9822
