import Not9822Bundle08Neighbors

-- Not9822GuardedPlacement
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

theorem guardedPlacement (d : Indexed) (out : Nat) (rep : Nat → Bool)
    (sites : List (Nat × Nat)) (ord : Ordered sites) (early : ∀ e ∈ sites, e.1 < out)
    (internalOut : 10 ≤ out) (sink : ∀ a b, d.edge a b → a ≠ out)
    (computes : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit)
    (raws : ∀ a b, d.edge a b → 10 ≤ b)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (signed : ∀ n g, d.get n = some g → Nonempty (Socket g.op) ∧ Nonempty (Socket (fun x y => g.op y x)))
    (repeats : ∀ v, v < 10 → rep v = false → fork d v = false)
    (repOne : rep 1 = false) (repTwo : rep 2 = false)
    (enumerates : ∀ k, 10 ≤ k → k ≠ out → fork d k = true → ∃ e ∈ sites, e.1 = k)
    (gates : ∀ e ∈ sites, fork d e.1 = true ∧ ∃ xs, Path d.edge out e.1 xs)
    (ownerOne : ∀ e ∈ sites, assigned d out (fork d) 1 = e.1 ↔ e.2 = 2)
    (ownerTwo : assigned d out (fork d) 2 = out)
    (guards : ∀ e ∈ sites, ownerBit e.2 ≠ 0 → ∃ block, PrivateSockets d e.1 (ownerBit e.2) block)
    : Placement (sites.map Prod.snd) (pack rep) := by
  have coldPow (k : Nat) (h : k ≠ out) : (2^k : Nat).testBit out = false := by
    simp [Nat.testBit_two_pow,h]
  have allIndependent (cut : Nat) := d.ownerBinIndependent out cut (fork d) rep sink (fork_unique d)
    distinct (d.tree_signed signed cut) computes
  apply placementOfSites d out (fork d) rep sites ord early sink (fork_unique d) computes _
    (coverOfShared d out (fork d) rep sites raws repeats enumerates) (allIndependent out)
  intro e he
  obtain ⟨share,live⟩ := gates e he
  have le := early e he
  refine ⟨share,live,Or.inl (by rw [ownerTwo]; omega),?_,?_,?_,allIndependent e.1,
    guards e he,?_⟩
  · simp [repOne, ownerOne e he]
  · intro j
    obtain ⟨block,h⟩ := guards e he (by simp [j,ownerBit])
    have hs : PrivateSockets d e.1 (2^1) block := by simpa [j,ownerBit] using h
    exact Or.inl (neighborGuardUnreachable (v:=6) (i:=1) (p:=260) (by decide)
      sink (fork_unique d) distinct share live le (d.tree_signed signed _) (repeats _ (by decide) repOne)
      (by omega) hs computes)
  · intro j
    obtain ⟨block,h⟩ := guards e he (by simp [j,ownerBit])
    have hs : PrivateSockets d e.1 (2^2) block := by simpa [j,ownerBit] using h
    exact Or.inl (neighborGuardUnreachable (v:=7) (i:=2) (p:=34) (by decide)
      sink (fork_unique d) distinct share live le (d.tree_signed signed _) (repeats _ (by decide) repTwo)
      (by omega) hs computes)
  · by_cases h : e.2 < 2
    · have casesJ : e.2 = 0 ∨ e.2 = 1 := by omega
      rcases casesJ with h0 | h1
      · change (ownerBit e.2).testBit out = false
        rw [h0]
        change (2^1 : Nat).testBit out = false
        exact coldPow 1 (by omega)
      · rw [h1]
        change (2^2 : Nat).testBit out = false
        exact coldPow 2 (by omega)
    · simp [ownerBit,h]

end Petersen9822.DagCut

-- Not9822OwnerSeparation
namespace Petersen9822.DagCut
open Petersen9822.FirstSite

theorem ownersSeparate (d : Indexed) (out : Nat) (shared : Nat → Bool)
    (sink : ∀ i j, d.edge i j → i ≠ out)
    (func : ∀ a, shared a = false → ∀ j k, d.edge a j → d.edge a k → j=k)
    (distinct : ∀ n g, d.get n = some g → g.left ≠ g.right)
    (signed : ∀ n g, d.get n = some g → Nonempty (Socket g.op) ∧ Nonempty (Socket (fun x y => g.op y x)))
    (computes : ∀ row, edgeHit row = (d.tree out).term.eval row.testBit) :
    assigned d out shared 1 ≠ assigned d out shared 2 := by
  intro eq
  let l1 := d.live_raw out (1 : Fin 10) sink computes
  let l2 := d.live_raw out (2 : Fin 10) sink computes
  have own1 : owner d.edge out shared 1 l1 = assigned d out shared 2 := (assigned_live l1).symm.trans eq
  have same := d.same_owner_LCA (a:=1) (b:=2) (by decide) sink func distinct
    (d.tree_signed signed _) l1 l2 own1 (assigned_live l2).symm computes
  exact and_or_no_shared (a:=2) (b:=4) (p:=192) (by decide +kernel)
    (by decide +kernel) (by decide +kernel) same

theorem threeSiteOrientation {A B out g₁ g₂ q : Nat}
    (coverA : A = out ∨ A = g₁ ∨ A = g₂ ∨ A = q)
    (coverB : B = out ∨ B = g₁ ∨ B = g₂ ∨ B = q)
    (ownA : g₁ < A) (ownB : g₂ < B)
    (otherA : A ≠ g₂) (otherB : B ≠ g₁) (apart : A ≠ B) :
    (A = q ∧ B = out ∧ g₁ < q) ∨ (B = q ∧ A = out ∧ g₂ < q) := by
  rcases coverA with h|h|h|h <;> rcases coverB with k|k|k|k <;> omega

theorem fourSiteOrientation {A B out g₁ g₂ q w : Nat}
    (coverA : A = out ∨ A = g₁ ∨ A = g₂ ∨ A = q ∨ A = w)
    (coverB : B = out ∨ B = g₁ ∨ B = g₂ ∨ B = q ∨ B = w)
    (ownA : g₁ < A) (ownB : g₂ < B)
    (otherA : A ≠ g₂) (otherB : B ≠ g₁) (apart : A ≠ B)
    (oneOutput : A = out ∨ B = out) :
    (B = out ∧ (A = q ∨ A = w) ∧ g₁ < A) ∨
    (A = out ∧ (B = q ∨ B = w) ∧ g₂ < B) := by
  rcases coverA with h|h|h|h|h <;> rcases coverB with k|k|k|k|k <;> omega

end Petersen9822.DagCut
