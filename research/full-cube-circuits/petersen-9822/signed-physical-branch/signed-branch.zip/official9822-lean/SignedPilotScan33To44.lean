import SignedNode
import SignedLookup9822
set_option maxRecDepth 16384
set_option maxHeartbeats 0
namespace Petersen9822
theorem scan_1_51 : nodeCheck frozen 1 51 [51] = true := by decide +kernel
theorem scan_1_56 : nodeCheck frozen 1 56 [56, 57] = true := by decide +kernel
theorem scan_1_57 : nodeCheck frozen 1 57 [57] = true := by decide +kernel
theorem scan_1_58 : nodeCheck frozen 1 58 [58, 59, 122, 123, 314, 315, 570, 571, 826, 827] = true := by decide +kernel
theorem scan_1_59 : nodeCheck frozen 1 59 [59, 123, 315, 571, 827] = true := by decide +kernel
theorem scan_1_112 : nodeCheck frozen 1 112 [112, 113] = true := by decide +kernel
theorem scan_1_113 : nodeCheck frozen 1 113 [113] = true := by decide +kernel
theorem scan_1_114 : nodeCheck frozen 1 114 [114, 115, 122, 123, 370, 371, 626, 627, 634, 635, 882, 883] = true := by decide +kernel
theorem scan_1_115 : nodeCheck frozen 1 115 [115, 123, 371, 627, 635, 883] = true := by decide +kernel
theorem scan_1_176 : nodeCheck frozen 1 176 [176, 177] = true := by decide +kernel
theorem scan_1_177 : nodeCheck frozen 1 177 [177] = true := by decide +kernel
theorem scan_1_178 : nodeCheck frozen 1 178 [178, 179, 186, 187, 242, 243, 434, 435, 690, 691, 698, 699] = true := by decide +kernel
end Petersen9822
