import Not9822Bundle03Sockets

namespace Petersen9822.Potential
structure SignedOp where
  isOr : Bool
  leftNeg : Bool
  rightNeg : Bool
  outNeg : Bool

def SignedOp.bit (o : SignedOp) (a b : Bool) : Bool :=
  let x := if o.leftNeg then !a else a
  let y := if o.rightNeg then !b else b
  let z := if o.isOr then x || y else x && y
  if o.outNeg then !z else z

open Petersen9822.DagCut
structure Fifteen (d : Indexed) : Prop where
  raw : ∀ v, v < 10 → d.get v = none
  present : ∀ v, 10 ≤ v → v < 25 → ∃ g, d.get v = some g
  extent : ∀ v g, d.get v = some g → 10 ≤ v ∧ v < 25
end Petersen9822.Potential

namespace Petersen9822.DagCut
def wireValue (d : Indexed) (n row : Nat) : Bool := (d.tree n).term.eval row.testBit

open Petersen9822.Potential Petersen9822.FirstSite
structure FifteenCore (d : Indexed) (out : Nat) where
  diagram : Fifteen d
  lowerOut : 10 ≤ out
  upperOut : out < 25
  finalWire : ∀ a b, d.edge a b → a ≠ out
  live : ∀ v, 10 ≤ v → v < 25 → ∃ xs, Path d.edge out v xs
  properSockets : ∀ n g, d.get n = some g → g.left ≠ g.right
  op : Nat → Potential.SignedOp
  signed : ∀ n g, d.get n = some g → ∀ a b, g.op a b = (op n).bit a b
  computes : ∀ row, edgeHit row = wireValue d out row
end Petersen9822.DagCut
