import Not9822ReaderSaving
import CompactRows9822
namespace Petersen9822.DagCut
open Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine
open Research.Signed9822

def onMoved (d : Indexed) (moves : List Move) (n : Nat) (r : Row) :=
  wireValue d n (movedRow moves r).val

theorem targetRows (r : Row) : observe target r = edgeHit r.val := by
  have eq : sample r = fun i : Fin 10 => r.val.testBit i.val := funext (fun i => input_bits i r)
  change bit r target = _
  rw [onRows,eq]
  exact (PEqualNP.Outside.L_meta_9822.Compact.rowEdge r.val).symm

theorem moved_raw {d out} (c : FifteenCore d out) (moves : List Move) (i : Fin 10) :
    onMoved d moves i.val = observe (rename (movedRow moves) (inputs.getD i.val zero)) := by
  rw [observe_rename]
  funext r
  change wireValue d i.val (movedRow moves r).val = observe (inputs.getD i.val zero) (movedRow moves r)
  rw [input_bits]
  simp [wireValue,d.tree_none (c.diagram.raw _ i.isLt),Tree.term,Term.eval]

theorem moved_output {d out} (c : FifteenCore d out) {moves : List Move} {G : Sig}
    (eq : rename (movedRow moves) target = G) : onMoved d moves out = observe G := by
  rw [←eq,observe_rename]
  funext r
  exact (c.computes _).symm.trans (targetRows _).symm

theorem moved_gate {d out} (c : FifteenCore d out) (moves : List Move) {n g} (hg : d.get n = some g) :
    onMoved d moves n = (c.op n).apply (onMoved d moves g.left) (onMoved d moves g.right) := by
  funext r
  rw [op_eval]
  simp only [onMoved,wireValue,d.tree_some hg,Tree.term,Term.eval,c.signed n g hg]

theorem unaryOfConstantOperand {d out} (c : FifteenCore d out) (moves : List Move)
    {i n : Nat} (cold : Constant (onMoved d moves i)) (edge : d.edge i n) :
    ∃ j < n, ∃ f : Bool → Bool, onMoved d moves n = fun r => f (onMoved d moves j r) := by
  obtain ⟨g,eq,side⟩ := edge
  obtain ⟨b,hb⟩ := cold
  have lt := d.back n g eq
  have form := moved_gate c moves eq
  rcases side with l | r
  · refine ⟨g.right,lt.2,fun y => (c.op n).bit b y,?_⟩
    rw [form,l,hb]; funext r; exact op_eval _ _ _ r
  · refine ⟨g.left,lt.1,fun x => (c.op n).bit x b,?_⟩
    rw [form,r,hb]; funext r; exact op_eval _ _ _ r

set_option maxRecDepth 4000 in
set_option exponentiation.threshold 1024 in
theorem moved_inputs {d out} (c : FifteenCore d out) {moves : List Move} {base : List Sig} {G : Sig}
    (ok : checkMap moves inputs target base G = true) :
    ∀ i, i < 10 → Available true (base.map observe) (onMoved d moves i) := by
  obtain ⟨_,sub⟩ := map_correct (u:=true) ok
  have member : ∀ i : Fin 10, inputs.getD i.val zero ∈ inputs := by decide +kernel
  intro i hi
  rw [moved_raw c moves ⟨i,hi⟩]
  exact sub _ (member ⟨i,hi⟩)

theorem soleOnFourteen {d out} (c : FifteenCore d out) {i : Nat} (moves : List Move)
    (base : List Sig) (G : Sig) (ok : checkMap moves inputs target base G = true)
    (floor : Lower true base G 14) (cold : Constant (onMoved d moves i)) : fork d i = false := by
  classical
  cases hot : fork d i with
  | false => rfl
  | true =>
    obtain ⟨a,b,ea,eb,ne⟩ := of_decide_eq_true hot
    have bounds (n : Nat) (e : d.edge i n) : 10 ≤ n ∧ n < 25 := by
      obtain ⟨g,h,_⟩ := e; exact c.diagram.extent n g h
    have ba := bounds a ea
    have bb := bounds b eb
    obtain ⟨k,bank,budget,run,avail⟩ := saveTwo (onMoved d moves) (base.map observe) a b
      ba.1 bb.1 ba.2 bb.2 ne (moved_inputs c ok)
      (fun n h => unaryOfConstantOperand c moves cold (by rcases h with rfl | rfl <;> assumption))
      (by
        intro n lo hi _ _
        obtain ⟨g,h⟩ := c.diagram.present n lo hi
        have less := d.back n g h
        exact ⟨g.left,less.1,g.right,less.2,c.op n,moved_gate c moves h⟩)
    have hit := avail out c.upperOut
    rw [moved_output c (map_correct (u:=true) ok).1] at hit
    have min := floor k bank run hit
    omega

end Petersen9822.DagCut
