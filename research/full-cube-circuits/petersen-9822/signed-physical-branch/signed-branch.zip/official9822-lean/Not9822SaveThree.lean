import Not9822ReaderSaving
namespace Petersen9822.Potential
open PEqualNP.Outside.L_meta_9825.Engine

theorem saveThree {R : Type} (w : Nat → Wire R) (roots : List (Wire R)) (A B C : Nat)
    (aLo : 10 ≤ A) (bLo : 10 ≤ B) (aHi : A < 25) (bHi : B < 25) (cLo : 10 ≤ C) (cHi : C < 25) (ne : A ≠ B) (ac : A ≠ C) (bc : B ≠ C)
    (input : ∀ i, i < 10 → Available true roots (w i))
    (free : ∀ n, n = A ∨ n = B ∨ n = C → ∃ j < n, ∃ f : Bool → Bool, w n = fun r => f (w j r))
    (paid : ∀ n, 10 ≤ n → n < 25 → n ≠ A → n ≠ B → n ≠ C →
      ∃ j < n, ∃ k < n, ∃ op : SignedOp, w n = op.apply (w j) (w k)) :
    ∃ k b, k ≤ 12 ∧ Reach true roots k b ∧ ∀ i, i < 25 → Available true b (w i) := by
  have progress (len : Nat) (hi : len ≤ 15) :
      ∃ k b, k+(if A < 10+len then 1 else 0)+(if B < 10+len then 1 else 0)+(if C < 10+len then 1 else 0) ≤ len ∧
        Reach true roots k b ∧ ∀ i, i < 10+len → Available true b (w i) := by
    induction len with
    | zero => exact ⟨0,roots,by simp [Nat.not_lt_of_ge aLo,Nat.not_lt_of_ge bLo,Nat.not_lt_of_ge cLo],Reach.start,input⟩
    | succ t ih =>
      obtain ⟨k,b,count,run,seen⟩ := ih (by omega)
      let n := 10+t
      by_cases special : n = A ∨ n = B ∨ n = C
      · obtain ⟨j,early,f,eq⟩ := free n special
        refine ⟨k,b,?_,run,?_⟩
        · dsimp [n] at special
          split_ifs at * <;> omega
        · intro i lim
          by_cases last : i = n
          · rw [last,eq]; exact unaryAvailable f (seen j early)
          · exact seen i (by dsimp [n] at last; omega)
      · obtain ⟨j,hj,l,hl,op,eq⟩ := paid n (by dsimp [n]; omega) (by dsimp [n]; omega)
          (fun e => special (Or.inl e)) (fun e => special (Or.inr (Or.inl e))) (fun e => special (Or.inr (Or.inr e)))
        obtain ⟨next,rNext,ready,grows⟩ := paidSignedStep op run (seen j hj) (seen l hl)
        refine ⟨k+1,next,?_,rNext,?_⟩
        · dsimp [n] at special
          split_ifs at * <;> omega
        · intro i lim
          by_cases last : i = n
          · simpa only [last,eq] using ready
          · exact grows _ (seen i (by dsimp [n] at last; omega))
  obtain ⟨k,b,count,run,seen⟩ := progress 15 (by decide)
  exact ⟨k,b,by simp [aHi,bHi,cHi] at count; omega,run,seen⟩

end Petersen9822.Potential
