import OR9822H1Geometry
namespace Research.Graph9822OneHidden
open Research.Graph9822TwoHidden

def safepoint (hn : N1 → Prop) (v : V1) := ∀ n, hn n → negRaw n v ≠ true

structure Grant1 {P : Type} (p : Arms (Option V1)) (hn : N1 → Prop)
    (pos : P → V1 → Prop) (hp : P → Prop) (c : Option V1) : Prop where
  loose : ∀ e,p.accepts (fun l e => oneRow (pos e) (hp e) l) e →
    (∃ v,c=some v ∧ pos e v) ∨ (hp e ∧ ∃ v,pos e v ∧ safepoint hn v)
  firm : ∀ v,c=some v →
    (∀ e,p.accepts (fun l e => oneRow (pos e) (hp e) l) e → pos e v) ∨
    (∀ e,p.accepts (fun l e => oneRow (pos e) (hp e) l) e →
      (pos e v ∨ hp e) ∧ ∃ u,pos e u ∧ adjacent1 v u ∧ safepoint hn u)

theorem chooseGrant1 {P} (p : Arms (Option V1)) (hn : N1 → Prop)
    (pos : P → V1 → Prop) (hp : P → Prop) (leak : ∃ n,hn n)
    (safe : ∀ n,¬p.accepts (fun l n => oneRow (fun v => negRaw n v=true) (hn n) l) n) :
    ∃ c,Grant1 p hn pos hp c := by
  classical
  rcases orient1 p hn safe with none|⟨v,s,which,_,short,_,long⟩
  · refine ⟨Option.none,⟨?_,by simp⟩⟩
    intro e accepted
    right
    obtain ⟨⟨a,la,oa⟩,⟨b,rb,ob⟩⟩ := accepted
    cases a with
    | none =>
      cases b with
      | none =>
        obtain ⟨n,on⟩ := leak
        exact (safe n ⟨⟨_,la,on⟩,⟨_,rb,on⟩⟩).elim
      | some y => exact ⟨oa,y,ob,fun n on hot => safe n ⟨⟨_,la,on⟩,⟨_,rb,hot⟩⟩⟩
    | some x =>
      cases b with
      | none => exact ⟨ob,x,oa,fun n on hot => safe n ⟨⟨_,la,hot⟩,⟨_,rb,on⟩⟩⟩
      | some y => exact (none x y ⟨la,rb⟩).elim
  · have same {R : Type} (test : Option V1 → R → Prop) (e : R) :
        s.accepts test e ↔ p.accepts test e := by
      rcases which with rfl|rfl
      · rfl
      · exact reverse1_accepts _ _ _
    have grants := star_grant s v (fun n u => negRaw n u=true) hn pos hp (adjacent1 v)
      short long leak (fun n acc => safe n ((same _ _).mp acc))
    refine ⟨some v,⟨?_,?_⟩⟩
    · intro e accept
      have acc := (same _ _).mpr accept
      rcases grants with weak|strong
      · exact Or.inl ⟨v,rfl,weak e acc⟩
      · obtain ⟨raw|hidden,u,pu,_,su⟩ := strong e acc
        · exact Or.inl ⟨v,rfl,raw⟩
        · exact Or.inr ⟨hidden,u,pu,su⟩
    · rintro u eq
      have : v=u := Option.some.inj eq
      subst u
      rcases grants with weak|strong
      · exact Or.inl fun e acc => weak e ((same _ _).mpr acc)
      · exact Or.inr fun e acc => strong e ((same _ _).mpr acc)
end Research.Graph9822OneHidden
#print axioms Research.Graph9822OneHidden.chooseGrant1
