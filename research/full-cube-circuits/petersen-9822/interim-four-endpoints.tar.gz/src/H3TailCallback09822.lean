import H3TailNumericCallbacks9822
namespace Research.H3TailGroups.Case0
def groups : Array Nat := #[0,1,2,0,1,3,4,5,6,5,1,1,2,2,6,6]
def edges : Array Nat := #[1030,24,17,33,3138,3204,264,528,160,2688,2624,320,288]
def negs : Array Nat := #[50,77,108,2164,139,3273,3280,276,387,2450,523,525,554,556,771,773]
def bans : Array Nat := #[2166,719,622,3273,3280,2454,903]
def apart : Array Nat := #[2454762525226500368,7364229910460633857,3674993452920279089,2454762524974842128,7364229910459585281,6067285568159748945,2454762248402456852,2454761972266283292,14467512012252002,2454761972249493784,7364229910459585281,7364229910460633857,3674993452920279089,3674993452920279089,14467512012252002,14467512013300578]
def covers : Array Nat := #[52776608465664,688285290817,824669381312,93459914444805,112151897702400,158362155550608,998579900296]
def reps : Array Nat := #[0,1,2,5,6,7,8]
def surjAt (g : Fin 7) := groupAt groups (Fin.ofNat 16 (reps[g.val]?.getD 0)) == g
theorem onto : Function.Surjective (groupAt groups) := by
  have good : (List.finRange 7).all surjAt = true := by decide +kernel
  intro g
  exact ⟨_,beq_iff_eq.mp (List.all_eq_true.mp good g (List.mem_finRange g))⟩
set_option maxRecDepth 10000 in
set_option maxHeartbeats 5000000 in
theorem classes : (List.finRange 16).all (classPage groups edges negs apart) = true := by decide +kernel
set_option maxRecDepth 10000 in
set_option maxHeartbeats 5000000 in
theorem prohibited : (List.finRange 7).all (banPage groups bans negs covers) = true := by decide +kernel
end Research.H3TailGroups.Case0
