import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class084 : runPacket packets[84]! = true := by decide +kernel
theorem class085 : runPacket packets[85]! = true := by decide +kernel
theorem class086 : runPacket packets[86]! = true := by decide +kernel
theorem class087 : runPacket packets[87]! = true := by decide +kernel
end Research.Graph9822FirstBroad
