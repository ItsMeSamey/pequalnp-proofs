import OR9822FiveMinimum
import OR9822ParetoSubstitution
import RowCover

namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FourSaturation
open Research.Graph9822.FeatureRun (WireLE read_mono run_mono)

def resultOn (ps : List Product) (out : Arm) (m : Nat) : Bool :=
  readArm (run ps 10 (fullWire m)) out

theorem result_mono (ps : List Product) (out : Arm) (x y : Nat)
    (le : below x y = true) : resultOn ps out x = true → resultOn ps out y = true := by
  apply read_mono (run_mono _ ps 10)
  intro j hot
  have parts : j<10 ∧ x.testBit j = true := by simpa [fullWire] using hot
  have eq : x &&& y = x := by simpa [below] using le
  have bit := congrArg (fun m : Nat => m.testBit j) eq
  simpa [fullWire,parts.1] using (show y.testBit j = true by simpa [parts.2] using bit)

def fromRows (ps : List Product) (out : Arm) (count : ps.length = 5)
    (ordered : Chronological 10 ps out) (disjoint : ∀ p ∈ ps, ∀ i ∈ p.1, i ∉ p.2)
    (pos : ∀ e ∈ edges, resultOn ps out (edgeMask e) = true)
    (neg : ∀ m ∈ witnesses, resultOn ps out m = false) : FiveProgram where
  products := ps
  out := out
  count := count
  ordered := ordered
  disjoint := disjoint
  correct := checked_rows_suffice (resultOn ps out) (result_mono ps out) pos neg

end Research.Graph9822.FreeOR
