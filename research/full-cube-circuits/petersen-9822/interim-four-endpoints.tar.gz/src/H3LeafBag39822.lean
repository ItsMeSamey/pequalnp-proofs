import H3LeafGroup249822
import H3LeafGroup259822
import H3LeafGroup269822
import H3LeafGroup279822
import H3LeafGroup289822
import H3LeafGroup299822
import H3LeafGroup309822
import H3LeafGroup319822
namespace Research.Graph9822H3Leaf
def bag3 : List (Nat × Nat) := gs24 ++ gs25 ++ gs26 ++ gs27 ++ gs28 ++ gs29 ++ gs30 ++ gs31
theorem bagOK3 : bag3.all (fun (h,s) => leafCheck h s)=true := by simp [bag3,pass24,pass25,pass26,pass27,pass28,pass29,pass30,pass31]
end Research.Graph9822H3Leaf
