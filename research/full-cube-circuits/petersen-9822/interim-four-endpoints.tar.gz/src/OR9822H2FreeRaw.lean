import OR9822H2RawMask
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)

private theorem collect_bit (ok : Nat → Bool) (xs : List Nat) (acc v : Nat) :
    (xs.foldl (fun a i => if ok i then a ||| bit i else a) acc).testBit v = true ↔
    acc.testBit v = true ∨ v ∈ xs ∧ ok v = true := by
  induction xs generalizing acc with
  | nil => simp
  | cons i xs ih =>
    simp only [List.foldl_cons,ih,List.mem_cons]
    cases yes : ok i <;> by_cases eq : v=i <;> first | subst v | have rev : i ≠ v := Ne.symm eq
    all_goals
      simp_all [Nat.testBit_two_pow,bit,or_assoc,or_left_comm,or_comm]

theorem freeRaw_member (f v : Nat) : (freeRaw f).testBit v = true ↔
    v<10 ∧ meets f (rawNeg (bit v)) = false := by
  have eq : freeRaw f = vs.foldl
      (fun a i => if !meets f (rawNeg (bit i)) then a ||| bit i else a) 0 := by
    unfold freeRaw
    congr 1
    funext a i
    cases meets f (rawNeg (bit i)) <;> rfl
  rw [eq,collect_bit]
  simp [vs]

theorem singleton_raw_neg (v : Fin 10) (n : Fin 16) :
    (rawNeg (bit v.val)).testBit n.val = Research.Graph9822.FourSaturation.witnesses[n.val]!.testBit v.val := by
  rw [raw_neg_bit]
  apply Bool.eq_iff_iff.mpr
  simp [meets_iff_exists,Nat.testBit_two_pow,bit]

end Research.Graph9822H2Check
