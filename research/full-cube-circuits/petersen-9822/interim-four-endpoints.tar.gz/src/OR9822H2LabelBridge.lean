import OR9822H2StepSound
import OR9822H2MaskLogic
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)

def witnessAllowed (h u v : Nat) : Bool :=
  if u == 11 then v != 11 else v == 11 || !meets (fixedNeg h u) (fixedNeg h v)
def forbidden (h u v : Nat) : Nat :=
  if u == 11 then fixedNeg h v else if v == 11 then fixedNeg h u else 0
def selectedPos (i a c : Nat) : Nat := if a == 11 || c == 11 then bit i else 0

theorem zero_holds (q : Nat) : holds q 0 := by simp [holds,sub]
theorem union_holds {s r q : Nat} (a : holds q s) (b : holds q r) :
    holds q (s ||| r) := join_subset a b

theorem left_shift_join (x y n : Nat) : (x ||| y) <<< n = (x <<< n) ||| (y <<< n) := by
  apply Nat.eq_of_testBit_eq
  intro k
  by_cases ge : k ≥ n <;> simp [Nat.testBit_shiftLeft,ge]

private theorem fold_forbidden (h q : Nat) (pairs : List (Nat × Nat)) (acc : Nat)
    (start : holds q (acc <<< 13))
    (safe : ∀ p ∈ pairs, holds q (forbidden h p.1 p.2 <<< 13)) :
    holds q ((pairs.foldl (fun f p => f ||| forbidden h p.1 p.2) acc) <<< 13) := by
  induction pairs generalizing acc with
  | nil => exact start
  | cons p ps ih =>
    apply ih
    · rw [left_shift_join]
      exact union_holds start (safe p List.mem_cons_self)
    · intro k hk; exact safe k (List.mem_cons_of_mem _ hk)

theorem numeric_label_witness (h q i j a b c d : Nat)
    (ai : a ∈ labels h i) (bj : b ∈ labels h j) (ci : c ∈ labels h i) (dj : d ∈ labels h j)
    (edgeI : holds q (selectedPos i a c)) (edgeJ : holds q (selectedPos j b d))
    (cross : ∀ p ∈ [(a,c),(a,d),(b,c),(b,d)], witnessAllowed h p.1 p.2 = true ∧
      holds q (forbidden h p.1 p.2 <<< 13)) :
    ∃ r ∈ rescue h i j, holds q r := by
  let pairs := [(a,c),(a,d),(b,c),(b,d)]
  let f := pairs.foldl (fun acc p => acc ||| forbidden h p.1 p.2) 0
  let r := demand (selectedPos i a c ||| selectedPos j b d) f
  have ok : pairs.all (fun p => witnessAllowed h p.1 p.2) = true :=
    List.all_eq_true.mpr (fun p hp => (cross p hp).1)
  have val : pairDemand h i j a b c d = some r := by
    change (do
      guard (pairs.all (fun p => witnessAllowed h p.1 p.2) = true)
      pure r) = some r
    simp [ok]
  have hit : holds q r := union_holds (union_holds edgeI edgeJ)
    (fold_forbidden h q pairs 0 (by simpa using zero_holds q) (fun p hp => (cross p hp).2))
  have mem : r ∈ (do
    let a ← labels h i
    let b ← labels h j
    let c ← labels h i
    let d ← labels h j
    (pairDemand h i j a b c d).toList : List Nat) := by
    simp only [List.bind_eq_flatMap,List.mem_flatMap]
    exact ⟨a,ai,b,bj,c,ci,d,dj,by simp [val]⟩
  obtain ⟨s,hs,weak⟩ := minimal_weakens mem
  exact ⟨s,hs,weaker_holds weak hit⟩

end Research.Graph9822H2Check
