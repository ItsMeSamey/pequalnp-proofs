import OR9822H1Geometry
import And9822CollectorShape
import OR9822ArmMask
namespace Research.Graph9822.FreeOR
open Research.Graph9822.FeatureRun Research.Graph9822Resolution
open Research.Graph9822TwoHidden Research.Graph9822OneHidden

def rawArms1 (p : Product) : Arms (Option (Fin 10)) :=
  ⟨fun v => v.elim (10∈p.1) (fun x => x.val∈p.1),
   fun v => v.elim (10∈p.2) (fun x => x.val∈p.2)⟩
def hidden1 (p : Product) (m : Nat) : Bool := productBit (fullWire m) p
def test1 (p : Product) (m : Nat) (l : Option (Fin 10)) :=
  oneRow (fun v => m.testBit v.val=true) (hidden1 p m=true) l

private theorem read1 (m : Nat) (b : Bool) (xs : Arm) (below : ∀ j∈xs,j<11) :
    readArm (Function.update (fullWire m) 10 b) xs = true ↔
    ∃ l : Option (Fin 10), l.elim (10∈xs) (fun x => x.val∈xs) ∧
      oneRow (fun v : Fin 10 => m.testBit v.val=true) (b=true) l := by
  change xs.any _ = true ↔ _
  rw [List.any_eq_true]
  constructor
  · rintro ⟨j,hj,on⟩
    by_cases e : j=10
    · subst j; exact ⟨none,hj,by simpa [oneRow] using on⟩
    · have lt : j<10 := by have := below j hj; omega
      exact ⟨some ⟨j,lt⟩,hj,by simpa [oneRow,Function.update_of_ne e,fullWire,lt] using on⟩
  · rintro ⟨_|v,h,on⟩
    · exact ⟨10,h,by simpa [oneRow] using on⟩
    · exact ⟨v.val,h,by simpa [oneRow,Function.update_of_ne (Nat.ne_of_lt v.isLt),fullWire,v.isLt] using on⟩

theorem term_rows1 (p q : Product) (m : Nat) (below : Below 11 q) :
    productBit (run [p] 10 (fullWire m)) q = true ↔
      (rawArms1 q).accepts (fun l (_ : Unit) => test1 p m l) () := by
  change (readArm (Function.update (fullWire m) 10 (hidden1 p m)) q.1 && readArm (Function.update (fullWire m) 10 (hidden1 p m)) q.2)=true ↔ _
  rw [Bool.and_eq_true,read1 m (hidden1 p m) q.1 below.1,read1 m (hidden1 p m) q.2 below.2]
  rfl

theorem physical1 (c : FiveProgram) (p : Product) (hp : (hiddenFirst c).1=[p]) :
    ∃ terms : Fin 4 → Product,
    (∀ i, terms i∈(hiddenFirst c).2) ∧
    (∀ q∈(hiddenFirst c).2,∃ i,terms i=q) ∧
    (∀ i, Apart (terms i) ∧ Below 11 (terms i)) ∧
    (∀ i : Fin 13, ∃ k, (rawArms1 (terms k)).accepts
      (fun l (_ : Unit) => test1 p (edges[i.val]!) l) ()) ∧
    (∀ k (n : Fin 16), ¬(rawArms1 (terms k)).accepts
      (fun l n => oneRow (fun v => negRaw n v=true)
        (hidden1 p (Research.Graph9822.FourSaturation.witnesses[n.val]!)=true) l) n) := by
  classical
  let ts := (hiddenFirst c).2
  have len : ts.length=4 := by
    have h := (hidden_first_sizes c).1
    rw [hp] at h
    simpa [ts] using (show (hiddenFirst c).2.length=4 by simp at h;omega)
  let term (k : Fin 4) := ts[k.val]'(by omega)
  have mem (k : Fin 4) : term k∈ts := List.getElem_mem ..
  have complete (q) (hq : q∈ts) : ∃ k, term k=q := by
    obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hq
    exact ⟨⟨i,by omega⟩,eq⟩
  have under (k) := (hidden_first_shape c).2.2 (term k) (mem k)
  simp only [hp,List.length_cons,List.length_nil,Nat.reduceAdd] at under
  refine ⟨term,mem,complete,under,?_,?_⟩
  · intro i
    let r : Fin 29 := ⟨i.val,by omega⟩
    have h := hidden_first_rows c r
    rw [hp] at h
    have raw : rawRow r=edges[i.val]! := by simp [rawRow,r,i.isLt]
    rw [raw] at h
    rw [show decide (r.val<13)=true from decide_eq_true i.isLt] at h
    obtain ⟨q,hq,on⟩ := List.any_eq_true.mp h
    obtain ⟨k,rfl⟩ := complete q hq
    exact ⟨k,(term_rows1 _ _ _ (under k).2).mp on⟩
  · intro k n hit
    let r : Fin 29 := ⟨13+n.val,by omega⟩
    have h := hidden_first_rows c r
    rw [hp] at h
    have raw : rawRow r=Research.Graph9822.FourSaturation.witnesses[n.val]! := by simp [rawRow,r]
    rw [raw] at h
    have on := (term_rows1 p (term k) _ (under k).2).mpr hit
    have yep := List.any_eq_true.mpr ⟨term k,mem k,on⟩
    have low : ¬ r.val<13 := by dsimp [r];omega
    rw [show decide (r.val<13)=false from decide_eq_false low] at h
    change (hiddenFirst c).2.any _=true at yep
    rw [h] at yep
    contradiction
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.physical1
