import OR9822H2CrossPair
import OR9822H2Rescue
namespace Research.Graph9822H2Check
open Research.Graph9822TwoHidden

private theorem endpoint_pos {h q i a c : Nat} (lt : i<13)
    (ha : numericPos h q i a) (hc : numericPos h q i c) : holds q (selectedPos i a c) := by
  by_cases qa : a=11
  · simpa [selectedPos,qa] using positive_at lt (ha.2 qa)
  · by_cases qc : c=11
    · simpa [selectedPos,qc] using positive_at lt (hc.2 qc)
    · simpa [selectedPos,qa,qc] using zero_holds q

theorem four_actual (h q : Nat) (bh : negative h < 65536)
    (leak : ∃ n : Fin 16, (negative q).testBit n.val = true)
    (terms : Fin 3 → Arms Nat)
    (cover : ∀ e : Fin 13, ∃ t, (terms t).accepts (fun u e => numericPos h q e.val u) e)
    (safe : ∀ t n, ¬ (terms t).accepts (fun u n => numericNeg h q u n = true) n)
    (rows : Fin 4 → Fin 13) (strict : StrictMono rows) :
    ∃ i j : Fin 4, (rows i).val < (rows j).val ∧
      ∃ s ∈ rescue h (rows i).val (rows j).val, holds q s := by
  obtain ⟨i,j,lt,⟨w⟩⟩ := four_rows_rescue terms _ _ rows (fun k => cover (rows k)) safe
  obtain ⟨pa,pb,pc,pd⟩ := w.positive
  refine ⟨i,j,strict lt,numeric_label_witness h q _ _ _ _ _ _ pa.1 pb.1 pc.1 pd.1
    (endpoint_pos (rows i).isLt pa pc) (endpoint_pos (rows j).isLt pb pd) ?_⟩
  intro pair mem
  rcases pair with ⟨l,r⟩
  apply numeric_pair_rules bh leak
  intro n
  simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
  apply w.safe l r n
  · rcases mem with eq | eq | eq | eq <;> simp [eq.1]
  · rcases mem with eq | eq | eq | eq <;> simp [eq.2]

end Research.Graph9822H2Check
