import OR9822H2PadThree
import OR9822H2ResidualBits
import OR9822H2RootCover
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden Research.Graph9822TwoHidden Research.Graph9822.FreeOR Research.Graph9822H1Check
theorem physical_mode2 {h q : Nat} (term : Fin 3 → Arms (Source (Fin 10)))
    (bh : negative q<65536) (lh : ∃ n,nBit2 h n) (lq : ∃ n,nBit2 q n)
    (cover : ∀ e : Fin 13,∃ k,(term k).accepts (fun u e => sourceRow (hasPos1 e) (pBit2 h e) (pBit2 q e) u) e)
    (safe : ∀ k n,¬(term k).accepts (fun u n => sourceRow (fun v => negRaw n v=true) (nBit2 h n) (nBit2 q n) u) n) :
    ∃ c∈centers,sub (residual2 h c) (positive q)=true ∧
      (sub (residual2 h c) (rawPos (freeRaw (negative q)))=true ∨
      (meets (negative h) (negative q)=false ∧ sub (residual2 h c &&& (8191 ^^^ positive h)) (rawPos (freeRaw (negative q)))=true)) := by
  classical
  choose v vc using fun k => raw_center (term k) _ _ (safe k)
  obtain ⟨c,cm,has⟩ := pad_three2 v
  let T (e : Fin 13) := (residual2 h c).testBit e.val=true
  have wit (e : Fin 13) (on : T e) := hot_residual2 e on
  have result := root_dichotomy T hasPos1 (pBit2 h) (pBit2 q) (nBit2 h) (nBit2 q)
    (fun n v => negRaw n v=true) (by
      intro e on
      obtain ⟨k,⟨a,la,pa⟩,b,rb,pb⟩ := cover e
      apply uncovered_edge _ _ _ _ _ _ a b pa pb (fun n both => safe k n ⟨⟨a,la,both.1⟩,b,rb,both.2⟩) _ (wit e on).2 lh lq
      intro u w eu ew
      subst a;subst b
      rcases vc k u w la rb with eq|eq
      · exact Bool.noConfusion ((wit e on).1.symm.trans (raw_hit1 (eq ▸ has k) pa))
      · exact Bool.noConfusion ((wit e on).1.symm.trans (raw_hit1 (eq ▸ has k) pb)))
  refine ⟨c,cm,sub_small2 (low_residual2 h c) result.1,?_⟩
  rcases result.2 with solo|⟨cross,only⟩
  · left
    apply sub_small2 (low_residual2 h c)
    intro i on
    obtain ⟨u,hit,guarded⟩ := solo i on
    exact raw_hit1 (safeRaw2 guarded) hit
  · right
    constructor
    · apply (empty_overlap ..).2
      intro i hi
      by_cases lt : i<16
      · exact Bool.eq_false_iff.mpr (cross ⟨i,lt⟩ hi)
      · exact Nat.testBit_lt_two_pow (lt_of_lt_of_le bh (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) (by omega : 16 ≤ i)))
    · apply sub_small2 (by intro i hi;simp [low_residual2 h c i hi])
      intro i on
      have pair := Bool.and_eq_true_iff.mp (by simpa only [Nat.testBit_and] using on)
      have cold : ¬pBit2 h i := by
        intro hp
        have mask : (8191:Nat).testBit i.val=true := by
          change (2^13-1:Nat).testBit i.val=true
          rw [Nat.testBit_two_pow_sub_one];simp [i.isLt]
        change (positive h).testBit i.val=true at hp
        simpa [mask,hp] using pair.2
      obtain ⟨u,ev,sv⟩ := only i pair.1 cold
      exact raw_hit1 (safeRaw2 sv) ev
end Research.Graph9822H2Check
#print axioms Research.Graph9822H2Check.physical_mode2
