import H2ActualRoot859822
import H23SharedBank9822
import OR9822H2Viable
import H2PortableQuads9822
namespace Research.Graph9822H2Local
open Research.Graph9822H2Check Research.Graph9822Implication
def sampleBook : List (Nat × List Nat) := [(1729382256910270465,[22,23,24,25,22]),(6917529027641081858,[26,27,28,29,26]),(9511602413006487560,[20,21,30,31,20]),(558345773059,[6,23,24,7,8,29,26,3,4,27,28,9,6]),(34426920969,[2,21,30,3,4,25,22,1,10,23,24,5,2]),(351843729294338,[6,33,38,7,8,29,26,13,18,27,28,9,6]),((512 + (160 <<< 60)),[34,35,38,39,34]),(2199157801000,[4,21,30,5,14,35,24,1,10,25,34,15,4]),(21990240953345,[2,23,24,13,18,25,22,3,4,33,38,5,2]),(343601586689,[2,35,38,3,4,25,22,15,18,23,24,5,2]),(36033195074126880,[12,25,34,13,18,39,32,5,14,33,38,19,12]),(2814749770252672,[8,31,34,9,18,39,28,11,14,29,38,19,8])]
set_option maxRecDepth 12000 in
set_option maxHeartbeats 5000000 in
theorem sampleBookGood : sampleBook.all good = true := by decide +kernel
theorem sampleBookMasks : sampleBook.map Prod.fst = sampleMasks := rfl

theorem root85Physical {q : Nat} (v : ViableTwo 33847320 q)
    (lanes : ∀ j ∈ List.range 4, laneGood j = true)
    (arcs : ∀ l ∈ List.range 40, validArcsAt l = true) : ¬holds q 535693216 := by
  obtain ⟨A,B,use,sem,bound,apart⟩ := v.nested
  apply actualRoot85
  · intro s reject
    refine shared_rejects sem bound apart lanes arcs sampleBook sampleBookGood
      (fun sig => sampleMasks.any (fun m => sub m sig)) ?_ (s := s) ?_
    · intro sig hit
      rw [← sampleBookMasks] at hit
      simpa only [List.any_map,Function.comp_def] using hit
    · have cold : keep s = false := by
        cases hk : keep s <;> simp_all
      simpa [isDenied,keep] using cold
  · obtain ⟨i,atI⟩ := portableQuad (code := 0) (q := [0,1,3,9]) (by decide +kernel)
    exact v.rescueRow i _ atI
end Research.Graph9822H2Local
