import H3TailGroups9822
namespace Research.H3TailGroups

def groupAt (rows : Array Nat) (n : Fin 16) : Fin 7 := Fin.ofNat 7 (rows[n.val]?.getD 0)
def edgeWitness (table : Array Nat) (i j : Fin 16) : Fin 13 :=
  Fin.ofNat 13 (((table[i.val]?.getD 0) >>> (4*j.val)) % 16)

def classPage (groups pos neg table : Array Nat) (i : Fin 16) :=
  (List.finRange 16).all fun j =>
    groupAt groups i == groupAt groups j ||
    let p := pos[(edgeWitness table i j).val]?.getD 0
    p &&& ((neg[i.val]?.getD 0) ||| (neg[j.val]?.getD 0)) == p

theorem classPage_witness (groups pos neg table : Array Nat) (i j : Fin 16)
    (ok : classPage groups pos neg table i = true)
    (different : groupAt groups i ≠ groupAt groups j) :
    ∃ p : Fin 13, (pos[p.val]?.getD 0) &&& ((neg[i.val]?.getD 0) ||| (neg[j.val]?.getD 0)) =
      pos[p.val]?.getD 0 := by
  have row := List.all_eq_true.mp ok j (List.mem_finRange j)
  rcases Bool.or_eq_true_iff.mp row with yes | no
  · exact False.elim (different (beq_iff_eq.mp yes))
  · exact ⟨edgeWitness table i j,beq_iff_eq.mp no⟩

theorem classPage_sound (groups pos neg table : Array Nat) (i j : Fin 16)
    (ok : classPage groups pos neg table i = true)
    (separate : ∀ p : Fin 13, ∃ f : Nat, (pos[p.val]?.getD 0).testBit f = true ∧
      (neg[i.val]?.getD 0).testBit f = false ∧ (neg[j.val]?.getD 0).testBit f = false) :
    groupAt groups i = groupAt groups j := by
  have row := List.all_eq_true.mp ok j (List.mem_finRange j)
  rcases Bool.or_eq_true_iff.mp row with yes | no
  · exact beq_iff_eq.mp yes
  · let p := edgeWitness table i j
    obtain ⟨f,hot,a,b⟩ := separate p
    have eq : (pos[p.val]?.getD 0) &&& ((neg[i.val]?.getD 0) ||| (neg[j.val]?.getD 0)) =
        pos[p.val]?.getD 0 := beq_iff_eq.mp no
    have clash := congrArg (fun w : Nat => w.testBit f) eq
    simp [Nat.testBit_and,Nat.testBit_or,hot,a,b] at clash

def banWitness (table : Array Nat) (g : Fin 7) (j : Nat) : Fin 16 :=
  Fin.ofNat 16 (((table[g.val]?.getD 0) >>> (4*j)) % 16)

def banPage (groups bans neg table : Array Nat) (g : Fin 7) :=
  (List.range 12).all fun j =>
    !(bans[g.val]!.testBit j) ||
    let n := banWitness table g j
    groupAt groups n == g && (neg[n.val]?.getD 0).testBit j

theorem banPage_sound (groups bans neg table : Array Nat) (g : Fin 7) (j : Nat)
    (ok : banPage groups bans neg table g = true)
    (lt : j<12) (lit : bans[g.val]!.testBit j = true) :
    ∃ n : Fin 16, groupAt groups n = g ∧ (neg[n.val]?.getD 0).testBit j = true := by
  have row := List.all_eq_true.mp ok j (List.mem_range.mpr lt)
  rcases Bool.or_eq_true_iff.mp row with absent | both
  · simp [lit] at absent
  · have v := Bool.and_eq_true_iff.mp both
    exact ⟨_,beq_iff_eq.mp v.1,v.2⟩

end Research.H3TailGroups
