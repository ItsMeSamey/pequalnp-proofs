import H3LeafGroup169822
import H3LeafGroup179822
import H3LeafGroup189822
import H3LeafGroup199822
import H3LeafGroup209822
import H3LeafGroup219822
import H3LeafGroup229822
import H3LeafGroup239822
namespace Research.Graph9822H3Leaf
def bag2 : List (Nat × Nat) := gs16 ++ gs17 ++ gs18 ++ gs19 ++ gs20 ++ gs21 ++ gs22 ++ gs23
theorem bagOK2 : bag2.all (fun (h,s) => leafCheck h s)=true := by simp [bag2,pass16,pass17,pass18,pass19,pass20,pass21,pass22,pass23]
end Research.Graph9822H3Leaf
