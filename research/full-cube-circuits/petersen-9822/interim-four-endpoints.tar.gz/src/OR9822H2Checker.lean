import OR9822HiddenTriangle
import FourSaturationData

namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden

def vs := List.range 10
def es := List.range 13
def bit (i : Nat) := 2 ^ i
def sub (a b : Nat) : Bool := a &&& b == a
def demand (t f : Nat) := t ||| (f <<< 13)
def positive (s : Nat) := s &&& 8191
def negative (s : Nat) := s >>> 13
def rawPos (x : Nat) := accepts x
def rawNeg (x : Nat) := edgeMask (meets x) Research.Graph9822.FourSaturation.witnesses
def freeRaw (f : Nat) := vs.foldl (fun a v =>
  if meets f (rawNeg (bit v)) then a else a ||| bit v) 0

def minimal (xs : List Nat) : List Nat :=
  let unique := xs.eraseDups
  (unique.filter (fun x => !(unique.any (fun y => x != y && sub y x)))).mergeSort

def covers (t : Nat) : List Nat :=
  (List.range 1024).filter fun b => sub t (rawPos b) &&
    vs.all (fun v => !b.testBit v || !sub t (rawPos (b ^^^ bit v)))

def feasible (h s : Nat) : Bool :=
  let t := positive s
  let f := negative s
  (covers t).any fun b =>
    let forbidden := f &&& rawNeg b
    let a := freeRaw forbidden &&& (1023 ^^^ b)
    sub t (rawPos a ||| (if meets (negative h) forbidden then 0 else positive h))

def labels (h i : Nat) : List Nat :=
  vs.filter (fun v => edges[i]!.testBit v) ++
    (if (positive h).testBit i then [10] else []) ++ [11]

def fixedNeg (h u : Nat) := if u == 10 then negative h else rawNeg (bit u)

def pairDemand (h i j a b c d : Nat) : Option Nat := do
  let pairs := [(a,c),(a,d),(b,c),(b,d)]
  guard (pairs.all fun (u,v) =>
    if u == 11 then v != 11 else v == 11 || !meets (fixedNeg h u) (fixedNeg h v))
  let forbidden := pairs.foldl (fun f (u,v) =>
    f ||| (if u == 11 then fixedNeg h v else if v == 11 then fixedNeg h u else 0)) 0
  let t := (if a == 11 || c == 11 then bit i else 0) |||
           (if b == 11 || d == 11 then bit j else 0)
  return demand t forbidden

def rescue (h i j : Nat) := minimal (do
  let a ← labels h i
  let b ← labels h j
  let c ← labels h i
  let d ← labels h j
  (pairDemand h i j a b c d).toList)

def matchings : List (List Nat) := do
  let i ← es
  let j ← es
  let k ← es
  let l ← es
  guard (i < j && j < k && k < l)
  let q := [i,j,k,l]
  let verts := q.foldl (fun m e => m ||| edges[e]!) 0
  guard ((vs.filter verts.testBit).length == 8)
  return q

def step (h s code : Nat) : Option (List Nat) := do
  if code == 255 then
    guard (negative s == 65535)
    return []
  let q ← matchings[code]?
  let opts := minimal (do
    let i ← q
    let j ← q
    guard (i < j)
    let r ← rescue h i j
    guard (feasible h (s ||| r))
    return s ||| r)
  guard (!opts.contains s)
  return opts

def initial (h : Nat) := minimal (do
  let c ← List.range 1024
  guard ((vs.filter c.testBit).length == 3)
  let base := positive h &&& rawPos (freeRaw (negative h))
  let t := 8191 ^^^ (rawPos c ||| base)
  let join ← [false,true]
  let x ← covers (if join then t &&& (8191 ^^^ positive h) else t)
  let s := demand t (rawNeg x ||| (if join then negative h else 0))
  guard (feasible h s)
  return s)

end Research.Graph9822H2Check
