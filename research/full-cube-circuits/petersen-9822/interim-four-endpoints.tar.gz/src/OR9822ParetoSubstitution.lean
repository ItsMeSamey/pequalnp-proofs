import OR9822FeatureRun
namespace Research.Graph9822.FeatureRun
open Research.Graph9822Resolution Research.Graph9822.FreeOR

def WireLE (w z : Wire) := ∀ j, w j = true → z j = true

theorem read_mono {w z : Wire} (le : WireLE w z) (a : Arm) :
    readArm w a = true → readArm z a = true := by
  intro h
  obtain ⟨j,hj,hot⟩ := List.any_eq_true.mp h
  exact List.any_eq_true.mpr ⟨j,hj,le j hot⟩

theorem run_mono {w z : Wire} (le : WireLE w z) (ps : List Product) (k : Nat) :
    WireLE (run ps k w) (run ps k z) := by
  induction ps generalizing w z k with
  | nil => exact le
  | cons p ps ih =>
    apply ih
    intro j
    by_cases eq : j=k
    · subst j
      simp only [Function.update_self,productBit,Bool.and_eq_true]
      exact fun h => ⟨read_mono le _ h.1,read_mono le _ h.2⟩
    · simpa [Function.update_of_ne eq] using le j

/-- Any fixed positive suffix tolerates simultaneous improvement of its bank on
positive rows and reverse improvement on negative rows. Arbitrary reuse is allowed. -/
theorem pareto_suffix (ps : List Product) (k : Nat) (out : Arm) (old new : Bank)
    (improve : ∀ i : Fin 29, if i.val < 13 then WireLE (fun j => old j i) (fun j => new j i)
      else WireLE (fun j => new j i) (fun j => old j i))
    (exactRows : ∀ i : Fin 29,
      readColumn (runColumns ps k old) out i = decide (i.val < 13)) :
    ∀ i : Fin 29, readColumn (runColumns ps k new) out i = decide (i.val < 13) := by
  intro i
  have promote {a b : Bank} (rel : WireLE (fun j => a j i) (fun j => b j i)) :
      readColumn (runColumns ps k a) out i = true →
      readColumn (runColumns ps k b) out i = true := by
    have r := read_mono (run_mono rel ps k) out
    unfold readColumn
    rw [scalar_run,scalar_run]
    exact r
  by_cases lt : i.val < 13
  · simpa [lt] using promote (by simpa [lt] using improve i)
      (by simpa [lt] using exactRows i)
  · simp only [lt,decide_false]
    apply Bool.eq_false_iff.mpr
    intro hot
    have contradiction := promote (by simpa [lt] using improve i) hot
    rw [exactRows] at contradiction
    simp [lt] at contradiction

end Research.Graph9822.FeatureRun
