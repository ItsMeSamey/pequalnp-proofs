import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class064 : runPacket packets[64]! = true := by decide +kernel
theorem class065 : runPacket packets[65]! = true := by decide +kernel
theorem class066 : runPacket packets[66]! = true := by decide +kernel
theorem class067 : runPacket packets[67]! = true := by decide +kernel
end Research.Graph9822FirstBroad
