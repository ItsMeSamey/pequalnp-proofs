import H3ImpFast9822
import OR9822H2Antichain
namespace Research.Graph9822Implication
open Research.Graph9822H2Check Research.Graph9822H3Implication

theorem allowed_le {r sig l v : Nat} (incl : sub r sig = true)
    (active : allowed r l v = true) : allowed sig l v = true := by
  cases eq : clauseBit l v with
  | none => simp [allowed,eq] at active
  | some x =>
    have small : sub x r = true := by simpa [allowed,eq] using active
    simpa [allowed,eq] using sub_trans small incl

theorem bank_refutes {bank : List (Nat × List Nat)} (sig : Nat)
    (all : bank.all good = true) (hit : bank.any (fun row => sub row.1 sig) = true)
    {value : Nat → Bool} (opposite : ∀ l, value (opp l) = !value l)
    (gates : ∀ l v, allowed sig l v = true → value l = true → value v = true) : False := by
  obtain ⟨row,mem,incl⟩ := List.any_eq_true.mp hit
  have checked : closedConflict (allowed row.1) row.2 = true :=
    List.all_eq_true.mp all row mem
  exact closedConflict_impossible opposite (fun l v act => gates l v (allowed_le incl act)) checked
end Research.Graph9822Implication
