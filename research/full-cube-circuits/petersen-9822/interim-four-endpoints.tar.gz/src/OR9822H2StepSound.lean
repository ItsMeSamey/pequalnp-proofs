import OR9822H2Antichain
namespace Research.Graph9822H2Check

/-- The packed mask of all requirements met by a fixed second gate. -/
def grants (q : Nat) := q ^^^ (65535 <<< 13)
def holds (q s : Nat) := sub s (grants q) = true

theorem weaker_holds {q s r : Nat} (small : sub r s = true) (live : holds q s) :
    holds q r := sub_trans small live

private theorem complete_children (h s : Nat) (quad : List Nat) (q : Nat)
    (branch : ∃ i ∈ quad, ∃ j ∈ quad, i < j ∧
      ∃ r ∈ rescue h i j, feasible h (s ||| r) = true ∧ holds q (s ||| r)) :
    ∃ k ∈ minimal (do
      let i ← quad
      let j ← quad
      guard (i < j)
      let r ← rescue h i j
      guard (feasible h (s ||| r))
      return s ||| r), holds q k := by
  obtain ⟨i,hi,j,hj,lt,r,hr,feas,live⟩ := branch
  have mem : s ||| r ∈ (do
      let i ← quad
      let j ← quad
      guard (i < j)
      let r ← rescue h i j
      guard (feasible h (s ||| r))
      return s ||| r : List Nat) := by
    simp only [List.bind_eq_flatMap,List.mem_flatMap]
    refine ⟨i,hi,j,hj,?_⟩
    simp [lt]
    exact ⟨r,hr,by simp [feas]⟩
  obtain ⟨k,member,weak⟩ := minimal_weakens mem
  exact ⟨k,member,weaker_holds weak live⟩

theorem step_preserves_witness {h s code q : Nat} {children : List Nat}
    (run : step h s code = some children)
    (leaks : negative s ≠ 65535)
    (resolves : ∀ quad, matchings[code]? = some quad →
      ∃ i ∈ quad, ∃ j ∈ quad, i < j ∧ ∃ r ∈ rescue h i j,
        feasible h (s ||| r) = true ∧ holds q (s ||| r)) :
    ∃ k ∈ children, holds q k := by
  by_cases top : code = 255
  · simp [step,top,leaks] at run
  · cases read : matchings[code]? with
    | none => simp [step,top,read] at run
    | some quad =>
      have hit := complete_children h s quad q (resolves quad read)
      simp [step,top,read,guard] at run
      split at run <;> simp_all [guard]

end Research.Graph9822H2Check
