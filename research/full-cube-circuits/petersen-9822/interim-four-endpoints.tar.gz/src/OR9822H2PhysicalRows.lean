import And9822CollectorShape
import OR9822TwoSlotRows
import OR9822H2FourActual
namespace Research.Graph9822.FreeOR
open Research.Graph9822.FeatureRun Research.Graph9822Resolution Research.Graph9822H2Check Research.Graph9822TwoHidden
def firstSig (p : Product) := encode (firstCol p)
def secondSig (p q : Product) := encode (secondCol p q)
theorem three_terms (c : FiveProgram) (p q : Product) (hp : (hiddenFirst c).1=[p,q]) :
    ∃ term : Fin 3 → Product,
      (∀ i,term i∈(hiddenFirst c).2) ∧
      (∀ prod∈(hiddenFirst c).2,∃ k,term k=prod) ∧
      (∀ i,Apart (term i) ∧ Below 12 (term i)) ∧
      (∀ e : Fin 13,∃ k,(productArms (term k)).accepts (fun u e => numericPos (firstSig p) (secondSig p q) e.val u) e) ∧
      (∀ k n,¬(productArms (term k)).accepts (fun u n => numericNeg (firstSig p) (secondSig p q) u n=true) n) := by
  let ts := (hiddenFirst c).2
  have size := (hidden_first_sizes c).1
  rw [hp] at size
  have len : ts.length=3 := by change (hiddenFirst c).2.length=3;simp at size;omega
  let term (k : Fin 3) := ts[k.val]'(by omega)
  have mem (k : Fin 3) : term k∈ts := List.getElem_mem ..
  have complete (d) (hd : d∈ts) : ∃ k,term k=d := by
    obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hd
    exact ⟨⟨i,by omega⟩,eq⟩
  have under (k) := (hidden_first_shape c).2.2 (term k) (mem k)
  simp only [hp,List.length_cons,List.length_nil,Nat.reduceAdd] at under
  have legal (k j) (hj : j∈(term k).1 ∨ j∈(term k).2) : j<12 :=
    hj.elim (fun h => (under k).2.1 j h) (fun h => (under k).2.2 j h)
  refine ⟨term,mem,complete,under,?_,?_⟩
  · intro e
    let r : Fin 29 := ⟨e.val,by omega⟩
    have h := hidden_first_rows c r
    rw [hp,show decide (r.val<13)=true from decide_eq_true e.isLt] at h
    obtain ⟨t,ht,on⟩ := List.any_eq_true.mp h
    obtain ⟨k,rfl⟩ := complete t ht
    exact ⟨k,(terminal_positive p q _ (legal k) e).mp on⟩
  · intro k n hit
    let r : Fin 29 := ⟨13+n.val,by omega⟩
    have h := hidden_first_rows c r
    have low : ¬ r.val<13 := by dsimp [r];omega
    rw [hp,show decide (r.val<13)=false from decide_eq_false low] at h
    have on := (terminal_negative p q _ (legal k) n).mpr hit
    have yep := List.any_eq_true.mpr ⟨term k,mem k,on⟩
    change (hiddenFirst c).2.any _=true at yep
    rw [h] at yep
    contradiction
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.three_terms
