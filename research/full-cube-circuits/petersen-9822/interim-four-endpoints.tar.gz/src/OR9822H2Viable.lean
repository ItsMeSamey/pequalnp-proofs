import OR9822H2ActualInitial
import OR9822H2PhysicalResolve
import OR9822H2ReheadLeaks
import OR9822H2ReheadTerms
import OR9822H2NestedPhysical
namespace Research.Graph9822H2Check
open Research.Graph9822.FeatureRun Research.Graph9822.FreeOR Research.Graph9822TwoHidden

structure ViableTwo (h q : Nat) : Prop where
  leak : ∃ n : Fin 16, (negative q).testBit n.val=true
  nested : ∃ a b use, NestedBits h q a b use ∧ a<1024 ∧ Research.Graph9822OneHidden.meets a b=false
  root : ∃ s∈fastInitial h, holds q s
  rescueRow : ∀ (sign : Nat) (quad : List Nat), matchings[sign]?=some quad →
    ∃ i∈quad, ∃ j∈quad, i<j ∧ ∃ d∈rescue h i j, holds q d

theorem viable_literal (c : MaximumFive) (p q : Product) (ts : List Product)
    (ps : c.products=p::q::ts) (out : c.out=List.range' 12 ts.length)
    (qt : Apart q) (legal : ∀ t∈ts, Apart t ∧ Below 12 t) :
    ViableTwo (firstSig p) (secondSig p q) := by
  obtain ⟨terms,_,_,bd,cov,safe⟩ := three_literal_terms c.toFiveProgram p q ts ps out legal
  obtain ⟨lh,lq⟩ := literal_two_leaks c p q ts ps out
  exact ⟨lq,physical_nested_bits p q qt,
    initial_two_terms terms (fun k => (bd k).2) cov safe (neg_bound2 _) (neg_bound2 _)
      lh lq (fun _ => physical_fast_feasible p q qt),
    resolve_two_terms (neg_bound2 _) lq (fun k => productArms (terms k)) cov safe⟩

end Research.Graph9822H2Check
