import OR9822H1Saturate
import OR9822H2Centers
import OR9822H1Seeds
namespace Research.Graph9822OneHidden
open Research.Graph9822TwoHidden
abbrev V1 := Fin 10
abbrev N1 := Fin 16
abbrev adjacent1 (a b : V1) : Prop :=
  (Research.Graph9822H1Check.neighbor a.val).testBit b.val = true
private theorem cross1 : ∀ a b : V1,
    (∀ n : N1, ¬(negRaw n a=true ∧ negRaw n b=true)) → adjacent1 a b := by decide +kernel
private theorem square1 : ∀ a b x y : V1, a≠b →
    adjacent1 a x → adjacent1 b x → adjacent1 a y → adjacent1 b y → x=y := by decide +kernel
private theorem symmetric1 : ∀ a b : V1, adjacent1 a b → adjacent1 b a := by decide +kernel
def reverse1 {L} (p : Arms L) : Arms L := ⟨p.right,p.left⟩
theorem reverse1_accepts {L R} (p : Arms L) (f : L → R → Prop) (r : R) :
    (reverse1 p).accepts f r ↔ p.accepts f r := And.comm

theorem orient1 (p : Arms (Option V1)) (h : N1 → Prop)
    (safe : ∀ n, ¬p.accepts (fun l n => oneRow (fun v => negRaw n v=true) (h n) l) n) :
    (∀ u v : V1, ¬(p.left (some u) ∧ p.right (some v))) ∨
    ∃ c : V1, ∃ s : Arms (Option V1), (s=p ∨ s=reverse1 p) ∧
      s.left (some c) ∧ (∀ v, s.left (some v) → v=c) ∧
      (∃ v, s.right (some v)) ∧ (∀ v,s.right (some v) → adjacent1 c v) := by
  classical
  by_cases ex : ∃ u v : V1,p.left (some u) ∧ p.right (some v)
  · right
    obtain ⟨a,b,la,rb⟩ := ex
    have adj (u v : V1) (l : p.left (some u)) (r : p.right (some v)) : adjacent1 u v :=
      cross1 u v (fun n both => safe n ⟨⟨some u,l,both.1⟩,⟨some v,r,both.2⟩⟩)
    by_cases left : ∀ v,p.left (some v) → v=a
    · exact ⟨a,p,Or.inl rfl,la,left,⟨b,rb⟩,fun v r => adj a v la r⟩
    · push_neg at left
      obtain ⟨u,lu,ua⟩ := left
      exact ⟨b,reverse1 p,Or.inr rfl,rb,fun v rv =>
        square1 u a v b ua (adj u v lu rv) (adj a v la rv) (adj u b lu rb) (adj a b la rb),
        ⟨a,la⟩,fun v lv => symmetric1 v b (adj v b lv rb)⟩
  · exact Or.inl fun u v both => ex ⟨u,v,both⟩
end Research.Graph9822OneHidden
#print axioms Research.Graph9822OneHidden.orient1
