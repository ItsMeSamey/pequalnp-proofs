import OR9822H2PhysicalRows
import And9822ReifyMaximum
namespace Research.Graph9822.FreeOR
open Research.Graph9822.FeatureRun Research.Graph9822Resolution Research.Graph9822H2Check Research.Graph9822TwoHidden
theorem three_literal_terms (c : FiveProgram) (p q : Product) (ts : List Product)
    (ps : c.products=p::q::ts) (out : c.out=List.range' 12 ts.length)
    (underAll : ∀ t∈ts, Apart t ∧ Below 12 t) :
    ∃ term : Fin 3 → Product,
      (∀ i,term i∈ts) ∧
      (∀ prod∈ts,∃ k,term k=prod) ∧
      (∀ i,Apart (term i) ∧ Below 12 (term i)) ∧
      (∀ e : Fin 13,∃ k,(productArms (term k)).accepts (fun u e => numericPos (firstSig p) (secondSig p q) e.val u) e) ∧
      (∀ k n,¬(productArms (term k)).accepts (fun u n => numericNeg (firstSig p) (secondSig p q) u n=true) n) := by
  have size := c.count
  rw [ps] at size
  have len : ts.length=3 := by simp at size;omega
  have rows (i : Fin 29) : ts.any (productBit (run [p,q] 10 (fullWire (rawRow i)))) =
      decide (i.val<13) := by
    obtain ⟨bound,actual⟩ := row_extrema i
    have ht := (c.correct ⟨_,bound⟩).trans actual
    change readArm (run c.products 10 (fullWire (rawRow i))) c.out=_ at ht
    rw [ps,out] at ht
    change readArm (run ([p,q]++ts) 10 _) _=_ at ht
    rw [join_runs] at ht
    exact (terminal_eval ts 12 12 (by decide) (fun t ht => (underAll t ht).2) _).symm.trans ht
  let term (k : Fin 3) := ts[k.val]'(by omega)
  have mem (k : Fin 3) : term k∈ts := List.getElem_mem ..
  have complete (d) (hd : d∈ts) : ∃ k,term k=d := by
    obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hd
    exact ⟨⟨i,by omega⟩,eq⟩
  have under (k) := underAll (term k) (mem k)
  have legal (k j) (hj : j∈(term k).1 ∨ j∈(term k).2) : j<12 :=
    hj.elim (fun h => (under k).2.1 j h) (fun h => (under k).2.2 j h)
  refine ⟨term,mem,complete,under,?_,?_⟩
  · intro e
    let r : Fin 29 := ⟨e.val,by omega⟩
    have h := rows r
    rw [show decide (r.val<13)=true from decide_eq_true e.isLt] at h
    obtain ⟨t,ht,on⟩ := List.any_eq_true.mp h
    obtain ⟨k,rfl⟩ := complete t ht
    exact ⟨k,(terminal_positive p q _ (legal k) e).mp on⟩
  · intro k n hit
    let r : Fin 29 := ⟨13+n.val,by omega⟩
    have h := rows r
    have low : ¬ r.val<13 := by dsimp [r];omega
    rw [show decide (r.val<13)=false from decide_eq_false low] at h
    have on := (terminal_negative p q _ (legal k) n).mpr hit
    have yep := List.any_eq_true.mpr ⟨term k,mem k,on⟩
    change ts.any _=true at yep
    rw [h] at yep
    contradiction
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.three_literal_terms
