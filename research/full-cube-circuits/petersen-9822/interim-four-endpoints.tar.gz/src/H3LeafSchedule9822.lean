import H3LeafBag09822
import H3LeafBag19822
import H3LeafBag29822
import H3LeafBag39822
import H3LeafBag49822
import H3LeafBag59822
import H3LeafBag69822
import H3LeafBag79822
import H3LeafBag89822
import H3LeafBag99822
namespace Research.Graph9822H3Leaf
def scheduled : List (Nat × Nat) := bag0 ++ bag1 ++ bag2 ++ bag3 ++ bag4 ++ bag5 ++ bag6 ++ bag7 ++ bag8 ++ bag9
theorem checked_schedule : scheduled.all (fun (h,s) => leafCheck h s)=true := by simp [scheduled,bagOK0,bagOK1,bagOK2,bagOK3,bagOK4,bagOK5,bagOK6,bagOK7,bagOK8,bagOK9]
theorem all_terminal {h s : Nat} (entry : (h,s) ∈ scheduled) :
    Graph9822DemandThree.terminal h s=true :=
  terminal_of_check (List.all_eq_true.mp checked_schedule (h,s) entry)
end Research.Graph9822H3Leaf
#print axioms Research.Graph9822H3Leaf.all_terminal
