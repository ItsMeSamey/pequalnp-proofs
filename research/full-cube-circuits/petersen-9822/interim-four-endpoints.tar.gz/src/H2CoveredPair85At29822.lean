import H2UnsortedRescue9822
namespace Research.Graph9822H2Check
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem pair85at2 : pairCovered 33847320 0 9 [183378432, 360694273, 529645569, 534913537] = true := by decide +kernel
end Research.Graph9822H2Check
