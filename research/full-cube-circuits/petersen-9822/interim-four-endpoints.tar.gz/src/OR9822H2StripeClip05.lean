import OR9822H2SeedStripeFields
namespace Research.Graph9822H2Check.SeedCache
set_option maxHeartbeats 6000000 in
set_option maxRecDepth 16000 in
theorem checkClip05 : ∀ i : Fin 8, clipChecked (40+i.val)=true := by decide +kernel
end Research.Graph9822H2Check.SeedCache
