import H3TailKernel9822
namespace Research.H3Tail

def Banned (x : Arms) (d e : Nat) : Prop :=
  ∀ f, e.testBit f = true → (block x d).testBit f = true

theorem bannedAdd (x : Arms) (slot mask d e : Nat) (h : Banned x d e) :
    Banned (add x slot mask) d e := by
  intro f hf
  have old := h f hf
  rcases slot with _ | _ | _ | _ | _ | _ | slot <;>
    rcases d with _ | _ | _ | _ | _ | _ | d <;>
    simp [add,block,Nat.testBit_and,Nat.testBit_or] at old ⊢ <;>
    tauto

end Research.H3Tail
