import OR9822H2SeedCacheCheck
import H2RawShoreBridge9822
import OR9822H2SeedCacheSound
namespace Research.Graph9822H2Check.SeedCache
open Research.Graph9822OneHidden (edges)
private theorem leaf : ∀ i : Fin 13,∀ u∈ends[i.val]!,u<1024 ∧
    ∃ v : Fin 10, u=bit v.val ∧ edges[i.val]!.testBit v.val=true := by decide +kernel

theorem small_choice (xs : List (List Nat)) (legal : ∀ e∈xs,∀ v∈e,v<1024) :
    ∀ x∈allChoices xs,x<1024 := by
  induction xs with
  | nil => simp [allChoices]
  | cons e es ih =>
    intro x hx
    obtain ⟨tail,ht,mm⟩ := List.mem_flatMap.mp hx
    obtain ⟨v,hv,rfl⟩ := List.mem_map.mp mm
    exact Nat.or_lt_two_pow (n:=10)
      (ih (fun f hf u hu => legal f (List.mem_cons_of_mem _ hf) u hu) tail ht)
      (legal e List.mem_cons_self v hv)

theorem shore_bits {t x : Nat} (small : t<8192) (mem : x∈fastCovers t) :
    x<1024 ∧ sub t (rawPos x)=true := by
  constructor
  · apply small_choice _ _ x (admitted_choice mem)
    intro e he u hu
    obtain ⟨i,ii,rfl⟩ := List.mem_map.mp he
    exact (leaf ⟨i,List.mem_range.mp (List.mem_filter.mp ii).1⟩ u hu).1
  · apply (subset_bits ..).2
    intro i ri
    have lt : i<13 := by
      by_contra! high
      have off : t.testBit i=false := Nat.testBit_lt_two_pow
        (lt_of_lt_of_le small (show 8192≤2^i from Nat.pow_le_pow_right (by decide : 0<(2:Nat)) high))
      exact Bool.noConfusion (ri.symm.trans off)
    have hits := shoreEnum_hits mem
    obtain ⟨u,ue,ux⟩ := hits (ends[i]!)
      (List.mem_map.mpr ⟨i,List.mem_filter.mpr ⟨List.mem_range.mpr lt,ri⟩,rfl⟩)
    obtain ⟨v,rfl,act⟩ := (leaf ⟨i,lt⟩ u ue).2
    rw [raw_pos_bit x ⟨i,lt⟩]
    exact meets_iff_exists.mpr ⟨v.val,(subset_bits ..).1 ux _ (by simp [bit,Nat.testBit_two_pow]),act⟩
end Research.Graph9822H2Check.SeedCache
