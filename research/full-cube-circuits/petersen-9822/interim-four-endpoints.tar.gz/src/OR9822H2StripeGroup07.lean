import OR9822H2StripeBound084
import OR9822H2StripeBound085
import OR9822H2StripeBound086
import OR9822H2StripeBound087
import OR9822H2StripeBound088
import OR9822H2StripeBound089
import OR9822H2StripeBound090
import OR9822H2StripeBound091
import OR9822H2StripeBound092
import OR9822H2StripeBound093
import OR9822H2StripeBound094
import OR9822H2StripeBound095
namespace Research.Graph9822H2Check.SeedCache
theorem stripeGroup07 (t : Nat) (low : 5120≤t) (high : t<6656) : stripe t=true := by
  by_cases l0 : t<5248
  · have eq : 5120+(t-5120)=t := by omega
    simpa only [eq] using boundStripe084 ⟨t-5120,by omega⟩
  by_cases l1 : t<5376
  · have eq : 5248+(t-5248)=t := by omega
    simpa only [eq] using boundStripe085 ⟨t-5248,by omega⟩
  by_cases l2 : t<5632
  · have eq : 5376+(t-5376)=t := by omega
    simpa only [eq] using boundStripe086 ⟨t-5376,by omega⟩
  by_cases l3 : t<5888
  · have eq : 5632+(t-5632)=t := by omega
    simpa only [eq] using boundStripe087 ⟨t-5632,by omega⟩
  by_cases l4 : t<6144
  · have eq : 5888+(t-5888)=t := by omega
    simpa only [eq] using boundStripe088 ⟨t-5888,by omega⟩
  by_cases l5 : t<6176
  · have eq : 6144+(t-6144)=t := by omega
    simpa only [eq] using boundStripe089 ⟨t-6144,by omega⟩
  by_cases l6 : t<6208
  · have eq : 6176+(t-6176)=t := by omega
    simpa only [eq] using boundStripe090 ⟨t-6176,by omega⟩
  by_cases l7 : t<6272
  · have eq : 6208+(t-6208)=t := by omega
    simpa only [eq] using boundStripe091 ⟨t-6208,by omega⟩
  by_cases l8 : t<6400
  · have eq : 6272+(t-6272)=t := by omega
    simpa only [eq] using boundStripe092 ⟨t-6272,by omega⟩
  by_cases l9 : t<6464
  · have eq : 6400+(t-6400)=t := by omega
    simpa only [eq] using boundStripe093 ⟨t-6400,by omega⟩
  by_cases l10 : t<6528
  · have eq : 6464+(t-6464)=t := by omega
    simpa only [eq] using boundStripe094 ⟨t-6464,by omega⟩
  by_cases l11 : t<6656
  · have eq : 6528+(t-6528)=t := by omega
    simpa only [eq] using boundStripe095 ⟨t-6528,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
