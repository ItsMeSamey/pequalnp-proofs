import OR9822FeatureRun
import OR9822H2Checker
namespace Research.Graph9822.FeatureRun
open Research.Graph9822Resolution Research.Graph9822.FreeOR

def encode (c : Column) : Nat := (BitVec.ofBoolListLE (List.ofFn c)).toNat

theorem encode_bit (c : Column) (i : Fin 29) : (encode c).testBit i.val = c i := by
  change (BitVec.ofBoolListLE (List.ofFn c)).getLsbD i.val = c i
  rw [BitVec.getLsbD_ofBoolListLE,List.getD_eq_getElem?_getD,List.getElem?_ofFn]
  simp [i.isLt]

theorem encode_bound (c : Column) : encode c < 2^29 := by
  simpa [encode] using (BitVec.ofBoolListLE (List.ofFn c)).isLt

theorem encode_ext (x y : Column) (h : encode x = encode y) : x = y := by
  funext i
  simpa [encode_bit] using congrArg (fun n : Nat => n.testBit i.val) h

theorem encode_and (x y : Column) : encode (fun i => x i && y i) = encode x &&& encode y := by
  apply Nat.eq_of_testBit_eq
  intro k
  by_cases lt : k < 29
  · let i : Fin 29 := ⟨k,lt⟩
    change (encode _).testBit i.val = (encode x &&& encode y).testBit i.val
    rw [Nat.testBit_and,encode_bit,encode_bit,encode_bit]
  · have zeros (z : Column) : (encode z).testBit k = false := by
      apply Nat.testBit_lt_two_pow
      exact lt_of_lt_of_le (encode_bound z) (Nat.pow_le_pow_right (by decide) (by omega))
    simp [Nat.testBit_and,zeros]

theorem encode_raw : ∀ v : Fin 10, encode (rawBank v.val) =
    Research.Graph9822H2Check.demand
      (Research.Graph9822H2Check.rawPos (2 ^ v.val))
      (Research.Graph9822H2Check.rawNeg (2 ^ v.val)) := by decide +kernel

end Research.Graph9822.FeatureRun
