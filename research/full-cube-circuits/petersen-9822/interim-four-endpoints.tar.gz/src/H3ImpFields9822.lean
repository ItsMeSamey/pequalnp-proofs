import H3ImpClauseInventory9822
namespace Research.Graph9822Implication
open Research.Graph9822H2Check
open Research.Graph9822.FourSaturation (witnesses)

structure PhysicalFields (h s : Nat) (useH : Bool) : Prop where
  posB : ∀ i v w, ((v,w),i) ∈ edgeEnds.zipIdx →
    sub (bit i) (fastSig h s useH) = true → (positive s).testBit i = true
  posA : ∀ i v w, ((v,w),i) ∈ edgeEnds.zipIdx →
    sub (bit (13+i)) (fastSig h s useH) = true → (positive s).testBit i = true ∧
      ¬ (useH = true ∧ (positive h).testBit i = true)
  cross : ∀ i v w, ((v,w),i) ∈ sourcePairs.zipIdx →
    sub (bit (26+i)) (fastSig h s useH) = true →
      ∃ n : Fin 16, (negative s).testBit n = true ∧
        witnesses[n.val]!.testBit v = true ∧ witnesses[n.val]!.testBit w = true
  unit : ∀ v ∈ vs, sub (bit (58+v)) (fastSig h s useH) = true →
    useH = true ∧ ∃ n : Fin 16, (negative s).testBit n = true ∧ (negative h).testBit n = true ∧
      witnesses[n.val]!.testBit v = true

end Research.Graph9822Implication
