import OR9822H2StripeBound060
import OR9822H2StripeBound061
import OR9822H2StripeBound062
import OR9822H2StripeBound063
import OR9822H2StripeBound064
import OR9822H2StripeBound065
import OR9822H2StripeBound066
import OR9822H2StripeBound067
import OR9822H2StripeBound068
import OR9822H2StripeBound069
import OR9822H2StripeBound070
import OR9822H2StripeBound071
namespace Research.Graph9822H2Check.SeedCache
theorem stripeGroup05 (t : Nat) (low : 3264≤t) (high : t<4224) : stripe t=true := by
  by_cases l0 : t<3328
  · have eq : 3264+(t-3264)=t := by omega
    simpa only [eq] using boundStripe060 ⟨t-3264,by omega⟩
  by_cases l1 : t<3584
  · have eq : 3328+(t-3328)=t := by omega
    simpa only [eq] using boundStripe061 ⟨t-3328,by omega⟩
  by_cases l2 : t<3648
  · have eq : 3584+(t-3584)=t := by omega
    simpa only [eq] using boundStripe062 ⟨t-3584,by omega⟩
  by_cases l3 : t<3712
  · have eq : 3648+(t-3648)=t := by omega
    simpa only [eq] using boundStripe063 ⟨t-3648,by omega⟩
  by_cases l4 : t<3840
  · have eq : 3712+(t-3712)=t := by omega
    simpa only [eq] using boundStripe064 ⟨t-3712,by omega⟩
  by_cases l5 : t<4096
  · have eq : 3840+(t-3840)=t := by omega
    simpa only [eq] using boundStripe065 ⟨t-3840,by omega⟩
  by_cases l6 : t<4112
  · have eq : 4096+(t-4096)=t := by omega
    simpa only [eq] using boundStripe066 ⟨t-4096,by omega⟩
  by_cases l7 : t<4128
  · have eq : 4112+(t-4112)=t := by omega
    simpa only [eq] using boundStripe067 ⟨t-4112,by omega⟩
  by_cases l8 : t<4160
  · have eq : 4128+(t-4128)=t := by omega
    simpa only [eq] using boundStripe068 ⟨t-4128,by omega⟩
  by_cases l9 : t<4176
  · have eq : 4160+(t-4160)=t := by omega
    simpa only [eq] using boundStripe069 ⟨t-4160,by omega⟩
  by_cases l10 : t<4192
  · have eq : 4176+(t-4176)=t := by omega
    simpa only [eq] using boundStripe070 ⟨t-4176,by omega⟩
  by_cases l11 : t<4224
  · have eq : 4192+(t-4192)=t := by omega
    simpa only [eq] using boundStripe071 ⟨t-4192,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
