import OR9822H2SeedCacheData
import H2FastInitial9822
namespace Research.Graph9822H2Check.SeedCache
open Research.Graph9822H2Eligibility (code)

def allChoices : List (List Nat) → List Nat
  | [] => [0]
  | e::es => (allChoices es).flatMap (fun x => e.map (fun v => x ||| v))

theorem admitted_choice {xs : List (List Nat)} {x : Nat} (live : x∈shoreEnum xs) :
    x∈allChoices xs := by
  induction xs generalizing x with
  | nil => exact live
  | cons e es ih =>
    have m := (List.mem_filter.mp (List.mem_mergeSort.mp live)).1
    obtain ⟨y,hy,hx⟩ := List.mem_flatMap.mp (List.mem_eraseDups.mp m)
    exact List.mem_flatMap.mpr ⟨y,ih hy,hx⟩

def choices (t : Nat) := allChoices ((es.filter t.testBit).map (fun i => ends[i]!))
def certified (t : Nat) : Bool :=
  entry t == 0 || (choices t).all (fun x =>
    decide (x<1024) && (row t).any (fun f => sub f (negative (code x))))
end Research.Graph9822H2Check.SeedCache
