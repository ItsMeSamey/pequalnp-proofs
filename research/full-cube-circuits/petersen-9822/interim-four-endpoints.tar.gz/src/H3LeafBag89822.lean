import H3LeafGroup649822
import H3LeafGroup659822
import H3LeafGroup669822
import H3LeafGroup679822
import H3LeafGroup689822
import H3LeafGroup699822
import H3LeafGroup709822
import H3LeafGroup719822
namespace Research.Graph9822H3Leaf
def bag8 : List (Nat × Nat) := gs64 ++ gs65 ++ gs66 ++ gs67 ++ gs68 ++ gs69 ++ gs70 ++ gs71
theorem bagOK8 : bag8.all (fun (h,s) => leafCheck h s)=true := by simp [bag8,pass64,pass65,pass66,pass67,pass68,pass69,pass70,pass71]
end Research.Graph9822H3Leaf
