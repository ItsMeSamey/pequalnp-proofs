import H2UnsortedRescue9822
namespace Research.Graph9822H2Check
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem pair85at5 : pairCovered 33847320 3 9 [40788488, 107979272, 435044864, 528588808, 528769544, 530989576] = true := by decide +kernel
end Research.Graph9822H2Check
