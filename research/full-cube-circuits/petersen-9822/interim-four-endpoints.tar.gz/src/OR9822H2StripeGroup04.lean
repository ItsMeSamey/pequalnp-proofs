import OR9822H2StripeBound048
import OR9822H2StripeBound049
import OR9822H2StripeBound050
import OR9822H2StripeBound051
import OR9822H2StripeBound052
import OR9822H2StripeBound053
import OR9822H2StripeBound054
import OR9822H2StripeBound055
import OR9822H2StripeBound056
import OR9822H2StripeBound057
import OR9822H2StripeBound058
import OR9822H2StripeBound059
namespace Research.Graph9822H2Check.SeedCache
theorem stripeGroup04 (t : Nat) (low : 2176≤t) (high : t<3264) : stripe t=true := by
  by_cases l0 : t<2240
  · have eq : 2176+(t-2176)=t := by omega
    simpa only [eq] using boundStripe048 ⟨t-2176,by omega⟩
  by_cases l1 : t<2304
  · have eq : 2240+(t-2240)=t := by omega
    simpa only [eq] using boundStripe049 ⟨t-2240,by omega⟩
  by_cases l2 : t<2336
  · have eq : 2304+(t-2304)=t := by omega
    simpa only [eq] using boundStripe050 ⟨t-2304,by omega⟩
  by_cases l3 : t<2368
  · have eq : 2336+(t-2336)=t := by omega
    simpa only [eq] using boundStripe051 ⟨t-2336,by omega⟩
  by_cases l4 : t<2432
  · have eq : 2368+(t-2368)=t := by omega
    simpa only [eq] using boundStripe052 ⟨t-2368,by omega⟩
  by_cases l5 : t<2560
  · have eq : 2432+(t-2432)=t := by omega
    simpa only [eq] using boundStripe053 ⟨t-2432,by omega⟩
  by_cases l6 : t<2688
  · have eq : 2560+(t-2560)=t := by omega
    simpa only [eq] using boundStripe054 ⟨t-2560,by omega⟩
  by_cases l7 : t<2816
  · have eq : 2688+(t-2688)=t := by omega
    simpa only [eq] using boundStripe055 ⟨t-2688,by omega⟩
  by_cases l8 : t<3072
  · have eq : 2816+(t-2816)=t := by omega
    simpa only [eq] using boundStripe056 ⟨t-2816,by omega⟩
  by_cases l9 : t<3136
  · have eq : 3072+(t-3072)=t := by omega
    simpa only [eq] using boundStripe057 ⟨t-3072,by omega⟩
  by_cases l10 : t<3200
  · have eq : 3136+(t-3136)=t := by omega
    simpa only [eq] using boundStripe058 ⟨t-3136,by omega⟩
  by_cases l11 : t<3264
  · have eq : 3200+(t-3200)=t := by omega
    simpa only [eq] using boundStripe059 ⟨t-3200,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
