import H2OneNodeLocal9822
namespace Research.Graph9822H2Local
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem rejectPair0 : ([184229891, 266788867, 358211587, 395821059] : List Nat).all (fun r => !keep (535693216 ||| r)) = true := by decide +kernel
end Research.Graph9822H2Local
