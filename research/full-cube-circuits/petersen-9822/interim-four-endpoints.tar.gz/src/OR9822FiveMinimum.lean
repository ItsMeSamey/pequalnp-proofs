import And9822FreeORDefs
import FourSaturationData
import OR9822H2RootCover
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution

/-- Original ten raw inputs and the original graph on the full cube. -/
def fullWire (m j : Nat) : Bool := decide (j < 10) && m.testBit j

structure FiveProgram where
  products : List Product
  out : Arm
  count : products.length = 5
  ordered : Chronological 10 products out
  disjoint : ∀ p ∈ products, ∀ v ∈ p.1, v ∉ p.2
  correct : ∀ m : Fin 1024, readArm (run products 10 (fullWire m.val)) out =
    Research.Graph9822.FourSaturation.accepts m.val

def collectorSize (out : Arm) : Nat := ((List.range' 10 5).filter out.contains).length

theorem collectorSize_le (out : Arm) : collectorSize out ≤ 5 := by
  simpa [collectorSize] using List.length_filter_le (l := List.range' 10 5) (p := out.contains)

structure MaximumFive extends FiveProgram where
  maximal : ∀ p : FiveProgram, collectorSize p.out ≤ collectorSize toFiveProgram.out

theorem exists_maximum (witness : FiveProgram) : Nonempty MaximumFive := by
  classical
  let reachable (k : Nat) := ∃ p : FiveProgram, 5 - collectorSize p.out = k
  have ex : ∃ k, reachable k := ⟨_,witness,rfl⟩
  obtain ⟨best,eq⟩ := Nat.find_spec ex
  refine ⟨⟨best,?_⟩⟩
  intro p
  have le : Nat.find ex ≤ 5 - collectorSize p.out := Nat.find_min' ex ⟨p,rfl⟩
  have ub := collectorSize_le best.out
  have up := collectorSize_le p.out
  omega

end Research.Graph9822.FreeOR
