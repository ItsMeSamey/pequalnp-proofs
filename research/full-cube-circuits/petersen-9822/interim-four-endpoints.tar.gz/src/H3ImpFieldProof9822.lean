import H3ImpLaneSpec9822
import OR9822H2MaskLogic
namespace Research.Graph9822Implication
open Research.Graph9822H2Check

private theorem zipBound {α : Type} {xs : List α} {x : α} {i : Nat}
    (inRows : (x,i) ∈ xs.zipIdx) : i < xs.length :=
  (List.getElem?_eq_some_iff.mp (List.mk_mem_zipIdx_iff_getElem?.mp inRows)).1

private theorem getSig {i sig : Nat} (small : sub (bit i) sig = true) :
    sig.testBit i = true := (subset_bits ..).1 small i (by simp [bit,Nat.testBit_two_pow])

private theorem noHigh {v n i : Nat} (size : v < 2^n) (high : n ≤ i) :
    v.testBit i = false :=
  Nat.testBit_lt_two_pow (lt_of_lt_of_le size (Nat.pow_le_pow_right (by decide) high))

private theorem posSmall (s : Nat) : positive s < 2^13 := by
  have le : s &&& 8191 ≤ 8191 := Nat.and_le_right
  change s &&& 8191 < 8192
  omega

private theorem needSmall (h s : Nat) (u : Bool) :
    (if u then positive s &&& (8191 ^^^ positive h) else positive s) < 2^13 := by
  cases u
  · exact posSmall s
  · exact lt_of_le_of_lt Nat.and_le_left (posSmall s)

theorem fields_of_lanes (h s : Nat) (u : Bool) (all : ∀ j ∈ List.range 4, laneGood j = true) :
    PhysicalFields h s u := by
  constructor
  · intro i v w mem sub
    have hi : i < 13 := zipBound mem
    have actual := getSig sub
    simpa [fastSig,Nat.testBit_or,Nat.testBit_shiftLeft,show ¬ i≥13 by omega,
      show ¬ i≥26 by omega,show ¬ i≥58 by omega] using actual
  · intro i v w mem sub
    have hi : i < 13 := zipBound mem
    have actual := getSig sub
    have low := noHigh (posSmall s) (show 13≤13+i by omega)
    have bitA : (if u then positive s &&& (8191 ^^^ positive h) else positive s).testBit i = true := by
      simpa [fastSig,Nat.testBit_or,Nat.testBit_shiftLeft,low,
        show 13+i≥13 by omega,show ¬13+i≥26 by omega,show ¬13+i≥58 by omega] using actual
    cases u with
    | false => exact ⟨bitA,by simp⟩
    | true =>
      have both : (positive s).testBit i = true ∧ (8191 ^^^ positive h).testBit i = true :=
        Bool.and_eq_true_iff.mp (by simpa only [if_true,Nat.testBit_and] using bitA)
      refine ⟨both.1,?_⟩
      rintro ⟨_,on⟩
      have ones : (8191:Nat).testBit i = true := by
        change (2^13-1 : Nat).testBit i = true
        rw [Nat.testBit_two_pow_sub_one 13 i]
        exact decide_eq_true hi
      have bad := both.2
      simp [Nat.testBit_xor,ones,on] at bad
  · intro i v w mem sub
    have hi : i < 32 := zipBound mem
    have actual := getSig sub
    have l0 := noHigh (posSmall s) (show 13≤26+i by omega)
    have l1 := noHigh (needSmall h s u) (show 13≤26+i-13 by omega)
    apply pairActive all mem
    simpa [fastSig,Nat.testBit_or,Nat.testBit_shiftLeft,l0,l1,show 26+i≥13 by omega,
      show 26+i≥26 by omega,show ¬26+i≥58 by omega] using actual
  · intro v vm sub
    have actual := getSig sub
    have l0 := noHigh (posSmall s) (show 13≤58+v by omega)
    have l1 := noHigh (needSmall h s u) (show 13≤58+v-13 by omega)
    have l2 := noHigh (pairBound (negative s) all) (show 32≤58+v-26 by omega)
    have hot : (if u then unitFields (negative s &&& negative h) else 0).testBit v = true := by
      simpa [fastSig,Nat.testBit_or,Nat.testBit_shiftLeft,l0,l1,l2,
        show 58+v≥13 by omega,show 58+v≥26 by omega,show 58+v≥58 by omega] using actual
    cases u with
    | false => simp at hot
    | true =>
      obtain ⟨n,bit,there⟩ := unitActive all vm hot
      have both := Bool.and_eq_true_iff.mp (by simpa only [Nat.testBit_and] using bit)
      exact ⟨rfl,n,both.1,both.2,there⟩

end Research.Graph9822Implication
