import PEqualNP.Defs
namespace Research.H3RegionEngine

structure Rules (α : Type) where
  dead : α → Bool
  step : α → Nat → Option (List α)

structure State (α : Type) where
  seen : List α
  hints : List Nat

def mark (k : α) (s : State α) : State α := {s with seen := k::s.seen}

def runList (f : α → State α → Option (State α)) :
    List α → State α → Option (State α)
  | [],s => some s
  | k::ks,s => do
    let t ← f k s
    runList f ks t

def walk [DecidableEq α] (r : Rules α) : Nat → α → State α → Option (State α)
  | 0,_,_ => none
  | fuel+1,k,s =>
    if k ∈ s.seen then some s else if r.dead k then some (mark k s) else
    match s.hints with
    | [] => none
    | h::hs => do
      let ks ← r.step k h
      let t ← runList (walk r fuel) ks ⟨s.seen,hs⟩
      pure (mark k t)

def Good (P : α → Prop) (s : State α) := ∀ k ∈ s.seen, P k

private theorem markGood {P : α → Prop} {k : α} {s : State α}
    (hp : P k) (hg : Good P s) : Good P (mark k s) := by
  intro x hx
  rcases List.mem_cons.mp hx with rfl | mem
  · exact hp
  · exact hg x mem

private theorem listSound {P : α → Prop} {f : α → State α → Option (State α)}
    (valid : ∀ k s t, Good P s → f k s = some t → P k ∧ Good P t)
    (ks : List α) (s t : State α) (hg : Good P s) (h : runList f ks s = some t) :
    (∀ k ∈ ks, P k) ∧ Good P t := by
  induction ks generalizing s with
  | nil =>
    have eq : s = t := Option.some.inj h
    subst t
    exact ⟨by simp,hg⟩
  | cons k ks ih =>
    cases e : f k s with
    | none => simp [runList,e] at h
    | some u =>
      have step := valid k s u hg e
      have rest := ih u step.2 (by simpa [runList,e] using h)
      refine ⟨?_,rest.2⟩
      intro x hx
      rcases List.mem_cons.mp hx with rfl | mem
      · exact step.1
      · exact rest.1 x mem

theorem walkSound [DecidableEq α] (r : Rules α) (P : α → Prop)
    (dead : ∀ k, r.dead k = true → P k)
    (step : ∀ k h cs, r.step k h = some cs → (∀ c ∈ cs, P c) → P k)
    (fuel : Nat) (k : α) (s t : State α) (hg : Good P s)
    (ok : walk r fuel k s = some t) : P k ∧ Good P t := by
  induction fuel generalizing k s t with
  | zero => simp [walk] at ok
  | succ fuel ih =>
    by_cases cached : k ∈ s.seen
    · have eq : s = t := by simpa [walk,cached] using ok
      subst t
      exact ⟨hg k cached,hg⟩
    by_cases finished : r.dead k = true
    · have eq : mark k s = t := by simpa [walk,cached,finished] using ok
      subst t
      exact ⟨dead k finished,markGood (dead k finished) hg⟩
    cases hs : s.hints with
    | nil => simp [walk,cached,finished,hs] at ok
    | cons h rest =>
      cases ec : r.step k h with
      | none => simp [walk,cached,finished,hs,ec] at ok
      | some cs =>
        cases et : runList (walk r fuel) cs ⟨s.seen,rest⟩ with
        | none => simp [walk,cached,finished,hs,ec,et] at ok
        | some u =>
          have eq : mark k u = t := by simpa [walk,cached,finished,hs,ec,et] using ok
          subst t
          have all := listSound ih cs ⟨s.seen,rest⟩ u hg et
          have pk := step k h cs ec all.1
          exact ⟨pk,markGood pk all.2⟩

def accepts [DecidableEq α] (r : Rules α) (fuel : Nat) (key : α) (hints : List Nat) : Bool :=
  match walk r fuel key ⟨[],hints⟩ with
  | some t => t.hints.isEmpty
  | none => false

theorem acceptsSound [DecidableEq α] (r : Rules α) (P : α → Prop)
    (dead : ∀ k, r.dead k = true → P k)
    (step : ∀ k h cs, r.step k h = some cs → (∀ c ∈ cs, P c) → P k)
    {fuel key hints} (ok : accepts r fuel key hints = true) : P key := by
  cases e : walk r fuel key ⟨[],hints⟩ with
  | none => simp [accepts,e] at ok
  | some t => exact (walkSound r P dead step fuel key _ t (by intro k h; simp at h) e).1

end Research.H3RegionEngine
