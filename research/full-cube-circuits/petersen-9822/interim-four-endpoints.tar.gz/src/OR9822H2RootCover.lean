import OR9822H2Initial
import Mathlib.Data.Finset.Powerset

namespace Research.Graph9822TwoHidden

/-- A finite cover contains a minimal cover. The test uses single-source deletion. -/
theorem minimal_subcover {V I : Type} [DecidableEq V] (edge : I → V → Prop)
    (need : I → Prop) (A : Finset V)
    (cover : ∀ i, need i → ∃ v ∈ A, edge i v) :
    ∃ b : Finset V, b ⊆ A ∧ (∀ i, need i → ∃ v ∈ b, edge i v) ∧
      ∀ v ∈ b, ¬ (∀ i, need i → ∃ w ∈ b.erase v, edge i w) := by
  classical
  let ok (k : Nat) := ∃ b : Finset V, b ⊆ A ∧ (∀ i, need i → ∃ v ∈ b, edge i v) ∧ b.card = k
  have ex : ∃ k, ok k := ⟨_, A, Finset.Subset.rfl,cover,rfl⟩
  obtain ⟨b,sub,hb,card⟩ := Nat.find_spec ex
  refine ⟨b,sub,hb,?_⟩
  intro v hv smaller
  have witness : ok (b.erase v).card :=
    ⟨_,fun _ hx => sub (Finset.mem_of_mem_erase hx),smaller,rfl⟩
  have bound := Nat.find_min' ex witness
  rw [Finset.card_erase_of_mem hv,card] at bound
  have pos : 0 < b.card := Finset.card_pos.mpr ⟨v,hv⟩
  omega

/-- Across all uncovered rows the optional H/Q cross pair has a single global mode. -/
theorem root_dichotomy {V P N : Type} (T : P → Prop) (row : P → V → Prop)
    (hp qp : P → Prop) (hn qn : N → Prop) (negative : N → V → Prop)
    (witness : ∀ p, T p → qp p ∧
       ((∃ v, row p v ∧ ∀ n, qn n → ¬ negative n v) ∨
          (hp p ∧ ∀ n, hn n → ¬ qn n))) :
    (∀ p, T p → qp p) ∧
      ((∀ p, T p → ∃ v, row p v ∧ ∀ n, qn n → ¬ negative n v) ∨
       ((∀ n, hn n → ¬ qn n) ∧
        ∀ p, T p → ¬ hp p → ∃ v, row p v ∧ ∀ n, qn n → ¬ negative n v)) := by
  classical
  refine ⟨fun p ht => (witness p ht).1,?_⟩
  by_cases cross : ∀ n, hn n → ¬ qn n
  · exact Or.inr ⟨cross,fun p ht cold => (witness p ht).2.elim id
      (fun h => False.elim (cold h.1))⟩
  · exact Or.inl (fun p ht => (witness p ht).2.elim id
      (fun h => False.elim (cross h.2)))

end Research.Graph9822TwoHidden
