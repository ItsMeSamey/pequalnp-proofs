import H3LeafGroup569822
import H3LeafGroup579822
import H3LeafGroup589822
import H3LeafGroup599822
import H3LeafGroup609822
import H3LeafGroup619822
import H3LeafGroup629822
import H3LeafGroup639822
namespace Research.Graph9822H3Leaf
def bag7 : List (Nat × Nat) := gs56 ++ gs57 ++ gs58 ++ gs59 ++ gs60 ++ gs61 ++ gs62 ++ gs63
theorem bagOK7 : bag7.all (fun (h,s) => leafCheck h s)=true := by simp [bag7,pass56,pass57,pass58,pass59,pass60,pass61,pass62,pass63]
end Research.Graph9822H3Leaf
