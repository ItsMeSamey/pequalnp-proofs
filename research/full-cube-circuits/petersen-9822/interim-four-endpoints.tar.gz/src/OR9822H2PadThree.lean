import OR9822H1Padding
import OR9822H2RootEntry
import Mathlib.Tactic.FinCases
namespace Research.Graph9822H2Check
theorem pad_three2 (v : Fin 3 → Fin 10) : ∃ c∈centers,∀ k,c.testBit (v k).val=true := by
  classical
  let s := Finset.univ.image v
  have small : s.card≤3 := Finset.card_image_le.trans (by simp)
  have co : 7≤sᶜ.card := by rw [Finset.card_compl]; simp at *;omega
  obtain ⟨excluded,sub,sz⟩ := Finset.exists_subset_card_eq co
  let t := excludedᶜ
  have card : t.card=3 := by rw [show t=excludedᶜ from rfl,Finset.card_compl,sz];decide
  let e := t.orderEmbOfFin card
  refine ⟨bit (e 0).val ||| bit (e 1).val ||| bit (e 2).val,
    centers_3 (e.strictMono (by decide : (0:Fin 3)<1)) (e.strictMono (by decide : (1:Fin 3)<2)) (e 2).isLt,?_⟩
  intro k
  have vk : v k∈s := Finset.mem_image.mpr ⟨k,Finset.mem_univ _,rfl⟩
  have vt : v k∈t := Finset.mem_compl.mpr (fun hv => (Finset.mem_compl.mp (sub hv)) vk)
  have em : v k∈Set.range e := by rw [show Set.range e=t from t.range_orderEmbOfFin card];exact vt
  obtain ⟨i,eq⟩ := em
  rw [←eq]
  fin_cases i <;> simp [bit,Nat.testBit_two_pow]
end Research.Graph9822H2Check
