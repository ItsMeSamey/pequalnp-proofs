import OR9822CollectorGain
import OR9822RepairShape
import OR9822StarRepair
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FourSaturation

theorem maximal_repair_impossible (c : MaximumFive) (pre post : List Product) (p r : Product)
    (decomp : c.products = pre ++ p :: post)
    (k : Nat) (slot : k = 10+pre.length) (hidden : k ∉ c.out)
    (valid : ValidInputs k r) (apart : ∀ i ∈ r.1, i ∉ r.2)
    (cover : ∀ e ∈ edges, productBit (run pre 10 (fullWire (edgeMask e))) p = true →
      productBit (run pre 10 (fullWire (edgeMask e))) r = true)
    (safe : ∀ m ∈ witnesses, productBit (run pre 10 (fullWire m)) r = false) : False := by
  have count := c.count
  rw [decomp,List.length_append,List.length_cons] at count
  have shape := promoted_shape pre post p r c.out k slot (decomp ▸ c.ordered) (decomp ▸ c.disjoint) valid apart
  have posT : ∀ e ∈ edges, edgeMask e < 1024 ∧ accepts (edgeMask e) = true := by decide +kernel
  have negT : ∀ m ∈ witnesses, m < 1024 ∧ accepts m = false := by decide +kernel
  have pos : ∀ e ∈ edges, resultOn (promoted pre post k r) (k :: omitSource k c.out) (edgeMask e) = true := by
    intro e he
    have tg := posT e he
    apply promoted_row pre post p r c.out _ k slot true
    · simpa [resultOn,← decomp,tg.2] using c.correct ⟨_,tg.1⟩
    · exact fun hp _ => cover e he hp
    · simp
  have neg : ∀ m ∈ witnesses, resultOn (promoted pre post k r) (k :: omitSource k c.out) m = false := by
    intro m hm
    have tg := negT m hm
    apply promoted_row pre post p r c.out m k slot false
    · simpa [resultOn,← decomp,tg.2] using c.correct ⟨m,tg.1⟩
    · simp
    · simp [safe m hm]
  let other := fromRows (promoted pre post k r) _ (by simpa [promoted] using count) shape.1 shape.2 pos neg
  have same : omitSource k c.out = c.out := by
    apply List.filter_eq_self.mpr
    intro i hi
    exact bne_iff_ne.mpr (fun eq => hidden (eq ▸ hi))
  exact maximal_forbids_promotion c other (by omega) (by omega) hidden
    (by change k :: omitSource k c.out = k :: c.out; rw [same])

theorem hidden_leaks (c : MaximumFive) (pre post : List Product) (p : Product)
    (decomp : c.products = pre ++ p :: post) (k : Nat) (slot : k = 10+pre.length)
    (hidden : k ∉ c.out) :
    ∃ m ∈ witnesses, productBit (run pre 10 (fullWire m)) p = true := by
  classical
  by_contra h
  have ordered := ((ordered_append ..).mp ((chronological_iff ..).mp (decomp ▸ c.ordered)).1).2
  apply maximal_repair_impossible c pre post p p decomp k slot hidden
  · simpa [slot] using ordered.1
  · exact c.disjoint p (by rw [decomp]; exact List.mem_append_right _ List.mem_cons_self)
  · exact fun _ _ hp => hp
  · intro m hm
    exact Bool.eq_false_iff.mpr (fun hot => h ⟨m,hm,hot⟩)

theorem hidden_not_star (c : MaximumFive) (pre post : List Product) (p : Product)
    (decomp : c.products = pre ++ p :: post) (k : Nat) (slot : k = 10+pre.length)
    (hidden : k ∉ c.out) (v : Fin 10) :
    ∃ e ∈ edges, productBit (run pre 10 (fullWire (edgeMask e))) p = true ∧
      v.val ≠ e.1 ∧ v.val ≠ e.2 := by
  classical
  by_contra h
  obtain ⟨ord,sep⟩ := star_valid v k (by omega)
  apply maximal_repair_impossible c pre post p (graphStar v) decomp k slot hidden ord sep
  · intro e he hp
    rw [star_prefix]
    apply (star_rows v).2 e he
    by_contra miss
    push_neg at miss
    exact h ⟨e,he,hp,miss⟩
  · intro m hm
    rw [star_prefix]
    exact (star_rows v).1 m hm

end Research.Graph9822.FreeOR
