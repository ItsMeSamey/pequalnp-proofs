import OR9822H2StripeBound024
import OR9822H2StripeBound025
import OR9822H2StripeBound026
import OR9822H2StripeBound027
import OR9822H2StripeBound028
import OR9822H2StripeBound029
import OR9822H2StripeBound030
import OR9822H2StripeBound031
import OR9822H2StripeBound032
import OR9822H2StripeBound033
import OR9822H2StripeBound034
import OR9822H2StripeBound035
namespace Research.Graph9822H2Check.SeedCache
theorem stripeGroup02 (t : Nat) (low : 928≤t) (high : t<1568) : stripe t=true := by
  by_cases l0 : t<960
  · have eq : 928+(t-928)=t := by omega
    simpa only [eq] using boundStripe024 ⟨t-928,by omega⟩
  by_cases l1 : t<1024
  · have eq : 960+(t-960)=t := by omega
    simpa only [eq] using boundStripe025 ⟨t-960,by omega⟩
  by_cases l2 : t<1040
  · have eq : 1024+(t-1024)=t := by omega
    simpa only [eq] using boundStripe026 ⟨t-1024,by omega⟩
  by_cases l3 : t<1056
  · have eq : 1040+(t-1040)=t := by omega
    simpa only [eq] using boundStripe027 ⟨t-1040,by omega⟩
  by_cases l4 : t<1088
  · have eq : 1056+(t-1056)=t := by omega
    simpa only [eq] using boundStripe028 ⟨t-1056,by omega⟩
  by_cases l5 : t<1152
  · have eq : 1088+(t-1088)=t := by omega
    simpa only [eq] using boundStripe029 ⟨t-1088,by omega⟩
  by_cases l6 : t<1184
  · have eq : 1152+(t-1152)=t := by omega
    simpa only [eq] using boundStripe030 ⟨t-1152,by omega⟩
  by_cases l7 : t<1216
  · have eq : 1184+(t-1184)=t := by omega
    simpa only [eq] using boundStripe031 ⟨t-1184,by omega⟩
  by_cases l8 : t<1280
  · have eq : 1216+(t-1216)=t := by omega
    simpa only [eq] using boundStripe032 ⟨t-1216,by omega⟩
  by_cases l9 : t<1408
  · have eq : 1280+(t-1280)=t := by omega
    simpa only [eq] using boundStripe033 ⟨t-1280,by omega⟩
  by_cases l10 : t<1536
  · have eq : 1408+(t-1408)=t := by omega
    simpa only [eq] using boundStripe034 ⟨t-1408,by omega⟩
  by_cases l11 : t<1568
  · have eq : 1536+(t-1536)=t := by omega
    simpa only [eq] using boundStripe035 ⟨t-1536,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
