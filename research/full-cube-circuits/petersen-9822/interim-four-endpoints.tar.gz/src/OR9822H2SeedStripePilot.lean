import OR9822H2SeedStripe
namespace Research.Graph9822H2Check.SeedCache
set_option maxHeartbeats 8000000 in
set_option maxRecDepth 30000 in
theorem stripe31 : ∀ j : Fin 256, stripe (7936+j.val)=true := by decide +kernel
end Research.Graph9822H2Check.SeedCache
