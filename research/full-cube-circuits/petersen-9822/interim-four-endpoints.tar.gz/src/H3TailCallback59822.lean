import H3TailNumericCallbacks9822
namespace Research.H3TailGroups.Case5
def groups : Array Nat := #[0,1,2,0,1,3,4,0,2,0,5,5,6,6,6,6]
def edges : Array Nat := #[1030,24,17,2081,1090,3204,2312,528,2208,640,576,2368,2336]
def negs : Array Nat := #[50,2125,108,116,2187,3273,3280,276,387,402,2571,2573,554,556,771,773]
def bans : Array Nat := #[502,2255,495,3273,3280,2575,815]
def apart : Array Nat := #[2454761972249461008,7364416827437355777,12297697876589613105,2454761972266238224,7364398135738635009,6067285568159748945,2454762248402456852,2454761972266238224,11067989847439712354,2454761972249461008,7364229910460175265,7364229910461223841,56182755760689,56182755760689,112326854716002,112326855764578]
def covers : Array Nat := #[32531022592,17593276567873,36542882440,93459914444805,112151897702400,176609055255466,884775898574]
def reps : Array Nat := #[0,1,2,5,6,10,12]
def surjAt (g : Fin 7) := groupAt groups (Fin.ofNat 16 (reps[g.val]?.getD 0)) == g
theorem onto : Function.Surjective (groupAt groups) := by
  have good : (List.finRange 7).all surjAt = true := by decide +kernel
  intro g
  exact ⟨_,beq_iff_eq.mp (List.all_eq_true.mp good g (List.mem_finRange g))⟩
set_option maxRecDepth 10000 in
set_option maxHeartbeats 5000000 in
theorem classes : (List.finRange 16).all (classPage groups edges negs apart) = true := by decide +kernel
set_option maxRecDepth 10000 in
set_option maxHeartbeats 5000000 in
theorem prohibited : (List.finRange 7).all (banPage groups bans negs covers) = true := by decide +kernel
end Research.H3TailGroups.Case5
