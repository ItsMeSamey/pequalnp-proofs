import H3LeafMask9822
import OR9822H1Fast
namespace Research.Graph9822H3Leaf
open Research.Graph9822H2Check Research.Graph9822OneHidden Research.Graph9822DemandThree
def fastSimple (p n : Nat) : Bool := n==0 || vs.any (fun v => sub p (ep (bit v)))
theorem simple_eq (p n : Nat) : fastSimple p n=notHidden p n := by simp [fastSimple,notHidden,ep_eq]

def fastSeed (h s : Nat) (useH : Bool) (a b : Nat) : Bool := Id.run do
  let hp := if useH then positive h else 0
  let hn := if useH then negative h else 0
  let t := positive s
  let f := negative s
  if meets a b || meets f ((nn a ||| hn) &&& nn b) then return true
  let am := fastFree (f &&& nn b) &&& (1023 ^^^ b)
  let bm := fastFree (f &&& (nn a ||| hn)) &&& (1023 ^^^ a)
  if fastSimple ((ep am ||| hp) &&& ep bm) ((nn am ||| hn) &&& nn bm) then return true
  return (subsets (am &&& (1023 ^^^ a))).all fun ax =>
    let av := a ||| ax
    (subsets (bm &&& (1023 ^^^ (av ||| b)))).all fun bx =>
      let bv := b ||| bx
      let p := (ep av ||| hp) &&& ep bv
      let n := (nn av ||| hn) &&& nn bv
      !sub t p || meets f n || fastSimple p n || exPair h (demand p n)


theorem seed_eq (h s : Nat) (u : Bool) (a b : Nat) :
    fastSeed h s u a b=seedSafe h s u a b := by
  simp only [fastSeed,seedSafe,free_eq,nn_eq,ep_eq,simple_eq]

def shores (t : Nat) := Graph9822H1Check.enumerate ((es.filter t.testBit).map fun i => ends[i]!)
theorem shore_mem (t x : Nat) : x∈shores t ↔ x∈fastCovers t :=
  Graph9822H1Check.enumerate_mem _ x

def leafCheck (h s : Nat) := [false,true].all fun u =>
  let hp := if u then positive h else 0
  (shores (positive s)).all fun b =>
    (shores (positive s &&& (8191 ^^^ hp))).all fun a => fastSeed h s u a b

theorem terminal_of_check {h s : Nat} (ok : leafCheck h s=true) : terminal h s=true := by
  simp only [terminal,leafCheck,List.all_eq_true,shore_mem,seed_eq] at ok ⊢
  exact ok
end Research.Graph9822H3Leaf
#print axioms Research.Graph9822H3Leaf.terminal_of_check
