import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class072 : runPacket packets[72]! = true := by decide +kernel
theorem class073 : runPacket packets[73]! = true := by decide +kernel
theorem class074 : runPacket packets[74]! = true := by decide +kernel
theorem class075 : runPacket packets[75]! = true := by decide +kernel
end Research.Graph9822FirstBroad
