import H2Key85Sound9822
import H2Root85Physical9822
import OR9822H2SeedRootFacts
namespace Research.Graph9822H2Check
open Research.Graph9822Implication Research.Graph9822H2Local SeedCache

theorem firstRealKey {q : Nat} (cache : ∀ t : Fin 8192, stripe t.val = true)
    (checks : allSeeds 33847320 (rootCovered key85dead [535693216]) = true) :
    ¬ViableTwo 33847320 q := by
  intro v
  obtain ⟨r,mem,live⟩ := frozen_roots [535693216] key85dead cache checks v (fun _ => key85reject v)
  have eq : r = 535693216 := List.mem_singleton.mp mem
  exact root85Physical v checkedLanes checkedArcs (eq ▸ live)

end Research.Graph9822H2Check
