import H2Key85Bank9822
namespace Research.Graph9822Implication
set_option maxRecDepth 10000 in
set_option maxHeartbeats 5000000 in
theorem key85part1Good : key85part1.all good = true := by decide +kernel
end Research.Graph9822Implication
