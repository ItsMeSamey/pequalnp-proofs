import H3ImpFast9822
import H3ImpLiteralValue9822
namespace Research.Graph9822Implication
open Research.Graph9822H2Check Research.Graph9822OneHidden Research.Graph9822H3Implication

abbrev Primitive := Nat × Nat × Nat
def clauses (c x y : Nat) : List Primitive := [(c,x,y),(c,y,x)]
def edgeEnds : List (Nat × Nat) :=
  [(1,2),(3,4),(0,4),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(6,9),(6,8),(5,8)]

def primitive : List Primitive :=
  (edgeEnds.zipIdx.flatMap fun ((v,w),i) =>
    clauses (bit i) (20+2*v) (20+2*w) ++ clauses (bit (13+i)) (2*v) (2*w)) ++
  (vs.flatMap fun v => clauses 0 (2*v+1) (21+2*v)) ++
  (sourcePairs.zipIdx.flatMap fun ((v,w),i) =>
    clauses (bit (26+i)) (2*v+1) (21+2*w) ++ clauses (bit (26+i)) (2*w+1) (21+2*v)) ++
  (vs.flatMap fun v => clauses (bit (58+v)) (21+2*v) (21+2*v))

def validArcsAt (l : Nat) : Bool := (List.range 40).all fun r =>
  (clauseBit l r).all fun c => primitive.contains (c,opp l,r)

def SatPrim (value : Nat → Bool) (sig : Nat) : Prop :=
  ∀ c x y, (c,x,y) ∈ primitive → sub c sig = true → value x = true ∨ value y = true

theorem implicationOfClause {value : Nat → Bool} {sig l r : Nat}
    (opposite : ∀ u, value (opp u) = !value u) (sat : SatPrim value sig)
    (arc : ∀ c, clauseBit l r = some c → (c,opp l,r) ∈ primitive)
    (on : allowed sig l r = true) : value l = true → value r = true := by
  cases eq : clauseBit l r with
  | none => simp [allowed,eq] at on
  | some c =>
    have subc : sub c sig = true := by simpa [allowed,eq] using on
    intro yes
    rcases sat c _ _ (arc c eq) subc with left | right
    · simp [opposite l,yes] at left
    · exact right

end Research.Graph9822Implication
