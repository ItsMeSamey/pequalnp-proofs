import OR9822H2Seed85Lane00
import OR9822H2Seed85Lane01
import OR9822H2Seed85Lane02
import OR9822H2Seed85Lane03
import OR9822H2Seed85Lane04
import OR9822H2Seed85Lane05
import OR9822H2Seed85Lane06
import OR9822H2Seed85Lane07
import OR9822H2Seed85Lane08
import OR9822H2Seed85Lane09
import OR9822H2Seed85Lane10
import OR9822H2Seed85Lane11
import OR9822H2Seed85Lane12
import OR9822H2Seed85Lane13
import OR9822H2Seed85Lane14
namespace Research.Graph9822H2Check.SeedCache
open Research.Graph9822Implication
theorem key85_all : allSeeds 33847320 (rootCovered key85dead [535693216])=true := by
  apply lanes_sound 33847320 6144 _ (by decide +kernel)
  intro lane mem
  simp only [centerLanes,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact lane85_00
  · exact lane85_01
  · exact lane85_02
  · exact lane85_03
  · exact lane85_04
  · exact lane85_05
  · exact lane85_06
  · exact lane85_07
  · exact lane85_08
  · exact lane85_09
  · exact lane85_10
  · exact lane85_11
  · exact lane85_12
  · exact lane85_13
  · exact lane85_14
end Research.Graph9822H2Check.SeedCache
