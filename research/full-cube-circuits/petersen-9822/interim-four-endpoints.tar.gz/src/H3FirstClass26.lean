import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class104 : runPacket packets[104]! = true := by decide +kernel
theorem class105 : runPacket packets[105]! = true := by decide +kernel
theorem class106 : runPacket packets[106]! = true := by decide +kernel
theorem class107 : runPacket packets[107]! = true := by decide +kernel
end Research.Graph9822FirstBroad
