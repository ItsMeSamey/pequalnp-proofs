import OR9822H2PhysicalRows
import And9822NormalizedWitness
namespace Research.Graph9822.FreeOR
open Research.Graph9822.FeatureRun Research.Graph9822Resolution Research.Graph9822H2Check Research.Graph9822TwoHidden
open Research.Graph9822.FourSaturation (witnesses)
private theorem rowN (n : Fin 16) : rawRow ⟨13+n.val,by omega⟩ = witnesses[n.val]! := by simp [rawRow]
theorem literal_two_leaks (c : MaximumFive) (p q : Product) (ts : List Product)
    (ps : c.products=p::q::ts) (out : c.out=List.range' 12 ts.length) :
    (∃ n : Fin 16,(negative (firstSig p)).testBit n.val=true) ∧
    (∃ n : Fin 16,(negative (secondSig p q)).testBit n.val=true) := by
  have hidden (k : Nat) (lo : k<12) : k∉c.out := by
    rw [out]; intro mem
    obtain ⟨j,_,eq⟩ := List.mem_range'.mp mem
    omega
  constructor
  · obtain ⟨m,hm,on⟩ := hidden_leaks c [] (q::ts) p ps 10 rfl (hidden 10 (by decide))
    obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hm
    let n : Fin 16 := ⟨i,by simpa [witnesses] using hi⟩
    refine ⟨n,?_⟩
    rw [firstSig,neg_col_bit]
    change productBit (fun j => rawBank j ⟨13+n.val,by omega⟩) p=true
    rw [←actual_input,rowN,getElem!_pos witnesses i hi,eq]
    exact on
  · obtain ⟨m,hm,on⟩ := hidden_leaks c [p] ts q ps 11 rfl (hidden 11 (by decide))
    obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hm
    let n : Fin 16 := ⟨i,by simpa [witnesses] using hi⟩
    let r : Fin 29 := ⟨13+n.val,by omega⟩
    refine ⟨n,?_⟩
    rw [secondSig,neg_col_bit]
    change productBit (fun j => runColumns [p] 10 rawBank j r) q=true
    rw [scalar_run,←actual_input]
    dsimp only [r]
    rw [rowN,getElem!_pos witnesses i hi,eq]
    exact on
end Research.Graph9822.FreeOR
