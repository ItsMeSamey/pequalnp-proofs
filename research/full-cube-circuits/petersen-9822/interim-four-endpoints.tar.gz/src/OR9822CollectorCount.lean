import And9822FreeORDefs
namespace Research.Graph9822.FreeOR

theorem filter_gain (xs out : List Nat) (k : Nat) (fresh : k ∉ out)
    (nodup : xs.Nodup) (used : k ∈ xs) :
    (xs.filter (k :: out).contains).length = (xs.filter out.contains).length + 1 := by
  induction xs with
  | nil => simp at used
  | cons j xs ih =>
    rw [List.nodup_cons] at nodup
    by_cases eq : j=k
    · subst j
      have same : xs.filter (k :: out).contains = xs.filter out.contains := by
        apply List.filter_congr
        intro v hv
        have ne : v ≠ k := fun e => nodup.1 (e ▸ hv)
        simp [List.contains_cons,ne,Ne.symm ne]
      simp [List.filter_cons,same,fresh]
    · have mem : k ∈ xs := (List.mem_cons.mp used).resolve_left (Ne.symm eq)
      have h := ih nodup.2 mem
      by_cases seen : j ∈ out
      · simp [List.filter_cons,seen,eq,Ne.symm eq,h]
      · simp [List.filter_cons,seen,eq,Ne.symm eq,h]

end Research.Graph9822.FreeOR
