import And9822FreeORDefs
import OR9822HiddenTriangle
import FourSaturationData

namespace Research.Graph9822.FeatureRun
open Research.Graph9822Resolution Research.Graph9822.FreeOR

abbrev Column := Fin 29 → Bool
abbrev Bank := Nat → Column

def rawRow : Fin 29 → Nat
  | i => if i.val < 13 then Research.Graph9822OneHidden.edges[i.val]!
         else Research.Graph9822.FourSaturation.witnesses[i.val-13]!

def rawBank : Bank := fun v i => (rawRow i).testBit v

def readColumn (w : Bank) (a : Arm) : Column := fun i => a.any (fun j => w j i)
def productColumn (w : Bank) (p : Product) : Column :=
  fun i => readColumn w p.1 i && readColumn w p.2 i

def runColumns : List Product → Nat → Bank → Bank
  | [],_,w => w
  | p::ps,k,w => runColumns ps (k+1) (Function.update w k (productColumn w p))

theorem scalar_run (ps : List Product) (k : Nat) (w : Bank) (i : Fin 29) :
    (fun j => runColumns ps k w j i) = run ps k (fun j => w j i) := by
  induction ps generalizing k w with
  | nil => rfl
  | cons p ps ih =>
    simp only [runColumns,run]
    rw [ih]
    apply congrArg (run ps (k+1))
    funext j
    by_cases eq : j=k
    · subst j
      simp [productColumn,readColumn,productBit,readArm]
    · simp [Function.update_of_ne eq]

theorem output_scalar (ps : List Product) (k : Nat) (out : Arm) (i : Fin 29) :
    readColumn (runColumns ps k rawBank) out i =
    readArm (run ps k (fun v => (rawRow i).testBit v)) out := by
  unfold readColumn readArm
  exact congrArg (fun f => out.any f) (scalar_run ps k rawBank i)

end Research.Graph9822.FeatureRun
