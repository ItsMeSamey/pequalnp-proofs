import OR9822FeatureMask
import OR9822FiveMinimum
namespace Research.Graph9822.FeatureRun
open Research.Graph9822.FreeOR Research.Graph9822Resolution
open Research.Graph9822H2Check (positive negative)

def firstCol (p : Product) : Column := productColumn rawBank p
def secondCol (p q : Product) : Column := productColumn (Function.update rawBank 10 (firstCol p)) q

theorem raw_row_small : ∀ r : Fin 29, rawRow r < 1024 := by decide +kernel

theorem actual_input (i : Fin 29) : fullWire (rawRow i) = (fun j => rawBank j i) := by
  funext j
  by_cases lt : j < 10
  · simp [fullWire,rawBank,lt]
  · have z : (rawRow i).testBit j = false := Nat.testBit_lt_two_pow
      (lt_of_lt_of_le (raw_row_small i) (show (1024 : Nat) ≤ 2^j from
        Nat.pow_le_pow_right (by decide : 0<2) (by omega : 10≤j)))
    simp [fullWire,rawBank,lt,z]

theorem after_two (p q : Product) (i : Fin 29) (j : Nat) :
    run [p,q] 10 (fullWire (rawRow i)) j =
      if j=11 then secondCol p q i else if j=10 then firstCol p i else rawBank j i := by
  rw [actual_input,← scalar_run [p,q] 10 rawBank i]
  by_cases eq : j=11 <;> by_cases ej : j=10 <;>
    simp [runColumns,eq,ej,firstCol,secondCol]

theorem pos_col_bit (c : Column) (e : Fin 13) :
    (positive (encode c)).testBit e.val = c ⟨e.val,by omega⟩ := by
  have lo : (8191:Nat).testBit e.val = true := by
    change (2^13-1 : Nat).testBit e.val = true; rw [Nat.testBit_two_pow_sub_one]; simp [e.isLt]
  simpa [positive,Nat.testBit_and,lo] using encode_bit c ⟨e.val,by omega⟩

theorem neg_col_bit (c : Column) (n : Fin 16) :
    (negative (encode c)).testBit n.val = c ⟨13+n.val,by omega⟩ := by
  simpa [negative] using encode_bit c ⟨13+n.val,by omega⟩

end Research.Graph9822.FeatureRun
