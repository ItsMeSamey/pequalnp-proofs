import OR9822H2SeedStripeFields
namespace Research.Graph9822H2Check.SeedCache
set_option maxHeartbeats 6000000 in
set_option maxRecDepth 16000 in
theorem checkRaw06 : ∀ i : Fin 128, rawChecked (768+i.val)=true := by decide +kernel
end Research.Graph9822H2Check.SeedCache
