import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class120 : runPacket packets[120]! = true := by decide +kernel
theorem class121 : runPacket packets[121]! = true := by decide +kernel
end Research.Graph9822FirstBroad
