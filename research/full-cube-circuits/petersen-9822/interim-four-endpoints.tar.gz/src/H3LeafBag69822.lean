import H3LeafGroup489822
import H3LeafGroup499822
import H3LeafGroup509822
import H3LeafGroup519822
import H3LeafGroup529822
import H3LeafGroup539822
import H3LeafGroup549822
import H3LeafGroup559822
namespace Research.Graph9822H3Leaf
def bag6 : List (Nat × Nat) := gs48 ++ gs49 ++ gs50 ++ gs51 ++ gs52 ++ gs53 ++ gs54 ++ gs55
theorem bagOK6 : bag6.all (fun (h,s) => leafCheck h s)=true := by simp [bag6,pass48,pass49,pass50,pass51,pass52,pass53,pass54,pass55]
end Research.Graph9822H3Leaf
