import OR9822H2Initial
import FourSaturationData

namespace Research.Graph9822TwoHidden
open Research.Graph9822.FourSaturation

private def adj (u v : Fin 10) := edges.contains (u.val,v.val) || edges.contains (v.val,u.val)

private theorem no_square : ∀ u v a c : Fin 10, u ≠ v →
    adj u a = true → adj v a = true → adj u c = true → adj v c = true → a = c := by
  decide +kernel

def negRaw (n : Fin 16) (v : Fin 10) : Bool := (witnesses[n.val]!).testBit v.val

theorem cross_adj : ∀ u v : Fin 10, (∀ n : Fin 16, ¬(negRaw n u = true ∧ negRaw n v = true)) →
    adj u v = true := by decide +kernel

/-- One raw center for each physical terminal's raw/raw contributions. -/
theorem raw_center (a : Arms (Source (Fin 10))) (hn qn : Fin 16 → Prop)
    (safe : ∀ n, ¬a.accepts (fun s n => sourceRow (fun v => negRaw n v = true) (hn n) (qn n) s) n) :
    ∃ c : Fin 10, ∀ u v, a.left (.raw u) → a.right (.raw v) → c = u ∨ c = v := by
  classical
  have adjPair (u v : Fin 10) (l : a.left (.raw u)) (r : a.right (.raw v)) : adj u v = true :=
    cross_adj u v (fun n both => safe n ⟨⟨_,l,both.1⟩,⟨_,r,both.2⟩⟩)
  by_cases two : ∃ u v, u ≠ v ∧ a.left (.raw u) ∧ a.left (.raw v)
  · obtain ⟨u,v,ne,lu,lv⟩ := two
    by_cases nonempty : ∃ d, a.right (.raw d)
    · obtain ⟨d,rd⟩ := nonempty
      exact ⟨d,fun _ b _ rb => Or.inr (no_square u v d b ne (adjPair _ _ lu rd)
        (adjPair _ _ lv rd) (adjPair _ _ lu rb) (adjPair _ _ lv rb))⟩
    · exact ⟨0,fun _ b _ rb => False.elim (nonempty ⟨b,rb⟩)⟩
  · by_cases nonempty : ∃ d, a.left (.raw d)
    · obtain ⟨d,ld⟩ := nonempty
      exact ⟨d,fun u _ lu _ => Or.inl (Classical.byContradiction (fun h => two ⟨d,u,h,ld,lu⟩))⟩
    · exact ⟨0,fun u _ lu _ => False.elim (nonempty ⟨u,lu⟩)⟩

end Research.Graph9822TwoHidden
