import OR9822H2SeedNibble
import Mathlib.Tactic.FinCases
namespace Research.Graph9822H2Check.SeedCache

theorem clip_bits (lut : Nat → Nat) (val : Nat) (j x : Nat)
    (law : ∀ z : Fin 64,(lut z.val).testBit j= sub (z.val%16) (nib val (z.val/16))) :
    (clip lut x).testBit j=true ↔ ∀ k : Fin 4, sub (nib x k.val) (nib val k.val)=true := by
  have each (k : Nat) (lo : k<4) : (lut (16*k+nib x k)).testBit j=sub (nib x k) (nib val k) := by
    have n : nib x k<16 := Nat.mod_lt _ (by decide)
    have idx : 16*k+nib x k<64 := by omega
    have m : (16*k+nib x k)%16=nib x k := by omega
    have d : (16*k+nib x k)/16=k := by omega
    simpa only [m,d] using law ⟨_,idx⟩
  have e0 := each 0 (by decide)
  have e1 := each 1 (by decide)
  have e2 := each 2 (by decide)
  have e3 := each 3 (by decide)
  simp [nib] at e0 e1 e2 e3
  simp only [clip,Nat.testBit_and,Bool.and_eq_true]
  constructor
  · rintro ⟨⟨⟨a,b⟩,c⟩,d⟩ k
    fin_cases k <;> simp_all [nib]
  · intro cuts
    exact ⟨⟨⟨by simpa [e0,nib] using cuts 0,by simpa [e1,nib] using cuts 1⟩,
      by simpa [e2,nib] using cuts 2⟩,by simpa [e3,nib] using cuts 3⟩

theorem paint_bit {j : Nat} (fs : List Nat) :
    (paint fs).testBit j=true ↔ ∃ f∈fs,(clip nClip f).testBit j=true := by
  induction fs with
  | nil => simp [paint]
  | cons x xs ih =>
    change ((clip nClip x) ||| paint xs).testBit j=true ↔ _
    rw [Nat.testBit_or,Bool.or_eq_true,ih]
    constructor
    · rintro (a|⟨f,hm,b⟩)
      · exact ⟨_,List.mem_cons_self,a⟩
      · exact ⟨f,List.mem_cons_of_mem _ hm,b⟩
    · rintro ⟨f,mem,hot⟩
      rcases List.mem_cons.mp mem with rfl|hm
      · exact Or.inl hot
      · exact Or.inr ⟨_,hm,hot⟩

end Research.Graph9822H2Check.SeedCache
