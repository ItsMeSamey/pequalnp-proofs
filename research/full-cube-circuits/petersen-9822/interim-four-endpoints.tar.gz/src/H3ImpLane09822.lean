import H3ImpLaneSpec9822
namespace Research.Graph9822Implication
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem lane0Good : laneGood 0 = true := by decide +kernel
end Research.Graph9822Implication
