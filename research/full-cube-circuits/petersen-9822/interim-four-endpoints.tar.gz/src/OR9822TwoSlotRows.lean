import OR9822TwoSlotValue
import OR9822H2PackedRow
import OR9822H2Rescue
namespace Research.Graph9822.FeatureRun
open Research.Graph9822.FreeOR Research.Graph9822Resolution
open Research.Graph9822H2Check Research.Graph9822TwoHidden

def productArms (p : Product) : Arms Nat := ⟨(· ∈ p.1),(· ∈ p.2)⟩

private theorem rawNegSlot : ∀ v : Fin 10, ∀ n : Fin 16,
    (rawNeg (bit v.val)).testBit n.val = rawBank v.val ⟨13+n.val,by omega⟩ := by decide +kernel

private theorem slot_pos (p q : Product) (e : Fin 13) (j : Nat) (bound : j<12) :
    run [p,q] 10 (fullWire (rawRow ⟨e.val,by omega⟩)) j = true ↔
      numericPos (encode (firstCol p)) (encode (secondCol p q)) e.val j := by
  rw [after_two]
  by_cases raw : j<10
  · have n10 : j≠10 := by omega
    have n11 : j≠11 := by omega
    simp [numericPos,labels,vs,raw,rawBank,rawRow,e.isLt,n10,n11,List.mem_append]
  · rcases (by omega : j=10 ∨ j=11) with rfl | rfl
    · simp [numericPos,labels,vs,pos_col_bit,e.isLt]
    · simp [numericPos,labels,vs,pos_col_bit,e.isLt]

private theorem slot_neg (p q : Product) (n : Fin 16) (j : Nat) (bound : j<12) :
    run [p,q] 10 (fullWire (rawRow ⟨13+n.val,by omega⟩)) j =
      numericNeg (encode (firstCol p)) (encode (secondCol p q)) j n := by
  rw [after_two]
  by_cases raw : j<10
  · have n10 : j≠10 := by omega
    have n11 : j≠11 := by omega
    simpa [numericNeg,fixedNeg,n10,n11] using (rawNegSlot ⟨j,raw⟩ n).symm
  · rcases (by omega : j=10 ∨ j=11) with rfl | rfl <;>
      simp [numericNeg,fixedNeg,neg_col_bit]

theorem terminal_positive (p q t : Product) (bound : ∀ j, j ∈ t.1 ∨ j ∈ t.2 → j<12)
    (e : Fin 13) :
    productBit (run [p,q] 10 (fullWire (rawRow ⟨e.val,by omega⟩))) t = true ↔
      (productArms t).accepts (fun u e => numericPos (encode (firstCol p))
        (encode (secondCol p q)) e.val u) e := by
  simp only [productBit,readArm,Bool.and_eq_true,List.any_eq_true,Arms.accepts,productArms]
  constructor
  · rintro ⟨⟨i,hi,vi⟩,⟨j,hj,vj⟩⟩
    exact ⟨⟨i,hi,(slot_pos p q e i (bound _ (Or.inl hi))).1 vi⟩,
      ⟨j,hj,(slot_pos p q e j (bound _ (Or.inr hj))).1 vj⟩⟩
  · rintro ⟨⟨i,hi,vi⟩,⟨j,hj,vj⟩⟩
    exact ⟨⟨i,hi,(slot_pos p q e i (bound _ (Or.inl hi))).2 vi⟩,
      ⟨j,hj,(slot_pos p q e j (bound _ (Or.inr hj))).2 vj⟩⟩

theorem terminal_negative (p q t : Product) (bound : ∀ j, j ∈ t.1 ∨ j ∈ t.2 → j<12)
    (n : Fin 16) :
    productBit (run [p,q] 10 (fullWire (rawRow ⟨13+n.val,by omega⟩))) t = true ↔
      (productArms t).accepts (fun u n => numericNeg (encode (firstCol p))
        (encode (secondCol p q)) u n = true) n := by
  simp only [productBit,readArm,Bool.and_eq_true,List.any_eq_true,Arms.accepts,productArms]
  constructor <;> rintro ⟨⟨i,hi,vi⟩,⟨j,hj,vj⟩⟩ <;>
    exact ⟨⟨i,hi,by simpa [slot_neg p q n i (bound _ (Or.inl hi))] using vi⟩,
      ⟨j,hj,by simpa [slot_neg p q n j (bound _ (Or.inr hj))] using vj⟩⟩

end Research.Graph9822.FeatureRun
