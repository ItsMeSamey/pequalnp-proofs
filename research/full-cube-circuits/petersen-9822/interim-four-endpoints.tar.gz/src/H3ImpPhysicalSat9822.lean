import H3ImpFields9822
import OR9822H2NestedSaturation
namespace Research.Graph9822Implication
open Research.Graph9822H2Check Research.Graph9822H3Implication
open Research.Graph9822OneHidden (meets edges)
open Research.Graph9822.FourSaturation (witnesses)

private def Fits (value : Nat → Bool) (sig : Nat) (ls : List Primitive) : Prop :=
  ∀ c x y, (c,x,y) ∈ ls → sub c sig = true → value x = true ∨ value y = true

private theorem appendFits {V S a b} (ha : Fits V S a) (hb : Fits V S b) : Fits V S (a++b) := by
  intro c x y mem subc
  exact (List.mem_append.mp mem).elim (fun m => ha _ _ _ m subc) (fun m => hb _ _ _ m subc)

private theorem flatFits {α : Type} {V S} {ls : List α} {f : α → List Primitive}
    (each : ∀ z ∈ ls, Fits V S (f z)) : Fits V S (ls.flatMap f) := by
  intro c x y mem subc
  obtain ⟨z,hz,hit⟩ := List.mem_flatMap.mp mem
  exact each z hz c x y hit subc

private theorem pairFits {V S c x y}
    (p : sub c S = true → V x = true ∨ V y = true) : Fits V S (clauses c x y) := by
  intro d a b mem gate
  simp only [clauses,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with eq | eq
  · cases eq; exact p gate
  · cases eq; exact (p gate).symm

private theorem litRows (A B v : Nat) (ab : A<1024) (hv : v<10) :
    let f := literalValue (A ||| (B <<< 10))
    f (2*v) = A.testBit v ∧ f (2*v+1) = !A.testBit v ∧
    f (20+2*v) = B.testBit v ∧ f (21+2*v) = !B.testBit v := by
  have enc : ∀ z : Fin 10,
      (2*z.val) >>> 1 = z.val ∧ (2*z.val).testBit 0 = false ∧
      (2*z.val+1) >>> 1 = z.val ∧ (2*z.val+1).testBit 0 = true ∧
      (20+2*z.val) >>> 1 = 10+z.val ∧ (20+2*z.val).testBit 0 = false ∧
      (21+2*z.val) >>> 1 = 10+z.val ∧ (21+2*z.val).testBit 0 = true := by decide +kernel
  obtain ⟨i,j,k,l,m,n,o,p⟩ := enc ⟨v,hv⟩
  have off : A.testBit (10+v) = false := Nat.testBit_lt_two_pow
    (lt_of_lt_of_le ab (show 1024 ≤ 2^(10+v) from Nat.pow_le_pow_right (by decide : 0 < (2 : Nat)) (by omega : 10≤10+v)))
  dsimp only
  simp [literalValue,i,j,k,l,m,n,o,p,Nat.testBit_or,Nat.testBit_shiftLeft,
    show ¬v≥10 by omega,show 10+v≥10 by omega,off]

private theorem edgeData : edgeEnds.zipIdx.all (fun ((v,w),i) =>
    decide (v<10 ∧ w<10 ∧ i<13) && (edges[i]! == (bit v ||| bit w))) = true := by decide +kernel

private theorem crossData : sourcePairs.zipIdx.all (fun ((v,w),_) =>
    decide (v<10 ∧ w<10)) = true := by decide +kernel

private theorem endpoint {i v w A : Nat} (hi : i<13) (row : edges[i]! = bit v ||| bit w)
    (read : (rawPos A).testBit i = true) : A.testBit v=true ∨ A.testBit w=true := by
  rw [raw_pos_bit A ⟨i,hi⟩,row] at read
  obtain ⟨k,hk,mem⟩ := meets_iff_exists.mp read
  simp [bit,Nat.testBit_or,Nat.testBit_two_pow] at mem
  rcases mem with eq | eq
  · exact Or.inl (by simpa [eq] using hk)
  · exact Or.inr (by simpa [eq] using hk)

theorem physicalSatPrim {h q A B s : Nat} {useH : Bool} (fields : PhysicalFields h s useH)
    (rows : NestedBits h q A B useH) (ab : A<1024) (apart : meets A B=false)
    (live : holds q s) : SatPrim (literalValue (A ||| (B <<< 10))) (fastSig h s useH) := by
  have block (n : Fin 16) (need : (negative s).testBit n=true) :
      ¬ (((rawNeg A).testBit n=true ∨ (useH=true ∧ (negative h).testBit n=true)) ∧
            (rawNeg B).testBit n=true) := by
    have no := false_on_demand live n need
    rw [rows.neg] at no
    intro hot
    have yes : (((rawNeg A).testBit n || (useH && (negative h).testBit n)) &&
        (rawNeg B).testBit n) = true := by simpa using hot
    rw [yes] at no
    contradiction
  have hit (a v : Nat) (n : Fin 16) (av : a.testBit v=true)
      (wv : witnesses[n.val]!.testBit v=true) : (rawNeg a).testBit n=true := by
    rw [raw_neg_bit]
    exact meets_iff_exists.mpr ⟨v,av,wv⟩
  unfold SatPrim primitive
  apply appendFits
  · apply appendFits
    · apply appendFits
      · apply flatFits
        rintro ⟨⟨v,w⟩,i⟩ mem
        obtain ⟨bounds,eq⟩ := Bool.and_eq_true_iff.mp (List.all_eq_true.mp edgeData _ mem)
        obtain ⟨hv,hw,hi⟩ : v<10 ∧ w<10 ∧ i<13 := of_decide_eq_true bounds
        have eg : edges[i]! = bit v ||| bit w := beq_iff_eq.mp eq
        have hot (need : (positive s).testBit i=true) :
            ((rawPos A).testBit i || (useH && (positive h).testBit i)) = true ∧
            (rawPos B).testBit i = true := by
          have yes := true_on_demand live ⟨i,hi⟩ need
          rw [rows.pos] at yes
          exact Bool.and_eq_true_iff.mp yes
        apply appendFits
        · apply pairFits
          intro gate
          rw [(litRows A B v ab hv).2.2.1,(litRows A B w ab hw).2.2.1]
          exact endpoint hi eg (hot (fields.posB i v w mem gate)).2
        · apply pairFits
          intro gate
          obtain ⟨need,noH⟩ := fields.posA i v w mem gate
          rw [(litRows A B v ab hv).1,(litRows A B w ab hw).1]
          have casesHot : (rawPos A).testBit i = true ∨ (useH && (positive h).testBit i) = true := by
            simpa only [Bool.or_eq_true] using (hot need).1
          rcases casesHot with a | hH
          · exact endpoint hi eg a
          · exact (noH (Bool.and_eq_true_iff.mp hH)).elim
      · apply flatFits
        intro v mem
        have hv := List.mem_range.mp (show v∈List.range 10 from mem)
        apply pairFits
        intro _
        rw [(litRows A B v ab hv).2.1,(litRows A B v ab hv).2.2.2]
        by_cases ha : A.testBit v=true
        · simp [(empty_overlap ..).1 apart v ha]
        · simp [Bool.eq_false_iff.mpr ha]
    · apply flatFits
      rintro ⟨⟨v,w⟩,i⟩ mem
      obtain ⟨hv,hw⟩ : v<10 ∧ w<10 := of_decide_eq_true (List.all_eq_true.mp crossData _ mem)
      have noCross (v w : Nat) (hv : v<10) (hw : w<10) (n : Fin 16)
          (need : (negative s).testBit n=true) (vOn : witnesses[n.val]!.testBit v=true)
          (wOn : witnesses[n.val]!.testBit w=true) :
          literalValue (A ||| (B <<< 10)) (2*v+1)=true ∨
            literalValue (A ||| (B <<< 10)) (21+2*w)=true := by
        rw [(litRows A B v ab hv).2.1,(litRows A B w ab hw).2.2.2]
        by_cases ha : A.testBit v=true
        · have hb : B.testBit w=false := Bool.eq_false_iff.mpr fun yes =>
            block n need ⟨Or.inl (hit A v n ha vOn),hit B w n yes wOn⟩
          simp [hb]
        · simp [Bool.eq_false_iff.mpr ha]
      apply appendFits
      · apply pairFits
        intro gate
        obtain ⟨n,nd,vOn,wOn⟩ := fields.cross i v w mem gate
        exact noCross v w hv hw n nd vOn wOn
      · apply pairFits
        intro gate
        obtain ⟨n,nd,vOn,wOn⟩ := fields.cross i v w mem gate
        exact noCross w v hw hv n nd wOn vOn
  · apply flatFits
    intro v mem
    have hv := List.mem_range.mp (show v∈List.range 10 from mem)
    apply pairFits
    intro gate
    obtain ⟨on,n,need,here,vOn⟩ := fields.unit v mem gate
    have off : B.testBit v=false := Bool.eq_false_iff.mpr fun yes =>
      block n need ⟨Or.inr ⟨on,here⟩,hit B v n yes vOn⟩
    simp [(litRows A B v ab hv).2.2.2,off]

end Research.Graph9822Implication
