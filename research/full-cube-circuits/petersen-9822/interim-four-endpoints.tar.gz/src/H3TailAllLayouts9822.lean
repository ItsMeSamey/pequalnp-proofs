import H3TailMonotone9822
namespace Research.H3Tail

def Obstructed (edges : Array Nat) (arms : Arms) : Prop :=
  ∃ d < 7, ∃ i < 13, ∃ edge, edges[i]? = some edge ∧ Banned arms d edge

def EveryLayout (edges bans : Array Nat) : List Nat → List Nat → Arms → Prop
  | [],_,arms => Obstructed edges arms
  | slot :: slots,unused,arms => ∀ g ∈ unused, ∀ b, bans[g]? = some b →
    EveryLayout edges bans slots (unused.erase g) (add arms slot b)

private theorem propagate {edges bans : Array Nat} {arms : Arms}
    (slots unused : List Nat) (blocked : Obstructed edges arms) :
    EveryLayout edges bans slots unused arms := by
  induction slots generalizing unused arms with
  | nil => exact blocked
  | cons slot slots ih =>
    intro g hg b hb
    obtain ⟨d,hd,i,hi,e,he,h⟩ := blocked
    exact ih _ ⟨d,hd,i,hi,e,he,bannedAdd arms slot b d e h⟩

private theorem fromBits (a : Arms) (d e : Nat) (h : e &&& block a d = e) :
    Banned a d e := by
  intro f yes
  have bits := congrArg (fun n : Nat => n.testBit f) h
  simpa [Nat.testBit_and,yes] using bits

private theorem foldCases {α β : Type} (f : α → β → Option α) (items : List β)
    (start stop : α) (ok : items.foldlM f start = some stop) :
    ∀ x ∈ items, ∃ a b, f a x = some b := by
  induction items generalizing start with
  | nil => simp
  | cons x xs ih =>
    cases hx : f start x with
    | none => simp [List.foldlM,hx] at ok
    | some a =>
      have tail := ih a (by simpa [List.foldlM,hx] using ok)
      intro y hy
      rcases List.mem_cons.mp hy with rfl | h
      · exact ⟨start,a,hx⟩
      · exact tail y h

theorem visitSound (edges bans : Array Nat) (slots unused : List Nat) (arms : Arms)
    (tape rest : List Nat) (ok : visit edges bans slots unused arms tape = some rest) :
    EveryLayout edges bans slots unused arms := by
  induction slots generalizing unused arms tape rest with
  | nil =>
    cases tape with
    | nil => simp [visit] at ok
    | cons c cs =>
      by_cases leaf : c < 91
      · cases eq : edges[c % 13]? with
        | none => simp [visit,leaf,eq] at ok
        | some e =>
          by_cases hit : e &&& block arms (c / 13) = e
          · exact ⟨c/13,by omega,c%13,by omega,e,eq,fromBits arms _ _ hit⟩
          · simp [visit,leaf,eq,hit] at ok
      · by_cases branch : c = 127 <;> simp [visit,leaf,branch] at ok
  | cons slot slots ih =>
    cases tape with
    | nil => simp [visit] at ok
    | cons c cs =>
      by_cases leaf : c < 91
      · cases eq : edges[c % 13]? with
        | none => simp [visit,leaf,eq] at ok
        | some e =>
          by_cases hit : e &&& block arms (c / 13) = e
          · exact propagate _ _ ⟨c/13,by omega,c%13,by omega,e,eq,fromBits arms _ _ hit⟩
          · simp [visit,leaf,eq,hit] at ok
      · by_cases branch : c = 127
        · simp only [visit,leaf,if_false,branch,beq_self_eq_true,if_true] at ok
          intro g hg b hb
          obtain ⟨t,u,run⟩ := foldCases _ _ _ _ ok g hg
          apply ih (unused.erase g) (add arms slot b) t u
          simpa [hb] using run
        · simp [visit,leaf,branch] at ok

end Research.H3Tail
