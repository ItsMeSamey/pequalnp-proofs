import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class032 : runPacket packets[32]! = true := by decide +kernel
theorem class033 : runPacket packets[33]! = true := by decide +kernel
theorem class034 : runPacket packets[34]! = true := by decide +kernel
theorem class035 : runPacket packets[35]! = true := by decide +kernel
end Research.Graph9822FirstBroad
