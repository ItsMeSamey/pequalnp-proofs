import OR9822H2SeedClip
import OR9822H2SeedShoreBits
import OR9822H2StripeRawAll
import OR9822H2StripeClipAll
namespace Research.Graph9822H2Check.SeedCache
open Research.Graph9822H2Eligibility (code code_eq)

theorem code_pos {x : Nat} (small : x<1024) : positive (code x)=rawPos x := by
  rw [code_eq small]
  apply Nat.eq_of_testBit_eq
  intro i
  by_cases low : i<13
  · have mask : (8191:Nat).testBit i=true := by
      change (2^13-1 : Nat).testBit i=true
      rw [Nat.testBit_two_pow_sub_one];simp [low]
    simp only [positive,demand,Nat.testBit_and,Nat.testBit_or,Nat.testBit_shiftLeft,
      show ¬i≥13 by omega,decide_false,Bool.false_and,Bool.or_false,mask,Bool.and_true]
  · have high : 13 ≤ i := Nat.le_of_not_gt low
    have off : (8191:Nat).testBit i=false := by
      change (2^13-1 : Nat).testBit i=false
      rw [Nat.testBit_two_pow_sub_one]
      simp [low]
    simp [positive,off,Graph9822H1Check.low13_raw x i high]

theorem stripe_member (t x : Nat) (small : t<8192) (ok : stripe t=true) (used : entry t≠0)
    (mem : x∈fastCovers t) : ∃ f∈row t,sub f (rawNeg x)=true := by
  obtain ⟨sz,cover⟩ := shore_bits small mem
  have chk := allRaw ⟨x,sz⟩
  change ((decide (rawIndex x<189) && sub (positive (code x)) (poss (rawIndex x))) &&
    (negative (code x)==negs (rawIndex x)))=true at chk
  have fields : (rawIndex x<189 ∧ sub (rawPos x) (poss (rawIndex x))=true) ∧ rawNeg x=negs (rawIndex x) := by
    simpa only [Bool.and_eq_true,decide_eq_true_eq,beq_iff_eq,code_pos sz,code_neg sz] using chk
  obtain ⟨⟨idx,hp⟩,hn⟩ := fields
  have laws (z : Fin 64) := Bool.and_eq_true_iff.mp (List.all_eq_true.mp (allClip z) _ (List.mem_range.mpr idx))
  have pos := (clip_bits pClip (poss (rawIndex x)) (rawIndex x) t
    (fun z => beq_iff_eq.mp (laws z).1)).2 (fun k => nib_sub (sub_trans cover hp) k.val)
  have inc : sub (clip pClip t) (paint (row t))=true := by simpa [stripe,used] using ok
  obtain ⟨f,ff,gr⟩ := (paint_bit _).1 ((subset_bits ..).1 inc _ pos)
  have bound : f<65536 := by
    obtain ⟨i,hi,rfl⟩ := List.mem_map.mp ff
    exact lt_of_le_of_lt Nat.and_le_right (by decide : 65535<65536)
  refine ⟨f,ff,?_⟩
  rw [hn]
  exact sub_from_nibs bound ((clip_bits nClip (negs (rawIndex x)) (rawIndex x) f
    (fun z => beq_iff_eq.mp (laws z).2)).1 gr)
end Research.Graph9822H2Check.SeedCache
