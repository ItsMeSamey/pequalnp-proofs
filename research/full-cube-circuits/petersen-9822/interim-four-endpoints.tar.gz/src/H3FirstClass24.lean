import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class096 : runPacket packets[96]! = true := by decide +kernel
theorem class097 : runPacket packets[97]! = true := by decide +kernel
theorem class098 : runPacket packets[98]! = true := by decide +kernel
theorem class099 : runPacket packets[99]! = true := by decide +kernel
end Research.Graph9822FirstBroad
