import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class088 : runPacket packets[88]! = true := by decide +kernel
theorem class089 : runPacket packets[89]! = true := by decide +kernel
theorem class090 : runPacket packets[90]! = true := by decide +kernel
theorem class091 : runPacket packets[91]! = true := by decide +kernel
end Research.Graph9822FirstBroad
