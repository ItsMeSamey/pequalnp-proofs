import H3LeafGroup409822
import H3LeafGroup419822
import H3LeafGroup429822
import H3LeafGroup439822
import H3LeafGroup449822
import H3LeafGroup459822
import H3LeafGroup469822
import H3LeafGroup479822
namespace Research.Graph9822H3Leaf
def bag5 : List (Nat × Nat) := gs40 ++ gs41 ++ gs42 ++ gs43 ++ gs44 ++ gs45 ++ gs46 ++ gs47
theorem bagOK5 : bag5.all (fun (h,s) => leafCheck h s)=true := by simp [bag5,pass40,pass41,pass42,pass43,pass44,pass45,pass46,pass47]
end Research.Graph9822H3Leaf
