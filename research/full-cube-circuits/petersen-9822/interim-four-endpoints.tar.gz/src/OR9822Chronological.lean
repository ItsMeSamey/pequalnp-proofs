import And9822FreeORDefs
namespace Research.Graph9822.FreeOR

def ValidInputs (k : Nat) (p : Product) :=
  (∀ i ∈ p.1, i < k) ∧ (∀ i ∈ p.2, i < k)

def OrderedAt : Nat → List Product → Prop
  | _,[] => True
  | k,p::ps => ValidInputs k p ∧ OrderedAt (k+1) ps

theorem chronological_iff (k : Nat) (ps : List Product) (out : Arm) :
    Chronological k ps out ↔ OrderedAt k ps ∧ ∀ i ∈ out, i < k+ps.length := by
  induction ps generalizing k with
  | nil => simp [Chronological,OrderedAt]
  | cons p ps ih =>
    simp only [Chronological,OrderedAt,ValidInputs,ih,List.length_cons]
    have eq : k+1+ps.length = k+(ps.length+1) := by omega
    rw [eq]
    tauto

theorem ordered_append (k : Nat) (pre post : List Product) :
    OrderedAt k (pre++post) ↔ OrderedAt k pre ∧ OrderedAt (k+pre.length) post := by
  induction pre generalizing k with
  | nil => simp [OrderedAt]
  | cons p ps ih =>
    simp only [List.cons_append,OrderedAt,List.length_cons,ih]
    have eq : k+1+ps.length = k+(ps.length+1) := by omega
    rw [eq]
    tauto

end Research.Graph9822.FreeOR
