import H2PairNode9822
import H2CoveredPair859822
import H2LocalSurvive09822
import H2LocalSurvive19822
import H2LocalSurvive29822
import H2LocalSurvive39822
import H2LocalSurvive49822
import H2LocalSurvive59822
import H2CoveredPair85At19822
import H2CoveredPair85At29822
import H2CoveredPair85At39822
import H2CoveredPair85At49822
import H2CoveredPair85At59822
namespace Research.Graph9822H2Local
open Research.Graph9822H2Check
theorem actualRoot85 {q : Nat}
    (bad : ∀ t, !keep t = true → ¬holds q t)
    (resolve : ∃ i ∈ [0,1,3,9], ∃ j ∈ [0,1,3,9], i < j ∧ ∃ r ∈ rescue 33847320 i j, holds q r) :
    ¬holds q 535693216 := by
  intro live
  obtain ⟨i,hi,j,hj,lt,r,hr,held⟩ := resolve
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hi hj
  rcases hi with rfl | rfl | rfl | rfl <;> rcases hj with rfl | rfl | rfl | rfl <;> try omega
  · exact deniedPair pair85covered rejectPair0 bad live r hr held
  · exact deniedPair pair85at1 rejectPair1 bad live r hr held
  · exact deniedPair pair85at2 rejectPair2 bad live r hr held
  · exact deniedPair pair85at3 rejectPair3 bad live r hr held
  · exact deniedPair pair85at4 rejectPair4 bad live r hr held
  · exact deniedPair pair85at5 rejectPair5 bad live r hr held
end Research.Graph9822H2Local
