import PEqualNP.Defs
namespace Research.H3TailGroups

def edgeRows : List Nat := [6,24,17,33,66,132,264,528,160,640,576,320,288]
def signature (h q i row : Nat) : Nat :=
  row ||| (((h >>> i) &&& 1) <<< 10) ||| (((q >>> i) &&& 1) <<< 11)

def check (h q : Nat) (mis groups positives bans : List Nat) : Bool := Id.run do
  let pos := edgeRows.zipIdx.map (fun (v,i) => signature h q i v)
  let ns := mis.zipIdx.map (fun (v,i) => signature h q (13+i) v)
  if pos != positives || ns.length != 16 || groups.length != 7 then return false
  let ix := List.range 16
  let same := fun i j => groups.any (fun g => g.testBit i && g.testBit j)
  let compat := fun (i j : Nat) =>
    let both := ns[i]! ||| ns[j]!
    pos.all (fun p => (p &&& both) != p)
  let ban := fun (g : Nat) => ix.foldl (fun acc i =>
    if g.testBit i then acc ||| ns[i]! else acc) 0
  return groups.all (fun g => 0 < g && g < 65536) &&
    ix.all (fun i => (groups.filter (fun g => g.testBit i)).length == 1) &&
    ix.all (fun i => ix.all (fun j => same i j == compat i j)) &&
    groups.map ban == bans
end Research.H3TailGroups
