import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class076 : runPacket packets[76]! = true := by decide +kernel
theorem class077 : runPacket packets[77]! = true := by decide +kernel
theorem class078 : runPacket packets[78]! = true := by decide +kernel
theorem class079 : runPacket packets[79]! = true := by decide +kernel
end Research.Graph9822FirstBroad
