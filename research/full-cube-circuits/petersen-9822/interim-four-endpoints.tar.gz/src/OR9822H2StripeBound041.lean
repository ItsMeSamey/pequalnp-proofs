import OR9822H2SeedStripe
namespace Research.Graph9822H2Check.SeedCache
set_option maxHeartbeats 4000000 in
set_option maxRecDepth 12000 in
theorem boundStripe041 : ∀ i : Fin 32, stripe (1824+i.val)=true := by decide +kernel
end Research.Graph9822H2Check.SeedCache
