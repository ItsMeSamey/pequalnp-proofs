import OR9822H1CoverageBits
import OR9822H2PhysicalRows
namespace Research.Graph9822H2Check
open Research.Graph9822.FeatureRun Research.Graph9822.FreeOR Research.Graph9822TwoHidden Research.Graph9822OneHidden
def sourceId2 : Source (Fin 10) → Nat
  | .raw v => v.val
  | .first => 10
  | .second => 11
def pBit2 (h : Nat) (e : Fin 13) := (positive h).testBit e.val=true
def nBit2 (h : Nat) (n : Fin 16) := (negative h).testBit n.val=true
def sArms2 (a : Arms Nat) : Arms (Source (Fin 10)) :=
  ⟨fun l => a.left (sourceId2 l),fun r => a.right (sourceId2 r)⟩
theorem sPos2 (h q : Nat) (e : Fin 13) (s : Source (Fin 10)) :
    numericPos h q e.val (sourceId2 s) ↔ sourceRow (hasPos1 e) (pBit2 h e) (pBit2 q e) s := by
  cases s with
  | raw v =>
    have a : v.val≠10 := by omega
    have b : v.val≠11 := by omega
    simp [numericPos,labels,vs,sourceId2,sourceRow,pBit2,hasPos1,v.isLt,a,b]
  | first => simp [numericPos,labels,vs,sourceId2,sourceRow,pBit2]
  | second => simp [numericPos,labels,vs,sourceId2,sourceRow,pBit2]
theorem sNeg2 (h q : Nat) (n : Fin 16) (s : Source (Fin 10)) :
    numericNeg h q (sourceId2 s) n=true ↔
      sourceRow (fun v => negRaw n v=true) (nBit2 h n) (nBit2 q n) s := by
  cases s with
  | raw v =>
    have a : v.val≠10 := by omega
    have b : v.val≠11 := by omega
    simp [numericNeg,fixedNeg,sourceId2,sourceRow,a,b,singleton_raw_neg,negRaw]
  | first => simp [numericNeg,fixedNeg,sourceId2,sourceRow,nBit2]
  | second => simp [numericNeg,fixedNeg,sourceId2,sourceRow,nBit2]
theorem source_ex2 {u : Nat} (b : u<12) : ∃ s,sourceId2 s=u := by
  by_cases raw : u<10
  · exact ⟨.raw ⟨u,raw⟩,rfl⟩
  · rcases (by omega : u=10 ∨ u=11) with rfl|rfl
    · exact ⟨.first,rfl⟩
    · exact ⟨.second,rfl⟩
theorem liftRows2 {h q : Nat} (term : Fin 3 → Product) (bound : ∀ k,Below 12 (term k))
    (cov : ∀ e : Fin 13,∃ k,(productArms (term k)).accepts (fun u e => numericPos h q e.val u) e)
    (safe : ∀ k n,¬(productArms (term k)).accepts (fun u n => numericNeg h q u n=true) n) :
    (∀ e : Fin 13,∃ k,(sArms2 (productArms (term k))).accepts
      (fun u e => sourceRow (hasPos1 e) (pBit2 h e) (pBit2 q e) u) e) ∧
    (∀ k n,¬(sArms2 (productArms (term k))).accepts
      (fun u n => sourceRow (fun v => negRaw n v=true) (nBit2 h n) (nBit2 q n) u) n) := by
  constructor
  · intro e
    obtain ⟨k,⟨u,lu,pu⟩,v,rv,pv⟩ := cov e
    obtain ⟨a,ra⟩ := source_ex2 ((bound k).1 u lu)
    obtain ⟨b,rb⟩ := source_ex2 ((bound k).2 v rv)
    subst u; subst v
    exact ⟨k,⟨a,lu,(sPos2 ..).mp pu⟩,b,rv,(sPos2 ..).mp pv⟩
  · rintro k n ⟨⟨u,lu,pu⟩,v,rv,pv⟩
    exact safe k n ⟨⟨_,lu,(sNeg2 ..).mpr pu⟩,_,rv,(sNeg2 ..).mpr pv⟩
end Research.Graph9822H2Check
