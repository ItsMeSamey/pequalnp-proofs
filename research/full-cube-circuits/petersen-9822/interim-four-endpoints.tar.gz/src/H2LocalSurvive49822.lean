import H2OneNodeLocal9822
namespace Research.Graph9822H2Local
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem rejectPair4 : ([8331266, 133087746, 528925184, 534323714] : List Nat).all (fun r => !keep (535693216 ||| r)) = true := by decide +kernel
end Research.Graph9822H2Local
