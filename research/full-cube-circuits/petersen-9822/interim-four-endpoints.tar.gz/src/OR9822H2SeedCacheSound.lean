import OR9822H2SeedCacheCheck
import OR9822H2AllRaw
import OR9822H1GrantFold
import H2WitnessSeeds9822
namespace Research.Graph9822H2Check.SeedCache
open Research.Graph9822H2Eligibility (code code_eq)
open Research.Graph9822H1Check (low13_raw)
theorem code_neg {x : Nat} (lt : x<1024) : negative (code x)=rawNeg x := by
  rw [code_eq lt]
  apply Nat.eq_of_testBit_eq
  intro i
  have off := low13_raw x (i+13) (by omega)
  simp [negative,demand,Nat.testBit_shiftLeft,off,Nat.add_comm]

theorem row_member (t x : Nat) (ok : certified t=true) (live : entry t≠0)
    (actual : x∈fastCovers t) : ∃ f∈row t,sub f (rawNeg x)=true := by
  have pass : (choices t).all (fun x => decide (x<1024) &&
      (row t).any (fun f => sub f (negative (code x))))=true := by
    simpa [certified,live] using ok
  have choice : x∈choices t := admitted_choice actual
  obtain ⟨bound,mem⟩ := Bool.and_eq_true_iff.mp (List.all_eq_true.mp pass x choice)
  simpa only [code_neg (of_decide_eq_true bound),List.any_eq_true] using mem

theorem extend_neg {f g : Nat} (subfg : sub f g=true) (t extra : Nat) :
    sub (demand t (f ||| extra)) (demand t (g ||| extra))=true := by
  apply (subset_bits ..).2
  intro i on
  simp only [demand,Nat.testBit_or,Nat.testBit_shiftLeft,Bool.or_eq_true,Bool.and_eq_true] at on ⊢
  rcases on with l|⟨k,a|b⟩
  · exact Or.inl l
  · exact Or.inr ⟨k,Or.inl ((subset_bits ..).1 subfg _ a)⟩
  · exact Or.inr ⟨k,Or.inr b⟩

def cachedCenters := centers.map rawPos
def allSeeds (h : Nat) (P : Nat → Bool) : Bool :=
  let base := positive h &&& rawPos (freeRaw (negative h))
  cachedCenters.all fun cp =>
    let t := 8191 ^^^ (cp ||| base)
    [false,true].all fun use =>
      let req := if use then t &&& (8191 ^^^ positive h) else t
      (decide (req<8192) && (entry req != 0)) && (row req).all (fun f =>
        P (demand t (f ||| (if use then negative h else 0))))

theorem held_below (h q s : Nat) (P : Nat → Bool) (checks : allSeeds h P=true)
    (cache : ∀ t : Fin 8192, certified t.val=true) (hs : s∈seedPool h) (live : holds q s) :
    ∃ weak, P weak=true ∧ holds q weak := by
  obtain ⟨c,hc,rest⟩ := List.mem_flatMap.mp hs
  obtain ⟨use,hu,more⟩ := List.mem_flatMap.mp rest
  obtain ⟨x,hx,hout⟩ := List.mem_flatMap.mp more
  let t := 8191 ^^^ (rawPos c ||| (positive h &&& rawPos (freeRaw (negative h))))
  let k := if use then t &&& (8191 ^^^ positive h) else t
  change s∈[demand t (rawNeg x ||| (if use then negative h else 0))] at hout
  have sx := List.mem_singleton.mp hout
  have atCenter : [false,true].all (fun use =>
      let req := if use then t &&& (8191 ^^^ positive h) else t
      (decide (req<8192) && (entry req != 0)) && (row req).all (fun f =>
        P (demand t (f ||| (if use then negative h else 0)))))=true := List.all_eq_true.mp checks (rawPos c) (List.mem_map.mpr ⟨c,hc,rfl⟩)
  have atMode := List.all_eq_true.mp atCenter use hu
  have passed : (decide (k<8192) && (entry k != 0))=true ∧ (row k).all
      (fun f => P (demand t (f ||| (if use then negative h else 0))))=true := Bool.and_eq_true_iff.mp atMode
  obtain ⟨lt,nonempty⟩ := Bool.and_eq_true_iff.mp passed.1
  have non : entry k≠0 := bne_iff_ne.mp nonempty
  obtain ⟨f,mem,small⟩ := row_member k x (cache ⟨k,of_decide_eq_true lt⟩) non hx
  subst s
  exact ⟨_,List.all_eq_true.mp passed.2 _ mem,weaker_holds (extend_neg small t _) live⟩
end Research.Graph9822H2Check.SeedCache
