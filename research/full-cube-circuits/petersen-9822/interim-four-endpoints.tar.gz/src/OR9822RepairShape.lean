import OR9822RepairRows
import OR9822Chronological
namespace Research.Graph9822.FreeOR

private theorem order_omit (ps : List Product) (k j : Nat) (ord : OrderedAt j ps) :
    OrderedAt j (ps.map (omitProduct k)) := by
  induction ps generalizing j with
  | nil => trivial
  | cons p ps ih =>
    exact ⟨⟨fun i hi => ord.1.1 i (List.mem_filter.mp hi).1,
      fun i hi => ord.1.2 i (List.mem_filter.mp hi).1⟩,ih _ ord.2⟩

theorem promoted_shape (pre post : List Product) (p r : Product) (out : Arm)
    (k : Nat) (slot : k = 10+pre.length)
    (ord : Chronological 10 (pre++p::post) out)
    (sep : ∀ s ∈ pre++p::post, ∀ i ∈ s.1, i ∉ s.2)
    (valid : ValidInputs k r) (privateR : ∀ i ∈ r.1, i ∉ r.2) :
    Chronological 10 (promoted pre post k r) (k :: omitSource k out) ∧
    ∀ s ∈ promoted pre post k r, ∀ i ∈ s.1, i ∉ s.2 := by
  obtain ⟨ordered,bound⟩ := (chronological_iff ..).mp ord
  obtain ⟨left,right⟩ := (ordered_append ..).mp ordered
  refine ⟨(chronological_iff ..).mpr ⟨(ordered_append ..).mpr ⟨left,?_⟩,?_⟩,?_⟩
  · rw [← slot] at right ⊢
    exact ⟨valid,order_omit _ _ _ right.2⟩
  · intro i hi
    have lens : (promoted pre post k r).length = (pre++p::post).length := by simp [promoted]
    rw [lens]
    rcases List.mem_cons.mp hi with eq | prior
    · simp [eq,slot]
    · exact bound i (List.mem_filter.mp prior).1
  · intro s hs i hi
    rcases List.mem_append.mp hs with earlier | tail
    · exact sep _ (List.mem_append_left _ earlier) _ hi
    rcases List.mem_cons.mp tail with eq | later
    · subst s; exact privateR _ hi
    obtain ⟨src,mem,rfl⟩ := List.mem_map.mp later
    intro rhs
    exact sep src (List.mem_append_right _ (List.mem_cons_of_mem _ mem)) i
      (List.mem_filter.mp hi).1 (List.mem_filter.mp rhs).1

end Research.Graph9822.FreeOR
