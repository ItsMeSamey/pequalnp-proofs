import H3ImpFields9822
namespace Research.Graph9822Implication
open Research.Graph9822H2Check
open Research.Graph9822.FourSaturation (witnesses)

def nibble (f lane : Nat) := (f >>> (4*lane)) % 16

def lanePair (j n : Nat) := match j with
  | 0 => pairLut0[n]!
  | 1 => pairLut1[n]!
  | 2 => pairLut2[n]!
  | _ => pairLut3[n]!

def laneUnit (j n : Nat) := match j with
  | 0 => unitLut0[n]!
  | 1 => unitLut1[n]!
  | 2 => unitLut2[n]!
  | _ => unitLut3[n]!

def laneGood (j : Nat) : Bool := (List.range 16).all fun x =>
  decide (lanePair j x < 2^32) &&
  (sourcePairs.zipIdx.all fun ((v,w),i) => !(lanePair j x).testBit i ||
    (List.range 4).any fun r => x.testBit r &&
       witnesses[4*j+r]!.testBit v && witnesses[4*j+r]!.testBit w) &&
  (vs.all fun v => !(laneUnit j x).testBit v ||
    (List.range 4).any fun r => x.testBit r && witnesses[4*j+r]!.testBit v)

def laneValues (table : Nat → Nat → Nat) (f : Nat) := (List.range 4).map (fun j => table j (nibble f j))

private theorem bitWitness (xs : List Nat) (i : Nat)
    (hot : (xs.foldr (· ||| ·) 0).testBit i = true) : ∃ x ∈ xs, x.testBit i = true := by
  induction xs with
  | nil => simp at hot
  | cons x xs ih =>
    rcases Bool.or_eq_true_iff.mp (by simpa only [List.foldr_cons,Nat.testBit_or] using hot) with h | h
    · exact ⟨x,by simp,h⟩
    · obtain ⟨y,mem,yes⟩ := ih h
      exact ⟨y,by simp [mem],yes⟩

private theorem pairFold (f : Nat) : pairFields f = (laneValues lanePair f).foldr (· ||| ·) 0 := by
  simp [pairFields,laneValues,lanePair,nibble,List.range_succ,Nat.or_assoc]
private theorem unitFold (f : Nat) : unitFields f = (laneValues laneUnit f).foldr (· ||| ·) 0 := by
  simp [unitFields,laneValues,laneUnit,nibble,List.range_succ,Nat.or_assoc]

private theorem originalBit {f j r : Nat} (lt : r < 4)
    (on : (nibble f j).testBit r = true) : f.testBit (4*j+r) = true := by
  change ((f >>> (4*j)) % 2^4).testBit r = true at on
  rw [Nat.testBit_mod_two_pow (f >>> (4*j)) 4 r,Nat.testBit_shiftRight] at on
  simpa only [lt,decide_true,Bool.true_and] using on

theorem pairActive {f i v w : Nat} (all : ∀ j ∈ List.range 4, laneGood j = true)
    (row : ((v,w),i) ∈ sourcePairs.zipIdx) (hot : (pairFields f).testBit i = true) :
    ∃ n : Fin 16, f.testBit n = true ∧ witnesses[n.val]!.testBit v = true ∧
      witnesses[n.val]!.testBit w = true := by
  rw [pairFold] at hot
  obtain ⟨x,mem,hx⟩ := bitWitness _ _ hot
  obtain ⟨j,jm,rfl⟩ := List.mem_map.mp mem
  have jl := List.mem_range.mp jm
  have good := List.all_eq_true.mp (all j jm) (nibble f j)
    (List.mem_range.mpr (Nat.mod_lt _ (by decide : 0 < 16)))
  have edges := (Bool.and_eq_true_iff.mp (Bool.and_eq_true_iff.mp good).1).2
  have one := List.all_eq_true.mp edges ((v,w),i) row
  have hits : (List.range 4).any (fun r => (nibble f j).testBit r &&
      witnesses[4*j+r]!.testBit v && witnesses[4*j+r]!.testBit w) = true := by
    simpa [hx] using one
  obtain ⟨r,rm,hr⟩ := List.any_eq_true.mp hits
  have rl := List.mem_range.mp rm
  obtain ⟨both,br⟩ := Bool.and_eq_true_iff.mp hr
  obtain ⟨nr,vr⟩ := Bool.and_eq_true_iff.mp both
  exact ⟨⟨4*j+r,by omega⟩,originalBit rl nr,vr,br⟩

theorem unitActive {f v : Nat} (all : ∀ j ∈ List.range 4, laneGood j = true)
    (row : v ∈ vs) (hot : (unitFields f).testBit v = true) :
    ∃ n : Fin 16, f.testBit n = true ∧ witnesses[n.val]!.testBit v = true := by
  rw [unitFold] at hot
  obtain ⟨x,mem,hx⟩ := bitWitness _ _ hot
  obtain ⟨j,jm,rfl⟩ := List.mem_map.mp mem
  have jl := List.mem_range.mp jm
  have good := List.all_eq_true.mp (all j jm) (nibble f j)
    (List.mem_range.mpr (Nat.mod_lt _ (by decide : 0 < 16)))
  have one := List.all_eq_true.mp (Bool.and_eq_true_iff.mp good).2 v row
  have hits : (List.range 4).any (fun r => (nibble f j).testBit r &&
      witnesses[4*j+r]!.testBit v) = true := by
    simpa [hx] using one
  obtain ⟨r,rm,hr⟩ := List.any_eq_true.mp hits
  have rl := List.mem_range.mp rm
  obtain ⟨nr,vr⟩ := Bool.and_eq_true_iff.mp hr
  exact ⟨⟨4*j+r,by omega⟩,originalBit rl nr,vr⟩

private theorem foldBound (xs : List Nat) (small : ∀ x ∈ xs, x < 2^32) :
    xs.foldr (· ||| ·) 0 < 2^32 := by
  induction xs with
  | nil => decide
  | cons x xs ih =>
    exact Nat.or_lt_two_pow (small x (by simp)) (ih (fun y hy => small y (by simp [hy])))

theorem pairBound (f : Nat) (all : ∀ j ∈ List.range 4, laneGood j = true) :
    pairFields f < 2^32 := by
  rw [pairFold]
  have small : ∀ x ∈ laneValues lanePair f, x < 2^32 := by
    intro x mem
    obtain ⟨j,jm,rfl⟩ := List.mem_map.mp mem
    have g := List.all_eq_true.mp (all j jm) (nibble f j)
      (List.mem_range.mpr (Nat.mod_lt _ (by decide : 0 < 16)))
    exact of_decide_eq_true (Bool.and_eq_true_iff.mp (Bool.and_eq_true_iff.mp g).1).1
  exact foldBound _ small

end Research.Graph9822Implication
