import OR9822H2RawMask
import OR9822FiveMinimum
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution
open Research.Graph9822H2Check (meets_iff_exists)
open Research.Graph9822OneHidden (meets)

def armMask (a : Arm) := (BitVec.ofBoolListLE (List.ofFn (fun i : Fin 10 => a.contains i.val))).toNat

theorem armMask_lt (a : Arm) : armMask a < 1024 := by
  simpa [armMask] using (BitVec.ofBoolListLE (List.ofFn (fun i : Fin 10 => a.contains i.val))).isLt

theorem armMask_bit {a : Arm} {v : Nat} (lt : v<10) : (armMask a).testBit v = a.contains v := by
  change (BitVec.ofBoolListLE (List.ofFn (fun i : Fin 10 => a.contains i.val))).getLsbD v = _
  rw [BitVec.getLsbD_ofBoolListLE,List.getD_eq_getElem?_getD,List.getElem?_ofFn]
  simp [lt]

theorem armMask_bit_iff (a : Arm) (v : Nat) : (armMask a).testBit v = true ↔ v<10 ∧ v∈a := by
  by_cases lt : v<10
  · simp [armMask_bit lt,lt]
  · have cold : (armMask a).testBit v = false := Nat.testBit_lt_two_pow
      (lt_of_lt_of_le (armMask_lt a) (show (1024:Nat) ≤ 2^v from
        Nat.pow_le_pow_right (by decide : 0<2) (by omega : 10≤v)))
    simp [cold,lt]

theorem read_arm_mask (a : Arm) (m : Nat) : readArm (fullWire m) a = meets (armMask a) m := by
  apply Bool.eq_iff_iff.mpr
  simp only [readArm,List.any_eq_true,meets_iff_exists,armMask_bit_iff,fullWire,
    Bool.and_eq_true,decide_eq_true_eq]
  constructor
  · rintro ⟨v,mem,lt,hot⟩
    exact ⟨v,⟨lt,mem⟩,hot⟩
  · rintro ⟨v,⟨lt,mem⟩,hot⟩
    exact ⟨v,mem,lt,hot⟩

theorem disjoint_arm_masks (a b : Arm) (sep : ∀ v ∈ a, v ∉ b) :
    armMask a &&& armMask b = 0 := by
  apply Nat.eq_of_testBit_eq
  intro v
  by_cases hit : (armMask a).testBit v = true
  · have forbid := sep v ((armMask_bit_iff a v).1 hit).2
    have cold := Bool.eq_false_iff.mpr (fun h => forbid ((armMask_bit_iff b v).1 h).2)
    simp [hit,cold]
  · simp [Bool.eq_false_iff.mpr hit]

end Research.Graph9822.FreeOR
