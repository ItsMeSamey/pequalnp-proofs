import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class024 : runPacket packets[24]! = true := by decide +kernel
theorem class025 : runPacket packets[25]! = true := by decide +kernel
theorem class026 : runPacket packets[26]! = true := by decide +kernel
theorem class027 : runPacket packets[27]! = true := by decide +kernel
end Research.Graph9822FirstBroad
