import H3ImpClauseInventory9822
namespace Research.Graph9822Implication
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem arcs0 : (List.range' 0 10).all validArcsAt = true := by decide +kernel
end Research.Graph9822Implication
