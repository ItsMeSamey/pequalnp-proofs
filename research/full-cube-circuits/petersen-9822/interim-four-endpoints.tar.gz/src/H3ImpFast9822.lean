import H3ImplicationTable9822
import H3ImplicationPath9822
namespace Research.Graph9822Implication
open Research.Graph9822H2Check Research.Graph9822H3Implication
def allowed (sig l r : Nat) : Bool := (clauseBit l r).any (fun c => sub c sig)
def good (r : Nat × List Nat) := closedConflict (allowed r.1) r.2
def pairLut0 : Array Nat := #[0,8389376,1122318,9511694,135897088,144286464,135897102,144286478,159498240,159499008,160555022,160555790,161079296,161080064,161079310,161080078]
def unitLut0 : Array Nat := #[0,50,77,127,108,126,109,127,116,118,125,127,124,126,125,127]
def pairLut1 : Array Nat := #[0,2098325,540016668,540017821,587202560,589300885,590348316,590349469,67256320,69354645,607272988,607274141,654458880,656557205,657604636,657605789]
def unitLut1 : Array Nat := #[0,139,201,203,208,219,217,219,276,415,477,479,468,479,477,479]
def pairLut2 : Array Nat := #[0,1073744945,1174408448,1174408497,4198597,1077943541,1178607045,1178607093,4464710,1078209655,1178873158,1178873207,4468935,1078213879,1178877383,1178877431]
def unitLut2 : Array Nat := #[0,387,402,403,523,907,923,923,525,911,927,927,527,911,927,927]
def pairLut3 : Array Nat := #[0,273158784,273457152,273461888,2147489889,2420644577,2420947041,2420947681,2147876962,2421035746,2421071970,2421076706,2147883107,2421037795,2421078115,2421078755]
def unitLut3 : Array Nat := #[0,554,556,558,771,811,815,815,773,815,813,815,775,815,815,815]
def pairFields (f : Nat) := pairLut0[(f >>> 0) % 16]! ||| pairLut1[(f >>> 4) % 16]! ||| pairLut2[(f >>> 8) % 16]! ||| pairLut3[(f >>> 12) % 16]!
def unitFields (f : Nat) := unitLut0[(f >>> 0) % 16]! ||| unitLut1[(f >>> 4) % 16]! ||| unitLut2[(f >>> 8) % 16]! ||| unitLut3[(f >>> 12) % 16]!
def fastSig (h s : Nat) (useH : Bool) : Nat :=
  let f := negative s
  let t := positive s
  let a := if useH then t &&& (8191 ^^^ positive h) else t
  let u := if useH then unitFields (f &&& negative h) else 0
  t ||| (a <<< 13) ||| (pairFields f <<< 26) ||| (u <<< 58)
end Research.Graph9822Implication
