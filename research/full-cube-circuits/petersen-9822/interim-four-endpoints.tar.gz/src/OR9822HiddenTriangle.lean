import Mathlib.Data.Finset.Basic
import OR9822Combinatorics

namespace Research.Graph9822OneHidden
def hits {α : Type} (A S : Finset α) : Prop := ∃ x ∈ S, x ∈ A

/-- Three negative sets meeting W require two clauses A,B to color a triangle. -/
theorem triangle_excludes {α : Type} [DecidableEq α] (T : Fin 3 → Finset α)
    (A B W : Finset α) (missing : Finset α → Prop)
    (w : ∀ i, hits W (T i)) (safe : ∀ i, ¬ (hits A (T i) ∧ hits B (T i) ∧ hits W (T i)))
    (need : ∀ e, missing e → hits A e ∧ hits B e)
    (conflict : ∀ i j, i ≠ j → ∃ e, missing e ∧ e ⊆ T i ∪ T j) : False := by
  classical
  have apart (X : Finset α) (hX : ∀ e, missing e → hits X e)
      (i j : Fin 3) (ne : i ≠ j) (a : ¬ hits X (T i)) (b : ¬ hits X (T j)) : False := by
    obtain ⟨e,he,sub⟩ := conflict i j ne
    obtain ⟨v,hv,wv⟩ := hX e he
    rcases Finset.mem_union.mp (sub hv) with h | h
    · exact a ⟨v,h,wv⟩
    · exact b ⟨v,h,wv⟩
  have ac := apart A (fun e h => (need e h).1)
  have bc := apart B (fun e h => (need e h).2)
  have color (i : Fin 3) : ¬ hits A (T i) ∨ ¬ hits B (T i) := by
    by_cases a : hits A (T i)
    · exact Or.inr (fun b => safe i ⟨a,b,w i⟩)
    · exact Or.inl a
  rcases color 0 with a | b
  · rcases color 1 with c | d
    · exact ac 0 1 (by decide) a c
    · rcases color 2 with e | f
      · exact ac 0 2 (by decide) a e
      · exact bc 1 2 (by decide) d f
  · rcases color 1 with c | d
    · rcases color 2 with e | f
      · exact ac 1 2 (by decide) c e
      · exact bc 0 2 (by decide) b f
    · exact bc 0 1 (by decide) b d

def edges : List Nat := [6,24,17,33,66,132,264,528,160,640,576,320,288]

def edgeMask (test : Nat → Bool) : List Nat → Nat
  | [] => 0
  | e :: es => (test e).toNat + 2 * edgeMask test es

def meets (x y : Nat) : Bool := x &&& y != 0
def contains (x y : Nat) : Bool := x &&& y == y
def accepts (x : Nat) := edgeMask (meets x) edges
def inside (x : Nat) := edgeMask (contains x) edges

structure Tri where
  need : Nat
  x : Nat
  y : Nat
  z : Nat
deriving DecidableEq, Repr
def tris : List Tri := [⟨14,50,77,554⟩,⟨70,50,139,387⟩,⟨296,208,77,554⟩,⟨545,208,523,77⟩,⟨644,50,139,523⟩,⟨646,50,139,523⟩,⟨776,50,139,523⟩,⟨808,50,139,523⟩,⟨1041,208,139,525⟩,⟨1154,50,77,525⟩,⟨1158,276,523,77⟩,⟨1552,208,139,523⟩,⟨1568,208,523,77⟩,⟨1666,50,139,525⟩,⟨1668,50,139,523⟩,⟨1680,50,208,523⟩,⟨1696,276,208,523⟩,⟨1824,208,523,77⟩,⟨2128,208,139,387⟩,⟨3136,276,523,77⟩,⟨3152,276,139,77⟩,⟨3600,208,139,523⟩,⟨4168,523,387,554⟩,⟨4392,276,208,554⟩,⟨4424,276,139,554⟩,⟨4872,50,208,523⟩,⟨6216,50,139,387⟩,⟨6224,50,208,387⟩,⟨7232,276,208,523⟩]

def Tri.valid (t : Tri) : Bool :=
  inside t.x == 0 && inside t.y == 0 && inside t.z == 0 &&
  meets t.need (inside (t.x ||| t.y)) && meets t.need (inside (t.x ||| t.z)) &&
  meets t.need (inside (t.y ||| t.z))

theorem triples_sound : tris.all Tri.valid = true := by decide +kernel

def Tri.sees (t : Tri) (w : Nat) := meets t.x w && meets t.y w && meets t.z w

def rejects (need w : Nat) : Bool :=
  !contains (accepts w) need || tris.any (fun t => t.need == need && t.sees w)

structure Star where
  center : Nat
  arm : Nat
  covers : Nat
deriving DecidableEq, Repr

def choices (s : Star) : List Nat := [0,s.center,s.arm]

def checkArms (double : Nat) (a b c d : Star) : Bool :=
  let need := 8191 ^^^ (a.covers ||| b.covers ||| c.covers ||| d.covers)
  !contains double need ||
    (choices a).all (fun x => (choices b).all (fun y =>
      (choices c).all (fun z => (choices d).all (fun t => rejects need (x ||| y ||| z ||| t)))))

def starArms : Nat → List Star
  | 0 => [⟨1,16,4⟩,⟨1,32,8⟩,⟨1,48,12⟩]
  | 1 => [⟨2,4,1⟩,⟨2,64,16⟩,⟨2,68,17⟩]
  | 2 => [⟨4,2,1⟩,⟨4,128,32⟩,⟨4,130,33⟩]
  | 3 => [⟨8,16,2⟩,⟨8,256,64⟩,⟨8,272,66⟩]
  | 4 => [⟨16,1,4⟩,⟨16,8,2⟩,⟨16,9,6⟩,⟨16,512,128⟩,⟨16,513,132⟩,⟨16,520,130⟩,⟨16,521,134⟩]
  | 5 => [⟨32,1,8⟩,⟨32,128,256⟩,⟨32,129,264⟩,⟨32,256,4096⟩,⟨32,257,4104⟩,⟨32,384,4352⟩,⟨32,385,4360⟩]
  | 6 => [⟨64,2,16⟩,⟨64,256,2048⟩,⟨64,258,2064⟩,⟨64,512,1024⟩,⟨64,514,1040⟩,⟨64,768,3072⟩,⟨64,770,3088⟩]
  | 7 => [⟨128,4,32⟩,⟨128,32,256⟩,⟨128,36,288⟩,⟨128,512,512⟩,⟨128,516,544⟩,⟨128,544,768⟩,⟨128,548,800⟩]
  | 8 => [⟨256,8,64⟩,⟨256,32,4096⟩,⟨256,40,4160⟩,⟨256,64,2048⟩,⟨256,72,2112⟩,⟨256,96,6144⟩,⟨256,104,6208⟩]
  | 9 => [⟨512,16,128⟩,⟨512,64,1024⟩,⟨512,80,1152⟩,⟨512,128,512⟩,⟨512,144,640⟩,⟨512,192,1536⟩,⟨512,208,1664⟩]

  | _ => []

def checkCenters (a b c d double : Nat) : Bool :=
  (starArms a).all (fun p => (starArms b).all (fun q =>
    (starArms c).all (fun r => (starArms d).all (fun s => checkArms double p q r s))))

end Research.Graph9822OneHidden
#print axioms Research.Graph9822OneHidden.triangle_excludes
#print axioms Research.Graph9822OneHidden.triples_sound
