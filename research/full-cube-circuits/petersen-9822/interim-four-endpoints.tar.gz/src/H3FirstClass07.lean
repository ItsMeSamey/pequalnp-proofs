import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class028 : runPacket packets[28]! = true := by decide +kernel
theorem class029 : runPacket packets[29]! = true := by decide +kernel
theorem class030 : runPacket packets[30]! = true := by decide +kernel
theorem class031 : runPacket packets[31]! = true := by decide +kernel
end Research.Graph9822FirstBroad
