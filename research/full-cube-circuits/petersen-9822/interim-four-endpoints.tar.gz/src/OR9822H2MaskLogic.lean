import OR9822H2Antichain
namespace Research.Graph9822H2Check

theorem subset_bits (x y : Nat) : sub x y = true ↔
    ∀ k, x.testBit k = true → y.testBit k = true := by
  constructor
  · intro h k atX
    have eq : x &&& y = x := by simpa [sub] using h
    have seen := congrArg (fun a : Nat => a.testBit k) eq
    simpa [atX] using seen
  · intro incl
    apply beq_iff_eq.mpr
    apply Nat.eq_of_testBit_eq
    intro k
    by_cases yes : x.testBit k = true
    · simp [yes,incl k yes]
    · simp [Bool.eq_false_iff.mpr yes]

theorem empty_overlap (x y : Nat) : Research.Graph9822OneHidden.meets x y = false ↔
    ∀ k, x.testBit k = true → y.testBit k = false := by
  constructor
  · intro h k hx
    have eq : x &&& y = 0 := by simpa [Research.Graph9822OneHidden.meets] using h
    have seen := congrArg (fun a : Nat => a.testBit k) eq
    simpa [hx] using seen
  · intro avoid
    have eq : x &&& y = 0 := by
      apply Nat.eq_of_testBit_eq
      intro k
      by_cases yes : x.testBit k = true
      · simp [yes,avoid k yes]
      · simp [Bool.eq_false_iff.mpr yes]
    simp [Research.Graph9822OneHidden.meets,eq]

theorem join_subset {s r u : Nat} (a : sub s u = true) (b : sub r u = true) :
    sub (s ||| r) u = true := by
  apply (subset_bits ..).2
  intro k h
  rw [Nat.testBit_or,Bool.or_eq_true] at h
  exact h.elim ((subset_bits ..).1 a k) ((subset_bits ..).1 b k)

end Research.Graph9822H2Check
