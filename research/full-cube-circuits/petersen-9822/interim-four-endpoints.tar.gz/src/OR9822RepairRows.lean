import OR9822RetireHidden
import OR9822FiveFromRows
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FourSaturation
open Research.Graph9822.FeatureRun (WireLE read_mono run_mono)

theorem run_append (pre post : List Product) (k : Nat) (w : Wire) :
    run (pre++post) k w = run post (k+pre.length) (run pre k w) := by
  induction pre generalizing k w with
  | nil => simp [run]
  | cons p ps ih =>
    simp only [List.cons_append,List.length_cons,run,ih]
    rw [show k + 1 + ps.length = k + (ps.length+1) by omega]

def promoted (pre post : List Product) (k : Nat) (r : Product) :=
  pre ++ r :: post.map (omitProduct k)

theorem promoted_row (pre post : List Product) (p r : Product) (out : Arm) (m : Nat)
    (k : Nat) (slot : k = 10+pre.length)
    (base : Bool) (original : resultOn (pre++p::post) out m = base)
    (whenHot : productBit (run pre 10 (fullWire m)) p = true → base = true →
      productBit (run pre 10 (fullWire m)) r = true)
    (safe : productBit (run pre 10 (fullWire m)) r = true → base = true) :
    resultOn (promoted pre post k r) (k :: omitSource k out) m = base := by
  let w := run pre 10 (fullWire m)
  let suffix (v : Bool) := readArm (run post (k+1) (Function.update w k v)) out
  have mono : suffix false = true → suffix true = true := by
    apply read_mono (run_mono _ post (k+1))
    intro j h
    by_cases e : j=k <;> simp_all [Function.update_of_ne]
  have before : suffix (productBit w p) = base := by
    simpa [resultOn,run_append,run,suffix,w,slot] using original
  have after : resultOn (promoted pre post k r) (k :: omitSource k out) m =
      (productBit w r || suffix false) := by
    simp only [resultOn,promoted,run_append,← slot,run]
    rw [retirement_output]
    simp [suffix,w,Function.update_idem]
  rw [after]
  cases hp : productBit w p <;> cases hr : productBit w r <;> cases base <;>
    simp_all [w]

end Research.Graph9822.FreeOR
