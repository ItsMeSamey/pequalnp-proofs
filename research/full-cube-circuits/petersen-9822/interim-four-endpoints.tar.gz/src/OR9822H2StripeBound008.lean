import OR9822H2SeedStripe
namespace Research.Graph9822H2Check.SeedCache
set_option maxHeartbeats 4000000 in
set_option maxRecDepth 12000 in
theorem boundStripe008 : ∀ i : Fin 16, stripe (272+i.val)=true := by decide +kernel
end Research.Graph9822H2Check.SeedCache
