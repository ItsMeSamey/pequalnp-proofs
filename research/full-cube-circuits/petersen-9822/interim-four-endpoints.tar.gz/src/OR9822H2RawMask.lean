import OR9822H2MaskLogic
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden (edgeMask meets edges)

theorem test_edgeMask (f : Nat → Bool) (xs : List Nat) (i : Nat) :
    (edgeMask f xs).testBit i = (xs[i]?.map f).getD false := by
  induction xs generalizing i with
  | nil => simp [edgeMask]
  | cons x xs ih =>
    cases i with
    | zero =>
      cases bit : f x <;> simp [edgeMask,bit,Nat.testBit_zero]
    | succ i =>
      rw [Nat.testBit_succ]
      have half : edgeMask f (x::xs) / 2 = edgeMask f xs := by
        cases bit : f x <;> simp [edgeMask,bit] <;> omega
      rw [half,ih]
      rfl

theorem raw_pos_bit (a : Nat) (i : Fin 13) : (rawPos a).testBit i.val = meets a edges[i.val]! := by
  have hi : i.val < edges.length := i.isLt
  simp [rawPos,Research.Graph9822OneHidden.accepts,test_edgeMask,List.getElem?_eq_getElem hi,
    getElem!_pos edges i.val hi]

theorem raw_neg_bit (a : Nat) (n : Fin 16) : (rawNeg a).testBit n.val =
    meets a Research.Graph9822.FourSaturation.witnesses[n.val]! := by
  have hn : n.val < Research.Graph9822.FourSaturation.witnesses.length := n.isLt
  simp [rawNeg,test_edgeMask,List.getElem?_eq_getElem hn,getElem!_pos Research.Graph9822.FourSaturation.witnesses n.val hn]

theorem meets_iff_exists {x y : Nat} : meets x y = true ↔
    ∃ k, x.testBit k = true ∧ y.testBit k = true := by
  classical
  constructor
  · intro hot
    by_contra no
    have apart : meets x y = false := (empty_overlap ..).2 (fun k hk => Bool.eq_false_iff.mpr
      (fun hy => no ⟨k,hk,hy⟩))
    simp [apart] at hot
  · rintro ⟨k,hk,hy⟩
    by_contra no
    have apart := (empty_overlap ..).1 (Bool.eq_false_iff.mpr no) k hk
    simp [hy] at apart

end Research.Graph9822H2Check
