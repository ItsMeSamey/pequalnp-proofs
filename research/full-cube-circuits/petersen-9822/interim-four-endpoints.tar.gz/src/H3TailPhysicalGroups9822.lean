import H3TailBijection9822
namespace Research.H3Tail

theorem physicalGroups {P N A F : Type} [Finite A]
    (pos : P → F → Prop) (neg : N → F → Prop)
    (reads : A → F → Prop) (group slot : N → A)
    (allGroups : Function.Surjective group)
    (positive : ∀ a p, ∃ f, reads a f ∧ pos p f)
    (negative : ∀ n f, reads (slot n) f → ¬neg n f)
    (compat : ∀ i j, (∀ p, ∃ f, pos p f ∧ ¬neg i f ∧ ¬neg j f) → group i = group j) :
    ∃ perm : A ≃ A, ∀ n, slot n = perm (group n) := by
  apply forcedAssignment group slot allGroups
  intro i j eq
  apply compat
  intro p
  obtain ⟨f,r,hp⟩ := positive (slot i) p
  exact ⟨f,hp,negative i f r,negative j f (eq ▸ r)⟩
end Research.H3Tail
