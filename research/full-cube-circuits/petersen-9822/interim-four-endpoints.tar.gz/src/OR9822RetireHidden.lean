import OR9822RetireArm
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution

theorem omit_run (k start : Nat) (less : k < start) (ps : List Product) (w : Wire) :
    Function.update (run (ps.map (omitProduct k)) start w) k false =
      run ps start (Function.update w k false) := by
  induction ps generalizing start w with
  | nil => rfl
  | cons p ps ih =>
    simp only [List.map_cons,run]
    rw [ih (start+1) (by omega)]
    apply congrArg (run ps (start+1))
    have prod : productBit w (omitProduct k p) = productBit (Function.update w k false) p := by
      simp [omitProduct,productBit,read_omit]
    rw [prod]
    funext j
    by_cases hk : j=k
    · subst j
      simp [Function.update_of_ne (Nat.ne_of_lt less)]
    · by_cases hs : j=start
      · subst j; simp [hk]
      · simp [hk,hs]

theorem stale_value (ps : List Product) {k start : Nat} (hk : k < start) (w : Wire) :
    run ps start w k = w k := by
  induction ps generalizing start w with
  | nil => rfl
  | cons p ps ih =>
    rw [run,ih (by omega),Function.update_of_ne (Nat.ne_of_lt hk)]

theorem retirement_output (ps : List Product) (k : Nat) (w : Wire) (out : Arm) :
    readArm (run (ps.map (omitProduct k)) (k+1) w) (k :: omitSource k out) =
    (w k || readArm (run ps (k+1) (Function.update w k false)) out) := by
  change (run _ (k+1) w k || readArm _ (omitSource k out)) = _
  rw [stale_value _ (by omega),read_omit,omit_run k (k+1) (by omega)]

end Research.Graph9822.FreeOR
