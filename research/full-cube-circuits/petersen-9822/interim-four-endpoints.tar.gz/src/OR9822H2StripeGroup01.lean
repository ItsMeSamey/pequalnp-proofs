import OR9822H2StripeBound012
import OR9822H2StripeBound013
import OR9822H2StripeBound014
import OR9822H2StripeBound015
import OR9822H2StripeBound016
import OR9822H2StripeBound017
import OR9822H2StripeBound018
import OR9822H2StripeBound019
import OR9822H2StripeBound020
import OR9822H2StripeBound021
import OR9822H2StripeBound022
import OR9822H2StripeBound023
namespace Research.Graph9822H2Check.SeedCache
theorem stripeGroup01 (t : Nat) (low : 416≤t) (high : t<928) : stripe t=true := by
  by_cases l0 : t<448
  · have eq : 416+(t-416)=t := by omega
    simpa only [eq] using boundStripe012 ⟨t-416,by omega⟩
  by_cases l1 : t<512
  · have eq : 448+(t-448)=t := by omega
    simpa only [eq] using boundStripe013 ⟨t-448,by omega⟩
  by_cases l2 : t<544
  · have eq : 512+(t-512)=t := by omega
    simpa only [eq] using boundStripe014 ⟨t-512,by omega⟩
  by_cases l3 : t<576
  · have eq : 544+(t-544)=t := by omega
    simpa only [eq] using boundStripe015 ⟨t-544,by omega⟩
  by_cases l4 : t<640
  · have eq : 576+(t-576)=t := by omega
    simpa only [eq] using boundStripe016 ⟨t-576,by omega⟩
  by_cases l5 : t<672
  · have eq : 640+(t-640)=t := by omega
    simpa only [eq] using boundStripe017 ⟨t-640,by omega⟩
  by_cases l6 : t<704
  · have eq : 672+(t-672)=t := by omega
    simpa only [eq] using boundStripe018 ⟨t-672,by omega⟩
  by_cases l7 : t<768
  · have eq : 704+(t-704)=t := by omega
    simpa only [eq] using boundStripe019 ⟨t-704,by omega⟩
  by_cases l8 : t<800
  · have eq : 768+(t-768)=t := by omega
    simpa only [eq] using boundStripe020 ⟨t-768,by omega⟩
  by_cases l9 : t<832
  · have eq : 800+(t-800)=t := by omega
    simpa only [eq] using boundStripe021 ⟨t-800,by omega⟩
  by_cases l10 : t<896
  · have eq : 832+(t-832)=t := by omega
    simpa only [eq] using boundStripe022 ⟨t-832,by omega⟩
  by_cases l11 : t<928
  · have eq : 896+(t-896)=t := by omega
    simpa only [eq] using boundStripe023 ⟨t-896,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
