import OR9822H2SeedStripeFields
import OR9822H2MaskLogic
namespace Research.Graph9822H2Check.SeedCache

theorem nib_bit (x k i : Nat) : (nib x k).testBit i = (decide (i<4) && x.testBit (4*k+i)) := by
  change ((x >>> (4*k)) % 2^4).testBit i=_
  rw [Nat.testBit_mod_two_pow,Nat.testBit_shiftRight]

theorem nib_sub {a b : Nat} (ab : sub a b=true) (k : Nat) : sub (nib a k) (nib b k)=true := by
  apply (subset_bits ..).2
  intro i hot
  simp only [nib_bit,Bool.and_eq_true] at hot ⊢
  exact ⟨hot.1,(subset_bits ..).1 ab _ hot.2⟩

theorem sub_from_nibs {a b : Nat} (small : a<65536)
    (ok : ∀ k : Fin 4,sub (nib a k.val) (nib b k.val)=true) : sub a b=true := by
  apply (subset_bits ..).2
  intro i hot
  have hi : i<16 := by
    by_contra! far
    have off : a.testBit i=false := Nat.testBit_lt_two_pow (lt_of_lt_of_le small
      (show 65536 ≤ 2^i from Nat.pow_le_pow_right (by decide : 0<(2:Nat)) far))
    exact Bool.noConfusion (hot.symm.trans off)
  let k : Fin 4 := ⟨i/4,by omega⟩
  have li : i%4<4 := Nat.mod_lt _ (by decide)
  have idx : 4*k.val+i%4=i := by dsimp [k];omega
  have left : (nib a k.val).testBit (i%4)=true := by simp [nib_bit,li,idx,hot]
  have right := (subset_bits ..).1 (ok k) _ left
  simpa [nib_bit,li,idx] using right

end Research.Graph9822H2Check.SeedCache
