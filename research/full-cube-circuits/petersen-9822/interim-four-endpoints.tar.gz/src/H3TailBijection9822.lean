import PEqualNP.Defs
namespace Research.H3Tail

theorem forcedAssignment {N A : Type} [Finite A]
    (group slot : N → A) (onto : Function.Surjective group)
    (consistent : ∀ x y, slot x = slot y → group x = group y) :
    ∃ perm : A ≃ A, ∀ n, slot n = perm (group n) := by
  classical
  choose rep ok using onto
  let f := fun a => slot (rep a)
  have inj : Function.Injective f := by
    intro a b h
    simpa only [ok] using consistent (rep a) (rep b) h
  have surj := Finite.injective_iff_surjective.mp inj
  refine ⟨Equiv.ofBijective f ⟨inj,surj⟩,?_⟩
  intro n
  obtain ⟨a,ha⟩ := surj (slot n)
  have eq : a = group n := by
    simpa only [ok] using consistent (rep a) n ha
  subst a
  exact ha.symm
end Research.H3Tail
