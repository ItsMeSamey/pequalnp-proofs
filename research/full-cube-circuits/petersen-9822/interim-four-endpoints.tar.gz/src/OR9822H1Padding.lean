import OR9822H1Geometry
import Mathlib.Data.Finset.Sort
import Mathlib.Data.Fintype.Card
namespace Research.Graph9822OneHidden

theorem pad_centers1 (s : Finset V1) (small : s.card≤4) :
    ∃ t : Finset V1, s⊆t ∧ t.card=4 := by
  classical
  have co : 6≤sᶜ.card := by rw [Finset.card_compl]; simp [V1] at *; omega
  obtain ⟨excludedVerts,inside,sz⟩ := Finset.exists_subset_card_eq co
  refine ⟨excludedVertsᶜ,?_,?_⟩
  · intro v h
    exact Finset.mem_compl.mpr (fun ho => (Finset.mem_compl.mp (inside ho)) h)
  · rw [Finset.card_compl,sz];decide

theorem fill_centers1 (v : Fin 4 → V1) :
    ∃ t : Finset V1, t.card=4 ∧ ∀ k,v k∈t := by
  classical
  let s := Finset.univ.image v
  have small : s.card≤4 := (Finset.card_image_le).trans (by simp)
  obtain ⟨t,st,size⟩ := pad_centers1 s small
  exact ⟨t,size,fun k => st (Finset.mem_image.mpr ⟨k,Finset.mem_univ _,rfl⟩)⟩

/-- If every padded slot is indispensable, all physical slots were occupied
and each center has a different physical terminal. -/
theorem full_centers1 (t : Finset V1) (card : t.card=4)
    (physical : Fin 4 → Option V1) (need : ∀ v∈t,∃ k,physical k=some v) :
    ∃ assign : (v : V1) → v∈t → Fin 4,
      (∀ v (h : v∈t),physical (assign v h)=some v) ∧
      ∀ k,∃ v,∃ h : v∈t,assign v h=k := by
  classical
  choose f hit using need
  let g (v : ↥t) := f v.val v.property
  have inj : Function.Injective g := by
    intro v w same
    apply Subtype.ext
    apply Option.some.inj
    exact (hit v.val v.property).symm.trans ((congrArg physical same).trans (hit w.val w.property))
  have all : Finset.univ.image g = Finset.univ := by
    apply Finset.eq_of_subset_of_card_le (Finset.subset_univ _)
    rw [Finset.card_image_of_injective _ inj]
    simp [card]
  refine ⟨f,hit,fun k => ?_⟩
  have hk : k∈Finset.univ.image g := by rw [all];simp
  obtain ⟨v,_,eq⟩ := Finset.mem_image.mp hk
  exact ⟨v.val,v.property,eq⟩
end Research.Graph9822OneHidden
