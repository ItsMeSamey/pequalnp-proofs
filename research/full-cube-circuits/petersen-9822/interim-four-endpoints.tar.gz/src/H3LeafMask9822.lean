import OR9822H2AllRaw
import OR9822H1GrantFold
import H3DemandNumeric9822
namespace Research.Graph9822H3Leaf
open Research.Graph9822H2Check Research.Graph9822H2Eligibility
def ep (x : Nat) := if x<1024 then code x &&& 8191 else rawPos x
def nn (x : Nat) := if x<1024 then code x >>> 13 else rawNeg x

private theorem low (x : Nat) : rawPos x < 8192 := Graph9822H1Check.mask_lt1 _ _

theorem ep_eq (x : Nat) : ep x=rawPos x := by
  unfold ep
  split
  next lt =>
    rw [code_eq lt]
    apply Nat.eq_of_testBit_eq
    intro i
    by_cases b : i<13
    · have mask : (8191:Nat).testBit i=true := by
        change (2^13-1:Nat).testBit i=true;rw [Nat.testBit_two_pow_sub_one];simp [b]
      simp [demand,Nat.testBit_shiftLeft,show ¬i≥13 by omega,mask]
    · have step : 13 ≤ i := Nat.le_of_not_gt b
      have z (a : Nat) (sz : a<8192) : a.testBit i=false := Nat.testBit_lt_two_pow
        (lt_of_lt_of_le sz (show 8192≤2^i from Nat.pow_le_pow_right (by decide : 0<2) step))
      simp [z 8191 (by decide),z _ (low x)]
  next => rfl

theorem nn_eq (x : Nat) : nn x=rawNeg x := by
  unfold nn
  split
  next lt =>
    rw [code_eq lt]
    apply Nat.eq_of_testBit_eq
    intro i
    have off : (rawPos x).testBit (13+i)=false := Nat.testBit_lt_two_pow
      (lt_of_lt_of_le (low x) (show 8192≤2^(13+i) from Nat.pow_le_pow_right (by decide : 0<2) (by omega : 13≤13+i)))
    have off' : (rawPos x).testBit (i+13)=false := by simpa only [Nat.add_comm] using off
    simp [demand,Nat.testBit_shiftRight,Nat.testBit_shiftLeft,off,off']
  next => rfl

def fastFree (f : Nat) := vs.foldl (fun a v =>
  if Graph9822OneHidden.meets f (nn (bit v)) then a else a ||| bit v) 0
theorem free_eq (f : Nat) : fastFree f=freeRaw f := by simp [fastFree,freeRaw,nn_eq]
end Research.Graph9822H3Leaf
