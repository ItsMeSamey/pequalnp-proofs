import OR9822HiddenTriangle
import Mathlib.Data.Fintype.Card

namespace Research.Graph9822TwoHidden

/-- The two unions feeding one terminal AND. -/
structure Arms (Label : Type) where
  left : Label → Prop
  right : Label → Prop

def Arms.accepts {L R : Type} (a : Arms L) (hot : L → R → Prop) (r : R) : Prop :=
  (∃ u, a.left u ∧ hot u r) ∧ (∃ v, a.right v ∧ hot v r)

/-- A single entry in the semantic enumeration for two chosen positive rows. -/
structure PairWitness {L P N : Type} (pos : L → P → Prop) (neg : L → N → Prop)
    (i j : P) where
  leftI : L
  leftJ : L
  rightI : L
  rightJ : L
  positive : pos leftI i ∧ pos leftJ j ∧ pos rightI i ∧ pos rightJ j
  safe : ∀ l r n, (l = leftI ∨ l = leftJ) → (r = rightI ∨ r = rightJ) →
    ¬ (neg l n ∧ neg r n)

/-- Among four positive rows, one pair has the four labels checked by a rescue hint. -/
theorem four_rows_rescue {L P N : Type} (arms : Fin 3 → Arms L)
    (pos : L → P → Prop) (neg : L → N → Prop) (rows : Fin 4 → P)
    (cover : ∀ k, ∃ a, (arms a).accepts pos (rows k))
    (safe : ∀ a n, ¬ (arms a).accepts neg n) :
    ∃ i j : Fin 4, i < j ∧ Nonempty (PairWitness pos neg (rows i) (rows j)) := by
  classical
  choose owner accepts using cover
  have collision : ¬ Function.Injective owner := by
    intro inj
    have h := Fintype.card_le_of_injective owner inj
    simp at h
  unfold Function.Injective at collision
  push_neg at collision
  obtain ⟨x,y,same,ne⟩ := collision
  have ordered : ∃ i j : Fin 4, i < j ∧ owner i = owner j := by
    rcases lt_or_gt_of_ne ne with lt | gt
    · exact ⟨x,y,lt,same⟩
    · exact ⟨y,x,gt,same.symm⟩
  obtain ⟨i,j,ij,eq⟩ := ordered
  obtain ⟨⟨a,ha,pa⟩,⟨c,hc,pc⟩⟩ := accepts i
  have hj := accepts j
  rw [← eq] at hj
  obtain ⟨⟨b,hb,pb⟩,⟨d,hd,pd⟩⟩ := hj
  refine ⟨i,j,ij,⟨⟨a,b,c,d,⟨pa,pb,pc,pd⟩,?_⟩⟩⟩
  intro l r n hl hr both
  apply safe (owner i) n
  exact ⟨⟨l,hl.elim (fun e => e.symm ▸ ha) (fun e => e.symm ▸ hb),both.1⟩,
    ⟨r,hr.elim (fun e => e.symm ▸ hc) (fun e => e.symm ▸ hd),both.2⟩⟩

end Research.Graph9822TwoHidden
