import OR9822H2StripeBound096
import OR9822H2StripeBound097
import OR9822H2StripeBound098
import OR9822H2StripeBound099
import OR9822H2StripeBound100
import OR9822H2StripeBound101
import OR9822H2StripeBound102
import OR9822H2SeedStripePilot
namespace Research.Graph9822H2Check.SeedCache
theorem stripeGroup08 (t : Nat) (low : 6656≤t) (high : t<8192) : stripe t=true := by
  by_cases l0 : t<6912
  · have eq : 6656+(t-6656)=t := by omega
    simpa only [eq] using boundStripe096 ⟨t-6656,by omega⟩
  by_cases l1 : t<7168
  · have eq : 6912+(t-6912)=t := by omega
    simpa only [eq] using boundStripe097 ⟨t-6912,by omega⟩
  by_cases l2 : t<7232
  · have eq : 7168+(t-7168)=t := by omega
    simpa only [eq] using boundStripe098 ⟨t-7168,by omega⟩
  by_cases l3 : t<7296
  · have eq : 7232+(t-7232)=t := by omega
    simpa only [eq] using boundStripe099 ⟨t-7232,by omega⟩
  by_cases l4 : t<7424
  · have eq : 7296+(t-7296)=t := by omega
    simpa only [eq] using boundStripe100 ⟨t-7296,by omega⟩
  by_cases l5 : t<7680
  · have eq : 7424+(t-7424)=t := by omega
    simpa only [eq] using boundStripe101 ⟨t-7424,by omega⟩
  by_cases l6 : t<7936
  · have eq : 7680+(t-7680)=t := by omega
    simpa only [eq] using boundStripe102 ⟨t-7680,by omega⟩
  by_cases l7 : t<8192
  · have eq : 7936+(t-7936)=t := by omega
    simpa only [eq] using stripe31 ⟨t-7936,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
