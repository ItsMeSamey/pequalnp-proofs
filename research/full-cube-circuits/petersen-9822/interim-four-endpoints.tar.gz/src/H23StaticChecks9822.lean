import H3ImpLane09822
import H3ImpLane19822
import H3ImpLane29822
import H3ImpLane39822
import H3ImpArcBlock09822
import H3ImpArcBlock19822
import H3ImpArcBlock29822
import H3ImpArcBlock39822
namespace Research.Graph9822Implication

theorem checkedLanes : ∀ j ∈ List.range 4, laneGood j = true := by
  intro j mem
  have lt := List.mem_range.mp mem
  have vals : j = 0 ∨ j = 1 ∨ j = 2 ∨ j = 3 := by omega
  rcases vals with rfl | rfl | rfl | rfl
  · exact lane0Good
  · exact lane1Good
  · exact lane2Good
  · exact lane3Good

theorem checkedArcs : ∀ r ∈ List.range 40, validArcsAt r = true := by
  have partition : List.range 40 = List.range' 0 10 ++ List.range' 10 10 ++
      List.range' 20 10 ++ List.range' 30 10 := by decide
  have checked : (List.range 40).all validArcsAt = true := by
    rw [partition]
    simp only [List.all_append,arcs0,arcs1,arcs2,arcs3] <;> rfl
  exact List.all_eq_true.mp checked
end Research.Graph9822Implication
