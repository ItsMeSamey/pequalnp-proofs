import H3ImpClauseInventory9822
namespace Research.Graph9822Implication
open Research.Graph9822H3Implication

theorem primitiveOfArc (valid : ∀ l ∈ List.range 40, validArcsAt l = true)
    {l r c : Nat} (there : clauseBit l r = some c) : (c,opp l,r) ∈ primitive := by
  have bounds : l < 40 ∧ r < 40 := by
    by_contra falseBounds
    have denied : (decide (l<40) && decide (r<40)) = false := by simp_all
    simp [clauseBit,guard,denied] at there
  have row := valid l (List.mem_range.mpr bounds.1)
  have edge := List.all_eq_true.mp row r (List.mem_range.mpr bounds.2)
  simpa [there] using edge

theorem arcsSound (valid : ∀ l ∈ List.range 40, validArcsAt l = true)
    {value : Nat → Bool} {sig : Nat} (opposite : ∀ l, value (opp l) = !value l)
    (sat : SatPrim value sig) :
    ∀ l r, allowed sig l r = true → value l = true → value r = true := by
  intro l r on
  exact implicationOfClause opposite sat (fun _ h => primitiveOfArc valid h) on
end Research.Graph9822Implication
