import H3LeafGroup089822
import H3LeafGroup099822
import H3LeafGroup109822
import H3LeafGroup119822
import H3LeafGroup129822
import H3LeafGroup139822
import H3LeafGroup149822
import H3LeafGroup159822
namespace Research.Graph9822H3Leaf
def bag1 : List (Nat × Nat) := gs08 ++ gs09 ++ gs10 ++ gs11 ++ gs12 ++ gs13 ++ gs14 ++ gs15
theorem bagOK1 : bag1.all (fun (h,s) => leafCheck h s)=true := by simp [bag1,pass08,pass09,pass10,pass11,pass12,pass13,pass14,pass15]
end Research.Graph9822H3Leaf
