import OR9822ParetoMaximum
import OR9822H2MaskLogic
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FeatureRun Research.Graph9822.FourSaturation
open Research.Graph9822H2Check

private theorem edge_row : ∀ e ∈ edges, ∃ k : Fin 13,
    rawRow ⟨k.val,by omega⟩ = edgeMask e := by decide +kernel
private theorem neg_row : ∀ m ∈ witnesses, ∃ n : Fin 16,
    rawRow ⟨13+n.val,by omega⟩ = m := by decide +kernel

theorem first_on_row (p : Product) (i : Fin 29) :
    firstCol p i = productBit (fullWire (rawRow i)) p := by
  rw [actual_input]; rfl

theorem pareto_first_rows (p r : Product)
    (dom : sub (encode (firstCol r) ^^^ 8191) (encode (firstCol p) ^^^ 8191)=true) :
    (∀ e∈edges, productBit (fullWire (edgeMask e)) p=true →
      productBit (fullWire (edgeMask e)) r=true) ∧
    (∀ m∈witnesses, productBit (fullWire m) r=true →
      productBit (fullWire m) p=true) := by
  constructor
  · intro e he
    obtain ⟨k,eq⟩ := edge_row e he
    rw [←eq,←first_on_row,←first_on_row]
    intro hot
    have mask : (8191:Nat).testBit k.val=true := by
      change (2^13-1 : Nat).testBit k.val=true
      rw [Nat.testBit_two_pow_sub_one]; simp [k.isLt]
    let i : Fin 29 := ⟨k.val,by omega⟩
    by_contra cold
    have off : firstCol r i=false := Bool.eq_false_iff.mpr cold
    have bit := (subset_bits ..).1 dom k.val
    change ((encode (firstCol r) ^^^ 8191).testBit i.val=true → (encode (firstCol p) ^^^ 8191).testBit i.val=true) at bit
    simp only [Nat.testBit_xor,encode_bit,show (8191:Nat).testBit i.val=true from mask,off,show firstCol p i=true from hot] at bit
    exact Bool.noConfusion (bit rfl)
  · intro m hm
    obtain ⟨n,eq⟩ := neg_row m hm
    rw [←eq,←first_on_row,←first_on_row]
    let i : Fin 29 := ⟨13+n.val,by omega⟩
    have z : (8191:Nat).testBit i.val=false := Nat.testBit_lt_two_pow
      (lt_of_lt_of_le (by decide : 8191<2^13) (Nat.pow_le_pow_right (by decide) (by dsimp [i];omega)))
    simpa only [Nat.testBit_xor,encode_bit,z,Bool.xor_false] using (subset_bits ..).1 dom i.val
end Research.Graph9822.FreeOR
