import PEqualNP.Defs
namespace Research.H3Tail

structure Arms where
  a : Nat
  b : Nat
  c : Nat
  d : Nat
  e : Nat
  f : Nat
deriving DecidableEq

def add (x : Arms) (slot mask : Nat) : Arms :=
  match slot with
  | 0 => {x with a := x.a ||| mask, c := x.c ||| mask}
  | 1 => {x with a := x.a ||| mask, d := x.d ||| mask, e := x.e ||| mask}
  | 2 => {x with a := x.a ||| mask, d := x.d ||| mask, f := x.f ||| mask}
  | 3 => {x with b := x.b ||| mask, c := x.c ||| mask, e := x.e ||| mask}
  | 4 => {x with b := x.b ||| mask, c := x.c ||| mask, f := x.f ||| mask}
  | 5 => {x with b := x.b ||| mask, d := x.d ||| mask, e := x.e ||| mask}
  | _ => {x with b := x.b ||| mask, d := x.d ||| mask, f := x.f ||| mask}

def block (x : Arms) : Nat → Nat
  | 0 => x.a &&& x.c
  | 1 => x.a &&& x.d &&& x.e
  | 2 => x.a &&& x.d &&& x.f
  | 3 => x.b &&& x.c &&& x.e
  | 4 => x.b &&& x.c &&& x.f
  | 5 => x.b &&& x.d &&& x.e
  | _ => x.b &&& x.d &&& x.f

def visit (edges bans : Array Nat) : List Nat → List Nat → Arms → List Nat → Option (List Nat)
  | order, unused, arms, code :: rest =>
    if code < 91 then do
      let edge ← edges[code % 13]?
      if edge &&& block arms (code / 13) == edge then some rest else none
    else if code == 127 then
      match order with
      | [] => none
      | slot :: slots => unused.foldlM (fun tape g => do
          let ban ← bans[g]?
          visit edges bans slots (unused.erase g) (add arms slot ban) tape) rest
    else none
  | _, _, _, [] => none
termination_by slots _ _ _ => slots.length

def accepts (edges bans : Array Nat) (order tape : List Nat) : Bool :=
  visit edges bans order (List.range 7) ⟨0,0,0,0,0,0⟩ tape == some []

end Research.H3Tail
