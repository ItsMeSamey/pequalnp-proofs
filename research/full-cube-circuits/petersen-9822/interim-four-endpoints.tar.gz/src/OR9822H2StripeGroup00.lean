import OR9822H2StripeBound000
import OR9822H2StripeBound001
import OR9822H2StripeBound002
import OR9822H2StripeBound003
import OR9822H2StripeBound004
import OR9822H2StripeBound005
import OR9822H2StripeBound006
import OR9822H2StripeBound007
import OR9822H2StripeBound008
import OR9822H2StripeBound009
import OR9822H2StripeBound010
import OR9822H2StripeBound011
namespace Research.Graph9822H2Check.SeedCache
theorem stripeGroup00 (t : Nat) (low : 0≤t) (high : t<416) : stripe t=true := by
  by_cases l0 : t<32
  · have eq : 0+(t-0)=t := by omega
    simpa only [eq] using boundStripe000 ⟨t-0,by omega⟩
  by_cases l1 : t<64
  · have eq : 32+(t-32)=t := by omega
    simpa only [eq] using boundStripe001 ⟨t-32,by omega⟩
  by_cases l2 : t<96
  · have eq : 64+(t-64)=t := by omega
    simpa only [eq] using boundStripe002 ⟨t-64,by omega⟩
  by_cases l3 : t<128
  · have eq : 96+(t-96)=t := by omega
    simpa only [eq] using boundStripe003 ⟨t-96,by omega⟩
  by_cases l4 : t<160
  · have eq : 128+(t-128)=t := by omega
    simpa only [eq] using boundStripe004 ⟨t-128,by omega⟩
  by_cases l5 : t<192
  · have eq : 160+(t-160)=t := by omega
    simpa only [eq] using boundStripe005 ⟨t-160,by omega⟩
  by_cases l6 : t<256
  · have eq : 192+(t-192)=t := by omega
    simpa only [eq] using boundStripe006 ⟨t-192,by omega⟩
  by_cases l7 : t<272
  · have eq : 256+(t-256)=t := by omega
    simpa only [eq] using boundStripe007 ⟨t-256,by omega⟩
  by_cases l8 : t<288
  · have eq : 272+(t-272)=t := by omega
    simpa only [eq] using boundStripe008 ⟨t-272,by omega⟩
  by_cases l9 : t<320
  · have eq : 288+(t-288)=t := by omega
    simpa only [eq] using boundStripe009 ⟨t-288,by omega⟩
  by_cases l10 : t<384
  · have eq : 320+(t-320)=t := by omega
    simpa only [eq] using boundStripe010 ⟨t-320,by omega⟩
  by_cases l11 : t<416
  · have eq : 384+(t-384)=t := by omega
    simpa only [eq] using boundStripe011 ⟨t-384,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
