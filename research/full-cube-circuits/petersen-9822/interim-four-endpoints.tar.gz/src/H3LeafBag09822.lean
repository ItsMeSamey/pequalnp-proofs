import H3LeafGroup009822
import H3LeafGroup019822
import H3LeafGroup029822
import H3LeafGroup039822
import H3LeafGroup049822
import H3LeafGroup059822
import H3LeafGroup069822
import H3LeafGroup079822
namespace Research.Graph9822H3Leaf
def bag0 : List (Nat × Nat) := gs00 ++ gs01 ++ gs02 ++ gs03 ++ gs04 ++ gs05 ++ gs06 ++ gs07
theorem bagOK0 : bag0.all (fun (h,s) => leafCheck h s)=true := by simp [bag0,pass00,pass01,pass02,pass03,pass04,pass05,pass06,pass07]
end Research.Graph9822H3Leaf
