import OR9822H1Seeds
import OR9822H2RawMask
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check
open Research.Graph9822OneHidden (edges edgeMask)
theorem mask_lt1 (test : Nat → Bool) (xs : List Nat) : edgeMask test xs < 2^xs.length := by
  induction xs with
  | nil => change 0<1;decide
  | cons x xs ih => simp only [edgeMask,List.length_cons,Nat.pow_succ]; cases test x <;> simp <;> omega
def low13 (m : Nat) := ∀ i,13 ≤ i → m.testBit i=false
theorem low13_raw (a : Nat) : low13 (rawPos a) := by
  intro i hi
  exact Nat.testBit_lt_two_pow (lt_of_lt_of_le (mask_lt1 _ _)
    (show 8192≤2^i from Nat.pow_le_pow_right (by decide : 0 < (2 : Nat)) hi))
theorem low13_or {a b : Nat} (ha : low13 a) (hb : low13 b) : low13 (a ||| b) := by
  intro i hi; simp [ha i hi,hb i hi]
theorem low13_andr (a : Nat) {b : Nat} (hb : low13 b) : low13 (a &&& b) := by
  intro i hi; simp [hb i hi]
theorem low13_full {a : Nat} (h : low13 a) (cover : ∀ i : Fin 13,a.testBit i.val=true) :
    a=8191 := by
  apply Nat.eq_of_testBit_eq
  intro i
  change a.testBit i = (2^13-1:Nat).testBit i
  rw [Nat.testBit_two_pow_sub_one]
  by_cases lt : i<13
  · simpa [lt] using cover ⟨i,lt⟩
  · simp [lt,h i (by omega)]

theorem grants_low (h v m : Nat) (mem : m∈termGrants h v) : low13 m := by
  simp only [termGrants,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with first|second
  · exact first.symm ▸ low13_raw (bit v)
  · exact second.symm ▸ low13_andr (rawPos (bit v) ||| positive h) (low13_raw (neighbor v &&& freeRaw (negative h)))

def assembled1 (h : Nat) (c : List Nat) :=
  c.foldl (fun xs v => xs.flatMap (fun x => (termGrants h v).map (fun y => x ||| y))) [0]

theorem assembled_member1 (h : Nat) (c : List Nat) (choice : Nat → Nat)
    (ok : ∀ v∈c,choice v∈termGrants h v) :
    c.foldl (fun x v => x ||| choice v) 0 ∈ assembled1 h c := by
  have go (vs : List Nat) (bank : List Nat) (a : Nat) (ha : a∈bank)
      (members : ∀ v∈vs,choice v∈termGrants h v) :
      vs.foldl (fun x v => x ||| choice v) a ∈
      vs.foldl (fun xs v => xs.flatMap (fun x => (termGrants h v).map (fun y => x ||| y))) bank := by
    induction vs generalizing bank a with
    | nil => exact ha
    | cons v vs ih =>
      apply ih
      · exact List.mem_flatMap.mpr ⟨a,ha,List.mem_map.mpr ⟨choice v,members v List.mem_cons_self,rfl⟩⟩
      · exact fun w hw => members w (List.mem_cons_of_mem _ hw)
  exact go c [0] 0 (by simp) ok

theorem assembled_bit1 (vs : List Nat) (a : Nat) (choice : Nat→Nat) (i : Nat) :
    (vs.foldl (fun x v => x ||| choice v) a).testBit i=true ↔
      a.testBit i=true ∨ ∃ v∈vs,(choice v).testBit i=true := by
  induction vs generalizing a with
  | nil => simp
  | cons v vs ih => simp [ih,List.mem_cons,or_assoc]

theorem forbids_firm1 {c : List Nat} {h : Nat} (reject : rejects c h=true)
    (choice : Nat → Nat) (ok : ∀ v∈c,choice v∈termGrants h v)
    (cover : ∀ i : Fin 13,∃ v∈c,(choice v).testBit i.val=true) : False := by
  let m := c.foldl (fun x v => x ||| choice v) 0
  have low : low13 m := by
    intro i hi
    apply Bool.eq_false_iff.mpr
    intro on
    rcases (assembled_bit1 c 0 choice i).mp on with bad|⟨v,hv,hot⟩
    · simpa using bad
    · rw [grants_low h v _ (ok v hv) i hi] at hot; contradiction
  have eq := low13_full low (fun i => (assembled_bit1 c 0 choice i.val).mpr (Or.inr (cover i)))
  have missing := List.all_eq_true.mp (Bool.and_eq_true_iff.mp reject).2 m (assembled_member1 h c choice ok)
  simp [eq] at missing

end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.forbids_firm1
