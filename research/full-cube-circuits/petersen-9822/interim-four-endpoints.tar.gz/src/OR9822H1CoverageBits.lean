import OR9822H1PhysicalGrants
import OR9822H1GrantFold
import OR9822H2FreeRaw
namespace Research.Graph9822H1Check
open Research.Graph9822H2Check Research.Graph9822OneHidden
open Research.Graph9822.FreeOR Research.Graph9822TwoHidden

theorem singleton_edge1 (v : V1) (e : Fin 13) :
    (rawPos (bit v.val)).testBit e.val=true ↔ hasPos1 e v := by
  rw [raw_pos_bit]
  simp [hasPos1,meets_iff_exists,bit,Nat.testBit_two_pow]

def packed1 (p : Product) := demand (rawPos (armMask p.1) &&& rawPos (armMask p.2))
  (rawNeg (armMask p.1) &&& rawNeg (armMask p.2))
private theorem hpos_small (p : Product) :
    rawPos (armMask p.1) &&& rawPos (armMask p.2)<8192 :=
  lt_of_le_of_lt Nat.and_le_left (mask_lt1 _ _)
theorem packed1_pos (p : Product) (e : Fin 13) :
    (positive (packed1 p)).testBit e.val=true ↔ HPos1 p e := by
  have mask : (8191:Nat).testBit e.val=true := by
    change (2^13-1:Nat).testBit e.val=true
    rw [Nat.testBit_two_pow_sub_one];simp [e.isLt]
  simp [packed1,demand,positive,mask,Nat.testBit_shiftLeft,show ¬ e.val≥13 by omega,
    raw_pos_bit,HPos1,hidden1,productBit,read_arm_mask]
theorem packed1_neg (p : Product) (n : Fin 16) :
    (negative (packed1 p)).testBit n.val=true ↔ HNeg1 p n := by
  have off : (rawPos (armMask p.1) &&& rawPos (armMask p.2)).testBit (13+n.val)=false :=
    Nat.testBit_lt_two_pow (lt_of_lt_of_le (hpos_small p)
      (show 8192≤2^(13+n.val) from Nat.pow_le_pow_right (by decide : 0 < (2 : Nat)) (by omega : 13≤13+n.val)))
  have offL := low13_raw (armMask p.1) (n.val+13) (by omega)
  simp [packed1,demand,negative,Nat.testBit_shiftLeft,offL,raw_neg_bit,HNeg1,hidden1,productBit,read_arm_mask,
    Nat.add_comm]
theorem safe_free1 (p : Product) (v : V1) (ok : safepoint (HNeg1 p) v) :
    (freeRaw (negative (packed1 p))).testBit v.val=true := by
  apply (freeRaw_member _ _).mpr
  refine ⟨v.isLt,(empty_overlap ..).2 ?_⟩
  intro i h
  by_cases small : i<16
  · let n : Fin 16 := ⟨i,small⟩
    have safe := ok n ((packed1_neg p n).mp h)
    have eq := singleton_raw_neg v n
    exact Bool.eq_false_iff.mpr (fun hot => safe (eq.symm.trans hot))
  · exact Nat.testBit_lt_two_pow (lt_of_lt_of_le (show rawNeg (bit v.val)<65536 from mask_lt1 _ _)
      (show 65536≤2^i from Nat.pow_le_pow_right (by decide : 0 < (2 : Nat)) (by omega : 16 ≤ i)))

theorem raw_hit1 {m : Nat} {v : V1} {e : Fin 13} (inm : m.testBit v.val=true) (on : hasPos1 e v) :
    (rawPos m).testBit e.val=true := by rw [raw_pos_bit];exact meets_iff_exists.mpr ⟨v.val,inm,on⟩

theorem term_firm1 (p q : Product) (v : V1)
    (grant : Grant1 (rawArms1 q) (HNeg1 p) hasPos1 (HPos1 p) (some v)) :
    ∃ mask∈termGrants (packed1 p) v.val,∀ e,
      (rawArms1 q).accepts (fun l e => oneRow (hasPos1 e) (HPos1 p e) l) e →
      mask.testBit e.val=true := by
  rcases grant.firm v rfl with weak|strong
  · exact ⟨_,List.mem_cons_self,fun e hit => (singleton_edge1 v e).mpr (weak e hit)⟩
  · refine ⟨_,List.mem_cons_of_mem _ List.mem_cons_self,?_⟩
    intro e hit
    obtain ⟨wh,u,pu,adj,su⟩ := strong e hit
    have a : (rawPos (bit v.val)).testBit e.val=true ∨ (positive (packed1 p)).testBit e.val=true :=
      wh.imp (singleton_edge1 v e).mpr (packed1_pos p e).mpr
    have b := raw_hit1 (m:=neighbor v.val &&& freeRaw (negative (packed1 p)))
      (v:=u) (by simp [adj,safe_free1 p u su]) pu
    simpa using And.intro a b
end Research.Graph9822H1Check
#print axioms Research.Graph9822H1Check.term_firm1
