import OR9822PrefixMask
import OR9822H1GrantFold
namespace Research.Graph9822.FeatureRun
open Research.Graph9822Resolution Research.Graph9822.FreeOR Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)
def rawCode (a : Nat) := demand (rawPos a) (rawNeg a)

theorem rawCodeBit (a : Nat) (i : Fin 29) :
    (rawCode a).testBit i.val = meets a (rawRow i) := by
  by_cases pos : i.val<13
  · have ne : ¬i.val≥13 := by omega
    simp only [rawCode,demand,Nat.testBit_or,Nat.testBit_shiftLeft,ne,decide_false,
      Bool.false_and,Bool.or_false,rawRow,pos,ite_true]
    exact raw_pos_bit a ⟨i.val,pos⟩
  · let n : Fin 16 := ⟨i.val-13,by have := i.isLt;omega⟩
    have hi : i.val≥13 := by omega
    have no := Graph9822H1Check.low13_raw a i.val hi
    simp only [rawCode,demand,Nat.testBit_or,Nat.testBit_shiftLeft,hi,decide_true,Bool.true_and,no,
      Bool.false_or,rawRow,pos,ite_false]
    exact raw_neg_bit a n

theorem rawCode_high (a k : Nat) (hi : 29≤k) : (rawCode a).testBit k=false := by
  have low := Graph9822H1Check.low13_raw a k (by omega)
  have negB : rawNeg a<65536 := Graph9822H1Check.mask_lt1 _ _
  have cold : (rawNeg a).testBit (k-13)=false := Nat.testBit_lt_two_pow
    (lt_of_lt_of_le negB (show 65536≤2^(k-13) from Nat.pow_le_pow_right (by decide : 0<(2:Nat)) (by omega : 16≤k-13)))
  simp only [rawCode,demand,Nat.testBit_or,Nat.testBit_shiftLeft,low,cold,Bool.and_false,Bool.or_self]

theorem first_code (p : Product) :
    encode (firstCol p)=rawCode (armMask p.1) &&& rawCode (armMask p.2) := by
  apply Nat.eq_of_testBit_eq
  intro k
  by_cases b : k<29
  · let i : Fin 29 := ⟨k,b⟩
    change (encode (firstCol p)).testBit i.val=Nat.testBit (rawCode (armMask p.1) &&& rawCode (armMask p.2)) i.val
    rw [encode_bit,Nat.testBit_and,rawCodeBit,rawCodeBit,first_row]
  · have hi : 29≤k := by omega
    have off : (encode (firstCol p)).testBit k=false := Nat.testBit_lt_two_pow
      (lt_of_lt_of_le (encode_bound _) (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) hi))
    simp only [off,Nat.testBit_and,rawCode_high _ _ hi,Bool.false_and]
end Research.Graph9822.FeatureRun
