import H3TailCallback49822
import And9822H3ExceptionData
import H3TailCase49822
namespace Research.H3TailGroups.Case4
open Research.Graph9822.FreeOR Research.Graph9822.H3Directions Research.Graph9822.FeatureRun Research.Graph9822Resolution
theorem rowE (p : Fin 13) : edges[p.val]? = some (posMask 786481 26106184 p) := by
  have all : (List.finRange 13).all (fun p => edges[p.val]? == some (posMask 786481 26106184 p)) = true := by decide +kernel
  exact beq_iff_eq.mp (List.all_eq_true.mp all p (List.mem_finRange p))
theorem rowN (n : Fin 16) : negs[n.val]?.getD 0 = negMask 786481 26106184 n := by
  have all : (List.finRange 16).all (fun n => negs[n.val]?.getD 0 == negMask 786481 26106184 n) = true := by decide +kernel
  exact beq_iff_eq.mp (List.all_eq_true.mp all n (List.mem_finRange n))
def order : List (Fin 7) := [0, 1, 3, 5, 2, 4, 6]
theorem impossible (c : FiveProgram) (H Q R A B : Product)
    (hh : (hiddenFirst c).1=[H,Q,R]) (ht : (hiddenFirst c).2=[A,B])
    (he : encode (firstCol H)=786481) (qe : encode (secondCol H Q)=26106184) : False := by
  refine no_exception_data c H Q R A B hh ht 786481 26106184 he qe (groupAt groups) onto ?_ edges bans order _ Research.H3Tail.acceptTail4 ?_ ?_ rowE ?_
  · intro i j different
    obtain ⟨p,eq⟩ := classPage_witness groups edges negs apart i j (List.all_eq_true.mp classes i (List.mem_finRange i)) different
    exact ⟨p,by simpa only [rowE,rowN,Option.getD_some] using eq⟩
  · decide +kernel
  · decide +kernel
  · intro g j hit
    obtain ⟨n,group,lit⟩ := banPage_sound groups bans negs covers g j.val (List.all_eq_true.mp prohibited g (List.mem_finRange g)) j.isLt hit
    exact ⟨n,group,by simpa only [rowN] using lit⟩
end Research.H3TailGroups.Case4
