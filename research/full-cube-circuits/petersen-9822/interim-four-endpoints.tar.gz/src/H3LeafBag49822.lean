import H3LeafGroup329822
import H3LeafGroup339822
import H3LeafGroup349822
import H3LeafGroup359822
import H3LeafGroup369822
import H3LeafGroup379822
import H3LeafGroup389822
import H3LeafGroup399822
namespace Research.Graph9822H3Leaf
def bag4 : List (Nat × Nat) := gs32 ++ gs33 ++ gs34 ++ gs35 ++ gs36 ++ gs37 ++ gs38 ++ gs39
theorem bagOK4 : bag4.all (fun (h,s) => leafCheck h s)=true := by simp [bag4,pass32,pass33,pass34,pass35,pass36,pass37,pass38,pass39]
end Research.Graph9822H3Leaf
