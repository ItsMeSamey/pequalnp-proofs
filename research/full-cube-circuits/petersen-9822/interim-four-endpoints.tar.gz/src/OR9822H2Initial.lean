import OR9822H2Rescue

namespace Research.Graph9822TwoHidden

inductive Source (V : Type)
  | raw : V → Source V
  | first : Source V
  | second : Source V

def sourceRow {V : Type} (r : V → Prop) (h q : Prop) : Source V → Prop
  | .raw v => r v
  | .first => h
  | .second => q

/-- Outside the centers, a terminal's accepting pair must use a hidden feature.
Pairwise negative safety then forces exactly the demands used at a root. -/
theorem uncovered_edge {V N : Type} (e : V → Prop) (negs : N → V → Prop)
    (h q : Prop) (hn qn : N → Prop) (l r : Source V)
    (left : sourceRow e h q l) (right : sourceRow e h q r)
    (safe : ∀ n, ¬(sourceRow (negs n) (hn n) (qn n) l ∧
                    sourceRow (negs n) (hn n) (qn n) r))
    (noRaw : ∀ v w, l = .raw v → r = .raw w → False)
    (noBase : ¬ (h ∧ ∃ v, e v ∧ ∀ n, hn n → ¬ negs n v))
    (hLeaks : ∃ n, hn n) (qLeaks : ∃ n, qn n) :
    q ∧ ((∃ v, e v ∧ ∀ n, qn n → ¬ negs n v) ∨
         (h ∧ ∀ n, hn n → ¬ qn n)) := by
  cases l <;> cases r <;> simp only [sourceRow] at left right safe
  case raw.raw a b => exact False.elim (noRaw a b rfl rfl)
  case raw.first a =>
    exact False.elim (noBase ⟨right,a,left,fun n nh nv => safe n ⟨nv,nh⟩⟩)
  case raw.second a => exact ⟨right,Or.inl ⟨a,left,fun n nq nv => safe n ⟨nv,nq⟩⟩⟩
  case first.raw a =>
    exact False.elim (noBase ⟨left,a,right,fun n nh nv => safe n ⟨nh,nv⟩⟩)
  case first.first =>
    obtain ⟨n,nh⟩ := hLeaks
    exact False.elim (safe n ⟨nh,nh⟩)
  case first.second => exact ⟨right,Or.inr ⟨left,fun n nh nq => safe n ⟨nh,nq⟩⟩⟩
  case second.raw a => exact ⟨left,Or.inl ⟨a,right,fun n nq nv => safe n ⟨nq,nv⟩⟩⟩
  case second.first => exact ⟨left,Or.inr ⟨right,fun n nh nq => safe n ⟨nq,nh⟩⟩⟩
  case second.second =>
    obtain ⟨n,nq⟩ := qLeaks
    exact False.elim (safe n ⟨nq,nq⟩)

end Research.Graph9822TwoHidden
