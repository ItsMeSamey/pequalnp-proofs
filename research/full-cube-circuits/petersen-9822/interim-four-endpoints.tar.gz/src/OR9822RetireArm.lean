import And9822FreeORDefs
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution

def omitSource (k : Nat) (a : Arm) : Arm := a.filter (fun i => i != k)
def omitProduct (k : Nat) (p : Product) : Product := (omitSource k p.1,omitSource k p.2)

theorem read_omit (k : Nat) (w : Wire) (a : Arm) :
    readArm w (omitSource k a) = readArm (Function.update w k false) a := by
  apply Bool.eq_iff_iff.mpr
  simp only [readArm,omitSource,List.any_eq_true,List.mem_filter,bne_iff_ne]
  constructor
  · rintro ⟨i,⟨ha,ne⟩,hi⟩
    exact ⟨i,ha,by simpa [Function.update_of_ne ne] using hi⟩
  · rintro ⟨i,ha,hi⟩
    by_cases eq : i = k
    · subst i
      simp at hi
    · exact ⟨i,⟨ha,eq⟩,by simpa [Function.update_of_ne eq] using hi⟩

end Research.Graph9822.FreeOR
