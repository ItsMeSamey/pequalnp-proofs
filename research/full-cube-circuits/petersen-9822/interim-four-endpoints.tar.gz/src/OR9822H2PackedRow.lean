import OR9822H2StepSound
import OR9822H2MaskLogic
namespace Research.Graph9822H2Check

theorem positive_at {q i : Nat} (lt : i<13) (hot : (positive q).testBit i = true) :
    holds q (bit i) := by
  apply (subset_bits ..).2
  intro k sel
  have eq : i=k := by simpa [bit,Nat.testBit_two_pow] using sel
  subst k
  have qhot : q.testBit i = true := (Bool.and_eq_true_iff.mp
    (by simpa only [positive,Nat.testBit_and] using hot)).1
  simp only [grants,Nat.testBit_xor,Nat.testBit_shiftLeft,show ¬i≥13 by omega,decide_false,Bool.false_and,qhot] <;> rfl

theorem negative_shore {q f : Nat} (bound : f < 65536)
    (apart : ∀ n : Fin 16, f.testBit n.val = true → (negative q).testBit n.val = false) :
    holds q (f <<< 13) := by
  apply (subset_bits ..).2
  intro i sel
  have parts : decide (i≥13) = true ∧ f.testBit (i-13) = true :=
    Bool.and_eq_true_iff.mp (by simpa only [Nat.testBit_shiftLeft] using sel)
  have lo : i≥13 := of_decide_eq_true parts.1
  have near : i-13<16 := by
    by_contra far
    have z : f.testBit (i-13) = false := Nat.testBit_lt_two_pow
      (lt_of_lt_of_le (show f<2^16 from bound) (Nat.pow_le_pow_right (by decide) (by omega)))
    simp [z] at parts
  have act := apart ⟨i-13,near⟩ parts.2
  have eq : 13+(i-13)=i := by omega
  have cold : q.testBit i = false := by simpa [negative,eq] using act
  have ones : (65535:Nat).testBit (i-13) = true := by
    change (2^16-1 : Nat).testBit (i-13) = true
    rw [Nat.testBit_two_pow_sub_one]
    simp [near]
  simp only [grants,Nat.testBit_xor,Nat.testBit_shiftLeft,lo,decide_true,Bool.true_and,cold,ones] <;> rfl

/-- Actual truth assignments for raw labels, H and Q; constants are read from packed columns. -/
def numericNeg (h q u : Nat) (n : Fin 16) : Bool :=
  (if u == 11 then negative q else fixedNeg h u).testBit n.val

def numericPos (h q i u : Nat) : Prop :=
  u ∈ labels h i ∧ (u = 11 → (positive q).testBit i = true)

end Research.Graph9822H2Check
