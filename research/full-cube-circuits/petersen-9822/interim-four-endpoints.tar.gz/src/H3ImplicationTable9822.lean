import OR9822H2Checker
namespace Research.Graph9822Implication
open Research.Graph9822H2Check Research.Graph9822OneHidden
def coPairs : List (Nat × Nat) := do
  let a ← vs
  let b ← vs
  guard (a < b && meets (rawNeg (bit a)) (rawNeg (bit b)))
  return (a,b)

def sourcePairs : List (Nat × Nat) := [(0,1),(0,2),(0,3),(0,6),(0,7),(0,8),(0,9),(1,3),(1,4),(1,5),(1,7),(1,8),(1,9),(2,3),(2,4),(2,5),(2,6),(2,8),(2,9),(3,5),(3,6),(3,7),(3,9),(4,5),(4,6),(4,7),(4,8),(5,6),(5,9),(6,7),(7,8),(8,9)]

def clauseBit (l r : Nat) : Option Nat := do
  guard (l < 40 && r < 40)
  let x := l ^^^ 1
  let v := (x / 2) % 10
  let w := (r / 2) % 10
  if x%2 == 0 && r%2 == 0 then
    guard (x/20 == r/20)
    let i := edges.idxOf (bit v ||| bit w)
    guard (i < 13)
    return bit ((if x < 20 then 13 else 0)+i)
  else
    guard (x%2 == 1 && r%2 == 1)
    if x/20 == r/20 then
      guard (20 ≤ x && v == w)
      return bit (58+v)
    else if v == w then return 0
    else
      let i := sourcePairs.idxOf (min v w,max v w)
      guard (i < 32)
      return bit (26+i)

def pathBits (start : Nat) : List Nat → Option Nat
  | [] => some 0
  | x :: xs => do
    let a ← clauseBit start x
    let b ← pathBits x xs
    return a ||| b

def required (p : List Nat) : Option Nat := do
  let h ← p.head?
  guard (p.getLast? == some h && p.contains (h ^^^ 1))
  let r ← pathBits h p.tail
  return r ^^^ ((r &&& 8191) &&& ((r >>> 13) &&& 8191))

def modeSig (h s : Nat) (useH : Bool) : Nat :=
  let t := positive s
  let f := negative s
  let need := if useH then t &&& (8191 ^^^ positive h) else t
  let bad := if useH then f &&& negative h else 0
  let pair := edgeMask (fun i => let (v,w) := coPairs[i]!; meets f (rawNeg (bit v) &&& rawNeg (bit w))) (List.range 32)
  let unit := edgeMask (fun v => meets bad (rawNeg (bit v))) vs
  t ||| (need <<< 13) ||| (pair <<< 26) ||| (unit <<< 58)
end Research.Graph9822Implication
