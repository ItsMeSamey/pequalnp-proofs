import H2UnsortedRescue9822
namespace Research.Graph9822H2Check
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem pair85at4 : pairCovered 33847320 1 9 [8331266, 133087746, 528925184, 534323714] = true := by decide +kernel
end Research.Graph9822H2Check
