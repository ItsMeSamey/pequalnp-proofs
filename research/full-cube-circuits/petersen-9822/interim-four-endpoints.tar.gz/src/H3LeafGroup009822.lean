import H3LeafCheck9822
namespace Research.Graph9822H3Leaf
def gs00 : List (Nat × Nat) := [(77890,24215686),(77890,309436550),(77890,310124678),(77890,339800328),(100096,6389766),(100096,48283660),(100096,106184737),(108416,6389766),(116256,6389766),(116512,6389766),(116512,106184737),(116512,114630673)]
theorem pass00 : gs00.all (fun (h,s) => leafCheck h s)=true := by decide +kernel
end Research.Graph9822H3Leaf
