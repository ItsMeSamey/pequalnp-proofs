import OR9822H2MatchingOrder
import OR9822H2PhysicalLeaks
import Mathlib.Tactic.FinCases
namespace Research.Graph9822.FreeOR
open Research.Graph9822.FeatureRun Research.Graph9822Resolution Research.Graph9822H2Check Research.Graph9822TwoHidden
theorem resolve_two_terms {h q : Nat} (bh : negative h<65536)
    (leak : ∃ n : Fin 16,(negative q).testBit n.val=true) (terms : Fin 3 → Arms Nat)
    (cover : ∀ e : Fin 13,∃ k,(terms k).accepts (fun u e => numericPos h q e.val u) e)
    (safe : ∀ k n,¬(terms k).accepts (fun u n => numericNeg h q u n=true) n)
    (code : Nat) (quad : List Nat) (lookup : matchings[code]?=some quad) :
    ∃ i∈quad,∃ j∈quad,i<j ∧ ∃ r∈rescue h i j,holds q r := by
  have mem : quad∈matchings := List.mem_of_getElem? lookup
  obtain ⟨i,j,k,l,rfl,ij,jk,kl,lo⟩ := decodeQuad2 quad mem
  let rows (a : Fin 4) : Fin 13 := if a=0 then ⟨i,by omega⟩ else if a=1 then ⟨j,by omega⟩ else if a=2 then ⟨k,by omega⟩ else ⟨l,lo⟩
  have ord : StrictMono rows := by
    intro a b lt
    fin_cases a <;> fin_cases b <;> simp_all [rows,Fin.lt_def] <;> omega
  have member (a : Fin 4) : (rows a).val∈[i,j,k,l] := by fin_cases a <;> simp [rows]
  obtain ⟨a,b,lt,s,hs,sat⟩ := four_actual h q bh leak terms cover safe rows ord
  exact ⟨_,member a,_,member b,lt,s,hs,sat⟩
theorem resolve_physical2 (c : MaximumFive) (p q : Product) (hp : (hiddenFirst c.toFiveProgram).1=[p,q])
    (code : Nat) (quad : List Nat) (lookup : matchings[code]?=some quad) :
    ∃ i∈quad,∃ j∈quad,i<j ∧ ∃ r∈rescue (firstSig p) i j,holds (secondSig p q) r := by
  obtain ⟨term,_,_,_,cover,safe⟩ := three_terms c.toFiveProgram p q hp
  exact resolve_two_terms (neg_bound2 _) (physical_leaks2 c p q hp).2
    (fun i => productArms (term i)) cover safe code quad lookup
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.resolve_physical2
