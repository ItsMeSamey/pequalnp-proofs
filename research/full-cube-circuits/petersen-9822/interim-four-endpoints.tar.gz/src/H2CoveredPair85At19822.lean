import H2UnsortedRescue9822
namespace Research.Graph9822H2Check
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem pair85at1 : pairCovered 33847320 0 3 [182870025, 249798665, 387047433, 498581513] = true := by decide +kernel
end Research.Graph9822H2Check
