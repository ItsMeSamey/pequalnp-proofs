import OR9822ArmMask
import OR9822TwoSlotValue
namespace Research.Graph9822.FeatureRun
open Research.Graph9822Resolution Research.Graph9822.FreeOR
open Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets)

theorem first_row (p : Product) (r : Fin 29) : firstCol p r =
    (meets (armMask p.1) (rawRow r) && meets (armMask p.2) (rawRow r)) := by
  change productBit (fun j => rawBank j r) p = _
  rw [← actual_input,productBit,read_arm_mask,read_arm_mask]

theorem read_with_first (p : Product) (a : Arm) (r : Fin 29) :
    readColumn (Function.update rawBank 10 (firstCol p)) a r =
      (meets (armMask a) (rawRow r) || (a.contains 10 && firstCol p r)) := by
  rw [← read_arm_mask]
  apply Bool.eq_iff_iff.mpr
  simp only [readColumn,readArm,List.any_eq_true,Bool.or_eq_true,Bool.and_eq_true,List.contains_iff_mem]
  constructor
  · rintro ⟨v,mem,hot⟩
    by_cases eq : v=10
    · subst v; exact Or.inr ⟨mem,by simpa using hot⟩
    · exact Or.inl ⟨v,mem,by simpa [actual_input,Function.update_of_ne eq] using hot⟩
  · rintro (⟨v,mem,hot⟩ | ⟨mem,hot⟩)
    · have ne : v ≠ 10 := by
        intro eq; subst v; simp [fullWire] at hot
      exact ⟨v,mem,by simpa only [Function.update_of_ne ne,actual_input] using hot⟩
    · exact ⟨10,mem,by simpa using hot⟩

theorem second_row (p q : Product) (r : Fin 29) : secondCol p q r =
    ((meets (armMask q.1) (rawRow r) || (q.1.contains 10 && firstCol p r)) &&
     (meets (armMask q.2) (rawRow r) || (q.2.contains 10 && firstCol p r))) := by
  simp [secondCol,productColumn,read_with_first]

theorem second_distinct (q : Product) (apart : ∀ i ∈ q.1, i ∉ q.2) :
    q.1.contains 10 = false ∨ q.2.contains 10 = false := by
  by_cases left : 10 ∈ q.1
  · exact Or.inr (by simpa using apart 10 left)
  · exact Or.inl (by simpa using left)

end Research.Graph9822.FeatureRun
