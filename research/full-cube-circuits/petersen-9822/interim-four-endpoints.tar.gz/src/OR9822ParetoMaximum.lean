import OR9822Chronological
import OR9822FiveFromRows
import OR9822TwoSlotValue
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FeatureRun
open Research.Graph9822.FourSaturation

/-- Replacing the first slot keeps every original collector. Full-cube correctness follows
from monotonicity on the thirteen edges and sixteen maximal independent sets. -/
def replaceFirstMaximum (c : MaximumFive) (p r : Product) (tail : List Product)
    (eq : c.products=p::tail) (valid : ValidInputs 10 r)
    (sep : ∀ j ∈ r.1, j ∉ r.2)
    (betterPos : ∀ e∈edges, productBit (fullWire (edgeMask e)) p=true →
      productBit (fullWire (edgeMask e)) r=true)
    (betterNeg : ∀ m∈witnesses, productBit (fullWire m) r=true →
      productBit (fullWire m) p=true) : MaximumFive := by
  have ordered := c.ordered
  rw [eq] at ordered
  have orderR : Chronological 10 (r::tail) c.out := ⟨valid.1,valid.2,ordered.2.2⟩
  have disR : ∀ g∈r::tail, ∀ j∈g.1,j∉g.2 := by
    intro g mem
    rcases List.mem_cons.mp mem with h|h
    · subst g; exact sep
    · exact c.disjoint g (by rw [eq]; exact List.mem_cons_of_mem p h)
  have move (m : Nat) (x y : Product)
      (rel : productBit (fullWire m) x=true → productBit (fullWire m) y=true) :
      resultOn (x::tail) c.out m=true → resultOn (y::tail) c.out m=true := by
    apply read_mono (run_mono _ tail 11)
    intro j
    by_cases same : j=10
    · subst j; simpa using rel
    · simp [Function.update_of_ne same]
  have pos : ∀ e ∈ edges, edgeMask e < 1024 ∧ accepts (edgeMask e)=true := by decide +kernel
  have neg : ∀ m ∈ witnesses, m < 1024 ∧ accepts m=false := by decide +kernel
  let w := fromRows (r::tail) c.out (by simpa [eq] using c.count) orderR disR
    (fun e he => move _ p r (betterPos e he) (by
      simpa [resultOn,←eq,(pos e he).2] using c.correct ⟨_,(pos e he).1⟩))
    (fun m hm => Bool.eq_false_iff.mpr (fun live => by
      have old := move m r p (betterNeg m hm) live
      have cold := c.correct ⟨_,(neg m hm).1⟩
      have off : resultOn (p::tail) c.out m=false := by
        simpa only [resultOn,←eq] using cold.trans (neg m hm).2
      exact Bool.noConfusion (old.symm.trans off)))
  exact ⟨w,c.maximal⟩
end Research.Graph9822.FreeOR
