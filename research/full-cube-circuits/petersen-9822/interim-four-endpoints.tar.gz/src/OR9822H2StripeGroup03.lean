import OR9822H2StripeBound036
import OR9822H2StripeBound037
import OR9822H2StripeBound038
import OR9822H2StripeBound039
import OR9822H2StripeBound040
import OR9822H2StripeBound041
import OR9822H2StripeBound042
import OR9822H2StripeBound043
import OR9822H2StripeBound044
import OR9822H2StripeBound045
import OR9822H2StripeBound046
import OR9822H2StripeBound047
namespace Research.Graph9822H2Check.SeedCache
theorem stripeGroup03 (t : Nat) (low : 1568≤t) (high : t<2176) : stripe t=true := by
  by_cases l0 : t<1600
  · have eq : 1568+(t-1568)=t := by omega
    simpa only [eq] using boundStripe036 ⟨t-1568,by omega⟩
  by_cases l1 : t<1664
  · have eq : 1600+(t-1600)=t := by omega
    simpa only [eq] using boundStripe037 ⟨t-1600,by omega⟩
  by_cases l2 : t<1728
  · have eq : 1664+(t-1664)=t := by omega
    simpa only [eq] using boundStripe038 ⟨t-1664,by omega⟩
  by_cases l3 : t<1792
  · have eq : 1728+(t-1728)=t := by omega
    simpa only [eq] using boundStripe039 ⟨t-1728,by omega⟩
  by_cases l4 : t<1824
  · have eq : 1792+(t-1792)=t := by omega
    simpa only [eq] using boundStripe040 ⟨t-1792,by omega⟩
  by_cases l5 : t<1856
  · have eq : 1824+(t-1824)=t := by omega
    simpa only [eq] using boundStripe041 ⟨t-1824,by omega⟩
  by_cases l6 : t<1920
  · have eq : 1856+(t-1856)=t := by omega
    simpa only [eq] using boundStripe042 ⟨t-1856,by omega⟩
  by_cases l7 : t<2048
  · have eq : 1920+(t-1920)=t := by omega
    simpa only [eq] using boundStripe043 ⟨t-1920,by omega⟩
  by_cases l8 : t<2080
  · have eq : 2048+(t-2048)=t := by omega
    simpa only [eq] using boundStripe044 ⟨t-2048,by omega⟩
  by_cases l9 : t<2112
  · have eq : 2080+(t-2080)=t := by omega
    simpa only [eq] using boundStripe045 ⟨t-2080,by omega⟩
  by_cases l10 : t<2144
  · have eq : 2112+(t-2112)=t := by omega
    simpa only [eq] using boundStripe046 ⟨t-2112,by omega⟩
  by_cases l11 : t<2176
  · have eq : 2144+(t-2144)=t := by omega
    simpa only [eq] using boundStripe047 ⟨t-2144,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
