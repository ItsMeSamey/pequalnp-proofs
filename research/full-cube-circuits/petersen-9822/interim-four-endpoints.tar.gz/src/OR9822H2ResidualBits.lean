import OR9822H2SourceRows
import OR9822H2RootEntry
namespace Research.Graph9822H2Check
open Research.Graph9822H1Check Research.Graph9822.FreeOR Research.Graph9822TwoHidden Research.Graph9822OneHidden
theorem safeRaw2 {h : Nat} {v : Fin 10} (safe : ∀ n,nBit2 h n → ¬negRaw n v=true) :
    (freeRaw (negative h)).testBit v.val=true := by
  apply (freeRaw_member _ _).mpr
  refine ⟨v.isLt,(empty_overlap ..).2 ?_⟩
  intro i hot
  by_cases lt : i<16
  · exact Bool.eq_false_iff.mpr (fun on => safe ⟨i,lt⟩ hot ((singleton_raw_neg v ⟨i,lt⟩).symm.trans on))
  · exact Nat.testBit_lt_two_pow (lt_of_lt_of_le (show rawNeg (bit v.val)<65536 from mask_lt1 _ _)
      (show 65536≤2^i from Nat.pow_le_pow_right (by decide : 0 < (2:Nat)) (by omega : 16 ≤ i)))
theorem hot_residual2 {h c : Nat} (e : Fin 13) (on : (residual2 h c).testBit e.val=true) :
    (rawPos c).testBit e.val=false ∧ ¬(pBit2 h e ∧ ∃ v,hasPos1 e v ∧ ∀ n,nBit2 h n → ¬negRaw n v=true) := by
  have mask : (8191:Nat).testBit e.val=true := by
    change (2^13-1:Nat).testBit e.val=true
    rw [Nat.testBit_two_pow_sub_one]; simp [e.isLt]
  simp only [residual2,Nat.testBit_xor,Nat.testBit_or,Nat.testBit_and,mask] at on
  have cold : (rawPos c).testBit e.val=false ∧
      ¬((positive h).testBit e.val=true ∧ (rawPos (freeRaw (negative h))).testBit e.val=true) := by
    revert on
    cases (rawPos c).testBit e.val <;> cases (positive h).testBit e.val <;> cases (rawPos (freeRaw (negative h))).testBit e.val <;> decide
  exact ⟨cold.1,fun ⟨hp,v,ev,sv⟩ => cold.2 ⟨hp,raw_hit1 (safeRaw2 sv) ev⟩⟩
theorem sub_small2 {a b : Nat} (bound : low13 a)
    (each : ∀ i : Fin 13,a.testBit i.val=true → b.testBit i.val=true) : sub a b=true := by
  apply (subset_bits ..).mpr
  intro i hi
  by_cases lt : i<13
  · exact each ⟨i,lt⟩ hi
  · rw [bound i (by omega)] at hi;contradiction
theorem low_residual2 (h c : Nat) : low13 (residual2 h c) := by
  intro i hi
  have off : (8191:Nat).testBit i=false := Nat.testBit_lt_two_pow (lt_of_lt_of_le (by decide : 8191<2^13)
    (Nat.pow_le_pow_right (by decide : 0<(2:Nat)) hi))
  simp [residual2,off,low13_raw c i hi,low13_raw (freeRaw (negative h)) i hi]
end Research.Graph9822H2Check
