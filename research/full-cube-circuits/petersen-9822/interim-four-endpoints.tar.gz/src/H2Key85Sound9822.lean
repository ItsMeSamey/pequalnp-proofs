import H2Key85BankPart09822
import H2Key85BankPart19822
import H2Key85BankPart29822
import H23StaticChecks9822
import OR9822H2Viable
namespace Research.Graph9822Implication
open Research.Graph9822H2Check

theorem key85bookGood : key85book.all good = true := by
  simp [key85book,List.all_append,key85part0Good,key85part1Good,key85part2Good]

theorem key85reject {q s : Nat} (v : ViableTwo 33847320 q)
    (ruled : key85dead s = true) : ¬holds q s := by
  obtain ⟨A,B,useH,sem,bound,apart⟩ := v.nested
  exact shared_rejects sem bound apart checkedLanes checkedArcs key85book key85bookGood
    key85hit (fun _ ok => ok) ruled

end Research.Graph9822Implication
