import OR9822H2Rescue
namespace Research.Graph9822OneHidden
open Research.Graph9822TwoHidden (Arms)

def oneRow {V : Type} (r : V → Prop) (h : Prop) : Option V → Prop
  | none => h
  | some v => r v

/-- Orient a physical raw/raw star so its singleton shore is on the left.
The H reader is a property of the terminal and hence fixes the grant on all positive rows. -/
theorem star_grant {V N P : Type} (term : Arms (Option V)) (c : V)
    (negative : N → V → Prop) (hn : N → Prop) (pos : P → V → Prop) (hp : P → Prop)
    (neighbor : V → Prop) (short : ∀ v, term.left (some v) → v=c)
    (long : ∀ v, term.right (some v) → neighbor v) (leak : ∃ n, hn n)
    (safe : ∀ n, ¬term.accepts (fun l n => oneRow (negative n) (hn n) l) n) :
    (∀ e, term.accepts (fun l e => oneRow (pos e) (hp e) l) e → pos e c) ∨
    (∀ e, term.accepts (fun l e => oneRow (pos e) (hp e) l) e →
      (pos e c ∨ hp e) ∧ ∃ v, pos e v ∧ neighbor v ∧ ∀ n, hn n → ¬negative n v) := by
  classical
  by_cases reads : term.left none
  · right
    intro e accept
    obtain ⟨⟨a,la,pa⟩,⟨b,rb,pb⟩⟩ := accept
    constructor
    · cases a with
      | none => exact Or.inr pa
      | some u => exact Or.inl (short u la ▸ pa)
    · cases b with
      | none =>
        obtain ⟨n,hot⟩ := leak
        exact False.elim (safe n ⟨⟨none,reads,hot⟩,⟨none,rb,hot⟩⟩)
      | some v => exact ⟨v,pb,long v rb,fun n nh nv =>
          safe n ⟨⟨none,reads,nh⟩,⟨some v,rb,nv⟩⟩⟩
  · left
    intro e accept
    obtain ⟨a,la,pa⟩ := accept.1
    cases a with
    | none => exact False.elim (reads la)
    | some u => exact short u la ▸ pa

end Research.Graph9822OneHidden
