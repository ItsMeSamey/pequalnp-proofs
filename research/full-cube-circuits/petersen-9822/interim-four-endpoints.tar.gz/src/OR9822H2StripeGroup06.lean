import OR9822H2StripeBound072
import OR9822H2StripeBound073
import OR9822H2StripeBound074
import OR9822H2StripeBound075
import OR9822H2StripeBound076
import OR9822H2StripeBound077
import OR9822H2StripeBound078
import OR9822H2StripeBound079
import OR9822H2StripeBound080
import OR9822H2StripeBound081
import OR9822H2StripeBound082
import OR9822H2StripeBound083
namespace Research.Graph9822H2Check.SeedCache
theorem stripeGroup06 (t : Nat) (low : 4224≤t) (high : t<5120) : stripe t=true := by
  by_cases l0 : t<4256
  · have eq : 4224+(t-4224)=t := by omega
    simpa only [eq] using boundStripe072 ⟨t-4224,by omega⟩
  by_cases l1 : t<4288
  · have eq : 4256+(t-4256)=t := by omega
    simpa only [eq] using boundStripe073 ⟨t-4256,by omega⟩
  by_cases l2 : t<4352
  · have eq : 4288+(t-4288)=t := by omega
    simpa only [eq] using boundStripe074 ⟨t-4288,by omega⟩
  by_cases l3 : t<4384
  · have eq : 4352+(t-4352)=t := by omega
    simpa only [eq] using boundStripe075 ⟨t-4352,by omega⟩
  by_cases l4 : t<4416
  · have eq : 4384+(t-4384)=t := by omega
    simpa only [eq] using boundStripe076 ⟨t-4384,by omega⟩
  by_cases l5 : t<4480
  · have eq : 4416+(t-4416)=t := by omega
    simpa only [eq] using boundStripe077 ⟨t-4416,by omega⟩
  by_cases l6 : t<4608
  · have eq : 4480+(t-4480)=t := by omega
    simpa only [eq] using boundStripe078 ⟨t-4480,by omega⟩
  by_cases l7 : t<4736
  · have eq : 4608+(t-4608)=t := by omega
    simpa only [eq] using boundStripe079 ⟨t-4608,by omega⟩
  by_cases l8 : t<4864
  · have eq : 4736+(t-4736)=t := by omega
    simpa only [eq] using boundStripe080 ⟨t-4736,by omega⟩
  by_cases l9 : t<4928
  · have eq : 4864+(t-4864)=t := by omega
    simpa only [eq] using boundStripe081 ⟨t-4864,by omega⟩
  by_cases l10 : t<4992
  · have eq : 4928+(t-4928)=t := by omega
    simpa only [eq] using boundStripe082 ⟨t-4928,by omega⟩
  by_cases l11 : t<5120
  · have eq : 4992+(t-4992)=t := by omega
    simpa only [eq] using boundStripe083 ⟨t-4992,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
