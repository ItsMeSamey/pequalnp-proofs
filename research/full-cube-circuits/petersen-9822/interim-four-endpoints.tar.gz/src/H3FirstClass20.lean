import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class080 : runPacket packets[80]! = true := by decide +kernel
theorem class081 : runPacket packets[81]! = true := by decide +kernel
theorem class082 : runPacket packets[82]! = true := by decide +kernel
theorem class083 : runPacket packets[83]! = true := by decide +kernel
end Research.Graph9822FirstBroad
