import OR9822FiveMinimum
import OR9822CollectorCount
namespace Research.Graph9822.FreeOR
theorem collector_gain (out : Arm) {k : Nat} (lo : 10 ≤ k) (hi : k < 15)
    (fresh : k ∉ out) : collectorSize (k :: out) = collectorSize out + 1 := by
  apply filter_gain _ _ _ fresh (by decide)
  exact List.mem_range'.mpr ⟨k-10,by omega,by omega⟩

theorem maximal_forbids_promotion (c : MaximumFive) (p : FiveProgram)
    {k : Nat} (lo : 10 ≤ k) (hi : k < 15) (fresh : k ∉ c.out) (out : p.out = k :: c.out) : False := by
  have bound := c.maximal p
  rw [out,collector_gain _ lo hi fresh] at bound
  omega

end Research.Graph9822.FreeOR
