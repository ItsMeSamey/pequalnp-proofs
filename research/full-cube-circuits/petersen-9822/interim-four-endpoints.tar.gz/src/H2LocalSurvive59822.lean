import H2OneNodeLocal9822
namespace Research.Graph9822H2Local
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem rejectPair5 : ([40788488, 107979272, 435044864, 528588808, 528769544, 530989576] : List Nat).all (fun r => !keep (535693216 ||| r)) = true := by decide +kernel
end Research.Graph9822H2Local
