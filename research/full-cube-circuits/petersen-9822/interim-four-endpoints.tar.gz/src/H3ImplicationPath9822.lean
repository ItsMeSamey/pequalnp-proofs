import PEqualNP.Defs

namespace Research.Graph9822H3Implication

def opp (l : Nat) : Nat := l ^^^ 1

def pathTo (edge : Nat → Nat → Bool) (finish : Nat) : Nat → List Nat → Bool
  | x, [] => x == finish
  | x, y :: ys => edge x y && pathTo edge finish y ys

def closedConflict (edge : Nat → Nat → Bool) : List Nat → Bool
  | [] => false
  | x :: xs => pathTo edge x x xs && xs.contains (opp x)

theorem pathTo_transports {edge : Nat → Nat → Bool} {value : Nat → Bool}
    (sound : ∀ x y, edge x y = true → value x = true → value y = true)
    {finish x : Nat} {xs : List Nat} (ok : pathTo edge finish x xs = true) :
    ∀ z ∈ x :: xs, (value x = true → value z = true) ∧
      (value z = true → value finish = true) := by
  induction xs generalizing x with
  | nil =>
    have eq : x = finish := by simpa [pathTo] using ok
    intro z mem
    have zx : z = x := by simpa using mem
    subst z
    subst finish
    exact ⟨id,id⟩
  | cons y ys ih =>
    obtain ⟨edgeXY,rest⟩ := Bool.and_eq_true_iff.mp ok
    have recPath := ih (x := y) rest
    have xy := sound x y edgeXY
    intro z mem
    rcases List.mem_cons.mp mem with eq | tail
    · subst z
      exact ⟨id, fun hx => (recPath y (by simp)).2 (xy hx)⟩
    · exact ⟨fun hx => (recPath z tail).1 (xy hx), (recPath z tail).2⟩

theorem closedConflict_impossible {edge : Nat → Nat → Bool} {value : Nat → Bool}
    (opposite : ∀ l, value (opp l) = !value l)
    (sound : ∀ x y, edge x y = true → value x = true → value y = true)
    {path : List Nat} (ok : closedConflict edge path = true) : False := by
  cases path with
  | nil => simp [closedConflict] at ok
  | cons x xs =>
    obtain ⟨closed,contains⟩ := Bool.and_eq_true_iff.mp ok
    have mem : opp x ∈ xs := by simpa using contains
    have both := pathTo_transports sound closed (opp x) (List.mem_cons_of_mem x mem)
    cases hx : value x with
    | false =>
      have ho : value (opp x) = true := by simp [opposite x,hx]
      have bad := both.2 ho
      simp [hx] at bad
    | true =>
      have bad := both.1 hx
      simp [opposite x,hx] at bad

end Research.Graph9822H3Implication
