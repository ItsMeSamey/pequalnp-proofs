import H3TailAllLayouts9822
namespace Research.H3Tail

def applyLayout (bans : Array Nat) : List Nat → List Nat → Arms → Option Arms
  | [],[],a => some a
  | slot::slots,g::gs,a => do
    let b ← bans[g]?
    applyLayout bans slots gs (add a slot b)
  | _,_,_ => none

theorem every_perm {edges bans : Array Nat} (slots unused gs : List Nat)
    (a final : Arms) (all : EveryLayout edges bans slots unused a)
    (perm : gs.Perm unused) (run : applyLayout bans slots gs a = some final) :
    Obstructed edges final := by
  induction slots generalizing unused gs a with
  | nil =>
    cases gs with
    | nil =>
      have eq : a = final := Option.some.inj run
      exact eq ▸ all
    | cons => simp [applyLayout] at run
  | cons slot slots ih =>
    cases gs with
    | nil => simp [applyLayout] at run
    | cons g gs =>
      have mem : g ∈ unused := perm.mem_iff.mp (by simp)
      have smaller : gs.Perm (unused.erase g) := by simpa using perm.erase g
      cases get : bans[g]? with
      | none => simp [applyLayout,get] at run
      | some b =>
        exact ih _ _ _ (all g mem b get) smaller (by simpa [applyLayout,get] using run)

theorem accepted_perm {edges bans : Array Nat} (slots gs hints : List Nat) (final : Arms)
    (accept : accepts edges bans slots hints = true) (perm : gs.Perm (List.range 7))
    (run : applyLayout bans slots gs ⟨0,0,0,0,0,0⟩ = some final) :
    Obstructed edges final := by
  have ok : visit edges bans slots (List.range 7) ⟨0,0,0,0,0,0⟩ hints = some [] := by
    simpa [accepts] using accept
  exact every_perm slots _ gs _ _ (visitSound _ _ _ _ _ _ _ ok) perm run

end Research.H3Tail
