import OR9822H2SeedCacheLanes
import H2Key85Bank9822
namespace Research.Graph9822H2Check.SeedCache
open Research.Graph9822Implication
set_option maxRecDepth 20000 in
set_option maxHeartbeats 6000000 in
theorem lane85_06 : eachLane 33847320 6144 (rootCovered key85dead [535693216]) (centerLanes[6]!)=true := by decide +kernel
end Research.Graph9822H2Check.SeedCache
