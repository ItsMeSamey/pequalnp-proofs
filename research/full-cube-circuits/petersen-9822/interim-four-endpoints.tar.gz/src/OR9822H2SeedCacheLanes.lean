import OR9822H2SeedCacheSound
namespace Research.Graph9822H2Check.SeedCache
def centerLanes : List (List Nat) := [[61, 95, 159, 4381, 3101, 829, 6237, 1693],
  [111, 175, 4397, 3133, 813, 6253, 1709, 206],
  [4430, 3166, 878, 6222, 1742, 4494, 3230, 942],
  [6350, 1678, 7452, 4908, 6476, 6028, 3900, 7260],
  [3740, 7020, 1964, 7884, 115, 183, 4409, 3121],
  [817, 6257, 1713, 215, 4443, 3155, 883, 6227],
  [1747, 4511, 3223, 951, 6359, 1687, 7449, 4921],
  [6489, 6041, 3889, 7249, 3729, 7025, 1969, 7889],
  [231, 4459, 3187, 867, 6243, 1763, 4527, 3255],
  [935, 6375, 1703, 7481, 4905, 6505, 6057, 3889],
  [7281, 3761, 7009, 1953, 7905, 4558, 3286, 998],
  [6342, 1734, 7514, 4970, 6474, 6090, 3954, 7250],
  [3794, 7010, 2018, 7874, 7582, 5038, 6606, 6030],
  [4022, 7382, 3734, 7142, 1958, 7878, 7992, 7512],
  [8088, 7016, 6056, 8136, 8048, 4016, 7888, 8160]]
private theorem literalCenters : centerLanes.flatten = cachedCenters := by decide +kernel

def centerTest (h base cp : Nat) (P : Nat → Bool) : Bool :=
  let t := 8191 ^^^ (cp ||| base)
  [false,true].all fun use =>
    let req := if use then t &&& (8191 ^^^ positive h) else t
    (decide (req<8192) && (entry req != 0)) && (row req).all (fun f =>
      P (demand t (f ||| (if use then negative h else 0))))

def eachLane (h base : Nat) (P : Nat → Bool) (lane : List Nat) :=
  lane.all (fun cp => centerTest h base cp P)

theorem lanes_sound (h base : Nat) (P : Nat → Bool)
    (eq : base=positive h &&& rawPos (freeRaw (negative h)))
    (ok : ∀ lane∈centerLanes, eachLane h base P lane=true) : allSeeds h P=true := by
  apply List.all_eq_true.mpr
  intro cp cm
  rw [←literalCenters] at cm
  obtain ⟨lane,lm,atLane⟩ := List.mem_flatten.mp cm
  subst base
  exact List.all_eq_true.mp (ok lane lm) cp atLane
end Research.Graph9822H2Check.SeedCache
