import H2UnsortedRescue9822
namespace Research.Graph9822H2Check
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem pair85covered :
    pairCovered 33847320 0 1 [184229891,266788867,358211587,395821059] = true := by decide +kernel
end Research.Graph9822H2Check
