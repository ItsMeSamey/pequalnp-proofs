import H3ImplicationPath9822
namespace Research.Graph9822H3Implication

def literalValue (wire l : Nat) : Bool :=
  (wire.testBit (l >>> 1)) ^^ (l.testBit 0)

theorem literalOpposite (wire l : Nat) :
    literalValue wire (opp l) = !literalValue wire l := by
  simp only [literalValue,opp,Nat.shiftRight_xor_distrib,Nat.testBit_xor]
  change ((wire.testBit ((l >>> 1) ^^^ 0)) ^^ ((l.testBit 0) ^^ true)) =
    !((wire.testBit (l >>> 1)) ^^ (l.testBit 0))
  rw [Nat.xor_zero]
  cases wire.testBit (l >>> 1) <;> cases l.testBit 0 <;> rfl

end Research.Graph9822H3Implication
