import OR9822H2StripeGroup00
import OR9822H2StripeGroup01
import OR9822H2StripeGroup02
import OR9822H2StripeGroup03
import OR9822H2StripeGroup04
import OR9822H2StripeGroup05
import OR9822H2StripeGroup06
import OR9822H2StripeGroup07
import OR9822H2StripeGroup08
namespace Research.Graph9822H2Check.SeedCache
theorem paidStripe (t : Fin 8192) : stripe t.val=true := by
  by_cases l0 : t.val<416
  · exact stripeGroup00 _ (by omega) l0
  by_cases l1 : t.val<928
  · exact stripeGroup01 _ (by omega) l1
  by_cases l2 : t.val<1568
  · exact stripeGroup02 _ (by omega) l2
  by_cases l3 : t.val<2176
  · exact stripeGroup03 _ (by omega) l3
  by_cases l4 : t.val<3264
  · exact stripeGroup04 _ (by omega) l4
  by_cases l5 : t.val<4224
  · exact stripeGroup05 _ (by omega) l5
  by_cases l6 : t.val<5120
  · exact stripeGroup06 _ (by omega) l6
  by_cases l7 : t.val<6656
  · exact stripeGroup07 _ (by omega) l7
  by_cases l8 : t.val<8192
  · exact stripeGroup08 _ (by omega) l8
  omega
end Research.Graph9822H2Check.SeedCache
