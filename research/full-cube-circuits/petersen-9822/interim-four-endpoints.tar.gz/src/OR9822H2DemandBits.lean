import OR9822H2PackedRow
namespace Research.Graph9822H2Check

theorem true_on_demand {s q : Nat} (live : holds q s) (e : Fin 13)
    (need : (positive s).testBit e.val = true) : (positive q).testBit e.val = true := by
  have mask : (8191:Nat).testBit e.val = true := by
    change (2^13-1 : Nat).testBit e.val = true; rw [Nat.testBit_two_pow_sub_one]; simp [e.isLt]
  have sHot : s.testBit e.val = true := by simpa [positive,mask] using need
  have allowed := (subset_bits ..).1 live e.val sHot
  have qHot : q.testBit e.val = true := by
    simpa only [grants,Nat.testBit_xor,Nat.testBit_shiftLeft,show ¬ e.val≥13 by omega,decide_false,Bool.false_and,Bool.xor_false] using allowed
  simp [positive,mask,qHot]

theorem false_on_demand {s q : Nat} (live : holds q s) (n : Fin 16)
    (forbid : (negative s).testBit n.val = true) : (negative q).testBit n.val = false := by
  have selected : s.testBit (13+n.val) = true := by simpa [negative] using forbid
  have permitted := (subset_bits ..).1 live _ selected
  have mask : (65535:Nat).testBit n.val = true := by
    change (2^16-1 : Nat).testBit n.val = true; rw [Nat.testBit_two_pow_sub_one]; simp [n.isLt]
  have hi : 13+n.val≥13 := by omega
  have idx : 13+n.val-13=n.val := by omega
  simp only [grants,Nat.testBit_xor,Nat.testBit_shiftLeft,hi,decide_true,Bool.true_and,idx,mask] at permitted
  rw [negative,Nat.testBit_shiftRight]
  cases v : q.testBit (13+n.val) <;> simp [v] at *

end Research.Graph9822H2Check
