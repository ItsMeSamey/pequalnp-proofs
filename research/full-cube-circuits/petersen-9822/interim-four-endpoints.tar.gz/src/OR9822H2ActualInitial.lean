import OR9822H2NestedPhysical
import OR9822H2PhysicalMode
import OR9822H2PhysicalLeaks
namespace Research.Graph9822H2Check
open Research.Graph9822.FeatureRun Research.Graph9822.FreeOR Research.Graph9822TwoHidden
theorem initial_two_terms {h q : Nat} (terms : Fin 3 → Product)
    (bound : ∀ k,Below 12 (terms k))
    (cov : ∀ e : Fin 13,∃ k,(productArms (terms k)).accepts (fun u e => numericPos h q e.val u) e)
    (safe : ∀ k n,¬(productArms (terms k)).accepts (fun u n => numericNeg h q u n=true) n)
    (bh : negative h<65536) (bq : negative q<65536)
    (lh : ∃ n,nBit2 h n) (lq : ∃ n,nBit2 q n)
    (possible : ∀ s,holds q s → fastFeasible h s=true) : ∃ s∈fastInitial h,holds q s := by
  obtain ⟨cov,safe⟩ := liftRows2 terms bound cov safe
  obtain ⟨c,cent,pos,mode⟩ := physical_mode2 (fun k => sArms2 (productArms (terms k))) bq lh lq cov safe
  exact initial_from_mode cent bh pos mode possible
theorem initial_original2 (c : MaximumFive) (p q : Product) (hc : (hiddenFirst c.toFiveProgram).1=[p,q])
    :
    ∃ s∈fastInitial (firstSig p),holds (secondSig p q) s := by
  obtain ⟨t,_,_,bd,cov,safe⟩ := three_terms c.toFiveProgram p q hc
  obtain ⟨a,b⟩ := physical_leaks2 c p q hc
  have aq := (hidden_first_shape c.toFiveProgram).2.1 q (by rw [hc];simp)
  exact initial_two_terms t (fun k => (bd k).2) cov safe (neg_bound2 _) (neg_bound2 _) a b (fun _ => physical_fast_feasible p q aq)
end Research.Graph9822H2Check
#print axioms Research.Graph9822H2Check.initial_original2
