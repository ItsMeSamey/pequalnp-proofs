import OR9822H2Checker
namespace Research.Graph9822H2Check
theorem decodeQuad2 (l : List Nat) (ok : l∈matchings) :
    ∃ a b c d,l=[a,b,c,d] ∧ a<b ∧ b<c ∧ c<d ∧ d<13 := by
  simp only [matchings,List.bind_eq_flatMap,List.mem_flatMap] at ok
  obtain ⟨a,_,b,_,c,_,d,hd,ok⟩ := ok
  by_cases ab : a<b <;> by_cases bc : b<c <;> by_cases cd : c<d
  all_goals try simp [ab,bc,cd] at ok
  refine ⟨a,b,c,d,?_,ab,bc,cd,List.mem_range.mp hd⟩
  exact ok.2
  all_goals
    obtain ⟨x,hx⟩ := ok.1
    exact False.elim (List.not_mem_nil hx)
end Research.Graph9822H2Check
