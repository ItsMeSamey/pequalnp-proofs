import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class036 : runPacket packets[36]! = true := by decide +kernel
theorem class037 : runPacket packets[37]! = true := by decide +kernel
theorem class038 : runPacket packets[38]! = true := by decide +kernel
theorem class039 : runPacket packets[39]! = true := by decide +kernel
end Research.Graph9822FirstBroad
