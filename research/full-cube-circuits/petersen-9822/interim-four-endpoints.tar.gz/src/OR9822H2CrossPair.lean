import OR9822H2LabelBridge
import OR9822H2PackedRow
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden (edgeMask meets)

theorem edgeMask_lt (test : Nat → Bool) (xs : List Nat) :
    edgeMask test xs < 2^xs.length := by
  induction xs with
  | nil => simp [edgeMask]
  | cons x xs ih =>
    simp only [edgeMask,List.length_cons,Nat.pow_succ]
    cases test x <;> simp <;> omega

theorem fixed_bound (h u : Nat) (bounded : negative h < 65536) : fixedNeg h u < 65536 := by
  unfold fixedNeg
  split
  · exact bounded
  · exact edgeMask_lt _ _

theorem numeric_pair_rules {h q u v : Nat} (bh : negative h < 65536)
    (leak : ∃ n : Fin 16, (negative q).testBit n.val = true)
    (safe : ∀ n, ¬(numericNeg h q u n = true ∧ numericNeg h q v n = true)) :
    witnessAllowed h u v = true ∧ holds q (forbidden h u v <<< 13) := by
  by_cases uq : u=11 <;> by_cases vq : v=11
  · obtain ⟨n,hot⟩ := leak
    exact False.elim (safe n (by simp [numericNeg,uq,vq,hot]))
  · refine ⟨by simp [witnessAllowed,uq,vq],?_⟩
    simp only [forbidden,uq,beq_self_eq_true,if_true]
    apply negative_shore (fixed_bound _ _ bh)
    intro n hv
    apply Bool.eq_false_iff.mpr
    intro hot
    exact safe n (by simp [numericNeg,uq,vq,hot,hv])
  · refine ⟨by simp [witnessAllowed,uq,vq],?_⟩
    simp [forbidden,uq,vq]
    apply negative_shore (fixed_bound _ _ bh)
    intro n hu
    apply Bool.eq_false_iff.mpr
    intro hot
    exact safe n (by simp [numericNeg,uq,vq,hot,hu])
  · have no : meets (fixedNeg h u) (fixedNeg h v) = false := by
      apply (empty_overlap ..).2
      intro k hot
      by_cases lo : k<16
      · apply Bool.eq_false_iff.mpr
        intro other
        exact safe ⟨k,lo⟩ (by simp [numericNeg,uq,vq,hot,other])
      · exact Nat.testBit_lt_two_pow (lt_of_lt_of_le (fixed_bound h v bh)
          (show (65536 : Nat) ≤ 2^k from Nat.pow_le_pow_right (by decide : 0<2) (by omega : 16 ≤ k)))
    exact ⟨by simp [witnessAllowed,uq,vq,no],by simpa [forbidden,uq,vq] using zero_holds q⟩

end Research.Graph9822H2Check
