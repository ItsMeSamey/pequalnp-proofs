import OR9822H2Checker
namespace Research.Graph9822H2Check

theorem sub_trans {a b c : Nat} (ab : sub a b = true) (bc : sub b c = true) :
    sub a c = true := by
  have eab : a &&& b = a := by simpa [sub] using ab
  have ebc : b &&& c = b := by simpa [sub] using bc
  apply beq_iff_eq.mpr
  calc
    a &&& c = (a &&& b) &&& c := by rw [eab]
    _ = a &&& (b &&& c) := Nat.and_assoc .. 
    _ = a := by rw [ebc,eab]

theorem minimal_weakens {xs : List Nat} {x : Nat} (mem : x ∈ xs) :
    ∃ m ∈ minimal xs, sub m x = true := by
  classical
  have ex : ∃ k, k ∈ xs ∧ sub k x = true := ⟨x,mem,by simp [sub]⟩
  let m := Nat.find ex
  obtain ⟨hm,hsub⟩ := Nat.find_spec ex
  refine ⟨m,?_,hsub⟩
  apply List.mem_mergeSort.mpr
  apply List.mem_filter.mpr
  refine ⟨List.mem_eraseDups.mpr hm,?_⟩
  simp only [Bool.not_eq_true',List.any_eq_false]
  intro y hy
  by_cases s : sub y m = true
  · have mini : m ≤ y := Nat.find_min' ex ⟨List.mem_eraseDups.mp hy,sub_trans s hsub⟩
    have eq : y &&& m = y := by simpa [sub] using s
    have le : y ≤ m := eq ▸ (Nat.and_le_right : y &&& m ≤ m)
    simp [Nat.le_antisymm le mini]
  · simp [s]

end Research.Graph9822H2Check
