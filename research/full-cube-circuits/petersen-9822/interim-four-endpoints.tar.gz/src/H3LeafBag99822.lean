import H3LeafGroup729822
namespace Research.Graph9822H3Leaf
def bag9 : List (Nat × Nat) := gs72
theorem bagOK9 : bag9.all (fun (h,s) => leafCheck h s)=true := by simp [bag9,pass72]
end Research.Graph9822H3Leaf
