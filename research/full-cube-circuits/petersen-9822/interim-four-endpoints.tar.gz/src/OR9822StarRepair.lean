import OR9822RepairRows
import OR9822Chronological
namespace Research.Graph9822.FreeOR
open Research.Graph9822Resolution Research.Graph9822.FourSaturation

def graphStar (v : Fin 10) : Product :=
  ([v.val],(List.range 10).filter fun u => edges.contains (u,v.val) || edges.contains (v.val,u))

theorem star_valid (v : Fin 10) (k : Nat) (ge : 10 ≤ k) :
    ValidInputs k (graphStar v) ∧ ∀ i ∈ (graphStar v).1, i ∉ (graphStar v).2 := by
  have graph : ∀ v : Fin 10, ValidInputs 10 (graphStar v) ∧
      ∀ i ∈ (graphStar v).1, i ∉ (graphStar v).2 := by
    intro u
    have lo : ∀ i ∈ (graphStar u).1, i < 10 := by simp [graphStar,u.isLt]
    have hi : ∀ i ∈ (graphStar u).2, i < 10 := fun _ mem =>
      List.mem_range.mp (List.mem_filter.mp mem).1
    have noLoop : ∀ i : Fin 10, i.val ∉ (graphStar i).2 := by decide +kernel
    exact ⟨⟨lo,hi⟩,by simpa [graphStar] using noLoop u⟩
  obtain ⟨⟨a,b⟩,s⟩ := graph v
  exact ⟨⟨fun i hi => lt_of_lt_of_le (a i hi) ge,fun i hi => lt_of_lt_of_le (b i hi) ge⟩,s⟩

theorem star_prefix (pre : List Product) (v : Fin 10) (m : Nat) :
    productBit (run pre 10 (fullWire m)) (graphStar v) = productBit (fullWire m) (graphStar v) := by
  have read (a : Arm) (low : ∀ j ∈ a, j < 10) :
      readArm (run pre 10 (fullWire m)) a = readArm (fullWire m) a := by
    apply Bool.eq_iff_iff.mpr
    simp only [readArm,List.any_eq_true]
    constructor <;> rintro ⟨j,hj,hot⟩ <;>
      exact ⟨j,hj,by simpa [stale_value pre (low j hj)] using hot⟩
  obtain ⟨⟨a,b⟩,_⟩ := star_valid v 10 (by decide)
  unfold productBit
  rw [read _ a,read _ b]

theorem star_rows : ∀ v : Fin 10,
    (∀ m ∈ witnesses, productBit (fullWire m) (graphStar v) = false) ∧
    (∀ e ∈ edges, (v.val=e.1 ∨ v.val=e.2) →
      productBit (fullWire (edgeMask e)) (graphStar v) = true) := by decide +kernel

end Research.Graph9822.FreeOR
