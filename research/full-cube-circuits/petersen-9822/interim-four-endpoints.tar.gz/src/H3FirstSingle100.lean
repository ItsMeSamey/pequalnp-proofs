import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class100 : runPacket packets[100]! = true := by decide +kernel
end Research.Graph9822FirstBroad
