import OR9822H2SeedStripeSound
import OR9822H2Viable
namespace Research.Graph9822H2Check.SeedCache
theorem held_below_stripe (h q s : Nat) (P : Nat → Bool) (checks : allSeeds h P=true)
    (cache : ∀ t : Fin 8192, stripe t.val=true) (hs : s∈seedPool h) (live : holds q s) :
    ∃ weak, P weak=true ∧ holds q weak := by
  obtain ⟨c,hc,rest⟩ := List.mem_flatMap.mp hs
  obtain ⟨use,hu,more⟩ := List.mem_flatMap.mp rest
  obtain ⟨x,hx,hout⟩ := List.mem_flatMap.mp more
  let t := 8191 ^^^ (rawPos c ||| (positive h &&& rawPos (freeRaw (negative h))))
  let k := if use then t &&& (8191 ^^^ positive h) else t
  change s∈[demand t (rawNeg x ||| (if use then negative h else 0))] at hout
  have sx := List.mem_singleton.mp hout
  have atCenter : [false,true].all (fun use =>
      let req := if use then t &&& (8191 ^^^ positive h) else t
      (decide (req<8192) && (entry req != 0)) && (row req).all (fun f =>
        P (demand t (f ||| (if use then negative h else 0)))))=true := List.all_eq_true.mp checks (rawPos c) (List.mem_map.mpr ⟨c,hc,rfl⟩)
  have atMode := List.all_eq_true.mp atCenter use hu
  have passed : (decide (k<8192) && (entry k != 0))=true ∧ (row k).all
      (fun f => P (demand t (f ||| (if use then negative h else 0))))=true := Bool.and_eq_true_iff.mp atMode
  obtain ⟨lt,nonempty⟩ := Bool.and_eq_true_iff.mp passed.1
  have non : entry k≠0 := bne_iff_ne.mp nonempty
  obtain ⟨f,mem,small⟩ := stripe_member k x (of_decide_eq_true lt) (cache ⟨k,of_decide_eq_true lt⟩) non hx
  subst s
  exact ⟨_,List.all_eq_true.mp passed.2 _ mem,weaker_holds (extend_neg small t _) live⟩
theorem frozen_roots {h q : Nat} (roots : List Nat) (bad : Nat → Bool)
    (cache : ∀ t : Fin 8192, stripe t.val=true)
    (checks : allSeeds h (rootCovered bad roots)=true)
    (v : ViableTwo h q) (sound : ∀ s, bad s=true → ¬holds q s) :
    ∃ r∈roots,holds q r := by
  obtain ⟨s,mem,live⟩ := v.root
  obtain ⟨t,covered,weak⟩ := held_below_stripe _ _ _ _ checks cache (retainedSeed mem) live
  exact seeded_root covered sound weak
end Research.Graph9822H2Check.SeedCache
