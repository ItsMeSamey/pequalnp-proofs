import H3FirstBroadPackets9822
namespace Research.Graph9822FirstBroad
theorem class060 : runPacket packets[60]! = true := by decide +kernel
theorem class061 : runPacket packets[61]! = true := by decide +kernel
theorem class062 : runPacket packets[62]! = true := by decide +kernel
theorem class063 : runPacket packets[63]! = true := by decide +kernel
end Research.Graph9822FirstBroad
