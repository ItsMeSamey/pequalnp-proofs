import H3ImpBankSound9822
import H3ImpArcs9822
import H3ImpFieldProof9822
import H3ImpPhysicalSat9822
namespace Research.Graph9822Implication
open Research.Graph9822H2Check Research.Graph9822H3Implication
open Research.Graph9822OneHidden (meets)

def isDenied (hit : Nat → Bool) (h s : Nat) :=
  hit (fastSig h s false) && hit (fastSig h s true)

theorem shared_rejects {h q A B s : Nat} {useH : Bool}
    (rows : NestedBits h q A B useH) (bound : A < 1024) (apart : meets A B = false)
    (lanes : ∀ j ∈ List.range 4, laneGood j = true)
    (arcs : ∀ l ∈ List.range 40, validArcsAt l = true)
    (bank : List (Nat × List Nat)) (checked : bank.all good = true)
    (hit : Nat → Bool) (lookup : ∀ sig, hit sig = true → bank.any (fun r => sub r.1 sig) = true)
    (dead : isDenied hit h s = true) : ¬holds q s := by
  intro live
  have sat := physicalSatPrim (fields_of_lanes h s useH lanes) rows bound apart live
  have both := Bool.and_eq_true_iff.mp dead
  have found : hit (fastSig h s useH) = true := by cases useH <;> simp_all
  exact bank_refutes _ checked (lookup _ found) (literalOpposite (A ||| (B <<< 10)))
    (arcsSound arcs (literalOpposite _) sat)
end Research.Graph9822Implication
