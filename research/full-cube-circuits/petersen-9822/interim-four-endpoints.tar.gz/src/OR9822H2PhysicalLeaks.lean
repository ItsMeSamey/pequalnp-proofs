import OR9822H2PhysicalRows
import And9822NormalizedWitness
namespace Research.Graph9822.FreeOR
open Research.Graph9822.FeatureRun Research.Graph9822Resolution Research.Graph9822H2Check Research.Graph9822TwoHidden
open Research.Graph9822.FourSaturation (witnesses)
private theorem rowN (n : Fin 16) : rawRow ⟨13+n.val,by omega⟩ = witnesses[n.val]! := by simp [rawRow]
theorem physical_leaks2 (c : MaximumFive) (p q : Product) (hp : (hiddenFirst c.toFiveProgram).1=[p,q]) :
    (∃ n : Fin 16,(negative (firstSig p)).testBit n.val=true) ∧
    (∃ n : Fin 16,(negative (secondSig p q)).testBit n.val=true) := by
  constructor
  · obtain ⟨m,hm,on⟩ := (compact_hidden_witness c [] [q] p hp).1
    obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hm
    let n : Fin 16 := ⟨i,by simpa [witnesses] using hi⟩
    refine ⟨n,?_⟩
    rw [firstSig,neg_col_bit]
    change productBit (fun j => rawBank j ⟨13+n.val,by omega⟩) p=true
    rw [←actual_input,rowN,getElem!_pos witnesses i hi,eq]
    exact on
  · obtain ⟨m,hm,on⟩ := (compact_hidden_witness c [p] [] q hp).1
    obtain ⟨i,hi,eq⟩ := List.mem_iff_getElem.mp hm
    let n : Fin 16 := ⟨i,by simpa [witnesses] using hi⟩
    let r : Fin 29 := ⟨13+n.val,by omega⟩
    refine ⟨n,?_⟩
    rw [secondSig,neg_col_bit]
    change productBit (fun j => runColumns [p] 10 rawBank j r) q=true
    rw [scalar_run,←actual_input]
    dsimp only [r]
    rw [rowN,getElem!_pos witnesses i hi,eq]
    exact on
theorem neg_bound2 (a : Column) : negative (encode a)<65536 := by
  rw [negative,Nat.shiftRight_eq_div_pow]
  exact (Nat.div_lt_iff_lt_mul (by decide)).mpr (encode_bound _)
end Research.Graph9822.FreeOR
