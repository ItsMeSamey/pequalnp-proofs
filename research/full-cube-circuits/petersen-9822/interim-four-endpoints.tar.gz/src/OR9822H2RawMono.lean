import OR9822H2FreeRaw
namespace Research.Graph9822H2Check
open Research.Graph9822OneHidden (meets edgeMask)

theorem raw_trace_mono (xs : List Nat) {a b : Nat} (le : sub a b = true) :
    sub (edgeMask (meets a) xs) (edgeMask (meets b) xs) = true := by
  apply (subset_bits ..).2
  intro k hot
  rw [test_edgeMask] at hot ⊢
  cases atK : xs[k]? with
  | none => simp [atK] at hot
  | some row =>
    have ha : meets a row = true := by simpa [atK] using hot
    obtain ⟨v,va,vr⟩ := meets_iff_exists.mp ha
    have hb := meets_iff_exists.mpr ⟨v,(subset_bits ..).1 le v va,vr⟩
    simpa [atK] using hb

theorem left_in_free {a f : Nat} (bound : a < 1024) (safe : meets f (rawNeg a) = false) :
    sub a (freeRaw f) = true := by
  apply (subset_bits ..).2
  intro v va
  have lo : v<10 := by
    by_contra bad
    have z : a.testBit v = false := Nat.testBit_lt_two_pow
      (lt_of_lt_of_le bound (show (1024:Nat) ≤ 2^v from
        Nat.pow_le_pow_right (by decide : 0<2) (by omega : 10≤v)))
    simp [z] at va
  apply (freeRaw_member ..).2
  refine ⟨lo,(empty_overlap ..).2 ?_⟩
  have singleton : sub (bit v) a = true := by
    apply (subset_bits ..).2
    intro k hit
    have eq : v=k := by simpa [bit,Nat.testBit_two_pow] using hit
    exact eq ▸ va
  have incl := raw_trace_mono Research.Graph9822.FourSaturation.witnesses singleton
  intro n nf
  apply Bool.eq_false_iff.mpr
  intro nv
  have hot := (subset_bits ..).1 incl n nv
  have cold := (empty_overlap ..).1 safe n nf
  change (rawNeg a).testBit n = true at hot
  simp [cold] at hot

end Research.Graph9822H2Check
