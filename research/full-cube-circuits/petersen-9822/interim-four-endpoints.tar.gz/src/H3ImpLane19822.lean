import H3ImpLaneSpec9822
namespace Research.Graph9822Implication
set_option maxRecDepth 16000 in
set_option maxHeartbeats 5000000 in
theorem lane1Good : laneGood 1 = true := by decide +kernel
end Research.Graph9822Implication
