import OR9822H2StripeClip00
import OR9822H2StripeClip01
import OR9822H2StripeClip02
import OR9822H2StripeClip03
import OR9822H2StripeClip04
import OR9822H2StripeClip05
import OR9822H2StripeClip06
import OR9822H2StripeClip07
namespace Research.Graph9822H2Check.SeedCache
theorem allClip (i : Fin 64) : clipChecked i.val=true := by
  by_cases l0 : i.val<8
  · have eq : 0+(i.val-0)=i.val := by omega
    simpa only [eq] using checkClip00 ⟨i.val-0,by omega⟩
  by_cases l1 : i.val<16
  · have eq : 8+(i.val-8)=i.val := by omega
    simpa only [eq] using checkClip01 ⟨i.val-8,by omega⟩
  by_cases l2 : i.val<24
  · have eq : 16+(i.val-16)=i.val := by omega
    simpa only [eq] using checkClip02 ⟨i.val-16,by omega⟩
  by_cases l3 : i.val<32
  · have eq : 24+(i.val-24)=i.val := by omega
    simpa only [eq] using checkClip03 ⟨i.val-24,by omega⟩
  by_cases l4 : i.val<40
  · have eq : 32+(i.val-32)=i.val := by omega
    simpa only [eq] using checkClip04 ⟨i.val-32,by omega⟩
  by_cases l5 : i.val<48
  · have eq : 40+(i.val-40)=i.val := by omega
    simpa only [eq] using checkClip05 ⟨i.val-40,by omega⟩
  by_cases l6 : i.val<56
  · have eq : 48+(i.val-48)=i.val := by omega
    simpa only [eq] using checkClip06 ⟨i.val-48,by omega⟩
  by_cases l7 : i.val<64
  · have eq : 56+(i.val-56)=i.val := by omega
    simpa only [eq] using checkClip07 ⟨i.val-56,by omega⟩
  omega
end Research.Graph9822H2Check.SeedCache
