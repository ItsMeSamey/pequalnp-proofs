import OR9822H1TermGrant
import OR9822H1PhysicalRows
namespace Research.Graph9822.FreeOR
open Research.Graph9822.FeatureRun Research.Graph9822Resolution
open Research.Graph9822TwoHidden Research.Graph9822OneHidden
private abbrev MIS := Research.Graph9822.FourSaturation.witnesses
def HPos1 (p : Product) (e : Fin 13) := hidden1 p (edges[e.val]!)=true
def HNeg1 (p : Product) (n : Fin 16) := hidden1 p (MIS[n.val]!)=true
def hasPos1 (e : Fin 13) (v : V1) := (edges[e.val]!).testBit v.val=true

theorem physicalGrants1 (c : FiveProgram) (p : Product)
    (atH : (hiddenFirst c).1=[p]) (leak : ∃ n,HNeg1 p n) :
    ∃ terms : Fin 4 → Product, ∃ centers : Fin 4 → Option V1,
      (∀ k,terms k∈(hiddenFirst c).2) ∧
      (∀ k,Grant1 (rawArms1 (terms k)) (HNeg1 p) hasPos1 (HPos1 p) (centers k)) ∧
      ∀ e,∃ k,(rawArms1 (terms k)).accepts (fun l e => oneRow (hasPos1 e) (HPos1 p e) l) e := by
  classical
  obtain ⟨terms,mem,_,_,cover,safe⟩ := physical1 c p atH
  choose centers grants using fun k => chooseGrant1 (rawArms1 (terms k)) (HNeg1 p)
    hasPos1 (HPos1 p) leak (safe k)
  refine ⟨terms,centers,mem,grants,?_⟩
  intro e
  obtain ⟨k,h⟩ := cover e
  exact ⟨k,h⟩
end Research.Graph9822.FreeOR
#print axioms Research.Graph9822.FreeOR.physicalGrants1
