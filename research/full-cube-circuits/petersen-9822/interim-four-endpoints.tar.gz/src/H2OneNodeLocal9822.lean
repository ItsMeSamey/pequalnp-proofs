import H3ImpFast9822
import H2PhysicalForest9822
namespace Research.Graph9822H2Local
open Research.Graph9822H2Check Research.Graph9822Implication Research.H3RegionEngine
def sampleMasks : List Nat := [1729382256910270465,6917529027641081858,9511602413006487560,558345773059,34426920969,351843729294338,(512 + (160 <<< 60)),2199157801000,21990240953345,343601586689,36033195074126880,2814749770252672]
def keep (s : Nat) : Bool :=
  !(sampleMasks.any (fun r => sub r (fastSig 33847320 s false)) &&
    sampleMasks.any (fun r => sub r (fastSig 33847320 s true)))

def go (s code : Nat) : Option (List Nat) := do
  guard (code == 0)
  let q : List Nat := [0,1,3,9]
  let children := minimal (do
    let i ← q
    let j ← q
    guard (i < j)
    let r ← rescue 33847320 i j
    guard (keep (s ||| r))
    return s ||| r)
  guard (!children.contains s)
  return children

def rules : Rules Nat := ⟨fun _ => false, go⟩
end Research.Graph9822H2Local
