import SixD3GridUnits9822
import SixD3GridDataA0379822
namespace Research.Graph9822.ThreeDirect.A037
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit0 : ∀ a, Known a g 217 → Known a g 218 :=
  singleKnown g 217 (unpack 28 [0x1032800000f52d2030927902a91cf02891b1021d19d01a510501111f90184512035c333017029201697f4]) (by decide +kernel)
private theorem unit1 : ∀ a, Known a g 218 → Known a g 219 :=
  singleKnown g 218 (unpack 28 [0x1032400000f52d2030527902ed23102cd1f9021919d01a110501091cf0180472035c333017029201697f4]) (by decide +kernel)
private theorem unit2 : ∀ a, Known a g 219 → Known a g 220 :=
  singleKnown g 219 (unpack 28 [0x1033000000f52d2031127902b11cf02911b1024919d01d510501111f90198512035c33303541f3017029200f015201697f400e8e90]) (by decide +kernel)
private theorem unit3 : ∀ a, Known a g 220 → Known a g 221 :=
  singleKnown g 220 (unpack 28 [0x1032c00000f52d2030d27902ad1cf028d1b1023519d01bd10501111f90190512035c333034c0b3017029200e401201697f400dc784]) (by decide +kernel)
private theorem unit4 : ∀ a, Known a g 221 → Known a g 222 :=
  singleKnown g 221 (unpack 28 [0x1034000000f52d202e91f902c51cf02a11b1027d19d0209105]) (by decide +kernel)
private theorem unit5 : ∀ a, Known a g 222 → Known a g 223 :=
  singleKnown g 222 (unpack 28 [0x1034400000f52d2030123102c91cf02a51b1028519d0211105]) (by decide +kernel)
private theorem unit6 : ∀ a, Known a g 223 → Known a g 224 :=
  singleKnown g 223 (unpack 28 [0x1033800000f52d2031927902d91f902b51cf026919d01f5105]) (by decide +kernel)
private theorem unit7 : ∀ a, Known a g 224 → Known a g 225 :=
  singleKnown g 224 (unpack 28 [0x1033c00000f52d202fd23102e11f902bd1cf027519d0201105]) (by decide +kernel)
private theorem unit8 : ∀ a, Known a g 225 → Known a g 226 :=
  singleKnown g 225 (unpack 28 [0x1031c00000f527802f923102dd1f902b91cf027119d01fd105]) (by decide +kernel)
private theorem unit9 : ∀ a, Known a g 226 → Known a g 227 :=
  singleKnown g 226 (unpack 28 [0x1031400000f527802f123102d11f902951b1026119d01ed105]) (by decide +kernel)
private theorem unit10 : ∀ a, Known a g 227 → Known a g 228 :=
  singleKnown g 227 (unpack 28 [0x1033400000f52d202f523102d51f902991b1026519d01f1105]) (by decide +kernel)
private theorem unit11 : ∀ a, Known a g 228 → Known a g 229 :=
  singleKnown g 228 (unpack 28 [0x10098000011e08800ba08d0120653007203503541f3034c0b300f015200e401200e8e9000dc784]) (by decide +kernel)
theorem up0 : ∀ a, Known a g 217 → Known a g 229 := by
  intro a h
  apply unit11 a
  apply unit10 a
  apply unit9 a
  apply unit8 a
  apply unit7 a
  apply unit6 a
  apply unit5 a
  apply unit4 a
  apply unit3 a
  apply unit2 a
  apply unit1 a
  apply unit0 a
  exact h
end Research.Graph9822.ThreeDirect.A037
