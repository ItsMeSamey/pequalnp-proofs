import SixD3GridSemA248x009822
import SixD3GridSemA248x019822
import SixD3GridSemA248x029822
import SixD3GridSemA248x039822
import SixD3GridSemA248x049822
import SixD3GridSemA248x059822
import SixD3GridSemA248x069822
import SixD3GridSemA248x079822
import SixD3GridSemA248x089822
import SixD3GridSemA248x099822
import SixD3GridSemA248x109822
import SixD3GridSemA248x119822
import SixD3GridSemA248x129822
import SixD3GridSemA248x139822
import SixD3GridSemA248x149822
import SixD3GridSemA248x159822
import SixD3UnitA248x0009822
import SixD3UnitA248x0019822
import SixD3UnitA248x0029822
import SixD3UnitA248x0039822
import SixD3UnitA248x0049822
import SixD3UnitA248x0059822
import SixD3UnitA248x0069822
import SixD3UnitA248x0079822
import SixD3UnitA248x0089822
import SixD3UnitA248x0099822
import SixD3UnitA248x0109822
import SixD3UnitA248x0119822
import SixD3UnitA248x0129822
import SixD3UnitA248x0139822
import SixD3UnitA248x0149822
import SixD3UnitA248x0159822
import SixD3UnitA248x0169822
import SixD3UnitA248x0179822
import SixD3UnitA248x0189822
import SixD3UnitA248x0199822
import SixD3UnitA248x0209822
import SixD3UnitA248x0219822
import SixD3UnitA248x0229822
import SixD3UnitA248x0239822
import SixD3UnitA248x0249822
import SixD3UnitA248x0259822
import SixD3UnitA248x0269822
import SixD3UnitA248x0279822
import SixD3UnitA248x0289822
import SixD3UnitA248x0299822
import SixD3UnitA248x0309822
import SixD3UnitA248x0319822
import SixD3UnitA248x0329822
import SixD3UnitA248x0339822
import SixD3UnitA248x0349822
import SixD3UnitA248x0359822
import SixD3UnitA248x0369822
import SixD3UnitA248x0379822
import SixD3UnitA248x0389822
import SixD3UnitA248x0399822
namespace Research.Graph9822.ThreeDirect.A248
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 2242 (rangeAppend sem0 (rangeAppend sem1 (rangeAppend sem2 (rangeAppend sem3 (rangeAppend sem4 (rangeAppend sem5 (rangeAppend sem6 (rangeAppend sem7 (rangeAppend sem8 (rangeAppend sem9 (rangeAppend sem10 (rangeAppend sem11 (rangeAppend sem12 (rangeAppend sem13 (rangeAppend sem14 (sem15))))))))))))))))
  intro a old
  apply endKnown g 2703 (by decide +kernel) a
  apply up39 a
  apply up38 a
  apply up37 a
  apply up36 a
  apply up35 a
  apply up34 a
  apply up33 a
  apply up32 a
  apply up31 a
  apply up30 a
  apply up29 a
  apply up28 a
  apply up27 a
  apply up26 a
  apply up25 a
  apply up24 a
  apply up23 a
  apply up22 a
  apply up21 a
  apply up20 a
  apply up19 a
  apply up18 a
  apply up17 a
  apply up16 a
  apply up15 a
  apply up14 a
  apply up13 a
  apply up12 a
  apply up11 a
  apply up10 a
  apply up9 a
  apply up8 a
  apply up7 a
  apply up6 a
  apply up5 a
  apply up4 a
  apply up3 a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A248
