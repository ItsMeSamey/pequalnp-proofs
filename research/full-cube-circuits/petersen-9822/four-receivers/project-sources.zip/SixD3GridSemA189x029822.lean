import SixD3GridDataA1899822
namespace Research.Graph9822.ThreeDirect.A189
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part288 : Range (aOK d) (aCl d) g 288 312 :=
  rangeCheck _ _ _ 288 24 (by decide +kernel)
private theorem part312 : Range (aOK d) (aCl d) g 312 315 :=
  rangeCheck _ _ _ 312 3 (by decide +kernel)
theorem sem2 : Range (aOK d) (aCl d) g 288 315 := rangeAppend part288 (part312)
end Research.Graph9822.ThreeDirect.A189
