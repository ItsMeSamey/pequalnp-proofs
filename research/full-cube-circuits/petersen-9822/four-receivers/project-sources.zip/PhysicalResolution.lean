import Resolution
namespace Research.Graph9822Resolution
open PEqualNP.CircuitLowerBounds

def asGate (g : Research.Graph9822Resolution.Gate) : PEqualNP.CircuitLowerBounds.Gate :=
  ⟨if g.isAnd then .and else .or, [g.left, g.right]⟩

def asCircuit (gs : List Research.Graph9822Resolution.Gate) (out : Nat) : Circuit :=
  ⟨gs.map asGate, out⟩

def wiresFrom (xs : List Bool) : Wire := fun j => xs.getD j false

private theorem wires_snoc (xs : List Bool) (x : Bool) :
    wiresFrom (xs ++ [x]) = Function.update (wiresFrom xs) xs.length x := by
  funext j
  rcases Nat.lt_trichotomy j xs.length with h | h | h
  · rw [Function.update_of_ne (Nat.ne_of_lt h)]
    exact List.getD_append _ _ _ _ h
  · subst j
    simp [wiresFrom,List.getD_eq_getElem?_getD]
  · rw [Function.update_of_ne (Nat.ne_of_gt h)]
    unfold wiresFrom
    rw [List.getD_eq_default _ _ (show (xs ++ [x]).length ≤ j by simp; omega),List.getD_eq_default _ _ (Nat.le_of_lt h)]

private theorem asGate_step (g : Research.Graph9822Resolution.Gate) (xs : List Bool) :
    (asGate g).op.eval ((asGate g).inputs.map (fun j => xs.getD j false)) =
        step g (wiresFrom xs g.left) (wiresFrom xs g.right) := by
  cases h : g.isAnd <;> simp [asGate, h, GateOp.eval, step, wiresFrom]

theorem physical_eval (gs : List Research.Graph9822Resolution.Gate) (out : Nat) (xs : List Bool) :
    (asCircuit gs out).eval xs = eval gs xs.length (wiresFrom xs) out := by
  induction gs generalizing xs with
  | nil => rfl
  | cons g tail ih =>
    let b := step g (wiresFrom xs g.left) (wiresFrom xs g.right)
    change (asCircuit tail out).eval (xs ++ [(asGate g).op.eval ((asGate g).inputs.map _)]) = _
    rw [asGate_step, ih]
    simp only [List.length_append,List.length_cons,List.length_nil,Nat.zero_add,wires_snoc,eval]

end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.physical_eval
