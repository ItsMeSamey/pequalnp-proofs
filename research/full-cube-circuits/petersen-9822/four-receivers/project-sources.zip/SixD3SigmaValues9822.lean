import SixD3SigmaRooms9822
namespace Research.Graph9822.ThreeDirect.Sigma
open Research.Graph9822.TwoDirect (Arm rooms edge rawBit opposes)
open Research.Graph9822.TwoDirect.Symmetry (vertex legal_vertex)
theorem origin_full : ∀ s : Swap, ∀ o : Fin 24, origin s o=22 ↔ o.val=22 := by decide +kernel
theorem origin_raw : ∀ s : Swap,∀ o : Fin 24,12≤o.val → o.val<22 →
    12≤origin s o ∧ origin s o<22 ∧ vertex (origin s o-12)=o.val-12 := by decide +kernel

theorem value_image (s : Swap) (o : Nat) (bo : o<24) (ray : Nat→Bool) (raw : Nat→Arm) (helper : Arm) :
    (if origin s o=22 then true else if origin s o=23 then (arm s helper).any (fun k=>ray (lbl s k))
    else if origin s o<12 then ray (lbl s (origin s o))
    else (arm s (raw (vertex (origin s o-12)))).any (fun k=>ray (lbl s k))) =
    (if o=22 then true else if o=23 then helper.any ray
    else if o<12 then ray o else (raw (o-12)).any ray) := by
  by_cases top : o=22
  · subst o; rfl
  by_cases help : o=23
  · subst o; exact any_image _ _ _
  by_cases low : o<12
  · have is : lbl s o < 12 := label_bound s ⟨o,low⟩
    have eq : origin s o=lbl s o := by simp [origin,low]
    have nt : lbl s o≠22 := by omega
    have nh : lbl s o≠23 := by omega
    simp [eq,nt,nh,is,label_invol,top,help,low]
  · obtain ⟨lo,hi,inv⟩ := origin_raw s ⟨o,bo⟩ (show 12≤o by omega) (show o<22 by omega)
    change 12≤origin s o at lo
    change origin s o<22 at hi
    change vertex (origin s o-12)=o-12 at inv
    have nt : origin s o≠22 := by omega
    have nh : origin s o≠23 := by omega
    simp [nt,nh,Nat.not_lt.mpr lo,inv,any_image,top,help,low]

theorem ordinary_image {s src dst} (law : Spec s src dst) (p : Shared src)
    (j : Nat) (hj : j<3) (nfull : origin s (p.origin (axis s j))≠22)
    (v w : Nat) (ord : v<w) (hw : w<10)
    (ev : edge ((ds dst)[j]?.getD 10) v=true) (ew : edge ((ds dst)[j]?.getD 10) w=true)
    (lv : (arm s (p.raw (vertex v))).length=2) : (arm s (p.raw (vertex w))).length≠2 := by
  intro lw
  let J : Fin 3 := ⟨j,hj⟩
  let i : Fin 10 := ⟨v,by omega⟩
  let k : Fin 10 := ⟨w,hw⟩
  let root : Fin 10 := ⟨_,law.bounded J⟩
  have ee (u : Fin 10) (a : edge root.val u.val=true) :
      edge ((ds src)[axis s j]?.getD 10) (vertex u.val)=true := by
    rw [← law.root J]
    exact (edge_image root u).trans a
  have bo := law.origBound ⟨_,small_axis s ⟨j,by omega⟩⟩ _ (p.named _ (small_axis s ⟨j,by omega⟩))
  have forbidden := p.ordinaryNeighbor (axis s j) (root_axis s J)
    (fun h=>nfull ((origin_full s ⟨_,bo⟩).2 h))
  rw [length_image] at lv lw
  by_cases lt : vertex v<vertex w
  · exact forbidden _ _ lt (legal_vertex k) (ee i ev) (ee k ew) lv lw
  · have ne := image_ne i k (by exact Nat.ne_of_lt ord)
    have rev : vertex w<vertex v := by change vertex v≠vertex w at ne; omega
    exact forbidden _ _ rev (legal_vertex i) (ee k ew) (ee i ev) lw lv

theorem absent_image {s src dst} (law : Spec s src dst) (p : Shared src) (j : Nat) (hj : j<3)
    (full : origin s (p.origin (axis s j))=22) (v : Nat) (hv : v<10) (outside : v∉ds dst)
    (e : edge v ((ds dst)[j]?.getD 10)=false) : 2*j+1 ∉ arm s (p.raw (vertex v)) := by
  let J : Fin 3 := ⟨j,hj⟩
  let i : Fin 10 := ⟨v,hv⟩
  let root : Fin 10 := ⟨_,law.bounded J⟩
  have bo := law.origBound ⟨_,small_axis s ⟨j,by omega⟩⟩ _ (p.named _ (small_axis s ⟨j,by omega⟩))
  have h := p.fullNonneighbor _ (root_axis s J) ((origin_full s ⟨_,bo⟩).1 full) _
    (legal_vertex i) (law.outside i outside)
    (show edge (vertex v) ((ds src)[axis s j]?.getD 10)=false by
      rw [← law.root J]; exact (edge_image i root).trans e)
  intro mem
  apply h
  simpa only [(poles_image s ⟨j,by omega⟩).2] using (arm_mem s _ _).1 mem
end Research.Graph9822.ThreeDirect.Sigma
#print axioms Research.Graph9822.ThreeDirect.Sigma.ordinary_image
