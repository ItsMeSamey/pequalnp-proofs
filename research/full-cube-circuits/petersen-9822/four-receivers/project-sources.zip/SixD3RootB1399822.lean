import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B139
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (1,3,9)
private noncomputable def rules : List Nat := unpack 35 [0x200003800c00c070b880000006060201c32200000010000207000800000010]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x8018164005199800c024001ae1001222c0024ee0000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B139
