import And9822RawChamberExit
import FourSaturationData

namespace Research.Graph9822.TraceCount
open Research.Graph9822.FourSaturation

def insideTraces (P : Profile) (A : Word → Bool) :=
  (((List.finRange 64).filter (fun w => A w)).map (trace P)).eraseDups

private def insideRow (v : Fin 10) (i : Fin 8) : Nat :=
  ((witnesses.filter (fun m => !(m.testBit v.val)))[i.val]!)

private theorem insideRows : ∀ v : Fin 10, (∀ i : Fin 8,
    insideRow v i ∈ witnesses ∧ (insideRow v i).testBit v.val = false) ∧
    (∀ i j : Fin 8, (∀ u : Fin 10, (insideRow v i).testBit u.val =
      (insideRow v j).testBit u.val) → i = j) := by decide +kernel

/-- An observed raw needs eight distinct ray traces on its true chamber. -/
theorem raw_inside_eight (P : Profile) (R : Fin 10 → Word → Bool)
    (built : ∀ v, Generated P (R v))
    (realize : ∀ m ∈ witnesses, ∃ w, ∀ u : Fin 10, R u w = !(m.testBit u.val))
    (v : Fin 10) : 8 ≤ (insideTraces P (R v)).length := by
  classical
  let existsWord (i : Fin 8) := realize (insideRow v i) ((insideRows v).1 i).1
  let wit (i : Fin 8) : Word := Classical.choose (existsWord i)
  have hw (i : Fin 8) (u : Fin 10) : R u (wit i) = !((insideRow v i).testBit u.val) :=
    Classical.choose_spec (existsWord i) u
  let t (i : Fin 8) := trace P (wit i)
  have inj {i j : Fin 8} (eq : t i = t j) : i = j := by
    apply (insideRows v).2
    intro u
    have e := generated_congr P (built u) eq
    rw [hw i u, hw j u] at e
    simpa using e
  have nd : ((List.finRange 8).map t).Nodup :=
    List.pairwise_map.mpr ((List.nodup_finRange 8).imp (fun h e => h (inj e)))
  have sub : (List.finRange 8).map t ⊆ insideTraces P (R v) := by
    intro x hx
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp hx
    apply List.mem_eraseDups.mpr
    apply List.mem_map.mpr
    refine ⟨wit i,List.mem_filter.mpr ⟨List.mem_finRange _,?_⟩,rfl⟩
    simp [hw i v,((insideRows v).1 i).2]
  simpa using nd.length_le_of_subset sub


def Pinched (P : Profile) (i : Axis) : Prop :=
  NonprimitiveName P i ∧ ((outsideTraces P (activation P i)).length < 5 ∨
    (insideTraces P (activation P i)).length < 8)

instance (P : Profile) (i : Axis) : Decidable (Pinched P i) := by
  unfold Pinched NonprimitiveName
  infer_instance

theorem pinched_nonraw (P : Profile) (i : Axis) (h : Pinched P i)
    (R : Fin 10 → Word → Bool) (built : ∀ v, Generated P (R v))
    (realize : ∀ m ∈ witnesses, ∃ w, ∀ v : Fin 10, R v w = !(m.testBit v.val))
    (v : Fin 10) : R v ≠ activation P i := by
  intro eq
  rcases h.2 with small | small
  · have bound := raw_outside_five P R built realize v
    rw [eq] at bound
    omega
  · have bound := raw_inside_eight P R built realize v
    rw [eq] at bound
    omega

end Research.Graph9822.TraceCount
#print axioms Research.Graph9822.TraceCount.pinched_nonraw
