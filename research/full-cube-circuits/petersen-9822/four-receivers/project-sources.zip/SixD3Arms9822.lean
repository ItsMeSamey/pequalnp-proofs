import SixD3Roster9822
import SixD3Order9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral Research.SixH4.PairPartition
open Research.Graph9822.ThreeDirect

def normArm (r : Roots) (ts : List Lit) : List Nat := Order.sort (ts.map (code r))
def normalized (r : Roots) (L : V → List Lit) (v : Nat) : List Nat :=
  if h : v<10 then normArm r (L ⟨v,h⟩) else []
theorem arm_mem (r : Roots) (ts : List Lit) (k : Nat) :
    k ∈ normArm r ts ↔ ∃ t ∈ ts, code r t=k := by
  rw [normArm,(Order.sort_perm _).mem_iff,List.mem_map]
theorem decoded_mem (r : Roots) (ts : List Lit) (t : Lit) :
    code r t ∈ normArm r ts ↔ t ∈ ts := by
  rw [arm_mem]
  constructor
  · rintro ⟨u,hu,eq⟩
    exact (code_injective r eq) ▸ hu
  · exact fun h=>⟨t,h,rfl⟩
theorem normalized_mem (r : Roots) (L : V → List Lit) (v : V) (k : Nat) :
    k∈normalized r L v.val ↔ ∃ t∈L v, code r t=k := by
  simpa [normalized,v.isLt] using arm_mem r (L v) k

def Shape (mix : Bool) (l : List Lit) : Prop :=
  (∃ a b : Lit, a.1 ≠ b.1 ∧ l=[a,b]) ∨
  (mix=true ∧ ∃ a b c : Lit, a.1 ≠ b.1 ∧ a.1 ≠ c.1 ∧ b.1 ≠ c.1 ∧ l=[a,b,c])
theorem triple_consistent (a b c : Lit) (ab : a.1≠b.1) (ac : a.1≠c.1) (bc : b.1≠c.1) :
    consistent [a,b,c] := by
  rcases a with ⟨i,s⟩; rcases b with ⟨j,t⟩; rcases c with ⟨k,u⟩
  intro z
  simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at *
  grind
theorem shape_consistent {mix L} (h : Shape mix L) : consistent L := by
  rcases h with ⟨a,b,ab,rfl⟩|⟨_,a,b,c,ab,ac,bc,rfl⟩
  · exact pair_consistent a b ab
  · exact triple_consistent a b c ab ac bc

theorem num_allowed : ∀ k : Fin 12, k.val≠0 → k.val≠2 → k.val≠4 → k.val ∈ allowed := by decide +kernel
def goodPair (a b : Nat) := if a∈allowed ∧ b∈allowed ∧ a/2≠b/2 then
    pairs.contains (Order.sort [a,b]) else true
private theorem pairs_ok : (List.range 12).all (fun a => (List.range 12).all (goodPair a))=true := by decide +kernel
theorem sorted_pair (a b : Fin 12) (ha : a.val∈allowed) (hb : b.val∈allowed) (ne : a.val/2≠b.val/2) :
    (Order.sort [a.val,b.val]) ∈ pairs := by
  have q := List.all_eq_true.mp (List.all_eq_true.mp pairs_ok a.val (List.mem_range.mpr a.isLt))
    b.val (List.mem_range.mpr b.isLt)
  have guard : a.val∈allowed ∧ b.val∈allowed ∧ a.val/2≠b.val/2 := ⟨ha,hb,ne⟩
  exact List.contains_iff_mem.mp (by simpa only [goodPair,if_pos guard] using q)
def goodTriple (a b c : Nat) := if a∈allowed ∧ b∈allowed ∧ c∈allowed ∧ a/2≠b/2 ∧ a/2≠c/2 ∧ b/2≠c/2 then
    triples.contains (Order.sort [a,b,c]) else true
def triplesAt (a : Nat) := (List.range 12).all (fun b=>(List.range 12).all (goodTriple a b))
private theorem triple_at0 : triplesAt 0=true := by decide +kernel
private theorem triple_at1 : triplesAt 1=true := by decide +kernel
private theorem triple_at2 : triplesAt 2=true := by decide +kernel
private theorem triple_at3 : triplesAt 3=true := by decide +kernel
private theorem triple_at4 : triplesAt 4=true := by decide +kernel
private theorem triple_at5 : triplesAt 5=true := by decide +kernel
private theorem triple_at6 : triplesAt 6=true := by decide +kernel
private theorem triple_at7 : triplesAt 7=true := by decide +kernel
private theorem triple_at8 : triplesAt 8=true := by decide +kernel
private theorem triple_at9 : triplesAt 9=true := by decide +kernel
private theorem triple_at10 : triplesAt 10=true := by decide +kernel
private theorem triple_at11 : triplesAt 11=true := by decide +kernel
theorem sorted_triple (a b c : Fin 12) (ha : a.val∈allowed) (hb : b.val∈allowed) (hc : c.val∈allowed)
    (ab : a.val/2 ≠ b.val/2) (ac : a.val/2 ≠ c.val/2) (bc : b.val/2 ≠ c.val/2) :
    (Order.sort [a.val,b.val,c.val]) ∈ triples := by
  have row : triplesAt a.val=true := by
    have e := (show ∀ a : Fin 12, a=0 ∨ a=1 ∨ a=2 ∨ a=3 ∨ a=4 ∨ a=5 ∨ a=6 ∨ a=7 ∨ a=8 ∨ a=9 ∨ a=10 ∨ a=11 by decide +kernel) a
    rcases e with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact triple_at0
    · exact triple_at1
    · exact triple_at2
    · exact triple_at3
    · exact triple_at4
    · exact triple_at5
    · exact triple_at6
    · exact triple_at7
    · exact triple_at8
    · exact triple_at9
    · exact triple_at10
    · exact triple_at11
  have q := List.all_eq_true.mp (List.all_eq_true.mp row b.val (List.mem_range.mpr b.isLt))
    c.val (List.mem_range.mpr c.isLt)
  have guard : a.val∈allowed ∧ b.val∈allowed ∧ c.val∈allowed ∧ a.val/2≠b.val/2 ∧ a.val/2≠c.val/2 ∧ b.val/2≠c.val/2 := ⟨ha,hb,hc,ab,ac,bc⟩
  exact List.contains_iff_mem.mp (by simpa only [goodTriple,if_pos guard] using q)

theorem shape_selected (r : Roots) (l : List Lit) (mix : Bool) (summary : Shape mix l)
    (na : r.a ∉ l) (nb : r.b ∉ l) (nc : r.c ∉ l) :
    normArm r l ∈ pairs ++ (if mix then triples else []) := by
  obtain ⟨a0,b2,c4⟩ := code_roots r
  have ok (t) (ht : t∈l) : code r t ∈ allowed := by
    apply num_allowed ⟨_,code_bound r t⟩
    · exact fun eq => na ((code_injective r (eq.trans a0.symm)) ▸ ht)
    · exact fun eq => nb ((code_injective r (eq.trans b2.symm)) ▸ ht)
    · exact fun eq => nc ((code_injective r (eq.trans c4.symm)) ▸ ht)
  have ax (a b : Lit) (d : a.1≠b.1) : code r a / 2 ≠ code r b / 2 := by
    rw [code_axis,code_axis]
    exact fun eq => d (axisInj r eq)
  rcases summary with ⟨a,b,ab,rfl⟩|⟨hm,a,b,c,ab,ac,bc,rfl⟩
  · apply List.mem_append.mpr
    exact Or.inl (sorted_pair ⟨_,code_bound r a⟩ ⟨_,code_bound r b⟩ (ok _ (by simp)) (ok _ (by simp)) (ax _ _ ab))
  · subst mix
    apply List.mem_append.mpr
    exact Or.inr (sorted_triple ⟨_,code_bound r a⟩ ⟨_,code_bound r b⟩ ⟨_,code_bound r c⟩
      (ok _ (by simp)) (ok _ (by simp)) (ok _ (by simp)) (ax _ _ ab) (ax _ _ ac) (ax _ _ bc))
end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.shape_selected
