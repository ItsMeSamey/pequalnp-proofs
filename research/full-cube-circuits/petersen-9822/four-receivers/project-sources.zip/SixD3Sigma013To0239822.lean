import SixD3SigmaShared9822
namespace Research.Graph9822.ThreeDirect.Sigma
open Research.Graph9822.TwoDirect.Symmetry (vertex)
private theorem legal013_023at0 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 0),arm 2 t ∈ options (0,2,3) mix 0 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal013_023at1 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 1),arm 2 t ∈ options (0,2,3) mix 1 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal013_023at2 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 2),arm 2 t ∈ options (0,2,3) mix 2 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal013_023at3 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 3),arm 2 t ∈ options (0,2,3) mix 3 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal013_023at4 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 4),arm 2 t ∈ options (0,2,3) mix 4 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal013_023at5 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 5),arm 2 t ∈ options (0,2,3) mix 5 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal013_023at6 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 6),arm 2 t ∈ options (0,2,3) mix 6 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal013_023at7 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 7),arm 2 t ∈ options (0,2,3) mix 7 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal013_023at8 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 8),arm 2 t ∈ options (0,2,3) mix 8 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal013_023at9 : ∀ mix : Bool,∀ t∈options (0,1,3) mix (vertex 9),arm 2 t ∈ options (0,2,3) mix 9 := by
  intro mix; cases mix <;> decide +kernel
def spec013_023 : Spec 2 (0,1,3) (0,2,3) where
  origBound := by decide +kernel
  legal := by
    intro v
    have e := (show ∀ k : Fin 10, k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 ∨ k=8 ∨ k=9 by decide +kernel) v
    rcases e with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact legal013_023at0
    · exact legal013_023at1
    · exact legal013_023at2
    · exact legal013_023at3
    · exact legal013_023at4
    · exact legal013_023at5
    · exact legal013_023at6
    · exact legal013_023at7
    · exact legal013_023at8
    · exact legal013_023at9
  named := by decide +kernel
  root := by decide +kernel
  outside := by decide +kernel
  bounded := by decide +kernel
def rooms013_023 {mix : Bool} : Rooms (0,1,3) mix → Rooms (0,2,3) mix := roomsTransfer spec013_023
def shared013_023 : Shared (0,1,3) → Shared (0,2,3) := sharedTransfer spec013_023
end Research.Graph9822.ThreeDirect.Sigma
#print axioms Research.Graph9822.ThreeDirect.Sigma.shared013_023
