import And9822NativeBankCaller
namespace Research.Graph9822.NumericBank
open ArbitraryScan Graph9822Profiles Graph9822.StarData Banks
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p

/-- The emitter scans all six activations, erasing the full and primitive keys. -/
def fullNamed (P : Axis6 → Mask6) :=
  ((Finset.univ : Finset Axis6).image (fun i => key P (P i))).filter
    (fun x => x ≠ key P Set.univ ∧ x ∉ rayKeys P)

theorem full_named_eq {P : Axis6 → Mask6} {p : List (Axis6 × Mask6)}
    (respects : ∀ s ∈ p,s.2=P s.1)
    (occurs : ∀ i,¬Primitive P (P i) → P i ∈ p.map Prod.snd) :
    namedKeys P p=fullNamed P := by
  classical
  ext x
  constructor
  · intro h
    obtain ⟨hm,rest⟩ := Finset.mem_filter.mp h
    obtain ⟨s,hs,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hm)
    exact Finset.mem_filter.mpr ⟨Finset.mem_image.mpr
      ⟨s.1,Finset.mem_univ _,congrArg (key P) (respects s hs).symm⟩,rest⟩
  · intro h
    obtain ⟨im,nt,nr⟩ := Finset.mem_filter.mp h
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp im
    have nonprim : ¬Primitive P (P i) := by
      rintro (top|⟨a,b,eq⟩)
      · exact nt (congrArg (key P) top)
      · exact nr (Finset.mem_image.mpr ⟨(a,b),Finset.mem_univ _,congrArg (key P) eq.symm⟩)
    exact (named_keys respects _).mpr ⟨P i,occurs i nonprim,nonprim,rfl⟩

/-- Common bank in the emitter's six-axis naming convention. The representation
of the current domain box is the only per-receiver checker interface. -/
theorem full_profile_keep {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (respects : ∀ s ∈ p, s.2 = P s.1) (occurs : ∀ i,¬Primitive P (P i) → P i ∈ p.map Prod.snd)
    (R : Fin 10 → Mask6) (returned : ∀ v, R v ∈ l)
    (proper : ∀ v, ∃ q, q ∉ R v) (inc : ∀ u v, u ≠ v → ¬ R u ⊆ R v)
    (intersects : ∀ u v,u≠v → ∃ q,q∈R u ∧ q∈R v)
    (cover : ∀ u v,adj u v=true → ∀ q,q∈R u ∨ q∈R v) (budget : n≤8)
    (d : Nat) (direct : ((Finset.univ : Finset (Fin 10)).filter (fun v => RayValue P (R v))).card=d)
    (boxes : Fin 10 → List Nat) (inBox : ∀ v,indexOfKey P d (key P (R v)) ∈ boxes v) :
    ∃ bank ∈ enumerate (indexOfKey P d) (rawLibrary P d) (rayKeys P) (fullNamed P) d,
      (∀ v,indexOfKey P d (key P (R v)) ∈ bank.available) ∧
      (∀ m ∈ bank.required, ∃ v,indexOfKey P d (key P (R v))=m) ∧
      ∀ v,keep (enumerate (indexOfKey P d) (rawLibrary P d) (rayKeys P) (fullNamed P) d)
        boxes (indexOfKey P d (key P (R v)))=true := by
  rw [←full_named_eq respects occurs]
  exact from_actual_profile scan P respects R returned proper inc intersects cover budget d direct boxes inBox

end
end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.full_named_eq

#print axioms Research.Graph9822.NumericBank.full_profile_keep
