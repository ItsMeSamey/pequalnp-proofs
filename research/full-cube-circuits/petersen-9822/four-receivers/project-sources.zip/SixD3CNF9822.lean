import SixD3Projection9822
namespace Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (Arm rooms edge rawBit opposes)
inductive Atom
  | fixed (b : Bool)
  | ray (k m : Nat)
  | raw (v : Nat) (arm : Arm)
  | origin (j o : Nat)
  | helperSel (arm : Arm)
  | helperBit (m : Nat)
  | ordinary (v : Nat)
  | wordRaw (v w : Nat)
  deriving DecidableEq, Inhabited, Repr
abbrev Lit := Atom × Bool
abbrev Clause := List Lit
def pos (a : Atom) : Lit := (a,true)
def neg (a : Atom) : Lit := (a,false)
structure Env where
  raw : Nat → Arm
  ray : Nat → Nat → Bool
  helper : Arm
  origin : Nat → Nat
def envOf (p : Rooms d mix) (h : Arm) (o : Nat → Nat) : Env := ⟨p.raw,p.ray,h,o⟩
def Env.val (e : Env) : Atom → Bool
  | .fixed b => b
  | .ray k m => e.ray k m
  | .raw v t => decide (e.raw v=t)
  | .origin j o => decide (e.origin j=o)
  | .helperSel t => decide (e.helper=t)
  | .helperBit m => e.helper.any (fun k=>e.ray k m)
  | .ordinary v => decide ((e.raw v).length=2)
  | .wordRaw v w => (e.raw v).any (fun k=>e.ray k (1024+w))
def Sat (e : Env) (c : Clause) := ∃ l ∈ c, e.val l.1 = l.2
def isObs (m : Nat) := rooms.contains m || decide (1024 ≤ m ∧ m<1088)
def rawAt (v m : Nat) : Atom :=
  if m<1024 then .fixed (rawBit v m) else .wordRaw v (m-1024)
def rayAt (m : Nat) (t : Arm) : List Atom := t.map (fun k => .ray k m)
def sourceAt (o m : Nat) : Atom :=
  if o=22 then .fixed true else if o=23 then .helperBit m else if o<12 then .ray o m else rawAt (o-12) m
def wordArm (j w : Nat) := 2*j+(if w.testBit j then 1 else 0)
def activationAt (j m : Nat) : List Atom :=
  if m<1024 then [.ray (2*j) m,.ray (2*j+1) m] else [.ray (wordArm j (m-1024)) m]
structure Equation where
  guard : Atom
  xs : List Atom
  rhs : Atom
def Equation.clause (eq : Equation) : Option Atom → Clause
  | none => neg eq.guard :: neg eq.rhs :: eq.xs.map pos
  | some a => [neg eq.guard,neg a,pos eq.rhs]
def Equation.legal (eq : Equation) : Option Atom → Bool
  | none => true
  | some a => eq.xs.contains a
def Equation.Holds (e : Env) (eq : Equation) := e.val eq.guard=true → eq.xs.any e.val = e.val eq.rhs
theorem Equation.sound (e : Env) (eq : Equation) (mode : Option Atom) (h : eq.Holds e)
    (ok : eq.legal mode=true) : Sat e (eq.clause mode) := by
  by_cases gs : e.val eq.guard=true
  · have he := h gs
    cases mode with
    | none =>
      cases rhs : e.val eq.rhs with
      | false => exact ⟨neg eq.rhs,by simp [clause],rhs⟩
      | true =>
        rw [rhs] at he
        obtain ⟨a,ha,v⟩ := List.any_eq_true.mp he
        exact ⟨pos a,List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (List.mem_map.mpr ⟨a,ha,rfl⟩)),v⟩
    | some a =>
      cases v : e.val a with
      | false => exact ⟨neg a,by simp [clause],v⟩
      | true =>
        have yes : eq.xs.any e.val=true := List.any_eq_true.mpr ⟨a,List.contains_iff_mem.mp ok,v⟩
        exact ⟨pos eq.rhs,by simp [clause],he.symm.trans yes⟩
  · cases mode <;> exact ⟨neg eq.guard,List.mem_cons_self,by simpa [neg] using gs⟩
end Research.Graph9822.ThreeDirect
