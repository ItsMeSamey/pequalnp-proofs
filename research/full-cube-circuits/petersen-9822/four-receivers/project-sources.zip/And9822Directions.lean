import Resolution

namespace Research.Graph9822Resolution

/-- Keep only the choices read at AND gates, in topological order. -/
def directions (gs : List Gate) (i : Nat) (s : Wire) : List Bool :=
  match gs with
  | [] => []
  | g :: tail =>
    if g.isAnd then s i :: directions tail (i+1) s else directions tail (i+1) s

theorem directions_length (gs : List Gate) (i : Nat) (s : Wire) :
    (directions gs i s).length = gs.countP Gate.isAnd := by
  induction gs generalizing i with
  | nil => rfl
  | cons g tail ih =>
    cases h : g.isAnd <;> simp [directions,h,ih,List.countP_cons,Nat.add_comm]

theorem resolve_congr_directions (gs : List Gate) (i : Nat) (s t w : Wire)
    (he : directions gs i s = directions gs i t) :
    resolve gs i s w = resolve gs i t w := by
  induction gs generalizing i w with
  | nil => rfl
  | cons g tail ih =>
    cases h : g.isAnd with
    | false =>
      simp only [directions,h,Bool.false_eq_true,if_false] at he
      simp only [resolve,resolved,h,Bool.false_eq_true,if_false]
      exact ih _ _ he
    | true =>
      simp only [directions,h,if_true,List.cons.injEq] at he
      simp only [resolve,he.1]
      exact ih _ _ he.2

end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.resolve_congr_directions
