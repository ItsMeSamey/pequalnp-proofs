import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B067
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (0,6,7)
private noncomputable def rules : List Nat := unpack 35 [0x40b0460b901607817202c0cc2e40581585c80b0240b901603c17202c0642e40580805c800000040000000050]
private def keys : List Nat := (List.range 10).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x2001d32800b4ee003d40801351a005d4d801b556007d5e80235a20099b5000000000a] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B067
