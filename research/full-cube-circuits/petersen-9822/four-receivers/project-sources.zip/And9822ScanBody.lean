import And9822ScanGrammar
import And9822LiteralPilot
set_option maxRecDepth 100000
set_option maxHeartbeats 0

-- And9822ScanBanks 60ead2e8015fcb78dba1673082ea5c91a32ea34c70f1c8f9310aca3b8922c6f6
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822.LiteralBank Graph9822.UnionCharge Graph9822.StarData
abbrev Axis6 := Graph9822Profiles.Axis
abbrev Mask6 := Graph9822Profiles.Mask
abbrev Word6 := Graph9822Profiles.Word
def ray (P : Axis6 → Mask6) (i : Axis6) (b : Bool) := P i ∩ side i b
def value (P : Axis6 → Mask6) (w : Nat) : Mask6 :=
  {x | has w 12 ∨ ∃ i b, has w (numLit i b) ∧ x ∈ ray P i b}
def typed (w : Nat) : Prop := ∀ k, has w k → k = 12 ∨ ∃ i b, k = numLit i b
theorem numLit_lt (i : Axis6) (b : Bool) : numLit i b < 12 := by
  have := i.isLt
  cases b <;> simp only [numLit,Bool.toNat_true,Bool.toNat_false] <;> omega
theorem value_observer (P : Axis6 → Mask6) : value P (lit 12) = Set.univ := by
  apply Set.ext
  intro x
  exact ⟨fun _ => trivial,fun _ => Or.inl ((lit_has _ _).mpr rfl)⟩
theorem value_ray (P : Axis6 → Mask6) (i : Axis6) (b : Bool) :
    value P (lit (numLit i b)) = ray P i b := by
  apply Set.ext
  intro x
  constructor
  · rintro (hf | ⟨j,d,hj,hx⟩)
    · have h := (lit_has _ _).mp hf
      have := numLit_lt i b
      omega
    · obtain ⟨eq,eq'⟩ := numLit_inj ((lit_has _ _).mp hj)
      simpa [eq,eq'] using hx
  · intro hx
    exact Or.inr ⟨i,b,(lit_has _ _).mpr rfl,hx⟩
theorem value_merge (P : Axis6 → Mask6) (x y : Nat) :
    value P (merge x y) = value P x ∪ value P y := by
  apply Set.ext
  intro q
  constructor
  · rintro (hf | ⟨i,b,hk,hq⟩)
    · exact ((merge_has x y _).mp hf).elim (fun h => Or.inl (Or.inl h)) (fun h => Or.inr (Or.inl h))
    · exact ((merge_has x y _).mp hk).elim
        (fun h => Or.inl (Or.inr ⟨i,b,h,hq⟩)) (fun h => Or.inr (Or.inr ⟨i,b,h,hq⟩))
  · rintro ((h | ⟨i,b,h,hq⟩) | (h | ⟨i,b,h,hq⟩))
    · exact Or.inl ((merge_has x y _).mpr (Or.inl h))
    · exact Or.inr ⟨i,b,(merge_has x y _).mpr (Or.inl h),hq⟩
    · exact Or.inl ((merge_has x y _).mpr (Or.inr h))
    · exact Or.inr ⟨i,b,(merge_has x y _).mpr (Or.inr h),hq⟩

def Available (P : Axis6 → Mask6) (ps : Pairs) (m : Mask6) : Prop :=
  ∃ w, value P w = m ∧ typed w ∧ Built (bank ps) w

/-- The stored pair list is newest first. Every paid join names two registers
derivable in the earlier suffix, even when supports have several derivations. -/
inductive Ordered : Pairs → Prop where
  | start : Ordered []
  | issue {ps : Pairs} {x y : Nat} : Ordered ps → typed x → typed y →
      Built (bank ps) x → Built (bank ps) y → Ordered ((x,y)::ps)

theorem all_banks {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (respects : ∀ s ∈ p, s.2 = P s.1) :
    ∃ ps : Pairs, ps.length = n ∧ Ordered ps ∧ ∀ m ∈ l, Available P ps m := by
  induction scan with
  | start =>
    refine ⟨[],rfl,Ordered.start,?_⟩
    intro m hm
    have e : m = Set.univ := by simpa using hm
    exact ⟨lit 12,(value_observer P).trans e.symm,
      fun k hk => Or.inl ((lit_has _ _).mp hk).symm,lit_built _ _⟩
  | join h hx hy ih =>
    obtain ⟨ps,hn,ord,old⟩ := ih respects
    obtain ⟨x,ex,tx,bx⟩ := old _ hx
    obtain ⟨y,ey,ty,by'⟩ := old _ hy
    refine ⟨(x,y)::ps,by simp [hn],Ordered.issue ord tx ty bx by',?_⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl | hm
    · exact ⟨merge x y,by rw [value_merge,ex,ey],
        fun k hk => ((merge_has x y _).mp hk).elim (tx k) (ty k),join_built _ bx by'⟩
    · obtain ⟨w,eq,tw,bw⟩ := old _ hm
      exact ⟨w,eq,tw,weaken _ _ bw⟩
  | @split b l p n u i h hu ih =>
    obtain ⟨ps,hn,ord,old⟩ := ih (fun s hs => respects s (List.mem_cons_of_mem _ hs))
    have eu : u = P i := respects (i,u) (by simp)
    have one (s : Bool) : Available P ps (u ∩ side i s) := by
      refine ⟨lit (numLit i s),by simpa [eu,ray] using value_ray P i s,?_,lit_built _ _⟩
      exact fun k h => Or.inr ⟨i,s,((lit_has _ _).mp h).symm⟩
    refine ⟨ps,hn,ord,?_⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl | hm
    · exact one _
    rcases List.mem_cons.mp hm with rfl | hm
    · exact one _
    · exact old _ hm

theorem excludes_observer {P : Axis6 → Mask6} {w : Nat}
    (miss : ∃ q, q ∉ value P w) : ¬ has w 12 := by
  obtain ⟨q,hq⟩ := miss
  exact fun hw => hq (Or.inl hw)

theorem outside_label {P : Axis6 → Mask6} {x y : Nat}
    (h : ¬ value P x ⊆ value P y) : ∃ l, has x l ∧ ¬ has y l := by
  classical
  apply Classical.byContradiction
  intro neg
  have all (k : Nat) (hx : has x k) : has y k :=
    Classical.byContradiction (fun hy => neg ⟨k,hx,hy⟩)
  apply h
  intro q hq
  rcases hq with obs | ⟨i,b,member,rayHit⟩
  · exact Or.inl (all 12 obs)
  · exact Or.inr ⟨i,b,all _ member,rayHit⟩

/-- Every activation precursor appeared in the register list and remains
represented in the same paid bank as all the receivers. -/
theorem precursors {b l p n} (scan : Scan b l p n) :
    ∀ s ∈ p, s.2 ∈ l := by
  induction scan with
  | start => simp
  | join _ _ _ ih =>
    intro s hs
    exact List.mem_cons_of_mem _ (ih _ hs)
  | split _ hu ih =>
    intro s hs
    rcases List.mem_cons.mp hs with rfl | hs
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hu)
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (ih _ hs))

theorem bank_and_precursors {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (respects : ∀ s ∈ p, s.2 = P s.1) :
    ∃ ps : Pairs, ps.length = n ∧ Ordered ps ∧ (∀ m ∈ l, Available P ps m) ∧
      ∀ s ∈ p, Available P ps s.2 := by
  obtain ⟨ps,hn,ord,old⟩ := all_banks scan P respects
  exact ⟨ps,hn,ord,old,fun s hs => old _ (precursors scan s hs)⟩

end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.bank_and_precursors

-- And9822ScanFull 0887fcface29cc97009bcddbd9bf285080b6442fd6914db40356c37c0199a7cd

namespace Research.Graph9822.FullScan
open Graph9822Profiles Graph9822.LiteralBank Graph9822.UnionCharge Graph9822.StarData

def sem (w : Nat) : Graph9822Profiles.Mask :=
  {p | ∃ a : Graph9822Profiles.Axis, has w (numLit a (p a))}
def Typed (w : Nat) := ∀ k, has w k → ∃ a b, k = numLit a b

theorem sem_lit (a : Graph9822Profiles.Axis) (b : Bool) :
    sem (lit (numLit a b)) = side a b := by
  apply Set.ext
  intro p
  constructor
  · rintro ⟨i,h⟩
    have eq := numLit_inj ((lit_has _ _).mp h)
    rcases eq with ⟨rfl,e⟩
    exact e.symm
  · intro h
    exact ⟨a,(lit_has _ _).mpr (by change p a = b at h; rw [h])⟩

theorem typed_lit (a : Graph9822Profiles.Axis) (b : Bool) : Typed (lit (numLit a b)) :=
  fun k h => ⟨a,b,((lit_has _ _).mp h).symm⟩
theorem sem_merge (x y : Nat) : sem (merge x y) = sem x ∪ sem y := by
  apply Set.ext
  intro p
  constructor
  · rintro ⟨i,h⟩
    rcases (merge_has x y _).mp h with h | h
    · exact Or.inl ⟨i,h⟩
    · exact Or.inr ⟨i,h⟩
  · rintro (⟨i,h⟩ | ⟨i,h⟩)
    · exact ⟨i,(merge_has x y _).mpr (Or.inl h)⟩
    · exact ⟨i,(merge_has x y _).mpr (Or.inr h)⟩
theorem typed_merge {x y} (hx : Typed x) (hy : Typed y) : Typed (merge x y) := by
  intro k h
  exact ((merge_has x y k).mp h).elim (hx k) (hy k)

def observer := merge (lit (numLit 0 false)) (lit (numLit 0 true))
theorem sem_observer : sem observer = Set.univ := by
  rw [observer,sem_merge,sem_lit,sem_lit]
  apply Set.ext
  intro p
  change ((p 0 = false ∨ p 0 = true) ↔ True)
  cases p 0 <;> simp

def Available (ps : Pairs) (m : Graph9822Profiles.Mask) : Prop :=
  ∃ w, sem w = m ∧ Typed w ∧ (m = Set.univ ∨ Built (bank ps) w)

theorem available_weaken (p : Nat × Nat) {ps : Pairs} {m} (h : Available ps m) : Available (p::ps) m := by
  obtain ⟨w,he,ht,full | hb⟩ := h
  · exact ⟨w,he,ht,Or.inl full⟩
  · exact ⟨w,he,ht,Or.inr (weaken _ _ hb)⟩

theorem scans {b l p n} (h : Scan b l p n)
    (full : ∀ s ∈ p, s.2 = Set.univ) :
    ∃ ps : Pairs, ps.length = n ∧ ∀ m ∈ l, Available ps m := by
  induction h with
  | start =>
    refine ⟨[],rfl,?_⟩
    intro m hm
    have e : m = Set.univ := by simpa using hm
    subst m
    exact ⟨observer,sem_observer,typed_merge (typed_lit _ _) (typed_lit _ _),Or.inl rfl⟩
  | join h hx hy ih =>
    obtain ⟨ps,hn,old⟩ := ih full
    obtain ⟨x,ex,tx,bx⟩ := old _ hx
    obtain ⟨y,ey,ty,by'⟩ := old _ hy
    refine ⟨(x,y)::ps,by simp [hn],?_⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl | hm
    · refine ⟨merge x y,by rw [sem_merge,ex,ey],typed_merge tx ty,?_⟩
      rcases bx with hf | hx'
      · exact Or.inl (by simp [hf])
      rcases by' with hf | hy'
      · exact Or.inl (by simp [hf])
      exact Or.inr (join_built _ hx' hy')
    · exact available_weaken _ (old _ hm)
  | @split b l p n u i h hu ih =>
    obtain ⟨ps,hn,old⟩ := ih (fun s hs => full s (List.mem_cons_of_mem _ hs))
    have eu : u = Set.univ := full (i,u) (by simp)
    have ray (s : Bool) : Available ps (u ∩ side i s) := by
      refine ⟨lit (numLit i s),by simp [eu,sem_lit],typed_lit i s,Or.inr (lit_built _ _)⟩
    refine ⟨ps,hn,?_⟩
    intro m hm
    rcases List.mem_cons.mp hm with rfl | hm
    · exact ray _
    rcases List.mem_cons.mp hm with rfl | hm
    · exact ray _
    · exact old _ hm

theorem no_all_full_scan {b l p n} (scan : Scan b l p n)
    (full : ∀ s ∈ p, s.2 = Set.univ)
    (raw : Fin 10 → Graph9822Profiles.Mask) (issued : ∀ v, raw v ∈ l)
    (proper : ∀ v, ∃ word, word ∉ raw v)
    (graph : ∀ u v, adj u v = true ↔ ∀ word, word ∈ raw u ∨ word ∈ raw v)
    (budget : n ≤ 8) : False := by
  classical
  obtain ⟨ps,hcost,available⟩ := scans scan full
  choose w eq typed mode using fun v => available (raw v) (issued v)
  have built (v) : Built (bank ps) (w v) := by
    rcases mode v with top | h
    · obtain ⟨q,no⟩ := proper v
      exact False.elim (no (by simp [top]))
    · exact h
  apply all_full_exclusion (bank ps) w built typed
  · intro v
    obtain ⟨q,hq⟩ := proper v
    refine ⟨q,?_⟩
    change q ∉ sem (w v)
    rw [eq]
    exact hq
  · intro u v
    change adj u v = true ↔ ∀ q, q ∈ sem (w u) ∨ q ∈ sem (w v)
    rw [eq,eq]
    exact graph u v
  · omega

end Research.Graph9822.FullScan
#print axioms Research.Graph9822.FullScan.scans

