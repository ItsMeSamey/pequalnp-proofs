import SixD3GridSemA246x009822
import SixD3GridSemA246x019822
import SixD3GridSemA246x029822
import SixD3GridSemA246x039822
import SixD3GridSemA246x049822
import SixD3GridSemA246x059822
import SixD3GridSemA246x069822
import SixD3GridSemA246x079822
import SixD3GridSemA246x089822
import SixD3GridSemA246x099822
import SixD3GridSemA246x109822
import SixD3UnitA246x0009822
import SixD3UnitA246x0019822
import SixD3UnitA246x0029822
import SixD3UnitA246x0039822
import SixD3UnitA246x0049822
import SixD3UnitA246x0059822
import SixD3UnitA246x0069822
import SixD3UnitA246x0079822
import SixD3UnitA246x0089822
import SixD3UnitA246x0099822
import SixD3UnitA246x0109822
import SixD3UnitA246x0119822
import SixD3UnitA246x0129822
import SixD3UnitA246x0139822
import SixD3UnitA246x0149822
import SixD3UnitA246x0159822
import SixD3UnitA246x0169822
import SixD3UnitA246x0179822
import SixD3UnitA246x0189822
namespace Research.Graph9822.ThreeDirect.A246
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 1529 (rangeAppend sem0 (rangeAppend sem1 (rangeAppend sem2 (rangeAppend sem3 (rangeAppend sem4 (rangeAppend sem5 (rangeAppend sem6 (rangeAppend sem7 (rangeAppend sem8 (rangeAppend sem9 (sem10)))))))))))
  intro a old
  apply endKnown g 1727 (by decide +kernel) a
  apply up18 a
  apply up17 a
  apply up16 a
  apply up15 a
  apply up14 a
  apply up13 a
  apply up12 a
  apply up11 a
  apply up10 a
  apply up9 a
  apply up8 a
  apply up7 a
  apply up6 a
  apply up5 a
  apply up4 a
  apply up3 a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A246
