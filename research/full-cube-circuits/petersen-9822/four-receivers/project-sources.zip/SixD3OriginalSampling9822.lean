import SixD3Projection9822
import SixH4D2ProjectionRows9822
namespace Research.Graph9822.ThreeDirect
open Research.Graph9822Profiles PEqualNP.Outside.L_meta_9822.Receivers
open Research.Graph9822.TwoDirect (Arm rooms edge rawBit opposes)
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
def reports (A : Nat→Mask) (q : Nat→Word) (k m : Nat) := decide (q m∈A k)

theorem sample_original {R : Fin 10→Mask} (exact : ExactReceivers (fun v w=>w∈R v))
    (cube : Nat→Word) : ∃ q : Nat→Word,
    (∀ m∈rooms,∀ v : Fin 10,q m∈R v ↔ rawBit v.val m=true) ∧
    (∀ w,q (1024+w)=cube w) := by
  classical
  obtain ⟨mis,hmis⟩ := TwoDirect.projection_sample exact
  have bounded : ∀ m∈rooms,m<1024 := by
    intro m hm
    exact of_decide_eq_true (List.all_eq_true.mp
      (show rooms.all (fun n=>decide (n<1024))=true by decide +kernel) m hm)
  let q (m : Nat) := if m<1024 then mis m else cube (m-1024)
  refine ⟨q,fun m hm v=>by simpa [q,bounded m hm] using hmis m hm v,?_⟩
  intro w
  simp [q,show ¬1024+w<1024 by omega]

theorem reports_arm (A : Nat→Mask) (q : Nat→Word) (arm : Arm) (m : Nat) :
    arm.any (fun k=>reports A q k m)=true ↔ ∃ k∈arm,q m∈A k := by
  simp [reports,List.any_eq_true]

def rooms_of_masks {d : Dir} {mix : Bool} {R : Fin 10→Mask} (A : Nat→Mask)
    (q : Nat→Word) (raw : Nat→Arm)
    (read : ∀ m∈rooms,∀ v : Fin 10,q m∈R v ↔ rawBit v.val m=true)
    (meaning : ∀ v : Fin 10,∀ w,w∈R v ↔ ∃ k∈raw v.val,w∈A k)
    (sel : ∀ v,v<10 → raw v∈options d mix v)
    (opp : ∀ u v,u<v → v<10 → edge u v=true → opposes (raw u) (raw v)=true)
    (dis : ∀ j,j<6 → ∀ w,w∈A (2*j) → w∉A (2*j+1)) : Rooms d mix where
  ray := reports A q
  raw := raw
  selected := sel
  opposed := opp
  rawRows := fun v hv m hm=>Bool.eq_iff_iff.mpr ((reports_arm A q _ m).trans
    ((meaning ⟨v,hv⟩ (q m)).symm.trans (read m hm ⟨v,hv⟩)))
  disjoint := by
    intro j hj m _
    have h := dis j hj (q m)
    by_cases l : q m∈A (2*j) <;> simp_all [reports]

theorem shared_of_masks {d : Dir} {R : Fin 10→Mask} (A : Nat→Mask)
    (raw : Nat→Arm) (H : Arm) (o : Nat→Nat) (cube : Nat→Word)
    (exact : ExactReceivers (fun v w=>w∈R v))
    (meaning : ∀ v : Fin 10,∀ w,w∈R v ↔ ∃ k∈raw v.val,w∈A k)
    (sel : ∀ v,v<10 → raw v∈options d true v)
    (opp : ∀ u v,u<v → v<10 → edge u v=true → opposes (raw u) (raw v)=true)
    (dis : ∀ j,j<6 → ∀ w,w∈A (2*j) → w∉A (2*j+1))
    (hOK : H∈pairs) (link : ∀ v,v<10 → (raw v).length=3 → ∀ k∈H,k∈raw v)
    (name : ∀ j,j<6 → o j∈originChoices d j)
    (act : ∀ j,j<6 → ∀ w,(w∈A (2*j) ∨ w∈A (2*j+1)) ↔
      if o j=22 then True else if o j=23 then ∃ k∈H,w∈A k
      else if o j<12 then w∈A (o j) else ∃ k∈raw (o j-12),w∈A k)
    (full : ∀ j,j<3 → o j=22 → ∀ v,v<10 → v∉ds d →
      edge v ((ds d)[j]?.getD 10)=false → 2*j+1∉raw v)
    (ordinary : ∀ j,j<3 → o j≠22 → ∀ v w,v<w → w<10 →
      edge ((ds d)[j]?.getD 10) v=true → edge ((ds d)[j]?.getD 10) w=true →
      (raw v).length=2 → (raw w).length≠2)
    (wrong : ∀ w,w<64 → ∀ j,j<6 → cube w∉A (2*j+(if w.testBit j then 0 else 1)))
    (cover : ∀ u v : Fin 10,edge u.val v.val=true → ∀ w,w∈R u ∨ w∈R v) :
    Nonempty (Shared d) := by
  obtain ⟨q,read,code⟩ := sample_original exact cube
  let base := rooms_of_masks A q raw read meaning sel opp dis
  refine ⟨⟨base,H,o,hOK,link,name,?_,full,ordinary,?_,?_⟩⟩
  · intro j hj m _
    change (reports A q (2*j) m || reports A q (2*j+1) m)=_
    apply Bool.eq_iff_iff.mpr
    simp only [Bool.or_eq_true,reports,decide_eq_true_eq]
    rw [act j hj (q m)]
    by_cases t : o j=22
    · simp [t]
    simp only [t,if_false]
    by_cases h : o j=23
    · simpa [h,base,rooms_of_masks] using (reports_arm A q H m).symm
    simp only [h,if_false]
    by_cases k : o j<12
    · simp [k,base,rooms_of_masks,reports]
    · simpa [k,base,rooms_of_masks] using (reports_arm A q (raw (o j-12)) m).symm
  · intro w hw j hj
    change decide (q (1024+w)∈_)=false
    rw [code]
    exact decide_eq_false (wrong w hw j hj)
  · intro u v huv hv edgeUV w hw
    have hu : u<10 := by omega
    have hit := cover ⟨u,hu⟩ ⟨v,hv⟩ edgeUV (q (1024+w))
    apply Bool.or_eq_true_iff.mpr
    exact hit.imp (fun h=>(reports_arm A q _ _).mpr ((meaning ⟨u,hu⟩ _).mp h))
      (fun h=>(reports_arm A q _ _).mpr ((meaning ⟨v,hv⟩ _).mp h))
end
end Research.Graph9822.ThreeDirect
#print axioms Research.Graph9822.ThreeDirect.shared_of_masks
