import Mathlib.Data.Set.Basic
import Mathlib.Data.Finset.Card

namespace Research.Graph9822.CommonBank

variable {α : Type*}
abbrev Mask (α : Type*) := Set α

noncomputable section
local instance : DecidableEq (Mask α) := Classical.decEq _

def Source (base : Mask α → Prop) (grants : Finset (Mask α))
    (hs : List (Mask α)) (x : Mask α) : Prop :=
  base x ∨ x ∈ grants ∨ x ∈ hs

def PairOf (S : Mask α → Prop) (x : Mask α) : Prop :=
  ∃ a b, S a ∧ S b ∧ x = a ∪ b

inductive Helpers (base : Mask α → Prop) (grants : Finset (Mask α)) :
    List (Mask α) → Prop where
  | nil : Helpers base grants []
  | cons {h hs} : Helpers base grants hs → PairOf (Source base grants hs) h →
      Helpers base grants (h :: hs)

inductive Trace (base : Mask α → Prop) : List (Mask α) → Prop where
  | nil : Trace base []
  | cons {x xs} : Trace base xs → PairOf (fun a => base a ∨ a ∈ xs) x →
      Trace base (x :: xs)

private theorem extendSource {base : Mask α → Prop} {gr : Finset (Mask α)}
    {hs : List (Mask α)} {h x} (hx : Source base gr hs x) :
    Source base gr (h :: hs) x := by
  rcases hx with hb | hg | hh
  · exact Or.inl hb
  · exact Or.inr (Or.inl hg)
  · exact Or.inr (Or.inr (List.mem_cons_of_mem h hh))

private theorem mapPair {S T : Mask α → Prop} {x} (w : PairOf S x)
    (f : ∀ a, S a → T a) : PairOf T x := by
  obtain ⟨a,b,ha,hb,e⟩ := w
  exact ⟨a,b,f a ha,f b hb,e⟩

/-- Allocate one physical slot per distinct reserved mask. Keep other nonprimitive
slots only if they are strictly below a raw. Raw-to-raw paths cannot enter that
subbank, because distinct raw receiver values are incomparable. -/
theorem extract {base : Mask α → Prop} (raw grants : Finset (Mask α))
    (antichain : ∀ x ∈ raw, ∀ y ∈ raw, x ⊆ y → x = y)
    {xs : List (Mask α)} (tr : Trace base xs) :
    ∃ hs, Helpers base grants hs ∧ (∀ h ∈ hs, ∃ r ∈ raw, h ⊆ r) ∧
      hs.length + (xs.toFinset ∩ (raw ∪ grants)).card ≤ xs.length ∧
      (∀ x ∈ xs, (∃ r ∈ raw, x ⊆ r) →
        (Source base grants hs x ∧ x ∉ raw) ∨ (x ∈ raw ∧ PairOf (Source base grants hs) x)) := by
  classical
  induction tr with
  | nil => exact ⟨[], .nil, by simp, by simp, by simp⟩
  | @cons x xs tr built ih =>
    obtain ⟨hs,hh,sub,hc,old⟩ := ih
    let R := raw ∪ grants
    by_cases existsOld : x ∈ xs
    · refine ⟨hs,hh,sub,?_,?_⟩
      · simpa [List.toFinset_cons, Finset.insert_eq_of_mem (List.mem_toFinset.mpr existsOld)] using
          Nat.le_succ_of_le hc
      · intro z hz
        rcases List.mem_cons.mp hz with rfl | hz
        · exact old _ existsOld
        · exact old _ hz
    have count (reserve : x ∈ R) :
        ((x::xs).toFinset ∩ R).card = (xs.toFinset ∩ R).card + 1 := by
      have he : (x::xs).toFinset ∩ R = insert x (xs.toFinset ∩ R) := by
        ext a
        by_cases h : a = x <;> simp [h,reserve]
      have unm : x ∉ xs.toFinset ∩ R := by
        intro hx
        exact existsOld (List.mem_toFinset.mp (Finset.mem_inter.mp hx).1)
      rw [he, Finset.card_insert_of_notMem unm]
    have unchanged (nr : x ∉ R) :
        (x::xs).toFinset ∩ R = xs.toFinset ∩ R := by
      ext a
      by_cases h : a = x <;> simp [h,nr]
    have loose : hs.length + ((x::xs).toFinset ∩ R).card ≤ (x::xs).length := by
      by_cases reserve : x ∈ R
      · rw [count reserve]; change hs.length + ((xs.toFinset ∩ R).card+1) ≤ xs.length+1
        change hs.length + (xs.toFinset ∩ R).card ≤ xs.length at hc
        omega
      · rw [unchanged reserve]; exact Nat.le_succ_of_le hc
    by_cases useful : ∃ r ∈ raw, x ⊆ r
    · obtain ⟨r,hr,hxr⟩ := useful
      have operands : PairOf (Source base grants hs) x := by
        obtain ⟨a,b,ha,hb,eq⟩ := built
        have lift (y) (hy : base y ∨ y ∈ xs) (le : y ⊆ x) : Source base grants hs y := by
          rcases hy with h | h
          · exact Or.inl h
          · rcases old y h ⟨r,hr,Set.Subset.trans le hxr⟩ with direct | ⟨hyRaw,_⟩
            · exact direct.1
            · have yr := antichain y hyRaw r hr (Set.Subset.trans le hxr)
              have yx : y = x := Set.Subset.antisymm le (by simpa only [yr] using hxr)
              exact False.elim (existsOld (yx ▸ h))
        exact ⟨a,b,lift _ ha (by rw [eq]; exact Set.subset_union_left),lift _ hb (by rw [eq]; exact Set.subset_union_right),eq⟩
      by_cases marked : Source base grants hs x ∨ x ∈ raw
      · refine ⟨hs,hh,sub,loose,?_⟩
        intro z hz hgood
        rcases List.mem_cons.mp hz with rfl | hz
        · by_cases hrx : z ∈ raw
          · exact Or.inr ⟨hrx,operands⟩
          · exact Or.inl ⟨marked.resolve_right hrx,hrx⟩
        · exact old _ hz hgood
      · have nr : x ∉ R := by
          intro hx
          rcases Finset.mem_union.mp hx with h | h
          · exact marked (Or.inr h)
          · exact marked (Or.inl (Or.inr (Or.inl h)))
        refine ⟨x::hs,.cons hh operands,?_,?_,?_⟩
        · intro a ha
          rcases List.mem_cons.mp ha with rfl | ha
          · exact ⟨r,hr,hxr⟩
          · exact sub _ ha
        · change hs.length+1 + ((x::xs).toFinset ∩ R).card ≤ xs.length+1
          rw [unchanged nr]
          change hs.length + (xs.toFinset ∩ R).card ≤ xs.length at hc
          omega
        · intro z hz hu
          rcases List.mem_cons.mp hz with rfl | hz
          · exact Or.inl ⟨Or.inr (Or.inr (by simp)),fun h => marked (Or.inr h)⟩
          · rcases old _ hz hu with s | ⟨hr,p⟩
            · exact Or.inl ⟨extendSource s.1,s.2⟩
            · exact Or.inr ⟨hr,mapPair p (fun _ => extendSource)⟩
    · refine ⟨hs,hh,sub,loose,?_⟩
      intro z hz hgood
      rcases List.mem_cons.mp hz with rfl | hz
      · exact False.elim (useful hgood)
      · exact old _ hz hgood

/-- Expand an extracted chronological bank at the two-auxiliary-slot frontier. -/
theorem atMostTwo {base : Mask α → Prop} {grants : Finset (Mask α)}
    {hs : List (Mask α)} (built : Helpers base grants hs) (cap : hs.length ≤ 2) :
    hs = [] ∨
    (∃ h, hs = [h] ∧ PairOf (Source base grants []) h) ∨
    ∃ h₁ h₂, hs = [h₂,h₁] ∧ PairOf (Source base grants []) h₁ ∧
      PairOf (Source base grants [h₁]) h₂ := by
  cases built with
  | nil => exact Or.inl rfl
  | @cons h rest prev last =>
    cases prev with
    | nil => exact Or.inr (Or.inl ⟨h,rfl,last⟩)
    | @cons h₁ tail earlier first =>
      have lim : tail.length + 1 + 1 ≤ 2 := cap
      have emp : tail = [] := List.length_eq_zero_iff.mp (by omega)
      subst tail
      exact Or.inr (Or.inr ⟨h₁,h,rfl,first,last⟩)

end
end Research.Graph9822.CommonBank
