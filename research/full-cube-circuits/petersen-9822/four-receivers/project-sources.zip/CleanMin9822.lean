import CleanDelete9822
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

structure Reduced (n : Nat) (gs : List Gate) (o : Nat) : Prop where
  clean : CleanL n gs
  live : ∀ p, p < gs.length → o = n+p ∨ ∃ q, Reads gs q (n+p)
  noConstant : ∀ p, p < gs.length → ∀ b : Bool,
    ¬ ∀ x : Fin n → Bool, vl gs x (n+p) = b
  noAlias : ∀ p, p < gs.length → ∀ j, j < n+p →
    ¬ ∀ x : Fin n → Bool, vl gs x (n+p) = vl gs x j

  minimum : ∀ t, HasCircuitSize n (fun x => vl gs x o) t → gs.length ≤ t

theorem reducedOf {n s : Nat} {f : (Fin n → Bool) → Bool}
    (nonconst : ∃ x y, f x ≠ f y) (h : HasCircuitSize n f s) :
    ∃ gs o, Reduced n gs o ∧ gs.length ≤ s ∧ ∀ x, vl gs x o = f x := by
  classical
  have clean := clean_of n f s nonconst h
  have ex : ∃ b, HasClean n f b := ⟨s,clean⟩
  obtain ⟨gs,o,hc,hs,eval⟩ := Nat.find_spec ex
  change ∀ x, vl gs x o = f x at eval
  obtain ⟨x,y,ne⟩ := nonconst
  have varied : ∃ x y, vl gs x o ≠ vl gs y o := ⟨x,y,by simpa only [eval] using ne⟩
  have noDrop : ¬ ∃ gs' o', CleanL n gs' ∧ gs'.length+1 ≤ gs.length ∧
      ∀ x : Fin n → Bool, vl gs' x o' = vl gs x o := by
    rintro ⟨gs',o',hc',hlt,eval'⟩
    have least := Nat.find_min' ex (show HasClean n f gs'.length from
      ⟨gs',o',hc',le_rfl,fun x => (eval' x).trans (eval x)⟩)
    omega
  refine ⟨gs,o,⟨hc,?_,?_,?_,?_⟩,hs.trans (Nat.find_min' ex clean),eval⟩
  · intro p hp
    by_contra no
    push Not at no
    exact noDrop (drop_dead n gs hc o p hp no.1 no.2 varied)
  · intro p hp b heq
    obtain ⟨g,hg⟩ : ∃ g, gs[p]? = some g := ⟨gs[p],List.getElem?_eq_getElem hp⟩
    obtain ⟨pre,post,rfl,rfl⟩ := split_at gs p g hg
    apply noDrop
    apply drop_core n pre g post hc o (Sum.inl b) _ varied
    intro z
    exact ⟨trivial,(heq z).symm⟩
  · intro p hp j hj heq
    exact noDrop (drop_alias n gs hc o p j hp hj heq varied)

  · intro t ht
    have clean' := clean_of n (fun x => vl gs x o) t varied ht
    have eqf : (fun x => vl gs x o) = f := funext eval
    rw [eqf] at clean'
    exact hs.trans (Nat.find_min' ex clean')

theorem Reduced.noSmaller {n gs o} (hr : Reduced n gs o) (D : Circuit)
    (legal : FanInTwo D) (eqv : ∀ x : Fin n → Bool, D.eval (List.ofFn x) = vl gs x o) :
    gs.length ≤ D.size :=
  hr.minimum D.size ⟨D,legal,le_rfl,eqv⟩

/-- Minimize a secondary structural cost over all reduced optima for the same function. -/
theorem reducedOfTieBreak {n s : Nat} {f : (Fin n → Bool) → Bool}
    (nonconst : ∃ x y, f x ≠ f y) (h : HasCircuitSize n f s)
    (score : List Gate → Nat → Nat) :
    ∃ gs o, Reduced n gs o ∧ gs.length ≤ s ∧ (∀ x, vl gs x o = f x) ∧
      ∀ gs' o', Reduced n gs' o' → gs'.length ≤ s → (∀ x, vl gs' x o' = f x) →
        score gs o ≤ score gs' o' := by
  classical
  obtain ⟨gs,o,hr,hs,he⟩ := reducedOf nonconst h
  let eligible := fun t : Nat => ∃ (xs : List Gate) (w : Nat),
    Reduced n xs w ∧ xs.length ≤ s ∧ (∀ x, vl xs x w = f x) ∧ score xs w = t
  have ex : ∃ t, eligible t := ⟨_,gs,o,hr,hs,he,rfl⟩
  obtain ⟨ys,v,red,bound,ev,hscore⟩ := Nat.find_spec ex
  refine ⟨ys,v,red,bound,ev,?_⟩
  intro xs w hr' hs' he'
  rw [hscore]
  exact Nat.find_min' ex ⟨xs,w,hr',hs',he',rfl⟩

end PEqualNP.Outside.L_meta_9822.Clean
#print axioms PEqualNP.Outside.L_meta_9822.Clean.reducedOf
