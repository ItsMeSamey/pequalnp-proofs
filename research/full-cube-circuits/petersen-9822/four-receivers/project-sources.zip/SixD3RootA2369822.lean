import SixD3RootA0179822
import SixD3Sigma236To0179822
namespace Research.Graph9822.ThreeDirect.A236
def d : Dir := (2,3,6)
theorem closed : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact A017.closed ⟨Sigma.shared236_017 p⟩
end Research.Graph9822.ThreeDirect.A236
