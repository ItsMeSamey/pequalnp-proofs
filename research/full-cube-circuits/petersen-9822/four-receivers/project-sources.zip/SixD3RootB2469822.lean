import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B246
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (2,4,6)
private noncomputable def rules : List Nat := unpack 35 [0x200002004c012040c8800000090002010042000000101802040b8800000010]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x80183d80050a6000c65a001e6700121d00025050000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B246
