import SixD3GridSemA019x009822
import SixD3GridSemA019x019822
import SixD3UnitA019x0009822
import SixD3UnitA019x0019822
import SixD3UnitA019x0029822
import SixD3UnitA019x0039822
namespace Research.Graph9822.ThreeDirect.A019
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 183 (rangeAppend sem0 (sem1))
  intro a old
  apply endKnown g 220 (by decide +kernel) a
  apply up3 a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A019
