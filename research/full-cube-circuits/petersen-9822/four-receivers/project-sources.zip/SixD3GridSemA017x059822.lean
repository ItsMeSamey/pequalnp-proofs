import SixD3GridDataA0179822
namespace Research.Graph9822.ThreeDirect.A017
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part720 : Range (aOK d) (aCl d) g 720 744 :=
  rangeCheck _ _ _ 720 24 (by decide +kernel)
private theorem part744 : Range (aOK d) (aCl d) g 744 768 :=
  rangeCheck _ _ _ 744 24 (by decide +kernel)
private theorem part768 : Range (aOK d) (aCl d) g 768 792 :=
  rangeCheck _ _ _ 768 24 (by decide +kernel)
private theorem part792 : Range (aOK d) (aCl d) g 792 816 :=
  rangeCheck _ _ _ 792 24 (by decide +kernel)
private theorem part816 : Range (aOK d) (aCl d) g 816 840 :=
  rangeCheck _ _ _ 816 24 (by decide +kernel)
private theorem part840 : Range (aOK d) (aCl d) g 840 864 :=
  rangeCheck _ _ _ 840 24 (by decide +kernel)
theorem sem5 : Range (aOK d) (aCl d) g 720 864 := rangeAppend part720 (rangeAppend part744 (rangeAppend part768 (rangeAppend part792 (rangeAppend part816 (part840)))))
end Research.Graph9822.ThreeDirect.A017
