import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part1584 : Range (aOK d) (aCl d) g 1584 1608 :=
  rangeCheck _ _ _ 1584 24 (by decide +kernel)
private theorem part1608 : Range (aOK d) (aCl d) g 1608 1632 :=
  rangeCheck _ _ _ 1608 24 (by decide +kernel)
private theorem part1632 : Range (aOK d) (aCl d) g 1632 1656 :=
  rangeCheck _ _ _ 1632 24 (by decide +kernel)
private theorem part1656 : Range (aOK d) (aCl d) g 1656 1680 :=
  rangeCheck _ _ _ 1656 24 (by decide +kernel)
private theorem part1680 : Range (aOK d) (aCl d) g 1680 1704 :=
  rangeCheck _ _ _ 1680 24 (by decide +kernel)
private theorem part1704 : Range (aOK d) (aCl d) g 1704 1728 :=
  rangeCheck _ _ _ 1704 24 (by decide +kernel)
theorem sem11 : Range (aOK d) (aCl d) g 1584 1728 := rangeAppend part1584 (rangeAppend part1608 (rangeAppend part1632 (rangeAppend part1656 (rangeAppend part1680 (part1704)))))
end Research.Graph9822.ThreeDirect.A023
