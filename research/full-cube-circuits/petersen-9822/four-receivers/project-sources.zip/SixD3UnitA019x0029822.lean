import SixD3GridUnits9822
import SixD3GridDataA0199822
namespace Research.Graph9822.ThreeDirect.A019
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit24 : ∀ a, Known a g 207 → Known a g 208 :=
  singleKnown g 207 (unpack 28 [0x101a0000026e090010a089000e043]) (by decide +kernel)
private theorem unit25 : ∀ a, Known a g 208 → Known a g 209 :=
  singleKnown g 208 (unpack 28 [0x1020c000026e090011e089029a06e033e06b030e047]) (by decide +kernel)
private theorem unit26 : ∀ a, Known a g 209 → Known a g 210 :=
  singleKnown g 209 (unpack 28 [0x101f8000025606000860590026043]) (by decide +kernel)
private theorem unit27 : ∀ a, Known a g 210 → Known a g 211 :=
  singleKnown g 210 (unpack 28 [0x1019800002560600076059029a06a034606f02411dc0261207029c509026523f033a077034128703316ba033573b030e047024919d024511302d432902cc1e902c40a902bc2880238148022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit28 : ∀ a, Known a g 211 → Known a g 212 :=
  singleKnown g 211 (unpack 28 [0x102a400002685a8027d6f20289673024123e02a973b026d2870216091025d20702996bb020a06f02551dd01fe06101ee05502b179501de0a101ca08d019e06b0176051012208900be067008a059034a07e030e04702815c7028564d024919d024511302d833302d432902d01f302cc1e902c80b302c40a902c029202bc288023c15202381480230012022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit29 : ∀ a, Known a g 212 → Known a g 213 :=
  singleKnown g 212 (unpack 28 [0x1030000002a973b015209102996bb014a06f013e08d013606b027609c034d2e0030e047]) (by decide +kernel)
private theorem unit30 : ∀ a, Known a g 213 → Known a g 214 :=
  singleKnown g 213 (unpack 28 [0x102b400002786e8027d79402412e002a973b02a16f3026d287026523f025d20702551dd02f1673021e091021a07f02996bb021206f01ce08d01ba07b01a606b012608900f607700c60670092059020606103520a4030e04702815c7028564d024919d024511302d833302d432902d01f302cc1e902c80b302c40a902c029202bc288023c15202381480230012022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit31 : ∀ a, Known a g 214 → Known a g 215 :=
  singleKnown g 214 (unpack 28 [0x102040000292060019205d030a0a40355690030e047]) (by decide +kernel)
private theorem unit32 : ∀ a, Known a g 215 → Known a g 216 :=
  singleKnown g 215 (unpack 28 [0x1029800002fd6ba002606f000e06b030e047]) (by decide +kernel)
private theorem unit33 : ∀ a, Known a g 216 → Known a g 217 :=
  singleKnown g 216 (unpack 28 [0x101d0000024e054004e04d03591be035e043]) (by decide +kernel)
private theorem unit34 : ∀ a, Known a g 217 → Known a g 218 :=
  singleKnown g 217 (unpack 28 [0x102ec000024e04c02ea055028d67302503c803591be035e04302d432902c40a902bc288022c00802b9ca40228784]) (by decide +kernel)
private theorem unit35 : ∀ a, Known a g 218 → Known a g 219 :=
  singleKnown g 218 (unpack 28 [0x101f4000024e054006204d03591be035e043]) (by decide +kernel)
theorem up2 : ∀ a, Known a g 207 → Known a g 219 := by
  intro a h
  apply unit35 a
  apply unit34 a
  apply unit33 a
  apply unit32 a
  apply unit31 a
  apply unit30 a
  apply unit29 a
  apply unit28 a
  apply unit27 a
  apply unit26 a
  apply unit25 a
  apply unit24 a
  exact h
end Research.Graph9822.ThreeDirect.A019
