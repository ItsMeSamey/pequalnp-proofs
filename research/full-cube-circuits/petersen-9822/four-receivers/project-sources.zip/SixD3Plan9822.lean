import SixD3Collapse9822
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
abbrev Mode := Option (Tag×Tag)
inductive Plan (P : Axis→Mask) (p : List (Axis×Mask)) : List Mask → Mode → Prop where
  | clean : Plan P p [] none
  | ray {H a} (seen : Seen p P a) (val : H=value P a) : Plan P p [H] none
  | pair {H a c} (first : Seen p P a) (last : Seen p P c) (diff : a.1≠c.1)
      (val : H=value P a∪value P c) : Plan P p [H] (some (a,c))
def PlanRaw (P : Axis→Mask) (mode : Mode) (m : Mask) : Prop :=
  match mode with
  | none => DistinctPair P m
  | some (a,c) => FixedRaw P a c m
theorem plan_weaken {P p e mode} (r : Plan P p e mode) (t : Axis×Mask) : Plan P (t::p) e mode := by
  cases r with
  | clean => exact .clean
  | ray seen val => exact .ray (List.mem_cons_of_mem _ seen) val
  | pair first last diff val => exact .pair (List.mem_cons_of_mem _ first) (List.mem_cons_of_mem _ last) diff val
theorem issue_sources {N b l p e m} (run : Marked N b l p e)
    (P : Axis→Mask) (ok : ∀t∈p,t.2=P t.1)
    (anti : ∀ x∈N,∀y∈N,x⊆y → x=y) (top : Set.univ∉N) (raw : m∈N) (fresh : m∉l)
    (x : Mask) (mem : x∈l) (sub : x⊆m) : (∃ a : Tag,Seen p P a ∧ x=value P a) ∨ x∈e := by
  rcases (marked_sources run).1 _ mem with full|paid|org|spare
  · have all : m=Set.univ := Set.eq_univ_of_forall (fun q=>sub (by rw [full]; trivial))
    exact False.elim (top (all ▸ raw))
  · exact False.elim (fresh ((anti _ paid _ raw sub) ▸ mem))
  · exact Or.inl (seen_origin ok org)
  · exact Or.inr spare

theorem plan_issue {N b l p e mode x y} (run : Marked N b l p e)
    (P : Axis→Mask) (ok : ∀t∈p,t.2=P t.1) (plan : Plan P p e mode)
    (anti : ∀ x∈N,∀y∈N,x⊆y → x=y) (top : Set.univ∉N)
    (hx : x∈l) (hy : y∈l) (raw : x∪y∈N) (fresh : x∪y∉l) : PlanRaw P mode (x∪y) := by
  have sx := issue_sources run P ok anti top raw fresh x hx (fun _ h=>Or.inl h)
  have sy := issue_sources run P ok anti top raw fresh y hy (fun _ h=>Or.inr h)
  have elem {x H : Mask} {a : Tag} (one : Seen p P a) (valid : H=value P a)
      (v : (∃ z,Seen p P z ∧ x=value P z) ∨ x∈[H]) : ∃ z,Seen p P z ∧ x=value P z := by
    rcases v with yes | mem
    · exact yes
    · exact ⟨a,one,(List.mem_singleton.mp mem).trans valid⟩
  cases plan with
  | clean =>
    rcases sx with ⟨a,sa,ax⟩|miss
    · rcases sy with ⟨c,sc,cy⟩|miss
      · exact ordinary_issued run P fresh a c sa sc (by rw [ax,cy])
      · contradiction
    · contradiction
  | ray seen val =>
    obtain ⟨a,sa,ax⟩ := elem seen val sx
    obtain ⟨c,sc,cy⟩ := elem seen val sy
    exact ordinary_issued run P fresh a c sa sc (by rw [ax,cy])
  | @pair H a c first last diff val =>
    rcases sx with ⟨z,sz,zx⟩|xh
    · rcases sy with ⟨w,sw,wy⟩|yh
      · exact Or.inl (ordinary_issued run P fresh z w sz sw (by rw [zx,wy]))
      · have eqy := List.mem_singleton.mp yh
        exact clean_extra_union run P ok anti top raw fresh a c z first last val (by rw [zx,eqy,Set.union_comm])
    · have eqx := List.mem_singleton.mp xh
      rcases sy with ⟨z,sz,zy⟩|yh
      · exact clean_extra_union run P ok anti top raw fresh a c z first last val (by rw [eqx,zy])
      · have same : x=y := eqx.trans (List.mem_singleton.mp yh).symm
        exact False.elim (fresh (by simpa [same] using hy))
end Research.Graph9822Profiles.Fresh
