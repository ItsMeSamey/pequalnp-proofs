import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part2160 : Range (aOK d) (aCl d) g 2160 2184 :=
  rangeCheck _ _ _ 2160 24 (by decide +kernel)
private theorem part2184 : Range (aOK d) (aCl d) g 2184 2208 :=
  rangeCheck _ _ _ 2184 24 (by decide +kernel)
private theorem part2208 : Range (aOK d) (aCl d) g 2208 2232 :=
  rangeCheck _ _ _ 2208 24 (by decide +kernel)
private theorem part2232 : Range (aOK d) (aCl d) g 2232 2256 :=
  rangeCheck _ _ _ 2232 24 (by decide +kernel)
private theorem part2256 : Range (aOK d) (aCl d) g 2256 2280 :=
  rangeCheck _ _ _ 2256 24 (by decide +kernel)
private theorem part2280 : Range (aOK d) (aCl d) g 2280 2304 :=
  rangeCheck _ _ _ 2280 24 (by decide +kernel)
theorem sem15 : Range (aOK d) (aCl d) g 2160 2304 := rangeAppend part2160 (rangeAppend part2184 (rangeAppend part2208 (rangeAppend part2232 (rangeAppend part2256 (part2280)))))
end Research.Graph9822.ThreeDirect.A023
