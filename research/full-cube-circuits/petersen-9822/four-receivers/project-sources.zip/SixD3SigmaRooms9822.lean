import SixD3SigmaData9822
namespace Research.Graph9822.ThreeDirect.Sigma
open Research.Graph9822.TwoDirect (Arm rooms edge rawBit opposes)
open Research.Graph9822.TwoDirect.Symmetry (vertex row_maps legal_vertex)
theorem arm_mem (s : Swap) (a : Arm) (k : Nat) : k∈arm s a ↔ lbl s k∈a := by
  rw [arm,(Research.SixD3.Order.sort_perm _).mem_iff,List.mem_map]
  constructor
  · rintro ⟨x,hx,rfl⟩; simpa [label_invol] using hx
  · exact fun h=>⟨lbl s k,h,label_invol s k⟩
theorem any_image (s : Swap) (a : Arm) (f : Nat→Bool) :
    (arm s a).any (fun k=>f (lbl s k))=a.any f := by
  apply Bool.eq_iff_iff.mpr
  simp only [List.any_eq_true]
  constructor
  · rintro ⟨k,hk,yes⟩; exact ⟨_,(arm_mem s a k).1 hk,yes⟩
  · rintro ⟨k,hk,yes⟩
    exact ⟨lbl s k,(arm_mem s a _).2 (by simpa [label_invol] using hk),by simpa [label_invol] using yes⟩
theorem length_image (s : Swap) (a : Arm) : (arm s a).length=a.length := by simp [arm]
theorem opposite_symm {a b : Arm} (op : opposes a b=true) : opposes b a=true := by
  obtain ⟨k,hk,other⟩ := List.any_eq_true.mp op
  refine List.any_eq_true.mpr ⟨k ^^^ 1,List.contains_iff_mem.mp other,?_⟩
  apply List.contains_iff_mem.mpr
  simpa [Nat.xor_assoc] using hk
theorem opposite_image (s : Swap) (a b : Arm) (bound : ∀k∈a,k<12) (op : opposes a b=true) :
    opposes (arm s a) (arm s b)=true := by
  obtain ⟨k,hk,other⟩ := List.any_eq_true.mp op
  refine List.any_eq_true.mpr ⟨lbl s k,(arm_mem s a _).2 (by simpa [label_invol] using hk),?_⟩
  apply List.contains_iff_mem.mpr
  apply (arm_mem s b _).2
  rw [← label_xor s ⟨k,bound k hk⟩,label_invol]
  exact List.contains_iff_mem.mp other

theorem image_ne (i j : Fin 10) (ne : i.val≠j.val) : vertex i.val≠vertex j.val := by
  intro eq
  apply ne
  simpa only [vertex_invol] using congrArg vertex eq

def roomsTransfer {s src dst} (law : Spec s src dst) {mix : Bool} (p : Rooms src mix) : Rooms dst mix where
  raw v := arm s (p.raw (vertex v))
  ray k m := p.ray (lbl s k) (obsMap s m)
  selected v hv := law.legal ⟨v,hv⟩ mix _ (p.selected _ (legal_vertex ⟨v,hv⟩))
  rawRows v hv m hm := by
    rw [any_image s _ (fun k=>p.ray k (obsMap s m)),obs_room s hm,p.rawRows _ (legal_vertex ⟨v,hv⟩) _ (row_maps m hm).1]
    exact (row_maps m hm).2 ⟨v,hv⟩
  opposed u v lt hv e := by
    let i : Fin 10 := ⟨u,by omega⟩
    let j : Fin 10 := ⟨v,hv⟩
    apply opposite_image _ _ _ (original_bounds (p.selected _ (legal_vertex i)))
    by_cases h : vertex u<vertex v
    · exact p.opposed _ _ h (legal_vertex j) ((edge_image i j).trans e)
    · have ne := image_ne i j (by exact Nat.ne_of_lt lt)
      have rev : vertex v<vertex u := by change vertex u≠vertex v at ne; omega
      have et := (Research.Graph9822.TwoDirect.Symmetry.edge_transfer i j lt e)
      rcases et with ⟨bad,_⟩|⟨_,ee⟩
      · exact False.elim (h bad)
      · exact opposite_symm (p.opposed _ _ rev (legal_vertex i) ee)
  disjoint j hj m hm := by
    rw [(poles_image s ⟨j,hj⟩).1,(poles_image s ⟨j,hj⟩).2,obs_room s hm]
    exact p.disjoint _ (small_axis s ⟨j,hj⟩) _ (row_maps m hm).1
end Research.Graph9822.ThreeDirect.Sigma
#print axioms Research.Graph9822.ThreeDirect.Sigma.roomsTransfer
