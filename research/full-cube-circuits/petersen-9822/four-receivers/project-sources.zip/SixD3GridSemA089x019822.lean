import SixD3GridDataA0899822
namespace Research.Graph9822.ThreeDirect.A089
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part144 : Range (aOK d) (aCl d) g 144 168 :=
  rangeCheck _ _ _ 144 24 (by decide +kernel)
private theorem part168 : Range (aOK d) (aCl d) g 168 192 :=
  rangeCheck _ _ _ 168 24 (by decide +kernel)
private theorem part192 : Range (aOK d) (aCl d) g 192 216 :=
  rangeCheck _ _ _ 192 24 (by decide +kernel)
private theorem part216 : Range (aOK d) (aCl d) g 216 228 :=
  rangeCheck _ _ _ 216 12 (by decide +kernel)
theorem sem1 : Range (aOK d) (aCl d) g 144 228 := rangeAppend part144 (rangeAppend part168 (rangeAppend part192 (part216)))
end Research.Graph9822.ThreeDirect.A089
