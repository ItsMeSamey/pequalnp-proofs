import SixD3GridDataA1599822
namespace Research.Graph9822.ThreeDirect.A159
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part144 : Range (aOK d) (aCl d) g 144 168 :=
  rangeCheck _ _ _ 144 24 (by decide +kernel)
private theorem part168 : Range (aOK d) (aCl d) g 168 181 :=
  rangeCheck _ _ _ 168 13 (by decide +kernel)
theorem sem1 : Range (aOK d) (aCl d) g 144 181 := rangeAppend part144 (part168)
end Research.Graph9822.ThreeDirect.A159
