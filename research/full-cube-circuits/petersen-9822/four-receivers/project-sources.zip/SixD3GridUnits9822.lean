import SixD3Grid9822
namespace Research.Graph9822.ThreeDirect.Packed
open PEqualNP.Library.LRAT
noncomputable def units (g : Grid) (lim : Nat) (xs : List Nat) (f : Nat) : Bool :=
  xs.rec (motive := fun _ => Nat → Bool) (fun _ => false) (fun z _ next f =>
    let i := z >>> 14
    let x := z % 16384
    let m := mask (stored g i)
    let u := Nat.xor m (Nat.land m f)
    decide (i<lim) && (if x=0 then u==0 else (u==(Nat.shiftLeft 1 x)) && next (setBit f (PEqualNP.Library.LRAT.neg x)))) f

theorem units_false {a g lim xs f} (old : Known a g lim) (hf : BitsFalse a f)
    (h : units g lim xs f=true) : False := by
  induction xs generalizing f with
  | nil => simp [units] at h
  | cons z zs ih =>
    let i := z >>> 14
    let x := z % 16384
    let m := mask (stored g i)
    let u := Nat.xor m (Nat.land m f)
    change (decide (i<lim) && (if x=0 then u==0 else (u==(Nat.shiftLeft 1 x)) &&
      units g lim zs (setBit f (PEqualNP.Library.LRAT.neg x))))=true at h
    obtain ⟨hi,h⟩ := Bool.and_eq_true_iff.mp h
    obtain ⟨w,hw,hv⟩ := witness_U a hf (maskSat_of_clauseSat a (old i (of_decide_eq_true hi)))
    change bit u w=true at hw
    split at h
    · have eq : u=0 := by simpa using h
      simp [eq,bit_zero] at hw
    · obtain ⟨eq,rest⟩ := Bool.and_eq_true_iff.mp h
      have eq' : u=(Nat.shiftLeft 1 x) := by simpa using eq
      rw [eq',bit_pow,decide_eq_true_eq] at hw
      subst w
      apply ih _ rest
      intro l hl
      rw [bit_setBit,Bool.or_eq_true,decide_eq_true_eq] at hl
      rcases hl with known | rfl
      · exact hf l known
      · rw [litVal_neg,hv]; rfl

theorem singleKnown (g : Grid) (n : Nat) (ts : List Nat)
    (h : units g n ts (mask (stored g n))=true) :
    ∀ a, Known a g n → Known a g (n+1) := by
  intro a old i hi
  by_cases p : i<n
  · exact old i p
  · have e : i=n := by omega
    subst i
    apply Classical.byContradiction
    intro bad
    apply units_false old _ h
    intro l hl
    have mem := (bit_mask _ _).mp hl
    cases hv : litVal a l
    · rfl
    · exact False.elim (bad ⟨l,mem,hv⟩)

theorem endKnown (g : Grid) (n : Nat) (empty : stored g n=[]) :
    ∀ a, Known a g (n+1) → False := by
  intro a old
  obtain ⟨l,hl,_⟩ := old n (by omega)
  simp [empty] at hl
end Research.Graph9822.ThreeDirect.Packed
