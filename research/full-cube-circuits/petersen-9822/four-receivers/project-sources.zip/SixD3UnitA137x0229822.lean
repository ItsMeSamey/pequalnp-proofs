import SixD3GridUnits9822
import SixD3GridDataA1379822
namespace Research.Graph9822.ThreeDirect.A137
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit260 : ∀ a, Known a g 2651 → Known a g 2652 :=
  singleKnown g 2651 (unpack 28 [0x1295c0000b855750abd4a90a6d49b032a0ad030208102fa0a502f207f02e605528ba047268207b]) (by decide +kernel)
private theorem unit261 : ∀ a, Known a g 2652 → Known a g 2653 :=
  singleKnown g 2652 (unpack 28 [0x10ba00000d757c50bd95f70b9c6ff0b985bf292d7050ba55b50ba95c30bf564d251833324fc1f324e40bf24dc0b30d8c2920898152085c01e08540120d797f40888e9008449dc]) (by decide +kernel)
private theorem unit262 : ∀ a, Known a g 2653 → Known a g 2654 :=
  singleKnown g 2653 (unpack 28 [0x10ba00000d617c50bd95f706ce0ad035609d0a745bf0a6e07e295d49a297157529694a90d4d76b296e08925405a518ed61d189d60917fd5e717455cd1ba97911a2d7830dcc504294e077292d70528ba047268207b25ea0990ba55b50ba95c30bf564d251833324fc1f324f01e524e40bf24dc0b30d8c2920898152088c144085c01e08540120d797f40888e9008449dc]) (by decide +kernel)
private theorem unit263 : ∀ a, Known a g 2654 → Known a g 2655 :=
  singleKnown g 2654 (unpack 28 [0x129100000b995750b7951b0acd4a90a7549b09bd3a70c845be29756ee2951497252433f24e40bf0d9829e085c01e0d797f408449dc]) (by decide +kernel)
private theorem unit264 : ∀ a, Known a g 2655 → Known a g 2656 :=
  singleKnown g 2655 (unpack 28 [0x10cb000006a6081028a077013a04d]) (by decide +kernel)
private theorem unit265 : ∀ a, Known a g 2656 → Known a g 2657 :=
  singleKnown g 2656 (unpack 28 [0x10cb000006da081028e077013e04d]) (by decide +kernel)
private theorem unit266 : ∀ a, Known a g 2657 → Known a g 2658 :=
  singleKnown g 2657 (unpack 28 [0x10b8400001720ad01420a5013a07f]) (by decide +kernel)
private theorem unit267 : ∀ a, Known a g 2658 → Known a g 2659 :=
  singleKnown g 2658 (unpack 28 [0x10b84000070a0a507860ad0cb2080298604d29115740b6d51b0a6d49b09b13a70ac54a9297e07f29820910cb85a70cb43c729796f82951497294e07728ba047268207b25ea099250c3270d802860d797f4]) (by decide +kernel)
private theorem unit268 : ∀ a, Known a g 2659 → Known a g 2660 :=
  singleKnown g 2659 (unpack 28 [0x126680001061e6b1015ddd0fd9dd11069ec50faddc30f65dbf00760ab007209700620730052071004e0a5004a091004206f003a055002a06b000e06700020430c1e03428ba047268207b]) (by decide +kernel)
private theorem unit269 : ∀ a, Known a g 2660 → Known a g 2661 :=
  singleKnown g 2660 (unpack 28 [0x10ba00000d757c50c856ef0b9c6ff0b985bf27595741c456f918715f71e6176b2989bea16d956514a953d133d53911cd3cd298d6e1096130909592af09492210925215090d20b08ed1f908c513b25405a5294e07718ed61d189d60917fd5e717455cd1ba97911a2d7830dcc5040dca31c292d7050ba55b50ba95c30bf564d252433f251833324fc1f324f01e524e40bf24dc0b30d9829e0d8c2920898152088c144085c01e08540120d797f40888e9008449dc]) (by decide +kernel)
private theorem unit270 : ∀ a, Known a g 2661 → Known a g 2662 :=
  singleKnown g 2661 (unpack 28 [0x105540000e4e08c107207e28ba04725ea099]) (by decide +kernel)
private theorem unit271 : ∀ a, Known a g 2662 → Known a g 2663 :=
  singleKnown g 2662 (unpack 28 [0x10c3c00005a20a1035a09d004a035299609027d9e7a2241e09224de150ba17821c456f90be16090e506531e6176b17715cd181d5e7292d7050ba55b50ba95c30bf564d251833324fc1f324dc0b30d8c292089815208540120d797f40888e9008449dc]) (by decide +kernel)
theorem up22 : ∀ a, Known a g 2651 → Known a g 2663 := by
  intro a h
  apply unit271 a
  apply unit270 a
  apply unit269 a
  apply unit268 a
  apply unit267 a
  apply unit266 a
  apply unit265 a
  apply unit264 a
  apply unit263 a
  apply unit262 a
  apply unit261 a
  apply unit260 a
  exact h
end Research.Graph9822.ThreeDirect.A137
