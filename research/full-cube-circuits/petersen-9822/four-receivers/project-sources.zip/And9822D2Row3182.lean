import And9822ConditionedTrace

namespace Research.Graph9822.TraceCount
open Research.Graph9822.FourSaturation

/-- The no-grant structural hypothesis supplied by the two-direct accounting
is sufficient; no special assumption about which vertex owns the last name. -/
theorem exclude3182_d2 (R : Fin 10 → Word → Bool)
    (built : ∀ v, Generated profile3182 (R v))
    (realize : ∀ m ∈ witnesses, ∃ w, ∀ u : Fin 10, R u w = !(m.testBit u.val))
    (allNamesRaw : ∀ i : Axis,
      (∃ w : Word, (profile3182 i).testBit w.val = false) →
      (∀ j : Axis, ∀ b : Bool, ∃ w : Word,
        (profile3182 i).testBit w.val ≠ branch profile3182 j b w) →
      ∃ v, R v = fun w => (profile3182 i).testBit w.val) : False :=
  row3182_no_raw R built realize
    (allNamesRaw 5 last3182_nonprimitive.1 last3182_nonprimitive.2)

end Research.Graph9822.TraceCount
#print axioms Research.Graph9822.TraceCount.exclude3182_d2
