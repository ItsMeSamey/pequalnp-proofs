import SixD3RawArms9822
import SixD3Selection9822
namespace Research.Graph9822.ArbitraryScan
open Research.Graph9822Profiles Research.SixD3.Labels Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (edge opposes)
open Research.SixH4.DirectLiteral (receives adj_code)
open Research.SixH4.PairPartition (adj)
open Research.Graph9822Resolution PEqualNP.Outside.L_meta_9822.Receivers
theorem select_physical {P : Axis→Mask} {R : Fin 10→Mask} {d : ThreeRoots P R} {mix helper}
    (a : PhysicalArms P R d mix helper) (real : ExactReceivers (fun v q=>q∈R v))
    (edges : ∀ i j : Fin 10,edge i.val j.val=true ↔ ∀q,q∈R i ∨ q∈R j) :
    labelDir d.x d.y d.z ∈ roster38 ∧
    (∀ v,v<10 → normalized d.roots a.L v∈options (labelDir d.x d.y d.z) mix v) ∧
    (∀ u v,u<v → v<10 → edge u v=true → opposes (normalized d.roots a.L u) (normalized d.roots a.L v)=true) := by
  have bits : ∀ u : Fin 16, ∃ m∈Research.Graph9822.FourSaturation.witnesses,
      ∀ v : Fin 10,m.testBit v.val=false ↔ v.val∉independentSets u := by decide +kernel
  have rooms (u : Fin 16) : ∃ q,∀ v,receives P (a.L v) q ↔ v.val∉independentSets u := by
    obtain ⟨m,hm,t⟩ := bits u
    obtain ⟨q,hq⟩ := real.realize m hm
    exact ⟨q,fun v=>(a.meaning v q).symm.trans ((hq v).trans (t v))⟩
  apply selection d.roots mix P a.L d.xy d.yz a.lx a.ly a.lz a.shape _ rooms
  intro i j e q
  exact ((edges i j).mp ((adj_code i j).1 e) q).imp (a.meaning i q).mp (a.meaning j q).mp
end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.select_physical
