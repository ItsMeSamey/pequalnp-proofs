import And9822Pricing
import And9822CommonBank

namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822.LiteralBank Graph9822.UnionCharge
open Graph9822.CommonBank
noncomputable section
local instance : DecidableEq Mask6 := Classical.decEq _

def Primitive (P : Axis6 → Mask6) (m : Mask6) : Prop :=
  m = Set.univ ∨ ∃ i b, m = ray P i b

def outputs (P : Axis6 → Mask6) (ps : Pairs) : List Mask6 :=
  ps.map (fun p => value P (merge p.1 p.2))

theorem available_trace {P : Axis6 → Mask6} {ps : Pairs} {m : Mask6}
    (hm : Available P ps m) : Primitive P m ∨ m ∈ outputs P ps := by
  classical
  by_cases h : Primitive P m
  · exact Or.inl h
  · right
    obtain ⟨w,hw,tw,bw⟩ := hm
    have proper : ∃ q, q ∉ value P w := by
      apply Classical.byContradiction
      intro none
      apply h
      apply Or.inl
      apply hw.symm.trans
      apply Set.eq_univ_of_forall
      intro q
      exact Classical.byContradiction (fun miss => none ⟨q,miss⟩)
    obtain ⟨i,hi⟩ := terminal ps tw bw proper (fun a b eq => h (Or.inr ⟨a,b,hw.symm.trans eq⟩))
    apply List.mem_map.mpr
    exact ⟨ps.get i, List.get_mem _ _, (congrArg (value P) hi).trans hw⟩

theorem ordered_trace {P : Axis6 → Mask6} {ps : Pairs} (ord : Ordered ps) :
    Trace (Primitive P) (outputs P ps) := by
  induction ord with
  | start => exact .nil
  | @issue ps x y _ tx ty bx by' ih =>
    apply Trace.cons ih
    exact ⟨value P x,value P y,available_trace ⟨x,rfl,tx,bx⟩,
      available_trace ⟨y,rfl,ty,by'⟩,value_merge P x y⟩

/-- Every proper nondirect raw has a final pair in one common helper bank.
The chronological helper bank counts only nonreserved slots. Named grants
are available from the outset and separately charged once each. -/
theorem ordered_common_bank {P : Axis6 → Mask6} {ps : Pairs} (ord : Ordered ps)
    (raw grants : Finset Mask6)
    (anti : ∀ x ∈ raw, ∀ y ∈ raw, x ⊆ y → x = y)
    (avail : ∀ x ∈ raw ∪ grants, Available P ps x)
    (nd : ∀ x ∈ raw ∪ grants, ¬Primitive P x) :
    ∃ hs, Helpers (Primitive P) grants hs ∧ (∀ h ∈ hs, ∃ r ∈ raw, h ⊆ r) ∧
      hs.length + (raw ∪ grants).card ≤ ps.length ∧
      ∀ x ∈ raw, PairOf (Source (Primitive P) grants hs) x := by
  classical
  have appears (x) (hx : x ∈ raw ∪ grants) : x ∈ outputs P ps :=
    (available_trace (avail x hx)).resolve_left (nd x hx)
  obtain ⟨hs,hh,sub,hc,uses⟩ := extract raw grants anti (ordered_trace (P:=P) ord)
  have eq : (outputs P ps).toFinset ∩ (raw ∪ grants) = raw ∪ grants :=
    Finset.inter_eq_right.mpr (by intro x hx; exact List.mem_toFinset.mpr (appears x hx))
  rw [eq] at hc
  refine ⟨hs,hh,sub,by simpa [outputs] using hc,?_⟩
  intro x hx
  have seen := appears x (Finset.mem_union_left _ hx)
  exact ((uses _ seen ⟨x,hx,Set.Subset.rfl⟩).resolve_left (fun z => z.2 hx)).2

def RayValue (P : Axis6 → Mask6) (x : Mask6) : Prop := ∃ i b, x = ray P i b

private theorem stripPair {P : Axis6 → Mask6} {g : Finset Mask6} {hs : List Mask6}
    {w : Mask6} (proper : w ≠ Set.univ)
    (h : PairOf (Source (Primitive P) g hs) w) :
    PairOf (Source (RayValue P) g hs) w := by
  obtain ⟨a,b,ha,hb,hw⟩ := h
  have one (y : Mask6) (hy : Source (Primitive P) g hs y) (le : y ⊆ w) :
      Source (RayValue P) g hs y := by
    rcases hy with (top | direct) | hg | hh
    · exact False.elim (proper (Set.eq_univ_of_forall (fun t => le (by rw [top]; exact Set.mem_univ t))))
    · exact Or.inl direct
    · exact Or.inr (Or.inl hg)
    · exact Or.inr (Or.inr hh)
  exact ⟨a,b,one _ ha (by rw [hw]; exact Set.subset_union_left),
    one _ hb (by rw [hw]; exact Set.subset_union_right),hw⟩

theorem ray_helpers {P : Axis6 → Mask6} {g : Finset Mask6} {hs : List Mask6}
    (hh : Helpers (Primitive P) g hs) (proper : ∀ h ∈ hs, h ≠ Set.univ) :
    Helpers (RayValue P) g hs := by
  induction hh with
  | nil => exact .nil
  | cons _ p ih =>
    exact .cons (ih (fun x hx => proper x (List.mem_cons_of_mem _ hx))) (stripPair (proper _ List.mem_cons_self) p)

theorem ordered_ray_bank {P : Axis6 → Mask6} {ps : Pairs} (ord : Ordered ps)
    (raw grants : Finset Mask6)
    (anti : ∀ x ∈ raw, ∀ y ∈ raw, x ⊆ y → x = y)
    (avail : ∀ x ∈ raw ∪ grants, Available P ps x)
    (nd : ∀ x ∈ raw ∪ grants, ¬Primitive P x) :
    ∃ hs, Helpers (RayValue P) grants hs ∧ hs.length + (raw ∪ grants).card ≤ ps.length ∧
      ∀ x ∈ raw, PairOf (Source (RayValue P) grants hs) x := by
  obtain ⟨hs,hh,sub,hc,rawPair⟩ := ordered_common_bank ord raw grants anti avail nd
  have proper (x) (hx : x ∈ raw) : x ≠ Set.univ :=
    fun top => nd _ (Finset.mem_union_left _ hx) (Or.inl top)
  refine ⟨hs,ray_helpers hh ?_,hc,fun x hx => stripPair (proper _ hx) (rawPair x hx)⟩
  intro h hmem he
  obtain ⟨r,hr,le⟩ := sub h hmem
  exact proper r hr (Set.eq_univ_of_forall (fun t => le (by rw [he]; exact Set.mem_univ t)))

end
end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.ordered_common_bank
