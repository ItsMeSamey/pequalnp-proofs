import SixD3BasicRules9822
namespace Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (Arm rooms edge rawBit opposes)
inductive SharedRule
  | base (r : Basic)
  | helperChoice
  | helperUnique (a b : Arm)
  | helperRow (t : Arm) (m : Nat) (mode : Option Atom)
  | linked (v : Nat) (t : Arm)
  | ordinary (v : Nat) (t : Arm)
  | nonneighbor (v j : Nat) (t : Arm)
  | ordinaryPair (j u v : Nat)
  | named (j : Nat)
  | source (j o m : Nat) (mode : Option Atom)
  | wrong (j w : Nat)
  | wordEdge (u v w : Nat)
  deriving Repr, Inhabited
def neighbor (d : Dir) (j v : Nat) := edge ((ds d)[j]?.getD 10) v
def wrongArm (j w : Nat) := 2*j+(if w.testBit j then 0 else 1)
def fittingPairs (t : Arm) := pairs.filter (fun a => a.all t.contains)
def SharedRule.ok (d : Dir) : SharedRule → Bool
  | .base r => r.ok
  | .helperChoice => true
  | .helperUnique a b => !(a == b)
  | .helperRow t m mode => (helperEq t m).legal mode
  | .linked v t => decide (v<10) && (t.length == 3)
  | .ordinary _ t => t.length == 2
  | .nonneighbor v j t => decide (j<3) && decide (v<10) && !((ds d).contains v) &&
      !(edge v ((ds d)[j]?.getD 10)) && t.contains (2*j+1)
  | .ordinaryPair j u v => decide (j<3) && decide (u<v) && decide (v<10) &&
      neighbor d j u && neighbor d j v
  | .named j => decide (j<6)
  | .source j o m mode => decide (j<6) && decide (o<24) && isObs m && (actEq j o m).legal mode
  | .wrong j w => decide (j<6) && decide (w<64)
  | .wordEdge u v w => decide (u<v) && decide (v<10) && edge u v && decide (w<64)
def SharedRule.clause (d : Dir) : SharedRule → Clause
  | .base r => r.clause d true
  | .helperChoice => pairs.map (fun a => pos (.helperSel a))
  | .helperUnique a b => [neg (.helperSel a),neg (.helperSel b)]
  | .helperRow t m mode => (helperEq t m).clause mode
  | .linked v t => neg (.raw v t) :: (fittingPairs t).map (fun a => pos (.helperSel a))
  | .ordinary v t => [neg (.raw v t),pos (.ordinary v)]
  | .nonneighbor v j t => [neg (.raw v t),neg (.origin j 22)]
  | .ordinaryPair j u v => [pos (.origin j 22),neg (.ordinary u),neg (.ordinary v)]
  | .named j => (originChoices d j).map (fun o => pos (.origin j o))
  | .source j o m mode => (actEq j o m).clause mode
  | .wrong j w => [neg (.ray (wrongArm j w) (1024+w))]
  | .wordEdge u v w => [pos (.wordRaw u w),pos (.wordRaw v w)]
theorem SharedRule.sound (p : Shared d) (r : SharedRule) (ok : r.ok d=true) :
    Sat (envOf p.toRooms p.helper p.origin) (r.clause d) := by
  cases r with
  | base r => exact r.sound p.toRooms p.helper p.origin ok
  | helperChoice =>
    exact ⟨_,List.mem_map.mpr ⟨p.helper,p.helperOK,rfl⟩,by simp [pos,Env.val,envOf]⟩
  | helperUnique a b =>
    simp only [SharedRule.ok,Bool.not_eq_true',beq_eq_false_iff_ne] at ok
    simp [Sat,SharedRule.clause,neg,Env.val,envOf]
    by_cases h1 : p.helper=a <;> by_cases h2 : p.helper=b <;> simp_all
  | helperRow t m mode =>
    exact Equation.sound _ _ mode (helperEq_holds p t m) ok
  | linked v t =>
    simp only [SharedRule.ok,Bool.and_eq_true,decide_eq_true_eq,beq_iff_eq] at ok
    by_cases g : p.raw v=t
    · have len : (p.raw v).length=3 := g.symm ▸ ok.2
      have fit : p.helper∈fittingPairs t := List.mem_filter.mpr
        ⟨p.helperOK,List.all_eq_true.mpr (fun k hk => List.contains_iff_mem.mpr (g ▸ p.linked v ok.1 len k hk))⟩
      exact ⟨_,List.mem_cons_of_mem _ (List.mem_map.mpr ⟨p.helper,fit,rfl⟩),by simp [pos,Env.val,envOf]⟩
    · exact ⟨neg (.raw v t),List.mem_cons_self,by simp [neg,Env.val,envOf,g]⟩
  | ordinary v t =>
    have ht : t.length=2 := by simpa [SharedRule.ok] using ok
    by_cases g : p.raw v=t
    · exact ⟨pos (.ordinary v),by simp [SharedRule.clause],by simp [pos,Env.val,envOf,g,ht]⟩
    · exact ⟨neg (.raw v t),List.mem_cons_self,by simp [neg,Env.val,envOf,g]⟩
  | nonneighbor v j t =>
    simp only [SharedRule.ok,Bool.and_eq_true,decide_eq_true_eq,Bool.not_eq_true',
      List.contains_iff_mem] at ok
    have notmem : v∉ds d := fun e => by
      have hh : (ds d).contains v=true := List.contains_iff_mem.mpr e
      have hf := ok.1.1.2
      simp_all
    have h := p.fullNonneighbor j ok.1.1.1.1
    simp [Sat,SharedRule.clause,neg,Env.val,envOf]
    by_cases g : p.raw v=t
    · right
      apply decide_eq_false
      intro full
      exact (h full v ok.1.1.1.2 notmem ok.1.2) (g.symm ▸ ok.2)
    · exact Or.inl (decide_eq_false g)
  | ordinaryPair j u v =>
    simp only [SharedRule.ok,Bool.and_eq_true,decide_eq_true_eq] at ok
    simp [Sat,SharedRule.clause,pos,neg,Env.val,envOf]
    by_cases full : p.origin j=22
    · exact Or.inl (decide_eq_true full)
    · by_cases ordinary : (p.raw u).length=2
      · exact Or.inr (Or.inr (decide_eq_false (p.ordinaryNeighbor j ok.1.1.1.1 full u v ok.1.1.1.2 ok.1.1.2
          ok.1.2 ok.2 ordinary)))
      · exact Or.inr (Or.inl (decide_eq_false ordinary))
  | named j =>
    exact ⟨_,List.mem_map.mpr ⟨p.origin j,p.named j (of_decide_eq_true ok),rfl⟩,
      by simp [pos,Env.val,envOf]⟩
  | source j o m mode =>
    simp only [SharedRule.ok,Bool.and_eq_true,decide_eq_true_eq] at ok
    exact Equation.sound _ _ mode (actEq_holds p ok.1.1.1 ok.1.1.2 (obsBool ok.1.2)) ok.2
  | wrong j w =>
    simp only [SharedRule.ok,Bool.and_eq_true,decide_eq_true_eq] at ok
    exact ⟨_,List.mem_cons_self,p.wrongSign w ok.2 j ok.1⟩
  | wordEdge u v w =>
    simp only [SharedRule.ok,Bool.and_eq_true,decide_eq_true_eq] at ok
    have h := p.edgeWords u v ok.1.1.1 ok.1.1.2 ok.1.2 w ok.2
    simpa [Sat,SharedRule.clause,pos,Env.val,envOf] using h
end Research.Graph9822.ThreeDirect
