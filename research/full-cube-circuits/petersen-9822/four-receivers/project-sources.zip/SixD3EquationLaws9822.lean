import SixD3CNF9822
namespace Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (Arm rooms edge rawBit opposes)
def rawEq (v m : Nat) (t : Arm) : Equation := ⟨.raw v t,rayAt m t,rawAt v m⟩
def helperEq (t : Arm) (m : Nat) : Equation := ⟨.helperSel t,rayAt m t,.helperBit m⟩
def actEq (j o m : Nat) : Equation := ⟨.origin j o,activationAt j m,sourceAt o m⟩
theorem small_rooms : ∀ m ∈ rooms, m < 1024 := by decide +kernel
theorem obsBool {m : Nat} (h : isObs m = true) : obs m := by
  simp only [isObs,Bool.or_eq_true,List.contains_iff_mem,decide_eq_true_eq] at h
  rcases h with h|⟨lo,hi⟩
  · exact Or.inl h
  · exact Or.inr ⟨m-1024,by omega,by omega⟩
theorem rawAt_val (p : Rooms d mix) (h : Arm) (o : Nat → Nat) {v m : Nat}
    (hv : v<10) (hm : obs m) :
    (envOf p h o).val (rawAt v m) = (p.raw v).any (fun k => p.ray k m) := by
  rcases hm with hm|⟨w,hw,rfl⟩
  · simpa [rawAt,small_rooms m hm,envOf,Env.val] using (p.rawRows v hv m hm).symm
  · have big : ¬1024+w<1024 := by omega
    simp [rawAt,big,envOf,Env.val]
theorem rawEq_holds (p : Rooms d mix) (h : Arm) (o : Nat → Nat) (v m : Nat) (t : Arm)
    (hv : v<10) (hm : obs m) : (rawEq v m t).Holds (envOf p h o) := by
  intro g
  have eq : p.raw v = t := of_decide_eq_true g
  rw [←eq]
  change ((rayAt m (p.raw v)).any (envOf p h o).val) = (envOf p h o).val (rawAt v m)
  rw [rawAt_val p h o hv hm]
  simp [rayAt,List.any_map,Function.comp_def,Env.val,envOf]
theorem helperEq_holds (p : Shared d) (t : Arm) (m : Nat) :
    (helperEq t m).Holds (envOf p.toRooms p.helper p.origin) := by
  intro g
  have eq : p.helper=t := of_decide_eq_true g
  subst t
  simp [helperEq,rayAt,List.any_map,Function.comp_def,Env.val,envOf]
theorem activationAt_val (p : Shared d) {j m : Nat} (hj : j<6) (hm : obs m) :
    (activationAt j m).any (envOf p.toRooms p.helper p.origin).val =
      (p.ray (2*j) m || p.ray (2*j+1) m) := by
  rcases hm with hm|⟨w,hw,rfl⟩
  · simp [activationAt,small_rooms m hm,Env.val,envOf]
  · have big : ¬1024+w<1024 := by omega
    rw [activationAt,if_neg big]
    have wrong := p.wrongSign w hw j hj
    cases sign : w.testBit j <;> simp_all [wordArm,Env.val,envOf]
theorem actEq_holds (p : Shared d) {j o m : Nat} (hj : j<6) (ho : o<24) (hm : obs m) :
    (actEq j o m).Holds (envOf p.toRooms p.helper p.origin) := by
  intro g
  have eq : p.origin j = o := of_decide_eq_true g
  change (activationAt j m).any _ = (envOf p.toRooms p.helper p.origin).val (sourceAt o m)
  rw [activationAt_val p hj hm,p.activation j hj m hm,eq]
  by_cases full : o=22
  · simp [full,sourceAt,envOf,Env.val]
  by_cases help : o=23
  · simp [help,sourceAt,envOf,Env.val]
  by_cases primitive : o<12
  · simp [sourceAt,full,help,primitive,envOf,Env.val]
  have bound : o-12<10 := by omega
  simpa [sourceAt,full,help,primitive] using (rawAt_val p.toRooms p.helper p.origin bound hm).symm
end Research.Graph9822.ThreeDirect
