import SixD3GridUnits9822
import SixD3GridDataA1359822
namespace Research.Graph9822.ThreeDirect.A135
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit48 : ∀ a, Known a g 1923 → Known a g 1924 :=
  singleKnown g 1923 (unpack 28 [0x115d000009a55e615e15f715f5609162d67f16556e116a168d16b56b716c96ef173d6cd174d705175d74d17697a7177975b17857b509bd5d90bc0473160961d16416a91669729167d78316dd73716f1791179176b17a17c509ad5c309a95b509fd64d1ce83331cb01f31c800b3098c29207d4152073c012097934407c4e9007249dc]) (by decide +kernel)
private theorem unit49 : ∀ a, Known a g 1924 → Known a g 1925 :=
  singleKnown g 1924 (unpack 28 [0x10b200000a799920add98f0aa58690b919cb0b859bb0b799ad0b499a10a8181f0ab58a50a7d81b1ce83331cdc3271cb01f31c800b31c700a7098c292098028607d4152073c012072c006097934407c4e9007249dc]) (by decide +kernel)
private theorem unit50 : ∀ a, Known a g 1925 → Known a g 1926 :=
  singleKnown g 1925 (unpack 28 [0x1070400005a89ac06d0993069898505fc81505b07b7060083d05ac7b31ce43311ca41f11c7c0b1098829007d01500738010097934407c4e9007249dc]) (by decide +kernel)
private theorem unit51 : ∀ a, Known a g 1926 → Known a g 1927 :=
  singleKnown g 1926 (unpack 28 [0x10ba400003ee055021a05101be047]) (by decide +kernel)
private theorem unit52 : ∀ a, Known a g 1927 → Known a g 1928 :=
  singleKnown g 1927 (unpack 28 [0x10b5c000021a061023e073021e06f]) (by decide +kernel)
private theorem unit53 : ∀ a, Known a g 1928 → Known a g 1929 :=
  singleKnown g 1928 (unpack 28 [0x10b5c00003ee061041207303f206f]) (by decide +kernel)
private theorem unit54 : ∀ a, Known a g 1929 → Known a g 1930 :=
  singleKnown g 1929 (unpack 28 [0x10b980000bf9beb0be1ba30ba5b230476091047207f1db1c4503f2055036608d031a07b021e05101c20470b9da770ba1afd1ce43311ca41f11c7c0b1098829007d01500738010097934407c4e9007249dc]) (by decide +kernel)
private theorem unit55 : ∀ a, Known a g 1930 → Known a g 1931 :=
  singleKnown g 1930 (unpack 28 [0x104c40000be207e033a07b01e2047]) (by decide +kernel)
private theorem unit56 : ∀ a, Known a g 1931 → Known a g 1932 :=
  singleKnown g 1931 (unpack 28 [0x10be0000043607f031607b01be0470b5e0601e2606f0bd5b6b0bbdb410b645110b604711e2a0731ce43311ca41f1098829007d0150097934407c4e90]) (by decide +kernel)
private theorem unit57 : ∀ a, Known a g 1932 → Known a g 1933 :=
  singleKnown g 1932 (unpack 28 [0x10bf8000043a091036208d01be047]) (by decide +kernel)
private theorem unit58 : ∀ a, Known a g 1933 → Known a g 1934 :=
  singleKnown g 1933 (unpack 28 [0x10bf800004fa091038608d0b5e0721e2606f1e320610b99bea0ba5b231e1e0510bd5b6b0b645111e220550bbdb410b604711e2dba30b9da770ba1afd1ce43311ca41f11c7c0b1098829007d01500738010097934407c4e9007249dc]) (by decide +kernel)
private theorem unit59 : ∀ a, Known a g 1934 → Known a g 1935 :=
  singleKnown g 1934 (unpack 28 [0x10b5c00001e207301c206f01be0611e36046]) (by decide +kernel)
theorem up4 : ∀ a, Known a g 1923 → Known a g 1935 := by
  intro a h
  apply unit59 a
  apply unit58 a
  apply unit57 a
  apply unit56 a
  apply unit55 a
  apply unit54 a
  apply unit53 a
  apply unit52 a
  apply unit51 a
  apply unit50 a
  apply unit49 a
  apply unit48 a
  exact h
end Research.Graph9822.ThreeDirect.A135
