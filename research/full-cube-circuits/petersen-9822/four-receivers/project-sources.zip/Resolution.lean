import PEqualNP.Defs

namespace Research.Graph9822Resolution

/-- Wires are functions of their numeric address. An assignment to an unused address
can be fixed to false when transporting the project's list-based gate semantics. -/
abbrev Wire := Nat → Bool

structure Gate where
  isAnd : Bool
  left : Nat
  right : Nat

def step (g : Gate) (a b : Bool) : Bool :=
  if g.isAnd then a && b else a || b

def resolved (g : Gate) (side a b : Bool) : Bool :=
  if g.isAnd then (if side then a else b) else a || b

def eval (gs : List Gate) (i : Nat) (w : Wire) : Wire :=
  match gs with
  | [] => w
  | g :: tail => eval tail (i+1) (Function.update w i (step g (w g.left) (w g.right)))

def resolve (gs : List Gate) (i : Nat) (s : Wire) (w : Wire) : Wire :=
  match gs with
  | [] => w
  | g :: tail => resolve tail (i+1) s
      (Function.update w i (resolved g (s i) (w g.left) (w g.right)))

theorem lower (gs : List Gate) (i : Nat) (s : Wire) (w v : Wire)
    (h : ∀ j, w j = true → v j = true) :
    ∀ j, eval gs i w j = true → resolve gs i s v j = true := by
  induction gs generalizing i w v with
  | nil => exact h
  | cons g tail ih =>
    apply ih
    intro j hj
    by_cases e : j = i
    · subst j
      simp only [Function.update_self] at hj ⊢
      have ha := h g.left
      have hb := h g.right
      cases ht : g.isAnd <;> cases hs : s i <;> cases wa : w g.left <;> cases wb : w g.right <;>
        simp_all [step, resolved]
    · simpa [Function.update_of_ne e] using h j (by simpa [Function.update_of_ne e] using hj)

/-- Choose the left input if it is false; otherwise the right input. This realizes
the ordinary value at every wire simultaneously on the given input. -/
theorem attains (gs : List Gate) (i : Nat) (w : Wire) :
    ∃ s : Wire, (∀ j, j < i → s j = false) ∧ resolve gs i s w = eval gs i w := by
  induction gs generalizing i w with
  | nil => exact ⟨fun _ => false, by simp, rfl⟩
  | cons g tail ih =>
    let v := Function.update w i (step g (w g.left) (w g.right))
    obtain ⟨s, hprefix, hs⟩ := ih (i+1) v
    let t := Function.update s i (!w g.left)
    have agree : ∀ (ls : List Gate) (k : Nat) (z : Wire), i < k →
        resolve ls k t z = resolve ls k s z := by
      intro ls
      induction ls with
      | nil => intros; rfl
      | cons a as h =>
        intro k z hk
        simp only [resolve, t, Function.update_of_ne (Nat.ne_of_gt hk)]
        exact h (k+1) _ (by omega)
    have hgate : resolved g (t i) (w g.left) (w g.right) = step g (w g.left) (w g.right) := by
      cases hg : g.isAnd <;> cases hl : w g.left <;> cases hr : w g.right <;> simp [t,resolved,step,hg,hl,hr]
    refine ⟨t, ?_, ?_⟩
    · intro j hj
      simp only [t, Function.update_of_ne (Nat.ne_of_lt hj)]
      exact hprefix j (by omega)
    · simp only [resolve, eval, hgate]
      exact (agree tail (i+1) v (by omega)).trans hs

theorem eval_iff_all_resolutions (gs : List Gate) (i : Nat) (w : Wire) (out : Nat) :
    eval gs i w out = true ↔ ∀ s, resolve gs i s w out = true := by
  constructor
  · intro hv s
    exact lower gs i s w w (fun _ h => h) out hv
  · intro h
    obtain ⟨s, _, hs⟩ := attains gs i w
    simpa [hs] using h s

end Research.Graph9822Resolution

#print axioms Research.Graph9822Resolution.lower
#print axioms Research.Graph9822Resolution.attains
#print axioms Research.Graph9822Resolution.eval_iff_all_resolutions
