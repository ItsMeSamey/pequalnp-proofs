import SixD3RootA2459822
import SixD3Sigma148To2459822
namespace Research.Graph9822.ThreeDirect.A148
def d : Dir := (1,4,8)
theorem closed : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact A245.closed ⟨Sigma.shared148_245 p⟩
end Research.Graph9822.ThreeDirect.A148
