import SixD3GridDataA1379822
namespace Research.Graph9822.ThreeDirect.A137
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part1008 : Range (aOK d) (aCl d) g 1008 1032 :=
  rangeCheck _ _ _ 1008 24 (by decide +kernel)
private theorem part1032 : Range (aOK d) (aCl d) g 1032 1056 :=
  rangeCheck _ _ _ 1032 24 (by decide +kernel)
private theorem part1056 : Range (aOK d) (aCl d) g 1056 1080 :=
  rangeCheck _ _ _ 1056 24 (by decide +kernel)
private theorem part1080 : Range (aOK d) (aCl d) g 1080 1104 :=
  rangeCheck _ _ _ 1080 24 (by decide +kernel)
private theorem part1104 : Range (aOK d) (aCl d) g 1104 1128 :=
  rangeCheck _ _ _ 1104 24 (by decide +kernel)
private theorem part1128 : Range (aOK d) (aCl d) g 1128 1152 :=
  rangeCheck _ _ _ 1128 24 (by decide +kernel)
theorem sem7 : Range (aOK d) (aCl d) g 1008 1152 := rangeAppend part1008 (rangeAppend part1032 (rangeAppend part1056 (rangeAppend part1080 (rangeAppend part1104 (part1128)))))
end Research.Graph9822.ThreeDirect.A137
