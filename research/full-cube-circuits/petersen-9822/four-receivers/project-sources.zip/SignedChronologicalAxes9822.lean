import CutGroupRoom
import ChronologicalAxis

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles

theorem event_tags_from_addrs (gs : List DGate) (base : Nat) (label : Nat → Axis) :
    (gateEvents label gs base).flatMap axisTags = (switchAddrs gs base).map label := by
  induction gs generalizing base with
  | nil => rfl
  | cons g rest ih =>
    cases h : g.isAnd <;> simp [gateEvents,switchAddrs,gateEvent,h,axisTags,ih]

theorem chronological_lookup (gs : List DGate) (base : Nat)
    (cap : (switchAddrs gs base).length ≤ 6) {j : Nat} (inside : j ∈ switchAddrs gs base) :
    switchAxis (switchAddrs gs base) cap j = axisOf gs base j := by
  obtain ⟨k,hk,eq⟩ := List.mem_iff_getElem.mp inside
  have hit : ∃ a : Fin (switchAddrs gs base).length, (switchAddrs gs base)[a.val] = j :=
    ⟨⟨k,hk⟩,eq⟩
  let a := hit.choose
  have hc := chronological_tags gs base
  rw [event_tags_from_addrs] at hc
  have loc := congrArg (fun l : List Axis => l[a.val]?) hc
  have val : (switchAddrs gs base)[a.val] = j := hit.choose_spec
  have lt := a.isLt
  have lt' : a.val < gs.countP Research.Graph9822Resolution.Gate.isAnd := by
    simpa only [switchAddrs_length] using lt
  have hr : a.val < (List.range (gs.countP Research.Graph9822Resolution.Gate.isAnd)).length := by simpa using lt'
  simp only [List.getElem?_map,List.getElem?_eq_getElem lt,List.getElem?_eq_getElem hr,Option.map_some,Option.some.injEq,List.getElem_range,val] at loc
  rw [switchAxis,dif_pos hit]
  rw [loc]
  apply Fin.ext
  change a.val = a.val % 6
  exact (Nat.mod_eq_of_lt (lt_of_lt_of_le lt cap)).symm

end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.chronological_lookup

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles

theorem signed_gate_tags (gs : List DGate) (base : Nat) (cap : (switchAddrs gs base).length≤6) :
    (gateEvents (switchAxis (switchAddrs gs base) cap) gs base).flatMap axisTags =
      (List.range (gs.countP Research.Graph9822Resolution.Gate.isAnd)).map (Fin.ofNat 6) := by
  rw [←chronological_tags gs base,event_tags_from_addrs,event_tags_from_addrs]
  exact List.map_congr_left (fun _ h => chronological_lookup gs base cap h)

theorem signed_padded_bank (gs : List DGate) (base out : Nat) (cap : (switchAddrs gs base).length≤6)
    (rawLive : ∀ a < base, (back (switchAxis (switchAddrs gs base) cap) gs base (initial out)).q a ≠ []) :
    let axis := switchAxis (switchAddrs gs base) cap
    let es := gateEvents axis gs base ++ rawEvents base
    let s := es.foldl paddedStep (initial out)
    Good s ∧ s.switches.map Prod.fst =
      ((List.range (gs.countP Research.Graph9822Resolution.Gate.isAnd)).map (Fin.ofNat 6)).reverse ∧
      s.receivers = (List.range base).map (fun a =>
        {w | Research.Graph9822Resolution.reaches gs base (fun j => w (axis j)) out a = true}) ∧
      s.cost=((activeEvents es (initial out)).foldl next (initial out)).cost := by
  dsimp only
  let axis := switchAxis (switchAddrs gs base) cap
  let es := gateEvents axis gs base ++ rawEvents base
  have same := actual_fold es (initial out) (initial out) ⟨rfl,rfl,rfl⟩
  have rawtags (i : Nat) : (rawEvents i).flatMap axisTags = [] := by
    induction i with
    | zero => rfl
    | succ i ih => simpa [rawEvents,axisTags] using ih
  refine ⟨good_padded _ _ (initial_good out),?_,?_,?_⟩
  · simp [issue_tags,List.flatMap_append,signed_gate_tags,rawtags,initial]
  · exact same.2.1.trans ((congrArg ReverseState.receivers (fold_active es (initial out))).symm.trans
      (receiver_list_exact axis gs base out rawLive))
  · exact same.2.2.trans (congrArg ReverseState.cost (fold_active es (initial out))).symm

end Research.Graph9822Profiles.OuterLive
