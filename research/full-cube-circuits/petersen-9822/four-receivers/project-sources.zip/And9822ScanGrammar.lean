import Mathlib.Logic.Equiv.Basic
import Mathlib.Data.Set.Basic
set_option maxRecDepth 100000
set_option maxHeartbeats 0

-- ProfileTransport abd19cc8d862ca2bca6c65f669361937a01948c44915d30398e465131d50228d
namespace Research.Graph9822Profiles

abbrev Axis := Fin 6
abbrev Word := Axis → Bool
abbrev Mask := Set Word

/-- Each new coordinate is a signed old coordinate; old axes are sent to perm i. -/
def change (perm : Equiv.Perm Axis) (flip : Axis → Bool) (word : Word) : Word :=
  fun j => xor (word (perm.symm j)) (flip j)

def wordEquiv (perm : Equiv.Perm Axis) (flip : Axis → Bool) : Equiv Word Word where
  toFun := change perm flip
  invFun := fun w i => xor (w (perm i)) (flip (perm i))
  left_inv w := by
    funext i
    simp only [change,Equiv.symm_apply_apply]
    cases w i <;> cases flip (perm i) <;> rfl
  right_inv w := by
    funext i
    simp only [change,Equiv.apply_symm_apply]
    cases w i <;> cases flip i <;> rfl

def liftMask (e : Equiv Word Word) (m : Mask) : Mask := e.symm ⁻¹' m

def side (a : Axis) (b : Bool) : Mask := {w | w a = b}

theorem lift_union (e : Equiv Word Word) (x y : Mask) :
    liftMask e (x ∪ y) = liftMask e x ∪ liftMask e y := rfl

theorem lift_full (e : Equiv Word Word) : liftMask e Set.univ = Set.univ := rfl

theorem lift_split (p : Equiv.Perm Axis) (f : Axis → Bool) (u : Mask) (i : Axis) (b : Bool) :
    liftMask (wordEquiv p f) (u ∩ side i b) =
      liftMask (wordEquiv p f) u ∩ side (p i) (xor b (f (p i))) := by
  ext w
  change ((_ ∈ u) ∧ xor (w (p i)) (f (p i)) = b) ↔ ((_ ∈ u) ∧ w (p i) = xor b (f (p i)))
  cases w (p i) <;> cases f (p i) <;> cases b <;> simp

inductive UnionRecipe (sources : List Mask) : Mask → Nat → Prop
  | input {m} (hm : m ∈ sources) : UnionRecipe sources m 0
  | join {x y a b} (left : UnionRecipe sources x a) (right : UnionRecipe sources y b) :
      UnionRecipe sources (x ∪ y) (a+b+1)

theorem recipe_transport (e : Equiv Word Word) {sources : List Mask} {m : Mask} {n : Nat}
    (r : UnionRecipe sources m n) :
    UnionRecipe (sources.map (liftMask e)) (liftMask e m) n := by
  induction r with
  | input h => exact .input (List.mem_map_of_mem h)
  | join _ _ ih jh => exact .join ih jh

/-- Induction on *physical* union gates retains shared wires and pays once per gate. -/
inductive Bank : List Mask → List Mask → Nat → Prop
  | done (src) : Bank src src 0
  | join {src lib n x y} (h : Bank src lib n) (hx : x ∈ lib) (hy : y ∈ lib) :
      Bank src ((x ∪ y)::lib) (n+1)

theorem bank_transport (e : Equiv Word Word) {src lib : List Mask} {n : Nat}
    (h : Bank src lib n) : Bank (src.map (liftMask e)) (lib.map (liftMask e)) n := by
  induction h with
  | done => exact .done _
  | join _ hx hy ih => exact .join ih (List.mem_map_of_mem hx) (List.mem_map_of_mem hy)

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.lift_split
#print axioms Research.Graph9822Profiles.bank_transport

-- ProfileGrammar e488c5f617c2c373a656fe3195d3745170a63529617a3fc54cd93ae5e7b09302
namespace Research.Graph9822Profiles

/-- A uniform full observer is granted separately. All other activation masks are
unions of earlier signed branches, without an a priori size bound on that union. -/
def bankPool : List Mask → List Mask
  | [] => [∅]
  | b::bs => let old := bankPool bs; old ++ old.map (fun a => a ∪ b)

theorem empty_mem_pool (bs : List Mask) : (∅ : Mask) ∈ bankPool bs := by
  induction bs with
  | nil => simp [bankPool]
  | cons b bs ih => exact List.mem_append_left _ ih

theorem primitive_mem_pool {b : Mask} {bs : List Mask} (hb : b ∈ bs) : b ∈ bankPool bs := by
  induction bs with
  | nil => simp at hb
  | cons a bs ih =>
    rcases List.mem_cons.mp hb with rfl | h
    · apply List.mem_append_right
      exact List.mem_map.mpr ⟨∅, empty_mem_pool bs, Set.empty_union _⟩
    · exact List.mem_append_left _ (ih h)

theorem pool_union {x y : Mask} (bs : List Mask)
    (hx : x ∈ bankPool bs) (hy : y ∈ bankPool bs) : x ∪ y ∈ bankPool bs := by
  induction bs generalizing x y with
  | nil =>
    simp [bankPool] at hx hy
    simp [hx,hy,bankPool]
  | cons b bs ih =>
    change x ∈ bankPool bs ++ _ at hx
    change y ∈ bankPool bs ++ _ at hy
    rcases List.mem_append.mp hx with hx | hx <;> rcases List.mem_append.mp hy with hy | hy
    · exact List.mem_append_left _ (ih hx hy)
    · obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hy
      apply List.mem_append_right
      exact List.mem_map.mpr ⟨x ∪ a,ih hx ha,by ext; simp [or_assoc]⟩
    · obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hx
      apply List.mem_append_right
      exact List.mem_map.mpr ⟨a ∪ y,ih ha hy,by ext; simp [or_assoc,or_left_comm,or_comm]⟩
    · obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hx
      obtain ⟨c,hc,rfl⟩ := List.mem_map.mp hy
      apply List.mem_append_right
      exact List.mem_map.mpr ⟨a ∪ c,ih ha hc,by ext; simp [or_assoc,or_left_comm,or_comm]⟩

theorem recipe_in_pool {bs : List Mask} {m : Mask} {n : Nat} (h : UnionRecipe bs m n) :
    m ∈ bankPool bs := by
  induction h with
  | input h => exact primitive_mem_pool h
  | join _ _ a b => exact pool_union _ a b

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.recipe_in_pool

-- ProfileScan 45bce64644c8dd8e5bad34f47922ee7ad0ebd96c62137e1208aa45abb6fdc7ca
namespace Research.Graph9822Profiles

/-- The list of issued masks can contain the full observer, split outputs and
previously materialized union gates. Folded fanout paths issue one union per
additional use. Split axes are supplied by the physical traversal. -/
inductive Scan : List Mask → List Mask → List (Axis × Mask) → Nat → Prop
 | start : Scan [] [Set.univ] [] 0
 | join {b l p n x y} (h : Scan b l p n) (hx : x ∈ l) (hy : y ∈ l) :
     Scan b ((x ∪ y)::l) p (n+1)
 | split {b l p n u i} (h : Scan b l p n) (hu : u ∈ l) :
     Scan ((u ∩ side i true)::(u ∩ side i false)::b)
          ((u ∩ side i true)::(u ∩ side i false)::l) ((i,u)::p) n

theorem pool_weaken (a b : Mask) (bs : List Mask) {x : Mask} (h : x ∈ bankPool bs) :
    x ∈ bankPool (a::b::bs) :=
  List.mem_append_left _ (List.mem_append_left _ h)

theorem scan_pool {b l p n} (h : Scan b l p n) :
    ∀ x ∈ l, x = Set.univ ∨ x ∈ bankPool b := by
 induction h with
 | start => simp
 | join h hx hy ih =>
   intro x hx'
   rcases List.mem_cons.mp hx' with rfl | hx'
   · rcases ih _ hx with e | a <;> rcases ih _ hy with f | b
     · simp [e]
     · simp [e]
     · simp [f]
     · exact Or.inr (pool_union _ a b)
   · exact ih _ hx'
 | split h hu ih =>
   intro x hx
   rcases List.mem_cons.mp hx with rfl | hx
   · exact Or.inr (primitive_mem_pool (by simp))
   rcases List.mem_cons.mp hx with rfl | hx
   · exact Or.inr (primitive_mem_pool (by simp))
   rcases ih _ hx with eq | old
   · exact Or.inl eq
   · exact Or.inr (pool_weaken _ _ _ old)

/-- List the selector records newest first, together with the exact pre-split
union-pool condition. -/
inductive Profile : List Mask → List (Axis × Mask) → Prop
 | empty : Profile [] []
 | issue {b p u i} (h : Profile b p) (hu : u = Set.univ ∨ u ∈ bankPool b) :
     Profile ((u ∩ side i true)::(u ∩ side i false)::b) ((i,u)::p)

theorem scan_profile {b l p n} (h : Scan b l p n) : Profile b p := by
  induction h with
  | start => exact .empty
  | join _ _ _ ih => exact ih
  | split h hu ih => exact .issue ih (scan_pool h _ hu)

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.scan_profile
