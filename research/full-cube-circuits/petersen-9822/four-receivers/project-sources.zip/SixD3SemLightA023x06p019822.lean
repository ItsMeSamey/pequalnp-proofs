import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem g888 : Range (aOK d) (aCl d) g 888 892 := rangeCheck _ _ _ 888 4 (by decide +kernel)
private theorem g892 : Range (aOK d) (aCl d) g 892 896 := rangeCheck _ _ _ 892 4 (by decide +kernel)
private theorem g896 : Range (aOK d) (aCl d) g 896 900 := rangeCheck _ _ _ 896 4 (by decide +kernel)
private theorem g900 : Range (aOK d) (aCl d) g 900 904 := rangeCheck _ _ _ 900 4 (by decide +kernel)
private theorem g904 : Range (aOK d) (aCl d) g 904 908 := rangeCheck _ _ _ 904 4 (by decide +kernel)
private theorem g908 : Range (aOK d) (aCl d) g 908 912 := rangeCheck _ _ _ 908 4 (by decide +kernel)
theorem light6p1 : Range (aOK d) (aCl d) g 888 912 := rangeAppend g888 (rangeAppend g892 (rangeAppend g896 (rangeAppend g900 (rangeAppend g904 (g908)))))
end Research.Graph9822.ThreeDirect.A023
