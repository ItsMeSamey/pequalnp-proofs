import SixD3SignedSampling9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral (Word Lit ray)
open Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (Arm)
def Choice (r : Roots) (P : Fin 6→Set Word) (R : Fin 10→Set Word)
    (d : Dir) (H : Set Word) (i : Fin 6) :=
    P i=Set.univ ∨ (∃ t : Lit,t.1≠i ∧ P i=ray P t.1 t.2) ∨
      (3≤axisCode r i ∧ (P i=H ∨ ∃ v : Fin 10,v.val∉ds d ∧ P i=R v))

theorem choose_names (r : Roots) (P : Fin 6→Set Word) (R : Fin 10→Set Word)
    (d : Dir) (H : Set Word) (raw : Nat→Arm) (arm : Arm)
    (src : ∀ i,Choice r P R d H i)
    (rec : ∀ v : Fin 10,∀ q,q∈R v ↔ ∃ k∈raw v.val,q∈mask r P k)
    (help : ∀ q,q∈H ↔ ∃ k∈arm,q∈mask r P k) :
    ∃ o : Nat→Nat,∀ j,j<6 →
      o j∈originChoices d j ∧
      (∀ w,(w∈mask r P (2*j) ∨ w∈mask r P (2*j+1)) ↔
        if o j=22 then True else if o j=23 then ∃ k∈arm,w∈mask r P k
        else if o j<12 then w∈mask r P (o j) else ∃ k∈raw (o j-12),w∈mask r P k) ∧
      (∀ i,axisCode r i=j → (o j=22 → P i=Set.univ) ∧
        (j<3 → o j≠22 → ∃ t : Lit,P i=ray P t.1 t.2)) := by
  classical
  let good (j n : Nat) := n∈originChoices d j ∧
      (∀ w,(w∈mask r P (2*j) ∨ w∈mask r P (2*j+1)) ↔
        if n=22 then True else if n=23 then ∃ k∈arm,w∈mask r P k
        else if n<12 then w∈mask r P n else ∃ k∈raw (n-12),w∈mask r P k) ∧
      (∀ i,axisCode r i=j → (n=22 → P i=Set.univ) ∧
        (j<3 → n≠22 → ∃ t : Lit,P i=ray P t.1 t.2))
  have pick (j : Nat) (bound : j<6) : ∃ n,good j n := by
    obtain ⟨i,idx⟩ := inverse_axis r ⟨j,bound⟩
    change axisCode r i=j at idx
    have sem (w) : (w∈mask r P (2*j) ∨ w∈mask r P (2*j+1)) ↔ w∈P i :=
      idx ▸ (slot_rows r P i w).1
    have uniq (k : Fin 6) (eq : axisCode r k=j) : k=i := axisInj r (eq.trans idx.symm)
    rcases src i with full|⟨t,diff,rel⟩|⟨hid,ex⟩
    · refine ⟨22,by simp [originChoices],fun w=>by simp [sem w,full],?_⟩
      intro k eq
      simp [uniq k eq,full]
    · have lim := code_bound r t
      have different : code r t/2≠j := by
        rw [code_axis]
        exact fun eq=>diff (uniq _ eq)
      refine ⟨code r t,by simp [originChoices,lim,different],?_,?_⟩
      · intro w
        simp [show code r t≠22 by omega,show code r t≠23 by omega,lim,sem w,mask_at,rel]
      · intro k eq
        exact ⟨by omega,fun _ _=>⟨t,(uniq k eq).symm ▸ rel⟩⟩
    · have hi : ¬j<3 := by omega
      rcases ex with rel|⟨v,out,rel⟩
      · refine ⟨23,by simp [originChoices,hi],fun w=>?_,fun k eq=>by simp [hi]⟩
        simpa [sem w,rel] using help w
      · have small := v.isLt
        have n22 : v.val+12≠22 := by omega
        have n23 : v.val+12≠23 := by omega
        have lt12 : ¬v.val+12<12 := by omega
        refine ⟨v.val+12,by simp [originChoices,hi,out,v.isLt],fun w=>?_,fun k eq=>by simp [hi,n22]⟩
        simpa [n22,n23,lt12,sem w,rel] using rec v w
  let o (j : Nat) := if hj : j<6 then (pick j hj).choose else 0
  exact ⟨o,fun j bound=>by simpa [o,bound,good] using (pick j bound).choose_spec⟩

end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.choose_names
