import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B078
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (0,7,8)
private noncomputable def rules : List Nat := unpack 35 [0x800000050]
private def keys : List Nat := (List.range 1).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 1 [0x9] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B078
