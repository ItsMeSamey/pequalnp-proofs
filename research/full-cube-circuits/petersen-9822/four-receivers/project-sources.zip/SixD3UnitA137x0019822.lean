import SixD3GridUnits9822
import SixD3GridDataA1379822
namespace Research.Graph9822.ThreeDirect.A137
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit12 : ∀ a, Known a g 2403 → Known a g 2404 :=
  singleKnown g 2403 (unpack 28 [0x10eb400008220a905d60a104a205d]) (by decide +kernel)
private theorem unit13 : ∀ a, Known a g 2404 → Known a g 2405 :=
  singleKnown g 2404 (unpack 28 [0x1108c00004a20ad04720a5046a07f]) (by decide +kernel)
private theorem unit14 : ∀ a, Known a g 2405 → Known a g 2406 :=
  singleKnown g 2405 (unpack 28 [0x10eb400007220a905a60a1047205d]) (by decide +kernel)
private theorem unit15 : ∀ a, Known a g 2406 → Known a g 2407 :=
  singleKnown g 2406 (unpack 28 [0x10eb400006be0a9059e0a1108e07e258e0ad259205d25960a5]) (by decide +kernel)
private theorem unit16 : ∀ a, Known a g 2407 → Known a g 2408 :=
  singleKnown g 2407 (unpack 28 [0x11be80000ba17901a6d7831e6576b18d9609192d61d1a197290c296e10c816ef0c0d67f0c6168d1d417051b917371d8174d17d95d91dc17a70ea45b30ea04731ea57c518815f70ba55b50ba95c30bf564d251833324fc1f324dc0b30d8c292089815208540120d797f40888e9008449dc]) (by decide +kernel)
private theorem unit17 : ∀ a, Known a g 2408 → Known a g 2409 :=
  singleKnown g 2408 (unpack 28 [0x110780000ee46530ee05b325183330d8c2920d797f4]) (by decide +kernel)
private theorem unit18 : ∀ a, Known a g 2409 → Known a g 2410 :=
  singleKnown g 2409 (unpack 28 [0x10ea8000080e095058a08d049e05d]) (by decide +kernel)
private theorem unit19 : ∀ a, Known a g 2410 → Known a g 2411 :=
  singleKnown g 2410 (unpack 28 [0x11044000080e09506fe0910656061]) (by decide +kernel)
private theorem unit20 : ∀ a, Known a g 2411 → Known a g 2412 :=
  singleKnown g 2411 (unpack 28 [0x123c00000ba16c024396cd24717050bed61d25586f30d3975b0d1574d0cd17410c8d7370c317290bdd60920c966122a168d1fc95f71f715e71f195d91ebd5cd22f96b723496ef23cd6f924a976b20e967f21456a90f34652219d6e1226566f0f306460ba55b50ba95c30bf564d2518333250c32724fc1f324dc0b30d8c2920d80286089815208540120d797f40888e9008449dc]) (by decide +kernel)
private theorem unit21 : ∀ a, Known a g 2412 → Known a g 2413 :=
  singleKnown g 2412 (unpack 28 [0x1097000010dd38910a937d0da5abc09d13cd18e9a8d18e5a810be86e70ba161c0bc95e709a53972585a9b2569ad125485130dd9aab097936f0dada7709d93f50ba55b50ba95c30bf564d0da9a650df5afd097536b2518333251432b250c327250832524fc1f324f41eb24f01e524dc0b324d80ab24d00a70d8c2920d8828a0d802860d7c2840898152089014a088c1440854012085000a08480060d797f40888e9008449dc]) (by decide +kernel)
private theorem unit22 : ∀ a, Known a g 2413 → Known a g 2414 :=
  singleKnown g 2413 (unpack 28 [0x1097000010d938910a537d0da5aaa09a139717f9a8d17f5a810bc45070ba15e609d53cd0bed61d0de1abd25586f3107865225b05b30b8151b10845c309c93b9108065909b93a72569ad12585a9b1088663107c5b91f055cd20115f7206960925a1c1f097936f0dada7709d93f50ba55b50ba95c30bf564d0da9a650df5afd097536b252c343251c3392518333251432b250c327250832524fc1f324f41eb24f01e524dc0b324d80ab24d00a70da02a20d902980d8c2920d8828a0d802860d7c2840898152089014a088c1440854012085000a08480060d797f40888e9008449dc]) (by decide +kernel)
private theorem unit23 : ∀ a, Known a g 2414 → Known a g 2415 :=
  singleKnown g 2414 (unpack 28 [0x10bc400009a05060ba15e6097139618495f717495cd170151b18a160911d13cd11953b9113d3a710d938910a537d18f161d097936f09d93f50ba55b50ba95c30bf564d097536b2518333250c32724fc1f324dc0b324d00a70d8c2920d802860898152085401208480060d797f40888e9008449dc]) (by decide +kernel)
theorem up1 : ∀ a, Known a g 2403 → Known a g 2415 := by
  intro a h
  apply unit23 a
  apply unit22 a
  apply unit21 a
  apply unit20 a
  apply unit19 a
  apply unit18 a
  apply unit17 a
  apply unit16 a
  apply unit15 a
  apply unit14 a
  apply unit13 a
  apply unit12 a
  exact h
end Research.Graph9822.ThreeDirect.A137
