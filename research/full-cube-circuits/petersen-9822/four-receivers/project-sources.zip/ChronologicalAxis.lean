import CutGroupLedger
import PaddedScan9822
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles

def axisOf (gs : List DGate) (base j : Nat) : Axis :=
  Fin.ofNat 6 ((gs.drop (j+1-base)).countP Research.Graph9822Resolution.Gate.isAnd)

theorem events_axis_ext (gs : List DGate) (base : Nat) (a b : Nat → Axis)
    (agree : ∀ j, base ≤ j → a j=b j) : gateEvents a gs base = gateEvents b gs base := by
  induction gs generalizing base with
  | nil => rfl
  | cons g tail ih =>
    simp only [gateEvents,ih (base+1) (fun j hj => agree j (by omega))]
    simp [gateEvent,agree base (by omega)]

theorem axis_tail (g : DGate) (gs : List DGate) (base j : Nat) (hj : base+1 ≤ j) :
    axisOf (g::gs) base j = axisOf gs (base+1) j := by
  unfold axisOf
  have h : j+1-base = (j+1-(base+1))+1 := by omega
  simp [h]

theorem chronological_tags (gs : List DGate) (base : Nat) :
    (gateEvents (axisOf gs base) gs base).flatMap axisTags =
        (List.range (gs.countP Research.Graph9822Resolution.Gate.isAnd)).map (Fin.ofNat 6) := by
  induction gs generalizing base with
  | nil => rfl
  | cons g gs ih =>
    simp only [gateEvents,List.flatMap_append,List.flatMap_cons,List.flatMap_nil,List.append_nil]
    rw [events_axis_ext gs (base+1) _ (axisOf gs (base+1)) (axis_tail g gs base),ih]
    have h : axisOf (g::gs) base base = Fin.ofNat 6 (gs.countP Research.Graph9822Resolution.Gate.isAnd) := by
      unfold axisOf
      simp
    cases hg : g.isAnd <;> simp [gateEvent,hg,axisTags,List.countP_cons,h] <;> rw [List.range_succ, List.map_append] <;> rfl

end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.chronological_tags
