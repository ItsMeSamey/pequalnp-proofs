import SixD3Labels9822
import SixH4ProjectionSelection9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral Research.SixH4.PairPartition
open Research.Graph9822.ThreeDirect
def roster38 : List Dir := [(0, 1, 3), (0, 1, 7), (0, 1, 8), (0, 1, 9), (0, 2, 3), (0, 2, 6), (0, 2, 8), (0, 2, 9), (0, 3, 6), (0, 3, 7), (0, 3, 9), (0, 6, 7), (0, 7, 8), (0, 8, 9), (1, 3, 5), (1, 3, 7), (1, 3, 9), (1, 4, 5), (1, 4, 7), (1, 4, 8), (1, 5, 9), (1, 7, 8), (1, 8, 9), (2, 3, 5), (2, 3, 6), (2, 3, 9), (2, 4, 5), (2, 4, 6), (2, 4, 8), (2, 5, 6), (2, 5, 9), (2, 8, 9), (3, 5, 6), (3, 5, 9), (3, 6, 7), (4, 5, 6), (4, 6, 7), (4, 7, 8)]
def labelDir (x y z : V) : Dir := (x.val,y.val,z.val)
set_option maxRecDepth 12000 in
private theorem roster_at0 : ∀ y z : V, labelDir 0 y z ∈ roster38 ↔
    (0 : V)<y ∧ y<z ∧ ¬adj 0 y ∧ ¬adj 0 z ∧ ¬adj y z := by decide +kernel
private theorem roster_at1 : ∀ y z : V, labelDir 1 y z ∈ roster38 ↔
    (1 : V)<y ∧ y<z ∧ ¬adj 1 y ∧ ¬adj 1 z ∧ ¬adj y z := by decide +kernel
private theorem roster_at2 : ∀ y z : V, labelDir 2 y z ∈ roster38 ↔
    (2 : V)<y ∧ y<z ∧ ¬adj 2 y ∧ ¬adj 2 z ∧ ¬adj y z := by decide +kernel
private theorem roster_at3 : ∀ y z : V, labelDir 3 y z ∈ roster38 ↔
    (3 : V)<y ∧ y<z ∧ ¬adj 3 y ∧ ¬adj 3 z ∧ ¬adj y z := by decide +kernel
private theorem roster_at4 : ∀ y z : V, labelDir 4 y z ∈ roster38 ↔
    (4 : V)<y ∧ y<z ∧ ¬adj 4 y ∧ ¬adj 4 z ∧ ¬adj y z := by decide +kernel
private theorem roster_at5 : ∀ y z : V, labelDir 5 y z ∈ roster38 ↔
    (5 : V)<y ∧ y<z ∧ ¬adj 5 y ∧ ¬adj 5 z ∧ ¬adj y z := by decide +kernel
private theorem roster_at6 : ∀ y z : V, labelDir 6 y z ∈ roster38 ↔
    (6 : V)<y ∧ y<z ∧ ¬adj 6 y ∧ ¬adj 6 z ∧ ¬adj y z := by decide +kernel
private theorem roster_at7 : ∀ y z : V, labelDir 7 y z ∈ roster38 ↔
    (7 : V)<y ∧ y<z ∧ ¬adj 7 y ∧ ¬adj 7 z ∧ ¬adj y z := by decide +kernel
private theorem roster_at8 : ∀ y z : V, labelDir 8 y z ∈ roster38 ↔
    (8 : V)<y ∧ y<z ∧ ¬adj 8 y ∧ ¬adj 8 z ∧ ¬adj y z := by decide +kernel
private theorem roster_at9 : ∀ y z : V, labelDir 9 y z ∈ roster38 ↔
    (9 : V)<y ∧ y<z ∧ ¬adj 9 y ∧ ¬adj 9 z ∧ ¬adj y z := by decide +kernel
theorem roster_exact : ∀ x y z : V, labelDir x y z ∈ roster38 ↔
    x<y ∧ y<z ∧ ¬adj x y ∧ ¬adj x z ∧ ¬adj y z := by
  intro x
  have cases_x := (show ∀ x : V, x=0 ∨ x=1 ∨ x=2 ∨ x=3 ∨ x=4 ∨ x=5 ∨ x=6 ∨ x=7 ∨ x=8 ∨ x=9 by decide +kernel) x
  rcases cases_x with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact roster_at0
  · exact roster_at1
  · exact roster_at2
  · exact roster_at3
  · exact roster_at4
  · exact roster_at5
  · exact roster_at6
  · exact roster_at7
  · exact roster_at8
  · exact roster_at9

theorem root_nonedge {A : Fin 6 → Set Word} {a b : Lit} (dist : a.1 ≠ b.1)
    {i j : V} (cover : adj i j → ∀ q, receives A [a] q ∨ receives A [b] q) : ¬adj i j := by
  intro e
  have h := opposed_single (edge_opposing (single_consistent a) (single_consistent b) (cover e))
  have same : opposite a = b := List.mem_singleton.mp h
  exact dist (show (opposite a).1=b.1 from congrArg Prod.fst same)
theorem roster (r : Roots) {A : Fin 6 → Set Word} (L : V → List Lit)
    {x y z : V} (xy : x<y) (yz : y<z)
    (lx : L x=[r.a]) (ly : L y=[r.b]) (lz : L z=[r.c])
    (cover : ∀ i j, adj i j → ∀ q, receives A (L i) q ∨ receives A (L j) q) :
    labelDir x y z ∈ roster38 := by
  apply (roster_exact _ _ _).mpr
  exact ⟨xy,yz,root_nonedge r.ab (by simpa [lx,ly] using cover x y),
    root_nonedge r.ac (by simpa [lx,lz] using cover x z),
    root_nonedge r.bc (by simpa [ly,lz] using cover y z)⟩
end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.roster
