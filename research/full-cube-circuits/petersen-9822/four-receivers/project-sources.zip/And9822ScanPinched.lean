import And9822Pinched
import And9822ForcedGrants

namespace Research.Graph9822.TraceCount
open Graph9822Profiles Graph9822MaskCode ArbitraryScan
noncomputable section
open Classical

def sampleMask (s : Mask6) (w : TraceCount.Word) := decide (direction w.val ∈ s)

theorem scan_samples {b l p n} (h : Scan b l p n) (T : TraceCount.Profile)
    (encoded : ∀ s ∈ p, sampleMask s.2 = activation T s.1) :
    ∀ x ∈ l, Generated T (sampleMask x) := by
  induction h with
  | start =>
    intro x hx
    obtain rfl : x = Set.univ := by simpa using hx
    have eq : sampleMask Set.univ = fun _ => true := by funext w; simp [sampleMask]
    rw [eq]
    exact Generated.const true
  | join h hx hy ih =>
    intro x hx'
    rcases List.mem_cons.mp hx' with rfl | old
    · convert Generated.join (ih encoded _ hx) (ih encoded _ hy) using 1
      funext w
      simp [sampleMask, Set.mem_union]
    · exact ih encoded _ old
  | @split b l p n u i prev hu ih =>
    have hu' := encoded (i,u) List.mem_cons_self
    have raygen (s : Bool) : Generated T (sampleMask (u ∩ side i s)) := by
      have eq : sampleMask (u ∩ side i s) = branch T i s := by
        funext w
        have a := congrFun hu' w
        change decide (direction w.val ∈ u) = (T i).testBit w.val at a
        simp [sampleMask,side,branch,Set.mem_inter_iff,a,direction]
        cases s <;> cases (w.val.testBit i.val) <;> rfl
      rw [eq]
      exact .raw i s
    intro x hx
    rcases List.mem_cons.mp hx with rfl | hx
    · exact raygen true
    rcases List.mem_cons.mp hx with rfl | hx
    · exact raygen false
    · exact ih (fun s hs => encoded s (List.mem_cons_of_mem _ hs)) _ hx

theorem sample_onto (x : Word6) : ∃ w : TraceCount.Word, direction w.val = x := by
  let bits := BitVec.ofBoolListLE (List.ofFn x)
  refine ⟨⟨bits.toNat,by simpa [bits] using bits.isLt⟩,?_⟩
  funext i
  change bits.getLsbD i.val = x i
  unfold bits
  rw [BitVec.getLsbD_ofBoolListLE,List.getD_eq_getElem?_getD,List.getElem?_ofFn,dif_pos i.isLt]
  rfl

theorem scan_pinched_nonraw {b l p n} (scan : Scan b l p n) (T : TraceCount.Profile)
    (enc : ∀ s ∈ p, sampleMask s.2 = activation T s.1)
    (R : Fin 10 → Mask6) (returned : ∀ v, R v ∈ l)
    (realize : ∀ m ∈ FourSaturation.witnesses, ∃ x : Word6,
      ∀ v : Fin 10, x ∈ R v ↔ m.testBit v.val = false)
    {i : TraceCount.Axis} (h : Pinched T i) {s : Mask6} (code : sampleMask s = activation T i)
    (v : Fin 10) : R v ≠ s := by
  have gen := fun v => scan_samples scan T enc _ (returned v)
  have real (m) (hm : m ∈ FourSaturation.witnesses) :
      ∃ w, ∀ v : Fin 10, sampleMask (R v) w = !(m.testBit v.val) := by
    obtain ⟨x,hx⟩ := realize m hm
    obtain ⟨w,ew⟩ := sample_onto x
    exact ⟨w,fun v => by simp [sampleMask,ew,hx v]⟩
  intro eq
  exact pinched_nonraw T i h _ gen real v ((congrArg sampleMask eq).trans code)

end
end Research.Graph9822.TraceCount
#print axioms Research.Graph9822.TraceCount.scan_pinched_nonraw
