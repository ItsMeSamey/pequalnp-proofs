import SixD3SigmaShared9822
namespace Research.Graph9822.ThreeDirect.Sigma
open Research.Graph9822.TwoDirect.Symmetry (vertex)
private theorem legal028_135at0 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 0),arm 1 t ∈ options (1,3,5) mix 0 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal028_135at1 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 1),arm 1 t ∈ options (1,3,5) mix 1 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal028_135at2 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 2),arm 1 t ∈ options (1,3,5) mix 2 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal028_135at3 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 3),arm 1 t ∈ options (1,3,5) mix 3 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal028_135at4 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 4),arm 1 t ∈ options (1,3,5) mix 4 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal028_135at5 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 5),arm 1 t ∈ options (1,3,5) mix 5 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal028_135at6 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 6),arm 1 t ∈ options (1,3,5) mix 6 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal028_135at7 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 7),arm 1 t ∈ options (1,3,5) mix 7 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal028_135at8 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 8),arm 1 t ∈ options (1,3,5) mix 8 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal028_135at9 : ∀ mix : Bool,∀ t∈options (0,2,8) mix (vertex 9),arm 1 t ∈ options (1,3,5) mix 9 := by
  intro mix; cases mix <;> decide +kernel
def spec028_135 : Spec 1 (0,2,8) (1,3,5) where
  origBound := by decide +kernel
  legal := by
    intro v
    have e := (show ∀ k : Fin 10, k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 ∨ k=8 ∨ k=9 by decide +kernel) v
    rcases e with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact legal028_135at0
    · exact legal028_135at1
    · exact legal028_135at2
    · exact legal028_135at3
    · exact legal028_135at4
    · exact legal028_135at5
    · exact legal028_135at6
    · exact legal028_135at7
    · exact legal028_135at8
    · exact legal028_135at9
  named := by decide +kernel
  root := by decide +kernel
  outside := by decide +kernel
  bounded := by decide +kernel
def rooms028_135 {mix : Bool} : Rooms (0,2,8) mix → Rooms (1,3,5) mix := roomsTransfer spec028_135
def shared028_135 : Shared (0,2,8) → Shared (1,3,5) := sharedTransfer spec028_135
end Research.Graph9822.ThreeDirect.Sigma
#print axioms Research.Graph9822.ThreeDirect.Sigma.shared028_135
