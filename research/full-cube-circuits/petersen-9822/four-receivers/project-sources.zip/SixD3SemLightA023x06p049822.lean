import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem g960 : Range (aOK d) (aCl d) g 960 964 := rangeCheck _ _ _ 960 4 (by decide +kernel)
private theorem g964 : Range (aOK d) (aCl d) g 964 968 := rangeCheck _ _ _ 964 4 (by decide +kernel)
private theorem g968 : Range (aOK d) (aCl d) g 968 972 := rangeCheck _ _ _ 968 4 (by decide +kernel)
private theorem g972 : Range (aOK d) (aCl d) g 972 976 := rangeCheck _ _ _ 972 4 (by decide +kernel)
private theorem g976 : Range (aOK d) (aCl d) g 976 980 := rangeCheck _ _ _ 976 4 (by decide +kernel)
private theorem g980 : Range (aOK d) (aCl d) g 980 984 := rangeCheck _ _ _ 980 4 (by decide +kernel)
theorem light6p4 : Range (aOK d) (aCl d) g 960 984 := rangeAppend g960 (rangeAppend g964 (rangeAppend g968 (rangeAppend g972 (rangeAppend g976 (g980)))))
end Research.Graph9822.ThreeDirect.A023
