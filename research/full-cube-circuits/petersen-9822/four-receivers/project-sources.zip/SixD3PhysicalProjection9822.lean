import SixD3SignedDescription9822
import SixD3HelperLabels9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral (Word Lit ray receives)
open Research.SixH4.PairPartition (V)
open Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (Arm edge opposes)
open PEqualNP.Outside.L_meta_9822.Receivers
noncomputable section
theorem ordinary_projection (r : Roots) (P : Fin 6→Set Word) (R : V→Set Word)
    (d : Dir) (L : V→List Lit) (exact : ExactReceivers (fun v q=>q∈R v))
    (desc : ∀ v w,w∈R v ↔ receives P (L v) w)
    (sel : ∀ v,v<10 → normalized r L v∈options d false v)
    (opp : ∀ u v,u<v → v<10 → edge u v=true → opposes (normalized r L u) (normalized r L v)=true) :
    Nonempty (Rooms d false) := by
  obtain ⟨q,read,_⟩ := sample_original exact (cube r)
  exact ⟨rooms_of_masks (mask r P) q (normalized r L) read (numeric_meaning r P L R desc)
    sel opp (slot_disjoint r P)⟩

theorem shared_projection (r : Roots) (P : Fin 6→Set Word) (R : V→Set Word)
    (d : Dir) (L : V→List Lit) (H : Set Word) (Hlit : List Lit)
    (exact : ExactReceivers (fun v q=>q∈R v))
    (desc : ∀ v w,w∈R v ↔ receives P (L v) w)
    (hdesc : ∀ w,w∈H ↔ receives P Hlit w)
    (shape : ∀ v,(∃ t,L v=[t]) ∨ Shape true (L v))
    (sel : ∀ v,v<10 → normalized r L v∈options d true v)
    (opp : ∀ u v,u<v → v<10 → edge u v=true → opposes (normalized r L u) (normalized r L v)=true)
    (hOK : normArm r Hlit∈pairs) (link : ∀ v : V,(L v).length=3 → ∀ t∈Hlit,t∈L v)
    (roots : RootRows d r P R) (source : ∀ i,Choice r P R d H i)
    (edges : ∀ a b : V,edge a.val b.val=true ↔ ∀ w,w∈R a ∨ w∈R b)
    (anti : ∀ a b : V,a≠b → ¬R a⊆R b) : Nonempty (Shared d) := by
  have meaning := numeric_meaning r P L R desc
  obtain ⟨o,orig⟩ := choose_names r P R d H (normalized r L) (normArm r Hlit) source meaning
    (fun w=>(hdesc w).trans (norm_meaning r P Hlit w))
  obtain ⟨full,ordinary⟩ := root_constraints r P R d (normalized r L) o roots meaning
    (fun j hj=>(orig j hj).2.2) (pair_of_len r P L R desc shape) edges anti
  exact shared_of_masks (mask r P) _ (normArm r Hlit) o (cube r) exact meaning sel opp
    (slot_disjoint r P) hOK (linked r Hlit L link) (fun j hj=>(orig j hj).1)
    (fun j hj=>(orig j hj).2.1) full ordinary (fun w _ j _=>cube_wrong r P w j)
    (fun u v h=>(edges u v).mp h)
end
end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.ordinary_projection
#print axioms Research.SixD3.Labels.shared_projection
