import SixD3Roots9822
import SixD3Arms9822
import SixD3Collapse9822
namespace Research.Graph9822.ArbitraryScan
open Research.SixD3.Labels Research.Graph9822Profiles Research.Graph9822Profiles.Fresh
open Research.SixH4.DirectLiteral (Lit receives)
noncomputable section
def ArmMeans (P : Axis→Mask) (m : Mask) (arm : List Lit) := ∀q,q∈m ↔ receives P arm q
structure PhysicalArms (P : Axis→Mask) (R : Fin 10→Mask) (d : ThreeRoots P R)
    (mix : Bool) (helper : List Lit) where
  L : Fin 10→List Lit
  lx : L d.x=[d.roots.a]
  ly : L d.y=[d.roots.b]
  lz : L d.z=[d.roots.c]
  shape : ∀v,v≠d.x → v≠d.y → v≠d.z → Shape mix (L v)
  meaning : ∀v,ArmMeans P (R v) (L v)
  linked : ∀v,(L v).length=3 → ∀ k∈helper,k∈L v

private theorem one_means (P : Axis→Mask) (a : Lit) : ArmMeans P (Research.Graph9822Profiles.Fresh.value P a) [a] := by
  intro q
  simp [receives,Research.Graph9822Profiles.Fresh.value,Research.SixH4.DirectLiteral.ray,side,Research.SixH4.DirectLiteral.side]
private theorem two_means (P : Axis→Mask) (a c : Lit) :
    ArmMeans P (Research.Graph9822Profiles.Fresh.value P a∪Research.Graph9822Profiles.Fresh.value P c) [a,c] := by
  intro q
  simp [receives,Research.Graph9822Profiles.Fresh.value,Research.SixH4.DirectLiteral.ray,side,Research.SixH4.DirectLiteral.side]
private theorem three_means (P : Axis→Mask) (a c z : Lit) :
    ArmMeans P ((Research.Graph9822Profiles.Fresh.value P a∪Research.Graph9822Profiles.Fresh.value P c)∪Research.Graph9822Profiles.Fresh.value P z) [a,c,z] := by
  intro q
  simp [receives,Research.Graph9822Profiles.Fresh.value,Research.SixH4.DirectLiteral.ray,side,Research.SixH4.DirectLiteral.side,or_assoc]
theorem arm_choice {P : Axis→Mask} {R : Fin 10→Mask} (d : ThreeRoots P R) (mix : Bool)
    (helper : List Lit)
    (rest : ∀ v,¬RayValue P (R v) → ∃ l : List Lit,Shape mix l ∧ ArmMeans P (R v) l ∧
       (l.length=3 → ∀ k∈helper,k∈l)) : Nonempty (PhysicalArms P R d mix helper) := by
  classical
  have nd {v} (x : v≠d.x) (y : v≠d.y) (z : v≠d.z) : ¬RayValue P (R v) := by
    intro t
    rcases (d.exactly v).mp t with h|h|h <;> contradiction
  let L (v : Fin 10) := if x : v=d.x then [d.roots.a] else if y : v=d.y then [d.roots.b]
    else if z : v=d.z then [d.roots.c] else (rest v (nd x y z)).choose
  have lx : L d.x=[d.roots.a] := by simp [L]
  have ly : L d.y=[d.roots.b] := by simp [L,d.xy.ne.symm]
  have lz : L d.z=[d.roots.c] := by simp [L,(lt_trans d.xy d.yz).ne.symm,d.yz.ne.symm]
  refine ⟨⟨L,lx,ly,lz,?_,?_,?_⟩⟩
  · intro v x y z
    simpa [L,x,y,z] using (rest v (nd x y z)).choose_spec.1
  · intro v
    by_cases x : v=d.x
    · subst v; rw [lx,d.rx]; exact one_means P d.roots.a
    by_cases y : v=d.y
    · subst v; rw [ly,d.ry]; exact one_means P d.roots.b
    by_cases z : v=d.z
    · subst v; rw [lz,d.rz]; exact one_means P d.roots.c
    simpa [L,x,y,z] using (rest v (nd x y z)).choose_spec.2.1
  · intro v length
    by_cases x : v=d.x
    · subst v; simp [lx] at length
    by_cases y : v=d.y
    · subst v; simp [ly] at length
    by_cases z : v=d.z
    · subst v; simp [lz] at length
    have tail := (rest v (nd x y z)).choose_spec.2.2
    simpa [L,x,y,z] using tail (by simpa [L,x,y,z] using length)

theorem ordinary_arms {P : Axis→Mask} {R : Fin 10→Mask} (d : ThreeRoots P R)
    (plain : ∀v,¬RayValue P (R v) → DistinctPair P (R v)) : Nonempty (PhysicalArms P R d false []) := by
  apply arm_choice
  intro v nd
  obtain ⟨i,s,j,t,ne,eq⟩ := plain v nd
  exact ⟨[(i,s),(j,t)],Or.inl ⟨_,_,ne,rfl⟩,by rw [eq]; exact two_means P (i,s) (j,t),by simp⟩
theorem mixed_arms {P : Axis→Mask} {R : Fin 10→Mask} (d : ThreeRoots P R) (a c : Lit)
    (ac : a.1≠c.1) (fixed : ∀v,¬RayValue P (R v) → FixedRaw P a c (R v)) :
    Nonempty (PhysicalArms P R d true [a,c]) := by
  apply arm_choice
  intro v nd
  rcases fixed v nd with pair|⟨z,za,zc,eq⟩
  · obtain ⟨i,s,j,t,ne,eq⟩ := pair
    exact ⟨[(i,s),(j,t)],Or.inl ⟨_,_,ne,rfl⟩,by rw [eq]; exact two_means P (i,s) (j,t),by simp⟩
  · exact ⟨[a,c,z],Or.inr ⟨rfl,a,c,z,ac,za.symm,zc.symm,rfl⟩,
      by rw [eq]; exact three_means P a c z,by simp⟩
end
end Research.Graph9822.ArbitraryScan
