import And9822CommonScan
import Mathlib.Data.Finset.Prod

namespace Research.Graph9822.NumericBank
open CommonBank

/-- Distinct source values may be paired in ascending unsigned mask order. -/
def unions (s : Finset Nat) : Finset Nat :=
  ((s ×ˢ s).filter (fun p => p.1 < p.2)).image (fun p => p.1 ||| p.2)

def terminal (s : Finset Nat) := s ∪ unions s

theorem pair_mem {s : Finset Nat} {a b : Nat} (ha : a ∈ s) (hb : b ∈ s) :
    a ||| b ∈ terminal s := by
  rcases lt_trichotomy a b with h | h | h
  · exact Finset.mem_union_right _ (Finset.mem_image.mpr ⟨(a,b),
      Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨ha,hb⟩,h⟩,rfl⟩)
  · subst b
    simpa [terminal] using (show a ∈ s ∨ a ∈ unions s from Or.inl ha)
  · exact Finset.mem_union_right _ (Finset.mem_image.mpr ⟨(b,a),
      Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hb,ha⟩,h⟩,Nat.or_comm b a⟩)

/-- Second helpers independent of the first are considered in sorted order.
A dependent second helper combines the first with one base value. -/
def second (base : Finset Nat) (x : Nat) : Finset Nat :=
  ((unions base).filter (fun y => x ≤ y)) ∪ base.image (fun v => x ||| v)

def libraries (base : Finset Nat) (spare : Nat) : Finset (Finset Nat) :=
  {base} ∪ ((unions base).biUnion fun x =>
    (if 1 ≤ spare then {insert x base} else ∅) ∪
    (if 2 ≤ spare then ((second base x).erase x).image
      (fun y => insert y (insert x base)) else ∅))

private theorem zero_mem (b : Finset Nat) (k) : b ∈ libraries b k := by
  exact Finset.mem_union_left _ (by simp)
private theorem one_mem {b : Finset Nat} {k x : Nat} (hx : x ∈ unions b) (h : 1 ≤ k) :
    insert x b ∈ libraries b k := by
  apply Finset.mem_union_right _
  exact Finset.mem_biUnion.mpr ⟨x,hx,Finset.mem_union_left _ (by simp [h])⟩
private theorem two_mem {b : Finset Nat} {k x y : Nat} (hx : x ∈ unions b)
    (hy : y ∈ second b x) (ne : y ≠ x) (h : 2 ≤ k) :
    insert y (insert x b) ∈ libraries b k := by
  apply Finset.mem_union_right _
  apply Finset.mem_biUnion.mpr
  refine ⟨x,hx,Finset.mem_union_right _ ?_⟩
  simp only [if_pos h]
  exact Finset.mem_image.mpr ⟨y,Finset.mem_erase.mpr ⟨ne,hy⟩,rfl⟩

private theorem classify {b : Finset Nat} {x y : Nat} (hy : y ∈ terminal (insert x b)) :
    y ∈ insert x b ∨ y ∈ unions b ∨ ∃ v ∈ b, y = x ||| v := by
  rcases Finset.mem_union.mp hy with h | h
  · exact Or.inl h
  obtain ⟨⟨u,v⟩,hu,rfl⟩ := Finset.mem_image.mp h
  obtain ⟨p,lt⟩ := Finset.mem_filter.mp hu
  obtain ⟨au,av⟩ := Finset.mem_product.mp p
  rcases Finset.mem_insert.mp au with eu | bu <;> rcases Finset.mem_insert.mp av with ev | bv
  · exfalso
    exact (ne_of_lt lt) (eu.trans ev.symm)
  · exact Or.inr (Or.inr ⟨v,bv,congrArg (fun a => a ||| v) eu⟩)
  · exact Or.inr (Or.inr ⟨u,bu,(congrArg (fun a => u ||| a) ev).trans (Nat.or_comm u x)⟩)
  · exact Or.inr (Or.inl (Finset.mem_image.mpr ⟨(u,v),
      Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨bu,bv⟩,lt⟩,rfl⟩))

private theorem one_cover {b : Finset Nat} {k x : Nat} (hx : x ∈ terminal b) (hk : 1 ≤ k) :
    insert x b ∈ libraries b k := by
  rcases Finset.mem_union.mp hx with hb|hu
  · rw [Finset.insert_eq_of_mem hb]; exact zero_mem _ _
  · exact one_mem hu hk

theorem two_cover {b : Finset Nat} {k x y : Nat} (hx : x ∈ terminal b)
    (hy : y ∈ terminal (insert x b)) (hk : 2 ≤ k) :
    insert y (insert x b) ∈ libraries b k := by
  rcases Finset.mem_union.mp hx with old|fresh
  · rw [Finset.insert_eq_of_mem old] at hy ⊢
    exact one_cover hy (by omega)
  rcases classify hy with old|indep|⟨v,bv,rfl⟩
  · rw [Finset.insert_eq_of_mem old]; exact one_mem fresh (by omega)
  · by_cases eq : x=y
    · subst y; simp only [Finset.insert_idem]; exact one_mem fresh (by omega)
    by_cases sorted : x≤y
    · exact two_mem fresh (Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨indep,sorted⟩)) (Ne.symm eq) hk
    rw [Finset.insert_comm]
    exact two_mem indep (Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨fresh,by omega⟩)) eq hk
  · by_cases eq : x ||| v = x
    · rw [eq,Finset.insert_idem]; exact one_mem fresh (by omega)
    exact two_mem fresh (Finset.mem_union_right _ (Finset.mem_image.mpr ⟨v,bv,rfl⟩)) eq hk

/-- Translate one semantic bank even when a union is idempotent or duplicates
an existing base value. The second independent union may be reordered. -/
theorem encode_helpers {α : Type*} (code : Set α → Nat)
    (cup : ∀ a b, code (a ∪ b) = code a ||| code b)
    {prim : Set α → Prop} {gr : Finset (Set α)} {hs : List (Set α)}
    (built : Helpers prim gr hs) (base : Finset Nat)
    (sources : ∀ m, prim m ∨ m ∈ gr → code m ∈ base)
    {k : Nat} (budget : hs.length ≤ k) (little : k ≤ 2) :
    ∃ B ∈ libraries base k, ∀ m, Source prim gr hs m → code m ∈ B := by
  classical
  have src0 (m) (hm : Source prim gr [] m) : code m ∈ base := by
    rcases hm with h|h|h
    · exact sources m (Or.inl h)
    · exact sources m (Or.inr h)
    · simp at h
  have conv {s : Finset Nat} {q : Set α → Prop} (map : ∀ m,q m → code m ∈ s)
      {m} (hm : PairOf q m) : code m ∈ terminal s := by
    obtain ⟨a,b,ha,hb,rfl⟩ := hm
    rw [cup]; exact pair_mem (map _ ha) (map _ hb)
  rcases atMostTwo built (budget.trans little) with h|⟨x,h,hx⟩|⟨x,y,h,hx,hy⟩
  · subst hs; exact ⟨base,zero_mem _ _,src0⟩
  · subst hs
    refine ⟨_,one_cover (conv src0 hx) (by simpa using budget),?_⟩
    intro m hm
    rcases hm with hp|hg|hl
    · exact Finset.mem_insert_of_mem (sources _ (Or.inl hp))
    · exact Finset.mem_insert_of_mem (sources _ (Or.inr hg))
    · have e : m=x := by simpa using hl
      simp [e]
  · subst hs
    have src1 (m) (hm : Source prim gr [x] m) : code m ∈ insert (code x) base := by
      rcases hm with hp|hg|hl
      · exact Finset.mem_insert_of_mem (sources _ (Or.inl hp))
      · exact Finset.mem_insert_of_mem (sources _ (Or.inr hg))
      · have e : m=x := by simpa using hl
        simp [e]
    refine ⟨_,two_cover (conv src0 hx) (conv src1 hy) (by simpa using budget),?_⟩
    intro m hm
    rcases hm with hp|hg|hl
    · exact Finset.mem_insert_of_mem (src1 m (Or.inl hp))
    · exact Finset.mem_insert_of_mem (src1 m (Or.inr (Or.inl hg)))
    · rcases List.mem_cons.mp hl with e|e
      · simp [e]
      · exact Finset.mem_insert_of_mem (src1 m (Or.inr (Or.inr e)))

end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.encode_helpers
