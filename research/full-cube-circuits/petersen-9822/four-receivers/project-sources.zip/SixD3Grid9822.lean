import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.Packed
open PEqualNP.Library.LRAT
abbrev Grid := Array (Array Nat)
def slot (g : Grid) (i : Nat) := ((g[i/32]?.getD #[])[i%32]?).getD (1 <<< 35)
def ruleAt (g : Grid) (i : Nat) := (slot g i) % (2^35)
noncomputable def stored (g : Grid) (i : Nat) := unpackWord 14 16383 256 ((slot g i) >>> 35) []
noncomputable def seedGood (ok : Nat → Bool) (cl : Nat → Clause) (g : Grid) (i : Nat) :=
  let w := ruleAt g i
  good ok cl w && (numeric (cl w)).all (stored g i).contains
def Range (ok : Nat → Bool) (cl : Nat → Clause) (g : Grid) (lo hi : Nat) :=
  ∀ i, lo≤i → i<hi → seedGood ok cl g i=true
theorem rangeCheck (ok : Nat → Bool) (cl : Nat → Clause) (g : Grid) (lo n : Nat)
    (c : (List.range n).all (fun k=>seedGood ok cl g (lo+k))=true) : Range ok cl g lo (lo+n) := by
  intro i a b
  have h := List.all_eq_true.mp c (i-lo) (List.mem_range.mpr (by omega))
  simpa [show lo+(i-lo)=i by omega] using h
theorem rangeAppend {ok cl g lo mid hi} (L : Range ok cl g lo mid) (R : Range ok cl g mid hi) :
    Range ok cl g lo hi := by
  intro i hl hh
  by_cases h : i<mid
  · exact L i hl h
  · exact R i (by omega) hh
def Known (a : Nat → Bool) (g : Grid) (n : Nat) := ∀ i, i<n → ClauseSat a (stored g i)
noncomputable def entries (g : Grid) (ids : List Nat) := ids.map (fun i => (i+1)::stored g i)
theorem inputs {a g n ids} (old : Known a g n) (valid : ids.all (fun i=>decide (i<n))=true) :
    EntriesSat a (entries g ids) := by
  intro e he
  obtain ⟨i,hi,rfl⟩ := List.mem_map.mp he
  exact old i (of_decide_eq_true (List.all_eq_true.mp valid i hi))
theorem advance (g : Grid) (lo n : Nat) (ins : List Nat) (W : Nat) (words : List Nat)
    (ok : ins.all (fun i=>decide (i<lo))=true)
    (checked : checkSeg (entries g ins) W words (entries g ((List.range n).map (lo+·)))=true) :
    ∀ a, Known a g lo → Known a g (lo+n) := by
  intro a old i endBound
  by_cases isOld : i<lo
  · exact old i isOld
  · have h := checkSeg_sound _ _ _ _ checked a (inputs old ok)
    have mem : i∈(List.range n).map (lo+·) :=
      List.mem_map.mpr ⟨i-lo,List.mem_range.mpr (by omega),by omega⟩
    exact h ((i+1)::stored g i) (List.mem_map.mpr ⟨i,mem,rfl⟩)
theorem finish (g : Grid) (lo : Nat) (ins : List Nat) (W : Nat) (words : List Nat)
    (ok : ins.all (fun i=>decide (i<lo))=true)
    (checked : checkLast (entries g ins) W words=true) :
    ∀ a, Known a g lo → False := by
  intro a old
  exact checkLast_sound _ _ _ checked a (inputs old ok)
theorem seedKnown (e : Env) (g : Grid) (n : Nat) (ok : Nat → Bool) (cl : Nat → Clause)
    (rg : Range ok cl g 0 n) (laws : ∀ w, ok w=true → Sat e (cl w)) :
    Known (fun k=>e.val (uncode k)) g n := by
  intro i hi
  have yes := rg i (Nat.zero_le i) hi
  obtain ⟨goodw,sub⟩ := Bool.and_eq_true_iff.mp yes
  obtain ⟨legal,rt⟩ := Bool.and_eq_true_iff.mp goodw
  obtain ⟨l,hl,hval⟩ := transport e rt (laws _ legal)
  exact ⟨l,List.contains_iff_mem.mp (List.all_eq_true.mp sub l hl),hval⟩
theorem gridA (d : Dir) (g : Grid) (n : Nat) (rg : Range (aOK d) (aCl d) g 0 n)
    (bad : ∀ a, Known a g n → False) : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact bad _ (seedKnown (envOf p.toRooms p.helper p.origin) _ _ _ _ rg
    (fun w v => (shared w).sound p v))
theorem gridB (d : Dir) (g : Grid) (n : Nat) (rg : Range bOK (bCl d) g 0 n)
    (bad : ∀ a, Known a g n → False) : ¬ Nonempty (Rooms d false) := by
  rintro ⟨p⟩
  exact bad _ (seedKnown (envOf p [] (fun _=>0)) _ _ _ _ rg
    (fun w v => (basic w).sound p _ _ v))
end Research.Graph9822.ThreeDirect.Packed
