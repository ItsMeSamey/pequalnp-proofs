import SixD3GridUnits9822
import SixD3GridDataA1359822
namespace Research.Graph9822.ThreeDirect.A135
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit36 : ∀ a, Known a g 1911 → Known a g 1912 :=
  singleKnown g 1911 (unpack 28 [0x11c300000a7994a1b918471ba98571bb987d1c118e91c219131bd990f1bed9471bf99e91c419ed1c5192d1c599651c65a071c69a151c6da250aa98690b259931d206530ccc6f20ac58e50a8d8390a8181f0ab58a50a7d81b1ce83331cdc3271cb01f31c800b31c700a7098c292098028607d4152073c012072c006097934407c4e9007249dc]) (by decide +kernel)
private theorem unit37 : ∀ a, Known a g 1912 → Known a g 1913 :=
  singleKnown g 1912 (unpack 28 [0x113d80000c25d1c13d5d0b0c55ccf0cf5d550c29cbd0c2dccb1ce43311cdc3271ca41f11c9c1eb1c7c0b11c740ab1c700a70988290098028607d015007cc14a0738010073000a072c006097934407c4e9007249dc]) (by decide +kernel)
private theorem unit38 : ∀ a, Known a g 1913 → Known a g 1914 :=
  singleKnown g 1913 (unpack 28 [0x11cb40001c91f361d105b30b045120b01f511ca9f2f1ce83331ce43311cb01f31ca1f271c99f2d1c95f251c740ab098c2920988290097c28507d415207d015007cc14a07c8144073000a0728005097934407c4e9007249dc]) (by decide +kernel)
private theorem unit39 : ∀ a, Known a g 1914 → Known a g 1915 :=
  singleKnown g 1914 (unpack 28 [0x10eac00001de0a701f60ab01d2071]) (by decide +kernel)
private theorem unit40 : ∀ a, Known a g 1915 → Known a g 1916 :=
  singleKnown g 1915 (unpack 28 [0x104240000ba6054025205101f6047]) (by decide +kernel)
private theorem unit41 : ∀ a, Known a g 1916 → Known a g 1917 :=
  singleKnown g 1916 (unpack 28 [0x10ec400002aa0ab02a20a90296073]) (by decide +kernel)
private theorem unit42 : ∀ a, Known a g 1917 → Known a g 1918 :=
  singleKnown g 1917 (unpack 28 [0x1079000001ce0a5016e09d0036043]) (by decide +kernel)
private theorem unit43 : ∀ a, Known a g 1918 → Known a g 1919 :=
  singleKnown g 1918 (unpack 28 [0x105740000bfa090056608d0c00653055e0471ce83331cb01f3098c29207d4152097934407c4e90]) (by decide +kernel)
private theorem unit44 : ∀ a, Known a g 1919 → Known a g 1920 :=
  singleKnown g 1919 (unpack 28 [0x10bf800004ae091036a08d01c6047]) (by decide +kernel)
private theorem unit45 : ∀ a, Known a g 1920 → Known a g 1921 :=
  singleKnown g 1920 (unpack 28 [0x114e400007e525814c522113c5243139120b13591e1128d23112591f912251cf10d513b109512d1055121147124d145921509452af092d2a108f12950c4465013211c311f91b109652bf08b128b0855279081515d111914b0c4865207ed117082519d07e91051cf83431cec3351cd42031cc01f51c8c0c31c800b31c7c0b109a02a2099029407e016207d81540748022073c0120738010097934407c4e9007249dc]) (by decide +kernel)
private theorem unit46 : ∀ a, Known a g 1921 → Known a g 1922 :=
  singleKnown g 1921 (unpack 28 [0x106c000005a8938064898106b08f106748e305fc8151cc86f40710963063892705ec8011d206531cbc6f207209bd06d49931cd87020650863060c85f05b87c505e47ef062c8df05b07b7060083d05ac7b31ce83331ce43311cb01f31ca41f11c800b31c7c0b1098c292098829007e016207d815407d415207d0150073c0120738010097934407c4e9007249dc]) (by decide +kernel)
private theorem unit47 : ∀ a, Known a g 1922 → Known a g 1923 :=
  singleKnown g 1922 (unpack 28 [0x108100001d145b507e514a0c9851408f92ef08ed29508d524d08c9215086d1c3082d1b107f11210bb03d50ba83d014352e513f928b139520b15452af12f12d312c9279125d1f9155930911bd171118115d10d913b07ed117082519d07e91051cf83431cec3351ce43311cd42031cc01f51ca41f11c8c0c309a02a20990294098829007e016207d815407d01500748022097934407c4e9007249dc]) (by decide +kernel)
theorem up3 : ∀ a, Known a g 1911 → Known a g 1923 := by
  intro a h
  apply unit47 a
  apply unit46 a
  apply unit45 a
  apply unit44 a
  apply unit43 a
  apply unit42 a
  apply unit41 a
  apply unit40 a
  apply unit39 a
  apply unit38 a
  apply unit37 a
  apply unit36 a
  exact h
end Research.Graph9822.ThreeDirect.A135
