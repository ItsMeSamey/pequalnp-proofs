import FourSaturationData
namespace PEqualNP.Outside.L_meta_9822.Receivers
open Research.Graph9822.FourSaturation

theorem negativeRowsSeparate : ∀ u v : Fin 10, u ≠ v →
    witnesses.any (fun m => !m.testBit u.val && m.testBit v.val) = true := by decide +kernel

theorem negativeRowsOmitTwo : ∀ u v : Fin 10,
    witnesses.any (fun m => !m.testBit u.val && !m.testBit v.val) = true := by decide +kernel

structure ExactReceivers {α : Type} (reaches : Fin 10 → α → Prop) : Prop where
  realize : ∀ m ∈ witnesses, ∃ a, ∀ v : Fin 10, reaches v a ↔ m.testBit v.val = false

theorem indispensable {α : Type} {reaches : Fin 10 → α → Prop} (r : ExactReceivers reaches)
    (u v : Fin 10) (different : u ≠ v) : ∃ a, reaches u a ∧ ¬ reaches v a := by
  obtain ⟨m,hm,e⟩ := List.any_eq_true.mp (negativeRowsSeparate u v different)
  obtain ⟨a,h⟩ := r.realize m hm
  have bits : m.testBit u.val = false ∧ m.testBit v.val = true := by simpa using e
  refine ⟨a,(h u).2 bits.1,?_⟩
  intro hv
  have bad := (h v).mp hv
  simp [bits.2] at bad

theorem overlap {α : Type} {reaches : Fin 10 → α → Prop} (r : ExactReceivers reaches)
    (u v : Fin 10) : ∃ a, reaches u a ∧ reaches v a := by
  obtain ⟨m,hm,e⟩ := List.any_eq_true.mp (negativeRowsOmitTwo u v)
  obtain ⟨a,h⟩ := r.realize m hm
  have bits : m.testBit u.val = false ∧ m.testBit v.val = false := by simpa using e
  exact ⟨a,(h u).2 bits.1,(h v).2 bits.2⟩

theorem distinctDirectAxes {α β : Type} {reaches : Fin 10 → α → Prop}
    (r : ExactReceivers reaches) (active : β → α → Prop) (bit : β → α → Bool)
    {u v : Fin 10} (hne : u ≠ v) {i j : β} {su sv : Bool}
    (hu : ∀ a, reaches u a ↔ active i a ∧ bit i a = su)
    (hv : ∀ a, reaches v a ↔ active j a ∧ bit j a = sv) : i ≠ j := by
  rintro rfl
  obtain ⟨t,ru,rv⟩ := overlap r u v
  have eq := ((hu t).1 ru).2.symm.trans ((hv t).1 rv).2
  obtain ⟨w,wu,wv⟩ := indispensable r u v hne
  exact wv ((hv w).2 ⟨((hu w).1 wu).1,((hu w).1 wu).2.trans eq⟩)

end PEqualNP.Outside.L_meta_9822.Receivers
