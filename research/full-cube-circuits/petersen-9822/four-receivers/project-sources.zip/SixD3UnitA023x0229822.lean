import SixD3GridUnits9822
import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit231 : ∀ a, Known a g 2789 → Known a g 2790 :=
  singleKnown g 2789 (unpack 28 [0x102400000fea08801d206707ba0762b9207f28f2097]) (by decide +kernel)
private theorem unit232 : ∀ a, Known a g 2790 → Known a g 2791 :=
  singleKnown g 2790 (unpack 28 [0x1026800007920602b8d1dc2b41e6c104de67025e08d025606b283e0592b8523e2b51e6f029609528f2097]) (by decide +kernel)
private theorem unit233 : ∀ a, Known a g 2791 → Known a g 2792 :=
  singleKnown g 2791 (unpack 28 [0x104c400007920602b8d1dc2b41e6c104de67044e08d041606b07ba07e2b9a07715b5e4d15a5e7315a1e551595e4915bde77155dd1b15b9e59283e05915cde7d2b8a05515d1e7f2b95e632b8523e2b51e6f28f2097]) (by decide +kernel)
private theorem unit234 : ∀ a, Known a g 2792 → Known a g 2793 :=
  singleKnown g 2792 (unpack 28 [0x12b400001675e731671e63166de551661e491641e3116a5e6716a9e771695e4d16a1e5916cde6d16d1e7d16d5e6f16d9e7f]) (by decide +kernel)
private theorem unit235 : ∀ a, Known a g 2793 → Known a g 2794 :=
  singleKnown g 2793 (unpack 28 [0x12b580000fb1e9907e52e1106deab05c20a507b923f055e07f07a5207052606f2a8dea307911dd04ea061077519d03b20470296077022a06701ba0590f89d77077d1bf014604d2b9e0942ba12872b51e6f]) (by decide +kernel)
private theorem unit236 : ∀ a, Known a g 2794 → Known a g 2795 :=
  singleKnown g 2794 (unpack 28 [0x12b44000229d85321858352119829244594b2479955249199d157d23f14e120714551dd13d91bf0f7c66124b196124c59a924f99c723b18d723d193923ed981240d8cb24218e92ba128712a119d113d113]) (by decide +kernel)
private theorem unit237 : ∀ a, Known a g 2795 → Known a g 2796 :=
  singleKnown g 2795 (unpack 28 [0x104a80002ba60542b9e0942ba9e312ba1287]) (by decide +kernel)
private theorem unit238 : ∀ a, Known a g 2796 → Known a g 2797 :=
  singleKnown g 2796 (unpack 28 [0x129fc0001299db11291d691289d211281d1f1249d151231d110ea9d19077833c2811d312831cfb2b5919c257c1fd25640bd074815c060c01c072cc3805f8784]) (by decide +kernel)
private theorem unit239 : ∀ a, Known a g 2797 → Known a g 2798 :=
  singleKnown g 2797 (unpack 28 [0x112a0000076d19c113d1132bb1e300fb1e992b8de6d10a1e7d1055e7710b5e7f0ff5e7300660991045e591079e5d0fdde5510a9e6f005e095005a08300560731031e4d0fc9e49004e093004a08107e52e1106deab00460a52815ed92865ec92a8dea307cd287004209107b923f003e07f07a52070fa1dbf003a06f0f95d9507911dd00360610f89d77077d1bf0032055104de67002e08d002a07b002606b002205d001e0510fe9e6300160890012077000e067000a059000604d2bae03428f2097]) (by decide +kernel)
private theorem unit240 : ∀ a, Known a g 2798 → Known a g 2799 :=
  singleKnown g 2798 (unpack 28 [0x1216000028bd834249d92924a996124b99a924d19b724e59c70f146612239843228d853243d94b242991323a58d723b990123c993923e198124158e9]) (by decide +kernel)
private theorem unit241 : ∀ a, Known a g 2799 → Known a g 2800 :=
  singleKnown g 2799 (unpack 28 [0x1210000028bd828246191d2471955248599d24cd9b724e19c70ee8661222d8432281853243994b24018cb2425913239d8b923b590123c593923dd981]) (by decide +kernel)
private theorem unit242 : ∀ a, Known a g 2800 → Known a g 2801 :=
  singleKnown g 2800 (unpack 28 [0x11b940002859b6607fd3802809a9f080536b080135d08413f5258c33125701f125580b1075c290073c15006000100750e94072cc3805f8784]) (by decide +kernel)
theorem up22 : ∀ a, Known a g 2789 → Known a g 2801 := by
  intro a h
  apply unit242 a
  apply unit241 a
  apply unit240 a
  apply unit239 a
  apply unit238 a
  apply unit237 a
  apply unit236 a
  apply unit235 a
  apply unit234 a
  apply unit233 a
  apply unit232 a
  apply unit231 a
  exact h
end Research.Graph9822.ThreeDirect.A023
