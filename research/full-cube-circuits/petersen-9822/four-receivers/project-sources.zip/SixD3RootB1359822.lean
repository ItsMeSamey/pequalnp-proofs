import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B135
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (1,3,5)
private noncomputable def rules : List Nat := unpack 35 [0x40d01922101a0323a20340646240680c8a480d01911101a0321c20340642e40680c840800000040000000060]
private def keys : List Nat := (List.range 10).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x2000ada800ab86003ae68012bb2005af3801abee007b048022c3a009d3b000400000a] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B135
