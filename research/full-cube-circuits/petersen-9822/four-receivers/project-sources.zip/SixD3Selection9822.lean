import SixD3Arms9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral Research.SixH4.PairPartition Research.Graph9822Resolution
open Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (opposes edge)
theorem selected_roots {A : Fin 6 → Set Word} (L : V → List Lit)
    (wit : ∀ u : Fin 16, ∃ q : Word, ∀ v : V, receives A (L v) q ↔ v.val ∉ independentSets u)
    (covers : ∀ i j, adj i j → ∀ q, receives A (L i) q ∨ receives A (L j) q)
    {x v : V} {a : Lit} (root : L x=[a]) (other : x≠v) (coh : consistent (L v)) :
    a∉L v ∧ (adj v x → mate a ∈ L v) := by
  constructor
  · intro yes
    obtain ⟨u,hv,hx⟩ := separated_rooms x v other
    obtain ⟨q,hq⟩ := wit u
    obtain ⟨b,hb,hit⟩ := (hq x).2 hx
    rw [root,List.mem_singleton] at hb
    exact (hq v).1 ⟨a,yes,hb ▸ hit⟩ hv
  · intro e
    have sym : ∀ v x : V, adj v x → adj x v := by decide +kernel
    have cx := covers x v (sym _ _ e)
    rw [root] at cx
    exact opposed_single (edge_opposing (single_consistent a) coh cx)

theorem selection (r : Roots) (mix : Bool) (A : Fin 6 → Set Word) (L : V → List Lit)
    {x y z : V} (xy : x<y) (yz : y<z) (lx : L x=[r.a]) (ly : L y=[r.b]) (lz : L z=[r.c])
    (shapes : ∀ v, v≠x → v≠y → v≠z → Shape mix (L v))
    (covers : ∀ i j, adj i j → ∀ q, receives A (L i) q ∨ receives A (L j) q)
    (wit : ∀ u : Fin 16, ∃ q : Word, ∀ v : V, receives A (L v) q ↔ v.val ∉ independentSets u) :
    labelDir x y z ∈ roster38 ∧
    (∀ v, v<10 → normalized r L v ∈ options (labelDir x y z) mix v) ∧
    (∀ u v, u<v → v<10 → edge u v=true → opposes (normalized r L u) (normalized r L v)=true) := by
  have coherent (v : V) : consistent (L v) := by
    by_cases h : v=x
    · rw [h,lx]; exact single_consistent _
    by_cases k : v=y
    · rw [k,ly]; exact single_consistent _
    by_cases m : v=z
    · rw [m,lz]; exact single_consistent _
    exact shape_consistent (shapes v h k m)
  refine ⟨roster r L xy yz lx ly lz covers,?_,?_⟩
  · intro n hn
    let v : V := ⟨n,hn⟩
    obtain ⟨ca,cb,cc⟩ := code_roots r
    have nyx : y.val≠x.val := fun h=> (ne_of_lt xy) (Fin.ext h.symm)
    have nzx : z.val≠x.val := fun h=> (ne_of_lt (lt_trans xy yz)) (Fin.ext h.symm)
    have nzy : z.val≠y.val := fun h=> (ne_of_lt yz) (Fin.ext h.symm)
    by_cases vx : v=x
    · have q : n=x.val := congrArg Fin.val vx
      subst n
      simp [normalized,normArm,options,labelDir,lx,ca,x.isLt]
    by_cases vy : v=y
    · have q : n=y.val := congrArg Fin.val vy
      subst n
      simp [normalized,normArm,options,labelDir,ly,cb,y.isLt,nyx]
    by_cases vz : v=z
    · have q : n=z.val := congrArg Fin.val vz
      subst n
      simp [normalized,normArm,options,labelDir,lz,cc,z.isLt,nzx,nzy]
    have nx : n≠x.val := fun e=>vx (Fin.ext e)
    have ny : n≠y.val := fun e=>vy (Fin.ext e)
    have nz : n≠z.val := fun e=>vz (Fin.ext e)
    obtain ⟨na,aa⟩ := selected_roots L wit covers lx (Ne.symm vx) (coherent v)
    obtain ⟨nb,bb⟩ := selected_roots L wit covers ly (Ne.symm vy) (coherent v)
    obtain ⟨nc,dd⟩ := selected_roots L wit covers lz (Ne.symm vz) (coherent v)
    unfold options
    change normalized r L n ∈ (if n=x.val then [[0]] else if n=y.val then [[2]] else if n=z.val then [[4]] else _)
    rw [if_neg nx,if_neg ny,if_neg nz,normalized,dif_pos hn]
    change normArm r (L v) ∈ _
    apply List.mem_filter.mpr
    refine ⟨shape_selected r (L v) mix (shapes v vx vy vz) na nb nc,?_⟩
    have force (t : Lit) (k : Nat) (w : V) (tk : code r t=k)
        (got : adj v w → mate t ∈ L v) :
        (!edge n w.val || (normArm r (L v)).contains (k ^^^ 1))=true := by
      cases he : edge n w.val with
      | false => rfl
      | true =>
        have h := (decoded_mem r (L v) (mate t)).2 (got ((adj_code v w).2 he))
        rw [code_mate,tk] at h
        exact List.contains_iff_mem.mpr h
    exact Bool.and_eq_true_iff.mpr ⟨Bool.and_eq_true_iff.mpr ⟨force r.a 0 x ca aa,force r.b 2 y cb bb⟩,
      force r.c 4 z cc dd⟩
  · intro i j ij hj e
    let u : V := ⟨i,by omega⟩
    let v : V := ⟨j,hj⟩
    obtain ⟨k,s,hu,hv⟩ := edge_opposing (coherent u) (coherent v) (covers _ _ ((adj_code u v).2 e))
    apply List.any_eq_true.mpr
    refine ⟨code r (k,s),(normalized_mem r L u _).2 ⟨_,hu,rfl⟩,?_⟩
    exact List.contains_iff_mem.mpr ((normalized_mem r L v _).2 ⟨mate (k,s),hv,code_mate r (k,s)⟩)
end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.selection
