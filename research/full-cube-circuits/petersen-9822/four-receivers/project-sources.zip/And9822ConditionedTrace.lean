import And9822TraceCount
import FourSaturationData

namespace Research.Graph9822.TraceCount
open Research.Graph9822.FourSaturation

def outsideTraces (P : Profile) (A : Word → Bool) :=
  (((List.finRange 64).filter (fun w => !(A w))).map (trace P)).eraseDups

private def outsideRow (v : Fin 10) (i : Fin 5) : Nat :=
  ((witnesses.filter (fun m => m.testBit v.val))[i.val]!)

private theorem outsideRows : ∀ v : Fin 10, (∀ i : Fin 5,
    outsideRow v i ∈ witnesses ∧ (outsideRow v i).testBit v.val = true) ∧
    (∀ i j : Fin 5, (∀ u : Fin 10, (outsideRow v i).testBit u.val =
      (outsideRow v j).testBit u.val) → i = j) := by decide +kernel

/-- An observed raw needs five distinct ray traces on its false chamber. -/
theorem raw_outside_five (P : Profile) (R : Fin 10 → Word → Bool)
    (built : ∀ v, Generated P (R v))
    (realize : ∀ m ∈ witnesses, ∃ w, ∀ u : Fin 10, R u w = !(m.testBit u.val))
    (v : Fin 10) : 5 ≤ (outsideTraces P (R v)).length := by
  classical
  let existsWord (i : Fin 5) := realize (outsideRow v i) ((outsideRows v).1 i).1
  let wit (i : Fin 5) : Word := Classical.choose (existsWord i)
  have hw (i : Fin 5) (u : Fin 10) : R u (wit i) = !((outsideRow v i).testBit u.val) :=
    Classical.choose_spec (existsWord i) u
  let t (i : Fin 5) := trace P (wit i)
  have inj {i j : Fin 5} (eq : t i = t j) : i = j := by
    apply (outsideRows v).2
    intro u
    have e := generated_congr P (built u) eq
    rw [hw i u, hw j u] at e
    simpa using e
  have nd : ((List.finRange 5).map t).Nodup :=
    List.pairwise_map.mpr ((List.nodup_finRange 5).imp (fun h e => h (inj e)))
  have sub : (List.finRange 5).map t ⊆ outsideTraces P (R v) := by
    intro x hx
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp hx
    apply List.mem_eraseDups.mpr
    apply List.mem_map.mpr
    refine ⟨wit i,List.mem_filter.mpr ⟨List.mem_finRange _,?_⟩,rfl⟩
    simp [hw i v,((outsideRows v).1 i).2]
  simpa using nd.length_le_of_subset sub

def profile3182 (i : Axis) : Nat :=
  ([18446744073709551615,6148914691236517205,1229782938247303441,
    12297829382473034410,18446744073709551615,48132216733761535] : List Nat)[i.val]!

def last3182 (w : Word) := (profile3182 5).testBit w.val

theorem last3182_nonprimitive : (∃ w : Word, last3182 w = false) ∧
    ∀ i : Axis, ∀ s : Bool, ∃ w : Word, last3182 w ≠ branch profile3182 i s w := by
  decide +kernel

theorem last3182_card : (outsideTraces profile3182 last3182).length = 4 := by
  decide +kernel

theorem row3182_no_raw (R : Fin 10 → Word → Bool)
    (built : ∀ v, Generated profile3182 (R v))
    (realize : ∀ m ∈ witnesses, ∃ w, ∀ u : Fin 10, R u w = !(m.testBit u.val))
    (required : ∃ v, R v = last3182) : False := by
  obtain ⟨v,h⟩ := required
  have bad := raw_outside_five profile3182 R built realize v
  rw [h,last3182_card] at bad
  exact (by decide : ¬5 ≤ 4) bad

end Research.Graph9822.TraceCount
#print axioms Research.Graph9822.TraceCount.row3182_no_raw
