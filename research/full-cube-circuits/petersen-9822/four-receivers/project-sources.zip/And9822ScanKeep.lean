import And9822NumericKeep

namespace Research.Graph9822.NumericBank
open ArbitraryScan Graph9822Profiles CommonBank Banks
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p

/-- Grant and helper witnesses are constructed from the chronological scan. -/
theorem scan_keep {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (respects : ∀ s ∈ p, s.2 = P s.1) (R : Fin 10 → Mask6) (returned : ∀ v, R v ∈ l)
    (proper : ∀ v, ∃ q, q ∉ R v) (inc : ∀ u v, u ≠ v → ¬ R u ⊆ R v) (budget : n ≤ 8)
    (code : Mask6 → Nat) (cup : ∀ a b, code (a ∪ b) = code a ||| code b)
    (id : Nat → Nat) (lib prim named : Finset Nat) (boxes : Fin 10 → List Nat)
    (primCode : ∀ m, RayValue P m → code m ∈ prim)
    (namedCode : ∀ x, x ∈ named ↔ ∃ m ∈ p.map Prod.snd, ¬Primitive P m ∧ code m=x)
    (inLib : ∀ v, code (R v) ∈ lib) (inBox : ∀ v,id (code (R v)) ∈ boxes v)
    (d : Nat) (direct : ((Finset.univ : Finset (Fin 10)).filter (fun v => RayValue P (R v))).card=d)
    (dmax : d ≤ 4) :
    ∃ bank ∈ enumerate id lib prim named d, (∀ v,id (code (R v)) ∈ bank.available) ∧
      (∀ m ∈ bank.required, ∃ v,id (code (R v))=m) ∧
      ∀ v,keep (enumerate id lib prim named d) boxes (id (code (R v)))=true := by
  classical
  obtain ⟨raw,gr,hs,hraw,hgr,built,cost,recv⟩ :=
    common_from_scan scan P respects R returned proper inc budget
  have inj : Function.Injective R := by
    intro u v e
    by_contra h
    exact inc u v h (fun x hx => e ▸ hx)
  have spare := spare_count inj hraw cost
  rw [direct] at spare
  apply keep_from_helpers code cup id lib prim named d dmax R boxes inLib inBox primCode built spare
  · intro m hm
    obtain ⟨hp,hn,_⟩ := (hgr m).mp hm
    exact (namedCode _).mpr ⟨m,hp,hn,rfl⟩
  · intro x hx ng
    obtain ⟨m,hp,hn,rfl⟩ := (namedCode x).mp hx
    by_cases hr : m ∈ raw
    · obtain ⟨v,hv,_⟩ := (hraw m).mp hr
      exact ⟨v,congrArg code hv⟩
    · exact False.elim (ng (Finset.mem_image.mpr ⟨m,(hgr m).mpr ⟨hp,hn,hr⟩,rfl⟩))
  · exact recv
end
end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.scan_keep
