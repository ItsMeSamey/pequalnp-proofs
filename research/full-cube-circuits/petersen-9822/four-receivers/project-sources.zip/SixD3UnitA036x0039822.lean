import SixD3GridUnits9822
import SixD3GridDataA0369822
namespace Research.Graph9822.ThreeDirect.A036
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit36 : ∀ a, Known a g 311 → Known a g 312 :=
  singleKnown g 311 (unpack 28 [0x104c0000039ddc303a1dfb03a9e9d047119c027d2d30275279026d23102651f9025d1cf02551b1015e0a1015a08d015607b015206b014e05d014a051012209d00f608900c6077009e0670072059004e04d04da046048a035]) (by decide +kernel)
theorem up3 : ∀ a, Known a g 311 → Known a g 312 := by
  intro a h
  apply unit36 a
  exact h
end Research.Graph9822.ThreeDirect.A036
