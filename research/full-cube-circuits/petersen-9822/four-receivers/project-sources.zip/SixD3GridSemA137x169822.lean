import SixD3GridDataA1379822
namespace Research.Graph9822.ThreeDirect.A137
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part2304 : Range (aOK d) (aCl d) g 2304 2328 :=
  rangeCheck _ _ _ 2304 24 (by decide +kernel)
private theorem part2328 : Range (aOK d) (aCl d) g 2328 2352 :=
  rangeCheck _ _ _ 2328 24 (by decide +kernel)
private theorem part2352 : Range (aOK d) (aCl d) g 2352 2376 :=
  rangeCheck _ _ _ 2352 24 (by decide +kernel)
private theorem part2376 : Range (aOK d) (aCl d) g 2376 2391 :=
  rangeCheck _ _ _ 2376 15 (by decide +kernel)
theorem sem16 : Range (aOK d) (aCl d) g 2304 2391 := rangeAppend part2304 (rangeAppend part2328 (rangeAppend part2352 (part2376)))
end Research.Graph9822.ThreeDirect.A137
