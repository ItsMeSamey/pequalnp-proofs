import SixD3GridDataA0179822
namespace Research.Graph9822.ThreeDirect.A017
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part576 : Range (aOK d) (aCl d) g 576 600 :=
  rangeCheck _ _ _ 576 24 (by decide +kernel)
private theorem part600 : Range (aOK d) (aCl d) g 600 624 :=
  rangeCheck _ _ _ 600 24 (by decide +kernel)
private theorem part624 : Range (aOK d) (aCl d) g 624 648 :=
  rangeCheck _ _ _ 624 24 (by decide +kernel)
private theorem part648 : Range (aOK d) (aCl d) g 648 672 :=
  rangeCheck _ _ _ 648 24 (by decide +kernel)
private theorem part672 : Range (aOK d) (aCl d) g 672 696 :=
  rangeCheck _ _ _ 672 24 (by decide +kernel)
private theorem part696 : Range (aOK d) (aCl d) g 696 720 :=
  rangeCheck _ _ _ 696 24 (by decide +kernel)
theorem sem4 : Range (aOK d) (aCl d) g 576 720 := rangeAppend part576 (rangeAppend part600 (rangeAppend part624 (rangeAppend part648 (rangeAppend part672 (part696)))))
end Research.Graph9822.ThreeDirect.A017
