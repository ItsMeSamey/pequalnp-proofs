import SixH4ProjectionCode9822
import SixD3Projection9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral
structure Roots where
  a : Lit
  b : Lit
  c : Lit
  ab : a.1 ≠ b.1
  ac : a.1 ≠ c.1
  bc : b.1 ≠ c.1
def rank (a b c i : Fin 6) : Nat :=
  if i=a then 0 else if i=b then 1 else if i=c then 2 else
    3 + ((List.range i.val).filter (fun j=> !(j==a.val) && !(j==b.val) && !(j==c.val))).length
def axisCode (r : Roots) (i : Fin 6) := rank r.a.1 r.b.1 r.c.1 i
def phase (r : Roots) (i : Fin 6) :=
  if i=r.a.1 then r.a.2 else if i=r.b.1 then r.b.2 else if i=r.c.1 then r.c.2 else false
def code (r : Roots) (t : Lit) := 2*axisCode r t.1 + if t.2 = phase r t.1 then 0 else 1
private theorem rank_bounds : ∀ (a b c : Fin 6), a≠b → a≠c → b≠c →
    ∀ i : Fin 6, rank a b c i < 6 := by decide +kernel
private theorem rank_diff : ∀ (a b c : Fin 6), a≠b → a≠c → b≠c →
    ∀ i j : Fin 6, i≠j → rank a b c i ≠ rank a b c j := by decide +kernel
theorem axisBound (r : Roots) (i : Fin 6) : axisCode r i < 6 :=
  rank_bounds _ _ _ r.ab r.ac r.bc i
theorem axisInj (r : Roots) : Function.Injective (axisCode r) := by
  intro i j eq
  by_contra ne
  exact rank_diff _ _ _ r.ab r.ac r.bc _ _ ne eq
theorem code_axis (r : Roots) (t : Lit) : code r t / 2 = axisCode r t.1 := by
  unfold code
  split <;> omega
theorem code_bound (r : Roots) (t : Lit) : code r t < 12 := by
  have bound := axisBound r t.1
  unfold code
  split <;> omega
theorem code_roots (r : Roots) : code r r.a=0 ∧ code r r.b=2 ∧ code r r.c=4 := by
  simp [code,axisCode,rank,phase,r.ab.symm,r.ac.symm,r.bc.symm]
private theorem small_flip : ∀ (n : Fin 6) (s p : Bool),
    2*n.val+(if (!s)=p then 0 else 1) = (2*n.val+(if s=p then 0 else 1)) ^^^ 1 := by decide +kernel
theorem code_mate (r : Roots) (t : Lit) : code r (mate t)=code r t ^^^ 1 :=
  small_flip ⟨_,axisBound r t.1⟩ t.2 (phase r t.1)
theorem code_injective (r : Roots) : Function.Injective (code r) := by
  rintro ⟨i,s⟩ ⟨j,t⟩ eq
  have axes := congrArg (fun k : Nat => k/2) eq
  rw [code_axis,code_axis] at axes
  have ij : i=j := axisInj r axes
  subst j
  have parity : s=t := by
    cases s <;> cases t <;> cases h : phase r i <;> simp_all [code] <;> omega
  simp [parity]
end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.code_injective
