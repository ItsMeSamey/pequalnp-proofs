import SixWideD3PhysicalMarked9822
import SixH4FreshPositive9822
import SixD3Projection9822
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822 Research.Graph9822.ArbitraryScan
open Research.Graph9822Profiles.Fresh
open PEqualNP.Outside.L_meta_9822.Sectors PEqualNP.Outside.L_meta_9822.Receivers
theorem original_d3_environment (gs : List DGate) (out : Nat) (size : gs.length≤17)
    (ok : WellWired gs 10) (ob : out<10+gs.length) (six : gs.countP Gate.isAnd=6)
    (computes : ∀ x : Fin 10 → Bool,(asCircuit gs out).eval (List.ofFn x)=edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le six.le)
    let st := (gateEvents axis gs 10 ++ rawEvents 10).foldl paddedStep (initial out)
    let R := tenR axis gs out
    let P := field st.switches
    ExactReceivers (fun v q=>q∈R v) ∧
      (∀ a b,a≠b → ¬R a⊆R b) ∧
      (∀ a b : Fin 10,TwoDirect.edge a.val b.val=true ↔ ∀ q,q∈R a ∨ q∈R b) ∧
      (∀ i,Stable (P i) i) ∧ (∀ i,∃ w,w∈P i) := by
  intro axis st R P
  obtain ⟨tags,_,_,_,⟨l,scan,_⟩,_,_⟩ := padded_profile_rows gs out size ok ob six.le computes
  have tags6 : st.switches.map Prod.fst=((List.range 6).map (Fin.ofNat 6)).reverse :=
    tags.trans (congrArg (fun n=>((List.range n).map (Fin.ofNat 6)).reverse) six)
  have names := six_names tags6
  have site (i : Axis) : (i,P i)∈st.switches := by
    obtain ⟨m,hm⟩ := names.2 i
    have eq : P i=m := field_at _ names.1 (i,m) hm
    exact eq.symm ▸ hm
  have h : ∀ x : Fin 10 → Bool,eval gs 10 (wiresFrom (List.ofFn x)) out=edge x := by
    intro x
    simpa only [physical_eval,List.length_ofFn] using computes x
  obtain ⟨real,sep,_,edges⟩ := physical_receiver_facts gs out six.le h
  refine ⟨real,?_,?_,fun i=>switch_stable scan names.1 _ (site i),
    fun i=>(scan_positive scan names.1).2 _ (site i)⟩
  · intro a b ne sub
    obtain ⟨q,yes,no⟩ := sep a b ne
    exact no (sub yes)
  · intro a b
    have eq : ∀ u v : Fin 10,TwoDirect.edge u.val v.val=rawEdge u v := by decide +kernel
    rw [eq]
    exact edges a b
end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.original_d3_environment
