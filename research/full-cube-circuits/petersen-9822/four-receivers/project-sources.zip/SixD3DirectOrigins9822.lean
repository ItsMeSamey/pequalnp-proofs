import SixH4FreshPair9822
import SixH4TwoDirectOrigins9822
import SixH4DirectFull9822
import SixH4FreshPositive9822
namespace Research.Graph9822.ArbitraryScan
open Research.Graph9822Profiles Research.Graph9822Profiles.Fresh

theorem direct_A_origin {P : Axis6→Mask6} {R : Fin 10→Mask6}
    (x v : Fin 10) (diff : x≠v) (i : Axis6) (s : Bool) (rx : R x=ray P i s)
    (anti : ∀ a b,a≠b → ¬R a⊆R b) (H : Mask6) (used : H⊆R v)
    (stable : Stable (P i) i) (live : ∃ q,q∈P i)
    (source : Primitive P (P i) ∨ (∃ u,R u=P i) ∨ P i=H) :
    P i=Set.univ ∨ ∃ k z,k≠i ∧ P i=ray P k z := by
  classical
  by_cases full : P i=Set.univ
  · exact Or.inl full
  right
  have notRaw := Research.SixH4.DirectLiteral.activation_not_raw P R x i s rx anti
    (straddles stable s live)
  have notH : P i≠H := by
    intro h
    apply anti x v diff
    intro q hq
    rw [rx] at hq
    exact used (h ▸ hq.1)
  have src : Primitive P (P i) ∨ ∃ u,R u=P i := by
    rcases source with prim|raw|eq
    · exact Or.inl prim
    · exact Or.inr raw
    · exact False.elim (notH eq)
  rcases different_origin stable live full src with good|⟨u,_,eq⟩
  · exact good
  · exact False.elim (notRaw u eq)

theorem ordinary_neighbors {P : Axis6→Mask6} {R : Fin 10→Mask6}
    {i : Axis6} {s : Bool} {x v w : Fin 10} (rx : R x=ray P i s)
    (ne : v≠w) (ant : ∀ a b,a≠b → ¬R a⊆R b)
    (other : ∃ k z,P i=ray P k z)
    (cover1 : ∀ q,q∈R x ∨ q∈R v) (cover2 : ∀ q,q∈R x ∨ q∈R w)
    (pairv : DistinctPair P (R v)) (pairw : DistinctPair P (R w)) : False := by
  obtain ⟨a,b,c,d,ac,ev⟩ := pairv
  obtain ⟨e,f,g,h,eg,ew⟩ := pairw
  have cv : ray P i s ∪ R v=Set.univ := Set.eq_univ_of_forall (fun q=>rx ▸ cover1 q)
  have cw : ray P i s ∪ R w=Set.univ := Set.eq_univ_of_forall (fun q=>rx ▸ cover2 q)
  have fv := Research.SixH4.DirectLiteral.forced_fallback P i s ac ev cv
  have fw := Research.SixH4.DirectLiteral.forced_fallback P i s eg ew cw
  have diff : R v≠R w := fun eq=>ant v w ne (by rw [eq])
  have full := Research.SixH4.DirectLiteral.direct_full P i s (fun _=>other) _ _ diff cv cw fv fw
  obtain ⟨j,t,eq⟩ := other
  let q : Word := fun _=> !t
  have hit : q∈ray P j t := eq ▸ (full.symm ▸ Set.mem_univ q)
  have bad : (!t)=t := hit.2
  revert bad
  cases t <;> decide
end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.direct_A_origin
#print axioms Research.Graph9822.ArbitraryScan.ordinary_neighbors
