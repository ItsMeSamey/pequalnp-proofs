import SixD3Plan9822
import SixWideD3HelperHistory9822
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
theorem fixed_plan {N b l p e} (run : Marked N b l p e) (P : Axis→Mask)
    (ok : ∀t∈p,t.2=P t.1) (one : e.length≤1) (cleanH : ∀H∈e,H≠Set.univ ∧ ∀m∈N,¬m⊆H)
    (anti : ∀ x∈N,∀y∈N,x⊆y → x=y) (top : Set.univ∉N) (no : ∀ i s,P i∩side i s∉N) :
    ∃ mode : Mode,Plan P p e mode ∧ ∀ m∈l,m∈N → PlanRaw P mode m := by
  induction run with
  | start => exact ⟨none,.clean,by simp [top]⟩
  | @first b l p e x y h hx hy used fresh ih =>
    obtain ⟨mode,plan,old⟩ := ih ok one cleanH
    refine ⟨mode,plan,?_⟩
    intro m mem raw
    rcases List.mem_cons.mp mem with rfl|prior
    · exact plan_issue h P ok plan anti top hx hy used fresh
    · exact old _ prior raw
  | @split b l p e u i h hu ih =>
    obtain ⟨mode,plan,old⟩ := ih (fun t mem=>ok t (List.mem_cons_of_mem _ mem)) one cleanH
    have ui : u=P i := ok (i,u) (by simp)
    refine ⟨mode,plan_weaken plan _,?_⟩
    intro m mem raw
    rcases List.mem_cons.mp mem with rfl|tail
    · exact False.elim (no i true (ui ▸ raw))
    rcases List.mem_cons.mp tail with rfl|prior
    · exact False.elim (no i false (ui ▸ raw))
    exact old _ prior raw
  | @spare b l p e x y h hx hy skip ih =>
    have nil : e=[] := List.length_eq_zero_iff.mp (by simp only [List.length_cons] at one; omega)
    subst e
    obtain ⟨mode,plan,old⟩ := ih ok (by simp) (by simp)
    cases plan
    have proper := cleanH (x∪y) List.mem_cons_self
    have lift (m) (hm : m∈(x∪y)::l) (hn : m∈N) : DistinctPair P m := by
      rcases List.mem_cons.mp hm with rfl|mem
      · exact False.elim (proper.2 _ hn (fun _ a=>a))
      · exact old _ mem hn
    rcases spare_history_shape (.spare h hx hy skip) P ok one (x∪y) List.mem_cons_self proper.1 proper.2
      with org | ⟨i,u,j,v,s,t,iu,jv,neq,eq⟩
    · obtain ⟨a,seen,valid⟩ := seen_origin ok org
      exact ⟨none,.ray seen valid,lift⟩
    · have ui : u=P i := ok (i,u) iu
      have vj : v=P j := ok (j,v) jv
      refine ⟨some ((i,s),(j,t)),.pair ?_ ?_ neq ?_,fun m hm hn=> Or.inl (lift m hm hn)⟩
      · simpa [Seen,←ui] using iu
      · simpa [Seen,←vj] using jv
      · simpa [value,ui,vj] using eq
end Research.Graph9822Profiles.Fresh
#print axioms Research.Graph9822Profiles.Fresh.fixed_plan
