import SixD3RootA2469822
import SixD3Sigma147To2469822
namespace Research.Graph9822.ThreeDirect.A147
def d : Dir := (1,4,7)
theorem closed : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact A246.closed ⟨Sigma.shared147_246 p⟩
end Research.Graph9822.ThreeDirect.A147
