import SixD3GridDataA2489822
namespace Research.Graph9822.ThreeDirect.A248
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part1440 : Range (aOK d) (aCl d) g 1440 1464 :=
  rangeCheck _ _ _ 1440 24 (by decide +kernel)
private theorem part1464 : Range (aOK d) (aCl d) g 1464 1488 :=
  rangeCheck _ _ _ 1464 24 (by decide +kernel)
private theorem part1488 : Range (aOK d) (aCl d) g 1488 1512 :=
  rangeCheck _ _ _ 1488 24 (by decide +kernel)
private theorem part1512 : Range (aOK d) (aCl d) g 1512 1536 :=
  rangeCheck _ _ _ 1512 24 (by decide +kernel)
private theorem part1536 : Range (aOK d) (aCl d) g 1536 1560 :=
  rangeCheck _ _ _ 1536 24 (by decide +kernel)
private theorem part1560 : Range (aOK d) (aCl d) g 1560 1584 :=
  rangeCheck _ _ _ 1560 24 (by decide +kernel)
theorem sem10 : Range (aOK d) (aCl d) g 1440 1584 := rangeAppend part1440 (rangeAppend part1464 (rangeAppend part1488 (rangeAppend part1512 (rangeAppend part1536 (part1560)))))
end Research.Graph9822.ThreeDirect.A248
