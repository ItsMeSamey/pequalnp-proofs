import SixD3Families9822
import SixWideD3PhysicalMarked9822
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Resolution Research.Graph9822 Research.Graph9822.ArbitraryScan Research.Graph9822Profiles.Fresh
open PEqualNP.Outside.L_meta_9822.Sectors
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
theorem original_d3_families (gs : List DGate) (out : Nat) (size : gs.length≤17)
    (ok : WellWired gs 10) (ob : out<10+gs.length) (six : gs.countP Gate.isAnd=6)
    (computes : ∀ x : Fin 10 → Bool,(asCircuit gs out).eval (List.ofFn x)=edge x) :
    let axis := switchAxis (switchAddrs gs 10) ((switchAddrs_length gs 10).trans_le six.le)
    let st := (gateEvents axis gs 10 ++ rawEvents 10).foldl paddedStep (initial out)
    let R := tenR axis gs out
    let P := field st.switches
    ((Finset.univ : Finset (Fin 10)).filter (fun v=>RayValue P (R v))).card=3 →
    ∃ N e, e.length≤1 ∧ (∀ m,m∈N ↔ ∃ v,R v=m ∧ ¬RayValue P m) ∧
      (∀ i,Primitive P (P i) ∨ P i∈N ∨ P i∈e) ∧ Families N P st.switches e := by
  classical
  intro axis st R P d
  obtain ⟨N,e,l,run,ret,one,defN,names,_⟩ := physical_marked_three gs out size ok ob six computes d
  obtain ⟨tags,_,_,_,_,_,_⟩ := padded_profile_rows gs out size ok ob six.le computes
  have tags6 : st.switches.map Prod.fst=((List.range 6).map (Fin.ofNat 6)).reverse :=
    tags.trans (congrArg (fun n=>((List.range n).map (Fin.ofNat 6)).reverse) six)
  have nodup := (six_names tags6).1
  have respects (t) (ht : t∈st.switches) : t.2=P t.1 := (field_at _ nodup t ht).symm
  have h : ∀ x : Fin 10 → Bool, eval gs 10 (wiresFrom (List.ofFn x)) out=edge x := by
    intro x
    simpa only [physical_eval,List.length_ofFn] using computes x
  obtain ⟨real,sep,_,_⟩ := physical_receiver_facts gs out six.le h
  have anti : ∀ a∈N,∀ c∈N,a⊆c → a=c := by
    intro a ha c hc sub
    obtain ⟨v,rfl,_⟩ := (defN a).mp ha
    obtain ⟨u,rfl,_⟩ := (defN c).mp hc
    by_cases eq : v=u
    · rw [eq]
    · obtain ⟨q,yes,no⟩ := sep v u eq
      exact False.elim (no (sub yes))
  have top : Set.univ∉N := by
    intro mem
    obtain ⟨v,eq,_⟩ := (defN _).mp mem
    obtain ⟨u,ne⟩ := (show ∀ v : Fin 10,∃ u : Fin 10,u≠v by decide +kernel) v
    obtain ⟨q,_,miss⟩ := sep u v ne
    apply miss
    change q∈R v
    change R v=Set.univ at eq
    rw [eq]
    trivial
  have no (i : Axis) (s : Bool) : P i∩side i s∉N := by
    intro h
    exact ((defN _).mp h).choose_spec.2 ⟨i,s,rfl⟩
  refine ⟨N,e,one,defN,names,family_cover run P respects one ?_ anti top no⟩
  intro m hm
  obtain ⟨v,rfl,_⟩ := (defN m).mp hm
  exact ret v
end
end Research.Graph9822Profiles.OuterLive
#print axioms Research.Graph9822Profiles.OuterLive.original_d3_families
