import SixD3RootA1359822
import SixD3Sigma028To1359822
namespace Research.Graph9822.ThreeDirect.A028
def d : Dir := (0,2,8)
theorem closed : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact A135.closed ⟨Sigma.shared028_135 p⟩
end Research.Graph9822.ThreeDirect.A028
