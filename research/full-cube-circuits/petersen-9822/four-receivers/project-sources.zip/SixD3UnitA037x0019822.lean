import SixD3GridUnits9822
import SixD3GridDataA0379822
namespace Research.Graph9822.ThreeDirect.A037
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit12 : ∀ a, Known a g 229 → Known a g 230 :=
  singleKnown g 229 (unpack 28 [0x1016000000da0a5009e09d01646f2035c333034c0b3017029200e401201697f400dc784]) (by decide +kernel)
private theorem unit13 : ∀ a, Known a g 230 → Known a g 231 :=
  singleKnown g 230 (unpack 28 [0x1015800000d60910096089015c652035c333034c0b3017029200e401201697f400dc784]) (by decide +kernel)
private theorem unit14 : ∀ a, Known a g 231 → Known a g 232 :=
  singleKnown g 231 (unpack 28 [0x1015000000d207f008e07701545b2035c333034c0b3017029200e401201697f400dc784]) (by decide +kernel)
private theorem unit15 : ∀ a, Known a g 232 → Known a g 233 :=
  singleKnown g 232 (unpack 28 [0x1014800000ce06f0086067014c512012d45e039d49703994df0395539013136b01353f5035c33303541f3034c0b3017029200f015200e401201697f400e8e9000dc784]) (by decide +kernel)
private theorem unit16 : ∀ a, Known a g 233 → Known a g 234 :=
  singleKnown g 233 (unpack 28 [0x1032000000f527802e51f902c11cf029d1b1027919d0205105]) (by decide +kernel)
private theorem unit17 : ∀ a, Known a g 234 → Known a g 235 :=
  singleKnown g 234 (unpack 28 [0x1019c0000175cdc01e5dd101e9e0901cdd7b0379ed500f5104037dddd0381eb70369ce9038deab0375ec50371dbf036ddc30365cf70389e5103a5e6b017dccf0179ccb0189d55035832503501e503480a5016c28400ec14400e000401697f400e8e9000dc784]) (by decide +kernel)
private theorem unit18 : ∀ a, Known a g 235 → Known a g 236 :=
  singleKnown g 235 (unpack 28 [0x10080000010605800ae05d0108473007203503541f3034c0b300f015200e401200e8e9000dc784]) (by decide +kernel)
private theorem unit19 : ∀ a, Known a g 236 → Known a g 237 :=
  singleKnown g 236 (unpack 28 [0x10088000010e0660072035011051303541f3034c0b300f015200e401200e8e9000dc784]) (by decide +kernel)
private theorem unit20 : ∀ a, Known a g 237 → Known a g 238 :=
  singleKnown g 237 (unpack 28 [0x10090000011607600b607b01185b3007203503541f3034c0b300f015200e401200e8e9000dc784]) (by decide +kernel)
private theorem unit21 : ∀ a, Known a g 238 → Known a g 239 :=
  singleKnown g 238 (unpack 28 [0x100a0000012609c00be0a101286f3007203503541f3034c0b300f015200e401200e8e9000dc784]) (by decide +kernel)
private theorem unit22 : ∀ a, Known a g 239 → Known a g 240 :=
  singleKnown g 239 (unpack 28 [0x10174000022dd770229d2d0225d190221d070215cdd024ddfb0251e430255e9d0259dd10239df7025de09026de15023de3f0241e990245d7b0281e7b017dccf0179ccb0189d55035832503501e503480a5016c28400ec14400e000401697f400e8e9000dc784]) (by decide +kernel)
private theorem unit23 : ∀ a, Known a g 240 → Known a g 241 :=
  singleKnown g 240 (unpack 28 [0x103a800001c9e9901c5e3f01c1df701b5d7701e1e9d01b1d2d01add1901a9d0701f9e1501d9dfb01dde43020de7b00f510403bd19d0381eb70385e5d0369ce9038deab0389e51037dddd03a5e6b0375ec50371dbf036ddc30365cf70379ed5]) (by decide +kernel)
theorem up1 : ∀ a, Known a g 229 → Known a g 241 := by
  intro a h
  apply unit23 a
  apply unit22 a
  apply unit21 a
  apply unit20 a
  apply unit19 a
  apply unit18 a
  apply unit17 a
  apply unit16 a
  apply unit15 a
  apply unit14 a
  apply unit13 a
  apply unit12 a
  exact h
end Research.Graph9822.ThreeDirect.A037
