import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem g936 : Range (aOK d) (aCl d) g 936 940 := rangeCheck _ _ _ 936 4 (by decide +kernel)
private theorem g940 : Range (aOK d) (aCl d) g 940 944 := rangeCheck _ _ _ 940 4 (by decide +kernel)
private theorem g944 : Range (aOK d) (aCl d) g 944 948 := rangeCheck _ _ _ 944 4 (by decide +kernel)
private theorem g948 : Range (aOK d) (aCl d) g 948 952 := rangeCheck _ _ _ 948 4 (by decide +kernel)
private theorem g952 : Range (aOK d) (aCl d) g 952 956 := rangeCheck _ _ _ 952 4 (by decide +kernel)
private theorem g956 : Range (aOK d) (aCl d) g 956 960 := rangeCheck _ _ _ 956 4 (by decide +kernel)
theorem light6p3 : Range (aOK d) (aCl d) g 936 960 := rangeAppend g936 (rangeAppend g940 (rangeAppend g944 (rangeAppend g948 (rangeAppend g952 (g956)))))
end Research.Graph9822.ThreeDirect.A023
