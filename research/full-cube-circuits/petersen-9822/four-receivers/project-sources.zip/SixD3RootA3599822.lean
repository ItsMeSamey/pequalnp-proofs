import SixD3GridSemA359x009822
import SixD3GridSemA359x019822
import SixD3UnitA359x0009822
import SixD3UnitA359x0019822
import SixD3UnitA359x0029822
namespace Research.Graph9822.ThreeDirect.A359
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 208 (rangeAppend sem0 (sem1))
  intro a old
  apply endKnown g 243 (by decide +kernel) a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A359
