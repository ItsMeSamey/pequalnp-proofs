import SixD3GridDataA1359822
namespace Research.Graph9822.ThreeDirect.A135
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part1872 : Range (aOK d) (aCl d) g 1872 1875 :=
  rangeCheck _ _ _ 1872 3 (by decide +kernel)
theorem sem13 : Range (aOK d) (aCl d) g 1872 1875 := part1872
end Research.Graph9822.ThreeDirect.A135
