import And9822RepresentativeKeep
namespace Research.Graph9822.NumericBank
open ArbitraryScan Graph9822Profiles Graph9822MaskCode Graph9822.LiteralBank Graph9822.UnionCharge Graph9822.StarData

def levels (rays : Finset Nat) : Nat → Finset Nat
  | 0 => {0}
  | k+1 =>
    let old := levels rays k
    old ∪ ((old ×ˢ rays).image (fun p => p.1 ||| p.2))

noncomputable def rawLibrary (P : Axis6 → Mask6) (d : Nat) : Finset Nat :=
  ((levels (rayKeys P) d).erase 0).erase (firstReps P).toNat

private theorem up {s : Finset Nat} {j k : Nat} (le : j ≤ k) : levels s j ⊆ levels s k := by
  induction k,le using Nat.le_induction with
  | base => intro _ h; exact h
  | succ k _ ih => intro x hx; exact Finset.mem_union_left _ (ih hx)

private theorem grow {s : Finset Nat} {j x y : Nat} (hx : x∈levels s j) (hy : y∈s) :
    x ||| y ∈ levels s (j+1) := Finset.mem_union_right _
  (Finset.mem_image.mpr ⟨(x,y),Finset.mem_product.mpr ⟨hx,hy⟩,rfl⟩)

def literalAt (P : Axis6 → Mask6) (k : Nat) :=
  ray P ⟨(k/2)%6,Nat.mod_lt _ (by decide)⟩ (decide (k%2=1))

private theorem literal_num (P : Axis6 → Mask6) (i : Axis6) (b : Bool) :
    literalAt P (numLit i b)=ray P i b := by
  cases b <;> simp [literalAt,numLit,Nat.mod_eq_of_lt i.isLt]
  congr 1
  apply Fin.ext
  change (2*i.val+1)/2%6=i.val
  have := i.isLt
  omega

def unionList (P : Axis6 → Mask6) : List Nat → Mask6
  | [] => ∅
  | x::xs => literalAt P x ∪ unionList P xs

private theorem member_union (P : Axis6 → Mask6) (q : Word6) (l : List Nat) :
    q∈unionList P l ↔ ∃ k∈l,q∈literalAt P k := by
  induction l with
  | nil => simp [unionList]
  | cons x xs ih => simp [unionList,ih]

private theorem list_value {P : Axis6 → Mask6} {w : Nat} (tw : typed w)
    (proper : ∃ q, q∉value P w) : value P w=unionList P (leaves w) := by
  ext q
  rw [member_union]
  constructor
  · rintro (full|⟨i,b,hk,hq⟩)
    · exact False.elim (excludes_observer proper full)
    · exact ⟨numLit i b,leaves_mem.mpr ⟨numLit_lt i b,hk⟩,by simpa only [literal_num] using hq⟩
  · rintro ⟨k,hk,hq⟩
    obtain ⟨lt,hw⟩ := leaves_mem.mp hk
    rcases tw _ hw with eq|⟨i,b,eq⟩
    · omega
    · subst k
      exact Or.inr ⟨i,b,hw,by simpa only [literal_num] using hq⟩

private theorem key_empty (P : Axis6 → Mask6) : key P ∅=0 := by
  have eq : encode (firstReps P) ∅=0 := by
    apply BitVec.eq_of_getLsbD_eq
    intro i hi
    rw [encode_bit _ _ _ hi]; simp
  simp [key,eq]

private theorem key_top (P : Axis6 → Mask6) : key P Set.univ=(firstReps P).toNat := by
  have eq : encode (firstReps P) Set.univ=firstReps P := by
    apply BitVec.eq_of_getLsbD_eq
    intro i hi
    rw [encode_bit _ _ _ hi]; simp
  simp [key,eq]

private theorem level_list (P : Axis6 → Mask6) (xs : List Nat) :
    key P (unionList P xs) ∈ levels (rayKeys P) xs.length := by
  induction xs with
  | nil => simp [unionList,key_empty,levels]
  | cons x xs ih =>
    have mem : key P (literalAt P x)∈rayKeys P :=
      Finset.mem_image.mpr ⟨(_, _),Finset.mem_univ _,rfl⟩
    simpa only [List.length_cons,unionList,key_union,Nat.or_comm] using grow ih mem

private theorem stable_value (P : Axis6 → Mask6) (w : Nat) : Stable P (value P w) := by
  intro x y same
  have forward (a b : Word6) (h : Same P a b) : a∈value P w → b∈value P w := by
    rintro (full|⟨i,c,hk,hm⟩)
    · exact Or.inl full
    · exact Or.inr ⟨i,c,hk,(h i c).mp hm⟩
  exact ⟨forward _ _ same,forward _ _ (fun i c => (same i c).symm)⟩

theorem priced_library {P : Axis6 → Mask6} {R : Fin 10 → Mask6} {n : Nat}
    (pr : Priced P R n) (proper : ∀ v, ∃ q,q∉R v) (nonempty : ∀ v, ∃ q,q∈R v)
    {d : Nat} (direct : ((List.finRange 10).filter pr.direct).length=d) (v : Fin 10) :
    key P (R v)∈rawLibrary P d := by
  let w := pr.wire v
  have e : value P w=R v := pr.interpreted v
  have ok : ∃ q,q∉value P w := by rw [e]; exact proper v
  have len : (leaves w).length ≤ d := (pr.leafLimit v).trans_eq direct
  have lv := up (s:=rayKeys P) len (level_list P (leaves w))
  rw [←list_value (pr.types v) ok,e] at lv
  have stable : Stable P (R v) := e ▸ stable_value P w
  have nonzero : key P (R v)≠0 := by
    intro zero
    have a := (key_eq stable (show Stable P ∅ from fun _ _ _ => Iff.rfl)).mp (zero.trans (key_empty P).symm)
    obtain ⟨q,h⟩ := nonempty v
    exact (a ▸ h : q ∈ (∅ : Mask6))
  have nontop : key P (R v)≠(firstReps P).toNat := by
    intro full
    have a := (key_eq stable (stable_top P)).mp (full.trans (key_top P).symm)
    obtain ⟨q,h⟩ := proper v
    apply h
    rw [a]; exact Set.mem_univ q
  exact Finset.mem_erase.mpr ⟨nontop,Finset.mem_erase.mpr ⟨nonzero,lv⟩⟩

end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.priced_library
