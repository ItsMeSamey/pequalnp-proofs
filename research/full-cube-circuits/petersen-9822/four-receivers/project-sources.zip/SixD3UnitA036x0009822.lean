import SixD3GridUnits9822
import SixD3GridDataA0369822
namespace Research.Graph9822.ThreeDirect.A036
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit0 : ∀ a, Known a g 275 → Known a g 276 :=
  singleKnown g 275 (unpack 28 [0x10438000024d2d204111f904011cf03ed1b103d119d0359105]) (by decide +kernel)
private theorem unit1 : ∀ a, Known a g 276 → Known a g 277 :=
  singleKnown g 276 (unpack 28 [0x10434000024d2d2041523104091f903e51b103b919d0341105]) (by decide +kernel)
private theorem unit2 : ∀ a, Known a g 277 → Known a g 278 :=
  singleKnown g 277 (unpack 28 [0x10428000024d278041923104051cf03f11b103d519d035d105]) (by decide +kernel)
private theorem unit3 : ∀ a, Known a g 278 → Known a g 279 :=
  singleKnown g 278 (unpack 28 [0x1042c000024d2d2041d27903f51cf03dd1b1037119d027123102d45a402f910504443250288284028559c]) (by decide +kernel)
private theorem unit4 : ∀ a, Known a g 279 → Known a g 280 :=
  singleKnown g 279 (unpack 28 [0x10430000024d2d2042127903f91cf03e11b1038519d02691f902dc504030d1050444325043c0a502882840240004028559c023c784]) (by decide +kernel)
private theorem unit5 : ∀ a, Known a g 280 → Known a g 281 :=
  singleKnown g 280 (unpack 28 [0x1031800002c9e980315e3f0311df7030ddbf0309d950305d770331e9d0301d2d02fdd1902f9d0702f5cf702f1ce902edcdd0335dd10339e09031dd7b0321d99033de510341eab0345ddd0349e15034de5d0351eb70325dc30329dfb0355e6b0359ec5032de43035de7b0361ed502d1ccf02cdccb02d9d55044432504401e5043c0a5028828402481440240004028559c0244e90023c784]) (by decide +kernel)
private theorem unit6 : ∀ a, Known a g 281 → Known a g 282 :=
  singleKnown g 281 (unpack 28 [0x10424000024d278040d1f903fd1cf03e91b103cd19d0461105]) (by decide +kernel)
private theorem unit7 : ∀ a, Known a g 282 → Known a g 283 :=
  singleKnown g 282 (unpack 28 [0x102200000266066022e06b021603504401e5043c0a5024814402400040244e90023c784]) (by decide +kernel)
private theorem unit8 : ∀ a, Known a g 283 → Known a g 284 :=
  singleKnown g 283 (unpack 28 [0x10264000015206b009e067000203502ba046023a091023208d046a26d02bc6440268505044432504401e502882840248144028559c0244e90]) (by decide +kernel)
private theorem unit9 : ∀ a, Known a g 284 → Known a g 285 :=
  singleKnown g 284 (unpack 28 [0x1024c000026d231025d1cf015607b014e05d00c6077007205900020350461105]) (by decide +kernel)
private theorem unit10 : ∀ a, Known a g 285 → Known a g 286 :=
  singleKnown g 285 (unpack 28 [0x1023800002ba090023208d02bc644044432504401e502882840248144028559c0244e90]) (by decide +kernel)
private theorem unit11 : ∀ a, Known a g 286 → Known a g 287 :=
  singleKnown g 286 (unpack 28 [0x101e4000026e07a024d230025d1cf01aa05d00ee0770096059002a0350461105]) (by decide +kernel)
theorem up0 : ∀ a, Known a g 275 → Known a g 287 := by
  intro a h
  apply unit11 a
  apply unit10 a
  apply unit9 a
  apply unit8 a
  apply unit7 a
  apply unit6 a
  apply unit5 a
  apply unit4 a
  apply unit3 a
  apply unit2 a
  apply unit1 a
  apply unit0 a
  exact h
end Research.Graph9822.ThreeDirect.A036
