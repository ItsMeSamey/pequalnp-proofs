import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B089
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (0,8,9)
private noncomputable def rules : List Nat := unpack 35 [0x400c000c8800000060402800202000000141808000b8800000040]
private def keys : List Nat := (List.range 6).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x20050f2800c64a001ae300126b80028890000000006] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B089
