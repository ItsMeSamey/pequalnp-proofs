import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B235
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (2,3,5)
private noncomputable def rules : List Nat := unpack 35 [0x200003004c010060c88000000806038182e20000001c000606010800000030]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x80143e2006198800c2a0001d3b00130340027480000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B235
