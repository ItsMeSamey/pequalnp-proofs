import And9822DirectionBound
import Sector9822

namespace Research.Graph9822Resolution
open PEqualNP.Outside.L_meta_9822.Sectors

def independentSets (u : Fin 16) : List Nat :=
  #[[1,4,5], [0,2,3,6], [2,3,5,6], [2,4,5,6], [0,1,3,7], [0,3,6,7], [4,6,7], [2,4,8], [0,1,7,8], [1,4,7,8], [0,1,3,9], [0,2,3,9], [1,3,5,9], [2,3,5,9], [0,1,8,9], [0,2,8,9]][u.val]'(by simpa using u.isLt)

def onSet (xs : List Nat) := edge fun i => decide (i.val ∈ xs)

theorem distinct_sets : ∀ u v : Fin 16, u ≠ v → ∃ p : Fin 10,
    ¬ (p.val ∈ independentSets u ↔ p.val ∈ independentSets v) := by
  decide +kernel

theorem reject_sets : ∀ u : Fin 16, onSet (independentSets u) = false := by
  decide +kernel

theorem maximal_sets : ∀ (u : Fin 16) (a : Fin 10), a.val ∉ independentSets u →
    onSet (a.val :: independentSets u) = true := by
  decide +kernel

theorem four_le (gs : List Gate) (out : Nat)
    (computes : ∀ xs : List Nat, (∀ j ∈ xs, j < 10) →
      eval gs 10 (inputSet xs) out = onSet xs) :
    4 ≤ gs.countP Gate.isAnd := by
  have bounded : ∀ u : Fin 16, (independentSets u).all (· < 10) = true := by decide +kernel
  have small (u : Fin 16) : ∀ j ∈ independentSets u, j < 10 := by
    simpa using List.all_eq_true.mp (bounded u)
  have h := maximal_count_le gs 10 out independentSets
    (fun u v h => by obtain ⟨p,hp⟩ := distinct_sets u v h; exact ⟨p,p.isLt,hp⟩)
    (fun u => (computes _ (small u)).trans (reject_sets u))
    (fun u a ha hmem => by
      rw [computes _ (by simpa using And.intro ha (small u))]
      exact maximal_sets u ⟨a,ha⟩ hmem)
  by_contra hn
  have upper : gs.countP Gate.isAnd ≤ 3 := by omega
  have h8 : 2 ^ gs.countP Gate.isAnd ≤ 8 := Nat.pow_le_pow_right (by decide) upper
  omega

end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.four_le
