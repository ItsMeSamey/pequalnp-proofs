import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B456
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (4,5,6)
private noncomputable def rules : List Nat := unpack 35 [0x4012080b880000009060402032200000020080008080800000000]
private def keys : List Nat := (List.range 6).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x200519a800c16a001e6500134ec0023d20000000006] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B456
