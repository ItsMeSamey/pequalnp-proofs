import SixD3GridDataA0179822
namespace Research.Graph9822.ThreeDirect.A017
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part2448 : Range (aOK d) (aCl d) g 2448 2472 :=
  rangeCheck _ _ _ 2448 24 (by decide +kernel)
private theorem part2472 : Range (aOK d) (aCl d) g 2472 2496 :=
  rangeCheck _ _ _ 2472 24 (by decide +kernel)
private theorem part2496 : Range (aOK d) (aCl d) g 2496 2520 :=
  rangeCheck _ _ _ 2496 24 (by decide +kernel)
private theorem part2520 : Range (aOK d) (aCl d) g 2520 2538 :=
  rangeCheck _ _ _ 2520 18 (by decide +kernel)
theorem sem17 : Range (aOK d) (aCl d) g 2448 2538 := rangeAppend part2448 (rangeAppend part2472 (rangeAppend part2496 (part2520)))
end Research.Graph9822.ThreeDirect.A017
