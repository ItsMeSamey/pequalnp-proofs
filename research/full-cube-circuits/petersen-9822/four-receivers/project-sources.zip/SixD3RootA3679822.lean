import SixD3GridSemA367x009822
import SixD3GridSemA367x019822
import SixD3UnitA367x0009822
import SixD3UnitA367x0019822
import SixD3UnitA367x0029822
namespace Research.Graph9822.ThreeDirect.A367
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 175 (rangeAppend sem0 (sem1))
  intro a old
  apply endKnown g 209 (by decide +kernel) a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A367
