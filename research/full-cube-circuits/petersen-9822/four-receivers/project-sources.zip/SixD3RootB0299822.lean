import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B029
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (0,2,9)
private noncomputable def rules : List Nat := unpack 35 [0x200000004c00e000c88000000706020002e200000010000400010800000020]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x80183c8005192800c288001c0f001222400261c0000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B029
