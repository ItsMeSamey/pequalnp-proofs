import Mathlib.Data.Finset.Sort
import SixD3Labels9822
import SixH4D2ReceiverFacts9822
import And9822CommonPhysical
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Research.SixD3.Labels PEqualNP.Outside.L_meta_9822.Receivers
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p
structure ThreeRoots (P : Axis→Mask) (R : Fin 10→Mask) where
  x : Fin 10
  y : Fin 10
  z : Fin 10
  xy : x<y
  yz : y<z
  roots : Roots
  rx : R x=ray P roots.a.1 roots.a.2
  ry : R y=ray P roots.b.1 roots.b.2
  rz : R z=ray P roots.c.1 roots.c.2
  exactly : ∀ v,RayValue P (R v) ↔ v=x ∨ v=y ∨ v=z

theorem choose_three {P : Axis→Mask} {R : Fin 10→Mask}
    (d : ((Finset.univ : Finset (Fin 10)).filter (fun v=>RayValue P (R v))).card=3)
    (real : ExactReceivers (fun v q=>q∈R v)) : Nonempty (ThreeRoots P R) := by
  classical
  let S := (Finset.univ : Finset (Fin 10)).filter (fun v=>RayValue P (R v))
  let tag := S.orderEmbOfFin d
  have has (k : Fin 3) : RayValue P (R (tag k)) :=
    (Finset.mem_filter.mp (S.orderEmbOfFin_mem d k)).2
  obtain ⟨i,s,rx⟩ := has 0
  obtain ⟨j,t,ry⟩ := has 1
  obtain ⟨k,u,rz⟩ := has 2
  have different {a b : Fin 10} {i j : Axis} {s t : Bool} (ne : a≠b)
      (ra : R a=ray P i s) (rb : R b=ray P j t) : i≠j :=
    distinctDirectAxes real (fun i q=>q∈P i) (fun i q=>q i) ne
      (fun q=>by rw [ra]; rfl) (fun q=>by rw [rb]; rfl)
  have left : tag 0 < tag 1 := tag.strictMono (by decide)
  have right : tag 1 < tag 2 := tag.strictMono (by decide)
  let roots : Roots := ⟨(i,s),(j,t),(k,u),different left.ne rx ry,
    different (lt_trans left right).ne rx rz,different right.ne ry rz⟩
  refine ⟨⟨tag 0,tag 1,tag 2,left,right,roots,rx,ry,rz,?_⟩⟩
  intro v
  constructor
  · intro h
    have hv : v∈S := Finset.mem_filter.mpr ⟨Finset.mem_univ _,h⟩
    have existsIndex : v∈Set.range tag := (S.range_orderEmbOfFin d).symm ▸ hv
    obtain ⟨w,rfl⟩ := existsIndex
    rcases (show ∀ a : Fin 3,a=0 ∨ a=1 ∨ a=2 by decide +kernel) w with rfl|rfl|rfl <;> simp
  · rintro (rfl|rfl|rfl)
    · exact has 0
    · exact has 1
    · exact has 2
end
end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.choose_three
