import And9822NumericBank
import And9822Banks
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Finset.Sort
import Mathlib.Data.List.Lex

namespace Research.Graph9822.NumericBank
open CommonBank
open Banks

private structure SortedBank where
  values : Finset Nat
  deriving DecidableEq

private instance : LinearOrder SortedBank :=
  LinearOrder.lift' (fun s : SortedBank => s.values.sort) (by
    rintro ⟨a⟩ ⟨b⟩ h
    have eq : a=b := by
      simpa only [Finset.sort_toFinset] using congrArg List.toFinset h
    cases eq
    rfl)

def orderedSets (v : Finset (Finset Nat)) : List (Finset Nat) :=
  ((v.image SortedBank.mk).sort).map SortedBank.values

private theorem mem_orderedSets {v : Finset (Finset Nat)} {s : Finset Nat} :
    s ∈ orderedSets v ↔ s ∈ v := by
  simp [orderedSets]

/-- The finite carrier contains mask values. The caller chooses the identical
numeric identifier for a value in its library and receiver domains. -/
def asBank (id : Nat → Nat) (lib needed B : Finset Nat) : Bank :=
  ⟨((lib ∩ terminal B).sort.map id), needed.sort.map id⟩

def enumerate (id : Nat → Nat) (lib prim named : Finset Nat) (d : Nat) : List Bank :=
  (orderedSets named.powerset).flatMap fun g =>
    if g.card + 2 ≤ d then
      ((orderedSets (libraries (prim ∪ g) (d-2-g.card))).filter
        (fun B => decide (named \ g ⊆ lib ∩ terminal B))).map (asBank id lib (named \ g))
    else []

/-- Every semantic grant is one actual named mask. Every non-granted named
mask is realized by a receiver. Both tests in the enumerator are discharged. -/
theorem keep_from_helpers {α : Type*} (code : Set α → Nat)
    (cup : ∀ a b, code (a ∪ b) = code a ||| code b)
    (id : Nat → Nat) (lib prim named : Finset Nat) (direct : Nat) (dmax : direct ≤ 4)
    (receivers : Fin 10 → Set α) (boxes : Fin 10 → List Nat)
    (inLib : ∀ v, code (receivers v) ∈ lib)
    (inBox : ∀ v, id (code (receivers v)) ∈ boxes v)
    {ray : Set α → Prop} (primCode : ∀ m, ray m → code m ∈ prim)
    {gr : Finset (Set α)} {hs : List (Set α)} (built : Helpers ray gr hs)
    (budget : hs.length + gr.card + 2 ≤ direct)
    (namedGrants : ∀ m ∈ gr, code m ∈ named)
    (namedRaw : ∀ x ∈ named, x ∉ gr.image code → ∃ v, code (receivers v) = x)
    (recv : ∀ v, ray (receivers v) ∨ PairOf (Source ray gr hs) (receivers v)) :
    ∃ b ∈ enumerate id lib prim named direct,
      (∀ v, id (code (receivers v)) ∈ b.available) ∧
      (∀ x ∈ b.required, ∃ v, id (code (receivers v))=x) ∧
      ∀ v, keep (enumerate id lib prim named direct) boxes (id (code (receivers v)))=true := by
  classical
  let g := gr.image code
  have gc : g.card ≤ gr.card := Finset.card_image_le
  have gsub : g ⊆ named := by
    intro x hx
    obtain ⟨m,hm,rfl⟩ := Finset.mem_image.mp hx
    exact namedGrants m hm
  obtain ⟨B,hB,src⟩ := encode_helpers code cup built (prim ∪ g)
    (fun m h => h.elim (fun hr => Finset.mem_union_left _ (primCode _ hr))
      (fun hgr => Finset.mem_union_right _ (Finset.mem_image.mpr ⟨m,hgr,rfl⟩)))
    (k:=direct-2-g.card) (by omega) (by omega)
  have present (v) : code (receivers v) ∈ lib ∩ terminal B := by
    refine Finset.mem_inter.mpr ⟨inLib v,?_⟩
    rcases recv v with raw|⟨a,b,ha,hb,h⟩
    · exact Finset.mem_union_left _ (src _ (Or.inl raw))
    · rw [h,cup]; exact pair_mem (src _ ha) (src _ hb)
  have support : named \ g ⊆ lib ∩ terminal B := by
    intro x hx
    obtain ⟨hn,ng⟩ := Finset.mem_sdiff.mp hx
    obtain ⟨v,rfl⟩ := namedRaw _ hn ng
    exact present v
  let b := asBank id lib (named \ g) B
  have member : b ∈ enumerate id lib prim named direct := by
    unfold enumerate
    apply List.mem_flatMap.mpr
    refine ⟨g,mem_orderedSets.mpr (Finset.mem_powerset.mpr gsub),?_⟩
    simp only [show g.card+2 ≤ direct by omega, if_true]
    apply List.mem_map.mpr
    exact ⟨B,List.mem_filter.mpr ⟨mem_orderedSets.mpr hB,decide_eq_true support⟩,rfl⟩
  have available (v) : id (code (receivers v)) ∈ b.available :=
    List.mem_map.mpr ⟨_,(Finset.mem_sort _).mpr (present v),rfl⟩
  have required (x) (hx : x ∈ b.required) : ∃ v,id (code (receivers v))=x := by
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hx
    obtain ⟨hn,ng⟩ := Finset.mem_sdiff.mp ((Finset.mem_sort _).mp ha)
    obtain ⟨v,hv⟩ := namedRaw _ hn ng
    exact ⟨v,congrArg id hv⟩
  exact ⟨b,member,available,required,keep_of_solution _ b member boxes _ inBox available required⟩
end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.keep_from_helpers
