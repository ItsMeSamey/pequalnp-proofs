import And9822Directions
import ResolveUnion

namespace Research.Graph9822Resolution

def bitsValue : List Bool → Nat
  | [] => 0
  | b :: bs => 2 * bitsValue bs + b.toNat

theorem bitsValue_lt (bs : List Bool) : bitsValue bs < 2 ^ bs.length := by
  induction bs with
  | nil => decide
  | cons b bs ih =>
    cases b <;> simp only [bitsValue,Bool.toNat_true,Bool.toNat_false,List.length_cons,Nat.pow_succ] <;> omega

theorem bitsValue_inj (bs cs : List Bool) (hl : bs.length = cs.length)
    (hv : bitsValue bs = bitsValue cs) : bs = cs := by
  induction bs generalizing cs with
  | nil => cases cs <;> simp_all
  | cons b bs ih =>
    cases cs with
    | nil => simp at hl
    | cons c cs =>
      simp only [List.length_cons,Nat.succ.injEq] at hl
      cases b <;> cases c <;> simp only [bitsValue,Bool.toNat_true,Bool.toNat_false] at hv <;>
        first | exact congrArg _ (ih cs hl (by omega)) | omega

theorem maximal_count_le {k : Nat} (gs : List Gate) (n out : Nat)
    (sets : Fin k → List Nat)
    (distinct : ∀ u v, u ≠ v → ∃ p, p < n ∧ ¬ (p ∈ sets u ↔ p ∈ sets v))
    (reject : ∀ u, eval gs n (inputSet (sets u)) out = false)
    (maximal : ∀ u a, a < n → a ∉ sets u →
      eval gs n (inputSet (a :: sets u)) out = true) :
    k ≤ 2 ^ gs.countP Gate.isAnd := by
  classical
  choose s hs using fun u => maximal_witness gs n (sets u) out (reject u) (maximal u)
  let f : Fin k → Fin (2 ^ gs.countP Gate.isAnd) := fun u =>
    ⟨bitsValue (directions gs n (s u)), by simpa [directions_length] using bitsValue_lt (directions gs n (s u))⟩
  have inj : Function.Injective f := by
    intro u v huv
    by_contra h
    obtain ⟨p,hp,hne⟩ := distinct u v h
    have he := bitsValue_inj (directions gs n (s u)) (directions gs n (s v))
      (by simp [directions_length]) (congrArg Fin.val huv)
    have eqr := congrFun (resolve_congr_directions gs n (s u) (s v)
      (fun j => decide (j=p)) he) out
    have hu := hs u p hp
    have hv := hs v p hp
    rw [eqr] at hu
    tauto
  simpa using Fintype.card_le_of_injective f inj

end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.maximal_count_le
