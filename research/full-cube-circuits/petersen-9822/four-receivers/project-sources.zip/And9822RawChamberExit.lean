import And9822D2Row3182

namespace Research.Graph9822.TraceCount
open Research.Graph9822.FourSaturation

def activation (P : Profile) (i : Axis) (w : Word) : Bool := (P i).testBit w.val

def NonprimitiveName (P : Profile) (i : Axis) : Prop :=
  (∃ w, activation P i w = false) ∧
  ∀ j : Axis, ∀ b : Bool, ∃ w, activation P i w ≠ branch P j b w

def AllNamesRaw (P : Profile) (R : Fin 10 → Word → Bool) : Prop :=
  ∀ i, NonprimitiveName P i → ∃ v, R v = activation P i

def Thin (P : Profile) (i : Axis) : Prop :=
  NonprimitiveName P i ∧ (outsideTraces P (activation P i)).length < 5

instance (P : Profile) (i : Axis) : Decidable (Thin P i) := by
  unfold Thin NonprimitiveName
  infer_instance

theorem thin_exit (P : Profile) (i : Axis) (thin : Thin P i)
    (R : Fin 10 → Word → Bool) (built : ∀ v, Generated P (R v))
    (realize : ∀ m ∈ witnesses, ∃ w, ∀ u : Fin 10, R u w = !(m.testBit u.val))
    (allRaw : AllNamesRaw P R) : False := by
  obtain ⟨v,eq⟩ := allRaw i thin.1
  have bound := raw_outside_five P R built realize v
  rw [eq] at bound
  exact (Nat.not_lt_of_ge bound) thin.2

/-- Catalogue group 97, local ordinals 1 through 16. The initial five
activations are stored once and all members have the same failing axis. -/
def group97 (s : Fin 16) (i : Axis) : Nat :=
  if i.val < 5 then profile3182 i else
  ([48132216733761535,72620539713290239,120471285765242879,1230045644216991743,
    1277896390268944383,4919338164822540287,4967188910874492927,4991677233854021631,
    5039527979905974271,6149102338357723135,6196953084409675775,12297923206033637375,
    12370262275065118719,13527687379568820223,17216979900174368767,17289318969205850111] :
      List Nat)[s.val]!

set_option maxHeartbeats 3000000 in
theorem group97_thin : ∀ n : Fin 16, Thin (group97 n) 5 := by decide +kernel

def group97_exit (n : Fin 16) := thin_exit (group97 n) 5 (group97_thin n)

end Research.Graph9822.TraceCount
#print axioms Research.Graph9822.TraceCount.group97_exit
