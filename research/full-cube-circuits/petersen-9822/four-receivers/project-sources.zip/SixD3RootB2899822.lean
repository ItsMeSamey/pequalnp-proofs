import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B289
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (2,8,9)
private noncomputable def rules : List Nat := unpack 35 [0x402c192210058323a200b0646240160c8a4802c191110058321c200b0642e40160c840800000030000000010]
private def keys : List Nat := (List.range 10).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x20004fe800941600350a8011442005517801947e00752880214ca009ae3000400000a] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B289
