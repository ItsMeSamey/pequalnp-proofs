import AndAllFullPilot9822
import Mathlib.Data.Nat.Find
set_option maxRecDepth 100000
set_option maxHeartbeats 0

-- And9822LiteralBank cbddd4dd63e703e573ebeba392ce8f2e27319806d6287b1fb08318566253abd3

namespace Research.Graph9822.LiteralBank
open UnionCharge
abbrev Pairs := List (Nat × Nat)
def has (w l : Nat) : Prop := (w+1).testBit l = true
instance (w l) : Decidable (has w l) := inferInstanceAs (Decidable (_ = true))
private theorem nonempty (w : Nat) : ∃ l, has w l :=
  ⟨(w+1).log2,Nat.testBit_log2 (by omega)⟩
def first (w : Nat) := Nat.find (nonempty w)
theorem le_first (w k : Nat) (h : has w k) : first w ≤ k := Nat.find_min' _ h
theorem first_ok (w : Nat) : has w (first w) := Nat.find_spec _
def merge (x y : Nat) := ((x+1) ||| (y+1))-1
theorem merge_value (x y : Nat) : merge x y + 1 = ((x+1) ||| (y+1)) := by
  have h : ((x+1) ||| (y+1)) ≠ 0 := by
    intro hz
    have e := congrArg (fun n : Nat => n.testBit (first x)) hz
    simp only [Nat.testBit_or] at e
    have hx : (x+1).testBit (first x) = true := first_ok x
    simp [hx] at e
  unfold merge
  omega

theorem merge_has (x y l : Nat) : has (merge x y) l ↔ has x l ∨ has y l := by
  simp [has,merge_value,Nat.testBit_or]
theorem merge_first (x y : Nat) : first (merge x y) = min (first x) (first y) := by
  have hx := le_first _ _ ((merge_has x y _).mpr (Or.inl (first_ok x)))
  have hy := le_first _ _ ((merge_has x y _).mpr (Or.inr (first_ok y)))
  rcases (merge_has x y _).mp (first_ok _) with h|h
  · have := le_first _ _ h
    omega
  · have := le_first _ _ h
    omega
def lit (l : Nat) := 2^l-1
theorem lit_has (l k : Nat) : has (lit l) k ↔ l=k := by
  have h : lit l + 1 = 2^l := by unfold lit; have := Nat.two_pow_pos l; omega
  simp [has,h,Nat.testBit_two_pow]
theorem lit_first (l : Nat) : first (lit l) = l := ((lit_has l _).mp (first_ok _)).symm
def bank (ps : Pairs) : Bank ps.length where
  left i := (ps.get i).1
  right i := (ps.get i).2
  output i := merge (ps.get i).1 (ps.get i).2
  has := has
  first := first
  firstLe := le_first
  firstMem := first_ok
  unionMem i := merge_has _ _
  firstUnion i := merge_first _ _

theorem lit_built (ps : Pairs) (l : Nat) : Built (bank ps) (lit l) :=
  .singleton _ (fun k hk => by change k = first (lit l); rw [lit_first]; exact ((lit_has _ _).mp hk).symm)

theorem weaken (p : Nat × Nat) (ps : Pairs) {w : Nat} (b : Built (bank ps) w) :
    Built (bank (p::ps)) w := by
  induction b with
  | singleton w h => exact .singleton w h
  | join i _ _ ih jh =>
    exact Built.join (b := bank (p::ps)) i.succ ih jh

theorem join_built (ps : Pairs) {x y : Nat} (hx : Built (bank ps) x) (hy : Built (bank ps) y) :
    Built (bank ((x,y)::ps)) (merge x y) :=
  Built.join (b := bank ((x,y)::ps)) ⟨0,by simp⟩ (weaken _ _ hx) (weaken _ _ hy)

end Research.Graph9822.LiteralBank
#print axioms Research.Graph9822.LiteralBank.join_built

-- And9822Width d067dbed764b1d69a75b649203903118fc738d69375b92df88e3d12519299862
namespace Research.Graph9822.UnionCharge

/-- Every listed nonleast source label needs its own merge. Joins reserved for
incomparable outputs are disjoint from these charges. -/
theorem width_with_reserved {c k t : Nat} (b : Bank c) (w : Nat) (built : Built b w)
    (label : Fin k → Nat) (use : ∀ i, b.has w (label i))
    (nonleast : ∀ i, b.first w < label i)
    (labelInj : ∀ i j, label i = label j → i = j)
    (reserved : Fin t → Fin c) (reserveInj : ∀ i j, reserved i = reserved j → i = j)
    (outside : ∀ j, ∃ l, b.has (b.output (reserved j)) l ∧ ¬ b.has w l) : k+t ≤ c := by
  classical
  have ex (i : Fin k) := chargeExists b built (use i) (nonleast i)
  let charge (i : Fin k) : Fin c := Classical.choose (ex i)
  have spec (i : Fin k) : Charge b w (label i) (charge i) := Classical.choose_spec (ex i)
  have ci {i j} (h : charge i = charge j) : i=j :=
    labelInj _ _ ((spec i).label.symm.trans ((congrArg (loss b) h).trans (spec j).label))
  have dis (i : Fin k) (j : Fin t) : charge i ≠ reserved j := by
    intro he
    obtain ⟨l,mem,no⟩ := outside j
    rw [←he] at mem
    exact no ((spec i).sub _ mem)
  let f (z : Fin (k+t)) : Fin c :=
    if h : z.val < k then charge ⟨z.val,h⟩
    else reserved ⟨z.val-k,by have := z.isLt; omega⟩
  have fi {x y : Fin (k+t)} (he : f x = f y) : x=y := by
    by_cases hx : x.val<k <;> by_cases hy : y.val<k
    · simp only [f,dif_pos hx,dif_pos hy] at he
      exact Fin.ext (congrArg (fun z : Fin k => z.val) (ci he))
    · simp only [f,dif_pos hx,dif_neg hy] at he
      exact False.elim (dis _ _ he)
    · simp only [f,dif_neg hx,dif_pos hy] at he
      exact False.elim (dis _ _ he.symm)
    · simp only [f,dif_neg hx,dif_neg hy] at he
      have eq := congrArg Fin.val (reserveInj _ _ he)
      apply Fin.ext
      change x.val-k = y.val-k at eq
      omega
  have nd : ((List.finRange (k+t)).map f).Nodup :=
    List.pairwise_map.mpr ((List.nodup_finRange _).imp (fun h e => h (fi e)))
  have h := nd.length_le_of_subset (l₂ := List.finRange c) (fun {x} _ => List.mem_finRange x)
  simpa using h

end Research.Graph9822.UnionCharge
#print axioms Research.Graph9822.UnionCharge.width_with_reserved
