import SixD3GridDataA2489822
namespace Research.Graph9822.ThreeDirect.A248
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part1152 : Range (aOK d) (aCl d) g 1152 1176 :=
  rangeCheck _ _ _ 1152 24 (by decide +kernel)
private theorem part1176 : Range (aOK d) (aCl d) g 1176 1200 :=
  rangeCheck _ _ _ 1176 24 (by decide +kernel)
private theorem part1200 : Range (aOK d) (aCl d) g 1200 1224 :=
  rangeCheck _ _ _ 1200 24 (by decide +kernel)
private theorem part1224 : Range (aOK d) (aCl d) g 1224 1248 :=
  rangeCheck _ _ _ 1224 24 (by decide +kernel)
private theorem part1248 : Range (aOK d) (aCl d) g 1248 1272 :=
  rangeCheck _ _ _ 1248 24 (by decide +kernel)
private theorem part1272 : Range (aOK d) (aCl d) g 1272 1296 :=
  rangeCheck _ _ _ 1272 24 (by decide +kernel)
theorem sem8 : Range (aOK d) (aCl d) g 1152 1296 := rangeAppend part1152 (rangeAppend part1176 (rangeAppend part1200 (rangeAppend part1224 (rangeAppend part1248 (part1272)))))
end Research.Graph9822.ThreeDirect.A248
