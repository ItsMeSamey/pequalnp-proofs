import CutGroupLedger
import ReversePhysical

-- OuterReceiverExact9822.lean line 3

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles Research.Graph9822Resolution

theorem mem_collect_deliver (w : Word) (q : Inbox) (k j : Nat) (m : Mask) :
    w ∈ collect (deliver q k m j) ↔ w ∈ collect (q j) ∨ (j=k ∧ w ∈ m) := by
  by_cases e : j=k
  · simp [e, deliver, collect, or_comm]
  · simp [e, deliver]

theorem mem_advance_gate (w : Word) (s : ReverseState) (g : DGate) (i a : Nat)
    (axis : Nat → Axis) :
    w ∈ collect ((advance s (gateEvent g i axis)).q a) ↔
      w ∈ collect (s.q a) ∨
        (w ∈ collect (s.q i) ∧
          resolved g (w (axis i)) (decide (g.left=a)) (decide (g.right=a)) = true) := by
  by_cases empty : s.q i = []
  · cases h : g.isAnd <;> simp [advance, gateEvent, h, Event.address, empty, collect]
  · have adv : advance s (gateEvent g i axis) = next s (gateEvent g i axis) := by
      cases h : g.isAnd <;> simp [gateEvent,h,advance,Event.address,empty]
    rw [adv]
    cases h : g.isAnd <;> cases b : w (axis i) <;>
      by_cases l : a = g.left <;> by_cases r : a = g.right <;>
      simp only [advance,gateEvent,h,Event.address,Bool.false_eq_true,ite_false,ite_true,
        decide_false,decide_true,next,mem_collect_deliver,
        Set.mem_inter_iff,side,Set.mem_setOf_eq,b,resolved] <;> simp_all <;> tauto

/-- Membership of a reverse receiver at a word is exactly forward singleton
propagation through the resolved physical gates. Shared operands are allowed. -/
theorem back_receiver_exact (axis : Nat → Axis) (w : Word) (gs : List DGate)
    (i a out : Nat) (ha : a < i) :
    w ∈ collect ((back axis gs i (initial out)).q a) ↔
      reaches gs i (fun j => w (axis j)) out a = true := by
  induction gs generalizing i a with
  | nil =>
    by_cases e : a=out <;> simp [back,initial,deliver,e,collect,reaches,resolve,atom,eq_comm] <;> exact Ne.symm e
  | cons g gs ih =>
    rw [back, mem_advance_gate, reverse_step g gs i a _ out ha,
        ih (i+1) a (by omega), ih (i+1) i (by omega)]
    simp

end Research.Graph9822Profiles.OuterLive
-- OuterReceiverList9822.lean line 3

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles Research.Graph9822Resolution

theorem raw_fold_receivers (n : Nat) (s : ReverseState) :
    ((rawEvents n).foldl next s).receivers =
      ((List.range n).map (fun a => collect (s.q a))) ++ s.receivers := by
  induction n generalizing s with
  | zero => rfl
  | succ n ih =>
    rw [rawEvents, List.foldl_cons, ih]
    simp [next,Event.address,List.range_succ,List.append_assoc]

theorem gate_receivers (axis : Nat → Axis) (gs : List DGate) (i : Nat) (s : ReverseState) :
    (back axis gs i s).receivers = s.receivers := by
  induction gs generalizing i with
  | nil => rfl
  | cons g gs ih =>
    cases h : g.isAnd <;> cases hq : ((back axis gs (i+1) s).q i).isEmpty <;>
      simp [back,advance,gateEvent,Event.address,h,hq,next,ih]

/-- The completed physical bank lists the receivers in increasing raw order.
The mask at each label is fixed by the physical resolution, including the
auxiliary raw substituted for the inverter. -/
theorem receiver_list_exact (axis : Nat → Axis) (gs : List DGate) (n out : Nat)
    (live : ∀ j < n, (back axis gs n (initial out)).q j ≠ []) :
    ((activeEvents (gateEvents axis gs n ++ rawEvents n) (initial out)).foldl next
      (initial out)).receivers =
    (List.range n).map (fun a => {w | reaches gs n (fun j => w (axis j)) out a = true}) := by
  rw [active_append,gates_fold,raw_all _ _ live,List.foldl_append,fold_active,gates_fold,
      raw_fold_receivers,gate_receivers]
  simp only [initial,List.append_nil]
  apply List.map_congr_left
  intro a ha
  ext w
  exact back_receiver_exact axis w gs n a out (List.mem_range.mp ha)

end Research.Graph9822Profiles.OuterLive
