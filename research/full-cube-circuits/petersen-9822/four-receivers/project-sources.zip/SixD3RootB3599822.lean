import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B359
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (3,5,9)
private noncomputable def rules : List Nat := unpack 35 [0x4010060808000000804038183220000001c0808060b8800000040]
private def keys : List Nat := (List.range 6).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x20050f8800c162001d32001303c0028890000000006] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B359
