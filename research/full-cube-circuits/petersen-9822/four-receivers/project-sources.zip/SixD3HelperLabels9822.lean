import SixD3Selection9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral Research.SixH4.PairPartition Research.Graph9822Resolution
open Research.Graph9822.ThreeDirect

theorem arm_length (r : Roots) (ts : List Lit) : (normArm r ts).length=ts.length := by
  simp [normArm]
theorem normalized_length (r : Roots) (L : V → List Lit) (v : V) :
    (normalized r L v.val).length=(L v).length := by simp [normalized,v.isLt,arm_length]
theorem helper_pair (r : Roots) (a b : Lit) (ab : a.1≠b.1) (W : List Lit)
    (inside : ∀ t∈[a,b],t∈W) (na : r.a∉W) (nb : r.b∉W) (nc : r.c∉W) :
    normArm r [a,b] ∈ pairs := by
  have shape : Shape false [a,b] := Or.inl ⟨a,b,ab,rfl⟩
  simpa using shape_selected r [a,b] false shape (fun h=>na (inside _ h))
    (fun h=>nb (inside _ h)) (fun h=>nc (inside _ h))
theorem linked (r : Roots) (H : List Lit) (L : V → List Lit)
    (bound : ∀ v, (L v).length=3 → ∀ t∈H,t∈L v) :
    ∀ n, n<10 → (normalized r L n).length=3 → ∀ k∈normArm r H,k∈normalized r L n := by
  intro n hn len k hk
  let v : V := ⟨n,hn⟩
  obtain ⟨t,ht,eq⟩ := (arm_mem r H k).1 hk
  apply (normalized_mem r L v k).2
  exact ⟨t,bound v ((normalized_length r L v).symm.trans len) t ht,eq⟩
end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.linked
