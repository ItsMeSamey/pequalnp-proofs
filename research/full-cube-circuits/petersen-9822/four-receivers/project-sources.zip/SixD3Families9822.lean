import SixD3ChoosePlan9822
import SixWideSharedRaw9822
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
def Families (N : Finset Mask) (P : Axis→Mask) (p : List (Axis×Mask)) (e : List Mask) : Prop :=
  (∀ m∈N,DistinctPair P m) ∨
    ∃ H∈e,∃ a c : Tag,Seen p P a ∧ Seen p P c ∧ a.1≠c.1 ∧ H=value P a∪value P c ∧
      (∀ m∈N,FixedRaw P a c m) ∧ ∃ m∈N,H⊆m ∧ H≠m
theorem family_cover {N b l p e} (run : Marked N b l p e) (P : Axis→Mask)
    (ok : ∀ t∈p,t.2=P t.1) (one : e.length≤1) (returned : ∀ m∈N,m∈l)
    (anti : ∀ x∈N,∀ y∈N,x⊆y → x=y) (top : Set.univ∉N) (no : ∀ i s,P i∩side i s∉N) :
    Families N P p e := by
  classical
  by_cases all : ∀ m∈N,DistinctPair P m
  · exact Or.inl all
  push_neg at all
  obtain ⟨m,raw,bad⟩ := all
  rcases marked_shared run P ok one anti top no m (returned m raw) raw with pair|shared
  · exact False.elim (bad pair)
  obtain ⟨H,hit,k,s,ne,eq⟩ := shared
  have sub : H⊆m := by rw [eq]; exact fun _ z=>Or.inl z
  have only {K : Mask} (hk : K∈e) : K=H := by
    cases e with
    | nil => simp at hit
    | cons x xs =>
      have nil : xs=[] := List.length_eq_zero_iff.mp (by simp only [List.length_cons] at one; omega)
      subst xs
      exact (List.mem_singleton.mp hk).trans (List.mem_singleton.mp hit).symm
  have clean (K : Mask) (hk : K∈e) : K≠Set.univ ∧ ∀ a∈N,¬a⊆K := by
    rw [only hk]
    constructor
    · intro full
      have mtop : m=Set.univ := Set.eq_univ_of_forall (fun q=>sub (by rw [full]; trivial))
      exact top (mtop ▸ raw)
    · intro a ha small
      have same := anti _ ha _ raw (small.trans sub)
      exact ne (Set.Subset.antisymm sub (same ▸ small))
  obtain ⟨mode,plan,describe⟩ := fixed_plan run P ok one clean anti top no
  cases plan with
  | clean => simp at hit
  | ray seen val => exact False.elim (bad (describe m (returned m raw) raw))
  | @pair h a c first last diff valid =>
    have hH : h=H := (List.mem_singleton.mp hit).symm
    exact Or.inr ⟨h,List.mem_cons_self,a,c,first,last,diff,valid,
      fun v hv=>describe _ (returned v hv) hv,m,raw,by rw [hH]; exact sub,by rw [hH]; exact ne⟩
end Research.Graph9822Profiles.Fresh
#print axioms Research.Graph9822Profiles.Fresh.family_cover
