import SixD3GridUnits9822
import SixD3GridDataA1379822
namespace Research.Graph9822.ThreeDirect.A137
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit0 : ∀ a, Known a g 2391 → Known a g 2392 :=
  singleKnown g 2391 (unpack 28 [0x10fdc0000e685130e643d325183330d8c2920d797f4]) (by decide +kernel)
private theorem unit1 : ∀ a, Known a g 2392 → Known a g 2393 :=
  singleKnown g 2392 (unpack 28 [0x10d6c0000ba17c40d5976b0cbd6f90c7d6ef0bd15f70d097050c256e10ba55b50ba95c30bf564d251833324fc1f324dc0b30d8c292089815208540120d797f40888e9008449dc]) (by decide +kernel)
private theorem unit2 : ∀ a, Known a g 2393 → Known a g 2394 :=
  singleKnown g 2393 (unpack 28 [0x10ecc000068e0ab059a0a104b606b]) (by decide +kernel)
private theorem unit3 : ∀ a, Known a g 2394 → Known a g 2395 :=
  singleKnown g 2394 (unpack 28 [0x10ba000018f561d18515f718055e717a95d917515cd1b316ef1bb17911c016c11c316f91cad79b1ce16cd19ad6a919c96e11a357831a8566f1abd68d1d997a71e217b51e797c5197567f1b116b71d1d70519416610ba55b50ba95c30bf564d251833324fc1f324dc0b30d8c292089815208540120d797f40888e9008449dc]) (by decide +kernel)
private theorem unit4 : ∀ a, Known a g 2395 → Known a g 2396 :=
  singleKnown g 2395 (unpack 28 [0x10e6c000050e07b06da0810416051]) (by decide +kernel)
private theorem unit5 : ∀ a, Known a g 2396 → Known a g 2397 :=
  singleKnown g 2396 (unpack 28 [0x10ef4000100deab0ff9e51042a0a70426093041a0a5041609104060550efdccf0f45d550ef9ccb251432b250c327250832524f41eb24f01e524d80ab24d00a70d8828a0d802860d7c284089014a088c144085000a08480060d797f40888e9008449dc]) (by decide +kernel)
private theorem unit6 : ∀ a, Known a g 2397 → Known a g 2398 :=
  singleKnown g 2397 (unpack 28 [0x10ef4000100deab0ff9e5107660a70762093070a0a50ff1e090f05cdd0e6e0800e745b30efdccf0f45d550ef9ccb2518333251432b250c327250832524f41eb24f01e524d80ab24d00a70d8c2920d8828a0d802860d7c284089014a088c144085000a08480060d797f40888e9008449dc]) (by decide +kernel)
private theorem unit7 : ∀ a, Known a g 2398 → Known a g 2399 :=
  singleKnown g 2398 (unpack 28 [0x112a00000971496098137d09e54170ac14a9172157516f951b16d1565168d50b154154b15214f114c147114a153d141949b13ed463136541b133553912d94df127545f11c53cd11893b911353a711013970db83d314454e30db03c4097936f09d93f5097536b2518333250c32724fc1f324f01e524dc0b324d00a70d8c2920d802860898152088c144085401208480060d797f40888e9008449dc]) (by decide +kernel)
private theorem unit8 : ∀ a, Known a g 2399 → Known a g 2400 :=
  singleKnown g 2399 (unpack 28 [0x116fc0000da5a8c1701aab1705abd0dada770da9a650df5afd251432b250832524f41eb24f01e524d80ab0d8828a0d7c284089014a088c144085000a0d797f40888e9008449dc]) (by decide +kernel)
private theorem unit9 : ∀ a, Known a g 2400 → Known a g 2401 :=
  singleKnown g 2400 (unpack 28 [0x109700000ae14f1097d37d0bb43de0bac3c70ba15cc18455f717f95e7169150b189960911c93cd118d3b9110539718e961d097936f09d93f50ba55b50ba95c30bf564d097536b2518333250c32724fc1f324e40bf24dc0b324d00a70d8c2920d802860898152085c01e085401208480060d797f40888e9008449dc]) (by decide +kernel)
private theorem unit10 : ∀ a, Known a g 2401 → Known a g 2402 :=
  singleKnown g 2401 (unpack 28 [0x109700000b7951b09bd3a70bd85be099d3970ba15f618ed61d189d60917fd5e717455cd169550b15254f111cd3cd11913b910d538910a137d0dcc504097936f09d93f50ba55b50ba95c30bf564d097536b2518333250c32724fc1f324f01e524e40bf24dc0b324d00a70d8c2920d802860898152088c144085c01e085401208480060d797f40888e9008449dc]) (by decide +kernel)
private theorem unit11 : ∀ a, Known a g 2402 → Known a g 2403 :=
  singleKnown g 2402 (unpack 28 [0x10cd40000ae465f0ae03df09714f0097d37d0ccc3c7097936f09d93f5097536b2518333250c32724fc1f324e40bf24dc0b324d00a70d8c2920d802860898152085c01e085401208480060d797f40888e9008449dc]) (by decide +kernel)
theorem up0 : ∀ a, Known a g 2391 → Known a g 2403 := by
  intro a h
  apply unit11 a
  apply unit10 a
  apply unit9 a
  apply unit8 a
  apply unit7 a
  apply unit6 a
  apply unit5 a
  apply unit4 a
  apply unit3 a
  apply unit2 a
  apply unit1 a
  apply unit0 a
  exact h
end Research.Graph9822.ThreeDirect.A137
