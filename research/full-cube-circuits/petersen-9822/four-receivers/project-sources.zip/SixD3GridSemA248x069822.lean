import SixD3GridDataA2489822
namespace Research.Graph9822.ThreeDirect.A248
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part864 : Range (aOK d) (aCl d) g 864 888 :=
  rangeCheck _ _ _ 864 24 (by decide +kernel)
private theorem part888 : Range (aOK d) (aCl d) g 888 912 :=
  rangeCheck _ _ _ 888 24 (by decide +kernel)
private theorem part912 : Range (aOK d) (aCl d) g 912 936 :=
  rangeCheck _ _ _ 912 24 (by decide +kernel)
private theorem part936 : Range (aOK d) (aCl d) g 936 960 :=
  rangeCheck _ _ _ 936 24 (by decide +kernel)
private theorem part960 : Range (aOK d) (aCl d) g 960 984 :=
  rangeCheck _ _ _ 960 24 (by decide +kernel)
private theorem part984 : Range (aOK d) (aCl d) g 984 1008 :=
  rangeCheck _ _ _ 984 24 (by decide +kernel)
theorem sem6 : Range (aOK d) (aCl d) g 864 1008 := rangeAppend part864 (rangeAppend part888 (rangeAppend part912 (rangeAppend part936 (rangeAppend part960 (part984)))))
end Research.Graph9822.ThreeDirect.A248
