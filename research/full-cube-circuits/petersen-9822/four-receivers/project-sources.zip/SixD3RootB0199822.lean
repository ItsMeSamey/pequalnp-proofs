import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B019
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (0,1,9)
private noncomputable def rules : List Nat := unpack 35 [0x200003804c00c070c880000006060201c2e200000010000207010800000010]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x80183e4005199800c2a4001ae300122240024f00000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B019
