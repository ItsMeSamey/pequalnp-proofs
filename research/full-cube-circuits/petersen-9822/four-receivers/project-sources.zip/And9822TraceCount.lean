import Std
namespace Research.Graph9822.TraceCount

abbrev Word := Fin 64
abbrev Axis := Fin 6
abbrev Profile := Axis → Nat
def branch (P : Profile) (i : Axis) (s : Bool) (w : Word) : Bool :=
  (P i).testBit w.val && (w.val.testBit i.val == s)
def trace (P : Profile) (w : Word) : List (Bool × Bool) :=
  (List.finRange 6).map (fun i => (branch P i false w,branch P i true w))
def atoms (P : Profile) := ((List.finRange 64).map (trace P)).eraseDups

theorem same_branches (P : Profile) (w z : Word) (he : trace P w = trace P z) (i : Axis)
    (s : Bool) : branch P i s w = branch P i s z := by
  have e := congrArg (fun a : List (Bool × Bool) => a[i.val]?) he
  simp [trace,List.getElem?_map,List.getElem?_eq_getElem (l := List.finRange 6)
    (i := i.val) (by simpa using i.isLt),List.getElem_finRange] at e
  cases s
  · exact e.1
  · exact e.2

inductive Generated (P : Profile) : (Word → Bool) → Prop where
  | const (b : Bool) : Generated P (fun _ => b)
  | raw (i : Axis) (s : Bool) : Generated P (branch P i s)
  | join {f g} : Generated P f → Generated P g → Generated P (fun u => f u || g u)

theorem generated_congr (P : Profile) {f} (hg : Generated P f) {w z : Word}
    (he : trace P w = trace P z) : f w = f z := by
  induction hg with
  | const _ => rfl
  | raw i s => exact same_branches _ _ _ he i s
  | join _ _ hf hg => dsimp only; rw [hf,hg]

theorem witnessBound (P : Profile) {n : Nat} (f : Fin 10 → Word → Bool)
    (built : ∀ v, Generated P (f v)) (sel : Fin n → Word)
    (diff : ∀ i j, i ≠ j → ∃ v, f v (sel i) ≠ f v (sel j)) : n ≤ (atoms P).length := by
  let t (i : Fin n) := trace P (sel i)
  have inj {i j : Fin n} (h : t i = t j) : i = j := by
    apply Classical.byContradiction
    intro ne
    obtain ⟨v,hv⟩ := diff i j ne
    exact hv (generated_congr P (built v) h)
  have nd : ((List.finRange n).map t).Nodup :=
    List.pairwise_map.mpr ((List.nodup_finRange n).imp (fun h e => h (inj e)))
  have sub : (List.finRange n).map t ⊆ atoms P := by
    intro x hx
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp hx
    exact List.mem_eraseDups.mpr (List.mem_map.mpr ⟨sel i,List.mem_finRange _,rfl⟩)
  simpa using nd.length_le_of_subset sub

end Research.Graph9822.TraceCount
#print axioms Research.Graph9822.TraceCount.witnessBound
