import SixD3Issued9822
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
private theorem collapsed {N b l p} {H m : Mask} (run : Marked N b l p [H]) (P : Axis→Mask)
    (ok : ∀ t∈p,t.2=P t.1) (anti : ∀ x∈N,∀ y∈N,x⊆y → x=y) (top : Set.univ∉N)
    (raw : m∈N) (fresh : m∉l) (a c z : Tag) (sa : Seen p P a) (sc : Seen p P c)
    (axis : a.1=z.1) (help : H=value P a∪value P c) (eq : m=H∪value P z) :
    DistinctPair P m := by
  obtain ⟨i,s⟩ := a
  obtain ⟨k,t⟩ := z
  change i=k at axis
  subst k
  have stored : H∈l := spare_in_store run H (by simp)
  have hm : H≠m := fun h=>fresh (h ▸ stored)
  by_cases signs : s=t
  · subst t
    have below : value P (i,s)⊆H := by rw [help]; exact fun _ h=>Or.inl h
    exact False.elim (hm (by rw [eq,Set.union_eq_self_of_subset_right below]))
  · have eq' : m=P i∪value P c := by
      rw [eq,help]
      ext q
      change (((q∈P i ∧ q i=s) ∨ q∈value P c) ∨ (q∈P i ∧ q i=t)) ↔ q∈P i ∨ q∈value P c
      cases s <;> cases t <;> cases q i <;> simp_all [or_comm,or_left_comm]
    have below : P i⊆m := by rw [eq']; exact fun _ h=>Or.inl h
    have source := marked_sources run
    have mem : P i∈l := source.2 (i,P i) sa
    rcases source.1 _ mem with full|paid|org|spare
    · have all : m=Set.univ := Set.eq_univ_of_forall (fun q=>below (by rw [full]; trivial))
      exact False.elim (top (all ▸ raw))
    · exact False.elim (fresh ((anti _ paid _ raw below) ▸ mem))
    · obtain ⟨r,sr,er⟩ := seen_origin ok org
      exact ordinary_issued run P fresh r c sr sc (by rw [←er,eq'])
    · have same : P i=H := List.mem_singleton.mp spare
      have nested : value P (i,t)⊆H := fun _ h=>same ▸ h.1
      exact False.elim (hm (by rw [eq,Set.union_eq_self_of_subset_right nested]))
def FixedRaw (P : Axis→Mask) (a c : Tag) (m : Mask) : Prop :=
  DistinctPair P m ∨ ∃ z : Tag, z.1≠a.1 ∧ z.1≠c.1 ∧ m=(value P a∪value P c)∪value P z
theorem clean_extra_union {N b l p} {H m : Mask} (run : Marked N b l p [H]) (P : Axis→Mask)
    (ok : ∀ t∈p,t.2=P t.1) (anti : ∀ x∈N,∀ y∈N,x⊆y → x=y) (top : Set.univ∉N)
    (raw : m∈N) (fresh : m∉l) (a c z : Tag) (sa : Seen p P a) (sc : Seen p P c)
    (help : H=value P a∪value P c) (eq : m=H∪value P z) : FixedRaw P a c m := by
  by_cases first : a.1=z.1
  · exact Or.inl (collapsed run P ok anti top raw fresh a c z sa sc first help eq)
  by_cases last : c.1=z.1
  · exact Or.inl (collapsed run P ok anti top raw fresh c a z sc sa last
      (help.trans (Set.union_comm _ _)) eq)
  · exact Or.inr ⟨z,Ne.symm first,Ne.symm last,by rw [eq,help]⟩
end Research.Graph9822Profiles.Fresh
