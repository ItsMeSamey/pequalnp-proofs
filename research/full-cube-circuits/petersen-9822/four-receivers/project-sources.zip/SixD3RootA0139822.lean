import SixD3RootA0239822
import SixD3Sigma013To0239822
namespace Research.Graph9822.ThreeDirect.A013
def d : Dir := (0,1,3)
theorem closed : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact A023.closed ⟨Sigma.shared013_023 p⟩
end Research.Graph9822.ThreeDirect.A013
