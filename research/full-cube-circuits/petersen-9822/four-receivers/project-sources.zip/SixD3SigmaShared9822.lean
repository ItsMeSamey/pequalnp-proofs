import SixD3SigmaValues9822
namespace Research.Graph9822.ThreeDirect.Sigma
open Research.Graph9822.TwoDirect (Arm edge)
open Research.Graph9822.TwoDirect.Symmetry (vertex legal_vertex edge_transfer)
theorem helper_image : ∀ s : Swap,∀ h∈pairs,arm s h∈pairs := by decide +kernel
theorem wrong_image (s : Swap) (w : Fin 64) (j : Fin 6) :
    lbl s (2*j.val+(if w.val.testBit j.val then 0 else 1)) =
    2*axis s j+(if (word s w).testBit (axis s j) then 0 else 1) := by
  rw [bit_image]
  cases w.val.testBit j.val with
  | true => exact (poles_image s j).1
  | false => exact (poles_image s j).2
def sharedTransfer {s src dst} (law : Spec s src dst) (p : Shared src) : Shared dst where
  toRooms := roomsTransfer law p.toRooms
  helper := arm s p.helper
  origin j := origin s (p.origin (axis s j))
  helperOK := helper_image s _ p.helperOK
  linked v hv h k mem := by
    apply (arm_mem s _ k).2
    apply p.linked _ (legal_vertex ⟨v,hv⟩)
    · exact (length_image s _).symm.trans h
    · exact (arm_mem s _ k).1 mem
  named j hj := law.named ⟨j,hj⟩ _ (p.named _ (small_axis s ⟨j,hj⟩))
  activation j hj m hm := by
    change (p.ray (lbl s (2*j)) (obsMap s m) || p.ray (lbl s (2*j+1)) (obsMap s m)) = _
    rw [(poles_image s ⟨j,hj⟩).1,(poles_image s ⟨j,hj⟩).2,
      p.activation _ (small_axis s ⟨j,hj⟩) _ (obs_ok s m hm)]
    exact (value_image s _ (law.origBound ⟨_,small_axis s ⟨j,hj⟩⟩ _ (p.named _ (small_axis s ⟨j,hj⟩)))
      (fun k=>p.ray k (obsMap s m)) p.raw p.helper).symm
  fullNonneighbor := absent_image law p
  ordinaryNeighbor := ordinary_image law p
  wrongSign w hw j hj := by
    change p.ray (lbl s (2*j+(if w.testBit j then 0 else 1))) (obsMap s (1024+w))=false
    rw [wrong_image s ⟨w,hw⟩ ⟨j,hj⟩,obs_word]
    exact p.wrongSign _ (word_bound s ⟨w,hw⟩) _ (small_axis s ⟨j,hj⟩)
  edgeWords u v lt hv e w hw := by
    let i : Fin 10 := ⟨u,by omega⟩
    let j : Fin 10 := ⟨v,hv⟩
    change ((arm s (p.raw (vertex u))).any (fun k=>p.ray (lbl s k) (obsMap s (1024+w))) ||
      (arm s (p.raw (vertex v))).any (fun k=>p.ray (lbl s k) (obsMap s (1024+w))))=true
    rw [any_image s (p.raw (vertex u)) (fun k=>p.ray k (obsMap s (1024+w))),
      any_image s (p.raw (vertex v)) (fun k=>p.ray k (obsMap s (1024+w))),obs_word]
    rcases edge_transfer i j lt e with ⟨a,h⟩|⟨a,h⟩
    · exact p.edgeWords _ _ a (legal_vertex j) h _ (word_bound s ⟨w,hw⟩)
    · rw [Bool.or_comm]
      exact p.edgeWords _ _ a (legal_vertex i) h _ (word_bound s ⟨w,hw⟩)
end Research.Graph9822.ThreeDirect.Sigma
#print axioms Research.Graph9822.ThreeDirect.Sigma.sharedTransfer
