import SixD3SemLightA023x06p009822
import SixD3SemLightA023x06p019822
import SixD3SemLightA023x06p029822
import SixD3SemLightA023x06p039822
import SixD3SemLightA023x06p049822
import SixD3SemLightA023x06p059822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem sem6 : Range (aOK d) (aCl d) g 864 1008 := rangeAppend light6p0 (rangeAppend light6p1 (rangeAppend light6p2 (rangeAppend light6p3 (rangeAppend light6p4 (light6p5)))))
end Research.Graph9822.ThreeDirect.A023
