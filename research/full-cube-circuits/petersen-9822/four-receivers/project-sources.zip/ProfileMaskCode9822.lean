import And9822ScanGrammar
namespace Research.Graph9822MaskCode
open Research.Graph9822Profiles

def direction (w : Nat) : Word := fun i => w.testBit i.val

noncomputable def encode (reps : BitVec 64) (s : Mask) : BitVec 64 := by
  classical
  let bs := (List.range 64).map fun w => reps.getLsbD w && decide (direction w ∈ s)
  exact (BitVec.ofBoolListLE bs).cast (by simp [bs])

theorem encode_bit (reps : BitVec 64) (s : Mask) (w : Nat) (hw : w < 64) :
    (encode reps s).getLsbD w = (reps.getLsbD w && @decide (direction w ∈ s) (Classical.propDecidable _)) := by
  classical
  unfold encode
  rw [BitVec.getLsbD_cast, BitVec.getLsbD_ofBoolListLE, List.getD_eq_getElem?_getD]
  simp [hw]

theorem encode_union (reps : BitVec 64) (s t : Mask) :
    encode reps (s ∪ t) = encode reps s ||| encode reps t := by
  classical
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  rw [BitVec.getLsbD_or, encode_bit _ _ _ hi, encode_bit _ _ _ hi, encode_bit _ _ _ hi]
  simp [Bool.and_or_distrib_left]

end Research.Graph9822MaskCode
