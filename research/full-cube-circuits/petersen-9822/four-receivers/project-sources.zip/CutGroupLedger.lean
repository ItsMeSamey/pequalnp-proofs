import PhysicalScanBundle9822
import SixStdCoverage
import Resolution

-- OuterLiveScan9822.lean line 3

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles

/-- The inverter cut can strand some originally live gates. Skip their inboxes
    without spending a switch, joining an empty list, or propagating any demand. -/
def activeEvents : List Event → ReverseState → List Event
  | [], _ => []
  | e :: tail, s =>
    if (s.q e.address).isEmpty then activeEvents tail s
    else e :: activeEvents tail (next s e)

theorem activeEvents_live (ev : List Event) (s : ReverseState) :
    allLive (activeEvents ev s) s := by
  classical
  induction ev generalizing s with
  | nil => trivial
  | cons e es ih =>
    by_cases h : s.q e.address = []
    · simpa [activeEvents,h] using ih s
    · exact (show allLive (activeEvents (e::es) s) s from by
        simpa [activeEvents,h,allLive] using And.intro h (ih (next s e)))

theorem extracted_good (events : List Event) (out : Nat) :
    Good ((activeEvents events (initial out)).foldl next (initial out)) :=
  good_fold _ _ (initial_good out) (activeEvents_live _ _)

theorem extracted_profile (events : List Event) (out : Nat) :
    let s := (activeEvents events (initial out)).foldl next (initial out)
    Profile s.branches s.switches :=
  graph_profile out _ (activeEvents_live _ _)

def inboxLengths : List Event → ReverseState → List Nat
  | [], _ => []
  | e::es,s => (s.q e.address).length :: inboxLengths es (next s e)

theorem inbox_positive (events : List Event) (s : ReverseState) (h : allLive events s) :
    ∀ k ∈ inboxLengths events s, 0 < k := by
  induction events generalizing s with
  | nil => simp [inboxLengths]
  | cons e es ih =>
    intro k hk
    rcases List.mem_cons.mp hk with rfl | tail
    · exact List.length_pos_iff.mpr h.1
    · exact ih _ h.2 k tail

theorem inbox_length (events : List Event) (s : ReverseState) :
    (inboxLengths events s).length = events.length := by
  induction events generalizing s with
  | nil => rfl
  | cons e es ih => simp [inboxLengths,ih]

theorem cost_inboxes (events : List Event) (s : ReverseState) :
    (events.foldl next s).cost = s.cost + ((inboxLengths events s).map (fun n => n-1)).sum := by
  induction events generalizing s with
  | nil => simp [inboxLengths]
  | cons e es ih =>
    rw [List.foldl_cons,ih]
    cases e <;> simp [inboxLengths,next,Nat.add_assoc]

theorem six_joins (events : List Event) (out gates : Nat) (small : gates ≤ 16)
    (eleven : (activeEvents events (initial out)).length = 11+gates)
    (pins : (inboxLengths (activeEvents events (initial out)) (initial out)).sum = 2*gates+1) :
    ((activeEvents events (initial out)).foldl next (initial out)).cost ≤ 6 := by
  let live := activeEvents events (initial out)
  let ns := inboxLengths live (initial out)
  have l : ns.length = 11+gates := (inbox_length _ _).trans eleven
  have h := Research.Graph9822Resolution.cost_of_live_wires ns
    (inbox_positive live _ (activeEvents_live events _))
  have budget : (ns.map (fun n => n-1)).sum ≤ 6 := by change ns.sum = _ at pins; omega
  simpa [cost_inboxes,initial,ns,live] using budget

end Research.Graph9822Profiles.OuterLive
-- OuterScheduledCost9822.lean line 2
namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles
def pending : Nat → Inbox → Nat
  | 0, _ => 0
  | n+1, q => pending n q + (q n).length

private theorem pending_congr {n : Nat} {q r : Inbox} (eq : ∀ j < n, q j = r j) :
    pending n q = pending n r := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [pending, ih (fun j hj => eq j (by omega)), eq n (by omega)]

theorem pending_deliver (n k : Nat) (q : Inbox) (m : Mask) (hk : k < n) :
    pending n (deliver q k m) = pending n q + 1 := by
  induction n with
  | zero => omega
  | succ n ih =>
    by_cases h : k = n
    · subst k
      have low : pending n (deliver q n m) = pending n q :=
        pending_congr (fun j hj => by simp [deliver, Nat.ne_of_lt hj])
      simp [pending,low,deliver,Nat.add_assoc]
    · have low := ih (by omega)
      simp [pending,low,deliver,Ne.symm h] <;> omega

def gateWeight : Event → Nat
  | .raw _ => 0
  | _ => 1

def Earlier (e : Event) (j : Nat) : Prop :=
  match e with
  | .orGate _ a b | .andGate _ a b _ => a < j ∧ b < j
  | .raw _ => True

inductive Schedule : Nat → List Event → Prop
  | done : Schedule 0 []
  | step {j es} (e : Event) (address : e.address = j)
      (inputs : Earlier e j) (tail : Schedule j es) : Schedule (j+1) (e::es)

private theorem pending_next (s : ReverseState) (e : Event) (j : Nat)
    (h : Earlier e j) : pending j (next s e).q = pending j s.q + 2 * gateWeight e := by
  cases e with
  | raw k => simp [next,gateWeight]
  | orGate k a b =>
    obtain ⟨ha,hb⟩ := h
    simp only [next,gateWeight,pending_deliver _ _ _ _ hb,pending_deliver _ _ _ _ ha] <;> omega
  | andGate k a b d =>
    obtain ⟨ha,hb⟩ := h
    simp only [next,gateWeight,pending_deliver _ _ _ _ hb,pending_deliver _ _ _ _ ha] <;> omega

theorem scheduled_pins {n : Nat} {events : List Event} (sc : Schedule n events)
    (s : ReverseState) :
    (inboxLengths (activeEvents events s) s).sum =
      pending n s.q + 2*((activeEvents events s).map gateWeight).sum := by
  induction sc generalizing s with
  | done => simp [activeEvents,inboxLengths,pending]
  | @step j es e address inputs tail ih =>
    cases qeq : s.q e.address with
    | nil =>
      have hz : s.q j = [] := address ▸ qeq
      simpa [activeEvents,qeq,pending,hz] using ih s
    | cons m ms =>
      have prior := ih (next s e)
      have inc := pending_next s e j inputs
      have hz : s.q j = m :: ms := address ▸ qeq
      simp only [activeEvents,qeq,List.isEmpty_cons,Bool.false_eq_true,if_false,
        inboxLengths,List.sum_cons,List.map_cons,pending,hz]
      omega

theorem initial_pending (n out : Nat) (h : out < n) :
    pending n (initial out).q = 1 := by
  have zero (m : Nat) : pending m (fun _ => []) = 0 := by
    induction m with
    | zero => rfl
    | succ m ih => simp [pending,ih]
  simpa [initial,zero] using pending_deliver n out (fun _ => []) Set.univ h

theorem scheduled_cost {n : Nat} {events : List Event} (sc : Schedule n events)
    (out : Nat) (inrange : out < n) (raws : Nat)
    (all_raws : (activeEvents events (initial out)).length =
      raws + ((activeEvents events (initial out)).map gateWeight).sum) :
    ((activeEvents events (initial out)).foldl next (initial out)).cost + raws =
      ((activeEvents events (initial out)).map gateWeight).sum + 1 := by
  let live := activeEvents events (initial out)
  let ns := inboxLengths live (initial out)
  have pins := scheduled_pins sc (initial out)
  rw [initial_pending _ _ inrange] at pins
  have ll := inbox_length live (initial out)
  have fees := Research.Graph9822Resolution.cost_of_live_wires ns
    (inbox_positive live _ (activeEvents_live events _))
  have val := cost_inboxes live (initial out)
  change (live.foldl next (initial out)).cost = 0 + (ns.map (fun i => i-1)).sum at val
  change ns.sum = 1 + 2 * (live.map gateWeight).sum at pins
  change ns.length = live.length at ll
  change live.length = raws + (live.map gateWeight).sum at all_raws
  change (live.foldl next (initial out)).cost + raws = (live.map gateWeight).sum + 1
  omega
end Research.Graph9822Profiles.OuterLive
-- OuterInboxEssential9822.lean line 3

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles

abbrev DGate := Research.Graph9822Resolution.Gate
abbrev DWire := Research.Graph9822Resolution.Wire

def gateEvent (g : DGate) (j : Nat) (axis : Nat → Axis) : Event :=
  if g.isAnd then .andGate j g.left g.right (axis j) else .orGate j g.left g.right

def advance (s : ReverseState) (e : Event) : ReverseState :=
  if (s.q e.address).isEmpty then s else next s e

def back (axis : Nat → Axis) : List DGate → Nat → ReverseState → ReverseState
  | [], _, s => s
  | g::gs, j, s => advance (back axis gs (j+1) s) (gateEvent g j axis)

def inboxAgree (s : ReverseState) (u v : DWire) :=
  ∀ j, s.q j ≠ [] → u j = v j

private theorem survives_deliver (q : Inbox) (k j : Nat) (mask : Mask) (h : q j ≠ []) :
    deliver q k mask j ≠ [] := by by_cases e : j=k <;> simp [deliver,e,h]

private theorem deliver_at (q : Inbox) (k : Nat) (mask : Mask) :
    deliver q k mask k ≠ [] := by simp [deliver]

theorem gate_agrees (s : ReverseState) (g : DGate) (j : Nat) (axis : Nat → Axis)
    (u v : DWire) (agree : inboxAgree (advance s (gateEvent g j axis)) u v) :
    inboxAgree s
      (Function.update u j (Research.Graph9822Resolution.step g (u g.left) (u g.right)))
      (Function.update v j (Research.Graph9822Resolution.step g (v g.left) (v g.right))) := by
  intro k hk
  by_cases active : s.q j = []
  · have same : advance s (gateEvent g j axis) = s := by
      cases flag : g.isAnd <;> simp [gateEvent,flag,advance,Event.address,active]
    have different : k ≠ j := fun e => hk (e.symm ▸ active)
    rw [Function.update_of_ne different, Function.update_of_ne different]
    exact agree k (by simpa only [same] using hk)
  · have state : advance s (gateEvent g j axis) = next s (gateEvent g j axis) := by
      cases flag : g.isAnd <;> simp [gateEvent,flag,advance,Event.address,active]
    rw [state] at agree
    have old : ∀ l, s.q l ≠ [] → (next s (gateEvent g j axis)).q l ≠ [] := by
      intro l hl
      cases h : g.isAnd <;> simp only [gateEvent,h,Bool.false_eq_true,if_false,if_true,next] <;>
        exact survives_deliver _ _ _ _ (survives_deliver _ _ _ _ hl)
    have lmem : (next s (gateEvent g j axis)).q g.left ≠ [] := by
      cases h : g.isAnd <;> simp only [gateEvent,h,Bool.false_eq_true,if_false,if_true,next] <;>
        exact survives_deliver _ _ _ _ (deliver_at _ _ _)
    have rmem : (next s (gateEvent g j axis)).q g.right ≠ [] := by
      cases h : g.isAnd <;> simp only [gateEvent,h,Bool.false_eq_true,if_false,if_true,next] <;>
        exact deliver_at _ _ _
    by_cases hit : k = j
    · subst k
      simp [agree g.left lmem,agree g.right rmem]
    · rw [Function.update_of_ne hit,Function.update_of_ne hit]
      exact agree k (old k hk)

theorem back_agrees (axis : Nat → Axis) (gs : List DGate) (j : Nat)
    (s : ReverseState) (u v : DWire) (h : inboxAgree (back axis gs j s) u v) :
    inboxAgree s (Research.Graph9822Resolution.eval gs j u) (Research.Graph9822Resolution.eval gs j v) := by
  induction gs generalizing j u v with
  | nil => exact h
  | cons g gs ih =>
    exact ih (j+1) _ _ (gate_agrees _ g j axis _ _ h)

theorem back_essential (axis : Nat → Axis) (gs : List DGate) (j out k : Nat)
    (u v : DWire) (off : ∀ i, i ≠ k → u i = v i)
    (ne : Research.Graph9822Resolution.eval gs j u out ≠ Research.Graph9822Resolution.eval gs j v out) :
    (back axis gs j (initial out)).q k ≠ [] := by
  intro empty
  apply ne
  apply back_agrees axis gs j (initial out) u v _ out (by simp [initial,deliver])
  intro i hi
  exact off i (fun e => hi (e.symm ▸ empty))

end Research.Graph9822Profiles.OuterLive
-- OuterEvents9822.lean line 3

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles

def gateEvents (axis : Nat → Axis) : List DGate → Nat → List Event
  | [], _ => []
  | g::gs, j => gateEvents axis gs (j+1) ++ [gateEvent g j axis]

def rawEvents : Nat → List Event
  | 0 => []
  | n+1 => Event.raw n :: rawEvents n

theorem fold_active (es : List Event) (s : ReverseState) :
    (activeEvents es s).foldl next s = es.foldl advance s := by
  induction es generalizing s with
  | nil => rfl
  | cons e es ih =>
    cases h : (s.q e.address).isEmpty <;> simp [activeEvents,advance,h,ih]

theorem active_append (a b : List Event) (s : ReverseState) :
    activeEvents (a++b) s = activeEvents a s ++ activeEvents b (a.foldl advance s) := by
  induction a generalizing s with
  | nil => rfl
  | cons e es ih =>
    cases h : (s.q e.address).isEmpty <;> simp [activeEvents,advance,h,ih]

theorem gates_fold (gs : List DGate) (j : Nat) (axis : Nat → Axis) (s : ReverseState) :
    (gateEvents axis gs j).foldl advance s = back axis gs j s := by
  induction gs generalizing j with
  | nil => rfl
  | cons g gs ih => simp [gateEvents,back,List.foldl_append,ih]

theorem raw_all (n : Nat) (s : ReverseState) (ready : ∀ j < n, s.q j ≠ []) :
    activeEvents (rawEvents n) s = rawEvents n := by
  induction n generalizing s with
  | zero => rfl
  | succ n ih =>
    have hn := ready n (by omega)
    have recurResult := ih (next s (.raw n)) (fun j hj => by simpa [next] using ready j (by omega))
    simp [rawEvents,activeEvents,Event.address,hn,recurResult]

theorem raw_statistics (n : Nat) :
    (rawEvents n).length = n ∧ ((rawEvents n).map gateWeight).sum = 0 := by
  induction n with
  | zero => decide
  | succ n ih => simp [rawEvents,gateWeight,ih.1,ih.2]

theorem active_length_le (es : List Event) (s : ReverseState) :
    (activeEvents es s).length ≤ es.length := by
  induction es generalizing s with
  | nil => simp [activeEvents]
  | cons e es ih =>
    have a := ih s
    have b := ih (next s e)
    cases h : (s.q e.address).isEmpty <;> simp [activeEvents,h] <;> omega

theorem gate_lengths (gs : List DGate) (j : Nat) (axis : Nat → Axis) :
    (gateEvents axis gs j).length = gs.length ∧
      ∀ e ∈ gateEvents axis gs j, gateWeight e = 1 := by
  induction gs generalizing j with
  | nil => simp [gateEvents]
  | cons g gs ih =>
    obtain ⟨len,all⟩ := ih (j+1)
    constructor
    · simp [gateEvents,len]
    · intro e he
      rcases List.mem_append.mp he with h | h
      · exact all e h
      · have eq : e = gateEvent g j axis := by simpa using h
        subst e
        cases flag : g.isAnd <;> simp [gateEvent,flag,gateWeight]

theorem all_active_gates (es : List Event) (s : ReverseState)
    (gate : ∀ e ∈ es, gateWeight e = 1) :
    ((activeEvents es s).map gateWeight).sum = (activeEvents es s).length := by
  induction es generalizing s with
  | nil => simp [activeEvents]
  | cons e es ih =>
    have ht := fun x (h : x ∈ es) => gate x (List.mem_cons_of_mem e h)
    cases h : (s.q e.address).isEmpty <;>
      simp [activeEvents,h,ih _ ht,gate e List.mem_cons_self,Nat.add_comm]

def WellWired : List DGate → Nat → Prop
  | [], _ => True
  | g::gs,j => g.left < j ∧ g.right < j ∧ WellWired gs (j+1)

theorem prepend_schedule (axis : Nat → Axis) (gs : List DGate) (j : Nat)
    (ok : WellWired gs j) (basis : List Event) (tail : Schedule j basis) :
    Schedule (j+gs.length) (gateEvents axis gs j ++ basis) := by
  induction gs generalizing j basis with
  | nil => simpa [gateEvents] using tail
  | cons g gs ih =>
    have addr : (gateEvent g j axis).address=j := by cases h : g.isAnd <;> simp [gateEvent,h,Event.address]
    have inp : Earlier (gateEvent g j axis) j := by
      cases h : g.isAnd <;> simpa [gateEvent,h,Earlier] using And.intro ok.1 ok.2.1
    have p := ih (j+1) ok.2.2 (gateEvent g j axis :: basis) (Schedule.step _ addr inp tail)
    simpa [gateEvents,List.append_assoc,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using p

theorem raw_schedule (n : Nat) : Schedule n (rawEvents n) := by
  induction n with
  | zero => exact .done
  | succ n ih => exact .step (.raw n) rfl trivial ih

theorem outer_six_actual (axis : Nat → Axis) (gs : List DGate) (out : Nat)
    (size : gs.length ≤ 16) (ok : WellWired gs 11) (outBound : out < 11+gs.length)
    (essential : ∀ k < 11, ∃ u v : DWire, (∀ j, j ≠ k → u j = v j) ∧
      Research.Graph9822Resolution.eval gs 11 u out ≠ Research.Graph9822Resolution.eval gs 11 v out) :
    let es := gateEvents axis gs 11 ++ rawEvents 11
    let live := activeEvents es (initial out)
    Profile (live.foldl next (initial out)).branches (live.foldl next (initial out)).switches ∧
    (live.foldl next (initial out)).cost ≤ 6 := by
  let gates := gateEvents axis gs 11
  let acts := activeEvents gates (initial out)
  have qlive : ∀ k < 11, (back axis gs 11 (initial out)).q k ≠ [] := by
    intro k hk
    obtain ⟨u,v,off,hit⟩ := essential k hk
    exact back_essential axis gs 11 out k u v off hit
  have act : activeEvents (gates++rawEvents 11) (initial out) = acts++rawEvents 11 := by
    rw [active_append]
    dsimp only [gates]
    rw [gates_fold,raw_all _ _ qlive]
  have cnt : (acts.map gateWeight).sum = acts.length := all_active_gates _ _ (gate_lengths gs 11 axis).2
  have lim : acts.length ≤ gs.length := (active_length_le _ _).trans_eq (gate_lengths gs 11 axis).1
  have rc := raw_statistics 11
  have total : (activeEvents (gates++rawEvents 11) (initial out)).length =
      11 + ((activeEvents (gates++rawEvents 11) (initial out)).map gateWeight).sum := by
    simp [act,rc.1,rc.2,cnt,Nat.add_comm]
  have exactCost := scheduled_cost (prepend_schedule axis gs 11 ok _ (raw_schedule 11)) out outBound 11 total
  have low : ((activeEvents (gates++rawEvents 11) (initial out)).map gateWeight).sum ≤ 16 := by
    simpa [act,rc.2,cnt] using lim.trans size
  exact ⟨extracted_profile _ _,by change _ ≤ 6; dsimp only [gates] at low; omega⟩

end Research.Graph9822Profiles.OuterLive
