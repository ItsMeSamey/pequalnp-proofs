import And9822PhysicalRooms

namespace Research.Graph9822.NumericBank
open Graph9822Profiles Graph9822MaskCode ArbitraryScan
noncomputable section
open Classical

def widthTest (reps : BitVec 64) (v : Fin 10) (k : Nat) (a : Bool) : Prop :=
  (requests [(v,a)]).card ≤ (rooms reps (fun _ => k) [(v,a)]).card

def initialBox (P : Axis6 → Mask6) (d : Nat) (v : Fin 10) : List Nat := by
  classical
  exact (((rawLibrary P d).sort).filter fun k =>
    decide (widthTest (firstReps P) v k true ∧ widthTest (firstReps P) v k false)).map
    (indexOfKey P d)

theorem initial_mem {P : Axis6 → Mask6} {d : Nat} {R : Fin 10 → Mask6}
    (e : RoomEmbedding P R) (lib : ∀ v, key P (R v) ∈ rawLibrary P d) (v : Fin 10) :
    indexOfKey P d (key P (R v)) ∈ initialBox P d v := by
  classical
  have h (a : Bool) : widthTest (firstReps P) v (key P (R v)) a := by
    simpa [widthTest,rooms] using room_capacity e [(v,a)]
  apply List.mem_map.mpr
  exact ⟨_,List.mem_filter.mpr ⟨by simpa using lib v,decide_eq_true ⟨h true,h false⟩⟩,rfl⟩

end
end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.initial_mem
