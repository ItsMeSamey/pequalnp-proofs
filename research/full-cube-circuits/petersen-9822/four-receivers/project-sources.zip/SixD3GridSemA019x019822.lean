import SixD3GridDataA0199822
namespace Research.Graph9822.ThreeDirect.A019
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part144 : Range (aOK d) (aCl d) g 144 168 :=
  rangeCheck _ _ _ 144 24 (by decide +kernel)
private theorem part168 : Range (aOK d) (aCl d) g 168 183 :=
  rangeCheck _ _ _ 168 15 (by decide +kernel)
theorem sem1 : Range (aOK d) (aCl d) g 144 183 := rangeAppend part144 (part168)
end Research.Graph9822.ThreeDirect.A019
