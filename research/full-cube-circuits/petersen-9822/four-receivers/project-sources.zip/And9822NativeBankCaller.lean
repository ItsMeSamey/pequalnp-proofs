import And9822BankLibrary

namespace Research.Graph9822.NumericBank
open ArbitraryScan Graph9822Profiles Graph9822.StarData Banks
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p

/-- Native library numbers are positions in ascending order of the surviving mask keys. -/
noncomputable def indexOfKey (P : Axis6 → Mask6) (d : Nat) (v : Nat) : Nat :=
  ((rawLibrary P d).sort).idxOf v

theorem from_actual_profile {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (respects : ∀ s ∈ p, s.2 = P s.1) (R : Fin 10 → Mask6) (returned : ∀ v, R v ∈ l)
    (proper : ∀ v, ∃ q, q ∉ R v) (inc : ∀ u v, u ≠ v → ¬ R u ⊆ R v)
    (intersects : ∀ u v,u≠v → ∃ q,q∈R u ∧ q∈R v)
    (cover : ∀ u v,adj u v=true → ∀ q,q∈R u ∨ q∈R v) (budget : n≤8)
    (d : Nat) (direct : ((Finset.univ : Finset (Fin 10)).filter (fun v => RayValue P (R v))).card=d)
    (boxes : Fin 10 → List Nat) (inBox : ∀ v,indexOfKey P d (key P (R v)) ∈ boxes v) :
    ∃ bank ∈ enumerate (indexOfKey P d) (rawLibrary P d) (rayKeys P) (namedKeys P p) d,
      (∀ v,indexOfKey P d (key P (R v)) ∈ bank.available) ∧
      (∀ m ∈ bank.required, ∃ v,indexOfKey P d (key P (R v))=m) ∧
      ∀ v,keep (enumerate (indexOfKey P d) (rawLibrary P d) (rayKeys P) (namedKeys P p) d)
        boxes (indexOfKey P d (key P (R v)))=true := by
  classical
  obtain ⟨pr,_⟩ := from_scan scan P respects R returned proper inc intersects cover budget
  have eq : ((List.finRange 10).filter pr.direct).toFinset =
      (Finset.univ : Finset (Fin 10)).filter (fun v => RayValue P (R v)) := by
    ext v
    simp only [List.mem_toFinset,List.mem_filter,List.mem_finRange,true_and,
      Finset.mem_filter,Finset.mem_univ]
    simpa only [true_and,RayValue] using pr.isDirect v
  have len : ((List.finRange 10).filter pr.direct).length=d := by
    rw [←List.toFinset_card_of_nodup ((List.nodup_finRange 10).filter _),eq,direct]
  have nonempty (v : Fin 10) : ∃ q,q ∈ R v := by
    let u : Fin 10 := if v=0 then 1 else 0
    have ne : v≠u := by
      by_cases h : v=0 <;> simp [u,h]
    obtain ⟨q,hit,_⟩ := intersects v u ne
    exact ⟨q,hit⟩
  exact representative_keep scan P respects R returned proper inc budget _ _ boxes
    (priced_library pr proper nonempty len) inBox d direct (len ▸ pr.directMax)
end
end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.from_actual_profile
