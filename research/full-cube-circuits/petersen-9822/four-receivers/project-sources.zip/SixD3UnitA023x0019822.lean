import SixD3GridUnits9822
import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit12 : ∀ a, Known a g 2570 → Known a g 2571 :=
  singleKnown g 2570 (unpack 28 [0x1030c00007ce08805a209100de043]) (by decide +kernel)
private theorem unit13 : ∀ a, Known a g 2571 → Known a g 2572 :=
  singleKnown g 2571 (unpack 28 [0x11089ec51085e6b10adec91081eb70fe1eaf1079e5d10b9ed910a9e6f0fd5dd51071ddd106deab0fd1ea31069e511099e6d1061dd10fb9dc91029dcd07b923f1021e9d1039ea70f81e8b0c6a0981011dc3104de670f69db1103ddd91049eb307e52e10fb1e9907a52070fa1dbf07911dd077d1bf077519d0fade3f0ea5d19101de430e85d1503120ad030a0ab030609703020a902fe09502fa08302f607302f20a702ee09302ea08102e607102e20a502de09102da07f02d606f02d206102ce05502ca0a102c608d02c207b02be06b02ba05d02b605102b204702ae09d024207701d6067016605900f204d007a04300160352505df72501d9524fdd7724f9e3124f5de924f1d8724edd692529e0524e9d2124e5d1d24e1d1b24ddd09252de4d24d9cff2531e112535e592539e77253de09250de492511e0d2515e552519e73251dd7b2521d992541e152525dfb0c706512545e7d2549e7f2509e010e71ccf0e41cbd0e45ccb0f55d55258c331258432525701f125681e525640bd25580b125540a5075c2900754284073c1500730144060c01c060001005fc0040750e94072cc3805f8784,0x10e3c0000eb9d2d1179e631129d351121d33111dd1f1111d0b110dcfb1109d2f10fdcf910f9d0710f5cf710f1ce910edcdd10e9d2910e1d0310ddcf310d9ce510d5cd910d1d2510cdd1110c5cef10c1ce110bdcd5077033c11f9e7b076d1122811d3128292871091ed51059ed10ff9ecd10a5ed71051ec10fedebd109dec7]) (by decide +kernel)
private theorem unit14 : ∀ a, Known a g 2572 → Known a g 2573 :=
  singleKnown g 2572 (unpack 28 [0x11724000076d2e014c920714311dd127119d161d287110d113]) (by decide +kernel)
private theorem unit15 : ∀ a, Known a g 2573 → Known a g 2574 :=
  singleKnown g 2573 (unpack 28 [0x110b00000e3dec80f01d0b0e71ccf0e41cbd0e45ccb0f55d55258432525681e525540a50754284073014405fc0040750e94072cc3805f8784]) (by decide +kernel)
private theorem unit16 : ∀ a, Known a g 2574 → Known a g 2575 :=
  singleKnown g 2574 (unpack 28 [0x106100000728c110718c010708bf306e0be706c8bdd0698bcb0658a690618a0f0664a9506149fd258c33125701f125580b1075c290073c15006000100750e94072cc3805f8784]) (by decide +kernel)
private theorem unit17 : ∀ a, Known a g 2575 → Known a g 2576 :=
  singleKnown g 2575 (unpack 28 [0x107b8000019607f0162077006e043]) (by decide +kernel)
private theorem unit18 : ∀ a, Known a g 2576 → Known a g 2577 :=
  singleKnown g 2576 (unpack 28 [0x11bcc0000c7dad41bc9ac11bc1a851be9beb1bedc451bf1b791bf5bf91bf9c531bfdb851c01c051bd9be71bddc411be1b231c05c5f1c09c131be5b411c0dc6d0d11b670d55b6b0ca9a9f1bc5a911bd1b1f1bd5b3d081c5050c85a770c81a730cf5afd258432525681e525540a50754284073014405fc0040750e94072cc3805f8784]) (by decide +kernel)
private theorem unit19 : ∀ a, Known a g 2577 → Known a g 2578 :=
  singleKnown g 2577 (unpack 28 [0x1109800001c209701aa09301a2071]) (by decide +kernel)
private theorem unit20 : ∀ a, Known a g 2578 → Known a g 2579 :=
  singleKnown g 2578 (unpack 28 [0x1076c00007e52e107b923f035209d0286077]) (by decide +kernel)
private theorem unit21 : ∀ a, Known a g 2579 → Known a g 2580 :=
  singleKnown g 2579 (unpack 28 [0x1076c00007e52e107b923f034a09d027e077109a070284a0931201113]) (by decide +kernel)
private theorem unit22 : ∀ a, Known a g 2580 → Known a g 2581 :=
  singleKnown g 2580 (unpack 28 [0x1109800005b209305aa071284e0a4]) (by decide +kernel)
private theorem unit23 : ∀ a, Known a g 2581 → Known a g 2582 :=
  singleKnown g 2581 (unpack 28 [0x1076c00007e52e107b923f05ca0a5036a09d029e077285209607911dd284605912011132819e6c]) (by decide +kernel)
theorem up1 : ∀ a, Known a g 2570 → Known a g 2582 := by
  intro a h
  apply unit23 a
  apply unit22 a
  apply unit21 a
  apply unit20 a
  apply unit19 a
  apply unit18 a
  apply unit17 a
  apply unit16 a
  apply unit15 a
  apply unit14 a
  apply unit13 a
  apply unit12 a
  exact h
end Research.Graph9822.ThreeDirect.A023
