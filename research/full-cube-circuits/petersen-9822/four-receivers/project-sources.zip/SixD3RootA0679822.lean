import SixD3GridSemA067x009822
import SixD3GridSemA067x019822
import SixD3UnitA067x0009822
import SixD3UnitA067x0019822
import SixD3UnitA067x0029822
namespace Research.Graph9822.ThreeDirect.A067
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 179 (rangeAppend sem0 (sem1))
  intro a old
  apply endKnown g 207 (by decide +kernel) a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A067
