import SixD3SigmaShared9822
namespace Research.Graph9822.ThreeDirect.Sigma
open Research.Graph9822.TwoDirect.Symmetry (vertex)
private theorem legal236_017at0 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 0),arm 1 t ∈ options (0,1,7) mix 0 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal236_017at1 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 1),arm 1 t ∈ options (0,1,7) mix 1 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal236_017at2 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 2),arm 1 t ∈ options (0,1,7) mix 2 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal236_017at3 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 3),arm 1 t ∈ options (0,1,7) mix 3 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal236_017at4 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 4),arm 1 t ∈ options (0,1,7) mix 4 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal236_017at5 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 5),arm 1 t ∈ options (0,1,7) mix 5 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal236_017at6 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 6),arm 1 t ∈ options (0,1,7) mix 6 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal236_017at7 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 7),arm 1 t ∈ options (0,1,7) mix 7 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal236_017at8 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 8),arm 1 t ∈ options (0,1,7) mix 8 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal236_017at9 : ∀ mix : Bool,∀ t∈options (2,3,6) mix (vertex 9),arm 1 t ∈ options (0,1,7) mix 9 := by
  intro mix; cases mix <;> decide +kernel
def spec236_017 : Spec 1 (2,3,6) (0,1,7) where
  origBound := by decide +kernel
  legal := by
    intro v
    have e := (show ∀ k : Fin 10, k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 ∨ k=8 ∨ k=9 by decide +kernel) v
    rcases e with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact legal236_017at0
    · exact legal236_017at1
    · exact legal236_017at2
    · exact legal236_017at3
    · exact legal236_017at4
    · exact legal236_017at5
    · exact legal236_017at6
    · exact legal236_017at7
    · exact legal236_017at8
    · exact legal236_017at9
  named := by decide +kernel
  root := by decide +kernel
  outside := by decide +kernel
  bounded := by decide +kernel
def rooms236_017 {mix : Bool} : Rooms (2,3,6) mix → Rooms (0,1,7) mix := roomsTransfer spec236_017
def shared236_017 : Shared (2,3,6) → Shared (0,1,7) := sharedTransfer spec236_017
end Research.Graph9822.ThreeDirect.Sigma
#print axioms Research.Graph9822.ThreeDirect.Sigma.shared236_017
