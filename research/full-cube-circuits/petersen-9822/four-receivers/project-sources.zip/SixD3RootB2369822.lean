import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B236
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (2,3,6)
private noncomputable def rules : List Nat := unpack 35 [0x200000004c010000c88000000800018000420000000c1802000b8800000010]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x80183c80050a2000c64a001d3b0011d200025050000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B236
