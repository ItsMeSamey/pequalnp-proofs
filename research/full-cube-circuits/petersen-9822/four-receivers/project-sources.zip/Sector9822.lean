import PEqualNP.Defs.MetaComplexity

namespace PEqualNP.Outside.L_meta_9822.Sectors
open PEqualNP.CircuitLowerBounds
open PEqualNP.MetaComplexity

def edge := fun x : Fin 10 → Bool => (x 1 && x 2) || (x 3 && x 4) || (x 0 && x 4) || (x 0 && x 5) || (x 1 && x 6) || (x 2 && x 7) || (x 3 && x 8) || (x 4 && x 9) || (x 5 && x 7) || (x 7 && x 9) || (x 6 && x 9) || (x 6 && x 8) || (x 5 && x 8)

def countsNot (g : Gate) : Bool :=
  match g.op with
  | .not => true
  | _ => false

def Candidate (C : Circuit) : Prop :=
  FanInTwo C ∧ C.size ≤ 17 ∧ ∀ x, C.eval (List.ofFn x) = edge x

theorem ofExclusions
    (monotone : ∀ C, Candidate C → C.gates.countP countsNot = 0 → False)
    (one : ∀ C, Candidate C → C.gates.countP countsNot = 1 → False)
    (many : ∀ C, Candidate C → 2 ≤ C.gates.countP countsNot → False) :
    ¬ (PEqualNP.MetaComplexity.HasCircuitSize 10 (fun x : Fin 10 → Bool => (x 1 && x 2) || (x 3 && x 4) || (x 0 && x 4) || (x 0 && x 5) || (x 1 && x 6) || (x 2 && x 7) || (x 3 && x 8) || (x 4 && x 9) || (x 5 && x 7) || (x 7 && x 9) || (x 6 && x 9) || (x 6 && x 8) || (x 5 && x 8)) 17) := by
  rintro ⟨C, legal, size, computes⟩
  have hc : Candidate C := ⟨legal, size, computes⟩
  by_cases hz : C.gates.countP countsNot = 0
  · exact monotone C hc hz
  by_cases ho : C.gates.countP countsNot = 1
  · exact one C hc ho
  exact many C hc (by omega)

end PEqualNP.Outside.L_meta_9822.Sectors
#print axioms PEqualNP.Outside.L_meta_9822.Sectors.ofExclusions
