import SixD3Projection9822
namespace Research.SixD3.Order
def insert (x : Nat) : List Nat → List Nat
  | [] => [x]
  | y::ys => if x≤y then x::y::ys else y::insert x ys
def sort : List Nat → List Nat
  | [] => []
  | x::xs => insert x (sort xs)
theorem insert_perm (x : Nat) (ys : List Nat) : (insert x ys).Perm (x::ys) := by
  induction ys with
  | nil => rfl
  | cons y ys ih =>
    unfold insert
    split
    · rfl
    · exact (List.Perm.cons y ih).trans (List.Perm.swap _ _ _)
theorem sort_perm (xs : List Nat) : (sort xs).Perm xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih => exact (insert_perm x _).trans (List.Perm.cons x ih)
@[simp] theorem sort_length (xs : List Nat) : (sort xs).length=xs.length := (sort_perm xs).length_eq
@[simp] theorem sort_single (x : Nat) : sort [x]=[x] := rfl
end Research.SixD3.Order
#print axioms Research.SixD3.Order.sort_perm
