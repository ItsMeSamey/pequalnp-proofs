import And9822ScanGrammar

namespace Research.Graph9822Profiles

def collect : List Mask → Mask
  | [] => ∅
  | x::xs => x ∪ collect xs

/-- Materialize the reverse fanout of a live wire. The expanded library
retains every earlier signal, including signals shared by other queues. -/
theorem settle (xs : List Mask) {b l p n} (h : Scan b l p n)
    (nonempty : xs ≠ []) (ready : ∀ x ∈ xs, x ∈ l) :
    ∃ l', Scan b l' p (n + (xs.length-1)) ∧ collect xs ∈ l' ∧ ∀ t ∈ l, t ∈ l' := by
  induction xs generalizing l n with
  | nil => exact False.elim (nonempty rfl)
  | cons x xs ih =>
    cases xs with
    | nil =>
      refine ⟨l, ?_, ?_, fun _ h => h⟩
      · simpa using h
      · simpa [collect] using ready x (by simp)
    | cons y ys =>
      obtain ⟨l',built,hy,preserved⟩ := ih h (by simp) (fun t ht => ready t (by simp [ht]))
      have hx := preserved _ (ready x (by simp))
      have joined := Scan.join built hx hy
      refine ⟨(x ∪ collect (y::ys))::l',?_,?_,?_⟩
      · simpa [List.length_cons,Nat.add_assoc] using joined
      · exact List.mem_cons_self
      · intro t ht
        exact List.mem_cons_of_mem _ (preserved t ht)

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.settle

namespace Research.Graph9822Profiles

abbrev Inbox := Nat → List Mask

def deliver (q : Inbox) (k : Nat) (v : Mask) : Inbox :=
  fun j => if j=k then v::q j else q j

def ready (l : List Mask) (q : Inbox) : Prop := ∀ j x, x ∈ q j → x ∈ l

theorem ready_deliver {l q k v} (r : ready l q) (h : v ∈ l) : ready l (deliver q k v) := by
  intro j x hx
  by_cases e : j=k
  · subst j
    have hh : x = v ∨ x ∈ q k := List.mem_cons.mp (by simpa [deliver] using hx)
    rcases hh with eq | hx
    · exact eq.symm ▸ h
    · exact r _ _ hx
  · exact r _ _ (by simpa [deliver,e] using hx)

theorem reverse_or {b l p n} (q : Inbox) (j a c : Nat) (h : Scan b l p n)
    (r : ready l q) (live : q j ≠ []) :
    let u := collect (q j)
    ∃ l', Scan b l' p (n + ((q j).length-1)) ∧
      ready l' (deliver (deliver q a u) c u) := by
  obtain ⟨l',built,hu,all⟩ := settle (q j) h live (r j)
  exact ⟨l',built,ready_deliver (ready_deliver (fun k x hx => all _ (r k x hx)) hu) hu⟩

theorem reverse_and {b l p n} (q : Inbox) (j a c : Nat) (i : Axis) (h : Scan b l p n)
    (r : ready l q) (live : q j ≠ []) :
    let u := collect (q j)
    let x := u ∩ side i true
    let y := u ∩ side i false
    ∃ l', Scan (x::y::b) l' ((i,u)::p) (n + ((q j).length-1)) ∧
      ready l' (deliver (deliver q a x) c y) := by
  obtain ⟨l',built,hu,all⟩ := settle (q j) h live (r j)
  let x := collect (q j) ∩ side i true
  let y := collect (q j) ∩ side i false
  have r' : ready (x::y::l') q := fun k z hz =>
    List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (all _ (r k z hz)))
  exact ⟨_,Scan.split built hu,ready_deliver (ready_deliver r' (by simp)) (by simp)⟩

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.reverse_and


namespace Research.Graph9822Profiles

inductive Event where
  | orGate (wire left right : Nat)
  | andGate (wire left right : Nat) (axis : Axis)
  | raw (wire : Nat)

structure ReverseState where
  q : Inbox
  branches : List Mask
  switches : List (Axis × Mask)
  receivers : List Mask
  cost : Nat

def initial (out : Nat) : ReverseState :=
  ⟨deliver (fun _ => []) out Set.univ,[],[],[],0⟩

def Event.address : Event → Nat
  | .orGate j _ _ | .andGate j _ _ _ | .raw j => j

def next (s : ReverseState) (ev : Event) : ReverseState :=
  let u := collect (s.q ev.address)
  let paid := s.cost + ((s.q ev.address).length-1)
  match ev with
  | .orGate _ a b =>
      {s with q := deliver (deliver s.q a u) b u, cost := paid}
  | .andGate _ a b i =>
      let x := u ∩ side i true
      let y := u ∩ side i false
      {s with q := deliver (deliver s.q a x) b y, cost := paid,
              branches := x::y::s.branches, switches := (i,u)::s.switches}
  | .raw _ => {s with cost := paid, receivers := u::s.receivers}

def Good (s : ReverseState) : Prop :=
  ∃ l, Scan s.branches l s.switches s.cost ∧ ready l s.q ∧
    ∀ m ∈ s.receivers, m ∈ l

theorem initial_good (out : Nat) : Good (initial out) := by
  refine ⟨[Set.univ],Scan.start,ready_deliver ?_ (by simp),?_⟩
  · intro j x hx
    simp at hx
  · simp [initial]

theorem good_next (s : ReverseState) (ev : Event) (g : Good s)
    (live : s.q ev.address ≠ []) : Good (next s ev) := by
  obtain ⟨l,h,r,receivers⟩ := g
  obtain ⟨l',built,hu,all⟩ := settle _ h live (r ev.address)
  have r' : ready l' s.q := fun j m hm => all _ (r j m hm)
  cases ev with
  | orGate j a b =>
    exact ⟨_,built,ready_deliver (ready_deliver r' hu) hu, fun x hx => all _ (receivers x hx)⟩
  | raw j =>
    refine ⟨_,built,r',?_⟩
    intro x hx
    rcases List.mem_cons.mp hx with rfl | hx
    · exact hu
    · exact all _ (receivers x hx)
  | andGate j a b i =>
    let x := collect (s.q j) ∩ side i true
    let y := collect (s.q j) ∩ side i false
    have rr : ready (x::y::l') s.q := fun k z hz =>
      List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (r' k z hz))
    refine ⟨_,Scan.split built hu,ready_deliver (ready_deliver rr (by simp)) (by simp),?_⟩
    intro z hz
    exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (all _ (receivers z hz)))

def allLive : List Event → ReverseState → Prop
  | [], _ => True
  | e::es, s => s.q e.address ≠ [] ∧ allLive es (next s e)

theorem good_fold (events : List Event) (s : ReverseState) (hs : Good s) (h : allLive events s) :
    Good (events.foldl next s) := by
  induction events generalizing s with
  | nil => exact hs
  | cons e es ih => exact ih (next s e) (good_next s e hs h.1) h.2

theorem graph_profile (out : Nat) (events : List Event) (h : allLive events (initial out)) :
    let res := events.foldl next (initial out)
    Profile res.branches res.switches := by
  obtain ⟨_,scan,_,_⟩ := good_fold events _ (initial_good out) h
  exact scan_profile scan

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.graph_profile

namespace Research.Graph9822Profiles

/-- A signed relabeling may exchange the two freshly inserted branches. The
transport theorem therefore retains library membership rather than list order. -/
theorem scan_equivariant (perm : Equiv.Perm Axis) (flips : Axis→Bool)
    {b l p n} (h : Scan b l p n) :
    let mv := liftMask (wordEquiv perm flips)
    ∃ b' l', Scan b' l' (p.map fun t => (perm t.1,mv t.2)) n ∧
      (∀ x∈b, mv x∈b') ∧ (∀ x∈l, mv x∈l') := by
  let mv := liftMask (wordEquiv perm flips)
  change ∃ b' l', Scan b' l' (p.map fun t => (perm t.1,mv t.2)) n ∧
    (∀ x∈b, mv x∈b') ∧ (∀ x∈l, mv x∈l')
  induction h with
  | start => exact ⟨[],[Set.univ],.start,by simp,by simp [mv,lift_full]⟩
  | join _ hx hy ih =>
    obtain ⟨b',l',scan,bok,lok⟩ := ih
    refine ⟨_,_,Scan.join scan (lok _ hx) (lok _ hy),bok,?_⟩
    intro z hz
    rcases List.mem_cons.mp hz with rfl | hz
    · exact List.mem_cons_self
    · exact List.mem_cons_of_mem _ (lok _ hz)
  | @split b l p n u i h hu ih =>
    obtain ⟨b',l',scan,bok,lok⟩ := ih
    have step := @Scan.split b' l' _ n (mv u) (perm i) scan (lok _ hu)
    have double (us xs : List Mask) (inc : ∀ x∈us, mv x∈xs) :
        ∀ x∈(u ∩ side i true)::(u ∩ side i false)::us,
        mv x ∈ (mv u ∩ side (perm i) true)::(mv u ∩ side (perm i) false)::xs := by
      intro x hx
      rcases List.mem_cons.mp hx with rfl | hx
      · cases hm : flips (perm i) <;> simp [mv,lift_split,hm]
      rcases List.mem_cons.mp hx with rfl | hx
      · cases hm : flips (perm i) <;> simp [mv,lift_split,hm]
      exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (inc _ hx))
    exact ⟨_,_,step,double _ _ bok,double _ _ lok⟩

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.scan_equivariant

namespace Research.Graph9822Profiles

/-- Newest-first rows are tagged with their true physical coordinate; reverse
the stored list before indexing a profile in the chronological archive. -/
inductive AxisOrder : List (Axis×Mask) → Prop
 | zero : AxisOrder []
 | add {p : List (Axis×Mask)} {j : Axis} {u : Mask}
      (h : AxisOrder p) (tag : j.val=p.length) : AxisOrder ((j,u)::p)

theorem tags_in_order {p : List (Axis×Mask)} (h : AxisOrder p) :
    p.reverse.map (fun e => e.1.val) = List.range p.length := by
  induction h with
  | zero => rfl
  | add _ tag ih => simp [List.reverse_cons,List.range_succ,ih,tag]

theorem tagged_get {p : List (Axis×Mask)} (h : AxisOrder p) (j : Nat) (hj : j<p.length) :
    (p.reverse[j]'(by simpa using hj)).1.val = j := by
  have ht := congrArg (fun xs : List Nat => xs[j]?) (tags_in_order h)
  simpa [List.getElem?_eq_getElem, hj] using ht

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.tags_in_order

namespace Research.Graph9822Profiles

/-- A disjunctive bit mover can be certified once by the full mask and the
twelve signed coordinate halves. Every contributor to an output word must
share all six bits with the target inverse word. -/
def scatter (rel : Word → Word → Prop) (m : Mask) : Mask :=
  {dst | ∃ src, rel src dst ∧ src ∈ m}

theorem basis_certifies (rel : Word → Word → Prop) (inv : Word → Word)
    (full : scatter rel Set.univ = Set.univ)
    (signed : ∀ i b, scatter rel (side i b) = inv ⁻¹' side i b) :
    ∀ m : Mask, scatter rel m = inv ⁻¹' m := by
  have unique (src dst : Word) (h : rel src dst) : src = inv dst := by
    funext i
    have seen : dst ∈ scatter rel (side i (src i)) := ⟨src,h,rfl⟩
    rw [signed] at seen
    exact seen.symm
  intro m
  ext dst
  constructor
  · rintro ⟨src,h,hx⟩
    change inv dst ∈ m
    rwa [←unique src dst h]
  · intro hx
    have seen : dst ∈ scatter rel Set.univ := by simp [full]
    obtain ⟨src,h,_⟩ := seen
    change inv dst ∈ m at hx
    exact ⟨src,h, by rwa [unique src dst h]⟩

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.basis_certifies
