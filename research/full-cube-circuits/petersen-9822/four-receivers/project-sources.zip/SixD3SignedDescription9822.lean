import SixD3Arms9822
import SixD3NamedSampling9822
import SixD3DirectOrigins9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral (Word Lit ray receives)
open Research.SixH4.PairPartition (V)
open Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (Arm edge)
open Research.Graph9822Profiles.Fresh (DistinctPair)
theorem norm_meaning (r : Roots) (P : Fin 6→Set Word) (ts : List Lit) (w : Word) :
    receives P ts w ↔ ∃ k∈normArm r ts,w∈mask r P k := by
  constructor
  · rintro ⟨t,ht,hit⟩
    exact ⟨code r t,(arm_mem r ts _).mpr ⟨t,ht,rfl⟩,by rwa [mask_at]⟩
  · rintro ⟨k,h,hit⟩
    obtain ⟨t,ht,rfl⟩ := (arm_mem r ts _).mp h
    exact ⟨t,ht,by rwa [mask_at] at hit⟩
theorem numeric_meaning (r : Roots) (P : Fin 6→Set Word) (L : V→List Lit)
    (R : V→Set Word) (desc : ∀ v w,w∈R v ↔ receives P (L v) w) :
    ∀ v : V,∀ w,w∈R v ↔ ∃ k∈normalized r L v.val,w∈mask r P k := by
  intro v w
  simpa [normalized,v.isLt] using (desc v w).trans (norm_meaning r P (L v) w)
theorem pair_of_len (r : Roots) (P : Fin 6→Set Word) (L : V→List Lit)
    (R : V→Set Word) (desc : ∀ v w,w∈R v ↔ receives P (L v) w)
    (shape : ∀ v,(∃ t,L v=[t]) ∨ Shape true (L v)) (v : V)
    (len : (normalized r L v.val).length=2) : DistinctPair P (R v) := by
  have size : (L v).length=2 := by simpa [normalized,normArm,v.isLt] using len
  rcases shape v with ⟨t,eq⟩|⟨a,b,diff,eq⟩|⟨_,a,b,c,_,_,_,eq⟩
  · simp [eq] at size
  · refine ⟨a.1,a.2,b.1,b.2,diff,?_⟩
    ext w
    simpa [eq,receives,ray,Research.SixH4.DirectLiteral.side,Research.Graph9822Profiles.side] using desc v w
  · simp [eq] at size
def RootRows (d : Dir) (r : Roots) (P : Fin 6→Set Word) (R : V→Set Word) :=
    ∀ j,j<3 → ∃ (i : Fin 6) (x : V) (s : Bool),axisCode r i=j ∧ x.val=(ds d)[j]?.getD 10 ∧
      R x=ray P i s ∧ s=phase r i
theorem root_rows (r : Roots) (P : Fin 6→Set Word) (R : V→Set Word) (x y z : V)
    (rx : R x=ray P r.a.1 r.a.2) (ry : R y=ray P r.b.1 r.b.2)
    (rz : R z=ray P r.c.1 r.c.2) : RootRows (labelDir x y z) r P R := by
  intro j hj
  interval_cases j
  · exact ⟨_,x,_,by simp [axisCode,rank],rfl,rx,by simp [phase]⟩
  · exact ⟨_,y,_,by simp [axisCode,rank,r.ab.symm],rfl,ry,by simp [phase,r.ab.symm]⟩
  · exact ⟨_,z,_,by simp [axisCode,rank,r.ac.symm,r.bc.symm],rfl,rz,by simp [phase,r.ac.symm,r.bc.symm]⟩
theorem root_constraints (r : Roots) (P : Fin 6→Set Word) (R : V→Set Word)
    (d : Dir) (raw : Nat→Arm) (o : Nat→Nat) (roots : RootRows d r P R)
    (meaning : ∀ v : V,∀ q,q∈R v ↔ ∃ k∈raw v.val,q∈mask r P k)
    (phys : ∀ j,j<6 → ∀ i,axisCode r i=j → (o j=22 → P i=Set.univ) ∧
       (j<3 → o j≠22 → ∃ t : Lit,P i=ray P t.1 t.2))
    (pair : ∀ v : V,(raw v.val).length=2 → DistinctPair P (R v))
    (edges : ∀ a b : V,edge a.val b.val=true ↔ ∀ w,w∈R a ∨ w∈R b)
    (anti : ∀ a b : V,a≠b → ¬R a⊆R b) :
    (∀ j,j<3 → o j=22 → ∀ v,v<10 → v∉ds d → edge v ((ds d)[j]?.getD 10)=false →
      2*j+1∉raw v) ∧
    (∀ j,j<3 → o j≠22 → ∀ v w,v<w → w<10 →
      edge ((ds d)[j]?.getD 10) v=true → edge ((ds d)[j]?.getD 10) w=true →
      (raw v).length=2 → (raw w).length≠2) := by
  constructor
  · intro j hj full v hv _ nonedge odd
    obtain ⟨i,x,s,idx,addr,rx,sgn⟩ := roots j hj
    have top := (phys j (by omega) i idx).1 full
    have e := (edges ⟨v,hv⟩ x).mpr (by
      intro w
      by_cases rside : w i=s
      · right; rw [rx]; exact ⟨top.symm ▸ Set.mem_univ w,rside⟩
      · left
        apply (meaning ⟨v,hv⟩ w).mpr
        refine ⟨2*j+1,odd,?_⟩
        rw [←idx,(slot_masks r P i).2]
        refine ⟨top.symm ▸ Set.mem_univ w,?_⟩
        change w i= !(phase r i)
        rw [←sgn]
        exact Bool.eq_not_of_ne rside)
    change edge v x.val=true at e
    rw [addr,nonedge] at e
    contradiction
  · intro j hj nonfull v w vw hw ev ew pairV pairW
    obtain ⟨i,x,s,idx,addr,rx,_⟩ := roots j hj
    obtain ⟨t,src⟩ := (phys j (by omega) i idx).2 hj nonfull
    let a : V := ⟨v,by omega⟩
    let b : V := ⟨w,hw⟩
    have ne : a≠b := fun eq=>Nat.ne_of_lt vw (congrArg Fin.val eq)
    exact Research.Graph9822.ArbitraryScan.ordinary_neighbors rx ne anti ⟨t.1,t.2,src⟩
      ((edges x a).mp (by simpa [a,addr] using ev)) ((edges x b).mp (by simpa [b,addr] using ew))
      (pair a pairV) (pair b pairW)
end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.root_constraints
