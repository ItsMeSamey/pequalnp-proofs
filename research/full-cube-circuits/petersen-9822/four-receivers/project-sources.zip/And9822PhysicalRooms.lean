import And9822FullProfileBanks
import FourSaturationData

namespace Research.Graph9822.NumericBank
open Graph9822Profiles Graph9822MaskCode ArbitraryScan
noncomputable section
open Classical

def mis (i : Fin 16) : Nat := FourSaturation.witnesses[i.val]'(by
  rw [FourSaturation.sixteen_distinct.1]; exact i.isLt)

def present (i : Fin 16) (v : Fin 10) : Bool := !(mis i).testBit v.val

private theorem separates : ∀ i j : Fin 16, i ≠ j → ∃ v : Fin 10, present i v ≠ present j v := by
  decide

structure RoomEmbedding (P : Axis6 → Mask6) (R : Fin 10 → Mask6) where
  row : Fin 16 ↪ Fin 64
  included : ∀ i, (firstReps P).getLsbD (row i).val = true
  hits : ∀ i v, (key P (R v)).testBit (row i).val = present i v

theorem physical_rooms {P : Axis6 → Mask6} {R : Fin 10 → Mask6}
    (stable : ∀ v, Stable P (R v))
    (realize : ∀ m ∈ FourSaturation.witnesses, ∃ x : Word6,
      ∀ v, x ∈ R v ↔ m.testBit v.val = false) : Nonempty (RoomEmbedding P R) := by
  classical
  have rows (i : Fin 16) : ∃ w : Fin 64, (firstReps P).getLsbD w.val = true ∧
      ∀ v, (key P (R v)).testBit w.val = present i v := by
    obtain ⟨x,hx⟩ := realize (mis i) (List.getElem_mem ..)
    obtain ⟨w,hw,bit,same⟩ := hasRep P x
    refine ⟨⟨w,hw⟩,bit,fun v => ?_⟩
    change (encode (firstReps P) (R v)).getLsbD w = _
    rw [encode_bit _ _ _ hw,bit,Bool.true_and]
    have eq := ((stable v) _ _ same).trans (hx v)
    simp [present,eq]
  choose f good corr using rows
  refine ⟨⟨⟨f,?_⟩,good,corr⟩⟩
  intro i j eq
  by_contra ne
  obtain ⟨v,hv⟩ := separates i j ne
  exact hv (by rw [←corr i v,←corr j v,eq])

def requests (pins : List (Fin 10 × Bool)) : Finset (Fin 16) :=
  Finset.univ.filter fun i => pins.all fun p => present i p.1 == p.2

def rooms (reps : BitVec 64) (K : Fin 10 → Nat) (pins : List (Fin 10 × Bool)) :
    Finset (Fin 64) :=
  Finset.univ.filter fun w => reps.getLsbD w.val &&
    pins.all fun p => (K p.1).testBit w.val == p.2

theorem room_capacity {P : Axis6 → Mask6} {R : Fin 10 → Mask6}
    (e : RoomEmbedding P R) (pins : List (Fin 10 × Bool)) :
    (requests pins).card ≤ (rooms (firstReps P) (fun v => key P (R v)) pins).card := by
  apply Finset.card_le_card_of_injOn e.row
  · intro i hi
    simpa [requests,rooms,e.included,e.hits] using hi
  · exact e.row.injective.injOn

end
end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.physical_rooms
#print axioms Research.Graph9822.NumericBank.room_capacity
