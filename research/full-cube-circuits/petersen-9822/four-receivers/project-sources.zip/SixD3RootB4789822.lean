import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B478
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (4,7,8)
private noncomputable def rules : List Nat := unpack 35 [0x401202080800000090402808322000000140806020b8800000030]
private def keys : List Nat := (List.range 6).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x20050f4800c152001e5e00126dc00275d0000000006] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B478
