import SixD3Order9822
import SixH4ProjectionSymmetryData9822
namespace Research.Graph9822.ThreeDirect.Sigma
open Research.Graph9822.TwoDirect (Arm rooms edge rawBit opposes)
open Research.Graph9822.TwoDirect.Symmetry (vertex moveRoom row_maps legal_vertex)
abbrev Swap := Fin 3
def axis (s : Swap) (j : Nat) := if j=0 then s.val else if j=s.val then 0 else j
def lbl (s : Swap) (k : Nat) := if k<6 then 2*axis s (k/2)+k%2 else k
def arm (s : Swap) (a : Arm) : Arm := Research.SixD3.Order.sort (a.map (lbl s))
def origin (s : Swap) (o : Nat) :=
  if o<12 then lbl s o else if o<22 then 12+vertex (o-12) else o
def word (s : Swap) (w : Nat) := (List.range 6).foldl
  (fun n i=>if w.testBit i then n ||| (2^axis s i) else n) 0
def obsMap (s : Swap) (m : Nat) := if m<1024 then moveRoom m else 1024+word s (m-1024)
theorem vertex_invol : ∀ i : Fin 10, vertex (vertex i.val)=i.val := by decide +kernel
theorem edge_image : ∀ i j : Fin 10, edge (vertex i.val) (vertex j.val)=edge i.val j.val := by decide +kernel
theorem small_axis : ∀ s : Swap,∀ j : Fin 6,axis s j<6 := by decide +kernel
theorem root_axis : ∀ s : Swap,∀ j : Fin 3,axis s j<3 := by decide +kernel
theorem poles_image : ∀ s : Swap,∀ j : Fin 6,
    lbl s (2*j.val)=2*axis s j ∧ lbl s (2*j.val+1)=2*axis s j+1 := by decide +kernel
theorem label_invol (s : Swap) (k : Nat) : lbl s (lbl s k)=k := by
  by_cases h : k<6
  · exact (show ∀ s : Swap,∀ a : Fin 6,lbl s (lbl s a.val)=a.val by decide +kernel) s ⟨k,h⟩
  · simp [lbl,h]
theorem label_xor : ∀ s : Swap,∀ k : Fin 12,lbl s (k.val ^^^ 1)=lbl s k.val ^^^ 1 := by decide +kernel
theorem label_bound : ∀ s : Swap,∀ k : Fin 12,lbl s k<12 := by decide +kernel
theorem word_bound : ∀ s : Swap,∀ w : Fin 64,word s w<64 := by decide +kernel
theorem bit_image : ∀ s : Swap,∀ w : Fin 64,∀ j : Fin 6,
    (word s w).testBit (axis s j)=w.val.testBit j.val := by decide +kernel
theorem obs_room (s : Swap) {m : Nat} (h : m∈rooms) : obsMap s m=moveRoom m := by
  have bound := (show ∀ u∈rooms,u<1024 by decide +kernel) m h
  simp [obsMap,bound]
theorem obs_word (s : Swap) (w : Nat) : obsMap s (1024+w)=1024+word s w  := by
  have no : ¬1024+w<1024 := by omega
  simp [obsMap,no]
theorem obs_ok (s : Swap) (m : Nat) (h : obs m) : obs (obsMap s m) := by
  rcases h with hm|⟨w,hw,rfl⟩
  · exact Or.inl (obs_room s hm ▸ (row_maps m hm).1)
  · exact Or.inr ⟨_,word_bound s ⟨w,hw⟩,obs_word s w⟩
theorem original_bounds {d mix v a} (h : a∈options d mix v) : ∀ k∈a,k<12 := by
  unfold options at h
  split at h
  · obtain rfl := List.mem_singleton.mp h; simp
  split at h
  · obtain rfl := List.mem_singleton.mp h; simp
  split at h
  · obtain rfl := List.mem_singleton.mp h; simp
  have hm := (List.mem_filter.mp h).1
  rcases List.mem_append.mp hm with h|h
  · exact (show ∀ a∈pairs,∀ k∈a,k<12 by decide +kernel) a h
  · cases mix with
    | false => simp at h
    | true => exact (show ∀ a∈triples,∀ k∈a,k<12 by decide +kernel) a h

structure Spec (s : Swap) (src dst : Dir) where
  origBound : ∀ j : Fin 6,∀ o∈originChoices src j.val,o<24
  legal : ∀ v : Fin 10,∀ mix : Bool,∀ a∈options src mix (vertex v.val), arm s a∈options dst mix v.val
  named : ∀ j : Fin 6,∀ o∈originChoices src (axis s j),origin s o∈originChoices dst j.val
  root : ∀ j : Fin 3,vertex ((ds dst)[j.val]?.getD 10)=(ds src)[axis s j]?.getD 10
  outside : ∀ v : Fin 10,v.val∉ds dst → vertex v.val∉ds src
  bounded : ∀ j : Fin 3,(ds dst)[j.val]?.getD 10<10
end Research.Graph9822.ThreeDirect.Sigma
#print axioms Research.Graph9822.ThreeDirect.Sigma.bit_image
