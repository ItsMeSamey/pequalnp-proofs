import PhysicalScanBundle9822
namespace Research.Graph9822Profiles

theorem observer_kept {b l p n} (h : Scan b l p n) : (Set.univ : Mask)∈l := by
  induction h with
  | start => simp
  | join _ _ _ ih => exact List.mem_cons_of_mem _ ih
  | split _ _ ih => exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ ih)

def padding (s : ReverseState) (i : Axis) : ReverseState :=
  {s with
    branches := (Set.univ ∩ side i true)::(Set.univ ∩ side i false)::s.branches
    switches := (i,Set.univ)::s.switches}

theorem good_padding (s : ReverseState) (i : Axis) (h : Good s) : Good (padding s i) := by
  obtain ⟨l,b,r,prev⟩ := h
  refine ⟨_,@Scan.split _ l _ _ Set.univ i b (observer_kept b),?_,?_⟩
  · intro k x hx
    exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (r k x hx))
  · intro x hx
    exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (prev x hx))

def paddedStep (s : ReverseState) (e : Event) : ReverseState :=
  if (s.q e.address).isEmpty then
    match e with
    | .andGate _ _ _ i => padding s i
    | _ => s
  else next s e

theorem good_paddedStep (s : ReverseState) (e : Event) (h : Good s) : Good (paddedStep s e) := by
  by_cases hr : s.q e.address = []
  · cases e <;> simp [paddedStep,hr,good_padding,h]
  · simpa [paddedStep,hr] using good_next s e h hr

theorem good_padded (es : List Event) (s : ReverseState) (h : Good s) :
    Good (es.foldl paddedStep s) := by
  induction es generalizing s with
  | nil => exact h
  | cons e es ih => exact ih _ (good_paddedStep s e h)

theorem padded_profile (es : List Event) (out : Nat) :
    let s := es.foldl paddedStep (initial out)
    Profile s.branches s.switches := by
  obtain ⟨_,scan,_,_⟩ := good_padded es _ (initial_good out)
  exact scan_profile scan

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.padded_profile

namespace Research.Graph9822Profiles

def realStep (s : ReverseState) (e : Event) : ReverseState :=
  if (s.q e.address).isEmpty then s else next s e

def actualEq (a b : ReverseState) : Prop :=
  a.q=b.q ∧ a.receivers=b.receivers ∧ a.cost=b.cost

theorem actual_step (a b : ReverseState) (e : Event) (eq : actualEq a b) :
    actualEq (paddedStep a e) (realStep b e) := by
  obtain ⟨he,hr,hc⟩ := eq
  cases e <;> simp only [actualEq,paddedStep,realStep,he] <;> split <;>
    simp_all [next,padding]

theorem actual_fold (es : List Event) (a b : ReverseState) (eq : actualEq a b) :
    actualEq (es.foldl paddedStep a) (es.foldl realStep b) := by
  induction es generalizing a b with
  | nil => exact eq
  | cons e es ih => exact ih _ _ (actual_step a b e eq)

def axisTags : Event → List Axis
  | .andGate _ _ _ i => [i]
  | _ => []

theorem issue_tags (es : List Event) (s : ReverseState) :
    (es.foldl paddedStep s).switches.map Prod.fst =
      (es.flatMap axisTags).reverse ++ s.switches.map Prod.fst := by
  induction es generalizing s with
  | nil => simp
  | cons e es ih =>
    simp only [List.foldl_cons,ih,List.flatMap_cons,List.reverse_append,List.append_assoc]
    congr 1
    cases e <;> simp only [paddedStep,axisTags] <;> split <;> simp [next,padding]

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.actual_fold
#print axioms Research.Graph9822Profiles.issue_tags

namespace Research.Graph9822Profiles

theorem unused_axes (axes : List Axis) (s : ReverseState) (g : Good s) :
    Good (axes.foldl padding s) ∧ actualEq (axes.foldl padding s) s ∧
      (axes.foldl padding s).switches.map Prod.fst = axes.reverse ++ s.switches.map Prod.fst := by
  induction axes generalizing s with
  | nil => exact ⟨g,⟨rfl,rfl,rfl⟩,by simp⟩
  | cons i tail ih =>
    obtain ⟨ok,eq,tags⟩ := ih (padding s i) (good_padding s i g)
    refine ⟨ok,eq,?_⟩
    simpa [padding,List.reverse_cons,List.append_assoc] using tags

end Research.Graph9822Profiles
#print axioms Research.Graph9822Profiles.unused_axes
