import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B239
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (2,3,9)
private noncomputable def rules : List Nat := unpack 35 [0x200000000c00e000b880000007060200032200000010000400000800000020]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x8018148005192800c008001c0d001222c00261a0000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B239
