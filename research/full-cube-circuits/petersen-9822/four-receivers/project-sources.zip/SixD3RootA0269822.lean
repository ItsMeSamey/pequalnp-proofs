import SixD3RootA1379822
import SixD3Sigma026To1379822
namespace Research.Graph9822.ThreeDirect.A026
def d : Dir := (0,2,6)
theorem closed : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact A137.closed ⟨Sigma.shared026_137 p⟩
end Research.Graph9822.ThreeDirect.A026
