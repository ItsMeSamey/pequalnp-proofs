import SixD3GridDataA2469822
namespace Research.Graph9822.ThreeDirect.A246
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part288 : Range (aOK d) (aCl d) g 288 312 :=
  rangeCheck _ _ _ 288 24 (by decide +kernel)
private theorem part312 : Range (aOK d) (aCl d) g 312 336 :=
  rangeCheck _ _ _ 312 24 (by decide +kernel)
private theorem part336 : Range (aOK d) (aCl d) g 336 360 :=
  rangeCheck _ _ _ 336 24 (by decide +kernel)
private theorem part360 : Range (aOK d) (aCl d) g 360 384 :=
  rangeCheck _ _ _ 360 24 (by decide +kernel)
private theorem part384 : Range (aOK d) (aCl d) g 384 408 :=
  rangeCheck _ _ _ 384 24 (by decide +kernel)
private theorem part408 : Range (aOK d) (aCl d) g 408 432 :=
  rangeCheck _ _ _ 408 24 (by decide +kernel)
theorem sem2 : Range (aOK d) (aCl d) g 288 432 := rangeAppend part288 (rangeAppend part312 (rangeAppend part336 (rangeAppend part360 (rangeAppend part384 (part408)))))
end Research.Graph9822.ThreeDirect.A246
