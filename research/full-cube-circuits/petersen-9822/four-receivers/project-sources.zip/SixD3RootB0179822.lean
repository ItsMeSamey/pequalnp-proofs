import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B017
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (0,1,7)
private noncomputable def rules : List Nat := unpack 35 [0x200003800c00a070b880000005060101c32200000008000007000800000000]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x8014166006199800c0240019b500118cc0023c20000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B017
