import SixD3GridSemA078x009822
import SixD3GridSemA078x019822
import SixD3GridSemA078x029822
import SixD3UnitA078x0009822
import SixD3UnitA078x0019822
import SixD3UnitA078x0029822
namespace Research.Graph9822.ThreeDirect.A078
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 389 (rangeAppend sem0 (rangeAppend sem1 (sem2)))
  intro a old
  apply endKnown g 417 (by decide +kernel) a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A078
