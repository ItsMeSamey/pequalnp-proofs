import SixD3GridSemA137x009822
import SixD3GridSemA137x019822
import SixD3GridSemA137x029822
import SixD3GridSemA137x039822
import SixD3GridSemA137x049822
import SixD3GridSemA137x059822
import SixD3GridSemA137x069822
import SixD3GridSemA137x079822
import SixD3GridSemA137x089822
import SixD3GridSemA137x099822
import SixD3GridSemA137x109822
import SixD3GridSemA137x119822
import SixD3GridSemA137x129822
import SixD3GridSemA137x139822
import SixD3GridSemA137x149822
import SixD3GridSemA137x159822
import SixD3GridSemA137x169822
import SixD3UnitA137x0009822
import SixD3UnitA137x0019822
import SixD3UnitA137x0029822
import SixD3UnitA137x0039822
import SixD3UnitA137x0049822
import SixD3UnitA137x0059822
import SixD3UnitA137x0069822
import SixD3UnitA137x0079822
import SixD3UnitA137x0089822
import SixD3UnitA137x0099822
import SixD3UnitA137x0109822
import SixD3UnitA137x0119822
import SixD3UnitA137x0129822
import SixD3UnitA137x0139822
import SixD3UnitA137x0149822
import SixD3UnitA137x0159822
import SixD3UnitA137x0169822
import SixD3UnitA137x0179822
import SixD3UnitA137x0189822
import SixD3UnitA137x0199822
import SixD3UnitA137x0209822
import SixD3UnitA137x0219822
import SixD3UnitA137x0229822
import SixD3UnitA137x0239822
import SixD3UnitA137x0249822
import SixD3UnitA137x0259822
import SixD3UnitA137x0269822
import SixD3UnitA137x0279822
import SixD3UnitA137x0289822
import SixD3UnitA137x0299822
import SixD3UnitA137x0309822
import SixD3UnitA137x0319822
import SixD3UnitA137x0329822
import SixD3UnitA137x0339822
import SixD3UnitA137x0349822
import SixD3UnitA137x0359822
import SixD3UnitA137x0369822
import SixD3UnitA137x0379822
import SixD3UnitA137x0389822
import SixD3UnitA137x0399822
import SixD3UnitA137x0409822
import SixD3UnitA137x0419822
import SixD3UnitA137x0429822
import SixD3UnitA137x0439822
import SixD3UnitA137x0449822
import SixD3UnitA137x0459822
import SixD3UnitA137x0469822
import SixD3UnitA137x0479822
import SixD3UnitA137x0489822
import SixD3UnitA137x0499822
import SixD3UnitA137x0509822
import SixD3UnitA137x0519822
namespace Research.Graph9822.ThreeDirect.A137
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 2391 (rangeAppend sem0 (rangeAppend sem1 (rangeAppend sem2 (rangeAppend sem3 (rangeAppend sem4 (rangeAppend sem5 (rangeAppend sem6 (rangeAppend sem7 (rangeAppend sem8 (rangeAppend sem9 (rangeAppend sem10 (rangeAppend sem11 (rangeAppend sem12 (rangeAppend sem13 (rangeAppend sem14 (rangeAppend sem15 (sem16)))))))))))))))))
  intro a old
  apply endKnown g 3007 (by decide +kernel) a
  apply up51 a
  apply up50 a
  apply up49 a
  apply up48 a
  apply up47 a
  apply up46 a
  apply up45 a
  apply up44 a
  apply up43 a
  apply up42 a
  apply up41 a
  apply up40 a
  apply up39 a
  apply up38 a
  apply up37 a
  apply up36 a
  apply up35 a
  apply up34 a
  apply up33 a
  apply up32 a
  apply up31 a
  apply up30 a
  apply up29 a
  apply up28 a
  apply up27 a
  apply up26 a
  apply up25 a
  apply up24 a
  apply up23 a
  apply up22 a
  apply up21 a
  apply up20 a
  apply up19 a
  apply up18 a
  apply up17 a
  apply up16 a
  apply up15 a
  apply up14 a
  apply up13 a
  apply up12 a
  apply up11 a
  apply up10 a
  apply up9 a
  apply up8 a
  apply up7 a
  apply up6 a
  apply up5 a
  apply up4 a
  apply up3 a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A137
