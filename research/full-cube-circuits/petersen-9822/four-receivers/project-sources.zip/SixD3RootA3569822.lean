import SixD3GridSemA356x009822
import SixD3GridSemA356x019822
import SixD3GridSemA356x029822
import SixD3GridSemA356x039822
import SixD3UnitA356x0009822
import SixD3UnitA356x0019822
import SixD3UnitA356x0029822
namespace Research.Graph9822.ThreeDirect.A356
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 437 (rangeAppend sem0 (rangeAppend sem1 (rangeAppend sem2 (sem3))))
  intro a old
  apply endKnown g 468 (by decide +kernel) a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A356
