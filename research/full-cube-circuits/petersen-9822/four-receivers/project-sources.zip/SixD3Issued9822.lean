import SixWideMarkedSources9822
import SixH4FreshPair9822
namespace Research.Graph9822Profiles.Fresh
open Research.Graph9822Profiles
abbrev Tag := Axis × Bool
def value (P : Axis→Mask) (a : Tag) := P a.1∩side a.1 a.2
def Seen (p : List (Axis × Mask)) (P : Axis→Mask) (a : Tag) := (a.1,P a.1)∈p
theorem seen_origin {p : List (Axis×Mask)} {P : Axis→Mask} {m : Mask}
    (ok : ∀ t∈p,t.2=P t.1) (o : Origin p m) : ∃ a,Seen p P a ∧ m=value P a := by
  obtain ⟨i,u,mem,s,eq⟩ := o
  have ui : u=P i := ok (i,u) mem
  exact ⟨(i,s),by simpa [Seen,←ui] using mem,by simpa [value,ui] using eq⟩
theorem issued_ray_in_store {N b l p e} (run : Marked N b l p e) :
    ∀ t∈p,∀ s,t.2∩side t.1 s∈l := by
  induction run with
  | start => simp
  | first h hx hy used fresh ih => exact fun t ht s=>List.mem_cons_of_mem _ (ih t ht s)
  | spare h hx hy skip ih => exact fun t ht s=>List.mem_cons_of_mem _ (ih t ht s)
  | @split b l p e u i h hu ih =>
    intro t ht s
    rcases List.mem_cons.mp ht with rfl|old
    · cases s <;> simp
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (ih t old s))
theorem spare_in_store {N b l p e} (r : Marked N b l p e) : ∀ H∈e,H∈l := by
  induction r with
  | start => simp
  | first h hx hy reserved fresh ih => exact fun H mem => List.mem_cons_of_mem _ (ih H mem)
  | spare h hx hy skip ih =>
    intro H mem
    rcases List.mem_cons.mp mem with rfl|old
    · exact List.mem_cons_self
    · exact List.mem_cons_of_mem _ (ih H old)
  | split h hu ih => exact fun H mem=>List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (ih H mem))
theorem ordinary_issued {N b l p e} (run : Marked N b l p e) (P : Axis→Mask)
    {m : Mask} (fresh : m∉l) (a c : Tag) (sa : Seen p P a) (sc : Seen p P c)
    (eq : m=value P a ∪ value P c) : DistinctPair P m := by
  refine ⟨a.1,a.2,c.1,c.2,?_,eq⟩
  rintro same
  obtain ⟨i,s⟩ := a
  obtain ⟨j,t⟩ := c
  change i=j at same
  subst j
  by_cases st : s=t
  · subst t
    apply fresh
    have u := issued_ray_in_store run (i,P i) sa s
    simpa [eq,value] using u
  · have parent := (marked_sources run).2 (i,P i) sa
    have united : m=P i := by
      rw [eq]
      ext q
      change ((q∈P i ∧ q i=s) ∨ (q∈P i ∧ q i=t)) ↔ q∈P i
      cases s <;> cases t <;> cases q i <;> simp_all
    exact fresh (by rw [united]; exact parent)
end Research.Graph9822Profiles.Fresh
