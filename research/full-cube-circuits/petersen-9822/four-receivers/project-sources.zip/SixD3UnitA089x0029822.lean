import SixD3GridUnits9822
import SixD3GridDataA0899822
namespace Research.Graph9822.ThreeDirect.A089
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit24 : ∀ a, Known a g 252 → Known a g 253 :=
  singleKnown g 252 (unpack 28 [0x1027800002de0a402a12e002d5287027609102c5207026e06f01b609d0182089010e06702ad1bf009604d03e205503b204303ad1dd02a511302a919d0388329037c1e903700a9036428803541480298008035dca4034da480290784]) (by decide +kernel)
private theorem unit25 : ∀ a, Known a g 253 → Known a g 254 :=
  singleKnown g 253 (unpack 28 [0x102cc00003f123e027207f03e60a0026208d024a07b021a05d01da047019a089016207703ee06b03ea05903b2043]) (by decide +kernel)
private theorem unit26 : ∀ a, Known a g 254 → Known a g 255 :=
  singleKnown g 254 (unpack 28 [0x1024400002d609002a128602cd23f024207f02c5207023e06f02dd2e101ae09d017a0890142077010606702ad1bf008e04d03f60a503e205503b204303ad1dd02a511302a919d0388329037c1e903700a9036428803541480298008035dca4034da480290784]) (by decide +kernel)
private theorem unit27 : ∀ a, Known a g 255 → Known a g 256 :=
  singleKnown g 255 (unpack 28 [0x1025400003e608c020e05d01ce04702c606e039e08902a120602ad1bf02dd2e103f20a103fa07b03f60a503ee06b03ea05903e205503b204303ad1dd02a511302a919d0388329037c1e903700a9036428803541480298008035dca4034da480290784]) (by decide +kernel)
private theorem unit28 : ∀ a, Known a g 256 → Known a g 257 :=
  singleKnown g 256 (unpack 28 [0x102cc00003f123e027207f03e60a0025e08d021605d01d60470196089015e07703fa07b03ee06b03ea05903b2043]) (by decide +kernel)
private theorem unit29 : ∀ a, Known a g 257 → Known a g 258 :=
  singleKnown g 257 (unpack 28 [0x103fc00002d528701b209d017e089010a067009204d0146077040209103b2043]) (by decide +kernel)
private theorem unit30 : ∀ a, Known a g 258 → Known a g 259 :=
  singleKnown g 258 (unpack 28 [0x103dc00003b604703fa07b03ee06b03ea05903e205503ba051]) (by decide +kernel)
private theorem unit31 : ∀ a, Known a g 259 → Known a g 260 :=
  singleKnown g 259 (unpack 28 [0x1040400002cd23f0146077040a08c03b2043]) (by decide +kernel)
private theorem unit32 : ∀ a, Known a g 260 → Known a g 261 :=
  singleKnown g 260 (unpack 28 [0x103e4000025a08d021205d01d20470192089015a077040e07e03fa07b03ee06b03ea059]) (by decide +kernel)
private theorem unit33 : ∀ a, Known a g 261 → Known a g 262 :=
  singleKnown g 261 (unpack 28 [0x102cc00003f123e027207f014a07704120a003b2043]) (by decide +kernel)
theorem up2 : ∀ a, Known a g 252 → Known a g 262 := by
  intro a h
  apply unit33 a
  apply unit32 a
  apply unit31 a
  apply unit30 a
  apply unit29 a
  apply unit28 a
  apply unit27 a
  apply unit26 a
  apply unit25 a
  apply unit24 a
  exact h
end Research.Graph9822.ThreeDirect.A089
