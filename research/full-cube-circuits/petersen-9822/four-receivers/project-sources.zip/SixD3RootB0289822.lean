import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B028
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (0,2,8)
private noncomputable def rules : List Nat := unpack 35 [0x40ae460b9015c7817202b8cc2e40571585c80ae240b9015c3c17202b8642e40570805c800000038000000050]
private def keys : List Nat := (List.range 10).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x2001c06800b03e003c14801306a005c21801b0a6007c3280230f20099b5000000000a] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B028
