import SixD3Labels9822
import SixD3OriginalSampling9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral (Word Lit ray)
def mask (r : Roots) (P : Fin 6→Set Word) (k : Nat) : Set Word :=
  {w | ∃ t : Lit,code r t=k ∧ w∈ray P t.1 t.2}
def cube (r : Roots) (w : Nat) : Word :=
  fun i=>if w.testBit (axisCode r i) then !(phase r i) else phase r i

theorem mask_at (r : Roots) (P : Fin 6→Set Word) (t : Lit) :
    mask r P (code r t)=ray P t.1 t.2 := by
  ext w
  constructor
  · rintro ⟨d,eq,h⟩
    exact (code_injective r eq) ▸ h
  · exact fun h=>⟨t,rfl,h⟩

theorem cube_wrong (r : Roots) (P : Fin 6→Set Word) (w j : Nat) :
    cube r w∉mask r P (2*j+(if w.testBit j then 0 else 1)) := by
  rintro ⟨t,hit,rayHit⟩
  have jEq := code_axis r t
  rw [hit] at jEq
  have eq : axisCode r t.1=j := by
    cases h : w.testBit j <;> simp_all <;> omega
  have yes : cube r w t.1=t.2 := rayHit.2
  cases bit : w.testBit j <;> cases pol : phase r t.1 <;> cases ht : t.2 <;>
    simp [cube,code,eq,bit,pol,ht] at yes hit <;> omega

theorem inverse_axis (r : Roots) (j : Fin 6) : ∃ i : Fin 6,axisCode r i=j.val := by
  let f (i : Fin 6) : Fin 6 := ⟨axisCode r i,axisBound r i⟩
  have inj : Function.Injective f := fun _ _ h=>axisInj r (congrArg Fin.val h)
  obtain ⟨i,eq⟩ := (Finite.injective_iff_surjective.mp inj) j
  exact ⟨i,congrArg Fin.val eq⟩

theorem slot_masks (r : Roots) (P : Fin 6→Set Word) (i : Fin 6) :
    mask r P (2*axisCode r i)=ray P i (phase r i) ∧
    mask r P (2*axisCode r i+1)=ray P i (!(phase r i)) := by
  have ev : code r (i,phase r i)=2*axisCode r i := by simp [code]
  have od : code r (i,!(phase r i))=2*axisCode r i+1 := by
    cases h : phase r i <;> simp [code,h]
  exact ⟨ev ▸ mask_at r P (i,phase r i),od ▸ mask_at r P (i,!(phase r i))⟩

theorem slot_rows (r : Roots) (P : Fin 6→Set Word) (i : Fin 6) (w : Word) :
    (w∈mask r P (2*axisCode r i) ∨ w∈mask r P (2*axisCode r i+1) ↔ w∈P i) ∧
    (w∈mask r P (2*axisCode r i) → w∉mask r P (2*axisCode r i+1)) := by
  obtain ⟨ev,od⟩ := slot_masks r P i
  rw [ev,od]
  change (((w∈P i ∧ w i=phase r i) ∨ (w∈P i ∧ w i= !(phase r i))) ↔ _) ∧
    ((w∈P i ∧ w i=phase r i) → ¬(w∈P i ∧ w i= !(phase r i)))
  cases phase r i <;> cases w i <;> simp

theorem slot_disjoint (r : Roots) (P : Fin 6→Set Word) (j : Nat) (h : j<6) (w : Word) :
    w∈mask r P (2*j) → w∉mask r P (2*j+1) := by
  obtain ⟨i,eq⟩ := inverse_axis r ⟨j,h⟩
  change axisCode r i=j at eq
  simpa only [eq] using (slot_rows r P i w).2
end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.cube_wrong
#print axioms Research.SixD3.Labels.slot_disjoint
