import And9822RoomDomains
import And9822CommonScan

namespace Research.Graph9822.NumericBank
open Graph9822Profiles ArbitraryScan
noncomputable section
open Classical

/-- A failed unary room at every receiver forbids the activation as a raw.
Each distinct such nonprimitive activation uses one common grant. -/
theorem forced_grant_count {P : Axis6 → Mask6} {R : Fin 10 → Mask6}
    (e : RoomEmbedding P R) (inj : Function.Injective R)
    {raw grants forced : Finset Mask6} {hs : List Mask6} {names : List Mask6}
    (rawDef : ∀ m, m ∈ raw ↔ ∃ v, R v = m ∧ ¬RayValue P m)
    (grantDef : ∀ m, m ∈ grants ↔ m ∈ names ∧ ¬Primitive P m ∧ m ∉ raw)
    (priced : hs.length + raw.card + grants.card ≤ 8)
    (named : ∀ m ∈ forced, m ∈ names ∧ ¬Primitive P m)
    (fails : ∀ m ∈ forced, ∀ v : Fin 10, ∃ a : Bool,
      ¬widthTest (firstReps P) v (key P m) a) :
    hs.length + forced.card + 2 ≤
      ((Finset.univ : Finset (Fin 10)).filter (fun v => RayValue P (R v))).card := by
  have sub : forced ⊆ grants := by
    intro m hm
    apply (grantDef m).mpr
    refine ⟨(named m hm).1,(named m hm).2,?_⟩
    intro hr
    obtain ⟨v,eq,_⟩ := (rawDef m).mp hr
    obtain ⟨a,no⟩ := fails m hm v
    apply no
    subst m
    simpa [widthTest,rooms] using room_capacity e [(v,a)]
  have bound := spare_count inj rawDef priced
  have card := Finset.card_le_card sub
  omega

end
end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.forced_grant_count
