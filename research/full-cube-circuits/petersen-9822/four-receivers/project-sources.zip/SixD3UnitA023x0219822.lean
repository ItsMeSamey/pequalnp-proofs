import SixD3GridUnits9822
import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit219 : ∀ a, Known a g 2777 → Known a g 2778 :=
  singleKnown g 2777 (unpack 28 [0x12b400000ff5e7310a1e7d10b5e7f023a0990226083021a093021608101d608901d20772b51e6f1501e6314fde5514f1e491511e671509e4d150de591515e6d2b61e7707a6066]) (by decide +kernel)
private theorem unit220 : ∀ a, Known a g 2778 → Known a g 2779 :=
  singleKnown g 2778 (unpack 28 [0x12b400000ff5e7310a1e7d10b5e7f053609905220830516093051208102d6089026e0771501e6314fde5514f1e491511e671509e4d150de592b61e772b6606e10a9e6f1515e6d28f2097]) (by decide +kernel)
private theorem unit221 : ∀ a, Known a g 2779 → Known a g 2780 :=
  singleKnown g 2779 (unpack 28 [0x113080002b41e4c12e1e7312d9e6312d1e5512c1e491319e591321e671365e7d1329e771375e7f135de6d2b5919c2b69207106deab07e52e10fb1e990f89d77077d1bf2b560a510a9e6f2a8dea328f2097]) (by decide +kernel)
private theorem unit222 : ∀ a, Known a g 2780 → Known a g 2781 :=
  singleKnown g 2780 (unpack 28 [0x101c800010a20982b41e7c0fc9e491031e4d1099e6d01aa09301a608101a2071018208d017205101660892b51e6f28f2097]) (by decide +kernel)
private theorem unit223 : ∀ a, Known a g 2781 → Known a g 2782 :=
  singleKnown g 2781 (unpack 28 [0x104f800010a20982b41e7c0fc9e491031e4d1099e6d04da09304d608104d2071044608d03d605102d208907920602b72059146de731469e631461e551479e771471e591475e671485e7f2b6d1dc10a9e6f28f2097]) (by decide +kernel)
private theorem unit224 : ∀ a, Known a g 2782 → Known a g 2783 :=
  singleKnown g 2782 (unpack 28 [0x113f0000076d1be11611132b41e481055e770ff5e7310a1e7d10b5e7f015609901420831031e4d1099e6d01360930132081012e07107a5207011e06f07911dd011a0611045e59104de67010e08d010a07b010606b010205d00fe051077519d00fa0470fdde550fe9e6300f208900ee07700ea06700e605907e52e12b51e6f2b560a528f2097]) (by decide +kernel)
private theorem unit225 : ∀ a, Known a g 2783 → Known a g 2784 :=
  singleKnown g 2783 (unpack 28 [0x12b400001055e770ff5e7310a1e7d1031e4d1099e6d0fc9e491045e59104de670fdde550fe9e6304ba099049a09304960810492071044208d042607b040a06b03d205102ce089026607701fa067018a0592b76054281e073282205d1485e7f2b51e6f2b7a04d28f2097]) (by decide +kernel)
private theorem unit226 : ∀ a, Known a g 2784 → Known a g 2785 :=
  singleKnown g 2784 (unpack 28 [0x1051c00007a606e2b59206077519d03ae0470222067106deab07e52e10fb1e992b560a52a8dea32b7d1dd2b760720f89d77077d1bf2b51e6f2b7a04d]) (by decide +kernel)
private theorem unit227 : ∀ a, Known a g 2785 → Known a g 2786 :=
  singleKnown g 2785 (unpack 28 [0x12b4000010a1e7d1055e770ff5e7310b5e7f04ba09904a60831031e4d1099e6d0fc9e49049a093049608104920711045e59104de67044208d042607b040a06b03ee05d03d20510fdde550fe9e6302ce089018a0592b7a04d026607701fa0672b820542b51e6f28f2097]) (by decide +kernel)
private theorem unit228 : ∀ a, Known a g 2786 → Known a g 2787 :=
  singleKnown g 2786 (unpack 28 [0x12b400001099e6d104de670fe9e63054e0930546071044e08d041606b02da08907ba07e026607701fa0672b51e6f15a5e7315a1e551595e49157de3115bde7715b9e5915cde7d15d1e7f15b5e4d049e0a7033209d009e043003203528f2097]) (by decide +kernel)
private theorem unit229 : ∀ a, Known a g 2787 → Known a g 2788 :=
  singleKnown g 2787 (unpack 28 [0x11098000054e0930546071285207e151520714011bf135d19d16cd28728f2097]) (by decide +kernel)
private theorem unit230 : ∀ a, Known a g 2788 → Known a g 2789 :=
  singleKnown g 2788 (unpack 28 [0x102d80000fea088020606728f2097]) (by decide +kernel)
theorem up21 : ∀ a, Known a g 2777 → Known a g 2789 := by
  intro a h
  apply unit230 a
  apply unit229 a
  apply unit228 a
  apply unit227 a
  apply unit226 a
  apply unit225 a
  apply unit224 a
  apply unit223 a
  apply unit222 a
  apply unit221 a
  apply unit220 a
  apply unit219 a
  exact h
end Research.Graph9822.ThreeDirect.A023
