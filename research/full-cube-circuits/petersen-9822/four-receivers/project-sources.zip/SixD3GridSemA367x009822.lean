import SixD3GridDataA3679822
namespace Research.Graph9822.ThreeDirect.A367
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part0 : Range (aOK d) (aCl d) g 0 24 :=
  rangeCheck _ _ _ 0 24 (by decide +kernel)
private theorem part24 : Range (aOK d) (aCl d) g 24 48 :=
  rangeCheck _ _ _ 24 24 (by decide +kernel)
private theorem part48 : Range (aOK d) (aCl d) g 48 72 :=
  rangeCheck _ _ _ 48 24 (by decide +kernel)
private theorem part72 : Range (aOK d) (aCl d) g 72 96 :=
  rangeCheck _ _ _ 72 24 (by decide +kernel)
private theorem part96 : Range (aOK d) (aCl d) g 96 120 :=
  rangeCheck _ _ _ 96 24 (by decide +kernel)
private theorem part120 : Range (aOK d) (aCl d) g 120 144 :=
  rangeCheck _ _ _ 120 24 (by decide +kernel)
theorem sem0 : Range (aOK d) (aCl d) g 0 144 := rangeAppend part0 (rangeAppend part24 (rangeAppend part48 (rangeAppend part72 (rangeAppend part96 (part120)))))
end Research.Graph9822.ThreeDirect.A367
