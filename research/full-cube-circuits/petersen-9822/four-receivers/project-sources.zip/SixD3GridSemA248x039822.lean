import SixD3GridDataA2489822
namespace Research.Graph9822.ThreeDirect.A248
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part432 : Range (aOK d) (aCl d) g 432 456 :=
  rangeCheck _ _ _ 432 24 (by decide +kernel)
private theorem part456 : Range (aOK d) (aCl d) g 456 480 :=
  rangeCheck _ _ _ 456 24 (by decide +kernel)
private theorem part480 : Range (aOK d) (aCl d) g 480 504 :=
  rangeCheck _ _ _ 480 24 (by decide +kernel)
private theorem part504 : Range (aOK d) (aCl d) g 504 528 :=
  rangeCheck _ _ _ 504 24 (by decide +kernel)
private theorem part528 : Range (aOK d) (aCl d) g 528 552 :=
  rangeCheck _ _ _ 528 24 (by decide +kernel)
private theorem part552 : Range (aOK d) (aCl d) g 552 576 :=
  rangeCheck _ _ _ 552 24 (by decide +kernel)
theorem sem3 : Range (aOK d) (aCl d) g 432 576 := rangeAppend part432 (rangeAppend part456 (rangeAppend part480 (rangeAppend part504 (rangeAppend part528 (part552)))))
end Research.Graph9822.ThreeDirect.A248
