import SixH4ProjectedModel9822
namespace Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (Arm rooms edge rawBit opposes)
abbrev Dir := Nat × Nat × Nat
def ds (d : Dir) := [d.1,d.2.1,d.2.2]
def allowed : List Nat := [1,3,5,6,7,8,9,10,11]
def pairs : List Arm := allowed.flatMap fun i => (allowed.filter (fun j =>
  decide (i<j) && !(i/2 == j/2))).map (fun j => [i,j])
def triples : List Arm := allowed.flatMap fun i => allowed.flatMap fun j =>
  if i < j ∧ i/2 ≠ j/2 then (allowed.filter (fun k =>
    decide (j<k) && !(i/2 == k/2) && !(j/2 == k/2))).map (fun k => [i,j,k]) else []
def options (d : Dir) (mix : Bool) (v : Nat) : List Arm :=
  if v=d.1 then [[0]] else if v=d.2.1 then [[2]] else if v=d.2.2 then [[4]] else
  (pairs ++ if mix then triples else []).filter fun t =>
    (!edge v d.1 || t.contains 1) && (!edge v d.2.1 || t.contains 3) &&
      (!edge v d.2.2 || t.contains 5)
def obs (m : Nat) := m ∈ rooms ∨ ∃ w < 64, m = 1024+w
structure Rooms (d : Dir) (mix : Bool) where
  raw : Nat → Arm
  ray : Nat → Nat → Bool
  selected : ∀ v, v<10 → raw v ∈ options d mix v
  rawRows : ∀ v, v<10 → ∀ m ∈ rooms, (raw v).any (fun k => ray k m) = rawBit v m
  opposed : ∀ u v, u<v → v<10 → edge u v = true → opposes (raw u) (raw v) = true
  disjoint : ∀ j, j<6 → ∀ m ∈ rooms, (ray (2*j) m && ray (2*j+1) m) = false
def originChoices (d : Dir) (j : Nat) :=
  [22] ++ ((List.range 12).filter (fun k => !(k/2 == j))) ++
    (if j<3 then [] else [23] ++ ((List.range 10).filter
      (fun v => !((ds d).contains v))).map (· + 12))
structure Shared (d : Dir) extends Rooms d true where
  helper : Arm
  origin : Nat → Nat
  helperOK : helper ∈ pairs
  linked : ∀ v, v<10 → (raw v).length=3 → ∀ k∈helper, k∈raw v
  named : ∀ j, j<6 → origin j ∈ originChoices d j
  activation : ∀ j, j<6 → ∀ m, obs m →
    (ray (2*j) m || ray (2*j+1) m) =
      if origin j=22 then true else if origin j=23 then helper.any (fun k => ray k m)
      else if origin j<12 then ray (origin j) m
      else (raw (origin j-12)).any (fun k => ray k m)
  fullNonneighbor : ∀ j, j<3 → origin j=22 → ∀ v, v<10 → v∉ds d →
    edge v ((ds d)[j]?.getD 10)=false → 2*j+1 ∉ raw v
  ordinaryNeighbor : ∀ j, j<3 → origin j≠22 → ∀ v w, v<w → w<10 →
    edge ((ds d)[j]?.getD 10) v=true → edge ((ds d)[j]?.getD 10) w=true →
    (raw v).length=2 → (raw w).length≠2
  wrongSign : ∀ w, w<64 → ∀ j, j<6 →
    ray (2*j+(if w.testBit j then 0 else 1)) (1024+w) = false
  edgeWords : ∀ u v, u<v → v<10 → edge u v=true → ∀ w, w<64 →
    ((raw u).any (fun k => ray k (1024+w)) || (raw v).any (fun k => ray k (1024+w))) = true
end Research.Graph9822.ThreeDirect
