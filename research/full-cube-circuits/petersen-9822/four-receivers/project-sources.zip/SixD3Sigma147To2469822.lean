import SixD3SigmaShared9822
namespace Research.Graph9822.ThreeDirect.Sigma
open Research.Graph9822.TwoDirect.Symmetry (vertex)
private theorem legal147_246at0 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 0),arm 0 t ∈ options (2,4,6) mix 0 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal147_246at1 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 1),arm 0 t ∈ options (2,4,6) mix 1 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal147_246at2 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 2),arm 0 t ∈ options (2,4,6) mix 2 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal147_246at3 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 3),arm 0 t ∈ options (2,4,6) mix 3 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal147_246at4 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 4),arm 0 t ∈ options (2,4,6) mix 4 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal147_246at5 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 5),arm 0 t ∈ options (2,4,6) mix 5 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal147_246at6 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 6),arm 0 t ∈ options (2,4,6) mix 6 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal147_246at7 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 7),arm 0 t ∈ options (2,4,6) mix 7 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal147_246at8 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 8),arm 0 t ∈ options (2,4,6) mix 8 := by
  intro mix; cases mix <;> decide +kernel
private theorem legal147_246at9 : ∀ mix : Bool,∀ t∈options (1,4,7) mix (vertex 9),arm 0 t ∈ options (2,4,6) mix 9 := by
  intro mix; cases mix <;> decide +kernel
def spec147_246 : Spec 0 (1,4,7) (2,4,6) where
  origBound := by decide +kernel
  legal := by
    intro v
    have e := (show ∀ k : Fin 10, k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 ∨ k=8 ∨ k=9 by decide +kernel) v
    rcases e with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact legal147_246at0
    · exact legal147_246at1
    · exact legal147_246at2
    · exact legal147_246at3
    · exact legal147_246at4
    · exact legal147_246at5
    · exact legal147_246at6
    · exact legal147_246at7
    · exact legal147_246at8
    · exact legal147_246at9
  named := by decide +kernel
  root := by decide +kernel
  outside := by decide +kernel
  bounded := by decide +kernel
def rooms147_246 {mix : Bool} : Rooms (1,4,7) mix → Rooms (2,4,6) mix := roomsTransfer spec147_246
def shared147_246 : Shared (1,4,7) → Shared (2,4,6) := sharedTransfer spec147_246
end Research.Graph9822.ThreeDirect.Sigma
#print axioms Research.Graph9822.ThreeDirect.Sigma.shared147_246
