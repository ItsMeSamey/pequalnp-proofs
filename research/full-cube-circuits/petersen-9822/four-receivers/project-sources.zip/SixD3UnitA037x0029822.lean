import SixD3GridUnits9822
import SixD3GridDataA0379822
namespace Research.Graph9822.ThreeDirect.A037
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit24 : ∀ a, Known a g 241 → Known a g 242 :=
  singleKnown g 241 (unpack 28 [0x101b800003c1d9400f510401111f900b051203a227a0195d990141435006e06101252d3006a0a1011d279006608d0115231006207b01051cf005e05d00fd1b1005a05100f919d0056047005209d004e089004a0770046059004204d0006035002e04303541f300f015200e8e90]) (by decide +kernel)
private theorem unit25 : ∀ a, Known a g 242 → Known a g 243 :=
  singleKnown g 242 (unpack 28 [0x1014000000c6061007e0590144472035c333034c0b3017029200e401201697f400dc784]) (by decide +kernel)
private theorem unit26 : ∀ a, Known a g 243 → Known a g 244 :=
  singleKnown g 243 (unpack 28 [0x10124000003a0a1001e09d0002035]) (by decide +kernel)
private theorem unit27 : ∀ a, Known a g 244 → Known a g 245 :=
  singleKnown g 244 (unpack 28 [0x10138000007604d00c2055013c3d203a141603c943503ba27b03ce043035c333034c0b3017029200e401201697f400dc784]) (by decide +kernel)
private theorem unit28 : ∀ a, Known a g 245 → Known a g 246 :=
  singleKnown g 245 (unpack 28 [0x10138000007604d00c2055013c3d203a141603c9435035c333034c0b3017029200e401201697f400dc784]) (by decide +kernel)
private theorem unit29 : ∀ a, Known a g 246 → Known a g 247 :=
  singleKnown g 246 (unpack 28 [0x100b0000011051303b206a03c11f8018dd950195d9900ae05d00ca06101011b10360473039127900a604703ad1cf03b523103d12d3035c33303541f3034c0b3017029200f015200e401201697f400e8e9000dc784]) (by decide +kernel)
private theorem unit30 : ∀ a, Known a g 247 → Known a g 248 :=
  singleKnown g 247 (unpack 28 [0x101d000003c1d9801b9d9500f510403b11f903c606b013d41700fd1b1007a04d00f919d039127900aa05100a604703ad1cf03b523103d83d3007203503d627a03d12d3035c33303541f3034c0b3017029200f015200e401201697f400e8e9000dc784]) (by decide +kernel)
private theorem unit31 : ∀ a, Known a g 248 → Known a g 249 :=
  singleKnown g 248 (unpack 28 [0x100f4000023119d01b910503c1d940195d99011d2790115231010d1f901051cf00fd1b1003e061003608d003207b002e06b002a05d00260510022047001a08900160770012067000e059000a04d000203503de04203d12d3]) (by decide +kernel)
theorem up2 : ∀ a, Known a g 241 → Known a g 249 := by
  intro a h
  apply unit31 a
  apply unit30 a
  apply unit29 a
  apply unit28 a
  apply unit27 a
  apply unit26 a
  apply unit25 a
  apply unit24 a
  exact h
end Research.Graph9822.ThreeDirect.A037
