import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B148
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (1,4,8)
private noncomputable def rules : List Nat := unpack 35 [0x200005800c00c0b0b880000006060182c3220000000c00020b000800000010]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x801817400519d800c034001ae10011d7c0024ee0000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B148
