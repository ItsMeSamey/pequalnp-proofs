import SixD3SelectedPhysical9822
import SixD3PhysicalNames9822
import SixD3PhysicalProjection9822
namespace Research.Graph9822.ArbitraryScan
open Research.Graph9822Profiles Research.Graph9822Profiles.Fresh
open Research.SixD3.Labels Research.Graph9822.ThreeDirect
open Research.SixH4.DirectLiteral (Lit receives)
open PEqualNP.Outside.L_meta_9822.Receivers
theorem project_mixed {P : Axis→Mask} {R : Fin 10→Mask} (r : ThreeRoots P R) (a c : Lit)
    (ac : a.1≠c.1) (arm : PhysicalArms P R r true [a,c]) (real : ExactReceivers (fun v q=>q∈R v))
    (edges : ∀ i j : Fin 10,TwoDirect.edge i.val j.val=true ↔ ∀q,q∈R i ∨ q∈R j)
    (anti : ∀ i j : Fin 10,i≠j → ¬R i⊆R j) (stable : ∀i,Stable (P i) i)
    (pos : ∀i,∃q,q∈P i) (H : Mask) (he : H=Research.Graph9822Profiles.Fresh.value P a∪Research.Graph9822Profiles.Fresh.value P c)
    (uses : ∃v,¬RayValue P (R v) ∧ H⊆R v)
    (issued : ∀i,Primitive P (P i) ∨ (∃v,R v=P i) ∨ P i=H) :
    labelDir r.x r.y r.z∈roster38 ∧ Nonempty (Shared (labelDir r.x r.y r.z)) := by
  obtain ⟨keep,sel,opp⟩ := select_physical arm real edges
  let d := labelDir r.x r.y r.z
  have mem (v : Fin 10) : v.val∈ds d ↔ v=r.x ∨ v=r.y ∨ v=r.z := by
    simp [d,ds,labelDir,Fin.ext_iff]
  obtain ⟨v,nd,sub⟩ := uses
  have rows := root_rows r.roots P R r.x r.y r.z r.rx r.ry r.rz
  have direct (u : Fin 10) (hu : u.val∈ds d) := (r.exactly u).2 ((mem u).1 hu)
  have no (u : Fin 10) (k : Lit) (eq : R u=Research.Graph9822Profiles.Fresh.value P k) (dir : RayValue P (R u)) : k∉[a,c] := by
    intro hk
    have ne : u≠v := fun eq=>nd (eq ▸ dir)
    apply anti u v ne
    intro q hq
    apply sub
    rw [he]
    rw [eq] at hq
    rcases List.mem_cons.mp hk with e|e
    · exact Or.inl (e ▸ hq)
    · exact Or.inr (List.mem_singleton.mp e ▸ hq)
  have hOK := helper_pair r.roots a c ac [a,c] (fun _ h=>h)
    (no r.x _ r.rx ⟨_,_,r.rx⟩) (no r.y _ r.ry ⟨_,_,r.ry⟩) (no r.z _ r.rz ⟨_,_,r.rz⟩)
  refine ⟨keep,shared_projection r.roots P R d arm.L H [a,c] real arm.meaning ?_ ?_ sel opp hOK arm.linked rows
    (choice_from_sites r.roots P R d H rows direct ⟨v,fun h=>nd (direct v h),sub⟩ stable pos anti issued) edges anti⟩
  · intro w
    rw [he]
    simp [receives,Research.Graph9822Profiles.Fresh.value,Research.SixH4.DirectLiteral.ray,side,Research.SixH4.DirectLiteral.side]
  · intro u
    by_cases x : u=r.x
    · exact Or.inl ⟨_,x.symm ▸ arm.lx⟩
    by_cases y : u=r.y
    · exact Or.inl ⟨_,y.symm ▸ arm.ly⟩
    by_cases z : u=r.z
    · exact Or.inl ⟨_,z.symm ▸ arm.lz⟩
    exact Or.inr (arm.shape u x y z)
end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.project_mixed
