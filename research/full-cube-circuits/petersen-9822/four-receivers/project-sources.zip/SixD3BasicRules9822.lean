import SixD3EquationLaws9822
namespace Research.Graph9822.ThreeDirect
open Research.Graph9822.TwoDirect (Arm rooms edge rawBit opposes)
inductive Basic
  | one (v : Nat)
  | eqn (v m : Nat) (t : Arm) (mode : Option Atom)
  | edge (u v : Nat) (a b : Arm)
  | disj (j m : Nat)
  deriving Repr, Inhabited
def Basic.ok : Basic → Bool
  | .one v => decide (v<10)
  | .eqn v m t mode => decide (v<10) && isObs m && (rawEq v m t).legal mode
  | .edge u v a b => decide (u<v) && decide (v<10) && TwoDirect.edge u v && !(opposes a b)
  | .disj j m => decide (j<6) && rooms.contains m
def Basic.clause (d : Dir) (mix : Bool) : Basic → Clause
  | .one v => (options d mix v).map (fun t => pos (.raw v t))
  | .eqn v m t mode => (rawEq v m t).clause mode
  | .edge u v a b => [neg (.raw u a),neg (.raw v b)]
  | .disj j m => [neg (.ray (2*j) m),neg (.ray (2*j+1) m)]
theorem Basic.sound (p : Rooms d mix) (help : Arm) (o : Nat → Nat) (r : Basic)
    (ok : r.ok=true) : Sat (envOf p help o) (r.clause d mix) := by
  cases r with
  | one v => exact ⟨_,List.mem_map.mpr ⟨p.raw v,p.selected v (of_decide_eq_true ok),rfl⟩,
      by simp [pos,Env.val,envOf]⟩
  | eqn v m t mode =>
    simp only [Basic.ok,Bool.and_eq_true,decide_eq_true_eq] at ok
    exact Equation.sound _ _ mode (rawEq_holds p help o v m t ok.1.1 (obsBool ok.1.2)) ok.2
  | edge u v a b =>
    simp only [Basic.ok,Bool.and_eq_true,decide_eq_true_eq,Bool.not_eq_true'] at ok
    have h := p.opposed u v ok.1.1.1 ok.1.1.2 ok.1.2
    simp [Sat,Basic.clause,neg,Env.val,envOf]
    by_cases h1 : p.raw u=a <;> by_cases h2 : p.raw v=b <;> simp_all
  | disj j m =>
    simp only [Basic.ok,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at ok
    have h := p.disjoint j ok.1 m ok.2
    simp [Sat,Basic.clause,neg,Env.val,envOf]
    cases ha : p.ray (2*j) m <;> cases hb : p.ray (2*j+1) m <;> simp_all
end Research.Graph9822.ThreeDirect
