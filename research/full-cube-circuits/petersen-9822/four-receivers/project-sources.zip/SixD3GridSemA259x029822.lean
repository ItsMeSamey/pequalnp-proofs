import SixD3GridDataA2599822
namespace Research.Graph9822.ThreeDirect.A259
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part288 : Range (aOK d) (aCl d) g 288 292 :=
  rangeCheck _ _ _ 288 4 (by decide +kernel)
theorem sem2 : Range (aOK d) (aCl d) g 288 292 := part288
end Research.Graph9822.ThreeDirect.A259
