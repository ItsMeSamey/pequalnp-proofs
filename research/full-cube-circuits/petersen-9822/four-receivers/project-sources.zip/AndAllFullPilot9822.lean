import FourSaturationData

-- And9822ChargeBundle
set_option maxRecDepth 100000
set_option maxHeartbeats 0

-- And9822UnionCharge.lean SHA-256 b565664b6b6abe6aa01077e18eef5750b2b475e2845a4a56903c9df80195801a
namespace Research.Graph9822.UnionCharge

structure Bank (cost : Nat) where
  left : Fin cost → Nat
  right : Fin cost → Nat
  output : Fin cost → Nat
  has : Nat → Nat → Prop
  first : Nat → Nat
  firstLe : ∀ w k, has w k → first w ≤ k
  firstMem : ∀ w, has w (first w)
  unionMem : ∀ i k, has (output i) k ↔ has (left i) k ∨ has (right i) k
  firstUnion : ∀ i, first (output i) = min (first (left i)) (first (right i))

inductive Built {cost : Nat} (b : Bank cost) : Nat → Prop where
  | singleton (w) : (∀ l, b.has w l → l = b.first w) → Built b w
  | join (i : Fin cost) : Built b (b.left i) → Built b (b.right i) → Built b (b.output i)

def loss {c} (b : Bank c) (i : Fin c) := max (b.first (b.left i)) (b.first (b.right i))

structure Charge {c} (b : Bank c) (w l : Nat) (i : Fin c) : Prop where
  label : loss b i = l
  here : b.has (b.output i) l
  lower : ∃ k, k < l ∧ b.has (b.output i) k
  sub : ∀ k, b.has (b.output i) k → b.has w k

theorem chargeExists {c} (b : Bank c) {w} (hw : Built b w) {l}
    (member : b.has w l) (later : b.first w < l) :
    ∃ i, Charge b w l i := by
  induction hw with
  | singleton w one =>
    have e := one l member
    omega
  | join i _ _ leftIH rightIH =>
    let a := b.first (b.left i)
    let d := b.first (b.right i)
    have smaller : min a d < l := by simpa [a,d,b.firstUnion] using later
    rcases (b.unionMem i l).mp member with hl | hr
    · by_cases h : a < l
      · obtain ⟨j,hj⟩ := leftIH hl h
        exact ⟨j,⟨hj.label,hj.here,hj.lower,fun k hk => (b.unionMem i k).mpr (Or.inl (hj.sub k hk))⟩⟩
      · have eq : a = l := by have := b.firstLe _ _ hl; change a ≤ l at this; omega
        have dl : d < l := by omega
        refine ⟨i,⟨?_,member,⟨d,dl,(b.unionMem i d).mpr (Or.inr (b.firstMem _))⟩,fun _ h => h⟩⟩
        change max a d = l
        omega
    · by_cases h : d < l
      · obtain ⟨j,hj⟩ := rightIH hr h
        exact ⟨j,⟨hj.label,hj.here,hj.lower,fun k hk => (b.unionMem i k).mpr (Or.inr (hj.sub k hk))⟩⟩
      · have eq : d = l := by have := b.firstLe _ _ hr; change d ≤ l at this; omega
        have al : a < l := by omega
        refine ⟨i,⟨?_,member,⟨a,al,(b.unionMem i a).mpr (Or.inl (b.firstMem _))⟩,fun _ h => h⟩⟩
        change max a d = l
        omega

theorem chargeUnique {c} {b : Bank c} {w v l k : Nat} {i : Fin c}
    (hw : Charge b w l i) (hv : Charge b v k i)
    (linear : w ≠ v → ∀ x y, b.has w x → b.has v x → b.has w y → b.has v y → x = y) :
    w = v ∧ l = k := by
  have eq : l = k := hw.label.symm.trans hv.label
  refine ⟨?_,eq⟩
  apply Classical.byContradiction
  intro diff
  obtain ⟨z,hz,hmem⟩ := hw.lower
  have h := linear diff l z (hw.sub _ hw.here) (hv.sub _ hw.here)
    (hw.sub _ hmem) (hv.sub _ hmem)
  omega

theorem bound {c n : Nat} (b : Bank c) (target lit : Fin n → Nat)
    (build : ∀ j, Built b (target j))
    (member : ∀ j, b.has (target j) (lit j))
    (later : ∀ j, b.first (target j) < lit j)
    (unique : ∀ i j, target i = target j → lit i = lit j → i = j)
    (linear : ∀ i j, target i ≠ target j → ∀ x y,
      b.has (target i) x → b.has (target j) x →
      b.has (target i) y → b.has (target j) y → x = y) : n ≤ c := by
  classical
  have ex (j : Fin n) := chargeExists b (build j) (member j) (later j)
  let f (j : Fin n) : Fin c := Classical.choose (ex j)
  have spec (j : Fin n) : Charge b (target j) (lit j) (f j) := Classical.choose_spec (ex j)
  have inj {i j : Fin n} (he : f i = f j) : i = j := by
    have h1 := spec i
    rw [he] at h1
    obtain ⟨hw,hl⟩ := chargeUnique h1 (spec j) (linear i j)
    exact unique _ _ hw hl
  have nd : ((List.finRange n).map f).Nodup :=
    List.pairwise_map.mpr ((List.nodup_finRange n).imp (fun h e => h (inj e)))
  have hit := nd.length_le_of_subset (l₂ := List.finRange c) (fun {x} _ => List.mem_finRange x)
  simpa using hit

/-- Each receiver has one free least literal. All remaining occurrences are charged
to pairwise distinct joins. This form accepts any list of distinct occurrences. -/
theorem boundAll {c n r : Nat} (b : Bank c) (wire : Fin r → Nat)
    (receiver : Fin n → Fin r) (lit : Fin n → Nat)
    (build : ∀ j, Built b (wire (receiver j)))
    (member : ∀ j, b.has (wire (receiver j)) (lit j))
    (unique : ∀ i j, receiver i = receiver j → lit i = lit j → i = j)
    (linear : ∀ i j : Fin r, i ≠ j → ∀ x y,
      b.has (wire i) x → b.has (wire j) x →
      b.has (wire i) y → b.has (wire j) y → x = y) : n ≤ r+c := by
  classical
  let base (i : Fin n) := b.first (wire (receiver i))
  have ex (j : Fin n) (h : lit j ≠ base j) :=
    chargeExists b (build j) (member j)
      (show base j < lit j by have hh : base j ≤ lit j := b.firstLe _ _ (member j); omega)
  let f (j : Fin n) : Fin (r+c) :=
    if he : lit j = base j then ⟨(receiver j).val,by have := (receiver j).isLt; omega⟩
    else ⟨r + (Classical.choose (ex j he)).val,by have := (Classical.choose (ex j he)).isLt; omega⟩
  have inj {i j : Fin n} (hh : f i = f j) : i = j := by
    have h := congrArg Fin.val hh
    by_cases hi : lit i = base i <;> by_cases hj : lit j = base j
    · simp only [f,dif_pos hi,dif_pos hj] at h
      have e : receiver i = receiver j := Fin.ext h
      exact unique i j e (hi.trans ((congrArg (fun z => b.first (wire z)) e).trans hj.symm))
    · simp only [f,dif_pos hi,dif_neg hj] at h
      have := (receiver i).isLt
      omega
    · simp only [f,dif_neg hi,dif_pos hj] at h
      have := (receiver j).isLt
      omega
    · simp only [f,dif_neg hi,dif_neg hj] at h
      have eq : Classical.choose (ex i hi) = Classical.choose (ex j hj) := Fin.ext (by omega)
      have ci := Classical.choose_spec (ex i hi)
      have cj := Classical.choose_spec (ex j hj)
      rw [eq] at ci
      have el := ci.label.symm.trans cj.label
      apply unique i j _ el
      apply Classical.byContradiction
      intro ne
      obtain ⟨z,hz,hm⟩ := ci.lower
      have e := linear _ _ ne (lit i) z (ci.sub _ ci.here) (cj.sub _ ci.here)
        (ci.sub _ hm) (cj.sub _ hm)
      omega
  have nd : ((List.finRange n).map f).Nodup :=
    List.pairwise_map.mpr ((List.nodup_finRange n).imp (fun h e => h (inj e)))
  have hit := nd.length_le_of_subset (l₂ := List.finRange (r+c)) (fun {x} _ => List.mem_finRange x)
  simpa using hit

end Research.Graph9822.UnionCharge
#print axioms Research.Graph9822.UnionCharge.bound

-- And9822Clauses.lean SHA-256 1e9a9181f15dc52992705f61e24cd543b524aa9a141db7a6d48b5b911a3a57f9
namespace Research.Graph9822.Clauses

def fires {V A : Type} (uses : V → A → Bool → Prop) (v : V) (p : A → Bool) : Prop :=
  ∃ i, uses v i (p i)

theorem consistent {V A : Type} (uses : V → A → Bool → Prop) {v : V}
    (proper : ∃ p, ¬ fires uses v p) (i : A) : ¬ (uses v i true ∧ uses v i false) := by
  obtain ⟨p,hp⟩ := proper
  rintro ⟨ht,hf⟩
  apply hp
  refine ⟨i,?_⟩
  cases h : p i <;> assumption

theorem cross_covers {V A : Type} (uses : V → A → Bool → Prop) {u v : V} {i : A} {b : Bool}
    (hu : uses u i b) (hv : uses v i (!b)) (p : A → Bool) :
    fires uses u p ∨ fires uses v p := by
  cases b <;> cases h : p i
  · exact Or.inl ⟨i,by simpa [h] using hu⟩
  · exact Or.inr ⟨i,by simpa [h] using hv⟩
  · exact Or.inr ⟨i,by simpa [h] using hv⟩
  · exact Or.inl ⟨i,by simpa [h] using hu⟩

theorem cover_crosses {V A : Type} (uses : V → A → Bool → Prop) {u v : V}
    (pu : ∃ p, ¬ fires uses u p) (pv : ∃ p, ¬ fires uses v p)
    (cover : ∀ p, fires uses u p ∨ fires uses v p) :
    ∃ i b, uses u i b ∧ uses v i (!b) := by
  classical
  apply Classical.byContradiction
  intro no
  let p := fun i => decide (¬ (uses u i true ∨ uses v i true))
  have hf (i : A) : ¬ ((uses u i true ∨ uses v i true) ∧ (uses u i false ∨ uses v i false)) := by
    rintro ⟨hu | hv,hu' | hv'⟩
    · exact consistent uses pu i ⟨hu,hu'⟩
    · exact no ⟨i,true,hu,hv'⟩
    · exact no ⟨i,false,hu',hv⟩
    · exact consistent uses pv i ⟨hv,hv'⟩
  have avoid (i : A) : ¬ (uses u i (p i) ∨ uses v i (p i)) := by
    by_cases h : uses u i true ∨ uses v i true
    · have e : p i = false := decide_eq_false (fun hn => hn h)
      rw [e]
      exact fun hf' => hf i ⟨h,hf'⟩
    · have e : p i = true := decide_eq_true h
      rw [e]
      exact h
  rcases cover p with ⟨i,hu⟩ | ⟨i,hv⟩
  · exact avoid i (Or.inl hu)
  · exact avoid i (Or.inr hv)

end Research.Graph9822.Clauses
#print axioms Research.Graph9822.Clauses.cover_crosses

-- And9822LiteralCode.lean SHA-256 75de6ffa8087eba7e20d8a2bcc10b59fce8b056c093d5e401fed8909b60e7265
namespace Research.Graph9822.StarData
def numLit (a : Fin 6) (b : Bool) := 2*a.val+b.toNat

theorem numLit_inj {a d : Fin 6} {b s : Bool} (h : numLit a b = numLit d s) :
    a=d ∧ b=s := by
  cases b <;> cases s <;> simp only [numLit,Bool.toNat_true,Bool.toNat_false] at h <;>
    first | exact ⟨Fin.ext (by omega),rfl⟩ | omega

end Research.Graph9822.StarData

-- And9822GraphBundle
set_option maxRecDepth 100000
set_option maxHeartbeats 0

-- And9822StarData.lean SHA-256 10df4f75a1f07d91d4ba911c47b56eb9cc0ac22cfb992684336385a9ab1537ee

namespace Research.Graph9822.StarData
open FourSaturation

def adj (u v : Fin 10) : Bool := edges.contains (u.val,v.val) || edges.contains (v.val,u.val)

theorem unique_common_neighbors : ∀ a b : Fin 10, a ≠ b →
    ((List.finRange 10).filter (fun c => adj a c && adj b c)).length ≤ 1 := by decide +kernel

def covers (m : Nat) : Bool := edges.all fun e => m.testBit e.1 || m.testBit e.2

def cardinal (m : Nat) : Nat := ((List.range 10).filter (fun j => m.testBit j)).length

theorem min_cover : ∀ m : Fin 1024, covers m.val = true → 6 ≤ cardinal m.val := by
  decide +kernel

theorem edge_count : edges.length = 13 ∧ edges.Nodup := by decide +kernel

end Research.Graph9822.StarData

-- And9822StarCover.lean SHA-256 6b496008614358c7bd4e7c265b13f7b4c033fbd2ccb2ca97f434898489bed9b1
namespace Research.Graph9822.StarData

def ends (e : Fin 13) : Fin 10 × Fin 10 :=
  (#[(1,2),(3,4),(0,4),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(6,9),(6,8),(5,8)] :
    Array (Fin 10 × Fin 10))[e.val]'(by simpa using e.isLt)

def encode (s : List (Fin 10)) : BitVec 10 :=
  (BitVec.ofBoolListLE (List.ofFn (fun x : Fin 10 => s.contains x))).cast List.length_ofFn

theorem encode_bit (s : List (Fin 10)) (x : Fin 10) :
    (encode s).getLsbD x.val = s.contains x := by
  simp only [encode,BitVec.getLsbD_cast,BitVec.getLsbD_ofBoolListLE,List.getD_eq_getElem?_getD,List.getElem?_ofFn]
  simp [x.isLt]

def selected (s : BitVec 10) := (List.finRange 10).filter (fun x => s.getLsbD x.val)

theorem six_needed : ∀ m : Fin 1024,
    (∀ e : Fin 13, m.val.testBit (ends e).1.val || m.val.testBit (ends e).2.val) →
    6 ≤ (selected (BitVec.ofNat 10 m.val)).length := by decide +kernel

theorem coverCost (s : List (Fin 10))
    (hit : ∀ e, (ends e).1 ∈ s ∨ (ends e).2 ∈ s) : 6 ≤ s.length := by
  let bv := encode s
  have hmask : ∀ e : Fin 13, bv.toNat.testBit (ends e).1.val || bv.toNat.testBit (ends e).2.val := by
    intro e
    change (bv.getLsbD (ends e).1.val || bv.getLsbD (ends e).2.val) = true
    change ((encode s).getLsbD (ends e).1.val || (encode s).getLsbD (ends e).2.val) = true
    rw [encode_bit,encode_bit]
    simpa using hit e
  have lower := six_needed bv.toFin hmask
  have hnd : (selected bv).Nodup := (List.nodup_finRange 10).filter _
  have hsub : selected bv ⊆ s := by
    intro x hx
    have hm := (List.mem_filter.mp hx).2
    change (encode s).getLsbD x.val = true at hm
    rw [encode_bit] at hm
    simpa using hm
  have upper := hnd.length_le_of_subset hsub
  have lo : 6 ≤ (selected bv).length := by simpa using lower
  omega

theorem essential_edge (c : Fin 6 → Fin 10) (i : Fin 6) :
    ∃ e : Fin 13, ∀ j : Fin 6, j ≠ i → c j ≠ (ends e).1 ∧ c j ≠ (ends e).2 := by
  classical
  let others := ((List.finRange 6).erase i).map c
  apply Classical.byContradiction
  intro hn
  have hit (e : Fin 13) : (ends e).1 ∈ others ∨ (ends e).2 ∈ others := by
    apply Classical.byContradiction
    intro hmiss
    apply hn
    refine ⟨e,fun j hji => ?_⟩
    have memj : j ∈ (List.finRange 6).erase i :=
      (List.mem_erase_of_ne hji).mpr (List.mem_finRange j)
    have hc : c j ∈ others := List.mem_map.mpr ⟨j,memj,rfl⟩
    exact ⟨fun eq => hmiss (Or.inl (eq ▸ hc)),fun eq => hmiss (Or.inr (eq ▸ hc))⟩
  have lb := coverCost others hit
  have length : others.length = 5 := by simp [others,List.length_erase_of_mem (List.mem_finRange i)]
  omega

end Research.Graph9822.StarData

-- And9822StarIntersection.lean SHA-256 7de71979461e27ae9b89cf8591bc33d8bee8fa94bdf62cb2c0baaf4dc840af0f
namespace Research.Graph9822.StarData

theorem no_square : ∀ u v a c : Fin 10, u ≠ v →
    adj u a = true → adj v a = true → adj u c = true → adj v c = true → a = c := by
  decide +kernel

/-- The premises name the six distinct centers and state that a sign occurring in
two receivers has the opposite sign at its center. -/
theorem shared_literal_unique
    (uses : Fin 10 → Fin 6 → Bool → Prop) (center : Fin 6 → Fin 10)
    (centerInj : ∀ i j, center i = center j → i = j)
    (proper : ∀ v i, ¬ (uses v i true ∧ uses v i false))
    (crosses : ∀ v w i b, uses v i b → uses w i (!b) → adj v w = true)
    (centerSign : ∀ u v i b, u ≠ v → uses u i b → uses v i b → uses (center i) i (!b))
    {u v : Fin 10} (diff : u ≠ v) {i j : Fin 6} {b d : Bool}
    (hui : uses u i b) (hvi : uses v i b) (huj : uses u j d) (hvj : uses v j d) :
    i = j ∧ b = d := by
  have hci := centerSign u v i b diff hui hvi
  have hcj := centerSign u v j d diff huj hvj
  have h := no_square u v (center i) (center j) diff
    (crosses _ _ _ _ hui hci) (crosses _ _ _ _ hvi hci)
    (crosses _ _ _ _ huj hcj) (crosses _ _ _ _ hvj hcj)
  have he := centerInj i j h
  subst j
  refine ⟨rfl,?_⟩
  cases b <;> cases d
  · rfl
  · exact False.elim (proper u i ⟨huj,hui⟩)
  · exact False.elim (proper u i ⟨hui,huj⟩)
  · rfl

end Research.Graph9822.StarData
#print axioms Research.Graph9822.StarData.shared_literal_unique

-- And9822StarCenters.lean SHA-256 993951349aae5c60f519b62f325e4aec6593da2541bb044482c7cae723e84d10
namespace Research.Graph9822.StarData
abbrev Vertex := Fin 10
abbrev Axis := Fin 6
def Centers (uses : Vertex → Axis → Bool → Prop) (c : Axis → Vertex) : Prop :=
  ∀ u v i b, uses u i b → uses v i (!b) → c i = u ∨ c i = v

theorem choose_centers (uses : Vertex → Axis → Bool → Prop)
    (crosses : ∀ u v i b, uses u i b → uses v i (!b) → adj u v = true) :
    ∃ c, Centers uses c := by
  classical
  have one (i : Axis) : ∃ z : Vertex, ∀ u v, uses u i true → uses v i false → z=u ∨ z=v := by
    by_cases double : ∃ u v, u ≠ v ∧ uses u i true ∧ uses v i true
    · obtain ⟨a,b,hab,ha,hb⟩ := double
      by_cases existsD : ∃ v, uses v i false
      · obtain ⟨z,hz⟩ := existsD
        refine ⟨z,fun u v _ hv => Or.inr ?_⟩
        exact no_square a b z v hab (crosses a z i true ha hz) (crosses b z i true hb hz)
          (crosses a v i true ha hv) (crosses b v i true hb hv)
      · exact ⟨0,fun _ v _ hv => False.elim (existsD ⟨v,hv⟩)⟩
    · by_cases existsA : ∃ u, uses u i true
      · obtain ⟨z,hz⟩ := existsA
        refine ⟨z,fun u _ hu _ => Or.inl ?_⟩
        exact Classical.byContradiction (fun h => double ⟨z,u,h,hz,hu⟩)
      · exact ⟨0,fun u _ hu _ => False.elim (existsA ⟨u,hu⟩)⟩
  let c := fun i => Classical.choose (one i)
  refine ⟨c,?_⟩
  intro u v i b hu hv
  cases b with
  | true => exact Classical.choose_spec (one i) u v hu hv
  | false => exact (Classical.choose_spec (one i) v u hv hu).symm

theorem essential_axis (uses : Vertex → Axis → Bool → Prop) (c : Axis → Vertex)
    (hc : Centers uses c)
    (realize : ∀ e : Fin 13, ∃ i b, uses (ends e).1 i b ∧ uses (ends e).2 i (!b))
    (i : Axis) : ∃ e b, (c i = (ends e).1 ∨ c i = (ends e).2) ∧
    uses (ends e).1 i b ∧ uses (ends e).2 i (!b) ∧
    ∀ j : Axis, j ≠ i → c j ≠ (ends e).1 ∧ c j ≠ (ends e).2 := by
  obtain ⟨e,essential⟩ := essential_edge c i
  obtain ⟨k,b,hl,hr⟩ := realize e
  have edge := hc _ _ _ _ hl hr
  have forced : k = i := Classical.byContradiction (fun ne =>
    edge.elim (essential k ne).1 (essential k ne).2)
  subst k
  exact ⟨e,b,edge,hl,hr,essential⟩

theorem centers_inj (uses : Vertex → Axis → Bool → Prop) (c : Axis → Vertex)
    (hc : Centers uses c)
    (realize : ∀ e : Fin 13, ∃ i b, uses (ends e).1 i b ∧ uses (ends e).2 i (!b))
    {i j : Axis} (he : c i = c j) : i = j := by
  apply Classical.byContradiction
  intro diff
  obtain ⟨e,_,edge,_,_,essential⟩ := essential_axis uses c hc realize i
  rw [he] at edge
  exact edge.elim (essential j (Ne.symm diff)).1 (essential j (Ne.symm diff)).2

theorem opposite_center (uses : Vertex → Axis → Bool → Prop) (c : Axis → Vertex)
    (hc : Centers uses c)
    (realize : ∀ e : Fin 13, ∃ i b, uses (ends e).1 i b ∧ uses (ends e).2 i (!b))
    {u v : Vertex} {i : Axis} {s : Bool} (diff : u ≠ v)
    (hu : uses u i s) (hv : uses v i s) : uses (c i) i (!s) := by
  obtain ⟨e,b,_,hl,hr,_⟩ := essential_axis uses c hc realize i
  have opp : ∃ z, uses z i (!s) := by
    cases s <;> cases b
    · exact ⟨_,hr⟩
    · exact ⟨_,hl⟩
    · exact ⟨_,hl⟩
    · exact ⟨_,hr⟩
  obtain ⟨z,hz⟩ := opp
  have A := hc _ _ _ _ hu hz
  have B := hc _ _ _ _ hv hz
  by_cases h : c i = z
  · simpa [h] using hz
  · exact False.elim (diff ((A.resolve_right h).symm.trans (B.resolve_right h)))

end Research.Graph9822.StarData

-- And9822StarTickets.lean SHA-256 12b27f2b62da1dbd45c58dc6ef5211b0fceaf6cb7f274dbd7b85d4e4f750c706
namespace Research.Graph9822.StarData
structure Token where
  v : Vertex
  a : Axis
  b : Bool

def matchesEdge (e : Fin 13) (u v : Vertex) : Prop :=
  ((ends e).1 = u ∧ (ends e).2 = v) ∨ ((ends e).2 = u ∧ (ends e).1 = v)

theorem ends_ne : ∀ e : Fin 13, (ends e).1 ≠ (ends e).2 := by decide +kernel

theorem edge_unique (e f : Fin 13) (u v : Vertex) (he : matchesEdge e u v) (hf : matchesEdge f u v) :
    e = f := by
  have canon : ∀ e f : Fin 13,
      (ends e = ends f ∨ (ends e).1 = (ends f).2 ∧ (ends e).2 = (ends f).1) → e=f := by decide +kernel
  apply canon
  rcases he with ⟨a,b⟩ | ⟨a,b⟩ <;> rcases hf with ⟨c,d⟩ | ⟨c,d⟩
  · exact Or.inl (Prod.ext (a.trans c.symm) (b.trans d.symm))
  · exact Or.inr ⟨a.trans c.symm,b.trans d.symm⟩
  · exact Or.inr ⟨b.trans d.symm,a.trans c.symm⟩
  · exact Or.inl (Prod.ext (b.trans d.symm) (a.trans c.symm))

inductive Ticket where
  | axis (i : Axis)
  | edge (e : Fin 13)

def ticket (i : Fin 19) : Ticket :=
  if h : i.val < 6 then .axis ⟨i.val,h⟩ else .edge ⟨i.val-6,by have := i.isLt; omega⟩

def ticketNum : Ticket → Nat
  | .axis i => i.val
  | .edge e => e.val + 6

theorem ticketNum_id (i : Fin 19) : ticketNum (ticket i) = i.val := by
  unfold ticket
  split <;> simp [ticketNum] <;> omega

theorem tokens (uses : Vertex → Axis → Bool → Prop) (c : Axis → Vertex)
    (hc : Centers uses c)
    (realize : ∀ e : Fin 13, ∃ i b, uses (ends e).1 i b ∧ uses (ends e).2 i (!b)) :
    ∃ t : Fin 19 → Token, (∀ j, uses (t j).v (t j).a (t j).b) ∧
      ∀ i j, (t i).v = (t j).v → (t i).a = (t j).a → i = j := by
  classical
  have rootEx (i : Axis) : ∃ b, uses (c i) i b := by
    obtain ⟨e,b,edge,hl,hr,_⟩ := essential_axis uses c hc realize i
    rcases edge with h | h
    · exact ⟨b,by simpa [h] using hl⟩
    · exact ⟨!b,by simpa [h] using hr⟩
  have leafEx (e : Fin 13) : ∃ t : Token, uses t.v t.a t.b ∧ matchesEdge e (c t.a) t.v ∧ t.v ≠ c t.a := by
    obtain ⟨a,b,hl,hr⟩ := realize e
    rcases hc _ _ _ _ hl hr with h | h
    · exact ⟨⟨(ends e).2,a,!b⟩,hr,Or.inl ⟨h.symm,rfl⟩,by simpa [h] using (ends_ne e).symm⟩
    · exact ⟨⟨(ends e).1,a,b⟩,hl,Or.inr ⟨h.symm,rfl⟩,by simpa [h] using ends_ne e⟩
  let leaf (e : Fin 13) := Classical.choose (leafEx e)
  have leafSpec (e : Fin 13) := Classical.choose_spec (leafEx e)
  let tok : Ticket → Token
    | .axis a => ⟨c a,a,Classical.choose (rootEx a)⟩
    | .edge e => leaf e
  have mem (z : Ticket) : uses (tok z).v (tok z).a (tok z).b := by
    cases z with
    | axis a => exact Classical.choose_spec (rootEx a)
    | edge e => exact (leafSpec e).1
  have inj (x y : Ticket) (ev : (tok x).v = (tok y).v) (ea : (tok x).a = (tok y).a) : x = y := by
    cases x with
    | axis i =>
      cases y with
      | axis j => exact congrArg Ticket.axis ea
      | edge e =>
        change c i = (leaf e).v at ev
        change i = (leaf e).a at ea
        exact False.elim ((leafSpec e).2.2 (ev.symm.trans (congrArg c ea)))
    | edge e =>
      cases y with
      | axis j =>
        change (leaf e).v = c j at ev
        change (leaf e).a = j at ea
        exact False.elim ((leafSpec e).2.2 (ev.trans (congrArg c ea.symm)))
      | edge f =>
        change (leaf e).a = (leaf f).a at ea
        change (leaf e).v = (leaf f).v at ev
        have hm : matchesEdge e (c (leaf e).a) (leaf e).v := (leafSpec e).2.1
        rw [ea,ev] at hm
        exact congrArg Ticket.edge (edge_unique e f _ _ hm (leafSpec f).2.1)
  refine ⟨fun i => tok (ticket i),fun i => mem _,?_⟩
  intro i j hv ha
  exact Fin.ext (by simpa [ticketNum_id] using congrArg ticketNum (inj _ _ hv ha))

end Research.Graph9822.StarData

-- And9822EndBundle
set_option maxRecDepth 100000
set_option maxHeartbeats 0

-- And9822AllFull.lean SHA-256 c472137e2251c078c7011fe631703f5a1c44d9adb8c9a671a9fa92394317c1bc
namespace Research.Graph9822.StarData
open UnionCharge

/-- An all-full bank uses the twelve independent signed coordinate literals. Pair
coverage gives the two crossing implications from the full-cube representation. -/
theorem all_full_cost {cost : Nat} (bank : Bank cost) (wire : Vertex → Nat)
    (build : ∀ v, Built bank (wire v))
    (typed : ∀ v l, bank.has (wire v) l → ∃ a b, l = numLit a b)
    (proper : ∀ v a, ¬ (bank.has (wire v) (numLit a true) ∧ bank.has (wire v) (numLit a false)))
    (crosses : ∀ u v a b, bank.has (wire u) (numLit a b) →
      bank.has (wire v) (numLit a (!b)) → adj u v = true)
    (realize : ∀ e : Fin 13, ∃ i b, bank.has (wire (ends e).1) (numLit i b) ∧
      bank.has (wire (ends e).2) (numLit i (!b))) : 9 ≤ cost := by
  let uses := fun v a b => bank.has (wire v) (numLit a b)
  obtain ⟨c,hc⟩ := choose_centers uses crosses
  have ci : ∀ i j, c i = c j → i = j := fun _ _ h => centers_inj uses c hc realize h
  have centerSign := fun u v i b => @opposite_center uses c hc realize u v i b
  obtain ⟨t,mem,inj⟩ := tokens uses c hc realize
  have budget := boundAll bank wire (fun j => (t j).v) (fun j => numLit (t j).a (t j).b)
    (fun j => build (t j).v) mem
    (fun i j hv hl => inj i j hv (numLit_inj hl).1)
    (fun i j hij x y hix hjx hiy hjy => by
      obtain ⟨a,b,rfl⟩ := typed i x hix
      obtain ⟨d,s,rfl⟩ := typed i y hiy
      obtain ⟨he,hs⟩ := shared_literal_unique uses c ci proper crosses centerSign hij hix hjx hiy hjy
      rw [he,hs])
  omega

theorem all_full_exclusion {cost : Nat} (bank : Bank cost) (wire : Vertex → Nat)
    (build : ∀ v, Built bank (wire v))
    (typed : ∀ v l, bank.has (wire v) l → ∃ a b, l = numLit a b)
    (proper : ∀ v, ∃ p : Axis → Bool, ¬ Clauses.fires
      (fun w a b => bank.has (wire w) (numLit a b)) v p)
    (represents : ∀ u v, adj u v = true ↔ ∀ p : Axis → Bool,
      Clauses.fires (fun w a b => bank.has (wire w) (numLit a b)) u p ∨
      Clauses.fires (fun w a b => bank.has (wire w) (numLit a b)) v p)
    (budget : cost ≤ 8) : False := by
  let uses := fun v a b => bank.has (wire v) (numLit a b)
  have edges_adj : ∀ e : Fin 13, adj (ends e).1 (ends e).2 = true := by decide +kernel
  have h := all_full_cost bank wire build typed (fun v a => Clauses.consistent uses (proper v) a)
    (fun u v _ _ hu hv => (represents u v).mpr (Clauses.cross_covers uses hu hv))
    (fun e => Clauses.cover_crosses uses (proper _) (proper _) ((represents _ _).mp (edges_adj e)))
  omega

end Research.Graph9822.StarData
#print axioms Research.Graph9822.StarData.all_full_cost
