import SixD3GridUnits9822
import SixD3GridDataA0679822
namespace Research.Graph9822.ThreeDirect.A067
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit0 : ∀ a, Known a g 179 → Known a g 180 :=
  singleKnown g 179 (unpack 28 [0x10150000026a05001be055013e047]) (by decide +kernel)
private theorem unit1 : ∀ a, Known a g 180 → Known a g 181 :=
  singleKnown g 180 (unpack 28 [0x1025c0000275d99028ddfb0281dc302cdd7b018607b017206b016205d013e047023a0a4010a09d029de4302c865302a5e9d014a07f014606f0142061000604302406f2023c6e50261ccf0265d5502bc33302b832502b41f302b01e502ac0b302a80a502582920254284024c152024814401f001201ec00402517f4024559801e8784]) (by decide +kernel)
private theorem unit2 : ∀ a, Known a g 181 → Known a g 182 :=
  singleKnown g 181 (unpack 28 [0x10268000001e05500060510002047]) (by decide +kernel)
private theorem unit3 : ∀ a, Known a g 182 → Known a g 183 :=
  singleKnown g 182 (unpack 28 [0x100ec000022e08801f54de022149700c20770239539021945f001e04301be0a501ba09101b607f01b206f011a09d009a06701f936b01fd3f502bc33302b41f302ac0b30258292024c15201f001202517f4024559801e8784]) (by decide +kernel)
private theorem unit4 : ∀ a, Known a g 183 → Known a g 184 :=
  singleKnown g 183 (unpack 28 [0x100cc00002a20a400be0a1025de9c0295e4300ba08d0275d9900b605d00ca09100c606100ae0470261ccf0265d5502b832502b01e502a80a50254284024814401ec00402517f4024559801e8784]) (by decide +kernel)
private theorem unit5 : ∀ a, Known a g 184 → Known a g 185 :=
  singleKnown g 184 (unpack 28 [0x1007c00002a20a4025de9c0295e43007a091028ddfb007607f0281dc3007206f006e0a1006a08d006607b006206b005e0470261ccf0265d5502b832502b01e502a80a50254284024814401ec00402517f4024559801e8784]) (by decide +kernel)
private theorem unit6 : ∀ a, Known a g 185 → Known a g 186 :=
  singleKnown g 185 (unpack 28 [0x1010000002a20a4025de9c0295e4300fe091028ddfb00fa07f0281dc300f606f00ea0a100e608d00e207b00de06b0275d9900da05d00f206100d20470261ccf0265d5502b832502b01e502a80a50254284024814401ec00402517f4024559801e8784]) (by decide +kernel)
private theorem unit7 : ∀ a, Known a g 186 → Known a g 187 :=
  singleKnown g 186 (unpack 28 [0x1013c000023a0a401f5538022d4df013a0910221497013607f021945f013206f020d435012e0610201417012a055010609d00d208900ae0770082067005e059003604d000204301f936b01fd3f502bc33302b41f302ac0b30258292024c15201f001202517f4024559801e8784]) (by decide +kernel)
private theorem unit8 : ∀ a, Known a g 187 → Known a g 188 :=
  singleKnown g 187 (unpack 28 [0x101a400002a20a0025de9c0295e43019608d0275d99015a05d022207e02de0770291dfb02245a502ea0470261ccf0265d5502b832502b01e502a80a50254284024814401ec00402517f4024559801e8784]) (by decide +kernel)
private theorem unit9 : ∀ a, Known a g 188 → Known a g 189 :=
  singleKnown g 188 (unpack 28 [0x102e0000020e0580279d99021046502b832502b01e50254284024814402517f40245598]) (by decide +kernel)
private theorem unit10 : ∀ a, Known a g 189 → Known a g 190 :=
  singleKnown g 189 (unpack 28 [0x102ec00001f5496022d4df02f143502e608901f936b01fd3f502bc33302b41f302ac0b30258292024c15201f001202517f4024559801e8784]) (by decide +kernel)
private theorem unit11 : ∀ a, Known a g 190 → Known a g 191 :=
  singleKnown g 190 (unpack 28 [0x10230000029864401f54de025de420221497028ddfb01de07f02a1e9d01aa0a1018207b00ca07702f609002f143502ea0470261ccf01f936b01fd3f50265d5502bc33302b832502b41f302b01e502ac0b302a80a502582920254284024c152024814401f001201ec00402517f4024559801e8784]) (by decide +kernel)
theorem up0 : ∀ a, Known a g 179 → Known a g 191 := by
  intro a h
  apply unit11 a
  apply unit10 a
  apply unit9 a
  apply unit8 a
  apply unit7 a
  apply unit6 a
  apply unit5 a
  apply unit4 a
  apply unit3 a
  apply unit2 a
  apply unit1 a
  apply unit0 a
  exact h
end Research.Graph9822.ThreeDirect.A067
