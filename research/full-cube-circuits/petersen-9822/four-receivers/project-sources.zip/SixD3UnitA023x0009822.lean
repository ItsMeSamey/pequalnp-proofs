import SixD3GridUnits9822
import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit0 : ∀ a, Known a g 2558 → Known a g 2559 :=
  singleKnown g 2558 (unpack 28 [0x11fa80000c7db401fadb791fb1bf91fa5b231f9db1f1fb5b851fb9c050d25be70ccdac10d69beb0df9c130d11b670d55b6b0ca9a9f1f95a851f99a911fa1b3d097c64509785050c85a770c81a730cf5afd258432525681e525540a50754284073014405fc0040750e94072cc3805f8784]) (by decide +kernel)
private theorem unit1 : ∀ a, Known a g 2559 → Known a g 2560 :=
  singleKnown g 2559 (unpack 28 [0x11fcc00007fd5121fbd55d1f955031ebd5391e914df1e654971e3945f1db952b1d9d4d11d894891d09409090954308b146908093751fdd56d1f254e91f0d4a11dd94171d354511cb93c51c6d3b11c1139f1bc138f0c883c4080536b080135d08413f5258c331258432525701f125580b1075c2900754284073c15006000100750e94072cc3805f8784]) (by decide +kernel)
private theorem unit2 : ∀ a, Known a g 2560 → Known a g 2561 :=
  singleKnown g 2560 (unpack 28 [0x11ef00000c7dbea1ef5c451ee9be71ee5b1f1ef9b791efdbf91ee1ad51f01c530c89a850d41b2308b03c51f09c6d1eedc410d11b670d55b6b0ca9a9f1f05c131eddac108b45050c85a770c81a730cf5afd258432525681e525540a50754284073014405fc0040750e94072cc3805f8784]) (by decide +kernel)
private theorem unit3 : ∀ a, Known a g 2561 → Known a g 2562 :=
  singleKnown g 2561 (unpack 28 [0x11f8000007fd4f41f594751f314e91f054691eb54df1e6145f1e314351e014171db14d11d2d4271d154091bb138109815030e046570e005171d814511cb13b11c0938f1b71375080536b080135d08413f5258c33125701f125600b725580b1075c290073c150060801606000100750e94072cc3805f8784]) (by decide +kernel)
private theorem unit4 : ∀ a, Known a g 2562 → Known a g 2563 :=
  singleKnown g 2562 (unpack 28 [0x11f7400007fd4f41f494751e994df1e0d4351dc152b1da54d11d214271d0d4091b81381097950308b5469081d38f1fc555d1f8d54f1f395431f294e91ec55391e4145f1ddd4171d3d4511cc13c51c753b11b313750ca8504080536b080135d08413f5258c331258432525701f125580b1075c2900754284073c15006000100750e94072cc3805f8784]) (by decide +kernel)
private theorem unit5 : ∀ a, Known a g 2563 → Known a g 2564 :=
  singleKnown g 2563 (unpack 28 [0x11f6000007fd4ac1f4d4751edd4691ea14df1e714971e154351da94d11d914891d254271d114091b8938109b1513097d50309414f508ed4e908293b11f154a11e4545f1de54171d414511c1d39f1bc938f1b393750ccc644080536b080135d08413f5258c331258432525701f125580b1075c2900754284073c15006000100750e94072cc3805f8784]) (by decide +kernel)
private theorem unit6 : ∀ a, Known a g 2564 → Known a g 2565 :=
  singleKnown g 2564 (unpack 28 [0x1172c000076d2e0156d23f14d1207143d1dd127d19d1119113]) (by decide +kernel)
private theorem unit7 : ∀ a, Known a g 2565 → Known a g 2566 :=
  singleKnown g 2565 (unpack 28 [0x115d4000076d23e14891dd137919d121d11317812e1]) (by decide +kernel)
private theorem unit8 : ∀ a, Known a g 2566 → Known a g 2567 :=
  singleKnown g 2566 (unpack 28 [0x1076c00017292e1156523f14351dd11111130e3dd0a2815ed92811d310e71ccf0e41cbd0e45ccb0f55d55258432525681e525540a50754284073014405fc0040750e94072cc3805f8784]) (by decide +kernel)
private theorem unit9 : ∀ a, Known a g 2567 → Known a g 2568 :=
  singleKnown g 2567 (unpack 28 [0x104e0000079206001b205900c6043]) (by decide +kernel)
private theorem unit10 : ∀ a, Known a g 2568 → Known a g 2569 :=
  singleKnown g 2568 (unpack 28 [0x103f000007920600176059008a043]) (by decide +kernel)
private theorem unit11 : ∀ a, Known a g 2569 → Known a g 2570 :=
  singleKnown g 2569 (unpack 28 [0x107cc000041a09102be089008e043]) (by decide +kernel)
theorem up0 : ∀ a, Known a g 2558 → Known a g 2570 := by
  intro a h
  apply unit11 a
  apply unit10 a
  apply unit9 a
  apply unit8 a
  apply unit7 a
  apply unit6 a
  apply unit5 a
  apply unit4 a
  apply unit3 a
  apply unit2 a
  apply unit1 a
  apply unit0 a
  exact h
end Research.Graph9822.ThreeDirect.A023
