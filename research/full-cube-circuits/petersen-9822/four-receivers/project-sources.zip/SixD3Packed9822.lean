import SixD3Check9822
namespace Research.Graph9822.ThreeDirect.Packed
open Research.Graph9822.TwoDirect (Arm rooms)
open PEqualNP.Library.LRAT
def domain : Array Arm := (((List.range 12).map (fun a => [a])) ++
  ((List.range 12).flatMap (fun b => (List.range b).map (fun a => [a,b]))) ++
  ((List.range 12).flatMap (fun c => (List.range c).flatMap (fun b => (List.range b).map (fun a => [a,b,c]))))).toArray
def tag : Arm → Nat
  | [a] => a
  | [a,b] => 12+a+b*(b-1)/2
  | [a,b,c] => 78+a+b*(b-1)/2+c*(c-1)*(c-2)/6
  | _ => 299
def arm (i : Nat) := domain[i]?.getD []
def ix (m : Nat) := if m<1024 then rooms.idxOf m else 16+(m-1024)
def obsAt (n : Nat) := if n<16 then rooms[n]?.getD 0 else 1024+(n-16)
def code : Atom → Nat
  | .fixed b => if b then 1 else 0
  | .ray k m => 2+80*k+ix m
  | .raw v t => 962+300*v+tag t
  | .origin j o => 3962+24*j+o
  | .helperSel t => 4106+tag t
  | .helperBit m => 4406+ix m
  | .ordinary v => 4486+v
  | .wordRaw v w => 4496+64*v+w
def uncode (n : Nat) : Atom :=
  if n<2 then .fixed (n==1) else if n<962 then .ray ((n-2)/80) (obsAt ((n-2)%80))
  else if n<3962 then .raw ((n-962)/300) (arm ((n-962)%300))
  else if n<4106 then .origin ((n-3962)/24) ((n-3962)%24)
  else if n<4406 then .helperSel (arm (n-4106))
  else if n<4486 then .helperBit (obsAt (n-4406))
  else if n<4496 then .ordinary (n-4486)
  else .wordRaw ((n-4496)/64) ((n-4496)%64)
def mode (s m : Nat) : Option Atom := if s=0 then none else some (.ray (s-1) m)
def basic (w : Nat) : Basic :=
  let p := (w >>> 4) % 512
  let q := (w >>> 13) % 512
  let r := (w >>> 22) % 512
  let s := (w >>> 31) % 16
  match w%16 with
  | 0 => .one p
  | 1 => .eqn r (obsAt q) (arm p) (mode s (obsAt q))
  | 2 => .edge (r/16) (r%16) (arm p) (arm q)
  | 3 => .disj p (obsAt q)
  | _ => .one 10
def shared (w : Nat) : SharedRule :=
  let p := (w >>> 4) % 512
  let q := (w >>> 13) % 512
  let r := (w >>> 22) % 512
  let s := (w >>> 31) % 16
  match w%16 with
  | 4 => .helperChoice
  | 5 => .helperUnique (arm p) (arm q)
  | 6 => .helperRow (arm p) (obsAt q) (mode s (obsAt q))
  | 7 => .linked q (arm p)
  | 8 => .ordinary q (arm p)
  | 9 => .nonneighbor q r (arm p)
  | 10 => .ordinaryPair p q r
  | 11 => .named p
  | 12 => .source p q (obsAt r) (mode s (obsAt r))
  | 13 => .wrong p q
  | 14 => .wordEdge p q r
  | _ => .base (basic w)
def num (l : Lit) := 2*code l.1+(if l.2 then 0 else 1)
def numeric (c : Clause) := (c.filter (fun l=> !void l)).map num
def roundtrip (c : Clause) := c.all (fun l => void l || (uncode (code l.1) == l.1))
theorem transport (e : Env) {c : Clause} (r : roundtrip c=true) (h : Sat e c) :
    ClauseSat (fun n=>e.val (uncode n)) (numeric c) := by
  obtain ⟨l,hl,eq⟩ := h
  have live := ThreeDirect.void_false e l eq
  have rt := List.all_eq_true.mp r l hl
  simp only [live,Bool.false_or,beq_iff_eq] at rt
  refine ⟨num l,List.mem_map.mpr ⟨l,List.mem_filter.mpr ⟨hl,by simp [live]⟩,rfl⟩,?_⟩
  rcases l with ⟨a,b⟩
  change e.val a=b at eq
  change uncode (code a)=a at rt
  have dv : (2*code a+1)/2 = code a := by omega
  cases b <;> simp [litVal,num,Nat.add_mod,dv,rt,eq]
def good (ok : Nat → Bool) (cl : Nat → Clause) (w : Nat) :=
  ok w && roundtrip (cl w)
theorem fromBlocks (e : Env) (ok : Nat → Bool) (cl : Nat → Clause) (cs : List Nat)
    (g : cs.all (good ok cl)=true) (laws : ∀ w, ok w=true → Sat e (cl w)) :
    FormulaSat (cs.map (fun w => numeric (cl w))) := by
  refine ⟨fun n=>e.val (uncode n),?_⟩
  intro c hc
  obtain ⟨w,hw,rfl⟩ := List.mem_map.mp hc
  have hh := List.all_eq_true.mp g w hw
  obtain ⟨leg,rt⟩ := Bool.and_eq_true_iff.mp hh
  exact transport e rt (laws w leg)
def bOK (w : Nat) := (basic w).ok
def bCl (d : Dir) (w : Nat) := (basic w).clause d false
def aOK (d : Dir) (w : Nat) := (shared w).ok d
def aCl (d : Dir) (w : Nat) := (shared w).clause d
theorem closeB (d : Dir) (cs : List Nat) (g : cs.all (good bOK (bCl d))=true)
    (bad : ¬ FormulaSat (cs.map (fun w=>numeric (bCl d w)))) : ¬ Nonempty (Rooms d false) := by
  rintro ⟨p⟩
  exact bad (fromBlocks (envOf p [] (fun _=>0)) _ _ _ g (fun w h=>(basic w).sound p _ _ h))
theorem closeA (d : Dir) (cs : List Nat) (g : cs.all (good (aOK d) (aCl d))=true)
    (bad : ¬ FormulaSat (cs.map (fun w=>numeric (aCl d w)))) : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact bad (fromBlocks (envOf p.toRooms p.helper p.origin) _ _ _ g (fun w h=>(shared w).sound p h))
end Research.Graph9822.ThreeDirect.Packed
