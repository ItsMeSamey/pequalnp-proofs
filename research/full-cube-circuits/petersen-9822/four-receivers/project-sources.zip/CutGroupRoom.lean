import CutGroupReceiver
import CutGroupOuter

-- OuterWordRoom9822.lean line 3

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles Research.Graph9822Resolution
open PEqualNP.Outside.L_meta_9822.OuterDirections

/-- Physical AND addresses, in reverse chronological order. -/
def switchAddrs : List DGate → Nat → List Nat
  | [], _ => []
  | g::gs, i => switchAddrs gs (i+1) ++ (if g.isAnd then [i] else [])

theorem switchAddrs_length (gs : List DGate) (i : Nat) :
    (switchAddrs gs i).length = gs.countP Gate.isAnd := by
  induction gs generalizing i with
  | nil => rfl
  | cons g gs ih => cases h : g.isAnd <;> simp [switchAddrs,h,ih,List.countP_cons,Nat.add_comm]

private theorem selector_congr (gs : List DGate) (i : Nat) (s t : DWire)
    (same : ∀ j ∈ switchAddrs gs i, s j = t j) (v : DWire) :
    resolve gs i s v = resolve gs i t v := by
  induction gs generalizing i v with
  | nil => rfl
  | cons g gs ih =>
    have tail : ∀ j ∈ switchAddrs gs (i+1), s j = t j :=
      fun j hj => same j (List.mem_append_left _ hj)
    have value : resolved g (s i) (v g.left) (v g.right) =
        resolved g (t i) (v g.left) (v g.right) := by
      cases h : g.isAnd with
      | false => simp [resolved,h]
      | true => rw [same i (by simp [switchAddrs,h])]
    simp only [resolve,value]
    apply ih _ tail

/-- Use the index in the physical address list as its selector coordinate. -/
noncomputable def switchAxis (l : List Nat) (cap : l.length ≤ 6) (j : Nat) : Axis :=
  if hj : ∃ k : Fin l.length, l[k.val] = j then
    ⟨hj.choose.val, lt_of_lt_of_le hj.choose.isLt cap⟩ else 0

private theorem covered_selector (l : List Nat) (cap : l.length ≤ 6) (s : DWire) :
    ∃ w : Word, ∀ j ∈ l, w (switchAxis l cap j) = s j := by
  classical
  refine ⟨fun k => s (l[k.val]?.getD 0), ?_⟩
  intro j hj
  obtain ⟨k,hk,eq⟩ := List.mem_iff_getElem.mp hj
  have hit : ∃ a : Fin l.length, l[a.val] = j := ⟨⟨k,hk⟩,eq⟩
  simp [switchAxis,hit,List.getElem?_eq_getElem,hit.choose_spec]

theorem physical_room_row (gs : List DGate) (n out : Nat) (cap : gs.countP Gate.isAnd ≤ 6)
    (original : Nat → Prop) (base : List Nat) (ext : Nat → List Nat)
    (reject : eval gs n (inputSet base) out = false)
    (accept : ∀ a, original a → a ∉ base → eval gs n (inputSet (a :: ext a)) out = true)
    (smaller : ∀ a, original a → ∀ j ∈ ext a, j ∈ base) :
    let axis := switchAxis (switchAddrs gs n) ((switchAddrs_length gs n).trans_le cap)
    ∃ w : Word, ∀ a, a < n → original a →
      (w ∈ collect ((back axis gs n (initial out)).q a) ↔ a ∉ base) := by
  dsimp only
  obtain ⟨s,hs⟩ := maximalOriginalWitness gs n out original base ext reject accept smaller
  obtain ⟨w,hw⟩ := covered_selector (switchAddrs gs n) ((switchAddrs_length gs n).trans_le cap) s
  refine ⟨w,?_⟩
  intro a ha orig
  rw [back_receiver_exact _ _ _ _ _ _ ha]
  change resolve gs n _ (atom a) out = true ↔ _
  rw [selector_congr gs n _ s hw]
  exact hs a orig


theorem signed_row_iff (gs : List DGate) (n out : Nat) (cap : gs.countP Gate.isAnd ≤ 6)
    (xs : List Nat) (bounded : ∀ a ∈ xs, a < n) :
    let axis := switchAxis (switchAddrs gs n) ((switchAddrs_length gs n).trans_le cap)
    eval gs n (inputSet xs) out = true ↔ ∀ w : Word,
      ∃ a ∈ xs, w ∈ collect ((back axis gs n (initial out)).q a) := by
  dsimp only
  rw [accepts_iff_reaches]
  constructor
  · intro yes w
    obtain ⟨a,ha,hits⟩ := List.any_eq_true.mp (yes (fun j => w
      (switchAxis (switchAddrs gs n) ((switchAddrs_length gs n).trans_le cap) j)))
    exact ⟨a,ha,(back_receiver_exact _ _ _ _ _ _ (bounded a ha)).2 hits⟩
  · intro cover s
    obtain ⟨w,hw⟩ := covered_selector (switchAddrs gs n) ((switchAddrs_length gs n).trans_le cap) s
    obtain ⟨a,ha,hits⟩ := cover w
    apply List.any_eq_true.mpr
    refine ⟨a,ha,?_⟩
    have h := (back_receiver_exact _ _ _ _ _ _ (bounded a ha)).1 hits
    change resolve gs n _ (atom a) out = true at h
    rw [selector_congr gs n _ s hw] at h
    exact h

end Research.Graph9822Profiles.OuterLive
-- OuterSixteenRoom9822.lean line 3

namespace Research.Graph9822Profiles.OuterLive
open Research.Graph9822Profiles Research.Graph9822Resolution
open PEqualNP.Outside.L_meta_9822.OuterDirections

theorem sixteen_room (gs : List DGate) (out : Nat) (cap : gs.countP Gate.isAnd ≤ 6)
    (guardBit : List Nat → Bool)
    (anti : ∀ xs a, guardBit (a::xs) = true → guardBit xs = true)
    (computes : ∀ xs, (∀ j ∈ xs, j<10) →
       eval gs 11 (inputSet (augment xs (guardBit xs))) out = onSet xs) :
    let axis := switchAxis (switchAddrs gs 11) ((switchAddrs_length gs 11).trans_le cap)
    ∃ rows : Fin 16 → Word, Function.Injective rows ∧ ∀ u (a : Fin 10),
      (rows u ∈ collect ((back axis gs 11 (initial out)).q a.val) ↔ a.val ∉ independentSets u) := by
  classical
  dsimp only
  let base (u : Fin 16) := augment (independentSets u) (guardBit (independentSets u))
  let ext (u : Fin 16) (a : Nat) := augment (independentSets u) (guardBit (a::independentSets u))
  have small (u : Fin 16) : ∀ j ∈ independentSets u, j<10 := by
    have h : ∀ v : Fin 16, (independentSets v).all (· < 10) = true := by decide +kernel
    simpa using List.all_eq_true.mp (h u)
  have row (u : Fin 16) := physical_room_row gs 11 out cap (· < 10) (base u) (ext u)
    ((computes _ (small u)).trans (reject_sets u)) (by
      intro a ha absent
      have ne : a ∉ independentSets u := fun hm => absent ((keepOriginal _ _ _ ha).2 hm)
      change eval gs 11 (inputSet (augment (a :: independentSets u) _)) out = true
      exact (computes _ (by simpa using And.intro ha (small u))).trans (maximal_sets u ⟨a,ha⟩ ne))
    (by
      intro a _ j hj
      cases hh : guardBit (a :: independentSets u) with
      | false =>
        have m : j ∈ independentSets u := by simpa [ext,augment,hh] using hj
        exact List.mem_append_left _ m
      | true =>
        have older := anti _ _ hh
        simpa [base,ext,hh,older] using hj)
  choose w hw using row
  have spec (u : Fin 16) (a : Fin 10) := (hw u a.val (by omega) a.isLt).trans
    (not_congr (keepOriginal (independentSets u) a.val _ a.isLt))
  refine ⟨w,?_,spec⟩
  intro u v eq
  by_contra ne
  obtain ⟨p,hp⟩ := distinct_sets u v ne
  have same := spec u p
  rw [eq] at same
  exact hp (by have z := same.symm.trans (spec v p); tauto)


theorem actual_signed_guard_row (gs : List DGate) (out : Nat)
    (cap : gs.countP Gate.isAnd ≤ 6) (xs : List Nat)
    (small : ∀ a ∈ xs, a < 10) (z : Bool)
    (on : eval gs 11 (inputSet (augment xs z)) out = onSet xs) :
    let axis := switchAxis (switchAddrs gs 11) ((switchAddrs_length gs 11).trans_le cap)
    onSet xs = true ↔ ∀ w : Word,
      (∃ a ∈ xs, w ∈ collect ((back axis gs 11 (initial out)).q a)) ∨
      (z = true ∧ w ∈ collect ((back axis gs 11 (initial out)).q 10)) := by
  dsimp only
  rw [← on]
  have bounded : ∀ a ∈ augment xs z, a < 11 := by
    intro a ha
    rcases List.mem_append.mp ha with h|h
    · exact Nat.lt_trans (small a h) (by decide)
    · cases z <;> simp_all
  have wordRule := signed_row_iff gs 11 out cap _ bounded
  dsimp only at wordRule
  rw [wordRule]
  apply forall_congr'
  intro w
  cases z <;> simp [augment,List.mem_append,or_and_right,exists_or]

end Research.Graph9822Profiles.OuterLive
