import SixD3SharedRules9822
namespace Research.Graph9822.ThreeDirect
open PEqualNP.Library.LRAT
def decode (vs : Array Atom) (n : Nat) : Lit := (vs[n/2]?.getD default,n%2 == 0)
def void : Lit → Bool
  | (.fixed b,s) => !(b==s)
  | _ => false
theorem void_false (e : Env) (l : Lit) (val : e.val l.1=l.2) : void l=false := by
  rcases l with ⟨a,s⟩
  cases a <;> simp_all [void,Env.val]
def supports (ok : α → Bool) (clauses : α → Clause) (vs : Array Atom)
    (rc : α × List Nat) : Bool :=
  ok rc.1 && (clauses rc.1).all (fun l => void l || (rc.2.map (decode vs)).contains l)
theorem numerical (e : Env) (ok : α → Bool) (clauses : α → Clause) (vs : Array Atom)
    (rows : List (α × List Nat)) (good : rows.all (supports ok clauses vs)=true)
    (laws : ∀ r, ok r=true → Sat e (clauses r)) : FormulaSat (rows.map Prod.snd) := by
  refine ⟨fun n => e.val (vs[n]?.getD default),?_⟩
  intro c hc
  obtain ⟨⟨r,C⟩,hr,rfl⟩ := List.mem_map.mp hc
  have hh := List.all_eq_true.mp good _ hr
  obtain ⟨valid,sub⟩ := Bool.and_eq_true_iff.mp hh
  obtain ⟨l,hl,val⟩ := laws r valid
  have h := List.all_eq_true.mp sub l hl
  simp only [void_false e l val,Bool.false_or,List.contains_iff_mem] at h
  obtain ⟨n,hn,eq⟩ := List.mem_map.mp h
  subst l
  exact ⟨n,hn,by simpa [litVal,decode] using val⟩
theorem closeBasic (d : Dir) (vs : Array Atom) (rows : List (Basic × List Nat))
    (good : rows.all (supports Basic.ok (Basic.clause d false) vs)=true)
    (bad : ¬ FormulaSat (rows.map Prod.snd)) : ¬ Nonempty (Rooms d false) := by
  rintro ⟨p⟩
  exact bad (numerical (envOf p [] (fun _=>0)) _ _ _ _ good (fun r h => r.sound p _ _ h))
theorem closeShared (d : Dir) (vs : Array Atom) (rows : List (SharedRule × List Nat))
    (good : rows.all (supports (SharedRule.ok d) (SharedRule.clause d) vs)=true)
    (bad : ¬ FormulaSat (rows.map Prod.snd)) : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact bad (numerical (envOf p.toRooms p.helper p.origin) _ _ _ _ good (fun r h => r.sound p h))
end Research.Graph9822.ThreeDirect
