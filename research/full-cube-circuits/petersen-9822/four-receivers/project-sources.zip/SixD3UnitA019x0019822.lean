import SixD3GridUnits9822
import SixD3GridDataA0199822
namespace Research.Graph9822.ThreeDirect.A019
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit12 : ∀ a, Known a g 195 → Known a g 196 :=
  singleKnown g 195 (unpack 28 [0x1016800002760a402412e0026d2870166091026523f016207f025d207015e06f02551dd015a061024d1bf0156055012a09d00fe08900ce077009e067006e059003a04d0002043024919d024511302d432902cc1e902c40a902bc2880238148022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit13 : ∀ a, Known a g 196 → Known a g 197 :=
  singleKnown g 196 (unpack 28 [0x1025400002e51dc01e606102511bf028a054028c3c9027d67202b179500b20a102a16f300aa07b00a2051026d2870096089006605902752e102fe043030209d00c60a500c209100be07f030e04702815c7028564d02d833302d432902d01f302c80b302c40a902c029202bc288023c1520230012022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit14 : ∀ a, Known a g 197 → Known a g 198 :=
  singleKnown g 197 (unpack 28 [0x101d800002b20a0027d79402896730172051030e04702815c7028564d02d833302d01f302c80b302c0292023c152023001202b9ca402349e00228784]) (by decide +kernel)
private theorem unit15 : ∀ a, Known a g 198 → Known a g 199 :=
  singleKnown g 198 (unpack 28 [0x100e000002b20a0027d794028967300d20510266076024123e025d207031606f02e60550312067030e04702815c7028564d024919d024511302d833302d432902d01f302cc1e902c80b302c40a902c029202bc288023c15202381480230012022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit16 : ∀ a, Known a g 199 → Known a g 200 :=
  singleKnown g 199 (unpack 28 [0x1016c000025606000720590006043]) (by decide +kernel)
private theorem unit17 : ∀ a, Known a g 200 → Known a g 201 :=
  singleKnown g 200 (unpack 28 [0x10080000025605802de06102b20a0027d794030e04702815c7028564d02d833302d01f302c80b302c0292023c152023001202b9ca402349e00228784]) (by decide +kernel)
private theorem unit18 : ∀ a, Known a g 201 → Known a g 202 :=
  singleKnown g 201 (unpack 28 [0x102200000226271025605801e6061028a054031e0510258468028c3c90321672030e04702d432902c40a902bc288022c00802b9ca40228784]) (by decide +kernel)
private theorem unit19 : ∀ a, Known a g 202 → Known a g 203 :=
  singleKnown g 202 (unpack 28 [0x101f0000026e0900116089001e043]) (by decide +kernel)
private theorem unit20 : ∀ a, Known a g 203 → Known a g 204 :=
  singleKnown g 203 (unpack 28 [0x101e0000026e090011208902b20a0027d794028967302e2051032a055031928603251dd030e04702815c7028564d02d833302d01f302c80b302c0292023c152023001202b9ca402349e00228784]) (by decide +kernel)
private theorem unit21 : ∀ a, Known a g 204 → Known a g 205 :=
  singleKnown g 204 (unpack 28 [0x101b4000026e0900241286025d20701b206f02551dd01ae061010e089007a0590312067026923f02a45a902a207a032d6f2030e047024919d024511302d432902cc1e902c40a902bc2880238148022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit22 : ∀ a, Known a g 205 → Known a g 206 :=
  singleKnown g 205 (unpack 28 [0x10200000025606002411dc026523f00f2077025d20700c2067008e059020e06f02aa09002fa08d027128702ac64902f6043030e047024919d024511302d432902cc1e902c40a902bc2880238148022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit23 : ∀ a, Known a g 206 → Known a g 207 :=
  singleKnown g 206 (unpack 28 [0x100ec000029a06e00da06b030e047]) (by decide +kernel)
theorem up1 : ∀ a, Known a g 195 → Known a g 207 := by
  intro a h
  apply unit23 a
  apply unit22 a
  apply unit21 a
  apply unit20 a
  apply unit19 a
  apply unit18 a
  apply unit17 a
  apply unit16 a
  apply unit15 a
  apply unit14 a
  apply unit13 a
  apply unit12 a
  exact h
end Research.Graph9822.ThreeDirect.A019
