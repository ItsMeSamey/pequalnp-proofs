import SixD3GridSemA017x009822
import SixD3GridSemA017x019822
import SixD3GridSemA017x029822
import SixD3GridSemA017x039822
import SixD3GridSemA017x049822
import SixD3GridSemA017x059822
import SixD3GridSemA017x069822
import SixD3GridSemA017x079822
import SixD3GridSemA017x089822
import SixD3GridSemA017x099822
import SixD3GridSemA017x109822
import SixD3GridSemA017x119822
import SixD3GridSemA017x129822
import SixD3GridSemA017x139822
import SixD3GridSemA017x149822
import SixD3GridSemA017x159822
import SixD3GridSemA017x169822
import SixD3GridSemA017x179822
import SixD3UnitA017x0009822
import SixD3UnitA017x0019822
import SixD3UnitA017x0029822
import SixD3UnitA017x0039822
import SixD3UnitA017x0049822
import SixD3UnitA017x0059822
import SixD3UnitA017x0069822
import SixD3UnitA017x0079822
import SixD3UnitA017x0089822
import SixD3UnitA017x0099822
import SixD3UnitA017x0109822
import SixD3UnitA017x0119822
import SixD3UnitA017x0129822
import SixD3UnitA017x0139822
import SixD3UnitA017x0149822
import SixD3UnitA017x0159822
import SixD3UnitA017x0169822
import SixD3UnitA017x0179822
import SixD3UnitA017x0189822
import SixD3UnitA017x0199822
import SixD3UnitA017x0209822
import SixD3UnitA017x0219822
namespace Research.Graph9822.ThreeDirect.A017
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 2538 (rangeAppend sem0 (rangeAppend sem1 (rangeAppend sem2 (rangeAppend sem3 (rangeAppend sem4 (rangeAppend sem5 (rangeAppend sem6 (rangeAppend sem7 (rangeAppend sem8 (rangeAppend sem9 (rangeAppend sem10 (rangeAppend sem11 (rangeAppend sem12 (rangeAppend sem13 (rangeAppend sem14 (rangeAppend sem15 (rangeAppend sem16 (sem17))))))))))))))))))
  intro a old
  apply endKnown g 2737 (by decide +kernel) a
  apply up21 a
  apply up20 a
  apply up19 a
  apply up18 a
  apply up17 a
  apply up16 a
  apply up15 a
  apply up14 a
  apply up13 a
  apply up12 a
  apply up11 a
  apply up10 a
  apply up9 a
  apply up8 a
  apply up7 a
  apply up6 a
  apply up5 a
  apply up4 a
  apply up3 a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A017
