import SixD3GridDataA2469822
namespace Research.Graph9822.ThreeDirect.A246
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part1296 : Range (aOK d) (aCl d) g 1296 1320 :=
  rangeCheck _ _ _ 1296 24 (by decide +kernel)
private theorem part1320 : Range (aOK d) (aCl d) g 1320 1344 :=
  rangeCheck _ _ _ 1320 24 (by decide +kernel)
private theorem part1344 : Range (aOK d) (aCl d) g 1344 1368 :=
  rangeCheck _ _ _ 1344 24 (by decide +kernel)
private theorem part1368 : Range (aOK d) (aCl d) g 1368 1392 :=
  rangeCheck _ _ _ 1368 24 (by decide +kernel)
private theorem part1392 : Range (aOK d) (aCl d) g 1392 1416 :=
  rangeCheck _ _ _ 1392 24 (by decide +kernel)
private theorem part1416 : Range (aOK d) (aCl d) g 1416 1440 :=
  rangeCheck _ _ _ 1416 24 (by decide +kernel)
theorem sem9 : Range (aOK d) (aCl d) g 1296 1440 := rangeAppend part1296 (rangeAppend part1320 (rangeAppend part1344 (rangeAppend part1368 (rangeAppend part1392 (part1416)))))
end Research.Graph9822.ThreeDirect.A246
