import SixD3GridUnits9822
import SixD3GridDataA0199822
namespace Research.Graph9822.ThreeDirect.A019
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit36 : ∀ a, Known a g 219 → Known a g 220 :=
  singleKnown g 219 (unpack 28 [0x100500000292060003e05d036569002b1795036a0a503620a1030e047]) (by decide +kernel)
private theorem unit37 : ∀ a, Known a g 220 → Known a g 221 :=
  singleKnown g 220 (unpack 28 [0x1029000001e6061018205d024e054036e04d036569002b1795036a0a503620a103591be035e043030e047]) (by decide +kernel)
theorem up3 : ∀ a, Known a g 219 → Known a g 221 := by
  intro a h
  apply unit37 a
  apply unit36 a
  exact h
end Research.Graph9822.ThreeDirect.A019
