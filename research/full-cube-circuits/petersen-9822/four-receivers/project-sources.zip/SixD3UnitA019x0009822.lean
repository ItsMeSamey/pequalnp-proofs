import SixD3GridUnits9822
import SixD3GridDataA0199822
namespace Research.Graph9822.ThreeDirect.A019
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit0 : ∀ a, Known a g 183 → Known a g 184 :=
  singleKnown g 183 (unpack 28 [0x101d400002b20a0027d79402996bb02060a501fa06f019a06b015a04702815c7028564d02d833302d01f302c80b302c0292023c152023001202b9ca402349e00228784]) (by decide +kernel)
private theorem unit1 : ∀ a, Known a g 184 → Known a g 185 :=
  singleKnown g 184 (unpack 28 [0x10178000026e09001020890006043]) (by decide +kernel)
private theorem unit2 : ∀ a, Known a g 185 → Known a g 186 :=
  singleKnown g 185 (unpack 28 [0x100e40000266076024123e025d20700b606701ee07f01ea06f001e043024919d024511302d432902cc1e902c40a902bc2880238148022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit3 : ∀ a, Known a g 186 → Known a g 187 :=
  singleKnown g 186 (unpack 28 [0x101e8000029a06e027d6ba02a973b01be08d02a16f301aa07b019606b01f209101ee07f015604702815c7028564d02d833302d01f302c80b302c0292023c152023001202b9ca402349e00228784]) (by decide +kernel)
private theorem unit4 : ∀ a, Known a g 187 → Known a g 188 :=
  singleKnown g 187 (unpack 28 [0x1005c00002aa090027d73a02a16f3005a07f02996bb005606f004a08d004607b004206b003a04702815c7028564d02d833302d01f302c80b302c0292023c152023001202b9ca402349e00228784]) (by decide +kernel)
private theorem unit5 : ∀ a, Known a g 188 → Known a g 189 :=
  singleKnown g 188 (unpack 28 [0x1017c000028a05001f6055016a047]) (by decide +kernel)
private theorem unit6 : ∀ a, Known a g 189 → Known a g 190 :=
  singleKnown g 189 (unpack 28 [0x1002c00002aa090001608d0002047]) (by decide +kernel)
private theorem unit7 : ∀ a, Known a g 190 → Known a g 191 :=
  singleKnown g 190 (unpack 28 [0x101c4000025e06e024120602551dd01c2061026523f00de07700ae067007e059001604301ca07f024919d024511302d432902cc1e902c40a902bc2880238148022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit8 : ∀ a, Known a g 191 → Known a g 192 :=
  singleKnown g 191 (unpack 28 [0x1003000002b20a4027d79402a16f3002a07f02916910022061001a0a1001207b028967302f573b001e055000a05d0006051000204702815c7028564d02d833302d01f302c80b302c0292023c152023001202b9ca402349e00228784]) (by decide +kernel)
private theorem unit9 : ∀ a, Known a g 192 → Known a g 193 :=
  singleKnown g 192 (unpack 28 [0x102b400002786e8027d79402412e002a16f3026523f014e07f0289673024d1bf0142055013a07b012e051026d28700fa08900ca077025d207009a06702551dd006a059003604d02fe0430152091014a06f0146061012a04702815c7028564d024919d024511302d833302d432902d01f302cc1e902c80b302c40a902c029202bc288023c15202381480230012022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit10 : ∀ a, Known a g 193 → Known a g 194 :=
  singleKnown g 193 (unpack 28 [0x1018c000026e0900241286026523f018a07f025d207018606f02752e1013209d010608900d607700a6067000a04301920a5024919d024511302d432902cc1e902c40a902bc2880238148022c00802b9ca402349e00228784]) (by decide +kernel)
private theorem unit11 : ∀ a, Known a g 194 → Known a g 195 :=
  singleKnown g 194 (unpack 28 [0x10144000027609c02412e0026d287011a089026523f00ea077025d20700ba067020209101fe07f01fa06f0292060030605d02591dd0294469024919d024511302d432902cc1e902c40a902bc2880238148022c00802b9ca402349e00228784]) (by decide +kernel)
theorem up0 : ∀ a, Known a g 183 → Known a g 195 := by
  intro a h
  apply unit11 a
  apply unit10 a
  apply unit9 a
  apply unit8 a
  apply unit7 a
  apply unit6 a
  apply unit5 a
  apply unit4 a
  apply unit3 a
  apply unit2 a
  apply unit1 a
  apply unit0 a
  exact h
end Research.Graph9822.ThreeDirect.A019
