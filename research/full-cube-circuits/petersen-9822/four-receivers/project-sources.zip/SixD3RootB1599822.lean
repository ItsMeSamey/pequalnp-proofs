import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B159
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (1,5,9)
private noncomputable def rules : List Nat := unpack 35 [0x200000804c00e010c88000000706030042e200000018000a01010800000050]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x80183cc005193800c28c001c0f0012b840029a00000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B159
