import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B037
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (0,3,7)
private noncomputable def rules : List Nat := unpack 35 [0x40924808101247c1020248d4204049168408092260810124401020248642040490b840800000048000000040]
private def keys : List Nat := (List.range 10).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x2001e65800b99e003e6e80139d2005e7b801ba0e007e8c8023a5a009882000000000a] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B037
