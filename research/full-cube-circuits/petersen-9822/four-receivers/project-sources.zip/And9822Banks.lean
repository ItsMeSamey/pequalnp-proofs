import Std
namespace Research.Graph9822.Banks

structure Bank where
  available : List Nat
  required : List Nat

def feasible (box : Fin 10 → List Nat) (b : Bank) : Bool :=
  (List.finRange 10).all (fun v => (box v).any (fun r => b.available.contains r)) &&
  b.required.all (fun m => (List.finRange 10).any (fun v => (box v).contains m))

theorem feasible_of_solution (b : Bank) (box : Fin 10 → List Nat) (r : Fin 10 → Nat)
    (inBox : ∀ v, r v ∈ box v) (avail : ∀ v, r v ∈ b.available)
    (must : ∀ m ∈ b.required, ∃ v, r v = m) : feasible box b = true := by
  apply Bool.and_eq_true_iff.mpr
  constructor
  · apply List.all_eq_true.mpr
    intro v _
    exact List.any_eq_true.mpr ⟨r v,inBox v,by simpa using avail v⟩
  · apply List.all_eq_true.mpr
    intro m h
    obtain ⟨v,hv⟩ := must m h
    exact List.any_eq_true.mpr ⟨v,List.mem_finRange _,by simpa [← hv] using inBox v⟩

def keep (bs : List Bank) (box : Fin 10 → List Nat) (x : Nat) : Bool :=
  bs.any fun b => feasible box b && b.available.contains x

theorem keep_of_solution (bs : List Bank) (b : Bank) (hb : b ∈ bs)
    (box : Fin 10 → List Nat) (r : Fin 10 → Nat)
    (inBox : ∀ v, r v ∈ box v) (avail : ∀ v, r v ∈ b.available)
    (must : ∀ m ∈ b.required, ∃ v, r v = m) (v : Fin 10) :
    keep bs box (r v) = true := by
  exact List.any_eq_true.mpr ⟨b,hb,Bool.and_eq_true_iff.mpr
    ⟨feasible_of_solution b box r inBox avail must,by simpa using avail v⟩⟩

theorem common_two (bs : List Bank) (b : Bank) (hb : b ∈ bs)
    (box : Fin 10 → List Nat) (r : Fin 10 → Nat)
    (inBox : ∀ v, r v ∈ box v) (avail : ∀ v, r v ∈ b.available)
    (must : ∀ m ∈ b.required, ∃ v, r v = m) (v w : Fin 10) :
    (bs.any (fun B => feasible box B && B.available.contains (r v) &&
      B.available.contains (r w))) = true := by
  exact List.any_eq_true.mpr ⟨b,hb,Bool.and_eq_true_iff.mpr ⟨Bool.and_eq_true_iff.mpr
    ⟨feasible_of_solution b box r inBox avail must,by simpa using avail v⟩,by simpa using avail w⟩⟩

end Research.Graph9822.Banks
#print axioms Research.Graph9822.Banks.common_two
