import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B367
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (3,6,7)
private noncomputable def rules : List Nat := unpack 35 [0x40b0102410160203e202c0406a4058080b480b01013101602020202c0403240580805c800000040000000050]
private def keys : List Nat := (List.range 10).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x20009b5800a6de0039be80127120059cb801a74e0079dc802279a009d32000400000a] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B367
