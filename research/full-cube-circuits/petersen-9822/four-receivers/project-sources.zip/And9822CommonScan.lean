import And9822CommonPhysical
import Mathlib.Data.Fintype.Card
set_option maxHeartbeats 800000
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822.CommonBank
noncomputable section
local instance : DecidableEq Mask6 := Classical.decEq _
local instance (p : Prop) : Decidable p := Classical.propDecidable p

/-- Reserve the distinct nondirect raw masks and the nonraw named grants in one
physical scan. The same optional bank is available to every receiver. -/
theorem common_from_scan {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (respects : ∀ s ∈ p, s.2 = P s.1) (R : Fin 10 → Mask6) (returned : ∀ v, R v ∈ l)
    (proper : ∀ v, ∃ q, q ∉ R v) (inc : ∀ u v, u ≠ v → ¬ R u ⊆ R v)
    (budget : n ≤ 8) :
    ∃ raw grants : Finset Mask6, ∃ hs,
      (∀ m, m ∈ raw ↔ ∃ v, R v = m ∧ ¬RayValue P m) ∧
      (∀ m, m ∈ grants ↔ m ∈ p.map Prod.snd ∧ ¬Primitive P m ∧ m ∉ raw) ∧
      Helpers (RayValue P) grants hs ∧ hs.length + raw.card + grants.card ≤ 8 ∧
      ∀ v, RayValue P (R v) ∨ PairOf (Source (RayValue P) grants hs) (R v) := by
  classical
  let raw := (Finset.univ.image R).filter (fun x => ¬RayValue P x)
  let grants := (p.map Prod.snd).toFinset.filter (fun x => ¬Primitive P x ∧ x ∉ raw)
  have rawDef (m) : m ∈ raw ↔ ∃ v, R v = m ∧ ¬RayValue P m := by
    simp only [raw,Finset.mem_filter,Finset.mem_image,Finset.mem_univ,true_and]
    constructor
    · rintro ⟨⟨v,e⟩,h⟩; exact ⟨v,e,h⟩
    · rintro ⟨v,e,h⟩; exact ⟨⟨v,e⟩,h⟩
  have gDef (m) : m ∈ grants ↔ m ∈ p.map Prod.snd ∧ ¬Primitive P m ∧ m ∉ raw := by
    simp [grants]
  have anti : ∀ x ∈ raw, ∀ y ∈ raw, x ⊆ y → x = y := by
    intro x hx y hy le
    obtain ⟨u,rfl,_⟩ := (rawDef _).mp hx
    obtain ⟨v,rfl,_⟩ := (rawDef _).mp hy
    by_cases eq : u = v
    · rw [eq]
    · exact False.elim (inc _ _ eq le)
  obtain ⟨ps,len,ord,seen,taps⟩ := bank_and_precursors scan P respects
  have avail : ∀ x ∈ raw ∪ grants, Available P ps x := by
    intro x hx
    rcases Finset.mem_union.mp hx with hr | hg
    · obtain ⟨v,rfl,_⟩ := (rawDef _).mp hr
      exact seen _ (returned v)
    · obtain ⟨s,st,rfl⟩ := List.mem_map.mp ((gDef _).mp hg).1
      exact taps s st
  have nd : ∀ x ∈ raw ∪ grants, ¬Primitive P x := by
    intro x hx
    rcases Finset.mem_union.mp hx with hr | hg
    · obtain ⟨v,rfl,no⟩ := (rawDef _).mp hr
      rintro (top | direct)
      · obtain ⟨q,nq⟩ := proper v
        exact nq (by rw [top]; exact Set.mem_univ q)
      · exact no direct
    · exact ((gDef _).mp hg).2.1
  obtain ⟨hs,hh,hc,pairs⟩ := ordered_ray_bank ord raw grants anti avail nd
  have dis : Disjoint raw grants := Finset.disjoint_left.mpr
    (by intro x hx hg; exact ((gDef x).mp hg).2.2 hx)
  rw [Finset.card_union_of_disjoint dis,len] at hc
  refine ⟨raw,grants,hs,rawDef,gDef,hh,by omega,?_⟩
  intro v
  by_cases direct : RayValue P (R v)
  · exact Or.inl direct
  · exact Or.inr (pairs _ ((rawDef _).mpr ⟨v,rfl,direct⟩))

/-- The accounting bound of the checker, in terms of its number d of direct
receivers rather than the cardinality of the nondirect receiver-mask set. -/
theorem spare_count {P : Axis6 → Mask6} {R : Fin 10 → Mask6}
    (inj : Function.Injective R) {raw grants : Finset Mask6} {hs : List Mask6}
    (rawDef : ∀ m, m ∈ raw ↔ ∃ v, R v = m ∧ ¬RayValue P m)
    (priced : hs.length + raw.card + grants.card ≤ 8) :
    hs.length + grants.card + 2 ≤
      ((Finset.univ : Finset (Fin 10)).filter (fun v => RayValue P (R v))).card := by
  classical
  let ND := (Finset.univ : Finset (Fin 10)).filter (fun v => ¬RayValue P (R v))
  have im : ND.image R = raw := by
    ext m
    rw [rawDef]
    simp only [ND,Finset.mem_image,Finset.mem_filter,Finset.mem_univ,true_and]
    constructor
    · rintro ⟨v,hv,rfl⟩
      exact ⟨v,rfl,hv⟩
    · rintro ⟨v,rfl,hv⟩
      exact ⟨v,hv,rfl⟩
  have nr : ND.card = raw.card := by
    rw [← im, Finset.card_image_of_injective _ inj]
  have sum := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset (Fin 10)))
    (fun v => RayValue P (R v))
  change _ + ND.card = _ at sum
  rw [Finset.card_univ,Fintype.card_fin] at sum
  omega

end
end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.common_from_scan
