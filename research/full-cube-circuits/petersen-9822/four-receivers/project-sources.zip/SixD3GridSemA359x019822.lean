import SixD3GridDataA3599822
namespace Research.Graph9822.ThreeDirect.A359
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part144 : Range (aOK d) (aCl d) g 144 168 :=
  rangeCheck _ _ _ 144 24 (by decide +kernel)
private theorem part168 : Range (aOK d) (aCl d) g 168 192 :=
  rangeCheck _ _ _ 168 24 (by decide +kernel)
private theorem part192 : Range (aOK d) (aCl d) g 192 208 :=
  rangeCheck _ _ _ 192 16 (by decide +kernel)
theorem sem1 : Range (aOK d) (aCl d) g 144 208 := rangeAppend part144 (rangeAppend part168 (part192))
end Research.Graph9822.ThreeDirect.A359
