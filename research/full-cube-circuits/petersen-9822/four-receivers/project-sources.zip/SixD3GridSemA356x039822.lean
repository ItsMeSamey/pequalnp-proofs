import SixD3GridDataA3569822
namespace Research.Graph9822.ThreeDirect.A356
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part432 : Range (aOK d) (aCl d) g 432 437 :=
  rangeCheck _ _ _ 432 5 (by decide +kernel)
theorem sem3 : Range (aOK d) (aCl d) g 432 437 := part432
end Research.Graph9822.ThreeDirect.A356
