import SixD3GridDataA2489822
namespace Research.Graph9822.ThreeDirect.A248
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part2016 : Range (aOK d) (aCl d) g 2016 2040 :=
  rangeCheck _ _ _ 2016 24 (by decide +kernel)
private theorem part2040 : Range (aOK d) (aCl d) g 2040 2064 :=
  rangeCheck _ _ _ 2040 24 (by decide +kernel)
private theorem part2064 : Range (aOK d) (aCl d) g 2064 2088 :=
  rangeCheck _ _ _ 2064 24 (by decide +kernel)
private theorem part2088 : Range (aOK d) (aCl d) g 2088 2112 :=
  rangeCheck _ _ _ 2088 24 (by decide +kernel)
private theorem part2112 : Range (aOK d) (aCl d) g 2112 2136 :=
  rangeCheck _ _ _ 2112 24 (by decide +kernel)
private theorem part2136 : Range (aOK d) (aCl d) g 2136 2160 :=
  rangeCheck _ _ _ 2136 24 (by decide +kernel)
theorem sem14 : Range (aOK d) (aCl d) g 2016 2160 := rangeAppend part2016 (rangeAppend part2040 (rangeAppend part2064 (rangeAppend part2088 (rangeAppend part2112 (part2136)))))
end Research.Graph9822.ThreeDirect.A248
