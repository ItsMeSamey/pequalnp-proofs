import SixD3GridSemA245x009822
import SixD3GridSemA245x019822
import SixD3GridSemA245x029822
import SixD3GridSemA245x039822
import SixD3GridSemA245x049822
import SixD3GridSemA245x059822
import SixD3GridSemA245x069822
import SixD3GridSemA245x079822
import SixD3GridSemA245x089822
import SixD3GridSemA245x099822
import SixD3UnitA245x0009822
import SixD3UnitA245x0019822
import SixD3UnitA245x0029822
import SixD3UnitA245x0039822
import SixD3UnitA245x0049822
import SixD3UnitA245x0059822
import SixD3UnitA245x0069822
import SixD3UnitA245x0079822
import SixD3UnitA245x0089822
import SixD3UnitA245x0099822
import SixD3UnitA245x0109822
import SixD3UnitA245x0119822
import SixD3UnitA245x0129822
import SixD3UnitA245x0139822
import SixD3UnitA245x0149822
import SixD3UnitA245x0159822
import SixD3UnitA245x0169822
import SixD3UnitA245x0179822
import SixD3UnitA245x0189822
namespace Research.Graph9822.ThreeDirect.A245
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 1429 (rangeAppend sem0 (rangeAppend sem1 (rangeAppend sem2 (rangeAppend sem3 (rangeAppend sem4 (rangeAppend sem5 (rangeAppend sem6 (rangeAppend sem7 (rangeAppend sem8 (sem9))))))))))
  intro a old
  apply endKnown g 1577 (by decide +kernel) a
  apply up18 a
  apply up17 a
  apply up16 a
  apply up15 a
  apply up14 a
  apply up13 a
  apply up12 a
  apply up11 a
  apply up10 a
  apply up9 a
  apply up8 a
  apply up7 a
  apply up6 a
  apply up5 a
  apply up4 a
  apply up3 a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A245
