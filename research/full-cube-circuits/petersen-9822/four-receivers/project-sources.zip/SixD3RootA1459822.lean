import SixD3RootA2489822
import SixD3Sigma145To2489822
namespace Research.Graph9822.ThreeDirect.A145
def d : Dir := (1,4,5)
theorem closed : ¬ Nonempty (Shared d) := by
  rintro ⟨p⟩
  exact A248.closed ⟨Sigma.shared145_248 p⟩
end Research.Graph9822.ThreeDirect.A145
