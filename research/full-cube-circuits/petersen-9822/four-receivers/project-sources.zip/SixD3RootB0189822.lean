import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B018
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (0,1,8)
private noncomputable def rules : List Nat := unpack 35 [0x200006804c00c0d0c88000000606028342e20000001400020d010800000010]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x80183fc00519f800c2bc001ae300126d40024f00000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B018
