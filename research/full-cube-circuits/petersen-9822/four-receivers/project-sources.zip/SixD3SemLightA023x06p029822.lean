import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem g912 : Range (aOK d) (aCl d) g 912 916 := rangeCheck _ _ _ 912 4 (by decide +kernel)
private theorem g916 : Range (aOK d) (aCl d) g 916 920 := rangeCheck _ _ _ 916 4 (by decide +kernel)
private theorem g920 : Range (aOK d) (aCl d) g 920 924 := rangeCheck _ _ _ 920 4 (by decide +kernel)
private theorem g924 : Range (aOK d) (aCl d) g 924 928 := rangeCheck _ _ _ 924 4 (by decide +kernel)
private theorem g928 : Range (aOK d) (aCl d) g 928 932 := rangeCheck _ _ _ 928 4 (by decide +kernel)
private theorem g932 : Range (aOK d) (aCl d) g 932 936 := rangeCheck _ _ _ 932 4 (by decide +kernel)
theorem light6p2 : Range (aOK d) (aCl d) g 912 936 := rangeAppend g912 (rangeAppend g916 (rangeAppend g920 (rangeAppend g924 (rangeAppend g928 (g932)))))
end Research.Graph9822.ThreeDirect.A023
