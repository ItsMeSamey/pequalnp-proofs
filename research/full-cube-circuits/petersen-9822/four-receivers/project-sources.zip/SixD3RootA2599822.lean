import SixD3GridSemA259x009822
import SixD3GridSemA259x019822
import SixD3GridSemA259x029822
import SixD3UnitA259x0009822
import SixD3UnitA259x0019822
namespace Research.Graph9822.ThreeDirect.A259
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 292 (rangeAppend sem0 (rangeAppend sem1 (sem2)))
  intro a old
  apply endKnown g 314 (by decide +kernel) a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A259
