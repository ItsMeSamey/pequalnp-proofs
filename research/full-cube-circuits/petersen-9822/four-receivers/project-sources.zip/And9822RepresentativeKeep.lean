import And9822ScanKeep
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.Fin
import And9822BankRepresentatives

namespace Research.Graph9822.NumericBank
open ArbitraryScan Graph9822Profiles Graph9822MaskCode Banks
noncomputable section
local instance (p : Prop) : Decidable p := Classical.propDecidable p

def key (P : Axis6 → Mask6) (m : Mask6) : Nat := (encode (firstReps P) m).toNat

theorem key_union (P : Axis6 → Mask6) (s t : Mask6) :
    key P (s ∪ t) = key P s ||| key P t := by
  simp [key,encode_union]

theorem key_eq {P : Axis6 → Mask6} {s t : Mask6} (hs : Stable P s) (ht : Stable P t) :
    key P s = key P t ↔ s=t := by
  change (encode (firstReps P) s).toNat = (encode (firstReps P) t).toNat ↔ _
  rw [BitVec.toNat_inj,encode_faithful hs ht]

def rayKeys (P : Axis6 → Mask6) : Finset Nat :=
  (Finset.univ : Finset (Axis6 × Bool)).image fun p => key P (ray P p.1 p.2)

private theorem ray_key {P : Axis6 → Mask6} {s : Mask6} (hs : Stable P s) :
    key P s ∈ rayKeys P ↔ RayValue P s := by
  constructor
  · intro h
    obtain ⟨⟨i,b⟩,_,e⟩ := Finset.mem_image.mp h
    exact ⟨i,b,(key_eq hs (stable_ray P i b)).mp e.symm⟩
  · rintro ⟨i,b,rfl⟩
    exact Finset.mem_image.mpr ⟨(i,b),Finset.mem_univ _,rfl⟩

def namedKeys (P : Axis6 → Mask6) (p : List (Axis6 × Mask6)) : Finset Nat :=
  ((p.map (fun a => key P a.2)).toFinset).filter fun x => x ≠ key P Set.univ ∧ x ∉ rayKeys P

theorem named_keys {P : Axis6 → Mask6} {p : List (Axis6 × Mask6)}
    (respects : ∀ a ∈ p, a.2 = P a.1) (x : Nat) :
    x ∈ namedKeys P p ↔ ∃ m ∈ p.map Prod.snd, ¬Primitive P m ∧ key P m=x := by
  classical
  constructor
  · intro h
    obtain ⟨hm,ht,hr⟩ := Finset.mem_filter.mp h
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hm)
    refine ⟨a.2,List.mem_map.mpr ⟨a,ha,rfl⟩,?_,rfl⟩
    rintro (u|⟨i,b,e⟩)
    · exact ht (congrArg (key P) u)
    · apply hr
      exact Finset.mem_image.mpr ⟨(i,b),Finset.mem_univ _,congrArg (key P) e.symm⟩
  · rintro ⟨m,hm,hn,rfl⟩
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hm
    have st : Stable P a.2 := by rw [respects a ha]; exact stable_activation P a.1
    apply Finset.mem_filter.mpr
    refine ⟨List.mem_toFinset.mpr (List.mem_map.mpr ⟨a,ha,rfl⟩),?_,?_⟩
    · exact fun e => hn (Or.inl ((key_eq st (stable_top P)).mp e))
    · exact fun e => hn (Or.inr ((ray_key st).mp e))

theorem representative_keep {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (respects : ∀ s ∈ p, s.2 = P s.1) (R : Fin 10 → Mask6) (returned : ∀ v, R v ∈ l)
    (proper : ∀ v, ∃ q, q ∉ R v) (inc : ∀ u v, u ≠ v → ¬ R u ⊆ R v) (budget : n ≤ 8)
    (id : Nat → Nat) (lib : Finset Nat) (boxes : Fin 10 → List Nat)
    (inLib : ∀ v, key P (R v) ∈ lib) (inBox : ∀ v,id (key P (R v)) ∈ boxes v)
    (d : Nat) (direct : ((Finset.univ : Finset (Fin 10)).filter (fun v => RayValue P (R v))).card=d)
    (dmax : d ≤ 4) :
    ∃ bank ∈ enumerate id lib (rayKeys P) (namedKeys P p) d,
      (∀ v,id (key P (R v)) ∈ bank.available) ∧
      (∀ m ∈ bank.required, ∃ v,id (key P (R v))=m) ∧
      ∀ v,keep (enumerate id lib (rayKeys P) (namedKeys P p) d) boxes (id (key P (R v)))=true := by
  apply scan_keep scan P respects R returned proper inc budget _ (key_union P) _ _ _ _ _ _ (named_keys respects) inLib inBox d direct dmax
  rintro m ⟨i,b,rfl⟩
  exact Finset.mem_image.mpr ⟨(i,b),Finset.mem_univ _,rfl⟩
end
end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.representative_keep
