import And9822CommonPhysical
import ProfileMaskCode9822
import Mathlib.Data.Finset.Prod

namespace Research.Graph9822.NumericBank
open Graph9822Profiles Graph9822MaskCode Graph9822.ArbitraryScan

def Same (P : Axis6 → Mask6) (w z : Word6) : Prop :=
  ∀ i b, w ∈ ray P i b ↔ z ∈ ray P i b

def Stable (P : Axis6 → Mask6) (s : Mask6) : Prop :=
  ∀ w z, Same P w z → (w ∈ s ↔ z ∈ s)

def First (P : Axis6 → Mask6) (w : Nat) : Prop :=
  ∀ j < w, ¬Same P (direction j) (direction w)

/-- Bit w is set precisely when direction w is the first with its twelve ray bits. -/
noncomputable def firstReps (P : Axis6 → Mask6) : BitVec 64 := by
  classical
  exact (BitVec.ofBoolListLE ((List.range 64).map (fun w => decide (First P w)))).cast (by simp)

private theorem first_bit (P : Axis6 → Mask6) (w : Nat) (h : w<64) :
    (firstReps P).getLsbD w = true ↔ First P w := by
  classical
  unfold firstReps
  rw [BitVec.getLsbD_cast, BitVec.getLsbD_ofBoolListLE, List.getD_eq_getElem?_getD]
  simp [h]

private theorem direction_onto (x : Word6) : ∃ w : Nat, w < 64 ∧ direction w=x := by
  let bits := BitVec.ofBoolListLE (List.ofFn x)
  refine ⟨bits.toNat,?_,?_⟩
  · simpa [bits] using bits.isLt
  · funext i
    change bits.getLsbD i.val = x i
    unfold bits
    rw [BitVec.getLsbD_ofBoolListLE, List.getD_eq_getElem?_getD]
    rw [List.getElem?_ofFn, dif_pos i.isLt]
    rfl

theorem hasRep (P : Axis6 → Mask6) (x : Word6) :
    ∃ w : Nat, w<64 ∧ (firstReps P).getLsbD w=true ∧ Same P (direction w) x := by
  classical
  obtain ⟨j,hj,ej⟩ := direction_onto x
  have valid : ∃ w : Nat, w<64 ∧ Same P (direction w) x :=
    ⟨j,hj,by rw [ej]; intro i b; rfl⟩
  let w := Nat.find valid
  obtain ⟨hw,hx⟩ := Nat.find_spec valid
  refine ⟨w,hw,(first_bit P w hw).2 ?_,hx⟩
  intro j lt eq
  exact (Nat.find_min valid lt) ⟨by omega,fun i b => (eq i b).trans (hx i b)⟩

theorem encode_faithful {P : Axis6 → Mask6} {s t : Mask6} (hs : Stable P s) (ht : Stable P t) :
    encode (firstReps P) s = encode (firstReps P) t ↔ s=t := by
  classical
  refine ⟨?_,congrArg _⟩
  intro eq
  ext x
  obtain ⟨w,hw,bit,same⟩ := hasRep P x
  have h := congrArg (fun m : BitVec 64 => m.getLsbD w) eq
  simp only [encode_bit _ _ _ hw,bit,Bool.true_and] at h
  exact (hs _ _ same).symm.trans ((decide_eq_decide.mp h).trans (ht _ _ same))

theorem stable_activation (P : Axis6 → Mask6) (i : Axis6) : Stable P (P i) := by
  intro w z same
  have go (a b : Word6) (eq : Same P a b) (ha : a ∈ P i) : b ∈ P i :=
    ((eq i (a i)).mp ⟨ha,rfl⟩).1
  exact ⟨go w z same,go z w (fun j b => (same j b).symm)⟩

theorem stable_ray (P : Axis6 → Mask6) (i : Axis6) (b : Bool) : Stable P (ray P i b) :=
  fun _ _ h => h i b

theorem stable_top (P : Axis6 → Mask6) : Stable P Set.univ := fun _ _ _ => Iff.rfl

end Research.Graph9822.NumericBank
#print axioms Research.Graph9822.NumericBank.encode_faithful
