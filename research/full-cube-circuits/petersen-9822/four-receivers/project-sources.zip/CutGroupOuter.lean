import CleanWire9822
import ResolveUnion
import And9822DirectionBound
import And9822Four

-- OuterRename9822.lean line 2
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds

def renGate (f : Nat → Nat) (g : Gate) : Gate := ⟨g.op,g.inputs.map f⟩

def WireEmbedding (f : Nat → Nat) (old new : List Bool) : Prop :=
  ∀ i, new.getD (f i) false = old.getD i false

theorem embedding_snoc (f : Nat → Nat) (inj : Function.Injective f)
    {u v : List Bool} (h : WireEmbedding f u v) (len : f u.length = v.length) (b : Bool) :
    WireEmbedding f (u++[b]) (v++[b]) := by
  intro i
  by_cases eq : i = u.length
  · subst i
    rw [len,getD_snoc_eq,getD_snoc_eq]
  · have n : f i ≠ v.length := fun bad => eq (inj (bad.trans len.symm))
    rw [getD_snoc_ne _ _ _ _ n,getD_snoc_ne _ _ _ _ eq,h i]

theorem embedding_run (f : Nat → Nat) (inj : Function.Injective f) (gs : List Gate)
    (u v : List Bool) (h : WireEmbedding f u v)
    (future : ∀ k, f (u.length+k) = v.length+k) :
    WireEmbedding f (wiresFrom gs u) (wiresFrom (gs.map (renGate f)) v) := by
  induction gs generalizing u v with
  | nil => exact h
  | cons g gs ih =>
    let b := g.op.eval (g.inputs.map fun i => u.getD i false)
    have eq : (renGate f g).op.eval ((renGate f g).inputs.map fun i => v.getD i false) = b := by
      simp only [renGate,b,List.map_map,Function.comp_apply]
      apply congrArg g.op.eval
      apply List.map_congr_left
      intro i _
      exact h i
    change WireEmbedding f (wiresFrom gs (u++[b]))
      (wiresFrom (gs.map (renGate f)) (v++[(renGate f g).op.eval ((renGate f g).inputs.map fun i => v.getD i false)]))
    rw [eq]
    apply ih _ _ (embedding_snoc f inj h (by simpa using future 0) b)
    intro k
    simpa [Nat.add_assoc,Nat.add_comm 1 k] using future (k+1)

end PEqualNP.Outside.L_meta_9822.Clean
-- OuterLift9822.lean line 2
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds

def shift (n i : Nat) := if i < n then i else i+1
def rotate (n p i : Nat) :=
  if i < n then i else if i < n+p then i+1 else if i = n+p then n else i

theorem shift_inj (n : Nat) : Function.Injective (shift n) := by
  intro a b e
  unfold shift at e
  split_ifs at e <;> omega

theorem rotate_inj (n p : Nat) : Function.Injective (rotate n p) := by
  intro a b e
  unfold rotate at e
  split_ifs at e <;> omega

theorem shiftSeed (x : List Bool) (z : Bool) : WireEmbedding (shift x.length) x (x ++ [z]) := by
  intro i
  by_cases h : i < x.length
  · rw [shift,if_pos h]
    exact List.getD_append _ _ _ _ h
  · simp only [shift,if_neg h]
    rw [List.getD_eq_default _ _ (by simp; omega), List.getD_eq_default x _ (by omega)]

theorem cutEmbedding (pre : List Gate) (x : List Bool) (z : Bool) :
    WireEmbedding (rotate x.length pre.length) (wiresFrom pre x ++ [z])
      (wiresFrom (pre.map (renGate (shift x.length))) (x ++ [z])) := by
  let left := wiresFrom pre x
  let right := wiresFrom (pre.map (renGate (shift x.length))) (x ++ [z])
  have llen : left.length = x.length + pre.length := length_wiresFrom _ _
  have rlen : right.length = x.length + pre.length + 1 := by
    simp [right,length_wiresFrom,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm]
  have he : WireEmbedding (shift x.length) left right := by
    apply embedding_run _ (shift_inj _) _ _ _ (shiftSeed x z)
    intro k
    simp [shift,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm]
  intro i
  change right.getD (rotate x.length pre.length i) false = (left ++ [z]).getD i false
  by_cases old : i < x.length+pre.length
  · have eq : rotate x.length pre.length i = shift x.length i := by simp [rotate,shift,old]
    rw [eq,he i,getD_snoc_ne _ _ _ _ (by omega)]
  · by_cases cut : i = x.length+pre.length
    · subst i
      have rank : rotate x.length pre.length (x.length+pre.length) = x.length := by simp [rotate]
      rw [rank,←llen,getD_snoc_eq]
      exact (getD_wiresFrom _ _ _ (by simp)).trans (getD_snoc_eq x z false)
    · have eq : rotate x.length pre.length i = i := by simp [rotate,old,cut,show ¬i<x.length by omega]
      rw [eq,List.getD_eq_default _ _ (by omega),List.getD_eq_default _ _ (by simp; omega)]

end PEqualNP.Outside.L_meta_9822.Clean
-- OuterCircuit9822.lean line 2
namespace PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

def outerCircuit (n : Nat) (pre post : List Gate) (out : Nat) : Circuit :=
  ⟨pre.map (renGate (shift n)) ++ post.map (renGate (rotate n pre.length)),
    rotate n pre.length out⟩

theorem outerSize (n : Nat) (pre post : List Gate) (out : Nat) :
    (outerCircuit n pre post out).size = pre.length + post.length := by
  simp [outerCircuit,Circuit.size]

theorem outerBasis (n : Nat) (pre post : List Gate) (out : Nat)
    (allowed : GateOp → Prop)
    (hp : ∀ g ∈ pre, allowed g.op ∧ g.inputs.length ≤ 2)
    (hs : ∀ g ∈ post, allowed g.op ∧ g.inputs.length ≤ 2) :
    ∀ g ∈ (outerCircuit n pre post out).gates, allowed g.op ∧ g.inputs.length ≤ 2 := by
  intro g hg
  rcases List.mem_append.mp hg with h|h
  · obtain ⟨q,hq,rfl⟩ := List.mem_map.mp h
    simpa [renGate] using hp q hq
  · obtain ⟨q,hq,rfl⟩ := List.mem_map.mp h
    simpa [renGate] using hs q hq

theorem outerCount (n : Nat) (pre post : List Gate) (out : Nat) (p : GateOp → Bool) :
    (outerCircuit n pre post out).gates.countP (fun g => p g.op) =
      pre.countP (fun g => p g.op) + post.countP (fun g => p g.op) := by
  simp [outerCircuit,List.countP_map,renGate,Function.comp_def]

theorem outerEval (pre post : List Gate) (out : Nat) (x : List Bool) (z : Bool) :
    (outerCircuit x.length pre post out).eval (x++[z]) =
      (wiresFrom post (wiresFrom pre x ++ [z])).getD out false := by
  let f := rotate x.length pre.length
  let old := wiresFrom pre x ++ [z]
  let new := wiresFrom (pre.map (renGate (shift x.length))) (x++[z])
  have cap : old.length = x.length+pre.length+1 := by simp [old,length_wiresFrom]
  have eq : old.length = new.length := by simp [new,old,length_wiresFrom,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm]
  have future (k : Nat) : f (old.length + k) = new.length + k := by
    unfold f rotate
    split_ifs <;> omega
  have emb := embedding_run f (rotate_inj _ _) post old new (cutEmbedding pre x z) future out
  change (wiresFrom (_ ++ _) (x++[z])).getD (f out) false = _
  rw [wiresFrom_append]
  exact emb

end PEqualNP.Outside.L_meta_9822.Clean
-- OuterDirections9822.lean line 2
namespace PEqualNP.Outside.L_meta_9822.OuterDirections
open Research.Graph9822Resolution

theorem maximalOriginalWitness (gs : List Gate) (start out : Nat)
    (original : Nat → Prop) (base : List Nat) (extension : Nat → List Nat)
    (reject : eval gs start (inputSet base) out = false)
    (accept : ∀ a, original a → a ∉ base →
      eval gs start (inputSet (a :: extension a)) out = true)
    (decreases : ∀ a, original a → ∀ j ∈ extension a, j ∈ base) :
    ∃ s : Wire, ∀ a, original a →
      (resolve gs start s (fun j => decide (j=a)) out = true ↔ a ∉ base) := by
  obtain ⟨s,_,hs⟩ := attains gs start (inputSet base)
  let hit := fun a => resolve gs start s (fun j => decide (j=a)) out
  have misses : ∀ a ∈ base, hit a ≠ true := by
    intro a ha hot
    have h : base.any hit = true := List.any_eq_true.mpr ⟨a,ha,hot⟩
    change base.any (fun a => resolve gs start s (fun j => decide (j=a)) out) = true at h
    rw [←resolve_inputs,hs,reject] at h
    contradiction
  refine ⟨s,?_⟩
  intro a raw
  constructor
  · intro found mem
    exact misses a mem found
  · intro missing
    have h := (accepts_iff_reaches gs start (a :: extension a) out).mp
      (accept a raw missing) s
    obtain ⟨j,hj,hits⟩ := List.any_eq_true.mp h
    rcases List.mem_cons.mp hj with e|tail
    · simpa [e] using hits
    · exact False.elim (misses j (decreases a raw j tail) hits)

end PEqualNP.Outside.L_meta_9822.OuterDirections
#print axioms PEqualNP.Outside.L_meta_9822.OuterDirections.maximalOriginalWitness
-- OuterCount9822.lean line 3
namespace PEqualNP.Outside.L_meta_9822.OuterDirections
open Research.Graph9822Resolution

theorem countOriginalRows {k : Nat} (gs : List Gate) (start out : Nat)
    (original : Nat → Prop) (base : Fin k → List Nat) (extensions : Fin k → Nat → List Nat)
    (distinct : ∀ u v, u ≠ v → ∃ p, original p ∧ ¬ (p ∈ base u ↔ p ∈ base v))
    (reject : ∀ u, eval gs start (inputSet (base u)) out = false)
    (accept : ∀ u a, original a → a ∉ base u →
      eval gs start (inputSet (a :: extensions u a)) out = true)
    (decreases : ∀ u a, original a → ∀ j ∈ extensions u a, j ∈ base u) :
    k ≤ 2 ^ gs.countP Gate.isAnd := by
  classical
  choose s witness using fun u =>
    maximalOriginalWitness gs start out original (base u) (extensions u)
      (reject u) (accept u) (decreases u)
  let f : Fin k → Fin (2 ^ gs.countP Gate.isAnd) := fun u =>
    ⟨bitsValue (directions gs start (s u)), by simpa [directions_length] using bitsValue_lt (directions gs start (s u))⟩
  have inj : Function.Injective f := by
    intro u v huv
    by_contra h
    obtain ⟨p,hp,hne⟩ := distinct u v h
    have he := bitsValue_inj (directions gs start (s u)) (directions gs start (s v))
      (by simp [directions_length]) (congrArg Fin.val huv)
    have eqr := congrFun (resolve_congr_directions gs start (s u) (s v)
      (fun j => decide (j=p)) he) out
    have hu := witness u p hp
    have hv := witness v p hp
    rw [eqr] at hu
    tauto
  simpa using Fintype.card_le_of_injective f inj

end PEqualNP.Outside.L_meta_9822.OuterDirections
-- OuterFour9822.lean line 3
namespace PEqualNP.Outside.L_meta_9822.OuterDirections
open Research.Graph9822Resolution
def augment (xs : List Nat) (z : Bool) : List Nat := xs ++ (if z then [10] else [])

theorem keepOriginal (xs : List Nat) (p : Nat) (z : Bool) (hp : p < 10) :
    p ∈ augment xs z ↔ p ∈ xs := by
  have h : p ≠ 10 := by omega
  cases z <;> simp [augment,h]

theorem fourOuter {gs : List Gate} {out : Nat} (guardBit : List Nat → Bool)
    (antitone : ∀ xs a, guardBit (a :: xs) = true → guardBit xs = true)
    (computes : ∀ xs, (∀ i ∈ xs, i < 10) →
      eval gs 11 (inputSet (augment xs (guardBit xs))) out = onSet xs) :
    4 ≤ gs.countP Gate.isAnd := by
  classical
  let base (u : Fin 16) := augment (independentSets u) (guardBit (independentSets u))
  let ext (u : Fin 16) (a : Nat) := augment (independentSets u) (guardBit (a :: independentSets u))
  have bounded : ∀ u : Fin 16, (independentSets u).all (· < 10) = true := by decide +kernel
  have small (u : Fin 16) : ∀ i ∈ independentSets u, i < 10 := by
    simpa using List.all_eq_true.mp (bounded u)
  have h := countOriginalRows gs 11 out (· < 10) base ext (by
    intro u v ne
    obtain ⟨p,hp⟩ := distinct_sets u v ne
    exact ⟨p,p.isLt,fun e => hp (((keepOriginal _ _ _ p.isLt).symm.trans e).trans (keepOriginal _ _ _ p.isLt))⟩)
    (fun u => (computes _ (small u)).trans (reject_sets u)) (by
      intro u a ha absent
      have hmem : a ∉ independentSets u := fun hm => absent ((keepOriginal _ _ _ ha).2 hm)
      change eval gs 11 (inputSet (augment (a :: independentSets u) _)) out = true
      exact (computes _ (by simpa using And.intro ha (small u))).trans (maximal_sets u ⟨a,ha⟩ hmem))
    (by
      intro u a _ j hj
      cases hh : guardBit (a :: independentSets u) with
      | false =>
        have hm : j ∈ independentSets u := by simpa [ext,augment,hh] using hj
        exact List.mem_append_left _ hm
      | true =>
        have old := antitone _ _ hh
        simpa [base,ext,hh,old] using hj)
  by_contra hn
  have h8 : 2 ^ gs.countP Gate.isAnd ≤ 8 :=
    Nat.pow_le_pow_right (by decide) (show gs.countP Gate.isAnd ≤ 3 by omega)
  omega
end PEqualNP.Outside.L_meta_9822.OuterDirections
