import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B245
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (2,4,5)
private noncomputable def rules : List Nat := unpack 35 [0x200005000c00e0a0b88000000700010280020000000818000a0c8800000000]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x801817000500c000c672001c0d00118680023db0000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B245
