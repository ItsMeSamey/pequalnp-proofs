import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem g984 : Range (aOK d) (aCl d) g 984 988 := rangeCheck _ _ _ 984 4 (by decide +kernel)
private theorem g988 : Range (aOK d) (aCl d) g 988 992 := rangeCheck _ _ _ 988 4 (by decide +kernel)
private theorem g992 : Range (aOK d) (aCl d) g 992 996 := rangeCheck _ _ _ 992 4 (by decide +kernel)
private theorem g996 : Range (aOK d) (aCl d) g 996 1000 := rangeCheck _ _ _ 996 4 (by decide +kernel)
private theorem g1000 : Range (aOK d) (aCl d) g 1000 1004 := rangeCheck _ _ _ 1000 4 (by decide +kernel)
private theorem g1004 : Range (aOK d) (aCl d) g 1004 1008 := rangeCheck _ _ _ 1004 4 (by decide +kernel)
theorem light6p5 : Range (aOK d) (aCl d) g 984 1008 := rangeAppend g984 (rangeAppend g988 (rangeAppend g992 (rangeAppend g996 (rangeAppend g1000 (g1004)))))
end Research.Graph9822.ThreeDirect.A023
