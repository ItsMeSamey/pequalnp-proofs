import SixD3SignedDescription9822
namespace Research.SixD3.Labels
open Research.SixH4.DirectLiteral (Word Lit ray)
open Research.SixH4.PairPartition (V)
open Research.Graph9822.ThreeDirect
open Research.Graph9822.ArbitraryScan (Primitive RayValue)
open Research.Graph9822Profiles.Fresh (Stable)
theorem ds_at {d : Dir} {j : Nat} (hj : j<3) : (ds d)[j]?.getD 10∈ds d := by
  interval_cases j <;> simp [ds]
theorem direct_roster (r : Roots) (P : Fin 6→Set Word) (R : V→Set Word) (x y z : V)
    (rx : R x=ray P r.a.1 r.a.2) (ry : R y=ray P r.b.1 r.b.2)
    (rz : R z=ray P r.c.1 r.c.2) : ∀ v : V,v.val∈ds (labelDir x y z) → RayValue P (R v) := by
  intro v mem
  rcases (show v=x ∨ v=y ∨ v=z by simpa [ds,labelDir,Fin.ext_iff] using mem) with eq|eq|eq
  · subst v; exact ⟨_,_,rx⟩
  · subst v; exact ⟨_,_,ry⟩
  · subst v; exact ⟨_,_,rz⟩
theorem choice_from_sites (r : Roots) (P : Fin 6→Set Word) (R : V→Set Word)
    (d : Dir) (H : Set Word) (roots : RootRows d r P R)
    (direct : ∀ v : V,v.val∈ds d → RayValue P (R v))
    (covered : ∃ v : V,v.val∉ds d ∧ H⊆R v)
    (stable : ∀ i,Stable (P i) i) (pos : ∀ i,∃ w,w∈P i)
    (anti : ∀ a b : V,a≠b → ¬R a⊆R b)
    (issued : ∀ i,Primitive P (P i) ∨ (∃ u,R u=P i) ∨ P i=H) :
    ∀ i,Choice r P R d H i := by
  classical
  intro i
  by_cases hid : 3≤axisCode r i
  · by_cases full : P i=Set.univ
    · exact Or.inl full
    rcases issued i with primitive|raw|helper
    · rcases Research.Graph9822.ArbitraryScan.different_origin (R:=R) (stable i) (pos i) full
          (Or.inl primitive) with ⟨k,s,ne,eq⟩|⟨v,nd,eq⟩
      · exact Or.inr (Or.inl ⟨(k,s),ne,eq⟩)
      · exact Or.inr (Or.inr ⟨hid,Or.inr ⟨v,fun h=>nd (direct v h),eq⟩⟩)
    · rcases Research.Graph9822.ArbitraryScan.different_origin (stable i) (pos i) full
          (Or.inr raw) with ⟨k,s,ne,eq⟩|⟨v,nd,eq⟩
      · exact Or.inr (Or.inl ⟨(k,s),ne,eq⟩)
      · exact Or.inr (Or.inr ⟨hid,Or.inr ⟨v,fun h=>nd (direct v h),eq⟩⟩)
    · exact Or.inr (Or.inr ⟨hid,Or.inl helper⟩)
  · obtain ⟨k,x,s,idx,addr,rx,_⟩ := roots (axisCode r i) (by omega)
    have ki := axisInj r idx
    subst k
    obtain ⟨v,without,sub⟩ := covered
    have xm : x.val∈ds d := addr ▸ ds_at (d:=d) (by omega : axisCode r i<3)
    have diff : x≠v := fun eq=>without (eq ▸ xm)
    rcases Research.Graph9822.ArbitraryScan.direct_A_origin x v diff i s rx anti H sub
      (stable i) (pos i) (issued i) with full|⟨k,t,ne,eq⟩
    · exact Or.inl full
    · exact Or.inr (Or.inl ⟨(k,t),ne,eq⟩)
end Research.SixD3.Labels
#print axioms Research.SixD3.Labels.choice_from_sites
