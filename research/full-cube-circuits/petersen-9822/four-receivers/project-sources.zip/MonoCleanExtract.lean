import PhysicalResolution
import CleanMin9822
import Sector9822
namespace Research.Graph9822Resolution
open PEqualNP.CircuitLowerBounds PEqualNP.Outside.L_meta_9822.Clean
open PEqualNP.Outside.L_meta_9822.Sectors

def dWell : List Gate → Nat → Prop
  | [], _ => True
  | g::gs, i => g.left < i ∧ g.right < i ∧ dWell gs (i+1)

theorem clean_as_binary (gs : List PEqualNP.CircuitLowerBounds.Gate) (i : Nat)
    (hc : CleanL i gs) (hz : ∀ g ∈ gs, g.op ≠ .not) :
    ∃ ds : List Gate, ds.map asGate = gs ∧ dWell ds i := by
  induction gs generalizing i with
  | nil => exact ⟨[],rfl,trivial⟩
  | cons g gs ih =>
    have tail : CleanL (i+1) gs := by
      intro n h hh
      simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using hc (n+1) h (by simpa using hh)
    obtain ⟨ds,hds,hw⟩ := ih (i+1) tail (fun k hk => hz k (List.mem_cons_of_mem _ hk))
    rcases hc 0 g (by simp) with bad | ⟨hop,j,k,hj,hk,hinputs⟩
    · exact False.elim (hz g List.mem_cons_self bad.1)
    · simp at hj hk
      rcases hop with ha | ho
      · let d : Gate := ⟨true,j,k⟩
        have eq : asGate d = g := by cases g; simp_all [asGate,d]
        exact ⟨d::ds,by simp [eq,hds],hj,hk,hw⟩
      · let d : Gate := ⟨false,j,k⟩
        have eq : asGate d = g := by cases g; simp_all [asGate,d]
        exact ⟨d::ds,by simp [eq,hds],hj,hk,hw⟩

theorem mono_candidate_binary (C : Circuit) (cand : Candidate C) (hc : CleanL 10 C.gates)
    (hz : C.gates.countP countsNot=0) :
    ∃ ds, dWell ds 10 ∧ ds.length ≤ 17 ∧
      ∀ x : Fin 10 → Bool, eval ds 10 (wiresFrom (List.ofFn x)) C.output = edge x := by
  have no : ∀ g ∈ C.gates, g.op ≠ .not := by
    intro g hg eq
    have hne := List.countP_eq_zero.mp hz g hg
    simp [countsNot,eq] at hne
  obtain ⟨ds,eq,hw⟩ := clean_as_binary C.gates 10 hc no
  have circ : asCircuit ds C.output = C := by cases C; simp_all [asCircuit]
  refine ⟨ds,hw,?_,?_⟩
  · have h := cand.2.1
    change C.gates.length ≤ 17 at h
    simpa [←eq] using h
  · intro x
    have h := cand.2.2 x
    rw [←circ,physical_eval,List.length_ofFn] at h
    simpa [circ] using h

end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.mono_candidate_binary
