import SixD3Packed9822
namespace Research.Graph9822.ThreeDirect.B147
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
def d : Dir := (1,4,7)
private noncomputable def rules : List Nat := unpack 35 [0x200000804c012010c8800000090002004042000000101804010b8800000020]
private def keys : List Nat := (List.range 7).map (·+1)
theorem closed : ¬ Nonempty (Rooms d false) :=
  closeB d rules (by decide +kernel) (checkW_sound _ keys 13 [0x80183cc0050a3000c64e001e6700121d00026310000000007] (by decide +kernel))
end Research.Graph9822.ThreeDirect.B147
