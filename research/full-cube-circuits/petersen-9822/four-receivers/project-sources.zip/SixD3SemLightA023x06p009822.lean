import SixD3GridDataA0239822
namespace Research.Graph9822.ThreeDirect.A023
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem g864 : Range (aOK d) (aCl d) g 864 868 := rangeCheck _ _ _ 864 4 (by decide +kernel)
private theorem g868 : Range (aOK d) (aCl d) g 868 872 := rangeCheck _ _ _ 868 4 (by decide +kernel)
private theorem g872 : Range (aOK d) (aCl d) g 872 876 := rangeCheck _ _ _ 872 4 (by decide +kernel)
private theorem g876 : Range (aOK d) (aCl d) g 876 880 := rangeCheck _ _ _ 876 4 (by decide +kernel)
private theorem g880 : Range (aOK d) (aCl d) g 880 884 := rangeCheck _ _ _ 880 4 (by decide +kernel)
private theorem g884 : Range (aOK d) (aCl d) g 884 888 := rangeCheck _ _ _ 884 4 (by decide +kernel)
theorem light6p0 : Range (aOK d) (aCl d) g 864 888 := rangeAppend g864 (rangeAppend g868 (rangeAppend g872 (rangeAppend g876 (rangeAppend g880 (g884)))))
end Research.Graph9822.ThreeDirect.A023
