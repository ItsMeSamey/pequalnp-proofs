import SixD3GridUnits9822
import SixD3GridDataA1379822
namespace Research.Graph9822.ThreeDirect.A137
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem unit153 : ∀ a, Known a g 2544 → Known a g 2545 :=
  singleKnown g 2544 (unpack 28 [0x10e78000036a093034208d0332051]) (by decide +kernel)
private theorem unit154 : ∀ a, Known a g 2545 → Known a g 2546 :=
  singleKnown g 2545 (unpack 28 [0x10e78000029e093027608d0266051]) (by decide +kernel)
private theorem unit155 : ∀ a, Known a g 2546 → Known a g 2547 :=
  singleKnown g 2546 (unpack 28 [0x10c94000070e0a500d60430e7a092274e0512395d992399dc323a1e9d2379cf7265608d237dd0723a5dd123adddd23b5eb723b9ec50f95e990f41d2d2375ce90ca06fe2385d952389dbf27697900d617c527be0ad27c209d27c607727857830fcde430be16090f85e3f0f35d190f51d770fa1d7b0f05cdd25c5a81259dbb92685dfb266dba30e806530e7c3d3252433f251833324fc1f324e40bf24dc0b30d9829e0d8c2920898152085c01e08540120d797f40888e9008449dc]) (by decide +kernel)
private theorem unit156 : ∀ a, Known a g 2547 → Known a g 2548 :=
  singleKnown g 2547 (unpack 28 [0x127b000027697900d617c50b4d50b07320ad072609706d2091035e09d029207727ba0a427c9bf52785783259dbb925c5a812685dfb266dba3]) (by decide +kernel)
private theorem unit157 : ∀ a, Known a g 2548 → Known a g 2549 :=
  singleKnown g 2548 (unpack 28 [0x127680000d617c50c957910c3d78306960ad06660a5059a0a1035209d028607700be0430042035]) (by decide +kernel)
private theorem unit158 : ∀ a, Known a g 2549 → Known a g 2550 :=
  singleKnown g 2549 (unpack 28 [0x10ae800007ca0a707320a5061a055]) (by decide +kernel)
private theorem unit159 : ∀ a, Known a g 2550 → Known a g 2551 :=
  singleKnown g 2550 (unpack 28 [0x10ae800002a20a702920a5027e0550d6207627697c40ca17910af06ff277609d27d60ad27cd54a278578327d206f25c5a81259dbb92685dfb266dba3252433f24e40bf0d9829e085c01e0d797f408449dc]) (by decide +kernel)
private theorem unit160 : ∀ a, Known a g 2551 → Known a g 2552 :=
  singleKnown g 2551 (unpack 28 [0x10d1c00007ba0a9036e09d01c6059]) (by decide +kernel)
private theorem unit161 : ∀ a, Known a g 2552 → Known a g 2553 :=
  singleKnown g 2552 (unpack 28 [0x12704000269dabc0a7d4e30b5d5650d3175b0ea9c010b094b50af547d0e79bf50e6dbad0e61b750b855750b214fd0ae954b0e2db230e85c4f0a9953d0e4dbeb0ec1c0f0a4d4390df9b110a294df0e21bd903de047081a0ab0816097080209507ee08307d6073079a0930776081074e07106f209106be07f064a061060a05505c60a1057e08d04e206b049205d043a051031a0890246067016204d00ea043006e035268207b]) (by decide +kernel)
private theorem unit162 : ∀ a, Known a g 2553 → Known a g 2554 :=
  singleKnown g 2553 (unpack 28 [0x127040000da5abc0b5d5650ea9c010e79bf50e6dbad0e61b750b855750ae954b0e2db230e85c4f0a9953d0e4dbeb0ec1c0f0df9b110e21bd9018604701de0ab01da09701d209501c209301be08101ba07101b209101ae07f01a2055019e0a1019a08d019206b018e05d018a051017e08900fe04d000a0350d1e05827e20a90dbda8d0b3d55709d13cd0a3953909f94351dc9c691dc5c5b1dbdb811db9c451db1b6b1dadb411da9c331da5b911da1b591d9db2f1d99ad11d95aab1d91a9b27de0a72495d2d0d2846b0d246e70d204671dcdc79268207b2659c1f0dada770da9a650df5afd251432b250c327250832524f41eb24f01e524d80ab24d00a70d8828a0d802860d7c284089014a088c144085000a08480060d797f40888e9008449dc]) (by decide +kernel)
private theorem unit163 : ∀ a, Known a g 2554 → Known a g 2555 :=
  singleKnown g 2554 (unpack 28 [0x10d1c00006860a9035209d01aa059]) (by decide +kernel)
private theorem unit164 : ∀ a, Known a g 2555 → Known a g 2556 :=
  singleKnown g 2555 (unpack 28 [0x12578000098938909f94350b315570b094b50af547d0b214fd0a4d43927e5a800d20467018604701e60ad01d60a901d209501ce08301ca07301b60a501b209101ae07f01aa06f01a6061018e05d018209d250c32724d00a70d8028608480060d797f408449dc]) (by decide +kernel)
theorem up13 : ∀ a, Known a g 2544 → Known a g 2556 := by
  intro a h
  apply unit164 a
  apply unit163 a
  apply unit162 a
  apply unit161 a
  apply unit160 a
  apply unit159 a
  apply unit158 a
  apply unit157 a
  apply unit156 a
  apply unit155 a
  apply unit154 a
  apply unit153 a
  exact h
end Research.Graph9822.ThreeDirect.A137
