import SixD3GridDataA1359822
namespace Research.Graph9822.ThreeDirect.A135
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part1728 : Range (aOK d) (aCl d) g 1728 1752 :=
  rangeCheck _ _ _ 1728 24 (by decide +kernel)
private theorem part1752 : Range (aOK d) (aCl d) g 1752 1776 :=
  rangeCheck _ _ _ 1752 24 (by decide +kernel)
private theorem part1776 : Range (aOK d) (aCl d) g 1776 1800 :=
  rangeCheck _ _ _ 1776 24 (by decide +kernel)
private theorem part1800 : Range (aOK d) (aCl d) g 1800 1824 :=
  rangeCheck _ _ _ 1800 24 (by decide +kernel)
private theorem part1824 : Range (aOK d) (aCl d) g 1824 1848 :=
  rangeCheck _ _ _ 1824 24 (by decide +kernel)
private theorem part1848 : Range (aOK d) (aCl d) g 1848 1872 :=
  rangeCheck _ _ _ 1848 24 (by decide +kernel)
theorem sem12 : Range (aOK d) (aCl d) g 1728 1872 := rangeAppend part1728 (rangeAppend part1752 (rangeAppend part1776 (rangeAppend part1800 (rangeAppend part1824 (part1848)))))
end Research.Graph9822.ThreeDirect.A135
