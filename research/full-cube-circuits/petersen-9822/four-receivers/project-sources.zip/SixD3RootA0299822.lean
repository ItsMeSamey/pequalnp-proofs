import SixD3GridSemA029x009822
import SixD3GridSemA029x019822
import SixD3GridSemA029x029822
import SixD3UnitA029x0009822
import SixD3UnitA029x0019822
import SixD3UnitA029x0029822
namespace Research.Graph9822.ThreeDirect.A029
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
theorem closed : ¬ Nonempty (Shared d) := by
  apply gridA d g 373 (rangeAppend sem0 (rangeAppend sem1 (sem2)))
  intro a old
  apply endKnown g 407 (by decide +kernel) a
  apply up2 a
  apply up1 a
  apply up0 a
  exact old
end Research.Graph9822.ThreeDirect.A029
