import SixD3GridDataA0179822
namespace Research.Graph9822.ThreeDirect.A017
open PEqualNP.Library.LRAT Packed
set_option maxRecDepth 80000
set_option maxHeartbeats 0
private theorem part1872 : Range (aOK d) (aCl d) g 1872 1896 :=
  rangeCheck _ _ _ 1872 24 (by decide +kernel)
private theorem part1896 : Range (aOK d) (aCl d) g 1896 1920 :=
  rangeCheck _ _ _ 1896 24 (by decide +kernel)
private theorem part1920 : Range (aOK d) (aCl d) g 1920 1944 :=
  rangeCheck _ _ _ 1920 24 (by decide +kernel)
private theorem part1944 : Range (aOK d) (aCl d) g 1944 1968 :=
  rangeCheck _ _ _ 1944 24 (by decide +kernel)
private theorem part1968 : Range (aOK d) (aCl d) g 1968 1992 :=
  rangeCheck _ _ _ 1968 24 (by decide +kernel)
private theorem part1992 : Range (aOK d) (aCl d) g 1992 2016 :=
  rangeCheck _ _ _ 1992 24 (by decide +kernel)
theorem sem13 : Range (aOK d) (aCl d) g 1872 2016 := rangeAppend part1872 (rangeAppend part1896 (rangeAppend part1920 (rangeAppend part1944 (rangeAppend part1968 (part1992)))))
end Research.Graph9822.ThreeDirect.A017
