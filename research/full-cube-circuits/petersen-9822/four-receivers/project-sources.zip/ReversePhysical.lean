import TraceInfluence
namespace Research.Graph9822Resolution

private theorem keep_atom (a i : Nat) (h : a ≠ i) :
    Function.update (atom a) i false = atom a := by
  funext j
  by_cases e : j=i
  · subst j; simp [atom,Ne.symm h]
  · simp [Function.update_of_ne e]

/-- Exact backward rule for an earlier wire at a binary gate. Its contribution
from other consumers persists, and it additionally receives the gate's reach
on precisely those words which select a matching operand. -/
theorem reverse_step (g : Gate) (tail : List Gate) (i a : Nat) (s : Wire)
    (out : Nat) (ha : a < i) :
    reaches (g::tail) i s out a =
      (reaches tail (i+1) s out a ||
        (reaches tail (i+1) s out i &&
          resolved g (s i) (decide (g.left=a)) (decide (g.right=a)))) := by
  change resolve tail (i+1) s
     (Function.update (atom a) i (resolved g (s i) (atom a g.left) (atom a g.right))) out = _
  have hi : a ≠ i := Nat.ne_of_lt ha
  cases h : resolved g (s i) (decide (g.left=a)) (decide (g.right=a)) with
  | false =>
    have h' : resolved g (s i) (atom a g.left) (atom a g.right) = false := h
    simp [h,h',keep_atom _ _ hi,reaches]
  | true =>
    have h' : resolved g (s i) (atom a g.left) (atom a g.right) = true := h
    rw [h']
    have u : Function.update (atom a) i true = wireUnion (atom a) (atom i) := by
      funext j
      by_cases e : j=i
      · subst j; simp [wireUnion,atom]
      · simp [wireUnion,atom,e,Function.update_of_ne e]
    rw [u,resolve_union]
    simp [wireUnion,reaches,h]

end Research.Graph9822Resolution
#print axioms Research.Graph9822Resolution.reverse_step
