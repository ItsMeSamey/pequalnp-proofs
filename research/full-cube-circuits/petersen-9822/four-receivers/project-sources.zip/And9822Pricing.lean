import And9822ScanBody
set_option maxRecDepth 100000
set_option maxHeartbeats 0

-- And9822Reserved 0aeccfe10383764d326b947b78901da85df5e714eabc7212c69f8589bd1065a3
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822.LiteralBank Graph9822.UnionCharge Graph9822.StarData

theorem terminal {P : Axis6 → Mask6} (ps : Pairs) {w : Nat}
    (tw : typed w) (built : Built (bank ps) w)
    (proper : ∃ q, q ∉ value P w) (nondirect : ∀ a b, value P w ≠ ray P a b) :
    ∃ i : Fin ps.length, (bank ps).output i = w := by
  cases built with
  | join i _ _ => exact ⟨i,rfl⟩
  | singleton w only =>
    have mem := first_ok w
    rcases tw _ mem with top | ⟨a,b,he⟩
    · exact False.elim ((excludes_observer proper) (by simpa [←top] using mem))
    · apply False.elim
      apply nondirect a b
      have eq : w = lit (numLit a b) := by
        have payload : w+1 = lit (numLit a b)+1 := by
          apply Nat.eq_of_testBit_eq
          intro k
          apply Bool.eq_iff_iff.mpr
          change has w k ↔ has (lit (numLit a b)) k
          rw [lit_has]
          constructor
          · intro h
            have eq' : k = first w := only k h
            exact (eq'.trans he).symm
          · intro hk
            have eq' := he.trans hk
            exact eq' ▸ mem
        omega
      rw [eq,value_ray]

/-- Pick paid terminal gates simultaneously for any list of distinct nondirect
raws that are incomparable with the receiver being priced. -/
theorem price_sources {P : Axis6 → Mask6} {ps : Pairs} {w : Nat} (b : Built (bank ps) w)
    {k t : Nat} (label : Fin k → Nat) (use : ∀ i, has w (label i))
    (nonleast : ∀ i, first w < label i) (li : ∀ i j, label i = label j → i = j)
    (raw : Fin t → Nat) (tr : ∀ j, typed (raw j)) (br : ∀ j, Built (bank ps) (raw j))
    (pr : ∀ j, ∃ q, q ∉ value P (raw j))
    (nr : ∀ j a s, value P (raw j) ≠ ray P a s)
    (ri : ∀ i j, raw i = raw j → i = j)
    (inc : ∀ j, ¬ value P (raw j) ⊆ value P w) : k+t ≤ ps.length := by
  classical
  choose gate eq using fun j => terminal ps (tr j) (br j) (pr j) (nr j)
  apply width_with_reserved (bank ps) w b label use nonleast li gate
  · intro i j he
    apply ri
    exact (eq i).symm.trans ((congrArg (bank ps).output he).trans (eq j))
  · intro j
    rw [eq]
    exact outside_label (inc j)

end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.price_sources

-- And9822LeafCount 2837a2932d0d23e024e0b9945547766a1d6b86712e886802293912f02720c371
namespace Research.Graph9822.ArbitraryScan
open Research.Graph9822.LiteralBank Research.Graph9822.UnionCharge Research.Graph9822.StarData

def leaves (w : Nat) := (List.range 12).filter (fun k => (w+1).testBit k)
theorem leaves_mem {w k} : k ∈ leaves w ↔ k<12 ∧ has w k := by simp [leaves,has]

theorem typed_small {P : Axis6 → Mask6} {w : Nat} (tw : typed w)
    (proper : ∃ q, q ∉ value P w) {k} (hk : has w k) : k < 12 := by
  rcases tw k hk with rfl | ⟨i,b,rfl⟩
  · exact False.elim (excludes_observer proper hk)
  · exact numLit_lt i b

theorem receiver_width {P : Axis6 → Mask6} {ps : Pairs} {w : Nat}
    (tw : typed w) (proper : ∃ q, q ∉ value P w) (bw : Built (bank ps) w)
    {t : Nat} (raw : Fin t → Nat) (tr : ∀ j, typed (raw j))
    (br : ∀ j, Built (bank ps) (raw j)) (pr : ∀ j, ∃ q, q ∉ value P (raw j))
    (nr : ∀ j a s, value P (raw j) ≠ ray P a s)
    (ri : ∀ i j, raw i = raw j → i = j) (inc : ∀ j, ¬ value P (raw j) ⊆ value P w) :
    (leaves w).length - 1 + t ≤ ps.length := by
  let rest := (leaves w).erase (first w)
  have nd : (leaves w).Nodup := (List.nodup_range (n := 12)).filter _
  have nd' : rest.Nodup := nd.erase _
  let lab (i : Fin rest.length) := rest[i.val]'i.isLt
  have spec (i : Fin rest.length) : lab i ≠ first w ∧ lab i ∈ leaves w :=
    nd.mem_erase_iff.mp (List.getElem_mem i.isLt)
  have mem (i) := (leaves_mem.mp (spec i).2).2
  have gt (i) : first w < lab i := by have := le_first w _ (mem i); have := (spec i).1; omega
  have inj (i j : Fin rest.length) (h : lab i = lab j) : i = j :=
    Fin.ext (nd'.eq_of_getElem_eq i.isLt j.isLt h)
  have e := price_sources bw lab mem gt inj raw tr br pr nr ri inc
  have first_in := leaves_mem.mpr ⟨typed_small tw proper (first_ok w),first_ok w⟩
  simpa [rest,List.length_erase_of_mem first_in] using e

theorem width_at_seventeen {P : Axis6 → Mask6} {ps : Pairs} {w : Nat}
    (tw : typed w) (proper : ∃ q, q ∉ value P w) (bw : Built (bank ps) w)
    {d t : Nat} (raw : Fin t → Nat) (tr : ∀ j, typed (raw j))
    (br : ∀ j, Built (bank ps) (raw j)) (pr : ∀ j, ∃ q, q ∉ value P (raw j))
    (nr : ∀ j a s, value P (raw j) ≠ ray P a s)
    (ri : ∀ i j, raw i = raw j → i = j) (inc : ∀ j, ¬ value P (raw j) ⊆ value P w)
    (others : 9 ≤ d+t) (cost : ps.length ≤ 8) : (leaves w).length ≤ d := by
  have := receiver_width tw proper bw raw tr br pr nr ri inc
  omega

end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.width_at_seventeen

-- And9822WidthAtRaw 871bb33b1dc25e57d09a913c0800972ced89789c19320aec224755775a6e855a
namespace Research.Graph9822.ArbitraryScan
open Research.Graph9822.LiteralBank Research.Graph9822.UnionCharge

theorem width_all {P : Axis6 → Mask6} {ps : Pairs} (raw : Fin 10 → Nat)
    (tw : ∀ v, typed (raw v)) (bw : ∀ v, Built (bank ps) (raw v))
    (proper : ∀ v, ∃ q, q ∉ value P (raw v))
    (inc : ∀ u v, u ≠ v → ¬ value P (raw u) ⊆ value P (raw v))
    (direct : Fin 10 → Bool)
    (nondirect : ∀ v, direct v = false → ∀ i b, value P (raw v) ≠ ray P i b)
    (cost : ps.length ≤ 8) (v : Fin 10) :
    (leaves (raw v)).length ≤ ((List.finRange 10).filter direct).length := by
  let other := (List.finRange 10).erase v
  let remaining := other.filter (fun i => !direct i)
  let label (i : Fin remaining.length) := remaining[i.val]'i.isLt
  have nd : (List.finRange 10).Nodup := List.nodup_finRange _
  have restND : remaining.Nodup := (nd.erase v).filter _
  have unary (i : Fin remaining.length) : label i ∈ other ∧ direct (label i) = false := by
    have h : label i ∈ remaining := List.getElem_mem i.isLt
    simpa [remaining] using List.mem_filter.mp h
  have hdiff (i : Fin remaining.length) : label i ≠ v := (nd.mem_erase_iff.mp (unary i).1).1
  have labInj (i j : Fin remaining.length) (h : raw (label i) = raw (label j)) : i=j := by
    by_contra he
    have diff : label i ≠ label j := fun eq => he (Fin.ext (restND.eq_of_getElem_eq i.isLt j.isLt eq))
    exact inc _ _ diff (fun q hq => by simpa only [h] using hq)
  have filtered : (other.filter direct).length ≤ ((List.finRange 10).filter direct).length := by
    have sub : other.Sublist (List.finRange 10) := List.erase_sublist
    exact (sub.filter direct).length_le
  have eq := List.length_eq_countP_add_countP direct (l := other)
  simp only [List.countP_eq_length_filter,decide_not,Bool.decide_eq_true] at eq
  have len : other.length = 9 := by simp [other,List.length_erase_of_mem (List.mem_finRange v)]
  apply width_at_seventeen (tw v) (proper v) (bw v) (fun i => raw (label i))
    (fun i => tw _) (fun i => bw _) (fun i => proper _)
    (fun i => nondirect _ (unary i).2) labInj (fun i => inc _ _ (hdiff i)) _ cost
  change 9 ≤ ((List.finRange 10).filter direct).length + (other.filter (fun i => !direct i)).length
  omega

end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.width_all

-- And9822DirectLabels 91bab9c94a485d8ffb92deb6387cbd0af2ab7536fa91eb87e4a33571454f3d41
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822.LiteralBank Graph9822.UnionCharge Graph9822.StarData

theorem direct_pair {P : Axis6 → Mask6} (R : Fin 10 → Mask6) {u v : Fin 10}
    (separate : R u ≠ R v) (intersects : ∃ q, q ∈ R u ∧ q ∈ R v)
    (cover : adj u v = true → ∀ q, q ∈ R u ∨ q ∈ R v)
    {i j : Axis6} {s t : Bool} (hu : R u = ray P i s) (hv : R v = ray P j t) :
    i ≠ j ∧ adj u v = false := by
  have distinct : i ≠ j := by
    intro he
    subst j
    by_cases e : s=t
    · exact separate (hu.trans ((congrArg (ray P i) e).trans hv.symm))
    obtain ⟨q,qu,qv⟩ := intersects
    rw [hu] at qu
    rw [hv] at qv
    exact e (qu.2.symm.trans qv.2)
  refine ⟨distinct,?_⟩
  cases h : adj u v with
  | false => rfl
  | true =>
    let q : Word6 := fun k => if k=i then !s else !t
    rcases cover h q with qu | qv
    · rw [hu] at qu
      have e : q i = s := qu.2
      cases s <;> simp [q] at e
    · rw [hv] at qv
      have e : q j = t := qv.2
      cases t <;> simp [q,Ne.symm distinct] at e

theorem at_least_two {P : Axis6 → Mask6} {ps : Pairs} (raw : Fin 10 → Nat)
    (typedR : ∀ v, typed (raw v)) (build : ∀ v, Built (bank ps) (raw v))
    (proper : ∀ v, ∃ q, q ∉ value P (raw v))
    (ri : ∀ u v, raw u = raw v → u=v)
    (direct : Fin 10 → Bool)
    (nondirect : ∀ v, direct v=false → ∀ i b, value P (raw v) ≠ ray P i b)
    (cost : ps.length ≤ 8) : 2 ≤ ((List.finRange 10).filter direct).length := by
  classical
  let rest := (List.finRange 10).filter (fun v => !direct v)
  let vertex (j : Fin rest.length) := rest[j.val]'j.isLt
  have hnd : rest.Nodup := (List.nodup_finRange _).filter _
  have no (j : Fin rest.length) : direct (vertex j) = false := by
    have h : vertex j ∈ rest := List.getElem_mem j.isLt
    simpa using (List.mem_filter.mp h).2
  choose gate eq using fun (j : Fin rest.length) =>
    terminal ps (typedR (vertex j)) (build _) (proper _) (nondirect _ (no j))
  have inj {i j : Fin rest.length} (h : gate i = gate j) : i=j := by
    have er := (eq i).symm.trans ((congrArg (bank ps).output h).trans (eq j))
    exact Fin.ext (hnd.eq_of_getElem_eq i.isLt j.isLt (ri _ _ er))
  have nd : ((List.finRange rest.length).map gate).Nodup :=
    List.pairwise_map.mpr ((List.nodup_finRange _).imp (fun h e => h (inj e)))
  have ub := nd.length_le_of_subset (l₂ := List.finRange ps.length) (fun {x} _ => List.mem_finRange x)
  have bound : rest.length ≤ ps.length := by simpa using ub
  have eq := List.length_eq_countP_add_countP direct (l := List.finRange 10)
  simp only [List.length_finRange,List.countP_eq_length_filter,decide_not,Bool.decide_eq_true] at eq
  change ((List.finRange 10).filter (fun v => !direct v)).length ≤ ps.length at bound
  omega

theorem at_most_four {P : Axis6 → Mask6} (R : Fin 10 → Mask6)
    (separate : ∀ u v, u ≠ v → R u ≠ R v)
    (overlap : ∀ u v, u ≠ v → ∃ q, q ∈ R u ∧ q ∈ R v)
    (cover : ∀ u v, adj u v = true → ∀ q, q ∈ R u ∨ q ∈ R v)
    (direct : Fin 10 → Bool) (get : ∀ v, direct v = true → ∃ i b, R v = ray P i b) :
    ((List.finRange 10).filter direct).length ≤ 4 := by
  have truth : ∀ e : Fin 13, adj (ends e).1 (ends e).2 = true := by decide +kernel
  let complement := (List.finRange 10).filter (fun v => !direct v)
  have hx (v : Fin 10) (h : direct v = false) : v ∈ complement :=
    List.mem_filter.mpr ⟨List.mem_finRange _,by simp [h]⟩
  have edgesHit (e : Fin 13) : (ends e).1 ∈ complement ∨ (ends e).2 ∈ complement := by
    cases h1 : direct (ends e).1 with
    | false => exact Or.inl (hx _ h1)
    | true =>
      cases h2 : direct (ends e).2 with
      | false => exact Or.inr (hx _ h2)
      | true =>
        obtain ⟨i,b,hu⟩ := get _ h1
        obtain ⟨j,s,hv⟩ := get _ h2
        have h := (direct_pair R (separate _ _ (ends_ne e)) (overlap _ _ (ends_ne e))
          (cover _ _) hu hv).2
        rw [truth] at h
        contradiction
  have lower := coverCost complement edgesHit
  have eq := List.length_eq_countP_add_countP direct (l := List.finRange 10)
  simp only [List.length_finRange,List.countP_eq_length_filter,decide_not,Bool.decide_eq_true] at eq
  change 6 ≤ ((List.finRange 10).filter (fun v => !direct v)).length at lower
  omega

end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.at_least_two
#print axioms Research.Graph9822.ArbitraryScan.at_most_four

-- And9822ProfileFrontend b51c367d3816dc23318252731c6cbcb8da1083b80dc6c9e66448cf95c86f9130
namespace Research.Graph9822.ArbitraryScan
open Graph9822Profiles Graph9822.LiteralBank Graph9822.UnionCharge Graph9822.StarData
structure Priced (P : Axis6 → Mask6) (R : Fin 10 → Mask6) (n : Nat) where
  ps : Pairs
  wire : Fin 10 → Nat
  direct : Fin 10 → Bool
  cost : ps.length=n
  ordered : Ordered ps
  interpreted : ∀ v, value P (wire v) = R v
  types : ∀ v, typed (wire v)
  generated : ∀ v, Built (bank ps) (wire v)
  isDirect : ∀ v, direct v = true ↔ ∃ i b, R v = ray P i b
  directMin : 2 ≤ ((List.finRange 10).filter direct).length
  directMax : ((List.finRange 10).filter direct).length ≤ 4
  leafLimit : ∀ v, (leaves (wire v)).length ≤ ((List.finRange 10).filter direct).length

theorem from_scan {b l p n} (scan : Scan b l p n) (P : Axis6 → Mask6)
    (respects : ∀ s ∈ p, s.2 = P s.1) (R : Fin 10 → Mask6) (givenR : ∀ v, R v ∈ l)
    (proper : ∀ v, ∃ q, q ∉ R v) (inc : ∀ u v, u ≠ v → ¬ R u ⊆ R v)
    (intersects : ∀ u v, u ≠ v → ∃ q, q ∈ R u ∧ q ∈ R v)
    (cover : ∀ u v, adj u v = true → ∀ q, q ∈ R u ∨ q ∈ R v)
    (budget : n ≤ 8) :
    ∃ out : Priced P R n, ∀ s ∈ p, Available P out.ps s.2 := by
  classical
  obtain ⟨ps,hn,ord,available,taps⟩ := bank_and_precursors scan P respects
  choose wire he typedW built using fun v => available _ (givenR v)
  let direct (v : Fin 10) := decide (∃ i b, R v = ray P i b)
  have hd (v) : direct v = true ↔ ∃ i b, R v = ray P i b := decide_eq_true_iff
  have bad (v) (h : direct v=false) (i : Axis6) (b : Bool) : value P (wire v) ≠ ray P i b := by
    intro eq
    have hv := (hd v).mpr ⟨i,b,(he v).symm.trans eq⟩
    simp [h] at hv
  have sep (u v) (h : u≠v) : R u ≠ R v :=
    fun e => inc u v h (fun q hq => by simpa only [e] using hq)
  have wi (u v) (h : wire u = wire v) : u=v := by
    apply Classical.byContradiction
    intro diff
    exact sep u v diff ((he u).symm.trans ((congrArg (value P) h).trans (he v)))
  have pr (v) : ∃ q, q ∉ value P (wire v) := by rw [he]; exact proper v
  have comp (u v) (h : u ≠ v) : ¬ value P (wire u) ⊆ value P (wire v) := by
    rw [he,he]
    exact inc u v h
  have cap : ps.length ≤ 8 := hn.trans_le budget
  let out : Priced P R n := ⟨ps,wire,direct,hn,ord,he,typedW,built,hd,
    at_least_two wire typedW built pr wi direct bad cap,
    at_most_four R sep intersects cover direct (fun v => (hd v).mp),
    width_all wire typedW built pr comp direct bad cap⟩
  exact ⟨out,taps⟩
end Research.Graph9822.ArbitraryScan
#print axioms Research.Graph9822.ArbitraryScan.from_scan
