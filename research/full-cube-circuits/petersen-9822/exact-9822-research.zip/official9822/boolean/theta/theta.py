from itertools import combinations
def run(lengths):
    edges=[]; n=2
    for length in lengths:
        path=[0,*range(n,n+length-1),1];n+=length-1
        edges.extend(zip(path,path[1:]))
    size=1<<n; truth=sum(1<<x for x in range(size) if any(x>>a&1 and x>>b&1 for a,b in edges))
    raws=[sum(1<<x for x in range(size) if x>>i&1) for i in range(n)]
    allbits=(1<<size)-1
    terms={}; desc={}
    for m in range(size):
        t=allbits
        for i in range(n):
            if m>>i&1:t &= raws[i]
        for col in [t,t&(raws[0]|raws[1])]:
            terms[col]=m&~3; desc.setdefault(col,(m,col!=t))
    pivots=[((truth>>(1<<i))^truth)&(allbits^r) for i,r in enumerate(raws)]
    survivors=[]; admissible=0
    for (a,s),(b,t) in combinations(terms.items(),2):
        cut=a|b; group=s|t
        if cut==a or cut==b or not group:continue
        admissible+=1
        if any(pivots[i]&~((cut>>(1<<i))^cut) for i in range(2,n) if group>>i&1):continue
        survivors.append((desc[a],desc[b]))
    print(lengths,n,admissible,len(survivors),survivors[:24],flush=True)
for lengths in [(2,3,3),(1,4,4),(1,4,5)]:run(lengths)
