# Monotone OR complexity of the 9822 graph is at least eleven

The full-cube target accepts a set of vertices precisely when it contains an edge of the graph in deletions.py. Gate fanout and the number of AND gates are unrestricted.

Each single raw zero cofactor needs at least nine ORs. For vertices 0 and 3 apply duality/nine-vertex-frontier.md in its monotone case. For 1 and 2, pin the other one to zero, saving an OR, and apply duality/eight-vertex-core.md to the remaining graph. For 4 through 9 the edge-multiset check in deletions.py peels zero, one or two pendant vertices to an induced theta. Each pendant pin saves an OR on any nonconstant circuit because it is essential and leaves an edge. The three theta cores need their full vertex count in ORs by boolean/theta/README.md, giving nine including the peeled vertices.

Suppose ten ORs suffice. Every raw must have a unique first OR among its paths to the output, because two such gates would both fold on its zero pin. There is no AND-only path to output, since the zero cofactor is nonzero. In a minimum-size implementation at this OR cap, the earliest OR A combines two raw conjunctions. Let S be their combined support. Every path from every member of S goes through A.

If S contains an edge, setting the exterior raws zero leaves a nonconstant monotone function of A alone, hence exactly A. Thus A rejects every singleton. For S proper, a crossing edge sx and the exterior singleton x then yield the same A and exterior inputs, a contradiction. If S is the full graph, A cannot supply thirteen distinct minimal edges with two conjunctions. Therefore S is independent. Every s in S has an exterior neighbor, forcing A true on each singleton s to distinguish the crossing edge. Two conjunctions cover at most two singletons. If S has one vertex A is redundant. With two, A identifies its distinct vertices in every exterior context, forcing identical neighborhoods. The graph has minimum degree two and no four-cycle, so this cannot happen.

This proves the eleven-OR floor. Under a total size cap of seventeen it leaves at most six ANDs, excluded by the separate corresponding finite certificates.
