"""Small independent cofactor audit, using only the Python standard library."""
from itertools import combinations
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
ENDPOINTS = {'1': 15, 'a': 10, 'b': 12, 'and': 8, 'or': 14}


def candidates(n, target):
    # Index by actual target-changing pairs for each internal site. A cut must
    # be false on every low assignment and true on every high partner.
    pivots = {}
    for v in range(2, n):
        bit = 1 << v
        pivots[v] = [x for x in range(1 << n)
                     if not x & bit and not target[x] and target[x | bit]]
    terms = []
    for subset in range(1 << (n-2)):
        mask = subset << 2
        for name, endpoint_table in ENDPOINTS.items():
            def term(x):
                return (x & mask) == mask and bool(endpoint_table & (1 << (x & 3)))
            changes = {}
            for v, low in pivots.items():
                low_is_live = any(term(x) for x in low)
                covered = frozenset(i for i, x in enumerate(low) if term(x | (1 << v)))
                changes[v] = low_is_live, covered
            terms.append((mask, endpoint_table, changes))
    counts = {v: len(rows) for v, rows in pivots.items()}
    kept = []
    admissible = 0
    for (s, a, sa), (t, b, tb) in combinations(terms, 2):
        if not s | t:
            continue
        # If left implies right or vice versa, the OR equals one input.
        if (s & t == t and a & b == a) or (s & t == s and a & b == b):
            continue
        admissible += 1
        valid = True
        for v in pivots:
            if not (s | t) & (1 << v):
                continue
            l, p = sa[v]
            m, q = tb[v]
            if l or m or len(p | q) != counts[v]:
                valid = False
                break
        if valid:
            kept.append(tuple(sorted(((s,a),(t,b)))))
    return admissible, sorted(kept)


def graph_truth(n, edges):
    masks = [(1 << x) | (1 << y) for x, y in edges]
    return [any(a & mask == mask for mask in masks) for a in range(1 << n)]


def theta(lengths):
    n = 2
    edges = []
    for distance in lengths:
        arc = [0] + list(range(n, n+distance-1)) + [1]
        edges.extend(zip(arc,arc[1:]))
        n += distance-1
    return n, edges


def original_crosswalk():
    source = (ROOT/'physical/Physical9822.lean').read_text()
    table = int(re.search(r'^def graph : Sig := (0x[0-9a-f]+)$', source, re.M)[1],16)
    raw = [int(x,16) for x in re.search(r'^def inputs : List Sig := \[(.*)\]$', source,re.M)[1].split(',')]
    assert len(raw) == 10
    for v, x in enumerate(raw):
        assert all((x >> s & 1) == (s >> v & 1) for s in range(1024))
    edges = {(a,b) for a,b in combinations(range(10),2) if table >> ((1 << a) | (1 << b)) & 1}
    assert len(edges) == 13
    truth = graph_truth(10,edges)
    assert all(bool(table >> s & 1) == truth[s] for s in range(1024))
    circ = json.loads((ROOT/'calculus/upper18.json').read_text())
    assert len(circ) == 18
    for op,a,b in circ:
        assert op in ('and','or') and 0 <= a < len(raw) and 0 <= b < len(raw)
        raw.append((raw[a]&raw[b]) if op=='and' else (raw[a]|raw[b]))
    assert raw[-1] == table
    print('raw graph', len(truth),'assignments',sum(truth),'positive',sorted(edges))
    for excluded in range(4,10):
        verts=set(range(10))-{excluded}
        inc = {v:{w for w in verts-{v} if tuple(sorted((v,w))) in edges} for v in verts}
        removed=0
        while (leaves:=[v for v in inc if len(inc[v])==1]):
            for v in leaves:
                x,=inc.pop(v)
                inc[x].remove(v)
                removed+=1
        x,y=sorted(v for v in inc if len(inc[v])==3)
        assert all(len(inc[v])==2 for v in set(inc)-{x,y})
        # Separate internal components after deleting the branch vertices.
        interior=set(inc)-{x,y}
        lengths=[1] if y in inc[x] else []
        while interior:
            start=next(iter(interior)); block={start}; todo=[start]
            for v in todo:
                for w in (inc[v]&interior)-block:
                    block.add(w);todo.append(w)
            assert len(inc[x]&block)==len(inc[y]&block)==1
            lengths.append(len(block)+1)
            interior-=block
        expect=[(2,(2,3,3)),(1,(1,4,4)),(2,(2,3,3)),(2,(2,3,3)),(1,(1,4,4)),(0,(1,4,5))]
        assert (removed,tuple(sorted(lengths)))==expect[excluded-4]
        print('deleted',excluded,'leaves',removed,'theta',sorted(lengths))


if __name__ == '__main__':
    original_crosswalk()
    for l, m in [((2,3,3),9477),((1,4,4),41153),((1,4,5),174501)]:
        n,edges=theta(l)
        a, survivors=candidates(n,graph_truth(n,edges))
        expect=[((4,10),(4,12))] if l[0]==2 else [((0,8),(1<<v,15)) for v in range(2,n)]
        assert a==m and survivors==expect
        print('theta',l,'rows',1<<n,'pairs',a,'survivors',survivors)
    _,toy=candidates(4,[bool(s&12) for s in range(16)])
    assert ((4,15),(8,15)) in toy and ((0,8),(4,15)) not in toy
    print('toy OR control passed')
