from pathlib import Path
import json,gzip,re,itertools
from collections import defaultdict,Counter
from pysat.card import CardEnc,EncType
D=Path('/dev/shm/04rank-proof170-45kyfyvh')
d=json.load(gzip.open('/dev/shm/04-merged-terms/joint181-pool-plus-near180.json.gz'));V=list(map(lambda x:int(x,16),d['truth']));F=(1<<1024)-1
assert len(set(V))==329
raw=[sum(1<<j for j in range(1024) if i in (j//32,32+j%32)) for i in range(64)]
assert V[:64]==raw
G=d['target'];assert V[G]==sum(int(w,16)<<(32*j) for j,w in enumerate(re.findall('0x[0-9a-fA-F]+',json.load(open('/tmp/pnp-official-20579-public.json'))['gap']['statement'])))
N={z:z-63 for z in range(64,329)}; pre=lambda z:N[z]+265
g=defaultdict(set);prod=defaultdict(list);uses=defaultdict(list);marks={};cl=[]; h=1074;entries=[]
def is110(v):return [(v>>k)&1 for k in (813,828,800)]==[1,1,0]
assert is110(V[G]) and not any(map(is110,raw))
for i,(z,o,*aa) in enumerate(d['recipes']):
 t=531+i;prod[z].append(t);cl.append([-t,N[z]])
 a,b=V[aa[0]],V[aa[-1]];assert z not in aa and V[z]=={'and':a&b,'or':a|b,'not':F^a}[o]
 if is110(V[z]) and not any(is110(V[k]) for k in aa):entries.append(t)
 for k in set(aa):
  if k in N:
   uses[k].append(t);g[z].add(k);cl.extend([[-t,N[k]],[-pre(z),-t,pre(k)]])
 if o=='not' and aa[0] in N:
  cl.append([-t,-pre(z)])
  if sum((V[z]>>(33*k)&1)<<k for k in range(6))==53:
   h+=1;marks[h]=z;cl.extend([[-h,t],[-h,pre(aa[0])]])
assert entries==[657,675,948,1028] and len(marks)==2
groups=[]
for z in N:
 cl.append([-N[z],*prod[z]])
 if len(prod[z])>1:groups.append(prod[z])
 if z!=G:cl.append([-N[z],*uses[z],*[k for k,v in marks.items() if z==v]])
cl.extend([[N[G]],list(marks),entries]);groups.append(list(marks))
seen={};post=[]
def dfs(v):
 if v in seen:return
 seen[v]=len(seen)
 for a in g[v]:dfs(a)
 post.append(v)
for z in N:dfs(z)
rev=defaultdict(set)
for z,aa in g.items():
 for a in aa:rev[a].add(z)
free=set(N);cc=[]
for z in reversed(post):
 if z not in free:continue
 todo=[z];com=set()
 while todo:
  a=todo.pop()
  if a not in free:continue
  free.remove(a);com.add(a);todo.extend(rev[a])
 if len(com)>1:cc.append(sorted(com,key=seen.get,reverse=True))
cc.sort(key=lambda c:post.index(c[-1]))
rank={};comp={}
for i,c in enumerate(cc):
 for z in c:
  comp[z]=i;b=list(range(h+1,h+len(c)));h+=len(b);rank[z]=b
  cl.extend([[-y,x] for x,y in zip(b,b[1:])])
for i,(z,o,*aa) in enumerate(d['recipes']):
 for a in set(aa):
  if z not in rank or comp.get(a)!=comp[z]:continue
  t=531+i;p=rank[z];q=rank[a];cl.extend([[-t,p[0]],[-t,-q[-1]]]);cl.extend([[-t,-x,y] for x,y in zip(q,p[1:])])
for group in groups:
 if len(group)<=8:cl.extend([[-a,-b] for a,b in itertools.combinations(group,2)])
 else:
  enc=CardEnc.atmost(group,1,top_id=h,encoding=EncType.seqcounter);h=enc.nv;cl.extend(enc.clauses)
enc=CardEnc.atmost(list(N.values()),170,top_id=h,encoding=EncType.cardnetwrk);cl.extend(enc.clauses);h=enc.nv
file=next(D.glob('*.cnf'));rows=file.read_text().splitlines();assert rows[0]==f'p cnf {h} {len(cl)}'
norm=lambda x:Counter(tuple(sorted(y)) for y in x)
assert norm(cl)==norm([list(map(int,l.split()))[:-1] for l in rows[1:]])
print(len(cl),h,entries,len(marks))
