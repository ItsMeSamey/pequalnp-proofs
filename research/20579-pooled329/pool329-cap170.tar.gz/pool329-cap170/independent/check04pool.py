import fcntl,hashlib,os,resource,subprocess,time
from pathlib import Path
D=Path('/dev/shm/04rank-proof170-45kyfyvh')
checker=Path('/workspace/scratch/syn_pruning/bank11/drat-trim')
cnf=next(D.glob('*.cnf'));proof=next(D.glob('*.drat'))
for p,h in [(checker,'4ef9e11c06e648f6fed570250bdcb48a161d33121ebce77462db7e5cdefcae1b'),(cnf,'c37977abf17cd3772f8cc8aa0a27e2fe24230f35d6e65baeb1e4e577dbae2a07'),(proof,'3b313e392dee8f594a40f10cfdd2a727cc87f53deb8da866593884d9afe70b4a')]:
 assert hashlib.sha256(p.read_bytes()).hexdigest()==h
def limits():
 os.nice(15);resource.setrlimit(resource.RLIMIT_CPU,(6,6));resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,)*2)
with open('/workspace/scratch/pnp-native-search.lock','a') as lock:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:raise SystemExit(75)
 st=os.fstat(lock.fileno()); pathst=os.stat('/workspace/scratch/pnp-native-search.lock')
 assert (st.st_dev,st.st_ino)==(pathst.st_dev,pathst.st_ino)
 tuplekey=f'{os.major(st.st_dev):02x}:{os.minor(st.st_dev):02x}:{st.st_ino}'
 rows=[l for l in Path('/proc/locks').read_text().splitlines() if f'FLOCK  ADVISORY  WRITE {os.getpid()} {tuplekey} ' in l]
 assert len(rows)==1
 print('lock',rows[0],flush=True)
 log=Path('/workspace/scratch/site-team-07/pool04-verifier.log')
 with log.open('wb') as f:
  p=subprocess.Popen([checker,cnf,proof],stdout=f,stderr=subprocess.STDOUT,preexec_fn=limits)
  start=time.monotonic()
  while p.poll() is None:
   try:rss=int(Path(f'/proc/{p.pid}/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
   except FileNotFoundError:continue
   if rss>100*1024**2 or time.monotonic()-start>12:p.kill();p.wait();raise RuntimeError('resource guard')
   time.sleep(.01)
 print('exit',p.returncode,'elapsed',time.monotonic()-start,'maxrss_kib',resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
 assert p.returncode==0 and b's VERIFIED' in log.read_bytes()

assert rows[0].split(': ',1)[1] not in Path('/proc/locks').read_text()
print('lock released',flush=True)
