"""Compile and optionally solve/verify physically schedulable 329-function gate cuts."""
import gzip,json,sys,time,itertools,hashlib,os,shutil,subprocess,resource,tempfile
from pathlib import Path
from pysat.card import CardEnc,EncType
D=Path(__file__).resolve().parent
catalog=Path('/dev/shm/04-merged-terms/joint181-pool-plus-near180.json.gz')
source=(D/'pooled317.py').read_text().split('if len(sys.argv)<2:sys.exit()')[0]
source=source.replace("(D.parent/'witness/joint181-pool.json.gz')","catalog").replace('==(317,481,18)','==(329,544,19)')
exec(source)
cap=int(sys.argv[1]);action=sys.argv[2] if len(sys.argv)>2 else 'stage';assert cap in (170,180)
def sha(b):return hashlib.sha256(b).hexdigest()
h=sha(blob);assert h=='b9f8bdaabf1785511a677a7a8a0301a512828845553a71c5b538c6b30ee4803e'
roots=(25*32+13,25*32+28,25*32+0)
def class110(v):return tuple(v>>i&1 for i in roots)==(1,1,0)
H={i for i,v in enumerate(vs) if class110(v)};assert not H.intersection(range(64)) and end in H
entries=[j for j,(z,op,vv) in enumerate(ops) if z in H and H.isdisjoint(vv)]
assert entries==[126,144,417,497]
lemma=[R[ops[j]] for j in entries];clauses.append(lemma)
# Explicit CNF for every cardinality, including raw-to-total pricing; no uncheckable native constraints.
for group in atmost:
 if len(group)<=8:
  clauses.extend([-a,-b] for a,b in itertools.combinations(group,2))
 else:
  enc=CardEnc.atmost(group,1,top_id=idx,encoding=EncType.seqcounter);idx=max(idx,enc.nv);clauses.extend(enc.clauses)
enc=CardEnc.atmost(list(N.values()),cap,top_id=idx,encoding=EncType.cardnetwrk);idx=max(idx,enc.nv);clauses.extend(enc.clauses)
hh=hashlib.sha256()
def chunks():
 yield f'p cnf {idx} {len(clauses)}\n'.encode()
 for c in clauses:yield (' '.join(map(str,c))+' 0\n').encode()
for data0 in chunks():hh.update(data0)
formula=hh.hexdigest();outdir=Path(os.environ.get('PNP_329_PRIVATE','/dev/shm/04rank-proof329'));outdir.mkdir(exist_ok=True)
prefix=outdir/f'k{cap}-{formula}';cnf=prefix.with_suffix('.cnf');proof=prefix.with_suffix('.drat');solverpath=D/'pooled317.py'
meta=dict(catalog_sha=h,cnf_sha=formula,compiler_sha=sha(Path(__file__).read_bytes()),structural_compiler_sha=sha(solverpath.read_bytes()),cap=cap,charged=len(N),raw=64,variables=idx,clauses=len(clauses),entry_recipe_indices=entries,entry_selector_lits=lemma,entry_certificate='raw indices have no 110 signature; first 110 node must use one of these recipes',cells=roots,marker_options=len(M))
near=d['approximate_controls'][0];assert not near['exact'];nr=near['output'];missing=(1<<roots[0])|(1<<roots[1]);assert vs[end]^vs[nr]==missing and not vs[nr]&~vs[end]
rows=near['warm_plan'];hints={}
for z,o,*aa in rows:hints[z]=o,tuple(sorted(aa))
def hint(comp):
 p=phases[1].copy()
 for (z,o,vv),j in R.items():
  if z in hints or z==end:
   if (z!=end and hints[z]==(o,tuple(sorted(vv)))) or (z==end and o=='or' and set(vv)=={nr,comp}):p.add(j)
   else:p.discard(j)
 for z,n in N.items():
  if z in hints or z in [end,comp]:p.add(n)
 return p
# Hints are never clauses/assumptions. In particular signal 328 and this OR are optional.
comp=[z for z,o,aa in ops if z==end and o=='or' and nr in aa]
fixes=sorted({a for z,o,aa in ops if z==end and o=='or' and nr in aa for a in aa if a!=nr})
meta['repair_hint_companions']=fixes
meta['goal']='Satisfiability of a charged physical DAG over the given catalogue at this cap, with first internal NOT mask 53.'
prefix.with_suffix('.meta.json').write_text(json.dumps(meta,sort_keys=True,indent=2));print(json.dumps(meta),flush=True)
if not cnf.exists():
 tmp=cnf.with_suffix('.cnf.tmp')
 with tmp.open('wb') as f:
  for chunk in chunks():f.write(chunk)
 tmp.replace(cnf)
assert sha(cnf.read_bytes())==formula
if action=='stage':sys.exit()
if action=='verify':
 assert proof.exists()
 checker=Path('/workspace/scratch/syn_pruning/bank11/drat-trim');v=subprocess.run([str(checker),str(cnf),str(proof),'-i'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(v.stdout[-900:]);assert 's VERIFIED' in v.stdout and v.returncode==0
 print('verified formula',formula,'proof',sha(proof.read_bytes()),'checker',sha(checker.read_bytes()));sys.exit()
assert action=='solve'
import pysolvers
from pysat.solvers import Cadical195
tempfile.tempdir=str(outdir)
deadline=time.process_time()+float(sys.argv[3])
with Cadical195(bootstrap_with=clauses,with_proof=True) as sl:
 ans=None;ph=hint(266);sl.set_phases([i if i in ph else -i for i in range(1,max(R.values())+1)])
 while time.process_time()<deadline:
  sl.conf_budget(100);ans=sl.solve_limited()
  if ans is None:
   pysolvers.flushpr(sl.prfp)
   if os.fstat(sl.prfile.fileno()).st_size>3*1024**2:break
   continue
  if ans is False:
   pysolvers.flushpr(sl.prfp);sl.prfile.seek(0)
   with proof.open('wb') as f:shutil.copyfileobj(sl.prfile,f)
   print('UNSAT; DRAT written awaiting independent verification',proof,sha(proof.read_bytes()),flush=True);break
  model=set(sl.get_model());plan={z:(o,aa) for (z,o,aa),k in R.items() if k in model}
  marker=next(z for k,(z,_,_) in M.items() if k in model);net,_=build(plan,marker)
  b=json.dumps(net,separators=(',',':')).encode();p=outdir/f'circuit-{len(net["gates"])}-{sha(b)}.json';p.write_bytes(b);res=check(p)
  assert res['mismatches']==0 and res['shard']==53 and res['gates']<=cap;print('SAT',p,res,flush=True);break
 else:print('UNKNOWN',sl.accum_stats(),flush=True)
 if time.process_time()<deadline and ans is None:print('UNKNOWN proof-size guard',sl.accum_stats(),flush=True)
