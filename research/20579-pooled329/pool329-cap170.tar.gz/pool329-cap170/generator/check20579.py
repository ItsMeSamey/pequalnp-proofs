"""Independently replay a 20579 circuit on all ordered singleton input pairs."""
import argparse
import json
import re
from pathlib import Path


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate property {key}")
        result[key] = value
    return result


def target_rows():
    public = json.loads(Path('/tmp/pnp-official-20579-public.json').read_bytes())
    gap = public['gap']
    if gap['id'] != 'L-meta-20579' or public['shard'] != 53:
        raise ValueError("wrong public task")
    rows = [int(word, 16) for word in re.findall(r'0x[0-9a-fA-F]+', gap['statement'])]
    if len(rows) != 32 or any(word >> 32 for word in rows):
        raise ValueError("invalid target rows")
    return rows


def check(path):
    rows = target_rows()
    obj = json.loads(path.read_bytes(), object_pairs_hook=unique_object)
    if type(obj) is not dict or set(obj) != {'gates', 'output'} or type(obj['gates']) is not list:
        raise ValueError("expected gates array and output index")
    operations = []
    first_internal_not = None
    for i, gate in enumerate(obj['gates'], 64):
        if type(gate) is not dict or set(gate) != {'op', 'inputs'}:
            raise ValueError(f"bad gate {i}")
        op, args = gate['op'], gate['inputs']
        if op not in ('and', 'or', 'not') or type(args) is not list or len(args) > 2:
            raise ValueError(f"bad operation or arity at {i}")
        if any(type(j) is not int or j < 0 for j in args):
            raise ValueError(f"bad wire at {i}")
        operations.append((op, args))
        if op == 'not' and args and 64 <= args[0] < i and first_internal_not is None:
            first_internal_not = i
    out = obj['output']
    if type(out) is not int or out < 0:
        raise ValueError("bad output")
    mask = 64 if first_internal_not is None else 0
    errors = 0
    for u in range(32):
        for v in range(32):
            wires = [False] * 64
            wires[u] = wires[32 + v] = True
            for op, args in operations:
                values = [wires[j] if j < len(wires) else False for j in args]
                if op == 'not':
                    wires.append(not (values[0] if values else False))
                elif op == 'and':
                    wires.append(all(values))
                else:
                    wires.append(any(values))
            actual = wires[out] if out < len(wires) else False
            errors += actual != ((rows[u] >> v) & 1)
            if first_internal_not is not None and u == v and u < 6:
                mask |= int(wires[first_internal_not]) << u
    valid = errors == 0 and mask == 53
    return dict(gates=len(operations), shard=mask, mismatches=errors, valid_in_range=valid,
                accepted=valid and len(operations) <= 170)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate', type=Path)
    args = parser.parse_args()
    try:
        result = check(args.candidate)
    except (ValueError, OSError) as exc:
        parser.exit(2, f'{exc}\n')
    print(json.dumps(result))
    raise SystemExit(0 if result['accepted'] else 1)
