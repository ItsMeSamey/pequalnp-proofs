"""Exact 305-function catalogue selection with SCC-local physical evaluation ranks."""
import collections,gzip,hashlib,json,sys,time,math
from pathlib import Path
from pysat.solvers import Minicard
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D.parent))
from check20579 import check,target_rows
src=(D.parent/'witness/joint181-pool.json.gz');blob=src.read_bytes();d=json.loads(gzip.decompress(blob))
vs=[int(x,16) for x in d['truth']];end=d['target'];F=(1<<1024)-1;ops=[(z,o,tuple(a)) for z,o,*a in d['recipes']]
assert (len(vs),len(ops),len(d['controls']))==(317,481,18)
assert vs[end]==sum(r<<(32*i) for i,r in enumerate(target_rows()))
raw=[sum(1<<(32*u+v) for u in range(32) for v in range(32) if i in (u,32+v)) for i in range(64)];assert vs[:64]==raw
for z,o,aa in ops:
 a,b=vs[aa[0]],vs[aa[-1]];assert vs[z]==(a&b if o=='and' else a|b if o=='or' else F^a)
idx=0;clauses=[];atmost=[]
def fresh():
 global idx
 idx+=1;return idx
N={z:fresh() for z in range(64,len(vs))};pre={z:fresh() for z in N};R={r:fresh() for r in ops};M={}
ins=collections.defaultdict(list);cons=collections.defaultdict(list);dep=collections.defaultdict(set)
for (z,o,aa),t in R.items():
 ins[z].append(t);clauses.append([-t,N[z]])
 for a in set(aa):
  if a<64:continue
  dep[z].add(a);cons[a].append(t);clauses.append([-t,N[a]]);clauses.append([-pre[z],-t,pre[a]])
 if o=='not' and aa[0]>=64:
  clauses.append([-t,-pre[z]])
  if sum((vs[z]>>(33*i)&1)<<i for i in range(6))==53:
   k=fresh();M[k]=(z,t,aa[0]);clauses.extend([[-k,t],[-k,pre[aa[0]]]])
for z in N:
 clauses.append([-N[z],*ins[z]])
 if len(ins[z])>1:atmost.append(ins[z])
 if z!=end:clauses.append([-N[z],*cons[z],*[k for k,(q,_,_) in M.items() if q==z]])
clauses+=[[N[end]],list(M)];atmost.append(list(M))
# Tarjan partitions the union of all possible internal dependencies before assigning ranks.
visit={};low={};stack=[];pending=set();components=[]
def tarjan(z):
 visit[z]=low[z]=len(visit);stack.append(z);pending.add(z)
 for a in dep[z]:
  if a not in visit:tarjan(a);low[z]=min(low[z],low[a])
  elif a in pending:low[z]=min(low[z],visit[a])
 if low[z]==visit[z]:
  cc=[]
  while True:
   a=stack.pop();pending.remove(a);cc.append(a)
   if a==z:break
  components.append(cc)
for z in N:
 if z not in visit:tarjan(z)
# Use monotone rank thresholds, only within SCCs with possible cycles.
# A selected dependency child→parent advances rank by ≥1.
comp={v:k for k,cc in enumerate(components) for v in cc}
ranks={}
for cc in components:
 if len(cc)==1:continue
 for v in cc:
  b=[fresh() for _ in range(len(cc)-1)];ranks[v]=b
  for j in range(1,len(b)):clauses.append([-b[j],b[j-1]])
for (z,o,aa),t in R.items():
 for a in set(aa):
  if a not in ranks or z not in ranks or comp[a]!=comp[z]:continue
  p,c=ranks[z],ranks[a];clauses.extend([[-t,p[0]],[-t,-c[-1]]])
  for j in range(len(p)-1):clauses.append([-t,-c[j],p[j+1]])
def build(plan,mz):
 gates=[];ws={i:i for i in range(64)}
 def go(z):
  if z not in ws:
   o,aa=plan[z];pins=[go(a) for a in aa];gates.append(dict(op=o,inputs=pins));ws[z]=len(gates)+63
  return ws[z]
 go(mz);out=go(end);return dict(gates=gates,output=out),ws
phases=[]
for ctl in d['controls']:
 plan={z:(o,tuple(a)) for z,o,*a in ctl['warm_plan']};mk=ctl['warm_marker'];net,ws=build(plan,mk)
 assert len(net['gates'])==ctl['warm_cost']
 phase={N[z] for z in ws if z>=64}|{R[z,*plan[z]] for z in ws if z>=64}
 root=next(k for k,(z,t,a) in M.items() if z==mk and t in phase);phase.add(root);todo=[M[root][2]]
 while todo:
  z=todo.pop()
  if z<64 or pre[z] in phase:continue
  phase.add(pre[z]);todo.extend(plan[z][1])
 for cc in components:
  order=sorted((z for z in cc if z in ws),key=ws.get)
  for j,z in enumerate(order):phase.update(ranks.get(z,())[:j])
 assert all(any((abs(a) in phase)==(a>0) for a in cl) for cl in clauses)
 assert all(sum(x in phase for x in group)<=1 for group in atmost)
 phases.append(phase)
print('catalog',hashlib.sha256(blob).hexdigest(),'nodes',len(N),'recipes',len(R),'marker options',len(M),'cyclic SCC sizes',[len(c) for c in components if len(c)>1],'rank bits',sum(map(len,ranks.values())),'clauses',len(clauses),'validated warm',[c['warm_cost'] for c in d['controls']],flush=True)
if len(sys.argv)<2:sys.exit()
cap=int(sys.argv[1]);duration=float(sys.argv[2]);deadline=time.process_time()+duration
with Minicard(bootstrap_with=clauses) as sl:
 for group in atmost:sl.add_atmost(group,1)
 sl.add_atmost(list(N.values()),cap)
 j=0
 while time.process_time()<deadline:
  phase=phases[j%len(phases)];j+=1;sl.set_phases([v if v in phase else -v for v in range(1,idx+1)])
  sl.conf_budget(500);ans=sl.solve_limited()
  if ans is None:continue
  if not ans:print('UNSAT full catalogue under cap',cap,sl.accum_stats(),flush=True);break
  model=set(sl.get_model());plan={z:(o,aa) for (z,o,aa),t in R.items() if t in model}
  marker=next(z for k,(z,_,_) in M.items() if k in model);net,_=build(plan,marker)
  b=json.dumps(net,separators=(',',':')).encode();h=hashlib.sha256(b).hexdigest();p=Path('/dev/shm')/f'04rank-pool-{len(net["gates"])}-{h}.json';p.write_bytes(b);res=check(p);assert res['mismatches']==0 and res['shard']==53 and res['gates']<=cap
  print(p,res,flush=True);break
 else:print('UNKNOWN',sl.accum_stats(),flush=True)
