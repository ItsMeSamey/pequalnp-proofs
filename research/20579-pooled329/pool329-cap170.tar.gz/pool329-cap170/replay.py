from pathlib import Path
import hashlib,sys,subprocess,tempfile
r=Path(__file__).resolve().parent
for line in (r/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
if sys.argv[1:]==['binding']:
 src=(r/'independent/audit04pool.py').read_text()
 for a,b in [('/dev/shm/04rank-proof170-45kyfyvh',str(r)),('/dev/shm/04-merged-terms/joint181-pool-plus-near180.json.gz',str(r/'catalogue.json.gz')),('/tmp/pnp-official-20579-public.json',str(r/'public-task.json'))]:
  src=src.replace(a,b)
 exec(compile(src,'independent/audit04pool.py','exec'))
elif sys.argv[1:]==['proof']:
 p=subprocess.run([str(r/'checker/drat-trim'),str(r/'catalogue.cnf'),str(r/'refutation.drat'),'-i'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 assert p.returncode==0 and b's VERIFIED' in p.stdout,p.stdout[-800:]
 print('s VERIFIED')
elif sys.argv[1:]:
 raise SystemExit('use: python replay.py [binding|proof]')
else:print('All payload checksums match.')
