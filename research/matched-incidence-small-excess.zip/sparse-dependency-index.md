# 8573 sparse range, source proof index

Use n vertices per shore, m edges, q gates. The conclusion is q≥m+n−1. The matching and both extra-neighbor hypotheses give n>0 and minimum degree two, hence m≥2n. Strict binary least AO implies all gates live and all 2n inputs essential; the physical excess is X=q−2n+1. The emitter cover size e, fork count f and X satisfy n≤e≤f≤X (small-excess-proof.md). Terminal means an unbranched route from the raw to the output; it is a physical incidence condition, not a truth-table identity.

* m=2n: X≥n gives q≥3n−1. At m=2n+1, a violation implies q≤3n−1, hence X=e=f=n. The equality analysis in small-excess-proof.md gains the last gate. No top-form dirty hypothesis needed in those two cases.
* m=2n+2: a violation is exactly q≤3n or X≤n+1. If X=n, f=e=n and all outlets double. If X=n+1,f=n, all are emitters and exactly one fork is triple. If X=f=n+1 all forks are double and e=n or n+1. No other rank profile can violate. Raw and computed emitter forks are both admitted.
* e=n,f=n: all Z terminal. e=n,f=n+1: there is one exceptional K. If its fresh set W is empty the other raws are terminal. For W nonempty, nonempty-exceptional-fork.md handles W of size ≥2 or singleton with K({w})=0 by port charging. For W={w}, K({w})=1, promote w; K has singleton support {w}, permitting the terminal charging proof without asserting K=w. e=n+1,f=n+1: all forks are emitters, Z terminal directly.
* In the terminal interface S is the chosen set, Z its independent complement. Put s=|S|, h=|E[S]|, d=m−h. The matching has exactly s−n internal edges; degree sum on Z gives s−n≤h≤2(s−n)+2. For s=n only h=0,1,2, covered by near-saturated-terminal.md. For s=n+1 only h=1,2,3,4; h=1,2 are covered there including its final third-gate lemma. Promoted profiles reach h=2,3,4. Do not charge a promoted K as a literal raw. Read nonempty-exceptional-fork.md with emitter-terminal-ports.md.
* For s=n+1 the disjoint baseline, where established by each high-h proof, is d+|Z|−1=3n−h. Thus h+1 additional distinct gates yield the required 3n+1 (four extras at h=3, five at h=4). An isolated vertex does not affect the internal-edge shape.

The induced graph is simple and bipartite. Its shortest possible cycle has length at least six by rectangle-freeness, so with up to four edges it is a forest. The following catalog is exhaustive by partitioning the number of edges among nontrivial connected components. Pk denotes a path on k vertices.

| h | All shapes | Source |
|---|---|---|
| 0,1,2 | Empty; K2; P3 or 2K2 | near-saturated-terminal.md |
| 3 | K1,3, P4, P3+K2 | h3-nonmatching.md |
| 3 | 3K2 | three-internal-matching.md |
| 4 | K1,4 or P5 | four-connected-injector-charge.md |
| 4 | Five-vertex tree with degrees 3,2,1,1,1 | h4-t-tree.md |
| 4 | K1,3+K2, P4+K2, 2P3, P3+2K2 | h4-disconnected-nonmatching.md. Independent parallel sources for the first three shapes: h4-star-and-edge.md, four-internal-path-plus-edge.md, two-internal-stars.md |
| 4 | 4K2 | four-internal-matching.md |

This index checks the logical partition, its arithmetic and file identities. Individual manuscripts supply the gate charges. It is not independent verification of all those charges, a compiled Lean theorem, or coverage for m≥2n+3. The one-exceptional-column lemma has a different physical premise and is not needed for this dispatch.

The nonempty exceptional-fork receipt now states the exact m=2n+2 scope. Team 09/w03 reported a scoped pass on that component.

## Frozen source SHA-256

4155932417d1b79d08bcc7f43ff1f00646aa2c2492208d76530fd16428246776  small-excess-proof.md
a37f52007eb0910ea910ad552f2074cc066537191fecc272f8d825245b6a22df  near-saturated-terminal.md
01858749daa81083234c62183ba0010e58f8dcfd2a694cb88d939609c0376c7d  nonempty-exceptional-fork.md
35839acdadd465b229997f92cc41aaf7fe1e25fd10e8e0cbd8b2e315e89777f8  emitter-terminal-ports.md
a087ce3a9c40cb2c98aa114a1353e6e502dcd88abe4f7e835218c5e33f7f2b21  h3-nonmatching.md
e52e2c73500eab4a95d2d4b27ef798c1ab84e482236e5ba26d06b7b7b2dd9117  three-internal-matching.md
7329f81155a3ef4bb86490feb11ffad5a25d0c5d3670d3997cf1ff3237a0a0f0  four-connected-injector-charge.md
fef03d689928dd0f0ab2388276832ac53519219922947116027b75c04da06b84  h4-t-tree.md
b5db43a4aadac37ecacd57bfabafc49f8cae7ae6741e6512e6d49619df0e7065  h4-disconnected-nonmatching.md
7aacbf677619629a4d1e77242a498315380df2ff08f5c89a927d13c04aa12ab3  h4-star-and-edge.md
f56e277680e01be8566ab30783557b34def8a660dd5bf8d3865c3a9a84ac6c46  four-internal-path-plus-edge.md
1549128e9dfb2b13559bc6edebadaea17370ceb537541f439f0df3fbec200fee  two-internal-stars.md
58d762856fbc143560d7c2aa11f1aa6e65ac65b7987fff625bbb3308bad6d687  four-internal-matching.md
