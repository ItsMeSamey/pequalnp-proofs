# Two disjoint internal two-edge stars

Assume m=2n+2, n+1 emitter vertices S, n−1 terminal vertices Z whose
paths to output are all unique, and I=G[S] consists of stars a:{b,c}
and d:{e,f} plus isolates. All N(z) have size two by incidence counting.
Write D=2n−2 for the cross-edge count.

Use the bearing-join and independent-complement tests of h3-nonmatching.md.
Specifically all |Z|−1 two-bearing joins are ORs by testing two terminals
on an independent pair of neighborhood representatives (C4 ensures one
exists). For z with N(z) on shore A, omit N(z) and the opposite endpoints
of all internal edges whose A end lies outside N(z). The remaining raw
assignment is independent. A selected pure guard rejects it and accepts
both singletons of N(z), yielding one distinguished bearing AND and a
pure OR with the same two singleton witnesses and rejection (trace the
two labels through a rejecting child at AND and accepting children at OR).
Same-shore charges cannot coincide by C4. For opposite-shore sharing,
each of the two selected A labels needs an internal edge to an unselected
B, and vice versa. The four witnesses are distinct and exhaust I. Every
selected label thus has internal degree one: each edge has exactly one
selected endpoint and all four labels have been used. The four selected
labels must be the four leaves. If the centers are on the same shore, the
leaves are all on the other shore. Otherwise each same-shore pair of
leaves already shares a center, and cannot both neighbor a terminal. This
rules out shared charges both for ANDs and for ORs. Baseline D+|Z|−1.

Let t be the number of bearing ORs injecting a pure operand (t≥1);
these are extra gates. For each injector fix a terminal z below its
bearing child. If an I-independent support X activates the pure operand,
then N(z) is contained in the open I-neighborhood of X: add each b∈N(z)
at all terminals low. The injector is high and all downstream AND guards
are high since each must accept the singleton b to transmit zb. Hence
X union {b} contains an internal edge. In particular an injector operand
accepts no singleton, by C4 and |N(z)|=2. Every I-positive input activates
some injector at zero terminals, by tracing the output back.

There are at least two pure ANDs. With none all pure operands accept a
singleton. With exactly one, every singleton-free nonzero pure operand
is equivalent to this AND: every path to it from a raw must meet the
AND or it passes its singleton via ORs. This AND is a product of disjoint
nonempty raw disjunctions. Its rectangle must cover ab and de. It also
covers the two complementary cross pairs of these two edges, obtained
by interchanging their endpoints across the rectangle factors. Both
cross pairs are independent; their internal neighborhoods are disjoint
because the neighbors of a center and of a leaf of the same star are
disjoint. They cannot both dominate one fixed N(z).

If the centers are on the same shore take C={a,e,f}. Otherwise take
C={b,c,e,f}. Both are inclusion-minimal vertex covers of I. No C contains
a complete terminal neighborhood: every pair within C on the same shore
already shares a star center. Thus S minus C, an independent set with
I-neighborhood contained in C, activates no injector.

Form the disjunction P of all t pure operands using t−1 fictitious ORs.
It is true on every internal edge and false on S minus C. At each pure
AND false on S minus C select a fixed false child; elsewhere select an
arbitrary child. This simultaneous replacement increases signals and
preserves original false signals on S minus C by induction. The output
now consists solely of an OR of raws contained in C hitting every edge;
it must use all C by minimality. The connected projected output cone has
at least |C|−1 binary ORs. At most t−1 are fictitious. Each traced
physical OR originally accepted singleton labels only within C, since it
feeds the projected output via ORs and projections only increased signals.
Hence none of its gates is a baseline charged pure OR, each of which
accepts a complete N(z). At least |C|−t new pure ORs are paid.

Adding t injectors, at least two pure ANDs, and the new pure ORs gives
at least |C|+2≥5 additional gates. Thus q≥D+|Z|+4=3n+1=m+n−1.
Source argument; no kernel verification.
