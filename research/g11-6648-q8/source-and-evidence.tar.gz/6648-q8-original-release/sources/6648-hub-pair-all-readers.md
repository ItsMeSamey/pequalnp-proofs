# K1,3 plus K2 at q=8, j=3, c=0

The size-21 original least candidate with this four-edge star mask is excluded for every reader type. The source branches are:
 
* Bare isolated edge: 6648-four-star-hub-disjoint-bare.md, 251f194ad5c91788e2d7efd018ce3694dd0bc554cc7baaf6687d1afefcf7c6fd.
* Nonbare, three imports: twin_6648_q8_hub_pair_nonbare_three.md, 92b6972a44de475f1987df1c7870a7ccf2496e38bca4fc0f38707dc9fd0d6207.
* Nonbare, four imports: 6648-four-star-hub-disjoint-four-imports.md, e748fe90ffae3d87e4f3cbbf2d5884ffd08808e8ed88a719cd9cd24360d5d02b.

For exhaustiveness, the original star cover of size two implies that at most one dirty AND is raw-mandatory by premises_6648_one_surviving_donor_all_stars.md. The five exterior labels therefore require at least four exterior OR readers, leaving at most four imports. An exterior graph edge exists since the independence number is four. It needs two opposite imports in the same ordinary top. With exactly two imports and a nonbare isolated pair these must be one per isolated side. The augmented-augmented joint top then subsumes the raw-raw product and excludes other terminals by fusion; the pure three-star component needs only its hub times a single leaf union. These two decoder ANDs plus three original dirty ANDs violate L_meta_17134 on a low false card. Zero and one import cannot accept the exterior edge. This wrapper combines source proofs, with no additional numerical or Lean check.
