"""Graph-only relaxation for six outsiders, three raw-mandatory distinct labels.
Usage: python3 file.py START END, exclusive wedge-mask index range.
A survivor is not a gate realization. Execution requires team scheduler.
"""
import itertools
import sys
from functools import lru_cache

EDGES = ((0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),
         (4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9))
V = (1<<11)-1
EM = tuple((1<<a)|(1<<b) for a,b in EDGES)

def submasks(mask):
    u = mask
    while True:
        yield u
        if not u:
            break
        u = (u-1)&mask

def maximal_independent(domain,edges):
    independent = {s for s in submasks(domain) if all(s&e!=e for e in edges)}
    return sorted(s for s in independent if not any(s|v in independent for v in
                  (1<<k for k in range(11) if (domain^s)>>k&1)))

@lru_cache(None)
def graph_mis(domain):
    return maximal_independent(domain,[e for e in EM if e&domain==e])

def wedge_masks():
    for stars in itertools.combinations(EM,3):
        w = stars[0]|stars[1]|stars[2]
        if w.bit_count()!=5:
            continue
        for i,j,k in ((0,1,2),(1,2,0),(2,0,1)):
            hub = stars[i]&stars[j]
            if hub and not stars[k]&(stars[i]|stars[j]):
                yield stars,w,hub,stars[k]
                break

def witnesses(stars,w,hub,de):
    outside = V^w
    for R in submasks(outside):
        if R.bit_count()!=3:
            continue
        domain = V^R
        Y = domain^w
        if any(Y&e==e for e in EM):
            continue
        if any(len(graph_mis(domain^(hub|p)))>3
               for p in (de&-de,de^(de&-de))):
            continue
        residual = [e for e in EM if e&domain==e and e not in stars]
        # Complements of inclusion-minimal clauses covering all residual edges.
        opt = maximal_independent(domain,residual)
        mis = graph_mis(domain)
        full = (1<<len(mis))-1
        exclusions = [sum(1<<i for i,s in enumerate(mis) if s&t==s) for t in opt]
        for k,g in enumerate(opt):
            if Y&g!=Y:
                continue
            need = full & ~exclusions[k]
            for i,a in enumerate(opt):
                for j in range(i,len(opt)):
                    if need & ~(exclusions[i]|exclusions[j]):
                        continue
                    yield R,domain^a,domain^opt[j],domain^g
                    break
                else:
                    continue
                break
            else:
                continue
            break

if __name__=='__main__':
    lo,hi=map(int,sys.argv[1:3])
    cases=found=0
    for n,(stars,w,hub,de) in enumerate(wedge_masks()):
        if not lo<=n<hi:
            continue
        cases+=1
        for row in witnesses(stars,w,hub,de):
            print(n,*stars,*row,flush=True)
            found+=1
    print('totals',lo,hi,cases,found,flush=True)
