# Three exterior raw-mandatory dirty gates at q=8 in the P3+K2 star mask

Assume the original least 21-gate TopForm G11 circuit, c=0,j=4,q=8, three ordinary stars al,ar,de on W={a,l,r,d,e}. The exterior O has six vertices and its induced graph has cover number at least two since τ(G)=7. Let three dirty gates directly read exterior raw variables, and denote their labels by R. The labels must be distinct: if two coincide set R false together with the star cover {a,d}. This fixes at most four labels and kills three dirty gates, impossible by the one-surviving-donor cover bound. Write F for the fourth dirty gate and Y=O minus R. Four raw-mandatory dirty gates would themselves be impossible: their raw labels together with a,d would cover G in six vertices. This proof uses a finite graph-only relaxation followed by a physical exclusion of every survivor.

## Exact relaxation

On G−R, all three mandatory gates are false, and F reduces to a product of two raw clauses P,Q. The ordinary tops retain all three matched/star products on raw inputs. A term outside those stars can only be F times a raw opposite guard. A top could not originally have F on both sides by OR-only paths, since it would accept an independent F-positive witness. Thus exactly on this eight-vertex cube,

    graph(G−R) = graph(S) OR ((OR P) AND (OR Q) AND (OR K)),

where S is the original three-edge star mask and K⊆W pools all appropriate opposite raw sides. Empty clauses and empty K are allowed. Y must be independent. On deleting either {a,d} or {a,e} as well, the graph is precisely a product of at most three clauses and so has at most three maximal independent sets.

The finite filter takes each three-edge subset in the fixed G edge order with a unique intersecting pair and a third edge disjoint from that pair. For each three-subset R of its exterior, it checks Y independence and both maximal-independent-set bounds, then the displayed exact product. Put J=(G−R) minus S. Each of P,Q,K is a vertex cover of J. Replacing each by any inclusion-minimal subcover retains all residual edges by construction and all star edges by the separate term; shrinking cannot introduce a false positive. Conversely three covers work if every maximal independent set of G−R is disjoint from at least one of them. The complements of the candidate minimal covers are exactly the maximal independent sets of J, with the complement of the K candidate required to contain all of Y. Enumerating these triples therefore decides precisely the displayed relaxation, including across both star covers simultaneously. The columns in this step apply to the actual circuit restriction R=false, not a change of the original star definitions.

Canonical source 6648-q8-p3-r3-shared-clauses.py (SHA-256 cc29aefca5684daedfa8d374d112fc93b5b0428dcefb8b085b58685e888bb46f) ran with guard 6648-q8-p3-r3-guard.py (65f29e8be11eaef50e52363e0c59a947659b0e391749a4b1738fd67b202ffa04). The ledger 6648-q8-p3-r3-graph-results.jsonl (9d257adc4212f832ca720d007d9abbe0cb34bce7a34b73e463f41d155456ae88) covers all 299 physical masks, consecutively indexed from zero; of 299×20 potential mask/R placements, 18 passed on 12 masks. Every passing triple of clauses was replayed on all 256 restricted assignments. For every survivor, the following table gives t∈Y adjacent to both d and e, and an edge from Y to P3. A repeated witness applies individually to every listed survivor for the same index; no presumption about failing rows is used.

| Mask index | de | t | Y-to-P3 edge |
|---|---|---|---|
| 11 | 14 | 8 | 2–5 |
| 110 | 14 | 8 | 0–9 |
| 119 | 37 | 6 | 0–10 |
| 121 | 14 | 8 | 0–9 |
| 136 | 14 | 8 | 0–9 |
| 151 | 18 | 4 | 0–10 |
| 152 | 36 | 7 | 0–9 |
| 169 | 18 | 4 | 0–10 |
| 174 | 37 | 6 | 0–10 |
| 181 | 36 | 7 | 0–9 |
| 236 | 36 | 7 | 0–9 |
| 250 | 37 | 6 | 0–10 |

## Physical contradiction on the retained placements

Let b count direct exterior-raw OR readers. At b=3 or less there must actually be three and all exterior readership is tight: reserving private readers and two incidences for multiply read variables gives b+3≥6. A tight AND reader, unable to read two exterior raws, is private and reads a label in R. Thus Y sees exactly three exterior-reader ORs. These are either three private OR readers or the three pairwise raw ORs among Y (multiple readers form a simple 2-regular graph, and two duplicate ORs would violate leastness). The latter form is impossible: any two labels in Y set all three ORs true. Any original maximal independent set containing two would then have to contain the third, since adding it cannot change an OR and its omission would contradict maximality. The three independent Y labels cannot satisfy this. If some has degree ≥3, its two nonneighbors in Y avert at most two neighbors by C4-freeness, permitting a maximal independent extension of the other two omitting that vertex. Otherwise the triple is drawn from the four degree-two labels 0,1,2,3 and includes 1 or 3, whose neighbors are disjoint from the others' neighborhoods. The same extension is available.

The private OR case is also impossible. Every t in the table belongs to {4,6,7,8}. For each there is a neighbor v with N(v)⊆N[t]: choose v=1 for 4 or 8 and v=3 for 6 or 7. Such a t cannot have an original sole OR reader, by the forbidden-sole-OR lemma in the published free-neighbor theorem. Thus b≥4.

Let h count the positive-W/raw-empty OR imports on ordinary raw traces. The original P3+K2 ledger for 2t_top+λ=10 gives h≥3; if h=3 all occur in P3 and the isolated matched group is a bare d∧e. This cannot agree with the table on R=false: positive inputs td and te have no P3 raw label and only one active dirty signal available, hence only the de group could win; a bare group cannot do so. Since imports are distinct paid gates from exterior raw readers, q=8 now forces b=h=4. There is no raw-empty OR available (it would itself be paid). Thus all imports receive literal dirty ANDs on their empty sides. The ordinary pin traces have disjoint raw groups {a}, subsets of {l,r}, {d}, and {e}.

Return to the positive input td with R=false. Only F may be active. Since only t and d are raw-true, no ordinary top outside the de group could win: both its raw sides would be false and F cannot occur on opposite sides. In the winning de term the singleton e-side must import F. The input te independently forces an F-import on the d-side. The table's Y-to-P3 edge likewise needs F on a P3 side. These are three different physical imports, since distinct raw groups cannot share a positive wire. At most one of the four imports can now receive any dirty donor other than F.

On the full original graph, every positive exterior edge activates two distinct dirty suppliers on opposite sides of a winning ordinary product. Pure exterior raw labels do not reach these pins. With four direct imports and no raw-empty OR there is at most one visible supplier other than F, and it is one of the three raw-mandatory donors. If this supplier does not exist, no exterior edge can be positive. Otherwise its one mandatory label meets every exterior edge, contradicting τ(G[O])≥2. This completes the g=3 exclusion; combine with the separate small-g proof at 2c266ede… for the entire original P3+K2 branch. The graph-only census is not an original-circuit census or a Lean proof.
