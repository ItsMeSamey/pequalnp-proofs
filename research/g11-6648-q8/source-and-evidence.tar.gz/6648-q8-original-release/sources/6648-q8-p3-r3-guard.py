"""Canonical single-slot q8 P3+K2 exterior-raw graph predicate runner."""
from pathlib import Path
from importlib.util import spec_from_file_location,module_from_spec
import os,fcntl,time,signal,resource,hashlib,json,sys
base=Path(__file__).resolve().parent
src=base/'6648-q8-p3-r3-shared-clauses.py'
pin='cc29aefca5684daedfa8d374d112fc93b5b0428dcefb8b085b58685e888bb46f'
assert hashlib.sha256(src.read_bytes()).hexdigest()==pin
lock=Path('/workspace/scratch/pnp-native-search.lock')
lo,hi=map(int,sys.argv[1:])
assert 0<=lo<hi<=560
ident=lambda s:(s.st_dev,s.st_ino)
assert ident(lock.stat())==(27,193638)
with lock.open('rb') as f:
    fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
    def guard():
        assert ident(os.fstat(f.fileno()))==ident(lock.stat())==(27,193638)
        assert any(l.split()[1:6]==['FLOCK','ADVISORY','WRITE',str(os.getpid()),'00:1b:193638']
                   for l in Path('/proc/locks').read_text().splitlines())
    guard()
    resource.setrlimit(resource.RLIMIT_CPU,(4,4))
    resource.setrlimit(resource.RLIMIT_AS,(96<<20,96<<20))
    signal.setitimer(signal.ITIMER_REAL,7)
    t=time.monotonic();spec=spec_from_file_location('filter_r3',src)
    m=module_from_spec(spec);spec.loader.exec_module(m)
    # Two raw-star-cover cuts, tested positively and negatively on original G11 domains.
    for single in (3,6):
        tri=(1<<3)|(1<<6)|(1<<7)
        assert len(m.graph_mis(tri^(1<<single)))==2
        # Disjoint edge 14 plus the retained triangle edge has exactly 4 MISs.
        assert len(m.graph_mis((tri^(1<<single))|(1<<1)|(1<<4)))==4
    cases=list(m.wedge_masks())
    assert len(cases)<=560 and len(set(c[0] for c in cases))==len(cases)
    stop=min(hi,len(cases)); assert lo<stop
    output=base/'6648-q8-p3-r3-graph-results.jsonl'
    with output.open('a') as out:
        for idx in range(lo,stop):
            stars,w,hub,de=cases[idx]; rows=list(m.witnesses(stars,w,hub,de))
            # Verify any saved witness independently on all 256 rows of the restricted cube.
            for R,p,q,z in rows:
                assert R.bit_count()==3 and not R&w and not z&~w
                for s in m.submasks(m.V^R):
                    assert any(s&e==e for e in m.EM)==(any(s&e==e for e in stars) or bool(s&p and s&q and s&z))
            guard()
            print(json.dumps(dict(index=idx,stars=stars,rows=rows,next=idx+1,
               source=pin,total=len(cases),controls=True,cpu=time.process_time(),wall=time.monotonic()-t,
               pid=os.getpid(),rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),sort_keys=True),file=out,flush=True)
            if time.process_time()>=3.25 or time.monotonic()-t>=5.7:break
        os.fsync(out.fileno())
    guard()
