"""Partition negative maxima into three clause-falsity classes."""
from functools import lru_cache
from itertools import combinations
from hashlib import sha256
from pathlib import Path
import json

edges = tuple((1 << x) | (1 << y) for x,y in (
    (0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
    (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)))
full = 2047
independent = [all(s & e != e for e in edges) for s in range(full + 1)]

@lru_cache(None)
def negatives(domain):
    bits = [1 << i for i in range(11) if domain >> i & 1]
    return [s for s in range(full+1) if not s & ~domain and independent[s]
            and all(b & s or not independent[s | b] for b in bits)]

def possible(domain, stars, y):
    residual = [e for e in edges if e & domain == e and e not in stars]
    def valid(mask):
        return all(mask & e != e for e in residual)
    if not valid(y):
        return False
    rows = sorted(negatives(domain), key=int.bit_count, reverse=True)
    def visit(i, bins):
        if i == len(rows):
            return True
        tried = set()
        for j, old in enumerate(bins):
            if old in tried:
                continue
            tried.add(old)
            new = old | rows[i]
            if valid(new):
                rest = bins.copy()
                rest[j] = new
                if visit(i+1, rest):
                    return True
        return False
    return visit(0, [y,0,0])

ledger = Path('/workspace/scratch/site-team-03/6648-q8-p3-r3-graph-results.jsonl').read_bytes()
assert sha256(ledger).hexdigest() == '9d257adc4212f832ca720d007d9abbe0cb34bce7a34b73e463f41d155456ae88'
records = [json.loads(line) for line in ledger.splitlines()]
masks = [s for s in combinations(edges,3) if (s[0]|s[1]|s[2]).bit_count()==5]
assert len(records)==len(masks)==299
import sys
start,end = map(int,sys.argv[1:])
survivors = {}
for index in range(start,end):
    stars=masks[index]
    record=records[index]
    assert record['index']==index and tuple(record['stars'])==stars
    outer=full ^ (stars[0]|stars[1]|stars[2])
    found=set()
    for bits in combinations([1<<i for i in range(11) if outer>>i&1],3):
        r=sum(bits)
        if possible(full^r, stars, outer^r):
            found.add(r)
    listed=[row[0] for row in record['rows']]
    assert sorted(found)==sorted(listed), (index,found,listed)
    if found:
        survivors[index]=sorted(found)
print(json.dumps({'range':[start,end],'sets':survivors},sort_keys=True))
