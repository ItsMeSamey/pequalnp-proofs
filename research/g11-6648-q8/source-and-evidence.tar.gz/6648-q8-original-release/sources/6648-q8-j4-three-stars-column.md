# Three original starred edges with four dirty ANDs and no centreless top

In a least 21-gate G11 TopForm circuit, the original signature j=4, c=0, s=3 is impossible for 4≤q≤8. Here s counts distinct starred graph edges. The five possible simple three-edge graphs are a triangle, a claw, a four-vertex path, a two-edge path plus a disjoint edge, and a matching. Additional ambient edges on the marked vertices are allowed. All cover and leastness arguments retain their original-circuit hypotheses.

## Eight paid ORs

* Triangle. Its eight exterior vertices require cover at least four, since its three marked vertices together with an exterior cover cover G11, whose cover number is seven. With P=j+q=12, P−8=4; the exterior cover obstruction applies directly.
* Claw or four-vertex path. Seven exterior vertices require cover at least three. The same obstruction excludes cover ≥4. At cover three, every exterior edge needs two visible suppliers, and the physical ledger gives n+k≤5. The two-visible proof handles k=2. The three-visible proof excludes k=4 and treats k=3 up to the two cyclic reader patterns. The cycle closure excludes both by tracing the fourth hidden donor's possible readers. The original ledger and its raw-gated cases exclude larger k. No cycle census is required.
* Two-edge path plus a disjoint edge. Partition by g, the number of dirty gates with direct exterior raw inputs. Four is excluded by the four mandatory labels plus the two-label star cover. For g≤2 the direct endpoint count and decoder give the small-g exclusion. For g=3 the shared three-clause filter covers all 299 masks and 20 placements per mask. Exactly 18 placements on 12 masks survive; the three disjoint physical imports exclude each survivor. The independent negative-row partition checker reproduced the exact set of placements.
* Three disjoint edges. The matching ledger excludes four raw-mandatory gates, then bounds endpoint imports and bare groups. At equality the raw readers or the earliest dirty ancestor are impossible. Below equality endpoint counting and opposite pairing forbid the required size.

## Four through seven paid ORs

Here P≤11 and the original size identity gives 2t+λ=22−P≥11. This is a transfer by inequalities on each original circuit. No gates are inserted.

* Triangle, claw and four-vertex path. The exterior has e≥7 and cover number at least three. P−e≤4, already impossible by the first exterior cover obstruction.
* Two-edge path plus a disjoint edge. The h≤2 and non-P3-only h=3 endpoint counts give 2t+λ<10 independent of j, so h≥3, and h=3 forces the bare matched AND on d,e. For g≤1 the reader count b+g≥6 forces h+b≥8. For g=2, h+b≤7 forces h=3,b=4,q=7. Exterior readership is tight and these seven paid gates exhaust the budget. Neither d nor e can enter a dirty AND by the small-g two-label star-cover deletion argument. Neither may enter an exterior OR under reader tightness. Both require a further reader beyond the bare AND, and no such gate remains. For g=3 the graph restriction, independent filter and its physical b≥4 argument do not use q. In every surviving placement the forced edges td and te exclude a bare matched group on R=false, so h≥4. This gives q≥8. The same cover argument excludes g=4.
* Matching. At all q the reservation inequality is 2(q−m)≥7−r+2h, with r≤3. Thus m+h≤q−2≤5. The endpoint count in the matching proof from the paragraph beginning “It remains” applies unchanged. For ≤3 imports it gives 2t+λ≤9. For four or five imports, λ≤1, triples are impossible, and any two double groups impose the opposite pairing that leaves no winning top on exterior edges. Hence t≤4 and 2t+λ≤9. This contradicts the lower-q size identity.

## Source pins

All paths except the specified independent checker are relative to the site-team-03 directory. SHA-256 digests follow.

    be32db767196332bdf299fab682cd5da3105d8437c3e6d9c092dbd4b7310404e  6648-exterior-cover-small-slack.md
    8a3a108f9be7f8303dfbf8b3adb89f48f43ccdbef3e189d881427ebcb5a5be8c  6648-connected-three-star-four-junk-two-visible.md
    709a57aac5d41d8f8dee1447f08d0c4f29e70b62e66f39f68070e078fdbc5dfe  6648-connected-visible-three-proof.md
    42b53b31fc71768f75c5f8e2d6c583b801d65c6a04317ff6962caf5932ab3e2d  6648-connected-cycle-necessity.md
    2c266ede43af1a1ccfebb7d34f6eacf86c4e55cf4b0f77e17fc76b70809c94a9  6648-q8-four-donor-p3-edge-small-r.md
    ba94ebd785f658cbe189f67058e8a3ff5d7a0771e1195da155fc102752af6ba6  6648-q8-four-donor-p3-edge-three-r.md
    61e197ea5f4c5ee146da4467a0def5c4e0e8d3a2c2b898cc257f032f2727be94  6648-q8-four-donor-three-matching.md
    6611f3a566722ac46cfb039e7a9977907349a881538cca79cc548db008a95ad7  twin_6648_q4_9_p3_k2.md
    cc29aefca5684daedfa8d374d112fc93b5b0428dcefb8b085b58685e888bb46f  6648-q8-p3-r3-shared-clauses.py
    65f29e8be11eaef50e52363e0c59a947659b0e391749a4b1738fd67b202ffa04  6648-q8-p3-r3-guard.py
    9d257adc4212f832ca720d007d9abbe0cb34bce7a34b73e463f41d155456ae88  6648-q8-p3-r3-graph-results.jsonl
    f51bd300376e31ee1d8ada814b2ea2ffb529dd37cc0185a6e618bd5279e23fba  ../site-team-07/p3_r3_color_verify.py
    4406f2b8e6a689d11b1f0b4361dd7aed6bc80b409d72229b9955e4645962fc77  /dev/shm/p3-r3-color-t8y21ryx
