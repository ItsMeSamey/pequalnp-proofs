# Exact gate counts at maximum average degree at most 9/4

For finite simple bipartite C4-free graphs G, assume every nonempty subgraph has average degree at most 9/4. Let m be the number of edges and ν the matching number. If m>0, the edge predicate on the full Boolean cube uses exactly m−1 OR gates and ν AND gates at its simultaneous optimum. Its exact total is m+ν−1, allowing arbitrary sharing. The theorem includes disconnected graphs.

The [density induction](corollary.md) is formulated as an implication from a four-edge open-ear refund. The [four-edge ear proof](four-edge-ear-or-transfer.md) establishes that premise, including nonadjacent same-shore endpoints and disconnected exterior. Together they give the unconditional mathematical statement above. The [long-ear OR proof](private-ear-or-8577.md), [private-vertex OR proof](8577-global-private-or.md), and [adjacent-degree-two AND proof](active8577-private-ear-and.md) provide the remaining structural reductions. The original five sources are preserved verbatim, with their manifest in SOURCE-SHA256SUMS. This is a research result without a Lean kernel receipt.

## Boundary example

Replace each of the nine edges of K₃,₃ by a three-edge path with fresh internal vertices. The graph has 24 vertices and 27 edges, is bipartite, and has girth 12. Its maximum average degree is 9/4. Indeed the full graph attains it; a subgraph of greater density could be pruned to minimum degree two while keeping greater density. It would then consist of complete paths, with e retained kernel edges on b hubs. Its average degree would be 6e/(b+2e)≤9/4 since 2e≤3b. Lift a perfect matching of the kernel by using the two outer edges on its three selected paths and the middle edge on each of the six others. The resulting 12-edge matching saturates the graph. Hence the optimum is **26 OR gates and 12 AND gates, totaling 38**. The example shows sharpness of the long-string criterion; it makes no assertion of failure of the gate bounds at larger densities.

## Edgeless convention

If m=0, then ν=0 and both lower bounds are zero. The edge predicate is constant false. In the repository model with N inputs, an empty gate list and output index N realize false at zero cost, even at N=0: Circuit.eval uses getD with default false, circuitFun calls that evaluation, and IsAO2 restricts the gates and their input pins. A syntax requiring a valid output wire may use another convention. The arithmetic expression m+ν−1 for the exact total above applies to m>0.

These definitions occur in PEqualNP/Defs/CircuitLowerBounds.lean, MetaComplexityMinimal.lean, and TopForm.lean. For historical context see P. A. Bloniarz, MIT-LCS-TR-238, chapter 3. No priority claim is made.
