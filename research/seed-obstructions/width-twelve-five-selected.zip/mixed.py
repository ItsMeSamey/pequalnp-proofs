"""Exhaust the 21-mixed-gate frontier at all line widths for every listed bank."""
from collections import Counter
from itertools import combinations,combinations_with_replacement,permutations
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys
from input import raw_samples
base=Path(__file__).resolve().parent
pos,neg,_=raw_samples(base/'L-meta-18968.json')
def move(mask, permutation):
    return sum(1<<target for bit,target in enumerate(permutation) if mask>>bit&1)
raw = tuple(1<<j for j in range(7))
stars = [sum({p&8191 for p in pos if p&(l<<13)}) for l in raw]
incidence = [sum(1<<j for j,s in enumerate(stars) if s>>i&1) for i in range(13)]
def symmetries():
    group = []
    for perm in permutations(range(7)):
        images = [move(x,perm) for x in incidence]
        if set(images)!=set(incidence):
            continue
        pp = [incidence.index(y) for y in images]
        line = [move(x,perm) for x in range(128)]
        def transform(r):
            return move(r&8191,pp) | line[r>>13]<<13
        if all({transform(r) for r in rows}==rows for rows in (pos,neg)):
            group.append((pp,line))
    assert len(group)==24
    return group
def line_banks(width, domain):
    if domain=='all' and width==8:
        return {tuple(sorted((*raw,x))) for x in range(128)}
    if domain=='all' and width==9:
        ordinary={tuple(sorted((*raw,x,y))) for x,y in combinations_with_replacement(range(128),2)}
        # A nine-line circuit can also omit a raw singleton. These 24 additional
        # masks come from the independently established minimal-line classification.
        exceptional={tuple(map(int,l.split())) for l in (base/'exceptional-nine.txt').read_text().splitlines()}
        assert len(exceptional)==24
        return ordinary|exceptional
    if domain=='all' and width not in (7,8,9):
        raise ValueError('all-signature domain only supplied for seven through nine lines')
    states={raw}
    for _ in range(width-7):
        states={tuple(sorted((*s,a|b))) for s in states for a,b in combinations(s,2) if a|b not in s}
    return states

def load_bases(name):
    return {tuple(map(int,line.split())) for line in (base/name).read_text().splitlines()}

def audit_bases():
    from pysat.card import CardEnc
    from pysat.solvers import Solver
    obligations={(p>>13,n>>13) for p in pos for n in neg if not (p&8191)&~n}
    previous={raw}
    for width,file in [(9,'exceptional-nine.txt'),(10,'exceptional-ten.txt')]:
        clauses=CardEnc.atmost(list(range(1,128)),width,top_id=127).clauses
        clauses.extend([mask for mask in range(1,128) if mask&p and not mask&n] for p,n in obligations)
        clauses.extend([-m for m in f] for f in previous)
        result=set()
        with Solver(name='cadical195',bootstrap_with=clauses) as solver:
            while solver.solve():
                family=tuple(sorted(m for m in solver.get_model() if 1<=m<=127))
                if len(family)!=width:
                    raise ValueError(('unexpected smaller line basis',family))
                result.add(family);solver.add_clause([-m for m in family])
        assert result==load_bases(file)
        previous.update(result)

def clashes(point_bank):
    positives=sorted(pos);negatives=sorted(neg)
    def flags(r):
        return sum(1<<i for i,m in enumerate(point_bank) if r&m&8191)
    pflags=list(map(flags,positives));nflags=list(map(flags,negatives))
    pos_sensitive=[0]*len(positives);neg_sensitive=[0]*len(negatives)
    line_only=[]
    for i,p in enumerate(positives):
        for j,n in enumerate(negatives):
            point_diff=pflags[i]&~nflags[j]
            line_diff=(p>>13)&~(n>>13)
            if not line_diff and point_diff.bit_count()==1:
                pos_sensitive[i]|=point_diff;neg_sensitive[j]|=point_diff
            if not point_diff:
                assert line_diff.bit_count()==1
                line_only.append((i,j,p>>13,n>>13))
    conflicts=[]
    for l in raw:
        for t in range(12):
            a=sum(1<<z for z,(i,j,pl,nl) in enumerate(line_only) if pl==l and pos_sensitive[i]>>t&1)
            o=sum(1<<z for z,(i,j,pl,nl) in enumerate(line_only) if pl==l and neg_sensitive[j]>>t&1)
            if a and o:
                conflicts.append((a,o))
    witnesses=[sum(1<<z for z,(i,j,p,n) in enumerate(line_only) if x&p and not x&n) for x in range(128)]
    return conflicts,witnesses


def main():
    gate_count=22 if sys.argv[1:]==['--line7-22'] else 21
    widths={7} if gate_count==22 else (set(map(int,sys.argv[1:])) or {7,8,9,10})
    assert widths<={7,8,9,10}
    audit_bases()
    pts=[tuple(map(int,row.split()[:-1])) for row in (base/'nonlocal-priced.txt').read_text().splitlines()]
    group=symmetries()
    with TemporaryDirectory() as tmp:
        exe=Path(tmp)/'frontier'
        subprocess.run(['c++','-std=c++17','-O3',base/'exact12.cpp','-o',exe],check=True)
        for L in sorted(widths):
            seen=set();cases=[];ruled_out=0;survived=0
            if L==10:
                choices={tuple(sorted((*s,x))) for s in load_bases('exceptional-nine.txt') for x in range(128)}
                choices|=load_bases('exceptional-ten.txt')
                choices={l for l in choices if not set(raw)<=set(l)}
                assert len(choices)==3485
            else:
                choices=line_banks(L,'all')
            for p in pts:
                if p in seen:continue
                imgs=[(tuple(sorted(move(m,pp) for m in p)),lm) for pp,lm in group]
                seen.update(q for q,lm in imgs)
                stab=[lm for q,lm in imgs if q==p]
                def canonical(l):
                    return all(l<=tuple(sorted(lm[x] for x in l)) for lm in stab)
                if L==10:
                    conflicts,dist=clashes(p)
                    for a,b,c in combinations_with_replacement(range(128),3):
                        keep=~(dist[a]|dist[b]|dist[c])
                        if any(keep&A and keep&O for A,O in conflicts):
                            ruled_out+=1
                        else:
                            survived+=1
                            if canonical((a,b,c)):cases.append((p,(*raw,a,b,c)))
                for l in choices:
                    if canonical(l):cases.append((p,l))
            print('width',L,'representatives for frontier',len(cases),'ordinary triple tests rejected',
                  ruled_out,'ordinary surviving',survived,flush=True)
            hist=Counter()
            for lo in range(0,len(cases),2048):
                chunk=cases[lo:lo+2048]
                payload=['28 245',' '.join(map(str,sorted(pos))),' '.join(map(str,sorted(neg))),
                         f'{len(chunk)} 12 {L} {gate_count-11-L}']
                payload.extend(' '.join(map(str,p+l)) for p,l in chunk)
                result=subprocess.run([exe],input='\n'.join(payload)+'\n',text=True,capture_output=True,check=True)
                dead=list(map(int,result.stdout.split()))
                assert len(dead)==len(chunk) and all(0<d<=gate_count for d in dead)
                hist.update(dead)
            print('first empty gate',dict(sorted(hist.items())),flush=True)
if __name__=='__main__':main()
