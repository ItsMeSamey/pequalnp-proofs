"""Check the actual whole-negative point obligations for every classified family."""
from pathlib import Path
from collections import Counter
import json,subprocess,sys
from input import point_obligations
base=Path(__file__).resolve().parent
raw,obs=point_obligations(base/'L-meta-18968.json')
raw=set(raw)
from functools import cache
@cache
def cover(mask):
    return sum(1<<i for i,(p,n) in enumerate(obs) if mask&p and not mask&n)
def check(f):
    bits=0
    for m in f:bits|=cover(m)
    assert bits==(1<<len(obs))-1
subprocess.run([sys.executable,base/'five_local.py'],cwd=base,check=True)
local=set()
for row in (base/'all-five-local.txt').read_text().splitlines():
    f=tuple(map(int,row.split()[:-1]));assert len(f)==len(set(f))==12
    check(f);local.add(f)
families={}
for f,gates in json.loads((base/'nonlocal-or-witnesses.json').read_text()):
    seen=raw.copy()
    for m,a,b in gates:
        assert a in seen and b in seen and m==a|b and m not in seen
        seen.add(m)
    assert set(f)<=seen
    check(f)
    families[tuple(f)]=len(gates)
assert set(families)=={tuple(map(int,l.split())) for l in (base/'abstract5-nonlocal-banks.txt').read_text().splitlines()}
assert len(local)==12288 and len(families)==12 and local.isdisjoint(families)
print(len(local)+len(families),'physically realizable banks verified',dict(sorted(Counter(families.values()).items())))
