from itertools import combinations,product
from collections import Counter
from pathlib import Path
raw={1<<i for i in range(13)}
T=[sum(1<<((j+6+d)%13) for d in (0,1,3,9)) for j in range(7)]
rows={}
for a,b in combinations(T,2):
 s=a|b
 assert s.bit_count()==7
 slots=[t for t in T if t not in [a,b]]
 opts=[[x for x in range(1,8192) if not x&~t and t&~(x|s)==0] for t in slots]
 for vals in product(*opts):
  bank=tuple(sorted([m for m in raw if m&s]+list(vals)))
  rows[bank]=sum(x.bit_count()-1 for x in vals)
out=Path('all-five-local.txt')
out.write_text(''.join(' '.join(map(str,(*k,v)))+'\n' for k,v in sorted(rows.items())))
print(len(rows),Counter(rows.values()))
