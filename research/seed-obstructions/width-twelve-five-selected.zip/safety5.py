from pathlib import Path
from functools import lru_cache
from itertools import combinations
from collections import Counter
from input import point_obligations
raw,obs=point_obligations(Path('L-meta-18968.json'))
raw=set(raw)
T=[sum(1<<((j+6+d)%13) for d in (0,1,3,9)) for j in range(7)]
@lru_cache(None)
def cover(m):return sum(1<<i for i,(p,n) in enumerate(obs) if m&p and not m&n)
pairs={a|b:sum(1<<i for i,(p,n) in enumerate(obs) if (a|b)&~n==0) for a,b in combinations([1<<i for i in range(13)],2)}
outs={t:[w for q,w in pairs.items() if not q&t] for t in T}
hosts={m:next(t for t in T if not m&~t) for m in range(1,8192) if m.bit_count()>1 and any(not m&~t for t in T)}
hist=Counter();gap=Counter();missing=Counter()
for l in Path('all-five-local.txt').read_text().splitlines():
 *bank,price=map(int,l.split())
 n=0
 for m in bank:
  if m in raw or m.bit_count()==2:continue
  priv=cover(m)
  for f in bank:
   if m!=f:priv&=~cover(f)
  lost=sum(not (priv&w) for w in outs[hosts[m]])
  if lost:n+=1
  missing[m.bit_count(),lost]+=1
 hist[n]+=1
 if n:gap[price]+=1
print('unsafe masks per bank',hist,'cost gap',gap,'raw pair failures',missing)
