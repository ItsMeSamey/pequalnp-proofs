from pathlib import Path
from itertools import combinations
from pysat.card import CardEnc
from pysat.solvers import Solver
import sys
D=Path(__file__).resolve().parent
from check import encode
from input import point_obligations
raw,obs=point_obligations(D/'L-meta-18968.json')
k=int(sys.argv[1]);cs,m,used,_=encode(raw,obs,12,5,selected=5,abstract=True)
for row in m:
 for r in [0,*raw]:cs.append([(-v if r>>j&1 else v) for j,v in enumerate(row)])
T=[sum(1<<((j+6+d)%13) for d in (0,1,3,9)) for j in range(7)]
v=max(abs(x) for c in cs for x in c);flags=list(range(v+1,v+6))
for flag,row in zip(flags,m):
 for t in T:cs.append([-flag,*[b for j,b in enumerate(row) if not t>>j&1]])
cs+=CardEnc.atleast(flags,k,top_id=v+5).clauses

with Solver(name='cadical195',bootstrap_with=cs) as s:
 count=0
 with open('abstract5-nonlocal-banks.txt','w',1) as out:
  while s.solve():
   a=set(s.get_model());se=[v for v in used if v in a];fp=[r for r,v in zip(raw,used) if v in a];fm=[sum(1<<i for i,b in enumerate(row) if b in a) for row in m]
   assert len(se)==7 and len(fm)==5
   print(*sorted(fp+fm),file=out);count+=1
   s.add_clause([-x for x in se]+[(-v if v in a else v) for row in m for v in row])
 print('DONE',count)
