from pathlib import Path
from itertools import combinations
from pysat.card import CardEnc
from pysat.solvers import Solver
import sys
D=Path(__file__).resolve().parent
from check import encode
from input import point_obligations
raw,obs=point_obligations(D/'L-meta-18968.json')
h=int(sys.argv[1])
cs,m,used,_=encode(raw,obs,12,h,selected=h,abstract=True)
for row in m:
 for r in [0,*raw]:cs.append([(-v if r>>j&1 else v) for j,v in enumerate(row)])
T=[sum(1<<((j+6+d)%13) for d in (0,1,3,9)) for j in range(7)]
v=max(abs(x) for c in cs for x in c)
local=[]
for row in m:
 host=[]
 for t in T:
  v+=1;flag=v;host.append(flag)
  outs=[b for j,b in enumerate(row) if not t>>j&1]
  cs.extend([[-flag,-b] for b in outs]);cs.append([flag,*outs])
 cs.append(host)
 local.append(host)
defects=[]
for t_index,t in enumerate(T):
 for j in range(13):
  if not(t>>j&1):continue
  v+=1;z=v;defects.append(z)
  for r,b in zip(raw,used):
   if (r>>j&1) and r&~t==0:cs.append([-z,-b])
  for row,flags in zip(m,local):cs.append([-z,-flags[t_index],-row[j]])
cs.append(defects)
with Solver(name='cadical195',bootstrap_with=cs) as s:
 res=s.solve();print('local-unrecovered',h,res,s.accum_stats(),flush=True)
 if res:
  a=set(s.get_model());print([r for r,b in zip(raw,used) if b in a],[sum(1<<i for i,b in enumerate(row) if b in a) for row in m])
