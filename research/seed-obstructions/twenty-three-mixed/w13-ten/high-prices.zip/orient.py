from functools import lru_cache

def orient(b):
 a=[0]*13;ex=[]
 for v in b:
  if v and not v&(v-1) and not a[v.bit_length()-1]:a[v.bit_length()-1]=v
  else:ex.append(v)
 missing=[j for j in range(13)if not a[j]]
 @lru_cache(None)
 def best(j,free):
  if not free:return (0,())
  opts=[]
  for i,v in enumerate(ex):
   if free>>i&1:
    score,rest=best(j+1,free^(1<<i))
    opts.append((score+bool(v>>missing[j]&1),(v,*rest)))
  bestscore=max(v[0]for v in opts)
  return min(v for v in opts if v[0]==bestscore)
 _,select=best(0,(1<<len(ex))-1)
 for j,v in zip(missing,select):a[j]=v
 return tuple(a)
