# Thirteen point slots, ten line slots, one excess read

This certificate checks every affordable point/line bank pair at line prices four through eight in the 23-mixed-gate stratum. The total gate cap is 33. Numbered point inputs and raw line labels follow the residual instance in L-meta-18968.json. The work uses the established pure-bank censuses and the exclusion through 22 mixed gates.

| Pure line price | Point-price ceiling tested | Nonzero point representatives | Tested labelled line banks | Joint pairs |
|---:|---:|---:|---:|---:|
|4|6|1,429|38,351|54,803,579|
|5|5|313|91,223|28,552,799|
|6|4|86|121,932|10,486,152|
|7|3|28|83,147|2,328,116|
|8|3|28|18,293|512,204|

All 96,682,850 pairs failed the necessary one-surplus test. The production ledger covers every listed point/line pair with no surviving candidates.

The point ceiling in the last row includes every affordable cost through two. The line domains come from the thirteen-ten pure-mask price census. The source snapshot source-linecaps.py uses its original workspace paths. The point domains at ceilings five and six are the P13L11 w13g5 and w13g6 true banks. At the two lower ceilings we take orbits of the labelled low-price banks under the 24 automorphisms preserving both raw sample sets. The line pools contain all labelled orientations. The independent check-domains.py verifies their invariance under generators. Reordering the slots of a particular bank preserves the existence of a circuit.

A slot whose mask is zero has value zero at every positive, on either side of the incidence relation. Setting the entire slot to zero preserves positives and can only decrease the output on negatives. Constant propagation deletes its first mixed consumer. The earlier mixed-gate lower bound excludes this possibility. Two point representatives at ceiling six and 24 line banks at price four with a zero in the first physical slot are removed this way. A zero in any later line slot is retained in the numerical sweep, which only enlarges the tested domain.

With exactly one excess read, the repeated source is a read-once subtree with a single Boolean output H. Its exterior is a read-once tree on the remaining leaves and two formal copies of H. A repeated boundary source corresponds to an inner subtree consisting of a single leaf. A larger inner subtree includes at least one leaf from each side because its gates belong to the mixed region.

For a positive and a negative let D comprise the slots which are one on the positive and zero on the negative. A unique slot in D gives a pivotality witness for that slot. Two such witnesses sharing a positive force the least common ancestor of their slots to be AND in a read-once tree. At a common negative the required ancestor is OR. A pair with both requirements cannot lie in the same region. The checker two-colors these constraints and explores each component's orientations. If no outer slot distinguishes a particular positive and negative, H must be one on that positive and zero on that negative. Whenever such a forced positive is dominated on all inner slots by a forced negative, the partition is infeasible by monotonicity.

For a set of banks, granting a slot the union of its positive truths and the intersection of its negative truths preserves every feasible separator. Singleton masks on a pure side evaluate exactly on its positive singleton and the disjunction of a mask's singleton coordinates gives a lower bound on negative truth. Alignments and adaptive subdivision accelerate the computation. The sparse lookup stores the negative bitset for submasks of each positive's feature mask. All queries intersect a mask with that positive and thus access only populated entries. The dense implementation is the upstream P13L10 joint.cpp. A comparison on 365,824 pairs produced identical comparison and recursion counts.

From this directory, run the following to reproduce the sample, compile the C++20 checker and check all five price bands. Optional numeric arguments select individual line prices.

```sh
nice -n 15 python3 verify.py
nice -n 15 python3 check-domains.py
```

The production.json ledger records disjoint half-open ranges in the filtered labelled line order. Each row gives the run name, first index, length, number of Cartesian pairs, and number of surviving pairs. Run python3 production.py for a fast coverage and arithmetic check. The full replay uses one fixed alignment and binary throughout. The production pass also used the equivalent dense kernel and other alignments on its early batches.

The earlier point-price archives w13-price5.zip and w13-price6.zip have SHA-256 digests b101d43f9ae33c1ebe89b42cb2170092149a96e434d4629494018702b1f9bdea and 648b97e18fa37cc61457fc648bdcfb4265a8d979ef97a5334d52f79858d74dc9 respectively. Their unfiltered bank lists are included alongside the filtered data. The lower point inputs start with 344 labelled price-three rows and 1,259 price-four rows. check-domains.py reconstructs their orbit representatives from the raw sample automorphisms.
