from pathlib import Path
from functools import reduce
from itertools import combinations
import gzip
from samples import actions
from inputs import P,N,stars
root=Path(__file__).resolve().parent
G=actions(P,N);raw=[tuple(stars.index(f[v])for v in stars)for f in G]
identity=tuple(range(7))
def expand(gens):
 seen={identity};stack=[identity]
 while stack:
  h=stack.pop()
  for t in gens:
   a=tuple(t[j] for j in h)
   if a not in seen:seen.add(a);stack.append(a)
 return seen
gens=[]
for a in raw:
 if a not in expand(gens):gens.append(a)
assert expand(gens)==set(raw)
images=[[sum(1<<p[j]for j in range(7)if v>>j&1)for v in range(128)]for p in gens]
for c,n in [(4,38375),(5,91223),(6,121932),(7,83147),(8,18293)]:
 rows={tuple(sorted(map(int,s.split()))) for s in gzip.decompress((root/f'line-{c}.gz').read_bytes()).splitlines()}
 assert len(rows)==n
 for p in images:
  assert all(tuple(sorted(p[v]for v in a))in rows for a in rows)
 print(c,n,len(gens),'generators',flush=True)
for g in (3,4):
 def read(name):
  return [tuple(map(int,r.split())) for r in gzip.decompress((root/name).read_bytes()).splitlines()]
 reps={min(tuple(sorted(f[x] for x in b)) for f in G) for b in read(f'labelled-point-{g}.gz')}
 assert reps==set(read(f'point-{g}.gz'))
 print('point',g,len(reps),'orbits',flush=True)
for g in (5,6):
 raw=read(f'w13g{g}.gz')
 assert sorted(x for x in raw if all(x))==sorted(read(f'point-{g}.gz'))
 print('point',g,len(raw),'unfiltered',flush=True)
