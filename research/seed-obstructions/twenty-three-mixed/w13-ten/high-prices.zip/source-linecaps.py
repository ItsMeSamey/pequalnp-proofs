from pathlib import Path
import sys
from collections import Counter
sys.path.insert(0,'/workspace/scratch/syn_cover/thirteen_ten/certificate')
from line_prices import collapse,synth
h=Path('/dev/shm/syn_cover_m23');origin=Path('/dev/shm/syn_cover_l12')
exact={}
outs={c:(h/f'line-exact-{c}').open('w') for c in range(3,9)}
for style in ['other','ordinary']:
 count=Counter()
 with (origin/f'gen-lines-{style}.txt').open() as f:
  for n,line in enumerate(f):
   a=tuple(map(int,line.split()));t=tuple(sorted(set(x for x in a if x.bit_count()>1)))
   key,nn,offset=collapse(t)
   if (key,nn) not in exact:exact[key,nn]=synth(key,nn)
   price=len(a)-len({x for x in a if x.bit_count()==1})-len(t)+offset+exact[key,nn]
   print(*a,file=outs[price]);count[price]+=1
   if n%2048==0:collapse.cache_clear()
 print(style,dict(count),flush=True)
for f in outs.values():f.close()
