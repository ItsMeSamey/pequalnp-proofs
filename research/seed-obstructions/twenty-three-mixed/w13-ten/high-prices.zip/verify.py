"""Rebuild the one-message tests on any selected price bands."""
import argparse
import gzip
import os
from pathlib import Path
import subprocess
import tempfile
from inputs import P,N
from orient import orient

base=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('prices',type=int,nargs='*',default=list(range(4,9)))
args=parser.parse_args()
sizes={4:(1429,38351),5:(313,91223),6:(86,121932),7:(28,83147),8:(28,18293)}
def rows(name):
    with gzip.open(base/name,'rt') as f:
        return [tuple(map(int,r.split())) for r in f]
def write(path,bank):
    path.write_text(''.join(' '.join(map(str,r))+'\n' for r in bank))
with tempfile.TemporaryDirectory() as tmp:
    t=Path(tmp)
    binary=os.environ.get('ONECUT_BINARY') or t/'verify'
    if 'ONECUT_BINARY' not in os.environ:
        subprocess.run(['g++','-O3','-std=c++20',base/'sparse.cpp','-o',binary],check=True)
    write(t/'rows',[(len(P),len(N),*sorted(P),*sorted(N))])
    for c in args.prices:
        g=max(3,10-c)
        points=sorted(map(orient,rows(f'point-{g}.gz')))
        lines=[r for r in rows(f'line-{c}.gz') if r[0]]
        assert (len(points),len(lines))==sizes[c]
        write(t/'points',points)
        pairs=survivors=0
        for a in range(0,len(lines),2048):
            group=lines[a:a+2048]
            write(t/'lines',group)
            result=subprocess.run([binary,t/'rows',t/'points',t/'lines','256','0',str(len(points)),'32'],capture_output=True,text=True,check=True)
            tag,n,_,_,s=result.stderr.splitlines()[-1].split()
            assert tag=='DONE' and int(n)==len(points)*len(group)
            assert int(s)==len(result.stdout.splitlines())
            for entry in result.stdout.splitlines():
                p,l=map(int,entry.split())
                print('candidate',c,points[p],group[l],flush=True)
            pairs+=int(n)
            survivors+=int(s)
        print(c,pairs,survivors,flush=True)
        assert not survivors
