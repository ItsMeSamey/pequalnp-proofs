"""Check the aggregate arithmetic and interval ledger exported by the first pass."""
import json
from pathlib import Path
rows=json.loads(Path(__file__).with_name('production.json').read_text())
for c,ps,ls in [(4,1429,38351),(5,313,91223),(6,86,121932),(7,28,83147),(8,28,18293)]:
    end=candidates=0
    for name,start,length,pairs,survivors in sorted(rows[str(c)],key=lambda r:r[1]):
        assert start==end and length>0 and pairs==ps*length and survivors>=0
        end+=length
        candidates+=survivors
    assert end==ls and not candidates
    print(c,end*ps,candidates)
