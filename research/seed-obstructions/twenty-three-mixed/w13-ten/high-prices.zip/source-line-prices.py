"""Exact singleton-domain price for the three extra slots in an ordinary ten-bank."""
from itertools import combinations_with_replacement,permutations
from collections import Counter
from functools import lru_cache
from pathlib import Path
import sys
from check import encode
from pysat.solvers import Solver

@lru_cache(None)
def collapse(targets):
    remove=tuple(t for t in targets if t.bit_count()>1)
    if remove!=targets:return collapse(remove)
    if not targets:return (),0,0
    labels=sorted({1<<p for t in targets for p in range(7) if t>>p&1})
    d=len(targets)
    # Source permutations and output permutations do not change pure cost.
    hist=min(tuple(sorted(sum(bool(t&p)<<i for i,t in enumerate(o)) for p in labels)) for o in permutations(targets))
    distinct=sorted(set(hist));cost=len(labels)-len(distinct)
    sub=tuple(sorted(sum(bool(u>>i&1)<<j for j,u in enumerate(distinct)) for i in range(d)))
    if any(t.bit_count()<=1 for t in sub):
        final,n,c=collapse(tuple(t for t in sub if t.bit_count()>1))
        return final,n,cost+c
    return sub,len(distinct),cost
def synth(key,n):
    if not key:return 0
    raw=[1<<i for i in range(n)]
    for gates in range(len(key),1+sum(k.bit_count()-1 for k in key)):
        c,V,_,_=encode(raw,[],0,gates,selected=0);hi=max(abs(z) for cl in c for z in cl)
        for val in key:
            opts=[]
            for v in V:
                hi+=1;opts.append(hi)
                c.extend([[-hi,z if val>>d&1 else -z] for d,z in enumerate(v)])
            c.append(opts)
        with Solver(name='cadical195',bootstrap_with=c) as s:
            if s.solve():return gates
    raise RuntimeError(key)
if __name__=='__main__':
    from verify import lines
    _,other,raw=lines()
    datasets=[('ordinary',((*raw,*t) for t in combinations_with_replacement(range(128),3))),('other',other)]
    exact={}
    expect={'ordinary':{3:8275,4:37415,5:89915,6:121051,7:82859,8:18245},'other':{4:960,5:1308,6:881,7:288,8:48}}
    for name,families in datasets:
        result=Counter()
        for bank in families:
            D=tuple(sorted({m for m in bank if m.bit_count()>1}))
            key,n,offset=collapse(D)
            overhead=len(bank)-len({m for m in bank if m.bit_count()==1})-len(D)
            if (key,n) not in exact:exact[key,n]=synth(key,n)
            result[overhead+offset+exact[key,n]]+=1
        print(name,sorted(result.items()),flush=True)
        assert result==expect[name]
