from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from itertools import combinations_with_replacement
import gzip,subprocess,sys
from sample import pos,neg
base=Path(__file__).resolve().parent
def run(*a,**kw):return subprocess.run(list(map(str,a)),check=True,**kw)
def write(t,rows):
 with t.open('w') as f:
  for r in rows:print(*r,file=f)
with TemporaryDirectory() as td:
 h=Path(td)
 for name in ('sparse','endpoint24'):run('g++','-std=c++20','-O3','-march=native',base/(name+'.cpp'),'-o',h/name)
 with ZipFile(base/'W13L9-true-through-seven.zip') as z:
  names=[n for n in z.namelist() if n.endswith('points7.gz')];assert len(names)==1
  points=[tuple(map(int,s.split())) for s in gzip.decompress(z.read(names[0])).splitlines()]
 assert len(points)==6908
 write(h/'points',points)
 (h/'rows').write_text(' '.join(map(str,[len(pos),len(neg),*sorted(pos),*sorted(neg)])))
 raw=tuple(1<<i for i in range(7));tables={raw}
 for _ in range(3):tables={tuple(sorted((*a,m))) for a in tables for x,y in combinations_with_replacement(a,2) for m in (x|y,x&y)}
 lines=sorted(tables);assert len(lines)==8275
 hits=[]
 for i in range(0,len(lines),256):
  write(h/'lines',lines[i:i+256]);r=run(h/'sparse',h/'rows',h/'points',h/'lines',128,0,len(points),16,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  pairs=[tuple(map(int,x.split())) for x in r.stdout.splitlines()]
  for pidx,lidx in pairs:hits.append((points[pidx],lines[i+lidx]))
  print(i,'line offset',len(pairs),'survivors',flush=True)
 rows=[]
 for p,l in hits:
  masks=(*p,*[v<<13 for v in l])
  def enc(x):return sum(bool(x&m)<<i for i,m in enumerate(masks))
  P=set(map(enc,pos));N=set(map(enc,neg));N={v for v in N if not any(w!=v and not w&~v for w in N)}
  rows.append(' '.join(map(str,[len(P),len(N),*sorted(P),*sorted(N)])))
 if rows:
  r=run(h/'endpoint24',13,10,1,input='\n'.join(rows)+'\n',text=True,stdout=subprocess.PIPE)
  results=r.stdout.splitlines();assert len(results)==len(hits) and all(s.startswith('0 ') for s in results)
 print('checked',len(points)*len(lines),'one-cut pairs and',len(hits),'exact endpoints')
