# Width 14 points and 10 lines, mixed cost 23

At total cost at most 33 the two pure costs sum to at most 10. Ten physical line slots require at least three paid line gates. Let S count distinct raw singleton point signatures.

| Line cost | Maximum point cost | Coverage |
|---|---|---|
| 3 | 7 | W14seven for S=4–11, W14low for S≥12 and physical padding |
| 4 | 6 | W14middle for S=4–7, W14-L10-g6-S89 for S=8–9, W14four for S≥10 |
| 5 | 5 | W14four for S≤7 or S≥10, W14middle for S=8–9 |
| ≥6 | 4 | W14four |

At all prices W14low handles physical zero and duplicate signatures. The raw-read bounds exclude S≤3 through point cost seven. Each archive records its proof, inputs, and native replay entry point. W14seven/replay.py accepts individual S values or runs the full range by default.
