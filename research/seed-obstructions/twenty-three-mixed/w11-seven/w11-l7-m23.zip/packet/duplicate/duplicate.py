from pathlib import Path
from collections import Counter
import sys
prior=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/scratch/syn_mitm/twelve-eight/certificate/prior')
for name,count in [('w12_zero_cert',12),('w12_two_masks',204)]:
 rows=[list(map(int,l.split())) for l in (prior/(name+'.txt')).read_text().splitlines()]
 assert len(rows)==count and all(len(r)==13 for r in rows)
 result=Counter(len(set(r[1:])) for r in rows)
 assert result=={12:count}
 print(name,count,'banks; all twelve slots distinct')
