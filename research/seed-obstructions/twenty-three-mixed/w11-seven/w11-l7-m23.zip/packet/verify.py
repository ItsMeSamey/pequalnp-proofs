"""Rebuild regional roles and rule out every unmarked raw two-input source."""
from pathlib import Path
from itertools import combinations
from tempfile import TemporaryDirectory
import json,subprocess,sys
from inputs import P,N,stars
from samples import actions
here=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(here/"duplicate"/"duplicate.py"),str(here/"duplicate")],check=True)
masks={int(i):l for i,l in json.loads((here/'masks.json').read_text()).items()}
banks={tuple(sorted(map(int,l.split()))) for l in (here/'cost-ten-star-local.txt').read_text().splitlines()}
assert len(banks)==354
assert all(sum(s in b for s in stars)<=1 for b in banks)
acts=list(actions(P,N))
reps=sorted({min(tuple(sorted(a[x] for x in b)) for a in acts) for b in banks})
assert len(reps)==23
def minimal(rows):
 rows=sorted(set(rows),key=int.bit_count);out=[]
 for x in rows:
  if not any(not a&~x for a in out):out.append(x)
 return out
def roles(b):
 def point(x):return sum(bool(x&m)<<i for i,m in enumerate(b))
 pc={p:point(p) for p in {v&8191 for v in set(P)|set(N)}|{1<<i for i in range(13)}|{(1<<i)|(1<<j) for i in range(13) for j in range(i)}}
 guards=[minimal(pc[1<<i]&~pc[(1<<j)|(1<<k)] for i in range(13) if s>>i&1 for j in range(13) if not s>>j&1 for k in range(j) if not s>>k&1) for s in stars]
 result=[]
 for d in [1,2]:
  for J in combinations(range(7),d):
   line=sum(1<<j for j in J)
   priv=minimal(x for j in J for x in guards[j])
   outside=minimal(pc[p&8191]&~pc[n&8191] for p in P if not (p>>13)&line for n in N if (p>>13)&(n>>13) and all(stars[j]&n for j in J))
   for H in range(1,2048):
    if all(x&H for x in priv) and all(x&~H for x in outside):result.append((J,H))
 return result
def kill_table(ps,ns,K,O):
 width=K.bit_count(); Z=((1<<18)-1)^K^O
 assert K&O==0
 pp=minimal(x&K for x in ps if not x&Z)
 nn=sorted({x&K for x in ns if not O&~x})
 nn=[n for n in nn if not any(n!=u and not n&~u for u in nn)]
 dif={p&~n for p in pp for n in nn}
 assert 0 not in dif and all(1<<j in dif for j in range(18) if K>>j&1)
 inds=[j for j in range(18) if K>>j&1]
 def compact(x):return sum(((x>>j)&1)<<i for i,j in enumerate(inds))
 rows=[*pp,*nn];pm=(1<<len(pp))-1;nm=((1<<len(rows))-1)^pm
 codes=[sum(((x|O)>>i&1)<<j for j,x in enumerate(rows)) for i in range(18)]
 forbidden=set()
 for q in range(11):
  for l in range(11,18):
   pair=(1<<q)|(1<<l)
   if not K&pair:continue
   for op in [0,1]:
    h=codes[q]|codes[l] if op else codes[q]&codes[l]
    substitutes=codes+[0,pm|nm] if (pair&K)==pair else [codes[q if not K>>q&1 else l]]
    if any(not h&pm&~z and not z&nm&~h for z in substitutes):forbidden.add((q,l,op))
 return forbidden,[width,5,len(pp),len(nn),*sorted(map(compact,pp)),*sorted(map(compact,nn))]
with TemporaryDirectory() as tmp:
 exe=Path(tmp)/'frontier'
 if '--engine' in sys.argv:
  exe=Path(sys.argv[sys.argv.index('--engine')+1]).resolve()
 else:
  subprocess.run(['c++','-O2','-std=c++17',str(here/'frontier.cpp'),'-o',str(exe)],check=True)
 actual=[]
 for idx,b in enumerate(reps):
  rs=roles(b)
  if not rs:continue
  assert len(rs)==1
  J,H=rs[0];assert len(J)==1 and H.bit_count()==1
  j=11+J[0];h=H.bit_length()-1
  assert b[h]==stars[j-11]
  def physical(x):return sum(bool(x&m)<<i for i,m in enumerate(b))|((x>>13)<<11)
  ps={physical(x) for x in P};ns={physical(x) for x in N}
  # Every last-gate raw AND/OR alternative is impossible.
  assert all(any(not v>>i&1 for v in ps) and any(v>>i&1 for v in ns) for i in range(18))
  forbidden=set();copyable=((1<<18)-1)^2047^(1<<j);depths=[]
  for K,O in masks[idx]:
   cut,data=kill_table(ps,ns,K,O)
   raw=' '.join(map(str,data))+'\n'
   ret=subprocess.run([str(exe)],input=raw,text=True,capture_output=True,check=True)
   depth,live=map(int,ret.stdout.split());assert live==0
   forbidden.update(cut);copyable&=K;depths.append(depth)
  assert any((p&~n)==1<<h and n>>j&1 for p in ps for n in ns)
  allowed=[]
  for q in range(11):
   for l in range(11,18):
    for op in [0,1]:
     if (q,l,op) in forbidden:continue
     def needs(a,other):
      return any(p&~n==1<<a and ((n>>other)&1 if op else not (p>>other)&1) for p in ps for n in ns)
     if needs(q,l) or (needs(l,q) and not copyable>>l&1):continue
     allowed.append((q,l,op))
  assert allowed==[(h,j,0)],(idx,allowed)
  print(idx,'role',h,j-11,'depths',depths,'only source',allowed[0],flush=True)
  actual.append(idx)
 assert actual==sorted(masks)
 print('All 23 bank orbits excluded.',flush=True)
