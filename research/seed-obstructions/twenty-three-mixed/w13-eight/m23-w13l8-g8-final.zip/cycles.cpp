#include <array>
#include <algorithm>
#include <bitset>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
using namespace std;
using B=bitset<245>;using V=vector<int>;using Table=vector<B>;using Profile=vector<B>;
using Choices=vector<Profile>;
struct Cycle{V p,l,pm,lm;};
Table pv(8192),lv(128);
vector<V> load(string f){ifstream in(f);string s;vector<V> out;while(getline(in,s)){istringstream a(s);V v;int i;while(a>>i)v.push_back(i);out.push_back(v);}return out;}
Choices prepare(const V& bank,const V& verts,const V& maxneg,const Table& tab){
 int S=0;for(int v:verts)S|=v;vector<V> opt(verts.size());for(int j=0;j<bank.size();j++)for(int t=0;t<verts.size();t++)if((bank[j]&S)==verts[t])opt[t].push_back(j);
 Choices out;V rep;auto go=[&](auto&& self,int t,unsigned used)->void{
 if(t<verts.size()){for(int j:opt[t]){rep.push_back(j);self(self,t+1,used|(1<<j));rep.pop_back();}return;}
 B base;base.set();for(int j=0;j<bank.size();j++)if((bank[j]&S)&&!(used>>j&1))base&=tab[bank[j]];
 if(base.none())return;Profile m;for(int q:maxneg){B b=base;for(int j=0;j<verts.size();j++)if(verts[j]&q)b&=tab[bank[rep[j]]];m.push_back(b);}
 for(auto &prior:out){bool dom=true;for(int i=0;i<m.size();i++)if((m[i]&~prior[i]).any()){dom=false;break;}if(dom)return;}
 out.push_back(m);};go(go,0,0);return out;}
int main(int ac,char**av){int t=atoi(av[1]),L=ac>2?atoi(av[2]):(t==3?9:8);auto N=load("neg");for(int j=0;j<N.size();j++){int x=N[j][0];for(int m=0;m<8192;m++)if(x&m)pv[m].set(j);for(int m=0;m<128;m++)if((x>>13)&m)lv[m].set(j);}
 vector<Cycle> cycles;for(auto &v:load("cycles"+to_string(t))){Cycle c;for(int i=0;i<t;i++){c.p.push_back(v[i]);c.l.push_back(v[i+t]);}for(int j=2*t+1;j<v.size();j+=2){c.pm.push_back(v[j]);c.lm.push_back(v[j+1]);}cycles.push_back(c);}
 auto ps=load("points"),ls=load("lines"+to_string(L));vector<vector<bool>> allowed(ls.size(),vector<bool>(ps.size(),ac<=3));if(ac>3)for(auto r:load(av[3]))allowed[r[1]][r[0]]=true;vector<vector<Choices>> pp;for(auto v:ps){v.erase(v.begin());vector<Choices> all;for(auto &c:cycles)all.push_back(prepare(v,c.p,c.pm,pv));pp.push_back(all);}
 long long counts[3]{},tot[3]{};string suf=ac>3?"-remaining":"";ofstream pending("left"+to_string(L)+suf),cert("hits"+to_string(L)+suf);
 for(int line=0;line<ls.size();line++){if(find(allowed[line].begin(),allowed[line].end(),true)==allowed[line].end())continue;vector<Choices> lp;for(auto &c:cycles)lp.push_back(prepare(ls[line],c.l,c.lm,lv));
 for(int point=0;point<ps.size();point++){if(!allowed[line][point])continue;int cost=ps[point][0],found=-1;tot[cost]++;for(int c=0;c<cycles.size()&&found<0;c++)for(auto &p:pp[point][c]){for(auto &l:lp[c]){bool ok=true;bool mono=false;for(int i=0;i<p.size();i++){bool witness=(p[i]&l[i]).any();bool both=cycles[c].pm[i]&&cycles[c].lm[i];if(t==3 && !both)mono|=witness;else if(!witness){ok=false;break;}}if(t==3&&!mono)ok=false;if(ok){found=c;break;}}if(found>=0)break;}
 if(found>=0){counts[cost]++;cert<<point<<' '<<line<<' '<<found<<'\n';}else pending<<point<<' '<<line<<'\n';}}
 for(int i=0;i<3;i++)cout<<L<<" point price "<<i<<" excluded "<<counts[i]<<" of "<<tot[i]<<endl;}
