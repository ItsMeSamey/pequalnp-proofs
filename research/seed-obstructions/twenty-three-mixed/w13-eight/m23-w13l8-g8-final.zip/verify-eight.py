from pathlib import Path
import tempfile,subprocess
from staged import run
from completion import cost
from exact_after import after
import staged
here=Path(__file__).resolve().parent
def records(p):
 with p.open()as f:
  for r in f:yield tuple(map(int,r.split()))
with tempfile.TemporaryDirectory()as tmp:
 w=Path(tmp)
 for n,cpp in [('price8','price8.cpp'),('geo','geo.cpp'),('cycles','cycles.cpp'),('endpoint24','endpoint24.cpp'),('assignments','assignments.cpp'),('stages','stages.cpp')]:
  subprocess.run(['g++','-std=c++20','-O3',here/cpp,'-o',w/n],check=True)
 staged.root=w;staged.raw=here/'rows'
 with (here/'points').open()as f,(w/'votes').open('w')as out:subprocess.run([w/'geo',here/'rows'],stdin=f,stdout=out,check=True)
 es=[[m for m in range(128) if m.bit_count()==k] for k in (2,3)]
 ps=[];vs=[];nb=ng=0
 with (w/'exact-price-input').open('w')as f:
  for p,v in zip(records(here/'points'),records(w/'votes'),strict=True):
   assert len(p)==14 and p[0]==0 and len(v)==2;nb+=1
   if not any(v):continue
   ng+=1;p=p[1:]
   if cost(p)+8<21:continue
   ps.append(p);vs.append(v)
   if len(set(p))==13 and min(p)>0:print(*p,file=f)
 assert nb==420948 and ng==104753
 with (w/'exact-price-input').open()as f,(w/'priced').open('w')as out:subprocess.run([w/'price8',here/'action-price','emit'],stdin=f,stdout=out,check=True)
 kept=set(records(w/'priced'));P=[];V=[]
 for p,v in zip(ps,vs):
  if len(set(p))<13 or min(p)==0 or p in kept:P.append(p);V.append(v)
 print('geometry and price',len(P),flush=True)
 lines=''.join(' '.join(map(str,[*(1<<j for j in range(7)),e]))+'\n' for e in es[0]+es[1])
 for ix in range(0,len(P),1024):
  d=w/f'd{ix}';d.mkdir()
  for n in ['neg','cycles4']:(d/n).symlink_to(here/n)
  (d/'lines8').write_text(lines)
  with (d/'points').open('w')as f,(d/'legal').open('w')as out:
   for i,(p,v) in enumerate(zip(P[ix:ix+1024],V[ix:ix+1024])):
    print(0,*p,file=f)
    for k,x in enumerate(v):
     for j in range(len(es[k])):
      if x>>j&1:print(i,j+k*len(es[0]),file=out)
  subprocess.run([w/'cycles','4','8','legal'],cwd=d,check=True)
  run(d,d/'left8-remaining')
  print('exact survivors rejected',after(d,w/'endpoint24',here/'rows'))
