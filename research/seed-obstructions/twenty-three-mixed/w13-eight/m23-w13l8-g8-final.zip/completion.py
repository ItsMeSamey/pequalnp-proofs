from functools import lru_cache
from pathlib import Path
root=Path(__file__).resolve().parent
def stars_from(rows):
 p=tuple(map(int,rows.read_text().split()))
 stars=[0]*7
 for v in p[2:2+p[0]]:stars[(v>>13).bit_length()-1]|=v&8191
 assert all(s.bit_count()==4 for s in stars)
 return tuple(stars)
stars=stars_from(root/'rows' if (root/'rows').exists() else root.parent/'thirteen-eight'/'rows')
@lru_cache(None)
def one(target,parts):
 if target in parts:return 0
 base=[1<<i for i in range(13) if (target>>i)&1]+list(parts)
 sums={x|y for x in base for y in base}
 if target in sums:return 1
 if any(target==(x|y) for x in sums for y in base):return 2
 return 3
def cost(bank):return sum(one(s,tuple(sorted({v for v in bank if v.bit_count()>=2 and (v&~s)==0})))for s in stars)
if __name__=='__main__':
 from collections import Counter
 import sys
 d=Path(sys.argv[1]);p=[tuple(map(int,r.split()[1:])) for r in (d/'points').open()]
 hist=Counter(cost(b)for b in p);print('bank-completion',sorted(hist.items()))
 if (d/'stage.left').exists():
  valid=Counter()
  for l in (d/'stage.left').open():
   i,j,*a=map(int,l.split());valid[i,j]=cost(p[i])
  print('survivors',sorted(valid.items()))
