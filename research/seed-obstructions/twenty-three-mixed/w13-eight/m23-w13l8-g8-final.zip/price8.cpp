#include <algorithm>
#include <array>
#include <bit>
#include <bitset>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;using U=uint64_t;
struct Key{array<short,8> t{};bool operator==(const Key&o)const{return t==o.t;}};
struct Hash{size_t operator()(const Key&k)const{U x=47;for(int a:k.t)x=(x^a)*1099511628211ull;return x;}};
array<int,31> raw;array<bool,8192> israw{};array<int,13> sig[24];int pm[24][8192];
bitset<8192> stepraw[8192];vector<int> first;bitset<8192> rawfirst;
using BS=bitset<128>;
struct Solver{
 int k,full,t[8]{},h;array<int,8192> idx{};vector<int> req[8];U cuts=0,member[8]{},edge[8][8]{};
 U help[8192];bitset<8192> computed;
 struct Pool{bitset<8192> known;vector<int> vals;vector<U> types;bool ready=false;};
 Pool pools[64];
 Solver(const vector<int>&z,int maxh):k(z.size()),full((1<<k)-1),h(maxh){for(int i=0;i<k;i++){t[i]=z[i];idx[t[i]]=1<<i;}}
 bool valid(int x){return x&&!israw[x]&&!idx[x];}
 int close(int seed,int x=0){int done=seed,last;
 do{last=done;for(int j=0;j<k;j++)if(!(done>>j&1)){bool ok=x&&stepraw[x][t[j]];for(int a:req[j])if(!(a&~done)){ok=true;break;}
 if(!ok&&x)for(int i=0;i<k;i++)if((done>>i&1)&&((x|t[i])==t[j]||(x&t[i])==t[j])){ok=true;break;}if(ok)done|=1<<j;}}while(last!=done);return done;}
 vector<int> helpful;
 U receipt(int x){return help[x];}
 void inverses(int target,int y,U flag){
 if(!flag||target==y)return;
 auto put=[&](int z){if(valid(z)){if(!help[z])helpful.push_back(z);help[z]|=flag;}};
 if((target&y)==y){int need=target^y;for(int u=y;;u=(u-1)&y){put(need|u);if(!u)break;}}
 else if((target&y)==target){int extra=8191^y;for(int u=extra;;u=(u-1)&extra){put(target|u);if(!u)break;}}}
 void add(Pool&p,int x){if(valid(x)&&!p.known[x]){p.known.set(x);p.vals.push_back(x);}}
 void make(Pool&p,int set,bool withTypes){if(!p.ready){for(int x:first)add(p,x);for(int i=0;i<k;i++)if(set>>i&1){int x=t[i];for(int y:raw){add(p,x|y);add(p,x&y);}for(int j=0;j<i;j++)if(set>>j&1){add(p,x|t[j]);add(p,x&t[j]);}}p.ready=true;}
 if(withTypes&&p.types.empty()){for(int x:p.vals)p.types.push_back(receipt(x));sort(p.types.begin(),p.types.end());p.types.erase(unique(p.types.begin(),p.types.end()),p.types.end());}}
 bool solve(){
 for(int j=0;j<k;j++){if(rawfirst[t[j]])req[j].push_back(0);for(int i=0;i<k;i++)if(i!=j){if(stepraw[t[i]][t[j]])req[j].push_back(1<<i);for(int m=0;m<i;m++)if(m!=j&&((t[i]|t[m])==t[j]||(t[i]&t[m])==t[j]))req[j].push_back((1<<i)|(1<<m));}}
 int base=close(0);if(base==full)return true;if(h==0)return false;
 if(h==1){Pool p;make(p,base,false);for(int x:p.vals)if(close(base,x)==full)return true;return false;}
 if(h>2)return true;
 for(int s=1;s<=full;s++)if(!(s&base)){bool closed=true;for(int j=0;j<k&&closed;j++)if(s>>j&1)for(int a:req[j])if(!(a&s)){closed=false;break;}
 if(!closed)continue;U bit=U(1)<<(s-1);cuts|=bit;for(int j=0;j<k;j++)if(s>>j&1){member[j]|=bit;for(int i=0;i<k;i++)if(!(s>>i&1))edge[j][i]|=bit;}}
 fill(help,help+8192,0);for(int j=0;j<k;j++)if(member[j]){for(int r:raw)inverses(t[j],r,member[j]);for(int i=0;i<k;i++)if(i!=j)inverses(t[j],t[i],edge[j][i]);}
 struct Candidates{vector<int> y;bool needDirect;};unordered_map<U,Candidates> cand;
 auto& p=pools[base];make(p,base,true);for(int x:p.vals){U miss=cuts&~receipt(x);if(!miss)return true;int avail=0;for(int j=0;j<k;j++)if(!(miss&member[j]))avail|=1<<j;
 auto &q=pools[avail];make(q,avail,true);
 auto [it,added]=cand.try_emplace(miss);auto &cs=it->second;
 if(added){
  for(int y:helpful)if(!(miss&~help[y]))cs.y.push_back(y);
  cs.needDirect=false;
  for(U pat:q.types){if(miss==cuts&&pat)continue;U left=miss&~pat;if(!left)continue;
   for(int j=0;j<k&&!cs.needDirect;j++)for(int l=0;l<=j;l++)if((t[j]&t[l])==t[j]||(t[j]&t[l])==t[l])if(!(left&~(member[j]|member[l]))){cs.needDirect=true;break;}
   if(cs.needDirect)break;}}
 if(!cs.y.empty()){
  if(cs.y.size()<48){for(int y:cs.y){if(q.known[y]||stepraw[x][y])return true;for(int j=0;j<k;j++)if(avail>>j&1)if((x|t[j])==y||(x&t[j])==y)return true;}}
  else{for(U pat:q.types)if(!(miss&~pat))return true;auto use=[&](int y){return valid(y)&&!(miss&~receipt(y));};for(int a:raw)if(use(x|a)||use(x&a))return true;
  for(int j=0;j<k;j++)if(avail>>j&1)if(use(x|t[j])||use(x&t[j]))return true;}}
 if(!cs.needDirect)continue;
 auto aux=[&](int y){if(!q.known[y]||y==x||(miss==cuts&&help[y]))return false;int z=idx[x|y]|idx[x&y];U mm=miss&~receipt(y);for(;z;z&=z-1)mm&=~member[countr_zero((unsigned)z)];return !mm;};
 for(int j=0;j<k;j++){if(!(miss&member[j]))continue;int target=t[j];if((x&target)==x){int need=x^target;for(int z=x;;z=(z-1)&x){if(aux(need|z))return true;if(!z)break;}}
 else if((x&target)==target){int extra=8191^x;for(int z=extra;;z=(z-1)&extra){if(aux(target|z))return true;if(!z)break;}}}
 }return false;
 }
};
int main(int argc,char**argv){ios::sync_with_stdio(false);cin.tie(nullptr);ifstream f(argv[1]);for(auto&r:raw){f>>r;israw[r]=true;}for(auto &s:pm)for(int&v:s)f>>v;
 for(int x=1;x<8192;x++)for(int r:raw){stepraw[x].set(x|r);stepraw[x].set(x&r);}for(int x:raw)for(int y:raw){rawfirst.set(x&y);rawfirst.set(x|y);}
 for(int i=1;i<8192;i++)if(rawfirst[i]&&!israw[i])first.push_back(i);
 array<int,8192> orprice;orprice.fill(100);orprice[0]=0;for(int v=1;v<8192;v++)for(int r:raw)if(!(r&~v))orprice[v]=min(orprice[v],1+orprice[v&~r]);
 unordered_map<Key,bool,Hash>cache;cache.reserve(300000);long long total=0,keep=0,solves=0;array<int,13>b;
 while(cin>>b[0]){for(int i=1;i<13;i++)cin>>b[i];total++;bool ok=false;vector<Key> options;
 for(auto&g:pm){Key key;int k=0;for(int x:b){if(!israw[g[x]]){if(k==8){k=9;break;}key.t[k++]=g[x];}}if(k>8)continue;if(k<6){ok=true;break;}sort(key.t.begin(),key.t.begin()+k);options.push_back(key);}
 sort(options.begin(),options.end(),[](const Key&a,const Key&b){return a.t<b.t;});options.erase(unique(options.begin(),options.end()),options.end());
 stable_sort(options.begin(),options.end(),[&](const Key&a,const Key&b){int x=0,y=0;for(int t:a.t)if(t)x+=orprice[t]-1;for(int t:b.t)if(t)y+=orprice[t]-1;return x<y;});
 for(auto&key:options){auto [it,added]=cache.try_emplace(key,false);if(added){vector<int> targets;for(int x:key.t)if(x)targets.push_back(x);Solver s(targets,8-targets.size());it->second=s.solve();solves++;}if(it->second){ok=true;break;}}
 if(ok){keep++;if(argc>2){for(int x:b)cout<<x<<' ';cout<<'\n';}}if(total%1000==0)cerr<<total<<' '<<keep<<' '<<solves<<'\n';if(cache.size()>4500000)cache.clear();}
 cerr<<"final "<<total<<' '<<keep<<' '<<solves<<'\n';
}
