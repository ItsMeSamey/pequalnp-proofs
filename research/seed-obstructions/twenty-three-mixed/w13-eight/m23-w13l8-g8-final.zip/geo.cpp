#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;using U=__uint128_t;
int ix(U x){return (unsigned long long)x?countr_zero((unsigned long long)x):64+countr_zero((unsigned long long)(x>>64));}
struct Row{int p,n;U flags;};
bool hit(const vector<int>&a,const vector<int>&b,int yes=0,int no=0){
 int q=0;
 for(;;){int ny=yes,nn=no,pa=0,pb=0,best=14;
  for(int s=0;s<2;s++)for(int x:s?b:a){if(x&(s?no:yes))continue;
   int rem=x&~(s?yes:no);if(!rem)return false;
   if((rem&(rem-1))==0){(s?nn:ny)|=rem;continue;}
   (s?pb:pa)++;int c=popcount((unsigned)rem);
   if(c<best){best=c;q=rem&-rem;}
  }
  if(ny&nn)return false;if(ny!=yes||nn!=no){yes=ny;no=nn;continue;}
  if(!pa||!pb)return true;break;
 }
 return hit(a,b,yes|q,no)||hit(a,b,yes,no|q);
}
#include "private.hpp"
int main(int argc,char**av){
 ifstream fs(av[1]);int np,nn;fs>>np>>nn;assert(np==28&&nn==245);
 vector<int>P(np),N(nn);int star[7]{};for(int &p:P){fs>>p;star[countr_zero((unsigned)(p>>13))]|=p&8191;}for(int &n:N)fs>>n;
 int jnum=0,jidx[128]{};vector<int> groups;for(int m=1;m<128;m++)if(popcount((unsigned)m)<=4){jidx[m]=jnum++;groups.push_back(m);}assert(jnum==98);
 vector<int> pat;int id[8192];fill_n(id,8192,-1);auto get=[&](int x){if(id[x]<0){id[x]=pat.size();pat.push_back(x);}return id[x];};
 vector<Row>pr,ou;
 for(int t=0;t<7;t++)for(int x=0;x<13;x++)if(star[t]>>x&1)for(int y=0;y<13;y++)if(!(star[t]>>y&1))for(int z=0;z<y;z++)if(!(star[t]>>z&1))pr.push_back({get(1<<x),get((1<<y)|(1<<z)),1ULL<<t});
 for(int p:P)for(int n:N)if((p>>13)&(n>>13)){int meet=0;for(int t=0;t<7;t++)if(n&star[t])meet|=1<<t;U tags=0;
  for(int j:groups)if(!(j&(p>>13))&&!(j&~meet))tags|=U(1)<<jidx[j];if(tags)ou.push_back({get(p&8191),get(n&8191),tags});}
 vector<int>rank(8192);for(int i=0;i<8192;i++)rank[i]=i;sort(rank.begin(),rank.end(),[](int x,int y){return popcount((unsigned)x)<popcount((unsigned)y);});
 array<int,13>b;long long total=0;array<long long,22>counts{};
 int ignored;while(cin>>ignored>>b[0]){for(int k=1;k<13;k++)cin>>b[k];vector<int>code(pat.size());for(int j=0;j<(int)pat.size();j++)for(int k=0;k<13;k++)if(pat[j]&b[k])code[j]|=1<<k;
  U at[8192]{},bt[8192]{};for(auto r:pr)at[code[r.p]&~code[r.n]]|=r.flags;for(auto r:ou)bt[code[r.p]&~code[r.n]]|=r.flags;
  vector<int>pp[7],oo[98];
  auto push=[](vector<int>&v,int m){for(int x:v)if(!(x&~m))return;v.push_back(m);};
  for(int x:rank){U a=at[x],b=bt[x];for(;a;a&=a-1)push(pp[ix(a)],x);for(;b;b&=b-1)push(oo[ix(b)],x);}
  array<array<Mask,13>,7> truth{};
  for(int t=0;t<7;t++)for(int i=0;i<13;i++){int pos=0,neg=4;
   for(int j=0;j<13;j++)if(star[t]>>j&1){if(b[i]>>j&1)truth[t][i]|=1ULL<<pos;pos++;}
   for(int a=0;a<13;a++)if(!(star[t]>>a&1))for(int z=0;z<a;z++)if(!(star[t]>>z&1)){if(b[i]&((1<<a)|(1<<z)))truth[t][i]|=1ULL<<neg;neg++;}
   assert(pos==4&&neg==40);
  }
  U possibles=0;
  for(int m:groups){vector<int>all;for(int j=0;j<7;j++)if(m>>j&1)all.insert(all.end(),pp[j].begin(),pp[j].end());if(hit(all,oo[jidx[m]])&&(!has_single_bit((unsigned)m)||private_one(all,oo[jidx[m]],truth[countr_zero((unsigned)m)])))possibles|=U(1)<<jidx[m];}
  unsigned long long f3=0,f4=0;int n3=0,n4=0;
  for(int E=0;E<128;E++){
   int ne=popcount((unsigned)E);if(ne!=2&&ne!=3)continue;
   int O=127^E;bool ok=false;
   for(int J=O;J;J=(J-1)&O)if(popcount((unsigned)J)<=3 && popcount((unsigned)(O^J))<=3 && ((possibles>>jidx[J])&1)){ok=true;break;}
   if(ne==2)f3|=(unsigned long long)(ok)<<n3++;else f4|=(unsigned long long)(ok)<<n4++;
  }
  cout<<f3<<" "<<f4<<"\n";total++;
 }
 cerr<<"banks "<<total<<"\n";
}
