using Mask=unsigned long long;
bool tree_guard(unsigned available,const array<Mask,13>& vals){
 int k=popcount(available);
 for(auto a=available;a;a&=a-1)if(vals[countr_zero(a)]==15)return true;
 // A read-once formula's minterm and maxterm intersect once.
 array<int,13> needp{};array<Mask,13> needn{};
 for(int p=0;p<4;p++)for(int t=4;t<40;t++){
  unsigned diff=0;
  for(auto z=available;z;z&=z-1){int j=countr_zero(z);if((vals[j]>>p&1)&&!(vals[j]>>t&1))diff|=1u<<j;}
  if(!diff)return false;
  if(has_single_bit(diff)){int j=countr_zero(diff);needp[j]|=1<<p;needn[j]|=1ULL<<t;}
 }
 for(int i=0;i<13;i++)for(int j=0;j<i;j++)if((needp[i]&needp[j])&&(needn[i]&needn[j]))return false;
 if(k>5)return true;
 // Exact search allowing arbitrary subsets of the available slots.
 array<vector<Mask>,32> dp;
 int i=0;for(auto a=available;a;a&=a-1)dp[1<<i++].push_back(vals[countr_zero(a)]);
 auto put=[](vector<Mask>&v,Mask z){
  if(!(z&15))return;
  for(auto x:v)if((x&z&15)==(z&15)&&!(x&~z&~15ULL))return;
  v.erase(remove_if(v.begin(),v.end(),[&](Mask x){return (x&z&15)==(x&15)&&!(z&~x&~15ULL);}),v.end());
  v.push_back(z);
 };
 for(int m=1;m<(1<<k);m++){
  for(int a=(m-1)&m;a;a=(a-1)&m){int b=m^a;if(b<a)continue;
   for(Mask x:dp[a])for(Mask y:dp[b]){if((x&y)==15||(x|y)==15)return true;put(dp[m],x&y);put(dp[m],x|y);}
  }
 }
 return false;
}
bool private_one(const vector<int>&pa,const vector<int>&outside,const array<Mask,13>&vals){
 unsigned char seen[8192]{};
 auto go=[&](auto&&self,unsigned possible)->bool{
  if(seen[possible])return false;seen[possible]=1;
  for(int m:pa)if(!(m&possible))return false;
  for(unsigned m:outside)if(!(m&~possible)){
   for(auto a=m;a;a&=a-1)if(self(self,possible^(a&-a)))return true;
   return false;
  }
  return tree_guard(possible,vals);
 };
 return go(go,8191);
}
