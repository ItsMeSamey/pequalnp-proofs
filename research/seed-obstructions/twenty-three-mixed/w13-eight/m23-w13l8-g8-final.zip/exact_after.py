from pathlib import Path
import subprocess
def after(d,exe,raw):
 def read(p):return [tuple(map(int,r.split()))for r in p.open()]
 pairs=sorted(set(r[:2]for r in read(d/'stage.left')))
 if not pairs:return 0
 P=read(d/'bare');L=read(d/'lines8');R=tuple(map(int,raw.read_text().split()))
 with (d/'final.in').open('w')as f:
  for i,j in pairs:
   B=(*P[i],*(v<<13 for v in L[j]))
   print(*R[:2],*(sum(1<<k for k,m in enumerate(B)if m&x)for x in R[2:]),file=f)
 with (d/'final.in').open()as inp:
  t=subprocess.run([exe,'13','8','3'],stdin=inp,capture_output=True,text=True,check=True)
 states=t.stdout.splitlines();assert len(states)==len(pairs)
 pending=[ij for ij,s in zip(pairs,states)if not s.startswith('0 ')]
 assert not pending,pending
 return len(pairs)
