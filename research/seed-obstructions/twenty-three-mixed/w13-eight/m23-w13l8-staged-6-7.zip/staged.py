from pathlib import Path
import sys,subprocess,time
root=Path(__file__).resolve().parent
raw=root.parent/'thirteen-eight'/'rows'
def run(d,source):
 bare=d/'bare'
 if not bare.exists():
  with bare.open('w')as f:
   for r in (d/'points').open():f.write(r.split(' ',1)[1])
 rows=[tuple(map(int,r.split())) for r in source.open()]
 with (d/'stage.cases').open('w')as f:
  for i,j in sorted(rows): print(i,j,file=f)
 with (d/'stage.cases').open()as inp,(d/'assignment.summary').open('w')as log,(d/'stage.log').open('w')as stat,(d/'stage.left').open('w')as left:
  a=subprocess.Popen([root/'assignments',raw,bare,d/'lines8','13','8','3','4294967294'],stdin=inp,stdout=subprocess.PIPE,stderr=log,text=True)
  v=subprocess.Popen([root/'stages',raw,bare,d/'lines8'],stdin=subprocess.PIPE,stdout=left,stderr=stat,text=True)
  ncase=0;npart=0
  for row in a.stdout:
   t=row.split()
   if t[0]=='CASE':i,j=t[1:];ncase+=1
   elif len(t)==4: print(i,j,*t,file=v.stdin);npart+=1
   else:raise ValueError(row)
  assert a.wait()==0;v.stdin.close();assert v.wait()==0 and ncase==len(rows)
 print(d,len(rows),npart,sum(1 for _ in (d/'stage.left').open()),flush=True)
if __name__=='__main__':run(Path(sys.argv[1]),Path(sys.argv[2]))
