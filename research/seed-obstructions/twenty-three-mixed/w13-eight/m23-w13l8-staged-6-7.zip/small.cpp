#include <algorithm>
#include <array>
#include <bit>
#include <iostream>
#include <set>
#include <vector>
using namespace std;using U=unsigned;using V=vector<U>;unsigned goal;int P,N,K;set<V> seen[5];long long countv;
bool dfs(V v,int k){
 sort(v.begin(),v.end());if(!seen[k].insert(v).second)return false;countv++;
 if(find(v.begin(),v.end(),goal)!=v.end())return true;
 unsigned pm[28]={},nm[32]={};for(int t=0;t<v.size();t++){for(int i=0;i<P;i++)if(v[t]>>i&1)pm[i]|=1<<t;for(int i=0;i<N;i++)if(v[t]>>(P+i)&1)nm[i]|=1<<t;}
 for(int i=0;i<P;i++)for(int j=0;j<N;j++)if(!(pm[i]&~nm[j]))return false;
 for(int i=0;i<v.size();i++)for(int j=0;j<i;j++)for(int o=0;o<2;o++){U h=o?v[i]&v[j]:v[i]|v[j];if(h==v[i]||h==v[j])continue;
 for(int s=0;s<4;s++){int q=popcount((unsigned)s);if(q>k)continue;V a;for(int x=0;x<v.size();x++)if((x!=i||(s&1))&&(x!=j||(s&2)))a.push_back(v[x]);a.push_back(h);if(dfs(a,k-q))return true;}}
 return false;
}
int main(){int W;while(cin>>W>>K>>P>>N){V v(W);goal=(1<<P)-1;for(int j=0;j<P+N;j++){U x;cin>>x;for(int i=0;i<W;i++)v[i]|=((x>>i)&1)<<j;}for(auto &z:seen)z.clear();countv=0;bool yes=dfs(v,K);cout<<W<<' '<<K<<' '<<yes<<' '<<countv<<endl;}}
