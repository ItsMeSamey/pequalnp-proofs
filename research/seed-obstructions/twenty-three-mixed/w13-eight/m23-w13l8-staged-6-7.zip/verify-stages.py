from pathlib import Path
from itertools import permutations
import subprocess,tempfile,shutil
from staged import run
here=Path(__file__).resolve().parent
def read(f):return [tuple(map(int,s.split())) for s in f.open()]
def check_geo():
 raw=tuple(map(int,(here/'rows').read_text().split()));np,nn=raw[:2];P=set(raw[2:2+np]);N=set(raw[2+np:]);assert len(P)==28 and len(N)==245 and set(x[0] for x in read(here/'neg'))==N
 standard=read(here/'omissions.in')
 E=set(standard[0][4:12]); assert E==set(standard[1][4:12])
 neg={n for n in range(256) if not any((e&n)==e for e in E)}
 mx={n for n in neg if not any(n!=v and n&~v==0 for v in neg)}
 assert len(mx)==10
 orbit=set()
 for row in standard:
  assert row[:4]==(8,3,8,9)
  hole,=mx-set(row[12:]);assert set(row[12:])<=mx
  for rot in range(8):
   for sign in (-1,1):
    cycle=[0,4,3,7,2,6,1,5]
    def img(x):return sum(1<<cycle[(rot+sign*i)%8] for i,j in enumerate(cycle) if x>>j&1)
    assert {img(e) for e in E}==E
    orbit.add(img(hole))
 assert orbit==mx
 for row in read(here/'cycles4'):
  ps=row[:4];ls=row[4:8];pairs=set(zip(row[9::2],row[10::2]));assert row[8]==10 and len(pairs)==10
  edges={1<<i|1<<(4+j) for i,p in enumerate(ps) for j,l in enumerate(ls) if p|(l<<13) in P}
  assert any({sum(1<<a[i] for i in range(4) if e>>i&1)+sum(1<<(4+b[j]) for j in range(4) if e>>(4+j)&1) for e in edges}==E for a in permutations(range(4)) for b in permutations(range(4)))
  ind={x for x in range(256) if not any((x&e)==e for e in edges)}
  mm={x for x in ind if not any(y!=x and x&~y==0 for y in ind)}
  assert pairs=={(sum(p for i,p in enumerate(ps) if x>>i&1),sum(l for j,l in enumerate(ls) if x>>(4+j)&1))for x in mm}
check_geo()
with tempfile.TemporaryDirectory()as tmp:
 t=Path(tmp)
 for n in ['small','partial','assignments','stages']:
  subprocess.run(['c++','-O3','-std=c++20',here/(n+'.cpp'),'-o',t/n],check=True)
 with (here/'omissions.in').open()as f:
  a=subprocess.run([t/'small'],stdin=f,capture_output=True,text=True,check=True)
  assert [r.split()[2] for r in a.stdout.splitlines()]==['0','0']
 rule=t/'rule';rule.write_text((' '.join(str(int(j.bit_count()>=9)) for j in range(1024))+'\n')*len(read(here/'cycles4')))
 import staged
 staged.root=t;staged.raw=here/'rows'
 for src in sorted(here.glob('g[0-9]')):
  g=int(src.name[1:]);d=t/src.name;d.mkdir()
  for n in ['points','lines8']:(d/n).symlink_to(src/n)
  for n in ['cycles4','neg']:(d/n).symlink_to(here/n)
  assert read(d/'lines8')==[tuple(1<<i for i in range(7))+(e,) for e in range(128) if 2<=e.bit_count()<=11-g]
  with (d/'left').open('w')as out:subprocess.run([t/'partial','0',str(len(read(d/'points'))),rule],stdout=out,cwd=d,check=True)
  run(d,d/'left')
  assert (d/'stage.left').stat().st_size==0
