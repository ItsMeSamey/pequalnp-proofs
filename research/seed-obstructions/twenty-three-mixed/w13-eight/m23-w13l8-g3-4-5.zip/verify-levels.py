from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parent
def read(p):return [tuple(map(int,r.split())) for r in p.read_text().splitlines()]
data=tuple(map(int,(root/'rows').read_text().split()))
with tempfile.TemporaryDirectory()as td:
 t=Path(td)
 for name in ['cycles','cohort','endpoint24']:
  subprocess.run(['g++','-std=c++20','-O3',root/(name+'.cpp'),'-o',t/name],check=True)
 for d in sorted(root.glob('g[0-9]')):
  g=int(d.name[1:]);w=t/d.name;w.mkdir()
  for n in ['neg','cycles4']:(w/n).symlink_to(root/n)
  for n in ['points','lines8']:(w/n).symlink_to(d/n)
  P=read(w/'points');L=read(w/'lines8');raw=tuple(1<<i for i in range(7))
  assert L==[raw+(e,) for e in range(128) if 2<=e.bit_count()<=11-g]
  subprocess.run([t/'cycles','4','8'],cwd=w,check=True)
  ordered=subprocess.run([t/'cohort',root/'rows',w/'points',w/'lines8','0',str(len(P)),'128'],stdout=subprocess.PIPE,text=True,check=True)
  keep=sorted(set(read(w/'left8')).intersection(tuple(map(int,r.split())) for r in ordered.stdout.splitlines()))
  with (w/'pack').open('w')as out:
   for i,j in keep:
    b=P[i][1:]+tuple(x<<13 for x in L[j])
    print(*data[:2],*(sum(1<<k for k,v in enumerate(b) if v&x)for x in data[2:]),file=out)
  with (w/'pack').open()as inp:
   out=subprocess.run([t/'endpoint24','13','8','3'],stdin=inp,stdout=subprocess.PIPE,text=True,check=True).stdout.splitlines()
  assert len(out)==len(keep) and all(r.startswith('0 ') for r in out)
  print('VERIFIED',g,len(P),len(L),len(keep),flush=True)
