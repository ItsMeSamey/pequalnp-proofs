#include "pair-bipartite.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <numeric>
using namespace std;
using namespace ordered_regions_pair;
using Bank=array<int,13>;
using TB=array<uint64_t,5>;
struct Scan{
 vector<Bank> points;vector<Side> lines;array<TB,8192> table{};
 unsigned long long tries=0,cut=0,pass=0,nodes=0;
 void scan(int lo,int hi,const vector<int>&active){
  nodes++;array<TB,13> x{};
  for(int j=0;j<13;j++)x[j]=table[points[lo][j]];
  for(int i=lo+1;i<hi;i++)for(int j=0;j<13;j++){auto&v=table[points[i][j]];x[j][0]|=v[0];for(int k=1;k<5;k++)x[j][k]&=v[k];}
  array<Mask,28> p{};array<Mask,245> n{};
  for(int j=0;j<13;j++){for(int i=0;i<28;i++)p[i]|=((x[j][0]>>i)&1)<<j;for(int i=0;i<245;i++)n[i]|=((x[j][1+i/64]>>(i%64))&1)<<j;}
  vector<int> keep;
  {Side side(13,p,n);for(int l:active){tries++;if(check(side,lines[l],3,500).possible)keep.push_back(l);}}
  cut+=(hi-lo)*(active.size()-keep.size());
  if(keep.empty())return;
  if(hi-lo==1){for(auto j:keep)cout<<lo<<' '<<j<<'\n';pass+=keep.size();return;}
  int mid=(lo+hi)/2;scan(lo,mid,keep);scan(mid,hi,keep);
 }
};
int main(int argc,char**argv){
 if(argc!=7)return 1;Scan s;ifstream f(argv[1]);int pn,nn;f>>pn>>nn;if(pn!=28||nn!=245)return 2;
 vector<int> pos(28),neg(245);for(int&x:pos)f>>x;for(int&x:neg)f>>x;
 for(int m=0;m<8192;m++){for(int q=0;q<28;q++)if(m&pos[q])s.table[m][0]|=1ull<<q;for(int q=0;q<245;q++)if(m&neg[q])s.table[m][1+q/64]|=1ull<<(q%64);}
 ifstream pf(argv[2]);int dummy;Bank b{};while(pf>>dummy){for(int&x:b)pf>>x;s.points.push_back(b);}
 ifstream lf(argv[3]);vector<int> l(8);while(lf>>l[0]){for(int j=1;j<8;j++)lf>>l[j];vector<Mask>p,n;
  auto mask=[&l](int x){Mask r=0;for(int j=0;j<8;j++)if(l[j]&(x>>13))r|=1<<j;return r;};
  for(int x:pos)p.push_back(mask(x));for(int x:neg)n.push_back(mask(x));s.lines.emplace_back(8,p,n);}
 vector<int> active(s.lines.size());iota(active.begin(),active.end(),0);int lo=stoi(argv[4]),hi=min(stoi(argv[5]),(int)s.points.size()),chunk=stoi(argv[6]);
 for(int ix=lo;ix<hi;ix+=chunk)s.scan(ix,min(hi,ix+chunk),active);
 if(s.pass+s.cut!=(unsigned long long)(hi-lo)*s.lines.size())return 3;
 cerr<<"DONE "<<s.cut+s.pass<<' '<<s.tries<<' '<<s.nodes<<' '<<s.pass<<endl;
}
