from pathlib import Path
import subprocess,tempfile,itertools
from exact_after import after
import staged
from completion import cost
here=Path(__file__).resolve().parent
families=['triple-10','shared-8','shared-9','five-9-4','five-9-5','five-10-3','five-10-4','five-11']
by_bank={}
for n in families:
 for r in (here/'reps'/(n+'.reps')).open():
  *b,t=map(int,r.split());assert len(b)==13 and t.bit_count()==3
  by_bank.setdefault(tuple(b),set()).update(t^(1<<i) for i in range(7) if t>>i&1)
assert len(by_bank)==30501 and sum(map(len,by_bank.values()))==262219
with tempfile.TemporaryDirectory()as tmp:
 w=Path(tmp)
 for n,cpp in [('endpoint24','endpoint24.cpp'),('assignments','assignments.cpp'),('stages','stages.cpp'),('price9','price9.cpp')]:
  subprocess.run(['c++','-std=gnu++20','-O3',here/cpp,'-o',w/n],check=True)
 with (w/'unique').open('w')as f:
  for b in sorted(by_bank):print(*b,file=f)
 with (w/'unique').open()as fi,(w/'priced').open('w')as fo:
  subprocess.run([w/'price9',here/'action-price','emit'],stdin=fi,stdout=fo,check=True)
 P=sorted(tuple(map(int,r.split())) for r in (w/'priced').open())
 assert len(P)==7334
 with (w/'points').open('w')as f:
  for b in P:print(0,*b,file=f)
 Es=[e for e in range(128)if e.bit_count()==2]
 with (w/'lines8').open('w')as f:
  for e in Es:print(*(1<<i for i in range(7)),e,file=f)
 with (w/'legal').open('w')as f:
  for i,b in enumerate(P):
   if cost(b)+9>=21:
    for e in by_bank[b]:print(i,Es.index(e),file=f)
 assert sum(1 for _ in (w/'legal').open())==31382
 staged.root=w;staged.raw=here/'rows';staged.run(w,w/'legal')
 print('exact survivors rejected',after(w,w/'endpoint24',here/'rows'))
