from pathlib import Path
from functools import lru_cache
from pysat.card import CardEnc
from pysat.solvers import Solver
from sample import base_info
import sys
D={(l,n):sum(1<<(m-1) for m in range(1,128) if m&1<<l and not m&n) for l in range(7) for n in range(128)}
def bits(x):
 while x:
  b=x&-x;x-=b;yield b.bit_length()
def minimal(f):
 out=[]
 for d in sorted(f,key=int.bit_count):
  if not any(c&d==c for c in out):out.append(d)
 return out
def check(f,budget):
 pp,nn,pv,nv,ps,ns,priv=base_info(f)
 bp=[sum(1<<i for i in range(len(f)) if ps[i+7]>>r&1) for r in range(len(pp))]
 bn=[sum(1<<i for i in range(len(f)) if ns[i+7]>>r&1) for r in range(len(nn))]
 groups={}
 for l,i,j in priv:
  d=D[l,nn[j]>>13];a,b=groups.get(d,(0,0));groups[d]=(a|bp[i],b|bn[j])
 singles=minimal(groups)
 doubles=set()
 for i in range(len(f)):
  a=minimal(d for d,(aa,bb) in groups.items() if aa>>i&1)
  b=minimal(d for d,(aa,bb) in groups.items() if bb>>i&1)
  doubles.update(x|y for x in a for y in b if x&y)
 doubles=minimal(doubles)
 cs=CardEnc.atmost(list(range(1,255)),budget,top_id=254).clauses
 cs.extend([-(i+127),i] for i in range(1,128))
 cs.extend(list(bits(v)) for v in singles)
 for d in doubles:
  occ=list(bits(d))
  cs.append(occ)
  cs.extend([j+127,*[k for k in occ if j!=k]] for j in occ)
 with Solver(name='cadical195',bootstrap_with=cs) as sol:
  if not sol.solve():return None
  return [x for x in sol.get_model() if 0<x<255]
if __name__=='__main__':
 b=Path(sys.argv[1]).read_text().splitlines()
 start,end=map(int,sys.argv[2:4]) if len(sys.argv)>2 else (0,len(b))
 for i in range(start,end):
  ans=check(tuple(map(int,b[i].split())),11)
  print(i,int(ans is not None),flush=True)
