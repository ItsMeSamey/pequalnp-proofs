from pathlib import Path
from tempfile import TemporaryDirectory
import os,subprocess,sys,gzip
from sample import pos,neg
src=Path(__file__).resolve().parent
def run(args,**kw):return subprocess.run(list(map(str,args)),check=True,**kw)
with TemporaryDirectory() as tmp:
 h=Path(tmp);os.environ['M23_WORK']=tmp
 for g,c in ((5,313),(6,1431)):
  data=gzip.decompress((src/f'w13g{g}.gz').read_bytes());assert len(data.splitlines())==c
  (h/f'w13g{g}').write_bytes(data)
 (h/'rows').write_text(' '.join(map(str,[len(pos),len(neg),*sorted(pos),*sorted(neg)])))
 for name in ('ordinaryfast','compare13x11'):run(['g++','-std=c++20','-O3','-march=native',src/(name+'.cpp'),'-o',h/name])
 with (h/'ordnative').open('w') as out:run([h/'ordinaryfast',h/'rows',h/'w13g6',13,4],stdout=out)
 assert (h/'ordnative').read_text().split()==['136','1357']
 run([sys.executable,src/'finishord.py'])
 f=(h/'w13g6').read_text().splitlines()
 for i in (136,1357):
  assert (h/f'ordinary11-{i}').read_text().split()==['35','52','70','104']
  assert sum(int(x).bit_count()==3 for x in f[i].split())>=3
 run([sys.executable,src/'fourtriples.py'])
 run([sys.executable,src/'missing11.py'])
 assert len((h/'missing11').read_text().splitlines())==251460
 result=run([h/'compare13x11',h/'rows',h/'missing11',h/'w13g5'],capture_output=True,text=True)
 print(result.stderr.strip());assert not result.stdout.strip() and result.stderr.strip().endswith('survivors 0')
 print('Width 13/11, mixed size 23, all pure allocations excluded.')
