from pathlib import Path
from pysat.solvers import Solver
import sys
from check import encode
targets=[35,52,70,104]
for gates in [7]:
 c,V,_,_=encode([1<<i for i in range(7)],[],0,gates,selected=0);v=max(abs(z) for cl in c for z in cl)
 for t in targets:
  choices=[]
  for bits in V:
   v+=1;choices.append(v)
   c.extend([[-v,z if t>>i&1 else -z] for i,z in enumerate(bits)])
  c.append(choices)
 with Solver(name='cadical195',bootstrap_with=c) as s:
  ans=s.solve();assert not ans;print(gates,ans,s.accum_stats(),flush=True)
