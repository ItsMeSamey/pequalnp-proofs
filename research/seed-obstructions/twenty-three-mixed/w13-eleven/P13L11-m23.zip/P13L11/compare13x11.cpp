#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <vector>
using namespace std;
using U=uint64_t;using Neg=array<U,4>;using KeyMap=array<Neg,28>;using Mark=array<U,5>;
constexpr int K=28*245;
vector<int> P,N;
array<Neg,8192> avoid{};array<Neg,7> act{};array<vector<pair<int,int>>,13> inc{};
void setup(){
 for(int y=0;y<245;y++){
  for(int m=0;m<8192;m++)if(!(N[y]&m))avoid[m][y/64]|=U(1)<<(y%64);
  for(int j=0;j<7;j++)if((N[y]>>13)&(1<<j))act[j][y/64]|=U(1)<<(y%64);
 }
 for(int a=0;a<28;a++)inc[countr_zero((unsigned)(P[a]&8191))].emplace_back(a,countr_zero((unsigned)(P[a]>>13)));
}
template<int W> bool keymap(const array<Mark,W>& marks,KeyMap& k){
 k={};for(const auto&m:marks){
  for(U pp=m[0];pp;pp&=pp-1){auto& z=k[countr_zero(pp)];
   for(int g=0;g<4;g++){if(z[g]&m[1+g])return false;z[g]|=m[1+g];}
  }
 }
 return true;
}
bool point(const array<int,13>& bank,KeyMap& key){
 array<Mark,13> mark{};
 for(int p=0;p<13;p++){
  int use[13],num=0;Neg many{},any{};
  for(int i=0;i<13;i++)if(bank[i]&(1<<p)){
   use[num++]=i;for(int g=0;g<4;g++){U w=avoid[bank[i]][g];many[g]|=any[g]&w;any[g]|=w;}
  }
  for(int t=0;t<num;t++){
   int i=use[t];for(auto [a,j]:inc[p]){
    U hit=0;for(int g=0;g<4;g++){U unique=avoid[bank[i]][g]&~many[g]&act[j][g];hit|=unique;mark[i][1+g]|=unique;}
    if(hit)mark[i][0]|=U(1)<<a;
   }
  }
 }
 return keymap<13>(mark,key);
}
template<int W> bool nextbank(ifstream& f,array<int,W>& b){if(!(f>>b[0]))return false;for(int i=1;i<W;i++)if(!(f>>b[i]))abort();return true;}
vector<U> banned,initial;vector<int> order;
int count_lines,words;
void line_index(const char* name){
 ifstream file(name);if(!file)abort();array<int,11> b;
 while(nextbank<11>(file,b))count_lines++;words=(count_lines+63)/64;
 banned.resize(size_t(K)*words);initial.assign(words,0);
 map<pair<int,int>,Mark> rel;
 for(int a=0;a<28;a++)for(int n=0;n<245;n++)if(!((P[a]&~N[n])&8191)){auto&m=rel[{P[a]>>13,N[n]>>13}];m[0]|=U(1)<<a;m[1+n/64]|=U(1)<<(n%64);}
 struct Row{int j,k;Mark m;};vector<Row> rr;for(auto&[c,m]:rel)rr.push_back({c.first,c.second,m});
 file.clear();file.seekg(0);int idx=0;
 while(nextbank<11>(file,b)){
  array<int,128> proj{};array<Mark,11> marks{};bool ok=true;
  for(int k=0;k<128;k++)for(int i=0;i<11;i++)proj[k]|=bool(k&b[i])<<i;
  for(auto&r:rr){int d=proj[r.j]&~proj[r.k];if(!d){ok=false;break;}if(has_single_bit((unsigned)d))for(int i=0;i<5;i++)marks[countr_zero((unsigned)d)][i]|=r.m[i];}
  KeyMap keys;if(ok&&keymap<11>(marks,keys)){
   U one=U(1)<<(idx%64);int word=idx/64;initial[word]|=one;
   for(int a=0;a<28;a++)for(int g=0;g<4;g++)for(U x=keys[a][g];x;x&=x-1){
    int n=64*g+countr_zero(x);if(P[a]&N[n]&8191)continue;
    banned[size_t(a*245+n)*words+word]|=one;
   }
  }
  idx++;
 }
 vector<int> weight(K);
 for(int k=0;k<K;k++){auto first=banned.data()+size_t(k)*words;for(int j=0;j<words;j++)weight[k]+=popcount(first[j]);if(weight[k])order.push_back(k);}
 sort(order.begin(),order.end(),[&](int a,int b){return weight[a]!=weight[b]?weight[a]>weight[b]:a<b;});
 cerr<<"line domain "<<count_lines<<" usable keys "<<order.size()<<" strongest "<<weight[order.front()]<<endl;
}
inline bool has(const KeyMap& keys,int k){int a=k/245,n=k%245;return (keys[a][n/64]>>(n%64))&1;}
vector<vector<int>> cores;
uint64_t clash_p=0,learn=0,reuse=0,kept=0,trials=0;
int check(const KeyMap& keys){
 for(int z=cores.size()-1;z>=0;z--){bool subset=true;for(int k:cores[z])if(!has(keys,k)){subset=false;break;}
  if(subset){reuse++;if(z+1<(int)cores.size())swap(cores[z],cores.back());return -1;}
 }
 vector<pair<int,U>> left;left.reserve(words);for(int w=0;w<words;w++)if(initial[w])left.emplace_back(w,initial[w]);
 vector<int> core;
 for(int k:order)if(has(keys,k)){
  auto block=banned.data()+size_t(k)*words;size_t sz=0;bool changed=false;
  for(auto [w,v]:left){U rem=v&~block[w];changed|=rem!=v;if(rem)left[sz++]={w,rem};}
  left.resize(sz);if(changed)core.push_back(k);
  if(left.empty()){
   if(cores.size()>=512)cores.erase(cores.begin());
   cores.push_back(move(core));learn++;return -1;
  }
 }
 return left.empty()?-1:64*left.front().first+countr_zero(left.front().second);
}
int main(int argc,char**v){
 if(argc<4)return 1;ifstream f(v[1]);int pn,nn;f>>pn>>nn;if(pn!=28||nn!=245)abort();P.resize(pn);N.resize(nn);for(int&x:P)f>>x;for(int&x:N)f>>x;
 setup();line_index(v[2]);
 for(int a=3;a<argc;a++){
  ifstream fi(v[a]);if(!fi)abort();array<int,13> b;
  while(nextbank<13>(fi,b)){trials++;KeyMap keys;if(!point(b,keys)){clash_p++;continue;}int id=check(keys);
   if(id>=0){kept++;cout<<id;for(int x:b)cout<<' '<<x;cout<<'\n';}
  }
  cerr<<v[a]<<" cumulative "<<trials<<" point-conflict "<<clash_p<<" new cores "<<learn<<" cache hits "<<reuse<<" survivors "<<kept<<endl;
 }
}
