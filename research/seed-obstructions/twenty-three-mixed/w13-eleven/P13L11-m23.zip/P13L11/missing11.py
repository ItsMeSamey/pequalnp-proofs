from pathlib import Path
from collections import Counter
from itertools import combinations_with_replacement
from pysat.card import CardEnc
from pysat.solvers import Solver
from sample import pos,neg
h=Path(__import__('os').environ['M23_WORK'])
raw={1<<i for i in range(7)}
ob=sorted({(p>>13,n>>13) for p in pos for n in neg if not((p&8191)&~(n&8191))})
clauses=sorted({tuple(x for x in range(1,128) if p&x and not n&x) for p,n in ob},key=len)
ss=[]
for c in clauses:
 if all(not s.issubset(c) for s in ss):ss.append(set(c))
print('minimal disjunctions',len(ss),flush=True)
cs=CardEnc.atmost(list(range(1,128)),11,top_id=127).clauses
with Solver(name='cadical195',bootstrap_with=[*cs,*map(list,ss)]) as sol,(h/'min11').open('w',buffering=1) as log:
 sol.add_clause([-x for x in raw])
 n=0
 while sol.solve():
  chosen={x for x in sol.get_model() if 0<x<=127}
  for x in sorted(chosen):
   if all((chosen-{x})&s for s in ss):chosen.remove(x)
  print(*sorted(chosen),file=log);sol.add_clause([-x for x in chosen]);n+=1
  if n%1000==0:print(n,flush=True)
out=set();hist=Counter()
for line in (h/'min11').read_text().splitlines():
 a=tuple(map(int,line.split()));hist[len(a)]+=1
 for more in combinations_with_replacement(range(128),11-len(a)):
  b=tuple(sorted((*a,*more)))
  if not raw.issubset(b):out.add(b)
print('minimal distributions',hist,'expanded',len(out),flush=True)
(h/'missing11').write_text(''.join(' '.join(map(str,b))+'\n' for b in sorted(out)))
