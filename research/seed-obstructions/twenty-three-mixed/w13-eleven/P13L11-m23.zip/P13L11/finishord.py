from pathlib import Path
from itertools import combinations_with_replacement
from pysat.card import CardEnc
from pysat.solvers import Solver
from sample import base_info
from multicover import bits,D,minimal
h=Path(__import__('os').environ['M23_WORK'])
def lines(f):
 pp,nn,pv,nv,ps,ns,priv=base_info(f)
 clauses=set()
 for l in range(7):
  ww=[(i,j,D[l,nn[j]>>13]) for x,i,j in priv if l==x]
  for t in range(7,7+len(f)):
   a=minimal({d for i,j,d in ww if ps[t]>>i&1});o=minimal({d for i,j,d in ww if ns[t]>>j&1})
   clauses.update(x|y for x in a for y in o)
 ds=[set(bits(c)) for c in minimal(clauses)]
 cs=CardEnc.atmost(list(range(1,128)),4,top_id=127).clauses
 out=set()
 with Solver(name='cadical195',bootstrap_with=[*cs,*map(list,ds)]) as sol:
  while sol.solve():
   ch={x for x in sol.get_model() if 0<x<128}
   for x in sorted(ch):
    if all((ch-{x})&d for d in ds):ch.remove(x)
   for xs in combinations_with_replacement(range(128),4-len(ch)):out.add(tuple(sorted([*ch,*xs])))
   sol.add_clause([-x for x in ch])
 return out
def screen(f,l):
 pp,nn,*_=base_info(f)
 bank=[*f,*[x<<13 for x in l]]
 def code(row):return sum(bool(row&m)<<i for i,m in enumerate(bank))
 a=list(map(code,pp));b=list(map(code,nn));sa=[0]*len(a);sb=[0]*len(b)
 for i,x in enumerate(a):
  for j,y in enumerate(b):
   d=x&~y
   if not d:return False
   if d.bit_count()==1:sa[i]|=d;sb[j]|=d
 for x in sa:
  if any((x&y).bit_count()>=2 for y in sb):return False
 return True
if __name__=='__main__':
 fbank=(h/'w13g6').read_text().splitlines()
 for i in map(int,(h/'ordnative').read_text().split()):
  f=tuple(map(int,fbank[i].split()));ll=lines(f);good=[l for l in ll if screen(f,[*[1<<j for j in range(7)],*l])]
  print('point',i,'placements',len(ll),'surviving',len(good),good[:3],flush=True)
  (h/f'ordinary11-{i}').write_text(''.join(' '.join(map(str,l))+'\n' for l in good))
