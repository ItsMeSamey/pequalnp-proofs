#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
using U=unsigned __int128;
using R=pair<int,int>;
int w=13,e=4;vector<int> pos,neg;
vector<U> keep(vector<U> v){
 sort(v.begin(),v.end());v.erase(unique(v.begin(),v.end()),v.end());
 auto wt=[](U x){return popcount((uint64_t)x)+popcount((uint64_t)(x>>64));};
 sort(v.begin(),v.end(),[&](U a,U b){return wt(a)<wt(b);});
 vector<U> out;for(U x:v){bool redundant=false;for(U y:out)if(!(y&~x)){redundant=true;break;}if(!redundant)out.push_back(x);}return out;
}
bool hit(const vector<U>& clauses,int k,U used=0){
 U pick=0,blocked=0;int lb=0;
 for(U x:clauses)if(!(used&x)){
  if(!pick)pick=x;
  if(!(blocked&x)){blocked|=x;if(++lb>k)return false;}
 }
 if(!pick)return true;
 if(k<=0)return false;
 for(U q=pick;q;q&=q-1)if(hit(clauses,k-1,used|(q&-q)))return true;
 return false;
}
bool test(const vector<int>&f){
 vector<int> pp,nn;auto proj=[&](int row){int v=row>>13;for(int i=0;i<w;i++)v|=int(bool(f[i]&(row&8191)))<<(7+i);return v;};
 for(int a:pos)pp.push_back(proj(a));for(int b:neg)nn.push_back(proj(b));
 vector<unsigned> pm(pos.size()),nm(neg.size());array<vector<R>,7> groups;
 for(int i=0;i<28;i++)for(int j=0;j<245;j++){unsigned d=pp[i]&~nn[j];if(!has_single_bit(d))continue;int z=countr_zero(d);
 if(z>=7){pm[i]|=d;nm[j]|=d;}else groups[z].push_back({i,j});}
 vector<U> clauses;for(int j=0;j<7;j++){
 array<U,128> options{};for(int n=0;n<128;n++)for(int x=1;x<128;x++)if((x>>j&1)&&!(x&n))options[n]|=(U)1<<x;
 for(int t=7;t<7+w;t++){set<int>a,o;for(auto [i,h]:groups[j]){if(pm[i]>>t&1)a.insert(neg[h]>>13);if(nm[h]>>t&1)o.insert(neg[h]>>13);}
 for(int x:a)for(int y:o)clauses.push_back(options[x]|options[y]);}
 }return hit(keep(move(clauses)),e);
}
int main(int argc,char**argv){ifstream rows(argv[1]),banks(argv[2]);w=stoi(argv[3]);e=stoi(argv[4]);int a,b;rows>>a>>b;pos.resize(a);neg.resize(b);for(int&x:pos)rows>>x;for(int&x:neg)rows>>x;int i=0,k=0;
 for(vector<int> f(w);banks>>f[0];i++){for(int h=1;h<w;h++)banks>>f[h];if(test(f)){cout<<i<<'\n';k++;}}cerr<<i<<" ordinary models "<<k<<'\n';}
