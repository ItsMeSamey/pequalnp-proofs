from argparse import ArgumentParser
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys
here=Path(__file__).resolve().parent
cli=ArgumentParser()
cli.add_argument('w12',type=Path,help='directory extracted from w12-l8-m23.zip')
cli.add_argument('--placement-only',action='store_true')
args=cli.parse_args();base=args.w12.resolve();sys.path.insert(0,str(base))
from sample import move,symmetries,raw
from verify import rows
bank=rows(base/'point-subset');bi={p:i for i,p in enumerate(bank)}
parents=rows(here/'embed.in');head=parents.pop(0)
assert len(parents)==32
samples=tuple(map(int,(base/'samples').read_text().split()))
assert head[0:2]==samples[0:2] and set(head[2:30])==set(samples[2:30]) and set(head[30:275])==set(samples[30:]) and head[-1]==32
targets=list(map(int,(here/'outstanding.idx').read_text().split()))
keys=rows(here/'dup1-individual.idx')
assert set(keys)=={(i,j)for i in targets for j in range(11)} and len(keys)==154
g=symmetries();work=[]
for i,j in keys:
    parent=parents[i];point=parent[:11]
    assert tuple(parent[11:18])==raw and parent[-1].bit_count()==2
    w=(*point,point[j]);p,e=min((tuple(sorted(move(x,t) for x in w)),u[parent[-1]])for t,u in g)
    work.append((bi[p],e))
with TemporaryDirectory() as td:
    tmp=Path(td)
    def build(name):
        target=tmp/name
        subprocess.run(['g++','-std=c++20','-O3',str(base/(name+'.cpp')),'-o',str(target)],check=True)
        return target
    with (base/'point-subset').open() as src:
        out=subprocess.run([build('cohort'),base/'samples','1','0','765'],stdin=src,stdout=subprocess.PIPE,text=True,check=True)
    keep={tuple(map(int,line.split()))for line in out.stdout.splitlines()}
    placed=[w for w in work if w in keep];unique=sorted(set(placed))
    assert len(placed)==53
    print('154 daughters,',len(placed),'pass placement,',len(unique),'distinct exact checks',flush=True)
    if not args.placement_only:
        inp=''.join(f'{i} {e}\n' for i,e in unique)
        projected=subprocess.run([build('project'),base/'samples',base/'point-subset'],input=inp,text=True,stdout=subprocess.PIPE,check=True)
        answer=subprocess.run([build('filtered-fast'),'12','8','4'],input=projected.stdout,text=True,stdout=subprocess.PIPE,check=True)
        lines=answer.stdout.splitlines();assert len(lines)==len(unique)
        for key,line in zip(unique,lines):
            if int(line.split()[0]):print('survivor',key)
        print('Surviving daughters',sum(dict(zip(unique,[int(l.split()[0]) for l in lines]))[w] for w in placed))
