# A point-boundary repeat on fourteen eleven-point banks at 23 mixed gates

The fourteen bank indices in outstanding.idx specify eleven point boundaries, seven raw line labels and one union of two line labels. If a particular point boundary is used at least twice in the mixed cone, assign one occurrence to a new formal slot with the identical point function. The mixed gate count stays 23 and the number of surplus reads falls from five to four. The new slot is free because it uses the same physical input. All eleven possible slots are tested for each original bank.

The 154 formal daughters reduce under the raw sample symmetries to the canonical point and line tables from w12-l8-m23.zip. The ordinary-private placement theorem is valid for repeated point signatures. It removes 101 daughters. The other 53 have 44 distinct normalized configurations. Recheck these with the four-surplus mixed kernel, granting arbitrary point-slot duplication without applying the physical twelve-wire point-price reduction. The source incidence table, bank selection and point slots are included. No exclusion of a repeat on a mixed gate or a line boundary follows from this test.

Extract w12-l8-m23.zip to a directory, and run `python verify.py /path/to/extracted`. The optional `--placement-only` switch verifies the reduction to 44 without running the recursive endpoint enumeration.

All 44 unrestricted four-surplus checks returned zero. Therefore none of the 154 daughters admits a separator, and none of these fourteen parent banks can repeat any pure point boundary.
