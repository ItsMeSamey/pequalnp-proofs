from pathlib import Path
from itertools import combinations
from inputs import P,N,stars
from samples import actions
r=Path(__file__).resolve().parent
rows=(r/'all-clean.in').read_text().splitlines()
np,nn,*raw=map(int,rows[0].split())
assert np==28 and nn==245 and set(raw[:np])==P and set(raw[np:])==N
assert list(map(int,rows[1].split()))==[32,11,8,5]
G=actions(P,N);perms=[[stars.index(f[t])for t in stars]for f in G]
def key(b,e):
 return min((tuple(sorted(f[v]for v in b)),sum(1<<perm[j]for j in range(7)if e>>j&1))for f,perm in zip(G,perms))
basis=[list(map(int,s.split()))for s in (r/'cost-nine-width-eleven.txt').read_text().splitlines()]
expected={key(b,(1<<i)|(1<<j))for b in basis for i,j in combinations(range(7),2)}
got=set()
for s in rows[2:]:
 v=list(map(int,s.split()));assert v[11:18]==[1<<j for j in range(7)] and v[18].bit_count()==2 and v[20:]==[0]*22
 got.add(key(v[:11],v[18]))
assert len(basis)==27 and len(expected)==len(got)==32 and got==expected
original=list(map(int,rows[25].split()))[:19];assert original[18]==66 and original[13]==4
for excess in range(1,6):
 pw,lw,k=11,8+excess,5-excess
 stem=f'{pw}_{lw}_{k}'
 parts=(r/'repeat'/(stem+'.in')).read_text().splitlines()
 assert parts[:2]==[rows[0],f'1 {pw} {lw} {k}']
 extended=list(map(int,parts[2].split()))
 assert extended[:19]==original and extended[19:19+excess]==[original[13]]*excess and extended[20+excess:]==[0]*22
print('27 point banks times 21 line pairs yield all 32 orbits and five exact multiplicities')
