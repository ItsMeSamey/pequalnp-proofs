#!/bin/sh
set -eu
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
c++ -O2 -std=c++20 anycut.cpp -o "$out/anycut"
"$out/anycut" all-clean.in all.idx 10000 > "$out/log"
cat "$out/log"
python - "$out/log" <<'PY'
import sys
rows=[line.split() for line in open(sys.argv[1])]
assert len(rows)==32 and [int(a[0]) for a in rows]==list(range(32))
assert all(a[1:3]==['DONE','0'] and int(a[3])<=10000 for a in rows)
PY
python check-inputs.py
for f in repeat/11_*.in; do
  label=${f%.in}
  "$out/anycut" "$f" "$label.idx" 150000 > "$out/one"
  cmp "$out/one" "$label.log"
  cat "$out/one"
done
