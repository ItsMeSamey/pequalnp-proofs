#include "anycut.hpp"
using namespace std;
int main(int argc,char**argv){
 if(argc<4)return 1;ifstream f(argv[1]),ids(argv[2]);int np,nn;f>>np>>nn;vector<int>rows(np+nn);for(auto&v:rows)f>>v;int count,pw,lw,k;f>>count>>pw>>lw>>k;
 for(int row=0;row<count;row++){int id;ids>>id;vector<int>b(pw+lw);for(auto&v:b)f>>v;for(int i=pw;i<pw+lw;i++)b[i]<<=13;int copy;f>>copy;frontierlib::Search s;for(auto&ban:s.banned)for(auto&v:ban)f>>v;if(argc>4&&id!=stoi(argv[4]))continue;
  vector<int>P,N,V;for(int i=0;i<np+nn;i++){int x=0;for(int j=0;j<pw+lw;j++)if(b[j]&rows[i])x|=1<<j;(i<np?P:N).push_back(x);}
  sort(P.begin(),P.end());P.erase(unique(P.begin(),P.end()),P.end());sort(N.begin(),N.end(),[](int x,int y){return __builtin_popcount(x)>__builtin_popcount(y);});for(int v:N)if(none_of(V.begin(),V.end(),[&](int w){return !(v&~w);}))V.push_back(v);
  vector<int>type(pw+lw);fill_n(type.begin(),pw,1);s.stage.assign(pw+lw,-1);for(int j=0;j<pw+lw;j++)s.origin.push_back(j);
  s.nodes=0;s.limit=stoll(argv[3]);for(auto&cache:frontierlib::failed)cache.clear();
  try{bool yes=s.treecut(P,V,pw+lw,k,type);cout<<id<<" DONE "<<yes<<" "<<s.nodes<<endl;}catch(int){cout<<id<<" LIMIT "<<s.nodes<<endl;}
 }
}
