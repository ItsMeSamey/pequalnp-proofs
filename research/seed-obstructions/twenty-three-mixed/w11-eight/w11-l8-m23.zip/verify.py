"""Verify all 32 genuine m23 width-eleven/eight-line representatives."""
from collections import Counter
from itertools import combinations_with_replacement,permutations
from pathlib import Path
import subprocess,tempfile,sys
from input import raw_samples
here=Path(__file__).resolve().parent
pos,neg,_=raw_samples(here/'L-meta-18968.json')
raw=tuple(1<<i for i in range(7))
stars=[sum({r&8191 for r in pos if r&(x<<13)}) for x in raw]
inc=tuple(sum(1<<j for j,x in enumerate(stars) if x>>i&1) for i in range(13))
def move(x,perm):
    return sum(1<<j for i,j in enumerate(perm) if x>>i&1)
group=[]
for perm in permutations(range(7)):
    image=tuple(move(x,perm) for x in inc)
    if set(image)!=set(inc):continue
    pp=tuple(inc.index(x) for x in image)
    lm=tuple(move(x,perm) for x in range(128))
    def pair(r):return move(r&8191,pp)|(lm[r>>13]<<13)
    if all({pair(r) for r in rs}==rs for rs in (pos,neg)):
        group.append((pp,lm))
assert len(group)==24
points=[tuple(map(int,r.split())) for r in (here/'cost-nine-width-eleven.txt').read_text().splitlines()]
assert len(set(points))==27
def load(path):
    return {tuple(map(int,r.split())) for r in path.read_text().splitlines()}
allpoints=load(here/'cost-ten-star-local.txt')
low=set(points)
assert len(low)==27 and low<=allpoints and len(allpoints)==354
def domain(banks,maxsize):
    reps=Counter()
    for p in banks:
        images=[(tuple(sorted(move(x,pp) for x in p)),lm) for pp,lm in group]
        best=min(q for q,lm in images)
        actions=[lm for q,lm in images if q==best]
        for x in range(128):
            if not 2<=x.bit_count()<=maxsize:continue
            reps[best,min(lm[x] for lm in actions)]+=1
    return reps
def minimal(rows):
 rows=sorted(set(rows),key=int.bit_count);out=[]
 for x in rows:
  if not any(not a&~x for a in out):out.append(x)
 return out
def kill_table(ps,ns,K,O):
 width=K.bit_count(); Z=((1<<19)-1)^K^O
 assert K&O==0
 pp=minimal(x&K for x in ps if not x&Z)
 nn=sorted({x&K for x in ns if not O&~x})
 nn=[n for n in nn if not any(n!=u and not n&~u for u in nn)]
 dif={p&~n for p in pp for n in nn}
 assert 0 not in dif and all(1<<j in dif for j in range(19) if K>>j&1)
 inds=[j for j in range(19) if K>>j&1]
 def compact(x):return sum(((x>>j)&1)<<i for i,j in enumerate(inds))
 rows=[*pp,*nn];pm=(1<<len(pp))-1;nm=((1<<len(rows))-1)^pm
 codes=[sum(((x|O)>>i&1)<<j for j,x in enumerate(rows)) for i in range(19)]
 forbidden=set()
 for q in range(11):
  for l in range(11,19):
   pair=(1<<q)|(1<<l)
   if not K&pair:continue
   for op in [0,1]:
    h=codes[q]|codes[l] if op else codes[q]&codes[l]
    substitutes=codes+[0,pm|nm] if (pair&K)==pair else [codes[q if not K>>q&1 else l]]
    if any(not h&pm&~z and not z&nm&~h for z in substitutes):forbidden.add((q,l,op))
 return forbidden,[width,5,len(pp),len(nn),*sorted(map(compact,pp)),*sorted(map(compact,nn))]

subprocess.run([sys.executable,str(here/'or_prices.py')],check=True)
def read(name):return [list(map(int,r.split()))for r in (here/name).read_text().splitlines()]
counts=domain(low,2);assert sum(counts.values())==567
rows=sorted(counts)
hard={i:(k,o)for i,k,o in read('hard.txt')}
guards=read('guards.txt');seeds=read('template4.in')
assert len(rows)==32 and len(hard)==16 and len(seeds)==17
tmp=tempfile.TemporaryDirectory()
def build(stem):
 out=Path(tmp.name)/stem
 subprocess.run(['c++','-O3','-std=c++17',str(here/(stem+'.cpp')),'-o',str(out)],check=True)
 return out
minor=build('minor')
def check(width,k,ps,ns):
 d={x&~y for x in ps for y in ns}
 assert 0 not in d and all(1<<i in d for i in range(width))
 tx=' '.join(map(str,[width,k,len(ps),len(ns),*ps,*ns]))+'\n'
 ret=subprocess.run([str(minor)],input=tx,text=True,capture_output=True,check=True)
 gate,out=map(int,ret.stdout.split());assert out==0
 return gate
def clip(ps,ns,coords,ones):
 mask=sum(1<<j for j in coords);assert len(set(coords))==len(coords) and not mask&ones
 zeros=524287^mask^ones
 def comp(x):return sum((x>>j&1)<<t for t,j in enumerate(coords))
 pp=minimal(comp(x)for x in ps if not x&zeros);nn=sorted({comp(x)for x in ns if not ones&~x})
 return pp,[x for x in nn if not any(x!=v and not x&~v for v in nn)]
for pc,nc,*v in seeds:
 assert len(v)==pc+nc
 check(10,4,v[:pc],v[pc:])
payload=[]
line_tasks=[]
for i,(point,e) in enumerate(rows):
 bank=(*point,*raw,e);m=[v if j<11 else v<<13 for j,v in enumerate(bank)]
 def val(x):return sum(bool(x&v)<<j for j,v in enumerate(m))
 ps=set(map(val,pos));ns=set(map(val,neg))
 if i==23:
  for l in range(11,19):
   if l==13:continue
   def aug(x):return x|((x>>l&1)<<19)
   pp=minimal(aug(x)for x in ps);ns0=set(aug(x)for x in ns)
   nn=sorted(x for x in ns0 if not any(x!=y and not x&~y for y in ns0))
   line_tasks.append(' '.join(map(str,[len(pp),len(nn),*pp,*nn])))
  if '--all-native' not in sys.argv:continue
 if i in hard:
  keep,o=hard[i];coords=[j for j in range(19)if keep>>j&1];pp,nn=clip(ps,ns,coords,o)
  print('minor',i,check(len(coords),5,pp,nn),flush=True);continue
 copies=524287;forbid=set()
 for cid,t,o,*coords in guards:
  if cid!=i:continue
  assert len(coords)==10
  pp,nn=clip(ps,ns,coords,o);pc,nc,*v=seeds[t]
  assert all(any(not x&~y for x in pp)for y in v[:pc])
  assert all(any(not y&~x for x in nn)for y in v[pc:])
  keep=sum(1<<j for j in coords);copies&=keep
  cut,_=kill_table(ps,ns,keep,o);forbid.update(cut)
 rates=[sum(1<<(l-11)for l in range(11,19)if(q,l,op)in forbid)for q in range(11)for op in range(2)]
 payload.append(' '.join(map(str,(*bank,copies,*rates))))
assert len(payload)==15+('--all-native' in sys.argv)
if '--minors' not in sys.argv:
 line_exe=Path(tmp.name)/'lines'
 subprocess.run(['c++','-O2','-std=c++20',str(here/'filtered-fast.cpp'),'-o',str(line_exe)],check=True)
 result=subprocess.run([str(line_exe),'11','9','4'],input='\n'.join(line_tasks)+'\n',capture_output=True,text=True,check=True)
 assert len(result.stdout.splitlines())==7 and all(x.startswith('0 ')for x in result.stdout.splitlines())
 print('All seven required extra raw-line placements for orbit 23 were rejected.',flush=True)
if '--minors' not in sys.argv:
 subprocess.run([str(build('frontier'))],input=' '.join(map(str,[len(pos),len(neg),*sorted(pos),*sorted(neg)]))+'\n'+f'{len(payload)} 11 8 5\n'+'\n'.join(payload)+'\n',text=True,check=True)
