"""Calculate actual OR implementations of the 354 affordable star-local banks."""
from functools import lru_cache
from itertools import combinations
from collections import Counter
from pathlib import Path
stars=[708,1416,2832,5664,3137,6274,4357]
raw={1<<i for i in range(13)}
for i in range(6):
 first=(1<<i)|(1<<(i+1));second=(1<<((i+3)%13))|(1<<((i+9)%13))
 raw.update([first,second,first|second])
# Compress each host to the same four-coordinate problem.
pairs=[v for v in range(1,16) if v.bit_count()>=2]
states={0};queue=[0]
while queue:
 st=queue.pop();avail=[1,2,4,8]+[m for i,m in enumerate(pairs) if st>>i&1]
 for a,b in combinations(avail,2):
  m=a|b
  if m not in pairs:continue
  nx=st|1<<pairs.index(m)
  if nx not in states:states.add(nx);queue.append(nx)
@lru_cache(None)
def price(required):
 return min(s.bit_count() for s in states if not required&~s)
def group_price(bank,t):
 pos=[i for i in range(13) if t>>i&1]
 masks=[sum(bool(v&(1<<j))<<i for i,j in enumerate(pos)) for v in bank if not v&~t]
 return price(sum(1<<pairs.index(m) for m in masks))
p=Path(__file__).resolve().parent/'cost-ten-star-local.txt'
counts=Counter()
exact_nine=set()
for line in p.read_text().splitlines():
 bank=set(map(int,line.split()))-raw
 g=sum(group_price(bank,t) for t in stars);counts[g]+=1
 if g==9:exact_nine.add(tuple(map(int,line.split())))
assert counts=={9:27,10:327}
print(counts)

assert exact_nine=={tuple(map(int,r.split()))for r in p.with_name('cost-nine-width-eleven.txt').read_text().splitlines()}
