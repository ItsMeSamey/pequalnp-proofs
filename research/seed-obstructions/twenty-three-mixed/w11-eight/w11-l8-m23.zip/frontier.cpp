#include "triple.hpp"
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using namespace std;
using Bits=uint64_t;
using Signature=array<Bits,6>; // positives, up to 245 negatives, ancestry side
using Family=array<int,11>;
using Frontier=array<int,24>; // zero entries are padding
template<class T> struct ArrayHash {
    size_t operator()(const T& values)const{
        size_t h=0x9e3779b97f4a7c15ULL;
        for(auto v:values){h^=v+0x9e3779b97f4a7c15ULL+(h<<6)+(h>>2);}
        return h;
    }
};
using States=unordered_set<Frontier,ArrayHash<Frontier>>;
struct Wire{
    Signature value;
};
static bool colorable(const array<int,24>&adj,int size,int colors){
    // Peel vertices of degree < colors: they always extend a coloring.
    unsigned live=(1u<<size)-1;
    for(bool changed=true;changed;){
        changed=false;
        for(unsigned a=live;a;a&=a-1){
            int v=__builtin_ctz(a);
            if(__builtin_popcount(live&adj[v])<colors){live^=1u<<v;changed=true;}
        }
    }
    if(!live)return true;
    array<unsigned,24> color{};
    auto solve=[&](auto&&rec,unsigned left,unsigned used)->bool{
        if(!left)return true;
        int best=-1,score=-1;unsigned banned=0;
        for(unsigned a=left;a;a&=a-1){
            int v=__builtin_ctz(a);unsigned taken=0;
            for(unsigned b=adj[v]&live&~left;b;b&=b-1)taken|=color[__builtin_ctz(b)];
            int priority=32*__builtin_popcount(taken)+__builtin_popcount(adj[v]&left);
            if(priority>score){score=priority;best=v;banned=taken;}
        }
        unsigned allowed=((1u<<colors)-1)&~banned;
        for(unsigned options=allowed;options;options&=options-1){
            unsigned c=options&-options;color[best]=c;
            if(rec(rec,left^(1u<<best),used|c))return true;
            if(!(c&used))break;
        }
        return false;
    };
    return solve(solve,live,0);
}
struct Search{
    int count_pos, count_neg, blocks;int repeatmask;int banned[11][2]{};unordered_set<int> unshared;unordered_set<unsigned long long> banjoin;
    vector<Wire> wires{{}};
    unordered_map<Signature,int,ArrayHash<Signature>> ids;
    unordered_map<uint64_t,int> joins;
    unordered_set<int> pure_replacements;
    vector<Signature> raw_bounds;
    unordered_map<int,bool> tested;
    unordered_map<Bits,vector<int>> candidates;
    bool dominated(int h) {
        if (pure_replacements.count(h))return true;
        auto [it,fresh]=tested.emplace(h,false);
        if(!fresh)return it->second;
        const Signature &g=wires[h].value;
        auto [cand,new_pos]=candidates.try_emplace(g[0]);
        if(new_pos){
            for(int i=0;i<(int)raw_bounds.size();i++)if(!(g[0]&~raw_bounds[i][0]))cand->second.push_back(i);
        }
        for(int i:cand->second){
            const Signature &r=raw_bounds[i];
            bool ok=true;
            for(int b=1;b<=blocks;b++)if(r[b]&~g[b]){ok=false;break;}
            if(ok)return it->second=true;
        }
        return false;
    }

    int intern(Signature sig){
        auto [entry,created]=ids.emplace(sig,wires.size());
        if(!created)return entry->second;
        wires.push_back({sig});
        return entry->second;
    }
    int combine(int a,int b,int op){
        auto key=(uint64_t(a)<<33)|(uint64_t(b)<<1)|op;
        auto it=joins.find(key);
        if(it!=joins.end())return it->second;
        Signature s{};
        for(int k=0;k<=blocks;k++)s[k]=op? wires[a].value[k]|wires[b].value[k] : wires[a].value[k]&wires[b].value[k];
        s[5]=2;
        return joins[key]=intern(s);
    }
    array<Signature,24> forced(const Frontier& state,int size){
        array<Signature,24> need{};
        array<array<unsigned char,24>,32> active{};
        array<unsigned char,32> counts{};
        array<const Signature*,24> values{};
        for(int i=0;i<size;i++){
            values[i]=&wires[state[i]].value;
            for(unsigned rows=(*values[i])[0];rows;rows&=rows-1){
                int p=__builtin_ctz(rows);
                active[p][counts[p]++]=i;
            }
        }
        for(int p=0;p<count_pos;p++)for(int b=0;b<blocks;b++){
            Bits once=0,twice=0;
            for(int j=0;j<counts[p];j++){
                int i=active[p][j];Bits d=~(*values[i])[b+1];
                twice|=once&d;once|=d;
            }
            Bits valid=(b+1<blocks||count_neg%64==0)?~Bits(0):((Bits(1)<<(count_neg%64))-1);
            Bits single=once&~twice&valid;
            if(!single)continue;
            for(int j=0;j<counts[p];j++){
                int i=active[p][j];Bits x=single&~(*values[i])[b+1];
                if(x){need[i][0]|=Bits(1)<<p;need[i][1+b]|=x;}
            }
        }
        return need;
    }
    bool may_read_once(const Frontier&state,int size){
        // Only obligations uniquely distinguished by one consumed wire can be
        // lost, because either operation preserves an obligation distinguished
        // by both operands. Store the two projections of these private pairs.
        auto need=forced(state,size);
        for(int i=0;i<size;i++)for(int j=i+1;j<size;j++){
            if(!(need[i][0]&need[j][0]))continue;
            for(int b=1;b<=blocks;b++)if(need[i][b]&need[j][b])return false;
        }
        return true;
    }
    bool directed_cut(const Frontier&state,int size,const array<int,24>&adj){
        using U=uint32_t; using Neg=array<uint64_t,4>;
        U all=(1u<<size)-1,point=0,line=0;
        array<U,64> pos{};array<Neg,24> truth{};
        for(int i=0;i<size;i++){auto&v=wires[state[i]].value;
            for(Bits q=v[0];q;q&=q-1)pos[__builtin_ctzll(q)]|=1u<<i;
            for(int k=0;k<blocks;k++)truth[i][k]=v[k+1];
            if(v[5]==1)point|=1u<<i;else if(v[5]==0)line|=1u<<i;
        }
        array<array<Neg,16>,6> lut{};int groups=(size+3)/4;
        for(int g=0;g<groups;g++){
            for(int b=0;b<blocks;b++)lut[g][0][b]=(b+1<blocks||count_neg%64==0)?~Bits(0):(Bits(1)<<(count_neg%64))-1;
            for(int t=1;t<(1<<min(4,size-4*g));t++)
                for(int b=0;b<blocks;b++)lut[g][t][b]=lut[g][t&(t-1)][b]&truth[4*g+__builtin_ctz(t)][b];
        }
        auto zero=[&](U mask){Neg r=lut[0][mask&15];for(int g=1;g<groups;g++){auto&a=lut[g][(mask>>(4*g))&15];for(int b=0;b<blocks;b++)r[b]&=a[b];}return r;};
        auto partial=[&](U one,U other){
            Bits forced=0;Neg neg{};
            for(int x=0;x<count_pos;x++){auto v=zero(pos[x]&(all^one));Bits any=0;for(int b=0;b<blocks;b++){neg[b]|=v[b];any|=v[b];}if(any)forced|=Bits(1)<<x;}
            for(Bits q=forced;q;q&=q-1){auto v=zero(pos[__builtin_ctzll(q)]&(all^other));for(int b=0;b<blocks;b++)if(v[b]&neg[b])return false;}
            return true;
        };
        array<pair<U,U>,24> comps{};int n=0;U live=all;
        while(live){U a=live&-live,b=0,front=a;bool rev=false;
            while(front){U next=0;for(U z=front;z;z&=z-1)next|=adj[__builtin_ctz(z)];if(next&(rev?b:a))return false;next&=~(a|b);if(rev)a|=next;else b|=next;front=next;rev=!rev;}
            comps[n++]={a,b};live&=~(a|b);
        }
        // In the absence of any conflicting pair this necessary test can be skipped.
        if(n==size)return true;
        sort(comps.begin(),comps.begin()+n,[](auto a,auto b){return __builtin_popcount(a.first|a.second)>__builtin_popcount(b.first|b.second);});
        auto rec=[&](auto&self,int i,U one,U other)->bool{
            if(i==n && (!one||((one&(one-1))&&((one&point)==one||(one&line)==one))))return false;
            if(i&&!partial(one,other))return false;if(i==n)return true;
            auto [a,b]=comps[i];return self(self,i+1,one|a,other|b)||self(self,i+1,one|b,other|a);
        };
        return rec(rec,0,0,0);
    }
    bool two_cut_state(const Frontier &state,int size){
        vector<int> p(count_pos),n(count_neg),side(size);
        for(int i=0;i<size;i++){
            const auto &v=wires[state[i]].value;side[i]=v[5];
            for(Bits z=v[0];z;z&=z-1)p[__builtin_ctzll(z)]|=1<<i;
            for(int k=1;k<=blocks;k++)for(Bits z=v[k];z;z&=z-1)n[64*(k-1)+__builtin_ctzll(z)]|=1<<i;
        }
        frontierlib::Search test;return test.treecut(p,n,size,2,side);
    }
    void next(const Frontier&state,int size,States&ordinary,States*copied,States*doublecopy,int remaining){
        // Only obligations uniquely distinguished by one consumed wire can be
        // lost, because either operation preserves an obligation distinguished
        // by both operands. Store the two projections of these private pairs.
        auto need=forced(state,size);
        // Once no further use can be retained the remainder is read-once.
        // On each positive a private obligation forces its wire into every
        // accepting minterm; on each negative it lies in every rejecting
        // maxterm. A read-once minterm and maxterm intersect once.
        array<int,24> adj{},degree{};int edges=0;
        for(int i=0;i<size;i++)for(int j=i+1;j<size;j++){
            if(!(need[i][0]&need[j][0]))continue;
            bool conflict=false;
            for(int b=1;b<=blocks;b++)if(need[i][b]&need[j][b]){conflict=true;break;}
            if(conflict){adj[i]|=1u<<j;adj[j]|=1u<<i;degree[i]++;degree[j]++;edges++;}
        }
        if(edges&&!colorable(adj,size,remaining+1))return;
        if(remaining==2&&edges>=7&&size<=20&&!two_cut_state(state,size))return;
        if(remaining==1&&edges>=3&&!directed_cut(state,size,adj))return;
        for(int i=0;i<size;i++)for(int j=i+1;j<size;j++){
            int a=state[i],b=state[j];
            auto av=wires[a].value,bv=wires[b].value;
            if(av[5]==bv[5]&&av[5]!=2)continue;
            for(int op=0;op<2;op++){
                // Both operands distinguish every obligation in need[i][j];
                // either AND or OR still distinguishes those obligations.
                // At need[i], a already separates; b must take the right
                // value at the positive (AND) or the negative (OR).
                bool unsafeA=false,unsafeB=false;
                if(!op){
                    unsafeA=need[i][0]&~bv[0];
                    unsafeB=need[j][0]&~av[0];
                }else{
                    for(int k=1;k<=blocks;k++){
                        unsafeA|=bool(need[i][k]&bv[k]);
                        unsafeB|=bool(need[j][k]&av[k]);
                    }
                }
                // Both parents must lose a negative in an AND, or gain
                // a positive in an OR. Otherwise that parent dominates.
                if(op){
                    if(!(av[0]&~bv[0])||!(bv[0]&~av[0]))continue;
                }else{
                    Bits a_only=0,b_only=0;
                    for(int k=1;k<=blocks;k++){a_only|=av[k]&~bv[k];b_only|=bv[k]&~av[k];}
                    if(!a_only||!b_only)continue;
                }
                if(!doublecopy&&(unsafeA||unsafeB)&&(!copied||(unsafeA&&unsafeB)))continue;
                if(banjoin.count((uint64_t(a)<<33)|(uint64_t(b)<<1)|op))continue;
                int h=combine(a,b,op);
                if(dominated(h)||binary_search(state.begin(),state.begin()+size,h))continue;
                auto push=[&](States& out,int keep){
                    Frontier n{};int t=0;
                    for(int k=0;k<size;k++)if((k!=i&&k!=j)||k==keep||keep==-2)n[t++]=state[k];
                    n[t++]=h;sort(n.begin(),n.begin()+t);out.insert(n);
                };
                if(!unsafeA&&!unsafeB)push(ordinary,-1);
                if(copied&&!unshared.count(a)&&!unsafeB&&(remaining!=1||degree[i]==edges))push(*copied,i);
                if(copied&&!unshared.count(b)&&!unsafeA&&(remaining!=1||degree[j]==edges))push(*copied,j);
                if(doublecopy&&!unshared.count(a)&&!unshared.count(b)&&(remaining!=2||degree[i]+degree[j]-((adj[i]>>j)&1)==edges))push(*doublecopy,-2);
            }
        }
    }
    pair<int,int> run(const vector<int>&ps,const vector<int>&ns,int nleaves,int budget){
        count_pos=ps.size();count_neg=ns.size();blocks=(count_neg+63)/64;
        assert(count_pos<=32&&blocks<=4);
        Frontier orig{};
        for(int i=0;i<nleaves;i++){
            Signature v{};
            for(int j=0;j<count_pos;j++)if(ps[j]>>i&1)v[0]|=Bits(1)<<j;
            for(int j=0;j<count_neg;j++)if(ns[j]>>i&1)v[1+j/64]|=Bits(1)<<(j%64);
            v[5]=i>=7&&i<18;
            orig[i]=intern(v);
        }
        auto wire=[&](int j){return orig[j<11?j+7:j<18?j-11:18];};
        for(int j=0;j<19;j++)if(!(repeatmask>>j&1))unshared.insert(wire(j));
        for(int q=0;q<11;q++)for(int op=0;op<2;op++)for(int l=0;l<8;l++)if(banned[q][op]>>l&1){
            int a=wire(q),b=wire(11+l);if(a>b)swap(a,b);
            banjoin.insert((uint64_t(a)<<33)|(uint64_t(b)<<1)|op);
        }
        // A replacement by a raw wire or one new pure gate saves a mixed gate.
        // The resulting point/line widths are at most 12/9 and those m<=22
        // sectors are already excluded under the original total-size cap.
        for(int i=0;i<nleaves;i++)raw_bounds.push_back(wires[orig[i]].value);
        const auto starts=raw_bounds;
        for(int i=0;i<(int)starts.size();i++)for(int j=0;j<i;j++){
            auto a=starts[i],b=starts[j];
            if(a[5]!=b[5])continue;
            for(int op=0;op<2;op++){
                Signature h{};
                for(int w=0;w<=blocks;w++)h[w]=op?a[w]|b[w]:a[w]&b[w];
                raw_bounds.push_back(h);
            }
        }
        Signature zero{},one{};
        one[0]=(Bits(1)<<count_pos)-1;
        for(int b=1;b<=blocks;b++)one[b]=(b<blocks||count_neg%64==0)?~Bits(0):((Bits(1)<<(count_neg%64))-1);
        raw_bounds.push_back(zero);raw_bounds.push_back(one);
        for(auto &v:raw_bounds)v[5]=0;
        sort(raw_bounds.begin(),raw_bounds.end());raw_bounds.erase(unique(raw_bounds.begin(),raw_bounds.end()),raw_bounds.end());
        sort(orig.begin(),orig.begin()+nleaves);
        vector<States> states(budget+1);states[0].insert(orig);
        for(int gate=1;gate<=nleaves-1+budget;gate++){
            vector<States> following(budget+1);size_t next_cleanup=100000;
            for(int u=0;u<=budget;u++)for(auto&s:states[u]){
                next(s,nleaves-(gate-1)+u,following[u],u<budget?&following[u+1]:nullptr,u+2<=budget?&following[u+2]:nullptr,budget-u);
                if(following[budget].size()>next_cleanup){
                    auto& group=following[budget];
                    for(auto it=group.begin();it!=group.end();){
                        if(may_read_once(*it,nleaves-gate+budget))++it;
                        else it=group.erase(it);
                    }
                    next_cleanup=max<size_t>(100000,2*group.size()+1);
                }
            }
            if(all_of(following.begin(),following.end(),[](const States&x){return x.empty();}))return {gate,0};
            states.swap(following);
        }
        return {nleaves-1+budget,int(states[budget].size())};
    }
};
int main(){
    int p=0,n=0,count=0,point_count=0,line_count=0,budget=0;
    cin>>p>>n;
    if(p!=28||n!=245)return 1;
    vector<int> raw_p(p),raw_n(n);
    for(int&x:raw_p)cin>>x;for(int&x:raw_n)cin>>x;
    cin>>count>>point_count>>line_count>>budget;
    if(point_count!=11 || line_count<7 || line_count>10 || budget<0 || budget>5)return 2;
    for(int i=0;i<count;i++){
        Family f{};
        for(int&x:f)if(!(cin>>x)||x<0||x>=8192)return 3;
        array<int,10> lines{};
        for(int j=0;j<line_count;j++)
            if(!(cin>>lines[j])||lines[j]<0||lines[j]>=128)return 4;
        auto project=[&](int r){
            int z=0;
            for(int j=0;j<7;j++)if((r>>13)&lines[j])z|=1<<j;
            for(int j=0;j<11;j++)if(r&f[j])z|=1<<(7+j);
            for(int j=7;j<line_count;j++)if((r>>13)&lines[j])z|=1<<(11+j);
            return z;
        };
        set<int> pp,nn;
        for(int r:raw_p)pp.insert(project(r));for(int r:raw_n)nn.insert(project(r));
        vector<int> ps(pp.begin(),pp.end()),ns;
        for(int r:nn)if(none_of(nn.upper_bound(r),nn.end(),[&](int q){return !(r&~q);}))ns.push_back(r);
        Search search;cin>>search.repeatmask;for(auto &row:search.banned)for(int &v:row)cin>>v;
        vector<int> primitives;
        for(int j=0;j<20;j++)primitives.push_back(1<<j);
        for(int j=0;j<6;j++){
            int a=3<<j,b=(1<<(j+3))|(1<<((j+9)%13));
            primitives.insert(primitives.end(),{a,b,a|b});
        }
        vector<int> lower(ps.size(),(1<<20)-1),upper(ns.size());
        for(int r:raw_p){int v=project(r); for(int j=0;j<(int)ps.size();j++)if(ps[j]==v)lower[j]&=r;}
        for(int r:raw_n){int v=project(r); for(int j=0;j<(int)ns.size();j++)if(!(v&~ns[j]))upper[j]|=r;}
        for(int prim:primitives){
            Signature h{};
            for(int j=0;j<(int)ps.size();j++)if(lower[j]&prim)h[0]|=Bits(1)<<j;
            for(int j=0;j<(int)ns.size();j++)if(upper[j]&prim)h[1+j/64]|=Bits(1)<<(j%64);
            h[5]=prim<8192;search.raw_bounds.push_back(h);
        }
        auto [gate,status]=search.run(ps,ns,11+line_count,budget);
        if(status!=0){cerr<<"surviving family row "<<i<<" status "<<status<<endl;return 5;}
        cout<<gate<<'\n';
    }
}
