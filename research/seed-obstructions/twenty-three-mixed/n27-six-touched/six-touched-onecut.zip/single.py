from eager import solve
from rows import raw
for j in range(7):
    result=solve([1<<i for i in range(7)]+[127^(1<<j)],raw)
    print(j,result,flush=True)
    assert not result
