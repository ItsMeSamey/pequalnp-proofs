from rows import raw,P,N
from pysat.solvers import Solver
from functools import lru_cache
from itertools import combinations
from pathlib import Path
def tr(ms,words):return [sum(1<<i for i,m in enumerate(ms) if w&m) for w in words]
@lru_cache(maxsize=2048)
def lits(d):
 return tuple(i+1 for i in range(d.bit_length()) if d>>i&1)
PP=tr(raw,P);NN=tr(raw,N)
def solve(lines,pts=raw):
 ms=tuple(m<<13 for m in lines)
 w=len(pts)+len(ms)
 pseq=[x|(y<<len(pts)) for x,y in zip(PP if pts==raw else tr(pts,P),tr(ms,P))]
 nseq=[x|(y<<len(pts)) for x,y in zip(NN if pts==raw else tr(pts,N),tr(ms,N))]
 hp=[0]*w;hn=hp.copy();clauses=[];gl={}
 # Combine equal projected difference sets: a single Boolean indicates all of its slots are inner.
 # A second Boolean indicates all slots are outer. Both implications used only in necessary direction.
 for a,p in enumerate(pseq):
  for b,n in enumerate(nseq):
   d=p&~n
   if not d:return False
   if d not in gl:gl[d]=[0,0,[]]
   z=gl[d];z[0]|=1<<a;z[1]|=1<<b;z[2].append((a,b))
 for d,(ps,ns,_) in gl.items():
  if not d&(d-1):i=d.bit_length()-1;hp[i]=ps;hn[i]=ns
 for i,j in combinations(range(w),2):
  if hp[i]&hp[j] and hn[i]&hn[j]:clauses.extend([[i+1,j+1],[-i-1,-j-1]])
 P0=w+1;N0=P0+len(P);v=N0+len(N)
 for d,(ps,ns,pairs) in gl.items():
  xs=lits(d);inside=v;outside=v+1;v+=2
  clauses.append([-x for x in xs]+[inside])
  clauses.append([*xs,outside])
  while ps:
   bit=ps&-ps;clauses.append([-inside,P0+bit.bit_length()-1]);ps^=bit
  while ns:
   bit=ns&-ns;clauses.append([-inside,-(N0+bit.bit_length()-1)]);ns^=bit
  clauses.extend([[-outside,-(P0+a),N0+b]for a,b in pairs])
 with Solver(name='cadical195',bootstrap_with=clauses) as sat:return sat.solve()
