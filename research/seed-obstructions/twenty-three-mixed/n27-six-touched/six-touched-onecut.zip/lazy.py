from rows import *
def solve(lines,pts):
 ms=[*pts,*[m<<13 for m in lines if m]]
 w=len(ms);S=[[w+1+i for i in range(len(P))],[w+1+len(P)+i for i in range(len(N))]]
 px=[sum(1<<i for i,m in enumerate(ms) if m&p) for p in P]
 nx=[sum(1<<i for i,m in enumerate(ms) if m&n) for n in N]
 hitp=[0]*w;hitn=[0]*w;DR={}
 for a,p in enumerate(px):
  for b,n in enumerate(nx):
   d=p&~n
   if not d:return False
   if not (d & (d-1)):
    i=d.bit_length()-1;hitp[i]|=1<<a;hitn[i]|=1<<b
   DR[a,b]=d
 F=[]
 for i,j in combinations(range(w),2):
  if hitp[i]&hitp[j] and hitn[i]&hitn[j]:F.extend([[i+1,j+1],[-i-1,-j-1]])
 with Solver(name='cadical195',bootstrap_with=F) as sat:
  if not sat.solve():return False
  # Lazy Boolean row violations. Work on a model through all row implications.
  seen=set()
  while True:
   model=set(sat.get_model());inner=sum(1<<i for i in range(w) if i+1 in model)
   highs=set();lows=set()
   for (a,b),d in DR.items():
    if not d&~inner:highs.add(a);lows.add(b)
   conflicts=[(a,b) for a in highs for b in lows if not DR[a,b]&inner]
   if not conflicts:return True
   # Add full bit clauses incident to the failed positive and failed negative.
   for a,b in conflicts:
    for idx in [(a,b),*[(a,k) for k in range(len(N)) if not DR[a,k]&~inner],*[(k,b) for k in range(len(P)) if not DR[k,b]&~inner]]:
     if idx in seen:continue
     seen.add(idx);i,j=idx;d=DR[idx];xs=[k+1 for k in range(w) if d>>k&1]
     sat.add_clause([-x for x in xs]+[S[0][i]])
     sat.add_clause([-x for x in xs]+[-S[1][j]])
     sat.add_clause(xs+[-S[0][i],S[1][j]])
   if not sat.solve():return False
