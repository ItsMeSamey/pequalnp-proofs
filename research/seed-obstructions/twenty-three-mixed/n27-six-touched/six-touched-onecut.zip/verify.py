"""Enumerate the six touched-label partitions and test a relaxation with every pure primitive."""
from itertools import combinations
from collections import Counter
from rows import raw
from eager import solve

def partitions(labels):
    if not labels:
        yield ()
        return
    head=min(labels)
    for size in range(2,len(labels)+1):
        for rest in combinations(sorted(labels-{head}),size-1):
            block={head,*rest}
            for out in partitions(labels-block):
                yield (sum(1<<j for j in block),*out)

if __name__=='__main__':
    import sys
    if '--lazy' in sys.argv:
        from lazy import solve
    hits=Counter()
    for untouched in range(7):
        for blocks in partitions(set(range(7))-{untouched}):
            if len(blocks)<2: continue
            profile=tuple(sorted(v.bit_count()for v in blocks))
            yes=solve([1<<i for i in range(7)]+list(blocks),raw)
            hits[profile,yes]+=1
            print(untouched,','.join(map(str,blocks)),int(yes),flush=True)
    print(sorted(hits.items()))
    assert hits=={((2,2,2),False):105,((2,4),False):105,((3,3),False):70}
