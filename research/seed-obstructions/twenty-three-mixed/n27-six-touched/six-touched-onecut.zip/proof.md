# All-source one-bit test for six touched line labels

After substituting the point forest, there is one repeated wire. Its inputs form a read-once subtree. The outer read-once formula uses two occurrences of the subtree's output H. A repeated original leaf is allowed. No restriction on which side supplies the inner leaves is imposed. At saturated line fanout, the labelled line slots consist of all seven singleton flags and disjoint blocks of touched labels. The upstream single-block sector is separate. Partitioning the six touched labels into blocks of size at least two and at least two blocks yields the sizes 2+4, 3+3, and 2+2+2. There are respectively 105, 70, and 105 labelled choices including the untouched label.

We may grant the partition all 31 physical point primitives. In a circuit using only 20, every unused primitive can be placed on either side and ignored by the corresponding function. Each mask evaluates as its singleton OR, exact on positive assignments and favorable on negatives. For each required positive p and negative n form the complete set D of slots true at p and false at n. A valid circuit needs D to be nonempty. If D={i}, monotonicity makes i pivotal at both p and n. In particular the original circuit must actually use i.

Two leaves pivotal at the same positive need an AND least common ancestor when they lie in the same read-once formula. Two leaves pivotal at a common negative need an OR ancestor. For two inner leaves pivotal changes must reach H. For two exterior leaves their pivotal flips fix both copies of H on each witness. Thus a pair with both requirements lies on opposite sides of the cut. The first SAT clauses enforce this constraint using the all-source witnesses, which any feasible subset inherits.

Write I_i=1 for a leaf inside the repeated subtree. If every slot in D is inner, the outside coordinates of p are dominated by those of n; H(p)=1 and H(n)=0 must follow. Conversely an H-positive row and an H-negative row must have at least one inner slot in D. These are two clauses with negative membership literals and one with positive membership literals for each ordered positive/negative comparison. Together with the ancestor constraints they apply even when H is a raw leaf or a pure function after forest substitution.

The solver initially enforces the ancestor constraints. For a tentative inner assignment it computes all p and n forced to H=1 and H=0 by comparisons with no outer distinctor. A forced-positive/forced-negative pair lacking any inner distinctor is contradictory. The solver adds the clauses for this pair and the comparisons forcing each endpoint. Every added clause is a necessary member of the fixed finite system. An UNSAT result excludes every 20-source choice simultaneously. A feasible assignment is only an unresolved one-bit relaxation.

The default verifier eagerly encodes the same three row clauses. Comparisons with identical D share an auxiliary for all-inner and another for all-outer. Only the implications from the conjunction of member choices to the auxiliary are needed. It scans each profile separately, sharing neither learned facts nor geometric relabellings across profiles. The flag --lazy selects the original incremental formulation.

```sh
nice -n 15 python3 verify.py
```

The six-label single-block profile and the handling of singleton echoes remain upstream case divisions. This verifier proves its three advertised profiles even if more than 20 primary point inputs are available. It does not require a point-width census, pure point complexity estimates, or symmetry reductions.

For completeness single.py directly checks the seven alternative six-label single-block profiles with the same all-source one-bit conditions. These seven are also unsatisfiable. This run supersedes the need to invoke a separate L8/k1 theorem for that profile. Together the four block sizes give all 287 labelled no-echo cases with six touched lines.
