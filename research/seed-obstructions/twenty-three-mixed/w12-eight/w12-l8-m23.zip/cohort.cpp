#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;using U=__uint128_t;
int ix(U x){return (unsigned long long)x?countr_zero((unsigned long long)x):64+countr_zero((unsigned long long)(x>>64));}
struct Row{int p,n;U flags;};
bool hit(const vector<int>&a,const vector<int>&b,int yes=0,int no=0){
 int q=0;
 for(;;){int ny=yes,nn=no,pa=0,pb=0,best=14;
  for(int s=0;s<2;s++)for(int x:s?b:a){if(x&(s?no:yes))continue;
   int rem=x&~(s?yes:no);if(!rem)return false;
   if((rem&(rem-1))==0){(s?nn:ny)|=rem;continue;}
   (s?pb:pa)++;int c=popcount((unsigned)rem);
   if(c<best){best=c;q=rem&-rem;}
  }
  if(ny&nn)return false;if(ny!=yes||nn!=no){yes=ny;no=nn;continue;}
  if(!pa||!pb)return true;break;
 }
 return hit(a,b,yes|q,no)||hit(a,b,yes,no|q);
}
int main(int argc,char**av){
 ifstream fs(av[1]);int np,nn;fs>>np>>nn;assert(np==28&&nn==245);
 vector<int>P(np),N(nn);int star[7]{};for(int &p:P){fs>>p;star[countr_zero((unsigned)(p>>13))]|=p&8191;}for(int &n:N)fs>>n;
 int jnum=0,jidx[128]{};vector<int> groups;for(int m=1;m<128;m++)if(popcount((unsigned)m)<=7){jidx[m]=jnum++;groups.push_back(m);}assert(jnum==127);
 vector<int> pat;int id[8192];fill_n(id,8192,-1);auto get=[&](int x){if(id[x]<0){id[x]=pat.size();pat.push_back(x);}return id[x];};
 vector<Row>pr,ou;
 for(int t=0;t<7;t++)for(int x=0;x<13;x++)if(star[t]>>x&1)for(int y=0;y<13;y++)if(!(star[t]>>y&1))for(int z=0;z<y;z++)if(!(star[t]>>z&1))pr.push_back({get(1<<x),get((1<<y)|(1<<z)),1ULL<<t});
 for(int p:P)for(int n:N)if((p>>13)&(n>>13)){int meet=0;for(int t=0;t<7;t++)if(n&star[t])meet|=1<<t;U tags=0;
  for(int j:groups)if(!(j&(p>>13))&&!(j&~meet))tags|=U(1)<<jidx[j];if(tags)ou.push_back({get(p&8191),get(n&8191),tags});}
 vector<int>rank(8192);for(int i=0;i<8192;i++)rank[i]=i;sort(rank.begin(),rank.end(),[](int x,int y){return popcount((unsigned)x)<popcount((unsigned)y);});
 if(argc!=5)return 2;ios::sync_with_stdio(false);cin.tie(nullptr);
 vector<array<int,12>> banks;array<int,12> b;
 while(cin>>b[0]){for(int j=1;j<12;j++)if(!(cin>>b[j]))return 3;banks.push_back(b);}
 int group=stoi(av[2]),start=stoi(av[3]),end=min(stoi(av[4]),(int)banks.size());
 if(group<=0||start<0||start>=end)return 4;
 vector<int> Es;for(int e=0;e<128;e++)if(popcount((unsigned)e)<=2)Es.push_back(e);
 auto weight=[](U x){return popcount((unsigned long long)x)+popcount((unsigned long long)(x>>64));};
 vector<U> allowed(Es.size());
 for(int i=0;i<(int)Es.size();i++){int o=127^Es[i];for(int j=o;j;j=(j-1)&o)if(popcount((unsigned)(o^j))<=4)allowed[i]|=U(1)<<jidx[j];}
 long long total=0,pass=0,nodes=0,tests=0;
 auto run=[&](auto&self,int a,int z,U emp)->void{
  U needed=0;for(U ed=emp;ed;ed&=ed-1)needed|=allowed[ix(ed)];
  nodes++;tests+=weight(needed);
  vector<int>hi(pat.size()),lo(pat.size(),4095);
  for(int j=0;j<(int)pat.size();j++)for(int i=0;i<12;i++){
   bool h=false,l=true;
   for(int s=a;s<z && (!h||l);s++){bool v=pat[j]&banks[s][i];h|=v;l&=v;}
   if(h)hi[j]|=1<<i;if(!l)lo[j]^=1<<i;
  }
  U at[8192]{},bt[8192]{};for(auto r:pr)at[hi[r.p]&~lo[r.n]]|=r.flags;for(auto r:ou)bt[hi[r.p]&~lo[r.n]]|=r.flags;
  vector<int>pp[7],oo[127];
  auto push=[](vector<int>&v,int m){for(int x:v)if(!(x&~m))return;v.push_back(m);};
  for(int x:rank){U a=at[x],b=bt[x];for(;a;a&=a-1)push(pp[ix(a)],x);b&=needed;for(;b;b&=b-1)push(oo[ix(b)],x);}
  U possibles=0;
  for(int m:groups){if(!(needed&(U(1)<<jidx[m])))continue;vector<int>all;for(int j=0;j<7;j++)if(m>>j&1)all.insert(all.end(),pp[j].begin(),pp[j].end());if(hit(all,oo[jidx[m]]))possibles|=U(1)<<jidx[m];}
  U keep=0;for(U es=emp;es;es&=es-1){int i=ix(es);if(possibles&allowed[i])keep|=U(1)<<i;}
  total+=(z-a)*weight(emp&~keep);
  if(!keep)return;
  if(z-a==1){for(U es=keep;es;es&=es-1){cout<<a<<" "<<Es[ix(es)]<<"\n";pass++;total++;}return;}
  int mid=(a+z)/2;self(self,a,mid,keep);self(self,mid,z,keep);
 };
 for(int a=start;a<end;a+=group){run(run,a,min(end,a+group),(U(1)<<Es.size())-1);if((a-start)%(group*16)==0)cerr<<"point "<<a<<" nodes "<<nodes<<" tests "<<tests<<" kept "<<pass<<endl;}
 cerr<<"DONE "<<total<<" "<<pass<<" "<<nodes<<" "<<tests<<endl;
 if(total!=int(Es.size())*1LL*(end-start))return 5;
}
