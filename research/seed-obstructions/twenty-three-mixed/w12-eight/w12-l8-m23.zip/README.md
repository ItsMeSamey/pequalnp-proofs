# Twelve point wires, eight line wires and 23 mixed gates

At nine paid point gates the remaining one paid gate produces the eighth line boundary. The seven singleton labels are necessary. The additional line has zero singleton support, repeats a singleton, or accepts the union of two singleton labels. The point catalogue grants the 765 affordable or unconstrained representatives in the nine-paid-point enumeration in twenty-two-nine-point-nine. Bounding a physical bank by its singleton masks preserves all positives and may remove negative acceptances. Thus an exclusion of a normalized bank transfers to every corresponding physical bank.

For a pair of line labels E, five other labels remain ordinary. Cutting four surplus reads gives at most four promotions in the ordinary-private placement theorem. At least one nonempty set J of ordinary targets is retained. Their guards can use a shared set of point inputs. The complementary point inputs must distinguish every non-J positive from every negative activating its line and meeting all J neighborhoods. The inputs assigned to a guard must distinguish each of its incident points from every off-target pair. Each off-target pair is dominated by an original negative of the relevant line. The component argument of syn_dual/eight-three/README.md works for any number of surplus reads: in the exterior component, connectivity bounds the number of promoted private groups by the sum of fanout minus one, while each nonroot sole ordinary resident is charged to its own surplus. In this first filter all possible sharing within the private pool is granted.

The C++ placement filter checks every set J and both disjoint sets of point inputs. The 14,051 simultaneous orbits for two-label E reduce to 3,231 candidates. The 4,847 one-label cases reduce to 322. All 765 zero cases pass placement. On physical zero cases, substituting false agrees on positives and decreases every negative. Simplifying its first incident mixed gate leaves at most 22 mixed gates, excluded by synthesis_new/twenty-two-summary.

The four-surplus checker cuts the first repeated wire in topological order, enumerates its possible read-once subtrees, and replaces it by two formal occurrences. A source may be cut again. In the one-surplus remainder it checks forced endpoint monotonicity and private pair constraints. With no surplus it checks the read-once LCA constraints and reconstructs the full typed tree. In states with two or three surplus reads, state-regions.hpp additionally checks ordered-region constraints on the current row signatures. Exceeding that filter's branch budget admits the state.

Run `python verify.py --placement-only` for the projected domain and first filter. The defaults use E of size two. Run `python verify.py` for a recursive check of all surviving pairs, or partition by `--start` and `--end` (zero-based half-open). Use `--weight 1` for the duplicate singleton. The supplied sample.py and input.py reconstruct the 28 positive and 245 negative samples from the raw formal statement and verify every geometric symmetry against them.

For an additional physical simplification, a zero point boundary can be clamped exactly as a zero line. If two point boundaries have the same singleton raw support, replace both with the raw input throughout the physical circuit. The substitution preserves their positive values and decreases every negative value. At least one paid point gate disappears and at most eleven physical point wires reach the mixed cone, whereas that width requires at least nine paid point gates. This rules out every such repeated-singleton case at point cost nine. The auxiliary filtered-fast.cpp uses a packed negative-row table in the final cotree precheck. Its complete subset enumeration after that precheck is identical to filtered.cpp.

For larger E, at most 11−|E| paid point gates remain. The connected dependency cone for the extra line uses at least |E|−1 binary gates to collect its essential raw labels, and an OR tree attains that cost. The independently checked twelve-eight manifest supplies 2,767 physical point banks through cost eight. Minimize the price over each point orbit, and divide the line masks by its stabilizer. This gives 4,279 triples on 151 point representatives, 757 quartets on 32, 73 quintets on seven, and six sextets on two. A weight-seven E requires six paid line gates and would leave four point gates, below the width-twelve minimum. Run `python verify_lower.py --weight 3` through `--weight 6` for these groups, optionally with the same half-open index range or `--domain-only`.

At weight two the default exact replay skips four zero point boundaries and 57 repeated raw-singleton point cases using those physical reductions. Its candidate list has 3,170 entries. Use `--all-normalized` to check the larger relaxation. Weight one is replayed on all 322 normalized candidates.

## Result

No circuit with at most 33 residual gates, 23 mixed gates, 12 point inputs to the mixed cone and eight line inputs to it satisfies the raw sample table.

| Extra line support | Joint point/line orbits | Exact four-copy checks | Survivors |
|---:|---:|---:|---:|
| 0 | 765 | Clamping lowers the mixed count | 0 |
| 1 | 4,847 | 322 | 0 |
| 2 | 14,051 | 3,170 | 0 |
| 3 | 4,279 | 4,279 | 0 |
| 4 | 757 | 757 | 0 |
| 5 | 73 | 73 | 0 |
| 6 | 6 | 6 | 0 |

The evidence logs contain one line per exact case, in the same order as the corresponding verifier. Their first field is the Boolean result. The direct and packed final-cotree implementations agree in the 15-case pair smoke test. The supplemental root-resident private guard observations are unnecessary for the exclusion and are omitted from the replay.
