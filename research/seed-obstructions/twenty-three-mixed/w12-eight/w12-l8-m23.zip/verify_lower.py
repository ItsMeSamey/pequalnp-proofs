"""Replay the lower point budgets for W12/L8 at 23 mixed gates."""
from argparse import ArgumentParser
from itertools import combinations
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory
from sample import move, neg, pos, raw, symmetries
from verify import rows

base=Path(__file__).resolve().parent
cli=ArgumentParser(description=__doc__)
cli.add_argument('--weight', type=int, choices=range(3,7), required=True)
cli.add_argument('--start',type=int,default=0)
cli.add_argument('--end',type=int)
cli.add_argument('--domain-only',action='store_true')
args=cli.parse_args()
sr=list(map(int,(base/'samples').read_text().split()))
assert sr[:2]==[28,245] and set(sr[2:30])==pos and set(sr[30:])==neg
g=symmetries()
table=rows(base/'banks-through-eight.txt')
assert len(table)==2767
masks={m for row in table for m in row[:-1]}
images=[{m:move(m,p) for m in masks} for p,_ in g]
price={}
for row in table:
    key=min(tuple(sorted(t[m] for m in row[:-1])) for t in images)
    price[key]=min(price.get(key,99),row[-1])
banks=rows(base/'point-subset')
ids=list(map(int,(base/'catalog-viable.txt').read_text().split()))
assert set(price)<=set(banks)
inputs=[]
for i,bank in enumerate(banks):
    if price.get(bank,99)>11-args.weight:continue
    group=[j for j,(p,_) in enumerate(g) if tuple(sorted(move(m,p) for m in bank))==bank]
    for choice in combinations(raw,args.weight):
        e=sum(choice)
        if e==min(g[j][1][e] for j in group):inputs.append((i,e))
assert len(inputs)=={3:4279,4:757,5:73,6:6}[args.weight]
assert {(ids[i],e) for i,e in inputs}==set(rows(base/f'c{args.weight}'))
print(len(inputs),'joint orbits',flush=True)
if not args.domain_only:
    with TemporaryDirectory() as rawdir:
        tmp=Path(rawdir)
        def build(name):
            target=tmp/name
            subprocess.run(['g++','-std=c++20','-O3',str(base/(name+'.cpp')),'-o',str(target)],check=True)
            return target
        chosen=inputs[args.start:args.end]
        pairs=''.join(f'{i} {e}\n' for i,e in chosen)
        projected=subprocess.run([build('project'),base/'samples',base/'point-subset'],input=pairs,text=True,stdout=subprocess.PIPE,check=True)
        answer=subprocess.run([build('filtered-fast'),'12','8','4'],input=projected.stdout,text=True,stdout=subprocess.PIPE,check=True)
        output=answer.stdout.splitlines()
        assert len(output)==len(chosen)
        for (i,e),line in zip(chosen,output):
            if int(line.split()[0]):print('survivor',ids[i],e)
        print(len(output),'checks;',sum(int(line.split()[0])for line in output),'survivors.')
