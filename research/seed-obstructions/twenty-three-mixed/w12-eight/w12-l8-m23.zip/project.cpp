#include <algorithm>
#include <array>
#include <bit>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
int main(int argc,char**argv){
 ifstream f(argv[1]),p(argv[2]);int np,nn;f>>np>>nn;vector<int> rows(np+nn);
 for(auto&x:rows)f>>x;
 array<int,12>a;vector<array<int,12>> bank;
 while(p>>a[0]){for(int k=1;k<12;k++)p>>a[k];bank.push_back(a);}
 int i,e,last=-1;vector<unsigned> yes,no;
 while(cin>>i>>e){
  if(i!=last){last=i;yes.clear();no.clear();vector<unsigned> outputs;
   for(auto r:rows){int t=(r>>13)<<12;for(int h=0;h<12;h++)if(r&bank[i][h])t|=1<<h;outputs.push_back(t);}
   yes.assign(outputs.begin(),outputs.begin()+np);sort(yes.begin(),yes.end());yes.erase(unique(yes.begin(),yes.end()),yes.end());
   vector<unsigned> candidates(outputs.begin()+np,outputs.end());sort(candidates.begin(),candidates.end(),[](auto a,auto b){return popcount(a)>popcount(b);});
   for(auto z:candidates)if(none_of(no.begin(),no.end(),[&](auto n){return !(z&~n);}))no.push_back(z);
  }
  cout<<yes.size()<<' '<<no.size();for(auto vals:{&yes,&no})for(auto z:*vals)cout<<' '<<(z|(((z>>12)&e)?1<<19:0));cout<<'\n';
 }
}
