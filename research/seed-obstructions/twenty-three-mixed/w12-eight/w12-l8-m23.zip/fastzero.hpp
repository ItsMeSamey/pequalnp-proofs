bool quick_cotree(const State&s){
 using Mask=unsigned;using Negative=array<uint64_t,4>;
 auto bit=[](Mask x){return countr_zero(x);};
 int n=s.size();Mask full=(1u<<n)-1,pmask=0,lmask=0,mmask=0;
 array<Mask,32> pos{};
 array<array<Negative,16>,6> groups{};
 for(int i=0;i<n;i++){
   if(s[i].type==1)pmask|=1u<<i;else if(s[i].type==2)lmask|=1u<<i;else mmask|=1u<<i;
   for(Mask v=s[i].p;v;v&=v-1)pos[bit(v)]|=1u<<i;
 }
 for(int g=0;g<(n+3)/4;g++){
   for(int k=0;k<4;k++)groups[g][0][k]=(nn<=64*k)?0:(nn>=64*(k+1))?~uint64_t(0):(uint64_t(1)<<(nn%64))-1;
   for(unsigned m=1;m<(1u<<min(4,n-4*g));m++){
     auto &t=groups[g][m], &a=groups[g][m&(m-1)];
     auto &b=s[4*g+bit(m)].n;for(int k=0;k<4;k++)t[k]=a[k]&b[k];
   }
 }
 auto zero=[&](Mask m){auto v=groups[0][m&15];for(int g=1;g<(n+3)/4;g++){auto &t=groups[g][(m>>(4*g))&15];
     for(int k=0;k<4;k++)v[k]&=t[k];}return v;};
    std::array<Mask,31> posmark{},yes{},no{},conflict{};
    std::array<Negative,31> negmark{};
    for(int x=0;x<np;x++){
        auto base=zero(pos[x]);
        if(base[0]|base[1]|base[2]|base[3])return false;
        for(Mask v=pos[x];v;v&=v-1){
            int i=bit(v);auto z=zero(pos[x]^(Mask(1)<<i));
            if(z[0]|z[1]|z[2]|z[3])posmark[i]|=Mask(1)<<x;
            for(int k=0;k<4;k++)negmark[i][k]|=z[k];
        }
    }
    for(int i=0;i<n;i++)for(int j=0;j<i;j++){
        bool and_pair=posmark[i]&posmark[j];bool or_pair=false;
        for(int k=0;k<4;k++)if(negmark[i][k]&negmark[j][k])or_pair=true;
        if(and_pair){yes[i]|=Mask(1)<<j;yes[j]|=Mask(1)<<i;}
        if(or_pair){no[i]|=Mask(1)<<j;no[j]|=Mask(1)<<i;}
        if(and_pair&&or_pair)return false;
    }
    auto component=[&](const auto&edge,Mask mask) {
        Mask frontier=mask&-mask,seen=frontier;
        while(frontier){
            Mask next=0;for(Mask v=frontier;v;v&=v-1)next|=edge[bit(v)];
            frontier=next&mask&~seen;seen|=frontier;
        }
        return seen;
    };
    auto compatible=[&](auto&&self,Mask mask)->bool {
        if(std::popcount(mask)<4)return true;
        Mask part=component(yes,mask);if(part==mask)part=component(no,mask);
        return part!=mask&&self(self,part)&&self(self,mask^part);
    };
    return compatible(compatible,full);
}
