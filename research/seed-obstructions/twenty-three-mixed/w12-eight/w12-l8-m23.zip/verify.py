"""Replay the 23-mixed-gate width-12/8, nine-paid-point filter and four-copy check."""
from itertools import combinations
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse
import subprocess
from sample import move, neg, pos, raw, symmetries

base = Path(__file__).resolve().parent
def rows(path):
    return [tuple(map(int, s.split())) for s in path.read_text().splitlines()]

def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--weight', type=int, choices=[0,1,2], default=2)
    cli.add_argument('--start', type=int, default=0)
    cli.add_argument('--end', type=int)
    cli.add_argument('--placement-only', action='store_true')
    cli.add_argument('--all-normalized',action='store_true',help='also run physically impossible zero and repeated raw-point cases')
    args = cli.parse_args()
    banks = rows(base/'point-subset')
    ids = list(map(int,(base/'catalog-viable.txt').read_text().split()))
    assert len(banks)==len(ids)==765 and ids==sorted(set(ids))
    group = symmetries()
    sr = list(map(int,(base/'samples').read_text().split()))
    assert sr[:2]==[28,245] and set(sr[2:30])==pos and set(sr[30:])==neg
    extras = [sum(t) for t in combinations(raw,args.weight)]
    mset = {m for bank in banks for m in bank}
    maps = [{m:move(m,p) for m in mset} for p,_ in group]
    inputs = []
    for i,bank in enumerate(banks):
        stabilizer = [q for q,u in enumerate(maps) if tuple(sorted(u[m] for m in bank))==bank]
        inputs.extend((i,e) for e in extras if e==min(group[q][1][e] for q in stabilizer))
    assert {(ids[i],e) for i,e in inputs}==set(rows(base/f'c{args.weight}'))
    with TemporaryDirectory() as td:
        tmp = Path(td)
        def build(name):
            target = tmp/name
            subprocess.run(['g++','-std=c++20','-O3',str(base/(name+'.cpp')),'-o',str(target)],check=True)
            return target
        with (base/'point-subset').open() as src:
            cohort = subprocess.run([build('cohort'),base/'samples','1','0','765'],stdin=src,
                                    stdout=subprocess.PIPE,check=True,text=True)
        keep={tuple(map(int,line.split())) for line in cohort.stdout.splitlines()}
        assert len(keep)==5023
        surviving = sorted(set(inputs)&keep)
        assert len(surviving)==[765,322,3231][args.weight]
        print(f'{len(inputs)} input pairs; {len(surviving)} pass placement.',flush=True)
        if args.placement_only:return
        if args.weight==2 and not args.all_normalized:
            def physical(bank):
                return 0 not in bank and all(v.bit_count()!=1 or bank.count(v)==1 for v in bank)
            surviving=[(i,e) for i,e in surviving if physical(banks[i])]
            assert len(surviving)==3170
            print('61 zero or repeated raw-point cases excluded by the physical budget.',flush=True)
        selection = surviving[args.start:args.end]
        pairs = ''.join(f'{i} {e}\n' for i,e in selection)
        projected = subprocess.run([build('project'),base/'samples',base/'point-subset'],input=pairs,
                                   text=True,stdout=subprocess.PIPE,check=True)
        answer = subprocess.run([build('filtered'),'12','8','4'],input=projected.stdout,
                                text=True,stdout=subprocess.PIPE,check=True)
        lines=answer.stdout.splitlines()
        assert len(lines)==len(selection)
        for (i,e),line in zip(selection,lines):
            if int(line.split()[0]): print('survivor',ids[i],e)
        print(f'{len(lines)} exact cases, {sum(int(line.split()[0]) for line in lines)} survivors.')
if __name__=='__main__':
    main()
