bool state_regions(const State&s,int surplus,unsigned budget){
 using Mask=unsigned;using Negative=array<uint64_t,4>;
 auto bit=[](Mask x){return countr_zero(x);};
 int n=s.size();Mask full=(1u<<n)-1,pmask=0,lmask=0,mmask=0;
 array<Mask,32> pos{};
 array<array<Negative,16>,6> groups{};
 for(int i=0;i<n;i++){
   if(s[i].type==1)pmask|=1u<<i;else if(s[i].type==2)lmask|=1u<<i;else mmask|=1u<<i;
   for(Mask v=s[i].p;v;v&=v-1)pos[bit(v)]|=1u<<i;
 }
 for(int g=0;g<(n+3)/4;g++){
   for(int k=0;k<4;k++)groups[g][0][k]=(nn<=64*k)?0:(nn>=64*(k+1))?~uint64_t(0):(uint64_t(1)<<(nn%64))-1;
   for(unsigned m=1;m<(1u<<min(4,n-4*g));m++){
     auto &t=groups[g][m], &a=groups[g][m&(m-1)];
     auto &b=s[4*g+bit(m)].n;for(int k=0;k<4;k++)t[k]=a[k]&b[k];
   }
 }
 auto zero=[&](Mask m){auto v=groups[0][m&15];for(int g=1;g<(n+3)/4;g++){auto &t=groups[g][(m>>(4*g))&15];
     for(int k=0;k<4;k++)v[k]&=t[k];}return v;};
    auto partial=[&](Mask one,Mask later){
        if(!one||!later)return true;
        Mask positive=0;Negative negative{};
        for(int x=0;x<np;x++) {
            auto z=zero(pos[x]&~one);
            if(z[0]|z[1]|z[2]|z[3])positive|=Mask(1)<<x;
            for(int k=0;k<4;k++)negative[k]|=z[k];
        }
        for(Mask q=positive;q;q&=q-1) {
            auto z=zero(pos[bit(q)]&~later);
            if((z[0]&negative[0])|(z[1]&negative[1])|(z[2]&negative[2])|(z[3]&negative[3]))return false;
        }
        return true;
    };
    std::array<Mask,31> posmark{},yes{},no{},conflict{};
    std::array<Negative,31> negmark{};
    for(int x=0;x<np;x++){
        auto base=zero(pos[x]);
        if(base[0]|base[1]|base[2]|base[3])return false;
        for(Mask v=pos[x];v;v&=v-1){
            int i=bit(v);auto z=zero(pos[x]^(Mask(1)<<i));
            if(z[0]|z[1]|z[2]|z[3])posmark[i]|=Mask(1)<<x;
            for(int k=0;k<4;k++)negmark[i][k]|=z[k];
        }
    }
    for(int i=0;i<n;i++)for(int j=0;j<i;j++){
        bool and_pair=posmark[i]&posmark[j];bool or_pair=false;
        for(int k=0;k<4;k++)if(negmark[i][k]&negmark[j][k])or_pair=true;
        if(and_pair){yes[i]|=Mask(1)<<j;yes[j]|=Mask(1)<<i;}
        if(or_pair){no[i]|=Mask(1)<<j;no[j]|=Mask(1)<<i;}
        if(and_pair&&or_pair){conflict[i]|=Mask(1)<<j;conflict[j]|=Mask(1)<<i;}
    }
    auto component=[&](const auto&edge,Mask mask) {
        Mask frontier=mask&-mask,seen=frontier;
        while(frontier){
            Mask next=0;for(Mask v=frontier;v;v&=v-1)next|=edge[bit(v)];
            frontier=next&mask&~seen;seen|=frontier;
        }
        return seen;
    };
    auto compatible=[&](auto&&self,Mask mask)->bool {
        if(std::popcount(mask)<4)return true;
        Mask part=component(yes,mask);if(part==mask)part=component(no,mask);
        return part!=mask&&self(self,part)&&self(self,mask^part);
    };
    std::array<Mask,9> region{};unsigned nodes=0;bool exhausted=false;
    auto search=[&](auto&& self,Mask remaining)->bool {
        if(++nodes>budget){exhausted=true;return true;}
        Mask later=region[surplus];
        for(int j=surplus-1;j>=0;j--){
            if(!partial(region[j],later))return false;
            later|=region[j];
        }
        if(!remaining){
            Mask first=region[0];
            return first&&(!(first&(first-1))||(first&mmask)||((first&pmask)&&(first&lmask)));
        }
        int best=-1,score=-1;
        for(Mask v=remaining;v;v&=v-1){
            int i=bit(v),banned=0;for(int j=0;j<=surplus;j++)banned+=bool(conflict[i]&region[j]);
            if(banned==surplus+1)return false;
            int rank=1000*banned+32*std::popcount(conflict[i]&remaining)+std::popcount((yes[i]|no[i])&remaining);
            if(rank>score){best=i;score=rank;}
        }
        Mask w=Mask(1)<<best;
        for(int j=0;j<=surplus;j++){
            if((conflict[best]&region[j])||!compatible(compatible,region[j]|w))continue;
            region[j]|=w;
            if(self(self,remaining^w))return true;
            region[j]^=w;
        }
        return false;
    };
    bool feasible=search(search,full);
    return feasible;
}
