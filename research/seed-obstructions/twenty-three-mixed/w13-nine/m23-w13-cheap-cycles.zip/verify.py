from pathlib import Path
import subprocess,sys,tempfile
from itertools import combinations_with_replacement
from collections import Counter
from cycles import P,N,family,rawp,rawl
from input import point_obligations
here=Path(__file__).resolve().parent
def parse(rows):return [tuple(map(int,l.split())) for l in rows.splitlines()]
def emit(work,name,rows): (work/name).write_text(''.join(' '.join(map(str,r))+'\n' for r in rows))
def run(args,**kw):return subprocess.run(args,check=True,text=True,capture_output=True,**kw).stdout
with tempfile.TemporaryDirectory() as td:
 w=Path(td)
 for name,file in [('native',here/'point/native.cpp'),('brute',here/'small.cpp'),('sieve',here/'sieve.cpp')]:
  run(['c++','-std=c++20','-O2',file,'-o',w/name])
 primitive,obs=point_obligations(here/'point/L-meta-18968.json')
 catalog=set(parse(run([w/'native'],input=' '.join(map(str,sorted(primitive)))+'\n'+''.join(f'{p} {n}\n' for p,n in obs))))
 assert len(catalog)==81 and catalog==set(parse((here/'point/banks.txt').read_text()))
 one=set(parse((here/'point/through-one.txt').read_text()));assert len(one)==13 and one<=catalog
 emit(w,'points',[(0 if v==rawp else 1 if v in one else 2,*v) for v in sorted(catalog)])
 run([sys.executable,here/'seventeen-final/line_basis.py'])
 nine=run([sys.executable,here/'lines/nine.py']);assert nine.split()==(here/'lines/nine.txt').read_text().split()
 exceptional=parse('\n'.join(nine.splitlines()[1:]))
 emit(w,'lines8',[(*rawl,i) for i in range(128)])
 l9=sorted(set(exceptional)|{tuple(sorted((*rawl,i,j))) for i,j in combinations_with_replacement(range(128),2)})
 assert len(l9)==8280
 emit(w,'lines9',l9);emit(w,'neg',[(x,) for x in sorted(N)])
 for t in (3,4):
  cc=family(t)
  assert len(cc)=={3:29,4:33}[t]
  emit(w,'cycles'+str(t),[(*pts,*lines,len(maxima),*(v for row in maxima for v in row)) for pts,lines,maxima in cc])
 for t,k in ((3,2),(4,3)):
  edges=[(1<<p)|(1<<(t+l)) for p in range(t) for l in (p,(p+1)%t)]
  independent=[x for x in range(1<<(2*t)) if all(e&~x for e in edges)]
  maximal=[x for x in independent if all(x==y or x&~y for y in independent)]
  omitted=[(1<<t)-1,((1<<t)-1)<<t] if t==3 else [-1]
  for hole in omitted:
   ns=[x for x in maximal if x!=hole]
   result=run([w/'brute'],input=' '.join(map(str,[2*t,k,len(edges),len(ns),*edges,*ns]))+'\n')
   assert result.split()[2]=='0',result
   print('minor',result.strip(),flush=True)
 for args in (('4','8'),('3','9'),('4','9','left9')):
  print(run([w/'sieve',*args],cwd=w),flush=True)
 assert not (w/'left8').read_text().strip()
 assert not (w/'left9-remaining').read_text().strip()
 print('All 81 point banks passed both cycle exclusions.')
