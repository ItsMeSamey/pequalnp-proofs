from itertools import combinations
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/"point"))
from samples import raw_samples
P,N=raw_samples(Path(__file__).resolve().parent/"point"/"L-meta-18968.json")
rawp=tuple(1<<i for i in range(13));rawl=tuple(1<<i for i in range(7))
def family(t):
 res=[]
 for L in combinations(rawl,t):
  ls=sum(L)
  choices=[p for p in rawp if sum((p|(l<<13)) in P for l in L)==2]
  for p in combinations(choices,t):
   if any(sum((q|(l<<13)) in P for q in p)!=2 for l in L):continue
   e=[(a,b) for a in p for b in L if (a|(b<<13)) in P]
   maximal=[]
   for u in range(1<<t):
    s=sum(q for i,q in enumerate(p) if u>>i&1);v=ls
    for a,b in e:
     if a&s:v&=~b
    if all(s&q or any(a==q and b&v for a,b in e) for q in p):maximal.append((s,v))
   if t==4 and len(maximal)!=10:continue
   res.append((tuple(p),tuple(L),maximal))
 return res
