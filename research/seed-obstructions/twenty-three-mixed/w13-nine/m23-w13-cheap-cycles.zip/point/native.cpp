#include <cstdint>
#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
using Raw=uint32_t;
struct Demand { int p,n; Raw clause; };
int primitive[31];
vector<Demand> demands;
vector<Raw> need;
set<array<int,13>> result;
vector<int> extra;
void finish(Raw chosen,Raw free,int remaining) {
    if(!remaining) {
        array<int,13> b{};int k=0;
        for(int x:extra)b[k++]=x;
        for(Raw s=chosen;s;s&=s-1)b[k++]=primitive[countr_zero(s)];
        assert(k==13);sort(b.begin(),b.end());result.insert(b);return;
    }
    while(popcount(free)>=remaining){
        Raw x=free&-free;free-=x;finish(chosen|x,free,remaining-1);
    }
}
void cover(Raw chosen,Raw free,int remaining) {
    Raw forced=0,choice=0;int best=32;
    for(Raw clause:need)if(!(clause&chosen)){
        Raw c=clause&free;if(!c)return;
        if(has_single_bit(c))forced|=c;
        int k=popcount(c);if(k<best){best=k;choice=c;}
    }
    if(forced){int k=popcount(forced);if(k<=remaining)cover(chosen|forced,free^forced,remaining-k);return;}
    if(!choice){finish(chosen,free,remaining);return;}
    if(!remaining)return;
    while(choice){
        Raw x=choice&-choice;choice-=x;free-=x;cover(chosen|x,free,remaining-1);
    }
}
int main(){
    for(int&i:primitive)cin>>i;
    int p,n;
    while(cin>>p>>n){Raw clause=0;for(int j=0;j<31;j++)if((primitive[j]&p)&&!(primitive[j]&n))clause|=1u<<j;demands.push_back({p,n,clause});}
    set<int> raw(begin(primitive),end(primitive)),first;
    for(int a:raw)for(int b:raw)for(int x:{a&b,a|b})if(x&&!raw.count(x))first.insert(x);
    set<pair<int,int>> pairs{{0,0}};
    for(int a:first){
        pairs.emplace(0,a);
        for(int b:first)if(a<b)pairs.emplace(a,b);
        for(int b:raw)for(int x:{a&b,a|b})if(x&&!raw.count(x)&&x!=a){pairs.emplace(0,x);pairs.emplace(min(a,x),max(a,x));}
    }
    int steps=0;
    for(auto [a,b]:pairs) {
        extra.clear();if(a)extra.push_back(a);if(b)extra.push_back(b);
        need.clear();Raw forced=0;int maxraw=13-extra.size();
        for(auto row:demands){
            if(((a&row.p)&&!(a&row.n))||((b&row.p)&&!(b&row.n)))continue;
            if(has_single_bit(row.clause))forced|=row.clause;else need.push_back(row.clause);
        }
        if(popcount(forced)>maxraw)continue;
        ++steps;cover(forced,0x7fffffffu^forced,maxraw-popcount(forced));
    }
    for(auto b:result){for(int x:b)cout<<x<<' ';cout<<'\n';}
    cerr<<"paid sets "<<pairs.size()<<" passed forced "<<steps<<" banks "<<result.size()<<'\n';
}
