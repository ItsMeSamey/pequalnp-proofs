from pathlib import Path
import gzip, shutil, subprocess as sp, tempfile, sys
root=Path(__file__).resolve().parent
expected={3:(68,0),4:(848,0),5:(12992,0),6:(210288,12),7:(923773,0)}
with tempfile.TemporaryDirectory() as td:
 w=Path(td)
 for src,name in [('stream.cpp','cycles'),('check-pair.cpp','order'),('endpoint24.cpp','exact')]:
  sp.run(['g++','-O3','-std=c++20',root/src,'-o',w/name],check=True)
 shutil.copy(root/'cycle/rule4',w/'rule4')
 data=list(map(int,(root/'samples').read_text().split()))
 for g in (map(int,sys.argv[1:]) if sys.argv[1:] else expected):
  d=w/str(g);d.mkdir()
  for f in ('cycles3','cycles4','neg'):shutil.copy(root/'cycle'/f,d/f)
  for file,src in [('points','new'),('lines9','lines')]:
   (d/file).write_bytes(gzip.decompress((root/'points'/f'{src}{g}.gz').read_bytes()))
  points=[r.split()[1:] for r in (d/'points').read_text().splitlines()]
  lines=[r.split() for r in (d/'lines9').read_text().splitlines()]
  (d/'pointbank').write_text(''.join(' '.join(r)+'\n' for r in points))
  with (d/'pairs').open('w')as out:sp.run([w/'cycles'],cwd=d,stdout=out,check=True)
  with (d/'pairs').open() as inp:
   n=sum(1 for _ in inp);assert n==expected[g][0];inp.seek(0)
   keep=sp.run([w/'order',root/'samples',d/'pointbank',d/'lines9','13','9','2','2000'],stdin=inp,capture_output=True,check=True,text=True).stdout.splitlines()
  assert len(keep)==expected[g][1]
  for row in keep:
   i,j=map(int,row.split());ms=list(map(int,points[i]))+[int(v)<<13 for v in lines[j]]
   packet=data[:2]+[sum(1<<k for k,v in enumerate(ms) if v&x) for x in data[2:]]
   out=sp.run([w/'exact','13','9','2'],input=' '.join(map(str,packet))+'\n',text=True,capture_output=True,check=True)
   assert out.stdout.split()[0]=='0'
  print(g,len(points)*len(lines),n,len(keep),0,flush=True)
