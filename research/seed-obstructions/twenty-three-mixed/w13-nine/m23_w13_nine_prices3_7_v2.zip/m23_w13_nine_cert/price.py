from collections import Counter
from pathlib import Path
import sys
root=Path('/dev/shm/syn_cover_w13l9')
def price(bank):
 d={m for m in bank if m.bit_count()>1}; overhead=len(bank)-len(d)-len({m for m in bank if m.bit_count()==1})
 if len(d)>2:assert len(d)==3 and all(m.bit_count()==2 for m in d);return overhead+3
 if len(d)==2:
  a,b=d;return overhead+(a|b).bit_count()-(1 if a&b else 2)
 return overhead+sum(m.bit_count()-1 for m in d)
if __name__=='__main__':
 tables=[tuple(map(int,l.split())) for l in (root/'lines.txt').read_text().splitlines()]
 print(Counter(map(price,tables)))
 for t in range(2,7):
  (root/f'lines{t}').write_text(''.join(' '.join(map(str,b))+'\n' for b in tables if price(b)<=t))
