from pathlib import Path
import sys
from itertools import permutations
near=Path(__file__).resolve().parent;sys.path.insert(0,str(near))
from cycles import P,family
data=list(map(int,(near/'cycle8.in').read_text().split()));pos=set(data[4:12]);neg=data[12:];assert len(neg)==10
repmap=list(map(int,(near/'rep4.map').read_text().split()))
keys=list(map(int,(near/'rep4.list').read_text().split()))
stats=[int(s.split()[2])for s in (near/'rep4k2-safe.out').read_text().splitlines()]
bans={q for q,k in enumerate(repmap)if q and stats[keys.index(k)]==0}
assert len(bans)==660
d=Path(sys.argv[1])
with (d/'rule4').open('w')as f:
 for ps,ls,maxi in family(4):
  edge={(i,j)for i,p in enumerate(ps)for j,l in enumerate(ls)if (p|(l<<13))in P}
  a,b=next((a,b)for a in permutations(range(4))for b in permutations(range(4))if {1<<a[i]|1<<(4+b[j])for i,j in edge}==pos)
  mapping=[neg.index(sum(1<<a[i]for i,p in enumerate(ps)if p&x)|sum(1<<(4+b[j])for j,l in enumerate(ls)if l&y))for x,y in maxi]
  assert sorted(mapping)==list(range(10))
  print(*(int(sum(1<<v for j,v in enumerate(mapping)if s>>j&1)in bans)for s in range(1024)),file=f)
