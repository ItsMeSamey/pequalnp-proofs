#include <array>
#include <algorithm>
#include <bitset>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
using namespace std;
using B=bitset<245>;using V=vector<int>;using Table=vector<B>;using Profile=vector<B>;
using Choices=vector<Profile>;
struct Cycle{V p,l,pm,lm;};
Table pv(8192),lv(128);
vector<V> load(string f){ifstream in(f);string s;vector<V> out;while(getline(in,s)){istringstream a(s);V v;int i;while(a>>i)v.push_back(i);out.push_back(v);}return out;}
Choices prepare(const V& bank,const V& verts,const V& maxneg,const Table& tab){
 int S=0;for(int v:verts)S|=v;vector<V> opt(verts.size());for(int j=0;j<bank.size();j++)for(int t=0;t<verts.size();t++)if((bank[j]&S)==verts[t])opt[t].push_back(j);
 Choices out;V rep;auto go=[&](auto&& self,int t,unsigned used)->void{
 if(t<verts.size()){for(int j:opt[t]){rep.push_back(j);self(self,t+1,used|(1<<j));rep.pop_back();}return;}
 B base;base.set();for(int j=0;j<bank.size();j++)if((bank[j]&S)&&!(used>>j&1))base&=tab[bank[j]];
 if(base.none())return;Profile m;for(int q:maxneg){B b=base;for(int j=0;j<verts.size();j++)if(verts[j]&q)b&=tab[bank[rep[j]]];m.push_back(b);}
 for(auto &prior:out){bool dom=true;for(int i=0;i<m.size();i++)if((m[i]&~prior[i]).any()){dom=false;break;}if(dom)return;}
 out.push_back(m);};go(go,0,0);return out;}
#include <unordered_map>
#include <cstdint>
using Key=string;
using Bits=vector<uint64_t>;
struct Group{Profile v;vector<int> labels;};
struct Rule{Cycle c;int t;array<uint8_t,1024> forbidden{};vector<Group> groups;unordered_map<Key,Bits> cache;};
Key key(const Profile&p){return string(reinterpret_cast<const char*>(p.data()),p.size()*sizeof(B));}
bool hits(const Profile&p,const Profile&l,const Rule&r){
 if(r.t==4){unsigned mask=0;for(unsigned j=0;j<p.size();j++)if((p[j]&l[j]).any())mask|=1<<j;return r.forbidden[mask];}
 bool mono=false;
 for(unsigned j=0;j<p.size();j++){bool a=(p[j]&l[j]).any();if(r.t==3&&(!r.c.pm[j]||!r.c.lm[j]))mono|=a;else if(!a)return false;}
 return r.t!=3||mono;
}
int main(int argc,char**argv){
 ios::sync_with_stdio(false);
 auto N=load("neg"),L=load("lines9");
 for(int j=0;j<(int)N.size();j++){int x=N[j][0];for(int m=0;m<8192;m++)if(x&m)pv[m].set(j);for(int m=0;m<128;m++)if((x>>13)&m)lv[m].set(j);}
 const int W=(L.size()+63)/64;vector<V> banks;
 ifstream stream("points");string row;int begin=argc>1?atoi(argv[1]):0,end=argc>2?atoi(argv[2]):1000000000;
 for(int id=0;getline(stream,row);id++){if(id<begin)continue;if(id>=end)break;istringstream s(row);int x;s>>x;V v;while(s>>x)v.push_back(x);banks.push_back(move(v));}
 vector<Bits> live(banks.size(),Bits(W,~0ull));for(auto&b:live)if(L.size()%64)b.back()=(1ull<<(L.size()%64))-1;
 vector<char> active(banks.size(),1);
 ifstream mapping("../rule4");if(!mapping)return 3;
 for(int t:{3,4})for(auto&v:load("cycles"+to_string(t))){
  if(none_of(active.begin(),active.end(),[](char x){return x;}))break;
  Rule r;r.t=t;if(t==4)for(auto&q:r.forbidden){int a;mapping>>a;q=a;}
  for(int j=0;j<t;j++){r.c.p.push_back(v[j]);r.c.l.push_back(v[t+j]);}
  for(int j=2*t+1;j<(int)v.size();j+=2){r.c.pm.push_back(v[j]);r.c.lm.push_back(v[j+1]);}
  unordered_map<Key,int> groups;
  for(int i=0;i<(int)L.size();i++)for(auto&p:prepare(L[i],r.c.l,r.c.lm,lv)){
   auto [it,fresh]=groups.emplace(key(p),groups.size());if(fresh)r.groups.push_back({p,{}});
   r.groups[it->second].labels.push_back(i);
  }
  groups.clear();
  for(int id=0;id<(int)banks.size();id++)if(active[id]){
   for(auto&p:prepare(banks[id],r.c.p,r.c.pm,pv)){
    Key k=key(p);if(r.cache.size()>=2048)r.cache.clear();
    auto [it,fresh]=r.cache.try_emplace(k);auto&gone=it->second;
    if(fresh){gone.assign(W,0);for(auto&g:r.groups)if(hits(p,g.v,r))for(int j:g.labels)gone[j/64]|=1ull<<(j%64);}
    for(int j=0;j<W;j++)live[id][j]&=~gone[j];
   }
   active[id]=any_of(live[id].begin(),live[id].end(),[](uint64_t x){return x;});
  }
 }
 uint64_t left=0;
 for(int i=0;i<(int)banks.size();i++)for(int j=0;j<W;j++)for(auto x=live[i][j];x;x&=x-1){cout<<(begin+i)<<' '<<(64*j+__builtin_ctzll(x))<<'\n';left++;}
 cerr<<"DONE "<<banks.size()*uint64_t(L.size())<<' '<<left<<endl;
}
