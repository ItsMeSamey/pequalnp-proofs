#include "pair-bipartite.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <numeric>
using namespace std;
using namespace ordered_regions_pair;
using Bank=array<int,13>;using TB=array<uint64_t,5>;
struct Node{
 int a,b,l=-1,r=-1;Side side;
 Node(int low,int high,Side x):a(low),b(high),side(move(x)){}
};
struct Study{
 vector<Bank> points;vector<array<int,9>> ls;vector<int>lid,roots;vector<Node>tree;
 array<TB,8192> table{};vector<int>pos,neg;array<TB,128> lineTable{};
 uint64_t attempts=0,excluded=0,passing=0,nodes=0;
 Side project(const vector<TB>&x){
  array<Mask,28>p{};array<Mask,245>n{};
  for(int j=0;j<int(x.size());j++){for(int i=0;i<28;i++)p[i]|=((x[j][0]>>i)&1)<<j;for(int i=0;i<245;i++)n[i]|=((x[j][1+i/64]>>(i%64))&1)<<j;}
  return Side(x.size(),p,n);
 }
 template<class Banks,class Table>
 Side aggregate(const Banks&banks,const Table&tab,int lo,int hi){
  int w=banks[lo].size();vector<TB>x(w);for(int j=0;j<w;j++)x[j]=tab[banks[lo][j]];
  for(int i=lo+1;i<hi;i++)for(int j=0;j<w;j++){auto&q=tab[banks[i][j]];x[j][0]|=q[0];for(int k=1;k<5;k++)x[j][k]&=q[k];}
  return project(x);
 }
 int build(int lo,int hi){
  int id=tree.size();tree.emplace_back(lo,hi,aggregate(ls,lineTable,lo,hi));
  if(hi-lo>1){int m=(lo+hi)/2;int l=build(lo,m),r=build(m,hi);tree[id].l=l;tree[id].r=r;}return id;
 }
 void scan(int lo,int hi,int node,int chunk){
  nodes++;auto point=aggregate(points,table,lo,hi);
  auto recurse=[&](auto&&self,int nd)->void{
   auto&line=tree[nd];attempts++;
   if(!check(point,line.side,2,150).possible){excluded+=uint64_t(hi-lo)*(line.b-line.a);return;}
   if(hi-lo==1 && line.b-line.a==1){cout<<lo<<' '<<lid[line.a]<<'\n';passing++;return;}
   if(line.b-line.a>1 && ((hi-lo<=chunk)|| double(line.b-line.a)>0.09*(hi-lo))){
    self(self,line.l);self(self,line.r);
   }else if(hi-lo>1){
    int m=(lo+hi)/2;scan(lo,m,nd,chunk);scan(m,hi,nd,chunk);
   }else{self(self,line.l);self(self,line.r);}
  };
  recurse(recurse,node);
 }
};
int main(int argc,char**argv){
 if(argc!=8)return 1;Study s;ifstream f(argv[1]);int pn,nn;f>>pn>>nn;if(pn!=28||nn!=245)return 2;
 s.pos.resize(pn);s.neg.resize(nn);for(int&x:s.pos)f>>x;for(int&x:s.neg)f>>x;
 for(int m=0;m<8192;m++){for(int i=0;i<pn;i++)if(s.pos[i]&m)s.table[m][0]|=1ull<<i;
 for(int i=0;i<nn;i++)if(s.neg[i]&m)s.table[m][1+i/64]|=1ull<<(i%64);}
 for(int m=0;m<128;m++){for(int i=0;i<pn;i++)if((s.pos[i]>>13)&m)s.lineTable[m][0]|=1ull<<i;
 for(int i=0;i<nn;i++)if((s.neg[i]>>13)&m)s.lineTable[m][1+i/64]|=1ull<<(i%64);}
 ifstream pf(argv[2]);int dummy;Bank bank;while(pf>>dummy){for(int&x:bank)pf>>x;s.points.push_back(bank);}
 ifstream lf(argv[3]);vector<pair<array<int,9>,int>> rows;array<int,9>b{};int num=0;
 while(lf>>b[0]){for(int j=1;j<9;j++)lf>>b[j];vector<int> extras(b.begin(),b.end());for(int j=0;j<7;j++){
   auto it=find(extras.begin(),extras.end(),1<<j);if(it==extras.end())return 5;extras.erase(it);b[j]=1<<j;}
  b[7]=extras[0];b[8]=extras[1];rows.emplace_back(b,num++);}
 sort(rows.begin(),rows.end());for(auto&[l,i]:rows){s.ls.push_back(l);s.lid.push_back(i);}
 for(int i=0;i<num;){int j=i+1;while(j<num&&s.ls[j][7]==s.ls[i][7])j++;s.roots.push_back(s.build(i,j));i=j;}
 int lo=stoi(argv[4]),hi=min(stoi(argv[5]),int(s.points.size())),size=stoi(argv[6]),chunk=stoi(argv[7]);
 for(int i=lo;i<hi;i+=size)for(auto n:s.roots)s.scan(i,min(i+size,hi),n,chunk);
 if(s.excluded+s.passing!=uint64_t(hi-lo)*num)return 3;
 cerr<<"DONE "<<s.passing+s.excluded<<' '<<s.attempts<<' '<<s.nodes<<' '<<s.passing<<endl;
}
