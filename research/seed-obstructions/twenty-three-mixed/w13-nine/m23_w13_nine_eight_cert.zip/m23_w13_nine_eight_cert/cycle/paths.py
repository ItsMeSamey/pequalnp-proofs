from pathlib import Path
from itertools import combinations,permutations
import sys
src=Path(__file__).resolve().parent
near=src
sys.path.insert(0,str(src))
from cycles import P,rawp,rawl
data=list(map(int,(near/'cycle8.in').read_text().split()))
edges=set(data[5:12]);ns=data[12:]
keys=list(map(int,(near/'path8-pilot.map').read_text().split()))
stats=[int(q.split()[2])for q in (near/'path8-pilot.out').read_text().splitlines()]
hard=[x for x,y in zip(keys,stats) if not y]
out=Path(sys.argv[1]);out.mkdir(exist_ok=True)
table=' '.join(str(int(any(not(q&~m)for q in hard)))for m in range(1024))+'\n'
n=0
with (out/'paths').open('w')as f,(out/'rules').open('w')as u:
 for L in combinations(rawl,4):
  lm=sum(L)
  for ps in combinations(rawp,4):
   e={(i,j)for i,p in enumerate(ps)for j,l in enumerate(L)if p|(l<<13) in P}
   if len(e)!=7: continue
   ds=[sum((i,j)in e for j in range(4))for i in range(4)]
   dl=[sum((i,j)in e for i in range(4))for j in range(4)]
   if sorted(ds)!=[1,2,2,2] or sorted(dl)!=[1,2,2,2]:continue
   p0=ds.index(1);l0=dl.index(1);found=False
   for a in permutations(range(4)):
    if a[p0]:continue
    for b in permutations(range(4)):
     if b[l0] or {1<<a[i]|(16<<b[j])for i,j in e}!=edges:continue
     found=True
     marks=[(sum(p for i,p in enumerate(ps)if v>>a[i]&1),sum(l for j,l in enumerate(L)if v>>(4+b[j])&1))for v in ns]
     print(*ps,*L,10,*(t for pair in marks for t in pair),file=f);u.write(table);n+=1
     five=[44,52,73,104,147]
     marks=[(sum(p for i,p in enumerate(ps)if v>>a[i]&1),sum(l for j,l in enumerate(L)if v>>(4+b[j])&1))for v in five]
     print(*ps,*L,5,*(t for pair in marks for t in pair),file=f)
     u.write(' '.join(str(int(m&31==31))for m in range(1024))+'\n')
   if found:pass
assert n==264,n
print(n,len(hard))
