"""Replay the W13-minus-cheaper-orbits, L9-two-paid, k=2 terminal exclusion."""
from pathlib import Path
import sys,tempfile,gzip,subprocess as sp,shutil
root=Path(__file__).resolve().parent
lo,hi=map(int,sys.argv[1:]) if len(sys.argv)==3 else (0,420948)
assert 0<=lo<hi<=420948
import zipfile
with zipfile.ZipFile(root/'dependencies/W13L9-eight.zip') as upstream:
 assert (root/'new8.gz').read_bytes()==upstream.read('eight/new8.gz')
def compile_native(src,out):
 sp.run(['c++','-O3','-std=c++20',root/src,'-o',out],check=True)
def read_rows(f):return [tuple(map(int,s.split()))for s in f.read_text().splitlines()]
with tempfile.TemporaryDirectory() as tmp:
 w=Path(tmp);d=w/'g8';d.mkdir()
 bank=d/'pointbank';table=d/'points'
 with gzip.open(root/'new8.gz','rt') as inp,bank.open('w')as raw,table.open('w')as tagged:
  for i,row in enumerate(inp):
   if lo<=i<hi:raw.write(row);tagged.write('0 '+row)
 assert i==420947
 for src,out in [('allocated.cpp','alloc'),('alloc_cohort.cpp','cohort'),('group_alloc.cpp','grouped'),('allocated_cycles.cpp','screen'),('check-pair.cpp','ord'),('endpoint24.cpp','end')]:compile_native(src,w/out)
 for n in ('cycles3','cycles4','neg'):shutil.copy(root/'cycle'/n,d/n)
 shutil.copy(root/'cycle/rule4',w/'rule4');shutil.copy(root/'lines9',d/'lines9')
 with bank.open()as inp,(d/'alloc8').open('w')as out:sp.run([w/'alloc',root/'samples'],stdin=inp,stdout=out,check=True)
 lines=read_rows(d/'lines9')
 from itertools import combinations_with_replacement
 raw=tuple(1<<i for i in range(7))
 def outputs(values):
  return {v for a,b in combinations_with_replacement(values,2) for v in (a&b,a|b)}
 physical={tuple(sorted((*raw,a,b)))for a in outputs(raw)for b in outputs((*raw,a))}
 assert len(physical)==len(lines)==540 and set(lines)==physical
 rows=list(map(int,(root/'samples').read_text().split()))
 for begin in range(lo,hi,8192):
  stop=min(hi,begin+8192);a=begin-lo;b=stop-lo
  orig=[]
  with bank.open()as inp:
   from itertools import islice
   orig=[tuple(map(int,row.split()))for row in islice(inp,a,b)]
  if begin<16384:
   pre=sp.run([w/'screen',str(a),str(b)],cwd=d,text=True,capture_output=True,check=True)
   local=''.join(f'{int(i)-a} {j}\n'for i,j in (r.split()for r in pre.stdout.splitlines()))
   frag=d/'fragment';frag.write_text(''.join(' '.join(map(str,v))+'\n' for v in orig))
   chk=sp.run([w/'ord',root/'samples',frag,d/'lines9','13','9','2','2000'],input=local,text=True,capture_output=True,check=True)
   keep=[(int(i),int(j))for i,j in(r.split()for r in chk.stdout.splitlines())]
  else:
   engine='grouped' if (196608<=begin<245760 or begin>=286720) else 'cohort'
   chk=sp.run([w/engine,root/'samples',table,d/'lines9',str(a),str(b),'128',d/'alloc8'],text=True,capture_output=True,check=True)
   keep=[(int(i)-a,int(j))for i,j in(r.split()for r in chk.stdout.splitlines())]
  for i,j in keep:
   ms=orig[i]+tuple(v<<13 for v in lines[j])
   vals=rows[:2]+[sum(1<<k for k,v in enumerate(ms) if v&x)for x in rows[2:]]
   run=sp.run([w/'end','13','9','2'],input=' '.join(map(str,vals))+'\n',capture_output=True,text=True,check=True)
   if run.stdout.split()[0]!='0':raise RuntimeError((begin+i,j,run.stdout))
  print(begin,stop,'pairs',(stop-begin)*540,'last finite checks',len(keep),'survivors',0,flush=True)
