from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess as sp,sys
root=Path(__file__).resolve().parent;c=root/'cycle'
with TemporaryDirectory() as folder:
 d=Path(folder)
 sp.run(['c++','-O3','-std=c++20',c/'small.cpp','-o',d/'small'],check=True)
 for a,b in [('rep4k2.in','rep4k2-safe.out'),('path8-pilot.in','path8-pilot.out')]:
  ret=sp.run([d/'small'],input=(c/a).read_text(),text=True,capture_output=True,check=True)
  assert [v.split()[:3]for v in ret.stdout.splitlines()]==[v.split()[:3]for v in (c/b).read_text().splitlines()]
 ret=sp.run([d/'small'],input=(c/'path8-min.in').read_text(),text=True,capture_output=True,check=True)
 assert ret.stdout.split()[:3]==['8','2','0']
 sp.run([sys.executable,c/'cycles_only.py',d],check=True)
 sp.run([sys.executable,c/'paths.py',d],check=True)
 assert (d/'rule4').read_bytes()+(d/'rules').read_bytes()==(c/'rule4').read_bytes()
 assert ''.join((c/'cycles4').read_text().splitlines(True)[33:])==(d/'paths').read_text()
 print('Eight-vertex tables agree.')
