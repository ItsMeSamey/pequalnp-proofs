#include "pair-bipartite.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <numeric>
using namespace std;
using namespace ordered_regions_pair;
using Bank=array<int,13>;
using TB=array<uint64_t,5>;
struct Scan{
 using U=unsigned __int128; vector<U> alloc; vector<int> extra; vector<int>ids; vector<Bank> points;vector<Side> lines;array<TB,8192> table{};
 unsigned long long tries=0,cut=0,pass=0,nodes=0;
 void scan(int lo,int hi,const vector<int>&active){
  nodes++; U allowed=0;for(int ix=lo;ix<hi;ix++)allowed|=alloc[ix];if(!allowed)return;array<TB,13> x{};
  for(int j=0;j<13;j++)x[j]=table[points[lo][j]];
  for(int i=lo+1;i<hi;i++)for(int j=0;j<13;j++){auto&v=table[points[i][j]];x[j][0]|=v[0];for(int k=1;k<5;k++)x[j][k]&=v[k];}
  array<Mask,28> p{};array<Mask,245> n{};
  for(int j=0;j<13;j++){for(int i=0;i<28;i++)p[i]|=((x[j][0]>>i)&1)<<j;for(int i=0;i<245;i++)n[i]|=((x[j][1+i/64]>>(i%64))&1)<<j;}
  vector<int> keep;
  {Side side(13,p,n);for(int l:active){if(!(allowed>>extra[l]&1))continue;tries++;if(check(side,lines[l],2,500).possible)keep.push_back(l);}}
  cut+=(hi-lo)*(active.size()-keep.size());
  if(keep.empty())return;
  if(hi-lo==1){for(auto j:keep)cout<<ids.at(lo)<<' '<<j<<'\n';pass+=keep.size();return;}
  int mid=(lo+hi)/2;scan(lo,mid,keep);scan(mid,hi,keep);
 }
};
int main(int argc,char**argv){
 if(argc!=8)return 1;Scan s;ifstream f(argv[1]);int pn,nn;f>>pn>>nn;if(pn!=28||nn!=245)return 2;
 vector<int> pos(28),neg(245);for(int&x:pos)f>>x;for(int&x:neg)f>>x;
 for(int m=0;m<8192;m++){for(int q=0;q<28;q++)if(m&pos[q])s.table[m][0]|=1ull<<q;for(int q=0;q<245;q++)if(m&neg[q])s.table[m][1+q/64]|=1ull<<(q%64);}
 ifstream pf(argv[2]);int dummy;Bank b{};while(pf>>dummy){for(int&x:b)pf>>x;s.points.push_back(b);}
 ifstream lf(argv[3]);vector<int> l(9);while(lf>>l[0]){for(int j=1;j<9;j++)lf>>l[j];auto tmp=l;for(int j=0;j<7;j++){auto it=find(tmp.begin(),tmp.end(),1<<j);if(it==tmp.end())return 4;tmp.erase(it);}s.extra.push_back(tmp[0]|tmp[1]);vector<Mask>p,n;
  auto mask=[&l](int x){Mask r=0;for(int j=0;j<9;j++)if(l[j]&(x>>13))r|=1<<j;return r;};
  for(int x:pos)p.push_back(mask(x));for(int x:neg)n.push_back(mask(x));s.lines.emplace_back(9,p,n);}
 vector<int> active(s.lines.size());iota(active.begin(),active.end(),0);int lo=stoi(argv[4]),hi=min(stoi(argv[5]),(int)s.points.size()),chunk=stoi(argv[6]);
 ifstream fa(argv[7]);unsigned long long aa,bb;while(fa>>aa>>bb)s.alloc.push_back(aa|Scan::U(bb)<<64);if(hi>(int)s.alloc.size())return 5;unsigned long long candidates=0;for(int i=lo;i<hi;i++)for(int e:s.extra)candidates+=(s.alloc[i]>>e)&1;
 vector<int> order(hi-lo);
 iota(order.begin(),order.end(),lo);
 stable_sort(order.begin(),order.end(),[&](int a,int b){return s.alloc[a]<s.alloc[b];});
 auto original=move(s.points);auto originalAlloc=move(s.alloc);
 for(int id:order){s.ids.push_back(id);s.points.push_back(original[id]);s.alloc.push_back(originalAlloc[id]);}
 for(int a=0;a<(int)order.size();){
  int b=a+1;while(b<order.size() && s.alloc[b]==s.alloc[a])b++;
  vector<int> permitted;for(int ix:active)if(s.alloc[a]>>s.extra[ix]&1)permitted.push_back(ix);
  for(int ix=a;ix<b;ix+=chunk)s.scan(ix,min(ix+chunk,b),permitted);
  a=b;
 }

 
 cerr<<"DONE "<<candidates<<' '<<s.tries<<' '<<s.nodes<<' '<<s.pass<<endl;
}
