#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
int main(int argc,char**argv){
 if(argc!=3)return 2;int w=stoi(argv[1]);ifstream tab(argv[2]);vector<array<int,128>> acts;array<int,128>g;
 while(tab>>g[0]){for(int i=1;i<128;i++)tab>>g[i];acts.push_back(g);}
 array<int,12>b{},c{};while(cin>>b[0]){for(int i=1;i<w;i++)cin>>b[i];bool good=true;
 for(const auto&f:acts){for(int j=0;j<w;j++)c[j]=f[b[j]];sort(c.begin(),c.begin()+w);if(c<b){good=false;break;}}
 if(good){for(int j=0;j<w;j++)cout<<b[j]<<' ';cout<<'\n';}}
}
