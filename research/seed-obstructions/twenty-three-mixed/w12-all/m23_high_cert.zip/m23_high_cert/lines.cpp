#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <vector>
using namespace std;
using Key=uint64_t;
int main(int argc,char**argv){
 if(argc!=4)return 2;
 int g=stoi(argv[1]),w=stoi(argv[2]);ifstream sample(argv[3]);int np,nn;sample>>np>>nn;
 vector<int>pos(np),neg(nn);for(int&x:pos)sample>>x;for(int&x:neg)sample>>x;
 array<vector<int>,7> forbidden;
 for(int i=0;i<7;i++){
  unordered_set<int> masks;
  for(int p:pos)if(p>>(13+i)&1)for(int n:neg)if(!((p&8191)&~n)&&!(n>>(13+i)&1))masks.insert(n>>13);
  for(int m:masks)if(none_of(masks.begin(),masks.end(),[&](int n){return m!=n&&!(m&~n);}))forbidden[i].push_back(m);
 }
 unordered_set<Key> states{0},result;
 for(int d=0;d<g;d++){
  unordered_set<Key> next;
  for(auto st:states){
   array<int,12> v{};for(int j=0;j<7;j++)v[j]=1<<j;
   for(int j=0;j<d;j++)v[7+j]=st>>(7*j)&127;
   bool opt[128]{};
   for(int i=0;i<7+d;i++)for(int j=i;j<7+d;j++){opt[v[i]|v[j]]=true;opt[v[i]&v[j]]=true;}
   for(int a=0;a<128;a++)if(opt[a]){
    int k=0;while(k<d && v[7+k]<=a)++k;
    auto low=(Key(1)<<(7*k))-1;next.insert((st&low)|(Key(a)<<(7*k))|((st&~low)<<7));
   }
  }
  states.swap(next);cerr<<"depth "<<d+1<<" states "<<states.size()<<endl;
 }
 vector<int> subsets;for(int b=0;b<(1<<(7+g));b++)if(popcount((unsigned)b)==w)subsets.push_back(b);
 for(Key st:states){
  array<int,12> v;for(int i=0;i<7;i++)v[i]=1<<i;for(int i=0;i<g;i++)v[7+i]=st>>(7*i)&127;
  for(int b:subsets){
   int r=b&127,t=0;array<int,5>extra{};
   for(int i=0;i<g;i++)if(b>>(7+i)&1){int x=v[7+i];if(has_single_bit((unsigned)x)&&!(r&x))r|=x;else extra[t++]=x;}
   bool good=true;
   for(int j=0;j<7&&good;j++)if(!(r>>j&1))for(int n:forbidden[j]){
    bool hit=false;for(int i=0;i<t;i++)hit|=(extra[i]>>j&1)&&!(extra[i]&n);
    if(!hit){good=false;break;}
   }
   if(good){Key key=r;for(int i=0;i<t;i++)key|=Key(extra[i])<<(7*(i+1));result.insert(key);}
  }
 }
 vector<Key>out(result.begin(),result.end());sort(out.begin(),out.end());
 for(Key key:out){int r=key&127;array<int,12> row{};int t=0;for(int j=0;j<7;j++)if(r>>j&1)row[t++]=1<<j;for(int i=0;t<w;i++)row[t++]=(key>>(7*(i+1)))&127;sort(row.begin(),row.begin()+w);for(int i=0;i<w;i++)cout<<row[i]<<' ';cout<<'\n';}
 cerr<<"LINE "<<g<<" width "<<w<<" covers "<<out.size()<<endl;
}
