# Twelve point wires, at least ten line wires, and 23 mixed gates

The residual cap of 33 leaves ten gates for point and line preprocessing. The twelve-point census gives minimum point price five and, through seven paid point gates, 2, 5, and 25 new point-bank orbits at prices five, six, and seven. Physical line width W costs at least W−7 paid line gates. Widths thirteen and higher therefore exceed the total budget. Width twelve forces five paid gates on both sides. All seven raw lines must occur. The bundled earlier read-once SAT check allows any five additional line signatures and excludes both price-five point orbits.

Widths ten and eleven leave two and one surplus mixed input uses respectively. For width ten at point prices five through seven, enumerate physical line programs of depth at most five, four, and three. At width eleven only point prices five and six remain, allowing five and four line gates respectively. Here depth in the enumerator counts sequential straight-line instructions, regardless of parallel depth.

A state is the sorted multiset of singleton signatures of all line gates constructed so far. The seven raw singleton labels are available separately. Applying either union or intersection to every pair of previously available physical signals generates all possible next singleton signatures. Retain duplicate and zero results. Two states with the same multiset have identical future choices, including the set of physical cut positions that can be selected at the end. Reusing the same operand in a gate is granted. Any shorter program extends to the exact budget by adjoining unused gates. At the final stage choose every subset of W physical positions among the seven raw and all paid positions. Drop a multiset only when some residual positive and negative ordered on raw points cannot be distinguished on lines either. For each positive line label it suffices to check the maximal negative raw line sets in this test. The resulting line-candidate counts are as follows.

| Line wires | Line gate budget | Covering multisets |
| --- | --- | --- |
| 10 | 3 | 8,275 |
| 10 | 4 | 46,650 |
| 10 | 5 | 137,873 |
| 11 | 4 | 113,380 |
| 11 | 5 | 847,878 |

For each point bank retain the least paid price realized by any representative of its orbit under the 24 simultaneous sample symmetries. The stabilizer of the selected representative acts on line multisets, and the line gate budget is invariant under permutations of raw line atoms. Take the lexicographically least line multiset in each stabilizer orbit.

On every positive sample, the singleton OR for a boundary signal agrees with the actual signal. On each negative sample it is bounded above by the actual value. Testing a monotone suffix on these optimistic tables covers every physical realization of the fixed banks. The ordered-region test in ordered-regions.md grants pure or mixed repeated sources, additional fanout, and zero or duplicate signatures. Exhausting the 500-node search budget retains the case. A zero survivor count rules out every mixed suffix at the applicable surplus.

Run `python verify.py` with Python 3, Python-SAT (for the twelve-line replay), and a C++20 compiler. For one configuration supply a width and point-price pair, such as `python verify.py 10-7`. The script regenerates the five physical line domains, quotients them with every point stabilizer, and checks the mixed cuts. The dependencies directory includes the point-census package and full twelve-line SAT proof.
