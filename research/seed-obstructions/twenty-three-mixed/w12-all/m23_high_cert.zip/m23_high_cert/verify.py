"""Regenerate all physically affordable line programs and test their joint cut signatures."""
from pathlib import Path
from collections import defaultdict,Counter
from subprocess import run
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import sys
from sample import pos,neg,move,symmetries

root=Path(__file__).resolve().parent
def write(path,rows):
 with path.open('w') as f:
  for row in rows:print(*row,file=f)
def compile(d,name,source):
 run(['c++','-std=c++20','-O3','-march=native',root/source,'-o',d/name],check=True)
def main():
 group=symmetries();points=defaultdict(list);seen=set()
 families=[tuple(map(int,row.split()))for row in (root/'banks-through-eight.txt').read_text().splitlines()]
 for row in sorted(families,key=lambda r:(r[-1],r[:-1])):
  bank,price=row[:-1],row[-1]
  if price>7 or bank in seen:continue
  seen.update(tuple(sorted(move(m,p)for m in bank))for p,l in group)
  points[price].append(bank)
 assert list(map(lambda g:len(points[g]),(5,6,7)))==[2,5,25]
 with TemporaryDirectory()as t:
  d=Path(t)
  for name,src in [('lines','lines.cpp'),('quotient','quotient.cpp'),('order','check-pair.cpp')]:compile(d,name,src)
  write(d/'samples',[(28,245),sorted(pos),sorted(neg)])
  for width,g in ((10,7),(10,6),(10,5),(11,6),(11,5)):
   if len(sys.argv)>1 and f'{width}-{g}' not in sys.argv[1:]:continue
   with (d/'full').open('w')as out:
    run([d/'lines',str(10-g),str(width),d/'samples'],stdout=out,check=True)
   tested=kept=exhausted=0
   for bank in points[g]:
    stab=[l for p,l in group if tuple(sorted(move(m,p)for m in bank))==bank]
    write(d/'point',[bank]);write(d/'stab',stab)
    with (d/'full').open()as raw,(d/'reps').open('w')as out:
     run([d/'quotient',str(width),d/'stab'],stdin=raw,stdout=out,check=True)
    with (d/'reps').open()as src:n=sum(1 for row in src)
    write(d/'ids',((0,j)for j in range(n)))
    with (d/'ids').open()as inp,(d/'survivors').open('w')as out:
     z=run([d/'order',d/'samples',d/'point',d/'reps','12',str(width),str(12-width),'500'],stdin=inp,stdout=out,stderr=-1,text=True,check=True)
    a,b,c=map(int,z.stderr.splitlines()[-1].split()[1:]);assert a==n
    tested+=a;kept+=b;exhausted+=c
    if b:raise RuntimeError((width,g,bank,b,'ordered survivors'))
   print(width,g,tested,kept,exhausted,flush=True)
  if len(sys.argv)==1 or '12-5' in sys.argv[1:]:
   with ZipFile(root/'dependencies/twenty-two-eleven-line.zip')as z:z.extractall(d)
   run([sys.executable,d/'twenty-two-eleven-line'/'verify23.py'],check=True)
if __name__=='__main__':main()
