from collections import Counter
from pathlib import Path
from subprocess import run
from tempfile import TemporaryDirectory
import sys
from inputs import P,N,stars
from samples import actions
root=Path(__file__).resolve().parent
ESET=(15,23,27,46,83)
def parse(t):return [tuple(map(int,r.split()))for r in t.splitlines()]
def records():
 out={8:set(),9:set(),10:set()}
 for b,program,kmax in ((8,'outside.py',3),(9,'virtual_outside9.py',2)):
  for e in ESET:
   frozen=parse((root/'recorded'/(f'out8-{e}-3' if b==8 else f'direct9-{e}')).read_text())
   if '--regenerate' in sys.argv:
    for k in range(kmax+1):
     x=run([sys.executable,root/program,str(e),str(k),*(['exact']if k==kmax else [])],capture_output=True,text=True,check=True)
     assert set(parse(x.stdout))==(set(frozen)if k==kmax else set())
   out[b].update((e,tuple(sorted(bank)))for bank in frozen)
 frozen=parse((root/'recorded/literal10').read_text())
 if '--regenerate' in sys.argv:
  z=run([sys.executable,root/'literal.py',*map(str,ESET)],capture_output=True,text=True,check=True)
  assert set(parse(z.stdout))==set(frozen)
 for e,n,*b in frozen:
  assert n==len(b)==10 and len(set(b+[t for i,t in enumerate(stars)if not(e>>i&1)])-{0})==13
  out[10].add((e,tuple(sorted(b))))
 return out
def project(e,fs):
 fix=[v for j,v in enumerate(stars)if not e>>j&1];ls=[1<<j for j in range(7)if e>>j&1]
 def value(r):return sum(bool((r>>13)&m)<<i for i,m in enumerate(ls))|sum(bool((r&8191)&m)<<(i+4)for i,m in enumerate(fs))
 positives={value(r)for r in P if r>>13&e}
 negatives={value(r)for r in N if all(r&t for t in fix)}
 ps=sorted(p for p in positives if all(q==p or q&~p for q in positives))
 ns=sorted(n for n in negatives if all(q==n or n&~q for q in negatives))
 w=4+len(fs);assert all(any(p&~n==1<<j for p in ps for n in ns)for j in range(w))
 return ' '.join(map(str,(w,w,len(ps),len(ns),*ps,*ns)))
def main():
 rs=records()
 assert [len(rs[b])for b in(8,9,10)]==[2,24,45]
 gs=actions(P,N)
 with TemporaryDirectory()as t:
  exe=Path(t)/'frontier';run(['c++','-std=c++20','-O3','-march=native',root/'frontier.cpp','-o',exe],check=True)
  for b in (8,9,10):
   assert all(len(s)==b and len(set(s))==b and 0 not in s for e,s in rs[b])
   def canonical(e,fs):
    return min((sum(1<<stars.index(g[t])for j,t in enumerate(stars)if e>>j&1),tuple(sorted(g[m]for m in fs)))for g in gs)
   unique={canonical(e,fs)for e,fs in rs[b]}
   counts=Counter()
   for e,fs in sorted(unique):
    p=project(e,fs);z=run([exe],input=p,text=True,capture_output=True,check=True)
    gate,live=map(int,z.stdout.split());assert live==0 and 0<gate<b+3
    counts[gate]+=1
   print('outside width',b,'labelled',len(rs[b]),'orbits',len(unique),'extinct by gate',sorted(counts.items()),flush=True)
if __name__=='__main__':main()
