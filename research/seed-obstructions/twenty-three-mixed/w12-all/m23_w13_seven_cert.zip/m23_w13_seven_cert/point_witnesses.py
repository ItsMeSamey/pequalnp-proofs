"""Find elementary OR programs confirming that some width-ten outside banks are physical."""
from itertools import combinations,product
from inputs import P,N,stars
from samples import actions
from instance import raw
from verify import records
G=actions(P,N);raw=set(raw)
def trees(t):
 atoms=[1<<j for j in range(13)if t>>j&1]
 out=set()
 for a,b in combinations(atoms,2):
  h=a|b;c,d=(s for s in atoms if s not in (a,b))
  for v in (h|c,h|d,c|d):out.add(tuple(sorted((h,v,t))))
 return sorted(out)
def witness(e,outside):
 fixed=[t for j,t in enumerate(stars)if not e>>j&1]
 for g in G:
  ts=[g[t]for t in fixed]
  bank={g[m]for m in outside}|set(ts);local=set(raw)
  for t in ts:local.update(v for v in range(1,t+1)if not v&~t)
  missing=bank-local
  if len(missing)>1:continue
  choices=[]
  for t in ts:
   need={x for x in bank-raw if not x&~t}
   choices.append([a for a in trees(t)if need<=set(a)])
  for a,b,c in product(*choices):
   have=raw|set(a+b+c)
   if not missing or any(x|y==next(iter(missing))for x,y in combinations(have,2)):
    return True
 return False
if __name__=='__main__':
 r=records()[10];n=sum(witness(e,fs)for e,fs in r)
 print('price-ten OR construction for',n,'of',len(r),'labelled quartet assignments')
