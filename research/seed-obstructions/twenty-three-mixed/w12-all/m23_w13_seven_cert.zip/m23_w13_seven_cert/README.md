# Thirteen point wires and seven lines at 23 mixed gates

At most ten point gates remain. The seven forced singleton line signals can be replaced by raw lines, preserving positive values and lowering negatives. The four-surplus allocation theorem in four-surplus.md applies since point width plus point price is at most 23. It eliminates fewer than four promoted labels. With four promoted labels there is zero cofactor overhead. The three ordinary targets retain disjoint private AND-side guards exclusively in the root. Their complement has eight to ten outside point slots.

Each exclusive guard for ordinary target T accepts every T singleton when its formal cut inputs are pinned to zero. Monotonicity therefore makes it already true at every negative meeting T. On negatives meeting all three ordinary targets, every guard is simultaneously true. Replace each entire guard by one before changing any lines. These negatives are unchanged, and positives can only gain acceptance. Then set the three ordinary raw lines to zero. Special positives are unchanged and negative values can only decrease. All private point leaves occur below the guards just pinned. The remaining features are four special lines and b outside point signals. Replacing the latter by their singleton ORs preserves positive values and decreases negatives.

Deleting dead subgraphs and contracting paths cannot increase the undirected cycle rank. A connected binary cone on n inputs of surplus k has n−1+k gates, so the simplified suffix has at most four surplus uses. Each of its b+4 inputs has a positive and negative distinguished only by that input. Thus at least b+3 gates are required. The frontier grants both binary operations on every pair, including same-side operands.

The earlier quartet companion condition applies to every special incidence. Its outside features must distinguish all special-active negatives meeting one ordinary companion. Reconstructing the three private stars adds at most 13−b−3 gates, for an augmented budget of 20−b. Nine local gates are charged to those stars. Grant all their submasks and all 55 images of the raw primitives as base features. At most 11−b nonbase outputs are possible. At saturation the nonbase outputs have a construction order from this base and preceding nonbase masks. The bundled quartet certificate proves these point-only premises; its physical extra line is unused here. The charge depends on producing gates and distinct nonbase signatures, so a virtual duplicate source is permitted.

At b=8 and b=9 the SAT stage grants arbitrary nonbase masks below saturation and topologically generated masks at saturation. Every surviving outside support fills all b slots with distinct nonzero masks. At b=10 the three ordinary groups are singleton star features, and the 1,323 original point comparisons apply to the entire bank. All 45 labelled assignments then have thirteen distinct nonzero masks. The optional construction check verifies all 45 are attainable at point cost at most ten in some raw orientation, using three three-gate star OR trees and at most one other OR. The b=8 and b=9 assignments are relaxed outside models.

| Outside width | Labelled quartet and outside assignments | Geometry orbits | Essential inputs | Frontier empties at gates |
| --- | --- | --- | --- | --- |
| 8 | 2 | 2 | 12 | 9 |
| 9 | 24 | 10 | 13 | 8 or 10 |
| 10 | 45 | 15 | 14 | 8, 9, or 11 |

Every frontier empties before its inputs can be connected. The 24 width-nine assignments reproduce exactly the earlier W12 four-surplus projection. These results exclude the entire W13 allocation, including a virtually duplicated point input arising by unfolding a shared input of W12.

Run `python verify.py` to compile the C++20 frontier and test the 27 projected orbits. Add `--regenerate` to regenerate the recorded outside supports using Python-SAT with CaDiCaL. Run `python point_witnesses.py` to check outside-width-ten point constructibility. Earlier allocation, charge and frontier certificates are included under dependencies.
