#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace frontierlib {
using namespace std;
using Bits=uint64_t;
using Signature=array<Bits,6>; // positives, up to 245 negatives, ancestry side
using Family=array<int,12>;
using Frontier=array<int,24>; // zero entries are padding
template<class T> struct ArrayHash {
    size_t operator()(const T& values)const{
        size_t h=0x9e3779b97f4a7c15ULL;
        for(auto v:values){h^=v+0x9e3779b97f4a7c15ULL+(h<<6)+(h>>2);}
        return h;
    }
};
struct Wire{Signature value;};
inline std::set<std::vector<Signature>> failed_roots;
struct Search{
    std::vector<int> stage;
    int count_pos, count_neg, blocks;
    vector<Wire> wires{{}};
    unordered_map<Signature,int,ArrayHash<Signature>> ids;


    int intern(Signature sig){
        auto [entry,created]=ids.emplace(sig,wires.size());
        if(!created)return entry->second;
        Wire wire{sig};
        wires.push_back(move(wire));
        return entry->second;
    }
    bool one_cut(const Frontier&state,int size,const std::vector<int>&roles={}){
        using U=uint32_t; using Neg=array<uint64_t,4>;
        U all=(1u<<size)-1,point=0,line=0;
        array<U,64> pos{};array<Neg,24> truth{};
        for(int i=0;i<size;i++){auto&v=wires[state[i]].value;
            for(Bits q=v[0];q;q&=q-1)pos[__builtin_ctzll(q)]|=1u<<i;
            for(int k=0;k<blocks;k++)truth[i][k]=v[k+1];
            if(v[5]==1)point|=1u<<i;else if(v[5]==0)line|=1u<<i;
        }
        array<array<Neg,16>,6> lut{};int groups=(size+3)/4;
        for(int g=0;g<groups;g++){
            for(int b=0;b<blocks;b++)lut[g][0][b]=(b+1<blocks||count_neg%64==0)?~Bits(0):(Bits(1)<<(count_neg%64))-1;
            for(int t=1;t<(1<<min(4,size-4*g));t++)
                for(int b=0;b<blocks;b++)lut[g][t][b]=lut[g][t&(t-1)][b]&truth[4*g+__builtin_ctz(t)][b];
        }
        auto zero=[&](U mask){Neg r=lut[0][mask&15];for(int g=1;g<groups;g++){auto&a=lut[g][(mask>>(4*g))&15];for(int b=0;b<blocks;b++)r[b]&=a[b];}return r;};
        auto partial=[&](U one,U other){
            Bits forced=0;Neg neg{};
            for(int x=0;x<count_pos;x++){auto v=zero(pos[x]&(all^one));Bits any=0;for(int b=0;b<blocks;b++){neg[b]|=v[b];any|=v[b];}if(any)forced|=Bits(1)<<x;}
            for(Bits q=forced;q;q&=q-1){auto v=zero(pos[__builtin_ctzll(q)]&(all^other));for(int b=0;b<blocks;b++)if(v[b]&neg[b])return false;}
            return true;
        };
        array<Signature,24> mark{};
        for(int x=0;x<count_pos;x++)for(U q=pos[x];q;q&=q-1){
            int i=__builtin_ctz(q);auto v=zero(pos[x]^(1u<<i));Bits any=0;
            for(int b=0;b<blocks;b++){Bits a=v[b]&~truth[i][b];any|=a;mark[i][b+1]|=a;}if(any)mark[i][0]|=Bits(1)<<x;
        }
        U protected_mask=0;
        for(int i=0;i<size;i++) if(!roles.empty() && roles[i]){
            protected_mask|=1u<<i;
            for(int j=0;j<i;j++) if(roles[j]){
                bool same=(roles[i]-1)/2==(roles[j]-1)/2;
                if(!same && (mark[i][0]&mark[j][0]))return false;
                if(same)for(int k=1;k<=blocks;k++)if(mark[i][k]&mark[j][k])return false;
            }
        }
        array<U,24> adj{},must_and{},must_or{};
        for(int i=0;i<size;i++)for(int j=0;j<i;j++){
            bool a=!!(mark[i][0]&mark[j][0]),o=false;
            for(int k=1;k<=blocks;k++) o|=!!(mark[i][k]&mark[j][k]);
            if(!roles.empty()&&roles[i]&&roles[j]){
                bool same=(roles[i]-1)/2==(roles[j]-1)/2;
                a|=same;o|=!same;
            }
            auto connect=[&](auto& edges){edges[i]|=1u<<j;edges[j]|=1u<<i;};
            if(a)connect(must_and);if(o)connect(must_or);if(a&&o)connect(adj);
        }
        auto component=[&](const auto& edges,U mask){
            U front=mask&-mask,seen=front;
            while(front){U next=0;for(U t=front;t;t&=t-1)next|=edges[__builtin_ctz(t)];
                front=next&mask&~seen;seen|=front;}
            return seen;};
        auto compatible=[&](auto&& self,U mask)->bool{
            if(__builtin_popcount(mask)<3)return true;
            U part=component(must_and,mask);
            if(part==mask)part=component(must_or,mask);
            return part!=mask&&self(self,part)&&self(self,mask^part);
        };
        array<pair<U,U>,24> comps{};int n=0;U live=all;
        while(live){U a=live&-live,b=0,front=a;bool rev=false;
            while(front){U next=0;for(U z=front;z;z&=z-1)next|=adj[__builtin_ctz(z)];if(next&(rev?b:a))return false;next&=~(a|b);if(rev)a|=next;else b|=next;front=next;rev=!rev;}
            comps[n++]={a,b};live&=~(a|b);
        }
        // In the absence of any conflicting pair this necessary test can be skipped.
        
        sort(comps.begin(),comps.begin()+n,[](auto a,auto b){return __builtin_popcount(a.first|a.second)>__builtin_popcount(b.first|b.second);});
        auto rec=[&](auto&self,int i,U one,U other)->bool{
            if(one&protected_mask)return false;
            if(i==n && (!one||((one&(one-1))&&((one&point)==one||(one&line)==one))))return false;
            if(i&&(!partial(one,other)||!compatible(compatible,one)||!compatible(compatible,other)))return false;if(i==n)return true;
            auto [a,b]=comps[i];return self(self,i+1,one|a,other|b)||self(self,i+1,one|b,other|a);
        };
        return rec(rec,0,0,0);
    }
    bool treecut(const vector<int>&ps,const vector<int>&ns,int nleaves,int surplus=3,const std::vector<int>& types={},const std::vector<int>& roles={}){
        using U=uint32_t;using Neg=array<Bits,4>;
        using Node=pair<U,Signature>;
        count_pos=ps.size();count_neg=ns.size();blocks=(count_neg+63)/64;
        U all=(1u<<nleaves)-1;
        array<vector<Node>,25> layer;
        Frontier roots{};array<Signature,24> raw{};
        for(int i=0;i<nleaves;i++){
            for(int x=0;x<count_pos;x++)if(ps[x]>>i&1)raw[i][0]|=Bits(1)<<x;
            for(int y=0;y<count_neg;y++)if(ns[y]>>i&1)raw[i][1+y/64]|=Bits(1)<<(y%64);
            raw[i][5]=types.empty()?int(i>=7&&i<19):types[i];roots[i]=intern(raw[i]);
        }
        array<array<Neg,16>,6> tab{};int groups=(nleaves+3)/4;
        for(int g=0;g<groups;g++){
            for(int k=0;k<blocks;k++)tab[g][0][k]=(k+1<blocks || count_neg%64==0)?~Bits(0):(Bits(1)<<(count_neg%64))-1;
            for(int a=1;a<1<<min(4,nleaves-4*g);a++)for(int k=0;k<blocks;k++)
                tab[g][a][k]=tab[g][a&(a-1)][k]&raw[4*g+__builtin_ctz(a)][1+k];
        }
        array<Signature,24> personal{};
        for(int x=0;x<count_pos;x++)for(U bits=ps[x];bits;bits&=bits-1){
          int i=__builtin_ctz(bits);U m=ps[x]^(1u<<i);Neg n=tab[0][m&15];
          for(int g=1;g<groups;g++)for(int j=0;j<blocks;j++)n[j]&=tab[g][(m>>(4*g))&15][j];
          Bits any=0;for(int j=0;j<blocks;j++){n[j]&=~raw[i][1+j];any|=n[j];personal[i][1+j]|=n[j];}
          if(any)personal[i][0]|=Bits(1)<<x;
        }
        for(int i=0;i<nleaves;i++) if(!roles.empty()&&roles[i])for(int j=0;j<i;j++)if(roles[j]){
            bool same=(roles[i]-1)/2==(roles[j]-1)/2;
            if(!same && (personal[i][0]&personal[j][0]))return false;
            if(same)for(int k=1;k<=blocks;k++)if(personal[i][k]&personal[j][k])return false;
        }
        auto needed=[&](U inside){Signature q{};
            for(int x=0;x<count_pos;x++){U t=ps[x]&(all^inside);Neg n=tab[0][t&15];
                for(int g=1;g<groups;g++)for(int k=0;k<blocks;k++)n[k]&=tab[g][(t>>(4*g))&15][k];
                Bits any=0;for(int k=0;k<blocks;k++){q[1+k]|=n[k];any|=n[k];}if(any)q[0]|=Bits(1)<<x;
            }return q;};
        std::array<U,24> req_and{},req_or{};
        if(!surplus){
            for(int i=0;i<nleaves;i++)for(int j=0;j<i;j++){
                bool a=personal[i][0]&personal[j][0],o=false;
                for(int k=1;k<=blocks;k++)o|=bool(personal[i][k]&personal[j][k]);
                if(a&&o)return false;
                if(a){req_and[i]|=1u<<j;req_and[j]|=1u<<i;}
                if(o){req_or[i]|=1u<<j;req_or[j]|=1u<<i;}
            }
            auto component=[&](const auto& graph,U mask){
                U f=mask&-mask,r=f;
                while(f){U nx=0;for(U t=f;t;t&=t-1)nx|=graph[__builtin_ctz(t)];
                    f=nx&mask&~r;r|=f;}
                return r;
            };
            auto compatible=[&](auto&& self,U m)->bool{
                if(!(m&(m-1)))return true;
                U h=component(req_and,m);if(h==m)h=component(req_or,m);
                return h!=m&&self(self,h)&&self(self,m^h);
            };
            if(!compatible(compatible,all))return false;
        }
        U must=0,allowed=0;
        for(int i=0;i<nleaves;i++){if(stage.at(i)==0)must|=1u<<i;if(stage[i]<=0)allowed|=1u<<i;}
        auto outer=[&](U m,const Signature&z){
            if((m&must)!=must || (m&~allowed))return false;
            if(surplus==0){
                if(m!=all || z[0]!=((Bits(1)<<count_pos)-1))return false;
                for(int k=1;k<=blocks;k++)if(z[k])return false;
                return true;
            }
            Frontier f{};int n=0;for(U a=all^m;a;a&=a-1)f[n++]=roots[__builtin_ctz(a)];
            int d=intern(z);f[n++]=d; f[n++]=d;
            std::vector<int> nextroles;
            if(!roles.empty()){
              for(U a=all^m;a;a&=a-1)nextroles.push_back(roles[__builtin_ctz(a)]);
              nextroles.push_back(0);nextroles.push_back(0);
            }
            if(surplus==2 && !one_cut(f,n,nextroles))return false;
            std::vector<int> pp(count_pos),nn(count_neg),tt(n);
            for(int i=0;i<n;i++){
                const auto& u=wires[f[i]].value;
                tt[i]=u[5];
                for(Bits x=u[0];x;x&=x-1) pp[__builtin_ctzll(x)] |= 1<<i;
                for(int k=0;k<blocks;k++) for(Bits x=u[k+1];x;x&=x-1)
                    nn[64*k+__builtin_ctzll(x)] |= 1<<i;
            }
            Search child;
            for(U a=all^m;a;a&=a-1){
                int j=stage[__builtin_ctz(a)];child.stage.push_back(j>0?j-1:-1);
            }
            child.stage.push_back(-1);child.stage.push_back(-1);
            std::vector<Signature> key;
            if(nextroles.empty()){
                key.reserve(n);
                for(int t=0;t<n;t++){
                    auto v=wires[f[t]].value;
                    v[5]+=3*(1+child.stage[t]);
                    key.push_back(v);
                }
                std::sort(key.begin(),key.end());
                Signature continuation{};continuation[5]=100+surplus;key.push_back(continuation);
                if(failed_roots.contains(key))return false;
            }
            bool answer=child.treecut(pp,nn,n,surplus-1,tt,nextroles);
            if(!answer&&!key.empty()){
                if(failed_roots.size()>=5000)failed_roots.clear();
                failed_roots.insert(std::move(key));
            }
            return answer;};
        for(int i=0;i<nleaves;i++){if(!(allowed&(1u<<i)))continue;if(surplus&&!roles.empty()&&roles[i])continue;U m=1u<<i;if(outer(m,raw[i]))return true;layer[1].push_back({m,raw[i]});}
        unordered_map<U,Signature> constraints;
        auto dom=[&](const Signature&a,const Signature&b){if(b[0]&~a[0])return false;for(int k=1;k<=blocks;k++)if(a[k]&~b[k])return false;return true;};
        for(int w=2;w<=nleaves;w++){
            if(w==3&&layer[2].empty())return false;
            unordered_map<U,vector<Signature>> bucket;
            for(int a=1;a<=w/2;a++)for(auto&[xm,x]:layer[a])for(auto&[ym,y]:layer[w-a]){
                if((xm&ym)||(a*2==w&&xm>=ym)||(x[5]==y[5]&&x[5]!=2))continue;
                U mask=xm|ym;Signature q{};int permit=3;
                if(!surplus){
                    for(U t=xm;t;t&=t-1){int i=__builtin_ctz(t);
                        if(req_and[i]&ym)permit&=1;
                        if(req_or[i]&ym)permit&=2;
                    }
                    if(!permit)continue;
                }
                if(w==2){
                 auto&mx=personal[__builtin_ctz(xm)];auto&my=personal[__builtin_ctz(ym)];
                 if((mx[0]&~y[0])||(my[0]&~x[0]))permit&=~1;
                 for(int k=1;k<=blocks;k++)if((mx[k]&y[k])||(my[k]&x[k]))permit&=~2;
                 if(!permit)continue;
                }else{auto [it,tmp]=constraints.try_emplace(mask);if(tmp)it->second=needed(mask);q=it->second;}
                if(!surplus&&!roles.empty()) {
                    for(U ai=xm;ai;ai&=ai-1)for(U bi=ym;bi;bi&=bi-1){
                       int u=roles[__builtin_ctz(ai)],v=roles[__builtin_ctz(bi)];
                       if(u&&v)permit&=((u-1)/2==(v-1)/2)?1:2;
                    }
                }
                for(int op=0;op<2;op++)if(permit&(1<<op)){
                    Signature z{};z[0]=op?(x[0]|y[0]):(x[0]&y[0]);if(q[0]&~z[0])continue;
                    bool ok=true;for(int k=1;k<=blocks;k++){z[k]=op?(x[k]|y[k]):(x[k]&y[k]);if(q[k]&z[k]){ok=false;break;}}
                    if(!ok)continue;z[5]=2;auto&v=bucket[mask];
                    if(any_of(v.begin(),v.end(),[&](const auto&other){return dom(other,z);}))continue;
                    v.erase(remove_if(v.begin(),v.end(),[&](const auto&other){return dom(z,other);}),v.end());v.push_back(z);
                }
            }
            for(auto&[mask,vs]:bucket)for(auto&v:vs){if(outer(mask,v))return true;layer[w].push_back({mask,v});}
        }
        return false;
    }
};
}
