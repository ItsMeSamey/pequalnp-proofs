"""Necessary physical gate prices for two extra line slots (or the triangle)."""
from pathlib import Path
import sys

def price(bank):
    singles = {m for m in bank if m.bit_count() == 1}
    rich = {m for m in bank if m.bit_count() >= 2}
    padding = len(bank) - len(singles) - len(rich)
    if len(rich) == 3:
        assert all(m.bit_count() == 2 for m in rich)
        return padding + 3
    if len(rich) == 2:
        a, b = rich
        return padding + (a | b).bit_count() - (1 if a & b else 2)
    return padding + sum(m.bit_count() - 1 for m in rich)

if __name__ == '__main__':
    work = Path(sys.argv[1])
    costs = [price(tuple(map(int, row.split()))) for row in (work / 'lines').read_text().splitlines()]
    point_cost = int(sys.argv[2])
    for row in sys.stdin:
        if costs[int(row.split()[1])] <= 10 - point_cost:
            print(row, end='')
