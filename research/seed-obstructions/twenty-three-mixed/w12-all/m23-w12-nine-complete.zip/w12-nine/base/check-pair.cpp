#include "pair-bipartite.hpp"
#include <fstream>
#include <iostream>
#include <memory>
#include <string>

using ordered_regions_pair::Mask;
using ordered_regions_pair::Side;
using Bank = std::vector<unsigned>;

std::vector<Bank> read(const char* path,int width) {
    std::ifstream in(path);if(!in)throw std::runtime_error(path);
    std::vector<Bank> banks;Bank row(width);
    while(in>>row[0]){
        for(int i=1;i<width;i++)if(!(in>>row[i]))throw std::runtime_error("truncated bank");
        banks.push_back(row);
    }
    return banks;
}
Side project(const Bank& bank,const std::vector<unsigned>&pos,const std::vector<unsigned>&neg,bool line) {
    auto eval=[&](const std::vector<unsigned>& rows){
        std::vector<Mask> out;out.reserve(rows.size());
        for(auto row:rows){
            auto x=line?row>>13:row&8191u;
            Mask m=0;for(size_t i=0;i<bank.size();i++)if(x&bank[i])m|=Mask(1)<<i;
            out.push_back(m);
        }
        return out;
    };
    return Side(bank.size(),eval(pos),eval(neg));
}
int main(int argc,char**argv) {
    if(argc<7||argc>8){std::cerr<<"args: raw-samples point-banks line-banks point-width line-width surplus [node-budget]\n";return 1;}
    int pw=std::stoi(argv[4]),lw=std::stoi(argv[5]),k=std::stoi(argv[6]);
    if(pw<1||pw>16||lw<1||lw>16||pw+lw>31)return 2;
    unsigned budget=argc==8?std::stoul(argv[7]):1000;
    std::ifstream sample(argv[1]);int np,nn;if(!(sample>>np>>nn)||np!=28||nn!=245)return 3;
    std::vector<unsigned> pos(np),neg(nn);for(auto&x:pos)sample>>x;for(auto&x:neg)sample>>x;
    if(!sample)return 4;
    auto p=read(argv[2],pw),l=read(argv[3],lw);
    // Cost stays bounded for a streamed line domain. A 64 MiB cache holds
    // the resident line blocks, and the last point bank is retained.
    std::vector<std::unique_ptr<Side>> lc(l.size());std::vector<int> live;
    size_t capacity=std::max<size_t>(1,(64ull<<20)/((1ull<<lw)*sizeof(ordered_regions_pair::Negative)+1024));
    std::unique_ptr<Side> pc;int last=-1,i,j;
    uint64_t tested=0,passing=0,limited=0;
    while(std::cin>>i>>j){
        if(i!=last){pc=std::make_unique<Side>(project(p.at(i),pos,neg,false));last=i;}
        if(!lc.at(j)){
            if(live.size()>=capacity){for(int t:live)lc[t].reset();live.clear();}
            lc[j]=std::make_unique<Side>(project(l[j],pos,neg,true));live.push_back(j);
        }
        auto r=ordered_regions_pair::check(*pc,*lc[j],k,budget);
        if(r.possible){std::cout<<i<<' '<<j<<std::endl;passing++;}
        limited+=r.exhausted_budget;
        if(++tested%10000==0)std::cerr<<tested<<" tested "<<passing<<" possible "<<limited<<" capped\n";
    }
    std::cerr<<"DONE "<<tested<<' '<<passing<<' '<<limited<<'\n';
}
