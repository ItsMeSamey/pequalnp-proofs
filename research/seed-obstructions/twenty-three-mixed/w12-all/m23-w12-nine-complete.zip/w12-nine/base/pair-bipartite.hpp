#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <vector>

namespace ordered_regions_pair {
using Mask = uint32_t;
using Negative = std::array<uint64_t,4>;
inline int bit(Mask v) { return std::countr_zero(v); }

// Positive and negative arguments are projected truth rows on this one side.
// At most sixteen columns per side. Equal or identically zero columns are allowed.
struct Side {
    int width;
    Mask full;
    std::array<Mask,28> positive{};
    std::vector<Negative> zero;
    Side(int columns, std::span<const Mask> pos, std::span<const Mask> neg) : width(columns) {
        if (columns<1 || columns>16 || pos.size()!=28 || neg.size()!=245) throw std::invalid_argument("side size");
        full=(Mask(1)<<columns)-1;
        std::copy(pos.begin(),pos.end(),positive.begin());
        zero.resize(full+1);
        std::array<Negative,16> truth{};
        for(int n=0;n<245;n++){
            if(neg[n]&~full) throw std::invalid_argument("negative projection");
            for(Mask v=neg[n];v;v&=v-1)truth[bit(v)][n/64]|=uint64_t(1)<<(n%64);
        }
        for(auto p:positive)if(p&~full)throw std::invalid_argument("positive projection");
        zero[0].fill(~uint64_t(0)); zero[0][3]=(uint64_t(1)<<53)-1;
        for(Mask m=1;m<=full;m++)for(int k=0;k<4;k++)
            zero[m][k]=zero[m&(m-1)][k]&truth[bit(m)][k];
    }
};

struct Result {bool possible; unsigned nodes; bool exhausted_budget;};

inline Result check(const Side& p,const Side& l,int surplus,unsigned budget=1000) {
    const int n=p.width+l.width;
    if(n>31||surplus<0||surplus>8)throw std::invalid_argument("combined width or surplus");
    const Mask full=(Mask(1)<<n)-1;
    std::array<Mask,28> pos;
    for(int x=0;x<28;x++)pos[x]=p.positive[x]|(l.positive[x]<<p.width);
    auto zero=[&](Mask m){
        const auto&a=p.zero[m&p.full];const auto&b=l.zero[m>>p.width];
        return Negative{a[0]&b[0],a[1]&b[1],a[2]&b[2],a[3]&b[3]};
    };
    auto partial=[&](Mask one,Mask later){
        if(!one||!later)return true;
        Mask positive=0;Negative negative{};
        for(int x=0;x<28;x++) {
            auto z=zero(pos[x]&~one);
            if(z[0]|z[1]|z[2]|z[3])positive|=Mask(1)<<x;
            for(int k=0;k<4;k++)negative[k]|=z[k];
        }
        for(Mask q=positive;q;q&=q-1) {
            auto z=zero(pos[bit(q)]&~later);
            if((z[0]&negative[0])|(z[1]&negative[1])|(z[2]&negative[2])|(z[3]&negative[3]))return false;
        }
        return true;
    };
    auto pair_cut=[&](Mask senders,Mask later){
        if(!senders||!later)return true;
        std::array<Negative,28> required,ordered;
        Mask alive=0;
        for(int x=0;x<28;x++){
            required[x]=zero(pos[x]&~senders);
            auto&r=required[x];if(r[0]|r[1]|r[2]|r[3])alive|=Mask(1)<<x;
        }
        if(std::popcount(alive)<3)return true;
        std::array<Mask,28> out{},in{};
        for(Mask a=alive;a;a&=a-1){
            int x=bit(a);auto&t=ordered[x];t=zero(pos[x]&~later);
            if(!(t[0]|t[1]|t[2]|t[3]))continue;
            for(Mask b=alive;b;b&=b-1){
                int y=bit(b);auto&r=required[y];
                if((r[0]&t[0])|(r[1]&t[1])|(r[2]&t[2])|(r[3]&t[3])){
                    out[x]|=Mask(1)<<y;in[y]|=Mask(1)<<x;
                }
            }
        }
        // Every obligation sharing a positive row x has a common neighbor
        // as soon as x orders any other obligation's negative. Bipartiteness
        // then forces the whole x row monochromatic.
        Mask fixed=0;
        for(Mask a=alive;a;a&=a-1){int x=bit(a);if(out[x])fixed|=Mask(1)<<x;}
        std::array<Mask,28> same{},opposite{};
        for(Mask a=fixed;a;a&=a-1){int x=bit(a);opposite[x]=(out[x]|in[x])&fixed;}
        for(Mask a=alive&~fixed;a;a&=a-1){
            int z=bit(a);auto&r=required[z];
            for(Mask b=in[z];b;b&=b-1){
                int x=bit(b);auto&t=ordered[x];
                for(Mask c=b&(b-1);c;c&=c-1){
                    int y=bit(c);auto&u=ordered[y];
                    if((r[0]&t[0]&u[0])|(r[1]&t[1]&u[1])|(r[2]&t[2]&u[2])|(r[3]&t[3]&u[3])){
                        same[x]|=Mask(1)<<y;same[y]|=Mask(1)<<x;
                    }
                }
            }
        }
        while(fixed){
            Mask side0=fixed&-fixed,side1=0,front0=side0,front1=0;
            while(front0||front1){
                Mask next0=0,next1=0;
                for(Mask q=front0;q;q&=q-1){int x=bit(q);next0|=same[x];next1|=opposite[x];}
                for(Mask q=front1;q;q&=q-1){int x=bit(q);next1|=same[x];next0|=opposite[x];}
                if((next0&side1)||(next1&side0)||(next0&next1))return false;
                front0=next0&~side0;front1=next1&~side1;side0|=next0;side1|=next1;
            }
            fixed&=~(side0|side1);
        }
        return true;
    };
    std::array<Mask,31> posmark{},yes{},no{},conflict{};
    std::array<Negative,31> negmark{};
    for(int x=0;x<28;x++){
        auto base=zero(pos[x]);
        if(base[0]|base[1]|base[2]|base[3])return {false,0,false};
        for(Mask v=pos[x];v;v&=v-1){
            int i=bit(v);auto z=zero(pos[x]^(Mask(1)<<i));
            if(z[0]|z[1]|z[2]|z[3])posmark[i]|=Mask(1)<<x;
            for(int k=0;k<4;k++)negmark[i][k]|=z[k];
        }
    }
    for(int i=0;i<n;i++)for(int j=0;j<i;j++){
        bool and_pair=posmark[i]&posmark[j];bool or_pair=false;
        for(int k=0;k<4;k++)if(negmark[i][k]&negmark[j][k])or_pair=true;
        if(and_pair){yes[i]|=Mask(1)<<j;yes[j]|=Mask(1)<<i;}
        if(or_pair){no[i]|=Mask(1)<<j;no[j]|=Mask(1)<<i;}
        if(and_pair&&or_pair){conflict[i]|=Mask(1)<<j;conflict[j]|=Mask(1)<<i;}
    }
    auto component=[&](const auto&edge,Mask mask) {
        Mask frontier=mask&-mask,seen=frontier;
        while(frontier){
            Mask next=0;for(Mask v=frontier;v;v&=v-1)next|=edge[bit(v)];
            frontier=next&mask&~seen;seen|=frontier;
        }
        return seen;
    };
    auto compatible=[&](auto&&self,Mask mask)->bool {
        if(std::popcount(mask)<4)return true;
        Mask part=component(yes,mask);if(part==mask)part=component(no,mask);
        return part!=mask&&self(self,part)&&self(self,mask^part);
    };
    std::array<Mask,9> region{};unsigned nodes=0;bool exhausted=false;
    auto search=[&](auto&& self,Mask remaining)->bool {
        if(++nodes>budget){exhausted=true;return true;}
        Mask later=region[surplus];
        for(int j=surplus-1;j>=0;j--){
            if(!partial(region[j],later))return false;
            later|=region[j];
        }
        int open=std::popcount(remaining);
        if(surplus>=2 && (open==0 || (open<=n/2 && open%4==0))){
            Mask suffix=region[surplus];
            for(int j=surplus-1;j>0;j--){
                if(region[j]&&suffix){
                    for(int i=0;i<j;i++)if(region[i]&&!pair_cut(region[i]|region[j],suffix))return false;
                }
                suffix|=region[j];
            }
        }
        if(!remaining){
            Mask first=region[0];
            return first&&(!(first&(first-1))||((first&p.full)&&(first&~p.full)));
        }
        int best=-1,score=-1;
        for(Mask v=remaining;v;v&=v-1){
            int i=bit(v),banned=0;for(int j=0;j<=surplus;j++)banned+=bool(conflict[i]&region[j]);
            if(banned==surplus+1)return false;
            int rank=1000*banned+32*std::popcount(conflict[i]&remaining)+std::popcount((yes[i]|no[i])&remaining);
            if(rank>score){best=i;score=rank;}
        }
        Mask w=Mask(1)<<best;
        for(int j=0;j<=surplus;j++){
            if((conflict[best]&region[j])||!compatible(compatible,region[j]|w))continue;
            region[j]|=w;
            if(self(self,remaining^w))return true;
            region[j]^=w;
        }
        return false;
    };
    bool feasible=search(search,full);
    return {feasible,nodes,exhausted};
}
}
