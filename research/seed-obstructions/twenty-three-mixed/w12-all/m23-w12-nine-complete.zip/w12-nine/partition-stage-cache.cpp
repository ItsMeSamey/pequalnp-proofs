#include "partition-stage-cache.hpp"
using namespace std;
template<size_t W> auto read_masks(const char* path){
 ifstream fs(path);vector<array<int,W>> data;array<int,W>b;
 while(fs>>b[0]){for(int i=1;i<W;i++)if(!(fs>>b[i]))abort();data.push_back(b);}
 return data;
}
template<size_t W> vector<int> project(const array<int,W>&b,const vector<int>&rows,bool point){
 vector<int> out;
 for(auto raw:rows){int v=0;for(int j=0;j<W;j++)if(b[j]&(point?(raw&8191):(raw>>13)))v|=1<<j;out.push_back(v);}
 return out;
}
int main(int argc,char**argv){
 if(argc!=4)return 2;ios::sync_with_stdio(false);cin.tie(nullptr);
 ifstream s(argv[1]);int np,nn;s>>np>>nn;if(np!=28||nn!=245)return 3;
 vector<int> rows(np+nn);for(auto&r:rows)s>>r;
 auto pt=read_masks<12>(argv[2]);auto ls=read_masks<9>(argv[3]);
 vector<vector<int>> pm,lm;for(auto&b:pt)pm.push_back(project(b,rows,true));for(auto&b:ls)lm.push_back(project(b,rows,false));
 int i,j;uint64_t total=0,yes=0;vector<int> type(21);fill_n(type.begin(),12,1);
 int previous_i=-1,previous_j=-1; unsigned a,b,c0,d; while(cin>>i>>j>>a>>b>>c0>>d){
  if(i!=previous_i||j!=previous_j){frontierlib::failed_roots.clear();previous_i=i;previous_j=j;}
  if((a|b|c0|d)!=(1u<<21)-1 || ((a&b)|(a&c0)|(a&d)|(b&c0)|(b&d)|(c0&d)))return 4;
  vector<int>P,N;
  for(int k=0;k<np+nn;k++)(k<np?P:N).push_back(pm.at(i)[k]|(lm.at(j)[k]<<12));
  sort(P.begin(),P.end());P.erase(unique(P.begin(),P.end()),P.end());
  sort(N.begin(),N.end(),[](int a,int b){return __builtin_popcount((unsigned)a)>__builtin_popcount((unsigned)b);});
  vector<int> maximal;for(int n:N)if(none_of(maximal.begin(),maximal.end(),[&](int q){return !(n&~q);}))maximal.push_back(n);
  frontierlib::Search c; for(int t=0;t<21;t++)c.stage.push_back((a>>t&1)?0:(b>>t&1)?1:(c0>>t&1)?2:3);if(c.treecut(P,maximal,21,3,type)){cout<<i<<' '<<j<<' '<<a<<' '<<b<<' '<<c0<<' '<<d<<endl;yes++;}
  if((++total%1000)==0)cerr<<total<<" "<<yes<<endl;
 }
 cerr<<"DONE "<<total<<" "<<yes<<endl;
}
