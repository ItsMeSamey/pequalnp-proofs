from pathlib import Path
from collections import Counter
from itertools import combinations_with_replacement
import sys
root=Path(__file__).resolve().parent
from inputs import P,N,stars
from samples import actions
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZipFile
work=Path(sys.argv[1]);work.mkdir(exist_ok=True)
source=ZipFile(root/'twelve-eight.zip')
def source_rows(f):return source.read('twelve-eight/'+f).decode().splitlines()
fs=actions(P,N)
lg=[tuple(stars.index(f[x])for x in stars)for f in fs]
lf=[tuple(sum((q>>i&1)<<j for i,j in enumerate(g))for q in range(128))for g in lg]
table={}
for row in source_rows('banks-through-eight.txt'):
 *p,c=map(int,row.split());key=min(tuple(sorted(f[m]for m in p))for f in fs)
 table[key]=min(c,table.get(key,100))
assert Counter(table.values())=={5:2,6:5,7:25,8:119}
ps=sorted(table,key=lambda p:(table[p],p))
def write(file,rows):file.write_text(''.join(' '.join(map(str,r))+'\n'for r in rows))
write(work/'points', ps)
ordinary=tuple(1<<i for i in range(7));line={}
for a,b in combinations_with_replacement(range(128),2):
 c=((a|b).bit_count()-1)if a&b else max(a.bit_count()-1,0)+max(b.bit_count()-1,0)
 l=tuple(sorted((*ordinary,a,b)));line[l]=c
for t in (source_rows('exceptional-nine.txt')):
 line[tuple(map(int,t.split()))]=3
assert len(line)==8280
assert Counter(line.values())=={0:36,1:189,2:630,3:1529,4:2464,5:2401,6:1031}
ls=sorted(line);write(work/'lines',ls)
print('point prices',Counter(table.values()),'line prices',Counter(line.values()),flush=True)
cache={}
(work/'rows').write_text(f'{len(P)} {len(N)}\n'+' '.join(map(str,sorted(P)))+'\n'+' '.join(map(str,sorted(N)))+'\n')
for c in range(5,9):
 pairs=[]
 for i,p in enumerate(ps):
  if table[p]!=c:continue
  stab=[j for j,f in enumerate(fs) if tuple(sorted(f[m] for m in p))==p]
  pairs.extend((i,k) for k,l in enumerate(ls) if line[l]<=10-c and l==min(tuple(sorted(lf[j][x] for x in l)) for j in stab))
 write(work/f'c{c}',pairs)
 print(c,len(pairs),flush=True)
