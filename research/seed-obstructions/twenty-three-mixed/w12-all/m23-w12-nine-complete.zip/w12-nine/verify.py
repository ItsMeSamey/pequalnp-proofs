"""Rebuild one complete W12/L9 point-price slice. Run python verify.py 6."""
import pathlib
import subprocess
import sys
import tempfile
root = pathlib.Path(__file__).resolve().parent
price = int(sys.argv[1])
assert price in range(5,9)

with tempfile.TemporaryDirectory() as temporary:
    work = pathlib.Path(temporary)
    subprocess.run([sys.executable, root/'cases.py', work], check=True)
    for name, source in [('order','base/check-pair.cpp'),('parts','assignments.cpp'),('exact','partition-stage-cache.cpp')]:
        subprocess.run(['g++','-O2','-std=c++20',root/source,'-o',work/name],check=True)
    base = [str(work/t) for t in ('rows','points','lines')]
    def run(cmd, source, target):
        with open(work/source,'rb') as f,open(work/target,'wb') as out:
            process = subprocess.run(cmd,stdin=f,stdout=out,stderr=subprocess.PIPE,check=True)
        log = process.stderr.decode().splitlines()
        assert log[-1].startswith('DONE ')
        counts = list(map(int,log[-1].split()[1:]))
        assert counts[0] == len((work/source).read_text().splitlines())
        print(source,target,counts,flush=True)
        return counts
    run([work/'order',*base,'12','9','3','1200'],f'c{price}','first')
    with open(work/'first','rb') as f,open(work/'priced','wb') as out:
        subprocess.run([sys.executable,root/'price_filter.py',work,str(price)],stdin=f,stdout=out,check=True)
    run([work/'order',*base,'12','9','3','18000'],'priced','strong')
    counts = run([work/'parts',*base,'12','9','3','4294967295'],'strong','partitions')
    assert counts[1:] == [0,0], ('partition cutoff',counts)
    seen = []
    with open(work/'expanded','w') as out:
        for row in (work/'partitions').read_text().splitlines():
            if row.startswith('CASE '):
                pair=row.split()[1:]
                seen.append(' '.join(pair))
            else:
                masks = list(map(int,row.split()))
                assert len(masks)==4 and sum(m.bit_count() for m in masks)==21
                assert (masks[0]|masks[1]|masks[2]|masks[3])==(1<<21)-1
                print(*pair,*masks,file=out)
    assert seen == (work/'strong').read_text().splitlines()
    counts = run([work/'exact',*base],'expanded','solutions')
    assert counts[1]==0 and (work/'solutions').stat().st_size==0
