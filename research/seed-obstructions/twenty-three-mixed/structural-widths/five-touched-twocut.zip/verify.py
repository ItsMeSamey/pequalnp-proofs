from two import solve
from itertools import combinations
from collections import Counter
import sys
counts=Counter()
for untouched in combinations(range(7),2):
    touched=set(range(7))-set(untouched)
    S=sum(1<<i for i in touched)
    profiles=[(S,)]
    for pair in combinations(sorted(touched),2):
        v=sum(1<<i for i in pair);profiles.append((v,S^v))
    for profile in profiles:
        result=solve(profile,2000)
        counts[len(profile),result]+=1
        print(*untouched,','.join(map(str,profile)),str(result),flush=True)
print(dict(counts))
