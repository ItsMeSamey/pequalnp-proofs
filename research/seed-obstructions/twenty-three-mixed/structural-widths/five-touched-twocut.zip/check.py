from pathlib import Path
from collections import Counter
from itertools import combinations
rows=Path(__file__).with_name('replay.log').read_text().splitlines()
actual={}
for r in rows:
 if r.startswith('{'):continue
 i,j,m,value=r.split()
 key=int(i),int(j),tuple(map(int,m.split(',')))
 assert key not in actual
 actual[key]=value
expected=set()
for i,j in combinations(range(7),2):
 touched=set(range(7))-{i,j};s=sum(1<<v for v in touched)
 expected.add((i,j,(s,)))
 for a,b in combinations(sorted(touched),2):
  p=1<<a|1<<b;expected.add((i,j,(p,s^p)))
assert set(actual)==expected and all(v=='False' for v in actual.values())
print(Counter(len(k[-1]) for k in actual))
