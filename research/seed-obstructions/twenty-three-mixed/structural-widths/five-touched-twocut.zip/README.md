# Five touched labels and two surplus reads

After substituting the pure point forest the DAG has at most two surplus reads. Cut its repeated vertices in topological order. This yields regions A, B, and C with disjoint physical leaves and formal ports for earlier signals. Any path carrying a raw leaf's dependence outside its own region must pass through its region output. Another route would require another repeated vertex. A single vertex repeated three times is covered by an unused second bit. A repeated original input may be the sole leaf of a region.

Let H and J be the cut outputs. H is monotone in A. J is monotone in B and H, and the exterior is monotone in C, H and J. The test allows earlier signals to feed all later regions, covering serial, parallel and split placements. It grants all 31 physical point masks. Omitted leaves may be assigned arbitrarily and ignored.

For positive p and negative n, D contains the physical slots active on p and inactive on n. Singleton D forces its leaf pivotal on both rows. If two leaves are pivotal at a common positive they need an AND least common ancestor when they share a read-once region. A common negative requires OR. Flipping either leaf keeps earlier ports fixed, and a flip that changes the root must change its own region output. Thus a leaf pair with both requirements must occupy two distinct regions.

Assign separate sample-row variables to H and J. For each p,n write h for H(p) and not H(n), and j for J(p) and not J(n). Necessarily h implies an A leaf in D. Likewise j implies a B leaf in D or h. Lastly there must be a C leaf in D, or h or j must hold. Each follows from monotonicity at one of the three region boundaries. Three auxiliary distinguisher bits, one per role, are each allowed to be true only when that role owns some member of D. Expanding the three requirements gives one, two, and four clauses. A genuine DAG satisfies them all. The solver applies a conflict budget and only explicit False results establish exclusion.

Two untouched labels have 21 possible placements. Their five complementary labels form one block of five or a pair plus a triple, giving 21 and 210 profiles. Saturated line branching supplies these specific non-echo shapes. The test itself handles the entire point library irrespective of the twenty-source bound.

Run python3 verify.py to rebuild the 231 SAT instances. Then run python3 check.py to verify the included ledger contains each required labelled profile once and all answers are False. Python-sat with CaDiCaL 195 is required.
