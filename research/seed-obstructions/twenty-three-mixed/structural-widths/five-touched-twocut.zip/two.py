from rows import P,N,raw
from pysat.formula import IDPool
from pysat.solvers import Solver
from itertools import combinations
def solve(blocks, budget=2000):
    ms=raw+[(1<<j)<<13 for j in range(7)]+[m<<13 for m in blocks]
    names=IDPool()
    roles=[[names.id(('r',i,t))for t in range(3)]for i in range(len(ms))]
    HP=[names.id(('hp',i))for i in range(len(P))]
    HN=[names.id(('hn',i))for i in range(len(N))]
    JP=[names.id(('jp',i))for i in range(len(P))]
    JN=[names.id(('jn',i))for i in range(len(N))]
    F=[]
    for row in roles:
        F.append(row)
        for a,b in combinations(row,2):F.append([-a,-b])
    def inputs(words):return [sum(1<<i for i,m in enumerate(ms)if m&w)for w in words]
    pp=inputs(P);nn=inputs(N)
    gl={};hp=[0]*len(ms);hn=hp.copy()
    for a,p in enumerate(pp):
        for b,n in enumerate(nn):
            d=p&~n
            if not d:return False
            gl.setdefault(d,[]).append((a,b))
            if d&(d-1)==0:
                i=d.bit_length()-1;hp[i]|=1<<a;hn[i]|=1<<b
    for i,j in combinations(range(len(ms)),2):
        if hp[i]&hp[j] and hn[i]&hn[j]:
            for k in range(3):F.append([-roles[i][k],-roles[j][k]])
    for d,pairs in gl.items():
        ix=[i for i in range(len(ms)) if d>>i&1]
        A,B,C=[names.id(('dist',d,t))for t in range(3)]
        for t,z in enumerate((A,B,C)):F.append([-z,*[roles[i][t]for i in ix]])
        for a,b in pairs:
            F.append([A,-HP[a],HN[b]])
            F.extend([[B,-JP[a],JN[b],HP[a]],[B,-JP[a],JN[b],-HN[b]]])
            for h in [HP[a],-HN[b]]:
                for j in [JP[a],-JN[b]]:F.append([C,h,j])
    with Solver(name='cadical195',bootstrap_with=F)as sat:
        sat.conf_budget(budget);return sat.solve_limited()
