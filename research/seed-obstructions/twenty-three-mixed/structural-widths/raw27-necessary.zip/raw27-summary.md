# Necessary structure with 27 live normalized raw inputs

There are 20 raw point inputs and seven raw line flags. The all-width raw line charge e≤h_l and regional trade give r+M+Q−1≤e+k+h_p≤7. The r≤3 reconstructions apply because g+P=20+h_p and δ+r+h_p≤7, so g+P−(7−r)+δ≤20 and the three-arm effective price is ≥1.

At r=4, zero mergers and three companions failed in the 28-input replay. All 455 labeled partitions with one or two mergers fail with three or two companions (r4-pools-check.py). At three mergers and one companion, keeping paths to ordinary roles leads to a one-bit cut toward the exterior from a nonempty ordinary subset. All 245 checks fail. At r=5 all 84 separate or two-pool partitions fail with both companions; at full connectivity all 63 ordinary-only sender tests fail. At r=6 a separated guard fails even with 21 inputs. The sole possible merger between guard and exterior must be physical pure sharing since no exterior supplier feeds a retained private guard. The unique common bit from a dedicated subtree fails in all seven instances.

Thus r=7. Since r−e≤k, e≤h_l and k+h_l+h_p≤7, necessarily h_p=0,h_l=e,k=7−e. Every line singleton is selected and the extras are disjoint OR blocks touching precisely e labels. At e=7 all 162 partitions fail even when all 31 raw point coordinates are granted to the read-once private-witness test. The open saturation cases have e≤6,k≥1, with e=1 impossible. In the source-equality cells P+L−(33−m)=27, g+P=20 implies g=0,P=20,c=L−7. This does not exclude all 27-input circuits.

Required companions:
* raw-width27-primary.zip cbb5b90a8b98cca0afbe26ce83672787b25b2dfd4acf0da7332fc4666dbb5a7f
* syn_bounds/raw27/raw27-one-directed-bridge.zip e9e273b8f2c4f89a3b92afc2d9b5dd895eb8c841fad98eac5c2fe85a96019821
* synthesis_new/raw27-five-special.zip b1fdcac974b99868cbfc23b3ebc26a733dd11daf7acd3265103ebfe5bf42b6f4
* syn_dual/raw27-bridge/n27-single-bridge.zip 6c760bedf2f1e7f007293ac43b2f1634adb530c4cd08557cfa40c28e3fd91753
* syn_mitm/raw-width27/raw27-all-seven.zip fabc47c3ce1f5835ee96a165c469c3317aa2ba75e1a74c50cd58f4095548ac20
