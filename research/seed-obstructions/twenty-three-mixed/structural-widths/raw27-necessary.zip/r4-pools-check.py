from itertools import combinations
from raw27_pools import feasible,partitions
for ordinary in combinations(range(7),3):
    for pi in partitions(4):
        m=4-len(set(pi))
        if m in [1,2]:
            assert not feasible(ordinary,pi,4-m,20),(ordinary,pi)
print('455 labeled nontrivial role partitions excluded')
