from itertools import combinations
from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
from forest import P,N,raw,stars

def partitions(length):
    def extend(prefix):
        if len(prefix)==length:
            yield prefix
            return
        for v in range(max(prefix)+2):
            yield from extend(prefix+(v,))
    yield from extend((0,))

def feasible(ordinary,pi,q,limit):
    ids=IDPool()
    n=max(pi)+1
    roles=[[ids.id(('raw',r,i)) for i in range(len(raw))] for r in range(n)]
    clauses=CardEnc.atmost(sum(roles,[]),limit,vpool=ids).clauses
    for a,b in combinations(roles,2):
        clauses.extend([[-x,-y] for x,y in zip(a,b)])
    def distinguish(group,point,neg):
        return [v for v,m in zip(roles[group],raw) if m&point and not m&neg]
    for index,j in enumerate(ordinary):
        exterior=[1<<i for i in range(13) if not stars[j]>>i&1]
        for p in [1<<i for i in range(13) if stars[j]>>i&1]:
            for a,b in combinations(exterior,2):
                clauses.append(distinguish(pi[index],p,a|b))
    for p in P:
        j=(p>>13).bit_length()-1
        if j in ordinary:continue
        options=[]
        for comp in combinations(ordinary,q):
            enabled=ids.id(('comp',p,comp))
            options.append(enabled)
            for neg in N:
                if neg>>13&1<<j and all(neg&stars[i] for i in comp):
                    clauses.append([-enabled]+distinguish(pi[-1],p,neg))
        clauses.append(options)
    with Solver(name='cadical195',bootstrap_with=clauses) as solver:
        return solver.solve()

if __name__=='__main__':
    import sys
    t=int(sys.argv[1])
    for ordinary in combinations(range(7),t):
        for pi in partitions(t+1):
            mergers=t+1-len(set(pi))
            q=min(t,1+t-mergers)
            if q<1:continue
            print(ordinary,pi,q,feasible(ordinary,pi,q,20),flush=True)
