"""Incremental all-source protocol CP with exact witness ordering."""
from itertools import combinations
from pysat.solvers import Solver
from rows import P,N,raw
def solve(blocks,k,budget=1000):
    ms=raw+[1<<(13+i)for i in range(7)]+[m<<13 for m in blocks];w=len(ms);M=(1<<len(N))-1
    ps=[sum(1<<i for i,m in enumerate(ms) if p&m)for p in P]
    ns=[sum(1<<i for i,m in enumerate(ms) if n&m)for n in N]
    truth=[sum(1<<j for j,n in enumerate(ns)if n>>i&1)for i in range(w)]
    h=[0]*w;n=h.copy();drows=[]
    for a,p in enumerate(ps):
        D=[p&~q for q in ns];drows.append(D)
        for b,d in enumerate(D):
            if d==0:return False
            if not d&(d-1):
                i=d.bit_length()-1;h[i]|=1<<a;n[i]|=1<<b
    def owner(r,i):return 1+r*w+i
    def pos(r,i):return 1+(k+1)*w+r*(len(N)+len(P))+i
    def neg(r,i):return pos(r,len(P)+i)
    F=[]
    for i in range(w):
        row=[owner(r,i) for r in range(k+1)];F.append(row)
        F.extend([[-u,-v]for u,v in combinations(row,2)])
    for i,j in combinations(range(w),2):
        if h[i]&h[j] and n[i]&n[j]:
            F.extend([[-owner(r,i),-owner(r,j)]for r in range(k+1)])
    with Solver(name='cadical195',bootstrap_with=F)as sat:
        seen=set()
        while True:
            sat.conf_budget(budget);ans=sat.solve_limited()
            if ans is not True:return ans
            model=set(sat.get_model())
            owners=[sum(1<<i for i in range(w)if owner(r,i) in model) for r in range(k+1)]
            nzero=[sum(1<<b for b in range(len(N))if neg(r,b) not in model)for r in range(k)]
            failures=[]
            for a,p in enumerate(ps):
                pending=M
                for r in range(k+1):
                    if r<k and pos(r,a) not in model:continue
                    new=pending if r==k else pending&nzero[r]
                    pending^=new
                    if not new:continue
                    choices=p&owners[r]
                    while choices and new:
                        bit=choices&-choices;choices^=bit;new&=truth[bit.bit_length()-1]
                    while new:
                        bit=new&-new;new^=bit;failures.append((r,a,bit.bit_length()-1))
                        if len(failures)>=128:break
                    if len(failures)>=128:break
                if len(failures)>=128:break
            if not failures:return True
            for r,a,b in failures:
                key=(r,a,b)
                if key in seen:raise AssertionError('duplicate witness')
                seen.add(key)
                rawd=drows[a][b]
                clause=[owner(r,i)for i in range(w)if rawd>>i&1]
                if r<k:clause.extend([-pos(r,a),neg(r,b)])
                # For each earlier signal, positive high AND negative low is an allowable escape.
                # One-way implications force the raw clause whenever no escape is actually available.
                for signs in range(1<<r):
                    sat.add_clause(clause+[pos(t,a) if signs>>t&1 else -neg(t,b) for t in range(r)])
