from inputs import P,N
from itertools import combinations
from pysat.solvers import Solver
from pathlib import Path
P=sorted(P);N=sorted(N)
raw={1<<i for i in range(13)}
for j in range(6):
 a=(1<<j)|(1<<(j+1));b=(1<<(j+3))|(1<<((j+9)%13));raw.update([a,b,a|b])
raw=sorted(raw)

