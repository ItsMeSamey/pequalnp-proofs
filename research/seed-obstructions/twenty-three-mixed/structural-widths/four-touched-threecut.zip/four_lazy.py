from four_profiles import profiles
from priority import solve
for i,blocks in enumerate(profiles()):
    answer=solve(blocks,3,1000)
    print(i,','.join(map(str,blocks)),answer,flush=True)
