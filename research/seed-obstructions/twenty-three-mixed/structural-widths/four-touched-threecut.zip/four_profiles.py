from itertools import combinations
def profiles():
    for touched in combinations(range(7),4):
        S=sum(1<<j for j in touched)
        yield (S,)
        first,*rest=touched
        for b in rest:
            v=(1<<first)|(1<<b)
            yield (v,S^v)
