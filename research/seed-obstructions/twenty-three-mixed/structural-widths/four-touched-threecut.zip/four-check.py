from four_profiles import profiles
from pathlib import Path
need=list(profiles())
assert len(need)==140 and len(set(need))==140
out=[]
for text in Path(__file__).with_name('four.log').read_text().splitlines():
 i,blocks,answer=text.split()
 assert int(i)==len(out) and answer=='False'
 out.append(tuple(map(int,blocks.split(','))))
assert out==need
print('35 quadruple profiles and 105 double-pair profiles excluded')
