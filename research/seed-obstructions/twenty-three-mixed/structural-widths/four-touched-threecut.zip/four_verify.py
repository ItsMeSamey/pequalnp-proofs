from multi import solve
from four_profiles import profiles
import argparse
parser=argparse.ArgumentParser(); parser.add_argument('--start',type=int,default=0);parser.add_argument('--stop',type=int,default=140);args=parser.parse_args()
for idx,b in enumerate(profiles()):
    if args.start<=idx<args.stop:
        ans=solve(b,3,1000)
        print(idx,','.join(map(str,b)),ans,flush=True)
