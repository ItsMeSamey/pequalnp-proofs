"""Necessary conditions for exclusive raw regions linked by monotone one-bit messages."""
from itertools import combinations
from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
from rows import P,N,raw

def trace(masks,rows):
    return [sum(1<<i for i,mask in enumerate(masks)if row&mask)for row in rows]

def solve(blocks,k,budget,raw_limit=None,tree_refine=False,all_rows=False,capfanout=False):
    masks=[*raw,*[1<<(13+j)for j in range(7)],*[m<<13 for m in blocks]]
    names=IDPool()
    owner=[[names.id(('owner',i,r))for r in range(k+1)]for i in range(len(masks))]
    pos=[[names.id(('p',r,i))for i in range(len(P))]for r in range(k)]
    neg=[[names.id(('n',r,i))for i in range(len(N))]for r in range(k)]
    clauses=[];selected=[]
    arcs={}
    if capfanout:
        for u in range(k):
            outgoing=[]
            for v in range(u+1,k+1):
                arcs[u,v]=names.id(('arc',u,v));outgoing.append(arcs[u,v])
            for triple in combinations(outgoing,3):clauses.append([-a for a in triple])
    for i,row in enumerate(owner):
        if raw_limit is not None and i<len(raw):
            take=names.id(('selected',i))
            selected.append(take)
            clauses.extend([[-s,take]for s in row])
        else:
            clauses.append(row)
        for a,b in combinations(row,2):clauses.append([-a,-b])
    if raw_limit is not None:
        clauses.extend(CardEnc.atmost(selected,raw_limit,vpool=names).clauses)
    pcode=trace(masks,P);ncode=trace(masks,N);groups={}
    high=[0]*len(masks);low=high.copy()
    for a,p in enumerate(pcode):
        for b,n in enumerate(ncode):
            d=p&~n
            if not d:return False
            groups.setdefault(d,[]).append((a,b))
            if not d&(d-1):
                i=d.bit_length()-1;high[i]|=1<<a;low[i]|=1<<b
    and_edges=[0]*len(masks)
    or_edges=and_edges.copy()
    for i,j in combinations(range(len(masks)),2):
        if high[i]&high[j]:
            and_edges[i]|=1<<j;and_edges[j]|=1<<i
        if low[i]&low[j]:
            or_edges[i]|=1<<j;or_edges[j]|=1<<i
        if high[i]&high[j] and low[i]&low[j]:
            for r in range(k+1):clauses.append([-owner[i][r],-owner[j][r]])
    def incoming(ws,v,a,b):
        if not capfanout:return ws
        out=[]
        for u,w in enumerate(ws):
            q=names.id(('received',u,v,a,b));out.append(q)
            clauses.extend([[-q,w],[-q,arcs[u,v]]])
        return out
    for d,pairs in groups.items():
        leaves=[i for i in range(len(masks))if d>>i&1]
        distinguished=[names.id(('leaf-witness',d,r))for r in range(k+1)]
        for r,w in enumerate(distinguished):clauses.append([-w,*[owner[i][r]for i in leaves]])
        for a,b in pairs:
            messages=[]
            for r in range(k):
                w=names.id(('wire-witness',r,a,b))
                clauses.append([-w,pos[r][a]])
                clauses.append([-w,-neg[r][b]])
                clauses.append([-pos[r][a],neg[r][b],distinguished[r],*incoming(messages,r,a,b)])
                messages.append(w)
            clauses.append([distinguished[-1],*incoming(messages,k,a,b)])
    fullcode=pcode+ncode
    gates=[pos[r]+neg[r]for r in range(k)]
    with Solver(name='cadical195',bootstrap_with=clauses)as sat:
        while True:
            sat.conf_budget(budget)
            answer=sat.solve_limited()
            if answer is not True or not (tree_refine or all_rows):return answer
            model=set(sat.get_model())
            if all_rows:
                colors=[sum(1<<i for i,o in enumerate(owner) if o[r] in model)for r in range(k)]
                failures=[]
                for r in range(k):
                    codes=[]
                    for a,x in enumerate(fullcode):
                        pred=sum(1<<u for u in range(r) if gates[u][a] in model and (not capfanout or arcs[u,r] in model))
                        codes.append((x&colors[r])|(pred<<len(masks)))
                    lo=[i for i in range(len(fullcode)) if gates[r][i] not in model]
                    for a in range(len(fullcode)):
                        if gates[r][a] not in model:continue
                        for b in lo:
                            if codes[a]&~codes[b]:continue
                            failures.append((r,a,b))
                            if len(failures)>=64:break
                        if len(failures)>=64:break
                    if len(failures)>=64:break
                if failures:
                    for r,a,b in failures:
                        d=fullcode[a]&~fullcode[b]
                        leaf_w=[o[r]for i,o in enumerate(owner) if d>>i&1]
                        earlier=[]
                        for u in range(r):
                            w=names.id(('all-rows-msg',u,a,b));earlier.append(w)
                            sat.add_clause([-w,gates[u][a]]);sat.add_clause([-w,-gates[u][b]])
                            if capfanout:
                                # This use is receiver-specific.
                                q=names.id(('all-rows-received',u,r,a,b));earlier[-1]=q
                                sat.add_clause([-q,w]);sat.add_clause([-q,arcs[u,r]])
                        sat.add_clause([-gates[r][a],gates[r][b],*leaf_w,*earlier])
                    continue
            if not tree_refine:return True
            bad=None
            for r in range(k+1):
                ids=sum(1<<i for i,o in enumerate(owner) if o[r] in model)
                bad=obstruction(ids,and_edges,or_edges)
                if bad:break
            if not bad:return True
            # Every owner color obeys the same least-common-ancestor restrictions.
            for q in range(k+1):sat.add_clause([-o[q]for i,o in enumerate(owner) if bad>>i&1])

def obstruction(ids,and_edges,or_edges):
    if ids.bit_count()<2:return 0
    for g in (and_edges,or_edges):
        seen=front=ids&-ids
        while front:
            node=front&-front;front^=node
            add=g[node.bit_length()-1]&ids&~seen
            front|=add;seen|=add
        if seen!=ids:
            return obstruction(seen,and_edges,or_edges) or obstruction(ids^seen,and_edges,or_edges)
    return ids
