from itertools import combinations
from pathlib import Path
from input import raw_samples, point_obligations

source = Path(__file__).with_name('L-meta-18968.json')
positive, negative, _ = raw_samples(source)
primitives, _ = point_obligations(source)
stars = [{(r & 8191).bit_length()-1 for r in positive if r >> 13 == 1 << h} for h in range(7)]
def masks(n,p):
    bit = 1 << p
    return all(m == bit or not m & bit or n & m for m in primitives)
neg = {(h,p): [n for n in negative if n >> (13+h) & 1 and masks(n,p)] for h in range(7) for p in stars[h]}
assert [(h,p) for (h,p),a in neg.items() if not a] == [(5,1)]
required = {p for (h,p),a in neg.items() if a}
assert len(required) == 12
for h,t in enumerate(stars):
    s=t & required
    edges={(p,q) for p,q in combinations(sorted(s),2) if set(neg[h,p]).intersection(neg[h,q])}
    reached={min(s)}
    for _ in s:
        reached.update(v for a in edges if reached.intersection(a) for v in a)
    assert reached == s
    print('Line',h,'compulsory points',sorted(s),'simultaneous mask edges',sorted(edges))
for a,b in combinations(stars,2):
    assert len(a&b)==1 and a&b <= required
for h in range(7):
    assert all(sum(1 for p in stars[h] if m & (1<<p))<=1 for m in primitives)
for p in sorted(required):
    incident=[i for i,t in enumerate(stars) if p in t]
    auto=[]; no_self=[]
    for h in range(7):
        conflicts={n for i in incident for n in neg[i,p] if n >> (13+h) & 1}
        if not conflicts:auto.append(h)
        if not any(masks(n,q) for n in conflicts for q in stars[h] & required):no_self.append(h)
    assert auto == no_self
    print('Raw point',p,'possible holders other than the full holder or root',no_self)
