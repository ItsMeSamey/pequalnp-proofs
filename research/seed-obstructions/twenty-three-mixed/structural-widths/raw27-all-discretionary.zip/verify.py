from collections import Counter
from itertools import combinations
from inputs import P,N,stars
raw={1<<i for i in range(13)}
for i in range(6):
    a=3<<i;b=(1<<(i+3))|(1<<((i+9)%13))
    raw.update((a,b,a|b))
assert len(raw)==31
assert all(not m&(m-1) or all((m&t).bit_count()<=1 for t in stars) for m in raw)
for t,st in enumerate(stars):
    assert {r&8191 for r in P if r>>13==1<<t}=={1<<p for p in range(13) if st>>p&1}
pairs={}
for t,st in enumerate(stars):
    for p in {st&u for u in stars if u!=st}:
        assert p.bit_count()==1
        pairs[t,p]=[]
        for a,b in combinations([i for i in range(13) if not st>>i&1],2):
            x=(1<<a)|(1<<b)
            if all(not(p&m) or p==m or x&m for m in raw):
                # Whenever t is special, an actual negative can also meet any chosen ordinary companion.
                assert all(any(n>>(13+t)&1 and n&x==x and n&v for n in N) for v in stars if v!=st)
                pairs[t,p].append(x)
        assert pairs[t,p]
def partitions(order):
    if not order:yield ();return
    x,*rest=order
    for bs in partitions(rest):
        yield ((x,),)+bs
        for i in range(len(bs)):yield bs[:i]+((x,)+bs[i],)+bs[i+1:]
results=Counter()
for bs in partitions(range(7)):
    if len(bs)==1:continue
    req={(t,stars[t]&stars[u]) for group in bs for t in group for u in range(7) if u not in group}
    active=sum(set(p for t,p in req))
    assert any(x&active for t,p in req for x in pairs[t,p]),bs
    results[len(bs)]+=1
assert results=={2:63,3:301,4:350,5:140,6:21,7:1}
print('Root partitions excluded',dict(sorted(results.items())),sum(results.values()))
