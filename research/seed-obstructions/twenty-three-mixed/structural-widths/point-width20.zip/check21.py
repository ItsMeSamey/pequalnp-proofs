from pathlib import Path
from itertools import combinations
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
import sys
root=Path(__file__).resolve().parent
from inputs import P,N,stars
raw={1<<i for i in range(13)}
for j in range(6):
 a=(1<<j)|(1<<(j+1));b=(1<<(j+3))|(1<<((j+9)%13));raw.update((a,b,a|b))
raw=sorted(raw)
def solve(ordinary,limit=19):
    v=IDPool();cnf=[]
    role=[[v.id(('slot',r,i)) for i in range(31)]for r in range(4)]
    for i in range(31):
        for a,b in combinations(range(4),2):cnf.append([-role[a][i],-role[b][i]])
    cnf+=CardEnc.atmost(sum(role,[]),limit,vpool=v).clauses
    first={x for a in raw for b in raw for x in (a|b,a&b)}
    second={x for a in first for b in raw for x in(a|b,a&b)}
    options=sorted(second-{0})
    paid=[[v.id(('paid',r,m))for m in options]for r in range(4)]
    cnf+=CardEnc.atmost(sum(paid,[]),2,vpool=v).clauses
    cnf+=CardEnc.atmost([lit for row in paid for lit,m in zip(row,options)if m not in first],1,vpool=v).clauses
    def distinguishing(r,p,n):return [lit for lit,m in zip(role[r],raw) if m&p and not m&n]+[lit for lit,m in zip(paid[r],options)if m&p and not m&n]
    for r,j in enumerate(ordinary):
        star=stars[j];outer=[1<<i for i in range(13) if not star>>i&1]
        for i in range(13):
            if star>>i&1:
                for a,b in combinations(outer,2):cnf.append(distinguishing(r,1<<i,a|b))
    for p in P:
        j=(p>>13).bit_length()-1
        if j in ordinary:continue
        pp=p&8191;opts=[]
        for i in ordinary:
            u=v.id(('comp',p,i));opts.append(u)
            negatives={n&8191 for n in N if n&(1<<(13+j)) and n&stars[i]}
            for n in negatives:cnf.append([-u,*distinguishing(3,pp,n)])
        cnf.append(opts)
    with Solver(name='cadical195',bootstrap_with=cnf) as s:
        s.conf_budget(5000); answer=s.solve_limited()
        if answer is not True:return answer,[]
        model=set(s.get_model())
        return True,[[raw[i]for i,a in enumerate(rr)if a in model]for rr in role]
if __name__=='__main__':
    for o in combinations(range(7),3):
        ans,slots=solve(o);print(o,ans,slots,flush=True);assert ans is False,o
