from pathlib import Path
from inputs import P,N,stars
home=Path(__file__).resolve().parent
from itertools import combinations
from collections import Counter
def enumerate_roles():
 stats=Counter()
 for row in (home/'w12_zero_cert.txt').read_text().splitlines():
  e,*B=map(int,row.split());fixed=[v for j,v in enumerate(stars) if not e>>j&1]
  for idx in combinations(range(12),4):
   private=[B[j] for j in idx];F=[B[j] for j in range(12) if j not in idx]
   if any(not any(all(any(v&p and not v&n for v in F) for n in N if (n>>13)&(p>>13) and n&t)for t in fixed)for p in P if (p>>13)&e):continue
   if any(not any(v&(1<<p) and not v&((1<<x)|(1<<y))for v in private) for t in fixed for p in range(13)if t>>p&1 for x,y in combinations([x for x in range(13)if not t>>x&1],2)):continue
   ls=[1<<j for j in range(7)if e>>j&1]
   def pack(r):return sum(bool(f&r)<<j for j,f in enumerate(F))+sum(bool((r>>13)&l)<<(8+j)for j,l in enumerate(ls))
   pos={pack(p)for p in P if p>>13&e};neg={pack(n)for n in N if all(v&n for v in fixed)}
   ps=sorted(p for p in pos if not any(q!=p and not q&~p for q in pos));ns=sorted(n for n in neg if not any(q!=n and not n&~q for q in neg))
   dif={p&~n for p in ps for n in ns}
   if 0 in dif:continue
   ess=sum(1<<i in dif for i in range(12));yield e,B,idx,ess,ps,ns
if __name__=='__main__':
 import json
 a=list(enumerate_roles());Path('hub.json').write_text(json.dumps(a));print(len(a),Counter(x[3] for x in a))
