from pathlib import Path
from tempfile import TemporaryDirectory
from subprocess import run, PIPE
from guardhub import enumerate_roles

root=Path(__file__).resolve().parent
ref=root/'cut-proj.cpp'
roles=list(enumerate_roles())
assert len(roles)==4 and all(essential==12 for e,B,I,essential,ps,ns in roles)
with TemporaryDirectory() as td:
 exe=Path(td)/'frontier'
 run(['g++','-O2','-std=c++17',str(ref),'-o',str(exe)],check=True)
 for e,B,I,essential,ps,ns in roles:
  s=' '.join(map(str,[12,4,len(ps),len(ns),*ps,*ns]))
  v=run([str(exe)],input=s,text=True,stdout=PIPE,check=True)
  assert tuple(map(int,v.stdout.split()))==(9,0)
  print(e,B,I,essential,9,0,flush=True)
