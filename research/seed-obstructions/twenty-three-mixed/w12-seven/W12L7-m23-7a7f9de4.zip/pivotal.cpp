#include "pivotal.hpp"
using namespace std;
template<size_t W> auto read_masks(const char* path){
 ifstream fs(path);vector<array<int,W>> data;array<int,W>b;
 while(fs>>b[0]){for(int i=1;i<W;i++)if(!(fs>>b[i]))abort();data.push_back(b);}
 return data;
}
template<size_t W> vector<int> project(const array<int,W>&b,const vector<int>&rows,bool point){
 vector<int> out;
 for(auto raw:rows){int v=0;for(int j=0;j<W;j++)if(b[j]&(point?(raw&8191):(raw>>13)))v|=1<<j;out.push_back(v);}
 return out;
}
int main(int argc,char**argv){
 if(argc!=5)return 2;ios::sync_with_stdio(false);cin.tie(nullptr);
 ifstream s(argv[1]);int np,nn;s>>np>>nn;if(np!=28||nn!=245)return 3;
 vector<int> rows(np+nn);for(auto&r:rows)s>>r;
 auto pt=read_masks<12>(argv[2]);auto ls=read_masks<8>(argv[3]);
 vector<vector<int>> pm,lm;for(auto&b:pt)pm.push_back(project(b,rows,true));for(auto&b:ls)lm.push_back(project(b,rows,false));
 int ordinary[74]={}; ifstream labels(argv[4]);int ix,ex,mx;while(labels>>ix>>ex>>mx) ordinary[ix]=127^ex; int stars[7]={708,1416,2832,5664,3137,6274,4357}; int i,j;uint64_t total=0,yes=0;vector<int> type(20);fill_n(type.begin(),12,1);
 vector<int>P,maximal; pair<int,int> last={-1,-1}; unsigned a,b,c0,d,e; while(cin>>i>>j>>a>>b>>c0>>d>>e){
  if((a|b|c0|d|e)!=(1u<<20)-1 || ((a&b)|(a&c0)|(a&d)|(b&c0)|(b&d)|(c0&d)|((a|b|c0|d)&e)))return 4;
  if(last!=make_pair(i,j)){for(auto& cache:frontierlib::failed)cache.clear();last={i,j};cerr<<"BEGIN "<<i<<" "<<j<<" "<<total<<endl;P.clear();maximal.clear(); vector<int>N;
  for(int k=0;k<np+nn;k++)(k<np?P:N).push_back(pm.at(i)[k]|(lm.at(j)[k]<<12));
  sort(P.begin(),P.end());P.erase(unique(P.begin(),P.end()),P.end());
  sort(N.begin(),N.end(),[](int a,int b){return __builtin_popcount((unsigned)a)>__builtin_popcount((unsigned)b);});
  for(int n:N)if(none_of(maximal.begin(),maximal.end(),[&](int q){return !(n&~q);}))maximal.push_back(n);}
  frontierlib::unlocked_star=0;for(size_t row=0;row<P.size();row++)if(P[row]&(1<<(12+j)))frontierlib::unlocked_star|=1ull<<row;frontierlib::Search c; for(int t=0;t<20;t++)c.stage.push_back((a>>t&1)?0:(b>>t&1)?1:(c0>>t&1)?2:(d>>t&1)?3:4);vector<int> roles(20);int pair=0;for(int t=0;t<7;t++)if(ordinary[i]>>t&1){int slot=find(pt[i].begin(),pt[i].end(),stars[t])-pt[i].begin();if(slot>=12)return 5;roles[slot]=++pair;roles[12+t]=++pair;}if(c.treecut(P,maximal,20,4,type,roles)){cout<<i<<' '<<j<<' '<<a<<' '<<b<<' '<<c0<<' '<<d<<' '<<e<<endl;yes++;}
  if((++total%1000)==0)cerr<<total<<" "<<yes<<endl;
 }
 cerr<<"DONE "<<total<<" "<<yes<<endl;
}
