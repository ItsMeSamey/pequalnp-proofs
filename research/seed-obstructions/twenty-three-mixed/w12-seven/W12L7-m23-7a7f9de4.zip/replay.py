from collections import defaultdict
from itertools import combinations_with_replacement
from pathlib import Path
import subprocess, tempfile, os, sys
from inputs import P,N,stars
from samples import actions
src=Path(__file__).resolve().parent
def rows(name):
 return [list(map(int,r.split()))for r in (src/name).read_text().splitlines()]
def line(v):return ' '.join(map(str,v))+'\n'
for x,y in combinations_with_replacement(range(13),2):
 assert any(not ((1<<x)|(1<<y))&~row for row in N)
G=actions(P,N)
def canonical(b):return min(tuple(sorted(f[x]for x in b))for f in G)
records=rows('w12_two_masks.txt')
banks=sorted({canonical(b)for _,*b in records+rows('w12_zero_cert.txt')})
cases=set()
for e,*b in records:
 dest=canonical(b);i=banks.index(dest)
 for f in G:
  if tuple(sorted(f[x]for x in b))!=dest:continue
  h=sum(1<<stars.index(f[s])for j,s in enumerate(stars)if e>>j&1)
  cases.add((i,h))
assert len(records)==204 and len(cases)==len({i for i,e in cases})==70 and len(banks)==74
out=Path(sys.argv[1] if len(sys.argv)>1 else tempfile.mkdtemp()).resolve();out.mkdir(parents=True,exist_ok=True)
def write(name,lines):(out/name).write_text(''.join(map(line,lines)))
write('raw',[[len(P),len(N),*sorted(P),*sorted(N)]])
write('points',banks);write('lines',[[*[1<<j for j in range(7)],1<<t]for t in range(7)])
write('labels',[(i,e,e)for i,e in sorted(cases)])
jobs=[]
for i,e in sorted(cases):
 b=banks[i];assert len(set(b))==12 and all(b)
 assert all(s&~v for j,s in enumerate(stars)if e>>j&1 for v in b)
 fixed=((127^e)<<12)|sum(1<<b.index(s)for j,s in enumerate(stars)if not e>>j&1)
 for t in range(7):
  if e>>t&1:jobs.append((i,t,fixed,(e^(1<<t))<<12,(1<<19)|(1<<(12+t))))
write('jobs',jobs);assert len(jobs)==350
solver=sys.argv[2] if len(sys.argv)>2 else 'cached-fixed'
assert solver in ('cached-fixed','pivotal')
for name in ('fixed',solver):
 subprocess.run(['g++','-O2','-std=c++20',str(src/(name+'.cpp')),'-o',out/name],check=True)
with open(out/'jobs')as f,open(out/'partitions','w')as g,open(out/'partitions.log','w')as h:
 subprocess.run([out/'fixed','raw','points','lines','12','8','4','300000'],cwd=out,stdin=f,stdout=g,stderr=h,check=True)
assert (out/'partitions.log').read_text().splitlines()[-1]=='DONE 350 0 0'
parts=defaultdict(set);count=0
for row in (out/'partitions').read_text().splitlines():
 v=row.split()
 if v[0]=='CASE':i,t=map(int,v[1:]);parts[i,t]
 else:
  a=list(map(int,v));assert len(a)==5;count+=1
  b=[m^((1<<(12+t))|(1<<19))if bool(m>>(12+t)&1)!=bool(m>>19&1)else m for m in a]
  parts[i,t].add(tuple(min(a,b)))
total=sum(map(len,parts.values()));print('partitions',count,total,flush=True)
assert (len(parts),count,total)==(350,219444,119814)
write('exact-jobs',[(i,t,*p)for (i,t),ps in sorted(parts.items(),key=lambda kv:len(kv[1])) for p in sorted(ps)])
with open(out/'exact-jobs')as f,open(out/'solutions','w')as g,open(out/'exact.log','w')as h:
 subprocess.run([out/solver,'raw','points','lines','labels'],cwd=out,stdin=f,stdout=g,stderr=h,check=True)
assert not (out/'solutions').read_text().strip()
assert (out/'exact.log').read_text().splitlines()[-1]=='DONE 119814 0'
print('all 350 directional cases excluded')
