#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
using M=array<uint64_t,5>;
inline bool clash(const M&a,const M&b){return (a[0]&b[0])&&((a[1]&b[1])|(a[2]&b[2])|(a[3]&b[3])|(a[4]&b[4]));}
inline void add(M& a,const M&b){for(int k=0;k<5;k++)a[k]|=b[k];}
template<int W> struct Marked{array<int,W> v{},ids{};bool bad=false;};
struct Rel{int p,n;M mark;};
template<int W> vector<Marked<W>> readbank(const char*path,const vector<int>&pos,const vector<int>&neg,bool pt,map<M,int>&ids,vector<M>&table){
 map<pair<int,int>,M> rel;
 for(int i=0;i<28;i++)for(int j=0;j<245;j++)if(!(pt?((pos[i]&~neg[j])>>13):((pos[i]&~neg[j])&8191))){
  int p=pt?pos[i]&8191:pos[i]>>13,n=pt?neg[j]&8191:neg[j]>>13;
  auto& a=rel[{p,n}];a[0]|=uint64_t(1)<<i;a[1+j/64]|=uint64_t(1)<<(j%64);
 }
 vector<Rel> rows;for(auto&[k,m]:rel)rows.push_back({k.first,k.second,m});
 ifstream f(path);if(!f)abort();vector<Marked<W>> banks;Marked<W> bk;
 while(f>>bk.v[0]){
  for(int a=1;a<W;a++)if(!(f>>bk.v[a]))abort();
  array<M,W> m{};bk.bad=false;array<int,8192> proj{}; // masks 0..127 on the line side or 0..8191 on the point side
  if(pt){ // Point banks are few, and the negative point rows repeat.
   for(auto&r:rows)for(int i=0;i<W;i++){proj[r.p]|=bool(r.p&bk.v[i])<<i;proj[r.n]|=bool(r.n&bk.v[i])<<i;}
  }else{
   for(int k=0;k<128;k++)for(int i=0;i<W;i++)proj[k]|=bool(k&bk.v[i])<<i;
  }
  for(auto&r:rows){
   int d=proj[r.p]&~proj[r.n];
   if(!d){bk.bad=true;break;}
   if(has_single_bit((unsigned)d))add(m[countr_zero((unsigned)d)],r.mark);
  }
  for(int i=0;i<W&&!bk.bad;i++)for(int j=0;j<i;j++)if(clash(m[i],m[j])){bk.bad=true;break;}
  for(int i=0;i<W;i++){auto[it,inserted]=ids.try_emplace(m[i],table.size());if(inserted)table.push_back(m[i]);bk.ids[i]=it->second;}
  banks.push_back(bk);
 }
 return banks;
}
int main(int argc,char**av){
 ifstream f(av[1]);int pn,nn;f>>pn>>nn;if(pn!=28||nn!=245)abort();
 vector<int> pos(pn),neg(nn);for(int&x:pos)f>>x;for(int&x:neg)f>>x;
 map<M,int> ids;vector<M> table;
 auto p=readbank<12>(av[2],pos,neg,true,ids,table);auto l=readbank<10>(av[3],pos,neg,false,ids,table);
 long long blocked=0,keep=0;
 for(auto&b:p){
  if(b.bad){blocked+=l.size();continue;}
  vector<unsigned char> fails(table.size());
  for(unsigned k=0;k<table.size();k++)for(int i:b.ids)if(clash(table[i],table[k])){fails[k]=1;break;}
  for(auto&a:l){
   bool bad=a.bad;for(int i:a.ids)if(fails[i]){bad=true;break;}
   if(bad){blocked++;continue;}
   keep++;for(int m:b.v)cout<<m<<' ';for(int m:a.v)cout<<m<<' ';cout<<'\n';
  }
 }
 cerr<<p.size()<<" x "<<l.size()<<" blocked "<<blocked<<" survivors "<<keep<<" mark profiles "<<table.size()<<endl;
}
