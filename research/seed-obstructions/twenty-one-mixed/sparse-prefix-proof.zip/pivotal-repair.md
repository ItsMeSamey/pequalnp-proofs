# A local test on pivotal incidences

Choose a terminal-clean separator minimizing total size and then number of dirty mixed gates. For a live dirty mixed gate G let S be the set of incidence positives lost from the final output when G is replaced by constant zero, and let q be the number of its distinct immediate consumer gates. Every originally false row stays false by monotonicity.

Simplify the circuit after setting G to zero. G disappears, and every one of the q consumers also disappears as a binary operation. This saves at least q+1 gates, counted before any other reachable simplification. A subset of the 28 incident pairs can be restored safely using its raw endpoint ANDs; no negative contains both endpoints of an incidence. More economically, partition the |S| edges into stars at a minimum vertex cover of their bipartite graph. There are at most ν(S) nonempty stars, where ν(S) denotes that minimum cover size. For a star with t edges the opposite raw coordinates can be ORed in t−1 gates and compared with the raw center in one AND. Attaching every star as another disjunct costs at most one more OR per star. The total repair cost is at most |S|+ν(S).

All new comparison gates are clean, all added arm gates are pure, and eliminating G removes a dirty mixed gate. Any other dirty wire becoming clean after the restriction can be hoisted by the terminal-clean normalization without increasing size or introducing dirty mixed gates, because bypasses lower the wire functions and new gates only combine clean disjuncts. Hence |S|+ν(S)≥q+2. In particular every dirty mixed gate is pivotal on at least two positives. A gate pivotal only on a pair of incidences with a common endpoint has at most one consumer. A gate pivotal on two disjoint incidences has at most two.

When a direct consumer is a terminal AND and at least two terminal disjuncts existed, one final OR also disappears after this terminal becomes zero. It is distinct from G and its immediate consumers, because dirty gates in terminal-clean form do not directly feed the final ORs. This strengthens the bound to |S|+ν(S)≥q+3. If all original disjuncts disappear, the star aggregate needs no attachment to the old false output, which only helps.

The same argument applies to any proposed raw-rectangle repair of S charging its actual gates plus attachments, and can undercut |S|+ν(S) when some surviving pure star arms already exist.

## Joint deletion

For any nonempty set A of dirty mixed gates, define C(A) to be all immediate consumer gates of elements of A, and T(A) to be the number of terminal ANDs among these consumers. Force every member of A to zero simultaneously and let S(A) be the lost positives. All binary operations in A∪C(A) disappear. A consumer outside A either becomes zero at an AND or is bypassed at an OR, regardless of overlap among consumers. With r output terms at least min(T(A),r−1) gates in the final OR tree disappear, after freely reassociating it. Thus every such A satisfies

    |S(A)| + ν(S(A)) ≥ |A∪C(A)| + min(T(A),r−1) + 1.

Counting the complete simplification to a pruned DAG can further increase the right-hand side. This holds for every A in the same lexicographic minimum, with one fixed terminal-clean circuit.

A terminal with j≥1 exclusively used dirty input gates has exclusive-positive set S, consisting of the positives accepted by this term alone. Zeroing those j gates loses exactly S. At r≥2 it saves at least j+2 gates including the terminal and an output OR. Therefore |S|+ν(S)≥j+3. In particular two private dirty parents require at least three exclusive positives, and one private dirty parent cannot support just two exclusive incidences sharing a center.
