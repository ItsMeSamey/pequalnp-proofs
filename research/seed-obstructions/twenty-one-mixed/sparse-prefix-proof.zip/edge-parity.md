# An internal-wire bound for odd wire counts

Use the definitions and minimum-total/minimum-dirty convention of edge-density.md. Every one-wire component needs a terminal pairing one of its two nonisolated vertices to another nonisolated component. Let h be the number of distinct terminals having a one-wire component at one end and a different nonisolated component at the other. One such terminal serves at most two one-wire components, so 2h≥s1. Its endpoints are all distinct by terminal matching. All 2h endpoints are unavailable as partners for isolates. Therefore d=n+i≤2n−2h≤2n−2⌈s1/2⌉.

Consequently d is bounded by an even integer no greater than 2(e+s1+s2)−s1≤3e, using the component inequalities n≤e+s1+s2 and s1+2s2≤e. In particular d≤2⌊3e/2⌋; at three internal wires the largest possible dirty count is eight. This applies irrespective of the assumed mixed-gate floor.
