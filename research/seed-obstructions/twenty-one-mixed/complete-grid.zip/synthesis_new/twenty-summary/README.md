# Twenty mixed gates in a residual circuit of size at most 33

The architecture matrix is in syn_bounds/twenty/README.md. The six cells excluded there leave P=11. The seven-line proof indexed in seven-lines.md and the ten-line matched-pair normalization exclude two more cells. The eight-line proof below excludes a ninth cell. The final eleven-point, nine-line case is excluded in nine-lines.md. Every separator of residual size at most 33 therefore has at least 21 mixed gates.

| Line boundary width | Extra reads | Further exact exclusions |
|---|---:|---|
| 7 | 3 | All cases covered in seven-lines.md; independent review passed. |
| 8 | 2 | All 27 nine-paid point banks paired with every possible eighth line mask. The 354 star-local ten-paid point banks also fail against all 99 affordable eighth masks. Independent review excludes all 35 four-label and all 35 three-label extra masks. For the remaining 21 raw pairs independent reviewers verified both placement and exhaustive saturation (syn_mitm/eight-two/pair-support-certificate.zip). |
| 9 | 1 | Exactly eleven paid point gates and two paid line gates are required. The remaining line banks have two disjoint pair extras (105 possibilities). The exceptional region contains one ordinary raw label. Two exterior point wires carry distinct pair-safe four-point stars. All 2,668 star-local banks at cost at most eleven fail. The remaining pattern would require seven paid outputs including a nonlocal signal, four raw singleton selections, and two literal star trees. The independent source and final raw-pair checks in nine-lines.md exclude this pattern. |
| 10 | 0 | All line banks excluded. The final 105 consist of three disjoint pairs; their normalized all-outer cases are both UNSAT (syn_cover/line20/matched-normalization.md). |

With seven lines, unfold any repeated point input into the excluded P-independent case of at most two surplus reads. The final two signatures were {1,1,0} and {1,e,0} with e≥2, where the numbers count original raw lines resident in each region. Complete exclusions appear in one-surplus/promote-one-ordinary.md and one-surplus/two-private-five.md, together with syn_mitm/promotion.md and the two-arm finite certificate. Existence of an unrestricted witness remains open.

The seven-line proofs are under synthesis_new/one-surplus, syn_mitm/twoarms/cert and syn_quotients/special3_certificate.zip. The other packages are under syn_sat/regions, syn_bounds/twenty-nine/nine-point-one-surplus, synthesis_new/twenty-ten-lines and syn_cover/line20.
