# Twenty-one mixed gates at residual budget 33

There are twelve available pure gates and k=22−P−L surplus operand uses. The certified point-projection floors at widths 11,12,13,14 are 9,5,0,0. The thirteen singleton point wires and two additional free wires also give floor zero at width 15. The line count requires at least L−7 paid gates. The table gives the raw necessary point-cost intervals before applying the architecture results in the last column.

| P | L | k | Paid point gates | Status |
|---:|---:|---:|---:|---|
| 11 | 7 | 4 | 9–12 | Nine and ten paid gates excluded; 11–12 remain |
| 11 | 8 | 3 | 9–11 | Nine and ten paid gates excluded; exactly 11 remain |
| 11 | 9 | 2 | 9–10 | Excluded by the nine- and ten-paid replays |
| 11 | 10 | 1 | 9 | Excluded by all 9,938 paired-frontier checks |
| 11 | 11 | 0 | empty | Excluded by cost |
| 12 | 7 | 3 | 5–12 | Excluded by the width-twelve three-surplus seven-line proof in syn_mitm/width12-k3 |
| 12 | 8 | 2 | 5–11 | Five paid gates excluded; 6–11 remain |
| 12 | 9 | 1 | 5–10 | Five paid gates excluded; 6–10 remain |
| 12 | 10 | 0 | 5–9 | Five paid gates excluded; 6–9 remain |
| 13 | 7 | 2 | 0–12 | Excluded, seven-line k≤2 |
| 13 | 8 | 1 | 0–11 | Excluded, eight-line k≤1 |
| 13 | 9 | 0 | 0–10 | Excluded by the nine-line transfers and width-thirteen four-private-group bound |
| 14 | 7 | 1 | 0–12 | Excluded, seven-line k≤2 |
| 14 | 8 | 0 | 0–11 | Excluded, eight-line k≤1 |
| 15 | 7 | 0 | 0–12 | Excluded, seven-line k≤2 |

P13/L9 ordinary banks with two adjacent pairs have cost two, so at most ten point gates. The missing-singleton banks cost three, so allow at most nine point gates. Four private groups each require a member containing its entire star. No free point mask contains any of the seven residual stars, so the zero-point-cost bank fails. The new syn_quotients/fourgroups11_w13 certificate gives an eleven-paid-point lower bound for all four-private thirteen-slot banks. Both remaining subcases therefore exceed the available budget. A zero or repeated line signature should be simplified first. At P13/L9 a duplicate routes to the excluded P-independent eight-/seven-line theorem. An empty signature may be set to zero and propagated in the read-once tree. The remaining tree has at most eight line occurrences; eight distinct signatures route to the eight-line read-once theorem, and seven distinct signatures give at most one surplus use after merging a duplicate. This reasoning is independent of surviving point width.

At P12 the certified minimum consists of five point banks. The two with masks 4416 and 641 fail the point-only cotree test at k≤1. local.py decodes all pinned samples. A positive line singleton dominated by a negative line set cannot be distinguished by any line signal. After lowering each point wire to the disjunction of its singleton signature, the point differences in those pairs force singleton sensitivities in the mixed cone. Simultaneous sensitivities at a positive (negative) force an AND (OR) least common ancestor in any tree region containing the two point wires. Split the point variables across at most k+1 regions. Each class must have a compatible read-once tree, checked by recursive component splitting. For each of the two banks there are six doubly constrained pairs and none of 2,047 nontrivial unoriented bipartitions passes. The three remaining banks pass this necessary test, and no existence follows.

The exact mixed-frontier solver in exact12.cpp now excludes all five minimum point banks at P12/L8, crossed with all 128 eighth signatures including duplicates and zero. Its 640 cases exhaust the eight-wire line domain. Thus constructive experiments on this plane should start at six point gates. P12/L9 likewise requires six paid point gates. The three point banks surviving the point-only filter were crossed with every pair of extra line signatures, including zero and duplicates, and with the 24 missing-singleton bases. All 21,492 genuine and 3,348 redundant labelled cases exhaust the frontier. For point cost six, sixseeds.py produces 35 concrete admissible point banks by replacing one output of a minimum-five circuit with one further OR of available wires; all five starting point circuits also use OR gates only. The exact five-bank equality classification proves these 35 have minimum cost six. They are an initial search set. The cheapest genuine line choices are the 21 raw pairs at L8 and the 315 cost-two banks at L9. The earlier P12/L8 heuristic under syn_near/planes targeted 19 mixed gates. The width12-search edits optimize a 28-gate formula over a fixed width-12 point bank and seven raw lines and do not exhaust 21-mixed architectures.


## Raw line bases of size at most ten

Every feasible ten-wire line multiset contains an inclusion-minimal line set of size at most ten. The size-seven basis consists of the raw singletons, there are no further size-eight bases, and there are 24 minimal size-nine bases. min10.py imposes all raw point-dominated line obligations on 127 Boolean signature-selection variables. Bound their cardinality by ten and block the seven-singleton set and all 24 nine-bases. Every remaining model has exactly ten distinct masks and is minimal. Enumerating and blocking each gives 437 lines in tenminimal: 361 with six singleton labels, 60 with five and 16 with four.

For the three width-twelve minimum-five point banks that pass the point cotree filter, one row represents all three under simultaneous sample symmetries and its stabilizer has eight elements. For ordinary ten-wire banks choose three unordered extras with repetition from all 128 masks, including zero. This gives 357,760 multisets, or 49,474 stabilizer orbits. Extend each nine-basis by an arbitrary tenth mask and add the 437 ten-bases to obtain the other list with 3,509 multisets (521 orbits). The 24 extensions supplying the missing singleton also occur in the ordinary list. Thus the full necessary line-only domain contains 361,245 distinct multisets. Removing these duplicate trials is optional.


Every one of the 49,474 ordinary and 521 other ten-wire representatives exhausted its read-once frontier by the first gate. Together with the cotree obstruction on the other two point banks this excludes the five-point-gate allocation at P12/L10 independently of line cost. At P12/L7 all five minimum point banks against the raw line set exhaust their three-surplus frontiers. Hence all m21 width-twelve candidates need at least six paid point gates.

At P11/L7, the 27 certified minimum point banks give three distinct geometries; their four-surplus frontiers reject them by gates 7, 7, and 8.


At P11/L10 at most nine paid point gates are available, forcing its minimum and exactly three paid line gates. Since all ten line wires must be selected, start from the seven raw lines and append three gates; retain all three outputs, including zero or duplicate signatures. The 8,275 possible multisets and 27 point banks form 223,425 labeled cases. All 9,938 simultaneous orbit representatives exhaust the one-surplus frontier. This excludes the entire P11/L10 cell at m21.

The 437 new ten-mask minimal line banks form 29 sample-symmetry classes. Their exact minimum paid line costs are five for 300 labeled banks (17 orbits) and six for 137 banks (12 orbits). For a cost target through six, every required nonraw mask is a distinct paid gate. Enumerate every possible set of the remaining zero, one or two hidden masks and compute the closure of the raw masks inside the allowed output and hidden set. Binary intersections and unions give the necessary singleton-domain price, and the same closure restricted to unions gives an actual OR-only line circuit for each representative at that price. tenprices.py / tenprices give the replay and representatives. In a P12/L10 search these line orbits can be combined with cost-six point banks; cost-five line banks also allow a seventh paid point gate.


At P11/L8 the nine-paid point candidates allow an eighth line mask of size at most four (at most three line gates), or a duplicate or zero signature. The 99 possibilities against 27 point banks reduce to 150 joint representatives. All three-surplus frontiers exhaust, so at least ten paid point gates are needed.


At P11/L9 the nine-paid candidates would allow line cost through three. All 2,069 affordable nine-line multisets and 27 minimum point banks reduce to 2,604 paired geometry representatives. Every two-surplus frontier exhausts. P11/L9 therefore forces exactly ten paid point gates and two paid line gates. Across all m21 widths the point cost is at least ten at width eleven, or at least six at width twelve. The only remaining candidates occur at those two widths, and the eleven-point ten-line plane is excluded.


The independent ten-paid global result excludes every actual non-star-local W11 bank. At P11/L7 the 354 affordable star-local ten-paid banks collapse to 23 simultaneous geometry representatives and their four-surplus frontiers all exhaust. Thus at least eleven paid point gates are required in this cell. The portable local_ten.py script reproduces this check with argument 7 and also supports the corresponding L8 and L9 correct-surplus cases.

At P11/L9 ten-paid point banks are also excluded. The 354 affordable star-local point banks and 540 two-paid-line multisets give 191,160 labeled cases and 8,466 joint representatives. The two-surplus mixed frontier exhausts in each representative. The independent ten-paid point theorem excludes any non-star-local bank, while the preceding nine-paid replay already allowed all three-paid-line banks. Therefore this entire cell is empty under the 33-gate cap.

At P11/L8 all 354 star-local banks through ten point gates crossed with all 64 eighth masks available at line cost through two exhaust their three-surplus frontiers (22,656 labeled, 1,070 geometry representatives). Combined with the nine-paid replay at line cost three and the independent nonlocal point exclusion this forces exactly eleven paid point gates and one paid line gate.
