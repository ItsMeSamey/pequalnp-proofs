from samples import actions,raw_samples
from instance import rows,raw,stars
from pathlib import Path
import sys
work=Path(sys.argv[1])
G=actions(*raw_samples(Path(__file__).with_name('L-meta-18968.json')))
for E in (15,23,27,46,83):
    f=[x for j,x in enumerate(stars) if not E>>j&1]
    base={g[x] for g in G for x in raw}|{v for v in range(8192) if any(v&~t==0 for t in f)}
    with (work/f'private8-{E}.data').open('w') as o:
        print(*f,len(base),*sorted(base),file=o)
        for a,n in rows:print(a,n,file=o)
