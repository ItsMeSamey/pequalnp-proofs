from itertools import combinations
from random import Random
from pathlib import Path
from subprocess import run
import sys
g=Random(9621); rows=[]
for _ in range(200):
    w=6;layers=[list(combinations(range(w),k)) for k in range(w+1)]
    def m(t):return sum(1<<i for i in t)
    p=g.sample(list(map(m,layers[3])),g.randrange(1,8));n=g.sample(list(map(m,layers[2])),g.randrange(1,10))
    if g.randrange(2)==0:
        mid=list(map(m,layers[3]));g.shuffle(mid);p,n=mid[:10],mid[10:]
    if g.randrange(2)==0:
        p=[v|(2 if v&1 else 0) if v&1 else v&~2 for v in p];n=[v|(2 if v&1 else 0) if v&1 else v&~2 for v in n]
    if any(a&~b==0 for a in p for b in n):continue
    rows.append(' '.join(map(str,[len(p),len(n),*p,*n])))
data='\n'.join(rows)+'\n'
def get(exe):
    b=run([exe,'3','3','2'],input=data,text=True,capture_output=True,check=True)
    return [r.split()[0] for r in b.stdout.splitlines()]
a=get(sys.argv[1]);b=get(sys.argv[2]);assert a==b and len(a)==len(rows) and set(a)=={'0','1'}
print('six-variable small cases',len(a),'positive',a.count('1'),'negative',a.count('0'))
