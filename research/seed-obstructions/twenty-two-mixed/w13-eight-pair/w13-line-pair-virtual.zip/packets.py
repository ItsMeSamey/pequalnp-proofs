"""Lift permitted outside slot supports to physical multisets, canonicalize joint symmetry."""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from collections import Counter
from instance import stars
from replay import groups,make
import sys
path=Path(sys.argv[1])
def completed(bank):
    missing=13-len(bank)
    assert missing>=0
    for fill in combinations_with_replacement(sorted({0,*bank}),missing):
        yield tuple(sorted((*bank,*fill)))
def paired(E,allbank):
    masks=[sum(1<<i for i in j) for j in combinations([i for i in range(7) if E>>i&1],2)]
    for b in completed(allbank):
        images=[tuple(sorted(pm[x] for x in b)) for pm,lm in groups]
        for m in masks:
            yield min((t,lm[m]) for t,(_,lm) in zip(images,groups))
if __name__=='__main__':
    seen=set();hist=Counter()
    if sys.argv[2]=='10':
        for line in (path/'literal10').read_text().splitlines():
            E,n,*b=map(int,line.split());assert n==len(b)
            hist[E,len(b)]+=1;extra=[v for j,v in enumerate(stars) if not E>>j&1]
            seen.update(paired(E,b+extra))
    elif sys.argv[2]=='8':
        for E in (15,23,27,46,83):
            for line in (path/f'priv8-{E}').read_text().splitlines():
                b=list(map(int,line.split()));assert len(b)==13
                hist[E,len(b)]+=1;seen.update(paired(E,b))
    else:
        for E in (15,23,27,46,83):
            for k in (0,1,2):
                for line in (path/f'comp9-{E}-{k}').read_text().splitlines():
                    b=list(map(int,line.split()));hist[E,len(b)]+=1
                    seen.update(paired(E,b))
    print('models',sorted(hist.items()),'orbits',len(seen),flush=True)
    with (path/f'private-{sys.argv[2]}.in').open('w') as f, (path/f'private-{sys.argv[2]}.reps').open('w') as qq:
        for b,m in sorted(seen):
            print(*b,m,file=qq);f.write(make(b,m))
