#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
using Cov=array<uint64_t,21>;
using Five=array<int,5>;
struct Value{int m;uint64_t ext;};
Value combine(Value a,Value b,int op){return op?Value{a.m|b.m,a.ext|b.ext}:Value{a.m&b.m,a.ext&b.ext};}
bool good(Value v,int target){return v.m==target&&!v.ext;}
int main(int argc,char**argv){
    ifstream data(argv[1]),outs(argv[2]);int n;array<int,3>T;for(int&z:T)data>>z;data>>n;
    vector<int> base(n);for(int&x:base)data>>x;
    int p,neg;array<Cov,8192> have{};int r=0;
    while(data>>p>>neg){for(int x=1;x<8192;x++)if((x&p)&&!(x&neg))have[x][r/64]|=1ull<<(r%64);r++;}
    if(r!=1323)return 2;
    set<Five> private_options;array<vector<array<int,2>>,3> pairs;
    for(int t=0;t<3;t++){
        vector<Value> v;
        for(int m:base){
            uint64_t mask=0;int id=0;
            for(int i=0;i<13;i++)if(!(T[t]>>i&1))for(int j=i+1;j<13;j++)if(!(T[t]>>j&1)){
                if(m&((1<<i)|(1<<j)))mask|=1ull<<id;
                id++;
            }
            v.push_back({m,mask});
        }
        for(int a=0;a<n;a++)for(int b=a;b<n;b++){
            if(good(combine(v[a],v[b],0),T[t])||good(combine(v[a],v[b],1),T[t]))pairs[t].push_back({v[a].m,v[b].m});
            for(int c=b;c<n;c++){
                array<Value,3>w{v[a],v[b],v[c]};bool ok=false;
                for(int k=0;k<3&&!ok;k++)for(int x=0;x<2&&!ok;x++)for(int y=0;y<2&&!ok;y++)
                    ok=good(combine(w[k],combine(w[(k+1)%3],w[(k+2)%3],x),y),T[t]);
                if(ok){Five f{v[a].m,v[b].m,v[c].m,T[(t+1)%3],T[(t+2)%3]};sort(f.begin(),f.end());private_options.insert(f);}
            }
        }
    }
    for(int t=0;t<3;t++)for(auto a:pairs[(t+1)%3])for(auto b:pairs[(t+2)%3]){
        Five f{T[t],a[0],a[1],b[0],b[1]};sort(f.begin(),f.end());private_options.insert(f);
    }
    vector<pair<Five,Cov>> options;
    for(auto f:private_options){Cov c{};for(int x:f)for(int k=0;k<21;k++)c[k]|=have[x][k];options.push_back({f,c});}
    set<array<int,13>> result;array<int,8>b;int seen=0;
    while(outs>>b[0]){
        for(int k=1;k<8;k++)if(!(outs>>b[k]))return 3;
        seen++;Cov missing;missing.fill(~0ull);missing[20]=(1ull<<43)-1;
        for(int x:b)for(int k=0;k<21;k++)missing[k]&=~have[x][k];
        for(auto&[f,c]:options){
            bool ok=true;for(int k=0;k<21&&ok;k++)ok=!(missing[k]&~c[k]);if(!ok)continue;
            array<int,13> bank;copy(b.begin(),b.end(),bank.begin());copy(f.begin(),f.end(),bank.begin()+8);sort(bank.begin(),bank.end());result.insert(bank);
        }
    }
    for(auto z:result){for(int x:z)cout<<x<<' ';cout<<'\n';}
    cerr<<"base "<<n<<" candidates "<<options.size()<<" outside "<<seen<<" joint "<<result.size()<<'\n';
}
