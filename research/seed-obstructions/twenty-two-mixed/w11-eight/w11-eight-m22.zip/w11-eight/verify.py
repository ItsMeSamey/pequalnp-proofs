"""Rebuild the genuine eight-line domains at point prices nine and ten."""
from collections import Counter
from itertools import combinations_with_replacement,permutations
from pathlib import Path
import subprocess,tempfile,sys
from input import raw_samples
here=Path(__file__).resolve().parent
pos,neg,_=raw_samples(here/'L-meta-18968.json')
raw=tuple(1<<i for i in range(7))
stars=[sum({r&8191 for r in pos if r&(x<<13)}) for x in raw]
inc=tuple(sum(1<<j for j,x in enumerate(stars) if x>>i&1) for i in range(13))
def move(x,perm):
    return sum(1<<j for i,j in enumerate(perm) if x>>i&1)
group=[]
for perm in permutations(range(7)):
    image=tuple(move(x,perm) for x in inc)
    if set(image)!=set(inc):continue
    pp=tuple(inc.index(x) for x in image)
    lm=tuple(move(x,perm) for x in range(128))
    def pair(r):return move(r&8191,pp)|(lm[r>>13]<<13)
    if all({pair(r) for r in rs}==rs for rs in (pos,neg)):
        group.append((pp,lm))
assert len(group)==24
points=[tuple(map(int,r.split())) for r in (here/'cost-nine-width-eleven.txt').read_text().splitlines()]
assert len(set(points))==27
def load(path):
    return {tuple(map(int,r.split())) for r in path.read_text().splitlines()}
allpoints=load(here/'cost-ten-star-local.txt')
low=set(points)
assert len(low)==27 and low<=allpoints and len(allpoints)==354
def domain(banks,maxsize):
    reps=Counter()
    for p in banks:
        images=[(tuple(sorted(move(x,pp) for x in p)),lm) for pp,lm in group]
        best=min(q for q,lm in images)
        actions=[lm for q,lm in images if q==best]
        for x in range(128):
            if not 2<=x.bit_count()<=maxsize:continue
            reps[best,min(lm[x] for lm in actions)]+=1
    return reps
def payload(rows):
    h=' '.join(map(str,(len(pos),len(neg),*sorted(pos),*sorted(neg))))
    return h+'\n'+f'{len(rows)} 11 8 4\n'+''.join(' '.join(map(str,(*p,*raw,x)))+'\n' for p,x in rows)
with tempfile.TemporaryDirectory() as tmp:
    binary=Path(tmp)/'frontier'
    subprocess.run(['c++','-std=c++17','-O3','-march=native',str(here/'frontier.cpp'),'-o',binary],check=True)
    for g,banks,limit,nrep,nlabs in [(9,low,3,83,1512),(10,allpoints-low,2,317,6867)]:
        if len(sys.argv)>1 and str(g) not in sys.argv[1:]:continue
        reps=domain(banks,limit)
        assert len(reps)==nrep and sum(reps.values())==nlabs
        r=subprocess.run([binary],input=payload(sorted(reps)),text=True,stdout=subprocess.PIPE,check=True)
        depths=list(map(int,r.stdout.split()))
        assert len(depths)==nrep and max(depths)<=22
        print('point-price',g,'representatives',nrep,'labeled',nlabs,'first-empty histogram',sorted(Counter(depths).items()),flush=True)
