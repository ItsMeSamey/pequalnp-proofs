from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys
root=Path(__file__).resolve().parent
with TemporaryDirectory() as tmp:
    d=Path(tmp)
    subprocess.run([sys.executable,root/'prepare.py',d],check=True)
    assert len((d/'c8').read_text().splitlines())==10034
    for driver,exe in [('driver.cpp','first'),('restricted-driver.cpp','last')]:
        subprocess.run(['c++','-std=c++20','-O3',root/driver,'-o',d/exe],check=True)
    def run(exe,source,flags):
        with source.open() as f:
            return subprocess.run([d/exe,d/'samples',d/'points',d/'lines',*flags],stdin=f,check=True,capture_output=True,text=True)
    first=run('first',d/'c8',[])
    assert first.stderr.splitlines()[-1]=='DONE 10034 35'
    assert first.stdout==(root/'c8-survivors').read_text()
    (d/'remaining').write_text(first.stdout)
    last=run('last',d/'remaining',['3'])
    assert last.stderr.splitlines()[-1]=='DONE 35 0' and not last.stdout
    print(first.stderr.splitlines()[-1],last.stderr.splitlines()[-1],sep='\n')
