"""Regenerate the admissible normalized point-cut domains."""
from collections import Counter
from itertools import combinations,combinations_with_replacement,permutations
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import numpy as np
from pysat.card import CardEnc
from pysat.solvers import Solver
from input import point_obligations,raw_samples
here=Path(__file__).resolve().parent
statement=here/'L-meta-18968.json'
pos,neg,_=raw_samples(statement)
raw,rows=point_obligations(statement)
stars=[sum({r&8191 for r in pos if r>>(13+j)&1}) for j in range(7)]
def image(mask,g):
    return sum(bool(mask&(1<<i))<<j for i,j in enumerate(g))
def group():
    labels=[sum(bool(t&(1<<p))<<j for j,t in enumerate(stars)) for p in range(13)]
    result=[]
    for g in permutations(range(7)):
        images=[image(a,g) for a in labels]
        if set(images)!=set(labels):continue
        p=[labels.index(a) for a in images]
        def row(x):return image(x&8191,p)|(image(x>>13,g)<<13)
        assert {row(x) for x in pos}==pos and {row(x) for x in neg}==neg
        result.append(p)
    assert len(result)==24
    granted=sorted({image(m,p) for p in result for m in raw})
    header=(here/'hereditary.hpp').read_text()
    values=list(map(int,header.split('int orbitraw[] = {')[1].split('}')[0].replace('\n','').split(',')))
    assert granted==values
    return result

def direct_costs():
    # For each possible set F of used nonsingleton raw masks, recover the
    # minimum number of distinct partner witnesses for each singleton p.
    primitive=[m for m in raw if m.bit_count()>1]
    assert len(primitive)==18
    subsets=np.arange(1<<18,dtype=np.int32)
    size=np.array([m.bit_count() for m in range(1<<18)],dtype=np.int16)
    per=np.empty((1<<18,13),dtype=np.int16)
    for j in range(13):
        p=1<<j
        ns=[n for x,n in rows if x==p]
        inc=[i for i,m in enumerate(primitive) if m&p]
        ix=np.zeros(1<<18,dtype=np.int16)
        for k,i in enumerate(inc):ix|=((subsets>>i)&1).astype(np.int16)<<k
        local=[]
        for selection in range(1<<len(inc)):
            used=[primitive[i] for k,i in enumerate(inc) if selection>>k&1]
            remaining=[n for n in ns if all(n&m for m in used)]
            if not remaining:local.append(0);continue
            bad=np.zeros(8192,dtype=bool);bad[remaining]=True
            for i in range(13):
                step=1<<i;v=bad.reshape(-1,2*step);v[:,:step]|=v[:,step:]
            choices=(~bad)&((np.arange(8192)&p)==0)
            local.append(int(size[:8192][choices].min()))
        per[:,j]=np.asarray(local)[ix]
    ordered=np.sort(per,axis=1)
    minima=[int((size+ordered[:,:13-s].sum(axis=1)).min()) for s in range(4)]
    assert minima==[28,25,22,19]
    return size,per,ordered

def point_representatives(cost,sym,arrays):
    size,per,ordered=arrays
    # An admissible S at size four, hence threshold cost+8.
    cap=cost+8
    keep=(size+ordered[:,:9].sum(axis=1))<=cap
    baseline=size[keep]+per[keep].sum(axis=1)
    allowed=set()
    for xs in combinations(range(13),4):
        w=baseline-per[keep][:,xs].sum(axis=1)
        if len(w) and w.min()<=cap:
            S=sum(1<<i for i in xs);allowed.update(image(S,p) for p in sym)
    out=[]
    for S in range(8192):
        if not 4<=S.bit_count()<=12 or (S.bit_count()==4 and S not in allowed):continue
        if S==min(image(S,p) for p in sym):out.append(S)
    return out

