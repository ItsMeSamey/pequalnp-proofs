from pathlib import Path
import sys
here=Path(__file__).resolve().parent
from point import group,image,stars,pos,neg
td=Path(sys.argv[1])
banks=[tuple(map(int,x.split())) for x in (here/'banks-through-eight.txt').read_text().splitlines()]
fs=[[image(x,g) for x in range(8192)] for g in group()]
ls=[[stars.index(f[s]) for s in stars] for f in fs]
points={}
for row in banks:
 p=min(tuple(sorted(f[m] for m in row[:-1])) for f in fs)
 points[p]=min(points.get(p,99),row[-1])
parts=sorted(points,key=lambda p:(points[p],p))
assert len(parts)==151
(td/'samples').write_text(f'{len(pos)} {len(neg)}\n'+' '.join(map(str,sorted(pos)))+'\n'+' '.join(map(str,sorted(neg)))+'\n')
(td/'points').write_text('\n'.join(' '.join(map(str,p)) for p in parts)+'\n')
(td/'lines').write_text('\n'.join(' '.join(map(str,(1,2,4,8,16,32,64,q))) for q in range(128))+'\n')
for cost in (5,6,7,8):
 cases=[]
 for i,p in enumerate(parts):
  if points[p]!=cost:continue
  stab=[l for l,f in zip(ls,fs) if tuple(sorted(f[m] for m in p))==p]
  cases.extend((i,q) for q in range(128) if (cost<8 or q.bit_count()<=4) and q==min(image(q,l) for l in stab))
 (td/f'c{cost}').write_text(''.join(f'{i} {q}\n' for i,q in cases))
 print(cost,len(cases))
