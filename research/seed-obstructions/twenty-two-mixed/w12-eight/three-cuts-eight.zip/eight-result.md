# The point-price-eight case

At 22 mixed gates and total size 33, all 10,034 joint representatives at point price eight and line width eight fail. The first, repeat-inclusive three-cut test leaves 35. The cases of reusing a point, reusing a line, or reusing only mixed signals cover every possible circuit on each of those 35 interfaces.

- A reused point can be chosen first, giving 420 inflations of width thirteen with the same eight lines. The ordered necessary search leaves 105. All 105 fail the two-surplus kernel.
- A reused line yields seven raw line slots plus E and a repeat, with favorable singleton-domain price at most three. The width-twelve/nine-line certificate through point price eight explicitly grants all extra signatures subject to its singleton-domain two-output price, including repeated signals and zero. The checker exhausted every such compatible point/line interface.
- If no original point or line repeats, all three excess uses occur at mixed gates. The restricted check on the 35 pairs gives zero.

Run python verify_eight.py for the first and final stages. This archive also includes the upstream cheap width-twelve/nine-line verifier. The 420 point inflations use the point-copy directory in the bundled w12l9-nine.zip. Earlier prices five through seven are certified in three-cuts-cheap.zip. This is a necessary-case exclusion for any 33-gate circuit and assumes no terminal-clean normal form.
