from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys,hashlib
root=Path(__file__).resolve().parent
with TemporaryDirectory() as temp:
    d=Path(temp)
    from input import raw_samples
    positives,negatives,_=raw_samples(root/'L-meta-18968.json')
    sample=list(map(int,(root/'samples').read_text().split()))
    assert sample==[28,245]+sorted(positives)+sorted(negatives)
    lines=[tuple(map(int,row.split())) for row in (root/'lines').read_text().splitlines()]
    assert lines==[(1,2,4,8,16,32,64,q) for q in range(128)]
    points=root/'points-9'
    assert hashlib.sha256(points.read_bytes()).hexdigest()=='80a542ce50d098efca9b53114740262312e5e06a7863e398a2b946f3286e5151'
    viable=set(map(int,(root/'catalog-viable.txt').read_text().split()))
    import zipfile
    with zipfile.ZipFile(root/'w12l9-and-point-copies.zip') as dependency:
        catalog=dependency.read('twenty-two-nine-point-nine/point-catalog/catalog-viable.txt')
    assert viable==set(map(int,catalog.split())) and len(viable)==765
    subprocess.run([sys.executable,root/'price_nine.py',points,d/'broad'],check=True)
    count=0
    with (d/'broad').open() as src,(d/'cases').open('w') as dst:
        for row in src:
            if int(row.split()[0]) in viable:
                count+=1
                dst.write(row)
    assert count==42918
    subprocess.run(['c++','-O3','-std=c++20',root/'restricted-driver.cpp','-o',d/'gates'],check=True)
    with (d/'cases').open() as src:
        proc=subprocess.run([d/'gates',root/'samples',points,root/'lines','3'],stdin=src,capture_output=True,text=True,check=True)
    print(proc.stderr,flush=True)
    survivors=proc.stdout
    n=len(survivors.splitlines())
    assert proc.stderr.splitlines()[-1]==f'DONE 42918 {n}'
    subprocess.run(['c++','-O3','-std=c++20',root/'continuation/strong.cpp','-o',d/'exact'],check=True)
    terminal=subprocess.run([d/'exact',root/'samples',points,root/'lines'],input=survivors,capture_output=True,text=True,check=True)
    print(terminal.stderr,flush=True)
    assert not terminal.stdout and terminal.stderr.splitlines()[-1]==f'DONE {n} 0'
