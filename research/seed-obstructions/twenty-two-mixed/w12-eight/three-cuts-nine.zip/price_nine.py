from pathlib import Path
import sys
from point import group, image, stars
points_file,destination=map(Path,sys.argv[1:])
points=[tuple(map(int,z.split())) for z in points_file.read_text().splitlines()]
assert len(points)==9268
maps=[[image(i,g) for i in range(8192)] for g in group()]
lines=[[stars.index(mapping[s]) for s in stars] for mapping in maps]
line_images=[[image(i,g) for i in range(128)] for g in lines]
counts=[0]*14
with destination.open('w') as out:
 for idx,p in enumerate(points):
    stabilizer=[L for M,L in zip(maps,line_images) if tuple(sorted(M[x] for x in p))==p]
    for E in range(128):
        if E.bit_count()<=3 and all(E<=L[E] for L in stabilizer):
            out.write(f'{idx} {E}\n')
            counts[len(set(v for v in p if v and v&(v-1)))]+=1
print(sum(counts),counts,flush=True)
