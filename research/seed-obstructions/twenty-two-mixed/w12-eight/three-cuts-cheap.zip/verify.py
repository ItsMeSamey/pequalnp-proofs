from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess, sys
root=Path(__file__).resolve().parent
with TemporaryDirectory() as tmp:
    d=Path(tmp)
    subprocess.run([sys.executable,root/'prepare.py',d],check=True)
    subprocess.run(['c++','-std=c++20','-O3',root/'driver.cpp','-o',d/'check'],check=True)
    for cost in map(int,sys.argv[1:] or [5,6,7]):
        count=sum(1 for _ in (d/f'c{cost}').open())
        with (d/f'c{cost}').open() as f:
            r=subprocess.run([d/'check',d/'samples',d/'points',d/'lines'],stdin=f,capture_output=True,text=True,check=True)
        print(cost,count,r.stderr.splitlines()[-1],flush=True)
        if r.stdout or r.stderr.splitlines()[-1]!=f'DONE {count} 0':
            raise SystemExit('a pair survived or verification failed')
