#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace frontierlib {
using namespace std;
using Bits=uint64_t;
using Signature=array<Bits,6>; // positives, up to 245 negatives, ancestry side
using Family=array<int,12>;
using Frontier=array<int,24>; // zero entries are padding
template<class T> struct ArrayHash {
    size_t operator()(const T& values)const{
        size_t h=0x9e3779b97f4a7c15ULL;
        for(auto v:values){h^=v+0x9e3779b97f4a7c15ULL+(h<<6)+(h>>2);}
        return h;
    }
};
struct Wire{Signature value;};
struct Search{
    int count_pos, count_neg, blocks;
    vector<Wire> wires{{}};
    unordered_map<Signature,int,ArrayHash<Signature>> ids;


    int intern(Signature sig){
        auto [entry,created]=ids.emplace(sig,wires.size());
        if(!created)return entry->second;
        Wire wire{sig};
        wires.push_back(move(wire));
        return entry->second;
    }
    using U=uint32_t;using Neg=array<Bits,4>;
    const Neg *ptab,*ltab;
    bool outer_cut(U m,const Signature&z,const vector<int>&ps,const array<Signature,24>&raw) {
        constexpr U dup=3u<<21, original=(1u<<21)-1;
        U all=(original^m)|dup,point=(4095u<<7)&all,line=((original^(4095u<<7))&all);
        if(z[5]==0)line|=dup;else if(z[5]==1)point|=dup;
        array<U,28> pos{}; array<Neg,23> truth{};
        for(int i=0;i<23;i++)for(int k=0;k<4;k++)truth[i][k]=i<21?raw[i][k+1]:z[k+1];
        for(int x=0;x<28;x++)pos[x]=(ps[x]&all)|((z[0]>>x&1)?dup:0);
        auto zero=[&](U mask){auto&a=ptab[(mask>>7)&4095];auto&b=ltab[(mask&127)|((mask>>12)&384)];
          Neg rv{};for(int k=0;k<4;k++)rv[k]=a[k]&b[k];if(mask&dup)for(int k=0;k<4;k++)rv[k]&=z[k+1];return rv;};
        auto partial=[&](U one,U other){
            Bits forced=0;Neg neg{};
            for(int x=0;x<count_pos;x++){auto v=zero(pos[x]&(all^one));Bits any=0;for(int b=0;b<blocks;b++){neg[b]|=v[b];any|=v[b];}if(any)forced|=Bits(1)<<x;}
            for(Bits q=forced;q;q&=q-1){auto v=zero(pos[__builtin_ctzll(q)]&(all^other));for(int b=0;b<blocks;b++)if(v[b]&neg[b])return false;}
            return true;
        };
        array<Signature,24> mark{};
        for(int x=0;x<count_pos;x++)for(U q=pos[x];q;q&=q-1){
            int i=__builtin_ctz(q);auto v=zero(pos[x]^(1u<<i));Bits any=0;
            for(int b=0;b<blocks;b++){Bits a=v[b]&~truth[i][b];any|=a;mark[i][b+1]|=a;}if(any)mark[i][0]|=Bits(1)<<x;
        }
        array<U,24> adj{};
        for(int i=0;i<21;i++)for(int j=0;j<i;j++)if(mark[i][0]&mark[j][0]){
            for(int b=0;b<blocks;b++)if(mark[i][b+1]&mark[j][b+1]){adj[i]|=1u<<j;adj[j]|=1u<<i;break;}
        }
        array<pair<U,U>,24> comps{};int n=0;U live=all;
        while(live){U a=live&-live,b=0,front=a;bool rev=false;
            while(front){U next=0;for(U z=front;z;z&=z-1)next|=adj[__builtin_ctz(z)];if(next&(rev?b:a))return false;next&=~(a|b);if(rev)a|=next;else b|=next;front=next;rev=!rev;}
            comps[n++]={a,b};live&=~(a|b);
        }
        // In the absence of any conflicting pair this necessary test can be skipped.
        if(n==__builtin_popcount(all))return true;
        sort(comps.begin(),comps.begin()+n,[](auto a,auto b){return __builtin_popcount(a.first|a.second)>__builtin_popcount(b.first|b.second);});
        auto rec=[&](auto&self,int i,U one,U other)->bool{
            if(i==n && (!one||((one&(one-1))&&((one&point)==one||(one&line)==one))))return false;
            if(i&&!partial(one,other))return false;if(i==n)return true;
            auto [a,b]=comps[i];return self(self,i+1,one|a,other|b)||self(self,i+1,one|b,other|a);
        };
        return rec(rec,0,0,0);
    }
    bool three(const vector<int>&P,const vector<int>&N){
      constexpr unsigned all=(1u<<21)-1,points=4095u<<7;
      auto zero=[&](U mask){auto&a=ptab[(mask>>7)&4095];auto&b=ltab[(mask&127)|((mask>>12)&384)];
       Neg rv;for(int k=0;k<4;k++)rv[k]=a[k]&b[k];return rv;};
      auto partial=[&](U one,U other){if(!one||!other)return true;
       unsigned forced=0;Neg neg{};for(int x=0;x<28;x++){auto v=zero(P[x]&~one);Bits any=0;for(int k=0;k<4;k++){neg[k]|=v[k];any|=v[k];}if(any)forced|=1u<<x;}
       for(U q=forced;q;q&=q-1){auto v=zero(P[__builtin_ctz(q)]&~other);for(int k=0;k<4;k++)if(v[k]&neg[k])return false;}return true;};
      array<Signature,21> mark{};array<U,21> yes{},no{},adj{};
      for(int x=0;x<28;x++)for(U v=P[x];v;v&=v-1){int t=__builtin_ctz(v);auto z=zero(P[x]^(1u<<t));auto base=zero(P[x]);
       Bits any=0;for(int k=0;k<4;k++){Bits q=z[k]&~base[k];mark[t][1+k]|=q;any|=q;}if(any)mark[t][0]|=Bits(1)<<x;}
      for(int i=0;i<21;i++)for(int j=0;j<i;j++){bool y=mark[i][0]&mark[j][0];bool n=false;for(int k=1;k<=4;k++)n|=bool(mark[i][k]&mark[j][k]);
       if(y){yes[i]|=1u<<j;yes[j]|=1u<<i;}if(n){no[i]|=1u<<j;no[j]|=1u<<i;}if(y&&n){adj[i]|=1u<<j;adj[j]|=1u<<i;}}
      auto component=[&](const auto&edge,U mask){U q=mask&-mask,seen=q;while(q){U z=0;for(U t=q;t;t&=t-1)z|=edge[__builtin_ctz(t)];q=z&mask&~seen;seen|=q;}return seen;};
      auto possible=[&](auto&&self,U mask)->bool{if(__builtin_popcount(mask)<4)return true;
       U y=component(yes,mask),part=y==mask?component(no,mask):y;return part!=mask&&self(self,part)&&self(self,mask^part);};
      unsigned nodes=0;
      auto dfs=[&](auto&&self,U A,U B,U C,U left)->bool{
       if(++nodes>1000)return true;
       if(!partial(A,B|C)||!partial(B,C))return false;
       if(!left)return A&&(!(A&(A-1))||((A&points)&&(A&~points)));
       int best=-1,score=-1;for(U t=left;t;t&=t-1){int i=__builtin_ctz(t);int v=1000*(bool(adj[i]&A)+bool(adj[i]&B)+bool(adj[i]&C))+25*__builtin_popcount(adj[i]&left)+__builtin_popcount((yes[i]|no[i])&left);
        if(v>score){score=v;best=i;}}
       U w=1u<<best,L=left^w;return (!(adj[best]&A)&&possible(possible,A|w)&&self(self,A|w,B,C,L))||(!(adj[best]&B)&&possible(possible,B|w)&&self(self,A,B|w,C,L))||(!(adj[best]&C)&&possible(possible,C|w)&&self(self,A,B,C|w,L));};
      return dfs(dfs,0,0,0,all);
    }
    bool treecut(const vector<int>&ps,const vector<int>&ns,int nleaves){
        using U=uint32_t;using Neg=array<Bits,4>;
        using Node=pair<U,Signature>;
        count_pos=ps.size();count_neg=ns.size();blocks=(count_neg+63)/64;
        U all=(1u<<nleaves)-1;
        array<vector<Node>,22> layer;
        Frontier roots{};array<Signature,24> raw{};
        for(int i=0;i<nleaves;i++){
            for(int x=0;x<count_pos;x++)if(ps[x]>>i&1)raw[i][0]|=Bits(1)<<x;
            for(int y=0;y<count_neg;y++)if(ns[y]>>i&1)raw[i][1+y/64]|=Bits(1)<<(y%64);
            raw[i][5]=i>=7&&i<19;roots[i]=intern(raw[i]);
        }
        array<array<Neg,16>,6> tab{};int groups=(nleaves+3)/4;
        for(int g=0;g<groups;g++){
            for(int k=0;k<blocks;k++)tab[g][0][k]=(k+1<blocks || count_neg%64==0)?~Bits(0):(Bits(1)<<(count_neg%64))-1;
            for(int a=1;a<1<<min(4,nleaves-4*g);a++)for(int k=0;k<blocks;k++)
                tab[g][a][k]=tab[g][a&(a-1)][k]&raw[4*g+__builtin_ctz(a)][1+k];
        }
        array<Signature,24> personal{};
        for(int x=0;x<count_pos;x++)for(U bits=ps[x];bits;bits&=bits-1){
          int i=__builtin_ctz(bits);U m=ps[x]^(1u<<i);Neg n=tab[0][m&15];
          for(int g=1;g<groups;g++)for(int j=0;j<blocks;j++)n[j]&=tab[g][(m>>(4*g))&15][j];
          Bits any=0;for(int j=0;j<blocks;j++){n[j]&=~raw[i][1+j];any|=n[j];personal[i][1+j]|=n[j];}
          if(any)personal[i][0]|=Bits(1)<<x;
        }
        auto needed=[&](U inside){Signature q{};
            for(int x=0;x<count_pos;x++){U t=ps[x]&(all^inside);Neg n=tab[0][t&15];
                for(int g=1;g<groups;g++)for(int k=0;k<blocks;k++)n[k]&=tab[g][(t>>(4*g))&15][k];
                Bits any=0;for(int k=0;k<blocks;k++){q[1+k]|=n[k];any|=n[k];}if(any)q[0]|=Bits(1)<<x;
            }return q;};
        auto outer=[&](U m,const Signature&z){return outer_cut(m,z,ps,raw);};
        for(int i=0;i<nleaves;i++){U m=1u<<i;if(outer(m,raw[i]))return true;layer[1].push_back({m,raw[i]});}
        unordered_map<U,Signature> constraints;
        auto dom=[&](const Signature&a,const Signature&b){if(b[0]&~a[0])return false;for(int k=1;k<=blocks;k++)if(a[k]&~b[k])return false;return true;};
        for(int w=2;w<=nleaves;w++){
            if(w==3&&layer[2].empty())return false;
            unordered_map<U,vector<Signature>> bucket;
            for(int a=1;a<=w/2;a++)for(auto&[xm,x]:layer[a])for(auto&[ym,y]:layer[w-a]){
                if((xm&ym)||(a*2==w&&xm>=ym)||(x[5]==y[5]&&x[5]!=2))continue;
                U mask=xm|ym;Signature q{};int permit=3;
                if(w==2){
                 auto&mx=personal[__builtin_ctz(xm)];auto&my=personal[__builtin_ctz(ym)];
                 if((mx[0]&~y[0])||(my[0]&~x[0]))permit&=~1;
                 for(int k=1;k<=blocks;k++)if((mx[k]&y[k])||(my[k]&x[k]))permit&=~2;
                 if(!permit)continue;
                }else{auto [it,tmp]=constraints.try_emplace(mask);if(tmp)it->second=needed(mask);q=it->second;}
                for(int op=0;op<2;op++)if(permit&(1<<op)){
                    Signature z{};z[0]=op?(x[0]|y[0]):(x[0]&y[0]);if(q[0]&~z[0])continue;
                    bool ok=true;for(int k=1;k<=blocks;k++){z[k]=op?(x[k]|y[k]):(x[k]&y[k]);if(q[k]&z[k]){ok=false;break;}}
                    if(!ok)continue;z[5]=2;auto&v=bucket[mask];
                    if(any_of(v.begin(),v.end(),[&](const auto&other){return dom(other,z);}))continue;
                    v.erase(remove_if(v.begin(),v.end(),[&](const auto&other){return dom(z,other);}),v.end());v.push_back(z);
                }
            }
            for(auto&[mask,vs]:bucket)for(auto&v:vs){if(outer(mask,v))return true;layer[w].push_back({mask,v});}
        }
        return false;
    }
};
}
