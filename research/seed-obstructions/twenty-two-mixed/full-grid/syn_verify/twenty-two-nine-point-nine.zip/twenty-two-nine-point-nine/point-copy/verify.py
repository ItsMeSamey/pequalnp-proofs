"""Unfold one repeated point boundary into a thirteenth point slot."""
import argparse
from collections import defaultdict
from pathlib import Path
from subprocess import run,Popen
from tempfile import TemporaryDirectory
import os,sys
here=Path(__file__).resolve().parent
root=here.parent;sys.path.insert(0,str(root))
from sample import move,symmetries,raw
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('price',type=int,choices=(8,9));args=parser.parse_args()
run([sys.executable,root/'setup.py'],cwd=root,check=True)
P=[tuple(map(int,l.split())) for l in ((here/'points-eight.txt') if args.price==8 else (root/'points-9')).read_text().splitlines()]
cases=defaultdict(list)
if args.price==8:
    for l in (here/'eligible-eight.txt').read_text().splitlines():
        i,e=map(int,l.split());cases[i].append(e)
else:
    run([sys.executable,root/'point-catalog/filter.py'],cwd=root,check=True)
    ids=list(map(int,(root/'catalog-viable.txt').read_text().split()))
    g=symmetries();masks={v for i in ids for v in P[i]}
    im=[{v:move(v,p) for v in masks}for p,_ in g]
    for i in ids:
        stab=[j for j,t in enumerate(im) if tuple(sorted(t[v] for v in P[i]))==P[i]]
        cases[i]=[e for e in range(128)if e.bit_count()<=3 and all(e<=g[j][1][e] for j in stab)]
    assert sum(map(len,cases.values()))==42918
ps=[];owners=[];idx={}
for i in sorted(cases):
    for slot,v in enumerate(P[i]):
        if v in P[i][:slot]:continue
        f=tuple(sorted((*P[i],v)))
        if f not in idx:idx[f]=len(ps);ps.append(f);owners.append([])
        owners[idx[f]].append((i,slot))
def put(path,rows):
    path.write_text(''.join(' '.join(map(str,r))+'\n' for r in rows))
with TemporaryDirectory() as td:
    td=Path(td);pt,lt=td/'point-banks',td/'line-banks'
    put(pt,ps);put(lt,[(*raw,e)for e in range(128)])
    for name in ('check','strong'):run(['c++','-O3','-march=native','-std=c++20',here/(name+'.cpp'),'-o',td/name],check=True)
    n=0
    with (td/'candidate').open('w')as out:
        with Popen([td/'check',root/'samples',pt,lt,'13','8','2'],stdin=-1,stdout=out,text=True)as proc:
            for j,orig in enumerate(owners):
                es=sorted({v for i,s in orig for v in cases[i]});n+=len(es)
                proc.stdin.write(''.join(f'{j} {v}\n'for v in es))
            proc.stdin.close()
            if proc.wait():raise RuntimeError('ordered-region check failed')
    with (td/'candidate').open()as inp:
        r=run([td/'strong',root/'samples',pt,lt],stdin=inp,text=True,capture_output=True,check=True)
    print('expanded',n);print(r.stderr,end='')
    for line in r.stdout.splitlines():
        j,e=map(int,line.split())
        for i,s in owners[j]:
            if e in cases[i]:print('survivor',i,e,s,P[i][s])
