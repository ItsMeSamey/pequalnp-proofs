# Repeated point inputs at twelve point and eight line boundary wires

If a circuit uses the same point boundary more than once, detach one use and regard it as an extra point leaf with the same truth values. The number of mixed gates stays 22. The enlarged thirteen-point, eight-line problem has two surplus uses. The duplicated physical source may occur anywhere in the original circuit.

At nine paid point gates, two line gates remain. Eight line masks consist of the seven original singleton line labels plus one mask E of size at most three, including zero. Intersecting the 765 affordable point representatives with the stabilizer action on E gives 42,918 initial point-line pairs. Adding any one of the twelve point masks as a duplicate gives 511,875 distinct enlarged cases. The ordered-region check leaves 3,313, and an exact two-copy frontier excludes all 3,313. Thus a nine-point-gate solution has no repeated pure point boundary. The companion line-duplication test excludes any repeated pure line boundary, so every surplus use must be on a mixed gate.

Run `python point-copy/verify.py 9` from a writable package copy. The price-eight command uses the furnished list of original configurations left by the independent mixed screening.

At eight paid point gates the upstream screen leaves 35 of its 10,034 initial configurations. Repeating one point wire in each induces 420 enlarged cases. The ordered-region test passes 105 and the exact mixed search excludes all 105. The three-line-gate relaxation in the nine-line, eight-point-gate pricing also covers the analogous duplicated line wires. The accompanying price-eight fixture contains every final upstream survivor.
