from pathlib import Path
from subprocess import run,Popen
from tempfile import TemporaryDirectory
from sample import move,symmetries
import os,sys
root=Path(__file__).resolve().parent
lo,hi=map(int,sys.argv[1:] or (0,9268))
os.chdir(root)
run([sys.executable,'setup.py'],check=True)
P=[tuple(map(int,r.split())) for r in (root/'points-9').read_text().splitlines()]
L=[tuple(map(int,r.split())) for r in (root/'lines-9').read_text().splitlines()]
assert len(P)==9268 and len(L)==540
group=symmetries();masks={m for f in P for m in f}
img=[{m:move(m,pp) for m in masks} for pp,lm in group];cache={}
with TemporaryDirectory() as td:
 exe=Path(td)/'kernel'
 run(['c++','-O3','-march=native','-std=c++20','subsetpure.cpp','-o',exe],check=True)
 with Popen([exe,'samples','points-9','lines-9'],stdin=-1,text=True) as proc:
  total=0
  for i in range(lo,hi):
   p=P[i];stab=tuple(z for z,g in enumerate(img) if tuple(sorted(g[m] for m in p))==p)
   if stab not in cache:
    cache[stab]=tuple(j for j,l in enumerate(L) if all(l<=tuple(sorted(group[z][1][v] for v in l)) for z in stab))
   for j in cache[stab]:
    total+=1;proc.stdin.write(f'{i} {j}\n')
  proc.stdin.close()
  if proc.wait():raise RuntimeError('kernel failed')
 print('tested',total,'point-line representatives',file=sys.stderr)
 if lo==0 and hi==9268:assert total==4680846
