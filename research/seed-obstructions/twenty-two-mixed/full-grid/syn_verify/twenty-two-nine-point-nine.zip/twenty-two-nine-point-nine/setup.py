from pathlib import Path
from itertools import combinations,combinations_with_replacement
import subprocess,sys
from hashlib import sha256
from tempfile import TemporaryDirectory, NamedTemporaryFile
root=Path(__file__).resolve().parent
src=root/'domain'
sys.path.insert(0,str(src))
from point import group,direct_costs,point_representatives,rows,pos,neg,image
from sample import raw,symmetries,move
def save(file,lst):
 dest=Path(file)
 with NamedTemporaryFile(mode='w',dir=dest.parent,delete=False) as output:
  output.writelines(' '.join(map(str,r))+'\n' for r in lst)
 Path(output.name).replace(dest)
gr=symmetries();fs=[[move(m,pp) for m in range(8192)] for pp,lm in gr]
p9file=root/'points-9'
if not p9file.exists() or sha256(p9file.read_bytes()).hexdigest()!="80a542ce50d098efca9b53114740262312e5e06a7863e398a2b946f3286e5151":
 with TemporaryDirectory() as td:
  work=Path(td)
  subprocess.run(['c++','-O3','-std=c++20','-march=native',src/'banks.cpp','-o',work/'banks'],check=True)
  (work/'rawreps').write_text(' '.join(map(str,point_representatives(9,group(),direct_costs()))))
  data=str(len(rows))+'\n'+''.join(f'{p} {n}\n'for p,n in rows)
  r=subprocess.run([work/'banks','9',work/'rawreps'],input=data,capture_output=True,text=True,check=True)
 banks={tuple(map(int,l.split())) for l in r.stdout.splitlines()};assert len(banks)==21821
 old={tuple(map(int,l.split())) for file in ('cost-nine-six.txt','three-seven-output-banks.txt') for l in (src/file).read_text().splitlines()}
 banks.update(tuple(sorted((*f,x))) for f in old for x in (0,*f))
 assert len(banks)==22145
 nine=sorted({min(tuple(sorted(g[x] for x in f)) for g in fs) for f in banks});assert len(nine)==9268
 save(p9file,nine)
R=set(raw);first={a|b for a,b in combinations(raw,2)}|R|{0};two=set()
for t in first:
 vals=R|{t}
 for c,d in combinations_with_replacement(vals,2):
  for u in (c|d,c&d):two.add(tuple(sorted((*raw,t,u))))
save(root/'lines-9',sorted(two))
save(root/'samples',[(28,245),sorted(pos),sorted(neg)])
print(9268,len(two),flush=True)
