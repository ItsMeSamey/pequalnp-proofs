#include "three.hpp"
#include <string>

using namespace std;
template<size_t W>
vector<array<int,W>> read_banks(const char* path) {
    ifstream input(path);
    vector<array<int,W>> banks;
    array<int,W> row;
    while(input >> row[0]) {
        for(size_t i=1;i<W;i++) if(!(input >> row[i])) abort();
        banks.push_back(row);
    }
    return banks;
}
template<size_t W>
int evaluate(const array<int,W>& masks, int x) {
    int result=0;
    for(size_t i=0;i<W;i++) if(masks[i]&x) result |= 1<<i;
    return result;
}
using Neg=frontierlib::Search::Neg;
template<size_t W> vector<Neg> table(const array<int,W>&bank,const vector<int>&neg,bool line){
 vector<Neg> z(1u<<W);array<Neg,W> t{};z[0].fill(~uint64_t(0));z[0][3]=(uint64_t(1)<<53)-1;
 for(int i=0;i<W;i++)for(size_t j=0;j<neg.size();j++)if((line?neg[j]>>13:neg[j]&8191)&bank[i])t[i][j/64]|=uint64_t(1)<<(j%64);
 for(unsigned m=1;m<z.size();m++)for(int k=0;k<4;k++)z[m][k]=z[m&(m-1)][k]&t[__builtin_ctz(m)][k];
 return z;
}
int main(int argc,char** argv) {
    if(argc<4)return 1;
    ifstream data(argv[1]); int np,nn; data>>np>>nn;
    if(np!=28||nn!=245)abort();
    vector<int> pos(np),neg(nn);
    for(auto& x:pos)data>>x;
    for(auto& x:neg)data>>x;
    auto points=read_banks<12>(argv[2]);
    auto lines=read_banks<9>(argv[3]);
    uint64_t checked=0,surviving=0;vector<vector<int>> pl,nl;
    for(auto&l:lines){vector<int>a,b;
     for(int x:pos){int y=evaluate(l,x>>13);a.push_back((y&127)|((y>>7)<<19));}
     for(int x:neg){int y=evaluate(l,x>>13);b.push_back((y&127)|((y>>7)<<19));}pl.push_back(a);nl.push_back(b);}
    vector<vector<Neg>> ltab;for(auto l:lines)ltab.push_back(table(l,neg,true));vector<Neg> ptab;int i,j,last=-1; vector<int> pp,pn;
    while(cin>>i>>j){if(i!=last){ptab=table(points.at(i),neg,false);pp.clear();pn.clear();for(int x:pos)pp.push_back(evaluate(points.at(i),x&8191)<<7);for(int x:neg)pn.push_back(evaluate(points.at(i),x&8191)<<7);last=i;}
    {vector<int>P=pp,N=pn;for(int k=0;k<(int)P.size();k++)P[k]|=pl[j][k];for(int k=0;k<(int)N.size();k++)N[k]|=nl[j][k];
        frontierlib::Search s;s.ptab=ptab.data();s.ltab=ltab[j].data();
        if(s.three(P,N)){cout<<i<<' '<<j<<endl;surviving++;}
        checked++;
        if(checked%1000==0)cerr<<checked<<" checked "<<surviving<<" surviving"<<endl;
    }
    }
    cerr<<"DONE "<<checked<<" "<<surviving<<endl;
}
