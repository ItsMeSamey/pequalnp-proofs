"""Replay the ordered-region test, then run the exact two-copy frontier."""
from pathlib import Path
from subprocess import run,Popen
from tempfile import TemporaryDirectory
import argparse,os,sys
from itertools import combinations
from sample import move,symmetries,raw
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--catalog',action='store_true')
parser.add_argument('--start',type=int,default=0)
parser.add_argument('--end',type=int,default=9268)
parser.add_argument('--extra-triples',action='store_true',help='grant the 315 additional raw-seven, triple, duplicate-or-zero line banks')
args=parser.parse_args()
os.chdir(root)
run([sys.executable,'setup.py'],check=True)
keep=set(range(9268))
if args.catalog:
    run([sys.executable,'point-catalog/filter.py'],check=True)
    keep=set(map(int,(root/'catalog-viable.txt').read_text().split()))
P=[tuple(map(int,l.split())) for l in (root/'points-9').read_text().splitlines()]
L=[tuple(map(int,l.split())) for l in (root/'lines-9').read_text().splitlines()]
assert len(P)==9268 and len(L)==540
if args.extra_triples:
    L=sorted({tuple(sorted((*raw,t,r))) for abc in combinations(raw,3) for t in [sum(abc)] for r in (*raw,t,0)})
    assert len(L)==315
group=symmetries();masks={m for f in P for m in f}
img=[{m:move(m,pp) for m in masks} for pp,lm in group];cache={}
with TemporaryDirectory() as td:
    td=Path(td)
    for name in ('three','strong'):
        run(['c++','-O3','-march=native','-std=c++20',name+'.cpp','-o',td/name],check=True)
    line_path=td/'lines'
    line_path.write_text(''.join(' '.join(map(str,l))+'\n' for l in L))
    count=0
    with (td/'candidates').open('w') as out:
        with Popen([td/'three','samples','points-9',line_path],stdin=-1,stdout=out,text=True) as work:
            for i in sorted(keep):
                if not args.start<=i<args.end:continue
                p=P[i];stab=tuple(z for z,g in enumerate(img) if tuple(sorted(g[m] for m in p))==p)
                if stab not in cache:
                    cache[stab]=[j for j,l in enumerate(L) if all(l<=tuple(sorted(group[z][1][m] for m in l)) for z in stab)]
                for j in cache[stab]:
                    work.stdin.write(f'{i} {j}\n');count+=1
            work.stdin.close()
            if work.wait():raise RuntimeError('ordered-region test failed')
    with (td/'candidates').open() as inp:
        exact=run([td/'strong','samples','points-9',line_path],stdin=inp,text=True,capture_output=True,check=True)
    print(exact.stderr,end='')
    if exact.stdout:raise RuntimeError('exact survivors:\n'+exact.stdout)
    print(count,'paired orbits checked')
    if not args.extra_triples and not args.catalog and args.start==0 and args.end==9268:assert count==4680846
