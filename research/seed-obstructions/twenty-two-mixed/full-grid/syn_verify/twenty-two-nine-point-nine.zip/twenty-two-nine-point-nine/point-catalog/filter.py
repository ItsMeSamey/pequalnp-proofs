from pathlib import Path
from collections import Counter
import sys
here=Path(__file__).resolve().parent
root=here.parent
sys.path.insert(0,str(root))
from sample import move,symmetries
from input import point_obligations
R=set(point_obligations((here/'L-meta-18968.json'))[0]);pts=[tuple(map(int,l.split())) for l in (root/'points-9').read_text().splitlines()]
masks={v for f in pts for v in f};img=[{v:move(v,s) for v in masks}for s,_ in symmetries()]
known=set()
for n in (7,8,9):
 file=(here/f'banks-{n}.txt')
 if not file.exists():raise FileNotFoundError(file)
 known.update(tuple(map(int,l.split()[:-1])) for l in file.read_text().splitlines())
def category(f):
 if len(set(f))<12 or 0 in f:return 'padded'
 seen={tuple(sorted(i[m] for m in f)) for i in img}
 if any(len(set(s)-R)<=6 for s in seen):return 'grant-six'
 if seen&known:return 'exact'
 return 'none'
ids=[];hist=Counter()
for j,f in enumerate(pts):
 c=category(f);hist[c]+=1
 if c!='none':ids.append(j)
print(hist)
(root/'catalog-viable.txt').write_text(' '.join(map(str,ids)))
