"""Enumerate admissible raw source profiles from the theorem, for a specified budget."""
import argparse
from pathlib import Path
from itertools import combinations
from math import comb
from collections import Counter
import numpy as np
from input import point_obligations
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('out',type=Path)
parser.add_argument('g',type=int,choices=(4,5,6,7,8,9))
parser.add_argument('--selected',nargs='+',type=int)
args=parser.parse_args()
base=Path(__file__).resolve().parent
args.out.mkdir(exist_ok=True,parents=True)
raw, obligations=point_obligations(base/'L-meta-18968.json')
frozen=[m for m in raw if m.bit_count()>1]
sets=np.arange(1<<len(frozen),dtype=np.int32)
size=np.array([i.bit_count() for i in range(len(sets))],dtype=np.int16)
read=np.empty((len(sets),13),dtype=np.int16)
masks=np.arange(8192,dtype=np.int32)
for i in range(13):
    p=1<<i
    neg=[n for a,n in obligations if a==p]
    incident=[j for j,m in enumerate(frozen) if m&p]
    projection=np.zeros(len(sets),dtype=np.int16)
    for bit,j in enumerate(incident):
        projection|=(((sets>>j)&1)<<bit).astype(np.int16)
    minima=[]
    for use in range(1<<len(incident)):
        available=[frozen[j] for bit,j in enumerate(incident) if use>>bit&1]
        pending=[n for n in neg if all(m&n for m in available)]
        if not pending:
            minima.append(0)
            continue
        bad=np.zeros(8192,dtype=bool);bad[pending]=True
        for bit in range(13):
            step=1<<bit
            view=bad.reshape(-1,2*step)
            view[:,:step]|=view[:,step:]
        minima.append(int(size[:8192][(~bad)&((masks&p)==0)].min()))
    read[:,i]=np.array(minima)[projection]

(args.out/'obs').write_text(''.join(f'{p} {n}\n' for p,n in obligations))
g=args.g
ordered=np.sort(read,axis=1)
for h in (args.selected or range(4,g+1)):
    profiles=bags=0
    with (args.out/f'profiles-{g}-{h}').open('w') as out:
        r=12-h
        for s in range(r+1):
            nsel=r-s
            ids=np.flatnonzero((size>=nsel)&((size-nsel+ordered[:,:13-s].sum(axis=1))<=g+h))
            if not len(ids):continue
            selections=list(combinations(range(13),s))
            unselected=np.array([[int(i not in ix) for i in range(13)] for ix in selections],dtype=np.int16)
            singleton_masks=[sum(1<<i for i in ix) for ix in selections]
            for z in ids:
                F=[m for i,m in enumerate(frozen) if int(z)>>i&1]
                minimum=unselected@read[z]+len(F)-nsel
                for t in np.flatnonzero(minimum<=g+h):
                    d=read[z]*unselected[t];lo=int(minimum[t])
                    for R in combinations(F,nsel):
                        print(h,singleton_masks[t],len(R),*R,len(F),*F,*d,file=out)
                        profiles+=1
                        bags+=sum(comb(12+len(F)+extra,extra) for extra in range(g+h-lo+1))
    print(f'{g} gates, {h} selected, {profiles} profiles, {bags} raw-occurrence multisets',flush=True)
