#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;
#ifndef GATE_BUDGET
#define GATE_BUDGET 6
#endif
constexpr int B=21,G=GATE_BUDGET; using U=uint64_t;using Bits=array<U,B>;using Family=array<int,12>;
struct W{int m=0;Bits neg{},cov{};};
Bits pos[8192]{},ALL{};W raw[8192];bool israw[8192]{};vector<pair<int,int>> obs;
W join(const W&a,const W&b,int op){W v;v.m=op?a.m|b.m:a.m&b.m;for(int z=0;z<B;z++){v.neg[z]=op?a.neg[z]|b.neg[z]:a.neg[z]&b.neg[z];v.cov[z]=pos[v.m][z]&~v.neg[z];}return v;}
void add(Bits&a,const Bits&b){for(int z=0;z<B;z++)a[z]|=b[z];}
set<Family> out;long long bags=0,bottoms=0,tops=0,complete=0;
struct Search{
 int h,S;vector<int> fixed,F,base,avail;Bits fixedcover{};vector<W> made;
 map<int,int> unused;vector<int> skipped;int L=0;
 bool covered(const vector<int>& later){
  Bits c=fixedcover;
  for(auto& v:made)add(c,v.cov);for(int i:later)add(c,raw[i].cov);
  for(auto [i,n]:unused)if(n)add(c,raw[i].cov);
  return c==ALL;
 }
 void record(){
  ++complete;
  for(int m=0;m<1<<G;m++)if(popcount((unsigned)m)==h){
   Bits c=fixedcover;vector<int> family=fixed;
   for(int i=0;i<G;i++)if(m>>i&1){if(israw[made[i].m]||!made[i].m)break;add(c,made[i].cov);family.push_back(made[i].m);}
   if(family.size()!=12||c!=ALL)continue;
   sort(family.begin(),family.end());if(adjacent_find(family.begin(),family.end())!=family.end())continue;
   Family f;copy(family.begin(),family.end(),f.begin());out.insert(f);
  }
 }
 void top(const vector<int>& left){
  ++tops;int n=made.size(),remaining=G-n;
  if((int)left.size()>remaining)return;
  if(!remaining){record();return;}
  // Raw--raw gates have been enumerated in the bottom matching. Each next
  // gate consumes either one remaining raw occurrence or two previous outputs.
  for(int j=0;j<(int)left.size();j++){
   if(j && left[j]==left[j-1])continue;
   vector<int> next=left;int m=next[j];next.erase(next.begin()+j);
   for(int v=0;v<n;v++){
    for(int op=(popcount((unsigned)m)==1)?1:0;op<=1;op++){
     auto w=join(raw[m],made[v],op);
     if(!w.m)continue;
     made.push_back(w);if(covered(next))top(next);made.pop_back();
    }
   }
  }
  if((int)left.size()==remaining)return;
  for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)for(int op=0;op<2;op++){
   W w=join(made[i],made[j],op);if(!w.m)continue;
   made.push_back(w);if(covered(left))top(left);made.pop_back();
  }
 }
 void bottom(){
  ++bottoms;auto it=find_if(unused.begin(),unused.end(),[](auto v){return v.second>0;});
  if(it==unused.end()){if(made.size()+skipped.size()<=G)top(skipped);return;}
  if(made.size()>=G)return;
  int a=it->first;it->second--;
  if(2*((int)skipped.size()+1)+L-(int)skipped.size()-1<=2*G){
   skipped.push_back(a);bottom();skipped.pop_back();
  }
  for(auto jt=it;jt!=unused.end();jt++)if(jt->second){
   int b=jt->first;if(israw[a|b]||a==b)continue;
   --jt->second;made.push_back(join(raw[a],raw[b],1));
   if(covered(skipped))bottom();
   made.pop_back();++jt->second;
  }
  ++it->second;
 }
 void extras(int remain,int first,int n){
  if(!remain){++bags;L=n;bottom();return;}
  for(int j=first;j<(int)avail.size();j++){++unused[avail[j]];extras(remain-1,j,n);--unused[avail[j]];}
 }
 void start(){
  for(int p:fixed)add(fixedcover,raw[p].cov);
  for(int p:base)++unused[p];
  for(int i=0;i<13;i++)avail.push_back(1<<i);
  avail.insert(avail.end(),F.begin(),F.end());
  for(int l=base.size();l<=G+h;l++)extras(l-base.size(),0,l);
 }
};
int main(int argc,char**argv){
 ifstream in("obs");int a,b;while(in>>a>>b)obs.emplace_back(a,b);if(obs.size()!=1323)return 1;
 for(int i=0;i<1323;i++)ALL[i/64]|=U(1)<<(i%64);
 for(int m=1;m<8192;m++){raw[m].m=m;for(int i=0;i<1323;i++){auto [p,n]=obs[i];U bit=U(1)<<(i%64);if(p&m)pos[m][i/64]|=bit;if(n&m)raw[m].neg[i/64]|=bit;}for(int i=0;i<B;i++)raw[m].cov[i]=pos[m][i]&~raw[m].neg[i];}
 for(int i=0;i<13;i++)israw[1<<i]=true;
 for(int j=0;j<6;j++){a=(1<<j)|(1<<(j+1));b=(1<<(j+3))|(1<<((j+9)%13));israw[a]=israw[b]=israw[a|b]=true;}
 int h,S,r,nf,ix=0;int from=argc>1?atoi(argv[1]):0,to=argc>2?atoi(argv[2]):100000000;
 while(cin>>h>>S>>r){
  Search q;q.h=h;q.S=S;
  for(int k=0;k<13;k++)if(S>>k&1)q.fixed.push_back(1<<k);
  for(int j=0;j<r;j++){cin>>a;q.fixed.push_back(a);}
  cin>>nf;for(int j=0;j<nf;j++){cin>>a;q.F.push_back(a);if(find(q.fixed.begin(),q.fixed.end(),a)==q.fixed.end())q.base.push_back(a);}
  for(int j=0;j<13;j++){int d;cin>>d;for(int k=0;k<d;k++)q.base.push_back(1<<j);}
  if(from<=ix&&ix<to)q.start();
  if(++ix%1000==0&&from<=ix&&ix<=to)cerr<<"case "<<ix<<" bags "<<bags<<" banks "<<out.size()<<"\n";
 }
 for(auto f:out){for(int v:f)cout<<v<<' ';cout<<G<<"\n";}
 cerr<<"DONE "<<ix<<" bags "<<bags<<" bottom "<<bottoms<<" top "<<tops<<" terminal "<<complete<<" banks "<<out.size()<<"\n";
}
