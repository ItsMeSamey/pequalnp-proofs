from collections import defaultdict,Counter
from itertools import combinations,combinations_with_replacement
from pathlib import Path
from sample import *
root=Path(__file__).resolve().parent
def read_bases(name):return {tuple(map(int,l.split())) for l in (root/name).read_text().splitlines()}
def points():
 fams=[tuple(map(int,l.split())) for l in (root/'banks-through-eight.txt').read_text().splitlines()]
 group=symmetries();seen=set();out=defaultdict(list)
 for row in sorted(fams,key=lambda r:(r[-1],r[:-1])):
  f,price=row[:-1],row[-1]
  if f in seen:continue
  seen.update(tuple(sorted(move(m,p) for m in f)) for p,l in group);out[price].append(f)
 return out
def all_line():
 R=set(raw)
 ordinary={tuple(sorted((*raw,*e))) for e in combinations_with_replacement(range(128),3)}
 high=read_bases('exceptional-ten.txt')|{tuple(sorted((*s,x))) for s in read_bases('exceptional-nine.txt') for x in range(128)}
 return sorted(ordinary|high)
def allowed_sets():
 R=set(raw);states={()};possible={()};out={}
 for g in range(1,5):
  nx=set()
  for st in states:
   have=R|set(st)
   for a,b in combinations(have,2):
    for x in (a&b,a|b):
     if x and x not in have:nx.add(tuple(sorted((*st,x))))
  states=nx
  for st in states:
   for k in range(len(st)+1):possible.update(combinations(st,k))
  if g>=3:out[g]=set(possible)
 return out
def line_domains():
 full=all_line();possible=allowed_sets();R=set(raw);out={5:full,6:full}
 for pcost in (7,8):
  g=11-pcost;lines=[]
  for f in full:
   r=R&set(f);non=tuple(sorted(set(f)-R-{0}))
   if len(r)>=10-g and non in possible[g]:lines.append(f)
  out[pcost]=lines
 return out
