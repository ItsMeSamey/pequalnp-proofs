from pathlib import Path
from subprocess import run
from tempfile import TemporaryDirectory
import sys
from domains import points,line_domains,pos,neg
root=Path(__file__).resolve().parent
def audit_bases():
 from pysat.card import CardEnc
 from pysat.solvers import Solver
 from sample import raw
 from domains import read_bases
 obligations={(p>>13,n>>13) for p in pos for n in neg if not (p&8191)&~n}
 previous={raw}
 for width,name in [(9,'exceptional-nine.txt'),(10,'exceptional-ten.txt')]:
  clauses=CardEnc.atmost(list(range(1,128)),width,top_id=127).clauses
  clauses.extend([m for m in range(1,128) if m&p and not m&n] for p,n in obligations)
  clauses.extend([-m for m in l] for l in previous)
  found=set()
  with Solver(name='cadical195',bootstrap_with=clauses) as solver:
   while solver.solve():
    ms=tuple(sorted(m for m in solver.get_model() if 1<=m<=127))
    assert len(ms)==width
    found.add(ms);solver.add_clause([-m for m in ms])
  assert found==read_bases(name)
  previous.update(found)
def main():
 audit_bases();p=points();domains=line_domains()
 assert {c:(len(p[c]),len(domains[c])) for c in p}=={5:(2,361245),6:(5,361245),7:(25,71920),8:(119,23325)}
 selected=tuple(map(int,sys.argv[1:])) or (8,7,5,6)
 with TemporaryDirectory() as t:
  tmp=Path(t);exe=tmp/'cut'
  run(['c++','-O3','-std=c++20','-march=native',root/'cut.cpp','-o',exe],check=True)
  sample=tmp/'samples';sample.write_text('28 245\n'+' '.join(map(str,sorted(pos)))+'\n'+' '.join(map(str,sorted(neg)))+'\n')
  pf=tmp/'points';lf=tmp/'lines'
  for c in selected:
   ps=p[c];ls=domains[c];pf.write_text(''.join(' '.join(map(str,f))+'\n' for f in ps));count=[0,0,0]
   for lo in range(0,len(ls),512):
    chunk=ls[lo:lo+512];lf.write_text(''.join(' '.join(map(str,f))+'\n' for f in chunk))
    r=run([exe,sample,pf,lf,'0',str(len(ps))],text=True,capture_output=True,check=True)
    total,bip,surv=map(int,r.stderr.splitlines()[-1].split()[1:])
    assert not r.stdout and not surv and total==len(ps)*len(chunk)
    count[0]+=total;count[1]+=bip;count[2]+=surv
   print(c,*count,flush=True)
if __name__=='__main__':main()
