# Width twelve with 22 mixed gates and ten line leaves

Twelve point and ten line leaves give 22 mixed leaves. A 22-gate binary circuit has exactly one operand use beyond a tree, so exactly one mixed or boundary signal is used twice. At a total price of 33, ten line leaves require at least three paid line gates, bounding the point price by eight. The point table includes all 2,767 actual through-eight banks. Sorting by price before quotienting by the 24 sample automorphisms gives 2, 5, 25 and 119 representatives first occurring at prices five, six, seven and eight.

A point representative is tested at the lowest price of any available bank in its orbit. This grants every line price that could occur for any bank in that orbit, even if a sample automorphism changes availability of some frozen point primitive. Line singleton atoms are permuted by every automorphism, preserving the line gate budget.

The line-bank domain includes zero signatures, omitted raw labels and repeated signatures. Minimal-cover SAT enumeration recovers the unique seven-label basis, 24 nine-label minimal bases and 437 ten-label minimal bases. Padding to ten positions produces 361,245 possible line multisets. The two cheapest point classes receive this entire unrestricted domain. Price seven permits at most four line gates and price eight at most three. Enumerate all sets of singleton signatures generable by that many distinct unions or intersections on the seven singleton raw masks. Repeated or primitive gate results can be bypassed without changing which singleton signatures are obtainable, and zero contributes no distinct nonprimitive mask. Retain every ten-position line multiset whose nonprimitive signatures are jointly available and which includes at least ten minus the gate budget distinct raw singleton labels. The latter follows because the actual boundary has ten distinct physical line wires, with no more paid wires than the gate budget. This gives 71,920 and 23,325 candidate multisets, respectively.

For the one-copy condition, cut off the expression computing the repeated signal D. Its inner leaves form a read-once subtree and the outer expression has its remaining leaves plus two formal D ports. A repeated boundary leaf is the case of a singleton inner set. An inner set of size greater than one must include both point and line ancestry. Shrinking each boundary signal on negative rows to the OR given by its singleton signature preserves successful separation.

A row pair with just one distinguishing input forces that leaf to be sensitive at both rows. For two leaves in the same read-once region, common sensitivity at a positive requires their lowest common ancestor to be AND. Common sensitivity at a negative requires OR. Hence a pair subject to both requirements must lie on opposite sides of the cut. The cached checker uses point-private witnesses where the raw lines are comparable and line-private witnesses where the raw points are comparable. It two-colors the resulting graph and tries both orientations of each component, including isolates.

During partial assignment let A be the assigned inner leaves and B the assigned outer leaves. For each positive/negative comparison whose complete set of distinguishing leaves lies in A, D must be one on that positive and zero on that negative: no outer original leaf helps. Collect all of the forced positive endpoints Q and negative endpoints R. If any q in Q and r in R are distinguished only by leaves already in B, no eventual inner expression can separate them. Monotonicity of D rules out every completion of that assignment. At a complete assignment the same argument and the mixed ancestry condition apply. This checker is the W12/L9 one-copy checker extended from nine to ten line positions.

Run `python verify.py` using Python-SAT with CaDiCaL and a C++20 compiler. A positional price limits the phase, for example `python verify.py 8`. The line slice is processed in bounded batches to keep the peak C++ storage small.

The reference replay exhausted all 7,102,390 point-orbit and line-multiset combinations. The prices count paid point gates.

| Point price | Combinations | Bipartite conflict graph | Surviving cuts |
| --- | ---: | ---: | ---: |
| 5 | 722,490 | 361,245 | 0 |
| 6 | 1,806,225 | 1,444,980 | 0 |
| 7 | 1,798,000 | 1,726,080 | 0 |
| 8 | 2,775,675 | 2,730,644 | 0 |

Thus a circuit with 22 mixed gates, twelve point boundary wires and ten line boundary wires costs at least 34 gates.
