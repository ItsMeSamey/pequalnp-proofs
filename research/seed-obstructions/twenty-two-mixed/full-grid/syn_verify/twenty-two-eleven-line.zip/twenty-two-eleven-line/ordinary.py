"""Can at most three arbitrary extra line signatures remove all raw LCA conflicts?"""
from pathlib import Path
from itertools import combinations
from collections import Counter
from pysat.card import CardEnc
from pysat.solvers import Solver
import sys
from sample import base_info,symmetries,move
def maximal(v):
 return tuple(x for x in v if not any(x!=y and not x&~y for y in v))
def query(f,k):
 pp,nn,pv,nv,ps,ns,private=base_info(f)
 pw=[[] for _ in range(7)]
 for l,i,j in private:pw[l].append((i,j,nn[j]>>13))
 c=CardEnc.atmost(list(range(1,128)),k,top_id=127);cs=c.clauses;top=c.nv
 constraints=set()
 for l in range(7):
  def options(n):return [x for x in range(1,128) if x&(1<<l) and not x&n]
  for t in range(7,19):
   A=maximal({n for i,j,n in pw[l] if ps[t]>>i&1})
   O=maximal({n for i,j,n in pw[l] if ns[t]>>j&1})
   if not A or not O: continue
   key=(l,A,O)
   if key in constraints:continue
   constraints.add(key)
   top+=1;flag=top
   cs.extend([[-flag,*options(n)] for n in A])
   cs.extend([[flag,*options(n)] for n in O])
 with Solver(name='cadical195',bootstrap_with=cs) as s:
  if not s.solve():return None
  return tuple(x for x in s.get_model() if 1<=x<=127)
