from pathlib import Path
from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
from sample import raw,base_info,symmetries,move
def clauses(f):
 pos,neg,pv,nv,ps,ns,private=base_info(f)
 pp=[sum(1<<t for t in range(12) if ps[t+7]>>i&1) for i in range(len(pos))]
 nn=[sum(1<<t for t in range(12) if ns[t+7]>>j&1) for j in range(len(neg))]
 raww={}
 for l,i,j in private:
  n=neg[j]>>13;k=(l,n);a,o=raww.get(k,(0,0));raww[k]=(a|pp[i],o|nn[j])
 W=[([x for x in range(1,128) if x&(1<<l) and not x&n],a,o) for (l,n),(a,o) in raww.items()]
 v=IDPool(start_from=255);cs=CardEnc.atmost(list(range(1,255)),11,vpool=v).clauses
 cs.extend([[-(x+127),x] for x in range(1,128)])
 for D,a,o in W:
  cs.append(D)
  for x in D:
   only=v.id();cs.append([x+127,*[y for y in D if x!=y],only])
   if a&o:cs.append([-only]);continue
   for i in range(12):
    if (a|o)>>i&1:
     z=v.id(('lca',x,i));cs.append([-only,z if a>>i&1 else -z])
 return cs

def main():
 root=Path(__file__).resolve().parent
 point_rows=(root/'banks-through-seven.txt').read_text().splitlines()
 banks={tuple(map(int,row.split()[:-1])) for row in point_rows}
 assert len(banks)==461
 seen=set();tested=0;group=symmetries()
 for f in sorted(banks):
  if f in seen:continue
  seen.update(tuple(sorted(move(m,p) for m in f)) for p,lm in group)
  with Solver(name='cadical195',bootstrap_with=clauses(f)) as solver:
   assert not solver.solve(),f
  tested+=1
 assert tested==32
 print(tested,'point orbits, arbitrary line multisets of cardinality at most eleven, all UNSAT')
if __name__=='__main__':main()
