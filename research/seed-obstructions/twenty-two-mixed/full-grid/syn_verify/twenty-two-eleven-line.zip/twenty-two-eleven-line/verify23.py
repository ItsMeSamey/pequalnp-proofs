"""Nearby read-once case at 23 mixed gates, twelve point leaves and twelve line leaves."""
from pathlib import Path
from sample import symmetries,move
from ordinary import query
root=Path(__file__).resolve().parent
fams=[tuple(map(int,l.split()[:-1])) for l in (root/'banks-through-seven.txt').read_text().splitlines() if l.split()[-1]=='5']
assert len(fams)==5
seen=set();tested=0
for f in fams:
 if f in seen:continue
 seen.update(tuple(sorted(move(x,p) for x in f)) for p,l in symmetries())
 assert query(f,5) is None
 tested+=1
assert tested==2
print(tested,'point orbits, seven raw plus five arbitrary extra line masks, all UNSAT')
