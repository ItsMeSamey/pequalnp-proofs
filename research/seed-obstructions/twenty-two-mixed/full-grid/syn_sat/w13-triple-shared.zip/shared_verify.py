from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys
root=Path(__file__).resolve().parent
Q=(15,23,27,46,83)
with TemporaryDirectory() as tmp:
    d=Path(tmp)
    def run(args,out=None,inp=None):
        with (out or Path('/dev/null')).open('w') as f:subprocess.run(args,stdout=f,stdin=inp,check=True,cwd=root)
    def py(name,*args,out=None):run([sys.executable,root/name,*map(str,args)],out)
    py('prepare8.py',d)
    for name in ('shared','fast','endpoint_pruned'):
        run(['c++','-O3','-std=c++20',root/(name+'.cpp'),'-o',d/name])
    for b in (9,8):
        for e in Q:
            for k in range(12-b):
                dest=d/f'outside-{b}-{e}-{k}'
                py('outside9.py' if b==9 else 'outside.py',e,k,*(['exact'] if k==11-b else []),out=dest)
                if k<11-b:assert not dest.stat().st_size
            row=(d/f'private8-{e}.data').read_text().splitlines()[0].split();base=set(map(int,row[4:]))
            for line in dest.read_text().splitlines():
                u=list(map(int,line.split()));assert len(u)==b and len(set(u)-base)==11-b
            run([d/'shared',str(b),d/f'private8-{e}.data',dest],d/f'shared{b}BANK-{e}')
        py('shared_packets.py',d,b,out=d/'count')
        inp=d/f'shared-{b}.in'
        with inp.open() as f:run([d/'fast'],d/'first',f)
        answers=(d/'first').read_text().splitlines()
        assert len(answers)=={8:37520,9:1751}[b]
        with inp.open() as f,(d/'pending').open('w') as output:
            for x,ans in zip(f,answers,strict=True):
                assert ans in ('0','1')
                if ans=='1':output.write(x)
        with (d/'pending').open() as f:run([d/'endpoint_pruned','13','8','2'],d/'final',f)
        res=(d/'final').read_text().splitlines();assert len(res)==answers.count('1') and all(x.startswith('0 ') for x in res)
        print('outside',b,'packets',len(answers),'exact exhaustions',len(res),flush=True)
