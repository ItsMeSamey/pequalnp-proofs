"""Lift permitted outside slot supports to physical multisets, canonicalize joint symmetry."""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from collections import Counter
from instance import stars
from replay import groups,make
import sys
path=Path(sys.argv[1])
def completed(bank):
    missing=13-len(bank)
    assert missing>=0
    for fill in combinations_with_replacement(sorted({0,*bank}),missing):
        yield tuple(sorted((*bank,*fill)))
def paired(E,allbank):
    masks=[sum(1<<i for i in j) for j in combinations([i for i in range(7) if E>>i&1],3)]
    for b in completed(allbank):
        images=[tuple(sorted(pm[x] for x in b)) for pm,lm in groups]
        for m in masks:
            yield min((t,lm[m]) for t,(_,lm) in zip(images,groups))
if __name__=='__main__':
    seen=set();hist=Counter()
    for E in (15,23,27,46,83):
        for line in (path/f'shared{sys.argv[2]}BANK-{E}').read_text().splitlines():
            bank=list(map(int,line.split()));assert len(bank)==13
            hist[E,len(bank)]+=1;seen.update(paired(E,bank))
    print('models',sorted(hist.items()),'orbits',len(seen),flush=True)
    with (path/f'shared-{sys.argv[2]}.in').open('w') as f, (path/f'shared-{sys.argv[2]}.reps').open('w') as qq:
        for b,m in sorted(seen):
            print(*b,m,file=qq);f.write(make(b,m))
