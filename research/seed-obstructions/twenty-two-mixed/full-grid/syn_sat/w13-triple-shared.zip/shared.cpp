#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
using U=__uint128_t;
using Bank=array<int,13>;
using Cov=array<uint64_t,21>;
using Opt=vector<vector<int>>;
int noutside,N;array<int,3>T;array<U,3> forbid;
vector<int>base;vector<U>val;array<Cov,8192>cover;vector<vector<int>>outside;
set<Bank>survivors;
U op(U a,U b,int v){return v?a|b:a&b;}
bool good(U a,int t){return int(a&8191)==T[t] && !(a&forbid[t]);}
bool anyform(const vector<U>&v,int t){
    int n=v.size();if(n==1)return good(v[0],t);
    if(n==2)return good(v[0]&v[1],t)||good(v[0]|v[1],t);
    if(n==3){
        for(int i=0;i<3;i++){U a=v[i],b=v[(i+1)%3],c=v[(i+2)%3];
            for(int x=0;x<2;x++)for(int y=0;y<2;y++)if(good(op(a,op(b,c,x),y),t))return true;}
        return false;
    }
    for(int i=0;i<4;i++)for(int j=0;j<4;j++)if(i!=j){
        int l=0;while(l==i||l==j)l++;int r=6-i-j-l;
        for(int x=0;x<2;x++)for(int y=0;y<2;y++)for(int z=0;z<2;z++)
            if(good(op(v[i],op(v[j],op(v[l],v[r],x),y),z),t))return true;
    }
    for(int i=1;i<4;i++){int j=1;while(j==i)j++;int k=6-i-j;
        for(int x=0;x<2;x++)for(int y=0;y<2;y++)for(int z=0;z<2;z++)
            if(good(op(op(v[0],v[i],x),op(v[j],v[k],y),z),t))return true;}
    return false;
}
Opt get(int t,int count,bool d,U value=0){
    Opt out;vector<int>masks;vector<U>vs;if(d)vs.push_back(value);
    auto dfs=[&](auto&self,int start,int left)->void{
        if(!left){if(anyform(vs,t))out.push_back(masks);return;}
        for(int k=start;k<(int)base.size();k++){masks.push_back(base[k]);vs.push_back(val[k]);self(self,k,left-1);masks.pop_back();vs.pop_back();}
    };dfs(dfs,0,count);return out;
}
void join(const vector<int>&d,const vector<int>&a,const vector<int>&b,const vector<int>&v){
    vector<int>p=d;for(auto z:{&a,&b,&v})p.insert(p.end(),z->begin(),z->end());
    for(auto&out:outside){
        Bank bank;copy(out.begin(),out.end(),bank.begin());copy(p.begin(),p.end(),bank.begin()+noutside);sort(bank.begin(),bank.end());
        if(!bank[0])continue;
        bool dup=false;for(int i=1;i<13;i++)if(bank[i]==bank[i-1]&&has_single_bit((unsigned)bank[i]))dup=true;if(dup)continue;
        if(survivors.count(bank))continue;
        Cov h{};for(int x:bank)for(int j=0;j<21;j++)h[j]|=cover[x][j];
        if(h[20]!=(1ull<<43)-1)continue;bool ok=true;for(int j=0;j<20;j++)if(~h[j])ok=false;if(ok)survivors.insert(bank);
    }
}
int main(int argc,char**argv){
    noutside=atoi(argv[1]);int npriv=13-noutside;ifstream data(argv[2]),out(argv[3]);
    for(int&x:T)data>>x;data>>N;base.resize(N);for(int&x:base)data>>x;
    int p,q,r=0;while(data>>p>>q){for(int x=1;x<8192;x++)if((p&x)&&!(q&x))cover[x][r/64]|=1ull<<(r%64);r++;}if(r!=1323)return 2;
    for(int m:base){U a=m;int bit=13;for(int i=0;i<13;i++)for(int j=i+1;j<13;j++,bit++){int mask=(1<<i)|(1<<j);if(m&mask)a|=U(1)<<bit;for(int t=0;t<3;t++)if(!(T[t]&mask))forbid[t]|=U(1)<<bit;}val.push_back(a);}
    set<vector<int>>outs;for(vector<int>v(noutside);out>>v[0];){for(int i=1;i<noutside;i++)if(!(out>>v[i]))return 3;outs.insert(v);}outside.assign(outs.begin(),outs.end());
    if(outside.empty())return 0;
    array<array<Opt,3>,3>ordinary;for(int t=0;t<3;t++)for(int s=1;s<=2;s++)ordinary[t][s]=get(t,s,false);
    auto process=[&](vector<int>d,U D){
        int ds=d.size(),m=D&8191;
        if(!m)return;
        if(ds>1 && (popcount((unsigned)m)<2||all_of(T.begin(),T.end(),[&](int t){return m&~t;})))return;
        array<array<Opt,4>,3> roles;bool ready[3][4]{};
        auto role=[&](int t,int s)->const Opt&{if(!ready[t][s]){roles[t][s]=get(t,s,true,D);ready[t][s]=true;}return roles[t][s];};
        for(int i=0;i<3;i++){int j=(i+1)%3,k=(i+2)%3;
            for(int nv=1;nv<=2;nv++)for(int na=0;na<=3;na++){
                int nb=npriv-ds-nv-na;if(nb<0||nb>3||max(na,nb)<1)continue;
                // A=D, B uses D and only one other leaf: any genuine operation is comparable with A.
                if(min(na,nb)==0&&max(na,nb)<=1)continue;
                int t1=j,t2=k,n1=na,n2=nb;if(n2<n1){swap(n1,n2);swap(t1,t2);}
                auto&a=role(t1,n1);if(a.empty())continue;auto&b=role(t2,n2);if(b.empty())continue;
                for(auto&x:a)for(auto&y:b)for(auto&v:ordinary[i][nv])join(d,x,y,v);
            }
        }
    };
    for(int a=0;a<N;a++)if(base[a]){process({base[a]},val[a]);
        if(npriv==5)for(int b=a;b<N;b++)if(base[b])for(int g=0;g<2;g++)process({base[a],base[b]},op(val[a],val[b],g));}
    for(auto&b:survivors){for(int x:b)cout<<x<<' ';cout<<'\n';}
    cerr<<"outside "<<outside.size()<<" surviving banks "<<survivors.size()<<'\n';
}
