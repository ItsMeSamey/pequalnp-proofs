#include "puretree.hpp"
#include <bit>
using namespace std;
using Bank=array<int,13>;
int main(int argc,char**argv){
    if(argc!=5)return 2;
    ifstream action(argv[1]),samples(argv[2]),points(argv[3]);
    int maxlabels=atoi(argv[4]),tmp;
    for(int i=0;i<31;i++)action>>tmp;
    array<array<int,8192>,24> G;array<array<int,128>,24> L{};
    array<int,7> stars{};
    for(int i=0;i<7;i++)for(int k:{0,1,3,9})stars[i]|=1<<((6+i+k)%13);
    for(int g=0;g<24;g++){
        for(int&x:G[g])action>>x;
        for(int m=1;m<128;m++){int j=countr_zero((unsigned)m),v=find(stars.begin(),stars.end(),G[g][stars[j]])-stars.begin();assert(v<7);L[g][m]=L[g][m&(m-1)]|(1<<v);}
    }
    int np,nn;samples>>np>>nn;assert(np==28&&nn==245);vector<int> rows(np+nn);for(int&x:rows)samples>>x;
    set<Bank> banks;Bank b;long long nbank=0;
    auto move=[&](Bank q,int g){for(int&x:q)x=G[g][x];sort(q.begin(),q.end());return q;};
    while(points>>b[0]){for(int i=1;i<13;i++)points>>b[i];nbank++;Bank key=b;for(int g=0;g<24;g++)key=min(key,move(b,g));banks.insert(key);}
    long long cnt=0,yes=0;
    for(auto& q:banks){
        vector<int> H;for(int g=0;g<24;g++)if(move(q,g)==q)H.push_back(g);
        vector<int> projected=rows;
        for(int&x:projected){int out=x&~8191;for(int i=0;i<13;i++)if(x&q[i]&8191)out|=1<<i;x=out;}
        vector<int> pos(projected.begin(),projected.begin()+np),neg(projected.begin()+np,projected.end());
        sort(neg.begin(),neg.end(),[](int a,int b){return popcount((unsigned)a)>popcount((unsigned)b);});
        vector<int> maximal;for(int x:neg)if(none_of(maximal.begin(),maximal.end(),[&](int y){return !(x&~y);}))maximal.push_back(x);
        sort(pos.begin(),pos.end());pos.erase(unique(pos.begin(),pos.end()),pos.end());
        for(int m=1;m<128;m++){
            int k=popcount((unsigned)m);if(k<2||k>maxlabels||any_of(H.begin(),H.end(),[&](int g){return L[g][m]<m;}))continue;
            vector<int>P=pos,N=maximal;
            for(auto v:{&P,&N})for(int&x:*v)if((x>>13)&m)x|=1<<20;
            frontierlib::Search run;if(run.treecut(P,N,21)){yes++;for(int x:q)cout<<x<<' ';cout<<m<<'\n';}
            cnt++;if(cnt%50000==0)cerr<<"progress "<<cnt<<" pending "<<yes<<'\n';
        }
    }
    cerr<<"banks "<<nbank<<" bank-orbits "<<banks.size()<<" mixed-orbits "<<cnt<<" pending "<<yes<<'\n';
}
