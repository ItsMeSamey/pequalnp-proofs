"""Replay price filters and the streamed two-cut screen without materializing large case tables."""
from pathlib import Path
from tempfile import TemporaryDirectory
from hashlib import sha256
import argparse,gzip,subprocess,sys
from instance import raw
from samples import actions,raw_samples
from replay import make
root=Path(__file__).resolve().parent
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('cost',type=int,choices=(3,4,5,6,7,8))
    args=parser.parse_args();g=args.cost
    name='W13-g8-potential.txt.gz' if g==8 else 'W13-g7-potential.txt.gz'
    catalogue=root/name
    if g!=8:assert sha256(catalogue.read_bytes()).hexdigest()=='89a64de1853b6b3f974d437cde4736ae6985dea85417e53056e2434c075941d1'
    with TemporaryDirectory() as tmp:
        w=Path(tmp);action=w/'action';samples=w/'samples'
        pos,neg=raw_samples(root/'L-meta-18968.json')
        samples.write_text(' '.join(map(str,[len(pos),len(neg),*sorted(pos),*sorted(neg)])))
        with action.open('w') as out:
            print(*sorted(raw),file=out)
            for pm in actions(pos,neg):print(*pm,file=out)
        for filename,exe in [('filterfast.cpp','filter'),('batch.cpp','batch')]:
            subprocess.run(['c++','-std=c++20','-O3',root/filename,'-o',w/exe],check=True)
        source=w/'points'
        with gzip.open(catalogue,'rb') as inp,source.open('wb') as out:
            z=subprocess.run([w/'filter',str(g),action],input=inp.read(),stdout=out,stderr=subprocess.PIPE,check=True)
        print(z.stderr.decode().strip(),flush=True)
        if g>=6:
            subprocess.run([sys.executable,root/'pad.py',str(g),source,w/'with-pad'],check=True)
            source=w/'with-pad'
        result=subprocess.run([w/'batch',action,samples,source,str(min(7,12-g))],capture_output=True,text=True,check=True)
        print(result.stderr.strip(),flush=True)
        if result.stdout:
            subprocess.run(['c++','-std=c++20','-O3',root/'endpoint.cpp','-o',w/'endpoint'],check=True)
            rows=[tuple(map(int,l.split())) for l in result.stdout.splitlines()]
            inp=''.join(make(r[:-1],r[-1]) for r in rows)
            result=subprocess.run([w/'endpoint','13','8','2'],input=inp,capture_output=True,text=True,check=True)
            lines=result.stdout.splitlines()
            assert len(lines)==len(rows) and all(l.startswith('0 pre ') for l in lines)
            print('remaining exact frontiers exhausted',len(lines))
if __name__=='__main__':main()
