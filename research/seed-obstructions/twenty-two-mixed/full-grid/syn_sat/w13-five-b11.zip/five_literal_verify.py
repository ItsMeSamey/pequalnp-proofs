from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys
root=Path(__file__).resolve().parent
with TemporaryDirectory() as tmp:
    d=Path(tmp)
    for e in (31,47,87):
        for k in range(4):
            with (d/f'five11-{e}-{k}').open('w') as out:
                subprocess.run([sys.executable,root/'five11.py',str(e),str(k),*(['exact'] if k==3 else [])],stdout=out,check=True)
    subprocess.run([sys.executable,root/'five_packets.py',d,'11'],check=True)
    for name in ('fast','endpoint_multi'):
        subprocess.run(['c++','-O3','-std=c++20',root/(name+'.cpp'),'-o',d/name],check=True)
    with (d/'five-11.in').open() as f:
        votes=subprocess.run([d/'fast'],stdin=f,capture_output=True,text=True,check=True).stdout.splitlines()
    assert len(votes)==6741 and votes.count('1')==18
    with (d/'five-11.in').open() as f:
        raw=''.join(s for s,v in zip(f,votes,strict=True) if int(v))
    result=subprocess.run([d/'endpoint_multi','13','8','2'],input=raw,capture_output=True,text=True,check=True).stdout.splitlines()
    assert len(result)==18 and all(s.startswith('0 ') for s in result)
    print('All 6741 physical triple packets excluded')
