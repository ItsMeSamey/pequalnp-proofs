"""Raise the W13/L8 price floor using the published W13 potential bank superset."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse,gzip,subprocess,sys
from instance import raw
from samples import actions,raw_samples
root=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('cost',type=int)
    args=parser.parse_args();g=args.cost
    assert g in (2,3,4,5)
    source=root/'W13-g7-potential.txt.gz'
    assert sha256(source.read_bytes()).hexdigest()=='89a64de1853b6b3f974d437cde4736ae6985dea85417e53056e2434c075941d1'
    with TemporaryDirectory() as tmp:
        w=Path(tmp);action=w/'action'
        with action.open('w') as out:
            print(*sorted(raw),file=out)
            for pm in actions(*raw_samples(root/'L-meta-18968.json')):print(*pm,file=out)
        for sourcefile,exe in [('filter.cpp','filter'),('fast.cpp','fast')]:
            subprocess.run(['c++','-std=c++20','-O3',root/sourcefile,'-o',w/exe],check=True)
        with gzip.open(source,'rb') as inp, (w/'points').open('wb') as out:
            proc=subprocess.run([w/'filter',str(g),action],input=inp.read(),stdout=out,stderr=subprocess.PIPE,check=True)
        print(proc.stderr.decode().strip(),flush=True)
        subprocess.run([sys.executable,root/'replay.py',w/'points',w/'reps',w/'in'],check=True)
        with (w/'in').open('rb') as inp:
            tested=subprocess.run([w/'fast'],stdin=inp,capture_output=True,check=True).stdout.splitlines()
        lines=(w/'in').read_bytes().splitlines()
        assert len(lines)==len(tested) and set(tested)<={b'0',b'1'}
        pending=[l for l,z in zip(lines,tested) if z==b'1']
        print('two-cut prefilter checked',len(lines),'pending',len(pending),flush=True)
        if pending:
            subprocess.run(['c++','-std=c++20','-O3',root/'endpoint.cpp','-o',w/'endpoint'],check=True)
            hard=subprocess.run([w/'endpoint','13','8','2'],input=b'\n'.join(pending)+b'\n',capture_output=True,check=True).stdout.splitlines()
            assert len(hard)==len(pending) and all(l.startswith(b'0 pre ') for l in hard)
        print('all mixed cases excluded',flush=True)
if __name__=='__main__':main()
