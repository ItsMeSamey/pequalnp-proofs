#include <algorithm>
#include <array>
#include <bit>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <vector>
#include <map>
#include <set>
#include <unordered_map>
using namespace std;
using Mask=unsigned;
struct Sig{unsigned p=0;array<uint64_t,4> n{};int type=0;auto operator<=>(const Sig&)const=default;};
using State=vector<Sig>;
struct Node{Mask m;Sig v;auto operator<=>(const Node&)const=default;};
int np,nn,points=11,width=19,limit=2;
Sig comb(const Sig&a,const Sig&b,bool conjunction){
 Sig r;r.p=conjunction?a.p&b.p:a.p|b.p;r.type=a.type|b.type;
 for(int i=0;i<4;i++)r.n[i]=conjunction?a.n[i]&b.n[i]:a.n[i]|b.n[i];return r;
}
bool fits(const Sig& a,const Sig& req){if(req.p&~a.p)return false;for(int k=0;k<4;k++)if(a.n[k]&req.n[k])return false;return true;}
struct Instance{
 State in;int n;Mask all,edge[2][24]{};vector<pair<Mask,Sig>>delta;unordered_map<Mask,Sig>cache;
 Instance(const State& s,bool record):in(s),n(s.size()),all((1u<<n)-1){
  vector<Mask>p(np),q(nn),up(np),dn(nn);
  for(int i=0;i<n;i++){for(int k=0;k<np;k++)if(s[i].p>>k&1)p[k]|=1u<<i;for(int k=0;k<nn;k++)if(s[i].n[k/64]>>(k%64)&1)q[k]|=1u<<i;}
  unordered_map<Mask,Sig> ds;
  for(int i=0;i<np;i++)for(int j=0;j<nn;j++){
   Mask d=p[i]&~q[j];if(!d){fprintf(stderr,"invalid input state\n");exit(1);}
   if(record){auto &v=ds[d];v.p|=1u<<i;v.n[j/64]|=1ULL<<(j%64);}
   if(has_single_bit(d)){up[i]|=d;dn[j]|=d;}
  }
  delta.assign(ds.begin(),ds.end());
  for(int t=0;t<2;t++)for(auto m:(t?dn:up))for(auto z=m;z;z&=z-1)edge[t][countr_zero(z)]|=m^(z&-z);
 }
 bool cotree(Mask m)const{
  if(!m||has_single_bit(m))return true;
  for(auto &es:edge){
   Mask c=m&-m,q=c;while(q){unsigned i=countr_zero(q);q&=q-1;auto a=es[i]&m&~c;q|=a;c|=a;}
   if(c!=m)return cotree(c)&&cotree(m^c);
  }return false;
 }
 const Sig& need(Mask m){auto [it,added]=cache.try_emplace(m);if(added)for(auto &[d,v]:delta)if(!(d&~m))it->second=comb(it->second,v,false);return it->second;}
 vector<vector<Node>> enumerate(bool target_only){
  vector<vector<Node>> out(n+1);
  if(target_only&&!cotree(all))return out;
  for(int i=0;i<n;i++)out[1].push_back({1u<<i,in[i]});
  for(int sz=2;sz<=n;sz++){
   set<Node> vals;
   for(int l=1;l<=sz/2;l++){
    auto &ls=out[l],&rs=out[sz-l];
    for(auto &a:ls)for(auto &b:rs){
     if((l==sz-l&&a.m>=b.m)||(a.m&b.m)||(a.v.type|b.v.type)!=3)continue;
     Mask m=a.m|b.m;
     for(int op=0;op<2;op++){
      bool legal=true;for(Mask z=a.m;z;z&=z-1)if(edge[op][countr_zero(z)]&b.m){legal=false;break;}
      if(!legal)continue;
      Sig v=comb(a.v,b.v,op);if(fits(v,need(m)))vals.insert({m,v});
     }
    }
   }out[sz].assign(vals.begin(),vals.end());
  }return out;
 }
};
set<State> seen[5];long long counts[5]{},finalcot=0,firstsizes[24]{},secondsizes[24]{};
bool solve(State s,int k){
 sort(s.begin(),s.end());if(!seen[k].insert(s).second)return false;counts[k]++;
 if(k==0){Instance probe(s,false);if(!probe.cotree(probe.all))return false;finalcot++;}
 Instance x(s,true);
 auto all=x.enumerate(k==0);
 if(k==0)return !all.back().empty();
 for(int j=1;j<(int)all.size();j++)for(auto &nd:all[j]){
  (k==limit?firstsizes:secondsizes)[j]++;
  State after;for(int i=0;i<x.n;i++)if(!(nd.m>>i&1))after.push_back(s[i]);
  after.push_back(nd.v);after.push_back(nd.v);
  if(solve(after,k-1))return true;
 }return false;
}
int main(int argc,char**argv){if(argc==4){points=atoi(argv[1]);width=points+atoi(argv[2]);limit=atoi(argv[3]);}else if(argc!=1)return 4;
 if(points<=0||width<=points||limit<0||limit>4||width+limit>23)return 4;while(scanf("%d%d",&np,&nn)==2){
 if(np>32||nn>256)return 3;State s(width);for(int t=0;t<2;t++)for(int i=0;i<(t?nn:np);i++){
  unsigned row;scanf("%u",&row);for(int j=0;j<width;j++)if(row>>j&1){if(t)s[j].n[i/64]|=1ULL<<(i%64);else s[j].p|=1u<<i;}}
 for(int j=0;j<width;j++)s[j].type=j<points?1:2;
 for(auto& z:seen)z.clear();fill_n(counts,5,0);fill_n(firstsizes,24,0);fill_n(secondsizes,24,0);finalcot=0;
 bool ans=solve(s,limit);
 printf("%d pre %lld final %lld cot %lld first",ans,counts[1],counts[0],finalcot);for(int j=1;j<24;j++)if(firstsizes[j])printf(" %d:%lld",j,firstsizes[j]);puts("");fflush(stdout);
}}
