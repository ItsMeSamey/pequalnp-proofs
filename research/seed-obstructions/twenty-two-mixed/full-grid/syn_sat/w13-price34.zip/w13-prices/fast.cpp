#include "puretree.hpp"
int main(){
    using namespace std;
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int p,n;
    while(cin>>p>>n){
        vector<int> P(p),N(n);
        for(int&x:P)cin>>x;
        for(int&x:N)cin>>x;
        frontierlib::Search search;
        cout<<search.treecut(P,N,21)<<'\n';
    }
}
