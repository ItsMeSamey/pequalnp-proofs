#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;
array<int,31> raw;
array<bool,8192> israw{},raworbit{},single3{};
array<array<int,8192>,24> G;
map<vector<int>,bool> cache;
bool closure(vector<int>& pool,const vector<int>& targets){
    bool changed;
    do{changed=false;
        for(int t:targets){
            if(find(pool.begin(),pool.end(),t)!=pool.end())continue;
            bool ok=false;
            for(int a:pool){for(int b:pool)if((a|b)==t||(a&b)==t){ok=true;break;}if(ok)break;}
            if(ok){pool.push_back(t);changed=true;}
        }
    }while(changed);
    return all_of(targets.begin(),targets.end(),[&](int t){return find(pool.begin(),pool.end(),t)!=pool.end();});
}
bool feasible(const vector<int>&targets,int g){
    if(targets.empty())return true;
    if(targets.size()==1&&g==3)return single3[targets[0]];
    vector<int> base(raw.begin(),raw.end());
    if(closure(base,targets))return true;
    int h=g-targets.size();if(!h)return false;
    // At higher caps, deliberately grant every two-hidden-gate case.
    if(h>=2)return true;
    set<int> next;
    for(int a:base)for(int b:base)for(int m:{a|b,a&b})if(m&&!israw[m])next.insert(m);
    for(int m:next){
        if(find(targets.begin(),targets.end(),m)!=targets.end())continue;
        vector<int> pool=base;pool.push_back(m);if(closure(pool,targets))return true;
    }
    return false;
}
void prepare(){
    set<int> first;
    for(int a:raw)for(int b:raw)for(int m:{a|b,a&b})if(m&&!israw[m])first.insert(m);
    for(int a:first) {
        single3[a]=true;
        for(int b:first){single3[a|b]=true;single3[a&b]=true;}
        for(int b:raw)for(int c:{a|b,a&b}){
            single3[c]=true;
            for(int d:raw){single3[c|d]=true;single3[c&d]=true;}
            single3[c|a]=true;single3[c&a]=true;
        }
    }
}
int main(int argc,char**argv){
    int g=atoi(argv[1]);ifstream in(argv[2]);
    for(int&i:raw){in>>i;israw[i]=true;}
    for(auto&pm:G){for(int&i:pm)in>>i;for(int x:raw)raworbit[pm[x]]=true;}
    prepare();set<array<int,13>> valid;
    array<int,13> b;int rows=0;
    while(cin>>b[0]){
        for(int i=1;i<13;i++)cin>>b[i];rows++;
        if(b.front()==0||adjacent_find(b.begin(),b.end())!=b.end())continue;
        if(count_if(b.begin(),b.end(),[](int x){return !raworbit[x];})>g)continue;
        for(auto&pm:G){
            vector<int> paid;array<int,13> moved;
            for(int j=0;j<13;j++){int x=moved[j]=pm[b[j]];if(!israw[x])paid.push_back(x);}
            if((int)paid.size()>g)continue;
            sort(paid.begin(),paid.end());
            auto [it,added]=cache.try_emplace(paid,false);
            if(added)it->second=feasible(paid,g);
            if(it->second){sort(moved.begin(),moved.end());valid.insert(moved);}
        }
    }
    for(auto a:valid){for(int x:a)cout<<x<<' ';cout<<'\n';}
    cerr<<"budget "<<g<<" source "<<rows<<" paid sets "<<cache.size()<<" banks "<<valid.size()<<'\n';
}
