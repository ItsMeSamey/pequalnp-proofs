"""Check all simultaneous point-bank and line-extra representatives by mixed frontier."""
from pathlib import Path
from collections import Counter,defaultdict
from functools import lru_cache
from samples import raw_samples,actions
from instance import stars
import subprocess,sys
here=Path(__file__).resolve().parent
pos,neg=raw_samples(here/'L-meta-18968.json')
groups=[]
for pm in actions(pos,neg):
    bits=[1<<stars.index(pm[x]) for x in stars]
    lm=[sum(v for i,v in enumerate(bits) if m>>i&1) for m in range(128)]
    groups.append((pm,lm))
def project(b,m,rows):
    return {sum(1<<i for i,x in enumerate(b) if x&r&8191)|((r>>13)<<13)|(bool((r>>13)&m)<<20) for r in rows}
@lru_cache(None)
def base_rows(b):
    p=project(b,0,pos);n=project(b,0,neg)
    maximal=[]
    for r in sorted(n,key=int.bit_count,reverse=True):
        if all(r&~s for s in maximal):maximal.append(r)
    return sorted(p),sorted(maximal)
def make(b,m):
    p,n=base_rows(b)
    packed=[r|(bool((r>>13)&m)<<20) for r in p+n]
    return ' '.join(map(str,[len(p),len(n),*packed]))+'\n'
if __name__=='__main__':
    bs=[tuple(map(int,l.split())) for l in Path(sys.argv[1]).read_text().splitlines()]
    masks=[i for i in range(128) if i.bit_count()>=2]
    reps={}
    for b in bs:
        images=[tuple(sorted(g[x] for x in b)) for g,lm in groups]
        for m in masks:
            key=min((bm,g[1][m]) for bm,g in zip(images,groups))
            if key not in reps:reps[key]=(b,m)
    print('complete labelled',len(bs)*len(masks),'orbits',len(reps),flush=True)
    if len(sys.argv)>2:
        with open(sys.argv[2],'w') as outf:
            for b,m in reps.values():print(*b,m,file=outf)
    if len(sys.argv)>3:
        with open(sys.argv[3],'w') as outf:
            for b,m in reps.values():outf.write(make(b,m))
