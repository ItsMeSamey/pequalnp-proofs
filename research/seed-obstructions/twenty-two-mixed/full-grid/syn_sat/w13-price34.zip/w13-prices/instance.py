from collections import Counter
from itertools import combinations
from pathlib import Path
from input import point_obligations

raw, rows = point_obligations(Path(__file__).with_name('L-meta-18968.json'))
free = set(raw)
many = sorted(m for m in raw if m.bit_count() > 1)
stars = [sum(1 << ((6+j+d) % 13) for d in (0,1,3,9)) for j in range(7)]
local = {m for m in range(1,8192) if any(not m & ~t for t in stars)}

def demand_tables():
    tables = []
    for i in range(13):
        p = 1 << i
        incident = sum(1 << j for j,m in enumerate(many) if m & p)
        lookup = {}
        mask = incident
        while True:
            used = [m for j,m in enumerate(many) if mask >> j & 1]
            unresolved = [n for a,n in rows if a == p and all(n & m for m in used)]
            forbidden = {0} if unresolved else set()
            for n in unresolved:
                sub = n
                while sub:
                    forbidden.add(sub)
                    sub = (sub-1) & n
            points = [1 << j for j in range(13) if j != i]
            lookup[mask] = next(k for k in range(13)
                                if any(sum(w) not in forbidden for w in combinations(points,k)))
            if not mask:
                break
            mask = (mask-1) & incident
        tables.append((incident,lookup))
    return tables

def equality_cases():
    tables = demand_tables()
    cases = []
    for f in range(1 << len(many)):
        demands = [lookup[f & incident] for incident,lookup in tables]
        minimum = f.bit_count() + sum(sorted(demands)[:10])
        assert minimum >= 19
        if minimum != 19:
            continue
        for three in combinations(range(13),3):
            if f.bit_count()+sum(demands)-sum(demands[i] for i in three)==19:
                cases.append((f,sum(1 << i for i in three),demands))
    assert len(cases)==266 and sum(f.bit_count() for f,S,d in cases)==609
    return cases
