"""Recompute outside, private-group and mixed-circuit feasibility from the instance."""
from pathlib import Path
from subprocess import run
from tempfile import TemporaryDirectory
import sys

here=Path(__file__).resolve().parent
quartets=(15,23,27,46,83)
def call(args,output=None,data=None):
    with (open(output,'w') if output else open('/dev/null','w')) as f:
        run(args,cwd=here,stdout=f,stdin=data,check=True)
with TemporaryDirectory() as td:
    d=Path(td)
    def py(name,*args,out=None):
        call([sys.executable,str(here/name),*map(str,args)],out)
    for source in ('private8','fast','endpoint'):
        call(['c++','-O3','-std=c++20',str(here/(source+'.cpp')),'-o',str(d/source)])
    py('prepare8.py',d)
    py('literal.py',*quartets,out=d/'literal10')
    for e in quartets:
        for k in range(3):
            py('composite.py',e,k,*(['exact'] if k==2 else []),out=d/f'comp9-{e}-{k}')
        for k in range(4):
            f=d/f'out8-{e}-{k}'
            py('outside.py',e,k,*(['exact'] if k==3 else []),out=f)
            if k<3: assert not f.stat().st_size
            else:
                data=(d/f'private8-{e}.data').read_text().splitlines()[0].split()
                base=set(map(int,data[4:]))
                for row in f.read_text().splitlines():
                    bank=list(map(int,row.split()))
                    assert len(bank)==8 and len(set(bank)-base)==3
        call([str(d/'private8'),str(d/f'private8-{e}.data'),str(d/f'out8-{e}-3')],d/f'priv8-{e}')
    for b in (8,9,10):
        py('packets.py',d,b,out=d/f'pack{b}')
        infile=d/f'private-{b}.in'
        assert sum(1 for _ in infile.open())=={8:49954,9:4247,10:64}[b]
        with infile.open() as f:call([str(d/'fast')],d/'phase1',f)
        kept=0
        with infile.open() as f,(d/'phase1').open() as g,(d/f'private-{b}.reps').open() as reps,(d/'phase2').open('w') as out:
            for line,answer,rep in zip(f,g,reps,strict=True):
                bank=list(map(int,rep.split()))[:-1]
                assert len(bank)==13 and bank==sorted(bank)
                if b==8 and (bank[0]==0 or any(x==y and x.bit_count()==1 for x,y in zip(bank,bank[1:]))):
                    continue
                assert answer.strip() in ('0','1')
                if int(answer):out.write(line);kept+=1
        with (d/'phase2').open() as f:call([str(d/'endpoint'),'13','8','2'],d/'final',f)
        answers=(d/'final').read_text().splitlines()
        assert len(answers)==kept and all(s.startswith('0 ') for s in answers)
        print('outside width',b,(d/f'pack{b}').read_text().strip(),'exact checks',kept,flush=True)
