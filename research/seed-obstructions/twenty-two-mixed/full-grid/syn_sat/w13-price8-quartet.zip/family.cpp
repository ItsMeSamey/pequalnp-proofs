#include "outerfast.hpp"
#include <bit>
using namespace std;
using Bank=array<int,13>;
int main(int argc,char**argv){
    if(argc!=7)return 2;
    ifstream action(argv[1]),samples(argv[2]),points(argv[3]);
    int maxlabels=atoi(argv[4]),tmp;
    for(int i=0;i<31;i++)action>>tmp;
    array<array<int,8192>,24> G;array<array<int,128>,24> L{};
    array<int,7> stars{};
    for(int i=0;i<7;i++)for(int k:{0,1,3,9})stars[i]|=1<<((6+i+k)%13);
    for(int g=0;g<24;g++){
        for(int&x:G[g])action>>x;
        for(int m=1;m<128;m++){int j=countr_zero((unsigned)m),v=find(stars.begin(),stars.end(),G[g][stars[j]])-stars.begin();assert(v<7);L[g][m]=L[g][m&(m-1)]|(1<<v);}
    }
    int np,nn;samples>>np>>nn;assert(np==28&&nn==245);vector<int> rows(np+nn);for(int&x:rows)samples>>x;
    set<Bank> banks;Bank b;long long nbank=0;
    auto move=[&](Bank q,int g){for(int&x:q)x=G[g][x];sort(q.begin(),q.end());return q;};
    while(points>>b[0]){for(int i=1;i<13;i++)points>>b[i];nbank++;Bank key=b;for(int g=0;g<24;g++)key=min(key,move(b,g));banks.insert(key);}
    ifstream prior(argv[6]);int priorrows=0;
    while(prior>>b[0]){
        for(int i=1;i<13;i++)prior>>b[i];
        Bank key=b;sort(key.begin(),key.end());
        for(int g=0;g<24;g++)key=min(key,move(b,g));
        banks.erase(key);priorrows++;
    }
    if(!priorrows)return 3;
    int minlabels=atoi(argv[5]);
    long long cnt=0,yes=0,calls=0,failedGroups=0;
    for(auto& q:banks){
        vector<int> H;for(int g=0;g<24;g++)if(move(q,g)==q)H.push_back(g);
        vector<int> projected=rows;
        for(int&x:projected){int out=x&~8191;for(int i=0;i<13;i++)if(x&q[i]&8191)out|=1<<i;x=out;}
        vector<int> pos(projected.begin(),projected.begin()+np),neg(projected.begin()+np,projected.end());
        sort(neg.begin(),neg.end(),[](int a,int b){return popcount((unsigned)a)>popcount((unsigned)b);});
        vector<int> maximal;for(int x:neg)if(none_of(maximal.begin(),maximal.end(),[&](int y){return !(x&~y);}))maximal.push_back(x);
        sort(pos.begin(),pos.end());pos.erase(unique(pos.begin(),pos.end()),pos.end());
        vector<int> masks;
        for(int m=1;m<128;m++){
            int k=popcount((unsigned)m);
            if(k>=minlabels&&k<=maxlabels&&none_of(H.begin(),H.end(),[&](int g){return L[g][m]<m;}))masks.push_back(m);
        }
        auto check=[&](auto&self,const vector<int>&family)->void{
            if(family.empty())return;
            calls++;vector<int>P=pos,N=maximal;int full=0;
            for(int m:family)full|=m;
            for(int&x:P)if((x>>13)&full)x|=1<<20;
            // For the negative grant, the extra column must stay true only if every mask hits that row.
            array<int,128> hit;hit.fill(-1);
            for(int&x:N){int lines=x>>13;
                if(hit[lines]<0)hit[lines]=all_of(family.begin(),family.end(),[&](int m){return (m&lines)!=0;});
                if(hit[lines])x|=1<<20;
            }
            frontierlib::Search run;
            if(!run.treecut(P,N,21)){failedGroups+=family.size()>1;return;}
            if(family.size()==1){yes++;for(int x:q)cout<<x<<' ';cout<<family[0]<<'\n';return;}
            int best=-1,score=-1;
            for(int j=0;j<7;j++){int c=count_if(family.begin(),family.end(),[&](int m){return (m>>j)&1;});
                c=min(c,int(family.size())-c);if(c>score){best=j;score=c;}}
            assert(score>0);vector<int> lo,hi;
            for(int m:family)((m>>best)&1?hi:lo).push_back(m);
            self(self,lo);self(self,hi);
        };
        check(check,masks);cnt+=masks.size();
        if(cnt/500000!=(cnt-masks.size())/500000)cerr<<"progress "<<cnt<<" calls "<<calls<<" pending "<<yes<<'\n';

    }
    cerr<<"banks "<<nbank<<" bank-orbits "<<banks.size()<<" mixed-orbits "<<cnt<<" pending "<<yes<<" calls "<<calls<<" failed-groups "<<failedGroups<<'\n';
}
