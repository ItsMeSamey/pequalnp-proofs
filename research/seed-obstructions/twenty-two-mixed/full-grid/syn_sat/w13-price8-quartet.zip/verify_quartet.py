"""Replay physical W13/L8 at point cost eight for every four-line extra."""
from hashlib import sha256
from pathlib import Path
import gzip
import subprocess
import sys
from instance import raw
from samples import actions, raw_samples
from replay import make

root=Path(__file__).resolve().parent
work=Path(sys.argv[1]).resolve()
work.mkdir(parents=True,exist_ok=True)
P,N=raw_samples(root/'L-meta-18968.json')
action=work/'action'
with action.open('w') as f:
    print(*sorted(raw),file=f)
    for g in actions(P,N):print(*g,file=f)
samples=work/'samples'
samples.write_text(' '.join(map(str,[len(P),len(N),*sorted(P),*sorted(N)])))
for name in ('refinefast','family','endpoint'):
    subprocess.run(['c++','-std=c++20','-O3',root/f'{name}.cpp','-o',work/name],check=True)
for cost,expected in ((7,'89a64de1853b6b3f974d437cde4736ae6985dea85417e53056e2434c075941d1'),(8,'1d8f39ca437f2896d6c3b28a545244139cb010be5e571364985e062404a9bc8e')):
    source=root/f'W13-g{cost}-potential.txt.gz'
    assert sha256(source.read_bytes()).hexdigest()==expected
    combined=set()
    with gzip.open(source,'rb') as rawdata:
        while True:
            from itertools import islice
            chunk=b''.join(islice(rawdata,250000))
            if not chunk:break
            result=subprocess.run([work/'refinefast',str(cost),action],input=chunk,stdout=subprocess.PIPE,check=True)
            combined.update(result.stdout.splitlines())
    assert len(combined)=={7:6851,8:427535}[cost]
    banks=work/f'price{cost}'
    banks.write_bytes(b'\n'.join(sorted(combined))+b'\n')
    subprocess.run([sys.executable,root/'pad.py',str(cost),banks,work/f'padded{cost}'],check=True)
byline=subprocess.run([work/'family',action,samples,work/'padded8','4','4',work/'padded7'],capture_output=True,text=True,check=True)
print(byline.stderr,flush=True)
pending=byline.stdout.splitlines()
if pending:
    rows=[list(map(int,line.split())) for line in pending]
    z=subprocess.run([work/'endpoint','13','8','2'],input=''.join(make(row[:-1],row[-1]) for row in rows),text=True,capture_output=True,check=True)
    assert len(z.stdout.splitlines())==len(rows) and all(x.startswith('0 pre ') for x in z.stdout.splitlines())
print('remaining endpoint tests',len(pending))
