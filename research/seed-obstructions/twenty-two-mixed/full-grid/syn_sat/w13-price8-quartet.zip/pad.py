"""Add zero/repeated positions to every affordable twelve-point predecessor."""
from pathlib import Path
import sys
g=int(sys.argv[1])
assert g in (6,7,8)
banks={tuple(map(int,l.split())) for l in Path(sys.argv[2]).read_text().splitlines()}
extra=set()
for l in Path(__file__).with_name('banks-through-seven.txt' if g==8 else 'banks-through-six.txt').read_text().splitlines():
    *b,price=map(int,l.split())
    if price>g-1:continue
    extra.update(tuple(sorted((*b,x))) for x in (0,*b))
with open(sys.argv[3],'w') as out:
    for b in sorted(banks|extra):print(*b,file=out)
print('distinct',len(banks),'padding',len(extra),'total',len(banks|extra))
