#include <algorithm>
#include <array>
#include <bit>
#include <bitset>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;
array<int,31> raw;
array<bool,8192> israw{},raworbit{},single3{};
array<array<int,8192>,24> G;
map<vector<int>,bool> cache;
array<bitset<8192>,8192> rawStep; array<bool,8192> firstSeed{};
bool closure(vector<int>& pool,const vector<int>& targets){
    bool changed;
    do{changed=false;
        for(int t:targets){
            if(find(pool.begin(),pool.end(),t)!=pool.end())continue;
            bool ok=false;
            for(int a:pool){for(int b:pool)if((a|b)==t||(a&b)==t){ok=true;break;}if(ok)break;}
            if(ok){pool.push_back(t);changed=true;}
        }
    }while(changed);
    return all_of(targets.begin(),targets.end(),[&](int t){return find(pool.begin(),pool.end(),t)!=pool.end();});
}
bool feasible(const vector<int>&targets,int g){
    if(targets.empty())return true;
    if(targets.size()==1&&g==3)return single3[targets[0]];
    int k=targets.size(),all=(1<<k)-1,h=g-k;
    if(h>=1)return true;
    array<vector<int>,8> req;
    for(int j=0;j<k;j++){
        int wanted=targets[j];
        if(firstSeed[wanted])req[j].push_back(0);
        for(int i=0;i<k;i++)if(i!=j){
            if(rawStep[targets[i]][wanted])req[j].push_back(1<<i);
            for(int m=0;m<i;m++)if(m!=j&&((targets[i]&targets[m])==wanted||(targets[i]|targets[m])==wanted))req[j].push_back((1<<i)|(1<<m));
        }
    }
    auto go=[&](int mask){
        int n=mask;
        for(int j=0;j<k;j++)if(!(mask>>j&1))for(int r:req[j])if(!(r&~mask)){n|=1<<j;break;}
        return n;
    };
    int base=0,tmp;
    while((tmp=go(base))!=base)base=tmp;
    if(base==all)return true;
    if(!h)return false;
    array<int,256> direct;direct.fill(-1);direct[base]=base;
    vector<int> xs(raw.begin(),raw.end());
    for(int j=0;j<k;j++)if(base>>j&1)xs.push_back(targets[j]);
    set<int> hidden;
    for(int a:xs)for(int b:xs)for(int x:{a|b,a&b})if(x&&!israw[x])hidden.insert(x);
    for(int x:hidden){
        bool unlock=false;
        for(int q=all^base;q&&!unlock;q&=q-1){
            int w=targets[countr_zero((unsigned)q)];unlock=rawStep[x][w];
            for(int m=base;m&&!unlock;m&=m-1){int y=targets[countr_zero((unsigned)m)];unlock=(x&y)==w||(x|y)==w;}
        }
        if(!unlock)continue;
        int seed=base;array<int,8> next{};
        for(int j=0;j<k;j++){
            int w=targets[j];if(rawStep[x][w])seed|=1<<j;
            for(int i=0;i<k;i++)if((x&targets[i])==w||(x|targets[i])==w)next[i]|=1<<j;
        }
        int old;
        do{old=seed;if(direct[old]<0)direct[old]=go(old);seed=direct[old];for(int m=old;m;m&=m-1)seed|=next[countr_zero((unsigned)m)];}while(seed!=old);
        if(seed==all)return true;
    }
    return false;
}
void prepare(){
    for(int x=1;x<8192;x++)for(int r:raw){rawStep[x].set(x&r);rawStep[x].set(x|r);}
    for(int a:raw)for(int b:raw){firstSeed[a|b]=true;firstSeed[a&b]=true;}
    set<int> first;
    for(int a:raw)for(int b:raw)for(int m:{a|b,a&b})if(m&&!israw[m])first.insert(m);
    for(int a:first) {
        single3[a]=true;
        for(int b:first){single3[a|b]=true;single3[a&b]=true;}
        for(int b:raw)for(int c:{a|b,a&b}){
            single3[c]=true;
            for(int d:raw){single3[c|d]=true;single3[c&d]=true;}
            single3[c|a]=true;single3[c&a]=true;
        }
    }
}
int main(int argc,char**argv){
    int g=atoi(argv[1]);ifstream in(argv[2]);
    for(int&i:raw){in>>i;israw[i]=true;}
    for(auto&pm:G){for(int&i:pm)in>>i;for(int x:raw)raworbit[pm[x]]=true;}
    prepare();set<array<int,13>> valid;
    array<int,13> b;int rows=0;
    while(cin>>b[0]){
        for(int i=1;i<13;i++)cin>>b[i];rows++;
        if(b.front()==0||adjacent_find(b.begin(),b.end())!=b.end())continue;
        if(count_if(b.begin(),b.end(),[](int x){return !raworbit[x];})>g)continue;
        array<int,13> canonical=b;
        for(auto&pm:G){array<int,13> q;for(int j=0;j<13;j++)q[j]=pm[b[j]];sort(q.begin(),q.end());canonical=min(canonical,q);}
        if(valid.count(canonical))continue;
        for(auto&pm:G){
            vector<int> paid;array<int,13> moved;
            for(int j=0;j<13;j++){int x=moved[j]=pm[b[j]];if(!israw[x])paid.push_back(x);}
            if((int)paid.size()>g)continue;
            sort(paid.begin(),paid.end());
            bool ok;
            if(g-(int)paid.size()>=1 && !(g==3&&paid.size()==1))ok=true;
            else {
                if(cache.size()>350000)cache.clear();
                auto [it,added]=cache.try_emplace(paid,false);
                if(added)it->second=feasible(paid,g);
                ok=it->second;
            }
            if(ok){valid.insert(canonical);break;}
        }
    }
    for(auto a:valid){for(int x:a)cout<<x<<' ';cout<<'\n';}
    cerr<<"budget "<<g<<" source "<<rows<<" paid sets "<<cache.size()<<" banks "<<valid.size()<<'\n';
}
