from pathlib import Path
from tempfile import TemporaryDirectory
import sys,subprocess
root=Path(__file__).resolve().parent
Q=(15,23,27,46,83)
with TemporaryDirectory() as t:
    d=Path(t)
    for b in range(3,10):
        for e in Q:
            p=subprocess.run([sys.executable,root/'project.py',str(e),str(b)],capture_output=True,text=True,check=True)
            assert p.stdout.strip()==f'{e} {b} None',p.stdout
        print('projected outside width',b,'excluded',flush=True)
    with (d/'triple-literal10').open('w') as out:
        subprocess.run([sys.executable,root/'literalrole.py',*map(str,Q)],stdout=out,check=True)
    subprocess.run([sys.executable,root/'packets.py',d,'10'],check=True)
    subprocess.run(['c++','-O3','-std=c++20',root/'fast.cpp','-o',d/'fast'],check=True)
    with (d/'triple-10.in').open() as inp:
        p=subprocess.run([d/'fast'],stdin=inp,capture_output=True,text=True,check=True)
    assert p.stdout.split()==['0']*5,p.stdout
    print('all five literal-group mixed packets excluded')
