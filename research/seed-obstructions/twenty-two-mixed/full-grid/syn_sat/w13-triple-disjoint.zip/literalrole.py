"""Width-13, b=10 outside slots, one possible nonbase paid wire."""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
from samples import actions,raw_samples
from instance import stars,raw,rows
import sys
root=Path(__file__).resolve().parent
P,N=raw_samples(root/'L-meta-18968.json');G=actions(P,N)
def maximum(pairs):
    pairs=set(pairs)
    return [(p,n) for p,n in pairs if all(p!=q or n==m or n&~m for q,m in pairs)]
def run(E):
    fixed=[s for i,s in enumerate(stars) if not E>>i&1]
    base={g[x] for x in raw for g in G}
    base.update(v for v in range(8192) if any(not v&~s for s in fixed))
    rich=set()
    domain=sorted(base|rich)
    ids=IDPool();flags={v:ids.id() for v in domain}
    cnf=CardEnc.atmost(list(flags.values()),10,vpool=ids).clauses

    def cover(p,n):return [flags[v] for v in domain if p&v and not n&v]
    for p,n in maximum(rows):
        if not any(p&s and not n&s for s in fixed):cnf.append(cover(p,n))
    for r in P:
        if not E&(r>>13):continue
        p=r&8191;opts=[]
        for v,w in combinations_with_replacement(fixed,2):
            q=ids.id();opts.append(q)
            for _,n in maximum((p,n&8191) for n in N if (r>>13)&(n>>13) and n&v and n&w):
                cnf.append([-q,*cover(p,n)])
        cnf.append(opts)
    cnt=0
    with Solver(name='cadical195',bootstrap_with=cnf) as sol:
        while sol.solve():
            model=set(sol.get_model());picked=tuple(v for v,x in flags.items() if x in model)
            print(E,len(picked),*picked,flush=True)
            sol.add_clause([(-x if x in model else x) for x in flags.values()])
            cnt+=1
    print('quartet',E,'base',len(base),'rich',len(rich),'supports',cnt,file=sys.stderr,flush=True)
if __name__=='__main__':
    for e in map(int,sys.argv[1:]):run(e)
