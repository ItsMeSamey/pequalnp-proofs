#include <algorithm>
#include <array>
#include <bit>
#include <bitset>
#include <fstream>
#include <iostream>
#include <map>
#include <memory>
#include <sstream>
#include <vector>
using namespace std;
struct Library{
    bitset<8192> base,raw,first;
    unique_ptr<bitset<8192>[]> edges{new bitset<8192>[8192]};
    map<array<int,7>,bool>cache;
    vector<int> closure(const vector<int>&v){
        vector<int>open;bool add;
        do{add=false;for(int x:v)if(find(open.begin(),open.end(),x)==open.end()){
            bool okay=first[x];for(int y:open){okay|=edges[y][x];for(int z:open)okay|=(y&z)==x||(y|z)==x;}
            if(okay){open.push_back(x);add=true;}
        }}while(add);return open;
    }
    bool accepts(const vector<int>&v,int cap){
        int h=cap-int(v.size());if(h<0)return false;if(h>=2)return true;
        array<int,7>key{};key[0]=h;copy(v.begin(),v.end(),key.begin()+1);
        auto[it,added]=cache.try_emplace(key,false);if(!added)return it->second;
        auto r=closure(v);if(r.size()==v.size())return it->second=true;
        if(!h)return false;
        auto hidden=first;for(int x:r){hidden|=edges[x];for(int y:r){hidden[x&y]=true;hidden[x|y]=true;}}
        for(int x=0;x<8192;x++)if(hidden[x]&&!base[x]&&find(v.begin(),v.end(),x)==v.end()){
            bool unlock=false;for(int w:v)if(find(r.begin(),r.end(),w)==r.end()){
                unlock|=edges[x][w];for(int y:r)unlock|=(x&y)==w||(x|y)==w;
            }
            if(!unlock)continue;auto v2=v;v2.push_back(x);
            if(closure(v2).size()==v2.size())return it->second=true;
        }return false;
    }
};
int main(int argc,char**argv){
    int aug=atoi(argv[1]),nlib;ifstream lib(argv[2]);array<int,2> ts;lib>>ts[0]>>ts[1]>>nlib;
    vector<Library> list(nlib);
    for(auto&L:list){
        vector<int>base;for(int i=0,m;i<31;i++){lib>>m;L.raw[m]=true;}
        for(int x=0;x<8192;x++)if(L.raw[x]||!(x&~ts[0])||!(x&~ts[1])){L.base[x]=true;base.push_back(x);}
        for(int x=0;x<8192;x++)for(int a:base){L.edges[x][x&a]=true;L.edges[x][x|a]=true;}
        for(int a:base)L.first|=L.edges[a];
    }
    string line;long long n=0,pass=0;
    while(getline(cin,line)){istringstream in(line);vector<int>bank;int m;while(in>>m)bank.push_back(m);if(bank.empty())continue;
        n++;sort(bank.begin(),bank.end());int cap=aug;
        for(int t:ts){int c=0;bool full=false;for(int x:bank)if(popcount((unsigned)x)>=2&&!(x&~t)){c++;full|=x==t;}
            cap-=max(3,c+!full);}
        bool ok=false;for(auto&L:list){int budget=cap,last=-1;vector<int>need;
            for(int x:bank){
                if(!x||(x==last&&L.raw[x]))budget--;
                if(!L.base[x]){if(x==last)budget--;else need.push_back(x);}last=x;
            }
            if(L.accepts(need,budget)){ok=true;break;}
        }
        if(ok){cout<<line<<'\n';pass++;}
    }
    cerr<<"orientation-checked "<<n<<" retained "<<pass<<'\n';
}
