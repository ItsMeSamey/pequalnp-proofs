#include <algorithm>
#include <array>
#include <bitset>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <vector>
using namespace std;
using Cov=array<unsigned long long,21>;
bitset<8192> base,first,stepmask[8192];
array<Cov,8192> coverage;
vector<int> basis;
vector<int> closure(const vector<int>&v){
    vector<int> open;bool added;
    do{added=false;for(int x:v)if(find(open.begin(),open.end(),x)==open.end()){
        bool ok=first[x];for(int y:open){ok|=stepmask[y][x];for(int z:open)ok|=(y|z)==x||(y&z)==x;}
        if(ok){open.push_back(x);added=true;}
    }}while(added);
    return open;
}
bool onehidden(vector<int> v){
    auto reached=closure(v);
    if(reached.size()==v.size())return true;
    reached.insert(reached.end(),basis.begin(),basis.end());bitset<8192> hidden;
    for(int x:reached)for(int y:reached){hidden[x|y]=true;hidden[x&y]=true;}
    for(int x=0;x<8192;x++)if(hidden[x]&&!base[x]&&find(v.begin(),v.end(),x)==v.end()){
        v.push_back(x);if(closure(v).size()==v.size())return true;v.pop_back();
    }
    return false;
}
int main(int argc,char**argv){
    int k=atoi(argv[1]);ifstream data(argv[2]),outside(argv[3]);array<int,2>T;int n;
    data>>T[0]>>T[1]>>n;basis.resize(n);for(int&x:basis){data>>x;base[x]=true;}
    for(int x=0;x<8192;x++)for(int y:basis){stepmask[x][x|y]=true;stepmask[x][x&y]=true;}
    for(int x:basis)first|=stepmask[x];int p,neg,r=0;
    while(data>>p>>neg){for(int x=1;x<8192;x++)if((x&p)&&!(x&neg))coverage[x][r/64]|=1ull<<(r%64);r++;}
    if(r!=1323)return 2;
    set<vector<int>>supports,result;string line;
    while(getline(outside,line)){istringstream stream(line);vector<int>bank;int x;while(stream>>x)bank.push_back(x);sort(bank.begin(),bank.end());supports.insert(bank);}
    for(auto&b:supports){
        vector<int> known;for(int x:b)if(!base[x])known.push_back(x);
        sort(known.begin(),known.end());known.erase(unique(known.begin(),known.end()),known.end());
        if((int)known.size()!=k)continue;
        if(k==3&&!onehidden(known))continue;
        if(k==4&&closure(known).size()!=known.size())continue;
        Cov miss;miss.fill(~0ull);miss[20]=(1ull<<43)-1;
        for(int x:b)for(int j=0;j<21;j++)miss[j]&=~coverage[x][j];
        for(int i=0;i<2;i++){int t=T[i],lit=T[1-i];Cov need=miss;
            for(int j=0;j<21;j++)need[j]&=~coverage[lit][j];
            auto add=[&](int x,int y){
                for(int j=0;j<21;j++)if(need[j]&~(coverage[x][j]|coverage[y][j]))return;
                auto all=b;all.insert(all.end(),{lit,x,y});sort(all.begin(),all.end());result.insert(all);
            };
            for(int x=t;;x=(x-1)&t){
                for(int y=t;;y=(y-1)&t){if(x<=y&&(x|y)==t)add(x,y);if(!y)break;}
                if(!x)break;
            }
            int ext=8191^t;
            for(int a=ext;;a=(a-1)&ext){
                int y=t|a;bool covered=base[y]||find(known.begin(),known.end(),y)!=known.end();
                if(!covered&&k==3){auto v=known;v.push_back(y);covered=closure(v).size()==v.size();}
                if(covered)add(t,y);if(!a)break;
            }
        }
    }
    for(auto&v:result){for(int x:v)cout<<x<<' ';cout<<'\n';}
    cerr<<"outside supports "<<supports.size()<<" full "<<result.size()<<'\n';
}
