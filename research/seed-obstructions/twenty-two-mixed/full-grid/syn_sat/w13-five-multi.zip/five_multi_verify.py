"""Replay both five-special nonliteral sectors in a dedicated work directory."""
from itertools import zip_longest
from pathlib import Path
import subprocess
import sys

src = Path(__file__).resolve().parent
work = Path(sys.argv[1]).resolve()
work.mkdir(exist_ok=True, parents=True)

def run(args, target=None, source=None):
    output = target.open('w') if target else None
    inp = source.open() if source else None
    try:
        subprocess.run(args, check=True, stdout=output, stdin=inp)
    finally:
        if inp: inp.close()
        if output: output.close()

def py(script, *args):
    return [sys.executable, src / (script + '.py'), *map(str,args)]

for name in ['five9join','five10join','roleprice','fast','endpoint_multi']:
    run(['c++','-std=c++20','-O3',src / (name+'.cpp'),'-o',work/name])
for script in ['five_data','role_libraries']:
    run(py(script,work))
for b in (9,10):
    cap = 14-b
    for e in (31,47,87):
        for k in range(cap+1):
            outside = work / f'support-{b}-{e}-{k}'
            if k < cap-1:
                run(py('five9outside' if b==9 else 'five10q0',e,k),outside)
                assert outside.stat().st_size==0
                continue
            exact = k==cap
            run(py('outside_ordered' if exact else 'outside_width',e,k,'exact' if exact else 'relax',b),outside)
            bank=work / f'five{b}bank-{e}-{k}'
            run([work/f'five{b}join',str(k),work/f'five-{e}.data',outside],bank)
            run([work/'roleprice',str(20-b),work/f'library-{e}'],work/f'five{b}price-{e}-{k}',bank)
    for k in (cap-1,cap):
        run(py('joined_packets',work,b,k))
        prefix=work/f'five-{b}-{k}'
        inp=prefix.with_suffix('.in'); flags=prefix.with_suffix('.flags')
        run([work/'fast'],flags,inp)
        pending=prefix.with_suffix('.pending')
        with flags.open() as f, inp.open() as g, pending.open('w') as out:
            for flag,row in zip_longest(f,g):
                assert row is not None and flag in ('0\n','1\n')
                if flag=='1\n':out.write(row)
        endpoint=prefix.with_suffix('.final')
        run([work/'endpoint_multi','13','8','2'],endpoint,pending)
        with pending.open() as f, endpoint.open() as g:
            for row,result in zip_longest(f,g):
                assert row and result and result.startswith('0 ')
        print('excluded',b,k,flush=True)
