#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
int main(){
    constexpr int basebits=4, extbits=3, n=1<<(basebits+extbits);
    vector<int> raw;
    for(int m=0;m<n;m++)if(popcount((unsigned)m&15)<=1)raw.push_back(m);
    set<vector<int>> states{{}};
    for(int depth=0;depth<=3;depth++){
        set<vector<int>> next;int fullstates=0;
        for(auto&marked:states){
            vector<int> xs=raw;xs.insert(xs.end(),marked.begin(),marked.end());array<bool,n> have{},newpartial{};
            for(int x:xs)have[x]=true;
            for(int j=0;j<(int)xs.size();j++)for(int i=0;i<j;i++)for(int z:{xs[i]|xs[j],xs[i]&xs[j]}){
                if(have[z])continue;
                int k=popcount((unsigned)z&15);
                if(k==4){
                    if(z==15){cerr<<"surviving marked masks";for(int x:marked)cerr<<' '<<x;cerr<<'\n';return 1;}
                    have[z]=true;xs.push_back(z);
                }
                if((k==2||k==3)&&(z>>4))newpartial[z]=true;
            }
            fullstates+=(xs.size()>raw.size()+marked.size());
            if(depth<3)for(int z=0;z<n;z++)if(newpartial[z]){
                auto v=marked;v.push_back(z);sort(v.begin(),v.end());next.insert(v);
            }
        }
        cout<<"partial gates "<<depth<<" states "<<states.size()<<" states-with-full "<<fullstates<<'\n';
        states=move(next);
    }
}
