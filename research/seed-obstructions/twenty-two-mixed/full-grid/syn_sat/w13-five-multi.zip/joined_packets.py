"""Lift permitted outside slot supports to physical multisets, canonicalize joint symmetry."""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from collections import Counter
from instance import stars
from replay import groups,make
import sys
path=Path(sys.argv[1])
def completed(bank):
    missing=13-len(bank)
    assert missing>=0
    for fill in combinations_with_replacement(sorted({0,*bank}),missing):
        yield tuple(sorted((*bank,*fill)))
def paired(E,allbank):
    masks=[sum(1<<i for i in j) for j in combinations([i for i in range(7) if E>>i&1],3)]
    for b in completed(allbank):
        images=[tuple(sorted(pm[x] for x in b)) for pm,lm in groups]
        for m in masks:
            yield min((t,lm[m]) for t,(_,lm) in zip(images,groups))
if __name__=='__main__':
    seen=set();hist=Counter()
    width,k=int(sys.argv[2]),int(sys.argv[3])
    for E in (31,47,87):
        for line in (path/f'five{width}price-{E}-{k}').read_text().splitlines():
            bank=list(map(int,line.split()));hist[E,len(bank)]+=1;seen.update(paired(E,bank))
    print('models',sorted(hist.items()),'orbits',len(seen),flush=True)
    import subprocess,tempfile
    from samples import raw_samples
    root=Path(__file__).resolve().parent
    reps=path/f'five-{width}-{k}.reps'
    with reps.open('w') as out:
        for b,m in sorted(seen):print(*b,m,file=out)
    P,N=raw_samples(root/'L-meta-18968.json')
    with tempfile.TemporaryDirectory() as tmp,(path/f'five-{width}-{k}.in').open('w') as out:
        exe=Path(tmp)/'emit'
        subprocess.run(['c++','-std=c++20','-O3',root/'emit.cpp','-o',exe],check=True)
        data=' '.join(map(str,[len(P),len(N),*P,*N]))
        subprocess.run([exe,reps],input=data,text=True,stdout=out,check=True)
