from instance import rows,raw,stars
from samples import actions,raw_samples
from pathlib import Path
import sys
work=Path(sys.argv[1]);group=actions(*raw_samples(Path(__file__).with_name('L-meta-18968.json')))
for e in (31,47,87):
    ts=[s for i,s in enumerate(stars) if not(e>>i&1)]
    base={g[x] for g in group for x in raw}|{x for x in range(8192) if any(not x&~t for t in ts)}
    with (work/f'five-{e}.data').open('w') as f:
        print(*ts,len(base),*sorted(base),file=f)
        for a,n in rows:print(a,n,file=f)
