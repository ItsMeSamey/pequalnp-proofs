#include <algorithm>
#include <array>
#include <bit>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
int main(int argc,char**argv){
    if(argc!=2)return 2;
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int np,nn;cin>>np>>nn;vector<int> raw(np+nn);for(int&x:raw)cin>>x;
    ifstream reps(argv[1]);array<int,13> previous{},bank{};bool first=true;int m;vector<int>pos,neg;
    while(reps>>bank[0]){
        for(int j=1;j<13;j++)reps>>bank[j];reps>>m;
        if(first||bank!=previous){
            first=false;previous=bank;
            vector<int> both=raw;
            for(int&x:both){int p=x&8191;int r=x&~8191;for(int j=0;j<13;j++)if(bank[j]&p)r|=1<<j;x=r;}
            pos.assign(both.begin(),both.begin()+np);sort(pos.begin(),pos.end());pos.erase(unique(pos.begin(),pos.end()),pos.end());
            vector<int> n(both.begin()+np,both.end());
            sort(n.begin(),n.end(),[](unsigned a,unsigned b){return popcount(a)>popcount(b);});
            neg.clear();for(int val:n)if(none_of(neg.begin(),neg.end(),[&](int q){return !(val&~q);}))neg.push_back(val);sort(neg.begin(),neg.end());
        }
        cout<<pos.size()<<' '<<neg.size();
        for(auto ptr:{&pos,&neg})for(int r:*ptr)cout<<' '<<(r|(((r>>13)&m)?1<<20:0));
        cout<<'\n';
    }
}
