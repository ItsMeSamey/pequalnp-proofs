#include <bit>
#include <map>
#include <algorithm>
#include <array>
#include <bitset>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <vector>
using namespace std;
using Cov=array<unsigned long long,21>;
bitset<8192> base,first,stepmask[8192];
array<Cov,8192> coverage;
vector<int> basis;
vector<int> closure(const vector<int>&v){
    vector<int> open;bool added;
    do{added=false;for(int x:v)if(find(open.begin(),open.end(),x)==open.end()){
        bool ok=first[x];for(int y:open){ok|=stepmask[y][x];for(int z:open)ok|=(y|z)==x||(y&z)==x;}
        if(ok){open.push_back(x);added=true;}
    }}while(added);
    return open;
}
bool onehidden(vector<int> v){
    auto reached=closure(v);
    if(reached.size()==v.size())return true;
    reached.insert(reached.end(),basis.begin(),basis.end());bitset<8192> hidden;
    for(int x:reached)for(int y:reached){hidden[x|y]=true;hidden[x&y]=true;}
    for(int x=0;x<8192;x++)if(hidden[x]&&!base[x]&&find(v.begin(),v.end(),x)==v.end()){
        v.push_back(x);if(closure(v).size()==v.size())return true;v.pop_back();
    }
    return false;
}
using U=__uint128_t;
using Four=array<int,4>;
struct Option{Four f;Cov c{};};
array<int,2>T;array<U,2> bad{};array<U,8192> V{};
array<vector<array<int,2>>,2>pairs_ok;
array<vector<array<int,3>>,2>pairs_sig;
vector<Option> baseline;array<vector<Option>,8192>rich;
array<bool,8192> cached{};
U op(U a,U b,int v){return v?a|b:a&b;}
bool good(U u,int t){return int(u&8191)==T[t]&&!(bad[t]&u);}
void insert(set<Four>&out,int a,int b,int c,int d){Four f{a,b,c,d};sort(f.begin(),f.end());out.insert(f);}
vector<Option> decorate(const set<Four>& options){
    vector<Option> ans;for(auto f:options){Option v;v.f=f;for(int x:f)for(int j=0;j<21;j++)v.c[j]|=coverage[x][j];ans.push_back(v);}return ans;
}
void init_private(){
    for(int m=0;m<8192;m++){U v=m;int pos=13;for(int i=0;i<13;i++)for(int j=i+1;j<13;j++,pos++){
        int mask=(1<<i)|(1<<j);if(m&mask)v|=U(1)<<pos;
        for(int t=0;t<2;t++)if(!(T[t]&mask))bad[t]|=U(1)<<pos;
    }V[m]=v;}
    set<Four> all;
    for(int t=0;t<2;t++){
        int f=T[1-t];for(size_t i=0;i<basis.size();i++)for(size_t j=i;j<basis.size();j++){
            int a=basis[i],b=basis[j];bool pair=false;
            for(int u=0;u<2;u++){
                U v=op(V[a],V[b],u);if(int(v&8191)==T[t])pairs_sig[t].push_back({a,b,u});
                pair|=good(v,t);
            }if(pair)pairs_ok[t].push_back({a,b});
            for(size_t k=j;k<basis.size();k++){int c=basis[k];array<U,3>v{V[a],V[b],V[c]};bool ok=false;
                for(int h=0;h<3&&!ok;h++)for(int q=0;q<2&&!ok;q++)for(int r=0;r<2&&!ok;r++)
                    ok=good(op(v[h],op(v[(h+1)%3],v[(h+2)%3],q),r),t);
                if(ok)insert(all,a,b,c,f);
            }
        }
    }
    for(auto a:pairs_ok[0])for(auto b:pairs_ok[1])insert(all,a[0],a[1],b[0],b[1]);baseline=decorate(all);
}
const vector<Option>& with_rich(int y){
    if(cached[y])return rich[y];cached[y]=true;set<Four> all;
    for(int t=0;t<2;t++){
        int v=T[1-t],s=T[t];
        if(popcount((unsigned)(y&s))<2)continue;
        for(int a:basis){
            int z=a&y;if(popcount((unsigned)z)<2||(z&~s))continue;
            U h=V[a]&V[y];for(int b=s;;b=(b-1)&s){
                if(good(h|V[b],t)||good(h&V[b],t))insert(all,y,a,b,v);
                if(!b)break;
            }
        }
        if((s&~y)==0){
            for(auto [a,b,which]:pairs_sig[t])if(good(op(V[a],V[b],which)&V[y],t))insert(all,y,a,b,v);
            if(good(V[s]&V[y],t))for(auto [a,b]:pairs_ok[1-t])insert(all,s,y,a,b);
        }
    }
    rich[y]=decorate(all);return rich[y];
}
int main(int argc,char**argv){
    int k=atoi(argv[1]);ifstream data(argv[2]),outside(argv[3]);int n;data>>T[0]>>T[1]>>n;
    basis.resize(n);for(int&x:basis){data>>x;base[x]=true;}
    for(int x=0;x<8192;x++)for(int y:basis){stepmask[x][x|y]=true;stepmask[x][x&y]=true;}
    for(int x:basis)first|=stepmask[x];
    int p,neg,r=0;while(data>>p>>neg){for(int x=1;x<8192;x++)if((x&p)&&!(x&neg))coverage[x][r/64]|=1ull<<(r%64);r++;}if(r!=1323)return 2;
    init_private();set<vector<int>>supports,result;string line;
    while(getline(outside,line)){istringstream ss(line);vector<int>b;int x;while(ss>>x)b.push_back(x);sort(b.begin(),b.end());supports.insert(b);}
    struct Choices{bool baseline=false;vector<int>other;};
    map<vector<int>,Choices> lookup;long long tries=0;
    for(auto&b:supports){
        vector<int>known;for(int x:b)if(!base[x])known.push_back(x);
        sort(known.begin(),known.end());known.erase(unique(known.begin(),known.end()),known.end());
        if((int)known.size()!=k)continue;
        auto [it,added]=lookup.try_emplace(known);
        if(added){
            auto&c=it->second;auto reach=closure(known);bool direct=reach.size()==known.size();c.baseline=direct;
            if(k==4){
                if(direct)c.other=known;
                bitset<8192>possible=first;for(int x:reach){possible|=stepmask[x];for(int z:reach){possible[x&z]=true;possible[x|z]=true;}}
                for(int y=0;y<8192;y++)if(possible[y]&&!base[y]&&find(known.begin(),known.end(),y)==known.end()){
                    auto v=known;v.push_back(y);
                    if(!direct&&closure(v).size()!=v.size())continue;
                    c.baseline=true;
                    if(popcount((unsigned)(y&T[0]))>=2||popcount((unsigned)(y&T[1]))>=2)c.other.push_back(y);
                }
            }
        }
        auto&c=it->second;if(!c.baseline)continue;
        Cov miss;miss.fill(~0ull);miss[20]=(1ull<<43)-1;
        for(int x:b)for(int j=0;j<21;j++)miss[j]&=~coverage[x][j];
        auto join=[&](const vector<Option>&p){
            for(auto&v:p){tries++;bool ok=true;for(int j=0;j<21&&ok;j++)ok=!(miss[j]&~v.c[j]);if(!ok)continue;
                vector<int> row=b;row.insert(row.end(),v.f.begin(),v.f.end());sort(row.begin(),row.end());result.insert(row);
            }
        };
        join(baseline);for(int y:c.other)join(with_rich(y));
    }
    for(auto&v:result){for(int x:v)cout<<x<<' ';cout<<'\n';}
    cerr<<"supports "<<supports.size()<<" nonbase-sets "<<lookup.size()<<" attempts "<<tries<<" banks "<<result.size()<<'\n';
}
