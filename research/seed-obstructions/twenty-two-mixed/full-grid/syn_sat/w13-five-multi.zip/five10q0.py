from itertools import combinations
from pathlib import Path
import sys,re
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
from inputs import N,P,stars
from samples import actions

def maximal(rows):
 rows=set(rows)
 return {(p,n) for p,n in rows if not any(p==q and n!=m and not n&~m for q,m in rows)}
E,k=map(int,sys.argv[1:3]);fixed=[s for i,s in enumerate(stars) if not E>>i&1]
p=IDPool();cnf=[]
group=actions(P,N)
primitive={1<<j for j in range(13)}
for j in range(6):
 x=(1<<j)|(1<<(j+1)); y=(1<<(j+3))|(1<<((j+9)%13))
 primitive.update((x,y,x|y))
orbit={f[x] for x in primitive for f in group}
assert len(orbit)==55
easy=sorted(set(orbit)|{v for v in range(8192) if any(not v&~f for f in fixed)})
choose={v:p.id() for v in easy}
zz=[[p.id() for _ in range(13)] for i in range(k)]
cnf.extend(CardEnc.atmost(list(choose.values()),10-k,vpool=p).clauses)
for z in zz:
 for v in easy:cnf.append([(-h if v>>j&1 else h) for j,h in enumerate(z)])
# At two nonbase outside outputs the two available nonbase gates are both selected.
if len(sys.argv)>3 and sys.argv[3]=="exact":
 easyset=set(easy);first={a|b for a in easy for b in easy}|{a&b for a in easy for b in easy}
 for i,z in enumerate(zz):
  options=[]
  fac=p.id();options.append(fac)
  for v in range(8192):
   if v not in first:cnf.append([-fac,*[-h if v>>j&1 else h for j,h in enumerate(z)]])
  for earlier in zz[:i]:
   for mask in easy:
    for op in range(2):
     sel=p.id();options.append(sel)
     for j,q in enumerate(z):
      bit=bool(mask>>j&1)
      if (op and bit) or (not op and not bit):cnf.append([-sel,q if bit else -q])
      else:
       cnf.append([-sel,-earlier[j],q]);cnf.append([-sel,earlier[j],-q])
  for a,b in combinations(zz[:i],2):
   for op in range(2):
    sel=p.id();options.append(sel)
    for j,v in enumerate(z):
     if op:cnf.extend([[-sel,-a[j],v],[-sel,-b[j],v],[-sel,-v,a[j],b[j]]])
     else:cnf.extend([[-sel,a[j],-v],[-sel,b[j],-v],[-sel,v,-a[j],-b[j]]])
  cnf.append(options)
else:
 for z,y in zip(zz,zz[1:]):
  eq=None
  for i in reversed(range(13)):
   prefix=[] if eq is None else [-eq]
   cnf.append([*prefix,-z[i],y[i]])
   nex=p.id()
   cnf.append([*prefix,-z[i],-y[i],nex]);cnf.append([*prefix,z[i],y[i],nex]);eq=nex
cache={}
def cover(a,n):
 if (a,n) in cache:return cache[a,n]
 j=a.bit_length()-1;cc=[h for v,h in choose.items() if v&a and not v&n]
 for z in zz:
  x=p.id();cc.append(x);cnf.append([-x,z[j]])
  for i,w in enumerate(z):
   if n>>i&1:cnf.append([-x,-w])
 cache[a,n]=cc;return cc
raw=maximal((r&8191,n&8191) for r in P for n in N if (r>>13)&(n>>13))
# Assign the two single-wire roles and the private two-input role.
options=set()
for t in fixed:
 lit=tuple(sorted(set(fixed)-{t}))
 subs=[v for v in range(8192) if not v&~t]
 for x in subs:
  for y in subs:
   if x<=y and x|y==t:options.add(tuple(sorted((*lit,x,y))))
 for z in range(8192):
  if not t&~z and (k<4 or z in easy):options.add(tuple(sorted((*lit,t,z))))
opt={v:p.id() for v in sorted(options)}
cnf.extend(CardEnc.equals(list(opt.values()),1,vpool=p).clauses)
for a,n in raw:
 extra=[h for f,h in opt.items() if any(a&v and not n&v for v in f)]
 if len(extra)<len(opt):cnf.append([*extra,*cover(a,n)])
for r in P:
 if not(E&r>>13):continue
 a=r&8191;opts=[]
 for v in fixed:
  choice=p.id();opts.append(choice)
  rs=maximal((a,n&8191) for n in N if (r>>13&n>>13) and n&v)
  for _,n in rs:cnf.append([-choice,*cover(a,n)])
 cnf.append(opts)
with Solver(name='cadical195',bootstrap_with=cnf) as sol:
 print('ready',len(cnf),file=sys.stderr,flush=True);count=0
 while sol.solve():
  M=set(sol.get_model());aux=[sum((h in M)<<j for j,h in enumerate(z)) for z in zz];ef=[v for v,h in choose.items() if h in M]
  chosen=next(f for f,h in opt.items() if h in M)
  print(*sorted(ef+aux+list(chosen)),flush=True)
  sol.add_clause([-opt[chosen],*(-h if h in M else h for h in choose.values()),*(-h if h in M else h for z in zz for h in z)])
  count+=1
 print('done',count,file=sys.stderr,flush=True)
