from instance import raw,stars
from samples import actions,raw_samples
from pathlib import Path
import sys
d=Path(sys.argv[1]);G=actions(*raw_samples(Path(__file__).with_name('L-meta-18968.json')))
libs=sorted({tuple(sorted(g[x] for x in raw)) for g in G})
for E in (31,47,87):
    t=[x for i,x in enumerate(stars) if not E>>i&1]
    with (d/f'library-{E}').open('w') as f:
        print(*t,len(libs),file=f)
        for lib in libs:print(*lib,file=f)
