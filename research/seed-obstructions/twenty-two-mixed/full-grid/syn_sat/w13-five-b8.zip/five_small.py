from project import model
for e in (31,47,87):
    assert model(e,8,1) is None
    print('five-special subset',e,'outside width eight excluded')
