from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'base.cpp').read_text()
prefix=s[:s.index(' array<int,13>b;')]
suffix=s[s.index('  U at[8192]'):s.index('  unsigned long long f3=')]
suffix=suffix.replace('code[r.p]&~code[r.n]','hi[r.p]&~lo[r.n]')
suffix=suffix.replace('for(int m:groups){vector<int>all;', 'for(int m:groups){if(!(needed&(U(1)<<jidx[m])))continue;vector<int>all;')
suffix=suffix.replace('for(;b;b&=b-1)push', 'b&=needed;for(;b;b&=b-1)push')
(p/'cohort.cpp').write_text(prefix+(p/'start.part').read_text()+suffix+(p/'end.part').read_text())
