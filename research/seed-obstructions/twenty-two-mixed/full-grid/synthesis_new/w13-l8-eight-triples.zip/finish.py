from pathlib import Path
import subprocess,sys
points, sample, keep, work = (Path(name).resolve() for name in sys.argv[1:5])
source=Path(__file__).resolve().parent
work.mkdir(exist_ok=True)
cases=[tuple(map(int,s.split())) for s in keep.read_text().splitlines()]
indices={i for i,e in cases}
with points.open() as f: rows={i:line.strip() for i,line in enumerate(f) if i in indices}
assert len(rows)==len(indices) and all(e.bit_count()==3 for i,e in cases)
reps=work/'survivors'
reps.write_text(''.join(f'{rows[i]} {e}\n' for i,e in cases))
for name in ('emit','fast','endpoint_multi'):
 if not (work/name).is_file():subprocess.run(['c++','-O3','-std=c++20',source/(name+'.cpp'),'-o',work/name],check=True)
with sample.open() as src,(work/'projected').open('w') as out:subprocess.run([work/'emit',reps],stdin=src,stdout=out,check=True)
with (work/'projected').open() as src:
 votes=subprocess.run([work/'fast'],stdin=src,check=True,capture_output=True,text=True).stdout.splitlines()
assert len(votes)==len(cases) and set(votes)<= {'0','1'}
with (work/'projected').open() as f:
 fallback=''.join(s for s,v in zip(f,votes,strict=True) if v=='1')
exact=subprocess.run([work/'endpoint_multi','13','8','2'],input=fallback,text=True,check=True,capture_output=True).stdout.splitlines()
(work/'exact.log').write_text('\n'.join(exact)+'\n')
assert len(exact)==votes.count('1') and all(s.startswith('0 ') for s in exact)
print('DONE',len(cases),len(exact),0)
