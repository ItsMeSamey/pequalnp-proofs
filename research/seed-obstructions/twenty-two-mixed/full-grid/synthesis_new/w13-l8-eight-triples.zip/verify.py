from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import gzip,subprocess,sys
from input import raw_samples
root=Path(__file__).resolve().parent
p,n,_=raw_samples(root/'L-meta-18968.json')
with TemporaryDirectory() as folder:
 w=Path(folder)
 samples=w/'samples'
 samples.write_text(f'{len(p)} {len(n)}\n'+' '.join(map(str,sorted(p)))+'\n'+' '.join(map(str,sorted(n)))+'\n')
 with ZipFile(root/'W13-exact-point8.zip') as upstream: data=gzip.decompress(upstream.read('prior.txt.gz'))
 assert len(data.splitlines())==427535 and sha256(data).hexdigest()=='308ec354d6aeedef4b810953f57637bf479621d34eeaead723f0b10732a7d416'
 points=w/'points';points.write_bytes(data);del data
 runner=w/'cohort'
 subprocess.run(['c++','-std=c++20','-O3',root/'cohort.cpp','-o',runner],check=True)
 with points.open() as src,(w/'kept').open('w') as out:
  result=subprocess.run([runner,samples,'64','0','427535'],stdin=src,stdout=out,stderr=subprocess.PIPE,check=True,text=True)
 count=len((w/'kept').read_text().splitlines())
 report=result.stderr.splitlines()[-1].split()
 assert report[:3]==['DONE',str(427535*35),str(count)]
 print(' '.join(report),flush=True)
 subprocess.run([sys.executable,root/'finish.py',points,samples,w/'kept',w/'final'],check=True)
