#include <array>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <set>
using namespace std;
int main(int argc,char**argv){
 ifstream f(argv[1]);int raw;
 for(int i=0;i<31;i++) f>>raw;
 int action[24][8192]{},x;
 for(auto &v:action)for(int &m:v)if(!(f>>m)||m<0||m>=8192)return 2;
 array<int,13>b{};set<array<int,13>> reps;
 while(cin>>b[0]){for(int i=1;i<13;i++)cin>>b[i];auto best=b;
 for(auto&v:action){array<int,13>a{};for(int i=0;i<13;i++)a[i]=v[b[i]];sort(a.begin(),a.end());best=min(best,a);}
 reps.insert(best);}
 for(auto&a:reps){for(int i:a)cout<<i<<" ";cout<<"\n";}
}
