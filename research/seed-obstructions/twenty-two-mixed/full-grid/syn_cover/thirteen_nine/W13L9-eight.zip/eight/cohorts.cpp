#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
using M=array<uint64_t,5>;
inline bool clash(const M&a,const M&b){return (a[0]&b[0])&&((a[1]&b[1])|(a[2]&b[2])|(a[3]&b[3])|(a[4]&b[4]));}
inline void add(M& a,const M&b){for(int k=0;k<5;k++)a[k]|=b[k];}
template<int W> struct Marked{array<int,W> v{},ids{};bool bad=false;};
struct Rel{int p,n;M mark;};
template<int W> vector<Marked<W>> readbank(const char*path,const vector<int>&pos,const vector<int>&neg,bool pt,map<M,int>&ids,vector<M>&table){
 map<pair<int,int>,M> rel;
 for(int i=0;i<28;i++)for(int j=0;j<245;j++)if(!(pt?((pos[i]&~neg[j])>>13):((pos[i]&~neg[j])&8191))){
  int p=pt?pos[i]&8191:pos[i]>>13,n=pt?neg[j]&8191:neg[j]>>13;
  auto& a=rel[{p,n}];a[0]|=uint64_t(1)<<i;a[1+j/64]|=uint64_t(1)<<(j%64);
 }
 vector<Rel> rows;for(auto&[k,m]:rel)rows.push_back({k.first,k.second,m});
 ifstream f(path);if(!f)abort();vector<Marked<W>> banks;Marked<W> bk;
 while(f>>bk.v[0]){
  for(int a=1;a<W;a++)if(!(f>>bk.v[a]))abort();
  array<M,W> m{};bk.bad=false;array<int,8192> proj{}; // masks 0..127 on the line side or 0..8191 on the point side
  if(pt){ // Point banks are few, and the negative point rows repeat.
   for(auto&r:rows)for(int i=0;i<W;i++){proj[r.p]|=bool(r.p&bk.v[i])<<i;proj[r.n]|=bool(r.n&bk.v[i])<<i;}
  }else{
   for(int k=0;k<128;k++)for(int i=0;i<W;i++)proj[k]|=bool(k&bk.v[i])<<i;
  }
  for(auto&r:rows){
   int d=proj[r.p]&~proj[r.n];
   if(!d){bk.bad=true;break;}
   if(has_single_bit((unsigned)d))add(m[countr_zero((unsigned)d)],r.mark);
  }
  
  for(int i=0;i<W;i++){auto[it,inserted]=ids.try_emplace(m[i],table.size());if(inserted)table.push_back(m[i]);bk.ids[i]=it->second;}
  banks.push_back(bk);
 }
 return banks;
}

#include <set>
struct Groups{array<int,22> a{},b{};int count=0;};
bool color(const int*adj,int n,Groups&out){
 unsigned live=(1u<<n)-1;
 while(live){
  unsigned a=live&-live,b=0,front=a;bool phase=false;
  while(front){
   unsigned next=0;
   for(unsigned v=front;v;v&=v-1)next|=adj[countr_zero(v)];
   if(next&(phase?b:a))return false;
   next&=~(a|b);
   if(phase)a|=next;else b|=next;
   front=next;phase=!phase;
  }
  out.a[out.count]=a;out.b[out.count++]=b;live&=~(a|b);
 }
 return true;
}
template<int W>struct Info{array<int,W> a{};Groups g; bool good;};
template<int W>Info<W> process(const Marked<W>&bank,const vector<M>&table){
 Info<W> r;r.good=!bank.bad;
 for(int i=0;i<W;i++)for(int j=0;j<i;j++)if(clash(table[bank.ids[i]],table[bank.ids[j]])){r.a[i]|=1<<j;r.a[j]|=1<<i;}
 r.good &=color(r.a.data(),W,r.g);return r;
}

using Bits=array<uint64_t,4>;
template<int W>struct Block{
 array<int,28> p{};array<Bits,1<<W> z{};
 Block(const array<M,W>&upper_lower) {
  for(int x=0;x<28;x++)for(int i=0;i<W;i++)p[x]|=((upper_lower[i][0]>>x)&1)<<i;
  z[0].fill(~uint64_t(0));z[0][3]=(uint64_t(1)<<53)-1;
  for(int m=1;m<1<<W;m++)for(int b=0;b<4;b++)z[m][b]=z[m&(m-1)][b]&upper_lower[countr_zero((unsigned)m)][b+1];
 }
 Block(const Marked<W>&bk,const vector<int>&pos,const vector<int>&neg,bool point){
  array<Bits,W> truth{};for(int x=0;x<28;x++)for(int i=0;i<W;i++)
   p[x]|=bool(bk.v[i]&(point?pos[x]&8191:pos[x]>>13))<<i;
  for(int y=0;y<245;y++)for(int i=0;i<W;i++)if(bk.v[i]&(point?neg[y]&8191:neg[y]>>13))truth[i][y/64]|=uint64_t(1)<<(y%64);
  z[0].fill(~uint64_t(0)); z[0][3]=(uint64_t(1)<<(245-192))-1;
  for(int m=1;m<1<<W;m++)for(int b=0;b<4;b++)z[m][b]=z[m&(m-1)][b]&truth[countr_zero((unsigned)m)][b];
 }
};
// Row x can force the repeated Boolean output to one iff no outer feature
// distinguishes it from at least one negative. Each such negative forces zero.
bool partial(const Block<13>&p,const Block<9>&l,unsigned inner,unsigned outer){
 unsigned ip=inner&8191,il=inner>>13,op=outer&8191,ol=outer>>13;
 unsigned Q=0;Bits R{};
 for(int x=0;x<28;x++){
  auto&a=p.z[(8191^ip)&p.p[x]];auto&b=l.z[(511^il)&l.p[x]];uint64_t any=0;
  for(int k=0;k<4;k++){uint64_t t=a[k]&b[k];any|=t;R[k]|=t;}
  if(any)Q|=1u<<x;
 }
 while(Q){
  int x=countr_zero(Q);Q&=Q-1;
  auto&a=p.z[(8191^op)&p.p[x]];auto&b=l.z[(511^ol)&l.p[x]];
  if((a[0]&b[0]&R[0])|(a[1]&b[1]&R[1])|(a[2]&b[2]&R[2])|(a[3]&b[3]&R[3]))return false;
 }
 return true;
}
bool modpart(const Groups&g,const Block<13>&p,const Block<9>&l){
 array<int,22> ix;for(int i=0;i<g.count;i++)ix[i]=i;
 sort(ix.begin(),ix.begin()+g.count,[&](int x,int y){return popcount((unsigned)(g.a[x]|g.b[x]))>popcount((unsigned)(g.a[y]|g.b[y]));});
 auto dfs=[&](auto &self,int k,unsigned inner,unsigned outer)->bool{
  if(k==g.count && (!inner || ((inner&(inner-1)) && (!(inner&8191)||!(inner>>13)))))return false;
  if(k && !partial(p,l,inner,outer))return false;
  if(k==g.count)return true;
  int t=ix[k];
  return self(self,k+1,inner|g.a[t],outer|g.b[t]) || self(self,k+1,inner|g.b[t],outer|g.a[t]);
 };
 return dfs(dfs,0,0,0);
}
using Bank = array<int,13>;
using Profile = array<M,13>;
array<M,8192> truth;
struct Record {int p,n;};
struct Study {
 vector<int> pos,neg;vector<Record> pairs;
 vector<Marked<9>> ln;vector<M> lm;vector<Info<9>> li;vector<Block<9>> lb;
 vector<Bank> points;
 uint64_t tried=0,pass=0,ex=0,nodes=0;
 vector<int> check(const Profile&x,const vector<int>&choices){
  nodes++;
  array<unsigned,28>P{};array<unsigned,245>N{};Profile marks{};
  for(unsigned i=0;i<13;i++){
   for(unsigned r=0;r<28;r++)P[r]|=((x[i][0]>>r)&1)<<i;
   for(unsigned r=0;r<245;r++)N[r]|=((x[i][1+r/64]>>(r%64))&1)<<i;
  }
  for(auto r:pairs){
   unsigned d=P[r.p]&~N[r.n];if(!has_single_bit(d))continue;
   auto&m=marks[countr_zero(d)];m[0]|=1u<<r.p;m[1+r.n/64]|=uint64_t(1)<<(r.n%64);
  }
  Marked<13> v;for(int i=0;i<13;i++)v.ids[i]=i;
  vector<M> mark(marks.begin(),marks.end());auto pi=process(v,mark);
  vector<int> keep;if(!pi.good)return keep;
  vector<int> link(lm.size());
  for(int k=0;k<(int)lm.size();k++){
   int m=0;for(int t=0;t<13;t++)if(clash(marks[t],lm[k]))m|=1<<t;
   for(int t=0;t<pi.g.count;t++)if((m&pi.g.a[t])&&(m&pi.g.b[t])){m=-1;break;}link[k]=m;
  }
  Block<13> pb(x);
  for(int j:choices){
   tried++;if(!li[j].good)continue;
   int adj[22]{};copy(pi.a.begin(),pi.a.end(),adj);bool ok=true;
   for(int t=0;t<9;t++){
    int u=link[ln[j].ids[t]];if(u<0){ok=false;break;}adj[t+13]=(li[j].a[t]<<13)|u;
    for(;u;u&=u-1)adj[countr_zero((unsigned)u)]|=1<<(13+t);
   }
   Groups g;if(!ok||!color(adj,22,g))continue;
   if(modpart(g,pb,lb[j]))keep.push_back(j);
  }
  return keep;
 }
 void segment(int low,int high,const vector<int>&active){
  Profile profile{};
  for(int i=0;i<13;i++)profile[i]=truth[points[low][i]];
  for(int t=low+1;t<high;t++)for(int i=0;i<13;i++){
   const M&m=truth[points[t][i]];profile[i][0]|=m[0];for(int k=1;k<5;k++)profile[i][k]&=m[k];
  }
  auto keep=check(profile,active);
  ex+=uint64_t(high-low)*(active.size()-keep.size());
  if(keep.empty())return;
  if(high-low==1){for(int j:keep)cout<<low<<" "<<j<<'\n';pass+=keep.size();return;}
  int mid=(high+low)/2;segment(low,mid,keep);segment(mid,high,keep);
 }
};
int main(int argc,char**argv){
 if(argc!=7)return 1;
 Study s;ifstream f(argv[1]);int p,n;f>>p>>n;if(p!=28||n!=245)return 2;
 s.pos.resize(p);s.neg.resize(n);for(auto &x:s.pos)f>>x;for(auto &x:s.neg)f>>x;
 for(int i=0;i<p;i++)for(int j=0;j<n;j++)if(!((s.pos[i]&~s.neg[j])>>13))s.pairs.push_back({i,j});
 for(int m=0;m<8192;m++){
  for(int i=0;i<p;i++)if(s.pos[i]&m)truth[m][0]|=1u<<i;
  for(int i=0;i<n;i++)if(s.neg[i]&m)truth[m][1+i/64]|=uint64_t(1)<<(i%64);
 }
 ifstream pts(argv[2]);Bank bank;while(pts>>bank[0]){for(int i=1;i<13;i++)if(!(pts>>bank[i]))return 3;s.points.push_back(bank);}
 map<M,int> ids;s.ln=readbank<9>(argv[3],s.pos,s.neg,false,ids,s.lm);vector<int> lines;
 for(int i=0;i<(int)s.ln.size();i++){s.li.push_back(process(s.ln[i],s.lm));s.lb.emplace_back(s.ln[i],s.pos,s.neg,false);lines.push_back(i);}
 int size=stoi(argv[4]),start=stoi(argv[5]),end=min((int)s.points.size(),stoi(argv[6]));
 if(size<1||start<0||start>=end)return 4;
 for(int i=start;i<end;i+=size){s.segment(i,min(i+size,end),lines);if((i-start)%(32*size)==0)cerr<<"progress "<<i<<" cut tests "<<s.tried<<" survivors "<<s.pass<<endl;}
 uint64_t total=uint64_t(end-start)*lines.size();if(s.ex+s.pass!=total)return 5;
 cerr<<"DONE "<<total<<' '<<s.tried<<' '<<s.nodes<<' '<<s.pass<<endl;
}
