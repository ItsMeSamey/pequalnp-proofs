#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;using U=unsigned long long;
struct Row{int p,n;U flags;};
bool hit(const vector<int>&a,const vector<int>&b,int yes=0,int no=0){
 int q=0;
 for(;;){int ny=yes,nn=no,pa=0,pb=0,best=14;
  for(int s=0;s<2;s++)for(int x:s?b:a){if(x&(s?no:yes))continue;
   int rem=x&~(s?yes:no);if(!rem)return false;
   if((rem&(rem-1))==0){(s?nn:ny)|=rem;continue;}
   (s?pb:pa)++;int c=popcount((unsigned)rem);
   if(c<best){best=c;q=rem&-rem;}
  }
  if(ny&nn)return false;if(ny!=yes||nn!=no){yes=ny;no=nn;continue;}
  if(!pa||!pb)return true;break;
 }
 return hit(a,b,yes|q,no)||hit(a,b,yes,no|q);
}
int main(int argc,char**av){
 ifstream fs(av[1]);int np,nn;fs>>np>>nn;assert(np==28&&nn==245);
 vector<int>P(np),N(nn);int star[7]{};for(int &p:P){fs>>p;star[countr_zero((unsigned)(p>>13))]|=p&8191;}for(int &n:N)fs>>n;
 int jnum=0,jidx[128]{};vector<int> groups;for(int m=1;m<128;m++)if(popcount((unsigned)m)<=3){jidx[m]=jnum++;groups.push_back(m);}assert(jnum==63);
 vector<int> pat;int id[8192];fill_n(id,8192,-1);auto get=[&](int x){if(id[x]<0){id[x]=pat.size();pat.push_back(x);}return id[x];};
 vector<Row>pr,ou;
 for(int t=0;t<7;t++)for(int x=0;x<13;x++)if(star[t]>>x&1)for(int y=0;y<13;y++)if(!(star[t]>>y&1))for(int z=0;z<y;z++)if(!(star[t]>>z&1))pr.push_back({get(1<<x),get((1<<y)|(1<<z)),1ULL<<t});
 for(int p:P)for(int n:N)if((p>>13)&(n>>13)){int meet=0;for(int t=0;t<7;t++)if(n&star[t])meet|=1<<t;U tags=0;
  for(int j:groups)if(!(j&(p>>13))&&!(j&~meet))tags|=1ULL<<jidx[j];if(tags)ou.push_back({get(p&8191),get(n&8191),tags});}
 vector<int>rank(8192);for(int i=0;i<8192;i++)rank[i]=i;sort(rank.begin(),rank.end(),[](int x,int y){return popcount((unsigned)x)<popcount((unsigned)y);});
 array<int,13>b;long long total=0;array<long long,22>counts{};
 while(cin>>b[0]){for(int k=1;k<13;k++)cin>>b[k];vector<int>code(pat.size());for(int j=0;j<(int)pat.size();j++)for(int k=0;k<13;k++)if(pat[j]&b[k])code[j]|=1<<k;
  U at[8192]{},bt[8192]{};for(auto r:pr)at[code[r.p]&~code[r.n]]|=r.flags;for(auto r:ou)bt[code[r.p]&~code[r.n]]|=r.flags;
  vector<int>pp[7],oo[63];
  auto push=[](vector<int>&v,int m){for(int x:v)if(!(x&~m))return;v.push_back(m);};
  for(int x:rank){U a=at[x],b=bt[x];for(;a;a&=a-1)push(pp[countr_zero(a)],x);for(;b;b&=b-1)push(oo[countr_zero(b)],x);}
  U possibles=0;
  for(int m:groups){vector<int>all;for(int j=0;j<7;j++)if(m>>j&1)all.insert(all.end(),pp[j].begin(),pp[j].end());if(hit(all,oo[jidx[m]]))possibles|=1ULL<<jidx[m];}
  U flags5=0,flags4=0;int ne=0,nf=0;
  for(int e=0;e<128;e++){int n=popcount((unsigned)e);if(n!=4&&n!=5)continue;
   int o=127^e;bool ok=(possibles>>jidx[o])&1;for(int t=o;t;t&=t-1)ok|=(possibles>>jidx[o^(t&-t)])&1;
   if(n==5)flags5|=U(ok)<<ne++;else flags4|=U(ok)<<nf++;}
  counts[popcount(flags5)]++;total++;cout<<flags4<<' '<<flags5<<'\n';
 }
 cerr<<"two-star-ordinary ";for(int k=0;k<=21;k++)if(counts[k])cerr<<k<<":"<<counts[k]<<" ";cerr<<"total "<<total<<'\n';
}
