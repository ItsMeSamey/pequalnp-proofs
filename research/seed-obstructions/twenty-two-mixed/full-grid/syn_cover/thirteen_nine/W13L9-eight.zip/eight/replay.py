from pathlib import Path
from collections import defaultdict
from struct import Struct
import subprocess,time,resource
from tempfile import TemporaryDirectory
import gzip,sys
from setup_inputs import prepare,source
tmp=TemporaryDirectory();root=Path(tmp.name);prepare(root)
sample=root/'rows';action=root/'action';envelope=root/'cohort';packing=Struct('>13H')
regular={4:[x for x in range(128) if x.bit_count()==4],5:[x for x in range(128) if x.bit_count()==5]}
lines=defaultdict(list);base=tuple(1<<j for j in range(7))
for s in (root/'lines3').read_text().splitlines():
 q=list(map(int,s.split()))
 if all(j in q for j in base):
  for j in base:q.remove(j)
  e=q[0]|q[1]
  if e.bit_count()<=3:continue
 else:e=-1
 lines[e].append(s)
assert len(lines[-1])==24 and sum(map(len,lines.values()))==1459
for e,values in lines.items():(root/f's8l{e}').write_text('\n'.join(values)+'\n')
def timed(args,**kw):return subprocess.run(list(map(str,args)),check=True,**kw)
def totext(banks):return ''.join(' '.join(map(str,packing.unpack(b)))+'\n' for b in banks)
bs=[packing.pack(*map(int,x.split())) for x in gzip.decompress((source/'new8.gz').read_bytes()).splitlines()]
assert len(bs)==420948 and all(x<y for x,y in zip(bs,bs[1:]))
lo,hi=map(int,sys.argv[1:] or (0,len(bs)));assert 0<=lo<hi<=len(bs)
name='replay';bs=bs[lo:hi]
chunks=12800
for start in range(0,len(bs),chunks):
 bb=bs[start:start+chunks];txt=totext(bb).encode()
 z=timed([root/'quartet',action,sample,root/'known'],input=txt,capture_output=True);q4=list(map(int,z.stdout.split()))
 z=timed([root/'partition',sample],input=txt,capture_output=True);q5=[tuple(map(int,l.split())) for l in z.stdout.splitlines()]
 assert len(bb)==len(q4)==len(q5)
 elig=defaultdict(list)
 for i,(a,(b,c)) in enumerate(zip(q4,q5)):
  elig[-1].append(i)
  for k,mask in ((4,a&b),(5,c)):
   while mask:
    bit=mask&-mask;mask^=bit;elig[regular[k][bit.bit_length()-1]].append(i)
 ecomp=native=kept=0
 for e,ids in sorted(elig.items()):
  (root/'s8-subpoints').write_text(totext([bb[i] for i in ids]))
  z=timed([envelope,sample,root/'s8-subpoints',root/f's8l{e}',128,0,len(ids)],capture_output=True,text=True)
  _,tested,tried,nodes,pending=z.stderr.splitlines()[-1].split();assert int(tested)==len(ids)*len(lines[e])
  ecomp+=int(tested);native+=int(tried);kept+=int(pending)
  if int(pending):
   with (root/'s8-pending').open('a') as out:
    for l in z.stdout.splitlines():
     i,j=map(int,l.split());print(*packing.unpack(bb[ids[i]]),'|',lines[e][j],file=out)
 assert kept==0
 print(name,lo+start,len(bb),'all',len(bb)*1459,'passed geometry',ecomp,'cohort cuts',native,'pending',kept,flush=True)
