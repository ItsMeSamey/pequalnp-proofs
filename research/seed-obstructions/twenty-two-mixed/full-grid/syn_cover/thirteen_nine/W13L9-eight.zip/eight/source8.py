"""Optional regeneration of the canonical table for point cost eight."""
from pathlib import Path
from tempfile import TemporaryDirectory
import gzip,subprocess
from setup_inputs import source
from verify import group,image,raw
with TemporaryDirectory() as td:
 d=Path(td);groups=group()
 with (d/'action').open('w') as f:
  print(*raw,file=f)
  for g in groups:print(*(image(i,g) for i in range(8192)),file=f)
 for s,n in [('refinefast.cpp','filter'),('orbit.cpp','orbit')]:
  subprocess.run(['c++','-O3','-march=native','-std=c++20',source/s,'-o',d/n],check=True)
 data=gzip.decompress((source/'W13-g8-potential.txt.gz').read_bytes())
 actual=subprocess.run([d/'filter','8',d/'action'],input=data,capture_output=True,check=True)
 collected={tuple(map(int,s.split())) for s in actual.stdout.splitlines()}
 assert len(collected)==427535
 padding=set()
 for row in (source/'banks-through-seven.txt').read_text().splitlines():
  *bank,cost=map(int,row.split());assert cost<=7
  padding.update(tuple(sorted((*bank,v))) for v in (0,*bank))
 payload=''.join(' '.join(map(str,b))+'\n' for b in sorted(padding)).encode()
 ret=subprocess.run([d/'orbit',d/'action'],input=payload,capture_output=True,check=True)
 collected.update(tuple(map(int,s.split())) for s in ret.stdout.splitlines());assert len(collected)==427856
 previous={tuple(map(int,s.split())) for s in gzip.decompress((source/'points7.gz').read_bytes()).splitlines()}
 assert len(previous)==6908 and previous<=collected
 final=sorted(collected-previous);assert len(final)==420948
 assert final==[tuple(map(int,s.split())) for s in gzip.decompress((source/'new8.gz').read_bytes()).splitlines()]
 print('new banks',len(final))
