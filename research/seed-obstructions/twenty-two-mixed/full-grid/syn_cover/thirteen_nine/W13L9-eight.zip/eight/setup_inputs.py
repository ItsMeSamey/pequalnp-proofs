import gzip,subprocess
from itertools import combinations_with_replacement
from pathlib import Path
from verify import group,raw,neg,pos,image
from price import price
source=Path(__file__).resolve().parent
def prepare(root):
 (root/'rows').write_text(' '.join(map(str,[len(pos),len(neg),*sorted(pos),*sorted(neg)])))
 g=group()
 with (root/'action').open('w') as f:
  print(*raw,file=f)
  for pm in g:print(*(image(x,pm) for x in range(8192)),file=f)
 (root/'known').write_bytes(gzip.decompress((source/'known.gz').read_bytes()))
 rawlines=tuple(1<<j for j in range(7))
 universe={tuple(sorted((*rawlines,a,b))) for a,b in combinations_with_replacement(range(128),2)}
 universe.update(tuple(map(int,l.split())) for l in (source/'exceptional.txt').read_text().splitlines()[1:])
 assert len(universe)==8280
 legal=[l for l in sorted(universe) if price(l)<=3];assert len(legal)==2069
 (root/'lines3').write_text(''.join(' '.join(map(str,l))+'\n' for l in legal))
 for src,binary in [('cohorts.cpp','cohort'),('quartet.cpp','quartet'),('partition5.cpp','partition')]:
  subprocess.run(['c++','-O3','-march=native','-std=c++20',source/src,'-o',root/binary],check=True)
