#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
using Bank=array<int,13>;
using U=unsigned long long;
int star[7],mapmask[8192],pid[28],label[28];
struct Row{int p,line,point,flags;};
vector<Row> rows;
map<Bank,U> known;
int quarter[128],quartets=0;
int main(int argc,char**av){
 ifstream act(av[1]),sample(av[2]),data(av[3]);int v,np,nn;for(int k=0;k<31;k++)act>>v;
 sample>>np>>nn;assert(np==28&&nn==245);vector<int> ps(np),ns(nn);
 for(int i=0;i<np;i++){sample>>ps[i];pid[i]=ps[i]&8191;label[i]=ps[i]>>13;star[countr_zero((unsigned)label[i])]|=pid[i];}
 for(int&n:ns)sample>>n;
 for(int i=0;i<np;i++)for(int n:ns)if((n>>13)&label[i]){int flags=0;for(int s=0;s<7;s++)if(n&star[s])flags|=1<<s;rows.push_back({i,label[i],n&8191,flags});}
 for(int e=0;e<128;e++)if(popcount((unsigned)e)==4)quarter[e]=quartets++;assert(quartets==35);
 vector<pair<Bank,int>> src;Bank b{};int e;
 while(data>>e){for(int&x:b)data>>x;src.emplace_back(b,e);}
 for(int g=0;g<24;g++){
  for(int &a:mapmask)act>>a;int ml[7];for(int j=0;j<7;j++){ml[j]=find(star,star+7,mapmask[star[j]])-star;assert(ml[j]<7);}
  for(auto&[bank,E]:src){Bank x=bank;for(int&m:x)m=mapmask[m];sort(x.begin(),x.end());int q=0;for(int j=0;j<7;j++)if(E>>j&1)q|=1<<ml[j];known[x]|=1ULL<<quarter[q];}
 }
 int st[8192];fill_n(st,8192,-1);for(int i=0;i<7;i++)st[star[i]]=i;
 vector<array<int,2>> exterior[7];for(int t=0;t<7;t++)for(int p=0;p<13;p++)for(int q=0;q<p;q++)if(!(star[t]&((1<<p)|(1<<q))))exterior[t].push_back({p,q});
 unsigned long long counts[36]{},total=0;
 while(cin>>b[0]){
  for(int i=1;i<13;i++)cin>>b[i];assert(is_sorted(b.begin(),b.end()));
  U elig=0;auto knownhere=known.find(b);if(knownhere!=known.end())elig=knownhere->second;
  vector<int> groups[7];
  U hits[7][13]{};for(int t=0;t<7;t++)for(int i=0;i<13;i++){int k=0;for(auto [p,q]:exterior[t]){if(b[i]&((1<<p)|(1<<q)))hits[t][i]|=1ULL<<k;k++;}}
  for(int i=0;i<13;i++){if(st[b[i]]>=0)groups[st[b[i]]].push_back(1<<i);
   for(int j=0;j<i;j++)for(int op=0;op<2;op++){
    int pair=op?b[i]&b[j]:b[i]|b[j];int t=st[pair];
    if(t>=0&&!(op?hits[t][i]&hits[t][j]:hits[t][i]|hits[t][j]))groups[t].push_back((1<<i)|(1<<j));
    for(int k=0;k<13;k++){if(k==i||k==j)continue;
     for(int op2=0;op2<2;op2++){
      int t=st[op2?pair&b[k]:pair|b[k]];if(t<0)continue;U x=op?hits[t][i]&hits[t][j]:hits[t][i]|hits[t][j];
      if(!(op2?x&hits[t][k]:x|hits[t][k]))groups[t].push_back((1<<i)|(1<<j)|(1<<k));
     }
    }
   }
  }
  for(auto&v:groups){sort(v.begin(),v.end());v.erase(unique(v.begin(),v.end()),v.end());}
  int pc=0;for(auto&v:groups)pc+=!v.empty();
  if(pc>=2){
   int bits[8192]{};for(auto &r:rows)if(!bits[r.point]){int f=0;for(int j=0;j<13;j++)if(b[j]&r.point)f|=1<<j;bits[r.point]=f;}
   int pbits[28]{};for(int i=0;i<28;i++)for(int j=0;j<13;j++)if(pid[i]&b[j])pbits[i]|=1<<j;
   for(int t=0;t<7;t++)for(int u=0;u<t;u++){
    int tu=(1<<t)|(1<<u),E=127^tu;bool good=false;
    for(int x:groups[t]){for(int y:groups[u]){int removed=x|y;if((x&y)||popcount((unsigned)removed)>4)continue;
     int bad[28]{};bool ok=true;for(auto&r:rows){if(!(r.line&E)||(pbits[r.p]&~bits[r.point]&~removed))continue;
      bad[r.p]|=r.flags;if((bad[r.p]&tu)==tu){ok=false;break;}}
     if(ok){good=true;break;}
    }if(good)break;}
    if(good)for(int k=0;k<7;k++)if(E>>k&1)elig|=1ULL<<quarter[E^(1<<k)];
   }
  }
  counts[popcount(elig)]++;total++;cout<<elig<<'\n';
 }
 cerr<<"quartet votes ";for(int k=0;k<=35;k++)if(counts[k])cerr<<k<<":"<<counts[k]<<" ";cerr<<"total "<<total<<"\n";
}
