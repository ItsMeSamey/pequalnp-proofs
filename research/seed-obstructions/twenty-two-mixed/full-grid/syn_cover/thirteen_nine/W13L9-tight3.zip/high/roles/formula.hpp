int minformula[1594323],tri[8192],power3[13];
void init_formula(){
 vector<int> bucket[10];int price[8192];fill_n(price,8192,10);
 for(int x=0;x<8192;x++)if(x==0||(hereditary::subraw[x]&hereditary::superraw[x])){price[x]=0;bucket[0].push_back(x);}
 for(int c=1;c<=9;c++)for(int a=0;a<=(c-1)/2;a++)for(int x:bucket[a])for(int y:bucket[c-1-a])
  for(int z:{x|y,x&y})if(price[z]>c){price[z]=c;bucket[c].push_back(z);}
 power3[0]=1;for(int j=1;j<13;j++)power3[j]=3*power3[j-1];
 for(int x=1;x<8192;x++)tri[x]=tri[x&(x-1)]+power3[countr_zero((unsigned)x)];
 fill_n(minformula,1594323,11);
 for(int x=0;x<8192;x++)minformula[tri[x]+2*tri[8191^x]]=price[x];
 for(int i=1594322;i>=0;i--)if(minformula[i]==11){int n=i,j=0;while(n%3){n/=3;j++;}minformula[i]=min(minformula[i+power3[j]],minformula[i+2*power3[j]]);}
}
