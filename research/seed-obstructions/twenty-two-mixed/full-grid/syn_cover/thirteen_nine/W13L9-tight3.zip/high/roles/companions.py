from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'certificate'))
from input import raw_samples
P,N,_=raw_samples(Path(__file__).resolve().parents[2]/'certificate/L-meta-18968.json')
out=Path(sys.argv[1])
for E in range(128):
 if E.bit_count()!=5:continue
 stars=[sum({p&8191 for p in P if p>>(13+j)&1}) for j in range(7)]
 data=[]
 for p in sorted(P):
  label=p>>13
  if not E&label:continue
  for j,t in enumerate(stars):
   if E>>j&1:continue
   sets={n&8191 for n in N if n>>13&label and n&t}
   maximal=sorted(a for a in sets if not any(a!=b and not a&~b for b in sets))
   data.append(str(len(maximal))+' '+' '.join(f'{p&8191} {n}' for n in maximal))
 (out/f'comp{E}').write_text('\n'.join(data)+'\n')
