from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'certificate'))
from verify import *
out=Path(sys.argv[1]);size,per,_=direct_costs();lib=[v for v in raw if v.bit_count()>1];g=group();total=size+per.sum(axis=1)
for s,rs in ((3,(1,3,5)),(4,(0,2,4))):
 by={r:{} for r in rs}
 for xs in combinations(range(13),s):
  S=sum(1<<x for x in xs);score=total-per[:,xs].sum(axis=1);m=int(score.min())
  if m!=22-s:continue
  for F in np.where(score==m)[0]:
   free=[v for i,v in enumerate(lib) if F>>i&1];cap=[sum((v>>j)&1 for v in free)+(1 if S>>j&1 else int(per[F,j])) for j in range(13)]
   for pm in g:
    moved=tuple(cap[pm.index(j)] for j in range(13));sel=image(S,pm);fr=sorted(image(v,pm) for v in free)
    for r,dd in by.items():
     for rsel in combinations(fr,r):
      key=(sel,*rsel)
      if key not in dd:dd[key]=moved
      else:dd[key]=tuple(map(max,zip(dd[key],moved)))
 for r,dd in by.items():
  (out/f'caps{s}-{r}').write_text(''.join(' '.join(map(str,[*key,*cap]))+'\n' for key,cap in sorted(dd.items())))
  print(s,r,len(dd),flush=True)
