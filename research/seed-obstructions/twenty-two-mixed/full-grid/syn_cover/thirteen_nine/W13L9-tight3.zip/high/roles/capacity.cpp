#include "hereditaryrole.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <fstream>
#include <set>
#include <map>
#include <vector>
using namespace std;
constexpr int W = 13, A = 8191, B = 32;
using U = uint64_t;
using Row = array<int, W>;
using Bits = array<U, B>;
struct R {
    int a, b;
};
vector<R> rows;
Bits pos[8192]{}, neg[8192]{}, full{};
int stars[7];
uint64_t family_count = 0, nodes = 0, charge_pruned = 0;
Row anchors{}, excluded{};
uint64_t stars_pruned = 0;
int fixedfour, nanchors;
int role[13], gsz[7];
uint64_t ncase = 0;

int freew,forced,single_count,single_set; bool capped;
int form[7],off[7],cap[13];
vector<pair<int,int>> comp_rows;
vector<vector<int>> comp_options;
constexpr int CB=20;
using CompBits=array<U,CB>;
CompBits comp_pos[8192],comp_neg[8192];
bool legal_comp(const Row& yes,const Row& no){
 CompBits possible{};
 for(int j=0;j<freew;j++)for(int k=0;k<(int(comp_rows.size())+63)/64;k++)
  possible[k]|=comp_pos[A^no[j]][k]&comp_neg[yes[j]][k];
 bool good=false;
 for(int i=0;i<(int)comp_options.size();i++){
  if(i%2==0)good=false;
  if(!good){good=true;for(int r:comp_options[i])if(!((possible[r/64]>>(r%64))&1)){good=false;break;}}
  if(i%2 && !good)return false;
 }
 return true;
}
Bits allow[W];
int sz(int f){return !f?0:f==1?1:f==2||f==7?2:f<=7?3:4;}
int fn(int f,const int *v){int a=v[0],b=v[1],c=v[2],d=v[3];switch(f){case 1:return a;case 2:return (a|b);case 7:return (a&b);case 3:return (a|b|c);case 4:return (a&b&c);case 5:return ((a&b)|c);case 6:return ((a|b)&c);case 8:return ((a|b|c)|d);case 9:return ((a|b|c)&d);case 10:return ((a&b&c)|d);case 11:return ((a&b&c)&d);case 12:return (((a&b)|c)|d);case 13:return (((a&b)|c)&d);case 14:return (((a|b)&c)|d);case 15:return (((a|b)&c)&d);case 16:return ((a|b)|(c|d));case 17:return ((a|b)&(c|d));case 18:return ((a|b)|(c&d));case 19:return ((a|b)&(c&d));case 20:return ((a&b)|(c&d));case 21:return ((a&b)&(c&d));default:abort();}}
int propagate(Row &lo,Row &no) {
 bool ch=false;
 for(int t=0;t<7;t++) if(form[t]>1){
  int k=off[t],f=form[t],n=sz(f),T=stars[t];
  int v[4]{},h[4]{};
  for(int i=0;i<n;i++)v[i]=lo[k+i],h[i]=A^no[k+i];
  if((fn(f,v)&~T)||(T&~fn(f,h)))return -1;
  for(int i=0;i<n;i++){
   int old=h[i];h[i]=0;int must=T&~fn(f,h);h[i]=old;
   int org=v[i];v[i]=A;int ban=~T&fn(f,v);v[i]=org;
   if((must&~org)||(ban&old)){lo[k+i]|=must;no[k+i]|=ban;ch=true;}
  }
  if(f!=2&&f!=3){
   for(int x=A&~T;x;x&=x-1)for(int y=x&(x-1);y;y&=y-1){
    int pair=(x&-x)|(y&-y),bb[4]{};
    for(int i=0;i<n;i++) bb[i]=bool(v[i]&pair);
    if(fn(f,bb))return -1;
    for(int i=0;i<n;i++)if(!bb[i]){
     bb[i]=1;int ban=fn(f,bb)?pair:0;bb[i]=0;
     if(ban&~no[k+i]){no[k+i]|=ban;ch=true;}
    }
   }
  }
 }
 return ch;
}
#include "formula.hpp"
void visit(Row yes, Row no) {
    if (++nodes % 1000000 == 0)
        cerr << nodes << " nodes " << family_count << " surviving families " << charge_pruned
             << " charge-pruned nodes " << stars_pruned << " recovery-pruned nodes" << endl;
    int slot = -1, bit = 0;
    for (;;) {
        for (int i = nanchors; i + 1 < freew; i++)
            if (role[i] == role[i + 1] && yes[i] > (A ^ no[i + 1]))
                return;
        for (int j = nanchors; j < W; j++)
            for (int i = 0; i < nanchors; i++) {
                if (role[i] == role[j] && !(anchors[i] & ~yes[j]) && !(excluded[i] & ~no[j]) &&
                    (A ^ no[j]) < yes[i])
                    return;
            }
        // For each slot and witness row track possible coverage, guaranteed
        // coverage, and coverage forced onto this slot.
        Bits can[W], sole[W];
        bool change = false;
        int selected = -1, best = W + 1;
        int fullstars = 0;
        for (int i = 0; i < W; i++)
            if ((yes[i] | no[i]) == A)
                for (int l = 0; l < 7; l++)
                    if (yes[i] == stars[l])
                        fullstars |= 1 << l;
        if (popcount((unsigned)fullstars) >= 4)
            return;
        for(int a=0;a<13;a++){const int v=1<<a;int n=0;for(int m:yes)n+=bool(m&v);
         if(n>cap[a])return;if(n==cap[a])for(int j=0;j<W;j++)if(!(yes[j]&v))no[j]|=v;}
        int prop = propagate(yes, no);
        if (prop < 0) {
            ++stars_pruned;
            return;
        }
        if (prop)
            continue;
        for (int z = 0; z < B; z++) {
            U c = 0, mc = 0, g = 0;
            for (int i = 0; i < W; i++) {
                U x = can[i][z] = allow[i][z] & pos[A ^ no[i]][z] & neg[yes[i]][z];
                U y = allow[i][z] & pos[yes[i]][z] & neg[A ^ no[i]][z];
                mc |= c & x;
                c |= x;
                g |= y;
            }
            if (c != full[z])
                return;
            for (int i = 0; i < W; i++) {
                sole[i][z] = can[i][z] & ~(mc | g);
            }
            if (best == 2)
                continue;
            U opt = full[z] & ~g & mc;
            while (opt) {
                int b = countr_zero(opt), ct = 0;
                for (int i = 0; i < W && ct < best; i++)
                    ct += (can[i][z] >> b) & 1;
                if (ct < best) {
                    best = ct;
                    selected = z * 64 + b;
                }
                opt &= opt - 1;
                if (best == 2)
                    break;
            }
        }
        for (int i = 0; i < W; i++) {
            int forced = 0, avoid = 0;
            for (int z = 0; z < B; z++) {
                U v = sole[i][z];
                while (v) {
                    auto r = rows[64 * z + countr_zero(v)];
                    v &= v - 1;
                    forced |= r.a;
                    avoid |= r.b;
                }
            }
            if ((forced | yes[i]) & (avoid | no[i]))
                return;
            if ((forced & ~yes[i]) || (avoid & ~no[i])) {
                yes[i] |= forced;
                no[i] |= avoid;
                change = true;
            }
        }
        if (change)
            continue;
        Row high;
        for (int i = 0; i < W; i++)
            high[i] = A ^ no[i];
        int cost=0;for(int j=0;j<W;j++)cost+=minformula[tri[yes[j]]+2*tri[no[j]]];if(cost>9)return;
        if(!legal_comp(yes,no))return;
        if(capped)for(int i=0;i<W;i++)if(yes[i] && popcount((unsigned)high[i])==1 && !(high[i]&single_set))return;
        if (hereditary::bound(yes, high)) {
            ++charge_pruned;
            return;
        }
        if (selected >= 0) {
            auto r = rows[selected];
            for (slot = 0; slot < W; slot++)
                if ((selected>=forced || slot<freew) && !((r.a & no[slot]) | (r.b & yes[slot])))
                    break;
            int free = (r.a | r.b) & ~(yes[slot] | no[slot]);
            bit = free & -free;
        } else {
            for (slot = 0; slot < W; slot++) {
                int f = A & ~(yes[slot] | no[slot]);
                if (f) {
                    bit = f & -f;
                    break;
                }
            }
            if (slot == W) {
                sort(yes.begin(), yes.end());
                ++family_count;
                for (int x : yes)
                    cout << x << ' ';
                cout << '\n';
                return;
            }
        }
        break;
    }
    Row alt = yes;
    alt[slot] |= bit;
    visit(alt, no);
    no[slot] |= bit;
    visit(yes, no);
}

int main(int argc,char**argv){
 if(argc<2)return 1;single_count=stoi(argv[1]);capped=single_count<5;
 if(single_count!=3&&single_count!=4)return 4;hereditary::setup();init_formula();
 for(int t=0;t<7;t++)stars[t]=hereditary::target[t];
 freew=W;
 for(int &f:form){cin>>f;freew-=sz(f);}
 Row y{},n{};
 int off0=freew;
 for(int t=0;t<7;t++)if(int f=form[t]){
  hereditary::known_groups[t]=sz(f);off[t]=off0;
  for(int i=0;i<sz(f);i++){
   if(f==1)y[off0]=stars[t],n[off0]=A^stars[t];
   role[off0++]=t+1;
  }
 }
 int E=0;for(int j=0;j<7;j++)if(!form[j])E|=1<<j;
 ifstream cf("comp"+to_string(E));if(!cf)return 2;
 int num;while(cf>>num){vector<int> opt;while(num--){int p,n;cf>>p>>n;
  auto it=find(comp_rows.begin(),comp_rows.end(),pair{p,n});int id=it-comp_rows.begin();if(it==comp_rows.end())comp_rows.push_back({p,n});opt.push_back(id);}comp_options.push_back(opt);}
 if(comp_options.size()!=40 || comp_rows.size()>64*CB)return 3;
 for(int i=0;i<(int)comp_rows.size();i++)for(int v=0;v<=A;v++){const auto [p,n]=comp_rows[i];U digit=U(1)<<(i%64);
  if(v&p)comp_pos[v][i/64]|=digit;
  if(!(v&n))comp_neg[v][i/64]|=digit;}
 int savedfree=freew; cin>>nanchors;
 if(nanchors>freew){cerr<<"PACKED"<<endl;return 0;}
 for(int i=0;i<nanchors;i++){int p,b;cin>>p>>b;}
 anchors=y;excluded=n;
 cin>>forced;
 int a,b;while(cin>>a>>b) rows.push_back({a,b});
 if(rows.size()>64*B)abort();
 for(int j=0;j<(int)rows.size();j++) {
  auto [p,n]=rows[j];uint64_t bit=uint64_t(1)<<(j%64);
  full[j/64]|=bit;
  for(int i=0;i<W;i++)if(j>=forced||i<freew)allow[i][j/64]|=bit;
  for(int m=0;m<=A;m++){
   if(m&p)pos[m][j/64]|=bit;
   if(!(m&n))neg[m][j/64]|=bit;
  }
 }
 vector<Bits> neighbors(forced);
 for(int i=0;i<forced;i++)for(int j=0;j<forced;j++)
  if((rows[i].a&rows[j].b)||(rows[j].a&rows[i].b))neighbors[i][j/64]|=U(1)<<(j%64);
 struct Anchor {int count=0;Row yes{},no{};};
 vector<int> marks;map<vector<int>,Anchor> cache;
 auto anch=[&](int left){
  vector<int> selected;for(int i=0;i<(int)marks.size();i++)if(left>>i&1)selected.push_back(marks[i]);
  auto [it,added]=cache.try_emplace(selected);auto &out=it->second;if(!added)return out;
  Bits act{};for(int i=0;i<forced;i++){bool covered=false;for(int v:selected)if((v&rows[i].a)&&!(v&rows[i].b)){covered=true;break;}if(!covered)act[i/64]|=U(1)<<(i%64);}
  for(;;){int best=-1,score=-1;
   for(int z=0;z<B;z++)for(U q=act[z];q;q&=q-1){
    int r=64*z+countr_zero(q),n=0;
    for(int h=0;h<B;h++)n+=popcount(act[h]&neighbors[r][h]);
    if(n>score){score=n;best=r;}
   }
   if(best<0)break;
   out.yes[out.count]=rows[best].a;out.no[out.count++]=rows[best].b;
   for(int z=0;z<B;z++)act[z]&=neighbors[best][z];
  }
  return out;
 };
 uint64_t cases=0, sets=0;
 int r=4-single_count;for(int f:form)if(f==1||f==7)r+=2;
 ifstream fs("caps"+to_string(single_count)+"-"+to_string(r));if(!fs)return 4;int S;
 while(fs>>S){single_set=S;sets++;marks.clear();for(int q=S;q;q&=q-1)marks.push_back(q&-q);
 for(int j=0,v;j<r;j++){fs>>v;marks.push_back(v);}for(int&v:cap)fs>>v;sort(marks.begin(),marks.end());
  auto rec=[&](auto &rec,int i,int left,Row y,Row n)->void{
   if(i<W){
    rec(rec,i+1,left,y,n);
    if(y[i] || n[i])return;
    for(int q=left;q;q&=q-1){
     int p=marks[countr_zero((unsigned)q)]; y[i]=p;n[i]=A^p;Row test_y=y,test_n=n;int v;do{v=propagate(test_y,test_n);}while(v>0);if(v==0)rec(rec,i+1,left^(q&-q),y,n);
    }
    return;
   }
   int outside=popcount((unsigned)left), unknown=savedfree-outside;
   if(unknown<0)return;
   auto pack=anch(left);if(pack.count>unknown)return;
   nanchors=pack.count;
   for(int j=0;j<nanchors;j++){y[j]=pack.yes[j];n[j]=pack.no[j];}
   anchors=pack.yes;excluded=pack.no;
   for(int j=0;j<savedfree;j++)role[j]=0;
   int j=unknown;for(int q=left;q;q&=q-1){int p=marks[countr_zero((unsigned)q)];y[j]=p;n[j]=A^p;role[j++]=99;}
   ++cases;visit(y,n);
  };
  rec(rec,savedfree,(1<<marks.size())-1,y,n);
 }
 cerr<<"PLACEMENTS "<<sets<<" "<<cases<<endl;

 cerr<<"DONE "<<nodes<<" "<<family_count<<endl;
}
