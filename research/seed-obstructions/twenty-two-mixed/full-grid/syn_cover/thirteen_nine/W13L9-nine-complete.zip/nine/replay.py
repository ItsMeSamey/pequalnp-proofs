from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys
here=Path(__file__).resolve().parent
with TemporaryDirectory() as tmp:
    cut=Path(tmp)/'cut'
    endpoint=Path(tmp)/'endpoint'
    for binary,source in ((cut,'cut.cpp'),(endpoint,'endpoint_pruned.cpp')):
        subprocess.run(['g++','-O3','-std=c++20',here/'certificate'/source,'-o',binary],check=True)
    for family in ('five10price-{e}-3','five9bank-{e}-4','five10bank-{e}-4','five9bank-{e}-5'):
        print(family,flush=True)
        subprocess.run([sys.executable,here/'high/physical.py',here/'banks',cut,endpoint,family,'31','47','87'],check=True)
