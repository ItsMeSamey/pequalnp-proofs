from pathlib import Path
from itertools import combinations,combinations_with_replacement
from tempfile import TemporaryDirectory
import sys,subprocess
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'certificate'))
from verify import stars,pos,neg
root,cut,exact=map(Path,sys.argv[1:4])
raw=[1<<i for i in range(7)]
with TemporaryDirectory() as td:
 d=Path(td);orig=sorted(pos)+sorted(neg)
 (d/'rows').write_text(' '.join(map(str,[len(pos),len(neg),*orig])))
 for e in map(int,sys.argv[5:]):
  banks=set()
  source=root/sys.argv[4].format(e=e)
  for l in source.read_text().splitlines():
   bank=list(map(int,l.split()));assert len(bank)<=13
   for fill in combinations_with_replacement(sorted({0,*bank}),13-len(bank)):banks.add(tuple(sorted((*bank,*fill))))
  banks=sorted(banks);lines=[]
  for drop in raw:
   if not e&drop:continue
   labels=[x for x in raw if x&(e^drop)]
   lines.extend([*raw,a|b,e^drop^a^b] for a,b in combinations(labels,2) if a==labels[0])
  for n,data in [('p',banks),('l',lines)]:(d/n).write_text(''.join(' '.join(map(str,l))+'\n' for l in data))
  z=subprocess.run([cut,d/'rows',d/'p',d/'l','0',str(len(banks))],capture_output=True,text=True,check=True);print(e,len(banks),len(lines),z.stderr.splitlines()[-1],flush=True)
  inp=[]
  for line in z.stdout.splitlines():
   i,j=map(int,line.split());p,l=banks[i],lines[j]
   def enc(x):return sum(bool((x&8191)&m)<<h for h,m in enumerate(p)) | sum(bool((x>>13)&m)<<(13+h) for h,m in enumerate(l))
   pv=sorted(set(map(enc,orig[:len(pos)])))
   nv=[]
   for row in sorted(set(map(enc,orig[len(pos):])),key=int.bit_count,reverse=True):
    if all(row&~m for m in nv):nv.append(row)
   inp.append(' '.join(map(str,[len(pv),len(nv),*pv,*nv])))
  if inp:
   z=subprocess.run([exact,'13','9','1'],input='\n'.join(inp)+'\n',text=True,capture_output=True,check=True);answers=z.stdout.splitlines();assert len(answers)==len(inp) and all(l.startswith('0 ') for l in answers);print('exact',len(inp),'extinct',flush=True)
