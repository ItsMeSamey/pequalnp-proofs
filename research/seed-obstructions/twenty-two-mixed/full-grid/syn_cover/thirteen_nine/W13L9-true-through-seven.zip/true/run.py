from pathlib import Path
from tempfile import TemporaryDirectory
from itertools import combinations_with_replacement
from hashlib import sha256
from collections import Counter
import sys,subprocess,gzip
from price import price
from input import raw_samples
root=Path(__file__).resolve().parent
pos,neg,_=raw_samples(root/'L-meta-18968.json')
ordinary=tuple(1<<j for j in range(7))
nine={tuple(sorted((*ordinary,a,b))) for a,b in combinations_with_replacement(range(128),2)}
nine.update(tuple(map(int,l.split())) for l in (root/'exceptional.txt').read_text().splitlines()[1:])
assert len(nine)==8280
assert Counter(map(price,nine))=={2:540,3:1529,4:2590,5:2527,6:1085,7:9}
with TemporaryDirectory() as tmp:
 d=Path(tmp);subprocess.run(['c++','-O3','-std=c++20',root/'cut.cpp','-o',d/'cut'],check=True)
 (d/'sample').write_text(' '.join(map(str,[len(pos),len(neg),*sorted(pos),*sorted(neg)])))
 for cost in map(int,sys.argv[1:] or ['6']):
  points=gzip.decompress((root/f'points{cost}.gz').read_bytes())
  lines=[r for r in sorted(nine) if price(r)<=11-cost]
  assert len(points.splitlines())=={6:1431,7:6908}[cost]
  (d/'points').write_bytes(points);(d/'lines').write_text(''.join(' '.join(map(str,r))+'\n' for r in lines))
  res=subprocess.run([d/'cut',d/'sample',d/'points',d/'lines','0',str(len(points.splitlines()))],capture_output=True,text=True,check=True)
  print(cost,res.stderr.splitlines()[-1],flush=True);print(res.stdout,end='');assert not res.stdout
