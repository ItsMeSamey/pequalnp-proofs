from pathlib import Path
from itertools import combinations
import tempfile,sys,subprocess
given,exe,rows=map(Path,sys.argv[1:4]);raw=[1<<j for j in range(7)]
with tempfile.TemporaryDirectory() as t:
 d=Path(t)
 for b in (8,9):
  for e in (15,23,27,46,83):
   points=given/f'shared{b}BANK-{e}';lines=d/'lines'
   lab=[x for x in raw if x&e]
   lines.write_text(''.join(' '.join(map(str,[*raw,a|c,e^(a|c)]))+'\n' for a,c in combinations(lab,2) if a==lab[0]))
   z=subprocess.run([exe,rows,points,lines,'0','99999999'],capture_output=True,text=True,check=True)
   print(b,e,z.stderr.splitlines()[-1],flush=True)
   if z.stdout:
    banks=[tuple(map(int,q.split())) for q in points.read_text().splitlines()]
    ls=[tuple(map(int,q.split())) for q in lines.read_text().splitlines()]
    pn,nn,*orig=map(int,rows.read_text().split())
    cases=[]
    for r in z.stdout.splitlines():
     i,j=map(int,r.split());bs=banks[i];line=ls[j]
     def enc(x):
      return sum(bool((x&8191)&m)<<k for k,m in enumerate(bs)) | sum(bool((x>>13)&m)<<(13+k) for k,m in enumerate(line))
     cases.append(' '.join(map(str,[pn,nn,*map(enc,orig)])))
    result=subprocess.run([sys.argv[4],'13','9','1'],input='\n'.join(cases)+'\n',text=True,capture_output=True,check=True)
    answers=result.stdout.splitlines();assert len(answers)==len(cases) and all(q.startswith('0 ') for q in answers)
    print('exact',len(answers),'all zero',flush=True)
