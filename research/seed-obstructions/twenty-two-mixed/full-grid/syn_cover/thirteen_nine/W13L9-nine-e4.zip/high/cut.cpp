#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
using M=array<uint64_t,5>;
inline bool clash(const M&a,const M&b){return (a[0]&b[0])&&((a[1]&b[1])|(a[2]&b[2])|(a[3]&b[3])|(a[4]&b[4]));}
inline void add(M& a,const M&b){for(int k=0;k<5;k++)a[k]|=b[k];}
template<int W> struct Marked{array<int,W> v{},ids{};bool bad=false;};
struct Rel{int p,n;M mark;};
template<int W> vector<Marked<W>> readbank(const char*path,const vector<int>&pos,const vector<int>&neg,bool pt,map<M,int>&ids,vector<M>&table){
 map<pair<int,int>,M> rel;
 for(int i=0;i<28;i++)for(int j=0;j<245;j++)if(!(pt?((pos[i]&~neg[j])>>13):((pos[i]&~neg[j])&8191))){
  int p=pt?pos[i]&8191:pos[i]>>13,n=pt?neg[j]&8191:neg[j]>>13;
  auto& a=rel[{p,n}];a[0]|=uint64_t(1)<<i;a[1+j/64]|=uint64_t(1)<<(j%64);
 }
 vector<Rel> rows;for(auto&[k,m]:rel)rows.push_back({k.first,k.second,m});
 ifstream f(path);if(!f)abort();vector<Marked<W>> banks;Marked<W> bk;
 while(f>>bk.v[0]){
  for(int a=1;a<W;a++)if(!(f>>bk.v[a]))abort();
  array<M,W> m{};bk.bad=false;array<int,8192> proj{}; // masks 0..127 on the line side or 0..8191 on the point side
  if(pt){ // Point banks are few, and the negative point rows repeat.
   for(auto&r:rows)for(int i=0;i<W;i++){proj[r.p]|=bool(r.p&bk.v[i])<<i;proj[r.n]|=bool(r.n&bk.v[i])<<i;}
  }else{
   for(int k=0;k<128;k++)for(int i=0;i<W;i++)proj[k]|=bool(k&bk.v[i])<<i;
  }
  for(auto&r:rows){
   int d=proj[r.p]&~proj[r.n];
   if(!d){bk.bad=true;break;}
   if(has_single_bit((unsigned)d))add(m[countr_zero((unsigned)d)],r.mark);
  }
  
  for(int i=0;i<W;i++){auto[it,inserted]=ids.try_emplace(m[i],table.size());if(inserted)table.push_back(m[i]);bk.ids[i]=it->second;}
  banks.push_back(bk);
 }
 return banks;
}

#include <set>
struct Groups{array<int,22> a{},b{};int count=0;};
bool color(const int*adj,int n,Groups&out){
 unsigned live=(1u<<n)-1;
 while(live){
  unsigned a=live&-live,b=0,front=a;bool phase=false;
  while(front){
   unsigned next=0;
   for(unsigned v=front;v;v&=v-1)next|=adj[countr_zero(v)];
   if(next&(phase?b:a))return false;
   next&=~(a|b);
   if(phase)a|=next;else b|=next;
   front=next;phase=!phase;
  }
  out.a[out.count]=a;out.b[out.count++]=b;live&=~(a|b);
 }
 return true;
}
template<int W>struct Info{array<int,W> a{};Groups g; bool good;};
template<int W>Info<W> process(const Marked<W>&bank,const vector<M>&table){
 Info<W> r;r.good=!bank.bad;
 for(int i=0;i<W;i++)for(int j=0;j<i;j++)if(clash(table[bank.ids[i]],table[bank.ids[j]])){r.a[i]|=1<<j;r.a[j]|=1<<i;}
 r.good &=color(r.a.data(),W,r.g);return r;
}

using Bits=array<uint64_t,4>;
template<int W>struct Block{
 array<int,28> p{};array<Bits,1<<W> z{};
 Block(const Marked<W>&bk,const vector<int>&pos,const vector<int>&neg,bool point){
  array<Bits,W> truth{};for(int x=0;x<28;x++)for(int i=0;i<W;i++)
   p[x]|=bool(bk.v[i]&(point?pos[x]&8191:pos[x]>>13))<<i;
  for(int y=0;y<245;y++)for(int i=0;i<W;i++)if(bk.v[i]&(point?neg[y]&8191:neg[y]>>13))truth[i][y/64]|=uint64_t(1)<<(y%64);
  z[0].fill(~uint64_t(0)); z[0][3]=(uint64_t(1)<<(245-192))-1;
  for(int m=1;m<1<<W;m++)for(int b=0;b<4;b++)z[m][b]=z[m&(m-1)][b]&truth[countr_zero((unsigned)m)][b];
 }
};
// Row x can force the repeated Boolean output to one iff no outer feature
// distinguishes it from at least one negative. Each such negative forces zero.
bool partial(const Block<13>&p,const Block<9>&l,unsigned inner,unsigned outer){
 unsigned ip=inner&8191,il=inner>>13,op=outer&8191,ol=outer>>13;
 unsigned Q=0;Bits R{};
 for(int x=0;x<28;x++){
  auto&a=p.z[(8191^ip)&p.p[x]];auto&b=l.z[(511^il)&l.p[x]];uint64_t any=0;
  for(int k=0;k<4;k++){uint64_t t=a[k]&b[k];any|=t;R[k]|=t;}
  if(any)Q|=1u<<x;
 }
 while(Q){
  int x=countr_zero(Q);Q&=Q-1;
  auto&a=p.z[(8191^op)&p.p[x]];auto&b=l.z[(511^ol)&l.p[x]];
  if((a[0]&b[0]&R[0])|(a[1]&b[1]&R[1])|(a[2]&b[2]&R[2])|(a[3]&b[3]&R[3]))return false;
 }
 return true;
}
bool modpart(const Groups&g,const Block<13>&p,const Block<9>&l){
 array<int,22> ix;for(int i=0;i<g.count;i++)ix[i]=i;
 sort(ix.begin(),ix.begin()+g.count,[&](int x,int y){return popcount((unsigned)(g.a[x]|g.b[x]))>popcount((unsigned)(g.a[y]|g.b[y]));});
 auto dfs=[&](auto &self,int k,unsigned inner,unsigned outer)->bool{
  if(k==g.count && (!inner || ((inner&(inner-1)) && (!(inner&8191)||!(inner>>13)))))return false;
  if(k && !partial(p,l,inner,outer))return false;
  if(k==g.count)return true;
  int t=ix[k];
  return self(self,k+1,inner|g.a[t],outer|g.b[t]) || self(self,k+1,inner|g.b[t],outer|g.a[t]);
 };
 return dfs(dfs,0,0,0);
}
int main(int argc,char**av){
 ifstream f(av[1]);int pn,nn;f>>pn>>nn;vector<int> pos(pn),neg(nn);for(int&x:pos)f>>x;for(int&x:neg)f>>x;
 map<M,int> pids,lids;vector<M> pm,lm;
 auto pt=readbank<13>(av[2],pos,neg,true,pids,pm);auto ln=readbank<9>(av[3],pos,neg,false,lids,lm);
 vector<Info<9>> li;vector<Block<9>> lb;lb.reserve(ln.size());
 for(auto&l:ln){li.push_back(process(l,lm));lb.emplace_back(l,pos,neg,false);}
 uint64_t all=0,bip=0,pass=0;int index=-1,i,j;Info<13> pi;vector<int> link(lm.size());Block<13>*pb=nullptr;
 int start=stoi(av[4]),end=min((int)pt.size(),stoi(av[5]));
 vector<int> active;for(int t=0;t<(int)ln.size();t++){
   int raws[7]{};for(int y:ln[t].v)if(y && has_single_bit((unsigned)y))raws[countr_zero((unsigned)y)]++;
   bool missing=false;for(auto v:raws)if(!v)missing=true;
   auto counts=ln[t].v;int E=0;
   if(!missing){int seen=0;for(int y:counts){if(y&&has_single_bit((unsigned)y)&&!(seen&y))seen|=y;else E|=y;}}
   if(argc>6 && string(av[6])=="secondary" && (missing||popcount((unsigned)E)>=5))continue;
   active.push_back(t);
 }
 unsigned long long readouts=0;
 for(i=start;i<end;i++){
  if((i-start)%500==0)cerr<<"point "<<i<<" pairs "<<all<<" kept "<<pass<<endl;
  for(int t:active){j=t;
  if(i!=index){
   index=i;auto&v=pt[i];pi=process(v,pm);delete pb;pb=new Block<13>(v,pos,neg,true);
   for(int k=0;k<(int)lm.size();k++){
    int m=0;for(int t=0;t<13;t++)if(clash(pm[v.ids[t]],lm[k]))m|=1<<t;
    for(int t=0;t<pi.g.count;t++)if((m&pi.g.a[t])&&(m&pi.g.b[t])){m=-1;break;}link[k]=m;
   }
  }
  all++;if(!pi.good||!li[j].good)continue;
  int adj[22]{};copy(pi.a.begin(),pi.a.end(),adj);bool ok=true;
  for(int t=0;t<9;t++){
   int v=link[ln[j].ids[t]];if(v<0){ok=false;break;}adj[t+13]=(li[j].a[t]<<13)|v;
   for(;v;v&=v-1)adj[countr_zero((unsigned)v)]|=1<<(13+t);
  }
  Groups g;if(!ok||!color(adj,22,g))continue;bip++;
  if(modpart(g,*pb,lb[j])){cout<<i<<' '<<j<<'\n';pass++;}
 }
 }
 cerr<<"DONE "<<all<<" "<<bip<<" "<<pass<<endl;
}
