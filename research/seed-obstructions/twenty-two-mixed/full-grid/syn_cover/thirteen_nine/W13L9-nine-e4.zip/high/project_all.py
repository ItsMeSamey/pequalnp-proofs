from pathlib import Path
from itertools import combinations,combinations_with_replacement
import sys,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'certificate'))
from verify import pos,neg
raw=tuple(1<<j for j in range(7))
stars=[sum({r&8191 for r in pos if r>>(13+j)&1}) for j in range(7)]
assert len(stars)==7
models=Path(sys.argv[1]);exe=Path(sys.argv[2])
with tempfile.TemporaryDirectory() as td:
 d=Path(td);rows=d/'rows';rows.write_text(' '.join(map(str,[len(pos),len(neg),*sorted(pos),*sorted(neg)])))
 for l in models.read_text().splitlines():
  E,n,*b=map(int,l.split());assert n==len(b) and E.bit_count()==4
  selected=[*b,*[v for j,v in enumerate(stars) if not(E>>j&1)]]
  points=[tuple(sorted((*selected,*extra))) for extra in combinations_with_replacement(sorted({0,*selected}),13-len(selected))]
  lines=[]
  for a,c in combinations_with_replacement(range(128),2):
   if ((a|c)&~E):continue
   lines.append((*raw,a,c))
  for name,t in [('p',points),('l',lines)]:
   (d/name).write_text(''.join(' '.join(map(str,v))+'\n' for v in t))
  result=subprocess.run([exe,rows,d/'p',d/'l','0',str(len(points))],capture_output=True,text=True,check=True)
  print(E,len(points),len(lines),result.stderr.splitlines()[-1],flush=True)
  assert not result.stdout
