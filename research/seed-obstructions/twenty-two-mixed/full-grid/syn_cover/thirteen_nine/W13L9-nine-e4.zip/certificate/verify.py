"""Replay the W13,L10 read-once exclusion at total residual size 33."""
from collections import Counter
from itertools import combinations,combinations_with_replacement,permutations
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import numpy as np
from pysat.card import CardEnc
from pysat.solvers import Solver
from input import point_obligations,raw_samples
here=Path(__file__).resolve().parent
statement=here/'L-meta-18968.json'
pos,neg,_=raw_samples(statement)
raw,rows=point_obligations(statement)
stars=[sum({r&8191 for r in pos if r>>(13+j)&1}) for j in range(7)]
def image(mask,g):
    return sum(bool(mask&(1<<i))<<j for i,j in enumerate(g))
def group():
    labels=[sum(bool(t&(1<<p))<<j for j,t in enumerate(stars)) for p in range(13)]
    result=[]
    for g in permutations(range(7)):
        images=[image(a,g) for a in labels]
        if set(images)!=set(labels):continue
        p=[labels.index(a) for a in images]
        def row(x):return image(x&8191,p)|(image(x>>13,g)<<13)
        assert {row(x) for x in pos}==pos and {row(x) for x in neg}==neg
        result.append(p)
    assert len(result)==24
    granted=sorted({image(m,p) for p in result for m in raw})
    header=(here/'hereditary.hpp').read_text()
    values=list(map(int,header.split('int orbitraw[] = {')[1].split('}')[0].replace('\n','').split(',')))
    assert granted==values
    return result

def direct_costs():
    # For each possible set F of used nonsingleton raw masks, recover the
    # minimum number of distinct partner witnesses for each singleton p.
    primitive=[m for m in raw if m.bit_count()>1]
    assert len(primitive)==18
    subsets=np.arange(1<<18,dtype=np.int32)
    size=np.array([m.bit_count() for m in range(1<<18)],dtype=np.int16)
    per=np.empty((1<<18,13),dtype=np.int16)
    for j in range(13):
        p=1<<j
        ns=[n for x,n in rows if x==p]
        inc=[i for i,m in enumerate(primitive) if m&p]
        ix=np.zeros(1<<18,dtype=np.int16)
        for k,i in enumerate(inc):ix|=((subsets>>i)&1).astype(np.int16)<<k
        local=[]
        for selection in range(1<<len(inc)):
            used=[primitive[i] for k,i in enumerate(inc) if selection>>k&1]
            remaining=[n for n in ns if all(n&m for m in used)]
            if not remaining:local.append(0);continue
            bad=np.zeros(8192,dtype=bool);bad[remaining]=True
            for i in range(13):
                step=1<<i;v=bad.reshape(-1,2*step);v[:,:step]|=v[:,step:]
            choices=(~bad)&((np.arange(8192)&p)==0)
            local.append(int(size[:8192][choices].min()))
        per[:,j]=np.asarray(local)[ix]
    ordered=np.sort(per,axis=1)
    minima=[int((size+ordered[:,:13-s].sum(axis=1)).min()) for s in range(4)]
    assert minima==[28,25,22,19]
    return size,per,ordered

def point_representatives(cost,sym,arrays):
    size,per,ordered=arrays
    # An admissible S at size four, hence threshold cost+8.
    cap=cost+9
    keep=(size+ordered[:,:9].sum(axis=1))<=cap
    baseline=size[keep]+per[keep].sum(axis=1)
    allowed=set()
    for xs in combinations(range(13),4):
        w=baseline-per[keep][:,xs].sum(axis=1)
        if len(w) and w.min()<=cap:
            S=sum(1<<i for i in xs);allowed.update(image(S,p) for p in sym)
    out=[]
    for S in range(8192):
        if not 4<=S.bit_count()<=13 or (S.bit_count()==4 and S not in allowed):continue
        if S==min(image(S,p) for p in sym):out.append(S)
    return out

def lines():
    obligations={(p>>13,n>>13) for p in pos for n in neg if not ((p&8191)&~(n&8191))}
    contributions=[sum(bool(m&a and not m&b)<<i for i,(a,b) in enumerate(sorted(obligations))) for m in range(128)]
    full=(1<<len(obligations))-1
    def valid(selected):
        v=0
        for m in selected:v|=contributions[m]
        return v==full
    base=tuple(1<<i for i in range(7))
    three={base}
    for _ in range(3):
        three={tuple(sorted((*s,v))) for s in three for a,b in combinations_with_replacement(s,2) for v in (a|b,a&b)}
    assert len(three)==8275 and all(valid(b) for b in three)
    clauses=CardEnc.atmost(list(range(1,128)),10,top_id=127).clauses
    clauses.extend([[m for m in range(1,128) if m&a and not m&b] for a,b in obligations])
    minimal=[]
    with Solver(name='cadical195',bootstrap_with=clauses) as sol:
        while sol.solve():
            chosen=[m for m in sol.get_model() if 0<m<128]
            for m in list(chosen):
                reduced=[v for v in chosen if v!=m]
                if valid(reduced):chosen=reduced
            bank=tuple(sorted(chosen));minimal.append(bank)
            sol.add_clause([-x for x in bank])
    assert Counter(map(len,minimal))=={7:1,9:24,10:437}
    other=set()
    for b in minimal:
        if len(b)==9:other.update(tuple(sorted((*b,m))) for m in range(128))
        if len(b)==10:other.add(b)
    other={b for b in other if not set(base)<=set(b)}
    assert len(other)==3485
    return sorted(three),sorted(other),base

def write_banks(path,families):
    with path.open('w') as f:
        for b in families:print(*b,file=f)

def main():
    sym=group();arrays=direct_costs();three,other,rawlines=lines()
    with TemporaryDirectory() as tmp:
        work=Path(tmp)
        for width in (12,13):
            subprocess.run(['c++','-std=c++20','-O3','-march=native',f'-DPOINT_WIDTH={width}',str(here/'banks.cpp'),'-o',str(work/f'banks{width}')],check=True)
        subprocess.run(['c++','-std=c++20','-O3','-march=native',str(here/'compare.cpp'),'-o',str(work/'compare')],check=True)
        table=work/'samples'
        table.write_text(' '.join(map(str,[len(pos),len(neg),*sorted(pos),*sorted(neg)])))
        payload=str(len(rows))+'\n'+''.join(f'{p} {n}\n' for p,n in rows)
        write_banks(work/'three',three);write_banks(work/'other',other)
        write_banks(work/'ordinary',((*rawlines,*t) for t in combinations_with_replacement(range(128),3)))
        for cost in (7,8):
            reps=point_representatives(cost,sym,arrays)
            r=work/'reps'
            # Keep duplicate/zero signatures as twelve distinct nonzero masks with
            # one added slot. The singleton-domain gate count drops by one, while
            # the admissible S still comes from the original full-negative circuit.
            r.write_text(' '.join(map(str,reps)))
            dup=subprocess.run([work/'banks12',str(cost-1),r],input=payload,capture_output=True,text=True,check=True)
            families={tuple(map(int,q.split())) for q in dup.stdout.splitlines()}
            padded={tuple(sorted((*q,z))) for q in families for z in (0,*q)}
            assert (len(families),len(padded))=={7:(16,208),8:(90,1170)}[cost]
            print(cost,'padded boundary families',len(families),len(padded),flush=True)
            paths=[work/'padded'];write_banks(paths[0],sorted(padded))
            for size_s in range(4,14):
                r.write_text(' '.join(str(S) for S in reps if S.bit_count()==size_s))
                out=work/f'points-{size_s}'
                with out.open('w') as f:
                    z=subprocess.run([work/'banks13',str(cost),r],input=payload,stdout=f,stderr=subprocess.PIPE,text=True,check=True)
                expected={7:[5,88,23486,437377,2352,2514,502,49,7,1],8:[8415,51022,695833,1946972,5868,3410,524,49,7,1]}[cost][size_s-4]
                assert int(z.stderr.split()[-1])==expected
                print('singleton count',size_s,z.stderr.strip(),flush=True);paths.append(out)
            for name in (('other','ordinary') if cost==7 else ('three',)):
                z=subprocess.run([work/'compare',table,work/name,*paths],capture_output=True,text=True,check=True)
                print(z.stderr.splitlines()[-1],flush=True)
                assert not z.stdout and z.stderr.splitlines()[-1].endswith('survivors 0')
if __name__=='__main__':main()
