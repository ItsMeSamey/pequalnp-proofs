# Thirteen point inputs and ten line inputs at twenty-two mixed gates

The residual problem has a binary monotone separator budget of 33. A connected cone of 22 mixed gates on 23 distinct point/line boundary wires is a tree. The pure sides share at most eleven gates. The ten line positions need at least three paid gates. The two cases tested are therefore point cost at most seven against the unrestricted ten-wire line domain, and point cost at most eight against the three-gate line domain.

Run `python verify.py` with Python 3, NumPy, Python-SAT/CaDiCaL and a C++20 compiler. This regenerates the original statement's 28 positive and 245 maximal negative rows, all point and line candidates, and the joint conflict tests. The optional `python line_prices.py` computes the complete line-price histogram. The argument uses the established eleven-point nine-gate lower bound and the hereditary projective-star charge bound.

## Whole-negative raw source bound

The 1,323 point obligations pair a singleton positive p with a negative point set N whose raw line bits include the positive raw line. At least one point boundary signal accepts p and rejects the full N. Let S be the set of distinct selected singleton point signatures. Replace any selected wire whose singleton mask is raw by that raw primitive; the primitive is the OR of its singleton points and is pointwise below the old wire. Zero-signature internal values may be replaced by zero. Both operations preserve positive values, and negative values can only decrease.

Let F be the set of used or selected nonsingleton raw primitives. For each unselected raw p the direct-operand theorem in operand-count.md bounds the number of raw operand slots reading p by d(p,F). Remove obligations already distinguished by an F member, and take the smallest set of non-p witnesses not contained in any remaining negative. At least one such witness can be charged to each direct OR partner of p. A direct AND at p true on p is redundant, and an OR with a partner already true at p equals that partner. The implementation enumerates every F and computes these minima by downward closure of negative masks.

In a simplified cost-g program with h selected paid outputs and k selected raw masks, at most g+h operand slots can be raw. At least |F| minus (k minus |S|) consume nonsingleton raw signals. Summing over unselected p gives M(S)+|S|≤g+13, where M(S) is the minimum of |F| plus the sum of d(p,F). At |S|=0,1,2,3 the minima of M are 28,25,22,19, respectively. Thus at least four singleton coordinates are selected in both price cases. For exactly four, the thresholds are 16 and 17 at budgets seven and eight. All choices of five or more singletons are granted. The twenty-four sample symmetries allow canonicalizing S. The verifier includes every eligible raw S orbit and grants all 55 masks in the symmetry closure of the 31 raw primitives.

## Exhausting point signatures

For fixed S, its singletons handle the original obligations at those points. The other boundary masks are nonsingletons. The interval enumerator banks.cpp tracks each such mask by required and forbidden bits. An outstanding row needs a possible slot containing p and avoiding N. A unique possibility forces p and all the relevant exclusions. Rows with incompatible requirements must use different slots, so an initial clique anchors separate interchangeable slots. The rest can be sorted, and every undecided bit branch is explored both ways.

The established hereditary certificate bounds the cost of each partial bank on every subfamily J of the seven projective stars. Restrict the masks to the union of J. A necessarily paid output that becomes transversal, or duplicates another paid output on that union, saves its gate. The target stars in J can then be reconstructed: a clean k-point piece saves k minus one relative to three direct gates, and two complementary clean pairs or an exact intersection of two supersets save two. The known lower bound of three gates per retained star with all transversals free yields the lower bound from the total deletions and reconstruction savings. The header evaluates the 128 subfamilies simultaneously. Its interval cuts count only forced nonraw, distinct signals and guaranteed savings.

When all thirteen selected signatures are distinct and nonzero, use the thirteen-slot search directly. At most one position can be empty or repeat a signature: otherwise there would be eleven or fewer distinct nonzero point masks covering the original obligations at cost at most eight. In the exceptional position case, at least one paid gate of the original circuit has an empty or repeated signature, because all original raw primitives are distinct and nonzero. On the singleton domain that gate can be eliminated by zero propagation or substitution of its earlier equal signature. The remaining twelve masks cover the obligations at signature cost at most g minus one. This step uses only singleton behavior. The raw operand bound on S is still the original thirteen-slot, cost-g bound, which was obtained using the full negatives before substitution. Run banks.cpp at width twelve and budget g minus one with precisely those original admissible S representatives. Add either zero or a duplicate of any of the twelve remaining masks. This retains all formal mixed trees with repeated or empty point signatures.

## Ten line slots

A positive point contained in a negative point input requires a selected line mask containing its positive label and avoiding the negative labels. Cardinality-ten SAT enumeration regenerates the inclusion-minimal bases: one of size seven, 24 of size nine and 437 of size ten. Extending to ten wires including repetitions and zero yields 357,760 ordinary multisets containing all seven raw singleton labels, and 3,485 others. At point cost eight the line budget is three. Starting with the seven raw singletons and appending three unions or intersections yields 8,275 line multisets. The main proof includes all repeats and zero without imposing simplifications on the mixed graph.

The exact singleton-domain line prices, including the extra cost of redundant formal wires, are:

| Minimum paid gates | Ordinary | Other |
|---:|---:|---:|
| 3 | 8,275 | 0 |
| 4 | 37,415 | 960 |
| 5 | 89,915 | 1,308 |
| 6 | 121,051 | 881 |
| 7 | 82,859 | 288 |
| 8 | 18,245 | 48 |

For this subsidiary calculation, every selected zero, extra copy or duplicated raw signature costs one dispensable gate on top of the price of all distinct nonraw nonzero target masks. They can each be produced with one gate. Two raw labels with identical nonzero incidence across all target masks can be merged for a saving of exactly one gate: deleting one raw label and propagating zero suppresses at least one gate using it, whereas a single initial OR gives the reverse construction. Inactive source labels can be set to zero. Iterate this reduction after ignoring outputs that are now free raw singletons. An exact sorted-signature AND/OR synthesis query prices the reduced systems, allowing all acyclic orders and using the raw singleton parents. Numerical ordering of distinct masks determines the direction of a nontrivial union/intersection. The upper price is afforded by constructing each target directly from its raw points.

## Cross-side read-once obstruction

Lower every boundary signal to the OR of its singleton-mask bits. This preserves the positive assignments and can only decrease values on negatives. For any row pair where the other side's raw singleton-positive bits are contained in the raw negative, a unique distinguishing variable on this side must be sensitive at both rows. Indeed, lowering that variable at the positive gives a vector below the negative and raising it at the negative gives one above the positive.

For a variable i let its key set be the Cartesian product of its forced-sensitive positive rows and forced-sensitive negative rows. Two variables with an overlapping key demand both AND and OR at their least common ancestor. Thus a side with two overlapping variable key sets fails. Otherwise its key set is the union across its variables. An intersection between the point-side union and the line-side union also rules out the pair.

The checker indexes, for each key, the still-possible line banks it rules out. A key whose positive point is contained in its negative cannot occur on the point side and can be omitted. For each point bank it greedily intersects the eligible line indices with the complement of each present key's blocked indices. If the intersection becomes empty, the keys used are a certificate that any subsequent point bank containing them also fails. The cache checks presence of every key before reusing a certificate. If no cached certificate applies, the checker exhausts the full line index for that point bank. A surviving index is printed so that an inconclusive comparison cannot be counted as an exclusion.

## Exhaustive counts

| Point budget | Distinct nonzero thirteen-slot representatives | Padded representatives | Tested line multisets | Surviving pairs |
|---:|---:|---:|---:|---:|
| 7 | 466,381 | 208 | 361,245 | 0 |
| 8 | 2,712,101 | 1,170 | 8,275 | 0 |

The two domains cover 191,005,260,830 representative pairings. They overlap intentionally. They exclude every read-once P13/L10 separator at 22 mixed gates and total residual size at most 33.
