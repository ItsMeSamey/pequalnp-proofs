"""Rebuild the necessary point banks, quotient paired geometries, test three mixed surplus uses."""
from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys
import numpy as np
from point import direct_costs,group,image,rows,raw,pos,neg,stars
root=Path(__file__).resolve().parent
def write(out,items):
 with out.open('w')as f:
  for item in items:print(*item,file=f)
def check(command,**kw):
 return subprocess.run(command,check=True,**kw)
def split_rows(f):
 return [tuple(map(int,line.split()))for line in f.read_text().splitlines()]
def main():
 with TemporaryDirectory() as tmp:
  d=Path(tmp);gs=group();sym=[[image(m,g)for m in range(8192)]for g in gs];sz,per,ordered=direct_costs()
  snaps=Counter();keys=set()
  for n in range(3,13):
   cap=22-n;ix=sz+ordered[:,:13-n].sum(axis=1)<=cap;val=sz[ix]+per[ix].sum(axis=1);seen=set()
   for S in range(8192):
    if S.bit_count()!=n or S in seen:continue
    orbit={g[S]for g in sym};seen|=orbit
    if n<=5 and (not len(val) or min(int((val-per[ix][:,[i for i in range(13)if s>>i&1]].sum(axis=1)).min())for s in orbit)>cap):continue
    keys.add(S);snaps[n]+=1
  assert [snaps[n]for n in range(3,13)]==[3,17,45,106,106,81,51,25,9,3]
  write(d/'S',[sorted(keys)])
  (d/'rows').write_text(f'{len(pos)} {len(neg)}\n'+' '.join(map(str,sorted(pos)))+'\n'+' '.join(map(str,sorted(neg)))+'\n')
  (d/'cover').write_text(str(len(rows))+'\n'+''.join(f'{p} {n}\n'for p,n in rows))
  write(d/'rawsym',[sorted(x for x in raw if x.bit_count()>1),*sym])
  for target,src in [('wide','banks.cpp'),('pad','padded.cpp'),('ten','ten.cpp'),('price','priced.cpp'),('charge','charge.cpp'),('order','check-pair.cpp'),('strong','strong.cpp')]:
   check(['c++','-O3','-march=native','-std=c++20',root/src,'-o',d/target])
  tenS=[x for x in range(8192)if 3<=x.bit_count()<=10 and x==min(g[x]for g in sym)]
  write(d/'tenS',[tenS])
  with (d/'cover').open()as i:
   t=check([d/'ten','10',d/'tenS'],stdin=i,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
   assert not t.stdout
  for exe,output in [('wide','b12'),('pad','b11')]:
   with (d/'cover').open()as i,(d/output).open('w')as o:
    check([d/exe,'10',d/'S'],stdin=i,stdout=o,stderr=subprocess.DEVNULL)
  b11=split_rows(d/'b11')
  assert len(b11)==40
  check([sys.executable,root/'sources.py',d/'profiles','10','--selected','7','8','9','10'])
  assert not (d/'profiles/profiles-10-10').stat().st_size
  with (d/'b12').open()as i,(d/'priced').open('w')as o:
   check([d/'price',d/'rawsym',*[d/'profiles'/f'profiles-10-{n}'for n in (7,8,9)]],stdin=i,stdout=o)
  assert len(split_rows(d/'priced'))==65752
  with (d/'priced').open()as i,(d/'charged').open('w')as o:
   check([d/'charge',d/'cover'],stdin=i,stdout=o)
  charged=split_rows(d/'charged');assert len(charged)==13617
  padded={tuple(sorted((*b,m)))for b in b11 for m in(0,*b)}
  pads=sorted({min(tuple(sorted(f[x]for x in b))for f in sym)for b in padded});assert len(pads)==224
  line=[m for m in range(128)if m.bit_count()==2];write(d/'lines',[(1,2,4,8,16,32,64,m)for m in line])
  lg=[[stars.index(f[t])for t in stars]for f in sym]
  lineper=[[image(m,g)for m in line]for g in lg]
  for name,points,want in [('distinct',charged,270608),('padded',pads,3948)]:
   write(d/'points',points);pairs=[]
   for i,p in enumerate(points):
    st=[j for j,f in enumerate(sym)if tuple(sorted(f[x]for x in p))==p]
    pairs.extend((i,k)for k,m in enumerate(line)if m==min(lineper[j][k]for j in st))
   assert len(pairs)==want
   w=check([d/'order',d/'rows',d/'points',d/'lines','12','8','3','2000'],input=''.join(f'{i} {j}\n'for i,j in pairs),capture_output=True,text=True)
   print(name,w.stderr.splitlines()[-1],flush=True)
   z=check([d/'strong',d/'rows',d/'points',d/'lines'],input=w.stdout,capture_output=True,text=True)
   print(name,z.stderr.splitlines()[-1],flush=True)
   if z.stdout:print('Surviving projected pairs',z.stdout,flush=True);raise SystemExit(3)
if __name__=='__main__':main()
