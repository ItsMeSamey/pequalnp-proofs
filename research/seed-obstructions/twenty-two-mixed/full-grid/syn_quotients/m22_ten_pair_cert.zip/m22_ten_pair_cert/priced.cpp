#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include <vector>
#include <set>
using namespace std;
using U=uint32_t;using Key=uint64_t;using Bank=array<int,12>;
int sym[24][8192],rawid[8192],fro[18];const int ALL=8191;
struct Base{array<int,13> dominated{};int slack;int F,mandatory;};
unordered_map<Key,vector<Base>> groups;
int main(int argc,char** argv){
 ifstream in(argv[1]);for(int i=0;i<18;i++){in>>fro[i];rawid[fro[i]]=14+i;}
 for(int i=0;i<13;i++)rawid[1<<i]=i+1;for(auto&f:sym)for(int&x:f)in>>x;
 for(int k=2;k<argc;k++){ifstream pr(argv[k]);int h,S,t;while(pr>>h>>S>>t){
  Key key=S;int R=t;
  for(int i=0,m;i<t;i++){pr>>m;key|=Key(1)<<(rawid[m]-1);}
  int nf,F=0;pr>>nf;for(int i=0,m;i<nf;i++){pr>>m;F|=1<<(rawid[m]-14);}
  Base a;a.F=F;a.mandatory=0;a.slack=10+h-(nf-R);
  for(int p=0,d;p<13;p++){pr>>d;a.slack-=d;if(d)a.mandatory|=1<<p;
   int shared=ALL;for(int i=0;i<18;i++)if((F>>i&1)&&(fro[i]>>p&1))shared&=fro[i];
   a.dominated[p]=shared; }
  // The set of raw source masks available to all computed signatures is
  // all frozen F, the mandatory raw singletons, plus up to slack further singletons.
  groups[key].push_back(a);
 }}
 for(auto&[key,vs]:groups){
  sort(vs.begin(),vs.end(),[](auto&a,auto&b){return tuple{a.F,a.mandatory,-a.slack}<tuple{b.F,b.mandatory,-b.slack};});
  vs.erase(unique(vs.begin(),vs.end(),[](auto&a,auto&b){return a.F==b.F&&a.mandatory==b.mandatory;}),vs.end());
 }
 Bank b;set<Bank> out;long checked=0,kept=0;
 while(cin>>b[0]){for(int i=1;i<12;i++)cin>>b[i];checked++;bool possible=false;
  Bank canonical=b;for(auto&f:sym){Bank m{};for(int i=0;i<12;i++)m[i]=f[b[i]];sort(m.begin(),m.end());canonical=min(canonical,m);}
  if(out.count(canonical))continue;
  for(auto&f:sym){Key key=0;int selected=0,all=0;array<int,13> shared{};shared.fill(ALL);
   for(int v:b){int m=f[v];if(rawid[m]){key|=Key(1)<<(rawid[m]-1);continue;}
    selected++;all|=m;for(int a=m;a;a&=a-1)shared[countr_zero((U)a)]&=m;}
   if(selected<=6){possible=true;break;}
   auto it=groups.find(key);if(it==groups.end())continue;
   for(auto&base:it->second){
    int missing=0;for(int u=all&~base.mandatory;u;u&=u-1){int p=countr_zero((U)u);
     // A frozen class distinguishing p from every excluded y exists iff
     // all such y lie outside the intersection of frozen masks containing p.
     if(base.dominated[p]==ALL||(base.dominated[p]&~shared[p]))missing++;
    }
    if(missing<=base.slack){possible=true;break;}
   }if(possible)break;
  }
  if(possible){out.insert(canonical);kept++;}
 }
 for(auto&r:out){for(int x:r)cout<<x<<' ';cout<<'\n';}
 cerr<<"priced "<<checked<<" canonical "<<kept<<'\n';
}
