#include "charge.hpp"
#include <array>
#include <fstream>
#include <iostream>
using namespace std;
struct Row{int p,b;};
int main(int argc,char**argv){
 hereditary::setup();branch_charge::setup();
 ifstream in(argv[1]);int n;in>>n;vector<Row> rows(n);for(auto&r:rows)in>>r.p>>r.b;
 static array<uint64_t,21> table[8192];for(int x=0;x<8192;x++)for(int j=0;j<n;j++)if((x&rows[j].p)&&!(x&rows[j].b))table[x][j/64]|=uint64_t(1)<<(j%64);
 hereditary::Mask p;int done=0,live=0;
 while(cin>>p[0]){
  for(int i=1;i<12;i++)cin>>p[i];array<array<uint64_t,21>,12> can;for(int i=0;i<12;i++)can[i]=table[p[i]];
  done++;if(branch_charge::exclude(p,p,can,rows))continue;
  live++;for(int x:p)cout<<x<<' ';cout<<'\n';
 }
 cerr<<done<<' '<<live<<endl;
}
