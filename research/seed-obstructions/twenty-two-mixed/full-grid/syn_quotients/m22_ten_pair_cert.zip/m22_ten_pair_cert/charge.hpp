#ifndef BRANCH_CHARGE_HPP
#define BRANCH_CHARGE_HPP
#include "hereditary.hpp"
#include <algorithm>
#include <bit>
#include <vector>
namespace branch_charge {
using U=unsigned __int128;using hereditary::Mask;
U pairbits[8192];
int plane[13],owner[8192];
void setup(){
 for(int t=0;t<13;t++)for(int d:{0,1,3,9})plane[t]|=1<<((t+d)%13);
 for(int m=0;m<8192;m++){
    owner[m]=-1;
    if(std::popcount((unsigned)m)>=2)for(int i=0;i<13;i++)if(!(m&~plane[i]))owner[m]=i;
    int k=0;for(int i=0;i<13;i++)for(int j=0;j<i;j++,k++)if((m>>i&1)&&(m>>j&1))pairbits[m]|=U(1)<<k;
 }
}
template<class Masks,class Rows>bool exclude(const Mask&lo,const Mask&hi,const Masks&can,const Rows&rows){
 int ext[12],ne=0,other=0,grp[12],nc[7]{},full[7]{},npair[7]{};int ub=0;
 for(int i=0;i<12;i++){
    int pop=std::popcount((unsigned)lo[i]),t=owner[lo[i]];grp[i]=-1;
    if(pop<2)continue;
    if(t<0){ext[ne++]=i;continue;}
    if(hi[i]&~plane[t])continue;
    if(t<6){
      if(!(hereditary::subraw[hi[i]]&hereditary::superraw[lo[i]]))++other;
    }else{
      grp[i]=t-6;++nc[t-6];full[t-6]|=lo[i]==plane[t];npair[t-6]|=pop==2;
    }
 }
 ub=other+ne;
 for(int t=0;t<7;t++)if(nc[t])ub+=nc[t]+1+(full[t]&&nc[t]==1);
 if(ub<11)return false;
 U rejected[12]{};bool safe[12]{},sf4[7]{},sf3[7]{};
 for(int z=0;z<(int)can[0].size();z++){
    uint64_t any=0,multiple=0;for(int i=0;i<12;i++){multiple|=any&can[i][z];any|=can[i][z];}
    for(int i=0;i<12;i++)if(grp[i]>=0&&std::popcount((unsigned)lo[i])>=3){
      U need=pairbits[8191^plane[grp[i]+6]];
      if(!(need&~rejected[i]))continue;
      for(uint64_t x=can[i][z]&~multiple;x&&(need&~rejected[i]);x&=x-1)rejected[i]|=pairbits[rows[64*z+std::countr_zero(x)].b];
    }
 }
 int base=ne+other;
 for(int i=0;i<12;i++)if(grp[i]>=0&&std::popcount((unsigned)lo[i])>=3){
    int t=grp[i];safe[i]=!(pairbits[8191^plane[t+6]]&~rejected[i]);if(safe[i]){sf3[t]=true;sf4[t]|=lo[i]==plane[t+6];}
 }
 int minimum[7];for(int t=0;t<7;t++){minimum[t]=std::max(nc[t],sf3[t]?2:0);base+=minimum[t];}
 if(base>=11)return true;
 for(int h=ne;h<=ne+10-base;h++){
    int u=h-ne,cap=ne*u+u*(u-1)/2;
    auto compat=[&](int a,int b,int L,int H){return !(L&~(hi[a]&hi[b]))&&!((lo[a]&lo[b])&~H);};
    for(int a=0;a<ne;a++)for(int b=0;b<a;b++){
      bool ok=false;
      for(int i=0;i<12;i++)if(grp[i]>=0&&(!safe[i]||sf4[grp[i]])&&compat(ext[a],ext[b],lo[i],hi[i]))ok=true;
      cap+=ok;
    }
    int eligible=std::max(h-2,0);cap=std::min({cap,eligible*(eligible-1)/2,21});
    auto clique=[&](int L,int H,int k){
       if(u>=k)return true;
       for(int x=0;x<ne;x++){int a=ext[x];if(L&~hi[a])continue;if(u+1>=k)return true;
        for(int y=0;y<x;y++){int b=ext[y];if(!compat(a,b,L,H))continue;if(u+2>=k)return true;
         for(int z=0;z<y;z++)if(compat(ext[z],a,L,H)&&compat(ext[z],b,L,H))return true;
        }
       }return false;
    };
    int dp[22];std::fill(dp,dp+22,100);dp[0]=0;
    for(int t=0;t<7;t++){
     int nd[22];std::fill(nd,nd+22,100);
     for(int c=minimum[t];c<=std::max(minimum[t]+1,3);c++){
       int q=0;
       if(sf4[t]&&c==2){if(h<6||!clique(plane[t+6],plane[t+6],3))continue;q=3;}
       else if(c==nc[t]&&c&&!npair[t]){
          bool ok=false;for(int i=0;i<12;i++)if(grp[i]==t&&!safe[i]&&clique(lo[i],hi[i],2))ok=true;
          if(!ok)continue;q=1;
       }
       for(int x=0;x+q<=cap;x++)nd[x+q]=std::min(nd[x+q],dp[x]+c);
     }
     std::copy(nd,nd+22,dp);
    }
    if(other+h+*std::min_element(dp,dp+cap+1)<=10)return false;
 }
 return true;
}
}
#endif
