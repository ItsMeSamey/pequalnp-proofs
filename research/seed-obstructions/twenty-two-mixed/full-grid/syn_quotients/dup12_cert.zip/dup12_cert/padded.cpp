#include "hereditary11.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
constexpr int W=11,A=8191,K=21;
using Word=uint64_t;
using Bits=array<Word,K>;
using Masks=array<int,W>;
struct Row{int p,n;};
vector<Row> obligations;
vector<Bits> clash;
array<Bits,8192> positive{},negative{};
Bits full{};
int free_slots,anchors;
set<Masks> outputs;
uint64_t nodes;
void visit(Masks lo,Masks no){
 ++nodes;
 int split_slot=-1,split_bit=0;
 while(true){
  for(int i=anchors;i+1<free_slots;i++) if(lo[i]>(A^no[i+1]))return;
  Masks upper{};for(int i=0;i<W;i++)upper[i]=A^no[i];
  for(int i=0;i<free_slots;i++)if(popcount((unsigned)upper[i])<2)return;
  Bits sole[W]{};
  int chosen=-1,mincount=W+1;
  for(int z=0;z<K;z++){
   Word possible[W]{},all=0,multi=0,achieved=0;
   for(int i=0;i<free_slots;i++){
    possible[i]=full[z]&positive[upper[i]][z]&negative[lo[i]][z];
    multi|=all&possible[i];all|=possible[i];
    achieved|=full[z]&positive[lo[i]][z]&negative[upper[i]][z];
   }
   if(all!=full[z])return;
   Word open=full[z]&~achieved;
   for(int i=0;i<free_slots;i++)sole[i][z]=possible[i]&open&~multi;
   for(Word bits=open&multi;bits&&mincount>2;bits&=bits-1){
    int bit=countr_zero(bits),count=0;
    for(int i=0;i<free_slots&&count<mincount;i++)count+=(possible[i]>>bit)&1;
    if(count<mincount){mincount=count;chosen=64*z+bit;}
   }
  }
  bool changed=false;
  for(int i=0;i<free_slots;i++){
   int must=lo[i],ban=no[i];
   for(int z=0;z<K;z++)for(Word b=sole[i][z];b;b&=b-1){
    auto r=obligations[64*z+countr_zero(b)];must|=r.p;ban|=r.n;
   }
   if(must&ban)return;
   changed|=must!=lo[i]||ban!=no[i];lo[i]=must;no[i]=ban;
  }
  if(changed)continue;
  if(hereditary::bound(lo,upper))return;
  if(chosen>=0){
   auto r=obligations[chosen];
   for(int i=0;i<free_slots;i++)if(!(r.p&no[i])&&!(r.n&lo[i])){
    int unknown=(r.p|r.n)&~(lo[i]|no[i]);
    if(!unknown)abort();
    split_slot=i;split_bit=unknown&-unknown;break;
   }
  }else{
   for(int i=0;i<free_slots;i++){
    int unknown=A&~(lo[i]|no[i]);
    if(unknown){split_slot=i;split_bit=unknown&-unknown;break;}
   }
   if(split_slot<0){
    sort(lo.begin(),lo.end());
    if(adjacent_find(lo.begin(),lo.end())==lo.end())outputs.insert(lo);
    return;
   }
  }
  break;
 }
 if(split_slot<0||!split_bit)abort();
 Masks upper_branch=lo;upper_branch[split_slot]|=split_bit;
 visit(upper_branch,no);no[split_slot]|=split_bit;visit(lo,no);
}
void run(int S){
 Masks lo{},no{};free_slots=W-popcount((unsigned)S);int j=free_slots;
 for(int v=S;v;v&=v-1){int p=v&-v;lo[j]=p;no[j++]=A^p;}
 full.fill(0);for(int k=0;k<(int)obligations.size();k++)if(!(S&obligations[k].p))full[k/64]|=Word(1)<<(k%64);
 Bits remaining=full;anchors=0;
 while(true){
  int best=-1,degree=-1;
  for(int z=0;z<K;z++)for(Word b=remaining[z];b;b&=b-1){
   int k=64*z+countr_zero(b);int d=0;for(int q=0;q<K;q++)d+=popcount(remaining[q]&clash[k][q]);
   if(d>degree){degree=d;best=k;}
  }
  if(best<0)break;
  if(anchors>=free_slots)return;
  lo[anchors]=obligations[best].p;no[anchors++]=obligations[best].n;
  for(int z=0;z<K;z++)remaining[z]&=clash[best][z];
 }
 visit(lo,no);
}
int main(int argc,char**argv){
 if(argc!=3)return 2;
 hereditary::gate_budget=stoi(argv[1]);hereditary::setup();
 int count;cin>>count;if(count!=1323)return 3;
 for(int k=0;k<count;k++){
  Row r;cin>>r.p>>r.n;obligations.push_back(r);
  if(!has_single_bit((unsigned)r.p)||(r.p&r.n))abort();
  for(int m=0;m<=A;m++){
   if(m&r.p)positive[m][k/64]|=Word(1)<<(k%64);
   if(!(m&r.n))negative[m][k/64]|=Word(1)<<(k%64);
  }
 }
 clash.resize(count);
 for(int i=0;i<count;i++)for(int j=0;j<count;j++){
  auto x=obligations[i],y=obligations[j];
  if((x.p&y.n)||(y.p&x.n))clash[i][j/64]|=Word(1)<<(j%64);
 }
 ifstream reps(argv[2]);if(!reps)return 4;int S;
 while(reps>>S)if(3<=popcount((unsigned)S)&&popcount((unsigned)S)<=W){run(S);cerr<<"S "<<S<<" boards "<<outputs.size()<<" nodes "<<nodes<<endl;}
 for(const auto&b:outputs){for(int m:b)cout<<m<<' ';cout<<'\n';}
 cerr<<"budget "<<hereditary::gate_budget<<" nodes "<<nodes<<" distinct point banks "<<outputs.size()<<endl;
}
