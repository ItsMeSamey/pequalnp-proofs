"""Rebuild the necessary point banks, quotient paired geometries, test three mixed surplus uses."""
from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,sys
import numpy as np
from point import direct_costs,group,image,rows,raw,pos,neg,stars
root=Path(__file__).resolve().parent
def write(out,items):
 with out.open('w')as f:
  for item in items:print(*item,file=f)
def check(command,**kw):
 return subprocess.run(command,check=True,**kw)
def split_rows(f):
 return [tuple(map(int,line.split()))for line in f.read_text().splitlines()]
def main():
 with TemporaryDirectory() as tmp:
  d=Path(tmp);gs=group();sym=[[image(m,g)for m in range(8192)]for g in gs];sz,per,ordered=direct_costs()
  minima=[int((sz+ordered[:,:13-n].sum(axis=1)).min())for n in range(3)]
  assert minima==[28,25,22] and all(m>22-n for n,m in enumerate(minima))
  snaps=Counter();keys=set()
  for n in range(3,13):
   cap=22-n;ix=sz+ordered[:,:13-n].sum(axis=1)<=cap;val=sz[ix]+per[ix].sum(axis=1);seen=set()
   for S in range(8192):
    if S.bit_count()!=n or S in seen:continue
    orbit={g[S]for g in sym};seen|=orbit
    if n<=5 and (not len(val) or min(int((val-per[ix][:,[i for i in range(13)if s>>i&1]].sum(axis=1)).min())for s in orbit)>cap):continue
    keys.add(S);snaps[n]+=1
  assert [snaps[n]for n in range(3,13)]==[3,17,45,106,106,81,51,25,9,3]
  write(d/'S',[sorted(keys)])
  (d/'rows').write_text(f'{len(pos)} {len(neg)}\n'+' '.join(map(str,sorted(pos)))+'\n'+' '.join(map(str,sorted(neg)))+'\n')
  (d/'cover').write_text(str(len(rows))+'\n'+''.join(f'{p} {n}\n'for p,n in rows))
  write(d/'rawsym',[sorted(x for x in raw if x.bit_count()>1),*sym])
  for target,src in [('wide','banks.cpp'),('pad','padded.cpp'),('ten','ten.cpp'),('order','check-pair.cpp'),('strong','strong.cpp')]:
   check(['c++','-O3','-march=native','-std=c++20',root/src,'-o',d/target])
  tenS=[x for x in range(8192)if 3<=x.bit_count()<=10 and x==min(g[x]for g in sym)]
  write(d/'tenS',[tenS])
  with (d/'cover').open()as i:
   t=check([d/'ten','10',d/'tenS'],stdin=i,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
   assert not t.stdout
  from gzip import decompress
  from zipfile import ZipFile
  from io import BytesIO
  from hashlib import sha256
  with (d/'cover').open() as src:
   assert not check([d/'pad','8',d/'S'],stdin=src,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL).stdout
  def canonical(b):return min(tuple(sorted(f[m]for m in b))for f in sym)
  def parse(t):return [tuple(map(int,r.split()))for r in t.splitlines()]
  with ZipFile(root/'dependencies/m22_w12nine_cert.zip')as a:
   named=next(n for n in a.namelist()if n.endswith('dependencies/twelve-eight.zip'))
   with ZipFile(BytesIO(a.read(named)))as catalog:
    physical=parse(catalog.read('twelve-eight/banks-through-eight.txt').decode())
  actual={}
  for row in physical:
   k=canonical(row[:-1]);actual[k]=min(actual.get(k,100),row[-1])
  assert Counter(actual.values())=={5:2,6:5,7:25,8:119}
  data=decompress((root/'broad9.gz').read_bytes())
  assert sha256(data).hexdigest()=='80a542ce50d098efca9b53114740262312e5e06a7863e398a2b946f3286e5151'
  broad=set(parse(data.decode()));assert len(broad)==9268
  for g,nraw,norbit in ((7,16,7),(8,90,32),(9,450,165)):
   with (d/'cover').open() as src:
    res=check([d/'wide',str(g-1),d/'S'],stdin=src,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
   banks=parse(res.stdout);assert len(banks)==nraw
   norm={canonical(b)for b in banks};assert len(norm)==norbit
   known={p for p,c in actual.items()if c<=g}
   if g<9:assert norm<=known
   else:
    assert norm<=broad
    extra=sorted(norm-known)
    assert len(extra)==14 and extra==split_rows(root/'extra')
   print('Original paid point gates',g,'raw banks',nraw,'sample orbits',norbit,flush=True)
  write(d/'extra',extra)
  write(d/'lines',[(1,2,4,8,16,32,64,m)for m in range(128)])
  packets=''.join(f'{i} {j}\n'for i in range(14)for j in range(128)if j.bit_count()<=3)
  z=check([d/'order',d/'rows',d/'extra',d/'lines','12','8','3','2000'],input=packets,capture_output=True,text=True)
  assert z.stderr.splitlines()[-1]=='DONE 896 28 0'
  y=check([d/'strong',d/'rows',d/'extra',d/'lines'],input=z.stdout,capture_output=True,text=True)
  assert not y.stdout and y.stderr.splitlines()[-1]=='DONE 28 0'
  print(z.stderr,y.stderr,sep='',end='')
if __name__=='__main__':main()
