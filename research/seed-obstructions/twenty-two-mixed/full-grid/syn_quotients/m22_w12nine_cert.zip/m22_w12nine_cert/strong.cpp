#include "exacttree.hpp"
#include <string>

using namespace std;
template<size_t W>
vector<array<int,W>> read_banks(const char* path) {
    ifstream input(path);
    vector<array<int,W>> banks;
    array<int,W> row;
    while(input >> row[0]) {
        for(size_t i=1;i<W;i++) if(!(input >> row[i])) abort();
        banks.push_back(row);
    }
    return banks;
}
template<size_t W>
int evaluate(const array<int,W>& masks, int x) {
    int result=0;
    for(size_t i=0;i<W;i++) if(masks[i]&x) result |= 1<<i;
    return result;
}
int main(int argc,char** argv) {
    if(argc<4)return 1;
    ifstream data(argv[1]); int np,nn; data>>np>>nn;
    if(np!=28||nn!=245)abort();
    vector<int> pos(np),neg(nn);
    for(auto& x:pos)data>>x;
    for(auto& x:neg)data>>x;
    auto points=read_banks<12>(argv[2]);
    auto lines=read_banks<9>(argv[3]);
    uint64_t checked=0,surviving=0;vector<vector<int>> pl,nl;
    for(auto&l:lines){vector<int>a,b;
     for(int x:pos){int y=evaluate(l,x>>13);a.push_back((y&127)|((y>>7)<<19));}
     for(int x:neg){int y=evaluate(l,x>>13);b.push_back((y&127)|((y>>7)<<19));}pl.push_back(a);nl.push_back(b);}
    int i,j,last=-1; vector<int> pp,pn;
    while(cin>>i>>j){if(i!=last){pp.clear();pn.clear();for(int x:pos)pp.push_back(evaluate(points.at(i),x&8191)<<7);for(int x:neg)pn.push_back(evaluate(points.at(i),x&8191)<<7);last=i;}
    {vector<int>P=pp,N=pn;for(int k=0;k<(int)P.size();k++)P[k]|=pl[j][k];for(int k=0;k<(int)N.size();k++)N[k]|=nl[j][k];
        frontierlib::Search s;
        if(s.treecut(P,N,21)){cout<<i<<' '<<j<<endl;surviving++;}
        checked++;
        if(checked%1000==0)cerr<<checked<<" checked "<<surviving<<" surviving"<<endl;
    }
    }
    cerr<<"DONE "<<checked<<" "<<surviving<<endl;
}
