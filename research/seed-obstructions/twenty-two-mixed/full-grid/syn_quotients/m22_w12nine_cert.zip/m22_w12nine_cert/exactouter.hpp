#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace outerlib {
using namespace std;
using Bits=uint64_t;
using Signature=array<Bits,6>; // positives, up to 245 negatives, ancestry side
using Family=array<int,12>;
using Frontier=array<int,24>; // zero entries are padding
template<class T> struct ArrayHash {
    size_t operator()(const T& values)const{
        size_t h=0x9e3779b97f4a7c15ULL;
        for(auto v:values){h^=v+0x9e3779b97f4a7c15ULL+(h<<6)+(h>>2);}
        return h;
    }
};
using States=unordered_set<Frontier,ArrayHash<Frontier>>;
struct Wire{
    Signature value;
    // For each positive row, mask of the negatives distinguished by this wire.
    vector<Bits> separates;
};
static bool colorable(const array<int,24>&adj,int size,int colors){
    // Peel vertices of degree < colors: they always extend a coloring.
    unsigned live=(1u<<size)-1;
    for(bool changed=true;changed;){
        changed=false;
        for(unsigned a=live;a;a&=a-1){
            int v=__builtin_ctz(a);
            if(__builtin_popcount(live&adj[v])<colors){live^=1u<<v;changed=true;}
        }
    }
    if(!live)return true;
    array<unsigned,24> color{};
    auto solve=[&](auto&&rec,unsigned left,unsigned used)->bool{
        if(!left)return true;
        int best=-1,score=-1;unsigned banned=0;
        for(unsigned a=left;a;a&=a-1){
            int v=__builtin_ctz(a);unsigned taken=0;
            for(unsigned b=adj[v]&live&~left;b;b&=b-1)taken|=color[__builtin_ctz(b)];
            int priority=32*__builtin_popcount(taken)+__builtin_popcount(adj[v]&left);
            if(priority>score){score=priority;best=v;banned=taken;}
        }
        unsigned allowed=((1u<<colors)-1)&~banned;
        for(unsigned options=allowed;options;options&=options-1){
            unsigned c=options&-options;color[best]=c;
            if(rec(rec,left^(1u<<best),used|c))return true;
            if(!(c&used))break;
        }
        return false;
    };
    return solve(solve,live,0);
}
struct Search{
    int count_pos, count_neg, blocks;
    vector<Wire> wires{{}};
    unordered_map<Signature,int,ArrayHash<Signature>> ids;
    unordered_map<uint64_t,int> joins;

    int intern(Signature sig){
        auto [entry,created]=ids.emplace(sig,wires.size());
        if(!created)return entry->second;
        Wire wire{sig,vector<Bits>(count_pos*blocks)};
        for(int p=0;p<count_pos;p++)if(sig[0]>>p&1){
            for(int b=0;b<blocks;b++)wire.separates[p*blocks+b]=~sig[b+1];
        }
        wires.push_back(move(wire));
        return entry->second;
    }
    int combine(int a,int b,int op){
        auto key=(uint64_t(a)<<33)|(uint64_t(b)<<1)|op;
        auto it=joins.find(key);
        if(it!=joins.end())return it->second;
        Signature s{};
        for(int k=0;k<=blocks;k++)s[k]=op? wires[a].value[k]|wires[b].value[k] : wires[a].value[k]&wires[b].value[k];
        s[5]=2;
        return joins[key]=intern(s);
    }
    bool may_read_once(const Frontier&state,int size){
        // Only obligations uniquely distinguished by one consumed wire can be
        // lost, because either operation preserves an obligation distinguished
        // by both operands. Store the two projections of these private pairs.
        array<Signature,24> need{};
        for(int p=0;p<count_pos;p++)for(int b=0;b<blocks;b++){
            Bits once=0,twice=0,d[24];
            for(int i=0;i<size;i++){
                d[i]=wires[state[i]].separates[p*blocks+b];
                twice|=once&d[i];once|=d[i];
            }
            Bits valid=(b+1<blocks||count_neg%64==0)?~Bits(0):((Bits(1)<<(count_neg%64))-1);
            Bits single=once&~twice&valid;
            if(!single)continue;
            for(int i=0;i<size;i++)if(Bits x=single&d[i]){
                need[i][0]|=Bits(1)<<p;need[i][1+b]|=x;
            }
        }
        for(int i=0;i<size;i++)for(int j=i+1;j<size;j++){
            if(!(need[i][0]&need[j][0]))continue;
            for(int b=1;b<=blocks;b++)if(need[i][b]&need[j][b])return false;
        }
        return true;
    }
    bool one_cut(const Frontier&state,int size){
        using U=uint32_t; using Neg=array<uint64_t,4>;
        U all=(1u<<size)-1,point=0,line=0;
        array<U,64> pos{};array<Neg,24> truth{};
        for(int i=0;i<size;i++){auto&v=wires[state[i]].value;
            for(Bits q=v[0];q;q&=q-1)pos[__builtin_ctzll(q)]|=1u<<i;
            for(int k=0;k<blocks;k++)truth[i][k]=v[k+1];
            if(v[5]==1)point|=1u<<i;else if(v[5]==0)line|=1u<<i;
        }
        array<array<Neg,16>,6> lut{};int groups=(size+3)/4;
        for(int g=0;g<groups;g++){
            for(int b=0;b<blocks;b++)lut[g][0][b]=(b+1<blocks||count_neg%64==0)?~Bits(0):(Bits(1)<<(count_neg%64))-1;
            for(int t=1;t<(1<<min(4,size-4*g));t++)
                for(int b=0;b<blocks;b++)lut[g][t][b]=lut[g][t&(t-1)][b]&truth[4*g+__builtin_ctz(t)][b];
        }
        auto zero=[&](U mask){Neg r=lut[0][mask&15];for(int g=1;g<groups;g++){auto&a=lut[g][(mask>>(4*g))&15];for(int b=0;b<blocks;b++)r[b]&=a[b];}return r;};
        auto partial=[&](U one,U other){
            Bits forced=0;Neg neg{};
            for(int x=0;x<count_pos;x++){auto v=zero(pos[x]&(all^one));Bits any=0;for(int b=0;b<blocks;b++){neg[b]|=v[b];any|=v[b];}if(any)forced|=Bits(1)<<x;}
            for(Bits q=forced;q;q&=q-1){auto v=zero(pos[__builtin_ctzll(q)]&(all^other));for(int b=0;b<blocks;b++)if(v[b]&neg[b])return false;}
            return true;
        };
        array<Signature,24> mark{};
        for(int x=0;x<count_pos;x++)for(U q=pos[x];q;q&=q-1){
            int i=__builtin_ctz(q);auto v=zero(pos[x]^(1u<<i));Bits any=0;
            for(int b=0;b<blocks;b++){Bits a=v[b]&~truth[i][b];any|=a;mark[i][b+1]|=a;}if(any)mark[i][0]|=Bits(1)<<x;
        }
        array<U,24> adj{};
        for(int i=0;i<size;i++)for(int j=0;j<i;j++)if(mark[i][0]&mark[j][0]){
            for(int b=0;b<blocks;b++)if(mark[i][b+1]&mark[j][b+1]){adj[i]|=1u<<j;adj[j]|=1u<<i;break;}
        }
        array<pair<U,U>,24> comps{};int n=0;U live=all;
        while(live){U a=live&-live,b=0,front=a;bool rev=false;
            while(front){U next=0;for(U z=front;z;z&=z-1)next|=adj[__builtin_ctz(z)];if(next&(rev?b:a))return false;next&=~(a|b);if(rev)a|=next;else b|=next;front=next;rev=!rev;}
            comps[n++]={a,b};live&=~(a|b);
        }
        // In the absence of any conflicting pair this necessary test can be skipped.
        if(n==size)return true;
        sort(comps.begin(),comps.begin()+n,[](auto a,auto b){return __builtin_popcount(a.first|a.second)>__builtin_popcount(b.first|b.second);});
        auto rec=[&](auto&self,int i,U one,U other)->bool{
            if(i==n && (!one||((one&(one-1))&&((one&point)==one||(one&line)==one))))return false;
            if(i&&!partial(one,other))return false;if(i==n)return true;
            auto [a,b]=comps[i];return self(self,i+1,one|a,other|b)||self(self,i+1,one|b,other|a);
        };
        return rec(rec,0,0,0);
    }
    void next(const Frontier&state,int size,States&ordinary,States*copied,States*doublecopy,int remaining){
        // Only obligations uniquely distinguished by one consumed wire can be
        // lost, because either operation preserves an obligation distinguished
        // by both operands. Store the two projections of these private pairs.
        array<Signature,24> need{};
        for(int p=0;p<count_pos;p++)for(int b=0;b<blocks;b++){
            Bits once=0,twice=0,d[24];
            for(int i=0;i<size;i++){
                d[i]=wires[state[i]].separates[p*blocks+b];
                twice|=once&d[i];once|=d[i];
            }
            Bits valid=(b+1<blocks||count_neg%64==0)?~Bits(0):((Bits(1)<<(count_neg%64))-1);
            Bits single=once&~twice&valid;
            if(!single)continue;
            for(int i=0;i<size;i++)if(Bits x=single&d[i]){
                need[i][0]|=Bits(1)<<p;need[i][1+b]|=x;
            }
        }
        // Once no further use can be retained the remainder is read-once.
        // On each positive a private obligation forces its wire into every
        // accepting minterm; on each negative it lies in every rejecting
        // maxterm. A read-once minterm and maxterm intersect once.
        array<int,24> adj{},degree{};int edges=0;
        for(int i=0;i<size;i++)for(int j=i+1;j<size;j++){
            if(!(need[i][0]&need[j][0]))continue;
            bool conflict=false;
            for(int b=1;b<=blocks;b++)if(need[i][b]&need[j][b]){conflict=true;break;}
            if(conflict){adj[i]|=1u<<j;adj[j]|=1u<<i;degree[i]++;degree[j]++;edges++;}
        }
        if(edges&&!colorable(adj,size,remaining+1))return;
        for(int i=0;i<size;i++)for(int j=i+1;j<size;j++){
            int a=state[i],b=state[j];
            auto av=wires[a].value,bv=wires[b].value;
            if(av[5]==bv[5]&&av[5]!=2)continue;
            for(int op=0;op<2;op++){
                // Both operands distinguish every obligation in need[i][j];
                // either AND or OR still distinguishes those obligations.
                // At need[i], a already separates; b must take the right
                // value at the positive (AND) or the negative (OR).
                bool unsafeA=false,unsafeB=false;
                if(!op){
                    unsafeA=need[i][0]&~bv[0];
                    unsafeB=need[j][0]&~av[0];
                }else{
                    for(int k=1;k<=blocks;k++){
                        unsafeA|=bool(need[i][k]&bv[k]);
                        unsafeB|=bool(need[j][k]&av[k]);
                    }
                }
                if(!doublecopy&&(unsafeA||unsafeB)&&(!copied||(unsafeA&&unsafeB)))continue;
                int h=combine(a,b,op);
                auto push=[&](States& out,int keep){
                    Frontier n{};int t=0;
                    for(int k=0;k<size;k++)if((k!=i&&k!=j)||k==keep||keep==-2)n[t++]=state[k];
                    n[t++]=h;sort(n.begin(),n.begin()+t);out.insert(n);
                };
                if(!unsafeA&&!unsafeB)push(ordinary,-1);
                if(copied&&!unsafeB&&(remaining!=1||degree[i]==edges))push(*copied,i);
                if(copied&&!unsafeA&&(remaining!=1||degree[j]==edges))push(*copied,j);
                if(doublecopy&&(remaining!=2||degree[i]+degree[j]-((adj[i]>>j)&1)==edges))push(*doublecopy,-2);
            }
        }
    }
    bool continuation(const vector<Signature>& signals,int np,int nn){
        int nleaves=signals.size(),budget=1;
        count_pos=np;count_neg=nn;blocks=(nn+63)/64;
        Frontier orig{};
        for(int i=0;i<nleaves;i++)orig[i]=intern(signals[i]);
        for(int p=0;p<np;p++)for(int b=0;b<blocks;b++){
            Bits sep=0,full=(b+1<blocks||nn%64==0)?~Bits(0):((Bits(1)<<(nn%64))-1);
            for(int i=0;i<nleaves;i++)sep|=wires[orig[i]].separates[p*blocks+b];
            if((sep&full)!=full)return false;
        }
        sort(orig.begin(),orig.begin()+nleaves);
        vector<States> states(budget+1);states[0].insert(orig);
        for(int gate=1;gate<=nleaves-1+budget;gate++){
            vector<States> following(budget+1);size_t next_cleanup=100000;
            for(int u=0;u<=budget;u++)for(auto&s:states[u]){
                next(s,nleaves-(gate-1)+u,following[u],u<budget?&following[u+1]:nullptr,u+2<=budget?&following[u+2]:nullptr,budget-u);
                if(following[budget].size()>next_cleanup){
                    auto& group=following[budget];
                    for(auto it=group.begin();it!=group.end();){
                        if(may_read_once(*it,nleaves-gate+budget))++it;
                        else it=group.erase(it);
                    }
                    next_cleanup=max<size_t>(100000,2*group.size()+1);
                }
            }
            if(budget>=1){
                auto& one=following[budget-1];
                for(auto it=one.begin();it!=one.end();){
                    if(one_cut(*it,nleaves-gate+budget-1))++it;else it=one.erase(it);
                }
            }
            if(all_of(following.begin(),following.end(),[](const States&x){return x.empty();}))return false;
            states.swap(following);
        }
        return !states[budget].empty();
    }
};
}
