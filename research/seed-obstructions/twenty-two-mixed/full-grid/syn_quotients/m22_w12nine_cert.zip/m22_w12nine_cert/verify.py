from pathlib import Path
from collections import Counter
from itertools import combinations_with_replacement
import sys
root=Path(__file__).resolve().parent
from inputs import P,N,stars
from samples import actions
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZipFile
temp=TemporaryDirectory()
work=Path(temp.name)
source=ZipFile(root/'dependencies/twelve-eight.zip')
def source_rows(f):return source.read('twelve-eight/'+f).decode().splitlines()
fs=actions(P,N)
lg=[tuple(stars.index(f[x])for x in stars)for f in fs]
lf=[tuple(sum((q>>i&1)<<j for i,j in enumerate(g))for q in range(128))for g in lg]
table={}
for row in source_rows('banks-through-eight.txt'):
 *p,c=map(int,row.split());key=min(tuple(sorted(f[m]for m in p))for f in fs)
 table[key]=min(c,table.get(key,100))
assert Counter(table.values())=={5:2,6:5,7:25,8:119}
ps=sorted(table,key=lambda p:(table[p],p))
def write(file,rows):file.write_text(''.join(' '.join(map(str,r))+'\n'for r in rows))
write(work/'points', ps)
ordinary=tuple(1<<i for i in range(7));line={}
for a,b in combinations_with_replacement(range(128),2):
 c=((a|b).bit_count()-1)if a&b else max(a.bit_count()-1,0)+max(b.bit_count()-1,0)
 l=tuple(sorted((*ordinary,a,b)));line[l]=c
for t in (source_rows('exceptional-nine.txt')):
 line[tuple(map(int,t.split()))]=3
assert len(line)==8280
assert Counter(line.values())=={0:36,1:189,2:630,3:1529,4:2464,5:2401,6:1031}
ls=sorted(line);write(work/'lines',ls)
print('point prices',Counter(table.values()),'line prices',Counter(line.values()),flush=True)
cache={}
(work/'rows').write_text(f'{len(P)} {len(N)}\n'+' '.join(map(str,sorted(P)))+'\n'+' '.join(map(str,sorted(N)))+'\n')
def compile_program(exe):
 subprocess.run(['c++','-O3','-march=native','-std=c++20',root/(exe+'.cpp'),'-o',work/exe],check=True)
compile_program('check')
for c in range(5,9):
 pairs=[]
 for i,p in enumerate(ps):
  if table[p]!=c:continue
  stab=tuple(j for j,f in enumerate(fs)if tuple(sorted(f[m]for m in p))==p)
  if (c,stab) not in cache:
   cache[c,stab]=[k for k,l in enumerate(ls)if line[l]<=11-c and l==min(tuple(sorted(lf[j][x]for x in l))for j in stab)]
  pairs.extend((i,k)for k in cache[c,stab])
 if sys.argv[1:] and str(c) not in sys.argv[1:]:continue
 assert len(pairs)=={5:2818,6:17598,7:83843,8:233892}[c]
 data=''.join(f'{i} {j}\n'for i,j in pairs)
 weak=subprocess.run([work/'check',work/'rows',work/'points',work/'lines'],input=data,text=True,capture_output=True,check=True)
 print('cost',c,'cut',weak.stderr.splitlines()[-1],flush=True)
 assert weak.stderr.splitlines()[-1]==f'DONE {len(pairs)} {len(weak.stdout.splitlines())}'
 if not weak.stdout:continue
 if not (work/'strong').exists():compile_program('strong')
 strong=subprocess.run([work/'strong',work/'rows',work/'points',work/'lines'],input=weak.stdout,text=True,capture_output=True,check=True)
 print('cost',c,'frontier',strong.stderr.splitlines()[-1],flush=True)
 assert not strong.stdout
