"""Replay exact three-surplus search for all materialized terminal survivors."""
from pathlib import Path
from tempfile import TemporaryDirectory
from subprocess import run
import sys
root=Path(__file__).resolve().parent
with TemporaryDirectory() as tmp:
    d=Path(tmp)
    run(['c++','-std=c++20','-O3','-march=native',root/'strong.cpp','-o',d/'exact'],check=True)
    rows=[list(map(int,x.split())) for x in (root/'cases.txt').read_text().splitlines()]
    assert all(len(r)==22 for r in rows) and len({tuple(r[:2])for r in rows})==len(rows)
    for name,start,stop in [('point',2,14),('line',14,22)]:
        (d/name).write_text(''.join(' '.join(map(str,r[start:stop]))+'\n' for r in rows))
    job=run([d/'exact',root/'samples',d/'point',d/'line'],input=''.join(f'{j} {j}\n'for j in range(len(rows))),text=True,capture_output=True,check=True)
    print(job.stderr,end='')
    if job.stdout or job.stderr.splitlines()[-1]!=f'DONE {len(rows)} 0':sys.exit(2)
    run(['c++','-std=c++20','-O3','-march=native',root/'endpoint_multi.cpp','-o',d/'secondary'],check=True)
    raw=list(map(int,(root/'samples').read_text().split()))
    packets=[]
    for r in rows:
        packets.extend(raw[:2])
        masks=r[2:14]+[q<<13 for q in r[14:22]]
        packets.extend(sum(1<<j for j,m in enumerate(masks) if m&v) for v in raw[2:])
    check=run([d/'secondary','12','8','3'],input=' '.join(map(str,packets)),capture_output=True,text=True,check=True)
    assert len(check.stdout.splitlines())==len(rows) and all(line.startswith('0 ') for line in check.stdout.splitlines())
    print('Independent endpoint excluded',len(rows))
