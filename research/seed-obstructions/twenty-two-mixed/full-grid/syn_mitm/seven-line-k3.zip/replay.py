from pathlib import Path
from tempfile import TemporaryDirectory
from subprocess import run,PIPE
import sys
here=Path(__file__).resolve().parent
for name in ('promoted.py','width.py','geometry.py','pair5.py'):
 run([sys.executable,str(here/name)],check=True)
with TemporaryDirectory() as tmp:
 exe=Path(tmp)/'tight'
 run(['g++','-O3','-std=c++17',str(here/'tighter.cpp'),'-o',str(exe)],check=True)
 result=run([str(exe)],text=True,stdout=PIPE,check=True)
 print(result.stdout,end='')
 rows=[list(map(int,l.split())) for l in result.stdout.splitlines()]
 assert rows==[[0,0,0,0],[1,0,0,0],[2,1,1,0],[3,36,156,0],[4,2502,29595,0]]
