from collections import Counter
from samples import lines as stars,neg
assert all(s.bit_count()==4 for s in stars)
hist=Counter()
for t,T in enumerate(stars):
    for u,U in enumerate(stars):
        if t==u:continue
        opposite=[j for j in range(13) if (U&~T)>>j&1]
        assert len(opposite)==3
        ordinary=[V for i,V in enumerate(stars) if i not in (t,u)]
        for p in range(13):
            if T>>p&1:continue
            candidates=[q for q,l in neg if (l>>t&1) and (q>>p&1) and all(q&V for V in ordinary)]
            number=sum(any(q>>marker&1 for q in candidates) for marker in opposite)
            assert number>=2
            hist[number]+=1
assert hist=={2:96,3:282}
print('Available opposite markers',dict(sorted(hist.items())))
