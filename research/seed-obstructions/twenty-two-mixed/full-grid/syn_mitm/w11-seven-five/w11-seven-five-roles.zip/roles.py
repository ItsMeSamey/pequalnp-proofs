from pathlib import Path
from itertools import combinations
from collections import Counter
import sys,json
here=Path(__file__).resolve().parent
from inputs import P,N,stars
from samples import actions
moves=[]
for pm in actions(P,N):
 ls=[stars.index(pm[s]) for s in stars]
 lm=[sum(1<<ls[i] for i in range(7) if j>>i&1) for j in range(128)]
 moves.append((pm,lm))
def sym_points(b):
 return [(tuple(sorted(pm[v] for v in b)),lm) for pm,lm in moves]
def banks(path):return {tuple(sorted(map(int,l.split()))) for l in path.read_text().splitlines()}
allbanks=banks(here/'banks.txt')
rolecases={(min(t for t,lm in sym_points(bank)),0) for bank in allbanks if any(v in bank for v in stars)}
allroles=Counter();survivors=Counter(); bankok=Counter(); records=[]
for case,(bank,pair) in enumerate(sorted(rolecases)):
 ordinary=[j for j in range(7) if not(pair>>j &1)]
 literals=[q for q in ordinary if stars[q] in bank]
 category=len(literals)
 # For each positive and potential guarding ordinary star, record every
 # necessary separating disjunction as the set of permissible point slots.
 req={}
 for r in P:
  for q in ordinary:
   masks={sum(1<<i for i,v in enumerate(bank) if r&v and not n&v) for n in N if (r>>13)&(n>>13) and n&stars[q]}
   req[r,q]=masks
 options=set()
 for q in literals:
  a=bank.index(stars[q])
  for w in ordinary:
   if w==q:continue
   if stars[w] in bank:
    options.add(tuple(sorted(((q,(a,)),(w,(bank.index(stars[w]),))))))
   for x,y in combinations([i for i in range(11) if i!=a],2):
    X,Y=bank[x],bank[y]
    if X|Y==stars[w] or ((X&Y)==stars[w] and stars[w] in (X,Y)):
     options.add(tuple(sorted(((q,(a,)),(w,(x,y))))))
 found=False
 for opt in sorted(options):
  (q,qi),(w,wi)=opt
  b=11-len(qi)-len(wi)
  outside=2047^sum(1<<i for i in qi+wi)
  allroles[category,b]+=1
  if not all(any(all(c&outside for c in req[r,v]) for v in (q,w)) for r in P if not ((r>>13)&((1<<q)|(1<<w)))):continue
  survivors[category,b]+=1
  found=True
  records.append(dict(case=case,bank=bank,pair=pair,roles=opt,b=b))
 if found:bankok[category]+=1
if '--output' in sys.argv:Path(sys.argv[sys.argv.index('--output')+1]).write_text(json.dumps(records))
print('cases',len(rolecases),'allroles',allroles,'surviving roles',survivors,'surviving banks',bankok,flush=True)
