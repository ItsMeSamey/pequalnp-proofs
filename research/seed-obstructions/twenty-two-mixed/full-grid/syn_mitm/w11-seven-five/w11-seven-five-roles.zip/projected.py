from pathlib import Path
import json
from inputs import P,N,stars
for rid,r in enumerate(json.loads(Path('survivors.json').read_text())):
 (q,(a,)),(w,(b,))=r['roles']
 features=[x for i,x in enumerate(r['bank']) if i not in (a,b)]+[1<<(13+j) for j in range(7) if j not in (q,w)]
 def proj(v):return sum(bool(v&x)<<i for i,x in enumerate(features))
 ps={proj(v) for v in P if not (v>>(13+q)&1 or v>>(13+w)&1)}
 ns={proj(v) for v in N if v&stars[q] and v&stars[w]}
 dif={p&~n for p in ps for n in ns}
 print(rid,len(ps),len(ns),sum(1<<i in dif for i in range(14)),0 in dif)
