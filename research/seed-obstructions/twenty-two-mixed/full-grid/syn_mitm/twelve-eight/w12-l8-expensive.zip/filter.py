from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess, sys
file=Path(sys.argv[1]);out=Path(sys.argv[2]);here=Path(__file__).resolve().parent
raw=file.read_text().splitlines();n,P,L,k=map(int,raw[1].split())
assert (P,L,k)==(12,8,2) and len(raw)==n+2
rows=[list(map(int,r.split()))for r in raw[2:]]
with TemporaryDirectory()as s:
 d=Path(s);(d/'rows').write_text(raw[0]+'\n')
 (d/'points').write_text(''.join(' '.join(map(str,r[:12]))+'\n'for r in rows))
 (d/'lines').write_text(''.join(' '.join(map(str,r[12:]))+'\n'for r in rows))
 ans=subprocess.run([here/'subsetpure',d/'rows',d/'points',d/'lines'],input=''.join(f'{j} {j}\n'for j in range(n)),text=True,capture_output=True,check=True)
 print(ans.stderr.splitlines()[-1],flush=True)
 ids=[int(k.split()[0])for k in ans.stdout.splitlines()]
 out.write_text('\n'.join([raw[0],f'{len(ids)} 12 8 2',*[raw[2+i]for i in ids]])+'\n')
