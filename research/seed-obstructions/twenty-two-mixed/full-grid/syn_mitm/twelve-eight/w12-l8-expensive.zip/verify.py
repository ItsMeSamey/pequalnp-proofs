"""Regenerate the two point-role SAT enumerations and test the complete mixed domains."""
import argparse
from itertools import combinations
from pathlib import Path
import shutil,subprocess,sys,tempfile
from inputs import P,N,stars
from samples import actions
home=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--direct',action='store_true',help='use the mixed frontier directly, without the recursive prescreen')
parser.add_argument('--recorded-pair',action='store_true',help='use the recorded SAT output instead of regenerating it')
args=parser.parse_args()
G=[(f,[sum(1<<stars.index(f[s]) for j,s in enumerate(stars) if E>>j&1) for E in range(128)]) for f in actions(P,N)]
orbits=sorted({min(l[e] for f,l in G) for e in range(128) if e.bit_count()==4})
assert orbits==[15,23,27,46,83]
def solve_roles(b):
 records=set()
 for E in orbits:
  for k in range(4 if b==8 else 3):
   last=3 if b==8 else 2
   f=home/'recorded'/f'{b}.{E}.{k}.txt'
   if args.recorded_pair:lines=f.read_text().splitlines()
   else:
    code=home/('composite.py' if b==8 else 'literal.py')
    cmd=[sys.executable,str(code),str(E),str(k)]+(['exact'] if k==last else [])
    result=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
    assert result.stderr.splitlines()[-1].startswith('done ')
    lines=result.stdout.splitlines()
    assert set(lines)==set(f.read_text().splitlines())
   for row in set(lines):
    bank=list(map(int,row.split()))
    if b==9:
     assert len(bank)==9
     bank.extend(v for j,v in enumerate(stars) if not E>>j&1)
    assert len(bank)==12
    records.add((E,tuple(sorted(bank))))
 assert len(records)=={8:234,9:24}[b]
 return records
def imported(name):
 return {(q[0],tuple(q[1:])) for row in (home/'prior'/f'{name}.txt').read_text().splitlines() if (q:=list(map(int,row.split())))}
def packet_domain(records,j):
 full={(B,sum(perm)) for E,B in records for perm in combinations([1<<i for i in range(7) if E>>i&1],j)}
 return sorted({min((tuple(sorted(f[x] for x in B)),l[E]) for f,l in G) for B,E in full})
def write_packet(file,rows):
 file.write_text(' '.join(map(str,[len(P),len(N),*sorted(P),*sorted(N)]))+'\n'+f'{len(rows)} 12 8 2\n'+''.join(' '.join(map(str,[*bank,1,2,4,8,16,32,64,e]))+'\n' for bank,e in rows))
with tempfile.TemporaryDirectory() as tmp:
 td=Path(tmp);exe=td/'exact'
 subprocess.run(['g++','-O3','-std=c++17',str(home/'frontier.cpp'),'-o',str(exe)],check=True)
 if not args.direct:
  subprocess.run(['g++','-O3','-std=c++20',str(home/'subsetpure.cpp'),'-o',str(td/'subsetpure')],check=True)
  shutil.copyfile(home/'filter.py',td/'filter.py')
 small=imported('w12_zero_cert');r5=imported('w12_roles_cert')|imported('w12_two_masks')
 assert len(small)==12 and len(r5)==704
 for name,records,j in [('pair-b8',solve_roles(8),2),('pair-b9',solve_roles(9),2),('triple-r4',small,3),('triple-r5',r5,3)]:
  rows=packet_domain(records,j)
  efile=td/'packets';write_packet(efile,rows)
  if not args.direct:
   keep=td/'keep'
   subprocess.run([sys.executable,str(td/'filter.py'),str(efile),str(keep)],check=True)
   efile=keep
  subset=int(efile.read_text().splitlines()[1].split()[0])
  with efile.open() as fin:
   r=subprocess.run([str(exe)],stdin=fin,stdout=subprocess.PIPE,text=True,check=True)
  gates=list(map(int,r.stdout.split()))
  assert len(gates)==subset and all(0<h<19 for h in gates)
  print(name,len(records),len(rows),subset,max(gates,default=0),flush=True)
