"""Replay the archived earlier certificates and check their exported point banks."""
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import os,runpy,subprocess,sys
here=Path(__file__).resolve().parent
if len(sys.argv)!=2:
 for name in ('w12_roles_cert','w12_two_masks','w12_zero_cert'):
  subprocess.run([sys.executable,str(Path(__file__).resolve()),name],check=True)
else:
 name=sys.argv[1]; prior=here/'prior'; saved=set(); original=subprocess.run
 def record(*args,**kwargs):
  command=args[0] if args else kwargs['args']
  if Path(command[0]).name=='mixed' and 'input' in kwargs:
   E=int(command[1]); rows=kwargs['input']
   if isinstance(rows,bytes):rows=rows.decode()
   saved.update((E,tuple(map(int,l.split()))) for l in rows.splitlines() if l.strip())
  return original(*args,**kwargs)
 with TemporaryDirectory() as d:
  with ZipFile(prior/(name+'.zip')) as archive:archive.extractall(d)
  root=Path(d)/name;os.chdir(root);sys.path.insert(0,str(root))
  subprocess.run=record
  runpy.run_path(str(root/'verify.py'),run_name='__main__')
 expect={(q[0],tuple(q[1:])) for line in (prior/(name+'.txt')).read_text().splitlines() if (q:=list(map(int,line.split())))}
 assert saved==expect,(name,len(saved),len(expect))
 print(name,'export verified',len(saved),flush=True)
