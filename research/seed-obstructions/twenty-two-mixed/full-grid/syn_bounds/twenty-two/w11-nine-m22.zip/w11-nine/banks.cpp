#include "triple.hpp"
#include <iostream>
#include <vector>
int main() {
    int cp,cn;
    std::cin>>cp>>cn;
    std::vector<int> rows(cp+cn);
    for(int &r: rows) std::cin>>r;
    int count,p,l,surplus; std::cin>>count>>p>>l>>surplus;
    for(int i=0;i<count;i++){
        std::vector<int> masks(p+l), side(p+l,0), pos,neg;
        for(int j=0;j<p+l;j++){
            std::cin>>masks[j]; if(j<p) side[j]=1; else masks[j]<<=13;
        }
        for(int j=0;j<cp+cn;j++){
            int y=0;
            for(int k=0;k<p+l;k++) if(rows[j]&masks[k]) y|=1<<k;
            (j<cp?pos:neg).push_back(y);
        }
        frontierlib::Search test;
        if(test.treecut(pos,neg,p+l,surplus,side))std::cout<<i<<std::endl;
        if(i%100==99)std::cerr<<i+1<<" checked\n";
    }
    std::cerr<<"DONE "<<count<<std::endl;
}
