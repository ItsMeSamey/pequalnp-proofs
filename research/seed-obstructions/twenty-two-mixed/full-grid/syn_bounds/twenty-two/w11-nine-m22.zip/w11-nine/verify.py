"""Rebuild the m22 W11L9 exact-price domain and independently check both stages."""
from collections import Counter
from itertools import combinations_with_replacement,permutations
from pathlib import Path
import subprocess,tempfile
from input import raw_samples
here=Path(__file__).resolve().parent
pos,neg,_=raw_samples(here/'L-meta-18968.json')
raw=tuple(1<<i for i in range(7))
stars=[sum({r&8191 for r in pos if r&(x<<13)}) for x in raw]
inc=tuple(sum(1<<j for j,x in enumerate(stars) if x>>i&1) for i in range(13))
def move(x,perm):
    return sum(1<<j for i,j in enumerate(perm) if x>>i&1)
group=[]
for perm in permutations(range(7)):
    image=tuple(move(x,perm) for x in inc)
    if set(image)!=set(inc):continue
    pp=tuple(inc.index(x) for x in image)
    lm=tuple(move(x,perm) for x in range(128))
    def pair(r):return move(r&8191,pp)|(lm[r>>13]<<13)
    if all({pair(r) for r in rs}==rs for rs in (pos,neg)):
        group.append((pp,lm))
assert len(group)==24
points=[tuple(map(int,r.split())) for r in (here/'cost-nine-width-eleven.txt').read_text().splitlines()]
assert len(set(points))==27
lines={raw}
for _ in range(2):
    lines={tuple(sorted((*f,z))) for f in lines for a,b in combinations_with_replacement(f,2) for z in (a|b,a&b)}
assert len(lines)==540
reps=Counter()
for p in points:
    images=[(tuple(sorted(move(x,pp) for x in p)),lm) for pp,lm in group]
    best=min(q for q,lm in images)
    actions=[lm for q,lm in images if q==best]
    for f in lines:
        reps[best,min(tuple(sorted(lm[x] for x in f)) for lm in actions)]+=1
domain=sorted(reps)
assert len(domain)==714 and sum(reps.values())==14580
def payload(rows):
    h=' '.join(map(str,(len(pos),len(neg),*sorted(pos),*sorted(neg))))
    return h+'\n'+f'{len(rows)} 11 9 3\n'+''.join(' '.join(map(str,(*p,*f)))+'\n' for p,f in rows)
if __name__=='__main__' and __import__('sys').argv[1:]==['--domain']:
    print(len(domain),sum(reps.values()))
    print(payload(domain),end='')
    raise SystemExit()
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    for src in ['banks','parents22']:
        subprocess.run(['c++','-std=c++17','-O3',str(here/(src+'.cpp')),'-o',str(tmp/src)],check=True)
    first=subprocess.run([tmp/'banks'],input=payload(domain),text=True,stdout=subprocess.PIPE,check=True)
    keep=list(map(int,first.stdout.split()))
    assert len(keep)==37 and keep==sorted(set(keep))
    second=subprocess.run([tmp/'parents22'],input=payload([domain[i] for i in keep]),text=True,stdout=subprocess.PIPE,check=True)
    depths=list(map(int,second.stdout.split()))
    assert len(depths)==37 and max(depths)<=22
    print('representatives',len(domain),'labeled',sum(reps.values()),'cut survivors',len(keep),'direct first-empty histogram',sorted(Counter(depths).items()))
