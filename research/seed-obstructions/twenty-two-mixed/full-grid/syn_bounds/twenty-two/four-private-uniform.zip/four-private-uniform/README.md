# A point-width-independent price for disjoint private groups

Let t≥1 distinct four-point residual stars have pairwise disjoint nonempty groups of selected physical point signals. The AND in each group accepts its target's four singleton points and rejects every pair exterior to the target. Let g be the physical number of paid pure point gates. Then

    g ≥ ceil((7t+2)/3).

In particular four such groups require at least ten paid gates at every point width.

Write s_i for the number of group members and s for their total. Every member's singleton signature contains its entire target, since each single target point is accepted by the AND. Every free raw point primitive meets each target in at most one point. Consequently every group member is a paid physical gate. The earliest of these s distinct paid gates requires at least three gates in its ancestor cone including itself: an output of two binary gates over raw primitives can involve at most three distinct raw primitives, whose union meets its target in at most three points. Intersection cannot add a point beyond that union. At least two preceding paid gates therefore belong to no group. This gives s≤g−2.

Within a group, partition its s_i signatures into two nearly equal halves. The intersections of the two halves cannot both contain exterior points: choosing one exterior point from each half hits all members, contrary to pair-safety. If the same exterior point lies in both intersections, append any different exterior point to obtain a forbidden pair. For a singleton group the signature is already the target. In every case at most ceil(s_i/2) member signatures intersect exactly in the target, so at most floor((s_i−1)/2) extra gates recover the exact target singleton mask. Running all these intersection programs after the physical point program recovers t exact target masks concurrently.

The prior 3t exact-target projection theorem now gives
```
3t ≤ g + sum_i floor((s_i−1)/2)
   ≤ g + floor((s−t)/2)
   ≤ g + floor((g−2−t)/2).
```
Rearranging gives the stated bound. This uses the same half-group and projection lemmas documented in syn_quotients/diagonal_fourgroups/README.md, with no finite search and no width assumption. At nine line wires and read-once mixing, total size 33 leaves at most 23−P paid point gates. Four groups therefore suffice to exclude every P≥14, while the existing width-thirteen finite certificate excludes P=13 as well.

## Excluding equality for four groups

In fact four disjoint private groups on this seven-star residual require at least **eleven** paid point gates, at every width. In this step, groups represent the necessary mask conditions; if a group already contains a mask equal to its target, retain just that mask. Otherwise each member strictly contains the target, and there must be at least three members: one exterior point from each of two strict members would hit them both. Normalization keeps physical slots disjoint and preserves their signature-based pair test.

Suppose g=10. Equality is mandatory throughout the displayed estimate for t=4, because the four recovered exact masks require twelve gates. The normalized groups contain exactly eight paid physical slots in total. The two paid gates strictly before the earliest member are the only nonmembers. Thus they are the first two physical paid gates; call their signals H1,H2. Each group size must be odd for the sum of floors to attain (8−4)/2=2. The two size patterns are (5,1,1,1) and (3,3,1,1).

Let T be the star of a singleton group. Its exact mask cannot be computed by OR. Both operands of such an OR must be contained in T. A member of any other group contains that other four-point star, so the operands must be raw or among H1,H2. The resulting expression for T must contain at least four distinct raw operands, one per T point, since each primitive is transversal. Three binary gates are available including the final OR, so all three must be used in a four-leaf tree and the four leaves cover different points of T. Every internal gate must be an OR: at each vertex the two raw leaf subsets cover disjoint points of T, so an intersection would lose all target points underneath. Since the final union is contained in T, both H1 and H2 are contained in T. Now consider the first group member belonging to any other target U. All signals available before it are raw, H1, H2, or the single T member. Every one meets U in at most one point, because T and U meet once. A single binary gate on two such signals cannot contain the four points of U. This contradiction excludes OR.

Consequently every singleton group's exact T is computed by intersection. Neither H1 nor H2 can contain T: even the second paid signal involves at most three distinct raw primitives. A raw primitive or a singleton member from another group cannot contain T either. The two intersection operands must therefore be members of two different nonsingleton groups. Two members of one group would both contain its own star, which would incorrectly survive their intersection. This rules out (5,1,1,1).

For (3,3,1,1), let X,Y be the nonsingleton groups' stars and U,V be the singleton stars. Both intersections computing U and V use one operand from group X and one from group Y. Hence the point X∩Y must belong to both U and V, putting four distinct residual stars through the same point. The incidence multiplicities of the thirteen points are respectively 2,1,2,1,1,1,2,3,3,3,3,3,3. Fourfold incidence is impossible, excluding g=10.

This also gives the width-thirteen nine-line read-once exclusion directly. The earlier finite four-group certificates remain independent checks.

## Replay

Run `python verify.py` in this directory to decode the pinned raw residual statement, check the 31 starting point masks, four-element pairwise intersections of size one, transversality, the concurrency ceiling, and the possible normalized size profiles. The included seven_certificate.zip supplies the referenced 3t exact-target signature theorem and its finite evidence; unpack it and follow seven_certificate/README.md when that prior theorem also needs replay.
