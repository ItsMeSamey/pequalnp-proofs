"""Reconstruct all finite geometric facts in the uniform private-group proof."""
from itertools import combinations,combinations_with_replacement
from pathlib import Path
from input import point_obligations, raw_samples
raw,_=point_obligations(Path(__file__).with_name('L-meta-18968.json'))
pos,_,_=raw_samples(Path(__file__).with_name('L-meta-18968.json'))
stars=[sum({r&8191 for r in pos if (r>>13)&(1<<j)}) for j in range(7)]
assert len(raw)==31 and all(x.bit_count()==4 for x in stars)
assert all((x&t).bit_count()<=1 for x in raw for t in stars)
assert all((x&y).bit_count()==1 for x,y in combinations(stars,2))
inc=[sum(bool(t&(1<<j)) for t in stars) for j in range(13)]
assert inc==[2,1,2,1,1,1,2,3,3,3,3,3,3]
possible=[v for v in combinations_with_replacement((1,3,4,5),4) if sum(v)<=8 and sum((k-1)//2 for k in v)>=2]
assert possible==[(1,1,1,5),(1,1,3,3)]
print('Target masks',stars)
print('Point multiplicities',inc)
print('Ten-gate normalized group sizes',possible)
