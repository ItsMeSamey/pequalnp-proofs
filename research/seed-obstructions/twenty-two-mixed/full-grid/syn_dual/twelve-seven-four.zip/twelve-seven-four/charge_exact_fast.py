from itertools import combinations,product
from functools import lru_cache
from inputs import stars,P,N
from samples import actions
primitive={1<<i for i in range(13)}
for i in range(6):
 a=(1<<i)|(1<<(i+1));b=(1<<(i+3))|(1<<((i+9)%13));primitive.update((a,b,a|b))
orientations=sorted({tuple(sorted(f[v] for v in primitive)) for f in actions(P,N)})
raw=set().union(*map(set,orientations))
@lru_cache(None)
def gates(E,aux,orientation):
 targets=[s for j,s in enumerate(stars) if not E>>j&1]
 groups=[tuple(x for x in range(8192) if x.bit_count()>=2 and not x&~s) for s in targets]
 vals=tuple(v for gr in groups for v in gr)+aux
 assert len(vals)==len(set(vals)) and not(set(vals)&set(orientation))
 bit={v:1<<i for i,v in enumerate(vals)};ways=[set() for _ in vals];pool=orientation+vals
 for i,a in enumerate(pool):
  for b in pool[:i+1]:
   for c in (a|b,a&b):
    if c in bit and c!=a and c!=b:ways[bit[c].bit_length()-1].add(bit.get(a,0)|bit.get(b,0))
 def closure(possible,initial=0):
  avail=initial
  while True:
   new=avail;slots=possible&~avail
   while slots:
    x=slots&-slots;slots^=x
    if any(w&~avail==0 for w in ways[x.bit_length()-1]):new|=x
   if new==avail:return avail
   avail=new
 universe=(1<<len(vals))-1;options=[]
 for t,gr in zip(targets,groups):
  group=sum(bit[v] for v in gr);outside=universe^group;eligible=[]
  for u,v in combinations([x for x in gr if x!=t],2):
   loc=bit[t]|bit[u]|bit[v]
   if closure(loc,outside)&bit[t]:eligible.append(loc)
  options.append(eligible)
 return targets,groups,bit,options,closure
def feasible(E,bank):
 targets=[s for j,s in enumerate(stars) if not E>>j&1]
 aux=tuple(sorted(v for v in bank if v not in raw and all(v&~t for t in targets)))
 if len(aux)!=3 or len(set(aux))<3:return True
 for orient in orientations:
  if any(v not in orient and v not in aux and all(v&~t for t in targets) for v in bank):continue
  targets,groups,bit,ops,closure=gates(E,aux,orient)
  req=sum(bit[v] for v in set(bank) if v in bit);extra=sum(bit[v] for v in aux)
  for t in targets:
   if any(s not in bank for s in targets if s!=t):continue
   if not any((a|b==t or ((a&b)==t and t in (a,b))) for a,b in combinations(bank,2)):continue
   choices=[]
   for s,gr,ls in zip(targets,groups,ops):
    need=sum(bit[v] for v in set(bank)&set(gr))
    outside=sum(bit.values())^sum(bit[v] for v in gr)
    if s==t:ls=[bit[a]|bit[b] for a,b in combinations(gr,2)]
    ls=[l for l in ls if not need&~closure(l,outside)]
    choices.append([l for l in ls if not need&~l])
   if any(not req&~closure(a|b|c|extra) for a,b,c in product(*choices)):return True
 return False
if __name__=='__main__':
 from pathlib import Path
 import sys
 E=int(sys.argv[1]);lines=Path(sys.argv[2]).read_text().splitlines();banks={tuple(map(int,l.split())) for l in lines}
 ok=[b for b in sorted(banks) if feasible(E,b)]
 print('input',len(banks),'retained',len(ok),file=sys.stderr)
 for b in ok:print(*b)
