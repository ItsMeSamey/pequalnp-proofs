"""Verify the two remaining P12/L7, k=4 branches."""
from collections import Counter
from pathlib import Path
from subprocess import run, PIPE
import sys,tempfile
from inputs import P,N,stars
from charge_exact_fast import feasible
here=Path(__file__).resolve().parent
orbits=(15,23,27,46,83)
def records(b):
 for e in orbits:
  for k in range(4 if b==8 else 3):
   rows=set((here/'recorded'/f'{b}.{e}.{k}.txt').read_text().splitlines())
   if '--regenerate' in sys.argv:
    cmd=[sys.executable,str(here/('composite.py' if b==8 else 'literal.py')),str(e),str(k)]
    if k==(3 if b==8 else 2):cmd+=['exact']
    result=run(cmd,text=True,stdout=PIPE,check=True)
    assert set(result.stdout.splitlines())==rows
   yield from ((e,tuple(map(int,row.split()))) for row in sorted(rows))
if '--skip-source' not in sys.argv:
 counts=Counter()
 for E,B in records(8):
  fixed=[v for i,v in enumerate(stars) if not E>>i&1]
  if all(f in B for f in fixed):
   assert not feasible(E,B)
   counts['all-three']+=1
  else:counts['missing-third']+=1
 assert counts=={'all-three':84,'missing-third':150}
 print('width eight',dict(counts),flush=True)
with tempfile.TemporaryDirectory() as tmp:
 exe=Path(tmp)/'frontier'
 run(['g++','-O3','-std=c++17',str(here/'frontier.cpp'),'-o',str(exe)],check=True)
 counts=Counter()
 for E,fs in records(9):
  ls=[1<<i for i in range(7) if E>>i&1]
  fix=[v for i,v in enumerate(stars) if not E>>i&1]
  def proj(r):
   return sum(bool(r>>13&v)<<j for j,v in enumerate(ls))+sum(bool(r&v)<<(4+j) for j,v in enumerate(fs))
  pos={proj(r) for r in P if r>>13&E}
  neg={proj(r) for r in N if all(r&v for v in fix)}
  ps=sorted(p for p in pos if not any(q!=p and not q&~p for q in pos))
  ns=sorted(n for n in neg if not any(q!=n and not n&~q for q in neg))
  assert len(fs)==9 and all(any(p&~n==(1<<i) for p in ps for n in ns) for i in range(13))
  packet=' '.join(map(str,[13,13,len(ps),len(ns),*ps,*ns]))
  result=run([str(exe)],input=packet,text=True,stdout=PIPE,check=True)
  g,v=map(int,result.stdout.split())
  assert v==0 and 0<g<12
  counts[g]+=1
  print('projected',E,fs,g,flush=True)
 assert sum(counts.values())==24
 print('width nine',dict(counts),flush=True)
