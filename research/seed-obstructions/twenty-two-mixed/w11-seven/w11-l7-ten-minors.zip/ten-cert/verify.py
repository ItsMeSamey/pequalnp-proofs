"""Rebuild all seven ten-coordinate restrictions and exhaust their frontiers."""
from pathlib import Path
import json
import subprocess
import tempfile
from inputs import P,N,stars
here=Path(__file__).resolve().parent
keep=[16206,16143,16199,16300,16332,16344,16270]
exp=[8,8,9,8,8,9,9]
records=json.loads((here/'survivors.json').read_text())
assert len(records)==7
with tempfile.TemporaryDirectory() as tmp:
 exe=Path(tmp)/'frontier'
 subprocess.run(['c++','-O2','-std=c++17',str(here/'frontier.cpp'),'-o',str(exe)],check=True)
 for cid,(r,mask) in enumerate(zip(records,keep)):
  (q,(a,)),(s,(b,))=r['roles']
  features=[m for i,m in enumerate(r['bank']) if i not in (a,b)]+[1<<(13+j) for j in range(7) if j not in (q,s)]
  assert len(features)==14 and mask.bit_count()==10 and mask>>9==31
  def full(x):return sum(bool(x&f)<<i for i,f in enumerate(features))
  P14={full(x) for x in P if not (x>>(13+q)&1 or x>>(13+s)&1)}
  N14={full(x) for x in N if x&stars[q] and x&stars[s]}
  def allessential(ps,ns,n):
   differences={p&~z for p in ps for z in ns}
   assert 0 not in differences and all(1<<i in differences for i in range(n))
  allessential(P14,N14,14)
  ns={n&mask for n in N14}
  ps={p for p in P14 if not p&~mask}
  ps={p for p in ps if not any(x!=p and not x&~p for x in ps)}
  ns={n for n in ns if not any(x!=n and not n&~x for x in ns)}
  positions=[j for j in range(14) if mask>>j&1]
  def compact(x):return sum(((x>>j)&1)<<i for i,j in enumerate(positions))
  ps=sorted(map(compact,ps));ns=sorted(map(compact,ns))
  allessential(ps,ns,10)
  data=' '.join(map(str,[10,5,len(ps),len(ns),*ps,*ns]))+'\n'
  ret=subprocess.run([str(exe)],input=data,text=True,capture_output=True,check=True)
  result=tuple(map(int,ret.stdout.split()))
  print(cid,mask,len(ps),len(ns),result,flush=True)
  assert result==(exp[cid],0)
