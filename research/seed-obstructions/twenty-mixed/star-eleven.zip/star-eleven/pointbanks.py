"""Generate all star-local candidates at eleven gates; rule out earlier primitive outputs."""
from argparse import ArgumentParser
from collections import defaultdict
from pathlib import Path

from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
from input import point_obligations
from samples import actions, raw_samples

BASE = Path(__file__).resolve().parent
statement = BASE / 'L-meta-18968.json'
raw, rows = point_obligations(statement)
raw = set(raw)
stars = [sum(1 << ((6+j+d) % 13) for d in (0,1,3,9)) for j in range(7)]
ordinary = {x for x in range(1,8192) if any(not x & ~t for t in stars)}
group = actions(*raw_samples(statement))

def clauses_on(domain):
    buckets = defaultdict(list)
    for p, n in rows:
        clause = sum(1 << i for i, x in enumerate(domain) if p & x and not n & x)
        buckets[clause].append((p,n))
    minimal = []
    for c in sorted(buckets, key=int.bit_count):
        if not any(not d & ~c for d in minimal):
            minimal.append(c)
    return minimal, buckets

def make_solver(domain, size, clauses):
    solver = Solver(name='cadical195')
    pool = IDPool()
    flags = {x:pool.id() for x in domain}
    ordered = list(flags.values())
    add = solver.add_clause
    def bound(xs,n):
        for c in CardEnc.atmost(xs, n, vpool=pool).clauses:
            add(c)
    bound(ordered,size)
    charges = [flags[x] for x in domain if x in ordinary and x.bit_count() >= 2]
    for t in stars:
        hosted = [x for x in domain if x.bit_count() >= 2 and not x & ~t]
        debt1, debt2 = pool.id(), pool.id()
        charges.extend((debt1,debt2))
        for x in hosted:
            others = [flags[y] for y in hosted if y != x]
            if x.bit_count() >= 3:
                add([-flags[x], *others, debt1])
            if x == t:
                add([-flags[x], *others, debt2])
            else:
                add([-flags[t], -flags[x], *[flags[y] for y in hosted if y not in (x,t)], debt1])
    bound(charges,11)
    for c in clauses:
        add([q for i,q in enumerate(ordered) if c >> i & 1])
    return solver, flags

def exclude_external():
    earlier = raw - ordinary
    domain = sorted(ordinary | {g[x] for g in group for x in earlier})
    clauses,buckets = clauses_on(domain)
    def erased(m):
        return sum(1 << i for i,c in enumerate(clauses)
                   if all(p & m and not n & m for p,n in buckets[c]))
    deletions = {x:erased(x) for x in earlier}
    maximal = []
    for d in sorted(set(deletions.values()), key=int.bit_count, reverse=True):
        if all(d & ~other for other in maximal):
            maximal.append(d)
    remaining = set(maximal)
    checked = 0
    for m,d in sorted(deletions.items()):
        if d not in remaining:
            continue
        remaining.difference_update(erased(g[m]) for g in group)
        solver,_ = make_solver(domain,10,[c for i,c in enumerate(clauses) if not d >> i & 1])
        assert not solver.solve()
        solver.delete()
        checked += 1
    assert len(earlier) == len(maximal) == 18 and checked == 5 and not remaining
    print('All five earlier-primitive queries are UNSAT.', flush=True)

def generate():
    domain = sorted(ordinary)
    clauses,_ = clauses_on(domain)
    assert len(domain) == 90 and len(clauses) == 184
    solver,flags = make_solver(domain,11,clauses)
    result = set()
    orbits = 0
    while solver.solve():
        model = set(solver.get_model())
        bank = tuple(x for x,q in flags.items() if q in model)
        orbit = {tuple(sorted(g[x] for x in bank)) for g in group}
        assert not (result & orbit)
        for image in orbit:
            if len(image) == 11:
                solver.add_clause([-flags[x] for x in image])
            else:
                solver.add_clause([-q if x in image else q for x,q in flags.items()])
        result.update(orbit)
        orbits += 1
    solver.delete()
    assert orbits == 145 and len(result) == 2668 and all(len(b)==11 for b in result)
    print('145 ordinary-bank orbits and 2668 labelled width-eleven banks.', flush=True)
    return sorted(result)

if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    exclude_external()
    banks = generate()
    payload = ''.join(' '.join(map(str,b))+'\n' for b in banks)
    assert payload == (BASE/'banks.txt').read_text()
    if args.output:
        args.output.write_text(payload)
