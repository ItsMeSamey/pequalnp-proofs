"""Check all 2,668 point candidates against the 540 two-gate nine-line banks."""
from collections import Counter, defaultdict
from hashlib import sha256
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

from samples import actions, raw_samples
from domain import line_banks

here = Path(__file__).resolve().parent
p,n = raw_samples(here/'L-meta-18968.json')
stars = [sum(1 << ((6+j+d)%13) for d in (0,1,3,9)) for j in range(7)]
banks = [tuple(map(int,x.split())) for x in (here/'banks.txt').read_text().splitlines()]
assert len(set(banks))==len(banks)==2668
lines = sorted(b for b,c in line_banks(p,n).items() if c==2)
assert len(lines)==540
group=actions(p,n)
line_maps=[]
for g in group:
    permutation=[1 << stars.index(g[t]) for t in stars]
    line_maps.append([sum(bit for i,bit in enumerate(permutation) if x>>i&1) for x in range(128)])
orbits=defaultdict(int)
for bank in banks:
    canonical=min(tuple(sorted(g[x] for x in bank)) for g in group)
    orbits[canonical]+=1
assert len(orbits)==145
cases=[]
for b,size in sorted(orbits.items()):
    stabilizer=[lm for g,lm in zip(group,line_maps) if tuple(sorted(g[x] for x in b))==b]
    assert size*len(stabilizer)==24
    counts=Counter(min(tuple(sorted(lm[x] for x in l)) for lm in stabilizer) for l in lines)
    cases.extend((b,l,size*c) for l,c in sorted(counts.items()))
assert len(cases)==62148 and sum(w for b,l,w in cases)==1440720
expected={1:189,2:2460,3:160908,4:495639,5:495534,6:196353,7:70218,8:17928,9:1287,10:204}
with TemporaryDirectory() as work:
    exe=Path(work)/'frontier'
    subprocess.run(['c++','-O3','-std=c++20','-march=native',here/'frontier.cpp','-o',exe],check=True)
    actual=Counter()
    for start in range(0,len(cases),1000):
        chunk=cases[start:start+1000]
        data=' '.join(map(str,[len(p),len(n),*sorted(p),*sorted(n),len(chunk),11,9,1]))+'\n'
        data+=''.join(' '.join(map(str,b+l))+'\n' for b,l,w in chunk)
        result=subprocess.run([exe],input=data,text=True,capture_output=True,check=True)
        levels=list(map(int,result.stdout.split()))
        for level,(b,l,w) in zip(levels,chunk,strict=True):
            assert 1<=level<=10,(b,l,level)
            actual[level]+=w
    assert dict(actual)==expected
    print('62,148 joint orbits; all 1,440,720 labelled cases excluded.',dict(sorted(actual.items())))
