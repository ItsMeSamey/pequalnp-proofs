"""Nine-line multisets and their minimum pure-side costs."""
from collections import Counter
from itertools import combinations_with_replacement

def line_banks(p,n):
    raw=tuple(1<<i for i in range(7))
    lines={}
    for a,b in combinations_with_replacement(range(128),2):
        if min(a.bit_count(),b.bit_count())<2 or a==b:
            cost=max(2,a.bit_count(),b.bit_count())
        else:
            cost=(a|b).bit_count()-1-int(not (a&b))
        if cost<=4:
            lines[tuple(sorted((*raw,a,b)))]=cost
    # Enumerate missing-singleton banks by the nine-line basis characterization.
    obligations={(pp>>13,nn>>13) for pp in p for nn in n if not (pp & 8191) & ~nn}
    from itertools import combinations
    for missing in raw:
        remaining=set(raw)-{missing}
        for tri in combinations(remaining,3):
            f=tuple(sorted(remaining|{missing|u for u in tri}))
            if all(any(s & a and not s & b for s in f) for a,b in obligations):
                lines[f]=3
    assert Counter(lines.values())=={2:540,3:1529,4:2590}
    assert sum(not set(raw)<=set(f) for f in lines)==24
    return lines
