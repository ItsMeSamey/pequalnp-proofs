"""Regenerate the budgeted line domain and screen the stated optimal point banks."""
import sys
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory
from line_domain import enumerate_banks
here=Path(__file__).resolve().parent
pareto=here.parent/'point-pareto'
sys.path.insert(0,str(pareto))
from input import raw_samples
p,n,_=raw_samples(pareto/'L-meta-18968.json')
banks=enumerate_banks(p,n)
raw={1<<i for i in range(7)}
with TemporaryDirectory() as temp:
    root=Path(temp)
    rows=root/'rows.txt'
    rows.write_text(' '.join(map(str,(len(p),len(n),*sorted(p),*sorted(n))))+'\n')
    points=root/'points.txt'
    points.write_text((pareto/'cost-nine-six.txt').read_text()+(here/'three-seven-output-banks.txt').read_text())
    assert len(points.read_text().splitlines())==27
    prog=root/'frontier'
    subprocess.run(['c++','-std=c++20','-O3',str(here/'frontier.cpp'),'-o',str(prog)],check=True)
    for paid,missing in ((4,1),(3,0),(4,0)):
        domain=[f for f,k in banks.items() if k==paid and len(raw-set(f))==missing]
        path=root/'lines.txt'
        path.write_text(''.join(' '.join(map(str,f))+'\n' for f in domain))
        subprocess.run([str(prog),str(rows),str(points),str(path)],check=True)
