"""Check whether another optimal eleven-wire bank with seven paid outputs exists."""
import argparse
import sys
import subprocess
from itertools import combinations
from pathlib import Path
from pysat.solvers import Solver
here=Path(__file__).resolve().parent
pareto=here.parent/'point-pareto'
sys.path.insert(0,str(pareto))
from input import point_obligations
from check import encode

def instance(raw,rows):
    clauses, boundary, selected, _ = encode(raw,rows,11,7,selected=7,abstract=True)
    high=max(abs(q) for c in clauses for q in c)
    def fresh():
        nonlocal high
        high+=1
        return high
    masks=boundary+[[fresh() for _ in range(13)] for _ in range(2)]
    # Sort the auxiliary masks independently of the sorted boundary masks.
    eq=[]
    for a,b in zip(reversed(masks[7]),reversed(masks[8])):
        clauses.append([-q for q in eq]+[-a,b])
        e=fresh()
        clauses.extend(([-e,-a,b],[-e,a,-b],[e,a,b],[e,-a,-b]))
        eq.append(e)
    clauses.append([-q for q in eq])
    # Repeated masks in a shortest singleton-domain circuit would cost a removable gate.
    for a in boundary:
        for b in masks[7:]:
            diff=[]
            for x,y in zip(a,b):
                d=fresh();diff.append(d)
                clauses.extend(([-d,x,y],[-d,-x,-y]))
            clauses.append(diff)
    order={(i,j):fresh() for i,j in combinations(range(9),2)}
    def before(i,j):return order[i,j] if i<j else -order[j,i]
    for i in range(9):
        for j in range(9):
            for k in range(i+1,9):
                if i!=j!=k:clauses.append([-before(i,j),-before(j,k),before(i,k)])
    shallow=sorted({v for a,b in combinations(raw,2) for v in (a&b,a|b)}-set(raw)-{0})
    uses=[[],[]]
    for i,output in enumerate(masks):
        options=[]
        def option(*parents):
            q=fresh()
            options.append(q)
            for j in parents:
                clauses.append([-q,before(j,i)])
                if j>=7:uses[j-7].append(q)
            return q
        def permitted(union,j):
            return (j<7)!=(i<7) or (j<i)==union
        for v in shallow:
            q=option()
            for bit,z in enumerate(output):clauses.append([-q,z if v>>bit&1 else -z])
        for j,parent in enumerate(masks):
            if j==i:continue
            for union in (False,True):
                if not permitted(union,j):continue
                for v in raw:
                    q=option(j)
                    for bit,(y,z) in enumerate(zip(parent,output)):
                        if (v>>bit&1)==union:clauses.append([-q,z if union else -z])
                        else:clauses.extend(([-q,-z,y],[-q,z,-y]))
        for j,k in combinations(range(9),2):
            if i in (j,k):continue
            for union in (False,True):
                if not (permitted(union,j) and permitted(union,k)):continue
                q=option(j,k)
                sign=1 if union else -1
                for x,y,z in zip(masks[j],masks[k],output):
                    x*=sign;y*=sign;z*=sign
                    clauses.extend(([-q,-x,z],[-q,-y,z],[-q,x,y,-z]))
        clauses.append(options)
    clauses.extend(uses)
    return clauses,boundary,selected

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--cnf',type=Path)
    ap.add_argument('--check-proof',type=Path)
    args=ap.parse_args()
    if args.check_proof and not args.cnf:ap.error('--check-proof requires --cnf')
    raw,rows=point_obligations(pareto/'L-meta-18968.json')
    known=[tuple(map(int,r.split())) for r in (here/'three-seven-output-banks.txt').read_text().splitlines()]
    clauses,masks,rsel=instance(raw,rows)
    for bank in known:
        paid=sorted(set(bank)-set(raw))
        assert len(paid)==7 and len(bank)==11
        assert all(any(x&p and not x&n for x in bank) for p,n in rows)
        assert sum(x.bit_count()-1 for x in paid)==9
        clauses.append([(-q if x>>j&1 else q) for x,m in zip(paid,masks) for j,q in enumerate(m)]
                     +[-q if x in bank else q for x,q in zip(raw,rsel)])
    with Solver(name='cadical195',bootstrap_with=clauses,with_proof=bool(args.check_proof)) as solver:
        if args.cnf:
            with args.cnf.open('w') as file:
                print('p cnf',solver.nof_vars(),len(clauses),file=file)
                for c in clauses:print(*c,0,file=file)
        if solver.solve():
            model=set(solver.get_model())
            paid=[sum((q in model)<<d for d,q in enumerate(m)) for m in masks]
            print('Additional bank',sorted(paid+[x for x,q in zip(raw,rsel) if q in model]),flush=True)
            raise SystemExit(1)
        print('No other nine-gate bank with seven selected nonraw masks.',flush=True)
        if args.check_proof:
            from pysat.solvers import pysolvers
            native=solver.solver
            pysolvers.flushpr(native.prfp)
            native.prfile.seek(0)
            checked=subprocess.run([str(args.check_proof),str(args.cnf),'-i'],stdin=native.prfile,stdout=subprocess.PIPE,check=True)
            output=checked.stdout.decode()
            if 's VERIFIED' not in output:raise SystemExit('DRAT checker rejected the trace')
            for line in output.splitlines():
                if 'VERIFIED' in line or 'verification time' in line:print(line,flush=True)
if __name__=='__main__':main()
