from collections import Counter
from functools import lru_cache
from itertools import combinations, combinations_with_replacement

def enumerate_banks(positive, negative):
    obligations = {(p>>13,n>>13) for p in positive for n in negative if not ((p&8191)&~(n&8191))}
    obligations = sorted((p,n) for p,n in obligations
                         if all(p!=q or n==m or n&~m for q,m in obligations))
    coverage = [sum(bool(a&p and not a&n)<<i for i,(p,n) in enumerate(obligations)) for a in range(128)]
    full = (1<<len(obligations))-1
    @lru_cache(None)
    def valid(bank):
        covered=0
        for x in bank:
            covered |= coverage[x]
        return covered == full
    raw=tuple(1<<i for i in range(7))
    states={raw}
    bank_cost={}
    for paid in range(1,5):
        following=set()
        for state in states:
            values={x for a,b in combinations_with_replacement(state,2) for x in (a|b,a&b)}
            following.update(tuple(sorted((*state,v))) for v in values)
        states=following
        if paid>=3:
            for state in states:
                for bank in combinations(state,10):
                    if valid(bank):
                        bank_cost.setdefault(bank,paid)
    counts=Counter((cost,len(set(raw)-set(bank))) for bank,cost in bank_cost.items())
    assert counts == {(3,0):8275,(4,0):37415,(4,1):960}
    cores=Counter()
    fourth=Counter()
    for bank in bank_cost:
        if set(raw)<=set(bank):continue
        options={bank[:i]+bank[i+1:] for i in range(10) if valid(bank[:i]+bank[i+1:])}
        assert len(options)==1
        core=options.pop()
        cores[core]+=1
        extra=list(bank)
        for x in core:extra.remove(x)
        fourth[extra[0].bit_count()]+=1
    assert len(cores)==24 and set(cores.values())=={40}
    assert fourth=={0:24,1:144,2:504,3:288}
    print('Line banks:',dict(sorted(counts.items())),'missing-label cores:',len(cores),'extensions per core:',40,flush=True)
    return bank_cost
