# Twenty mixed gates with eleven point and ten line inputs

The 21 inputs force any connected twenty-gate mixed cone to be a binary tree, hence read-once in its boundary positions. The 33-gate limit leaves thirteen paid gates for the pure sides. Eleven point inputs require at least nine paid point gates, so at most four paid line gates are available.

## Affordable line signatures

Starting from the seven singleton line masks, enumerate multisets of outputs of zero through four binary unions or intersections. Include duplicate and empty results and select every ten-wire submultiset. Whenever the raw positive point input is contained in the raw negative point input, at least one selected line mask must contain the positive line singleton and avoid the negative line set. This condition is necessary for any monotone separator.

| Minimum paid line gates | Missing raw singletons | Qualifying ten-wire multisets |
| --- | ---: | ---: |
| 3 | 0 | 8,275 |
| 4 | 0 | 37,415 |
| 4 | 1 | 960 |

Every bank in the last row has a unique qualifying nine-wire submultiset. There are 24 such cores, each with 40 extensions. Across all 960 banks the additional mask is empty 24 times, a singleton 144 times, a pair 504 times, and a triple 288 times. An omitted raw singleton forces exactly nine paid point gates.

## Read-once conflicts

For each positive/negative pair, record which of the 21 point or line coordinates is one at the positive and zero at the negative. A pair distinguished only by coordinate i forces every monotone separator to be sensitive to i at both rows. At an accepting assignment, two simultaneously sensitive variables of a monotone read-once formula must have an AND as their least common ancestor. At a rejecting assignment, the corresponding ancestor must be an OR. Thus sharing a private positive and a private negative, with potentially different partner rows, contradicts read-once computation.

The preceding point-Pareto certificate gives 24 nine-gate point banks with six selected computed masks, and requires six or seven selected computed masks at this gate count. Exactly three seven-output point banks fit the budget. Each has one four-point mask and six pairs on different stars. All 27 fail the read-once conflict test against all 46,650 line banks, including every one of the 960 missing-singleton multisets. The checker uses all raw ordered positive and maximal negative rows and every labelled point and line family. The test uses the singleton-OR relaxation of the original boundary functions, which preserves every positive and can only lower negatives.

Run `python verify_local.py` with Python 3, a C++20 compiler, and the companion `point-pareto` directory beside this one. The 27 point families are the entire star-local minimum-cost domain. For a star with c selected local paid masks, let s be four minus the minimum number of selected pieces and raw singleton points covering it. Choosing any subset J of stars allows the paid outputs on other hosts to be granted free as transversal masks. Reconstructing stars in J and invoking the three-gates-per-star lower bound gives point cost at least the sum of max(c,s) over all hosts. With seven selected nonraw masks and point budget nine, exhaustively choosing local masks and up to four raw wires leaves precisely the three seven-output banks given here.

## Complete nine-gate point domain

Run `python optimal_banks.py` with python-sat to exclude every further seven-selected point bank. The formula uses all 1,323 original point separation obligations, selects at most four of the 31 raw masks, and requires seven distinct selected computed masks and two auxiliary gates. The seven boundary masks and two hidden masks are each independently sorted by value. The shared precedence constraints still permit any acyclic gate order across the two groups. A shortest singleton-domain program cannot duplicate a mask, and both hidden masks must be used; otherwise eight paid gates suffice, contradicting the preceding Pareto result. Blocking only the three known full boundary sets includes all alternate choices of internal wires. The optional flags `--cnf point.cnf --check-proof /path/to/drat-trim` stream the UNSAT proof to an independent checker.

Consequently the nine-point-gate allocation is excluded for every ten-line bank in the table. The sole remaining allocation for a separator of total size at most 33 in this slice uses ten paid point gates and three paid line gates. All seven raw singleton line masks must be present. No circuit existence claim for the remaining allocation is implied.

## Necessary condition in the ten-point-gate allocation

If every selected computed point mask is contained in a residual star, the same projection argument applies at point budget ten with an arbitrary number of selected gates. Writing c for the number selected on a host star, its cost contribution beyond c is positive in just three cases. A lone triple adds one, a lone full star adds two, and a two-mask host containing the full star adds one. Hence a cardinality constraint with two extra charge flags per host enumerates every qualifying bank. Zero and duplicate traces cannot help: deleting repeated masks still leaves a bank, and no feasible bank under this necessary bound has fewer than eleven mask positions. The exhaustive relaxation gives 354 eleven-wire banks. Against all 8,275 line banks of cost three, each candidate has a read-once conflict. Thus a remaining candidate must use at least one computed point mask that is not contained in any residual star.

Run `python verify_remaining_local.py` for the labelled point and line case counts. The check uses Python 3, python-sat and a C++20 compiler.
