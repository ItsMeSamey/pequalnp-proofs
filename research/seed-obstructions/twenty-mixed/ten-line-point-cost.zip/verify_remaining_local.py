"""Screen every labelled star-local point candidate in the remaining allocation."""
import sys
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory
from line_domain import enumerate_banks
here=Path(__file__).resolve().parent
pareto=here.parent/'point-pareto'
sys.path.insert(0,str(pareto))
from input import raw_samples
p,n,_=raw_samples(pareto/'L-meta-18968.json')
lines=enumerate_banks(p,n)
with TemporaryDirectory() as temp:
    root=Path(temp);rows=root/'rows.txt'
    rows.write_text(' '.join(map(str,(len(p),len(n),*sorted(p),*sorted(n))))+'\n')
    pts=root/'point.txt'
    subprocess.run([sys.executable,str(here/'star_local.py'),str(pts)],check=True)
    ls=root/'line.txt'
    ls.write_text(''.join(' '.join(map(str,f))+'\n' for f,k in lines.items() if k==3))
    exe=root/'frontier'
    subprocess.run(['c++','-std=c++20','-O3',str(here/'frontier.cpp'),'-o',str(exe)],check=True)
    subprocess.run([str(exe),str(rows),str(pts),str(ls)],check=True)
