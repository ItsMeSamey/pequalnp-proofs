#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
template<size_t W> vector<array<int,W>> load(const char* name){
 ifstream f(name);vector<array<int,W>> r;array<int,W> a;
 while(f>>a[0]){for(int i=1;i<W;i++)if(!(f>>a[i]))throw runtime_error("partial family");r.push_back(a);}return r;
}
template<size_t N> int project(int x,array<int,N> a){
 int y=0;for(int i=0;i<N;i++)y|=bool(x&a[i])<<i;return y;
}
int main(int argc,char**v){
 ifstream input(v[1]);int pn,nn;input>>pn>>nn;vector<int> p(pn),n(nn);for(int &r:p)input>>r;for(int&r:n)input>>r;
 auto ps=load<11>(v[2]);auto ls=load<10>(v[3]);if(pn!=28||nn!=245||ps.empty()||ls.empty())return 4;int count[3]{};
 for(auto L:ls){
  vector<int> pl(pn),nl(nn);for(int i=0;i<pn;i++)pl[i]=project(p[i]>>13,L);for(int j=0;j<nn;j++)nl[j]=project(n[j]>>13,L);
  for(auto P:ps){
   vector<int> pp(pn),np(nn);
   for(int i=0;i<pn;i++)pp[i]=pl[i]|(project(p[i]&8191,P)<<10);
   for(int j=0;j<nn;j++)np[j]=nl[j]|(project(n[j]&8191,P)<<10);
   array<uint32_t,21> pm{};array<array<uint64_t,4>,21> nm{};
   bool bad=false;
   for(int i=0;i<pn&&!bad;i++)for(int j=0;j<nn;j++){
    int d=pp[i]&~np[j];if(!d){bad=true;break;}
    if((d&(d-1))==0){int k=countr_zero((unsigned)d);pm[k]|=1u<<i;nm[k][j/64]|=uint64_t(1)<<(j%64);}
   }
   if(bad){count[0]++;continue;}
   for(int i=0;i<21&&!bad;i++)for(int j=0;j<i&&!bad;j++)if(pm[i]&pm[j])for(int k=0;k<4;k++)if(nm[i][k]&nm[j][k])bad=true;
   if(bad){count[1]++;continue;}
   count[2]++;for(int a:P)cout<<a<<' ';for(int a:L)cout<<a<<' ';cout<<'\n';
  }
 }
 cerr<<"families "<<ps.size()<<" x "<<ls.size()<<" dominated "<<count[0]<<" conflict "<<count[1]<<" remaining "<<count[2]<<endl;
 return count[2]!=0;
}
