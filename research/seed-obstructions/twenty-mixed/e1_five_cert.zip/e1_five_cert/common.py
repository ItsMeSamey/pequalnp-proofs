"""Rebuild the point-role instances and exhaust every noncanonical case."""
from itertools import permutations
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import re
import subprocess
import sys
import zipfile
from inputs import N,P,stars
from samples import actions

HERE=Path(__file__).resolve().parent
A=8191

def maximal(rows):
    rows=set(rows)
    return {(p,n) for p,n in rows if not any(p==q and n!=m and not n&~m for q,m in rows)}

def clique(rows):
    points=sorted(rows)
    neighbors=[sum(1<<j for j,(x,y) in enumerate(points) if p&y or x&n)
               for p,n in points]
    best=[]
    for i in range(len(points)):
        remaining=neighbors[i]
        chosen=[i]
        while remaining:
            candidates=[j for j in range(len(points)) if remaining>>j&1]
            index=max(candidates,key=lambda j:(remaining&neighbors[j]).bit_count())
            chosen.append(index)
            remaining &=neighbors[index]
        if len(chosen)>len(best):
            best=chosen
    result=[points[i] for i in best]
    assert all(a&d or b&c for i,(a,b) in enumerate(result) for c,d in result[:i])
    return result

