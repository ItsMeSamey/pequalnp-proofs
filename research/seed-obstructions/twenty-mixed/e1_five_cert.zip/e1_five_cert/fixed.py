from common import *
def run():
    raw=maximal((p&A,n&A) for p in P for n in N if not (p>>13)&~(n>>13))
    assert len(raw)==1323
    with TemporaryDirectory() as td:
        exe=Path(td)/'fixed'
        subprocess.run(['c++','-O3','-std=c++20','-march=native',HERE/'fixed5/search.cpp','-o',exe],check=True)
        for E,expected in [(31,985),(47,981),(87,999)]:
            ordinary=[t for j,t in enumerate(stars) if not E>>j&1]
            rows={(p,n) for p,n in raw if not any(p&t and not n&t for t in ordinary)}
            forced=set()
            for j,t in enumerate(stars):
                if not E>>j&1:continue
                active={n&A for n in N if (n>>13)&(1<<j)}
                ns={x&y for x in active if x&ordinary[0] for y in active if y&ordinary[1]}
                forced.update((1<<d,n) for d in range(13) if t>>d&1 for n in ns)
            rows.update(maximal(forced))
            form=[int(not E>>j&1) for j in range(7)]
            data=' '.join(map(str,form))+'\n0\n'+str(len(rows))+'\n'+''.join(f'{p} {n}\n' for p,n in sorted(rows))
            result=subprocess.run([exe,'all'],input=data,capture_output=True,text=True,check=True)
            print(E,result.stderr.splitlines()[-1],flush=True)
            assert not result.stdout and result.stderr.splitlines()[-1]==f'DONE 715 {expected} 0'
if __name__=='__main__':
    assert __debug__
    run()
