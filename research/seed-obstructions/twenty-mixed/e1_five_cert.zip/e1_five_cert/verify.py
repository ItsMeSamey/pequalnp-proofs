from common import *
from itertools import permutations
from project import model
from collections import Counter
A=8191
def run():
    sym=[tuple(stars.index(f[s]) for s in stars) for f in actions(P,N)]
    raw=maximal((p&A,n&A) for p in P for n in N if not (p>>13)&~(n>>13))
    assert len(raw)==1323
    def five(E):
        ordinary=[t for j,t in enumerate(stars) if not E>>j&1]
        rows=set()
        for j,t in enumerate(stars):
            if not E>>j&1:continue
            eligible={n&A for n in N if (n>>13)&(1<<j)}
            sets={x&y for x in eligible if x&ordinary[0] for y in eligible if y&ordinary[1]}
            for d in range(13):
                if t>>d&1:rows.update((1<<d,x) for x in sets)
        return maximal(rows)
    representatives=sorted({min(sum(1<<g[i] for i in range(7) if E>>i&1) for g in sym)
                            for E in range(128) if E.bit_count()==5})
    assert representatives==[31,47,87]
    for E in representatives:
        assert len(clique(five(E)))==5
        for b in (5,6):assert model(E,b) is None
        print('special set',E,'packing 5 and b=5,6 UNSAT',flush=True)
    roles=[(1,2),(1,7),(2,2),(2,7),(7,7),*((1,f) for f in (3,4,5,6))]
    cases=sorted({min(tuple(a[i] for i in g) for g in sym) for form in roles
                  for a in set(permutations((*form,0,0,0,0,0)))})
    assert len(cases)==34
    lookup={};nodes=Counter();count=Counter()
    with TemporaryDirectory() as td:
        exe=Path(td)/'search'
        subprocess.run(['c++','-O3','-std=c++20','-march=native',HERE/'point/search.cpp','-o',exe],check=True)
        for a in cases:
            E=sum(1<<j for j,f in enumerate(a) if not f)
            if E not in lookup:lookup[E]=five(E)
            forced=set(lookup[E]);rest=[]
            for p,n in sorted(raw-forced):
                if any(f==1 and p&stars[t] and not n&stars[t] for t,f in enumerate(a)):continue
                if any((f in (2,3) and p&stars[t]) or f in (4,5,6,7) for t,f in enumerate(a)):rest.append((p,n))
                else:forced.add((p,n))
            anchor=clique(forced)
            pairs=lambda r:''.join(f'{p} {b}\n' for p,b in r)
            inp=' '.join(map(str,a))+'\n'+str(len(anchor))+'\n'+pairs(anchor)+str(len(forced))+'\n'+pairs(sorted(forced))+pairs(rest)
            run=subprocess.run([exe],input=inp,text=True,capture_output=True,check=True)
            match=re.fullmatch(r'DONE (\d+) 0\s*',run.stderr)
            assert not run.stdout and match
            b=11-sum({0:0,1:1,2:2,3:3,4:3,5:3,6:3,7:2}[f] for f in a)
            nodes[b]+=int(match[1]);count[b]+=1
            print('b',b,'roles',*a,'nodes',match[1],flush=True)
    assert nodes=={7:87918,8:2646054} and count=={7:26,8:8}
    print('Actual b=9 is necessary.')
if __name__=='__main__':
    if not __debug__:raise SystemExit('Enable Python assertions.')
    run()
