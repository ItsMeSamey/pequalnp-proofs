#include "hereditaryrole.hpp"
#include "branch.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <fstream>
#include <set>
#include <vector>
using namespace std;
constexpr int W = 11, A = 8191, B = 16;
using U = uint64_t;
using Row = array<int, W>;
using Bits = array<U, B>;
struct R {
    int a, b;
};
vector<R> rows;
Bits pos[8192]{}, neg[8192]{}, full{};
int stars[7];
uint64_t family_count = 0, nodes = 0, charge_pruned = 0;
Row anchors{}, excluded{};
uint64_t stars_pruned = 0;
int fixedfour, nanchors;
int role[11], gsz[7];
uint64_t ncase = 0;

int freew,forced;
int form[7],off[7];
Bits allow[W];
int sz(int f) { return !f?0:f==1?1:(f==2||f==7)?2:3; }
int fn(int f,int a,int b,int c) {
 switch(f) {
 case 1:return a; case 2:return a|b; case 3:return a|b|c;
 case 4:return a&b&c; case 5:return (a&b)|c; case 6:return (a|b)&c;
 case 7:return a&b; default:abort();
 }
}
int propagate(Row &lo,Row &no) {
 bool ch=false;
 for(int t=0;t<7;t++) if(form[t]>1){
  int k=off[t],f=form[t],n=sz(f),T=stars[t];
  int v[3]{},h[3]{};
  for(int i=0;i<n;i++)v[i]=lo[k+i],h[i]=A^no[k+i];
  if((fn(f,v[0],v[1],v[2])&~T)||(T&~fn(f,h[0],h[1],h[2])))return -1;
  for(int i=0;i<n;i++){
   int old=h[i];h[i]=0;int must=T&~fn(f,h[0],h[1],h[2]);h[i]=old;
   int org=v[i];v[i]=A;int ban=~T&fn(f,v[0],v[1],v[2]);v[i]=org;
   if((must&~org)||(ban&old)){lo[k+i]|=must;no[k+i]|=ban;ch=true;}
  }
  if(f!=2&&f!=3){
   for(int x=A&~T;x;x&=x-1)for(int y=x&(x-1);y;y&=y-1){
    int pair=(x&-x)|(y&-y),bb[3]{};
    for(int i=0;i<n;i++) bb[i]=bool(v[i]&pair);
    if(fn(f,bb[0],bb[1],bb[2]))return -1;
    for(int i=0;i<n;i++)if(!bb[i]){
     bb[i]=1;int ban=fn(f,bb[0],bb[1],bb[2])?pair:0;bb[i]=0;
     if(ban&~no[k+i]){no[k+i]|=ban;ch=true;}
    }
   }
  }
 }
 return ch;
}
bool cut_charge(const Row& lo,const Row& hi){
 static int exterior_table[8192],clean_table[8192];static bool ready=false;
 if(!ready){
  for(int m=0;m<=A;m++){
   exterior_table[m]=1;
   for(int j=0;j<13;j++){
    int line=(1<<j)|(1<<((j+1)%13))|(1<<((j+3)%13))|(1<<((j+9)%13));
    if(!(m&~line)){exterior_table[m]=0;if(j>=6 && !form[j-6])clean_table[m]=1;}
   }
  }
  ready=true;
 }
 int exterior=0,clean=0;
 for(int i=0;i<freew;i++){
  bool transversal_line=!exterior_table[lo[i]],special_clean=clean_table[hi[i]];
  exterior+=!transversal_line;
  clean+=special_clean && popcount((unsigned)lo[i])>=2;
 }
 // The current run applies this extra cut only to actual, unnormalized 1+1 groups.
 if(freew!=5)return false;
 for(int h=exterior;h<=7;h++)if(h+clean<=5+min(2,h*(h-1)/6))return false;
 return true;
}
void visit(Row yes, Row no) {
    if (++nodes % 1000000 == 0)
        cerr << nodes << " nodes " << family_count << " surviving families " << charge_pruned
             << " charge-pruned nodes " << stars_pruned << " recovery-pruned nodes" << endl;
    int slot = -1, bit = 0;
    for (;;) {
        for (int i = nanchors; i + 1 < freew; i++)
            if (role[i] == role[i + 1] && yes[i] > (A ^ no[i + 1]))
                return;
        for (int j = nanchors; j < W; j++)
            for (int i = 0; i < nanchors; i++) {
                if (role[i] == role[j] && !(anchors[i] & ~yes[j]) && !(excluded[i] & ~no[j]) &&
                    (A ^ no[j]) < yes[i])
                    return;
            }
        // For each slot and witness row track possible coverage, guaranteed
        // coverage, and coverage forced onto this slot.
        Bits can[W]{},sole[W]{},possible_private[W],guaranteed[W];
        bool change = false;
        int selected = -1, best = W + 1;
        int fullstars = 0;
        for (int i = 0; i < W; i++)
            if ((yes[i] | no[i]) == A)
                for (int l = 0; l < 7; l++)
                    if (yes[i] == stars[l])
                        fullstars |= 1 << l;
        if (popcount((unsigned)fullstars) >= 4)
            return;
        int prop = propagate(yes, no);
        if (prop < 0) {
            ++stars_pruned;
            return;
        }
        if (prop)
            continue;
        for (int z = 0; z < B; z++) {
            U c=0,mc=0,g=0,mg=0;
            for (int i = 0; i < freew; i++) {
                U x = can[i][z] = allow[i][z] & pos[A ^ no[i]][z] & neg[yes[i]][z];
                U y = guaranteed[i][z] = allow[i][z] & pos[yes[i]][z] & neg[A ^ no[i]][z];
                mc |= c & x;
                c |= x;
                mg |= g&y;g |= y;
            }
            if (c != full[z])
                return;
            for (int i = 0; i < freew; i++) {
                sole[i][z] = can[i][z] & ~(mc | g);
                possible_private[i][z]=can[i][z]&~(mg|(g&~guaranteed[i][z]));
            }
            if (best == 2)
                continue;
            U opt = full[z] & ~g & mc;
            while (opt) {
                int b = countr_zero(opt), ct = 0;
                for (int i = 0; i < freew && ct < best; i++)
                    ct += (can[i][z] >> b) & 1;
                if (ct < best) {
                    best = ct;
                    selected = z * 64 + b;
                }
                opt &= opt - 1;
                if (best == 2)
                    break;
            }
        }
        for (int i = 0; i < freew; i++) {
            int forced = 0, avoid = 0;
            for (int z = 0; z < B; z++) {
                U v = sole[i][z];
                while (v) {
                    auto r = rows[64 * z + countr_zero(v)];
                    v &= v - 1;
                    forced |= r.a;
                    avoid |= r.b;
                }
            }
            bool has=false;int private_pos=A,private_neg=A;
            for(int z=0;z<B;z++){
                U v=possible_private[i][z];has|=bool(v);
                while(v&&(private_pos||private_neg)){
                    auto [p,n]=rows[64*z+countr_zero(v)];
                    private_pos &=p;private_neg &=n;v &= v-1;
                }
            }
            if(!has)return;
            forced |= private_pos;avoid |= private_neg;
            if ((forced | yes[i]) & (avoid | no[i]))
                return;
            if ((forced & ~yes[i]) || (avoid & ~no[i])) {
                yes[i] |= forced;
                no[i] |= avoid;
                change = true;
            }
        }
        if (change)
            continue;
        Row high;
        for (int i = 0; i < W; i++)
            high[i] = A ^ no[i];
        bool nonlocal=false;
        for(int i=0;i<5;i++){
            if(popcount((unsigned)high[i])<2)return;
            bool possible=true;for(int T:stars)if(!(high[i]&~T))possible=false;
            nonlocal|=possible;
        }
        if(!nonlocal)return;
        if (cut_charge(yes,high) || hereditary::bound(yes, high) || branch_charge::exclude(yes,high,can,rows)) {
            ++charge_pruned;
            return;
        }
        if (selected >= 0) {
            auto r = rows[selected];
            for (slot = 0; slot < W; slot++)
                if ((selected>=forced || slot<freew) && !((r.a & no[slot]) | (r.b & yes[slot])))
                    break;
            int free = (r.a | r.b) & ~(yes[slot] | no[slot]);
            bit = free & -free;
        } else {
            for (slot = 0; slot < W; slot++) {
                int f = A & ~(yes[slot] | no[slot]);
                if (f) {
                    bit = f & -f;
                    break;
                }
            }
            if (slot == W) {
                sort(yes.begin(), yes.end());
                ++family_count;
                for (int x : yes)
                    cout << x << ' ';
                cout << '\n';
                return;
            }
        }
        break;
    }
    Row alt = yes;
    alt[slot] |= bit;
    visit(alt, no);
    no[slot] |= bit;
    visit(yes, no);
}


int main(int argc,char**argv){
 if(argc<2)return 1;
 hereditary::setup();branch_charge::setup();
 for(int t=0;t<7;t++)stars[t]=hereditary::target[t];
 for(int &f:form)cin>>f;
 Row y{},n{};int off0=9;
 for(int t=0;t<7;t++)if(form[t]){
  if(form[t]!=1)abort();
  hereditary::known_groups[t]=1;
  off[t]=off0;role[off0]=t+1;y[off0]=stars[t];n[off0++]=A^stars[t];
 }
 if(off0!=11)abort();
 int a,b,nold;cin>>nold;
 while(nold--)cin>>a>>b;cin>>forced;
 while(cin>>a>>b)rows.push_back({a,b});
 if(forced!=(int)rows.size()||forced>64*B)abort();
 for(int j=0;j<forced;j++){
  auto [p,n]=rows[j];U x=U(1)<<(j%64);
  for(int m=0;m<=A;m++){if(m&p)pos[m][j/64]|=x;if(!(m&n))neg[m][j/64]|=x;}
 }
 // Precompute raw-interval incompatibility.
 vector<Bits> neighbors(forced);
 for(int i=0;i<forced;i++)for(int j=0;j<forced;j++)
  if((rows[i].a&rows[j].b)||(rows[j].a&rows[i].b))neighbors[i][j/64]|=U(1)<<(j%64);
 int checked=0;freew=5;
 for(int S=0;S<=A;S++)if(popcount((unsigned)S)==4){
  if(argc>=4 && S%stoi(argv[3])!=stoi(argv[2]))continue;
  Row ys=y,ns=n;
  int j=5;for(int v=S;v;v&=v-1){int p=v&-v;ys[j]=p;ns[j++]=A^p;}
  full.fill(0);
  for(int r=0;r<forced;r++)if(!(rows[r].a&S)||rows[r].a&rows[r].b)full[r/64]|=U(1)<<(r%64);
  // Every raw obligation has disjoint positive and negative point sets. A selected
  // singleton covers exactly the rows with that positive point.
  Bits act=full;nanchors=0;
  for(;;){
   int best=-1,score=-1;
   for(int z=0;z<B;z++)for(U v=act[z];v;v&=v-1){
    int r=64*z+countr_zero(v),value=0;
    for(int h=0;h<B;h++)value+=popcount(act[h]&neighbors[r][h]);
    if(value>score){score=value;best=r;}
   }
   if(best<0)break;
   if(nanchors>=5)abort();
   ys[nanchors]=rows[best].a;ns[nanchors++]=rows[best].b;
   for(int z=0;z<B;z++)act[z]&=neighbors[best][z];
  }
  for(int i=0;i<5;i++)allow[i]=full;
  anchors=ys;excluded=ns;
  visit(ys,ns);checked++;
  if(checked%100==0)cerr<<"raw sets "<<checked<<" nodes "<<nodes<<" banks "<<family_count<<endl;
 }
 cerr<<"DONE "<<checked<<" "<<nodes<<" "<<family_count<<endl;
}
