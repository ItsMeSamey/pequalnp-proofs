from itertools import combinations
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'eightplus'))
from samples import lines,neg
from verify_clamp import badpoints,flags
from collections import Counter
h=Counter()
for tup in combinations(range(7),4):
 I=set(tup)
 ns=[(q,l) for q,l in neg if any(l>>i&1 for i in I)]
 assert all(any(q>>p&1 for q,l in ns) for p in range(13))
 bad={(i,p) for i,T in enumerate(lines) for p in badpoints(ns,[T])}
 defect={(i,j,p) for i,T in enumerate(lines) for j,U in enumerate(lines) if i!=j for p in range(13) if not (T>>p&1) and not any(l>>i&1 and q>>p&1 and q&U for q,l in ns)}
 h[len(bad)]+=1
 if bad:
  assert len(bad)==1
  F,c=next(iter(bad))
  assert F in I and {i for i,T in enumerate(lines) if T>>c&1}==I-{F}
  assert defect=={(t,F,c) for t in set(range(7))-I}
  flags(ns,0,lambda i,j:j!=F or i in I)
 else:
  assert not defect
  flags(ns,0,lambda i,j:True)
assert h=={0:11,1:24}
print(h)
