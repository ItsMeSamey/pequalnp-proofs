from itertools import permutations
from pathlib import Path
from collections import Counter
import sys
from basic import model,stars,projective,positive,negative
def image(x,perm):return sum(((x>>j)&1)<<k for j,k in enumerate(perm))
labels=[sum(bool(s>>j&1)<<i for i,s in enumerate(stars)) for j in range(13)]
group=[]
for g in permutations(range(7)):
 moved=[image(a,g) for a in labels]
 if set(moved)!=set(labels):continue
 pts=[labels.index(y) for y in moved]
 assert {image(t,pts) for t in projective}==set(projective)
 def row(r):return image(r&8191,pts)|(image(r>>13,g)<<13)
 assert {row(r) for r in positive}==positive and {row(r) for r in negative}==negative
 group.append(g)
assert len(group)==24
step=int(sys.argv[1]);budget=int(sys.argv[2]);only=int(sys.argv[3]) if len(sys.argv)>3 else None
for size in (2,3,4):
 reps=Counter(min(image(m,g) for g in group) for m in range(128) if m.bit_count()==size)
 print('orbits',size,reps,flush=True)
 for e,mult in sorted(reps.items()):
    if only and e!=only:continue
    for b in range(min(4+size,3*size-3)+1):
        r,answer=model(e,b,step,budget);print(e,size,mult,b,r,answer,flush=True)
