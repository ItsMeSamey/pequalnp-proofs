from pysat.solvers import Solver
from pysat.formula import IDPool
from pysat.card import CardEnc
from itertools import combinations,product
from collections import Counter
from functools import lru_cache
from pathlib import Path
import sys
source=Path(__file__).resolve().parent
sys.path.insert(0,str(source));from input import raw_samples
positive,negative,_=raw_samples(source/'L-meta-18968.json')
stars=[sum({p&8191 for p in positive if p>>(13+j)&1}) for j in range(7)]
projective=[sum(1<<((j+d)%13) for d in (0,1,3,9)) for j in range(13)]
def bits(s):return [i for i in range(13) if s>>i&1]
def model(E,b,cluster=0,ceil=12000,cost=None):
 special=[s for i,s in enumerate(stars) if E>>i&1];o=7-len(special);slack=25-(len(special) if cost is None else cost)-4*o-b
 if slack<0:return ('COUNT',None)
 P=IDPool();cnf=[]
 def lit(x):return P.id(x)
 def ors(v):
  z=lit(('or',*sorted(v)));cnf.extend([[-q,z] for q in v]+[[-z,*v]]);return z
 def ands(v):return -ors([-q for q in v])
 def cap(v,k):
  return CardEnc.atmost(v,k,vpool=P).clauses if 0<=k<len(v) else [] if k>=len(v) else [[]]
 z=[[lit((i,j))for j in range(13)]for i in range(b)]
 def ub(i,mask):return ands([-z[i][j] for j in bits(8191^mask)])
 for i in range(b-1):
  eq=[]
  for j in reversed(range(13)):
   x,y=z[i][j],z[i+1][j];cnf.append([-r for r in eq]+[-x,y])
   eq.append(ands([ors([x,-y]),ors([-x,y])]))
 for t in special:
  j=stars.index(t)
  ordinary=[u for u in stars if u not in special]
  eligible=[n&8191 for n in negative if n&(1<<(13+j))]
  sets={8191^t}
  if isinstance(cluster,tuple):
   groups=product(*[[stars[j] for j in bits(block)] for block in cluster])
  else:
   groups=[ordinary] if not cluster else combinations(ordinary,min(cluster,len(ordinary)))
  for group in groups:
   rows={x for x in eligible if all(x&u for u in group)}
   sets={x&y for x in sets for y in rows}
   sets={x for x in sets if not any(x!=y and not x&~y for y in sets)}
  for v in bits(t):
   for X in sets:
    cnf.append([ands([zz[v],*[-zz[x] for x in bits(X)]]) for zz in z])
 if b+o==11:
  # Every ordinary private group has one leaf, whose mask is its star.
  ordinary=[u for u in stars if u not in special]
  for r in positive:
   point=(r&8191).bit_length()-1
   for n in negative:
    if not (r&~8191)&n:continue
    X=n&8191
    if any((u&(1<<point)) and not (u&X) for u in ordinary):continue
    cnf.append([ands([zz[point],*[-zz[x] for x in bits(X)]]) for zz in z])
 ext=[-ors([ub(i,t) for t in projective])for i in range(b)]
 clean=[]
 savings=[]
 for t in special:
  flags=[lit(('save',t,j)) for j in range(3)];savings+=flags
  for i,zz in enumerate(z):
   c=ub(i,t)
   for n in range(2,5):
    for vs in combinations(bits(t),n):cnf.append([-c,*[-zz[v] for v in vs],flags[n-2]])
  for j in range(2):cnf.append([-flags[j+1],flags[j]])
 for i,zz in enumerate(z):
  n2=ors([ands([zz[x],zz[y]])for x,y in combinations(range(13),2)])
  clean.append(ands([n2,ors([ub(i,t) for t in special])]))
 cnf+=cap(savings,slack)
 # Project onto all ordinary targets plus a chosen special subset. Original
 # paid OR-side gates that become transversals can be granted and deleted.
 rich={}
 for i,zz in enumerate(z):
  for t in stars:
   rich[i,t]=ors([ands([zz[x],zz[y]]) for x,y in combinations(bits(t),2)])
 globally=[ors([rich[i,t] for t in stars]) for i in range(b)]
 for J in range(1<<len(special)):
  kept=[t for t in stars if t not in special]+[t for j,t in enumerate(special) if J>>j&1]
  union=0
  for t in kept:union|=t
  removed=[ands([globally[i],*[-rich[i,t] for t in kept]]) for i in range(b)]
  savings2=[]
  for j,t in enumerate(special):
   if not J>>j&1:continue
   flags=[lit(('proj',J,t,k)) for k in range(3)]
   savings2+=flags
   cleanproj=[ands([-zz[d] for d in bits(union&~t)]) for zz in z]
   for i,zz in enumerate(z):
    for n in range(2,5):
     for vs in combinations(bits(t),n):cnf.append([-cleanproj[i],*[-zz[v] for v in vs],flags[n-2]])
   for k in range(2):cnf.append([-flags[k+1],flags[k]])
   for i,k in combinations(range(b),2):
    pairunion=ands([cleanproj[i],cleanproj[k],*[ors([z[i][d],z[k][d]]) for d in bits(t)]])
    pairinter=ands([*[z[n][d] for n in (i,k) for d in bits(t)],
                   *[ors([-z[i][d],-z[k][d]]) for d in bits(union&~t)]])
    cnf.append([-pairunion,flags[1]])
    cnf.append([-pairinter,flags[1]])
  cnf+=cap(removed+savings2,slack)
 options=[]
 for h in range(slack+o+1):
  q=min(o,h*(h-1)//6);c=slack+q-h
  if c<0:continue
  v=lit(('bound',h));options.append(v)
  for row in cap(ext,h)+cap(clean,c):cnf.append([-v,*row])
 cnf.append(options)
 with Solver(name='cadical195',bootstrap_with=cnf) as s:
  s.conf_budget(ceil)
  result=s.solve_limited()
  if result is None:return ('UNKNOWN',None)
  if result:
   M=set(s.get_model());return 'SAT',[sum((x in M)<<j for j,x in enumerate(zz)) for zz in z]
 return ('UNSAT',None)
if __name__=='__main__':
 E=int(sys.argv[1]);b=int(sys.argv[2]);print(E,b,model(E,b))
