# Four disjoint pair-safe groups require 24−P paid point gates for widths P=13 through 17

On the residual L-meta-18968 sample, take any bank of P physical point-side boundary signals that covers the raw point separation obligations. Suppose four distinct residual target lines each have their own disjoint set of these physical slots. The AND of the slots in each group accepts all four singleton points of its target and rejects every pair of distinct points outside it. Then the original purely point-side program requires at least 24−P binary union/intersection gates. The claim permits unused, raw-redundant and duplicate-signature slots, including physically distinct slots computing the same singleton signature.

Run `python verify.py` with Python 3 and a C++20 compiler supporting native unsigned 128-bit arithmetic. No solver library is needed for this replay. The separate seven_certificate.zip gives the prior 3k projection theorem, including its own dependencies and finite proof.

## Guard groups

Write the singleton signature of a guard as a thirteen-bit set. For every pair of exterior points of T, some guard in its group must have a signature disjoint from that pair. Otherwise every guard would accept the pair by monotonicity. In particular, intersecting the guards' singleton sets gives exactly T. If a group contains a signature equal to T, retain just that one mask for this combinatorial test. This retains the required mask property. Otherwise each guard has some exterior point. A group with one or two strict supersets fails the exterior-pair test, since one exterior point from each member hits all the members. Thus a normalized group either has size one and equals T, or has at least three strict supersets. For three members their exterior parts are nonempty and pairwise disjoint. Sharing of an exterior point between two parts would let that point and one point from the third part hit all three.

To compute T from m given group masks, at most ceil(m/2) operands suffice. Partition the group into two parts whose sizes differ by at most one. If both intersections contain an exterior point, one such point from each part hits every member of the group. For m=1 use the existing exact mask. In all cases at most floor((m−1)/2) additional binary intersections suffice. This claim uses the singleton signatures alone after normalization.

## Input and symmetry checks

The Python driver decodes the 676-row statement, checks its fingerprint, derives the 28 required positives and 245 maximal negatives, and computes all 24 joint point and line coordinate permutations preserving those samples. It derives five orbits of target quartets. The orbit union of the 31 free point-primitive masks has size 55. Allowing all 55 simultaneously makes the cost bound invariant under the 24 permutations. Every one of them is a transversal of the seven targets.

For a positive with singleton point a and a negative with point set b, take the pair (a,b) whenever the negative contains all the positive line coordinates. The possible point boundary signatures X that separate it have a in X and b disjoint from X. For each a retain the maximal b. This gives the independently reconstructed 1,323 rows. Every feasible bank must cover these rows. The verifier admits slots that cover no row uniquely.

For each quartet a seven-row incompatibility clique is supplied and validated. The first four anchors each require a whole target T and exclude an exterior pair. They are satisfied by a slot chosen from the corresponding private group. The last three anchors are required raw rows. Distinct rows in the clique cannot be satisfied by the same signature because some required point of one row is forbidden by the other. The seven anchors therefore label distinct slots. The remaining P−7 slots are unanchored. Enumerate the assignments of all P−4 slots other than the first four to the four groups or to the unused class. The unanchored slots are ordered by class, and then by numeric value within a class. Within a class an anchored slot uses the least compatible available signature in preference to an unanchored slot. Each signature can satisfy at most one anchor, so this choice eliminates only alternative labellings.

The bitwise search maintains forced presences and absences for each slot. It propagates raw rows that can be covered by only one slot. The search branches both ways on a remaining bit. It rejects incompatible role assignments, groups of size two, four simultaneously exact distinct canonical lines and incomplete raw coverages. Four exact targets need at least twelve point gates. It enforces that nonsingleton groups have strict supersets, enforces the disjoint-exterior condition for three members, and enforces every exterior-pair condition in larger groups.

## The projection bound

For each subset J of target lines project every point mask to the union of J. This commutes with both gate operations. All masks meeting every line in J at most once may be taken for free in the 3|J| bound. A known paid boundary output that becomes such a transversal can have its construction gate removed and its projected mask used for free. If several known paid boundary signals become the same projected mask, retain the earliest and delete the others. For every partial state the checker greedily selects a subset of certainly paid slots whose allowed mask intervals are pairwise disjoint. They must arise from distinct paid gates, while repeated signatures cannot double-charge. The search uses conditions that hold throughout a partial interval of possible signatures.

If the remaining circuit can recover each target of J using d further gates, and h paid gates have been deleted by projection, its original cost is at least 3|J|−d+h. Three singleton unions per target give a default construction. A known clean pair on T saves one gate. A clean triple, two complementary clean pairs, or two full-bearing masks intersecting exactly in T save two. An existing full clean T saves three. Clean means that all exterior points disappear on the chosen projection. The half-group argument above gives additional recoveries for the four private targets on every projection that retains them. Independent improvements for the same target are combined by taking their maximum. The counter computes the bound for all 128 subsets of the seven targets and excludes a bank if any lower bound reaches 24−P.


## Checked counts

The five representative quartets 15, 23, 27, 46 and 83 have orbit sizes 12, 6, 12, 1 and 4. The table gives their exhaustive search counts, with zero survivors throughout.

| Width | Minimum cost proved | Q15 | Q23 | Q27 | Q46 | Q83 |
|---:|---:|---:|---:|---:|---:|---:|
|13|11|20,155|5,743|4,867|12,871|15,153|
|14|10|2,037|834|664|1,216|572|
|15|9|597|296|296|296|296|
|16|8|853|457|457|457|457|
|17|7|1,285|681|681|681|681|

For P≥18 choose one physical boundary wire from each of the four disjoint groups. Each is paid as its mask contains its entire target. The earliest of the four chosen wires requires at least two earlier gates in its fan-in cone. Each raw input meets its target in at most one point, and covering four points needs a binary cone with at least four inputs, hence at least three gates including its output. This gives an absolute lower bound of six gates when the selected wires are physically distinct, as in the read-once mixed cone.

A read-once mixed cone on nine line and P point wires needs P+8 mixed gates. For adjacent two-line-extra placements forcing four groups, total cost is at least 34 since the line cost is at least two. The missing-singleton banks force four groups and line cost at least three, hence 35. Both apply at P≥13 using this certificate. Lower widths have separately certified four-group bounds. For other ordinary placements the reconstructive bound of P−7+d gates, d≤c+2 for line cost c, gives 36+c−d≥34 uniformly. The occurrence-linear transfer, its verification of all 105 punctured cost-six banks, and the classification of the remaining adjacent placements are detailed in the companion read-once-nine.md and linesplits.py/log in syn_bounds/twenty. Zero and repeated line signatures reduce to seven or eight genuine signatures with at most two or one surplus uses respectively. Applying the earlier width-free bounded-surplus results handles those cases.
