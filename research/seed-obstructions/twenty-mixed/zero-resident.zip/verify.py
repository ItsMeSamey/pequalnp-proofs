from pathlib import Path
import subprocess, tempfile,sys
from models import model,positive,negative,stars,bits
from geometry import cases
from itertools import combinations
from rows import instance
here=Path(__file__).resolve().parent
stages=set(sys.argv[1:]) or {'lossless','lost','pin','fixed'}
if not stages<={'lossless','lost','pin','fixed'}:raise SystemExit('Unknown stage')
es=[15,23,27,46,83]
if 'lossless' in stages:
 for e in es:
  for b in range(3,9):assert model(e,b,budget=22) is None,(e,b)
 print('All thirty zero-resident lossless special envelopes are impossible.',flush=True)
if 'lost' in stages:
 for e in es:
  for b in range(3,8):assert model(e,b) is None,(e,b)
 for e in (23,46,83):assert model(e,8) is None,e
 print('All 25 single-gate-loss envelopes through b=7, plus three b=8 orbits, are impossible.',flush=True)
if 'pin' in stages:
 marked=cases(2);assert len(marked)==35
 for e,k,q in marked:
  for b in range(3,8):assert model(e,b,q) is None,(e,k,q,b)
 print('All 175 two-point-pinned special envelopes are impossible.',flush=True)
 for e in range(128):
  if e.bit_count()!=4:continue
  for k in range(7):
   if e>>k&1:continue
   for ps in combinations(bits(stars[k]),3):
    q=sum(1<<p for p in ps)
    for j in range(7):
     if not e>>j&1:continue
     for u in range(7):
      if e>>u&1:continue
      rows=[n for n in negative if n&(1<<(13+j)) and n&q and n&stars[u]]
      for a,b in combinations(bits(8191^stars[j]),2):
       assert any(n&(1<<a) and n&(1<<b) for n in rows)
 print('All 420 three-point strata retain all exterior-pair witnesses.',flush=True)
if 'fixed' in stages:
 marked=[(e,k,c) for e,k,c in cases(1) if e in (15,27)]
 assert len(marked)==14
 with tempfile.TemporaryDirectory() as temp:
  d=Path(temp);binary=d/'fixed';sample=d/'samples'
  subprocess.run(['c++','-std=c++20','-O3',here/'combined.cpp','-o',binary],check=True)
  sample.write_text(' '.join(map(str,(28,245,*sorted(positive),*sorted(negative))))+'\n')
  nodes=survivors=0
  for e,k,c in marked:
   assert instance(d,e,k,c)==5
   with (d/f'{e}-{k}-{c}.in').open() as f:
    r=subprocess.run([binary,str(e),sample],stdin=f,text=True,capture_output=True,check=True)
   row=r.stderr.splitlines()[-1].split()
   assert not r.stdout and row[0]=='DONE'
   nodes+=int(row[1]);survivors+=int(row[2])
  print('Fixed triples:',len(marked),'orbits,',nodes,'nodes,',survivors,'charge survivors, zero mixed survivors.',flush=True)
  assert nodes==3695138 and survivors==4
