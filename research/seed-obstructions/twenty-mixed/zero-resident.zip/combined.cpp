#include "hereditaryrole.hpp"
#include "mixed.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <fstream>
#include <set>
#include <vector>
using namespace std;
constexpr int W = 11, A = 8191, B = 16;
using U = uint64_t;
using Row = array<int, W>;
using Bits = array<U, B>;
struct R {
    int a, b;
};
vector<R> rows;
Bits pos[8192]{}, neg[8192]{}, full{};
int stars[7];
uint64_t family_count = 0, nodes = 0, charge_pruned = 0;
Row anchors{}, excluded{};
uint64_t stars_pruned = 0;
int fixedfour, nanchors;
int role[W], gsz[7];
uint64_t ncase = 0;
// Each designated group must reject every pair exterior to its target.
int four_propagate(Row &yes, Row &no) {
    bool changed = false;
    for (int t = 0; t < 7; t++)
        if (gsz[t] > 1) {
            int T = stars[t], ex = A ^ T;
            if (gsz[t] == 3) {
                int have = 0;
                for (int i = 0; i < W; i++)
                    if (role[i] == t) {
                        int x = yes[i] & ex;
                        if (x & have)
                            return -1;
                        have |= x;
                    }
                for (int i = 0; i < W; i++)
                    if (role[i] == t) {
                        int need = have & ~yes[i];
                        if (need & ~no[i]) {
                            no[i] |= need;
                            changed = true;
                        }
                    }
            }
            for (int i = 0; i < W; i++)
                if (role[i] == t && !(yes[i] & ex)) {
                    int free = ex & ~no[i];
                    if (!free)
                        return -1;
                    if (!(free & (free - 1))) {
                        yes[i] |= free;
                        changed = true;
                    }
                }
            if (gsz[t] > 3) {
                for (int x = ex; x; x &= x - 1)
                    for (int y = x & (x - 1); y; y &= y - 1) {
                        int pair = (x & -x) | (y & -y), ct = 0, last = -1;
                        for (int i = 0; i < W && ct < 2; i++)
                            if (role[i] == t && !(yes[i] & pair)) {
                                ct++;
                                last = i;
                            }
                        if (ct == 0)
                            return -1;
                        if (ct == 1 && (pair & ~no[last])) {
                            no[last] |= pair;
                            changed = true;
                        }
                    }
            }
        }
    return changed;
}
void visit(Row yes, Row no) {
    if (++nodes % 1000000 == 0)
        cerr << nodes << " nodes " << family_count << " surviving families " << charge_pruned
             << " charge-pruned nodes " << stars_pruned << " recovery-pruned nodes" << endl;
    int slot = -1, bit = 0;
    for (;;) {
        for (int i = nanchors; i + 1 < W; i++)
            if (role[i] == role[i + 1] && yes[i] > (A ^ no[i + 1]))
                return;
        for (int j = nanchors; j < W; j++)
            for (int i = 0; i < nanchors; i++) {
                if (role[i] == role[j] && !(anchors[i] & ~yes[j]) && !(excluded[i] & ~no[j]) &&
                    (A ^ no[j]) < yes[i])
                    return;
            }
        // For each slot and witness row track possible coverage, guaranteed
        // coverage, and coverage forced onto this slot.
        Bits can[W], sole[W];
        bool change = false;
        int selected = -1, best = W + 1;
        int fullstars = 0;
        for (int i = 0; i < W; i++)
            if ((yes[i] | no[i]) == A)
                for (int l = 0; l < 7; l++)
                    if (yes[i] == stars[l])
                        fullstars |= 1 << l;
        if (popcount((unsigned)fullstars) >= 4)
            return;
        int prop = four_propagate(yes, no);
        if (prop < 0) {
            ++stars_pruned;
            return;
        }
        if (prop)
            continue;
        for (int z = 0; z < B; z++) {
            U c = 0, mc = 0, g = 0;
            for (int i = 0; i < W; i++) {
                U x = can[i][z] = pos[A ^ no[i]][z] & neg[yes[i]][z];
                U y = pos[yes[i]][z] & neg[A ^ no[i]][z];
                if(i<3){x=0;y=0;can[i][z]=0;}
                mc |= c & x;
                c |= x;
                g |= y;
            }
            if (c != full[z])
                return;
            for (int i = 0; i < W; i++) {
                sole[i][z] = can[i][z] & ~(mc | g);
            }
            if (best == 2)
                continue;
            U opt = full[z] & ~g & mc;
            while (opt) {
                int b = countr_zero(opt), ct = 0;
                for (int i = 0; i < W && ct < best; i++)
                    ct += (can[i][z] >> b) & 1;
                if (ct < best) {
                    best = ct;
                    selected = z * 64 + b;
                }
                opt &= opt - 1;
                if (best == 2)
                    break;
            }
        }
        for (int i = 0; i < W; i++) {
            int forced = 0, avoid = 0;
            for (int z = 0; z < B; z++) {
                U v = sole[i][z];
                while (v) {
                    auto r = rows[64 * z + countr_zero(v)];
                    v &= v - 1;
                    forced |= r.a;
                    avoid |= r.b;
                }
            }
            if ((forced | yes[i]) & (avoid | no[i]))
                return;
            if ((forced & ~yes[i]) || (avoid & ~no[i])) {
                yes[i] |= forced;
                no[i] |= avoid;
                change = true;
            }
        }
        if (change)
            continue;
        Row high;
        for (int i = 0; i < W; i++)
            high[i] = A ^ no[i];
        if (hereditary::bound(yes, high)) {
            ++charge_pruned;
            return;
        }
        if (selected >= 0) {
            auto r = rows[selected];
            for (slot = 3; slot < W; slot++)
                if (!((r.a & no[slot]) | (r.b & yes[slot])))
                    break;
            int free = (r.a | r.b) & ~(yes[slot] | no[slot]);
            bit = free & -free;
        } else {
            for (slot = 0; slot < W; slot++) {
                int f = A & ~(yes[slot] | no[slot]);
                if (f) {
                    bit = f & -f;
                    break;
                }
            }
            if (slot == W) {
                sort(yes.begin(), yes.end());
                ++family_count;
                if(!frontierlib::possible(yes))return;
                for (int x : yes)
                    cout << x << ' ';
                cout << '\n'; std::exit(7);
            }
        }
        break;
    }
    Row alt = yes;
    alt[slot] |= bit;
    visit(alt, no);
    no[slot] |= bit;
    visit(yes, no);
}
// Assign the seven slots after the four dedicated group anchors to a group or to unused.

int main(int argc,char**argv){
 if(argc!=3)return 2;
 frontierlib::selected_E=stoi(argv[1]);
 ifstream fin(argv[2]);int np,nn;fin>>np>>nn;if(np!=28||nn!=245)return 3;
 frontierlib::rawp.resize(np);frontierlib::rawn.resize(nn);
 for(int& x:frontierlib::rawp)fin>>x;for(int& x:frontierlib::rawn)fin>>x;
 hereditary::setup();for(int& v:stars)cin>>v;
 Row y{},n{};for(int i=0;i<3;i++){cin>>y[i];n[i]=A^y[i];role[i]=-i-1;}
 int k,r;cin>>k>>r;nanchors=3+k;
 for(int i=3;i<nanchors;i++)cin>>y[i]>>n[i];
 anchors=y;excluded=n;
 if(r>64*B||nanchors>W)return 2;
 for(int j=0;j<r;j++){
  int a,b;cin>>a>>b;rows.push_back({a,b});U s=U(1)<<(j%64);full[j/64]|=s;
  for(int x=0;x<=A;x++){
   if(x&a)pos[x][j/64]|=s;
   if(!(x&b))neg[x][j/64]|=s;
  }
 }
 visit(y,n);cerr<<"DONE "<<nodes<<" "<<family_count<<endl;
}
