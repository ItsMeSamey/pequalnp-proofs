from pathlib import Path
import sys
from geometry import cases
from models import *
from random import Random
from collections import defaultdict
def instance(directory,e,k,c):
 known=[t if j!=k else t^c for j,t in enumerate(stars) if not (e>>j&1)]
 rows=[set() for _ in range(13)]
 ordinary=[t for j,t in enumerate(stars) if not (e>>j&1)]
 for j,t in enumerate(stars):
  eligible=[n&8191 for n in negative if n&(1<<(13+j))]
  for p in bits(t):
   for x in eligible:
    if not any(m&(1<<p) and not m&x for m in known):rows[p].add(x)
  if e>>j&1:
   sets={8191^t}
   for u in ordinary:
    sets={x&y for x in sets for y in eligible if y&u}
    sets={x for x in sets if not any(x!=y and not x&~y for y in sets)}
   for p in bits(t):rows[p].update(sets)
 rr=[(1<<p,n) for p,ns in enumerate(rows) for n in sorted(ns) if not any(n!=x and not n&~x for x in ns)]
 adj=[sum(1<<i for i,(q,m) in enumerate(rr) if p&m or q&n) for p,n in rr]
 rng=Random(123)
 best=[]
 for it in range(150):
  clique=[];s=(1<<len(rr))-1
  while s:
   idx=[];z=s
   while z:
    b=z&-z;z-=b;idx.append(b.bit_length()-1)
   i=max(idx,key=lambda i:(adj[i]&s).bit_count()+rng.randrange(10))
   clique.append(i);s&=adj[i]
  if len(clique)>len(best):best=clique
  if len(best)>=8:break
 if len(best)>8:return False
 assert all(p&n==0 for p,n in rr)
 assert all(rr[i][0]&rr[j][1] or rr[j][0]&rr[i][1] for i,j in combinations(best,2))
 f=directory/f'{e}-{k}-{c}.in'
 f.write_text(' '.join(map(str,stars+known+[len(best),len(rr)]))+'\n'+''.join(f'{p} {n}\n' for p,n in [rr[i] for i in best]+rr))
 return len(best)
