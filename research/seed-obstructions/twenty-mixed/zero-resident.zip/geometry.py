from models import *
from itertools import permutations
inc=[sum((s>>p&1)<<j for j,s in enumerate(stars)) for p in range(13)]
def im(x,p):return sum(1<<v for i,v in enumerate(p) if x>>i&1)
grp=[]
for g in permutations(range(7)):
 ims=[im(m,g) for m in inc]
 if set(ims)!=set(inc):continue
 q=[inc.index(v) for v in ims]
 def f(r):return im(r&8191,q)|(im(r>>13,g)<<13)
 if {f(x) for x in positive}==positive and {f(x) for x in negative}==negative:grp.append((g,q))
assert len(grp)==24
def orbits(items):
 return {min((im(e,g),g[k],im(x,q)) for g,q in grp) for e,k,x in items}
def cases(n):
 return sorted(orbits((e,k,sum(1<<v for v in vs)) for e in range(128) if e.bit_count()==4 for k,t in enumerate(stars) if not e>>k&1 for vs in combinations(bits(t),n)))
