"""Generate all star-local candidates at eleven gates; rule out earlier primitive outputs."""
from argparse import ArgumentParser
from collections import defaultdict
from pathlib import Path

from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
from input import point_obligations
from samples import actions, raw_samples

BASE = Path(__file__).resolve().parent
statement = BASE / 'L-meta-18968.json'
raw, rows = point_obligations(statement)
raw = set(raw)
stars = [sum(1 << ((6+j+d) % 13) for d in (0,1,3,9)) for j in range(7)]
ordinary = {x for x in range(1,8192) if any(not x & ~t for t in stars)}
group = actions(*raw_samples(statement))

def clauses_on(domain):
    buckets = defaultdict(list)
    for p, n in rows:
        clause = sum(1 << i for i, x in enumerate(domain) if p & x and not n & x)
        buckets[clause].append((p,n))
    minimal = []
    for c in sorted(buckets, key=int.bit_count):
        if not any(not d & ~c for d in minimal):
            minimal.append(c)
    return minimal, buckets

def make_solver(domain, size, clauses, budget=11):
    solver = Solver(name='cadical195')
    pool = IDPool()
    flags = {x:pool.id() for x in domain}
    ordered = list(flags.values())
    add = solver.add_clause
    def bound(xs,n):
        for c in CardEnc.atmost(xs, n, vpool=pool).clauses:
            add(c)
    bound(ordered,size)
    charges = [flags[x] for x in domain if x in ordinary and x.bit_count() >= 2]
    for t in stars:
        hosted = [x for x in domain if x.bit_count() >= 2 and not x & ~t]
        debt1, debt2 = pool.id(), pool.id()
        charges.extend((debt1,debt2))
        for x in hosted:
            others = [flags[y] for y in hosted if y != x]
            if x.bit_count() >= 3:
                add([-flags[x], *others, debt1])
            if x == t:
                add([-flags[x], *others, debt2])
            else:
                add([-flags[t], -flags[x], *[flags[y] for y in hosted if y not in (x,t)], debt1])
    bound(charges,budget)
    for c in clauses:
        add([q for i,q in enumerate(ordered) if c >> i & 1])
    return solver, flags

