"""Point-gate lower-bound check with one nonlocal output and a local core."""
from argparse import ArgumentParser
from collections import defaultdict
from pathlib import Path
from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver

from input import point_obligations
from samples import actions, raw_samples

here = Path(__file__).resolve().parent
path = here / 'L-meta-18968.json'
raw, rows = point_obligations(path)
raw = set(raw)
stars = [sum(1 << ((6 + j + d) % 13) for d in (0, 1, 3, 9)) for j in range(7)]
ordinary = sorted(x for x in range(1, 8192) if any(not x & ~t for t in stars))
assert len(ordinary) == 90
group = actions(*raw_samples(path))

def is_transversal(mask):
    return all((mask & t).bit_count() <= 1 for t in stars)

def required_clauses():
    buckets = defaultdict(list)
    for p, n in rows:
        clause = sum(1 << i for i, x in enumerate(ordinary) if x & p and not x & n)
        buckets[clause].append((p, n))
    minimal = []
    for clause in sorted(buckets, key=int.bit_count):
        if not any(not smaller & ~clause for smaller in minimal):
            minimal.append(clause)
    assert len(minimal) == 184
    requirements = []
    for clause in minimal:
        must = excluded = 0
        for p, n in buckets[clause]:
            must |= p
            excluded |= n
        requirements.append((must, excluded))
    return minimal, requirements

def deleted(mask, requirements):
    return sum(1 << i for i, (must, excluded) in enumerate(requirements)
               if not (must & ~mask or excluded & mask))

def representatives(masks, requirements):
    losses = {m: deleted(m, requirements) for m in masks}
    maximal = []
    for d in sorted(set(losses.values()), key=int.bit_count, reverse=True):
        if all(d & ~other for other in maximal):
            maximal.append(d)
    remaining = set(maximal)
    reps = []
    for mask, loss in losses.items():
        if loss in remaining:
            reps.append((mask, loss))
            remaining.difference_update(deleted(g[mask], requirements) for g in group)
    assert not remaining
    return reps, len(maximal)

def relaxed_cores(clauses, loss, budget):
    pool = IDPool()
    flags = {x: pool.id() for x in ordinary}
    selected = list(flags.values())
    charges = [q for x, q in flags.items() if x.bit_count() >= 2]
    with Solver(name='cadical195') as solver:
        def atmost(literals, limit):
            for c in CardEnc.atmost(literals, limit, vpool=pool).clauses:
                solver.add_clause(c)
        atmost(selected, 10)
        for t in stars:
            hosted = [x for x in ordinary if x.bit_count() >= 2 and not x & ~t]
            h1, h2 = pool.id(), pool.id()
            charges.extend((h1, h2))
            for x in hosted:
                others = [flags[y] for y in hosted if y != x]
                if x.bit_count() >= 3:
                    solver.add_clause([-flags[x], *others, h1])
                if x == t:
                    solver.add_clause([-flags[x], *others, h2])
                if x != t:
                    solver.add_clause([-flags[t], -flags[x],
                        *[flags[y] for y in hosted if y not in (x, t)], h1])
        atmost(charges, budget)
        for i, clause in enumerate(clauses):
            if not loss >> i & 1:
                solver.add_clause([q for j, q in enumerate(selected) if clause >> j & 1])
        while solver.solve():
            model = set(solver.get_model())
            yield tuple(x for x, q in flags.items() if q in model)
            solver.add_clause([-q if q in model else q for q in selected])

def completions(core, only_transversal):
    must = excluded = 0
    for p, n in rows:
        if not any(x & p and not x & n for x in core):
            must |= p
            excluded |= n
    if must & excluded:
        return
    optional = 8191 ^ (must | excluded)
    sub = optional
    while True:
        m = must | sub
        if m and m not in ordinary and (not only_transversal or is_transversal(m)):
            for g in group:
                if g[m] not in raw:
                    yield tuple(sorted([g[m], *[g[x] for x in core]]))
        if not sub:
            break
        sub = (sub - 1) & optional

def main():
    parser = ArgumentParser()
    parser.add_argument('--all', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    trans = not args.all
    masks = [x for x in range(1, 8192) if x not in raw and x not in ordinary
             and (not trans or is_transversal(x))]
    clauses, requirements = required_clauses()
    reps, maximal = representatives(masks, requirements)
    assert (len(masks), maximal, len(reps)) == ((80, 6, 1) if trans else (8083, 116, 14))
    cores = set()
    for mask, loss in reps:
        models = list(relaxed_cores(clauses, loss, 10 if trans else 11))
        print(mask, len(models), flush=True)
        cores.update(models)
    found = {bank for core in cores for bank in completions(core, trans)}
    assert len(cores) == (209 if trans else 1831) and not found
    if args.output:
        args.output.write_text(''.join(' '.join(map(str, x)) + '\n' for x in sorted(found)))
    print(len(masks), 'signatures,', len(reps), 'representatives,', len(cores),
          'distinct cores,', len(found), 'covering banks')

if __name__ == '__main__':
    main()
