from geometry import clauses_on, make_solver, stars, ordinary, raw, group

trans = {x for x in range(1,8192) if all((t&x).bit_count() <= 1 for t in stars)}
extra = sorted(trans - (ordinary | raw))
domain = sorted(trans | ordinary)
clauses,buckets = clauses_on(domain)
def deleted(m):
    return sum(1 << i for i,c in enumerate(clauses)
               if all(p&m and not n&m for p,n in buckets[c]))
loss = {x:deleted(x) for x in extra}
maximal = []
for m in sorted(set(loss.values()),key=int.bit_count,reverse=True):
    if all(m&~other for other in maximal):
        maximal.append(m)
todo = set(maximal)
checked = 0
for m,d in loss.items():
    if d not in todo:
        continue
    todo.difference_update(deleted(g[m]) for g in group)
    solver,_ = make_solver(domain,10,[c for i,c in enumerate(clauses) if not d>>i&1],budget=10)
    assert not solver.solve()
    solver.delete()
    checked+=1
assert len(extra)==len(maximal)==80 and checked==12 and not todo
print('80 candidate distinguished transversal masks, all 12 symmetry-relaxed queries UNSAT.')
