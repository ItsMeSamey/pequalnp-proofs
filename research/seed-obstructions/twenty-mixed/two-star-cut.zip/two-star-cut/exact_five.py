from pathlib import Path
from itertools import combinations
import sys
base=Path(__file__).resolve().parent
src=base.parent/'point-pareto'
sys.path.insert(0,str(src))
from input import point_obligations
raw,rows=point_obligations(src/'L-meta-18968.json')
stars=[708,1416,2832,5664,3137,6274,4357]
ns=[m for m in raw if m.bit_count()>1]
items=[(x,y,o) for x,y in combinations(raw,2) for o in (0,1) if (x|y if o else x&y) not in [0,*raw]]
cover=[sum(1<<i for i,(x,y,o) in enumerate(items) if (p&(x|y) and not n&(x|y) if o else p&x&y and not (n&x and n&y))) for p,n in rows]
from functools import lru_cache
from collections import Counter
adj={}
for item_id,(x,y,o) in enumerate(items):
 mask=x|y if o else x&y
 key=(x,y)
 cv=sum(1<<j for j,q in enumerate(cover) if q>>item_id&1)
 adj.setdefault(key,[]).append((mask,cv,int(all(mask&~t for t in stars))))
@lru_cache(None)
def d(F,i):
 p=1<<i
 touched=[m for k,m in enumerate(ns) if F>>k&1 and m&p]
 neg=[n for q,n in rows if p==q and all(n&m for m in touched)]
 if not neg:return 0
 for k in range(1,14):
  for bits in combinations([j for j in range(13) if j!=i],k):
   w=sum(1<<j for j in bits)
   if all(w&~n for n in neg):return k
def match(tokens,target,used,nl):
 if not tokens:return not target and nl
 x=tokens[0]
 for j in range(1,len(tokens)):
  y=tokens[j]
  if j>1 and y==tokens[j-1]:continue
  for m,c,l in adj.get((min(x,y),max(x,y)),[]):
   if m in used:continue
   if match(tokens[1:j]+tokens[j+1:],target&~c,used|{m},nl|l):return True
 return False
tot=surv=0
for line in (base/'twostar-sources.txt').read_text().splitlines():
 a,b,S,F,t=map(int,line.split());A,B=stars[a],stars[b]
 tok=[m for j,m in enumerate(ns) if F>>j&1]
 for i in range(13):
  g=((A>>i)&1)+((B>>i)&1)
  tok += [1<<i]*max(0,(0 if S>>i&1 else d(F,i))-g)
 assert len(tok)==10
 target=sum(1<<j for j,(p,n) in enumerate(rows) if not (p&S or (p&A and not n&A) or (p&B and not n&B)))
 if match(sorted(tok),target,{A,B},0):
  print('surv',line,flush=True);surv+=1
 tot+=1
print('total',tot,surv)

assert (tot,surv)==(660,0)
