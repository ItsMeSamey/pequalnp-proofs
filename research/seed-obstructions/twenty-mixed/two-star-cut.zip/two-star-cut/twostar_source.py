from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'nonlocal-seven'))
from operand_audit import *
from itertools import combinations
from collections import Counter
stars=[708,1416,2832,5664,3137,6274,4357];ids=np.flatnonzero(size+ordered[:,:9].sum(axis=1)<=18)
v=per[ids];fsize=size[ids];hist=Counter();path=Path(__file__).with_name('twostar-sources.txt')
print('initial frozen sets',len(ids),flush=True)
with path.open('w') as out:
 for a,b in combinations(range(7),2):
  g=np.array([((stars[a]>>d)&1)+((stars[b]>>d)&1) for d in range(13)],dtype=np.int16)
  current=np.maximum(v,g);inn=fsize+current.sum(axis=1)
  for ss in combinations(range(13),4):
   total=inn+g[list(ss)].sum()-current[:,list(ss)].sum(axis=1)
   for j in np.flatnonzero(total<=18):
    print(a,b,sum(1<<d for d in ss),int(ids[j]),int(total[j]),file=out);hist[(a,b,int(total[j]))]+=1
  print(a,b,[hist[a,b,k] for k in range(16,19)],flush=True)
print('total',sum(hist.values()))
assert sum(hist.values())==660 and all(k==18 for (a,b,k) in hist if hist[a,b,k])
