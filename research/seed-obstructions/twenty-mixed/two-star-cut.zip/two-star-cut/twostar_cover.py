from itertools import combinations
from pathlib import Path
import sys
from functools import lru_cache
base=Path(__file__).resolve().parent
sys.path.insert(0,str(base.parent/'point-pareto'))
from input import point_obligations
raw,rows=point_obligations(Path(sys.path[0])/'L-meta-18968.json')
ns=[m for m in raw if m.bit_count()>1]
stars=[708,1416,2832,5664,3137,6274,4357]
def coverage(a,b,op):
 mask=(a|b) if op else (a&b)
 return sum(1<<k for k,(p,n) in enumerate(rows) if mask&p and (not n&(a|b) if op else not (n&a and n&b)))
bank={(a,b,op):coverage(a,b,op) for a,b in combinations(raw,2) for op in (0,1) if (a|b if op else a&b) not in [0,*raw]}
single={a:coverage(a,a,1) for a in [*raw,*stars]}
allrows=(1<<len(rows))-1
def solve(target,cands,nonlocal_candidates):
 cs=list(set(c&target for c in cands)-{0})
 union=0
 for c in cs:union|=c
 if target&~union:return False
 byrow={i:[j for j,c in enumerate(cs) if c>>i&1] for i in range(len(rows)) if target>>i&1}
 order=sorted(byrow,key=lambda i:len(byrow[i]))
 @lru_cache(None)
 def rec(t,k):
  if not t:return True
  if not k:return False
  i=next(i for i in order if t>>i&1)
  return any(rec(t&~cs[j],k-1) for j in byrow[i])
 return any(rec(target&~c,4) for c in nonlocal_candidates)
surv=[]
for line in (base/'twostar-sources.txt').read_text().splitlines():
 a,b,S,F,t=map(int,line.split());assert t==18
 avail={m for m in raw if m.bit_count()==1}|{m for j,m in enumerate(ns) if F>>j&1}
 target=allrows&~(single[stars[a]]|single[stars[b]])
 for i in range(13):
  if S>>i&1:target &=~single[1<<i]
 cs=[c for (x,y,op),c in bank.items() if x in avail and y in avail]
 nonlocal_candidates=[c for (x,y,op),c in bank.items() if x in avail and y in avail and all((x|y if op else x&y)&~star for star in stars)]
 if solve(target,cs,nonlocal_candidates):surv.append(line)
print('survivors',len(surv),surv[:5],flush=True)
assert not surv, "nonlocal bank survived"
