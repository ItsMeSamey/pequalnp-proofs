from itertools import combinations
from pathlib import Path
from subprocess import run, PIPE
from tempfile import TemporaryDirectory
import sys
from inputs import P,N,stars
from samples import actions
from envelope import model

here=Path(__file__).resolve().parent
group=actions(P,N)
def move(E,f):
 return sum(1<<stars.index(f[s]) for i,s in enumerate(stars) if E>>i&1)
reps=sorted({min(move(E,f) for f in group) for E in range(128) if E.bit_count()==4})
assert reps==[15,23,27,46,83]
if '--small' in sys.argv:
 for E in reps:
  for b in range(8):
   status,_=model(E,b,0,10000000,2)
   print(E,b,status,flush=True)
   assert status in ('COUNT','UNSAT')
 sys.exit(0)
packets=set()
for E in reps:
 fixed=[s for i,s in enumerate(stars) if not E>>i&1]
 for k in range(4):
  result=run([sys.executable,str(here/'saturation.py'),str(E),str(k)],stdout=PIPE,text=True,check=True)
  for line in result.stdout.splitlines():
   free=list(map(int,line.split()))
   assert len(free)==8
   for a,b in combinations([1<<i for i in range(7) if E>>i&1],2):
    packets.add((*sorted(fixed+free),a+b))
assert len(packets)==12
rows=' '.join(map(str,[len(P),len(N),*sorted(P),*sorted(N)]))
with TemporaryDirectory() as tmp:
 exe=Path(tmp)/'frontier'
 run(['g++','-O3','-std=c++17',str(here/'frontier.cpp'),'-o',str(exe)],check=True)
 for packet in sorted(packets):
  bank=[*packet[:11],1,2,4,8,16,32,64,packet[-1]]
  data=rows+'\n1 11 8 2\n'+' '.join(map(str,bank))+'\n'
  result=run([str(exe)],input=data,stdout=PIPE,text=True,check=True)
  print(packet,result.stdout.strip(),flush=True)
