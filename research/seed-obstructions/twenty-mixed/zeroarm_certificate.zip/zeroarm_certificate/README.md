# Width eleven with one distinguished special target

Use the seven residual target stars of L-meta-18968 and a bank of eleven physical point-side slots. Four ordinary stars have pairwise disjoint, read-once point expressions using at most six slots in total. On its four target singletons each ordinary expression accepts; on every pair of distinct exterior points it rejects. All eleven slots together cover the 1,323 raw point obligations.

Distinguish one of the other three targets as X, and call the other two T and U. Among the slots outside the four ordinary expressions require two properties.

* For each singleton positive on T or U, the outside slots distinguish it from every maximal negative that contains its line coordinate and whose point set meets all five stars consisting of X and the four ordinary stars.
* For each singleton point on X, these slots distinguish it from every pair of distinct points exterior to X. The requirement on exterior singletons follows by monotonicity.

These conditions force at least 14 paid point gates. Application to the mixed topology with two singleton-resident endpoints and one line-free endpoint uses the separate envelope and attachment arguments establishing the two properties.

## Finite proof

Monotonicity lets us assign every slot the 13-bit mask of singletons it accepts. To distinguish a positive singleton p from a point set n, a slot must contain p in its mask and have mask disjoint from n. The verifier decodes the actual instance, verifies its statement hash and extra conditions, constructs the raw and outside-slot obligations, and computes joint point/line symmetries. For a given p only inclusion-maximal negative point sets in each class need be retained.

Each one-slot ordinary expression has mask equal to its target. A two-slot expression uses OR or AND. In the latter case one operand must have exact target mask: both contain the target, and if both have some exterior point then one from each, extended to two distinct exterior points if necessary, makes the AND true on an exterior pair. Retain one exact mask as the ordinary slot and permit the other to help the outside bank. This weakens the abstract coverage requirements. Exact ordinary slots need only their singleton masks in the resulting search. With three slots the expression is either OR of three, AND of three, (x AND y) OR z, or (x OR y) AND z, up to ordering. The four disjoint groups therefore normalize to four exact slots, three exact and one OR pair, two exact and two OR pairs, or three exact and one of the four ternary formulas.

Four exact slots are excluded by the embedded fourgroups14 computation using their exact singleton signatures and global raw coverage. On the other configurations the verifier forms orbits of the seven target roles, including the distinguished X. It grants all 55 free point masks in the orbit of the original 31 primitives under the 24 sample symmetries. The C++ checker completely searches the resulting mask intervals over eleven labelled slots up to interchangeable outside slots. It enforces the singleton and exterior-pair restrictions of each ordinary expression, propagates coverage if only one slot can meet an obligation, and branches in both directions on a remaining singleton bit. Incompatible outside-slot obligations are used to anchor distinct outside slots. The anchor construction verifies incompatibility before use.

For each subset J of the seven targets the search projects to their union. The prior 3|J| bound permits any mask meeting each projected star at most once as a free input. Deleted paid gates whose masks become transversals or duplicate an earlier projected mask can contribute to the bound. Distinctness of counted paid gates is guaranteed by disjoint intervals before projection. Each known ordinary expression on m operands reconstructs that target with at most m−1 additional gates on this projection. The checker also tests recoveries arising from clean pairs, triples, complementary pairs, full masks, or two supersets with no remaining common exterior point. If h disjoint paid gates disappear and the targets in J need at most d extra gates from the remaining signals, the original circuit costs at least 3|J|−d+h. This is the same C++ checker as in the three-singleton-endpoint certificate. Only the definition of the outside-slot obligations and the role symmetries change.

## Replay

Run python verify.py using Python 3 and a C++20 compiler with native unsigned 128-bit arithmetic. Use python verify.py --with-prior to replay the embedded canonical-four computation too. The included fourgroups14.zip contains the prior seven-target projection proof and its own complete reproduction instructions.

The release run exhausted 143 noncanonical role configurations in 2,289,037 nodes with zero survivors. The eight all-exact configurations with distinguished X are covered by the prior five symmetry orbits of undistinguished quartets.
