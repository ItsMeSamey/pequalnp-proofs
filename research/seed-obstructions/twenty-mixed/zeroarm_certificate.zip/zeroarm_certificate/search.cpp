#include "hereditaryrole.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <fstream>
#include <set>
#include <vector>
using namespace std;
constexpr int W = 11, A = 8191, B = 32;
using U = uint64_t;
using Row = array<int, W>;
using Bits = array<U, B>;
struct R {
    int a, b;
};
vector<R> rows;
Bits pos[8192]{}, neg[8192]{}, full{};
int stars[7];
uint64_t family_count = 0, nodes = 0, charge_pruned = 0;
Row anchors{}, excluded{};
uint64_t stars_pruned = 0;
int fixedfour, nanchors;
int role[11], gsz[7];
uint64_t ncase = 0;

int freew,forced;
int form[7],off[7];
Bits allow[W];
int sz(int f) { return !f?0:f==1?1:(f==2||f==7)?2:3; }
int fn(int f,int a,int b,int c) {
 switch(f) {
 case 1:return a; case 2:return a|b; case 3:return a|b|c;
 case 4:return a&b&c; case 5:return (a&b)|c; case 6:return (a|b)&c;
 case 7:return a&b; default:abort();
 }
}
int propagate(Row &lo,Row &no) {
 bool ch=false;
 for(int t=0;t<7;t++) if(form[t]>1){
  int k=off[t],f=form[t],n=sz(f),T=stars[t];
  int v[3]{},h[3]{};
  for(int i=0;i<n;i++)v[i]=lo[k+i],h[i]=A^no[k+i];
  if((fn(f,v[0],v[1],v[2])&~T)||(T&~fn(f,h[0],h[1],h[2])))return -1;
  for(int i=0;i<n;i++){
   int old=h[i];h[i]=0;int must=T&~fn(f,h[0],h[1],h[2]);h[i]=old;
   int org=v[i];v[i]=A;int ban=~T&fn(f,v[0],v[1],v[2]);v[i]=org;
   if((must&~org)||(ban&old)){lo[k+i]|=must;no[k+i]|=ban;ch=true;}
  }
  if(f!=2&&f!=3){
   for(int x=A&~T;x;x&=x-1)for(int y=x&(x-1);y;y&=y-1){
    int pair=(x&-x)|(y&-y),bb[3]{};
    for(int i=0;i<n;i++) bb[i]=bool(v[i]&pair);
    if(fn(f,bb[0],bb[1],bb[2]))return -1;
    for(int i=0;i<n;i++)if(!bb[i]){
     bb[i]=1;int ban=fn(f,bb[0],bb[1],bb[2])?pair:0;bb[i]=0;
     if(ban&~no[k+i]){no[k+i]|=ban;ch=true;}
    }
   }
  }
 }
 return ch;
}
void visit(Row yes, Row no) {
    if (++nodes % 1000000 == 0)
        cerr << nodes << " nodes " << family_count << " surviving families " << charge_pruned
             << " charge-pruned nodes " << stars_pruned << " recovery-pruned nodes" << endl;
    int slot = -1, bit = 0;
    for (;;) {
        for (int i = nanchors; i + 1 < freew; i++)
            if (role[i] == role[i + 1] && yes[i] > (A ^ no[i + 1]))
                return;
        for (int j = nanchors; j < W; j++)
            for (int i = 0; i < nanchors; i++) {
                if (role[i] == role[j] && !(anchors[i] & ~yes[j]) && !(excluded[i] & ~no[j]) &&
                    (A ^ no[j]) < yes[i])
                    return;
            }
        // For each slot and witness row track possible coverage, guaranteed
        // coverage, and coverage forced onto this slot.
        Bits can[W], sole[W];
        bool change = false;
        int selected = -1, best = W + 1;
        int fullstars = 0;
        for (int i = 0; i < W; i++)
            if ((yes[i] | no[i]) == A)
                for (int l = 0; l < 7; l++)
                    if (yes[i] == stars[l])
                        fullstars |= 1 << l;
        if (popcount((unsigned)fullstars) >= 5)
            return;
        int prop = propagate(yes, no);
        if (prop < 0) {
            ++stars_pruned;
            return;
        }
        if (prop)
            continue;
        for (int z = 0; z < B; z++) {
            U c = 0, mc = 0, g = 0;
            for (int i = 0; i < W; i++) {
                U x = can[i][z] = allow[i][z] & pos[A ^ no[i]][z] & neg[yes[i]][z];
                U y = allow[i][z] & pos[yes[i]][z] & neg[A ^ no[i]][z];
                mc |= c & x;
                c |= x;
                g |= y;
            }
            if (c != full[z])
                return;
            for (int i = 0; i < W; i++) {
                sole[i][z] = can[i][z] & ~(mc | g);
            }
            if (best == 2)
                continue;
            U opt = full[z] & ~g & mc;
            while (opt) {
                int b = countr_zero(opt), ct = 0;
                for (int i = 0; i < W && ct < best; i++)
                    ct += (can[i][z] >> b) & 1;
                if (ct < best) {
                    best = ct;
                    selected = z * 64 + b;
                }
                opt &= opt - 1;
                if (best == 2)
                    break;
            }
        }
        for (int i = 0; i < W; i++) {
            int forced = 0, avoid = 0;
            for (int z = 0; z < B; z++) {
                U v = sole[i][z];
                while (v) {
                    auto r = rows[64 * z + countr_zero(v)];
                    v &= v - 1;
                    forced |= r.a;
                    avoid |= r.b;
                }
            }
            if ((forced | yes[i]) & (avoid | no[i]))
                return;
            if ((forced & ~yes[i]) || (avoid & ~no[i])) {
                yes[i] |= forced;
                no[i] |= avoid;
                change = true;
            }
        }
        if (change)
            continue;
        Row high;
        for (int i = 0; i < W; i++)
            high[i] = A ^ no[i];
        if (hereditary::bound(yes, high)) {
            ++charge_pruned;
            return;
        }
        if (selected >= 0) {
            auto r = rows[selected];
            for (slot = 0; slot < W; slot++)
                if ((selected>=forced || slot<freew) && !((r.a & no[slot]) | (r.b & yes[slot])))
                    break;
            int free = (r.a | r.b) & ~(yes[slot] | no[slot]);
            bit = free & -free;
        } else {
            for (slot = 0; slot < W; slot++) {
                int f = A & ~(yes[slot] | no[slot]);
                if (f) {
                    bit = f & -f;
                    break;
                }
            }
            if (slot == W) {
                sort(yes.begin(), yes.end());
                ++family_count;
                for (int x : yes)
                    cout << x << ' ';
                cout << '\n';
                return;
            }
        }
        break;
    }
    Row alt = yes;
    alt[slot] |= bit;
    visit(alt, no);
    no[slot] |= bit;
    visit(yes, no);
}

int main(){
 hereditary::setup();
 for(int t=0;t<7;t++)stars[t]=hereditary::target[t];
 freew=W;
 for(int &f:form){cin>>f;freew-=sz(f);}
 Row y{},n{};
 int off0=freew;
 for(int t=0;t<7;t++)if(int f=form[t]){
  hereditary::known_groups[t]=sz(f);off[t]=off0;
  for(int i=0;i<sz(f);i++){
   if(f==1)y[off0]=stars[t],n[off0]=A^stars[t];
   role[off0++]=t+1;
  }
 }
 cin>>nanchors;
 if(nanchors>freew){cerr<<"PACKED"<<endl;return 0;}
 for(int i=0;i<nanchors;i++)cin>>y[i]>>n[i];
 anchors=y;excluded=n;
 cin>>forced;
 int a,b;while(cin>>a>>b) rows.push_back({a,b});
 if(rows.size()>64*B)abort();
 for(int j=0;j<(int)rows.size();j++) {
  auto [p,n]=rows[j];uint64_t bit=uint64_t(1)<<(j%64);
  full[j/64]|=bit;
  for(int i=0;i<W;i++)if(j>=forced||i<freew)allow[i][j/64]|=bit;
  for(int m=0;m<=A;m++){
   if(m&p)pos[m][j/64]|=bit;
   if(!(m&n))neg[m][j/64]|=bit;
  }
 }
 visit(y,n);
 cerr<<"DONE "<<nodes<<" "<<family_count<<endl;
}
