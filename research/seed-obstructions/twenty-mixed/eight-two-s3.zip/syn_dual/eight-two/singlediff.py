from four import *
from essential import cert
n=0
for I in combinations(range(7),3):
 if lines[I[0]]&lines[I[1]]&lines[I[2]]:continue
 s=sum(1<<i for i in I)
 ns=[(q,l) for q,l in neg if l&s]
 for f in I:
  a,b=set(I)-{f};cut=lines[a]&lines[b];c=cut.bit_length()-1
  assert any(row[0]==c for row in cert)
  flags(ns,cut,lambda i,j:i in I or j not in I or j==f)
  for t in set(range(7))-set(I):
   assert not badpoints(ns,[lines[t],lines[f]],cut)
   for y in set(range(7))-{f,t}:
    for u,v in combinations(set(range(7))-{y},2):
     assert any(l>>y&1 and q&lines[u]&~cut and q&lines[v]&~cut for q,l in ns),(I,f,t,y,u,v)
    for p in range(13):
     if p==c or lines[y]>>p&1:continue
     if y in I:
      for u,v in combinations(set(range(7))-{y},2):
       assert any(l>>y&1 and q>>p&1 and q&lines[u]&~cut and q&lines[v]&~cut for q,l in ns)
    for p in badpoints(ns,[lines[y]],cut):assert y in I and p!=c
    n+=1
print(n)
