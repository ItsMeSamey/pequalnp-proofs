from four import combinations,lines,neg,badpoints
n=0
for I in combinations(range(7),3):
 if lines[I[0]]&lines[I[1]]&lines[I[2]]:continue
 ns=[(q,l) for q,l in neg if any(l>>i&1 for i in I)]
 for i in I:
  a,b=set(I)-{i}
  assert badpoints(ns,[lines[i]])=={(lines[a]&lines[b]).bit_length()-1}
 n+=1
assert n==29
print(n,'triangle supports checked')
