from itertools import permutations,combinations
from collections import Counter
from three import lines,neg,run
from four import badpoints
def moved(mask,pi):return sum(((mask>>j)&1)<<k for j,k in enumerate(pi))
labels=[sum(((t>>p)&1)<<i for i,t in enumerate(lines)) for p in range(13)]
group=[]
for pi in permutations(range(7)):
 other=[moved(x,pi) for x in labels]
 if set(other)!=set(labels):continue
 pts=[labels.index(x) for x in other]
 assert {(moved(p,pts),moved(l,pi)) for p,l in neg}==neg
 group.append(pi)
assert len(group)==24
counts=Counter()
for I in combinations(range(7),4):
 f=sum(1<<i for i in I);ns=[(q,l) for q,l in neg if l&f]
 bad=[i for i,s in enumerate(lines) if badpoints(ns,[s])]
 if not bad:continue
 for ab in combinations(set(range(7))-set(I),2):
  spec=(1<<bad[0])|sum(1<<i for i in ab)
  counts[min((moved(f,g),moved(spec,g)) for g in group)]+=1
assert sum(counts.values())==72
if __name__=='__main__':
 for (f,spec),n in sorted(counts.items()):
  arms=tuple(i for i in range(7) if spec>>i&1)
  print(f,arms,n,flush=True);run(f,arms,4)
