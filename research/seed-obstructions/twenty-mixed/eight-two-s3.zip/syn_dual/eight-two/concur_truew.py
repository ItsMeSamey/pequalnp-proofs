from three import lines, neg
from orbits import group,moved
from itertools import combinations, product
from pysat.solvers import Solver
from pysat.formula import CNF,IDPool
from collections import Counter
def setup(s,arms):
 c=next(p for p in range(13) if all(t>>p&1 for i,t in enumerate(lines) if s>>i&1))
 ordinary=[t for i,t in enumerate(lines) if i not in arms]
 ns=[]
 for j in arms:
  by=[]
  for u in ordinary:
   down={0}
   for q,l in neg:
    if not(l>>j&1 and q&u&~(1<<c) and q&lines[W]):continue
    if (s>>j)&1 and not l&s:continue
    q &= ~(1<<c)
    Q=q
    while Q:
     down.add(Q);Q=(Q-1)&q
   by.append(down)
  down=set.intersection(*by)
  ns.append({q for q in down if not any(q!=r and not q&~r for r in down)})
 return c,ns
def instance(s,arms,b,lo):
 c,negatives=setup(s,arms)
 P=IDPool();C=CNF(); cache={}; one=P.id('one');C.append([one])
 def gate(xs,o):
  xs=tuple(sorted(set(xs)-({one} if o==0 else {-one})))
  if (-one if o==0 else one) in xs:return -one if o==0 else one
  if len(xs)==1:return xs[0]
  if not xs:return one if o==0 else -one
  if (xs,o) in cache:return cache[xs,o]
  v=P.id((xs,o));cache[xs,o]=v
  if o==0:
   for x in xs:C.append([-v,x])
   C.append([v,*[-x for x in xs]])
  else:
   for x in xs:C.append([v,-x])
   C.append([-v,*xs])
  return v
 raw=[[P.id(('f',i,p)) if p!=c else -one for p in range(13)] for i in range(b)]
 for j,ns in zip(arms,negatives):
  for q in ns:
   dis=[gate([-x for k,x in enumerate(f) if q>>k&1],0) for f in raw]
   for p in range(13):
    if p!=c and lines[j]>>p&1:C.append([gate([f[p],d],0) for f,d in zip(raw,dis)])
 ordinary=[t for i,t in enumerate(lines) if i not in arms]
 bank=raw+[[one if t>>p&1 else -one for p in range(13)] for t in ordinary]
 def exclude(w,d):
  for j,L in zip(arms,lo):
   need=5+d-L
   if need>4:continue
   inside=[x for k,x in enumerate(w) if lines[j]>>k&1];out=[x for k,x in enumerate(w) if not lines[j]>>k&1]
   for ch in combinations(inside,need):C.append(out+[-x for x in ch])
 for x in bank:exclude(x,0)
 for x,y in combinations(bank,2):
  for o in (0,1):
   w=[gate(ls,o) for ls in zip(x,y)];exclude(w,1)
   if max(lo)<3:continue
   for z in bank:
    if z in (x,y):continue
    for t in (0,1):exclude([gate(ls,t) for ls in zip(w,z)],2)
 with Solver(name='cadical195',bootstrap_with=C.clauses) as sol:
  if not sol.solve():return None
  mod=set(sol.get_model());return [sum((x in mod)<<k for k,x in enumerate(f)) for f in raw]
def check(s,arms,b):
 a=sum(s>>i&1 for i in arms);budget=a+b
 if budget>=6:return True
 for v in range(4):
  w=budget+1-v
  if not 0<=w<=3:continue
  witness=instance(s,arms,b,(v,w))
  if witness:
   print('OPEN',s,arms,b,(v,w),witness,flush=True);return False
 print('PASS',s,arms,b,flush=True);return True
def candidates():
 ans=Counter()
 for I in combinations(range(7),3):
  if not (lines[I[0]]&lines[I[1]]&lines[I[2]]):continue
  s=sum(1<<i for i in I)
  for ab in combinations(range(7),2):
   arms=sum(1<<i for i in ab);k=min((moved(s,g),moved(arms,g)) for g in group)
   ans[k]+=1
 return ans
if __name__=='__main__':
 for ab,b in [((1,4),5),((1,5),5),((4,6),4),((4,6),5)]:
  for W in set(range(7))-set(ab)-{0,2,3}:
   print('W',W,flush=True);check(13,ab,b)
