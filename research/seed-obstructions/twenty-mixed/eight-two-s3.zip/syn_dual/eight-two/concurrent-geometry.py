from four import *
n=0
for I in combinations(range(7),3):
 if not lines[I[0]]&lines[I[1]]&lines[I[2]]:continue
 s=sum(1<<i for i in I)
 for y in range(7):
  for a,b in combinations(set(range(7))-{y},2):
   assert any(l&s and l>>y&1 and q&lines[a] and q&lines[b] for q,l in neg)
   n+=1
assert n==630
print(n,'two-witness existence checks')
