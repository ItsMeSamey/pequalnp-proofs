from four import *
from essential import cert
h=0
checked=set()
for I in combinations(range(7),3):
 if lines[I[0]]&lines[I[1]]&lines[I[2]]:continue
 S=set(I);ns=[(q,l) for q,l in neg if any(l>>i&1 for i in I)]
 for f1,f2 in combinations(I,2):
  a,b=S-{f1};cut=lines[a]&lines[b];c=cut.bit_length()-1
  assert any(row[0]==c for row in cert)
  for t1 in set(range(7))-S:
   for t2 in set(range(7))-S-{t1}:
    if (I,f1) not in checked:
     flags(ns,cut,lambda i,j: i in S or j not in S or j==f1)
     checked.add((I,f1))
    for f,t in ((f1,t1),(f2,t2)):
     assert not badpoints(ns,[lines[f],lines[t]],cut)
    assert any(l>>t2&1 and q&lines[f2]&~cut for q,l in ns)
    h+=1
print(h,'ordered two-region checks')
