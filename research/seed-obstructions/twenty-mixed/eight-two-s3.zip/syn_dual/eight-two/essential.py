from itertools import combinations
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'eightplus'))
from samples import neg,lines
primitive=set(1<<j for j in range(13))
for j in range(6):
 a=(1<<j)|(1<<(j+1));b=(1<<(j+3))|(1<<((j+9)%13))
 primitive.update((a,b,a|b))
cert=[]
for p in range(13):
 P=1<<p
 matches=[(t,q,l) for t,T in enumerate(lines) if P&T for q,l in sorted(neg)
          if l>>t&1 and [f for f in primitive if f&P and not f&q]==[P]]
 if not matches:continue
 cert.append((p,*matches[0]))
print(cert)
