"""A counterexample lacks every cheap witness on each of its two target arms."""
from itertools import combinations
from pathlib import Path
import sys
from pysat.formula import CNF, IDPool
from pysat.solvers import Solver

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'eightplus'))
from samples import lines, neg

def counterexample(arms, flags, b, thresholds):
    formula = CNF()
    pool = IDPool()
    features = [[pool.id(('feature', i, p)) for p in range(13)] for i in range(b)]
    cache = {}
    def gate(literals, operation):
        literals = tuple(sorted(set(literals)))
        if len(literals) == 1:
            return literals[0]
        key = operation, literals
        if key in cache:
            return cache[key]
        result = pool.id(key)
        cache[key] = result
        if operation == 'AND':
            for x in literals:
                formula.append([-result, x])
            formula.append([result] + [-x for x in literals])
        else:
            for x in literals:
                formula.append([result, -x])
            formula.append([-result, *literals])
        return result

    for t in arms:
        negatives = {q for q,l in neg if (l>>t)&1 and l&flags and
                     all(q&v for i,v in enumerate(lines) if i not in arms)}
        for q in negatives:
            if any(q != r and not q & ~r for r in negatives):
                continue
            disjoint = [gate((-a for j,a in enumerate(row) if (q>>j)&1), 'AND')
                        for row in features]
            for p in range(13):
                if (lines[t]>>p)&1:
                    formula.append([gate((row[p], d), 'AND') for row,d in zip(features,disjoint)])

    def exclude_cheap_output(row, gates):
        for t,th in zip(arms,thresholds):
            inside = [x for p,x in enumerate(row) if (lines[t]>>p)&1]
            outside = [x for p,x in enumerate(row) if not (lines[t]>>p)&1]
            for subset in combinations(inside, 4+gates-th):
                formula.append(outside + [-x for x in subset])

    for row in features:
        exclude_cheap_output(row, 0)
    for r,s in combinations(features, 2):
        for op in ('AND','OR'):
            w = [gate(x,op) for x in zip(r,s)]
            exclude_cheap_output(w, 1)
            for h in features:
                if h in (r,s):
                    continue
                for op2 in ('AND','OR'):
                    exclude_cheap_output([gate(x, op2) for x in zip(w,h)], 2)
    return formula, features


def run(S,arms,b):
    from itertools import permutations
    cases=[(2,2,2)] if b==5 else set(permutations((1,2,2)))
    for thresholds in sorted(cases):
        cnf,features=counterexample(arms,S,b,thresholds)
        with Solver(name='cadical195', bootstrap_with=cnf.clauses) as solver:
            if solver.solve():
                model=set(solver.get_model());ret=[sum((x in model)<<p for p,x in enumerate(row)) for row in features]
                print(S,arms,b,thresholds,ret,flush=True);return False
    print(S,arms,b,'UNSAT',flush=True);return True
if __name__=='__main__':
    run(15,(1,4,5),4);run(15,(1,4,5),5)
