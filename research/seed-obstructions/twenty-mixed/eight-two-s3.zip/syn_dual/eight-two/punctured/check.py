from itertools import combinations
from collections import Counter
from pathlib import Path
import sys
from basic import model as plain
from envelope import model as projected
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from orbits import group,moved,lines
d=Counter()
for I in combinations(range(7),3):
 c=lines[I[0]]&lines[I[1]]&lines[I[2]]
 if not c:continue
 s=sum(1<<i for i in I)
 for h in I:
  for ab in combinations(set(range(7))-set(I),2):
   a=sum(1<<i for i in (h,*ab))
   d[min((moved(s,g),moved(a,g)) for g in group)]+=1
for (s,a),n in sorted(d.items()):
 labels=[i for i in range(7) if s>>i&1]
 c=lines[labels[0]]&lines[labels[1]]&lines[labels[2]]
 for b in range(8):
  solve=plain if b==7 else projected
  k,v=solve(a,b,1,30000,1,c)
  print(s,a,n,b,k,flush=True)
