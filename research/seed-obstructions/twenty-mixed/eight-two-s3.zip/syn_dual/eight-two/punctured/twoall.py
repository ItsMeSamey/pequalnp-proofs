from itertools import combinations
from collections import Counter
from pathlib import Path
import sys
from basic import model as plain
from envelope import model as projected
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from concurrent import candidates,lines
for (s,m),n in sorted(candidates().items()):
 ids=[i for i in range(7) if s>>i&1];c=lines[ids[0]]&lines[ids[1]]&lines[ids[2]];a=(s&m).bit_count()
 for b in range(1+min(6,5-a)):
  solve=plain if b==6 else projected
  k,_=solve(m,b,0,30000,a,c)
  print(s,m,n,b,k,flush=True)
