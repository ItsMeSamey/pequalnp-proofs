from bank import *
for s in (15,23,27,46,83,31,47,87,63,95):
 o=7-s.bit_count()
 for b in range(3,min(11-o,21-4*o)+1):
  print(s,b,model(s,b),flush=True)
