from pysat.solvers import Solver
from pysat.formula import IDPool
from pysat.card import CardEnc
from itertools import combinations
from collections import Counter
from functools import lru_cache
from pathlib import Path
import sys
import os
source=Path(os.environ.get('POINT_PARETO_SOURCE','/workspace/scratch/synthesis_new/point-pareto'))
sys.path.insert(0,str(source));from input import raw_samples
positive,negative,_=raw_samples(source/'L-meta-18968.json')
stars=[sum({p&8191 for p in positive if p>>(13+j)&1}) for j in range(7)]
projective=[sum(1<<((j+d)%13) for d in (0,1,3,9)) for j in range(13)]
def bits(s):return [i for i in range(13) if s>>i&1]
def model(E,b,oplim=0):
 special=[s for i,s in enumerate(stars) if E>>i&1];o=7-len(special);slack=21-4*o-b
 if slack<0:return None
 P=IDPool();cnf=[]
 def lit(x):return P.id(x)
 def ors(v):
  z=lit(('or',*sorted(v)));cnf.extend([[-q,z] for q in v]+[[-z,*v]]);return z
 def ands(v):return -ors([-q for q in v])
 def cap(v,k):
  return CardEnc.atmost(v,k,vpool=P).clauses if 0<=k<len(v) else [] if k>=len(v) else [[]]
 z=[[lit((i,j))for j in range(13)]for i in range(b)]
 def ub(i,mask):return ands([-z[i][j] for j in bits(8191^mask)])
 for i in range(b-1):
  eq=[]
  for j in reversed(range(13)):
   x,y=z[i][j],z[i+1][j];cnf.append([-r for r in eq]+[-x,y])
   eq.append(ands([ors([x,-y]),ors([-x,y])]))
 for t in special:
  j=stars.index(t)
  eligible=[n&8191 for n in negative if (n>>13)&(1<<j)]
  ordinary=[v for v in stars if v not in special]
  # Maximal point sets guaranteed rejected by every OR summand, since its
  # ancestor guards use a common ordinary resident (possibly different
  # witnesses across attachments).
  sets={8191^t}
  for u in ordinary:
   sets={x&y for x in sets for y in eligible if y&u}
   sets={x for x in sets if not any(x!=y and not x&~y for y in sets)}
  sets=set(eligible)
  for v in bits(t):
   for X in sets:
    cnf.append([ands([zz[v],*[-zz[x] for x in bits(X)]]) for zz in z])
 ext=[-ors([ub(i,t) for t in projective])for i in range(b)]
 clean=[]
 savings=[]
 for t in special:
  flags=[lit(('save',t,j)) for j in range(3)];savings+=flags
  for i,zz in enumerate(z):
   c=ub(i,t)
   for n in range(2,5):
    for vs in combinations(bits(t),n):cnf.append([-c,*[-zz[v] for v in vs],flags[n-2]])
  for j in range(2):cnf.append([-flags[j+1],flags[j]])
 for i,zz in enumerate(z):
  n2=ors([ands([zz[x],zz[y]])for x,y in combinations(range(13),2)])
  clean.append(ands([n2,ors([ub(i,t) for t in special])]))
 cnf+=cap(savings,slack)
 assert b==10 and o==1
 cnf+=cap(clean+ext,8)
 mult=[ors([ands([zz[x],zz[y]]) for x,y in combinations(range(13),2)]) for zz in z]
 cnf+=cap([-v for v in mult],4)
 cnf.append([-ors([ub(i,t) for t in stars]) for i in range(b)])
 with Solver(name='cadical195',bootstrap_with=cnf) as s:
  if s.solve():
   M=set(s.get_model());return [sum((x in M)<<j for j,x in enumerate(zz)) for zz in z]
 return None
if __name__=='__main__':
 E=int(sys.argv[1]);b=int(sys.argv[2]);print(E,b,model(E,b))
