from pathlib import Path
p=Path('bank_rows.py');s=p.read_text().replace('def model(E,b,oplim=0):','def model(E,b,alloc):')
s=s.replace('z=[[lit((i,j))for j in range(13)]for i in range(b)]','''o_stars=[t for t in stars if t not in special]
 starts=[0,b]
 for n in alloc:starts.append(starts[-1]+n)
 assert starts[-1]==11 and len(alloc)==o
 z=[[lit((i,j))for j in range(13)]for i in range(11)]''')
s=s.replace('for i in range(b-1):','for i in [i for u,v in zip(starts,starts[1:]) for i in range(u,v-1)]:')
s=s.replace(' for t in special:\n  j=stars.index(t)',''' group_rows={}
 for t in stars:
  j=stars.index(t)''',1).replace('  ordinary=[v for v in stars if v not in special]','  ordinary=[v for v in o_stars if v!=t]')
s=s.replace('  for v in bits(t):\n   for X in sets:\n    cnf.append([ands([zz[v],*[-zz[x] for x in bits(X)]]) for zz in z])','''  if not ordinary:sets=set(eligible)
  group_rows[t]=sets
  subset=z[:b] if t in special else z[starts[1+o_stars.index(t)]:starts[2+o_stars.index(t)]]
  for v in bits(t):
   for X in sets:
    cnf.append([ands([zz[v],*[-zz[x] for x in bits(X)]]) for zz in subset])
 # Enforce original width on all labelled point-side obligations.
 for j,t in enumerate(stars):
  ns={n&8191 for n in negative if n&(1<<(13+j))}
  for X in ns:
   if any(not X&~m for m in group_rows[t]): continue
   for v in bits(t):
    cnf.append([ands([zz[v],*[-zz[x] for x in bits(X)]]) for zz in z])''')
s=s.replace('ext=[-ors([ub(i,t) for t in projective])for i in range(b)]','ext=[-ors([ub(i,t) for t in projective])for i in range(11)]')
s=s.replace(" for i,zz in enumerate(z):\n  n2=", " for i,zz in enumerate(z):\n  n2=")
s=s.replace(' for j in range(2):cnf.append([-flags[j+1],flags[j]])',' for j in range(2):cnf.append([-flags[j+1],flags[j]])')
s=s.replace('E=int(sys.argv[1]);b=int(sys.argv[2]);print(E,b,model(E,b))','E=int(sys.argv[1]);b=int(sys.argv[2]);alloc=list(map(int,sys.argv[3:]));print(E,b,alloc,model(E,b,alloc))')
Path('bank_all.py').write_text(s)
