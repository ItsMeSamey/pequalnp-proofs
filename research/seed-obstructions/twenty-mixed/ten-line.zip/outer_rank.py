from bank import stars,negative,bits
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
def run(E):
 O=next(t for j,t in enumerate(stars) if not E>>j&1)
 A=8191^O
 opts=[m for m in range(1,8192) if not m&~A]
 # A point mask can be restricted to the nine exterior points here: every
 # demand accepts an exterior singleton and must avoid a raw negative.
 demands={(p,n&A) for j,t in enumerate(stars) if E>>j&1 for p in bits(t&A)
          for n in negative if n&(1<<(13+j))}
 maximal={(p,X) for p,X in demands if not any(p==q and X!=Y and not X&~Y for q,Y in demands)}
 # A stronger option strictly covers all obligations of a dominated option.
 covers={m:frozenset((p,X) for p,X in maximal if m>>p&1 and not m&X) for m in opts}
 keep=[m for m,row in covers.items() if row and not any(row<r for r in covers.values())]
 keep=[m for m in keep if all(covers[n]!=covers[m] for n in keep if n<m)]
 P=IDPool();v={m:P.id(m) for m in keep}
 cnf=[[v[m] for m in keep if d in covers[m]] for d in maximal]
 for k in range(5,10):
  with Solver(name='cadical195',bootstrap_with=cnf+CardEnc.atmost(list(v.values()),k,vpool=P).clauses) as s:
   ok=s.solve()
   if ok:
    sol=set(s.get_model());return len(maximal),len(keep),k,[m for m in keep if v[m] in sol]
for E in [63,95]:print(E,run(E),flush=True)
