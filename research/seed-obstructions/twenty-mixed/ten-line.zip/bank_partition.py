from pysat.solvers import Solver
from pysat.formula import IDPool
from pysat.card import CardEnc
from itertools import combinations
from collections import Counter
from functools import lru_cache
from pathlib import Path
import sys
import os
source=Path(os.environ.get('POINT_PARETO_SOURCE','/workspace/scratch/synthesis_new/point-pareto'))
sys.path.insert(0,str(source));from input import raw_samples
positive,negative,_=raw_samples(source/'L-meta-18968.json')
stars=[sum({p&8191 for p in positive if p>>(13+j)&1}) for j in range(7)]
projective=[sum(1<<((j+d)%13) for d in (0,1,3,9)) for j in range(13)]
def bits(s):return [i for i in range(13) if s>>i&1]
def model(E,b,alloc,bo):
 special=[s for i,s in enumerate(stars) if E>>i&1];o=7-len(special);slack=21-4*o-b
 if slack<0:return None
 P=IDPool();cnf=[]
 def lit(x):return P.id(x)
 memo={}
 def ors(v):
  v=tuple(sorted(set(v)))
  if len(v)==1:return v[0]
  if v in memo:return memo[v]
  q=lit(('or',*v));memo[v]=q;cnf.extend([[-x,q] for x in v]+[[-q,*v]]);return q
 def ands(v):return -ors([-q for q in v])
 def cap(v,k):
  return CardEnc.atmost(v,k,vpool=P).clauses if 0<=k<len(v) else [] if k>=len(v) else [[]]
 o_stars=[t for t in stars if t not in special]
 starts=[0,b]
 for n in alloc:starts.append(starts[-1]+n)
 assert starts[-1]==11 and len(alloc)==o
 z=[[lit((i,j))for j in range(13)]for i in range(11)]
 def ub(i,mask):return ands([-z[i][j] for j in bits(8191^mask)])
 for i in [i for u,v in zip(starts,starts[1:]) for i in range(u,v-1) if i+1!=bo]:
  eq=[]
  for j in reversed(range(13)):
   x,y=z[i][j],z[i+1][j];cnf.append([-r for r in eq]+[-x,y])
   eq.append(ands([ors([x,-y]),ors([-x,y])]))
 group_rows={}
 for t in stars:
  j=stars.index(t)
  eligible=[n&8191 for n in negative if (n>>13)&(1<<j)]
  ordinary=[v for v in o_stars if v!=t]
  # Maximal point sets guaranteed rejected by every OR summand, since its
  # ancestor guards use a common ordinary resident (possibly different
  # witnesses across attachments).
  sets={8191^t}
  for u in ordinary:
   sets={x&y for x in sets for y in eligible if y&u}
   sets={x for x in sets if not any(x!=y and not x&~y for y in sets)}
  if not ordinary:sets=set(eligible)
  group_rows[t]=sets
  subset=z[:b] if t in special else z[starts[1+o_stars.index(t)]:starts[2+o_stars.index(t)]]
  for v in bits(t):
   for X in sets:
    cnf.append([ands([zz[v],*[-zz[x] for x in bits(X)]]) for zz in subset])
 # Enforce original width on all labelled point-side obligations.
 for j,t in enumerate(stars):
  ns={n&8191 for n in negative if n&(1<<(13+j))}
  for X in ns:
   if any(not X&~m for m in group_rows[t]): continue
   for v in bits(t):
    cnf.append([ands([zz[v],*[-zz[x] for x in bits(X)]]) for zz in z])
 ext=[-ors([ub(i,t) for t in projective])for i in range(11)]
 clean=[]
 savings=[]
 for t in special:
  flags=[lit(('save',t,j)) for j in range(3)];savings+=flags
  for i,zz in enumerate(z):
   c=ub(i,t)
   for n in range(2,5):
    for vs in combinations(bits(t),n):cnf.append([-c,*[-zz[v] for v in vs],flags[n-2]])
  for j in range(2):cnf.append([-flags[j+1],flags[j]])
 for i,zz in enumerate(z):
  n2=ors([ands([zz[x],zz[y]])for x,y in combinations(range(13),2)])
  clean.append(ands([n2,ors([ub(i,t) for t in special])]))
 cnf+=cap(savings,slack)
 # The released ten-gate local-bank certificate excludes all-star-local
 # computed masks. A remaining bank has a nonlocal signature and at least
 # seven distinct paid masks: the complete six-paid-output family is local.
 mult=[ors([ands([zz[x],zz[y]]) for x,y in combinations(range(13),2)]) for zz in z]
 cnf+=cap([-v for v in mult],4)
 cnf.append([-ors([ub(i,t) for t in stars]) for i in range(11)])
 assert len(o_stars)==1 and b==10 and alloc==[1]
 O=o_stars[0]
 # At least two of the ten OR-side masks are raw. All raw masks fit inside
 # the complementary prefix lines, so permit this symmetry-stable relaxation.
 rawlike=[ors([ub(i,t) for t in projective if t not in stars]) for i in range(b)]
 cnf+=cap([-v for v in rawlike],8)
 for t in special:
  j=stars.index(t)
  wc=lit(('outer-intersection',t))
  for v in bits(t):
   for r in negative:
    if not r&(1<<(13+j)):continue
    X=r&8191
    oo=[ands([zz[v],*[-zz[y] for y in bits(X)]]) for zz in z[:bo]]
    if O&1<<v:
     cnf.append([-wc,*oo])
     if X&O:
      ii=[ands([zz[v],*[-zz[y] for y in bits(X)]]) for zz in z[bo:b]]
      cnf.append([wc,*ii])
    else:cnf.append(oo)
 options=[]
 for h in range(slack+o+1):
  q=min(o,h*(h-1)//6);c=slack+q-h
  if c<0:continue
  v=lit(('bound',h));options.append(v)
  for row in cap(ext,h)+cap(clean,c):cnf.append([-v,*row])
 cnf.append(options)
 with Solver(name='cadical195',bootstrap_with=cnf) as s:
  if s.solve():
   M=set(s.get_model());return [sum((x in M)<<j for j,x in enumerate(zz)) for zz in z]
 return None
if __name__=='__main__':
 E=int(sys.argv[1]);b=int(sys.argv[2]);bo=int(sys.argv[3]);print(E,b,bo,model(E,b,[1],bo))
