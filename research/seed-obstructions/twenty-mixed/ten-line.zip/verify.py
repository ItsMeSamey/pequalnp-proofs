"""Check the untouched-ordinary-label restriction on three-gate line banks."""
from collections import Counter
from itertools import combinations, combinations_with_replacement, permutations
from pathlib import Path
import sys
import os
if len(sys.argv) > 1: os.environ['POINT_PARETO_SOURCE']=sys.argv[1]
from bank import model, stars, projective, positive, negative

def image(mask, p):
    return sum(bool(mask & (1<<i)) << j for i,j in enumerate(p))

point_labels = [sum(bool(t & (1<<p)) << j for j,t in enumerate(stars)) for p in range(13)]
assert len(set(point_labels)) == 13
group = []
for g in permutations(range(7)):
    moved = [image(m,g) for m in point_labels]
    if set(moved) != set(point_labels):
        continue
    pg = [point_labels.index(m) for m in moved]
    assert {image(t,pg) for t in projective} == set(projective)
    def row(r):return image(r&8191,pg) | (image(r>>13,g)<<13)
    assert {row(r) for r in positive} == positive and {row(r) for r in negative} == negative
    group.append(g)
assert len(group)==24
# Guard and OR-side witness requirements.
for t,T in enumerate(stars):
    for x,y in combinations(range(13),2):
        assert any((r&(1<<x)) and (r&(1<<y)) for r in negative)
        if T & ((1<<x)|(1<<y)):continue
        for u,U in enumerate(stars):
            if t==u:continue
            assert any(r & (1<<(13+t)) and r&(1<<x) and r&(1<<y) and r&U for r in negative)
raw=tuple(1<<i for i in range(7))
states={raw}
for _ in range(3):
    states={tuple(sorted((*s,z))) for s in states for x,y in combinations_with_replacement(s,2) for z in (x|y,x&y)}
by=Counter(); reps={}
for bank in states:
    extra=list(bank)
    for t in raw:extra.remove(t)
    if 0 in extra:by[0]+=1;continue
    E=extra[0]|extra[1]|extra[2]
    by[E.bit_count()]+=1
    reps.setdefault(E.bit_count(),set()).add(min(image(E,g) for g in group))
assert by=={0:540,1:7,2:168,3:1645,4:4235,5:1575,6:105}
print('Original banks by exceptional label count:',sorted(by.items()),flush=True)
from bank_rows import model as stronger
for n in (2,3,4,5):
    count=0;o=7-n
    for E in sorted(reps[n]):
        # At b<=2 Three exclusive point codes cannot be incomparable. The
        # sole two-label case at b=1 also fails incomparability directly.
        for b in range(3, min(11-o,21-4*o)+1):
            assert (stronger if n==5 else model)(E,b) is None,(E,b)
            count+=1
    print(n,'special labels, representatives',sorted(reps[n]),'UNSAT checks',count,flush=True)
print('Excluded',sum(by[n] for n in range(6)),'of',len(states),'line banks.')
for E in sorted(reps[6]):
    for b in range(3,10):
        assert stronger(E,b) is None,(E,b)
    print('Six exceptional labels, projected mask',E,'requires b=10.',flush=True)
