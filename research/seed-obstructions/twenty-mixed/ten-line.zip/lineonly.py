from pathlib import Path
from itertools import combinations,combinations_with_replacement
from collections import Counter
import sys
src=Path('/workspace/scratch/synthesis_new/point-pareto')
sys.path.insert(0,str(src))
from input import raw_samples
ps,ns,_=raw_samples(src/'L-meta-18968.json')
ps,ns=sorted(ps),sorted(ns)
raw=tuple(1<<i for i in range(7))
states={raw}
for d in range(3):
 states={tuple(sorted((*s,t))) for s in states for x,y in combinations_with_replacement(s,2) for t in (x|y,x&y)}
assert len(states)==8275
private=[[(k,n>>13) for k,n in enumerate(ns) if not ((p&8191)&~(n&8191))] for p in ps]
im={i:sum(1<<j for j,n in enumerate(ns) if n>>13&i) for i in range(128)}
rp=[next(i for i in range(7) if p>>(13+i)&1) for p in ps]
raw_oblig=[sum(1<<k for k,m in row if not m&(1<<j)) for row,j in zip(private,rp)]
graphs=Counter();hist=Counter();records={}
for bank in sorted(states):
 extra=list(bank)
 for t in raw:extra.remove(t)
 force={t:0 for t in range(7)}
 for j in range(7):
  n=0
  for t,row in zip(rp,raw_oblig):
   if t==j:n|=row
  for e in extra:
   if e>>j&1:n&=im[e]
  force[j]=n
 edges=tuple((i,j) for i,j in combinations(range(7),2) if force[i]&force[j])
 graphs[edges]+=1
 hist[len(edges)]+=1
 records[bank]=edges
print('banks',len(states),'OR-edge counts',sorted(hist.items()),'different OR graphs',len(graphs))
print('complete7',hist[21], 'AND-labels 0')
if __name__=='__main__':
 import json
 Path('graphs.json').write_text(json.dumps([{'bank':k,'or':v} for k,v in records.items()],separators=(',',':')))
