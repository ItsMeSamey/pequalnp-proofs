from bank_partition import *
import sys
E=int(sys.argv[1])
for bo in [10,9,8,7,6,5,4,3,2,1,0]:
 print(E,bo,model(E,10,[1],bo),flush=True)
