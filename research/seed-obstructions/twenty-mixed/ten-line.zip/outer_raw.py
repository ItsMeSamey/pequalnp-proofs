from bank import stars,negative,bits
from collections import Counter
stats=Counter()
for line in open('remaining-105.txt'):
 bank=list(map(int,line.split()))
 pairs=[m for m in bank if m.bit_count()==2]
 E=pairs[0]|pairs[1]|pairs[2];o=next(j for j in range(7) if not E>>j&1);O=stars[o]
 for m in pairs:
  for j in bits(m):
   k=next(h for h in bits(m) if h!=j)
   assert any(n&(1<<(13+k)) and n&(1<<p) and not n&(1<<(13+j)) for n in negative for p in bits(stars[j]&~O))
   for p in bits(O&~stars[j]):
    assert any(n & (1<<p) and n & (1<<(13+j)) for n in negative)
 share=sum(bool(stars[j]&stars[k]&O) for m in pairs for j,k in [bits(m)])
 stats[o,share]+=1
print(sorted(stats.items()))
