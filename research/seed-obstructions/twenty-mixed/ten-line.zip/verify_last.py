"""Verify the matched-pair witnesses and the two normalized outer-bank SAT cases."""
import os
from pathlib import Path
import sys
from itertools import combinations

if len(sys.argv)>1:
    os.environ['POINT_PARETO_SOURCE']=sys.argv[1]
from bank import stars,projective,negative,bits
from bank_partition import model
from input import point_obligations

def matchings(labels):
    if not labels:
        yield []
        return
    j,*others=labels
    for k in others:
        for rest in matchings([v for v in others if v!=k]):
            yield [(j,k),*rest]

count=0
for o,O in enumerate(stars):
    for matching in matchings([j for j in range(7) if j!=o]):
        count+=1
        shared=[]
        for a,b in matching:
            if O&stars[a]&stars[b]: shared.append(O&stars[a]&stars[b])
            for j,k in ((a,b),(b,a)):
                assert any(n&(1<<(13+k)) and n&(1<<p) and not n&(1<<(13+j))
                           for n in negative for p in bits(stars[j]&~O))
                for p in bits(O&~stars[j]):
                    assert any(n&(1<<p) and n&(1<<(13+j)) for n in negative)
            for p in bits(O&stars[a]&stars[b]):
                assert not any(n & (1<<p) and n>>13 & ((1<<a)|(1<<b)) for n in negative)
        assert all(m.bit_count()==1 for m in shared) and len(shared)==len(set(shared))
    for p in bits(O):
        assert any(n&(1<<p) for n in negative) # set all raw line bits to zero
assert count==105
root=Path(os.environ.get('POINT_PARETO_SOURCE','/workspace/scratch/synthesis_new/point-pareto'))
raw,_=point_obligations(root/'L-meta-18968.json')
prefix=set(projective)-set(stars)
assert all(any(not m&~u for u in prefix) for m in raw)
print('Matched-pair raw witnesses and singleton normalization verified for all 105 banks.',flush=True)
for E in (63,95):
    assert model(E,10,[1],10) is None
    print('All-outer normalized point bank UNSAT at exceptional mask',E,flush=True)
