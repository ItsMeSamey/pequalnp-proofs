from pathlib import Path
s=Path('bank_global.py').read_text()
s=s.replace(' def ors(v):\n  z=lit((\'or\',*sorted(v)));cnf.extend([[-q,z] for q in v]+[[-z,*v]]);return z', ''' memo={}
 def ors(v):
  v=tuple(sorted(set(v)))
  if len(v)==1:return v[0]
  if v in memo:return memo[v]
  q=lit(('or',*v));memo[v]=q;cnf.extend([[-x,q] for x in v]+[[-q,*v]]);return q''')
i=s.index(' with Solver(')
s=s[:i]+''' # Compute exact point-only private positions at all relevant rows.
 ps=sorted(positive);ns=sorted(negative)
 pc=[[[] for _ in z] for _ in ps];nc=[[[] for _ in z] for _ in ns]
 for ip,p in enumerate(ps):
  qp=(p&8191).bit_length()-1
  for j,n in enumerate(ns):
   if p>>13 & ~(n>>13):continue
   d=[ands([zz[qp],*[-zz[x] for x in bits(n&8191)]]) for zz in z]
   for i,x in enumerate(d):
    u=ands([x,*[-v for k,v in enumerate(d) if k!=i]])
    pc[ip][i].append(u);nc[j][i].append(u)
 pm=[[ors(v) for v in row] for row in pc];nm=[[ors(v) for v in row]for row in nc]
 colors=[[lit(('color',i,t)) for t in range(7)] for i in range(11)]
 raw=tuple(1<<i for i in range(7)); states={raw}
 for _ in range(3):
  states={tuple(sorted((*s,v))) for s in states for k,a in enumerate(s) for b0 in s[k:] for v in (a|b0,a&b0)}
 choice=[]
 for bank in states:
  extra=list(bank)
  for t in raw:extra.remove(t)
  if 0 in extra or (extra[0]|extra[1]|extra[2])!=E:continue
  sel=lit(('bank',*bank));choice.append(sel)
  pp=[set() for _ in range(7)];nn=[set() for _ in range(7)]
  for ip,p in enumerate(ps):
   t=(p>>13).bit_length()-1
   for j,n in enumerate(ns):
    if (p&8191)&~(n&8191) or (n>>13)&(1<<t):continue
    if all(not (v&(1<<t)) or v&(n>>13) for v in extra):
     pp[t].add(ip);nn[t].add(j)
  for t in range(7):
   for i in range(11):
    if pp[t]:cnf.append([-sel,-ors([pm[k][i] for k in pp[t]]),colors[i][t]])
    if nn[t]:cnf.append([-sel,-ors([nm[k][i] for k in nn[t]]),-colors[i][t]])
 cnf.append(choice)
'''+s[i:]
Path('bank_cot.py').write_text(s)
