from bank_rows import *
import sys
E=int(sys.argv[1]);o=7-E.bit_count()
for b in reversed(range(3,min(11-o,21-4*o)+1)):
 print(E,b,model(E,b),flush=True)
