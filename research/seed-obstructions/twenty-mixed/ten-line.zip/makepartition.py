from pathlib import Path
s=Path('bank_global.py').read_text().replace('def model(E,b,alloc):','def model(E,b,alloc,bo):')
s=s.replace('for i in [i for u,v in zip(starts,starts[1:]) for i in range(u,v-1)]:','for i in [i for u,v in zip(starts,starts[1:]) for i in range(u,v-1) if i+1!=bo]:')
s=s.replace(' def ors(v):\n  z=lit((\'or\',*sorted(v)));cnf.extend([[-q,z] for q in v]+[[-z,*v]]);return z', ''' memo={}
 def ors(v):
  v=tuple(sorted(set(v)))
  if len(v)==1:return v[0]
  if v in memo:return memo[v]
  q=lit(('or',*v));memo[v]=q;cnf.extend([[-x,q] for x in v]+[[-q,*v]]);return q''')
a=s.index(' options=[]')
s=s[:a]+''' assert len(o_stars)==1 and b==10 and alloc==[1]
 O=o_stars[0]
 # At least two of the ten OR-side masks are raw. All raw masks fit inside
 # the complementary prefix lines, so permit this symmetry-stable relaxation.
 rawlike=[ors([ub(i,t) for t in projective if t not in stars]) for i in range(b)]
 cnf+=cap([-v for v in rawlike],8)
 for t in special:
  j=stars.index(t)
  wc=lit(('outer-intersection',t))
  for v in bits(t):
   for r in negative:
    if not r&(1<<(13+j)):continue
    X=r&8191
    oo=[ands([zz[v],*[-zz[y] for y in bits(X)]]) for zz in z[:bo]]
    if O&1<<v:
     cnf.append([-wc,*oo])
     if X&O:
      ii=[ands([zz[v],*[-zz[y] for y in bits(X)]]) for zz in z[bo:b]]
      cnf.append([wc,*ii])
    else:cnf.append(oo)
'''+s[a:]
s=s.replace('alloc=list(map(int,sys.argv[3:]));print(E,b,alloc,model(E,b,alloc))','bo=int(sys.argv[3]);print(E,b,bo,model(E,b,[1],bo))')
Path('bank_partition.py').write_text(s)
