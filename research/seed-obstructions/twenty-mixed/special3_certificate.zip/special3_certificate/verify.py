"""Rebuild the point-role instances and exhaust every noncanonical case."""
from itertools import permutations
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import re
import subprocess
import sys
import zipfile
from inputs import N,P,stars
from samples import actions

HERE=Path(__file__).resolve().parent
A=8191

def maximal(rows):
    rows=set(rows)
    return {(p,n) for p,n in rows if not any(p==q and n!=m and not n&~m for q,m in rows)}

def clique(rows):
    points=sorted(rows)
    neighbors=[sum(1<<j for j,(x,y) in enumerate(points) if p&y or x&n)
               for p,n in points]
    best=[]
    for i in range(len(points)):
        remaining=neighbors[i]
        chosen=[i]
        while remaining:
            candidates=[j for j in range(len(points)) if remaining>>j&1]
            index=max(candidates,key=lambda j:(remaining&neighbors[j]).bit_count())
            chosen.append(index)
            remaining &=neighbors[index]
        if len(chosen)>len(best):
            best=chosen
    result=[points[i] for i in best]
    assert all(a&d or b&c for i,(a,b) in enumerate(result) for c,d in result[:i])
    return result

def main():
    raw=maximal((p&A,n&A) for p in P for n in N if not (p>>13)&~(n>>13))
    assert len(raw)==1323
    group=actions(P,N)
    actions7=[tuple(stars.index(f[t]) for t in stars) for f in group]
    ordinary=[(1,1,1,1),(1,1,1,2),(1,1,2,2),*((1,1,1,f) for f in range(3,7))]
    cases=sorted({min(tuple(a[i] for i in g) for g in actions7)
                  for form in ordinary for a in set(permutations((*form,0,0,0)))})
    assert len(cases)==74
    primitives={1<<i for i in range(13)}
    for j in range(6):
        x=(1<<j)|(1<<(j+1))
        y=(1<<(j+3))|(1<<((j+9)%13))
        primitives.update((x,y,x|y))
    raw55=sorted({f[x] for x in primitives for f in group})
    literal=re.search(r'orbitraw\[\]\s*=\s*\{([^}]+)\}',(HERE/'hereditaryrole.hpp').read_text(),re.DOTALL)
    assert literal and raw55==list(map(int,literal[1].split(',')))
    dependency=HERE/'fourgroups14.zip'
    assert hashlib.sha256(dependency.read_bytes()).hexdigest()=='f80b03feabef9bd0415597bc3dab78d73978decbe28b6f93d2ee8ea539387b3d'
    total=0
    noncanonical=0
    with TemporaryDirectory() as td:
        work=Path(td)
        if '--with-prior' in sys.argv:
            with zipfile.ZipFile(dependency) as archive:archive.extractall(work/'prior')
            prior=next((work/'prior').rglob('verify.py'))
            subprocess.run([sys.executable,prior],check=True)
        binary=work/'search'
        subprocess.run(['c++','-O3','-march=native','-std=c++20',HERE/'search.cpp','-o',binary],check=True)
        cache={}
        for k,a in enumerate(cases):
            if max(a)==1:
                continue
            quartet=sum(1<<i for i,f in enumerate(a) if f)
            if quartet not in cache:
                active=[t for i,t in enumerate(stars) if quartet>>i&1]
                cache[quartet]=maximal((p&A,n&A) for p in P for n in N
                    if not (p>>13)&~(n>>13) and not (p>>13)&quartet and all(t&n for t in active))
            forced=set(cache[quartet])
            general=[]
            for p,n in sorted(raw-forced):
                if any(f==1 and p&stars[t] and not n&stars[t] for t,f in enumerate(a)):
                    continue
                if any((f in (2,3) and p&stars[t]) or f in (4,5,6) for t,f in enumerate(a)):
                    general.append((p,n))
                else:
                    forced.add((p,n))
            anchors=clique(forced)
            pairs=lambda r: ''.join(f'{p} {n}\n' for p,n in r)
            inp=' '.join(map(str,a))+'\n'+str(len(anchors))+'\n'+pairs(anchors)
            inp+=str(len(forced))+'\n'+pairs(sorted(forced))+pairs(general)
            result=subprocess.run([binary],input=inp,text=True,capture_output=True,check=True)
            summary=re.fullmatch(r'DONE (\d+) 0\s*',result.stderr)
            assert summary and not result.stdout
            nodes=int(summary[1])
            total+=nodes
            noncanonical+=1
            print('case',k,'forms',*a,'nodes',nodes,flush=True)
    assert noncanonical==69 and total==701397
    print('All 69 noncanonical cases have zero banks in',total,'nodes.')
    print('Five canonical quartet cases use the embedded four-group theorem.')
if __name__=='__main__':
    if not __debug__:raise SystemExit('Enable Python assertions.')
    main()
