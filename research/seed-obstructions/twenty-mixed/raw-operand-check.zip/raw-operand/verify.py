"""Minimum raw operand-slot charge from the pinned point obligations."""
from itertools import combinations
from pathlib import Path
import sys
previous=Path(__file__).resolve().parents[1]/'point-pareto'
sys.path.insert(0,str(previous))
from input import point_obligations
raw,rows=point_obligations(previous/'L-meta-18968.json')
many=[x for x in raw if x.bit_count()>1]
assert len(many)==18
tables=[]
for i in range(13):
    p=1<<i
    neighbors=[j for j,x in enumerate(many) if x&p]
    bits=sum(1<<j for j in neighbors)
    lookup={}
    local=bits
    while True:
        active=[many[j] for j in neighbors if local>>j&1]
        unresolved=[n for a,n in rows if a==p and all(n&x for x in active)]
        forbidden={0} if unresolved else set()
        for n in unresolved:
            z=n
            while z:
                forbidden.add(z);z=(z-1)&n
        demand=next(k for k in range(13) if any(sum(1<<j for j in subset) not in forbidden for subset in combinations([j for j in range(13) if j!=i],k)))
        lookup[local]=demand
        if not local:break
        local=(local-1)&bits
    tables.append((bits,lookup))
best=[[100]*(r+1) for r in range(12)]
for f in range(1<<len(many)):
    ds=sorted((v[f&bits] for bits,v in tables),reverse=True)
    total=sum(ds);n=f.bit_count()
    for s in range(12):
        if s:total-=ds[s-1]
        for r in range(s,min(11,s+n)+1):
            best[r][s]=min(best[r][s],n-(r-s)+total)
for r,arr in enumerate(best):
    print('selected raw',r,'by selected singletons',arr,'minimum',min(arr),flush=True)
assert min(best[3])>18
