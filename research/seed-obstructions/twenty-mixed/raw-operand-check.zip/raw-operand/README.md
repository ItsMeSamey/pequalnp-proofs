# Ten paid point gates at width eleven force a star-local bank in an actual separator

Suppose an actual normalized residual separator uses eleven distinct point-side boundary wires and at most ten paid point gates. Every selected nonprimitive singleton signature must lie in one residual star. The proof uses the original Boolean functions on entire negative point sets.

Earlier point Pareto and nonlocal checks leave only the branch with ten paid gates, eight distinct selected nonprimitive masks and three selected raw masks. All 27 nine-gate equality banks are star-local. At ten gates the six-selected case is structurally star-local; the seven-, nine- and ten-selected nonlocal cases have separate finite exclusions (synthesis_new/nonlocal-seven). In the remaining hypothetical branch every actual paid gate already has a distinct nonzero nonprimitive singleton signature. Otherwise simplifying a duplicate, zero or primitive result yields a shorter singleton-mask program for the same nonlocal covering bank, contradicting the nine-gate classification. This proves a property of the original gates; we now evaluate them without replacement.

Each of the two unselected paid gates must feed a later operand or the singleton-mask program again shortens. Of twenty paid gate operand slots, at most eighteen can therefore refer to raw primitives.

Let S denote the s selected raw singleton indices. Let F consist of all nonsingleton raw primitives either selected or used by a paid gate. At least |F|−(3−s) operand slots use nonsingleton raw primitives. For each p outside S take all obligations (p,N) not separated by any element of F; the free primitives are literal disjunctions on N. The row pair giving this obligation has its positive line assignment contained in the negative line assignment. Hence some actual selected point wire is true on p and false on N. Only raw singleton p can distinguish these two tests among the accessible primitive wires.

Some direct paid successor of raw p must distinguish the tests; otherwise every such successor and every other raw source satisfies positive value ≤ negative value, and monotonicity propagates that to all outputs. AND with raw p would have singleton signature zero or p, already ruled out. A distinguishing first successor is thus OR(p,Z), with actual Z false on N. Each direct OR partner has a singleton point outside p, since otherwise the result would have primitive signature p. Pick one such exterior point for each direct partner. Every remaining obligation misses at least one chosen point by monotonicity of Z. An OR of two singletons has two operand slots, so separate charges for those two points are valid.

Define d(p,F) as the minimum size of a set W of exterior points that is not contained in any remaining N for p; use zero when the row list is empty. This lower-bounds the raw-p operand count. The total raw operand count is therefore at least

    |F| − (3−s) + sum of d(p,F) over p outside S.

The checker enumerates all 262,144 possible F using the pinned raw sample. For fixed F,s it removes the s largest demands to minimize over S. The minima for s=0,1,2,3 are 25,23,21,19. All exceed eighteen. The independent checker synthesis_new/nonlocal-seven/operand_audit.py computes the same numbers. The bounded C++ scan in synthesis_new/two-slot/rawcut.cpp uses separate mask enumeration.

Singleton-mask coverage alone does not ensure actual negative rejection: two masks may meet N at different points, so their intersection avoids N even when both inputs and their AND are true on N. The proof invokes the original separator to obtain actual point-signal separation before applying the first-successor argument.

## General operand budget

Any actual separator can first be made free of paid point signals with empty or primitive singleton mask. Pin an empty-mask signal to zero, or replace the other kind with the corresponding primitive OR of singleton bits. Monotonicity ensures this only lowers values on arbitrary point inputs and preserves all singleton positives. Propagate constants and discard unused gates. This normalization does not require equality between signals sharing a nonprimitive mask.

Let r count selected raw primitives, h selected paid wires and g paid point gates after normalization. There are at most g+h raw operands because g−h hidden gates need outgoing reads. The same expression with 3 replaced by r gives the necessary lower bound T(r), hence g≥T(r)−h. For r=0 through 11, T(r) takes values 28,25,22,19,16,13,10,8,6,4,3,2. See verified.log for the breakdown by selected raw singleton count. These are minima of the relaxed operand expression, not exact gate costs. At width eleven, eight, nine, ten or eleven selected paid wires therefore require at least eleven, thirteen, fifteen or seventeen paid gates. Equality for eight selected and eleven paid requires three selected raw singletons.
