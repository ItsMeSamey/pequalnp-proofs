"""Regenerate all 609 equality inputs and exhaust the actual sample-wise forest problem."""
from collections import Counter
from itertools import combinations
from pathlib import Path
from subprocess import run
from tempfile import TemporaryDirectory
import numpy as np
from input import point_obligations

base=Path(__file__).resolve().parent
raw, obligations=point_obligations(base/'L-meta-18968.json')
frozen=[m for m in raw if m.bit_count()>1]
sets=np.arange(1<<len(frozen),dtype=np.int32)
size=np.array([i.bit_count() for i in range(len(sets))],dtype=np.int16)
read=np.empty((len(sets),13),dtype=np.int16)
masks=np.arange(8192,dtype=np.int32)
for i in range(13):
    p=1<<i
    neg=[n for a,n in obligations if a==p]
    incident=[j for j,m in enumerate(frozen) if m&p]
    projection=np.zeros(len(sets),dtype=np.int16)
    for bit,j in enumerate(incident):
        projection|=(((sets>>j)&1)<<bit).astype(np.int16)
    minima=[]
    for use in range(1<<len(incident)):
        available=[frozen[j] for bit,j in enumerate(incident) if use>>bit&1]
        pending=[n for n in neg if all(m&n for m in available)]
        if not pending:
            minima.append(0)
            continue
        bad=np.zeros(8192,dtype=bool);bad[pending]=True
        for bit in range(13):
            step=1<<bit
            view=bad.reshape(-1,2*step)
            view[:,:step]|=view[:,step:]
        minima.append(int(size[:8192][(~bad)&((masks&p)==0)].min()))
    read[:,i]=np.array(minima)[projection]
# One of the frozen primitives is selected and therefore accounts for no raw operand.
lower=size-1+np.sort(read,axis=1)[:,:10].sum(axis=1)
assert int(lower[size>0].min())==18
cases=set()
for idx in np.flatnonzero((size>0)&(lower==18)):
    selected=[m for j,m in enumerate(frozen) if int(idx)>>j&1]
    for S in combinations(range(13),3):
        leaves=[1<<i for i,n in enumerate(read[idx]) if i not in S for _ in range(n)]
        if len(leaves)+len(selected)-1!=18:continue
        s=sum(1<<i for i in S)
        for f in selected:
            source=sorted([*leaves,*(m for m in selected if m!=f)])
            cases.add((s,f,*source))
assert len(cases)==609
with TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    (tmp/'obs').write_text(''.join(f'{p} {n}\n' for p,n in obligations))
    exe=tmp/'forest'
    run(['c++','-std=c++20','-O3',str(base/'forest.cpp'),'-o',str(exe)],check=True)
    result=run([exe],input=''.join(' '.join(map(str,c))+'\n' for c in sorted(cases)),
               cwd=tmp,capture_output=True,text=True,check=True)
    stats=[row.split() for row in result.stdout.splitlines()]
    if len(stats)!=609 or any(row[3]!='UNSAT' for row in stats):
        raise ValueError(('incomplete exclusion',result.stderr))
    print('Rejected all 609 raw-source multisets.',flush=True)
    print('Bottom matching nodes, bottom completions, top calls:',
          *(sum(int(row[j]) for row in stats) for j in (4,5,6)),flush=True)
    control=run([exe],input=(base/'control').read_text(),cwd=tmp,capture_output=True,text=True,check=True)
    assert control.stdout.split()[3]=='SAT'
    # Check the returned actual circuit against all obligations from scratch.
    rootline,recipe_line=control.stderr.splitlines()
    s,f,*roots=map(int,rootline.split()[1:])
    recipe=[tuple(map(int,item.split(','))) for item in recipe_line.split()]
    assert len(recipe)==11 and len(roots)==7
    fixed_s,fixed_f,*control_leaves=map(int,(base/'control').read_text().split())
    assert (s,f)==(fixed_s,fixed_f)
    operands=Counter(v for _,a,b in recipe for v in (a,b))
    assert Counter({v:n for v,n in operands.items() if v<8192})==Counter(control_leaves)
    assert all(n==1 for v,n in operands.items() if v>=8192)
    assert all(0<=a<8192+i and 0<=b<8192+i and op in (0,1)
               for i,(op,a,b) in enumerate(recipe))
    def eval_tree(row):
        values={m:bool(m&row) for m in raw}
        for i,(op,a,b) in enumerate(recipe,8192):
            values[i]=(values[a] or values[b]) if op else (values[a] and values[b])
        return values
    used={v for op,a,b in recipe for v in (a,b) if v>=8192}
    root_ids=sorted(set(range(8192,8203))-used)
    assert len(root_ids)==7
    assert all((s&p&~n) or ((p&f) and not(n&f)) or
               any(eval_tree(p)[w] and not eval_tree(n)[w] for w in root_ids)
               for p,n in obligations)
    print('The positive control has seven terminal roots and separates all 1,323 obligations.')
