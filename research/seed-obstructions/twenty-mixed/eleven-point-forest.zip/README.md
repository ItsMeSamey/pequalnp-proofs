# Eleven paid point gates, seven selected outputs and three selected singleton inputs

Consider an eleven-wire point boundary consisting of seven selected paid gates, three raw singletons and one nonsingleton raw primitive. In a normalized point circuit with eleven paid gates, no such bank can separate the actual raw point obligations. This exclusion concerns the indicated selection and input counts. It applies independently of how the mixed gates and line inputs are arranged.

Run the following command from this directory with Python 3, NumPy and a C++20 compiler.

```sh
python verify.py
```

## Why the gates form a forest

Let S be the three selected singleton coordinates, and let F contain all nonsingleton raw primitives that are selected or read by a paid gate. Fix the selected member f of F. For an unselected singleton p, take the obligations (p,N) not separated by any member of F. The only raw signal capable of separating such a pair is p itself. At least one direct successor of p must preserve the distinction for every pending N. In a normalized circuit such a successor is an OR of p with an operand that is false on N and has some non-p point in its singleton signature. An AND with p is either p or has empty singleton signature. A partner true on p would make the OR redundant. Empty singleton signatures may be set to zero throughout a monotone circuit: positive singleton rows are unchanged and negative values can only decrease; gates made redundant can be eliminated. These are the normalizations used for the source lower bound.

Choose one non-p singleton in each direct OR partner. For every pending N some choice must be outside N. Write d(p,F) for the minimum number of distinct coordinates in a set of such choices. This bounds the raw operand multiplicity of p from below. Each member of F other than f must be read at least once. Thus the raw operand count is at least the sum of d(p,F) over unselected p, plus |F|−1. The Python verifier regenerates all 1,323 obligations and checks every subset F of the eighteen nonsingleton raw primitives. It takes the downward closure of the pending negative sets to compute each d, then enumerates S and f. The minimum is eighteen. At equality exactly 609 labeled combinations of S, f, and raw operand multiset are possible.

Eleven gates have 22 operand slots. Their four unselected gates must each feed a later gate in a live program, leaving at most eighteen raw slots. Therefore there are exactly eighteen raw operands; each hidden gate is used once and no selected gate feeds another. The selected outputs are seven disjoint binary-tree roots whose leaves are the prescribed raw occurrences. The raw f and each selected singleton have zero paid uses at equality.

## Bottom matchings and top completions

A bottom gate has two raw operands. If b gates are bottom gates, then 18−2b raw leaves remain unpaired and 11−b gates remain to consume them. A remaining gate consumes at most one raw operand. Therefore b is 7, 8, or 9. Enumerating all partial matchings of the leaf multiset with at most four unpaired leaves includes every possible forest. Equal-copy permutations may be explored repeatedly without affecting completeness.

If a bottom pair contains an unselected raw singleton p, its operation must be OR. Every occurrence of p meets the multiplicity lower bound above, so an occurrence not contributing a real direct OR successor could be removed from the count. Equal raw operands cannot make a useful bottom gate; a repeated nonsingleton raw operand is already excluded by the source multiset. For each p, keep the raw partners matched so far. Remove a pending N only when one of those partners is false on the entire N. For the remaining pending sets, enumerate all choices of as many non-p singleton witnesses as there are unassigned occurrences of p. Failure to hit a complement proves that this partial matching has no completion. The other bottom gates may use AND or OR.

The checker evaluates all intermediate truth values both on positive singletons and on whole negative point sets. At any partial matching or later join, the selected raw signals, the live outputs and the unused raw leaves together must still separate every obligation. Monotonicity ensures that once all those signals are dominated on a positive-negative pair, later AND/OR gates cannot restore separation. For each complete bottom matching the search exhausts all joins between a computed signal and an unpaired raw or another computed signal. Neither operand is reused. A candidate finish must have exactly seven roots, all computed, and must distinguish every obligation. No finished forest achieves this on any of the 609 cases.

The positive control replaces the selected nonsingleton by a fourth selected singleton and supplies an eighteen-leaf multiset for a known covering bank. The C++ search finds a circuit and the Python runner independently evaluates all eleven returned gates on every positive and negative obligation. This confirms that the actual-output check can accept a valid forest with the same seven-root topology.

The optional command below suppresses the partner-witness pruning after the 609 source inputs have been derived. It directly tests every eligible bottom matching using only full sample separation and the necessary singleton-OR restriction.

```sh
FOREST_SKIP_PARTNER_FILTER=1 python verify.py
```
