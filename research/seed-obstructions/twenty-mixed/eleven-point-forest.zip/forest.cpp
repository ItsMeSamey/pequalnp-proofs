#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <vector>
#include <cstdlib>
using namespace std;
const bool use_partner_filter = std::getenv("FOREST_SKIP_PARTNER_FILTER") == nullptr;
constexpr int B=21;using U=uint64_t;using Bits=array<U,B>;
struct Wire {int p=0; Bits n{},sep{};};
vector<pair<int,int>> obs;
Bits ones{},pv[8192];Wire raw[8192];
Wire join(const Wire&a,const Wire&b,bool o){
 Wire c;c.p=o?a.p|b.p:a.p&b.p;
 // Evaluate the negative vector as a whole set, including for intersections.
 for(int j=0;j<B;j++){c.n[j]=o?a.n[j]|b.n[j]:a.n[j]&b.n[j];c.sep[j]=pv[c.p][j]&~c.n[j];}
 return c;
}
bool one(int a){return a && !(a&(a-1));}
struct Search {
 int S,F;array<int,18> source;map<int,int> counts;Bits fixed{};
 vector<int> skip;vector<Wire> bot;vector<array<int,3>> recipes;
 vector<int> outside[13],partners[13];int multiplicity[13]{};
 map<vector<int>,bool> partner_ok[13];
 unsigned long long nodes=0,leaves=0,tops=0,solutions=0;long long limit;
 Search(int s,int f,const array<int,18>&xs,long long limit):S(s),F(f),source(xs),limit(limit){
  vector<int> fs={F};for(int x:xs){counts[x]++;if(!one(x))fs.push_back(x);else multiplicity[countr_zero((unsigned)x)]++;}
  for(int p=0;p<13;p++)if(S>>p&1)for(int j=0;j<B;j++)fixed[j]|=raw[1<<p].sep[j];
  for(int j=0;j<B;j++)fixed[j]|=raw[F].sep[j];
  for(auto [p,n]:obs)if(!(S&p) && none_of(fs.begin(),fs.end(),[&](int x){return (x&p)&&!(x&n);})){outside[countr_zero((unsigned)p)].push_back(n);}
 }
 bool okpartner(int p){
  auto vals=partners[p];sort(vals.begin(),vals.end());auto& memo=partner_ok[p];
  auto it=memo.find(vals);if(it!=memo.end())return it->second;
  int remain=multiplicity[p]-vals.size();vector<int> unmet;
  for(int n:outside[p])if(none_of(vals.begin(),vals.end(),[&](int x){return !(n&x);}))unmet.push_back(n);
  // Choose a non-p positive singleton from each future partner. Every true
  // circuit must yield a set of at most 'remain' witnesses avoiding one N.
  bool good=unmet.empty();
  if(!good && remain>0){
   int t=(1<<remain)-1;
   while(t<8192){
    if(!(t>>p&1)&&none_of(unmet.begin(),unmet.end(),[&](int n){return !(t&~n);})){good=true;break;}
    int z=t&-t,v=t+z;t=(((v^t)>>2)/z)|v;
   }
  }
  return memo[vals]=good;
 }
 // Fixed boundary wires, partially built trees and unconsumed leaves form a cut.
 bool possible(){
  Bits cover=fixed;
  for(auto& w:bot)for(int j=0;j<B;j++)cover[j]|=w.sep[j];
  for(int x:skip)for(int j=0;j<B;j++)cover[j]|=raw[x].sep[j];
  for(auto [x,n]:counts)if(n)for(int j=0;j<B;j++)cover[j]|=raw[x].sep[j];
  return cover==ones;
 }
 struct Node{Wire w;bool primitive;int id;};
 // No later join may have two raw parents: all such gates belong to the bottom matching.
 bool top(vector<Node> v,int depth) {
  ++tops;
  if(v.size()==7){
   if(any_of(v.begin(),v.end(),[](auto& a){return a.primitive;}))return false;
   ++solutions;
   if(solutions==1){
    cerr<<"SOLUTION "<<S<<' '<<F<<' ';for(auto&w:v)cerr<<w.w.p<<' ';cerr<<"\n";
    for(auto r:recipes)cerr<<r[0]<<','<<r[1]<<','<<r[2]<<' ';cerr<<"\n";
   }
   return true;
  }
  for(int a=0;a<(int)v.size();a++)for(int b=a+1;b<(int)v.size();b++){
   if(v[a].primitive&&v[b].primitive)continue;
   Bits other=fixed;for(int i=0;i<(int)v.size();i++)if(i!=a&&i!=b)for(int j=0;j<B;j++)other[j]|=v[i].w.sep[j];
   for(int op=0;op<=1;op++){
    if(!op&&((v[a].primitive&&one(v[a].w.p))||(v[b].primitive&&one(v[b].w.p))))continue;
    Wire w=join(v[a].w,v[b].w,op);
    bool ok=true;for(int j=0;j<B;j++)if((other[j]|w.sep[j])!=ones[j]){ok=false;break;}if(!ok)continue;
    vector<Node> next;for(int i=0;i<(int)v.size();i++)if(i!=a&&i!=b)next.push_back(v[i]);
    next.push_back({w,false,8192+(int)recipes.size()});recipes.push_back({op,v[a].id,v[b].id});
    if(top(next,depth+1))return true;recipes.pop_back();
   }
  }
  return false;
 }
 // Every forest starts with an unordered partial matching of raw leaf occurrences.
 bool match(){
  ++nodes;if(limit>0 && nodes>(unsigned long long)limit)return false;
  auto it=find_if(counts.begin(),counts.end(),[](auto&a){return a.second>0;});
  if(it==counts.end()){
   if(bot.size()<7||bot.size()>9)return false;++leaves;
   vector<Node> v;for(int x:skip)v.push_back({raw[x],true,x});
   for(int i=0;i<(int)bot.size();i++)v.push_back({bot[i],false,8192+i});
   return top(v,0);
  }
  const int a=it->first;--it->second;
  if(skip.size()<4){skip.push_back(a);if(match())return true;skip.pop_back();}
  for(auto jt=it;jt!=counts.end();++jt){
   if(!jt->second)continue;const int b=jt->first;if(a==b)continue;
   --jt->second;
   if(one(a))partners[countr_zero((unsigned)a)].push_back(b);
   if(one(b))partners[countr_zero((unsigned)b)].push_back(a);
   if(!use_partner_filter || ((!one(a)||okpartner(countr_zero((unsigned)a)))&&(!one(b)||okpartner(countr_zero((unsigned)b))))){
    for(int op=(one(a)||one(b))?1:0;op<=1;op++){
     bot.push_back(join(raw[a],raw[b],op));recipes.push_back({op,a,b});
     if(possible()&&match())return true;
     recipes.pop_back();bot.pop_back();
    }
   }
   if(one(a))partners[countr_zero((unsigned)a)].pop_back();
   if(one(b))partners[countr_zero((unsigned)b)].pop_back();
   ++jt->second;
  }
  ++it->second;return false;
 }
};
int main(int argc,char**argv){
 int p,n;ifstream ff("obs");while(ff>>p>>n)obs.emplace_back(p,n);if(obs.size()!=1323)return 1;
 for(int i=0;i<1323;i++)ones[i/64]|=U(1)<<(i%64);
 for(int m=1;m<8192;m++){
  raw[m].p=m;
  for(int i=0;i<1323;i++){
   auto [a,b]=obs[i];U mask=U(1)<<(i%64);if(a&m)pv[m][i/64]|=mask;
   if(b&m)raw[m].n[i/64]|=mask;
  }
  for(int i=0;i<B;i++)raw[m].sep[i]=pv[m][i]&~raw[m].n[i];
 }
 int s,f,ix=0;array<int,18> xs;long long budget=argc>1?atoll(argv[1]):0;
 int start=argc>2?atoi(argv[2]):0,end=argc>3?atoi(argv[3]):10000;
 while(cin>>s>>f){
  for(int&i:xs)cin>>i;if(ix>=start&&ix<end){
   Search q(s,f,xs,budget);bool sat=q.match();
   cout<<ix<<' '<<s<<' '<<f<<' '<<(sat?"SAT":budget>0&&q.nodes>(unsigned long long)budget?"UNKNOWN":"UNSAT")<<' '<<q.nodes<<' '<<q.leaves<<' '<<q.tops<<'\n'<<flush;
  }++ix;
 }
}
