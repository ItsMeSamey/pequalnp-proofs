"""Replay the cost-nine point-bank slice at P11, L9, k=1."""
from collections import Counter
from pathlib import Path
import subprocess
import sys
import tempfile

here=Path(__file__).resolve().parent
source=Path(sys.argv[1]) if len(sys.argv)>1 else here.parent/'point-pareto'
sys.path.insert(0,str(source))
from input import raw_samples

p,n,_=raw_samples(source/'L-meta-18968.json')
assert (len(p),len(n))==(28,245)
points=[tuple(map(int,line.split())) for line in (here/'point-banks.txt').read_text().splitlines()]
assert len(set(points))==len(points)==27 and all(len(f)==11 for f in points)
from domain import line_banks
lines=line_banks(p,n)
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    inp=tmp/'cases'
    with inp.open('w') as out:
        print(len(p),len(n),*sorted(p),*sorted(n),file=out)
        print(len(points)*len(lines),11,9,1,file=out)
        for f in points:
            for l in sorted(lines):
                print(*f,*l,file=out)
    exe=tmp/'frontier'
    subprocess.run(['c++','-std=c++20','-O3','-march=native',here/'frontier.cpp','-o',exe],check=True)
    with inp.open() as stream:
        out=subprocess.run([exe],stdin=stream,capture_output=True,text=True,check=True)
    hist=Counter(int(s) for s in out.stdout.splitlines())
    assert hist=={1:84,2:1140,3:77400,4:36177,5:9777,6:1065,8:150}, hist
    print('Point banks:',len(points),'line banks:',len(lines),'empty frontiers:',sum(hist.values()))
    print('First empty frontier, counts:',sorted(hist.items()))
