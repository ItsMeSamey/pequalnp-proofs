"""Check the star-local portion of the ten-paid-point allocation using sample symmetries."""
from collections import Counter
from itertools import permutations
from pathlib import Path
import subprocess
import sys
import tempfile
from domain import line_banks

here=Path(__file__).resolve().parent
base=Path(sys.argv[1]) if len(sys.argv)>1 else here.parent/'point-pareto'
local=Path(sys.argv[2]) if len(sys.argv)>2 else here.parent/'twenty-ten-lines'/'star_local.py'
sys.path.insert(0,str(base))
from input import raw_samples
p,n,_=raw_samples(base/'L-meta-18968.json')
stars=[sum(1<<((6+j+d)%13) for d in (0,1,3,9)) for j in range(7)]
inc=[sum(bool(s>>i&1)<<j for j,s in enumerate(stars)) for i in range(13)]
def permute(x,perm):
    return sum(1<<v for i,v in enumerate(perm) if x>>i&1)
actions=[]
for lines in permutations(range(7)):
    moved=[permute(m,lines) for m in inc]
    if set(moved)!=set(inc):continue
    point_perm=[inc.index(m) for m in moved]
    def transform(row):return permute(row&8191,point_perm)|(permute(row>>13,lines)<<13)
    if any({transform(row) for row in table}!=set(table) for table in (p,n)):continue
    actions.append((point_perm,[permute(x,lines) for x in range(128)]))
assert len(actions)==24
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    path=tmp/'banks.txt'
    subprocess.run([sys.executable,local,path],check=True)
    points=[tuple(map(int,s.split())) for s in path.read_text().splitlines()]
    assert len(set(points))==len(points)==354
    line_sets=sorted(f for f,c in line_banks(p,n).items() if c<=3)
    assert len(line_sets)==2069
    reps=Counter()
    for f in points:
        image=[tuple(sorted(permute(m,q) for m in f)) for q,_ in actions]
        target=min(image)
        perms=[actions[i][1] for i,v in enumerate(image) if v==target]
        for line_set in line_sets:
            reps[target,min(tuple(sorted(q[m] for m in line_set)) for q in perms)]+=1
    assert len(reps)==31826
    exe=tmp/'frontier'
    subprocess.run(['c++','-std=c++20','-O3','-march=native',here/'frontier.cpp','-o',exe],check=True)
    with (tmp/'cases').open('w') as stream:
        print(len(p),len(n),*sorted(p),*sorted(n),file=stream)
        print(len(reps),11,9,1,file=stream)
        for f,l in sorted(reps):print(*f,*l,file=stream)
    with (tmp/'cases').open() as stream:
        res=subprocess.run([exe],stdin=stream,capture_output=True,text=True,check=True)
    levels=list(map(int,res.stdout.splitlines()))
    assert len(levels)==len(reps)
    hist=Counter()
    for pair,level in zip(sorted(reps),levels):hist[level]+=reps[pair]
    assert hist == {1:459,2:4455,3:237300,4:319566,5:131592,6:23013,7:11766,8:4218,9:3,10:54}
    print('31,826 representatives:',sum(hist.values()),'labelled cases; depths',sorted(hist.items()))
