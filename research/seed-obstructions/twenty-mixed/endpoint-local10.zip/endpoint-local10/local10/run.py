import sys, subprocess
from hashlib import sha256
from collections import defaultdict
from pathlib import Path
from tempfile import TemporaryDirectory
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'certificate'))
from samples import actions,raw_samples
from verify import make_cases
def main():
 raw=(here/'banks.txt').read_bytes()
 assert sha256(raw).hexdigest()=='bf2fc676af927663edab4a1aff894904fd5978b8a9f0b67ef4b5e2be9938c485'
 banks=[tuple(map(int,r.split())) for r in raw.decode().splitlines()]
 assert len(set(banks))==len(banks)==354 and all(len(b)==11 for b in banks)
 masks=[m for m in range(128) if m.bit_count()<=4]
 pairs=[(b,m) for b in banks for m in masks]
 assert len(pairs)==35046
 pos,neg=raw_samples(here.parent/'certificate'/'L-meta-18968.json')
 stars=[sum(1<<((j+6+d)%13) for d in (0,1,3,9)) for j in range(7)]
 transforms=[]
 for pm in actions(pos,neg):
  line=[1<<stars.index(pm[t]) for t in stars]
  lm=[sum(x for i,x in enumerate(line) if m>>i&1) for m in range(128)]
  transforms.append((pm,lm))
 assert len(transforms)==24
 # Partition only after constructing the full labelled list. An orbit is
 # indexed by its unrestricted minimum, but use a genuine input to test it.
 classes=defaultdict(list)
 for b in banks:
  bmaps=[tuple(sorted(pm[x] for x in b)) for pm,lm in transforms]
  for m in masks:
   key=min((bm,lm[m]) for bm,(_,lm) in zip(bmaps,transforms))
   classes[key].append((b,m))
 assert len(classes)==1641 and sum(map(len,classes.values()))==len(pairs)
 reps=defaultdict(list)
 index={b:i for i,b in enumerate(banks)}
 # Each row in the optional explicit mapping is (point ID, mask,
 # representative point ID, representative mask). Point IDs index banks.txt.
 mapping=[]
 for orbit in classes.values():
  b,m=min(orbit)
  reps[b].append((m,len(orbit)))
  mapping.extend((index[u],v,index[b],m) for u,v in orbit)
 if len(sys.argv)>1:
  with Path(sys.argv[1]).open('w') as f:
   for row in sorted(mapping):print(*row,file=f)
 if '--listing-only' in sys.argv:return
 print('labelled',len(pairs),'orbits',len(classes),'point representatives',len(reps),flush=True)
 with TemporaryDirectory() as work:
  solver=Path(work)/'endpoint'
  subprocess.run(['c++','-std=c++20','-O3','-march=native',here.parent/'certificate'/'endpoint.cpp','-o',solver],check=True)
  for i,(b,entries) in enumerate(sorted(reps.items())):
   entries.sort()
   rs=subprocess.run([solver,'11','8','2'],input=make_cases(b,[m for m,n in entries],pos,neg),text=True,capture_output=True,check=True).stdout
   for (m,n),r in zip(entries,rs.splitlines(),strict=True):
    print('case',i,m,n,r,flush=True)
    assert r.split()[0]=='0',(b,m,r)
if __name__=='__main__':main()
