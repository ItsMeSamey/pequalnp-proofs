"""Enumerate star-local point banks satisfying the ten-gate projection bound."""
import sys
from pathlib import Path
from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'point-pareto'))
from input import point_obligations
raw,rows=point_obligations(here.parent/'point-pareto/L-meta-18968.json')
stars=[sum(1<<((6+j+d)%13) for d in (0,1,3,9)) for j in range(7)]
raw=set(raw)
local=sorted(x for x in range(8192) if x.bit_count()>=2 and any(not x&~t for t in stars))
assert len(local)==77 and not set(local)&raw
pool=IDPool()
flags={x:pool.id() for x in sorted(raw)+local}
clauses=CardEnc.atmost(list(flags.values()),11,vpool=pool).clauses
heavy=[]
for t in stars:
    group=[x for x in local if not x&~t]
    unit,second=pool.id(),pool.id()
    heavy.extend((unit,second))
    for x in group:
        other=[flags[y] for y in group if x!=y]
        if x.bit_count()>=3:
            clauses.append([-flags[x],*other,unit])
        if x.bit_count()==4:
            clauses.append([-flags[x],*other,second])
    for x in group:
        if x!=t:
            clauses.append([-flags[t],-flags[x],*[flags[y] for y in group if y not in (t,x)],unit])
clauses.extend(CardEnc.atmost([flags[x] for x in local]+heavy,10,vpool=pool).clauses)
for p,n in rows:clauses.append([v for x,v in flags.items() if x&p and not x&n])
banks=[]
with Solver(name='cadical195',bootstrap_with=clauses) as solver:
    while solver.solve():
        model=set(solver.get_model())
        banks.append(tuple(sorted(x for x,q in flags.items() if q in model)))
        solver.add_clause([-q if q in model else q for q in flags.values()])
assert len(banks)==354 and all(len(bank)==11 for bank in banks)
if len(sys.argv)>1:
    Path(sys.argv[1]).write_text(''.join(' '.join(map(str,b))+'\n' for b in sorted(banks)))
print('354 affordable star-local candidate banks, all of width eleven.',flush=True)
