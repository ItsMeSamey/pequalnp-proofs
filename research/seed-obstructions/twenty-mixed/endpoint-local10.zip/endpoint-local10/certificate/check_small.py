"""Compare against direct topological DAG enumeration on all four-variable targets."""
import subprocess
import tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
def run(args,stdin=''):
    return subprocess.run(args,text=True,input=stdin,capture_output=True,check=True).stdout
def main():
    monotones=[s for s in range(1,65535) if all(not (s>>i&1) or (s>>j&1)
               for i in range(16) for j in range(16) if i&j==i)]
    assert len(monotones)==166
    with tempfile.TemporaryDirectory() as temp:
        binaries={}
        for name in ('small_verify','endpoint'):
            binary=Path(temp)/name
            subprocess.run(['c++','-std=c++20','-O3',HERE/(name+'.cpp'),'-o',binary],check=True)
            binaries[name]=binary
        for k in range(3):
            truths=set(map(int,run([binaries['small_verify'],str(k)]).split()))
            inputs=[]
            for s in monotones:
                p=[i for i in range(16) if s>>i&1]
                n=[i for i in range(16) if not s>>i&1]
                inputs.extend([len(p),len(n),*p,*n])
            text=' '.join(map(str,inputs))+'\n'
            out=run([binaries['endpoint'],'2','2',str(k)],text)
            observed={s for s,r in zip(monotones,out.splitlines(),strict=True) if int(r.split()[0])}
            assert observed==truths,(k,observed^truths)
            print(k,len(monotones),len(truths),'match')
if __name__=='__main__':main()
