#include <array>
#include <cstdio>
#include <cstdlib>
#include <set>
using namespace std;
array<int,10> val{},type{},anc{};
set<int> truth;
void build(int i,int out){
 if(i==out+1){if(anc[out]==(1<<(out+1))-1)truth.insert(val[out]);return;}
 for(int j=0;j<i;j++)for(int h=j;h<i;h++){
  if((type[j]|type[h])!=3)continue;
  type[i]=3;anc[i]=anc[j]|anc[h]|(1<<i);
  val[i]=val[j]|val[h];build(i+1,out);
  val[i]=val[j]&val[h];build(i+1,out);
 }
}
int main(int argc,char** argv){int k=atoi(argv[1]);for(int j=0;j<4;j++){type[j]=j<2?1:2;anc[j]=1<<j;for(int x=0;x<16;x++)if(x>>j&1)val[j]|=1<<x;}
 build(4,6+k);for(int v:truth)printf("%d\n",v);}
