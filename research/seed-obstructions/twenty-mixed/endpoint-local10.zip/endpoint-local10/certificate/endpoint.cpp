#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <set>
#include <unordered_map>
#include <vector>

using Mask = unsigned;
struct Signature {
    Mask positive = 0;
    std::array<uint64_t, 4> negative{};
    int type = 0; // point=1, line=2, mixed=3
    auto operator<=>(const Signature&) const = default;
};
using Frontier = std::vector<Signature>;
struct Source {
    Mask leaves;
    Signature value;
    auto operator<=>(const Source&) const = default;
};

Signature combine(const Signature& a, const Signature& b, bool is_and) {
    Signature r;
    r.positive = is_and ? a.positive & b.positive : a.positive | b.positive;
    for (int i = 0; i < 4; ++i)
        r.negative[i] = is_and ? a.negative[i] & b.negative[i] : a.negative[i] | b.negative[i];
    r.type = a.type | b.type;
    return r;
}

bool fits(const Signature& value, const Signature& required) {
    if (required.positive & ~value.positive) return false;
    for (int i = 0; i < 4; ++i)
        if (required.negative[i] & value.negative[i]) return false;
    return true;
}

struct Constraints {
    const Frontier& inputs;
    const int size;
    const Mask all;
    bool separable = true;
    std::array<std::array<Mask, 24>, 2> edge{};
    std::unordered_map<Mask, Signature> differences, cache;

    Constraints(const Frontier& signals, int np, int nn, bool record_differences)
        : inputs(signals), size(signals.size()), all((1u << size) - 1) {
        std::vector<Mask> pos(np), neg(nn), sensitive_pos(np), sensitive_neg(nn);
        for (int j = 0; j < size; ++j) {
            for (int i = 0; i < np; ++i)
                if (signals[j].positive >> i & 1) pos[i] |= 1u << j;
            for (int i = 0; i < nn; ++i)
                if (signals[j].negative[i / 64] >> (i % 64) & 1) neg[i] |= 1u << j;
        }
        for (int i = 0; i < np; ++i) {
            for (int j = 0; j < nn; ++j) {
                Mask delta = pos[i] & ~neg[j];
                if (!delta) { separable = false; return; }
                if (record_differences) {
                    auto& rows = differences[delta];
                    rows.positive |= 1u << i;
                    rows.negative[j / 64] |= 1ULL << (j % 64);
                }
                if (std::has_single_bit(delta)) {
                    sensitive_pos[i] |= delta;
                    sensitive_neg[j] |= delta;
                }
            }
        }
        for (int kind = 0; kind < 2; ++kind)
            for (Mask active : (kind ? sensitive_neg : sensitive_pos))
                for (Mask q = active; q; q &= q - 1)
                    edge[kind][std::countr_zero(q)] |= active ^ (q & -q);
    }

    // An OR split cannot cross an AND edge, and an AND split cannot cross an OR edge.
    bool cotree(Mask leaves) const {
        if (!leaves || std::has_single_bit(leaves)) return true;
        for (const auto& graph : edge) {
            Mask component = leaves & -leaves;
            Mask queue = component;
            while (queue) {
                int vertex = std::countr_zero(queue);
                queue &= queue - 1;
                Mask added = graph[vertex] & leaves & ~component;
                queue |= added;
                component |= added;
            }
            if (component != leaves) return cotree(component) && cotree(leaves ^ component);
        }
        return false;
    }

    const Signature& requirements(Mask leaves) {
        auto [it, fresh] = cache.try_emplace(leaves);
        if (fresh)
            for (const auto& [delta, rows] : differences)
                if (!(delta & ~leaves)) it->second = combine(it->second, rows, false);
        return it->second;
    }

    bool permits(Mask left, Mask right, bool is_and) const {
        for (Mask q = left; q; q &= q - 1)
            if (edge[is_and][std::countr_zero(q)] & right) return false;
        return true;
    }

    std::vector<std::vector<Source>> sources() {
        std::vector<std::vector<Source>> by_size(size + 1);
        for (int j = 0; j < size; ++j) by_size[1].push_back({1u << j, inputs[j]});
        for (int n = 2; n <= size; ++n) {
            std::set<Source> candidates;
            for (int l = 1; l <= n / 2; ++l) {
                for (const auto& a : by_size[l]) for (const auto& b : by_size[n-l]) {
                    if ((2*l == n && a.leaves >= b.leaves) || (a.leaves & b.leaves)) continue;
                    if ((a.value.type | b.value.type) != 3) continue;
                    Mask leaves = a.leaves | b.leaves;
                    for (bool is_and : {false, true}) {
                        if (!permits(a.leaves, b.leaves, is_and)) continue;
                        Signature merged = combine(a.value, b.value, is_and);
                        if (fits(merged, requirements(leaves))) candidates.insert({leaves, merged});
                    }
                }
            }
            by_size[n].assign(candidates.begin(), candidates.end());
        }
        return by_size;
    }
};

struct Search {
    int np, nn, limit;
    std::array<std::set<Frontier>, 5> visited;
    std::array<long long, 24> first_sizes{};
    long long terminal_cotrees = 0;

    bool solve(Frontier inputs, int remaining) {
        std::sort(inputs.begin(), inputs.end());
        if (!visited[remaining].insert(inputs).second) return false;
        if (remaining == 0) {
            Constraints probe(inputs, np, nn, false);
            if (!probe.separable || !probe.cotree(probe.all)) return false;
            ++terminal_cotrees;
        }
        Constraints constraints(inputs, np, nn, true);
        if (!constraints.separable) return false;
        auto sources = constraints.sources();
        if (remaining == 0) return !sources.back().empty();
        for (int size = 1; size <= constraints.size; ++size) {
            for (const auto& source : sources[size]) {
                if (remaining == limit) ++first_sizes[size];
                Frontier next;
                for (int j = 0; j < constraints.size; ++j)
                    if (!(source.leaves >> j & 1)) next.push_back(inputs[j]);
                next.push_back(source.value);
                next.push_back(source.value);
                if (solve(next, remaining-1)) return true;
            }
        }
        return false;
    }
};

int main(int argc, char** argv) {
    int points = 11, width = 19, limit = 2;
    if (argc == 4) {
        points = std::atoi(argv[1]);
        width = points + std::atoi(argv[2]);
        limit = std::atoi(argv[3]);
    } else if (argc != 1) return 4;
    if (points <= 0 || width <= points || limit < 0 || limit > 4 || width + limit > 23) return 4;
    int np, nn;
    while (std::scanf("%d%d", &np, &nn) == 2) {
        if (np < 0 || nn < 0 || np > 32 || nn > 256) return 3;
        Frontier inputs(width);
        for (bool negative : {false, true}) for (int i = 0; i < (negative ? nn : np); ++i) {
            Mask row;
            if (std::scanf("%u", &row) != 1 || row >= (1u << width)) return 3;
            for (int j = 0; j < width; ++j) if (row >> j & 1) {
                if (negative) inputs[j].negative[i / 64] |= 1ULL << (i % 64);
                else inputs[j].positive |= 1u << i;
            }
        }
        for (int j = 0; j < width; ++j) inputs[j].type = j < points ? 1 : 2;
        Search search{np, nn, limit};
        bool found = search.solve(inputs, limit);
        std::printf("%d pre %zu final %zu cot %lld first", found,
                    search.visited[1].size(), search.visited[0].size(), search.terminal_cotrees);
        for (int i = 1; i < 24; ++i)
            if (search.first_sizes[i]) std::printf(" %d:%lld", i, search.first_sizes[i]);
        std::puts("");
        std::fflush(stdout);
    }
}
