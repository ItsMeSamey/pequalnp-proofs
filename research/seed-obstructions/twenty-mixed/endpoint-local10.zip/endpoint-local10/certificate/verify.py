"""Reproduce the point-cost-nine P11/L8/two-surplus exclusions."""
import argparse
import hashlib
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

from samples import raw_samples

HERE=Path(__file__).resolve().parent
BANKS={
    'cost-nine-six.txt':'6bb7da07db52298b436c8cd9e4e221d398d0367ad156b15e393cf5db8c47c72a',
    'three-seven-output-banks.txt':'3b798cece27d9da60cb6b88f895f525142854c1fa145f655c47c51d0238ae50a',
}

def point_banks():
    banks=[]
    for filename,digest in BANKS.items():
        path=HERE/filename
        assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
        banks.extend(tuple(map(int,line.split())) for line in path.read_text().splitlines())
    assert len(set(banks))==len(banks)==27
    assert all(len(bank)==len(set(bank))==11 for bank in banks)
    return banks

def make_cases(bank,extras,positives,negatives):
    def project(row):
        return sum(bool(row&8191&m)<<i for i,m in enumerate(bank))|((row>>13)<<11)
    selected=[list(map(project,rows)) for rows in (positives,negatives)]
    cases=[]
    for extra in extras:
        p,n=({r|(bool((r>>11)&extra)<<18) for r in rows} for rows in selected)
        n={r for r in n if not any(r!=s and r&~s==0 for s in n)}
        cases.extend((str(len(p)),str(len(n)),*map(str,sorted(p)),*map(str,sorted(n))))
    return ' '.join(cases)+'\n'

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--cost-four',action='store_true',help='Check just the 21 five-line masks.')
    args=parser.parse_args()
    positives,negatives=raw_samples(HERE/'L-meta-18968.json')
    masks=[m for m in range(128) if not args.cost_four or m.bit_count()==5]
    totals=Counter()
    with tempfile.TemporaryDirectory() as temp:
        binary=Path(temp)/'endpoint'
        subprocess.run(['c++','-std=c++20','-O3','-march=native',HERE/'endpoint.cpp','-o',binary],check=True)
        for bank in point_banks():
            inp=make_cases(bank,masks,positives,negatives)
            out=subprocess.run([binary,'11','8','2'],input=inp,text=True,check=True,capture_output=True).stdout
            for m,line in zip(masks,out.splitlines(),strict=True):
                fields=line.split()
                assert fields[0]=='0' and fields[1:8:2]==['pre','final','cot','first']
                totals['cases']+=1
                totals['first-endpoint states']+=int(fields[2])
                totals['terminal states']+=int(fields[4])
                totals['terminal cotrees']+=int(fields[6])
        expected = (567,14352,271347,0) if args.cost_four else (3456,80778,1444746,0)
        assert tuple(totals.values())==expected,totals
    for label,value in totals.items():print(label,value)

if __name__=='__main__':
    if not __debug__:raise SystemExit('Run with Python assertions enabled.')
    main()
