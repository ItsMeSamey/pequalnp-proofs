"""Equality forests for eight selected nonraw point roots at eleven paid gates."""
from instance import free, rows, local, many, equality_cases
from argparse import ArgumentParser
from pathlib import Path
from io import StringIO
from itertools import combinations
from functools import lru_cache
from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
from collections import defaultdict
@lru_cache(None)
def cofactors(R):
 if not R:return {0}
 if len(R)==1:return {0,R[0]}
 result=set()
 # Zeroing singleton leaves may delete subexpressions; allowing each
 # nonsingleton primitive to be omitted subsumes all such simplifications.
 for split in range(1,1<<(len(R)-1)):
  left=tuple(x for j,x in enumerate(R) if split>>j&1)
  right=tuple(x for j,x in enumerate(R) if not split>>j&1)
  for a in cofactors(left):
   for b in cofactors(right):result.update((a|b,a&b))
 return result
def tiles(f,S,ds,chosen_raw):
 F=[x for j,x in enumerate(many) if f>>j&1]
 P=[1<<j for j,d in enumerate(ds) if d and not S>>j&1]
 caps={}
 for p in P:
  unresolved={n for a,n in rows if a==p and not any(p&x and not n&x for x in F)}
  forbid=set()
  for W in combinations([1<<i for i in range(13) if 1<<i!=p],ds[p.bit_length()-1]-1):
   w=sum(W);v=0
   for n in unresolved:
    if not w&~n:v|=n
   forbid.add(v)
  caps[p]=sorted(v for v in forbid if not any(u!=v and not u&~v for u in forbid))
 F=[x for x in F if x not in chosen_raw]
 lim=5+len(chosen_raw)
 out=set()
 for l in range(min(lim,len(F))+1):
  for extra in combinations(range(len(F)),l):
   ix=sum(1<<d for d in extra)
   vals=cofactors(tuple(F[d] for d in extra))
   for n in range(max(0,2-l),min(lim-l,len(P))+1):
    for chosen in combinations(P,n):
     leaves=sum(chosen)
     for h in vals:
      z=leaves|h
      if z in free or not z:continue
      if all(any(not z&o for o in caps[p]) for p in chosen):
       out.add((leaves,ix,z))
 return sorted(out),len(F)
def solve(f,S,ds,out,only_nonlocal=True,chosen_raw=()):
 ts,nf=tiles(f,S,ds,chosen_raw)
 pool=IDPool()
 vf={(p,f,z,i):pool.id() for p,f,z in ts for i in range(1 if f else min(ds[j] for j in range(13) if p>>j&1))}
 g=defaultdict(list)
 for t,v in vf.items():g[t[2]].append(v)
 Z={z:pool.id() for z in g}
 solver=Solver(name='cadical195');add=solver.add_clause
 for (p,f,z,i),v in vf.items():
  if i:add([-v,vf[p,f,z,i-1]])
 def eq(variables,n):
  if not 0<=n<=len(variables):add([]);return
  if n==0:
   for v in variables:add([-v])
   return
  if len(variables)==n:
   for v in variables:add([v])
   return
  for cl in CardEnc.equals(variables,n,vpool=pool).clauses:add(cl)
 for z,flags in g.items():
  for v in flags:add([-v,Z[z]])
  add([-Z[z],*flags])
 eq(list(vf.values()),8-len(chosen_raw))
 for j,n in enumerate(ds):
  if not S>>j&1:eq([v for (P,F,z,i),v in vf.items() if P>>j&1],n)
 for j in range(nf):eq([v for (P,F,z,i),v in vf.items() if F>>j&1],1)
 if only_nonlocal:add([q for z,q in Z.items() if z not in local])
 for p,n in rows:
  if not S&p and not any(p&x and not n&x for x in chosen_raw):add([q for z,q in Z.items() if z&p and not z&n])
 cnt=0
 while solver.solve():
  model=set(solver.get_model());b=sorted([z for z,q in Z.items() if q in model]+[1<<j for j in range(13) if S>>j&1]+list(chosen_raw))
  assert len(b)<=11 and all(any(z&p and not z&n for z in b) for p,n in rows)
  print(*b,file=out,flush=True);cnt+=1
  add([-q if q in model else q for q in Z.values()])
 solver.delete();return len(ts),len(Z),cnt
if __name__=='__main__':
 parser=ArgumentParser()
 parser.add_argument('--selected', choices=(7,8), type=int, default=8)
 parser.add_argument('--control', action='store_true')
 args=parser.parse_args()
 num=total=roots=0
 for f,S,ds in equality_cases():
  selected_options=[()] if args.selected==8 else [(x,) for j,x in enumerate(many) if f>>j&1]
  for u in selected_options:
   stream=StringIO()
   tile_count,sigs,count=solve(f,S,ds,stream,not args.control,u)
   roots+=tile_count;total+=count;num+=1
   if not args.control:assert not count,stream.getvalue()
 assert num==(266 if args.selected==8 else 609)
 print(num,'equality cases,',roots,'root descriptions,',total,'covering bank occurrences.')
