"""Independent check with four existentially selected singleton signals per star pair."""
from itertools import combinations
from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
from instance import raw, rows, stars

roots = {op for a,b in combinations(raw,2) for op in (a|b,a&b)}-set(raw)-{0}
assert len(roots)==327
nonlocal_roots={m for m in roots if all(m & ~t for t in stars)}
for t,u in combinations(stars,2):
    ids=IDPool()
    features={m:ids.id() for m in sorted(roots)}
    singleton={1<<i:ids.id() for i in range(13)}
    clauses=CardEnc.atmost(list(features.values()),5,vpool=ids).clauses
    clauses+=CardEnc.equals(list(singleton.values()),4,vpool=ids).clauses
    clauses.append([features[m] for m in nonlocal_roots])
    # Reduce the fixed positive clauses by containment, preserving the
    # existential choice of four singleton inputs in the same SAT instance.
    constraints=set()
    for p,n in rows:
        if (p&t and not n&t) or (p&u and not n&u):
            continue
        constraints.add(frozenset([singleton[p],*[v for m,v in features.items() if p&m and not n&m]]))
    minimal=[]
    for c in sorted(constraints,key=lambda x:(len(x),sorted(x))):
        if not any(previous <= c for previous in minimal):
            minimal.append(c)
    clauses.extend(map(list,minimal))
    with Solver(name='glucose4',bootstrap_with=clauses) as s:
        result=s.solve()
        assert not result,(t,u,s.get_model())
        print(t,u,'UNSAT',len(minimal),flush=True)
