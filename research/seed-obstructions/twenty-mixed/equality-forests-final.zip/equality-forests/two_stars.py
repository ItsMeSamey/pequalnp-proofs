"""All g11 forests with two full stars among seven point roots and four singleton outputs."""
from instance import free, rows, local, stars as T
from itertools import combinations
from argparse import ArgumentParser
from pysat.solvers import Solver
from pysat.card import CardEnc
from pysat.formula import IDPool
from collections import Counter
shallow=sorted({x|y for x,y in combinations(free,2)}-free-{0})
assert len(shallow)==327 and all((x&y) in free|{0} for x,y in combinations(free,2))
a=IDPool();single=[a.id() for j in range(13)];star=[a.id() for t in T];Z={x:a.id() for x in shallow}
s=Solver(name='cadical195')
for c in CardEnc.atmost(list(Z.values()),5,vpool=a).clauses:s.add_clause(c)
s.add_clause([q for x,q in Z.items() if x not in local])
for p,n in rows:
 s.add_clause([single[p.bit_length()-1],*[q for t,q in zip(T,star) if t&p and not t&n],*[q for x,q in Z.items() if x&p and not x&n]])
parser=ArgumentParser()
parser.add_argument('--overlap', action='store_true')
zero=not parser.parse_args().overlap
total=0;cases=0
for j,k in combinations(range(7),2):
 ds=[q if i in (j,k) else -q for i,q in enumerate(star)];cnt=0
 for P in combinations(range(13),4):
  S=sum(1<<i for i in P)
  if zero and S&(T[j]|T[k]):continue
  if not zero and not S&(T[j]|T[k]):continue
  aa=ds+[q if i in P else -q for i,q in enumerate(single)];cases+=1
  assert not s.solve(assumptions=aa),(j,k,P)
 total+=cnt;print(j,k,cases,cnt,total,s.accum_stats()['conflicts'],flush=True)

assert cases == (315 if zero else 14700)
