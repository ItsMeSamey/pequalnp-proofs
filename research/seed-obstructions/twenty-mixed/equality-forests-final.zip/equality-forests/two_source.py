"""Tighten the raw-point occurrence demand with two canonical four-leaf star trees."""
from collections import Counter
from itertools import combinations
from instance import many, stars, demand_tables

tables = demand_tables()
pairs = {}
for j,k in combinations(range(7),2):
    pairs[j,k]=[((stars[j]>>i)&1)+((stars[k]>>i)&1) for i in range(13)]
base_stats=Counter()
hits=Counter()
for f in range(1 << len(many)):
    d=[lookup[incident & f] for incident,lookup in tables]
    count=f.bit_count()
    if count + sum(sorted(d)[:9]) > 18:
        continue
    for selected in combinations(range(13),4):
        base=count+sum(d)-sum(d[i] for i in selected)
        if base>18:
            continue
        base_stats[base]+=1
        need=d.copy()
        for i in selected:
            need[i]=0
        for forced in pairs.values():
            total=count+sum(max(a,b) for a,b in zip(need,forced))
            if total<=18:
                hits[total]+=1
assert base_stats == {16:83,17:2184,18:25068}
assert hits == {18:660}
print('Ordinary raw use counts',dict(sorted(base_stats.items())))
print('With both canonical trees',dict(hits))
