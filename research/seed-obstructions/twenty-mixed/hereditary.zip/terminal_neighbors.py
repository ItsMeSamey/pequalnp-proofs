"""Test every possible one-slot replacement of the 27 nine-gate covering banks."""
from exact import pareto,point_obligations

raw,rows=point_obligations(pareto/'L-meta-18968.json')
stars=[708,1416,2832,5664,3137,6274,4357]
files=[pareto/'cost-nine-six.txt',pareto.parent/'twenty-ten-lines/three-seven-output-banks.txt']
banks=[tuple(map(int,line.split())) for file in files for line in file.read_text().splitlines()]
assert len(banks)==len(set(banks))==27
covering=nonlocal_count=0
for bank in banks:
    lower=[0]*11;forbidden=[0]*11
    for p,n in rows:
        hits=[i for i,x in enumerate(bank) if x&p and not x&n]
        assert hits
        if len(hits)==1:
            j=hits[0];lower[j]|=p;forbidden[j]|=n
    for lo,ban in zip(lower,forbidden):
        assert not (lo&ban)
        flex=8191&~(lo|ban);z=flex
        while True:
            m=lo|z;covering+=1
            if m not in raw and all(m&~t for t in stars):nonlocal_count+=1
            if not z:break
            z=(z-1)&flex
print('banks',len(banks),'covering single-slot alternatives',covering,'nonlocal',nonlocal_count)
assert nonlocal_count==0
