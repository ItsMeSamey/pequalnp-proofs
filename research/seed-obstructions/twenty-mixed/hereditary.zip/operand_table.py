from operand_audit import *
for k in range(14):
 vals=[]
 for s in range(k+1):
  allowed=size>=k-s
  a=size-(k-s)+ordered[:,:13-s].sum(axis=1)
  val=int(a[allowed].min())
  arg=allowed&(a==val)
  fs=sorted(set(size[arg].tolist()))
  vals.append((val,s,fs,int(arg.sum())))
 best=min(x[0] for x in vals)
 print('selected raw',k,'minimum source reads',best,'attainers',(list(x[1:] for x in vals if x[0]==best)),flush=True)
 if k<=6:print(' singleton-count optima',[x[0] for x in vals],flush=True)
