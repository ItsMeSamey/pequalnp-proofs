# Nonlocal eleven-wire point banks at cost ten

A point bank contains at most eleven singleton signatures from the thirteen-point residual. A computed boundary mask is nonlocal if it is contained in none of the seven target stars. This package tests programs with exactly ten paid point gates and a nonlocal selected computed mask. The companion point-Pareto and ten-line certificates show that every covering bank of cost at most nine is star-local. Consequently a nonlocal bank in this package has an essential ten-gate realization on singleton signatures. An unused gate, a zero gate, a duplicate result, or a result equal to a raw mask could be removed, contradicting that cost minimum.

The input statement, raw samples, 31 raw point masks and 1,323 point-separation obligations come from the sibling directory `point-pareto`.

## Seven selected computed masks

The search uses at most four raw selected inputs and seven distinct, sorted computed masks. It first imposes point separation, nonlocality and distinctness from raw masks without any circuit restrictions on the seven computed outputs. The certificate then excludes intervals of candidate masks using the previously verified geometric theorem that any family J of target stars costs at least three gates per star, even when all masks meeting each retained star in at most one point are provided for free.

A cut specifies lower and upper bitmasks for each of the seven selected outputs and a nonempty subfamily J. Restrict the program to the union U of the stars in J. A required computed output whose upper mask meets every retained star in at most one point can be provided for free, saving its distinct paid gate. For each retained star t, direct construction from raw singletons costs three additional gates. Each guaranteed clean piece with k points saves at least k−1, provided its possible support in U is contained in t. Two clean pieces covering t save two gates. Two guaranteed supersets of t whose possible intersection in U is t itself also save two gates by using their intersection. Taking the best saving per star and adding the deleted paid gates gives a lower bound on the original program cost. Each recorded cut has lower bound at least eleven. The verifier checks these claims directly in Python and converts each forbidden interval to one CNF clause.

Run `python verify.py verify 7 h7.cuts.gz` to validate all recorded intervals and check the final Boolean query. Supply `--cnf /tmp/h7.cnf --checker /path/to/drat-trim` for independently checked propositional refutation. To rediscover the cuts, use `python verify.py generate 7 my.cuts.gz` with a C++20 compiler. The C++ helper is needed only for discovery. The public validation uses the Python checks.

## Nine or ten selected computed masks

Run `python exact.py 9` and `python exact.py 10` with Python-SAT. The exact gate encoding sorts the selected and hidden point masks separately and permits every chronological order through acyclic precedence variables. Each gate must equal a binary union or intersection of two available sources. All hidden gates must feed another selected gate or an intermediate. Distinctness and nonlocality use the original thirteen singleton coordinates. Both commands accept the same optional CNF and DRAT checker arguments as the cut verifier.

The eight-selected case is separate. A nonlocal point bank satisfying the pure relaxation would still require a mixed read-once circuit and a valid lift to the full raw samples.
