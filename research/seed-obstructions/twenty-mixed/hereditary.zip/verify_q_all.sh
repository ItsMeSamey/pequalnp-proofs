#!/bin/sh
set -eu
cd "$(dirname "$0")"
python pattern_boundary.py 5
python pattern_boundary.py 6
for ordinary in 0 1 2 3 4 5 6; do
  python q_pattern.py "$ordinary" --selected-extra 7 --original 8
done
