"""Independent audit of raw-operand lower bounds using downward closure of negative masks."""
from pathlib import Path
import sys
import numpy as np
pdir=Path(__file__).resolve().parent.parent/'point-pareto'
sys.path.insert(0,str(pdir))
from input import point_obligations
raw,rows=point_obligations(pdir/'L-meta-18968.json')
nonsingle=[m for m in raw if m.bit_count()>1]
assert len(nonsingle)==18
subsets=np.arange(1<<18,dtype=np.int32)
size=np.array([i.bit_count() for i in range(1<<18)],dtype=np.int16)
masks=np.arange(8192,dtype=np.int32)
per=np.empty((len(subsets),13),dtype=np.int16)
for i in range(13):
 p=1<<i
 ns=[n for x,n in rows if x==p];assert all(not n&p for n in ns)
 inc=[j for j,m in enumerate(nonsingle) if m&p]
 ix=np.zeros(len(subsets),dtype=np.int16)
 for k,j in enumerate(inc):ix|=((subsets>>j)&1).astype(np.int16)<<k
 local=[]
 for keep in range(1<<len(inc)):
  selected=[nonsingle[j] for k,j in enumerate(inc) if keep>>k&1]
  uncovered=[n for n in ns if all(n&m for m in selected)]
  if not uncovered:local.append(0);continue
  # bad[w] iff w is contained in at least one remaining negative.
  bad=np.zeros(8192,dtype=bool);bad[uncovered]=True
  for b in range(13):
   step=1<<b;view=bad.reshape(-1,2*step);view[:,:step]|=view[:,step:]
  valid=(~bad)&((masks&p)==0)
  assert np.any(valid)
  local.append(int(np.min(size[:8192][valid])))
 per[:,i]=np.array(local)[ix]
# For fixed nonsingleton availability F, the s best selected raw singletons
# remove precisely the s largest direct-read lower bounds. No upper cutoff on F.
ordered=np.sort(per,axis=1)
for s in range(4):
 total=size-(3-s)+ordered[:,:13-s].sum(axis=1)
 allowed=size>=3-s
 low=int(np.min(total[allowed]));idx=int(np.flatnonzero(allowed&(total==low))[0])
 print(s,'minimum',low,'witness frozen raw count',int(size[idx]),flush=True)
 assert low==[25,23,21,19][s]
