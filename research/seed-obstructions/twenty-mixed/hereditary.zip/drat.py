"""Send CaDiCaL's binary DRAT stream to drat-trim without expanding it in Python."""
import subprocess
from pysat.solvers import pysolvers

def verify_binary(solver,cnf,checker):
    native=solver.solver
    pysolvers.flushpr(native.prfp)
    native.prfile.seek(0)
    run=subprocess.run([str(checker),str(cnf),'-i'],stdin=native.prfile,stdout=subprocess.PIPE,check=True)
    out=run.stdout.decode()
    if 's VERIFIED' not in out:raise RuntimeError('drat-trim failed to certify UNSAT')
    for line in out.splitlines():
        if 'VERIFIED' in line or 'verification time' in line:print(line,flush=True)
