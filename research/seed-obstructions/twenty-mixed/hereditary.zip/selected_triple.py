from exact import pareto,point_obligations
from itertools import combinations
from collections import Counter
from pathlib import Path
raw,rows=point_obligations(pareto/'L-meta-18968.json')
stars=[708,1416,2832,5664,3137,6274,4357]
files=[pareto/'cost-nine-six.txt',pareto.parent/'twenty-ten-lines/three-seven-output-banks.txt']
banks=[tuple(map(int,l.split())) for file in files for l in file.read_text().splitlines()]
assert len(set(banks))==27
needed={};tested=set();valid=set();count=Counter()
def coverage(m):
 if m not in needed:needed[m]=sum((bool(m&p and not m&n))<<i for i,(p,n) in enumerate(rows))
 return needed[m]
allrows=(1<<len(rows))-1
for low in banks:
 for t in stars:
  for d in range(13):
   p=1<<d;b=t^p
   if not (t&p and b in low and p in low):continue
   count['sources']+=1
   others=[m for m in low if m not in (p,b)]
   # B precedes Q by the canonical pattern, so its own value stays fixed.
   for flip in range(1<<len(others)):
    bank=tuple(sorted([t,b,*[(m|p if flip>>i&1 else m) for i,m in enumerate(others)]]))
    if bank in tested:continue
    tested.add(bank)
    if len(set(bank))!=11 or sum(m not in raw for m in bank)!=8:continue
    if all(m in raw or any(not m&~s for s in stars) for m in bank):continue
    count['nonlocal candidates']+=1;cov=0
    for m in bank:cov|=coverage(m)
    if cov==allrows:valid.add(bank)
print('nine-gate banks',len(banks),'marked source triples',count['sources'],'different inverse banks',len(tested),'eight-paid nonlocal',count['nonlocal candidates'],'covering',len(valid))
for v in sorted(valid):print(*v)
