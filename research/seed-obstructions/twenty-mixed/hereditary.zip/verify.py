import argparse
import ctypes
import gzip
import random
import subprocess
import sys
import tempfile
from itertools import combinations
from pathlib import Path
from pysat.solvers import Solver
here=Path(__file__).resolve().parent
pareto=here.parent/'point-pareto'
sys.path.insert(0,str(pareto))
from check import encode
from input import point_obligations

stars=[708,1416,2832,5664,3137,6274,4357]
def base(h):
    raw,rows=point_obligations(pareto/'L-meta-18968.json')
    clauses,V,R,_=encode(raw,rows,11,h,selected=h,abstract=True)
    z=max(abs(q) for c in clauses for q in c)
    outs=[]
    for v in V:
        z+=1;outs.append(z)
        for t in stars:clauses.append([-z,*[q for d,q in enumerate(v) if not t>>d&1]])
        for m in [0,*raw]:clauses.append([(-q if m>>d&1 else q) for d,q in enumerate(v)])
    clauses.append(outs)
    return clauses,V,R,raw

def geometric_budget(J,lo,hi):
    chosen=[t for j,t in enumerate(stars) if J>>j&1]
    union=0
    for t in chosen:union|=t
    cost=sum(all((x&t).bit_count()<=1 for t in chosen) for x in hi)
    for t in chosen:
        clean=[x&t for x,y in zip(lo,hi) if not y&(union^t)]
        save=max([0,*[x.bit_count()-1 for x in clean]])
        if any((x|y)==t for x,y in combinations(clean,2)):save=max(save,2)
        supers=[y for x,y in zip(lo,hi) if x&t==t]
        if any(not (x&y&(union^t)) for x,y in combinations(supers,2)):save=max(save,2)
        cost+=save
    return cost

def clause(lo,hi,V):
    return [(-z if x>>d&1 else z) for x,y,v in zip(lo,hi,V) for d,z in enumerate(v) if x>>d&1 or not y>>d&1]

def generate(h,output):
    clauses,V,R,raw=base(h)
    rng=random.Random(18968)
    with tempfile.TemporaryDirectory() as td:
        so=Path(td)/'limit.so'
        subprocess.run(['c++','-O3','-std=c++20','-shared','-fPIC',str(here/'limit.cpp'),'-o',str(so)],check=True)
        lib=ctypes.CDLL(str(so));lib.setup_bound()
        T=ctypes.c_int*h
        with Solver(name='cadical195',bootstrap_with=clauses) as s,gzip.open(output,'wt') as f:
            rounds=cuts=0
            while s.solve():
                m=set(s.get_model());bits=[sum((q in m)<<d for d,q in enumerate(v)) for v in V]
                lo=T(*bits);hi=T(*bits)
                if lib.limit(lo,hi,h)<=10:
                    raise RuntimeError(('surviving model',bits,[x for x,q in zip(raw,R) if q in m]))
                ordered=[(i,d) for i in range(h) for d in range(13)]
                best=[]
                for _ in range(6):
                    rng.shuffle(ordered)
                    for i,b in enumerate(bits):lo[i]=hi[i]=b
                    k=0
                    for i,d in ordered:
                        bit=1<<d
                        if bits[i]&bit:lo[i]^=bit
                        else:hi[i]^=bit
                        if lib.limit(lo,hi,h)<=10:
                            if bits[i]&bit:lo[i]^=bit
                            else:hi[i]^=bit
                            k+=1
                    best.append((k,tuple(lo),tuple(hi)))
                for _,l,u in sorted(best,key=lambda x:x[0])[:3]:
                    witness=next(J for J in range(1,128) if geometric_budget(J,l,u)>10)
                    print(witness,*l,*u,file=f);s.add_clause(clause(l,u,V));cuts+=1
                rounds+=1
                if rounds%100==0:print(rounds,cuts,flush=True)
            print('UNSAT',rounds,'models',cuts,'independently checked clauses',s.accum_stats(),flush=True)

def verify(h,source,cnf,checker):
    clauses,V,R,raw=base(h);n=0
    with gzip.open(source,'rt') as f:
        for row in f:
            J,*v=map(int,row.split());lo=v[:h];hi=v[h:]
            assert 1<=J<128 and len(v)==2*h and all((x&~y)==0 and 0<=x<=y<=8191 for x,y in zip(lo,hi))
            assert geometric_budget(J,lo,hi)>10
            clauses.append(clause(lo,hi,V));n+=1
    high=max(abs(q) for c in clauses for q in c)
    if cnf:
        with open(cnf,'w') as f:
            print('p cnf',high,len(clauses),file=f)
            for c in clauses:print(*c,0,file=f)
    with Solver(name='cadical195',bootstrap_with=clauses,with_proof=bool(checker)) as s:
        assert s.solve() is False
        print('UNSAT on',n,'validated geometric cuts and',len(clauses),'total clauses',flush=True)
        if checker:
            assert cnf
            from drat import verify_binary
            verify_binary(s,cnf,checker)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('mode',choices=['generate','verify']);a.add_argument('h',type=int);a.add_argument('cuts',type=Path);a.add_argument('--cnf');a.add_argument('--checker');args=a.parse_args()
    if args.mode=='generate':generate(args.h,args.cuts)
    else:verify(args.h,args.cuts,args.cnf,args.checker)
