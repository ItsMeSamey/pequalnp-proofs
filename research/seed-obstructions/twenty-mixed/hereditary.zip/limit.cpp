#include "hereditary.hpp"
using namespace hereditary;
extern "C" void setup_bound(){setup();}
extern "C" int limit(const int* x,const int* y,int h){
 Mask lo,hi;lo.fill(1);hi.fill(1);
 for(int i=0;i<h;i++){lo[i]=x[i];hi[i]=y[i];}
 return bound<true>(lo,hi);
}
