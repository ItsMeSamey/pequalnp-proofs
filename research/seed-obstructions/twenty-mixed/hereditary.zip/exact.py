"""Synthesize a non-star-local ten-gate program with a fixed number of selected computed masks."""
import argparse
import sys
import subprocess
from itertools import combinations
from pathlib import Path
from pysat.solvers import Solver
here=Path(__file__).resolve().parent
pareto=here.parent/'point-pareto'
sys.path.insert(0,str(pareto))
from input import point_obligations,raw_samples
from check import encode

def instance(raw,rows,h,abstract=False):
    clauses, boundary, selected, _ = encode(raw,rows,11,h,selected=h,abstract=True)
    high=max(abs(q) for c in clauses for q in c)
    def fresh():
        nonlocal high
        high+=1
        return high
    stars=[sum(1<<((6+j+d)%13) for d in (0,1,3,9)) for j in range(7)]
    outside=[]
    for mask in boundary:
        flag=fresh();outside.append(flag)
        for star in stars:clauses.append([-flag,*[q for d,q in enumerate(mask) if not (star>>d&1)]])
        for m in [0,*raw]:clauses.append([(-q if m>>d&1 else q) for d,q in enumerate(mask)])
    clauses.append(outside)
    if abstract:return clauses,boundary,selected
    masks=boundary+[[fresh() for _ in range(13)] for _ in range(10-h)]
    for prev,nxt in zip(masks[h:],masks[h+1:]):
        eq=[]
        for a,b in zip(reversed(prev),reversed(nxt)):
            clauses.append([-q for q in eq]+[-a,b])
            e=fresh();eq.append(e)
            clauses.extend(([-e,-a,b],[-e,a,-b],[e,a,b],[e,-a,-b]))
        clauses.append([-q for q in eq])
    for b in masks[h:]:
        for m in [0,*raw]:clauses.append([(-q if m>>d&1 else q) for d,q in enumerate(b)])
        for a in boundary:
            diff=[]
            for x,y in zip(a,b):
                d=fresh();diff.append(d)
                clauses.extend(([-d,x,y],[-d,-x,-y]))
            clauses.append(diff)
    order={(i,j):fresh() for i,j in combinations(range(10),2)}
    def before(i,j):return order[i,j] if i<j else -order[j,i]
    for i in range(10):
        for j in range(10):
            for k in range(i+1,10):
                if i!=j!=k:clauses.append([-before(i,j),-before(j,k),before(i,k)])
    shallow=sorted({v for a,b in combinations(raw,2) for v in (a&b,a|b)}-set(raw)-{0})
    uses=[[] for _ in range(10-h)]
    for i,output in enumerate(masks):
        options=[]
        def option(*parents):
            q=fresh()
            options.append(q)
            for j in parents:
                clauses.append([-q,before(j,i)])
                if j>=h:uses[j-h].append(q)
            return q
        def permitted(union,j):
            return (j<h)!=(i<h) or (j<i)==union
        for v in shallow:
            q=option()
            for bit,z in enumerate(output):clauses.append([-q,z if v>>bit&1 else -z])
        for j,parent in enumerate(masks):
            if j==i:continue
            for union in (False,True):
                if not permitted(union,j):continue
                for v in raw:
                    q=option(j)
                    for bit,(y,z) in enumerate(zip(parent,output)):
                        if (v>>bit&1)==union:clauses.append([-q,z if union else -z])
                        else:clauses.extend(([-q,-z,y],[-q,z,-y]))
        for j,k in combinations(range(10),2):
            if i in (j,k):continue
            for union in (False,True):
                if not (permitted(union,j) and permitted(union,k)):continue
                q=option(j,k)
                sign=1 if union else -1
                for x,y,z in zip(masks[j],masks[k],output):
                    x*=sign;y*=sign;z*=sign
                    clauses.extend(([-q,-x,z],[-q,-y,z],[-q,x,y,-z]))
        clauses.append(options)
    clauses.extend(uses)
    return clauses,boundary,selected



def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('selected',type=int,choices=range(7,11))
    parser.add_argument('--cnf',type=Path)
    parser.add_argument('--checker',type=Path)
    args=parser.parse_args()
    if args.checker and not args.cnf:parser.error('--checker requires --cnf')
    raw,rows=point_obligations(pareto/'L-meta-18968.json')
    clauses,V,R=instance(raw,rows,args.selected)
    with Solver(name='cadical195',bootstrap_with=clauses,with_proof=bool(args.checker)) as solver:
        if args.cnf:
            with args.cnf.open('w') as f:
                print('p cnf',solver.nof_vars(),len(clauses),file=f)
                for c in clauses:print(*c,0,file=f)
        if solver.solve():
            m=set(solver.get_model())
            bank=[x for q,x in zip(R,raw) if q in m]+[sum((q in m)<<d for d,q in enumerate(v)) for v in V]
            raise SystemExit(f'surviving bank {sorted(bank)}')
        print('UNSAT',args.selected,'selected',solver.accum_stats(),flush=True)
        if args.checker:
            from drat import verify_binary
            verify_binary(solver,args.cnf,args.checker)
if __name__=='__main__':main()
