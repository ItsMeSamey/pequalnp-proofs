from operand_audit import *
from itertools import combinations
from collections import Counter
from pathlib import Path
s=3
total=size+(ordered[:,:10].sum(axis=1))
which=np.flatnonzero(total==19);cases=Counter()
out=Path(__file__).with_name('eleven-source-sets.txt')
with out.open('w') as f:
 for idx in which:
  F=[m for j,m in enumerate(nonsingle) if int(idx)>>j&1]
  for S in combinations(range(13),3):
   v=[0 if i in S else int(n) for i,n in enumerate(per[int(idx)])]
   if sum(v)+len(F)!=19:continue
   mask=sum(1<<i for i in S);src=[1<<i for i,n in enumerate(v) for _ in range(n)]+F
   print(mask,*src,file=f);cases[len(F)]+=1
print('labelled source sets',sum(cases.values()),'histogram by frozen operand count',dict(sorted(cases.items())))
