from exact import pareto,point_obligations
from itertools import combinations
from collections import Counter
from pathlib import Path
raw,rows=point_obligations(pareto/'L-meta-18968.json')
stars=[708,1416,2832,5664,3137,6274,4357]
files=[pareto/'cost-nine-six.txt',pareto.parent/'twenty-ten-lines/three-seven-output-banks.txt']
banks=[tuple(map(int,l.split())) for file in files for l in file.read_text().splitlines()]
assert len(set(banks))==27
needed={};tested=set();valid=set();count=Counter()
def coverage(m):
 if m not in needed:needed[m]=sum((bool(m&p and not m&n))<<i for i,(p,n) in enumerate(rows))
 return needed[m]
allrows=(1<<len(rows))-1
for low in banks:
 for p in low:
  if p.bit_count()!=1:continue
  for b in low:
   if b==p or b&p:continue
   t=b|p
   if t in raw:continue
   count['sources']+=1
   others=[m for m in low if m not in (p,b)]
   for flip in range(1<<len(others)):
    bank=tuple(sorted([t,b,*[(m|p if flip>>i&1 else m) for i,m in enumerate(others)]]))
    count['expansions']+=1
    if len(set(bank))!=11 or sum(m not in raw for m in bank)!=8:continue
    if all(m in raw or any(not m&~s for s in stars) for m in bank):continue
    count['nonlocal candidates']+=1;cov=0
    for m in bank:cov|=coverage(m)
    if cov==allrows:valid.add(bank)
print('nine-gate banks',len(banks),'marked sources',count['sources'],'expansions',count['expansions'],'eight-paid nonlocal visits',count['nonlocal candidates'],'distinct covering',len(valid))
for v in sorted(valid):print(*v)
from verify import geometric_budget
for bank in valid:
 paid=[x for x in bank if x not in raw]
 assert any(geometric_budget(J,paid,paid)>10 for J in range(1,128))
print('passing point cost ten',0)
