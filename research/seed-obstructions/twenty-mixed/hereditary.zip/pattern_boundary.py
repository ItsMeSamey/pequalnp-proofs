from exact import encode,pareto,point_obligations,Solver
import sys,os,subprocess,tempfile
from pathlib import Path
raw,rows=point_obligations(pareto/"L-meta-18968.json")
from pysat.formula import IDPool
from pysat.card import CardEnc
h=int(sys.argv[1]);budget=int(sys.argv[2]) if len(sys.argv)>2 else 0
stars=[708,1416,2832,5664,3137,6274,4357]
P=[]
for t in stars:
 pairs=[m for m in range(8192) if m.bit_count()==2 and not m&~t]
 triples=[m for m in range(8192) if m.bit_count()==3 and not m&~t]
 P += [(t,x,t^x) for x in pairs if x<t^x]+[(t,x,y) for x in pairs for y in triples if not x&~y]
loc=sorted(set(x for pat in P for x in pat));starts=raw+loc
cla,V,R,_=encode(starts,rows,11,h,selected=h,abstract=True)
pool=IDPool(start_from=max(abs(q) for c in cla for q in c)+1)
pat=[pool.id() for _ in P]
cla+=CardEnc.equals(pat,1,vpool=pool).clauses
for q,(t,a,b) in zip(pat,P):cla.append([-q,R[starts.index(t)]])
for m,q in zip(loc,R[len(raw):]):cla.append([-q,*[p for v,p in zip(P,pat) if m in v]])
cla+=CardEnc.atmost(R[:len(raw)],3,vpool=pool).clauses
cla+=CardEnc.equals(R[len(raw):],8-h,vpool=pool).clauses
outside=[]
for v in V:
 q=pool.id();outside.append(q)
 for t in stars:cla.append([-q,*[z for d,z in enumerate(v) if not t>>d&1]])
 for m in [0,*raw]:cla.append([(-z if m>>d&1 else z) for d,z in enumerate(v)])
 for m,q in zip(loc,R[len(raw):]):cla.append([-q,*[(-z if m>>d&1 else z) for d,z in enumerate(v)]])
cla.append(outside)
checker=os.environ.get('POINT_DRAT_CHECKER')
s=Solver(name='cadical195',bootstrap_with=cla,with_proof=bool(checker))
if budget:s.conf_budget(budget);res=s.solve_limited()
else:res=s.solve()
print('remaining-paid',h,res,s.accum_stats(),flush=True)
if res:
 m=set(s.get_model());print('pattern',[x for x,q in zip(P,pat) if q in m],'bank',sorted([x for x,q in zip(starts,R) if q in m]+[sum((q in m)<<d for d,q in enumerate(v)) for v in V]),flush=True)

if checker and res is False:
 with tempfile.TemporaryDirectory() as tmp:
  cnf=Path(tmp)/'point.cnf'
  with cnf.open('w') as f:
   print('p cnf',s.nof_vars(),len(cla),file=f)
   for c in cla:print(*c,0,file=f)
  from drat import verify_binary
  verify_binary(s,cnf,checker)
if h in (5,6) and res is not False:raise SystemExit('Pattern boundary case was not refuted')
