from exact import encode,pareto,point_obligations,combinations,Solver
raw,rows=point_obligations(pareto/"L-meta-18968.json")
from pysat.card import CardEnc
from pysat.formula import IDPool
import argparse
import os,tempfile
from pathlib import Path
stars=[708,1416,2832,5664,3137,6274,4357]
def make(o,original=0):
    t=stars[o];pairs=[m for m in range(8192) if not m&~t and m.bit_count()==2]
    triples=[m for m in range(8192) if not m&~t and m.bit_count()==3]
    pats=[(t,p,t^p) for p in pairs if p<t^p]+[(t,p,u) for u in triples for p in pairs if not p&~u]
    assert len(pats)==15
    local=[t,*pairs,*triples];starts=raw+local
    c,V,R,A=encode(starts,rows,11,7,abstract=True)
    pool=IDPool(start_from=max(abs(q) for a in c for q in a)+1);new=pool.id
    B=[new() for _ in pats];c+=CardEnc.equals(B,1,vpool=pool).clauses
    active={}
    for m,b in zip(local,R[len(raw):]):
        q=new();active[m]=q
        p=[u for u,pat in zip(B,pats) if m in pat]
        c.extend([[-w,q] for w in p]);c.extend([[-q,*p],[-b,q]])
    c.append([R[len(raw)]])
    paid=R[len(raw):]+A
    if original:c+=CardEnc.equals(paid,original,vpool=pool).clauses
    else:
        c+=CardEnc.atleast(paid,7,vpool=pool).clauses
        c+=CardEnc.atmost(paid,9,vpool=pool).clauses
    avail_values={}
    for idx,pat in enumerate(pats):
        base=raw+list(pat)
        for x,y in combinations(base,2):
            for z in (x|y,x&y):
                if z and z not in raw and z not in pat:avail_values.setdefault(z,set()).add(idx)
    outside=[]
    order={(i,j):new() for i,j in combinations(range(7),2)}
    def before(i,j):return order[i,j] if i<j else -order[j,i]
    for i in range(7):
        for j in range(7):
            for k in range(i+1,7):
                if i!=j!=k:c.append([-before(i,j),-before(j,k),before(i,k)])
    usage=[[] for _ in range(7)]
    for i,v in enumerate(V):
        u=new();outside.append(u);c.append([-u,A[i]])
        for st in stars:c.append([-u,*[z for d,z in enumerate(v) if not st>>d&1]])
        for m in [0,*raw,*local]:
            forbid=[-z if m>>d&1 else z for d,z in enumerate(v)]
            c.append(([-active[m]] if m in active else [])+forbid)
        opts=[]
        for m,ids in avail_values.items():
            q=new();opts.append(q)
            if len(ids)!=len(pats):c.append([-q,*[B[j] for j in ids]])
            for d,z in enumerate(v):c.append([-q,z if m>>d&1 else -z])
        for j,parent in enumerate(V):
            if j==i:continue
            union=j<i
            for m in starts:
                q=new();opts.append(q);usage[j].append(q);c.append([-q,before(j,i)])
                if m in active:c.append([-q,active[m]])
                for d,(y,z) in enumerate(zip(parent,v)):
                    if (m>>d&1)==union:c.append([-q,z if union else -z])
                    else:c.extend([[-q,-z,y],[-q,z,-y]])
        for j,k in combinations(range(7),2):
            if i in (j,k) or (j<i)!=(k<i):continue
            q=new();opts.append(q);usage[j].append(q);usage[k].append(q)
            c.extend([[-q,before(j,i)],[-q,before(k,i)]])
            sign=1 if j<i else -1
            for y,z,x in zip(V[j],V[k],v):
                x*=sign;y*=sign;z*=sign
                c.extend([[-q,-y,x],[-q,-z,x],[-q,y,z,-x]])
        c.append(opts)
    c.append(outside)
    for a,us in zip(A,usage):c.append([a,*us])
    return c,V,R,A,B,starts,pats
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('o',type=int);ap.add_argument('--budget',type=int,default=0);ap.add_argument('--split',action='store_true');ap.add_argument('--selected-extra',type=int,default=0);ap.add_argument('--original',type=int,default=0)
    args=ap.parse_args();c,V,R,A,B,starts,pats=make(args.o,args.original);checker=os.environ.get("POINT_DRAT_CHECKER");s=Solver(name='cadical195',bootstrap_with=c,with_proof=bool(checker))
    if args.selected_extra:
        extra=CardEnc.equals(A,args.selected_extra,top_id=s.nof_vars()).clauses
        for clause in extra:s.add_clause(clause)
        c.extend(extra)
    print('ordinary',args.o,'clauses',s.nof_clauses(),'variables',s.nof_vars(),flush=True)
    for idx,ass in enumerate([[q] for q in B] if args.split else [[]]):
        if args.budget:s.conf_budget(args.budget);z=s.solve_limited(assumptions=ass)
        else:z=s.solve(assumptions=ass)
        print('result',idx,z,s.accum_stats(),flush=True)
        if z:
            m=set(s.get_model());print('pattern',[p for p,b in zip(pats,B) if b in m], 'bank', sorted([x for x,r in zip(starts,R) if r in m]+[sum((q in m)<<d for d,q in enumerate(v)) for v,a in zip(V,A) if a in m]),'computed',[sum((q in m)<<d for d,q in enumerate(v)) for v in V],flush=True);break

    if checker and not args.split and z is False:
        from drat import verify_binary
        with tempfile.TemporaryDirectory() as tmp:
            cnf=Path(tmp)/'q-pattern.cnf'
            with cnf.open('w') as f:
                print('p cnf',s.nof_vars(),len(c),file=f)
                for clause in c:print(*clause,0,file=f)
            verify_binary(s,cnf,checker)
    if not args.budget and not args.split and z is not False:raise SystemExit(1)
