from itertools import combinations,combinations_with_replacement
from check_three import checked,edges,neighbors,negatives,POINT,LINE

for j in range(13,20):
    exterior = [p for p in range(13) if (p,j) not in edges]
    for x,y in combinations_with_replacement(exterior,2):
        mask=(1<<j)|(1<<x)|(1<<y)
        assert any(n & mask == mask for n in negatives)
assert max(len(neighbors[p]) for p in range(13)) == 3

def sparse_match(j,used):
    if j==20:return []
    for p in sorted(neighbors[j]-used):
        if len(neighbors[p])>2:continue
        other=sparse_match(j+1,used|{p})
        if other is not None:return [(p,j),*other]
    return None
matching=sparse_match(13,set())
assert matching is not None and len(matching)==7 and len({p for p,j in matching})==7
for clauses in checked:
    assert min(c.bit_count() for c in clauses)>=2
    for a,b in combinations(clauses,2):
        # A binary AND of these two OR clauses, on the line-singleton inputs.
        assert (a & b & LINE).bit_count() <= 1
print('Every line and pair of exterior points has a dominating raw negative.')
print('Point degrees are at most three. Matching to points of degree at most two:',matching)
print('All genuine triple intermediates have at most one line singleton and no raw singleton operand.')
