from pathlib import Path
from itertools import combinations,product
from functools import lru_cache
from collections import defaultdict,Counter

from check import rows,front,target,edges,neighbors,expanded
core = (1<<20)-1
positives = sorted({x&core for i,x in enumerate(rows) if (front^target)>>i&1})
all_negative = {x&core for i,x in enumerate(rows) if not target>>i&1}
negatives = sorted(x for x in all_negative if not any(x!=y and x&~y==0 for y in all_negative))
assert (len(positives),len(negatives))==(28,245)
N = (1<<len(negatives))-1
POINT=(1<<13)-1
LINE=core^POINT

@lru_cache(None)
def reject(c):
    return sum(1<<i for i,n in enumerate(negatives) if not c&n)

def minimal_clauses(group):
    active = 0
    for p in group:
        active |= p & LINE
    out=set()
    line_set=active
    while True:
        points=0
        for p in group:
            if not p & line_set:
                points |= p & POINT
        lines=0
        for p in group:
            if not p & points:
                lines |= p & LINE
        out.add(points | lines)
        if not line_set:break
        line_set=(line_set-1)&active
    return [c for c in sorted(out) if not any(d!=c and d&~c==0 for d in out)]

def covers(group):
    cs=minimal_clauses(group)
    # Rejection by at most three clauses is hereditary in the required positives.
    if any(reject(c)==N for c in cs):return 1,[]
    if any((reject(a)|reject(b))==N for a,b in combinations(cs,2)):return 2,[]
    triples=[(a,b,c) for a,b,c in combinations(cs,3) if reject(a)|reject(b)|reject(c)==N]
    return (3,triples) if triples else (4,[])

roots=set()
counts=Counter()
def enumerate_groups(group,first):
    for i in range(first,len(positives)):
        nxt=group+(positives[i],)
        k,triples=covers(nxt)
        if k>3:continue
        counts[k]+=1;roots.update(triples)
        enumerate_groups(nxt,i+1)
enumerate_groups((),0)
assert counts=={2:132,3:840} and len(roots)==420

roles=defaultdict(set)
checked=set()
for clauses in roots:
    allowed=[]
    for i,c in enumerate(clauses):
        others=reject(clauses[(i+1)%3])|reject(clauses[(i+2)%3])
        private=reject(c)&~others
        assert private
        extra=core^c
        while private:
            bit=private&-private;private^=bit
            extra&=~negatives[bit.bit_length()-1]
        opts=[];s=extra
        while True:
            opts.append(c|s)
            if not s:break
            s=(s-1)&extra
        allowed.append(opts)
    for candidate in product(*allowed):
        a,b,c=candidate
        if reject(a)|reject(b)|reject(c)!=N:continue
        key=tuple(sorted(candidate))
        if key in checked:continue
        checked.add(key)
        point_arm, = [t for t in candidate if not t&LINE]
        line_arm, = [t for t in candidate if not t&POINT]
        guard, = [t for t in candidate if t&POINT and t&LINE]
        assert point_arm.bit_count()>=2 and line_arm.bit_count()>=2
        point_center, = [p for p in range(13) if all((p,j) in edges for j in range(13,20) if line_arm>>j&1)]
        line_center, = [j for j in range(13,20) if all((p,j) in edges for p in range(13) if point_arm>>p&1)]
        assert point_arm>>point_center&1 and line_arm>>line_center&1
        assert guard>>point_center&1 and guard>>line_center&1
        expected = {x for x in positives if
                    (x&(1<<point_center) and x&line_arm) or (x&(1<<line_center) and x&point_arm)}
        assert {x for x in positives if all(x&t for t in candidate)}==expected
        roles[guard].add((point_center,line_center))
for centers in roles.values():
    assert len({p for p,j in centers})==len(centers)==len({j for p,j in centers})
assert len(checked)==4548 and Counter(map(len,roles.values()))=={1:1056,2:492,3:48}
print('Verified 420 canonical triples and 4,548 safe possibly enlarged triples.')
print('Every guard has at most three possible centers and its center edges have disjoint endpoints.')
