from itertools import combinations
from pathlib import Path
from verify_packing import samples

rows,front,target = samples(Path(__file__).with_name('L-meta-18968.json'))
point = (1 << 13)-1
line = 127
core = (1 << 20)-1
positive = {r & core for i,r in enumerate(rows) if (target ^ front) >> i & 1}
negative = {r & core for i,r in enumerate(rows) if not target >> i & 1}
assert all(not (r >> 38) for i,r in enumerate(rows) if (target ^ front) >> i & 1)

expanded = [1<<j for j in range(20)]
expanded.extend((1<<j)|(1<<(j+1)) for j in range(6))
expanded.extend((1<<(j+3))|(1<<((j+9)%13)) for j in range(6))
expanded.extend(expanded[20+j]|expanded[26+j] for j in range(6))
assert len(expanded) == 38
for r in rows:
    assert all(bool(r >> j & 1) == bool(r & core & s) for j,s in enumerate(expanded))

edges = set()
for p in positive:
    x, y = p & point, p >> 13
    assert x.bit_count() == y.bit_count() == 1
    edges.add((x.bit_length()-1,13+y.bit_length()-1))
safe = {(a,b) for a in range(20) for b in range(a,20)
        if not any(n >> a & 1 and n >> b & 1 for n in negative)}
assert len(edges)==28 and safe==edges

neighbors = [set() for _ in range(20)]
for a,b in edges:
    neighbors[a].add(b)
    neighbors[b].add(a)
for a,b in combinations(range(20),2):
    assert len(neighbors[a] & neighbors[b])<=1
for N in neighbors:
    star = sum(1<<i for i in N)
    assert all(s.bit_count()==1 or s & ~star for s in expanded)

def matching(j,used):
    if j==20:return []
    for x in sorted(neighbors[j]-used):
        suffix=matching(j+1,used|{x})
        if suffix is not None:return [(x,j)]+suffix
    return None
witness=matching(13,set())
assert len(witness)==7 and len({x for x,_ in witness})==7
print('Checked 676 rows, 28 safe coordinate pairs, no four-cycle, and no free nonsingleton inside a star.')
print('Seven disjoint edges:',witness)
