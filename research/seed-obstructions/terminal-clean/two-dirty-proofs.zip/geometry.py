from itertools import combinations_with_replacement,combinations
from pathlib import Path
from input import raw_samples,point_obligations

path=Path(__file__).with_name('L-meta-18968.json')
pos,neg,_=raw_samples(path)
points,_=point_obligations(path);raw=set(points);lines=[1<<(13+j) for j in range(7)]
stars=[sum({r&8191 for r in pos if r&l}) for l in lines]
assert all((a&b) in raw|{0} and (not a&b or a&b in (a,b) or (a&b).bit_count()==1) for a,b in combinations_with_replacement(raw,2))
assert all((a&t).bit_count()<=1 for a in raw for t in stars)
assert all((t&u).bit_count()<=1 for t,u in combinations(stars,2))
assert max(sum(bool(t&(1<<j)) for t in stars) for j in range(13))<=4
assert all((x.bit_count()==4) for x in stars)
for group in [raw,lines]:
 for a,b in combinations_with_replacement(group,2):
  assert any((a&n) and (b&n) for n in neg)
for p in range(13):
 for l,t in zip(lines,stars):
  if not t>>p&1:assert any(n&(1<<p) and n&l for n in neg)
for J in combinations(stars,4):
 d=[sum(t>>p&1 for t in J) for p in range(13)]
 assert sum(sorted([x for x in d if x>=2],reverse=True)[:4])<=9
for J in combinations(raw,3):
 isolated={a for a in J if a.bit_count()==1}
 for a,b in combinations(J,2):
  if (a&b).bit_count()==1:isolated.add(a&b)
 x=J[0]&J[1]&J[2]
 if x.bit_count()==1:isolated.add(x)
 assert len(isolated)<=3
 if len(isolated)==3:assert sum(x.bit_count()==1 for x in J) in (0,3)
print('Verified raw coactivation, all off-incidences, restricted line degrees, isolated triples and four-line counts.')
