# A serial dirty AND followed by one mixed gate

Let the first mixed gate be H = A B, with A point-pure and B line-pure. The next mixed gate K combines H with a pure C. Each affected terminal ANDs H or K with one pure guard. Other terminals may use pure factors. All terminals are clean, and their outputs are ORed. The pure prefix is arbitrary and shared. We remove H and K without increasing total gate count, so the existing pure rectangle lower bound of 34 applies.

We also use letters for singleton supports. Every clean rectangle consists only of incident cells, since a nonincident pair extends to a sampled negative. Two or more lines have at most one common point and conversely. A raw pivot is bounded on all inputs by any monotone signal accepting its singleton. The replacements preserve the union of covered positive incidences and lower negative values. Delete empty positive terms. A group of t old terminal gates has t−1 grouping ORs after regrouping the top. All old pure gates can be retained, preserving sharing. By symmetry take C point-pure.

## K = H C

Write U for the support of A C. If A or B has singleton support of size one, every affected incidence lies on its raw pivot. Form the restricted OR of all affected terminals by fixing that side to the pivot singleton, then AND this restricted expression with the raw pivot. The values decrease by monotonicity, and the positive incidences coincide. The restricted expression uses only the other side; the restricted H becomes its other parent, paying for the final AND. If A or B has empty support, drop the whole group.

Suppose both A and B have at least two singleton coordinates. Every productive point guard on either mixed gate produces a rectangle with the same line factor B. Its point side is the unique common point p of B. Merge them into raw p times B. All productive line guards on H similarly reduce to A times one raw line.

For line guards on K with |U|≥2, the rectangles share point factor A C. Merge them into (A C) times the unique common raw line. Only one extra pure gate is needed. For U empty there are no such incidences. For U={q}, aggregate the s productive line guards into their union L and form raw q times (B L). This costs s+1 versus 2s−1 before charging H or K, a surcharge of at most one. The other groups can only save gates, and deleting H,K pays for the surcharge.

## K = H OR C

At a point-guarded consumer K P, the point-only product C P cannot accept a singleton: that point alone is dominated by a negative. Replace K by H at all such terminals. If this accounts for every K consumer, the one-dirty-gate theorem finishes. Otherwise let L be the union of the s≥1 productive line guards on K. If C has empty support drop its branch. If A or B has empty support drop H, using just C on the K branch.

For |C|≥2, every productive line guard has the same singleton line k since C times that guard is clean. If k belongs to B the group becomes raw k times (C OR A), otherwise raw k times C. At most two gates are needed, paid by K, its s terminal ANDs and their s−1 grouping ORs. The direct consumers of H can be converted by the one-dirty theorem using H and their own gates.

Now suppose C={q}. Replace C by raw q. If |A|,|B|≥2, direct point guards on H merge into a raw point times B and direct line guards merge into A times a raw line. Their terminal gates suffice, freeing H. At the K group B intersect L is either empty or the unique line k incident to all points of A. Use q L, optionally ORed with A times raw k. The maximum new cost is (s−1)+3=s+2. The old group budget including K is 2s; the freed H pays the only possible deficit, when s=1.

If B={j} and j is outside L, the K group becomes q L and the direct consumers of H are handled separately. If j belongs to L, this group covers all of A times {j}. Drop H's direct consumers and use (A times raw j) OR (q L). Its cost s+2 fits the old 2s+1 gates for H,K and the group itself.

Finally suppose A={p} and B has at least two coordinates. If p=q, K has the same positive evaluations as its lower signal raw p, so remove K before the one-dirty conversion. If p differs from q and H has a productive direct point guard, that guard covers all of {p} times B. Use raw p times B for H's direct terms and for the H-derived part of K; the other term is q L. This costs s+2, paid by H,K and their terminal gates and ORs.

Otherwise the r productive direct H guards are all line signals D_j. Use the OR of q L and raw p times [B AND (L OR all D_j)]. This is bounded by the old group because A dominates raw p and the old C dominates raw q. Construct L once. New cost r+s+3 is within the original 2r+2s+1 whenever r+s≥2. In the remaining case r=0 and s=1, any line in B intersect L must be incident both to p and to q. Thus there is at most one, k. Use q L OR raw p times raw k if k exists, and q L alone otherwise. At most three gates replace H,K and their terminal.
