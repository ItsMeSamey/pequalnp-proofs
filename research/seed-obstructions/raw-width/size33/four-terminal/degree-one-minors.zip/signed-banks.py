from itertools import combinations
from minors import DEGREE_ONE
units={1<<j for j in range(13)}
a=[3<<j for j in range(6)]
b=[(1<<(j+3))|(1<<((j+9)%13)) for j in range(6)]
cs=a+b+[x|y for x,y in zip(a,b)]
library=units|set(cs)|{0}
assert len(cs)==len(set(cs))==18
for k in range(5):
 for e in combinations(DEGREE_ONE,k):
  cut=sum(e)
  allowed=[c for c in cs if not any(d!=c and not d&~c and not ((c^d)&~cut)for d in library)]
  print(e,len(allowed),sorted(allowed))
  if k==4:assert sorted(allowed)==[129,354,523,1046,2092,4160]
