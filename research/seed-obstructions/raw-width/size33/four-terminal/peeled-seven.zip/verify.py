from screen import *
from collections import Counter
counts=Counter()
for width in range(4):
 for c in combinations(sorted(extra),width):
  H,U,V,K=test(c)
  bank,pos,ns,F,_,_,hit,_=make(c)
  high=sum(1<<extra[m] for m in H)
  for p in K:
   for u in range(7):
    if V>>u&1:assert any(n&high==high and l>>u&1 for n,l in F[p])
  print(c,H,U,V,K)
  counts[width]+=1
assert list(counts.values())==[1,6,15,20]
print("VERIFIED",sum(counts.values()))
