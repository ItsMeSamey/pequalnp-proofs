from itertools import combinations
from functools import cache
from pathlib import Path
import sys
from marks import make,points,stars,extra
inc={p:sum(1<<u for u,T in enumerate(stars)if p in T)for p in points}
def test(c):
 bank,pos,ns,F,_,_,hit,_=make(c)
 nbits=(1<<7)-1
 def labs(x):return [u for u in range(7)if x>>u&1]
 for hcnt in range(len(c),-1,-1):
  for H in combinations(c,hcnt):
   high=sum(1<<extra[x]for x in H)
   low=sum(1<<extra[x]for x in c if x not in H)
   ns1=[(n,l)for n,l in ns if (n&high)==high]
   phit={n:sum(1<<v for v,T in enumerate(stars)if any(not pos[q]&low and not (pos[q]&~high)&~n for q in T)) for n,l in ns1}
   for us in [list(range(7)),*combinations(range(7),6),*combinations(range(7),5)]:
    U=sum(1<<u for u in us)
    P=[p for p in points if not pos[p]&low and inc[p]&U not in (0,U) and
       all(any(n&p and l>>u&1 for n,l in ns1)for u in us if not inc[p]>>u&1) and
       all(any(n&p and phit[n]>>u&1 for n,l in ns1)for u in range(7))]
    for vs in [us,*combinations(us,len(us)-1),*combinations(us,len(us)-2)]:
     V=sum(1<<u for u in vs)
     if any(not any(l>>u&1 and phit[n]>>v&1 for n,l in ns1)for u in vs for v in range(7) if u!=v):continue
     K=[p for p in P if inc[p]&V and all(any(l&inc[p]&U and l>>u&1 for n,l in ns1)for u in vs)]
     bad=lambda p,q: inc[p]&U==inc[q]&U or not any(l&inc[p]&U and l&inc[q]&U for n,l in ns1) or not any(n&q for n,l in F[p]if n&high==high) and not any(n&p for n,l in F[q]if n&high==high)
     def reject(k):
      for p,q in combinations(k,2):
       if bad(p,q):return reject([a for a in k if a!=p])or reject([a for a in k if a!=q])
      budget=3-len(c)
      for d in range(budget+1):
       for omit in combinations(k,d):
        groups=[inc[p]&V for p in k if p not in omit]
        if sum(max(0,sum(bool(g>>u&1)for g in groups)-2)for u in vs)<=budget-d:return None
      return tuple(k)
     w=reject(K)
     if w:return H,U,V,w
 return None
if __name__=='__main__':
 import argparse
 z=argparse.ArgumentParser();z.add_argument('n',type=int);z.add_argument('--limit',type=int,default=100);a=z.parse_args()
 for c in list(combinations(sorted(extra),a.n))[:a.limit]:print(c,test(c),flush=True)
