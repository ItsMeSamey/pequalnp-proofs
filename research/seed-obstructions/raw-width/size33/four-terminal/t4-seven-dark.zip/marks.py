import json
from pathlib import Path
from itertools import combinations
from functools import cache
from collections import Counter
data=json.loads(Path(__file__).with_name('t4.json').read_text())
wid=data['original_wire_ids']
def orig(x):return sum(1<<j for i,j in enumerate(wid)if x>>i&1)
P=tuple(map(orig,data['positives']));N=tuple(map(orig,data['maximal_negatives']))
points=tuple(1<<j for j in range(13)if j in wid)
extra={129:30,354:37,523:32,1046:33,2092:34,4160:29}
line=127<<13
stars=tuple({s&8191 for s in P if s>>(13+u)&1}for u in range(7))
assert len(P)==24 and len(N)==239 and all(len(a&b)==1 for a,b in combinations(stars,2))
def make(c):
 bank=sum(points)+sum(1<<extra[m] for m in c)
 pos={p:next(x&bank for x in P if x&p)for p in points}
 assert all(x&bank==pos[x&8191]for x in P)
 ns=tuple((n&bank,(n>>13)&127)for n in N)
 # Retained raw p is individually compulsory and original masked point supplier is dark on every such negative.
 F={p:tuple((n,l)for n,l in ns if not n&p and not (pos[p]&~p)&~n and any(p in stars[u]and l>>u&1 for u in range(7)))for p in points}
 assert all(F.values())
 assert all(any(not pos[p]&~n for n,l in F[q])or any(not pos[q]&~n for n,l in F[p])for p,q in combinations(points,2))
 hits=lambda n,T:any(not pos[p]&~n for p in T)
 QQ=[[n for n,l in ns if l>>u&1]for u in range(7)]
 hit={n:sum(1<<u for u,T in enumerate(stars)if hits(n,T))for n,_ in ns}
 assert all(any(not(pos[p]|pos[q])&~n for n,_ in ns)for p in points for q in points)
 @cache
 def rejects(t,x):
  v=0
  for n in QQ[t]:
   if not x&~n:v|=hit[n]
  return (v|(1<<t))==127
 private={p:{u for u in range(7)if p in stars[u]and rejects(u,pos[p]&~p)}for p in points}
 relation={(p,q):not any(not pos[q]&~n for n,l in F[p])for p in points for q in points if p!=q}
 return bank,pos,ns,F,private,relation,hit,rejects
@cache
def pass_budget(ds,b):
 if b<0:return False
 if len(ds)<=b:return True
 assert all(m.bit_count()==3 for m in ds)
 universe=sum(1<<i for i in range(8)if any(m>>i&1 for m in ds))
 z=[{0}]
 for n in range(1,b+1):
  one={1<<j for j in range(len(ds))}if n==1 else set()
  for C in combinations([j for j in range(8)if universe>>j&1],min(universe.bit_count(),n+1)):
   t=sum(1<<j for j in C);one.add(sum(1<<j for j,m in enumerate(ds)if(t&m).bit_count()>=2))
  for i in range(1,n):one.update(x|y for x in z[i]for y in z[n-i])
  if (1<<len(ds))-1 in one:return True
  z.append(one)
 return False
def profile(c,O):
 bank,pos,ns,F,priv,rel,hit,rej=make_cache(c);os=sum(1<<j for j in O)
 R={p:sum(1<<j for j in O if j in priv[p])for p in points}
 E={p:tuple(n for n,l in F[p]if any(p in stars[u]and l>>u&1 for u in range(7)if u not in O)and hit[n]&os==os)for p in points}
 dm={p:(R[p]|(128 if E[p]else 0))for p in points};M=[p for p,m in dm.items()if m.bit_count()>=2]
 allowed={(q,p): rel[q,p] and all(not rej(t,(pos[q]&~q)|pos[p])for t in O if q in stars[t])for q in M for p in M if q!=p}
 solo=[dm[p]for p in M if dm[p].bit_count()>=3 and all(not allowed[q,p]for q in M if q!=p)]
 b=10-len(c)-(7-len(O))-len(M)
 return M,dm,b,solo,E,allowed
make_cache=cache(make)
if __name__=='__main__':
 for ex in range(5):
  res=Counter()
  for c in combinations(extra,ex):
   for z in range(8):
    for O in combinations(range(7),z):
     M,dm,b,solo,E,allowed=profile(c,O)
     if pass_budget(tuple(sorted(solo)),b):res[7-z]+=1
  print('ncore',16+ex,'kcore',10-ex,'survivor-counts',sorted(res.items()),flush=True)
