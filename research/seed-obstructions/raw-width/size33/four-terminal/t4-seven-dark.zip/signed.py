from ast import literal_eval
from pathlib import Path
from itertools import combinations
from marks import make,stars,points,extra
rows=[((),((),127,127,points))]
for f in ('one','two','three'):
 for line in Path(f+'.log').read_text().splitlines():
  end=line.index(') ')+1
  rows.append((literal_eval(line[:end]),literal_eval(line[end:].strip())))
assert {c for c,w in rows}=={c for b in range(4)for c in combinations(sorted(extra),b)}
assert len(rows)==42
for c,(H,U,V,K) in rows:
 bank,pos,raw,F,_,_,hit,_=make(c)
 assert set(H)<=set(c) and not V&~U and len(K)==len(set(K)) and set(K)<=set(points)
 hi=sum(1<<extra[m]for m in H);lo=sum(1<<extra[m]for m in c if m not in H)
 ns=[(n,l)for n,l in raw if n&hi==hi]
 inc={p:sum(1<<u for u in range(7)if p in stars[u])for p in K}
 us=[u for u in range(7)if U>>u&1];vs=[u for u in us if V>>u&1]
 assert all(any(l>>u&1 and hit[n]>>v&1 for n,l in ns)for u in vs for v in range(7)if v!=u)
 for p in K:
  assert not pos[p]&lo and inc[p]&U not in (0,U) and inc[p]&V
  assert all(any(n&p and hit[n]>>u&1 for n,l in ns)for u in range(7))
  assert all(any(n&p and l>>u&1 for n,l in ns)for u in us if p not in stars[u])
  assert all(any(l&inc[p]&U and l>>u&1 for n,l in ns)for u in vs)
  assert all(any(n&hi==hi and l>>u&1 for n,l in F[p])for u in vs)
 for p,q in combinations(K,2):
  assert inc[p]&U!=inc[q]&U and any(l&inc[p]&U and l&inc[q]&U for n,l in ns)
  assert any(n&hi==hi and n&q for n,l in F[p])or any(n&hi==hi and n&p for n,l in F[q])
 budget=3-len(c)
 measures=[min(d+sum(max(0,len((set(K)-set(z))&stars[u])-2)for u in vs)for z in combinations(K,d))for d in range(budget+1)]
 assert min(measures)>budget
 print(c,tuple(H),U,V,tuple(K),budget,measures)
