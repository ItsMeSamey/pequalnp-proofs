from exterior import *
counts=Counter()
for size in range(5):
 for C in combinations(extra,size):
  _,pos,ns,F,priv,rel,hit,rej=make_cache(C)
  for k in range(8):
   for O in combinations(range(7),k):
    r=7-k;M,dm,b,solo,E,allowed=profile(C,O)
    if not pass_budget(tuple(sorted(solo)),b):continue
    counts[size,r]+=1
    if r!=6:assert r==7;continue
    t,=O
    if b==0:
     assert set(M)==stars[t] and not any(allowed.values()) and all(dm[p]==((1<<t)|128)for p in M)
     assert not check(C,O)
     continue
    assert C==()and t in (1,2,3,5) and b==1 and set(M)==stars[t] and len(M)==3
    K=set(points)-set(M)
    assert all(any(l>>u&1 for n,l in F[p]) for u in range(7)for p in points)
    assert all(any(l>>u&1 and hit[n]>>v&1 for n,l in ns)for u in range(7)for v in range(7)if u!=v)
    for p in K:assert all(any(not pos[p]&~n and l>>u&1 for n,l in ns)for u in range(7)if p not in stars[u])
    for p,q in combinations(K,2):
     a={u for u in range(7)if p in stars[u]};d={u for u in range(7)if q in stars[u]}
     assert a!=d and len(a&d)<=1 and any(any(l>>u&1 for u in a)and any(l>>v&1 for v in d) for n,l in ns)
    D={u:max(0,len(K&stars[u])-2)for u in range(7)}
    assert {u for u in D if D[u]}=={0,4,6}and sum(D.values())==3
    assert all(any(len((K-{p})&stars[u])>2 for u in D)for p in K)
print('baseline by composite count and owners',sorted(counts.items()))
assert counts=={(0,6):7,(0,7):1,(1,6):24,(1,7):6,(2,7):15,(3,7):20}
print('all six-owner cases excluded; remaining seven-owner banks',1+6+15+20)
