from marks import *
from itertools import combinations_with_replacement
@cache
def shapes(n,k):
 arr=[]
 for tpl in combinations_with_replacement(range(1,1<<n),k):
  r={0}
  for t in tpl:r|={s|t for s in r if not s&t}
  arr.append(r)
 return arr
def check(c,O):
 _,pos,ns,F,pr,rel,hit,rej=make_cache(c)
 ns=tuple(set(ns));vset=set(range(7))-set(O);oa=sum(1<<u for u in O)
 masking={(u,p):set((n,l) for n,l in F[p]if l>>u&1)for u in vset for p in stars[u]}
 A={(u,p):{(n,l)for n,l in rows if hit[n]&oa==oa}for (u,p),rows in masking.items()}
 M={p:set.union(*(rows for (u,q),rows in A.items()if q==p)) for p in points if any(rows for (u,q),rows in A.items()if q==p)}
 ds={p:{7,*vset}for p in M}
 for p in M:
  for v in vset:
   if A.get((v,p)) and any(u!=v and any(hit[n]>>v&1 for n,l in A.get((u,p),()))for u in vset):ds[p].remove(v)
 while True:
  rm=0
  for p in M:
   for v in list(ds[p]-{7}):
    if any(l>>v&1 and any(v not in ds[q]and (n,l)in masking.get((v,q),())for q in M)for n,l in M[p]):ds[p].remove(v);rm+=1
  if not rm:break
 inc={p:{u for u in vset if A.get((u,p))and all(w==u or any(hit[n]>>w&1 for n,l in masking[u,p])for w in vset)}for p in M}
 @cache
 def bill(h,u,sub):
  ps=[p for p in M if p&sub and u in inc[p]]
  if not ps or h==u:return 0
  cols={(n,l)for n,l in ns if (hit[n]&oa==oa if h==7 else hit[n]>>h&1)}
  for p in M:
   if sub&p:cols.update(M[p])
  rows={(sum(1<<j for j,p in enumerate(ps)if not pos[p]&~n),sum(1<<j for j,p in enumerate(ps)if(n,l)in M[p]))for n,l in cols}
  for k in (1,2):
   if any(all(any(not(y&~m or m&z)for m in sh)for y,z in rows)for sh in shapes(len(ps),k)):return k
  return 3
 loc=tuple(sorted(M,key=lambda p:len(ds[p])));g=[0]*8
 def walk(i):
  if i==len(loc):return True
  p=loc[i]
  for h in ds[p]:
   g[h]|=p
   edges={u:{v for v in vset if v!=u and bill(v,u,g[v])}for u in vset}
   for w in vset:
    for u in vset:
     if w in edges[u]:edges[u]|=edges[w]
   if not any(u in ee for u,ee in edges.items()) and all(sum(bill(v,u,g[v])for v in (*vset,7))<=2 for u in vset)and walk(i+1):return True
   g[h]^=p
  return False
 return walk(0)
if __name__=='__main__':
 for c in [(),*((m,)for m in extra)]:
  for O in combinations(range(7),1):
   M,dm,b,so,E,al=profile(c,O)
   if b==0:print(c,O,check(c,O))
