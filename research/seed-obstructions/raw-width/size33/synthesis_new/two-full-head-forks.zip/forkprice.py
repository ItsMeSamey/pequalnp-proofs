from functools import cache
from itertools import combinations
from collections import Counter
import gzip,json,sys
from cuts import DEGREE_ONE,load,extra
samples=cache(load)
P,_=samples(())
stars={q:{p&8191 for p in P if p>>(13+u)&1 and not p&q} for q,u in DEGREE_ONE.items()}
@cache
def profile(e,raw,C):
 P,N=samples(e);point=raw|sum(1<<extra[c] for c in C);mask=point|127<<13
 heads=[q for q in DEGREE_ONE if q not in e and raw&q];pool=set.union(*(stars[q] for q in heads))
 @cache
 def swap(r,s):
  return any(n&s and not n&r and not (p&mask&~r)&~n for p in P if p&r for n in N)
 pts={p&8191:p for p in P};ok={}
 for q in heads:
  rq=pts[q]&mask&~q;W=[n for n in N if not n&q and not rq&~n]
  ok[q]={r for r in stars[q] if swap(r,q) and any(not (pts[r]&point&~r)&~n for n in W)}
 clean={(r,s)for r,s in combinations(sorted(pool),2)if swap(r,s) or swap(s,r)};out={}
 for z in (2,3):
  for Q in combinations(heads,z):
   R=sorted(set.union(*(ok[q]for q in Q)))
   out[sum(Q)]=max(n for n in range(len(R)+1)if any(all(p in clean for p in combinations(H,2))for H in combinations(R,n)))
 return out
counts=Counter()
for i,l in enumerate(gzip.open(sys.argv[1],'rt')):
 t,e,r,C,idx,a,price,old=json.loads(l)
 if t>1 or old or 0 in a:continue
 out=profile(tuple(e),r,tuple(C));two=[price-15-len(C)-n for q,n in out.items()if q.bit_count()==2]
 print(i,list(out.items()));counts[t,price,max(two)]+=1
print('COUNTS',sorted(counts.items()))
