import ast
import gzip
import json
import sys
from collections import Counter
from functools import cache
from cuts import DEGREE_ONE, extra, load
cached_load = cache(load)

@cache
def profile(peeled, raw, comps):
    positives, negatives = cached_load(peeled)
    point = raw | sum(1 << extra[c] for c in comps)
    mask = point | (127 << 13)
    profiles = []
    for q in DEGREE_ONE:
        if q in peeled or not q & raw:
            continue
        pos = next(p for p in positives if p & q)
        stripped = pos & mask & ~q
        witnesses = [n for n in negatives if not n & q and not stripped & ~n]
        line_union = 0
        for n in witnesses:
            line_union |= (n >> 13) & 127
        unmasked_points = set()
        for p in positives:
            trace = p & point & ~q
            if not any(not trace & ~n for n in witnesses):
                unmasked_points.add(p & 8191)
        profiles.append((q, line_union, sum(unmasked_points)))
    return tuple(profiles)

counts = Counter()
with gzip.open(sys.argv[1], 'rt') as rows:
    for key, row in enumerate(rows):
        t, e, raw, comps, _, aliases, price, old = json.loads(row)
        if t > 1 or old or 0 in aliases:
            continue
        sig = profile(tuple(e), raw, tuple(comps))
        # 'need_line' forbids a point-only companion. 'need_point' forbids line-only.
        need_line = sum(x[2] == 0 for x in sig)
        need_point = sum(x[1] == 127 for x in sig)
        both = sum(x[1] == 127 and x[2] == 0 for x in sig)
        counts[t, price, len(sig), need_line, need_point, both] += 1
        print(key, t, price, sig)
print('COUNTS', sorted(counts.items()))
