# Three pure gates per complete degree-one star

Choose m of the at most four degree-one points whose pure-point unextracted OR heads H_i=q_i OR B_i realize exactly their incident stars T_i on the retained positive singleton points. Write S_i=T_i minus q_i. Each S_i has three points; no other peeled degree-one point is on T_i. B_i realizes S_i: if B_i were true at q_i, bypassing H_i to B_i would preserve every positive and only decrease negatives. Every raw point primitive, including all 18 compounds, meets each S_i at most once (the four masks are 6272,1408,2816,5632). Different incident lines meet at most once.

Single out H_i and the first physical wire F_i with signature S_i. These are 2m distinct paid pure-point gates provided F_i is selected in the pure-point subcircuit, as it is here. F_i precedes H_i because B_i already realizes S_i. Let h count all remaining pure-point gates; duplicate signatures and arbitrary fanout are allowed.

For an OR F_i one parent is contained in S_i and holds at least two of its points. It is counted among the h: no raw, H_j or F_j for a different target contains two of those points, and H_i is later. That parent can serve only one such OR, and cannot be a parent of an AND target S_j (it does not contain S_j). For an AND F_i both parents contain S_i and hence both must be among the h. They are distinct since an equal pair would realize S_i before F_i. One unordered pair computes only one intersection.

If o targets are OR and a are AND, h≥o and a≤binomial(h-o,2). For a=1,2,3,4 this needs at least 2,3,3,4 gates outside the o respectively, in each case at least a. Thus h≥o+a=m, including a=0. The total pure-point gate count is at least 3m, with no pair-safety hypothesis.

The original mixed floor 23 allows only ten pure gates at size 33. Four complete point stars are therefore impossible across the entire original domain. Three require nine pure-point gates, leaving at most one additional pure gate. No whole bank is excluded solely by this restriction.
