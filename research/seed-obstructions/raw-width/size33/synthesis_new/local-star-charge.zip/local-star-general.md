# Partial point stars

Select any physically pure-point degree-one OR heads H_i=q_i OR B_i whose retained singleton signatures lie inside their own incident lines. Write A_i for the companion signature and k_i for its size. Minimality gives q_i outside A_i and 1≤k_i≤3. The circuit needs at least sum_i k_i paid pure-point gates.

Count H_i for every head and the earliest pure-point wire F_i realizing A_i whenever k_i≥2. Each original primitive hits A_i at most once, so F_i is paid. These counted wires are distinct: lines intersect at most once and H_i follows F_i.

For each triple target whose F_i is OR, one additional wire contained in A_i includes at least two points. Different OR triples need distinct such gates. None can be a parent of an AND realizing a different triple. An AND triple requires two distinct additional gates as parents; no raw nor previously counted F_j or H_j covers this triple (its own H_i is later). An unordered pair of parents realizes only one intersection. Thus if the number of extra gates is h and there are o OR triples and a AND triples, h≥o and a≤binomial(h-o,2). For a=0,1,2,3,4 this gives h≥o+a. Summing proves the bound.

The single-point witness table in star.md forces this locality for every pure-point head on 2112+5047 noninert originals, and on at least one potential head of every noninert original. The count applies to those heads which are physically pure point. The simultaneous full-star consequence needs only the raw incidence and the stated support premise.
