from functools import cache
from collections import Counter
from itertools import combinations,product
import gzip,json,sys
from cuts import DEGREE_ONE,load,extra
samples=cache(load)
P,_=samples(())
stars={q:{p&8191 for p in P if p>>(13+u)&1 and not p&q} for q,u in DEGREE_ONE.items()}
@cache
def rows(e,raw,C):
 P,N=samples(e)
 mask=raw|127<<13|sum(1<<extra[c]for c in C)
 witnesses={}
 for q,q2 in combinations([q for q in DEGREE_ONE if q not in e and raw&q],2):
  common,=stars[q]&stars[q2]
  need=[(i,p&mask&~common) for i,p in enumerate(P) if p&common]
  for a,b in product(sorted(stars[q]-{common}),sorted(stars[q2]-{common})):
   w=next(((i,j) for i,p in need for j,n in enumerate(N) if not n&common and n&a and n&b and not p&~n),None)
   witnesses[q,q2,common,a,b]=w
 return witnesses
D=Counter()
for i,l in enumerate(gzip.open(sys.argv[1],'rt')):
 t,e,r,C,idx,als,price,old=json.loads(l)
 if t>1 or old or 0 in als:continue
 w=rows(tuple(e),r,tuple(C));heads=[q for q in DEGREE_ONE if q not in e and r&q]
 infos=[]
 for T in combinations(heads,3):
  n=0
  for q,v in combinations(T,2):
   n+=all(ans is not None for k,ans in w.items() if k[:2]==(q,v))
  infos.append((sum(T),n))
 print(i,infos);D[t,price,len(C),min((s for k,s in infos),default=-1)]+=1
print('COUNTS',sorted(D.items()))
with open('jointread-witnesses.json','w')as f:
 keys=set()
 for l in gzip.open(sys.argv[1],'rt'):
  t,e,r,C,idx,als,price,old=json.loads(l)
  if t<=1 and not old and 0 not in als:keys.add((tuple(e),r,tuple(C)))
 data=[(k,list(rows(*k).items()))for k in sorted(keys)]
 json.dump(data,f,separators=(',',':'))
