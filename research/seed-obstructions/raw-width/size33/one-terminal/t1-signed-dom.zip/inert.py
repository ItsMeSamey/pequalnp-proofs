from bankjoin import *
src=Path('.')
old=defaultdict(list)
for c,w,*_ in map(literal_eval,(src/'missing2.log').read_text().splitlines()):old[c].append(dict(w))
R=8133
sel=[]
for i,s in enumerate(gzip.open(src/'terminal-raw-keys.jsonl.gz','rt')):
 t,e,r,co,idx,alias,g,_=json.loads(s)
 if t!=1 or g!=28 or 0 not in alias:continue
 ct=Counter(pts);ct.update(x for x in alias if x)
 c=tuple(x for x in D if x in ct)
 w=tuple(sorted((x,k)for x,k in ct.items() if k>1))
 matches=[v for v in old[c] if all(ct[x]>=k for x,k in v.items())]
 sel.append((i,e,r,co,alias,c,w,bool(matches)))
print('labelled',len(sel),'direct',sum(b for *_,b in sel),'caps',Counter(c for _,_,_,_,_,c,_,_ in sel))
Path('inert24.txt').write_text(repr(sel))
