from bankjoin import *
BASE=8133|127<<13
def maps():
 for pi,pm in perms():
  dmap={c:sum(pm[p] for p in pts if p&c) for c in D}
  bm={**{p:p0 for p0,p in pm.items()},**{1<<(13+j):1<<(13+i)for i,j in pi.items()}}
  def back(r):return sum(t for s,t in bm.items()if r&s)
  dom=[sum(1<<j for j,b in enumerate(N)if not back(n)&~b)for n in N]
  assert all(dom)and all(any(a&BASE==back(p) for a in P)for p in P)
  yield pm,dmap,dom
def run():
 assert len(P)==24 and len(N)==239
 assert all(bool(p&m)==bool(p>>extra[m]&1)for p in P for m in D)
 rows=literal_eval(Path('allkeys.txt').read_text())
 olds=defaultdict(list)
 for c,w,*_ in map(literal_eval,Path('missing2.log').read_text().splitlines()):olds[c].append(dict(w))
 neg={x:sum(1<<j for j,b in enumerate(N)if b>>extra[x]&1) for x in D}
 oldfocus=literal_eval(Path('t1focus.txt').read_text());base=set(i for c,w,ii,_,skip in oldfocus if skip for i in ii)
 found=set();direc=set();ccount=Counter();receipts={}
 for aid,(pm,ds,domains) in enumerate(maps()):
  # projected source m must be high on every preimage of a target positive where it is present.
  mods={s:next((t for t in D if (t&8133)==ds[s]),None) for s in D}
  opts={s:[t for t in (mods[s],-1) if t is not None]for s in D}
  from itertools import product
  for c,items in __import__('itertools').groupby(rows,key=lambda t:t[0]):
   items=list(items)
   for dest in product(*(opts[s]for s in c)):
    cd=tuple(sorted(set(dest)-{-1}))
    if -1 not in dest and cd not in olds:continue
    good=True
    for j,n in enumerate(N):
     d=domains[j]
     for a,b in zip(c,dest):
      if b<0 or n>>extra[b]&1:d&=neg[a]
     if not d:good=False;break
    if not good:continue
    for _,w,ids in items:
     if -1 in dest:
      found.update(ids);ccount['constant']+=len(ids);continue
     price={pm[k] if k in pm else mods[k]:q for k,q in w}
     for weight in olds[cd]:
      if all(price.get(k,1)>=v for k,v in weight.items()):
       direc.update(ids)
       for i in ids:receipts[i]=(c,w,aid,cd,tuple(sorted(weight.items())))
       break
 print('constants',len(found),'weighted',len(direc),'known',len(base),'new',len((found|direc)-base),sorted((found|direc)-base)[:25])
 Path('witnesses.txt').write_text(repr(sorted(receipts.items())))
 Path('keys.txt').write_text(repr(sorted((found|direc)-base)))
run()
