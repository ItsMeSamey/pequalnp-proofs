from ast import literal_eval
from itertools import permutations
from collections import Counter,defaultdict
from functools import cache
from pathlib import Path
import gzip,json
from geometry import P,N,pts,stars,inc
from cuts import extra
D=(129,354,523,1046,2092,4160);focus=((),(129,),(4160,))
def maxima(s):return {x for x in s if not any(x!=y and not x&~y for y in s)}
@cache
def table(c):
 mask=8133|127<<13|sum(1<<extra[x]for x in c)
 return {p&mask for p in P},maxima({n&mask for n in N})
def perms():
 by={frozenset(j for j,t in enumerate(stars)if p&t):p for p in pts};a=(1,2,3,5);b=(0,4,6)
 for x in permutations(a):
  for y in permutations(b):
   pi=dict(zip(a+b,x+y))
   try:pm={p:by[frozenset(pi[u]for u in ns)]for ns,p in by.items()}
   except KeyError:continue
   yield pi,pm
def actions(c):
 A=[]
 for pi,pm in perms():
  d=tuple(sorted(sum(q for p,q in pm.items()if p&x)for x in c))
  if d not in focus:continue
  M={**pm,**{1<<(13+i):1<<(13+j)for i,j in pi.items()}}
  if c:M[1<<extra[c[0]]]=1<<extra[d[0]]
  T=lambda r:sum(y for x,y in M.items()if x&r)
  P0,N0=table(c);P1,N1=table(d)
  if {T(p)for p in P0}==P1 and {T(n)for n in N0}==N1:A.append((d,pm))
 return A
def make():
 rows=defaultdict(list)
 for i,s in enumerate(gzip.open('terminal-raw-keys.jsonl.gz','rt')):
  t,e,r,co,idx,aliases,bound,old=json.loads(s)
  if t!=1 or r!=(8191^sum(e)) or bound!=28:continue
  assert r&8133==8133 and 0 not in aliases
  ct=Counter(pts);ct.update(aliases);c=tuple(x for x in D if ct[x]);w=tuple((x,k)for x,k in sorted(ct.items())if k>1)
  rows[c,w].append(i)
 assert sum(map(len,rows.values()))==5976
 old=defaultdict(list)
 for C,W,ii,ss in map(literal_eval,Path('missing2.log').read_text().splitlines()):old[C].append(dict(W))
 ac={c:actions(c)for c in focus};out=[];stats=Counter()
 for (c,w),ids in rows.items():
  if c not in focus:continue
  orb=[];skip=False
  for d,perm in ac[c]:
   W=tuple(sorted((perm.get(x,d[0] if d else -1),k)for x,k in w));Wd=dict(W);orb.append((d,W))
   if any(all(Wd.get(x,1)>=k for x,k in base.items())for base in old.get(d,[])):skip=True
  out.append((c,w,ids,min(orb),skip));stats[c,skip]+=len(ids)
 Path('t1focus.txt').write_text(repr(sorted(out)));Path('allkeys.txt').write_text(repr(sorted((c,w,ids)for (c,w),ids in rows.items())))
 print('all',sum(map(len,rows.values())),len(rows),'focus',dict(stats),'action sizes',[len(ac[c])for c in focus], 'unique focus',len(set(r[3]for r in out if not r[-1])))
 print('keys priced',sorted(Counter((r[3][0],sum(k-1 for x,k in r[3][1]))for r in out if not r[-1]for i in r[2]).items()))
if __name__=='__main__':make()
