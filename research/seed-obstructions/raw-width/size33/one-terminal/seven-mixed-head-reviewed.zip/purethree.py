import gzip,json,sys
from functools import cache
from itertools import combinations,product
from collections import Counter
from cuts import DEGREE_ONE,load,extra
samples=cache(load);P,_=samples(())
stars={q:{p&8191 for p in P if not p&q and p>>(13+u)&1}for q,u in DEGREE_ONE.items()}
@cache
def test(e,r,C):
 P,N=samples(e);pm=r|sum(1<<extra[c]for c in C);mask=pm|127<<13;pt={p&8191:p for p in P}
 Q=tuple(q for q in DEGREE_ONE if q not in e and r&q);assert len(Q)==3
 @cache
 def swap(a,b):
  return any(n&b==b and not n&a and not (p&mask&~a)&~n for p in P if p&a for n in N)
 for q in Q:
  stripped=pt[q]&mask&~q;W=[n for n in N if not n&q and not stripped&~n]
  V={a for a,p in pt.items() if not any(not (p&pm&~q)&~n for n in W)}
  if not V<=stars[q]:return 'nonlocal'
  for a in stars[q]:
   if not swap(a,q) or not any(not (pt[a]&pm&~a)&~n for n in W):return 'large'
  if not all(swap(a,b) or swap(b,a) for a,b in combinations(stars[q],2)):return 'large'
 for pool in combinations(sorted(set.union(*(stars[q]for q in Q))),2):
  opts=[]
  for q in Q:
   u=sorted(stars[q]&set(pool));opts.append([*[(x,)for x in u],*list(combinations(u,2))])
  for A in product(*opts):
   bad=False
   for a in pool:
    other=[q if len(x)==1 else next(v for v in x if v!=a) for q,x in zip(Q,A) if a in x]
    if len(other)==2 and swap(a,other[0]|other[1]):bad=True;break
   if not bad:return ('small',Q,A)
 return 'excluded'
d=Counter()
for i,l in enumerate(gzip.open(sys.argv[1],'rt')):
 t,e,r,C,idx,al,s,old=json.loads(l)
 if t!=1 or s!=28 or old or 0 in al or len(C)!=4:continue
 a=test(tuple(e),r,tuple(C));print(i,a);d[a if isinstance(a,str) else a[0]]+=1
print('COUNTS',d)
