# First point fork from a head

Let pure-point B be high at r and H=q OR B. Assume a q-masking negative dominates the r point pattern after raw r is removed, and a positive on r has a negative with q high and r low dominating all other raw inputs. Then raw r is pivotal for B on the bare singleton. Not all output paths from r pass through H since H is high at the latter negative.

The first branching vertex F_r on the unique path from raw r thus occurs before H, possibly at B or r. It is pure point since it reaches H. It is high at bare r since B changes with r and all change must pass through F_r. For two priced points r,s, suppose a positive on r has a negative containing s and lacking r dominating all other raw inputs, in either orientation. Then F_r and F_s differ: otherwise their common F is high at s and thus on the negative, which would dominate the positive at that cut.

A head bypass transfers its excess to the companion: at fanout d the companion loses one occurrence and gains d. Marked head and marked predecessor can charge the combined excess legitimately. Distinct point-fork units stay on pure-point vertices, disjoint from mandatory line owners and the additional raw-alias merger debit. No canonicalization of B is required.
