from functools import cache
from collections import Counter
import gzip,json,sys
from cuts import DEGREE_ONE,load,extra
samples=cache(load)
P,_=samples(())
stars={q:sorted({p&8191 for p in P if p>>(13+u)&1 and not p&q}) for q,u in DEGREE_ONE.items()}
@cache
def rows(e,raw,C):
    P,N=samples(e)
    mask=raw|127<<13|sum(1<<extra[c]for c in C)
    obligations={}
    for q,arm in stars.items():
        if q in e or not raw&q:continue
        for r in arm:
            assert raw&r
            need=[p&mask&~r for p in P if p&r]
            for s in [q,*[x for x in arm if x!=r]]:
                obligations[q,r,s]=next(((i,j)for i,p in enumerate(need)
                    for j,n in enumerate(N) if n&s and not n&r and not p&~n),None)
    return obligations
counts=Counter()
for i,l in enumerate(gzip.open(sys.argv[1],'rt')):
 t,e,r,C,idx,als,price,old=json.loads(l)
 if t>1 or old or 0 in als:continue
 d=rows(tuple(e),r,tuple(C));a=sorted(k for k,w in d.items()if w is None)
 print(i,','.join('-'.join(map(str,k))for k in a));counts[t,len(a)]+=1
print('COUNTS',sorted(counts.items()))
