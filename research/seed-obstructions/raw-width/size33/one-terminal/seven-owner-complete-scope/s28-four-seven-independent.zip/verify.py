from pathlib import Path
import sys,subprocess,ast
from collections import Counter
r=Path(__file__).resolve().parent;L=r/'ledgers'
def check(cmd,args,log):
 d=subprocess.check_output([sys.executable,str(r/cmd),*map(str,args)],cwd=L)
 assert d==log.read_bytes(),cmd
check('make.py',[],r/'make.log')
check('census.py',[],r/'counts.log')
inds=list(map(int,sys.argv[1:]))or list(range(15))
done=set();by=Counter()
for i in inds:
 a=L/f'{i}.log';b=L/f'joint{i}.log'
 check('census.py',[i],a);check('cross.py',[i],b)
 c,w,ids,slots=ast.literal_eval(a.read_text())
 assert not w and not done.intersection(ids)
 if slots:
  c1,w1,ids1,n,remaining=ast.literal_eval(b.read_text())
  assert (c1,w1,ids1,n)==(c,w,ids,len(slots))and not remaining
 else:assert b.read_text()==''
 done.update(ids);by['cross-pin' if slots else 'coarse']+=len(ids)
if len(inds)==15:assert len(done)==164 and by=={'coarse':68,'cross-pin':96}
print(len(done),dict(by))
