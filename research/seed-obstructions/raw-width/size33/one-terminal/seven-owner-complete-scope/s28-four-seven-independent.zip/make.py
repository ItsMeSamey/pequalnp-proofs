from collections import defaultdict,Counter
from pathlib import Path
import gzip,json
src=Path(__file__).resolve().parent/'src'
pts=[1<<i for i in range(13) if 8133>>i&1]
comp=(129,354,523,1046,2092,4160)
keys=defaultdict(list);tags={};counts=Counter()
for i,l in enumerate(gzip.open(src/'terminal-raw-keys.jsonl.gz','rt')):
 t,e,r,original,idx,alias,b,old=json.loads(l)
 if old or t not in (0,1):continue
 if b not in (28,29,30):continue
 raw=Counter(pts)
 raw.update(x for x in alias if x)
 c=tuple(x for x in comp if raw[x])
 if len(c)!=4:continue
 counts[(t,b,tuple(e),r==8191^sum(e),alias.count(0))]+=1
 if b!=28 or t!=1 or 0 in alias:continue
 assert r&8133==8133
 w=tuple(sorted((p,n)for p,n in raw.items()if n>1))
 keys[c,w].append(i);tags[i]=(t,tuple(e),r,tuple(original))
out=Path(__file__).parent
(out/'allkeys.txt').write_text(repr(sorted((c,w,ids)for (c,w),ids in keys.items())))
(out/'tags.log').write_text(repr(tags))
print('ancestry',dict(counts))
for c in sorted({c for c,w in keys}):
 fam=[(w,ids)for (cc,w),ids in keys.items()if cc==c]
 print(c,len(fam),dict(Counter(tags[i][0]for w,ids in fam for i in ids)))
