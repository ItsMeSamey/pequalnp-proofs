import sys,ast
from pathlib import Path
from collections import defaultdict
from functools import reduce
src=Path(__file__).resolve().parent/'src'
sys.path.insert(0,str(src))
from weighted import *
from checkedgroups import checked_allow
keys=defaultdict(list)
for c,w,ids in ast.literal_eval(Path(__file__).with_name('allkeys.txt').read_text()):
 if len(c)==4:keys[c].append((w,ids))
triples=sorted(keys,key=lambda c:(sum(t in c for t in (129,4160)),c))
def conflicts(c):
 top=pack(lambda n:all(n>>extra[x]&1 for x in c))
 f={p:pack(lambda n:not n&p and n>>13&inc[p] and all(not p&x or n>>extra[x]&1 for x in c))for p in pts}
 return [(p,q)for p,q in combinations(pts,2)if not top&(f[p]&pt[q]|f[q]&pt[p])]
def grouped(c,w,pairs):
 W=dict(w);raw=sum(p for p in pts if p in W);b=2-sum(v-1 for p,v in w)
 if b<0:return
 groups=[sum(G)for k in range(1,len(pts)+1) for G in combinations([p for p in pts if p not in W],k) if all(pair in pairs for pair in combinations(G,2))]
 for a in range(b+1):
  for gs in combinations(groups,a):
   if any(x&y for x,y in combinations(gs,2)):continue
   for g in range(b-a+1):
    for ds in product(range(b-a-g+1),repeat=a+g):
     spare=b-a-g-sum(ds)
     if spare>=0:yield raw|union(gs),gs,g,ds,spare
def run(i):
 c=triples[i];bad=conflicts(c);cs=checked_allow(c)
 for w,ids in keys[c]:
  keep=[]
  for z,gs,g,ds,sp in grouped(c,w,bad):
   for v,k,up in cs:
    req=tuple(sorted(inc[p]&v for p in pts if p&k&~z))
    su=tuple(sorted([(0 if b&k else (v & reduce(int.__and__,[up[pts.index(p)] for p in bm(b)],127)),2+ds[j])for j,b in enumerate(gs)]+[(v,2+d)for d in ds[len(gs):]]))
    if not enough(req,v,su,sp):break
   else:keep.append((z,gs,g,ds,sp))
  print((c,w,ids,keep),flush=True)
if __name__=='__main__':
 if len(sys.argv)==1:
  for i,c in enumerate(triples):print(i,c,len(keys[c]),sum(len(ids) for w,ids in keys[c]),conflicts(c))
 else:run(int(sys.argv[1]))
