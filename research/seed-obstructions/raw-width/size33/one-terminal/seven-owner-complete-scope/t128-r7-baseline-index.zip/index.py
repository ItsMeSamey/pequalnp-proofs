import ast,gzip,hashlib,json,zipfile
from collections import Counter,defaultdict
from pathlib import Path
from shutil import copyfile
root=Path('/workspace/scratch')
def find(n):
 for d in ('syn_sat','syn_quotients','syn_pruning','syn_verify','syn_mitm','synthesis_new','syn_cover'):
  p=root/d/n
  if p.exists():return p
 raise FileNotFoundError(n)
deps={
'empty':['t1-r7-empty-two-plus.zip','t1-r7-empty-universal.zip'],
'single4':['t128-r7-quartet-top.zip'],
'endpoint':['t1-r7-endpoint-retained.zip','t1-endpoint-anon-complete.zip','t1-low-endpoint-anonymous.zip','one-end-virtual-literal-extension.zip'],
'pairbase':['one-terminal-seven-two-compounds.zip','t428-missing-seven-two-compounds.zip'],
'pairtop':['t1-seven-pair-top.zip','t1-seven-one-end-virtual-reviewed.zip'],
'both':['t1-seven-both-cross.zip'],
'three':['t1-three-seven-complete-v2.zip'],
'four':['t1-four-seven-68.zip','t1-four-unnamed.zip','t1-four-named.zip','t1-four-complete.zip','four-compound-antichain.zip']}
def read(n,f):
 with zipfile.ZipFile(find(n))as z:return z.read(f).decode()
def material(n,p):
 if not Path(n).exists():copyfile(p,n)
 return Path(n)
folder=find('t1r7')
raw=material('terminal-raw-keys.jsonl.gz',folder/'terminal-raw-keys.jsonl.gz')
keys=material('allkeys.txt',folder/'allkeys.txt')
focus=material('t1focus.txt',folder/'t1focus.txt')
low=material('singleton-live.txt',find('t1lowend')/'live.txt')
virt=material('virtual-more.jsonl',find('t1lowend')/'virtual-more.jsonl')
meta={}
for n in sorted(set(sum(deps.values(),[]))):
 p=find(n)
 with zipfile.ZipFile(p)as z:assert z.testzip() is None
 meta[n]=[str(p),hashlib.sha256(p.read_bytes()).hexdigest()]
bank={};all28={}
for i,s in enumerate(gzip.open(raw)):
 t,e,r,c,idx,als,price,old=json.loads(s)
 if t!=1 or price!=28:continue
 all28[i]=[e,r,c,als,old]
 if r!=8191^sum(e):continue
 assert 0 not in als
 w=Counter(1<<j for j in range(13)if 8133>>j&1);w.update(als)
 bank[i]=(tuple(a for a in (129,354,523,1046,2092,4160)if w[a]),tuple(sorted((a,k)for a,k in w.items()if k>1)))
assert bank=={i:(c,w)for c,w,ids in ast.literal_eval(keys.read_text())for i in ids}
ep={129,4160};both=json.loads(read(deps['both'][0],'both-reasons.json'))
lowids={i:w for w,ids in ast.literal_eval(low.read_text())for i in ids}
via={i for i,t,full,p,c,*tail in map(json.loads,virt.read_text().splitlines())if t==1 and full and p==28 and len(c)==1}
foc={i:(skip,k)for c,w,ids,k,skip in ast.literal_eval(focus.read_text())for i in ids}
pr=set(map(int,read(deps['pairbase'][0],'remaining.ids').split()))
with zipfile.ZipFile(find(deps['three'][0]))as z:
 tri={i for j in range(20)for l in z.read(f'ledgers/{j}.log').decode().splitlines()for i in ast.literal_eval(l)[2]}
assert tri=={i for i,(c,w)in bank.items()if len(c)==3}
four={i for l in read('t1-four-complete.zip','join.log').splitlines()if l[:1].isdigit()for i in ast.literal_eval(l[l.index('['):])}
assert four=={i for i,(c,w)in bank.items()if len(c)==4}
blocks=defaultdict(list);rows=[]
for i,(c,w)in bank.items():
 if not c:s=b='empty'
 elif len(c)==1 and c[0] not in ep:s='single-quartet';b='single4'
 elif len(c)==1:
  b='endpoint'
  if i in lowids:s='single-end-wild16' if not lowids[i] else 'single-end-low-positive'
  elif foc[i][0]:s='single-end-weight-transfer'
  elif sum(v-1 for p,v in w)>=3:s='single-end-high'
  elif i in via:s='single-end-virtual'
  else:raise ValueError(i)
 elif len(c)==2:
  if set(c)==ep:
   b='both';s='both-'+both[str(i)];s+=('-cap16' if not w and s=='both-open'else '')
  elif i not in pr:s='pair-initial';b='pairbase'
  else:s='pair-virtual' if ep.intersection(c) else 'pair-quartets-top';b='pairtop'
 elif len(c)==3:s=b='three'
 else:s=b='four'
 blocks[s].append(i);rows.append([i,c,w,s,b])
Path('ledger.jsonl').write_text(''.join(json.dumps(l,separators=(',',':'))+'\n'for l in rows))
Path('blocks.json').write_text(json.dumps(dict(sorted(blocks.items())),sort_keys=True))
Path('outside.json').write_text(json.dumps({i:r for i,r in all28.items()if i not in bank}))
Path('dependencies.json').write_text(json.dumps({'groups':deps,'archives':meta},indent=2))
print('all t1/28',len(all28),'all-present',len(bank),'other',len(all28)-len(bank),Counter(len(c)for c,w in bank.values()))
print({k:len(v)for k,v in sorted(blocks.items())})
