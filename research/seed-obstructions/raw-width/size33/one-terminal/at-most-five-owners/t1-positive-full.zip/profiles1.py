from resources import *
import ast,sys
from collections import defaultdict
src=json.loads(Path('remaining.json').read_text());j=defaultdict(list)
for key,(ids,rs)in src.items():
 _,c,w=ast.literal_eval(key)
 if len(c)!=1:continue
 for O,b in rs:
  if O.bit_count()==2:j[c,O].append((dict(w),ids))
for i,((c,O),rows) in enumerate(sorted(j.items())):
 if not int(sys.argv[1])<=i<int(sys.argv[2]):continue
 ws=[w for w,ids in rows];w={p:min(d[p]for d in ws)for p in ws[0]if all(p in d for d in ws)}
 s=Source(0);s.bank(c);oo=tuple(t for t in range(7)if O>>t&1);_,M,_,_=s.roles(O,12);b=12-5-len(set(M)|set(w))-sum(n-2 for n in w.values())
 for an in range(b+1):
  ret=run(s,oo,12,an,500,True,w);print(i,c,O,an,ret,flush=True)
