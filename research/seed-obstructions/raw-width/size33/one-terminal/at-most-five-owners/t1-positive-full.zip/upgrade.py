from core import *
import ast
x=json.loads(Path('profiles.json').read_text());src=ast.literal_eval(Path('allkeys.txt').read_text())
s=Source(0)
@cache
def cover(r,n):
 if not r:return True
 if n==0:return False
 v=min(r,key=int.bit_count)
 while v:
  u=v&-v;v-=u
  if cover(tuple(m for m in r if not m&u),n-1):return True
 return False
def exists(O,d,M,w):
 for p in M:
  Q=tuple(q for q in M if q!=p and q not in w)
  masks=set()
  for u in range(7):
   if not d[p]>>u&1:continue
   good=[q for q in Q if not(s.no[q,p]or s.no_t[q,p]&O)]
   for k in range(len(good)+1):
    for A in combinations(good,k):
     if s.reject(u,(s.pp[p]&~p)|union(s.pp[q]for q in A)):
      masks.add(1<<u|sum(1<<(8+j)for j,q in enumerate(Q)if q in good and q not in A))
  if d[p]&128:
   rows=s.F[p]&s.on[s.inc[p]&~O]&s.Ehits[O]
   while rows:
    bit=rows&-rows;rows-=bit
    masks.add(128|sum(1<<(8+j)for j,q in enumerate(Q)if not s.domq[q]&bit))
  req=tuple(sorted(m for m in masks if not any(n!=m and not n&~m for n in masks)))
  if not cover(req,max(2,w.get(p,0))):return False
 return True
out={};by=[set()for _ in range(6)];base=set();calls=0
for c in sorted({tuple(v[0]) for v in src}):
 s.bank(c)
 for cc,ww,ids in src:
  if tuple(cc)!=c:continue
  ww=tuple(map(tuple,ww));w=dict(ww);key=str((28,c,ww));rows=x[key][1];keep=[]
  if rows:base.update(ids)
  for O,b in rows:
   d,M,_,_=s.roles(O,13-len(c))
   req=tuple(sorted(d[p]for p in M if d[p].bit_count()>max(2,w.get(p,0))and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&O for q in M)))
   if not pass_budget(req,b):continue
   if not b:
    calls+=1
    if not exists(O,d,M,w):continue
   keep.append((O,b));by[7-O.bit_count()].update(ids)
  out[key]=(ids,keep)
 s.dom.cache_clear();s.reject.cache_clear()
 print(c,len(out),flush=True)
Path('upgraded.json').write_text(json.dumps(out,separators=(',',':')))
print('base',len(base),'calls',calls,'by',list(map(len,by)),'any',len(set.union(*by)),'universe',sum(len(z[0])for z in out.values()))
