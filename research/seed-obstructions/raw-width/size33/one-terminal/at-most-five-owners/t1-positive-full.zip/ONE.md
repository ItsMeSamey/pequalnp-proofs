# One retained compound and five mandatory owners

Use the binary-exterior versus retained-source dichotomy from the two-compound certificate. With one retained compound the source surplus is twelve. The 126 groups are six compound masks crossed with the 21 ordinary-label pairs. Grant each group its componentwise common forced multiplicities. Ninety groups are excluded. The 36 remaining groups have both ordinary labels chosen from 1, 2, 3, 5.

The ledger aggregate.py recovers the original IDs using the weighted source packet and subsequent solver logs. Through these one-compound receipts, 4,748 of the 5,976 no-inert lifts require six or seven mandatory line owners.
