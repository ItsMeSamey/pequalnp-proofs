# Cohort results for the one-terminal no-inert domain

The source relaxation may grant every compound in the union of member banks, the largest member fanout budget and only the minimum compulsory multiplicities shared by all. This preserves a physical solution of any member. Signed point comparisons are recomputed on the enlarged union. rawregional.py is the existing region routing relaxation. A line is eliminated only when every available anonymous count returns False. True and None preserve the entire group.

The initial weighted census leaves 1,548 original lifts when all seven lines are ordinary. The 1,304 with one retained compound are covered in one joint cohort at fanout surplus twelve. The other 244 have the pure point bank. All its zero-through-three-anonymous calls are UNSAT and its last four-anonymous call is UNSAT on the larger conflict limit in pure0.py. Consequently every circuit in the 5,976-bank domain has at least one mandatory line owner.
