import ast,json
from pathlib import Path
T=json.loads(Path('upgraded.json').read_text())
size=set()
for fn in Path('.').glob('cohorts-*.log'):
 for ln in fn.read_text().splitlines():
  i,O,d,n,b,v=ln.split(' ',5)
  if all(a is False for a in ast.literal_eval(v)):size.add((int(O),int(d)))
exact=set()
for patt in ('pairretain.log','singleretain-*.log','smallretain-*.log'):
 for fn in Path('.').glob(patt):
  for ln in fn.read_text().splitlines():
   i,rest=ln.split(' ',1);lim=rest.index(')')+1;c=ast.literal_eval(rest[:lim]);O,n,b,res=rest[lim+1:].split(' ',3)
   if all(a is False for a in ast.literal_eval(res)):exact.add((c,int(O)))
if Path('exact1-b.log').exists():
 from collections import defaultdict
 stages=defaultdict(set)
 for fn in ('exact1-0.log','exact1-a.log','exact1-b.log'):
  for line in Path(fn).read_text().splitlines():
   i,c,O,an,rest=line.split(' ',4)
   if ast.literal_eval(rest.rsplit(' ',1)[0])==[]:stages[ast.literal_eval(c),int(O)].add(int(an))
 exact.update(k for k,v in stages.items() if v=={0,1,2})
if Path('profiles3.log').exists():
 from collections import defaultdict
 none=defaultdict(set)
 for line in Path('profiles3.log').read_text().splitlines():
  if line.startswith('original '):continue
  i,c,O,an,v=line.split(' ',4)
  if ast.literal_eval(v)==(False,[]):none[ast.literal_eval(c),int(O)].add(int(an))
 exact.update(key for key,done in none.items()if done=={0,1,2,3})
if Path('purehigher.log').exists():
 for line in Path('purehigher.log').read_text().splitlines():
  O,b,rest=line.split(' ',2);a=ast.literal_eval(rest.rsplit(' ',1)[0])
  if len(a)==int(b)+1 and all(x is False for x in a):exact.add(((),int(O)))
r0=json.loads(Path('r0-gone.json').read_text())
assert len(r0)==1304 and Path('pure0.log').read_text().strip()=='False'
by=[set()for r in range(6)];paid={}
for key,(ids,roles)in T.items():
 g,c,w=ast.literal_eval(key)
 live=[(O,b)for O,b in roles if O!=127 and (O,len(c))not in size and (c,O)not in exact]
 for O,b in live:by[7-O.bit_count()].update(ids)
 if live:paid[key]=(ids,live)
print('exact',len(exact),'size',len(size),'remaining by r',list(map(len,by)),'require six or seven',5976-len(set.union(*by)))
Path('remaining.json').write_text(json.dumps(paid,separators=(',',':')))
