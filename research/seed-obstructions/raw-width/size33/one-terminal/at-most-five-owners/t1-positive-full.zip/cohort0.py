from rawregional import *
import ast
src=json.loads(Path('upgraded.json').read_text());tab=[];s=Source(0)
for key,(ids,roles)in src.items():
 if any(O==127 for O,b in roles):
  g,c,w=ast.literal_eval(key);tab.append((c,dict(w),ids))
def test(block):
 c=tuple(sorted(set().union(*(set(q[0])for q in block))))
 w={p:min(q[1].get(p,1)for q in block)for p in block[0][1]if all(p in q[1]for q in block)}
 k=max(13-len(q[0])for q in block);s.bank(c)
 _,M,_,_=s.roles(127,k);b=k-len(set(M)|set(w))-sum(n-2 for n in w.values())
 ret=[]
 for an in range(b+1):
  ret.append(run(s,tuple(range(7)),k,an,400,w=w))
  if ret[-1]is not False:break
 s.dom.cache_clear();s.reject.cache_clear()
 return all(x is False for x in ret),ret
queue=[('all',tab)];n=0;gone=[]
while queue and n<60:
 key,block=queue.pop(0);n+=1;a,r=test(block)
 print(key,len(block),sum(len(v[2])for v in block),r,flush=True)
 if a:gone.extend(i for v in block for i in v[2])
 elif key=='all':
  for k in sorted({len(v[0])for v in block}):queue.append((str(k),[v for v in block if len(v[0])==k]))
 elif len(key)==1:
  for C in sorted({v[0]for v in block}):queue.append((repr(C),[v for v in block if v[0]==C]))
 Path('r0-gone.json').write_text(json.dumps(sorted(set(gone))))
