import gzip,json
from collections import Counter,defaultdict
from core import Source,pass_budget
from pathlib import Path
src=Path('terminal-raw-keys.jsonl.gz')
s=Source(0);grp=defaultdict(list);stats=Counter()
for i,line in enumerate(gzip.open(src,'rt')):
 t,E,R,C,_,aliases,b,closed=json.loads(line)
 if t!=1 or closed:continue
 a=Counter(s.pts);a.update(x for x in aliases if x)
 c=tuple(sorted(x for x in a if x not in s.pts))
 w=tuple(sorted((x,n)for x,n in a.items() if n>1)) if 0 not in aliases else ()
 grp[b,c,w].append(i);stats[b,len(c),len(C),int(0 in aliases)]+=1
assert sum(map(len,grp.values()))==6213
print('physical by bound,width,original-compounds,inert',sorted(stats.items()),flush=True)
print('key-count',len(grp),flush=True)
ct=Counter();new=Counter();ans={}
for c in sorted({k[1] for k in grp}):
 s.bank(c)
 for (g,cc,w),ids in grp.items():
  if cc!=c:continue
  w=dict(w);lefts=[];k=g+1-16-len(c)
  for O in range(1,128):
   r=7-O.bit_count()
   if r>5:continue
   d,M,_,_=s.roles(O,k);U=set(M)|set(w)
   left=k-r-sum(max(1,w.get(p,1)-1)for p in U)
   req=[d[p]for p in M if d[p].bit_count()>max(2,w.get(p,0))and all(q==p or q in w and not q&p or q in M and(s.no[q,p]or s.no_t[q,p]&O)for q in U)]
   if pass_budget(tuple(sorted(req)),left):
    ct[g,r]+=len(ids);new[g,r]+=1;lefts.append((O,left))
  ans[str((g,c,tuple(w.items())))]=[ids,lefts]
 s.dom.cache_clear();s.reject.cache_clear()
print('assignments labelled',sorted(ct.items()),'keyed',sorted(new.items()))
print('r<=5 possible original',Counter({g:sum(len(v[0]) for key,v in ans.items() if key.startswith('('+str(g)+',') and v[1]) for g in (28,29)}))
Path('profiles.json').write_text(json.dumps(ans,separators=(',',':')))
