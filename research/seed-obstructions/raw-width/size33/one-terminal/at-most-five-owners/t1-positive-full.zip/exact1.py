import branchsp
from pathlib import Path
from ast import literal_eval
import sys
for fn in sys.argv[1:]:
 for line in Path(fn).read_text().splitlines():
  i,c,O,an,v=line.split(' ',4);c=literal_eval(c);O=int(O);pr=literal_eval(v.rsplit(' ',1)[0]);res=[]
  try:
   for r,a,ex in pr:
    if a==1:
     if branchsp.chk(c,O,r,(),(),True,(),ex):res.append((r,a,ex))
    else:res.append((r,a,ex))
  except TimeoutError:sys.exit(0)
  print(i,c,O,an,res,branchsp.nc,flush=True)
