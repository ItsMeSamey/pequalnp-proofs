import ast,json
from pathlib import Path
def select(variable):
 outs={}
 for key,(ids,rs) in json.loads(Path('upgraded.json').read_text()).items():
  g,c,w=ast.literal_eval(key)
  if variable in ('one-five','one-three') and len(c)!=1:continue
  if variable.startswith('pure') and c:continue
  def allowed(o):
   if variable=='one-five':return o in (6,10,12,34,36,40)
   if variable=='one-three':return o==46
   if variable=='pure-four':return o in (13,14,38,42,44)
   if variable=='pure-previous':return o in (23,92,95,111,119,125,101,114,75,110,13,47,57,14,38,42,44,46,62)
   return o.bit_count()==2
  roles=[(o,b)for o,b in rs if allowed(o)]
  if roles:outs[key]=[ids,roles]
 return outs
if __name__=='__main__':
 import sys
 Path('remaining.json').write_text(json.dumps(select(sys.argv[1]),separators=(',',':')))
