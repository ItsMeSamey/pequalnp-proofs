from rawregional import *
s=Source(0);s.bank(());print(run(s,tuple(range(7)),13,4,10000),flush=True)
