from rawregional import *
from exterior import check
import ast
from collections import defaultdict
jobs=defaultdict(list)
for key,(ids,roles)in json.loads(Path('upgraded.json').read_text()).items():
 _,c,w=ast.literal_eval(key)
 for O,b in roles:
  if 3<=O.bit_count()<=6:jobs[c,O].append((w,ids))
for i,((c,O),rows) in enumerate(sorted(jobs.items(),key=lambda v:-sum(len(ids)for w,ids in v[1]))):
 if not int(sys.argv[1])<=i<int(sys.argv[2]):continue
 ds=[dict(w)for w,ids in rows];w={p:min(d[p]for d in ds)for p in ds[0]if all(p in d for d in ds)}
 s=Source(0);s.bank(c);k=13-len(c);_,M,_,_=s.roles(O,k);b=k-(7-O.bit_count())-len(set(M)|set(w))-sum(n-2 for n in w.values())
 ord=tuple(t for t in range(7)if O>>t&1);ret=[]
 if check(s,ord):ret=['exterior']
 else:
  for a in range(b+1):
   ret.append(run(s,ord,k,a,800,w=w,retain=True))
   if ret[-1]is not False:break
 print(i,c,O,len(rows),sum(len(ids)for w,ids in rows),ret,flush=True)
