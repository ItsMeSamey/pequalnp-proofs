from geometry import *
from core import library
from itertools import combinations
for c in library:
 if c not in (129,354,523,1046,2092,4160):continue
 pins=[alln,pack(lambda n:bool(n&(1<<library[c])))]
 fail=[(h,u,v)for h,cs in enumerate(pins)for u in range(7)for v in range(7)if u!=v and not(cs&on[u]&meet[v])]
 print(c,fail)
