from rawregional import *
import ast
from collections import defaultdict
jobs=defaultdict(list)
for key,(ids,roles) in json.loads(Path('upgraded.json').read_text()).items():
 g,c,w=ast.literal_eval(key)
 for O,b in roles:
  if O==127:continue
  jobs[O,len(c)].append((key,c,dict(w),ids))
def body(O,block):
 C=tuple(sorted(set().union(*(set(q[1])for q in block))))
 w={p:min(q[2].get(p,1)for q in block) for p in block[0][2] if all(p in q[2]for q in block)}
 k=max(13-len(q[1])for q in block);s=Source(0);s.bank(C)
 _,M,_,_=s.roles(O,k);b=k-(7-O.bit_count())-len(set(M)|set(w))-sum(n-2 for n in w.values())
 ret=[]
 for a in range(b+1):
  ret.append(run(s,tuple(t for t in range(7)if O>>t&1),k,a,300,w=w))
  if ret[-1]is not False:break
 return ret
priority=sorted(jobs,key=lambda i:-sum(len(x[-1])for x in jobs[i]))
for pos in range(int(sys.argv[1]),min(len(jobs),int(sys.argv[2]))):
 O,d=priority[pos];block=jobs[O,d];ret=body(O,block);print(pos,O,d,len(block),sum(len(x[-1])for x in block),ret,flush=True)
