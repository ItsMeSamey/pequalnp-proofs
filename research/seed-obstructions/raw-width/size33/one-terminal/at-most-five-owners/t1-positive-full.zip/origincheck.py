from collections import Counter,defaultdict
from ast import literal_eval
from pathlib import Path
import gzip,json
expected=defaultdict(list)
for i,line in enumerate(gzip.open('terminal-raw-keys.jsonl.gz','rt')):
 t,E,r,C,idx,d,g,closed=json.loads(line)
 if t!=1 or closed or g!=28 or 0 in d:continue
 assert r==8191^sum(E)
 count=Counter((1,4,64,128,256,512,1024,2048,4096));count.update(d)
 c=tuple(sorted(q for q in count if q.bit_count()>1))
 w=tuple(sorted((q,n)for q,n in count.items()if n>1));expected[c,w].append(i)
actual={(c,w):ids for c,w,ids in literal_eval(Path('allkeys.txt').read_text())}
assert expected==actual and sum(map(len,actual.values()))==5976 and len(actual)==1327
print('5976 original ordinals verified in 1327 weighted banks')
