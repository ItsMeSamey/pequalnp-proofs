from flex import *
from functools import cache
import spec_ext_two as spec_ext
spec_orig=spec_ext
nc=0
@cache
def fit2(c,om,named,raw,ext,H2,H1=(),sp=0):
 global nc
 assert not c
 s=Source(0);s.bank(c);O=tuple(u for u in range(7)if om>>u&1);S=127^om
 F={p:(s.F[p]&s.on[s.inc[p]&S]&s.Ehits[om] if ext else s.F[p]) for p in s.phys}
 qs=[p for p in s.phys if p not in named]
 rr=tuple((j,p)for j,p in enumerate(named)if p in raw)
 B=[v for d in range(len(qs)+1 if ext else 2)for v in combinations(qs,d)if not any(F[p]&s.domq[q]or F[q]&s.domq[p]for q,p in combinations(v,2))]
 fun=spec_ext.actual if ext else spec_orig.actual
 for a in B:
  if any(F[q]&s.domq[p]for q in a for p in H1):continue
  for b in B:
   if (not H2 and not H1 and a>b)or set(a)&set(b)or any(F[p]&s.domq[q]for p in b for q in H2):continue
   z=(*named,*a,*b);gs=[(p,)for p in named]+[a or(-1,),b or(-2,)]
   up=[sum(1<<u for u in range(7)if S>>u&1 and not any(F[p]&s.tag[u]for p in v))for v in (a,b)]
   pr=[(p,1)for p in z];off=len(named)
   def walk(lo,hi,rev):
    global nc
    nc+=1
    if nc+__import__('flex').calls+__import__('branchsp').nc>950:raise TimeoutError
    edges=[(off+rev,off+1-rev)]
    if not fun((),pr,[[0]*off+lo],edges,gs,sp,[[0]*off+hi],ordinary=O,rawnodes=rr,special_high=union(s.domq[p]for p in H2),before_high=union(s.domq[p]for p in H1)):return False
    if lo==hi:return (a,b,lo,rev)
    j=max(range(2),key=lambda i:(hi[i]^lo[i]).bit_count());u=(lo[j]^hi[j])&-(lo[j]^hi[j]);uu=hi[:];uu[j]&=~u
    x=walk(lo,uu,rev)
    if x:return x
    ll=lo[:];ll[j]|=u
    return walk(ll,hi,rev)
   for r in range(2):
    x=walk([0,0],up,r)
    if x:return x
 return False
