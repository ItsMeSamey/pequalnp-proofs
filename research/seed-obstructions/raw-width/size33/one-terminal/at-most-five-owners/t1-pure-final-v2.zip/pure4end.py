from rawregional import *
import ast
s=Source(0);s.bank(())
allbanks=json.loads(Path('upgraded.json').read_text())
src=[(dict(ast.literal_eval(k)[2]),{om for om,b in v})for k,(_,v) in allbanks.items()if not ast.literal_eval(k)[1]]
for O,a in [(14,2),(14,3),(38,3),(42,3),(44,3)]:
 ds=[w for w,os in src if O in os];w={x:min(d[x]for d in ds) for x in ds[0]if all(x in d for d in ds)}
 oo=tuple(t for t in range(7)if O>>t&1)
 print(O,a,w,run(s,oo,13,a,10000,True,w),flush=True)
