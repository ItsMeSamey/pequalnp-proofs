from rawregional import *
import ast
from collections import defaultdict
tab=defaultdict(list)
for key,(ids,rows) in json.loads(Path('remaining.json').read_text()).items():
 _,c,w=ast.literal_eval(key);assert not c
 for O,b in rows:
  if O.bit_count()>=3:tab[O].append((dict(w),ids))
s=Source(0);s.bank(())
calls=0
for O,rows in sorted(tab.items(),key=lambda x:-sum(len(ids)for w,ids in x[1])):
 ws=[w for w,ids in rows];w={p:min(x[p]for x in ws)for p in ws[0]if all(p in x for x in ws)}
 o=tuple(t for t in range(7)if O>>t&1);_,M,_,_=s.roles(O,13);b=13-(7-len(o))-len(set(M)|set(w))-sum(n-2 for n in w.values())
 vals=[]
 for a in range(b+1):
  if calls==95:break
  vals.append(run(s,o,13,a,3000,w=w));calls+=1
  if vals[-1]is not False:break
 print(O,b,vals,calls,flush=True)
