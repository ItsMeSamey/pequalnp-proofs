from core import *
s=Source(0);s.bank(());O=6;U=(1,2);d,M,_,_=s.roles(O,13);T=[s.stars[u]for u in U]
assert set.union(*T)==set(M) and len(M)==5
assert all(d[p]>>u&1 for u,S in zip(U,T)for p in S)
assert all(s.no[q,p]or s.no_t[q,p]&O for q in M for p in M if p!=q)
for u,S in zip(U,T):
 for p in S:
  for q in set(M)-S:assert s.reject(u,(s.pp[p]&~p)|s.pp[q])
print('stars',T,'marks',M,'mutual-blocks all verified')
N=s.Ehits[O]
print('after high pins every mandatory point-only baseline dark',all(N&s.domq[p]&s.meet[v]for p in s.phys for v in range(7)if not O>>v&1))
print('foreign dark',all(N&s.tag[u]&s.meet[v] for u in range(7)for v in range(7)if u!=v and not O>>u&1 and not O>>v&1))
