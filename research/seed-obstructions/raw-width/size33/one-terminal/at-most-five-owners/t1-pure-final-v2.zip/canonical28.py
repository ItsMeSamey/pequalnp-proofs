from ast import literal_eval
from itertools import combinations
from pathlib import Path
import gzip,json
t=json.loads(Path('upgraded.json').read_text())
unweighted={literal_eval(k)[1]:v[0]for k,v in t.items()if literal_eval(k)[2]==()}
A=(129,354,523,1046,2092,4160)
assert set(unweighted)=={c for n in range(5)for c in combinations(A,n)}
rows=[]
for i,line in enumerate(gzip.open('terminal-raw-keys.jsonl.gz','rt')):
 t,e,r,co,idx,alias,g,old=json.loads(line)
 if t==1 and g==28 and 0 in alias:
  c=tuple(x for x in A if x in alias)
  assert all(d in unweighted for n in range(len(c)+1)for d in combinations(c,n))
  rows.append(i)
assert len(rows)==24
print('unweighted width profiles',len(unweighted),'additional inert original IDs',rows)
