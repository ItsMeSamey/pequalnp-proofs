from resources import *
import ast,sys
from exterior import check
from staged import select
from collections import defaultdict
src=select('pure-five');j=defaultdict(list)
for key,(ids,rs)in src.items():
 _,c,w=ast.literal_eval(key)
 if c:continue
 for O,b in rs:
  if O.bit_count()==2:j[c,O].append((dict(w),ids))
for i,((c,O),rows) in enumerate(sorted(j.items())):
 if not int(sys.argv[1])<=i<int(sys.argv[2]):continue
 ws=[w for w,ids in rows];w={p:min(d[p]for d in ws)for p in ws[0]if all(p in d for d in ws)}
 s=Source(0);s.bank(c);oo=tuple(t for t in range(7)if O>>t&1);_,M,_,_=s.roles(O,13);b=13-5-len(set(M)|set(w))-sum(n-2 for n in w.values())
 retain=not check(s,oo);print("retain",i,O,retain,flush=True)
 for an in range(b+1):
  ret=run(s,oo,13,an,500,retain,w);print(i,c,O,an,ret,flush=True)
