from pathlib import Path
from ast import literal_eval as ev
from itertools import combinations
def rows(f):return Path(f).read_text().splitlines()
actions=[ev(s[:s.index(')')+1])for s in rows('equiv.log')if s.startswith('(')]
assert len(actions)==24
def orbit(m):return {sum(1<<a[u] for u in range(7)if m>>u&1)for a in actions}
assert {m for i in (3,17,6)for m in orbit(i)}=={sum(1<<v for v in o)for o in combinations(range(7),2)}
assert [len(orbit(i))for i in (3,17,6)]==[12,3,6] and 36 in orbit(6)
r4=set()
for line in rows('purehigher.log'):
 O,b,body=line.split(' ',2);v=ev(body.rsplit(' ',1)[0])
 if len(v)!=int(b)+1 or not all(a is False for a in v):r4.add(int(O))
assert r4=={13,14,38,42,44}
limited={}
for line in rows('pure4.log'):
 i,c,o,a,v=line.split(' ',4);t,p=ev(v);assert p==[((),0)]
 if t is not False:limited[int(o),int(a)]=t
fixed={(int(o),int(a))for o,a,w,v in (s.split()for s in rows('pure4end.log'))if v=='False'}
assert set(limited)==fixed
for o in r4:
 assert any('() '+str(o)+' ' in line and 'exterior'not in line for line in rows('smallretain-0.log'))
for line in rows('pure5-exact-primary.log'):
 assert ev(line.split(' ',4)[4].rsplit(' ',1)[0])==[]
q=[s for s in rows('purefinal.log') if ' False 'not in s]
assert len(rows('purefinal.log'))==13 and q==['6 3 (128, 256, 512, 1024, 2048) 1 0 True 15']
assert len(rows('fiveproper.log'))==64 and len([s for s in rows('fiveproper.log') if ' False ' not in s])==1
assert rows('bothhigh.log')==['False () False','True () False','False (128, 256, 512, 1024, 2048) co']
assert rows('postco.log')[-2:]==['(None, None, None, None) False','calls 1']
print('three signed pair orbits verified; one maximal candidate before the joint private clamp, neither final resource branch feasible')
