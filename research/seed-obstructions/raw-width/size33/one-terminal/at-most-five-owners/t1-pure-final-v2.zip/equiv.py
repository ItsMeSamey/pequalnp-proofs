from core import *
from itertools import permutations
s=Source(0);s.bank(())
P=set((p,1<<u)for p in s.phys for u in range(7)if s.inc[p]>>u&1)
N0={(n,l)for n,l in s.ns}
N={(n,l)for n,l in N0 if not any((n,l)!=(m,k) and not n&~m and not l&~k for m,k in N0)}
lookup={m:p for p,m in s.inc.items()}
land=set();order=0
for action in permutations(range(7)):
 if any(len(s.stars[j])!=len(s.stars[v])for j,v in enumerate(action)):continue
 def line(x):return sum(1<<v for j,v in enumerate(action)if x>>j&1)
 pts={p:lookup.get(line(m))for p,m in s.inc.items()}
 if None in pts.values():continue
 def apply(rows):return {(sum(v for p,v in pts.items()if p&n),line(l))for n,l in rows}
 if apply(N)!=N:continue
 assert apply(P)==P
 order+=1;land.add(tuple(sorted(action[j]for j in (1,2))))
 print(action,pts)
print('signed pure point quotient',len(P),len(N),'automorphisms',order,'ordinary pairs',sorted(land))
