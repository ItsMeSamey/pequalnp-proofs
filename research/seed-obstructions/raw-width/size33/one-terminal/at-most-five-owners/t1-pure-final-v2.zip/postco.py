from core import *
from sliced2 import actual
from itertools import product
s=Source(0);s.bank(());O=6;ordinary=(1,2)
for n in (6,):
 N=s.Ehits[O];_,z,_,_=s.roles(O,13)
 F={p:N&s.F[p]&s.on[s.inc[p]&~O]for p in s.phys}
 assert all(N&s.domq[q]&s.meet[u]for q in s.phys for u in range(7)if not O>>u&1)
 P=[q for q in s.phys if q not in z]
 options=[[None,*[q for q in z if not(F[q]&s.domq[p]or F[p]&s.domq[q])]]for p in P]
 print('slots',dict(zip(P,options)),flush=True);calls=0
 for shape in product(*options):
  g=[(q,)+tuple(p for p,home in zip(P,shape)if home==q)for q in z]
  if any(F[p]&s.domq[q]or F[q]&s.domq[p]for v in g for p,q in combinations(v,2)):continue
  active=[(p,1)for v in g for p in v]
  hi=[sum(1<<u for u in range(7)if not O>>u&1 and not any(F[p]&s.tag[u]for p in v))for v in g]
  calls+=1
  if calls>400:break
  pos=actual((),active,[[0]*len(g)],(),g,0,[hi],ordinary=ordinary,keep=N)
  print(shape,pos,flush=True)
 print('calls',calls,flush=True)
