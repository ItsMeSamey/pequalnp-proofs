from core import *
import branchsp,flex
Z=(128,256,512,1024,2048)
for a in (0,1):
 for n in range(len(Z)+1):
  for rr in combinations(Z,n):
   if a:v=branchsp.chk((),6,rr,(),(),True,(),0)
   else:v=flex.signed((),6,rr,(),(),0,False)
   print(a,rr,v,branchsp.nc+flex.calls,flush=True)
