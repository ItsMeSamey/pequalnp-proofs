from flex900 import signed
import flex900 as flex
from ast import literal_eval
from pathlib import Path
import sys
for path in sys.argv[1:]:
 for ln in Path(path).read_text().splitlines():
  i,c,O,an,rest=ln.split(' ',4);c=literal_eval(c);O=int(O)
  val,ps=literal_eval(rest)
  if val is not False:print(i,c,O,an,'partial',flush=True);continue
  normalized={(tuple(sorted(p for p in rr if p>0)),sum(p<0 for p in rr),ex)for rr,ex in ps}
  maximal=[(r,a,e)for r,a,e in sorted(normalized)if not any((set(r)<set(rr) or a<aa or e<ee)and set(r)<=set(rr)and a<=aa and e<=ee for rr,aa,ee in normalized)]
  keep=[]
  try:
   for r,a,ex in maximal:
    v=signed(c,O,r,(),(),ex,bool(a))if a<=1 else True
    if v:keep.append((r,a,ex))
  except TimeoutError:sys.exit(0)
  print(i,c,O,an,keep,flex.calls,flush=True)
