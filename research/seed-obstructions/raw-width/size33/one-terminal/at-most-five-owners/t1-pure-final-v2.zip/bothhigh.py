from twopost import *
O=6
_,M,_,_=sc.roles(O,13);N=sc.Ehits[O]
for X,z in ((False,()),(True,()),(False,M)):
 print(X,z,check(O,tuple(z),(),N,X,0),flush=True)
