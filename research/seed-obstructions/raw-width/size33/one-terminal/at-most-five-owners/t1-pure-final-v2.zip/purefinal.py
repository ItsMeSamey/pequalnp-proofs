import branchsp,px2
from core import *
from ast import literal_eval
s=Source(0);s.bank(())
for line in Path('pure5-cost.log').read_text().splitlines():
 i,c,o,a,x=line.split(' ',4);O=int(o);an=int(a)
 if (O,an)not in ((6,3),(36,2)):continue
 gs=literal_eval(x.rsplit(' ',1)[0])
 for z,k,ex in gs:
  ok=all(s.F[p]&s.tag[v]for p in z for v in range(7)if not O>>v&1)
  foreign=all(s.meet[h]&s.tag[v]for h in range(7)for v in range(7)if h!=v)
  if not foreign or k==2 and not ok:res='unlicensed'
  else:
   try:
    if k==1:res=bool(branchsp.chk((),O,z,(),(),True,(),ex))
    else:res=bool(px2.fit2((),O,z,(),True,(),(),ex))
   except TimeoutError:raise SystemExit
  print(O,an,z,k,ex,res,px2.nc+branchsp.nc,flush=True)
