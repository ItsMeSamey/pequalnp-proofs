from core import *
def setup(s,c):
 w=tuple(1<<library[m]for m in c);hs=[s.dom(sum(x for j,x in enumerate(w)if h>>j&1))for h in range(1<<len(w))];top=hs[-1]
 up={p:sum(v for v,t in zip(TAGS,s.tag)if not s.F[p]&top&t)for p in s.phys}
 bad=[];free={p:0 for p in s.phys}
 for p,q in combinations(s.phys,2):
  a=up[p]&up[q]
  sep=any(top&s.dom(y)&s.tag[u]for x,y in ((p,q),(q,p))for u in range(7)if(s.inc[x]&~s.inc[y]&~a)>>u&1)
  pair=bool(top&s.on[s.inc[p]&~a]&s.on[s.inc[q]&~a])
  if not(sep and pair and (top&s.F[p]&s.dom(q) or top&s.F[q]&s.dom(p))):bad.append((p,q))
 for p in s.phys:
  if not all(top&s.dom(p)&v for v in s.meet):continue
  for h,N in enumerate(hs):
   if any(s.pp[p]&x and not h>>j&1 for j,x in enumerate(w)):continue
   for u in range(7):
    if s.inc[p]>>u&1 and N&s.tag[u]&s.on[s.inc[p]] and all(N&s.tag[u]&s.meet[v]for v in range(7)if v!=u):free[p]|=1<<u
 return top,up,bad,free
def check(s,O,M,b,pre):
 top,up,bad,free=pre
 pp=[p for p in s.phys if p not in M and all(s.F[p]&s.domq[q]or s.F[q]&top&s.dom(p)for q in M)]
 for V in range(127,0,-1):
  if any(up[q]&V for q in M):continue
  K=sum(p for p in pp if not up[p]&V and free[p]&V==s.inc[p]&V and s.inc[p]&V);ks={K}
  for p,q in bad:ks={m for k in ks for m in ((k^p,k^q)if k&p and k&q else(k,))}
  for k in ks:
   ps=[p for p in pp if p&k];ok=False
   for d in range(b+1):
    for zz in combinations(ps,d):
     pts=set(ps)-set(zz);ex=b-d
     de=[max(0,len(pts&T)-(1 if O>>u&1 else 2))if V>>u&1 else 0 for u,T in enumerate(s.stars)]
     if sum(de)<=ex:ok=True;break
     gain=[0]
     for j in range(1,ex+1):
      g=max([0]+[sum(min(ds,max(0,len(set(C)&T)-1))for ds,T in zip(de,s.stars))for C in combinations(pts,min(len(pts),j+1))])
      gain.append(max([g,1+gain[-1]]+[gain[v]+gain[j-v]for v in range(1,j)]))
     if gain[-1]>=sum(de):ok=True;break
    if ok:break
   if not ok:return V,k
if __name__=='__main__':
 from ast import literal_eval
 for rem in map(int,sys.argv[1:]):
  s=Source(rem);key=None;r=Counter();keep=[]
  for n,c,o,O,b in literal_eval(Path(f'postsplice-{rem}.txt').read_text()):
   if key!=(c,o):s.bank(c,o);pre=setup(s,c);key=c,o
   d,M,so,b=s.roles(O,31-n);hit=check(s,O,M,b,pre);r[n,bool(hit)]+=1
   if not hit:keep.append((n,c,o,O,b))
  print(rem,r,flush=True);Path(f'postbins-{rem}.txt').write_text(repr(keep))
