from cuts import *
cc=(129,354,523,1046,2092,4160)
P,N=load(tuple(DEGREE_ONE)); raw=(1<<20)-1
r=8191^sum(DEGREE_ONE)
def make(C):
 H=sum(1<<extra[x] for x in C)
 neg=sorted({n&raw for n in N if n&H==H})
 ps=sorted({p&raw for p in P})
 return ps,neg
def compute(C):
 ps,neg=make(C)
 missing=[(p,u) for p in bm(r) for u in range(7) if (p|(1<<(13+u))) not in ps and not any(n&p and n>>(13+u)&1 for n in neg)]
 ess=sum(1 for b in bm(raw&~sum(DEGREE_ONE)) if any(p&~n==b for p in ps for n in neg))
 geo=[(p,q) for p,q in combinations(bm(r),2) if not any(n&p and n&q for n in neg)]
 zz=[(u,v) for u,v in combinations(range(7),2) if not any(n>>(13+u)&1 and n>>(13+v)&1 for n in neg)]
 print(C,'N',len(neg),'ess',ess,'cells',missing,'barepoints',geo,'barelines',zz,flush=True)
if __name__=='__main__':
 for C in combinations(cc,2):compute(C)
