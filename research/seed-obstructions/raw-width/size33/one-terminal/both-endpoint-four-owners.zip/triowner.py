from endpoint_core import Source
from geometry import make
from rawregional import run as normal
from dualroute import run as bright
s=Source(0);_,s.N=make((129,4160));s.bank((),0)
def terms(mask):return tuple(i for i in range(7) if mask>>i&1)
def search(full,B):
 DD={};EE={};PRE={};M=set()
 for o in range(1,128):
  if o&~full:continue
  if B:
   base=s.Ehits[o]&(s.domq[B[0]] if len(B)==1 else s.domq[4]|s.domq[1024])
   ex={p:base&~s.domq[p]&(s.full if p in s.stars[2] else s.on[s.inc[p]&~o]) for p in s.phys}
  else:ex={p:s.F[p]&s.on[s.inc[p]&~o]&s.Ehits[o] for p in s.phys}
  PRE[o]={p:s.F[p]&s.on[s.inc[p]&~o]&s.Ehits[o] for p in s.phys}
  d={p:(s.pr[p]&o)|(128 if ex[p] or PRE[o][p] else 0) for p in s.phys}
  M.update(p for p in s.phys if d[p].bit_count()>=2);DD[o]=d;EE[o]=ex
 M=tuple(sorted(M));base=11-(7-full.bit_count()-bool(B))-len(M)
 print('M',full,B,M,base,flush=True)
 cells={(a,D) for a in range(base+1) for D in ([None]if not B else [p for p in B if p in M and all(p==q or not(s.no[p,q] or s.no_t[p,q]&full) for q in B)]+[-j-1 for j in range(a)])}
 for o in sorted(DD,key=lambda j: -sum(d.bit_count() for d in DD[j].values())):
  if not cells:break
  s.roles=lambda O,k:(DD[o],M,(),base);s.ext2=EE[o];s.pre_ext=PRE[o]
  for a,D in tuple(cells):
   k=11+(full.bit_count()-o.bit_count())+bool(B)
   v=bright(s,terms(o),k,a,800,chosen=D,bright=B) if B else normal(s,terms(o),k,a,800)
   if v is False:cells.remove((a,D));print('CUT',full,B,o,a,D,flush=True)
 print('END',full,B,cells,flush=True)
if __name__=='__main__':
 import sys
 for f in map(int,sys.argv[1:]):
  assert f.bit_count()==4
  for B in ([()] if f&4 else [(4,),(1024,),(4,1024)]):
   search(f,B)
