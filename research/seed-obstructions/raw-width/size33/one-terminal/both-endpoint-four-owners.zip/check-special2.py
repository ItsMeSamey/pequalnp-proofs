from pathlib import Path
from ast import literal_eval as ev
s=Path('special2.log').read_text().splitlines()
assert s[-1]=='EXIT 0'
got=set()
for l in s[1:-1]:
 pre,tail=l.rsplit(')',1)
 a,d,v=tail.split()
 assert v=='False'
 got.add((ev(pre[5:]+')'),int(a),int(d)))
expected=set()
for B in [(4,),(1024,),(4,1024)]:
 for a in range(3):
  for d in ([*B] if len(B)==1 else [])+[-1-i for i in range(a)]:expected.add((B,a,d))
assert got==expected and len(got)==15
for f in ('endpoint-routes.log','endpoint-ifzero-routes.log'):
 x={int(l.split()[0]) for l in Path(f).read_text().splitlines()if 'True' in l or 'not-routed' in l}
 assert all(i.bit_count()<6 for i in x)
print('PASS 15/15 positive-D2 cells and complete r0/r1 ledger')
