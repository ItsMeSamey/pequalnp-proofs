from ast import literal_eval as ev
from pathlib import Path
def rows(path):
 a=Path(path).read_text().splitlines();assert a[-1]=='EXIT 0';return a[:-1]
def opened(k):
 low=Path('endpoint-'+k+'low.log').read_text().splitlines()
 rt=rows('endpoint-'+k+'routes.log');s={int(l.split()[0])for l in low if l.endswith(' open')}
 for l in rt:
  if l.endswith(']') and set(ev(l[l.index('['):]))=={False}:s.remove(int(l.split()[0]))
 return {i for i in s if i.bit_count()==4}
assert opened('')=={30,46} and opened('ifzero-')==set()
masks={m for m in range(128)if m.bit_count()==4};needed={30,46}|{m for m in masks if not m&4}
assert len(masks)==35 and len(needed)==17
for m in needed:
 bs=[()] if m&4 else [(4,),(1024,),(4,1024)];l=rows(f'tri-{m}.log')
 assert [x for x in l if x.startswith('END ')]==[f'END {m} {b} set()' for b in bs]
print('PASS 35/35 current three-owner choices, 17 completed shards, 47 empty residual sets')
