from endpoint_core import Source
from geometry import make
from rawregional import run
from pathlib import Path
s=Source(0);_,s.N=make((129,4160));s.bank((),0)
for l in Path('endpoint-ifzero-low.log').read_text().splitlines():
 if not l.endswith(' open'):continue
 o,r,_=l.split();o=int(o);O=tuple(j for j in range(7) if o>>j&1)
 _,M,_,b=s.roles(o,11)
 if len(O)<2:print(o,'not-routed',flush=True);continue
 ans=[]
 for k in range(b+1):
  ans.append(run(s,O,11,k,800))
  if ans[-1] is True:break
 print(o,b,ans,flush=True)
