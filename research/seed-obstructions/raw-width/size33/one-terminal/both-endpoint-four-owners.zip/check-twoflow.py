from pathlib import Path
from ast import literal_eval as ev
def rows(p):
 l=Path(p).read_text().splitlines()
 assert l[-1]=='EXIT 0'
 return l[:-1]
b=rows('bypass2.log')
assert {int(l.split()[1]) for l in b if l.startswith('END ')and l.endswith(' CLOSED')}=={122,121,115,91,59}
s=rows('subset2.log')
for t in ['END 62 () set()','END 107 (4,) set()','END 107 (4, 1024) set()']:assert t in s
d=rows('dual107.log');assert d[-1]=='END 107 (1024,) set()'
assert {l.split(') ')[1]for l in d if l.startswith('CUT ')}=={'107 1 1024','107 0 1024','107 1 -1'}
base={int(l.split()[0])for l in rows('endpoint-routes.log')if 'True' in l or 'not-routed'in l}
low={int(l.split()[0])for l in rows('endpoint-ifzero-routes.log')if 'True' in l or 'not-routed'in l}
assert {o for o in base if o.bit_count()==5}=={62}
assert not {o for o in low if o.bit_count()==5}
print('PASS two current owners, all 21 tag-owner choices and all D2 brightness branches')
