from core import *
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
from itertools import combinations,permutations
def run(s,O,k,an,limit=1000,retain=False,w=None,chosen=None,bright=()):
 om=sum(1<<t for t in O)
 dm,M,_,b=s.roles(om,k);w=w or {}
 M=tuple(sorted(set(M)|{p for p in w if p in s.phys}))
 forced={p:p for p in w if p in s.phys}
 for j,d in enumerate(p for p in w if p not in s.phys):forced[-an-j-1]=d
 anon=tuple(-j-1 for j in range(an))+tuple(x for x in forced if x<0)
 cash=k-(7-len(O))-len(M)-len(anon)
 if cash<0:return False
 qs=s.phys
 M=tuple(M);nodes=tuple((*M,*anon));vs=IDPool();v=vs.id
 with Solver(name='cadical195')as solver:
  add=solver.add_clause
  def OR(*l):
   t=v(('or',*l))
   add([-t,*l])
   for x in l:add([-x,t])
   return t
  def AND(*l):return -OR(*[-x for x in l])
  def cap(xs,k):
   if len(xs)>k:solver.append_formula(CardEnc.atmost(xs,k,vpool=vs).clauses)
  def edge(x,y):return v(('edge',x,y))
  def prec(x,y):return v(('before',x,y))if x<y else -v(('before',y,x))
  def hi(x,q):return v(('hi',x,q))
  def sink(x,t):return v(('sink',x,t))
  assert chosen in nodes
  for q in qs:add([hi(chosen,q) if q in bright else -hi(chosen,q)])
  for x,y in permutations(nodes,2):add([-edge(x,y),prec(x,y)])
  for x,y,z in permutations(nodes,3):add([-prec(x,y),-prec(y,z),prec(x,z)])
  for j in range(an-1):add([prec(-j-1,-j-2)])
  for x,d in forced.items():
   for y in nodes:
    if y!=x:add([-edge(y,x)])
   for q in qs:
    # Composite raw bits can also be high on peeled points. Only surviving positives matter here.
    active=bool(q&d)
    add([hi(x,q) if active else -hi(x,q)])
  for x in M:
   add([hi(x,x)])
   for q in qs:
    if q!=x and (s.no[x,q] or s.no_t[x,q]&om):add([-hi(x,q)])
  S=tuple(O)+('ext',);extra=v('mandatory_extra')
  over=[extra]
  if cash==0:add([-extra])
  witness=[]
  for x in nodes:
   pay=[v(('over',x,j))for j in range(cash)];over+=pay
   if x in forced:
    minimum=w[forced[x]]-2
    if minimum>cash:return False
    for a in pay[:minimum]:add([a])
   outs=[sink(x,t) for t in S]+[edge(x,y)for y in nodes if y!=x]
   pr=[(sink(x,'ext'),v(('live',x,'ext')))]
   add([pr[0][1]])
   for y in nodes:
    if x!=y:pr.append((edge(x,y),v(('alive',y))))
   ac=[]
   for y,(ed,alive) in enumerate(pr):
    dup=v(('dup',x,y));add([-dup,ed]);outs.append(dup)
    ac.extend((AND(ed,alive),AND(dup,alive)))
   add([-v(('alive',x)),OR(*ac)])
   cap(outs+[-s for s in pay],2+cash)
   witness.extend(AND(a,b)for a,b in combinations(ac,2))
  cap(over,cash)
  if retain:add([extra,*witness])
  def route(p,n,t,ispriv):
   avail=[x for x in nodes if x==p or x<0 or (not n&x and (not ispriv or not (s.no[x,p] or s.no_t[x,p]&om)))]
   states={x:v(('walk',p,n,t,x))for x in avail};add([states[p]])
   for x in avail:
    a=states[x]
    if ispriv:add([-a,hi(x,p)])
    for q in qs:
     if n&q:add([-a,-hi(x,q)])
    if x==p:continue
    add([-a,*[AND(states[y],edge(y,x))for y in avail if y!=x]])
   add([AND(a,sink(x,t))for x,a in states.items()])
  for p in M:
   for t in O:
    if not dm[p]>>t&1:continue
    away=[q for q in qs if q not in s.stars[t]]
    masks=[]
    for n in range(len(away),-1,-1):
     for a in combinations(away,n):
      qmask=sum(a)
      if any(not qmask&~j for j in masks):continue
      x=(s.pp[p]&~p)|union(s.pp[q]for q in a)
      if s.reject(t,x):masks.append(qmask);route(p,qmask,t,True)
  solver.conf_budget(limit)
  return solver.solve_limited()
if __name__=='__main__':
 from ast import literal_eval
 for n,c,omit,om,b in literal_eval(Path('postbins-0.txt').read_text()):
  if om.bit_count()<2:continue
  s=Source(0);s.bank(c)
  O=tuple(t for t in range(7)if om>>t&1)
  print(c,O,[run(s,O,32-n,j,800)for j in range(b+1)],flush=True)
