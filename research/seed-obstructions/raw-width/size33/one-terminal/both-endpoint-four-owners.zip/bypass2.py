from endpoint_core import Source
from geometry import make
from bypassroute import run
s=Source(0);_,s.N=make((129,4160));s.bank((),0)
def roles(O,k):
 d={p:(s.pr[p]&O)|(128 if s.ext2[p] else 0) for p in s.phys}
 M=tuple(p for p in s.phys if d[p].bit_count()>=2)
 return d,M,(),k-(7-O.bit_count())-len(M)
s.roles=roles
for v in (0,1,3,4,5,6):
 o=123^(1<<v);O=tuple(i for i in range(7)if o>>i&1);unresolved=False
 for B in ((4,),(1024,),(4,1024)):
  base=s.Ehits[o]&(s.domq[B[0]] if len(B)==1 else s.domq[4]|s.domq[1024])
  s.ext2={p:base&~s.domq[p]&(s.full if p in s.stars[2]else s.tag[v] if p in s.stars[v]else 0) for p in s.phys}
  d,M,_,b=roles(o,12)
  print('B',o,B,len(M),b,flush=True)
  for an in range(b+1):
   for D in (*M,*(-1-i for i in range(an))):
    if D>0 and (D not in B or any(D!=p and (s.no[D,p]or s.no_t[D,p]&o)for p in B)):continue
    ans=run(s,O,12,an,1000,chosen=D,bright=B)
    print('CELL',o,B,an,D,ans,flush=True)
    if ans is not False:unresolved=True;break
   if unresolved:break
  if unresolved:break
 print('END',o,'OPEN' if unresolved else 'CLOSED',flush=True)
