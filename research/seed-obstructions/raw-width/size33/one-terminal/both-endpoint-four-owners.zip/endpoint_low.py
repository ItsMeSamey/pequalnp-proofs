from geometry import make
from endpoint_core import Source,pass_budget
from splice import exterior_splice
from exterior import check as chk
from union_bins import check,setup
s=Source(0);_,s.N=make((129,4160));s.bank((),0)
assert s.badbase=={(4,2),(1024,2)}
W=setup(s,())
for O in range(1,128):
 if not O&4:continue
 d,M,solo,b=s.roles(O,11)
 stage='open'
 if not pass_budget(solo,b):stage='price'
 elif exterior_splice(s,O,11) and not chk(s,tuple(i for i in range(7) if O>>i&1)):stage='splice'
 elif check(s,O,M,b,W):stage='bins'
 print(O,7-O.bit_count(),stage,flush=True)
