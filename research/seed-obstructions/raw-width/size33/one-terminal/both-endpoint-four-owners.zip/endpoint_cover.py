from geometry import make,bm
from functools import cache
P,N=make((129,4160))
F=sorted({v for x in P for v in bm(x)})
def compress(x):return sum(1<<i for i,b in enumerate(F) if x&b)
P=list(map(compress,P));N=list(map(compress,N))
full=(1<<len(F))-1
neighbors={q:sum(p for p in bm(full) if not any(n&q and n&p for n in N)) for q in bm(full)}
common={0:full};best={}
for A in range(1,full+1):
 q=A&-A;nb=common[A^q]&neighbors[q];common[A]=nb;B=nb
 while B>A:
  m=sum(1<<i for i,x in enumerate(P) if x&A and x&B);c=A.bit_count()+B.bit_count()
  if m and (m not in best or c<best[m][0]):best[m]=(c,A,B)
  B=(B-1)&nb
opts=[(m,c,a,b) for m,(c,a,b) in best.items()]
uses=[[v for v in opts if v[0]>>i&1]for i in range(len(P))]
@cache
def cover(K,k):
 if not K:return ()
 if k<=0:return None
 rows=min((tuple(v for v in uses[i] if v[1]<=k) for i in range(len(P)) if K>>i&1),key=len)
 if not rows:return None
 for m,c,a,b in sorted(rows,key=lambda v:-(v[0]&K).bit_count()/v[1]):
  s=cover(K&~m,k-c)
  if s is not None:return ((a,b),)+s
 return None
T=cover((1<<len(P))-1,27)
print('patterns',len(opts),'states',cover.cache_info(),'terms',T,flush=True)
if T is not None:
 assert all(any(p&a and p&b for a,b in T) for p in P)
 assert not any(any(n&a and n&b for a,b in T) for n in N)
 print('cost',sum(a.bit_count()+b.bit_count() for a,b in T)-1,'raw',[[[F[i] for i in range(len(F)) if a>>i&1]for a in t]for t in T])
