from endpoint_core import Source
from geometry import make
from privateroute import run
s=Source(0);_,s.N=make((129,4160));s.bank((),0)
def roles(O,k):
 dm={p:s.pr[p]&O for p in s.phys};M=tuple(p for p in s.phys if dm[p].bit_count()>=2)
 return dm,M,(),k-(7-O.bit_count())-len(M)
s.roles=roles;om=123;O=tuple(i for i in range(7)if om>>i&1)
dm,M,_,b=roles(om,12);print('COST',dm,M,b,flush=True)
for B in ((4,),(1024,),(4,1024)):
 for an in range(b+1):
  for d in (*M,*(-1-i for i in range(an))):
   if d>0 and (d not in B or any(d!=p and (s.no[d,p]or s.no_t[d,p]&om)for p in B)):continue
   print('CELL',B,an,d,run(s,O,12,an,1600,chosen=d,bright=B),flush=True)
