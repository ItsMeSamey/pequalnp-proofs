from pathlib import Path
from ast import literal_eval as ev
def rows(p):
 a=Path(p).read_text().splitlines();assert a[-1]=='EXIT 0';return a[:-1]
def old(k):
 a={int(l.split()[0])for l in Path('endpoint-'+k+'low.log').read_text().splitlines()if l.endswith(' open')}
 for l in rows('endpoint-'+k+'routes.log'):
  if l.endswith(']') and set(ev(l[l.index('['):]))=={False}:a.remove(int(l.split()[0]))
 return {k for k in a if k.bit_count()==3}
assert old('')=={14}and old('ifzero-')==set()
masks={i for i in range(128)if i.bit_count()==3}
assert len(masks)==35
for o in {14}|{i for i in masks if not i&4}:
 bs=[()]if o&4 else[(4,),(1024,),(4,1024)]
 ls=[l for l in rows(f'four-{o}.log')if l.startswith('END')]
 assert len(ls)==len(bs)
 for l,b in zip(ls,bs):
  prefix=f'END {o} {b} ';assert l.startswith(prefix)
  if (o,b)in [(14,()),(42,(1024,))]:continue
  assert l==prefix+'set()'
assert rows('pooled4-14.log')[-1]=='END 14 () set()'
assert ev(rows('pooled4-42.log')[-1].split(') ',1)[1])=={(0,1024),(1,1024),(2,1024)}
assert rows('paidout42.log')[-1]=='END 42 (1024,) set()'
assert len([l for l in rows('paidout42.log') if l.startswith('CUT ')])==3
print('PASS 35/35 current four-owner choices incl all D2 supports')
