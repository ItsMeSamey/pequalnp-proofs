from ast import literal_eval
from pathlib import Path
import sys,json
from itertools import combinations
D=(129,354,523,1046,2092,4160)
i=int(sys.argv[1]);C=tuple(combinations(D,2))[i];endpoint,=set(C)&{129,4160}
O={1<<j for j in range(13)if endpoint>>j&1};P={1<<j for j in range(13)if 8133>>j&1};G=P-O
I={p:sum(1<<u for u,s in enumerate([708,1408,2816,5632,3137,6272,4357]) if p&s)for p in P}
T={f:{tuple(k):v for k,v in rows}for f,rows in json.loads(Path(f'top{i}.json').read_text())['witnesses'].items()}
def ok(f,*x):return T[f][tuple(x)] is not None
for p in P:
 for u in range(7):
  assert ok('owner_point',p,u)
  if not I[p]>>u&1:assert ok('nonincident',p,u)
  if p in G:assert ok('holder_tag',p,u)
 for q in P-{p}:
  assert ok('holder_foreign',p,q)
  if p in G or q in G:assert ok('pair_tags',*sorted((p,q))) and ok('pair_holder',*sorted((p,q)))
for u in range(7):
 for v in range(7):
  if u!=v:assert ok('owner_tag',u,v)
wits={}
for q in G:
 for p in P-{q}:
  s=next(u for u in range(7)if I[q]>>u&1 and not I[p]>>u&1 and ok('nonincident',p,u))
  wits[str((q,p))]=[s,T['nonincident'][p,s]]
Path(f'virtual{i}.json').write_text(json.dumps(wits))
rows=literal_eval(Path('allkeys.txt').read_text());openids=set(map(int,Path('remaining.ids').read_text().split()))
a={j for c,w,ids in rows if not set(c)&{129,4160} and len(c)==2 for j in ids}
b={j for c,w,ids in rows if len(set(c)&{129,4160})==1 and len(c)==2 for j in ids}
print(C,len(G),len(wits),'quartets',len(a&openids),'one-end',len(b&openids),'bothend',len(openids-b-a))
