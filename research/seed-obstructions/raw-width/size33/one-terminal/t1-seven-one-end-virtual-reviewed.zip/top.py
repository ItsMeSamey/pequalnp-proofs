from weighted import *
from sample import samples
from pathlib import Path
import sys,json
D=(129,354,523,1046,2092,4160);i=int(sys.argv[1]);C=tuple(combinations(D,2))[i]
raw,seed,target=samples(Path('L-meta-18968.json'))
proj=((1<<38)-1)^sum(DEGREE_ONE) if 'DEGREE_ONE'in globals() else ((1<<38)-1)^58
physical={x&proj:k for k,x in enumerate(raw)if not target>>k&1}
N=[x for x in N if x in physical]
def pack(f):return sum(1<<i for i,n in enumerate(N)if f(n))
on=[pack(lambda n:n>>(13+j)&1)for j in range(7)]
pt={p:pack(lambda n:n&p)for p in pts};meet=[pack(lambda n:n&s)for s in stars]
line=lambda m:union(on[j]for j in range(7)if m>>j&1)
h=pack(lambda n:all(n>>extra[c]&1 for c in C))
F={p:h&~pt[p]&line(inc[p]) for p in pts}
tests={
 'holder_tag':{(p,u):F[p]&on[u]for p in pts for u in range(7)},
 'owner_point':{(p,u):h&pt[p]&meet[u]for p in pts for u in range(7)},
 'owner_tag':{(u,v):h&on[u]&meet[v]for u in range(7) for v in range(7)if u!=v},
 'nonincident':{(p,u):h&pt[p]&on[u]for p in pts for u in range(7)if not inc[p]>>u&1},
 'holder_foreign':{(p,q):F[q]&pt[p]for p in pts for q in pts if p!=q},
 'pair_tags':{(p,q):h&line(inc[p])&line(inc[q])for p,q in combinations(pts,2)},
 'pair_holder':{(p,q):F[p]&pt[q]|F[q]&pt[p]for p,q in combinations(pts,2)}
}
wits={k:[(x,physical[N[(v&-v).bit_length()-1]] if v else None)for x,v in t.items()]for k,t in tests.items()}
out=Path(f'top{i}.json');out.write_text(json.dumps(dict(C=C,witnesses=wits)))
full=any(set(H)==set(C)and v==127 and K==8133 for H,v,K in cuts(P,N,8133,C))
bad={k:[x for x,v in t.items()if not v]for k,t in tests.items()if not all(t.values())}
print(C,'toprows',h.bit_count(),'full',full,'absences',bad,flush=True)
