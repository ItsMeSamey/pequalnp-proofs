import sys,zipfile,ast,json
from collections import Counter
from pathlib import Path
here=Path(__file__).parent
z=zipfile.ZipFile(sys.argv[1])
openids=set(map(int,z.read('both-open.ids').split()))
nong=set()
for f in z.namelist():
 if not f.startswith('rr') or not f.endswith('.log'): continue
 for line in z.read(f).decode().splitlines():
  if line.startswith('('):
   i,w,ids,n,R=ast.literal_eval(line)
   if R and all(g>0 for _,g,_,_ in R):nong.update(ids)
s={}
for f in ('purethree.log','generalpure.log'):
 for l in (here/f).read_text().splitlines():
  if l.startswith('COUNTS'):continue
  i,r=l.split(maxsplit=1);s[int(i)]=r.split(',')[0]
d={}
for i in sorted(openids & set(s)):
 r=s[i];d[i]='mixed-direct' if r=='excluded' else 'mixed-g0' if r in ("('open'","('small'") and i in nong else 'open'
assert Counter(d.values())=={'mixed-direct':78,'mixed-g0':53,'open':25}
print(len(openids),len(nong),Counter(d.values()))
(here/'join-open.json').write_text(json.dumps(d,sort_keys=True)+'\n')
