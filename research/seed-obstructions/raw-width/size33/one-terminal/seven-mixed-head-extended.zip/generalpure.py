import gzip,json,sys
from functools import cache,reduce
from itertools import combinations,product
from operator import or_
from collections import Counter
from cuts import DEGREE_ONE,load,extra
samples=cache(load)
@cache
def test(e,raw,C):
 P,N=samples(e);pm=raw|sum(1<<extra[c]for c in C);mask=pm|127<<13;pt={p&8191:p for p in P}
 Q=tuple(q for q in DEGREE_ONE if q not in e and raw&q)
 @cache
 def swap(a,b):
  return any(n&b==b and not n&a and not (p&mask&~a)&~n for p in P if p&a for n in N)
 V={}
 for q in Q:
  rq=pt[q]&mask&~q;W=[n for n in N if not n&q and not rq&~n]
  V[q]={a for a,p in pt.items() if a!=q and not any(not (p&pm&~q)&~n for n in W)}
  if V[q]&set(Q):return 'other-head'
  if any(not raw&a or not swap(a,q) for a in V[q]):return 'native'
  if any(not swap(a,b) for a in V[q] for b in V[q] if a!=b):return 'pair-swap'
  if any((c&sum(pt)).bit_count()==2 and not (c&sum(pt))&~sum(V[q]) for c in C):return 'raw-pair'
  for A in combinations(V[q],3):
   if any(not any(not (pt[a]&pm&~a)&~n for n in W)for a in A):return 'large'
 for n in (1,2):
  for pool in combinations(sorted(set.union(*V.values())),n):
   opts=[]
   for q in Q:
    u=sorted(V[q]&set(pool));opts.append([*[(x,)for x in u],*list(combinations(u,2))])
   for A in product(*opts):
    forks=Counter(x for x in A if len(x)==2);price=sum(k-1 for k in forks.values())
    for a in pool:
     opp=[q for q,x in zip(Q,A)if x==(a,)]+[next(x for x in pair if x!=a)for pair in forks if a in pair]
     if opp:price+=max(1,len(opp)-1+swap(a,reduce(or_,opp)))
    if price<=2:return ('open',Q,A,price)
 return 'excluded'
old={int(s.split()[0])for s in open(sys.argv[2])if s.endswith('nonlocal\n')};d=Counter()
for i,l in enumerate(gzip.open(sys.argv[1],'rt')):
 if i not in old:continue
 t,e,r,C,*_=json.loads(l);a=test(tuple(e),r,tuple(C));print(i,a);d[a if isinstance(a,str)else a[0]]+=1
print('COUNTS',d)
