from original import *
from cuts import DEGREE_ONE
from core import union,cache
class Child(Source):
 def __init__(self,j,t=None):
  from sample import samples
  rr,seed,target=samples(__import__("pathlib").Path("L-meta-18968.json"));P=[x for i,x in enumerate(rr) if (target&~seed)>>i&1];N=[x for i,x in enumerate(rr)if not target>>i&1];C=banks[115];self.j=j;self.dummy=DEGREE_ONE[j];self.pts=self.phys=tuple(1<<i for i in range(13)if 1<<i not in DEGREE_ONE);self.effective=tuple(v for v in range(7)if v!=self.dummy)
  O=sum(self.pts);L=sum(1<<(13+v)for v in self.effective)
  lift=lambda n: (n&(O|L))|sum(1<<extra[c]for c in C if n&c)
  self.P=tuple(sorted({lift(n)for n in P if n&O and n&L}))
  self.N=tuple(sorted({lift(n)for n in N if n&j}))
  if t is not None:
   cols=[a & ~(127<<13) for a in self.P if a>>(13+t)&1 and (a&8191)&int(__import__("os").environ.get("HITS","8191"))]
   self.N=tuple(n for n in self.N if any(x&~n==0 for x in cols))
  print("rows",j,len(self.P),len(self.N))
  self.stars=tuple({x&8191 for x in self.P if x>>(13+u)&1}for u in range(7))
  self.inc={p:sum(1<<u for u in self.effective if p in self.stars[u])for p in self.pts}
  self.pp={p:lift(p)for p in self.pts};self.full=(1<<len(self.N))-1;rows=lambda f:sum(1<<i for i,n in enumerate(self.N)if f(n))
  self.dom=cache(lambda m:rows(lambda n:n&m==m));self.domq={p:self.dom(a)for p,a in self.pp.items()}
  self.tag=[rows(lambda n:n>>(13+v)&1)for v in range(7)];self.meet=[union(self.domq[p]for p in T)for T in self.stars];self.meet[self.dummy]=self.full
  self.on=[union(t for k,t in enumerate(self.tag)if m>>k&1)for m in range(128)]
  self.F={p:self.dom(self.pp[p]^p)&~self.domq[p]&self.on[self.inc[p]]for p in self.pts}
  self.reject=cache(lambda u,x:all(v==u or self.dom(x)&self.tag[u]&self.meet[v]for v in self.effective))
  self.pr={p:sum(1<<u for u in self.effective if p in self.stars[u]and self.reject(u,self.pp[p]^p))for p in self.pts}
  self.ns=tuple((n,n>>13&127)for n in self.N);self.no={(p,q):bool(self.F[p]&self.domq[q])for p in self.pts for q in self.pts if p!=q}
  self.no_t={(p,q):sum(1<<u for u in self.effective if p in self.stars[u]and self.reject(u,(self.pp[p]^p)|self.pp[q]))for p,q in self.no}
  self.Ehits=[self.full for _ in range(128)]
  for m in range(128):
   for u in self.effective:
    if m>>u&1:self.Ehits[m]&=self.meet[u]
if __name__=='__main__':
 for j,v in DEGREE_ONE.items():
  s=Child(j)
  for q,u in DEGREE_ONE.items():
   if q==j:continue
   T=s.stars[u];_,M,_,_=s.roles(1<<u,11);B=(1<<20)-1|sum(1<<extra[c]for c in banks[115])
   dark=[(v,p)for v in s.effective for p in T if not any(a>>(13+v)&1 and a&~n==1<<(13+v) and s.pp[p]&~n==0 for a in s.P for n in s.N)]
   sep=[(p,z)for p in T for z in T if p!=z and not s.no[p,z]]
   print(j,q,'T',sorted(T),'M',M,'nodark',dark,'nosep',sep,flush=True)
