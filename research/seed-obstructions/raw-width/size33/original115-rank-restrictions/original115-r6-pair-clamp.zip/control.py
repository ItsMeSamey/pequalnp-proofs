from signedchild import *
from ast import literal_eval
from pathlib import Path
from itertools import combinations
for q,j in ((2,8),(8,32),(16,32),(32,8)):
 u=DEGREE_ONE[q];s=Child(j); orig=Orig(115);T=tuple(sorted(s.stars[u]));k=len(T)
 assert k==3 and all(any((orig.pp[z]&~n)==0 and not n&j and n>>(13+DEGREE_ONE[j])&1 for n in orig.N) for z in T if z not in orig.stars[DEGREE_ONE[j]])
 for z in T:
  assert s.F[z]&s.tag[u]
  for w in T:
   if w!=z:assert s.no[z,w]
  for h in s.effective:
   assert any(a>>(13+h)&1 and a&~n==1<<(13+h) and not s.pp[z]&~n for a in s.P for n in s.N)
 pre=Path(f'pre{q}-{j}.log').read_text().splitlines()
 def terms(lines):
  return [literal_eval(a[a.index('('):a.index(', ())')+5])for a in lines if a.startswith('open')]
 assert all(', ())' in a for a in pre if a.startswith('open'))
 profiles=set(terms(pre)); assert {k for _,k,_,_ in profiles}=={1}
 assert all(sp==0 and set(S)<=set(T) and 2<=len(S)<=3 for S,_,sp,_ in profiles)
 assert sum(l.startswith(f'{q} {j} ') for l in pre)==6
 for S,_,_,_ in sorted(profiles):
  log=f'restricted{q}-{j}.log' if len(S)==3 else f'pair{q}-{j}.log'
  lines=Path(log).read_text().splitlines()
  if len(S)==2:assert lines[0]=='FOR '+repr(S)
  assert len([t for t in lines if t.startswith('rows ')])==1
  assert set((int(lines[0 if len(S)==3 else 1].split()[-1]),))<=set((33,44))
  for row in lines:
   if not row.startswith('open'):continue
   e=row.index(')');F=literal_eval(row[5:e+1]);Y=int(row[e+2])
   assert not (Y==0 and set(F)<=set(S) and len(F)<len(S) or Y==1 and not F)
  print('closed',q,j,S,flush=True)
