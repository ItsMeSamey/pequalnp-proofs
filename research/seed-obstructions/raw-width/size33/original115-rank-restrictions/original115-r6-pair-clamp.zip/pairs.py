import os,sys
from pathlib import Path
from ast import literal_eval
q,j=map(int,sys.argv[1:3])
profiles={literal_eval(r.split(' ((),')[0][5:]) if False else literal_eval(r[5:r.index(', ())')+5]) for r in Path(f'pre{q}-{j}.log').read_text().splitlines() if r.startswith('open') and ', ())' in r}
for names,an,sp,_ in sorted(profiles):
 if len(names)!=2:continue
 os.environ['HITS']=str(sum(names))
 # A fresh helper invocation is required for module geometry.
 import subprocess
 print('FOR',names,flush=True)
 subprocess.run([sys.executable,'restricted.py',str(q),str(j)],check=True)
