from signedchild import *
from relaxed import run
import types
q,j=map(int,sys.argv[1:3]);u=DEGREE_ONE[q];s=Child(j,u);C=banks[115];du=s.dummy;O=(u,);origom=(1<<u)|(1<<du)
mod=types.ModuleType('geometry');mod.N=s.N;mod.P=s.P;mod.pts=s.phys;mod.alln=s.full;mod.stars=tuple(sum(S)for S in s.stars);mod.inc=s.inc;mod.pack=lambda f:sum(1<<i for i,n in enumerate(s.N)if f(n));mod.on=s.tag;mod.meet=s.meet;mod.pt=s.domq;mod.line=lambda m:s.on[m];mod.cache=cache;mod.combinations=combinations;mod.union=union
sys.modules['geometry']=mod
import holderbranch as hb,flex
flex.Source=hb.Source=lambda _:s
s.bank=lambda _:None
@cache
def envelope(sub,an,sp,y):
 flex.calls=hb.nc=0
 if an>1:return 'two'
 try:
  if not an:return flex.signed(C,origom,sub,(),(),sp,0)
  if y:return hb.chk(C,origom,sub,(),(),True,y,sp,required=())
  return hb.chk(C,origom,sub,(),(),True,(),sp)
 except TimeoutError:return 'cutoff'

T=tuple(sorted(s.stars[u]))
print('cross original',T,flush=True)
for k in range(4):
 for z in combinations(T,k):
  for a in range(2):
   if k==3 and a==1:continue
   v=envelope(z,a,0,())
   if v:print('open',z,a,v,flush=True)
