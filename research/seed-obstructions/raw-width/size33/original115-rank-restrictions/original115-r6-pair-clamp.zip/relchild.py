from signedchild import *
from relaxed import run
import types
q,j=map(int,sys.argv[1:3]);u=DEGREE_ONE[q];s=Child(j);C=banks[115];du=s.dummy;O=(u,);origom=(1<<u)|(1<<du)
mod=types.ModuleType('geometry');mod.N=s.N;mod.P=s.P;mod.pts=s.phys;mod.alln=s.full;mod.stars=tuple(sum(S)for S in s.stars);mod.inc=s.inc;mod.pack=lambda f:sum(1<<i for i,n in enumerate(s.N)if f(n));mod.on=s.tag;mod.meet=s.meet;mod.pt=s.domq;mod.line=lambda m:s.on[m];mod.cache=cache;mod.combinations=combinations;mod.union=union
sys.modules['geometry']=mod
import holderbranch as hb,flex
flex.Source=hb.Source=lambda _:s
s.bank=lambda _:None
@cache
def envelope(sub,an,sp,y):
 flex.calls=hb.nc=0
 if an>1:return 'two'
 try:
  if not an:return flex.signed(C,origom,sub,(),(),sp,0)
  if y:return hb.chk(C,origom,sub,(),(),True,y,sp,required=())
  return hb.chk(C,origom,sub,(),(),True,(),sp)
 except TimeoutError:return 'cutoff'
for Y in combinations(sorted(s.stars[u]),2):
 for g in (1,2):
  status,profiles=run(s,O,11,g,1500,bridge=Y)
  assert status is False
  need=set()
  for m,k in profiles:
   pa=tuple(sorted(p for p in m if p>0))
   for n in range(len(pa)+1):
    for sub in combinations(pa,n):
     for an in range(1+sum(x<0 for x in m)):
      for sp in range(k+1):need.add((sub,an,sp,Y if g==1 and an else ()))
  print(q,j,Y,g,len(need),flush=True)
  for t in sorted(need):
   a=envelope(*t)
   if a:print('open',t,str(a)[:95],flush=True)
