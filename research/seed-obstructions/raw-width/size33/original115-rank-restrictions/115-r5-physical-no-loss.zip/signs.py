from cuts import *
P,N=load(())
C=(129,4160);M=8191|(127<<13)|sum(1<<extra[c]for c in C)
for q,u in DEGREE_ONE.items():
 t=1<<(13+u)
 assert {p&M for p in P if p&q}=={q|t}
 for c in C:
  a=1<<extra[c]
  f=next(i for i,n in enumerate(N)if n&t and n&a and not n&q)
  dirty=next(i for i,n in enumerate(N) if n&q and n&c and not n&t)
  print(q,u,c,f,dirty)
