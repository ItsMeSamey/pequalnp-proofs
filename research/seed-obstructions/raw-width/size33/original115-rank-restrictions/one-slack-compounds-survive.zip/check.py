from cuts import *
P,N=load(())
for idx,C in ((0,()),(7,(129,)),(17,(4160,)),(115,(129,4160))):
 W=(1<<20)-1|sum(1<<extra[c]for c in C)
 pos={p&W for p in P};neg=tuple(n&W for n in N)
 for q,u in DEGREE_ONE.items():
  t=1<<(13+u)
  assert {x for x in pos if x&q}=={q|t}
  uc=next(i for i,n in enumerate(neg)if n&t and not n&q)
  bare=next(i for i,n in enumerate(neg)if n&q and not n&t)
  assert all(not n&t for n in neg if n&q)
  # An unrelated constant source a cannot have q's first head as its sole exit.
  cert=[]
  for a in (set(DEGREE_ONE)-{q})|{t}:
   (p,i)=next((p,i) for p in sorted(pos) if p&a for i,n in enumerate(neg)
              if n&q and not n&a and not(p&~a&~n))
   cert.append((a,p,i))
  print(idx,q,u,uc,bare,cert)
  for r in DEGREE_ONE:
   for a in (set(DEGREE_ONE)|{t})-{r}:
    assert any(n&r and not n&a and not(x&~a&~n) for x in pos if x&a for n in neg)
  # Every projected bare point and every bare retained tag is dominated.
  for b in [1<<i for i in range(13) if 1<<i not in DEGREE_ONE]:
   assert any(n&q and n&b and all(not b&c or n>>extra[c]&1 for c in C)for n in neg)
  for a in range(7):
   if a!=u:assert any(n&q and n>>(13+a)&1 for n in neg)
  for c in C:assert any(n&t and not n&q and n&(1<<extra[c])for n in neg)
