from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from collections import defaultdict
from io import BytesIO
import subprocess,re,sys
root=Path('/workspace/scratch')
paths=defaultdict(list)
for raw in subprocess.check_output(['rg','--files','--hidden','-g','*.zip',str(root)]).decode().splitlines():
 p=Path(raw);paths[p.name].append(p)
seen=set();miss=set()
def visit(bs,label):
 digest=sha256(bs).hexdigest()
 if digest in seen:return
 seen.add(digest)
 with ZipFile(BytesIO(bs))as z:
  ns=z.namelist();hits=[];sat=[];manifest=[]
  for n in ns:
   if n.endswith(('.py','.cpp','.cc','.hpp','.lean')):
    s=z.read(n).decode(errors='replace')
    if re.search(r'def reject_local|leaves\s*==\s*4|distinct\s*==\s*3.{0,40}leaves',s):hits.append(n)
    if re.search(r'pysat|cadical|Minisat|kissat',s,re.I):sat.append(n)
   if n.rsplit('/',1)[-1] in ('SHA256SUMS','SHA256SUMS.txt'):
    for line in z.read(n).decode().splitlines():
     m=re.fullmatch(r'([a-f0-9]{64})\s+\*?(.+\.zip)',line.strip())
     if m:manifest.append(m.groups())
  print(label,digest,len(ns),'shape='+','.join(hits),'SAT='+','.join(sat),sep='\t')
  for n in ns:
   if n.endswith('.zip'):visit(z.read(n),label+'!'+n)
  for h,name in manifest:
   for p in paths[Path(name).name]:
    sb=p.read_bytes()
    if sha256(sb).hexdigest()==h:visit(sb,name);break
   else:miss.add((h,name))
visit(Path('../core27-complete.zip').read_bytes(),'core27-complete.zip')
for m in sorted(miss):print('MISSING',*m)
