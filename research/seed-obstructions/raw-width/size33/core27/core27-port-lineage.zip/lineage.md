# Dependency review of the physical port-count correction

inventory.py followed the 17-package manifest in core27-complete.zip, every embedded archive and every listed ZIP with a SHA256SUMS entry. It identified 41 distinct archives, with no named package missing. source-inventory.tsv records the hash and SAT/shape-source evidence for each one.

The 53/57 precursor uses six geometric and small routing packages. Its only SAT caller, regional.py in t427-low, defines static route witnesses, a common acyclic ordering, and distinct/duplicate outgoing edges with cardinality budgets. It calls the solver once after constructing its constraints and never learns a local arity clause from a chosen model. The other five use signed masks, receiver counts, local-rank tests or direct enumeration.

The cost26 intermediate t426-low, t4-seven-26-complete and its three ordinary-label supplements contain no shape blocker. They derive costs from signed incidence, guard and receiver ranks, and enumerate fixed finite profiles. For the 129/ordinary1 supplement the independently checked high mask range includes zero, and all accepted precursor pairs require bit 0, which licenses its subsequent zero-baseline test.

The single-compound seven-owner packet for at least two anonymous helpers uses singleroute.py (static capacity/routing) and graph129.py (blocks exact directed-edge and destination assignments, before independent signed filtering). These do not infer arity-dependent rejection. The four actual patched versions of the disputed blocker occur only in the regression artifact, where they are diagnostics.

The original one-anonymous reduction to 65 and 118, the temporal source expansion and the receiver alternatives are independent of the faulty rule. The controlling f51bd9a6 archive regenerates all 68 final temporal rows with the coarse shape rule removed entirely. Its learned local truth-table obstructions guard each physical directed edge, C location, and participating operand/output signs. The old key105 proof is withdrawn. The corrected CNF fd6076d9… and DRAT e3d5c89c… are the controlling key105 receipt. Hostile review separately confirmed the full frozen ledger and independently checked keys 191 and 107.

This is a source and dependency check against the reported defect. It does not claim 41 fresh independent numerical replays.
