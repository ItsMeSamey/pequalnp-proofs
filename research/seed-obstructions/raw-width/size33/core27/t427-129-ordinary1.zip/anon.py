from clamp import *
# candidate rows: original marked holders are M, and one anonymous X. E.g. z=M plus one named holder, or z=M.
from functools import lru_cache
@lru_cache(None)
def masks_k(hp,H):
 h=H&(pack(lambda n:bool(n&C))if hp else alln)
 raw={p:p for p in pts if not p&C or hp}
 F={p:(~pt[p])&line(inc[p]&alllabels)&h for p in raw}
 av=sum(1<<u for u in range(7)if u!=t and all(h&on[u]&meet[v]for v in range(7)if v not in(t,u)))
 res=set()
 for U in range(1,128):
  if U&~alllabels:continue
  rr=[p for p in raw if inc[p]&U not in (0,U) and all(h&pt[p]&on[u]for u in range(7)if U>>u&1 and not inc[p]>>u&1) and all(h&pt[p]&meet[u] for u in range(7)if u!=t)]
  for V in range(1,128):
   if V&~(U&av):continue
   k=sum(p for p in rr if inc[p]&V and all(F[p]&on[u] and h&line(inc[p]&U)&on[u]for u in range(7)if V>>u&1))
   if k.bit_count()<3:continue
   ks={k}
   for p,q in combinations(bm(k),2):
    if inc[p]&U==inc[q]&U or not h&line(inc[p]&U)&line(inc[q]&U)or not (F[p]&pt[q]|F[q]&pt[p]):ks={d for r in ks for d in ((r^p,r^q)if r&p and r&q else(r,))}
   res.update((V,k)for k in ks if k.bit_count()>=3)
 return res,h,F
def price(gs,V,slots,fans,credit,avail):
 if not slots:return enough(tuple(gs),V,tuple(fans),credit)
 z,possible,bright=slots[0]
 return (price(gs,V,slots[1:],fans+[(bright,2)],credit,avail) or any(price([r for i,r in enumerate(gs)if i!=j],V,slots[1:],fans,credit,avail[:j]+avail[j+1:])for j,q in enumerate(avail)if possible&q))
def scan(Z,S):
 extra=bm(Z^ordinary)
 assert all(((~pt[z])&line(inc[z])&(pack(lambda n:bool(n&C))if z&C else alln)&pt[p])for z in bm(Z)for p in M if z!=p)
 H=meet[t] if not S else pack(lambda n:bool(n&S))
 for hp in (0,1):
  seen,h,F=masks_k(hp,H)
  for V,K in sorted(seen,key=lambda vk:-vk[1].bit_count()):
   slots=[]
   for z in extra:
    # z stays positive at least on the all-high pin. Disallow other omitted rows whose new negative dominates that anchor.
    occ=sum(p for p in bm(K)if z==p or (not hp)or not F[p]&pt[z])
    emit=sum(1<<u for u in range(7)if V>>u&1 and not ((~pt[z])&line(inc[z]&alllabels)&on[u]&h&(pack(lambda n:bool(n&C)) if z&C else alln)))
    slots.append((z,occ,emit))
   if not S:slots.append((0,K,V))
   # grant the unspent original unit to another pair of deliveries, a surviving fanout, or a mandatory owner
   free=1-len(extra); g=[inc[p]&V for p in bm(K)]
   ok=price(g,V,slots,[],free,bm(K))
   if free and not ok:
    ok=price(g,V,slots+[(0,K,V)],[],0,bm(K))
    if not ok:
     # A third read at a surviving helper, merged or separate, can save at most one further delivery per tag.
     ok=price(g,V,slots,[(V,2)],0,bm(K))
   if not ok:return hp,V,K
if __name__=='__main__':
 for Z in (1408,1409,1412,1472,1920,3456,5504):
  for S in range(8):
   s=sum(p for i,p in enumerate(M)if S>>i&1)
   print(Z,s,scan(Z,s),flush=True)
