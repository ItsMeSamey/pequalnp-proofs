from anon import *
for both in combinations(M,2):
 ans=None
 for hp in (0,1):
  seen,h,F=masks_k(hp,meet[t])
  for V,K in sorted(seen,key=lambda vk:-vk[1].bit_count()):
   slots=[]
   for q in both:
    occ=sum(p for p in bm(K)if p==q or (not hp and bool(q&C)) or not F[p]&pt[q])
    bright=sum(1<<u for u in range(7)if V>>u&1 and not h&(~pt[q])&line(inc[q]&alllabels)&on[u]&(pack(lambda n:bool(n&C))if q&C else alln))
    slots.append((q,occ,bright))
   if not price([inc[p]&V for p in bm(K)],V,slots,[],0,bm(K)):
    ans=hp,V,K;break
  if ans:break
 print(both,ans,flush=True)
