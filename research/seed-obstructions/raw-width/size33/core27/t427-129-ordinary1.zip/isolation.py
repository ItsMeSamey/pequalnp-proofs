from clamp import *
for Z in (1408,1409,1412,1472,1920,3456,5504):
 bad=[(z,q)for z in bm(Z)for q in M if z!=q and not((~pt[z])&line(inc[z])&(pack(lambda n:bool(n&C))if z&C else alln)&pt[q])]
 print(Z,bad)
