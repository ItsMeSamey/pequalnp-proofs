from cuts import load,extra,DEGREE_ONE,bm
from itertools import combinations
from collections import Counter
U=bm(8191);Q=set(DEGREE_ONE)
for t in range(3):
 for E in combinations(sorted(Q),t):
  P,N=load(E);units=8191^sum(E)
  opts=[c for c in extra if not any(d!=c and not d&~c and not(c^d)&units for d in [0,*U,*extra])]
  pairs={ (q,r):[(p&~n)&~(q|r)for p in P for n in N if (p&q and n&r or p&r and n&q)and not(p&n&(q|r))]for q,r in combinations(sorted(Q-set(E)),2)}
  cnt=Counter()
  for R in [units]+([units^2]if units&2 else []):
   for k in range(18-t-R.bit_count()):
    for C in combinations(opts,k):
     if R!=units and not {3,6,258}<=set(C):continue
     w=R|(127<<13)|sum(1<<extra[c]for c in C)
     gaps=tuple(qr for qr,ww in pairs.items()if all(p&R for p in qr)and not any(not m&w for m in ww))
     cnt[R==units,gaps]+=1
  print(t,E,dict(cnt),flush=True)
