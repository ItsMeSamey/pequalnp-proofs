from itertools import product
from single import C,E,opts,bm,pt,line,inc,on,alln
from holder import actual
for i,(z,anon,ds) in enumerate(opts):
 if anon:continue
 names=bm(z); groups=[(p,) for p in names]; spare=4-len(ds)-sum(ds)
 upper=[tuple(sum(1<<u for u in range(7) if not (~pt[p]&line(inc[p])&on[u]&(E if pin or p&C else alln))) for p in names) for pin in (0,1)]
 low=[tuple(0 for _ in names)]*2
 edges=tuple((i,j) for i in range(len(names)) for j in range(len(names)) if i!=j)
 live=[f for f in product((2,3),repeat=len(names)) if actual((C,),list(zip(names,f)),low,edges,groups,spare,upper)]
 print(i,z,ds,live,flush=True)
