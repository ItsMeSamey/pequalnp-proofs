from single import *
from holder_safe import actual
from ast import literal_eval
from pathlib import Path
import sys
i=int(sys.argv[1]);z,anon,ds=opts[i];names=bm(z);groups=[(p,) for p in names]
F={p:~pt[p]&line(inc[p])&(E if p&C else alln) for p in names}
assert all(F[p]&E for p in names)
hi=[tuple(sum(1<<u for u in range(7) if not(F[p]&on[u]&(E if pin else alln))) for p in names) for pin in (0,1)]
print(i,names,hi,flush=True)
base=next(l for l in (Path(__file__).parent/'named.log').read_text().splitlines() if int(l.split()[0])==i)
flags=literal_eval(base[base.index('['):])
edges=tuple((i,j) for i in range(4) for j in range(4) if i!=j)
def run(L,U):
 if not any(actual((C,),list(zip(names,f)),L,edges,groups,0,U) for f in flags):return 0
 b=next(((t,j,(x^y)&-(x^y)) for t in range(2) for j,(x,y) in enumerate(zip(L[t],U[t])) if x!=y),None)
 if b is None:print('open',L,flush=True);return 1
 t,j,v=b
 A=[list(x) for x in U]; A[t][j]&=~v
 if t==1:A[0][j]&=~v
 B=[list(x) for x in L]; B[t][j]|=v
 if t==0:B[1][j]|=v
 return run(L,A) or run(B,U)
print('RESULT',run([[0]*4,[0]*4],hi),flush=True)
