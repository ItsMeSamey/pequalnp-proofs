import ast,json
from collections import Counter
from pathlib import Path
from itertools import combinations
def lines(f):return [ast.literal_eval(row)for row in Path(f).read_text().splitlines()]
banks=json.loads(Path('banks.json').read_text());raw=ast.literal_eval(Path('raw-live.txt').read_text());pool=sorted({(c,w,om,l)for _,c,w,om,l in raw if om.bit_count()==1},key=lambda a:(7-a[2].bit_count(),a[3],a));weighted=lines('weighted.log');allkeys={idx for _,_,ids,_ in weighted for idx in ids}
assert allkeys=={i for i,(j,R,C) in enumerate(banks)if not R&2 and 2 not in list(combinations((2,8,16,32),2))[j]}and len(allkeys)==138
check={(c,w):set()for c,w,ids,s in weighted}
for c,w,s,r in lines('checksites.log'):
 if r:check[c,w].add(s)
r7={idx:c for c,w,ids,slots in weighted for idx in ids if check[c,w]and len(c)<2}
assert len(r7)==61
middle={354,523,1046,2092};r7mid={i:c for i,c in r7.items()if not(middle&set(c))}
corr=set(range(268,284));new=corr-{268,269,270,271,272,276};ten={int(l.split()[0])for l in Path('clampsub.log').read_text().splitlines()};assert len(ten)==10
index={k:j for j,k in enumerate(pool)}
data={}
for idx in sorted(allkeys):
 j,r,c=banks[idx];dst,w,_,slots=next(row for row in weighted if idx in row[2])
 ds=[index[c0,w0,O,b]for i,c0,w0,O,b in raw if i==idx and O.bit_count()==1]
 data[idx]=dict(peeled=list(combinations((2,8,16,32),2))[j],point_source_mask=r,original_composites=c,canonical_composites=dst,multiplicities=w,seven_profiles=sorted(check[dst,w])if idx in r7 else [],seven_current=idx in r7mid,six_corrected=[k for k in ds if k in corr],six_current=[k for k in ds if k in new],ten_hold=[k for k in ds if k in ten])
for name,ids,seven in [('frozen corrected',corr,r7),('latest six only',new,r7),('latest both',new,r7mid),('latest both + ten hold',new|ten,r7mid),('frozen corrected + ten hold',corr|ten,r7)]:
 six={i for i,c,w,o,b in raw if o.bit_count()==1 and index[c,w,o,b]in ids};both=set(seven)&six;print(name,len(six),len(seven),len(both),len(set(seven)|six))
Path('missing-138.json').write_text(json.dumps(data,separators=(',',':')))
scopes={
 'frozen':[i for i,r in data.items()if r['six_corrected'] or r['seven_profiles']],
 'latest':[i for i,r in data.items()if r['six_current']or r['seven_current']],
 'latest_with_ten_held':[i for i,r in data.items()if r['six_current'] or r['seven_current'] or r['ten_hold']]}
Path('surviving-keys.json').write_text(json.dumps(scopes,separators=(',',':')))
