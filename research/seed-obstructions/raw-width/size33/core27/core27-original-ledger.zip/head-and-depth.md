# AND depth after deleting raw OR heads

Assume a normalized residual separator of at most 33 gates in the signed degree-one terminal form. Remove its extracted terminal products and their collector ORs. In the remaining graph bypass each head q OR B to B, where q is one of the degree-one primitive inputs. Consider the graph before constant simplification or semantic mergers.

Between surviving paid gates the bypass preserves ancestor relations. Every lost incoming edge from q starts at a primitive. Every path through B continues at the replacement wire. Thus a path through two AND gates exists before bypass exactly when one exists afterward. The removed terminal products are collected by ORs and have no paid AND ancestors.

If the original circuit had no such path, every AND would combine two ORs of primitives, and its consumers would lie entirely in the top OR collection. Any top-level primitive disjunct that accepts a residual positive also accepts an actual negative and cannot be present in a separator. Other primitive disjuncts can be removed. The existing two-clause lower bound then requires 34 gates (two-clause.zip, README and signed check).

Primitive source aliasing or splitting cannot alter AND-to-AND paths. Thus a concrete AND-depth-one donor, including the 30-gate seven-star control, cannot lift to 33 solely by these OR-head insertions, primitive aliases and terminal products. Applications after paid-gate removal due to inert sources or semantic simplifications require additional proof.
