import json,gzip
from pathlib import Path
from itertools import combinations
from collections import Counter
S=tuple(1<<k for k in range(13));peeled=(2,8,16,32);keep=8191^sum(peeled)
A=tuple(3<<k for k in range(6));B=tuple((1<<(3+k))|(1<<((9+k)%13))for k in range(6));C=tuple(x|y for x,y in zip(A,B));lib=sorted((*A,*B,*C));superset=[0,*S,*lib]
def canonical(live):
 return [c for c in lib if all(d==c or d&~c or (c^d)&live for d in superset)]
dst=sorted(q for q in (*S,*canonical(keep))if q&keep);assert set(canonical(keep))=={129,354,523,1046,2092,4160}
t2=json.loads(Path('banks.json').read_text());keyids={(j,r,tuple(c)):i for i,(j,r,c)in enumerate(t2)}
if __name__=='__main__':
 cnt=Counter();tot=Counter();seen=set()
 with gzip.GzipFile('terminal-raw-keys.jsonl.gz','wb',mtime=0) as out:
  for t in range(3):
   for j,E in enumerate(combinations(peeled,t)):
    live=8191^sum(E)
    for r in (live,live&~2)if live&2 else(live,):
     for n in range(18-t-r.bit_count()):
      for c in combinations(canonical(live),n):
       missing=r!=live
       if missing and not {3,6,258}<=set(c):continue
       aliases=[]
       for x in c:
        if not x&keep:aliases.append(0);continue
        d,=[q for q in dst if q&~x==0 and (q^x)&keep==0];aliases.append(d)
       bound=33-2*t-((4-t)-int(missing))-aliases.count(0)
       idx=keyids[j,r,c]if t==2 else None
       if idx is not None:seen.add(idx)
       row=[t,E,r,c,idx,aliases,bound,bound<=27]
       out.write((json.dumps(row,separators=(',',':'))+'\n').encode());tot[t]+=1;cnt[t]+=bound<=27
 assert len(seen)==len(t2)==4902
 assert dict(tot)=={0:4169,1:8001,2:4902}and dict(cnt)=={0:137,1:1788,2:4764}
 print('original',dict(tot),'core bound <=27',dict(cnt))
