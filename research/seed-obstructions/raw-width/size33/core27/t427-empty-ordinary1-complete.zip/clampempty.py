from geometry import *
from cps import enough
from itertools import combinations
from functools import cache
# Each nonzero point-only named donor (and each mandatory holder) has an independent bound
# on its zero-line positive support. Exact for this empty-composite domain.
@cache
def cuts(t):
 valid=[];raw=127^(1<<t);B=meet[t]
 for U in range(1,128):
  if U&~raw:continue
  good=sum(1<<u for u in range(7)if U>>u&1 and all(B&on[u]&meet[v]for v in range(7)if v not in (t,u)))
  rows=[p for p in pts if inc[p]&U not in (0,U)and all(B&pt[p]&on[u]for u in range(7)if U>>u&1 and not inc[p]>>u&1)and all(B&pt[p]&meet[v]for v in range(7)if v!=t)]
  bad=[(p,q)for p,q in combinations(rows,2)if inc[p]&U==inc[q]&U or not B&line(inc[p]&U)&line(inc[q]&U)or not B&(line(inc[p]&U)&~pt[p]&pt[q]|line(inc[q]&U)&~pt[q]&pt[p])]
  for V in range(1,128):
   if V&~good:continue
   K=sum(p for p in rows if inc[p]&V and all(B&~pt[p]&line(inc[p]&U)&on[u] and B&line(inc[p]&U)&on[u] for u in range(7)if V>>u&1))
   ks={K}
   for p,q in bad:ks={y for k in ks for y in ((k^p,k^q)if k&p and k&q else(k,))}
   valid.extend((k,V)for k in ks if k.bit_count()>=3)
 return sorted(set(valid),key=lambda x:-x[0].bit_count())
def proof(t,z,n,ds):
 named=bm(z);M=bm(stars[t]);K0=tuple(p for p in pts if p not in named)
 F={p:line(inc[p])&~pt[p]for p in pts}
 assert all(F[q]&pt[p]for q in named for p in pts if p!=q)
 assert all(pt[p]&meet[v]for p in M for v in range(7)if v!=t)
 assert all(meet[t]&~pt[p]&line(inc[p]^(1<<t))for p in M) # each p also essential in exterior
 # Lost root occurrences can cover M only through own named origin or an anonymous origin.
 # Grant each lost anonymous occurrence the whole of M to maximize its usefulness.
 choices=[tuple(i for i,p in enumerate(named)if p in M)]+[(len(named)+i,)for i in range(n)]
 spare=6-len(ds)-sum(ds)
 for L in choices:
  cap=[2+d-(i in L)for i,d in enumerate(ds)]
  # A lost binary named source has at most one exterior read and can be inlined.
  retained=sum(p for i,p in enumerate(named)if cap[i]>=2)
  unknown=[y for y in cap[len(named):]if y>=2]
  # Anonymous point-only-high probes may become resident after inlining another source. Grant arbitrary omissions.
  for K,V in cuts(t):
   candidates=bm(K&~retained);take=min(len(candidates),len(unknown))
   if not any(enough(tuple(inc[p]&V for p in candidates if p not in omitted),V,tuple((127,f)for f in unknown),spare)
              for omitted in combinations(candidates,take)):break
  else:return True
 return False
if __name__=='__main__':
 import sys
 from ast import literal_eval
 from pathlib import Path
 t=int(sys.argv[1]);rows=literal_eval(Path(f'orig-{t}.txt').read_text())
 for i,(z,n,ds)in enumerate(rows):print(i,proof(t,z,n,ds))
