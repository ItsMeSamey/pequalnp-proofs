from clampempty import *
from ast import literal_eval
from pathlib import Path
from itertools import product
@cache
def tests(t,Bmask):
 B=union(pt[p]for p in bm(Bmask));raw=127^(1<<t);valid=set()
 for U in range(1,128):
  if U&~raw:continue
  good=sum(1<<u for u in range(7)if U>>u&1 and all(B&on[u]&meet[v]for v in range(7)if v not in (t,u)))
  rows=[p for p in pts if inc[p]&U not in (0,U)and all(B&pt[p]&on[u]for u in range(7)if U>>u&1 and not inc[p]>>u&1)and all(B&pt[p]&meet[v]for v in range(7)if v!=t)]
  bad=[(p,q)for p,q in combinations(rows,2)if inc[p]&U==inc[q]&U or not B&line(inc[p]&U)&line(inc[q]&U)or not B&(line(inc[p]&U)&~pt[p]&pt[q]|line(inc[q]&U)&~pt[q]&pt[p])]
  for V in range(1,128):
   if V&~good:continue
   K=sum(p for p in rows if inc[p]&V and all(B&~pt[p]&line(inc[p]&U)&on[u] and B&line(inc[p]&U)&on[u] for u in range(7)if V>>u&1))
   ks={K}
   for p,q in bad:ks={y for k in ks for y in ((k^p,k^q)if k&p and k&q else(k,))}
   valid.update((k,V)for k in ks if k.bit_count()>=3)
 return sorted(valid,key=lambda kv:-kv[0].bit_count())
def check(t,z,n,ds,R):
 M=stars[t];named=bm(z);qset=R or M
 B=union(pt[p]for p in bm(qset));F={p:line(inc[p])&~pt[p]for p in pts}
 assert all(F[q]&pt[p]for p in pts for q in named if q!=p)
 assert all(pt[p]&meet[v]for p in bm(M)for v in range(7)if v!=t)
 if R:
  assert n==1
 else:assert n<=1
 retained=[(p,2+d-int(bool(p&M)))for p,d in zip(named,ds)if 2+d-int(bool(p&M))>=2]
 raw_anon=(n and not R)
 left=6-len(ds)-sum(ds)
 for K,V in tests(t,qset):
  masks=[];opts=[]
  for p,fan in retained:
   if R:
    # High on its original q, stays low on every retained negative that masks q.
    # Grant all other compatible new zero-line baselines.
    om=sum(q for q in bm(K)if not B&F[p]&pt[q])
    mask=sum(u for u in bm(V)if not B&F[p]&on[u.bit_length()-1])
   else:om=p&K;mask=0
   if p&K:mask=0
   opts.append([0,*bm(om)])
   masks.append((mask,fan))
  if raw_anon:
   opts.append([0,*bm(K&~M)]);masks.append((127,2+ds[-1]))
  if not any(enough(tuple(inc[p]&V for p in bm(K)if p not in omit),V,tuple(sorted(masks)),left)for omit in product(*opts)):return False
 return True
def live(t,z,n,ds):
 M=bm(stars[t]);return [R for R in (range(1<<len(M))if n else [0])if check(t,z,n,ds,sum(p for i,p in enumerate(M)if R>>i&1))]
if __name__=='__main__':
 import sys
 t,a,b=map(int,sys.argv[1:]);rows=literal_eval(Path(f'orig-{t}.txt').read_text())
 for i in range(a,min(b,len(rows))):
  z,n,ds=rows[i]
  if n<=1:print(i,live(t,z,n,ds),flush=True)
