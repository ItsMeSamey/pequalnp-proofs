from geometry import *
from itertools import combinations
from pathlib import Path
from ast import literal_eval
def checks(t):
 U=127^(1<<t)
 for z,n,ds in literal_eval(Path(f'orig-{t}.txt').read_text()):
  P=bm(8133^z);F={p:~pt[p]&line(inc[p]) for p in pts}
  for u in bm(U):
   h=u.bit_length()-1
   assert all(on[h]&meet[v]for v in range(7)if v not in (h,t))
   assert all(on[h]&F[p]for p in bm(z))
   for p in P:
    assert inc[p]&U not in (0,U)
    assert all(pt[p]&meet[v] for v in range(7) if v!=t)
    assert inc[p]&u or pt[p]&on[h]
    assert F[p]&on[h] and line(inc[p]&U)&on[h]
  for p,q in combinations(P,2):
   assert (inc[p]&U)!=(inc[q]&U)
   assert line(inc[p]&U)&line(inc[q]&U)
   assert F[p]&pt[q] or F[q]&pt[p]
if __name__=='__main__':checks(0);checks(1);print('Whole protected-bin geometry verified.')
