from six import *
from marks import profile
from holder import actual
from pathlib import Path
from ast import literal_eval
P,N=load(tuple(DEGREE_ONE))
def source(t):
 M,_,b,*_=profile((),(t,));B=sum(M)
 opts=test(P,N,8133,(),[B+sum(d)for d in subs(bm(8133^B),b+2)],t)
 Path(f'orig-{t}.txt').write_text(repr(opts))
 print(t,B,len(opts),flush=True)
def run(t,a,b):
 rows=literal_eval(Path(f'orig-{t}.txt').read_text())
 for i in range(a,min(b,len(rows))):
  z,n,ds=rows[i];gr=[(p,) for p in bm(z)]+[(-k-1,)for k in range(n)]
  spare=6-len(ds)-sum(ds);mask=127^(1<<t);k=z.bit_count()
  live=actual((),[(p,1)for p in bm(z)],[[0]*len(ds)],(),gr,spare,[[0]*k+[mask]*n],t)
  print(i,z,n,ds,live,flush=True)
if __name__=='__main__':
 t=int(sys.argv[1]);source(t) if len(sys.argv)==2 else run(t,*map(int,sys.argv[2:]))
