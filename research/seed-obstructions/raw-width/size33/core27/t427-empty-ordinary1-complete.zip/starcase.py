from multicopy import *
from itertools import product
def signatures(i,files):
 ans=set()
 for fn in files:
  for l in Path(fn).read_text().splitlines():
   s=l.split(' ',6);t,j,arc,a,b,_,r=s
   if int(j)!=i:continue
   for m in literal_eval(r):
    ans.add((int(arc),tuple(m)))
    if not int(arc):ans.update((e,tuple(mm))for e in (0,1) for mm in (m,m[::-1]))
 return sorted(ans)
def fitstar(t,z,n,ds,m,E,start,end):
 # R[j] records J_j(p) on the ordinary singleton probes, not its read allocation.
 M=stars[t];starsub=tuple(sorted(allsubs(M)));indices=product(starsub,repeat=n)
 for k,R in enumerate(indices):
  if k<start or k>=end:continue
  for pr in range(1<<n):
   need=0
   for p in bm(M):
    active=[i for i in range(n)if pr>>i&1 and R[i]&p]
    if not active or on[t]&reduce(and_,[union(pt[q]for q in bm(R[i]))|line(m[i])for i in active],alln):need|=p
   if bill(t,z,n,ds,R,m,E,pr,need):return k,R,pr,need
 return None
if __name__=='__main__':
 import sys
 t,i,a,b=map(int,sys.argv[1:]);z,n,ds=literal_eval(Path(f'orig-{t}.txt').read_text())[i]
 sig=signatures(i,('t1-masks.log','t1-flex.log'))
 for j in range(a,min(b,len(sig))):
  arc,m=sig[j];r=fitstar(t,z,n,ds,m,2*arc,0,8**n)
  print(i,j,arc,m,r,flush=True)
