from partial import *
from functools import reduce
from operator import and_
def allsubs(k):
 v=k
 while True:
  yield v
  if not v:break
  v=(v-1)&k
@cache
def testsB(t,B):
 return arbitrary(t,B)[:32]
# Geometric cut generator with a packed negative set.
import inspect
exec(inspect.getsource(tests).replace('def tests(t,Bmask):','def arbitrary(t,B):').replace('B=union(pt[p]for p in bm(Bmask));',''))
def bill(t,z,n,ds,R,masks,arcs,priv,rawpriv):
 named=bm(z);M=stars[t];lab=127^(1<<t);F={p:~pt[p]&line(inc[p])for p in pts}
 spare=6-len(ds)-sum(ds);f={p:2+d for p,d in zip(named,ds)};fa=[2+d for d in ds[len(named):]]
 live=lambda i,p: bool(R[i]&p)
 edges={(i,j) for i in range(n)for j in range(i+1,n)if arcs>>((i*3)+j)&1}
 # Grant indirect arrival of every support bit whenever an appropriately bright earlier source has a paid arc.
 recv={p:{i for i in range(n)if live(i,p)and not any(j==i and live(l,p)for l,j in edges)}for p in bm(M)}
 track=tuple(range(n));B0=meet[t]
 high=[union(pt[p] for p in bm(r))|line(ma)for r,ma in zip(R,masks)]
 if any(len(recv[p])+int(bool(rawpriv&p))>f[p]for p in bm(M)):return False
 if any(sum(j==i for j,k in edges)+int(priv>>i&1)>fa[i]for i in track):return False
 for p in bm(M):
  if rawpriv&p:continue
  opts=[i for i in track if live(i,p)and priv>>i&1]
  if not opts or on[t]&reduce(and_,[high[i]for i in opts],alln):return False
 for cut in allsubs((1<<n)-1):
  B=B0;J=[i for i in track if cut>>i&1]
  for i in J:B&=high[i]
  if not B:continue
  caps={p:f[p]-bool(p&rawpriv)-len(recv.get(p,set())&set(J))for p in named}
  if any(caps[p]<=0 and B&~pt[p]&line(inc[p]&lab)for p in named):return False
  retained=[(p,caps[p])for p in named if caps[p]>=2]
  aux=[(i,fa[i]-(priv>>i&1)-sum((i,j)in edges for j in J))for i in track if i not in J]
  aux=[(i,f)for i,f in aux if f>=2]
  for K,V in testsB(t,B):
   holders=[];roles=[]
   for p,fan in retained:
    if J:
     om=sum(q for q in bm(K)if not B&F[p]&pt[q])
     bright=sum(u for u in bm(V)if not B&F[p]&on[u.bit_length()-1])
    else:om=K&p;bright=0
    holders.append([0,*bm(om)])
    roles.append((0 if K&p else bright,fan))
   for i,fan in aux:
    om=K if J else K&(~M|R[i])
    # Its original known high row is a lower bound even after any upstream pin.
    om=sum(p for p in bm(om)if not B&high[i]&~pt[p]&line(inc[p]&lab))
    holders.append([0,*bm(om)])
    roles.append((127 if J else masks[i],fan))
   if not any(enough(tuple(inc[p]&V for p in bm(K)if p not in omitted),V,tuple(sorted(roles)),spare) for omitted in product(*holders)):return False
 return True
