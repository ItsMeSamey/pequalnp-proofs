from stage import *
from holder import *
from itertools import product
from functools import reduce
from operator import and_,or_
S=stars
@cache
def groups(K,k):
 return tuple(sum(r)for r in combinations(bm(K),min(k,K.bit_count())))
@cache
def req(K,k,t,least):
 if least<=0:return (1<<len(groups(K,k)))-1
 return sum(1<<i for i,d in enumerate(groups(K,k))if (t&d).bit_count()>=least)
@cache
def fit(V,K,ma,mb,arc,fa,fb):
 for a in groups(K,fa-arc):
  b=(1<<len(groups(K,fb)))-1
  for u in range(7):
   if not V>>u&1:continue
   x=ma>>u&1;y=mb>>u&1
   demand=(S[u]&K)&~(a if x else 0)
   need=demand.bit_count()+x+y-int(x and y and arc)-2
   if y:b&=req(K,fb,demand,need)
   elif need>0:b=0
   if not b:break
  if b:return True
 return False
def suite(t,i,arc,start,end):
 z,n,ds=literal_eval(Path(f'orig-{t}.txt').read_text())[i];g=z.bit_count();sp=6-len(ds)-sum(ds);V=127^(1<<t)
 assert n==2 and not sp and ds[g:]==(0,0)
 cand=[(a,b) for a in range(start,end) for b in range(128)if not (a|b)&~V and (arc or a<=b) and fit(V,8133^z,a,b,arc,2,2)]
 E=((g,g+1),)if arc else ();named=bm(z);groups=[(p,)for p in named]+[(-1,),(-2,)]
 def walk(xs):
  if not xs:return []
  lo=[[0]*g+[reduce(and_,v)for v in zip(*xs)]];hi=[[0]*g+[reduce(or_,v)for v in zip(*xs)]]
  if not actual((),[(p,1)for p in named],lo,E,groups,sp,hi,t):return []
  if len(xs)==1:return xs
  _,k,u=max((min(n,len(xs)-n),k,u)for k in (0,1) for u in range(7) if 0<(n:=sum(x[k]>>u&1 for x in xs))<len(xs))
  return walk([x for x in xs if x[k]>>u&1])+walk([x for x in xs if not x[k]>>u&1])
 res=walk(cand);print(t,i,arc,start,end,len(cand),res,flush=True)
if __name__=='__main__':suite(*map(int,sys.argv[1:]))
