from pathlib import Path
from ast import literal_eval
import argparse,contextlib,io,subprocess,tempfile
from geometry import bm,stars
from verifygeom import checks
from threemask import run
TOPOLOGIES=(0,2,6,34,36,38)
COUNTS=(6000,10460,5784,9362,1812,25)
def validate(e):
 data=[tuple(map(int,l.split())) for l in Path(f'm3-{e}.txt').read_text().splitlines()]
 assert len(data)==len(set(data))==COUNTS[TOPOLOGIES.index(e)]
 masks=sorted({x[0]for x in data})
 receipts=Path(f'three-rank-{e}.log').read_text().splitlines()
 assert len(receipts)==len(masks)
 assert sum(int(r.split()[2])for r in receipts)==sum((e!=0 or x<=y<=z)and(e!=6 or y<=z)and(e!=36 or x<=y) for x,y,z in data)
 for x,r in zip(masks,receipts):
  k,a,num,result=r.split(' ',3)
  assert (int(k),int(a),literal_eval(result))==(e,x,[])
 return receipts,masks
def main():
 p=argparse.ArgumentParser();p.add_argument('--generate',metavar='BINARY');p.add_argument('--replay',nargs=3,type=int,metavar=('GRAPH','START','END'));args=p.parse_args()
 checks(1);expected=literal_eval(Path('orig-1.txt').read_text())
 assert expected[13]==(1408,3,(0,0,0,0,0,0))
 K=bm(8133^1408);inp=' '.join(str(sum(1<<i for i,p in enumerate(K)if p&s))for u,s in enumerate(stars)if u!=1)+'\n'
 assert Path('k.txt').read_text()==inp
 for e in TOPOLOGIES:
  rows,masks=validate(e)
  if args.generate:
   got=subprocess.run([str(Path(args.generate).resolve()),str(e)],input=inp,text=True,capture_output=True,check=True)
   assert got.stdout==Path(f'm3-{e}.txt').read_text()
  if args.replay and args.replay[0]==e:
   a,b=args.replay[1:];out=io.StringIO()
   with contextlib.redirect_stdout(out):
    for m in masks[a:b]:run(e,m)
   assert out.getvalue().splitlines()==rows[a:b]
 print('Six anonymous-source graphs, 33,443 raw mask triples, zero surviving allocations.')
if __name__=='__main__':main()
