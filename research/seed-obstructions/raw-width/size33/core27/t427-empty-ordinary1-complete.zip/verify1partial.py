from pathlib import Path
from ast import literal_eval
from partial import live
from starcase import fitstar,signatures
import stage,exactmask,flexmask,contextlib,io
def check():
 old=Path('orig-1.txt').read_text();stage.source(1);assert old==Path('orig-1.txt').read_text()
 rows=literal_eval(old);assert len(rows)==139
 for i,(z,n,ds)in enumerate(rows):
  if n<=1:assert live(1,z,n,ds)==[]
 two=[i for i,r in enumerate(rows)if r[1]==2];assert two==[7,8,9,10,11,12,25,37,56,75,93,115]
 for ids,mod,name in [(two[6:],exactmask,'t1-masks.log'),(two[:3],flexmask,'t1-flex.log')]:
  out=io.StringIO()
  with contextlib.redirect_stdout(out):
   for i in ids:
    for arc in (0,1):
     for a in range(0,128,8):mod.suite(1,i,arc,a,a+8)
  assert out.getvalue()==Path(name).read_text()
 for i in two:
  if i in (10,11,12):
   assert rows[i][:2]==rows[7][:2]and rows[i][2][-2:]==(0,0)and sum(rows[i][2])==1
   continue
  sig=signatures(i,('t1-masks.log','t1-flex.log'))
  if i not in (25,37,56):
   assert not sig
   continue
  for arc,m in sig:
   assert fitstar(1,*rows[i],m,2*arc,0,64) is None
 print('Only Z=1408 with three binary anonymous remains.')
if __name__=='__main__':check()
