from geometry import *
from holder import actual
from pathlib import Path
from operator import and_,or_
from functools import reduce
import sys
def run(e,a):
 X=[tuple(map(int,l.split()))for l in Path(f'm3-{e}.txt').read_text().splitlines()]
 xs=[m for m in X if m[0]==a and (e!=0 or m[0]<=m[1]<=m[2])and(e!=6 or m[1]<=m[2])and(e!=36 or m[0]<=m[1])]
 z=bm(1408);gr=[(p,)for p in z]+[(-1,),(-2,),(-3,)];E=[(3+i,3+j)for i in range(3)for j in range(i+1,3)if e>>(3*i+j)&1]
 def visit(xs):
  if not xs:return []
  lo=[[0]*3+[reduce(and_,a)for a in zip(*xs)]];hi=[[0]*3+[reduce(or_,a)for a in zip(*xs)]]
  if not actual((),[(p,1)for p in z],lo,E,gr,0,hi,1):return []
  if len(xs)==1:return xs
  _,k,b=max((min(n,len(xs)-n),i,b)for i in range(3)for b in range(7)if 0<(n:=sum(m[i]>>b&1 for m in xs))<len(xs))
  return visit([m for m in xs if m[k]>>b&1])+visit([m for m in xs if not m[k]>>b&1])
 result=visit(xs);print(e,a,len(xs),result,flush=True)
if __name__=='__main__':
 e,a,b=map(int,sys.argv[1:]);ms=sorted({int(l.split()[0])for l in Path(f'm3-{e}.txt').read_text().splitlines()})
 for m in ms[a:b]:run(e,m)
