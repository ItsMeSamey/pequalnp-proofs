#include <array>
#include <bit>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
int main(int argc,char**argv){
 int topology=stoi(argv[1]);int edges[3]{},out[3]{};
 for(int i=0;i<3;i++)for(int j=i+1;j<3;j++)if(topology&(1<<(3*i+j))){edges[j]|=1<<i;out[i]++;}
 int stars[6];for(int&x:stars)cin>>x;
 vector<int> dest[3];for(int i=0;i<3;i++)for(unsigned p=0;p<64;p++)if(popcount(p)==2-out[i])dest[i].push_back(p);
 vector<unsigned char> ok(1<<18);
 for(int a:dest[0])for(int b:dest[1])for(int c:dest[2]){
  int destinations[]={a,b,c};array<vector<int>,6> allowed;
  for(int x=0;x<8;x++){
   int cost=0,cover=0;for(int i=0;i<3;i++)if(x&(1<<i)){cost+=!(x&edges[i]);cover|=destinations[i];}
   for(int u=0;u<6;u++)if(cost+popcount(unsigned(stars[u]&~cover))<=2)allowed[u].push_back(x<<(3*u));
  }
  auto collect=[&](auto self,int u,int key)->void{if(u==6){ok[key]=1;return;}for(auto tag:allowed[u])self(self,u+1,key|tag);};
  collect(collect,0,0);
 }
 long count=0;
 for(int k=0;k<1<<18;k++)if(ok[k]){
  int m[3]{};for(int u=0;u<6;u++)for(int i=0;i<3;i++)if(k&(1<<(3*u+i)))m[i]|=1<<(u+(u>=1));
  bool active=true;for(int i=0;i<3;i++)for(int j=i+1;j<3;j++)if((edges[j]&(1<<i))&&!(m[i]&m[j]))active=false;
  if(active){cout<<m[0]<<" "<<m[1]<<" "<<m[2]<<"\n";count++;}
 }
 cerr<<topology<<" "<<count<<"\n";
}
