from pair import banks
from itertools import combinations
from collections import Counter
from cuts import DEGREE_ONE,extra
Z=sum(DEGREE_ONE);T={129,354,523,1046,2092,4160};library={1<<i for i in range(13)}|T
A=Counter()
for i,E in enumerate(combinations(DEGREE_ONE,2)):
 for j,R,C in banks:
  if i!=j or any(not R&p for p in set(DEGREE_ONE)-set(E)):continue
  if any(not c&~Z for c in C):
   A['inert']+=1;continue
  possible=[[d for d in library if not d&~c and (d^c)&~Z==0 and d&~Z]for c in C]
  assert all(len(k)==1 for k in possible)
  A[tuple(sorted({k[0]for k in possible}&T))]+=1
print('inert',A.pop('inert'),'clean',sum(A.values()),'bank_count',len(A));print('gap',set(T)-set(x for l in A for x in l))
