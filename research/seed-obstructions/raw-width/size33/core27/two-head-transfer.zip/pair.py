import sys,json
from pathlib import Path
from itertools import combinations
from collections import Counter
r=Path(__file__).resolve().parent
sys.path.insert(0,str(r))
from cuts import load,DEGREE_ONE,extra
banks=json.loads((r/'banks.json').read_text())
for i,E in enumerate(combinations(DEGREE_ONE,2)):
 P,N=load(E);a,b=sorted(set(DEGREE_ONE)-set(E))
 # For a mandatory comparison, positive and negative differ favorably on q alone and the negative activates its partner.
 witness=[p&~n for p in P for n in N if (p&a and n&b or p&b and n&a)]
 d=Counter()
 for j,R,C in banks:
  if j!=i:continue
  w=R|(127<<13)|sum(1<<extra[c]for c in C)
  if R&a and R&b:
   d['requires_distinct' if any(x&w in (a,b)for x in witness)else 'shared_open']+=1
  else:d['absent']+=1
 print(E,a,b,d)
