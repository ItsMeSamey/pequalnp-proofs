from geometry import *
from six import test,subs
from marks import profile
from holder import actual
from itertools import product
import sys
def go(C,t):
 M,_,b,*_=profile(C,(t,));s=6-len(C)
 out=test(P,N,8133,C,[sum(M)+sum(d)for d in subs(bm(8133^sum(M)),s-len(M))],t)
 for z,a,ds in out:
  Z=bm(z); groups=[(p,)for p in Z]+[(-1-i,) for i in range(a)]
  upper=[]
  for h in range(1<<len(C)):
   upper.append([sum(1<<u for u in range(7)if not (~pt[p]&line(inc[p])&on[u]&pack(lambda n:all(n&m for j,m in enumerate(C) if p&m or h>>j&1)))) for p in Z]+[127]*a)
  # Each named holder is high at some permitted pin. Its upper composite pin can always serve as witness.
  lo=[[0]*len(groups)for _ in upper]
  for codes in product(*[([sum(1<<h for h in range(len(upper)) if h&sum(1<<j for j,m in enumerate(C)if m&p)==sum(1<<j for j,m in enumerate(C)if m&p))] if p in M else [1<<(len(upper)-1)]) for p in Z]):
   prof=list(zip(Z,codes))
   # Overgrant point baseline 1 everywhere for cost exemptions, but require high only at the proved pins.
   print(C,t,z,a,ds,'STRUCT',flush=True)
   if any(ds):continue
   # Actual native named point can have additional baseline values; test all monotone tables.
   fam=[]
   for j,p in enumerate(Z):
    fam.append([f for f in range(1<<len(upper)) if f&codes[j]==codes[j] and all(not f>>h&1 or f>>k&1 for h in range(len(upper))for k in range(len(upper))if h&~k==0)])
   passes=[]
   for fs in product(*fam):
    if actual(C,list(zip(Z,fs)),lo,(),groups,s-len(groups),upper,ordinary=t):passes.append(fs)
   print(C,t,z,'RESULT',len(passes),passes[:4],flush=True)
for t in map(int,sys.argv[1:]):go((129,),t)
