from geometry import *
from marks import extra
from cps import enough
from itertools import combinations
from functools import cache
C=129;t=2;ordinary=stars[t];M=bm(ordinary)
alllabels=127^(1<<t)
def prove(z):
 Z=bm(z);other=bm(z^ordinary)
 def masked(p):
  return (pack(lambda n:not n&p and (not C&p or n&C))&line(inc[p]))
 assert all(masked(s)&pt[p] for s in Z for p in M if s!=p)
 assert all(pt[p]&meet[u]for u in range(7)for p in M)
 # After the ordinary-private clamp, all marked raw inputs and all six tags stay essential.
 H=meet[t]
 for p in M:assert H&masked(p)&line(inc[p]&alllabels)
 for u in range(7):
  if u!=t:assert any(H&pt[p] for p in bm(stars[u]))
 for hp in (0,1):
  h=H & (pack(lambda n:bool(n&C))if hp else alln)
  sp=[p for p in pts if not p&C or hp]
  # Raw holders/foreign mandatory darkness are checked on retained native negatives.
  goodowner=sum(1<<u for u in range(7)if u!=t and all(h&on[u]&meet[v]for v in range(7)if v not in (t,u)))
  for U in range(1,128):
   if U&~alllabels:continue
   rows=[p for p in sp if inc[p]&U not in (0,U) and all(h&pt[p]&on[u]for u in range(7)if U>>u&1 and not inc[p]>>u&1) and all(h&pt[p]&meet[u]for u in range(7)if u!=t)]
   for V in range(1,128):
    if V&~(U&goodowner):continue
    K=sum(p for p in rows if inc[p]&V and all(h&masked(p)&on[u] and h&line(inc[p]&U)&on[u] for u in range(7)if V>>u&1))
    bad=[(p,q)for p,q in combinations(bm(K),2)if inc[p]&U==inc[q]&U or not h&line(inc[p]&U)&line(inc[q]&U) or not h&(masked(p)&pt[q]|masked(q)&pt[p])]
    ks={K}
    for p,q in bad:ks={x for r in ks for x in ((r^p,r^q)if r&p and r&q else(r,))}
    for k in ks:
     gs=tuple(inc[p]&V for p in bm(k&~sum(other)))
     masks=[0 if k&p else sum(1<<u for u in range(7)if V>>u&1 and not h&masked(p)&on[u])for p in other]
     # Two known original auxiliaries can only disappear or lose reads.
     origmask=[sum(1<<u for u in range(7)if V>>u&1 and not masked(p)&on[u]&(pack(lambda n:bool(n&C))if hp else alln))for p in other]
     if not enough(gs,V,tuple((a,2)for a in origmask),0):return hp,U,V,k
for z in (2884,3844,6976):print(z,prove(z),flush=True)
