from ast import literal_eval
from pathlib import Path
from subprocess import check_output
import sys
def replay(args):return check_output([sys.executable,'-B','-u',*args],text=True)
src=Path('run.log').read_text().splitlines()
assert replay(['run.py','2']).splitlines()==[l for l in src if l.startswith('(129,) 2 ')]
s=literal_eval(Path('stage.log').read_text().splitlines()[1].split(' ',1)[1])
assert all((z,n,tuple(0 for _ in ds))in s for z,n,ds in s)
for f in ['clamp','anon','two','dedicated']:assert replay([f+'.py'])==Path(f+'.log').read_text()
assert Path('two.log').read_text().count('None')==3
assert not any('None' in Path(f+'.log').read_text()for f in ['clamp','anon','dedicated'])
assert check_output(['bash','named.sh'],text=True)==Path('named.log').read_text()
print('C129 ordinary2 at core cost 27: all named and anonymous housings excluded')
