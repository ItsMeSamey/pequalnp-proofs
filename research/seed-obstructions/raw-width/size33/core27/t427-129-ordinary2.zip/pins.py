from itertools import permutations,product
from geometry import *
from marks import extra
from holderconst import actual
import sys
t,z,a,base=map(int,sys.argv[1:5]);fs=tuple(map(int,sys.argv[5:]));ps=bm(z); C=(129,);groups=[(p,)for p in ps]+[(-k-1,)for k in range(a)];pr=list(zip(ps,fs))
def forb(p,h):return pack(lambda n:not n&p and (not (h or p&129) or n&129) and n>>13&inc[p])
hi=tuple(tuple(sum(1<<u for u in range(7)if u!=t and not forb(p,h)&on[u])for p in ps)+tuple([127^(1<<t)]*a)for h in range(2))
lo=tuple((0,)*len(groups)for _ in range(2));live=tuple(i for i,m in enumerate(hi[-1])if m)
nodes=0
def branch(L,U,edges):
 global nodes
 nodes+=1
 if not actual(C,pr,L,edges,groups,5-len(groups),U,ordinary=t,constant=base):return False
 choices=[(h,i,1<<u)for u in range(7)for i in live for h in range(2)if (U[h][i]^L[h][i])>>u&1]
 if not choices:return True
 h,i,b=choices[0]
 L1=tuple(tuple(x|b if k==i and st>=h else x for k,x in enumerate(row))for st,row in enumerate(L))
 U0=tuple(tuple(x&~b if k==i and st<=h else x for k,x in enumerate(row))for st,row in enumerate(U))
 return branch(L,U0,edges) or branch(L1,U,edges)
for order in permutations(live):
 edges=tuple((x,y)for i,x in enumerate(order)for y in order[i+1:])
 y=branch(lo,hi,edges)
 print(t,z,a,base,fs,order,y,nodes,flush=True)
 if y:break
