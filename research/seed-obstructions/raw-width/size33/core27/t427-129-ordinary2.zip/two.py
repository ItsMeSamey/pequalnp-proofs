from anon import *
for x in range(8):
 for y in range(x,8):
  marks=lambda j:sum(p for i,p in enumerate(M)if j>>i&1)
  S=[marks(j)for j in (x,y)]
  H=meet[t]
  for a in S:
   if a:H&=pack(lambda n:bool(n&a))
  ans=None;alive=S.count(0)
  for hp in (0,1):
   seen,h,F=masks_k(hp,H)
   for V,K in sorted(seen,key=lambda a:-a[1].bit_count()):
    gs=[inc[p]&V for p in bm(K)]
    if not price(gs,V,[(0,K,V)]*alive,[],0,bm(K)):
     ans=hp,V,K;break
   if ans:break
  print(*S,ans,flush=True)
