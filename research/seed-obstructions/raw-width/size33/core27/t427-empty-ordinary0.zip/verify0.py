from stage import source
from partial import live
from exactmask import suite
from ast import literal_eval
from pathlib import Path
import contextlib,io
saved=Path('orig-0.txt').read_text()
source(0)
assert saved==Path('orig-0.txt').read_text()
rows=literal_eval(saved)
assert len(rows)==27
for i,(z,n,ds) in enumerate(rows):
 if i!=3:assert n<=1 and not live(0,z,n,ds)
assert rows[3]==(708,2,(0,0,0,0,0,0))
buf=io.StringIO()
with contextlib.redirect_stdout(buf):
 for arc in (0,1):
  for x in range(0,128,8):suite(0,3,arc,x,x+8)
assert buf.getvalue()==Path('t0-masks.log').read_text()
assert all(l.endswith(' []') for l in buf.getvalue().splitlines())
print('All 27 original allocations excluded.')
