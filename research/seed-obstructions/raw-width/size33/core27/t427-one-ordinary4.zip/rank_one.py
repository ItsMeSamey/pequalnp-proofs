from itertools import product
import sys
from holder import actual
from geometry import *
from ast import literal_eval
from pathlib import Path
t=int(sys.argv[1])
for z,a,ds in literal_eval(Path(f'129-{t}.log').read_text().split(' ',3)[-1]):
 ps=bm(z);g=[(p,)for p in ps]+[(-1,)]*a
 for fs in product(*[(2,3)for p in ps]):
  up=[]
  for h in range(2):
   masks=[]
   for p in ps:
    f=pack(lambda n:not n&p and (not p&129 or n&129) and n>>13&inc[p] and (not h or n&129))
    masks.append(sum(1<<u for u in range(7)if u!=t and not f&on[u]))
   up.append(masks+[127^(1<<t)]*a)
  lo=[[0]*len(g)for h in range(2)]
  if actual((129,),list(zip(ps,fs)),lo,(),g,5-len(g)-sum(ds),up,ordinary=t):
   print('OPEN',z,a,fs,up,flush=True)
 print('DONE',z,a,flush=True)
