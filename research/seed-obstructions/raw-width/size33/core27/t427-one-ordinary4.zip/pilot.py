from six import *
from marks import profile
import sys
t=int(sys.argv[1]);c=(int(sys.argv[2]),)
P,N=load(tuple(DEGREE_ONE));R=8133;M=profile(c,(t,))[0];s=5
Z=[sum(M)+sum(x)for x in subs(bm(R^sum(M)),s-len(M))]
cases=test(P,N,R,c,Z,t)
print(c,t,len(cases),cases,flush=True)
