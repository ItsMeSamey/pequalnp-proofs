import sys
from itertools import permutations
from geometry import *
from marks import extra
from dormant_holder import actual
a,j,Z,an=129,4,3137,1
ms=(a,)
state=lambda p:sum(1<<k for k,m in enumerate(ms)if p&m)
ns=lambda n:sum(1<<k for k,m in enumerate(ms)if n>>extra[m]&1)
z=bm(Z);groups=[(p,)for p in z]+[(-1,)]*an
pr=[(p,sum(1<<k for k in range(2)if not state(p)&~k))for p in z]
def forbid(p,k):return pack(lambda n:not n&p and not(state(p)|k)&~ns(n) and n>>13&inc[p])
up=tuple(tuple(sum(1<<u for u in range(7)if u!=j and not forbid(p,k)&on[u])for p in z)+tuple([127^(1<<j)]*an)for k in range(2))
lo=tuple((0,)*len(groups)for _ in range(2))
live=tuple(i for i in range(len(groups))if up[1][i]);print('upper',up,'live',live,flush=True)
nodes=0
def branch(lo,up,edges):
 global nodes
 nodes+=1
 if not actual(ms,pr,lo,edges,groups,5-len(groups),up,ordinary=j):return False
 choices=[(k,i,1<<u)for u in range(7) for i in live for k in (0,1)if (up[k][i]^lo[k][i])>>u&1]
 if not choices:
  print('residual',lo,edges,flush=True);return True
 k,i,bit=choices[0]
 lower=tuple(tuple(x|bit if h==i and not k&~s else x for h,x in enumerate(row))for s,row in enumerate(lo))
 upper=tuple(tuple(x&~bit if h==i and not s&~k else x for h,x in enumerate(row))for s,row in enumerate(up))
 return branch(lo,upper,edges) or branch(lower,up,edges)
from itertools import product
for flags in product((2,3),repeat=len(z)):
 if any(flag!=3 for p,flag in zip(z,flags) if not p&129):continue
 pr=list(zip(z,flags))
 for order in permutations(live):
  nodes=0
  edges=tuple((x,y)for i,x in enumerate(order)for y in order[i+1:])
  print(flags,order,actual(ms,pr,lo,edges,groups,5-len(groups),up,ordinary=j),flush=True)
