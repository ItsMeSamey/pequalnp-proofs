import ast
from pathlib import Path
import subprocess
import sys
from six import load,DEGREE_ONE,extra
from itertools import product
C=(129,4160);P,N=load(tuple(DEGREE_ONE))
assert all(bool(x&m)==bool(x&(1<<extra[m]))for x in P+N for m in C)
def check(args):
 return subprocess.check_output([sys.executable,'-B',*map(str,args)],text=True)
args=(0,1,2,3,4,5,6)
raw=check(['run.py',*args]);assert raw==Path('run.log').read_text()
second=check(['more.py',1,2,3,5]);assert second==Path('more.log').read_text()
def entries(s):
 for l in s.splitlines():
  if ' RESULT 'in l:
   data=l.split(') ')[1];ts,zs,_,ns,ex=data.split(' ',4)
   if int(ns):yield int(ts),int(zs),int(ns)
assert list(entries(raw))==[(2,2817,3),(2,2880,3)]
assert list(entries(second))==[(1,1408,3),(2,2816,1),(3,5632,3),(5,6272,9)]
for z,fs in [(2817,(10,14,15)),(2880,(12,14,15))]:
 for f in fs:
  out=check(['refine.py',*C,2,z,0,f,15,15,15])
  assert 'True'not in out and ' False ' in out
for t,z,fs in [(1,1408,(10,15,15)),(2,2816,(15,15,15)),(3,5632,(15,15,12)),(5,6272,(10,15,12))]:
 for program in ['refine.py','const.py']:
  out=check([program,*C,t,z,1,*fs])
  assert 'True'not in out
  assert out.count(' False ')=={1:2,2:1,3:2,5:6}[t]
print('C129+4160 at 27 gates, 6 owners: every ordinary label excluded, including all anonymous high baselines')
