import sys
from itertools import permutations
from geometry import *
from marks import extra
from holder import actual
a,b,j,Z,an=map(int,sys.argv[1:6])
ms=(a,b)
state=lambda p:sum(1<<k for k,m in enumerate(ms)if p&m)
ns=lambda n:sum(1<<k for k,m in enumerate(ms)if n>>extra[m]&1)
z=bm(Z);groups=[(p,)for p in z]+[(-1,)]*an
pr=list(zip(z,map(int,sys.argv[6:])))
assert len(pr)==len(z)
def forbid(p,k):return pack(lambda n:not n&p and not(state(p)|k)&~ns(n) and n>>13&inc[p])
up=tuple(tuple(sum(1<<u for u in range(7)if u!=j and not forbid(p,k)&on[u])for p in z)+tuple([127^(1<<j)]*an)for k in range(4))
lo=tuple((0,)*len(groups)for _ in range(4))
live=tuple(i for i in range(len(groups))if up[3][i]);print('upper',up,'live',live,flush=True)
nodes=0
def branch(lo,up,edges):
 global nodes
 nodes+=1
 if not actual(ms,pr,lo,edges,groups,4-len(groups),up,ordinary=j):return False
 choices=[(k,i,1<<u)for u in range(7) for i in live for k in (0,3,1,2)if (up[k][i]^lo[k][i])>>u&1]
 if not choices:
  print('residual',lo,edges,flush=True);return True
 k,i,bit=choices[0]
 lower=tuple(tuple(x|bit if h==i and not k&~s else x for h,x in enumerate(row))for s,row in enumerate(lo))
 upper=tuple(tuple(x&~bit if h==i and not s&~k else x for h,x in enumerate(row))for s,row in enumerate(up))
 return branch(lo,upper,edges) or branch(lower,up,edges)
for order in permutations(live):
 edges=tuple((x,y)for i,x in enumerate(order)for y in order[i+1:])
 print('order',order,branch(lo,up,edges),'nodes',nodes,flush=True)
