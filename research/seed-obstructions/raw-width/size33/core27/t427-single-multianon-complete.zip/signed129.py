from singleroute import *
from physicalsocket import actual
from ast import literal_eval
K=bm(R^129);G=[(1,),(128,),(-1,),(-2,)]
def run(E,ds):
 req=lambda h,u:sum(1<<k for k,p in enumerate(K)if pincover[p][h]>>u&1)
 covers=[reduce(int.__or__,(d for i,d in enumerate(ds)if w>>i&1),0)for w in range(16)]
 send=[sum(1<<i for i in range(4)if w>>i&1 and not any(w>>j&1 for j,k in E if k==i))for w in range(16)]
 rawhi=[[s for s in range(16)if (not s&1 or 35>>u&1)and(not s&2 or 80>>u&1)and send[s].bit_count()+(req(1,u)&~covers[s]).bit_count()<=2]for u in range(7)]
 if any(not x for x in rawhi):return 0
 clean=sum(1<<i for i in range(4) if i<2 or any(all(s>>i&1 for s in d)for d in rawhi))
 lo=[[0]*4 for _ in range(2)];hi=[[0]*4 for _ in range(2)]
 it=[];dr=[]
 for u in range(7):
  rows=[]
  for h in rawhi[u]:
   for l in range(16):
    if l&~h&clean:continue
    seeds=send[l]|send[h];direct=(req(1,u)&~covers[h])|(req(0,u)&~covers[l])
    if seeds.bit_count()+direct.bit_count()<=2:rows.append((l,h,seeds,direct))
  if not rows:return 0
  for i in range(4):
   if all(r[2]>>i&1 for r in rows):it.append((u,i))
   for j in range(2):
    if all(r[j]>>i&1 for r in rows):lo[j][i]|=1<<u
    if not clean>>i&1 or any(r[j]>>i&1 for r in rows):hi[j][i]|=1<<u
  for k,p in enumerate(K):
   if all(r[3]>>k&1 for r in rows):dr.append((u,p))
 dest=[(i,p)for i,d in enumerate(ds)for k,p in enumerate(K)if d>>k&1]
 return sum(1<<k for k,fs in enumerate(product((2,3),repeat=2))if actual(C,list(zip((1,128),fs)),lo,E,G,0,hi,route=(dr,dest,it)))
def swap(e,d):
 p=(0,1,3,2)
 return tuple(sorted((p[i],p[j])for i,j in e)),tuple(d[i]for i in p)
if __name__=='__main__':
 a=set(map(literal_eval,Path('graph129poses.txt').read_text().splitlines()))
 assert all(swap(*r)in a for r in a)
 for e,d in sorted(a):
  if (e,d)<=swap(e,d):print((e,d),run(e,d),flush=True)
