from singleroute import *
from physicalsocket import actual
from ast import literal_eval
K=bm(R^65);groups=[(1,),(64,),(-1,),(-2,)];I=(0,2,3);E=((0,2),(2,3))
def options(ds,u):
 a=1<<u;upper=7 if a&35 else 6;out=[]
 for h in range(8):
  if h&~upper:continue
  for l in range(8):
   if l&~h:continue
   send=(l&~(l<<1))|(h&~(h<<1));direct=set()
   for t,s in enumerate((l,h)):
    for k,p in enumerate(K):
     if pincover[p][t]&a and not any(s>>i&1 and ds[i]>>k&1 for i in range(3)):direct.add(p)
   if len(direct)+send.bit_count()<=2:out.append((l,h,send,frozenset(direct)))
 return out
def run(ds):
 D=[options(ds,u)for u in range(7)]
 assert all(D)
 for i in range(3):
  assert any(all(x[1]>>i&1 for x in dom)for dom in D)
 forced=[]
 for i,w in enumerate(ds):
  for k,p in enumerate(K):
   if w>>k&1:
    d=list(ds);d[i]^=1<<k
    if any(not options(d,u) for u in range(7)):forced.append((I[i],p))
 count=0
 def node(D,fs,where):
  nonlocal count
  count+=1
  lo=[[0]*4 for _ in range(2)];hi=[[0]*4 for _ in range(2)]
  it=[];dr=[]
  for u,dom in enumerate(D):
   for i,reg in enumerate(I):
    if all(x[2]>>i&1 for x in dom):it.append((u,reg))
    for h in range(2):
     if any(x[h]>>i&1 for x in dom):hi[h][reg]|=1<<u
     if all(x[h]>>i&1 for x in dom):lo[h][reg]|=1<<u
   dr.extend((u,p)for p in set.intersection(*(set(x[3])for x in dom)))
  if not actual(C,list(zip((1,64),fs)),lo,E,groups,0,hi,site_override={128:where},route=(dr,forced,it)):return False
  if all(len(d)==1 for d in D):return True
  if count>=150:return None
  u=min((j for j in range(7)if len(D[j])>1),key=lambda j:len(D[j]))
  for x in D[u]:
   A=list(D);A[u]=[x];s=node(A,fs,where)
   if s is not False:return s
  return False
 for fs in product((2,3),repeat=2):
  for where in ([8],list(range(7))+[11]):
   s=node(D,fs,where)
   if s is not False:return (s,count,fs,where,forced)
 return False,count,forced
if __name__=='__main__':
 for e,d in literal_eval(Path("graph65poses.txt").read_text()):
  if e==((0,1),(1,2)):print(e,d,run(d),flush=True)
  elif e!=((0,2),(2,1)):print("UNTESTED",e,d,flush=True)
