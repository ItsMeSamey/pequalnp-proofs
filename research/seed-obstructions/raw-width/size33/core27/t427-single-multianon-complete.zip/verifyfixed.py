from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
import subprocess,sys
with ZipFile('upstream.zip')as a:
 a.extract('singlecross.py');a.extract('singlecross.log')
 with ZipFile(BytesIO(a.read('predecessor.zip')))as b:
  for f in b.namelist():
   if f!='verify.py':b.extract(f)
def output(f):return subprocess.check_output([sys.executable,'-B',f+'.py'])
assert output('singlecross')==Path('singlecross.log').read_bytes()
from singleroute import pincover,bm,R,inc
assert all(pincover[p]==[0 if p in (1,128) else inc[p],inc[p]]for p in bm(R))
from ast import literal_eval
for name in ('5','65'):
 gn='graph'+name;cn='chains'+name
 out=output(gn);q=literal_eval(Path(gn+'poses.txt').read_text())
 assert len(q)==6 and all(e in (((0,1),(1,2)),((0,2),(2,1)))for e,d in q)
 from importlib import import_module
 m=import_module(cn)
 for e,d in q:
  if e!=((0,1),(1,2)):continue
  for i in range(3):
   assert any(not any(not(w>>i&1) and (not w&1 or 35>>u&1) and (w&~(w<<1)).bit_count()+sum(1 for k,p in enumerate(m.K)if inc[p]>>u&1 and not any(w>>j&1 and d[j]>>k&1 for j in range(3)))<=2 for w in range(8)) for u in range(7))
 a=output(cn);assert (out+a if name=='65' else a)==Path(cn+'.log').read_bytes()
assert output('graph129').strip()==b'EXHAUSTED 234'
assert output('signed129')==Path('signed129.log').read_bytes()
assert len(Path('signed129.log').read_text().splitlines())==117 and all(s.endswith(' 0') for s in Path('signed129.log').read_text().splitlines())
print('All 48/48 allocations with at least two anonymous helpers excluded.')
