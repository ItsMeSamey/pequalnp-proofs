from singleroute import *
from time import monotonic
from pathlib import Path
def run():
 K=bm(R^129);v=IDPool();act=range(4);U=(35,80,127,127)
 with Solver(name='cadical195')as sat,open('graph129poses.txt','w',buffering=1)as fp:
  add=sat.add_clause
  def cap(X,k):sat.append_formula(CardEnc.atmost(X,k,vpool=v).clauses)
  def both(a,b):
   t=v.id();add([-t,a]);add([-t,b]);add([t,-a,-b]);return t
  E={(i,j):v.id()for i,j in permutations(act,2)}
  O={(i,j):v.id()for i,j in E}
  for (i,j),t in E.items():add([-t,O[i,j]]);add([-O[i,j],-O[j,i]])
  for i,j,k in permutations(act,3):add([-O[i,j],-O[j,k],O[i,k]])
  dest={(i,p):v.id()for i in act for p in K}
  for i in act:cap([e for (k,j),e in E.items()if k==i]+[e for (k,p),e in dest.items()if k==i],2)
  for u in range(7):
   sig=[v.id()for i in act];ins=[v.id()for i in act]
   direct={p:v.id()for p in K if inc[p]>>u&1}
   cap(ins+list(direct.values()),2)
   for i in act:
    if not U[i]>>u&1:add([-sig[i]])
    add([-sig[i],ins[i]]+[both(E[j,i],sig[j])for j in act if i!=j])
   for p,y in direct.items():add([y]+[both(dest[i,p],sig[i])for i in act])
  S=list(E.values())+list(dest.values());num=0;start=monotonic()
  while sat.solve():
   s=set(sat.get_model());ep=tuple((i,j) for (i,j),a in E.items()if a in s)
   d=tuple(sum(1<<k for k,p in enumerate(K)if dest[i,p]in s)for i in act)
   print((ep,d),file=fp);num+=1
   add([-x if x in s else x for x in S])
   if monotonic()-start>12:print('CAPPED',num,flush=True);return
  print('EXHAUSTED',num,flush=True)
if __name__=='__main__':run()
