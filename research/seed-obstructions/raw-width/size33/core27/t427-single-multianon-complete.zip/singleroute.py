from singlecross import *
from itertools import permutations
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
pincover={p:[reduce(int.__or__,[v&inc[p]for v,k in layer if k&p],0)for layer in CC]for p in bm(R)}
def route(z,g,ds,B,pos):
 U=[reduce(int.__and__,(UP[p]for p in bm(b)),127)for b in B]
 active=[i for i,u in enumerate(U)if u]
 K=[p for p in bm(R^z)if not any(p&B[i]for i in active) and pincover[p][pos[p]]==inc[p]]
 assert all(p not in K or q not in K for p,q in bad)
 v=IDPool()
 with Solver(name='cadical195') as sat:
  add=sat.add_clause
  def cap(xs,k):
   if len(xs)>k:sat.append_formula(CardEnc.atmost(xs,k,vpool=v).clauses)
  def both(a,b):
   t=v.id();add([-t,a]);add([-t,b]);add([t,-a,-b]);return t
  E={(i,j):v.id()for i in active for j in active if i!=j}
  order={(i,j):v.id()for i in active for j in active if i!=j}
  for (i,j),x in E.items():add([-x,order[i,j]]);add([-order[i,j],-order[j,i]])
  for i,j,k in permutations(active,3):add([-order[i,j],-order[j,k],order[i,k]])
  dest={(i,p):v.id()for i in active for p in K}
  for i in active:cap([dest[i,p]for p in K]+[e for (k,_),e in E.items()if k==i],2+ds[i])
  ages={}
  for h in range(2):
   for i in active:
    m=127
    for p in bm(B[i]):
     f=pack(lambda n:not n&p and n>>13&inc[p] and (n>>extra[129]&1 or not(h or p&129)))
     m&=sum(1<<u for u in range(7)if not f&on[u])
    for u in range(7):
     q=v.id();ages[h,i,u]=q
     if not m>>u&1:add([-q])
  direct={(u,p):v.id()for u in range(7)for p in K if inc[p]>>u&1}
  for u in range(7):
   ins={i:v.id()for i in active}
   cap(list(ins.values())+[x for (k,p),x in direct.items()if k==u],2)
   for h in range(2):
    for i in active:add([-ages[h,i,u],ins[i]]+[both(E[j,i],ages[h,j,u])for j in active if j!=i])
   for p in K:
    if (u,p)in direct:add([direct[u,p]]+[both(dest[i,p],ages[pos[p],i,u])for i in active])
  sat.conf_budget(5000);return sat.solve_limited()
if __name__=='__main__':
 for z,g in [(5,2),(65,2),(129,2),(1409,0),(2817,0),(5633,0),(6273,0)]:
  ds=(0,0,0,0);remaining=[]
  for ass,B in screen(z,g,ds):
   pset=bm(R^z);choices=[[h for h,w in enumerate(pincover[p])if w==inc[p]]for p in pset]
   for t in product(*choices):
    pos=dict(zip(pset,t));ans=route(z,g,ds,B,pos)
    if ans is False:break
   else:remaining.append(B)
  print(z,g,len(remaining),remaining,flush=True)
