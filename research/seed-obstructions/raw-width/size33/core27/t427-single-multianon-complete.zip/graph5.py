from itertools import combinations,product,permutations
from collections import Counter
from pathlib import Path
rows=(17,35,70,13,26,52,104)
target=tuple(sum(1<<p for p,r in enumerate(rows)if r>>u&1)for u in range(7));upper=(35,127,127)
def run():
 totals=Counter();seen=set();survivors=[]
 for order in permutations(range(3)):
  full=list(combinations(order,2))
  for mask in range(8):
   E=tuple(sorted((i,j)for k,(i,j) in enumerate(full)if mask>>k&1))
   if E in seen:continue
   seen.add(E);f=tuple(2-sum(i==k for i,j in E)for k in range(3))
   choices=[tuple(sum(1<<i for i in c)for c in combinations(range(7),q))for q in f]
   req=[]
   for u,t in enumerate(target):
    opt=set()
    for seed in range(8):
     if seed.bit_count()>2 or any(seed>>j&1 and not upper[j]>>u&1 for j in range(3)):continue
     reach=seed
     for i in order:
      if reach>>i&1:
       for j in range(3):
        if (i,j)in E and upper[j]>>u&1:reach|=1<<j
     opt.add((reach,2-seed.bit_count()))
    req.append((t,sorted(opt)))
   for ds in product(*choices):
    totals[len(E),False]+=1;a,b,c=ds;cov=(0,a,b,a|b,c,a|c,b|c,a|b|c)
    if all(any((t&~cov[r]).bit_count()<=n for r,n in opt)for t,opt in req):
     totals[len(E),True]+=1;survivors.append((E,ds))
 print(sorted(totals.items()),'surviving completions',len(survivors),flush=True)
 Path('graph5poses.txt').write_text(repr(survivors))
if __name__=='__main__':run()
