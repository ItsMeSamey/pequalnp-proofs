from pysat.formula import IDPool
from pysat.solvers import Glucose4
from localkw import LocalRectangle
def control(fn,repeat):
 pool=IDPool();var=lambda *k:pool.id(k);val=lambda h,i:var('v',h,i);edge=lambda h,d:var('e',h,d)
 h=3;vs=list(range(8));sig=[0]*12;own=[0]*12;own[h]=4 if repeat else 7
 with Glucose4()as sat:
  C=[var('C',i)for i in range(12)];sat.add_clause([-C[h]])
  opts=[[]for _ in range(11)]
  if repeat:
   for s in (0,1):
    opts[s]=[h];sat.add_clause([edge(s,h)])
    for j,p in enumerate(vs):sat.add_clause([val(s,j)if p>>s&1 else -val(s,j)])
  for j,p in enumerate(vs):
   b=fn(p);sig[h]|=int(b)<<j;sat.add_clause([val(h,j)if b else -val(h,j)])
  rec=LocalRectangle(h,sat,var,edge,val,C,opts,vs,own,[0]*12,[0]*12)
  while sat.solve():
   if not rec.check(set(sat.get_model()),sig):return True
  return False
assert control(lambda p:bool(p&4 and p&3),False)
assert not control(lambda p:p.bit_count()>=2,False)
assert control(lambda p:p.bit_count()>=2,True)
print('conditional hub rectangle controls pass')
