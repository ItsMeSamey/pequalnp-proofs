from pathlib import Path
from ast import literal_eval as ev
def parse(file):
 l=next(l for l in Path(file).read_text().splitlines() if l.startswith('(129,) '));return ev(l[7:].split(' ',1)[1])
opts=parse('third.log')
