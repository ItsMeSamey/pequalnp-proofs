from itertools import combinations
class Rectangle:
 def __init__(self,sat,var,edge,val,location,opts,P,N,housing,pos,neg):
  self.sat=sat;self.var=var;self.n=len(N);self.np=len(P);self.ends=[];self.cells=set()
  for h in range(11):
   if 11 not in opts[h]:continue
   for k in range(2):
    relay=var('tile',h,k);sat.add_clause([-relay,edge(h,11)])
    if k:
     for dest in opts[h]:
      if dest!=11:sat.add_clause([-relay,-edge(h,dest)])
    a=[];b=[]
    for idx in range(len(P)+len(N)):
     p=idx<len(P);fixed=neg[h]if p else pos[h]
     x=0 if fixed>>idx&1 else var('member',h,k,idx)
     if x:sat.add_clause([-x,relay]);sat.add_clause([-x,val(h,idx)if p else -val(h,idx)])
     (a if p else b).append(x)
    self.ends.append((a,b))
  for raw in [j for j in range(13)if housing[-1]>>j&1]+[20]:
   a=[];b=[]
   for idx,r in enumerate(P+N):
    p=idx<len(P);bit=bool(r&(129 if raw==20 else 1<<raw))
    x=var('rawmember',raw,idx) if bit==p else 0
    if x and raw==20:sat.add_clause([-x,location[11]])
    (a if p else b).append(x)
   self.ends.append((a,b))
 def cut(self,p,n):
  assert(p,n)not in self.cells
  self.cells.add((p,n));a=self.sat.add_clause;atoms=[]
  for i,(v,w) in enumerate(self.ends):
   b,c=v[p],w[n]
   if not b or not c:continue
   x=self.var('kwcell',p,n,i);a([-x,b]);a([-x,c]);a([x,-b,-c]);atoms.append(x)
  a(atoms)
  for x,y in combinations(atoms,2):a([-x,-y])
 def check(self,model,budget=56):
  ns=[sum(1<<j for j,x in enumerate(w)if x and x in model)for v,w in self.ends]
  total=0;alln=(1<<self.n)-1
  for i in range(self.np):
   seen=0;dup=0
   for j,(a,b)in enumerate(self.ends):
    if a[i] and a[i]in model:dup|=seen&ns[j];seen|=ns[j]
   bad=(alln^seen)|dup;cnt=0
   while bad and cnt<4:
    lb=bad&-bad;self.cut(i,lb.bit_length()-1);bad-=lb;cnt+=1;total+=1
   if total>=budget:break
  return total
