from smallfn import tables
f=sum(1<<x for x in range(8)if x.bit_count()>=2)
assert f not in tables((2,1,1)) and f in tables((2,2,1))
# Full model guarding the read-once cut: both these original arcs true.
# Losing the second sender's other edge permits the new duplicate.
from pysat.solvers import Glucose4
with Glucose4(bootstrap_with=[[-1,-2],[1],[-2]])as s:assert s.solve()
print('four-leaf rejection preserves five-leaf majority after a split changes')
