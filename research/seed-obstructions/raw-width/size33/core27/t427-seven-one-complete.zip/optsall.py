from single import *
import optshouse
from optshouse import actual
import json,sys
from lateholder import actual as ordered
from itertools import product
def test(i):
 z,n,ds=opts[i];names=bm(z);gs=[(q,)for q in names]+[(-1,)];sp=4-len(gs)-sum(ds)
 for s in [1]:
  print("mask",i,s,flush=True)
  baseline=[tuple([0]*len(gs)),tuple([0]*len(names)+[s])]
  upper=[tuple([sum(1<<u for u in range(7) if not ((~pt[p]) & line(inc[p]) & on[u] & (E if h or p&C else alln)))for p in names]+[s]) for h in (0,1)]
  # All named sources may feed the anonymous origin. Foreign owner cofactor fallback is conservatively granted via suppressing the sender lower bound where applicable.
  if any(s>>u&1 and not foreign[u] for u in range(7)):
   baseline[1]=tuple([0]*len(gs))
  edges=tuple((j,len(names))for j in range(len(names)))
  for f in [(2,3,3),(3,3,3)]:
   lows=[i for i,b in enumerate(f) if b==2]
   if len(lows)>1:continue
   ls=list(baseline)
   if lows:
    q=lows[0];forced=s&~upper[1][q]
    ls[0]=tuple([0]*len(names)+[forced])
   optshouse.CANDIDATES=[d['housing'] for d in source if tuple(d['f'])==f and list(d['housing'][7:10])==names]
   for last in range(7):
    for m in range(16):
     key=(i,*f,last,m)
     if key in done:continue
     late=tuple(h+7 for h in range(4)if m>>h&1)
     if last==0 and 10 not in late:
      print("done",*key,flush=True);continue
     actual((C,),list(zip(names,f)),ls,edges,gs,sp,upper,last=last,late=late)
     print("done",*key,flush=True)
if __name__=='__main__':
 print("bare-C-dark",all(E&m for m in meet),[(p,bool(E&~pt[p]&line(inc[p]))) for p in pts],flush=True)
 source=[json.loads(l)for l in open("allhouses.log")if l.startswith("{")]
 done=set()
 for file in sys.argv[1:]:
  done.update(tuple(map(int,l.split()[1:]))for l in open(file)if l.startswith("done "))
 for i in (65,118):print(i,test(i),flush=True)
