# Seven mandatory line owners and one anonymous repeated source

This certificate covers the 68 one-anonymous layouts for the four-peeled size-27 core and C129. Signed symmetry transports its conclusion to C4160. The 120-layout native inventory in third.log is an upstream dependency. The raw sample is regenerated from L-meta-18968.json.

README-one.md details the reduction to IDs 65 and 118. In each, three named binary sources and one binary anonymous X supplement the seven mandatory owners. On the high composite pin X is dark on bare C and has exactly tag-zero singleton support. The three named native point flags are (2,3,3) or (3,3,3), granting high-only or both-pin activation at each held point. With one flag 2 the sole raw C socket is in that named region. With all flags 3 the solver chooses among all twelve possible raw C locations.

Unordered native receiver ranks allow 48 housings across these four modes. Choose the last mandatory owner and which auxiliaries follow it. The 448 choices yield 352 housing/mode/order records. Each JSON row in temporal.jsonl.gz gives the physical point housing, forced positive/negative values for each signal, and possible counts of direct reads at the root. A signed comparison differing favorably solely on primitives held at one region forces that region to distinguish the pair. Monotonicity extends these marks over raw coordinates conservatively granted upstream. This gives opposing forced truth values in 284 records. Each of the remaining 68 is checked separately.

optsall.py enumerates the possible sets of physical consumers for each mandatory owner. Charge at least one occurrence per receiving nonroot region, or its signed local rank if larger, and the larger of the local and root-conditional ranks for the root. Enumerate every placement of exactly two output occurrences within budget. Both can enter the same destination. With no nonroot receiver, both enter the root.

clean.py permits all acyclic region graphs with the specified ordering and receiver sets. Each nonroot output has two occurrences. Two distinct destinations receive one occurrence each. A sole destination receives both. Each origin has an unknown Boolean value on every signed row and every specified cofactor probe. A region high at a and low at b requires a primitive or an actual predecessor separating them in that direction. If C distinguishes the pair the clause permits its placement in that region. The solver adds violated conditions lazily.

For regions of up to five leaves the solver enumerates all AND/OR trees on the exact multiset of operands. If no tree fits the observed rows, the learned clause permits any change of the entire region graph, the raw C location, or any operand or output truth value used by the witness. This guards changes in whether two occurrences of a source enter the same region. The final solver omits the coarse leaf-count pruning used during discovery. aliascontrol.py checks that majority first excluded at multiplicities (2,1,1) becomes feasible at (2,2,1).

At the root each physical input occurrence contributes at most one rectangle to a disjoint partition of the positive-by-negative pairs. At an OR gate the formula protocol chooses a child true at the positive row, and at an AND gate a child false at the negative row. Deterministic choices partition the pairs into rectangles labelled by the corresponding leaves. jointroot.py couples each tile to its actual physical input. A second tile from an origin requires both output occurrences at the root. Positive and negative memberships imply the source's truth and falsity. A C tile requires the root C socket. The solver enforces exact cover on violated cells.

The same partition requirement applies inside D1 in layout 65 and D5 in layout 118. localkw.py conditions its obligations on the chosen local output values for the two rows. Each tile is coupled to a raw local input or an actual predecessor, with its true multiplicity and signed values. All partitions are required within the same trace and physical graph.

## Replay

Use Python 3 and python-sat. From the archive root run

    python verify.py initial 0 120
    python verify.py modes
    python verify.py tables
    python verify.py controls
    python verify.py ledger
    python verify.py final 105

The final command accepts any list of zero-based temporal keys. Set CHECK_DRAT=1 and DRAT_CHECKER to a drat-trim executable for independent proof replay. Optionally set CERT_TMP and CERT_KEEP for temporary storage and retained final CNF and proof outputs.

## Verified outcome

The fresh corrected replay excluded all 68 internally consistent keys. verified.log contains exactly one final verdict for each. clean.py handles 62 keys. On 105, 106, 107, 280, 282 and 283, earlyclean.py adds the same conditional hub rectangle clauses sooner and checks pairs with fewer distinguishing operands first. This changes search order only. Thus the 284 opposing native marks and 68 SAT exclusions exhaust the 352 ordered records, completing the C129 one-anonymous class. The corrected proof pilot, when supplied, is identified by proof105_corrected.log. The withdrawn discovery proof is excluded from this release.
