from functools import cache
@cache
def tables(mult):
 n=len(mult);W=1<<n
 atoms=[sum(1<<k for k in range(W)if k>>j&1)for j in range(n)]
 leaves=sum(([i]*m for i,m in enumerate(mult)),[])
 @cache
 def gen(mask):
  if not mask&(mask-1):return {atoms[leaves[mask.bit_length()-1]]}
  out=set();a=(mask-1)&mask
  while a:
   b=mask^a
   if a<b:
    for l in gen(a):
     for r in gen(b):out.add(l&r);out.add(l|r)
   a=(a-1)&mask
  return out
 return tuple(sorted(gen((1<<len(leaves))-1)))
def obstruction(mult,observations):
 fs=tables(mult);live=(1<<len(fs))-1;choices=[]
 for (x,y),r in observations.items():
  keep=sum(1<<j for j,f in enumerate(fs)if f>>x&1==y)
  choices.append((keep,r))
 while live:
  b=min(choices,key=lambda el:(live&el[0]).bit_count())
  if live&b[0]==live:return []
  yield b[1];live&=b[0]
