from single import *
from holder import actual
from orderholder import actual as ordered
from itertools import product
def test(i):
 z,n,ds=opts[i];names=bm(z);gs=[(q,)for q in names]+[(-1,)];sp=4-len(gs)-sum(ds)
 for s in run(z,ds,1):
  ls=[tuple([0]*len(gs)),tuple([0]*len(names)+[s])]
  upper=[tuple([sum(1<<u for u in range(7) if not ((~pt[p]) & line(inc[p]) & on[u] & (E if h or p&C else alln)))for p in names]+[s]) for h in (0,1)]
  # All named sources may feed the anonymous origin. Foreign owner cofactor fallback is conservatively granted via suppressing the sender lower bound where applicable.
  if any(s>>u&1 and not foreign[u] for u in range(7)):
   ls[1]=tuple([0]*len(gs))
  edges=tuple((j,len(names))for j in range(len(names)))
  for f in product((2,3),repeat=len(names)):
   if actual((C,),list(zip(names,f)),ls,edges,gs,sp,upper):
    for last in range(7):
     for m in range(1<<len(gs)):
      late=tuple(j+7 for j in range(len(gs))if m>>j&1)
      if ordered((C,),list(zip(names,f)),ls,edges,gs,sp,upper,last=last,late=late):return s,f,last,late
if __name__=='__main__':
 for i in (65,118,46):print(i,test(i),flush=True)
