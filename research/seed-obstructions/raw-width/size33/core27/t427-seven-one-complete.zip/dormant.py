from tight import *
from dormant_holder import actual
def check(i):
 z,n,ds=opts[i];names=bm(z);gs=[(p,)for p in names]+[(-1,)]
 upper=[tuple([sum(1<<u for u in range(7) if not (~pt[p]&line(inc[p])&on[u]&(E if h or p&C else alln))) for p in names]+[127])for h in range(2)]
 lo=[tuple(0 for _ in gs)]*2
 for f in product((2,3),repeat=len(names)):
  if actual((C,),list(zip(names,f)),lo,(),gs,4-len(ds)-sum(ds),upper,dormant=True):return f
if __name__=='__main__':
 for l in open('single.log'):
  v=l.split();i=int(v[0])
  if v[-2:]==['True','True']:print(i,check(i),flush=True)
