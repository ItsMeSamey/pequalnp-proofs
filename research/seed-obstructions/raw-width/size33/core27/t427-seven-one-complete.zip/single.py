from charge import *
from domains import *
from functools import cache
@cache
def domains(hp,S):
 h=(E if hp else alln)&(alln if not S else line(S))
 F={p:h&~pt[p]&line(inc[p])&(E if p&C else alln)for p in pts}
 res=[[]for _ in range(7)]
 for u in range(7):
  if not all(h&on[u]&meet[v]for v in range(7)if v!=u):continue
  A=[p for p in bm(stars[u])if (hp or not p&C) and all(h&pt[p]&g for g in meet)and F[p]&on[u]]
  for k in range(len(A),0,-1):
   for g in combinations(A,k):
    K=sum(g)
    if any(not K&~v for v in res[u]):continue
    if all(any(h&on[v]&pt[b]for a,b in ((p,q),(q,p))for v in range(7)if inc[a]>>v&1 and not inc[b]>>v&1)for p,q in combinations(g,2)):res[u].append(K)
 return res,F
@cache
def bills(z,ds,hp,S):
 Z=bm(z);rows,F=domains(hp,S);out=[]
 for u,groups in enumerate(rows):
  ml=0
  for K in groups:
   omissions=[sum(p for p in bm(K)if q==p or (not hp)or not F[p]&pt[q])for q in Z]
   vs={K:0}
   for j,q in enumerate(Z):
    nxt={}
    can=not (F[q]&on[u])
    for k,credit in vs.items():
     nxt[k]=max(nxt.get(k,0),credit+(1+ds[j]if can else 0))
     for p in bm(k&omissions[j]):nxt[k^p]=max(nxt.get(k^p,0),credit)
    vs=nxt
   ml=max(ml,min(k.bit_count()-v for k,v in vs.items()))
  out.append(ml)
 return tuple(out)
def run(z,ds,hp):
 # Z are the only named positive omissions. For a true anonymous tag cofactor rising from zero, an incoming raw owner path is compulsory.
 pre=bills(z,ds,hp,0);Z=bm(z);_,fn=domains(hp,0);x=1+ds[-1];sp=4-len(ds)-sum(ds);ans=[]
 for s in range(128):
  if sum(max(0,v-2-(x if s>>u&1 else 0))for u,v in enumerate(pre))>sp:continue
  if not s:ans.append(s);continue
  post=bills(z,ds,hp,s)
  direct=sum(max(0,v-2+int(bool(s>>u&1) and (not hp or foreign[u]) and all(fn[q]&on[u]for q in Z)))for u,v in enumerate(post))
  if direct<=sp:ans.append(s)
 return ans
if __name__=='__main__':
 import sys
 for i,(z,n,ds) in enumerate(opts):
  if n!=1 or i<int(sys.argv[1]):continue
  a,b=run(z,ds,0),run(z,ds,1)
  # A composite-only high anonymous is forced high on negatives in the source high pin; it contributes no usable tag distinctions there.
  const=sum(max(0,v-2)for v in bills(z,ds,1,0))<=4-len(ds)-sum(ds)
  live=any(not l&~h for l in a for h in b)or const and bool(a)
  print(i,z,ds,len(a),len(b),const,live,flush=True)
