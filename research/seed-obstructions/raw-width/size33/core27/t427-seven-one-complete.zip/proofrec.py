"""Optional independent DRAT replay of the ordinary CNF accumulated by the search."""
import os,shutil,subprocess,tempfile
from pathlib import Path
from pysat.solvers import Glucose4
class Recorded:
 def __init__(self):
  self.solver=Glucose4();self.tmp=tempfile.TemporaryDirectory(dir=os.environ.get('CERT_TMP'))
  self.root=Path(self.tmp.name);self.body=(self.root/'body').open('w');self.nv=self.nc=0
 def add_clause(self,c):
  self.solver.add_clause(c)
  self.nv=max(self.nv,max((abs(x)for x in c),default=0));self.nc+=1
  self.body.write(' '.join(map(str,c))+' 0\n')
 def solve(self):return self.solver.solve()
 def get_model(self):return self.solver.get_model()
 def verify(self):
  self.solver.delete();self.body.close()
  cnf=self.root/'final.cnf'
  with cnf.open('w')as out,(self.root/'body').open()as inp:
   out.write(f'p cnf {self.nv} {self.nc}\n');shutil.copyfileobj(inp,out)
  with Glucose4(with_proof=True)as fresh,(self.root/'body').open()as inp:
   for l in inp:fresh.add_clause([int(w)for w in l.split()[:-1]])
   assert fresh.solve()is False
   drat=self.root/'final.drat';drat.write_text('\n'.join(fresh.get_proof())+'\n')
  checker=os.environ.get('DRAT_CHECKER','drat-trim')
  p=subprocess.run([checker,str(cnf),str(drat)],capture_output=True)
  assert p.returncode==0 and b's VERIFIED'in p.stdout,p.stdout[-1000:]
  print('VERIFIED',self.nv,self.nc,drat.stat().st_size,flush=True)
  if os.environ.get('CERT_KEEP'):
   import hashlib
   out=Path(os.environ['CERT_KEEP']);out.mkdir(exist_ok=True)
   for f in (cnf,drat):
    assert f.stat().st_size<40*1024*1024
    print(f.name,hashlib.sha256(f.read_bytes()).hexdigest(),f.stat().st_size,flush=True)
    shutil.copyfile(f,out/f.name)
  self.tmp.cleanup()
