import sys
from single import run,bills,opts
from tight import test
from order import test as ordered
from dormant import check
for i in range(*map(int,sys.argv[1:])):
 z,n,ds=opts[i]
 if n!=1:continue
 a,b=run(z,ds,0),run(z,ds,1)
 spare=4-len(ds)-sum(ds)
 const=bool(a) and sum(max(0,v-2)for v in bills(z,ds,1,0))<=spare
 if const:assert i==46
 normal=any(not l&~h for l in a for h in b)
 if normal:normal=bool(ordered(i)if i==46 else test(i))
 if const:const=bool(check(i))
 print(i,normal,const,flush=True)
 assert bool(normal or const)==(i in (65,118))
