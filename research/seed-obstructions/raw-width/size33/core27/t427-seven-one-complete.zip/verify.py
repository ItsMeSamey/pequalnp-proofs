import collections,gzip,json,os,subprocess,sys
from pathlib import Path
os.chdir(Path(__file__).resolve().parent)
def call(*xs):return subprocess.check_output([sys.executable,*map(str,xs)],text=True)
def objects(s):return [json.loads(l)for l in s.splitlines()if l.startswith('{')]
def norm(ds):return collections.Counter(json.dumps(d,sort_keys=True)for d in ds)
def known():return list(map(json.loads,gzip.open('temporal.jsonl.gz','rt')))
def consistent(d):return not any(x&y for k in ('pos','neg')for x,y in zip(d[k+'zero'],d[k+'one']))
cmd,*args=sys.argv[1:]
if cmd=='initial':print(call('replay_one.py',*args),end='')
elif cmd=='modes':
 a=call('modes.py');assert [l for l in a.splitlines()if l.startswith('pass ')]==[l for l in Path('modes.log').read_text().splitlines()if l.startswith('pass ')]
 print('Four native modes')
elif cmd=='tables':
 a=objects(call('allhouses.py'));assert len(a)==48 and norm(a)==norm(objects(Path('allhouses.log').read_text()))
 a=objects(call('fastall.py'));assert len(a)==352 and norm(a)==norm(known())
 a=objects(call('optsall.py'));assert len(a)==352 and norm(a)==norm(objects(Path('optsall.log').read_text()))
 print('48 source housings and 352 ordered trace/port records regenerated')
elif cmd=='final':
 ds=known()
 for arg in args:
  i=int(arg);d=ds[i]
  if not consistent(d):print(i,'forced trace contradiction');continue
  a=call('earlyclean.py' if i in (105,106,107,280,282,283) else 'clean.py',i,7 if d['f'][0]==2 else -1,'optsall.log');print(a,end='',flush=True)
  assert a.splitlines()[-1].startswith("('UNSAT',")
elif cmd=='controls':
 for fn in ('aliascontrol','kwcontrol','localcontrol'):print(call(fn+'.py'),end='')
elif cmd=='ledger':
 ds=known();assert len(ds)==352;live={i for i,d in enumerate(ds)if consistent(d)};assert len(live)==68
 done=set()
 for l in Path('verified.log').read_text().splitlines():
  if l.startswith('result ') and "('UNSAT',"in l:done.add(int(l.split()[1]))
 assert done==live,(done-live,live-done)
 print('284 contradictory native trace records and 68 definite UNSAT solver records')
else:raise ValueError(cmd)
