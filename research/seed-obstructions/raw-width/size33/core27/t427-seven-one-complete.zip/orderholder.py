from geometry import *
from itertools import combinations_with_replacement
@cache
def shapes(n):
 return [(0,a,b) if a&b else (0,a,b,a|b)for a,b in combinations_with_replacement(range(1<<n),2)]
def rank(cells,k):
 if not cells:return 0
 s=union(a for a,b in cells)
 if not any(a and b&s for a,b in cells):return 1
 return 2 if any(all(any((m&a)==a and not m&b for m in S)for a,b in cells)for S in shapes(k))else 3
def actual(ms,pr,LS,edges,groups,spare=0,upperLS=None,ordinary=-1,last=-1,late=()):
 LP=LS[0]
 z=tuple(g[0] for g in groups);fn=dict(pr);M={}
 state=lambda p:sum(1<<i for i,m in enumerate(ms) if p&m)
 hpos={p:state(p)for p in pts};F={}
 cs=[pack(lambda n,j=j:all(not j>>k&1 or n&m for k,m in enumerate(ms)))for j in range(1<<len(ms))]
 for p in pts:
  for u,t in enumerate(stars):
   if p&t:M[p,u]=~pt[p]&on[u]&cs[hpos[p]]
  F[p]=union(M[p,u]for u in range(7)if p&stars[u])
 Z=sum(p for p,f in pr);D=sum(p for p,f in pr if f&1);e=union(ms);rt=7+len(z);S=tuple(i for i in range(rt)if i!=ordinary)
 selfno={(p,h):bool(M[p,h])and any(M[p,u]&meet[h]for u in range(7)if u!=h and p&stars[u])for h in range(7)for p in pts if p&stars[h]}
 auto=[any(not p&(D|e) and p&t and (selfno[p,h]or any(q&t and not q&(D|e)and selfno[q,h]and M[p,h]&M[q,h]for q in pts))for p in pts)for h,t in enumerate(stars)]
 upperm=[[sum(1<<u for u in range(7)if not (meet[h]&on[u]&cs[j]))for h in range(7)]for j in range(1<<len(ms))]
 U=[upperm[j]+list((upperLS or LS)[j])for j in range(1<<len(ms))]
 high=[on[h]if auto[h]else 0 for h in range(7)]
 for k,p in enumerate(z):
  sig=union(cs[j]&line(LS[j][k]) for j in range(1<<len(ms)))
  high.append(sig|union(pack(lambda n,q=q:bool(n&q and fn[q]>>state(n)&1))for q in groups[k]if q>0))
 sites={}
 for p in pts:
  hs=[i+7 for i,g in enumerate(groups)if p in g]
  if hs:sites[p]=hs;continue
  sites[p]=[rt]+[h for h in S if not(F[p]&high[h]) and not(h<7 and p&stars[h]and selfno[p,h])]
 for p in pts:
  sites[p]=[h for h in sites[p] if h>=7 or all(q&(e|D)or not(stars[h]&q)or not(F[p]&M[q,h])or h in sites[q] for q in pts)]
 allzero=[h for h in range(1<<len(ms))]
 if last>=0:
  for p in pts:
   if p&stars[last] and p not in fn:sites[p]=[h for h in sites[p]if h in late or h in (last,rt)]
 sites0=tuple(sorted(pts,key=lambda p:len(sites[p])))
 subtract=[{0}for _ in range(7)]
 @cache
 def cost(h,u,g):
  ps=[p for p in pts if p&g&stars[u]and M[p,u]]
  if h==u or not ps:return 0
  Nset=alln if h==rt else meet[h] if h<7 else F.get(z[h-7],0)
  Nset|=union(F[p]for p in pts if p&g)
  yes=[]
  for p in ps:
   r=pt[p]&cs[hpos[p]]&Nset
   active=[i for i in S if i!=h and i!=u and U[hpos[p]][i]>>u&1]
   if h!=rt and h not in late:active=[i for i in active if i not in late]
   if u==last:active=[i for i in active if i in late]
   for i in active:r&=high[i]
   yes.append(r)
  cs0=set()
  for i,p in enumerate(ps):
   if not(fn.get(p,0)>>hpos[p]&1) and not any(i!=h and i!=u and U[hpos[p]][i]>>u&1 and (u!=last or i in late) and (h==rt or h in late or i not in late) for i in S):cs0.add((1<<i,0))
  relevant=union(yes)
  while relevant:
   b=relevant&-relevant;relevant^=b
   cs0.add((sum(1<<k for k,x in enumerate(yes)if x&b),sum(1<<k for k,p in enumerate(ps)if F[p]&b)))
  return rank(cs0,len(ps))
 @cache
 def rootprice(u,Q,X):
  ns=alln
  for i in X:ns&=high[i]
  ps=[p for p in pts if p&stars[u]]
  cells=set()
  while ns:
   b=ns&-ns;ns^=b
   need=sum(1<<k for k,p in enumerate(ps) if pt[p]&b&cs[hpos[p]])
   if need:cells.add((need,sum(1<<k for k,p in enumerate(ps)if Q&p and M[p,u] and F[p]&b)))
  return rank(cells,len(ps))
 sender=[]
 for u in range(7):
  compelled=set()
  for st,ls in enumerate(LS):
   act=[i+7 for i,m in enumerate(ls)if m>>u&1]
   act=[j for j in act if not any((upperLS or LS)[st][i]>>u&1 and k+7==j for i,k in edges)]
   compelled.update(act)
  sender.append(compelled)
 @cache
 def ok(u,rr,raw):
  need={h for h in S if rr[h]}|sender[u]
  if u==last and any(h not in late for h in need):return 3+spare
  best=3+spare
  for k in range(len(need),3+spare):
   for A in combinations([h for h in S if h!=u and h not in need and (u!=last or h in late)],k-len(need)):
    X=tuple(sorted(need|set(A)));charge=sum(max(1,rr[h])for h in X)
    if charge+rr[rt]<best:best=min(best,charge+max(rr[rt],rootprice(u,raw,X)))
  return best
 g=[0]*(rt+1)
 def walk(i):
  if i==len(pts):return True
  p=sites0[i]
  for h in sites[p]:
   g[h]|=p
   if sum(max(0,ok(u,tuple(cost(a,u,v)for a,v in enumerate(g)),g[rt]&t)-2) for u,t in enumerate(stars)if u!=ordinary)<=spare and walk(i+1):return True
   g[h]^=p
  return False
 return walk(0)
