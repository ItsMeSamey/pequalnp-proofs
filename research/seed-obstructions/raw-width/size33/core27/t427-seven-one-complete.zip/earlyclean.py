import json,gzip,sys,os
from proofrec import Recorded
from jointroot import Rectangle
from frontlocal import LocalRectangle
from itertools import combinations,islice
from pysat.solvers import Glucose4
from pysat.formula import IDPool
from smallfn import tables,obstruction
from functools import cache
def bits(x):
 while x:
  b=x&-x;yield b.bit_length()-1;x-=b
def solve(d,ch):
 sat=Recorded() if os.environ.get("CHECK_DRAT") else Glucose4();ids=IDPool()
 def var(*k):return ids.id(k)
 add=sat.add_clause
 G=d['housing'];P=d['pos'];N=d['neg'];rows=P+N;num=len(rows);last=d['last'];late=set(d['late'])
 own=[G[h]|((1<<(13+h))if h<7 else 0)for h in range(12)]
 values=[(v&((1<<20)-1))|((1<<20)if v&129 else 0)for v in rows]
 rr=[[(v&own[h])for v in values]for h in range(12)]
 pos=[d['posone'][h]|d['negone'][h]<<len(P)for h in range(11)]+[(1<<len(P))-1]
 neg=[d['poszero'][h]|d['negzero'][h]<<len(P)for h in range(11)]+[((1<<len(N))-1)<<len(P)]
 def probe(raw,ones,zeros):
  nonlocal num
  j=1<<num;num+=1;values.append(raw)
  for h in range(12):rr[h].append(raw&own[h])
  for h in ones:pos[h]|=j
  for h in zeros:neg[h]|=j
 for pin in (0,1):
  probe(pin<<20,[],range(11))
  for u in range(7):
   probe((pin<<20)|(1<<(13+u)),([10]if pin and u==0 else []),[h for h in range(7)if h!=u]+([10]if u!=0 else []))
  for j,f in enumerate(d['f']):
   assert G[7+j].bit_count()==1
   probe(G[7+j]|(pin<<20),[7+j]if f>>pin&1 else [],[]if f>>pin&1 else[7+j])
 location=[var('C',h)for h in range(12)];add(location)
 for i,j in combinations(location,2):add([-i,-j])
 if ch>=0:add([location[ch]])
 def edge(i,h):return var('e',i,h)
 def order(i,h):return var('ord',i,h)
 def val(h,j):return var('v',h,j)
 opts=[]
 for i in range(11):
  z=[h for h in range(12)if h!=i and not(i==last and h not in late|{11})and not(i in late and h not in late|{11})]
  opts.append(z);add([edge(i,h)for h in z])
  for g in combinations(z,3):add([-edge(i,h)for h in g])
  for h in z:add([-edge(i,h),order(i,h)])
  if i<7:
   r=d['Dranges'][i]
   if 0 not in r:add([edge(i,11)])
   if max(r)==0:add([-edge(i,11)])
   if 2 not in r:add([-edge(i,11)]+[edge(i,h)for h in z if h!=11])
   if min(r)==2:
    for h in z:
     if h!=11:add([-edge(i,h)])
 for i in range(12):
  for j in range(12):
   if i==j:continue
   add([-order(i,j),-order(j,i)])
   for k in range(12):
    if k not in (i,j):add([-order(i,j),-order(j,k),order(i,k)])
  if i!=last:add([order(last,i) if i in late|{11} else order(i,last)])
  for a in bits(pos[i]):add([val(i,a)])
  for b in bits(neg[i]):add([-val(i,b)])
 preds=[[i for i in range(11)if h in opts[i]]for h in range(12)]
 if 'optsD' in d:
  for u,z in enumerate(d['optsD']):
   ss=[]
   for k,mask in enumerate(z):
    if any(j not in opts[u]for j in bits(mask)):continue
    sel=var('DFan',u,k);ss.append(sel)
    for j in opts[u]:add([-sel,edge(u,j) if mask>>j&1 else -edge(u,j)])
   add(ss)
 part=Rectangle(sat,var,edge,val,location,opts,P,N,G,pos,neg)
 hub=1 if G[1] else 5
 partH=LocalRectangle(hub,sat,var,edge,val,location,opts,values,own,pos,neg)
 @cache
 def witness(h,i,a,b):
  w=var('w',h,i,a,b);add([-w,edge(i,h)]);add([-w,val(i,a)]);add([-w,-val(i,b)]);return w
 @cache
 def comp(h,a,b):
  good=[i for i in preds[h]if not (neg[i]>>a&1 or pos[i]>>b&1)]
  add([-val(h,a),val(h,b)]+([location[h]]if values[a]&~values[b]&(1<<20)else[])+[witness(h,i,a,b)for i in good])
 @cache
 def supers(h,a):
  return sum(1<<b for b,y in enumerate(rr[h])if not rr[h][a]&~y)
 hasC=sum(1<<a for a,x in enumerate(values)if x&(1<<20))
 it=0
 while sat.solve():
  model=set(sat.get_model());it+=1
  adj=[[h for h in z if edge(i,h)in model]for i,z in enumerate(opts)];pr=[[i for i,z in enumerate(adj)if h in z]for h in range(12)]
  cloc=next(h for h in range(12)if location[h]in model)
  err=0
  sig=[sum(1<<a for a in range(num)if val(h,a)in model)for h in range(12)]
  for h in reversed(range(12)):
   ct=0
   for a in bits(sig[h]):
    bad=supers(h,a)&~sig[h]
    if h==cloc and values[a]&(1<<20):bad&=hasC
    for i in pr[h]:
     if sig[i]>>a&1:bad&=sig[i]
    for b in islice(bits(bad),4):
     comp(h,a,b);ct+=1
    if ct>=24:break
   err+=ct
  err+=part.check(model)
  if err:err+=partH.check(model,sig,limit=12,fixed=True)
  if not err:
   for h,pp in enumerate(pr):
    rawlist=list(bits(own[h]))+([20]if cloc==h else [])
    mult=tuple([1]*len(rawlist)+[3-len(adj[i])for i in pp])
    if not mult or sum(mult)>5:continue
    obs={};bc=len(rawlist)
    for j in range(num):
     pat=sum(1<<k for k,b in enumerate(rawlist)if values[j]>>b&1)
     pat|=sum(1<<(bc+k)for k,i in enumerate(pp)if sig[i]>>j&1)
     obs.setdefault((pat,(sig[h]>>j)&1),j)
    if any(all((f>>p&1)==y for p,y in obs)for f in tables(mult)):continue
    guard=[-location[cloc]]+[(-edge(i,j) if j in adj[i] else edge(i,j)) for i in range(11) for j in opts[i]]
    for j in obstruction(mult,obs):
     for i in pp+[h]:guard.append(-val(i,j)if sig[i]>>j&1 else val(i,j))
    add(list(set(guard)));err+=1
  if not err:err+=partH.check(model,sig)
  if it%10==0 or not err:print("model",it,err,ids.top,flush=True)
  if not err:return 'SAT',cloc,[sum(1<<j for j in z)for z in adj]+[0]
 if isinstance(sat,Recorded):sat.verify()
 return 'UNSAT',it
if __name__=='__main__':
 idx=int(sys.argv[1]);d=json.loads(next(islice(gzip.open('temporal.jsonl.gz','rt'),idx,None)))
 if len(sys.argv)>3:
  target=(d['f'],d['housing'],d['last'],d['late'])
  d['optsD']=next(x['optsD']for l in open(sys.argv[3]) if l.startswith('{')for x in [json.loads(l)]if (x['f'],x['housing'],x['last'],x['late'])==target)
 print('key',idx,d['f'],d['last'],d['late'],d['housing'],flush=True);print(solve(d,int(sys.argv[2])),flush=True)
