from geometry import *
from itertools import combinations
C=129
allP=sum(pts)
E=pack(lambda n:bool(n&C))
foreign=tuple(all(on[u]&E&meet[v] for v in range(7)if v!=u)for u in range(7))
def cuts(hp,S,again=False):
 # S=None indicates a zero-baseline relay that carries no tag at this pin (no clamp). 127 also used for composite-only baseline via unconditional H.
 h=(E if hp else alln)&(alln if S is None or again else line(S))
 if not h:return []
 allow=[p for p in pts if hp or not p&C]
 out=[]
 for u in range(7):
  if not all(h&on[u]&meet[v]for v in range(7)if v!=u):continue
  rr=[p for p in allow if p&stars[u]and all(h&pt[p]&g for g in meet) and h&~pt[p]&line(inc[p])&on[u]]
  for n in range(len(rr),1,-1):
   for group in combinations(rr,n):
    if not all(any(h&on[v]&pt[b] for a,b in ((p,q),(q,p))for v in range(7)if inc[a]>>v&1 and not inc[b]>>v&1)for p,q in combinations(group,2)):continue
    out.append((u,sum(group)));break
   else:continue
   break
 return out
if __name__=='__main__':
 for pin in (0,1):
  alive=[]
  for S in range(128):
   c=cuts(pin,S if S else None)
   bad=any(p.bit_count()>2-int(bool(S>>u&1) and (not pin or foreign[u]))for u,p in c)
   if not bad:alive.append(S)
  print(pin,alive,flush=True)
 print('constant',cuts(1,None,True))
