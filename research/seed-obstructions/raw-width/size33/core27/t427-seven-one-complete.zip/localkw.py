from itertools import combinations
class LocalRectangle:
 def __init__(self,h,sat,var,edge,val,location,opts,values,own,pos,neg):
  self.h=h;self.sat=sat;self.var=var;self.edge=edge;self.val=val;self.loc=location;self.opts=opts;self.values=values;self.pos=pos;self.neg=neg
  self.tiles=[(i,k)for i,z in enumerate(opts)if h in z for k in range(2)]+[(12+j,0)for j in range(21)if j==20 or own[h]>>j&1]
  self.mem=[({}, {})for t in self.tiles];self.used=set();self.num=len(values)
 def member(self,j,side,r):
  h=self.h;i,k=self.tiles[j];p=side==0
  if i<11 and ((self.neg[i]if p else self.pos[i])>>r)&1:return 0
  if i>=12 and bool(self.values[r]>>(i-12)&1)!=p:return 0
  memo=self.mem[j][side]
  if r in memo:return memo[r]
  x=self.var('lm',h,j,side,r);memo[r]=x;a=self.sat.add_clause
  if i<11:
   a([-x,self.edge(i,h)]);a([-x,self.val(i,r)if p else -self.val(i,r)])
   if k:
    for dst in self.opts[i]:
     if dst!=h:a([-x,-self.edge(i,dst)])
  elif i==32:a([-x,self.loc[h]])
  a([-x,self.val(h,r)if p else -self.val(h,r)])
  return x
 def cut(self,p,n):
  assert (p,n)not in self.used
  self.used.add((p,n));atoms=[];add=self.sat.add_clause
  for j in range(len(self.tiles)):
   x=self.member(j,0,p);y=self.member(j,1,n)
   if not x or not y:continue
   z=self.var('lrect',self.h,j,p,n);atoms.append(z);add([-z,x]);add([-z,y]);add([z,-x,-y])
  add([-self.val(self.h,p),self.val(self.h,n)]+atoms)
  for x,y in combinations(atoms,2):add([-x,-y])
 def check(self,model,sig,limit=36):
  nmask=(1<<self.num)-1
  ns=[sum(1<<r for r,x in rr[1].items()if x in model)for rr in self.mem]
  yes=sig[self.h];no=nmask^yes;cuts=0
  while yes:
   bp=yes&-yes;p=bp.bit_length()-1;yes-=bp;once=0;dup=0
   for j,(a,b)in enumerate(self.mem):
    if a.get(p)in model:dup|=once&ns[j];once|=ns[j]
   bad=no&((nmask^once)|dup);ct=0
   while bad and ct<3:
    bn=bad&-bad;bad-=bn;self.cut(p,bn.bit_length()-1);ct+=1;cuts+=1
   if cuts>=limit:break
  return cuts
