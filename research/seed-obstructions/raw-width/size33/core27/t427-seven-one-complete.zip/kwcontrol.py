from pysat.formula import IDPool
from pysat.solvers import Glucose4
from jointroot import Rectangle
def run(P,N,R,aux):
 pool=IDPool();v=lambda *k:pool.id(k)
 E=lambda i,j:v('e',i,j)
 V=lambda h,j:v('v',h,j)
 with Glucose4()as s:
  C=[v('C',i)for i in range(12)];s.add_clause([-C[11]])
  opts=[[]for _ in range(11)]
  for h in range(aux):
   opts[h]=[11];s.add_clause([E(h,11)])
   for j,x in enumerate(P+N):s.add_clause([V(h,j) if x>>h&1 else -V(h,j)])
  r=Rectangle(s,v,E,V,C,opts,P,N,[0]*11+[R],[0]*12,[0]*12)
  while s.solve():
   if not r.check(set(s.get_model())):return True
  return False
assert run([5,6],[3,4],7,0)
assert not run([3,5,6],[1,2,4],7,0)
assert run([3,5,6],[1,2,4],4,2)
print('planted read-once, majority obstruction, repeated-port majority: pass')
