from pathlib import Path
from itertools import combinations,product
import ast,hashlib,sys
opts=[[0,1,2]]*2
def guard(p,old=False):
 tree=ast.parse(p.read_text())
 fun=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='reject_local')
 if old:
  branch=next(n for n in ast.walk(fun) if isinstance(n,ast.If) and 'len(adj[i]) == 1' in ast.unparse(n.test))
  branch.orelse=[]
 ns={'preds':[[0,1]],'opts':opts,'location':[100],'edge':lambda i,j:1+3*i+j}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fun],type_ignores=[])),str(p),'exec'),ns)
 def clause(adj,at):
  result=[];ns['add']=result.append
  ns['reject_local'](0,[i for i,v in enumerate(adj) if 0 in v],adj,0 if at else 1)
  assert len(result)==1
  return result[0]
 return clause
def event(adj,at):
 return {1+3*i+j for i,z in enumerate(adj) for j in z}|({100} if at else set())
def sig(adj,at):
 return tuple(3-len(z) if 0 in z else 0 for z in adj),at
def blocked(cl,ev):return not any((x in ev if x>0 else -x not in ev)for x in cl)
opt=list(combinations(range(3),1))+list(combinations(range(3),2))
domain=list(product(product(opt,repeat=2),(0,1)))
def tr(x,y,z):return ((x and y) or (z and (x or y)))
assert all(tr(*t)==(sum(t)>=2) for t in product((0,1),repeat=3))
for arg in sys.argv[1:]:
 p=Path(arg);get=guard(p);a=((0,),(0,1));b=((0,),(0,))
 assert sig(a,1)==((2,1),1) and sig(b,1)==((2,2),1)
 assert blocked(guard(p,True)(a,1),event(b,1))
 assert not blocked(get(a,1),event(b,1)), 'four-leaf guard incorrectly blocks legal five-leaf majority'
 tests=0
 for old,at in domain:
  cl=get(old,at)
  assert blocked(cl,event(old,at))
  for new,c in domain:
   if blocked(cl,event(new,c)):assert sig(old,at)==sig(new,c),(old,at,new,c,cl)
   tests+=1
 print(p.name,hashlib.sha256(p.read_bytes()).hexdigest(),tests,'OK',flush=True)
