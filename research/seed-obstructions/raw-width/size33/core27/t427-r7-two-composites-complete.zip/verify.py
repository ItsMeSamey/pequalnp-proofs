from zipfile import ZipFile
from pathlib import Path
import subprocess,sys
with ZipFile('predecessor.zip')as z:
 for f in z.namelist():
  if f!='verify.py':z.extract(f)
with ZipFile('upstream.zip')as z:
 for f in z.namelist():
  if f!='verify.py':z.extract(f)
subprocess.run([sys.executable,'-B','auditcross.py'],check=True)
