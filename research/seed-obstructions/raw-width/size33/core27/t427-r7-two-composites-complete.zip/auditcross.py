from crossrole import *
from ast import literal_eval
from pathlib import Path
assert all(not UP[p]&inc[p]for p in UP)
assert sorted(bad)==[(1,128),(64,4096)]
assert all(not inc[p]&inc[q] for p,q in bad)
for p in bm(R):
 assert any(inc[p]==x for x in cover[p])
for p,mask in UP.items():
 F=pack(lambda n:not n&p and n>>13&inc[p]and all(n>>extra[m]&1 for m in C))
 assert F&top and mask==sum(1<<u for u in range(7)if not F&top&on[u])
line=next(l for l in Path('third.log').read_text().splitlines()if l.startswith('(129, 4160) '))
opts=literal_eval(line.split(')',1)[1].strip().split(' ',1)[1])
live=[]
for z,g,d in opts:
 if g<2:continue
 a=screen(z,g,d)
 if a:live.append((z,g,d,a))
assert live==[(4,2,(0,0,0),[((-1,-1,-1,-1),(4,0,0))])]
V=79;rows={p:inc[p]&V for p in bm(R^4)if inc[p]&V}
for p,q in bad:rows[p]|=rows.pop(q)
assert list(rows.values())==[67,73,70,13,10,4]
assert not enough(tuple(sorted(rows.values())),V,tuple(sorted([(UP[4],2),(127,2),(127,2)])),0)
print('13 two- or three-anonymous cases exhausted; all 56 profiles excluded with upstream')
