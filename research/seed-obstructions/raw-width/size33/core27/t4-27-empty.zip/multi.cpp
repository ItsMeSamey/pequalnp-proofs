#include <cstdio>
#include <algorithm>
using namespace std;
int g,z,Q,k[3],spare,dag[3],recv[3],stars[7],cnt[8192],best;
void price(){
 int cover[8]={};
 for(int a=1;a<(1<<g);a++){
  int reach=a;
  for(int i=0;i<g;i++)if(reach>>i&1)reach|=dag[i];
  for(int i=0;i<g;i++)if(reach>>i&1)cover[a]|=recv[i];
 }
 int sum=0;
 for(int s:stars){
  int need=s&Q,d=cnt[need]+bool((s&z)&&need);
  for(int a=1;a<(1<<g);a++)d=min(d,cnt[a]+cnt[need&~cover[a]]);
  sum+=max(0,d-2);
 }
 best=min(best,sum);
}
void visit(int i){
 if(i==g){price();return;}
 int n=min(cnt[Q],k[i]-cnt[dag[i]]);
 for(int r=Q;;r=(r-1)&Q){
  if(cnt[r]==n){recv[i]=r;visit(i+1);}
  if(!r)break;
 }
}
int main(){
 for(int x=1;x<8192;x++)cnt[x]=1+cnt[x&(x-1)];
 for(int &s:stars)if(scanf("%d",&s)!=1)return 1;
 while(scanf("%d%d%d%d",&g,&z,&Q,&spare)==4){
  for(int i=0;i<g;i++)scanf("%d",&k[i]);
  sort(k,k+g);best=100;
  do{for(int d=0;d<1<<(g*(g-1)/2);d++){
   int b=0;fill(dag,dag+3,0);
   for(int i=0;i<g;i++)for(int j=i+1;j<g;j++){if(d>>b&1)dag[i]|=1<<j;b++;}
   visit(0);
  }}while(next_permutation(k,k+g));
  printf("%d %d %d %d\n",g,z,spare,best);
 }
}
