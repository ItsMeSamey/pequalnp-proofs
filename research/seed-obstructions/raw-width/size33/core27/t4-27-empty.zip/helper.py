from check import profiles, stars, pts
from collections import Counter
from itertools import combinations
def masks(z,g,ds):
 Q=[p for p in pts if not p&z]
 read=2+ds[-1]
 spare=5-z.bit_count()-g-sum(ds)
 active=set()
 for m in range(128):
  k=[(s&~z).bit_count() for s in stars]
  fixed=sum(max(0,n+int(n>0 and bool(s&z))-2) for t,(n,s) in enumerate(zip(k,stars)) if not m>>t&1)
  if fixed>spare:continue
  for G in combinations(Q,min(read,len(Q))):
   v=sum(G)
   cost=fixed+sum(max(0,1+(s&~(z|v)).bit_count()-2) for t,s in enumerate(stars) if m>>t&1)
   if cost<=spare:
    active.add(m);break
 return active
surv=Counter()
for z,g,ds in profiles:
 if g!=1:continue
 M=masks(z,g,ds)
 surv[bool(M)]+=1
 print(z,ds,sorted(M))
print('profiles',surv)
