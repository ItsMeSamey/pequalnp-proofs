from check import profiles,stars
with open('multi.in','w') as f:
 print(*stars,file=f)
 for z,g,ds in profiles:
  if g>=2:
   print(g,z,8133^z,5-z.bit_count()-g-sum(ds),*(2+d for d in ds[-g:]),file=f)
