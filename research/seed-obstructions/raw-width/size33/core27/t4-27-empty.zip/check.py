import ast
from pathlib import Path
import sys
from collections import Counter
source=Path('/workspace/scratch/syn_quotients/t427')
sys.path.insert(0,str(source))
from geometry import P,N,pts,stars,inc
profiles=ast.literal_eval((source/'third.log').read_text().splitlines()[0].split(' ',2)[2])
for p in pts:
 for u,s in enumerate(stars):
  assert any(n>>(13+u)&1 and n>>13&inc[p] and not n&p for n in N)
  if not s&p: assert any((n&p) and (n>>(13+u)&1) for n in N)
print(len(P),len(N),len(profiles),Counter(g for z,g,ds in profiles))
keep=[]
for z,g,ds in profiles:
 k=[(s&~z).bit_count() for s in stars]
 bill=sum(max(0,n+int(n>0 and bool(s&z))-2) for n,s in zip(k,stars))
 if g==0 and bill>5-z.bit_count()-sum(ds):continue
 keep.append((z,g,ds))
print('survivors',len(keep),Counter(g for z,g,ds in keep))
