from itertools import product
from pathlib import Path
S=list(map(int,Path('last.in').read_text().splitlines()[0].split()))
for line in Path('last.log').read_text().splitlines():
 if not line.startswith('pass'):continue
 _,zz,arc,r,_,*opts=line.split();z=int(zz[2:]);assert arc=='arc=0'
 X,Y=map(int,r[6:].split(','));Q=8133^z
 reach=(0,X,Y,X|Y); count=left=0
 for A in product(*[[a for a in range(4) if int(m)>>a&1] for m in opts]):
  assert 0 not in A
  tight=[i for i,(s,a) in enumerate(zip(S,A)) if a.bit_count()+(s&Q&~reach[a]).bit_count()==2]
  clean=0
  for i in tight:clean|=S[i]&Q
  good=False
  for i in tight:
   if not S[i]&z:continue
   receivers=reach[A[i]] | (S[i]&Q)
   if not receivers&~clean:good=True
  count+=1;left+=not good
 print(z,X,Y,count,left)
