import cuts4,stronger4,origins4
from cuts4 import *
e=tuple(DEGREE_ONE);P,N=load(e)
for R,C in banks(e,P,N):
 key=cuts4.test(P,N,R,C)
 if key:print('DARK',C,key,flush=True);continue
 key=stronger4.test(P,N,R,C)
 if key:print('PAIR',C,key,flush=True);continue
 try:z=origins4.test(P,N,R,C)
 except AssertionError:z=None
 print('ORIGINS',C,z,flush=True)
