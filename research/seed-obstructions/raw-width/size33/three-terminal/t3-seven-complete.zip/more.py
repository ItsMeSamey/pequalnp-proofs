from stronger import *
from ast import literal_eval
from pathlib import Path
j=int(sys.argv[1]);e=list(combinations(DEGREE_ONE,3))[j];P,N=load(e)
for l in Path('out%d'%j).read_text().splitlines():
 R,C,t=literal_eval(l)
 if not t:print((R,C,test(P,N,R,C)),flush=True)
