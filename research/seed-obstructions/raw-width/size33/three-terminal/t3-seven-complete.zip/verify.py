from pathlib import Path
import sys,subprocess
from ast import literal_eval as ev
for src,log,ns in [('cuts.py','out',range(4)),('more.py','more',range(4)),('last.py','last',range(4)),('stage.py','cps.log',(None,)),('four.py','four.log',(None,)),('stage4.py','cps4.log',(None,))]:
 for i in ns:
  suffix=[]if i is None else [str(i)]
  name=log+''.join(suffix)
  data=subprocess.check_output([sys.executable,'-B',src]+suffix)
  assert data==Path(name).read_bytes(),name
print('1046/1046 three-peeled r7 physical banks excluded. Four-peeled at 26 gates leaves one bank with two allocations.')
