from component4 import *
from ast import literal_eval as ev
from pathlib import Path
P,N=load(tuple(DEGREE_ONE))
for ln in Path('four.log').read_text().splitlines():
 if not ln.startswith('ORIGINS'):continue
 ln=ln[8:];k=ln.index(')')+1;C=ev(ln[:k]);zs=ev(ln[k:].strip())
 out=test(P,N,8133,C,zs); print(C,len(out),out,flush=True)
