from component import *
from ast import literal_eval as ev
from pathlib import Path
for j,e in enumerate(combinations(DEGREE_ONE,3)):
 P,N=load(e)
 for l in Path('last%d'%j).read_text().splitlines():
  R,C,zs=ev(l);rs=test(P,N,R,C,zs);print(j,C,len(rs),rs,flush=True)
