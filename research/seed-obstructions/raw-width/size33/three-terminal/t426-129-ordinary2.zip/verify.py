from geometry import *
from holder import rank
from six import test as first,subs
C=129; ordinary=2;z=(1,256,512,2048)
E=pack(lambda n:bool(n&C))
def mask(p,u):
 return ~pt[p]&on[u]&(E if p&C else alln)
F={p:union(mask(p,u)for u in range(7)if p&stars[u])for p in pts}
for d,p in ((0,4),(1,1024),(3,1024),(4,64),(5,4096),(6,4)):
 assert p&stars[d] and not p&C and p not in z
 assert mask(p,d) and any(mask(p,v)&meet[d]for v in range(7)if v!=d and p&stars[v])
for p in (64,1024):
 assert all(F[p]&on[d] for d in range(7)if d!=ordinary)
 assert all(F[p]&pt[q]&(E if q&C else alln)for q in z)
assert all(on[4]&F[q]for q in z)
assert all(meet[d]&on[4]for d in range(7)if d not in (ordinary,4))
assert pt[1024]&on[0] and not stars[0]&1024 and stars[0]&64
assert on[4] and pt[64] and pt[1024]
t=bm(stars[4]);cells=set()
for n in N:
 a=sum(1<<i for i,q in enumerate(t)if n&q)
 b=sum(1<<i for i,q in enumerate(t)if q in (64,1024)and bool((1<<N.index(n))&F[q]))
 if a:cells.add((a,b))
assert rank(cells,len(t))==3
print('mandatory bare tags automatic; 64 and 1024 root-local; two direct copies reserved, four-row rank exceeds two')
m=bm(stars[ordinary]);R=8133
assert m==[256,512,2048]
from marks import profile
M,_,b,*_=profile((129,),(2,));assert list(M)==m
assert first(P,N,R,(C,),[sum(M)+sum(d)for d in subs(bm(R^sum(M)),b+1)],2)==[(2817,0,(0,0,0,0))]
print('all structural allocations of C=129 and ordinary label 2 excluded')
