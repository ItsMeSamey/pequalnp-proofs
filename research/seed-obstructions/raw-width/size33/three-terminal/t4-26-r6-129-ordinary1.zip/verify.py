import subprocess,sys
from pathlib import Path
from cut import test,load,DEGREE_ONE
from geometry import *
here=Path(__file__).resolve().parent
P,N=load(tuple(DEGREE_ONE))
for h in [0,1]:
 c=pack(lambda n:not h or n&129)
 assert all(all(meet[j]&on[u]&c for u in range(7)if u!=j)for j in range(7))
ans=[test(P,N,8133,(129,),(),1,h)for h in (False,True)]
assert repr(ans)+'\n'==(here/'codes.txt').read_text()
assert len(ans[0])==128 and len(ans[1])==56
assert sum(1 for x in ans[0]for y in ans[1]if not x[0]&~y[0]and not x[1]&~y[1])==1512
for prog,log in [('solve.py','pilot.log'),('confirm.py','confirm.log')]:
 got=subprocess.check_output([sys.executable,prog],cwd=here,text=True)
 assert got==(here/log).read_text()
assert len((here/'confirm.log').read_text().splitlines())==16
assert all(x.endswith(' 0')for x in (here/'confirm.log').read_text().splitlines())
print('VERIFIED 5 128 56 1512 16 0')
