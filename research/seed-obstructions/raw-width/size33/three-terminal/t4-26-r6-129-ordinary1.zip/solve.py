from itertools import product
import sys
from holder import actual
from geometry import *
for z,a in [(1408,0),(1408,1),(1409,0),(1412,0),(1472,0)]:
 ps=bm(z);g=[(p,)for p in ps]+[(-1,)]*a
 for fs in product(*[(2,3)for p in ps]):
  up=[]
  for h in range(2):
   masks=[]
   for p in ps:
    f=pack(lambda n:not n&p and (not p&129 or n&129) and n>>13&inc[p] and (not h or n&129))
    masks.append(sum(1<<u for u in range(7)if u!=1 and not f&on[u]))
   up.append(masks+[125]*a)
  lo=[[0]*len(g)for h in range(2)]
  if actual((129,),list(zip(ps,fs)),lo,(),g,4-len(g),up,ordinary=1):
   print('OPEN',z,a,fs,up,flush=True)
 print('DONE',z,a,flush=True)
