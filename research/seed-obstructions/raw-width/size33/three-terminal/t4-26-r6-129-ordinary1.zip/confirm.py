from ast import literal_eval
from itertools import product
import sys
from holder import actual
from geometry import *
a,b=literal_eval(open('codes.txt').read())
pairs=[(x,y)for x in a for y in b if not x[0]&~y[0] and not x[1]&~y[1]]
import functools
def tryblock(pairs,flags,arcs):
 lo=[];hi=[]
 from operator import and_,or_
 for s in range(2):
  l=[];h=[]
  for i in range(2):
   vv=[v[s][i]for v in pairs];l.append(functools.reduce(and_,vv));h.append(functools.reduce(or_,vv))
  lo.append([l[0],0,0,l[1]]);hi.append([h[0],0,0,h[1]])
 return actual((129,),list(zip((128,256,1024),flags)),lo,arcs,[(128,),(256,),(1024,),(-1,)],0,hi,ordinary=1)
def descend(c,flags,edges):
 if not c or not tryblock(c,flags,edges):return 0
 if len(c)==1:return 1
 k=len(c)//2
 return descend(c[:k],flags,edges)+descend(c[k:],flags,edges)
for flags in product((2,3),repeat=3):
 for arc in [((0,3),),((3,0),)]:
  n=descend(pairs,flags,arc)
  print(flags,arc,n,flush=True)
