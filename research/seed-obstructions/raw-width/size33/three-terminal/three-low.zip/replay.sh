#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 core.py 2 8 16 32
python3 splice.py 2 8 16 32
python3 union_bins.py 2 8 16 32
sha256sum -c ledgers.sha256
