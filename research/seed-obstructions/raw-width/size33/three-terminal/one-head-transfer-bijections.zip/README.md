# Removing one OR entry preserves all raw-line owner identities

In a three-peeled core let the last degree-one point q have its sole physical use at G=q OR B. Set q low and bypass G to B. Keep repeated operand occurrences, even when two parents become equal. The root cannot be G since q alone appears on a negative. Every other live raw and gate retains a path to the output: traversals through G from any other vertex previously passed through B. There are exactly two deletions, one raw source q and one gate G. The remaining core has at most 26 gates. At every other positive q was zero; negatives only decrease. If q's sole positive still passed with q zero, reattaching the three original products would give a separator of size at most 32. Hence its projected q-positive is a forced rejection too. This is the exact signed four-peeled sample.

Let f count outgoing occurrences. Cut repeated origins including raw vertices with f≥2. Only B changes fanout, to f(B)−1+f(G).
* With f(G)=1 no endpoints change; q and G disappear from their region.
* With f(G)≥2 and f(B)=1 the old G endpoint becomes B, which inherits its exits. That region loses its local q and operation G; its other original local raw leaves stay inside B.
* With f(G)≥2 and f(B)≥2 the dropped region G had only resident raw q and its other operand was a cut port of B. Its former exits are replaced by further ports of B. No raw line occupied the dropped region.

Thus the partition of all seven raw flags into original root and nonroot regions, and the individual identity of each sole resident label at a nonroot endpoint, are unchanged up to renaming G as B in the second case. No bypass witness is required. The projected circuit may be algebraically redundant; an exclusion on all live physical circuits of this bank and owner class is sufficient.

The forty outstanding t3 six-owner producer entries all have q physically present and no composites or just 129 or 4160. The remaining raw signals have unchanged physical provenance in the t4 minor. Each of these forty transfers to a t4/26 six-owner case at the identical composite bank and ordinary raw label. This packet effects a reduction only.
