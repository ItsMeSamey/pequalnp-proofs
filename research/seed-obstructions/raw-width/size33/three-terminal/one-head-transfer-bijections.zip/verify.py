from ast import literal_eval
from collections import Counter
from pathlib import Path
import subprocess,sys
D=Path(__file__).resolve().parent
rows=[r for f in D.glob('postbins-*.txt') for r in literal_eval(f.read_text())]
assert len(rows)==40
keys={(c,t.bit_length()-1)for n,c,j,t,s in rows}
assert keys=={(c,t) for c in [(),(129,),(4160,)]for t in [1,2,3,5]}
out=subprocess.check_output([sys.executable,'orbit.py'],text=True,cwd=D)
assert out==(D/'orbit.log').read_text()
for l in out.splitlines():
 c,j,v=l.split(' ',2)
 assert set(literal_eval(v))&{((),1),((129,),1),((129,),2)}
print('VERIFIED 40 12 3')
