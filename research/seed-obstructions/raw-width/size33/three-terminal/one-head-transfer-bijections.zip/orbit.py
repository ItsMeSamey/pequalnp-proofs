from itertools import permutations
from pathlib import Path
import sys
from marks import points,stars,make,extra
V=[1,2,3,5]; shades=[0,4,6]
inc={p:frozenset(j for j,T in enumerate(stars)if p in T)for p in points};by={v:p for p,v in inc.items()}
def maxima(a):return {x for x in a if not any(x!=y and not x&~y for y in a)}
def rows(c):
 b,pos,ns,*_=make(c)
 return ({pos[p]|(1<<(13+j)) for p in points for j in inc[p]},maxima({n|(l<<13)for n,l in ns}))
keys=[(c,j)for c in [(),(129,),(4160,)]for j in V]
tbl={c:rows(c)for c,j in keys}
def test(c,t,pi):
 pmap={p:by[frozenset(pi[j]for j in s)]for p,s in inc.items()}
 outc=tuple(sum(v for p,v in pmap.items()if p&m)for m in c)
 if outc not in tbl:return
 tr={p.bit_length()-1:v for p,v in pmap.items()};tr.update({13+j:1<<(13+t)for j,t in pi.items()})
 for old,new in zip(c,outc):tr[extra[old]]=1<<extra[new]
 def f(n):return sum(v for i,v in tr.items()if n>>i&1)
 p,n=tbl[c];p1,n1=tbl[outc]
 if {f(x)for x in p}!=p1:return
 # One directional transfer: if source negative table covers the images of the requested target negatives.
 if {f(x)for x in n}==n1:return outc,pi[t]
for c,j in keys:
 out=set()
 for v in permutations(V):
  for s in permutations(shades):
   pi=dict(zip(V+shades,v+s))
   try:k=test(c,j,pi)
   except KeyError:continue
   if k:out.add(k)
 print(c,j,sorted(out))
