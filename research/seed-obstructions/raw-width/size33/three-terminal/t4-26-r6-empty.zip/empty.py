from holder import *
from pathlib import Path
from ast import literal_eval as ev
def case(z,n,ds,ls=None,edges=()):
 gr=[(p,)for p in bm(z)]+[(-1-i,)for i in range(n)];pr=[(p,1)for p in bm(z)]
 sp=5-len(gr)-sum(ds)
 lo=[([0]*len(pr)+([0]*n if ls is None else list(ls)))];hi=[([0]*len(pr)+([125]*n if ls is None else list(ls)))]
 return actual((),pr,lo,edges,gr,sp,hi,ordinary=1)
if __name__=='__main__':
 l=next(l for l in Path('run.log').read_text().splitlines()if l.startswith('() 1 '))
 out=[]
 for z,n,ds in ev(l.split(' ',3)[3]):
  if case(z,n,ds):out.append((z,n,ds))
 print(out)
