from pathlib import Path
from ast import literal_eval
import subprocess,sys
from geometry import *
for p in pts:
 for u in range(7):
  assert (alln^pt[p])&on[u]&line(inc[p])
  assert pt[p]&meet[u]
  assert on[u]&line(inc[p])
 for q in pts:
  if q==p:continue
  assert inc[p]!=inc[q]and line(inc[p])&line(inc[q])
  assert (line(inc[p])&pt[q]&~pt[p])or(line(inc[q])&pt[p]&~pt[q])
for u in range(7):
 for v in range(7):
  if u!=v:assert on[u]&meet[v]
from marks import profile
M,_,b,_,_,allow=profile((),(1,))
assert tuple(M)==(128,256,1024)and b+1==2 and not any(allow.values())
from six import test as source,subs
s=source(P,N,8133,(),[1408+sum(d)for d in subs(bm(8133^1408),2)],1)
line=next(l for l in Path('run.log').read_text().splitlines()if l.startswith('() 1 '))
assert s==literal_eval(line.split(' ',3)[3])
for prog,log in [('empty.py','empty.log'),('lastempty.py','end.log')]:
 o=subprocess.check_output([sys.executable,'-B',prog])
 assert o==Path(log).read_bytes()
assert all(l.split()[4]=='0'for l in Path('end.log').read_text().splitlines())
print('Empty bank / ordinary label 1: all original-row holder assignments excluded')
