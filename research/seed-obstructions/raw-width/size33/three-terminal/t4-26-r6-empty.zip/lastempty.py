from empty import *
from itertools import product
from functools import reduce
from operator import and_,or_
S=stars
@cache
def groups(K,k):
 return tuple(sum(r)for r in combinations(bm(K),min(k,K.bit_count())))
@cache
def req(K,k,t,least):
 if least<=0:return (1<<len(groups(K,k)))-1
 return sum(1<<i for i,d in enumerate(groups(K,k))if (t&d).bit_count()>=least)
@cache
def fit(V,K,ma,mb,arc,fa,fb):
 for a in groups(K,fa-arc):
  b=(1<<len(groups(K,fb)))-1
  for u in range(7):
   if not V>>u&1:continue
   x=ma>>u&1;y=mb>>u&1
   demand=(S[u]&K)&~(a if x else 0)
   need=demand.bit_count()+x+y-int(x and y and arc)-2
   if y:b&=req(K,fb,demand,need)
   elif need>0:b=0
   if not b:break
  if b:return True
 return False
def check(z,n,ds):
 pr=[(p,1)for p in bm(z)];gr=[(p,)for p,f in pr]+[(-i-1,)for i in range(n)];offset=len(pr);sp=5-len(gr)-sum(ds);assert not sp
 for arc in range(n):
  mask=125;fan=[d+2 for d in ds[offset:]]+[0]
  cand=[]
  for a in range(128):
   if a&~mask:continue
   for b in range(128 if n==2 else 1):
    if b&~mask or n==2 and not arc and b<a:continue
    if fit(125,8133^z,a,b,arc,fan[0],fan[1]):cand.append((a,b))
  edges=((offset,offset+1),)if arc else ()
  def walk(xs):
   if not xs:return []
   lo=[[0]*offset+[reduce(and_,vs)for vs in zip(*xs)][:n]]
   hi=[[0]*offset+[reduce(or_,vs)for vs in zip(*xs)][:n]]
   if not actual((),pr,lo,edges,gr,sp,hi,ordinary=1):return []
   if len(xs)==1:return xs
   opts=[(min(k,len(xs)-k),j,b)for j in range(n)for b in range(7)if (k:=sum(x[j]>>b&1 for x in xs))not in (0,len(xs))]
   _,j,b=max(opts)
   return walk([x for x in xs if not x[j]>>b&1])+walk([x for x in xs if x[j]>>b&1])
  out=walk(cand)
  print(z,n,arc,len(cand),len(out),out[:16],flush=True)
  Path('left-%d-%d-%d.txt'%(z,n,arc)).write_text(repr(out))
if __name__=='__main__':
 for z,n,ds in ev(Path('empty.log').read_text()):check(z,n,ds)
