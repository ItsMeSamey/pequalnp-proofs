# Seven mandatory owners at size 32 and width 21

The native bank has thirteen singleton point signals, one of eighteen composite point signals and seven raw line flags. Every circuit of physical size 32 on this bank would need all seven labels in distinct mandatory owners. This certificate covers each of the 18 × 127 = 2,286 labeled configurations with at least one ordinary label. The all-seven-owner sector is a separate question.

Extract each inner ZIP in its own directory. Run the following files with Python; the first requires python-sat with cadical195.

| Stage | Command | Contribution |
|---|---|---|
| At least five mandatory | python verify.py | 1,782 allocations with at most four mandatory owners |
| Partial neighborhoods | python partial.py | 118 one-ordinary and 346 two-ordinary allocations |
| Final one-ordinary | python paired-pool.py and python sign-transport.py | Last 8 one-ordinary allocations |
| Ingress codes | python coded-multi.py | 30 more two-ordinary allocations |
| Final two-ordinary | python four-final.py 129 4160 | Last 2 two-ordinary allocations |

The one-ordinary and two-ordinary totals are 126 and 378 respectively. The earlier conditional single-fanout and first-gate results are not dependencies of this cover.

| Archive | SHA-256 |
|---|---|
| size32-raw21-at-least-five.zip | d64d00cf3d223e85c805ce83fdd4236f4bdcc067404c176904904d3544193720 |
| size32-raw21-partial-neighborhoods.zip | c9a326d7bda487498a15cd9827a472d5b7b8098b5437cd67e039e5fd4ee44944 |
| size32-raw21-one-ordinary-final.zip | b118139ba29d38ad17d5c1e429caa2e1366081f19d2b0c6c5ddf05f73f22f0bd |
| size32-raw21-ingress-codes.zip | 4150ea57466a161362c6145736e3a37f9c5164242cc9cd72ca1c5543cedbd4c6 |
| size32-raw21-two-ordinary-final.zip | 130da4ffe34aca337a4cc314c604c7ff60f83a28bd3c137f2d15a6994cd8704d |
