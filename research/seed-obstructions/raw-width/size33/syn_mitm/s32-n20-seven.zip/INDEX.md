# Size 32, raw width 20, seven mandatory owners

Run python verify.py with python-sat and the CaDiCaL 1.9.5 backend. The scripts decode the official residual sample from L-meta-18968.json, check the exact twenty-coordinate action and grouped incidence inequalities, and test the remaining physical root KW relaxations.

Read branch.md for the structural reduction and root-cuts.md for the physical socket accounting. The proof imports the established regional point-skeleton/deepest-bin analysis, geometry of the 13-point Fano-residual incidence neighborhoods, and the complete exclusion of 31 gates. The included six-omission component is due to the pruning agent. Counts are 163 named groupings, 19 actual-sample orbits, 14 orbits after the high-branch filter (4,6,4 by omission number). Final KW calls number 16,144,4 respectively. This concerns seven mandatory owners only.
