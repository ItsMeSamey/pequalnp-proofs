from high import census, inspect
from inputs import P,N
from samples import actions
from collections import Counter

def key(groups, omitted, action):
    return (tuple(sorted(action[g] for g in groups)), action[omitted])

group = actions(P,N)
orbits = {}
for groups, omitted in census():
    label = min(key(groups, omitted, a) for a in group)
    _, costs = inspect(groups)
    passes = all(c < g.bit_count() for g,c in zip(groups,costs))
    previous = orbits.setdefault(label, passes)
    assert previous == passes
print("all",Counter(o.bit_count() for _,o in orbits))
print("conditional",Counter(o.bit_count() for (_,o), keep in orbits.items() if keep))
