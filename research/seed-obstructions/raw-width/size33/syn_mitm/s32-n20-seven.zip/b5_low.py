from literal_kw import code_model
from orbits import orbits
from groups import stars,tags
from inputs import P,N
from itertools import combinations
import sys
geometry=-1
for (gs,o) in orbits:
    if o.bit_count()!=5: continue
    geometry+=1
    if len(sys.argv)>1 and geometry!=int(sys.argv[1]):continue
    pair=next(g for g in gs if g.bit_count()==2)
    a,b=[p for p in range(13) if pair>>p&1]
    join=tags[a]&tags[b]
    assert join.bit_count()==1 and (stars[join.bit_length()-1]&~o).bit_count()==3
    sat=sum(1<<u for u,t in enumerate(stars) if sum(bool(t&g) for g in gs)==2)
    assert all(tags[p].bit_count()>=2 for p in range(13)if o>>p&1)
    allowed=127
    for q in (a,b):
        if tags[q].bit_count()>=2: allowed &=tags[q]
    low=[p for p,t in enumerate(tags)if t.bit_count()==1 and not o>>p&1]
    for sig in range(1,128):
        if join&~sig or sig&~allowed:continue
        for m in range(1<<len(low)):
            moved={q for i,q in enumerate(low)if m>>i&1}
            dirty=127^sat
            copies=[1+((o>>p)&1)for p in range(13)] + [2-((sig>>u)&1)for u in range(7)] + [2]
            for q in moved:
                if q in (a,b):
                    dirty|=sig
                    copies[-1]-=1
                else:
                    dirty|=tags[q]
                    copies[13+tags[q].bit_length()-1]-=1
            def proj(r):
                return r | (int(bool((r>>13)&sig))<<20)
            ps=[proj(r) for r in P if (q:=(r&8191).bit_length()-1) not in moved and
                (not (o>>q&1) or not ((r>>13)&dirty))]
            ns=[proj(r)for r in N]
            print(geometry,o,sig,m,code_model(ps,ns,copies,500),flush=True)
