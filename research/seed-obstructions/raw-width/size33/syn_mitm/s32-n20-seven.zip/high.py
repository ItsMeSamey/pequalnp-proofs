from groups import *
from collections import Counter
def inspect(gs):
 sat=sum(1<<u for u,t in enumerate(stars)if sum(bool(g&t)for g in gs)==2)
 c=[]
 for g in gs:
  exact=sum(1<<p for p in range(13)if g>>p&1 and tags[p].bit_count()>=2 and tags[p]&sat)
  c.append(sum(max(0,(exact&t).bit_count()-1)for u,t in enumerate(stars)if sat>>u&1))
 return sat,c
if __name__=='__main__':
 cc=Counter()
 for gs,o in census():
  sat,c=inspect(gs)
  cc[o.bit_count(),all(v<g.bit_count()for g,v in zip(gs,c))]+=1
 print(cc)
