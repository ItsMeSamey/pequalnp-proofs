from inputs import *
from itertools import combinations
from collections import Counter
tags=[sum(1<<j for j,t in enumerate(stars)if t>>p&1)for p in range(13)]
def ok(ss):return all(sum(bool(t&(1<<j))for t in ss)<=2 for j in range(7))
def census():
 assert all(not ok([tags[p]for p in w])for w in combinations(range(13),8))
 count=Counter(); masks=Counter()
 for seed in combinations(range(13),7):
  labels=[tags[p]for p in seed]
  if not ok(labels):continue
  rem=[p for p in range(13)if p not in seed]
  points=[1<<p for p in seed]
  def walk(i,omit):
   if i==len(rem):
    count[omit.bit_count()]+=1;masks[omit]+=1
    yield tuple(points),omit
    return
   p=rem[i];yield from walk(i+1,omit|1<<p)
   for h,z in enumerate(seed):
    if p<z:continue
    l=labels[h];labels[h]|=tags[p];points[h]|=1<<p
    if ok(labels):yield from walk(i+1,omit)
    points[h]^=1<<p;labels[h]=l
  yield from walk(0,0)
if __name__=='__main__':
 res=list(census());print(len(res),Counter(o.bit_count()for _,o in res))
 print('omissions',Counter(k[0].bit_count()for k in set((o,)for _,o in res)))
