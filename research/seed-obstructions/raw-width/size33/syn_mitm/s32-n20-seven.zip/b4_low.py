from literal_kw import code_model, copies
from groups import stars,tags
from inputs import P,N
from orbits import orbits
from itertools import combinations
for (gs,o),keep in orbits.items():
    if not keep or o.bit_count()!=4:continue
    low=[p for p,t in enumerate(tags) if t.bit_count()==1 and not o>>p&1]
    for size in range(5):
        for moving in combinations(low,size):
            dirty=sum(tags[p] for p in moving)
            allowed=[]
            for row in P:
                q=(row&8191).bit_length()-1
                if q not in moving and (not (o>>q&1) or not (row>>13&dirty)):
                    allowed.append(row)
            mult=copies(o)
            for p in moving:
                mult[13+tags[p].bit_length()-1]-=1
            print(o,moving,len(allowed),code_model(allowed,N,mult,500),flush=True)
    break
