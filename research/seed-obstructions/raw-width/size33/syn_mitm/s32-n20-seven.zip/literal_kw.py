"""Necessary rectangle partition on the exact raw samples for specified source copies."""
from itertools import combinations
from pysat.formula import IDPool
from pysat.solvers import Solver
from inputs import P, N, stars
from groups import tags
from samples import actions
import argparse


def copies(omitted):
    p = [1 + ((omitted >> i) & 1) for i in range(13)]
    u = [max(2, (star & ~omitted).bit_count()) for star in stars]
    return p + u


def model(omitted, budget, allowed=None):
    multiplicity = copies(omitted)
    return code_model(P if allowed is None else allowed, N, multiplicity, budget)


def code_model(positive, negative, multiplicity, budget):
    positives, negatives = sorted(set(positive)), sorted(set(negative))
    ids = IDPool()
    with Solver(name="cadical195") as s:
        rows = [[i for i, p in enumerate(positives) if p >> x & 1] for x in range(len(multiplicity))]
        def row(x, j, i):
            return ids.id(("r", x, j, i))
        forced = {(i,x) for x in range(len(multiplicity)) for i in rows[x] if any((positives[i] & ~n) == 1 << x for n in negatives)}
        for x, count in enumerate(multiplicity):
            for i in rows[x]:
                if (i,x) in forced:
                    s.add_clause([row(x, j, i) for j in range(count)])
            # Order the row membership vectors to break interchangeable copy symmetry.
            for j in range(count-1):
                e = None
                for i in rows[x]:
                    a,b = row(x,j,i),row(x,j+1,i)
                    pref = [] if e is None else [-e]
                    s.add_clause(pref + [a,-b])
                    f = ids.id(("eq", x,j,i))
                    s.add_clause(pref + [a,b,f])
                    s.add_clause(pref + [-a,-b,f])
                    e = f
        for integer in negatives:
            for i,p in enumerate(positives):
                terms = []
                for x in range(len(multiplicity)):
                    if not (p & ~integer) >> x & 1:
                        continue
                    for j in range(multiplicity[x]):
                        col = ids.id(("c",x,j,integer))
                        if multiplicity[x] == 1 and (i,x) in forced:
                            terms.append(col)
                            continue
                        r = row(x,j,i)
                        z = ids.id(("z", x,j,i,integer))
                        s.add_clause([-z,col]); s.add_clause([-z,r]); s.add_clause([z,-col,-r])
                        terms.append(z)
                s.add_clause(terms)
                for a,b in combinations(terms,2):
                    s.add_clause([-a,-b])
        s.conf_budget(budget)
        return s.solve_limited(), s.accum_stats()["conflicts"]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=int)
    parser.add_argument("--budget", type=int, default=2000)
    args = parser.parse_args()
    orbit = actions(P,N)
    domains = {min(a[o] for a in orbit) for o in range(8192) if sum(copies(o)) == 33}
    representatives = sorted(domains)
    for i,o in enumerate(representatives):
        if args.index == i:
            print(i,o,model(o,args.budget),flush=True)
        elif args.index is None:
            print(i,o,copies(o))
