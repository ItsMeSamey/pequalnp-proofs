from ast import literal_eval
from collections import Counter
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile
from groups import census, stars, tags
from inputs import N, P
from samples import actions
from orbits import orbits

def replay(name, count):
    lines=subprocess.check_output([sys.executable,name],text=True).splitlines()
    tested=[s for s in lines if not s.startswith(("all ","conditional "))]
    assert len(tested)==count and all("(False," in s for s in tested)
    print(name,count,"UNSAT",flush=True)

cases=list(census())
assert len(cases)==163 and all(all(any(g&t for g in gs)for t in stars) for gs,o in cases)
assert Counter(o.bit_count() for (gs,o),keep in orbits.items() if keep)=={4:4,5:6,6:4}
group=actions(P,N)
small={min(a[o] for a in group)for (gs,o),keep in orbits.items()if keep and o.bit_count()==4}
assert len(small)==1
for o in small:
    heavy=[t for t in stars if (t & ~o).bit_count()>2]
    assert len(heavy)==1 and (heavy[0]&~o).bit_count()==4
    assert all(tags[p].bit_count()>=2 for p in range(13)if heavy[0]>>p&1 or o>>p&1)
assert all(any(n>>p&1 and n>>q&1 for n in N)for p in range(13)for q in range(13))
assert all(any(n>>p&1 and n>>(13+u)&1 for n in N) for p in range(13)for u in range(7)if not tags[p]>>u&1)
replay("b4_low.py",16)
replay("b5_low.py",144)
with tempfile.TemporaryDirectory() as temp:
    with ZipFile("s32-n20-b6-clean.zip") as z:z.extractall(temp)
    for mask in (1923,3717,3969,8064):
        line=subprocess.check_output([sys.executable,"clean6.py",str(mask)],cwd=temp,text=True)
        assert "(False," in line
    print("clean6.py 4 UNSAT",flush=True)
print("seven-owner grouped cases completed")
