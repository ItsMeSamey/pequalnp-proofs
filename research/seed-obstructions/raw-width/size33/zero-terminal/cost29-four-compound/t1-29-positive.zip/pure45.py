from resources import *
from exterior import check
import ast
from collections import defaultdict
tab=defaultdict(list)
for key,(ids,rs)in json.load(open('rows.json')).items():
 g,c,w=ast.literal_eval(key)
 if c or not any(i>=4169 for i in ids):continue
 for O,b in rs:
  if O.bit_count()in (2,3):tab[O].append(dict(w))
s=Source(0);s.bank(());calls=0
for i,(O,ds)in enumerate(sorted(tab.items())):
 w={p:min(d[p]for d in ds)for p in ds[0]if all(p in d for d in ds)}
 oo=tuple(x for x in range(7)if O>>x&1);M=s.roles(O,14)[1];b=14-7+len(oo)-len(set(M)|set(w))-sum(n-2 for n in w.values())
 retain=not check(s,oo)
 for a in range(b+1):
  if calls>=200:raise SystemExit
  v=run(s,oo,14,a,500,retain,w);calls+=1
  print(i,O,a,w,retain,v,flush=True)
