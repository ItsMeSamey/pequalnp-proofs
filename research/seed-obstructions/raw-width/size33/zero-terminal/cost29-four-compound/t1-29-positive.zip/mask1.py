import ast,sys
import maskflex
from pathlib import Path
for line in Path('named15.log').read_text().splitlines():
 i,c,O,a,ret,r=line.split(' ',5);i=int(i);c=ast.literal_eval(c);O=int(O);a=int(a)
 if not int(sys.argv[1])<=i<int(sys.argv[2]):continue
 done,ps=ast.literal_eval(r);assert done is False and ret=='True'
 allp={(tuple(sorted(p for p in rr if p>0)),sum(p<0 for p in rr),ex)for rr,ex in ps}
 mx=[(r,h,s)for r,h,s in sorted(allp)if not any((set(r)<set(t)or h<k or s<z)and set(r)<=set(t)and h<=k and s<=z for t,k,z in allp)]
 keep=[]
 for r,h,sp in mx:
  if maskflex.calls>=1400:raise SystemExit
  try:v=maskflex.signed(c,O,r,tuple(p for p in r if p in (1,4,256)),(),sp,bool(h))if h<=1 else True
  except TimeoutError:raise SystemExit
  if v:keep.append((r,h,sp))
 print(i,c,O,a,keep,maskflex.calls,flush=True)
