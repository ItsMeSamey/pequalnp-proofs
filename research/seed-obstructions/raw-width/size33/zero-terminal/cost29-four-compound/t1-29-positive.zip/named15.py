from resources import *
from exterior import check
from collections import defaultdict
import ast
T=defaultdict(list)
for key,(ids,roles)in json.loads(Path('rows.json').read_text()).items():
 g,c,w=ast.literal_eval(key);orig=[i for i in ids if i>=4169]
 if not orig or len(c)!=1:continue
 for O,b in roles:
  if O.bit_count()==2:T[c,O].append((dict(w),orig))
for i,((c,O),group)in enumerate(sorted(T.items())):
 if not int(sys.argv[1])<=i<int(sys.argv[2]):continue
 ds=[w for w,_ in group];w={q:min(d[q]for d in ds)for q in ds[0]if all(q in d for d in ds)}
 assert all(w.get(p,0)>=2 for p in (1,4,256))
 sc=Source(0);sc.bank(c);k=13;oo=tuple(t for t in range(7)if O>>t&1);M=sc.roles(O,k)[1]
 b=k-5-len(set(M)|set(w))-sum(n-2 for n in w.values());retain=not check(sc,oo)
 for an in range(b+1):
  ans=run(sc,oo,k,an,500,retain,w)
  print(i,c,O,an,retain,ans,flush=True)
