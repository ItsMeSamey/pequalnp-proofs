from rawregional import *
s=Source(0);s.bank(())
print(run(s,tuple(range(7)),14,5,40000,w={1:2,4:2,256:2}),flush=True)
