from core import *
from itertools import combinations_with_replacement
s=Source(0);D=(129,354,523,1046,2092,4160)
# All 57 destination banks embed in this fixed signed physical sample. A selected replacement is always available.
C=s.pts+D+tuple(-i-1 for i in range(7))
bit={q:q.bit_length()-1 if q in s.pts else library[q] if q>0 else 12-q for q in C}
sig=lambda rows,q:sum(1<<i for i,row in enumerate(rows)if row>>bit[q]&1)
p={q:sig(s.P,q)for q in C};n={q:sig(s.N,q)for q in C}
rows=[]
for x,y in combinations_with_replacement(C,2):
 for op in ('AND','OR'):
  gp=p[x]&p[y]if op=='AND'else p[x]|p[y]
  gn=n[x]&n[y]if op=='AND'else n[x]|n[y]
  replac=[q for q in C if not(gp&~p[q]or n[q]&~gn)]
  rows.append((x,y,op,gp==0,replac))
assert all(dead or any(q in s.pts for q in checks)for x,y,op,dead,checks in rows if x>0 and y>0 and x!=y and op=='AND')
assert all(dead for x,y,op,dead,checks in rows if x<0 and y<0 and x!=y and op=='AND')
Path('raw-gates.json').write_text(json.dumps(rows,separators=(',',':')))
for w in range(5):
 pools=[]
 for opt in combinations(D,w):
  live=set(s.pts)|set(opt)|set(C[-7:]);pairs=[(x,y,op)for x,y,op,dead,rr in rows if x!=y and x in live and y in live and (dead or live.intersection(rr))]
  pools.append(len(pairs))
 print(w,'distinct-port gate types debit at least one',min(pools),max(pools))
