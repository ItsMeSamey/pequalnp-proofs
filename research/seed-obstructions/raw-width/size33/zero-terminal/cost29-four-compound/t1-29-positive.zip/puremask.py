import ast
from collections import defaultdict
from pathlib import Path
import maskflex
fixed={1,4,256}
group=[]
for line in Path('equiv.log').read_text().splitlines():
 if not line.startswith('('):continue
 a,b=line.split(') ',1)
 pi=ast.literal_eval(a+')');pm=ast.literal_eval(b)
 if {pm[p] for p in fixed}==fixed:group.append(pi)
opts=defaultdict(list)
for line in Path('pure45.log').read_text().splitlines():
 pre,post=line.split('} ',1)
 i,O,an,w=pre.split(' ',3)
 assert ast.literal_eval(w+'}')==dict.fromkeys(fixed,2)
 ret,res=post.split(' ',1);assert ret=='True'
 O=int(O);done,ps=ast.literal_eval(res)
 key=min(sum(1<<pi[j]for j in range(7)if O>>j&1)for pi in group),int(an)
 terms={(tuple(sorted(p for p in rr if p>0)),sum(p<0 for p in rr),sp)for rr,sp in ps}
 terms=[(r,h,sp)for r,h,sp in sorted(terms)if not any((set(r)<set(t)or h<k or sp<s)and set(r)<=set(t)and h<=k and sp<=s for t,k,s in terms)]
 opts[key].append((done is not False,len(terms),O,terms))
for key,options in sorted(opts.items()):
 unknown,n,O,terms=min(options)
 if unknown:
  print(key,O,'UNKNOWN',flush=True);continue
 keep=[]
 for r,h,sp in terms:
  if maskflex.calls>=900:raise SystemExit
  if h>1 or maskflex.signed((),O,r,tuple(p for p in r if p in fixed),(),sp,bool(h)):keep.append((r,h,sp))
 print(key,O,keep,maskflex.calls,flush=True)
