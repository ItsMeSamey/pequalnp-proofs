from ast import literal_eval as ev
from pathlib import Path
import json,collections
killed=set()
for f in sorted(Path('.').glob('t1groups-*.log')):
 for row in f.read_text().splitlines():
  _,tail=row.split(' ',1);st=tail.index(')')+1;k=ev(tail[:st]);_,_,b,rest=tail[st+1:].split(' ',3);res=ev(rest.rsplit(' ',1)[0])
  if len(res)==int(b)+1 and all(x is False for x in res):killed.add(k)
un=collections.defaultdict(set);case=collections.Counter()
for key,(ids,roles)in json.load(open('rows.json')).items():
 g,c,w=ev(key);ids=[i for i in ids if i>=4169]
 if not ids:continue
 for O,b in roles:
  r=7-O.bit_count();k=(r,O,len(c))
  if r>3 or k in killed:continue
  un[r].update(ids);case[k]+=len(ids)
print('closed cohorts',len(killed),'surviving r',[(r,len(un[r]))for r in range(4)],'remaining groups',len(case))
Path('low-left.txt').write_text(repr(dict(case)))
