from rawregional import *
from collections import defaultdict
import ast
T=defaultdict(list)
for key,(ids,rows)in json.loads(Path('rows.json').read_text()).items():
 g,c,w=ast.literal_eval(key);ids=[i for i in ids if i>=4169]
 if g!=29 or not ids:continue
 for O,b in rows:
  r=7-O.bit_count()
  if r<=3:T[(r,O,len(c))].append((c,dict(w),ids))
q=sorted(T,key=lambda k:(k[0],-sum(len(j)for c,w,j in T[k]),k));calls=0
left=set(ast.literal_eval(Path("low-left.txt").read_text()))
for n,key in enumerate(q):
 if not int(sys.argv[1])<=n<int(sys.argv[2]):continue
 if key not in left:continue
 group=T[key];r,O,d=key;C=tuple(sorted(set().union(*[set(c)for c,w,ids in group])));ww={p:min(w[p]for c,w,ids in group)for p in group[0][1]if all(p in w for c,w,ids in group)}
 s=Source(0);s.bank(C);k=14-d;M=s.roles(O,k)[1];b=k-r-len(set(M)|set(ww))-sum(z-2 for z in ww.values());os=tuple(i for i in range(7)if O>>i&1);res=[]
 for a in range(b+1):
  if calls>=74:break
  res.append(run(s,os,k,a,5000,w=ww));calls+=1
  if res[-1]is not False:break
 print(n,key,len(group),sum(len(ids)for c,w,ids in group),b,res,calls,flush=True)
 if calls==74:break
