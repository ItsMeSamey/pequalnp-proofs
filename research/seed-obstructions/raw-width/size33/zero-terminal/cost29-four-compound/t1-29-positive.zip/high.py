from rawregional import *
from exterior import check
from collections import defaultdict
import ast
T=defaultdict(list)
for key,(ids,rows)in json.loads(Path('rows.json').read_text()).items():
 g,c,w=ast.literal_eval(key);ids=[i for i in ids if i>=4169]
 if g!=29 or not ids:continue
 for O,b in rows:
  r=7-O.bit_count()
  if r in (4,5):T[r,O,c].append((dict(w),ids))
queries=sorted(T,key=lambda k:-sum(len(ids)for w,ids in T[k]))
cnt=0
for j,(r,O,C)in enumerate(queries):
 if not int(sys.argv[1])<=j<int(sys.argv[2]):continue
 ds=[w for w,ids in T[r,O,C]];w={p:min(d[p]for d in ds)for p in ds[0]if all(p in d for d in ds)}
 s=Source(0);s.bank(C);oo=tuple(t for t in range(7)if O>>t&1);k=14-len(C);M=s.roles(O,k)[1]
 b=k-r-len(set(M)|set(w))-sum(n-2 for n in w.values());ret=not check(s,oo);ans=[]
 for a in range(b+1):
  if cnt>=200:break
  ans.append(run(s,oo,k,a,500,ret,w));cnt+=1
  if ans[-1]is not False:break
 print(j,r,O,C,b,ret,ans,cnt,flush=True)
 if cnt>=200:break
