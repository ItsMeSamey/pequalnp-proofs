from pathlib import Path
import json
from collections import Counter
tab=json.loads(Path('inert-keyed.json').read_text());live=set(map(int,json.loads(Path('original-live-v2.json').read_text())))
allkeys=json.loads(Path('rolekeys.json').read_text())
safe={i for c,w,ids,rs in allkeys if not set(ids)&live for i in ids}
stats=Counter();closed=[]
for i,(t,b,c,w,exact,weak)in tab.items():
 if b!=28:continue
 assert exact is not None
 ok=any(j in safe for j in weak)
 stats[t,ok]+=1
 if ok:closed.append(int(i))
print(dict(stats))
Path('inert-r6-closed.json').write_text(json.dumps(sorted(closed)))
