from pathlib import Path
from ast import literal_eval as ev
import sys,maskbranch
for i,(case,c,O,a,z,h,sp)in enumerate(ev(Path('mask-one-left').read_text())):
 if not int(sys.argv[1])<=i<int(sys.argv[2]):continue
 c=ev(c);O=int(O)
 assert h==1 and sp==0
 try:v=maskbranch.chk(c,O,z,tuple(p for p in z if p in (1,4,256)),(),True,(),0)
 except TimeoutError:break
 print(i,case,c,O,a,z,bool(v),maskbranch.nc,flush=True)
