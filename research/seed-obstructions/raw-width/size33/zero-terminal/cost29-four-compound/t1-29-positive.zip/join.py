import gzip,json
from ast import literal_eval as ev
from collections import Counter,defaultdict
from pathlib import Path
pts=(1,4,64,128,256,512,1024,2048,4096);cats=defaultdict(list);result={}
for c,w,ids in ev(Path('allkeys.txt').read_text()):cats[c].append((w,min(ids)))
counts=Counter()
for i,line in enumerate(gzip.open('terminal-raw-keys.jsonl.gz','rt')):
 t,E,R,C,j,a,b,old=json.loads(line)
 if old or 0 not in a or (t,b)not in ((0,28),(1,28),(0,29)):continue
 nw=Counter(pts);nw.update(q for q in a if q);c=tuple(sorted(set(nw)-set(pts)));w=tuple((x,v)for x,v in sorted(nw.items())if v>1)
 exact=next((idx for ww,idx in cats[c]if ww==w),None)
 domin=[idx for ww,idx in cats[c]if all(nw[p]>=cnt for p,cnt in ww)]
 assert domin
 result[i]=(t,b,c,w,exact,domin);counts[t,b,exact is not None]+=1
Path('inert-keyed.json').write_text(json.dumps(result,separators=(',',':')))
print(sorted(counts.items()))
