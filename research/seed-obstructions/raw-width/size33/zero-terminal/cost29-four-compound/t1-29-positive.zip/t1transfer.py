import json,ast
from collections import defaultdict,Counter
T=defaultdict(list);L=[]
for key,(ids,rs)in json.load(open('rows.json')).items():
 g,c,w=ast.literal_eval(key)
 if g!=29:continue
 t1=[i for i in ids if i>=4169]
 if t1:T[c].append((w,t1))
 t0=[i for i in ids if i<4169]
 if t0:L.append((c,dict(w),t0))
s=Counter()
for c,w,ids in L:
 if any(all(w.get(q,1)>=n for q,n in W)for W,_ in T[c]):s[len(c)]+=len(ids)
print(s)
