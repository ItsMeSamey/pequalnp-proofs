from core import *
import gzip
from collections import defaultdict
g=defaultdict(list);tag={};hist=Counter()
s=Source(0)
for i,line in enumerate(gzip.open('terminal-raw-keys.jsonl.gz','rt')):
 t,E,R,C,_,a,b,old=json.loads(line)
 if old or (t!=0 and not(t==1 and b==29)):continue
 c=tuple(sorted(set(a)-set(s.pts)-{0}));w=Counter(s.pts);w.update(q for q in a if q)
 ww=tuple((q,n)for q,n in sorted(w.items())if n>1)
 hist[t,b,a.count(0)]+=1;tag[i]=(t,b,0 in a)
 if 0 in a:continue
 g[c,b,ww].append(i)
print('source-budgets and inert counts',dict(sorted(hist.items())),flush=True)
out={}
for c in sorted({k[0]for k in g}):
 s.bank(c)
 for (cc,b,ww),ids in g.items():
  if c!=cc:continue
  w=dict(ww);k=b-15-len(c);roles=[]
  for O in range(1,128):
   d,M,_,_=s.roles(O,k);r=7-O.bit_count();U=set(w)|set(M)
   cash=k-r-sum(max(1,w.get(p,1)-1)for p in U)
   req=tuple(sorted(d[p]for p in M if d[p].bit_count()>max(2,w.get(p,0))and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&O for q in M)))
   if pass_budget(req,cash):roles.append((O,cash))
  out[str((b,c,ww))]=(ids,roles)
 s.dom.cache_clear();s.reject.cache_clear()
Path('rows.json').write_text(json.dumps(out,separators=(',',':')))
for t,b,h in sorted(hist):
 if h:continue
 count=Counter()
 for ids,roles in out.values():
  n=sum(tag[i]==(t,b,False)for i in ids)
  if n:count[min([7-O.bit_count()for O,k in roles]+[7])]+=n
 print('t,b',t,b,'local floor',dict(sorted(count.items())))
