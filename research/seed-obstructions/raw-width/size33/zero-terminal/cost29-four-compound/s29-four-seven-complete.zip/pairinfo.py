from allpins import *
p,q=256,512
for h,b in enumerate(cs):
 print(h,cov[h][p],cov[h][q],bool(b&(F[p]&pt[q]|F[q]&pt[p])),up[h][p]&up[h][q],disjoint(p,q,h))
