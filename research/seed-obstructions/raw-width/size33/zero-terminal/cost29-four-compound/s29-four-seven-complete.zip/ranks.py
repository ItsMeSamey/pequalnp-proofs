from census import *
from weightedholder import actual
import sys
def feasible(c,z,gs,g,ds,sp):
 assert not any(p<=0 for p in gs)
 H=1<<len(c);q=bm(z)
 groups=[tuple(bm(b))for b in gs]+[(-1-i,)for i in range(g)]
 assert set(q)=={p for b in gs for p in bm(b)}
 F={p:~pt[p]&line(inc[p])&pack(lambda n:all(not p&x or n>>extra[x]&1 for x in c))for p in q}
 pr=[(p,1<<(H-1))for p in q]
 U=[]
 for h in range(H):
  nmask=pack(lambda n:all(not h>>j&1 or n>>extra[x]&1 for j,x in enumerate(c)))
  U.append([sum(1<<u for u in range(7)if not any(nmask&F[p]&on[u]for p in bm(b)))for b in gs]+[127]*g)
 return actual(c,pr,[[0]*len(groups)for h in range(H)],(),groups,sp,U)
if __name__=='__main__':
 i=int(sys.argv[1])
 for record in Path(f'joint{i}.log').read_text().splitlines():
  c,w,ids,n,S=ast.literal_eval(record)
  assert not w
  for j,s in enumerate(S):
   if len(sys.argv)>2 and j<int(sys.argv[2]):continue
   print((s,feasible(c,*s)),flush=True)
