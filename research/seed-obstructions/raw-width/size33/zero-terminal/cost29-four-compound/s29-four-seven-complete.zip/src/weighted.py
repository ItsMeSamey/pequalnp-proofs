from missing import banks
from geometry import *
from cps import enough
from all4 import test as cuts,extra
from collections import defaultdict
from itertools import product
from pathlib import Path
def checked(C):
 m=8133|sum(1<<extra[c]for c in C);pos={r&8191:r&m for r in P}
 f={p:pack(lambda n:not n&p and not(pos[p]&~p)&~n and n>>13&inc[p]) for p in pts}
 top=pack(lambda n:all(n>>extra[c]&1 for c in C))
 assert all(top&(f[p]&pt[q]|f[q]&pt[p])for p,q in combinations(pts,2))
 layers={}
 for h,v,k in cuts(P,N,8133,C):
  hh=sum(1<<C.index(c)for c in h)
  neg=pack(lambda n:all(n>>extra[c]&1 for c in h))
  key=hh,k
  if key not in layers:layers[key]=[]
  layers[key].append(v)
 # Per K retain only maximal tag sets, since restrictions/savings are monotone
 out=set()
 for (hh,k),vs in layers.items():
  h=pack(lambda n:all(not hh>>i&1 or n>>extra[c]&1 for i,c in enumerate(C)))
  up=tuple(sum(1<<u for u in range(7)if not h&f[p]&on[u])for p in pts)
  for v in sorted(set(vs),key=int.bit_count,reverse=True):
   if not any((v&~a)==0 for a,b,t in out if k==b and up==t):out.add((v,k,up))
 return sorted(out,key=lambda t:-(t[0].bit_count()*t[1].bit_count()))
def layouts(C,w):
 W=dict(w);q=[p for p in pts if p in W];rawextras=[x for x in W if x not in pts]
 budget=6-len(C)-sum(n-1 for p,n in w)
 rest=[p for p in pts if p not in W]
 for a in range(budget+1):
  for t in combinations(rest,a):
   for g in range(budget-a+1):
    for ds in product(range(budget-a-g+1),repeat=a+g):
     spare=budget-a-g-sum(ds)
     if spare<0:continue
     yield sum(q)+sum(t),t,g,ds,spare
def screen(C,w,cuts):
 kept=[]
 for z,t,g,ds,spare in layouts(C,w):
  for v,k,up in cuts:
   gs=tuple(sorted(inc[p]&v for p in pts if p&k&~z))
   sup=tuple(sorted((0 if p&k else up[pts.index(p)]&v,2+ds[i])for i,p in enumerate(t)))+tuple((127,2+d)for d in ds[len(t):])
   if not enough(gs,v,sup,spare):break
  else:kept.append((z,g,ds,spare))
 return kept
if __name__=='__main__':
 jobs=defaultdict(list)
 for i,c,w in banks():jobs[c,w].append(i)
 assert len(jobs)==61 and sum(map(len,jobs.values()))==138
 data={}
 for (c,w),ids in sorted(jobs.items()):
  if c not in data:data[c]=checked(c)
  a=screen(c,w,data[c]);print((c,w,ids,a),flush=True)
