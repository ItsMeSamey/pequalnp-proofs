from core import *
T=(129,354,523,1046,2092,4160)
Z=2|8|16|32
pts=[1<<j for j in range(13) if not Z>>j&1]
def banks():
 for idx,(j,R,C) in enumerate(json.loads(Path('banks.json').read_text())):
  if R&2 or 2 in list(combinations((2,8,16,32),2))[j]:continue
  cnt=Counter(p for p in pts if R&p)
  for c in C:
   choices=[d for d in (*pts,*T)if not d&~c and (d^c)&~Z==0]
   d=min(choices,key=lambda q:(q.bit_count(),q));cnt[d]+=1
  w=tuple(sorted((p,i)for p,i in cnt.items()if i>=2))
  assert all(cnt[x]>=2 for x in (1,4,256))
  yield idx,tuple(p for p in T if cnt[p]),w
def census():
 s=Source(0);out=[];ct=Counter()
 bank=list(banks());assert len(bank)==138 and len({c for i,c,w in bank})==22
 cache={}
 for i,c,w in bank:
  if (c,w)not in cache:
   s.bank(c);r=[];k=13-len(c)
   for om in range(1,128):
    dm,M,_,b=s.roles(om,k)
    w0=dict(w);active=set(M)|set(w0)
    left=k-(7-om.bit_count())-sum(max(1,w0.get(p,1)-1)for p in active)
    req=[]
    for p in M:
     if dm[p].bit_count()<=max(2,w0.get(p,0)):continue
     if all(q==p or(q in w0 and not q&p)or(q in M and(s.no[q,p]or s.no_t[q,p]&om))for q in active):
      req.append(dm[p])
    if pass_budget(tuple(sorted(req)),left):r.append((om,left))
   cache[c,w]=r
  for om,left in cache[c,w]:
   out.append((i,c,w,om,left));ct[7-om.bit_count()]+=1
 print(len(cache),sorted(ct.items()),'distinct unlabelled',Counter(7-om.bit_count()for c,w,om,b in {(c,w,om,b)for i,c,w,om,b in out}))
 Path('raw-live.txt').write_text(repr(out))
if __name__=='__main__':census()
