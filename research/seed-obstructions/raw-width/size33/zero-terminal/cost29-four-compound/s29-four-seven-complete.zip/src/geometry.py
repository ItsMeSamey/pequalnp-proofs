from cuts import load, bm, DEGREE_ONE
from itertools import combinations
from functools import cache
P,N=load(tuple(DEGREE_ONE));pts=bm(8133)
def pack(f):return sum(1<<i for i,n in enumerate(N)if f(n))
alln=(1<<len(N))-1
stars=tuple(sum(r&8191 for r in P if r>>(13+u)&1)for u in range(7))
inc={p:sum(1<<u for u,s in enumerate(stars)if s&p)for p in pts}
on=[pack(lambda n:n>>(13+u)&1) for u in range(7)]
pt={p:pack(lambda n:n&p)for p in pts}
meet=[pack(lambda n:n&s)for s in stars]
def union(I):
 a=0
 for x in I:a|=x
 return a
def line(m):return union(on[u]for u in range(7)if m>>u&1)
