from pathlib import Path
import subprocess,sys
from ast import literal_eval as ev
from collections import Counter
R=Path(__file__).resolve().parent;L=R/'ledgers'
def run(name,args):
 return subprocess.check_output([sys.executable,str(R/name),*map(str,args)],cwd=L).decode()
def exact(name,args,log):assert run(name,args)==(L/log).read_text()
step=sys.argv[1]
if step=='census':
 assert run('make.py',[])==(R/'make.log').read_text()
 assert run('census.py',[])==(R/'counts.log').read_text()
for i in (list(map(int,sys.argv[2:]))or list(range(15))):
 if step=='census':exact('census.py',[i],f'{i}.log')
 if step=='cross'and(L/f'joint{i}.log').exists():exact('cross.py',[i],f'joint{i}.log')
 if step=='rank'and(L/f'rank{i}.log').exists():exact('ranks.py',[i],f'rank{i}.log')
 if step=='cancel'and(L/f'rank{i}.log').exists():
  for f in L.glob(f'cancel{i}-*.log'):
   a=int(f.stem.split('-')[1]);exact('cancel.py',[i,a,a+15],f.name)
 if step=='sockets'and(L/f'slots{i}.log').exists():exact('slots.py',[i],f'slots{i}.log')
if step=='last':
 exact('pairinfo.py',[14],'pairinfo.log')
 got=[ev(l)for l in run('jointlow.py',[14]).splitlines()if l.startswith('((')]
 saved=[ev(l)for l in(L/'jointlow.log').read_text().splitlines()if l.startswith('((')]
 assert Counter(got)==Counter(saved)
 exact('twoplus.py',[14],'twoplus.log')
