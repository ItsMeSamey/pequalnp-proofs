from allpins import *
pair=[256,512]
bothmarks=768
def test(s):
 z,gs,g,ds,sp=s
 if bothmarks not in gs:return None
 h=0
 assert all(cov[h][p]==inc[p]for p in pair)
 # Each raw q that dominates a p-masking negative cannot remain positive
 # at the corresponding bare state in their common region.
 dark=[q for p,q in (pair,pair[::-1])if F[p]&pt[q]&cs[h]]
 print('dark',dark,flush=True)
 if not dark:return True
 s2=(z^union(dark),gs,g,ds,sp)
 ans=route((),s2)
 return ans if ans is not True else route((),s2,True)
for f in Path('.').glob('cancel14-*.log'):
 for l in f.read_text().splitlines():
  s,res=ast.literal_eval(l)
  if res is True and bothmarks in s[1]:print((s,test(s)),flush=True)
