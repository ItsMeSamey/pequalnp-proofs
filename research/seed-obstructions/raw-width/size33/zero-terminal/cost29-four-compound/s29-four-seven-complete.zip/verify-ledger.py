from pathlib import Path
from ast import literal_eval as ev
from collections import Counter
base=Path(__file__).resolve().parent/'ledgers'
status={};tail=[]
for i in range(15):
 c,w,ids,S=ev((base/f'{i}.log').read_text());assert not w
 j=base/f'joint{i}.log'
 if S:
  C,W,J,n,T=ev(j.read_text());assert (C,W,J,n)==(c,w,ids,len(S))and set(T)<=set(S);S=T
 if S:
  rank=dict(ev(l)for l in (base/f'rank{i}.log').read_text().splitlines())
  assert set(rank)==set(S);S=[s for s in S if rank[s]]
 if S:
  partial=dict(ev(l)for f in base.glob(f'cancel{i}-*.log')for l in f.read_text().splitlines())
  z0=(0,(),3,(0,0,0),0)
  assert set(partial)==set(S)-{z0}
  if z0 in S:assert any(l.endswith(' False')for l in(base/f'slots{i}.log').read_text().splitlines())
  S=[s for s in S if s!=z0 and partial[s]is not False]
 assert not set(status)&set(ids)
 status.update({a:'open'if S else 'excluded'for a in ids});tail.extend((i,s)for s in S)
print(dict(Counter(status.values())),tail)
assert len(status)==41 and sum(v=='excluded'for v in status.values())==37
assert {i for i,s in tail}=={14}
rest={s for i,s in tail}
j=[ev(l) for l in (base/'jointlow.log').read_text().splitlines()if l.startswith('((')]
assert set(s for s,v in j if v is False)=={s for s in rest if 768 in s[1]}
assert len(j)==10 and rest-{s for s,v in j}=={(0,(),2,(0,0),1)}
cells=[l.split() for l in(base/'twoplus.log').read_text().splitlines()]
assert set(map(tuple,cells))=={(str(h),str(i),'False')for h in (False,True)for i in range(7)}
print('41 of 41 original t0 size-29 four-compound IDs excluded; no t1 size-29 four-compound ID')
