from census import *
from all4 import test as licensed
def search(c,w,z,gs,g,ds,sp):
 up=UP
 H=len(gs)+g
 def visit(B):
  ub=[reduce(int.__and__,[up[p]for p in bm(b)],127) for b in B]
  for v in range(127,0,-1):
   k=sum(p for p in bm(8133&~z)if inc[p]&v and any(not (inc[p]&v)&~m for m in cover[p]) and not any(b&p and u&v for b,u in zip(B,ub)))
   # maximally grant unseparated points a shared receiver
   blocks=[p for p in bm(k)]
   for p,q in bad:
    if p&k and q&k:
     a=next(b for b in blocks if b&p);b=next(b for b in blocks if b&q)
     if a!=b:blocks.remove(a);blocks.remove(b);blocks.append(a|b)
   req=tuple(sorted(union(inc[p] for p in bm(b))&v for b in blocks))
   su=tuple(sorted((u&v,2+d)for u,d in zip(ub,ds)))
   if not enough(req,v,su,sp):return False
  return True
 rest=[p for p in pts if not p&z and UP[p]]
 for ass in product(range(-1,H),repeat=len(rest)):
  B=[*gs,*([0]*g)]
  for p,i in zip(rest,ass):
   if i>=0:B[i]|=p
  if visit(B):return True
 return False
if __name__=='__main__':
 i=int(sys.argv[1]);c=triples[i]
 cc=[[]for _ in range(1<<len(c))]
 for high,v,k in licensed(P,N,8133,c):cc[sum(1<<c.index(s)for s in high)].append((v,k))
 top=pack(lambda n:all(n>>extra[s]&1 for s in c))
 UP={p:sum(1<<u for u in range(7)if not top&~pt[p]&line(inc[p])&on[u]) for p in pts}
 cover={p:[union(v&inc[p] for v,k in cc[h]if k&p) for h in range(1<<len(c))] for p in pts}
 def clash(p,q):
  a=UP[p]&UP[q]
  common=any(inc[p]>>u&1 and inc[q]>>v&1 and not a&((1<<u)|(1<<v))and top&on[u]&on[v]for u in range(7)for v in range(7))
  sep=any(inc[x]>>u&1 and not inc[y]>>u&1 and not a>>u&1 and top&pt[y]&on[u]for x,y in ((p,q),(q,p))for u in range(7))
  return bool(common and sep)
 bad=[(p,q)for p,q in combinations(pts,2)if not clash(p,q)]
 assert all(not UP[p]&inc[p]for p in pts)
 for row in Path(str(i)+'.log').read_text().splitlines():
  c,w,ids,slots=ast.literal_eval(row)
  if len(sys.argv)>2 and not w:continue
  if slots:print((c,w,ids,len(slots),[s for s in slots if search(c,w,*s)]),flush=True)
