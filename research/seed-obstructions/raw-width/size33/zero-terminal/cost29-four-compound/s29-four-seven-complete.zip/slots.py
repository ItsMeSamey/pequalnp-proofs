from cancel import *
def slots(pins,blocks):
 ids=IDPool();var=lambda *x:ids.id(x)
 Q=list(pins);H=range(3);S=[(a,i)for a in range(10)for i in range(2)]
 with Solver(name='cadical195')as sat:
  add=sat.add_clause
  def atmost(v):
   for a,b in combinations(v,2):add([-a,-b])
  @cache
  def And(parts):
   if len(parts)==1:return parts[0]
   t=var('and',parts)
   for p in parts:add([-t,p])
   add([t]+[-p for p in parts]);return t
  def conj(*l):return And(tuple(sorted(l)))
  owner={(q,j):var('owner',q,j)for q in Q for j in H}
  for q in Q:atmost([owner[q,j]for j in H])
  loc={};dst={}
  for a,b in S:
   for j in H:
    if a>=7+j:continue
    loc[a,b,j]=var('loc',a,b,j)
   atmost([v for (s,t,j),v in loc.items()if (s,t)==(a,b)])
   for k in blocks:dst[a,b,k]=var('bin',a,b,k)
   atmost([dst[a,b,k]for k in blocks])
   for (s,t,j),l in loc.items():
    if(s,t)!=(a,b):continue
    for k in blocks:add([-l,-dst[a,b,k]]+[owner[q,j]for q in bm(k)])
  def age(a,h,u):return var('sig',a,h,u)
  for q,h in pins.items():
   k=next(k for k in blocks if k&q)
   for u in range(7):
    if not inc[q]>>u&1:continue
    for j in H:
     y=age(j,h,u)
     for r in Q:
      if not up[h][r]>>u&1:add([-y,-owner[r,j]])
     src=[]
     for a,b in S:
      if(a,b,j)not in loc or a<7 and a!=u:continue
      x=loc[a,b,j];src.append(x if a<7 else conj(x,age(a-7,h,u)))
     add([-y]+src)
    demand=[]
    for a,b in S:
     if a<7 and a!=u:continue
     witness=var('usable',a,b,q,u)
     add([-witness,dst[a,b,k]])
     if a>=7:add([-witness,age(a-7,h,u)])
     # Equality between socket-region and the counted q at the instant
     # this socket certifies q. Outside these three sources is one class.
     for j in H:
      l=loc.get((a,b,j));o=owner[q,j]
      if l:add([-witness,-l,o]);add([-witness,l,-o])
      else:add([-witness,-o])
     demand.append(witness)
    add(demand)
  # Order the two equivalent sockets by their selected terminal class.
  # Lex ranking of the absent sentinel is optional; break only defined order.
  for a in range(10):
   for x in blocks:
    for y in blocks:
     if x>y:add([-dst[a,0,x],-dst[a,1,y]])
  sat.conf_budget(50000);return sat.solve_limited()
if __name__=='__main__':
 for rev in (False,True):
  states={p:[h for h in range(1<<len(c))if cov[h][p]==inc[p]]for p in pts}
  pins={p:min(hs,key=lambda h:(h.bit_count(),-h if rev else h))for p,hs in states.items()if hs}
  blocks=list(pins)
  for p,q in combinations(pins,2):
   if not disjoint(p,q,pins[p]|pins[q]):
    a=next(k for k in blocks if k&p);b=next(k for k in blocks if k&q)
    if a!=b:blocks.remove(a);blocks.remove(b);blocks.append(a|b)
  print(rev,pins,blocks,slots(pins,blocks),flush=True)
