from ast import literal_eval
from pathlib import Path
import sys
from general import check
cases=[(c,u,ids) for c,w,ids in literal_eval(Path('allkeys.txt').read_text()) for u in (1,2,3,5)]
for i in range(int(sys.argv[1]),int(sys.argv[2])):
 c,u,ids=cases[i]
 print(i,c,u,ids,check(c,u),flush=True)
