from ast import literal_eval
from collections import Counter
from pathlib import Path
import re
banks=literal_eval(Path('allkeys.txt').read_text())
stats=Counter()
complete=[]
for b,(c,w,ids) in enumerate(banks):
 f=Path(f'shadow-{b}.log')
 if not f.exists():continue
 seen={}
 for row in f.read_text().splitlines():
  i,z,a,h,res=row.split(' ',4)
  label=(int(i),int(z),int(a),int(h))
  assert label not in seen
  seen[label]=literal_eval(res)
 expected=set()
 for i in range(4*b,4*b+4):
  row=Path(f'slack-{10*(i//10)}.log').read_text().splitlines()[i%10]
  _,c0,j,ids0,rs=re.fullmatch(r'(\d+) (\([^)]*\)) (\d+) (\[[^]]*\]) (.*)',row).groups()
  assert literal_eval(c0)==c and literal_eval(ids0)==ids
  for z,a in literal_eval(rs):
   if a:
    assert a==1 and z.bit_count()==3
    for h in range(z+1):
     if not h&~z:expected.add((i,z,a,h))
   else:expected.add((i,z,a,-1))
 assert expected==set(seen)
 live=[key for key,value in seen.items()if value is None]
 print(b,c,ids,'records',len(seen),'open',live)
 stats['records']+=len(seen);stats['open']+=len(live)
 if not live:complete+=ids
print('total',dict(stats),'complete',len(complete),sorted(complete))
