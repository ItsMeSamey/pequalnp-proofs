import ast, sys
from pathlib import Path
from clamps import clamp
from helpclamp import probe
from geometry import stars,bm
for row in Path(f'slack-{int(sys.argv[1])}.log').read_text().splitlines():
 key,c,j,ids,rs=__import__('re').fullmatch(r'(\d+) (\([^)]*\)) (\d+) (\[[^]]*\]) (.*)',row).groups()
 key,j=int(key),int(j)
 c,rs=ast.literal_eval(c),ast.literal_eval(rs)
 if not int(sys.argv[2])<=key<int(sys.argv[3]):continue
 for z,a in rs:
  if a:
   for h in range(8):
    H=sum(p for i,p in enumerate(bm(stars[j])) if h>>i&1)
    print(key,z,a,H,probe(c,j,H,0),flush=True)
  else:print(key,z,a,-1,clamp(c,j,z),flush=True)
