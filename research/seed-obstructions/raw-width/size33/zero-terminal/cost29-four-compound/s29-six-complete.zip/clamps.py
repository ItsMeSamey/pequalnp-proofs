from general import *
from cps import enough
import re,ast
def clamp(c,j,z):
 Z=bm(z);M=bm(stars[j]);other=bm(z^stars[j]);Uall=127^(1<<j)
 if z&stars[j]!=stars[j] or 8-len(c)!=len(Z):return
 states=range(1<<len(c));pa={p:sum(1<<i for i,m in enumerate(c)if p&m)for p in pts}
 ns=lambda n:sum(1<<i for i,m in enumerate(c)if n>>extra[m]&1)
 cs=[pack(lambda n:not h&~ns(n))for h in states]
 mask={p:~pt[p]&line(inc[p])&cs[pa[p]] for p in pts}
 dom={p:pt[p]&cs[pa[p]]for p in pts};meet=[union(dom[p]for p in bm(t))for t in stars]
 if not all(mask[s]&dom[p] for s in Z for p in M if s!=p):return
 if not all(dom[p]&meet[u] for u in range(7)for p in M):return
 H=meet[j]
 if not all(H&mask[p]&line(inc[p]&Uall)for p in M):return
 if not all(any(H&dom[p] for p in bm(stars[u]))for u in range(7)if u!=j):return
 for h0 in states:
  h=H&cs[h0];sp=[p for p in pts if not pa[p]&~h0]
  good=sum(1<<u for u in range(7)if u!=j and all(h&on[u]&meet[v]for v in range(7)if v not in (u,j)))
  for U in range(1,128):
   if U&~Uall:continue
   rows=[p for p in sp if inc[p]&U not in (0,U)and all(h&pt[p]&on[u]for u in range(7)if U>>u&1 and not inc[p]>>u&1) and all(h&pt[p]&meet[u]for u in range(7)if u!=j)]
   for V in range(1,128):
    if V&~(U&good):continue
    K=sum(p for p in rows if inc[p]&V and all(h&mask[p]&on[u] and h&line(inc[p]&U)&on[u]for u in range(7)if V>>u&1))
    ks={K}
    for p,q in combinations(bm(K),2):
     if inc[p]&U==inc[q]&U or not h&line(inc[p]&U)&line(inc[q]&U)or not h&(mask[p]&pt[q]|mask[q]&pt[p]):
      ks={v for k in ks for v in ((k^p,k^q)if k&p and k&q else(k,))}
    for k in ks:
     gs=tuple(inc[p]&V for p in bm(k&~sum(other)))
     sups=tuple((sum(1<<u for u in range(7)if V>>u&1 and not mask[p]&on[u]&cs[h0]),2)for p in other)
     if not enough(gs,V,sups,0):return h0,U,V,k
if __name__=='__main__':
 for f in sorted(Path('.').glob('three-*.log')):
  for row in f.read_text().splitlines():
   i,c,j,t=re.match(r'^(\d+) (\[[^\]]*\]) (\d+) (.*)$',row).groups()
   for z,a in ast.literal_eval(t):
    if a==0:print(i,z,clamp(tuple(ast.literal_eval(c)),int(j),z),flush=True)
