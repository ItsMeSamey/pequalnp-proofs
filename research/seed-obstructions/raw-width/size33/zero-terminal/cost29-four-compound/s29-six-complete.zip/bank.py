import sys
from pathlib import Path
n=int(sys.argv[1])
for lo in range(4*n,4*n+4):
 sys.argv=['shadow.py',str(lo//10*10),str(lo),str(lo+1)]
 exec(compile(Path('shadow.py').read_text(),'shadow.py','exec'),{'__name__':'__main__'})
