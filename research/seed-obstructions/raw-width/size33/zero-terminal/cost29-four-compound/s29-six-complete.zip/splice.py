from exterior import *
from ast import literal_eval
def exterior_splice(s,O,k):
 os=tuple(j for j in range(7)if O>>j&1)
 dm,M,_,b=s.roles(O,k);rel=lambda q,p: not s.no[q,p] and not s.no_t[q,p]&O
 if any(rel(q,p)for p in M for q in M if p!=q):return False
 if b==0:return all(dm[p]&O for p in M)
 if b!=1 or len(os)!=2:return False
 busy=[p for p in M if dm[p].bit_count()==3]
 if len(busy)!=1:return False
 p,=busy
 if dm[p]!=(O|128):return False
 reach=[{q for q in s.phys if not s.reject(t,(s.pp[p]&~p)|s.pp[q])}for t in os]
 er=s.F[p]&s.on[s.inc[p]&~O]&s.Ehits[O]
 forbidden={q for q in s.phys if er&s.domq[q]}
 hi=(reach[0]&reach[1])|((reach[0]|reach[1])-forbidden)
 return not any(q in hi for q in M if q!=p)
def stage(rem):
 s=Source(rem);key=None;C=Counter();out=[]
 for n,c,o,O,b in literal_eval(Path(f'remaining-{rem}.txt').read_text()):
  if key!=(c,o):s.bank(c,o);key=(c,o)
  if exterior_splice(s,O,32-n)and not check(s,tuple(j for j in range(7)if O>>j&1)):C[n,7-O.bit_count()]+=1
  else:out.append((n,c,o,O,b))
 print(rem,sorted(C.items()),'remaining',Counter((n,7-O.bit_count(),b)for n,c,o,O,b in out),flush=True)
 Path(f'postsplice-{rem}.txt').write_text(repr(out)+'\n')
if __name__=='__main__':
 for r in map(int,sys.argv[1:]):stage(r)
