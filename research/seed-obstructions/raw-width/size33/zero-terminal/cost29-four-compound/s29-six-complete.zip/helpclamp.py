from general import *
from cps import enough
import re,ast
def probe(c,j,Hmask,xx):
 z=stars[j]
 Z=bm(z);M=bm(stars[j]);other=bm(z^stars[j]);Uall=127^(1<<j)
 if 8-len(c)!=1+len(Z):return
 states=range(1<<len(c));pa={p:sum(1<<i for i,m in enumerate(c)if p&m)for p in pts}
 ns=lambda n:sum(1<<i for i,m in enumerate(c)if n>>extra[m]&1)
 cs=[pack(lambda n:not h&~ns(n))for h in states]
 mask={p:~pt[p]&line(inc[p])&cs[pa[p]] for p in pts}
 dom={p:pt[p]&cs[pa[p]]for p in pts};meet=[union(dom[p]for p in bm(t))for t in stars]
 if not all(mask[s]&dom[p] for s in Z for p in M if s!=p):return
 if not all(dom[p]&meet[u] for u in range(7)for p in M):return
 H=meet[j] & (union(dom[p] for p in bm(Hmask))if Hmask else alln)
 
 if not all(any(H&dom[p] for p in bm(stars[u]))for u in range(7)if u!=j):return
 for h0 in states:
  h=H&cs[h0];sp=[p for p in pts if not pa[p]&~h0]
  good=sum(1<<u for u in range(7)if u!=j and all(h&on[u]&meet[v]for v in range(7)if v not in (u,j)))
  for U in range(1,128):
   if U&~Uall:continue
   rows=[p for p in sp if inc[p]&U not in (0,U)and all(h&pt[p]&on[u]for u in range(7)if U>>u&1 and not inc[p]>>u&1) and all(h&pt[p]&meet[u]for u in range(7)if u!=j)]
   for V in range(1,128):
    if V&~(U&good):continue
    K=sum(p for p in rows if inc[p]&V and all(h&mask[p]&on[u] and h&line(inc[p]&U)&on[u]for u in range(7)if V>>u&1))
    ks={K}
    for p,q in combinations(bm(K),2):
     if inc[p]&U==inc[q]&U or not h&line(inc[p]&U)&line(inc[q]&U)or not h&(mask[p]&pt[q]|mask[q]&pt[p]):
      ks={v for k in ks for v in ((k^p,k^q)if k&p and k&q else(k,))}
    for k in ks:
     gs=tuple(inc[p]&V for p in bm(k&~sum(other)))
     if Hmask:
      if not enough(gs,V,(),0):return h0,U,V,k
     else:
      if enough(gs,V,((V,2),),0):continue
      if any(enough(tuple(inc[r]&V for r in bm(k^p)),V,(),0)for p in bm(k)):continue
      return h0,U,V,k
if __name__=='__main__':
 from pathlib import Path
 import re,ast,sys
 for f in sorted(Path('.').glob('three-*.log')):
  for row in f.read_text().splitlines():
   i,c,j,t=re.match(r'^(\d+) (\[[^\]]*\]) (\d+) (.*)$',row).groups();c=tuple(ast.literal_eval(c));j=int(j)
   if not int(sys.argv[1])<=int(i)<int(sys.argv[2]) or not any(a for z,a in ast.literal_eval(t)):continue
   M=bm(stars[j])
   for H in [0,sum(M)]+[sum(q) for size in (1,2) for q in combinations(M,size)]:
    print(i,j,H,probe(c,j,H,0),flush=True)
