from holder import actual
from geometry import *
from marks import extra,profile
from itertools import combinations
from functools import cache
import json,sys
from pathlib import Path
def check(c,j):
 k=8-len(c);M=tuple(profile(c,(j,))[0]);R=sum(pts)
 if len(M)>k:return []
 states=range(1<<len(c));pa={p:sum(1<<i for i,m in enumerate(c)if p&m)for p in pts}
 ns=lambda n:sum(1<<i for i,m in enumerate(c)if n>>extra[m]&1)
 cs={h:pack(lambda n:not h&~ns(n))for h in states}
 F={p:~pt[p]&cs[pa[p]]&line(inc[p])for p in pts}
 up={p:[sum(1<<u for u in range(7)if u!=j and not F[p]&on[u]&cs[h])for h in states]for p in pts}
 ret=[]
 for d in range(k-len(M)+1):
  for more in combinations([p for p in pts if p not in M],d):
   z=tuple(sorted(M+more));pr=[(p,sum(1<<h for h in states if not pa[p]&~h))for p in z]
   for a in range(k-len(z)+1):
    groups=[(p,)for p in z]+[(-i-1,)for i in range(a)]
    lo=[[0]*len(groups)for h in states]
    hi=[[up[p][h] for p in z]+[127^(1<<j)]*a for h in states]
    if actual(c,pr,lo,(),groups,k-len(groups),hi,ordinary=j):ret.append((sum(z),a))
 return ret
if __name__=='__main__':
 idx=int(sys.argv[1]);out=json.load(open('orbits.json'));c,j=out[idx][0]
 print(idx,c,j,check(tuple(c),j),flush=True)
