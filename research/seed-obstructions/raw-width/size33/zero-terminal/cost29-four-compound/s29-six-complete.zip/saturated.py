from ast import literal_eval
from collections import Counter
from pathlib import Path
from splice import Source, exterior_splice, check
s=Source(0)
counts=Counter()
for c,w,ids in literal_eval(Path('allkeys.txt').read_text()):
 assert not w
 s.bank(c)
 for u in range(7):
  O=1<<u
  _,M,_,b=s.roles(O,10)
  if b:continue
  sep=exterior_splice(s,O,10)
  result='excluded' if sep and not check(s,(u,)) else 'open'
  counts[result]+=1
  print(c,u,ids,M,sep,result,flush=True)
assert sum(counts.values())==45
print(dict(counts))
