from pathlib import Path
from collections import Counter
from ast import literal_eval
import re
files=Path('.')
expected={}
for b in range(15):
 for row in Path(f'shadow-{b}.log').read_text().splitlines():
  i,z,a,h,result=row.split(' ',4)
  if result=='None':
   assert (a,h)==('1','0') and int(i)not in expected
   expected[int(i)]=int(z)
assert len(expected)==8
for i,z in sorted(expected.items()):
 rows=Path(f'{"full" if i in (29,33) else "focus"}-{i}.log').read_text().splitlines()
 native={}
 for row in rows:
  k,B,result,n=re.fullmatch(r'(\d+) (\([^)]*\)) (\w+) (\d+)',row).groups()
  B=literal_eval(B)
  assert int(k)==i and result=='False' and B not in native
  native[B]=int(n)
 assert set(native)=={()}|{(1<<b,) for b in range(13)if z>>b&1}
 print(i,z,sum(native.values()))
print('all',len(expected),'roles closed')
