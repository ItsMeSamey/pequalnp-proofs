from geometry import *
from marks import extra
from safe_ext import actual
from pathlib import Path
from ast import literal_eval
import sys
key,limit=map(int,sys.argv[1:])
c,_,ids=literal_eval(Path('allkeys.txt').read_text())[key//4]
j=(1,2,3,5)[key%4];Z=bm(stars[j]);S=list(range(16));U=127^(1<<j)
pa={p:sum(1<<i for i,m in enumerate(c)if p&m)for p in pts}
ns=lambda n:sum(1<<i for i,m in enumerate(c)if n>>extra[m]&1)
cs=[pack(lambda n:not h&~ns(n))for h in S];dom={p:pt[p]&cs[pa[p]]for p in pts}
meet=[union(dom[p]for p in bm(t))for t in stars];H=meet[j]
F={p:~pt[p]&line(inc[p])&cs[pa[p]]for p in pts};FX={p:H&F[p]&line(inc[p]&U)for p in pts}
# Without localization proof, grant arbitrary original raw subsets B to the surviving helper.
pool=Z if all(F[s]&dom[p]for s in Z for p in pts if p!=s)else pts
assert all(H&dom[p]&meet[u]for p in pts for u in range(7)if u!=j)
assert all(FX.values())
for size in range(len(pool)+1):
 for B in combinations(pool,size):
  if any(FX[s]&dom[p]or FX[p]&dom[s]for s,p in combinations(B,2)):continue
  pr=[(p,sum(1<<h for h in S if not pa[p]&~h))for p in B];gr=[B or (-1,)]
  up=[sum(1<<u for u in range(7)if U>>u&1 and not any(FX[p]&cs[h]&on[u]for p in B))for h in S]
  possible_top={h for h in S if h and not any(FX[p]&cs[h]for p in B)}
  nodes=0
  def go(L,A,lo,hi):
   global nodes
   nodes+=1
   if nodes>limit:return 'CAP'
   if not actual(c,pr,[[m]for m in lo],(),gr,0,[[m]for m in hi],ordinary=(j,),special_high=union(cs[h] for h in L),allowcost=A):return False
   use=sorted(set(pa.values()),key=lambda t:(-sum(v==t for v in pa.values()),t.bit_count(),t))
   split=next((h for h in use if h in A-L),None)
   if split is not None:
    new={h for h in S if split&~h==0}
    return go(L,A-{h for h in S if h&~split==0},lo,hi) or (new<=A and all(hi[h]==U for h in new) and go(L|new,A,[U if h in new else x for h,x in enumerate(lo)],hi))
   q=next(((h,1<<u)for h in use for u in range(7)if (lo[h]^hi[h])>>u&1),None)
   if q is None:return 'RELAXED'
   t,b=q
   return go(L,A,lo,[x&~b if h&~t==0 else x for h,x in enumerate(hi)]) or go(L,A,[x|b if t&~h==0 else x for h,x in enumerate(lo)],hi)
  print(key,B,go(set(),possible_top,[0]*16,up),nodes,flush=True)
