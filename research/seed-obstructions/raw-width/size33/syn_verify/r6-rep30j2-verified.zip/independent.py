from qonly import *
from itertools import combinations_with_replacement
from mask6struct import screen as subset_screen
bank=(2,129,4160)
j=2
def check(z):
    M=sum(p for p in pts if p&stars[j] and inc[p]&~(1<<j))
    masks=[t for t in range(M+1) if not t&~M]
    opts=[-1]+[u for u in range(7)if u!=j]+list(range(7,7+z.bit_count()))
    for degree in combinations_with_replacement(opts,5-z.bit_count()):
        k=degree.count(-1)
        assert k<=2
        unknowns=[()] if not k else [((v,1),)for v in masks] if k==1 else [((v,2),)for v in masks]+[tuple((v,1)for v in x)for x in combinations_with_replacement(masks,2)]
        for a in unknowns:
            if screen(bank,j,z,degree,a,M):continue
            if not any(subset_screen(bank,j,z,degree,a,m) for m in masks if m.bit_count()>=2):return False
    return True
for row in Path('qrun1.log').read_text().splitlines():
    z=int(row.split()[3])
    assert check(z)
    print(z,'excluded',flush=True)
