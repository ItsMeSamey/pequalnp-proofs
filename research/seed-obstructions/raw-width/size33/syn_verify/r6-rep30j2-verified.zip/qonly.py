from marks import *
from functools import lru_cache
from itertools import product
from pathlib import Path
from inputs import P
nn=tuple(N)
def pack(f):return sum(1<<i for i,n in enumerate(nn) if f(n))
alln=(1<<len(nn))-1
on=[pack(lambda n:n>>(13+u)&1) for u in range(7)]
pt={p:pack(lambda n:n&p) for p in pts}
meet=[pack(lambda n:n&s) for s in stars]
inc={p:sum(1<<u for u,s in enumerate(stars) if p&s) for p in pts}
def union(It):
 a=0
 for v in It:a|=v
 return a
@lru_cache(None)
def line(m):return union(on[u] for u in range(7) if m>>u&1)
@lru_cache(None)
def infeasible(gs,j): # j only determines count of residual surplus chips
 b=3 if j>=0 else 4
 labels=union(gs);need=[(sum(1<<i for i,g in enumerate(gs) if g>>u&1)) for u in range(7) if labels>>u&1]
 for d in range(b+1):
  for rows in combinations(range(len(gs)),d):
   drop=sum(1<<i for i in rows)
   if sum(max(0,(s&~drop).bit_count()-2) for s in need)<=b-d:return False
 return True
def screen(bank,j,z,degree,unknowns,subset=8191):
 comps=[m for m in bank if m!=2];missing=0 if 2 in bank else 2
 phys=tuple(p for p in pts if p!=missing)
 # Positive ordinary inputs whose raw p, and no other feature, is the
 # sole distinguished coordinate against some original j-active negative.
 strict=set()
 if j>=0:
  for p in phys:
   ng=on[j]&~pt[p]
   for m in comps:
    if m&p:ng&=union(pt[q] for q in pts if q&m)
   if ng:strict.add(p)
 R=127^(1<<j) if j>=0 else 127
 M=[p for p in phys if j>=0 and p&stars[j] and p in strict and inc[p]&R and p&subset]
 while M:
  live=union(pt[p] for p in M)
  M2=[]
  for p in M:
   f=live&~pt[p]&line(inc[p]&R)
   for m in comps:
    if m&p:f&=union(pt[q] for q in pts if m&q)
   if f:M2.append(p)
  if M==M2:break
  M=M2
 if j>=0 and len(M)<2:return None
 MM=sum(M);qz=[q for q in pts if q&z];allowed=[]
 for q in qz:
  f=~pt[q]&line(inc[q])
  for m in comps:
   if q&m:f&=union(pt[x] for x in pts if m&x)
  allowed.append(sum(p for p in M if not f&pt[p]))
 unknown=degree.count(-1)
 extra={q:degree.count(7+i) for i,q in enumerate(qz)}
 labelx={u:degree.count(u) for u in range(7)}
 cases=[]
 for num in range(len(qz)+1):
  for lost in combinations(range(len(qz)),num):
   cover=union(allowed[i] for i in lost)
   if any(not allowed[i] for i in lost):continue
   vanish=0
   selectable=[v&MM for v,cap in unknowns if v&MM]
   for a in range(len(selectable)+1):
    if a+num<1:continue
    for tails in combinations(selectable,a):
     if cover|union(tails)!=MM:continue
     key=(sum(1<<i for i in lost),5-num-a-vanish,unknown-a-vanish)
     if not any(x&~key[0]==0 and r>=key[1] and g>=key[2] for x,r,g in cases):cases.append(key)
 livecases=set(cases)
 if not livecases:return ("no surviving boundary",MM)
 for flags in product((1,0),repeat=len(comps)):
  high=[m for m,b in zip(comps,flags) if b];low=union(m for m,b in zip(comps,flags) if not b)
  base=alln
  for m in high:base&=union(pt[p] for p in pts if p&m)
  rawus=127^(1<<j) if j>=0 else 127
  for n in (rawus.bit_count(),rawus.bit_count()-1):
   for ul in combinations([u for u in range(7) if rawus>>u&1],n):
    U=sum(1<<u for u in ul);basep=[p for p in phys if not low&p and inc[p]&U]
    ns=base&(union(pt[p] for p in M) if j>=0 else alln)
    if any(not(ns&on[u]) for u in ul):continue
    avail=[p for p in basep if inc[p]&U!=U and all(ns&pt[p]&on[u] for u in ul if not inc[p]>>u&1) and all(ns&pt[p]&meet[u] for u in range(7) if u!=j)]
    fail={p:sum(1<<u for u in ul if not ns&on[u]&line(inc[p]&U)) for p in avail}
    bad=[(p,q) for p,q in combinations(avail,2) if inc[p]&U==inc[q]&U or not ns&line(inc[p]&U)&line(inc[q]&U)]
    for V in [U]+[U^(1<<u) for u in ul]+[U^(1<<u)^(1<<v) for u,v in combinations(ul,2)]:
     if any(not ns&on[u]&meet[v] for u in ul if V>>u&1 for v in range(7) if v!=j and v!=u):continue
     def walk(K):
      for p,q in bad:
       if p in K and q in K:return walk(K-{p}) or walk(K-{q})
      gs=tuple(sorted(inc[p]&V for p in K if inc[p]&V))
      if len(gs)<=4:return None
      kb={p:inc[p]&V for p in K if inc[p]&V}
      ff=[]
      for p in pts:
       if not z&p:continue
       f=ns&~pt[p]&line(inc[p])
       for m in comps:
        if p&m:f&=union(pt[q] for q in pts if q&m)
       mask=sum(1<<u for u in ul if V>>u&1 and not f&on[u])
       options=sum(q for q in kb if not f&pt[q])
       ff.append((mask,options))
      @lru_cache(None)
      def priced(vals,free):
       if not free:return all(sum(bool(v>>u&1) for v in vals)<=2+labelx[u] for u in ul)
       w=free[0]
       if not w or not vals:return priced(vals,free[1:])
       return any(priced(vals[:i]+(v&~w,)+vals[i+1:],free[1:]) for i,v in enumerate(vals))
      @lru_cache(None)
      def group(vals,left,free):
       if priced(vals,free):return True
       if left:
        for i,v in enumerate(vals):
         for k,w in enumerate(vals[:i]):
          if group(tuple(sorted(vals[:k]+vals[k+1:i]+vals[i+1:]+(v|w,))),left-1,free):return True
       return False
      def anonymous(g,gen,free):
       poss=[q for q in g if z&q and (not q&MM or any(not q&m for m in high) or any(q&s for s,_ in unknowns))]
       for n in range(min(gen,len(poss))+1):
        for ds in combinations(poss,n):
         if group(tuple(sorted(v for q,v in g.items() if q not in ds)),gen-n,free):return True
       return False
      def num(g,i,gen,lost,free):
       if i==len(qz):return anonymous(g,gen,free)
       copies=1+extra[qz[i]]-((lost>>i)&1)
       if not copies:return num(g,i+1,gen,lost,free)
       mask,options=ff[i];p=qz[i]
       if p in K:mask=0
       if num(g,i+1,gen,lost,free+(mask,)*copies):return True
       return any(num({v:w for v,w in g.items() if v!=q},i+1,gen,lost,free) for q in g if q&z and q&options)
      for case in tuple(livecases):
       lost,total,gen=case
       if not num(kb,0,gen,lost,()):livecases.remove(case)
      if not livecases:return tuple(sorted(K))
     K=walk({p for p in avail if not fail[p]&V})
     if K:return flags,ul,V,K
if __name__=='__main__':
 import sys
 bank=tuple(map(int,sys.argv[1:]))
 for j in (-1,*range(7)):print(bank,j,screen(bank,j),flush=True)
