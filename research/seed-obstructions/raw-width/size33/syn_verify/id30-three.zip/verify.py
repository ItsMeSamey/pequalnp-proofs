from pathlib import Path
from itertools import product
import ast
from twocut import upper
from sweep import run
import contextlib, io
cases=[(pr,g) for pr,g in ast.literal_eval(Path('grow-30.txt').read_text()) if len(pr)==3]
expected={((p,f),(256,15),(512,15)) for p,f in product((1,64),(8,10,12,14,15))}
assert {pr for pr,_ in cases}==expected and len(cases)==10
assert all(g==[(1,(0,0,0,0))] for _,g in cases)
for pr,_ in cases:
    assert [p for p,f in pr if upper((129,4160),3,p)]==[pr[0][0]]
    buff=io.StringIO()
    with contextlib.redirect_stdout(buff):run(pr)
    assert buff.getvalue()==f"ZERO {pr} [2, 0, 0]\n",buff.getvalue()
    print(buff.getvalue(),end='')
