from envelope import actual
import ast
from pathlib import Path
from functools import reduce
from operator import and_,or_
from itertools import product
work=Path(__file__).resolve().parent
def le(x,y):return all(not a&~b for a,b in zip(x,y))
def run(pr):
    groups=[(p,)for p,f in pr]+[(-1,)]
    assert [p for p,f in pr][1:]==[256,512]
    dom=ast.literal_eval((work/('domains-30-'+'-'.join('%dx%d'%p for p in pr)+'.txt')).read_text())
    counts=[0,0,0]
    def narrow(ds):
        ds=list(map(tuple,ds))
        for i,j in ((0,1),(0,2),(1,3),(2,3))*2:
            ds[i]=tuple(x for x in ds[i]if any(le(x,y)for y in ds[j]))
            ds[j]=tuple(y for y in ds[j]if any(le(x,y)for x in ds[i]))
        return ds
    def walk(ds,arc):
        ds=narrow(ds)
        if not all(ds):return False
        lo=[];hi=[]
        for d in ds:
            a,b=zip(*d);lo.append((reduce(and_,a),0,0,reduce(and_,b)));hi.append((reduce(or_,a),0,0,reduce(or_,b)))
        edges=((),((0,3),),((3,0),))[arc]
        counts[0]+=1
        if not actual((129,4160),pr,lo,edges,groups,0,hi):return False
        possible=[(min(k,len(d)-k),s,i,b) for s,d in enumerate(ds) for i in (0,1)for b in range(7) if (k:=sum(x[i]>>b&1 for x in d)) not in (0,len(d))]
        if not possible:
            print('FIT',pr,arc,ds,flush=True);return True
        _,s,i,b=max(possible)
        for v in (0,1):
            child=ds[:];child[s]=[x for x in ds[s]if (x[i]>>b&1)==v]
            if walk(child,arc):return True
        return False
    for arc,g in enumerate(dom):
        if len(g)!=4:continue
        t,a,b,l=g
        if walk([l,a,b,t],arc):break
    else:print('ZERO',pr,counts,flush=True);return
if __name__=='__main__':
 for pr,opts in ast.literal_eval((work/'grow-30.txt').read_text()):
    if len(pr)==3:run(pr)
