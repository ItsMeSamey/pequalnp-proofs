from primary import *
from itertools import combinations
@lru_cache(None)
def survives(dem,b):
 if b<0:return False
 if b==0:return not dem
 D=sum(z.bit_count()-2 for z in dem)
 if D<=b:return True
 U=0
 for m in dem:U|=m
 roles=[1<<j for j in range(8)if U>>j&1]
 assert all(m.bit_count()==3 for m in dem)
 target=(1<<len(dem))-1
 by_cost=[{0}]
 for cost in range(1,b+1):
  choices={1<<j for j in range(len(dem))} if cost==1 else set()
  for C in combinations(roles,min(cost+1,len(roles))):
   rc=sum(C)
   choices.add(sum(1<<j for j,m in enumerate(dem) if (m&rc).bit_count()>=2))
  combined=set(choices)
  for fee in range(1,cost):
   combined.update(a|z for a in by_cost[fee]for z in by_cost[cost-fee])
  if target in combined:return True
  by_cost.append({a for a in combined if not any(a!=z and not a&~z for z in combined)})
 return False
def states(O,k):
 ds={};rs={}
 for p in ps:
  ext=0
  for (u,q),ll in perp.items():
   if u not in O and q==p:
    for n,m in ll:
     if all(n&stars[j] for j in O):ext|=m
  rs[p]=[(j,private[j,p])for j in O]+[(7,ext)]
  ds[p]=threshold([m for j,m in rs[p]],2)
 solo={p:ds[p]&~__import__('functools').reduce(int.__or__,(ds[q]&possible[q,p]for q in ps if q!=p),0)for p in ps}
 for i in range(len(bank)):
  w=1<<i;b=k-7+len(O)-sum(bool(m&w)for m in ds.values())
  masks=[sum(1<<j for j,m in rs[p]if m&w)for p in ps if solo[p]&w]
  yield tuple(sorted(m for m in masks if m.bit_count()>2)),b
def run(k):
 for r in range(6):
  n=passed=0;cs=Counter()
  for O in combinations(range(7),7-r):
   for d,b in states(O,k):
    n+=1
    if survives(d,b):passed+=1;cs[b]+=1
  print(r,n,passed,sorted(cs.items()),flush=True)
if __name__=='__main__':run(34-int(os.environ['LOW_WIDTH']))
