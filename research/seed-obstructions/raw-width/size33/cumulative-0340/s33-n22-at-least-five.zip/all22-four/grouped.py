from group_roles import *
from itertools import groupby
from collections import Counter,defaultdict
import sys
def run(O):
 k=34-int(os.environ['LOW_WIDTH']);groups=defaultdict(list)
 for i in range(len(bank)):
  R,E,M=info(O,i);sl=k-7+len(O)-len(M)
  if sl<0:continue
  groups[(tuple(M),tuple(p for p in M if any(q!=p and possible[q,p]&(1<<i)for q in M)),sl)].append(i)
 stat=Counter()
 for (M,flex,sl),ii in groups.items():
  results=[test(O,ii,a,300) for a in range(sl+1)]
  stat[tuple('U'if s is None else 'Y'if s else 'N'for s in results)]+=len(ii)
 print(O,len(groups),sorted(stat.items()),flush=True)
if __name__=='__main__':
 for arg in sys.argv[1:]:run(tuple(map(int,arg)))
