from spec import *
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
from itertools import combinations,permutations
def run(O,idx,an,limit=3000,retain=True):
 R,E,M=info(O,idx);i0=1<<idx;sz=34-int(os.environ['LOW_WIDTH']);cash=sz-(7-len(O)+len(M)+an)
 if cash<0:return False
 M=tuple(M);nodes=tuple((*M,*[-1-j for j in range(an)]));vs=IDPool();v=vs.id
 with Solver(name='cadical195')as solver:
  add=solver.add_clause
  def OR(*l):
   t=v(('or',*l))
   add([-t,*l])
   for x in l:add([-x,t])
   return t
  def AND(*l):return -OR(*[-x for x in l])
  def cap(xs,k):
   if len(xs)>k:solver.append_formula(CardEnc.atmost(xs,k,vpool=vs).clauses)
  def edge(x,y):return v(('edge',x,y))
  def prec(x,y):return v(('before',x,y))if x<y else -v(('before',y,x))
  def hi(x,q):return v(('hi',x,q))
  def sink(x,t):return v(('sink',x,t))
  for x,y in permutations(nodes,2):add([-edge(x,y),prec(x,y)])
  for x,y,z in permutations(nodes,3):add([-prec(x,y),-prec(y,z),prec(x,z)])
  for j in range(an-1):add([prec(-j-1,-j-2)])
  for x in M:
   add([hi(x,x)])
   for q in qs:
    if q!=x and q in ps and not possible[x,q]&i0:add([-hi(x,q)])
  S=tuple(O)+('ext',);extra=v('mandatory_extra')
  over=[extra]
  if cash==0:add([-extra])
  witness=[]
  for x in nodes:
   pay=[v(('over',x,j))for j in range(cash)];over+=pay
   outs=[sink(x,t) for t in S]+[edge(x,y)for y in nodes if y!=x]
   pr=[(sink(x,'ext'),v(('live',x,'ext')))]
   add([pr[0][1]])
   for y in nodes:
    if x!=y:pr.append((edge(x,y),v(('alive',y))))
   ac=[]
   for y,(ed,alive) in enumerate(pr):
    dup=v(('dup',x,y));add([-dup,ed]);outs.append(dup)
    ac.extend((AND(ed,alive),AND(dup,alive)))
   add([-v(('alive',x)),OR(*ac)])
   cap(outs+[-s for s in pay],2+cash)
   witness.extend(AND(a,b)for a,b in combinations(ac,2))
  cap(over,cash)
  if retain:add([extra,*witness])
  def route(p,n,t,ispriv):
   avail=[x for x in nodes if x==p or x<0 or (not n&x and (not ispriv or possible[x,p]&i0))]
   states={x:v(('walk',p,n,t,x))for x in avail};add([states[p]])
   for x in avail:
    a=states[x]
    if ispriv:add([-a,hi(x,p)])
    for q in qs:
     if n&q:add([-a,-hi(x,q)])
    if x==p:continue
    add([-a,*[AND(states[y],edge(y,x))for y in avail if y!=x]])
   add([AND(a,sink(x,t))for x,a in states.items()])
  for p in M:
   for t in R[p]:
    for q,r in combinations([q for q in qs if not q&stars[t]],2):
     if mark(p,q|r)&i0:route(p,q|r,t,True)
   for n in E[p]:route(p,n&8191,'ext',False)
  solver.conf_budget(limit)
  return solver.solve_limited()
if __name__=='__main__':
 import sys,re,ast
 for l in open('grouped22.log'):
  if 'True'not in l:continue
  O,idx=re.match(r'4 (\(.+?\)) 1 (\d+)',l).groups();O=ast.literal_eval(O);idx=int(idx)
  R,E,M=info(O,idx);sl=12-4-len(M)
  print(O,idx,[run(O,idx,a)for a in range(sl+1)],flush=True)
