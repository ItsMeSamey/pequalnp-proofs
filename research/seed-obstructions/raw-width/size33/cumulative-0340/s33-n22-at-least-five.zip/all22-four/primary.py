from census import *
def threshold(bs,k):
 if k<=0:return full
 a=[full]+[0]*k
 for b in bs:
  for j in range(k,0,-1):a[j]|=a[j-1]&b
 return a[-1]
def classify(O,k):
 r=7-len(O);D={};busy={};ex={}
 for p in ps:
  ex[p]=0
  for (u,q),ll in perp.items():
   if u not in O and q==p:
    for n,m in ll:
     if all(n&stars[j] for j in O):ex[p]|=m
  demand=[private[j,p] for j in O]+[ex[p]]
  D[p]=threshold(demand,2);busy[p]=threshold(demand,3)
 for p in ps:
  busy[p]&=~__import__('functools').reduce(int.__or__,(D[q]&possible[q,p]for q in ps if q!=p),0)
 d=k-r
 neg=threshold(D.values(),d+1);sat=threshold(D.values(),d)&~neg
 b=threshold(busy.values(),1)&sat
 return neg,b
if __name__=='__main__':
 k=34-int(os.environ['LOW_WIDTH'])
 print(len(bank),k)
 for o in range(2,8):
  c=Counter()
  for O in combinations(range(7),o):
   neg,b=classify(O,k);c.update({'cash':neg.bit_count(),'busy':b.bit_count(),'remaining':(full&~(neg|b)).bit_count()})
  print('r=',7-o,c)
