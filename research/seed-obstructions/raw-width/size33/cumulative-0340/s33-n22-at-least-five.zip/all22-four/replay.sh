#!/bin/sh
set -eu
cd "$(dirname "$0")"
export LOW_WIDTH=22
python exact_savings.py | cmp - exact22.log
python grouped.py 0123456 | tee ordinary.tmp
head -n1 grouped7.log | cmp - ordinary.tmp
python grouped22.py 1 2 3 4 | cmp - grouped22.log
python full_roles.py | cmp - full4.log
python check_lanes.py
