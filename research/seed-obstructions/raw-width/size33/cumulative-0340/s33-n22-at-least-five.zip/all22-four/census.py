import os
from collections import Counter
from itertools import combinations
from pathlib import Path
from functools import lru_cache
from input import raw_samples, point_obligations
src=Path(__file__).with_name('L-meta-18968.json')
P,N,_=raw_samples(src);raw,obligations=point_obligations(src)
fixed={1<<p for p in range(13) if p!=1};optional=sorted(set(raw)-fixed)
def blockers(p,n):
 return sum(1<<j for j,m in enumerate(optional) if m!=p and m&p and not m&n)
def banks():
 # The only point outside the twelve compulsory singletons is index one.
 req={sum(1<<j for j,m in enumerate(optional) if m&p and not m&n)
      for p,n in obligations if p==2}
 req={m for m in req if not any(x!=m and x&m==x for x in req)}
 assert sorted(tuple(optional[j] for j in range(19) if m>>j&1) for m in req)==[(2,3),(2,6),(2,258)]
 return [m for inds in combinations(range(19),int(os.environ["LOW_WIDTH"])-19) if all((m:=sum(1<<j for j in inds))&x for x in req)]
bank=banks();sizes=[sum(1<<i for i,v in enumerate(bank) if v.bit_count()==size) for size in range(6)];full=(1<<len(bank))-1
stars=[sum(r&8191 for r in P if r>>13==1<<t) for t in range(7)]
ps=sorted(fixed|{2})
physical_two=sum(1<<i for i,b in enumerate(bank)if b&(1<<optional.index(2)))
@lru_cache(None)
def enabled(b):
 return int.from_bytes(bytes(sum((not v&b)<<k for k,v in enumerate(bank[i:i+8])) for i in range(0,len(bank),8)),'little')
def mark(p,n):return (enabled(blockers(p,n)) & (physical_two if p==2 else full)) if all(m==p or not m&p or m&n for m in fixed) else 0
private={}
for t,s in enumerate(stars):
 for p in ps:
  v=0
  if s&p:
   for a,b in combinations([1<<j for j in range(13) if not s>>j&1],2):v |= mark(p,a|b)
  private[t,p]=v
perp={(u,p):[(n,mark(p,n)) for n in N if n>>(13+u)&1 and not n&p] for u,s in enumerate(stars) for p in ps if s&p}
possible={(q,p):full for q in ps for p in ps if q!=p}
for q,p in possible:
 for (u,r),rows in perp.items():
  if q==r:
   for n,m in rows:
    if n&p:possible[q,p] &= ~m
def run():
 for o in range(1,8):
  for O in combinations(range(7),o):
   hist=[full]+[0]*len(ps)
   Ds={};overs={}
   for p in ps:
    one=two=three=0
    for t in O:
     k=private[t,p];three|=two&k;two|=one&k;one|=k
    ext=0
    for (u,q),rows in perp.items():
     if u not in O and p==q:
      for n,b in rows:
       if all(n&stars[t] for t in O):ext|=b
    overs[p]=three|(two&ext)
    two |= one&ext
    Ds[p]=two
    for j in reversed(range(1,len(hist))):hist[j]=(hist[j]&~two)|(hist[j-1]&two)
    hist[0]&=~two
   bad=0
   for p in ps:
    alone=overs[p]
    for q in ps:
     if q!=p:alone &= ~(Ds[q]&possible[q,p])
    bad |= alone
   hist[o+4] &= ~bad
   bins=[(o+4-j,tuple((v&k).bit_count() for k in sizes)) for j,v in enumerate(hist) if v and j<=o+4]
   if bins:print(tuple(O),bins)
if __name__=='__main__':
 print('exact banks by price', [s.bit_count() for s in sizes]);run()
