from route5 import *
from ast import literal_eval
from collections import Counter
import re
hit=[]
for row in open('grouped22.log'):
 r,o,n,i,raw=re.fullmatch(r'(\d+) (\(.+?\)) (\d+) (\d+) (.+)\n',row).groups()
 if any(z!='False' for a,z in literal_eval(raw)):
  assert (r,n)==('4','1')
  O=literal_eval(o);i=int(i);assert check(i,O)==0;hit.append((O,i))
seen=[]
for row in open('full4.log'):
 o,i,res=re.fullmatch(r'(\(.+?\)) (\d+) (.+)\n',row).groups()
 assert all(v is False for v in literal_eval(res));seen.append((literal_eval(o),int(i)))
assert hit==seen and len(hit)==11
