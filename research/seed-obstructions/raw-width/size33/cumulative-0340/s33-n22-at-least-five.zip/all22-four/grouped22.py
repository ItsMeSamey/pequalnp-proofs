from exact_savings import *
from group_roles import test
from spec import info
def run(r):
 for O in combinations(range(7),7-r):
  groups={}
  for i,(d,b)in enumerate(states(O,12)):
   if not survives(d,b):continue
   _,_,M=info(O,i)
   flex=tuple(p for p in M if any(q!=p and possible[q,p]&(1<<i)for q in M))
   groups.setdefault((tuple(M),flex,b),[]).append(i)
  for (M,flex,b),ii in groups.items():
   out=[test(O,ii,a,500)for a in range(b+1)]
   print(r,O,len(ii),ii[0],[(a,'unknown'if v is None else str(v))for a,v in enumerate(out)],flush=True)
  info.cache_clear()
if __name__=='__main__':
 import sys
 for r in sys.argv[1:]:run(int(r))
