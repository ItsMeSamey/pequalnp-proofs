from spec import *
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
from itertools import product
def test(O,inds,a,limit=1200):
 inds=tuple(inds)
 bits=sum(1<<i for i in inds)
 R0,E0,M=info(O,inds[0])
 assert all(info(O,i)[2]==M for i in inds)
 R={p:set.intersection(*(set(info(O,i)[0][p]) for i in inds)) for p in M}
 E={p:set.intersection(*(set(info(O,i)[1][p]) for i in inds)) for p in M}
 sl=34-int(os.environ["LOW_WIDTH"])-(7-len(O)+len(M))
 if a>sl:return False
 vs=IDPool();v=vs.id
 with Solver(name='cadical195') as s:
  add=s.add_clause
  def AND(*l):
   t=v(('and',*l));add([t,*[-x for x in l]])
   for x in l:add([-t,x])
   return t
  def OR(*l):return -AND(*[-x for x in l])
  def cap(xs,k):
   if len(xs)>k:s.append_formula(CardEnc.atmost(xs,k,vpool=vs).clauses)
  guard=tuple(O);scores=[]; X=range(a)
  for node,go in [*( (p,R[p]) for p in M),*((-j-1,guard) for j in X)]:
   cand=[v(('d',node,t)) for t in go]+[v(('a',node,j)) for j in X if node>=0 or j>-node-1]+[v(('ex',node))]
   pay=[v(('pay',node,i)) for i in range(sl-a)]
   cap(cand+[-c for c in pay],2+len(pay))
   scores.extend(pay)
  cap(scores,sl-a)
  reach={};far={}
  for j in reversed(range(a)):
   far[j]=OR(v(('ex',-j-1)),*[AND(v(('a',-j-1,k)),far[k]) for k in X if k>j])
  for p in M:
   if any(q!=p and possible[q,p]&bits for q in M):continue
   for j in X:
    reach[p,j]=OR(v(('a',p,j)),*[AND(reach[p,k],v(('a',-k-1,j))) for k in range(j)])
   if E[p]:
    for n in E[p]:
     route=[]
     for j in X:
      entry=OR(v(('a',p,j)),*[AND(route[k],v(('a',-k-1,j))) for k in range(j)])
      route.append(AND(entry,*[-v(('hi',j,q)) for q in qs if n&q]))
     add([v(('ex',p)),*[AND(route[j],v(('ex',-j-1))) for j in X]])
   for t in R[p]:
    ex=[q for q in qs if not stars[t]&q]
    for q,r in combinations(ex,2):
     if mark(p,q|r)&bits!=bits:continue
     add([v(('d',p,t)),*[AND(reach[p,j], v(('d',-j-1,t)),v(('hi',j,p)), -v(('hi',j,q)), -v(('hi',j,r))) for j in X]])
  s.conf_budget(limit)
  return s.solve_limited()
