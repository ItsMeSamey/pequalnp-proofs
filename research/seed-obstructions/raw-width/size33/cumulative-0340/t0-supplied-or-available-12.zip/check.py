from pathlib import Path
import hashlib,itertools,json,re,zipfile
from collections import Counter
archive=Path(__file__).with_name('t0-pivot-clean.zip')
if not archive.exists():
    archive=Path('/workspace/scratch/synthesis_new/t0-pivot-clean.zip')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='74076570ddf32e2cd7d734b996322b2ca1700e7d99bb1a85fbd2676e4f409d37'
with zipfile.ZipFile(archive) as z:
    official=json.loads(z.read('L-meta-18968.json'))['formal_statement']
    originals=[json.loads(l) for l in z.read('remaining.jsonl').splitlines()]
    targets=set(map(int,z.read('t0-remaining-26.ids').split()))
seeds=[int(''.join(v.zfill(19) for v in re.findall(r'\((\d+) : ℕ\)',block))) for block in re.findall(r'\[([^]]+)\]',official)]
fields={int(i):int(v) for i,v in re.findall(r'x1 \((\d+) : ℕ\) = \((\d+) : ℕ\)',official)}
def rot(i,s,off,k):
    return sum(((s>>(i-i%13+(i-j-off)%13))&1)<<j for j in range(k))
rows=[(rot(i,seeds[0],0,13),rot(i,seeds[1],6,7), 1 if (fields[88]&~fields[54])>>i&1 else (-1 if not fields[88]>>i&1 else 0)) for i in range(676)]
pos=[(p,t) for p,t,s in rows if s==1]
neg=[(p,t) for p,t,s in rows if s==-1]
def bm(j):return 1<<j
stars={p:sum(t for pt,t in pos if pt==p) for p in map(bm,range(13))}
rare={p:u for p,u in stars.items() if u.bit_count()==1}
ordinary=8191-sum(rare)
def lookup(source,perm): return sum(v for b,v in perm.items() if source&b)
def chart(q):
    u=rare[q]
    return {(p,t) for p,t in pos if p&ordinary and t!=u}, {(p&ordinary,t&~u) for p,t in neg if p&q}
baseP,baseN=chart(2)
def maps(q):
    P,N=chart(q)
    tags=set(map(bm,range(7)))-{rare[q]}
    for tg in itertools.permutations(sorted(set(map(bm,range(7)))-{rare[2]})):
        f=dict(zip(sorted(tags),tg))
        h={st&~rare[2]:p for p,st in stars.items() if p&ordinary}
        g={p:h.get(lookup(st&~rare[q],f),0) for p,st in stars.items() if p&ordinary}
        if len(set(g.values()))!=9 or not all(g.values()):continue
        if {(lookup(p,g),lookup(t,f)) for p,t in N}==baseN and {(lookup(p,g),lookup(t,f)) for p,t in P}==baseP:yield g,f
allmaps={q:list(maps(q)) for q in rare}
assert all(len(v)==6 for v in allmaps.values())
known={(129,), (320,), (129,320),(129,2052),(129,513),(320,513),()}
print('original q protected-tags other-pairs possible-singleton-transports')
four=[]
data=[]
for i,t,E,R,C in originals:
    if t or i not in targets:continue
    cuts={}
    for q,u in rare.items():
        hot=[c for c in C if c&q]
        if len(hot)!=1 or any(not c&(q|ordinary) for c in C):continue
        c=hot[0]
        rest={s&ordinary for s in C if s!=c and (s&ordinary).bit_count()>1}
        valid=[(g,f)for g,f in allmaps[q] if tuple(sorted(lookup(a,g) for a in rest)) in known]
        if not valid:continue
        assert {(p,t)for p,t in pos if p&q}=={(q,u)}
        assert all(not t&u for p,t in neg if p&q)
        assert all(any(p&s and p&c and t&u and not p&q for p,t in neg) for s in C if s!=c)
        cuts[q]=(rest,valid)
    for q,(rest,valid) in cuts.items():
        forced=sum(u for p,u in rare.items() if p!=q and p in cuts)
        opts=sorted({(tuple(sorted(lookup(a,g) for a in rest)),lookup(forced,f)) for g,f in valid})
        data.append((i,q,forced,rest,opts))
    if len(cuts)==4:
        rest,_=cuts[2]
        assert rest in ({129},{4160})
        four.append(i)
assert four==[120,143,771,931]
for i,q,tag,rest,opts in data:print(i,q,tag,','.join(map(str,sorted(rest))),repr(opts))
