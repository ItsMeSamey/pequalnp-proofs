from contextlib import redirect_stdout
import io
with redirect_stdout(io.StringIO()):
    import check as a
nativeA=[3<<j for j in range(6)]
nativeB=[(1<<(j+3))|(1<<((j+9)%13)) for j in range(6)]
native=set(nativeA+nativeB+[s|t for s,t in zip(nativeA,nativeB)])
signed={}
for i,t,E,R,selected in a.originals:
    if t or i not in a.targets:continue
    for C in selected:
        S=C&a.ordinary
        anchors=[q for q in a.rare if q&C]
        if S not in native or S.bit_count()!=2 or len(anchors)!=2:continue
        if any(not any(xx[0]==i and xx[1]==q for xx in a.data) for q in anchors):continue
        assert C==S|sum(anchors)
        assert all((p&S)==(p&C) or p in anchors for p,t in a.pos)
        def flags(p,t):
            return p|(t<<13)|sum((1<<(20+k)) for k,c in enumerate(selected) if c&p)
        for q,j in (anchors,anchors[::-1]):
            u=a.rare[q]
            assert [c for c in selected if c&q]==[C]
            assert all(not(p&C) for p,v in a.pos if v==u and p!=q)
            assert all(not(t&u) for p,t in a.neg if p&q)
            P,N=a.chart(q)
            assert all(any(p&v for p,t in N) for v in a.stars if v&a.ordinary)
            assert all(any(t&(1<<k) for p,t in N) for k in range(7) if 1<<k!=u)
            assert all(any(p&c for p,t in N) for c in selected if c!=C)
            for p,t in a.pos:
                if t!=u:continue
                eligible=[pn for pn,tn in a.neg if flags(p,t)&~flags(pn,tn)==u<<13]
                assert eligible and (p==q or any(pn&j for pn in eligible))
            piv=[k for k in a.data if k[0]==i and k[1]==q]
            print(i,C,S,q,j,u,piv[0][4])
        signed[i]=(C,S)
        break
print('complete', sorted(signed),len(signed))
