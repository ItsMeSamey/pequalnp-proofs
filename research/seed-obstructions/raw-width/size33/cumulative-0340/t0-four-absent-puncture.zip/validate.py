from search import *
P,N=data(())
A,T,_=chart(2)
for line in (s.parent/'one-terminal-frontier/remaining.jsonl').read_text().splitlines():
 i,t,e,r,C=json.loads(line);p={4075:4,4112:64,4113:64,4163:2048}[i]
 bank=r|(127<<13)|sum(1<<extra[c]for c in C)
 O=sum(pts)^p
 U=1<<18
 H=sum(1<<extra[c] for c in (3,6,258))
 alias,= [c for c in C if c not in (3,6,258) and c&O]
 assert (alias&O).bit_count()==1
 def native(a,l):return a&O|l|H|((1<<extra[alias]) if a&(alias&O) else 0)
 pos=[native(a,l) for a,l in A if a!=p]; neg=[native(a,l) for a,l in T]
 assert all(any(not (v&bank)&~x for v in P) for x in pos)
 assert all(any(not x&~v for v in N) for x in neg)
 assert all(any(x&w for x in neg)for w in bm(O|((127<<13)^U)))
 pq=next(v&bank for v in P if v&2)
 assert any(not (pq^U)&~v and not v&U for v in N)
 print(i,p,alias,alias&O,len(pos),len(neg))
