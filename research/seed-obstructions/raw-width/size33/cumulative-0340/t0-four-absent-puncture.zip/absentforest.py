from search import *
from collections import defaultdict,Counter
def forests(i,r,C,p):
 P,N=data(());U=1<<(13+5); B=r|(127<<13)|sum(1<<extra[c]for c in C);q=2
 high=sum(1<<extra[c] for c in (3,6,258))
 low=(r&sum(DEGREE_ONE))|p|U|sum(1<<extra[c]for c in C if not c&(sum(pts)^p) and not c&2)
 S=high|low
 assert S.bit_count()==9
 pq=next(a&B for a in P if a&2); assert pq==high|U
 distinguished=bm(pq); qi=next(j for j,a in enumerate(P)if a&2)
 Pext=tuple(P)+tuple(pq^x for x in distinguished)+(high,)
 ps={v:sum(1<<j for j,x in enumerate(Pext) if x&v)for v in bm(B)}
 ns={v:sum(1<<j for j,x in enumerate(N) if x&v)for v in bm(B)}
 real=(1<<len(P))-1
 @cache
 def dom(x):
  if not x:return (1<<len(N))-1
  v=x&-x;return dom(x^v)&ns[v]
 @cache
 def rules(k):
  positive=negative=0
  for j,a in enumerate(P):
   m=dom(a&B&~k)
   if m:positive|=1<<j;negative|=m
  return positive,negative
 groups={};out=defaultdict(set)
 for n in range(1,S.bit_count()+1):
  for vals in combinations(bm(S),n):
   k=sum(vals)
   if n==1:groups[k]={(ps[k],ns[k])}
   else:
    G=set();req,forbid=rules(k)
    a=(k-1)&k
    while a:
     b=k^a
     if a<b:
      for ap,an in groups[a]:
       for bp,bn in groups[b]:
        for isor in (True,False):
         if any(v in DEGREE_ONE and (not isor or w>>next(j for j,x in enumerate(P)if x&v)&1)for v,w in ((a,bp),(b,ap))):continue
         pp,nn=(ap|bp,an|bn)if isor else (ap&bp,an&bn)
         if pp&req!=req or nn&forbid:continue
         if not pp&real or pp&real==1<<qi:continue
         if any(not (pp&real)&~hp and not hn&~nn for hp,hn in [(ap,an),(bp,bn)]+[(ps[w],ns[w])for w in ps]):continue
         G.add((pp,nn))
     a=(a-1)&k
    groups[k]=G
   for pp,nn in groups[k]:
    if k&pq:
     if not pp>>qi&1 or any(pp>>(len(P)+j)&1 for j,v in enumerate(distinguished)if v&k):continue
    out[k].add((pp,nn))
 def rec(unused,pieces):
  if not unused:yield pieces;return
  x=unused&-unused
  for k in out:
   if k&x and not k&~unused:
    for pp,nn in out[k]:
     flag=pp>>(len(P)+4)&1
     if k in DEGREE_ONE and flag:continue
     yield from rec(unused^k,pieces+[(k,pp,flag)])
 h=Counter();bad=[]
 for ff in rec(S,[]):
  cat=(sum((k&pq).bit_count()>1 for k,v,t in ff),sum(bool(k&high)and not t for k,v,t in ff),sum(not bool(k&pq) and bool(v>>qi&1)!=bool(t) for k,v,t in ff))
  h[cat]+=1
  if cat!=(0,0,0):continue
  splits=[(k,v)for k,v,t in ff if k&high]
  # earliest split's ordinary point r must be shielded by a later split's zero.
  # Every possible linear order: loss suffices if SOME split can be exchanged and a later one screens it.
  from itertools import permutations
  def impossible_order(order):
   for j,(k,_)in enumerate(order[:-1]):
    c=next(c for c in (3,6,258)if k&(1<<extra[c])); rr=c^2
    if any(not any(x&rr and v>>t&1 for t,x in enumerate(P))for _,v in order[j+1:]):return True
   return False
  if any(not impossible_order(order)for order in permutations(splits)):bad.append(ff)
 print(i,'forests',sum(h.values()),h,'bad order',len(bad),flush=True)
 if bad:print('example',bad[0],flush=True)
 assert sum(h.values())==1 and set(h)=={(0,0,0)} and not bad
if __name__=='__main__':
 d={4075:4,4112:64,4113:64,4163:2048}
 for l in (s.parent/'one-terminal-frontier/remaining.jsonl').read_text().splitlines():
  i,t,e,r,C=json.loads(l)
  if i in set(map(int,sys.argv[1:])):forests(i,r,C,d[i])
