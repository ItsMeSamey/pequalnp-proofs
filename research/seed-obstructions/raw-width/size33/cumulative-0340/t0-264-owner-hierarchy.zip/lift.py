import ast,collections,gzip,hashlib,itertools,json,re,sys
from pathlib import Path
from zipfile import ZipFile
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/scratch')
local=Path(__file__).resolve().parent
def digest(d):return hashlib.sha256(d).hexdigest()
manifest=[tuple(l.split())for l in (local/'packets.txt').read_text().splitlines()]
for role,p in manifest:
 path=root/p
 print(role,digest(path.read_bytes()),p)
p0=root/'syn_mitm/s29-three-top-complete.zip'
with ZipFile(p0)as z:
 def read(n):return z.read(n).decode()
 def idset(n):return set(map(int,read(n).split()))
 W=json.loads(read('L-meta-18968.json'))
 raw=z.read('terminal-raw-keys.jsonl.gz')
 assert digest(raw)=='7fb9105d5048dc80f8f1ee4f7b7382495308f6228e3b0b00afb65d9eb4819600'
 rawrows=list(map(json.loads,gzip.decompress(raw).splitlines()))
 top=idset('closed-r7.ids');first=idset('whole.ids');last=idset('cross-new.ids')
 assert len(rawrows)==17072 and len(first)==152 and len(last)==112 and first.isdisjoint(last)and first|last==top
 floor=json.loads(read('rows.json'));low={}
 for f in ('t0wide-0.log','t0wide-100.log'):
  for l in read(f).splitlines():
   idx,r,O,c,b,_,res,_=re.fullmatch(r'(\d+) (\d+) (\d+) (\([^)]*\)) (-?\d+) (True|False) (\[[^]]*\]) (\d+)',l).groups()
   rr=ast.literal_eval(res);assert len(rr)==max(0,int(b)+1) and all(x is False for x in rr)
   low[int(r),int(O),ast.literal_eval(c)]=[f,int(idx)]
 assert len(low)==136
 roles={}
 base=['r6/ten.log']+sorted(n for n in z.namelist()if n.startswith('r6/q-')and n.endswith('.log'))
 extra=['r6/common-0.log']+sorted(n for n in z.namelist()if n.startswith('r6/cm-')and n.endswith('.log'))+['r6/crosscash0.log']+sorted(n for n in z.namelist()if n.startswith(('r6/xc-','r6/ac-'))and n.endswith('.log'))
 for f in base+extra:
  ex=f in extra
  pat=r'(\d+) (\d+) (\([^)]*\)) (.*?) (\[[^]]*\]) (\d+)'if ex else r'(\d+) (\([^)]*\)) (\d+) (.*?) (\[[^]]*\]) (\d+)'
  for lineno,l in enumerate(read(f).splitlines(),1):
   g=list(re.fullmatch(pat,l).groups())
   if not ex:g[1],g[2]=g[2],g[1]
   _,u,c,w,ids,a=g
   if int(a):continue
   for i in ast.literal_eval(ids):roles.setdefault((i,int(u)),[f,lineno,ast.literal_eval(c),ast.literal_eval(w)])
 records=[]; fullkeys=ast.literal_eval(read('allkeys.txt'))
 comb=tuple(itertools.combinations((129,354,523,1046,2092,4160),3))
 for c,w,ids in fullkeys:
  fid,possible=floor[str((29,c,w))]
  assert set(ids)=={i for i in fid if i<4169}
  refs=[low[7-O.bit_count(),O,c] for O,k in possible if O.bit_count()>=2]
  for i in ids:
   if i not in top:continue
   data=rawrows[i];t,e,r,orig,_,aliases,b,old=data
   assert t==0 and not e and r==8191 and b==29 and not old and 0 not in aliases
   cnt=collections.Counter(1<<i for i in range(13)if 8133>>i&1);cnt.update(aliases)
   assert tuple(x for x in comb[0]+(1046,2092,4160)if x in cnt)==c
   assert tuple(sorted((a,n)for a,n in cnt.items()if n>1))==w
   rr=[roles[i,u]for u in range(7)]
   assert all(x[2:]==[c,w]for x in rr)
   assert json.loads(read(f'top{comb.index(c)}.json'))['C']==list(c)
   records.append(dict(id=i,source_row=data,compound_masks=c,physical_weights=w,lower_admitted_floor_queries=refs,six_zero_receipt_by_ordinary=[q[:2]for q in rr],seven_high_row_receipt=f'top{comb.index(c)}.json',six_stage='initial152'if i in first else 'additional112'))
 assert len(records)==264
 (local/'originals.jsonl').write_text(''.join(json.dumps(x,separators=(',',':'))+'\n'for x in sorted(records,key=lambda x:x['id'])))
 (local/'originals.ids').write_text(''.join(str(i)+'\n'for i in sorted(top)))
 print('Original ID join: 424 raw noninert triple keys, 264 zero/one endpoint; all 264 have seven signed six-owner zero receipts and a high-pin table.')
