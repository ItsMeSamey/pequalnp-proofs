from deleted import Native
from itertools import permutations,combinations
from pathlib import Path
from private import Native as Parent
from functools import reduce
s0=Parent()
def aut():
 ret=[]
 for f in permutations(s0.effective):
  perm=dict(zip(s0.effective,f))
  tr=lambda m:sum(1<<perm[u]for u in s0.effective if m>>u&1)
  lookup={v:p for p,v in s0.inc.items()}
  if not all(tr(v)in lookup for v in s0.inc.values()):continue
  pt={p:lookup[tr(v)]for p,v in s0.inc.items()}
  if {(sum(pt[q]for q in pt if q&p),tr(l))for p,l in s0.ns}!=set(s0.ns):continue
  ret.append(pt)
 return ret
if __name__=='__main__':
 A=aut();print('orbits',sorted({tuple(sorted({f[p] for f in A}))for p in s0.pts}))
 for p in s0.pts:
  s=Native(p);us=s.effective;pts=s.pts
  assert set(s.N)=={n&~p for n in s0.N}
  assert set(s.P)=={n for n in s0.P if not n&p}
  assert all(any(n&a and n&b for n in s.N for a in s.stars[u]for b in s.stars[v])for u,v in combinations(us,2))
  assert all(any(n&q and any(n&r for r in s.stars[u])for n in s.N) for q in pts for u in us)
  assert all(s.F[q]&s.tag[u] for q in pts for u in us)
  assert all(s.no[a,b] for a,b in permutations(pts,2))
  assert all(s.on[s.inc[a]]&s.on[s.inc[b]]for a,b in combinations(pts,2))
  assert all(s.domq[q]&s.tag[u] for q in pts for u in us if not s.inc[q]>>u&1)
  assert all(s.tag[u]&s.meet[v]for u,v in permutations(us,2))
  match=next(seq for seq in permutations(pts,6)if all(a in s.stars[u]for a,u in zip(seq,us)))
  n=len(s.P)
  assert s.k==n-8
  print(p,'positives',n,'negatives',len(s.N),'zero-pin upper',n+5,'test cap',n+4,'adapter',s.k,'matching',match)
