from signed import *
from cps import gain
for p in (1,128,256):
 s=Native(p);rows=tuple(s.inc.values());deficits=tuple(max(0,sum(v>>u&1 for v in rows)-2)for u in range(7));B=s.k-7
 gains=[gain(deficits,rows,95,r+1)for r in range(1,B+1)]
 print(p,'deficit',sum(deficits),'budget',B,'gains',gains,flush=True)
 assert all(any(n&q and n>>(13+t)&1 and (n>>13)&s.inc[r] for n in s.N)for q,r in permutations(s.pts,2)for t in s.effective if not s.inc[q]>>t&1)
