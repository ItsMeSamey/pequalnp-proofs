from pathlib import Path
import sys
from functools import cache
from itertools import combinations
from sample import samples
from minors import DEGREE_ONE
from resources import run
from core import Source,union
class Native(Source):
 def __init__(self,pin):
  raw,seed,tgt=samples(Path('L-meta-18968.json'))
  self.pts=self.phys=tuple(1<<i for i in range(13)if 1<<i not in DEGREE_ONE and (1<<i)!=pin)
  self.P=tuple({(n&sum(self.pts))|(n&((127^32)<<13)) for i,n in enumerate(raw) if tgt>>i&1 and not seed>>i&1 and n&sum(self.pts) and not n>>18&1})
  self.N=tuple({(n&sum(self.pts))|(n&(127<<13))for i,n in enumerate(raw)if not tgt>>i&1 and n&2})
  assert len(self.P) in (18,19);self.k=len(self.P)-8
  self.stars=tuple({n&8191 for n in self.P if n>>(13+u)&1}for u in range(7))
  self.inc={p:sum(1<<u for u,S in enumerate(self.stars)if p in S)for p in self.pts}
  self.ns=tuple((n&8191,(n>>13)&127)for n in self.N);self.pp={p:p for p in self.pts}
  self.full=(1<<len(self.N))-1
  def rows(f):return sum(1<<i for i,n in enumerate(self.N)if f(n))
  self.dom=cache(lambda p:rows(lambda n:n&p==p)); self.domq={p:self.dom(p) for p in self.pts}
  self.tag=[rows(lambda n:n>>(13+u)&1)for u in range(7)]
  self.meet=[union(self.domq[p] for p in S) for S in self.stars];self.meet[5]=self.full
  self.on=[union(v for u,v in enumerate(self.tag) if m>>u&1)for m in range(128)]
  self.F={p:~self.domq[p]&self.on[self.inc[p]] for p in self.pts}
  self.effective=tuple(u for u in range(7)if u!=5)
  self.reject=cache(lambda u,x:all(v==u or self.dom(x)&self.tag[u]&self.meet[v]for v in self.effective))
  self.pr={p:sum(1<<u for u in self.effective if p in self.stars[u] and self.reject(u,0)) for p in self.pts}
  self.no={(p,q):bool(self.F[p]&self.domq[q])for p in self.pts for q in self.pts if p!=q}
  self.no_t={(p,q):sum(1<<u for u in self.effective if p in self.stars[u] and self.reject(u,q)) for p,q in self.no}
  self.Ehits=[self.full for i in range(128)]
  for m in range(128):
   for u in self.effective:
    if m>>u&1:self.Ehits[m]&=self.meet[u]
