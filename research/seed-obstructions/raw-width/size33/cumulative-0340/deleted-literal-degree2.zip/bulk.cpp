#include <cstdlib>
#include <algorithm>
#include <cstdio>
#include <vector>
using namespace std;
int star[]={708,1408,2816,5632,3137,6272,4357};
int ordinary; int Q,Z,n,g,sp,ar[6],rec[6],cap[6],bo[7],hd[7],aff[7];
long long ng,nassign,lives;
struct Opt{int h,cl,eff;}; vector<Opt> opts[7];
int pc(int x){return __builtin_popcount((unsigned)x);}
void assign(int u,int active,int clean){
 if(lives)return;
 if(u==7){
  if(active!=(1<<n)-1)return;
  nassign++;
  for(int i=0;i<7;i++)if(aff[i]>=0 && (star[i]&Z) && !(aff[i]&~clean))return;
  if(lives++==0){printf("first z%d n%d E%d,%d,%d R%d,%d,%d H",Z,n,ar[0],ar[1],ar[2],rec[0],rec[1],rec[2]);for(int i=0;i<7;i++)printf(" %d",hd[i]);puts("");fflush(stdout);}
  return;
 }
 for(auto o:opts[u]){hd[u]=o.h;aff[u]=o.eff;assign(u+1,active|o.h,clean|o.cl);}
}
void test(){
 if(lives)return;
 int full=(1<<n)-1,loose=0;
 for(int i=0;i<n;i++)if(pc(rec[i])+pc(ar[i])<cap[i])loose|=1<<i;
 for(int u=0;u<7;u++){
  opts[u].clear();int req=star[u]&Q;
  for(int h=0;h<=full;h++){
   int parents=0,covered=0;
   for(int i=0;i<n;i++)if(h>>i&1){parents|=ar[i];covered|=rec[i];}
   int seeds=h&~parents,dr=req&~covered,cost=pc(seeds)+pc(dr);
   if(cost+(!h && req && (star[u]&Z))>((ordinary>>u&1)?1:2)+bo[u])continue;
   int reach=seeds;
   for(int i=0;i<n;i++)if(reach>>i&1)reach|=ar[i];
   int affected=dr;
   for(int i=0;i<n;i++)if(reach>>i&1)affected|=rec[i];
   bool tight=cost==((ordinary>>u&1)?1:2)+bo[u];
   opts[u].push_back({h,(tight&&!(loose&h))?req:0,(tight&&!(loose&reach))?affected:-1});
  }
  if(opts[u].empty())return;
 }
 ng++;assign(0,0,0);
}
int seedsCost[64], capacityLeft[7][64], partial[7][64], occ[6][6];
void receiver(int i){
 if(lives)return;
 int full=1<<n;
 for(int u=0;u<7;u++)if(star[u]){
   int req=star[u]&Q, lim=((ordinary>>u&1)?1:2)+bo[u]; bool ok=false;
   for(int h=0;h<full&&!ok;h++) {
    int free=lim-seedsCost[h];
    if(free>=0 && pc(req&~partial[i][h])<=free+capacityLeft[i][h])ok=true;
   }
   if(!ok)return;
 }
 if(i==n){test();return;}
 for(int r=Q;;r=(r-1)&Q){
  bool ok=pc(r)+pc(ar[i])<=cap[i];
  for(int j=0;j<i&&ok;j++)if(occ[j][i]&&rec[j]>r)ok=false;
  if(ok){
   rec[i]=r;
   for(int h=0;h<full;h++)partial[i+1][h]=partial[i][h] | ((h>>i&1)?r:0);
   receiver(i+1);
  }
  if(!r||lives)break;
 }
}
void prep(){
 for(int i=0;i<n;i++)if(pc(ar[i])>cap[i])return;
 for(int h=0;h<(1<<n);h++){
  int par=0;capacityLeft[n][h]=0;
  for(int i=n-1;i>=0;i--){
   bool chosen=h>>i&1; if(chosen)par|=ar[i];
   capacityLeft[i][h]=capacityLeft[i+1][h]+(chosen?cap[i]-pc(ar[i]):0);
  }
  seedsCost[h]=pc(h&~par);
 }
 for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
  bool same=cap[i]==cap[j]&&ar[i]==ar[j];
  for(int a=0;a<n;a++)if(((ar[a]>>i)^(ar[a]>>j))&1)same=false;
  occ[i][j]=same;
 }
 receiver(0);
}
void owners(int left,int u){
 if(lives)return;
 if(left && u==7)return;
 if(u==7){prep();return;}
 for(bo[u]=0;bo[u]<=((ordinary>>u&1)?0:left);bo[u]++)owners(left-bo[u],u+1);
}
int main(int argc,char** argv){int removed=std::atoi(argv[2]); for(int &t:star)t&=~removed; star[5]=0;ordinary=std::atoi(argv[1]);
 int k[6];
 while(scanf("%d%d%d%d",&ordinary,&Z,&g,&sp)==4){
  for(int i=0;i<g;i++)scanf("%d",k+i);
  Q=8133^removed^Z;ng=nassign=lives=0;
  for(int subset=0;!lives && subset<1<<g;subset++){
   n=0;fill(cap,cap+6,0);
   for(int i=0;i<g;i++)if(subset>>i&1)cap[n++]=k[i];
   sort(cap,cap+n);
   do{
    for(int m=0;!lives && m<(1<<(n*(n-1)/2));m++){
     int y=0;fill(ar,ar+6,0);fill(rec,rec+6,0);
     for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)if(m>>(y++)&1)ar[i]|=1<<j;
     owners(sp,0);
    }
   }while(next_permutation(cap,cap+n));
  }
  printf("done %d %d %d %d %lld %lld %lld\n",ordinary,Z,g,sp,ng,nassign,lives);fflush(stdout);
 }
}
