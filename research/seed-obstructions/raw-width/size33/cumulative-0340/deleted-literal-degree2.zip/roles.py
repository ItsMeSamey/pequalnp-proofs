from deleted import *
from core import pass_budget
p=int(sys.argv[1]);s=Native(p)
for r in map(int,sys.argv[2:]):
 for O in combinations(s.effective,6-r):
  o=sum(1<<u for u in O);d,M,solo,b=s.roles(o,s.k)
  assert b==s.k-1-r-len(M)
  if not pass_budget(solo,b):continue
  for g in range(b+1):
   out=run(s,O,s.k,g,900)
   print(p,r,o,g,repr(out),flush=True)
