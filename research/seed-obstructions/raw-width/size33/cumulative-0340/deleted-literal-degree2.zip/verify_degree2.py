from pathlib import Path
from collections import Counter
from signed import Native
import subprocess,sys
def call(*args):subprocess.run([sys.executable,*args],check=True)
call('signed.py')
call('zero.py')
call('checkedledger.py')
for p in (1,128):
 s=Native(p)
 accepted=lambda n:any(n&q and (n>>13)&s.inc[q] for q in s.pts)
 assert all(accepted(n) for n in s.P) and not any(accepted(n) for n in s.N)
 assert {d for a in s.P for n in s.N if (d:=a&~n).bit_count()==1}==set(s.pts)|{1<<(13+u) for u in s.effective}
 expected=Counter()
 for f in Path('.').glob(f'{p}-*.in'):
  o=int(f.stem.split('-')[1])
  for l in f.read_text().splitlines():expected[(o,*map(int,l.split()))]+=1
 actual=Counter()
 for f in Path('.').glob(f'bulk-{p}-*'):
  if f.suffix:continue
  lines=f.read_text().splitlines()
  done=[l.split() for l in Path(str(f)+'.log').read_text().splitlines() if l.startswith('done ')]
  assert len(done)==len(lines) and Path(str(f)+'.rc').read_text().strip()=='0'
  for l,d in zip(lines,done):
   a=tuple(map(int,l.split()));assert a[:4]==tuple(map(int,d[1:5]))
   actual[a]+=1
 assert actual==expected
 for r in range(7):
  live={tuple(map(int,l.split()[:3]))for l in Path(f'verifiedlive-{p}-{r}.txt').read_text().splitlines()}
  if r==6 and p==1:
   assert all(o==z==0 for o,z,g in live)
   continue
  for o,z,g in live:
   f=Path(f'ex-{p}-{r}-{o}.log');assert Path(str(f)+'.rc').read_text().strip()=='0'
   ls=f.read_text().splitlines();assert not any('OPEN' in l for l in ls)
   assert any(l==f'no private {o} {z} {g}' or l.startswith(f'done {o} {z} {g} ') and l.endswith(' []') for l in ls)
 print('degree-two checked',p,sum(actual.values()))
