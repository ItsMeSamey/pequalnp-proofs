from deleted import Native,combinations,cache,union
from core import pass_budget
from cps import parts,gain
from itertools import combinations_with_replacement
from pathlib import Path
import sys
p=int(sys.argv[1]);s=Native(p);k=s.k-1
for r in range(7):
 for O in combinations(s.effective,6-r):
  o=sum(1<<u for u in O);dm,M,solo,b=s.roles(o,s.k)
  if not pass_budget(solo,b):continue
  @cache
  def fits(rows,ds,sp):
   req=tuple(max(0,sum(t>>u&1 for t in rows)-(1 if u in O else 2)) if u in s.effective else 0 for u in range(7))
   delta=sum(req)-sp
   return delta<=0 or any(sum(gain(req,rows,95,1+sum(1+ds[j]for j in part))for part in partn)>=delta for partn in parts(len(ds)))
  with Path(f'{p}-{o}.in').open('w')as f:
   for a in range(len(M),min(len(s.pts),k-r)+1):
    for plus in combinations(set(s.pts)-set(M),a-len(M)):
     Z=set(M)|set(plus); rows=tuple(s.inc[q]for q in s.pts if q not in Z)
     for n in range(k-r-a+1):
      for ds in combinations_with_replacement(range(k-r-a-n+1),n):
       sp=k-r-a-n-sum(ds)
       if sp>=0 and fits(rows,ds,sp):print(sum(Z),n,sp,*[2+d for d in ds],file=f)
