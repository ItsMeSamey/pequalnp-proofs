from deleted import Native
from pathlib import Path
from collections import defaultdict
from ast import literal_eval
src={}
for f in Path('.').glob('roles*.log'):
 p,r=map(int,f.stem[5:].split('-'))
 for line in f.read_text().splitlines():
  try:_,_,o,g,ans=line.split(' ',4);a=literal_eval(ans);src[p,int(o),int(g)]= a not in (False,(False,[]))
  except Exception:continue
for p in (1,128):
 s=Native(p)
 print('removed',p)
 for r in range(7):
  alive=[];n=done=0;unknown=[]
  for f in Path('.').glob(f'bulk-{p}-{r}-*'):
   if f.suffix:continue
   tests=[tuple(map(int,l.split()))for l in f.read_text().splitlines()]
   of=Path(str(f)+'.log')
   receipts=[list(map(int,l.split()[1:]))for l in (of.read_text().splitlines()if of.exists()else[]) if l.startswith('done')]
   for idx,row in enumerate(tests):
    o,z,g,sp,*ds=row;n+=1
    if idx<len(receipts):
     a=receipts[idx];assert a[:4]==[o,z,g,sp]
     if a[-1]==0:done+=1;continue
    if r<6 and all(not src.get((p,o,an),True)for an in range(g+z.bit_count()-len(s.roles(o,s.k)[1])+1)):done+=1;continue
    if idx>=len(receipts):unknown.append(row)
    alive.append(row)
  print(r,n,done,'open',len(alive),'unchecked',len(unknown),'ordinary',sorted({a[0]for a in alive}))
  Path(f'verifiedlive-{p}-{r}.txt').write_text(''.join(' '.join(map(str,row))+'\n'for row in sorted(alive)))
