from deleted import *
import sys
p,r,o=map(int,sys.argv[1:4])
import types
from functools import cache
s=Native(p)
mod=types.ModuleType('geometry')
mod.N=s.N;mod.P=s.P;mod.pts=s.phys
mod.pack=lambda f:sum(1<<i for i,n in enumerate(s.N)if f(n))
mod.alln=s.full;mod.stars=tuple(sum(S)for S in s.stars);mod.inc=s.inc;mod.on=s.tag;mod.pt=s.domq;mod.meet=s.meet
mod.union=union;mod.line=lambda m:s.on[m];mod.cache=cache;mod.combinations=combinations
sys.modules['geometry']=mod
import extkw,flex
flex.Source=lambda unused:s
s.bank=lambda c:None
s.roles_original=s.roles
def role(om,k):
 d,m,solo,b=s.roles_original(om,k)
 assert all(q&s.z for q in m)
 return d,tuple(q for q in s.pts if q&s.z),solo,b
s.roles=role
# fl.signed tests one optional anonymous helper (a grant) plus the exact named and owner overage.
seen={}
def exterior(o,named,a,sp):
 if a>1:return 'two-anon'
 k=(o,named,a,sp)
 if k not in seen:
  flex.calls=0
  try:seen[k]=flex.signed((),o|32,named,(),(),sp,a)
  except TimeoutError:seen[k]='cutoff'
 return seen[k]

import holderbranch as hb
hb.Source=lambda _:s

from itertools import chain
@cache
def envelope(o,named,an,sp):
 if an>=2:return "uncovered two-anonymous"
 if not an:return exterior(o,named,0,sp)
 hb.nc=flex.calls=0
 try:return hb.chk((),o|32,named,(),(),True,(),sp)
 except TimeoutError:return 'cutoff'
for o in [o]:
 O=tuple(u for u in s.effective if o>>u&1)
 done=set()
 for l in Path(f'live-{p}-{r}.txt').read_text().splitlines():
  oo,z,g,*_=map(int,l.split())
  if oo!=o:continue
  if (z,g)in done:continue
  done.add((z,g));s.z=z
  out=run(s,O,s.k,g,1500)
  if out is False:print('no private',o,z,g,flush=True);continue
  status,profiles=out
  if status is not False:print('OPEN price',o,z,g,status,flush=True)
  required=set()
  for m,sp in profiles:
   named=tuple(sorted(x for x in m if x>0))
   for k in range(len(named)+1):
    for subset in combinations(named,k):
     for an in range(1+sum(x<0 for x in m)):
      for b in range(sp+1):required.add((subset,an,b))
  live=[]
  for named,an,sp in sorted(required):
   res=envelope(o,named,an,sp)
   if res:live.append((named,an,sp,res))
  print('done',o,z,g,len(required),live,flush=True)
