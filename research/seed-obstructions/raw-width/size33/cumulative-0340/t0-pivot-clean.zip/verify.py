from pathlib import Path
from itertools import combinations
from collections import Counter
import json
exec(Path('high-head-isomorphisms.py').read_text().split('for q in DEGREE_ONE:')[0])
ordinary=sum(pts);D=sum(DEGREE_ONE)
P2,N2=sample(2);h=neigh(P2);transport={}
for q in DEGREE_ONE:
 P,N=sample(q);hq=neigh(P);maps=[]
 for f in permutations(range(6)):
  m=[transform(x,f)for x in hq]
  if set(m)!=set(h):continue
  d=[h.index(x)for x in m]
  if {(transform(p,d),transform(l,f))for p,l in N}==N2:maps.append(d)
 assert len(maps)==6
 transport[q]=maps
A=[3<<j for j in range(6)];B=[(1<<(j+3))|(1<<((j+9)%13))for j in range(6)]
extra=dict(zip(A+B+[a|b for a,b in zip(A,B)],range(20,38)))
ids=set(map(int,Path('t0-remaining-26.ids').read_text().split()))
for i,t,E,R,C in map(json.loads,Path('remaining.jsonl').read_text().splitlines()):
 if t or i not in ids:continue
 hits=[]
 for q,u in DEGREE_ONE.items():
  tag=1<<(13+u); touched=[c for c in C if c&q]
  if R!=8191 or len(touched)!=1 or any(not(c&(ordinary|q)) for c in C):continue
  high=q|sum(1<<extra[c] for c in touched);low=(D^q)|tag
  bank=R|(127<<13)|sum(1<<extra[c] for c in C)
  active={a&ordinary for a in C if a not in touched and (a&ordinary).bit_count()>1}
  orb=min(tuple(sorted(transform(sum(1<<j for j,v in enumerate(pts)if v&a),d)for a in active))for d in transport[q])
  if orb not in ((),(9,),(20,),(9,20),(9,33),(9,130),(20,33)):continue
  P=set();N=set();own=0
  for j,w in enumerate(rows):
   pos=bool((target&~seed)>>j&1);neg=not(target>>j&1)
   if pos and w&q:
    assert w&bank==high|tag;own+=1
   x=(w&(ordinary|((127<<13)^tag)))|high|sum(1<<extra[a]for a in C if a not in touched and a&w&ordinary)
   if pos and w&ordinary and not w&tag:
    assert not(w&bank&~x);P.add(w&(ordinary|((127<<13)^tag)))
   if neg and w&q:
    assert not(x&bank&~w) and not high&~w
    N.add(w&(ordinary|((127<<13)^tag)))
  assert (own,len(P),len(N))==(1,21,90) and (high|low).bit_count()==6
  hits.append((q,u,orb))
 print(i,hits)
