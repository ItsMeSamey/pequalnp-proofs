from pairs import *
from orbit5 import reps,check
flags=Counter();special=set()
for O in combinations(range(7),2):
 for i in range(len(bank)):
  cat=classify(O,i);flags[cat]+=1
  if cat=='binary':
   assert set(O)<={1,2,3,5}
   special.add((i,O))
  elif cat=='zero':
   R,E,M=info(O,i);p=stars[O[0]]&stars[O[1]];w=1<<i
   assert p in M and len(R[p])==2 and E[p]
   q,=[q for q in M if q!=p and possible[q,p]&w]
   assert len(R[q])==1 and E[q] and not any(possible[v,q]&w for v in M if v!=q) and any(n&q for n in E[p])
  else:assert cat in ('busy','cash')
 info.cache_clear()
g=reps();assert set(x for group in g for x in group)==special and len(g)==1772
assert flags=={'busy':9806,'cash':2493,'zero':166,'binary':4986}
print('source stages',flags,'representatives',len(g),flush=True)
for j,s in enumerate(g):
 i,O=s[0];assert check(i,O)==0,(j,i,O)
print('five-owner survivors',0)
