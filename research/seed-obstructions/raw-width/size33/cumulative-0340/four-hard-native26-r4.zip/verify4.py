from pathlib import Path
import os,subprocess,sys
for b in ('129,2052','129,320','320,513'):
 env=dict(os.environ,BANK=b)
 got=subprocess.check_output([sys.executable,'nativeext.py','4'],text=True,env=env)
 assert got+'EXIT 0\n'==Path('r4-'+b+'.log').read_text()
 if b!='129,320':assert all(l.endswith('live []')for l in got.splitlines())
 else:assert [l for l in got.splitlines() if not l.endswith('live []')]==["6 1 3 live [((128,), 0, 0, 'cross')]"]
out=subprocess.check_output([sys.executable,'r4cross.py'],text=True,env=dict(os.environ,BANK='129,320'))
assert out+'EXIT 0\n'==Path('r4cross.log').read_text()
assert subprocess.check_output([sys.executable,'chart4.py'],text=True)==Path('chart4.log').read_text()
print('Four mandatory owners excluded on all three paired banks and all twelve native placements.')
