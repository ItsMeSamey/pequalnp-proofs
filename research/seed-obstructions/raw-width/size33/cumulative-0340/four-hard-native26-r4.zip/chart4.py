from pathlib import Path
s=Path('transport.py').read_text()
s=s.replace('mapped.append(tuple(mp(x)for x in (129,4160)))','mapped.append((tuple(mp(x)for x in (129,4160)),tuple(sorted(tf.items()))))')
s=s[:s.index('  for L in ((0,)')]+'''  bank=tf=None
  for k in (v for v in keys if len(v)==2):
   candidates=[f for ds,f in mapped if frozenset(k)==frozenset(ds)]
   if candidates:
    bank=k;tf=dict(min(candidates));break
  masks=sorted({int(l.split()[0])for l in Path('r4-'+','.join(map(str,bank))+'.log').read_text().splitlines()if 'live' in l})
  im=lambda x:sum(1<<t for t,j in tf.items()if x>>j&1)
  print(e,q,','.join(map(str,bank)),','.join(map(str,sorted(im(m)for m in masks))),im(6)if bank==(129,320) else 0)
'''
exec(s)
