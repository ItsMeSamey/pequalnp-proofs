from nativeext import *
o=6;O=tuple(t for t in range(7) if (o|32)>>t&1);named=(128,)
unknown=[p for p in s.pts if p not in named and any(not(s.no[q,p] or s.no_t[q,p]&o) for q in named)]
cof=[s.dom(sum(1<<(20+i)for i in range(len(MASKS))if j>>i&1))for j in range(1<<len(MASKS))]
def qp(p):return sum(1<<i for i,m in enumerate(MASKS) if p&m)
pr=[(q,sum(1<<j for j in range(len(cof))if j&qp(q)==qp(q)))for q in named]+[(p,0)for p in unknown]
hi=[[sum(1<<u for u in s.effective if not o>>u&1 and not s.F[q]&cof[j]&s.tag[u])for q in named]for j in range(len(cof))]
res=extkw.actual(MASKS,pr,[[0]*len(named)for _ in cof],(),[(q,)for q in named],0,hi,ordinary=O)
print(MASKS,o,named,unknown,res);assert not res
