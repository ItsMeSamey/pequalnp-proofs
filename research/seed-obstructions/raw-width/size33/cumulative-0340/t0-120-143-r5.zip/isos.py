from original import *
from itertools import permutations
a=Orig(120)
for i,j in [(8,18),(120,143)]:
 A=Orig(i);B=Orig(j);P,Aneg=A.P,A.N
 P0=[r&((1<<20)-1)for r in P];n0=[r&((1<<20)-1)for r in Aneg]
 lookup={y:q for q,y in A.inc.items()}
 for per in permutations(range(7)):
  tr=lambda m:sum(1<<per[u]for u in range(7)if m>>u&1)
  if not all(tr(x)in lookup for x in A.inc.values()):continue
  f={p:lookup[tr(x)]for p,x in A.inc.items()}
  move=lambda x:sum(v for p,v in f.items()if x&p)
  if sorted(map(move,banks[i]))!=sorted(banks[j]):continue
  ffull=lambda x:move(x&8191)|(tr(x>>13&127)<<13)|sum(1<<extra[move(m)]for m in banks[i]if x>>extra[m]&1)
  bx= (1<<20)-1|sum(1<<extra[m]for m in banks[j])
  if set(map(ffull,A.P))=={m&bx for m in B.P}and set(map(ffull,A.N))=={m&bx for m in B.N}:
   print(i,j,'tags',per,'point images',tuple(f.values()));break
 else:print(i,j,'NO')
