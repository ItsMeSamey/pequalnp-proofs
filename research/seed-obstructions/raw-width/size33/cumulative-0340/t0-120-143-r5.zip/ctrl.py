from original import *
from pathlib import Path
for i in (120,143):
 s=Orig(i);s0=Orig(i);bm=s0.inc
 assert len(s.P)==28 and len(s.pts)==13
 assert all(A&B for A,B in combinations(s.stars,2))
 assert all(any(s.dom(s.pp[a]|s.pp[b])for b in S)for a in s.pts for S in s.stars)
 assert all(s.F[p] for p in s.pts)
 assert all(s.F[p]&s.domq[q] or s.F[q]&s.domq[p]for p,q in combinations(s.pts,2))
 assert all(s.domq[q]&s.tag[u] for q in s.pts for u in s.effective if not s.inc[q]>>u&1)
 assert all(s.tag[u]&s.meet[v]for u in s.effective for v in s.effective if u!=v)
 assert all(any(n&8191&p and n>>13&s.inc[p] for p in s.pts)for n in s.P)
 assert not any(any(n&8191&p and n>>13&s.inc[p]for p in s.pts)for n in s.N)
 a=run(s,tuple(s.effective),15,0,3000)
 assert a[1],a
 print(i,'rank0 canonical feasible','signed positive',len(s.P),'negative',len(s.N),'individual marks',len(s.no))
ls=Path('original-120.log').read_text().splitlines()
from ast import literal_eval
G=0
for l in ls:
 _,r,o,z,b,result=l.split(' ',5);o,b=int(o),int(b)
 a=Path(f'x120-{o}.log').read_text().splitlines()
 assert a==[f'{o} {g} complete True open []'for g in range(b+1)]
 assert Path(f'x120-{o}.rc').read_text().strip()=='0'
 G+=len(a)
assert {int(l.split()[2])for l in ls}=={sum(1<<u for u in o)for o in combinations(range(7),2)}
print('rank5 pair count',len(ls),'source groups',G)
