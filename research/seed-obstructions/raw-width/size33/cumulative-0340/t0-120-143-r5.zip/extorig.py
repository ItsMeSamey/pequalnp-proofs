from original import *
from functools import cache
from core import union
from types import ModuleType
id=int(sys.argv[1]);o=int(sys.argv[2]);s=Orig(id);C=banks[id];O=tuple(u for u in range(7)if o>>u&1)
mod=ModuleType('geometry');mod.P=s.P;mod.N=s.N;mod.pts=s.phys;mod.alln=s.full;mod.stars=tuple(sum(S)for S in s.stars);mod.inc=s.inc
mod.pack=lambda f:sum(1<<i for i,n in enumerate(s.N)if f(n));mod.on=s.tag;mod.meet=s.meet;mod.pt=s.domq;mod.line=lambda mask:s.on[mask];mod.cache=cache;mod.combinations=combinations;mod.union=union
sys.modules['geometry']=mod
import holderbranch as hb, flex
flex.Source=hb.Source=lambda _:s
s.bank=lambda _:None
d,M,solo,b=s.roles(o,s.k)
@cache
def envelope(sub,an,sp):
 if an>=2:return 'twohelpers'
 hb.nc=flex.calls=0
 try:return hb.chk(C,o,sub,(),(),True,(),sp)if an else flex.signed(C,o,sub,(),(),sp,0)
 except TimeoutError:return 'cutoff'
for g in range(b+1):
 ans=run(s,O,s.k,g,3000)
 if ans is False:print(o,g,'NO-CASH');continue
 status,profiles=ans;openp=[]
 for names,k in profiles:
  ns=tuple(sorted(x for x in names if x>0))
  for n in range(len(ns)+1):
   for sub in combinations(ns,n):
    for an in range(1+sum(x<0 for x in names)):
     for sp in range(k+1):
      w=envelope(sub,an,sp)
      if w and (sub,an,sp)not in openp:openp.append((sub,an,sp))
 print(o,g,'complete',status is False,'open',openp,flush=True)
