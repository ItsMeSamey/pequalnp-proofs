from cuts import load,extra
from core import Source,pass_budget
from resources import run
from itertools import combinations
import sys
banks={8:(177,),18:(4184,),120:(177,523),143:(354,4184)}
class Orig(Source):
 def __init__(self,id):
  self.id=id;self.P,self.N=load(());self.pts=tuple(1<<j for j in range(13));self.effective=tuple(range(7))
  self.stars=tuple({n&8191 for n in self.P if n>>(13+u)&1}for u in self.effective)
  self.inc={p:sum(1<<u for u in self.effective if p in self.stars[u])for p in self.pts}
  self.bank(banks[id]);self.k=14-len(banks[id])
def probe(id,r):
 s=Orig(id)
 for O in combinations(range(7),7-r):
  o=sum(1<<u for u in O);d,M,solo,b=s.roles(o,s.k)
  if not pass_budget(solo,b):continue
  print(id,r,o,sum(M),b,end=' ',flush=True)
  a=[run(s,O,s.k,g,1500) for g in range(b+1)]
  print([(x[0],len(x[1]))if isinstance(x,tuple)else(x,0)for x in a],flush=True)
if __name__=='__main__':probe(*map(int,sys.argv[1:]))
