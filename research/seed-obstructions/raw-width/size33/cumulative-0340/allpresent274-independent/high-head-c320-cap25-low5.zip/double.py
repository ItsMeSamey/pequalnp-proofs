from nativeext import *
import compound_ext as ce
from itertools import product
cs=[s.full,s.dom(1<<20)]
def configs(o):
 mask=95^o
 fq={p:s.F[p]&s.on[s.inc[p]&mask]&s.Ehits[o] for p in s.pts}
 for a in range(1<<9):
  b=tuple(p for j,p in enumerate(s.pts) if a>>j&1)
  if any(fq[p]&s.domq[q]or fq[q]&s.domq[p] for p,q in combinations(b,2)):continue
  hi=tuple(sum(1<<u for u in s.effective if mask>>u&1 and not any(fq[p]&s.tag[u]&cs[h] for p in b))for h in (0,1))
  yield b,hi
def test(o,b,c,hh):
 O=tuple(i for i in range(7)if (o|32)>>i&1)
 groups=[b or (-1,),c or (-2,)]; pr=[(p,2 if p&320 else 3)for p in b+c]
 pre=tuple([0,0]for _ in range(2))
 def probe(lo,hi):
  global nodes
  nodes+=1
  if not ce.actual((320,),pr,lo,[(0,1),(1,0)],groups,0,hi,ordinary=O,allowcost=(1,)):return False
  if lo==hi:return (lo,hi)
  for h,j in product(range(2),repeat=2):
   if lo[h][j]!=hi[h][j]:break
  m=(hi[h][j]^lo[h][j])&-(hi[h][j]^lo[h][j])
  L=[v[:]for v in lo];H=[v[:]for v in hi]
  for hh in range(h,2):L[hh][j]|=m
  for hh in range(h+1):H[hh][j]&=~m
  return probe(lo,H) or probe(L,hi)
 return probe([[0,0],[0,0]],hh)
for o in map(int,sys.argv[1:]):
 bs=list(configs(o));count=0;nodes=0
 for i,(b,h)in enumerate(bs):
  for c,k in bs[i:]:
   if set(b)&set(c):continue
   count+=1
   ans=test(o,b,c,[[h[0],k[0]],[h[1],k[1]]])
   if ans:print('live',o,b,c,ans,flush=True)
 print('done',o,count,nodes,flush=True)
