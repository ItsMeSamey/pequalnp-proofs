from pathlib import Path
import subprocess as sp,sys
from full import *
s=Compound()
assert all(s.F.values()) and all(s.no[p,q] or s.no[q,p]for p,q in combinations(s.pts,2))
assert all(s.domq[p]&s.meet[u] for p in s.pts for u in s.effective)
assert all(s.stars[u]&s.stars[v] for u,v in combinations(s.effective,2))
for r in range(4):
 for O in combinations(s.effective,6-r):
  om=sum(1<<u for u in O)
  d,m,v,b=s.roles(om,11)
  assert not pass_budget(v,b)
def py(*args):return sp.check_output([sys.executable,*args])
for r in (4,5):
 got=py('nativeext.py',str(r)).decode()
 assert got==Path(f'ext{r}.log').read_text() and 'OPEN' not in got
assert py('double.py','2')==Path('double2.log').read_bytes()
assert py('double.py','4','8')==Path('double48.log').read_bytes()
assert all(l.startswith('done')for l in (Path('double2.log').read_text()+Path('double48.log').read_text()).splitlines())
print('C320 cap25 used input; owned ranks 0 through 5 all excluded')
