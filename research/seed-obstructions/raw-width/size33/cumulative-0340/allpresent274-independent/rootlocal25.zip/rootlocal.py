from itertools import combinations
from pathlib import Path
from sample import samples
from minors import DEGREE_ONE
from cps import gain
raw,seed,tgt=samples(Path(__file__).with_name('L-meta-18968.json'))
points=tuple(1<<i for i in range(13) if 1<<i not in DEGREE_ONE)
tags=(0,1,2,3,4,6)
P={(x&sum(points),x>>13&127) for i,x in enumerate(raw) if tgt>>i&1 and not seed>>i&1 and x&sum(points) and not x>>18&1}
N={(x&sum(points),x>>13&127) for i,x in enumerate(raw) if not tgt>>i&1 and x&2}
assert (len(P),len(N))==(21,90)
inc={p:sum(u for a,u in P if a==p) for p in points}
assert all(any(l>>u&l>>v&1 for a,l in N) for u in tags for v in tags)
assert all(any(a&p for a,l in N) for p in points)
assert all(any(a&p and l>>v&1 and l&inc[q] for a,l in N) for p in points for q in points if p!=q for v in tags if not inc[p]>>v&1)
assert len(set(inc.values()))==9 and min(u.bit_count() for u in inc.values())==2
req=tuple(max(0,sum(t>>i&1 for t in inc.values())-2) for i in range(7))
gs=[gain(req,tuple(inc.values()),sum(1<<j for j in tags),r+1) for r in range(1,6)]
assert (sum(req),gs)==(9,[1,3,5,7,9])
print('signed chart',len(P),len(N),'point stars',list(inc.values()),'tag deficits',req,'max gains',gs)
