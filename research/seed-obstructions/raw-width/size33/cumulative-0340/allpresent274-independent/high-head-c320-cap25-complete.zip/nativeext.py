from full import *
import types
from core import library
library[320]=20
s=Compound()
mod=types.ModuleType('geometry')
mod.N=s.N;mod.P=s.P;mod.pts=s.phys
mod.pack=lambda f:sum(1<<i for i,n in enumerate(s.N) if f(n))
mod.alln=s.full;mod.stars=tuple(sum(S) for S in s.stars);mod.inc=s.inc;mod.on=s.tag;mod.pt=s.domq;mod.meet=s.meet
mod.union=union;mod.line=lambda m:s.on[m];mod.cache=cache;mod.combinations=combinations
sys.modules['geometry']=mod
import extkw,flex,holderbranch as hb
flex.Source=hb.Source=lambda unused:s
s.bank=lambda c:None
@cache
def check(o,named,an,sp):
 if an>=2:return "two-anon"
 flex.calls=hb.nc=0
 try:
  if not an:return flex.signed((320,),o|32,named,(),(),sp,False)
  return hb.chk((320,),o|32,named,(),(),True,(),sp)
 except TimeoutError:return 'cutoff'
if __name__=='__main__':
 for r in map(int,sys.argv[1:]):
  for O in combinations(s.effective,6-r):
   o=sum(1<<u for u in O);d,m,solo,b=s.roles(o,11)
   if not pass_budget(solo,b):continue
   for g in range(b+1):
    out=run(s,O,11,g,1500)
    if out is False:continue
    price,profiles=out;req=set()
    if price is not False:print('OPEN',o,g,price,flush=True)
    for m,sp in profiles:
     named=tuple(sorted(x for x in m if x>0))
     for n in range(len(named)+1):
      for z in combinations(named,n):
       for a in range(1+sum(x<0 for x in m)):
        for sv in range(sp+1):req.add((z,a,sv))
    live=[(z,a,sv,res)for z,a,sv in sorted(req)if(res:=check(o,z,a,sv))]
    print(o,g,len(req),'live',live,flush=True)
