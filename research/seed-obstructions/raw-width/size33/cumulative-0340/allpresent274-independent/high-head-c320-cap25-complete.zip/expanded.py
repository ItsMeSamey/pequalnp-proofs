from pathlib import Path
import sys
from itertools import combinations

from sample import samples
from minors import DEGREE_ONE
from core import pass_budget
base=Path(__file__).resolve().parent
raw,seed,tgt=samples(base/'L-meta-18968.json')
pts=tuple(1<<i for i in range(13) if 1<<i not in DEGREE_ONE)
from functools import cache
from itertools import combinations_with_replacement

from cps import parts,gain
@cache
def suitable(rows,ds,sp):
 req=tuple(max(0,sum(bool(m>>u&1)for m in rows)-(1 if j>>u&1 else 2))if u in T else 0 for u in range(7))
 demand=sum(req)-sp
 if demand<=0:return True
 for parts_ in parts(len(ds)):
  if sum(gain(req,rows,U,1+sum(1+ds[t] for t in part))for part in parts_)>=demand:return True
 return False
for q,t in ((2,5),):
 T=[0,1,2,3,4,6]
 U=127^(1<<t)
 P=sorted({(x&sum(pts),x>>13&127) for i,x in enumerate(raw) if tgt>>i&1 and not seed>>i&1 and x&sum(pts) and not x>>(13+t)&1})
 N=sorted({(x&sum(pts),x>>13&127) for i,x in enumerate(raw) if not tgt>>i&1 and x&q})
 assert len(P)==21 and len(N)==90
 inc={p:sum(l for a,l in P if a==p)for p in pts}
 stars={1<<j:sum(p for p in pts if inc[p]>>j&1)for j in range(7)if j!=t}
 assert all(any(n&p for n,l in N) and any(l&inc[p] and not n&p for n,l in N) for p in pts)
 assert all(any(n&stars[u] and not l&u for n,l in N) for u in stars)
 assert all(a&b for a,b in combinations(stars.values(),2))
 absent=[(p,v)for p,v in combinations(pts,2)if not any(n&p and n&v for n,l in N)]
 assert len(absent)==6
 for p in pts:
  for u in stars:
   assert any(n&p and n&stars[u] for n,l in N)
   assert any(not n&p and l&inc[p] and l&u for n,l in N)
   if not inc[p]&u:assert any(n&p and l&u for n,l in N)
  for v in pts:
   if p!=v:
    assert inc[p]&~inc[v]
    assert any(not n&p and l&inc[p] and n&v for n,l in N)
    assert any(l&inc[p] and l&inc[v] for n,l in N)
 for u,v in combinations(stars,2):
  assert any(l&u and n&stars[v] for n,l in N) and any(l&v and n&stars[u] for n,l in N)
 def reject(u,pat):
  return all(any(n&pat==pat and u&l and n&hv for n,l in N)for v,hv in stars.items() if v!=u)
 pr={p:sum(u for u in stars if u&inc[p] and reject(u,0))for p in pts}
 for r in map(int,sys.argv[1:]):
  rem=[]
  for ordinary in combinations(stars,6-r):
   O=sum(ordinary)
   m={p:(pr[p]&O)|(128 if any(not n&p and l&inc[p]&~O and all(n&stars[u] for u in ordinary)for n,l in N)else 0)for p in pts}
   M=[p for p in pts if p&320 or m[p].bit_count()>=2]
   assert all(any(not n&p and l&inc[p] and n&v for n,l in N)or any(not n&v and l&inc[v] and n&p for n,l in N)for p,v in combinations(M,2))
   solo=[m[p] for p in M if m[p].bit_count()>2 and all(v==p or any(not n&v and l&inc[v] and n&p for n,l in N)or any(inc[v]&u and reject(u,p) for u in ordinary) for v in M)]
   if not pass_budget(tuple(solo),12-r-len(M)):continue
   j=O; suitable.cache_clear(); rem.append(O)
   with open(f'q2-{O}.in','w') as f:
    for a in range(len(M),min(9,12-r)+1):
     for extra in combinations(set(pts)-set(M),a-len(M)):
      z=set(M)|set(extra);rows=tuple(inc[p] for p in pts if p not in z)
      for g in range(12-r-a+1):
       for ds in combinations_with_replacement(range(13-r-a-g),g):
        sp=12-r-a-g-sum(ds)
        if sp>=0 and suitable(rows,ds,sp):print(sum(z),g,sp,*[2+d for d in ds],file=f)
  print(q,r,len(rem),rem,flush=True)
