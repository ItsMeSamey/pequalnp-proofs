from pathlib import Path
import subprocess as sp,sys,gzip,hashlib
from collections import defaultdict,Counter
def py(*args):return sp.check_output([sys.executable,*args])
P=Path
if not sys.argv[1:] or 'front' in sys.argv:
 for name,d in [('high-head-c320-cap25-low5.zip','765cd4b33f4d6dcd044ff6a2a3000f6f5eee9a07377dae42348ebebfd224973c'),('high-head-literal25-low5.zip','5ea903aad4ac0f109f4e5ab4107b5bc151903f314f4a57b9e74bcd97b8bd9a05'),('rootlocal25.zip','d68f6b04077178550f2422c7fd355c102e6cd73502f4a97259485aa0b0d471df')]:
  assert hashlib.sha256((P('deps')/name).read_bytes()).hexdigest()==d
 inp=P('q2-0.in').read_bytes()
 assert py('expanded.py','6')==b'2 6 1 [0]\n' and P('q2-0.in').read_bytes()==inp
 sp.run(['c++','-O2','two.cpp','-o','./clean'],check=True)
 out=sp.check_output(['./clean','0'],input=inp)
 assert out==P('q2-0.out').read_bytes()
 done=[a.split() for a in out.splitlines()if a.startswith(b'done')]
 keep=[]
 for a,b in zip(done,inp.splitlines(),strict=True):
  assert a[1:4]==b.split()[:3]
  if int(a[-1]):keep.append(b)
 assert len(keep)==34 and len(done)==246
 selected=b''.join(b+b'\n'for b in keep if int(b.split()[1])>=2)
 assert selected==P('selected.in').read_bytes()
 sp.run(['c++','-O2','tagmasks.cpp','-o','./tagmasks'],check=True)
 rows=sp.check_output(['./tagmasks','0'],input=selected)
 assert rows==gzip.decompress(P('tagmasks-reference.gz').read_bytes())
 assert py('native6.py','0','1')==P('native601.log').read_bytes()
 assert len(P('native601.log').read_text().splitlines())==16 and all(l.endswith('False')for l in P('native601.log').read_text().splitlines())
 print('246 layouts; 34 survive; 16 g0/1 excluded',flush=True)
if not sys.argv[1:] or 'masks' in sys.argv:
 import masktree as mt
 data=defaultdict(set)
 for line in gzip.decompress(P('tagmasks-reference.gz').read_bytes()).splitlines():
  a=line.split()
  if a[0]!=b'mask':continue
  z,g,k=map(int,a[1:]);data[z,g].add(tuple(k>>(7*i)&127 for i in range(g)))
 counts=Counter()
 for (z,g),vv in sorted(data.items()):
  vs=sorted(vv);mt.calls=0
  for i in range(0,len(vs),100):
   assert not mt.work(z,g,vs[i:i+100])
  counts[g]+=len(vs)
  print('mask class',z,g,len(vs),'all rejected',flush=True)
 assert counts=={2:1181,3:4518,4:4667}
 print('all 10366 possible low label multisets excluded')
