#include <cstdlib>
#include <set>
#include <cstdint>
#include <algorithm>
#include <cstdio>
#include <vector>
using namespace std;
int star[]={708,1408,2816,5632,3137,6272,4357};
int ordinary; int Q,Z,n,g,sp,ar[6],rec[6],cap[6],bo[7],hd[7],aff[7];
long long ng,nassign,lives;
std::set<uint64_t> masks;
struct Opt{int h,cl,eff;}; vector<Opt> opts[7];
int pc(int x){return __builtin_popcount((unsigned)x);}
void assign(int u,int active,int clean){
 if(u==7){
  if(active!=(1<<n)-1)return;
  nassign++;
  for(int i=0;i<7;i++)if(aff[i]>=0 && (star[i]&Z) && !(aff[i]&~clean))return;
  int cols[6]={};
  for(int k=0;k<n;k++)for(int v=0;v<7;v++)if(v!=5 && (hd[v]>>k&1))cols[k]|=1<<v;
  sort(cols,cols+g);uint64_t key=0;for(int i=0;i<g;i++)key=(key<<7)|cols[i];
  masks.insert(key);lives++;
  return;
 }
 for(auto o:opts[u]){hd[u]=o.h;aff[u]=o.eff;assign(u+1,active|o.h,clean|o.cl);}
}
void test(){
 int full=(1<<n)-1,loose=0;
 for(int i=0;i<n;i++)if(pc(rec[i])+pc(ar[i])<cap[i])loose|=1<<i;
 for(int u=0;u<7;u++){
  opts[u].clear();int req=star[u]&Q;
  for(int h=0;h<=full;h++){
   int parents=0,covered=0;
   for(int i=0;i<n;i++)if(h>>i&1){parents|=ar[i];covered|=rec[i];}
   int seeds=h&~parents,dr=req&~covered,cost=pc(seeds)+pc(dr);
   if(cost+(!h && req && (star[u]&Z))>((ordinary>>u&1)?1:2)+bo[u])continue;
   int reach=seeds;
   for(int i=0;i<n;i++)if(reach>>i&1)reach|=ar[i];
   int affected=dr;
   for(int i=0;i<n;i++)if(reach>>i&1)affected|=rec[i];
   bool tight=cost==((ordinary>>u&1)?1:2)+bo[u];
   opts[u].push_back({h,(tight&&!(loose&h))?req:0,(tight&&!(loose&reach))?affected:-1});
  }
  if(opts[u].empty())return;
 }
 ng++;assign(0,0,0);
}
void receiver(int i){
 if(i==n){test();return;}
 for(int r=Q;;r=(r-1)&Q){
  if(pc(r)+pc(ar[i])<=cap[i]){rec[i]=r;receiver(i+1);}
  if(!r)break;
 }
}
void owners(int left,int u){
 if(left && u==7)return;
 if(u==7){receiver(0);return;}
 for(bo[u]=0;bo[u]<=((ordinary>>u&1)?0:left);bo[u]++)owners(left-bo[u],u+1);
}
int main(int argc,char** argv){star[5]=0;ordinary=std::atoi(argv[1]);
 int k[6];
 while(scanf("%d%d%d",&Z,&g,&sp)==3){
  for(int i=0;i<g;i++)scanf("%d",k+i);
  masks.clear();Q=8133^Z;ng=nassign=lives=0;
  for(int subset=0;subset<1<<g;subset++){
   n=0;fill(cap,cap+6,0);
   for(int i=0;i<g;i++)if(subset>>i&1)cap[n++]=k[i];
   sort(cap,cap+n);
   do{
    for(int m=0;m<(1<<(n*(n-1)/2));m++){
     int y=0;fill(ar,ar+6,0);fill(rec,rec+6,0);
     for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)if(m>>(y++)&1)ar[i]|=1<<j;
     owners(sp,0);
    }
   }while(next_permutation(cap,cap+n));
  }
  for(auto m:masks)printf("mask %d %d %llu\n",Z,g,(unsigned long long)m);
  printf("done %d %d %d %lld %lld %lld\n",Z,g,sp,ng,nassign,lives);fflush(stdout);
 }
}
