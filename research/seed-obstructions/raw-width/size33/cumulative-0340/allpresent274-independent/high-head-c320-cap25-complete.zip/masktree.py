from nativeext import *
import compound_ext as ce
def work(z,g,V):
 named=tuple(p for p in s.pts if p&z and not p&320)
 pre=[0]*len(named);groups=[(p,) for p in named]+[(-1-j,)for j in range(g)];E=[(i,j)for i in range(len(groups)) for j in range(len(named),len(groups))if i!=j]
 from functools import reduce
 from operator import and_,or_
 def walk(V):
  global calls
  cols=list(zip(*V));lo=[reduce(and_,c)for c in cols];hi=[reduce(or_,c)for c in cols]
  poss=[p for p in s.pts if p not in named and any(not s.F[p]&s.on[m]for m in lo)]
  pr=[(p,3)for p in named]+[(p,0)for p in poss]
  calls+=1
  if not ce.actual((320,),pr,[pre+lo,pre+lo],E,groups,0,[pre+hi,pre+[95]*g],ordinary=(5,),allowcost=(1,)):return []
  if len(V)==1:return V
  j,u=min(((j,u)for j in range(g)for u in s.effective if (hi[j]^lo[j])&(1<<u)),key=lambda ju:abs(len(V)-2*sum(x[ju[0]]>>ju[1]&1 for x in V)))
  a=[v for v in V if v[j]>>u&1];b=[v for v in V if not v[j]>>u&1]
  return walk(a)+walk(b)
 return walk(V)
if __name__=='__main__':
 from collections import defaultdict
 masks=defaultdict(set)
 for l in Path('tagmasks.log').read_text().splitlines():
  a=l.split()
  if a[0]!='mask':continue
  z,g,k=map(int,a[1:]);h=tuple(k>>(7*i)&127 for i in range(g));masks[z,g].add(h)
 z,g=map(int,sys.argv[1:3]);V=sorted(masks[z,g]);calls=0
 start,end=map(int,sys.argv[3:5])
 for i in range(start,min(end,len(V)),100):
  subset=V[i:min(i+100,end)]
  ans=work(z,g,subset);print('range',i,len(subset),calls,len(ans),ans[:2],flush=True)
