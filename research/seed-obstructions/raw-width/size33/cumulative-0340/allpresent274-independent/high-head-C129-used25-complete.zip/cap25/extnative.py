from native import *
import types,sys
s=Compound()
mod=types.ModuleType('geometry')
mod.N=s.N;mod.P=s.P;mod.pts=s.pts
mod.pack=lambda f:sum(1<<i for i,n in enumerate(s.N)if f(n))
mod.alln=s.full;mod.stars=tuple(sum(S)for S in s.stars);mod.inc=s.inc;mod.on=s.tag;mod.pt=s.domq;mod.meet=s.meet
mod.union=union;mod.line=lambda m:s.on[m];mod.cache=cache;mod.combinations=combinations
sys.modules['geometry']=mod
import extkw
extkw.extra={129:20}
for o in (3,6,10,12,20,72):
 O=tuple(i for i in range(7)if (o|32)>>i&1)
 print(o,extkw.actual((129,),(),[[],[]],(),(),0,ordinary=O),flush=True)
print('recheck',run(s,(2,3),11,1,2000))
