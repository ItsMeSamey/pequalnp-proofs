from native import *
s=Compound()
for r in (3,4):
 for O in combinations(s.effective,6-r):
  o=sum(1<<u for u in O)
  _,m,so,b=s.roles(o,11)
  if not pass_budget(so,b):continue
  for a in range(b+1):
   result=run(s,O,11,a,100)
   print(r,o,a,repr(result)[:500],flush=True)
