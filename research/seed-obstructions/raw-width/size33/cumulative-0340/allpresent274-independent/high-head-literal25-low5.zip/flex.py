from core import *
from extkw import actual,pack,on
from functools import cache
calls=0
@cache
def signed(c,om,named,raw,co,sp,extra):
 global calls
 s=Source(0);s.bank(c);O=tuple(u for u in range(7)if om>>u&1);H=1<<len(c)
 cs=[pack(lambda n,j=j:all(not j>>a&1 or n>>library[m]&1 for a,m in enumerate(c)))for j in range(H)]
 du=s.on[127^om]&s.Ehits[om];F={q:s.F[q]&du for q in s.phys};qpin={q:sum(1<<a for a,m in enumerate(c)if q&m)for q in s.phys}
 qs=tuple(q for q in s.phys if q not in named)
 if any(not(s.no[q,p] or s.no_t[q,p]&om)for q in named if q not in raw for p in qs):return 'cross'
 for d in range(len(qs)+1 if extra else 1):
  for B in combinations(qs,d):
   if any(F[q]&s.domq[p]or F[p]&s.domq[q]for q,p in combinations(B,2)):continue
   gr=[(p,)for p in named]+[(-j-1,)for j in range(len(co))]+([B or(-100,)]if extra else [])
   rs=tuple((j,p)for j,p in enumerate(named)if p in raw)+tuple((len(named)+j,p)for j,p in enumerate(co))
   pr=[(p,(1<<H)-1 if p in raw else sum(1<<j for j in range(H)if j&qpin[p]==qpin[p]))for p in (*named,*B)]
   hi=[]
   for j in range(H):
    hi.append([(0 if q in raw else sum(1<<u for u in range(7)if u not in O and not(s.F[q]&cs[j]&s.tag[u])))for q in named]+[127 if j>>c.index(q)&1 else 0 for q in co]+([sum(1<<u for u in range(7)if u not in O and not any(F[p]&cs[j]&s.tag[u]for p in B))]if extra else []))
   calls+=1
   if calls>800:raise TimeoutError
   if actual(c,pr,[[0]*len(gr)for j in range(H)],(),gr,sp,hi,ordinary=O,rawnodes=rs):return ('possible',B)
 return False
