from itertools import combinations,product
from functools import cache
@cache
def parts(n):
 if not n:return [()]
 out=[]
 for p in parts(n-1):
  out.append(p+((n-1,),))
  for j in range(len(p)):out.append(p[:j]+(p[j]+(n-1,),)+p[j+1:])
 return out
@cache
def gain(req,pts,mask,fan):
 return max(sum(min(req[u],max(0,sum(bool(p>>u&1)for p in dest)-1))for u in range(7)if mask>>u&1)for dest in combinations(pts,min(len(pts),fan)))
@cache
def enough(pts,V,sups,owner):
 req=tuple(max(0,sum(bool(p>>u&1)for p in pts)-2) if V>>u&1 else 0 for u in range(7))
 n=sum(req)-owner
 if n<=0:return True
 act=tuple(s for s in sups if s[0]&V)
 for pp in parts(len(act)):
  g=0
  for t in pp:
   m=0;fan=1
   for i in t:m|=act[i][0];fan+=act[i][1]-1
   g+=gain(req,pts,m,fan)
  if g>=n:return True
 return False
def expand(z,s):
 for n in range(s-z.bit_count()+1):
  e=n+z.bit_count()
  for ds in product(range(s-e+1),repeat=e):
   if sum(ds)<=s-e:yield (z,n,ds)
