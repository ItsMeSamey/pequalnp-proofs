import subprocess as sp,sys
from pathlib import Path
from collections import Counter
def py(*args):return sp.check_output([sys.executable,*args])
assert py('high-head-isomorphisms.py')==Path('high-head-isomorphisms.log').read_bytes()
assert py('sym.py')==Path('sym.log').read_bytes()
assert py('low.py')==Path('low.log').read_bytes()
sp.run(['c++','-O2','two.cpp','-o','./check'],check=True)
counts=Counter();survivors=Counter()
for p in sorted(Path('expected').glob('q2-*.out')):
 o=int(p.stem.split('-')[1]);r=6-o.bit_count()
 rows=Path(f'q2-{o}.in').read_bytes()
 out=sp.run(['./check',str(o)],input=rows,stdout=sp.PIPE,check=True).stdout
 assert out==p.read_bytes()
 Path(p.name).write_bytes(out)
 done=[a.split() for a in out.splitlines() if a.startswith(b'done ')]
 for a,b in zip(done,rows.splitlines(),strict=True):
  assert a[1:4]==b.split()[:3]
  counts[r]+=1;survivors[r]+=int(int(a[-1])>0)
assert [counts[i]for i in range(6)]==[4,0,0,37,102,300]
assert [survivors[i]for i in range(6)]==[4,0,0,36,21,0]
for r in [0,3,4]:
 def stats(txt):return sorted(tuple(l.split()[:4]) for l in txt.splitlines())
 actual=py('private.py',str(r)).decode()
 assert stats(actual)==stats(Path(f'private{r}.log').read_text())
 if r<4:assert all(l.split()[3]=='True' for l in actual.splitlines())
 else:
  opens={int(l.split()[0]) for l in actual.splitlines() if l.split()[3]!='True'}
  assert opens=={3,20,72,6,10,12}
out=py('allsub.py','3','6').decode()
assert out==Path('allsub.log').read_text() and all(l.startswith('done') and l.endswith('[]')for l in out.splitlines())
print('cap25 ranks zero through five excluded; 57 subgroup profiles')
