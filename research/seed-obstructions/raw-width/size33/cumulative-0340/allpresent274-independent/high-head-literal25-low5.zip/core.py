import json
from pathlib import Path
from itertools import combinations
from functools import cache,reduce
import operator,sys
from collections import Counter
TAGS=tuple(1<<j for j in range(7))
ALL=tuple(1<<j for j in range(13))
A=[3<<j for j in range(6)]
B=[(1<<(3+j))|(1<<((9+j)%13))for j in range(6)]
library={m:k for k,m in enumerate(A+B+[x|y for x,y in zip(A,B)],20)}
def union(xx):return reduce(operator.or_,xx,0)
class Source:
 def __init__(self,rem):
  d=json.loads(Path(__file__).with_name(f'core-{rem}.json').read_text());ids=d['original_wire_ids']
  orig=lambda t:sum(1<<v for j,v in enumerate(ids)if t>>j&1)
  self.P=tuple(map(orig,d['positives']));self.N=tuple(map(orig,d['maximal_negatives']))
  self.pts=tuple(p for p in ALL if p not in d['peeled'])
  self.stars=tuple({r&8191 for r in self.P if r>>(13+j)&1}for j in range(7))
  self.inc={p:sum(l for l,s in zip(TAGS,self.stars)if p in s)for p in self.pts}
  assert all(a&b for a,b in combinations(self.stars,2))
  cut=sum(d['peeled']);ss=set(ALL)|set(library)|{0}
  self.allow=tuple(m for m in sorted(library)if not any(x!=m and not x&~m and not((x^m)&~cut)for x in ss))
  assert len(self.allow)==6
 def banks(self):
  for nw in range(20,25):
   for omit in ((0,2)if 2 in self.pts else(0,)):
    for c in combinations(self.allow,nw-20+bool(omit)):
     if omit and not {3,6,258}<=set(c):continue
     yield nw,c,omit
 def bank(self,c,omit=0):
  pts=self.pts;ns=self.N;raw=sum(pts)-omit+sum(1<<library[m]for m in c)
  self.phys=tuple(p for p in pts if p!=omit)
  self.pp={p:next(x&raw for x in self.P if x&p)for p in pts};self.ns=tuple((n&raw,(n>>13)&127)for n in ns)
  assert all(not any(not (x&(raw|(127<<13)))&~n for n in ns)for x in self.P)
  self.full=(1<<len(ns))-1
  def rows(f):return sum(1<<i for i,x in enumerate(ns)if f(x))
  @cache
  def dom(y):return rows(lambda r:not y&~r)
  self.dom=dom;self.domq={p:dom(s)for p,s in self.pp.items()}
  self.tag=[rows(lambda r:r>>(13+j)&1)for j in range(7)]
  self.meet=[union(self.domq[p]for p in T)for T in self.stars]
  self.on=[union(tt for m,tt in zip(TAGS,self.tag)if v&m)for v in range(128)]
  self.F={p:dom(self.pp[p]&~p)&~dom(p)&self.on[self.inc[p]]for p in self.phys}
  marked_domain=[p for p in self.phys if self.inc[p].bit_count()>=2]
  assert all(self.F[p] for p in marked_domain)and all(self.F[p]&self.domq[q] or self.F[q]&self.domq[p]for p,q in combinations(marked_domain,2))
  assert all(self.domq[p]&self.domq[q]for p in pts for q in pts)
  self.reject=cache(lambda u,x:all(j==u or dom(x)&self.tag[u]&self.meet[j]for j in range(7)))
  self.pr={p:sum(1<<u for u,T in enumerate(self.stars)if p in T and self.reject(u,self.pp[p]&~p))for p in self.phys}
  self.no={(q,p):bool(self.F[q]&self.domq[p])for q in self.phys for p in self.phys if p!=q}
  self.no_t={(q,p):sum(1<<u for u,S in enumerate(self.stars)if q in S and self.reject(u,(self.pp[q]&~q)|self.pp[p]))for q,p in self.no}
  self.Ehits=[reduce(operator.and_,(z for j,z in enumerate(self.meet)if O>>j&1),self.full)for O in range(128)]
 def roles(self,O,k):
  d={p:(self.pr[p]&O)|(128 if self.F[p]&self.on[self.inc[p]&~O]&self.Ehits[O] else 0)for p in self.phys}
  M=tuple(p for p,m in d.items()if m.bit_count()>=2)
  solo=tuple(sorted(d[p]for p in M if d[p].bit_count()>2 and all(q==p or self.no[q,p]or self.no_t[q,p]&O for q in M)))
  return d,M,solo,k-(7-O.bit_count())-len(M)
@cache
def pass_budget(ds,b):
 if b<0:return False
 if len(ds)<=b:return True
 assert all(m.bit_count()==3 for m in ds)
 universe=sum(1<<i for i in range(8)if any(m>>i&1 for m in ds))
 z=[{0}]
 for n in range(1,b+1):
  one={1<<j for j in range(len(ds))}if n==1 else set()
  for C in combinations([j for j in range(8)if universe>>j&1],min(universe.bit_count(),n+1)):
   t=sum(1<<j for j in C);one.add(sum(1<<j for j,m in enumerate(ds)if(t&m).bit_count()>=2))
  for i in range(1,n):one.update(x|y for x in z[i]for y in z[n-i])
  if (1<<len(ds))-1 in one:return True
  z.append(one)
 return False
def main(rem):
 s=Source(rem);surv=[];count=Counter();stat=Counter()
 for n,c,o in s.banks():
  s.bank(c,o);count[n]+=1
  for O in range(1,128):
   d,M,solo,b=s.roles(O,32-n)
   if pass_budget(solo,b):stat[n,7-O.bit_count(),b]+=1;surv.append((n,c,o,O,b))
  s.dom.cache_clear();s.reject.cache_clear()
 print(rem,sorted(count.items()),sorted(stat.items()),flush=True)
 Path(f'remaining-{rem}.txt').write_text(repr(surv)+'\n')
if __name__=='__main__':
 for rem in map(int,sys.argv[1:]):main(rem)
