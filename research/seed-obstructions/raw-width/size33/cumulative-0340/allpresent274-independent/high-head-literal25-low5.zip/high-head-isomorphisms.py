from itertools import permutations
from minors import DEGREE_ONE
from sample import samples
from pathlib import Path
rows,seed,target=samples(Path(__file__).with_name('L-meta-18968.json'))
pts=[1<<i for i in range(13) if 1<<i not in DEGREE_ONE]
def sample(q):
    u=DEGREE_ONE[q]
    lines=[1<<j for j in range(7) if j!=u]
    def compact(r):
        return (sum(1<<i for i,x in enumerate(pts) if r&x),sum(1<<i for i,x in enumerate(lines) if (r>>13)&x))
    P={compact(x) for i,x in enumerate(rows) if target>>i&1 and not seed>>i&1 and (x&sum(pts)) and not x>>(13+u)&1}
    N={compact(x) for i,x in enumerate(rows) if not target>>i&1 and x&q}
    return P,N
def transform(x,perm):
    return sum(1<<k for j,k in enumerate(perm) if x>>j&1)
def neigh(P):
    return [sum(l for p,l in P if p==1<<i) for i in range(9)]
for q in DEGREE_ONE:
    P,N=sample(q)
    for r in DEGREE_ONE:
        A,B=sample(r)
        g,h=neigh(P),neigh(A)
        assert len(set(g))==9 and len(set(h))==9
        matches=0
        for f in permutations(range(6)):
            mapped=[transform(x,f) for x in g]
            if set(mapped)!=set(h):continue
            d=[h.index(x) for x in mapped]
            if {(transform(p,d),transform(l,f)) for p,l in N}==B:
                matches+=1
        print(q,r,matches)
