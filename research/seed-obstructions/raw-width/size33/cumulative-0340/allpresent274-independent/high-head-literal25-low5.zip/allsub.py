from private import *
import types
from functools import cache
s=Native()
mod=types.ModuleType('geometry')
mod.N=s.N;mod.P=s.P;mod.pts=s.phys
mod.pack=lambda f:sum(1<<i for i,n in enumerate(s.N)if f(n))
mod.alln=s.full;mod.stars=tuple(sum(S)for S in s.stars);mod.inc=s.inc;mod.on=s.tag;mod.pt=s.domq;mod.meet=s.meet
mod.union=union;mod.line=lambda m:s.on[m];mod.cache=cache;mod.combinations=combinations
sys.modules['geometry']=mod
import extkw,flex
flex.Source=lambda unused:s
s.bank=lambda c:None
s.roles_original=s.roles
# fl.signed tests one optional anonymous helper (a grant) plus the exact named and owner overage.
seen={}
def exterior(o,named,a,sp):
 if a>1:return 'two-anon'
 k=(o,named,a,sp)
 if k not in seen:
  flex.calls=0
  try:seen[k]=flex.signed((),o|32,named,(),(),sp,a)
  except TimeoutError:seen[k]='cutoff'
 return seen[k]

import holderbranch as hb
hb.Source=lambda _:s

from itertools import chain
@cache
def envelope(o,named,an,sp):
 if an>=2:return "uncovered two-anonymous"
 if not an:return exterior(o,named,0,sp)
 hb.nc=flex.calls=0
 try:return hb.chk((),o|32,named,(),(),True,(),sp)
 except TimeoutError:return 'cutoff'
for o in map(int,sys.argv[1:]):
 O=tuple(u for u in s.effective if o>>u&1)
 done=set()
 for l in Path(f'q2-{o}.out').read_text().splitlines():
  a=l.split()
  if a[0]!='done' or a[-1]=='0':continue
  z,g=map(int,a[1:3])
  if (z,g)in done:continue
  done.add((z,g));s.z=z
  status,profiles=run(s,O,12,g,1500)
  if status is not False:print('OPEN price',o,z,g,status,flush=True)
  required=set()
  for m,sp in profiles:
   named=tuple(sorted(x for x in m if x>0))
   for k in range(len(named)+1):
    for subset in combinations(named,k):
     for an in range(1+sum(x<0 for x in m)):
      for b in range(sp+1):required.add((subset,an,b))
  live=[]
  for named,an,sp in sorted(required):
   res=envelope(o,named,an,sp)
   if res:live.append((named,an,sp,res))
  print('done',o,z,g,len(required),live,flush=True)
