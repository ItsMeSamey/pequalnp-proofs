from pathlib import Path
cases=set(Path('q2-0.in').read_text().splitlines())
closed=set()
for stem,keyfile in [('z2','z2.in'),('z1fast','z1fast.in')]+[('any-%02d'%i,'keys-%02d'%i) for i in range(1,8)]:
    source=Path(keyfile).read_text().splitlines()
    report=Path(stem+'.out').read_text().splitlines()
    rows=[r.split() for r in report if r.startswith('done ')]
    assert report[-1]=='EXIT 0' and len(rows)==len(source)
    for key,res in zip(source,rows):
        assert res[1:4]==key.split()[:3] and res[-1]=='0'
        closed.add(key)
for key in Path('z1four.in').read_text().splitlines():
    z=key.split()[0]
    rows=Path('fast-z'+z+'.out').read_text().splitlines()
    if rows and rows[-1]=='EXIT 0' and rows[-2].split()[-1]=='0':
        assert rows[-2].split()[1:4]==key.split()[:3]
        closed.add(key)
assert closed<=cases
print('closed',len(closed),'remaining',len(cases-closed))
for row in sorted(cases-closed): print(row)
