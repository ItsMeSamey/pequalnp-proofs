# Six-owner literal minor at 25 gates

The signed chart after pinning point 2 has nine physical point coordinates, six tags, 21 positives and 90 negatives. The previously checked 24-gate chart supplies the masking and deepest-guard lemmas. Six mandatory owner fanouts leave five units for named point origins, other helpers, and additional owner outputs. six.py enumerates the 394 possible profile keys. A row records the named point mask, number of available helpers, excess owner reads, and helper fanout caps.

any.cpp uses the existing clean-guard check and stops at the first compatible complete layout. fast.cpp additionally tests each partially populated recipient table. For any tag and any chosen effective helper set h, at least the number of indegree-zero vertices in the induced h subgraph have to receive direct owner outputs. Among its other direct outputs plus all as-yet unallocated guard slots of h it must be possible to cover every required point still outside the assigned recipients. This is only a cardinality upper bound on coverage. It allows every future helper slot to reach a different useful guard. A failed bound for every h rules out the prefix.

When two helpers have equal fanout caps and identical complete incoming and outgoing adjacency, exchanging them preserves arcs, tag choices, clean masks and all output tests. fast.cpp orders their guard recipient masks. Inactive helpers are still enumerated by the outer subset loop.

Run python named-ledger.py to verify reported completed scopes. The remaining zero-named profiles do not yield an exclusion just from the clean test. A compatible accounting assignment is not a circuit.
