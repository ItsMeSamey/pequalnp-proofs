from forest import *
i,t,e,r,C=next(x for l in (s.parent/'one-terminal-frontier/remaining.jsonl').read_text().splitlines()if (x:=json.loads(l))[0]==312)
u,q=2,16;bank=r|(127<<13)|sum(1<<extra[c]for c in C)
# Confirm q16-high dominates all actual negatives, and recheck source.
base=(r&sum(DEGREE_ONE))|4|(1<<(13+u));pinned=base|sum(1<<extra[c]for c in C)
A,B,_=chart(q);P,N=data(tuple(e))
fixed=bank&~pinned
hs=q|sum(1<<extra[c]for c in C if c&q)
pos=[(p,l)for p,l in A if not p&4]
neg=[(p,l)for p,l in B]
print(i,t,e,r,C,'price',33-2*t-pinned.bit_count(),'fixed',fixed,'high',hs)
pv=[next((j for j,v in enumerate(P)if not (v&bank)&~((p|l)&fixed|hs)),None)for p,l in pos]
nv=[next((j for j,v in enumerate(N)if not ((p|l)&fixed|hs)&~(v&bank)),None)for p,l in neg]
print('dom',len(pv),len(nv),None in pv,None in nv,'strict',oracle(tuple(e))(bank,q,pinned),flush=True)
print(pv,nv)
