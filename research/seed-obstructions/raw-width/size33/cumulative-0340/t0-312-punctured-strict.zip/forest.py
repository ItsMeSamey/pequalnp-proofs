from search import *
@cache
def oracle(e):
 P,N=data(e)
 ones={1<<i:sum(1<<j for j,n in enumerate(N)if n>>i&1)for i in range(38)}
 Pbits={v:sum(1<<j for j,p in enumerate(P)if p&v)for v in ones}
 posQ={v:n for n,p in enumerate(P)for v in DEGREE_ONE if p&v}
 @cache
 def dominate(x):
  if not x:return (1<<len(N))-1
  v=x&-x;return dominate(x^v)&ones[v]
 def gateok(bank,S,a,b,v,w,op):
     hp,hn=(v[0]|w[0],v[1]|w[1]) if op=='or' else (v[0]&w[0],v[1]&w[1])
     for z,zother in [(a,w),(b,v)]:
         if z in DEGREE_ONE and (op!='or' or (zother[0]>>posQ[z]&1)):return
     if not hp or any(not hp&~pp and not nn&~hn for pp,nn in [v,w]):return
     for x in bm(bank):
         if not hp&~Pbits[x] and not ones[x]&~hn:return
     for j,p in enumerate(P):
         ds=dominate(p&bank&~S)
         if ds and (not hp>>j&1 or ds&hn):return
     return hp,hn
 def could(bank,q,possible):
     terms={v:{(Pbits[v],ones[v])} for v in bm(possible)}
     subsets=[0]
     for v in bm(possible):subsets += [s|v for s in subsets]
     for S in sorted(subsets[1:],key=int.bit_count):
         if S not in terms:
             terms[S]=set()
             a=(S-1)&S
             while a:
                 b=S^a
                 if a<b:
                     for v in terms[a]:
                         for w in terms[b]:
                             for op in ('and','or'):
                                 h=gateok(bank,S,a,b,v,w,op)
                                 if h:terms[S].add(h)
                 a=(a-1)&S
         for w in terms[S]:
             if gateok(bank,S|q,q,S,(Pbits[q],ones[q]),w,'or'):return True
     return False
 @cache
 def blocked(bank,q,pin):
  possible=pin^q
  for p in P:
   pp=p&bank
   for v in bm(pp&possible):
    if dominate(pp^v)&ones[q]&~ones[v]:possible^=v
  return not could(bank,q,possible)
 return blocked
