import sys,json
from pathlib import Path
from functools import cache
from itertools import combinations,permutations
s=Path(__file__).resolve().parent/'base';sys.path.insert(0,str(s))
from cuts import extra,load,bm,DEGREE_ONE
exec((s/'high-head-isomorphisms.py').read_text().split('for q in DEGREE_ONE:')[0].replace("Path(__file__).with_name('L-meta-18968.json')","s/'L-meta-18968.json'"))
@cache
def chart(q):
 P,N=sample(q);g=neigh(P);A,B=sample(2);h=neigh(A);ds=[]
 for f in permutations(range(6)):
  mg=[transform(k,f)for k in g]
  if set(mg)!=set(h):continue
  d=[h.index(v)for v in mg]
  if {(transform(a,d),transform(b,f))for a,b in N}==B:ds.append(tuple(d))
 L=[u for u in range(7)if u!=DEGREE_ONE[q]]
 def full(V):return [(sum(p for j,p in enumerate(pts)if a>>j&1),sum(1<<(13+u)for j,u in enumerate(L)if b>>j&1))for a,b in V]
 return full(P),full(N),ds
@cache
def project(x,C):return sum(1<<j for j,v in enumerate(C)if x&v)
@cache
def allow(n,v,pos):return sum(1<<j for j in range(1<<n)if (not v&~j if pos else not j&~v))
@cache
def data(e):return load(e)
def scan(i,t,e,r,C):
 P,N=data(tuple(e));out=[]
 for q,u in DEGREE_ONE.items():
  TP,TN,ds=chart(q);O=sum(pts);fixed=r&O|(127^(1<<u))<<13
  for n in range(len(C)+1):
   for use in combinations(C,n):
    mp={c:c&O for c in use}
    if 0 in mp.values():continue
    paid=tuple(sorted(set(m for m in mp.values()if m.bit_count()>1)))
    cost=33-2*t-len(C)+n-(r&sum(DEGREE_ONE)).bit_count()-1
    if cost>25:continue
    canon=min(tuple(sorted(transform(project(m,tuple(pts)),d)for m in paid))for d in ds)
    known=((),(9,),(20,),(9,20),(9,33),(9,130),(20,33))
    mintotal=min(cost+sum(m.bit_count()-1 for m in paid if m not in retained) for k in range(len(paid)+1) for retained in combinations(paid,k) if min(tuple(sorted(transform(project(m,tuple(pts)),d)for m in retained))for d in ds) in known)
    if mintotal>25:continue
    ext=sum(1<<extra[c]for c in use); bits=tuple(bm(r&sum(DEGREE_ONE)))+(1<<(13+u),)+tuple(1<<extra[c]for c in C if c not in use)
    mask=(1<<(1<<len(bits)))-1
    for pos,targets,native in [(True,TP,P),(False,TN,N)]:
     pairs={(v&(fixed|ext),project(v,bits))for v in native}
     for xp,xl in targets:
      target=(xp|xl)&fixed|sum(1<<extra[c]for c,m in mp.items()if xp&m)
      good=0
      for v,b in pairs:
       if (not v&~target if pos else not target&~v):good|=allow(len(bits),b,pos)
      mask&=good
      if not mask:break
     if not mask:break
    if mask:
     v=(mask&-mask).bit_length()-1;out.append([mintotal,q,use,canon,[bit.bit_length()-1 for j,bit in enumerate(bits)if v>>j&1],mask.bit_count()])
 return out
if __name__=='__main__':
 t,start,stop=map(int,sys.argv[1:]);folder=Path(__file__).resolve().parent/'lists'
 ids=sorted(map(int,(folder/f't{t}-remaining-{(466,4)[t]}.ids').read_text().split()))[start:stop]
 for l in (s.parent/'one-terminal-frontier/remaining.jsonl').read_text().splitlines():
  i,t0,e,r,C=json.loads(l)
  if t0==t and i in ids:print(json.dumps([i,scan(i,t,e,r,C)]),flush=True)
