from search import *
from collections import Counter
lookup={x[0]:x for ln in (s.parent/'one-terminal-frontier/remaining.jsonl').read_text().splitlines()for x in [json.loads(ln)]}
out={};hist=Counter()
for row in Path('t0.log').read_text().splitlines():
 i,cases=json.loads(row)
 if not cases:continue
 _,t,e,r,C=lookup[i];price,q,use,canon,hi,_=cases[0];u=DEGREE_ONE[q];P,N=data(tuple(e));A,B,_=chart(q);O=sum(pts)
 masks=r&O|((127^(1<<u))<<13);inhi=sum(1<<x for x in hi)
 pin=(r&sum(DEGREE_ONE))|(1<<(13+u))|sum(1<<extra[c]for c in C if c not in use)
 mask=(r|(127<<13)|sum(1<<extra[c]for c in C))
 def vec(p,l):return (p|l)&masks|inhi|sum(1<<extra[c]for c in use if c&O&p)
 assert not inhi&~pin and t==0 and price>=33-pin.bit_count()
 witness=[]
 for pre,rows_,sign in [(A,P,1),(B,N,0)]:
  witness.append([next(idx for idx,n in enumerate(rows_)if (not (n&mask)&~vec(p,l) if sign else not vec(p,l)&~(n&mask)))for p,l in pre])
 assert len(witness[0])==21 and len(witness[1])==90
 out[i]={'q':q,'used':use,'high':hi,'pinned_bits':pin,'price':price,'library':canon,'witnesses':witness}
 hist[tuple(canon)]+=1
print(len(out),hist);Path('witness54.json').write_text(json.dumps(out,sort_keys=True))
