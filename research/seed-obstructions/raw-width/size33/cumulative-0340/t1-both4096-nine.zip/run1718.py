import os,sys,inspect,gzip,json,ast
from pathlib import Path
V=str(Path(__file__).resolve().parent);sys.path.insert(0,V)
import nativechart as c
a,b=map(int,sys.argv[1:3]);jobs={}
for l in Path('rr15.log').read_text().splitlines():
 j,w,ids,n,s=ast.literal_eval(l)
 if j in (17,18):
  assert s==[(sum(v for v,k in w)+4096,1,(0,0),0)]
  for i in ids:jobs[i]=s[0][0]
ii=sorted(jobs)
rows={i:json.loads(l)for i,l in enumerate(gzip.open('terminal-raw-keys.jsonl.gz'))if i in ii[a:b]}
os.chdir(V)
for i,r in rows.items():
 z=jobs[i];assert set(r[5])=={64,z-4096-64,129,4160} and len(r[5])==4
 src=inspect.getsource(c.solve).replace('~641',f'~{z}').replace('if p!=128','if p!=4096').replace('sat.conf_budget(5000)','sat.conf_budget(2500)')
 env=dict(vars(c));exec(src,env);n=c.setup(r)
 print(i,[env['solve'](r,[8191]*12,conf,n)for conf in (((4096,0),(0,0)),((0,0),(4096,0)))],flush=True)
