from route2 import *
from itertools import combinations_with_replacement
@cache
def test(z,conf,bo,site):
 n=len(conf);vmax=7+n; regs=range(vmax+1)
 fans=[2+r for r in bo]+[2+d for _,d in conf]
 S=[(i,b)for i,f in enumerate(fans) for b in range(f+(i<7))]
 PH=[(p,h)for p in bm(8133&~z)for h in range(4)if cov[h][p]==inc[p]]
 Q=sorted({p for p,h in PH});ids=IDPool();v=lambda *k:ids.id(k)
 with Solver(name='cadical195') as sat:
  add=sat.add_clause
  def amo(xs):
   for x,y in combinations(xs,2):add([-x,-y])
  L={(a,b,r):v('L',a,b,r)for a,b in S for r in regs if not 7<=r<min(a+1,vmax) and (b<fans[a] or r==a)}
  for a,b in S:amo([L[a,b,r]for r in regs if (a,b,r)in L])
  H={(p,r):v('S',p,r)for p in Q for r in regs}
  for p in Q:
   row=[H[p,r]for r in regs];amo(row);add(row)
   for j,(x,d)in enumerate(conf):
    if x and F[p]&pt[x]&cs[3]:add([-H[p,7+j]])
  mapsite=[*range(7)]+[8 if p==128 else 10 for p,d in conf]+[11]
  for (p,r),var in H.items():
   if not site[mapsite[r]]&p:add([-var])
  for u in range(7):amo([L[u,b,u]for b in range(fans[u])])
  age=lambda a,h,u:v('age',a,h,u)
  @cache
  def both(x,y):
   t=v('AND',x,y);add([-t,x]);add([-t,y]);add([-x,-y,t]);return t
  for h,u in {(h,u)for p,h in PH for u in range(7)if inc[p]>>u&1}:
   for p in Q:
    if not up[h][p]>>u&1:add([-H[p,u],-age(u,h,u)])
   for j,(x,d)in enumerate(conf):
    a=7+j;y=age(a,h,u)
    if x and not up[h][x]>>u&1:add([-y])
    for p in Q:
     if not up[h][p]>>u&1:add([-H[p,a],-y])
    add([-y]+[both(L[b,k,a],age(b,h,u))for b,k in S if (b,k,a)in L and(b==u or b>=7)])
  for a,b in S:
   for p,h in PH:
    t=v('guard',a,b,p,h)
    for r in regs:
     add([-t,-H[p,r]]+([L[a,b,r]] if(a,b,r)in L else []))
   for (p,h),(q,k)in combinations(PH,2):
    if p!=q and disjoint(p,q,h|k):add([-v('guard',a,b,p,h),-v('guard',a,b,q,k)])
  for p,h in PH:
   for bit in bm(inc[p]):
    j=bit.bit_length()-1;opts=[]
    for a,b in S:
     if a<7 and a!=j:continue
     w=v('use',p,h,j,a,b);opts.append(w)
     add([-w,v('guard',a,b,p,h)])
     add([-w,age(a,h,j)]+([H[p,a]]if a<7 else []))
    add(opts)
  sat.conf_budget(2000);return sat.solve_limited()

from ast import literal_eval
def can(site):
 return any(test(641,conf,(0,)*7,site) is not False for conf in (((128,0),(0,0)),((0,0),(128,0))))
if __name__=='__main__':
 a,b=map(int,sys.argv[1:3])
 for i,l in enumerate(Path('sites.txt').read_text().splitlines()):
  if a<=i<b:print(i,can(literal_eval(l)),flush=True)
