from geometry import *
from cuts import extra
import sys
from pathlib import Path
from ast import literal_eval
from all4 import test as licensed
from pysat.formula import IDPool
from pysat.solvers import Solver
from itertools import permutations
from functools import cache
c=(129,4160)
cs=[pack(lambda n:all(not h>>j&1 or n>>extra[x]&1 for j,x in enumerate(c))) for h in range(4)]
orig={p:sum(1<<j for j,x in enumerate(c)if x&p) for p in pts}
F={p:~pt[p]&line(inc[p])&cs[orig[p]] for p in pts}
up=[{p:sum(1<<u for u in range(7)if not b&F[p]&on[u]) for p in pts}for b in cs]
cov=[{p:0 for p in pts}for _ in range(4)]
for H,v,k in licensed(P,N,8133,c):
 h=sum(1<<c.index(x)for x in H)
 for p in bm(k):cov[h][p]|=v&inc[p]
@cache
def disjoint(p,q,h):
 a=up[h][p]&up[h][q]
 common=any(inc[p]>>t&1 and inc[q]>>u&1 and not a&((1<<t)|(1<<u))and cs[h]&on[t]&on[u]for t in range(7)for u in range(7))
 sep=any(inc[x]>>u&1 and not inc[y]>>u&1 and not a>>u&1 and cs[h]&pt[y]&on[u]for x,y in ((p,q),(q,p))for u in range(7))
 return common and sep
def route(w,s,bo,reverse=False):
 z,gs,g,ds,sp=s;assert sum(bo)==sp
 Q=bm(8133&~z);n=len(ds); H=range(n)
 states={p:[h for h in range(4)if cov[h][p]==inc[p]] for p in Q}
 Q=[p for p in Q if states[p]]
 pins={p:min(states[p],key=lambda h:(h.bit_count(),-h if reverse else h)) for p in Q}
 blocks=Q[:]
 for p,q in combinations(Q,2):
  if disjoint(p,q,pins[p]|pins[q]):continue
  a=next(b for b in blocks if b&p);b=next(b for b in blocks if b&q)
  if a!=b:blocks.remove(a);blocks.remove(b);blocks.append(a|b)
 ids=IDPool();v=lambda *x:ids.id(x)
 with Solver(name='cadical195') as sat:
  add=sat.add_clause
  def cap(a,k):
   for sub in combinations(a,k+1):add([-x for x in sub])
  def both(x,y):
   b=v('both',x,y);add([-b,x]);add([-b,y]);add([-x,-y,b]);return b
  e={(a,b):v('edge',a,b)for a in H for b in H if a!=b}
  for a,b in e:add([-e[a,b],v('order',a,b)]);add([-v('order',a,b),-v('order',b,a)])
  for a,b,d in permutations(H,3):add([-v('order',a,b),-v('order',b,d),v('order',a,d)])
  dest={(a,b):v('bin',a,b)for a in H for b in blocks}
  for a in H:cap([dest[a,b]for b in blocks]+[e[a,b]for b in H if a!=b],2+ds[a])
  holds={}
  for p in Q:
   W=[]
   for a in H:
    if a<len(gs) and F[p]&pt[gs[a]]&cs[3]:continue
    h=v('holdactive',a,p);holds[a,p]=h;W.append(h)
   cap(W,1)
  for u in range(7):
   send=[v('send',u,a)for a in H]
   direct={b:v('direct',u,b)for b in blocks if any(inc[p]>>u&1 for p in bm(b))}
   cap(list(direct.values())+send,2+bo[u])
   for p in Q:
    h=pins[p]
    if not inc[p]>>u&1:continue
    b=next(b for b in blocks if p&b); row=[direct[b]]
    row.extend(holds[a,p]for a in H if (a,p) in holds)
    for a in H:
     t=v('sig',h,u,a)
     if a<len(gs) and not up[h][gs[a]]>>u&1:add([-t])
     for (j,q),hold in holds.items():
      if j==a and not up[h][q]>>u&1:add([-hold,-t])
     add([-t,send[a]]+[both(e[j,a],v('sig',h,u,j))for j in H if j!=a])
     row.append(both(dest[a,b],t))
    add(row)
  # Excusing a resident is permitted only for a helper which can carry at
  # least one global high-pin tag given all its actual assigned residents.
  for a in H:
   labels=[v('high',a,u)for u in range(7)]
   if a<len(gs):
    for u in range(7):
     if not up[3][gs[a]]>>u&1:add([-labels[u]])
   for (j,q),hold in holds.items():
    if j!=a:continue
    add([-hold]+labels)
    for u in range(7):
     if not up[3][q]>>u&1:add([-hold,-labels[u]])
  def compatible(p,q):
   h=pins[p]|pins[q];a=up[h][p]&up[h][q]
   return any(inc[p]>>t&1 and inc[q]>>s&1 and not a&((1<<t)|(1<<s)) and cs[h]&on[t]&on[s]for t in range(7)for s in range(7))
  seen=0
  while seen<1000:
   sat.conf_budget(2000);result=sat.solve_limited()
   if result is not True:return result
   model=set(sat.get_model())
   exclusion=None
   for t in range(7):
    reachable={a for a in H if v('send',t,a) in model}
    occupied=[v('send',t,a) for a in reachable]
    bins={b for b in blocks if v('direct',t,b) in model}
    occupied.extend(v('direct',t,b)for b in bins)
    if len(occupied)!=2+bo[t]:continue
    for _ in H:
     reachable|={b for (a,b),lit in e.items()if a in reachable and lit in model}
    for a in reachable:
     outlets=[k for (h,b),k in e.items()if h==a and k in model]
     to={b for b in blocks if v('bin',a,b)in model}
     if len(outlets)+len(to)!=2+ds[a]:break
     bins.update(to);occupied.extend(outlets);occupied.extend(v('bin',a,b)for b in to)
    else:
     affected=bm(union(bins))
     if any(not compatible(p,q)for p,q in combinations(affected,2)):continue
     if any(all(F[q]&pt[p]&cs[pins[q]] for q in affected)for p in bm(stars[t]&z)):
      exclusion=[-x for x in occupied];break
   if exclusion is None:return True
   add(exclusion);seen+=1
  return None

from itertools import combinations_with_replacement
def permitted(w,s):
 z,g,ds,sp=s;gs=tuple(p for p in bm(z)if p not in dict(w))
 for grp in combinations_with_replacement(range(7),sp):
  b=tuple(grp.count(u)for u in range(7))
  for rev in (False,True):
   result=route(w,(z,gs,g,ds,sp),b,rev)
   if result is False:break
  else:return True
 return False
if __name__=='__main__':
 start,end=map(int,sys.argv[1:])
 cases={}
 for f in sorted(Path('.').glob('b[ctx][0-9]*.log')):
  for l in f.read_text().splitlines():
   if l.startswith('('):
    row=literal_eval(l);cases[row[0]]=row
 for j in range(start,end):
  if j not in cases:continue
  _,w,ids,n,js,rs=cases[j]
  kept=[s for s in rs if permitted(w,s)]
  print(repr((j,w,ids,len(rs),kept)),flush=True)
