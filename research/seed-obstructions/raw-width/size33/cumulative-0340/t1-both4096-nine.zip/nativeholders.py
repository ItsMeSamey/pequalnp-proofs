from ast import literal_eval
from itertools import combinations
from collections import Counter
import gzip,json,sys
from cuts import load,bm,extra
from pathlib import Path
from functools import cache
KEYS={8933,8934,8969,8970,10953,10954,10989,10990}
def run(row,ss):
 _,e,R,C,*_=row
 sel=R|(127<<13)|sum(1<<extra[c]for c in C)
 P,N=load(tuple(e));P=[p&sel for p in P];N=[n&sel for n in N]
 unique=[{n:a&~n for n in N if (a&~n).bit_count()==1}for a in P]
 A=[set(d.values())for d in unique];B=[{d[n]for d in unique if n in d}for n in N]
 ands=set(t for s in A for t in combinations(sorted(s),2))
 ors=set(t for s in B for t in combinations(sorted(s),2))
 ban=ands&ors
 def can(group):
  return not any(group&a and group&b for a,b in ban)
 X=[1<<extra[c] for c in C]+[p for p in bm(R) if p&58 or p in [1,512]]
 X=tuple(sorted(set(X)))
 def test(s):
  # Ignore restrictions on the two actual destinations of each alias pair.
  owners=tuple((s[h]&~(1|512))|((1<<(13+h)) if h<7 else 0) for h in [*range(7),8,10,11])
  # A mandatory raw line may itself have multiple occurrences. Only its own
  # intersection with a local point implies this line really occurs once locally.
  if not all(can(g)for g in owners):return False
  @cache
  def rec(rem,gs):
   if not rem:return True
   x=min(rem,key=lambda a:sum(can(g|a)for g in gs))
   return any(rec(rem-{x},tuple((g|x if j==i else g)for j,g in enumerate(gs)))for i,h in enumerate(gs) if can(h|x))
  return rec(frozenset(X),owners)
 return len(ban),[i for i,s in enumerate(ss)if test(s)]
if __name__=='__main__':
 ss=[literal_eval(l)for l in Path('sites.txt').read_text().splitlines()][:19]
 for i,l in enumerate(gzip.open('terminal-raw-keys.jsonl.gz')):
  if i in KEYS:print(i,*run(json.loads(l),ss),flush=True)
