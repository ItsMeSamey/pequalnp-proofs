from nativeholders import KEYS
from exact import *
from itertools import combinations
import json,gzip
from cuts import load,extra
def setup(row):
 _,e,R,C,*_=row
 PP,NN=load(tuple(e));Q0=bm(R)
 ii={p:sum(1<<j for j in range(7)if any((r&8191)==p and r>>(13+j)&1 for r in PP))for p in Q0}
 def pk(fn):return sum(1<<j for j,n in enumerate(NN)if fn(n))
 nn=[pk(lambda n:n>>(13+j)&1)for j in range(7)]
 xx={p:pk(lambda n:n&p)for p in Q0}
 hh=[pk(lambda n:all(not h>>j&1 or n>>extra[m]&1 for j,m in enumerate(C)))for h in range(16)]
 ff={p:pk(lambda n:not n&p and any((r&8191)==p and not (r&(R|sum(1<<extra[m]for m in C)|127<<13)&~p)&~n for r in PP))for p in Q0}
 uu=[{p:sum(1<<j for j in range(7)if not h&ff[p]&nn[j])for p in Q0}for h in hh]
 src=Path('all4.py').read_text().split('if __name__')[0].replace('subs(bm(127),3)','[()]').replace('subs(bm(U&av),4)','[()]')
 src=src.replace('if sum(max(0,(k&t).bit_count()-2)for u,t in enumerate(S)if V>>u&1)>0:yield k','if k:yield k').replace('for k in walk(K):yield H,V,k','if K:yield H,V,K')
 env={};exec(src,env)
 pv={}
 for H,V,K in env['test'](PP,NN,R,C):
  h=sum(1<<C.index(m)for m in H)
  for p in bm(K):pv[p,h]=pv.get((p,h),0)|(V&ii[p])
 ph=[(p,h)for p,h in pv if pv[p,h]==ii[p]]
 return ii,hh,ff,nn,xx,uu,ph
def solve(row,site,conf,native):
 ii,hh,ff,nn,xx,uu,ph=native
 ids=IDPool();v=lambda *k:ids.id(k)
 src=Path('freesite.py').read_text().split('from ast import')[0]
 # Run both pin families in the same SAT instance by named clauses/variable IDs.
 base=src[src.index('  add=sat.add_clause'):src.index('  sat.conf_budget')]
 with Solver(name='cadical195')as sat:
  for nat in (0,1):
   active=ph if nat else [(p,h)for p in bm(8133&~641)for h in range(4)if cov[h][p]==inc[p]]
   if nat:active=[(p,h)for p,h in active if p!=128]
   up0=uu if nat else up;inc0=ii if nat else inc
   def key(*args):
    if args[0] in ('age','guard','use'):return v(nat,*args)
    return v(*args)
   def sep(p,q,h):
    if not nat:return disjoint(p,q,h)
    a=uu[h][p]&uu[h][q]
    return (any(ii[p]>>t&1 and ii[q]>>u&1 and not a&((1<<t)|(1<<u)) and hh[h]&nn[t]&nn[u]for t in range(7)for u in range(7)) and any(ii[x]>>u&1 and not ii[y]>>u&1 and not a>>u&1 and hh[h]&xx[y]&nn[u]for x,y in [(p,q),(q,p)]for u in range(7)))
   code=base.replace('if not site[mapsite[r]]&p:', 'if p not in free and not site[mapsite[r]]&p:').replace('cs[3]','cs[-1]').replace('    add(opts)','    add(opts+waive(p,h))')
   # At original pins grant any eligible point residing at either helper a
   # local omission; its unknown actual bare-point baseline may turn high.
   def waiver(p,h):
    if not nat:return []
    return [key('S',p,7+j)for j,(x,d) in enumerate(conf) if not x or not ff[p]&xx[x]&hh[-1]]
   S=[(i,k)for i in range(9)for k in range(2+(i<7))]
   scope=dict(v=key,sat=sat,S=S,regs=range(10),vmax=9,PH=active,Q=sorted({p for p,h in active}),conf=conf,site=site,fans=[2]*9,F=ff if nat else F,pt=xx if nat else pt,cs=hh if nat else cs,up=up0,inc=inc0,cache=cache,combinations=combinations,bm=bm,disjoint=sep,waive=waiver,free=(1,512,2,8,16,32)if nat else ())
   exec('if True:\n'+code,scope)
  sat.conf_budget(5000);return sat.solve_limited()
if __name__=='__main__':
 idx,a,b=map(int,sys.argv[1:4])
 row=next(json.loads(l)for i,l in enumerate(gzip.open('terminal-raw-keys.jsonl.gz'))if i==idx);n=setup(row)
 print('licensed',len(n[-1]),flush=True)
 for i,l in enumerate(Path('sites.txt').read_text().splitlines()):
  if a<=i<b:print(i,[solve(row,literal_eval(l),c,n)for c in (((128,0),(0,0)),((0,0),(128,0)))],flush=True)
