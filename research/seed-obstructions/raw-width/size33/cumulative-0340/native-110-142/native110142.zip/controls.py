"""Apply the predecessor's native geometric and donor controls to both new originals."""
from io import BytesIO
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import subprocess
with TemporaryDirectory() as tmp, ZipFile(Path(__file__).with_name('t0-110-142.zip')) as z:
    with ZipFile(BytesIO(z.read('predecessor.zip'))) as p:
        p.extractall(tmp)
    d = Path(tmp)
    (d / 'original.py').write_bytes(z.read('original.py'))
    code = (d / 'ctrl.py').read_text().split('ls=')[0]
    assert code.count('for i in (120,143):') == 1
    (d / 'native_controls.py').write_text(code.replace('for i in (120,143):','for i in (110,142):'))
    subprocess.run([sys.executable, '-B', 'native_controls.py'], cwd=d, check=True)
