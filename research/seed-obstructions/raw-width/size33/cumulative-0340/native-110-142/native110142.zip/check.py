"""Native true-budget checks, with original coordinate indexing in both banks."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from cuts import load
from minors import DEGREE_ONE
from realcore import ALL, Source, library, pass_budget
from realresources import run

here = Path(__file__).resolve().parent
ledger = {r[0]: r for r in map(json.loads, (here / 'remaining.jsonl').read_text().splitlines())}
archive = here / 't0-110-142.zip'
assert sha256(archive.read_bytes()).hexdigest() == '6a0094f13f488febe5c2d3e291e85f71e36548950b97813a891e14b281f94b57'

with TemporaryDirectory() as exterior:
    with ZipFile(archive) as outer:
        with ZipFile(BytesIO(outer.read('predecessor.zip'))) as inner:
            inner.extractall(exterior)
        (Path(exterior) / 'original.py').write_bytes(outer.read('original.py'))
    for ident, wanted, candidates in (
            (110, [129, 523], [34,38,42,46,127]),
            (142, [354, 4160], [40,42,44,46,127])):
        _, terminals, peeled, physical, compounds = ledger[ident]
        assert terminals == 0 and not peeled and physical == sum(ALL) and compounds == wanted
        quartet, = [x for x in compounds if x.bit_count() == 4]
        special = [p for p in DEGREE_ONE if p & quartet]
        assert len(special) == 2
        forced = sum(1 << DEGREE_ONE[p] for p in special)
        assert forced == candidates[0]
        surplus = 34 - (physical.bit_count() + 7 + len(compounds))
        assert surplus == 12
        s = object.__new__(Source)
        s.P, s.N = load(())
        assert (len(s.P), len(s.N)) == (28,245)
        s.pts = ALL
        s.stars = tuple({p & 8191 for p in s.P if p >> (13+u) & 1} for u in range(7))
        s.inc = {p: sum(1 << u for u, star in enumerate(s.stars) if p in star) for p in ALL}
        for x in s.P + s.N:
            assert all(bool(x & m) == bool(x >> bit & 1) for m, bit in library.items())
        s.bank(tuple(compounds), 0)
        marks = set.union(*(s.stars[DEGREE_ONE[p]] for p in special)) - set(DEGREE_ONE)
        assert len(marks) == 5
        survivors = [o for o in range(128) if o & forced == forced
                     and pass_budget(*s.roles(o, surplus)[2:])]
        assert survivors == candidates
        print(ident, 'ordinary masks', survivors, 'five marks', sorted(marks))
        for o in survivors:
            tags = tuple(j for j in range(7) if o >> j & 1)
            _, named, _, slack = s.roles(o, surplus)
            assert marks <= set(named)
            for p in marks:
                for q in named:
                    assert p == q or s.no[p,q] or s.no[q,p] or s.no_t[q,p] & o
            if o == forced:
                continue
            for g in range(slack + 1):
                result = run(s, tags, surplus, g, 2500)
                assert result == (False, []), (ident, o, g, result)
                print(ident, o, 'helpers', g, 'private routing UNSAT')
        process = subprocess.run(
            [sys.executable, '-B', 'extorig.py', str(ident), str(forced)],
            cwd=exterior, text=True, capture_output=True, check=True)
        log = process.stdout.splitlines()
        assert log == [f'{forced} {g} complete True open []' for g in range(3)], log
        for line in log:
            print(ident, line)
