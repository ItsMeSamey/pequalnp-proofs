from pathlib import Path
from ast import literal_eval
import re
R=lambda f:Path(f).read_text().splitlines()
base=[tuple(map(int,l.split()))for l in R('q2-0.in')]
out=[l.split() for l in R('six.out')if l.startswith('done ')]
assert R('six.out')[-1]=='EXIT 0' and len(base)==len(out)==57
alive=set()
for k,x in zip(base,out):
 assert k[:3]==tuple(map(int,x[1:4]))
 if x[-1]!='0':alive.add(k[:3])
assert len(alive)==34
def results(f,kind):
 for l in R(f):
  match=re.fullmatch(r'(\d+) (\d+) (\d+) (\(.*?\)) (False)',l)
  if match:yield (*map(int,match.group(1,2,3)),literal_eval(match[4]) if kind else ())
low=set(results('native6low.log',False))|set(results('extra6b.log',True))|set(results('extra6tail.log',True))
for z,g,sp in alive:
 if g>1:continue
 for rr in [()]+([(p,)for p in (1,64,128,256)] if sp else []):
  assert (z,g,sp,rr)in low,(z,g,sp,rr)
mrows=[l.split()for l in R('multi.log')if l.startswith('mask ')]
assert R('multi.log')[-1]=='EXIT 0'
def masks(z,g):return sorted(set(int(a[3])for a in mrows if a[1:3]==[str(z),str(g)]))
def interval(f):
 k,span,success=R(f)
 assert success=='EXIT 0' and span.startswith('DONE ') and literal_eval(span[5:])[1] is None,(f,span)
 t=k.split();return tuple(map(int,t[1:]))
for z in (961,2497,453,4545):
 a,b,c=R('cut-%d-2-0.log'%z);assert int(a.split()[-1])==len(masks(z,2));assert b.endswith('None)') and c=='EXIT 0'
streams=R('cut-449-2-1.log');assert int(streams[0].split()[-1])==len(masks(449,2))
assert any(l.startswith('RESULT () ') and l.endswith('None)') for l in streams)
assert any(l.startswith('RESULT (1,) ') and l.endswith('None)') for l in streams)
def coverage(z,g,rr,files):
 bounds=set()
 for f in files:
  Z,G,S,RW,A,B,L=interval(f);assert (Z,G,S,RW)==(z,g,0,rr) and B-A==L;bounds.update(range(A,B))
 assert bounds==set(range(len(masks(z,g)))),(z,g,rr,len(bounds),len(masks(z,g)))
for rr in (0,64,128,256):
 coverage(449,2,rr,['group-449-2-%d.log'%rr,*Path('.').glob('g449-2-%d-*.log'%rr)])
coverage(1473,2,0,Path('.').glob('end-1473-*.log'))
coverage(449,3,0,['group-449-3-0.log','end-449-80-580.log',*Path('.').glob('t3-*.log'),*Path('.').glob('tail3-*.log')])
print('57 expanded profiles; 34 clean survivors; all native branches excluded')
