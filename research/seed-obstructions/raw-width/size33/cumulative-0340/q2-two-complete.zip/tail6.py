from nativeext import *
for l in Path('six.out').read_text().splitlines():
 a=l.split()
 if a[0]!='done' or a[-1]=='0':continue
 z,g,sp=map(int,a[1:4]);ns=tuple(p for p in s.pts if p&z and not p&449)
 if g>1 or sp!=1:continue
 hs=[(ns,(),sp)]+[(tuple(sorted((*ns,p))),(p,),0)for p in (1,64,128,256)]
 for named,raw,sur in hs:
  key=" ".join(map(str,(z,g,sp)))+" "+str(raw)+" "
  if any(row.startswith(key) for row in Path("extra6b.log").read_text().splitlines()):continue
  hb.nc=flex.calls=0
  try:
   res=(hb.chk((320,129),32,named,raw,(),True,(),sur) if g else flex.signed((320,129),32,named,raw,(),sur,False))
  except TimeoutError:res='cutoff'
  print(z,g,sp,raw,res,flush=True)
