from nativeext import *
import compound_ext as ce
from functools import reduce
from operator import and_,or_
from collections import defaultdict
rows=defaultdict(set)
for l in Path('multi.log').read_text().splitlines():
 a=l.split()
 if a[0]=='mask':
  z,g,k=map(int,a[1:])
  rows[z,g].add(tuple((k>>(7*i))&127 for i in range(g)))
def work(z,g,sp,raw,V):
 ms=(320,129)
 names=tuple(p for p in s.pts if (p&z and not p&449)or p in raw)
 groups=[(p,)for p in names]+[(-1-j,)for j in range(g)]
 edge=[(i,j)for i in range(len(groups))for j in range(len(names),len(groups))if i!=j]
 rn=tuple((i,p)for i,p in enumerate(names) if p in raw)
 pad=[0]*len(names);calls=0
 def rec(V):
  nonlocal calls
  calls+=1
  lo=[reduce(and_,v)for v in zip(*V)];hi=[reduce(or_,v)for v in zip(*V)]
  poss=[p for p in s.pts if p&449 and p not in names and any(not(s.F[p]&s.on[m])for m in lo)]
  pr=[(p,15)for p in names]+[(p,0)for p in poss]
  if not ce.actual(ms,pr,[pad+lo for _ in range(4)],edge,groups,sp,[pad+hi]+[pad+[95]*g for _ in range(3)],ordinary=(5,),rawnodes=rn,allowcost=(1,2,3)):return None
  if len(V)==1:return V[0]
  j,u=min(((j,u)for j in range(g)for u in s.effective if (hi[j]^lo[j])>>u&1),key=lambda ju:abs(len(V)-2*sum(v[ju[0]]>>ju[1]&1 for v in V)))
  l=[v for v in V if v[j]>>u&1];r=[v for v in V if not(v[j]>>u&1)]
  return rec(l)or rec(r)
 result=rec(V)
 return calls,result
if __name__=='__main__':
 z,g,sp=map(int,sys.argv[1:4]);V=sorted(rows[z,g]);n=len(V);print('COUNT',z,g,sp,n,flush=True)
 for raw in [()]+([(1,),(64,),(128,),(256,)]if sp else []):
  ans=work(z,g,sp-len(raw),raw,V);print('RESULT',raw,ans,flush=True)
