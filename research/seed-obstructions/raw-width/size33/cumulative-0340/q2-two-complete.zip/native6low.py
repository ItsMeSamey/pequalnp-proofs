from nativeext import *
for l in Path('six.out').read_text().splitlines():
 a=l.split()
 if a[0]!='done' or a[-1]=='0':continue
 z,g,sp=map(int,a[1:4])
 if g not in {0,1}:continue
 names=tuple(p for p in s.pts if z&p and not p&449)
 if g==1 and sp==1:continue
 print(z,g,sp,names,check(0,names,g,sp),flush=True)
