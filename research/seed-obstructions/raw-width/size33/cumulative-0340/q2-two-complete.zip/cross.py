from nativeext import *
for ns in ((128,),(128,256),(128,1024),(128,256,1024)):
 o=2; O=(1,5); cs=[s.dom((1<<20 if j&1 else 0)|(1<<21 if j&2 else 0)) for j in range(4)]
 masks=(320,129)
 qp={q:sum(1<<j for j,m in enumerate(masks) if m&q)for q in s.pts}
 pr=[(q,sum(1<<j for j in range(4) if j&qp[q]==qp[q])) for q in ns]+[(512,0)]
 hi=[[sum(1<<u for u in s.effective if not o>>u&1 and not(s.F[q]&cs[j]&s.tag[u]))for q in ns]for j in range(4)]
 res=extkw.actual(masks,pr,[[0]*len(ns)for j in range(4)],(),[(q,)for q in ns],0,hi,ordinary=O)
 print(ns,res,flush=True)
