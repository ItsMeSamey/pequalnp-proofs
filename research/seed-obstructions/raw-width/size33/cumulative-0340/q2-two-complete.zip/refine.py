from strictcut import *
from itertools import product
def branch(z,g,sp,raw,hh,upper=None):
 global calls
 calls=0
 if upper is None:upper=hh
 names=tuple(p for p in s.pts if (p&z and not p&449)or p in raw)
 ms=(320,129)
 opts=[]
 for mask in hh:
  opts.append([0]+[p for p in s.pts if p&449 and p not in raw and not s.F[p]&s.on[mask]])
 qp=lambda p:sum(1<<j for j,m in enumerate(ms) if m&p)
 cs=[s.dom(sum(1<<(20+j)for j in range(2)if k>>j&1))for k in range(4)]
 edge=tuple((i,j)for i in range(len(names)+g)for j in range(len(names),len(names)+g)if i!=j)
 rn=tuple((i,p) for i,p in enumerate(names)if p in raw)
 for B in product(*opts):
  if len(set(B)-{0})!=sum(bool(p)for p in B):continue
  pre=[0]*len(names);gs=[(p,)for p in names]+[(p if p else -10-i,)for i,p in enumerate(B)]
  pr=[(p,15)for p in names]+[(p,sum(1<<k for k in range(4)if k&qp(p)==qp(p)))for p in B if p]
  lo=[pre+list(hh) for k in range(4)]
  hi=[pre+list(upper)]+[pre+[sum(1<<u for u in s.effective if not p or not(s.F[p]&cs[k]&s.tag[u])) for p in B]for k in range(1,4)]
  if any(x&~y for lx,hx in zip(lo,hi)for x,y in zip(lx,hx)):continue
  def test(lo,hi):
   global calls
   calls+=1
   if calls>400:return "cutoff"
   if not ce.actual(ms,pr,lo,edge,gs,sp,hi,ordinary=(5,),rawnodes=rn,allowcost=(1,2,3)):return None
   if lo==hi:return lo
   k,i=next((k,i)for k in (3,1,2,0)for i in range(len(names),len(gs)) if lo[k][i]!=hi[k][i])
   delta=lo[k][i]^hi[k][i];bit=delta&-delta
   newlo=[t[:]for t in lo];newhi=[t[:]for t in hi]
   for j in range(4):
    if j&k==k:newlo[j][i]|=bit
    if j&k==j:newhi[j][i]&=~bit
   if all(not(x&~y)for lx,hx in zip(lo,newhi)for x,y in zip(lx,hx)):
    a=test(lo,newhi)
    if a is not None:return a
   if all(not(x&~y)for lx,hx in zip(newlo,hi)for x,y in zip(lx,hx)):
    return test(newlo,hi)
  hit=test(lo,hi)
  if hit is not None:return B,hit
 return None
if __name__=='__main__':
 z,g,sp=map(int,sys.argv[1:4]);hh=tuple(map(int,sys.argv[4:]));print(branch(z,g,sp,(),hh),calls)
