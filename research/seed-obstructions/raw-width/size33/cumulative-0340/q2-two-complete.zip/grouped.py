from special import *
def groupscan(z,g,sp,raw,V):
 calls=0
 def walk(V):
  nonlocal calls
  cols=tuple(zip(*V));lo=tuple(reduce(and_,v)for v in cols);hi=tuple(reduce(or_,v)for v in cols)
  calls+=1
  res=branch(z,g,sp,raw,lo,hi)
  if res is None:return None
  if len(V)==1:return V[0],res
  j,u=min(((j,u)for j in range(g)for u in s.effective if (hi[j]^lo[j])>>u&1),key=lambda ju:abs(len(V)-2*sum(v[ju[0]]>>ju[1]&1 for v in V)))
  return walk([v for v in V if v[j]>>u&1])or walk([v for v in V if not(v[j]>>u&1)])
 ans=walk(V);return calls,ans
if __name__=='__main__':
 z,g,sp,raw,start,stop=map(int,sys.argv[1:]);V=sorted(rows[z,g])[start:stop];print('KEY',z,g,sp,raw,start,stop,len(V),flush=True);print('DONE',groupscan(z,g,sp,((raw,)if raw else ()),V),flush=True)
