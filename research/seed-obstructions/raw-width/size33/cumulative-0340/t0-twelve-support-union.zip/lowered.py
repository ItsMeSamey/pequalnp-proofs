exec(open('maps.py').read().split("print('sym'")[0])
finite={8,18,106,171,116,125}
expanded={}
for C,i in t0.items():
 if i not in ids:continue
 for d in aut:
  image=tuple(sorted(tr(c,d) for c in C))
  if t0.get(image) in finite:
   expanded[i]=t0[image];break
print(sorted(expanded.items()))
assert set(expanded)=={8,18,106,108,112,114,116,125,155,164,169,171}
