from pathlib import Path
from itertools import combinations
from collections import Counter
import json
exec(Path('high-head-isomorphisms.py').read_text().split('for q in DEGREE_ONE:')[0])
ordinary=sum(pts);D=sum(DEGREE_ONE)
P2,N2=sample(2);h=neigh(P2);transport={}
for q in DEGREE_ONE:
 P,N=sample(q);hq=neigh(P);maps=[]
 for f in permutations(range(6)):
  m=[transform(x,f)for x in hq]
  if set(m)!=set(h):continue
  d=[h.index(x)for x in m]
  if {(transform(p,d),transform(l,f))for p,l in N}==N2:maps.append(d)
 assert len(maps)==6
 transport[q]=maps
A=[3<<j for j in range(6)];B=[(1<<(j+3))|(1<<((j+9)%13))for j in range(6)]
extra=dict(zip(A+B+[a|b for a,b in zip(A,B)],range(20,38)))
previous={(int(a[0]),int(a[1])):a[2]for l in Path('pair-frontier-534.log').read_text().splitlines()if len(a:=l.split())==3}
caps={():25,(9,):25,(20,):25,(9,20):25,(9,33):25,(9,130):25,(20,33):25}
count=Counter()
for l in Path('keys.jsonl').read_text().splitlines():
 i,t,E,R,C=json.loads(l)
 proofs=[]
 for q,u in DEGREE_ONE.items():
  tag=1<<(13+u);maps=transport[q]
  if R&q:continue
  mask=R|(127<<13)|sum(1<<extra[c]for c in C)
  high=sum(1<<extra[c]for c in C if c&q)
  low=(R&D)|tag|sum(1<<extra[c]for c in C if not c&(q|ordinary))
  assert not low&high and not (low|high)&~mask
  active=sorted({c&ordinary for c in C if not c&q and (c&ordinary).bit_count()>1})
  g=33-2*t-(low|high).bit_count()
  opts=[]
  for k in range(min(2,len(active))+1):
   for keep in combinations(active,k):
    orb=min(tuple(sorted(transform(sum(1<<j for j,x in enumerate(pts)if c&x),d)for c in keep))for d in maps)
    price=g+sum(c.bit_count()-1 for c in active if c not in keep)
    if price<=caps.get(orb,-1):opts.append((k,price,orb,keep))
  if not opts:continue
  PS=set();NS=set()
  for j,w in enumerate(rows):
   pos=bool(target>>j&1 and not seed>>j&1 and w&ordinary and not w&tag)
   neg=bool(not (target>>j&1) and w&q)
   if not pos and not neg:continue
   proj=(w&(ordinary|((127<<13)^tag)))|high|sum(1<<extra[c]for c in C if not c&q and w&ordinary&c)
   if pos:
    assert not w&mask&~proj and not w&sum(E)
    PS.add(w&(ordinary|((127<<13)^tag)))
   if neg:
    assert not (proj&mask&~w)
    NS.add(w&(ordinary|((127<<13)^tag)))
  assert (len(PS),len(NS))==(21,90)
  proofs.append((q,g,tuple(active),min(opts)))
 if not proofs:continue
 status='new' if previous[t,i]=='open' else 'prior'
 count[t,status]+=1
 print(t,i,status,proofs)
print('total',sorted(count.items()))
