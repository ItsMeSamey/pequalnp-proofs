import check as a
for key in (106,171):
    id_,t,E,R,selected=next(row for row in a.originals if row[0]==key)
    assert not t and not E and R==8191
    S,C=sorted(selected,key=int.bit_count)
    assert C&a.ordinary==S and S.bit_count()==2 and C.bit_count()==4
    anchors=[v for v in a.rare if C&v]
    assert len(anchors)==2
    for q,j in (anchors,anchors[::-1]):
        u=a.rare[q]
        assert not any((p&S) and t==u for p,t in a.pos)
        assert {(p,t) for p,t in a.pos if (p&C) and not (p&S)}=={(q,u),(j,a.rare[j])}
        assert all(not(t&u) for p,t in a.neg if p&q)
        assert not q&S and C&q
        def mask(p,t):
            return p|(t<<13)|(int(bool(p&S))<<20)|(int(bool(p&C))<<21)
        for p,t in a.pos:
            if t!=u:continue
            x=mask(p,t)
            assert any((x&~mask(pn,tn))==u<<13 for pn,tn in a.neg)
            if p==q:continue
            assert p&a.ordinary and not p&C
            assert any((pn&j) and (x&~mask(pn,tn))==u<<13 for pn,tn in a.neg)
        assert not any(p&q and t&u for p,t in a.neg)
        piv=[k for k in a.data if k[0]==key and k[1]==q]
        assert len(piv)==1 and piv[0][3]=={S}
        print('split',id_,q,j,u,'ordinary positives',[(p,t) for p,t in a.pos if t==u and not(p&q)])
