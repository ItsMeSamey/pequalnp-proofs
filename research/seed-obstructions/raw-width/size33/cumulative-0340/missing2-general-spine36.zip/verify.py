from pathlib import Path
from itertools import combinations
from collections import Counter
import json
exec(Path('high-head-isomorphisms.py').read_text().split('for q in DEGREE_ONE:')[0])
ordinary=sum(pts);D=sum(DEGREE_ONE)
P2,N2=sample(2);h=neigh(P2);transport={}
for q in DEGREE_ONE:
 P,N=sample(q);hq=neigh(P);maps=[]
 for f in permutations(range(6)):
  m=[transform(x,f)for x in hq]
  if set(m)!=set(h):continue
  d=[h.index(x)for x in m]
  if {(transform(p,d),transform(l,f))for p,l in N}==N2:maps.append(d)
 assert len(maps)==6
 transport[q]=maps
A=[3<<j for j in range(6)];B=[(1<<(j+3))|(1<<((j+9)%13))for j in range(6)]
extra=dict(zip(A+B+[a|b for a,b in zip(A,B)],range(20,38)))
roster=set(map(int,Path('t0-remaining-336.ids').read_text().split()))
splits=(3,6,258)
high=sum(1<<extra[x]for x in splits)
tag=1<<18
H=Counter()
for i,t,E,R,C in map(json.loads,Path('remaining.jsonl').read_text().splitlines()):
 if t or i not in roster or R&2:continue
 assert R==(8191^2) and not E and {c for c in C if c&2}==set(splits)
 keep=[c for c in C if not c&2]; assert all(c&ordinary for c in keep)
 mask=R|(127<<13)|sum(1<<extra[x]for x in C)
 low=(R&D)|tag
 assert (low|high).bit_count()==7 and not high&low
 PS,NS=set(),set(); m2=[]
 for j,w in enumerate(rows):
  pos=bool((target&~seed)>>j&1);neg=not(target>>j&1)
  if pos and w&2:m2.append(w&mask)
  for c in splits:
   a=c^2;v=1<<extra[c]
   if pos and not w&2:assert bool(a&w)==bool(v&w)
   if neg and a&w:assert v&w
  x=(w&(ordinary|((127<<13)^tag)))|high|sum(1<<extra[c]for c in keep if w&ordinary&c)
  if pos and w&ordinary and not w&tag:
   assert not(w&mask&~x);PS.add(w&(ordinary|((127<<13)^tag)))
  if neg and w&2:
   assert not(x&mask&~w);NS.add(w&(ordinary|((127<<13)^tag)))
 assert m2==[high|tag] and len(PS)==21 and len(NS)==90
 assert any(not(target>>j&1) and (m2[0]&~w)==tag for j,w in enumerate(rows))
 for c in keep:
  assert any(n&c&ordinary for n in NS)
 assert all(any(n&v for n in NS) for v in pts+[1<<(j+13) for j in range(7) if j!=5])
 active=sorted({c&ordinary for c in keep if (c&ordinary).bit_count()>1})
 orb=min(tuple(sorted(transform(sum(1<<j for j,v in enumerate(pts)if v&c),d)for c in active))for d in transport[2])
 assert orb in ((9,),(9,130))
 print(i,C,active,orb)
 H[orb]+=1
assert H=={(9,):28,(9,130):8}
print('complete',H)
