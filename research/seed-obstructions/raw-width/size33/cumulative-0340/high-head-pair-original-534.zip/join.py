from itertools import permutations
from pathlib import Path
exec(Path('high-head-isomorphisms.py').read_text().split('for q in DEGREE_ONE:')[0].replace("Path(__file__).with_name('L-meta-18968.json')","Path('L-meta-18968.json')"))

A,B=sample(2)
h=neigh(A); transports={}
for q in DEGREE_ONE:
    P,N=sample(q);g=neigh(P); ds=[]
    for f in permutations(range(6)):
        mapped=[transform(x,f) for x in g]
        if set(mapped)!=set(h):continue
        d=[h.index(x) for x in mapped]
        if {(transform(p,d),transform(l,f)) for p,l in N}==B:ds.append(d)
    assert len(ds)==6
    transports[q]=ds


from cuts import extra
import json
from collections import defaultdict
old=Path('.')
K0=set(map(int,(old/'t0-remaining-534.ids').read_text().split()))
K1=set(map(int,(old/'t1-remaining-60.ids').read_text().split()))
O=8191-sum(DEGREE_ONE)
out=defaultdict(list);pair=defaultdict(set)
for line in Path('remaining.jsonl').read_text().splitlines():
    i,t,E,R,C=json.loads(line)
    if t not in (0,1) or i not in (K0,K1)[t]:continue
    for q,u in DEGREE_ONE.items():
        if not R&q:continue
        pin=(R&sum(DEGREE_ONE))|1<<(13+u)|sum(1<<extra[c] for c in C if c&q or not c&O)
        g=32-2*t-pin.bit_count()
        active=sorted({c&O for c in C if not c&q and (c&O).bit_count()>1})
        canon={c:min(transform(sum(1<<j for j,x in enumerate(pts) if c&x),d) for d in transports[q]) for c in active}
        for cp in __import__('itertools').combinations(active,2):
            if g+sum(c.bit_count()-1 for c in active if c not in cp)>25:continue
            masks=[sum(1<<j for j,x in enumerate(pts) if c&x) for c in cp]
            orbit=min(tuple(sorted(transform(m,d)for m in masks)) for d in transports[q])
            pair[t,orbit].add(i)
        for kept in [0]+active:
            if kept and canon[kept] not in (9,20):continue
            price=g+sum(c.bit_count()-1 for c in active if c!=kept)
            if price<=25:out[t,i].append((price,q,kept,canon.get(kept,0),tuple(active)))

for t,K in enumerate((K0,K1)):
    sectors={o:ids for (j,o),ids in pair.items() if j==t}
    covered=set.union(set(),*sectors.values())
    print(t,len(K),len(covered),sorted((o,len(v)) for o,v in sectors.items()))
    for i in sorted(K):
        print(t,i,','.join('-'.join(map(str,o)) for o in sorted(sectors) if i in sectors[o]) or 'open')
