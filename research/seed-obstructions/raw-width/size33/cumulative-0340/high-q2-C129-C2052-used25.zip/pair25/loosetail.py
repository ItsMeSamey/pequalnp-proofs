from nativecross import *
import compound_ext as ce
from functools import reduce
from operator import and_,or_
from collections import defaultdict
cc=(129,2052); end=2181
def work(z,g,records,sp,T):
 named=tuple(p for p in s.pts if p&z and (not p&end or p in T))
 H=4; gs=[(p,)for p in named]+[(-1-j,)for j in range(g)]
 E=[(i,j) for i in range(len(gs))for j in range(len(named),len(gs))if i!=j]
 cs=[s.dom(sum(1<<(20+a)for a in range(2)if t>>a&1)) for t in range(H)]
 F=s.F
 upper=[[sum(1<<u for u in s.effective if p not in T and not F[p]&s.tag[u]&cs[t])for p in named] for t in range(H)]
 assert not any(upper[0])
 def walk(V):
  global nodes
  cols=list(zip(*V));lo=[reduce(and_,c)for c in cols];hi=[reduce(or_,c)for c in cols]
  poss=[p for p in s.pts if p not in named and (any(not F[p]&s.on[m] for m in lo)or any(not(s.no[q,p])for q in named))]
  pr=[(p,15)for p in named]+[(p,0)for p in poss];nodes+=1
  lows=[[0]*len(named)+lo for _ in range(4)]
  highs=[upper[t]+(hi if not t else [95]*g)for t in range(4)]
  if not ce.actual(cc,pr,lows,E,gs,sp,highs,ordinary=(5,),allowcost=(1,2,3),rawnodes=tuple((idx,p)for idx,p in enumerate(named)if p in T)):return []
  if len(V)==1:return V
  j,u=min(((j,u)for j in range(g)for u in s.effective if (hi[j]^lo[j])&(1<<u)),key=lambda ju:abs(len(V)-2*sum(x[ju[0]]>>ju[1]&1 for x in V)))
  a=[v for v in V if v[j]>>u&1];b=[v for v in V if not v[j]>>u&1];return walk(a)+walk(b)
 return walk(records)
if __name__=='__main__':
 masks=defaultdict(set)
 for l in Path('tagmasks.log').read_text().splitlines():
  a=l.split()
  if a[0]=='mask':
   z,g,k=map(int,a[1:]);masks[z,g].add(tuple(k>>(7*i)&127 for i in range(g)))
 for (z,g),V in sorted(masks.items()):
  left=3-g-(z&~end).bit_count()
  if left<=0 or (z==2181 and g in (1,2)):continue
  for n in range(left+1):
   for T in combinations((1,4,128,2048),n):
    nodes=0;live=work(z,g,sorted(V),left-n,T)
    print(z,g,T,len(V),nodes,len(live),live[:2],flush=True)
