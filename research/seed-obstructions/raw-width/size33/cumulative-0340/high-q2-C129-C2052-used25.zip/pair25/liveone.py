from nativecross import *
import compound_ext as ce
from itertools import product
cc=(129,2052);cs=[s.dom(sum(1<<(20+a)for a in range(2)if t>>a&1))for t in range(4)]
F=s.F;U=95
def calc(named,T,mask,sp):
 n=len(named); anon=n
 Ex=[p for p in s.pts if p not in named and any(not s.no[q,p] for q in named if q not in T)]
 un=[[sum(1<<u for u in s.effective if p not in T and not F[p]&s.tag[u]&cs[t])for p in named]for t in range(4)]
 qs=[p for p in s.pts if p not in named and not F[p]&s.on[mask]]
 edges=[(h,anon)for h in range(n)]
 raw=tuple((i,p)for i,p in enumerate(named)if p in T)
 for k in range(len(qs)+1):
  for B in combinations(qs,k):
   if any(F[p]&s.domq[q]or F[q]&s.domq[p]for p,q in combinations(B,2)):continue
   gr=[(p,)for p in named]+[B or (-1,)]
   def pstate(p):return (int(bool(p&129))|2*bool(p&2052))
   pr=[(p,sum(1<<t for t in range(4)if pstate(p)&~t==0))for p in (*named,*B)]
   pr.extend((p,0)for p in Ex if p not in dict(pr))
   hi=[sum(1<<u for u in s.effective if not any(F[p]&s.tag[u]&cs[t] for p in B))for t in range(4)]
   hi[0]=mask
   def test(lo,hi):
    if any(l&~h for l,h in zip(lo,hi)):return False
    if not ce.actual(cc,pr,[[0]*n+[l]for l in lo],edges,gr,sp,[un[t]+[h]for t,h in enumerate(hi)],ordinary=(5,),allowcost=(1,2,3),rawnodes=raw):return False
    if lo==hi:return True
    t=next(t for t in range(4)if lo[t]!=hi[t]);v=(hi[t]^lo[t])&-(hi[t]^lo[t])
    return test([x|v if t&~a==0 else x for a,x in enumerate(lo)],hi) or test(lo,[x&~v if a&~t==0 else x for a,x in enumerate(hi)])
   if test([mask]*4,hi):return B,mask
 return False
if __name__=='__main__':print(calc((512,1024),(),64,0))
