from loose import *
import loose
V=set()
for l in Path('tagmasks.log').read_text().splitlines():
 a=l.split()
 if a[:3]==['mask','2181','2']:
  k=int(a[3]);V.add((k&127,k>>7&127))
V=sorted(V)
import sys
for x in map(int,sys.argv[1:]):
 T=(x,)if x else ();sp=1-len(T)
 for i in range(0,len(V),25):
  loose.nodes=0;alive=work(2181,2,V[i:i+25],sp,T);print(x,i,len(V[i:i+25]),loose.nodes,len(alive),alive,flush=True)
