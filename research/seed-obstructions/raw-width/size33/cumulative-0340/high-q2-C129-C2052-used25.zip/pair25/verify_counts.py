from pathlib import Path
from itertools import combinations
from collections import defaultdict
from ast import literal_eval
import re
def rows(f):return Path(f).read_text().splitlines()
M=defaultdict(set)
for line in rows('tagmasks.log'):
 a=line.split()
 if a[0]=='mask':
  z,g,k=map(int,a[1:]);M[z,g].add(tuple((k>>(7*i))&127 for i in range(g)))
Z0=1|4|128|2048
tight={};loose={};last={}
for z,g in M:
 n=3-g-(z&~Z0).bit_count();assert n>=0 and (z&Z0)==Z0
 if n==0:tight[z,g]=len(M[z,g])
 else:
  for a in range(n+1):
   for T in combinations((1,4,128,2048),a):loose[z,g,T]=len(M[z,g])
for line in rows('tight.log')+rows('triple.log'):
 a=line.split(maxsplit=5);z,g,n,_,k=map(int,a[:5]);assert n==tight.pop((z,g))
 if k:assert (z,g,k,literal_eval(a[5]))==(3717,1,1,[(64,)]) and rows('liveone.log')==['False']
assert not tight
for line in rows('loose.log')+rows('loose-tail.log'):
 m=re.fullmatch(r'(\d+) (\d+) (\(.*?\)) (\d+) \d+ 0 \[\]',line)
 z,g,n=map(int,[m[1],m[2],m[4]]);assert loose.pop((z,g,literal_eval(m[3])))==n
for line in rows('last.log'):
 a=line.split();x,start,n,nodes,k=map(int,a[:5]);assert k==0
 assert start==last.get(x,0);last[x]=start+n
for x,n in last.items():assert loose.pop((2181,2,(x,) if x else ()))==n
assert not loose
print('all signed mask records covered',len(M),sum(map(len,M.values())))
