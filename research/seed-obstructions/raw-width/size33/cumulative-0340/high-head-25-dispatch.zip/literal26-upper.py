from pathlib import Path
exec(Path('high-head-isomorphisms.py').read_text().split('for q in DEGREE_ONE:')[0].replace("Path(__file__).with_name('L-meta-18968.json')","Path('L-meta-18968.json')"))
P,N=sample(2)
gates=[]
def emit(kind,x,y):
    gates.append((kind,x,y))
    return 14+len(gates)
def join(xs):
    z=xs[0]
    for x in xs[1:]:z=emit('OR',z,x)
    return z
stars=[]
for j in range(6):
    p=sorted(m.bit_length()-1 for m,v in P if v==1<<j)
    stars.append(emit('AND',9+j,join(p)))
out=join(stars)
assert len(gates)==26 and out==40
for p,v in P|N:
    X=[bool(p>>i&1) for i in range(9)]+[bool(v>>i&1)for i in range(6)]
    for op,a,b in gates:X.append(X[a] and X[b] if op=='AND' else X[a] or X[b])
    assert X[out]==((p,v) in P)
print('INPUTS',pts,'line IDs',list(j for j in range(7) if j!=5))
for i,gate in enumerate(gates,15):print(i,*gate)
print('PASS',len(gates),len(P),len(N))
