from itertools import permutations
from pathlib import Path
exec(Path('high-head-isomorphisms.py').read_text().split('for q in DEGREE_ONE:')[0].replace("Path(__file__).with_name('L-meta-18968.json')","Path('L-meta-18968.json')"))

A,B=sample(2)
h=neigh(A); transports={}
for q in DEGREE_ONE:
    P,N=sample(q);g=neigh(P); ds=[]
    for f in permutations(range(6)):
        mapped=[transform(x,f) for x in g]
        if set(mapped)!=set(h):continue
        d=[h.index(x) for x in mapped]
        if {(transform(p,d),transform(l,f)) for p,l in N}==B:ds.append(d)
    assert len(ds)==6
    transports[q]=ds


from cuts import extra
import json
from collections import defaultdict
old=Path('.')
K0=set(map(int,(old/'t0-remaining-2380.ids').read_text().split()))
K1=set(map(int,(old/'t1-remaining-130.ids').read_text().split()))
O=8191-sum(DEGREE_ONE)
out=defaultdict(list)
for line in Path('remaining.jsonl').read_text().splitlines():
    i,t,E,R,C=json.loads(line)
    if t not in (0,1) or i not in (K0,K1)[t]:continue
    for q,u in DEGREE_ONE.items():
        if not R&q:continue
        pin=(R&sum(DEGREE_ONE))|1<<(13+u)|sum(1<<extra[c] for c in C if c&q or not c&O)
        g=32-2*t-pin.bit_count()
        active=sorted({c&O for c in C if not c&q and (c&O).bit_count()>1})
        canon={c:min(transform(sum(1<<j for j,x in enumerate(pts) if c&x),d) for d in transports[q]) for c in active}
        for kept in [0]+active:
            if kept and canon[kept] not in (9,20):continue
            price=g+sum(c.bit_count()-1 for c in active if c!=kept)
            if price<=25:out[t,i].append((price,q,kept,canon.get(kept,0),tuple(active)))
with open('high-head-complete25.tsv','w')as f:
 for (t,i),v in sorted(out.items()):print(t,i,*min(v),sep='\t',file=f)
print('GROSS',*[sum(k==t for k,i in out) for t in (0,1)])
for t,n in [(0,2836),(1,6083)]:
 c=set(map(int,(old/f't{t}-signed-{n}.ids').read_text().split()))
 print('NEW',t,n,len({i for (k,i) in out if k==t}-c))
