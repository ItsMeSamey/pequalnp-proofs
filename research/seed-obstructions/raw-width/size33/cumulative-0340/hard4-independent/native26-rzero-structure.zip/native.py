from cuts import load,DEGREE_ONE,extra
from itertools import combinations
comp=(129,4160)
P0,N0=load(())
orig={t:sum({a&8191 for a in P0 if a>>(13+t)&1}) for t in range(7)}
assert all(s.bit_count()==4 for s in orig.values())
assert all((c&s).bit_count()<=1 for c in comp for s in orig.values())
D=sum(DEGREE_ONE)
for e in DEGREE_ONE:
 P0,N0=load((e,))
 for q,u in DEGREE_ONE.items():
  if e==q:continue
  W=(8191^D)|((127^(1<<u))<<13)|sum(1<<extra[c] for c in comp)
  P={a&W for a in P0 if not a&D and not a>>(13+u)&1}
  N={n&W for n in N0 if n&q};pts=sorted({a&8191 for a in P});tags=[t for t in range(7) if t!=u]
  pp={p:p|sum(1<<extra[c] for c in comp if p&c) for p in pts}
  for a in P|N:
   assert all(bool(a>>extra[c]&1)==bool(a&c) for c in comp)
  star={t:sum(p for p in pts if pp[p]|(1<<(13+t)) in P) for t in tags}
  assert sum((orig[t]^star[t]).bit_count()for t in tags)==3
  assert all((orig[t]&star[t])==star[t] and not((orig[t]^star[t])&~D)for t in tags)
  assert all((s&v).bit_count()==1 for s,v in combinations(star.values(),2))
  dom=lambda x,n:not x&~n
  for p in pts:
   assert any(dom(pp[p],n) for n in N)
   for t in tags:
    assert any(dom(pp[p]|pp[r],n)for r in pts if star[t]&r for n in N)
    if p&star[t]:continue
    for v in tags:
     if v==t:continue
     assert any(dom(pp[p]|pp[r]|(1<<(13+t)),n)for r in pts if star[v]&r for n in N)
  print(e,q,len(P),len(N),sorted(star.values()))
