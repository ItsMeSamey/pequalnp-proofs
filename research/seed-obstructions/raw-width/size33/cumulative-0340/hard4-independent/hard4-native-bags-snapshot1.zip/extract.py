from ast import literal_eval
from pathlib import Path
from itertools import combinations
def remaining(bank,o):
 records=set()
 for l in Path('price5-'+bank+'.log').read_text().splitlines():
  if not l.startswith(str(o)+' '):continue
  a,cs=literal_eval(l.split(') ',1)[1].split(' ',1)[1])
  assert a is False
  for mark,sp in cs:
   nm=sorted(x for x in mark if x>0)
   for k in range(len(nm)+1):
    for ns in combinations(nm,k):
     for g in range(1+sum(x<0 for x in mark)):
      for v in range(sp+1):records.add((ns,g,v))
 items=sorted(records)
 certified=set()
 for f in Path('.').glob('s5-'+bank+'-'+str(o)+'*.log'):
  lines=f.read_text().splitlines()
  for k,l in zip(lines,lines[1:]):
   if k.startswith(f'KEY {o} ') and l.startswith('OUT '):
    j=int(k.split()[2]); tup,g,v=items[j]; assert k==f'KEY {o} {j} {tup} {g} {v}'
    if literal_eval(l[4:])[-1] is None:certified.add(j)
 early=Path('r5-'+bank+'.log').read_text().splitlines()
 allg={int(l.split()[1]) for l in Path('price5-'+bank+'.log').read_text().splitlines() if l.startswith(str(o)+' ')}
 zero={int(l.split()[1])for l in early if l.startswith(str(o)+' ') and l.endswith('live []')}
 return bool(set(range(len(items)))-certified) and not allg<=zero
allbanks=['129,2052','129,320','320,513']
avail={b:[1<<i for i in (0,1,2,3,4,6) if remaining(b,1<<i)]for b in allbanks}
print('canonical',avail)
s=Path('transport.py').read_text().replace('mapped.append(tuple(mp(x)for x in (129,4160)))','mapped.append((tuple(mp(x)for x in (129,4160)),tuple(sorted(tf.items()))))')
s=s[:s.index('  for L in ((0,)')]+'''
  bank,ts=next((k,min(f for v,f in mapped if set(v)==set(k)))for k in keys if len(k)==2 and any(set(v)==set(k)for v,f in mapped))
  key=','.join(map(str,bank));allowed[e,q]=sorted(t for t,i in ts if 1<<i in avail[key]); print('pivot',e,q,key,allowed[e,q])
'''
allowed={};exec(s)
from itertools import product
import json
ids={2:4243,8:6184,16:8204,32:10224};ledger={}
for e in DEGREE_ONE:
 Q=[q for q in DEGREE_ONE if q!=e]; U=[DEGREE_ONE[q]for q in Q]
 r6={w:list(product(*[([None,*allowed[e,q]] if u==w else ([w]if w in allowed[e,q]else []))for q,u in zip(Q,U)]))for w in range(7)}
 r7=[a for a in product(*[[None,*allowed[e,q]]for q in Q]) if len(set(x for x in a if x!=None))==sum(x!=None for x in a)]
 ledger[ids[e]]=dict(Q=Q,U=U,r6=r6,r7=r7)
 print('origin',ids[e],Q,'r6',[(w,len(a))for w,a in r6.items()if a],'r7',len(r7))
Path('join.json').write_text(json.dumps(ledger))
prior=json.loads(Path('original-r6.json').read_text())
for i,j in ledger.items():
 live={w:len(a) for w,a in j['r6'].items() if a and w in prior[str(i)]}
 print('r6-intersection',i,live)
