from cuts import load,DEGREE_ONE
from sample import samples
from itertools import permutations,combinations
from pathlib import Path
D=sum(DEGREE_ONE);pts=[1<<i for i in range(13)if (1<<i)&(8191^D)]
raw,seed,tgt=samples(Path('L-meta-18968.json'))
wanttags=tuple(t for t in range(7)if t!=5)
def pairs(P):
 return {p:tuple(t for t in range(7)if p|1<<(t+13) in P) for p in pts}
def mx(S):return frozenset(x for x in S if not any(x!=y and not(x&~y) for y in S))
W=(8191^D)|((127^32)<<13)
cp={r&W for i,r in enumerate(raw)if tgt>>i&1 and not seed>>i&1 and r&(8191^D) and not(r>>18&1)}
cn=mx({r&W for i,r in enumerate(raw)if not tgt>>i&1 and r&2})
can=pairs(cp);inv={vs:p for p,vs in can.items()}
keys=[(129,),(320,),(129,320),(129,2052),(320,513)]
for e in DEGREE_ONE:
 P0,N0=load((e,))
 for q,u in DEGREE_ONE.items():
  if q==e:continue
  U=127^(1<<u);W=(8191^D)|(U<<13)
  P={a&W for a in P0 if not a&D and not a>>(13+u)&1}
  N=mx({a&W for a in N0 if a&q});g=pairs(P);mapped=[]
  for order in permutations(wanttags):
   tf=dict(zip([i for i in range(7)if U>>i&1],order))
   df={p:inv.get(tuple(sorted(tf[t]for t in vs))) for p,vs in g.items()}
   if None in df.values():continue
   def mp(n):return sum(b for p,b in df.items()if p&n)
   tr=lambda n:mp(n)|sum(1<<(13+tf[t])for t in tf if n>>(13+t)&1)
   if frozenset(tr(n)for n in N)==cn:mapped.append(tuple(mp(x)for x in (129,4160)))
  for L in ((0,),(1,),(0,1)):
   dest=next((k for k in keys if any(set(k)=={ds[i]for i in L} for ds in mapped)),None)
   assert dest
   print(e,q,tuple((129,4160)[i]for i in L),dest)
