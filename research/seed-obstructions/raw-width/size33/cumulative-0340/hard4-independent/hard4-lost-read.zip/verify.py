from pathlib import Path
import json
from sample import samples
rows,seed,target=samples(Path('L-meta-18968.json'))
tags={2:5,8:1,16:2,32:3}; ids={4243,6184,8204,10224}; checked=set()
for line in Path('remaining.jsonl').read_text().splitlines():
 i,t,E,R,C=json.loads(line)
 if i not in ids:continue
 assert t==1 and len(E)==1 and C==[129,4160]
 long=[(1<<(j+3))|(1<<((j+9)%13)) for j in range(6)]
 mask=R|(127<<13)|sum(1<<(26+long.index(c)) for c in C)
 for q,u in tags.items():
  if q in E:continue
  U=1<<(13+u)
  j,=[j for j,w in enumerate(rows) if (target&~seed)>>j&1 and w&q]
  assert rows[j]&mask==q|U
  dark=[k for k,w in enumerate(rows) if not(target>>k&1) and w&q]
  assert dark and any(rows[k]&U and not rows[k]&q for k in range(len(rows)) if not(target>>k&1))
  assert all((rows[j]&mask&~U)&~rows[k]==0 for k in dark)
  print(i,q,u,j,len(dark),dark[0]);checked.add((i,q))
assert len(checked)==12
