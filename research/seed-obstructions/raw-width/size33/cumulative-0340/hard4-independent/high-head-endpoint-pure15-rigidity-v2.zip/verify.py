from pathlib import Path
import subprocess as sp,sys
sp.run([sys.executable,'intervals.py'],check=True)
sp.run(['g++','-std=c++17','-O2','interval.cpp','-o','interval'],check=True)
for q,n in [(2,568),(8,564),(16,564),(32,564)]:
 inp=Path(f'i{q}.in').read_bytes()
 out=sp.run(['./interval'],input=inp,stdout=sp.PIPE,stderr=sp.PIPE,check=True)
 assert len(inp.splitlines())==n and out.stdout==b'' and out.stderr==f'done {n}\n'.encode()
 print(q,n,0,flush=True)
