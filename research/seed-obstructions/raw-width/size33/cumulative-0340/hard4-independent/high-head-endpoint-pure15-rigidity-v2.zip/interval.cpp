#include <algorithm>
#include <array>
#include <bitset>
#include <iostream>
#include <vector>
using namespace std;
using B=bitset<512>;
int t[6],c[6],e[6][2],v[9],h[9],nv,A;
B raw,allowed,slots[9];int idn;
vector<int> vals(B s){vector<int>v;for(size_t i=s._Find_first();i<512;i=s._Find_next(i))v.push_back(i);return v;}
B ops(B s){B b;auto v=vals(s);for(int i=0;i<(int)v.size();i++)for(int j=0;j<i;j++){b[v[i]|v[j]]=1;b[v[i]&v[j]]=1;}b[0]=0;return b&~s;}
B close(B b){for(;;){B n=b|(allowed&ops(b));
for(int j=0;j<6;j++){if(b[c[j]])n[t[j]]=1;if(n[c[j]])continue;
B l=b&slots[e[j][0]],r=b&slots[e[j][1]];for(int a:vals(l)){for(int d:vals(r))if((a&d)==c[j]){n[c[j]]=1;break;}if(n[c[j]])break;}}
if(n==b)return b;b=n;}}
bool ok(B s){for(int j=0;j<6;j++)if(!s[t[j]])return false;return true;}
int main(){for(int i=0;i<9;i++)raw[1<<i]=1;raw[9]=raw[260]=1;
while(cin>>A>>nv){++idn;for(int&i:t)cin>>i;for(int&i:c)cin>>i;for(auto&p:e)cin>>p[0]>>p[1];for(int i=0;i<nv;i++)cin>>v[i];for(int i=0;i<nv;i++)cin>>h[i];
allowed.reset();for(int i=0;i<nv;i++){slots[i].reset();for(int x=1;x<512;x++)if((x&v[i])==v[i]&&(x&h[i])==x&&find(t,t+6,x)==t+6&&find(c,c+6,x)==c+6)slots[i][x]=1;allowed|=slots[i];}
bool live=false;for(int x:vals(ops(raw))){B a=raw;a[x]=1;B b=close(a);if(ok(b)){live=true;break;}if(A==2)for(int y:vals(ops(b))){B d=b;d[y]=1;if(ok(close(d))){live=true;break;}}if(live)break;}if(live)cout<<idn<<" "<<A<<" "<<nv<<"\n";}
cerr<<"done "<<idn<<"\n";}
