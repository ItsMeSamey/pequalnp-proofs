from pathlib import Path
import graphs2 as G
exec(Path("high-head-isomorphisms.py").read_text().split("for q in DEGREE_ONE:")[0])
import sys
def graph_rows(q):
 P,_=sample(q);G.stars=stars=tuple(sum(p for p,l in P if l==1<<j)for j in range(6))
 extras={sum(1<<i for i,p in enumerate(pts) if p&v) for v in (129,4160)}
 assert extras=={9,260} and (len(P),len(_))==(21,90)
 for j,t in enumerate(stars):
  assert all((x&t).bit_count()<=1 for x in extras)
  assert all(any(n>>i&1 and l>>j&1 for n,l in _) for i in range(9) if not t>>i&1)
  assert all(not(n&t) or not(l>>j&1) for n,l in _)
 for C,V,E in G.cases():
  hi=[511]*len(V)
  for t,(a,b)in zip(C,E):
   hi[a]&=511^(V[b]&~t);hi[b]&=511^(V[a]&~t)
  A=9-len(V)-sum(c!=t for c,t in zip(C,stars))
  assert 1<=A<=2
  yield [A,len(V),*stars,*C,*sum(E,()),*V,*hi]
if __name__=='__main__':
 for q in (2,8,16,32):
  with open('i'+str(q)+'.in','w')as f:
   for row in graph_rows(q):print(*row,file=f)
