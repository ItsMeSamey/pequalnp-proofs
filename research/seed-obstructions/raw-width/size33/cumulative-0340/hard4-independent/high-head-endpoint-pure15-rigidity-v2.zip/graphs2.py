from itertools import combinations,product
from collections import Counter
stars=(46,88,176,352,197,275)
def graphs(C):
 r=sum(a!=b for a,b in zip(C,stars)); lim=8-r
 def walk(i,vs,edges):
  if i==6:
   yield tuple(vs),tuple(edges);return
  k=len(vs); t=C[i]
  for a in range(k+1):
   for b in range(a+1,min(lim,k+1+(a==k))):
    v=vs+[0]*max(0,b+1-k);v[a]|=t;v[b]|=t
    ed=edges+[(a,b)]
    if any(v[x]&v[y]!=C[j] for j,(x,y) in enumerate(ed)):continue
    yield from walk(i+1,v,ed)
 yield from walk(0,[],[])
def cases():
 for C in product(*[[t]+([t^(1<<i)for i in range(9)if t>>i&1] if t.bit_count()==4 else []) for t in stars]):
  r=sum(a!=b for a,b in zip(C,stars))
  for v,e in graphs(C):
   # At the first parent all prior gates are unmarked nonparents.
   if 9-r-len(v)<1:continue
   yield C,v,e
if __name__=='__main__':print(Counter((sum(a!=b for a,b in zip(C,stars)),len(v))for C,v,e in cases()))
