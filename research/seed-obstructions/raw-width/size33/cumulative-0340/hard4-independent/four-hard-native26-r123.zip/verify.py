import os,sys,subprocess
from pathlib import Path
env=dict(os.environ)
for bank in ('129,2052','129,320','320,513','129','320'):
 env['BANK']=bank
 got=subprocess.check_output([sys.executable,'nativeext.py','1','2','3'],env=env,text=True)
 assert got+'EXIT 0\n'==Path(bank+'.log').read_text()
 assert all(l.endswith('live []')for l in got.splitlines())
out=subprocess.check_output([sys.executable,'transport.py'],text=True)
assert out==Path('transport.log').read_text() and len(out.splitlines())==36
print('Five native used banks; ranks 1-3 excluded; 36 signed transfers.')
