import json,sys
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path('../t0-tight').resolve()))
from cuts import load,DEGREE_ONE
P,N=load(());S=json.load(open('tight.json'));A=json.load(open('cases.json'));v=Counter();Q={}
for i,(e,r,C,a,b)in A.items():
 if r!=8191:continue
 ql=[]
 for q,hi,other,x in S[i]:
  if not x or len(hi)!=1:continue
  c,=hi;p=c^q;u=1<<(13+DEGREE_ONE[q])
  inc=any(s&p and s&u for s in P)
  v[q,c,p,inc]+=1
  ql.append((q,c,p,int(inc)))
 Q[i]=ql
print(v)
open('meet.json','w').write(json.dumps(Q))
