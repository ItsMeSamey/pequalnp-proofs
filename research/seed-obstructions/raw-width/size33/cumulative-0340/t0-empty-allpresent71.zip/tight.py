import json
from collections import Counter
D=(2,8,16,32);PT=8191^sum(D);rows=json.load(open('cases.json'));holds={};H=Counter()
for i,(E,R,C,a,b)in rows.items():
 T=[]
 for q in D:
  if not R&q:continue
  high=[c for c in C if c&q]; other=[c for c in C if not c&q and not c&PT]
  cap=31-sum(bool(R&d)for d in D)-len(high)-len(other)
  if cap!=26:continue
  eligible=not other and all(c&PT and c&q and (c&PT).bit_count()==1 and R&c&PT for c in high)
  T.append((q,high,other,eligible))
 H[b,len(T),sum(e for *_,e in T)]+=1
 holds[i]=T
print('tight incidence',sum(map(len,holds.values())),'eligible',sum(e for T in holds.values() for *_,e in T),'eligible bank',sum(any(e for *_,e in T)for T in holds.values()),'mixed',sorted(H.items()))
open('tight.json','w').write(json.dumps(holds))
