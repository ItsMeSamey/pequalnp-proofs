import json,sys
from pathlib import Path
sys.path.insert(0,str(Path('../t0-tight').resolve()))
from cuts import load,DEGREE_ONE,extra
P,N=load(());cases=json.load(open('cases.json'));T=json.load(open('meet.json'));keep={}
for i,sc in T.items():
 if not sc:continue
 e,R,C,a,b=cases[i];assert R==8191 and b==29 and i!='0'
 bank=R|(127<<13)|sum(1<<extra[c]for c in C)
 for q,c,p,overlap in sc:
  u=1<<(13+DEGREE_ONE[q]);X=next(x for x in P if x&q)
  assert not overlap and all(not x&u or not x&p for x in P)
  assert not any(not n&(1<<extra[c]) and n&p for n in N)
  assert all(not x&(1<<extra[c]) or x&(p|q) for x in P)
  assert X&bank==q|u|1<<extra[c]
  rs=[x for x in P if (x&8191)not in DEGREE_ONE and x&u]
  assert rs
  for x in rs:
   assert any(not ((x&bank&~u)&~n)and not n&u for n in N)
 keep[int(i)]=sc
assert len(keep)==71
print('banks',len(keep),'pivots',sum(map(len,keep.values())))
Path('b29.ids').write_text(''.join(f'{i}\n'for i in sorted(keep)))
