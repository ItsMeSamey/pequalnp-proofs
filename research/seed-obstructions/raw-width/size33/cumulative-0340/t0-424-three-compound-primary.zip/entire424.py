"""Reconcile the sealed original-key hierarchy and the six disjoint double-endpoint strata."""
from zipfile import ZipFile
from pathlib import Path
from ast import literal_eval
from hashlib import sha256
import json
sources=Path('sources')
base='t0-264-owner-hierarchy.zip';rep='s29-three-compound16.zip';one='s29-three-double-raw1-sixteen.zip';p64='s29-three-double-raw64.zip';p4='s29-three-double-raw4-final.zip';p1024='s29-three-double-raw1024-0123.zip';others='s29-three-double-other-12cells.zip';unw='s29-three-double-unweighted-0123.zip'
def member(arc,n):
 with ZipFile(sources/arc)as z:return z.read(n).decode()
keys=literal_eval(member(rep,'allkeys.txt'));groups={base:[],rep:[],one:[],p64:[],p4:[],p1024:[],others:[],unw:[]}
def group(c,w):
 if not {129,4160}<=set(c):return base
 if not w:return unw
 (p,n),=w;assert n==2
 if p in c:return rep
 return {1:one,4:p4,64:p64,1024:p1024,256:others,512:others,2048:others}[p]
rows=[]
for c,w,ids in keys:
 n=group(c,w);groups[n].extend(ids)
 for i in ids:rows.append((i,c,w,n))
assert len(rows)==len({i for i,*v in rows})==424
assert [len(groups[n])for n in (base,rep,one,p64,p4,p1024,others,unw)]==[264,16,16,16,32,16,48,16]
assert set(map(int,member(base,'originals.ids').split()))==set(groups[base])
for n in [p4,p64,p1024,others,unw]:
 assert set(map(int,member(n,'COVERAGE.txt').split()))==set(groups[n])
for c,w,ids in keys:
 if group(c,w)!=one:continue
 i=(354,523,1046,2092).index(c[1])
 if i==0:
  assert all('False'in member(one,f'un-0-1-{m}.log')for m in (0,1))
  for s in ['esc0-1-2.log','lex0-1-3.log']:assert member(one,s).strip().endswith('False')
 else:
  for m in (1,2,3):assert member(one,f'lex{i}-1-{m}.log').strip().endswith('False')
print('exact original IDs',len(rows),'subtotals',[(n,len(v))for n,v in groups.items()])
Path('originals424.jsonl').write_text(''.join(json.dumps(dict(original=i,compounds=c,reads=w,primary=n))+'\n' for i,c,w,n in sorted(rows)))
