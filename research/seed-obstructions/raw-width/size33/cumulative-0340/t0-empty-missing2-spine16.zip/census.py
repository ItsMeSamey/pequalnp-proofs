from pathlib import Path
from collections import Counter
import json,gzip
D=Path(__file__).resolve().parent.parent
signed=set(map(int,Path('/workspace/scratch/threshold-assembly-review/cumulative-0340/t0-signed-3472.ids').read_text().split()))
out={}
with gzip.open(D/'t0-29/terminal-raw-keys.jsonl.gz','rt')as f:
 for i,l in enumerate(f):
  t,E,R,C,raw,a,b,old=json.loads(l)
  if t!=0 or i in signed or old or any(p and p.bit_count()>1 for p in a):continue
  out[i]=(E,R,C,a,b)
print('count',len(out),'strata',Counter((b,len(C),tuple(sorted(Counter(a).values())))for E,R,C,a,b in out.values()))
Path('cases.json').write_text(json.dumps(out))
