import json
from pathlib import Path
import sys
D=Path('../t0-tight').resolve();sys.path.insert(0,str(D))
from cuts import load,extra,DEGREE_ONE
P,N=load(());A=json.load(open('cases.json'))
case=[]
for i,(E,R,C,a,b)in A.items():
 if b!=30:continue
 assert R==8189 and {3,6,258}<=set(C) and not set(a)-{1,4,64,128,256,512,1024,2048,4096}
 bank=R|(127<<13)|sum(1<<extra[c]for c in C)
 active=next(p for p in P if p&2)&bank
 piv={1<<18,*[1<<extra[c]for c in (3,6,258)]}
 assert active==sum(piv)
 assert any(not (active&~(1<<18))&~n and not n&(1<<18)for n in N)
 assert all(not(p&v and p&w)for p in P if not p&2 for v in piv for w in piv if v!=w)
 for c in (3,6,258):
  p=c^2
  assert R&p and all(not r&(1<<extra[c]) or r&p or r&2 for r in P)
  assert all(not(r&2 or r&p)or r&(1<<extra[c])for r in N)
 case.append(int(i))
assert len(case)==16
print(case)
Path('b30.ids').write_text(''.join(f'{j}\n'for j in sorted(case)))
