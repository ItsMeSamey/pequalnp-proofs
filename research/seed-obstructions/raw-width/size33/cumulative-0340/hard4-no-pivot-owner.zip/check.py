from cuts import load,extra,DEGREE_ONE
for e in DEGREE_ONE:
 P,N=load((e,))
 bank=(8191^e)|(127<<13)|sum(1<<extra[c]for c in (129,4160))
 for q,u in DEGREE_ONE.items():
  if e==q:continue
  b=1<<(13+u)
  assert {p&bank for p in P if p&q}=={q|b}
  mask=next(i for i,n in enumerate(N) if n&b and not n&q)
  no=len([n for n in N if n&q]);assert no>0
  # A q-high restricted negative has u=0 already on the native row.
  assert all(not n&b for n in N if n&q)
  print(e,q,u,mask,no)
