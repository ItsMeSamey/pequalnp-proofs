from sroles import *
from itertools import combinations
import maskbranch,maskflex,w40ret
s=Source(0);s.bank((354,));z=(128,512,1024,2048,4096);w={}
for n in range(int(sys.argv[1]),int(sys.argv[2])):
 for zz in combinations(z,n):
  raw=tuple(p for p in zz if p in w)
  if not maskbranch.chk((354,),40,zz,raw,(),True,(),0):
   print("initial-failed",zz,flush=True);continue
  print('z',zz,'zero',maskflex.signed((354,),40,zz,raw,(),0,False),flush=True)
  for xx in [(-1,),(-2,),(-3,)]:
   d,pp=w40ret.run(s,(3,5),13,3,1500,True,w,(zz,xx,0));ys=[p for (p,) in pp if not any(set(q)<set(p) for (q,) in pp)]
   A=[(p,maskbranch.chk((354,),40,zz,raw,(),True,p,0))for p in ys]
   print(zz,xx,d,A,flush=True)
