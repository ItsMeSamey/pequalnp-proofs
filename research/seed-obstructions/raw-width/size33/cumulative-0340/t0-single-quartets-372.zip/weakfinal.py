from weakjoin import *
from itertools import combinations
from ast import literal_eval
import re
for z,n in [((128,2048),2),((512,1024),2),((128,2048),3),((512,1024),3)]:
 files=[f'weak2-{z[0]}.log'] if n==2 else [f'weak3-{z[0]}-{size}.log'for size in ('01','2')]
 lines=[line for f in files for line in Path(f).read_text().splitlines()]
 cert=set()
 for line in lines:
  m=re.fullmatch(r'(\(.*?\)) (\(.*?\)) False (\[.*\]) (\d+)',line)
  if m and all(r is False for p,r in literal_eval(m[3])):cert.add((literal_eval(m[1]),literal_eval(m[2])))
 expect={(ss,xx)for d in range(3)for ss in combinations(z,d)for xx in combinations(range(-n,0),2)}
 assert cert==expect,(z,n,expect-cert)
m=(128,512,1024,2048,4096)
ls=Path('weakone0.log').read_text().splitlines()+Path('weakone4.log').read_text().splitlines()
for n in range(6):
 for z in combinations(m,n):
  if 'initial-failed '+str(z) in ls:continue
  assert f'z {z} zero False' in ls
  for x in [-1,-2,-3]:
   prefix=f'{z} {(x,)} False '
   row=next(l for l in ls if l.startswith(prefix))
   assert all(r is False for p,r in literal_eval(row[len(prefix):]))
assert len(allids)==372 and len(weak)==36 and set(leftweak)=={10,12,14,16,159,162}
assert all((i,a) in {(7,1),(22,2),(22,3)} for i,w,a in active)
assert "done False" in Path('weak72.log').read_text() and all(l.endswith("False") for l in Path('weak72.log').read_text().splitlines())
print('All 372 original IDs closed; last six:', sorted(leftweak))
Path('quartets372.ids').write_text(''.join(f'{p}\n' for p in sorted(allids)))
