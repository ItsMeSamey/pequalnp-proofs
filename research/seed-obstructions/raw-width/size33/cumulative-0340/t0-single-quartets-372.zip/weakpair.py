from sroles import *
import w40required,w40ret
from itertools import combinations
s=Source(0);s.bank((354,));z=tuple(map(int,sys.argv[1:3]));a=int(sys.argv[3]);w={int(p):2 for p in sys.argv[4:]}
for n in range(len(z)+1):
 for b in combinations(z,n):
  if n not in map(int,__import__("os").environ["SIZES"]):continue
  for xx in combinations(range(-a,0),2):
   w40required.calls=0
   d,pp=w40ret.run(s,(3,5),13,a,1200,True,w,(b,xx,0))
   mm=[p for p in pp if not any(q!=p and all(set(t)<=set(v)for t,v in zip(q,p))for q in pp)]
   ans=[]
   for p in mm:
    try:v=w40required.test((354,),40,b,tuple(x for x in b if x in w),0,p)
    except TimeoutError:v='UNKNOWN'
    ans.append((p,v))
   print(b,xx,d,ans,w40required.calls,flush=True)
