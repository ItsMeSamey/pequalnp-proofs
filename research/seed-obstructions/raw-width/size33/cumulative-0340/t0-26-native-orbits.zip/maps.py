from pathlib import Path
from itertools import permutations
import json
from sample import samples
rows,seed,target=samples(Path('L-meta-18968.json'))
def tr(x,perm):
 return sum(1<<j for i,j in enumerate(perm) if x>>i&1)
mask=(1<<20)-1
P={x&mask for j,x in enumerate(rows) if (target&~seed)>>j&1}
N={x&mask for j,x in enumerate(rows) if not(target>>j&1)}
N={x for x in N if not any(x!=y and not x&~y for y in N)}
ne=[sum(x>>13 for x in P if x&8191==1<<i) for i in range(13)]
aut=[]
for f in permutations(range(7)):
 m=[tr(x,f) for x in ne]
 if set(m)!=set(ne):continue
 d=[ne.index(x) for x in m]
 if {tr(x&8191,d)|(tr(x>>13,f)<<13) for x in N}==N:aut.append(d)
A=[3<<j for j in range(6)]; B=[1<<(j+3)|1<<((j+9)%13) for j in range(6)]
extra=set(A+B+[a|b for a,b in zip(A,B)])
t0={tuple(sorted(C)):i for i,t,e,R,C in map(json.loads,Path('remaining.jsonl').read_text().splitlines()) if t==0 and R==8191}
ids=set(map(int,Path('t0-remaining-26.ids').read_text().split()))
print('sym',len(aut))
for C,i in t0.items():
 if i not in ids:continue
 groups=tuple(sorted({c&~58 for c in C}))
 opts=[]
 for d in aut:
  f=tuple(sorted(tr(c,d) for c in groups))
  if set(f)<=extra:opts.append(t0.get(f,'other'))
 print(i,groups,sorted(set(opts),key=str))
for ids2 in ({110,142},{108,112,114,116,125,155,164,169}):
 for C,i in t0.items():
  if i not in ids2:continue
  base=tuple(sorted({c&~58 for c in C}))
  native={t0[tuple(sorted(tr(c,d) for c in C))] for d in aut if tuple(sorted(tr(c,d) for c in C)) in t0}
  orb=min(tuple(sorted(tr(c,d) for c in base)) for d in aut)
  print('orbit',i,'native',native&ids,'virtual',orb)
