exec(open('maps.py').read().split("print('sym'")[0])
assert len(aut)==24 and len(set(ne))==13
cov=set()
for C,i in t0.items():
 if i not in ids or i in cov:continue
 D={}
 for d in aut:
  im=tuple(sorted(tr(c,d) for c in C))
  if im in t0 and t0[im] in ids:
   j=t0[im]
   assert {tr(c,d) for c in C}==set(im)
   D[j]=d
 cov.update(D)
 print('rep',i,'members',sorted(D))
 for j,p in sorted(D.items()):print('map',i,j,p)
assert cov==ids
