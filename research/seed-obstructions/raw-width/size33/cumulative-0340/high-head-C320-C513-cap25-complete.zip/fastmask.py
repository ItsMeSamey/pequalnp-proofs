from nativeext import *
import cached_ext as ce
def work(z,g,sp,V):
 named=tuple(p for p in s.pts if p&z and not p&833)
 cs=[s.dom(sum(1<<(20+i)for i in range(2)if h>>i&1))for h in range(4)]
 # A named nonendpoint is high at its singleton even at the low pin.
 pre=[0]*len(named); upper=[[sum(1<<u for u in s.effective if not s.F[p]&s.tag[u]&cs[h])for p in named]for h in range(4)]
 groups=[(p,) for p in named]+[(-1-j,)for j in range(g)];E=[(i,j)for i in range(len(groups)) for j in range(len(groups))if i!=j]
 from functools import reduce
 from operator import and_,or_
 def walk(V):
  global calls
  cols=list(zip(*V));lo=[reduce(and_,c)for c in cols];hi=[reduce(or_,c)for c in cols]
  poss=[p for p in s.pts if p not in named and any(not s.F[p]&s.on[m]for m in lo)]
  pr=[(p,15)for p in named]+[(p,0)for p in poss]
  calls+=1
  if not ce.actual((320,513),pr,[pre+lo for h in range(4)],E,groups,sp,[upper[h]+(hi if h==0 else [95]*g)for h in range(4)],ordinary=(5,),allowcost=(1,2,3)):return []
  if len(V)==1:return V
  j,u=min(((j,u)for j in range(g)for u in s.effective if (hi[j]^lo[j])&(1<<u)),key=lambda ju:abs(len(V)-2*sum(x[ju[0]]>>ju[1]&1 for x in V)))
  a=[v for v in V if v[j]>>u&1];b=[v for v in V if not v[j]>>u&1]
  return walk(a)+walk(b)
 return walk(V)

from collections import defaultdict
def read(g):
 d=defaultdict(set);buf=set()
 for l in Path(f'g{g}-masks.log').read_text().splitlines():
  a=l.split()
  if a[0]=='mask':
   z,g0,k=map(int,a[1:]);assert g==g0;buf.add(tuple(k>>(7*i)&127 for i in range(g)))
  if a[0]=='done':
   z,g0,sp=map(int,a[1:4]);assert g==g0;d[z,sp].update(buf);buf=set()
 return d
if __name__=='__main__':
 g=int(sys.argv[1]);start,stop=map(int,sys.argv[2:4])
 for (z,sp),v in sorted(read(g).items()):
  V=sorted(v);calls=0
  for i in range(start,min(stop,len(V)),100):
   subset=V[i:min(i+100,stop)];ans=work(z,g,sp,subset)
   print('range',z,g,sp,i,len(subset),calls,len(ans),ans,flush=True)
