from masktree import *
import allplaces_ext as ce
groups=[(1024,),(512,),(256,)];named=(1024,512,256)
pr=[(1024,15),(512,12),(256,10)]
cs=[s.dom(sum(1<<(20+i)for i in range(2)if ar>>i&1))for ar in range(4)]
lo=[[0,64,1]for _ in range(4)]
hi=[[sum(1<<u for u in s.effective if not s.F[p]&s.tag[u]&cs[h])for p in named] for h in range(4)]
hi[0]=lo[0][:]
E=[(i,j)for i in range(3)for j in range(3)if i!=j]
ce.actual((320,513),pr,lo,E,groups,0,hi,ordinary=(5,),allowcost=(1,2,3))
for g in sorted(ce.collected):print(g)
