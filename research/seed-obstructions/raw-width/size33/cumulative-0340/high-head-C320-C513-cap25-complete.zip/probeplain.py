from full import *
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
from itertools import permutations
s=Compound();T=s.effective;U=95
def checker(z,H,control,rounds=80):
 named=tuple(p for p in s.pts if p&z and not p&833)
 prims=tuple(s.pts)+(1<<20,1<<21);own=tuple(1<<(13+u)for u in T)
 nn=len(named);ng=len(H);rt=6+nn+ng
 W=sorted(set(s.N)|set(s.P)|set(s.pp.values())|set(own)|{((hp&1)<<20)|((hp>>1)<<21)|t for hp in range(4) for t in (0,*own)});nr=len(W)
 vs=IDPool();v=vs.id;sv=Solver(name='cadical195')
 add=sv.add_clause
 def cap(xs,k):
  if len(xs)>k:sv.append_formula(CardEnc.atmost(xs,k,vpool=vs).clauses)
 def AND(a,b):
  x=v(('and',a,b))
  if x not in aux:add([-x,a]);add([-x,b]);add([x,-a,-b]);aux.add(x)
  return x
 aux=set()
 def edge(i,h):return v(('e',i,h))
 def loc(p,h):return v(('loc',p,h))
 def y(h,j):return v(('y',h,j))
 def order(i,h):return v(('order',i,h))
 for i in range(rt):
  for h in range(rt+1):
   if h!=i:add([-v(('dup',i,h)),edge(i,h)])
  cap([x for h in range(rt+1)if h!=i for x in (edge(i,h),v(('dup',i,h)))],2)
 for i,h in permutations(range(rt),2):
  add([-edge(i,h),order(i,h)]);add([-order(i,h),-order(h,i)])
 for i,j,h in permutations(range(rt),3):add([-order(i,j),-order(j,h),order(i,h)])
 for p in prims:
  places=[loc(p,h)for h in range(rt+1)];cap(places,1);add(places)
 for p in (4,128,2048,4096):add([loc(p,rt)])
 for p,places in [(1,(rt,0,2,3)),(64,(rt,1,2,5))]:add([loc(p,h) for h in places])
 for i,p in enumerate(named):add([loc(p,i+6)])
 for k,p in enumerate((512,256)):
  h=6+nn+k
  add([loc(p,h)])
  for j,w in enumerate(W):
   if w&s.pp[p]==s.pp[p]:add([y(h,j)])
 for j,w in enumerate(W):
  for h in range(rt+1):
   if not w:add([-y(h,j)])
  if w in s.P:add([y(rt,j)])
  elif w in s.N or w in s.pp.values()or w in own or not w:add([-y(rt,j)])
  for h,u in enumerate(T):
   if w&own[h]:add([y(h,j)])
   if w in s.N and any(w&s.pp[p]==s.pp[p]for p in s.stars[u]):add([-y(h,j)])
  for k,p in enumerate(named):
   if w&s.pp[p]==s.pp[p]:add([y(6+k,j)])
  if w in own:
   bit=1<<T[own.index(w)]
   for k in range(ng):add([y(6+nn+k,j) if H[k]&bit else -y(6+nn+k,j)])
  if w in s.P:
   p=w&8191;t=(w>>13)&127
   if any(n&(s.pp[p]^p)==(s.pp[p]^p) and not n&p and n&(t<<13) for n in s.N):
    for h in range(rt+1):add([-loc(p,h),y(h,j)])
  if w in s.N:
   for p in s.pts:
    if not w&p and w&(s.pp[p]^p)==s.pp[p]^p and (w>>13)&s.inc[p]:
     for h in range(rt+1):add([-loc(p,h),-y(h,j)])
 for a,w in enumerate(W):
  for b,n in enumerate(W):
   if a!=b and not w&~n:
    for h in range(rt+1):add([-y(h,a),y(h,b)])
 import ast
 profiles=[ast.literal_eval(l.split('] ',1)[1]) for l in Path('profiles2.log').read_text().splitlines() if l.startswith('profile')]
 picks=[v(('pick',i))for i in range(len(profiles))];add(picks)
 for pick,vs0 in zip(picks,profiles):
  for hp,V in enumerate(vs0):
   for t in T:
    j=W.index(((hp&1)<<20)|((hp>>1)<<21)|(1<<(13+t)))
    for h in range(3):
     add([-pick,y(6+h,j) if V[h]>>t&1 else -y(6+h,j)])
 # A difference across a single primitive must pass through the region holding it.
 for j,w in enumerate(W):
  for p in prims:
   if not w&p or (w^p) not in W:continue
   i=W.index(w^p)
   for h in range(rt):
    for k in range(rt+1):
     if k==h:continue
     add([-y(h,j),y(h,i),-loc(p,k)]+([order(k,h)] if k<rt else []))
 if control:
  # A true positive/negative duty from a particular genuine-routing branch.
  for u,(pts,seeds) in enumerate(control):
   if u==5:continue
   l=T.index(u)
   for k in range(ng):
    if seeds>>k&1:add([edge(l,6+nn+k)])
   for p in s.pts:
    if p&pts:
     for h in range(rt+1):
      if h==l:add([-loc(p,h)])
      else:add([-loc(p,h),edge(l,h)])
 # Favorable arbitrary monotone local function; learn its necessary comparison clauses.
 learned=set()
 for step in range(rounds):
  sv.conf_budget(10000);ok=sv.solve_limited()
  if ok is not True:sv.delete();return ok,step,len(learned)
  M=set(sv.get_model());new=0
  masks=[sum(1<<h for h in range(rt) if y(h,j) in M)for j in range(nr)]
  for h in range(rt+1):
   raw=sum(p for p in prims if loc(p,h)in M)|(own[h] if h<6 else 0)
   sources=sum(1<<i for i in range(rt)if i!=h and edge(i,h)in M)
   key=[(w&raw,masks[j]&sources)for j,w in enumerate(W)]
   hi=[j for j in range(nr)if y(h,j)in M];lo=[j for j in range(nr)if y(h,j)not in M]
   nc=0
   for a in hi:
    for b in lo:
     if key[a][0]&~key[b][0] or key[a][1]&~key[b][1]:continue
     assert (h,a,b)not in learned
     learned.add((h,a,b));add([-y(h,a),y(h,b),*[loc(p,h)for p in prims if W[a]&p and not W[b]&p],*[AND(edge(i,h),AND(y(i,a),-y(i,b)))for i in range(rt)if i!=h]])
     new+=1;nc+=1
     if nc>=25:break
    if nc>=25:break
  if not new:sv.delete();return True,step,len(learned)
 sv.delete();return 'round-cap',rounds,len(learned)
if __name__=='__main__':
 case=-1;rows=[]
 if case>=0:
  s0=list(map(int,rows[case].split()[1:]));controls=list(zip(s0[::2],s0[1::2]))
 else:controls=()
 print(case,checker(1857,(64,1),controls),flush=True)
