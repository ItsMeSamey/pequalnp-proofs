from pathlib import Path
import subprocess as sp,sys
from full import *
s=Compound()
assert all(s.F.values()) and all(s.no[p,q]or s.no[q,p]for p,q in combinations(s.pts,2))
assert all(s.domq[p]&s.meet[u]for p in s.pts for u in s.effective)
assert all(s.stars[u]&s.stars[v]for u,v in combinations(s.effective,2))
for r in range(5):
 for O in combinations(s.effective,6-r):
  d,m,solo,b=s.roles(sum(1<<u for u in O),10)
  assert b==9-r-len(m) and not pass_budget(solo,b)
assert sp.check_output([sys.executable,'sym.py'])==Path('sym.log').read_bytes()
out=sp.check_output([sys.executable,'nativeext.py','5'])
assert out==Path('ext.log').read_bytes() and len(out.splitlines())==9 and all(l.endswith(b'live []')for l in out.splitlines())
print('all ranks through five excluded')
