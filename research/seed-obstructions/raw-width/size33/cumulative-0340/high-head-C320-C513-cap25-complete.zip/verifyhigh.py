import subprocess as sub,sys
from pathlib import Path
def output(*cmd,stdin=None):
 return sub.check_output(cmd,input=stdin)
def main():
 py=sys.executable
 expected=Path('q2-0.in').read_bytes()
 output(py,'expanded.py','6')
 assert Path('q2-0.in').read_bytes()==expected
 for name in ['two','tagmasks']:
  sub.check_call(['g++','-std=c++20','-O2',name+'.cpp','-o',name])
 res=output('./two','0',stdin=expected)
 assert res==Path('q2-0.out').read_bytes()
 assert output(py,'native6.py','0','1')==Path('native601.log').read_bytes()
 from fastmask import read,work
 import exact,fastmask
 rows=expected.splitlines()
 live=[(int(b[1]),int(b[2]),int(b[3]))for line in res.splitlines()if (b:=line.split())[0]==b'done' and int(b[-1])]
 for g in [2,3]:
  active=[r for r in rows if tuple(map(int,r.split()[:3]))in live and int(r.split()[1])==g]
  raw=b'\n'.join(active)+b'\n'
  assert raw==Path(f'g{g}.in').read_bytes()
  Path(f'g{g}-masks.log').write_bytes(output('./tagmasks','0',stdin=raw))
  keep=set();num=0
  for (z,spare),sigs in read(g).items():
   v=sorted(sigs);num+=len(v)
   for i in range(0,len(v),100):
    fastmask.calls=0
    for H in work(z,g,spare,v[i:i+100]):
     exact.nc=0
     if exact.certify(z,H,spare):keep.add((z,H,spare))
  assert (num,keep)==((5055,{(1857,(64,1),0),(1857,(65,65),0)}) if g==2 else (15838,set()))
 for script,log in [('order','order'),('g2groups','g2groups'),('places','places'),('profiles','profiles2')]:
  assert output(py,script+'.py')==Path(log+'.log').read_bytes()
 out=output(py,'probeplain.py')
 assert b'(False,' in out
 print('all seven ranks excluded when combined with verifylow.py',out.decode().strip())
if __name__=='__main__':main()
