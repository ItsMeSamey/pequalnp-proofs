from masktree import *
from itertools import product
cs=[s.dom(sum(1<<(20+i)for i in range(2)if h>>i&1))for h in range(4)]
@cache
def holders(named,L):
 bs=[]
 for mask in range(1<<len(s.pts)):
  B=tuple(p for i,p in enumerate(s.pts)if mask>>i&1)
  if set(B)&set(named)or any(s.F[p]&s.domq[q]or s.F[q]&s.domq[p]for p,q in combinations(B,2)):continue
  hi=tuple(sum(1<<u for u in s.effective if not any(s.F[p]&s.tag[u]&cs[h] for p in B))for h in range(4))
  if not L&~hi[0]:bs.append((B,hi))
 return bs
def certify(z,H,sp,order):
 g=len(H);named=tuple(p for p in s.pts if p&z and not p&833)
 vpre=[[sum(1<<u for u in s.effective if not s.F[p]&s.tag[u]&cs[h])for p in named]for h in range(4)]
 edges=[(i,j)for i in range(len(named)+g)for j in range(len(named)+g)if order.index(i)<order.index(j)]
 for opts in product(*(holders(named,m)for m in H)):
  bb=[p for b,h in opts for p in b]
  if len(bb)!=len(set(bb)):continue
  groups=[(p,)for p in named]+[b or (-i-1,)for i,(b,h) in enumerate(opts)]
  pr=[(p,15)for p in named]
  for p in bb:
   hp=(1 if p&320 else 0)|(2 if p&513 else 0)
   pr.append((p,sum(1<<h for h in range(4)if h&hp==hp)))
  lo=[[0]*len(named)+list(H)for _ in range(4)]
  hi=[vpre[h]+([k[h]for b,k in opts]if h else list(H))for h in range(4)]
  def walk(lo,hi):
   global nc
   nc+=1
   if not ce.actual((320,513),pr,lo,edges,groups,sp,hi,ordinary=(5,),allowcost=(1,2,3)):return False
   if lo==hi:return True
   h,i=next((h,i) for h in (3,1,2,0)for i in range(len(groups)) if lo[h][i]!=hi[h][i])
   u=(lo[h][i]^hi[h][i])&-(lo[h][i]^hi[h][i])
   L=[x[:]for x in lo];R=[x[:]for x in hi]
   for a in range(4):
    if a&h==h:L[a][i]|=u
    if a&h==a:R[a][i]&=~u
   if all(not l&~r for ll,rr in zip(lo,R)for l,r in zip(ll,rr))and walk(lo,R):return True
   return all(not l&~r for ll,rr in zip(L,hi)for l,r in zip(ll,rr))and walk(L,hi)
  if walk(lo,hi):return True
 return False
if __name__=='__main__':
 import ast
 from itertools import permutations
 for H in ((65,65),(64,1)):
  for order in permutations(range(3)):
   nc=0;a=certify(1857,H,0,order);print(H,order,a,nc,flush=True)
