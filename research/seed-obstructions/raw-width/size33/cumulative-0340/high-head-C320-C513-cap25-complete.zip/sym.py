from full import Native
from itertools import permutations
s=Native();tags=s.effective
aut=[]
for f in permutations(tags):
 perm=dict(zip(tags,f))
 def L(l):return sum(1<<perm[u] for u in tags if l>>u&1)
 inv={v:p for p,v in s.inc.items()}
 if not all(L(v)in inv for v in s.inc.values()):continue
 points={p:inv[L(v)]for p,v in s.inc.items()}
 def pt(n):return sum(q for p,q in points.items()if n&p)
 if {(pt(n),L(l))for n,l in s.ns}!=set(s.ns):continue
 aut.append((perm,points))
assert len(aut)==6
for x in (320,513):
 print(x,sorted({sum(d[p]for p in s.pts if p&x)for _,d in aut}))
print('pair orbit',sorted({tuple(sorted(sum(d[p]for p in s.pts if p&x) for x in (320,513)))for _,d in aut}))
