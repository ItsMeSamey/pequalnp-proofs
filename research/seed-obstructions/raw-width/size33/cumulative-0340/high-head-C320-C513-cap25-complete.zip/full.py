from pathlib import Path
import sys
from private import Native,combinations,cache,union,run
from core import pass_budget
from itertools import combinations_with_replacement
class Compound(Native):
 def __init__(self):
  super().__init__();feat=lambda n:sum(1<<(20+i) for i,c in enumerate((320,513)) if n&c)
  self.P=tuple(n|feat(n)for n in self.P)
  self.N=tuple(n|feat(n)for n in self.N)
  self.pp={p:p|feat(p)for p in self.pts}
  def rows(f):return sum(1<<i for i,n in enumerate(self.N)if f(n))
  self.dom=cache(lambda p:rows(lambda n:n&p==p));self.domq={p:self.dom(a)for p,a in self.pp.items()}
  self.reject=cache(lambda u,x:all(v==u or self.dom(x)&self.tag[u]&self.meet[v]for v in self.effective))
  self.F={p:self.dom(self.pp[p]^p)&~self.domq[p]&self.on[self.inc[p]]for p in self.pts}
  assert all(self.F.values())
  self.pr={p:sum(1<<u for u in self.effective if p in self.stars[u]and self.reject(u,self.pp[p]^p))for p in self.pts}
  self.no={(p,q):bool(self.F[p]&self.domq[q])for p in self.pts for q in self.pts if p!=q}
  self.no_t={(p,q):sum(1<<u for u in self.effective if p in self.stars[u]and self.reject(u,self.pp[p]^p|self.pp[q]))for p,q in self.no}
  self.z=None
 def roles(self,o,k):
  d,m,solo,b=super(Native,self).roles(o,k)
  return d,m if self.z is None else tuple(p for p in self.pts if self.z&p),solo,b
if __name__=='__main__':
 s=Compound()
 for r in range(7):
  alive=[]
  for O in combinations(s.effective,6-r):
   o=sum(1<<u for u in O);d,m,solo,b=s.roles(o,10)
   assert b==9-r-len(m)
   if pass_budget(solo,b):alive.append((o,sum(m),b))
  print(r,alive,flush=True)
