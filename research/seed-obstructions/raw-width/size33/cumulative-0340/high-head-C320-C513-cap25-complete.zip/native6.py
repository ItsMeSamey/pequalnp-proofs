from nativeext import *
for l in Path('q2-0.out').read_text().splitlines():
 x=l.split()
 if x[0]!='done' or x[-1]=='0':continue
 z,g,sp=map(int,x[1:4]);named=tuple(p for p in s.pts if p&z and not p&833)
 if g not in set(map(int,sys.argv[1:])):continue
 print(z,g,sp,check(0,named,g,sp),flush=True)
