from full import *
s=Compound()
for r in map(int,sys.argv[1:]):
 for O in combinations(s.effective,6-r):
  o=sum(1<<u for u in O);d,m,solo,b=s.roles(o,10)
  if not pass_budget(solo,b):continue
  for g in range(b+1):
   out=run(s,O,10,g,1200)
   print(o,g,repr(out),flush=True)
