import gzip,json
from collections import Counter
from pathlib import Path
from sys import argv
from cuts import DEGREE_ONE

def ids(path):
    return set(map(int,Path(path).read_text().split()))

zero_closed = ids(argv[1])
one_closed = ids(argv[2])
rows=list(map(json.loads,gzip.open('terminal-raw-keys.jsonl.gz','rt')))
donors={(e[0],r,tuple(C)):(i,old) for i,(t,e,r,C,_,_,_,old) in enumerate(rows) if t==1}
assert len(donors)==sum(row[0]==1 for row in rows)
results=Counter()
for i,(t,e,r,C,_,_,price,old) in enumerate(rows):
    if t!=0 or old or i in zero_closed:
        continue
    choices={}
    for q in DEGREE_ONE:
        if r&q:
            hit=donors.get((q,r&~q,tuple(C)))
            if hit is None:
                choices[q]=['absent']
            else:
                j,prior=hit
                choices[q]=['closed' if j in one_closed or prior else 'open',j]
    missing=sum(v[0]=='open' for v in choices.values())
    results[price,len(choices),missing]+=1
    print(i,json.dumps(choices,separators=(',',':')))
print('COUNTS',sorted(results.items()))
