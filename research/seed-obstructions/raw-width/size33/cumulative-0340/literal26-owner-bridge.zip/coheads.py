from cuts import *
for e in DEGREE_ONE:
 P,N=load((e,)); M=(8191^e)|(127<<13)|sum(1<<extra[c]for c in (129,4160))
 P=[x&M for x in P];N=[x&M for x in N]; Q=[q for q in DEGREE_ONE if q!=e]
 for q,r in combinations(Q,2):
  scores=[]
  for a in bm(127<<13):
   w=next(((i,j)for i,p in enumerate(P)if p&a for j,n in enumerate(N)if not n&a and n&q and n&r and not((p&~a)&~n)),None)
   scores.append(w)
  print(e,q,r,scores)
