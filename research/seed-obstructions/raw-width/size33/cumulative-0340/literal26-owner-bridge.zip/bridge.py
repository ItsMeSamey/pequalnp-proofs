from cuts import *
for e in DEGREE_ONE:
 P,N=load((e,));C=(129,4160); labels=127<<13
 M=(8191^e)|labels|sum(1<<extra[c]for c in C)
 P=[p&M for p in P];N=[n&M for n in N]
 Q=[q for q in DEGREE_ONE if q!=e]
 H={q:next(p for p in P if p&q) for q in Q}
 w=[]
 for q,r in combinations(Q,2):
  z=(H[q]^q)|(H[r]^r)
  w.append(next(i for i,n in enumerate(N)if not (q|r)&n and not z&~n))
 for side in (M^labels,labels):
  assert all(any(n&a and n&b for n in N)for a in bm(side) for b in bm(side))
 for c in C:
  assert not any(all(any(p&b and p&t for p in P)for b in bm(c))for t in bm(labels))
 for p in bm(8191^e):
  for t in bm(labels):
   if any(x&p and x&t for x in P):continue
   x=next(x&~labels for x in P if x&p)
   assert any(not((x|t)&~n) for n in N)
 print(e,w,'pair-safety, compound endpoints and nonedges verified')
 for q in Q:
  for a in [*Q,*[1<<(13+DEGREE_ONE[r])for r in Q]]:
   if a==q:continue
   assert any(n&q and not n&a and not ((p&~a)&~n) for p in P if p&a for n in N)
