from pathlib import Path
from itertools import combinations
from collections import Counter
import json
exec(Path('high-head-isomorphisms.py').read_text().split('for q in DEGREE_ONE:')[0])
ordinary=sum(pts);D=sum(DEGREE_ONE)
P2,N2=sample(2);h=neigh(P2);transport={}
for q in DEGREE_ONE:
 P,N=sample(q);hq=neigh(P);maps=[]
 for f in permutations(range(6)):
  m=[transform(x,f)for x in hq]
  if set(m)!=set(h):continue
  d=[h.index(x)for x in m]
  if {(transform(p,d),transform(l,f))for p,l in N}==N2:maps.append(d)
 assert len(maps)==6
 transport[q]=maps
A=[3<<j for j in range(6)];B=[(1<<(j+3))|(1<<((j+9)%13))for j in range(6)]
extra=dict(zip(A+B+[a|b for a,b in zip(A,B)],range(20,38)))
roster=set(map(int,Path('t0-remaining-336.ids').read_text().split()))
from collections import defaultdict
out=defaultdict(list)
for i,t,E,R,C in map(json.loads,Path('remaining.jsonl').read_text().splitlines()):
 if t or i not in roster or R!=8191:continue
 mask=R|(127<<13)|sum(1<<extra[x]for x in C)
 for q,u in DEGREE_ONE.items():
  tag=1<<(13+u); selected=[c for c in C if c&q]
  if len(selected)!=1:continue
  c,=selected;p=c^q
  if p not in pts or any(not a&(q|ordinary) for a in C):continue
  P=[w for j,w in enumerate(rows)if (target&~seed)>>j&1];N=[w for j,w in enumerate(rows)if not(target>>j&1)]
  if any(w&p and w&tag for w in P):continue
  active={a&ordinary for a in C if a!=c and (a&ordinary).bit_count()>1}
  orb=min(tuple(sorted(transform(sum(1<<j for j,v in enumerate(pts)if v&a),d)for a in active))for d in transport[q])
  if orb not in ((),(9,),(20,),(9,20),(9,130),(9,33),(20,33)):continue
  assert all(w&mask==q|tag|1<<extra[c] for w in P if w&q)
  assert all(any((w&mask&~n)==tag for n in N)for w in P if w&tag)
  high=q|(1<<extra[c]);low=(D^q)|tag; assert (high|low).bit_count()==6
  keep=set(C)-{c}; PS=set();NS=set()
  for j,w in enumerate(rows):
   x=(w&(ordinary|((127<<13)^tag)))|high|sum(1<<extra[a] for a in keep if w&ordinary&a)
   if (target&~seed)>>j&1 and w&ordinary and not w&tag:
    assert not(w&mask&~x);PS.add(w&(ordinary|((127<<13)^tag)))
   if not(target>>j&1) and w&q:
    assert not(x&mask&~w);NS.add(w&(ordinary|((127<<13)^tag)))
  assert (len(PS),len(NS))==(21,90) and all(any(n&a&ordinary for n in NS)for a in keep)
  assert all(any(n&v for n in NS) for v in pts+[1<<(13+j) for j in range(7) if j!=u])
  assert all(bool(w&(1<<extra[c]))==bool(w&(q|p)) for w in rows)
  out[i].append((q,c,orb))
print(len(out),Counter(tuple(x[2] for x in a) for a in out.values()))
for i,v in out.items():print(i,v)
assert len(out)==274
