# Candidate normalized residual lower bound of 33

At size 32, excess 33−n≥10 and the forced raw coordinates imply 20≤n≤23. The earlier lower bound already excludes every size through 31. Each of the four widths must therefore be handled.

Width 20 has one bank and seven possible line owner labels; the through-six archive and seven-owner archive cover every owner set. Width 21 has 18 actual banks and 2,304 owner choices; the dispatch separates 1,782 through four owners, 378 at five, 126 at six and 18 at seven. Width 23 has 831 actual banks, covered by size32-n23-complete. All three width closures have independent review.

Width 22 has 154 raw banks: point mask 2 with any two of 18 distinct composites (153 choices), or the single bank {3,6,258}. The width-22 at-least-six certificate excludes every owner assignment below six. At six, the initial 1,078 labelled cases reduce to five actual assignments in r6.tsv via anonymous-increment. Four are equivalent to rep29 ordinary 5, covered by s32-n22-r29-j5 with its original negative table. The single remaining representative 30 ordinary 2 has 22 source masks (8 prior exclusions, 14 final ZERO). At seven, the initial 154 banks reduce to 17 in eight orbits via seven-increment. Reps 15/25/35/38 are excluded by two-more-reviewed, 28 by r7-id28, 29/32 by seven-29-32, and the remaining bank (2,129,4160), rep30, by id30-domain and the terminal zero/one/two/three named proofs. The complete id30-seven alternative is also included in the input list.

The primary assembly requires independent global review. The official bridge gives unrestricted minimum R+1 from normalized minimum R. Excluding 32 would leave R=33 or 34. The posted 34-slot statement is equivalent to R≤33, so the primary lower-bound work does not decide that statement.

ID30 has 46 profiles, distributed 1,2,3,12,28 across counts of zero through four named origins. All 28 four-named are excluded, leaving 18. The three-named screen reduces twelve to ten, leaving sixteen profiles for the terminal archives. six-owner-complete.zip supplies an additional unified original-labelled census and replay.
