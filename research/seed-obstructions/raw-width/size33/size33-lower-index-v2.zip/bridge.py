import zipfile
from pathlib import Path
from tempfile import TemporaryDirectory
with zipfile.ZipFile('/workspace/scratch/synthesis_new/size32-lower.zip') as z,TemporaryDirectory() as d:
 p=Path(d)/'task.json';p.write_bytes(z.read('upper34/L-meta-18968.json'))
 g={};exec(z.read('upper34/check.py').decode().split('root = Path(__file__)')[0],g)
 rows,front,target=g['samples'](p)
assert len(rows)==676 and not front&~target
mask=(1<<38)-1
P={r&mask for i,r in enumerate(rows) if target>>i&1 and not front>>i&1}
N={r&mask for i,r in enumerate(rows) if not target>>i&1}
E={r&mask for i,r in enumerate(rows) if front>>i&1}
assert all(r>>38==0 for i,r in enumerate(rows) if target>>i&1 and not front>>i&1)
minp={p for p in P if not any(q!=p and not q&~p for q in P)}
maxn={n for n in N if not any(m!=n and not n&~m for m in N)}
assert E and all(any(not e&~n for n in maxn)for e in E)
assert not any(not p&~n for p in minp for n in maxn)
print(len(P),len(N),len(E),len(minp),len(maxn))
