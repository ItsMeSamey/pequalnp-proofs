from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import sys
root=Path('/workspace/scratch')
files="""synthesis_new/size32-lower.zip
syn_pruning/s32-n20-through-six.zip
syn_mitm/s32-n20-seven.zip
synthesis_new/size32-n21-dispatch.zip
syn_cover/size32-raw21-all-ordinary.zip
syn_quotients/s32-n21-seven-owner-complete.zip
syn_verify/size32-n23-complete.zip
syn_bounds/s32-n22/n22-k11-at-least-six.zip
syn_dual/s32-n22/anonymous-increment.zip
syn_pruning/s32-n22-r29-j5.zip
syn_dual/s32-n22/seven-increment.zip
syn_quotients/s32-n22-r7-two-more-reviewed.zip
syn_quotients/s32-n22-r7-id28.zip
syn_bounds/s32-r7/seven-29-32.zip
syn_bounds/s32-r7/cross-pin.zip
syn_verify/id30-three.zip
syn_quotients/s32-n22-r7-id30-domain.zip
syn_quotients/s32-n22-id30-two-named.zip"""
for rel in files.splitlines()+sys.argv[1:]:
 p=root/rel
 with ZipFile(p) as a: assert a.testzip() is None
 print(sha256(p.read_bytes()).hexdigest(),rel)
