from geom import *
from functools import cache
from itertools import combinations
@cache
def ledger(e,d,z,L):
 D=sum(d); A=[p for p in pts if not p&(e|D)]
 named=[i for i,p in enumerate(z) if p&e];assert len(named)==1
 ix=named[0];iy=4; a=L[ix];b=L[iy];sinks=[(ix,iy,0),(ix,iy,1),(iy,ix,1)]
 out=set()
 for i,j,arc in sinks:
  l1,l2=L[i],L[j]
  for left in combinations(A,2-arc):
   R=sum(left)
   for right in combinations(A,2):
    S=sum(right);needs=[]
    for u,t in enumerate(stars):
     x=l1>>u&1;y=l2>>u&1
     first=(1<<(7+i) if x else 0)|(1<<(7+j)if y and not(x and arc)else 0)
     missing=t&~(D|e|(R if x else 0)|(S if y else 0))
     if missing.bit_count()+first.bit_count()>2:break
     needs.append((missing,first))
    else:out.add(tuple(needs))
 return tuple(sorted(out))
