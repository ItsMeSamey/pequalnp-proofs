from baseroute import check
for d in ((256,512,1024),(256,512,4096)):
 for q in (1,128):
  z=tuple(sorted((*d,q)));passed=check(129,d,z)
  print(d,z,passed,flush=True)
  assert not passed
