from inputs import N,stars
from itertools import combinations
from collections import Counter
pts=[1<<i for i in range(13)]
extras={0}
for j in range(6):
 a=3<<j;b=(1<<(j+3))|(1<<((j+9)%13));extras.update((a,b,a|b))
def mask(p,n,e):return not n&p and (not e&p or e&n)
def calc(O,e):
 priv={p:tuple(t for t in O if p&stars[t] and any(mask(p,q|r,e) for q,r in combinations([x for x in pts if not x&stars[t]],2))) for p in pts}
 ext={p:any(any(p&star and n>>(13+u)&1 for u,star in enumerate(stars) if u not in O) and mask(p,n,e) and all(n&stars[t] for t in O) for n in N) for p in pts}
 seen=[p for p in pts if len(priv[p])+ext[p]>=2]
 forced={p:[n for n in N if any(p&star and n>>(13+u)&1 for u,star in enumerate(stars)) and mask(p,n,e)] for p in seen}
 def isolated(p):return all(p==q or any(n&p for n in forced[q]) for q in seen)
 busy=[p for p in seen if len(priv[p])+ext[p]>2 and isolated(p)]
 return priv,ext,seen,forced,busy
if __name__=='__main__':
 for nr in (5,6):
  hist=Counter()
  for O in combinations(range(7),7-nr):
   for e in sorted(extras):
    p,x,s,f,b=calc(O,e);hist[(11-nr-len(s),len(b))]+=1
  print(nr,hist)
