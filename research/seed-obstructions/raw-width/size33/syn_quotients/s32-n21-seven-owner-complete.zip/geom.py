from inputs import P,N,stars
P=tuple(P);N=tuple(N);pts=[1<<i for i in range(13)]
def cols(pred):return sum(1<<j for j,n in enumerate(N)if pred(n))
def build(E):
 m={(p,u):cols(lambda n: n>>(13+u)&1 and not n&p and(not E&p or n&E))for p in pts for u,t in enumerate(stars)if p&t}
 f={p:0 for p in pts}
 for (p,u),v in m.items():f[p]|=v
 pres={p:cols(lambda n,p=p:bool(n&p))for p in pts}
 return m,f,pres
if __name__=='__main__':
 M,F,pres=build(129)
 for p in pts:
  us=[u for u,T in enumerate(stars)if T&p]
  if len(us)==1:
   u=us[0];print('self',p,[q for q in pts if sum(bool(t&q)for t in stars)>1 and q&stars[u] and M[q,u]&M[p,u]])
