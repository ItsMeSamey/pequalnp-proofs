from select_bins import *
from omit7 import omit
from itertools import product
from functools import lru_cache
@lru_cache(None)
def charge(gs,U,free,r):
 if free:
  m=free[0]
  return any(charge(tuple(sorted((*gs[:i],*gs[i+1:],g&~m))),U,free[1:],r) for i,g in enumerate(gs)) if m and gs else charge(gs,U,free[1:],r)
 return sum(max(0,sum(bool(b>>u&1) for b in gs)-2) for u in U)<=r
@lru_cache(None)
def join(gs,U,ms,r):
 if charge(gs,U,ms,r):return True
 if r<=0:return False
 return any(join(tuple(sorted(gs[:j]+gs[j+1:i]+gs[i+1:]+(g|gs[j],))),U,ms,r-1) for i,g in enumerate(gs) for j in range(i))
def setup(e):
 ng={p:[n for n in N if n&e and mask(p,n,e) and any(n>>(13+u)&1 and p&s for u,s in enumerate(stars))] for p in pts}
 assert all(any(n&q for n in ng[p]) or any(n&p for n in ng[q]) for p,q in combinations(pts,2))
 assert all(any(n&e and n&p and n&s for n in N) for p in pts for s in stars)
 assert all(any(n&e and n>>(13+u)&1 for n in N) for u in range(7))
 return {p:sum(1<<u for u in range(7) if not any(n>>(13+u)&1 for n in ng[p])) for p in pts}
def check(e):
 m=setup(e)
 cases={(d,tuple(sorted((*d,*a)))) for d in omit(e) for n in range(6-len(d)) for a in combinations([p for p in pts if p not in d],n)}
 for nu in (7,6,5):
  for U in combinations(range(7),nu):
   for nv in range(nu,2,-1):
    for V in combinations(U,nv):
     vm=sum(1<<u for u in V)
     for g,K in cuts(e,-1,U,V,1):
      K=frozenset(K); keep=set()
      for d,z in cases:
       gs=tuple(sorted(sum(1<<u for u in V if p&stars[u]) for p in K-set(z)))
       free=tuple(sorted(m[p]&vm for p in z if p not in K and m[p]&vm))
       if join(gs,V,free,5-len(z)):keep.add((d,z))
      cases=keep
      if not cases:return []
 return sorted(cases)
if __name__=='__main__':
 import sys
 e=int(sys.argv[1]);c=check(e);print('KEPT',len(c),c,flush=True)
