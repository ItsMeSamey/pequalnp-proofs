from functools import cache
from geom import *
from named import shapes
@cache
def noroute(e,rootmask,u):
 M,F,pr=build(e)
 ps=[p for p in pts if p&stars[u]]
 cells={(sum(1<<i for i,p in enumerate(ps) if n&p),sum(1<<i for i,p in enumerate(ps) if rootmask&p and F[p]>>j&1)) for j,n in enumerate(N)}
 two=shapes(len(ps))
 rows=0
 for yes,no in cells:rows|=yes
 if not rows:return 0
 if not any(yes and no&rows for yes,no in cells):return 1
 return 2 if any(all(any(y&a==a and not y&b for y in S)for a,b in cells)for S in two)else 3
@cache
def records(e,u):
 _,F,pr=build(e);ps=[p for p in pts if p&stars[u]];n=len(ps)
 return ps,[(sum(1<<i for i,p in enumerate(ps)if nrow&p),sum(1<<i for i,p in enumerate(ps)if F[p]>>j&1)) for j,nrow in enumerate(N)]
@cache
def fr(e,u,which,ns):
 ps,R=records(e,u)
 local=sum(1<<i for i,p in enumerate(ps)if which&p)
 cols=set()
 while ns:
  bit=ns&-ns;ns^=bit
  a,b=R[bit.bit_length()-1]
  if a:cols.add((a,b&local))
 if not cols:return 0
 rs=0
 for a,b in cols:rs|=a
 if not any(b&rs for a,b in cols):return 1
 return 2 if any(all(any(y&a==a and not y&b for y in S) for a,b in cols) for S in shapes(len(ps)))else 3
def routes(e,high,allowed,must,cap):
 from itertools import combinations
 alln=(1<<len(N))-1
 trees=[[]for u in range(7)]
 for u in range(7):
  sites=[h for h in range(12)if h!=u and allowed[h]]
  for k in range(cap+1):
   for X in combinations(sites,k):
    m=sum(1<<h for h in X)
    if must[u] and not m&must[u]:continue
    s=alln
    for h in X:s&=high[h]
    trees[u].append((m,s))
 def minimum(u,rr,raw,upper):
  need=sum(1<<i for i in range(12)if rr[i]);charge=sum(rr[:12])
  best=upper+1
  for m,ns in trees[u]:
   if need&~m:continue
   sc=charge+(m&~need).bit_count()
   if sc+rr[12]>=best:continue
   val=sc+max(rr[12],fr(e,u,raw,ns));best=min(best,val)
  return best
 return minimum
