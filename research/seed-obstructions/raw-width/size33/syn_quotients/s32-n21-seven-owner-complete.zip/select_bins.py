from quickbins import bins
from marks import *
def cuts(e,j,U,V,h):
 us=list(U);bs={p:sum(1<<u for u in U if p&stars[u]) for p in pts}
 M=sum(p for p in pts if j>=0 and p&stars[j] and (h or not p&e) and bs[p])
 ns=[n for n in N if (j<0 or n&M) and (not h or n&e)]
 if j>=0 and (M.bit_count()<2 or any(not any(n>>13&bs[p] for n in ns) for p in pts if p&M)):return
 if any(not any(n&stars[u] and n>>(13+v)&1 for n in ns) for u in range(7) if u!=j for v in V if u!=v):return
 K=[p for p in pts if (h or not p&e) and bs[p] and all(any(n>>(13+u)&1 and n>>13&bs[p] for n in ns) for u in V)]
 K=[p for p in K if all(any(n&p and n>>(13+u)&1 for n in ns) for u in U if not bs[p]>>u&1) and all(any(n&p and n&stars[u] for n in ns) for u in range(7) if u!=j)]
 conflict=[(p,q)for p,q in combinations(K,2) if bs[p]==bs[q] or not any(n>>13&bs[p] and n>>13&bs[q] for n in ns)]
 vm=sum(1<<u for u in V)
 def visit(keepers):
  for p,q in conflict:
   if p in keepers and q in keepers:
    yield from visit(keepers-{p});yield from visit(keepers-{q});return
  if any(bs[p]==sum(1<<u for u in U) for p in keepers):return
  yield tuple(sorted(bs[p]&vm for p in keepers if bs[p]&vm)),keepers
 yield from visit(set(K)) 
def search(e,j):
 for h in (1,0):
  lead=tuple(u for u in range(7) if u!=j)
  for nu in (len(lead),len(lead)-1):
   for U in combinations(lead,nu):
    for nv in range(nu,2,-1):
     for V in combinations(U,nv):
      for gs,ks in cuts(e,j,U,V,h):
       if not bins(gs,V,4 if j<0 else 3):return h,U,V,sorted(ks),gs
if __name__=='__main__':
 import sys
 e,j=map(int,sys.argv[1:])
 print(e,j,search(e,j))
