from geom import *
from linked import ledger
from independent import routes
from high_origins import setup
from itertools import product,combinations_with_replacement
from functools import cache,reduce
from operator import or_
import ast
@cache
def shapes(n):
 bags=[]
 for a,b in combinations_with_replacement(range(1<<n),2):
  bags.append((0,a,b) if a&b else(0,a,b,a|b))
 return bags
from itertools import combinations
from select_bins import cuts
@cache
def C(e,h):
 return {(sum(1<<u for u in V),sum(K)) for n in (7,6,5) for U in combinations(range(7),n) for nv in range(n,2,-1) for V in combinations(U,nv) for _,K in cuts(e,-1,U,V,h)}
@cache
def lowfit(e,d,z,L):
 rem=z.count(0)-1
 for vm,K in C(e,0):
  gs=[sum(1<<u for u,t in enumerate(stars)if t&p)&vm for p in pts if K&p and p not in d]
  free=[a&vm for q,a in zip(z,L)if a&vm and not(q in d and K&q)]
  def walk(i,gs):
   if i==len(free):return sum(max(0,sum(g>>u&1 for g in gs)-2)for u in range(7))<=rem
   return not gs or any(walk(i+1,gs[:j]+[b&~free[i]]+gs[j+1:]) for j,b in enumerate(gs))
  if not walk(0,gs) and not(rem and __import__("high_origins").join(tuple(sorted(gs)),tuple(range(7)),tuple(sorted(free)),rem)):return False
 return True
def check(e,d,z):
 remaining=4-len(z);z=(*z,*([0]*(remaining+1)))
 M,F,pr=build(e);F[0]=0;pr[0]=0; D=sum(d);Z=sum(z)
 tags=[cols(lambda n:n>>(13+u)&1) for u in range(7)]
 meet=[cols(lambda n:n&s)for s in stars];Ec=cols(lambda n:n&e)
 # Mark positive at p must require its local holder in every allowed incidence.
 if any(not a for a in M.values()):return True
 if any(not (mm&meet[h]) for (p,u),mm in M.items() for h in range(7) if u!=h):return True
 high=setup(e);high[0]=127
 low={p:sum(1<<u for u in range(7)if not F[p]&tags[u]) for p in z}
 auto=[any(t&p and not(D|e)&p and (sum(bool(s&p)for s in stars)>1 or any(q&t and not(e|D)&q and sum(bool(s&q)for s in stars)>1 and M[p,u]&M[q,u] for q in pts)) for p in pts) for u,t in enumerate(stars)]
 kill=meet+[F[q]for q in z]+[(1<<len(N))-1]
 if not all(meet[h]&tags[u]&Ec for h in range(7)for u in range(7) if u!=h):return True
 for H in product(*[([127]if i==4 else [0]if not p else [a for a in range(128)if a&high[p]==a]) for i,p in enumerate(z)]):
  for L in product(*[[a for a in range(128)if a&(h&low[p])==a]for p,h in zip(z,H)]):
   if not lowfit(e,d,z,L):continue
   def attempt(H,gh,readE):
    negative=[]
    for i,q in enumerate(z):
     keep=(pr[q] & (-1 if q in d else Ec)) | reduce(or_,[tags[u]for u in range(7)if L[i]>>u&1],0)
     helpH=gh if i==4 else H[i]
     keep|=Ec & reduce(or_,[tags[u]for u in range(7)if helpH>>u&1],0)
     if readE and i==4:keep|=Ec
     negative.append(keep)
    sites={}
    for p in pts:
     if p in z:sites[p]=[7+z.index(p)];continue
     sites[p]=[12]+[h for h in range(7)if not(auto[h] and F[p]&tags[h])and not (p&stars[h] and sum(bool(p&s)for s in stars)>1)]+[7+i for i,q in enumerate(z)if (q or i==4) and not F[p]&negative[i]]
    for p in pts:
     sites[p]=[h for h in sites[p] if h>=7 or all(not (q&stars[h]) or q&(e|D) or not F[p]&M[q,h] or h in sites[q] for q in pts)]
    maybe_auto={h for h in range(7)if not auto[h]}
    @cache
    def rank(h,u,g):
     ps=[p for p in pts if p&g&stars[u] and p not in z]
     if h==u or not ps:return 0
     ns=kill[h]|reduce(or_,(F[p]for p in pts if p&g),0)
     con=set()
     for i,p in enumerate(ps):
      if all(7+k==h or not((H if p&e else L)[k]>>u&1) or (p&e and k==4 and readE) for k in range(5)):
       con.add((1<<i,0))
     for j,n in enumerate(N):
      if not ns>>j&1:continue
      yes=0;no=0
      for i,p in enumerate(ps):
       if F[p]>>j&1:no|=1<<i
       if n&p and all(k+7==h or not ((H if p&e else L)[k]>>u&1) or (negative[k]>>j&1) for k in range(5)):
        yes|=1<<i
      if yes:con.add((yes,no))
     if not con:return 0
     if not any(no&reduce(or_,(a for a,b in con),0) for a,no in con):return 1
     return 2 if any(all(any(x&a==a and not x&b for x in S)for a,b in con)for S in shapes(len(ps))) else 3
    caps=[2-int(any(m>>u&1 for m in (*H[:4],(L[4] if readE else gh))))for u in range(7)]
    highcols=[tags[h] if auto[h]else 0 for h in range(7)]
    highcols+=negative
    allowed=[True]*7+[bool(q)or i==4 for i,q in enumerate(z)]
    must=[sum(1<<(i+7)for i,m in enumerate((*H[:4],127))if m>>u&1) if caps[u]==1 else 0 for u in range(7)]
    mincost=routes(e,highcols,allowed,must,2+remaining)
    g=[0]*13
    def walk(i,order):
     if i==len(order):
      for h in maybe_auto:
       if (stars[h]&~(e|D))&~g[h] and any(F[p]&tags[h] for p in pts if p&g[h]):return False
      costs=[[rank(h,u,v)for h,v in enumerate(g)]for u in range(7)]
      for data in ledger(e,d,z,L):
       for u,(missing,first)in enumerate(data):
        if not auto[u] and not((stars[u]&~(e|D))&~g[u]):missing=0
        cost=[max(costs[u][h],max((v&missing).bit_count(),(first>>h)&1)) for h,v in enumerate(g)]
        if mincost(u,cost,g[12]&stars[u],2)>2:break
       else:return True
      return False
     p=order[i]
     for h in sites[p]:
      if h<7 and any(not (g[h]&q) and q in order[:i] and F[p]&M[q,h] for q in pts if q&stars[h] and not q&(e|D)):continue
      if any(k<7 and k!=h and stars[k]&p and not p&(e|D) and F[q]&M[p,k] for k,v in enumerate(g) for q in pts if q&v):continue
      g[h]|=p
      if sum(max(0,mincost(u,[rank(k,u,v)for k,v in enumerate(g)],g[12]&stars[u],2+remaining)-2) for u in range(7))<=remaining and walk(i+1,order):return True
      g[h]^=p
     return False
    return walk(0,sorted(pts,key=lambda p:len(sites[p])))
   if not attempt(H,L[4],False):continue
   I=sum(1<<u for u,t in enumerate(stars)if t&(e&~sum(z)))
   if attempt(H,127,True):return True
   for a in range(128):
    if a&~(I&~L[4]):continue
    b=L[4]|a
    if attempt((*H[:4],b),b,False):return True
 return False
if __name__=='__main__':
 import sys
 for e in map(int,sys.argv[1:]):
  rows=ast.literal_eval(open('actual-%d.txt'%e).read())
  keep=[(d,z)for d,z in rows if check(e,d,z)]
  print(e,len(rows),len(keep),flush=True);open('onegeneric-%d.txt'%e,'w').write(repr(keep)+'\n')
