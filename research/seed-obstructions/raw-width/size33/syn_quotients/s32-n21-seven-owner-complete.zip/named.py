from geom import *
from high_origins import setup
from itertools import product,combinations_with_replacement
from functools import cache,reduce
from operator import or_
import ast
@cache
def shapes(n):
 bags=[]
 for a,b in combinations_with_replacement(range(1<<n),2):
  bags.append((0,a,b) if a&b else(0,a,b,a|b))
 return bags
def check(e,d,z):
 M,F,pr=build(e); D=sum(d);Z=sum(z)
 tags=[cols(lambda n:n>>(13+u)&1) for u in range(7)]
 meet=[cols(lambda n:n&s)for s in stars];Ec=cols(lambda n:n&e)
 # Mark positive at p must require its local holder in every allowed incidence.
 if any(not a for a in M.values()):return True
 if any(not (mm&meet[h]) for (p,u),mm in M.items() for h in range(7) if u!=h):return True
 high=setup(e)
 low={p:sum(1<<u for u in range(7)if not F[p]&tags[u]) for p in z}
 auto=[any(t&p and not(D|e)&p and (sum(bool(s&p)for s in stars)>1 or any(q&t and not(e|D)&q and sum(bool(s&q)for s in stars)>1 and M[p,u]&M[q,u] for q in pts)) for p in pts) for u,t in enumerate(stars)]
 kill=meet+[F[q]for q in z]+[(1<<len(N))-1]
 if not all(meet[h]&tags[u]&Ec for h in range(7)for u in range(7) if u!=h):return True
 for H in product(*[[a for a in range(128)if a&high[p]==a] for p in z]):
  for L in product(*[[a for a in range(128)if a&(h&low[p])==a]for p,h in zip(z,H)]):
   sites={}
   for p in pts:
    if p in z:sites[p]=[7+z.index(p)];continue
    sites[p]=[12]+[h for h in range(7)if not(auto[h] and F[p]&tags[h])and not (p&stars[h] and sum(bool(p&s)for s in stars)>1)]+[7+i for i,q in enumerate(z)if not(F[p]&pr[q]&(Ec if q not in d else -1)) and not any(F[p]&tags[u] for u in range(7)if L[i]>>u&1)]
   @cache
   def rank(h,u,g):
    ps=[p for p in pts if p&g&stars[u] and p not in z]
    if h==u or not ps:return 0
    ns=kill[h]|reduce(or_,(F[p]for p in pts if p&g),0)
    con=set()
    for j,n in enumerate(N):
     if not ns>>j&1:continue
     yes=0;no=0
     for i,p in enumerate(ps):
      if F[p]>>j&1:no|=1<<i
      if n&p and all(k+7==h or not ((H if p&e else L)[k]>>u&1) or (n&z[k] and (n&e or z[k] in d)) or ((n>>13)&L[k]) or (n&e and (n>>13)&H[k]) for k in range(5)):
       yes|=1<<i
     if yes:con.add((yes,no))
    if not con:return 0
    if not any(no&reduce(or_,(a for a,b in con),0) for a,no in con):return 1
    return 2 if any(all(any(x&a==a and not x&b for x in S)for a,b in con)for S in shapes(len(ps))) else 3
   caps=[2-int(any(m>>u&1 for m in H))for u in range(7)]
   g=[0]*13
   def walk(i,order):
    if i==len(order):return True
    p=order[i]
    for h in sites[p]:
     g[h]|=p
     if all(sum(rank(k,u,v)for k,v in enumerate(g)) + int(caps[u]==1 and not any(m>>u&1 and rank(7+i,u,g[7+i]) for i,m in enumerate(H)))<=2 for u in range(7)) and walk(i+1,order):return True
     g[h]^=p
    return False
   if walk(0,sorted(pts,key=lambda p:len(sites[p]))):return True
 return False
if __name__=='__main__':
 import sys
 for e in map(int,sys.argv[1:]):
  rows=ast.literal_eval(open('surv-%d.txt'%e).read())
  keep=[(d,z)for d,z in rows if len(z)<5 or check(e,d,z)]
  print(e,len(rows),len(keep),flush=True);open('actual-%d.txt'%e,'w').write(repr(keep)+'\n')
