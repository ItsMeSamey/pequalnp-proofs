from marks import *
from fractions import Fraction
from itertools import combinations
def data(e,h,us):
 ns=[n for n in N if not h or e&n]
 bs={p:sum(1<<u for u in us if p&stars[u]) for p in pts}
 K=[p for p in pts if bs[p] and (h or not p&e) and all(any(n>>(13+u)&1 and n>>13&bs[p] for n in ns) for u in us)]
 if not all(any(n&p and n>>(13+u)&1 for n in ns) for p in K for u in us if not bs[p]>>u&1):return ()
 if not all(any(n&p and n&s for n in ns) for p in K for s in stars):return ()
 if not all(any(n&stars[u] and n>>(13+v)&1 for n in ns)for u in range(7) for v in us if u!=v):return ()
 return tuple(sorted(set(bs[p]for p in K)))
if __name__=='__main__':
 from grid6 import weight,ws,g
 for e in [3,24,129,258,177]:
  best=(-100,())
  for h in [0,1]:
   for us in combinations(range(7),6):
    k=data(e,h,us)
    if not k:continue
    sc=sum(weight(m) for m in k)-16-2*sum(g[:,u] for u in us)
    best=max(best,(int(sc.max()),(h,us)))
  print(e,best,flush=True)
