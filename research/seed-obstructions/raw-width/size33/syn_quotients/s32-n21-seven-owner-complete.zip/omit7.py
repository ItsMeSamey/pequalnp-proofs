from marks import *
from functools import lru_cache
from itertools import combinations
@lru_cache(None)
def feasible(groups,remaining,may_drop):
 n=[sum(bool(g>>u&1) for g in groups) for u in range(7)]
 if sum(max(i-2,0) for i in n)<=remaining:return True
 if remaining==0 or max(n)>2+remaining:return False
 for i,a in enumerate(groups):
  reduced=groups[:i]+groups[i+1:]
  if may_drop and feasible(reduced,remaining-1,True):return True
  for j in range(i):
   b=groups[j]
   if not a&b:continue
   nxt=tuple(sorted(groups[:j]+groups[j+1:i]+groups[i+1:]+(a|b,)))
   if feasible(nxt,remaining-1,False):return True
 return False

def omit(e):
 K=[p for p in pts if not p&e]
 labels={p:sum(1<<u for u,s in enumerate(stars) if p&s) for p in K}
 return [d for b in range(6) for d in combinations(K,b) if feasible(tuple(sorted(labels[p]for p in K if p not in d)),5-b,False)]
if __name__=='__main__':
 for e in (3,129,258):
  out=omit(e);print(e,Counter(map(len,out)),out[:3])
