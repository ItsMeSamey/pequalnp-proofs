from lines7 import *
def bins(groups,us,b,j=-1):
 for d in range(b+1):
  for drop in combinations(range(len(groups)),d):
   if sum(max(0,sum(bool(g>>u&1) for i,g in enumerate(groups) if i not in drop)-2+(u==j)) for u in us)<=b-d:return True
 return False
def search(e):
 for n in (7,6,5,4):
  for h in (0,1):
   for us in combinations(range(7),n):
    gs=data(e,h,us)
    if gs and not bins(gs,us,4):return h,us,gs
if __name__=='__main__':
 for e in [3,24,129,258,177]:
  print(e,search(e),flush=True)
