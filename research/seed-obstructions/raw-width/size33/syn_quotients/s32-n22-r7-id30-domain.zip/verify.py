from pathlib import Path
from hashlib import sha256
import ast,subprocess,sys
from collections import Counter
for stage in ['start', 'bits', 'joined', 'twocut', 'original', 'savings', 'onedomain', 'runner']:
 subprocess.run([sys.executable,'-B',stage+'.py','30'],check=True)
for line in Path('checksums.txt').read_text().splitlines():
 digest,name=line.split()
 assert sha256(Path(name).read_bytes()).hexdigest()==digest,name
assert Path('dispatch.txt').read_bytes()==Path('grow-30.txt').read_bytes()
rows=ast.literal_eval(Path('dispatch.txt').read_text())
assert Counter(len(pr) for pr,r in rows)=={0:1,1:2,2:3,3:10}
print('16 final profiles, verified all stage hashes')
