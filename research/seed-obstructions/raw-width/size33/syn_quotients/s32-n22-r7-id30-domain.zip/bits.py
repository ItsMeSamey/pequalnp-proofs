from screen import *
import ast
from functools import cache
def load(i,h):return ast.literal_eval(Path('dom-%d-%d.txt'%(i,h)).read_text())
@cache
def rawprice(fs):
 a,b,c,o=[fs.count(x) for x in (10,12,8,14)]
 def excess(x):return max(0,x-1)
 return min(excess(a+k+j+(k<c)+(j<o))+excess(b+k+j+(k<c)+(j<o))+excess(c-k)+excess(o-j) for k in range(c+1)for j in range(o+1))
def tuples(i):
 bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()))
 _,a,b=bank;ms=(a,b);ns=alln
 for m in ms:ns&=union(pt[p]for p in pts if p&m)
 ds,A,B,AB=[load(i,h)for h in range(4)]
 def okay(t):
  return all(ns&meet[u] for u in range(7))and all(ns&~pt[p]&line(inc[p]) for p in pts if t&p)
 def source(t,z):
  ps=[p for p in pts if p&t]
  roles=[]
  for p in ps:
   yes=[];no=[]
   for h,r in enumerate(z):
    if any(p&m and not h>>j&1 for j,m in enumerate(ms)):continue
    (yes if r&p else no).append(h)
   roles.append([f for f in (8,10,12,14,15)if all(f>>h&1 for h in yes)and all(not f>>h&1 for h in no)])
  for fs in product(*roles):
   if rawprice(tuple(sorted(fs)))<=4-len(ps):yield tuple(zip(ps,fs))
 count=0;res=[];profiles=0
 for ab in AB:
  for a0 in A:
   if a0&~ab:continue
   for b0 in B:
    if b0&~ab:continue
    for d in ds:
     if d&~(a0&b0):continue
     z=(d,a0,b0,ab);count+=1
     if not okay(ab):res.append((z,None));continue
     rp=list(source(ab,z))
     if rp:res.append((z,rp));profiles+=len(rp)
 print('entry',i,'inclusion',count,'priced',len(res),'profiles',profiles,'unchecked',sum(x is None for z,x in res),flush=True)
 return res
if __name__=='__main__':
 import sys
 for i in map(int,sys.argv[1:]):
  try:r=tuples(i)
  except FileNotFoundError:continue
  Path('profiles-%d.txt'%i).write_text(repr(r)+'\n')
