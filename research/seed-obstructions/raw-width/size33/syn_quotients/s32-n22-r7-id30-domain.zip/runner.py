from origgen import *
def run(i):
 bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()));ms=bank[1:]
 out=[]
 for pr,opts in ast.literal_eval(Path('oneb-%d.txt'%i).read_text()):
  if len(pr)!=3:out.append((pr,opts));continue
  bright=[p for p,f in pr if upper(ms,3,p)];assert len(bright)==1
  z1=bright[0];ix=[p for p,f in pr].index(z1)
  res=[]
  for g,d in opts:
   yes=False
   # Start with low finite tag pairs and one common arc, then physiological site rank.
   C=cutlist(ms,0,pr);D=sum(p for p,f in pr if f&1)
   for a in range(128):
    if a&~upper(ms,0,z1):continue
    for b in range(128 if g else 1):
     for arc in range(3 if g else 1):
      if not all(not(v&a and K&z1)and fit(v,K&~D,a,b,arc,2,2 if g else 0,1-g)for v,K in C):continue
      L=[0]*len(pr);L[ix]=a
      if g:L.append(b)
      if actual(ms,pr,tuple(L),arc,g,1-g):yes=True;break
     if yes:break
    if yes:break
   if yes:res.append((g,d))
  if res:out.append((pr,res))
  print('step',i,pr,res,flush=True)
 print('generic kw',i,len(out),Counter(len(pr)for pr,r in out),flush=True)
 Path('grow-%d.txt'%i).write_text(repr(out)+'\n')
if __name__=='__main__':
 import sys
 for i in map(int,sys.argv[1:]):run(i)
