from fixed import *
import sys
for i in map(int,sys.argv[1:]):
 bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()))
 comp=bank[1:]
 for h in [comp,(comp[0],),(comp[1],),()]:
  z=possible(bank,h)
  print(i,h,None if z is None else __import__('collections').Counter(x.bit_count()for x in z),flush=True)
  if z is not None:Path('dom-%d-%d.txt'%(i,sum(1<<j for j,c in enumerate(comp)if c in h))).write_text(repr(sorted(z))+'\n')
