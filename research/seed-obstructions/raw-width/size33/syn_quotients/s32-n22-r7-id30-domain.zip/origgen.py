from twocut import *
from itertools import combinations_with_replacement
@cache
def shapes(n):
 return [(0,a,b) if a&b else (0,a,b,a|b)for a,b in combinations_with_replacement(range(1<<n),2)]
def rank(cells,k):
 if not cells:return 0
 s=union(a for a,b in cells)
 if not any(a and b&s for a,b in cells):return 1
 return 2 if any(all(any((m&a)==a and not m&b for m in S)for a,b in cells)for S in shapes(k))else 3
def actual(ms,pr,LP,arc,ng=0,spare=0):
 z=tuple(p for p,f in pr)+tuple(-j-1 for j in range(ng));fn=dict(pr);M={}
 state=lambda p:sum(1<<i for i,m in enumerate(ms) if p&m)
 hpos={p:state(p)for p in pts};F={}
 cs=[pack(lambda n,j=j:all(not j>>k&1 or n&m for k,m in enumerate(ms)))for j in range(4)]
 for p in pts:
  for u,t in enumerate(stars):
   if p&t:M[p,u]=~pt[p]&on[u]&cs[hpos[p]]
  F[p]=union(M[p,u]for u in range(7)if p&stars[u])
 Z=sum(p for p,f in pr);D=sum(p for p,f in pr if f&1);e=union(ms);rt=7+len(z);S=range(rt)
 selfno={(p,h):bool(M[p,h])and any(M[p,u]&meet[h]for u in range(7)if u!=h and p&stars[u])for h in range(7)for p in pts if p&stars[h]}
 auto=[any(not p&(D|e) and p&t and (selfno[p,h]or any(q&t and not q&(D|e)and selfno[q,h]and M[p,h]&M[q,h]for q in pts))for p in pts)for h,t in enumerate(stars)]
 upperm=[[sum(1<<u for u in range(7)if not (meet[h]&on[u]&cs[j]))for h in range(7)]for j in range(4)]
 U=[[upperm[j][h]if h<7 else LP[h-7]if j==0 else upper(ms,j,z[h-7]) if z[h-7]>0 else 127 for h in S]for j in range(4)]
 high=[on[h]if auto[h]else 0 for h in range(7)]
 for p,L in zip(z,LP):
  high.append(line(L)|(pack(lambda n,p=p:bool(n&p and fn[p]>>state(n)&1)) if p>0 else 0))
 sites={}
 for p in pts:
  if p in z:sites[p]=[7+z.index(p)];continue
  sites[p]=[rt]+[h for h in S if not(F[p]&high[h]) and not(h<7 and p&stars[h]and selfno[p,h])]
 for p in pts:
  sites[p]=[h for h in sites[p] if h>=7 or all(q&(e|D)or not(stars[h]&q)or not(F[p]&M[q,h])or h in sites[q] for q in pts)]
 allzero=[h for h in range(4)]
 sites0=tuple(sorted(pts,key=lambda p:len(sites[p])))
 subtract=[{0}for _ in range(7)]
 @cache
 def cost(h,u,g):
  ps=[p for p in pts if p&g&stars[u]and M[p,u]]
  if h==u or not ps:return 0
  Nset=alln if h==rt else meet[h] if h<7 else F.get(z[h-7],0)
  Nset|=union(F[p]for p in pts if p&g)
  yes=[]
  for p in ps:
   r=pt[p]&Nset
   active=[i for i in S if i!=h and i!=u and U[hpos[p]][i]>>u&1]
   for i in active:r&=high[i]
   yes.append(r)
  cs0=set()
  for i,p in enumerate(ps):
   if not(fn.get(p,0)>>hpos[p]&1)and not any(i!=h and i!=u and U[hpos[p]][i]>>u&1 for i in S):cs0.add((1<<i,0))
  relevant=union(yes)
  while relevant:
   b=relevant&-relevant;relevant^=b
   cs0.add((sum(1<<k for k,x in enumerate(yes)if x&b),sum(1<<k for k,p in enumerate(ps)if F[p]&b)))
  return rank(cs0,len(ps))
 @cache
 def rootprice(u,Q,X):
  ns=alln
  for i in X:ns&=high[i]
  ps=[p for p in pts if p&stars[u]]
  cells=set()
  while ns:
   b=ns&-ns;ns^=b
   need=sum(1<<k for k,p in enumerate(ps) if pt[p]&b)
   if need:cells.add((need,sum(1<<k for k,p in enumerate(ps)if Q&p and M[p,u] and F[p]&b)))
  return rank(cells,len(ps))
 sender=[]
 for u in range(7):
  act=[i+7 for i,m in enumerate(LP)if m>>u&1]
  if len(act)==2 and arc:act=act[:1]if arc==1 else act[1:]
  sender.append(set(act))
 @cache
 def ok(u,rr,raw):
  need={h for h in S if rr[h]}|sender[u]
  best=3+spare
  for k in range(len(need),3+spare):
   for A in combinations([h for h in S if h!=u and h not in need],k-len(need)):
    X=tuple(sorted(need|set(A)));charge=sum(max(1,rr[h])for h in X)
    if charge+rr[rt]<best:best=min(best,charge+max(rr[rt],rootprice(u,raw,X)))
  return best
 g=[0]*(rt+1)
 def walk(i):
  if i==13:return True
  p=sites0[i]
  for h in sites[p]:
   g[h]|=p
   if sum(max(0,ok(u,tuple(cost(a,u,v)for a,v in enumerate(g)),g[rt]&t)-2) for u,t in enumerate(stars))<=spare and walk(i+1):return True
   g[h]^=p
  return False
 return walk(0)
def trybank(i):
 bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()));ms=bank[1:]
 prlist=ast.literal_eval(Path('tc-%d.txt'%i).read_text());kept=[]
 for pr in prlist:
  if len(pr)<4:kept.append(pr);continue
  z=[p for p,f in pr];ix=[k for k,p in enumerate(z)if upper(ms,3,p)]
  C=cutlist(ms,0,pr);Z=sum(p for p,f in pr if f&1)
  ans=False
  for a,b in product(*[[m for m in range(128)if not m&~upper(ms,0,z[k])]for k in ix]):
   for arc in range(3):
    if not all(not(K&z[ix[0]] and v&a) and not(K&z[ix[1]] and v&b)and fit(v,K&~Z,a,b,arc,2,2)for v,K in C):continue
    L=[0]*4;L[ix[0]]=a;L[ix[1]]=b
    if actual(ms,pr,tuple(L),arc):ans=True;break
   if ans:break
  if ans:kept.append(pr)
 print('physical roots',i,len(prlist),len(kept),Counter(map(len,kept)),flush=True)
 Path('actual-%d.txt'%i).write_text(repr(kept)+'\n')
if __name__=='__main__':
 import sys
 for i in map(int,sys.argv[1:]):trybank(i)
