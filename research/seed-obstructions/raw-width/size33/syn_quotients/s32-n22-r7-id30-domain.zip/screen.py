from marks import *
from functools import lru_cache
from itertools import product
from pathlib import Path
from inputs import P
nn=tuple(N)
def pack(f):return sum(1<<i for i,n in enumerate(nn) if f(n))
alln=(1<<len(nn))-1
on=[pack(lambda n:n>>(13+u)&1) for u in range(7)]
pt={p:pack(lambda n:n&p) for p in pts}
meet=[pack(lambda n:n&s) for s in stars]
inc={p:sum(1<<u for u,s in enumerate(stars) if p&s) for p in pts}
def union(It):
 a=0
 for v in It:a|=v
 return a
@lru_cache(None)
def line(m):return union(on[u] for u in range(7) if m>>u&1)
@lru_cache(None)
def infeasible(gs,j): # j only determines count of residual surplus chips
 b=3 if j>=0 else 4
 labels=union(gs);need=[(sum(1<<i for i,g in enumerate(gs) if g>>u&1)) for u in range(7) if labels>>u&1]
 for d in range(b+1):
  for rows in combinations(range(len(gs)),d):
   drop=sum(1<<i for i in rows)
   if sum(max(0,(s&~drop).bit_count()-2) for s in need)<=b-d:return False
 return True
def screen(bank,j):
 comps=[m for m in bank if m!=2];missing=0 if 2 in bank else 2
 phys=tuple(p for p in pts if p!=missing)
 # Positive ordinary inputs whose raw p, and no other feature, is the
 # sole distinguished coordinate against some original j-active negative.
 strict=set()
 if j>=0:
  for p in phys:
   ng=on[j]&~pt[p]
   for m in comps:
    if m&p:ng&=union(pt[q] for q in pts if q&m)
   if ng:strict.add(p)
 for flags in product((1,0),repeat=len(comps)):
  high=[m for m,b in zip(comps,flags) if b];low=union(m for m,b in zip(comps,flags) if not b)
  base=alln
  for m in high:base&=union(pt[p] for p in pts if p&m)
  rawus=127^(1<<j) if j>=0 else 127
  for n in (rawus.bit_count(),rawus.bit_count()-1):
   for ul in combinations([u for u in range(7) if rawus>>u&1],n):
    U=sum(1<<u for u in ul);basep=[p for p in phys if not low&p and inc[p]&U]
    M=[p for p in basep if j>=0 and stars[j]&p and p in strict]
    if j>=0 and len(M)<2:continue
    ns=base&(union(pt[p] for p in M) if j>=0 else alln)
    if any(not(ns&on[u]) for u in ul):continue
    avail=[p for p in basep if inc[p]&U!=U and all(ns&pt[p]&on[u] for u in ul if not inc[p]>>u&1) and all(ns&pt[p]&meet[u] for u in range(7) if u!=j)]
    fail={p:sum(1<<u for u in ul if not ns&on[u]&line(inc[p]&U)) for p in avail}
    bad=[(p,q) for p,q in combinations(avail,2) if inc[p]&U==inc[q]&U or not ns&line(inc[p]&U)&line(inc[q]&U)]
    for V in [U]+[U^(1<<u) for u in ul]+[U^(1<<u)^(1<<v) for u,v in combinations(ul,2)]:
     if any(not ns&on[u]&meet[v] for u in ul if V>>u&1 for v in range(7) if v!=j and v!=u):continue
     def walk(K):
      for p,q in bad:
       if p in K and q in K:return walk(K-{p}) or walk(K-{q})
      gs=tuple(sorted(inc[p]&V for p in K if inc[p]&V))
      if len(gs)<=4:return None
      if infeasible(gs,j):return tuple(sorted(K))
     K=walk({p for p in avail if not fail[p]&V})
     if K:return flags,ul,V,K
if __name__=='__main__':
 import sys
 bank=tuple(map(int,sys.argv[1:]))
 for j in (-1,*range(7)):print(bank,j,screen(bank,j),flush=True)
