from joined import *
@cache
def subsets(q,k):
 a=[p for p in pts if p&q];return tuple(sum(c)for c in combinations(a,min(k,len(a))))
@cache
def draws(q,k,scope,need):
 r=subsets(q,k)
 if need<=0:return (1<<len(r))-1
 if need>k:return 0
 return sum(1<<i for i,v in enumerate(r)if (v&scope).bit_count()>=need)
@cache
def fit(v,K,ma,mb,arc,fa,fb,spare=0):
 if arc==2:return fit(v,K,mb,ma,1,fb,fa,spare)
 for a in subsets(K,fa-arc):
  options=(1<<len(subsets(K,fb)))-1;second=options if spare else 0
  for u,t in enumerate(stars):
   if not v>>u&1:continue
   x=ma>>u&1;y=mb>>u&1
   uncovered=t&K&~(a if x else 0);need=uncovered.bit_count()+x+y-int(x and y and arc)-2
   ok=draws(K,fb,uncovered,need)if y else(-1 if need<=0 else 0)
   if spare:
    relax=draws(K,fb,uncovered,need-1)if y else(-1 if need<=1 else 0)
    second=(second&ok)|(options&relax)
   options&=ok
   if not(options or second):break
  else:return True
 return False
def cutlist(ms,h,pr):
 z=sum(p for p,f in pr if f>>h&1)
 def key(t):
  v,k=t;nums=[(s&k&~z).bit_count()for u,s in enumerate(stars)if v>>u&1]
  return (sum(max(0,n-2)for n in nums),sum(nums)-2*len(nums),len(nums))
 return sorted(allcuts_cached(ms,h),key=key,reverse=True)
allcuts_cached=cache(allcuts)
@cache
def upper(ms,h,p):
 ns=alln
 for j,m in enumerate(ms):
  if h>>j&1 or p&m:ns&=union(pt[q]for q in pts if q&m)
 f=ns&~pt[p]&line(inc[p])
 return sum(1<<u for u in range(7)if not f&on[u])
def ordered(dom):
 if not all(dom):return False
 return any( any(u[0]&~a[0]==0 and u[1]&~a[1]==0 and a[0]&~w[0]==0 and a[1]&~w[1]==0 for a in dom[1])and any(u[0]&~a[0]==0 and u[1]&~a[1]==0 and a[0]&~w[0]==0 and a[1]&~w[1]==0 for a in dom[2])for u in dom[0]for w in dom[3])
def test(i):
 bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()));ms=bank[1:]
 prlist=ast.literal_eval(Path('joint-%d.txt'%i).read_text());keep=[]
 for pr in prlist:
  if len(pr)!=4:keep.append(pr);continue
  bright=[p for p,f in pr if upper(ms,3,p)];assert len(bright)==2
  z1,z2=bright;graphs=[[],[],[]]
  for h in (0,1,2,3):
   z=sum(p for p,f in pr if f>>h&1);C=cutlist(ms,h,pr)
   pairs=list(product([m for m in range(128)if m&~upper(ms,h,z1)==0],[m for m in range(128)if m&~upper(ms,h,z2)==0]))
   for arc in range(3):
    passed=set(pairs)
    for v,K in C:
     passed={t for t in passed if not(K&z1 and v&t[0])and not(K&z2 and v&t[1])and fit(v,K&~z,*t,arc,2,2)}
     if not passed:break
    graphs[arc].append(passed)
   if all(not gg[-1] for gg in graphs):break
  if len(graphs[0])==4 and any(ordered(g)for g in graphs):keep.append(pr)
 print(i,len(prlist),'to',len(keep),Counter(map(len,keep)),flush=True)
 Path('tc-%d.txt'%i).write_text(repr(keep)+'\n')
if __name__=='__main__':
 import sys
 for i in map(int,sys.argv[1:]):test(i)
