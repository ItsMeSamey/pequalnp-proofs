from twocut import *
from functools import reduce
from operator import or_
@cache
def parts(n):
 if n==0:return [()]
 rr=[]
 for part in parts(n-1):
  rr.append((*part,(n-1,)))
  for j in range(len(part)):rr.append((*part[:j],(*part[j],n-1),*part[j+1:]))
 return rr
@cache
def localgain(v,k,allowed,slots):
 req=[max(0,(t&k).bit_count()-2) if v>>u&1 else 0 for u,t in enumerate(stars)]
 return max(sum(min(req[u],max(0,(s&stars[u]).bit_count()-1))for u in range(7)if allowed>>u&1)for s in subsets(k,slots))
@cache
def possible(v,k,allowed,fanout,spare):
 avail=[(a&v,fa) for a,fa in zip(allowed,fanout)if a&v]
 need=sum(max(0,(k&t).bit_count()-2)for u,t in enumerate(stars)if v>>u&1)-spare
 if need<=0:return True
 for groups in parts(len(avail)):
  if sum(localgain(v,k,reduce(or_,[avail[j][0]for j in g],0),1+sum(avail[j][1]-1 for j in g))for g in groups)>=need:return True
 return False
def witness(ms,pr,g,delta):
 z=[p for p,f in pr]+[0]*g;fan=tuple(x+2 for x in delta);spare=4-len(z)-sum(delta)
 for h in (3,1,2,0):
  omit=sum(p for p,f in pr if f>>h&1)
  weight=[upper(ms,h,p)if p else 127 for p in z]
  for v,K in cutlist(ms,h,pr):
   if not possible(v,K&~omit,tuple(0 if K&p else a for p,a in zip(z,weight)),fan,spare):return False
 return True
def run(i):
 bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()));ms=bank[1:]
 ps=ast.literal_eval(Path('actual-%d.txt'%i).read_text());out=[]
 for pr in ps:
  sols=[]
  for g in range(5-len(pr)):
   for delta in product(range(5-len(pr)-g),repeat=len(pr)+g):
    if sum(delta)>4-len(pr)-g:continue
    if witness(ms,pr,g,delta):sols.append((g,delta))
  if sols:out.append((pr,sols))
 print('savings',i,len(ps),len(out),Counter(len(p)for p,s in out),flush=True)
 Path('saving-%d.txt'%i).write_text(repr(out)+'\n')
if __name__=='__main__':
 import sys
 for i in map(int,sys.argv[1:]):run(i)
