from twocut import *
def reduce(i):
 bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()));ms=bank[1:]
 out=[]
 for pr,opts in ast.literal_eval(Path('saving-%d.txt'%i).read_text()):
  if len(pr)!=3:out.append((pr,opts));continue
  bright=[p for p,f in pr if upper(ms,3,p)]
  if len(bright)!=1:out.append((pr,opts));continue
  z1=bright[0];res=[]
  for generic,delta in opts:
   assert not any(delta)
   graphs=[[],[],[]] if generic else [[]]
   for h in (3,1,2,0):
    z=sum(p for p,f in pr if f>>h&1);cc=cutlist(ms,h,pr)
    pairs={(a,b) for a in range(128) if not a&~upper(ms,h,z1)for b in range(128 if generic else 1)}
    for arc,gg in enumerate(graphs):
     if gg and not gg[-1]:gg.append(set());continue
     keep=pairs
     for v,K in cc:
      keep={s for s in keep if not(K&z1 and v&s[0])and fit(v,K&~z,*s,arc,2,2 if generic else 0,1-generic)}
      if not keep:break
     gg.append(keep)
    if all(not g[-1] for g in graphs):break
   if generic:
    result=[g for g in graphs]
    Path('domains-%d-%s.txt'%(i,'-'.join('%dx%d'%(p,f)for p,f in pr))).write_text(repr([[[*sorted(d)]for d in g]for g in result])+'\n')
   if any(len(g)==4 and ordered([g[3],g[1],g[2],g[0]]) for g in graphs):res.append((generic,delta))
  if res:out.append((pr,res))
 print('onebright',i,len(out),Counter(len(pr)for pr,r in out),flush=True)
 Path('oneb-%d.txt'%i).write_text(repr(out)+'\n')
if __name__=='__main__':
 import sys
 for i in map(int,sys.argv[1:]):reduce(i)
