from bits import *
from fixed import coalesce
def allcuts(ms,h):
 ns=alln
 for j,m in enumerate(ms):
  if h>>j&1:ns&=union(pt[p] for p in pts if p&m)
 low=union(m for j,m in enumerate(ms)if not h>>j&1);ref=[p for p in pts if not p&low]
 out=set()
 for n in (7,6,5):
  for us in combinations(range(7),n):
   U=sum(1<<u for u in us)
   rows=[p for p in ref if inc[p]&U not in (0,U) and all(ns&pt[p]&on[u] for u in us if not inc[p]>>u&1)]
   bad=[(p,q)for p,q in combinations(rows,2) if inc[p]&U==inc[q]&U or not ns&line(inc[p]&U)&line(inc[q]&U)]
   for nv in range(n,2,-1):
    for vs in combinations(us,nv):
     V=sum(1<<u for u in vs)
     if any(not(ns&meet[a]&on[u])for u in vs for a in range(7)if u!=a):continue
     K=sum(p for p in rows if all(ns&line(inc[p]&U)&on[u] for u in vs))
     def choose(K):
      for p,q in bad:
       if p&K and q&K:yield from choose(K^p);yield from choose(K^q);return
      yield K
     out.update((V,k)for k in choose(K))
 return sorted(out, key=lambda x:-(x[0].bit_count()*x[1].bit_count()))
@cache
def price(fs,h):
 a,b,c,o=[fs.count(x)for x in(10,12,8,14)]
 def ex(n,m):return max(0,n-1)*((m>>h)&1)
 return min(ex(a+k+j+(k<c)+(j<o),10)+ex(b+k+j+(k<c)+(j<o),12)+ex(c-k,8)+ex(o-j,14) for k in range(c+1)for j in range(o+1))
def test(i):
 bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()));ms=bank[1:]
 profiles=set()
 for z,rp in ast.literal_eval(Path('profiles-%d.txt'%i).read_text()):profiles.update(tuple(x) for x in rp)
 for h in (3,0,1,2):
  C=allcuts(ms,h)
  ns=alln
  for j,m in enumerate(ms):
   if h>>j&1:ns&=union(pt[p]for p in pts if p&m)
  F={p:~pt[p]&line(inc[p])&ns for p in pts}
  for p in pts:
   for m in ms:
    if m&p:F[p]&=union(pt[q]for q in pts if m&q)
  sig={p:sum(1<<u for u in range(7)if not F[p]&on[u])for p in pts}
  @cache
  def ok(top,Z,k):
   for v,K in C:
    g=tuple(sorted(inc[p]&v for p in pts if K&p and not Z&p and inc[p]&v))
    free=tuple(sorted(sig[p]&v for p in pts if top&p and not K&p and sig[p]&v))
    if not coalesce(g,v,free,k):return False
   return True
  profiles={pr for pr in profiles if ok(sum(p for p,f in pr),sum(p for p,f in pr if f>>h&1),4-len(pr)-price(tuple(sorted(f for p,f in pr)),h))}
  print(i,h,len(profiles),flush=True)
 Path('joint-%d.txt'%i).write_text(repr(sorted(profiles))+'\n')
if __name__=='__main__':
 import sys
 for i in map(int,sys.argv[1:]):test(i)
