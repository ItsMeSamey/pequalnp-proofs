from screen import *
from itertools import product
from functools import lru_cache
@lru_cache(None)
def coalesce(gs,U,free,r):
 if plain(gs,U,free,r):return True
 if r<=0:return False
 return any(coalesce(tuple(sorted(gs[:j]+gs[j+1:i]+gs[i+1:]+(g|gs[j],))),U,free,r-1)
            for i,g in enumerate(gs) for j in range(i))
@lru_cache(None)
def plain(gs,U,free,r):
 if free:
  m=free[0]
  if not gs or not m:return plain(gs,U,free[1:],r)
  return any(plain(tuple(sorted(gs[:i]+gs[i+1:]+(g&~m,))),U,free[1:],r) for i,g in enumerate(gs))
 return sum(max(0,sum(bool(g>>u&1) for g in gs)-2) for u in range(7) if U>>u&1)<=r
def possible(bank,HIGH):
 comp=[m for m in bank if m!=2]
 phy=[p for p in pts if 2 in bank or p!=2]
 low=union(m for m in comp if m not in HIGH)
 ref=[p for p in phy if not p&low]
 ns=alln
 for m in HIGH:ns&=union(pt[p] for p in pts if p&m)
 if any(not(ns&pt[p]&meet[u]) for p in ref for u in range(7)):return None
 if any(not(ns&on[u]) for u in range(7)):return None
 raw_rej={}
 for p in ref:
  f=~pt[p]&line(inc[p])
  for m in comp:
   if p&m:f&=union(pt[q]for q in pts if q&m)
  raw_rej[p]=f&ns
 if any(not ((raw_rej[p]&pt[q])or(raw_rej[q]&pt[p])) for p,q in combinations(ref,2)):return None
 source={p:sum(1<<u for u in range(7) if not raw_rej[p]&on[u]) for p in ref}
 # Low-pinned omitted sets are true baselines in the original physical bank,
 # and remain high under this new high/low pin on each such p.
 lowrefs=[p for p in phy if all(not(m&p) for m in comp)]
 D=[sum(ds) for b in range(5) for ds in combinations(lowrefs,b) if coalesce(tuple(sorted(inc[p] for p in lowrefs if p not in ds)),127,(),4-b)]
 sets={sum(zz) for n in range(5) for zz in combinations(ref,n) if any((sum(zz)&d)==d for d in D)}
 for n in (7,6,5):
  for us in combinations(range(7),n):
   U=sum(1<<u for u in us)
   rows=[p for p in ref if inc[p]&U not in (0,U) and all(ns&pt[p]&on[u] for u in us if not inc[p]>>u&1)]
   dark={p:sum(1<<u for u in us if not ns&on[u]&line(inc[p]&U)) for p in rows}
   bad=[(p,q) for p,q in combinations(rows,2) if inc[p]&U==inc[q]&U or not ns&line(inc[p]&U)&line(inc[q]&U)]
   for nv in range(n,2,-1):
    for vs in combinations(us,nv):
     V=sum(1<<u for u in vs)
     if any(not(ns&meet[a]&on[u]) for u in vs for a in range(7) if u!=a):continue
     def choose(K):
      for p,q in bad:
       if p&K and q&K:yield from choose(K^p);yield from choose(K^q);return
      yield K
     for K in set(choose(sum(p for p in rows if not dark[p]&V))):
      live=set()
      for z in sets:
       gs=tuple(sorted(inc[p]&V for p in rows if p&K and not p&z and inc[p]&V))
       free=tuple(sorted(source[p]&V for p in ref if z&p and not K&p and source[p]&V))
       if coalesce(gs,V,free,4-z.bit_count()):live.add(z)
      sets=live
      if not sets:return set()
 return sets
if __name__=='__main__':
 import sys
 idx=int(sys.argv[1]);bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[idx].split()))
 cc=tuple(m for m in bank if m!=2)
 for n in range(len(cc),-1,-1):
  for h in combinations(cc,n):
   z=possible(bank,h);print(idx,h,None if z is None else len(z),flush=True)
   if z==set():quit()
