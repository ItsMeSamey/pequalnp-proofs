from two30 import pairs
from env30 import actual
ms=(129,4160)
for pr in (((256,14),(512,15)),((256,15),(512,14)),((256,15),(512,15))):
 for g,arc in ((1,0),(2,0),(2,1)):
  tops=pairs(pr,3,arc,g)
  passed=[]
  for xy in tops:
   hi=(0,0,*xy[:g]);lo=[(0,)*len(hi)]*3+[hi]
   if actual(ms,pr,lo,((2,3),)if arc else (),[(256,),(512,)]+[(-j-1,)for j in range(g)],0,[hi]*4):passed.append(xy)
  print(pr,g,arc,len(tops),passed,flush=True)
  assert not passed
