from single30 import *
ms=(129,4160)
for pr in (((256,14),(512,15)),((256,15),(512,14)),((256,15),(512,15))):
 assert not any(upper(ms,3,p)for p,f in pr)
 d=[0]*7
 for h in range(4):
  z=sum(p for p,f in pr if f>>h&1)
  for v,k in cutlist(ms,h,pr):
   for u,t in enumerate(stars):
    if v>>u&1:d[u]=max(d[u],(k&t&~z).bit_count()-2)
 assert sum(d)>2
 for r in range(7):
  bonus=tuple(int(u==r)for u in range(7))
  def fits(h):
   z=sum(p for p,f in pr if f>>h&1)
   ds=set(range(128))
   for v,k in cutlist(ms,h,pr):
    ds={m for m in ds if options(v,k&~z,m,2,bonus)}
    if not ds:return False
   return True
  assert not all(fits(h)for h in range(4))
 # Four protected bins of one tag on the high pin force both binary
 # helpers (or a standalone ternary) to be nonconstant on bare inputs.
 Z=256|512
 assert any((k&t&~Z).bit_count()==4 for v,k in cutlist(ms,3,pr)for u,t in enumerate(stars)if v>>u&1)
 print(pr,d,sum(d),'zero, one binary extinct')
