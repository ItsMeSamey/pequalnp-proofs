from exactsite import *
from single30 import options
ms=(129,4160)
def pairs(pr,h,arc,g):
 z=sum(p for p,f in pr if f>>h&1)
 ds={(a,b) for a in range(128) for b in (range(a,128) if not arc and h==3 else range(128))} if g==2 else {(a,0)for a in range(128)}
 for v,K in cutlist(ms,h,pr):
  k=K&~z
  ds={s for s in ds if (fit(v,k,*s,arc,2,2) if g==2 else options(v,k,s[0],3,(0,)*7))}
  if not ds:break
 return sorted(ds)
if __name__=='__main__':
 for pr in (((256,14),(512,15)),((256,15),(512,14)),((256,15),(512,15))):
  for g,arc in [(1,0),(2,0),(2,1)]:
   for h in (3,1,2,0):
    ds=pairs(pr,h,arc,g)
    print(pr,g,arc,h,len(ds),ds[:4],flush=True)
    Path('t30-%s-%s-%s-%s-%s.txt'%(pr[0][1],pr[1][1],g,arc,h)).write_text(repr(ds)+'\n')
