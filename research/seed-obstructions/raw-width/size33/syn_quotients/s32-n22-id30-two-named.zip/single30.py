from twocut import *
from itertools import combinations_with_replacement
@cache
def options(v,k,m,fa,bonus):
 feasible=(1<<len(subsets(k,fa)))-1
 for u,t in enumerate(stars):
  if not v>>u&1:continue
  inside=bool(m>>u&1)
  need=(t&k).bit_count()+inside-2-bonus[u]
  if need>0:
   if not inside:return False
   feasible&=draws(k,fa,t,need)
   if not feasible:return False
 return True
def main():
 ms=(129,4160)
 cases=ast.literal_eval(Path('grow-30.txt').read_text())
 for pr,ss in cases:
  if any(upper(ms,3,p) for p,f in pr):continue
  for g,delta in ss:
   if g!=1:continue
   spare=4-len(pr)-1-sum(delta)
   budgets=set(tuple(x.count(j)for j in range(7)) for x in combinations_with_replacement(range(7),spare))
   good=[]
   for bonus in budgets:
    dd=[]
    for h in (3,1,2,0):
     z=sum(p for p,f in pr if f>>h&1)
     dom=set(range(128))
     for v,k in cutlist(ms,h,pr):
      dom={m for m in dom if options(v,k&~z,m,2+delta[-1],bonus)}
      if not dom:break
     dd.append(dom)
     if not dom:break
    if len(dd)==4 and all(dd):good.append((bonus,list(map(len,dd))))
   print(pr,delta,good,flush=True)
if __name__=='__main__':main()
