from pathlib import Path
import subprocess,sys
for s in ("cheap30","high30"):
 out=subprocess.check_output([sys.executable,"-B",s+".py"])
 assert out==Path(s+".log").read_bytes()
 print(out.decode(),end="")
