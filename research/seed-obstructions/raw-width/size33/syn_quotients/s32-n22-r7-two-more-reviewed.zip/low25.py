from triple import banks
from itertools import permutations
S=banks(24|4160,(256,))
out={s for v in S for s in permutations(v) if not(s[0]&~104 or s[1]&~17)}
print('named 64,4096 palettes',len(out),flush=True)
open('low25.txt','w').writelines('%d %d %d\n'%v for v in sorted(out))
