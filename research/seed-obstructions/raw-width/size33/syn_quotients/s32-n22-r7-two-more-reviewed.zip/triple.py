from geom import *
from itertools import product,combinations
from functools import cache
from collections import Counter
def banks(e,D):
 K=[p for p in pts if not p&e and p not in D]
 target=[sum(1<<j for j,p in enumerate(K) if p&t)for t in stars]
 sub=[[sum(1<<j for j in c) for d in range(k+1)for c in combinations(range(len(K)),d)]for k in range(3)]
 out=set();pro=Counter()
 for arc in range(1,8):
  edges=[(i,j) for b,(i,j)in enumerate(((0,1),(0,2),(1,2))) if arc>>b&1]
  sends=[m.bit_count()-sum(bool(m>>j&1)and any(v==j and m>>u&1 for u,v in edges) for j in range(3)) for m in range(8)]
  pools=[sub[2-sum(u==i for u,v in edges)]for i in range(3)]
  for r,s,t in product(*pools):
   rr=(0,r,s,r|s,t,r|t,s|t,r|s|t)
   opts=[]
   for T in target:
    ok=[m for m,S in enumerate(rr)if sends[m]+(T&~S).bit_count()<=2]
    if not ok:break
    opts.append(ok)
   else:
    for ms in product(*opts):
     L=tuple(sum(1<<u for u,m in enumerate(ms) if m>>i&1)for i in range(3))
     if min(L)==0:continue
     pro[arc]+=1
     out.add(tuple(sorted(L)))
 print('profiles',pro,'distinct signature multisets',len(out),flush=True)
 return out
if __name__=='__main__':
 e=258;S=banks(e,(512,1024))
 for q in (2,256):
  M,F,pr=build(e);mx=sum(1<<u for u in range(7) if not F[q]&cols(lambda n:n>>(13+u)&1))
  sols=sorted({(L[i],*sorted(L[:i]+L[i+1:])) for L in S for i in range(3) if L[i]&mx==L[i]})
  print(q,mx,len(sols),flush=True)
  open('triple-%d.txt'%q,'w').writelines('%d %d %d\n'%s for s in sols)
