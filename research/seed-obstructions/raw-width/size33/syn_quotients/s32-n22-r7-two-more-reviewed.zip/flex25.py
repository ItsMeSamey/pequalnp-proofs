from geom import *
from itertools import combinations,product
K=[p for p in pts if not p&(24|4160)and p!=256]
T=[sum(1<<j for j,p in enumerate(K)if p&t)for t in stars]
subs=[[sum(1<<j for j in c)for c in combinations(range(len(K)),w)]for w in range(4)]
out=set()
for arc in [0,1,2]:
 for fa,fb in ((2,2),(3,2),(2,3)):
  rem=5-fa-fb
  for a,b in product(subs[fa-(arc==1)],subs[fb-(arc==2)]):
   options=[]
   for u,t in enumerate(T):
    opt=[]
    for x,y in product(range(2),repeat=2):
     if x and not 104>>u&1 or y and not 17>>u&1:continue
     src=x+y-int(bool(arc and x and y));cost=max(0,src+(t&~((a if x else 0)|(b if y else 0))).bit_count()-2)
     if cost<=rem:opt.append((x,y,cost))
    if not opt:break
    options.append(opt)
   else:
    for choices in product(*options):
     if sum(t[2]for t in choices)>rem:continue
     out.add(tuple(sum(v[c]<<u for u,v in enumerate(choices))for c in (0,1)))
print('two nonzero-or-empty named helpers with one spare',len(out),sorted(out))
