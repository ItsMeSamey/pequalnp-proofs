from joined import *
def cost(K,V,x,y,arc):
 ps=[p for p in pts if p&K and p not in (256,512)]
 need=[sum(1<<j for j,p in enumerate(ps) if p&stars[u]) for u in range(7)]
 ret=set()
 left=[sum(1<<j for j in c) for c in combinations(range(len(ps)),min(len(ps),x-arc))]
 right=[sum(1<<j for j in c) for c in combinations(range(len(ps)),min(len(ps),y))]
 for a,b in product(left,right):
  options=[];out=[]
  for u,t in enumerate(need):
   if not V>>u&1:options.append(tuple(range(4)) if y else(0,1));continue
   ok=[]
   for m in (range(4)if y else (0,1)):
    send=(m&1)+(m>>1)-int(m==3 and arc)
    covered=(a if m&1 else 0)|(b if m&2 else 0)
    if send+(t&~covered).bit_count()<=2:ok.append(m)
   if not ok:break
   options.append(ok)
  else:
   for rr in product(*options):
    ret.add((sum((q&1)<<u for u,q in enumerate(rr)),sum((q>>1)<<u for u,q in enumerate(rr))))
 return ret
def witness(K,V,x,y,arc,ab):
 a1,b1=ab;ps=[p for p in pts if p&K and p not in (256,512)]
 for aa in combinations(ps,min(len(ps),x-arc)):
  for bb in combinations(ps,min(len(ps),y)):
   for u,t in enumerate(stars):
    if not V>>u&1:continue
    a=(a1>>u)&1;b=(b1>>u)&1
    S=(sum(aa)if a else 0)|(sum(bb)if b else 0)
    if a+b-int(arc and a and b)+(t&sum(ps)&~S).bit_count()>2:break
   else:return True
 return False
def test(x,y,arc):
 domains=[]
 for h in (2,3,1,0):
  C=allcuts((3,4160),h)
  def score(row):
   v,K=row
   ds=[sum(bool(p&K and p&t and p not in (256,512))for p in pts)for u,t in enumerate(stars)if v>>u&1]
   return (sum(max(0,n-2)for n in ds),sum(ds)-2*v.bit_count(),v.bit_count())
  C=sorted(C,key=score,reverse=True)
  v,K=C[0];domain=cost(K,v,x,y,arc)
  for v,K in C[1:]:
   if not domain:break
   if not score((v,K))[0]:continue
   domain={ab for ab in domain if witness(K,v,x,y,arc,ab)}
  print(x,y,arc,h,len(domain),flush=True)
  Path('gates-%d-%d.txt'%(x,h)).write_text(repr(sorted(domain))+'\n')
  if not domain:break
  domains.append(domain)
if __name__=='__main__':
 test(3,0,0);test(2,2,1)
