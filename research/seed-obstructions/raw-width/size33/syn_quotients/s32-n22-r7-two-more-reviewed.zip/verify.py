import ast,subprocess,sys
import bits,joined
from fixed import possible
from pathlib import Path
def child(name):return subprocess.check_output([sys.executable,'-B',name],text=True)
bits.rawprice=lambda fs:0
joined.price=lambda fs,h:0
for i,expected in ((15,1),(25,9)):
 bank=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()))
 a,b=bank[1:]
 for h,high in enumerate(((),(a,),(b,),(a,b))):
  val=possible(bank,high);assert val is not None;Path('dom-%d-%d.txt'%(i,h)).write_text(repr(sorted(val)))
 J=bits.tuples(i);assert all(p is not None for Z,p in J)
 Path('profiles-%d.txt'%i).write_text(repr(J))
 joined.test(i);left=ast.literal_eval(Path('joint-%d.txt'%i).read_text());assert len(left)==expected
 if i==15:assert left==[((256,15),(512,15))]
 else:assert all(tuple(x[0]for x in pr)==(64,256,4096)and pr[1][1]==15 for pr in left)
from screen import pts,pt,inc,line,on,alln,union
def maskbounds(ms,p,high):
 n=alln
 for m in ms:
  if high or m&p:n&=union(pt[q]for q in pts if q&m)
 return sum(1<<u for u in range(7)if not (n&~pt[p]&line(inc[p])&on[u]))
assert all(maskbounds((3,4160),p,True)==0 for p in (256,512))
assert [maskbounds((24,4160),p,False)for p in (64,256,4096)]==[104,0,17]
def gap(h):
 return max(sum((inc[p]&v).bit_count()for p in pts if p&k and p not in(256,512))-2*v.bit_count()for v,k in joined.allcuts((3,4160),h))
assert gap(2)>=3 and gap(3)>=2
assert sum(inc[p].bit_count()for p in pts if not p&(24|4160|256))==18
out=child('gates15.py');print(out,end='');assert out.splitlines()==['3 0 0 2 2','3 0 0 3 0','2 2 1 2 33','2 2 1 3 0']
out=child('low25.py');print(out,end='');assert out.splitlines()[-1]=='named 64,4096 palettes 0'
out=child('flex25.py');print(out,end='');assert out.strip().endswith('0 []')
print('both additional banks excluded')
