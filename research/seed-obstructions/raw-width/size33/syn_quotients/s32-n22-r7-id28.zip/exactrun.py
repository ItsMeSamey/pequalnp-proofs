from exactsite import *
def subset(a,b):return not(a[0]&~b[0]or a[1]&~b[1])
def run(i):
 ms=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()))[1:]
 out=[]
 for pr,opts in ast.literal_eval(Path('grow-%d.txt'%i).read_text()):
  if len(pr)!=3:out.append((pr,opts));continue
  q,=[p for p,f in pr if upper(ms,3,p)]
  base=[p for p,f in pr];qidx=base.index(q)
  dom=ast.literal_eval(Path('domains-%d-%s.txt'%(i,'-'.join('%dx%d'%(p,f)for p,f in pr))).read_text())
  keep=[]
  for g,delta in opts:
   if not g:keep.append((g,delta));continue
   def test():
    for arc,states in enumerate(dom):
     if len(states)!=4:continue
     tops,As,Bs,lows=states
     for t in tops:
      for a in As:
       if not subset(a,t):continue
       for b in Bs:
        if not subset(b,t):continue
        for l in lows:
         if not(subset(l,a)and subset(l,b)):continue
         ls=tuple(tuple(v[0]if k==qidx else v[1]if k==3 else 0 for k in range(4)) for v in (l,a,b,t))
         if actual(ms,pr,ls,arc,g,0):return True
    return False
   if test():keep.append((g,delta))
  if keep:out.append((pr,keep))
  print('exact lattice',i,pr,keep,flush=True)
 Path('exact-%d.txt'%i).write_text(repr(out)+'\n')
if __name__=='__main__':
 import sys
 for i in map(int,sys.argv[1:]):run(i)
