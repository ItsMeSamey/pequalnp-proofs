import ast, subprocess, sys
from pathlib import Path
for stage in ['start', 'bits', 'joined', 'twocut', 'original', 'savings', 'onedomain', 'runner', 'exactrun']:
    subprocess.run([sys.executable, "-B",stage+".py","28"],check=True)
for stage, count in [('joint', 53), ('tc', 22), ('actual', 10), ('saving', 4), ('oneb', 3), ('grow', 3), ('exact', 0)]:
    got=len(ast.literal_eval(Path(stage+"-28.txt").read_text()))
    assert got==count,(stage,got,count)
print("Representative 28, masks 129 and 258, seven mandatory owners: zero.")
