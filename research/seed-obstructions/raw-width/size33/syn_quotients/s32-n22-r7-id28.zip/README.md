# Size 32, width 22, seven compulsory line owners, representative 28

Replay with python verify.py from an extracted directory. Inputs are the original sample and signed representative table. The proof assumes the established seven-owner and regional marker/bin bounds for this grid.

The four projections pin the two composite point inputs low or high independently. Each compulsory singleton whose regional baseline is positive at the high corner requires a physical holder. Its other three zero-line values form a monotone two-bit truth table. The repeated baseline signals that become constant true on a pin consume surplus independently of productive tag fanout on that pin. The initial stages intersect these pin and allocation constraints.

The two-helper pass tests all orientations and grants each state its own tag masks. Original-row tests then use the actual raw composite values on the positive and negative rows. The component saving bound caps reachable distinct receivers by one plus the sum of outgoing fanout excesses. After this bound, each remaining allocation has just one possibly tag-positive named holder and at most one anonymous supplier. The last stage intersects their four tag masks under one physical orientation and monotonicity across adjacent pins and checks original-row holder and fanout constraints. No essential-coordinate-location rule is used.
