#!/bin/sh
set -eu
cd "$(dirname "$0")"
for item in fixed degree one; do
    python "$item.py" | diff - "$item.log"
done
