import sys
from tercase import check
for z in (6272,6288,6304):
 print(z,check((2,129,1040),5,z),flush=True)
