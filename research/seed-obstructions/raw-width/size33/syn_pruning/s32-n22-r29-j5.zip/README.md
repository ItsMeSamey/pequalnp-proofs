# Size 32, width 22, six mandatory owners, representative 29 and ordinary label 5

This exact representative has the thirteen singleton point inputs, seven raw labels and point composites 129 and 1040. The ordinary star has points 2, 128, 2048 and 4096 in one-hot notation. Its three compulsory original marked origins are 128, 2048 and 4096. The original ordinary clamp, directional named-set screen and fixed-departure accounting are upstream lemmas described in SIX.md and JOINT.md.

Pin both composites high. All thirteen points pass the mandatory-darkness test. The only unproved separation of two potential marked holders is the pair 32 and 1024. Apply the directional named-set test twice, omitting 32 and omitting 1024. Both tests concern the same physical holders under identical pins. The actual projected marked-point sets must agree on the other eleven points. The two lists of 26 and 29 candidate sets give 36 consistent unions. When both exceptional points are present, treat distinct holders and a coincidence separately. For coincident holders, removing either of these two points leaves a distinct subclique; an obstruction on either subclique excludes the coincidence. For distinct holders, over five origins exceed budget; test the others with the original fixed-tail lemma. fixed.py does precisely this and leaves 6272, 6288 and 6304, all with distinct holders.

degree.py grants all dispositions of the additional repeated reads. The only surviving dispositions have two anonymous credits at 6272 or one at 6288 and 6304. one.py uses the unmodified duality ternary baseline screen. For two credits, grant either two binary holders or a single ternary holder. Enumerate every subset of the three ordinary marks as the baseline high set of each anonymous holder. ternaryfull.py clamps only the ordinary guard, retains negatives meeting the full ordinary star and requires one departing tail. ternary.py separately uses eligible subsets of marks and the deeper common-high clamp with its corresponding restricted negatives. A physical holder has one fixed baseline signature shared by these tests. The ternary-only grouping rule applies solely when both credits of that holder remain and all named credits are spent: a point-bearing holder can omit one bin, and a point-free one joins at most three bins into one component. This final procedure independently eliminates all three remaining masks.

Run the three standard-Python commands from this directory and compare their output to fixed.log, degree.log and one.log.

    python fixed.py
    python degree.py
    python one.py

The altered two-tail test with an additional point-2 negative family used in a preliminary calculation is excluded from this proof. That calculation does not certify that a shared signal clamped outside the ordinary guard remains high on the new negatives.
