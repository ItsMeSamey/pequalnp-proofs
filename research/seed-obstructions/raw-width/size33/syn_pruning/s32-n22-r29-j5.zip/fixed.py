import sys
from pathlib import Path
from sliced import possible
from jointloss import screen
b=(2,129,1040);h=b[1:];j=5
A=possible(b,h,j,32);B=possible(b,h,j,1024)
D=sorted({a|c for a in A for c in B if not(a^c)&~1056},key=lambda z:(z.bit_count(),z))
for z in D:
 if z.bit_count()<=5:
  print(z,'separate',bool(screen(b,j,z)),flush=True)
 if z&1056==1056:
  print(z,'merged',bool(screen(b,j,z^1024)) or bool(screen(b,j,z^32)),flush=True)
