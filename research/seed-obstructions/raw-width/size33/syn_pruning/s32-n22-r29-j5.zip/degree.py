from pathlib import Path
import sys
from jointdegree import screen
from itertools import combinations_with_replacement
b=(2,129,1040);j=5
for z in (6272,6288,6304):
 opts=[-1,0,1,2,3,4,6]+list(range(7,7+z.bit_count()))
 good=[]
 for d in combinations_with_replacement(opts,5-z.bit_count()):
  if not screen(b,j,z,d):
   good.append(d);print(z,d,flush=True)
 print('completed',z,len(good),flush=True)
