from screen import *
from itertools import product
from functools import lru_cache
@lru_cache(None)
def coalesce(gs,U,free,r):
 if plain(gs,U,free,r):return True
 if r<=0:return False
 return any(coalesce(tuple(sorted(gs[:j]+gs[j+1:i]+gs[i+1:]+(g|gs[j],))),U,free,r-1)
            for i,g in enumerate(gs) for j in range(i))
@lru_cache(None)
def plain(gs,U,free,r):
 if free:
  m=free[0]
  if not gs or not m:return plain(gs,U,free[1:],r)
  return any(plain(tuple(sorted(gs[:i]+gs[i+1:]+(g&~m,))),U,free[1:],r) for i,g in enumerate(gs))
 return sum(max(0,sum(bool(g>>u&1) for g in gs)-2) for u in range(7) if U>>u&1)<=r
def possible(bank,HIGH,j):
 comp=[m for m in bank if m!=2]
 phy=[p for p in pts if 2 in bank or p!=2]
 low=union(m for m in comp if m not in HIGH)
 ref=[p for p in phy if not p&low]
 ns=alln
 for m in HIGH:ns&=union(pt[p] for p in pts if p&m)
 if any(not(ns&pt[p]&meet[u]) for p in ref for u in range(7) if u!=j):return None
 if any(not(ns&on[u]) for u in range(7)):return None
 raw_rej={}
 for p in ref:
  f=~pt[p]&line(inc[p])
  for m in comp:
   if p&m:f&=union(pt[q]for q in pts if q&m)
  raw_rej[p]=f&ns
 if any(not ((raw_rej[p]&pt[q])or(raw_rej[q]&pt[p])) for p,q in combinations(ref,2)):return None
 source={p:sum(1<<u for u in range(7) if not raw_rej[p]&on[u]) for p in ref}
 marks=[]
 for p in ref:
  if not p&stars[j]:continue
  pr=any(all(not p&m or (x|y)&m for m in comp) for x,y in combinations([t for t in pts if not t&stars[j]],2))
  er=~pt[p]&line(inc[p]&~(1<<j))&meet[j]
  for m in comp:
   if p&m:er&=union(pt[q] for q in pts if q&m)
  if pr and er:marks.append(p)
 M=sum(marks)
 sets={sum(zz) for b in range(len(marks),6) for zz in combinations(ref,b) if not M&~sum(zz)}
 for n in (7,6,5):
  for us in combinations(range(7),n):
   U=sum(1<<u for u in us)
   rows=[p for p in ref if inc[p]&U not in (0,U) and all(ns&pt[p]&on[u] for u in us if not inc[p]>>u&1)]
   dark={p:sum(1<<u for u in us if not ns&on[u]&line(inc[p]&U)) for p in rows}
   bad=[(p,q) for p,q in combinations(rows,2) if inc[p]&U==inc[q]&U or not ns&line(inc[p]&U)&line(inc[q]&U)]
   for nv in range(n,2,-1):
    for vs in combinations(us,nv):
     V=sum(1<<u for u in vs)
     if any(not(ns&meet[a]&on[u]) for u in vs for a in range(7) if u!=a and a!=j):continue
     def choose(K):
      for p,q in bad:
       if p&K and q&K:yield from choose(K^p);yield from choose(K^q);return
      yield K
     for K in set(choose(sum(p for p in rows if not dark[p]&V))):
      live=set()
      for z in sets:
       gs=tuple(sorted(inc[p]&V for p in rows if p&K and not p&z and inc[p]&V))
       free=tuple(sorted(source[p]&V&~(1<<j) for p in ref if z&p and not K&p and source[p]&V))
       if sum(bool(g>>j&1) for g in gs)<=1 and coalesce(gs,V,free,5-z.bit_count()):live.add(z)
      sets=live
      if not sets:return set()
 return sets
def check(bank,j):
 cc=tuple(x for x in bank if x!=2)
 for n in range(len(cc),-1,-1):
  for h in combinations(cc,n):
   if possible(bank,h,j)==set():return h,j
