from pathlib import Path
import ast,sys
sys.path.insert(0,str(Path(__file__).parent/'cross-pin'))
from port_switch import *
K=7354;V=46
assign={2:(0,127),8:(0,127),16:(0,127),32:(0,127),128:(1,47),1024:(0,127),2048:(0,127),4096:(2,110)}
assert sum(assign)==K
for p,(h,U)in assign.items():
 ns=[n for n in N if all(not h>>j&1 or n&m for j,m in enumerate((A,B)))]
 assert all(not p&m for j,m in enumerate((A,B))if not h>>j&1)
 S=inc[p]&V
 assert S and S&~U==0 and not bound(p,high)&V
 assert all(any(present(n,u)and n&t for n in ns)for u in labels if S&u for v,t in zip(labels,stars)if v!=u)
 assert all(any(present(n,inc[p]&U)and present(n,u)for n in ns)for u in labels if S&u)
 assert all(any(n&p and n&t for n in ns)for t in stars)
for p,q in combinations(assign,2):
 b=bound(p,high)&bound(q,high)
 assert any(inc[p]&u and inc[q]&v and not b&(u|v) and any(present(n,u)and present(n,v)for n in high)for u in labels for v in labels)
 assert any(inc[x]&u and not inc[y]&u and not b&u and any(n&y and present(n,u)for n in high)for x,y in ((p,q),(q,p))for u in labels)
deficit={u:max(0,(K&t).bit_count()-2)for u,t in zip(labels,stars)if V&u}
assert list(deficit.values())==[1,0,1,2]
gain=lambda s:sum(min(deficit[u],max(0,(s&t).bit_count()-1))for u,t in zip(labels,stars)if V&u)
assert [max(gain(sum(ps))for ps in combinations(assign,k))for k in (1,2,3)]==[0,1,3]
assert bound(256,high)==bound(512,high)==0
profiles=ast.literal_eval((Path(__file__).parent/'predecessor'/'expected-30.txt').read_text())
from collections import Counter
c=Counter(tuple(p for p,f in pr)for pr in profiles)
assert c=={():1,(2048,):2,(256,512):3,(1,256,512):6,(64,256,512):6}
assert not set(assign)&{1,64,256,512}
print('18 terminal profiles',c)
print('joint pin demands',K,V,'deficit',sum(deficit.values()),'available savings <= 3')
