#!/bin/sh
set -eu
cd "$(dirname "$0")"
(
 cd predecessor
 python start.py 30
 python bits.py 30
 python joined.py 30
 python twocut.py 30
 python original.py 30
 cmp actual-30.txt expected-30.txt
)
python verify.py
