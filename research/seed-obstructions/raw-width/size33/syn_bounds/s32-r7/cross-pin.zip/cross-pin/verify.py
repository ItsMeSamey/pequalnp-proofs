from itertools import combinations
from inputs import P,N,stars
points=tuple(1<<j for j in range(13))
labels=tuple(1<<u for u in range(7))
inc={p:sum(u for u,t in zip(labels,stars)if p&t)for p in points}
A,B=129,4160
def present(n,u):return bool(n>>13&u)
def bits(mask):return [p for p in points if p&mask]
def bound(p,ns):
 bad=[n for n in ns if not p&n and present(n,inc[p]) and all(not p&m or n&m for m in (A,B))]
 return sum(u for u in labels if not any(present(n,u)for n in bad))
assert len(P)==28 and len(N)==245
high=[n for n in N if n&A and n&B]
assert bound(2048,high)==0
for named in (False,True):
 sets=[]
 for j,V,K in [(0,47,4030),(1,110,7998)]:
  ms=(A,B);ns=[n for n in N if n&ms[j]]
  pts=bits(K&~(2048 if named else 0));us=[u for u in labels if u&V]
  assert all(not p&ms[1-j] for p in pts)
  assert all(any(present(n,u)and n&t for n in ns)for u in us for v,t in zip(labels,stars)if v!=u)
  assert all(0<(inc[p]&V)<V for p in pts)
  for p in pts:
   assert all(any(p&n and present(n,u)for n in ns)for u in us if not inc[p]&u)
   assert all(any(present(n,inc[p]&V)and present(n,u)for n in ns)for u in us)
   assert all(any(p&n and n&t for n in ns)for t in stars)
  for p,q in combinations(pts,2):
   assert (inc[p]&V)!=(inc[q]&V)
   assert any(present(n,inc[p]&V)and present(n,inc[q]&V)for n in ns)
  Q=sum(pts); deficit={u:max(0,(Q&t).bit_count()-2)for u,t in zip(labels,stars)if u&V};D=sum(deficit.values())
  b=4-int(named); endpoint_count=b+1
  best=[];exact=[]
  for width in range(1,endpoint_count+1):
   scores=[(sum(min(deficit[u],max(0,(sum(C)&t).bit_count()-1))for u,t in zip(labels,stars)if u&V),C)for C in combinations(pts,width)]
   best.append(max(x for x,_ in scores))
   if width==endpoint_count:exact=[C for x,C in scores if x>=D]
  def allocations(rem,used=()):
   yield used,rem
   for x in range(1,rem+1):yield from allocations(rem-x,(*used,x))
  assert [x for x in allocations(b)if sum(best[k]for k in x[0])+x[1]>=D]==[((b,),0)]
  assert len(exact)==1 and best[-2]<D
  print('named',int(named),'pin',j,'deficit',D,'maxima',best,'required',exact[0]);sets.append(exact[0])
 assert sets[0]!=sets[1]
 allpoints=sorted(set(sets[0])|set(sets[1]))
 for p,q in combinations(allpoints,2):
  allowed=bound(p,high)&bound(q,high)
  assert any(not((u|v)&allowed)and inc[p]&u and inc[q]&v and any(present(n,u)and present(n,v)for n in high)for u in labels for v in labels)
  assert any(inc[x]&u and not inc[y]&u and not allowed&u and any(y&n and present(n,u)for n in high)for x,y in ((p,q),(q,p))for u in labels)
 print('top incompatible pairs',len(list(combinations(allpoints,2))))
