from split_tags import *
from twocut import cutlist
from savings import possible
from slot_faces import bill
from functools import reduce
def test(i):
 pair={29:(32,1024),32:(2,128)}[i]
 ms=tuple(map(int,(D/'representatives-3.txt').read_text().splitlines()[i].split()))[1:]
 def check(groups,pr,g,delta):
  slots=tuple(x+2 for x in delta);spare=4-len(groups)-g-sum(delta)
  for h in (3,1,2,0):
   omit=sum(p for p,f in pr if f>>h&1)
   weight=[reduce(int.__and__,(upper(ms,h,p)for p in b))for b in groups]+[127]*g
   for v,K in cutlist(ms,h,pr):
    ss=tuple(0 if K&sum(b)else s for b,s in zip(groups+([()] *g),weight))
    if not possible(v,K&~omit,ss,slots,spare):return False
  return True
 out=[]
 for sh,pr in ast.literal_eval(Path(f'split-tags-{i}.txt').read_text()):
  groups=[(p,)for p,f in pr if not sh or p not in pair]+([pair]if sh else [])
  if len(groups)>=4 or not bill(sh,pr,pair):continue
  ss=[]
  for g in range(5-len(groups)):
   b=4-g-len(groups)
   for d in product(range(b+1),repeat=4-b):
    if sum(d)<=b and check(groups,pr,g,d):ss.append((g,d))
  out.append((sh,pr,ss))
 print(i,len(out),sum(bool(x)for a,b,x in out),Counter((len(pr)-int(sh),g,sum(d))for sh,pr,ss in out for g,d in ss),flush=True)
 Path(f'split-savings-{i}.txt').write_text(repr(out)+'\n')
if __name__=='__main__':
 for i in map(int,sys.argv[1:]):test(i)
