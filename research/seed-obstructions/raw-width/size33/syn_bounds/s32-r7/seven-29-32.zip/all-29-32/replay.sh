#!/bin/sh
set -eu
cd "$(dirname "$0")"
unzip -oq named-four.zip
(cd named-four && sh replay.sh)
cp split_savings.py named-four/
cp savings.py named-four/predecessor/
(cd named-four && python split_savings.py 29 32) | cmp - savings.log
