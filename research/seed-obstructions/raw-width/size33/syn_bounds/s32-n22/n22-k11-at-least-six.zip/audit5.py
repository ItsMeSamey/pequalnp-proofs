from collections import Counter
from pairs import *
from orbit5 import reps,check
stats=Counter()
for O in combinations(range(7),2):
 for i in range(len(bank)):
  case=classify(O,i);stats[case]+=1
  if case=='binary':
   assert set(O)<={1,2,3,5}
  elif case=='zero':
   R,E,M=info(O,i);one=1<<i;p=stars[O[0]]&stars[O[1]]
   assert p in M and len(R[p])==2 and E[p]
   q, = [q for q in M if q!=p and possible[q,p]&one]
   assert len(R[q])==1 and E[q] and all(not possible[r,q]&one for r in M if r!=q)
   assert any(n&q for n in E[p])
  else:assert case in ['cash','busy']
assert stats['binary']==924 and stats['zero']==10
groups=reps()
assert len(groups)==211 and sum(map(len,groups))==924
for case in groups:
 i,O=case[0];assert check(i,O)==0
print('original bank/pair stages',sorted(stats.items()),'joint representatives',len(groups),'surviving maps 0')
