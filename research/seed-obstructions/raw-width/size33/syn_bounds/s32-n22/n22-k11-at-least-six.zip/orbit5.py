from spec import *
from samples import actions
from inputs import P,N,stars
from route5 import check
from sys import argv
from pathlib import Path
def reps():
 pmaps=actions(P,N);ls=[tuple(stars.index(pm[t]) for t in stars) for pm in pmaps]
 ix={}
 for i in range(len(bank)):
  b=Rbank(i); keys=[tuple(sorted(pm[p] for p in b)) for pm in pmaps]
  for O in combinations([1,2,3,5],2):
   k=min((rawkey,tuple(sorted(l[t] for t in O))) for rawkey,l in zip(keys,ls))
   ix.setdefault(k,[]).append((i,O))
 return [v for k,v in sorted(ix.items())]
if __name__=='__main__':
 r=reps();print('JOINT',len(r),sum(map(len,r)),flush=True)
 start,count=map(int,argv[1:3]) if len(argv)>1 else (0,0)
 for j,g in enumerate(r[start:start+count],start):
  i,O=g[0];print(j,i,O,len(g),check(i,O),flush=True)
