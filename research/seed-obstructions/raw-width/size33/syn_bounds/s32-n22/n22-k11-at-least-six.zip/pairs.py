from spec import *
def classify(O,i):
 R,E,M=info(O,i);left=sl(O,i);one=1<<i
 if left<0:return 'cash'
 busy=[p for p in M if len(R[p])+bool(E[p])>2 and all(q==p or not possible[q,p]&one for q in M)]
 if left==0:
  return 'busy' if busy else 'zero'
 if left!=1 or len(busy)!=1:return 'other'
 p,=busy
 assert p==stars[O[0]]&stars[O[1]]
 # A guard can save its direct Jp only when S0 meets p and avoids the
 # union of the exterior masking pair points. This might not be all exterior points.
 ex_allowed=[]
 for t in O:
  blocked=0
  for x,y in combinations([q for q in qs if not stars[t]&q],2):
   if mark(p,x|y)&one:blocked |= x|y
  ex_allowed.append(8191^blocked)
 alln=0
 for n in E[p]:alln|=n&8191
 # If both guards missed, or only one and S cuts exterior p, bound S support.
 possible_hi=(ex_allowed[0]&ex_allowed[1])|((ex_allowed[0]|ex_allowed[1])&~alln)
 # Only other MARKED Jq need directly feed private guards.
 if any(possible[q,r]&one for q in M for r in M if r!=q):return 'mixed-origins'
 return 'binary' if not any(possible_hi&q for q in M if q!=p) else 'broad'
if __name__=='__main__':
 for o in combinations(range(7),2):
  print(o,Counter(classify(o,i) for i in range(len(bank))))
