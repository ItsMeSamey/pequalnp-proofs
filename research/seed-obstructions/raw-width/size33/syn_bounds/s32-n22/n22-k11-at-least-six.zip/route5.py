import five
from spec import *
from functools import lru_cache
from itertools import combinations_with_replacement
from collections import Counter

@lru_cache(None)
def shapes(n,k):
 xs=[]
 for rr in combinations_with_replacement(range(1,1<<n),k):
  g={0}
  for r in rr:g|={j|r for j in g if not j&r}
  xs.append(g)
 return xs
def check(e,O):
 five.setbank(e)
 owners,A,M,domains=five.domain(O)
 exterior=[n for n in N if all(n&stars[t] for t in O)]
 inc={p:{u for u in owners if A.get((u,p)) and all( v==u or any(n&stars[v] for n in five.masks[u,p]) for v in owners)} for p in M}
 @lru_cache(None)
 def bill(h,held,u):
  rs=[p for p in M if p&held and u in inc[p]]
  if not rs or h==u:return 0
  cols=set(exterior if h==7 else [n for n in N if n&stars[h]])
  for p in M:
   if held&p:cols.update(M[p])
  wants={(sum(1<<i for i,p in enumerate(rs)if p&n),sum(1<<i for i,p in enumerate(rs)if n in M[p]))for n in cols}
  for k in (1,2):
   if any(all(any(not(y&~m or m&v) for m in g) for y,v in wants) for g in shapes(len(rs),k)):return k
  return 3
 alive=0
 for h,arc in five.cases(O):
  if all(sum(bill(v,sum(p for p,where in h.items() if where==v),u) for v in [*owners,7])<=2 for u in owners):alive+=1
 return alive
if __name__=='__main__':
 out=Counter()
 for e in sorted(extras):
  for O in combinations([1,2,3,5],2):
   n=check(e,O);out[n]+=1
   if n:print('OPEN',e,O,n,flush=True)
 print('RESULT',out,flush=True)
