from pathlib import Path
import tempfile,subprocess,sys,shutil,zipfile,hashlib
base=Path(__file__).resolve().parent
def expand(path,target):
 with zipfile.ZipFile(path) as z:z.extractall(target)
def run(args,wd):
 return subprocess.check_output(args,cwd=wd,text=True)
with tempfile.TemporaryDirectory() as d:
 root=Path(d);a=root/'rep30';a.mkdir();r=root/'rep29';r.mkdir()
 parent=base/'rep30-final.zip'
 assert hashlib.sha256(parent.read_bytes()).hexdigest()=='10ded409532f630f537a3fc6859bf18e16c3d8b861af7f9b9e1c537848d884aa'
 for name in ('anonymous-increment','joint-increment','loss-increment','named-increment','six-increment','seven-increment','primary-clamps',None):
  expand(parent,a)
  if name:parent=a/(name+'.zip')
 assert hashlib.sha256((a/'anonymous-increment.zip').read_bytes()).hexdigest()=='f7bd50aeebf7ae9f4a2533cfd7f2de7acfcf0f1f5233de2f52e72963b19f1a19'
 shutil.copy(base/'labelled_final.py',a)
 precursor=run([sys.executable,'labelled_anon.py'],a).strip()
 assert 'BANKS 154 R6_CLOSED 1073' in precursor
 path=base/'s32-n22-r29-j5.zip'
 assert hashlib.sha256(path.read_bytes()).hexdigest()=='1c8308a2703c36fff314c375e9e7405b56032d02af55aa56a90ed93eee273c31'
 expand(path,r);run(['sh','verify.sh'],r)
 print('PASS rep29 j5',flush=True)
 out=run([sys.executable,'rep30_verify.py'],a)
 assert out==(a/'rep30.log').read_text()
 print(out,end='')
 ledger=run([sys.executable,'labelled_final.py'],a).splitlines()
 assert ledger[0].startswith('BANKS 154 R6_CLOSED 1078') and len(ledger)==155
 print('PASS 154 banks, 1078 six-owner assignments, 0 unresolved')
