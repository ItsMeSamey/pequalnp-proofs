# All six-owner cases at size 32 and raw width 22

On the specified signed sample, the eleven-surplus branch with exactly six mandatory owners has 154 eligible physical banks and seven ordinary-label assignments per bank. All 1,078 assignments are excluded.

The frozen precursor f7bd50ae covers 1,073. Its five outstanding labelled assignments fall into two actual signed-sample symmetry orbits. The rep29 certificate handles ordinary label 5 with composites 129 and 1040 using two sliced source domains, their compatibility and the original and root-only ternary price bounds. The rep30 certificate handles ordinary label 2 with composites 129 and 4160. Its ROOT-ONLY.md proves the root-local clamp, the omitted-point restriction and the physical fanout bounds. The complete all-high domain has 22 sets, the prior screen removes eight, and the new computation excludes each of the fourteen remaining sets.

Run python verify.py for both final representatives and the complete labelled ledger. It checks the immutable parent hashes and unpacks each source into a fresh temporary directory. It compares the rep30 output byte for byte and checks all 154 final rows. Earlier proof computations and replay commands are contained in the nested precursor archives. The seven-owner branch lies outside this certificate.
