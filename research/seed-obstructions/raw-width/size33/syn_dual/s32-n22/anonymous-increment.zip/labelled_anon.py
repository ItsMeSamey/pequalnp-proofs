from screen import *
from itertools import permutations
from ast import literal_eval
banklist=[tuple(map(int,a.split())) for a in Path('representatives-3.txt').read_text().splitlines()]
def move(m,perm):return sum(1<<v for i,v in enumerate(perm) if m>>i&1)
sig=[inc[p] for p in pts]
sym=[]
for l in permutations(range(7)):
 a=[move(s,l) for s in sig]
 if set(a)!=set(sig):continue
 f=[sig.index(x) for x in a]
 def tr(n):return move(n&8191,f)|(move(n>>13,l)<<13)
 if {tr(n) for n in N}==set(N) and {tr(y) for y in P}==set(P):sym.append((f,l))
assert len(sym)==24
lines=[s for s in Path('reps-0.log').read_text().splitlines() if s.startswith('CHECK')]
left={int(s.split()[1]):literal_eval(s[s.index('['):]) for s in lines}
for lp in sorted(Path('.').glob('fixed-*.log')):
 for s in lp.read_text().splitlines():
  if s.endswith(') 0'):
   i=int(s.split()[0])
   if -1 in left[i]:left[i].remove(-1)
for name in ("lattice-a.log","physical-a.log","partial-a.log"):
 for s in Path(name).read_text().splitlines():
  a=s.split()
  i=int(a[1]) if a[0] in ("RESULT","COMPAT") else int(a[0]) if a[0].isdigit() else None
  if i!=None and ("(False," in s or s.endswith(" -1") or s.endswith(") 0")) and -1 in left[i]:left[i].remove(-1)
for s in Path("columns-first.log").read_text().splitlines():
 a=s.split();i=int(a[0])
 if s[len(a[0])+1:].startswith("(0,") and -1 in left[i]:left[i].remove(-1)
for lp in [Path("before.log"),*Path(".").glob("phys6*.log"),*Path(".").glob("z6*.log")]:
 for s in lp.read_text().splitlines():
  word,i,j,w=s.split(" ",3);i=int(i);j=int(j)
  if w!="None" and j in left[i]:left[i].remove(j)
for path in [*Path(".").glob("named-*.log"),*Path(".").glob("lost-*.log"),*Path(".").glob("small-*.log"),*Path(".").glob("joint-*.log")]:
 for s in path.read_text().splitlines():
  if s.startswith("NAMED ") and not s.endswith(" None"):
   _,i,j,_=s.split(" ",3);i=int(i);j=int(j)
   if j in left[i]:left[i].remove(j)
for row in Path("slice-one.log").read_text().splitlines():
 i,j,w=row.split();i=int(i);j=int(j)
 if w=="True" and j in left[i]:left[i].remove(j)
if Path("anon.log").read_text().startswith("ZERO "):left[28].remove(3)
banks=[(2,*c) for c in combinations(sorted(extras-{0}),2)]+[(3,6,258)]
surv=[]
for bank in banks:
 masks=set(bank)-{2}; c=[]
 for i,rep in enumerate(banklist):
  if (2 in bank)!=(2 in rep):continue
  for f,l in sym:
   if {move(m,f) for m in masks}==set(rep)-{2}:c.append({j for j in range(-1,7) if (l[j] if j>=0 else -1) in left[i]})
 assert c
 surv.append(set.intersection(*c))
print('BANKS',len(surv),'R6_CLOSED',7*len(surv)-sum(len(s-{-1}) for s in surv),'R7_CLOSED',sum(-1 not in s for s in surv))
