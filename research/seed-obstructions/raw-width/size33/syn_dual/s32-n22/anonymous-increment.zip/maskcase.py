from mask6 import *
from itertools import combinations_with_replacement
from jointdegree import screen as old
from sixz import possible
def check(b,j,z):
 Q=[p for p in pts if p&stars[j] and inc[p]&~(1<<j)];mm=sum(Q);subs=[mm]+[sum(t) for k in range(2,len(Q)) for t in combinations(Q,k)]
 masks=[sum(t) for k in range(len(Q)+1) for t in combinations(Q,k)]
 opts=[-1]+[u for u in range(7) if u!=j]+list(range(7,7+z.bit_count()))
 for d in combinations_with_replacement(opts,5-z.bit_count()):
  if old(b,j,z,d):continue
  k=d.count(-1)
  if k>2:return ('many',d)
  for a in ([()] if not k else [((v,1),) for v in masks] if k==1 else [((v,2),) for v in masks]+[tuple((w,1) for w in t) for t in combinations_with_replacement(masks,2)]):
   if not any(screen(b,j,z,d,a,ss) for ss in subs):return d,a
 return 'ZERO'
if __name__=='__main__':
 import sys
 i,j,z=map(int,sys.argv[1:]);b=tuple(map(int,Path('representatives-3.txt').read_text().splitlines()[i].split()));print(i,j,z,check(b,j,z),flush=True)
