from maskcase import *
from jointloss import screen as prior
b=(2,129,258);j=3;zdomain=possible(b,(129,258),j)
remaining=[z for z in sorted(zdomain) if not prior(b,j,z)]
assert remaining==[5634]
assert check(b,j,5634)=='ZERO'
print('ZERO',len(zdomain),remaining)
