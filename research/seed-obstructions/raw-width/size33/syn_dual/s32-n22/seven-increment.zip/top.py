from fixed import *
import sys
banks=Path('representatives-3.txt').read_text().splitlines()
for i in map(int,sys.argv[1:]):
 b=tuple(map(int,banks[i].split()));h=tuple(x for x in b if x!=2)
 z=possible(b,h);print(i,h,None if z is None else len(z),flush=True)
