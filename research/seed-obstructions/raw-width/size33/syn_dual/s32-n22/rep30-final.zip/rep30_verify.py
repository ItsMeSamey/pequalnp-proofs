from qcase import check
from sixz import possible
from jointloss import screen
b=(2,129,4160); j=2
original=possible(b,(129,4160),j)
res=[z for z in sorted(original,key=lambda z:(z.bit_count(),z)) if not screen(b,j,z)]
assert len(original)==22 and len(res)==14
print('DOMAIN',sorted(original))
print('PRIOR',sorted(original-set(res)))
print('RESIDUAL',sorted(res))
for z in res:
 answer=check(b,j,z)
 assert answer=='ZERO',(z,answer)
 print('ZERO',z,flush=True)
print('COMPLETE',len(original),len(res))
