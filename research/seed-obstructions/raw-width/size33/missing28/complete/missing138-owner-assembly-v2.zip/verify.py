from ast import literal_eval
from collections import Counter
from itertools import combinations
from pathlib import Path
import json
read=lambda p:[literal_eval(r)for r in Path(p).read_text().splitlines()]
banks=json.loads(Path('banks.json').read_text());raw=literal_eval(Path('raw-live.txt').read_text())
pay=read('weighted.log')
origin={i for i,(j,r,c)in enumerate(banks)if not r&2 and 2 not in tuple(combinations((2,8,16,32),2))[j]}
assert len(origin)==138 and len(pay)==61 and sum(len(ids)for c,w,ids,ss in pay)==138 and origin=={i for c,w,ids,ss in pay for i in ids}
occ={(c,w):set()for c,w,ids,ss in pay}
for c,w,s,b in read('checksites.log'):
 if b:occ[c,w].add(s)
six=sorted({(c,w,o,b)for i,c,w,o,b in raw if o.bit_count()==1},key=lambda s:(7-s[2].bit_count(),s[3],s))
assert len(six)==284
res={}
for c,w,ids,ss in pay:
 for i in ids:
  j,r,rawc=banks[i];ks=sorted({six.index((d,k,o,b))for n,d,k,o,b in raw if n==i and o.bit_count()==1})
  if len(c)>=2 or not occ[c,w]:seven='two-compounds-and-initial-pricing'
  elif not c:seven='empty'
  elif c[0] in (354,523,1046,2092):seven='middle'
  else:seven=str(c[0])
  res[i]=dict(peeled=tuple(combinations((2,8,16,32),2))[j],raw_points=r,raw_compounds=rawc,core_compounds=c,prices=w,owners_0_to_5='low-complete',six_keys=ks,six_stage='135-and-283'if 283 in ks else '135',seven_stage=seven,endpoint_zero=bool(seven in ('129','4160')and any(s[1]==0 for s in occ[c,w])),endpoint_anonymous=bool(seven in ('129','4160')and any(s[1]>0 for s in occ[c,w])))
assert {i for i,r in res.items()if 283 in r['six_keys']}=={3176,4016,4856}
counts=Counter(r['seven_stage'] for r in res.values())
assert counts=={'two-compounds-and-initial-pricing':77,'empty':10,'middle':28,'129':12,'4160':11}
print('labelled',len(res),'weighted',len(pay),'six keys',len(six),'seven',dict(counts))
Path('ledger.json').write_text(json.dumps(dict(sorted(res.items())),indent=1)+'\n')
