from twin1600 import *
from branchsp import chk
from flex import signed
from itertools import product
def assess(j):
 t=pool();c,w,om,b=t[j];w=dict(w);assert not c and b==2
 s=Source(0);s.bank(c);dm,M,ss,_=s.roles(om,13);z=set(M)|set(w);T=s.stars[om.bit_length()-1]
 D={p for p in z if p in dm and dm[p]&om and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&om for q in z)}
 rr={q for q in z if max(2,w.get(q,0))-int(q in D)>=2}
 def par(a):return tuple(sorted(a)),tuple(sorted(a&set(w)))
 for d in range(1,len(D)+1):
  for h in combinations(sorted(D),d):
   n,r=par(rr|set(h));orig=par(z)
   if chk(c,om,n,r,(),True,()) and fit2(c,om,*orig,False,h):print(j,'one',h,flush=True)
   if not signed(c,om,n,r,(),0,False):continue
   for split in range(1<<(len(h)-1)):
    a=tuple(p for i,p in enumerate(h)if split>>i&1);e=tuple(p for p in h if p not in a)
    if fit2(c,om,*orig,False,e,a):print(j,'two',a,e,flush=True)
if __name__=='__main__':
 for j in map(int,sys.argv[1:]):
  assess(j);print(j,'complete',flush=True)
