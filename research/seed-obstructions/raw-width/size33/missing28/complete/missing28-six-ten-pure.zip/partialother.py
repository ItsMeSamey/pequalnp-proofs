from lastall import *
for j in (273,274,275):
 goals=((1,4,256),(1,4,4096),(1,4,256,4096))if j!=274 else((256,512,2048),)
 for h in goals:
  print('H',j,h,flush=True);calc(j,h)
