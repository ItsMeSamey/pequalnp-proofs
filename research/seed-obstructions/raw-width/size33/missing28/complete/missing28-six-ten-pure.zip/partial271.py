from lastall import *
for h in ((1,4,256),(1,4,4096),(1,4,256,4096)):
 print('H',h,flush=True);calc(271,h)
