from missing import *
from rawregional import run
from ast import literal_eval
def pool():
 a=literal_eval(Path('raw-live.txt').read_text())
 return sorted({(c,w,om,left)for i,c,w,om,left in a if om.bit_count()==1},key=lambda q:(7-q[2].bit_count(),q[3],q))
if __name__=='__main__':
 lo,hi=map(int,sys.argv[1:3])
 for z,(c,w,om,left)in enumerate(pool()[lo:hi],lo):
  s=Source(0);s.bank(c);O=tuple(t for t in range(7)if om>>t&1)
  ans=[]
  for an in range(left+1):
   a=run(s,O,13-len(c),an,400,w=dict(w));ans.append(a)
   if a is True:break
  print(z,c,w,om,left,ans,flush=True)
