from pathlib import Path
import sys

from bigclean import init
import big2,bigpost,branchsp,flex
from itertools import product
from functools import cache
C,w,om,Z,T=init();T=sorted(T);sc=bigpost.sc
def rem(st,B):
 r=[{p for p,d in zip(T,st)if d>>i&1}for i in range(3)];edges=[set()for _ in range(3)];first={}
 for p,d in zip(T,st):
  ar=[i for i in range(3)if d>>i&1]+[3];first[p]=ar[0]
  for a,b in zip(ar,ar[1:]):edges[a].add(b)
 if any(len(q)>2 for q in edges):return 'fanout'
 gone={3}|{i for i in range(3)if B>>i&1}
 if any(not r[i]for i in gone if i<3):return None
 for i in (2,1,0):
  if len(edges[i]&gone)>=2:gone.add(i)
 surv=tuple(i for i in range(3)if i not in gone and not edges[i]&gone)
 named=tuple(p for p in T if first[p] not in gone)
 N=sc.Ehits[om]
 for i in range(3):
  if B>>i&1:N&=flex.union(sc.domq[p]for p in r[i])
 return (named,tuple(sorted(set(named)&set(w))),N,tuple(tuple(sorted(r[i]))for i in surv))
@cache
def signed(named,raw,N,count):
 bigpost.nc=0
 a=bigpost.check(om,named,raw,N,False)
 if a:return True
 if count:
  bigpost.nc=0
  return bool(bigpost.check(om,named,raw,N,True))
 return False
@cache
def two(named,raw,A,B):
 big2.nc=branchsp.nc=flex.calls=0
 return bool(big2.fit2(C,om,named,raw,True,B,A))
def run(st):
 cases=[]
 for mask in range(8):
  v=rem(st,mask)
  if v=='fanout':return 'fanout'
  if v is not None:cases.append((mask,v))
 for mask,(named,raw,N,h)in sorted(cases,key=lambda z:(len(z[1][3]),z[0].bit_count())):
  if len(h)<=1 and not signed(named,raw,N,len(h)):return 'slice'+str(mask)
 for mask,(named,raw,N,h)in cases:
  if not mask and len(h)==2 and not two(named,raw,*h):return 'two'
 return 'OPEN'
if __name__=='__main__':
 a,b=map(int,sys.argv[1:3])
 for j,st in enumerate(product(range(8),repeat=4)):
  if not a<=j<b:continue
  try:answer=run(st)
  except TimeoutError:answer='cap'
  print(j,answer,flush=True)
