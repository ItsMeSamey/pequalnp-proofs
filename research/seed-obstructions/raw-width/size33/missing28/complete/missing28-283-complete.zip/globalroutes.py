from paths import *
from collections import defaultdict
import json
D=Path(__file__).parent
def features(st):
 out={}
 for mask in range(8):
  a=rem(st,mask)
  if a=='fanout':return {}
  if a is None:continue
  named,raw,N,g=a;z=sum(named)
  if len(g)<=1:out[('slice',z,N,len(g))]=mask
  if not mask and len(g)==2:out[('two',z,sum(g[0]),sum(g[1]))]=mask
 return out
def evalf(f):
 typ,z,a,b=f;named=tuple(q for q in T if q&z);raw=tuple(sorted(set(named)&set(w)))
 if typ=='slice':return signed(named,raw,a,b)
 return two(named,raw,tuple(p for p in T if p&a),tuple(p for p in T if p&b))
def main():
 st=list(product(range(8),repeat=4));allf=list(map(features,st))
 alive={i for i,q in enumerate(st)if rem(q,0)!='fanout'}
 by=defaultdict(set)
 for i in alive:
  for f in allf[i]:by[f].add(i)
 tested=set()
 for line in (D/'paths1.log').read_text().splitlines():
  i,verdict=line.split();i=int(i)
  if verdict=='two':fs=[f for f in allf[i]if f[0]=='two']
  elif verdict.startswith('slice'):
   mask=int(verdict[5:]);named,raw,N,g=rem(st[i],mask);fs=[('slice',sum(named),N,len(g))]
  else:continue
  for f in fs:assert f in by;alive-=by[f];tested.add(f)
 receipt=D/'features.jsonl'
 if receipt.exists():
  for l in receipt.read_text().splitlines():
   f,result=json.loads(l);f=tuple(f);tested.add(f)
   if result is False:alive-=by[f]
 print('seed',len(alive),'tested',len(tested),'incidence keys',len(by),flush=True)
 (D/'unresolved.json').write_text(json.dumps(sorted(alive)))
 for step in range(int(sys.argv[1])):
  candidates=[(len(by[f]&alive)/(1 if f[0]=='slice'and not f[-1]else 2 if f[0]=='slice'else 5),f)for f in by if f not in tested and by[f]&alive]
  if not candidates:break
  _,f=max(candidates)
  try:result=evalf(f)
  except TimeoutError:result='cap'
  with receipt.open('a')as out:print(json.dumps([f,result]),file=out)
  tested.add(f)
  if result is False:alive-=by[f]
  print(step,result,len(alive),flush=True)
  (D/'unresolved.json').write_text(json.dumps(sorted(alive)))
 print('end',len(alive),flush=True)
if __name__=='__main__':main()
