from paths import *
import sliced2
keep=sc.Ehits[om]
F={p:sc.F[p]&sc.on[sc.inc[p]&63]&keep for p in sc.phys}
B=[v for k in range(len(sc.phys)+1)for v in flex.combinations(sc.phys,k)if not any(F[p]&sc.domq[q]or F[q]&sc.domq[p]for q,p in flex.combinations(v,2))]
def test(groups):
 gs=[v or (-i-1,) for i,v in enumerate(groups)]
 pr=[(p,1) for v in groups for p in v]
 hi=[sum(1<<u for u in range(6)if not any(F[p]&sc.tag[u] for p in v)) for v in groups]
 def rec(lo,hi):
  if not sliced2.actual((),pr,[lo],[(0,1),(0,2),(1,2)],gs,0,[hi],ordinary=(6,),keep=keep):return None
  if lo==hi:return lo
  i=max(range(3),key=lambda j:(lo[j]^hi[j]).bit_count())
  b=(lo[i]^hi[i])&-(lo[i]^hi[i]); h=hi[:];h[i]^=b
  x=rec(lo,h)
  if x is not None:return x
  l=lo[:];l[i]|=b;return rec(l,hi)
 return rec([0]*3,hi)
if __name__=='__main__':
 assert all(keep&sc.domq[q]&sc.meet[u] for q in sc.phys for u in range(6))
 triples=sorted((v for v in product(B,repeat=3) if len(set(sum(v,())))==sum(map(len,v))),key=lambda v:-sum(map(len,v)))
 print('groups',len(B),'layouts',len(triples),flush=True)
 for i in range(int(sys.argv[1]),min(len(triples),int(sys.argv[2]))):
  print(i,triples[i],test(triples[i]),flush=True)
