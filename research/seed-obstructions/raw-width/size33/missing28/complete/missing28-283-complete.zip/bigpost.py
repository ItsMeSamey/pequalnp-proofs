from route import *
from sliced2 import actual
from functools import cache
sc=Source(0);sc.bank(())
nc=0
@cache
def check(om,z,raw,N,X,sp=0):
 global nc
 O=(om.bit_length()-1,);sel=sc.on[127^om]&N
 if not all(N&sc.domq[q]&sc.meet[u]for q in sc.phys for u in range(7)if u not in O):return 'dark'
 F={p:sel&sc.F[p]for p in sc.phys}
 if any(not(F[q]&sc.domq[p])for q in z if q not in raw for p in sc.phys if p!=q and p not in z):return 'co'
 rr=tuple((i,p)for i,p in enumerate(z)if p in raw);pts=[q for q in sc.phys if q not in z]
 for d in range(len(pts)+1 if X else 1):
  for B in combinations(pts,d):
   if any(F[p]&sc.domq[q]or F[q]&sc.domq[p]for q,p in combinations(B,2)):continue
   pr=tuple((p,1)for p in (*z,*B));grp=[(p,)for p in z]+([B or(-1,)]if X else [])
   hi=[0 if p in raw else sum(1<<u for u in range(7)if u not in O and not F[p]&sc.tag[u])for p in z]
   top=sum(1<<u for u in range(7)if u not in O and not any(F[q]&sc.tag[u]for q in B))
   edges=tuple((i,len(z))for i in range(len(z)))if X else ()
   def test(m):
    global nc
    nc+=1
    if nc>1200:raise TimeoutError
    lo=127;up=0
    for v in m:lo&=v;up|=v
    if not actual((),pr,[[0]*len(z)+([lo]if X else[])],edges,grp,sp,[hi+([up]if X else[])],ordinary=O,rawnodes=rr,keep=N):return False
    if len(m)==1:return (B,m[0])
    j=len(m)//2;return test(m[:j])or test(m[j:])
   r=test([m for m in range(128)if m&~top==0]if X else [0])
   if r:return r
 return False
