from globalroutes import *
from slice_pair import run as pair
import sys
st=list(product(range(8),repeat=4));fs=list(map(features,st));bad=set()
for l in (D/'paths1.log').read_text().splitlines():
 i,v=l.split();i=int(i)
 if v=='two':bad.update(f for f in fs[i]if f[0]=='two')
 if v.startswith('slice'):
  named,raw,N,h=rem(st[i],int(v[5:]));bad.add(('slice',sum(named),N,len(h)))
for l in (D/'features.jsonl').read_text().splitlines():
 f,v=json.loads(l)
 if v is False:bad.add(tuple(f))
ordered=sorted(bad)
if len(sys.argv)>1:
 low,high=map(int,sys.argv[1:3])
 for j,f in enumerate(ordered):
  if low<=j<high:assert evalf(f)is False;print('replayed',j,flush=True)
out=[i for i,s in enumerate(st)if rem(s,0)!='fanout'and not(bad&fs[i].keys())]
assert out==[0,577,584,585,1154,1168,1170,2308,2336,2340]
print('distinct exact exterior subqueries',len(ordered),'first-stage survivors',out)
if not sys.argv[1:]:
 for omit in (0,256,4096):assert pair([p for p in T if p!=omit])is False
 print('only all-direct remains')
