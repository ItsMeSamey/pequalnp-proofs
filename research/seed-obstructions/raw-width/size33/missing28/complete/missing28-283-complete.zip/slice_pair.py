from paths import *
import sliced2
from functools import cache
def run(H):
 keep=flex.union(sc.domq[p]for p in H);sp=0;O=(6,);S=63;qs=sc.phys
 if not all(keep&sc.domq[q]&sc.meet[u]for q in qs for u in range(6)):return 'unverified baseline'
 if signed((),(),keep,1):return 'zero-or-one'
 F={p:sc.F[p]&sc.on[sc.inc[p]&S]&keep for p in qs}
 B=[v for k in range(len(qs)+1)for v in flex.combinations(qs,k)if not any(F[p]&sc.domq[q]or F[q]&sc.domq[p]for q,p in flex.combinations(v,2))]
 def fit(a,b,rev):
  gs=[a or(-1,),b or(-2,)];pr=[(p,1)for p in (*a,*b)]
  up=[sum(1<<u for u in range(6)if not any(F[p]&sc.tag[u]for p in v))for v in (a,b)]
  def walk(lo,hi):
   if not sliced2.actual((),pr,[lo],[(rev,1-rev)],gs,0,[hi],ordinary=O,keep=keep):return False
   if lo==hi:return lo
   j=max(range(2),key=lambda i:(hi[i]^lo[i]).bit_count());u=(lo[j]^hi[j])&-(lo[j]^hi[j]);uu=hi[:];uu[j]^=u
   r=walk(lo,uu)
   if r is not False:return r
   ll=lo[:];ll[j]|=u;return walk(ll,hi)
  return walk([0,0],up)
 for a in B:
  for b in B:
   if a>b or set(a)&set(b):continue
   for rev in range(2):
    v=fit(a,b,rev)
    if v is not False:return a,b,rev,v
 return False
if __name__=='__main__':
 for omit in (0,256,4096):
  print('start',omit,flush=True);print('result',omit,run([p for p in T if p!=omit]),flush=True)
