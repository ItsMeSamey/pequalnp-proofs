from big2 import *
def init():
 c,w,om,b=pool()[283];w=dict(w);s=Source(0);s.bank(c);dm,M,ss,_=s.roles(om,13);z=set(M)|set(w);T=s.stars[om.bit_length()-1]
 assert set(M)==T and all(q in w or s.no[q,p]or s.no_t[q,p]&om for p in T for q in z if p!=q)
 return c,w,om,z,T
if __name__=='__main__':
 import big2
 c,w,om,z,T=init()
 for pay in [-1,0,*sorted(z)]:
  r={p for p in z if max(2,w.get(p,0))+int(pay==p)-int(p in T)>=2}
  print(pay,fit2(c,om,tuple(sorted(r)),tuple(sorted(r&set(w))),True,(),(),int(pay==0)),'calls',big2.nc,flush=True)
