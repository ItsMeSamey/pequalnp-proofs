# The one-terminal and zero-terminal size-33 frontier

The stratum counts collected one-positive point products in the signed degree-one normal form of a globally size-minimal, then raw-width-minimal residual circuit. A 33-gate residual physical witness would meet the 34-slot official target upon restoring the seed. The proved residual minimum belongs to {33,34}.

The signed four- and three-terminal dispatches exclude every original in those strata. The 27-core theorem and 17,072-label recount leave 4,032 zero-terminal originals, 6,213 one-terminal originals and 138 two-terminal originals. Each surviving two-terminal original omits raw singleton 2. Its projected four-peeled core has at most 28 gates and inherits raw source multiplicities. The two-terminal case requires a separate per-original and per-owner certificate covering these 138 physical preimages.

If the 138-case hypothesis is established, every possible 33-gate circuit has a representative in the zero- or one-terminal strata. There are then 10,245 original labelled candidates before subsequent exclusions inside these strata. Canonical projections have separate multiplicities. The total count does not measure the number of physical circuits.
