import gzip, json
from collections import Counter
from pathlib import Path
src=json.loads(Path('owner138.json').read_text())
counts=Counter();seen=set();keepers=[]; mapping=[]
for i,l in enumerate(gzip.open('terminal-raw-keys.jsonl.gz','rt')):
 t,e,r,c,idx,aliases,limit,peeled=json.loads(l)
 if peeled:continue
 counts[t]+=1
 if t<2:
  assert idx is None
  keepers.append((i,t,e,r,c));continue
 assert t==2 and idx not in seen and limit==28
 row=src[str(idx)]
 assert (e,r,c)==(row['peeled'],row['raw_points'],row['raw_compounds'])
 assert row['owners_0_to_5']=='low-complete' and row['six_stage'] and row['seven_stage']
 seen.add(idx);mapping.append((i,idx))
assert seen==set(map(int,src)) and counts=={0:4032,1:6213,2:138}
assert i==17071 and len(keepers)==10245
with Path('remaining.jsonl').open('w')as f:
 for row in keepers:print(json.dumps(row,separators=(',',':')),file=f)
print('global/local t2 last three',[(a,b) for a,b in mapping if b in (3176,4016,4856)])
print('checked 17072 original bank keys; original t0 4032, t1 6213, t2 138 completely dispatched; retained 10245')
