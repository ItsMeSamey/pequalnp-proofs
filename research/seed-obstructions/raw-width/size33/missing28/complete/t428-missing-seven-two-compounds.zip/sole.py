from weighted import *
from weightedholder import actual
from functools import reduce
C=(129,4160);zt=261;groups=[(1,),(4,),(256,),(-1,)]
def run():
 cells=[set()for _ in range(4)]
 for h,v,k in cuts(P,N,8133,C):cells[sum(1<<C.index(c)for c in h)].add((v,k&~zt))
 @cache
 def allowed(k,v,m):
  return any(all((t&k&~(d if (1<<u)&m else 0)).bit_count()+int(bool(m&(1<<u)))<=2 for u,t in enumerate(stars)if v>>u&1)for d in [sum(t)for t in combinations(bm(k),min(2,k.bit_count()))])
 dom=[]
 for cells_h in cells:
  opts=set(range(128))
  for v,k in sorted(cells_h,key=lambda x:-x[1].bit_count()*x[0].bit_count()):
   opts={m for m in opts if allowed(k,v,m)}
   if not opts:break
  if 0 in opts:opts.add(127)
  dom.append(opts)
 print('per pin',list(map(len,dom)),flush=True)
 n=0
 def walk(D):
  nonlocal n
  n+=1;D=[set(d)for d in D]
  for a,b in ((0,1),(0,2),(1,3),(2,3))*2:
   D[a]={x for x in D[a]if any(not x&~y for y in D[b])}
   D[b]={y for y in D[b]if any(not x&~y for x in D[a])}
  if not all(D):return False
  lo=[[0,0,0,reduce(int.__and__,d)]for d in D];hi=[[0,0,0,reduce(int.__or__,d)]for d in D]
  if not actual(C,[(p,15)for p in bm(zt)],lo,(),groups,0,hi,rawnodes=list(enumerate(bm(zt)))):return False
  cand=[(min(k,len(d)-k),h,u)for h,d in enumerate(D)for u in range(7)if 0<(k:=sum(x>>u&1 for x in d))<len(d)]
  if not cand:return True
  _,h,u=max(cand)
  for x in range(2):
   E=D[:];E[h]={v for v in D[h]if v>>u&1==x}
   if walk(E):return True
  return False
 print('final',walk(dom),n,flush=True)
if __name__=='__main__':run()
