from pathlib import Path
from ast import literal_eval as parse
import subprocess,sys
def run(f):
 x=subprocess.check_output([sys.executable,'-B',f+'.py'])
 assert x==Path(f+'.log').read_bytes()
for f in ['weighted','checksites','sole']:run(f)
a=list(map(parse,Path('weighted.log').read_text().splitlines()))
b=list(map(parse,Path('checksites.log').read_text().splitlines()))
assert len(a)==61 and len({i for _,_,I,_ in a for i in I})==138
assert len(b)==280 and sum(s for _,_,_,s in b)==213
assert [(c,s)for c,w,s,t in b if t and len(c)==2]==[((129,4160),(261,1,(0,),0))]
print('Two-composite seven-owner cases excluded on the 138-lift missing-2 domain.')
