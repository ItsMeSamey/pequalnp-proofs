from flex import *
from itertools import combinations_with_replacement
def assess(c,w,om,b):
 s=Source(0);s.bank(c);dm,M,ss,_=s.roles(om,13-len(c));z=set(M)|set(w)
 direct={p for p in z if p in dm and dm[p]&om and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&om for q in z)}
 for pays in combinations_with_replacement([0,*sorted(z)],b):
  r={p for p in z if max(2,w.get(p,0))+pays.count(p)-int(p in direct)>=2}
  n=tuple(sorted(p for p in r if p in s.phys));co=tuple(sorted(r-set(n)));raw=tuple(p for p in n if p in w)
  if not signed(c,om,n,raw,co,pays.count(0),False):continue
  return pays
 return False
if __name__=='__main__':
 import flex
 tab=pool()
 for j in range(267,284):
  if flex.calls>950:break
  c,w,om,b=tab[j];print(j,assess(c,dict(w),om,b),'calls',flex.calls,flush=True)
