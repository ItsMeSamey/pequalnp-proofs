from branchsp import *
from flex import signed
from itertools import combinations_with_replacement
def one(c,w,om,b):
 s=Source(0);s.bank(c);dm,M,ss,_=s.roles(om,13-len(c));z=set(M)|set(w)
 direct=tuple(sorted(p for p in z if p in dm and dm[p]&om and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&om for q in z)))
 def par(rr):
  n=tuple(sorted(p for p in rr if p in s.phys));return n,tuple(p for p in n if p in w),tuple(sorted(rr-set(n)))
 out=[]
 for pays in combinations_with_replacement([-1,0,*sorted(z)],b-1):
  fs={p:max(2,w.get(p,0))+pays.count(p)for p in z};fy=2+pays.count(-1);sp=pays.count(0)
  rr={q for q in z if fs[q]-int(q in direct)>=2}
  x=chk(c,om,*par(rr),True,(),sp)
  if x:out.append((pays,(),x));continue
  for d in range(1,len(direct)+1):
   for h in combinations(direct,d):
    if set(h)>=s.stars[om.bit_length()-1]:continue
    if fy==2:
     if not signed(c,om,*par(rr|set(h)),sp,False):continue
    elif not chk(c,om,*par(rr|set(h)),True,h,sp):continue
    x=chk(c,om,*par(z),False,h,sp)
    if x:out.append((pays,h,x));break
   else:continue
   break
 return out
if __name__=='__main__':
 import branchsp,flex
 t=pool()
 for j in map(int,sys.argv[1:]):
  c,w,om,b=t[j];print(j,one(c,dict(w),om,b),'calls',branchsp.nc+flex.calls,flush=True)
