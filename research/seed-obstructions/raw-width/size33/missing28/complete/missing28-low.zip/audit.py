from route import *
import re
t=pool(); gg=set()
for l in Path('route-0.log').read_text().splitlines():
 j=int(l.split(' ',1)[0]);ans=literal_eval('['+l.rsplit(' [',1)[1])
 if ans and all(x is False for x in ans):gg.add(j)
for f in sorted(Path('.').glob('cohort-*.log')):
 for l in f.read_text().splitlines():
  m=re.fullmatch(r'(\d+) (\[.*?\]) (\[.*\])',l);assert m
  a=literal_eval(m[2]);v=literal_eval(m[3])
  if all(x is False for x in v):gg.update(a)
data=literal_eval(Path('raw-live.txt').read_text());left=set(t)-{t[j]for j in gg}
print('remaining weighted',sorted(Counter(7-om.bit_count()for c,w,om,b in left).items()))
print('remaining labelled',sorted(Counter(7-om.bit_count()for i,c,w,om,b in data if(c,w,om,b)in left).items()))
print('low-owner banks',len({i for i,c,w,om,b in data if(c,w,om,b)in left}))
Path('open.txt').write_text(repr(sorted(set(range(len(t)))-gg)))
