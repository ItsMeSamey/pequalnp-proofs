#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p replay
cp core.py core-0.json banks.json missing.py rawregional.py route.py cohorts.py tiny.py audit.py replay/
cd replay
python3 missing.py
python3 route.py 0 8 >route-0.log
python3 cohorts.py 0 3 >cohort-03.log
python3 cohorts.py 4 5 >cohort-45.log
python3 audit.py
python3 tiny.py >cohort-tight.log
python3 audit.py
