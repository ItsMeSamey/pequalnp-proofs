from cohorts import *
orig=run
def up(s,O,k,an,limit,w):return orig(s,O,k,an,4000,w=w)
cut.__globals__['run']=up
for om in (127,95):
 ids=set(literal_eval(Path('open.txt').read_text()))
 js=[j for j in edges[om]if j in ids]
 assert all(not table[j][0] for j in js)
 print(om,js,cut(js),flush=True)
