from route import *
from collections import defaultdict
edges=defaultdict(list)
for j,(c,w,om,left) in enumerate(pool()):edges[om].append(j)
table=pool()
def cut(js):
 C=tuple(sorted(set().union(*(set(table[j][0])for j in js))))
 ds=[dict(table[j][1])for j in js]
 w={x:min(d.get(x,1)for d in ds)for x in ds[0]if all(x in d for d in ds)}
 k=max(13-len(table[j][0])for j in js);om=table[js[0]][2];O=tuple(t for t in range(7)if om>>t&1)
 s=Source(0);s.bank(C)
 dm,M,solo,b=s.roles(om,k);anmax=k-(7-len(O))-len(set(M)|set(w))-sum(v-2 for v in w.values())
 ans=[]
 for an in range(anmax+1):
  ans.append(run(s,O,k,an,300,w=w))
  if ans[-1]is not False:break
 return ans
if __name__=='__main__':
 for om,js in sorted(edges.items(),key=lambda kv:-kv[0].bit_count()):
  if not(int(sys.argv[1])<=7-om.bit_count()<=int(sys.argv[2])):continue
  queue=[js]
  while queue:
   block=queue.pop(0);res=cut(block)
   print(om,block,res,flush=True)
   if any(v is not False for v in res)and len(block)>1:
    cs=sorted({table[j][0]for j in block})
    if len(cs)>1:
     for c in cs:queue.append([j for j in block if table[j][0]==c])
    else:
     m=len(block)//2;queue.extend((block[:m],block[m:]))
