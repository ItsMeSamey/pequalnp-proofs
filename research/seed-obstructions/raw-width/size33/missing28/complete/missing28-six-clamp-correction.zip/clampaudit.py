from route import *
from sliced import actual
tab=pool()
for l in Path('clampsub.log').read_text().splitlines():
 i=int(l.split()[0]);c,w,om,b=tab[i];s=Source(0);s.bank(c);w=dict(w)
 dm,M,ss,_=s.roles(om,13-len(c));z=set(M)|set(w);O=(om.bit_length()-1,)
 assert all(not(s.dom(q)&~s.domq[q])for q in s.phys)
 col=s.meet[O[0]]
 dark=all(col&s.domq[q]&s.meet[u]for q in s.phys for u in range(7)if u not in O)
 assert dark
 rr=tuple(sorted(q for q in z if max(2,w.get(q,0))-int(bool(dm[q]&om))>=2))
 assert set(rr)<=w.keys() and all(p in s.phys for p in rr)
 n=1<<len(c);pr=[(q,(1<<n)-1)for q in rr];sig=[[0]*len(rr)for j in range(n)]
 print(i,rr,actual(c,pr,sig,(),[(q,)for q in rr],0,sig,ordinary=O,rawnodes=tuple(enumerate(rr))),flush=True)
