from route import *
from sliced import actual
from itertools import combinations_with_replacement
from functools import cache
@cache
def chk(c,om,rr,raw,sp):
 s=Source(0);s.bank(c);O=(om.bit_length()-1,);K=s.meet[O[0]];n=1<<len(c)
 assert all(not(s.dom(q)&~s.domq[q])for q in s.phys)
 if not all(K&s.domq[q]&s.meet[u]for q in s.phys for u in range(7)if u not in O):return 'baseline'
 z=tuple(q for q in rr if q in s.phys);comp=tuple(q for q in rr if q not in s.phys);F={q:K&s.F[q]&s.on[s.inc[q]&~om]for q in s.phys}
 if any(not(F[q]&s.domq[p])for q in z if q not in raw for p in s.phys if p!=q and p not in z):return 'co-resident'
 cs=[s.dom(sum(1<<library[m]for i,m in enumerate(c)if j>>i&1))for j in range(n)]
 pin=lambda p:sum(1<<i for i,m in enumerate(c)if p&m)
 pr=[(q,(1<<n)-1 if q in raw else sum(1<<j for j in range(n)if j&pin(q)==pin(q)))for q in z]
 gr=[(q,)for q in z]+[(-j-1,)for j in range(len(comp))]
 rn=tuple((j,q)for j,q in enumerate(z)if q in raw)+tuple((len(z)+j,q)for j,q in enumerate(comp))
 lo=[[0]*len(gr)for j in range(n)]
 hi=[[(0 if q in raw else sum(1<<u for u in range(7)if not(F[q]&cs[j]&s.tag[u])))for q in z]+[(127 if j>>c.index(q)&1 else 0)for q in comp]for j in range(n)]
 return actual(c,pr,lo,(),gr,sp,hi,ordinary=O,rawnodes=rn)
def one(c,w,om,b):
 s=Source(0);s.bank(c);dm,M,ss,_=s.roles(om,13-len(c));z=set(M)|set(w)
 d={p for p in z if p in dm and dm[p]&om and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&om for q in z)}
 if not s.stars[om.bit_length()-1]<=d:return []
 out=[]
 for pays in combinations_with_replacement([-1,0,*sorted(z)],b-1):
  rr=tuple(sorted(p for p in z if max(w.get(p,0),2)+pays.count(p)-int(p in d)>=2))
  k=chk(c,om,rr,tuple(q for q in rr if q in w),pays.count(0))
  if k:out.append((pays,rr,k))
 return out
if __name__=='__main__':
 t=pool()
 for j in range(267,284):
  c,w,om,b=t[j];print(j,one(c,dict(w),om,b),flush=True)
