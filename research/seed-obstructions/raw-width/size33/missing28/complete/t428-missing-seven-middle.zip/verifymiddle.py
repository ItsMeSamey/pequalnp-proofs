from zipfile import ZipFile
from pathlib import Path
import sys,subprocess
from ast import literal_eval
with ZipFile('upstream.zip')as z:z.extractall()
for q in ['saturation','funnel']:
 assert subprocess.check_output([sys.executable,'-B',q+'.py'])==Path(q+'.log').read_bytes()
a=list(map(literal_eval,Path('funnel.log').read_text().splitlines()))
assert len(a)==28 and sum(r[3]for r in a)==388 and all(not r[4]for r in a)
print('All 388 licensed housing records reduce to at most 27 gates.')
