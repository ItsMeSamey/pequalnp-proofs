from named import *
from satholder import actual as guard
@cache
def prep(c):
 m=pack(lambda n:all(n>>extra[x]&1 for x in c))
 uc={p:sum(1<<u for u in range(7)if not m&~pt[p]&line(inc[p])&on[u])for p in pts}
 out=[set()for _ in range(7)];hi=[set() for _ in range(7)]
 for h,v,k in cuts(P,N,8133,c):
  for u in range(7):
   if v>>u&1:
    out[u].add(k&stars[u])
    if tuple(h)==c:hi[u].add(k&stars[u])
 return uc,out,hi
def check(c,w,s):
 z,g,ds,sp=s;ps=bm(z);wd=dict(w);names=[p for p in ps if p not in wd]
 uc,sets,hig=prep(c);assert not g and not sp and not any(uc[p]for p in names)
 guards=[]
 for ss in sets:
  dd={d&~z for d in ss}
  guards.append([m for m in dd if not any(m!=b and not m&~b for b in dd)])
 rs=[(i,p)for i,p in enumerate(ps)if p in wd]
 gr=[(p,)for p in ps];LS=[[0]*len(ps)]*2
 sat=tuple(u for u in range(7) if any((k&~z).bit_count()>=2 for k in hig[u]));result=[]
 for fs in product((2,3),repeat=len(names)):
  if fs.count(2)>1:continue
  pr=[(p,3 if p in wd else fs[names.index(p)])for p in ps]
  poses=set();guard(c,pr,LS,(),gr,0,LS,rawnodes=rs,guards=guards,ucap=uc,sat=sat,poses=poses)
  if poses:result.append((fs,sorted(poses)))
 return sat,result
if __name__=='__main__':
 for c,w,s,b in map(literal_eval,Path('checksites.log').read_text().splitlines()):
  if b and c in [(354,),(523,),(1046,),(2092,)]:print((c,w,s,check(c,w,s)),flush=True)
