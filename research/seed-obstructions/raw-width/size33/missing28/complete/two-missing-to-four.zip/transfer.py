from deletion import *
def lifted(e):
 d=dataset(e)
 return [[sum(1<<d['original_wire_ids'][i] for i in bits(x))for x in d[k]]for k in ('positives','maximal_negatives')]
all4=tuple(DEGREE_ONE); P4,N4=lifted(all4); keep=8191^sum(all4)
for e in combinations((8,16,32),2):
 P,N=lifted(e);fixed=(8191^sum(e)^2)|(127<<13)
 R=8191^sum(e)
 opt=[i for i in range(20,38) if not any(m!=masks[i] and not m&~masks[i] and not((m^masks[i])&R) for m in [0,*masks.values()])]
 base=[i for i in opt if masks[i] in (3,6,258)]
 hist=Counter();out=set()
 for k in range(3):
  for add in combinations([i for i in opt if i not in base],k):
   cs=base+list(add); bank=fixed|sum(1<<c for c in cs)
   if not all(p&~n&bank for p in P for n in N):continue
   sub={c:min([j for j,m in masks.items() if not m&~masks[c] and not (m^masks[c])&keep],key=lambda j:(masks[j].bit_count(),j)) if masks[c]&keep else -1 for c in cs}
   def proj(r):
    return r&fixed&~sum(all4) |sum(1<<c for c,j in sub.items() if j>=0 and r>>j&1)
   assert all(j>=0 for j in sub.values())
   assert {masks[c]:masks[sub[c]] for c in base}=={3:1,6:4,258:256}
   pp=all(any(not p&bank&~proj(r) for p in P)for r in P4)
   nn=all(any(not proj(r)&~n for n in N)for r in N4)
   hist[k,pp,nn]+=1
   if pp and nn:out.add(tuple(sorted(masks[j] for j in set(sub.values()) if j>=20)))
 print(e,hist, sorted(out))
