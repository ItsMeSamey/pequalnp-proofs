from itertools import combinations
from collections import Counter
from minors import dataset,DEGREE_ONE
from functools import reduce
from operator import and_
from pathlib import Path
import argparse

A=[3<<i for i in range(6)]
B=[1<<(i+3)|1<<((i+9)%13) for i in range(6)]
masks={**{i:1<<i for i in range(13)},**dict(enumerate(A+B+[a|b for a,b in zip(A,B)],20))}
def bits(mask):
    while mask:
        v=mask&-mask;yield v.bit_length()-1;mask^=v
def trial(peeled,missing):
    d=dataset(peeled);ids=d['original_wire_ids']
    def decode(x):return sum(1<<ids[i]for i in bits(x))
    P=list(map(decode,d['positives']));N=list(map(decode,d['maximal_negatives']))
    units=[i for i in ids if i<13 and not (i==1 and missing)]
    flags=list(range(13,20));fixed=sum(1<<i for i in units+flags)
    retain=8191^sum(peeled)
    permitted=[i for i in range(20,38) if not any(m!=masks[i] and not m&~masks[i] and not((m^masks[i])&retain) for m in [0,*masks.values()])]
    if missing and 2 in peeled:return
    poss=[0]+[1<<u for u in ids]
    def prep(rows,reference,reverse):
        ans={}
        for r in rows:
            base=[j for j,s in enumerate(reference)if not (((r&~s)if reverse else(s&~r))&fixed)]
            for c in permitted:
                if bool(r>>c&1)==reverse:continue
                b0=[j for j in base if bool(reference[j]>>c&1)==reverse]
                blocks=[sum(1<<w for w in permitted if (((r&~reference[j]) if reverse else (reference[j]&~r))>>w&1))for j in b0]
                # A witness protects the changed sample whenever its extra differences avoid the bank.
                blocks=tuple(sorted(set(blocks),key=int.bit_count))
                mins=[]
                for b in blocks:
                    if not any(not a&~b for a in mins):mins.append(b)
                if 0 not in mins:ans.setdefault(c,[]).append((r,tuple(mins)))
        return ans
    prows=prep(P,P,False);nrows=prep(N,N,True)
    # Every admitted bank must separate each retained positive from each signed negative.
    residual={sum(1<<c for c in permitted if (p&~n)>>c&1) for p in P for n in N if not(p&~n&fixed)}
    maxcomp=17-len(peeled)-len(units)
    must={i for i,m in masks.items() if m in (3,6,258)} if missing else set()
    hist=Counter();moves=[]
    for k in range(maxcomp+1):
        for cs in combinations(permitted,k):
            if not must.issubset(cs):continue
            bank=sum(1<<c for c in cs)
            if any(not b&bank for b in residual):continue
            hist['banks']+=1;direct=[];shifts=[]
            for c in cs:
                # All replacement columns that meet every weak positive/negative comparison.
                js=(1<<38)-1;can_zero=True
                for r,blocks in prows.get(c,()):
                    if not any(not b&bank for b in blocks):js&=r;can_zero=False
                for r,blocks in nrows.get(c,()):
                    if not any(not b&bank for b in blocks):js&=~r
                src=(fixed|bank)^(1<<c)
                direct.extend((c,j) for j in bits(js&src))
                if can_zero:direct.append((c,-1))
                for j in bits(js&~(fixed|bank)):
                    if j in masks and j in ids and masks[j].bit_count()<masks[c].bit_count():
                        shifts.append((c,j))
            if direct:hist['delete']+=1
            elif shifts:hist['outside']+=1
            if direct or shifts:moves.append((tuple(masks[c]for c in cs),direct,shifts))
    return hist,moves
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('t',type=int);ap.add_argument('idx',type=int);a=ap.parse_args()
    e=list(combinations(DEGREE_ONE,a.t))[a.idx]
    for missing in (False,True):
        res=trial(e,missing)
        if res:
            h,ms=res; print(e,missing,dict(h),'examples',ms[:2],flush=True)
