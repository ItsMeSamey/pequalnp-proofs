from ast import literal_eval
from itertools import combinations,combinations_with_replacement
from pathlib import Path
R=8133;S=[708,1408,2816,5632,3137,6272,4357]
def bm(x):return [1<<k for k in range(x.bit_length()) if x>>k&1]
def layouts(s):
 z,g,ds,sp=s;Q=R^z
 for n in range(min(2+ds[-1],Q.bit_count())+1):
  for D in map(sum,combinations(bm(Q),n)):
   for m in range(128):
    if not m and D:continue
    req=[1+(t&Q&~D).bit_count() if m>>u&1 else (t&Q).bit_count()+int(bool(t&Q and t&z))for u,t in enumerate(S)]
    over=[max(0,k-2)for k in req];rem=sp-sum(over)
    if rem<0:continue
    for more in combinations_with_replacement(range(7),rem):yield m,D,tuple(x+more.count(u)for u,x in enumerate(over))
if __name__=='__main__':
 for w,s in literal_eval(Path('emptycompact.txt').read_text()):
  if s[1]==1:print((w,s,list(layouts(s))),flush=True)
