from zipfile import ZipFile
from pathlib import Path
from ast import literal_eval as ev
import subprocess,sys
with ZipFile('upstream.zip') as z:z.extractall()
with ZipFile('mitm-proof.zip')as z:
 f=next(k for k in z.namelist()if k.endswith('multi.cpp') and not k.endswith('make_multi.cpp'));Path('multi.cpp').write_bytes(z.read(f))
def run(cmd,**kw):return subprocess.check_output(cmd,**kw)
run([sys.executable,'-B','makemulti.py'])
run(['g++','-std=c++17','-O2','multi.cpp','-o','multi'])
coarse=run(['./multi'],input=Path('multi.in').read_bytes());assert coarse==Path('multi.out').read_bytes()
keys=ev(Path('multi.keys').read_text());assert len(keys)==152
live=[]
for (w,s),line in zip(keys,coarse.splitlines()):
 g,z,sp,best=map(int,line.split());assert (z,g,sp)==(s[0],s[1],s[3])
 if best<=sp:live.append((w,s))
assert len(live)==47;Path('emptycompact.txt').write_text(repr(live))
for f in ('singlelayout','cleanone'):
 assert run([sys.executable,'-B',f+'.py'])==Path(f+'.log').read_bytes()
one=list(map(ev,Path('cleanone.log').read_text().splitlines()));assert len(one)==33 and sum(len(q)for w,s,q in one)==250 and all(u is not None for w,s,q in one for flags,u in q)
jobs={(z,g,sp,*sorted(2+d for d in ds[-g:]))for w,(z,g,ds,sp)in live if g>=2}
inp=''.join(' '.join(map(str,x))+'\n'for x in sorted(jobs,key=lambda x:(x[1],x))).encode()
assert inp==Path('cleanmulti.in').read_bytes() and len(jobs)==9
run(['g++','-std=c++17','-O2','cleanmulti.cpp','-o','cleanmulti'])
out=run(['./cleanmulti'],input=inp);assert out==Path('cleanmulti.log').read_bytes()
assert all(line.startswith(b'done') and line.endswith(b' 0')for line in out.splitlines())
print('Empty bank: 152 weighted allocations, 47 coarse survivors, 0 final survivors.')
