from ast import literal_eval
from pathlib import Path
r=[]
for c,w,s,b in map(literal_eval,Path('checksites.log').read_text().splitlines()):
 if not c and b:r.append((w,s))
with open('multi.in','w')as f:
 print(708,1408,2816,5632,3137,6272,4357,file=f)
 for w,(z,g,ds,sp)in r:print(g,z,8133^z,sp,*([2+x for x in ds[-g:]]if g else []),file=f)
Path('multi.keys').write_text(repr(r))
