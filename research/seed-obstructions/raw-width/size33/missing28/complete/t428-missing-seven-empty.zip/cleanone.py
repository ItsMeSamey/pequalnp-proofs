from singlelayout import *
def check(s,key):
 m,D,b=key;z,g,ds,sp=s;Q=R^z
 assert m and D.bit_count()==2+ds[-1]
 tight=[u for u,t in enumerate(S)if (int(bool(m>>u&1))+(t&Q&~(D if m>>u&1 else 0)).bit_count()==2+b[u])]
 clean=0
 for u in tight:clean|=S[u]&Q
 for u in tight:
  if not z&S[u]:continue
  affected=(S[u]&Q)|(D if m>>u&1 else 0)
  if not affected&~clean:return u
 return None
if __name__=='__main__':
 for w,s,rr in map(literal_eval,Path('singlelayout.log').read_text().splitlines()):
  print((w,s,[(k,check(s,k))for k in rr]),flush=True)
