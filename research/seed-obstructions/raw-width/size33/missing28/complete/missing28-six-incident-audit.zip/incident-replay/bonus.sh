set -eu
for p in 0 -1; do
 python bigbonus.py "$p" >"incident-replay/bigbonus-$p.log"
 cmp "bigbonus-$p.log" "incident-replay/bigbonus-$p.log"
done
python bigbonus.py -2 800 >incident-replay/bigbonus--2.log
cmp bigbonus--2.log incident-replay/bigbonus--2.log
python bigbonus.py -2 600 211 >incident-replay/bigbonus--2-tail.log
cmp bigbonus--2-tail.log incident-replay/bigbonus--2-tail.log
wc -l incident-replay/bigbonus*.log
