from core import Source
s=Source(0)
s.bank(())
checks=0
for t,negative_slice in enumerate(s.meet):
 ordinary=1<<t
 for q in s.phys:
  old=negative_slice&s.F[q]&s.on[127^ordinary]
  new=negative_slice&s.F[q]&s.on[s.inc[q]&~ordinary]
  assert old==new,(t,q,old^new)
  checks+=1
print('bitwise equal on all',checks,'point/ordinary pairs and',len(s.ns),'original raw rows')
