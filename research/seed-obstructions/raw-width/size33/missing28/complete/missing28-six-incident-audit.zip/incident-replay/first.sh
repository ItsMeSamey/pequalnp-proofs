set -eu
python last267.py > incident-replay/last267.log
cmp last267.log incident-replay/last267.log
python lastall.py 268 269 270 272 > incident-replay/last-four.log
cmp last-four.log incident-replay/last-four.log
python partial271.py > incident-replay/partial271.log
cmp partial271.log incident-replay/partial271.log
python partialother.py > incident-replay/partialother.log
cmp partialother.log incident-replay/partialother.log
wc -l incident-replay/{last267,last-four,partial271,partialother}.log
