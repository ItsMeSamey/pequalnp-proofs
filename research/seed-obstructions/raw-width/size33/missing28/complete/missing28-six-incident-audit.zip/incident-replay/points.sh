set -eu
for p in 1 4 256 4096; do
 python bigprivate.py "$p" >"incident-replay/bigprivate-$p.log"
 cmp "bigprivate-$p.log" "incident-replay/bigprivate-$p.log"
done
wc -l incident-replay/bigprivate-*.log
