# Missing singleton 2, six mandatory owners

The scope is the 138 original two-terminal lifts in the missing-singleton-2 class under the four-terminal 28-gate transfer. The at-most-five-owner certificate is missing28-low-complete.zip in the adjacent peeled4-28 directory.

Read missing28-six-through-one.zip for the 597 physical bank/ordinary assignments and their 284 distinct weighted cases. The original one-helper proofs must be read with missing28-six-clamp-correction.zip, which rechecks every affected mandatory local comparison on the retained negative rows. It also corrects the one-helper checks from missing28-six-extra-helpers.zip. Use the correction for all ten contested one-spare cases and all 17 high-spare cases.

The subsequent original-table and sliced proofs in missing28-six-267.zip, missing28-six-ten-pure.zip, and missing28-six-compounds.zip eliminate the remaining two-spare IDs 267 through 282 inclusive. ID283 remains the sole open six-owner allocation. The physical source rows mapping to it are 3176, 4016, and 4856. Every other original lift in the class requires seven mandatory owners. The result is conditional on independent proof review. Seven-owner feasibility is tracked separately.
