from route import *
from itertools import product
from functools import cache
import spec_orig_two as orig,spec_ext_two as ext
nc=0
@cache
def run2(c,om,named,raw,ex,Y,X=()):
 global nc
 assert len(c)==1
 s=Source(0);s.bank(c);S=127^om;O=(om.bit_length()-1,);hs=range(2)
 cs=[s.full,s.dom(1<<library[c[0]])];target=s.on[S]&s.Ehits[om]if ex else s.full
 F={p:target&s.F[p]for p in s.phys};qlo=tuple(q for q in s.phys if q not in named)
 if any(not(s.no[p,q]or s.no_t[p,q]&om)for p in named if p not in raw for q in qlo):return 'cross'
 loc=[b for d in range(len(qlo)+1 if ex else 2)for b in combinations(qlo,d)if not any(F[p]&s.domq[q]or F[q]&s.domq[p]for p,q in combinations(b,2))]
 rs=tuple((j,p)for j,p in enumerate(named)if p in raw)
 base=ext.actual if ex else orig.actual
 orig_upper=[[0 if p in raw else sum(1<<u for u in range(7)if S>>u&1 and not s.F[p]&cs[j]&s.tag[u])for p in named]for j in hs]
 for a in loc:
  if any(F[p]&s.domq[x]for p in a for x in X):continue
  for b in loc:
   if set(a)&set(b)or(not X and not Y and a>b)or any(F[p]&s.domq[y]for p in b for y in Y):continue
   gs=[(p,)for p in named]+[a or(-1,),b or(-2,)]
   pr=[(p,3 if p in raw or not(p&c[0])else 2)for p in (*named,*a,*b)]
   for cx,cy in product(hs,repeat=2):
    const=(cx,cy);Bs=(a,b)
    if any(v and any(F[p]&cs[1]for p in bs)for v,bs in zip(const,Bs)):continue
    LL=[];UU=[]
    for j in hs:
     for g,bs in enumerate(Bs):
      LL.append(S if j and const[g]else 0)
      UU.append(S if j and const[g]else sum(1<<u for u in range(7)if S>>u&1 and not any(F[p]&cs[j]&s.tag[u]for p in bs)))
    off=len(named)
    def walk(low,up,rev):
     global nc
     nc+=1
     if nc+__import__('branchsp').nc+__import__('flex').calls>1200:raise TimeoutError
     edges=[(off+rev,off+1-rev)]+[(i,j)for i in range(off)for j in (off,off+1)]
     lo=[[0]*off+[low[2*j],low[2*j+1]]for j in hs]
     hi=[orig_upper[j]+[up[2*j],up[2*j+1]]for j in hs]
     for g in (0,1):
      if const[g]:lo[1][off+g]=0
     v=base(c,pr,lo,edges,gs,0,hi,ordinary=O,rawnodes=rs,before_high=union(s.domq[p]for p in X)|(cs[1]if cx else 0),special_high=union(s.domq[p]for p in Y)|(cs[1]if cy else 0))
     if not v:return False
     if low==up:return (a,b,const,low,rev)
     k=max(range(4),key=lambda i:(low[i]^up[i]).bit_count());f=(low[k]^up[k])&-(low[k]^up[k]);j,g=divmod(k,2)
     h=up[:];l=low[:]
     for state in hs:
      if state<=j:h[2*state+g]&=~f
      if state>=j:l[2*state+g]|=f
     if all(not x&~y for x,y in zip(low,h)):
      v=walk(low,h,rev)
      if v:return v
     if all(not x&~y for x,y in zip(l,up)):return walk(l,up,rev)
     return False
    for rev in hs:
     v=walk(LL,UU,rev)
     if v:return v
 return False
def direct(c,w,om):
 s=Source(0);s.bank(c);dm,M,ss,_=s.roles(om,13-len(c));z=set(M)|set(w)
 D={p for p in z if p in dm and dm[p]&om and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&om for q in z)}
 r={q for q in z if max(2,w.get(q,0))-int(q in D)>=2}
 return run2(c,om,tuple(sorted(r)),tuple(sorted(r&set(w))),True,())
if __name__=='__main__':
 t=pool()
 for j in map(int,sys.argv[1:]):
  c,w,om,b=t[j];print(j,direct(c,dict(w),om),'calls',nc,flush=True)
