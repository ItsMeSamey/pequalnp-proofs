from route import *
from exterior import check
from functools import cache
@cache
def admiss(c,om):
 s=Source(0);s.bank(c)
 return check(s,tuple(t for t in range(7)if om>>t&1))
if __name__=='__main__':
 tab=pool()
 for j in literal_eval(Path('open.txt').read_text()):
  c,w,om,b=tab[j];O=tuple(t for t in range(7)if om>>t&1)
  if admiss(c,om):print(j,'binary',flush=True);continue
  s=Source(0);s.bank(c)
  arr=[]
  for an in range(b+1):
   arr.append(run(s,O,13-len(c),an,300,retain=True,w=dict(w)))
   if arr[-1]is True:break
  print(j,arr,flush=True)
