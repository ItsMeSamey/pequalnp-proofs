from route import *
t=pool();gone=set();present=set(literal_eval(Path('open.txt').read_text()))
for f in ('retained.log','close4.log'):
 for l in Path(f).read_text().splitlines():
  j,a=l.split(' ',1)
  if a!='binary' and all(s is False for s in literal_eval(a)):gone.add(int(j))
g={t[j] for j in present-gone};a=literal_eval(Path('raw-live.txt').read_text())
print('weighted',Counter((7-o.bit_count(),len(c),b)for c,w,o,b in g))
print('labelled',Counter(7-o.bit_count()for i,c,w,o,b in a if(c,w,o,b)in g))
print('banks',len({i for i,c,w,o,b in a if(c,w,o,b)in g}))
print('basis/ordinary',Counter((c,o)for c,w,o,b in g))
Path('after-splice.txt').write_text(repr(sorted(present-gone)))
