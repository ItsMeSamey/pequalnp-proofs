from retained import *
t=pool()
for j in [214,226,231]:
 c,w,om,b=t[j];s=Source(0);s.bank(c);O=tuple(t for t in range(7)if om>>t&1)
 assert not admiss(c,om) and b==1
 print(j,[False,run(s,O,13-len(c),1,5000,retain=True,w=dict(w))],flush=True)
