from ast import literal_eval
from pathlib import Path
out={}
for suffix in ('first','second','final'):
 signed=(Path('resid-'+suffix+'.log').read_text().splitlines())
 choices=Path('two-'+suffix+'.log').read_text().splitlines()
 assert len(signed)==len(choices)
 for t,w in zip(choices,signed):
  i,an,status,profiles=t.split(' ',3);j,b,n,left=w.split(' ',3)
  assert (i,an)==(j,b) and status=='False' and not literal_eval(left)
  ps=literal_eval(profiles)
  mx=[(r,ex)for r,ex in ps if not any((set(r)<set(q)and ex<=e)or(set(r)<=set(q)and ex<e)for q,e in ps)]
  assert len(mx)==int(n) and (int(i),int(an))not in out
  out[int(i),int(an)]=len(mx)
assert set(out)=={(i,a)for i in range(445,455)for a in range(3)}
print('10 weighted cases, 30 completed SAT poses,',sum(out.values()),'maximal profiles, 0 surviving')
