from exactrelay import relay
from one import verdict
from route import *
def read(path):
 table=pool()
 for l in Path(path).read_text().splitlines():
  j,an,status,ps=l.split(' ',3);j=int(j);assert status=='False'
  arr=literal_eval(ps)
  maximal=[(q,ex)for q,ex in arr if not any((set(q)<set(qq)and ex<=ee) or (set(q)<=set(qq)and ex<ee)for qq,ee in arr)]
  c,w,om,b=table[j];w=dict(w);assert not c
  rem=[]
  for r,sp in maximal:
   import one,exactrelay
   if one.calls+exactrelay.counter>1160:raise TimeoutError
   z=tuple(sorted(x for x in r if x>0));h=sum(x<0 for x in r);raw=tuple(x for x in z if x in w)
   if h==0:ok=verdict(om,z,raw,sp,False)
   elif h==1 and not sp:ok=relay(om,z,raw)
   else:ok='open'
   if ok:rem.append((r,sp,ok))
  print(j,an,len(maximal),rem,flush=True)
if __name__=='__main__':read(sys.argv[1])
