from route import *
from resources import run as resources
t=pool()
for j in map(int,sys.argv[1:]):
 c,w,om,b=t[j];s=Source(0);s.bank(c);O=tuple(u for u in range(7)if om>>u&1)
 for an in range(b+1):
  status,ps=resources(s,O,13,an,500,retain=True,w=dict(w))
  print(j,an,status,ps,flush=True)
