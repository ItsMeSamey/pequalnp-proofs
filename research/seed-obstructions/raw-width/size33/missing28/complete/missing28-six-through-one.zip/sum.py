from route import *
t=pool();orig=literal_eval(Path('raw-live.txt').read_text())
gone={int(l.split()[0])for l in Path('cost.log').read_text().splitlines()if 'False' in l}
for filename in ('retained.log','residual.log'):
 f=Path(filename)
 if not f.exists():continue
 for l in f.read_text().splitlines():
  z,r=l.split(' ',1)
  if r!='binary' and all(x is False for x in literal_eval(r)):gone.add(int(z))
keep=[i for i in range(len(t))if i not in gone]
cases={t[i] for i in keep};rows=[x for x in orig if x[3].bit_count()==1 and x[1:]in cases]
print('weighted, labelled, original banks',len(cases),len(rows),len({i for i,*_ in rows}))
print('composite count / free units',sorted(Counter((len(c),b)for c,w,om,b in cases).items()))
Path('open.txt').write_text(repr(keep))
