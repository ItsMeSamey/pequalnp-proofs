#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 missing.py
python3 cost.py >cost.log
python3 sum.py
python3 zero.py >zero.log
python3 flex.py >flex.log
python3 branching.py 0 12 >branch-first.log
python3 branching.py 12 83 >branch-next.log
python3 branch_end.py 83 101 >branch-end.log
python3 clampsub.py branch-first.log branch-next.log branch-end.log >clampsub.log
python3 current.py
