from route import *
t=pool();gone=set()
for ln in Path('cost.log').read_text().splitlines():
 if 'False' in ln:gone.add(int(ln.split()[0]))
for ln in Path('zero.log').read_text().splitlines():
 j,r=ln.split();assert r=='False';gone.add(int(j))
xa=set();gg=set()
for s in ('first','next','end'):
 for ln in Path('branch-'+s+'.log').read_text().splitlines():
  j,r=ln.split(' ',1);assert int(j)not in xa;xa.add(int(j))
  if r.startswith('False '):gg.add(int(j))
for ln in Path('clampsub.log').read_text().splitlines():
 j,r=ln.split(' ',1);assert r.startswith('False ') and int(j) not in gg;gg.add(int(j))
assert xa==gg and len(gg)==101;gone.update(gg)
k=set(range(len(t)))-gone;assert k==set(range(267,284))
a=literal_eval(Path('raw-live.txt').read_text());keep={t[j]for j in k}
ss=[x for x in a if x[3].bit_count()==1 and x[1:]in keep]
print(len(ss),'line assignments;',len({i for i,*_ in ss}),'original bank rows;',sorted({i for i,*_ in ss}))
for j in sorted(k):print(j,t[j],sum(x[1:]==t[j]for x in ss))
