from route import *
from extkw import actual
def trial(s,c,w,om,b):
 O=tuple(t for t in range(7)if om>>t&1);assert len(O)==1 and b==0
 w=dict(w);dm,M,ds,_=s.roles(om,13-len(c));z=set(M)|set(w)
 def direct(p):
  return all(q==p or q in w or s.no[q,p] or s.no_t[q,p]&om for q in z)
 rr={p for p in z if max(2,w.get(p,0))-int(p in dm and dm[p]&om!=0 and direct(p))>=2}
 if not rr<=set(w):return 'nonliteral',sorted(rr-set(w))
 sp=tuple(sorted(p for p in rr if p in s.phys));co=tuple(sorted(rr-set(sp)))
 G=[(p,)for p in sp]+[(-j-1,)for j in range(len(co))]
 raw=tuple(enumerate((*sp,*co)))
 h=1<<len(c)
 # A pure singleton remains high on its own probe at every compound-pin state.
 pr=[(p,(1<<h)-1)for p in sp]
 lo=[[0]*len(G)for j in range(h)]
 hi=[[0]*len(sp)+[127 if j>>c.index(p)&1 else 0 for p in co]for j in range(h)]
 return actual(c,pr,lo,(),G,0,hi,ordinary=O,rawnodes=raw)
if __name__=='__main__':
 tab=pool()
 for i in literal_eval(Path('open.txt').read_text()):
  c,w,om,b=tab[i]
  if b:continue
  s=Source(0);s.bank(c)
  print(i,trial(s,c,w,om,b),flush=True)
