from route import *
from rawholder import actual,pack,on
from itertools import product
ncalls=0
def poss(s,c,w,om,k):
 w=dict(w);dm,M,solo,bb=s.roles(om,k)
 O=tuple(t for t in range(7)if om>>t&1)
 fixed=tuple(sorted(set(M)|set(w).intersection(s.phys)))
 rawc=tuple(q for q in w if q not in s.phys)
 b=k-(7-len(O))-len(fixed)-len(rawc)-sum(v-2 for v in w.values())
 assert b>=0
 nst=1<<len(c)
 cs=[pack(lambda n,j=j:all(not j>>k&1 or n>>library[m]&1 for k,m in enumerate(c)))for j in range(nst)]
 ids={p:sum(1<<i for i,m in enumerate(c)if m&p)for p in s.phys}
 up={p:[sum(1<<u for u in range(7)if not(s.F[p]&s.tag[u]&q))for q in cs]for p in s.phys}
 # s.F uses core.N order; cs uses geometry.N which is identical. 
 for d in range(b+1):
  for zz in combinations([p for p in s.phys if p not in fixed],d):
   z=(*fixed,*zz);pr=[(p,sum(1<<j for j in range(nst)if ids[p]&j==ids[p]))for p in z]
   for an in range(b-d+1):
    gr=[(p,)for p in z]+[(-v-1,)for v in range(len(rawc)+an)]
    raw=[(j,p)for j,p in enumerate(z)if p in w]+[(len(z)+j,p)for j,p in enumerate(rawc)]
    lo=[[0]*len(gr)for j in cs]
    hi=[[(0 if p in w else up[p][j])for p in z]+[(127 if j>>c.index(q)&1 else 0)for q in rawc]+[127]*an for j in range(nst)]
    global ncalls
    ncalls+=1
    if ncalls>1600:raise RuntimeError('resource cap')
    result=actual(c,pr,lo,(),gr,b-d-an,hi,ordinary=O,rawnodes=raw)
    if result:return zz,an
 return False
if __name__=='__main__':
 lo,hi,r=map(int,sys.argv[1:4]);tab=pool()
 for j in literal_eval(Path('open.txt').read_text()):
  if not lo<=j<hi:continue
  c,w,om,b=tab[j]
  if 7-om.bit_count()!=r:continue
  s=Source(0);s.bank(c);print(j,c,w,om,'price',poss(s,c,w,om,13-len(c)),flush=True)
