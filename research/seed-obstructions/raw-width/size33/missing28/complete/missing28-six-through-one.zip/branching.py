from flex import *
from spec_ext import actual as extbase
from spec_orig import actual as fullbase
from functools import cache
nc=0
@cache
def chk(c,om,named,raw,co,ext,Y):
 global nc
 s=Source(0);s.bank(c);O=tuple(u for u in range(7)if om>>u&1);S=127^om;H=1<<len(c)
 cs=[pack(lambda n,j=j:all(not j>>a&1 or n>>library[m]&1 for a,m in enumerate(c)))for j in range(H)]
 qpin={q:sum(1<<a for a,m in enumerate(c)if q&m)for q in s.phys}
 F={q:(s.F[q]&s.on[s.inc[q]&S]&s.Ehits[om]if ext else s.F[q])for q in s.phys}
 qs=[q for q in s.phys if q not in named]
 if any(not(s.no[q,p] or s.no_t[q,p]&om)for q in named if q not in raw for p in qs):return 'cross'
 un=[[0 if q in raw else sum(1<<u for u in range(7)if not(s.F[q]&cs[j]&s.tag[u]))for q in named]+[127 if j>>c.index(q)&1 else 0 for q in co]for j in range(H)]
 nr=tuple((i,p)for i,p in enumerate(named)if p in raw)+tuple((i+len(named),p)for i,p in enumerate(co))
 base=extbase if ext else fullbase
 for d in range(len(qs)+1 if ext else 2):
  for B in combinations(qs,d):
   if any(F[q]&s.domq[p]or F[p]&s.domq[q]for p,q in combinations(B,2)):continue
   if any(F[q]&s.domq[y]for q in B for y in Y):continue
   orig=[[0]*len(un[j])for j in range(H)]
   z=(*named,*B);gr=[(p,)for p in named]+[(-j-1,)for j in range(len(co))]+[B or(-100,)]
   pr=[(p,(1<<H)-1 if p in raw else sum(1<<j for j in range(H)if j&qpin[p]==qpin[p]))for p in z]
   upper=[sum(1<<u for u in range(7)if S>>u&1 and not any(F[p]&cs[j]&s.tag[u]for p in B))for j in range(H)]
   for mask in range(0,1<<H,2):
    con=[j for j in range(H)if mask>>j&1]
    if any(j&q==j and q not in con for j in con for q in range(H)):continue
    if any(F[p]&cs[j] for p in B for j in con):continue
    hi=[S if j in con else upper[j]for j in range(H)]
    lo=[S if j in con else 0 for j in range(H)]
    high=union(cs[j]for j in con)|union(s.domq[p]for p in Y)
    # Prior named suppliers with licensed tags can feed the extra relay.
    edges=tuple((i,len(gr)-1)for i in range(len(gr)-1))
    def walk(lo,hi):
     global nc
     nc+=1
     if nc>1500:raise TimeoutError
     if not base(c,pr,[orig[j]+[lo[j]]for j in range(H)],edges,gr,0,[un[j]+[hi[j]]for j in range(H)],ordinary=O,rawnodes=nr,special_high=high,allowcost=con):return False
     if lo==hi:return (B,con,lo)
     j=next(i for i in range(H)if lo[i]!=hi[i]);u=(lo[j]^hi[j])&-(lo[j]^hi[j])
     lh=[x|u if k&j==j else x for k,x in enumerate(lo)]
     hh=[x&~u if k&j==k else x for k,x in enumerate(hi)]
     if all(not a&~b for a,b in zip(lo,hh)):
      t=walk(lo,hh)
      if t:return t
     return walk(lh,hi)if all(not a&~b for a,b in zip(lh,hi))else False
    ans=walk(lo,hi)
    if ans:return ans
 return False
def solve(c,w,om):
 s=Source(0);s.bank(c);dm,M,ss,_=s.roles(om,13-len(c));z=set(M)|set(w)
 direct={p for p in z if p in dm and dm[p]&om and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&om for q in z)}
 def params(rr):
  n=tuple(sorted(p for p in rr if p in s.phys));return n,tuple(p for p in n if p in w),tuple(sorted(rr-set(n)))
 r={p for p in z if max(2,w.get(p,0))-int(p in direct)>=2}
 x=chk(c,om,*params(r),True,())
 if x:return 'exterior',x
 for p in sorted(direct):
  x=chk(c,om,*params(z),False,(p,))
  if x:return 'private',p,x
 return False
if __name__=='__main__':
 tab=pool();ids=[j for j in literal_eval(Path('open.txt').read_text())if tab[j][3]==1]
 for j in ids[int(sys.argv[1]):int(sys.argv[2])]:
  c,w,om,b=tab[j];print(j,solve(c,dict(w),om),'calls',nc,flush=True)
