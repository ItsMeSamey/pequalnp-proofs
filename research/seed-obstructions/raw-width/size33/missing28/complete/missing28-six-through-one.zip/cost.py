from price import *
import price
tab=pool()
for j,(c,w,om,b) in sorted(enumerate(tab),key=lambda z:z[1][3]):
 if price.ncalls>950:break
 s=Source(0);s.bank(c)
 print(j,c,om,b,poss(s,c,w,om,13-len(c)),price.ncalls,flush=True)
