from branching import *
from flex import signed
def subset(c,w,om):
 s=Source(0);s.bank(c);dm,M,ss,_=s.roles(om,13-len(c));z=set(M)|set(w)
 direct={p for p in z if p in dm and dm[p]&om and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&om for q in z)}
 def params(rr):
  n=tuple(sorted(p for p in rr if p in s.phys));return n,tuple(p for p in n if p in w),tuple(sorted(rr-set(n)))
 r={p for p in z if max(2,w.get(p,0))-int(p in direct)>=2}
 for d in range(1,len(direct)+1):
  for h in combinations(sorted(direct),d):
   if set(h)>=s.stars[om.bit_length()-1]:continue
   if not signed(c,om,*params(r|set(h)),0,False):continue
   import branching,flex
   if branching.nc+flex.calls>350:raise TimeoutError
   x=chk(c,om,*params(z),False,h)
   if x:return h,x
 return False
if __name__=='__main__':
 import branching,flex
 t=pool()
 for fn in sys.argv[1:]:
  for l in Path(fn).read_text().splitlines():
   if "'private'" not in l:continue
   j=int(l.split()[0]);c,w,om,b=t[j]
   print(j,subset(c,dict(w),om),'calls',branching.nc+flex.calls,flush=True)
