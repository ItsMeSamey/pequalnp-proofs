from pathlib import Path
from itertools import product
import ast
expected=list(product(range(4),repeat=4))[1:]
for pay in (1,4,256,4096,0,-1,-2):
 stem='bigprivate' if pay>0 else 'bigbonus'
 files=[Path(f'{stem}-{pay}.log')]
 if pay==-2:files.append(Path('bigbonus--2-tail.log'))
 rows=[row for f in files for row in f.read_text().splitlines()]
 assert len(rows)==255
 for idx,(line,route) in enumerate(zip(rows,expected),1):
  key,v=line.split(' ',1); pose,verdict,calls=v.rsplit(' ',2)
  assert int(key)==idx and ast.literal_eval(pose)==route and verdict=='False' and int(calls)>0
 print(pay,len(rows),'excluded')
