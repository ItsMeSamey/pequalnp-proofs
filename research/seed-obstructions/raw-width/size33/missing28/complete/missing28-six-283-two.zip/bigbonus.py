from bigclean import init
import big2,branchsp,flex,bigpost as last267
from itertools import product
import sys
c,w,om,z,T=init()
T=sorted(T)
s=last267.sc
pay=int(sys.argv[1])
cap=int(sys.argv[2]) if len(sys.argv)>2 else 1200
assert pay in (0,-1,-2)
sp=int(pay==0)
def params(r):
 return tuple(sorted(r)),tuple(sorted(r&set(w)))
def calls():
 return big2.nc+branchsp.nc+flex.calls+last267.nc
def gate(fn):
 def limited(*args,**kw):
  if calls()>cap:raise TimeoutError
  return fn(*args,**kw)
 return limited
for module,name in [(last267,'actual'),(big2.spec_orig,'actual'),(big2.spec_ext,'actual'),(branchsp,'extbase'),(branchsp,'fullbase'),(flex,'actual')]:
 if hasattr(module,name):setattr(module,name,gate(getattr(module,name)))
def passed(states):
 A,B,C=[{p for p,d in zip(T,states) if d==x}for x in (1,2,3)]
 hx=A|B
 hy=B|C
 for px,py in ((1,1),(1,0),(0,1),(0,0)):
  if px and not hx or py and not hy:continue
  y=0 if py else 2+(pay==-2)-bool(hy)
  x=0 if px else 2+(pay==-1)-bool(A)-bool(B and not y)
  r={p for p in z if 2+(p==pay)-(p not in A|B|C)-bool(p in hx and not x)-bool(p in C and not y)>=2}
  n,raw=params(r)
  if px or py:
   N=s.Ehits[om]
   for active,group in ((px,hx),(py,hy)):
    if active:N&=flex.union(s.domq[p]for p in group)
   if not N:continue
   if not last267.check(om,n,raw,N,False,sp) and (max(x,y)<2 or not last267.check(om,n,raw,N,True,sp)):return False
  else:
   if x>=2 and y>=2:
    v=big2.fit2(c,om,n,raw,True,tuple(sorted(hy)),tuple(sorted(hx)),sp)
   elif max(x,y)>=2:v=branchsp.chk(c,om,n,raw,(),True,tuple(sorted(hx if x>=2 else hy)),sp)
   else:v=flex.signed(c,om,n,raw,(),sp,False)
   if not v:return False
 return bool(big2.fit2(c,om,*params(z),False,tuple(sorted(hy)),tuple(sorted(hx)),sp))
for i,st in enumerate(product(range(4),repeat=4)):
 if not any(st) or i<(int(sys.argv[3]) if len(sys.argv)>3 else 1):continue
 if calls()>=cap:break
 try:ans=passed(st)
 except TimeoutError:break
 print(i,st,ans,calls(),flush=True)
