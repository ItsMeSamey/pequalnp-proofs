set -eu
python bigclean.py > replay-bigclean.log
cmp bigclean.log replay-bigclean.log
python bigrest.py > replay-bigrest.log
cmp bigrest.log replay-bigrest.log
for q in 1 4 256 4096; do
 python bigprivate.py "$q" > "replay-bigprivate-$q.log"
 cmp "bigprivate-$q.log" "replay-bigprivate-$q.log"
done
for q in 0 -1; do
 python bigbonus.py "$q" > "replay-bigbonus-$q.log"
 cmp "bigbonus-$q.log" "replay-bigbonus-$q.log"
done
python bigbonus.py -2 800 > replay-bigbonus--2.log
cmp bigbonus--2.log replay-bigbonus--2.log
python bigbonus.py -2 600 211 > replay-bigbonus--2-tail.log
cmp bigbonus--2-tail.log replay-bigbonus--2-tail.log
