from rawholder import actual
from namedregional import run as constrained
from route import *
from functools import reduce
from operator import and_,or_
import time
calls=0
def favorable(s,w,om,b,zz,an,ss):
 global calls
 O=tuple(t for t in range(7)if om>>t&1)
 dm,M,solo,base=s.roles(om,13)
 z=tuple(sorted(set(M)|set(w)|set(zz)));gr=[(p,)for p in z]+[(-1-j,) for j in range(an)]
 raw=tuple((j,p)for j,p in enumerate(z)if p in w)
 pr=tuple((p,1)for p in z)
 sp=b-len(zz)-an
 def check(lo,hi,edges=()):
  global calls
  calls+=1
  if calls>1200:raise TimeoutError
  return actual((),pr,[[0]*len(z)+lo],edges,gr,sp,[[0]*len(z)+hi],ordinary=O,rawnodes=raw)
 if not an:return check([],[])
 if an==1:
  def rec(v):
   if not check([reduce(and_,v)],[reduce(or_,v)]):return False
   if len(v)==1:return True
   h=len(v)//2;return rec(v[:h])or rec(v[h:])
  return rec([i for i in range(128)if not i&om])
 return check([0]*an,[127^om]*an)
def allows(s,c,w,om,b):
 O=tuple(u for u in range(7)if om>>u&1);dm,M,ds,_=s.roles(om,13)
 z=set(M)|set(w)
 for d in range(b+1):
  for zz in combinations([q for q in s.phys if q not in z],d):
   for an in range(b-d+1):
    if constrained(s,O,13,an,300,retain=True,w=w,zz=zz)is False:continue
    if favorable(s,w,om,b,zz,an,None):return zz,an
 return False
if __name__=='__main__':
 t=pool();s=Source(0);s.bank(())
 ids=sorted(literal_eval(Path('after-splice.txt').read_text()),key=lambda j:t[j][3])
 for j in ids:
  c,w,om,b=t[j];assert not c
  print(j,allows(s,c,dict(w),om,b),'calls',calls,flush=True)
