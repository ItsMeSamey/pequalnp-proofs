from route import *
from reduced import actual
from itertools import product
from functools import cache
s=Source(0);s.bank(())
calls=0
@cache
def verdict(om,z,raw,sp,anon):
 global calls
 calls+=1
 if calls+__import__('exactrelay').counter>2000:raise TimeoutError
 O=tuple(t for t in range(7)if om>>t&1)
 gr=[(p,)for p in z]+([(-1,)]if anon else [])
 hi=[[0]*len(z)+([127^om]if anon else [])];lo=[[0]*len(gr)]
 return actual((),[(q,1)for q in z],lo,(),gr,sp,hi,ordinary=O,rawnodes=tuple(7+i for i,p in enumerate(z)if p in raw))
def solve(w,om,b):
 from exactrelay import relay
 w=dict(w);O=tuple(t for t in range(7)if om>>t&1);dm,M,ds,_=s.roles(om,13)
 z=tuple(sorted(set(M)|set(w)));assert b==1 and all(s.no[q,p]for q in z for p in z if p!=q)
 f={p:max(2,w.get(p,0))for p in z}
 need={p:tuple(t for t in O if dm[p]>>t&1)for p in z}
 rq=tuple(q for q in z if f[q]-len(need[q])>=2)
 def ext(rr,sp=0,anon=False,add=()):
  zz=tuple(sorted(set(rr)|set(add)));raw=tuple(p for p in zz if p in w)
  return verdict(om,zz,raw,sp,anon)
 if all(f[q]>=dm[q].bit_count()for q in z) and ext(rq,1):return ('owner',)
 for p in z:
  rr=tuple(q for q in z if f[q]+int(p==q)-len(need[q])>=2)
  if all(f[q]+int(p==q)>=dm[q].bit_count()for q in z) and ext(rr):return ('point',p)
 if all(f[q]>=dm[q].bit_count()for q in z):
  rr=tuple(sorted(rq))
  if relay(om,rr,tuple(q for q in rr if q in w)):return ('relay',)
 for used in product(*(range(1<<len(need[p]))for p in z)):
  H={p for p,v in zip(z,used) if v}
  if not H:continue
  sides=set();ds={p:len(need[p])for p in z};ok=True
  for p,v in zip(z,used):
   for j,t in enumerate(need[p]):
    if v>>j&1:
     if any(s.reject(t,s.pp[q])for q in H if q!=p):ok=False;break
     sides.add(t);ds[p]-=1
   if not ok:break
  if not ok or len(sides)>2:continue
  rem={q:f[q]-ds[q]-int(q in H and len(sides)==2)for q in z}
  if any(f[q]<ds[q]+int(q in H) or rem[q]<bool(dm[q]&128) for q in z):continue
  for q in H:
   if len(sides)==1 and rem[q]==1:
    ff=s.F[q]&s.on[s.inc[q]&~om]&s.Ehits[om]
    if any(ff&s.domq[p]for p in H):ok=False;break
  if not ok:continue
  rr=tuple(q for q in z if rem[q]>=2)
  if ext(rr):return ('private',tuple(sorted(H)),rr)
 return False
if __name__=='__main__':
 t=pool();rows=[j for j in literal_eval(Path('after-splice.txt').read_text())if t[j][3]==1]
 for j in rows[int(sys.argv[1]):int(sys.argv[2])]:
  c,w,om,b=t[j];assert not c
  print(j,solve(w,om,b),'calls',calls+__import__('exactrelay').counter,flush=True)
