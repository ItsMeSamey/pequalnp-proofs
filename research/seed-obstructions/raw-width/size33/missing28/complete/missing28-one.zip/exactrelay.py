from one import *
from functools import reduce
from operator import and_,or_
import sys
counter=0
@cache
def relay(om,rr,raw):
 global counter
 O=tuple(t for t in range(7)if om>>t&1);S=127^om
 F={q:s.F[q]&s.on[s.inc[q]&S]&s.Ehits[om]for q in s.phys}
 pts=[q for q in s.phys if q not in rr];ans=[];nr=tuple(i+7 for i,p in enumerate(rr)if p in raw)
 for d in range(len(pts)+1):
  for B in combinations(pts,d):
   if any(F[q]&s.domq[v]or F[v]&s.domq[q]for q,v in combinations(B,2)):continue
   mask=sum(1<<u for u in range(7)if u not in O and not any(F[q]&s.tag[u]for q in B))
   sig=[x for x in range(128)if not x&~mask];pr=tuple((p,1)for p in (*rr,*B))
   gs=[(p,)for p in rr]+[B or(-1,)]
   def walk(vs):
    global counter
    counter+=1
    if counter>1500:raise TimeoutError
    z=[0]*len(rr)
    if not actual((),pr,[z+[reduce(and_,vs)]],(),gs,0,[z+[reduce(or_,vs)]],ordinary=O,rawnodes=nr):return
    if len(vs)==1:ans.append((B,vs[0]));return
    h=len(vs)//2;walk(vs[:h]);walk(vs[h:])
   walk(sig)
 return ans
if __name__=='__main__':
 t=pool()
 for j in (322,323,324):
  c,w,om,b=t[j];w=dict(w);d,M,ss,bb=s.roles(om,13);z=set(M)|set(w)
  rq=tuple(sorted(q for q in z if max(2,w.get(q,0))-(d[q]&om).bit_count()>=2))
  print(j,rq,relay(om,rq,tuple(p for p in rq if p in w)),counter,flush=True)
