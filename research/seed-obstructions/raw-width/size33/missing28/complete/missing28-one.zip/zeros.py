from route import *
from holder_ext import actual
s=Source(0);s.bank(())
def remain(w,om,b):
 assert not b
 O=tuple(j for j in range(7)if om>>j&1)
 dm,M,ds,base=s.roles(om,13)
 z=set(w)|set(M)
 assert all(s.no[q,p] for p in z for q in z if p!=q)
 arr={}
 for q in z:
  left=max(2,w.get(q,0))-(dm[q]&om).bit_count()
  if left>=2:assert q in w;arr[q]=left
 return arr
if __name__=='__main__':
 t=pool()
 for j in literal_eval(Path('after-splice.txt').read_text()):
  c,w,om,b=t[j]
  if b or j==276:continue
  arr=remain(dict(w),om,b);z=tuple(arr)
  res=actual((),[(q,1)for q in z],[[0]*len(z)],(),[(q,)for q in z],0,ordinary=tuple(j for j in range(7)if om>>j&1))
  print(j,arr,res,flush=True)
