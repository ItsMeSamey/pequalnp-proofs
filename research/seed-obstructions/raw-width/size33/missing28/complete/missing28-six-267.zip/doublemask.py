from flex import *
from functools import cache
import spec_orig,spec_ext
nc=0
@cache
def fit2(c,om,named,raw,ext,H2):
 global nc
 assert not c
 s=Source(0);s.bank(c);O=tuple(u for u in range(7)if om>>u&1);S=127^om
 F={p:(s.F[p]&s.on[s.inc[p]&S]&s.Ehits[om] if ext else s.F[p]) for p in s.phys}
 qs=[p for p in s.phys if p not in named]
 rr=tuple((j,p)for j,p in enumerate(named)if p in raw)
 B=[v for d in range(len(qs)+1 if ext else 2)for v in combinations(qs,d)if not any(F[p]&s.domq[q]or F[q]&s.domq[p]for q,p in combinations(v,2))]
 fun=spec_ext.actual if ext else spec_orig.actual
 for a in B:
  for b in B:
   if (not H2 and a>b)or set(a)&set(b)or any(F[p]&s.domq[q]for p in b for q in H2):continue
   z=(*named,*a,*b);gs=[(p,)for p in named]+[a or(-1,),b or(-2,)]
   up=[sum(1<<u for u in range(7)if S>>u&1 and not any(F[p]&s.tag[u]for p in v))for v in (a,b)]
   pr=[(p,1)for p in z];off=len(named)
   def walk(lo,hi,rev):
    global nc
    nc+=1
    if nc>1200:raise TimeoutError
    edges=[(off+rev,off+1-rev)]
    if not fun((),pr,[[0]*off+lo],edges,gs,0,[[0]*off+hi],ordinary=O,rawnodes=rr,special_high=union(s.domq[p]for p in H2)):return False
    if lo==hi:return (a,b,lo,rev)
    j=max(range(2),key=lambda i:(hi[i]^lo[i]).bit_count());u=(lo[j]^hi[j])&-(lo[j]^hi[j]);uu=hi[:];uu[j]&=~u
    x=walk(lo,uu,rev)
    if x:return x
    ll=lo[:];ll[j]|=u
    return walk(ll,hi,rev)
   for r in range(2):
    x=walk([0,0],up,r)
    if x:return x
 return False
def clean(c,w,om):
 s=Source(0);s.bank(c);dm,M,_,_=s.roles(om,13-len(c));z=set(M)|set(w)
 direct={p for p in z if p in dm and dm[p]&om and all(q==p or q in w or s.no[q,p]or s.no_t[q,p]&om for q in z)}
 rr={q for q in z if max(2,w.get(q,0))-int(q in direct)>=2}
 return fit2(c,om,tuple(sorted(rr)),tuple(sorted(rr&set(w))),True,())
if __name__=='__main__':
 tab=pool()
 for j in map(int,sys.argv[1:]):
  c,w,om,b=tab[j];print(j,clean(c,dict(w),om),'calls',nc,flush=True)
