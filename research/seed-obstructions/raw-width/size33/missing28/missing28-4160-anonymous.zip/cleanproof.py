from target import *
p=256
for u in (1,2):
 Q=bm(stars[u]&~p)
 print(u,Q,'base',bool(TOP&pt[p]),'foreign',[(q,s)for q in Q for s in range(7) if inc[q]>>s&1 and not inc[p]>>s&1 and TOP&on[s]&pt[p]])
