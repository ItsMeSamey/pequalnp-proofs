from ast import literal_eval
from target import *
from itertools import combinations
drows=[literal_eval('('+s.split(' ',1)[0]+', '+s.split(')) ',1)[1]+')') for s in open('mask4160.log')]
for (w,(z,g,ds,sp)),(_,(_,hm)) in zip([row for row in I if row[1][1]==1],drows):
 if z in (325,4357):continue
 gr=[inc[p]for p in pts if not (p & (z|4160))]
 gr.append(inc[64]|inc[4096])
 choices=[]
 for m in hm:
  for k in range(min(len(gr),2+ds[-1]+sp)+1):
   for G in combinations(range(len(gr)),k):
    cost=[(sum(bool(v>>u&1) for i,v in enumerate(gr) if i not in G or not(m>>u&1))+int(bool(m>>u&1)))for u in range(7)]
    if sum(max(0,b-2)for b in cost)+max(0,k-2-ds[-1])<=sp:choices.append((m,G,cost))
 print(z, [(m,[u for u in (1,2) if not (m>>u&1) and cost[u]==2 and stars[u]&z]) for m,G,cost in choices])
