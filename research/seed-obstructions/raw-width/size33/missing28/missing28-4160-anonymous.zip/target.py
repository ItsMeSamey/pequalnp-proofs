from geometry import *
from all4 import test,extra
from ast import literal_eval
from pathlib import Path
C=(4160,);R=8133
I=[(w,s)for c,w,s,b in map(literal_eval,Path('checksites.log').read_text().splitlines())if b and c==C and s[1]]
TOP=pack(lambda n:bool(n>>extra[4160]&1))
def report():
 for h,B in [(0,alln),(1,TOP)]:
  print(h,[(p,inc[p],sum(1<<u for u in range(7)if not B&~pt[p]&line(inc[p])&on[u]))for p in pts])
  print('pairbad',[(p,q)for p,q in combinations(pts,2)if not B&line(inc[p])&line(inc[q])])
  print('nonincident',[(p,u)for p in pts for u in range(7)if not p&stars[u]and not B&pt[p]&on[u]])
 print('count',len(I))
if __name__=='__main__':report()
