from mask4160 import *
def screen(z):
 named=z^261
 Q=8133^z; qs=bm(Q&~4160)+[64]
 U=127
 def choices(k):return [sum(G)for n in range(k+1)for G in combinations(qs,n)]
 for arc in range(3):
  good=[]
  for j in choices(2-(arc==1)):
   for x in choices(2-(arc==2)):
    poss=[]
    for u,orig in enumerate(stars):
     s=(orig&~4160)|(64 if orig&4160 else 0)
     t=1<<u; n=s&Q;opts=[]
     for a in range(4):
      active=a&(3 if t&U else 2)
      if arc==1 and active&1:active|=2
      if arc==2 and active&2 and t&U:active|=1
      supplied=(j if active&1 else 0)|(x if active&2 else 0)
      req=a.bit_count()+(n&~supplied).bit_count()
      if req>2:continue
      if u in (1,2) and not a and req==2:continue
      reached=a|(2 if arc==1 and a&1 else 0)|(1 if arc==2 and a&2 else 0)
      full=(not(reached&1) or j.bit_count()+(arc==1)==2) and (not(reached&2) or x.bit_count()+(arc==2)==2)
      tight=req==2 and full
      affected=n | (j if reached&1 else 0) | (x if reached&2 else 0)
      opts.append((tight,affected))
     poss.append(opts)
    if all(poss):
     clean=sum(q for q in qs if q!=64 and any((q&stars[u]) and all(flag for flag,b in opts)for u,opts in enumerate(poss)))
     if all(not (stars[u]&261) or any(not flag or b&~clean for flag,b in opts)for u,opts in enumerate(poss)):good.append((j,x,poss))
  print(z,arc,len(good),good[:1],flush=True)
screen(261)
