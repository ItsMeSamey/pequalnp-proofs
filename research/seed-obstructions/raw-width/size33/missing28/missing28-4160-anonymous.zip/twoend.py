from mask4160 import *
def screen(z):
 named=z^261
 Q=8133^z; qs=bm(Q)
 U=sum(1<<u for u in range(7)if not E&F[named]&on[u])
 def choices(k):return [sum(G)for n in range(k+1)for G in combinations(qs,n)]
 for arc in range(3):
  good=[]
  for j in choices(2-(arc==1)):
   for x in choices(2-(arc==2)):
    poss=[]
    for u,s in enumerate(stars):
     t=1<<u; n=s&Q;opts=[]
     for a in range(4):
      active=a&(3 if t&U else 2)
      if arc==1 and active&1:active|=2
      if arc==2 and active&2 and t&U:active|=1
      supplied=(j if active&1 else 0)|(x if active&2 else 0)
      req=a.bit_count()+(n&~supplied).bit_count()
      if req>2:continue
      if u in (1,2) and not a and req==2:continue
      opts.append(a)
     poss.append(opts)
    if all(poss):good.append((j,x,poss))
  print(z,arc,len(good),good[:1],flush=True)
for z in (325,4357):screen(z)
