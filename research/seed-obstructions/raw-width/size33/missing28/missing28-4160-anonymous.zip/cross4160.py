import sys
from geometry import *
from cuts import extra
from pathlib import Path
from functools import reduce
from all4 import test as allcuts
from cuts import load,DEGREE_ONE
C=(4160,);R=8133;P,N=load(tuple(DEGREE_ONE))
CC=[set(),set()]
for h,v,k in allcuts(P,N,R,C):CC[bool(h)].add((v,k))

from cps import enough
from itertools import product
top=pack(lambda n:all(n>>extra[m]&1 for m in C))
def topupper(p):
 f=pack(lambda n:not n&p and n>>13&inc[p])&top
 return sum(1<<u for u in range(7)if not f&on[u])
UP={p:topupper(p)for p in bm(R)}
bright=[p for p in bm(R)if UP[p]]
def clash(p,q):
 a=UP[p]&UP[q]
 common=any(inc[p]>>u&1 and inc[q]>>v&1 and not a&((1<<u)|(1<<v))and top&on[u]&on[v]for u in range(7)for v in range(7))
 sep=any(inc[x]>>u&1 and not inc[y]>>u&1 and not a>>u&1 and top&pt[y]&on[u]for x,y in ((p,q),(q,p))for u in range(7))
 return bool(common and sep)
bad=[(p,q)for p,q in combinations(bm(R),2)if not clash(p,q)]
cover={p:set()for p in bm(R)}
for h in range(2):
 layer={p:0 for p in bm(R)}
 for v,k in CC[h]:
  for p in bm(k):layer[p]|=v&inc[p]
 for p,v in layer.items():cover[p].add(v)
def screen(z,g,ds,w):
 ps=[p for p in bm(z) if p not in dict(w)];H=len(ps)+g
 def visit(B):
  U=[reduce(int.__and__,(UP[p] for p in bm(b)),127)for b in B]
  for V in range(127,0,-1):
   K=sum(p for p in bm(R&~z)if inc[p]&V and any((inc[p]&V)&~w==0 for w in cover[p])and not any(p&b and u&V for b,u in zip(B,U)))
   dom={K}
   for p,q in bad:dom={r for k in dom for r in ((k^p,k^q)if k&p and k&q else (k,))}
   merged={p:inc[p]&V for p in bm(K)}
   for p,q in bad:
    if p in merged and q in merged:merged[p]|=merged.pop(q)
   if not enough(tuple(sorted(merged.values())),V,tuple(sorted((m,2+d)for m,d in zip(U,ds))),0):return False
   for k in dom:
    req=tuple(sorted(inc[p]&V for p in bm(k)))
    if not enough(req,V,tuple(sorted((m,2+d)for m,d in zip(U,ds))),0):return False
  return True
 rest=[p for p in bright if not p&z];kept=[]
 for ass in product(range(-1,H),repeat=len(rest)):
  B=[*ps,*([0]*g)]
  for p,i in zip(rest,ass):
   if i>=0:B[i]|=p
  if visit(B):kept.append((ass,tuple(B)))
 return kept

from ast import literal_eval
samples=Path(__file__).with_name('checksites.log')
for c,w,(z,g,ds,sp),ok in map(literal_eval,samples.read_text().splitlines()):
 if not ok or c!=(4160,) or not g:continue
 if sp:continue
 res=screen(z,g,ds,w)
 print(z,g,w,len(res),res,flush=True)
