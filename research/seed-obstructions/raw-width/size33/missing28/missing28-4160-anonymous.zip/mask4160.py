from pathlib import Path
import sys,ast
src=Path(__file__).resolve().parent
from geometry import *
from cuts import extra
from itertools import combinations
C=4160
E=pack(lambda n:bool(n>>extra[C]&1))
F={p:~pt[p]&line(inc[p])&(E if p&C else alln) for p in pts}
rows=[(w,s) for c,w,s,ok in map(ast.literal_eval,(src/'checksites.log').read_text().splitlines()) if c==(C,) and s[1] and ok]
@cache
def groupmarks(pin,mask):
 h=(E if pin else alln)&(line(mask) if mask else alln)
 Fp={p:F[p]&h for p in pts}
 out=[]
 for u in range(7):
  if not all(h&on[u]&meet[v]for v in range(7) if v!=u):continue
  A=[p for p in bm(stars[u]) if (pin or not p&C) and Fp[p]&on[u] and all(h&pt[p]&m for m in meet)]
  for k in range(1,len(A)+1):
   for G in combinations(A,k):
    if all(any(h&on[v]&pt[b] for a,b in ((p,q),(q,p)) for v in range(7) if inc[a]>>v&1 and not inc[b]>>v&1) for p,q in combinations(G,2)):out.append((u,sum(G)))
 return out
def fits(pin,mask,z,w,fan,clamp):
 h=(E if pin else alln)&(line(mask) if clamp and mask else alln)
 named=[p for p in bm(z)if p not in dict(w)]
 for u,G in groupmarks(pin,mask if clamp else 0):
  namedactive=sum(not bool(h&F[p]&on[u]) for p in named if not G&p)
  count=(G&~z).bit_count()
  if clamp:
   direct=bool(mask>>u&1 and not any(not ((E if pin else alln)&F[p]&on[u])for p in named) and all((E if pin else alln)&on[u]&meet[v] for v in range(7)if v!=u))
   if count>2+sp-direct+namedactive: return False
  elif count>2+sp+namedactive+(fan-1 if mask>>u&1 else 0):return False
 return True
if __name__=='__main__':
 for w,(z,g,ds,sp) in rows:
  if g!=1:continue
  dom=[]
  for pin in range(2):
   d={m for m in range(128) if fits(pin,m,z,w,2+ds[-1]+sp,False) and (not m or fits(pin,m,z,w,2+ds[-1]+sp,True))}
   if 0 in d:d.add(127)
   dom.append(d)
  print(z,w,[sorted(d)for d in dom],flush=True)
