from satsource import *
from pysat.solvers import Glucose4
from pysat.formula import IDPool
from itertools import combinations,permutations
def possible(c,w,z,site,f,limit=3000):
 ps=bm(z);W=dict(w);names=[p for p in ps if p not in W];rt=len(site)-1;assert rt==7+len(ps)
 lits={7+ps.index(p) for p in W};v=IDPool().id
 comp=[i for i in range(rt+1)if i not in lits]
 for j,b in enumerate(f):
  if b==2:comp=[7+ps.index(names[j])]
 uc,ss,hh=prep(c);bright=union(uc[p]for p in names)
 with Glucose4()as s:
  ad=s.add_clause
  def E(i,j):return v(('e',i,j))
  def O(i,j):return v(('o',i,j))
  def C(i):return v(('c',i))
  ad([C(i)for i in comp])
  for a,b in combinations(comp,2):ad([-C(a),-C(b)])
  opts=[[j for j in range(rt+1)if j!=i and j not in lits]for i in range(rt)]
  for i,dst in enumerate(opts):
   es=[E(i,j)for j in dst];ad(es)
   for a,b,d in combinations(es,3):ad([-a,-b,-d])
   for j in dst:ad([-E(i,j),O(i,j)])
  for a,b in combinations(range(rt),2):ad([-O(a,b),-O(b,a)])
  for a,b,d in permutations(range(rt),3):ad([-O(a,b),-O(b,d),O(a,d)])
  for u in range(7):
   if bright>>u&1:continue
   for m in ss[u]:
    for h,mask in enumerate(site):
     k=(mask&m&~z).bit_count()
     if h==u or not k:continue
     ad([E(u,h)])
     if k>=2:
      for j in opts[u]:
       if j!=h:ad([-E(u,j)])
  inp=[(a&8191,((a>>13)&127).bit_length()-1)for a in P]
  rr=[(a&((1<<20)-1))|((1<<20) if a&c[0] else 0) for a in P+N]
  pos=[0]*rt+[(1<<len(P))-1];neg=[0]*rt+[((1<<len(N))-1)<<len(P)]
  own=[m|((1<<(13+h)) if h<7 else 0) for h,m in enumerate(site)]
  def probe(x,hi,lo):
   b=1<<len(rr);rr.append(x)
   for h in hi:pos[h]|=b
   for h in lo:neg[h]|=b
  for pin in (0,1):
   probe(pin<<20,(),range(rt))
   for u in range(7):probe((1<<(13+u))|(pin<<20),(),[h for h in range(7)if h!=u]+[7+ps.index(p)for p in names if not uc[p]>>u&1])
   for j,p in enumerate(names):
    h=7+ps.index(p);probe(p|(pin<<20),[h]if f[j]>>pin&1 else [],[]if f[j]>>pin&1 else[h])
  for j,p in enumerate(ps):
   h=7+j
   if p in W:
    for k,x in enumerate(rr):
     if x&p:pos[h]|=1<<k
     else:neg[h]|=1<<k
  for u in range(7):
   for j,x in enumerate(N):
    if x&stars[u]:neg[u]|=1<<(len(P)+j)
  for i,a in enumerate(rr[:len(P)]):
   for j,b in enumerate(rr[len(P):len(P)+len(N)]):
    delta=a&~b
    if delta&(1<<20):continue
    hs=[h for h,m in enumerate(own)if m&delta]
    if len(hs)==1:pos[hs[0]]|=1<<i;neg[hs[0]]|=1<<(len(P)+j)
  def V(h,j):return v(('v',h,j))
  for h in range(rt+1):
   for j in range(len(rr)):
    if pos[h]>>j&1:ad([V(h,j)])
    if neg[h]>>j&1:ad([-V(h,j)])
  from functools import cache
  @cache
  def witness(h,i,a,b):
   x=v(('wit',h,i,a,b));ad([-x,E(i,h)]);ad([-x,V(i,a)]);ad([-x,-V(i,b)]);return x
  @cache
  def compare(h,a,b):
   clause=[-V(h,a),V(h,b)]
   if h in comp and rr[a]&~rr[b]&(1<<20):clause.append(C(h))
   clause.extend(witness(h,i,a,b) for i in range(rt)if h in opts[i] and not ((neg[i]>>a|pos[i]>>b)&1))
   ad(clause)
  supers=[[sum(1<<j for j,y in enumerate(rr)if not (x&own[h])&~y)for x in rr]for h in range(rt+1)]
  maxbits=(1<<len(rr))-1
  assert all(pack(lambda n:bool(n&c[0]))&v for v in meet)
  assert all(pack(lambda n:bool(n&c[0]) and not n&p and n>>13&inc[p])for p in names)
  num=0
  while True:
   s.conf_budget(limit);status=s.solve_limited()
   if status is not True:return status,num
   num+=1;m=set(s.get_model());cc=next(i for i in comp if C(i)in m)
   adj=[sum(1<<j for j in ds if E(i,j)in m)for i,ds in enumerate(opts)]+[0]
   bad=0
   for p,u in inp:
    who=next(i for i,g in enumerate(site)if g&p)
    sources=(1<<who)|(1<<u)|((1<<cc)if p&c[0]else 0)
    for cut in range(rt):
     dest=1<<rt;inside=sources&~(1<<cut);front=inside
     while front and not inside&dest:
      nxt=0
      for h in range(rt):
       if front>>h&1:nxt|=adj[h]
      front=nxt&~(1<<cut)&~inside;inside|=front
     if inside&dest:continue
     ad([-C(cc)]+[E(h,j)for h in range(rt)if inside>>h&1 for j in opts[h]if j!=cut and not inside>>j&1])
     bad+=1
   if bad:continue
   sig=[sum(1<<j for j in range(len(rr))if V(h,j) in m)for h in range(rt+1)]
   for h in range(rt+1):
    yes=sig[h];ct=0
    while yes and ct<12:
     a=(yes&-yes).bit_length()-1;yes&=yes-1
     rest=supers[h][a]&(maxbits^sig[h])
     if h==cc and rr[a]&(1<<20):rest&=sum(1<<j for j,x in enumerate(rr)if x&(1<<20))
     for k in range(rt):
      if adj[k]>>h&1 and sig[k]>>a&1:rest&=sig[k]
     for _ in range(3):
      if not rest:break
      b=(rest&-rest).bit_length()-1;rest&=rest-1
      compare(h,a,b);ct+=1
    bad+=ct
   if not bad:return (cc,adj),num

if __name__=='__main__':
 from pathlib import Path
 from ast import literal_eval
 import sys
 D=[(c,w,s)for c,w,s,b in map(literal_eval,Path('checksites.log').read_text().splitlines())if b and c in [(129,),(4160,)]]
 data=[l for p in Path(__file__).parent.glob('sat-*.log')for l in p.read_text().splitlines()]
 for l in data:
  i=int(l.split()[0])
  if i not in map(int,sys.argv[1:]):continue
  c,w,s=D[i];cases=literal_eval(l[l.index('['):])
  import os
  for f,site,_ in cases[int(os.getenv('OFFSET','0')):int(os.getenv('END','1000000'))]:print(i,f,site,possible(c,w,s[0],site,f),flush=True)
