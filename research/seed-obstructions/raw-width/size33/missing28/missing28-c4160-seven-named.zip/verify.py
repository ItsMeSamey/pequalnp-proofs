from pathlib import Path
from ast import literal_eval
import sys
from geometry import N,pts,stars
from cuts import extra,bm
def fields(s):
 parts=[]; depth=0; start=0
 for i,ch in enumerate(s.strip()+' '):
  if ch==' ' and not depth:
   if start<i:parts.append(literal_eval(s[start:i]))
   start=i+1
  depth+=int(ch in '([')-int(ch in ')]')
 return parts
here=Path(__file__).resolve().parent
src=Path(sys.argv[1]) if len(sys.argv)>1 else here
D=[(c,w,s)for c,w,s,b in map(literal_eval,(here/'checksites.log').read_text().splitlines())if b and c in [(129,),(4160,)]]
keys={}; specs={}
for path in sorted(src.glob('sat-*.log')):
 for row in path.read_text().splitlines():
  i,c,s,sat,tot,num,ts=fields(row)
  if c!=(4160,):continue
  assert D[i][0]==c and D[i][2]==s and i not in keys and num==len(ts)
  z,_,ds,sp=s; fixed=dict(D[i][1]); names=[p for p in bm(z)if p not in fixed]
  def key(f,h):
   flags=tuple((p,3 if p in fixed else f[names.index(p)])for p in bm(z))
   assert len(f)==len(names) and all(k in (2,3)for k in f)
   assert len(h)==8+len(flags) and all(sum(bool(g&p)for g in h)==1 for p in pts)
   return flags,tuple(h)
  keys[i]={key(f,h)for f,h,e in ts if e is None}
  specs[i]=(fixed,names)
  assert len(keys[i])==num
  print('chart',i,'pre',tot,'open',num)
assert set(keys)=={13,23,24,25,27,29,31} and keys[13]==keys[23]==set()
for i,j in [(27,25),(29,24),(31,25)]:
 assert D[i][2][0]==D[j][2][0] and specs[j][0].items()<=specs[i][0].items()
 assert keys[i]<=keys[j]
 print('transport',i,j,len(keys[i]))
from sample import samples
raw,seed,target=samples(here/'L-meta-18968.json')
for c in (129,4160):
 witnesses=[]
 for u in range(7):
  for v in range(7):
   if u==v:continue
   ix=next(i for i,r in enumerate(N) if r>>extra[c]&1 and r>>(13+u)&1 and r&stars[v])
   orig=next(k for k,r in enumerate(raw) if not ((target>>k)&1) and r>>(13+u)&1 and r&stars[v] and r>>extra[c]&1)
   witnesses.append((u,v,ix,N[ix],orig,raw[orig]))
 assert len(witnesses)==42
 print('foreign',c,witnesses)
for j in (24,25):
 done=set()
 for path in sorted(src.glob(f'probe-{j}-*.log')):
  for row in path.read_text().splitlines():
   i,f,h,(live,n)=fields(row)
   fixed,names=specs[i];base=((tuple((p,3 if p in fixed else f[names.index(p)])for p in bm(D[i][2][0]))),tuple(h))
   assert i==j and base in keys[j] and base not in done and live is False and n>=0
   done.add(base)
 print('keyed probes',j,len(done),'of',len(keys[j]),flush=True)
 if '--complete' in sys.argv:assert done==keys[j]
