from checksites import *
from functools import reduce
def complete(c,w,row):
 z,g,ds,sp=row;assert not g and not sp and all(not d for d in ds)
 ps=bm(z);W=dict(w);assert not set(W)-set(ps)
 named=[p for p in ps if p not in W];groups=[(p,)for p in ps]
 rawa=list((j,p)for j,p in enumerate(ps)if p in W)
 neg=pack(lambda n:n>>extra[c[0]]&1)
 up={p:sum(1<<u for u in range(7)if not neg&~pt[p]&line(inc[p])&on[u])for p in named}
 assert all(up[p]!=127 for p in named)
 dom=[[x for x in range(128)if not x&~up[p]] for p in named];nodes=0
 def tree(D,fs):
  nonlocal nodes
  nodes+=1
  lo=[[0]*len(ps)for _ in (0,1)];hi=[[0]*len(ps)for _ in (0,1)]
  for p,d in zip(named,D):
   j=ps.index(p)
   for h in (0,1):
    hi[h][j]=reduce(int.__or__,[y[h]for y in d]);lo[h][j]=reduce(int.__and__,[y[h]for y in d])
  pr=[(p,3 if p in W else fs[named.index(p)])for p in ps]
  es=[(ps.index(p),ps.index(q))for p in named for q in named if p!=q and up[p]&up[q]]
  if not actual(c,pr,lo,es,groups,0,hi,rawnodes=rawa):return False
  pick=[(min(k,len(d)-k),i,h,u)for i,d in enumerate(D)for h in (0,1)for u in range(7)if 0<(k:=sum(y[h]>>u&1 for y in d))<len(d)]
  if not pick:return True
  _,i,h,u=max(pick)
  for val in (0,1):
   E=D[:];E[i]=[y for y in D[i]if y[h]>>u&1==val]
   if tree(E,fs):return True
  return False
 for fs in product((2,3),repeat=len(named)):
  if fs.count(2)>1:continue
  d=[[(l,h)for h in s for l in s if not l&~h]for s in dom]
  if 2 in fs:
   f=named[fs.index(2)]
   for j,p in enumerate(named):
    if p!=f:d[j]=[(l,h)for l,h in d[j]if not (h&~l)&~up[f]]
  if tree(d,fs):return True,nodes,up
 return False,nodes,up
if __name__=='__main__':
 for c,w,s,b in map(literal_eval,Path('checksites.log').read_text().splitlines()):
  if b and c in [(354,),(523,),(1046,),(2092,)]:print(c,w,s,complete(c,w,s),flush=True)
