from ast import literal_eval
from weightedholder import actual
from weighted import *
def feasible(c,w,s):
 z,g,ds,sp=s;H=1<<len(c);wd=dict(w);q=bm(z);comp=[p for p,n in w if p not in pts]
 groups=[(p,)for p in q]+[(-1-i,)for i in range(len(comp)+g)]
 raw=[(i,p)for i,p in enumerate(q+comp)if p in wd]
 F={p:pack(lambda n:not n&p and n>>13&inc[p] and all(not p&x or n>>extra[x]&1 for x in c))for p in pts}
 pr=[(p,(1<<H)-1 if p in wd else 1<<(H-1))for p in q]
 U=[]
 for h in range(H):
  neg=pack(lambda n:all(not h>>j&1 or n>>extra[x]&1 for j,x in enumerate(c)))
  U.append([(0 if p in wd else sum(1<<u for u in range(7)if not neg&F[p]&on[u]))for p in q]+[127 if h>>c.index(p)&1 else 0 for p in comp]+[127]*g)
 return actual(c,pr,[[0]*len(groups)for h in range(H)],(),groups,sp,U,ordinary=(),rawnodes=raw)
if __name__=='__main__':
 data=list(map(literal_eval,Path('weighted.log').read_text().splitlines()))
 for c,w,ids,slots in sorted(data,key=lambda a:-len(a[0])):
  for s in slots:print((c,w,s,feasible(c,w,s)),flush=True)
