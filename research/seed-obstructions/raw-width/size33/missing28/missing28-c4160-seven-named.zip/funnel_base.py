from ast import literal_eval
from pathlib import Path
from itertools import combinations
N={1:80,4:65,64:17,128:35,256:70,512:13,1024:26,2048:52,4096:104}
def witness(c,z,sat,site):
 for u in sat:
  pairs=[p for p,v in N.items() if not z&p and v>>u&1]
  if len(pairs)!=2:continue
  hh=[next(j for j,ms in enumerate(site)if p&ms)for p in pairs]
  if hh[0]!=hh[1]or hh[0]==len(site)-1 or hh[0]==u:continue
  for p in pairs:
   if not any(p&v for v in c):return p,u,hh[0]
 return None
