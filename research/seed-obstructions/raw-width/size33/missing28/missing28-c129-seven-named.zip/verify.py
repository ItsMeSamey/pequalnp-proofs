from pathlib import Path
from ast import literal_eval
from itertools import product
import sys,subprocess
base=Path(__file__).parent
rows=list(map(str.strip,(base/'sat-129.log').open()))
assert [int(l.split()[0])for l in rows]==[0,6,7,8,10,11,12]
maps={int(l.split()[0]):literal_eval(l[l.index('['):])for l in rows}
assert [len(maps[i])for i in sorted(maps)]==[0,0,0,3,2,0,2]
for f,s,n in maps[10]:
 assert ((3,f[0]),s,None)in maps[8]
for f,s,n in maps[12]:
 assert ((f[0],3),s,None)in maps[8]
receipts=[literal_eval('('+x.split(' ',1)[1].replace(') (', '), (')+')')for x in [(base/k).read_text().strip()for k in ('trace8.log','trace8-1.log','trace8-2.log')]]
assert sorted((f,s)for f,s,r in receipts if r[0]is False)==sorted((f,s)for f,s,_ in maps[8])
print('VERIFIED 7 C129 allocations; 7 final native housing/flags reduce to 3 signed UNSAT receipts')
