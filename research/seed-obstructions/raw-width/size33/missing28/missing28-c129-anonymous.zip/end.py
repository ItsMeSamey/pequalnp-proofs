from mask import *
Q=8133^389
def choices(k):return [sum(G)for n in range(k+1)for G in combinations(bm(Q),n)]
# All five retained points support their full true incidence demand at C=0.
for q in bm(Q):
 for u in bm(inc[q]):
  assert any(G&q and 1<<v==u for v,G in groupmarks(0,0))
for q in bm(Q):
 for p in bm(389):assert F[q]&pt[p]
# Since neither C end is among these five, all pairwise AND-LCAs/conflicting
# deepest guards are ruled out as in the cross-pin certificate.
U=[sum(1<<u for u in range(7)if not F[128]&on[u]),127]
for arc in (0,1,2): # 1 = J to X; 2 = X to J
 total=live=0
 for j in choices(2-(arc==1)):
  for x in choices(2-(arc==2)):
   receivers=(j,x)
   opts=[]
   for u,s in enumerate(stars):
    need=s&Q;t=1<<u
    choices_u=[]
    for a in range(4):
     reached=a|(2 if arc==1 and a&1 else 0)|(1 if arc==2 and a&2 else 0)
     # A route on a bare tag must traverse helpers able to transmit it.
     active=a
     for i in range(2):
      if not U[i]&t:active&=~(1<<i)
     through=active
     if arc==1 and active&1 and U[1]&t:through|=2
     if arc==2 and active&2 and U[0]&t:through|=1
     supplied=(j if through&1 else 0)|(x if through&2 else 0)
     demand=a.bit_count()+(need&~supplied).bit_count()
     if demand>2:continue
     blocked=demand==2 and bool(s&389) and all(not reached>>i&1 or receivers[i].bit_count()+int(arc==i+1)==2 for i in range(2))
     choices_u.append((a,blocked))
    opts.append(choices_u)
   if all(opts):
    total+=1
    if all(any(not b for a,b in choices_u)for choices_u in opts):
     live+=1;print('pass',arc,j,x,opts)
 print('summary',arc,total,live)
