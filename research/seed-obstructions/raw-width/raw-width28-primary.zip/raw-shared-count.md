# A shared pair of private guards and one separate guard require thirteen raw leaves

Let A,B,C be distinct four-point residual stars. The private expressions of A and B use a common pool P of original point-side inputs. The private expression for C uses a disjoint pool D. Sharing inside P is unrestricted. All three private expressions accept their own target singletons and reject their exterior pairs.

The leaf argument in raw-private-count.md shows that each target point whose exact singleton raw input is absent from its pool needs three distinct leaves in that pool that carry the point. Let m count missing singleton inputs on the seven points of A∪B. The 7−m present singletons supply none of the missing incidences. The remaining inputs each carry at most two union points by transversality. Consequently |P|≥7−m+ceil(3m/2)=7+ceil(m/2). If D misses even one C singleton, then |D|≥6, giving |P|+|D|≥13.

Otherwise D has all four C singleton inputs, so none of those four can belong to P. If A,B,C meet at one point p, at least three members of P carry p. None can carry any other A∪B point. The other six points require at least six different leaves by the preceding count applied only to those points. Thus |P|≥9.

In the nonconcurrent case, P omits the two distinct singletons a=A∩C and b=B∩C. To have |P|≤8, the first bound forces m=2. Five singleton inputs then occupy five of the eight positions. The remaining three must all carry a and all carry b, since each omitted point needs three witnesses. Both a and b lie on C, violating transversality of each such raw input.

In every case |P|+|D|≥13. For the n=29 forest there are at most 22 original point inputs, so at most nine can serve the exterior role. The four-special one-companion exterior SAT test raw_outside.py on the 31 actual raw masks finds eleven ten-mask supports and 255 eleven-mask supports across all 35 labelled quartets, and none of size at most nine. Thus this shared-cofactor case is impossible. Equivalently, one may run the stronger pooled.py directly at the 22-leaf bound.
