from itertools import combinations
from pysat.card import CardEnc
from pysat.formula import IDPool
from pysat.solvers import Solver
from forest import P,N,raw,stars

def solve(ordinary):
    names=IDPool()
    selected=[names.id(('raw',i)) for i in range(len(raw))]
    clauses=CardEnc.atmost(selected,9,vpool=names).clauses
    for row in P:
        j=(row>>13).bit_length()-1
        if j in ordinary:continue
        options=[]
        for i in ordinary:
            used=names.id(('companion',row,i))
            options.append(used)
            for neg in N:
                if neg & (1<<(13+j)) and neg & stars[i]:
                    clauses.append([-used]+[v for v,m in zip(selected,raw) if m&row and not m&neg])
        clauses.append(options)
    with Solver(name='cadical195',bootstrap_with=clauses) as solver:
        return solver.solve()
if __name__=='__main__':
    for ordinary in combinations(range(7),3):
        assert not solve(ordinary),ordinary
    print('35 labeled quartets require at least ten exterior raw point inputs')
