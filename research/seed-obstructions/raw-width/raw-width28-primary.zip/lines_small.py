from itertools import combinations, combinations_with_replacement
from collections import Counter
from inputs import P,N
raw=tuple(1<<i for i in range(7))
obligations={(p>>13,n>>13) for p in P for n in N if not ((p&8191)&~(n&8191))}
def additions(available):
    return {op for a,b in combinations_with_replacement(available,2) for op in (a|b,a&b)}
def catalog(width,cost):
    available={raw}
    for i in range(cost):
        available={tuple(sorted(bank+(add,))) for bank in available for add in additions(bank)}
    families={selected for bank in available for selected in combinations(bank,width)}
    return {bank for bank in families if all(any(mask&p and not mask&n for mask in bank) for p,n in obligations)}
if __name__=='__main__':
    for L,c in [(7,1),(8,2),(9,2)]:
        families=catalog(L,c)
        print(L,c, len(families), Counter(len(set(raw)-set(row)) for row in families))
        assert all(set(raw)<=set(row) for row in families)
