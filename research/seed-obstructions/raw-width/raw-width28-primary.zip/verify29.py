from itertools import combinations
from forest_two_noforce import solve as two
from forest_two_comp_noforce import solve as three
from pooled import solve as pool
from raw_outside import solve as outside
import subprocess,sys
subprocess.run([sys.executable,'lines_small.py'],check=True)
for pair in combinations(range(7),2):
    assert not two(pair,22)[0],pair
print('21 two-guard checks passed',flush=True)
for triple in combinations(range(7),3):
    assert not three(triple,22)[0],triple
    assert not outside(triple),triple
    for solo in triple:
        order=tuple(q for q in triple if q!=solo)+(solo,)
        assert not pool(order,22)[0],order
print('35 three-guard, 35 exterior and 105 pooled guard checks passed',flush=True)
