from crossing import *
from itertools import permutations
import json
def test0(ms):
 rawd,rawa=json.loads(Path('profile-'+'-'.join(map(str,ms))+'.json').read_text())
 adj={(H,p):x for H,p,x in rawa};data=[(h,a,tuple(z))for h,a,z in rawd]
 force={p:act[labels[p]]&~contains[p]&reduce(int.__and__,(contains[x]for x in ms if x&p),(1<<len(ns))-1) for p in points}
 # Lower read counts on a single charged tag, distinguishing rows using all seven raw flags.
 tables={}
 for h,a,vs in data:
  ng=reduce(int.__and__,(contains[m]for i,m in enumerate(ms)if h>>i&1),(1<<len(ns))-1)
  good=[p for p in subs(a) if all(ng&contains[p]&on[v]for v in range(7)if not labels[p]>>v&1)]
  tt=[]
  for u in range(7):
   if not all(ng&on[u]&meets[v]for v in range(7)if v!=u):continue
   k=sum(p for p in good if p&stars[u])
   if k.bit_count()<=2:continue
   dark=k|sum(p for p in points if force[p]&ng&on[u])
   tt.append((k,dark))
  tables[h,a]=tt
 @lru_cache(None)
 def cap(h,a,z,g):
  return all((k&~z).bit_count()+sum(bool(x&bad)for x in g)<=5 for k,bad in tables[h,a])
 def dfs(todo,used,edges,g,chosen):
  if not todo:return g
  H,A,vs=todo[0]
  for z in sorted(vs,key=int.bit_count):
   e=list(edges);new=list(subs(z&~used))
   for p in subs(z):
    bad=adj[H,p]&~p
    e[p.bit_length()-1]|=bad
    for q in subs(bad):e[q.bit_length()-1]|=p
   if any(any(e[p.bit_length()-1]&x for p in subs(x))for x in g):continue
   olds={v for v,x in enumerate(g) if x&z}
   if len(olds)!=(used&z).bit_count():continue
   checked=set()
   for colors in permutations(set(range(3))-olds,len(new)):
    gg=list(g)
    for c,p in zip(colors,new):gg[c]|=p
    gg=tuple(sorted(gg))
    if gg in checked:continue
    checked.add(gg)
    if any(any(e[p.bit_length()-1]&x for p in subs(x))for x in gg):continue
    ch=chosen+[(H,A,z)]
    if not all(cap(h,a,r,gg)for h,a,r in ch):continue
    update=[]
    for h,a,opts in todo[1:]:
     w=tuple(r for r in opts if (H&~h or not z&a&~r)and (h&~H or not r&A&~z)and cap(h,a,r,gg))
     if not w:break
     update.append((h,a,w))
    else:
     update.sort(key=lambda row:len(row[2]))
     rr=dfs(update,used|z,e,gg,ch)
     if rr is not None:return rr
  return None
 return dfs(sorted(data,key=lambda row:len(row[2])),0,[0]*13,(0,0,0),[])
if __name__=='__main__':
 for ln in Path('cross-frontier.txt').read_text().splitlines():
  ms,k=ast.literal_eval(ln);print(ms,k,test0(ms),flush=True)
