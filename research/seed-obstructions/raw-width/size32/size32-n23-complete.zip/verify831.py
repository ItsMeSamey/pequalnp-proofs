from verify800 import run0
from payments import scan_physical
from crossing import input_profiles, fits
from pathlib import Path
import ast
import json

def finish():
    candidates = []
    for row in Path("multi-frontier.txt").read_text().splitlines():
        missing, masks, count = ast.literal_eval(row)
        assert missing == 0
        domains, adjacency = input_profiles(masks)
        if fits(domains, adjacency):
            candidates.append((masks,count))
            data = [domains, [(h,p,v) for (h,p),v in adjacency.items()]]
            cache = Path("profile-" + "-".join(map(str,masks)) + ".json")
            assert json.loads(json.dumps(data)) == json.loads(cache.read_text())
    expected = [ast.literal_eval(row) for row in Path("cross-frontier.txt").read_text().splitlines()]
    assert candidates == expected and sum(k for _,k in candidates) == 10
    for masks, count in candidates:
        assert scan_physical(masks) is not None
    print("831 of 831 physical point banks excluded, under the seven-owner and three-surplus assumptions")

if __name__ == "__main__":
    run0()
    finish()
