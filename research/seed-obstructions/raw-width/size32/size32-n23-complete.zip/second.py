import ast
from highz import *
def run():
 out=[];left=[];hist=Counter()
 for miss,ms,k in map(ast.literal_eval,Path('n23-frontier.txt').read_text().splitlines()):
  w=test(ms,miss)
  hist[miss,bool(w)]+=k
  if w:out.append((miss,ms,k,w))
  else:left.append((miss,ms,k))
 print('fixed high baseline pass',hist,'remaining orbits',len(left),flush=True)
 Path('z-witnesses.txt').write_text(''.join(str(x)+'\n'for x in out))
 Path('z-frontier.txt').write_text(''.join(str(x)+'\n'for x in left))
if __name__=='__main__':run()
