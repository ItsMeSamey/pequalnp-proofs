from multi import *
def get_profiles(ms,high,missing=0,rep=0,lowsets=None):
 data=[]
 for A,ng,cost in rows(ms,high,missing,rep):
  pts=tuple(subs(A))
  cand=[sum(z)for n in range(4)for z in combinations(pts,n)]
  if lowsets is not None:cand=[z for z in cand if any(not(d&A&~z)for d in lowsets)]
  for U in sorted(range(1,128),key=int.bit_count,reverse=True):
   if U.bit_count()<4:break
   lg={q:labels[q]&U for q in pts}
   onK=[p for p in pts if lg[p] and lg[p]!=U and all(ng&contains[p]&on[u] for u in range(7)if U>>u&1 and not lg[p]>>u&1)]
   if len(onK)<5:continue
   active={p:sum(1<<v for v in range(7)if ng&on[v]&act[lg[p]])for p in onK}
   bad=[(p,q)for p,q in combinations(onK,2)if lg[p]==lg[q] or not ng&act[lg[p]]&act[lg[q]]]
   for V in sorted((v for v in range(1,128) if not v&~U and v.bit_count()>=3),key=int.bit_count,reverse=True):
    if any(not ng&on[v]&meets[h]for v in range(7)if V>>v&1 for h in range(7)if h!=v):continue
    base=sum(q for q in onK if not V&~active[q])
    for K in set(independent(base,bad)):
     if K.bit_count()<5:continue
     cand=[z for z in cand if feasible(tuple(sorted(lg[p]&V for p in subs(K&~z)if lg[p]&V)),
               3-z.bit_count()+sum(bool(cost[p]&V)for p in subs(z&~K)),False)]
     if not cand:return [(A,[])]
  data.append((A,cand))
  if lowsets is not None:
   lowsets[:]=[d for d in lowsets if any(not(d&A&~z) for z in cand)]
   if not lowsets:return True
 return data
