from collect import *
import ast
from functools import lru_cache
def input_profiles(ms):
 f={p:act[labels[p]]&~contains[p]&reduce(int.__and__,(contains[x]for x in ms if x&p),(1<<len(ns))-1)for p in points}
 S=8191&~reduce(or_,ms,0)
 data=[(0,S,[sum(d) for d in run(ms,0)])]
 for k in range(1,len(ms)+1):
  for high in combinations(ms,k):
   H=sum(1<<i for i,m in enumerate(ms)if m in high)
   for A,zs in get_profiles(ms,high):data.append((H,A,zs))
 def adj(H,p):
  mask=contains[p]&reduce(int.__and__,(contains[x]for i,x in enumerate(ms)if H>>i&1),(1<<len(ns))-1)
  return sum(q for q in points if f[q]&mask)
 adj0={(H,p):adj(H,p) for H,A,zs in data for p in subs(A)}
 return data,adj0
def fits(data,adj):
 # Each selected high origin must receive one of the three available physical extras. Establish colorability as choices are added.
 def color(a,e):
  if a.bit_count()<=3:return True
  seq=sorted(subs(a),key=lambda p:(e[p.bit_length()-1]&a).bit_count(),reverse=True)
  def assign(i,gs):
   if i==len(seq):return True
   p=seq[i];bad=e[p.bit_length()-1]
   for k,v in enumerate(gs):
    if not bad&v:
     ng=gs[:];ng[k]|=p
     if assign(i+1,ng):return True
     if not v:break
   return False
  return assign(0,[0,0,0])
 data=sorted(data,key=lambda it:len(it[2]))
 def enumerate0(todo,active,edges):
  if not todo:return True
  H,A,opts=todo[0]
  for z in sorted(opts,key=int.bit_count):
   e=list(edges)
   for p in subs(z):
    v=adj[H,p]&~p
    e[p.bit_length()-1]|=v
    for q in subs(v):e[q.bit_length()-1]|=p
   if not color(active|z,e):continue
   updated=[]
   for h,a,vs in todo[1:]:
    if not H&~h:qv=[r for r in vs if not (z&a&~r)]
    else:qv=vs
    if not h&~H:qv=[r for r in qv if not (r&A&~z)]
    if not qv:break
    updated.append((h,a,qv))
   else:
    updated.sort(key=lambda it:len(it[2]))
    if enumerate0(updated,active|z,e):return True
  return False
 return enumerate0(data,0,[0]*13)
if __name__=='__main__':
 import sys
 for line in Path('multi-frontier.txt').read_text().splitlines()[int(sys.argv[1]):int(sys.argv[2])]:
  _,ms,k=ast.literal_eval(line);d,a=input_profiles(ms)
  print(ms,k,'fits',fits(d,a),'mincounts',[min(map(int.bit_count,z)) for h,A,z in d],flush=True)
