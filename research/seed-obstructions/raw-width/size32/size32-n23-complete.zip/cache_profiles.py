from crossing import *
import json
if __name__=='__main__':
 for line in Path('cross-frontier.txt').read_text().splitlines():
  ms,k=ast.literal_eval(line);d,a=input_profiles(ms)
  Path('profile-'+('-'.join(map(str,ms)))+'.json').write_text(json.dumps([d,[(h,p,v) for (h,p),v in a.items()]],separators=(',',':')))
  print(ms,[(h,A.bit_count(),len(z),0 in z)for h,A,z in d],flush=True)
