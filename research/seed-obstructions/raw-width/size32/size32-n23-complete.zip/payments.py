from shadow_model import *
from functools import lru_cache
@lru_cache(None)
def due(gs):return sum(max(0,sum(bool(x>>u&1)for x in gs)-2)for u in range(7))
@lru_cache(None)
def fits0(gs,free,k):
 if due(gs)<=k:return True
 if free:
  if fits0(gs,free[:-1],k):return True
  t=free[-1]
  if any(fits0(tuple(sorted(gs[:i]+gs[i+1:]+((g&~t,) if g&~t else ()))),free[:-1],k)for i,g in enumerate(gs)if g&t):return True
 if k:
  for i,g in enumerate(gs):
   for j in range(i):
    if fits0(tuple(sorted(gs[:j]+gs[j+1:i]+gs[i+1:]+(g|gs[j],))),free,k-1):return True
 return False
def scan_physical(ms):
 ms=tuple(ms);calls=0;seen={}
 f={p:act[labels[p]]&~contains[p]&reduce(int.__and__,(contains[x]for x in ms if x&p),(1<<len(ns))-1)for p in points}
 @lru_cache(None)
 def neg(H):return reduce(int.__and__,(contains[x]for i,x in enumerate(ms)if H>>i&1),(1<<len(ns))-1)
 @lru_cache(None)
 def width(H,g):
  return sum(1<<u for u in range(7)if not neg(H)&on[u]&reduce(int.__or__,(f[q]for q in subs(g)),0))
 def pay(H,z,g,U,V,K):
  gs=tuple(sorted(labels[p]&V for p in subs(K&~z)if labels[p]&V))
  free=tuple(sorted(m for c in g if c and not c&K and (m:=V&width(H,c))))
  return fits0(gs,free,g.count(0))
 def filt(H,A,z,g):
  return all(pay(H,z,g,U,V,K) for U,V,K in seen.get((H,A),()))
 def conflict(H,A,z,g):
  ng=neg(H);pts=tuple(subs(A));vs=range(1,128)
  for U in sorted(vs,key=int.bit_count,reverse=True):
   if U.bit_count()<3:break
   ls={q:labels[q]&U for q in pts}
   kk=[q for q in pts if ls[q] and ls[q]!=U and all(ng&contains[q]&on[u]for u in range(7)if U>>u&1 and not ls[q]>>u&1)]
   if len(kk)<3:continue
   allowed={q:sum(1<<u for u in range(7)if ng&on[u]&act[ls[q]]) for q in kk}
   bad=[(p,q)for p,q in combinations(kk,2)if ls[p]==ls[q] or not ng&act[ls[p]]&act[ls[q]]]
   for V in sorted((v for v in vs if not v&~U),key=int.bit_count,reverse=True):
    if any(not ng&on[v]&meets[h]for v in range(7)if V>>v&1 for h in range(7)if h!=v):continue
    for K in set(independent(sum(p for p in kk if not V&~allowed[p]),bad)):
     if not pay(H,z,g,U,V,K):return U,V,K
 while True:
  model=test0(ms,filt)
  if model is None:break
  g,chosen=model
  for H,A,z in chosen:
   found=conflict(H,A,z,g)
   if found:seen.setdefault((H,A),set()).add(found);break
  else:
   print('FIT',ms,g,calls,flush=True);break
  calls+=1
 print('CUTS',ms,calls,'closed',model is None,flush=True)
 return seen if model is None else None
if __name__=='__main__':
 import sys
 for line in Path('cross-frontier.txt').read_text().splitlines()[int(sys.argv[1]):int(sys.argv[2])]:
  ms,k=ast.literal_eval(line);c=scan_physical(ms)
  Path('cuts-'+'-'.join(map(str,ms))+'.txt').write_text(repr(c))
