import os,sys,subprocess,tempfile,zipfile
from pathlib import Path
from itertools import combinations
with tempfile.TemporaryDirectory()as tmp:
 for i,(ar,sc)in enumerate([('s32-n20-at-least-five.zip','replay.py'),('s32-n20-five-owner-01.zip','pair01.py'),('s32-n20-five-owner-04.zip','pair04.py'),('size31-raw20-two-ordinary.zip','verify.py')]):
  d=Path(tmp)/str(i);zipfile.ZipFile(Path(__file__).with_name(ar)).extractall(d)
  subprocess.run([sys.executable,sc],cwd=d,check=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  if i==2:
   sys.path.insert(0,str(d))
   from inputs import P,N,stars
   from samples import actions
   orbits={tuple(sorted([stars.index(pm[stars[u]]),stars.index(pm[stars[v]])])) for pm in actions(P,N) for u,v in [(0,1),(0,4),(1,2)]};assert len(orbits)==21
   for a,b in combinations((1,2,3,5),2):
    for u,v in ((a,b),(b,a)):
     assert any(p&stars[u] and not p&stars[v] and any(n&p and n&(8192<<v) for n in N) for p in [1<<j for j in range(13)] if sum(bool(p&t)for t in stars)>1)
print('all 21 five-owner placements and all lower counts checked')
