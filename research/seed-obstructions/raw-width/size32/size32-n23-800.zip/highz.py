from strata import *
from functools import reduce
from operator import or_
ns=tuple(N)
def cols(fn):return sum(1<<i for i,n in enumerate(ns) if fn(n))
on=[cols(lambda n:n>>(13+u)&1)for u in range(7)]
meets=[cols(lambda n:n&s)for s in stars]
contains={m:cols(lambda n:n&m)for m in raw}
act={l:reduce(or_,(on[u]for u in range(7)if l>>u&1),0)for l in range(128)}
def subs(s):
 while s:
  a=s&-s;yield a;s-=a
def independent(K,bad):
 for a,b in bad:
  if K&a and K&b:
   yield from independent(K^a,bad);yield from independent(K^b,bad);return
 yield K
def profile(ms,high,missing=0,rep=0,U=127):
 low=set(ms)-set(high)
 keep=reduce(int.__and__,[contains[m]for m in high],(1<<len(ns))-1)
 available=8191
 for m in low:available&=~(m&~missing if m==rep else m)
 if not rep:available&=~missing
 # Each retained unit has its actual original raw singleton, except an optional physical carrier for point 1.
 # Low noncarrier inputs must be zero throughout all positive comparisons used at any named origin.
 where=lambda p:rep if p==missing else p
 def mask(p):
  phys=where(p)
  n=act[labels[p]&U]&keep&~contains[phys]
  for feat in rawbank:
   if feat!=phys and feat&p:n&=contains[feat]
  return n
 rawbank=tuple(p for p in points if p!=missing)+ms
 universe=[p for p in points if available&p and labels[p]&U and (labels[p]&U)!=U and
           all(contains[p]&keep&s for s in meets) and all(keep&contains[p]&on[u]for u in range(7)if U>>u&1 and not labels[p]>>u&1)]
 if len(universe)<5:return
 Ng={p:mask(p)for p in universe}
 # Named origins cannot coincide if one remains forced low at a retained original mask covering the other's artificial high baseline.
 incompatible=[(p,q)for p,q in combinations(universe,2)if not ((Ng[p]&contains[where(q)]) or (Ng[q]&contains[where(p)]))]
 for A in set(independent(sum(universe),incompatible)):
  if A.bit_count()<5:continue
  pts=tuple(subs(A));cost={p:sum(1<<v for v in range(7)if not Ng[p]&on[v]) for p in pts}
  zlist=[sum(s)for k in range(4)for s in combinations(pts,k)]
  active={p:sum(1<<v for v in range(7)if keep&on[v]&act[labels[p]&U])for p in pts}
  bad=[(p,q)for p,q in combinations(pts,2)if (labels[p]&U)==(labels[q]&U) or not keep&act[labels[p]&U]&act[labels[q]&U]]
  vt=[V for V in range(1,128)if not V&~U and V.bit_count()>=3]
  vt.sort(key=int.bit_count,reverse=True)
  for V in vt:
   if any(not keep&on[v]&meets[h]for v in range(7)if V>>v&1 for h in range(7)if h!=v):continue
   possible=sum(p for p in pts if not V&~active[p])
   for K in set(independent(possible,bad)):
    if K.bit_count()<5:continue
    stay=[]
    for z in zlist:
     b=3-z.bit_count()+sum(bool(cost[p]&V)for p in subs(z&~K))
     groups=tuple(sorted(labels[p]&V for p in subs(K&~z)if labels[p]&V))
     if feasible(groups,b,False):stay.append(z)
    zlist=stay
    if not zlist:return high,missing,rep,U,A,V,K
def test(ms,missing=0):
 for r in range(len(ms),0,-1):
  for high in combinations(ms,r):
   for rep in [0]+([m for m in set(ms)-set(high) if m&missing]if missing else []):
    ans=profile(ms,high,missing,rep)
    if ans:return ans
if __name__=='__main__':
 import ast,sys,time
 L=[ast.literal_eval(x)for x in Path('n23-frontier.txt').read_text().splitlines()]
 st=time.monotonic();n=0
 for missing,ms,k in L[:int(sys.argv[1])]:
  w=test(ms,missing)
  if w:n+=k
 print('scanned',sys.argv[1],'closed',n,'seconds',round(time.monotonic()-st,2),flush=True)
