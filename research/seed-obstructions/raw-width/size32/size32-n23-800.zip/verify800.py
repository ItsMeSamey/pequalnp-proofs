from multi import *
from strata import low0,key,banks
from collections import defaultdict
import ast,re
def run0():
 _,ob=point_obligations(src)
 cons={frozenset(m for m in raw if m&p and not m&n)for p,n in ob}
 fixed={next(iter(c)) for c in cons if len(c)==1};assert fixed==set(points)-{2}
 rem={c for c in cons if not c&fixed}
 assert {c for c in rem if not any(x<c for x in rem)}=={frozenset((2,j))for j in (3,6,258)}
 gg=symmetries();front={}
 for missed,bankset in zip((0,2),banks()):
  d=defaultdict(list)
  for ms in bankset:d[key(ms,missed,gg)].append(ms)
  assert len(d)==(308 if not missed else 12)
  for ls in d.values():
   if not any(low0(ms,missed)for ms in ls):front[missed,ls[0]]=len(ls)
 assert sum(front.values())==507
 for line in Path('z-witnesses.txt').read_text().splitlines():
  missing,ms,k,(high,mr,rep,U,A,V,K)=ast.literal_eval(line)
  assert mr==missing and set(high)<=set(ms) and (not rep or rep in set(ms)-set(high) and rep&missing)
  assert profile(ms,high,missing,rep,U) and front.pop((missing,ms))==k
 assert sum(front.values())==67
 lines=Path('multi-pilot.txt').read_text().splitlines()+Path('multi-more.txt').read_text().splitlines()
 for line in lines:
  row,cert=re.fullmatch(r'(\(.*?\)) (None|\(.*\))',line).groups()
  m,ms,k=ast.literal_eval(row)
  if cert!='None':
   assert scan(ms,m) and front.pop((m,ms))==k
 assert [(m,ms,k)for (m,ms),k in front.items()]==[ast.literal_eval(s)for s in Path('multi-frontier.txt').read_text().splitlines()]
 assert sum(front.values())==31 and all(m==0 for m,ms in front)
 print('831 physical banks; 320 signed orbits; 800 excluded, 31 full-singleton candidates in 20 orbits')
if __name__=='__main__':run0()
