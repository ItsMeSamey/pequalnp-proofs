from highz import *
import ast
def rows(ms,high,missing,rep):
 low=set(ms)-set(high)
 keep=reduce(int.__and__,[contains[m]for m in high],(1<<len(ns))-1)
 available=8191
 for m in low:available&=~(m&~missing if m==rep else m)
 if not rep:available&=~missing
 physical=lambda p:rep if p==missing else p
 rawbank=tuple(p for p in points if p!=missing)+ms
 def mask(p):
  g=act[labels[p]]&keep&~contains[physical(p)]
  for feat in rawbank:
   if feat!=physical(p) and feat&p:g&=contains[feat]
  return g
 universe=[p for p in points if available&p and all(contains[p]&keep&s for s in meets)]
 ng={p:mask(p)for p in universe}
 bad=[(p,q)for p,q in combinations(universe,2)if not (ng[p]&contains[physical(q)] or ng[q]&contains[physical(p)])]
 use=sorted(set(independent(sum(universe),bad)),key=int.bit_count,reverse=True)
 for A in use:
  if A.bit_count()<5:continue
  yield A,keep,{p:sum(1<<u for u in range(7)if not ng[p]&on[u])for p in subs(A)}
def joint(ms,high,missing=0,rep=0,lowsets=None):
 for A,ng,cost in rows(ms,high,missing,rep):
  pts=tuple(subs(A))
  cand=[sum(z)for n in range(4)for z in combinations(pts,n)]
  if lowsets is not None:cand=[z for z in cand if any(not(d&A&~z)for d in lowsets)]
  for U in sorted(range(1,128),key=int.bit_count,reverse=True):
   if U.bit_count()<4:break
   lg={q:labels[q]&U for q in pts}
   onK=[p for p in pts if lg[p] and lg[p]!=U and all(ng&contains[p]&on[u] for u in range(7)if U>>u&1 and not lg[p]>>u&1)]
   if len(onK)<5:continue
   active={p:sum(1<<v for v in range(7)if ng&on[v]&act[lg[p]])for p in onK}
   bad=[(p,q)for p,q in combinations(onK,2)if lg[p]==lg[q] or not ng&act[lg[p]]&act[lg[q]]]
   for V in sorted((v for v in range(1,128) if not v&~U and v.bit_count()>=3),key=int.bit_count,reverse=True):
    if any(not ng&on[v]&meets[h]for v in range(7)if V>>v&1 for h in range(7)if h!=v):continue
    base=sum(q for q in onK if not V&~active[q])
    for K in set(independent(base,bad)):
     if K.bit_count()<5:continue
     cand=[z for z in cand if feasible(tuple(sorted(lg[p]&V for p in subs(K&~z)if lg[p]&V)),
               3-z.bit_count()+sum(bool(cost[p]&V)for p in subs(z&~K)),False)]
     if not cand:return True
  if lowsets is not None:
   lowsets[:]=[d for d in lowsets if any(not(d&A&~z) for z in cand)]
   if not lowsets:return True
 return False
def scan(ms,miss):
 lowsets=[sum(d)for d in run(ms,miss)]
 for r in reversed(range(1,len(ms)+1)):
  for high in combinations(ms,r):
   for rep in [0]+([m for m in set(ms)-set(high)if m&miss]if miss else []):
    if joint(ms,high,miss,rep,lowsets):return high,rep
if __name__=='__main__':
 import sys,time
 dl=[ast.literal_eval(x)for x in Path('z-frontier.txt').read_text().splitlines()]
 for row in dl[int(sys.argv[1]):int(sys.argv[2])]:
  miss,ms,k=row
  print(row,scan(ms,miss),flush=True)
