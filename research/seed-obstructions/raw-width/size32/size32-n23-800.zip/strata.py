from labelproj import *
from itertools import combinations
from collections import Counter
from sample import symmetries,move
def banks():
 return [tuple(v)for v in combinations(comps,3)],[(3,6,258,m)for m in comps if m not in (3,6,258)]
def projections(ms,missing):
 # A distinguished composite can serve as a virtual unit at the missing point when all other support points are deleted.
 for hs in product((0,1),repeat=len(ms)):
  high=tuple(m for m,v in zip(ms,hs)if v);low=tuple(m for m,v in zip(ms,hs)if not v)
  for rep in ([0]+[m for m in low if missing&m] if missing else [0]):
   S=allowed(high)
   for m in low:S&=~(m&~missing if m==rep else m)
   if not rep:S&=~missing
   if all(S&s for s in stars):yield S,high,rep
def low0(ms,missing):
 for S,hs,r in projections(ms,missing):
  if assess(S) or not feasible(tuple(sorted(labels[p]for p in points if p&S)),3,True):return hs,r,S
def key(ms,missing,gg):
 b=[p for p in points if p!=missing]+list(ms)
 return min(tuple(sorted(move(m,perm)for m in b))for perm,line in gg)
def first():
 full,no=banks();gg=symmetries();hist=Counter(); todo=[]
 for missing,bs in [(0,full),(2,no)]:
  keyed={}
  for ms in bs:keyed.setdefault(key(ms,missing,gg),[]).append(ms)
  for k,ls in keyed.items():
   win=next(((ms,w) for ms in ls if (w:=low0(ms,missing))),None)
   if not win:todo.append((missing,ls[0],len(ls)))
   hist[missing,bool(win)]+=len(ls)
  print(missing,'physical',len(bs),'orbits',len(keyed),'counts',hist,flush=True)
 assert len(full)+len(no)==831
 Path('n23-frontier.txt').write_text(''.join(str(row)+'\n' for row in todo))
 return todo
if __name__=='__main__':first()
