from functools import lru_cache
from itertools import combinations
@lru_cache(None)
def sep(F,forbidden,known,free):
 # Every row-comparison must have a distinguishing entrance.
 points=F[0]|F[-1]
 scope=points
 for _,fixed in known:scope|=fixed
 neg=[]
 for group in forbidden:
  masks={z&scope for z in group}
  neg.append([z for z in masks if not any(z!=w and not z&~w for w in masks)])
 cells=[(1<<p,z) for i,m in enumerate(F) for p in range(13) if m>>p&1 for z in neg[i]]
 def options(allowed,required):
  z=allowed&points
  scores=set()
  while True:
   if not required&points&~z and all(m&~z for m in F):
    scores.add(sum(1<<i for i,(p,q)in enumerate(cells)if p&z and not q&(z|required)))
   if not z:break
   z=(z-1)&allowed&points
  rank=sorted(scores,key=int.bit_count,reverse=True);keep=[]
  for x in rank:
   if not any(not x&~a for a in keep):keep.append(x)
  return keep
 choices=[options(a,r)for a,r in known]+[options(points,0)]*free
 choices.sort(key=len)
 ALL=(1<<len(cells))-1
 def go(i,m):
  if m==ALL:return True
  if i==len(choices):return False
  return any(go(i+1,m|x) for x in choices[i])
 return go(0,0)
