from functools import lru_cache
from itertools import product
from ingress_many import sep
@lru_cache(None)
def four(F,forbid,known,free):
 if not sep(F,forbid,known,free):return False
 # Borrow one loss for a fork: at most 3 active entrances, allowing arbitrary monotone code thereafter.
 if free>=1 and sep(F,forbid,known,free-1):return True
 points=F[0]|F[-1];scope=points
 for _,fixed in known:scope|=fixed
 negs=[];L=[];qmap=[]
 for i,g in enumerate(forbid):
  masks={z&scope for z in g}
  masks=[z for z in masks if not any(z!=w and z&~w==0 for w in masks)]
  for z in masks:negs.append(z);qmap.append(i)
 want=(1<<len(negs))-1
 def opts(a,f):
  allowed=a&points;z=allowed;out=set()
  while True:
   if not(f&points&~z) and all(m&~z for m in F):
    high=z|f;out.add(z|sum(1<<(13+i)for i,w in enumerate(negs)if high&w))
   if not z:break
   z=(z-1)&allowed
  return out
 opts0=[opts(a,f) for a,f in known]+[opts(points,0)]*free
 @lru_cache(None)
 def score(x):
  return sum(1<<i for i,j in enumerate(qmap)if x&F[j]==F[j] and not x>>(13+i)&1)
 @lru_cache(None)
 def possible(vals,coverage):
  if coverage==want:return True
  if len(vals)==1:return False
  for j in range(1,len(vals)):
   for i in range(j):
    rest=[x for k,x in enumerate(vals)if k not in (i,j)]
    for v in (vals[i]&vals[j],vals[i]|vals[j]):
     if possible(tuple(sorted((*rest,v))),coverage|score(v)):return True
  return False
 for vals in product(*opts0):
  if possible(tuple(sorted(vals)),0):return True
 return False
