from census import *
from functools import lru_cache
from collections import Counter
qs=[1<<i for i in range(13)]
def Rbank(i):
 return tuple(sorted(fixed|{m for j,m in enumerate(optional) if bank[i]>>j&1}))
@lru_cache(None)
def ext_pools(O):
 ext={p:{} for p in ps}
 for (u,p),rows in perp.items():
  if u not in O:
   for n,bs in rows:
    if bs and all(n&stars[t] for t in O):ext[p][n]=bs
 return ext
@lru_cache(None)
def info(O,i):
 one=1<<i
 roles={p:tuple(t for t in O if private[t,p]&one) for p in ps}
 ns={p:tuple(n for n,k in ns.items() if k&one) for p,ns in ext_pools(O).items()}
 marked=[p for p in ps if len(roles[p])+bool(ns[p])>=2]
 return roles,ns,marked
def sl(O,i): return 12-7+len(O)-len(info(O,i)[2])
def hol(O,i):
 m=info(O,i)[2]
 return sum(bool(possible[q,p]&(1<<i)) for q in m for p in m if q!=p)
