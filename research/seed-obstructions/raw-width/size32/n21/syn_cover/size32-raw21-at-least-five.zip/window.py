from census import *
def threshold(arr,k):
 acc=[full]+[0]*k
 for b in arr:
  for j in reversed(range(1,k+1)):acc[j] |= acc[j-1]&b
 return acc[-1]
def test(O):
 ext={p:0 for p in ps}
 for (u,p),rows in perp.items():
  if u not in O:
   for n,k in rows:
    if all(n&stars[t] for t in O):ext[p]|=k
 ds={p:threshold([private[t,p] for t in O]+[ext[p]],2) for p in ps}
 alive=~threshold(ds.values(),len(O)+5)&threshold(ds.values(),len(O)+4)&full
 busy={}
 for p in ps:
  b=threshold([private[t,p] for t in O]+[ext[p]],3)
  for q in ps:
   if q!=p:b &= ~(ds[q]&possible[q,p])
  busy[p]=b
 must_extra=threshold(busy.values(),2)
 direct={}
 rejected=0
 for p in ps:
  dirs=[]
  for t in O:
   d=0
   if p&stars[t]:
    for a,b in combinations([1<<q for q in range(13) if not stars[t]>>q&1],2):
     d |= mark(p,a|b)&(busy.get(a,0)|busy.get(b,0))
   dirs.append(d)
   direct[p,t]=d
  rejected |= busy[p]&threshold(dirs+[ext[p]],3)
 kept=alive&~(must_extra&rejected)
 placements=0
 for slots in combinations(O,2):
  valid=kept
  for p in ps:
   direct_groups=[private[t,p] if t not in slots else direct[p,t] for t in O]
   valid &= ~(busy[p]&must_extra&threshold(direct_groups,2))
  placements |= valid
 if len(O)>=2:kept &= placements
 return [((k&alive).bit_count(),(k&kept).bit_count()) for k in (full,)]
if __name__=='__main__':
 for O in [(1,2,3,5),(0,1,2,3,5),(0,1,2,3,4,5),(1,2,3,4,5,6),tuple(range(7))]:
  print(O,test(O))
