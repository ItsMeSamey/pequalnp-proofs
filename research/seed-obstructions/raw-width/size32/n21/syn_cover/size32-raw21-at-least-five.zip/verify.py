from ast import literal_eval
from collections import Counter
from pathlib import Path
import sys
from group_roles import *
from window import test as window_test
import re

recorded={}
for line in Path(__file__).with_name('group.log').read_text().splitlines():
    rawset, slack, ls = re.fullmatch(r'(\([^)]*\)) (\d+) (\[.*\])', line).groups()
    recorded[literal_eval(rawset)]=dict(literal_eval(ls))
receipt_only=sys.argv[1:]==['--receipt']
assert receipt_only or not sys.argv[1:]
assert len(optional)==18 and all(x.bit_count() in (2,4) for x in optional)
assert set(fixed)=={1<<p for p in range(13)}
assert test((1,),range(18),0,2000) is True
hist=Counter(); covered=0; satsets=set(); runs=0
for n in range(3,8):
    for O in combinations(range(7),n):
        assert window_test(O)[0][1]==0
        leftovers=[]
        for i in range(18):
            R,E,M=info(O,i); d=sl(O,i);hist[d]+=1
            assert not hol(O,i)
            if d<0: continue
            if d==0:
                assert any(len(R[p])+bool(E[p])>=3 for p in M)
                continue
            if d==1: continue
            leftovers.append(i)
        if not leftovers:continue
        assert leftovers==list(range(18))
        d=sl(O,0); assert d in (2,3)
        assert all(sl(O,i)==d and info(O,i)[2]==info(O,0)[2] for i in leftovers)
        satsets.add(O)
        assert set(recorded[O])==set(range(d+1))
        for a in range(d+1):
            assert recorded[O][a] is False
            if not receipt_only:assert test(O,leftovers,a,2000) is False
            runs+=1
        covered+=len(leftovers)
assert set(recorded)==satsets and len(satsets)==16 and runs==50 and covered==288
assert hist=={-1:18,0:612,1:864,2:252,3:36}
print('one ordinary positive control SAT')
print('1782 actual cases, isolated marked suppliers in all cases')
print('slack -1,0,1,2,3:',[hist[d] for d in range(-1,4)])
print('16 remaining grouped ordinary sets, 288 allocations, 50 UNSAT cases')
