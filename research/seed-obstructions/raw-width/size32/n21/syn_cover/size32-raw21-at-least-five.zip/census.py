from collections import Counter
from itertools import combinations
from pathlib import Path
from functools import lru_cache
from input import raw_samples, point_obligations
src=Path(__file__).with_name('L-meta-18968.json')
P,N,_=raw_samples(src);raw,obligations=point_obligations(src)
fixed={1<<p for p in range(13)}
optional=sorted(set(raw)-fixed)
def blockers(p,n):
 return sum(1<<j for j,m in enumerate(optional) if m&p and not m&n)
bank=[1<<i for i in range(len(optional))]
assert len(bank)==18
full=(1<<len(bank))-1
stars=[sum(r&8191 for r in P if r>>13==1<<t) for t in range(7)]
ps=sorted(fixed)
@lru_cache(None)
def enabled(b):
 return int.from_bytes(bytes(sum((not v&b)<<k for k,v in enumerate(bank[i:i+8])) for i in range(0,len(bank),8)),'little')
def mark(p,n):return enabled(blockers(p,n)) if all(m==p or not m&p or m&n for m in fixed) else 0
private={}
for t,s in enumerate(stars):
 for p in ps:
  v=0
  if s&p:
   for a,b in combinations([1<<j for j in range(13) if not s>>j&1],2):v |= mark(p,a|b)
  private[t,p]=v
perp={(u,p):[(n,mark(p,n)) for n in N if n>>(13+u)&1 and not n&p] for u,s in enumerate(stars) for p in ps if s&p}
possible={(q,p):full for q in ps for p in ps if q!=p}
for q,p in possible:
 for (u,r),rows in perp.items():
  if q==r:
   for n,m in rows:
    if n&p:possible[q,p] &= ~m
