from four import *
import json
from pathlib import Path
seen=set()
for (o,c,t),perm,line in json.loads(Path(__file__).with_name('transports.json').read_text()):
 assert sorted(perm)==list(range(13)) and sorted(line)==list(range(7))
 def m(x,pm):return sum(1<<v for u,v in enumerate(pm)if x>>u&1)
 assert (m(129,perm),line[o])==(c,t)
 for g in (P,N):
  assert {m(x&8191,perm)|(m(x>>13,line)<<13)for x in g}==g
 seen.add((c,t))
assert seen=={(c,t)for c in [129,4160]for t in [1,2,3,5]}
print('eight labeled alignments on the full positive and negative sample')
