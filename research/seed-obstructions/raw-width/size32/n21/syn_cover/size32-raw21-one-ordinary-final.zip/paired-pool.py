from partial import labelsets,origmarks,meet,onp,onl,row,V,U
from extra_credit import cutoff as extra
from triplecut import cutoff as triple
from importlib import import_module
both=import_module('degree-four').cutoff
c=129
for o,single,pair in [(1,7,(8,10)),(2,9,(8,11))]:
 M=origmarks((o,),c);assert sorted(M)==sorted([single,*pair])
 ns=meet(c)
 for p in M:
  assert all(any(ns&onp[q]&onl[v] for v in U if row[p]>>v&1 and not row[q]>>v&1) for q in M if q!=p)
  assert all(ns&onp[p]&meet(sum(1<<q for q in V if row[q]>>u&1)) for u in U if u!=o)
 def eligible(fn,want):
  for rows,sp,F,kp,sm,n2,S in labelsets((o,),c,1):
   if F[0]!=want:continue
   rs=tuple(sum(1<<j for j,u in enumerate(sp)if z>>u&1)for z in rows)
   mark=sum(1<<j for j,p in enumerate(kp)if p in M)
   hi=tuple(sum(1<<q for q in V if all(not ns&onp[q]&onl[v] for v in U if row[p]>>v&1 and not row[q]>>v&1)) for p in kp)
   if fn(rs,mark,6,F,hi,()):return True
  return False
 assert all(eligible(extra,1<<single|1<<p) for p in pair)
 assert eligible(triple,sum(1<<p for p in M))
 mask=sum(1<<p for p in pair)
 ng=ns&meet(mask)
 assert any(row[single]>>u&1 and ng&onl[u] for u in U if u!=o)
 assert eligible(both,mask)
 print(o,'two forbidden pools, full set needs at most two active entrants; complementary pool cut rejected')
