from uncoupled import *
from itertools import combinations
from functools import lru_cache
def origmarks(oo,c):
 M=[]
 for p,r in enumerate(row):
  private=sum(r>>u&1 for u in oo)
  exterior=any(n>>13&r&~sum(1<<u for u in oo) and not n>>p&1 and all(n&stars[u] for u in oo) and (not c>>p&1 or n&c) for n in nn)
  if private+exterior>=2:M.append(p)
 return M
@lru_cache(None)
def cutoff(rs,mark,r,F,hi,ghosts):
 B=12-r
 cycle=3 if r==6 else 4
 k=B-cycle
 for b in range(k+1):
  for L in combinations(range(len(rs)),b):
   dom=[i for i in range(len(rs)) if mark>>i&1 and i not in L]
   s=len(dom)
   gates=0
   for i in dom:gates|=hi[i]
   G=[h0 for n0,h0 in ghosts if not any(n0>>i&1 for i in L)]
   spare=-100
   for dg in range(1<<len(G)):
    pref=gates
    for j,x in enumerate(G):
     if dg>>j&1:pref|=x
    xtra=max((2 if not m&pref else int(bool(m&~pref)) for m in F),default=0)
    spare=max(spare,B-max(cycle,s+dg.bit_count()+xtra)-b-(len(G)-dg.bit_count()))
   if spare<0:continue
   maskrows=[v for i,v in enumerate(rs)if i not in L]
   # For fixed omissions the simultaneous unavoidable cell bills must fit every label restriction.
   if all(sum(min(a,(z&t).bit_count()) for z in maskrows)<=2*t.bit_count()+a*spare
      for t in range(1,1<<r) for a in (1,2,3)):
    return False
 return True
if __name__=='__main__':
 for k in (1,2):
  tot=0
  for c in comps:
   W=[]
   for oo in combinations(U,k):
    mark=origmarks(oo,c)
    excl=False
    for h in (0,1):
     for rows,sp,F in domains(oo,c,h):
      n2=meet(c) if h else ALL
      for m in F:n2&=meet(m)
      S=8191 if h else 8191^c
      kp=validrows(n2,sp,S);sm=sum(1<<u for u in sp)
      true={row[p]&sm for p in mark if p in kp}
      packed=tuple(sum(1<<j for j,u in enumerate(sp)if z>>u&1)for z in rows)
      mask=sum(1<<j for j,z in enumerate(rows)if z in true)
      ns=meet(c) if h else ALL
      def possible(z):
       candidates=[p for p in mark if p in kp and row[p]&sm==z]
       if not candidates:return 0
       a=candidates[0]
       return sum(1<<q for q in V if all(not ns&onp[q]&onl[v] for v in U if row[a]>>v&1 and not row[q]>>v&1))
      hi=tuple(map(possible,rows))
      ghosts=[]
      selected={next(p for p in mark if p in kp and row[p]&sm==z) for z in true}
      for a in mark:
       if a in selected:continue
       pre=ns & ~onp[a]
       if c>>a&1:pre&=meet(c)
       hits=0
       for v in U:
        if row[a]>>v&1:hits|=onl[v]
       pre&=hits
       final=pre&n2
       if not all(final&onl[v] for v in sp):continue
       may=0
       for j,z in enumerate(rows):
        # Choose a fixed representative, preserving mandatory marks where available.
        cand=[q for q in kp if row[q]&sm==z]
        q=next((p for p in mark if p in cand),cand[0])
        if not final&onp[q]:may|=1<<j
       h0=sum(1<<q for q in V if not pre&onp[q])
       ghosts.append((may,h0))
      if cutoff(packed,mask,len(sp),F,hi,tuple(ghosts)):excl=True;break
     if excl:break
    if excl:W.append(oo)
   print(k,c,len(W),W,flush=True);tot+=len(W)
  print('total',tot)
