from itertools import combinations,product
from pathlib import Path
from functools import lru_cache
from input import raw_samples,point_obligations
f=Path(__file__).with_name("L-meta-18968.json")
P,N,_=raw_samples(f)
V=tuple(range(13)); U=tuple(range(7))
row=tuple(sum(1<<u for u in U if (1<<p | 1<<(13+u)) in P) for p in V)
stars=[sum(1<<p for p in V if row[p]>>u&1) for u in U]
comps=[m for m in point_obligations(f)[0] if m.bit_count()>1]
nn=sorted(N)
ALL=(1<<len(nn))-1
def negbits(f):return sum(1<<i for i,n in enumerate(nn) if f(n))
onp=[negbits(lambda n:n>>p&1)for p in V]
onl=[negbits(lambda n:n>>(13+u)&1)for u in U]
@lru_cache(None)
def meet(m):return negbits(lambda n:n&m)
def validrows(ns,special,allowed):
 lm=sum(1<<u for u in special)
 if any(not ns&meet(stars[u])&onl[v] for u in special for v in special if u!=v):return []
 kp=[]
 for p,r in enumerate(row):
  l=r&lm
  if not (1<<p&allowed and l):continue
  mask=0
  for u in special:
   if row[p]>>u&1:mask|=onl[u]
  if (all(ns&mask&onl[v] and (r>>v&1 or ns&onp[p]&onl[v]) for v in special)
    and all(ns&onp[p]&meet(stars[u]) for u in special)):kp.append(p)
 return kp
def domains(oo,c,high):
 sp=tuple(u for u in U if u not in oo);lm=sum(1<<u for u in sp)
 S=8191 if high else 8191^c
 ns=meet(c) if high else ALL
 init=[p for p in V if S>>p&1 and row[p]&lm and all(ns&onp[p]&meet(stars[u]) for u in sp)]
 marks=[]
 for o in oo:
  pp=[p for p in init if row[p]>>o&1]
  marks.append([sum(1<<p for p in g)for k in range(2,len(pp)+1)for g in combinations(pp,k)])
 for F in product(*marks):
  if any(not ns&onl[o] for o in oo):continue
  if len(F)==2 and any(not any(F[i]>>p&1 and not row[p]>>oo[1-i]&1 and ns&onp[p]&onl[oo[1-i]] for p in V) for i in range(2)):continue
  n2=ns
  for m in F:n2&=meet(m)
  kp=validrows(n2,sp,S)
  if any(not any(n2&onl[u] for u in sp if row[p]>>u&1) for m in F for p in V if m>>p&1):continue
  if any(not any(S>>p&1 and row[p]>>u&1 for p in V) or not n2&onl[u] for u in sp):continue
  yield tuple(sorted(set(row[p]&lm for p in kp))),sp,F
def strict(rows,sp):
 for m in range(1,128):
  if m & ~sum(1<<u for u in sp):continue
  if sum(min(2,(r&m).bit_count()) for r in rows)>8-2*(6-len(sp))+2*m.bit_count():return m
 return 0
if __name__=='__main__':
 for l in (1,2):
  yes=0
  for c in comps:
   ok=[]
   for oo in combinations(U,l):
    x=next(((h,F,m)for h in (0,1)for rows,sp,F in domains(oo,c,h)if (m:=strict(rows,sp))),0)
    if x:ok.append(oo)
   yes+=len(ok);print(l,c,len(ok),ok,flush=True)
  print('total',yes)
