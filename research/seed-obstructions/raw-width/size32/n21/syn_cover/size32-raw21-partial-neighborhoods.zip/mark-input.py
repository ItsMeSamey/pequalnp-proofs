from four import *
from marks import origmarks
from itertools import combinations
for c in comps:
 for p,q in combinations(V,2):
  assert any(any(not n>>a&1 and n>>b&1 and n>>13&row[a] and (not c>>a&1 or n&c) for n in nn) for a,b in ((p,q),(q,p)))
 for size in (1,2):
  for oo in combinations(U,size):
   for p in origmarks(oo,c):
    for u in oo:
     if not row[p]>>u&1:continue
     assert any(not stars[u]>>q&1 and not stars[u]>>r&1 and (not c>>p&1 or c&(1<<q|1<<r)) for q,r in combinations(V,2))
print('18 composite inputs, all 78 supplier-pair conflicts per input and all private marks checked')
