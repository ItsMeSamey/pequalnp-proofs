from uncoupled import *
from itertools import combinations
from functools import lru_cache
def origmarks(oo,c):
 M=[]
 for p,r in enumerate(row):
  private=sum(r>>u&1 for u in oo)
  exterior=any(n>>13&r&~sum(1<<u for u in oo) and not n>>p&1 and all(n&stars[u] for u in oo) and (not c>>p&1 or n&c) for n in nn)
  if private+exterior>=2:M.append(p)
 return M
@lru_cache(None)
def cutoff(rs,mark,r,F,hi,ghosts):
 B=12-r
 cycle=2 if r==6 else 4
 k=B-cycle
 for b in range(k+1):
  for L in combinations(range(len(rs)),b):
   dom=[i for i in range(len(rs)) if mark>>i&1 and i not in L]
   s=len(dom)
   gates=0
   for i in dom:gates|=hi[i]
   G=[h0 for n0,h0 in ghosts if not any(n0>>i&1 for i in L)]
   spare=-100
   for dg in range(1<<len(G)):
    pref=gates
    for j,x in enumerate(G):
     if dg>>j&1:pref|=x
    xtra=max((2 if not m&pref else int(bool(m&~pref)) for m in F),default=0)
    spare=max(spare,B-max(cycle,s+dg.bit_count()+xtra)-b-(len(G)-dg.bit_count()))
   if spare<0:continue
   maskrows=[v for i,v in enumerate(rs)if i not in L]
   # For fixed omissions the simultaneous unavoidable cell bills must fit every label restriction.
   if all(sum(min(a,(z&t).bit_count()) for z in maskrows)<=2*t.bit_count()+a*spare
      for t in range(1,1<<r) for a in (1,2,3)):
    return False
 return True
def labelsets(oo,c,h):
 sp=tuple(u for u in U if u not in oo);S=8191 if h else 8191^c
 full=sum(1<<u for u in sp)
 ns=meet(c) if h else ALL
 init=[p for p in V if S>>p&1 and row[p]&full and all(ns&onp[p]&meet(stars[u]) for u in sp)]
 M=[[sum(1<<p for p in g) for k in range(2,5) for g in combinations([p for p in init if row[p]>>o&1],k)]for o in oo]
 for F in product(*M):
  if any(not ns&onl[o] for o in oo):continue
  if len(F)==2 and any(not any(F[i]>>p&1 and not row[p]>>oo[1-i]&1 and ns&onp[p]&onl[oo[1-i]] for p in V) for i in range(2)):continue
  n2=ns
  for m in F:n2&=meet(m)
  if any(not any(n2&onl[u] for u in sp if row[p]>>u&1) for m in F for p in V if m>>p&1):continue
  if any(not any(S>>p&1 and row[p]>>u&1 for p in V) or not n2&onl[u] for u in sp):continue
  for size in range(len(sp),2,-1):
   for ed in combinations(sp,size):
    if any(not n2&meet(stars[u])&onl[v] for u in sp for v in ed if u!=v):continue
    sm=sum(1<<u for u in ed)
    kp=[]
    for p in V:
     if not S>>p&1 or not row[p]&sm:continue
     Pm=0
     for v in sp:
      if row[p]>>v&1:Pm|=onl[v]
     if all(n2&onl[v]&Pm for v in ed) and all(n2&onp[p]&meet(stars[u]) for u in sp):kp.append(p)
    if len(kp)<4:continue
    conflicts=[(p,q) for p,q in combinations(kp,2) if not any(
       row[a]>>v&1 and not row[b]>>v&1 and n2&onp[b]&onl[v]
       for a,b in ((p,q),(q,p)) for v in sp)]
    families=[set(kp)]
    for p,q in conflicts:
     nxt=[]
     for fam in families:
      if {p,q}<=fam:nxt.extend((fam-{p},fam-{q}))
      else:nxt.append(fam)
     families=[set(z) for z in set(map(frozenset,nxt)) if not any(set(z)<t for t in nxt)]
    for sel in families:
     sel=sorted(sel)
     if len(sel)>=4:yield tuple(row[p]&sm for p in sel),sp,F,sel,sm,n2,S
if __name__=='__main__':
 for k in (1,2):
  tot=0
  import sys
  for c in (tuple(map(int,sys.argv[1:])) or comps):
   W=[]
   for oo in combinations(U,k):
    mark=origmarks(oo,c)
    excl=False
    for h in (0,1):
     for rows,sp,F,kp,sm,n2,S in labelsets(oo,c,h):
      packed=tuple(sum(1<<j for j,u in enumerate(sp) if z>>u&1)for z in rows)
      mask=sum(1<<j for j,p in enumerate(kp)if p in mark)
      ns=meet(c) if h else ALL
      def possible(a):
       return sum(1<<q for q in V if all(not ns&onp[q]&onl[v] for v in U if row[a]>>v&1 and not row[q]>>v&1))
      hi=tuple(map(possible,kp))
      ghosts=[];selected=set(kp)&set(mark)
      for a in mark:
       if a in selected:continue
       pre=ns & ~onp[a]
       if c>>a&1:pre&=meet(c)
       hits=0
       for v in U:
        if row[a]>>v&1:hits|=onl[v]
       pre&=hits
       final=pre&n2
       if not all(final&onl[v] for v in sp if sm>>v&1):continue
       may=0
       for j,q in enumerate(kp):
        if not final&onp[q]:may|=1<<j
       h0=sum(1<<q for q in V if not pre&onp[q])
       ghosts.append((may,h0))
      if cutoff(packed,mask,len(sp),F,hi,tuple(ghosts)):excl=True;break
     if excl:break
    if excl:W.append(oo)
   print(k,c,len(W),W,flush=True);tot+=len(W)
  print('total',tot)
