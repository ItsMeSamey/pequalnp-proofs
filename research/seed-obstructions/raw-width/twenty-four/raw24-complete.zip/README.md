# Exclusion of physical excess nine

In the live seed-deleted residual graph let s count binary gates and n count distinct live raw input labels. Its physical excess is k=s+1−n. The published raw25-complete result proves k≥9 for s≤33. At equality n=s−8≤25. At most eighteen point primitives occur, including at least twelve compulsory singleton points. All optional budgets thus use at most six. A model may grant six placements and permit unused raw coordinates.

The raw-nine-discretionary and raw-nine-six-owners arguments force seven distinct mandatory owners. Each takes at least one of the nine surplus occurrences. The remaining two admit exactly five classes.

| Other repeated endpoints | Distribution | Supporting certificates |
|---|---|---|
| None | One owner has four reads or two owners have three | raw25-no-extra |
| One twice-read endpoint | One owner has three reads | raw25-high-owner-empty-extra plus raw25-high-owner-nonempty |
| One three-read endpoint | All owners have two reads | n25-triple-X-empty plus raw25-triple-X-nonempty-results |
| Two incomparable twice-read endpoints | All owners have two reads | parallel empty/empty, one-nonempty, both-nonempty |
| Two comparable twice-read endpoints | All owners have two reads | serial both-empty, upstream-only, downstream-only, both-nonempty |

A holder set lists compulsory singleton raw point sources in the endpoint's own physical region. Optional-only sources, raw repeated signals, and pure gates are included. Comparability includes routes through mandatory owners. The serial cases count zero, one, or two direct upstream references at the downstream endpoint. Each read of a duplicated physical wire contributes separately. The deductions use the live graph, omitting any need for a minimality or terminal-clean assumption.

Every case completed empty. Hence k≥10 and n≤s−9≤24 for s≤33. This statement concerns the normalized seed-deleted graph. The existence problem at 33 residual gates remains open.

The comparable sector used all 107 upstream supports, 8,068 ordered pairs and three direct-read counts. No pair survived. All 442 original incomparable both-nonempty Hall rows failed. The separate one-nonempty 369-case screen left seven maps, each contradicted by three label-0 masking negatives. These conclusions do not rely on numerical CEGAR pilots.

The supplied table keeps prior width triples satisfying P−g_max≤17, since at most g_max paid point gates contribute to the width beyond the raw inputs. This leaves 246 necessary rows.
