from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
base=Path(__file__).resolve().parent
records=(base/'prerequisites.sha256').read_text().splitlines()
for line in records:
    digest, location=line.split()
    file=base/'certificates'/Path(location).name
    if not file.is_file():file=Path('/workspace/scratch')/location
    assert sha256(file.read_bytes()).hexdigest()==digest,file
    with ZipFile(file) as archive:assert archive.testzip() is None,file
old=(base/'prior-widths.tsv').read_text().splitlines(keepends=True)
new=(base/'widths.tsv').read_text().splitlines(keepends=True)
assert len(old)==256 and old[:1]+[row for row in old[1:] if int(row.split()[1])-int(row.split()[4])<=17]==new
assert len(new)==247
print('verified',len(records),'archives and 255 to 246 necessary widths')
