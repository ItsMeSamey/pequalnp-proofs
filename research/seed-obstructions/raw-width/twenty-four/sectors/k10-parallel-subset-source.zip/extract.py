from zipfile import ZipFile
from hashlib import sha256
from collections import defaultdict
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
src=Path(sys.argv[1])
assert sha256(src.read_bytes()).hexdigest()=='dec0ea4a7a9cb66e3443c3608d91d62b3f4c70dcfc867ac8c3bda68f137c7b99'
a=defaultdict(set)
with ZipFile(src) as z:
 for n in z.namelist():
  if n.endswith('.log'):
   for l in z.read(n).decode().splitlines():
    if l.startswith('CASE '):
     _,h,b,w,*_=l.split();a[int(h)].add(int(b))
for h,c in enumerate([131,125,123,124,126,114,125]):
 assert len(a[h])==c
 (root/f'high-{h}.txt').write_text(''.join(f'{b}\n'for b in sorted(a[h])))
