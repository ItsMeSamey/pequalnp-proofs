"""All 3165 globally affordable optional pools tested with bit-parallel masks."""
from functools import lru_cache
from itertools import combinations
from pools import options,pools,ps,P,N,stars
neg=list(N);ALL=(1<<len(pools))-1
# For each q and negative n, record globally selected optional sources that
# could break primitive domination, if any. The literal q itself is fixed.
gap={(p,n):sum(1<<i for i,m in enumerate(options)if m&p and not m&n) for p in ps for n in neg}
@lru_cache(None)
def avoid(m):return sum(1<<j for j,pool in enumerate(pools)if not pool&m)
tags={p:sum(1<<u for u,t in enumerate(stars)if p&t)for p in ps}
@lru_cache(None)
def shadows(B):
 out=[]
 for n in neg:
  o=0
  for q in ps:
   if B&q and not n&q and n>>13&tags[q]:o|=avoid(gap[q,n])
  out.append(o)
 return out
@lru_cache(None)
def valid(B,z):
 a=ALL
 if z:
  for n,bad in zip(neg,shadows(B)):
   if n&z:a&=~bad
 return a
@lru_cache(None)
def dark(B,p,u,saturated):
 bad=0
 for n,k in zip(neg,shadows(B)):
  if n&p or not n>>(13+u)&1:continue
  if saturated and n&stars[u]:k=ALL
  if k:bad|=k&avoid(gap[p,n])
 return bad
@lru_cache(None)
def atmost(ms,d):
 if d<0:return 0
 if len(ms)<=d:return ALL
 good=ALL
 for subset in combinations(ms,d+1):
  hit=ALL
  for v in subset:hit&=v
  good&=~hit
 return good
@lru_cache(None)
def allowance(u,Q,A,B,x,y,f,c,d,v):
 if not Q:return ALL
 if not x:c=0
 if not y:d=0
 if Q.bit_count()>v+c+d:return 0
 xx=tuple(dark(A,p,u,x==f)if c else ALL for p in ps if Q&p)
 yy=tuple(dark(B,p,u,y==f)if d else ALL for p in ps if Q&p)
 return atmost(xx,v+d)&atmost(yy,v+c)&atmost(tuple(a&b for a,b in zip(xx,yy)),v)
