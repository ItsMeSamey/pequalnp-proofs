from k10 import *
from five import allowance
from pools import pools
from random import Random
rng=Random(144)
tests=0
for k in range(60):
 u=rng.randrange(7);T=stars[u];q=sum(p for p in pts if T&p and rng.randrange(2))
 A=sum(rng.sample(pts,2));B=sum(rng.sample([p for p in pts if not p&A],2))
 x,y=map(int,(rng.randrange(2),rng.randrange(2)));f=2
 c,d=map(int,(rng.randrange(4),rng.randrange(4)));v=rng.randrange(3)
 out=allowance(u,q,A,B,x,y,f,c,d,v)
 for j in rng.sample(range(len(pools)),3):
  ms,fn=poolgeo(pools[j])
  def darkset(b):
   n=0
   for p in bits(b):n|=fn[p]
   return {p for p in pts if p&q and ms[p,u]&n}
  qq=set(bits(q));xd=darkset(A)if x and c else qq;yd=darkset(B)if y and d else qq
  left=max(0,len(qq)-(c if x else 0)-(d if y else 0),len(xd)-(d if y else 0),len(yd)-(c if x else 0),len(xd&yd))
  assert bool(out>>j&1)==(left<=v)
  tests+=1
print('scalar allowance checks',tests)
for t in [-1,*range(7)]:
 for f,g in ([(2,3),(3,2)]if t<0 else[(2,2)]):
  assert all(solve(8,32,z,w,f,g,t,pricefive=True)[0]is None for z,w in product((0,8),(0,32)))
print('all fanout and local baseline choices for supports (8,32) excluded')
