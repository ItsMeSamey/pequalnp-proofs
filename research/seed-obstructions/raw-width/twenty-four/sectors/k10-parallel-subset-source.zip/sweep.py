"""Interruptible domain slices. Any capped holder search is recorded as open."""
from k10 import *
from forecast import candidates
import argparse
from collections import Counter
p=argparse.ArgumentParser();p.add_argument('high',type=int,help='owner 0..6, or -1 for 3-read extra Y')
p.add_argument('domain',type=Path);p.add_argument('start',type=int);p.add_argument('end',type=int)
p.add_argument('--physical',action='store_true');p.add_argument('--five',action='store_true');p.add_argument('--nodes',type=int,default=300)
p.add_argument('--occupancy',choices=('one','both','nonempty','empty'),default='nonempty')
o=p.parse_args();h=o.high
dom=[0]+sorted(set(int(l.split()[0])for l in o.domain.read_text().splitlines())-{0})
fx,fy=(2,3)if h==-1 else(2,2)
counts=Counter()
for i in range(o.start,min(o.end,len(dom))):
 A=dom[i]
 for j,B in enumerate(dom):
  if A&B or h>=0 and i>j:continue
  occ=int(bool(A))+int(bool(B))
  if occ not in {'one':(1,),'both':(2,),'nonempty':(1,2),'empty':(0,)}[o.occupancy]:continue
  for z,w in product(candidates(A),candidates(B)):
   allow,_=solve(A,B,z,w,fx,fy,h,pricefive=o.five)
   counts['global tried']+=1
   if allow is None:continue
   counts['global open']+=1
   if not o.physical:
    print('GLOBAL',A,B,z,w,allow,flush=True);continue
   for c,d in product(settings(fx,allow),settings(fy,allow)):
    if A==B==0 and h>=0 and c>d:continue
    r,n=solve(A,B,z,w,fx,fy,h,(c,d),o.nodes,pricefive=o.five)
    counts['physical tried']+=1;counts['nodes']+=n
    if r is not None:
     counts['physical open']+=1;print('OPEN',A,B,z,w,c,d,r,flush=True)
 print('PROGRESS',i,dict(counts),file=sys.stderr,flush=True)
print('DONE',dict(counts),flush=True)
