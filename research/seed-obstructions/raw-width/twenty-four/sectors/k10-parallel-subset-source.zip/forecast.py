from k10 import *
from collections import Counter
@lru_cache(None)
def candidates(b):
 neg=0
 for p in bits(b):neg|=forced[p]
 return [0]+[p for p in bits(b)if not present[p]&neg]
if __name__=='__main__':
 for h in [-1,*range(7)]:
  dom=[0,*map(int,(root/('binary-sets.txt'if h<0 else f'high-{h}.txt')).read_text().split())]
  stats=Counter()
  for i,a in enumerate(dom):
   for j,b in enumerate(dom):
    if a&b or h>=0 and i>j:continue
    k=int(bool(a))+int(bool(b));stats[k,0]+=1;stats[k,1]+=len(candidates(a))*len(candidates(b))
  print(h,len(dom)-1,*[(stats[k,0],stats[k,1])for k in range(3)])
