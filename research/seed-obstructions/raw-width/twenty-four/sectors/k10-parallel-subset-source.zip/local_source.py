from functools import lru_cache
from itertools import combinations_with_replacement
from collections import Counter
from pathlib import Path
from inputs import P,N,stars
N=list(N)
raw={1<<i for i in range(13)}
for i in range(6):
 a=(1<<i)|(1<<(i+1)); b=(1<<(i+3))|(1<<((i+9)%13))
 raw.update((a,b,a|b))
comp=8191^2
@lru_cache(None)
def forced(p):
 return {n for n in N if any(n>>(13+j)&1 and stars[j]&p for j in range(7)) and not n&p and all(m==p or not m&p or n&m for m in raw)}
@lru_cache(None)
def shapes(d,k):
 out=[]
 for rs in combinations_with_replacement(range(1,1<<d),k):
  s={0}
  for a in rs:s|={a|b for b in s if not a&b}
  out.append(s)
 return out
def rank(h,u,b,z=None):
 pts=[1<<i for i in range(13)if b&stars[u]&(1<<i)]
 if not pts:return 0
 ng=set().union(*(forced(1<<i)for i in range(13)if b>>i&1))
 if h==7:ng=set(N)
 if h<7:ng.update(n for n in N if n&stars[h])
 for p in pts:assert any(n>>(13+u)&1 for n in forced(p))
 cols={(sum(1<<i for i,p in enumerate(pts)if n&p),sum(1<<i for i,p in enumerate(pts)if n in forced(p))) for n in ng}
 if z is not None:cols.update((1<<i,0)for i,p in enumerate(pts)if p!=z)
 for k in range(len(pts)+1):
  if any(all(any(m&y==y and not m&n for m in s)for y,n in cols)for s in shapes(len(pts),k)):return k
 raise AssertionError()
