from itertools import combinations
from inputs import P,N,stars
raw={1<<i for i in range(13)}
for i in range(6):
 a=(1<<i)|(1<<(i+1));b=(1<<(i+3))|(1<<((i+9)%13));raw.update((a,b,a|b))
comp=8191^2
ps=[1<<i for i in range(13)if comp>>i&1]
options=sorted(raw-set(ps))
clauses={sum(1<<i for i,m in enumerate(options)if m&r and not m&n)for r in P for n in N if r>>13&n>>13 and not(r&comp and not r&n&8191)}
clauses={a for a in clauses if not any(a!=b and (a&b)==b for b in clauses)}
pools=[q for inds in combinations(range(len(options)),5)if(q:=sum(1<<i for i in inds))and all(q&c for c in clauses)]
if __name__=='__main__':print(len(options),len(clauses),len(pools))
