from k10 import *
from itertools import combinations
from pools import options,clauses
assert sum(all(c&sum(1<<i for i in q)for c in clauses)for q in combinations(range(19),6))==9023
rows=[tuple(map(int,s.split()))for s in(root/'k9-controls.txt').read_text().splitlines()]
total=0
for a,b,z,w,C,D in rows:
 def ports(t):return tuple(3-t.bit_count() if t>>h&1 else 0 for h in range(8))
 r,n=solve(a,b,z,w,2,2,-1,(ports(C),ports(D)),400,pricefive=False)
 assert r is None,(a,b,z,w,C,D,r)
 total+=n
print('k9 both nonempty replay',len(rows),total,'at six optional pool floor 9023')
