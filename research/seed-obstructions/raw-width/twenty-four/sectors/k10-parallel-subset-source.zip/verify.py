from functools import lru_cache
from itertools import product
from collections import Counter
from pathlib import Path
from inputs import P,N,stars
root=Path(__file__).resolve().parent
raw={1<<i for i in range(13)}
for i in range(6):
 a=(1<<i)|(1<<(i+1));b=(1<<(i+3))|(1<<((i+9)%13));raw.update((a,b,a|b))
comp={1<<i for i in range(13) if i!=1}
N=tuple(N)
def bits(x):
 while x:
  a=x&-x;yield a;x^=a
def cols(test):return sum(1<<j for j,n in enumerate(N)if test(n))
mask={(p,u):cols(lambda n,p=p,u=u:n>>(13+u)&1 and not n&p and all(not m&p or m==p or m&n for m in raw))for p in comp for u,t in enumerate(stars)if p&t}
forced={p:0 for p in comp}
for (p,u),ns in mask.items():forced[p]|=ns
