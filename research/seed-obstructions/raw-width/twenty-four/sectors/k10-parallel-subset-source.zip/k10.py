"""Necessary all-seven-tag holder/mode constraints at variable physical fanouts."""
from verify import stars,mask,comp,forced,N,cols,bits
from local_source import rank
from itertools import product,combinations_with_replacement
from functools import lru_cache, reduce
from operator import or_
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
pts=list(bits(comp if isinstance(comp,int) else sum(comp)))
whole=sum(pts)
neighbors={8:((1<<7)|(1<<10)),16:((1<<8)|(1<<9)|(1<<11)),32:((1<<10)|(1<<12))}
meet=[cols(lambda n,t=t:bool(n&t))for t in stars]
present={p:cols(lambda n,p=p:bool(n&p))for p in pts}
@lru_cache(None)
def local(B,z,owned_caps,pool=None):
 neg=0
 for p in bits(B):neg|=poolgeo(pool)[1][p]
 if z and present[z]&neg:return None
 loads=tuple(rank(8,u,B,z)for u in range(7))
 if any(l>k for l,k in zip(loads,owned_caps)):return None
 for u,k in enumerate(owned_caps):
  if loads[u]==k:neg|=meet[u]
 if z and present[z]&neg:return None
 return loads,neg
@lru_cache(None)
def poolgeo(pool):
 if pool is None:return mask,forced
 from pools import options
 act=[options[i] for i in range(len(options)) if pool>>i&1]
 marks={(p,u):cols(lambda n,p=p,u=u: n>>(13+u)&1 and not n&p and all(not a&p or n&a for a in act))
        for p in pts for u,t in enumerate(stars)if p&t}
 low={p:0 for p in pts}
 for (p,u),ns in marks.items():low[p]|=ns
 return marks,low
def solve(A,B,z,w,fx,fy,high,targets=None,limit=10000,pool=None,pricefive=False):
 caps=tuple(2+int(u==high)for u in range(7))
 keymask,_=poolgeo(pool)
 loc=[local(k,e,caps,pool)for k,e in ((A,z),(B,w))]
 if None in loc:return None,0
 (la,na),(lb,nb)=loc
 # targets=None grants every region all extra ports; use aggregate budget only.
 if targets is not None:
  C,D=targets
  assert sum(C)==fx and sum(D)==fy
  recv={h for h in range(7) if C[h]or D[h]}
 else:recv=set()
 outside=[p for p in pts if not p&(A|B)]
 selfok={p for p in outside if p in neighbors and not neighbors[p]&~(z|w)}
 @lru_cache(None)
 def choices(u):
  f=caps[u]
  return [(a,b)for a,b in product(range(f+1),repeat=2)
          if a>=la[u]and b>=lb[u] and a+b<=f and (not a+b or u not in recv)]
 def direct(u,a,b,Q,portx,porty):
  darkx=na|(meet[u]if a==caps[u]else 0)
  darky=nb|(meet[u]if b==caps[u]else 0)
  X=portx if a else 0;Y=porty if b else 0
  q=list(bits(Q));lx=[not X or bool(keymask[p,u]&darkx)for p in q];ly=[not Y or bool(keymask[p,u]&darky)for p in q]
  return max(0,len(q)-X-Y,sum(lx)-Y,sum(ly)-X,sum(x and y for x,y in zip(lx,ly)))
 Q=[sum(p for p in outside if p&stars[u] and p not in selfok)for u in range(7)]
 possible=[[m for m in choices(u) if direct(u,*m,Q[u],fx,fy)<=caps[u]-sum(m)]for u in range(7)]
 if any(not m for m in possible):return None,0
 if pricefive:
  from five import allowance,valid
  allowed=valid(A,z)&valid(B,w)
  for u in range(7):
   offer=0
   for a,b in possible[u]:
    offer|=allowance(u,Q[u],A,B,a,b,caps[u],fx,fy,caps[u]-a-b)
   allowed&=offer
  if not allowed:return None,0
 if targets is None:return tuple(u for u in range(7)if (0,0)in possible[u])+(7,),0
 @lru_cache(None)
 def dc(u,a,b,h,q):return 0 if u==h else direct(u,a,b,q,C[h],D[h])
 @lru_cache(None)
 def fits(place):
  for u in range(7):
   if not any(sum(dc(u,a,b,h,m&stars[u])for h,m in enumerate(place))<=caps[u]-a-b for a,b in possible[u]):return False
  if pricefive:
   ok=allowed
   for u in range(7):
    offered=0
    for a,b in possible[u]:
     rem=caps[u]-a-b;dp=[ok]*(rem+1)
     for h,g in enumerate(place):
      q=g&stars[u]
      if not q or h==u:continue
      hs=[allowance(u,q,A,B,a,b,caps[u],C[h],D[h],i)for i in range(rem+1)]
      dp=[reduce(or_,(hs[i]&dp[d-i]for i in range(d+1)),0)for d in range(rem+1)]
     offered|=dp[-1]
    ok&=offered
    if not ok:return False
  return True
 nodes=0
 def dfs(place):
  nonlocal nodes
  nodes+=1
  if nodes>limit:return 'PENDING'
  used=sum(place);best=None
  for p in outside:
   if used&p:continue
   dom=[]
   for h in range(8):
    if h<7 and stars[h]&p and p not in selfok:continue
    pp=list(place);pp[h]|=p;pp=tuple(pp)
    if fits(pp):dom.append(pp)
   if not dom:return None
   if best is None or len(dom)<len(best):best=dom
  if best is None:return place
  for pp in best:
   got=dfs(pp)
   if got is not None:return got
  return None
 return dfs((0,)*8),nodes
def settings(k,eligible=range(8)):
 for hs in combinations_with_replacement(eligible,k):
  yield tuple(hs.count(x)for x in range(8))
if __name__=='__main__':
 A,B,z,w,fx,fy,high=map(int,sys.argv[1:8])
 print('global',solve(A,B,z,w,fx,fy,high))
 if len(sys.argv)>8:
  hs=[list(map(int,s.split(',')))for s in sys.argv[8:10]]
  print('physical',solve(A,B,z,w,fx,fy,high,hs))
