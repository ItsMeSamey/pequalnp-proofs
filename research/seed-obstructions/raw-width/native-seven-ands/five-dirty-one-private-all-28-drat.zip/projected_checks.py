from donor_control import *
from itertools import product
def check_resolutions(w):
    missing=[]
    for z in (0,1,2):
        for Z in combinations(tags,z):
            forget=sum(Z)
            eligible=[n for n in N0 if n>>13==forget and all(n&U[t]for t in tags if t not in Z)]
            n=next(r for r in sorted(N) if any(not d&~r for d in eligible))
            atoms=[sx(t)for t in tags if not sx(t)&n and U[t]&n]
            atoms+=[p for p in points if not p&n and any(sx(t)&n and U[t]&p for t in tags)]
            _,socks=evaluate(w,n)
            cols=[]
            for g in range(8):
                choices=[sum(1<<j for j,x in enumerate(atoms) if evaluate(w,x)[1][g][s]) for s in range(2) if not socks[g][s]]
                cols.append(choices if choices else [0])
            good=False
            for sel in product(*cols):
                a=0
                for x in sel:a|=x
                if a==(1<<len(atoms))-1:good=True;break
            if not good:missing.append(Z)
    return missing
if __name__=='__main__':
    w=native();missing=check_resolutions(w)
    print('ordinary-complement resolutions absent on partial-positive control',missing)
    for x in (*cycle,*(sx(t)for t in ordinary)):
        _,a=evaluate(w,x);_,b=evaluate(w,x|sx(2));assert all(a[g]==b[g]for g in (0,1,3))
    for t,g in ((1,0),(16,1),(64,3)):
        side=evaluate(w,sx(t))[1][g].index(True)
        for p in cycle:
            if p&U[t]:
                y=evaluate(w,p)[1][g];assert y[1-side] and not y[side]
                if g==3:assert evaluate(w,p|sx(t|2))[0][4]
    print('physical restored C6 row, ordinary bijection and B-last covered')
