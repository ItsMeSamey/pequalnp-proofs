from model import *
from pathlib import Path
import json
chart=(2,2,'shared')
def physical():
    old=json.loads(Path(__file__).with_name('prior-four-dirty.json').read_text())
    # Put the former exterior F at position zero, and move its old three dirties and B one slot later.
    # Contaminate tag 1's C6 point socket by nonneighbor 256 and connect to the later ordinary D3.
    # On every original negative with F high, 256 is already high at that later point socket.
    def lift(word):return (word&((1<<20)-1)) | ((word>>20)<<21)
    words=[sx(1),4|64|256]+[lift(m) for m in old[:8]]+[lift(m)for m in old[10:]]
    words[7]|=1<<20
    for g,t in ((6,8),(7,32)):
        words[2*g]|=sx(t);words[2*g+1]|=U[t]
    assert len(words)==16
    return words
def evaluate(w,n,omit=False):
    wires=n;vals=[];socks=[]
    for g in range(8):
        allowed=wires&~(1<<24) if omit else wires
        s=[bool(allowed&m)for m in w[2*g:2*g+2]]
        socks.append(s);vals.append(all(s))
        if all(s):wires|=1<<(20+g)
    return vals,socks
def native():
    w=physical();positive=set();lost=set();dirt=set()
    for p,t,y in rows:
        v,ss=evaluate(w,p|sx(t));omit,_=evaluate(w,p|sx(t),True)
        if y<0:
            assert not any(v[5:]) and not any(omit[5:]);dirt.update(g for g in range(5) if v[g])
        if y>0:
            if any(v[5:]):positive.add((p,t))
            if any(v[5:]) and not any(omit[5:]):lost.add((p,t))
    assert positive=={(p,t)for p,t in edges if t!=1} and dirt==set(range(5)) and (q[2],2)in lost
    def hot(m):return {g for g,s in enumerate(evaluate(w,m)[1])if any(s)}
    for ix,t in enumerate(private):
        g=(2,5,6,7)[ix];assert hot(q[t])=={g} and hot(sx(t))==({g,4} if ix<2 else {g})
    assert all(not any(evaluate(w,sx(t))[0]) and len(hot(sx(t)))<=2 for t in tags)
    assert all(len(hot(sx(t|v)))<=3 for t,v in combinations(tags,2))
    for t in tags:
        assert any(evaluate(w,sx(t))[1][g][s] and all(not evaluate(w,sx(v))[1][g][s]for v in tags if v!=t) for g in range(8)for s in (0,1))
    assert all(hot(sx(t))&{0,1,3}=={g} for t,g in zip((1,16,64),(0,1,3)))
    for x in (*cycle,*(sx(t)for t in ordinary)):
        v,ss=evaluate(w,sx(2)|x);assert not any(any(ss[g]) for g in (5,6,7)) and not v[2] and not v[4]
    print('all 676 signed rows; 24 preserved positives; all 5 dirty; D4 omission loses',sorted(lost))
    return w
def pinned(cls,w,expected):
    skip=tuple(Z for z in (1,2) for Z in combinations(tags,z) if 1 in Z)
    m=cls(*chart,skip_resolution=skip);ass=[]
    for g in range(8):
        word=w[2*g:2*g+2]
        if g in m.ext:
            word=sorted(word,key=lambda z:tuple(bool(z&(1<<j))for j in range(20+min(g,5))))
        for s,z in enumerate(word):
            ass.extend((1 if z&(1<<j) else -1)*v for j,v in enumerate(m.selectors[g,s]))
    drop={m.positive[p|sx(t)]for p,t in edges if t==1}
    with Glucose4(bootstrap_with=[c for c in m.C if tuple(c)not in drop])as s:assert s.solve(assumptions=ass) is expected
    with Glucose4(bootstrap_with=m.C)as s:assert not s.solve(assumptions=ass)
if __name__=='__main__':
    import sys
    w=native()
    if '--signed-cnf' in sys.argv:
        text=Path(__file__).with_name('model.py').read_text()
        target='for d in range(min(g,5)))'
        assert text.count(target)==1;ns={'__name__':'legacy'}
        exec(compile(text.replace(target,'for d in range(min(g,4)))'),'legacy.py','exec'),ns)
        pinned(Model,w,True);pinned(ns['Model'],w,False)
        print('pinned corrected CNF SAT, omitted D4 UNSAT on 24 positives; both UNSAT on 28')
