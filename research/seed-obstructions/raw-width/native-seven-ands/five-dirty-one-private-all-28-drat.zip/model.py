"""One dirty private H, four dirty exteriors, three isolated clean private terminals."""
from itertools import combinations
from nativecontrol import edges,rows
from pysat.formula import IDPool
from pysat.solvers import Glucose4
private=(2,4,8,32);ordinary=(1,16,64);tags=private+ordinary
def sx(t):return t<<13
P={p|sx(t) for p,t in edges}
N0={p|sx(t) for p,t,y in rows if y<0}
N={n for n in N0 if not any(n!=m and not n&~m for m in N0)}
U={t:sum(p for p,j in edges if j==t) for t in tags}
points=tuple(1<<i for i in range(13))
q={t:next(p for p in points if p&U[t] and sum(bool(p&u)for u in U.values())==1)for t in private}
cycle=(1,4,64)
def charts():
    for h in range(4):
        yield h,1,'only'
        for k in (2,3,4):
            for mode in ('shared','guest'):yield h,k,mode
class Model:
    def __init__(self,h,k,mode, pin=True, resolved=True, skip_resolution=()):
        assert (h,k,mode) in charts()
        self.h=h;self.k=k;self.mode=mode
        private_sites=dict(zip(private,(h,5,6,7)))
        secondary={t:(4 if i==0 or mode=='shared' else h) for i,t in enumerate(private[:k])}
        ds=tuple(i for i in range(4)if i!=h);ext=(*ds,4);self.ext=ext
        C=self.C=[];V=self.V=IDPool().id
        def W(g,s,j):return V(('wire',g,s,j))
        def A(g,s,n):return V(('arm',g,s,n))
        def G(g,n):return V(('gate',g,n))
        def T(g,n):return V(('hot',g,n))
        self.W=W;self.A=A;self.G=G;self.T=T
        def join(y,xs,is_and):
            if is_and:
                C.append([y,*[-x for x in xs]]);C.extend([-y,x]for x in xs)
            else:
                C.append([-y,*xs]);C.extend([y,-x]for x in xs)
            return y
        self.selectors={(g,s):[W(g,s,j)for j in range(20+min(g,5))]for g in range(8)for s in range(2)}
        for g in range(8):
            owner=next((t for t in private if private_sites[t]==g),None)
            for s in (0,1):
                for j in range(20):
                    x=1<<j;fixed=None
                    if x in q.values():fixed=owner is not None and x==q[owner] and s==1
                    elif j>=13 and (1<<(j-13))in private:
                        t=1<<(j-13)
                        if g==private_sites[t]:fixed=s==0
                        elif secondary.get(t)!=g:fixed=False
                        elif owner:fixed=s==0
                    elif owner and s==1 and not (x&U[owner]):fixed=False
                    elif owner and g!=h and s==0:fixed=False
                    if fixed is not None:C.append([(1 if fixed else -1)*W(g,s,j)])
        for t,b in secondary.items():
            j=13+t.bit_length()-1;C.append([W(b,0,j),W(b,1,j)])
        probes=N|P|{1<<i for i in range(20)}|{sx(t|v) for t,v in combinations(tags,2)}
        u=2
        if pin:
            probes|={sx(u)|p for p in cycle}
            probes|={sx(u|t)|p for p in cycle for t in ordinary}
        self.probes=probes
        for n in sorted(probes):
            for g in range(8):
                for s in (0,1):
                    inputs=[W(g,s,j) for j in range(20) if n>>j&1]
                    inputs.extend(join(V(('active',g,s,d,n)),[W(g,s,20+d),G(d,n)],True)
                                  for d in range(min(g,5)))
                    join(A(g,s,n),inputs,False)
                join(G(g,n),[A(g,0,n),A(g,1,n)],True)
                join(T(g,n),[A(g,0,n),A(g,1,n)],False)
        self.evaluation_end=len(C)
        self.positive={n:tuple(G(g,n)for g in (5,6,7))for n in P}
        for c in self.positive.values():C.append(list(c))
        for n in N:C.extend([-G(g,n)] for g in (5,6,7))
        self.verified_eval_structure=len(C)
        for g in range(5):C.append([G(g,n)for n in N])
        for t,g in private_sites.items():
            C.extend([-T(a,q[t])] for a in range(8) if a!=g)
        for t in tags:
            n=sx(t)
            C.extend([-G(g,n)]for g in range(8))
            C.extend([-T(g,n)for g in D]for D in combinations(range(8),3))
            choices=[]
            for g in range(8):
                for s in (0,1):
                    lit=V(('exclusive',g,s,t));choices.append(lit)
                    C.append([-lit,A(g,s,n)])
                    C.extend([-lit,-A(g,s,sx(v))]for v in tags if v!=t)
            C.append(choices)
        for a,b in combinations(tags,2):
            n=sx(a|b);C.extend([-T(g,n)for g in D]for D in combinations(range(8),4))
        for j in (1,2,3):
            for subset in combinations(ordinary,j):
                for cut in combinations(ext,j-1):C.append([T(g,sx(t))for t in subset for g in ext if g not in cut])
        for t in private[k:]:
            g=private_sites[t];C.extend([A(g,1,p)]for p in points if p&U[t])
        n=q[u]|sx(u)
        C.extend([[G(h,n)],[G(4,n)]])
        for n in N:
            if n&sx(u):C.append([-G(h,n)])
            C.append([-G(h,n),-G(4,n)])
        for s in (0,1):
            w=W(4,s,14)
            for n in probes:C.append([-w,-G(h,n),A(4,1-s,n)])
            for n in N:C.append([-w,-G(h,n),-A(4,s,n)])
            for t in tags:
                if t==u:continue
                guest=W(4,s,13+t.bit_length()-1)
                for p in points:
                    if p&U[u] and not p&U[t]:C.append([-w,-guest,A(h,1,p)])
        if mode=='shared':
            for n in N:
                if n&sx(sum(private[:k])):C.append([-G(h,n)])
        for g in ext:
            prev=[]
            for j in range(20+min(g,5)):
                a,b=W(g,0,j),W(g,1,j);C.append(prev+[-a,b])
                e=V(('lex',g,j));C.append(prev+[a,b,e]);C.append(prev+[-a,-b,e]);prev=[-e]
        if pin:self.add_pin(ds,private_sites)
        if resolved:
            from selection import add
            add(self,tags,sx,U,N,N0,lambda *x:V(('selection',*x)),A,skip_resolution)
    def add_pin(self,ds,private_sites):
        A,G,T,W,C=self.A,self.G,self.T,self.W,self.C;h=self.h
        u=2
        # Every dirty gate before B is a strict ancestor of B.
        for g in range(4):
            C.append([W(i,s,20+g) for i in range(g+1,5) for s in (0,1)])
        C.append([W(g,s,24) for g in (5,6,7) for s in (0,1)])
        for x in (*cycle,*(sx(t)for t in ordinary)):
            for g in (5,6,7):C.append([-T(g,sx(u)|x)])
            for g in (h,4):C.append([-G(g,sx(u)|x)])
            for g in ds:
                for s in (0,1):
                    a,b=A(g,s,x),A(g,s,sx(u)|x)
                    C.extend([[a,-b],[-a,b]])
        for t in ordinary:
            n=sx(t)
            C.append([T(g,n)for g in ds])
            for a,b in combinations(ds,2):C.append([-T(a,n),-T(b,n)])
        for g in ds:
            for t,v in combinations(ordinary,2):C.append([-T(g,sx(t)),-T(g,sx(v))])
            for t in ordinary:
                for p in cycle:
                    if not p&U[t]:continue
                    for s in (0,1):
                        mark=A(g,s,sx(t));C.extend([[-mark,A(g,1-s,p)],[-mark,-A(g,s,p)]])
                    if g==ds[-1]:C.append([-T(g,sx(t)),G(4,p|sx(u|t))])
        unbacked=[private_sites[t]for t in private[self.k:]]
        for a,b in combinations(unbacked,2):
            for d in range(5):
                ant=[-W(a,0,20+d),-W(b,0,20+d)]
                if d<h or d==4:C.append(ant)
                else:
                    for n in N:C.extend([ant+[-G(d,n),G(h,n)],ant+[-G(d,n),-G(4,n)]])
        if len(unbacked)==3:
            for d in range(5):C.append([-W(g,0,20+d)for g in unbacked])
