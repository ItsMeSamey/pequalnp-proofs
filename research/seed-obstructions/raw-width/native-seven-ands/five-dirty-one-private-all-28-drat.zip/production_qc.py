"""Materialize and check a model from the same bounded production query if it is SAT."""
from pathlib import Path
from collections import Counter
from itertools import combinations
import json
from model import *
def check(m,literals):
    actual=set(literals); words=[]
    for g in range(8):
        for s in range(2):
            words.append({j for j,v in enumerate(m.selectors[g,s]) if v in actual})
    assert all(words)
    gates={};idx=28
    while any(len(w)>1 for w in words):
        freq=Counter(pair for w in words for pair in combinations(sorted(w),2));pair=min(freq,key=lambda p:(-freq[p],p));a,b=pair
        gates[idx]=('or',a,b)
        for w in words:
            if a in w and b in w:w.difference_update(pair);w.add(idx)
        idx+=1
    for g in range(8):gates[20+g]=('and',*(next(iter(w))for w in words[2*g:2*g+2]))
    gates[idx]=('or',25,26);gates[idx+1]=('or',idx,27);out=idx+1
    order=[*range(20)];dst={j:j for j in order};physical=[]
    def visit(i):
        if i not in dst:
            op,a,b=gates[i];a=visit(a);b=visit(b);dst[i]=20+len(physical);physical.append([op,a,b])
        return dst[i]
    root=visit(out);assert all(z in dst for z in range(20,28));sites=[dst[z]for z in range(20,28)]
    def eval(mask):
        v=[bool(mask&(1<<i))for i in range(20)]
        for op,a,b in physical:v.append(v[a] and v[b] if op=='and' else v[a] or v[b])
        socks=[tuple(v[x]for x in physical[i-20][1:])for i in sites]
        return v[root],{i for i,z in enumerate(socks) if all(z)},{i for i,z in enumerate(socks) if any(z)}
    dirty=set()
    for p,t,y in rows:
        val,on,_=eval(p|sx(t))
        if y:assert val==(y>0)
        if y<0:dirty.update(on)
    assert dirty==set(range(5))
    for ix,t in enumerate(private):
        owner=(m.h,5,6,7)[ix]
        assert eval(q[t])[2]=={owner}
        back=4 if ix==0 or m.mode=='shared' else m.h
        assert eval(sx(t))[2]==({owner,back} if ix<m.k else {owner})
    for t in tags:
        _,on,hot=eval(sx(t));assert not on and len(hot)<=2
    assert all(len(eval(sx(a|b))[2])<=3 for a,b in combinations(tags,2))
    record=dict(gates=physical,output=root,ands=sites,dirty=sorted(dirty))
    file=Path(f'{m.h}-{m.k}-{m.mode}.gates.json')
    file.write_text(json.dumps(record,separators=(',',':')))
    print('physical gate count',len(physical),'signed rows',len(rows),'verified',file,flush=True)
