"""Check signed native domination and its two boundary controls."""
from itertools import combinations
from nativecontrol import rows,edges
negatives={p+(t<<13) for p,t,s in rows if s<0}
private=(2,4,8,32)
stars={t:sum(p for p,k in edges if k==t) for t in (1,2,4,8,16,32,64)}
private_points={t:next(p for p,k in edges if k==t and sum(bool(p&u) for u in stars.values())==1) for t in private}
regular=8191-sum(private_points.values())
def failures(recipients,read_points=0,more_removed_tags=0):
    petitions=0
    for v in recipients:petitions |=stars[v]
    alphabet=regular|read_points|((127^sum(recipients)^more_removed_tags)<<13)
    good={m&alphabet for m in negatives if m&petitions}
    return {n&alphabet for n in negatives if not any((n&alphabet)&~g==0 for g in good)}
for v,w in combinations(private,2):
    assert not failures((v,w))
    rem=[t for t in private if t!=v and t!=w]
    rich=[len(failures((v,w),private_points[t])) for t in rem]
    assert all(rich)
    print('pair',v,w,'uncovered projections 0; one extra private point',rich)
for v in private:
    left=failures((v,))
    assert left
    print('single',v,'uncovered projections',len(left))
for i in private:
    T=tuple(t for t in private if t!=i)
    left=failures(T,private_points[i])
    assert left=={private_points[i]|69}
    print('one dirty-private label',i,'triple recipient unique uncovered projection',left.pop())
