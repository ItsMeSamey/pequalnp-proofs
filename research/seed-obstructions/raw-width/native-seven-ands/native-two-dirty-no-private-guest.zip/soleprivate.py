from soleforward import negatives, private, stars
choices = exclusions = 0
for q, u in sorted(private.items()):
    for p, g in sorted(private.items()):
        if p == q:
            continue
        U, T = stars[u], stars[g]
        P = T & ~U
        assert p & P and (U & T).bit_count() == 1
        for i in range(13):
            z = 1 << i
            if not z & U:
                assert any(n & (u << 13) and n & z and n & P for n in negatives)
                exclusions += 1
            if not z & T:
                assert any(n & (g << 13) and n & z for n in negatives)
        choices += 1
print('private ordered host/guest charts', choices, 'ordinary point exits checked', exclusions)
