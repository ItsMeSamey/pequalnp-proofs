from pathlib import Path
from itertools import combinations
from collections import Counter

lines = [tuple(map(int, line.split())) for line in Path(__file__).with_name("native.in").read_text().splitlines()]
assert lines[0] == (28,468) and len(lines) == 497
edges = set(lines[1:29])
assert len(edges) == 28
neg = lines[29:]
points = [1 << i for i in range(13)]
tags = [1 << i for i in range(7)]
T = {v: {p for p,t in edges if t == v} for v in tags}
N = {p: {t for d,t in edges if d == p} for p in points}
assert all(len(T[v] & T[w]) == 1 for v,w in combinations(tags,2))
private = {p: next(iter(N[p])) for p in points if len(N[p]) == 1}
assert len(private) == 4
def negative(pm,tm):
    return any(n & pm == pm and w & tm == tm for n,w in neg)
ct = Counter()
for pm in range(8192):
    for tm in (range(128) if pm.bit_count() <= 3 else ()):
        k = pm.bit_count()+tm.bit_count()
        if k <= 2 or (k == 3 and pm and tm):
            if not any(pm & p and tm & v for p,v in edges):
                assert negative(pm,tm)
                ct['small and mixed rejected nonedges'] += 1
holes = {frozenset(trip) for trip in combinations(tags,3) if not negative(0,sum(trip))}
assert len(holes) == 6 and holes == {frozenset(n) for n in N.values() if len(n)==3}
print('pure tag triple holes',sorted(sum(h) for h in holes))
for q,u in private.items():
    for t in tags:
        if u == t: continue
        U = T[u]
        r, = U & T[t]
        partners = [j for j in tags if j not in (t,u) and frozenset((j,u,t)) in holes]
        assert len(partners) <= 1
        for j in partners:
            assert T[t] & T[j] == {r} and U & T[j] == {r}
            assert len((U|T[j]) & T[t]) == 1
            assert len((U|T[t]) & T[j]) == 1
            ct['two-arm exceptional geometry'] += 1
        for gm in range(128):
            G = {v for v in tags if gm & v}
            if u in G or t not in G or len(G)<2: continue
            outside = {d for d in points if d not in U and G <= N[d]}
            assert len(outside)<=1 and outside<=T[t]
            if outside:
                d, = outside
                assert G & N[r] == {t}
                for v in G:
                    f, = U&T[v]
                    assert (U|{d}) & T[v] == {d,f}
            ct['one-arm multitag geometry'] += 1
print(dict(ct))
