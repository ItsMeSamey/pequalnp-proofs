from fixed import *
from collections import Counter
import sys
def run(b,u):
    M=Chart(b,u)
    count=Counter();live=[];unknown=[]
    with Cadical195(bootstrap_with=M.C) as S:
        todo=list(domain())
        for budget in (300,1500):
            again=[]
            for k in todo:
                S.conf_budget(budget);out=S.solve_limited(assumptions=ass(M,k))
                if out is None:again.append(k)
                elif out:live.append((k,None))
                else:count['infeasible']+=1
            todo=again
        for k in todo:
            splits=sorted(M.fs) if u else [None]
            anySAT=False;incon=[]
            for m in splits:
                S.conf_budget(4000);out=S.solve_limited(assumptions=ass(M,k)+([M.V('G',2,m)] if m is not None else []))
                if out:anySAT=True;live.append((k,m));break
                if out is None:incon.append(m)
            if not anySAT:
                if incon:unknown.append((k,incon))
                else:count['infeasible']+=1
    print('census',b,u,count['infeasible'],len(live),len(unknown),flush=True)
    print('live',live,flush=True)
    print('unknown',unknown,flush=True)
if __name__=='__main__':
    b=int(sys.argv[1]);u=int(sys.argv[2])
    run((2,4),u or None)
