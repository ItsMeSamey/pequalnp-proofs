from fixed import *
from layouts import families,symmetry
import sys
b=private[:int(sys.argv[1])]; u=int(sys.argv[2]) or None
M=Chart(b,u)
W=families(M)
with Cadical195(bootstrap_with=M.C+list(symmetry(M,W))) as S:
    for g in range(4):
        S.conf_budget(4000);res=S.solve_limited(assumptions=M.backup(g))
        print('backup',b,u,g,res,flush=True)
