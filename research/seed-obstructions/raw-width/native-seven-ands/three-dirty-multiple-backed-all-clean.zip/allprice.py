from fixed import *
from layouts import *
import json,sys
b=private[:int(sys.argv[1])];M=Chart(b,None)
W=[];cc=Counter()
for k in json.load(open(f'keys{len(b)}-0.json'))['live']:
    ct=Counter()
    for w in tuples(M,ass(M,k)):
        W.append(w);T=library(M,w);res=lower(T);ct[res]+=1;cc[res]+=1
    print('footprint',k,sorted(ct.items()),flush=True)
open(f'lib{len(b)}.json','w').write(json.dumps(sorted(set(W)),separators=(',',':'))+'\n')
print('total',len(b),len(W),sorted(cc.items()),flush=True)
