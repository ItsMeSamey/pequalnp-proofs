from layouts import *
from autos import candidates
from controls import validate
import json
for k in (2,3):
    for b in combinations(private,k):
        E=[four(b,u) for u in private if u not in b]
        assert all(len(v)==6 and all(m<(1<<13) and m.bit_count()==4 for m in v) for v in E)
        assert all(not(x&y)for x,y in combinations(E,2))
from autos import N
assert len(rows)==676 and sum(s<0 for p,t,s in rows)==624 and len(N0)==468 and len(N)==245
P=sorted({tuple(sorted(sum(y for x,y in p.items() if m&x)for m in (129,4160)))for _,p in candidates()})
assert len(P)==12 and set.union(*(set(s)for s in P))=={129,320,513,1028,2052,4160}
M=Chart((2,4),None)
W=json.load(open('lib2.json'));assert len(set(map(tuple,W)))==160
C=Counter(lower(library(M,w))for w in W)
assert min(C)>=29
assert all(not json.load(open(f'lib{k}.json')) for k in (3,4))
for k,net in json.load(open('physical2.json')):
    validate(net)
    assert len(net['gates'])==41 and not net['accepted_independent_tag_masks']
    def marks(p,t):
        m=p|(t<<13);v=[bool(m&(1<<i))for i in range(20)];M={}
        for i,(o,a,b)in enumerate(net['gates'],20):
            if o=='and':M[i]=(v[a],v[b])
            v.append((v[a] and v[b]) if o=='and' else (v[a] or v[b]))
        return M
    Q={u:[i for i,x in marks(q[u],0).items() if any(x)]for u in private}
    assert all(len(l)==1 for l in Q.values()) and len({l[0] for l in Q.values()})==4
    off=set(net['dirty']);assert not any(i in off for l in Q.values() for i in l)
    for u in private:
        i,=Q[u];x=marks(q[u],0)[i];y=marks(0,u)[i]
        assert x in [(False,True),(True,False)] and y==x[::-1]
        assert sum(any(v)for v in marks(0,u).values())==1+(u in (2,4))
    for t in (*ordinary,*private):
        assert not any(all(v) for v in marks(0,t).values())
        assert sum(any(v)for v in marks(0,t).values())<=2
    for t,u in combinations((*ordinary,*private),2):
        assert sum(any(v)for v in marks(0,t|u).values())<=3
print('library',len(W),'supported pair transports',len(P),'verified prices',sorted(C.items()),'minimum',min(C))
print('actual full incidence controls',len(json.load(open('physical2.json'))))
