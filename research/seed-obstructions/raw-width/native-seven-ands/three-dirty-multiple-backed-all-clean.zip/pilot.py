from layouts import *
from itertools import product
import sys
b=(2,4)
for u in (None,8):
    M=Chart(b,u);W=families(M)
    C=M.C+list(symmetry(M,W))
    with Cadical195(bootstrap_with=C) as S:
        for g,opp in product(range(4),range(2)):
            # No orientation is fixed by this branch.
            x,y=[M.orig.index(v<<13) for v in b]
            a,c=M.V('w',g,0,x),M.V('w',g,0,y)
            cond=M.V('same',g);S.add_clause([-cond,-a,c]);S.add_clause([-cond,a,-c])
            S.add_clause([cond,a,c]);S.add_clause([cond,-a,-c])
            k=M.backup(g)+[cond if not opp else -cond]
            S.conf_budget(3000);ans=S.solve_limited(assumptions=k);print('pilot',u,g,opp,ans,flush=True)
