import json
from layouts import *
from fixed import ass
def build(w,backed):
    raw=list(w)+[x for t in private if t not in backed for x in (t<<13,sum(stars[t]))]
    sets=[{j for j in range(23) if m&(1<<j)}for m in raw]
    gates={};n=28
    while any(len(s)>1 for s in sets):
        freq=Counter(pair for s in sets for pair in combinations(sorted(s),2))
        x,y=min(freq,key=lambda z:(-freq[z],z))
        for s in sets:
            if {x,y}<=s:s.difference_update((x,y));s.add(n)
        gates[n]='or',x,y;n+=1
    vals=[next(iter(s)) for s in sets]
    for g in range(8):gates[20+g]='and',*vals[2*g:2*g+2]
    root=23
    for i in range(24,28):gates[n]='or',root,i;root=n;n+=1
    ids={i:i for i in range(20)};ops=[]
    def visit(i):
        if i in ids:return ids[i]
        o,a,b=gates[i];a=visit(a);b=visit(b);ids[i]=20+len(ops);ops.append([o,a,b]);return ids[i]
    output=visit(root)
    return dict(gates=ops,output=output)
def validate(net):
    def run(m):
        v=[bool(m&(1<<j))for j in range(20)]
        for o,a,b in net['gates']:v.append((v[a] and v[b]) if o=='and' else (v[a] or v[b]))
        return v
    dirty=set()
    for p,t,s in rows:
        v=run(p|t<<13)
        if s:assert v[net['output']]==(s>0)
        if s<0:dirty.update(i for i,(o,a,b)in enumerate(net['gates'],20) if o=='and' and v[i])
    assert len(dirty)==3 and sum(o=='and' for o,a,b in net['gates'])==8
    neg=[]
    for t in range(128):
        p=sum(i for i in set.union(*stars.values()) if all(not(v&t) or i not in stars[v] for v in stars))
        if run(p|t<<13)[net['output']]:neg.append(t)
    net['dirty']=sorted(dirty);net['accepted_independent_tag_masks']=neg
if __name__=='__main__':
    b=private[:int(argv[1])];M=Chart(b,None);out=[]
    for k in json.load(open(f'keys{len(b)}-0.json'))['live']:
        best=min((build(w,b)for w in tuples(M,ass(M,k))),key=lambda net:len(net['gates']))
        validate(best);out.append([k,best]);print('control',k,len(best['gates']),len(best['accepted_independent_tag_masks']),flush=True)
    open(f'physical{len(b)}.json','w').write(json.dumps(out,separators=(',',':'))+'\n')
