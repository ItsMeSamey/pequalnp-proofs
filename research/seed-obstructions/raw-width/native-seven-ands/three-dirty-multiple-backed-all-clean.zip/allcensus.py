from fixed import *
from layouts import symmetry,families
from collections import Counter
import json,sys
b=private[:int(sys.argv[1])];u=int(sys.argv[2]) or None
M=Chart(b,u);stat=Counter();live=[];pend=list(domain())
with Cadical195(bootstrap_with=M.C+list(symmetry(M,families(M))))as S:
    for budget in [300,1300,4500,12000]:
        again=[]
        for k in pend:
            S.conf_budget(budget);a=S.solve_limited(assumptions=ass(M,k))
            if a is None:again.append(k)
            else:
                stat[a]+=1
                if a:live.append(k)
        pend=again
        if not pend:break
print('census',len(b),u,stat,'open',len(pend),flush=True)
open(f'keys{len(b)}-{u or 0}.json','w').write(json.dumps({'live':sorted(live),'unknown':pend})+'\n')
