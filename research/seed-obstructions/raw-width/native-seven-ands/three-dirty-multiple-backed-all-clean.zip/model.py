from nativecontrol import rows,edges
from itertools import combinations,product,permutations
from pysat.formula import IDPool
from pysat.solvers import Cadical195
private=(2,4,8,32); ordinary=(1,16,64)
stars={u:{p for p,v in edges if v==u} for _,u in edges}
q={u:next(p for p in stars[u] if sum(p in S for S in stars.values())==1) for u in private}
regular=sorted(set.union(*stars.values())-set(q.values()))
N0={p|(t<<13) for p,t,y in rows if y<0}
def dominated(m):return any(m&~n==0 for n in N0)
def escape(m,U):return all(not dominated(m|p) for p in U)
def four(b,u):
    base=regular+[t<<13 for t in (*ordinary,*b)]
    return {sum(z) for k in (1,2,3,4) for z in combinations(base,k) if dominated(sum(z)) and escape(sum(z),stars[u])}
class Chart:
    def __init__(self,b,u):
        self.b=b; self.u=u
        tags=[*ordinary,*b]+([u] if u else [])
        own=list(b)+([u] if u else [])
        orig=regular+[t<<13 for t in tags]+[q[j] for j in own]
        self.orig=orig;nraw=len(orig);nn=4+len(own);self.nn=nn
        self.id=IDPool().id; V=self.V
        C=[];self.C=C
        def OR(o,ls):C.append([-o,*ls]);C.extend([o,-x] for x in ls)
        def AND(o,ls):C.append([o,*[-x for x in ls]]);C.extend([-o,x] for x in ls)
        P={self.pack(p,t) for p,t in edges if t in tags}
        N={self.pack(p,t)for p,t,y in rows if y<0}
        N={m for m in N if not any(m!=n and m&~n==0 for n in N)}
        tb=[self.pack(0,t) for t in (*ordinary,*b)]
        fs=set() if not u else {self.pack(m,0) for m in four(b,u)}
        if u:assert len(fs)==6
        self.fs=fs
        probes=sorted(P|N|{1<<i for i in range(nraw)}|{a|b for a,b in combinations(tb,2)}|fs)
        for g in range(nn):
            for s in (0,1):
                for i,x in enumerate(orig):
                    if g<4:
                        if x in regular or x in {t<<13 for t in (*ordinary,*b)}:continue
                        ok=False
                    else:
                        t=own[g-4]
                        if s==0:ok=x==t<<13
                        elif x in stars[t]:
                            if x!=q[t]:continue
                            ok=True
                        else:ok=False
                    C.append([(1 if ok else -1)*V('w',g,s,i)])
        if u:
            C.extend([[-V('w',nn-1,0,nraw)],[-V('w',nn-1,0,nraw+1)],[V('w',nn-1,0,nraw+2)]])
        for n in probes:
            for g in range(nn):
                arms=[]
                for s in (0,1):
                    w=[V('w',g,s,j) for j in range(nraw) if n&(1<<j)]
                    for h in range(min(3,g)):
                        y=V('g',g,s,h,n);AND(y,[V('w',g,s,nraw+h),V('G',h,n)]);w.append(y)
                    a=V('a',g,s,n);OR(a,w);arms.append(a)
                AND(V('G',g,n),arms);OR(V('hot',g,n),arms)
            if n in P:C.append([V('G',g,n)for g in range(3,nn)])
            if n in N:C.extend([-V('G',g,n)]for g in range(3,nn))
        for g in range(3):C.append([V('G',g,n) for n in N])
        for n in tb:
            for g in range(nn):C.append([-V('G',g,n)])
            for gs in combinations(range(nn),3):C.append([-V('hot',g,n)for g in gs])
        for a,b0 in combinations(tb,2):
            for gs in combinations(range(nn),4):C.append([-V('hot',g,a|b0)for g in gs])
        for k in (1,2,3):
            for ts in combinations(tb[:3],k):
                for cut in combinations(range(4),k-1):C.append([V('hot',g,n) for n in ts for g in range(4) if g not in cut])
        for tv in tb[3:]:
            C.append([V('hot',g,tv)for g in range(4)])
            for i,j in combinations(range(4),2):C.append([-V('hot',i,tv),-V('hot',j,tv)])
        for g in range(4):
            h0=V('hot',g,tb[3])
            for tv in tb[4:]:
                h1=V('hot',g,tv);C.extend([[-h0,h1],[h0,-h1]])
        if u:
            for p in stars[u]:C.append([V('a',nn-1,1,self.pack(p,0))])
            C.append([V('G',2,m) for m in fs])
    def pack(self,p,t):return sum(1<<j for j,x in enumerate(self.orig) if x&(p|(t<<13)))
    def V(self,*s):return self.id(s)
    def backup(self,bk):
        return [self.V('hot',g,self.pack(0,t))*(1 if g==bk else -1) for t in self.b for g in range(4)]
