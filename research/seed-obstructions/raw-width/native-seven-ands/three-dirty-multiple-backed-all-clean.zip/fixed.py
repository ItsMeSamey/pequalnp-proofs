from model import *
from itertools import product
opts=[m for m in range(1,16)if m.bit_count()<=2]
def domain():
    for k in product(opts,repeat=3):
        if any((a|b).bit_count()>3 for a,b in combinations(k,2)):continue
        if not any(all(m&(1<<g) for m,g in zip(k,gs)) for gs in permutations(range(4),3)):continue
        for g in range(4):
            if all((m|(1<<g)).bit_count()<=2 for m in k):yield (*k,g)
def ass(M,k):
    return M.backup(k[-1])+[M.V('hot',g,M.pack(0,t))*(1 if m&(1<<g) else -1) for t,m in zip(ordinary,k[:3]) for g in range(4)]
if __name__=='__main__':
    import sys
    M=Chart((2,4),int(sys.argv[2]) or None)
    limit=int(sys.argv[3])
    with Cadical195(bootstrap_with=M.C) as S:
        for k in domain():
            S.conf_budget(limit);res=S.solve_limited(assumptions=ass(M,k))
            print(k,res,flush=True)
