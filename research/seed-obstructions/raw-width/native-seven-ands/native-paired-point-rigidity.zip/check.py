from contextlib import redirect_stdout
from itertools import combinations
from functools import cache, reduce
from collections import Counter
from operator import or_
import io
with redirect_stdout(io.StringIO()):
    import chart_inputs as native
P = [p | t << 13 for p,t in native.pos]
N = [p | t << 13 for p,t in native.neg]
def atoms(s):
    return [1 << j for j in range(20) if s & (1<<j)]

@cache
def instance(Q, blocked_points):
    removed = Q | blocked_points | reduce(or_, (e for e in P if e & Q),0)
    edges = [e for e in P if not e & removed]
    vertices = reduce(or_,edges,0)
    tags = vertices & ~8191
    allowed = [n for n in N if not Q & ~n]
    targets = set()
    for n in allowed:
        required = reduce(or_,(e & tags for e in edges if e & n & 8191),0)
        if required == tags ^ (tags & n):
            targets.add(required)
    return vertices, tags, edges, allowed, targets

counts = Counter()
rigid = Counter()
for p,q in combinations(range(13),2):
    Q = (1 << p) | (1 << q)
    _, T0, _, negative, Z0 = instance(Q,0)
    # Free points that never coexist with Q in a given signed negative.
    blocked = 8191 & ~reduce(or_,negative,0)
    V,T,E,negative,Z = instance(Q, blocked)
    tags = atoms(T)
    m = len(tags)
    assert T0 == T and Z0 == Z and len(Z) * 2 > (1 << m)
    assert all(4 * sum(not (M & t) for M in Z) > (1 << m) for t in tags)
    assert all({M & (u|t) for M in Z} == {0,t,u,t|u}
               for t,u in combinations(tags,2))
    assert all(any(n&t for n in negative) for t in tags)
    counts[m,len(Z)] += 1
    strong = True
    for r in atoms(V & 8191):
        assert any(n&r for n in negative)
        d = sum(bool(e&r) for e in E)
        _, _, _, _, Z3 = instance(Q|r, blocked)
        if 2 * len(Z3) <= 1 << (m-d): strong = False
    if strong:
        assert all(sum(bool(e&t) for e in E)==3 for t in tags)
        rigid[m,len(E)] += 1
    print(p,q,blocked,m,len(Z),int(strong))
print('tag ownership',sorted(counts.items()))
print('full restricted rigidity',sorted(rigid.items()))
assert sum(counts.values())==78 and rigid=={(2,6):21,(3,9):24}
