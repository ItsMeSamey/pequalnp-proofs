"""Check any candidate produced by the production solver on the actual native rows."""
from model import *
from collections import Counter
from pathlib import Path
import json
def check(m,assignment,key):
    a=set(assignment);words=[]
    for g in range(8):
        for s in (0,1):words.append({j for j,v in enumerate(m.selectors[g,s])if v in a})
    assert all(words)
    gates={};idx=28
    while any(len(w)>1 for w in words):
        pairs=Counter(p for w in words for p in combinations(sorted(w),2));ab=min(pairs,key=lambda p:(-pairs[p],p))
        gates[idx]=('or',*ab)
        for w in words:
            if set(ab)<=w:w.difference_update(ab);w.add(idx)
        idx+=1
    for g in range(8):gates[20+g]=('and',*[next(iter(w))for w in words[2*g:2*g+2]])
    nodes=[];wire={i:i for i in range(20)}
    def visit(g):
        if g not in wire:
            op,l,r=gates[g];l=visit(l);r=visit(r);wire[g]=20+len(nodes);nodes.append((op,l,r))
        return wire[g]
    out=visit(27);live=[g for g in range(8) if 20+g in wire]
    assert len(live)==8,(key,'nonlive candidate',live)
    def evaluate(n):
        v=[bool(n&(1<<j))for j in range(20)]
        for op,l,r in nodes:v.append((v[l] and v[r]) if op=='and' else (v[l] or v[r]))
        ss=[tuple(v[i]for i in nodes[wire[20+g]-20][1:])for g in live]
        return v[out],{g for g,x in enumerate(ss) if all(x)},{g for g,x in enumerate(ss)if any(x)},ss
    counts=Counter(y for _,_,y in rows)
    assert counts=={-1:624,0:24,1:28}
    dirt=set()
    for p,t,y in rows:
        val,on,_,_=evaluate(p|sx(t))
        if y:assert val==(y>0)
        if y<0:dirt.update(on)
    assert dirt==set(range(7))
    for t,g in m.owner.items():
        back=m.B if m.mode=='ext' or t==32 else m.owner[32]
        assert evaluate(q[t])[2]=={g} and evaluate(sx(t))[2]=={g,back}
        assert {g,back}<=evaluate(q[t]|sx(t))[1]
        guest=m.mode=='ext' or t!=32
        if guest:
            assert all(g not in evaluate(p)[1] for p in points)
            assert all(evaluate(p)[3][g][1] for p in points if p&U[t])
        for p,v,y in rows:
            if y<0:
                on=evaluate(p|sx(v))[1]
                assert not {g,back}<=on
                if v&t or guest and v&sum(private):assert g not in on
    for t in tags:
        _,on,hot,ss=evaluate(sx(t));assert not on and len(hot)<=2
        assert any(ss[g][s] and all(not evaluate(sx(j))[3][g][s]for j in tags if j!=t)for g in live for s in (0,1))
    assert all(len(evaluate(sx(t|u))[2])<=3 for t,u in combinations(tags,2))
    from itertools import permutations
    assert any(all(g in evaluate(sx(t))[2]for g,t in zip(ss,ordinary))for ss in permutations(m.exterior,3))
    # Trace actual physical gate ancestry after sharing ORs; count exterior predecessors per private gate.
    prefix={i:set()for i in range(20)};index={wire[20+i]:i for i in live}
    for n,(op,l,r) in enumerate(nodes,20):
        pre=prefix[l]|prefix[r]
        if n in index:
            site=index[n]
            if site in m.owner.values():assert len(pre & (set(m.exterior)-{7}))>=2
            prefix[n]=pre|{site}
        else:prefix[n]=pre
    Path(key+'.gates.json').write_text(json.dumps(dict(gates=nodes,output=out),separators=(',',':')))
    print(key,'676 native rows; live ANDs',len(live),'dirties',len(dirt),'raw binary gates',len(nodes),flush=True)
