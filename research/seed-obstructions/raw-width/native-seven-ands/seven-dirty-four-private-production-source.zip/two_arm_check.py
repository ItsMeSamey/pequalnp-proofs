"""Inspect all clauses linking the D6 selection to each terminal operand on a named native row."""
from model import Model,charts,P
def check(chart):
    m=Model(*chart);row=min(P);ng=m.G(6,row);out=m.G(7,row)
    # A witness variable occurs in the ternary conjunction clause paired with
    # this exact wire and donor. Check the full gate substitution independently.
    for s in (0,1):
        w=m.selectors[7,s][26];assert w==m.W(7,s,26)
        na=m.A(7,s,row)
        joint,=[c[0] for c in m.C if len(c)==3 and c[1:]==[-w,-ng]]
        required={(joint,-w,-ng),(-joint,w),(-joint,ng),(na,-joint),(-out,na)}
        rest={tuple(c)for c in m.C if c and (c[0]in (joint,-joint,na,-out))}
        assert required<=rest
        assert any(c[0]==-na and joint in c[1:]for c in m.C if c)
    assert [out,-m.A(7,0,row),-m.A(7,1,row)]in m.C
    assert set(charts())=={(group,b,e)for group in ('ext','hub') for b,e in [(6,6),*((7,e)for e in range(2,7))]}
    print(chart,'full D6 gated evaluation and terminal AND verified separately on both normalized sockets')
if __name__=='__main__':check(('hub',7,6))
