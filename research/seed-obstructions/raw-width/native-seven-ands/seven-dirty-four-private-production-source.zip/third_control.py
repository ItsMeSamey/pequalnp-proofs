"""D6 as the third exterior distinct from the sole clean backup B=7, ext-7-6."""
from pathlib import Path
from donor_control import evaluate
from model import *
def diagram():
    w=[(128,512|sx(1)),(256,4096|sx(64))]
    for t in private:w.append((sx(t)|(1<<20)|(1<<21),U[t]))
    old=1<<25
    w.append((old|sx(16),old|1024))
    other=(1<<22)|(1<<23)|(1<<24)
    w.append((sx(sum(private)),other|(1<<26)))
    return w
def native(w):
    dirty=set();goodpos=set();lost=set()
    for p,t,y in rows:
        good,_=evaluate(w,p|sx(t));omit,_=evaluate(w,p|sx(t),True)
        if y<0:
            assert not good[7] and not omit[7]
            dirty.update(i for i,z in enumerate(good)if z)
        if y>0:
            if good[7]:goodpos.add((p,t))
            if good[7] and not omit[7]:lost.add((p,t))
    assert dirty==set(range(7))and goodpos=={e for e in edges if e[1] in private}
    assert lost=={e for e in edges if e[1]==32}
    def hot(m):return {i for i,row in enumerate(evaluate(w,m)[1])if any(row)}
    for g,t in enumerate(private,2):
        assert hot(q[t])=={g} and hot(sx(t))=={g,7}
        for p in points:
            if p&U[t]:assert evaluate(w,p)[1][g][1]
    for t in tags:
        assert not any(evaluate(w,sx(t))[0]) and len(hot(sx(t)))<=2
        assert any(evaluate(w,sx(t))[1][g][s] and all(not evaluate(w,sx(v))[1][g][s] for v in tags if v!=t)for g in range(8)for s in (0,1))
    assert all(len(hot(sx(a|b)))<=3 for a,b in combinations(tags,2))
    assert all(hot(sx(t))=={g}for t,g in ((1,0),(64,1),(16,6)))
    print('ext-7-6: seven genuine dirties, sixteen private positive rows; D6 loss',sorted(lost))
def check(cls,w,expected):
    from pysat.solvers import Glucose4
    m=cls('ext',7,6);pins=[]
    for g,h in enumerate(w):
        arms=list(h)
        if g in m.exterior:arms.sort(key=lambda z:tuple(bool(z&(1<<j))for j in range(20+min(g,7))))
        for s,z in enumerate(arms):pins.extend((1 if z&(1<<j)else -1)*v for j,v in enumerate(m.selectors[g,s]))
    ordinary_demands={m.positive[p|sx(t)]for p,t in edges if t in ordinary}
    assert len(ordinary_demands)==12
    with Glucose4(bootstrap_with=[c for c in m.C if tuple(c)not in ordinary_demands])as sol:assert sol.solve(assumptions=pins)is expected
    with Glucose4(bootstrap_with=m.C)as sol:assert sol.solve(assumptions=pins)is False
if __name__=='__main__':
    import sys
    w=diagram();native(w)
    if '--signed-cnf'in sys.argv:
        text=Path(__file__).with_name('model.py').read_text()
        x='for d in range(min(g,7)))';assert text.count(x)==1;ns={'__name__':'omit_d6'}
        exec(compile(text.replace(x,'for d in range(min(g,6)))'),'omit_d6.py','exec'),ns)
        check(Model,w,True);check(ns['Model'],w,False)
        print('pinned corrected SAT, omitted-D6 UNSAT on 16; both UNSAT on full 28 demand')
