"""One explicitly requested bounded operation, with no job discovery or automatic continuation."""
from pathlib import Path
import os,sys,time,subprocess
def main(token):
    if token=='shape-both':args=['two_arm_check.py']
    elif token in ('control-6','control-7'):args=['donor_control.py',token[-1],'--signed-cnf']
    elif token=='control-third':args=['third_control.py','--signed-cnf']
    elif token in ('native-6','native-7'):args=['donor_control.py',token[-1]]
    elif token=='native-third':args=['third_control.py']
    else:
        keys={f'{mode}-{b}-{x}' for mode in ('ext','hub') for b,x in [(6,6),*((7,j) for j in range(2,7))]}
        assert token in keys
        args=['production.py','/workspace/scratch/syn_pruning/bank11/drat-trim',token]
    cmd=['flock','-F','/workspace/scratch/pnp-native-search.lock','nice','-n','15','timeout','10s','prlimit','--cpu=8','--as=167772160',sys.executable,'-B',*args]
    start=time.monotonic()
    res=subprocess.run(cmd,cwd=Path(__file__).parent,env=dict(os.environ,PYTHONPATH='/tmp/refute-pysat',PYTHONUNBUFFERED='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    body=res.stdout+f'elapsed={time.monotonic()-start:.3f} rc={res.returncode}\n'.encode()
    Path(__file__).with_name(token+'.log').write_bytes(body);sys.stdout.buffer.write(body)
    return res.returncode
if __name__=='__main__':sys.exit(main(sys.argv[1]))
