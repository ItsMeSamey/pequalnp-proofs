from nativecontrol import rows,edges
from itertools import combinations
from pysat.formula import IDPool
from pysat.solvers import Cadical195
from sys import argv
from pysat.solvers import Glucose4

private=(2,4,8,32)
ordinary=(1,16,64)
stars={t:{p for p,v in edges if v==t} for _,t in edges}
qs={u:next(p for p in stars[u] if sum(p in S for S in stars.values())==1) for u in private}
regular=sorted(set.union(*stars.values())-set(qs.values()))
def run(backed,bak,emit=None):
    sites=4+len(backed)
    tags_here=(*ordinary,*backed)
    orig=regular+[t<<13 for t in tags_here]+[qs[t] for t in backed]
    nraw=len(orig)
    def mask(p,t):return sum(1<<j for j,a in enumerate(orig) if a&(p|(t<<13)))
    tags=[mask(0,t) for t in tags_here]
    pos={mask(p,t) for p,t,y in rows if y>0 and t in tags_here}
    neg={mask(p,t) for p,t,y in rows if y<0}
    neg={n for n in neg if not any(n!=m and n&~m==0 for m in neg)}
    probes=set(pos)|neg|{1<<j for j in range(nraw)}|{a|b for a,b in combinations(tags,2)}
    # Include the original, uncompressed signed masks to test safety of a proposed repair.
    actualN={mask(p,t) for p,t,y in rows if y<0}
    probes |= actualN
    key=IDPool().id; V=lambda *args:key(args)
    C=[]
    def And(o,ls): C.append([o]+[-x for x in ls]);C.extend([-o,x] for x in ls)
    def Or(o,ls): C.append([-o]+ls);C.extend([o,-x] for x in ls)
    def t(g,s,j):return V('term',g,s,j)
    def a(g,s,m):return V('arm',g,s,m)
    def G(g,m):return V('and',g,m)
    def h(g,m):return V('hot',g,m)
    for g in range(sites):
        for s in (0,1):
            for j,z in enumerate(orig):
                if g<4:
                    if j<12:continue
                    ok=12 <= j < 12+len(backed) and g==bak and s==0
                else:
                    x=backed[g-4]
                    if s==0:ok=z==x<<13
                    elif z in stars[x]:
                        if z!=qs[x]:continue
                        ok=True
                    else:ok=False
                C.append([t(g,s,j) if ok else -t(g,s,j)])
    for m in sorted(probes):
        for g in range(sites):
            for s in (0,1):
                ls=[t(g,s,j) for j in range(nraw) if (m>>j)&1]
                for d in range(min(g,2)):
                    o=V('donor',g,s,d,m)
                    And(o,[t(g,s,nraw+d),G(d,m)]);ls.append(o)
                Or(a(g,s,m),ls)
            And(G(g,m),[a(g,0,m),a(g,1,m)])
            Or(h(g,m),[a(g,0,m),a(g,1,m)])
        if m in pos:C.append([G(g,m) for g in range(2,sites)])
        if m in neg:
            for g in range(2,sites):C.append([-G(g,m)])
    for g in (0,1):C.append([G(g,m) for m in neg])
    for x in tags:
        for g in range(sites):C.append([-G(g,x)])
        for gg in combinations(range(sites),3):C.append([-h(g,x) for g in gg])
    for x,y in combinations(tags,2):
        for gg in combinations(range(sites),4):C.append([-h(g,x|y) for g in gg])
    cuts=[[-a(g,1,mask(p,0)) for p in stars[tg]] for g,tg in enumerate(backed,4)]
    if emit is not None:
        return emit(C,cuts)
    solver = Glucose4 if '--glucose' in argv else Cadical195
    with solver(bootstrap_with=C) as S:
        base=S.solve()
        if base:
            M=set(S.get_model())
            W=[[sum(1<<j for j in range(nraw+min(g,2)) if t(g,s,j) in M) for s in (0,1)] for g in range(sites)]
            def evalrow(p,t):
                m=mask(p,t);bits=[]
                for g,(left,right) in enumerate(W):
                    bits.append([bool(m&left),bool(m&right)])
                    if all(bits[-1]):m|=1<<(nraw+g)
                for h in private:
                    if h not in backed:bits.append([bool(t&h),bool(p&sum(stars[h]))])
                return bits
            dirty=set()
            for p,tg,z in rows:
                bits=evalrow(p,tg)
                if z<0:dirty.update(g for g,b in enumerate(bits) if all(b))
                if z:assert any(all(b) for b in bits[2:])==(z>0)
            assert dirty=={0,1}
            for tg in private:
                bits=evalrow(0,tg)
                assert sum(any(b) for b in bits)==1+(tg in backed)
            for tg in (*ordinary,*private):
                assert not any(all(b) for b in evalrow(0,tg))
            for x,y in combinations((*ordinary,*private),2):
                assert sum(any(b) for b in evalrow(0,x|y))<=3
            print('native control',backed,bak,W,flush=True)
        for clause in cuts:S.add_clause(clause)
        deficient=S.solve()
        print('status',backed,bak,base,deficient,flush=True)
    return base,deficient
if __name__=='__main__':
    for k in (2,3,4):
        for backed in combinations(private,k):
            for b in (0,1):
                yes,escaped=run(backed,b)
                assert yes == (len(backed)==2 and b==1)
                assert escaped is False
