from pathlib import Path
import gzip, hashlib,sys,tempfile,subprocess
from itertools import combinations
from pysat.solvers import Glucose4
from proofmodel import run,private
out=Path(__file__).parent/'drat'
def digest(b):return hashlib.sha256(b).hexdigest()
def case(backed,b):
    def check(C, cuts):
        base=not(len(backed)==2 and b==1)
        if not base:C=C+cuts
        key='-'.join(map(str,(*backed,b)))+('-base' if base else '-def')
        cnf=('p cnf %d %d\n'%(max(abs(x) for c in C for x in c),len(C))+''.join(' '.join(map(str,c))+' 0\n' for c in C)).encode()
        archive=out/(key+'.drat.gz')
        if '--verify-only' in sys.argv:
            proof=gzip.decompress(archive.read_bytes())
        else:
            with Glucose4(bootstrap_with=C,with_proof=True) as S:
                assert S.solve() is False
                proof=('\n'.join(S.get_proof())+'\n').encode()
            archive.write_bytes(gzip.compress(proof,compresslevel=6,mtime=0))
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);f=p/'case.cnf';g=p/'case.drat';f.write_bytes(cnf);g.write_bytes(proof)
            cmd=[sys.argv[1],str(f),str(g),'-t','30']
            R=subprocess.run(cmd,capture_output=True,timeout=40)
            assert R.returncode==0 and 's VERIFIED' in R.stdout.decode(),(key,R.returncode,R.stdout[-300:])
        print(key,len(C),len(proof),len(archive.read_bytes()),digest(cnf),digest(proof),'VERIFIED',flush=True)
    run(backed,b,check)
if __name__=='__main__':
    for k in (2,3,4):
        for group in combinations(private,k):
            for b in (0,1):case(group,b)
