exec(open('raw.py').read().split('pairs=0')[0])
from collections import Counter
import sys
NB={1<<i:0 for i in range(20)}
for edge in P:
 for v in bits(edge):NB[v]|=edge^v
@lru_cache(None)
def hostcost(ts):
    ts=set(ts);base=set.union(*(set(bits(t)) for t in ts));start=frozenset(base);Q={start}
    for i in range(16):
        if any(ts<=v for v in Q):return i
        new=set()
        for v in Q:
            for a,b in combinations(v,2):
                c=a|b
                if c not in v and any(not c&~t for t in ts):new.add(v|{c})
        Q=new
    raise AssertionError
hist=Counter()
for s in sys.stdin:
 if not s.startswith('pass'):continue
 _,a,b,c,d,mode,M,L=s.split();a,b,c,d,mode,M=map(int,(a,b,c,d,mode,M))
 hosts={};other=set()
 for x in set((a,b,c,d)):
    ht=[v for v,t in NB.items() if not x&~t]
    if len(ht)==1:hosts.setdefault(ht[0],set()).add(x)
    else:
        assert x&8191 and x>>13
        other.add(x)
 F=sum(hosts)
 unc=[e for i,e in enumerate(P) if not M>>i&1 and not e&F]
 pre=sum(hostcost(tuple(sorted(X))) for X in hosts.values())+len(other)
 # All K inlet raw clauses, whether one or both contain H, are nonempty.
 pay=13+1+pre+max(0,len(unc)-6)
 hist[pay]+=1
 print(a,b,c,d,mode,M,pay,len(unc),pre)
print('bounds',sorted(hist.items()),file=sys.stderr)
