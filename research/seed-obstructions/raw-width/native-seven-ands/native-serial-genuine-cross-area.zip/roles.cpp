#include <algorithm>
#include <array>
#include <bitset>
#include <cstdio>
#include <cstdint>
#include <iostream>
#include <unordered_set>
#include <vector>
using namespace std;
struct Sig { uint32_t p=0;bitset<512> n; };
Sig operator|(const Sig&a,const Sig&b){return {a.p|b.p,a.n|b.n};}
Sig operator&(const Sig&a,const Sig&b){return {a.p&b.p,a.n&b.n};}
struct Rect{Sig left,right;uint32_t raw;};
Sig atom[20];vector<Rect> rec;int E[28];uint32_t full=(1u<<28)-1;
Sig arm(int m){Sig r;for(;m;m&=m-1)r=r|atom[__builtin_ctz(m)];return r;}
using P=pair<int,uint32_t>;
vector<P> slots[28];int addr[8],req=0;
bool matching(int u,int seen){
 if(u==7)return true;
 for(int i=0;i<8;++i)if(!(seen>>i&1)&&(addr[i]>>u&1)&&matching(u+1,seen|1<<i))return true;
 return false;
}
int encode(int v){return v>>13 | ((v&2)?128:0)|((v&8)?256:0)|((v&16)?512:0)|((v&32)?1024:0);}
bool valid(int a,int b){
 int q=(a|b)&58;
 if(!q)return true;
 if((q&(q-1))||(a&b&q))return false;
 int u=(q==2?32:q==8?2:q==16?4:8)<<13;
 return bool((a&q?b:a)&u);
}
int host=0,cross=0,st[7]={};bitset<512> blackout[7][7];
int own(int q){return q==2?5:q==8?1:q==16?2:3;}
bool role(int A,int B,const Sig&L,const Sig&R){
 int q=(A|B)&58,m=(A|B)>>13;
 if(q)return (m&81)==(q==host?cross:0);
 int c=m&cross;if(!c)return true;
 if(c&(c-1))return false;
 int i=__builtin_ctz(c),j=own(host),bit=c<<13;
 if(bool(A&bit)==bool(B&bit))return false;
 if((((A&bit)?B:A)&(st[i]&~st[j]))!=(st[i]&~st[j]))return false;
 return (((A&bit)?L:R).n&blackout[j][i]).none();
}
bool assigned(int i,int used){
 if(i==3)return true;
 int u=(i==0?0:i==1?4:6);
 for(int j=0;j<8;j++)if(!(used>>j&1)&&!(addr[j]&1920)&&(addr[j]&(1<<u))&&assigned(i+1,used|(1<<j)))return true;
 return false;
}
bool endtest(){
 for(int m:{17,65,80}){int n=0;for(int j=0;j<8;j++)n+=bool(addr[j]&m);if(n>3)return false;}
 return assigned(0,0)&&matching(0,0);
}
bool search(uint32_t rem,int k,int once,int twice){
 if(!rem)return k==8&&!(req&~twice)&&endtest();
 if(k==8)return false;
 int b=__builtin_ctz(rem);
 for(auto v=rem;v;v&=v-1)if(slots[__builtin_ctz(v)].size()<slots[b].size())b=__builtin_ctz(v);
 for(auto [m,p]:slots[b])if(!(twice&m)&&!(once&m&1920)){
 addr[k]=m;if(search(rem&~p,k+1,once|m,twice|(once&m)))return true;
 }
 return false;
}
struct R{int a,b;uint32_t raw;};struct Tm{int m;uint32_t p,r;};
int main(int argc,char**argv){
 FILE*f=fopen("native.in","r");int n,m,p,t;fscanf(f,"%d%d",&n,&m);
 for(int i=0;i<n+m;++i){fscanf(f,"%d%d",&p,&t);int e=p|(t<<13);if(i<n)E[i]=e;
 for(int j=0;j<20;++j)if(e>>j&1){if(i<n)atom[j].p|=1u<<i;else atom[j].n.set(i-n);}}
 vector<R> rs;for(int j=0;j<20;++j){auto s=atom[j].p;for(auto z=s;z;z=(z-1)&s){
 int b=0;for(auto y=z;y;y&=y-1)b|=E[__builtin_ctz(y)]^(1<<j);rs.push_back({1<<j,b,z});}}
 int a,b,c,d,mode;uint32_t M;int num=0,weak=0,final=0;
 host=atoi(argv[1]);cross=atoi(argv[2]);for(auto e:E)st[__builtin_ctz(e>>13)]|=e&8191;
 for(int j=0;j<7;j++)for(int i=0;i<7;i++)blackout[j][i]=(atom[13+j]&arm(st[i]&~st[j])).n;
 while(cin>>a>>b>>c>>d>>mode>>M){
 ++num;auto H=arm(a)&arm(b);auto K=mode==1?(H|arm(c))&arm(d):H|(arm(c)&arm(d));
 Sig T[4]={{},H,K,H|K};vector<Tm> terms;
 int h=a&b,k=mode==1?(h|c)&d:h|(c&d);
 int flags[4]={0,h,k,h|k};
 if(!role(a,b,arm(a),arm(b))||!role(c|h,d|(mode==2?h:0),arm(c)|H,(mode==2?arm(d)|H:arm(d))))continue;
 if(!valid(a,b)||!valid(c|h,d|(mode==2?h:0)))continue;
 auto dark=[&](int left,int right,const Sig &L,const Sig &R){int q=(left|right)&58;
 if(!q)return true;int u=q==2?5:q==8?1:q==16?2:3;
 return ((left&q?L.n:R.n)&atom[13+u].n).none();};
 if(!dark(a,b,arm(a),arm(b))||!dark(c|h,d|(mode==2?h:0),arm(c)|H,mode==2?arm(d)|H:arm(d)))continue;
 addr[0]=encode(a|b);addr[1]=encode(c|d|h);
 if(addr[0]&addr[1]&1920)continue;
 int once=addr[0]|addr[1],twice=addr[0]&addr[1];
 auto put=[&](int a,int b,uint32_t r,int i,int j){
 if(!valid(a|flags[i],b|flags[j])||!role(a|flags[i],b|flags[j],arm(a)|T[i],arm(b)|T[j]))return;
 int m=encode(a|b|flags[i]|flags[j]);if((m&twice)||(m&once&1920))return;
 auto z=(arm(a)|T[i])&(arm(b)|T[j]);if(z.n.none()&&z.p)terms.push_back({m,z.p,r});
 };
 for(auto r:rs)for(int i=0;i<4;i++)for(int j=0;j<4;j++)put(r.a,r.b,r.raw,i,j);
 for(int i=1;i<4;i++){
 int av=0;for(int j=0;j<20;j++)if((atom[j].n&T[i].n).none())av|=1<<j;
 for(auto mm=M;mm;mm&=mm-1){
 int bit=__builtin_ctz(mm),ban=(T[i].p&1u<<bit)?E[bit]:0,B=av&~ban;
 for(int tags=(B>>13);;tags=(tags-1)&(B>>13)){
 for(int q=B&58;;q=(q-1)&(B&58)){for(int j=0;j<4;j++){int b=(B&(8191^58))|q|(tags<<13);put(0,b,0,i,j);
 if(host && (((b|flags[j])>>13)&cross))put(0,b&(st[own(host)]|(127<<13)),0,i,j);}if(!q)break;}if(!tags)break;}
 }}
 bool pass=false;
 for(auto L=M;L&&!pass;L=(L-1)&M){
 int sz=__builtin_popcount(L);if(sz<8||sz>10)continue;
 vector<P> pool,maxs;for(auto x:terms)if(!(x.r&L)&&(L&~x.p))pool.emplace_back(x.m,x.p);
 sort(pool.begin(),pool.end(),[](auto a,auto b){if(a.first!=b.first)return a.first<b.first;return __builtin_popcount(a.second)>__builtin_popcount(b.second);});
 for(auto &q:slots)q.clear();
 for(auto z:pool){bool sub=false;for(auto w:maxs)if(z.first==w.first&&!(z.second&~w.second)){sub=true;break;}if(sub)continue;
 maxs.push_back(z);for(auto n=z.second;n;n&=n-1)slots[__builtin_ctz(n)].push_back(z);}
 if(search(full,2,once,twice)){pass=true;cout<<"pass "<<a<<" "<<b<<" "<<c<<" "<<d<<" "<<mode<<" "<<M<<" "<<L<<endl;}
 }final+=pass;
 }cout<<"total "<<num<<" pass "<<final<<endl;return 0;}
