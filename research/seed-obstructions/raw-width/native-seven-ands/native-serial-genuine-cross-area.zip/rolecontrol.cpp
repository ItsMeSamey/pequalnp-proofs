#define main prior_driver
#include "roles.cpp"
#undef main
int main(){
 FILE*f=fopen("native.in","r");int n,m,p,t;fscanf(f,"%d%d",&n,&m);
 for(int i=0;i<n+m;++i){fscanf(f,"%d%d",&p,&t);int e=p|(t<<13);if(i<n){E[i]=e;st[__builtin_ctz(t)]|=p;}for(int j=0;j<20;++j)if(e>>j&1){if(i<n)atom[j].p|=1u<<i;else atom[j].n.set(i-n);}}
 for(int j=0;j<7;j++)for(int i=0;i<7;i++)blackout[j][i]=(atom[13+j]&arm(st[i]&~st[j])).n;
 int cnt=0;for(int q:{2,8,16,32})for(int c:{1,16,64,17,65,80,81}){
 host=q;cross=c;int h=own(q);Sig result;int once=0,twice=0;
 for(int j=0;j<7;j++){int l=st[j],r=((1<<j)|(j==h?c:0))<<13;
 if(!valid(l,r)||!role(l,r,arm(l),arm(r)))return 1;
 addr[j]=encode(l|r);if(addr[j]&twice)return 2;twice|=addr[j]&once;once|=addr[j];
 auto z=arm(l)&arm(r);if(j==h){int v=1<<(13+j);
 if(!role(0,v,z,arm(v)))return 3;
 addr[7]=encode(v);z=z&arm(v);}result=result|z;}
 if((addr[7]&twice)||result.p!=full||result.n.any()||!endtest())return 4;
 ++cnt;}
 cout<<cnt<<" original crossing controls passed"<<endl;
}
