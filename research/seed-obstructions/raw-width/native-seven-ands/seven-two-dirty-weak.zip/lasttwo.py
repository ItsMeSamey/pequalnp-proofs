from itertools import combinations
from cuts import load,bm
P,N=load(());P=[r&1048575 for r in P];N=[r&1048575 for r in N]
U=(1<<20)-1
def covers(rows):
 masks={0}
 for row in rows:
  masks={x|y for x in masks for y in ([0]if x&row else bm(row))}
 return [x for x in masks if not any(y!=x and not y&~x for y in masks)]
def test(j,k):
 pos=[p for p in P if p&((1<<(13+j))|(1<<(13+k)))]
 for b in covers(pos):
  ng=[n for n in N if n&b];a=U
  for n in ng:a &=~n
  req=[p for p in pos if not p&a]
  arms=covers(req)
  for c,d in ((c,d)for c in arms for d in arms if c<=d):
   if any(n&c and n&d for n in ng):continue
   for t in N:
    if t&b:continue
    for x in ([0]if t&c else bm(t)):
     for y in ([0]if t&d else bm(t)):
      if not any(n&(c|x) and n&(d|y)for n in ng):
       return b,a,c|x,d|y,t
if __name__=='__main__':
 for j,k in combinations(range(7),2):print(j,k,test(j,k),flush=True)
