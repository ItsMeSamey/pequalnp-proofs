from itertools import permutations,product
from collections import Counter
from cuts import bm,load,extra
P,N=load(())
P=[r&1048575 for r in P];N=[r&1048575 for r in N]
assert len(P)==28 and len(N)==245
tags=tuple(1<<u for u in range(7));pts=tuple(1<<p for p in range(13))
hood={p:sum(r>>13 for r in P if r&p)for p in pts}
assert all(any(not ((p|t<<13)&~n)for n in N)for p in pts for t in tags if not hood[p]&t)
assert all(any(p&n for n in N) for p in pts)
def actions():
 by={v:k for k,v in hood.items()}
 for a in permutations((1,2,3,5)):
  for b in permutations((0,4,6)):
   pi=dict(zip((1,2,3,5,0,4,6),a+b))
   h=lambda s:sum(1<<pi[t.bit_length()-1]for t in bm(s))
   if not all(h(n)in by for n in hood.values()):continue
   pm={p:by[h(n)]for p,n in hood.items()}
   tr=lambda n:sum(pm[p]for p in pts if n&p)|(h(n>>13)<<13)
   yield pm,[tr(n)for n in N]
def run(src,lib):
 out=[];act=Counter()
 for i,(pm,ns) in enumerate(actions()):
  ims=[sum(pm[p]for p in pts if p&s)for s in src]
  domains=[sum(1<<j for j,n in enumerate(ns) if not t&~n)for t in N]
  if not all(domains):continue
  neg=[sum(1<<j for j,n in enumerate(ns) if n&s)for s in ims]
  for ds in product(*[[m for m in lib if not s&~m]+[-1] for s in ims]):
   if all(__import__('functools').reduce(int.__and__,[neg[k]for k,m in enumerate(ds) if m==-1 or m&t],d) for t,d in zip(N,domains)):
    out.append((i,tuple(ims),ds));act[ds]+=1
 return out
if __name__=='__main__':
 for src,lib in [((129,513),tuple(extra)),((129,513),(129,513)),((129,4160),tuple(extra)),((129,523),tuple(extra)),((4160,354),tuple(extra))]:
  rows=run(src,lib);print(src,'positive-control' if lib==(129,513)else 'native',len(rows),sorted(set(ds for i,s,ds in rows)),flush=True)
