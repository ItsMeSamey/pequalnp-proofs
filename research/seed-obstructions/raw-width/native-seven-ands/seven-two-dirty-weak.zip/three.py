from itertools import combinations
from pysat.formula import IDPool
from pysat.solvers import Solver
from cuts import load,DEGREE_ONE
import sys,time
P,N=load(());P=[r&1048575 for r in P];N=[r&1048575 for r in N]
def trial(tags,mode,secs):
 start=time.monotonic();active=sum(1<<(13+t)for t in tags)
 pos=[p for p in P if p&active]
 v=IDPool().id;s=Solver(name='g4');add=s.add_clause
 memo={}
 def OR(xs):
  key=tuple(xs)
  if key in memo:return memo[key]
  a=v(('or',key));memo[key]=a
  for x in xs:add([-x,a])
  add([-a]+xs);return a
 def AND(xs):return -OR([-x for x in xs])
 edges={1:((0,0),(1,0),(1,0)),3:((0,0),(0,0),(1,0))}.get(mode)
 def sel(g,h):
  z=[v(('s',g,h,i))for i in range(20+g)]
  for i in range(g):
   if edges:add([z[20+i] if edges[g][h]>>i&1 else -z[20+i]])
  add(z);return z
 ss=[[sel(g,h)for h in range(2)]for g in range(3)]
 if mode==2:add([ss[2][0][21]]);add([-ss[2][1][21]])
 def evaluate(r,drop=-1):
  out=[]
  for g in range(3):
   if g==drop:out.append(None);continue
   arms=[]
   for z in ss[g]:
    cols=[z[i]for i in range(20)if r>>i&1]
    cols.extend(AND([z[20+i],a])for i,a in enumerate(out)if a is not None)
    arms.append(OR(cols))
   out.append(AND(arms))
  return out
 roots=[2]if mode==2 else [1,2]
 def final(o):return OR([o[i]for i in roots if o[i] is not None])
 for p in pos:add([final(evaluate(p))])
 for g in ([] if 'weak' in sys.argv else range(3)):
  dropped=[final(evaluate(p,g))for p in pos]
  for q,u in DEGREE_ONE.items():
   add([-o for o,p in zip(dropped,pos)if not p&(1<<(13+u))or p&q])
 dirty=[[]for _ in range(2 if mode==2 else 1)]
 for n in N:
  o=evaluate(n)
  for i in roots:add([-o[i]])
  for j,l in enumerate(dirty):l.append(o[j])
 for ls in dirty:add(ls)
 for p,q in (() if 'weak' in sys.argv else ((0,7),(6,12),(1,3),(4,5),(8,9),(10,11))):
  for o in evaluate(active|(8191^(1<<p)^(1<<q))):add([o])
 while time.monotonic()-start<secs:
  s.conf_budget(500);ans=s.solve_limited()
  if ans is None:continue
  if not ans:return 'UNSAT'
  m=set(s.get_model());gates=[[[i for i,l in enumerate(z)if l in m]for z in gate]for gate in ss]
  full=[[[13+t],[i for i in range(13)if any(p&(1<<i) and p&(1<<(13+t))for p in P)]]for t in range(7)if t not in tags]
  full.extend([[[i if i<20 else i+4 for i in z]for z in gate]for gate in gates])
  root=[20,21,22,23]+[24+i for i in roots]
  for j,r in enumerate(P+N):
   for g,(a,b) in enumerate(full):
    if all(any(r>>i&1 for i in z)for z in(a,b)):r|=1<<(20+g)
   assert any(r>>i&1 for i in root)==(j<len(P))
  return {'gates':full,'root':root}
 return 'UNKNOWN'
if __name__=='__main__':
 print(sys.argv[1:3],trial(tuple(map(int,sys.argv[1])),int(sys.argv[2]),float(sys.argv[3])),flush=True)
