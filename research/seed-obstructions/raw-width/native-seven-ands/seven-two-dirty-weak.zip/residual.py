from itertools import combinations
from cuts import load,bm
P,N=load(());P=[r&1048575 for r in P];N=[r&1048575 for r in N]
U=(1<<20)-1
def covers(rows):
 masks={0}
 for row in rows:
  masks={x|y for x in masks for y in ([0]if x&row else bm(row))}
 return [x for x in masks if not any(y!=x and not y&~x for y in masks)]
def rows_test(pos):
 for b in covers(pos):
  ng=[n for n in N if n&b];a=U
  for n in ng:a &=~n
  req=[p for p in pos if not p&a]
  arms=covers(req)
  for c,d in ((c,d)for c in arms for d in arms if c<=d):
   if any(n&c and n&d for n in ng):continue
   for t in N:
    if t&b:continue
    for x in ([0]if t&c else bm(t)):
     for y in ([0]if t&d else bm(t)):
      if not any(n&(c|x) and n&(d|y)for n in ng):
       return b,a,c|x,d|y,t
if __name__=='__main__':
 pairs=[]
 for js in combinations(range(7),3):
  group=sum(1<<(13+t)for t in js)
  for atom in [1<<i for i in range(20)]:
   pos=[p for p in P if p&group and not p&atom]
   w=rows_test(pos)
   if w:pairs.append((js,atom,w))
 print('700 residual tests; surviving:',len(pairs));print(pairs[:4])
