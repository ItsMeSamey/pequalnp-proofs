from ports1 import *
from functools import reduce
from operator import or_
from pathlib import Path
FULL=(1<<20)-1
pairneg={(x,y):sum(1<<i for i,n in enumerate(N)if n&x and n&y)for x,y in combinations_with_replacement(raw,2)}
rneg={x:pairneg[x,x]for x in raw}
def rectangle(S):
 neg=reduce(or_,(rneg[x] for x in bm(S)),0)
 neigh={x:sum(y for y in raw if not pairneg[min(x,y),max(x,y)]&neg)for x in raw}
 sides={FULL}
 for n in set(neigh.values()):sides.update({s&n for s in sides})
 for a in sides:
  if not a:continue
  b=reduce(int.__and__,(neigh[x] for x in bm(a)),FULL)
  if a>b or not b:continue
  if len({r&8191 for r in P if r&a and r&b})<4:continue
  if any(n&a and n&b for n in N):return True
 return False
def masks():
 sets={0}
 for (x,y),d in pairneg.items():
  if not d:continue
  m=touch(x,y);s=m
  while s:sets.add(s);s=(s-1)&m
 return sorted(sets,key=lambda v:(-v.bit_count(),v))
if __name__=='__main__':
 ss=masks();print('inputs',len(ss),flush=True)
 out=[]
 for s in ss:
  if all(s&~b for b in out)and rectangle(s):out.append(s)
 print('max guards',len(out),Counter(v.bit_count()for v in out),flush=True)
 Path('guard-max.txt').write_text(repr(out))
