from pathlib import Path
from min_orbit import homes
from ast import literal_eval
from three import N as sat
from actions import N as geom
from minneg import N as sig
assert sat==geom==sig
assert homes()==literal_eval(Path('minneg-orbits.txt').read_text())
for i in range(15):
 for edge in ('parallel','serial'):
  assert Path(f'weakpair-{i}-{edge}.log').read_text().strip()=='0123456 2 UNSAT'
print('30 weak orbit replays returned UNSAT; all dirty-first negative row indices are identical')
