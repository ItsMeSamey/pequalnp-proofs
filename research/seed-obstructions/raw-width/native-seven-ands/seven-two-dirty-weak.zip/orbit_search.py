from three import P,N,DEGREE_ONE
from pysat.formula import IDPool
from pysat.solvers import Solver
import sys,time
def run(tags,d,seconds,shape='',strong=True):
 k=len(tags)+int(__import__('os').environ.get('EXTRA_AND','0'));start=time.monotonic();U=sum(1<<(13+j) for j in tags)
 pos=[p for p in P if p&U];v=IDPool().id;s=Solver(name=__import__('os').environ.get('S33_SOLVER','g4'));add=s.add_clause
 memo={}
 def OR(xs):
  key=tuple(xs)
  if key not in memo:
   a=v(('or',key));memo[key]=a
   for x in xs:add([-x,a])
   add([-a]+xs)
  return memo[key]
 def AND(xs):return -OR([-x for x in xs])
 def sel(g,h):
  z=[v(('s',g,h,i))for i in range(20+min(g,d))];add(z);return z
 ss=[[sel(g,h)for h in range(2)]for g in range(k)]
 if shape:
  masks=list(map(int,shape.split(',')))
  for g in range(k):
   for h in range(2):
    for i,x in enumerate(ss[g][h][20:]):add([x if masks[2*g+h]>>i&1 else -x])
 for i in range(d):
  add([ss[j][h][20+i]for j in range(i+1,k)for h in range(2)])
  for j in range(d,k):add([-ss[j][0][20+i],-ss[j][1][20+i]])
 def evaluate(row,drop=-1):
  o=[]
  for g in range(k):
   if g==drop:o.append(None);continue
   arms=[]
   for z in ss[g]:
    xs=[x for i,x in enumerate(z[:20])if row>>i&1]
    xs.extend(AND([a,x])for a,x in zip(o,z[20:])if a is not None)
    arms.append(OR(xs))
   o.append(AND(arms))
  return o
 def final(o):return OR([x for x in o[d:]if x is not None])
 def lex(a,b):
  tie=None
  for i,(x,y) in enumerate(zip(a,b)):
   add(([-tie]if tie else [])+[-x,y])
   same=AND([OR([-x,y]),OR([x,-y])])
   tie=AND([tie,same])if tie else same
 controls=__import__('os').environ
 if d==2:
  order=controls.get('DIRTY_EDGE','any')
  if order=='parallel':
   for z in ss[1]:add([-z[20]])
  if order=='serial':add([ss[1][0][20],ss[1][1][20]])
  if len(tags)>=6 and controls.get('STAR_CAP') in ('1','0'):
   # A raw-only clean product must be an entire canonical tag star.
   # At most one in the reconstructed circuit, including already supplied stars.
   rawonly=[AND([-x for z in ss[g]for x in z[20:]])for g in range(2,k)]
   if len(tags)==6 or controls.get('STAR_CAP')=='0':
    for x in rawonly:add([-x])
   if len(tags)==7:
    for i,x in enumerate(rawonly):
     for y in rawonly[:i]:add([-x,-y])
  for g in range(2,k):
   # A higher numeric dirty source, if selected, occurs in first arm.
   add([-ss[g][1][21]]);add([-ss[g][1][20],ss[g][0][21]])
 pe=[evaluate(p)for p in pos]
 for i in range(d,k-1):lex([o[i] for o in pe],[o[i+1]for o in pe])
 for o in pe:add([final(o)])
 def atleast4(bits):
  from itertools import combinations
  # Fewer than four positive point classes may not carry every loss.
  for tr in combinations(range(len(bits)),3):
   add([x for i,x in enumerate(bits) if i not in tr])
 if controls.get('POINT_BILLS'):
  for g in range(k):
   if g<d:loss=[-final(evaluate(p,g))for p in pos]
   else:loss=[AND([o[g]]+[-o[i]for i in range(d,k)if i!=g])for o in pe]
   by=[OR([x for x,p in zip(loss,pos)if p&(1<<j)])for j in range(13)]
   atleast4(by)
 if controls.get('ARM_ORDER'):
  lex(ss[0][0],ss[0][1])
 if strong:
  for g in range(k):
   dropped=[final(evaluate(p,g))for p in pos]
   for q,u in DEGREE_ONE.items():add([-x for x,p in zip(dropped,pos)if p&q or not p&(1<<(13+u))])
  for a,b,c in ((0,6,12),(1,3,5),(7,8,9),(2,4,10)):
   for o in evaluate(U|(8191^(1<<a)^(1<<b)^(1<<c))):add([o])
 dirty=[[]for _ in range(d)]
 minimal=int(controls.get('MIN_ORBIT','-1'))
 mask=0
 if minimal>=0:
  from ast import literal_eval
  from pathlib import Path
  mask=literal_eval(Path('minneg-orbits.txt').read_text())[minimal]
 for j,n in enumerate(N):
  o=evaluate(n)
  if mask>>j&1:add([o[0]])
  for x in o[d:]:add([-x])
  for i in range(d):dirty[i].append(o[i])
 for xs in dirty:add(xs)
 while time.monotonic()-start<seconds:
  s.conf_budget(600);r=s.solve_limited()
  if r is None:continue
  if not r:return 'UNSAT'
  m=set(s.get_model());gates=[[[i for i,x in enumerate(z)if x in m]for z in gate]for gate in ss]
  base=[[[13+t],[i for i in range(13) if any(p&(1<<i) and p&(1<<(13+t))for p in P)]]for t in range(7)if t not in tags]
  full=base+[[[i if i<20 else i+len(base)for i in z]for z in gate]for gate in gates]
  root=list(range(20,20+len(base)))+list(range(20+len(base)+d,20+len(base)+k))
  for j,r in enumerate(P+N):
   for g,(a,b)in enumerate(full):
    if all(any(r&(1<<i)for i in z)for z in (a,b)):r|=1<<(20+g)
   assert any(r&(1<<i)for i in root)==(j<len(P))
  return {'gates':full,'root':root}
 return 'UNKNOWN'
if __name__=='__main__':
 tags,d,secs=sys.argv[1:4];print(tags,d,run(tuple(map(int,tags)),int(d),float(secs),sys.argv[4] if len(sys.argv)>4 else '',len(sys.argv)<=5),flush=True)
