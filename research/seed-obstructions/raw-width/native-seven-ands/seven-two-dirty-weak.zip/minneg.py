from guard2 import *
from itertools import combinations
from functools import cache
from residual import covers
from ast import literal_eval
import sys
@cache
def nb(m):return reduce(or_,(rneg[x]for x in bm(m)),0)
def build(chunk):
 seen=set()
 for j,poss in enumerate(combinations(P,4)):
  if j%8!=chunk or len({p&8191 for p in poss})!=4:continue
  arms=covers(poss)
  ns=[nb(a)for a in arms]
  for i,a in enumerate(ns):
   for j in range(i+1):
    b=ns[j];d=a&b
    if d:seen.add(d);continue
    # The chosen raw arms cover four distinct points but are jointly safe.
    # Add the actual unsafe pair, one raw atom per arm.
    for x in raw:
     for y in raw:
      d=(a|rneg[x])&(b|rneg[y])
      if d:seen.add(d)
 mins=[]
 for s in sorted(seen,key=int.bit_count):
  if all(m&~s for m in mins):mins.append(s)
 return mins
if __name__=='__main__':
 if len(sys.argv)>1:
  c=int(sys.argv[1]);out=build(c);Path(f'minneg-{c}.txt').write_text(repr(out));print(c,len(out))
 else:
  ss=set().union(*(literal_eval(Path(f'minneg-{c}.txt').read_text())for c in range(8)))
  out=[]
  for s in sorted(ss,key=int.bit_count):
   if all(m&~s for m in out):out.append(s)
  print('minimal',len(out),Counter(s.bit_count()for s in out))
  pairs=[(i,j)for i,s in enumerate(out)for j,t in enumerate(out[:i])if not s&t]
  print('opposite pairs',len(pairs),'of',len(out)*(len(out)-1)//2)
  Path('minneg-final.txt').write_text(repr(out))
