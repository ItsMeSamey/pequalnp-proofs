from minneg import *
from actions import actions
def homes():
 data=literal_eval(Path('minneg-final.txt').read_text());indices={n:i for i,n in enumerate(N)}
 result=set();action=[]
 for pm,ns in actions():
  if set(ns)==set(N):action.append([indices[n] for n in ns])
 def tr(mask,order):return sum(1<<order[i.bit_length()-1]for i in bm(mask))
 for m in data:result.add(min(tr(m,pi)for pi in action))
 assert len(action)==24
 return sorted(result)
if __name__=='__main__':
 out=homes();print(len(out),[m.bit_count()for m in out]);Path('minneg-orbits.txt').write_text(repr(out))
