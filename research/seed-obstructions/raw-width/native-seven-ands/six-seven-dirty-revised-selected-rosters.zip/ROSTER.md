# Six- and seven-dirty selected role counts

These are covering counts for the selected protected native area-33 eight-AND separator. The earlier rosters of 98 and 52 remain sufficient. At four backed labels, e51d7492 proves that whenever at least two private matches are dirty each minimal dirty private match has at least two exterior dirty ancestors. Thus in any topological order the first dirty matched private index is at least 2. The proof allows clean backed private recipients and the single allowed opposite backed tag. It uses signed safety on all four labels and at least two actual co-armed foreign labels.

| Dirty | Dirty private | Backed | Earlier | Revised | Chronological restriction |
|---|---:|---|---:|---:|---|
| 6 | 2 | 2,3,4 | 12+12+12 | 12+12+6 | B=5. Choose two private indices from 1..4 when b≤3, or 2..4 when b=4; two centers. |
| 6 | 3 | 3,4 | 30+30 | 30+10 | Pick three private indices from 1..5, or 2..5 at b=4. B can be a later dirty exterior or the clean exterior; two centers. |
| 6 | 4 | 4 | 2 | 2 | The two exterior dirty sites precede every private match. The exterior backup is clean. |
| 7 | 3 | 3,4 | 20+20 | 20+8 | B=6. Choose three private indices from 1..5 when b=3, or 2..5 when b=4; two centers. |
| 7 | 4 | 4 | 12 | 12 | Two roles with a dirty exterior backup, ten with a clean exterior backup; first two sites exterior. |

Thus **72 selected six-dirty roles and 40 selected seven-dirty roles** suffice. These totals precede prospective case exclusions. The original frozen generators and their broader direct schedules are unchanged. At six dirty the budget permits 24 precollector ORs; at seven dirty the allowance is 25. The four raw banks and signed symmetry for feasibility retain their separate physical price requirements.
