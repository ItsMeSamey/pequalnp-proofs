from footprints import *
def main(key,mask,goal):
    m=keymodel(key);ws=words(m);m.sat.delete();z=fp(m)
    path=Path(f'family-{key}-{mask}.json');boxes=load(path)
    with Glucose4(bootstrap_with=m.C)as s:
      for b in boxes:s.add_clause(clause(ws,b))
      for it in range(7):
        base=pin(z,mask)
        s.conf_budget(30000);flag=s.solve_limited(assumptions=base)
        if flag is not True:
            print(key,mask,'remaining',flag,'boxes',len(boxes),flush=True);return
        a=set(s.get_model());exact=[sum(x for x,v in row if v in a)for row in ws]
        if not Path('sample-'+key+'.json').exists():
            Path('sample-'+key+'.json').write_text(json.dumps(exact))
        fixed={v if v in a else -v for row in ws for x,v in row}
        for lit in sorted(fixed,key=abs):
            if lit not in fixed:continue
            s.conf_budget(60);y=s.solve_limited(assumptions=base+[-lit])
            if y:fixed.intersection_update(s.get_model())
            elif y is None:fixed.remove(lit)
        box=[(sum(x for x,v in row if v in fixed),sum(x for x,v in row if -v not in fixed))for row in ws]
        print(key,mask,'common',score(m,box),'exact',score(m,[(a,a)for a in exact]),flush=True)
        while score(m,box)<goal:
            opt=[]
            for i in range(16):
                if box[i]!=(exact[i],exact[i]):
                    extend=list(box);extend[i]=(exact[i],exact[i]);opt.append((score(m,extend),(box[i][1]^box[i][0]).bit_count(),i,extend))
            if not opt:print(key,mask,'low score',score(m,box));return
            box=max(opt)[-1]
        boxes.append(box);path.write_text(json.dumps(boxes,separators=(',',':')))
        s.add_clause(clause(ws,box))
        print(key,mask,'certifiable',len(boxes),score(m,box),flush=True)
if __name__=='__main__':main(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]))
