"""The fourth dirty donor is the only point-side input of F."""
from pathlib import Path
from model import Model, edges, rows, points, private, ordt, stars, sx
from pysat.solvers import Cadical195

chart = (3, 2, "cross", 4)
def diagram():
    petals = {t: {p for p, tag in edges if tag == t} for t in private}
    net = [None] * 8
    net[3] = ({sx(2), sx(4)}, petals[2])
    net[4] = ({sx(2)}, {-4})
    for i, (v, ordinary) in enumerate(zip(private[1:], ordt)):
        p = min(p for p in points if p & stars[v] and not p & stars[ordinary])
        net[i] = ({sx(ordinary)}, {p})
        net[i+5] = ({sx(v)}, petals[v] | {-1-i})
    return net

def accepts(net, p, t, omit):
    row = p | sx(t)
    outputs = []
    for arms in net:
        def present(x):
            if x > 0:
                return bool(x & row)
            return (x != -4 or not omit) and outputs[-1-x]
        outputs.append(all(any(present(x) for x in arm) for arm in arms))
    return any(outputs[4:])

def native(net):
    changed = set()
    for p,t,y in rows:
        correct, omitted = (accepts(net,p,t,z) for z in (False, True))
        if y > 0:
            assert correct == (t in private)
            assert omitted == (t in private[1:])
            if correct != omitted:
                changed.add((p,t))
        if y < 0:
            assert not correct and not omitted
    assert changed == {(p,t) for p,t in edges if t==2} and len(changed)==4
    return sorted(changed)

def signed_check(cls, net, partial_expected):
    model = cls(*chart)
    pins = []
    for g, arms in enumerate(net):
        if g in model.ex:
            arms = sorted(arms, key=lambda a: tuple(x in a for x in model.keys[g,0]))
        for s, arm in enumerate(arms):
            keys = model.keys[g,s] if g < model.n else [-1-i for i in range(4)]
            pins.extend((1 if x in arm else -1)*model.term(g,s,x) for x in keys)
    ordinary_demands = {tuple(model.G(g, p|sx(t)) for g in range(4,8))
                        for p,t in edges if t in ordt}
    assert len(ordinary_demands) == 12
    with Cadical195(bootstrap_with=[c for c in model.C if tuple(c) not in ordinary_demands]) as partial:
        assert partial.solve(assumptions=pins) is partial_expected
    assert model.sat.solve(assumptions=pins) is False
    model.sat.delete()

def main():
    net = diagram()
    changed = native(net)
    text = Path(__file__).with_name("model.py").read_text()
    correct = "for i in range(min(g,4)))"
    legacy = "for i in range(min(g,3)))"
    assert text.count(correct) == 1 and legacy not in text
    namespace = {"__name__": "donor_regression_mutation"}
    exec(compile(text.replace(correct,legacy),"omitted_donor_model.py","exec"),namespace)
    signed_check(Model, net, True)
    signed_check(namespace["Model"], net, False)
    print("chart",chart,"native signed positive pairs lost with omitted D3:",changed)
    print("pinned signed private demands: corrected SAT; omitted D3 UNSAT")
    print("pinned full native demands: corrected UNSAT; omitted D3 UNSAT")
if __name__ == "__main__":
    main()
