from model import *
from pysat.solvers import Cadical195

def fixture(m, native_only=False):
    ordinary=ordt
    H,B,k,mode=m.h,m.B,m.k,m.mode
    F=4;u=2;T=private[:k]
    # The early raw contaminant can be one common neighbor of the other backed tags.
    if mode=='shared' and k==4:return None
    Pset=lambda t:{p for p,j in edges if j==t}
    if mode=='cross':tagarm={sx(t)for t in T}
    else:
        x=next(p for p in points if all(p&stars[t]for t in T[1:]) and not p&stars[u])
        tagarm={sx(u),x}
    net={H:(tagarm,Pset(u))}
    for i,t in enumerate(private[1:],5):net[i]=({sx(t)},Pset(t))
    back_tags={sx(t)for t in ((u,) if mode=='cross' else T)}
    if B==F:net[F]=(back_tags,{-1-H});first=0
    else:
        net[B]=(back_tags,{-1-H,sx(ordt[0])})
        net[F]=({-1-H},{-1-B});first=1
    ds=[g for g in range(4)if g not in (H,B)]
    for j,g in enumerate(ds):
        v=private[1+j];t=ordt[first+j]
        p=next(p for p in points if p&stars[v] and not p&stars[t])
        net[g]=({sx(t)},{p});net[5+j][1].add(-1-g)
    def evaluate(row):
        out=[];hot=set();sockets=[]
        for g in range(8):
            a,b=[any((bool(row&x) if x>0 else out[-1-x])for x in terms)for terms in net[g]]
            if a or b:hot.add(g)
            out.append(a and b);sockets.append((a,b))
        return out,hot,sockets
    dirt=set()
    for p,t,s in rows:
        out,hot,_=evaluate(p|sx(t))
        if s<0:
            assert not any(out[4:]);dirt.update(i for i,x in enumerate(out)if x)
        if s>0:assert any(out[4:])==(t in private)
    assert dirt==set(range(4))
    for i,t in enumerate(private):
        g=H if i==0 else 4+i
        assert evaluate(q[t])[1]=={g}
        assert evaluate(sx(t))[1]==({H,B}if t==u else {g,H if mode=='cross' else B} if t in T else {g})
    for t in ordinary+private:
        out,hot,socks=evaluate(sx(t));assert not any(out)and len(hot)<=2
        assert any(socks[g][s] and all(not evaluate(sx(v))[2][g][s]for v in ordinary+private if v!=t)for g in range(8)for s in (0,1))
    assert all(len(evaluate(sx(t|v))[1])<=3 for t,v in combinations(ordinary+private,2))
    assert any(all(g in evaluate(sx(t))[1]for g,t in zip(G,ordinary))for G in permutations(m.ex,3))
    if native_only:return True
    pins=[]
    for g in range(8):
        arms=net[g]
        if g in m.ex:arms=sorted(arms,key=lambda S:tuple(x in S for x in m.keys[g,0]))
        for s,S in enumerate(arms):
            xs=m.keys[g,s]if g<m.n else [-1-h for h in range(4)]
            pins.extend((1 if x in S else -1)*m.term(g,s,x)for x in xs)
    relax={tuple(m.G(g,p|sx(t))for g in range(4,8))for p,t in edges if t in ordt}
    assert len(relax)==12
    with Cadical195(bootstrap_with=[c for c in m.C if tuple(c)not in relax])as sat:assert sat.solve(assumptions=pins),(H,k,mode,B)
    assert m.sat.solve(assumptions=pins) is False
    return True

if __name__=='__main__':
    import argparse
    from types import SimpleNamespace
    ap=argparse.ArgumentParser()
    ap.add_argument('--native-only',action='store_true')
    ap.add_argument('--case')
    args=ap.parse_args()
    tally=Counter()
    for h,k,mode,B in charts():
        if k==4 and mode=='shared':continue
        if args.case and args.case!=f"{h}-{k}-{mode}-{B}":continue
        if args.native_only:
            M=SimpleNamespace(h=h,k=k,mode=mode,B=B,ex=tuple(g for g in range(5) if g!=h))
        else:
            M=Model(h,k,mode,B)
        assert fixture(M,args.native_only)
        tally[k,mode]+=1
    print("physical diagrams per class",dict(tally))
    print(sum(tally.values()),"pass all native negatives, sixteen private positives, and actual marks")
    if not args.native_only:
        print("each pinned corrected CNF SAT with private demands and UNSAT with all original demands")
