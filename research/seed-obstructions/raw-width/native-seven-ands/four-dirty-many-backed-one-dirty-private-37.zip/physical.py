from collections import Counter
from itertools import combinations,permutations
import json
from pathlib import Path
from model import edges,rows,private,ordt,stars,q,sx

def build(words):
    sets=[{j for j in range(24) if m & (1<<j)} for m in words]
    predecessors={};index=28
    while any(len(s)>1 for s in sets):
        freq=Counter(pair for s in sets for pair in combinations(sorted(s),2))
        a,b=min(freq,key=lambda pair:(-freq[pair],pair))
        for s in sets:
            if {a,b}<=s:s.difference_update((a,b));s.add(index)
        predecessors[index]=('or',a,b);index+=1
    for g in range(8):predecessors[20+g]=('and',*[next(iter(s)) for s in sets[2*g:2*g+2]])
    out=24
    for g in range(25,28):predecessors[index]=('or',out,g);out=index;index+=1
    gates=[];wire={i:i for i in range(20)}
    def visit(i):
        if i not in wire:
            op,a,b=predecessors[i];a=visit(a);b=visit(b)
            wire[i]=20+len(gates);gates.append((op,a,b))
        return wire[i]
    output=visit(out)
    assert all(20+i in wire for i in range(8))
    return {'gates':gates,'output':output,'and_wires':[wire[20+i] for i in range(8)]}

def audit(key,net):
    h=int(key[0]);ands=net['and_wires'];gates=net['gates'];out=net['output']
    assert sum(op=='and' for op,a,b in gates)==len(ands)==8
    def eval(m):
        vals=[bool((1<<j)&m) for j in range(20)];states=[]
        for j,(op,a,b) in enumerate(gates,20):
            assert op in ('and','or') and max(a,b)<j and min(a,b)>=0
            vals.append(vals[a] and vals[b] if op=='and' else vals[a] or vals[b])
        socks=[(vals[gates[j-20][1]],vals[gates[j-20][2]])for j in ands]
        return vals[out],{i for i,z in enumerate(socks) if all(z)},{i for i,z in enumerate(socks) if any(z)},socks
    dirty=set()
    for p,t,s in rows:
        val,on,hot,arms=eval(p|sx(t));assert s==0 or val==(s>0)
        if s<0:dirty.update(on)
    assert dirty==set(range(4))
    for i,t in enumerate(private):
        owner=h if i==0 else i+4
        assert eval(q[t])[2]=={owner}
        assert eval(sx(t))[2]==({owner,3} if i<2 else {owner})
    labels=private+ordt
    for t in labels:
        _,on,hot,socks=eval(sx(t))
        assert not on and len(hot)<=2 and any(socks[g][side] and all(not eval(sx(v))[3][g][side]for v in labels if v!=t)for g in range(8)for side in (0,1))
    assert all(len(eval(sx(a|b))[2])<=3 for a,b in combinations(labels,2))
    assert any(all(g in eval(sx(t))[2]for g,t in zip(gs,ordt))for gs in permutations([g for g in range(5) if g!=h],3))
    mins=[{1<<j}for j in range(20)]
    for op,a,b in gates:
        z=mins[a]|mins[b] if op=='or' else {l|r for l in mins[a]for r in mins[b]}
        mins.append({m for m in z if not any(x!=m and x&~m==0 for x in z)})
    full=mins[out]=={p|sx(t)for p,t in edges}
    return len(gates),full
if __name__=='__main__':
    controls={}
    for h in (1,2):
        key=f'{h}-2-shared-3';w=json.loads(Path('sample-'+key+'.json').read_text())
        for g,t in enumerate(private[2:],6):
            w[2*g]|=sx(t);w[2*g+1]|=stars[t]
        control=build(w);print(key,audit(key,control));controls[key]=control
    Path('physical.json').write_text(json.dumps(controls,separators=(',',':')))
