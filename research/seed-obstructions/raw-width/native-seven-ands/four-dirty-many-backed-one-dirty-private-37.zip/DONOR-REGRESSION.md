# Fourth donor differential control

Run donor_regression.py from this directory. The fixed chart has H=D3, B=F=4, two backed private tags and cross addressing. F receives raw tag 2 on one socket and only D3 on its other socket. D3 computes the point star of tag 2 AND the union of tags 2 and 4. Three clean private gates cover the other private tags. Each of D0,D1,D2 is made dirty on a nonincident ordinary edge and feeds one of these clean private gates redundantly on its point socket.

The independent signed evaluator checks all 676 native indices. With D3 included, the physical circuit accepts the 16 private positive pairs and rejects all signed negatives. Removing D3 from the core socket evaluator loses exactly the four positive pairs with tag 2. Both circuits miss the twelve ordinary positive pairs.

The differential then pins every source-selection bit of this same circuit. Deleting only the twelve ordinary-positive demand clauses must give SAT with the corrected socket encoder, UNSAT with the one-token legacy mutation. Both must give UNSAT under the full original demand list. The mutation leaves all available keys and source pins intact and changes only evaluation of D3 as a donor to a core site. This single chart is a regression and conveys no UNSAT result for unrestricted diagrams.
