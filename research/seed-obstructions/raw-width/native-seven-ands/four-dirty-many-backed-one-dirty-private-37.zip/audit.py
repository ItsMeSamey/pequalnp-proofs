"""Check chart coverage, certificate digests, native rows and signed permutations."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip
from model import N,N0,P,charts,exceptional,private,rows
from sym import group,banks
base=Path(__file__).resolve().parent
if __name__=='__main__':
    assert len(group)==24 and len(P)==28 and len(N)==245 and len(N0)==468
    assert Counter(s for p,t,s in rows)=={1:28,-1:624,0:24}
    keys={'-'.join(map(str,c)) for c in charts()}
    assert len(keys)==60
    got=set()
    for line in (base/'certificates.log').read_text().splitlines():
        key,count,size,cnfsha,proofsha,flag=line.split()
        assert key in keys and key not in got and flag=='VERIFIED'
        got.add(key)
        proof=gzip.decompress((base/'proofs'/f'{key}.drat.gz').read_bytes())
        assert len(proof)==int(size) and sha256(proof).hexdigest()==proofsha
        assert len(cnfsha)==64 and int(count)>50000
    assert got==keys
    counts={k:[dict(Counter(m.bit_count()for m in exceptional(k,v))) for v in private[k:]] for k in (2,3)}
    print('signed rows',len(rows),'distinct negative rows',len(N0),'maximal',len(N),'symmetries',len(group))
    print('exceptional witnesses per remaining unbacked tag by atom count',counts)
    print('certificate keys',len(got),'per backed count',dict(Counter(int(k.split('-')[1])for k in got)))
