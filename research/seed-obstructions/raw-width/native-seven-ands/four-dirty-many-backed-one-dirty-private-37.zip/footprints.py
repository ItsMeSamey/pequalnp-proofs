from price import *
from pysat.solvers import Glucose4
from model import ordt,sx
def fp(m):
    return [m.hot(g,sx(t)) for t in ordt for g in range(8)]
def bitset(z,a):
    return sum(1<<i for i,x in enumerate(z) if x in a)
def pin(z,mask):
    return [v if mask&(1<<i)else -v for i,v in enumerate(z)]
def main(key):
    m=keymodel(key);m.sat.delete()
    with Glucose4(bootstrap_with=m.C)as s:
        z=fp(m);found=[]
        for i in range(40):
            s.conf_budget(50000);a=s.solve_limited()
            if a is not True:break
            mask=bitset(z,set(s.get_model()));found.append(mask)
            s.add_clause([-x for x in pin(z,mask)])
            print(key,mask,flush=True)
        print('done',a,found,flush=True)
        Path('marks-'+key+'.json').write_text(json.dumps(found))
if __name__=='__main__':main(sys.argv[1])
