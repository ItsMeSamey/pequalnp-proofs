from price import words,score,clause,load
from pathlib import Path
def constraints(m,key):
    result=[];ws=words(m);domain=[sum(x for x,v in row)for row in ws]
    for f in sorted(Path(__file__).resolve().parent.glob(f'family-{key}-*.json')):
        for box in load(f):
            assert len(box)==16
            assert all(lo>=0 and hi>=0 and not(lo &~hi) and not(hi &~mask)for (lo,hi),mask in zip(box,domain))
            cost=score(m,box);assert cost>=26,(f,cost)
            result.append(clause(ws,box))
    assert len(result)==4
    return result
