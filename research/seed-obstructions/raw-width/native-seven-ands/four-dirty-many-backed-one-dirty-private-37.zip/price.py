from pysat.solvers import Glucose4
from model import Model,private,stars,sx
from unionprice import lower
from pathlib import Path
import json,sys
from functools import lru_cache

def bit(x):
    return x if x>0 else 1<<(19-x)

def words(m):
    return [[(bit(x),m.term(g,s,x)) for x in
             (m.keys[g,s] if g<m.n else tuple(-1-i for i in range(4)))]
            for g in range(8) for s in range(2)]

def intervals(m, bounds):
    """Exact support bounds at core sockets. Infer mandatory petals at filled unbacked sockets."""
    targets=list(bounds[:2*m.n]);upper_singletons=[]
    for i in range(4):
        arm=[]
        for s in (0,1):
            hi=bounds[2*i+s][1]
            points=hi&8191
            for j,prev in enumerate(upper_singletons):
                if hi&(1<<(20+j)):points|=prev
            arm.append(points)
        upper_singletons.append(arm[0]&arm[1])
    for g,v in enumerate(private[m.k:],m.n):
        lo,hi=bounds[2*g]
        targets.append((lo|sx(v),hi|sx(v)))
        lo,hi=bounds[2*g+1];maybe=0
        for j,U in enumerate(upper_singletons):
            if hi&(1<<(20+j)):maybe|=U
        targets.append((lo|(stars[v]&~maybe),hi|stars[v]))
    return tuple(sorted(set(map(tuple,targets))))

def score(m,bounds):
    return lower(intervals(m,bounds))

def clause(ws,bounds):
    return [-v if a&x else v for row,(a,b) in zip(ws,bounds)
            for x,v in row if a&x or not b&x]

def load(path):
    return json.loads(path.read_text()) if path.exists() else []

def keymodel(key):
    h,k,variant,b=key.split('-')
    return Model(int(h),int(k),variant,int(b))

def explore(key,cap,goal):
    m=keymodel(key);ws=words(m);m.sat.delete();s=Glucose4(bootstrap_with=m.C)
    path=Path('boxes-'+key+'.json')
    boxes=load(path)
    for bounds in boxes:s.add_clause(clause(ws,bounds))
    root_units={c[0] for c in m.C if len(c)==1}
    lo0=[sum(x for x,v in row if v in root_units) for row in ws]
    hi0=[sum(x for x,v in row if -v not in root_units)for row in ws]
    for it in range(cap):
        s.conf_budget(40000);flag=s.solve_limited()
        if flag is not True:
            print(key,'remaining',flag,'boxes',len(boxes),flush=True);return
        assignment=set(s.get_model())
        exact=[sum(x for x,v in row if v in assignment)for row in ws]
        bounds=[(a,a) for a in exact]
        val=score(m,bounds)
        if val<goal:
            print(key,'exact weak price',val,'boxes',len(boxes),flush=True);return
        if it==0 and not boxes:
            Path('sample-'+key+'.json').write_text(json.dumps(exact))
        # First widen whole sockets; then widen individual selector bits if needed.
        def widen(j,a,b):
            alt=bounds[:];alt[j]=(a,b)
            if score(m,alt)>=goal:bounds[j]=(a,b)
        for j in sorted(range(16),key=lambda j:(exact[j].bit_count(),j)):
            widen(j,lo0[j],hi0[j])
        for j,row in enumerate(ws):
            for x,v in row:
                a,b=bounds[j]
                if a&x and not lo0[j]&x:widen(j,a^x,b)
                elif not b&x and hi0[j]&x:widen(j,a,b|x)
        assert score(m,bounds)>=goal
        boxes.append(bounds)
        path.write_text(json.dumps(boxes,separators=(',',':')))
        s.add_clause(clause(ws,bounds))
        print(key,'box',len(boxes),'bound',score(m,bounds),'pins',len(clause(ws,bounds)),flush=True)
    print(key,'checkpoint',len(boxes),flush=True)
if __name__=='__main__':
    explore(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]))
