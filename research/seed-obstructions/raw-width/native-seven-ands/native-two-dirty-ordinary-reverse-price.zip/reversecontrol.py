from soleforward import atom, positives, negatives, private, stars, rows
from itertools import chain

checked = 0
for q, u in private.items():
    U = stars[u]
    for g,T in stars.items():
        if g in private.values():
            continue
        r = U & T
        P0 = T & ~r
        for b in [x for x in atom[:13] if x & U and not x & T and x not in private]:
            circuit=[]
            def gate(op,a,c):
                circuit.append((op,a,c))
                return len(circuit)+19
            def Or(a,c):
                return gate('OR',a,c)
            def And(a,c):
                return gate('AND',a,c)
            def bits(mask):
                return [j for j in range(20) if 1<<j & mask]
            def many(seq):
                y,*tail=seq
                for x in tail:
                    y=Or(y,x)
                return y
            uin,=bits(u<<13); gin,=bits(g<<13)
            UU=many(bits(U)); PP=many(bits(P0)); rr,=bits(r); bb,=bits(b)
            TT=Or(PP,rr)
            E=And(gin,Or(PP,bb))
            H=And(Or(UU,E),Or(uin,gin))
            K=And(H,Or(uin,TT))
            terms=[K]
            for t,star in stars.items():
                if t not in (u,g):
                    tin,=bits(t<<13)
                    terms.append(And(tin,many(bits(star))))
            out=many(terms)
            assert len(circuit)==38 and sum(op=='AND' for op,a,c in circuit)==8
            dirty=set()
            for p,t,s in rows:
                val=[bool((p|(t<<13))&a) for a in atom]
                for j,(op,a,c) in enumerate(circuit,20):
                    z=val[a] and val[c] if op=='AND' else val[a] or val[c]
                    val.append(z)
                    if s<0 and z and op=='AND':
                        dirty.add(j)
                assert not s or val[out]==(s==1)
            assert dirty=={E,H}
            checked+=1
print('all native q/g/b physical 38-gate controls',checked)
