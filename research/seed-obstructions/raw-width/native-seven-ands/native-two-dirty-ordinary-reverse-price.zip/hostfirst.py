from itertools import combinations
from soleforward import atom, negatives, private, stars

charts = pairchecks = 0
for q, u in private.items():
    U = stars[u]
    for g, T in stars.items():
        if g in private.values():
            continue
        r = U & T
        others = [v for v in stars if v not in (g, u)]
        P = T & 69
        assert P.bit_count() == 2 and all(stars[v] & P == 0 for v in private.values())
        h, = [v for v in private.values() if v != u and not any(((u | g | v) << 13) & ~n == 0 for n in negatives)]
        assert r == stars[h] & T == stars[h] & U and r.bit_count() == 1
        for z in atom[:13]:
            if z not in private:
                assert any(n & q and n & z and n & P for n in negatives)
            if z & (U | T) == 0:
                assert any(not (z | ((u | g) << 13)) & ~n for n in negatives)
            for a in atom[:13]:
                assert any(not (z | a) & ~n for n in negatives)
        for v in others:
            N = stars[v]
            assert any(not (q | ((g | v) << 13)) & ~n for n in negatives)
            if v in private.values():
                p, = [x for x,y in private.items() if y == v]
                assert any(not (q | (g << 13) | p) & ~n for n in negatives)
            for z in atom:
                if z != v << 13:
                    assert any(n & z and n & N for n in negatives)
            for k in (1,2,3):
                for arr in combinations([a for a in atom if a != v << 13],k):
                    m = sum(arr)
                    if any(not m & ~n for n in negatives):
                        assert any(not m & ~n and n & N for n in negatives)
                        pairchecks += 1
        charts += 1
print('original signed host/ordinary charts', charts, 'unsafe one/two/three-atom extensions', pairchecks)
