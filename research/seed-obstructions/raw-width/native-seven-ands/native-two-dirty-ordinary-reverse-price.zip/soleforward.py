from itertools import combinations_with_replacement
from nativecontrol import rows

positives = {p | t << 13 for p, t, sign in rows if sign == 1}
negatives = {p | t << 13 for p, t, sign in rows if sign == -1}
points = 8191
stars = {1 << i: sum(x & points for x in positives if x & (1 << (i + 13))) for i in range(7)}
private = {p: t for p, t, sign in rows if sign == 1 and sum(bool(y & p) for y in positives) == 1}
assert len(private) == 4 and len(negatives) == 468
atom = [1 << i for i in range(20)]
minterms = {i | j for i, j in combinations_with_replacement(atom, 2)}
charts = extensions = 0
for q, u in sorted(private.items()):
    for g, T in stars.items():
        if g == u:
            continue
        r = T & stars[u]
        petals = T ^ r
        assert r.bit_count() == 1 and petals.bit_count() == 3 and r not in private
        adjacent = {n for n in negatives if n & petals}
        for z in atom:
            if z != g << 13:
                assert any(n & z for n in adjacent)
            if z < 1 << 13 and z not in private:
                assert any(n & q and n & z for n in adjacent)
            if z < 1 << 13 and not z & stars[u]:
                assert any(n & z and n & (u << 13) for n in negatives)
        for m in minterms:
            if not m & (g << 13) and any(m & ~n == 0 for n in negatives):
                assert any(m & ~n == 0 for n in adjacent)
            if m & (q | ((u | g) << 13)):
                continue
            if any((m | r) & ~n == 0 for n in negatives):
                assert any(m & ~n == 0 and n & (r | q) for n in adjacent)
                extensions += 1
        charts += 1
print('host/guest charts', charts, 'minterm-with-common-point extensions', extensions)
