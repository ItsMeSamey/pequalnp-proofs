from itertools import combinations,combinations_with_replacement
from ports1 import P,N,raw,bm,touch,blanks
from collections import Counter
incidences={tuple(sorted(bm(p))) for p in P};admitted={}
safe=set();unsafe=0
for x,y in combinations_with_replacement(raw,2):
 l=touch(x,y)
 if l is None:safe.add((x,y));continue
 unsafe+=1
 missed=tuple(sorted({p>>13 for p in blanks(l)}))
 if len(missed)<=2:
  assert x<y<8192 and len(missed)==2 and missed not in admitted
  admitted[missed]=(x,y)
assert safe==incidences and len(safe)==28 and unsafe==182
assert set(admitted)==set(combinations([1<<u for u in range(7)],2))
for t,(x,y)in sorted(admitted.items()):print(tuple(k.bit_length()-1 for k in t),x,y)
print('182 unsafe, exactly 21 admissible with distinct forced two-tag sets')
