from itertools import combinations_with_replacement
from collections import Counter
from cuts import bm,load
P,N=load(());P=[r&1048575 for r in P];N=[r&1048575 for r in N]
def touch(x,y):
 a=(1<<20)-1;hit=False
 for n in N:
  if n&x and n&y:a&=~n;hit=True
 return a if hit else None
def blanks(l):return [p for p in P if not p&l]
def cover(rows,k):
 if not rows:return True
 if not k:return False
 return any(cover([p for p in rows if not p&a],k-1)for a in bm(rows[0]))
raw=bm((1<<20)-1)
if __name__=='__main__':
 c=Counter();surv=[]
 for x,y in combinations_with_replacement(raw,2):
  m=touch(x,y)
  if m is None:continue
  c[m.bit_count()]+=1
  if cover(blanks(m),2):surv.append((x,y,m))
 print(c,'surviving two-star cover',len(surv),surv[:5])
