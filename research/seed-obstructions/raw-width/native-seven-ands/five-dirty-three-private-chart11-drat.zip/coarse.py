from physical import *
from proofs import verify_cnf
from pathlib import Path
import sys
if __name__=='__main__':
 gl,budget=sys.argv[1],int(sys.argv[2])
 sel=(list(map(int,sys.argv[3].split(',')))if len(sys.argv)>3 else sorted(range(60),key=lambda i:(list(charts())[i][2][0]==0,i)))
 for i in sel:
  H=list(charts())[i];M=Model(*H,solver=False);z=verify_cnf(f'{i}-zero',M.C,gl,budget=budget);print('role',i,H,z,flush=True)
