from pathlib import Path
import subprocess,tempfile,gzip,hashlib
from pysat.solvers import Glucose4
def verify_cnf(key,C,checker,verify=False,budget=12000):
 file=Path('proofs')/f'{key}.gz';file.parent.mkdir(exist_ok=True)
 if file.exists() and not verify:return 'cached'
 if verify:proof=gzip.decompress(file.read_bytes())
 else:
  with Glucose4(bootstrap_with=C,with_proof=True)as S:
   S.conf_budget(budget);z=S.solve_limited()
   if z is not False:return z
   proof=('\n'.join(S.get_proof())+'\n').encode()
 cnf=('p cnf %d %d\n'%(max(abs(v)for clause in C for v in clause),len(C))+''.join(' '.join(map(str,r))+' 0\n' for r in C)).encode()
 with tempfile.TemporaryDirectory(dir='/dev/shm')as td:
  p=Path(td);f=p/'c';d=p/'d';f.write_bytes(cnf);d.write_bytes(proof)
  def go(args):
   z=subprocess.run([checker,str(f),str(d),'-t','40',*args],capture_output=True,timeout=180);assert z.returncode==0 and b's VERIFIED'in z.stdout,(key,z.stdout[-350:])
  if not verify:
   tr=p/'trim';go(['-C','-l',str(tr)]);proof=tr.read_bytes();d.write_bytes(proof)
  go(['-i'])
 if not verify:file.write_bytes(gzip.compress(proof,compresslevel=4,mtime=0))
 print('verified',key,len(C),hashlib.sha256(cnf).hexdigest(),len(proof),hashlib.sha256(proof).hexdigest(),flush=True);return False
