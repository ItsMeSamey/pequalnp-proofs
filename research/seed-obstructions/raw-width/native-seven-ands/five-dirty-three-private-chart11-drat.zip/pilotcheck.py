from physical import Model
from pathlib import Path
import tempfile,sys,gzip,hashlib,subprocess,time,resource
H=('ext',3,(1,2,3),4);C=Model(*H,solver=False).C
cnf=('p cnf %d %d\n'%(max(abs(z) for c in C for z in c),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode()
raw=gzip.decompress(Path('pilot-untrimmed.drat.gz').read_bytes());exe=sys.argv[1]
with tempfile.TemporaryDirectory(dir='/dev/shm')as td:
 p=Path(td);a=p/'cnf';d=p/'raw';t=p/'trim';a.write_bytes(cnf);d.write_bytes(raw)
 w=time.monotonic()
 out=subprocess.run([exe,str(a),str(d),'-C','-l',str(t),'-t','3'],capture_output=True)
 assert out.returncode==0 and b's VERIFIED'in out.stdout,out.stdout[-300:]
 dat=t.read_bytes();Path('pilot-trimmed.drat.gz').write_bytes(gzip.compress(dat,compresslevel=3,mtime=0))
 out=subprocess.run([exe,str(a),str(t),'-i','-t','3'],capture_output=True)
 assert out.returncode==0 and b's VERIFIED'in out.stdout,out.stdout[-300:]
 r=resource.getrusage(resource.RUSAGE_CHILDREN);s=resource.getrusage(resource.RUSAGE_SELF)
 print('11',len(C),hashlib.sha256(cnf).hexdigest(),len(dat),hashlib.sha256(dat).hexdigest(),'VERIFIED; total verify CPU',round(r.ru_utime+r.ru_stime+s.ru_utime+s.ru_stime,3),'checker wall',round(time.monotonic()-w,3))
