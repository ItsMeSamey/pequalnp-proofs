from functools import lru_cache
from random import Random
@lru_cache(maxsize=50000)
def price_cover(req, paired):
    if not req:return 0
    i=req&-req
    return 1+min(price_cover(req&~m,paired) for m in (i,*paired) if i&m)
def cheapest(req, granted):
    paired=tuple(sorted({req&g for g in granted if (req&g).bit_count()>1}))
    return max(0,price_cover(req, paired)-1)
def trial(T,order,provided):
    granted=[];total=0
    for i in order:
        lo,hi=T[i]
        # A shared previous cone can provide an arbitrary subset of its upper set.
        # A free supplied compound can only enter an OR cone if fully within its upper set.
        total+=cheapest(lo,[x for x in provided if x&~hi==0]+granted)
        granted.append(hi)
    return total
def lower(T,seed=7,provided=(129,320,513,1028,2052,4160)):
    rr=Random(seed);n=len(T);base=list(range(n))
    orders=[base,base[::-1],sorted(base,key=lambda i:T[i][0].bit_count()),sorted(base,key=lambda i:-T[i][0].bit_count())]
    for _ in range(12):
        p=base[:];rr.shuffle(p);orders.append(p)
    return max(trial(T,p,provided) for p in orders)
