import fcntl,os,signal,subprocess,sys,time
from pathlib import Path
def spawn(argv):
    return subprocess.Popen([sys.executable,'-c',"import os,signal,sys;os.setsid();os.nice(15);os.kill(os.getpid(),signal.SIGSTOP);os.execvp(sys.argv[1],sys.argv[1:])",*argv])
p=spawn(sys.argv[1:]);os.waitpid(p.pid,os.WUNTRACED)
try:
    while p.poll() is None:
        with open('/workspace/scratch/pnp-native-search.lock','a')as f:
            try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:time.sleep(.8);continue
            os.killpg(p.pid,signal.SIGCONT)
            for _ in range(22):
                time.sleep(.22)
                if p.poll() is not None:break
            if p.poll() is None:os.killpg(p.pid,signal.SIGSTOP)
        time.sleep(1.5)
finally:
    if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
sys.exit(p.wait())
