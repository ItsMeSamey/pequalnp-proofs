from itertools import combinations
def add(M,tags,sx,stars,N,N0,V,arm):
 # Use the named native negative for each zero-, one-, or two-label forbidden set. Extend to a maximal signed negative supporting all still-required labels.
 for z in (0,1,2):
  for Z in combinations(tags,z):
   forbid=sum(Z)
   zz=[n for n in N0 if n>>13==forbid and all(n&stars[t]for t in tags if t not in Z)]
   assert zz
   n=next(r for r in sorted(N)if any(not d&~r for d in zz))
   atoms=[sx(t)for t in tags if not sx(t)&n and stars[t]&n]
   atoms += [p for p in [1<<j for j in range(13)]if not p&n and any(sx(t)&n and stars[t]&p for t in tags)]
   ls={x:[] for x in atoms}
   for g in range(8):
    choices=[]
    for s in (0,1):
     a=V(('zero socket',Z,g,s));choices.append(a);M.C.append([-a,-arm(g,s,n)])
     for x in atoms:
      b=V(('first entry',Z,g,s,x));M.C.extend([[-b,a],[-b,arm(g,s,x)]]);ls[x].append(b)
    M.C.append([-choices[0],-choices[1]])
   M.C.extend(list(ls.values()))
