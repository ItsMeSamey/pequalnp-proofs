from physical import charts
from collections import Counter
H=list(charts());assert len(set(H))==len(H)==60
print('charts',len(H),'by center/backed',dict(Counter((mode,b)for mode,b,_,_ in H)))
print('series starts with exterior site',sum(hs[0]>0 for _,_,hs,_ in H))
