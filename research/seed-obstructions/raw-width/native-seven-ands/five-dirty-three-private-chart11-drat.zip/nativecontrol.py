"""Recover signed native rows and check actual 8-AND controls with each crossing multiplicity."""
import json,re
from pathlib import Path
src=json.loads(Path(__file__).with_name('L-meta-18968.json').read_text())['formal_statement']
seeds=[int(''.join(v.zfill(19) for v in re.findall(r'\((\d+) : ℕ\)',block))) for block in re.findall(r'\[([^]]+)\]',src)]
fields={int(i):int(v) for i,v in re.findall(r'x1 \((\d+) : ℕ\) = \((\d+) : ℕ\)',src)}
def rot(i,seed,off,k):
    return sum(((seed>>(i-i%13+(i-j-off)%13))&1)<<j for j in range(k))
rows=[(rot(i,seeds[0],0,13),rot(i,seeds[1],6,7),1 if (fields[88]&~fields[54])>>i&1 else -1 if not fields[88]>>i&1 else 0) for i in range(676)]
edges={(p,t) for p,t,s in rows if s==1}
assert len(edges)==28
private=32; other=(1,16,64)
for k in range(4):
    C=sum(other[:k])
    def run(p,t):
        petals=sum(a for a,b in edges if b==private)
        gates=[(bool(p&petals),bool(t&(C|private)))]
        gates.append((all(gates[0]), bool(t&private)))
        for j in range(7):
            v=1<<j
            if v!=private:gates.append((bool(p&sum(a for a,b in edges if b==v)),bool(t&v)))
        return any(all(x) for x in gates[1:]),gates
    for p,t,s in rows:
        val,_=run(p,t)
        assert s==0 or val==(s==1)
    for t in other:
        _,marks=run(0,t)
        assert sum(1 for x in marks if any(x))==1+bool(t&C)
    print('Native rows',len(rows),'crossing labels',k,'AND sites',len(marks))
