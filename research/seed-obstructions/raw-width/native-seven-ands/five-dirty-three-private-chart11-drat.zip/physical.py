from itertools import combinations, permutations, product
from nativecontrol import edges,rows
from pysat.formula import IDPool
from pysat.solvers import Cadical195
private=(2,4,8,32);ordinary=(1,16,64);alltag=private+ordinary
U={t:sum(p for p,s in edges if s==t) for t in alltag}
pts=[1<<j for j in range(13)]
q={t:next(p for p in pts if p&U[t] and sum(bool(p&m)for m in U.values())==1)for t in private}
N={p|t<<13 for p,t,y in rows if y<0}
mx=lambda S:{m for m in S if not any(m!=a and m&~a==0 for a in S)}
class Model:
    def __init__(self,mode,k,hosts,E,solver=False):
        self.mode=mode;self.k=k;self.C=C=[]; self.V=IDPool().id;V=lambda *x:self.V(x)
        def OR(o,ys):
            C.append([-o,*ys]);C.extend([o,-y]for y in ys);return o
        def AND(o,ys):
            C.append([o,*[-y for y in ys]]);C.extend([-o,y]for y in ys);return o
        W=self.W=lambda g,s,i:V('wire',g,s,i)
        G=self.G=lambda g,n:V('G',g,n)
        A=self.A=lambda g,s,n:V('arm',g,s,n)
        T=self.T=lambda g,n:V('hot',g,n)
        B=private[:k]
        sites=list(hosts);dext=sorted(set(range(5))-set(sites));ext=self.ext=tuple([*dext,5,6])
        J=self.J=dict(zip(private,sites+[7]));self.B=B;self.X=tuple(dext);self.E=E
        backup={t:(E if mode=='ext' or t==8 else J[8])for t in B}
        P={p|t<<13 for p,t in edges}
        neg=mx(N);pn={t:mx({n for n in N if n&(t<<13)}) for t in B}
        probes=neg|P|set.union(*pn.values())|{1<<i for i in range(20)}|{(t|v)<<13 for t,v in combinations(alltag,2)}
        for g in range(8):
            own=next((t for t,v in J.items()if g==v),None)
            for s in (0,1):
                for i in range(20):
                    x=1<<i;parts=None
                    if x in q.values():parts=(own is not None and q[own]==x and s==1)
                    elif i>=13 and (1<<(i-13)) in private:
                        t=1<<(i-13)
                        if g==J[t]:parts=s==0
                        elif backup.get(t)!=g:parts=False
                        elif own is not None:parts=s==0
                    elif own is not None and s==1 and not (x&U[own]):parts=False
                    elif own==32 and s==0:parts=False
                    if parts is not None:C.append([W(g,s,i)*(1 if parts else -1)])
        for t,g in backup.items():C.append([W(g,0,13+t.bit_length()-1),W(g,1,13+t.bit_length()-1)])
        for n in sorted(probes):
            for g in range(8):
                arms=[]
                for s in range(2):
                    ys=[W(g,s,i) for i in range(20)if n&(1<<i)]
                    ys += [AND(V('lit',g,s,d,n),[W(g,s,20+d),G(d,n)]) for d in range(min(g,5))]
                    arms.append(OR(A(g,s,n),ys))
                AND(G(g,n),arms);OR(T(g,n),arms)
            if n in P:C.append([G(g,n)for g in range(5,8)])
            if n in neg:C.extend([-G(g,n)]for g in range(5,8))
        for t in private[:3]:
            g=J[t]
            C.append([G(g,n)for n in neg])
            C.extend([-G(g,n)]for n in pn[t])
            C.extend([[G(g,q[t]|(t<<13))],[G(backup[t],q[t]|(t<<13))]])
            for i in range(8):
                if i!=g:C.append([-T(i,q[t])])
        for X in dext:C.append([G(X,n)for n in neg])
        for t in private:
            for j in range(8):
                if j!=J[t]:C.append([-T(j,q[t])])
        for t in alltag:
            n=t<<13
            C.extend([-G(g,n)]for g in range(8))
            C.extend([-T(g,n)for g in v]for v in combinations(range(8),3))
        for t,v in combinations(alltag,2):
            n=(t|v)<<13
            C.extend([-T(g,n) for g in sites]for sites in combinations(range(8),4))
        for r in (1,2,3):
            for S in combinations(ordinary,r):
                for cut in combinations(ext,r-1):C.append([T(g,t<<13)for g in ext if g not in cut for t in S])
        # Native singleton-tag complement resolution ensures a private tag socket for every tag.
        for t in alltag:
            choices=[]
            for g in range(8):
                for side in (0,1):
                    x=V('exclusive',g,side,t)
                    C.append([-x,W(g,side,13+t.bit_length()-1)])
                    C.extend([-x,-W(g,side,13+v.bit_length()-1)]for v in alltag if v!=t)
                    choices.append(x)
            C.append(choices)
        # In each numbered private site, no other raw point on the petal may be high in the presence of its tag at an unsafe input.
        if k==3:
            for p in pts:
                if U[32]&p:C.append([A(7,1,p)])
        for g in ext:
            pre=[]
            for i in range(20+min(g,5)):
                a,b=W(g,0,i),W(g,1,i); C.append(pre+[-a,b]);e=V('eq',g,i)
                C.append(pre+[a,b,e]);C.append(pre+[-a,-b,e]);pre=[-e]
        # Exterior sites 4,5,6 are interchangeable. Sort their singleton ordinary-tag addresses.
        for g in ([5] if E<5 else []):
            pre=[]
            for t in ordinary:
                a,b=T(g,t<<13),T(g+1,t<<13);C.append(pre+[-a,b]);e=V('lex',g,t)
                C.append(pre+[a,b,e]);C.append(pre+[-a,-b,e]);pre=[-e]
        self.solver=None;self.hot=T;self.G=G
        self.cuts=[(J[t],t,backup[t]) for t in private[:3]]
        for t in private[:3]:
            g=J[t];bpos=backup[t]
            C.extend([-G(g,n),-G(bpos,n)] for n in neg)
            for side in (0,1):
                w=W(bpos,side,13+t.bit_length()-1)
                for n in probes:C.append([-w,-G(g,n),A(bpos,1-side,n)])
                for n in neg:C.append([-w,-G(g,n),-A(bpos,side,n)])
            for v in alltag:
                if t==v:continue
                for side in (0,1):
                    a=[-W(bpos,side,13+t.bit_length()-1),-W(bpos,side,13+v.bit_length()-1)]
                    C.extend(a+[A(g,1,p)]for p in pts if p&U[t] and not p&U[v])
            for v in alltag:
                if v==t:continue
                for side in (0,1):
                    c=[-W(bpos,side,13+t.bit_length()-1),-W(bpos,side,13+v.bit_length()-1)]
                    for n in neg:
                        if n&(v<<13):C.append(c+[-G(g,n)])
        # Common exterior: the earlier callers cannot read their own correction.
        if mode=='ext':
            for side in (0,1):
                anchor=W(E,side,13+private[0].bit_length()-1)
                for t in private[1:3]:
                    w=W(E,side,13+t.bit_length()-1);C.extend([[-anchor,w],[-w,anchor]])
        full=private[:3] if mode=='ext' else private[:2]
        for t in full:
            for p in pts:
                if U[t]&p:C.append([A(J[t],1,p)])
                C.append([-G(J[t],p)])
            C.extend([-G(J[t],n)]for n in neg if n&sum(j<<13 for j in B))
            C.extend([-A(J[t],0,j<<13)]for j in alltag if j!=t)
        from selection import add as select
        select(self,alltag,lambda t:t<<13,U,neg,N,V,A)
    def solve(self):
        with Cadical195(bootstrap_with=self.C)as S:
            S.conf_budget(12000);return S.solve_limited()
def charts():
 for mode in ('ext','hub'):
  for k in (3,4):
   for hs in combinations(range(5),3):
    for E in (5,*range(hs[-1]+1,5)):yield mode,k,hs,E

private_sources=private
ordt=ordinary
stars=U
def sx(t):return t<<13
P={p|sx(t)for p,t in edges}
N0=N
