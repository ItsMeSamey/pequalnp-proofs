import itertools,json,os,resource,signal,sys,time
from pathlib import Path
from physical import Model,charts,ordinary,sx
from pysat.solvers import Cadical195,Glucose4
from boxes import stock,masks
from controlcheck import realize
H=('ext',3,(1,2,3),4);ix=list(charts()).index(H)
cpu=lambda:round(time.process_time(),3)
wall=time.monotonic()
print('one pilot',ix,H,'dirty 0,4 exterior; private 1,2,3; backup 4; clean 5,6,7',flush=True)
M=Model(*H,solver=False);T=stock(M)
print('clauses',len(M.C),'features',[(T[2*g][1]>>20)&31 for g in (5,6,7)],'CPU',cpu(),flush=True)
def witness(S,phase):
 v=set(S.get_model());w=masks(T,v);marks=[sum(1<<g for g in range(8)if M.hot(g,sx(t))in v) for t in ordinary]
 sol=realize(ix,w,marks);Path('pilot-control.json').write_text(json.dumps([ix,marks,w,*sol],separators=(',',':')))
 print('NATIVE CONTROL',phase,marks,'area',sol[0],'full cube',sol[1],flush=True)
def attempt(S,tag,ass,budget,proof=False):
 S.conf_budget(budget);a=S.solve_limited(assumptions=ass);print(tag,a,'budget',budget,'CPU',cpu(),'wall',round(time.monotonic()-wall,3),flush=True)
 if a is True:witness(S,tag);return 'done'
 if a is False and not ass:
  if proof:
   import gzip
   dat=('\n'.join(S.get_proof())+'\n').encode();Path('pilot-untrimmed.drat.gz').write_bytes(gzip.compress(dat,compresslevel=1,mtime=0))
   print('raw DRAT bytes',len(dat),flush=True)
  return 'done'
 return 'continue'
# Ordinary masks remain unrestricted in the whole-chart attempts.
with Cadical195(bootstrap_with=M.C)as S:
 for tag,k in [('planted last backup a',(17,32,64)),('planted separate readers',(1,48,64))]:
  ass=[(1 if m>>g&1 else -1)*M.hot(g,sx(t))for m,t in zip(k,ordinary)for g in range(8)]
  if attempt(S,tag,ass,300)=='done':sys.exit(0)
 if attempt(S,'whole CaDiCaL',[],900)=='done':sys.exit(0)
with Glucose4(bootstrap_with=M.C,with_proof=True) as G:
 attempt(G,'whole Glucose',[],2600,True)
print('finished CPU',cpu(),'wall',round(time.monotonic()-wall,3),flush=True)
