from nativecontrol import edges,rows
from itertools import combinations
private=(2,4,8,32)
S={t:{p for p,j in edges if t==j}for t in {*private,1,16,64}}
q={t:next(p for p in S[t]if sum(p in a for a in S.values())==1)for t in private}
N={p|(t<<13)for p,t,y in rows if y<0}
reg=set().union(*S.values())-set(q.values())
assert len(reg)==9 and all(len(S[t])==4 and S[t]-{q[t]}<=reg for t in private)
assert all(len(S[a]&S[b])==1 for a,b in combinations(private,2))
assert all(not set.intersection(*(S[t]for t in ss))for ss in combinations(private,3))
assert all(len([p for p in S[t]if p&C])<=1 for t in private for C in (129,4160))
assert all(not q[t]&C for t in private for C in (129,4160))
for t in private:
 for v,w in combinations(set(private)-{t},2):
  assert (S[t]-S[v])|(S[t]-S[w])==S[t]
 for p in set().union(*S.values())-S[t]:
  assert any(not ((t<<13)|p)&~n for n in N)
print('4 stars of four points; all six pair intersections singleton; four triple intersections empty; no free pair hits two petals of one private star; all private nonincidence probes have genuine negative extensions')
