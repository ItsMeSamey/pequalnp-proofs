from model import *
from pysat.solvers import Glucose4
from pathlib import Path
import hashlib,sys,gzip,tempfile,subprocess
def writeproof(i,budget,gl,verify,part):
 H=list(charts())[i];M=Model(*H);C=list(M.C)
 if part:
  from corpus import ass,keys
  ks=list(keys(H));jj,jjmax=part
  ks=ks[jj::jjmax];opts=[]
  for k in ks:
   opt=M.V(('name',*k));opts.append(opt);C.extend([-opt,z]for z in ass(M,k))
  C.append(opts)
 key=str(i) if not part else f'{i}-{jj}-{jjmax}'
 target=Path('proofs')/(key+'.drat.gz')
 if target.exists():verify=True
 if verify:proof=gzip.decompress(target.read_bytes())
 else:
  with Glucose4(bootstrap_with=C,with_proof=True)as S:
   S.conf_budget(budget);ans=S.solve_limited()
   if ans is not False:print(key,ans,flush=True);return False
   proof=('\n'.join(S.get_proof())+'\n').encode()
 cnf=('p cnf %d %d\n'%(max(abs(v)for c in C for v in c),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode()
 with tempfile.TemporaryDirectory(dir='/dev/shm')as td:
  p=Path(td);f=p/'chart.cnf';d=p/'receipt.drat';f.write_bytes(cnf);d.write_bytes(proof)
  def test(opts):
   res=subprocess.run([gl,str(f),str(d),'-t','30',*opts],capture_output=True,timeout=120)
   assert res.returncode==0 and b's VERIFIED'in res.stdout,(key,res.stdout[-300:])
  if not verify:
   trim=p/'trim.drat';test(['-C','-l',str(trim)]);proof=trim.read_bytes();d.write_bytes(proof)
  test(['-i'])
 if not verify:target.parent.mkdir(exist_ok=True);target.write_bytes(gzip.compress(proof,compresslevel=6,mtime=0))
 print(key,H,len(C),hashlib.sha256(cnf).hexdigest(),len(proof),hashlib.sha256(proof).hexdigest(),'VERIFIED',flush=True);return True
if __name__=='__main__':
 ix,bud,gl=sys.argv[1:4]
 for i in [int(z)for z in ix.split(',')]:writeproof(i,int(bud),gl,'--verify-only'in sys.argv,tuple(map(int,sys.argv[4:6])) if len(sys.argv)>5 else None)
