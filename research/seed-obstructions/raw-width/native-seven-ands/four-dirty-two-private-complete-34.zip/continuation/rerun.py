from boxes import *
for i in map(int,sys.argv[1].split(',')):
 if Path(f'proofs/{i}-boxes.gz').exists():run(i,sys.argv[2],verify=True)
 else:verify_cnf(f'{i}-zero',Model(*list(charts())[i],solver=False).C,sys.argv[2],True)
