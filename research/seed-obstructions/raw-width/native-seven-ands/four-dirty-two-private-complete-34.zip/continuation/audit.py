from boxes import *
from pathlib import Path
from collections import Counter
import gzip,hashlib
from sym import banks as transported
assert set(BANKS)==set(transported)
covered={}
for log in ['coarse.log','boxes.log']:
 for row in Path(log).read_text().splitlines():
  if not row.startswith('verified '):continue
  _,key,clauses,cnf,sz,sha=row.split();i,mode=key.split('-');i=int(i)
  assert i not in covered
  layout=read(i);M=Model(*list(charts())[i],solver=False);T=stock(M)
  if mode=='boxes':
   assert layout
   for r in layout:
    assert len(r['w'])==16 and all((a&m)==a and not m&~b for (a,b),m in zip(r['box'],r['w']))
   addboxes(M,T,layout)
  else:assert mode=='zero' and not layout
  C=M.C;assert len(C)==int(clauses)
  bb=('p cnf %d %d\n'%(max(abs(x)for c in C for x in c),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode();assert hashlib.sha256(bb).hexdigest()==cnf
  pr=gzip.decompress((Path('proofs')/(key+'.gz')).read_bytes());assert len(pr)==int(sz) and hashlib.sha256(pr).hexdigest()==sha
  covered[i]=(mode,len(layout),min([r['charge']for r in layout],default=None))
old={int(p.name.split('.')[0])for p in Path('../proofs').glob('*.drat.gz')}
assert not old&covered.keys() and old|covered.keys()==set(range(60)) and len(old)==32
stats=Counter()
for i,H in enumerate(charts()):
 r=('checkpoint',0,None) if i in old else covered[i];print(i,*H,*r,flush=True);stats[H[-1],r[0]]+=1
print('all roles',sorted(stats.items()),'boxes',sum(r[1]for r in covered.values()),'minimum boxed OR',min(r[2]for r in covered.values()if r[2] is not None))
