from boxes import *
from pathlib import Path
old={int(p.name.split('.')[0])for p in Path('../proofs').glob('*.drat.gz')}
zero={int(p.name.split('-')[0])for p in Path('proofs').glob('*-zero.gz')}
for i in sorted(set(range(60))-old-zero,key=lambda j:(list(charts())[j][0]==0,j)):
 if Path(f'proofs/{i}-boxes.gz').exists():continue
 print('start',i,flush=True);print('result',i,run(i,sys.argv[1],cap=int(sys.argv[2]),budget=int(sys.argv[3])),flush=True)
