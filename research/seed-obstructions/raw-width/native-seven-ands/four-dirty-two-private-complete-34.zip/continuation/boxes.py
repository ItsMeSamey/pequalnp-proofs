from physical import *
from unionprice import trial
from proofs import verify_cnf
from functools import lru_cache
from random import Random
import json
from pathlib import Path
BANKS=((129,320),(129,1028),(129,2052),(129,4160),(320,513),(320,1028),(320,2052),(513,1028),(513,2052),(513,4160),(1028,4160),(2052,4160))
free=tuple(sorted({p for pair in BANKS for p in pair}));quota=23
def bit(x):return x if x>0 else 1<<(19-x)
def stock(M):
 T=[];units={c[0] for c in M.C if len(c)==1}
 for g in range(8):
  for s in (0,1):
   if g<6:fixed=0;symbols=M.keys[g,s]
   else:
    t=(8,32)[g-6];fixed=sx(t) if s==0 else q[t]
    symbols=[-1-i for i in range(4)]
    if s==1:symbols+=sorted(p for p,j in edges if j==t and p!=q[t])
   entries=[];lo=hi=fixed
   for x in symbols:
    lit=M.term(g,s,x);a=bit(x)
    if -lit in units:continue
    hi|=a
    if lit in units:lo|=a
    else:entries.append((a,lit))
   T.append((lo,hi,entries))
 return T
def masks(T,sm):return tuple(lo|sum(a for a,l in cols if l in sm)for lo,hi,cols in T)
def encode(T,box):
 out=[]
 assert len(T)==len(box)==16
 for (floor,ceil,cols),(lo,hi) in zip(T,box):
  assert not floor&~lo and not lo&~hi and not hi&~ceil
  for a,v in cols:
   if a&lo:out.append(v)
   elif not a&hi:out.append(-v)
 return out
@lru_cache(maxsize=10000)
def orderings(T):
 seq=list(range(len(T)));r=Random(67);arr=[seq,seq[::-1],sorted(seq,key=lambda i:T[i][0].bit_count()),sorted(seq,key=lambda i:-T[i][0].bit_count())]
 for _ in range(18):
  z=seq[:];r.shuffle(z);arr.append(z)
 return arr
@lru_cache(maxsize=50000)
def charge(box):
 T=tuple(sorted(set((lo,hi)for lo,hi in box if lo)))
 def cost(bank):
  v=0
  for ix in orderings(T):
   v=max(v,trial(T,ix,bank))
   if v>=quota:break
  return v
 z=cost(free)
 if z>=quota:return z
 return min(cost(p)for p in BANKS)
def widen(T,w):
 orig=tuple((m,m) for m in w);score=charge(orig)
 if score<quota:return orig,score
 box=list(orig)
 # First coarsen donor assignments across every socket at once, where possible.
 rawcap=(1<<20)-1;domains=[(l,r)for l,r,c in T]
 pureraw=[(m&rawcap|l&~rawcap,m&rawcap|r&~rawcap)for m,(l,r) in zip(w,domains)]
 if charge(tuple(pureraw))>=quota:box=pureraw
 for phase in ('whole','donor','neg','pos'):
  for i in sorted(range(16),key=lambda i:-(domains[i][1]^domains[i][0]).bit_count()):
   l,r=domains[i];a,b=box[i]
   if phase=='whole':z=(l,r)
   elif phase=='donor':z=(a&rawcap|l&~rawcap,b&rawcap|r&~rawcap)
   elif phase=='neg':z=(a,r)
   else:z=(l,b)
   if z==box[i]:continue
   row=box[i];box[i]=z
   if charge(tuple(box))<quota:box[i]=row
 return tuple(box),charge(tuple(box))
def path(i):return Path(f'boxes-{i}.json')
def read(i):return json.loads(path(i).read_text())if path(i).exists()else []
def addboxes(M,T,data):
 for row in data:
  box=tuple(tuple(z)for z in row['box']);assert charge(box)==row['charge'] and row['charge']>=quota
  M.C.append([-s for s in encode(T,box)])
def run(i,checker,cap=12,budget=9000,verify=False):
 H=list(charts())[i];M=Model(*H,solver=False);T=stock(M);data=read(i);addboxes(M,T,data)
 if verify:return verify_cnf(str(i)+'-boxes',M.C,checker,True)
 S=Cadical195(bootstrap_with=M.C);queued=0
 while queued<cap:
  S.conf_budget(budget);ans=S.solve_limited()
  if ans is None:print('cadical budget',i,len(data),flush=True);break
  if ans is False:break
  model=set(S.get_model());w=masks(T,model);box,score=widen(T,w)
  marks=[sum(1<<g for g in range(6)if M.hot(g,sx(t))in model) for t in ordt]
  if score<quota:
   print('low',i,score,marks,flush=True);Path(f'low-{i}.json').write_text(json.dumps([marks,w]));return 'low'
  cc=[-v for v in encode(T,box)];M.C.append(cc);S.add_clause(cc);queued+=1
  data.append({'box':box,'charge':score,'w':w,'marks':marks})
  tmp=path(i).with_suffix('.tmp');tmp.write_text(json.dumps(data,separators=(',',':'))+'\n');tmp.replace(path(i))
  print('box',i,len(data),score,len(cc),flush=True)
 S.delete()
 if queued==cap:return 'limit'
 return verify_cnf(str(i)+'-boxes',M.C,checker,budget=budget*2)
if __name__=='__main__':
 ix,gl,cap=sys.argv[1:4]
 for i in map(int,ix.split(',')):print('result',i,run(i,gl,int(cap),verify='--verify-only'in sys.argv),flush=True)
