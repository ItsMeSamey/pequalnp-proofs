from physical import *
from proofs import verify_cnf
from pathlib import Path
checker=sys.argv[1];budget=int(sys.argv[2]);done={int(p.name.split('.')[0]) for p in Path('../proofs').glob('*.drat.gz')}
for i in sorted(set(range(60))-done,key=lambda i:(list(charts())[i][0]==0,i)):
 H=list(charts())[i];M=Model(*H,solver=False);ans=verify_cnf(str(i)+'-zero',M.C,checker,budget=budget)
 print('chart',i,H,ans,flush=True)
