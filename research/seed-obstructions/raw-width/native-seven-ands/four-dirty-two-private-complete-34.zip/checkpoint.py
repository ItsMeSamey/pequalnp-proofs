from pathlib import Path
from ast import literal_eval
import hashlib,gzip
from collections import Counter
logs=['initial.log','four.log','three.log','primary.log']
found={};reported={}
for log in logs:
 for line in Path(log).read_text().splitlines():
  if not line[:1].isdigit():continue
  if line.endswith((' True',' None')):
   key,answer=line.split();reported[int(key)]=answer;continue
  if not line.endswith(' VERIFIED'):continue
  key,H=line.split(' ',1);which,j=H.split(') ',1);H=literal_eval(which+')');_,cnf_sha,n,proof_sha,_=j.split()
  proof=gzip.decompress(Path(f'proofs/{key}.drat.gz').read_bytes())
  assert len(proof)==int(n) and hashlib.sha256(proof).hexdigest()==proof_sha
  assert int(key) not in found or found[int(key)]==H
  found[int(key)]=H
assert {int(p.name.split('.')[0])for p in Path('proofs').glob('*.drat.gz')}==set(found)
assert all(i in found for i in range(2,60,3))
print('whole-chart checked',dict(sorted(Counter(h[-1]for h in found.values()).items())))
print('covered',sorted(found))
print('unpriced relaxation flags',sorted(reported.items()))
