from model import *
def keys(chart):
 h,k,mode,B=chart
 pairs=((1<<h)|(1<<B),(1<<k)|(1<<(h if mode=='cross' else B)))
 ex=set(range(6))-{h,k}
 masks=[m for m in range(1,64)if m.bit_count()<=2 and not m>>k&1 and any(m&(1<<j) for j in ex) and all((m|r).bit_count()<=3 for r in pairs)]
 perms=[dict(zip((3,4),p))for p in permutations((3,4))if B<3 or p[0]==3]
 for ms in product(masks,repeat=3):
  if any((a|b).bit_count()>3 for a,b in combinations(ms,2)):continue
  if not any(all(m>>g&1 for m,g in zip(ms,G))for G in permutations(ex,3)):continue
  if any(tuple(sum(1<<p.get(i,i) for i in range(6)if m>>i&1)for m in ms)<ms for p in perms):continue
  yield ms
def ass(M,k):return [M.hot(g,sx(t))*(1 if m>>g&1 else -1)for t,m in zip(ordt,k)for g in range(6)]
if __name__=='__main__':
 index=int(sys.argv[1]);H=list(charts())[index];M=Model(*H)
 for k in keys(H):
  z=M.do(ass(M,k),1600);print(k,z,flush=True)
