# Exactly two backed private tags and one dirty private matched site at three dirty ANDs cost 38

Work in the established normalized native eight-AND family with exactly three dirty ANDs and five isolated contributing clean ANDs. Each private point has one matched site opposite its tag. Each tag touches at most two sites, every tag pair touches at most three on its actual evaluation, every bare tag is AND-low, each tag has a tag-exclusive socket, and the ordinary tags have distinct exterior representatives. The exclusive-socket fact follows by forbidding one competing label on each of the at most two tagged sockets in native-eight-tag-hall.zip. Assume exactly two private tags are backed (have second AND addresses) and exactly one private matched site is dirty. This branch has exact physical area 38 when the native compound inputs are available. Its lower bound of 38 holds across all four native compound banks.

## Roles and cuts

Let H be the dirty private site with private point q and own tag u. Every path from q first hits H; there is no OR-only route to the rejecting output and only H marks q. Since the circuit rejects bare u and accepts q+u, H(q+u)=1. On any actual negative carrying u, H must be low, since fixing its value high cuts every separate effect of q and gives acceptance at bare u beyond the cut. If H were also the sole address of u, every raw path from q or u would first meet H; any genuine dirty negative for H would dominate q+u beyond that cut and accept. Thus u is backed.

Let K be the clean matched site of the other backed tag v. A clean private site cannot carry a foreign tag: a guest on its own tag operand accepts its private point with that foreign tag, while a tag on the opposite operand accepts a pair of tags. Its own tag socket contains no raw points, since these would accept their pair with the private point opposite or the bare private point. Its point socket can contain only raw native points from its own star. Dirty donors to its two sockets are still unrestricted at this stage, and the raw membership of K's point socket is not filled. Backed v may have positives served elsewhere.

Write B for u's second site, necessarily exterior. B must be high on q+u. Otherwise the q+u values of the two-site cut H,B would be dominated on any dirty negative of H. All q or u paths meet one of H,B. By the same argument the two sites cannot simultaneously rise on a negative. B(q+u)=1 and B(u)=0 force H strictly before B. The second address of v is H or an exterior. In the exterior case it must equal B, since otherwise u+v would mark four sites. In the H case v is a genuine private guest, and B retains its role as H's own-tag backup. These shared and cross cases exhaust all backup locations. No ordering or compensation duty is imposed on K's second address from K's cleanliness. An extra no-joint-negative clause for K and that address is automatic since K already rejects every negative.

## Finite signed model

The 24 signed symmetries checked in sym.py realize all permutations of the four private labels. The checker transports the exact incidence positives and the maximal original negatives. Monotonicity preserves the native signed problem and dirtiness on a true negative. Therefore arrange u=2 and v=4. Number the dirty ANDs 0,1,2 in topological order with H at h. Two clean exterior sites are 3,4, K is site 5, and the two unbacked private clean terminals are 6,7. For a clean B choose site 3, and for a dirty B use every index strictly after h. Both shared and cross variants are tested at each of the six choices of h,B.

The six core sites (0–5) take formal ORs of nine nonprivate points, the two backed private points and tags, the three ordinary tags, and earlier dirty outputs. The two unique private points can only enter the point sockets of their own sites. Raw point leaves on H's q socket belong to its own star and no tags can occur there by H's darkness on negatives containing u. H's tag socket may include any ordinary guest or projected regular point. K's two raw sockets obey the clean restrictions above and are separately enumerated, each allowing all prior dirty donors. In particular the signed search neither forces complete N(v) on K's point socket nor assumes its tag socket remains literal v.

For each of the two unbacked sites Jt, its point operand is high on every bare p of N(t), because adding t at p changes the output, the only raw address of t is Jt's tagged socket, and its other socket cannot depend on t. A clean private site also has no raw atoms outside t on the tag socket and outside N(t) on the point socket as above. The point socket may be semantically filled with all raw N(t) for unpriced feasibility: any row carrying such a p already raises it by monotonicity. Both operands are allowed arbitrary subsets of all three dirty outputs. All 28 original positives must be accepted by some one of the five clean ANDs; all native maximal negatives are rejected by every clean AND and at least one such actual negative raises each dirty AND. Actual singleton marks, bare tag AND darkness, full pair-evaluation caps, exclusive sockets and exterior representatives are tested. The raw petal filling is never used as a physical OR demand.

Corpus.py names all sets of up to two sites for each of the three ordinary tags, including their distinct exterior representatives and excluding the clean private K. It includes ordinary guests at H and retains the two backed private masks for the union cap. Only the two exterior clean names may be swapped, and only if this preserves the already named B position. Each core AND other than H,K uses a lexicographic clause to order its two input sockets. Price.py exhaustively blocks the twelve core membership vectors under each feasible signature, leaving the donor flags of the two unbacked sites existential.

| h | B | Mode | Queries | Realizable | Enumerated core layouts |
|---:|---:|---|---:|---:|---:|
| 0 | 3 | shared | 300 | 0 | 0 |
| 0 | 1 | shared | 150 | 0 | 0 |
| 0 | 2 | shared | 150 | 3 | 225 |
| 0 | 3 | cross | 192 | 0 | 0 |
| 0 | 1 | cross | 96 | 0 | 0 |
| 0 | 2 | cross | 96 | 0 | 0 |
| 1 | 3 | shared | 300 | 4 | 1,696 |
| 1 | 2 | shared | 150 | 9 | 785 |
| 1 | 3 | cross | 192 | 0 | 0 |
| 1 | 2 | cross | 96 | 0 | 0 |
| 2 | 3 | shared | 300 | 4 | 1,696 |
| 2 | 3 | cross | 192 | 4 | 240 |

All 2,214 queries yield definite results. There are 2,190 rejected signatures, 24 realizable signatures and 4,642 surviving twelve-socket membership assignments. No ordinary tag marks H in a feasible shared signature. In every cross signature H is last, B is clean, and one or two ordinary tags additionally join v on H. Since an incomparable dirty site could be ordered after H, both other dirty sites must physically precede H in the cross case.

## Physical charge and attainment

The twelve core OR sockets are exact formal targets. For each unbacked site Jt the upper set for the physical point socket comprises N(t) and every dirty Dg low on all native negatives carrying t. Its compulsory lower set contains each point p in N(t) where none of these eligible dirty outputs is high on bare p. Such p must physically occur as a raw origin to give that mandatory bare-p response. Any costs of the two other private tag sockets are omitted. Formal dirty outputs are distinct atomic origins.

For a fixed target order, assign each physical prefix OR to the first target whose OR-only input cone contains it. At a later target a previously charged signal can cover only mandatory atoms also lying in a prior target's permitted upper set. Grant the entire such intersection as a single reusable input. Singleton sources and supplied point pairs wholly contained in the current upper set are also free. If k facilitated sources are still needed to cover its mandatory inputs, connecting them takes at least k−1 newly charged binary ORs. This counts disjoint gates across the order and permits repeated and overlapping sockets.

The signed permutations need not preserve the two supplied primitive pairs 129 and 4160. Sym.py computes all twelve transported pair banks. The OR cover initially grants all six individual pair wires seen anywhere among them. If necessary price.py tests each separate bank and takes the minimum. Thus the bound remains valid after any signed relabeling or omission of an original free compound. Every one of the 4,642 assignments certifies at least 26 upstream physical ORs. The five exposed clean terminals require four additional collector ORs. There are eight physical ANDs, so area is at least 38.

Controls.py verifies all 24 positive signatures on actual binary DAGs, checking all 676 native rows, actual dirtiness, the four private point addresses, all retained site masks, tag-pair and singleton probes, and both the exclusive socket and exterior matching requirements. The output's set of minimal true terms is exactly the 28 incidence pairs for every control, giving whole-cube realizations. The areas are 38 for two controls, 40 for two, 41 for nine and 42 for eleven. Both controls attaining 38 have a shared, dirty exterior B at position 2; H is at position 0 or 1.

## Replay

Use Python 3 and python-sat with CaDiCaL195. For indices i=0 through 11, run corpus.py i to corpus-i.log, then price.py i 15000 to prices-i.log. Run receipts.py, controls.py and sym.py. Each control record gives the chart, ordinary mask triple, physical gate count, full-cube flag, gate list, AND wire indices, and output. Raw wires are 0–19; primitive pairs 129 and 4160 are wires 20,21 respectively; the binary gate list begins at 22.
