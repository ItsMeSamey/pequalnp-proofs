from nativecontrol import rows,edges
from itertools import combinations,product,permutations
from pysat.formula import IDPool
from pysat.solvers import Cadical195
from collections import Counter
import sys
P={p|(t<<13) for p,t in edges}
N0={p|(t<<13) for p,t,y in rows if y<0}
N={x for x in N0 if not any(x!=y and x&~y==0 for y in N0)}
private=(2,4,8,32);ordt=(1,16,64)
stars={t:sum(p for p,j in edges if j==t)for t in (*private,*ordt)}
q={t:next(p for p,j in edges if j==t and sum(bool(S&p)for S in stars.values())==1)for t in private}
points=sorted({p for p,t in edges}-set(q.values()))
def sx(t):return t<<13
def mx(xs):return {x for x in xs if not any(x!=y and x&~y==0 for y in xs)}
class Model:
  def __init__(self,h,k,variant,B):
    self.h=h;self.k=k;self.B=B;self.mode=variant
    raw=points+[sx(j) for j in (*ordt,2,4)]+[q[2],q[4]]
    self.raw=raw;A=sum(raw); self.A=A
    ex=tuple(i for i in range(6)if i not in (h,k));self.ex=ex
    cuts=[(h,2,B),(k,4,h if variant=='cross' else B)];self.cuts=cuts
    C=[];V=IDPool().id;self.C=C;self.V=V
    def term(g,s,x):return V(('wire',g,s,x))
    self.term=term
    def AND(y,x):C.append([y,*[-z for z in x]]);C.extend([-y,z]for z in x);return y
    def OR(y,x):C.append([-y,*x]);C.extend([y,-z]for z in x);return y
    def G(g,m):return V(('gate',g,m&A if g<6 else m))
    def arm(g,s,m):return V(('arm',g,s,m&A if g<6 else m))
    def hot(g,m):return V(('hot',g,m&A if g<6 else m))
    self.hot=hot;self.G=G
    tags=(*ordt,*private);sing=[sx(t)for t in tags];pairs=[sx(a|b)for a,b in combinations(tags,2)]
    probes=P|N|set(sing+pairs+list(q.values())+points)
    # Dirty / exterior clean form the six core sites.
    keys={}
    for g in range(6):
      for s in (0,1):
        keys[g,s]=[*raw,*[-1-i for i in range(min(3,g))]]
        for i,(d,t,back) in enumerate(cuts):
          if (g,s)!=(d,1):C.append([-term(g,s,q[t])])
          if g==d and s==0:
            C.append([term(g,s,sx(t))])
            if g==k:C.extend([-term(g,s,x)]for x in raw if x!=sx(t))
          if g==d and s==1:
            C.append([term(g,s,q[t])])
            C.extend([-term(g,s,x)]for x in raw if x&stars[t]==0)
      if g not in (h,k):
        prefix=None
        for x in keys[g,0]:
          a,b=term(g,0,x),term(g,1,x);prev=[] if prefix is None else [-prefix]
          C.append(prev+[-a,b]);eq=V(('eq',g,x));C.append(prev+[a,b,eq]);C.append(prev+[-a,-b,eq]);prefix=eq
    self.keys=keys
    for g in range(6):
      for m in sorted({x&A for x in probes}):
        a=[]
        for s in (0,1):
          ls=[term(g,s,x)for x in raw if x&m]
          ls.extend(AND(V(('aux',g,s,i,m)),[term(g,s,-1-i),G(i,m)])for i in range(min(g,3)))
          a.append(OR(arm(g,s,m),ls))
        AND(G(g,m),a);OR(hot(g,m),a)
    for g,t in enumerate((8,32),6):
      for m in probes:
        a=[]
        for s in (0,1):
          ls=[]
          if (s==0 and m&sx(t)) or (s==1 and m&stars[t]):
            a.append(arm(g,s,m));C.append([a[-1]]);continue
          ls.extend(AND(V(('unbacked aux',g,s,i,m&A)),[term(g,s,-1-i),G(i,m)])for i in range(3))
          a.append(OR(arm(g,s,m),ls))
        AND(G(g,m),a);OR(hot(g,m),a)
    for m in N:C.extend([-G(g,m)]for g in range(3,8))
    for m in P:C.append([G(g,m)for g in range(3,8)])
    for g in range(3):C.append([G(g,m)for m in N])
    for d,t,back in cuts:
      for m in N:
        if m&sx(t):C.append([-G(d,m)])
        C.append([-G(d,m),-G(back,m)])
      if d==h:C.append([G(back,q[t]|sx(t))])
      for g in range(8):
        if g!=d:C.append([-hot(g,q[t])])
        C.append([(1 if g in (d,back) else -1)*hot(g,sx(t))])
    for t in (8,32):
      for g in range(8):
        if g!=6+(t==32):C.append([-hot(g,q[t])])
    for m in sing+pairs:
      for gs in combinations(range(8),3 if m in sing else 4):C.append([-hot(g,m)for g in gs])
      if m in sing:C.extend([-G(g,m)]for g in range(8))
    # An exclusive socket per ordinary / private backed label (sole unbacked labels raw elsewhere cannot enter).
    for t in (*ordt,2,4):
      ll=[]
      for g in range(6):
        for s in (0,1):
          y=V(('exclusive',t,g,s));ll.append(y)
          C.append([-y,arm(g,s,sx(t))]);C.extend([-y,-arm(g,s,sx(z))]for z in (*ordt,2,4) if z!=t)
      C.append(ll)
    for j in (1,2,3):
      for ts in combinations(ordt,j):
        for gs in combinations(ex,j-1):C.append([hot(g,sx(t))for g in ex if g not in gs for t in ts])
    self.sat=Cadical195(bootstrap_with=C)
  def do(self,ass,n):
    self.sat.conf_budget(n);return self.sat.solve_limited(assumptions=ass)
  def witness(self):
    W=set(self.sat.get_model())
    return [[tuple(x for x in self.keys[g,s] if self.term(g,s,x)in W)for s in (0,1)]for g in range(6)]
def charts():
  for h in range(3):
    for mode in ('shared','cross'):
      for B in (3,*range(h+1,3)):
        yield h,5,mode,B
if __name__=='__main__':
 for H in charts():
    M=Model(*H);z=M.do([],4000);print(H,z,M.witness()if z else '',flush=True)
