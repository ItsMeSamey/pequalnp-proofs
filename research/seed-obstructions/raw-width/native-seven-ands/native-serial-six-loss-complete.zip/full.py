from screen import *
def run(ix,ex,limit,control=0):
 t=atoms[13+ix]
 terms=[(a,sum(nbr[a])) for a in atoms[13:] if a!=t]
 base={0,129,4160,*atoms}
 for v,w in terms:
  s=w
  while s:base.add(s);s=(s-1)&w
 base=sorted(base)
 f=CNF(); extra=[]
 drops={e:f.new() for e in P if not e&t}
 f.cl.extend(CardEnc.equals(list(drops.values()),2,vpool=f.pool,encoding=EncType.seqcounter).clauses)
 for j in range(ex):
  r,s=[f.choose(base,extra) for _ in range(2)]
  extra.append([f.OR(a,b) for a,b in zip(r,s)])
 arms=[f.choose(base,extra) for _ in range(4)]
 kh=[f.new(),f.new()];f.cl.append(kh)
 taps=[[[f.new(),f.new()]for j in range(2)]for i in terms]
 for j in range(2):
  f.cl.append([taps[i][a][j]for i in range(6)for a in range(2)])
 for i in range(6):
  for j in range(2):f.cl.append([-taps[i][0][j],-taps[i][1][j]])
 # Both exposed gates have only one first nonempty merge apiece.
 for j in range(2):
  anchor=[f.new()for _ in atoms];f.cl.append(anchor)
  for i,(v,w) in enumerate(terms):
   for d,r in enumerate((v,w)):
    for a,sel in zip(atoms,anchor):
     if not r&a:f.cl.append([-sel,-taps[i][d][j]])
     elif d:f.cl.append([-sel,-taps[i][d][j],-drops[v|a]])
  if j==0:
   for arm,uses in zip(arms[2:],kh):
    nonzero=f.OR(*arm)
    for bit,sel in zip(arm,anchor):f.cl.append([-sel,-uses,-nonzero,bit])
 for a in atoms[13:]:
  r=[arm[atoms.index(a)]for arm in arms]
  f.cl.append([-r[0],-r[1]])
  ht=f.OR(r[0],r[1]);kt=f.OR(r[2],r[3])
  if a!=t:f.cl.append([-ht,-kt])
  else:f.cl.append([ht,kt])
  k=f.AND(r[2],r[3])
  count=[ht,kt]
  for (v,w),tap in zip(terms,taps):
   if v==a:count.append(f.one)
   else:count.append(f.AND(k,f.OR(tap[0][1],tap[1][1])))
  f.atmost(count,2)
 def evaluate(row):
  a,b,c,d=[f.OR(*[arm[i]for i,v in enumerate(atoms)if row&v])for arm in arms]
  h=f.AND(a,b);k=f.AND(f.OR(c,f.AND(h,kh[0])),f.OR(d,f.AND(h,kh[1])))
  out=[]
  for (x,y),s in zip(terms,taps):
   vals=[f.OR((f.c(bool(row&z)) if z==x else f.OR(*[-drops[x|v] for v in bm(y&row)])),f.AND(h,dh),f.AND(k,dk)) for z,(dh,dk) in zip((x,y),s)]
   out.append(f.AND(*vals))
  return h,k,out
 neg=[evaluate(n)for n in N]
 for _,_,out in neg:
  for z in out:f.cl.append([-z])
 for i in range(2):f.cl.append([v[i]for v in neg])
 for e in P:
  if not control: f.cl.append(evaluate(e)[2])
 with Solver(name='cadical195',bootstrap_with=f.cl) as sol:
  sol.conf_budget(limit)
  ans=sol.solve_limited()
  print(ix,ex,ans,sol.accum_stats()['conflicts'], flush=True)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
