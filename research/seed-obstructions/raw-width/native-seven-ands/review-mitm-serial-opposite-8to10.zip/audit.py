from pathlib import Path
from zipfile import ZipFile
import json
from functools import lru_cache
base=Path(__file__).resolve().parent
S=Path('/workspace/scratch')
orig=S/'syn_mitm/serial-cross'
def rows(path):
 return [tuple(map(int,l.split())) for l in path.read_text().splitlines()]
def folder(x):return base/('native-serial-opposite-'+x)
t,h,rev,star,ten=[folder(v)for v in ('two-genuine','H-genuine','CD-genuine89','two-stars','CD-genuine10')]
with ZipFile(S/'syn_pruning/native-serial-genuine-hall.zip') as z:
 orig_hall={tuple(map(int,s.split()[1:7]))for s in z.read('hallF0.log').decode().splitlines()if s.startswith('pass ')}
 assert orig_hall==set(rows(t/'hall179')) and len(orig_hall)==179
assert all((p/'native.in').read_bytes()==(S/'syn_verify/serial-global/native.in').read_bytes()for p in (t,h,rev,star,ten))
with ZipFile(S/'syn_pruning/native-serial-genuine-traces.zip')as z:
 assert all((q/'any.first').read_bytes()==(base/'traces'/'any.first').read_bytes()for q in (h,rev,ten));assert len(rows(h/'any.first'))==366
data=rows(t/'native.in')[1:];P=[a|b<<13 for a,b in data[:28]];N=[a|b<<13 for a,b in data[28:]]
syms=json.loads((star/'permutations.json').read_text())
for s in syms:
 masks=s['point']+[j<<13 for j in s['tag']]
 assert len(set(masks))==20 and all(x.bit_count()==1 for x in masks)
 def tr(v):return sum(q for i,q in enumerate(masks)if v>>i&1)
 assert {tr(v)for v in P}==set(P) and {tr(v)for v in N}==set(N)
assert len(syms)==24
@lru_cache(None)
def val(w,neg):return sum(1<<i for i,r in enumerate(N if neg else P)if r&w)
@lru_cache(None)
def signature(a,b):
 n=val(a,1)&val(b,1);u=sum(1<<j for j in range(20)if not n&val(1<<j,1))
 mask=val(a,0)&val(b,0)&val(u,0)
 return n,u,mask,any(not mask&~val(1<<j,0)for j in range(20))
def scan(key,flags,needdirty=True):
 a,b,c,d,m,L=key
 assert m==1 and 8<=L.bit_count()<=10
 hn,u,x,hs=signature(a,b);cn,v,y,cs=signature(c,d)
 assert hn and (cn or not needdirty) and not (d&~u) and not L&~(x|y) and (hs,cs)==flags
 return cn
def hall(path,prefix,source,out,n):
 keys=rows(source);assert len(keys)==n and len(set(keys))==n
 passes=[]
 for i in range(0,n,500):
  lines=(path/f'{prefix}-{i+1}.log').read_text().splitlines()
  chunk=set(keys[i:i+500]);seen=set()
  for line in lines[:-1]:
   z=line.split();assert z[0]=='pass' and z[-1]==z[-2]
   k=tuple(map(int,z[1:7]));assert k in chunk and k not in seen;seen.add(k)
  assert lines[-1]==f'total {len(chunk)} pass {len(seen)}';passes+=sorted(seen)
 if out:assert set(passes)==set(rows(path/out))
 else:assert not passes
 print(prefix,n,len(passes))
hall(h,'vt',orig/'veto-actual','vt178',17292)
hall(star,'th',orig/'twostar-actual.orbits','twohall',5982)
hall(rev,'rh',orig/'revactual',None,14854)
def sat(path,prefix,expected):
 found={};block=0
 for f in path.glob(prefix+'-*.log'):
  for s in f.read_text().splitlines():
   a,i,L,verdict,b,p=s.split();k=int(i),int(L);assert a=='result' and k not in found and verdict=='False' and p=='0'
   found[k]=True;block+=int(b)
 assert set(found)==expected
 return block
rr=rows(t/'safe36')
assert set(rr)=={k for k in orig_hall if k[4]==1 and not signature(k[0],k[1])[0]&val(k[3],1)}
ob={(i,z)for i,r in enumerate(rr)for z in [r[-1],*[r[-1]^1<<j for j in range(28)if r[-1]>>j&1]]}
assert len(ob)==360 and all(scan(r,(False,False))for r in rr)
for p in ('sol','g'):assert sat(t,p,ob)==128
dd=rows(h/'vtdirty');assert set(dd)=={r for r in rows(h/'vt178')if signature(r[2],r[3])[0]}
for path,dataset,flags,prefixes in [(h,dd,(False,True),('vp','vg')),(star,rows(star/'twohall'),(True,True),('tp','tg'))]:
 assert all(scan(r,flags)for r in dataset)
 for pref in prefixes:print(pref,len(dataset),sat(path,pref,{(i,r[-1])for i,r in enumerate(dataset)}))
assert all(scan(r,(True,False)) for r in rows(ten/'rev10'))
print('F0 179 -> 36, 360 SAT rejections per solver. 24 original permutations preserve 28 positives and 468 negatives. Reverse10 48.')
