from audit import *
for n,filename,flags,need in [(17292,'veto-actual',(False,True),False),(14854,'revactual',(True,False),True),(125850,'twostar-actual',(True,True),True)]:
 cases=rows(orig/filename)
 assert len(set(cases))==len(cases)==n
 for row in cases:
  scan(row,flags,need)
  a,b,c,d,mode,L=row;hn,u,x,hs=signature(a,b);cn,v,y,cs=signature(c,d)
  assert val(d,1)&val(v,1)
  if hs:assert val(a,1)&val(u,1) and val(b,1)&val(u,1)
 print(filename,n,'signed shapes and enlargement-veto witnesses verified')
