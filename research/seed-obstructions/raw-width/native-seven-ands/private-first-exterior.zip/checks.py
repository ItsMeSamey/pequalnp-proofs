from nativecontrol import edges,rows
from itertools import permutations
P=(2,4,8,32);T=tuple(1<<j for j in range(7));X=tuple(1<<j for j in range(13))
U={t:{x for x,u in edges if u==t}for t in T};N={p|(t<<13)for p,t,y in rows if y<0}
Q={t:next(x for x in U[t] if sum(x in u for u in U.values())==1)for t in P}
def neg(m):return any(not(m&~n)for n in N)
for u,v in permutations(P,2):
    assert len(U[u]&U[v])==1 and not (U[u]&U[v])&set(Q.values())
    for p in X:
        if p not in U[v]:assert neg(Q[u]|p|(v<<13))
    for t in T:
        if t!=u:assert neg(Q[u]|((v|t)<<13))
print('12 ordered private pairs checked, each unique common point is nonprivate')
