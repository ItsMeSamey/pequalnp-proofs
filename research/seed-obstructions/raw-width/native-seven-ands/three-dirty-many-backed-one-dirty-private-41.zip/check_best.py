"""Evaluate the displayed physical circuit directly from its gate list."""
import json
from itertools import combinations, permutations
from pathlib import Path
from nativecontrol import rows, edges

d=json.loads(Path(__file__).with_name('best.json').read_text())
gates=d['gates'];ands=d['and_wires'];o=d['output']
assert len(gates)==d['area']==41 and sum(op=='and'for op,l,r in gates)==8
for j,(op,l,r)in enumerate(gates,22):
    assert op in ('and','or') and 0<=l<j and 0<=r<j and not ({20,21}&{l,r})
def eval(p,t):
    x=[(p|t<<13)>>i&1 for i in range(20)]+[0,0]
    for op,a,b in gates:x.append((x[a]&x[b])if op=='and'else(x[a]|x[b]))
    hot={j for j,g in enumerate(ands)if x[gates[g-22][1]] or x[gates[g-22][2]]}
    return x,hot
dirt=set()
for p,t,s in rows:
    x,_=eval(p,t)
    if s:assert x[o]==(s==1)
    if s<0:dirt.update(j for j,g in enumerate(ands)if x[g])
assert dirt=={0,1,2}
tags=(1,2,4,8,16,32,64);priv=(2,4,8,32);ordinary=(1,16,64)
for i,t in enumerate(priv):
    p,=[p for p,v in edges if v==t and sum(x==p for x,j in edges)==1]
    g=[0,5,6,7][i]
    assert eval(p,0)[1]=={g}
    assert eval(0,t)[1]==({g,2} if i<3 else {g})
assert all(len(eval(0,t)[1])<=2 and not any(eval(0,t)[0][g] for g in ands)for t in tags)
assert all(len(eval(0,t|v)[1])<=3 for t,v in combinations(tags,2))
assert any(all(g in eval(0,t)[1]for g,t in zip(gs,ordinary))for gs in permutations((1,2,3,4),3))
for t in tags:
    assert any(eval(0,t)[0][wire] and all(not eval(0,v)[0][wire]for v in tags if v!=t)for a in ands for wire in gates[a-22][1:])
assert all(a not in ands[3:] and b not in ands[3:]for j,(op,a,b)in enumerate(gates,22)if op=='and')
true=[{1<<i}for i in range(20)]+[set(),set()]
for op,a,b in gates:
    m=true[a]|true[b] if op=='or' else {s|t for s in true[a] for t in true[b]}
    true.append({s for s in m if not any(t!=s and t&~s==0 for t in m)})
assert true[o]=={p|t<<13 for p,t in edges}
print('41 raw-only binary gates, 8 ANDs, all 676 signed-index rows and all 28 minimal incidence terms checked')
