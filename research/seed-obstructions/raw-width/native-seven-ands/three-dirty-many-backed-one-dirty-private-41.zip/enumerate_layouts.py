from pathlib import Path
import json
from model import Model,charts
def layout_mask(M,w):
    return [[sum(1<<i for i,x in enumerate(M.keys[g,s]) if x in w[g][s])for s in (0,1)]for g in range(M.n)]
def block(M,w):
    return [(-1 if x in w[g][s] else 1)*M.term(g,s,x)for g in range(M.n)for s in (0,1)for x in M.keys[g,s]]
if __name__=='__main__':
    chart=(0,3,'shared',2);M=Model(*chart);rows=[]
    while len(rows)<20000:
        z=M.do([],20000)
        if z is not True:break
        w=M.witness();rows.append(layout_mask(M,w));M.sat.add_clause(block(M,w))
        if len(rows)%500==0:print('progress',len(rows),flush=True)
    print('termination',len(rows),z,flush=True)
    if z is False:Path('layouts.json').write_text(json.dumps(sorted(rows),separators=(',',':')))
