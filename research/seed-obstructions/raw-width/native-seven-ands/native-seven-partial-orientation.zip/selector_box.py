from collections import defaultdict
from itertools import product
from pathlib import Path

def load(path):
    rows = [tuple(map(int,s.split())) for s in Path(path).read_text().splitlines()]
    np,nn = rows[0]
    assert np+nn+1==len(rows)
    stars=[0]*13
    for p,t in rows[1:np+1]: stars[p.bit_length()-1]|=t
    classes=defaultdict(list)
    for p,t in rows[np+1:]:
        hi=lo=127
        for i,s in enumerate(stars):
            if p>>i&1: hi &= ~s
            if not t&s: lo &= ~s
        if lo==hi: classes[lo].append(p | (t<<13))
    assert len(classes)==69
    return stars,classes

def bounds(classes,gates):
    counts={}
    for bits in product(range(2),repeat=len(gates)):
        count=0
        for samples in classes.values():
            for n in samples:
                if all(a==b or not (b if side else a)
                       for (a,b),side in zip((g(n) for g in gates),bits)):
                    count+=1
                    break
        counts[bits]=count
    return counts

if __name__=='__main__':
    stars,classes=load(Path(__file__).with_name('native.in'))
    gates=[]
    for t in range(7):
        pm=sum(1<<p for p,s in enumerate(stars) if s>>t&1)
        gates.append(lambda n,p=pm,k=13+t:(bool(n&p), bool(n>>k&1)))
    for j in range(8):
        v=bounds(classes,gates[:j]).values()
        print(j,min(v),max(v),2**(7-j))
        assert max(v)<=2**(7-j)
    assert list(bounds(classes,[lambda n:(bool(n&1),bool(n&1))]).values())==[69,69]
