from pathlib import Path
from sample import samples
w,seed,target=samples(Path('L-meta-18968.json'))
P=sorted({(r&8191,r>>13&127) for j,r in enumerate(w) if (target&~seed)>>j&1})
N=sorted({(r&8191,r>>13&127) for j,r in enumerate(w) if not(target>>j&1)})
assert len(P)==28
print(len(P),len(N))
for p,t in P+N:print(p,t)
