from itertools import combinations,permutations,product
from pysat.formula import IDPool
from pysat.solvers import Cadical195
from nativecontrol import rows
Ps={p|(t<<13) for p,t,s in rows if s==1}
Ns={p|(t<<13) for p,t,s in rows if s==-1}
priv=(2,8,16,32)
own=(32,2,4,8)
ordt=(1,16,64)
class Coupled:
 def __init__(self,h):
  q=priv[h];u=own[h];atoms=(1,4,64,*[t<<13 for t in ordt],q,u<<13)
  def native(r):return sum(x for j,x in enumerate(atoms)if r>>j&1)
  can=lambda r:any(r&~n==0 for n in Ns)
  pos=[r for r in range(256)if native(r)in Ps]
  neg=[r for r in range(256) if can(native(r)) and all(can(native(r)|(v<<13)) for v in own if v!=u)]
  assert len(pos)==7
  singleton=[1<<i for i in range(8)]
  assert set(singleton)<=set(neg)
  # Only keep maximal required negatives but model all singleton and all pair probes.
  neg=[n for n in neg if not any(n!=z and n&~z==0 for z in neg)]
  samples=sorted(set(pos+neg+singleton+[24,40,48]))
  pool=IDPool();v=self.v=lambda *x:pool.id(x);cla=[]
  def And(y,L):cla.append([y]+[-p for p in L]);cla.extend([-y,p] for p in L)
  def Or(y,L):cla.append([-y]+L);cla.extend([y,-p]for p in L)
  for r in samples:
   signals=[]
   for g in range(6):
    arms=[]
    for s in range(1 if g==5 else 2):
     terms=[v('src',g,s,i) for i in range(8) if r>>i&1]
     for j,y in enumerate(signals):
      z=v('gated',r,g,s,j);And(z,[v('src',g,s,8+j),y]);terms.append(z)
     a=v('arm',g,s,r);Or(a,terms);arms.append(a)
    if g<5:
     sig=v('and',g,r);And(sig,arms);signals.append(sig)
    elif r in pos+neg:cla.append([arms[0] if r in pos else -arms[0]])
   if r in [24,40,48]:
    hot=[]
    for g in range(5):
     z=v('hot',g,r);Or(z,[v('arm',g,0,r),v('arm',g,1,r)]);hot.append(z)
    for xx in combinations(hot,4):cla.append([-b for b in xx])
  self.s=Cadical195(bootstrap_with=cla);self.pos=pos;self.neg=neg
 def one(self,order,c,backup):
  # V0..2 matched exterior, V3 spare, V4 private. Own backup by site,
  # unique own arm is tag-pure, necessarily opposite ordinary if matched.
  gg=[]
  for name in order:
   if name==4: pair=(1<<6,(c<<3)|(1<<7))
   elif name<3:pair=((1<<7) if name==backup else 0,8<<name)
   else:pair=((1<<7) if name==backup else 0,0)
   gg.append(pair)
  tests=[self.v('arm',g,s,1<<i)*(1 if m>>i&1 else -1) for g,pair in enumerate(gg)for s,m in enumerate(pair)for i in (3,4,5,6,7)]
  # J q-facing arm dark at the three ordinary points, hence in any absent host's cut too.
  for j in range(3):tests.append(-self.v('arm',order.index(4),0,1<<j))
  if not self.s.solve(assumptions=tests):return
  yes=set(self.s.get_model());w=[[sum(1<<i for i in range(8+g)if self.v('src',g,s,i) in yes) for s in range(1 if g==5 else 2)] for g in range(6)]
  def seen(r):
   vals=r;R=[]
   for g,pp in enumerate(w):
    x=[bool(vals&m) for m in pp];R.append(x)
    if g<5 and all(x):vals|=1<<(8+g)
   return R
  for r in self.pos+self.neg:assert seen(r)[-1][0]==(r in self.pos)
  for g,pair in enumerate(gg):
   for s,m in enumerate(pair):
    for i in (3,4,5,6,7):assert seen(1<<i)[g][s]==bool(m>>i&1)
  return w

if __name__=='__main__':
 for h in range(4):
  M=Coupled(h);print('chart',h,'negatives',M.neg,flush=True)
  for c in range(1,8):
   for b in range(4):
    if b<3 and c.bit_count()>=2 and c>>b&1:continue
    for order in permutations(range(5)):
     w=M.one(order,c,b)
     if w:
      print('SAT',h,c,b,order,w,flush=True);break
    else:print('UNSAT',h,c,b,flush=True)
