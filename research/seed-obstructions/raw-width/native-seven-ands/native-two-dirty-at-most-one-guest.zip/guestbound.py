from coupled import *
from itertools import combinations,combinations_with_replacement
def pts(t):return sum(e&8191 for e in Ps if e&(t<<13))
count=0
for q,u in zip(priv,own):
 Gs=[1<<j for j in range(7)if 1<<j!=u]
 U=pts(u)
 for g in Gs:
  P0=pts(g)&~U
  Np=[n for n in Ns if n&P0]
  for i,j in combinations_with_replacement(range(20),2):
   r=1<<i|1<<j
   if not(r&(g<<13)) and any(r&~n==0 for n in Ns):assert any(r&~n==0 for n in Np)
  for h in Gs:
   if g==h:continue
   assert any(n&q and n&(h<<13) and n&P0 for n in Ns)
   comp=(1<<20)-1
   for n in Np:
    if n&q and n&(h<<13):comp&=~n
   assert not comp&~(pts(h)|((u|g)<<13)),(q,g,h,comp)
   count+=1
print('ordered guest/other-guest directions',count)
