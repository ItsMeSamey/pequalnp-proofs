from coupled import *
from itertools import permutations
Psets={1<<j:sum(e&8191 for e in Ps if e&(1<<(13+j))) for j in range(7)}
cnt=0
for q,u in zip(priv,own):
 U=Psets[u]
 for a,b in permutations([t for t in Psets if t!=u],2):
  A=Psets[a];B=Psets[b];w=A&B
  assert w.bit_count()==1
  assert len([e for e in Ps if e&w])<=3
  for g in (a,b):
   pp=Psets[g]&~U
   assert pp.bit_count()==3 and (Psets[g]&U).bit_count()==1 and not(Psets[g]&U&sum(priv))
   for j in range(13):assert any(n&(1<<j) and n&pp for n in Ns)
   for t in Psets:
    if t!=g:assert any(n&(t<<13) and n&pp for n in Ns)
  assert any(n&q and n&(b<<13) and n&(A&~U) for n in Ns)
  assert any(n&q and n&(a<<13) and n&(B&~U) for n in Ns)
  if a not in ordt or b not in ordt:assert w not in (1,4,64)
  cnt+=1
print('asymmetric last cases and guest-retie witnesses',cnt)
