import NativeTable

namespace ThresholdStarWindow

set_option maxRecDepth 64000
set_option maxHeartbeats 0

def tagOf (r : Nat × Nat) : Fin 7 := ⟨(r.2.log2 - 13) % 7, Nat.mod_lt _ (by decide)⟩
def tagAt (n : Nat) (t : Fin 7) : Bool := n.testBit (13+t.val)
def retained (u : Nat) := 8191 ||| (u <<< 13)

def colorRowCheck (j : Nat) : Bool :=
  (List.range 69).all fun k => (j == k) || goodRows.any fun r =>
    ((r.2 &&& (badRows[j]!.2 ||| badRows[k]!.2)) == r.2) &&
    (tagAt badRows[j]!.2 (tagOf r) != tagAt badRows[k]!.2 (tagOf r))

def keptCheck (u : Nat) : Bool := goodRows.all fun r =>
  !(u.testBit (tagOf r).val) || ((r.2 &&& retained u) == r.2)
private theorem colorRowCheck_0 : (List.range' 0 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_2 : (List.range' 2 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_4 : (List.range' 4 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_6 : (List.range' 6 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_8 : (List.range' 8 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_10 : (List.range' 10 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_12 : (List.range' 12 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_14 : (List.range' 14 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_16 : (List.range' 16 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_18 : (List.range' 18 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_20 : (List.range' 20 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_22 : (List.range' 22 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_24 : (List.range' 24 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_26 : (List.range' 26 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_28 : (List.range' 28 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_30 : (List.range' 30 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_32 : (List.range' 32 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_34 : (List.range' 34 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_36 : (List.range' 36 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_38 : (List.range' 38 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_40 : (List.range' 40 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_42 : (List.range' 42 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_44 : (List.range' 44 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_46 : (List.range' 46 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_48 : (List.range' 48 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_50 : (List.range' 50 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_52 : (List.range' 52 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_54 : (List.range' 54 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_56 : (List.range' 56 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_58 : (List.range' 58 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_60 : (List.range' 60 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_62 : (List.range' 62 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_64 : (List.range' 64 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_66 : (List.range' 66 2).all colorRowCheck = true := by decide +kernel
private theorem colorRowCheck_68 : (List.range' 68 1).all colorRowCheck = true := by decide +kernel

theorem colorRowCheck_ok (j : Nat) (hj : j < 69) : colorRowCheck j = true := by
  by_cases h0 : j < 2
  · exact List.all_eq_true.mp colorRowCheck_0 j (by simp only [List.mem_range'_1]; omega)
  by_cases h2 : j < 4
  · exact List.all_eq_true.mp colorRowCheck_2 j (by simp only [List.mem_range'_1]; omega)
  by_cases h4 : j < 6
  · exact List.all_eq_true.mp colorRowCheck_4 j (by simp only [List.mem_range'_1]; omega)
  by_cases h6 : j < 8
  · exact List.all_eq_true.mp colorRowCheck_6 j (by simp only [List.mem_range'_1]; omega)
  by_cases h8 : j < 10
  · exact List.all_eq_true.mp colorRowCheck_8 j (by simp only [List.mem_range'_1]; omega)
  by_cases h10 : j < 12
  · exact List.all_eq_true.mp colorRowCheck_10 j (by simp only [List.mem_range'_1]; omega)
  by_cases h12 : j < 14
  · exact List.all_eq_true.mp colorRowCheck_12 j (by simp only [List.mem_range'_1]; omega)
  by_cases h14 : j < 16
  · exact List.all_eq_true.mp colorRowCheck_14 j (by simp only [List.mem_range'_1]; omega)
  by_cases h16 : j < 18
  · exact List.all_eq_true.mp colorRowCheck_16 j (by simp only [List.mem_range'_1]; omega)
  by_cases h18 : j < 20
  · exact List.all_eq_true.mp colorRowCheck_18 j (by simp only [List.mem_range'_1]; omega)
  by_cases h20 : j < 22
  · exact List.all_eq_true.mp colorRowCheck_20 j (by simp only [List.mem_range'_1]; omega)
  by_cases h22 : j < 24
  · exact List.all_eq_true.mp colorRowCheck_22 j (by simp only [List.mem_range'_1]; omega)
  by_cases h24 : j < 26
  · exact List.all_eq_true.mp colorRowCheck_24 j (by simp only [List.mem_range'_1]; omega)
  by_cases h26 : j < 28
  · exact List.all_eq_true.mp colorRowCheck_26 j (by simp only [List.mem_range'_1]; omega)
  by_cases h28 : j < 30
  · exact List.all_eq_true.mp colorRowCheck_28 j (by simp only [List.mem_range'_1]; omega)
  by_cases h30 : j < 32
  · exact List.all_eq_true.mp colorRowCheck_30 j (by simp only [List.mem_range'_1]; omega)
  by_cases h32 : j < 34
  · exact List.all_eq_true.mp colorRowCheck_32 j (by simp only [List.mem_range'_1]; omega)
  by_cases h34 : j < 36
  · exact List.all_eq_true.mp colorRowCheck_34 j (by simp only [List.mem_range'_1]; omega)
  by_cases h36 : j < 38
  · exact List.all_eq_true.mp colorRowCheck_36 j (by simp only [List.mem_range'_1]; omega)
  by_cases h38 : j < 40
  · exact List.all_eq_true.mp colorRowCheck_38 j (by simp only [List.mem_range'_1]; omega)
  by_cases h40 : j < 42
  · exact List.all_eq_true.mp colorRowCheck_40 j (by simp only [List.mem_range'_1]; omega)
  by_cases h42 : j < 44
  · exact List.all_eq_true.mp colorRowCheck_42 j (by simp only [List.mem_range'_1]; omega)
  by_cases h44 : j < 46
  · exact List.all_eq_true.mp colorRowCheck_44 j (by simp only [List.mem_range'_1]; omega)
  by_cases h46 : j < 48
  · exact List.all_eq_true.mp colorRowCheck_46 j (by simp only [List.mem_range'_1]; omega)
  by_cases h48 : j < 50
  · exact List.all_eq_true.mp colorRowCheck_48 j (by simp only [List.mem_range'_1]; omega)
  by_cases h50 : j < 52
  · exact List.all_eq_true.mp colorRowCheck_50 j (by simp only [List.mem_range'_1]; omega)
  by_cases h52 : j < 54
  · exact List.all_eq_true.mp colorRowCheck_52 j (by simp only [List.mem_range'_1]; omega)
  by_cases h54 : j < 56
  · exact List.all_eq_true.mp colorRowCheck_54 j (by simp only [List.mem_range'_1]; omega)
  by_cases h56 : j < 58
  · exact List.all_eq_true.mp colorRowCheck_56 j (by simp only [List.mem_range'_1]; omega)
  by_cases h58 : j < 60
  · exact List.all_eq_true.mp colorRowCheck_58 j (by simp only [List.mem_range'_1]; omega)
  by_cases h60 : j < 62
  · exact List.all_eq_true.mp colorRowCheck_60 j (by simp only [List.mem_range'_1]; omega)
  by_cases h62 : j < 64
  · exact List.all_eq_true.mp colorRowCheck_62 j (by simp only [List.mem_range'_1]; omega)
  by_cases h64 : j < 66
  · exact List.all_eq_true.mp colorRowCheck_64 j (by simp only [List.mem_range'_1]; omega)
  by_cases h66 : j < 68
  · exact List.all_eq_true.mp colorRowCheck_66 j (by simp only [List.mem_range'_1]; omega)
  exact List.all_eq_true.mp colorRowCheck_68 j (by simp only [List.mem_range'_1]; omega)

private theorem keptCheck_0 : (List.range' 0 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_8 : (List.range' 8 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_16 : (List.range' 16 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_24 : (List.range' 24 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_32 : (List.range' 32 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_40 : (List.range' 40 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_48 : (List.range' 48 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_56 : (List.range' 56 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_64 : (List.range' 64 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_72 : (List.range' 72 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_80 : (List.range' 80 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_88 : (List.range' 88 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_96 : (List.range' 96 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_104 : (List.range' 104 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_112 : (List.range' 112 8).all keptCheck = true := by decide +kernel
private theorem keptCheck_120 : (List.range' 120 8).all keptCheck = true := by decide +kernel

theorem keptCheck_ok (j : Nat) (hj : j < 128) : keptCheck j = true := by
  by_cases h0 : j < 8
  · exact List.all_eq_true.mp keptCheck_0 j (by simp only [List.mem_range'_1]; omega)
  by_cases h8 : j < 16
  · exact List.all_eq_true.mp keptCheck_8 j (by simp only [List.mem_range'_1]; omega)
  by_cases h16 : j < 24
  · exact List.all_eq_true.mp keptCheck_16 j (by simp only [List.mem_range'_1]; omega)
  by_cases h24 : j < 32
  · exact List.all_eq_true.mp keptCheck_24 j (by simp only [List.mem_range'_1]; omega)
  by_cases h32 : j < 40
  · exact List.all_eq_true.mp keptCheck_32 j (by simp only [List.mem_range'_1]; omega)
  by_cases h40 : j < 48
  · exact List.all_eq_true.mp keptCheck_40 j (by simp only [List.mem_range'_1]; omega)
  by_cases h48 : j < 56
  · exact List.all_eq_true.mp keptCheck_48 j (by simp only [List.mem_range'_1]; omega)
  by_cases h56 : j < 64
  · exact List.all_eq_true.mp keptCheck_56 j (by simp only [List.mem_range'_1]; omega)
  by_cases h64 : j < 72
  · exact List.all_eq_true.mp keptCheck_64 j (by simp only [List.mem_range'_1]; omega)
  by_cases h72 : j < 80
  · exact List.all_eq_true.mp keptCheck_72 j (by simp only [List.mem_range'_1]; omega)
  by_cases h80 : j < 88
  · exact List.all_eq_true.mp keptCheck_80 j (by simp only [List.mem_range'_1]; omega)
  by_cases h88 : j < 96
  · exact List.all_eq_true.mp keptCheck_88 j (by simp only [List.mem_range'_1]; omega)
  by_cases h96 : j < 104
  · exact List.all_eq_true.mp keptCheck_96 j (by simp only [List.mem_range'_1]; omega)
  by_cases h104 : j < 112
  · exact List.all_eq_true.mp keptCheck_104 j (by simp only [List.mem_range'_1]; omega)
  by_cases h112 : j < 120
  · exact List.all_eq_true.mp keptCheck_112 j (by simp only [List.mem_range'_1]; omega)
  exact List.all_eq_true.mp keptCheck_120 j (by simp only [List.mem_range'_1]; omega)


theorem colorClash (j k : Fin 69) (ne : j ≠ k) :
    ∃ r ∈ goodRows, r.2 &&& ((bad j).2 ||| (bad k).2) = r.2 ∧
      tagAt (bad j).2 (tagOf r) ≠ tagAt (bad k).2 (tagOf r) := by
  have d : j.val ≠ k.val := fun h => ne (Fin.ext h)
  have h := List.all_eq_true.mp (colorRowCheck_ok j.val j.isLt) k.val (List.mem_range.mpr k.isLt)
  have e : (j.val == k.val) = false := by simpa using d
  rw [e, Bool.false_or] at h
  obtain ⟨r, hr, hit⟩ := List.any_eq_true.mp h
  refine ⟨r, hr, ?_⟩
  simpa [bad] using hit

theorem keptGood (u : Fin 128) {r : Nat × Nat} (hr : r ∈ goodRows)
    (keep : u.val.testBit (tagOf r).val = true) : r.2 &&& retained u.val = r.2 := by
  have h := List.all_eq_true.mp (keptCheck_ok u.val u.isLt) r hr
  simpa [keep] using h

end ThresholdStarWindow
#print axioms ThresholdStarWindow.colorClash
