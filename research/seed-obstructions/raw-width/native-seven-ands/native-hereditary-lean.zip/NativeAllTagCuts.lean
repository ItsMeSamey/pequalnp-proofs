import NativeSelector
import NativeProjectionData
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

namespace ThresholdStarWindow

open Research.Graph9822Resolution
open scoped BigOperators

def activeTags (u : Fin 128) : Finset (Fin 7) :=
  Finset.univ.filter fun t => u.val.testBit t.val = true

/-- On every tag subset, separating retained positives from all restricted negatives
takes at least one physical AND per retained tag. Point compounds may be arbitrary ORs. -/
theorem native_all_tag_cuts (u : Fin 128) (gs : List Gate) (start out : Nat)
    (raw : Nat → List Nat) (bias : Wire)
    (pos : ∀ r, positiveRow r = true → nativeMask r &&& retained u.val = nativeMask r →
      eval gs start (bankWire raw bias (nativeMask r)) out = true)
    (neg : ∀ r, negativeRow r = true →
      eval gs start (bankWire raw bias (nativeMask r &&& retained u.val)) out = false) :
    (activeTags u).card ≤ andCount gs := by
  classical
  let holes := (activeTags u)ᶜ
  let Color := ↥holes → Bool
  let col (j : Fin 69) : Color := fun t => tagAt (bad j).2 t.val
  let fiber (c : Color) : Finset (Fin 69) := Finset.univ.filter fun j => col j = c
  have one (c : Color) : (fiber c).card ≤ 2 ^ andCount gs := by
    let e := (Fintype.equivFin ↥(fiber c)).symm
    have ok : Fintype.card ↥(fiber c) ≤ 2 ^ andCount gs := by
      apply selector_capacity gs start out raw bias (fun j => (bad (e j).val).2 &&& retained u.val)
      · intro j
        obtain ⟨hn, hm⟩ := badRows_native (e j).val
        rw [← hm]
        exact neg _ hn
      · intro j k ne
        have distinct : (e j).val ≠ (e k).val := fun h => ne (e.injective (Subtype.ext h))
        obtain ⟨r, hr, dominates, differs⟩ := colorClash _ _ distinct
        have hj : col (e j).val = c := (Finset.mem_filter.mp (e j).property).2
        have hk : col (e k).val = c := (Finset.mem_filter.mp (e k).property).2
        have present : u.val.testBit (tagOf r).val = true := by
          cases h : u.val.testBit (tagOf r).val with
          | true => rfl
          | false =>
            have ht : tagOf r ∈ holes := by simp [holes, activeTags, h]
            exact False.elim (differs (congrFun (hj.trans hk.symm) ⟨tagOf r, ht⟩))
        have kept := keptGood u hr present
        have source := List.all_eq_true.mp goodRows_native r hr
        simp only [goodCheck, Bool.and_eq_true, beq_iff_eq] at source
        refine ⟨r.2, ?_, ?_⟩
        · rw [← Nat.and_or_distrib_right, ← Nat.and_assoc, dominates, kept]
        · rw [← source.2]
          exact pos _ source.1 (by simpa only [source.2] using kept)
    simpa using ok
  have bound : 69 ≤ 2 ^ (holes.card + andCount gs) := by
    calc
      69 = (Finset.univ : Finset (Fin 69)).card := by simp
      _ = ∑ c : Color, (fiber c).card := Finset.card_eq_sum_card_fiberwise (f := col) (by simp)
      _ ≤ ∑ _c : Color, 2 ^ andCount gs := Finset.sum_le_sum fun c _ => one c
      _ = 2 ^ (holes.card + andCount gs) := by simp [Color, Fintype.card_fun, Nat.pow_add]
  have seven : 7 ≤ holes.card + andCount gs := by
    by_contra h
    have small : holes.card + andCount gs ≤ 6 := by omega
    have ub := Nat.pow_le_pow_right (by decide : 0 < 2) small
    change 2 ^ (holes.card + andCount gs) ≤ 64 at ub
    omega
  have hc : holes.card = 7 - (activeTags u).card := by simp [holes, Finset.card_compl]
  have ha : (activeTags u).card ≤ 7 := by simpa using (activeTags u).card_le_univ
  omega

end ThresholdStarWindow
#print axioms ThresholdStarWindow.native_all_tag_cuts
