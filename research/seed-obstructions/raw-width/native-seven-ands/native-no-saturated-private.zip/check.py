from contextlib import redirect_stdout
from itertools import combinations
import io
with redirect_stdout(io.StringIO()):
    import chart_inputs as n
P=set(n.pos); N=set(n.neg)
private={q:s for q,s in n.stars.items() if s.bit_count()==1}
assert len(private)==4 and len(P)==28
for q,u in private.items():
    assert all(not(q&b)for b in [129,4160])
    assert len({p for p,t in P if t==u and p!=q})==3
    for r,v in private.items():
        if r==q:continue
        assert any(p&r and t&u for p,t in N)
        assert any(t&u and t&v for p,t in N)
for u,v in combinations({t for p,t in P},2):
    assert len({p for p,t in P if t==u}&{p for p,t in P if t==v})<=1
print('private point -> tag',private)
print('private cross pairs and tag pairs project from original negatives')
