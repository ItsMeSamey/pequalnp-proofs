from coupled import *
from itertools import combinations
def pts(t):return sum(e&8191 for e in Ps if e&(t<<13))
def allowed(feed,sockets):
    return sum(1<<j for j in range(20) if not any(n&(1<<j) and n&sockets for n in feed))
for q,u in zip(priv,own):
 U=pts(u)
 for guests in combinations(ordt,2):
  G=sum(guests);w=pts(guests[0])&pts(guests[1]);z=next(t for t in ordt if t not in guests)
  assert w.bit_count()==1 and not(w&U)
  nn=[n for n in Ns if n&q and n&(G<<13)]
  assert allowed(nn,(1<<20)-1)==(u<<13)|w
  # Exclude u independently wherever L is not H,K.
  for v in [1<<j for j in range(7)if 1<<j!=u]:
   V=pts(v)
   if v in guests:
    possible=allowed(nn,V&~U)&((v<<13)|U)
    assert possible&(v<<13) and not(possible&V)
    assert allowed(nn,v<<13)&~(u<<13)&~V==0
   elif v==z:
    assert allowed(nn,V)&~(u<<13)==(v<<13)|w
    assert allowed(nn,v<<13)&~(u<<13)==V|w
   else:
    # v's other marker must lie at H to allow dirtiness.
    n2=[n for n in Ns if n&q and n&((G|v)<<13)]
    possible=allowed(n2,V&~U)&(8191^sum(priv))
    assert not(possible&V)
   print('verified',q,u,G,v,w)
