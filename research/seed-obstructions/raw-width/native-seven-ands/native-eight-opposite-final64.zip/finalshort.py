from layouts import *
import json
from itertools import product
from common import lower,shared,free
H=1<<20;K=1<<21
def toatom(i):return 129 if i==30 else 4160 if i==29 else 1<<i
def arm(x):return reduce(or_,(toatom(i)for i in x),0)
def truth(x):return pp(x),reduce(or_,(rneg[b]for b in bm(x)),0)
def both(a,b):return a[0]&b[0],a[1]&b[1]
def feeds(A):return tuple(arm(a)for a in A)
def control(i,j):
 p,n=both(truth(i[0]),truth(i[1]));q,d=both(truth(j[0]),truth(j[1]))
 gain=p&q # add safe raw opposite each helper
 for f,g in [(p,n),(q,d)]:
  gain|=f&pp(sum(a for a in raw if not(g&rneg[a])))
 return not any(not gain&~pp(u)for u in raw[13:])
def init(h,k):
 T=[truth(a)for a in raw]+[both(*map(truth,h)),both(*map(truth,k))]
 A=range(len(T));allm=(1<<22)-1
 nbr=[sum(1<<j for j in A if not T[i][1]&T[j][1])for i in A]
 sides={allm}
 for a in nbr:sides.update([v&a for v in sides])
 @cache
 def val(a):return reduce(or_,(T[i.bit_length()-1][0]for i in bm(a)),0)
 rectangles=[]
 for a in sides:
  if a:
   b=reduce(int.__and__,(nbr[i.bit_length()-1]for i in bm(a)),allm)
   if a<=b and b:
    f=val(a)&val(b)
    if f:rectangles.append((a,b,f))
 F=set(f for a,b,f in rectangles)
 mx=tuple(sorted(a for a in F if not any(a!=b and not a&~b for b in F)))
 return val,rectangles,mx
def bodies(upper,req,val):
 s=upper
 while s:
  if not req&~val(s):yield s
  s=(s-1)&upper
def run(k,h,d):
 val,rs,mx=init(h,d);sol=allcover(mx)
 print('COVERS',k,len(sol),Counter(len(s)for s in sol),flush=True)
 for cs in sol:
  if len(cs)<6:continue
  es=[m&~reduce(or_,(n for n in cs if n!=m),0)for m in cs]
  opts=[]
  for e in es:
   R=set()
   for a,b,f in rs:
    if e&~f:continue
    for x,y in product(bodies(a,e,val),bodies(b,e,val)):
     R.add((x,y))
   opts.append(sorted(R))
  hist=Counter();weak=Counter();nd=0
  for ts in product(*opts):
   if not any((a&H and b&K)or(a&K and b&H)for a,b in ts):continue
   if reduce(or_,(val(a)&val(b)for a,b in ts),0)!=V:continue
   nd+=1
   S={x for t in ts for x in t if x.bit_count()>1}-free
   weak[lower(S,shared(S))]+=1
   S|={x for x in h+d if x.bit_count()>1}-free
   price=lower(S,shared(S))
   if price<=20:
    print('SHORT',k,sorted(S),flush=True)
   hist[price]+=1
  print('PRICE',k,nd,sorted(hist.items()),sorted(weak.items()),flush=True)
if __name__=='__main__':
 from collections import Counter
 cases=[(k,feeds(a),feeds(b))for k,a,b in json.loads(Path('p65_final64.json').read_text())]
 assert all(control(*a[1:]) for a in cases)
 print('cases',len(cases),flush=True)
 for k,h,d in cases:run(k,h,d)
