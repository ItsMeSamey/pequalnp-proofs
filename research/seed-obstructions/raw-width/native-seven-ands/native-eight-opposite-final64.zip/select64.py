import json
from pathlib import Path
a=json.loads(Path('p65_preimages.json').read_text())
ids=[int(l.split()[0])for l in open('p65_final.hits')]
assert len(ids)==len(set(ids))==64 and len(a)==68
assert json.loads(Path('p65_final64.json').read_text())==[[k,*a[k][1:]]for k in ids]
print('64 geometric survivors among 68 physical signed pairs')
