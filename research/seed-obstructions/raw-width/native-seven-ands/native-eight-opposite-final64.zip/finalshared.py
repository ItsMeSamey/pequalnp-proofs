from common import *
from ast import literal_eval
for line in open('finalshort.log'):
 if not line.startswith('SHORT '):continue
 _,i,s=line.split(maxsplit=2);R=set(literal_eval(s));S=sorted(shared(R));best=100
 for k in range(len(S)+1):
  if len(R)+k>best:break
  for C in combinations(S,k):
   M=R|set(C);best=min(best,lower(M,set()))
 print(i,best,flush=True)
