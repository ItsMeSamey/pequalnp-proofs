from opp import *
@cache
def equivalent(h):
 hp,hn=both(*map(truth,h));t=[truth(a)for a in raw];full=(1<<20)-1
 adj=[sum(1<<j for j,(y,b)in enumerate(t) if not(p&y&~hp or n&b&~hn))for p,n in t]
 cl={full}
 for g in adj:cl.update([v&g for v in cl])
 @cache
 def arms(f):
  m=f;out=[]
  while m:
   p,n=truth(m)
   if not(hp&~p or hn&~n):out.append(m)
   m=(m-1)&f
  return out
 cand=set()
 for x in cl-{0}:
  y=reduce(int.__and__,(adj[a.bit_length()-1] for a in bm(x)),full)
  if x<=y and y and both(truth(x),truth(y))==(hp,hn):
   for a,b in product(arms(x),arms(y)):
    assert both(truth(a),truth(b))==(hp,hn)
    cand.add(tuple(sorted((a,b))))
 return sorted(cand)
if __name__=='__main__':
 rows=[(k,feeds(a),feeds(b))for k,a,b in json.loads(Path('p65_models.json').read_text())]
 for k,h,d in rows:
  if control(h,d):print(k,len(equivalent(h)),len(equivalent(d)),flush=True)
