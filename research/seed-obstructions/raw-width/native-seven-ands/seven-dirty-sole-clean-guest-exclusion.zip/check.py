from itertools import permutations,product
from nativecontrol import rows,edges
tags=(1,2,4,8,16,32,64);V=(2,4,8,32);O=(1,16,64)
U={t:sum(p for p,j in edges if j==t)for t in tags}
q={t:next(p for p,j in edges if j==t and sum(bool(p&s)for s in U.values())==1)for t in V}
sx=lambda t:t<<13
N={p|sx(t) for p,t,s in rows if s<0}
atoms=sorted({p for p,t in edges if p not in q.values()})+[sx(t)for t in O]
for u,w,x in permutations(V,3):
 assert any((q[u]|sx(w|x))&~n==0 for n in N)
 assert any((q[u]|q[w]|sx(x))&~n==0 for n in N)
for u,w in permutations(V,2):
 v,z=(i for i in V if i not in (u,w))
 r=U[v]&U[z];assert r.bit_count()==1 and not r&U[u]
 assert any((q[u]|r)&~n==0 and n&U[w] for n in N)
 bad=[n for n in N if n&U[u] and (n&sx(sum(V)-w) or n&U[w])]
 good={(a,b)for a,b in product(atoms,repeat=2)if not(a==b and a>=8192) and not any((a|b)&~n==0 for n in bad)}
 pure={(p,sx(t))for p,t in edges if t in O}
 assert good==pure|{(b,a)for a,b in pure}
 print('owner',u,'clean label',w,'excluded tag-arm point',r,'allowed ordered pairs',len(good))
