from coupled import *
F=(1<<20)-1
def below(r):return any(r&~n==0 for n in Ns)
for q,u in zip(priv,own):
    U=sum(e&8191 for e in Ps if e&(u<<13))
    G=sum(ordt)
    negatives=[n for n in Ns if n&q and n&(G<<13)]
    allow=F
    for n in negatives:allow&=~n
    assert allow==u<<13
    for v in [1<<j for j in range(7) if 1<<j!=u]:
        V=sum(e&8191 for e in Ps if e&(v<<13))
        P0=V&~U
        assert P0.bit_count()==3
        guests=G|v
        Ns0=[n for n in Ns if n&q and n&(guests<<13)]
        admitted=U if v in ordt else (8191^sum(priv))
        for z in [1<<i for i in range(13) if admitted>>i&1]:
            assert any(n&z and n&P0 for n in Ns0)
        assert all(below(q|(v<<13)|(1<<i)) for i in range(13) if not(V>>i&1))
        assert all(below(q|((v|(1<<j))<<13))for j in range(7) if 1<<j!=u)
        print('verified raw site',q,u,v,P0,admitted)
