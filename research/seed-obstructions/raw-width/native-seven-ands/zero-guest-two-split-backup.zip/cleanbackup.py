from itertools import combinations
from nativecontrol import rows,edges
prv=(2,4,8,32)
stars={t:{p for p,v in edges if v==t} for _,t in edges}
qs={next(p for p in stars[u] if sum(p in U for U in stars.values())==1) for u in prv}
pts=set.union(*stars.values())-qs
atoms=sorted(pts|{t<<13 for t in (1,16,64)})
assert len(qs)==4 and len(atoms)==12
ns={p|(t<<13) for p,t,y in rows if y<0}
def dominated(m):return any(m&~n==0 for n in ns)
def escape(m,A):return all(not dominated(m|p) for p in A)
bad={sum(z) for k in (1,2,3) for z in combinations(atoms,k) if dominated(sum(z))}
assert len(rows)==676
for u in prv:
    assert not any(escape(m,stars[u]) for m in bad)
for u,v in combinations(prv,2):
    A,B=stars[u]-stars[v],stars[v]-stars[u]
    assert len(A)==len(B)==3
    X={m for m in bad if escape(m,A)};Y={m for m in bad if escape(m,B)}
    assert len(X)==len(Y)==4 and not(X&Y) and all(m.bit_count()==3 and m<8192 for m in X|Y)
    print('private pair',u,v,'sole common petal',sum(stars[u]&stars[v]),'exception counts',len(X),len(Y),len(X&Y))
for us in combinations(prv,3):assert not set.intersection(*(stars[t] for t in us))
