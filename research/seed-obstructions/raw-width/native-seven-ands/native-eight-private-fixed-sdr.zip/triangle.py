from itertools import combinations
from pysat.formula import IDPool
from pysat.solvers import Cadical195
def run(k,group,limit):
 pool=IDPool();cla=[]; v=lambda *x:pool.id(x)
 def Or(y,x):
  cla.append([-y]+x);cla.extend([y,-a] for a in x)
 def And(y,x):
  cla.append([y]+[-a for a in x]);cla.extend([-y,a] for a in x)
 P=[(1<<p)|(1<<(3+t)) for p in range(3)for t in range(3) if p!=t]
 N=[7,56]+[(1<<p)|(1<<(3+p))for p in range(3)]
 for r in sorted(set(P+N+[8,16,32])):
  sig=[]
  for g in range(k+1):
   arms=[]
   for a in range(1 if g==k else 2):
    terms=[v('sel',g,a,i)for i in range(6)if r&(1<<i)]
    for j in range(g):
     z=v('use',r,g,a,j);And(z,[v('sel',g,a,j+6),sig[j]]);terms.append(z)
    y=v('a',r,g,a);Or(y,terms);arms.append(y)
    if g<k and r in group:cla.append([-y,v('mark',g)])
   if g<k:
    z=v('g',r,g);And(z,arms);sig.append(z)
   elif r in P+N:cla.append([arms[0] if r in P else -arms[0]])
 for cc in combinations(range(k),limit+1):cla.append([-v('mark',g) for g in cc])
 with Cadical195(bootstrap_with=cla)as s:
  s.conf_budget(200000);return s.solve_limited()
for n in [1,2,3]:
 print(n,run(4, [8,16,32][:n], n-1),flush=True)
print('control',run(4,[8,16,32],3),flush=True)
