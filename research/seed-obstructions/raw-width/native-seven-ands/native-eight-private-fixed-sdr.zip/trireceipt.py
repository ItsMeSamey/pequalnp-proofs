from ports1 import P,N
A=(1,4,64); T=tuple(1<<(13+i)for i in (0,4,6))
F=tuple(1<<(13+i)for i in (1,2,3,5))
present=[(p,t)for p in A for t in T if p|t in P]
assert len(present)==6
false=[sum(A),sum(T)]+[p|t for p in A for t in T if (p,t)not in present]
assert len(false)==5
for n in false:
 ext=[next(i for i,y in enumerate(N)if not (n|u)&~y) for u in F]
 print(n,ext)
for c in (129,4160):assert (c&sum(A)).bit_count()==1
