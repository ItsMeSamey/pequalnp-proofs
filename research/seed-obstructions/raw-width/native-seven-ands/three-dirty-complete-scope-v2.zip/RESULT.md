# Native eight ANDs with three dirty sites

For the four native banks, a protected eight-AND representative with precisely three dirty ANDs and five isolated clean output ANDs requires **at least 35 gates**. All four private tags cannot be backed in this architecture, even without an OR budget. The proof uses the 676 signed native rows, including 624 indexed negatives, 468 distinct negative masks and 245 inclusion-maximal negative masks, and permits arbitrary OR sharing. The remaining area-33 question with eight ANDs may still involve four or more dirty sites. The global area-33 range remains eight to ten ANDs.

The antecedent is exactly four distinct physical private sites, one per private point q with a unique singleton AND address opposite its tag u, singleton tag AND darkness, each tag touching at most two sites and each tag pair at most three, and an exterior site SDR for the three ordinary tags. The five isolated clean output terms do not feed any other AND. These named conditions are supplied by the protected representative and compatible clean normalization described in native-eight-scope-crosswalk-v2.zip. The input banks at original IDs 0, 7, 17 and 115 supply respectively neither point pair, 129, 4160 or both. This theorem does not assert that arbitrary exact-eight-AND witnesses have exactly three dirty sites or preserve their dirtiness classifications under changes of representative.

Let b count private tags that touch a second AND, and h count dirty private sites. Every unbacked private site is clean. Indeed the only address for its private point and matched tag is that site J. Each path from either raw to the output must pass J, as an all-OR bypass would already accept the singleton. The positive q+u forces J high and any negative raising J would dominate the positive outside this cut. Thus 0≤h≤min(b,3), independently of how the other sites share operands.

| Backed private tags b | h=0 | h=1 | h=2 | h=3 |
|---|---|---|---|---|
| 0 | 40 | impossible by cut | impossible by cut | impossible by cut |
| 1 | 40 | ≥35 | impossible by cut | impossible by cut |
| 2 | 41 | ≥38 | ≥38 | impossible by cut |
| 3 | impossible | 41 | ≥38 | 40 |
| 4 | impossible | impossible | impossible | impossible |

Bare numbers in the table have matching upper controls on every bank. A numerical lower bound with ≥ applies to every bank, even if a displayed sharp control in its source uses specific optional compounds. The uniform 35 bound need not be tight.

The ten source archives in DEPENDS.sha256 map to the cells as follows. three-dirty-all-unbacked-40 covers (0,0). three-dirty-one-backed-clean-40 covers (1,0). three-dirty-one-backed-dirty-J and three-dirty-guest-rich-40 cover (1,1), splitting the four possible ordinary-guest counts into 0/1 and 2/3 respectively. three-dirty-multiple-backed-all-clean covers (2,0), (3,0) and (4,0). three-dirty-two-backed-one-dirty-private-38 and three-dirty-two-dirty-private-38 cover (2,1) and (2,2). three-dirty-many-backed-one-dirty-private-41, three-dirty-many-backed-two-private-drat and three-dirty-three-dirty-private-40 cover columns h=1,2,3 for b=3 and 4.

Numerical coverage has two receipt types. The all-unbacked, all-private-clean, and final three multiple-backed packets contain externally checked DRAT refutations combined with native controls and physical OR accounting. The one-backed dirty-host 0/1 and 2/3 guest packets and the two-backed one/two dirty-host packets contain complete native solver ledgers and source replays; this wrapper does not upgrade their pre-existing receipt type. The mathematics and finite models still require independent source review. No global original-bank assignment is excluded by the table alone.

## Native exclusive tag sockets

Some component encodings additionally require a socket touched by a given tag t but by no other bare tag. This is a consequence of the original native signed complement-resolution rows and the at-most-two tagged sites, as established in native-eight-tag-hall.zip, which is included in the dependency digest list. At each touched site bare-tag darkness puts t on just one arm. If every such arm also carries a different tag, select one competing tag from each of these at most two arms. The native resolution for the complement of those at most two tags must include t, yet every t socket is blocked. Thus a t-exclusive socket exists. Distinct private points, tag probes and an abstract exterior matching alone would not justify this addition in a different partial-function model. The theorem uses the actual native signed negatives throughout.
