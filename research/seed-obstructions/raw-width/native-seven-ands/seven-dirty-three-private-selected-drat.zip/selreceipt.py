from hashlib import sha256
from itertools import combinations
import gzip
import json
from pathlib import Path
from physical import charts
from livecontrol import inspect_control


def main():
    roster=list(charts())
    eligible={('ext',b,h,6) for b in (3,4) for h in combinations(range(2,6),3)}
    ids=[i for i,role in enumerate(roster) if role in eligible]
    assert ids==[16,17,18,19,36,37,38,39]
    folder=Path('selected')
    receipts={int(f.stem) for f in folder.glob('*.json') if '.' not in f.stem}
    assert receipts==set(ids)
    print('ID center backed dirty_private_hosts B status clauses canonical_DIMACS_SHA256 uncompressed_trimmed_DRAT_SHA256 compressed_DRAT_SHA256')
    for i in ids:
        data=json.loads((folder / f'{i}.json').read_text())
        m,b,h,E=data['H']
        assert data['i']==i and (m,b,tuple(h),E)==roster[i]
        out=[i, m, b, ','.join(map(str,h)),E, data['status']]
        if data['status']=='verified UNSAT':
            blob=(folder / f'{i}.drat.gz').read_bytes()
            proof=gzip.decompress(blob)
            assert len(proof)==data['size'] and sha256(proof).hexdigest()==data['drat']
            out.extend([data['clauses'], data['cnf'],data['drat'],sha256(blob).hexdigest()])
        elif data['status'] in ('SAT relaxation','native SAT'):
            control=json.loads((folder / f'{i}.control.json').read_text())
            verdict=inspect_control(control['w'])
            if data['status']=='native SAT':assert verdict['exact_live']
        else:assert data['status']=='UNKNOWN'
        print(*out)
if __name__=='__main__':main()
