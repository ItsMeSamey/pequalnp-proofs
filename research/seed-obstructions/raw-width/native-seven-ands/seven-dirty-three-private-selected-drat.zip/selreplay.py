from physical import Model,charts
from pathlib import Path
import hashlib,gzip,subprocess,sys,tempfile,json
checks=list(map(int,sys.argv[1].split(',')));exe=sys.argv[2]
for i in checks:
 r=json.loads(Path(f'selected/{i}.json').read_text());assert r['status']=='verified UNSAT'
 C=Model(*list(charts())[i]).C
 cnf=('p cnf %d %d\n'%(max(abs(v)for c in C for v in c),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode()
 proof=gzip.decompress(Path(f'selected/{i}.drat.gz').read_bytes())
 assert len(C)==r['clauses'] and hashlib.sha256(cnf).hexdigest()==r['cnf'] and hashlib.sha256(proof).hexdigest()==r['drat']
 with tempfile.TemporaryDirectory(dir='/dev/shm')as td:
  p=Path(td);f=p/'c';d=p/'r';f.write_bytes(cnf);d.write_bytes(proof)
  z=subprocess.run([exe,str(f),str(d),'-i'],capture_output=True)
  assert z.returncode==0 and b's VERIFIED'in z.stdout
 print('VERIFIED',i,flush=True)
