# Seven dirty ANDs and three dirty matched private owners

All eight selected common-exterior roles are UNSAT for the unpriced production formulas. The eight trimmed DRATs were independently checked against their own canonical DIMACS within each production slice after trimming. The per-chart schedule and SHA256 hashes of the CNF, uncompressed trimmed DRAT, and compressed stored DRAT appear in selected-crosswalk.log. There were no SAT or UNKNOWN roles.

The selected protected eight-AND, area-at-most-33 representative has seven dirty sites, three dirty matched private owners, one clean private output J32, and exterior backup B=D6. Under c3d7d8b2 only a common exterior center and earliest private index at least 2 are needed for both backing counts. The four possible dirty private host triples are (2,3,4), (2,3,5), (2,4,5), and (3,4,5). In the frozen direct role generator they occupy IDs 16 through 19 at three backed tags and 36 through 39 at four backed tags. With the stated structural reduction, the result closes this seven-dirty, three-dirty-private sector. A chart receipt alone addresses its recorded tuple.

The search used the full 7afa0d04 gate semantics, all native signed constraints and original C6 obligations. The separate 77d0c004 preflight compared production/socket semantics and the deliberately defective omitted-D6 kernel under a partial fixture. No mutated kernel, partial fixture pins, extra wiring convention or OR budget was used in the eight production formulas.

All eight slices used the shared native lock at nice 15 and released it between roles, with a 768 MiB address-space ceiling, CPU limits and per-role wall timeout. Aggregate measured worker CPU was 8.819 seconds; peak per-role time was 1.559 CPU seconds and 2.003 wall seconds. The stored proofs total 666,144 compressed bytes.

For fresh replay, selreplay.py takes a comma-separated list of the recorded IDs and a drat-trim executable. It regenerates the entire formula, checks both digests, and invokes the checker on the uncompressed retained certificate. Independent review of this newly produced set is pending at freeze.
