from nativecontrol import rows

def inspect_control(masks):
    assert len(masks)==16
    inputs=[(masks[2*g]|masks[2*g+1])>>20 for g in range(8)]
    reached={7}
    for g in range(7,-1,-1):
        assert inputs[g] < 1<<g
        if g in reached:
            reached.update(d for d in range(g) if inputs[g]>>d&1)
    dirty=set()
    for p,t,sign in rows:
        wires=p|t<<13
        for g in range(8):
            bit=bool(wires&masks[2*g]) and bool(wires&masks[2*g+1])
            if bit:
                wires |= 1<<(20+g)
                if sign<0:dirty.add(g)
        assert not sign or bool(wires>>27&1)==(sign>0)
    assert dirty==set(range(7))
    return dict(live=sorted(reached),dirty=sorted(dirty),rows=len(rows),
                exact_live=len(reached)==8)
