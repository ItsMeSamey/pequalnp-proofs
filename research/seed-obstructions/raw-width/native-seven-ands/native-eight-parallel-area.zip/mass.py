from rect import *
from itertools import combinations
F=(1<<20)-1;H=1<<20;K=1<<21
stars=[sum({r&8191 for r in P if r&u})for u in raw[13:]]
def sole(up,e):
 return reduce(or_,(r&up for h,r in enumerate(P)if e>>h&1 and (r&up).bit_count()==1),0)
@cache
def node(lo,up):
 if lo.bit_count()<2:return ()
 # a native added point pair meets each residual star at most once
 masked=[lo&(~8191|s)for s in stars]
 return tuple((x,up)for x in set(masked)if x.bit_count()>=2 and not any(x!=y and not x&~y for y in masked))
@cache
def lb(nodes):
 if not nodes:return 0
 a,up=nodes[0];rest=nodes[1:]
 neigh=tuple((b,v)for b,v in rest if (a&v).bit_count()<=1 or (b&up).bit_count()<=1)
 return max(lb(rest),a.bit_count()-1+lb(neigh))
def cost(ns):return lb(tuple(sorted(set(ns),key=lambda a:(-a[0].bit_count(),a))))
def small(i,j,c,e,ft,fu):
 allm=set()
 for t,T in zip(raw[13:],stars):
  if not e&~pp(t):
   allm.add(node(sole(T,e),T));break
 for h,s,f in ((H,Q[i][0],ft),(K,Q[j][0],fu),(H|K,Q[i][0]&Q[j][0],ft|fu)):
  b=s
  while b:
   allowed=fits(b)
   if not(e&~(pp(b)&(pp(allowed)|f))):
    allm.add(tuple(sorted(node(b,b)+node(sole(allowed,e&~f)|h,allowed|h))))
   b=(b-1)&s
 return sorted(allm,key=lambda a:(cost(a),a))
def run(i,j,c):
 o=max(c,key=int.bit_count); es={m:m&~reduce(or_,(t for t in c if t!=m),0)for m in c};e=es[o]
 count=0;closed=0;mincost=99
 s=Q[i][0]&Q[j][0];b=s
 while b:
  fallback=pp(b)&pp(fits(b));aux=fits(b)
  if not e&~pp(b):
   rs=list(rect(b))
   for t in rs:
    x=pp(t[0])&pp(t[1])&Q[i][1]
    for v in rs:
     y=pp(v[0])&pp(v[1])&Q[j][1]
     if e&~(x|y|fallback):continue
     fixed=node(b,b)+node(H|K|sole(aux,e&~(x|y)),H|K|aux)
     for a,r in ((t,e&~(y|fallback)),(v,e&~(x|fallback))):
      for ar in a:fixed+=node(sole(ar,r),ar)
     pools=[small(i,j,m,ee,x,y)for m,ee in es.items()if m!=o]
     def rec(terms,ns):
      nonlocal mincost
      co=cost(ns)
      if co>20 or co>=mincost:return
      if not terms:mincost=co;return
      for a in terms[0]:rec(terms[1:],ns+a)
     rec(pools,fixed)
     count+=1
  b=(b-1)&s
 return count,mincost
if __name__=='__main__':
 import sys
 for i,j,_,(cs,) in map(literal_eval,open('layouts.log')):
  if len(sys.argv)>1 and i not in list(map(int,sys.argv[1:])):continue
  lb.cache_clear();print(i,j,*run(i,j,cs),flush=True)
