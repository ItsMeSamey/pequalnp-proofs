from guard2 import *
from functools import cache
@cache
def pp(m):return sum(1<<i for i,p in enumerate(P) if p&m)
def signatures(s):
 ng=reduce(or_,(rneg[x] for x in bm(s)),0)
 neigh={x:sum(y for y in raw if not pairneg[min(x,y),max(x,y)]&ng)for x in raw}
 sides={FULL}
 for x in set(neigh.values()):sides.update([v&x for v in sides])
 result=set()
 for a in sides:
  if not a:continue
  b=reduce(int.__and__,(neigh[x]for x in bm(a)),FULL)
  if a>b or not b:continue
  f=pp(a)&pp(b)&pp(s)
  if f and any(n&a and n&b for n in N):result.add(f)
 return [f for f in result if not any(f!=g and not f&~g for g in result)]
if __name__=='__main__':
 import sys
 i,k=map(int,sys.argv[1:3])
 for s in masks()[i::k]:
  print(s,*signatures(s),flush=True)
