from pathlib import Path
L=set()
for line in open('all-signatures.txt'):
 s,*f=map(int,line.split())
 L.update((s,x)for x in f)
K=[]
for s,f in sorted(L,key=lambda p:(-sum(a.bit_count()for a in p),p)):
 if not any(not(s&~t or f&~g)for t,g in K):K.append((s,f))
print('raw',len(L),'maximal',len(K))
Path('max-profiles.txt').write_text(repr(K))
