from layouts import *
def rect(b):
 ng=reduce(or_,(rneg[x]for x in bm(b)),0)
 nbr={x:sum(y for y in raw if not pairneg[min(x,y),max(x,y)]&ng)for x in raw}
 sides={FULL}
 for x in set(nbr.values()):sides.update([v&x for v in sides])
 for x in sides:
  if x:
   y=reduce(int.__and__,(nbr[t]for t in bm(x)),FULL)
   if x<=y and y:yield(x,y)
