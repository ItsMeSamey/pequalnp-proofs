from guards import *
from actions import actions
from ast import literal_eval
profiles=literal_eval(Path('max-profiles.txt').read_text());idx={z:i for i,z in enumerate(profiles)}
print(len(profiles))
for p in profiles:print(*p)
for x in raw:print(sum(y for y in raw if not pairneg[min(x,y),max(x,y)]),pp(x))
ps=[]
for pm,ns in actions():
 if set(ns)!=set(N):continue
 mm=pm.copy()
 for u in raw[13:]:
  g={pm[p&8191]for p in P if p&u}
  mm[u]=next(v for v in raw[13:]if {p&8191 for p in P if p&v}==g)
 t=[P.index(sum(mm[x]for x in bm(p)))for p in P]
 ps.append([idx[sum(mm[x]for x in bm(s)),sum(1<<t[x.bit_length()-1]for x in bm(f))]for s,f in profiles])
print(len(ps))
for p in ps:print(*p)
