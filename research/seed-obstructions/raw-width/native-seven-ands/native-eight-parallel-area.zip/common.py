from itertools import combinations
from functools import cache
from pathlib import Path
from collections import Counter
free={129,320,513,1028,2052,4160}
@cache
def covernum(m,pool):
 if not m:return 0
 options=[s for s in pool if s&m&-m] + [m&-m]
 return 1+min(covernum(m&~s,pool)for s in options)
def lower(R,T):
 tot=0
 for m in R:
  pool=tuple(sorted(a for a in (R|T|free)-{m}if not a&~m))
  tot+=max(1,covernum(m,pool)-1)
 return tot
def shared(R):
 T=set()
 for x,y in combinations(R,2):
  m=x&y;s=m
  while s:
   if s.bit_count()>=2:T.add(s)
   s=(s-1)&m
 return T-R-free
if __name__=='__main__':
 fails=[]
 for f in sorted(Path('.').glob('real-*')):
  hist=Counter()
  for k,l in enumerate(f.open()):
   R={int(s)for s in l.split()if int(s).bit_count()>1}-free;T=shared(R)
   x=lower(R,T);hist[x]+=1
   if x<=20:fails.append((f.name,k,sorted(R),sorted(T)))
  print(f.name,sorted(hist.items()),flush=True)
 Path('common-open.txt').write_text(''.join(repr(x)+'\n'for x in fails))
