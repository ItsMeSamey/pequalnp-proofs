#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <vector>
using M=uint32_t;
constexpr M FULL=(1u<<28)-1, ALL=(1u<<20)-1;
struct Profile{M s,f;};
M neighbors[20],atom[20],pos[1<<20],base[1<<20];
using L=std::vector<M>;
L terms(Profile p){
 L v;
 for(M b=p.s;b;b=(b-1)&p.s){
  M r=base[b]|(pos[b]&p.f);
  if(r!=0)v.push_back(r);
 }
 std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());return v;
}
Profile combine(Profile a,Profile b){return {a.s&b.s,a.f|b.f};}
bool cover(M m,int k,const L* cols){
 if(!m)return true;
 if(k==0)return false;
 unsigned pick=std::countr_zero(m);
 for(M bits=m;bits;bits&=bits-1){
  unsigned i=std::countr_zero(bits);
  if(cols[i].size()<cols[pick].size())pick=i;
 }
 for(M a:cols[pick])if(cover(m&~a,k-1,cols))return true;
 return false;
}
int main(int argc,char**argv){
 int n;std::cin>>n;if(n!=690)return 2;
 std::vector<Profile> p(n);for(auto &a:p)std::cin>>a.s>>a.f;
 for(int i=0;i<20;++i)std::cin>>neighbors[i]>>atom[i];
 int ng;std::cin>>ng;std::vector<std::vector<int>> perm(ng,std::vector<int>(n));for(auto &v:perm)for(auto &a:v)std::cin>>a;
 for(M b=1;b<=ALL;++b){unsigned i=std::countr_zero(b);pos[b]=pos[b&(b-1)]|atom[i];}

 for(M b=1;b<=ALL;++b){M a=ALL;for(M x=b;x;x&=x-1)a&=neighbors[std::countr_zero(x)];base[b]=pos[a]&pos[b];}
 std::vector<L> single(n);for(int i=0;i<n;++i)single[i]=terms(p[i]);
 int reps=0,yes=0,lowyes=0;
 for(int i=0;i<n;++i)for(int j=0;j<=i;++j){
  bool rep=true;for(auto &g:perm)if(std::pair{std::max(g[i],g[j]),std::min(g[i],g[j])}<std::pair{i,j}){rep=false;break;}if(!rep)continue;
  ++reps;L opts(atom,atom+20);
  for(auto &v:{single[i],single[j],terms(combine(p[i],p[j]))})opts.insert(opts.end(),v.begin(),v.end());
  std::sort(opts.begin(),opts.end(),[](M a,M b){int x=std::popcount(a),y=std::popcount(b);return x>y||(x==y&&a<b);});
  L maxs;for(M a:opts)if(std::none_of(maxs.begin(),maxs.end(),[&](M b){return !(a&~b);}))maxs.push_back(a);
  L by[28];for(auto a:maxs)for(M x=a;x;x&=x-1)by[std::countr_zero(x)].push_back(a);
  if(cover(FULL,6,by)){std::cout<<i<<" "<<j<<"\n";++yes;if(cover(FULL,5,by))++lowyes;}
 }
 std::cerr<<"reps "<<reps<<" six "<<yes<<" five "<<lowyes<<"\n";
}
