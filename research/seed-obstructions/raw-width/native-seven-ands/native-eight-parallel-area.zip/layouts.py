from guards import *
from functools import cache
from ast import literal_eval
Q=literal_eval(Path('max-profiles.txt').read_text())
V=(1<<28)-1
@cache
def fits(s):
 ng=reduce(or_,(rneg[x]for x in bm(s)),0)
 return sum(x for x in raw if not rneg[x]&ng)
def options(q,t):
 S=[None,q,t,(q[0]&t[0],q[1]|t[1])]
 opt={pp(x) for x in raw}
 for s,f in S[1:]:
  b=s
  while b:
   opt.add(pp(b)&(pp(fits(b))|f));b=(b-1)&s
 return tuple(sorted(a for a in opt if not any(a!=b and not a&~b for b in opt)))
def allcover(opt):
 by=[tuple(i for i,a in enumerate(opt)if a>>j&1)for j in range(28)]
 sols=set()
 def rec(m,chosen):
  if not m:sols.add(tuple(sorted(opt[i]for i in chosen)));return
  if len(chosen)==6:return
  bs=min((by[j]for j in range(28)if m>>j&1),key=len)
  for i in bs:rec(m&~opt[i],chosen+(i,))
 rec(V,());return sorted(sols)
if __name__=='__main__':
 for row in open('six-pairs.txt'):
  i,j=map(int,row.split());opt=options(Q[i],Q[j]);cs=allcover(opt)
  print((i,j,len(cs),cs),flush=True)
