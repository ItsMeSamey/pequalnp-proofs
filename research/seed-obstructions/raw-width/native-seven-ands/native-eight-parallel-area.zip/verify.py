from pathlib import Path
import subprocess as s,sys
P=sys.executable
def run(args,out,diag=None):
 z=s.run(args,check=True,capture_output=True)
 assert z.stdout==Path(out).read_bytes(),out
 if diag:assert z.stderr==Path(diag).read_bytes(),diag
with open('all-signatures.txt','wb')as f:s.run([P,'guards.py','0','1'],stdout=f,check=True)
s.run([P,'reduce.py'],check=True)
with open('pair.in','wb')as f:s.run([P,'input.py'],stdout=f,check=True)
s.run(['g++','-O2','-std=c++20','pair.cpp','-o','pair'],check=True)
with open('pair.in','rb')as f:
 z=s.run(['./pair'],stdin=f,check=True,capture_output=True)
 assert z.stdout==Path('six-pairs.txt').read_bytes() and z.stderr==Path('pair.log').read_bytes()
for name in ('layouts','roles','mass','interval','actual','common','controls'):
 out='intervals' if name=='interval' else name
 run([P,name+'.py']+('280 281 399 414 416 418 429 508 514 548'.split()if name=='actual'else []),out+'.log')
assert not Path('common-open.txt').read_text()
print('PASS all 29 orbits; total gate count at least 34')
