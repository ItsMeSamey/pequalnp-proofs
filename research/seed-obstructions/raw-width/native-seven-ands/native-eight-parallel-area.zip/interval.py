from mass import *
from itertools import product
@cache
def arm(up,low,req):
 return (up,low,tuple(sorted({r&up for j,r in enumerate(P)if req>>j&1})))
def unit(x):return arm(x,x,0)
def charges(A):
 up,lo,req=A
 return node(lo|reduce(or_,(r for r in req if r.bit_count()==1),0),up)
def variants(i,j,e,ft,fu):
 ans=set()
 for t,T in zip(raw[13:],stars):
  if not e&~pp(t):ans.add((unit(t),arm(T,0,e)));break
 for h,s,f in ((H,Q[i][0],ft),(K,Q[j][0],fu),(H|K,Q[i][0]&Q[j][0],ft|fu)):
  b=s
  while b:
   a=fits(b)
   if not(e&~(pp(b)&(pp(a)|f))):ans.add((unit(b),arm(a|h,h,e&~f)))
   b=(b-1)&s
 return sorted(ans)
def cases(i,j,c):
 o=max(c,key=int.bit_count);es={m:m&~reduce(or_,(t for t in c if t!=m),0)for m in c};e=es[o];s=Q[i][0]&Q[j][0];b=s
 while b:
  a=fits(b);fb=pp(b)&pp(a)
  if not e&~pp(b):
   rs=list(rect(b))
   for t in rs:
    x=pp(t[0])&pp(t[1])&Q[i][1]
    for v in rs:
     y=pp(v[0])&pp(v[1])&Q[j][1]
     if e&~(x|y|fb):continue
     fixed=(unit(b),arm(a|H|K,H|K,e&~(x|y)))+tuple(arm(ar,0,z) for h,z in ((t,e&~(y|fb)),(v,e&~(x|fb)))for ar in h)
     pools=[variants(i,j,ee,x,y)for m,ee in es.items()if m!=o]
     for p in product(*pools):
      block=tuple(sorted(set(fixed+sum(p,()))))
      if cost(sum((charges(w)for w in block),()))<=20:yield block
  b=(b-1)&s
if __name__=='__main__':
 keep={tuple(map(int,l.split()[:2]))for l in open('mass.log')if '99'!=l.split()[-1]}
 for i,j,_,(c,) in map(literal_eval,open('layouts.log')):
  if (i,j) not in keep:continue
  A=set(cases(i,j,c))
  print(i,j,len(A),flush=True)
  Path(f'inter-{i}-{j}').write_text('\n'.join(map(repr,sorted(A)))+'\n')
