from interval import *
from functools import reduce
@cache
def domain(A):
 up,lo,req=A;ss=[];m=up
 while m:
  if not lo&~m and all(m&r for r in req):ss.append(m)
  m=(m-1)&up
 return ss
@cache
def signed(m):
 assert not m&~F
 return pp(m),reduce(or_,(rneg[x]for x in bm(m)),0)
def evals(a,x,y):
 p,n=signed(a&F)
 if a&H:p|=x[0];n|=x[1]
 if a&K:p|=y[0];n|=y[1]
 return p,n
def test(pair,x,y):
 (p,n),(q,d)=(evals(a,x,y)for a in pair)
 return p&q,n&d
def real(i,j,c):
 o=max(c,key=int.bit_count);es={m:m&~reduce(or_,(t for t in c if t!=m),0)for m in c};e=es[o];s=Q[i][0]&Q[j][0];b=s
 while b:
  a=fits(b);fb=pp(b)&pp(a)
  if not e&~pp(b):
   rs=list(rect(b))
   for t in rs:
    x=pp(t[0])&pp(t[1])&Q[i][1]
    for v in rs:
     y=pp(v[0])&pp(v[1])&Q[j][1]
     if e&~(x|y|fb):continue
     big=(unit(b),arm(a|H|K,H|K,e&~(x|y)))
     d=tuple(arm(ar,0,z)for h,z in ((t,e&~(y|fb)),(v,e&~(x|fb))) for ar in h)
     cr=[(m,variants(i,j,ee,x,y))for m,ee in es.items()if m!=o]
     for variant in product(*(s for _,s in cr)):
      allt=(big,)+variant;fixed=big+d+sum(variant,())
      if cost(sum((charges(w)for w in fixed),()))>20:continue
      for hh in product(*(domain(z)for z in d)):
       X=test(hh[:2],(0,0),(0,0));Y=test(hh[2:],(0,0),(0,0))
       if not X[1] or not Y[1]:continue
       pools=[]
       for (la,ra),m in zip(allt,[o]+[m for m,_ in cr]):
        vs=[]
        for a1,a2 in product(domain(la),domain(ra)):
         p,n=test((a1,a2),X,Y)
         if not n and not(es[m]&~p):vs.append((a1,a2,p))
        if not vs:break
        pools.append(vs)
       else:
        for chosen in product(*pools):
         if reduce(or_,(p for l,r,p in chosen),0)==V:
          yield tuple(sorted(set(hh+tuple(a for l,r,p in chosen for a in (l,r)))))
  b=(b-1)&s
if __name__=='__main__':
 import sys
 for i,j,_,(c,) in map(literal_eval,open('layouts.log')):
  if i not in list(map(int,sys.argv[1:])):continue
  ans=sorted(set(real(i,j,c)))
  print(i,j,len(ans),flush=True)
  Path(f'real-{i}-{j}').write_text(''.join(' '.join(map(str,row))+'\n'for row in ans))
