from layouts import *
def modes(i,j,c):
 a,d=Q[i],Q[j];r=[]
 for o in c:
  e=o&~reduce(or_,(t for t in c if t!=o),0)
  choices=[]
  if any(not(e&~pp(x)) for x in raw):choices.append(0)
  for h,(s,f) in enumerate((a,d,(a[0]&d[0],a[1]|d[1])),1):
   b=s
   while b:
    if not(e&~(pp(b)&(pp(fits(b))|f))):choices.append(h);break
    b=(b-1)&s
  r.append(tuple(choices))
 return r
if __name__=='__main__':
 for i,j,_,cs in map(literal_eval,open('layouts.log')):
  r=modes(i,j,cs[0]);print(i,j,sum(x==(0,)for x in r),r)
