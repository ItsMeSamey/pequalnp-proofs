from common import *
from ast import literal_eval
from sample import samples
p=Path(__file__).parent
rows,seed,target=samples(p/'L-meta-18968.json')
program=[tuple(map(int,r.split()))for r in (p/'sixkey-414-399.txt').read_text().splitlines()]
for k,r in enumerate(rows):
 a=[bool(r>>i&1)for i in range(38)]
 for op,i,j in program:a.append(a[i] and a[j] if op else a[i] or a[j])
 if not seed>>k&1:assert a[-1]==bool(target>>k&1)
_,_,rects,terms,_=literal_eval((p/'sixkey-414-399.src').read_text())
R=set(v for pair in rects for v in pair)
for b,a,h in terms:R.update([b,a|(h<<20)])
R={x for x in R if x.bit_count()>1}-free
price=lower(R,shared(R))
assert price<=len(program)-8-5
assert sum(op for op,i,j in program)==8
# Cab and Cad share Ca. Two target ORs cost 3, while summing two separate 3-input arms would charge 4.
oldfree=free.copy();free.clear()
r={7,11}
assert lower(r,shared(r))==2 and lower(r,set())==4
free.update(oldfree)
print('checked 676 native positions and free-intersection control; gates',len(program),'noncollector ORs',len(program)-13,'private floor',price)
