"""Pin one physical graph in the verbatim production gate-evaluation block."""
import ast
import copy
from itertools import combinations
from pathlib import Path
from donor_control import physical as fixture, evaluate
from physical import Model, N, P, alltag, edges, mx, rows, sx


def compile_kernels():
    src = Path(__file__).with_name('physical.py').read_text()
    root = ast.parse(src)
    model = next(x for x in root.body if isinstance(x, ast.ClassDef) and x.name=='Model')
    init = next(x for x in model.body if isinstance(x, ast.FunctionDef) and x.name=='__init__')
    gate_defs = [x for x in init.body if isinstance(x, ast.FunctionDef) and x.name in ('OR','AND')]
    assert [x.name for x in gate_defs] == ['OR','AND']
    row = next(x for x in init.body if isinstance(x, ast.For) and ast.unparse(x.iter)=='sorted(probes)')
    gate_loop, positive_unit, negative_unit = row.body
    assert ast.unparse(gate_loop.iter)=='range(8)'
    assert ast.unparse(positive_unit.test)=='n in P' and ast.unparse(negative_unit.test)=='n in neg'
    f = ast.parse('def kernel(n,C,V,W,G,A,T): pass').body[0]
    f.body = [*gate_defs, gate_loop]
    module = ast.fix_missing_locations(ast.Module(body=[f], type_ignores=[]))

    def compile_module(tree):
        ns = {}
        exec(compile(tree,'physical.py:gate-semantics','exec'), ns)
        return ns['kernel']

    omitted = copy.deepcopy(module)
    bounds = [n for n in ast.walk(omitted) if isinstance(n,ast.Call) and ast.unparse(n)=='min(g, 7)']
    assert len(bounds)==1
    bounds[0].args[1].value=6
    return compile_module(module), compile_module(omitted)


def pins(model, sockets):
    return {model.W(g,s,j): bool(sockets[g][s] >> j & 1)
            for g in range(8) for s in range(2) for j in range(20+g)}


def propagate(clauses, selector_truth):
    # Every gate's inputs have already been fixed when its relation is read.
    values=selector_truth.copy()
    for clause in clauses:
        unknown=0
        for lit in clause:
            val=values.get(abs(lit))
            if val is None:
                assert unknown==0
                unknown=lit
            elif val==(lit>0):
                break
        else:
            assert unknown, 'conflict under the physical selector pins'
            values[abs(unknown)]=unknown>0
    return values


def truth_check(model, n, values, sockets, omitted):
    outputs, arms = evaluate(sockets,n,omit=omitted)
    for g in range(8):
        assert values[model.G(g,n)]==bool(outputs>>g&1)
        assert values[model.hot(g,n)]==any(arms[g])
        for side in range(2):
            assert values[model.A(g,side,n)]==arms[g][side]
            for d in range(min(g,6 if omitted else 7)):
                z=model.V(('lit',g,side,d,n))
                assert values[z]==bool((sockets[g][side]>>(20+d)) & (outputs>>d) & 1)
    return values[model.G(7,n)]


def check():
    model=Model('ext',4,(2,3,4),6)
    original, missing=compile_kernels()
    V=lambda *keys:model.V(keys)
    kernel_args=(V,model.W,model.G,model.A,model.hot)
    mbad=mx(N)
    production_probes=mbad|P|{1<<j for j in range(20)}|{sx(a|b) for a,b in combinations(alltag,2)}
    for t in (2,4,8,32):
        production_probes |= mx({n for n in N if n&sx(t)})
    first={}
    for index,clause in enumerate(model.C):
        first.setdefault(clause[0],index)
    masks={p|sx(t) for p,t,_ in rows}
    sockets=fixture()
    swapped=sockets[:7]+[tuple(reversed(sockets[7]))]
    settings=[(ss,pins(model,ss)) for ss in (sockets,swapped)]
    accepted=[[set(),set()] for _ in settings]
    original_total=0
    for n in sorted(production_probes|masks):
        for mutation,kernel in enumerate((original,missing)):
            clauses=[]
            kernel(n,clauses,*kernel_args)
            if mutation==0 and n in production_probes:
                start=first[-model.A(0,0,n)]
                assert model.C[start:start+len(clauses)]==clauses
                if n in P or n in mbad:
                    signed=model.G(7,n) if n in P else -model.G(7,n)
                    assert model.C[start+len(clauses)]==[signed]
                original_total+=len(clauses)
            for index,(ss,selectors) in enumerate(settings):
                values=propagate(clauses,selectors)
                if truth_check(model,n,values,ss,mutation==1):
                    accepted[index][mutation].add(n)
    expected_original={p|sx(t) for p,t in edges if t in (2,4,8)}|{2|sx(32),4096|sx(32)}
    expected_mutated={2|sx(32),4096|sx(32)}
    for orig,mut in accepted:
        assert orig&P==expected_original and mut&P==expected_mutated
        assert not (orig|mut)&N
        assert sum(bool((p|sx(t)) in orig) for p,t,y in rows if y==1)==14
        assert sum(bool((p|sx(t)) in mut) for p,t,y in rows if y==1)==2
    assert accepted[0]==accepted[1]
    print(len(production_probes),'production probes;',original_total,'verbatim kernel clauses compared against the full chart')
    print(len(masks),'unique original masks;',len(rows),'indexed native rows; both terminal socket orientations')
    print('Identical physical pins per pair: 14 vs 2 accepted positives; both reject all 624 negatives; twelve changed positive units')
    print('All W selectors pinned and all G, arm, hot and donor-lit truth values checked against independent physical evaluation')


if __name__=='__main__':
    check()
