exec(open('raw.py').read().split('pairs=0')[0])
x,y=72968,581664
for a,b in combinations_with_replacement(covers(x),2):
 h=neg(a)&neg(b);u=sum(1<<i for i,n in enumerate(na) if not h&n)
 for d,v in combinations_with_replacement(covers(y|(x&~elig(h))),2):
  for c in covers(y):
   def out(r):
    H=bool(r&a and r&b);K=bool((H or r&c) and r&d)
    return H,K,bool((H and r&u) or (K and r&v))
   if any(out(r)[2] for r in N):continue
   acc=sum(1<<i for i,r in enumerate(P) if out(r)[2])
   if not (x|y)&~acc:
    print('A B C D U V',a,b,c,d,u,v,'accepted',acc,acc.bit_count(),'H/K dirty',tuple(sum(out(r)[i] for r in N) for i in [0,1]));raise SystemExit
raise AssertionError
