from itertools import combinations,combinations_with_replacement
from functools import lru_cache
from pathlib import Path
rows=[tuple(map(int,x.split())) for x in (Path(__file__).parent/'native.in').read_text().splitlines()]
P=[p|t<<13 for p,t in rows[1:29]]
N=[p|t<<13 for p,t in rows[29:]]
allP=(1<<28)-1;allN=(1<<len(N))-1
pa=[sum(1<<i for i,x in enumerate(P) if x>>j&1) for j in range(20)]
na=[sum(1<<i for i,x in enumerate(N) if x>>j&1) for j in range(20)]
def bits(x):
    while x:
        b=x&-x;yield b;x-=b
@lru_cache(None)
def covers(m):
    L=[0]
    for i in bits(m):
        e=P[i.bit_length()-1];allc={a if a&e else a|b for a in L for b in bits(e)}
        L=[a for a in allc if not any(a!=c and c&~a==0 for c in allc)]
    return L
@lru_cache(None)
def neg(a):
    s=0
    for b in bits(a):s|=na[b.bit_length()-1]
    return s
@lru_cache(None)
def elig(f):
    r=0
    for n,p in zip(na,pa):
        if not f&n:r|=p
    return r
X={x|y for x,y in combinations(pa,2)}
Y={pa[(e&8191).bit_length()-1]|pa[(e>>13).bit_length()+12] for e in P}
def sub(S,k):
    return sorted({sum(ss) for s in S for ss in combinations(bits(s),k)})
pairs=0
for k,j in [(8,4),(7,5),(6,6)]:
    cand=0;surv=0
    for x in sub(X,k):
        hh=[neg(a)&neg(b) for a,b in combinations_with_replacement(covers(x),2)]
        for y in sub(Y,j):
            if x&y:continue
            cand+=1
            for h in set(hh):
                dv={neg(v) for v in covers(y|(x&~elig(h)))}
                for d,v in combinations_with_replacement(dv,2):
                    mask=d&v
                    if mask&h:continue
                    if any(not (neg(c)&mask) for c in covers(y)):
                        surv+=1;break
                else:continue
                break
    print(k,j,cand,surv,flush=True)
