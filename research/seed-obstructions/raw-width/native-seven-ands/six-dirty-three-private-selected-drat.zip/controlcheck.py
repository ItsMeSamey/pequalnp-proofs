from physical import *
from pathlib import Path
from collections import Counter
import json
def realize(i,w,actual):
 mode,b,hosts,E=list(charts())[i];own=dict(zip(private,(*hosts,7)));bk={t:(E if mode=='ext' or t==8 else own[8]) for t in private[:b]}
 words=[{j for j in range(26)if m>>j&1}for m in w];assert len(words)==16
 ORs={};known={i:i for i in range(20)}
 for k,pp in enumerate(((0,7),(6,12))):
  for s in words:
   if set(pp)<=s:s.difference_update(pp);s.add(28+k)
  known[28+k]=20+k
 while any(len(s)>1 for s in words):
  c=Counter(p for s in words for p in combinations(sorted(s),2));p=min(c,key=lambda z:(-c[z],z));n=30+len(ORs);ORs[n]=p
  for s in words:
   if set(p)<=s:s.difference_update(p);s.add(n)
 ops=[];ands=[]
 def gate(op,l,r):ops.append([op,l,r]);return 21+len(ops)
 def get(i):
  if i not in known:
   a,b=ORs[i];known[i]=gate('or',get(a),get(b))
  return known[i]
 for g in range(8):
  a,=words[2*g];r,=words[2*g+1];ands.append(gate('and',get(a),get(r)));known[20+g]=ands[-1]
 o=gate('or',ands[6],ands[7])
 def ev(m):
  z=m|bool(m&129)<<20|bool(m&4160)<<21
  for n,(op,l,r)in enumerate(ops,22):
   z|=(((z>>l&z>>r)if op=='and' else(z>>l|z>>r))&1)<<n
  return z
 def mark(m):
  z=ev(m);return {i for i,n in enumerate(ands)if(z>>ops[n-22][1]|z>>ops[n-22][2])&1}
 dirt=set()
 for p,t,y in rows:
  z=ev(p|sx(t));assert not y or bool(z>>o&1)==(y>0)
  if y<0:dirt.update(g for g,n in enumerate(ands)if z>>n&1)
 assert dirt==set(range(6))
 for t,d in own.items():
  assert mark(q[t])=={d} and mark(sx(t))==({d,bk[t]} if t in bk else {d})
 for t,m in zip(ordinary,actual):assert sum(1<<g for g in mark(sx(t)))==m
 for t in alltag:
  assert len(mark(sx(t)))<=2 and not any(ev(sx(t))>>n&1 for n in ands)
  assert any(ev(sx(t))>>a&1 and not any(ev(sx(j))>>a&1 for j in alltag if j!=t)for n in ands for a in ops[n-22][1:])
 assert all(len(mark(sx(t|v)))<=3 for t,v in combinations(alltag,2))
 assert any(all(g in mark(sx(t))for g,t in zip(gs,ordinary))for gs in permutations(set(range(8))-set(own.values()),3))
 origins=[{1<<j}for j in range(20)]+[{1,128},{64,4096}]
 for op,l,r in ops:
  a,b=origins[l],origins[r];z=a|b if op=='or' else {i|j for i in a for j in b}
  origins.append({i for i in z if not any(j!=i and not j&~i for j in z)})
 return [len(ops),origins[o]==P,ops,ands,o]
if __name__=='__main__':
 out={}
 for f in sorted(Path('.').glob('boxes-*.json')):
  i=int(f.stem.split('-')[1])
  for r in json.loads(f.read_text()):
   x=realize(i,r['w'],r['marks']);k=(i,tuple(r['marks']))
   if k not in out or (not x[1],x[0])<(not out[k][1],out[k][0]):out[k]=x
 Path('controls.json').write_text(json.dumps([[k,m,*s]for (k,m),s in sorted(out.items())],separators=(',',':')))
