from nativecontrol import rows

def inspect_control(masks):
    assert len(masks) == 16
    donors = [((masks[2*g] | masks[2*g+1]) >> 20) for g in range(8)]
    for g, predecessors in enumerate(donors):
        assert predecessors < 1 << min(g, 6)
    # The two clean products both feed the output OR.
    reached = {6, 7}
    for g in range(7, -1, -1):
        if g in reached:
            reached.update(d for d in range(min(g, 6)) if donors[g] >> d & 1)
    dirty = set()
    for points, tags, sign in rows:
        wires = points | tags << 13
        for g in range(8):
            value = bool(wires & masks[2*g]) and bool(wires & masks[2*g+1])
            wires |= int(value) << (20+g)
            if sign < 0 and value:
                dirty.add(g)
        assert not sign or bool(wires >> 26 & 3) == (sign > 0)
    assert dirty == set(range(6))
    return dict(live=sorted(reached), dirty=sorted(dirty), rows=len(rows),
                exact_live=(len(reached)==8))
