from physical import Model,charts,ordinary,sx
from boxes import stock,masks
from controlcheck import realize
from livecontrol import inspect_control
from pysat.solvers import Glucose4
from pathlib import Path
import sys,gzip,hashlib,tempfile,subprocess,json
def main(i,drat):
 H=list(charts())[i];assert H[2][0]>=(2 if H[1]==4 else 1);M=Model(*H,solver=False);C=M.C
 dst=Path('selected');dst.mkdir(exist_ok=True);root=dst/str(i)
 cnf=('p cnf %d %d\n'%(max(abs(x)for clause in C for x in clause),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode()
 sha=lambda z:hashlib.sha256(z).hexdigest()
 def save(p,data):
  z=p.with_suffix('.tmp');z.write_bytes(data);z.replace(p)
 with Glucose4(bootstrap_with=C,with_proof=True)as S:
  S.conf_budget(4800);ans=S.solve_limited()
  if ans is None:print('UNKNOWN',i,flush=True);return
  if ans:
   sm=set(S.get_model());w=masks(stock(M),sm);k=[sum(1<<g for g in range(8)if M.hot(g,sx(t))in sm)for t in ordinary]
   save(root.with_suffix('.control.json'),json.dumps(dict(i=i,H=H,marks=k,w=w)).encode())
   save(root.with_suffix('.json'),json.dumps(dict(i=i,H=H,status='SAT relaxation',cnf=sha(cnf),clauses=len(C))).encode())
   checked=inspect_control(w)
   save(root.with_suffix('.control.json'),json.dumps(dict(i=i,H=H,marks=k,w=w,**checked)).encode())
   status='native SAT' if checked['exact_live'] else 'SAT relaxation'
   save(root.with_suffix('.json'),json.dumps(dict(i=i,H=H,status=status,cnf=sha(cnf),clauses=len(C),**checked)).encode())
   if not checked['exact_live']:return
   sol=realize(i,w,k);save(root.with_suffix('.control.json'),json.dumps([i,H,k,w,*sol],separators=(',',':')).encode())
   save(root.with_suffix('.json'),json.dumps({'i':i,'H':H,'status':'native SAT','clauses':len(C),'cnf':sha(cnf),'area':sol[0],'fullcube':sol[1],**checked}).encode());print('native SAT',i,k,sol[0],sol[1],flush=True);return
  raw=('\n'.join(S.get_proof())+'\n').encode()
 with tempfile.TemporaryDirectory(prefix=f'd6h3-sel-{i}-',dir='/dev/shm')as td:
  p=Path(td);f=p/'c';z=p/'r';d=p/'t';f.write_bytes(cnf);z.write_bytes(raw)
  r=subprocess.run([drat,str(f),str(z),'-C','-l',str(d),'-t','5'],capture_output=True);assert r.returncode==0 and b's VERIFIED'in r.stdout,(i,r.stdout[-200:])
  t=d.read_bytes();r=subprocess.run([drat,str(f),str(d),'-i','-t','5'],capture_output=True);assert r.returncode==0 and b's VERIFIED'in r.stdout,(i,r.stdout[-200:])
  blob=gzip.compress(t,compresslevel=3,mtime=0)
  if len(blob)+sum(p.stat().st_size for p in dst.iterdir())>12*1024**2:print('STORAGE STOP',i,flush=True);(dst/'STORAGE_STOP').touch();return
  save(root.with_suffix('.drat.gz'),blob);save(root.with_suffix('.json'),json.dumps(dict(i=i,H=H,status='verified UNSAT',clauses=len(C),cnf=sha(cnf),size=len(t),drat=sha(t))).encode())
  print('VERIFIED',i,len(C),len(t),flush=True)
if __name__=='__main__':main(int(sys.argv[1]),sys.argv[2])
