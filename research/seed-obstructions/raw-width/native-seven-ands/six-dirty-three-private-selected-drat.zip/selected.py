from physical import charts
from pathlib import Path
import fcntl,sys,os,time,subprocess,resource,signal,json,shutil
LOCK='/workspace/scratch/pnp-native-search.lock';CHK='/workspace/scratch/syn_pruning/bank11/drat-trim';tick=os.sysconf('SC_CLK_TCK')
def usage():
 r=resource.getrusage(resource.RUSAGE_CHILDREN);return r.ru_utime+r.ru_stime
def gcpu(pid):
 ids=[pid]
 try:ids+=list(map(int,Path(f'/proc/{pid}/task/{pid}/children').read_text().split()))
 except OSError:pass
 val=0
 for i in ids:
  try:d=Path(f'/proc/{i}/stat').read_text().rsplit(')',1)[1].split();val+=sum(map(int,d[11:15]))
  except OSError:pass
 return val/tick
def run(i,remain):
 with open(LOCK,'a')as f:
  while True:
   try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);break
   except BlockingIOError:time.sleep(.6)
  start=time.monotonic();base=usage();out=open('selected.log','ab',buffering=0)
  def setup():os.setsid();os.nice(15);resource.setrlimit(resource.RLIMIT_CPU,(7,8));resource.setrlimit(resource.RLIMIT_AS,(768*1024**2,768*1024**2))
  p=subprocess.Popen([sys.executable,'-uB','slice.py',str(i),CHK],preexec_fn=setup,stdout=out,stderr=out)
  high=0;reason=''
  while p.poll()is None:
   high=max(high,gcpu(p.pid))
   if time.monotonic()-start>9.25 or high>min(7.55,remain-.30):
    reason='slice timeout UNKNOWN';os.killpg(p.pid,signal.SIGKILL);break
   time.sleep(.07)
  p.wait();cpu=max(high,usage()-base);wall=time.monotonic()-start;out.close()
  for tmp in Path('/dev/shm').glob(f'd6h3-sel-{i}-*'):shutil.rmtree(tmp)
  print('slice',i,'return',p.returncode,'CPU',round(cpu,3),'wall',round(wall,3),reason,flush=True)
 return cpu
if __name__=='__main__':
 H=list(charts())
 todo=[i for i,(_,k,hosts,_) in enumerate(H) if hosts[0]>=(2 if k==4 else 1)]
 assert len(todo)==40
 if sys.argv[1:]==['--roster']:
  for i in todo:print(i,*H[i])
  sys.exit(0)
 if sys.argv[1:]!=['--run']:sys.exit('use --roster or --run')
 out=Path('selected');out.mkdir(exist_ok=True)
 for i in todo:
  receipt=out/f'{i}.json'
  if receipt.exists():continue
  run(i,float('inf'))
  if not receipt.exists():
   receipt.write_text(json.dumps({'i':i,'H':H[i],'status':'UNKNOWN'}))
  if (out/'STORAGE_STOP').exists():break
  time.sleep(1.25)
 print('bounded pass complete, lock released',flush=True)
