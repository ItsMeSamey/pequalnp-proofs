"""Verify role and stored certificate crosswalk without rerunning a solver."""
from collections import Counter
from itertools import combinations
from pathlib import Path
import gzip
import hashlib
import json
from physical import charts
from livecontrol import inspect_control


def crosswalk():
    charts_by_id = list(charts())
    selected = {i for i, (_, k, hs, _) in enumerate(charts_by_id)
                if hs[0] >= (2 if k == 4 else 1)}
    independent = {(m, k, hs, backup)
                   for m in ('ext', 'hub') for k in (3, 4)
                   for hs in combinations(range(2 if k == 4 else 1, 6), 3)
                   for backup in (6, *range(hs[-1]+1, 6))}
    assert len(selected) == len(independent) == 40
    assert {charts_by_id[i] for i in selected} == independent
    data = Path('selected')
    results = {}
    for i in selected:
        file = data / f'{i}.json'
        if not file.exists():
            continue
        r = json.loads(file.read_text())
        assert r['i'] == i
        m, k, h, b = r['H']
        assert (m, k, tuple(h), b) == charts_by_id[i]
        if r['status'] == 'verified UNSAT':
            proof = gzip.decompress((data / f'{i}.drat.gz').read_bytes())
            assert len(proof) == r['size'] and hashlib.sha256(proof).hexdigest() == r['drat']
        elif r['status'] in ('native SAT','SAT relaxation'):
            control = json.loads((data / f'{i}.control.json').read_text())
            w = control['w'] if isinstance(control, dict) else control[3]
            checked = inspect_control(w)
            if r['status'] == 'native SAT':
                assert checked['exact_live'] and r['live'] == checked['live']
        else:
            assert r['status'] == 'UNKNOWN'
        results[i] = r['status']
    print('id center backed private_indices backup status')
    for i in sorted(selected):
        print(i, *charts_by_id[i], results.get(i, 'unrun'))
    for role in [('ext',3),('ext',4),('hub',3),('hub',4)]:
        group=[results.get(i,'unrun') for i in selected if charts_by_id[i][:2]==role]
        print(*role, dict(Counter(group)))
    print('total',dict(Counter(results.values())), 'unrun',len(selected)-len(results))
    return results

if __name__ == '__main__':
    crosswalk()
