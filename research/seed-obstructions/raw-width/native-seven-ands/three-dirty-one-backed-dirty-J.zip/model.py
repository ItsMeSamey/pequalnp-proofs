from nativecontrol import rows
from itertools import combinations, permutations, product
from pysat.formula import IDPool
from pysat.solvers import Cadical195
from collections import Counter
import sys
h=int(sys.argv[2]);q=int(sys.argv[1]);u={2:32,8:2,16:4,32:8}[q]
point=[1,4,64,128,256,512,1024,2048,4096]
ordinary=[1,16,64];tags=ordinary+[u]
atoms=point+[t<<13 for t in tags]+[q]
NPTS=9; ND=len(atoms)
D0=list(range(4))
native={t:sum({p for p,j,s in rows if s==1 and j==t}) for t in tags}
def pack(p,t):return sum(1<<i for i,a in enumerate(atoms) if (p|t<<13)&a)
tt=[pack(0,t) for t in tags]
P={pack(p,t) for p,t,s in rows if s==1 and t in tags}
Pord=sorted(pack(p,t) for p,t,s in set(rows) if s==1 and t in ordinary)
neg={pack(p,t) for p,t,s in rows if s<0}
N={k for k in neg if not any(k!=l and k&~l==0 for l in neg)}
probes=P|N|{1<<i for i in range(ND)}|{a|b for a,b in combinations(tt,2)}
private={2:32,8:2,16:4,32:8}
others=[v for v in private.values() if v!=u]
fullstars={v:sum({p for p,t,y in rows if y==1 and t==v}) for v in private.values()}
def mx(S):return {s for s in S if not any(s!=t and not s&~t for t in S)}
vneg={v:mx({pack(p,t) for p,t,y in rows if y<0 and t&v}) for v in others}
pneg={v:mx({pack(p,t) for p,t,y in rows if y<0 and p&fullstars[v]}) for v in others}
uneg=mx({pack(p,t) for p,t,y in rows if y<0 and t&u})
for v in others:probes|=pneg[v]|vneg[v]
probes|=uneg
ids=IDPool();v=lambda *a:ids.id(a)
cnf=[]
def And(y,ls):
    cnf.append([y]+[-x for x in ls]);cnf.extend([-y,x] for x in ls)
def Or(y,ls):
    cnf.append([-y]+ls);cnf.extend([y,-x] for x in ls)
def term(g,s,j):return v('term',g,s,j)
def arm(g,s,n):return v('arm',g,s,n)
def site(g,n):return v('site',g,n)
def hot(g,n):return v('hot',g,n)
def no(x):cnf.append([-x])
for g in range(5):
    for so in range(2):
        if (g,so)!=(h,1):no(term(g,so,13))
for j in range(9,13):no(term(h,1,j))
cnf+=[[term(h,0,12)],[term(h,1,13)]]
for n in sorted(probes):
    for g in range(5):
        for s in range(2):
            yy=[term(g,s,j) for j in range(ND) if n>>j&1]
            for i in range(min(g,3)):
                y=v('conj',g,s,i,n);And(y,[term(g,s,ND+i),site(i,n)]);yy.append(y)
            Or(arm(g,s,n),yy)
        ax=[arm(g,s,n) for s in range(2)]
        And(site(g,n),ax);Or(hot(g,n),ax)

    if n in N:cnf.extend([-site(g,n)] for g in (3,4))
for g in range(3):cnf.append([site(g,n) for n in sorted(N)])
for n in tt:
    for g in range(5):no(site(g,n))
    for gg in combinations(range(5),3):cnf.append([-hot(g,n)for g in gg])
for a,b in combinations(tt,2):
    for gg in combinations(range(5),4):cnf.append([-hot(g,a|b)for g in gg])
for g in range(5):
    if g!=h:no(hot(g,1<<13))
ext=[g for g in range(5)if g!=h]
for k in (1,2,3):
    for X in combinations(tt[:3],k):
        for G in combinations(ext,k-1):cnf.append([hot(g,n)for g in ext if g not in G for n in X])
for n in uneg:no(site(h,n))
for vtag in others:
    T=v('private tag receives last',vtag)
    for n in pneg[vtag]:cnf.append([-T,-site(2,n)])
    for g in range(3):
        Y=v('private point receives',vtag,g)
        for n in vneg[vtag]:cnf.append([-Y,-site(g,n)])
        for n in N:cnf.append([-Y,-T,-site(g,n),-site(2,n)])
for p,t,y in set(rows):
    if y!=1 or t not in tags:continue
    n=pack(p,t);pos=[site(3,n),site(4,n)]
    for vtag in others:
        T=v('private tag receives last',vtag)
        z=v('donor-positive',vtag,n)
        if p&fullstars[vtag]:And(z,[T,site(2,n)])
        else:
            extra=[]
            for g in range(3):
                zz=v('positive point via',vtag,n,g)
                And(zz,[v('private point receives',vtag,g),site(g,n)])
                extra.append(zz)
            pp=v('positive point pass',vtag,n);Or(pp,extra)
            And(z,[T,site(2,n),pp])
        pos.append(z)
    cnf.append(pos)
sat=Cadical195(bootstrap_with=cnf)
def query(asp,budget=2000):
    sat.conf_budget(budget);b=sat.solve_limited(assumptions=asp)
    if b is not True:return b
    M=set(sat.get_model())
    return [[sum(1<<j for j in range(ND+min(g,3)) if term(g,s,j) in M)for s in (0,1)]for g in range(5)]
