from model import *
from pathlib import Path
from collections import Counter
from itertools import product,permutations,combinations
def sw(k):
  return tuple((m&7)|((m&8)<<1)|((m&16)>>1) for m in k)
def keys():
  opts=[m for m in range(1,32) if m.bit_count()<=2]
  for backup in ext:
    mu=(1<<h)|(1<<backup)
    for kk in product(opts,repeat=3):
        k=kk+(mu,)
        if sum(bool(m>>h&1) for m in kk)>1 or k>sw(k):continue
        if any((a|b).bit_count()>3 for a,b in combinations(k,2)):continue
        if not any(all(m>>j&1 for m,j in zip(kk,G)) for G in permutations(ext,3)):continue
        yield k
def assign(k):return [(1 if m>>i&1 else -1)*hot(i,t) for m,t in zip(k,tt)for i in range(5)]
if __name__=='__main__':
  for k in keys():print(k,query(assign(k),2500),flush=True)
