from nativecontrol import rows
from itertools import combinations
from collections import Counter
private={2:32,8:2,16:4,32:8}
ordt=(1,16,64)
raw=[1,4,64,128,256,512,1024,2048,4096]
edges={(p,t) for p,t,y in rows if y==1}
N={p|t<<13 for p,t,y in rows if y<0}
c=Counter()
for q,u in private.items():
    for v in private.values():
        if v==u:continue
        P=sum(p for p,t in edges if t==v)
        atoms=[q,*raw]+[j<<13 for j in (*ordt,u)]
        for k in (1,2,3):
            for ss in combinations(atoms,k):
                m=sum(ss)
                if any(not m&~n for n in N):
                    assert any(not m&~n and n&P for n in N)
                    c[k]+=1
        for x in ordt:
            assert any(not (q|x<<13)&~n and n&P for n in N)
print('unsafe original extensions including q,u',dict(c))
