from ast import literal_eval
from collections import Counter,defaultdict
from itertools import product,combinations,permutations
from pathlib import Path
allstats=Counter(); prices=defaultdict(Counter); cases=Counter();from collections import defaultdict
for q,h in product((2,8,16,32),range(3)):
    ext=set(range(5))-{h}
    def canon(k):
        swapped=tuple((m&7)|((m&8)<<1)|((m&16)>>1) for m in k)
        return min(k,swapped)
    allkeys={canon(m+((1<<h)|(1<<b),))for b in ext for m in product([x for x in range(1,32) if x.bit_count()<3],repeat=3) if sum(x>>h&1 for x in m)<2 and all((x|y).bit_count()<=3 for x,y in combinations((*m,(1<<h)|(1<<b)),2)) and any(all(z>>j&1 for z,j in zip(m,gs)) for gs in permutations(ext,3))}
    assert len(allkeys)==780
    def read(prefix):
        dic={}
        for l in Path(f'{prefix}-{q}-{h}.log').read_text().splitlines():
            if l.startswith('('):
                a,b=l.split(') ',1);k=literal_eval(a+')')
                assert k not in dic;dic[k]=b
        return dic
    sig=read('signed');det=read('price')
    assert set(sig)==allkeys
    assert set(det)=={k for k,b in sig.items() if b!='False'}
    assert all(b.endswith(' False')for b in det.values())
    for k in allkeys:
        allstats['footprints']+=1
        if k not in det:allstats['UNSAT']+=1;continue
        C=dict(literal_eval(det[k].rsplit(' ',1)[0]))
        assert all(n>0 for n in C.values())
        if sig[k]=='None':allstats['recovered initial unknown']+=1
        if not C:
            assert sig[k]=='None';allstats['UNSAT']+=1;continue
        assert sig[k].startswith('[[')or sig[k]=='None'
        allstats['SAT']+=1
        g=sum(x>>h&1 for x in k[:3])
        prices[h,g].update(C);cases[h,g]+=1
print('all canonical footprints',dict(allstats))
for key in sorted(prices):
    C=prices[key];print('H position, guests, footprints, layouts, minimum charged upstream ORs',key,cases[key],sum(C.values()),min(C))
print('all layouts',sum(sum(C.values())for C in prices.values()),'minimum OR price',min(min(C)for C in prices.values()))
