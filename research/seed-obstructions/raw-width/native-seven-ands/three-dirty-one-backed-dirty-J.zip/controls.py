from nativecontrol import rows
from itertools import combinations, permutations
from collections import Counter
from pathlib import Path
from ast import literal_eval
import json,sys
private={2:32,8:2,16:4,32:8}
ordinary=(1,16,64)
stars={t:sum({p for p,u,s in rows if s==1 and u==t}) for t in [*private.values(),*ordinary]}
pts=[1,4,64,128,256,512,1024,2048,4096]
def build(q,h,guest,model,donate=True):
    u=private[q];tlabels=[1,16,64,u]
    atom=pts+[t<<13 for t in tlabels]+[q]
    if any(not x for pair in model for x in pair):return
    source=[x.bit_length()-1 for x in atom]+[20,21,22]
    ar=[{source[j] for j in range(len(source)) if m>>j&1}for ab in model for m in ab]
    own=[j for j in private.values() if j!=u]
    for j in own:ar += [{13+j.bit_length()-1}, {i for i in range(13) if stars[j]>>i&1}]
    if donate:
        for j,pr in enumerate(((0,7),(6,12))):
            for a in ar:
                if set(pr)<=a:a.difference_update(pr);a.add(23+j)
    # Factor every repeated pair jointly, including across dirty levels.
    defs={}
    while any(len(a)>1 for a in ar):
        c=Counter(z for a in ar for z in combinations(sorted(a),2))
        pair=min(c,key=lambda z:(-c[z],z));k=25+len(defs);defs[k]=pair
        for a in ar:
            if set(pair)<=a:a.difference_update(pair);a.add(k)
    net=[]; known={**{i:i for i in range(20)},23:20,24:21};ands=[];marks={}
    def gate(op,l,r):net.append([op,l,r]);return 21+len(net)
    def phys(j):
        if j not in known:
            l,r=defs[j];known[j]=gate('or',phys(l),phys(r))
        return known[j]
    for g in range(8):
        l,=ar[2*g];r,=ar[2*g+1];z=gate('and',phys(l),phys(r));ands.append(z)
        if g<3:known[20+g]=z
    out=ands[3]
    for n in ands[4:]:out=gate('or',out,n)
    def evaluate(p,t):
        z=p|t<<13|bool(p&129)<<20|bool(p&4160)<<21
        for i,(op,l,r) in enumerate(net,22):
            val=z>>l&1 and z>>r&1 if op=='and' else (z>>l|z>>r)&1
            z|=val<<i
        return z
    def marked(p,t):
        z=evaluate(p,t)
        return {i for i,n in enumerate(ands)if (z>>net[n-22][1]|z>>net[n-22][2])&1}
    dirt=set()
    for p,t,s in rows:
        z=evaluate(p,t)
        if s and bool(z>>out&1)!=(s==1):return
        if s<0:dirt.update(j for j,n in enumerate(ands)if z>>n&1)
    if dirt!={0,1,2}:return
    if marked(q,0)!={h} or h not in marked(0,u) or len(marked(0,u))!=2:return
    if {i for i,t in enumerate(ordinary) if h in marked(0,t)}!={i for i in range(3)if guest>>i&1}:return
    for i,j in enumerate(own,5):
        p,=[p for p,x in private.items()if x==j]
        if marked(p,0)!={i} or marked(0,j)!={i}:return
    for t in stars:
        if len(marked(0,t))>2 or any(evaluate(0,t)>>n&1 for n in ands):return
    if not any(all(i in marked(0,t) for i,t in zip(pr,ordinary)) for pr in permutations([g for g in range(5) if g!=h],3)):return
    if any(len(marked(0,t|s))>3 for t,s in combinations(stars,2)):return
    return len(net),net,ands,out
def allcube(net,out):
    origins=[{1<<i} for i in range(20)]+[{1,128},{64,4096}]
    for op,l,r in net:
        a,b=origins[l],origins[r]
        z=a|b if op=='or' else {i|j for i in a for j in b}
        origins.append({i for i in z if not any(j!=i and not j&~i for j in z)})
    return origins[out]=={p|t<<13 for p,t,s in rows if s==1}
controls=[]
for path in sorted(Path('.').glob('signed-*-*.log')):
    q,h=map(int,path.stem.split('-')[1:])
    for l in path.read_text().splitlines():
        if ' [[' not in l:continue
        ks,ws=l.split(' [[',1);k=literal_eval(ks);w=literal_eval('[['+ws)
        guest=sum(1<<j for j,m in enumerate(k[:3]) if m>>h&1)
        sol=build(q,h,guest,w)
        if sol:
            n,net,ands,out=sol
            def rawmarks(t):
                z=t<<13
                for i,(op,l,r) in enumerate(net,22):z|=(((z>>l&z>>r) if op=='and' else (z>>l|z>>r))&1)<<i
                return sum(1<<g for g,j in enumerate(ands) if (z>>net[j-22][1]|z>>net[j-22][2])&1)
            assert tuple(rawmarks(t) for t in (*ordinary,private[q]))==k
            controls.append((q,h,k,n,allcube(net,out),net,ands,out))
Path('controls.json').write_text(json.dumps(controls,separators=(',',':')))
print('verified control counts',len(controls),Counter(x[4] for x in controls),Counter(x[3]for x in controls))
