from physical import charts
from pathlib import Path
from collections import Counter
import gzip,hashlib,json
H=list(charts());eligible={i for i,h in enumerate(H)if h[2][0]>0};assert len(eligible)==20 and 11 in eligible
seen={11:'prior verified UNSAT'}
for f in sorted(Path('selected').glob('*.json')):
 if f.name.endswith('control.json'):continue
 r=json.loads(f.read_text());i=r['i'];assert i in eligible and i not in seen
 assert tuple(r['H'][:2])==H[i][:2] and tuple(r['H'][2])==H[i][2] and r['H'][3]==H[i][3];seen[i]=r['status']
 if r['status']=='verified UNSAT':
  p=Path(f'selected/{i}.drat.gz');z=gzip.decompress(p.read_bytes());assert len(z)==r['size']and hashlib.sha256(z).hexdigest()==r['drat']
 else:assert r['status']=='native SAT' and Path(f'selected/{i}.control.json').exists()
print('index center backed private_positions B status')
for i in sorted(eligible):print(i,*H[i],seen.get(i,'unverified'))
print('totals',Counter(seen.values()),'unverified',sorted(eligible-seen.keys()))
