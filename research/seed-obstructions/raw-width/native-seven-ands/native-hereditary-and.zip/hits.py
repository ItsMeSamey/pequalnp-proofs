import io,sys,itertools
from contextlib import redirect_stdout
with redirect_stdout(io.StringIO()):import chart_inputs as a
from functools import lru_cache
def minimal(sets):
    out=[]
    for s in sorted(set(sets),key=int.bit_count):
        if not any(q&~s==0 for q in out):out.append(s)
    return out
def model(tags,extras):
    prime=set(a.stars)
    for t in set(map(a.bm,range(7)))-set(tags):
        star=[p for p,m in a.stars.items()if m&t]
        for k in range(2,len(star)+1):
            prime.update(sum(v)for v in itertools.combinations(star,k))
    prime=sorted(prime|set(extras))
    P={p for p,t in a.pos if t in tags}
    prime=[f for f in prime if any(p&f for p in P)]
    req=[]
    for p,t in a.pos:
        if t not in tags:continue
        near=[(j,f)for j,f in enumerate(prime)if f&p]
        req.extend(sum(1<<j for j,f in near if not f&S) for S,V in a.neg if V&t)
    return prime,minimal(req)
def low(sets):
    b=c=0
    for S in sets:
        if not (b&S):b|=S;c+=1
    return c
def solve(req,budget):
    visited=set();leaves=set()
    def rec(sel):
        if sel in visited:return
        visited.add(sel);rem=[r for r in req if not r&sel]
        if not rem:leaves.add(sel);return
        if low(rem)> budget-sel.bit_count():return
        cand=rem[0]
        while cand:
            j=cand&-cand;cand^=j;rec(sel|j)
    rec(0);return leaves,len(visited)
if __name__=='__main__':
    from collections import Counter
    for ts in itertools.combinations(map(a.bm,range(7)),2):
        sources,req=model(ts,(129,4160))
        lo=low(req)
        ss,vc=solve(req,7)
        print(ts,len(sources),len(req),lo,Counter(x.bit_count()for x in ss),vc,flush=True)
