from collections import Counter
from hits import a
def count_forced(points,tags,positives,negatives):
    maximal={}
    for t in range(128):
        if t&~tags:continue
        p=points&~sum({x for x,y in positives if y&t})
        l=tags&~sum({y for x,y in positives if x&p})
        if l==t:maximal[t]=p
    forced=set()
    for p,t in negatives:
        candidates=[l for l,v in maximal.items() if not((points&p&~v)|(tags&t&~l))]
        assert candidates
        if len(candidates)==1:forced.add(candidates[0])
    return len(maximal),len(forced)
for k in range(1,8):
    data=[]
    for U in range(128):
        if U.bit_count()!=k:continue
        _,s=count_forced(8191,U,[(p,t) for p,t in a.pos if U&t],a.neg)
        assert s>2**(k-1)
        data.append(s)
    print(k,sorted(Counter(data).items()))
for q,u in a.rare.items():
    P,N=a.chart(q)
    assert count_forced(a.ordinary,127-u,P,N)==(39,33)
    print('high',q,39,33)
