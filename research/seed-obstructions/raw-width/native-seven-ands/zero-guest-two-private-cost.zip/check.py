"""Native signed facts and a zero-guest control with both dirty hosts private."""
import itertools
import json
import re
from pathlib import Path
statement = json.loads(Path(__file__).with_name('L-meta-18968.json').read_text())['formal_statement']
seeds = [int(''.join(x.zfill(19) for x in re.findall(r'\((\d+) : ℕ\)',b)))
         for b in re.findall(r'\[([^]]+)\]',statement)]
fields = {int(i): int(v) for i,v in re.findall(r'x1 \((\d+) : ℕ\) = \((\d+) : ℕ\)',statement)}
def rot(i, seed, off, k):
    return sum(((seed >> (i-i%13+(i-j-off)%13))&1) << j for j in range(k))
rows = [(rot(i,seeds[0],0,13),rot(i,seeds[1],6,7),1 if (fields[88]&~fields[54])>>i&1
         else -1 if not fields[88]>>i&1 else 0) for i in range(676)]
edges = {(p,t) for p,t,sgn in rows if sgn == 1}
neg = [(p,t) for p,t,sgn in rows if sgn == -1]
atoms = [1 << i for i in range(13)]
tags = [1 << i for i in range(7)]
stars = {t:frozenset(p for p,v in edges if v==t) for t in tags}
assert len(edges) == 28 and all(len(x)==4 for x in stars.values())
assert all(len(stars[t]&stars[v]) == 1 for t,v in itertools.combinations(tags,2))
for t in tags:
    for v in tags:
        assert any((s&t) and (s&v) for _,s in neg)
    for p in atoms:
        assert ((p,t) in edges) == (not any(s&t and n&p for n,s in neg))
assert all(c & sum(x) != c for x in stars.values() for c in (129,4160))
rare={p:t for p,t in edges if sum(1 for q,v in edges if p==q)==1}
print('signed geometry',len(rows),len(neg),len(edges),sorted(rare.items()))
u,v=2,32
r,=stars[u]&stars[v]
def run(p,t):
    terms=[]
    for z in tags:
        A=bool(p & sum(stars[z]))
        B=bool(t & z or (z in (u,v) and p & r))
        terms.append((A,B))
    H,J=all(terms[u.bit_length()-1]),all(terms[v.bit_length()-1])
    terms.append((H or J,bool(t&(u|v))))
    out=all(terms[-1]) or any(all(terms[i]) for i,z in enumerate(tags) if z not in (u,v))
    return out,terms
dirty=set()
for p,t,sgn in rows:
    out,terms=run(p,t)
    assert sgn==0 or out==(sgn==1)
    if sgn==-1:
        dirty.update(i for i,x in enumerate(terms) if all(x))
assert dirty=={u.bit_length()-1,v.bit_length()-1}
for p,t in rare.items():
    host=t.bit_length()-1
    assert [i for i,x in enumerate(run(p,0)[1]) if any(x)]==[host]
    assert [z for z in tags if any(run(0,z)[1][host])]==[t]
print('literal control',8,'AND',21+2+2+5,'OR', sorted(dirty),'zero guests')
