from itertools import combinations
from soleforward import atom, minterms, negatives, private, stars
charts = 0
for q,u in private.items():
    pts = [p for p in atom[:13] if p != q and p & stars[u]]
    assert len(pts) == 3
    for k in (2,3):
        for P in combinations(pts,k):
            S = sum(P)
            missed = [m for m in minterms if not m & (q | (u << 13)) and
                      any(not m & ~n for n in negatives) and
                      not any(not m & ~n and n & S for n in negatives)]
            assert len(missed) == (4 if k == 2 else 0)
            assert all(not m & 8191 and m.bit_count() == 2 for m in missed)
            charts += 1
print('native multi-point host overlaps',charts)
