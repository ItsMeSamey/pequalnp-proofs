from collections import Counter
from itertools import combinations
from pathlib import Path
rows = [tuple(map(int,x.split())) for x in Path(__file__).with_name('native.in').read_text().splitlines()]
assert rows[0] == (28,468)
edges = set(rows[1:29])
neg = rows[29:]
point = [1<<j for j in range(13)]
tag = [1<<j for j in range(7)]
stars = {t:{p for p,v in edges if v==t} for t in tag}
private = {p:t for p,t in edges if sum(p==x for x,v in edges)==1}
assert all(len(stars[t]&stars[v])==1 for t,v in combinations(tag,2))
mixed = 0
for d in point:
    for i,u in enumerate(tag):
        for g in tag[i:]:
            if (d,g) in edges or (d,u) in edges:continue
            assert any(n&d and (w&(u|g))==u|g for n,w in neg)
            mixed += 1
print('nonincident native mixed triples including repeated tags',mixed)
# Enumerate every geometry chosen by the paid lost-positive argument.
# Ignoring raw POINTS of M here only relaxes the necessary E AND u test.
count = Counter()
for q,u in private.items():
    for s in stars[u]-{q}:
        for t in tag:
            if t==u or s not in stars[t]:continue
            T=sum(stars[t])
            for p in stars[t]-{s}:
                count['q,u,s,t,p'] += 1
                assert p not in stars[u]
                for D in range(T+1):
                    if D&~T or not D&p:continue
                    for G in range(128):
                        if G&u or not G&t:continue
                        if any(n&D and w&u and w&G for n,w in neg):continue
                        count['safe reduced E'] += 1
                        if G==t:continue
                        count['multitag'] += 1
                        assert D&~s == p
                        assert all((p,g) in edges for g in tag if G&g)
                        actual={(x,g) for x,g in edges if x&D and g&G}
                        retained={(p,g) for g in tag if G&g}
                        assert actual-retained <= {(s,t)}
                        count['redundant secondary edge'] += bool(actual-retained)
print('exhaustive raw-port geometry',dict(count))
