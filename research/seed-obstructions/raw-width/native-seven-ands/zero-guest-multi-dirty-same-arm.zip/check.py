"""Check the original native geometry used in the same-arm dirty backup fold."""
import json
import re
from functools import cache
from itertools import combinations
from pathlib import Path

src = json.loads(Path(__file__).with_name('L-meta-18968.json').read_text())['formal_statement']
seeds = [int(''.join(v.zfill(19) for v in re.findall(r'\((\d+) : ℕ\)', block)))
         for block in re.findall(r'\[([^]]+)\]', src)]
fields = {int(i): int(v) for i, v in re.findall(r'x1 \((\d+) : ℕ\) = \((\d+) : ℕ\)', src)}

def rotation(i, seed, offset, width):
    return sum(((seed >> (i-i%13+(i-j-offset)%13)) & 1) << j for j in range(width))

rows = [(rotation(i,seeds[0],0,13), rotation(i,seeds[1],6,7),
         1 if (fields[88] & ~fields[54]) >> i & 1 else -1 if not fields[88] >> i & 1 else 0)
        for i in range(676)]
edges = {(p,t) for p,t,s in rows if s == 1}
neg = {p | (t<<13) for p,t,s in rows if s == -1}
@cache
def dominated(mask):
    return any(mask & ~n == 0 for n in neg)

private = (2,4,8,32)
ordinary = (1,16,64)
points = [1<<j for j in range(13)]
tags = private + ordinary
stars = {u:{p for p,t in edges if t==u} for u in tags}
private_points = {p for p in points if sum(p in s for s in stars.values())==1}
assert len(edges)==28 and len(private_points)==4
for u in private:
    assert len(stars[u])==4 and len(stars[u] & private_points)==1
for S in combinations(private,3):
    assert not set.intersection(*(stars[u] for u in S))
assert all(dominated(p | (u<<13)) for p in points for u in tags if (p,u) not in edges)
assert all(dominated(a|b) for a,b in combinations(points,2))
assert all(dominated((a|b)<<13) for a,b in combinations(tags,2))
assert all(dominated((v|a|b)<<13) for v in private for a,b in combinations(ordinary,2))
outside = sorted(set(points)-private_points) + [u<<13 for u in ordinary]
base = [(sum(K),k) for k in (1,2,3) for K in combinations(outside,k)]
for u,v in combinations(private,2):
    r, = stars[u] & stars[v]
    assert r not in private_points
    bounds = []
    for i in (u,v):
        A = stars[i] - {r}
        def escapes(mask):
            return all(not dominated(mask|p) for p in A)
        assert all(not escapes(m) for m,k in base if k<=2 and dominated(m))
        bad = {m for m,k in base if dominated(m|r) and escapes(m)}
        assert len(bad)==4 and all(m<8192 and m.bit_count()==3 for m in bad)
        bounds.append(bad)
    assert not (bounds[0] & bounds[1])
    print(u,v,r,[sorted(x) for x in bounds])
print('all native extension, nonincidence and tag-pair transport checks passed')
