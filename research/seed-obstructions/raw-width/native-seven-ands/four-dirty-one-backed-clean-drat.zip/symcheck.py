from itertools import permutations, product, combinations
from geometry import private, ordinary, stars, N0, edges, masks

maxneg={n for n in N0 if not any(n!=m and n&~m==0 for m in N0)}
P={p|(t<<13) for p,t in edges}
by={frozenset(t for t in stars if p in stars[t]):p for p in set.union(*stars.values())}
group=[]
for a,b in product(permutations(private),permutations(ordinary)):
    tags=dict(zip(private+ordinary,a+b))
    try:
        points={p:by[frozenset(tags[t] for t in S)]for S,p in by.items()}
    except KeyError:
        continue
    pi={**points,**{t<<13:j<<13 for t,j in tags.items()}}
    def image(z):
        return sum(j for t,j in pi.items()if t&z)
    if {image(z)for z in maxneg}==maxneg and {image(z)for z in P}==P:
        group.append(tags)
assert len(group)==24 and len({tuple(g[t]for t in private) for g in group})==24
for u in private:
    S=masks(u)
    assert all(len(m)==6 and all(z<8192 and z.bit_count()==4 for z in m)for m in S.values())
    assert all(not (a&b) for a,b in combinations(S.values(),2))
    for a,b in product((0,*S),repeat=2):
        assert any((g.get(a,0),g.get(b,0)) in {(0,0),(4,0),(0,4),(4,4),(4,8)}for g in group if g[u]==2)
print('native signed symmetries',len(group),'private tag permutations',24,'positive native masks',len(P),'maximal negative masks',len(maxneg))
print('all 12 recipient lists have six pure quartets; distinct unbacked recipients have disjoint lists')
print('all 64 ordered choices (backed tag, two recipients) covered by five cases')
