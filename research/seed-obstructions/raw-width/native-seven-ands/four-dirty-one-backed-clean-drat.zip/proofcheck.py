from pathlib import Path
import argparse
from itertools import product
from time import monotonic
import gzip
import hashlib
import subprocess
import tempfile
from pysat.solvers import Glucose4
from model import Model

out=Path(__file__).resolve().parent/'proofs'
pairs=((0,0),(4,0),(0,4),(4,4),(4,8))
def sha(data):
    return hashlib.sha256(data).hexdigest()
def run(args):
    model=Model(2)
    for pair,B in product(pairs,range(4)):
        key='-'.join(map(str,(B,*pair)))
        if args.case and key!=args.case:continue
        C=model.C+[[x]for x in model.assumptions(B,pair)]
        cnf=('p cnf %d %d\n'%(model.base.top,len(C))+''.join(' '.join(map(str,c))+' 0\n' for c in C)).encode()
        archive=out/(key+'.drat.gz')
        if args.verify_only:
            proof=gzip.decompress(archive.read_bytes())
        else:
            with Glucose4(bootstrap_with=C,with_proof=True) as s:
                s.conf_budget(50000)
                ans=s.solve_limited()
                assert ans is False,(key,ans)
                proof=('\n'.join(s.get_proof())+'\n').encode()
            out.mkdir(exist_ok=True)
            archive.write_bytes(gzip.compress(proof,compresslevel=3,mtime=0))
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);f=p/'c.cnf';g=p/'p.drat';f.write_bytes(cnf);g.write_bytes(proof)
            r=subprocess.run([args.drat_trim,str(f),str(g),'-t','30'],capture_output=True,timeout=35)
            assert r.returncode==0 and b's VERIFIED' in r.stdout,(key,r.returncode,r.stdout[-400:])
        print(key,len(C),len(proof),sha(cnf),sha(proof),'VERIFIED',flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('drat_trim');ap.add_argument('--verify-only',action='store_true');ap.add_argument('--case');run(ap.parse_args())
