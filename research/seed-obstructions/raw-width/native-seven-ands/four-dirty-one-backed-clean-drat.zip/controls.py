"""Relax only the 12 ordinary-positive demands and pin an explicit signed control."""
from itertools import combinations
from geometry import private,ordinary,stars,q,points,rows,edges
from model import Model
from pysat.solvers import Cadical195

u=2
M=Model(u)
f=(u,4,8,32)
raw=points+[t<<13 for t in (*ordinary,u)]
D=[]
for g,v in enumerate(f):
    if g<3:
        t=ordinary[g]
        p=next(p for p in points if p in stars[v]-stars[t])
        D.append(({p},{t<<13,u<<13} if g==0 else {t<<13}))
    else:
        p=next(p for p in points if p in stars[v])
        z=next(e for e in points if e!=p)
        D.append(({p},{z}))
T={v:({v<<13},set(stars[v])|{-1-g})for g,v in enumerate(f)}
def evaluate(p,t):
    inputs=p|(t<<13);out=[]
    for a,b in D:
        out.append(all(any(x&inputs for x in S)for S in (a,b)))
    val=[]
    for v in private:
        a,b=T[v]
        val.append(all(any((bool(inputs&x) if x>0 else out[-1-x]) for x in S)for S in (a,b)))
    return out,val
for p,t,s in rows:
    d,ts=evaluate(p,t)
    if s==-1:assert not any(ts)
    if s==1:assert any(ts)==(t in private)
assert all(any(evaluate(p,t)[0][g]for p,t,s in rows if s==-1)for g in range(4))
# Pin the complete control to the solver's genuine formal operands.
pins=[]
for g,pair in enumerate(D):
    xs=raw+[-1-h for h in range(g)]
    pair=sorted(pair,key=lambda a:tuple(x in a for x in xs))
    for s,S in enumerate(pair):pins.extend((1 if x in S else -1)*M.wire(g,s,x) for x in xs)
for v,(tag,arm) in T.items():
    g=M.skin[v]
    for s,S in enumerate((tag,arm)):
        xs=([v<<13]if s==0 else sorted(stars[v]))+[-1-h for h in range(4)]
        pins.extend((1 if x in S else -1)*M.wire(g,s,x) for x in xs)
relax={tuple(M.base.id(('clean',4+j,p|(t<<13)))for j in range(4))for p,t in edges if t in ordinary}
assert len(relax)==12
with Cadical195(bootstrap_with=[c for c in M.C if tuple(c)not in relax]) as sat:
    assert sat.solve(assumptions=pins)
with Cadical195(bootstrap_with=M.C) as sat:
    assert not sat.solve(assumptions=pins)
print('four physically routed dirty sources, four private attachments; full native negatives and 16 retained positives passed')
print('pinned model is SAT with 12 ordinary demands removed, UNSAT with them restored')
