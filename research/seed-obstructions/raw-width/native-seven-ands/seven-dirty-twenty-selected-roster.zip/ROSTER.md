# Twenty selected seven-dirty roles

An eight-AND separator in the protected six-tie representation with seven dirty sites has one isolated clean output. Its dirty private count h is either three or four. The h=3, h=4 distinction refers to the unique AND addresses of the four private points, and remains meaningful if a private match is itself dirty. The free-OR role encodings expand the optional designated point disjunctions. The signed target and the WLOG antecedents remain as in c791fe95.

## Three dirty private matches

The sole clean term is the fourth private match. The exterior backup B is D6 and all six earlier dirty sites reach B. B reaches precisely one socket of the last private match. The proof c3d7d8b2 eliminates the private-center geometry for both possible backing counts and requires at least two exterior predecessors of the first private match in the common exterior geometry. Among pre-B positions 0 through 5, choose the three private positions from 2 through 5. In each of the three- and four-backed cases these are (2,3,4), (2,3,5), (2,4,5), (3,4,5). These are direct-generator IDs 16–19 and 36–39. The model allows either terminal socket to receive B.

## Four dirty private matches

The sole clean gate is exterior and all four private tags are backed. Every dirty private has two distinct dirty exterior ancestors. The first two dirty sites are exterior. With an exterior dirty backup it is D6, with the other two exterior dirties at 0 and 1. With a clean backup (the output) the third dirty exterior may occupy any position from 2 through 6. Each choice admits a common exterior center or a private center, giving 2+10=12 roles. In the full h4 encoding D6 can thus be the dirty exterior backup, the ordinary exterior other than the backup, or the last matched private owner. Both sockets independently evaluate D6. The schedule grants arbitrary allowed donor choices and does not impose a serial edge between the two first exteriors.

These 8+12 roles are a covering set for this selected representation. The earlier 52- and 40-role lists remain sufficient. This receipt concerns the roster prior to numerical feasibility or pricing.
