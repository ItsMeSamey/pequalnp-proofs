from corpus import *
from ast import literal_eval
from pathlib import Path
import json
records=json.loads(Path('controls.json').read_text());ok=set()
total=Counter()
for i,H in enumerate(charts()):
 def read(fn):
  yy={}
  for l in Path(fn).read_text().splitlines():
   if not l.startswith('('):continue
   a,b=l.split(') ',1);k=literal_eval(a+')');assert k not in yy;yy[k]=b
  return yy
 a=read(f'corpus-{i}.log');b=read(f'prices-{i}.log')
 assert set(a)==set(keys(H));assert all(x in ('True','False')for x in a.values())
 assert set(b)=={k for k,z in a.items()if z=='True'}
 extra=read(f'sharp-{i}.log') if i in (6,7) else {}
 assert set(extra)=={k for k,x in b.items() if min(dict(literal_eval(x.rsplit(' ',1)[0])))<26}
 C=Counter()
 for k,x in b.items():
  assert x.endswith(' False')
  V=dict(literal_eval(x.rsplit(' ',1)[0]));assert min(V)>=22
  if k in extra:
   y=extra[k];assert y.endswith(' False');V2=dict(literal_eval(y.rsplit(' ',1)[0]));assert sum(V.values())==sum(V2.values());V=V2
  assert min(V)>=26;C.update(V);ok.add((H,k))
 total['tests']+=len(a);total['sat']+=len(b);total['layouts']+=sum(C.values())
 print('chart, queries, feasible, layouts, minimum upstream',H,len(a),len(b),sum(C.values()),min(C,default=None))
print('overall',total)
assert {(tuple(v[0]),tuple(v[1]))for v in records}==ok and len(records)==len(ok)
