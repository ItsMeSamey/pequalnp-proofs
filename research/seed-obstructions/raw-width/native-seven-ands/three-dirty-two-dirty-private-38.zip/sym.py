from model import *
by={frozenset(t for t in stars if p&stars[t]):p for p,j in edges}
group=[]
for a,b in product(permutations(private),permutations(ordt)):
 t=dict(zip(private+ordt,a+b))
 try: pp={p:by[frozenset(t[j]for j in S)] for S,p in by.items()}
 except KeyError:continue
 pi={**pp,**{sx(x):sx(y) for x,y in t.items()}}
 def conv(z):return sum(y for x,y in pi.items() if x&z)
 if {conv(m)for m in N}==N and {conv(m)for m in P}==P:group.append((t,conv(129),conv(4160)))
assert len(group)==24 and len({(t[2],t[4])for t,a,b in group})==12
banks=sorted({tuple(sorted((a,b)))for _,a,b in group})
if __name__=='__main__':print('24 signed permutations;',len(banks),'transported compound pairs',banks)
