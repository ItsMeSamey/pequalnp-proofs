from itertools import combinations
from pathlib import Path
R=[tuple(map(int,s.split())) for s in Path(__file__).with_name('native.in').read_text().splitlines()]
E=[p|t<<13 for p,t in R[1:29]]
N=[p|t<<13 for p,t in R[29:]]
H=[sum(1<<i for i in a) for a in combinations(range(20),3)]
H=[h for h in H if not any(e&~h==0 for e in E) and not any(h&~n==0 for n in N)]
assert [sum((h&8191).bit_count()==i for h in H) for i in range(4)]==[6,0,0,52]
# Independent exact certificate: enumerate maximal negatives avoiding the sparse upper DNF by backtracking.
hyper=E+H
def avoiding(i,m):
 if i==20:
  if all(any(c&~(m|1<<j)==0 for c in hyper) for j in range(20) if not m>>j&1):
   yield m
  return
 yield from avoiding(i+1,m)
 a=m|1<<i
 if not any(c&~a==0 for c in hyper):yield from avoiding(i+1,a)
maxneg=set(avoiding(0,0))
official={n for n in N if not any(n!=s and n&~s==0 for s in N)}
assert maxneg==official
print('cubic holes',H)
print('equal maximal-negative antichains',len(maxneg))
