#include <algorithm>
#include <bit>
#include <iostream>
#include <vector>
using namespace std;
int main(){int a,b;cin>>a>>b;int n=1<<20;vector<char>neg(n),edge(n),bad(n);vector<int>P;
 for(int i=0;i<a+b;i++){int p,t;cin>>p>>t;int m=p|(t<<13);if(i<a){edge[m]=1;P.push_back(m);}else neg[m]=1;}
 for(int bit=1;bit<n;bit*=2)for(int i=0;i<n;i++)if(i&bit){neg[i^bit]|=neg[i];edge[i]|=edge[i^bit];}
 // Separate independent downward and upward closures: the shared bit order above is valid for both.
 int hist[21]{},first=0;
 for(int i=0;i<n;i++)if(!neg[i]&&!edge[i]){
   bad[i]=1;bool minimal=true;for(int s=i;s;s&=s-1)if(!neg[i^(s&-s)]){minimal=false;break;}
   if(minimal){hist[popcount(unsigned(i))]++;if(!first||popcount(unsigned(first))>popcount(unsigned(i)))first=i;}
 }
 for(int bit=1;bit<n;bit*=2)for(int i=0;i<n;i++)if(i&bit)bad[i]|=bad[i^bit];
 int maxv=0,maxe=0,ev=0,ee=0,h[29]{};
 for(int m=0;m<n;m++)if(!bad[m]){
  int v=popcount(unsigned(m)),e=0;for(int edge:P)if((m&edge)==edge)e++;h[e]++;
  if(v>maxv){maxv=v;ev=m;}if(e>maxe){maxe=e;ee=m;}
 }
 for(int i=0;i<=20;i++)if(hist[i])cout<<"minimal "<<i<<" "<<hist[i]<<"\n";
 cout<<"smallest "<<first<<" vertices "<<maxv<<" "<<ev<<" edges "<<maxe<<" "<<ee<<" count "<<h[maxe]<<"\n";
}
