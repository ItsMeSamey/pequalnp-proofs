from pathlib import Path
from collections import Counter
R=[tuple(map(int,s.split())) for s in Path(__file__).with_name('native.in').read_text().splitlines()]
P,N=R[1:29],R[29:]
graph=[0]*13
for p,t in P:graph[p.bit_length()-1]|=t
def maximal(t):
 p=sum(1<<i for i,s in enumerate(graph) if not s&t)
 return (p,t) if all(any((1<<i)&p and s&(1<<j) for i,s in enumerate(graph)) for j in range(7) if not t&(1<<j)) else None
M={v for t in range(128) if (v:=maximal(t))}
contained=lambda a,b:(a[0]&~b[0])==0 and (a[1]&~b[1])==0
covers={m for m in M if any(contained(m,n) for n in N)}
classes=set()
for n in N:
 ext=[m for m in M if contained(n,m)]
 assert ext
 if len(ext)==1:classes.add(ext[0])
print('maximal',len(M),'covered',len(covers),'forced extensions',len(classes))
print('omitted maximal (8191,0)',(8191,0) in M-covers)
assert len(M)==101 and len(covers)==40 and len(classes)==69
assert (8191,0) in M-covers and not any(p==8191 for p,t in N)
