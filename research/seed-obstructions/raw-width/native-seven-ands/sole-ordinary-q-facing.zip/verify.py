"""Enumerate the allowed raw arms of a first dirty companion at an owned socket."""
from pathlib import Path
import runpy
import sys

source = Path(sys.argv[1]).resolve()
data = runpy.run_path(str(source / "nativecontrol.py"))
rows = data["rows"]
edges = data["edges"]
tags = [1 << i for i in range(7)]
stars = {t: {p for p, v in edges if v == t} for t in tags}
owners = {p: t for p, t in edges if sum(x == p for x, _ in edges) == 1}
neg = [p | (v << 13) for p, v, s in rows if s < 0]
atoms = [1 << i for i in range(20)]
for q, u in sorted(owners.items()):
    for g in sorted(set(tags) - set(owners.values())):
        U, T = stars[u], stars[g]
        P = T - U
        assert len(U & T) == 1 and len(P) == 3
        active_u = [n for n in neg if n & (u << 13)]
        upper_c = {a for a in atoms if not any(n & a and n & sum(P) for n in active_u)}
        upper_d = {a for a in atoms if not any(n & a and n & (g << 13) for n in active_u)}
        assert upper_c <= U | {g << 13}
        extras = upper_d - (U | T)
        h, = extras
        assert h >> 13 in owners.values() and h >> 13 not in (u, g)
        # Validate every raw petal and C choice in the migration on native positives.
        r, = U & T
        for D in (P, T):
            for mask in range(1 << len(U)):
                C = {p for j, p in enumerate(sorted(U)) if mask >> j & 1}
                R = C & D
                assert R <= {r}
                for p, t in edges:
                    if t != g:
                        assert (p in C and p in D) == (p in R)
        print(q, u, g, r, h >> 13)
        assert r in stars[h >> 13]
        assert U & stars[h >> 13] == {r}
        assert all(any(n & p and n & z for n in neg) for p in T for z in U)
        owner_h, = [a for a, t in owners.items() if t == h >> 13]
        assert all(any(n & owner_h and n & p for n in neg) for p in (1 << j for j in range(13)))
        for D in (P, T):
            for mask in range(1 << len(U)):
                C = {p for j, p in enumerate(sorted(U)) if mask >> j & 1}
                for h_on in (False, True):
                    special = h_on and r in C and D == P
                    for p, t in edges:
                        if t == g:
                            continue
                        old = p in C and (p in D or (h_on and t == h >> 13))
                        repl = (p == r and t == h >> 13) if special else p in (C & D)
                        assert old == repl
