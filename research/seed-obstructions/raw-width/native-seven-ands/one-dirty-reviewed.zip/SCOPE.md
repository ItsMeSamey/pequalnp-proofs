# One dirty AND on the native promise

For native banks 0, 7, 17 and 115, every binary monotone circuit with at most one distinct AND high on the union of the required negative rows needs at least 34 gates. The proof permits arbitrary fanout and an arbitrary number of ANDs.

The signed-domain clean-terminal normalization preserves existence and area. GENERAL.md supplies the arbitrary-count loss and matching argument in place of the eight-AND terminal inventory. The single-receiver, physical clipping and both-mixed arguments apply at any terminal count. The final repair accounts for pure receivers, supplemented receivers, shared OR wires and the terminal collector. The independent full-chain audit checked these transfers and all 420 typed arm-support cases. An original circuit's wire addresses and owner maps cannot be carried through this normalization without a separate proof.

A residual circuit of size 33 on these banks would therefore have at least two dirty ANDs. The separate physical seven-AND theorem supplies the bound of eight ANDs. Both restrictions apply within each remaining bank.
