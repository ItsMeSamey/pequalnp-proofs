#include <algorithm>
#include <array>
#include <bit>
#include <cstdio>
#include <set>
#include <vector>
using namespace std;
int n; array<bool,512> freeval;
int covering(int goal,const vector<int>& pieces){
 array<int,512> dp;dp.fill(12);dp[0]=0;
 for(int m=1;m<=goal;m++)if((m&goal)==m)for(int p:pieces)if(m&p)dp[m]=min(dp[m],1+dp[m&~p]);
 return dp[goal];
}
int lb(vector<int> terms,int stop){
 sort(terms.begin(),terms.end());terms.erase(unique(terms.begin(),terms.end()),terms.end());
 vector<int> T; for(int a:terms)if(!freeval[a])T.push_back(a);
 if((int)T.size()>stop)return T.size();
 int cost=0;for(int x:T){
  vector<int> p;for(int f=x;f;f=(f-1)&x)if(freeval[f])p.push_back(f);
  bool sub=false;for(int y:T)if(x!=y){int v=x&y;if(v==x){sub=true;break;}if(v)p.push_back(v);}
  cost+=sub?1:max(1,covering(x,p)-1);
  if(cost>stop)break;
 }return cost;
}
long nodes=0;
set<pair<vector<int>,int>> failed;
bool exact(vector<int> T,int n) {
 T.erase(remove_if(T.begin(),T.end(),[](int x){return freeval[x];}),T.end());
 sort(T.begin(),T.end());T.erase(unique(T.begin(),T.end()),T.end());
 if(T.empty())return true;
 if(n<=0 || T.size()>unsigned(n) || failed.contains({T,n}))return false;
 nodes++;auto next=T;int x=next.back();next.pop_back();
 for(int y=(x-1)&x;y;y=(y-1)&x){
  int need=x&~y;
  for(int more=y;;more=(more-1)&y){
   int z=need|more;
   if(z<x && y<=z){auto sub=next;sub.push_back(y);sub.push_back(z);if(exact(sub,n-1))return true;}
   if(!more)break;
  }
 }
 failed.insert({T,n});return false;
}
int main(){
 // bits 0..2 T-only, 3..5 V-only, 6 common, 7 and 8 tags.
 for(int i=0;i<9;i++)freeval[1<<i]=true;
 for(int i=0;i<3;i++)for(int j=3;j<6;j++)freeval[1<<i|1<<j]=true;
 freeval[0]=true;array<int,4>s={384,127,71|256,120|128};sort(s.begin(),s.end());
 int live=0,ncase=0,best=20;
 do{
  int f=s[0],d=s[1],a=s[2],b=s[3];
  int em=d&a&b;for(int e=em;;e=(e-1)&em){
   int cm=a&b;for(int c=cm;;c=(c-1)&cm){
    int rm=c|e,k=int(bool(c))+int(bool(e)),dc=d&e,ac=a&rm,bc=b&rm;
    for(int di=dc;;di=(di-1)&dc){
     for(int ai=ac;;ai=(ai-1)&ac){
      for(int bi=bc;;bi=(bi-1)&bc){
       vector<int> term={f,(d&~e)|di,(a&~rm)|ai,(b&~rm)|bi,c,e};int l=lb(term,5-k);ncase++;
       best=min(best,k+l);
       if(exact(term,5-k)){live++;if(live<5)printf("open %d %d %d %d %d %d lb%d\n",term[0],term[1],term[2],term[3],c,e,k+l);}
       if(!bi)break;
      }if(!ai)break;
     }if(!di)break;
    }if(!c)break;
   }if(!e)break;
  }
 }while(next_permutation(s.begin(),s.end()));printf("all %d survivors %d minimum-capped %d\n",ncase,live,best);
}
