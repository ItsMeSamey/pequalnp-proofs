#include <array>
#include <bit>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;
int main(){
 int p,n;cin>>p>>n;vector<int>P(p),N(n);for(auto *v:{&P,&N})for(auto &r:*v){int a,b;cin>>a>>b;r=a+(b<<13);}
 vector<pair<int,int>> witnesses;
 for(int s=1;s<(1<<20);++s)if(popcount((unsigned)s)<=3){
  int available=(1<<20)-1;bool unsafe=false;
  for(int x:N)if((x&s)==s){unsafe=true;available&=~x;}
  if(unsafe)witnesses.push_back({s,available});
 }
 vector<set<int>> van(4);for(auto [s,a]:witnesses)van[popcount((unsigned)s)].insert(a);
 for(int t=1;t<=3;t++)cout<<"witness size "<<t<<" distinct opposite sets "<<van[t].size()<<'\n';
 for(int c=1;c<=5;c++){
  int r=6-c;array<int,4> topo{};array<int,4> single{};map<int,int> buckets;
  for(int choose=1;choose<(1<<20);choose++)if(popcount((unsigned)choose)==c){
   vector<int> rest;array<int,13> graph{};
   for(int m:P)if(!(m&choose)){rest.push_back(m);graph[countr_zero((unsigned)(m&8191))]|=m>>13;}
   array<bool,4> ok{};
   for(int k=1;k<=3;k++)for(int v:van[k]){
    bool cover=true;for(int row:rest)if(!(row&v)){cover=false;break;}
    if(cover){ok[k]=true;break;}
   }
   if(!(ok[1]||ok[2]||ok[3]))continue;
   // Min/max closure of each negative independent set in the residual graph.
   array<int,128> low{};for(int t=0;t<128;t++){int b=0;for(int m:graph)if(!(t&m))b|=m;low[t]=127^b;}
   set<int> forced;for(int x:N){int b=0;unsigned a=x&8191;while(a){b|=graph[countr_zero(a)];a&=a-1;}if(low[x>>13]==(127^b))forced.insert(127^b);}
   buckets[forced.size()]++;if(c==5 && forced.size()<=5){if(choose&8191){printf("unexpected(point) %d\n",choose);return 4;}}
   for(int k=1;k<=3;k++)if(ok[k]){
    topo[k]+=forced.size()<=unsigned(1+4*((1<<r)-1));
    single[k]+=forced.size()<=unsigned(1+3*((1<<r)-1));
   }
  }
  cout<<"centers "<<c<<" histogram";for(auto [h,k]:buckets)cout<<" "<<h<<":"<<k;
  cout<<" single";for(int k=1;k<=3;k++)cout<<" "<<single[k];
  cout<<" double";for(int k=1;k<=3;k++)cout<<" "<<topo[k];cout<<'\n';
 }
}
