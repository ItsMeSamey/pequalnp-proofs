from itertools import combinations
xs=list(map(int,open('native.in').read().split()));p,n=xs[:2]
vals=[a|(b<<13) for a,b in zip(xs[2::2],xs[3::2])]
P=set(vals[:p]);N=vals[p:]
S=[sum(e&8191 for e in P if e&(1<<(13+i)))for i in range(7)]
assert all(t.bit_count()==4 for t in S)
assert all((t&v).bit_count()==1 for t,v in combinations(S,2))
assert max(sum(bool(t&(1<<i))for t in S)for i in range(13))==3
assert all((t&m).bit_count()<=1 for t in S for m in (129,4160))
for i,j in combinations(range(20),2):
 m=(1<<i)|(1<<j)
 if m not in P:assert any(not m&~n for n in N)
assert all(any(n>>i&1 for n in N)for i in range(20))
for i in range(20):
 assert any(n>>i&1 for n in N)
print('28 positives, 468 negative patterns, all 162 nonedges dominated; seven size-four stars intersect once; point incidence at most three.')
