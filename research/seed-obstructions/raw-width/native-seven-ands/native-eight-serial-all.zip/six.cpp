#include <array>
#include <bit>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
int main(){
 int a,b;cin>>a>>b;vector<int>P(a),N(b);for(auto *v:{&P,&N})for(int& w:*v){int p,t;cin>>p>>t;w=p|t<<13;}
 for(int c=0;c<=6;c++){
  map<pair<int,int>,int> hist;
  for(int m=0;m<(1<<20);m++)if(popcount((unsigned)m)==c){
   array<int,13> g{};for(int e:P)if(!(e&m))g[countr_zero((unsigned)(e&8191))]|=e>>13;
   array<int,128> l{};for(int t=0;t<128;t++){int v=0;for(int q:g)if(!(q&t))v|=q;l[t]=127^v;}
   int sets=0;array<bool,128> h{};for(int x:N){int n=0;unsigned p=x&8191;while(p){n|=g[countr_zero(p)];p&=p-1;}
    int k=127^n;if(k==l[x>>13] && !h[k]){h[k]=true;if(++sets>4)break;}}
   if(sets<=4){hist[{popcount((unsigned)(m>>13)),sets}]++;if(c==6)cout<<"viable "<<m<<" "<<sets<<"\n";}
  }
  cout<<"centers "<<c;for(auto [p,n]:hist)cout<<" t"<<p.first<<"/f"<<p.second<<":"<<n;cout<<"\n";
 }
}
