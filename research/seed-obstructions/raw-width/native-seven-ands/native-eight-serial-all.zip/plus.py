from itertools import combinations
from collections import Counter
x=list(map(int,open('native.in').read().split()));n,m=x[:2];raw=[p|t<<13 for p,t in zip(x[2::2],x[3::2])];P,N=raw[:n],raw[n:]
def f(E):
 graph=[0]*13
 for e in E:graph[(e&8191).bit_length()-1]|=e>>13
 low={}
 for t in set(n>>13 for n in N):
  u=0
  for b in graph:
   if not b&t:u|=b
  low[t]=127^u
 out=set()
 for n in N:
  u=0;i=n&8191
  while i:
   s=i&-i;i-=s;u|=graph[s.bit_length()-1]
  if low[n>>13]==127^u:out.add(127^u)
 return len(out)
H=Counter()
for u,v in combinations(range(7),2):
 S=[p for p in P if p>>13 & (1<<u|1<<v)]
 for q in set(P)-set(S):
  H[f(S+[q])]+=1
print(H)
