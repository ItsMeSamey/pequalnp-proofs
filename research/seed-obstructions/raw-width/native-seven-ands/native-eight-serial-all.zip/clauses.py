exec(open('plus.py').read().split('H=Counter()')[0])
def ors(S):
 b=0
 for s in S:b|=s
 return b
def chart(u,v):
 E=[p for p in P if p&(1<<(13+u)|1<<(13+v))]
 V=ors(E);M=(1<<(13+u),1<<(13+v));A,B=[ors(p&8191 for p in E if p&t) for t in M]
 allowed=(M[0]|M[1],A|B,A|M[1],B|M[0])
 ns={n&V for n in N}
 forced=[{n for n in ns if not n&K and all(n&L for L in allowed if L!=K)}for K in allowed]
 return E,V,allowed,[V^ors(group) for group in forced]
if __name__=='__main__':
 for u,v in combinations(range(7),2):
  E,V,a,b=chart(u,v);print(u,v,list(x==y for x,y in zip(a,b)),[sorted({x for x in E if not x&z})for z in b]if not all(x==y for x,y in zip(a,b)) else '')
