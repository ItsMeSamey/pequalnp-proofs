exec(open('plus.py').read().split('H=Counter()')[0])
from functools import lru_cache
from itertools import product
def minimal(es):
 E=sorted(es);ids=tuple(ors for ors in product(*(tuple((p&8191,p&(127<<13)))for p in E)))
 K=set()
 for cc in ids:
  m=0
  for x in cc:m|=x
  K.add(m)
 K={k for k in K if not any(h!=k and not h&~k for h in K)}
 types={sum(1<<j for j,k in enumerate(K)if not k&n)for n in N}
 mins=tuple(t for t in types if not any(h!=t and not h&~t for h in types))
 @lru_cache(None)
 def solve(B):
  if not B:return 0
  t=min(B,key=int.bit_count)
  return 1+min(solve(tuple(x for x in B if x&b==0))for j in range(t.bit_length())if t>>j&1 for b in [1<<j])
 return solve(mins)
h=Counter()
for es in combinations(P,3):
 if len({p&8191 for p in es})==len({p>>13 for p in es})==3:h[minimal(es)]+=1
print(h)
