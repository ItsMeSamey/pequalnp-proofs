from itertools import combinations
from nativecontrol import rows

points=[1,4,64,128,256,512,1024,2048,4096]
private=(2,4,8,32)
edges={(p,t) for p,t,y in rows if y==1}
N={p|t<<13 for p,t,y in rows if y<0}
assert len(N)==468 and len(edges)==28
count=0
for backed in private:
    for unbacked in private:
        if backed==unbacked:continue
        atom=points+[v<<13 for v in (1,16,64,backed)]
        star=sum(p for p,t in edges if t==unbacked)
        for k in (1,2,3):
            for sub in combinations(atom,k):
                m=sum(sub)
                if any(not m&~n for n in N):
                    assert any(not m&~n and n&star for n in N)
                    count+=1
for p,t in edges:
    assert any(not p&~n for n in N)
for a,b in combinations(range(13),2):
    assert any(not ((1<<a)|(1<<b))&~n for n in N)
print('three-atom/smaller unsafe extensions',count)
