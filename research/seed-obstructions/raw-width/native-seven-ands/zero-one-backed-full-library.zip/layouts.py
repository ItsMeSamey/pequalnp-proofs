from five import *
from ast import literal_eval
from functools import cache
from random import Random
from collections import Counter
from pathlib import Path
STARS={j:sum({p for p,t,s in rows if s==1 and t==j})for j in (2,4,8,32)}
priv=[j for j in STARS if j!=u];neglist=sorted({(p,t)for p,t,s in rows if s<0})
sample=neglist+[(1<<j,0)for j in range(13)]
raw=[sum(1<<i for i,(p,t)in enumerate(sample) if x&(p|t<<13)) for x in atoms]
zonal={j:sum(1<<i for i,(p,t) in enumerate(neglist)if t&j)for j in priv}
@cache
def rawvals(m):return 0 if not m else raw[(m&-m).bit_length()-1]|rawvals(m&(m-1))
@cache
def conv(m):
    if not m:return 0
    j=(m&-m).bit_length()-1
    return (atoms[j] if j<ND else 1<<(20+j-ND))|conv(m&(m-1))
def sets(w):
    H=[]
    for ar in w[:2]:
        def eval(m):
            v=rawvals(m&((1<<ND)-1))
            for j,x in enumerate(H):
                if m>>(ND+j)&1:v|=x
            return v
        H+=[eval(ar[0])&eval(ar[1])]
    ret=[]
    for j in priv:
        lo=hi=STARS[j]
        for g,v in enumerate(H):
            if v&zonal[j]:continue
            hi|=1<<(20+g);lo&=~(v>>len(neglist))
        ret.append((lo,hi))
    for ab in w:
        for x in ab:
            if x.bit_count()>1:ret.append((conv(x),conv(x)))
    return tuple(sorted(set(ret)))
@cache
def cover(q,bs):
    if not q:return 0
    i=q&-q
    return 1+min(cover(q&~v,bs)for v in (i,*bs)if v&i)
def cost(req,gr):
    if not req:return 0
    bs=tuple(sorted({v&req for v in gr if (v&req).bit_count()>1}))
    return cover(req,bs)-1
def bound(T):
    n=len(T);rr=Random(7);orders=[list(range(n)),list(reversed(range(n))),sorted(range(n),key=lambda i:-T[i][0].bit_count()),sorted(range(n),key=lambda i:T[i][0].bit_count())]
    for _ in range(12):
        a=list(range(n));rr.shuffle(a);orders.append(a)
    result=0
    for a in orders:
        k=0;prior=[]
        for i in a:
            lo,hi=T[i];k+=cost(lo,prior+[v for v in (129,4160)if not(v&~hi)]);prior.append(hi)
        result=max(result,k)
        if result>=21:return result
    return result
def lex():
    for g in range(4):
        pref=None
        for j in range(ND+min(g,2)):
            a=term(g,0,j);b=term(g,1,j);pre=[] if pref is None else [-pref]
            sat.add_clause(pre+[-a,b]);new=v('eq',g,j)
            sat.add_clause(pre+[-a,-b,new]);sat.add_clause(pre+[a,b,new]);pref=new
def jobs():
    for l in Path(f'five-{q}.log').read_text().splitlines():
        if not l.startswith(('literal ','exclusive ')):continue
        m,r=l.split(' ',1);z,ss=r.split(') ',1);k=literal_eval(z+')')
        swap=tuple((a&3)|((a&4)<<1)|((a&8)>>1) for a in k)
        if ss!='False' and k<=swap:yield m,k
def samplelayouts(m,k,cap):
    asp=cs(k)+([-term(4,0,ND),-term(4,0,ND+1)] if m=='literal' else [anyexc])
    fresh=v('activate',m,*k);h=Counter()
    for i in range(cap):
        w=query(asp+[fresh])
        if w is False:return i,h,'complete'
        if w is None:return i,h,'budget'
        h[bound(sets(w))]+=1
        sat.add_clause([-fresh]+[(-1 if w[g][s]>>j&1 else 1)*term(g,s,j) for g in range(5)for s in (0,1)for j in range(ND+min(g,2))])
    return cap,h,'open'
if __name__=='__main__':
    lex()
    for m,k in jobs():
        if len(sys.argv)>3 and (m,k[-1])!=(sys.argv[3],int(sys.argv[4])):continue
        n,h,st=samplelayouts(m,k,int(sys.argv[2]));print(m,k,n,st,sorted(h.items()),flush=True)
