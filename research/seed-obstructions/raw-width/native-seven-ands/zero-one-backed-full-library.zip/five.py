from nativecontrol import rows
from itertools import combinations, permutations, product
from pysat.formula import IDPool
from pysat.solvers import Cadical195
from collections import Counter
import sys
q=int(sys.argv[1]);u={2:32,8:2,16:4,32:8}[q]
point=[1,4,64,128,256,512,1024,2048,4096]
ordinary=[1,16,64];tags=ordinary+[u]
atoms=point+[t<<13 for t in tags]+[q]
NPTS=9; ND=len(atoms)
D0=list(range(4))
native={t:sum({p for p,j,s in rows if s==1 and j==t}) for t in tags}
def pack(p,t):return sum(1<<i for i,a in enumerate(atoms) if (p|t<<13)&a)
tt=[pack(0,t) for t in tags]
P={pack(p,t) for p,t,s in rows if s==1 and t in tags}
Pord=sorted(pack(p,t) for p,t,s in set(rows) if s==1 and t in ordinary)
neg={pack(p,t) for p,t,s in rows if s<0}
N={k for k in neg if not any(k!=l and k&~l==0 for l in neg)}
probes=P|N|{1<<i for i in range(ND)}|{a|b for a,b in combinations(tt,2)}
ids=IDPool();v=lambda *a:ids.id(a)
cnf=[]
def And(y,ls):
    cnf.append([y]+[-x for x in ls]);cnf.extend([-y,x] for x in ls)
def Or(y,ls):
    cnf.append([-y]+ls);cnf.extend([y,-x] for x in ls)
def term(g,s,j):return v('term',g,s,j)
def arm(g,s,n):return v('arm',g,s,n)
def site(g,n):return v('site',g,n)
def hot(g,n):return v('hot',g,n)
def no(x):cnf.append([-x])
for g in range(4):
    for s in range(2):no(term(g,s,13))
for j,x in enumerate(atoms):
    if x!=u<<13:no(term(4,0,j))
    if x not in point+[q] or not x&native[u]:no(term(4,1,j))
cnf+=[[term(4,0,12)],[term(4,1,13)]]
for n in sorted(probes):
    for g in range(5):
        for s in range(2):
            yy=[term(g,s,j) for j in range(ND) if n>>j&1]
            for i in range(min(g,2)):
                y=v('conj',g,s,i,n);And(y,[term(g,s,ND+i),site(i,n)]);yy.append(y)
            Or(arm(g,s,n),yy)
        ax=[arm(g,s,n) for s in range(2)]
        And(site(g,n),ax);Or(hot(g,n),ax)
    if n in P:cnf.append([site(g,n) for g in (2,3,4)])
    if n in N:cnf.extend([-site(g,n)] for g in (2,3,4))
for g in range(2):cnf.append([site(g,n) for n in sorted(N)])
for n in tt:
    for g in range(5):no(site(g,n))
    for gg in combinations(range(5),3):cnf.append([-hot(g,n)for g in gg])
for a,b in combinations(tt,2):
    for gg in combinations(range(5),4):cnf.append([-hot(g,a|b)for g in gg])
for n in tt:
    cnf.append([hot(g,n) for g in range(4)])
for i,j in combinations(range(3),2):
    for g in range(4):
        cnf.append([hot(h,tt[i])for h in range(4)if h!=g]+[hot(h,tt[j])for h in range(4)if h!=g])
for G in combinations(range(4),2):
    cnf.append([hot(h,n)for h in range(4)if h not in G for n in tt[:3]])
exc=[]
for n in Pord:
    y=v('exclusive',n);And(y,[site(4,n),-site(2,n),-site(3,n)]);exc.append(y)
anyexc=v('anyexclusive');Or(anyexc,exc)
sat=Cadical195(bootstrap_with=cnf)
def query(asp,budget=2000):
    sat.conf_budget(budget);b=sat.solve_limited(assumptions=asp)
    if b is not True:return b
    M=set(sat.get_model())
    return [[sum(1<<j for j in range(ND+min(g,2)) if term(g,s,j) in M)for s in (0,1)]for g in range(5)]
def cs(k):
    return [(1 if m>>g&1 else -1)*hot(g,n) for n,m in zip(tt,k) for g in range(4)]
def domain():
    opts=[j for j in range(1,16)if j.bit_count()<=2]
    for k in product(opts,repeat=3):
        if any((i|j).bit_count()>3 for i,j in combinations(k,2)):continue
        if not any(all(m>>h&1 for m,h in zip(k,p))for p in permutations(range(4),3)):continue
        for s in range(4):
            if all((m|(1<<s)).bit_count()<=2 for m in k):yield k+(1<<s,)
if __name__=='__main__':
    ks=list(domain());print(q,u,'domains',len(ks),'positives',len(P),'negatives',len(N))
    for mode,st in [('literal',[-term(4,0,ND),-term(4,0,ND+1)]),('exclusive',[anyexc])]:
        for k in ks:
            print(mode,k,query(cs(k)+st),flush=True)
