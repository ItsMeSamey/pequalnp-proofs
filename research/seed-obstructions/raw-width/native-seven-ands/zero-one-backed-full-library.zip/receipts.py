from ast import literal_eval
from five import *
from pathlib import Path
from collections import defaultdict,Counter
def row_eval(w,p,t):
    v=pack(p,t);sites=[]
    for g,ab in enumerate(w):
        s=[bool(m&v) for m in ab];sites.append(s)
        if all(s):v|=1<<(ND+g)
    return sites
def check(w,k,mode):
    dirty=set();ex=False
    for p,t,y in rows:
        ss=row_eval(w,p,t);live={g for g,s in enumerate(ss)if all(s)}
        priv=any(t&j and p&sum({x for x,z,s in rows if s==1 and z==j}) for j in (2,4,8,32)if j!=u)
        assert not y or (bool(live&{2,3,4} or priv)==(y==1))
        if y<0:dirty|=live
        if y==1 and t in ordinary and live&{2,3,4}=={4}:ex=True
    assert dirty=={0,1}
    for j,t in enumerate(tags):
        assert k[j]==sum(1<<g for g,s in enumerate(row_eval(w,0,t)[:4]) if any(s))
    if mode=='literal':assert w[4][0]==(1<<12)
    else:assert ex
def read():
    seen={};counts=Counter()
    for l in Path(f'five-{q}.log').read_text().splitlines():
        if not l.startswith(('literal ','exclusive ')):continue
        mode,r=l.split(' ',1);z,ss=r.split(') ',1);k=literal_eval(z+')');w=literal_eval(ss)
        assert w is not None and (mode,k) not in seen;seen[mode,k]=w
        if w is False:continue
        check(w,k,mode);counts[mode,k[-1],sum(x.bit_count()==2 for x in k[:3])]+=1
    assert set(seen)==set(product(('literal','exclusive'),domain()))
    return seen,counts
if __name__=='__main__':seen,counts=read();print(q,u,len(seen),sorted(counts.items()))
