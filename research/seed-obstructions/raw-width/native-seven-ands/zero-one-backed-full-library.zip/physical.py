from receipts import row_eval
from five import *
from pathlib import Path
from ast import literal_eval
import json
pairs=list((1<<j,0)for j in range(13))+list((0,1<<j)for j in range(7))
def build(w):
    if any(not m for ab in w for m in ab):return None
    nets=[]; cache={}
    def gate(op,l,r):
        net=(op,min(l,r),max(l,r))
        if op=='or' and net in cache:return cache[net]
        i=len(nets)+20;nets.append(net)
        if op=='or':cache[net]=i
        return i
    def merge(bits):
        src=sorted(set(bits))
        while len(src)>1:
            for a,b in combinations(src,2):
                if ('or',a,b) in cache:break
            else:a,b=src[0],src[1]
            src.remove(a);src.remove(b);z=gate('or',a,b)
            if z not in src:src.append(z);src.sort()
        return src[0]
    wires=[x.bit_length()-1 for x in atoms]; sites=[]
    for g,ab in enumerate(w):
        ar=[merge(wires[j] for j in range(ND+min(g,2))if bits>>j&1)for bits in ab]
        sites+=[gate('and',*ar)]
        if g<2:wires.append(sites[-1])
    for j in [t for t in (2,4,8,32) if t!=u]:
        U={p.bit_length()-1 for p,t,sgn in rows if t==j and sgn==1}
        sites.append(gate('and',13+j.bit_length()-1,merge(U)))
    out=merge(sites[2:])
    def evaluate(p,t):
        z=p|t<<13
        for i,(op,l,r) in enumerate(nets,20):
            h=z>>l&1 and z>>r&1 if op=='and' else (z>>l|z>>r)&1
            z|=h<<i
        return z
    dirty=set()
    for p,t,s in rows:
        z=evaluate(p,t)
        if s:assert bool(z>>out&1)==(s==1)
        if s<0:dirty.update(g for g in sites if z>>g&1)
    assert dirty==set(sites[:2])
    def touches(p,t):
        z=evaluate(p,t)
        return {i for i in sites if (z>>nets[i-20][1]|z>>nets[i-20][2])&1}
    private_tags=[u]+[v for v in (2,4,8,32) if v!=u]
    private_points={v:p for p,v in ((2,32),(8,2),(16,4),(32,8))}
    for j,private_site in zip(private_tags,sites[4:]):
        assert touches(private_points[j],0)=={private_site}
        if j==u:assert private_site in touches(0,j) and len(touches(0,j))==2
        else:assert touches(0,j)=={private_site}
    for a,b in combinations((1,2,4,8,16,32,64),2):
        assert len(touches(0,a|b))<=3

    return len(nets),nets,out,sites
if __name__=='__main__':
    dst={}
    for l in Path(f'five-{q}.log').read_text().splitlines():
        if not l.startswith(('literal ','exclusive ')) or l.endswith('False'):continue
        m,r=l.split(' ',1);k,a=r.split(') ',1);k=literal_eval(k+')');w=literal_eval(a);g=build(w)
        if g and ((m,k[-1]) not in dst or g[0]<dst[m,k[-1]][0]):dst[m,k[-1]]=(g[0],k,w,g[1:])
    Path(f'physical-{q}.json').write_text(json.dumps([[m,k,*r]for (m,k),r in sorted(dst.items())],separators=(',',':')))
    print(q,sorted((m,k,r[0])for (m,k),r in dst.items()))
