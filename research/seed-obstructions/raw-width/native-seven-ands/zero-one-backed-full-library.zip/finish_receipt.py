from layouts import *
def countsfile(path):
    out={}
    for line in Path(path).read_text().splitlines():
        if not line.startswith(('literal ','exclusive ')):continue
        mode,x=line.split(' ',1);k,rest=x.split(') ',1);n,st,h=rest.split(' ',2)
        key=mode,literal_eval(k+')');assert key not in out and st in ('open','complete')
        out[key]=int(n),st,dict(literal_eval(h))
    return out
seen=countsfile(f'price-{q}.log');extra=countsfile(f'extra-{q}.log')
assert set(seen)==set(jobs())
assert set(extra)=={k for k,(n,s,h)in seen.items()if s=='open'}
seen.update(extra);hist=Counter()
for k,(n,s,h) in seen.items():
    assert n==sum(h.values()) and 0<n<2500 and s=='complete' and min(h)>=21
    hist[k[0]]+=n
print('chart',q,'canonical keys',len(seen),'layouts',dict(hist),'worst preterminal lower bound',min(min(h) for n,s,h in seen.values()))
if 'replay' in sys.argv:
    lex()
    for (mode,k),(n,_,h) in seen.items():
        nu,hu,st=samplelayouts(mode,k,2500)
        assert st=='complete' and nu==n and dict(hu)==h
    print('complete fresh replay',q)
