from layouts import *
import ast
lex()
for line in Path(f'price-{q}.log').read_text().splitlines():
    if ' open ' not in line:continue
    m,rest=line.split(' ',1)
    k=literal_eval(rest.split(') ',1)[0]+')')
    n,h,st=samplelayouts(m,k,int(sys.argv[2]));print(m,k,n,st,sorted(h.items()),flush=True)
