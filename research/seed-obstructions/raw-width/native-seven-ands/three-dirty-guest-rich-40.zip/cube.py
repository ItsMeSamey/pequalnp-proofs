from nativecontrol import rows
from itertools import combinations, permutations
from collections import Counter
import json
private={2:32,8:2,16:4,32:8};ordt=(1,16,64)
edges={(p,t) for p,t,s in rows if s==1}
stars={t:sum(p for p,v in edges if v==t) for t in (*private.values(),*ordt)}
def minimal(masks):return {x for x in masks if not any(y!=x and y&x==y for y in masks)}
def build(q,a,b,extra):
    u=private[q];r=stars[u]&stars[a];assert r.bit_count()==1 and not r&stars[b]
    v,=[j for j in private.values() if j!=u and stars[j]&r]
    assert {x for x in stars if stars[x]&r}=={u,a,v}
    sites=[];nets=[]
    def gate(op,l,s):
        nets.append((op,l,s));z=19+len(nets)
        if op=='and':sites.append(z)
        return z
    def OR(*atoms):
        l=atoms[0]
        for s in atoms[1:]:l=gate('or',l,s)
        return l
    label=lambda t:13+t.bit_length()-1
    arms={j:OR(*[i for i in range(13) if U>>i&1])for j,U in stars.items()}
    A=gate('and',arms[b],OR(label(b),r.bit_length()-1))
    B=gate('and',OR(arms[a],A),OR(label(a),A))
    H=gate('and',OR(arms[u],B),OR(*[label(j)for j in ([u,a,b,v] if extra else [u,a,b])]))
    F=gate('and',H,OR(label(u),B))
    other={j:gate('and',label(j),arms[j]) for j in stars if j not in (a,b,u)}
    output=OR(F,*other.values())
    assert len(sites)==8 and len(nets)==40+extra
    mins=[{1<<i} for i in range(20)]
    for op,l,s in nets:
        x,y=mins[l],mins[s]
        mins.append(minimal(x|y if op=='or' else {i|j for i in x for j in y}))
    assert mins[output]=={p|t<<13 for p,t in edges}
    def val(p,t):
        z=p|t<<13
        for j,(op,l,s) in enumerate(nets,20):
            bit=(z>>l&z>>s)&1 if op=='and' else (z>>l|z>>s)&1
            z|=bit<<j
        return z
    def mark(p,t):
        z=val(p,t);return {g for g in sites if (z>>nets[g-20][1]|z>>nets[g-20][2])&1}
    dirt=set()
    for p,t,y in rows:
        z=val(p,t)
        if y:assert bool(z>>output&1)==(y==1)
        if y<0:dirt.update(g for g in sites if z>>g&1)
    assert dirt=={A,B,H}
    for p,j in private.items():assert mark(p,0)=={H if p==q else other[j]}
    assert mark(0,a)=={B,H} and mark(0,b)=={A,H} and mark(0,u)=={F,H}
    for j,g in other.items():assert mark(0,j)==({g,H}if extra and j==v else {g})
    assert all(not val(0,j)>>g&1 for j in stars for g in sites)
    assert all(len(mark(0,i|j))<=3 for i,j in combinations(stars,2))
    return q,u,a,b,v if extra else 0,nets,sites,output
records=[build(q,a,b,x) for q in private for a,b in permutations(ordt,2)for x in (0,1)]
open('cube-dags.json','w').write(json.dumps(records,separators=(',',':')))
print('physical full-cube controls',dict(Counter(len(z[5]) for z in records)))
