from find3 import *
for v,negset in safe.items():
    asafe=[-site(2,n) for n in negset]
    for guest in (3,5,6,7):
        A=asafe+[(1 if guest>>j&1 else -1)*hot(h,n) for j,n in enumerate(tt[:3])]
        print(q,h,v,guest,query(A,2500),flush=True)
