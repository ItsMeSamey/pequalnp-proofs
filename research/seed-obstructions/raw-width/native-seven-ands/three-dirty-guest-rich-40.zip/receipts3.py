from pathlib import Path
from ast import literal_eval
from itertools import permutations
from collections import Counter
import json

def load(p,k):
    ret={}
    for l in Path(p).read_text().splitlines():
        if not l or not l[0].isdigit():continue
        x=l.split(' ',k)
        key=tuple(map(int,x[:k]));assert key not in ret;ret[key]=literal_eval(x[k])
    return ret
def union(files,k):
    all={}
    for f in files:
        x=load(f,k);assert not(all.keys()&x.keys());all.update(x)
    return all
root=Path('.');qs=(2,8,16,32);mult=(3,5,6,7)
top=union(sorted(root.glob('top-*.log')),3)
assert set(top)=={(q,h,m) for q in qs for h in range(3) for m in (range(8) if h==2 else mult)}
bad={k for k,w in top.items() if w is None}
assert all(w is False or w is None for (q,h,m),w in top.items() if h<2 or m==7)
assert all(w for (q,h,m),w in top.items()if h==2 and m!=7)
sub=load('single-split.log',4)
assert set(sub)=={(q,h,g,b) for q,h,g in bad for b in [-1,*[i for i in range(5)if i!=h]]}
assert all(x is False for x in sub.values())
private={2:32,8:2,16:4,32:8}
safe=union(sorted(root.glob('safe-*.log')),4)
assert set(safe)=={(q,h,v,m) for q in qs for h in (0,1) for v in private.values()if v!=private[q] for m in mult}
assert all(w is None or w is False for w in safe.values())
sp=union(sorted(root.glob('split-safe-*.log')),6)
needed={k for k,w in safe.items() if w is None}
assert set(sp)=={(*k,a,b) for k in needed for a,b in permutations([g for g in range(5)if g!=k[1]],2)}
assert all(x is False for x in sp.values())
price=load('price-all.log',3)
assert set(price)=={(q,2,g) for q in qs for g in (3,5,6)}
assert all(n==sum(i for a,i in c)==96 and min(a for a,i in c)==28 and s=='complete' for n,c,s in price.values())
print('no grant cases',len(top),'initial unknowns',len(bad),'resolved leaves',len(sub))
print('signed safe grant cases',len(safe),'initial unknowns',len(needed),'resolved leaves',len(sp))
print('priced complete families',len(price),'formal operand layouts',sum(n for n,c,s in price.values()))
