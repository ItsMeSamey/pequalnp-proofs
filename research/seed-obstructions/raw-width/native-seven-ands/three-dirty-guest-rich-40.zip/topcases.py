from find3 import *
for guest in ([0,1,2,3,4,5,6,7] if h==2 else [3,5,6,7]):
    asp=[(1 if guest>>j&1 else -1)*hot(h,n) for j,n in enumerate(tt[:3])]
    print(q,h,guest,query(asp,7000),flush=True)
