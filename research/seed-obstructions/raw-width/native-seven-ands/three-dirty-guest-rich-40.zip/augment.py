import json
from itertools import combinations,permutations
from collections import Counter
from nativecontrol import rows
private={2:32,8:2,16:4,32:8}
def test(r,added):
    q,h,g,num,net,A,out,_=r;hn=A[h]
    # Attach fresh ORs to the tagged operand of H and renumber downstream uses.
    addn=len(added)
    shift=lambda i:i+addn if i>=hn else i
    L=net[hn-22][1];extra=[]
    for i,t in enumerate(added,hn):
        extra.append(['or',L,t.bit_length()-1+13]);L=i
    nn=net[:hn-22]+extra+[['and',L,net[hn-22][2]]]+[[o,shift(a),shift(b)]for o,a,b in net[hn-21:]]
    an=[shift(z) for z in A];out=shift(out)
    def val(p,t):
        z=p|t<<13|bool(p&129)<<20|bool(p&4160)<<21
        for i,(o,a,b) in enumerate(nn,22):
            y=(z>>a&z>>b)&1 if o=='and' else (z>>a|z>>b)&1
            z|=y<<i
        return z
    def mark(p,t):
        z=val(p,t);return {j for j,n in enumerate(an) if (z>>nn[n-22][1]|z>>nn[n-22][2])&1}
    dirt=set()
    for p,t,s in rows:
        z=val(p,t)
        if s and bool(z>>out&1)!=(s==1):return
        if s<0:dirt.update(j for j,n in enumerate(an)if z>>n&1)
    if dirt!={0,1,2}:return
    if not all(mark(p,0)=={j} for j,p in [(h,q)]+list(zip(range(5,8),[p for p in private if p!=q]))):return
    tags=(1,2,4,8,16,32,64)
    if any(len(mark(0,t))>2 or any(val(0,t)>>i&1 for i in an) for t in tags):return
    if any(len(mark(0,t|s))>3 for t,s in combinations(tags,2)):return
    return [q,h,g,added,len(nn),nn,an,out]
if __name__=='__main__':
    out=[]
    for r in json.load(open('native-controls.json')):
        for k in range(1,4):
            for a in combinations([t for t in private.values() if t!=private[r[0]]],k):
                y=test(r,a)
                if y:out.append(y)
    print('extra private-guest controls',len(out),Counter((r[2].bit_count(),len(r[3])) for r in out))
    open('added-controls.json','w').write(json.dumps(out,separators=(',',':')))
