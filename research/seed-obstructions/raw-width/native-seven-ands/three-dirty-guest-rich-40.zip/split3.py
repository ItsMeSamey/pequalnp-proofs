from find3 import *
guest=int(sys.argv[3])
base=[(1 if guest>>j&1 else -1)*hot(h,n) for j,n in enumerate(tt[:3])]
elsewhere=[g for g in range(5)if g!=h]
for b in [-1,*elsewhere]:
    a=base+[(1 if g==b else -1)*hot(g,tt[-1]) for g in elsewhere]
    print(q,h,guest,b,query(a,6000),flush=True)
