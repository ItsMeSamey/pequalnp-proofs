from find3 import *
from pathlib import Path
for l in Path(f'safe-{q}-{h}.log').read_text().splitlines():
    if not l.endswith(' None'):continue
    _,_,vg,m,_=l.split();vg,m=map(int,(vg,m));temp=[-site(2,n) for n in safe[vg]]
    temp +=[(1 if m>>j&1 else -1)*hot(h,n) for j,n in enumerate(tt[:3])]
    first=[tt[j] for j in range(3) if m>>j&1][:2]
    for ga,gb in permutations(ext,2):
        extra=[(1 if i==g else -1)*hot(i,n) for g,n in zip((ga,gb),first)for i in ext]
        print(q,h,vg,m,ga,gb,query(temp+extra,3500),flush=True)
