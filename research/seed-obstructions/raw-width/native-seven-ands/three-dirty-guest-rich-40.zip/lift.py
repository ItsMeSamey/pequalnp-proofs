from nativecontrol import rows
from itertools import combinations, permutations
from collections import Counter
from pathlib import Path
from ast import literal_eval
import json,sys
private={2:32,8:2,16:4,32:8}
ordinary=(1,16,64)
stars={t:sum({p for p,u,s in rows if s==1 and u==t}) for t in [*private.values(),*ordinary]}
pts=[1,4,64,128,256,512,1024,2048,4096]
def build(q,h,guest,model,donate=True):
    u=private[q];tlabels=[1,16,64,u]
    atom=pts+[t<<13 for t in tlabels]+[q]
    if any(not x for pair in model for x in pair):return
    source=[x.bit_length()-1 for x in atom]+[20,21,22]
    ar=[{source[j] for j in range(len(source)) if m>>j&1}for ab in model for m in ab]
    own=[j for j in private.values() if j!=u]
    for j in own:ar += [{13+j.bit_length()-1}, {i for i in range(13) if stars[j]>>i&1}]
    if donate:
        for j,pr in enumerate(((0,7),(6,12))):
            for a in ar:
                if set(pr)<=a:a.difference_update(pr);a.add(23+j)
    # Factor every repeated pair jointly, including across dirty levels.
    defs={}
    while any(len(a)>1 for a in ar):
        c=Counter(z for a in ar for z in combinations(sorted(a),2))
        pair=min(c,key=lambda z:(-c[z],z));k=25+len(defs);defs[k]=pair
        for a in ar:
            if set(pair)<=a:a.difference_update(pair);a.add(k)
    net=[]; known={**{i:i for i in range(20)},23:20,24:21};ands=[];marks={}
    def gate(op,l,r):net.append([op,l,r]);return 21+len(net)
    def phys(j):
        if j not in known:
            l,r=defs[j];known[j]=gate('or',phys(l),phys(r))
        return known[j]
    for g in range(8):
        l,=ar[2*g];r,=ar[2*g+1];z=gate('and',phys(l),phys(r));ands.append(z)
        if g<3:known[20+g]=z
    out=ands[3]
    for n in ands[4:]:out=gate('or',out,n)
    def evaluate(p,t):
        z=p|t<<13|bool(p&129)<<20|bool(p&4160)<<21
        for i,(op,l,r) in enumerate(net,22):
            val=z>>l&1 and z>>r&1 if op=='and' else (z>>l|z>>r)&1
            z|=val<<i
        return z
    def marked(p,t):
        z=evaluate(p,t)
        return {i for i,n in enumerate(ands)if (z>>net[n-22][1]|z>>net[n-22][2])&1}
    dirt=set()
    for p,t,s in rows:
        z=evaluate(p,t)
        if s and bool(z>>out&1)!=(s==1):return
        if s<0:dirt.update(j for j,n in enumerate(ands)if z>>n&1)
    if dirt!={0,1,2}:return
    if marked(q,0)!={h} or h not in marked(0,u):return
    if {i for i,t in enumerate(ordinary) if h in marked(0,t)}!={i for i in range(3)if guest>>i&1}:return
    for i,j in enumerate(own,5):
        p,=[p for p,x in private.items()if x==j]
        if marked(p,0)!={i} or marked(0,j)!={i}:return
    for t in stars:
        if len(marked(0,t))>2 or any(evaluate(0,t)>>n&1 for n in ands):return
    if not any(all(i in marked(0,t) for i,t in zip(pr,ordinary)) for pr in permutations([g for g in range(5) if g!=h],3)):return
    if any(len(marked(0,t|s))>3 for t,s in combinations(stars,2)):return
    return len(net),net,ands,out
def smaller(q,h,g,w):
    best=build(q,h,g,w)
    if not best:return
    for gate in range(5):
        for a in range(2):
            for j in reversed(range(14+min(3,gate))):
                if not w[gate][a]>>j&1:continue
                candidate=[z.copy() for z in w]
                candidate[gate][a]^=1<<j
                c=build(q,h,g,candidate)
                if c and c[0]<=best[0]:best=c;w=candidate
    for d in (False,True):
        c=build(q,h,g,w,d)
        if c and c[0]<best[0]:best=c
    return best,w
if __name__=='__main__':
    best={}
    for f in sorted(Path('.').glob('top-*.log'))+sorted(Path('.').glob('probe-*.log')):
        for l in f.read_text().splitlines():
            if not l[0].isdigit() or '[[' not in l:continue
            q,h,g,w=l.split(' ',3);q,h,g=map(int,(q,h,g))
            r=smaller(q,h,g,literal_eval(w))
            assert r,(q,h,g)
            if (q,h,g) not in best or r[0][0]<best[q,h,g][0][0]:best[q,h,g]=r
    Path('native-controls.json').write_text(json.dumps([[q,h,g,*r[0],r[1]]for (q,h,g),r in sorted(best.items())],separators=(',',':')))
    print('physical verified',len(best),'prices',dict(sorted(Counter(r[0][0] for r in best.values()).items())))
    print('orders and guest counts',dict(sorted(Counter((h,g.bit_count()) for q,h,g in best).items())))
