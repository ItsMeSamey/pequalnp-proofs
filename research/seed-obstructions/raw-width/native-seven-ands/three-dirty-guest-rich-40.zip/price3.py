from find3 import *
from collections import Counter
from random import Random
from functools import cache
guest=int(sys.argv[3]);cap=int(sys.argv[4]);private=(2,4,8,32);own=[j for j in private if j!=u]
stars={j:sum({p for p,t,s in rows if t==j and s==1}) for j in [*private,*ordinary]}
negorig=sorted({(p,t)for p,t,s in rows if s<0});sample=negorig+[(1<<i,0)for i in range(13)]
raw=[sum(1<<i for i,(p,t)in enumerate(sample)if a&(p|t<<13))for a in atoms]
zones={t:sum(1<<i for i,(p,j)in enumerate(negorig)if j&t)for t in own}
@cache
def ev(m):return 0 if not m else raw[(m&-m).bit_length()-1]|ev(m&(m-1))
@cache
def cv(m):
    if not m:return 0
    i=(m&-m).bit_length()-1
    return cv(m&(m-1))|(atoms[i] if i<ND else 1<<(20+i-ND))
def intervals(w):
    d=[]
    for pair in w[:3]:
        def aval(m):
            z=ev(m&((1<<ND)-1))
            for i,x in enumerate(d):
                if m>>(ND+i)&1:z|=x
            return z
        d.append(aval(pair[0])&aval(pair[1]))
    T=[]
    for t in own:
        lo=hi=stars[t]
        for i,z in enumerate(d):
            if z&zones[t]:continue
            hi|=1<<(20+i);lo&=~(z>>len(negorig))
        T.append((lo,hi))
    for pair in w:
        for m in pair:
            if m.bit_count()>1:T.append((cv(m),cv(m)))
    return tuple(sorted(set(T)))
@cache
def cover(req,bs):
    if not req:return 0
    a=req&-req
    return 1+min(cover(req&~t,bs)for t in (a,*bs) if t&a)
def cost(T):
    rr=Random(7);n=len(T);orders=[list(range(n)),list(reversed(range(n))),sorted(range(n),key=lambda i:-T[i][0].bit_count()),sorted(range(n),key=lambda i:T[i][0].bit_count())]
    for _ in range(12):
        a=list(range(n));rr.shuffle(a);orders.append(a)
    best=0
    for order in orders:
        prev=[];score=0
        for i in order:
            lo,hi=T[i];gr=prev+[x for x in (129,4160) if not x&~hi]
            bs=tuple(sorted({lo&x for x in gr if (lo&x).bit_count()>1}))
            score+=max(0,cover(lo,bs)-1);prev.append(hi)
        best=max(best,score)
        if best>=28:break
    return best
def price():
    for g in range(5):
        if g==h:continue
        pref=None
        for j in range(ND+min(g,3)):
            a,b=term(g,0,j),term(g,1,j);pre=[] if pref is None else [-pref]
            sat.add_clause(pre+[-a,b]);new=v('eq',g,j)
            sat.add_clause(pre+[a,b,new]);sat.add_clause(pre+[-a,-b,new]);pref=new
    asp=[(1 if guest>>j&1 else -1)*hot(h,n) for j,n in enumerate(tt[:3])]
    hist=Counter()
    for i in range(cap):
        w=query(asp,5000)
        if w is not None and w is not False:
            hist[cost(intervals(w))]+=1
            sat.add_clause([(-1 if w[g][s]>>j&1 else 1)*term(g,s,j)for g in range(5)for s in range(2)for j in range(ND+min(g,3))])
        else:return i,sorted(hist.items()),'complete' if w is False else 'unknown'
    return cap,sorted(hist.items()),'limit'
if __name__=='__main__':print(q,h,guest,price(),flush=True)
