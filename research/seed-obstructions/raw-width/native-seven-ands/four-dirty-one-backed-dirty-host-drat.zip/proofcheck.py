from pathlib import Path
import argparse
import gzip
import hashlib
import subprocess
import tempfile
from pysat.solvers import Glucose4
from model import Model, ordinary

out=Path(__file__).resolve().parent/'proofs'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def run(args):
    models={}
    for H,B,j in ((H,B,j)for H in range(4) for B in range(H+1,5) for j in range(4)):
        key='-'.join(map(str,(H,B,j)))
        if args.case and key!=args.case:continue
        if H not in models:models[H]=Model(2,H)
        model=models[H]
        units=[model.hot(B,2)]+[(1 if i<j else -1)*model.hot(H,t) for i,t in enumerate(ordinary)]
        C=model.C+[[x]for x in units]
        cnf=('p cnf %d %d\n'%(model.base.top,len(C))+''.join(' '.join(map(str,c))+' 0\n' for c in C)).encode()
        archive=out/(key+'.drat.gz')
        if args.verify_only:
            proof=gzip.decompress(archive.read_bytes())
        else:
            with Glucose4(bootstrap_with=C,with_proof=True) as s:
                s.conf_budget(50000)
                ans=s.solve_limited()
                assert ans is False,(key,ans)
                proof=('\n'.join(s.get_proof())+'\n').encode()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);f=p/'c.cnf';g=p/'p.drat';f.write_bytes(cnf);g.write_bytes(proof)
            cmd=[args.drat_trim,str(f),str(g),'-t','30']
            if not args.verify_only:
                trimmed=p/'trimmed.drat'
                r=subprocess.run(cmd+['-l',str(trimmed),'-C'],capture_output=True,timeout=35)
                assert r.returncode==0 and b's VERIFIED' in r.stdout,(key,r.stdout[-400:])
                proof=trimmed.read_bytes()
                g.write_bytes(proof)
            r=subprocess.run(cmd+['-i'],capture_output=True,timeout=35)
            assert r.returncode==0 and b's VERIFIED' in r.stdout,(key,r.returncode,r.stdout[-400:])
        if not args.verify_only:
            out.mkdir(exist_ok=True)
            archive.write_bytes(gzip.compress(proof,compresslevel=6,mtime=0))
        print(key,len(C),len(proof),sha(cnf),sha(proof),'VERIFIED',flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('drat_trim');ap.add_argument('--verify-only',action='store_true');ap.add_argument('--case');run(ap.parse_args())
