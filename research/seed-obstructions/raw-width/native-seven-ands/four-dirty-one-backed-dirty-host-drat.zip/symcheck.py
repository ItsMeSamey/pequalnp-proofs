from itertools import permutations, product, combinations
from geometry import private, ordinary, stars, N0, edges, hostmasks

maxneg={n for n in N0 if not any(n!=m and n&~m==0 for m in N0)}
P={p|(t<<13) for p,t in edges}
by={frozenset(t for t in stars if p in stars[t]):p for p in set.union(*stars.values())}
group=[]
for a,b in product(permutations(private),permutations(ordinary)):
    tags=dict(zip(private+ordinary,a+b))
    try:
        points={p:by[frozenset(tags[t] for t in S)]for S,p in by.items()}
    except KeyError:
        continue
    pi={**points,**{t<<13:j<<13 for t,j in tags.items()}}
    def image(z):
        return sum(j for t,j in pi.items()if t&z)
    if {image(z)for z in maxneg}==maxneg and {image(z)for z in P}==P:
        group.append(tags)
assert len(group)==24 and len({tuple(g[t]for t in private) for g in group})==24
for u in private:
    S=hostmasks(u)
    for v,exc in S.items():
        assert len(exc)==17 and sum(m<8192 and m.bit_count()==4 for m in exc)==15
        assert sum(m>=8192 and m.bit_count()==5 for m in exc)==2
    assert all(len(a&b)==3 for a,b in combinations(S.values(),2))
    for k in range(4):
        for L in combinations(ordinary,k):
            assert any(g[u]==2 and {g[t] for t in L}==set(ordinary[:k]) for g in group)
print('native signed symmetries',len(group),'private tag permutations',24,'positive native masks',len(P),'maximal negative masks',len(maxneg))
print('all 12 lists: 15 pure quartets plus two tagged quintets; pairwise intersections for each u have three elements')
print('signed symmetries realize all guest-subset normalizations including all four backed tags')
