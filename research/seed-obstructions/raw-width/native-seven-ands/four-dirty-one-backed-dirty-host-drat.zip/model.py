from itertools import combinations
from geometry import *
from pysat.formula import IDPool
from pysat.solvers import Cadical195

class Model:
    def __init__(self,u,H):
        self.u=u; self.H=H; self.base=IDPool(); self.C=[]
        V=self.base.id;C=self.C
        self.wire=lambda g,s,x:V(('wire',g,s,x))
        wire=self.wire
        def Or(y,xs):
            C.append([-y,*xs]);C.extend([y,-x]for x in xs);return y
        def And(y,xs):
            C.append([y,*[-x for x in xs]]);C.extend([-y,x]for x in xs);return y
        raw=points+[q[u]]+[t<<13 for t in (*ordinary,u)]
        alphabet=sum(raw);Q=hostmasks(u);fullneg={n for n in N0 if not any(n!=m and not n&~m for m in N0)}
        self.probe=fullneg|{p|(v<<13)for p,v in edges}|set(points)|set(q.values())|{v<<13 for v in (*ordinary,*private)}|{(v|t)<<13 for v,t in combinations((*ordinary,*private),2)}|set.union(*Q.values())
        sites={}
        def dirty(g,s,m):return V(('darm',g,s,m&alphabet))
        def D(g,m):return V(('dirty',g,m&alphabet))
        for m in {m&alphabet for m in self.probe}:
            for g in range(4):
                a=[]
                for s in range(2):
                    opts=[wire(g,s,x)for x in raw if x&m]
                    opts.extend(And(V(('aux',g,s,h,m)),[wire(g,s,-1-h),D(h,m)])for h in range(g))
                    a.append(Or(dirty(g,s,m),opts))
                And(D(g,m),a)
        # Only the private dirty H receives q. Raw u and q are opposite there.
        C.extend([[wire(H,0,u<<13)],[wire(H,1,q[u])],[-wire(H,0,q[u])],[-wire(H,1,u<<13)]])
        for h in range(4):
            if h!=H:C.extend([[-wire(h,s,q[u])]for s in range(2)])
        # On u-high negatives, H must be false by the private q cut.
        C.extend([-D(H,n)] for n in fullneg if n&(u<<13))
        C.extend([-wire(H,1,x)] for x in raw if x not in stars[u])
        # Symmetry removal: compare arms as high-to-low bitstrings.
        for g in range(4):
            if g==H: continue
            prev=None
            for x in raw+[-h-1 for h in range(g)]:
                a,b=wire(g,0,x),wire(g,1,x)
                C.append(([ -prev]if prev is not None else [])+[-a,b])
                eq=V(('eq',g,x));C.extend([[-eq,-a,b],[-eq,a,-b],[eq,a,b],[eq,-a,-b]])
                prev=eq if prev is None else And(V(('pref',g,x)),[prev,eq])
        for g in range(4):C.append([D(g,n)for n in fullneg])
        self.skin={}
        for v in private:
            g=4+private.index(v);self.skin[v]=g
            if v!=u:C.extend([[wire(g,0,v<<13)],[wire(g,1,q[v])]])
            if v!=u:C.extend([wire(g,1,p)]for p in stars[v])
            # Site 4+index(u) is the sole exterior clean terminal F.
            for h in range(4):
                if v!=u:
                    w=wire(g,0,-1-h)
                    if h<2:C.append([-w]);continue
                    C.append([-w,*[D(h,m)for m in Q[v]]]);C.extend([-w,-D(h,n)]for n in fullneg if n&sum(stars[v]))
            for m in sorted(self.probe):
                a=[]
                for s in range(2):
                    R=([v<<13] if s==0 else sorted(stars[v])) if v!=u else [x for x in raw if x!=q[u]]
                    # Full semantic petals are available at every unbacked private terminal.
                    opts=[wire(g,s,x)for x in R if x&m]
                    opts.extend(And(V(('caux',g,s,h,m&alphabet)),[wire(g,s,-1-h),D(h,m)])for h in range(4))
                    a.append(Or(V(('carm',g,s,m)),opts))
                sites[g,m]=And(V(('clean',g,m)),a)
                if m in fullneg:C.append([-sites[g,m]])
                if v!=u and m in stars[v]:C.append([a[1]])
        for m in [p|(t<<13) for p,t in edges]:C.append([sites[4+j,m]for j in range(4)])
        hot={}
        for ts in list(combinations((*ordinary,*private),1))+list(combinations((*ordinary,*private),2)):
            m=sum(ts)<<13;hc=[]
            for g in range(8):
                a=[dirty(g,s,m) if g<4 else V(('carm',g,s,m))for s in range(2)]
                hc.append(Or(V(('hot',g,m)),a))
                if len(ts)==1:C.append([-(D(g,m)if g<4 else sites[g,m])])
            for ss in combinations(hc,2+len(ts)):C.append([-h for h in ss])
            hot[ts]=hc
        self.hot=lambda g,t:hot[(t,)][g]
        F=self.skin[u];self.F=F;ex=[h for h in range(4) if h!=H]+[F]
        ub=[hot[(u,)][h] for h in ex]
        C.append(ub);C.extend([-a,-b]for a,b in combinations(ub,2))
        # The backed site and the backup form a two-site cut of q+u.
        # The backup must activate there and must occur after H.
        for h in range(H):C.append([-self.hot(h,u)])
        qp=q[u]|(u<<13)
        for h in ex:
            b=self.hot(h,u);C.append([-b,(D(h,qp) if h<4 else sites[F,qp])])
            if h<4:C.extend([-b,-D(H,n),-D(h,n)]for n in fullneg)
        # Retain actual q singleton AND addresses, including propagation from H.
        for g in range(8):
            if g==H:continue
            for s in range(2):C.append([-(dirty(g,s,q[u]) if g<4 else V(('carm',g,s,q[u])))])
        for k in (1,2,3):
            for ts in combinations(ordinary,k):
                for hs in combinations(ex,k-1):C.append([self.hot(g,t)for t in ts for g in ex if g not in hs])
        self.D=D
        self.solver=Cadical195(bootstrap_with=C)
