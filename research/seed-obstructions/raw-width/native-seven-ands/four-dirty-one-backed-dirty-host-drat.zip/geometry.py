from itertools import combinations
from functools import cache
from nativecontrol import rows,edges
private=(2,4,8,32)
ordinary=(1,16,64)
stars={t:{p for p,v in edges if v==t} for _,t in edges}
q={u:next(p for p in stars[u] if sum(p in S for S in stars.values())==1) for u in private}
points=sorted(set.union(*stars.values())-set(q.values()))
N0={p|(t<<13) for p,t,y in rows if y<0}
@cache
def dominated(m):return any(m&~n==0 for n in N0)
def hostmasks(u):
    raw=points+[q[u]]+[t<<13 for t in (*ordinary,u)]
    return {v:{sum(z)for k in range(1,6)for z in combinations(raw,k)if dominated(sum(z)) and all(not dominated(sum(z)|p)for p in stars[v])}for v in private if v!=u}
