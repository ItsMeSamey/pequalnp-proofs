"""One explicit original-row control for each chart after only the 12 ordinary demands are dropped."""
from model import Model
from geometry import *
from pysat.solvers import Cadical195
from itertools import combinations,permutations

u=2
unbacked=[v for v in private if v!=u]
raw=points+[q[u]]+[t<<13 for t in (*ordinary,u)]
count=0
for H in range(4):
    M=Model(u,H);F=M.F
    remove={tuple(M.base.id(('clean',4+j,p|(t<<13))) for j in range(4))for p,t in edges if t in ordinary}
    assert len(remove)==12
    with Cadical195(bootstrap_with=[c for c in M.C if tuple(c)not in remove]) as relaxed:
        for B in range(H+1,5):
            for n in range(4):
                z=next(p for p in points if p not in stars[u])
                net={H:({u<<13}|{t<<13 for t in ordinary[:n]}|({z}if not n else set()),set(stars[u]))}
                priv={v:({v<<13},set(stars[v])) for v in unbacked}
                rest=[g for g in range(4)if g not in (H,B)]
                if B==F:
                    net[F]=({u<<13},{-1-H});offset=0
                else:
                    net[B]=({u<<13},{-1-H,z,ordinary[0]<<13})
                    net[F]=({-1-H},{-1-B});offset=1
                for j,g in enumerate(rest):
                    t=ordinary[j+offset];v=unbacked[j]
                    p=next(e for e in points if e in stars[v]-stars[t])
                    net[g]=({t<<13},{p});priv[v][1].add(-1-g)
                for v,S in priv.items():net[M.skin[v]]=S
                def evaluate(p,t):
                    m=p|(t<<13);vals=[];hot=[]
                    for g in range(8):
                        a,b=[any((bool(m&x) if x>0 else vals[-1-x])for x in S)for S in net[g]]
                        vals.append(a and b);hot.append(a or b)
                    return vals,{i for i,k in enumerate(hot)if k}
                dirty=set()
                for p,t,s in rows:
                    vals,hot=evaluate(p,t)
                    if s==-1:
                        assert not any(vals[4:]);dirty.update(i for i,z0 in enumerate(vals)if z0)
                    if s==1:assert any(vals[4:])==(t in private)
                assert dirty==set(range(4))
                assert evaluate(q[u],0)[1]=={H} and evaluate(0,u)[1]=={H,B}
                for v in unbacked:assert evaluate(0,v)[1]==evaluate(q[v],0)[1]=={M.skin[v]}
                for t in (*ordinary,*private):
                    vals,marks=evaluate(0,t);assert not any(vals) and len(marks)<=2
                assert all(len(evaluate(0,t|v)[1])<=3 for t,v in combinations((*ordinary,*private),2))
                assert any(all(g in evaluate(0,t)[1] for g,t in zip(sel,ordinary))for sel in permutations([g for g in range(5)if g!=H],3))
                assert {t for t in ordinary if H in evaluate(0,t)[1]}==set(ordinary[:n])
                pins=[]
                for g in range(8):
                    terms=net[g]
                    if g<4 and g!=H:
                        xs=raw+[-i-1 for i in range(g)]
                        terms=sorted(terms,key=lambda S:tuple(x in S for x in xs))
                    for s,S in enumerate(terms):
                        if g<4:xs=raw+[-i-1 for i in range(g)]
                        elif g==F:xs=[x for x in raw if x!=q[u]]+[-i-1 for i in range(4)]
                        else:
                            v=private[g-4]
                            xs=([v<<13]if s==0 else list(stars[v]))+[-i-1 for i in range(4)]
                        pins.extend((1 if x in S else -1)*M.wire(g,s,x)for x in xs)
                assert relaxed.solve(assumptions=pins),(H,B,n)
                assert not M.solver.solve(assumptions=pins)
                count+=1
print(count,'original-row controls satisfy all 624 indexed negatives, all 16 private-tag positives, dirty signs, actual singleton and pair caps, and the indicated chart')
print('all pinned CNFs SAT after removing only the 12 ordinary positive demands; all 40 UNSAT upon restoring them')
