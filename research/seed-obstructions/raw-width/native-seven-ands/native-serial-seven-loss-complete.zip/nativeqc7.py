from pathlib import Path
from sample import samples
rows,front,target=samples(Path(__file__).with_name('L-meta-18968.json'))
def fn(r,restore):
 h=bool(r&655360) and bool(r&4356)
 k=bool(r&262144) and (bool(r&2048) or h)
 terms=[((bool(r&1) or h) and bool(r&524288)),(bool(r&8192) and bool(r&708)),(bool(r&16384) and bool(r&1416)),(bool(r&32768) and bool(r&2832)),(bool(r&65536) and bool(r&5664)),((bool(r&131072) or k) and bool(r&3137))]
 if restore:terms.append(bool(r&262144) and bool(r&(4096|128|2)))
 return any(terms)
for repair in (False,True):
 high=[];low=[]
 for i,r in enumerate(rows):
  v=bool(front>>i&1) or fn(r&1048575,repair)
  expected=bool(target>>i&1)
  if v and not expected:high.append(i)
  if not v and expected:low.append(i)
 assert not high and (len(low)==0 if repair else len(low)>0)
 print('native 676 after repair',repair,'false positives',high,'false negatives',low)
