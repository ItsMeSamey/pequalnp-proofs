from signed import *
from pysat.solvers import Solver
from pysat.card import CardEnc, EncType
from pysat.formula import IDPool
import sys
from itertools import combinations
class CNF:
 def __init__(self):
  self.pool=IDPool();self.cl=[]
  self.one=self.new(); self.cl.append([self.one])
 def new(self):return self.pool.id()
 def c(self,b):return self.one if b else -self.one
 def AND(self,*xs):
  q=self.new()
  for x in xs:self.cl.append([-q,x])
  self.cl.append([q]+[-x for x in xs])
  return q
 def OR(self,*xs):return -self.AND(*[-x for x in xs])
 def atmost(self,xs,k):
  self.cl.extend(CardEnc.atmost(xs,k,vpool=self.pool,encoding=EncType.seqcounter).clauses)
 def choose(self,base,extra):
  vs=[self.new() for _ in range(len(base)+len(extra))]
  self.atmost(vs,1);self.cl.append(vs)
  return [self.OR(*[v for v,b in zip(vs,base) if b&a],*[self.AND(v,e[i]) for v,e in zip(vs[len(base):],extra)]) for i,a in enumerate(atoms)]
def run(ix,ex,limit,control=0):
 t,u=list(combinations(atoms[13:],2))[ix];p,=nbr[t]&nbr[u]
 terms=[(a,sum(nbr[a])) for a in atoms[13:] if a not in (t,u)]+[(p,t|u)]
 base={0,129,4160,*atoms,t|u}
 for v,w in terms:
  s=w
  while s:base.add(s);s=(s-1)&w
 base=sorted(base)
 f=CNF(); extra=[]
 for j in range(ex):
  r,s=[f.choose(base,extra) for _ in range(2)]
  extra.append([f.OR(a,b) for a,b in zip(r,s)])
 arms=[f.choose(base,extra) for _ in range(4)]
 kh=[f.new(),f.new()];f.cl.append(kh)
 taps=[[[f.new(),f.new()]for j in range(2)]for i in terms]
 for j in range(2):
  f.cl.append([taps[i][a][j]for i in range(6)for a in range(2)])
 for i in range(6):
  for j in range(2):f.cl.append([-taps[i][0][j],-taps[i][1][j]])
 for a in atoms[13:]:
  r=[arm[atoms.index(a)]for arm in arms]
  h=f.AND(r[0],r[1]);f.cl.append([-h])
  ht=f.OR(r[0],r[1]);kt=f.OR(r[2],r[3]);f.cl.append([-ht,-kt])
  if a in (t,u):
   if a==t:touch=[ht,kt]
   else:f.cl.append(touch+[ht,kt])
  k=f.AND(r[2],r[3])
  for i,(v,w) in enumerate(terms):
   if not (v|w)&a:
    for j in range(2):f.cl.append([-k,-taps[i][j][1]])
 def evaluate(row):
  a,b,c,d=[f.OR(*[arm[i]for i,v in enumerate(atoms)if row&v])for arm in arms]
  h=f.AND(a,b);k=f.AND(f.OR(c,f.AND(h,kh[0])),f.OR(d,f.AND(h,kh[1])))
  out=[]
  for (x,y),s in zip(terms,taps):
   vals=[f.OR(f.c(bool(row&z)),f.AND(h,dh),f.AND(k,dk)) for z,(dh,dk) in zip((x,y),s)]
   out.append(f.AND(*vals))
  return h,k,out
 neg=[evaluate(n)for n in N]
 for _,_,out in neg:
  for z in out:f.cl.append([-z])
 for i in range(2):f.cl.append([v[i]for v in neg])
 for e in P:
  if not control and not any(e&x and e&y for x,y in terms): f.cl.append(evaluate(e)[2])
 with Solver(name='cadical195',bootstrap_with=f.cl) as sol:
  sol.conf_budget(limit)
  ans=sol.solve_limited()
  print(ix,ex,ans,sol.accum_stats()['conflicts'], flush=True)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
