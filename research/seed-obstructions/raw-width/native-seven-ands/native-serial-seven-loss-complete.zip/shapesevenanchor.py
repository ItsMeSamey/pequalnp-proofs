from screen import *
def run(ix,ex,limit,control=0):
 centers=bm(ix)
 terms=[(c,sum(nbr[c])) for c in centers]
 assert len(terms)==6 and sum(bool(c&8191)for c in centers)==1
 base={0,129,4160,*atoms}
 for c,n in terms:
  sub=n
  while sub:base.add(sub);sub=(sub-1)&n
 base=sorted(base)
 f=CNF();extra=[]
 drops={(c,v):f.new() for c,n in terms for v in bm(n)}
 retained=[]
 for e in P:
  retained.append(f.OR(*[-q for (c,v),q in drops.items()if c|v==e]))
 f.cl.extend(CardEnc.equals(retained,21,vpool=f.pool,encoding=EncType.seqcounter).clauses)
 for c,n in terms:f.cl.append([-drops[c,v]for v in bm(n)])
 for j in range(ex):
  r,s=[f.choose(base,extra) for _ in range(2)]
  extra.append([f.OR(a,b) for a,b in zip(r,s)])
 arms=[f.choose(base,extra) for _ in range(4)]
 kh=[f.new(),f.new()];f.cl.append(kh)
 taps=[[[f.new(),f.new()]for j in range(2)]for i in terms]
 for j in range(2):
  f.cl.append([taps[i][a][j]for i in range(6)for a in range(2)])
 for i in range(6):
  for j in range(2):f.cl.append([-taps[i][0][j],-taps[i][1][j]])
 # Both exposed gates have only one first nonempty merge apiece.
 for j in range(2):
  anchor=[f.new()for _ in atoms];f.cl.append(anchor)
  for i,(v,w) in enumerate(terms):
   for d,r in enumerate((v,w)):
    for a,sel in zip(atoms,anchor):
     if not r&a:f.cl.append([-sel,-taps[i][d][j]])
     elif d:f.cl.append([-sel,-taps[i][d][j],-drops[v,a]])
  if j==0:
   for arm,uses in zip(arms[2:],kh):
    nonzero=f.OR(*arm)
    for bit,sel in zip(arm,anchor):f.cl.append([-sel,-uses,-nonzero,bit])
 matches=[]
 for a in atoms[13:]:
  r=[arm[atoms.index(a)]for arm in arms]
  f.cl.append([-r[0],-r[1]])
  ht=f.OR(r[0],r[1]);kt=f.OR(r[2],r[3]);k=f.AND(r[2],r[3])
  touch=[ht,kt]
  for (v,w),tw in zip(terms,taps):
   raw=f.one if v==a else (-drops[v,a] if w&a else -f.one)
   touch.append(f.OR(raw,f.AND(k,f.OR(tw[0][1],tw[1][1]))))
  f.atmost(touch,2)
  match=[f.new()for q in touch];f.cl.append(match)
  for z,q in zip(match,touch):f.cl.append([-z,q])
  matches.append(match)
 for slot in zip(*matches):f.atmost(list(slot),1)
 def evaluate(row):
  a,b,c,d=[f.OR(*[arm[i]for i,v in enumerate(atoms)if row&v])for arm in arms]
  h=f.AND(a,b);k=f.AND(f.OR(c,f.AND(h,kh[0])),f.OR(d,f.AND(h,kh[1])))
  out=[]
  for (x,y),s in zip(terms,taps):
   vals=[f.OR((f.c(bool(row&z)) if z==x else f.OR(*[-drops[x,v] for v in bm(y&row)])),f.AND(h,dh),f.AND(k,dk)) for z,(dh,dk) in zip((x,y),s)]
   out.append(f.AND(*vals))
  return h,k,out
 neg=[evaluate(n)for n in N]
 for _,_,out in neg:
  for z in out:f.cl.append([-z])
 for i in range(2):f.cl.append([v[i]for v in neg])
 for e in P:
  if not control: f.cl.append(evaluate(e)[2])
 with Solver(name='cadical195',bootstrap_with=f.cl) as sol:
  sol.conf_budget(limit)
  ans=sol.solve_limited()
  print(ix,ex,ans,sol.accum_stats()['conflicts'], flush=True)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
