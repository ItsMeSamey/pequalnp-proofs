from cuts import bm,load
from itertools import combinations_with_replacement,combinations
P,N=load(())
P=[r&1048575 for r in P];N=[r&1048575 for r in N]
atoms=bm(1048575)
nbr={a:{b for b in atoms if not any(n&a and n&b for n in N)}for a in atoms}
assert all(set(bm(p))=={a,b} for a,b in combinations(atoms,2) if b in nbr[a] for p in [a|b])
assert {a|b for a in atoms for b in nbr[a]}==set(P) and len(P)==28
assert all(len(nbr[a]&nbr[b])<=1 for a,b in combinations(atoms,2))
assert all(any(n&a for n in N)for a in atoms)
assert all(len(set(bm(c))&nbr[a])<=1 for c in (129,4160)for a in atoms)
for a in atoms:
 for b in atoms:
  if b not in nbr[a]:assert any(n&a and n&b for n in N)
print('20 singleton atoms; 28 compatible incidence pairs; every other ordered atom pair has a signed negative; star intersections at most one.')
