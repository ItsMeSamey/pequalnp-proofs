from pathlib import Path
from collections import Counter
charts=[tuple(map(int,s.split())) for s in Path('chart7.txt').read_text().splitlines()]
centers={x for x,y in charts if x&8191}
assert len(centers)==147
counts=[]
for c in centers:
 for ex in (2,3):
  row=Path(f'os7/{c}-{ex}.log').read_text().splitlines()[-1].split()
  assert row[:3]==[str(c),str(ex),'False'],(c,row)
  counts.append(int(row[3]))
allm={m for c,m in charts};mixed={m for c,m in charts if c in centers}; pure={m for c,m in charts if c not in centers}
assert (len(allm),len(mixed),len(pure&mixed))==(14588,588,168)
print('definitive UNSAT:',len(counts),'; conflicts:',min(counts),max(counts))
print('together with distinct six-tag centers: signed full-bank losses',len(allm))
