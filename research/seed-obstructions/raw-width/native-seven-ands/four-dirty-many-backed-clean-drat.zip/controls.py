from model import Model,cases
from geometry import *
from pysat.solvers import Cadical195
from itertools import combinations,permutations

for k,left,B in cases:
    m=Model(k,left,B);T=private[:k];L,R=m.groups
    remove={tuple(m.duo[g,p|(v<<13)]for g in range(4,8)) for p,v in edges if v in ordinary}
    assert len(remove)==12
    net={}; targets={v:({v<<13},set(stars[v]))for v in private}
    if not R:
        v=T[0];p=next(p for p in points if p in stars[v] and any(p not in stars[t] for t in T))
        net[B]=({t<<13 for t in L},{p});targets[v][1].add(-1-B)
    else:
        net[B]=({t<<13 for t in L},{t<<13 for t in R})
        if len(R)==1:targets[R[0]][0].add(-1-B)
    Ds=[g for g in range(4)if g!=B]
    for i,g in enumerate(Ds):
        v=private[i];t=ordinary[i];p=next(p for p in points if p in stars[v]-stars[t])
        net[g]=({t<<13},{p});targets[v][1].add(-1-g)
    for i,v in enumerate(private):net[4+i]=targets[v]
    def evaluate(p,t):
        n=p|(t<<13);out=[];hot=set()
        for g in range(8):
            a,b=[any((bool(x&n) if x>0 else out[-1-x])for x in S)for S in net[g]]
            if a or b:hot.add(g)
            out.append(a and b)
        return out,hot
    dirt=set()
    for p,t,s in rows:
        out,hot=evaluate(p,t)
        if s<0:
            assert not any(out[4:]);dirt.update(g for g,z in enumerate(out) if z)
        if s>0:assert any(out[4:])==(t in private)
    assert dirt==set(range(4))
    for i,v in enumerate(private):
        assert evaluate(q[v],0)[1]=={4+i}
        assert evaluate(0,v)[1]==({B,4+i}if v in T else {4+i})
    for t in (*ordinary,*private):
        out,mk=evaluate(0,t);assert not any(out)and len(mk)<=2
    assert all(len(evaluate(0,t|v)[1])<=3 for t,v in combinations(ordinary+private,2))
    assert all(g in evaluate(0,t)[1]for g,t in zip(Ds,ordinary))
    pins=[]
    for g,arms in sorted(net.items()):
        if g<4 and g!=B:
            xs=m.raw+[-1-h for h in range(g)]
            arms=sorted(arms,key=lambda S:tuple(x in S for x in xs))
        for s,S in enumerate(arms):
            if g<4:xs=m.raw+[-1-h for h in range(g)]
            else:
                v=private[g-4]
                xs=([v<<13]if s==0 else sorted(stars[v]))+[-1-h for h in range(4)]
            pins.extend((1 if x in S else -1)*m.W(g,s,x)for x in xs)
    with Cadical195(bootstrap_with=[c for c in m.C if tuple(c)not in remove])as sat:assert sat.solve(assumptions=pins),(k,left,B)
    with Cadical195(bootstrap_with=m.C)as sat:assert not sat.solve(assumptions=pins)
print('28 native controls pass 624 indexed negatives, all 16 private positives, the four dirty signs, actual addresses and caps')
print('28 pinned SAT with only twelve ordinary positive clauses removed; 28 pinned UNSAT with the full objective')
print('the four 2+2 split controls retain a dirty B with no physical reader, as explicitly granted by the relaxation')
