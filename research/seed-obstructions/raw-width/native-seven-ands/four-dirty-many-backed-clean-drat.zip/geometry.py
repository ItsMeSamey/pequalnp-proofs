from itertools import combinations
from functools import cache
from nativecontrol import rows,edges
private=(2,4,8,32)
ordinary=(1,16,64)
stars={t:{p for p,v in edges if v==t} for _,t in edges}
q={u:next(p for p in stars[u] if sum(p in S for S in stars.values())==1) for u in private}
points=sorted(set.union(*stars.values())-set(q.values()))
N0={p|(t<<13) for p,t,y in rows if y<0}
@cache
def dominated(m):return any(m&~n==0 for n in N0)
