from itertools import combinations
from pysat.formula import IDPool
from pysat.solvers import Cadical195
from geometry import private,ordinary,points,stars,q,N0,edges,dominated

def maximal(S):
    return {x for x in S if not any(x!=s and x&~s==0 for s in S)}

class Model:
    def __init__(self,k,left,B):
        self.k=k;self.left=left;self.B=B
        T=private[:k];groups=(T[:left],T[left:]);self.groups=groups
        NP=points; raw=NP+[t<<13 for t in ordinary]
        # A formal symbol for the common OR of the tags on each B arm.
        symbol=(1<<26,1<<27);self.symbol=symbol; self.raw=raw
        fullN=maximal(N0);P={p|(t<<13)for p,t in edges}
        base=IDPool();self.base=base;C=[];self.C=C
        V=lambda *a:base.id(a)
        W=lambda g,s,x:V('wire',g,s,x)
        self.W=W
        def OR(o,ins):
            C.append([-o,*ins]);C.extend([o,-x]for x in ins);return o
        def AND(o,ins):
            C.append([o,*[-x for x in ins]]);C.extend([-o,x]for x in ins);return o
        def project(z):
            return (z&sum(raw))|sum(b for S,b in zip(groups,symbol)if (z>>13)&sum(S))
        def D(g,z):return V('D',g,project(z))
        def arm(g,s,z):return V('a',g,s,project(z))
        tags=ordinary+private
        probes=fullN|P|set(points)|set(q.values())|{t<<13 for t in tags}|{(t|s)<<13 for t,s in combinations(tags,2)}
        extpos={project(z)for z in probes}
        Q={}
        for v in private[k:]:
            atoms=raw+[t<<13 for t in T]
            Q[v]={sum(a)for j in range(1,6)for a in combinations(atoms,j)if dominated(sum(a))and all(not dominated(sum(a)|p)for p in stars[v])}
            extpos.update(project(z)for z in Q[v])
        for m in sorted(extpos):
            for g in range(4):
                arms=[]
                for s in (0,1):
                    src=[W(g,s,x)for x in raw if x&m]
                    for h in range(g):src.append(AND(V('da',g,s,h,m),[W(g,s,-1-h),V('D',h,m)]))
                    o=V('a',g,s,m)
                    if g==B and groups[s] and m&symbol[s]:C.append([o])
                    else:OR(o,src)
                    arms.append(o)
                AND(V('D',g,m),arms)
        for g in range(4):
            C.append([D(g,n)for n in fullN])
            if g==B:continue
            prev=None
            for x in raw+[-h-1 for h in range(g)]:
                a,b=W(g,0,x),W(g,1,x)
                C.append(([-prev] if prev is not None else [])+[-a,b])
                eq=V('eq',g,x);C.extend([[-eq,-a,b],[-eq,a,-b],[eq,a,b],[eq,-a,-b]])
                prev=eq if prev is None else AND(V('pref',g,x),[prev,eq])
        duo={};mark={}
        for j,v in enumerate(private):
            g=4+j
            C.extend([[W(g,0,v<<13)],[W(g,1,q[v])]])
            if v not in T:
                C.extend([W(g,1,p)]for p in stars[v])
                for h in range(4):
                    w=W(g,0,-1-h)
                    if h<2:C.append([-w]);continue
                    C.append([-w,*sorted({D(h,n)for n in Q[v]})]);C.extend([-w,-d]for d in {D(h,n)for n in fullN if n&sum(stars[v])})
            hs={}
            for m in sorted(probes):
                # Exact duplicate rows at this terminal share their Tseitin variables.
                sig=(project(m),m&((v<<13)|sum(stars[v])))
                if sig not in hs:
                    a=[]
                    for s in (0,1):
                        src=[W(g,s,x)for x in ([v<<13] if s==0 else sorted(stars[v])) if m&x]
                        for h in range(4):
                            key=(s,h,project(m))
                            if key not in hs:
                                hs[key]=AND(V('pa',g,*key),[W(g,s,-1-h),D(h,m)])
                            src.append(hs[key])
                        a.append(OR(V('prarm',g,s,*sig),src))
                    hs[sig]=(AND(V('clean',g,*sig),a),OR(V('hot',g,*sig),a))
                duo[g,m],mark[g,m]=hs[sig]
                if m in fullN:C.append([-duo[g,m]])
        # A backed tag can distinguish itself from a same-arm tag only at its private site.
        for G in groups:
            for v in G:
                for p in stars[v]:
                    if any(p not in stars[t] for t in G):C.append([duo[4+private.index(v),p|(v<<13)]])
        # On an opposite tag pair, the clean private sites and the backup use the whole hot-site cap.
        if groups[0] and groups[1]:
            opposed=[{i,j} for i in groups[0] for j in groups[1]]
            allowed=set.intersection(*opposed)
            for h in range(B+1,4):C.extend([-W(h,s,-1-B)]for s in (0,1))
            for j,v in enumerate(private):
                C.append([-W(4+j,1,-1-B)])
                if v not in allowed:C.append([-W(4+j,0,-1-B)])
        self.duo=duo
        for m in sorted(P):C.append([duo[g,m]for g in range(4,8)])
        for ts in (*combinations(tags,1),*combinations(tags,2)):
            m=sum(ts)<<13
            for g in range(4):mark[g,m]=OR(V('hot0',g,project(m)),[arm(g,s,m)for s in (0,1)])
            for xs in combinations([mark[g,m]for g in range(8)],len(ts)+2):C.append([-x for x in xs])
            if len(ts)==1:
                for g in range(8):C.append([-(D(g,m) if g<4 else duo[g,m])])
        for j in (1,2,3):
            for ts in combinations(ordinary,j):
                for G in combinations(range(4),j-1):C.append([mark[g,t<<13]for t in ts for g in range(4)if g not in G])
        self.hot=lambda g,t:mark[g,t<<13];self.D=D
    def solve(self,limit=20000):
        with Cadical195(bootstrap_with=self.C)as S:
            S.conf_budget(limit)
            return S.solve_limited()

cases=[(k,l,B) for k in (2,3,4) for l in range((k+1)//2,k+1) for B in range(4)]
if __name__=='__main__':
    from sys import argv
    from time import monotonic
    for k,l,b in cases:
        t=monotonic();m=Model(k,l,b);r=m.solve(int(argv[1]));print(k,l,b,r,round(monotonic()-t,2),flush=True)
