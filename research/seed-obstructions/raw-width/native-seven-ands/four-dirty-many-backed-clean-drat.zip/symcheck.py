from itertools import permutations, product, combinations
from geometry import private, ordinary, stars, N0, edges, points, dominated

maxneg={n for n in N0 if not any(n!=m and n&~m==0 for m in N0)}
P={p|(t<<13) for p,t in edges}
by={frozenset(t for t in stars if p in stars[t]):p for p in set.union(*stars.values())}
group=[]
for a,b in product(permutations(private),permutations(ordinary)):
    tags=dict(zip(private+ordinary,a+b))
    try:
        permutation={p:by[frozenset(tags[t] for t in S)]for S,p in by.items()}
    except KeyError:
        continue
    pi={**permutation,**{t<<13:j<<13 for t,j in tags.items()}}
    def image(z):
        return sum(j for t,j in pi.items()if t&z)
    if {image(z)for z in maxneg}==maxneg and {image(z)for z in P}==P:
        group.append(tags)
assert len(group)==24 and len({tuple(g[t]for t in private) for g in group})==24
raw0=points+[t<<13 for t in ordinary]
for k in (2,3,4):
    for T in combinations(private,k):
        raw=raw0+[t<<13 for t in T]
        for v in private:
            if v in T:continue
            bad={sum(z)for j in range(1,6)for z in combinations(raw,j)if dominated(sum(z)) and all(not dominated(sum(z)|p)for p in stars[v])}
            assert len(bad)==6 and all(m<8192 and m.bit_count()==4 for m in bad)
        for n in range(k+1):
            for left in combinations(T,n):
                a,b=set(left),set(T)-set(left)
                if len(a)<len(b):a,b=b,a
                assert any({g[t]for t in a}==set(private[:len(a)])and {g[t]for t in b}==set(private[len(a):k])for g in group)
print('24 genuine native signed permutations; 28 positives and 245 maximal negative masks')
print('all common-backup partitions for 2,3,4 backed tags normalize to seven unordered arm types')
print('all unbacked recipients have exactly six pure quartet exceptions through witness size five')
