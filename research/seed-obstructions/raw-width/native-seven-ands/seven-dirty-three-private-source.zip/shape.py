"""Build one CNF per center and inspect literal plumbing. This module has no solver."""
from itertools import combinations, product
from collections import Counter
from physical import Model, N, P, U, charts, mx, ordinary, rows


def check(role):
    model = Model(*role)
    clauses = {tuple(c) for c in model.C}
    witnesses = set(mx(N))
    unit_rows = {c[0] for c in model.C if len(c) == 1}
    assert all(model.G(7, n) in unit_rows for n in P)
    assert all(-model.G(7, n) in unit_rows for n in witnesses)
    for g in range(7):
        assert tuple(model.G(g, n) for n in mx(N)) in clauses
    probe = next(iter(P))
    for s, d in product(range(2), range(7)):
        lit = model.V(('lit', 7, s, d, probe))
        wire = model.W(7, s, 20 + d)
        donor = model.G(d, probe)
        assert {(lit, -wire, -donor), (-lit, wire), (-lit, donor),
                (model.A(7, s, probe), -lit)} <= clauses
    for g in range(6):
        assert tuple(model.W(h,s,20+g) for h in range(g+1,7) for s in range(2)) in clauses
    reads = tuple(model.W(7,s,26) for s in range(2))
    assert reads in clauses and tuple(-w for w in reads) in clauses
    earlier=[g for g in model.ext if g!=6]
    for t in ordinary:
        for g,s in product(earlier,range(2)):
            mark=model.V(('ordinary representative',t,g,s))
            assert (-mark,model.A(g,s,t<<13)) in clauses
            assert all((-mark,model.A(g,1-s,p)) in clauses for p in (1,4,64) if U[t]&p)
            assert all((-mark,-model.hot(h,t<<13)) in clauses for h in earlier if h!=g)
    print(role, len(model.C), 'clauses; terminal, D6, six ancestors and original marks checked')


if __name__=='__main__':
    roster=list(charts())
    direct={(m,k,tuple(i for i in range(6) if mask>>i&1),6)
            for m,k in product(('ext','hub'),(3,4))
            for mask in range(64) if mask.bit_count()==3}
    assert len(roster)==len(direct)==80 and direct==set(roster)
    selected=[r for r in roster if r[2][0]>0]
    assert len(selected)==40
    assert Counter((m,k) for m,k,_,_ in selected)=={(m,k):10 for m,k in product(('ext','hub'),(3,4))}
    assert Counter(y for p,t,y in rows)=={-1:624,0:24,1:28}
    print('direct roles',len(roster),'selected roles',len(selected),'10 selected per center/backed count')
    for role in [('ext',3,(0,2,5),6),('hub',4,(1,3,4),6)]:
        check(role)
