from itertools import combinations


def constrain(model, ordinary, neighborhoods, new_var, arm, wire):
    clauses = model.C
    backup = model.E
    earlier_exterior = [g for g in model.ext if g != backup]
    core_points = (1, 4, 64)

    # Each earlier dirty site reaches B by one or more OR-only donor edges.
    # Since all six are required to reach B, it suffices for each to have a
    # successor among the remaining dirty sites: their indices strictly grow.
    for g in range(backup):
        clauses.append([
            wire(later, side, 20 + g)
            for later in range(g + 1, backup + 1)
            for side in (0, 1)
        ])

    # The last dirty site is live and cannot feed both inputs of the only clean AND.
    final_reads = [wire(7, side, 20 + backup) for side in (0, 1)]
    clauses.extend([final_reads, [-x for x in final_reads]])

    # Restored 91bfa91d marks are on original bare atoms. They are
    # semantic socket marks; no raw membership on the point side is assumed.
    # H and B are outside the three-site bijection.
    by_gate = {g: [] for g in earlier_exterior}
    for tag in ordinary:
        address = []
        neighbors = [p for p in core_points if neighborhoods[tag] & p]
        assert len(neighbors) == 2
        for g in earlier_exterior:
            for side in (0, 1):
                chosen = new_var('ordinary representative', tag, g, side)
                address.append(chosen)
                by_gate[g].append(chosen)
                clauses.append([-chosen, arm(g, side, tag << 13)])
                clauses.append([-chosen, -arm(g, 1 - side, tag << 13)])
                for p in neighbors:
                    clauses.append([-chosen, arm(g, 1 - side, p)])
                for other in earlier_exterior:
                    if other != g:
                        clauses.append([-chosen, -model.hot(other, tag << 13)])
        clauses.append(address)
        clauses.extend([-a,-b] for a,b in combinations(address,2))
    for choices in by_gate.values():
        clauses.extend([-a,-b] for a,b in combinations(choices,2))
