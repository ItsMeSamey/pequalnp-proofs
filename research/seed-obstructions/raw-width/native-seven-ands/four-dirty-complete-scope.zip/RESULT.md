# Four dirty gates in the native eight-AND chart

On each native bank, a protected eight-AND separator with exactly four dirty sites and four exposed clean output terms requires **at least 34 gates**. Four backed private tags are impossible at every OR cost. This is a lower bound on the signed native chart; no tight circuit at 34 gates is asserted. At area 33 the remaining dirty counts for eight ANDs are five through seven when combined with the separate d≤3 results. The global question also permits nine or ten ANDs.

Assume the four private points have distinct unique AND addresses opposite their own tags, bare-tag AND darkness, one/two-tag site touch caps, and the exterior matching and tag-exclusive sockets from native complement resolution. These conditions refer to the actual signed table of 676 rows, 28 distinct positive edges, and 624 indexed negative rows with 468 distinct negative masks of which 245 are inclusion-maximal. The original four banks 0,7,17,115 have the thirteen point and seven tag raws and allow optional designated point disjunctions.

Let b count private tags with a second address and h the number of dirty ANDs at private matches. An unbacked private site cuts both inputs of the private positive, and if high on any negative that negative would dominate the private positive outside the cut. Hence 0≤h≤b≤4.

| b | h=0 | h=1 | h=2 | h=3 | h=4 |
|---|---|---|---|---|---|
| 0 | impossible | cut | cut | cut | cut |
| 1 | impossible | impossible | cut | cut | cut |
| 2 | impossible | ≥37 | ≥34 | cut | cut |
| 3 | impossible | impossible | ≥34 | ≥37 | cut |
| 4 | impossible | impossible | impossible | impossible | impossible |

“Cut” denotes h>b. The b=0 source is four-dirty-all-unbacked. At b=1 use four-dirty-one-backed-clean-drat and four-dirty-one-backed-dirty-host-drat. At h=0 with b≥2 use four-dirty-many-backed-clean-drat. For h=1 with b≥2, four-dirty-many-backed-one-dirty-private-37 includes the corrected fourth-donor regression and all 60 verified conflicts. The invalid earlier run supplies no data. The final direct 60-role h=2 source covers both b=2,3 and b=4; use its historical checkpoint only for the checked conflicts it retains. For h=3 use four-dirty-three-dirty-private-37. For h=4 refer to private-hub-safety: each dirty private owner requires a downstream second address, their four address pairs form a star, and the earliest one's raw tagged socket admits no foreign point or tag on the jointly safe backup, so it is clean instead.

The four clean terminal terms cost three collector ORs in addition to the eight ANDs. Thus at least 23 precollector ORs certify 34 gates; at least 26 certify 37. The h=1,2,3 price archives validate formal-socket interval boxes under arbitrary shared ORs, then attach checked UNSAT certificates after blocking only the validated expensive boxes. Actual high-budget controls are included for surviving footprints. In particular the final h=2 source covers private-first and exterior-first orders independently of any secondary minimization. The direct table does not rely on an inference that refitting to at most three dirty sites would always give the cost floor for exactly three.

The native normalization antecedents and earlier dirty counts are separately referenced in DEPENDS.sha256. No other dirty count or original-bank decrement follows from this table by itself.
