#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;
struct Row {int p,t;};
vector<Row> neg,edges; array<unsigned,13> g; array<int,129> hist;
int forced(){
 array<unsigned,128> low;
 for(int t=0;t<128;t++){unsigned ban=0;for(unsigned s:g)if(!(s&t))ban|=s;low[t]=127^ban;}
 uint64_t bits[2]{};array<int,128> reps; reps.fill(-1);int ix=0;
 for(auto [p,t]:neg){unsigned ban=0;while(p){int b=countr_zero((unsigned)p);p&=p-1;ban|=g[b];}
 unsigned high=127^ban;if(low[t]==high){bits[high/64]|=uint64_t(1)<<(high%64);if(reps[high]<0)reps[high]=ix;}ix++;}
 
 int n=popcount(bits[0])+popcount(bits[1]);
 if(n!=64)return n;
 array<uint64_t,20> cols{};int nr=0;
 for(int z:reps)if(z>=0){
 unsigned row=neg[z].p|(neg[z].t<<13);
 for(int j=0;j<20;j++)if(row>>j&1)cols[j]|=uint64_t(1)<<nr;
 nr++;
 }
 const unsigned all=(1<<20)-1;
 set<unsigned> right={all};
 for(int j=0;j<20;j++){
 unsigned allowed=0;for(int k=0;k<20;k++)if(!(cols[j]&cols[k]))allowed|=1u<<k;
 vector<unsigned> add;for(auto s:right)add.push_back(s&allowed);
 right.insert(add.begin(),add.end());
 }
 set<uint64_t> balanced;
 for(auto r:right){
 uint64_t B=0,A=0;for(int j=0;j<20;j++)if(r>>j&1)B|=cols[j];
 if(popcount(B)!=32)continue;
 for(auto c:cols)if(!(c&B))A|=c;
 if((A|B)==~uint64_t(0))balanced.insert(min(A,B));
 }
 if(balanced.size()<6)return 70;
 return n;
}
void visit(int first,int k,unsigned mask){
 if(!k){int h=forced();hist[h]++;if(h>=65)cout<<mask<<' '<<h<<'\n';return;}
 for(int i=first;i+k<=int(edges.size());i++){
 auto [p,t]=edges[i];int j=countr_zero((unsigned)p);g[j]^=t;
 visit(i+1,k-1,mask|(1u<<i));g[j]^=t;}
}
int main(int argc,char**argv){
 int a,b;cin>>a>>b;for(int i=0;i<a+b;i++){int p,t;cin>>p>>t;
 if(i<a){edges.push_back({p,t});g[countr_zero((unsigned)p)]|=t;}else neg.push_back({p,t});}
 if(a!=28||forced()!=69)return 2;
 for(int k=0;k<=stoi(argv[1]);k++){hist.fill(0);visit(0,k,0);cerr<<k;for(int i=0;i<=128;i++)if(hist[i])cerr<<' '<<i<<'='<<hist[i];cerr<<'\n';}
}
