from hits import a
from itertools import combinations, combinations_with_replacement
points=list(sorted(a.stars))
tags=[1<<(13+i) for i in range(7)]
positives={p|(t<<13) for p,t in a.pos}
negatives={p|(t<<13) for p,t in a.neg}
safe={(x|y) for x,y in combinations_with_replacement(points+tags,2)
      if not any((x|y)&n==(x|y) for n in negatives)}
assert safe==positives and len(safe)==28
stars=[sum(p for p in points if p|t in positives) for t in tags]
assert all(s.bit_count()==4 for s in stars)
assert max(a.stars[p].bit_count() for p in points)==3
assert all((s&t).bit_count()<=1 for s,t in combinations(stars,2))
for c in (129,4160):assert all(c&~s for s in stars)
print(len(positives),len(negatives),len(safe),stars)
