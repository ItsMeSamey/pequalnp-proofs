from itertools import combinations
from nativecontrol import rows,edges
from fullpetal import private,regular,stars
negative={p|(t<<13) for p,t,y in rows if y<0}
for u in private:
    origins=regular+[t<<13 for t in stars if t!=u]
    for k in (1,2,3):
        for subset in combinations(origins,k):
            m=sum(subset)
            if any(m&~n==0 for n in negative):
                assert any((m|p)&~n==0 for p in stars[u] for n in negative)
print('Unbacked full-petal extensions pass for all four tags.')
