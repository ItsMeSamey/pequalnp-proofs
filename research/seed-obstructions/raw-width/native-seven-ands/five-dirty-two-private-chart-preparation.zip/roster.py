from model import charts
from collections import Counter
roles=list(charts())
assert len(roles)==len(set(roles))==120
assert all(0<=h<k<B<=5 for h,k,mode,B,b in roles)
for h,k,mode,B,b in roles:
 assert b in (2,3,4) and mode in ('shared','cross')
for mode in ('shared','cross'):
 for b in (2,3,4):
  L=[r for r in roles if r[2]==mode and r[4]==b]
  print(mode,b,len(L),sum(h>0 for h,*r in L))
  assert len(L)==20 and sum(h>0 for h,*r in L)==10
