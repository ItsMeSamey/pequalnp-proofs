from coupled import *
def covers(E):
    out=set()
    def go(rem,C):
        if not rem:out.add(tuple(sorted(C)));return
        if len(C)==6:return
        e=rem[0]
        for z in (e&8191,e&~8191):go([r for r in rem if not r&z],C|{z})
    go(sorted(E),set());return out
ncase=0
for q,u in zip(priv,own):
    U=sum(e&8191 for e in Ps if e&(u<<13));foreign=[1<<j for j in range(7) if 1<<j!=u]
    def signed(z):return any(z&~n==0 for n in Ns)
    for x in foreign:
        T=sum(e&8191 for e in Ps if e&(x<<13));r=U&T
        assert r.bit_count()==1
        mandatory={e for e in Ps if not e&U and (not e&T or e&(x<<13))}
        family=covers(mandatory)
        assert family=={tuple(v<<13 for v in foreign)} and len(mandatory)==14
        for v in foreign:
            petals=[e&8191 for e in mandatory if e&(v<<13)]
            assert len(petals)>=2 and signed(q|((x|v)<<13))
            assert v==x or any(signed(q|(x<<13)|p)for p in petals)
        P0=T&~U
        assert sum(e&8191 for e in mandatory if e&(x<<13))==P0 and P0.bit_count()==3
        for j in range(13):
            z=1<<j
            if not z&sum(priv):assert any(n&q and n&z and n&P0 for n in Ns)
            if not z&U:assert any(n&(u<<13) and n&z and n&P0 for n in Ns)
        for v in foreign:
            if v!=x:assert any(n&(u<<13) and n&(v<<13) and n&P0 for n in Ns)
        print(q,u,x,r,len(mandatory),list(family)[0]);ncase+=1
print('original signed charts',ncase)
