from layouts import *
from pathlib import Path
from pysat.solvers import Glucose4
import subprocess,tempfile,gzip,hashlib,json,sys
def signed_layouts():
    M=Chart(2,None)
    K=literal_eval(next(z[5:] for z in open('census20.log')if z.startswith('live ')))
    out=sorted({w for k,_ in K for w in tuples(M,k)})
    assert len(out)==246
    return out
def clauses(M):
    W=families(M);C=M.C+list(symmetry(M,W))
    if M.u is None:
        atoms=M.orig+[1<<(20+i)for i in range(3)]
        for w in json.loads(Path('library.json').read_text()):
            C.append([(-v if mask&val else v) for mask,ws in zip(w,W) for v,val in zip(ws,atoms)])
    return C
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    if sys.argv[1]=='enumerate':
        Path('library.json').write_text(json.dumps(signed_layouts(),separators=(',',':'))+'\n');return
    verify='--verify-only' in sys.argv
    b=2;u=int(sys.argv[1]) or None;M=Chart(b,u);C0=clauses(M)
    path=Path('drat');path.mkdir(exist_ok=True)
    # Stabilizer of ordered b,u need not fix the first ordinary tag. No orbit reductions within the probes.
    for bk in range(4):
        for idx,fs in enumerate(sorted(M.fs) if u else [None]):
            key=f'{u or 0}-{bk}-{idx}';pp=path/(key+'.gz')
            if pp.exists() and not verify:continue
            assumptions=M.backup(bk)+([M.V('G',2,fs)] if fs is not None else [])
            C=C0+[[v]for v in assumptions]
            if verify:proof=gzip.decompress(pp.read_bytes())
            else:
                with Glucose4(bootstrap_with=C,with_proof=True) as S:
                    S.conf_budget(35000)
                    ans=S.solve_limited()
                    if ans!=False:print('needsplit',key,ans,flush=True);continue
                    proof=('\n'.join(S.get_proof())+'\n').encode()
            cnf=('p cnf %d %d\n'%(max(abs(v)for c in C for v in c),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode()
            with tempfile.TemporaryDirectory() as td:
                p=Path(td);(p/'c').write_bytes(cnf);(p/'d').write_bytes(proof)
                r=subprocess.run([sys.argv[2],str(p/'c'),str(p/'d'),'-t','40'],capture_output=True,timeout=45)
                assert r.returncode==0 and b's VERIFIED' in r.stdout,(key,r.stdout[-100:])
            if not verify:pp.write_bytes(gzip.compress(proof,compresslevel=3,mtime=0))
            print('verified',key,len(proof),sha(cnf),sha(proof),flush=True)
if __name__=='__main__':main()
