from model import *
from collections import Counter
alltag=tuple(sorted(stars))
def maxes(S):return {x for x in S if not any(x!=n and x&~n==0 for n in S)}
N=maxes(N0)
ngh={p:tuple(t for t in alltag if p in stars[t]) for p in set.union(*stars.values())}
by={frozenset(t):p for p,t in ngh.items()}
def candidates():
    for ii in permutations(private):
        for oo in permutations(ordinary):
            tmap=dict(zip(private+ordinary,ii+oo)); pm={}
            for p,A in ngh.items():
                key=frozenset(tmap[t]for t in A)
                if key not in by:break
                pm[p]=by[key]
            else:
                morph=pm|{u<<13:v<<13 for u,v in tmap.items()}
                def xf(m):return sum(y for x,y in morph.items() if m&x)
                if {xf(m) for m in N}==N:yield tmap,pm
if __name__=='__main__':
    As=list(candidates())
    print('native signed automorphisms',len(As))
    print('ordered private-pair orbit',sorted({(t[2],t[4]) for t,p in As}))
    print('optional pair images',sorted({tuple(sorted(sum(y for x,y in p.items() if m&x)for m in (129,4160))) for t,p in As}))
