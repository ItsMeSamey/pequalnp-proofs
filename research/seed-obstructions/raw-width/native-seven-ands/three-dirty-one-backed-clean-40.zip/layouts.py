from ast import literal_eval
from collections import Counter
from sys import argv
from fixed import *
from unionprice import lower
from functools import lru_cache
@lru_cache(None)
def ndomain():
    return tuple((p|(t<<13),t)for p,t in {(p,t)for p,t,y in rows if y<0})
def families(M):
    n=len(M.orig)
    return [[M.V('w',g,s,j) for j in range(n+min(g,3))] for g in range(M.nn) for s in (0,1)]
def symmetry(M,W):
    for g in range(4):
            pre=[]
            for i,(a,b) in enumerate(zip(W[2*g],W[2*g+1])):
                yield pre+[-a,b]
                eq=M.V('eq',g,i)
                yield pre+[a,b,eq];yield pre+[-a,-b,eq];pre=[-eq]
def tuples(M,k):
    W=families(M)
    with Cadical195(bootstrap_with=M.C) as S:
        # Sort the two operand vectors at each exterior site by first unequal bit.
        for c in symmetry(M,W):S.add_clause(c)
        while S.solve(assumptions=ass(M,k)):
            A=set(S.get_model())
            atoms=M.orig+[1<<(20+i) for i in range(3)]
            yield tuple(sum(val for v,val in zip(ws,atoms)if v in A) for ws in W)
            S.add_clause([(-v if v in A else v) for ws in W for v in ws])
def score(w,n):
    m=n
    for i in range(3):
        if w[2*i]&m and w[2*i+1]&m:m|=1<<(20+i)
    return m
def library(M,w):
    us=list(private);us.remove(M.b)
    T={(x,x)for x in w if x.bit_count()>1}
    neg=ndomain()
    F=[0]*3; B=[0]*3
    for m,t in neg:
        a=score(w,m)
        for i in range(3):
            if (a>>(20+i))&1:F[i]|=t
    for j in range(13):
        a=score(w,1<<j)
        for i in range(3):
            if (a>>(20+i))&1:B[i]|=1<<j
    for u in us:
        lo=hi=sum(stars[u])
        for i in range(3):
            if not (F[i]&u):lo&=~B[i];hi|=1<<(20+i)
        T.add((lo,hi))
    return tuple(sorted(T))
def main():
    M=Chart(2,None)
    good=literal_eval(next(z[5:] for z in open('census20.log')if z.startswith('live ')))
    for j,(k,_) in enumerate(good):
        if len(argv)>1 and j!=int(argv[1]):continue
        stat=Counter()
        for w in tuples(M,k):
            c=lower(library(M,w));stat[c]+=1
            if sum(stat.values())==1:print('control',j,k,c,w,flush=True)
            if c<22:print('WEAK',k,c,w,flush=True);return
        print('layouts',j,k,sum(stat.values()),sorted(stat.items()),flush=True)
if __name__=='__main__':main()
