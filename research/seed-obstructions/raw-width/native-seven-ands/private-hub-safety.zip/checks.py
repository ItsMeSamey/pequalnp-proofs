from nativecontrol import rows,edges
from itertools import combinations
from collections import Counter
P=(2,4,8,32);T=tuple(1<<j for j in range(7));X=tuple(1<<i for i in range(13))
mask=lambda p,t:p|(t<<13)
N=sorted({mask(p,t)for p,t,y in rows if y<0})
U={t:{p for p,v in edges if v==t}for t in T}
Q={t:next(x for x in X if x in U[t] and sum(x in v for v in U.values())==1)for t in P}
def witnesses(m):return [n for n in N if m&~n==0]
count=Counter()
for t in P:
    for x in X:
        opts=[(v,witnesses(mask(Q[t]|x,v))) for v in P if v!=t]
        assert any(w for v,w in opts)
        count['point witnesses']+=1
    for vtag in T:
        if vtag!=t:
            opts=[witnesses(mask(Q[t],vtag|v))for v in P if v!=t]
            assert any(opts)
            count['foreign tag witnesses']+=1
    for p in X:
        if p not in U[t]:assert witnesses(mask(p,t))
    for v in T:assert witnesses(mask(0,v|t))
    for foreign in P:
        if foreign!=t:
            assert witnesses(mask(Q[t],foreign))
print('native',len(rows),'distinct negatives',len(N))
print(count,'max private degree',max(sum(p in U[t]for t in P)for p in X))
assert max(sum(p in U[t]for t in P)for p in X)==2
for own in P:
    for a,b in combinations([t for t in P if t!=own],2):
        common=U[a]&U[b];assert len(common)==1 and not(common&U[own])
        for p in X:
            if p not in common:assert any(witnesses(mask(Q[own]|p,v))for v in (a,b))
        for y in T:
            if y!=own:assert any(witnesses(mask(Q[own],y|v))for v in (a,b))
print('two-foreign-tag tests',12)
