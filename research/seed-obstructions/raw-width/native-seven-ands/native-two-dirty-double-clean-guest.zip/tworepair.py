from coupled import *
from itertools import permutations
def N(t):return sum(e&8191 for e in Ps if e&(t<<13))
def safe_wit(m):return any(not m&~n for n in Ns)
for q,u in zip(priv,own):
 for x,y in permutations(ordt,2):
  U=N(u);T=N(y);P0=T&~U; r=T&U;w=N(x)&T
  assert r.bit_count()==1 and not r&sum(priv)
  assert P0.bit_count()==3 and P0&w and not w&U
  assert any(safe_wit(q|(x<<13)|p) for p in (1<<j for j in range(13)if P0>>j&1))
  for z in (1<<j for j in range(13)):
   assert any(n&z and n&P0 for n in Ns)
  for v in (1<<j for j in range(7)if 1<<j!=y):
   assert any(n&(v<<13) and n&P0 for n in Ns)
  print(q,x,y,r,w)
