from nativecontrol import rows,edges
from itertools import combinations
from collections import Counter
P=(1,4,64)
ordinary=(1,16,64)
private=(2,4,8,32)
N={v:{p for p,t in edges if t==v}for v in private+ordinary}
q={v:next(p for p in N[v] if sum(p in n for n in N.values())==1)for v in private}
neg=[(i,n,w) for i,(n,w,y) in enumerate(rows) if y<0]
def witness(p,t,petal=0):
    return next(i for i,n,w in neg if n&p==p and w&t==t and (not petal or petal&n))
for u in private:
    assert not N[u].intersection(P)
    seen={}
    for v in private:
        if v==u:continue
        for p in P:
            seen['tag socket on point',v,p]=witness(q[v]|p,u)
            seen['point socket on point',v,p]=witness(p,u|v)
        for t in ordinary:
            seen['tag socket on tag',v,t]=witness(q[v],u|t)
    for p in P:
        for t in ordinary:
            if (p,t) not in edges:
                seen['cycle nonedge',p,t]=witness(p,u|t)
    assert all(len(N[t].intersection(P))==2 for t in ordinary)
    assert all(len(N[t].intersection(N[s],P))==1 for t,s in combinations(ordinary,2))
    for p in P:seen['H low on point',p]=witness(p,u)
    nv=set.union(*(N[v] for v in private if v!=u))
    needed=sum(nv)
    escape=[]
    all_private=set(q.values())
    pm=(8191^sum(all_private))+q[u]
    tm=sum(ordinary)+u
    for _,n,w in neg:
        a,b=n&pm,w&tm
        if not any(m&needed and m&a==a and s&b==b for _,m,s in neg):
            escape.append((a,b))
    assert set(escape)=={(q[u]|sum(P),0)}
    triples=[(a|b,witness(q[u]|a|b,0,needed))for a,b in combinations(P,2)]
    print('u',u,'proper q+pair witnesses',triples,'escape',sorted(set(escape)))
    for k,i in sorted(seen.items(),key=repr):print('native',u,k,i)
