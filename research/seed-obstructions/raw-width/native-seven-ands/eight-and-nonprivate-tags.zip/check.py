from itertools import combinations_with_replacement
pairs=list(combinations_with_replacement(range(16),2))
surv=[]
for gates in combinations_with_replacement(pairs,3):
 if not {1,2,4,8}.issubset(x for g in gates for x in g): continue
 unions={0}
 for a,b in gates:
  unions|={x|y for x in unions for y in (a,b)}
 if len(unions)==16:surv.append(gates)
print(len(surv),surv[:8])
