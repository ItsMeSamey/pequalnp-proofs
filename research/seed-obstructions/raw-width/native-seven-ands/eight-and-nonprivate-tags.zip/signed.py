from itertools import product
from pathlib import Path
rows=[list(map(int,l.split())) for l in Path("native.in").read_text().splitlines()]
p,n=rows[0]; P,N=rows[1:p+1],rows[p+1:]
assert len(N)==n
private=[(2,32),(8,2),(16,4),(32,8)]
assert all(list(x) in P for x in private)
for choices in product(range(3),repeat=4):
 q=sum(a for c,(a,b) in zip(choices,private) if c==1)
 t=sum(b for c,(a,b) in zip(choices,private) if c==2)
 ix=next(i for i,(r,v) in enumerate(N) if r&q==q and v&t==t)
 print(q,t,ix,*N[ix])
