# Five dirty ANDs in the selected protected native representative

On the four native banks, a putative area-at-most-33 separator with eight ANDs cannot have five dirty ANDs in the selected protected clean-output representation. Here the four private matches are unique, ordinary labels admit exterior representatives, the stated actual singleton and two-tag caps hold, and the selector takes the six minima in the order used in 5ed9fc7f and 5943467c. Eight ANDs with five dirty sites have three isolated clean terms. The comparison uses 28 original positive edges and 624 indexed negative rows, with 468 distinct projected masks and 245 maximal masks. Optional point disjunctions are included by expansion. The signed symmetry on raw rows suffices for the free-OR feasibility refutations.

| Dirty matched private sites | Coverage |
|---|---|
| 0 | Impossible: only four exterior sites are available. |
| 1 | All four exteriors are dirty. The exterior backup is last; the C6 cofactor identifies the other three exterior ordinary addresses on original bare atoms (2d2d9cfd). The 28 B-last charts are infeasible by whole-CNF refutations, across one through four backed labels (817f60da). |
| 2 | A selected representation has an exterior dirty site first (5943467c). For each of two common-center choices and backed counts 2,3,4, ten chronological triples remain. All 60 of the 120 direct roles thus required are infeasible (3cf50f2c). |
| 3 | The same selection leaves 20 of 60 direct roles, with a common exterior or private-center backup and three or four backed tags. The 20 are infeasible by chart 11 and the other 19 checked refutations (a6cda1e7, 97efc7f1). |
| 4 | Exactly one dirty exterior remains. In either center type the earliest matched site admits the cost-preserving local repair or the signed three-witness rectangle contradiction (0e6cfa1e), precluding this selected layout. |

The three numerical strata together use 108 checked whole-role refutations: 28+60+20. No interval pricing is needed. The one-private B-last argument is an actual reachability result. In the two-/three-private strata the earlier-private topological cases omitted by the numerical tables depend essentially on the no-increase physical rewrite in the six-tie representative. At four private sites the same selection is essential. Consequently this statement is an exclusion in the selected area-33 representative; it does not give a direct area lower bound for arbitrary circuits constrained to have five dirty gates.

Combining with the prior d≤4 releases leaves six or seven dirty ANDs in a selected eight-AND candidate. At d=6 the private dirty count is 2,3,4; at d=7 it is 3,4. Eight dirty sites cannot yield a clean output. Nine- and ten-AND candidates are separate. This does not change the full original residual area bound.
