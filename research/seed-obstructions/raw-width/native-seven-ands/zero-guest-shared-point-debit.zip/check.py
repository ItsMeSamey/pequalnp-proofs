"""Check the two-socket debit, including a shared impure OR and serial/reconvergent models."""
from collections import Counter
from itertools import product
from functools import reduce
from operator import or_
from pathlib import Path
from random import Random
import json
import re

s=json.loads(Path(__file__).with_name('L-meta-18968.json').read_text())['formal_statement']
seeds=[int(''.join(w.zfill(19) for w in re.findall(r'\((\d+) : ℕ\)', b))) for b in re.findall(r'\[([^]]+)\]',s)]
fields={int(i):int(v)for i,v in re.findall(r'x1 \((\d+) : ℕ\) = \((\d+) : ℕ\)',s)}
def rotate(r,seed,off,count):
    return sum(((seed>>(r-r%13+(r-j-off)%13))&1)<<j for j in range(count))
rows=[(rotate(i,seeds[0],0,13),rotate(i,seeds[1],6,7)) for i in range(676)]
P={x for i,x in enumerate(rows) if (fields[88]&~fields[54])>>i&1}
U=[sum(p for p,t in P if t==1<<j) for j in range(7)]
assert len(P)==28 and all(u.bit_count()==4 for u in U)
assert all((u&v).bit_count()==1 for i,u in enumerate(U) for v in U[:i])
raw=[1<<j for j in range(13)]+[129,4160]
assert all((u&x).bit_count()<=1 for u in U for x in raw)

class Model:
    def __init__(self):
        self.gates=[('raw',0,0) for _ in raw]
        self.sup=raw[:]
        self.donors=[]
    def add(self,op,x,y):
        idx=len(self.gates)
        self.gates.append((op,x,y))
        self.sup.append((self.sup[x]|self.sup[y]) if op=='or' else (self.sup[x]&self.sup[y]))
        if op=='and':self.donors.append(idx)
        return idx
    def audit(self,targets):
        total=Counter(); out=[]
        for choices in product(range(2),repeat=len(self.donors)):
            selectors=dict(zip(self.donors,choices))
            paid=Counter()
            for u,ts in targets.items():
                assert all(not self.sup[t]&~u for t in ts)
                if not ts:continue
                expanded=[None]*len(self.gates)
                charges=[None]*len(self.gates)
                for i,(op,x,y) in enumerate(self.gates):
                    marks=self.sup[i]&u
                    if op=='raw' or (op=='and' and marks.bit_count()<=1):
                        a,q=marks,set()
                    elif op=='and':
                        a,q=expanded[(x,y)[selectors[i]]],charges[(x,y)[selectors[i]]]
                    elif not expanded[x]:
                        a,q=expanded[y],charges[y]
                    elif not expanded[y]:
                        a,q=expanded[x],charges[x]
                    else:
                        a=expanded[x]|expanded[y]
                        q=(charges[x]|charges[y]|{i}) if a.bit_count()>=2 else set()
                    assert not marks&~a and (a==marks or marks.bit_count()>=2)
                    expanded[i],charges[i]=a,q
                cg=set.union(*(charges[t] for t in ts))
                assert all((self.sup[i]&u).bit_count()>=2 for i in cg)
                union=reduce(or_,(self.sup[t] for t in ts),0)
                assert len(cg)>=union.bit_count()-len(ts)
                paid.update(cg)
            total.update(paid);out.append(paid)
        assert max(total.values(),default=0)<=len(out)
        return out

m=Model()
u,v=U[1],U[5]
def atoms(x):return [j for j in range(13) if x>>j&1]
a,b,*_=atoms(u&~v);c,d,*_=atoms(v&~u);x,y,*_=atoms(8191&~(u|v))
g=m.add('or',m.add('or',a,c),m.add('or',b,d))
l=m.add('and',g,m.add('or',m.add('or',a,b),x))
r=m.add('and',g,m.add('or',m.add('or',c,d),y))
e=m.audit({u:[l],v:[r]})
assert [z[g] for z in e]==[2,1,1,0]
print('shared cross-group OR charges by socket choice', [z[g] for z in e])

rng=Random(80929)
multi=0;serial=0
for _ in range(500):
    m=Model()
    for stage in range(3):
        for _ in range(14):
            # Half of the ORs are biased toward one star, creating nontrivial targets.
            k=rng.choice(U)
            available=[i for i,s in enumerate(m.sup) if s and not s&~k] if rng.randrange(2) else list(range(len(m.sup)))
            x,y=rng.choices(available,k=2)
            m.add('or',x,y)
        if stage<2:
            x,y=rng.choices(range(len(m.sup)),k=2)
            if stage and rng.randrange(2):
                x=m.add('or',x,m.donors[0]);serial+=1
            m.add('and',x,y)
    goals={u:sorted({idx for idx,s in enumerate(m.sup) if s.bit_count()>=2 and not s&~u},key=lambda i:-m.sup[i].bit_count())[:2] for u in U}
    multi+=sum(bool(ts)for ts in goals.values())
    m.audit(goals)
print('random two-exception DAGs',500,'forced serial',serial,'nonempty target groups',multi)
