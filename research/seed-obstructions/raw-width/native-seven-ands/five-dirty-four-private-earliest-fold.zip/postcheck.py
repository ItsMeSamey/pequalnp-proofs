"""Signed controls and independent exhaustive verification by each left raw shore."""
from itertools import combinations
from nativecontrol import rows,edges
from raw_rectangle import atoms,private,ordinary,stars,negs,sx,candidates
def truth(s):
    return sum(1<<i for i,(p,t,y) in enumerate(rows) if s & (p|sx(t)))
traces={x:truth(x) for x in atoms}
def check(u):
    U=stars[u]
    guards=sum(1<<i for i,(p,t,y) in enumerate(rows) if y<0 and p&U and t&sum(private))
    dirty=sum(1<<i for i,(p,t,y) in enumerate(rows) if y<0 and p&U)
    pos=sum(1<<i for i,(p,t,y) in enumerate(rows) if y>0 and p&U and t in ordinary)
    right_candidates=len(atoms)
    bins=[0]*8
    for selection in range(1,1<<len(atoms)):
        left=[x for j,x in enumerate(atoms) if selection>>j&1]
        lt=0
        for x in left:lt|=traces[x]
        right=[r for r in atoms if not (r>=8192 and r in left) and not (traces[r]&lt&guards)]
        rt=0
        for x in right:rt|=traces[x]
        xt=lt&rt
        outside=any(not x&U for x in left) and any(not x&U for x in right)
        i=bool(xt&pos)+2*bool(xt&dirty)+4*outside;bins[i]+=1
    assert sum(bins)==4095 and bins[7]==0 and min(bins[3],bins[5],bins[6])>0,(u,bins)
    g,d,o,P,W=candidates(u)
    assert (g,len(d),o,len(P),len(W))==(36,12,24,3,0)
    print('owner',u,'maximal-right footprint histogram',bins)
    # Actual native diagrams whose selected X has two of the three required features.
    def actual(L,R,expect):
        xl=xr=0
        for x in L:xl|=traces[x]
        for x in R:xr|=traces[x]
        z=xl&xr
        off=bool(set(x for x in L if not x&U)) and bool(set(x for x in R if not x&U))
        assert not z&guards and (bool(z&pos),bool(z&dirty),off)==expect
        return next((i for i,(p,t,y) in enumerate(rows) if (1<<i)&z&dirty),None)
    tested=0
    for p,t in P:
        b=next(b for a,b in d if a==p)
        index=actual([p],[t,b],(True,True,False))
        print('  global implication control X = p AND (t OR b)',p,t,b,'dirty row',index)
        tested+=1
    a,b=next((a,b)for a,b in d if not(a|b)&U)
    index=actual([a],[b],(False,True,True))
    print('  no ordinary improvement control X = a AND b',a,b,'dirty row',index)
    p,t=P[0];r=next(a for a,j in edges if sx(j)==t and not a&U and a in atoms)
    assert actual([t],[p,r],(True,False,True)) is None
    print('  clean control X = t AND (p OR r)',t,p,r)
    assert tested==3
if __name__=='__main__':
    import time
    start=time.monotonic()
    for u in private:check(u)
    print('all four owners, 16380 raw left supports, 20 individual signed controls; elapsed %.3f s'%(time.monotonic()-start))
