"""Direct signed row lookup for the earliest private gate. No SAT solver or circuit search."""
from nativecontrol import rows,edges
from itertools import product
private=(2,4,8,32)
ordinary=(1,16,64)
def sx(t):return t<<13
stars={t:sum(p for p,j in edges if j==t)for t in private+ordinary}
regular=[1<<i for i in range(13) if sum(bool(st & (1<<i))for st in stars.values())>1]
atoms=regular+[sx(t)for t in ordinary]
negs={p|sx(t)for p,t,s in rows if s<0}

def candidates(u):
    U=stars[u]
    guards={n for n in negs if n&U and n&sx(sum(private))}
    # A pair is disallowed as a rectangle cross-pair by signed safety, or by a bare tag.
    good={(a,b)for a,b in product(atoms,repeat=2)
          if not (a==b and a>=8192) and not any((a|b)&~n==0 for n in guards)}
    dirty=[(a,b)for a,b in good if any(n&U and (a|b)&~n==0 for n in negs)]
    outside=[(a,b)for a,b in good if not (a|b)&U]
    ordinary_positive=[(p,sx(t))for p,t in edges if t in ordinary and p&U]
    survivors=set()
    for p,t in ordinary_positive:
        # Orient the raw X rectangle with p left and ordinary t right.
        for a,b in dirty:
            for c,d in outside:
                left=frozenset([p,a,c]);right=frozenset([t,b,d])
                if all((l,r)in good for l in left for r in right):
                    survivors.add((tuple(sorted(left)),tuple(sorted(right))))
    return (len(good),sorted(dirty),len(outside),sorted(ordinary_positive),sorted(survivors))
if __name__=='__main__':
    for u in private:
        g,d,o,p,w=candidates(u)
        print('owner',u,'allowed pairs',g,'dirty oriented pairs',len(d),'outside oriented pairs',o,'ordinary positives',p,'witnesses',len(w))
        print('dirty pairs',d,'sample witnesses',w[:8])
