from three import P,N,DEGREE_ONE
from pysat.formula import IDPool
from pysat.solvers import Solver
import sys,time
def run(tags,d,seconds,shape='',strong=True):
 k=len(tags)+int(__import__('os').environ.get('EXTRA_AND','0'));start=time.monotonic();U=sum(1<<(13+j) for j in tags)
 pos=[p for p in P if p&U];v=IDPool().id;s=Solver(name=__import__('os').environ.get('S33_SOLVER','g4'));add=s.add_clause
 memo={}
 def OR(xs):
  key=tuple(xs)
  if key not in memo:
   a=v(('or',key));memo[key]=a
   for x in xs:add([-x,a])
   add([-a]+xs)
  return memo[key]
 def AND(xs):return -OR([-x for x in xs])
 def sel(g,h):
  z=[v(('s',g,h,i))for i in range(20+min(g,d))];add(z);return z
 ss=[[sel(g,h)for h in range(2)]for g in range(k)]
 if shape:
  masks=list(map(int,shape.split(',')))
  for g in range(k):
   for h in range(2):
    for i,x in enumerate(ss[g][h][20:]):add([x if masks[2*g+h]>>i&1 else -x])
 for i in range(d):
  add([ss[j][h][20+i]for j in range(i+1,k)for h in range(2)])
  for j in range(d,k):add([-ss[j][0][20+i],-ss[j][1][20+i]])
 def evaluate(row,drop=-1):
  o=[]
  for g in range(k):
   if g==drop:o.append(None);continue
   arms=[]
   for z in ss[g]:
    xs=[x for i,x in enumerate(z[:20])if row>>i&1]
    xs.extend(AND([a,x])for a,x in zip(o,z[20:])if a is not None)
    arms.append(OR(xs))
   o.append(AND(arms))
  return o
 def final(o):return OR([x for x in o[d:]if x is not None])
 for p in pos:add([final(evaluate(p))])
 if strong:
  for g in range(k):
   dropped=[final(evaluate(p,g))for p in pos]
   for q,u in DEGREE_ONE.items():add([-x for x,p in zip(dropped,pos)if p&q or not p&(1<<(13+u))])
  for a,b,c in ((0,6,12),(1,3,5),(7,8,9),(2,4,10)):
   for o in evaluate(U|(8191^(1<<a)^(1<<b)^(1<<c))):add([o])
 dirty=[[]for _ in range(d)]
 for n in N:
  o=evaluate(n)
  for x in o[d:]:add([-x])
  for i in range(d):dirty[i].append(o[i])
 for xs in dirty:add(xs)
 while time.monotonic()-start<seconds:
  s.conf_budget(600);r=s.solve_limited()
  if r is None:continue
  if not r:return 'UNSAT'
  m=set(s.get_model());gates=[[[i for i,x in enumerate(z)if x in m]for z in gate]for gate in ss]
  base=[[[13+t],[i for i in range(13) if any(p&(1<<i) and p&(1<<(13+t))for p in P)]]for t in range(7)if t not in tags]
  full=base+[[[i if i<20 else i+len(base)for i in z]for z in gate]for gate in gates]
  root=list(range(20,20+len(base)))+list(range(20+len(base)+d,20+len(base)+k))
  for j,r in enumerate(P+N):
   for g,(a,b)in enumerate(full):
    if all(any(r&(1<<i)for i in z)for z in (a,b)):r|=1<<(20+g)
   assert any(r&(1<<i)for i in root)==(j<len(P))
  return {'gates':full,'root':root}
 return 'UNKNOWN'
if __name__=='__main__':
 tags,d,secs=sys.argv[1:4];print(tags,d,run(tuple(map(int,tags)),int(d),float(secs),sys.argv[4] if len(sys.argv)>4 else '',len(sys.argv)<=5),flush=True)
