from actions import actions,P,N
from itertools import combinations
h={i:sum(r>>13 for r in P if r&1<<i)for i in range(13)}
maps=[]
for pm,ns in actions():
 if set(ns)!=set(N):continue
 ls=[h[pm[1<<i].bit_length()-1].bit_length()-1 for i in (1,3,4,5)]
 tagmap={u:v for u,v in zip((5,1,2,3),ls)}
 for u in (0,4,6):
  eq=[i for i in range(13)if h[i]>>u&1]
  t=127
  for i in eq:t&=h[pm[1<<i].bit_length()-1]
  assert t.bit_count()==1
  tagmap[u]=t.bit_length()-1
 maps.append(tagmap)
def key(js):return min(tuple(sorted(p[j]for j in js))for p in maps)
from collections import Counter
orbits=Counter(key(js)for js in combinations(range(7),3))
if __name__=='__main__':print(len(maps),orbits)
