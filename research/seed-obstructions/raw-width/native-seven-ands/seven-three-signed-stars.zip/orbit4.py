from orbit3 import key
from itertools import combinations
from collections import Counter
print(Counter(key(js)for js in combinations(range(7),4)))
