from contextlib import redirect_stdout
import io
with redirect_stdout(io.StringIO()):
    import chart_inputs as native
d2=[p for p,s in native.stars.items() if s.bit_count()==2]
d3=[p for p,s in native.stars.items() if s.bit_count()==3]
assert d2==[1,4,64] and d3==[128,256,512,1024,2048,4096]
for unions in ([],[129],[4160],[129,4160]):
    print(unions, 'covered degree-two', [p for p in d2 if not any(p&c for c in unions)],
          'covered degree-three', [p for p in d3 if not any(p&c for c in unions)])
