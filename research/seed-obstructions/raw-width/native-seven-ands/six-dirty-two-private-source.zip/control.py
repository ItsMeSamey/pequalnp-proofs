from physical import *
from pathlib import Path
import json
def build(i,w,k,donate=True):
 h,kpos,mode,B,b=list(charts())[i]
 cuts=[(h,2,kpos if mode=='cross' else B),(kpos,4,B)];extra=private[2:b];ex=set(range(6))-{h,kpos}
 ar=[{1<<j for j in range(20)if m>>j&1}|{-1-j for j in range(6)if m>>(20+j)&1}for m in w]
 assert len(ar)==16
 # symbols >2^20 are private to this factoring routine
 for n,x in enumerate((129,4160),22):
  pr={p for p in points if p&x}
  for a in ar:
   if pr<=a:a.difference_update(pr);a.add(1<<n)
 defs={};known={1<<i:i for i in range(20)}|{1<<22:20,1<<23:21}
 while any(len(a)>1 for a in ar):
  ps=Counter(p for a in ar for p in combinations(sorted(a),2));p=min(ps,key=lambda z:(-ps[z],z));x=1<<(24+len(defs));defs[x]=p
  for a in ar:
   if set(p)<=a:a.difference_update(p);a.add(x)
 net=[];ands=[]
 def gate(op,l,r):net.append((op,l,r));return 21+len(net)
 def phys(j):
  if j not in known:
   a,b=defs[j];known[j]=gate('or',phys(a),phys(b))
  return known[j]
 for g in range(8):
  a,=ar[2*g];b,=ar[2*g+1];ands.append(gate('and',phys(a),phys(b)))
  if g<6:known[-1-g]=ands[-1]
 o=ands[6]
 for n in ands[7:]:o=gate('or',o,n)
 def eval(m):
  z=m|bool(m&129)<<20|bool(m&4160)<<21
  for i,(op,l,r)in enumerate(net,22):
   z|=(((z>>l&z>>r)if op=='and' else(z>>l|z>>r))&1)<<i
  return z
 def marks(m):
  z=eval(m);return {i for i,n in enumerate(ands)if (z>>net[n-22][1]|z>>net[n-22][2])&1}
 dirty=set()
 for p,t,y in rows:
  z=eval(p|sx(t))
  if y:assert bool(z>>o&1)==(y==1)
  if y<0:dirty.update(i for i,n in enumerate(ands)if z>>n&1)
 assert dirty=={0,1,2,3,4,5}
 for t,i in ((2,h),(4,kpos),(8,6),(32,7)):assert marks(q[t])=={i}
 for d,t,b in cuts:assert marks(sx(t))=={d,b}
 for g,t in enumerate((8,32),6):assert marks(sx(t))==({g,kpos if mode=='cross' else B}if t in extra else {g})
 for t,m in zip(ordt,k):assert sum(1<<i for i in marks(sx(t)))==m
 for t in stars:
  assert len(marks(sx(t)))<=2 and all(not (eval(sx(t))>>n)&1 for n in ands)
  assert any((eval(sx(t))>>wire)&1 and all(not (eval(sx(v))>>wire)&1 for v in stars if v!=t)for n in ands for wire in net[n-22][1:])
 assert any(all(g in marks(sx(t))for g,t in zip(gs,ordt))for gs in permutations(ex,3))
 assert all(len(marks(sx(a|b)))<=3 for a,b in combinations(stars,2))
 origins=[{1<<i}for i in range(20)]+[{1,128},{64,4096}]
 for op,l,r in net:
  a,b=origins[l],origins[r];z=a|b if op=='or' else {i|j for i in a for j in b}
  origins.append({i for i in z if not any(j!=i and not j&~i for j in z)})
 return len(net),origins[o]==P,net,ands,o

