from coupled import *
for h,q in enumerate(priv):
 u=own[h];U=sum(e&8191 for e in Ps if e&(u<<13))
 for t in ordt:
  T=sum(e&8191 for e in Ps if e&(t<<13))
  A0=q;B0=(u|t)<<13;D0=(u<<13)|(T&~U)
  other=sum(1<<i for i in range(13))^sum(priv)
  Ballow=[1<<i for i in range(13)if 1<<i&other and not any(n&A0 and n&(1<<i) and n&D0 for n in Ns)]
  Dallow=sum(1<<i for i in range(13)if 1<<i&other and not any(n&A0 and n&B0 and n&(1<<i) for n in Ns))
  # C's tag-facing raw side is dark on n containing u and some T point outside U.
  bad=[n for n in Ns if n&(u<<13) and n&(T&~U)]
  allowed=(1<<20)-1
  for n in bad:allowed&=~n
  assert allowed==U|(t<<13) and not Ballow and Dallow==T
  assert len([e for e in Ps if e&(U&T)])==3 and (U&T).bit_count()==1 and (T&~U).bit_count()==3
  assert all(sum(1 for p in (1,2,4,8,16,32,64,128,256,512,1024,2048,4096) if p&c and p&mask)<=1 for c in (129,4160)for mask in (U,T))
  print(h,t,'A universe',U,'B tags',u|t,'C dark complement',allowed,'D universe',Dallow)
  # Test all 2^3 * 2^3 * 2 choices, and physically priced numerical counts.
  for asub in range(8):
   UU=[1<<j for j in range(13)if (U^q)>>j&1]
   A=q|sum(p for j,p in enumerate(UU) if asub>>j&1)
   for csub in range(8):
    C=sum(p for j,p in enumerate(UU)if csub>>j&1)
    for D in (T&~U,T):
     def helpers(n):
      x=bool(n&A and n&B0)
      y=bool((x or n&(C|(t<<13))) and n&(D|(u<<13)))
      return x,y
     foreign={z for z in Ps if not z&B0}
     forced={z for z in foreign if not any(helpers(z))}
     ownmissing={z for z in Ps if z&(u<<13) and not z&(A|C)}
     assert all(not any(helpers(z)) for z in ownmissing)
     a=(A|C).bit_count();d=D.bit_count()
     assert len(foreign)==20 and len(forced)>=19 and len(ownmissing)==4-a
     assert len(forced)+d>=23
     assert 8+5+len(forced|ownmissing)-6+(a-1)+1+d+1>=35
print('verified',4*3*128,'raw arm tuples')
