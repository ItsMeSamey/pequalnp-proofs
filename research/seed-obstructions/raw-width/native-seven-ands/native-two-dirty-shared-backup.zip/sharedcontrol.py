from coupled import *
for q,u in zip(priv,own):
 for t in ordt:
  U=sum(e&8191 for e in Ps if e&(u<<13)); T=sum(e&8191 for e in Ps if e&(t<<13))
  def ev(p,w):
   J=bool((p&U) and (w&(u|t)))
   E=bool((w&t or J) and (w&u or p&T))
   G=E and (J or bool(p&T))
   F=G or any(p&(e&8191) and w&(e>>13) for e in Ps if e>>13 not in (u,t))
   return F,J,E,G
  for p,w,s in rows:
   assert s==0 or ev(p,w)[0]==(s==1)
  assert ev(q,t)[1:] == (True,False,False) and ev(0,u|t)[1:]==(False,True,False)
  for Uhit in (False,True):
   for Thit in (False,True):
    for uh in (False,True):
     for th in (False,True):
      J=Uhit and (uh or th); E=(th or J) and (uh or Thit)
      assert (E and (J or Thit))==((uh and Uhit) or (th and Thit))
  print('true native 38-gate / eight-AND shared-backup control',q,t)
