from coupled import *
from collections import Counter
bins=Counter()
for h in range(4):
    M=Coupled(h)
    for c in range(1,8):
        for b in range(4):
            if b<3 and c.bit_count()>=2 and c>>b&1:continue
            yes=set()
            for order in permutations(range(5)):
                if M.one(order,c,b):yes.add(order)
            allowed={o for o in permutations(range(5)) if o.index(4)<o.index(b)} if (b==3 or c==1<<b) else set()
            assert yes==allowed
            print(h,c,b,len(yes))
            bins[len(yes)]+=1
print('order bins',sorted(bins.items()))
