from coupled import *
def orig_receipt():
    signed=set(Ns)
    def check(r):return any(r&~n==0 for n in signed)
    count=0
    for h,q in enumerate(priv):
        for x in ordt+own:
            if x==own[h]:continue
            for v,p_not_v in zip(ordt,(1,4,64)):
                if x==v:continue
                # Need a C6 neighbor of v not adjacent to the guest x.
                ps=[p for p in (1,4,64) if p|(v<<13) in Ps and p|(x<<13) not in Ps and check(q|p|(x<<13))]
                assert ps
                print('signed',h,x,v,min(ps));count+=1
    print('witness triples',count)
if __name__=='__main__':orig_receipt()
