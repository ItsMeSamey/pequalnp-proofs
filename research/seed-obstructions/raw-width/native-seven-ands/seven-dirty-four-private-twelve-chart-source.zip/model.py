"""Seven dirty ANDs and four dirty private owners, 12 physical base charts."""
from itertools import combinations
from nativecontrol import edges,rows
from pysat.formula import IDPool
private=(2,4,8,32);ordinary=(1,16,64);tags=private+ordinary
def sx(t):return t<<13
P={p|sx(t)for p,t in edges}
N0={p|sx(t)for p,t,y in rows if y<0}
N={n for n in N0 if not any(n!=m and not n&~m for m in N0)}
U={t:sum(p for p,j in edges if j==t)for t in tags}
points=tuple(1<<i for i in range(13))
q={t:next(p for p in points if p&U[t] and sum(bool(p&a)for a in U.values())==1)for t in private}
cycle=(1,4,64)
def charts():
    for mode in ('ext','hub'):
        yield mode,6,6
        for third in range(2,7): yield mode,7,third
class Model:
    def __init__(self,mode,B,third):
        assert (mode,B,third) in charts()
        self.mode=mode;self.B=B;self.third=third
        C=self.C=[];V=IDPool().id
        def W(g,s,j):return V(('source',g,s,j))
        def A(g,s,n):return V(('arm',g,s,n))
        def G(g,n):return V(('gate',g,n))
        def T(g,n):return V(('hot',g,n))
        self.W=W;self.A=A;self.G=G;self.T=T
        def emit(i,xs,and_gate):
            if and_gate:
                C.append([i,*[-x for x in xs]]);C.extend([-i,x]for x in xs)
            else:
                C.append([-i,*xs]);C.extend([i,-x]for x in xs)
            return i
        self.selectors={(g,s):tuple(W(g,s,j)for j in range(20+min(g,7)))for g in range(8)for s in (0,1)}
        exterior_dirty=(0,1,third)
        ext=self.exterior=(*exterior_dirty,7)
        owner=self.owner=dict(zip(private,(g for g in range(7) if g not in exterior_dirty)))
        backup={t:(B if mode=='ext' or t==32 else owner[32])for t in private}
        guests=private if mode=='ext' else private[:3]
        for g in range(8):
            own=next((t for t in private if owner[t]==g),None)
            for s in (0,1):
                for j in range(20):
                    x=1<<j;val=None
                    if x in q.values():val=own is not None and x==q[own] and s==1
                    elif j>=13 and (1<<(j-13))in private:
                        t=1<<(j-13)
                        if g==owner[t]:val=s==0
                        elif g!=backup[t]:val=False
                        elif own:val=s==0
                    elif own and s==1 and not x&U[own]:val=False
                    elif own in guests and s==0:val=False
                    if val is not None:C.append([(1 if val else -1)*W(g,s,j)])
        for t in private:
            g=backup[t];j=13+t.bit_length()-1;C.append([W(g,0,j),W(g,1,j)])
        probes=N|P|{1<<i for i in range(20)}|{sx(a|b)for a,b in combinations(tags,2)}
        for n in sorted(probes):
            for g in range(8):
                for s in (0,1):
                    ls=[W(g,s,j)for j in range(20)if n>>j&1]
                    ls.extend(emit(V(('active',g,s,d,n)),[W(g,s,20+d),G(d,n)],True)
                              for d in range(min(g,7)))
                    emit(A(g,s,n),ls,False)
                emit(G(g,n),[A(g,0,n),A(g,1,n)],True);emit(T(g,n),[A(g,0,n),A(g,1,n)],False)
        self.positive={n:(G(7,n),)for n in P}
        for c in self.positive.values():C.append(list(c))
        for n in N:C.append([-G(7,n)])
        for g in range(7):C.append([G(g,n)for n in N])
        for t in private:
            g=owner[t];b=backup[t];p=q[t];j=13+t.bit_length()-1
            C.extend([-T(i,p)]for i in range(8)if i!=g)
            C.extend([[G(g,p|sx(t))],[G(b,p|sx(t))]])
            C.extend([-G(g,n)]for n in N if n&sx(t))
            C.extend([-G(g,n),-G(b,n)]for n in N)
            for s in (0,1):
                mark=W(b,s,j)
                for n in probes:C.append([-mark,-G(g,n),A(b,1-s,n)])
            if t in guests:
                C.extend([-G(g,n)]for n in N if n&sx(sum(private)))
                C.extend([-G(g,p)]for p in points)
                C.extend([A(g,1,p)]for p in points if p&U[t])
        if mode=='ext':
            for s in (0,1):
                first=W(B,s,14)
                for t in private[1:]:
                    later=W(B,s,13+t.bit_length()-1);C.extend([[first,-later],[-first,later]])
        for t in tags:
            n=sx(t);C.extend([-G(g,n)]for g in range(8))
            C.extend([-T(g,n)for g in gg]for gg in combinations(range(8),3))
            choices=[]
            for g in range(8):
                for s in (0,1):
                    z=V(('exclusive',g,s,t));choices.append(z);C.append([-z,A(g,s,n)])
                    C.extend([-z,-A(g,s,sx(v))]for v in tags if v!=t)
            C.append(choices)
        for a,b in combinations(tags,2):
            n=sx(a|b);C.extend([-T(g,n)for g in gg]for gg in combinations(range(8),4))
        for j in (1,2,3):
            for tt in combinations(ordinary,j):
                for cut in combinations(ext,j-1):C.append([T(g,sx(t))for g in ext if g not in cut for t in tt])
        # Each private needs two actual exterior dirty ancestors.  When B is clean
        # and the third exterior is early, these may be different pairs for different private sites.
        reaches={}
        for start in exterior_dirty:
            for g in range(start+1,7):
                vias=[W(g,s,20+start)for s in (0,1)]
                for d in range(start+1,g):
                    for side in (0,1):
                        vias.append(emit(V(('via',start,d,g,side)),[reaches[start,d],W(g,side,20+d)],True))
                reaches[start,g]=emit(V(('reaches',start,g)),vias,False)
        for g in owner.values():
            for pair in combinations(exterior_dirty,2):
                C.append([reaches[a,g] for a in pair if a<g])
        # The selected physical netlist is live.  The sole terminal is g=7.
        for g in range(7):
            C.append([W(j,s,20+g)for j in range(g+1,8)for s in (0,1)])
        for g in ext:
            prev=[]
            for j in range(20+min(g,7)):
                a,b=W(g,0,j),W(g,1,j);C.append(prev+[-a,b])
                same=V(('lex',g,j));C.append(prev+[a,b,same]);C.append(prev+[-a,-b,same]);prev=[-same]
