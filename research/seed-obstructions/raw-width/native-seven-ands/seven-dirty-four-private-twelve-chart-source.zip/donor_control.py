"""Predicted D6-sensitive native witnesses, one per possible clean-output role."""
from pathlib import Path
from itertools import permutations
from model import *
def physical(B):
    dirt=[(128,512|sx(1)),(256,4096|sx(64))]
    if B==7:dirt.append((1024,2048|sx(16)))
    before=len(dirt);w=list(dirt)
    extra=sum(1<<(20+d)for d in range(before))
    for t in private:w.append((sx(t)|extra,U[t]))
    prior=sum(1<<(20+d)for d in range(before,before+4))
    if B==7:w.append((sx(sum(private)),prior))
    else:
        w.append((sx(sum(private)),prior|1024))
        w.append((1<<26,prior|sx(16)))
    assert len(w)==8
    return w
def evaluate(w,n,omit=False):
    wires=n;outs=[];socks=[]
    for g,(a,b) in enumerate(w):
        z=wires&~(1<<26) if omit else wires
        pair=(bool(z&a),bool(z&b));socks.append(pair);outs.append(all(pair))
        if all(pair):wires|=1<<(20+g)
    return outs,socks
def native(B):
    w=physical(B);positive=set();lost=set();dirty=set()
    for p,t,y in rows:
        good,_=evaluate(w,p|sx(t));bad,_=evaluate(w,p|sx(t),True)
        if y<0:
            assert not good[7] and not bad[7];dirty.update(i for i,v in enumerate(good)if v)
        if y>0:
            if good[7]:positive.add((p,t))
            if good[7] and not bad[7]:lost.add((p,t))
    assert dirty==set(range(7))
    assert positive=={e for e in edges if e[1]in private}
    expected={e for e in edges if e[1]in ((32,)if B==7 else private)}
    assert lost==expected
    def hot(n):return {g for g,s in enumerate(evaluate(w,n)[1])if any(s)}
    own=dict(zip(private,range(3 if B==7 else 2,7 if B==7 else 6)))
    ext=set(range(8))-set(own.values())
    for t,g in own.items():
        assert hot(q[t])=={g} and hot(sx(t))=={g,B}
        for p in points:
            if p&U[t]:assert evaluate(w,p)[1][g][1]
    for t in tags:
        assert not any(evaluate(w,sx(t))[0])and len(hot(sx(t)))<=2
        assert any(evaluate(w,sx(t))[1][g][s]and
                   all(not evaluate(w,sx(j))[1][g][s]for j in tags if j!=t)
                   for g in range(8)for s in (0,1))
    assert all(len(hot(sx(a|b)))<=3 for a,b in combinations(tags,2))
    assert any(all(g in hot(sx(t))for g,t in zip(gg,ordinary))for gg in permutations(ext,3))
    print('ext',B,'actual seven dirties, sixteen private positive rows; deleted D6 lost',sorted(lost))
    return w
def pinned(cls,B,w,result):
    from pysat.solvers import Glucose4
    m=cls('ext',B,2 if B==7 else 6);pins=[]
    for g,h in enumerate(w):
        arms=list(h)
        if g in m.exterior:arms.sort(key=lambda z:tuple(bool(z&(1<<j))for j in range(20+min(g,7))))
        for side,z in enumerate(arms):
            pins.extend((1 if z&(1<<j)else -1)*v for j,v in enumerate(m.selectors[g,side]))
    drop={m.positive[p|sx(t)]for p,t in edges if t in ordinary}
    assert len(drop)==12
    with Glucose4(bootstrap_with=[c for c in m.C if tuple(c)not in drop])as s:assert s.solve(assumptions=pins)is result
    with Glucose4(bootstrap_with=m.C)as s:assert s.solve(assumptions=pins)is False
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('B',type=int,choices=[6,7]);ap.add_argument('--signed-cnf',action='store_true')
    args=ap.parse_args();w=native(args.B)
    if args.signed_cnf:
        src=Path(__file__).with_name('model.py').read_text()
        expr='for d in range(min(g,7)))';assert src.count(expr)==1;ns={'__name__':'legacy'}
        exec(compile(src.replace(expr,'for d in range(min(g,6)))'),'omit_d6.py','exec'),ns)
        pinned(Model,args.B,w,True);pinned(ns['Model'],args.B,w,False)
        print('corrected pinned SAT; omitted D6 pinned UNSAT; full 28 positive rows UNSAT at both pins')
