from pathlib import Path
from tempfile import TemporaryDirectory
from hashlib import sha256
import gzip,subprocess,argparse
from model import Model,charts
from pysat.solvers import Glucose4
def run(chart,checker,verify):
    m=Model(*chart);C=m.C
    key='-'.join(map(str,chart));target=Path('proofs')/(key+'.drat.gz')
    cnf=('p cnf %d %d\n'%(max(abs(x)for c in C for x in c),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode()
    if verify:proof=gzip.decompress(target.read_bytes())
    else:
        with Glucose4(bootstrap_with=C,with_proof=True)as s:
            s.conf_budget(30000);a=s.solve_limited()
            if a is not False:print(key,'status',a,flush=True);return
            proof=('\n'.join(s.get_proof())+'\n').encode()
    with TemporaryDirectory()as root:
        p=Path(root);f=p/'c';g=p/'proof';trim=p/'small';f.write_bytes(cnf);g.write_bytes(proof)
        if not verify:
            r=subprocess.run([checker,str(f),str(g),'-l',str(trim),'-C'],capture_output=True)
            assert r.returncode==0 and b's VERIFIED' in r.stdout
            proof=trim.read_bytes();g.write_bytes(proof)
        r=subprocess.run([checker,str(f),str(g),'-i'],capture_output=True)
        assert r.returncode==0 and b's VERIFIED' in r.stdout
    if not verify:
        target.parent.mkdir(exist_ok=True);target.write_bytes(gzip.compress(proof,compresslevel=6,mtime=0))
    print(key,len(C),len(proof),sha256(cnf).hexdigest(),sha256(proof).hexdigest(),'VERIFIED',flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('checker');ap.add_argument('key');ap.add_argument('--verify',action='store_true')
    a=ap.parse_args();table={'-'.join(map(str,c)):c for c in charts()}
    run(table[a.key],a.checker,a.verify)
