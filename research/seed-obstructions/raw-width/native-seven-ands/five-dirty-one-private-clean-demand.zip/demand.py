from itertools import combinations
from nativecontrol import rows,edges
O=(1,16,64); L=(2,4,8,32); P=(1,4,64)
N={v:sum(p for p,t in edges if t==v) for v in O+L}
q={v:next(p for p,t in edges if t==v and sum(bool(p & m) for m in N.values())==1)for v in L}
regular=8191^sum(q.values())
signed=[(i,p,t) for i,(p,t,y) in enumerate(rows) if y<0]
def neg(p,t,need=0):
 return next(i for i,n,w in signed if n&p==p and w&t==t and (not need or n&need))
for u in L:
 for v in L:
  if v==u:continue
  for t in O+tuple(j for j in L if j!=u):
   neg(q[u],v|t)
   if t!=v:neg(q[u]|q[v],t)
  M=N[v]&~N[u]
  assert len([neg(q[u]|(1<<j),0,M) for j in range(13)])==13
 for v,w in combinations(set(L)-{u},2):
  z,=set(L)-{u,v,w}
  s=N[u]&N[z];Q=q[u];need=N[v]|N[w]
  pm=regular|Q;tm=sum(O)+u
  good={(p&pm,t&tm) for _,p,t in signed if p&need}
  escapes={(p&pm,t&tm) for _,p,t in signed if not any(a&(p&pm)==p&pm and b&(t&tm)==t&tm for a,b in good)}
  assert len(escapes)==3 and (Q|sum(P),0) in escapes
  for n,t in escapes:
   assert not t and n.bit_count()==4 and n&Q
   if n!=Q|sum(P):assert n&s and (n&sum(P)).bit_count()==2
   # All proper subsets of each witness have a petal-bearing dominating native negative.
   for j in range(13):
    if n&(1<<j):neg(n^(1<<j),0,need)
  print('dirty, two tag recipients, complementary tag, shared point, escapes',u,sorted((v,w)),z,s,sorted(n for n,t in escapes))
print('Guest exclusion and all 156 raw-H point-pair extensions verified')
