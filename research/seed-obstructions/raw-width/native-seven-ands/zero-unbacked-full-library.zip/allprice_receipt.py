import sys
from fastprice import *
from controls import verify
def check(by, cap):
    keys=[k for k in keyset() if sum(m.bit_count()==2 for m in k)==by]
    total=0
    for k in keys:
        n=0; floor=999
        for w in catalogue(k,cap):
            T=libraryfast(w)
            if n==0:
                assert T==library(w)
                assert verify(w,tuple(b.bit_count()-1 for b in k))>=34
            c=cost(T)
            if c < (26 if by==3 else 21):
                print('open layout',k,w,c,flush=True)
                return False
            n+=1;floor=min(floor,c)
        assert 0<n<cap,(k,n)
        total+=n
        print(k,n,floor,flush=True)
    assert (len(keys),total)=={2:(33,133740),3:(9,276)}[by]
    print('complete',by,len(keys),total,flush=True)
    return True
if __name__=='__main__':
    assert check(int(sys.argv[1]),12000)
