from libraryprice import *
from collections import Counter
from ast import literal_eval
neglist=sorted({(p,t) for p,t,y in rows if y<0})
samples=neglist+[(1<<i,0) for i in range(13)]
def rawmask(a):
    return sum(1<<j for j,(p,t) in enumerate(samples) if a & (p|(t<<13)))
raw=[rawmask(x) for x in atoms]
onepoints=(1<<13)-1
origin={u:rawmask(u<<13) & ((1<<len(neglist))-1) for u in prv}
@lru_cache
def evalraw(x):
    return 0 if x==0 else raw[(x&-x).bit_length()-1] | evalraw(x&(x-1))
def evalarm(x,donors):
    a=evalraw(x&4095)
    for g,d in enumerate(donors):
        if (x>>(12+g))&1:a|=d
    return a
def libraryfast(w):
    d=[]
    for a,b in w[:2]:d.append(evalarm(a,d)&evalarm(b,d))
    T=[]
    for u,U in private_stars.items():
        lo=hi=U
        for j,m in enumerate(d):
            if m&origin[u]:continue
            hi |= 1<<(20+j)
            lo &= ~(m>>len(neglist))
        T.append((lo,hi))
    for a,b in w:
        for x in (a,b):
            m=convert(x)
            if m.bit_count()>1:T.append((m,m))
    return tuple(sorted(set(T)))
def cost(T):
    base=list(range(len(T)))
    orders=(base,base[::-1],sorted(base,key=lambda i:T[i][0].bit_count()),sorted(base,key=lambda i:-T[i][0].bit_count()))
    c=0
    for p in orders:
        c=max(c,trial(T,p))
        if c>=21:return c
    return lower(T)
def clean_swap(k):return tuple((b&3)|((b&4)<<1)|((b&8)>>1) for b in k)
def keyset():
    out=set()
    for line in Path(__file__).with_name('footprints.log').read_text().splitlines():
        if not line.startswith('(') or 'False' in line:continue
        k=literal_eval(line.split(') ')[0]+')')
        out.add(min(k,clean_swap(k)))
    return sorted(out)
def screen(k,cap):
    hist=Counter();first=[]
    for w in catalogue(k,cap):
        T=libraryfast(w)
        if not hist:assert T==library(w)
        c=cost(T);hist[c]+=1
        if c<21 and len(first)<4:first.append(w)
    print(k,sum(hist.values()),min(hist),list(sorted(hist.items())),first,flush=True)
    return sum(hist.values())<cap
if __name__=='__main__':
    import sys
    by=int(sys.argv[1]);cap=int(sys.argv[2])
    for k in keyset():
        if sum(m.bit_count()==2 for m in k)==by:screen(k,cap)
