from fastprice import *
keys=[k for k in keyset() if sum(m.bit_count()==2 for m in k)==1]
assert len(keys)==18
count=0
for k in keys:
    n=0
    for w in catalogue(k,3000):
        T=libraryfast(w)
        if n==0:
            assert T==library(w)
            from controls import verify
            assert verify(w,tuple(b.bit_count()-1 for b in k))>=34
        assert cost(T)>=21,(k,w)
        n+=1
    assert 0<n<3000, (k,n)
    count+=n
    print(k,n,flush=True)
assert count==4386
print('Preterminal bound >=21 on all',count,'complete charts.')
