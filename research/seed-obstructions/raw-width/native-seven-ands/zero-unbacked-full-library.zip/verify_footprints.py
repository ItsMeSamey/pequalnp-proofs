from ast import literal_eval
from itertools import permutations,product
from collections import Counter
from controls import *
data={}
for line in Path(__file__).with_name('footprints.log').read_text().splitlines():
    if not line.startswith('('):continue
    a,b=line.split(') ',1); key=literal_eval(a+')'); assert key not in data
    data[key]=literal_eval(b)
opts=[m for m in range(1,16)if m.bit_count()<=2]
expect={k for k in product(opts,repeat=3) if all((a|b).bit_count()<=3 for a,b in combinations(k,2)) and any(all(c>>s&1 for c,s in zip(k,pp)) for pp in permutations(range(4),3))}
assert set(data)==expect and None not in data.values()
valid=[]
for k,w in data.items():
    if w is False:continue
    for i,t in enumerate(tags):
        assert k[i]==sum(1<<j for j,x in enumerate(checked_valuation(w,0,t))if any(x))
    assert verify(w,[m.bit_count()-1 for m in k])>=1
    valid.append(k)
print('indexed',len(data),'SAT',len(valid),'UNSAT',sum(w is False for w in data.values()))
print('SAT by repeat count',sorted(Counter(sum(m.bit_count()==2 for m in k) for k in valid).items()))
triple=[k for k in valid if all(m.bit_count()==2 for m in k)]
print('all three repeat',sorted(set(tuple(sorted(k))for k in triple)))
assert all(k[0]&k[1]&k[2] in (2,4,8) for k in triple)
