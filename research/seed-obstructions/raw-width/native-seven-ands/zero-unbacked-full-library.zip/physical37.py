from controls import *
import json
w=[[516,46],[1536,46],[9216,4289],[2048,275]]
U=[(2,128,2048,4096),(8,128,256,1024),(16,256,512,2048),(32,512,1024,4096)]
private_tags=[32,2,4,8]
nets={}; targets=[{p.bit_length()-1 for p in z} for z in U]
for g,ss in enumerate(w):
    for m in ss:targets.append({atoms[j].bit_length()-1 if j<12 else 20+j-12 for j in range(12+min(g,2)) if m>>j&1})
n=24
while any(len(z)>1 for z in targets):
    cnt=Counter(pair for z in targets for pair in combinations(sorted(z),2))
    a,b=min(cnt,key=lambda k:(-cnt[k],k))
    nets[n]='or',a,b
    for z in targets:
        if {a,b}<=z:z.difference_update((a,b));z.add(n)
    n+=1
ends=[next(iter(z)) for z in targets]
for i in range(4):nets[20+i]='and',ends[4+2*i],ends[5+2*i]
terms=[22,23]
for v,t in zip(ends[:4],private_tags):
    nets[n]='and',v,13+t.bit_length()-1;terms.append(n);n+=1
root=terms[0]
for v in terms[1:]:
    nets[n]='or',root,v;root=n;n+=1
ids={i:i for i in range(20)}; ops=[]
def visit(node):
    if node in ids:return ids[node]
    op,a,b=nets[node]; u=visit(a);v=visit(b)
    ids[node]=20+len(ops);ops.append([op,u,v]);return ids[node]
output=visit(root)
assert len(ops)==37 and sum(g[0]=='and' for g in ops)==8 and output==56
dirty=set()
for p,t,s in rows:
    raw=p|(t<<13);arr=[bool(raw>>j&1) for j in range(20)]
    for j,(op,a,b) in enumerate(ops,20):
        y=(arr[a] and arr[b]) if op=='and' else (arr[a] or arr[b])
        arr.append(y)
        if op=='and' and y and s<0:dirty.add(j)
    assert not s or arr[-1]==(s==1)
assert dirty=={ids[20],ids[21]}
Path(__file__).with_name('physical37.json').write_text(json.dumps({'input_order':'13 native point bits followed by 7 tag bits','gates':ops,'output':output,'dirty':sorted(dirty)},indent=2)+'\n')
print('physical gates',len(ops),'OR/AND',sum(z[0]=='or' for z in ops),8,'native rows',len(rows),'dirty',sorted(dirty))
