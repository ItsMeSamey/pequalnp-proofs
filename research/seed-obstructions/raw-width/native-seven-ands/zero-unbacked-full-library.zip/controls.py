from exterior import *
from ast import literal_eval
from collections import Counter
def price(expressions):
    gates=[];targets=[set(z) for z in expressions]
    while any(len(z)>1 for z in targets):
        occ=Counter(pair for z in targets for pair in combinations(sorted(z),2))
        a,b=min(occ,key=lambda x:(-occ[x],x))
        k=24+len(gates);gates.append((a,b))
        for z in targets:
            if a in z and b in z:
                z.difference_update((a,b));z.add(k)
    return len(gates)
def checked_valuation(w,p,t):
    val=pack(p,t);marks=[]
    for g,ss in enumerate(w):
        arms=[bool(m&val) for m in ss];marks.append(arms)
        if all(arms):val|=1<<(12+g)
    return marks
def verify(w,bits):
    private_stars={v:sum({p for p,t,s in rows if s==1 and t==v}) for v in (2,4,8,32)}
    cx=[[i for i in range(13) if U>>i&1] for U in private_stars.values()]
    def local(j):return atoms[j].bit_length()-1 if j<12 else 20+j-12
    for g,ss in enumerate(w):
        for m in ss:cx.append([local(j) for j in range(12+min(g,2)) if m>>j&1])
    dirty=set()
    for p,t,s in rows:
        marks=checked_valuation(w,p,t)
        out=any(all(x) for x in marks[2:]) or any(p&U and t&v for v,U in private_stars.items())
        if s<0:dirty.update(i for i,x in enumerate(marks) if all(x))
        assert not s or out==(s==1)
    assert dirty=={0,1}
    for j,t in enumerate(tags):
        n=sum(any(x) for x in checked_valuation(w,0,t))
        if bits is not None:assert n==1+bits[j]
    return 13+price(cx)
if __name__=='__main__':
    for line in Path(__file__).with_name('counts.log').read_text().splitlines():
        if line.startswith('('):
            bits,end=line.split(') ',1);bits=literal_eval(bits+')')
            if end!='False':print(bits,verify(literal_eval(end),bits))
