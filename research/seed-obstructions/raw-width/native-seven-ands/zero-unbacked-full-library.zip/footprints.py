from exterior import *
from itertools import permutations,product
from time import monotonic
opts=[m for m in range(1,16) if m.bit_count()<=2]
t0=monotonic()
for cs in product(opts,repeat=3):
    if any((a|b).bit_count()>3 for a,b in combinations(cs,2)):
        continue
    if not any(all(c>>s&1 for c,s in zip(cs,pp)) for pp in permutations(range(4),3)):
        continue
    ass=[(1 if m>>g&1 else -1)*hot(g,n) for n,m in zip(tt,cs) for g in range(4)]
    w=solve(ass,3000)
    print(cs,w,flush=True)
print('elapsed',round(monotonic()-t0,2))
