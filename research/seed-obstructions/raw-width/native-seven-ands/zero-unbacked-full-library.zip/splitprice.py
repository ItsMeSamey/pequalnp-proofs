from itertools import combinations, permutations
from nativecontrol import rows

ordinary = (1, 16, 64)
stars = {t: {p for p, a, y in rows if y == 1 and a == t} for t in range(1, 128) if any(a == t and y == 1 for _, a, y in rows)}
negative = {p | (t << 13) for p, t, y in rows if y == -1}
points = set.union(*(stars[t] for t in ordinary))
assert len(rows) == 676 and len(negative) == 468 and len(points) == 9

def dominated(x):
    return any(x & ~n == 0 for n in negative)

def extends_into(x, petals):
    return any(dominated(x | p) for p in petals)

for t, s, v in permutations(ordinary):
    T, S, V = (stars[a] for a in (t, s, v))
    assert len(T - S) == len(V - S) == 3 and not (T & S & V)
    for k, petals in ((s, S), (v, V - S)):
        for size in (1, 2):
            for subset in combinations(sorted(points | {t << 13}), size):
                m = sum(subset)
                if dominated(m):
                    assert extends_into(m, petals), (t, s, v, k, subset)
        for x in (points | {a << 13 for a in ordinary}) - {k << 13}:
            assert extends_into(x, petals), (k, x)
    for k, gone in ((s, S), (v, V)):
        for z in points - gone:
            assert extends_into((k << 13) | z, T - S), (t, s, v, k, z)
    for p in points - (T | S):
        assert dominated(((s | t) << 13) | p)
    print('original extension tests passed', t, s, v)

from exterior import arm, hot, tt, solve
from controls import verify
for t, s, v in permutations(ordinary):
    site = {t: 3, s: 6, v: 10}
    constraints = []
    for label, bit in zip(ordinary, tt):
        constraints.extend(hot(g, bit) * (1 if (site[label] >> g) & 1 else -1) for g in range(4))
        constraints.append(arm(1, 0, bit) * (1 if label == s else -1))
    witness = solve(constraints, 10000)
    assert isinstance(witness, list)
    size = verify(witness, (1, 1, 1))
    print('actual native split control', t, s, v, size, witness)
for U in stars.values():
    for optional in (129,4160):
        assert (optional & sum(U)).bit_count() < 2
