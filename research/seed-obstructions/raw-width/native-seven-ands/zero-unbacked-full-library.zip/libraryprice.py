from controls import checked_valuation
from smallrepeat_survey import *
from itertools import permutations
from functools import lru_cache
from random import Random
from nativecontrol import edges
prv=(2,4,8,32)
fullpts=(1<<13)-1
private_stars={u:sum(p for p,t in edges if t==u) for u in prv}
def convert(m):
    z=0
    for i in range(14):
        if m>>i&1:z|=atoms[i] if i<12 else 1<<(20+i-12)
    return z
def library(w):
    targets=[]
    for u,U in private_stars.items():
        lo=hi=U
        for g in (0,1):
            if any(y<0 and u&t and all(checked_valuation(w,p,t)[g]) for p,t,y in rows):continue
            hi |= 1<<(20+g)
            for j in range(13):
                p=1<<j
                if all(checked_valuation(w,p,0)[g]):lo &= ~p
        targets.append((lo,hi))
    for pair in w:
        for m in pair:
            a=convert(m)
            if a.bit_count()>1:targets.append((a,a))
    return tuple(sorted(set(targets)))
@lru_cache(maxsize=50000)
def price_cover(req, paired):
    if not req:return 0
    i=req&-req
    return 1+min(price_cover(req&~m,paired) for m in (i,*paired) if i&m)
def cheapest(req, granted):
    paired=tuple(sorted({req&g for g in granted if (req&g).bit_count()>1}))
    return max(0,price_cover(req, paired)-1)
def trial(T,order):
    granted=[129,4160];total=0
    for i in order:
        lo,hi=T[i]
        # A shared previous cone can provide an arbitrary subset of its upper set.
        # A free supplied compound can only enter an OR cone if fully within its upper set.
        total+=cheapest(lo,[x for x in (129,4160) if x&~hi==0]+granted[2:])
        granted.append(hi)
    return total
def lower(T,seed=7):
    rr=Random(seed);n=len(T);base=list(range(n))
    orders=[base,base[::-1],sorted(base,key=lambda i:T[i][0].bit_count()),sorted(base,key=lambda i:-T[i][0].bit_count())]
    for _ in range(12):
        p=base[:];rr.shuffle(p);orders.append(p)
    return max(trial(T,p) for p in orders)
if __name__=='__main__':
    from collections import Counter
    for k in ((1,3,4),(1,4,9),(1,4,10)):
        hist=Counter()
        for w in catalogue(k,1001):
            T=library(w);hist[lower(T)]+=1
        print(k,hist,flush=True)
