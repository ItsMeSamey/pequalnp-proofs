from nativecontrol import rows,edges
from itertools import combinations,product,permutations
from pysat.formula import IDPool
from pysat.solvers import Cadical195
from collections import Counter
import sys
P={p|(t<<13) for p,t in edges}
N0={p|(t<<13) for p,t,y in rows if y<0}
N={x for x in N0 if not any(x!=y and x&~y==0 for y in N0)}
private=(2,4,8,32);ordt=(1,16,64)
stars={t:sum(p for p,j in edges if j==t)for t in (*private,*ordt)}
q={t:next(p for p,j in edges if j==t and sum(bool(S&p)for S in stars.values())==1)for t in private}
points=sorted({p for p,t in edges}-set(q.values()))
def sx(t):return t<<13
def mx(xs):return {x for x in xs if not any(x!=y and x&~y==0 for y in xs)}
class Model:
  def __init__(self,h,k,variant,B,b,solver=True):
    dirty_count=5
    self.h=h;self.k=k;self.B=B;self.mode=variant
    self.extra=(8,32)[:b-2]; self.b=b
    raw=points+[sx(j) for j in (*ordt,2,4,*self.extra)]+[q[2],q[4]]
    self.raw=raw;A=sum(raw); self.A=A
    ex=tuple(i for i in range(6)if i not in (h,k));self.ex=ex
    cuts=[(h,2,k if variant=='cross' else B),(k,4,B)];self.cuts=cuts
    C=[];V=IDPool().id;self.C=C;self.V=V
    def term(g,s,x):return V(('wire',g,s,x))
    self.term=term
    def AND(y,x):C.append([y,*[-z for z in x]]);C.extend([-y,z]for z in x);return y
    def OR(y,x):C.append([-y,*x]);C.extend([y,-z]for z in x);return y
    def G(g,m):return V(('gate',g,m&A if g<6 else m))
    def arm(g,s,m):return V(('arm',g,s,m&A if g<6 else m))
    def hot(g,m):return V(('hot',g,m&A if g<6 else m))
    self.hot=hot;self.G=G;self.arm=arm
    tags=(*ordt,*private);sing=[sx(t)for t in tags];pairs=[sx(a|b)for a,b in combinations(tags,2)]
    probes=P|N|set(sing+pairs+list(q.values())+points)
    # Dirty / exterior clean form the six core sites.
    keys={}
    for g in range(6):
      for s in (0,1):
        keys[g,s]=[*raw,*[-1-i for i in range(min(dirty_count,g))]]
        for i,(d,t,back) in enumerate(cuts):
          if (g,s)!=(d,1):C.append([-term(g,s,q[t])])
          if g==d and s==0:C.append([term(g,s,sx(t))])
          if g==d and s==1:
            C.append([term(g,s,q[t])])
            C.extend([-term(g,s,x)]for x in raw if x&stars[t]==0)
      if g not in (h,k):
        prefix=None
        for x in keys[g,0]:
          a,b=term(g,0,x),term(g,1,x);prev=[] if prefix is None else [-prefix]
          C.append(prev+[-a,b]);eq=V(('eq',g,x));C.append(prev+[a,b,eq]);C.append(prev+[-a,-b,eq]);prefix=eq
    self.keys=keys
    for t in self.extra:
      center=k if variant=='cross' else B
      for i in range(6): C.append([(1 if i==center else -1)*hot(i,sx(t))])
    for g in range(6):
      for m in sorted({x&A for x in probes}):
        a=[]
        for s in (0,1):
          ls=[term(g,s,x)for x in raw if x&m]
          ls.extend(AND(V(('aux',g,s,i,m)),[term(g,s,-1-i),G(i,m)])for i in range(min(g,dirty_count)))
          a.append(OR(arm(g,s,m),ls))
        AND(G(g,m),a);OR(hot(g,m),a)
    for g,t in enumerate((8,32),6):
      for m in probes:
        a=[]
        for s in (0,1):
          ls=[]
          if (s==0 and m&sx(t)) or (s==1 and m&q[t]):
            a.append(arm(g,s,m));C.append([a[-1]]);continue
          if s==1:ls.extend(term(g,s,x)for x,j in edges if j==t and x!=q[t] and m&x)
          ls.extend(AND(V(('unbacked aux',g,s,i,m&A)),[term(g,s,-1-i),G(i,m)])for i in range(dirty_count))
          a.append(OR(arm(g,s,m),ls))
        AND(G(g,m),a);OR(hot(g,m),a)
    for g,t in enumerate((8,32),6):
      if t not in self.extra:C.extend([arm(g,1,p)] for p,j in sorted(edges) if j==t)
    for d,t,back in cuts:
      for s in (0,1):
        tag_arm=arm(back,s,sx(t))
        for n in sorted(probes): C.append([-tag_arm,-G(d,n),arm(back,1-s,n)])
        for n in sorted(N):C.append([-tag_arm,-G(d,n),-arm(back,s,n)])
        for other in (*ordt,*private):
          if other==t:continue
          for p,j in sorted(edges):
            if j==t and not stars[other]&p:C.append([-tag_arm,-arm(back,s,sx(other)),arm(d,1,p)])
    if variant=='shared':
      for s in (0,1):
        au,av=arm(B,s,sx(2)),arm(B,s,sx(4));C.extend([[-au,av],[-av,au]])
      for d,u in ((h,2),(k,4)):
        C.extend([-arm(d,0,sx(t))]for t in (*ordt,*private) if t!=u)
        C.extend([-G(d,n)]for n in N if n&sum(sx(t)for t in (2,4,*self.extra)))
    for m in N:C.extend([-G(g,m)]for g in range(dirty_count,8))
    for m in P:C.append([G(g,m)for g in range(dirty_count,8)])
    for g in range(dirty_count):C.append([G(g,m)for m in N])
    for d,t,back in cuts:
      for m in N:
        if m&sx(t):C.append([-G(d,m)])
        C.append([-G(d,m),-G(back,m)])
      C.append([G(back,q[t]|sx(t))])
      for g in range(8):
        if g!=d:C.append([-hot(g,q[t])])
        C.append([(1 if g in (d,back) else -1)*hot(g,sx(t))])
    for t in (8,32):
      for g in range(8):
        if g!=6+(t==32):C.append([-hot(g,q[t])])
    for m in sing+pairs:
      for gs in combinations(range(8),3 if m in sing else 4):C.append([-hot(g,m)for g in gs])
      if m in sing:C.extend([-G(g,m)]for g in range(8))
    # An exclusive socket per ordinary / private backed label (sole unbacked labels raw elsewhere cannot enter).
    for t in (*ordt,2,4):
      ll=[]
      for g in range(6):
        for s in (0,1):
          y=V(('exclusive',t,g,s));ll.append(y)
          C.append([-y,arm(g,s,sx(t))]);C.extend([-y,-arm(g,s,sx(z))]for z in (*ordt,2,4,*self.extra) if z!=t)
      C.append(ll)
    for j in (1,2,3):
      for ts in combinations(ordt,j):
        for gs in combinations(ex,j-1):C.append([hot(g,sx(t))for g in ex if g not in gs for t in ts])
    from selection import add as select_cuts
    select_cuts(self,tags,sx,stars,N,N0,V,arm)
    from geometry import add
    add(self,raw,N,q,stars,sx,G,term,V,OR,probes)
    self.sat=Cadical195(bootstrap_with=C) if solver else None
  def do(self,ass,n):
    self.sat.conf_budget(n);return self.sat.solve_limited(assumptions=ass)
  def witness(self):
    W=set(self.sat.get_model())
    return [[tuple(x for x in self.keys[g,s] if self.term(g,s,x)in W)for s in (0,1)]for g in range(6)]
def charts():
  for h,k in combinations(range(5),2):
    for mode in ('shared','cross'):
      for B in (5,*range(k+1,5)):
        for b in (2,3,4):yield h,k,mode,B,b
if __name__=='__main__':
 for H in charts():
    M=Model(*H);z=M.do([],4000);print(H,z,M.witness()if z else '',flush=True)
