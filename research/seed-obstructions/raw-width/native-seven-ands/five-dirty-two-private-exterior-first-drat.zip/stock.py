from physical import *
from unionprice import trial

from functools import lru_cache
from random import Random
import json
from pathlib import Path
BANKS=((129,320),(129,1028),(129,2052),(129,4160),(320,513),(320,1028),(320,2052),(513,1028),(513,2052),(513,4160),(1028,4160),(2052,4160))
free=tuple(sorted({p for pair in BANKS for p in pair}));quota=24
def bit(x):return x if x>0 else 1<<(19-x)
def stock(M):
 T=[];units={c[0] for c in M.C if len(c)==1}
 for g in range(8):
  for s in (0,1):
   if g<6:fixed=0;symbols=M.keys[g,s]
   else:
    t=(8,32)[g-6];fixed=sx(t) if s==0 else q[t]
    symbols=[-1-i for i in range(5)]
    if s==1:symbols+=sorted(p for p,j in edges if j==t and p!=q[t])
   entries=[];lo=hi=fixed
   for x in symbols:
    lit=M.term(g,s,x);a=bit(x)
    if -lit in units:continue
    hi|=a
    if lit in units:lo|=a
    else:entries.append((a,lit))
   T.append((lo,hi,entries))
 return T
def masks(T,sm):return tuple(lo|sum(a for a,l in cols if l in sm)for lo,hi,cols in T)
