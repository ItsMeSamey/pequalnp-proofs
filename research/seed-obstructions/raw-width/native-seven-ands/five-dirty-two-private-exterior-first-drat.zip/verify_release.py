"""Validate an exact selected-role certificate ledger and optionally replay individual proofs."""
from pathlib import Path
from hashlib import sha256
import argparse,gzip,json,subprocess,tempfile
from physical import charts,Model

def cnf_bytes(clauses):
 return ('p cnf %d %d\n'%(max(abs(z)for c in clauses for z in c),len(clauses))+''.join(' '.join(map(str,c))+' 0\n'for c in clauses)).encode()
def run(i,checker):
 d=Path('proof-'+str(i)+'.gz'); proof=gzip.decompress(d.read_bytes());g=Model(*list(charts())[i],solver=False);cnf=cnf_bytes(g.C)
 logs=[Path(f'case-{i}.log'),Path(f'pilot-{i}.log')]
 line='VERIFIED '+sha256(cnf).hexdigest()+' '+sha256(proof).hexdigest()
 assert any(p.exists()and line in p.read_text().splitlines() for p in logs),i
 if checker:
  with tempfile.TemporaryDirectory(dir='/dev/shm')as td:
   f=Path(td)/'formula';d=Path(td)/'proof';f.write_bytes(cnf);d.write_bytes(proof)
   s=subprocess.run([checker,str(f),str(d),'-i'],capture_output=True);assert s.returncode==0 and b's VERIFIED' in s.stdout
 print(i,list(charts())[i],line,flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('indices',type=int,nargs='*');a.add_argument('--checker');args=a.parse_args()
 idx={i for i,r in enumerate(charts())if r[0]>0}
 ready={int(p.stem.split('-')[1])for p in Path().glob('proof-*.gz')};assert ready<=idx
 if args.indices:
  for i in args.indices:assert i in ready;run(i,args.checker)
 else:print('certified',len(ready),'of',len(idx),'remaining',sorted(idx-ready))
