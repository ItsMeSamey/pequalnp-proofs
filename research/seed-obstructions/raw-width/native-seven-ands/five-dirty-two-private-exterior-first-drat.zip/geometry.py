from itertools import combinations
from functools import cache
def add(M,raw,N,q,stars,sx,G,term,V,OR,probes):
 h,k,B=M.h,M.k,M.B;center=k if M.mode=='cross' else B
 ns=sorted(N);Nfull=(1<<len(ns))-1
 masks={x:sum(1<<j for j,n in enumerate(ns)if x&n)for x in [*raw,q[8],q[32],sx(8),sx(32)]}
 # The tuple gives an optional condition for the donor, followed by all forbidden original negatives.
 for g in range(5):
  alphabet=[x for x in raw if (x not in (q[2],sx(2)) or g>=h) and (x not in (q[4],sx(4)) or g>=k) and (x not in {sx(t) for t in M.extra} or g>=center)]
  need=[]
  for d,t,b in M.cuts:
   if g==d:need.append((None,masks[sx(t)]))
  for j,t in enumerate((8,32),6):
   petals=q[t]if t in M.extra else stars[t]
   bad=sum(1<<z for z,n in enumerate(ns)if n&petals)
   need += [(term(j,0,-1-g),bad),(term(j,1,-1-g),masks[sx(t)])]
  for c,bad in need:
   good=0
   for size in range(1,g+3):
    for xs in combinations(alphabet,size):
     L=Nfull
     for x in xs:L&=masks[x]
     if L and not L&bad:good|=L
   prefix=[] if c is None else [-c]
   for i,n in enumerate(ns):
    if not good>>i&1:M.C.append(prefix+[-G(g,n)])
   if not good:M.C.append(prefix)
