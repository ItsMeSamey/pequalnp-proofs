"""Produce a checked whole-chart refutation, or materialize a real signed control."""
import argparse,gzip,json,subprocess,tempfile
from hashlib import sha256
from pathlib import Path
from pysat.solvers import Glucose4
from physical import Model,charts,ordt,sx
from stock import stock,masks
from control import build
def solve(i,limit,checker):
 chart=list(charts())[i];m=Model(*chart,solver=False)
 with Glucose4(bootstrap_with=m.C,with_proof=True) as sat:
  sat.conf_budget(limit);ans=sat.solve_limited()
  print(i,chart,len(m.C),ans,flush=True)
  if ans is None:return
  if ans:
   w=set(sat.get_model());marks=[sum(1<<g for g in range(8)if m.hot(g,sx(t))in w)for t in ordt]
   sockets=masks(stock(m),w)
   outcome=build(i,sockets,marks);Path(f'control-{i}.json').write_text(json.dumps((chart,sockets,marks,outcome)))
   print('physically checked area/full cube',outcome[:2],flush=True);return
  proof=('\n'.join(sat.get_proof())+'\n').encode()
 cnf=('p cnf %d %d\n'%(max(abs(z)for c in m.C for z in c),len(m.C))+''.join(' '.join(map(str,c))+' 0\n'for c in m.C)).encode()
 with tempfile.TemporaryDirectory(dir='/dev/shm') as root:
  p=Path(root);f=p/'input';g=p/'proof';tr=p/'trim';f.write_bytes(cnf);g.write_bytes(proof)
  ret=subprocess.run([checker,str(f),str(g),'-l',str(tr),'-C'],capture_output=True);assert ret.returncode==0 and b's VERIFIED' in ret.stdout
  proof=tr.read_bytes();g.write_bytes(proof)
  ret=subprocess.run([checker,str(f),str(g),'-i'],capture_output=True);assert ret.returncode==0 and b's VERIFIED' in ret.stdout
 Path(f'proof-{i}.gz').write_bytes(gzip.compress(proof,mtime=0));print('VERIFIED',sha256(cnf).hexdigest(),sha256(proof).hexdigest(),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('index',type=int);p.add_argument('conflicts',type=int);p.add_argument('checker');a=p.parse_args();solve(a.index,a.conflicts,a.checker)
