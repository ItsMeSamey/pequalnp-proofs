from physical import charts,Model
from boxes import stock,quota
from itertools import combinations,product
from collections import Counter
R=list(charts())
# Independent role construction: choose three dirty owners for a clean correction or four ordered dirty sites for a dirty correction.
D=range(6)
cases={(m,b,h,6)for m,b in product(('ext','hub'),(3,4)) for h in combinations(D,3)}
cases|={(m,b,z[:3],z[3])for m,b in product(('ext','hub'),(3,4)) for z in combinations(D,4)}
assert len(R)==len(cases)==140 and set(R)==cases
assert sum(h[0]>0 for _,_,h,_ in R)==60 and sum(h[0]>=2 for _,_,h,_ in R)==20
print('direct roles',len(R),'exterior-first (zero-based h0>=1)',60,'two exterior sites before first private',20)
for k in sorted({(m,b)for m,b,hs,e in R}):
 a=[(hs,e)for m,b,hs,e in R if(m,b)==k]
 print(*k,'all',len(a),'exterior-first',sum(hs[0]>0 for hs,e in a),'clean E',sum(e==6 for hs,e in a),'dirty E',sum(e<6 for hs,e in a))
# Construct one representative CNF, without a SAT instance.
chart=('hub',4,(1,3,4),5);M=Model(*chart,solver=False);T=stock(M)
assert M.solver is None and len(T)==16 and quota==25 and M.ext==(0,2,5,6)
p=next(n for n in (1,4,64))
cl={tuple(c) for c in M.C}
for g in (6,7):
 for s in (0,1):
  w=M.W(g,s,25);a=M.V(('lit',g,s,5,p));d=M.G(5,p)
  assert (a,-w,-d)in cl and (-a,w)in cl and (-a,d)in cl and (M.A(g,s,p),-a)in cl
  assert T[2*g+s][1]>>(20+5)&1
assert all((M.G(6,n),M.G(7,n))in cl for n in __import__('physical').P)
print('compiled source probe',chart,len(M.C),'clauses; D5 reaches both sockets of both clean terminals; two-output collector; quota',quota)
