import json
from prices import *
from collections import Counter
def build(w):
    raw=list(w)
    sets=[{j for j in range(24) if m&(1<<j)}for m in raw]
    gates={};n=28
    while any(len(s)>1 for s in sets):
        freq=Counter(pair for s in sets for pair in combinations(sorted(s),2))
        x,y=min(freq,key=lambda z:(-freq[z],z))
        for s in sets:
            if {x,y}<=s:s.difference_update((x,y));s.add(n)
        gates[n]='or',x,y;n+=1
    vals=[next(iter(s)) for s in sets]
    for g in range(8):gates[20+g]='and',*vals[2*g:2*g+2]
    root=24
    for i in range(25,28):gates[n]='or',root,i;root=n;n+=1
    ids={i:i for i in range(20)};ops=[]
    def visit(i):
        if i in ids:return ids[i]
        o,a,b=gates[i];a=visit(a);b=visit(b);ids[i]=20+len(ops);ops.append([o,a,b]);return ids[i]
    output=visit(root)
    return dict(gates=ops,output=output)
def validate(net):
    def run(m):
        v=[bool(m&(1<<j))for j in range(20)]
        for o,a,b in net['gates']:v.append((v[a] and v[b]) if o=='and' else (v[a] or v[b]))
        return v
    dirty=set()
    for p,t,s in rows:
        v=run(p|t<<13)
        if s:assert v[net['output']]==(s>0)
        if s<0:dirty.update(i for i,(o,a,b)in enumerate(net['gates'],20) if o=='and' and v[i])
    assert len(dirty)==4 and sum(o=='and' for o,a,b in net['gates'])==8
    neg=[]
    for t in range(128):
        p=sum(i for i in pts if all(not(v&t) or not(i&U[v]) for v in alltag))
        if run(p|t<<13)[net['output']]:neg.append(t)
    net['dirty']=sorted(dirty);net['accepted_independent_tag_masks']=neg
if __name__=='__main__':
    out=[]
    for mode,b,x,e in cases():
        key=f'{mode}-{b}-{x}-{e}';M=Model(mode,b,x,e);K=json.load(open(f'marks-{key}.json'))
        if not K:continue
        W=stock(M);C=M.C+[[M.W(g,s,20+h) for g in range(h+1,8)for s in (0,1)]for h in range(4)]
        for k in K:
            with Cadical195(bootstrap_with=C)as S:
                best=None
                for _ in range(35):
                    if not S.solve(assumptions=marks(M,k)):break
                    a=set(S.get_model());w=tuple(sum(1<<j for j,v in enumerate(z)if v in a)for z in W)
                    S.add_clause([(-v if v in a else v)for z in W for v in z])
                    g=build(w)
                    if best is None or len(g['gates'])<len(best['gates']):best=g
                if best is None:print('no-live-control',key,k,flush=True);continue
                validate(best);out.append([key,k,best]);print('control',key,k,len(best['gates']),len(best['accepted_independent_tag_masks']),flush=True)
    open('physical.json','w').write(json.dumps(out,separators=(',',':'))+'\n')
