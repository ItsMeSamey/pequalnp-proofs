from footprint import *
from unionprice import lower
from pathlib import Path
import sys
def stock(M):return [[M.W(g,s,j)for j in range(20+min(g,4))]for g in range(8)for s in (0,1)]
def encode(words,box):
    return [v*(1 if (lo>>j)&1 else -1)for z,(lo,hi)in zip(words,box)for j,v in enumerate(z)if (lo>>j)&1 or not (hi>>j)&1]
def evalbox(box):return lower(tuple(sorted(set(map(tuple,box)))))
def firstbox(M,S,words,base):
    a=set(S.get_model());w=tuple(sum(1<<j for j,v in enumerate(z)if v in a)for z in words)
    fixed={v if v in a else -v for z in words for v in z}
    for lit in sorted(fixed,key=abs):
        if lit not in fixed:continue
        S.conf_budget(1000);res=S.solve_limited(assumptions=base+[-lit])
        if res:fixed.intersection_update(S.get_model())
        elif res is None:fixed.remove(lit)
    return w,[(sum(1<<j for j,v in enumerate(z)if v in fixed),sum(1<<j for j,v in enumerate(z)if -v not in fixed))for z in words]
def refine(w,box):
    box=list(box);score=evalbox(box)
    while score<23:
        alt=[]
        for i,m in enumerate(w):
            if box[i]!=(m,m):
                z=box[:];z[i]=(m,m);alt.append((evalbox(z),(box[i][1]^box[i][0]).bit_count(),i,z))
        if not alt:break
        score,_,_,box=max(alt)
    return box,score
def go(M,k,cap):
    words=stock(M);base=marks(M,k);cover=[]
    with Cadical195(bootstrap_with=M.C)as S:
        for _ in range(cap):
            S.conf_budget(3500);ans=S.solve_limited(assumptions=base)
            if ans is not True:return ans,cover
            w,box=firstbox(M,S,words,base);box,c=refine(w,box)
            if c<23:return ('low',w,c),cover
            cover.append((box,c));S.add_clause([-v for v in encode(words,box)])
    return 'more',cover
if __name__=='__main__':
    mode,b,x,e=sys.argv[1:5];b,x,e=map(int,(b,x,e));M=Model(mode,b,x,e);key=f'{mode}-{b}-{x}-{e}';dk={}
    for k in json.load(open(f'marks-{key}.json')):
        res,L=go(M,k,int(sys.argv[5]));print('price',key,k,res if not isinstance(res,tuple)else res[:1],len(L),[r for _,r in L][:10],flush=True)
        dk[str(k)]={'res':res,'boxes':L}
    Path(f'boxes-{key}.json').write_text(json.dumps(dk,separators=(',',':'))+'\n')
