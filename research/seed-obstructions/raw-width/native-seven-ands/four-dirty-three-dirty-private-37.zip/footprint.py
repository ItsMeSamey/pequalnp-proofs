from model import *
import json
def marks(M,k):
    return [M.T(g,t<<13)*(1 if m&(1<<g)else -1) for t,m in zip(ordinary,k)for g in range(7)]
def catalogue(M):
    ks=[]
    with Cadical195(bootstrap_with=M.C)as S:
        for _ in range(400):
            S.conf_budget(15000);ans=S.solve_limited()
            if not ans:return ans,ks
            model=set(S.get_model());k=tuple(sum(1<<g for g in range(7)if M.T(g,t<<13)in model)for t in ordinary)
            S.add_clause([-a for a in marks(M,k)]);ks.append(k)
    return None,ks
if __name__=='__main__':
    for mode,b,x,e in cases():
        M=Model(mode,b,x,e);ans,K=catalogue(M)
        key=f'{mode}-{b}-{x}-{e}';open(f'marks-{key}.json','w').write(json.dumps(K)+'\n')
        print(key,ans,len(K),flush=True)
