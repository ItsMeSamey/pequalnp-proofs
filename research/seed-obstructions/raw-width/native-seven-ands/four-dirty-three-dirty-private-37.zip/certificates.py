from prices import *
from pysat.solvers import Glucose4
import gzip,tempfile,subprocess,hashlib
def certify(key,C,tool,verify):
    file=Path('proofs')/(key+'.gz');file.parent.mkdir(exist_ok=True)
    if file.exists() and not verify:return
    if verify:proof=gzip.decompress(file.read_bytes())
    else:
        with Glucose4(bootstrap_with=C,with_proof=True)as S:
            S.conf_budget(40000);ans=S.solve_limited()
            if ans is not False:print('UNRESOLVED',key,ans,flush=True);return
            proof=('\n'.join(S.get_proof())+'\n').encode()
    cnf=('p cnf %d %d\n'%(max(abs(v)for c in C for v in c),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode()
    with tempfile.TemporaryDirectory()as td:
        d=Path(td);f=d/'c';z=d/'p';trim=d/'t';f.write_bytes(cnf);z.write_bytes(proof)
        cmd=[tool,str(f),str(z),'-t','60']
        if not verify:
            out=subprocess.run(cmd+['-l',str(trim),'-C'],capture_output=True)
            assert out.returncode==0 and b's VERIFIED' in out.stdout,(key,out.stdout[-150:])
            proof=trim.read_bytes();z.write_bytes(proof)
        out=subprocess.run(cmd+['-i'],capture_output=True)
        assert out.returncode==0 and b's VERIFIED' in out.stdout,(key,out.stdout[-150:])
    if not verify:file.write_bytes(gzip.compress(proof,compresslevel=4,mtime=0))
    print('verified',key,len(C),len(proof),hashlib.sha256(cnf).hexdigest(),hashlib.sha256(proof).hexdigest(),flush=True)
def goall():
    for mode,b,x,e in cases():
        key=f'{mode}-{b}-{x}-{e}';M=Model(mode,b,x,e);words=stock(M);C=M.C[:]
        data=json.load(open(f'boxes-{key}.json'))
        for rec in data.values():
            assert rec['res']is False
            for box,c in rec['boxes']:
                assert len(box)==16 and all(not(a&~z)for a,z in box)
                assert evalbox(box)==c and c>=26
                C.append([-v for v in encode(words,box)])
        certify(key,C,sys.argv[1],'--verify-only' in sys.argv)
if __name__=='__main__':goall()
