import fcntl,os,signal,time,sys
from pathlib import Path
def run(pid):
    p=Path(f'/proc/{pid}')
    if not p.exists() or (p/'cwd').resolve()!=Path.cwd():return
    os.setpriority(os.PRIO_PROCESS,pid,15)
    with open('/workspace/scratch/pnp-native-search.lock','a')as f:
        try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return
        try:
            os.kill(pid,signal.SIGCONT)
            for _ in range(30):
                time.sleep(.2)
                if not p.exists() or (p/'cwd').resolve()!=Path.cwd():break
        finally:
            try:
                if (p/'cwd').resolve()==Path.cwd():os.kill(pid,signal.SIGSTOP)
            except (ProcessLookupError,FileNotFoundError):pass
for _ in range(int(sys.argv[1])):
    for s in sys.argv[2:]:run(int(s));time.sleep(1)
