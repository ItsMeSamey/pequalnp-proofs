from prices import *
from time import sleep
for mode,b,x,e in cases():
    key=f'{mode}-{b}-{x}-{e}';p=Path(f'marks-{key}.json')
    while not p.exists():sleep(3)
    if Path(f'boxes-{key}.json').exists():continue
    M=Model(mode,b,x,e);dk={}
    for k in json.load(open(p)):
        res,L=go(M,k,60);print('price',key,k,res if not isinstance(res,tuple)else res[:1],len(L),[r for _,r in L][:6],flush=True)
        dk[str(k)]={'res':res,'boxes':L}
    Path(f'boxes-{key}.json').write_text(json.dumps(dk,separators=(',',':'))+'\n')
