from controls import *
from itertools import permutations
D=json.load(open('physical.json'));assert len(D)==6
for key,k,g in D:
    validate(g);assert len(g['gates'])==42 and not g['accepted_independent_tag_masks']
    def hot(p,t):
        raw=p|(t<<13);values=[bool(raw&(1<<i))for i in range(20)];out={}
        for j,(o,a,b)in enumerate(g['gates'],20):
            if o=='and':out[j]=values[a],values[b]
            values.append(values[a] and values[b] if o=='and' else values[a] or values[b])
        return out
    addr=lambda p,t:{i for i,x in hot(p,t).items() if any(x)}
    allsites=set(hot(0,0));own={}
    for t in private:
        j,=addr(q[t],0);own[t]=j
        assert hot(q[t],0)[j]==hot(0,t)[j][::-1] and not all(hot(0,t)[j])
        assert len(addr(0,t))==1+(t!=32)
    assert len(set(own.values()))==4 and set(g['dirty'])&set(own.values())=={own[t]for t in private[:3]}
    for t in alltag:
        assert len(addr(0,t))<=2 and not any(all(z)for z in hot(0,t).values())
    for a,b in combinations(alltag,2):assert len(addr(0,a|b))<=3
    assert any(all(s in addr(0,t)for s,t in zip(S,ordinary))for S in permutations(allsites-set(own.values()),3))
    print('control',key,'raw gates',len(g['gates']))
assert sum('verified ' in s for s in open('cert.log'))==20
boxes=0
for mode,b,x,e in cases():
    H=json.load(open(f'boxes-{mode}-{b}-{x}-{e}.json'));assert b!=4 or not H
    for r in H.values():
        for T,c in r['boxes']:
            assert c==evalbox(T) and c>=26;boxes+=1
assert boxes==13
print('verified box prices',boxes,'complete charts',20)
