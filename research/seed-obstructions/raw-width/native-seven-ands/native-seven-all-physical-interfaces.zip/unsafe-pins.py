from clean_groups import E,N
from collections import Counter
from itertools import combinations_with_replacement
def floor(q):
 edges=[p|t<<13 for p,t in E];forced=0
 for e in edges:
  if e&q:forced|=e&~q
 edges=[e for e in edges if not e&(q|forced)]
 live=0;stars=[0]*13
 for e in edges:live|=e;stars[(e&8191).bit_length()-1]|=e>>13
 T=live>>13;M=[]
 for t in range(128):
  if t&~T:continue
  p=sum(1<<i for i,s in enumerate(stars) if s and not s&t)
  if all(any(p>>i&1 and s>>j&1 for i,s in enumerate(stars)) for j in range(7) if (T&~t)>>j&1):M.append(p|t<<13)
 classes=set()
 for n in {n&live for n in N if n&q==q}:
  A=[m for m in M if not n&~m]
  if len(A)==1:classes.add(A[0])
 return len(edges),live.bit_count(),len(classes)
res={}
for a,b in combinations_with_replacement(range(20),2):
 q=(1<<a)|(1<<b)
 if any(n&q==q for n in N):res[a,b]=floor(q)
print(Counter((v[2]-1).bit_length() for v in res.values()))
for k,v in res.items():print(*k,*v)
