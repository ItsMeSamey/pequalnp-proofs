from itertools import combinations
from functools import lru_cache
from pathlib import Path
import sys
R=[tuple(map(int,s.split())) for s in Path('native.in').read_text().splitlines()]
E=R[1:29];N=[p|(t<<13) for p,t in R[29:]]
full=(1<<len(N))-1
cols=[sum(1<<i for i,n in enumerate(N) if n>>j&1) for j in range(20)]
def possible(m,k):
    ne=[E[i] for i in range(28) if m>>i&1]
    covers={0}
    for p,t in ne:
        edge=p|(t<<13)
        candidates={a for a in covers if a&edge}
        for a in covers:
            if not(a&edge): candidates.update((a|p,a|(t<<13)))
        covers={a for a in candidates if not any(b!=a and b&a==b for b in candidates)}
    ds=[]
    for c in covers:
        d=full
        while c:
            l=c&-c;d&=~cols[l.bit_length()-1];c^=l
        ds.append(d)
    def solve(r,k):
        if not r:return True
        if k==1:return any(r&~d==0 for d in ds)
        b=r&-r
        return any(solve(r&~d,k-1) for d in ds if d&b)
    return solve(full,k)
if __name__=='__main__':
 k,n=map(int,sys.argv[1:3]);base=Path(f'cnf{k}.{n-1}')
 old=set(map(int,base.read_text().split()));accepted=[]
 for m in sorted(old):
    for j in range(m.bit_length(),28):
        a=m|1<<j
        if all(a^(1<<i) in old for i in range(j) if m>>i&1) and possible(a,k):accepted.append(a)
 Path(f'cnf{k}.{n}').write_text(''.join(f'{a}\n' for a in accepted))
 print(n,len(accepted))
