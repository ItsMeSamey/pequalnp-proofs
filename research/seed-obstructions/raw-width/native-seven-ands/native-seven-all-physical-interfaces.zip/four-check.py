from pathlib import Path
from itertools import product
from clean_groups import E,N
f={tuple(map(int,l.split()[:2])):int(l.split()[4]) for l in Path('unsafe-pins.log').read_text().splitlines() if len(l.split())==5 and l[0].isdigit()}
Q=[1,3,4,5];T=[18,14,15,16]
for i in range(4):
 assert f[Q[i],Q[i]]==45
 assert [t for p,t in E if p==1<<Q[i]]==[1<<(T[i]-13)]
 for j in range(4):
  if i!=j:assert f[Q[j],T[i]]==17
for modes in product(range(3),repeat=4):
 m=sum((0,1<<q,1<<t)[v] for v,q,t in zip(modes,Q,T))
 assert any(not (m&~n) for n in N)
print('4 singleton floors, 12 cross floors, 81 private negatives')
