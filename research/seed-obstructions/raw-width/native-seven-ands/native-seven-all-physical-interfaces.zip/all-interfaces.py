from pathlib import Path
from clean_groups import E,N
from itertools import combinations
F={tuple(map(int,l.split()[:2])):int(l.split()[4]) for l in Path('unsafe-pins.log').read_text().splitlines() if len(l.split())==5 and l[0].isdigit()}
P=[{p.bit_length()-1 for p,t in E if t==1<<j} for j in range(7)]
for t,s in enumerate(P):
 o=[q for q in (1,3,4,5) if q not in s]
 assert len(o)>=3 and all(F[q,13+t]>=17 for q in o)
 print(t,sorted(s),[(q,F[q,13+t]) for q in o])
for t,v in combinations(range(7),2):
 assert P[t]-P[v] and P[v]-P[t]
 for p in P[t]-P[v]:
  for r in P[v]-P[t]:
   assert any(n&1<<p and n&1<<r for n in N)
for p in range(13):
 tags=[t for t,s in enumerate(P) if p in s]
 assert (F[p,p]-1).bit_length()==7-len(tags)
 print(p,tags,F[p,p])
