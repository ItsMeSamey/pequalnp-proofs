from itertools import combinations,permutations
import json
from pathlib import Path
from nativecontrol import rows
obj=json.loads(Path(__file__).with_name('physical-best.json').read_text())
ops=obj['gates']; output=obj['output']; sites=[i for i,(op,a,b) in enumerate(ops,20) if op=='and']
assert len(ops)==40 and len(sites)==8
def evalrow(p,t):
    m=p|(t<<13);val=[bool(m&(1<<i)) for i in range(20)];marks={};high=set()
    for i,(op,a,b) in enumerate(ops,20):
        assert a<i and b<i and op in ('or','and')
        if op=='and':
            marks[i]=(val[a],val[b]);val.append(val[a] and val[b])
            if val[-1]:high.add(i)
        else:val.append(val[a] or val[b])
    return val[output],{g for g,z in marks.items() if any(z)},high
D=set()
for p,t,y in rows:
    v,_,h=evalrow(p,t)
    if y:assert v==(y>0)
    if y<0:D|=h
assert len(D)==3
private={2:32,8:2,16:4,32:8}; ordinary=(1,16,64)
J=set()
for q,u in private.items():
    O,A,H=evalrow(q,0)
    assert not O and not H and len(A)==1
    assert A==evalrow(0,u)[1] and not (A&D);J|=A
assert len(J)==4
alltags=tuple(private.values())+ordinary
for t in alltags:
    _,marks,h=evalrow(0,t);assert not h and len(marks)<=2
for t,v in combinations(alltags,2):assert len(evalrow(0,t|v)[1])<=3
assert any(all(g in evalrow(0,t)[1] for g,t in zip(gs,ordinary)) for gs in permutations(set(sites)-J,3))
print('40 gates, eight ANDs, 3 dirty, 5 clean, 676 native rows, all required singleton and pair marks verified.')
