from ast import literal_eval
from collections import Counter
from itertools import permutations,product
from survey import *
from unionprice import lower
from nativecontrol import edges
private=(2,4,8,32)
U={t:sum(p for p,a in edges if a==t) for t in private}
def conv(m):
    return sum(atoms[j] if j<12 else 1<<(20+j-12) for j in range(15) if (m>>j)&1)
def evaluate(w,p,t):
    m=pack(p,t);out=[]
    for j,(a,b) in enumerate(w):
        out.append(bool(a&m) and bool(b&m))
        if out[-1]:m|=1<<(12+j)
    return out
def library(w):
    dom=sorted({(p,t) for p,t,s in rows if s<0})
    unsafe=[0,0,0]
    for p,t in dom:
        scores=evaluate(w,p,t)
        for g in range(3):
            if scores[g]:unsafe[g]|=t
    M=[sum(1<<i for i in range(13) if evaluate(w,1<<i,0)[g]) for g in range(3)]
    targets=[]
    for t,u in U.items():
        lo=hi=u
        for g in range(3):
            if unsafe[g]&t:continue
            lo &= ~M[g];hi|=1<<(20+g)
        targets.append((lo,hi))
    for pair in w:
        for m in pair:
            x=conv(m)
            if x.bit_count()>1:targets.append((x,x))
    return tuple(sorted(set(targets)))
def run():
    data={}
    for line in open('footprints.log'):
        if not line.startswith('('):continue
        k,val=line.split(') ',1);key=literal_eval(k+')')
        assert key not in data
        data[key]=literal_eval(val)
    opts=[x for x in range(1,16) if x.bit_count()<=2]
    expected={c for c in product(opts,repeat=3) if all((a|b).bit_count()<=3 for a,b in combinations(c,2)) and any(all(c[i]&(1<<j) for i,j in enumerate(p)) for p in permutations(range(4),3))}
    assert set(data)==expected and None not in data.values()
    total=0;costs=Counter()
    for k,w0 in data.items():
        if w0 is False:continue
        n=0;C=Counter()
        for w in catalogue(k,1000):
            n+=1
            if n==1:
                for p,t,s in rows:
                    f=evaluate(w,p,t)[3] or any(t&a and p&u for a,u in U.items())
                    if s:assert bool(f)==(s>0)
            T=library(w);c=lower(T);C[c]+=1
            assert c>=28, (k,w,c)
        print(k,n,dict(sorted(C.items())),flush=True)
        assert 0<n<1000
        total+=n;costs+=C
    assert total==2826
    print('total',total,dict(sorted(costs.items())),flush=True)
if __name__=='__main__':run()
