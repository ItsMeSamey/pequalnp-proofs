from exterior import *
from pysat.solvers import Cadical195
def catalogue(k, cap):
    readings=[(1 if m>>g&1 else -1)*hot(g,n) for n,m in zip(tt,k) for g in range(4)]
    fixed=[term(g,s,j) for g in range(4) for s in range(2) for j in range(12+min(g,3))]
    with Cadical195(bootstrap_with=C) as S:
        for g in range(4):
            old=None
            for i in range(12+min(g,3)):
                a,b=term(g,0,i),term(g,1,i)
                pre=[-old] if old is not None else []
                S.add_clause(pre+[-a,b])
                old=V('sg',g,i)
                S.add_clause(pre+[a,b,old]); S.add_clause(pre+[-a,-b,old])
        for n in range(cap):
            if not S.solve(assumptions=readings):return
            r=S.get_model();yield model(r)
            A=set(r);S.add_clause([(-v if v in A else v) for v in fixed])
if __name__=='__main__':
    for k in ((1,3,4),(1,4,9),(1,4,10)):
        print(k,sum(1 for w in catalogue(k,3001)),flush=True)
