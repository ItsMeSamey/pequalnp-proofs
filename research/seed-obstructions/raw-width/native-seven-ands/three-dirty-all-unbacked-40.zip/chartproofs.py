from ast import literal_eval
from itertools import combinations,permutations
from pathlib import Path
from pysat.solvers import Cadical195
from exterior import C,tt,V,term,hot,model
from survey import catalogue
from proofcheck import check
import sys
def go():
    data={}
    for line in open('footprints.log'):
        if line.startswith('('):
            x,y=line.split(') ',1);data[literal_eval(x+')')]=literal_eval(y)
    sats=[k for k,v in data.items() if isinstance(v,list)]
    # Add Hall on the three named tag footprint sets; other size caps follow
    # from single-tag and pair-hot physical clauses already in the base.
    guard=[]
    for r in (1,2,3):
        for subset in combinations(tt,r):
            for tiny in combinations(range(4),r-1):
                guard.append([hot(g,n) for g in range(4) if g not in tiny for n in subset])
    def given(k):
        return [hot(g,n)*(1 if m&(1<<g) else -1) for n,m in zip(tt,k) for g in range(4)]
    leftover=C+guard+[[-lit for lit in given(k)] for k in sats]
    check('chart','all-missing',leftover)
    order=[]
    for g in range(4):
        prev=[]
        for j in range(12+min(g,3)):
            a,b=term(g,0,j),term(g,1,j)
            order.append(prev+[-a,b]);c=V('sg',g,j)
            order.extend((prev+[a,b,c],prev+[-a,-b,c]));prev=[-c]
    for k in sats:
        blocked=[]
        for w in catalogue(k,1000):
            blocked.append([term(g,s,j)*(-1 if m&(1<<j) else 1) for g,ops in enumerate(w) for s,m in enumerate(ops) for j in range(12+min(g,3))])
        check('layout','-'.join(map(str,k)),C+order+[[x] for x in given(k)]+blocked)
if __name__=='__main__':go()
