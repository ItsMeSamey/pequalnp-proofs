from pathlib import Path
from nativecontrol import rows
from pysat.formula import IDPool
from pysat.solvers import Cadical195
from itertools import combinations
points=[1,4,64,128,256,512,1024,2048,4096];tags=[1,16,64]
atoms=points+[t<<13 for t in tags]
def pack(p,t):
    return sum(1<<i for i,z in enumerate(atoms) if z&(p|(t<<13)))
P={pack(p,t) for p,t,s in rows if s==1 and t in tags}
N0={pack(p,t) for p,t,s in rows if s==-1}
N={n for n in N0 if not any(n!=m and n&~m==0 for m in N0)}
assert len(P)==12 and len(N)==56
I=IDPool().id
def V(*a):return I(tuple(a))
C=[]
def ae(o,ii):
    C.append([o,*[-i for i in ii]]);C.extend([-o,i] for i in ii)
def oe(o,ii):
    C.append([-o,*ii]);C.extend([o,-i] for i in ii)
def unit(x):C.append([x])
tt=[1<<(9+i) for i in range(3)]
probes=sorted(P|N|{1<<i for i in range(12)}|set(a|b for a,b in combinations(tt,2)))
def sig(g,n):return V('gate',g,n)
def arm(g,s,n):return V('arm',g,s,n)
def term(g,s,i):return V('wire',g,s,i)
def hot(g,n):return V('hot',g,n)
for n in probes:
    for g in range(4):
        slots=[]
        for s in range(2):
            yy=[term(g,s,j) for j in range(12) if n>>j&1]
            for j in range(min(g,3)):
                w=V('lit',g,s,j,n);ae(w,[term(g,s,12+j),sig(j,n)]);yy.append(w)
            out=arm(g,s,n);oe(out,yy);slots.append(out)
        ae(sig(g,n),slots);oe(hot(g,n),slots)
    if n in P:unit(sig(3,n))
    if n in N:
        unit(-sig(3,n))
for g in range(3):C.append([sig(g,n) for n in sorted(N)])
for n in tt:
    for g in range(4):unit(-sig(g,n))
    for gg in combinations(range(4),3):C.append([-hot(g,n) for g in gg])
for a,b in combinations(tt,2):C.append([-hot(g,a|b) for g in range(4)])
solver=Cadical195(bootstrap_with=C)
def model(assign):
    M=set(assign)
    return [[sum((1<<i) for i in range(12+min(g,3)) if term(g,s,i) in M) for s in range(2)]for g in range(4)]
def solve(ass=(),budget=5000):
    solver.conf_budget(budget)
    x=solver.solve_limited(assumptions=list(ass))
    return model(solver.get_model()) if x else x
if __name__=='__main__':
    print('clauses',len(C),'general budgeted sample:',solve(),flush=True)
