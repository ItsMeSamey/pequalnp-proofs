import json
from ast import literal_eval
from collections import Counter
from itertools import combinations
from price3 import *
def physical(w):
    target=[{p.bit_length()-1 for p in (1<<i for i in range(13)) if p&U[t]} for t in private]
    for pair in w:
        for m in pair:
            T=conv(m);target.append({j for j in range(23) if (T>>j)&1})
    # Priority IDs 20..22 for the dirty helper outputs, 23 for the clean exterior.
    gates={};free=24
    while any(len(t)>1 for t in target):
        cnt=Counter(pair for t in target for pair in combinations(sorted(t),2))
        a,b=min(cnt,key=lambda z:(-cnt[z],z));gates[free]='or',a,b
        for t in target:
            if {a,b}<=t:t.difference_update((a,b));t.add(free)
        free+=1
    tt=[next(iter(t))for t in target]
    for g in range(4):gates[20+g]='and',tt[4+2*g],tt[5+2*g]
    end=23
    for j,t in enumerate(private):
        gates[free]='and',tt[j],13+t.bit_length()-1
        gates[free+1]='or',end,free;end=free+1;free+=2
    stable={i:i for i in range(20)};ops=[]
    def topo(n):
        if n in stable:return stable[n]
        op,x,y=gates[n];a,b=topo(x),topo(y)
        stable[n]=20+len(ops);ops.append([op,a,b]);return stable[n]
    last=topo(end)
    return ops,last
def run():
    best=1000
    for line in open('footprints.log'):
        if '[[' not in line:continue
        k=literal_eval(line.split(') ')[0]+')')
        for w in catalogue(k,1000):
            ops,out=physical(w)
            if len(ops)<best:
                best=len(ops);print('improved',best,k,w,flush=True)
                D=set()
                for p,t,y in rows:
                    m=p|t<<13;vals=[bool(m&(1<<j))for j in range(20)]
                    for j,(op,a,b) in enumerate(ops,20):
                        v=(vals[a] and vals[b]) if op=='and' else (vals[a] or vals[b])
                        vals.append(v)
                        if v and y<0 and op=='and':D.add(j)
                    if y:assert vals[out]==(y>0)
                assert len(D)==3 and sum(op=='and' for op,_,_ in ops)==8
                open('physical-best.json','w').write(json.dumps({'input_order':'13 point bits then 7 tag bits','output':out,'gates':ops,'dirty':sorted(D)},indent=2)+'\n')
    print('best',best,flush=True)
if __name__=='__main__':run()
