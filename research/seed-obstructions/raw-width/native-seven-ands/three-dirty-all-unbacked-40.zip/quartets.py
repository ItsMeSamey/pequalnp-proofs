from itertools import combinations
from nativecontrol import rows,edges
from pysat.formula import IDPool
from pysat.solvers import Cadical195
private=(2,4,8,32);tags=(1,16,64)
stars={t:{p for p,v in edges if v==t} for _,t in edges}
q={u:next(p for p in stars[u] if sum(p in S for S in stars.values())==1) for u in private}
raw=sorted(set.union(*stars.values())-set(q.values()))+[t<<13 for t in tags]
N0={p|(t<<13) for p,t,y in rows if y<0}
def dominated(m):return any(m&~n==0 for n in N0)
def escapes(m,U):return all(not dominated(m|p) for p in U)
by={u:{sum(z) for s in range(1,5) for z in combinations(raw,s) if dominated(sum(z)) and escapes(sum(z),stars[u])} for u in private}
assert all(len(b)==6 and all(m<8192 and m.bit_count()==4 for m in b) for b in by.values())
assert all(not(by[u]&by[v]) for u,v in combinations(private,2))
def test(u):
    orig=raw+[q[u],u<<13];nraw=len(orig)
    def pack(p,t):return sum(1<<j for j,x in enumerate(orig) if x&(p|(t<<13)))
    POS={pack(p,t) for p,t in edges if t in tags or t==u}
    neg={pack(p,t) for p,t,y in rows if y<0}
    NEG={m for m in neg if not any(m!=n and m&~n==0 for n in neg)}
    tagbits=[pack(0,t) for t in tags]
    quartets=[pack(m,0) for m in sorted(by[u])]
    rows0=sorted(POS|NEG|set(quartets)|{1<<j for j in range(nraw)}|{a|b for a,b in combinations(tagbits,2)})
    id=IDPool().id;V=lambda *args:id(args)
    C=[]
    def OR(o,z):C.append([-o]+z);C.extend([o,-a] for a in z)
    def AND(o,z):C.append([o]+[-a for a in z]);C.extend([-o,a] for a in z)
    for g in range(5):
        for s in (0,1):
            for i,x in enumerate(orig):
                if g<4:
                    if i<12:continue
                    ok=False
                elif s==0:
                    ok=x==(u<<13)
                elif x in stars[u]:
                    if x!=q[u]:continue
                    ok=True
                else:ok=False
                C.append([(1 if ok else -1)*V('term',g,s,i)])
    C.extend([-V('term',4,0,nraw+h)] for h in (0,1))
    for n in rows0:
        for g in range(5):
            for s in (0,1):
                ls=[V('term',g,s,j) for j in range(nraw) if (n>>j)&1]
                for h in range(min(3,g)):
                    y=V('c',g,s,h,n);AND(y,[V('term',g,s,nraw+h),V('gate',h,n)]);ls.append(y)
                OR(V('arm',g,s,n),ls)
            arms=[V('arm',g,s,n) for s in (0,1)]
            OR(V('hot',g,n),arms);AND(V('gate',g,n),arms)
        if n in POS:C.append([V('gate',g,n) for g in (3,4)])
        if n in NEG:C.extend([-V('gate',g,n)] for g in (3,4))
    for g in range(3):C.append([V('gate',g,n) for n in NEG])
    for n in tagbits:
        for g in range(5):C.append([-V('gate',g,n)])
        for gg in combinations(range(5),3):C.append([-V('hot',g,n) for g in gg])
    for a,b in combinations(tagbits,2):
        for gg in combinations(range(5),4):C.append([-V('hot',g,a|b) for g in gg])
    for p in stars[u]:C.append([V('arm',4,1,pack(p,0))])
    with Cadical195(bootstrap_with=C) as S:
        for n in quartets:
            S.conf_budget(10000)
            status=S.solve_limited(assumptions=[V('term',4,0,nraw+2), V('gate',2,n)])
            print('mandatory quartet',u,n,status,flush=True)
if __name__=='__main__':
    for u in private:test(u)
