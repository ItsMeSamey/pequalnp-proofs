from collections import Counter
from contextlib import redirect_stdout
from itertools import combinations
import io

with redirect_stdout(io.StringIO()):
    import chart_inputs as original
edges = set(original.pos)
neg = set(original.neg)
points = sorted({p for p, _ in edges})
assert len(edges) == 28 and len(points) == 13

def certificate(pins):
    fixed = sum(pins)
    neighbors = {t for p, t in edges if p & fixed}
    retained = [(p, t) for p, t in edges if t not in neighbors]
    tags = sorted({t for _, t in retained})
    target = sum(tags)
    exact = set()
    for active_points, active_tags in neg:
        if fixed & ~active_points:
            continue
        forbidden = active_tags & target
        required = 0
        for p, t in retained:
            if p & active_points:
                required |= t
        if required == target ^ forbidden:
            exact.add(required)
    return tags, exact

for p in points:
    tags, exact = certificate([p])
    m = len(tags)
    excludes = min(sum(not (r & t) for r in exact) for t in tags)
    assert excludes > (1 << (m - 2))
    assert all({r & (t | s) for r in exact} == {0, t, s, t | s}
               for t, s in combinations(tags, 2))
    assert all(any((n & (p | q)) == (p | q) for n, _ in neg)
               for q in points if p != q)
    assert all(any(n & p and z & t for n, z in neg) for t in tags)
    print('point', p, 'remaining tags', m, 'exact profiles', len(exact),
          'minimum excluding one tag', excludes)
counts = Counter()
for p, q in combinations(points, 2):
    tags, exact = certificate([p, q])
    assert (len(exact) - 1).bit_length() == len(tags)
    counts[len(tags), len(exact)] += 1
print('two-point face counts by (tags, profiles)', sorted(counts.items()))
