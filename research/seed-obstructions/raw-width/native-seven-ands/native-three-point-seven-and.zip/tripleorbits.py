from exactnear import *
from itertools import permutations,combinations
from collections import Counter
def autos():
    P=set(a.pos);N=set(a.neg); star2p={v:p for p,v in a.stars.items()}
    for order in permutations([1<<i for i in range(7)]):
        mapped=[sum(y for j,y in enumerate(order) if x>>j&1) for x in range(128)]
        mp={p:star2p.get(mapped[v]) for p,v in a.stars.items()}
        if None in mp.values():continue
        def ps(x):return sum(y for p,y in mp.items() if p&x)
        if {(ps(p),mapped[t])for p,t in N}==N:yield mp
if __name__=='__main__':
    aut=list(autos());print('group',len(aut))
    orbit=Counter(min(sum(f[p] for p in v) for f in aut) for v in combinations(a.stars,3))
    print('orbits',len(orbit),[(k,n,len(classes(8191^k))) for k,n in orbit.items()])
