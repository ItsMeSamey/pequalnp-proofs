"""Earliest physical AND and branch-local selector capacity."""
from near import classes
from itertools import combinations
from functools import lru_cache

def pairs(G, raw, k, cap=10000):
    """G records nonempty groups of projected native rows, unique positive-independent maximal containers."""
    m=len(G); half=1<<(k-1); need=m-half; d=2*half-m
    assert need>0 and d>=0
    full=(1<<m)-1
    bygroup=[list(x) for x in G]
    col={}
    for i in raw:
        possible=sum(1<<j for j,rs in enumerate(bygroup) if any(r>>i&1 for r in rs))
        col[i]=possible
    states=[]
    def extend(at,mask,p):
        if (full^p).bit_count()<need:return
        if p.bit_count()>=need:
            h=sum(1<<j for j,rs in enumerate(bygroup) if p>>j&1 and all(r&mask for r in rs))
            if h.bit_count()>=need:
                states.append((mask,h,full^p))
        for n in range(at,len(raw)):
            i=raw[n]
            extend(n+1,mask|1<<i,p|col[i])
    extend(0,0,0)
    for (a,h,z),(b,h2,z2) in combinations(states,2):
        left=h&z2;right=z&h2
        if min(left.bit_count(),right.bit_count())>=need and m-(left|right).bit_count()<=d:
            yield a,b

def branch(G,a,b):
    return tuple(t for rs in G if (t:=tuple(r for r in rs if not (r&a) or r&b)))

def exclude(K,extra=1):
    G=tuple(tuple(sorted(g)) for g in classes(K))
    raw=[i for i in range(20) if (K|127<<13)>>i&1]
    counts=[0]*(extra+1)
    @lru_cache(None)
    def test(G,k,depth):
        if len(G)>1<<k:return True
        if k==0 or len(G)<=1<<(k-1):return False
        for a,b in pairs(G,raw,k):
            counts[depth]+=1
            if not depth:return False
            X,Y=sorted((branch(G,a,b),branch(G,b,a)),key=len,reverse=True)
            if not test(X,k-1,depth-1) and not test(Y,k-1,depth-1):return False
        return True
    return test(G,6,extra),counts
if __name__=='__main__':
    import sys
    for v in map(int,sys.argv[1:]):
        print(v,exclude(8191^v),flush=True)
