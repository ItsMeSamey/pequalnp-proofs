from near import classes
from hits import a
from itertools import combinations

def signatures(K):
    G=classes(K);m=len(G);d=64-m;need=32-2*d
    FULL=(1<<m)-1;W=[sum(1<<i for i,g in enumerate(G) if any(r>>v&1 for r in g)) for v in range(20)]
    raw=[v for v in range(20)if (K|127<<13)>>v&1]
    rows=[list(g) for g in G]
    states=set()
    def extend(at,mask,present):
        if (FULL^present).bit_count()<need: return
        if present.bit_count()>=need:
            high=sum(1<<i for i,rs in enumerate(rows) if present>>i&1 and all(r&mask for r in rs))
            if (present^high).bit_count()<=d and high.bit_count()>=need:
                states.add((high,FULL^present))
        for n in range(at,len(raw)):
            v=raw[n];extend(n+1,mask|1<<v,present|W[v])
    extend(0,0,0)
    cand=set()
    for (h,z),(h2,z2) in combinations(states,2):
        left=h&z2;right=z&h2
        if min(left.bit_count(),right.bit_count())>=need and m-(left|right).bit_count()<=d:
            cand.add(tuple(sorted((left,right))))
    return m,sorted(cand)
def combine(m,cand,limit=200000):
    d=64-m;F=(1<<m)-1
    calls=0
    def walk(at,blocks,dep):
        nonlocal calls
        calls+=1
        if calls>limit:raise TimeoutError
        if dep==6:return True
        cap=1<<(5-dep)
        for j in range(at,len(cand)-(5-dep)):
            h,z=cand[j]
            branches=[g&v for g in blocks for v in (h,z) if g&v]
            if sum(min(cap,b.bit_count()) for b in branches)<m-d:continue
            if walk(j+1,branches,dep+1):return True
        return False
    try:res=walk(0,[F],0)
    except TimeoutError:res=None
    return res,calls
if __name__=='__main__':
 for x,y in [(1,2),(1,4),(2,8),(128,256),(1,128)]:
    m,cand=signatures(8191^x^y);print(x,y,m,len(cand),combine(m,cand),flush=True)
