from earliest import exclude
from tripleorbits import autos, a
from near import classes
from itertools import combinations

def main():
    permutations=list(autos())
    assert len(permutations)==24
    triples={sum(p) for p in combinations(a.stars,3)}
    assert len(triples)==286
    seen=set()
    for deletion in sorted(triples):
        if deletion in seen:continue
        orbit={sum(y for p,y in perm.items() if deletion&p) for perm in permutations}
        assert deletion==min(orbit) and not orbit&seen
        seen.update(orbit)
        result,_=exclude(8191^deletion,5)
        print(deletion,len(orbit),len(classes(8191^deletion)),result)
        assert result
    assert seen==triples
    # Deleting a full column gives a genuine six-product satisfiable control.
    for u in (1<<j for j in range(7)):
        deletion=sum(p for p,t in a.pos if t==u)
        assert deletion.bit_count()==4
        assert all(not any((p&~deletion)&x and t&v for x,v in a.pos if v!=u) for p,t in a.neg)
        assert not exclude(8191^deletion,1)[0]
    print('286 triple deletions excluded; 7 native six-AND controls retained')
if __name__=='__main__':main()
