from hits import a
import itertools
def classes(K, U=127):
    M=[]
    for t in range(128):
        if t&~U:continue
        p=K&~sum({x for x,y in a.pos if y&t})
        if t==U&~sum({y for x,y in a.pos if x&p}):M.append(p|t<<13)
    groups={}
    for p,t in a.neg:
        r=(p&K)|(t&U)<<13
        cand=[m for m in M if not r&~m]
        if len(cand)==1:groups.setdefault(cand[0],set()).add(r)
    return list(groups.values())
def test(K):
 G=classes(K);delta=64-len(G);raw=[1<<i for i in range(20) if (1<<i)&(K|127<<13)]
 co={v:sum(w for w in raw if sum(any((r&(v|w))==v|w for r in group) for group in G)<=delta) for v in raw}
 same=[(v,w) for v in raw for w in raw if co[v]&w and bool(v&8191)==bool(w&8191)]
 c4=[(v,w) for v,w in itertools.combinations([x for x in raw if x&K],2) if ((co[v]&co[w])>>13).bit_count()>=2]
 ok=[]
 for v in raw:
    possible0=possible1=bad=0
    for group in G:
        b=all(r&v for r in group)
        c=all(not r&v and r&co[v] for r in group)
        possible1+=b;possible0+=c;bad+=not(b or c)
    if min(possible1,possible0)>=32-2*delta and bad<=delta:ok.append(v)
 return len(G),len(same),len(c4),ok
if __name__=='__main__':
 for c in [129,4160,1,2,4,8,16,32,64,128]:
    print(c,test(8191&~c))
