from model import *
from itertools import product,permutations
import sys,json
def domain(M):
    k=M.k;mode=M.mode
    owned=[(1<<(j if j<3 else 7))|(1<<(3 if mode=='ext' or j==2 else 2)) for j in range(k)]
    opts=[m for m in range(1,128) if m&120 and m.bit_count()<=2 and all((m|o).bit_count()<=3 for o in owned)]
    for a in product(opts,repeat=3):
        if any((x|y).bit_count()>3 for x,y in combinations(a,2)):continue
        if not any(all(x&(1<<g)for x,g in zip(a,p))for p in permutations(range(3,7),3)):continue
        G=lambda g:tuple(1 if x&(1<<g)else 0 for x in a)
        if not G(4)<=G(5)<=G(6):continue
        yield a
def marks(M,k):
    return [M.T(g,t<<13)*(1 if m&(1<<g) else -1)for m,t in zip(k,ordinary) for g in range(7)]
if __name__=='__main__':
    mode=sys.argv[1];bk=int(sys.argv[2]);M=Model(mode,bk);todo=list(domain(M));good=[];no=0
    print('count',len(todo),flush=True)
    with Cadical195(bootstrap_with=M.C)as S:
        for budget in (500,3000,10000):
            rem=[]
            for k in todo:
                S.conf_budget(budget);ans=S.solve_limited(assumptions=marks(M,k))
                if ans is None:rem.append(k)
                elif ans:good.append(k)
                else:no+=1
            todo=rem
    print('partition',len(good),no,len(todo),flush=True)
    open(f'marks-{mode}-{bk}.json','w').write(json.dumps({'live':good,'unknown':todo})+'\n')
