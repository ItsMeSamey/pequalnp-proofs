from footprint import *
from unionprice import lower
from collections import Counter
def expressions(M,mark):
    terms=[[[M.W(g,s,j)for j in range(20+min(g,3))] for s in range(2)]for g in range(8)]
    with Cadical195(bootstrap_with=M.C)as S:
        while S.solve(assumptions=marks(M,mark)):
            a=set(S.get_model())
            yield tuple(sum(1<<j for j,v in enumerate(ws) if v in a) for gs in terms for ws in gs)
            S.add_clause([v*(-1 if v in a else 1)for gs in terms for ws in gs for v in ws])
if __name__=='__main__':
    mode=sys.argv[1];bk=int(sys.argv[2]);M=Model(mode,bk)
    K=json.load(open(f'marks-{mode}-{bk}.json'))
    for mark in K['live']:
        c=Counter()
        for i,w in enumerate(expressions(M,mark),1):
            T=tuple(sorted({(x,x)for x in w if x.bit_count()>1}))
            v=lower(T);c[v]+=1
            if i==1:print('witness',mark,v,w,flush=True)
            if i>=int(sys.argv[3]):break
        print('price',mark,i,sorted(c.items()),flush=True)
