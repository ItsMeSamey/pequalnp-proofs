from itertools import combinations
from nativecontrol import edges,rows
from pysat.formula import IDPool
from pysat.solvers import Cadical195
private=(2,4,8,32);ordinary=(1,16,64);alltag=private+ordinary
U={t:sum(p for p,s in edges if s==t) for t in alltag}
pts=[1<<j for j in range(13)]
q={t:next(p for p in pts if p&U[t] and sum(bool(p&m)for m in U.values())==1)for t in private}
N={p|t<<13 for p,t,y in rows if y<0}
mx=lambda S:{m for m in S if not any(m!=a and m&~a==0 for a in S)}
class Model:
    def __init__(self,mode,k):
        self.mode=mode;self.k=k;self.C=C=[]; self.V=IDPool().id;V=lambda *x:self.V(x)
        def OR(o,ys):
            C.append([-o,*ys]);C.extend([o,-y]for y in ys);return o
        def AND(o,ys):
            C.append([o,*[-y for y in ys]]);C.extend([-o,y]for y in ys);return o
        W=self.W=lambda g,s,i:V('wire',g,s,i)
        G=self.G=lambda g,n:V('G',g,n)
        A=self.A=lambda g,s,n:V('arm',g,s,n)
        T=self.T=lambda g,n:V('hot',g,n)
        B=private[:k]
        J={2:0,4:1,8:2,32:7}
        backup={t:(3 if mode=='ext' or t==8 else 2)for t in B}
        P={p|t<<13 for p,t in edges}
        neg=mx(N);pn={t:mx({n for n in N if n&(t<<13)}) for t in B}
        probes=neg|P|set.union(*pn.values())|{1<<i for i in range(20)}|{(t|v)<<13 for t,v in combinations(alltag,2)}
        for g in range(8):
            own=next((t for t,v in J.items()if g==v),None)
            for s in (0,1):
                for i in range(20):
                    x=1<<i;parts=None
                    if x in q.values():parts=(own is not None and q[own]==x and s==1)
                    elif i>=13 and (1<<(i-13)) in private:
                        t=1<<(i-13)
                        if g==J[t]:parts=s==0
                        elif backup.get(t)!=g:parts=False
                        elif own is not None:parts=s==0
                    elif own is not None and s==1 and not (x&U[own]):parts=False
                    elif own==32 and s==0:parts=False
                    if parts is not None:C.append([W(g,s,i)*(1 if parts else -1)])
        for t,g in backup.items():C.append([W(g,0,13+t.bit_length()-1),W(g,1,13+t.bit_length()-1)])
        for n in sorted(probes):
            for g in range(8):
                arms=[]
                for s in range(2):
                    ys=[W(g,s,i) for i in range(20)if n&(1<<i)]
                    ys += [AND(V('lit',g,s,d,n),[W(g,s,20+d),G(d,n)]) for d in range(min(g,3))]
                    arms.append(OR(A(g,s,n),ys))
                AND(G(g,n),arms);OR(T(g,n),arms)
            if n in P:C.append([G(g,n)for g in range(3,8)])
            if n in neg:C.extend([-G(g,n)]for g in range(3,8))
        for g,t in enumerate(private[:3]):
            C.append([G(g,n)for n in neg])
            C.extend([-G(g,n)]for n in pn[t])
            C.extend([[G(g,q[t]|(t<<13))],[G(backup[t],q[t]|(t<<13))]])
            for i in range(8):
                if i!=g:C.append([-T(i,q[t])])
        for t in alltag:
            n=t<<13
            C.extend([-G(g,n)]for g in range(8))
            C.extend([-T(g,n)for g in v]for v in combinations(range(8),3))
        for t,v in combinations(alltag,2):
            n=(t|v)<<13
            C.extend([-T(g,n) for g in sites]for sites in combinations(range(8),4))
        for r in (1,2,3):
            for S in combinations(ordinary,r):
                for cut in combinations(range(3,7),r-1):C.append([T(g,t<<13)for g in range(3,7) if g not in cut for t in S])
        # In each numbered private site, no other raw point on the petal may be high in the presence of its tag at an unsafe input.
        if k==3:
            for p in pts:
                if U[32]&p:C.append([A(7,1,p)])
        for g in range(3,7):
            pre=[]
            for i in range(23):
                a,b=W(g,0,i),W(g,1,i); C.append(pre+[-a,b]);e=V('eq',g,i)
                C.append(pre+[a,b,e]);C.append(pre+[-a,-b,e]);pre=[-e]
        # Exterior sites 4,5,6 are interchangeable. Sort their singleton ordinary-tag addresses.
        for g in (4,5):
            pre=[]
            for t in ordinary:
                a,b=T(g,t<<13),T(g+1,t<<13);C.append(pre+[-a,b]);e=V('lex',g,t)
                C.append(pre+[a,b,e]);C.append(pre+[-a,-b,e]);pre=[-e]
    def solve(self):
        with Cadical195(bootstrap_with=self.C)as S:
            S.conf_budget(12000);return S.solve_limited()
if __name__=='__main__':
    for m in ('ext','hub'):
        for k in (3,4):
            M=Model(m,k);print(m,k,len(M.C),M.solve(),flush=True)
