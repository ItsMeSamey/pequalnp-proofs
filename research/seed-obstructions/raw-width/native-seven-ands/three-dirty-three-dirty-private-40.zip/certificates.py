from pathlib import Path
import argparse
import gzip
import hashlib
import subprocess
import tempfile
from pysat.solvers import Glucose4
from pricing import *

out=Path(__file__).resolve().parent/'proofs'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def run(args):
    for mode,bk,ik in [(m,k,i)for m in ('ext','hub')for k in (3,4) for i in ([-1] if k==4 else [-1,0,1])]:
        key=f'{mode}-{bk}-{ik}'
        if args.case and args.case!=key:continue
        M=Model(mode,bk); ks=json.load(open(f'marks-{mode}-{bk}.json'))['live']
        if ik<0:C=M.C+[[-v for v in marks(M,k)]for k in ks]
        else:
            k=ks[ik];C=M.C+[[v]for v in marks(M,k)]
            for w in json.load(open(f'lib-{mode}-3.json')):
                mt=tuple(sum(1<<g for g in range(7)if (w[2*g]|w[2*g+1])&(t<<13))for t in ordinary)
                if tuple(k)!=mt:continue
                C.append([M.W(g,s,j)*(-1 if w[2*g+s]&(1<<j)else 1)for g in range(8)for s in (0,1)for j in range(20+min(g,3))])
        cnf=('p cnf %d %d\n'%(max(abs(v)for c in C for v in c),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode()
        archive=out/(key+'.drat.gz')
        if args.verify_only:
            proof=gzip.decompress(archive.read_bytes())
        else:
            with Glucose4(bootstrap_with=C,with_proof=True) as s:
                s.conf_budget(50000)
                ans=s.solve_limited()
                if ans is not False:print("UNKNOWN",key,ans,flush=True);continue
                proof=('\n'.join(s.get_proof())+'\n').encode()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);f=p/'c.cnf';g=p/'p.drat';f.write_bytes(cnf);g.write_bytes(proof)
            cmd=[args.drat_trim,str(f),str(g),'-t','30']
            if not args.verify_only:
                trimmed=p/'trimmed.drat'
                r=subprocess.run(cmd+['-l',str(trimmed),'-C'],capture_output=True,timeout=35)
                assert r.returncode==0 and b's VERIFIED' in r.stdout,(key,r.stdout[-400:])
                proof=trimmed.read_bytes()
                g.write_bytes(proof)
            r=subprocess.run(cmd+['-i'],capture_output=True,timeout=35)
            assert r.returncode==0 and b's VERIFIED' in r.stdout,(key,r.returncode,r.stdout[-400:])
        if not args.verify_only:
            out.mkdir(exist_ok=True)
            archive.write_bytes(gzip.compress(proof,compresslevel=6,mtime=0))
        print(key,len(C),len(proof),sha(cnf),sha(proof),'VERIFIED',flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('drat_trim');ap.add_argument('--verify-only',action='store_true');ap.add_argument('--case');run(ap.parse_args())
