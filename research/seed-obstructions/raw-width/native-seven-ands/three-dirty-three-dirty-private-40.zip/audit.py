from controls import *
from itertools import permutations
from model import mx,N
assert len(rows)==676 and sum(y<0 for _,_,y in rows)==624 and len(N)==468 and len(mx(N))==245
nb={p:frozenset(v for v in alltag if U[v]&p)for p in pts}
idx={val:p for p,val in nb.items()};images=set();maps=[]
for a in permutations(private):
    for b in permutations(ordinary):
        v=dict(zip(alltag,a+b));vset={p:frozenset(v[t]for t in ns)for p,ns in nb.items()}
        if not all(s in idx for s in vset.values()):continue
        pm={p:idx[s] for p,s in vset.items()};d=pm|{t<<13:w<<13 for t,w in v.items()}
        def tr(m):return sum(y for x,y in d.items() if m&x)
        if {tr(m) for m in mx(N)}!=mx(N):continue
        images|={tr(129),tr(4160)};maps.append(a)
assert len(maps)==24 and images=={129,320,513,1028,2052,4160}
for mode,count in [('ext',1940),('hub',96)]:
    W=json.load(open(f'lib-{mode}-3.json'));assert len(set(map(tuple,W)))==count
    c=Counter(lower(tuple(sorted({(x,x) for x in w if x.bit_count()>1}))) for w in W)
    assert min(c)>=28;print('price',mode,sorted(c.items()))
for mode,k,net in json.load(open('physical.json')):
    validate(net);assert not net['accepted_independent_tag_masks']
    def marks_at(p,t):
        v=[bool((p|(t<<13))&(1<<i))for i in range(20)];M={}
        for g,(o,a,b)in enumerate(net['gates'],20):
            if o=='and':M[g]=v[a],v[b]
            v.append(v[a] and v[b] if o=='and' else v[a] or v[b])
        return M
    j={};hot=lambda p,t:[i for i,x in marks_at(p,t).items()if any(x)]
    for u in private:
        i,=hot(q[u],0);j[u]=i;x=marks_at(q[u],0)[i];y=marks_at(0,u)[i]
        assert x in [(False,True),(True,False)]and x==y[::-1] and len(hot(0,u))==1+(u!=32)
    assert len(set(j.values()))==4 and set(net['dirty'])=={j[u]for u in private[:3]}
    for t in alltag:
        assert len(hot(0,t))<=2 and not any(all(x)for x in marks_at(0,t).values())
    for t,u in combinations(alltag,2):assert len(hot(0,t|u))<=3
    assert min(sum(all(x)for x in marks_at(q[u],u).values())for u in private[:3])>=2
    assert any(all(a in hot(0,t) for a,t in zip(ls,ordinary))for ls in permutations(set(marks_at(0,0))-set(j.values()),3))
    print('physical',mode,k,len(net['gates']))
