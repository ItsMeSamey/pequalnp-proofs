from pricing import *
def run(mode):
    M=Model(mode,3);data=[]
    for k in json.load(open(f'marks-{mode}-3.json'))['live']:
        c=Counter()
        for w in expressions(M,k):
            data.append(w);c[lower(tuple(sorted({(m,m) for m in w if m.bit_count()>1})))]+=1
        print('priced',mode,k,sum(c.values()),sorted(c.items()),flush=True)
    open(f'lib-{mode}-3.json','w').write(json.dumps(sorted(set(data)),separators=(',',':'))+'\n')
if __name__=='__main__':
    for mode in ('ext','hub'):run(mode)
