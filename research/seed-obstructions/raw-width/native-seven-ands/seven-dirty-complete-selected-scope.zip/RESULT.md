# Seven dirty ANDs in the protected native eight-AND representation

For each native bank, a protected separator selected at area at most 33 with eight AND gates cannot have seven dirty sites. The sole clean gate must provide the output. Four matched private sites and four exterior sites partition its eight ANDs. Exactly three or four dirty sites are private.

| Dirty private matches | Location of sole clean output | Selected roles | Whole-CNF certificates |
|---:|---|---:|---:|
| 3 | The remaining matched private site | Four chronological triples at each of three and four backed tags, all at a common exterior center | 8 |
| 4 | The remaining exterior site | Two center choices for a dirty exterior backup, or two center choices times five locations of the third exterior dirty for a clean backup | 12 |

In the first row, c3d7d8b2 excludes the private center and places at least two dirty exterior sites before the first dirty private one. The backup is the last dirty site. It can reach either socket of the sole clean output. The second row uses two distinct dirty exterior ancestors for every matched private site. In both rows full gate semantics allow any permitted earlier dirty donor to enter either socket and unrestricted OR sharing at any depth between ANDs. The chart partition and direct role indices appear in edc195b2.

Whole-CNF proofs 980f7f79 and 74cffa3a give eight and twelve UNSAT certificates for the signed role encodings before any OR pricing. The table uses signed native data and protected structural conditions. Distinct donor controls exercise the last dirty gate on the full indexed native probes. Those partial-positive circuits served only as encoder regression controls. No control pins or dropped production demands enter the whole-CNF proofs.

The chronological reductions use the selected six-objective representative. They do not assert unconditional seven-dirty impossibility for arbitrary higher-area circuits. The whole original transport across all dirty counts has a separate dependency crosswalk.
