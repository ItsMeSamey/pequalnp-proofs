#include <array>
#include <cassert>
#include <cstdint>
#include <cstdio>

using Mask = std::uint64_t;

struct SixSites {
    // An orientation selects the left or the right socket at each of six sites.
    // Any chosen socket containing a forbidden tag is independently discarded.
    std::array<Mask, 12> orientations{};
    std::array<int, 12> socket{};
    std::array<bool, 12> reserved{};
    std::array<int, 7> primary{}, backup{};
    long long total = 0, feasible = 0;

    void reserve(int tag, int site, int side) {
        int port = 2 * site + side;
        primary[tag] = port;
        reserved[port] = true;
        socket[port] = 1 << tag;
    }

    explicit SixSites(int pairs) {
        for (int orientation = 0; orientation < 64; ++orientation)
            for (int g = 0; g < 6; ++g)
                orientations[2*g + ((orientation >> g) & 1)] |= Mask(1) << orientation;
        int tag = 0, site = 0;
        while (site < pairs) {
            reserve(tag++, site, 0);
            reserve(tag++, site++, 1);
        }
        while (tag < 7) reserve(tag++, site++, 0);
        assert(site <= 6);
    }

    bool realizes(int forbidden) const {
        Mask allowed = ~Mask(0);
        for (int t = 0; t < 7; ++t) {
            if (forbidden & (1 << t)) continue;
            Mask provided = orientations[primary[t]];
            int b = backup[t];
            if (b >= 0 && !(socket[b] & forbidden))
                provided |= orientations[b];
            allowed &= provided;
        }
        return allowed != 0;
    }

    void enumerate(int tag) {
        if (tag == 7) {
            ++total;
            for (int avoid = 0; avoid < 128; ++avoid)
                if (__builtin_popcount(unsigned(avoid)) <= 2 && !realizes(avoid)) return;
            ++feasible;
            return;
        }
        backup[tag] = -1;
        enumerate(tag + 1);
        for (int b = 0; b < 12; ++b) {
            if (reserved[b] || b/2 == primary[tag]/2) continue;
            backup[tag] = b;
            socket[b] |= 1 << tag;
            enumerate(tag + 1);
            socket[b] ^= 1 << tag;
        }
    }
};

int main() {
    const std::array<int, 3> expected{112500, 162000, 233280};
    for (int pairs = 1; pairs <= 3; ++pairs) {
        SixSites m(pairs);
        m.enumerate(0);
        std::printf("%d paired sites: %lld assignments, %lld feasible\n",
                    pairs, m.total, m.feasible);
        if (m.total != expected[pairs-1] || m.feasible != 0) return 1;
    }
}
