from contextlib import redirect_stdout
from itertools import combinations
import io
with redirect_stdout(io.StringIO()):
    import chart_inputs as table

assert len(table.pos) == 28 and len(table.neg) == 624
for size in range(3):
    for absent in combinations(range(7), size):
        forbidden = sum(1 << i for i in absent)
        for row, (points, tags, sign) in enumerate(table.rows):
            if tags != forbidden or sign != -1:
                continue
            covered = 0
            for p, t in table.pos:
                if points & p:
                    covered |= t
            if covered == (127 ^ forbidden):
                print(forbidden, row, points)
                break
        else:
            raise AssertionError(('missing native witness', forbidden))
