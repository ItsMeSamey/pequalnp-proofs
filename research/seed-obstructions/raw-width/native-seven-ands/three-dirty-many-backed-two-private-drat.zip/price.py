from corpus import *
from sym import banks
from functools import cache
from random import Random
from ast import literal_eval
from pathlib import Path
import json
Norig=sorted(N0);sample=Norig+[1<<i for i in range(13)]
rawmask={x:sum(1<<i for i,m in enumerate(sample)if m&x) for x in {1<<j for j in range(20)}}
zones={v:sum(1<<i for i,m in enumerate(Norig)if m&sx(v))for v in (8,32)}
def cone(terms,physical):
 d=[];T=[]
 for so in terms:
  a=[]
  for xx in so:
   m=z=0
   for x in xx:
    m|=x if x>0 else 1<<(19-x)
    z|=rawmask[x] if x>0 else d[-1-x]
   if m.bit_count()>1:T.append((m,m))
   a.append(z)
  if len(d)<3:d.append(a[0]&a[1])
 for v in (8,32):
  selected=physical.get(v);lo=hi=stars[v] if selected is None else selected
  for j,z in enumerate(d):
   if not z&zones[v]:
    if selected is None:lo&=~(z>>len(Norig))
    hi|=1<<(20+j)
  T.append((lo,hi))
 return tuple(sorted(set(T)))
@cache
def cover(m,bs):
 if not m:return 0
 a=m&-m
 return 1+min(cover(m&~b,bs)for b in (a,*bs)if b&a)
@cache
def orders(T):
 rr=Random(7);n=len(T);r=[list(range(n)),list(reversed(range(n))),sorted(range(n),key=lambda i:-T[i][0].bit_count()),sorted(range(n),key=lambda i:T[i][0].bit_count())]
 for _ in range(36):
  a=list(range(n));rr.shuffle(a);r.append(a)
 return r
def cost(T,bank):
 best=0
 for perm in orders(T):
  prev=[];score=0
  for i in perm:
   lo,hi=T[i];gr=prev+[x for x in bank if not x&~hi]
   bs=tuple(sorted({lo&x for x in gr if (lo&x).bit_count()>1}))
   score+=max(0,cover(lo,bs)-1);prev.append(hi)
  best=max(best,score)
  if best>=28:break
 return best
@cache
def price(T):
 z=cost(T,tuple(sorted({x for b in banks for x in b})))
 return z if z>=28 else min(cost(T,b)for b in banks)
def process():
 ix=int(sys.argv[1]);cap=int(sys.argv[2]);H=list(charts())[ix];M=Model(*H);records=[]
 for l in Path(f'corpus-{ix}.log').read_text().splitlines():
  if not l.startswith('(')or l.endswith('False'):continue
  k=literal_eval(l.split(')')[0]+')');asp=ass(M,k);switch=M.V(('activate',k));asp+=[switch];C=Counter()
  for j in range(cap):
   z=M.do(asp,10000)
   if z is not True:break
   w=M.witness();sm=set(M.sat.get_model());physical={}
   privbits=[]
   for g,v in enumerate((8,32),6):
    if v not in M.extra:continue
    mask=q[v]
    for x,jj in sorted(edges):
     if jj!=v or x==q[v]:continue
     bit=M.term(g,1,x);privbits.append(-bit if bit in sm else bit)
     if bit in sm:mask|=x
    physical[v]=mask
   score=price(cone(w,physical));C[score]+=1;records.append([k,w,physical,score])
   M.sat.add_clause([-switch,*privbits,*[(-1 if x in w[g][s] else 1)*M.term(g,s,x)for g in range(6)for s in (0,1)for x in M.keys[g,s]]])
  else:z='limit'
  print(k,sorted(C.items()),z,flush=True)
 Path(f'layouts-{ix}.json').write_text(json.dumps(records,separators=(',',':')))
if __name__=='__main__':process()
