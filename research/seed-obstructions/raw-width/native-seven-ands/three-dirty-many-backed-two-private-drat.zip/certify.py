from corpus import *
from price import cone,price
from pysat.solvers import Glucose4
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess,json,hashlib,gzip,argparse
def certified(i,exe,verify):
 H=list(charts())[i];M=Model(*H);C=list(M.C);ss=[]
 for k in keys(H):
  sel=M.V(('named signature',*k));ss.append(sel);C.extend([-sel,j]for j in ass(M,k))
 C.append(ss)
 layout=json.loads(Path(f'layouts-{i}.json').read_text());seen=set()
 for k,w,r,score in layout:
  r={int(t):m for t,m in r.items()};assert set(r)==set(M.extra)
  assert price(cone(w,r))==score and score>=26
  block=[(-1 if x in w[g][s] else 1)*M.term(g,s,x)for g in range(6)for s in (0,1)for x in M.keys[g,s]]
  for g,t in enumerate((8,32),6):
   if t in r:
    assert r[t]&q[t] and not r[t]&~stars[t]
    for x,j in sorted(edges):
     if j==t and x!=q[t]:block.append((-1 if x&r[t] else 1)*M.term(g,1,x))
  assert tuple(block) not in seen;seen.add(tuple(block));C.append(block)
 cnf=('p cnf %d %d\n'%(max(abs(v)for c in C for v in c),len(C))+''.join(' '.join(map(str,c))+' 0\n'for c in C)).encode()
 target=Path('proofs')/f'{i}.drat.gz'
 if verify:proof=gzip.decompress(target.read_bytes())
 else:
  with Glucose4(bootstrap_with=C,with_proof=True)as S:
   S.conf_budget(30000);ans=S.solve_limited()
   assert ans is False,(i,ans);proof=('\n'.join(S.get_proof())+'\n').encode()
 with TemporaryDirectory(dir='/dev/shm')as d:
  p=Path(d);f=p/'chart.cnf';z=p/'proof.drat';f.write_bytes(cnf);z.write_bytes(proof)
  def test(args):
   res=subprocess.run([exe,str(f),str(z),'-t','20',*args],capture_output=True,timeout=25)
   assert res.returncode==0 and b's VERIFIED'in res.stdout,(i,res.returncode,res.stdout[-500:])
  if not verify:
   trimmed=p/'trim.drat';test(['-C','-l',str(trimmed)]);proof=trimmed.read_bytes();z.write_bytes(proof)
  test(['-i'])
 if not verify:target.parent.mkdir(exist_ok=True);target.write_bytes(gzip.compress(proof,compresslevel=6,mtime=0))
 print(i,len(ss),len(layout),len(C),hashlib.sha256(cnf).hexdigest(),hashlib.sha256(proof).hexdigest(),len(proof),'VERIFIED',flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('checker');ap.add_argument('--case',type=int);ap.add_argument('--verify-only',action='store_true');a=ap.parse_args()
 for i in (range(16)if a.case is None else [a.case]):certified(i,a.checker,a.verify_only)
