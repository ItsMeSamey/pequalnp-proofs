from controls import *
from collections import Counter
import json
out=[]
for i,H in enumerate(charts()):
 rr=json.loads(Path(f'layouts-{i}.json').read_text());best={}
 if not rr:continue
 M=Model(*H)
 for k,w,phys,score in rr:
  ass0=ass(M,k)+[(1 if x in w[g][s] else -1)*M.term(g,s,x)for g in range(6)for s in (0,1)for x in M.keys[g,s]]
  for g,t in enumerate((8,32),6):
   if t in M.extra:ass0 += [(1 if phys[str(t)]&p else -1)*M.term(g,1,p)for p,j in edges if j==t and p!=q[t]]
  assert M.do(ass0,1000) is True
  b=build(M,w,k);key=tuple(k)
  if b[1] and (key not in best or b[0]<best[key][0]):best[key]=b
 for k,b in best.items():out.append([H,k,*b])
Path('best-controls.json').write_text(json.dumps(out,separators=(',',':')))
print('physical upper bounds per case',[(x[0],x[1],x[2])for x in out])
