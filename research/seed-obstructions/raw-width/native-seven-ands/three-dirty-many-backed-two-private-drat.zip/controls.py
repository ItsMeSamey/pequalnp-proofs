from corpus import *
from pathlib import Path
from ast import literal_eval
import json
def build(M,w,k):
 ar=[set(x)for pair in w for x in pair];sm=set(M.sat.get_model())
 for g,t in enumerate((8,32),6):
  ar.extend([{sx(t)}|{-1-i for i in range(3)if M.term(g,0,-1-i)in sm},{p for p,j in edges if j==t and (t not in M.extra or p==q[t] or M.term(g,1,p)in sm)}|{-1-i for i in range(3)if M.term(g,1,-1-i)in sm}])
 # symbols >2^20 are private to this factoring routine
 for n,x in enumerate((129,4160),22):
  pr={p for p in points if p&x}
  for a in ar:
   if pr<=a:a.difference_update(pr);a.add(1<<n)
 defs={};known={1<<i:i for i in range(20)}|{1<<22:20,1<<23:21}
 while any(len(a)>1 for a in ar):
  ps=Counter(p for a in ar for p in combinations(sorted(a),2));p=min(ps,key=lambda z:(-ps[z],z));x=1<<(24+len(defs));defs[x]=p
  for a in ar:
   if set(p)<=a:a.difference_update(p);a.add(x)
 net=[];ands=[]
 def gate(op,l,r):net.append((op,l,r));return 21+len(net)
 def phys(j):
  if j not in known:
   a,b=defs[j];known[j]=gate('or',phys(a),phys(b))
  return known[j]
 for g in range(8):
  a,=ar[2*g];b,=ar[2*g+1];ands.append(gate('and',phys(a),phys(b)))
  if g<3:known[-1-g]=ands[-1]
 o=ands[3]
 for n in ands[4:]:o=gate('or',o,n)
 def eval(m):
  z=m|bool(m&129)<<20|bool(m&4160)<<21
  for i,(op,l,r)in enumerate(net,22):
   z|=(((z>>l&z>>r)if op=='and' else(z>>l|z>>r))&1)<<i
  return z
 def marks(m):
  z=eval(m);return {i for i,n in enumerate(ands)if (z>>net[n-22][1]|z>>net[n-22][2])&1}
 dirty=set()
 for p,t,y in rows:
  z=eval(p|sx(t))
  if y:assert bool(z>>o&1)==(y==1)
  if y<0:dirty.update(i for i,n in enumerate(ands)if z>>n&1)
 assert dirty=={0,1,2}
 for t,i in ((2,M.h),(4,M.k),(8,6),(32,7)):assert marks(q[t])=={i}
 for d,t,b in M.cuts:assert marks(sx(t))=={d,b}
 for g,t in enumerate((8,32),6):assert marks(sx(t))==({g,M.k if M.mode=='cross' else M.B}if t in M.extra else {g})
 for t,m in zip(ordt,k):assert sum(1<<i for i in marks(sx(t)))==m
 for t in stars:
  assert len(marks(sx(t)))<=2 and all(not (eval(sx(t))>>n)&1 for n in ands)
  assert any((eval(sx(t))>>wire)&1 and all(not (eval(sx(v))>>wire)&1 for v in stars if v!=t)for n in ands for wire in net[n-22][1:])
 assert any(all(g in marks(sx(t))for g,t in zip(gs,ordt))for gs in permutations(M.ex,3))
 assert all(len(marks(sx(a|b)))<=3 for a,b in combinations(stars,2))
 origins=[{1<<i}for i in range(20)]+[{1,128},{64,4096}]
 for op,l,r in net:
  a,b=origins[l],origins[r];z=a|b if op=='or' else {i|j for i in a for j in b}
  origins.append({i for i in z if not any(j!=i and not j&~i for j in z)})
 return len(net),origins[o]==P,net,ands,o
def run():
 rec=[]
 for i,H in enumerate(charts()):
  M=Model(*H)
  for l in Path(f'corpus-{i}.log').read_text().splitlines():
   if not l.endswith('True'):continue
   k=literal_eval(l.rsplit(' ',1)[0]);assert M.do(ass(M,k),30000)
   rec.append((H,k,*build(M,M.witness(),k)))
 Path('controls.json').write_text(json.dumps(rec,separators=(',',':')))
 print('binary controls',len(rec),'full cube',sum(r[3]for r in rec),'areas',Counter(r[2]for r in rec))
if __name__=='__main__':run()
