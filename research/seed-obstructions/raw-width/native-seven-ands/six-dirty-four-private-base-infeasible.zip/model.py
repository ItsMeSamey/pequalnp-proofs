"""Six dirty ANDs, four dirty private owners; base and optionally serial prefix."""
from itertools import combinations
from nativecontrol import edges,rows
from pysat.formula import IDPool
private=(2,4,8,32);ordinary=(1,16,64);tags=private+ordinary
def sx(t):return t<<13
P={p|sx(t)for p,t in edges}
N0={p|sx(t)for p,t,y in rows if y<0}
N={n for n in N0 if not any(n!=m and not n&~m for m in N0)}
U={t:sum(p for p,j in edges if j==t)for t in tags}
points=tuple(1<<i for i in range(13))
q={t:next(p for p in points if p&U[t] and sum(bool(p&a)for a in U.values())==1)for t in private}
cycle=(1,4,64)
class Model:
    def __init__(self,mode,serial=False):
        assert mode in ('ext','hub')
        self.mode=mode; self.serial=serial
        C=self.C=[];V=IDPool().id
        def W(g,s,j):return V(('source',g,s,j))
        def A(g,s,n):return V(('arm',g,s,n))
        def G(g,n):return V(('gate',g,n))
        def T(g,n):return V(('hot',g,n))
        self.W=W;self.A=A;self.G=G;self.T=T
        def emit(i,xs,and_gate):
            if and_gate:
                C.append([i,*[-x for x in xs]]);C.extend([-i,x]for x in xs)
            else:
                C.append([-i,*xs]);C.extend([i,-x]for x in xs)
            return i
        self.selectors={(g,s):tuple(W(g,s,j)for j in range(20+min(g,6)))for g in range(8)for s in (0,1)}
        owner=dict(zip(private,range(2,6)))
        backup={t:(6 if mode=='ext' or t==32 else 5)for t in private}
        guests=private if mode=='ext' else private[:3]
        for g in range(8):
            own=next((t for t in private if owner[t]==g),None)
            for s in (0,1):
                for j in range(20):
                    x=1<<j;val=None
                    if x in q.values():val=own is not None and x==q[own] and s==1
                    elif j>=13 and (1<<(j-13))in private:
                        t=1<<(j-13)
                        if g==owner[t]:val=s==0
                        elif g!=backup[t]:val=False
                        elif own:val=s==0
                    elif own and s==1 and not x&U[own]:val=False
                    elif own in guests and s==0:val=False
                    if val is not None:C.append([(1 if val else -1)*W(g,s,j)])
        for t in private:
            g=backup[t];j=13+t.bit_length()-1;C.append([W(g,0,j),W(g,1,j)])
        probes=N|P|{1<<i for i in range(20)}|{sx(a|b)for a,b in combinations(tags,2)}
        for n in sorted(probes):
            for g in range(8):
                for s in (0,1):
                    ls=[W(g,s,j)for j in range(20)if n>>j&1]
                    ls.extend(emit(V(('active',g,s,d,n)),[W(g,s,20+d),G(d,n)],True)
                              for d in range(min(g,6)))
                    emit(A(g,s,n),ls,False)
                emit(G(g,n),[A(g,0,n),A(g,1,n)],True);emit(T(g,n),[A(g,0,n),A(g,1,n)],False)
        self.positive={n:(G(6,n),G(7,n))for n in P}
        for c in self.positive.values():C.append(list(c))
        for n in N:C.extend([[-G(6,n)],[-G(7,n)]])
        for g in range(6):C.append([G(g,n)for n in N])
        for t in private:
            g=owner[t];b=backup[t];p=q[t];j=13+t.bit_length()-1
            C.extend([-T(i,p)]for i in range(8)if i!=g)
            C.extend([[G(g,p|sx(t))],[G(b,p|sx(t))]])
            C.extend([-G(g,n)]for n in N if n&sx(t))
            C.extend([-G(g,n),-G(b,n)]for n in N)
            for s in (0,1):
                mark=W(b,s,j)
                for n in probes:C.append([-mark,-G(g,n),A(b,1-s,n)])
            if t in guests:
                C.extend([-G(g,n)]for n in N if n&sx(sum(private)))
                C.extend([-G(g,p)]for p in points)
                C.extend([A(g,1,p)]for p in points if p&U[t])
        if mode=='ext':
            for s in (0,1):
                first=W(6,s,14)
                for t in private[1:]:
                    later=W(6,s,13+t.bit_length()-1);C.extend([[first,-later],[-first,later]])
        for t in tags:
            n=sx(t);C.extend([-G(g,n)]for g in range(8))
            C.extend([-T(g,n)for g in gg]for gg in combinations(range(8),3))
            choices=[]
            for g in range(8):
                for s in (0,1):
                    z=V(('exclusive',g,s,t));choices.append(z);C.append([-z,A(g,s,n)])
                    C.extend([-z,-A(g,s,sx(v))]for v in tags if v!=t)
            C.append(choices)
        for a,b in combinations(tags,2):
            n=sx(a|b);C.extend([-T(g,n)for g in gg]for gg in combinations(range(8),4))
        ext=(0,1,6,7)
        for j in (1,2,3):
            for tt in combinations(ordinary,j):
                for cut in combinations(ext,j-1):C.append([T(g,sx(t))for g in ext if g not in cut for t in tt])
        # Exact dirty-wire ancestry, independent of functional redundancy at a socket.
        for start in (0,1):
            reach={}
            for g in range(start+1,6):
                vias=[W(g,s,20+start)for s in (0,1)]
                for d in range(start+1,g):
                    for s in (0,1):
                        vias.append(emit(V(('reach via',start,d,g,s)),[reach[d],W(g,s,20+d)],True))
                reach[g]=emit(V(('reaches',start,g)),vias,False)
                if g>=2:C.append([reach[g]])
        for g in ext:
            prev=[]
            for j in range(20+min(g,6)):
                a,b=W(g,0,j),W(g,1,j);C.append(prev+[-a,b])
                same=V(('lex',g,j));C.append(prev+[a,b,same]);C.append(prev+[-a,-b,same]);prev=[-same]
        if serial:self.add_serial()
    def add_serial(self):
        C,W,A,T=self.C,self.W,self.A,self.T
        sites=(0,1,7)
        for t in ordinary:
            C.append([T(g,sx(t))for g in sites])
            for g,h in combinations(sites,2):C.append([-T(g,sx(t)),-T(h,sx(t))])
        for g in sites:
            for a,b in combinations(ordinary,2):C.append([-T(g,sx(a)),-T(g,sx(b))])
            for t in ordinary:
                for s in (0,1):
                    m=A(g,s,sx(t))
                    for p in cycle:
                        if U[t]&p:C.extend([[-m,A(g,1-s,p)],[-m,-A(g,s,p)]])
                    if g==1:
                        for j in range(20):
                            if 1<<j!=sx(t):C.append([-m,-W(g,s,j)])
                            if not (1<<j)&U[t]:C.append([-m,-W(g,1-s,j)])
        C.extend([[W(1,0,20),W(1,1,20)],[-W(1,0,20),-W(1,1,20)]])
        # The chronologically first private J, D2 for label 2.
        C.extend([[-W(2,0,20)],[W(2,0,21)],[-W(2,1,20)],[-W(2,1,21)]])
        C.extend([W(2,1,p.bit_length()-1)]for p in points if p&U[2])
        for t in ordinary:
            r=U[t]&U[2];assert r.bit_count()==1
            C.append([-T(1,sx(t)),self.G(2,r|sx(t))])
