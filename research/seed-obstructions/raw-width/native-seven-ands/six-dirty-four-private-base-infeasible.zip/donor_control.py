"""Six genuine dirty ANDs, four dirty private owners, sensitive fifth (D5) indexed donor."""
from pathlib import Path
from model import *
def physical():
    w=[(128,512|sx(1)),(256,4096|sx(64))]
    for t in private:w.append((sx(t)|(1<<20)|(1<<21),U[t]))
    w.append((sx(sum(private)),sum(1<<(20+d)for d in range(2,6))))
    w.append((sx(16),U[16]))
    return w
def eval(w,n,omit):
    wires=n;vals=[];socks=[]
    for g,(a,b) in enumerate(w):
        z=(wires&~(1<<25)) if omit else wires
        s=(bool(a&z),bool(b&z));socks.append(s);vals.append(all(s))
        if all(s):wires|=1<<(20+g)
    return vals,socks
def native():
    w=physical();lost=set();hits=set();dirty=set()
    for p,t,y in rows:
        vals,_=eval(w,p|sx(t),False);old,_=eval(w,p|sx(t),True)
        if y<0:
            assert not any(vals[6:]) and not any(old[6:]);dirty.update(i for i,v in enumerate(vals)if v)
        if y>0:
            if any(vals[6:]):hits.add((p,t))
            if any(vals[6:]) and not any(old[6:]):lost.add((p,t))
    assert dirty==set(range(6)) and hits=={(p,t)for p,t in edges if t in (*private,16)}
    assert lost=={(p,t)for p,t in edges if t==32}
    def hot(m):return {g for g,s in enumerate(eval(w,m,False)[1])if any(s)}
    for g,t in enumerate(private,2):
        assert hot(q[t])=={g} and hot(sx(t))=={g,6}
        for p in points:
            if p&U[t]:assert eval(w,p,False)[1][g][1]
    assert all(not any(eval(w,sx(t),False)[0])and len(hot(sx(t)))<=2 for t in tags)
    assert all(len(hot(sx(t|v)))<=3 for t,v in combinations(tags,2))
    assert all(hot(sx(t))=={g}for t,g in ((1,0),(64,1),(16,7)))
    print('actual six dirties; all 624 native negative rows rejected; twenty accepted positives')
    print('D5 omission loses precisely the four original private-32 edges',sorted(lost))
    return w
def signed(cls,w,partial):
    from pysat.solvers import Glucose4
    m=cls('ext',serial=False);pins=[]
    for g,hh in enumerate(w):
        arms=list(hh)
        if g in (0,1,6,7):
            arms.sort(key=lambda a:tuple(bool(a&(1<<j))for j in range(20+min(g,6))))
        for s,z in enumerate(arms):
            pins.extend((1 if z&(1<<j)else -1)*v for j,v in enumerate(m.selectors[g,s]))
    dropped={m.positive[p|sx(t)]for p,t in edges if t in (1,64)}
    assert len(dropped)==8
    with Glucose4(bootstrap_with=[c for c in m.C if tuple(c)not in dropped])as sol:
        assert sol.solve(assumptions=pins)is partial
    with Glucose4(bootstrap_with=m.C)as sol:assert sol.solve(assumptions=pins)is False
if __name__=='__main__':
    import sys
    w=native()
    if '--signed-cnf' in sys.argv:
        src=Path(__file__).with_name('model.py').read_text()
        target='for d in range(min(g,6)))';assert src.count(target)==1
        ns={'__name__':'omitted_d5'};exec(compile(src.replace(target,'for d in range(min(g,5)))'),'omitted.py','exec'),ns)
        signed(Model,w,True);signed(ns['Model'],w,False)
        print('corrected SAT; omitted D5 UNSAT on identical twenty-positive fixture; both UNSAT at full 28')
