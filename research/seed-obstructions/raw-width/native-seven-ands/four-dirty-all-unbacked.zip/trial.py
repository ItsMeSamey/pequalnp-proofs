from itertools import combinations
from nativecontrol import rows,edges
from pysat.formula import IDPool
from pysat.solvers import Cadical195
private=(2,4,8,32);tags=(1,16,64)
stars={t:{p for p,v in edges if v==t} for _,t in edges}
q={u:next(p for p in stars[u] if sum(p in S for S in stars.values())==1) for u in private}
raw=sorted(set.union(*stars.values())-set(q.values()))+[t<<13 for t in tags]
N0={p|(t<<13) for p,t,y in rows if y<0}
def dominated(m):return any(m&~n==0 for n in N0)
def escapes(m,U):return all(not dominated(m|p) for p in U)
by={u:{sum(z) for s in range(1,6) for z in combinations(raw,s) if dominated(sum(z)) and escapes(sum(z),stars[u])} for u in private}
assert all(len(b)==6 and all(m<8192 and m.bit_count()==4 for m in b) for b in by.values())
assert all(not(by[u]&by[v]) for u,v in combinations(private,2))
from itertools import product
def pack(p,t):return sum(1<<j for j,x in enumerate(raw) if x&(p|(t<<13)))
P={pack(p,t) for p,t in edges if t in tags}
def maxes(S):return {x for x in S if not any(x!=z and x&~z==0 for z in S)}
N=maxes({pack(p,t) for p,t,y in rows if y<0})
guard={u:maxes({pack(p,t) for p,t,y in rows if y<0 and p&sum(stars[u])}) for u in private}
tagbits=[pack(0,t)for t in tags]
Q={u:{pack(m,0) for m in S} for u,S in by.items()}
tagneg={u:maxes({pack(p,t) for p,t,y in rows if y<0 and t&u}) for u in private}
probes=sorted(set.union(P,N,*tagneg.values(),*guard.values(),*Q.values(),set(tagbits),{a|b for a,b in combinations(tagbits,2)}))
pool=IDPool();V=lambda *s:pool.id(s);C=[]
def OR(o,ls):C.append([-o]+ls);C.extend([o,-x] for x in ls)
def AND(o,ls):C.append([o]+[-x for x in ls]);C.extend([-o,x] for x in ls)
def G(g,n):return V('G',g,n)
def hot(g,n):return V('hot',g,n)
for n in probes:
    for g in range(4):
        os=[]
        for a in (0,1):
            opts=[V('raw',g,a,j) for j in range(12) if (n>>j)&1]
            for h in range(g):
                y=V('d',g,a,h,n);AND(y,[G(h,n),V('raw',g,a,12+h)]);opts.append(y)
            o=V('s',g,a,n);OR(o,opts);os.append(o)
        AND(G(g,n),os);OR(hot(g,n),os)
for g in range(4):C.append([G(g,n)for n in N])
for n in tagbits:
    for g in range(4):C.append([-G(g,n)])
    for gg in combinations(range(4),3):C.append([-hot(g,n)for g in gg])
for a,b in combinations(tagbits,2):C.append([-hot(g,a|b)for g in range(4)])
for r in (1,2,3):
    for ts in combinations(tagbits,r):
        for small in combinations(range(4),r-1):C.append([hot(g,n) for g in range(4) if g not in small for n in ts])
safe={}
for g,u in product(range(4),private):
    k=V('safe',g,u);safe[g,u]=k
    AND(k,[-G(g,n) for n in tagneg[u]])
def clauses(pair,require=P):
    cs=[]
    active={g:u for g,u in zip((2,3),pair) if u}
    for g,u in active.items():
        cs.extend([-G(g,m)] for m in guard[u])
        cs.append([G(g,m) for m in Q[u]])
    for m in sorted(require):
        p=raw[(m&-m).bit_length()-1];terms=[]
        for u in set(active.values()):
            on=V('on',pair,u,m)
            xs=[G(g,m)for g,x in active.items() if x==u]
            cs.append([-on]+xs);cs.extend([on,-x] for x in xs)
            if p in stars[u]:terms.append(on);continue
            for g in range(4):
                if active.get(g)==u:continue
                o=V('hit',pair,u,g,m);arr=[on,G(g,m),safe[g,u]]
                cs.append([o]+[-a for a in arr]);cs.extend([-o,a]for a in arr)
                terms.append(o)
        cs.append(terms)
    return cs
if __name__=='__main__':
    import sys
    scopes=[(0,2),(2,0),(2,2),(2,4)] if len(sys.argv)>1 else [p for p in product((0,*private),repeat=2) if any(p)]
    for p in scopes:
        with Cadical195(bootstrap_with=C+clauses(p)) as S:
            S.conf_budget(10000)
            ans=S.solve_limited()
            print(p,ans,flush=True)
