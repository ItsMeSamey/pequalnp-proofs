from trial import *
for pair in ((0,2),(2,2),(2,4)):
    for req in (sorted(P)[:4], sorted(P)[:2], []):
        with Cadical195(bootstrap_with=C+clauses(pair,req)) as S:
            S.conf_budget(5000)
            s=S.solve_limited()
            if s is True:
                m=set(S.get_model())
                w=[[sum((1<<j)for j in range(12+g) if V('raw',g,a,j) in m) for a in (0,1)] for g in range(4)]
                print(pair,req,w,flush=True);break
