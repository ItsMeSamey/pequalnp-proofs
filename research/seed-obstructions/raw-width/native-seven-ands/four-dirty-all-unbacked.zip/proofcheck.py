from pathlib import Path
import gzip, hashlib,sys,tempfile,subprocess
from itertools import combinations
from pysat.solvers import Glucose4
from trial import C,clauses,private,product
out=Path(__file__).parent/'drat'
def digest(b):return hashlib.sha256(b).hexdigest()
def check(u,n,C):
        key=str(u)+'-'+str(n)
        cnf=('p cnf %d %d\n'%(max(abs(x) for c in C for x in c),len(C))+''.join(' '.join(map(str,c))+' 0\n' for c in C)).encode()
        archive=out/(key+'.drat.gz')
        if '--verify-only' in sys.argv:
            proof=gzip.decompress(archive.read_bytes())
        else:
            with Glucose4(bootstrap_with=C,with_proof=True) as S:
                assert S.solve() is False
                proof=('\n'.join(S.get_proof())+'\n').encode()
            archive.write_bytes(gzip.compress(proof,compresslevel=6,mtime=0))
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);f=p/'case.cnf';g=p/'case.drat';f.write_bytes(cnf);g.write_bytes(proof)
            cmd=[sys.argv[1],str(f),str(g),'-t','30']
            R=subprocess.run(cmd,capture_output=True,timeout=40)
            assert R.returncode==0 and 's VERIFIED' in R.stdout.decode(),(key,R.returncode,R.stdout[-300:])
        print(key,len(C),len(proof),len(archive.read_bytes()),digest(cnf),digest(proof),'VERIFIED',flush=True)
if __name__=='__main__':
    for pair in product((0,*private),repeat=2):
        if any(pair):check(*pair,C+clauses(pair))
