from coupled import *
from itertools import combinations

def covers(edges,limit):
    ans=set()
    def go(rows,chosen):
        if not rows:
            ans.add(tuple(sorted(chosen)));return
        if len(chosen)>=limit:return
        e=rows[0]
        for a in (e&8191,e&~8191):go([r for r in rows if not r&a],chosen|{a})
    go(sorted(edges),set())
    return ans

nchart=0;gcharts=0
for q,u in zip(priv,own):
    tags=[1<<j for j in range(7) if 1<<j!=u]
    U=sum(e&8191 for e in Ps if e&(u<<13))
    can=lambda r:any(r&~n==0 for n in Ns)
    def N(x):return sum(e&8191 for e in Ps if e&(x<<13))
    for x in tags:
        bad=[n for n in Ns if n&q and n&(x<<13)]
        comp=(1<<20)-1
        for n in bad:comp&=~n
        assert comp==N(x)|(u<<13)
        assert all(can(q|((x|v)<<13)) for v in tags)
    for w in [0]+[1<<j for j in range(13)]:
        edges={e for e in Ps if not e&(U|w)}
        cv=covers(edges,6)
        assert cv=={tuple(v<<13 for v in tags)}
        assert all(sum(bool(e&(v<<13)) for e in edges)>=2 for v in tags)
        nchart+=1
    for k in range(2,7):
        for guests in combinations(tags,k):
            G=(1<<13)-1
            for x in guests:G&=N(x)
            assert G.bit_count()<=1
            for w in {0,G}:
                left={e for e in Ps if not e&(U|w)}
                for v in tags:
                    x=next(x for x in guests if x!=v)
                    good=[e&8191 for e in left if e&(v<<13) and can(q|(x<<13)|(e&8191))]
                    assert good
                gcharts+=1
    print('verified host',q,u)
print('14 optional omissions per host:',nchart,'signed guest charts:',gcharts)
