# Six dirty gates in the protected eight-AND separator

For each of the four original native input banks, an area-at-most-33 separator in the selected protected eight-AND representation cannot have exactly six dirty sites. The assumptions and ordered choices are those of 23b86705, 5ed9fc7f and 5943467c. Four AND sites are unique matched private sites. The other four are exterior sites. Six dirty sites leave two isolated clean output terms. Consequently the number of dirty private matches is two, three or four.

| Dirty private matches | Physical restrictions | Whole-role certificates |
|---|---|---:|
| Two | All four exterior sites are dirty. Every other dirty site is a strict ancestor of the last exterior backup. Its three exterior predecessors have the ordinary signed marks from the C6 projection. For two or three backed tags the first private index is at least one. Four backed tags require index at least two. Two common-center possibilities give 12+12+6 roles. | 30 |
| Three | There are three exterior dirty sites, one clean exterior and one clean private match. In both center modes the distinguished exterior backup can be a later dirty exterior or the clean exterior. The earliest private index is at least one for three backed labels and two for four. These give 15+5 roles per center. | 40 |
| Four | Both dirty exterior sites are ancestors of every dirty private match. The distinguished exterior backup is clean, with either a common exterior center or a private center. The two base roles allow either exterior wire in each physically admissible operand. | 2 |

The 72 whole-role refutations use free OR evaluation on each operand. This grants arbitrary OR-only sharing and includes the disjunctions computed by either optional point-pair input. The formulae impose the original signed requirements and the structural conditions on actual protected gates. Chronological restrictions use the selected representation. The four-private proof uses the unpriced base roles without imposing the optional serial-prefix restriction. Each production packet records the full CNF and DRAT digests, regeneration sources and the role-by-role outcome.

The signed native relation has 28 distinct positive incidence pairs and 624 indexed negative rows. Their projections have 468 distinct masks, of which 245 are maximal. The clauses can use equivalent or monotonicity-redundant rows. The proof does not require a particular off-promise completion.

Together with the earlier exclusions through five dirty gates, this leaves exactly seven dirty gates for a selected eight-AND candidate of area at most 33. Eight dirty gates would leave no clean output term. The nine- and ten-AND candidates require their own proofs. This result alone gives no change to the unrestricted area interval 33–34.
