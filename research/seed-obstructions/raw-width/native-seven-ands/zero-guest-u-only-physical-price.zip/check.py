from itertools import combinations
from pathlib import Path

raw = [tuple(map(int, line.split())) for line in
       Path(__file__).with_name("native.in").read_text().splitlines()]
assert raw[0] == (28, 468) and len(raw) == 497
edges = set(raw[1:29])
assert len(edges) == 28
negative = raw[29:]
points = [1 << i for i in range(13)]
tags = [1 << i for i in range(7)]
neighbors = {t: {p for p in points if (p, t) in edges} for t in tags}
private = {p: t for p, t in edges if sum(p == d for d, g in edges) == 1}
assert len(private) == 4
assert all(len(a & b) == 1 for a, b in combinations(neighbors.values(), 2))
def rejected(pm, tm):
    return any(n & pm == pm and w & tm == tm for n, w in negative)
mixed = 0
for pm in range(8192):
    if pm.bit_count() > 3:
        continue
    for tm in range(128):
        size = pm.bit_count() + tm.bit_count()
        if size > 3 or (size == 3 and not (pm and tm)):
            continue
        if any(pm & d and tm & g for d,g in edges):
            continue
        assert rejected(pm, tm)
        mixed += 1

def subsets(seq):
    for bitmask in range(1 << len(seq)):
        yield {v for i,v in enumerate(seq) if bitmask & (1 << i)}

controls = 0
for q,u in private.items():
    for t in tags:
        if t == u:
            continue
        T = neighbors[t]
        p, = T & neighbors[u]
        for D in subsets(sorted(T)):
            if p not in D:
                continue
            for G in subsets([v for v in tags if v != u]):
                if t not in G:
                    continue
                for d,g in edges:
                    if d not in D or g not in G or g == t or d == p:
                        continue
                    assert not D <= neighbors[g]
                    if all(d in neighbors[v] for v in G):
                        actual = {(y,v) for y,v in edges if y in D and v in G}
                        assert actual <= {(d,v) for v in G} | {(y,t) for y in D}
                    controls += 1
print("Native nonincidences under maximal negatives for all sets of size <=2 and mixed triples:", mixed)
print("Incidence-geometry checks for foreign off-star edges:", controls)
