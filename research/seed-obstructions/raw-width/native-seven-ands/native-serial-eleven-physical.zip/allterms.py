exec(open('raw.py').read().split('pairs=0')[0])
from itertools import product
s=72968|581664
a,b,c,d=8320,708,1288,16640
RR=P+N
@lru_cache(None)
def table(mask):return sum(1<<i for i,r in enumerate(RR) if r&mask)
def check(l,a,b,c,d):
 A,B,C,D=map(table,(a,b,c,d));H=A&B;K=(H|C)&D
 helper=[0,H,K,H|K];rem=allP^l
 terms={}
 def add(a,b,i,j):
    z=(table(a)|helper[i])&(table(b)|helper[j])
    if z>>28 or not z:return
    if z not in terms:terms[z]=(a,b,i,j)
 for i,star in enumerate(pa):
    m=star&rem;t=m
    while t:
        A=1<<i;B=0
        for e in bits(t):B|=P[e.bit_length()-1]^A
        for h,k in product(range(4),repeat=2):add(A,B,h,k)
        t=(t-1)&m
 for h,k in product(range(1,4),range(4)):
    B=sum(1<<i for i,n in enumerate(na) if not n&(helper[h]>>28))
    add(0,B,h,k)
 M=sorted(terms,key=int.bit_count,reverse=True)
 M=[z for j,z in enumerate(M) if not any(z&~w==0 for w in M[:j])]
 order={b:[z for z in M if z&b] for b in bits(allP)}
 @lru_cache(None)
 def dfs(todo,left):
    if not todo:return ()
    if not left:return None
    cands=min((order[b] for b in bits(todo)),key=len)
    for z in sorted(cands,key=int.bit_count,reverse=True):
        ans=dfs(todo&~z,left-1)
        if ans is not None:return (terms[z],)+ans
 ans=dfs(allP,int(__import__('sys').argv[1]) if len(__import__('sys').argv)>1 else 6)
 return ans
av=0
for ln in open('profiles.txt'):
 l,mode,a,b,c,d=map(int,ln.split());assert mode==1
 ans=check(l,a,b,c,d)
 if ans is not None:print('pass',l,a,b,c,d,ans,flush=True);av+=1
print('accepting fixed profiles',av,flush=True)
