exec(open('raw.py').read().split('pairs=0')[0])
from itertools import permutations
from collections import Counter
@lru_cache(None)
def pos(a):return sum(1<<i for i,p in enumerate(P) if p&a)
triples=[tuple(map(int,s.split())) for s in open('triples.txt')]
accepted=set();stats=Counter()
for line in open('extremal.log'):
 if not line[0].isdigit():continue
 l=int(line.split()[0])
 for triple in triples:
    S=allP
    for z in triple:S&=pos(z)
    y=l&S;x=l&~y
    if x.bit_count() not in (5,6) or y.bit_count() not in (5,6):continue
    for c,d,v in permutations(triple):
        z=x&~(pos(d)&pos(v))
        dv=neg(d)&neg(v)
        if not any((h:=neg(a)&neg(b))&dv==0 and not z&~elig(h) for a,b in combinations_with_replacement(covers(x),2)):continue
        kind=any(not z&~star for star in pa)
        stats[kind,z.bit_count()]+=1
        accepted.add((l,c,d,v,x,z))
print(stats,'records',len(accepted))
with open('rivals.txt','w') as f:
 for row in sorted(accepted):print(*row,file=f)
