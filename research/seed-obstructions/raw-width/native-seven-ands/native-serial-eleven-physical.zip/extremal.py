exec(open('raw.py').read().split('pairs=0')[0])
import json
mp=json.loads((Path(__file__).parent/'permutations.json').read_text())
def tr(m,perm):
 return sum(perm[x.bit_length()-1] for x in bits(m))
G=[]
for m in mp:
 f=m['point']+[x<<13 for x in m['tag']]
 G.append([1<<P.index(tr(p,f)) for p in P])
def orbit(x):return {tr(x,g) for g in G}
patterns=set()
for k,j in [(8,3),(7,4),(6,5),(5,6)]:
 n=z=0;Yj=sub(Y,j)
 for x in sub(X,k):
    if min(orbit(x))!=x:continue
    st=[g for g in G if tr(x,g)==x]
    hh=set(neg(a)&neg(b) for a,b in combinations_with_replacement(covers(x),2))
    for y in Yj:
        if x&y or min(tr(y,g) for g in st)!=y:continue
        n+=1
        for h in hh:
            dv={neg(a) for a in covers(y|(x&~elig(h)))}
            if any(not (d&v&h) and any(not (d&v&neg(c)) for c in covers(y)) for d,v in combinations_with_replacement(dv,2)):
                patterns.add(min(orbit(x|y)));z+=1;break
 print('split',k,j,'pose pairs',n,'admissible',z,flush=True)
print('delivery poses',len(patterns),flush=True)
for l in sorted(patterns):
 ctr=covers(allP^l);small=[a for a in ctr if a.bit_count()<=6]
 print(l,len(orbit(l)),min(a.bit_count() for a in ctr),len(small),flush=True)
