exec(open('rivals.py').read().split('accepted=set()')[0])
profiles=set()
for line in open('rivals.txt'):
 l,c,d,v,x,z=map(int,line.split())
 assert z.bit_count()>=5 and all(z&~s for s in pa)
 for t in triples:
    if any(z&~pos(a) for a in t):continue
    for a,b,u in permutations(t):
        if a>b or x&~(pos(a)&pos(b)):continue
        hn=neg(a)&neg(b);hp=pos(a)&pos(b)
        if hn&neg(u) or hn&neg(d)&neg(v):continue
        for mode in (1,2):
            kn=(hn|neg(c))&neg(d) if mode==1 else hn|(neg(c)&neg(d))
            kp=(hp|pos(c))&pos(d) if mode==1 else hp|(pos(c)&pos(d))
            if not (hn and kn) or kn&neg(v):continue
            if ((hp&elig(hn))|(kp&elig(kn)))!=l:continue
            profiles.add((l,mode,a,b,c,d))
with open('profiles.txt','w') as f:
 for r in sorted(profiles):print(*r,file=f)
print('actual fixed physical raw arm profiles',len(profiles),Counter(r[1] for r in profiles))
