"""Verify the original chart, derivative child, and four-gate restoration."""
import contextlib,io,json,itertools
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()):
    from reverse import rows,pos,neg,Q,core,sign,subprice
full=(1<<20)-1
roles=list(itertools.product((7,11,12),(7,8,10),(8,9,11),(9,10,12)))
def sig(r,s): return sign(rows[r]&s,3)
for d in (0,2,6,7,8,9,10,11,12):
    s=full;traces=[]
    for v in (1<<d,*Q):
        new=s^v
        positives=[r for r in pos if rows[r]&~s==0]
        live=next(r for r in pos if rows[r]&~new==0)
        assert all(not sig(r,new)&~sig(r,s) for r in range(676))
        assert all(sig(r,new)==sig(r,s) for r in pos if rows[r]&~new==0)
        pair=next((r,n) for r in positives if rows[r]&v for n in neg if not rows[n]&v and not(sig(r,s)&~v&~sig(n,s)))
        traces.append([v,*pair,live])
        s=new
    assert s==core^(1<<d)
    opts=[129,4160]
    hits=[c for c in opts if c&(1<<d)]
    alias=[c^(1<<d) for c in hits]
    keep=[c for c in opts if c not in hits]
    assert all(bool(rows[r]&s&c)==bool(rows[r]&v) for c,v in zip(hits,alias) for r in range(676))
    a=[r for r in pos if not rows[r]&sum(Q) and rows[r]&(1<<d)]
    stars=[rows[r]^(1<<d) for r in a]
    assert len(stars) in (2,3) and all(v.bit_count()==1 for v in stars)
    cover=sum(stars)
    assert all(not(rows[n]&(1<<d) and rows[n]&cover) for n in neg)
    assert all((not rows[r]&(1<<d)) or (rows[r]&cover) for r in pos if not rows[r]&sum(Q))
    floor,_=subprice(1<<d)
    if d in (7,12): assert floor==17
    ids=[j for j,role in enumerate(roles) if role.count(d)==2]
    print('d',d,'stages [raw,positive,negative,surviving positive]',traces,'remaining',sum(not rows[r]&~s for r in pos),'alias',alias,'retained options',keep,'restored tags',stars,'OR floor',floor,'role IDs',ids)
