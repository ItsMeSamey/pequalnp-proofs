import ast,contextlib,io,random,zipfile,hashlib
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()):
    from reverse import rows,pos,neg,core,Q
D=(0,2,6,7,8,9,10,11,12);full=(1<<20)-1
PP=sum(1<<r for r in pos);NN=sum(1<<r for r in neg)
U={d:sum(1<<k for k in range(676) if rows[k]&1<<d) for d in range(20)}
def run(g,s):
    w=[U[j] if s>>j&1 else 0 for j in range(20)];w.extend([w[0]|w[7],w[6]|w[12]])
    o=set();h=set()
    for i,(k,a,b) in enumerate(g,22):
        x,y=w[a],w[b]
        if not x or not y:(h if k else o).add(i)
        w.append(x&y if k else x|y)
    return w[-1],o,h
def validate(g,fl):
    live={21+len(g)}
    for i in range(21+len(g),21,-1):
        assert i in live
        _,a,b=g[i-22];assert max(a,b)<i;live.update([a,b])
    assert all(j not in live or fl>>(j-20)&1 for j in (20,21))
    f,_,_=run(g,full);assert not(PP&~f) and not(f&NN)
    out=[]
    for d in D:
        s=full^1<<d;_,cut,_=run(g,s);z=len(cut)
        for q in Q:
            s^=q;y,nxt,an=run(g,s)
            assert cut<nxt;cut=nxt
        deg=sum(not rows[r]&sum(Q) and bool(rows[r]&(1<<d)) for r in pos)
        M=29 if fl<3 or d in (0,6,7,12) else 28
        assert len(g)>=M+3-deg+z+len(an)
        out.append((z,len(an),len(cut)))
    return out
one=Path('/workspace/scratch/syn_mitm/native-four-star-34.zip')
two=Path('/workspace/scratch/syn_verify/private-joint-control37.zip')
assert hashlib.sha256(two.read_bytes()).hexdigest()=='f0356ba86efa6e38a5cce56c71ff9bf5706978d6eb601d36504b4b2584396acb'
with zipfile.ZipFile(one) as z: raw=z.read('graph34.txt').decode().splitlines()
def addr(i):assert i<20 or i>=38;return i if i<20 else i-16
g34=[(k,addr(a),addr(b)) for k,a,b in [map(int,s.split()) for s in raw]]
with zipfile.ZipFile(two) as z:raw=z.read('control.log').decode().splitlines()[1:]
def ad(i):return i if i<20 else i+2
g37=[(int(k=='AND'),ad(a),ad(b)) for _,(k,a,b) in map(ast.literal_eval,raw)]
for label,g in [('original34',g34),('original37',g37)]:
    for fl in range(4):
        got=validate(g,fl)
        if fl==3:print(label,len(g),got)
rng=random.Random(12308)
for fl in range(4):
    for trial in range(8):
        g=[];astart=list(range(20))
        def op(k,a,b):g.append((k,a,b));return 21+len(g)
        for j,p in enumerate(((0,7),(6,12))):
            if fl>>j&1:
                v=rng.choice(p);astart[v]=op(1,v,20+j)
        def join(xs):
            xs=list(xs);rng.shuffle(xs)
            while len(xs)>1:
                a=xs.pop(rng.randrange(len(xs)));b=xs.pop(rng.randrange(len(xs)))
                xs.append(op(0,a,b))
            return xs[0]
        out=[]
        for t in range(13,20):
            points=[astart[(rows[r]&8191).bit_length()-1] for r in pos if rows[r]>>t&1]
            rng.shuffle(points)
            split=rng.randrange(len(points)) if rng.randrange(3)==0 else 0
            for group in (points[:split],points[split:]):
                if group:out.append(op(1,astart[t],join(group)))
        join(out);validate(g,fl)
print('Both frozen controls and 32 seeded live randomized separators passed all nine cuts; both present optionals occur physically in every randomized rich-bank tape.')
# Tag13 admits the exact three-source substitute on the original rows.
g=[];heads={}
def gate(k,a,b):g.append((k,a,b));return 21+len(g)
for q,d in ((1,7),(3,7),(4,8),(5,9)):heads[q]=gate(0,q,d)
def comb(k,xs):
    x,*zs=xs
    for y in zs:x=gate(k,x,y)
    return x
X=gate(1,heads[1],heads[3])
terminal=[]
for t in range(13,20):
    points=[(rows[r]&8191).bit_length()-1 for r in pos if rows[r]>>t&1]
    q=next((q for q in heads if q in points),None)
    if q is not None:
        d={1:7,3:7,4:8,5:9}[q]
        points.remove(q);points.remove(d)
        if d==7:terminal.append(gate(1,heads[q],t))
        else:points.append(heads[q])
    if t==13:
        points.remove(7);others=comb(0,points)
        points=[gate(1,gate(0,others,X),gate(0,others,20))]
    terminal.append(gate(1,t,comb(0,points)))
comb(0,terminal)
for fl in (1,3):
    got=validate(g,fl)
    print('mixed',len(g),'OR',sum(not k for k,_,_ in g),'AND',sum(k for k,_,_ in g),'z,m,total OR cuts for d7',got[D.index(7)])
