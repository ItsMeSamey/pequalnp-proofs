from itertools import combinations
from collections import Counter
from native import edges,rows
T=[(p,t<<13) for p,t in sorted(edges)]
N=sorted(set(p|t<<13 for p,t,y in rows if y<0))
A=[1<<j for j in range(20)]
bins=[sum(1<<j for j,n in enumerate(N) if n&a) for a in A]
def span(v):
 r=(1<<len(N))-1
 while v:
  a=v&-v;v-=a;r&=bins[a.bit_length()-1]
 return r
from functools import lru_cache
@lru_cache(None)
def ext(m):return span(m)
def rect(m):
 must=[(a,b) for a,b in T if ext(m|a) and ext(m|b)]
 def pairfail(e,f):
  a,b=e;c,d=f
  return bool((ext(m|a|d) or ext(m|b|c)) and (ext(m|a|c) or ext(m|b|d)))
 adj=[sum(1<<j for j,f in enumerate(must) if pairfail(e,f)) for e in must]
 best=[]
 def visit(rest,path):
  nonlocal best
  if len(path)>len(best):best=path
  while rest.bit_count()+len(path)>len(best):
   i=rest&-rest;rest-=i;j=i.bit_length()-1
   visit(rest&adj[j],path+[j])
 visit((1<<len(must))-1,[])
 return [must[i] for i in best]
if __name__=='__main__':
 rs={m:rect(m) for m in A+[a|b for a,b in combinations(A,2)] if ext(m)}
 print(Counter(map(len,rs.values())))
 for j in range(1,5):
  print('exactly',j,[m for m,r in rs.items() if len(r)==j])
from pathlib import Path
import re
from native import rows
assert Counter(y for p,t,y in rows) == {-1:624,0:24,1:28}
assert len(T)==28 and len(N)==468 and len(rs)==182
def incompatible(x,y):
 return any(not ((a|b)&~(x|y)) for a,b in T)
tab=Path(__file__).with_name('NativeTable.lean').read_text()
seed=tab.split('def badRows :')[1].split('def bad (')[0]
raw69=[(int(i),int(mask))for i,mask in re.findall(r'\((\d+),(\d+)\)',seed)]
assert len(raw69)==69
for i,m in raw69:
 p,t,sgn=rows[i];assert sgn<0 and m==p|t<<13
assert all(incompatible(x,y) for (_,x),(_,y) in combinations(raw69,2))
adj=[sum(1<<j for j,n in enumerate(N) if incompatible(m,n)) for m in N]
for m in rs:
 eligible=ext(m);chosen=[]
 while eligible and len(chosen)<4:
  inds=[j for j in range(len(N)) if eligible>>j&1]
  k=max(inds,key=lambda j:(eligible&adj[j]).bit_count())
  chosen.append(N[k]);eligible &= adj[k]
 assert len(chosen)==4 and all(m&~n==0 for n in chosen)
 assert all(incompatible(x,y) for x,y in combinations(chosen,2))
 for a,b in rs[m]:assert ext(m|a) and ext(m|b)
 for (a,b),(c,d) in combinations(rs[m],2):
  assert (ext(m|a|d) or ext(m|b|c)) and (ext(m|a|c) or ext(m|b|d))
reg3=[128,256,512,1024,2048,4096]
weak={m for m,cert in rs.items() if len(cert)<=2}
assert weak=={a|b for a,b in combinations(reg3,2)}|{129,513,1028,2052,320,4160}
assert min(len(rs[a]) for a in A)==4
private=(2,4,8,32)
q={t:next(p for p,s in edges if s==t and sum(a==p for a,j in edges)==1)for t in private}
trans=[]
for U in combinations(private,2):
 m=sum(q[t]for t in U) | sum(t<<13 for t in private if t not in U)
 i=next(i for i,(p,t,y)in enumerate(rows)if y<0 and not m&~(p|t<<13))
 trans.append(m)
 print('matched-point owners',U,'transversal',m,'original negative index',i,'row',rows[i])
assert all(any(not (p|t<<13)&~(m|n) for t,p in q.items())for m,n in combinations(trans,2))
print('69-clique, all 182 four-cliques, raw incompatibilities and six private transversal witnesses checked.')
