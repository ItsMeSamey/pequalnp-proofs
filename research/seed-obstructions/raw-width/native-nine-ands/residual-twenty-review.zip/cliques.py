from sample import samples
from pathlib import Path
from itertools import combinations,product
import json
R,F,T=samples(Path('L-meta-18968.json'))
mask=(((1<<20)-1)^58)|(1<<29)|(1<<30)
P={x&mask for i,x in enumerate(R) if (T&~F)>>i&1 and not x&58}
roles=json.loads(Path('residual-witness.json').read_text())
names=list(product((7,11,12),(7,8,10),(8,9,11),(9,10,12)))
pairs=0
for (rs,skip,ids,hi),rr in zip(roles,names,strict=True):
    assert tuple(rs)==rr and len(set(ids))==33
    assert set(skip)=={1<<p|t for p,t in zip(rr,(262144,16384,32768,65536))}
    E={x for x in P if x&1048575 not in skip}
    assert len(E)==20 and all(not T>>i&1 for i in ids)
    for a,b in combinations(ids,2):
        assert any(not e&~(R[a]|R[b]) for e in E)
        pairs+=1
print('Independent original native 676 source,',len(roles),'roles,',pairs,'pairwise union witnesses.')
