"""An independent signed DAG replay from the original decimal seeds."""
import contextlib,io,itertools,functools,collections,gzip,json
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()):
    from reverse import rows,pos,neg,core,Q,tags,sign
from functools import cache
def held(P,N,T):
    def indices(s):
        return [i for i,x in enumerate(P) if not s&~x]
    def blocked(x):
        return sum(1<<j for j,y in enumerate(N) if not x&~y)
    parts={0}
    for x in P:
        parts.update(bits(x&T))
        if not (x&65535)&~T:
            parts.add(x&65535)
    D=[blocked(x&~T) for x in P]
    if not any(D):return ('none',)
    for a,b in itertools.combinations(parts,2):
        if a&b:continue
        ds=[blocked(x&~(a|b)) for x in P]
        need={i for i,d in enumerate(ds) if d}
        bad=functools.reduce(int.__or__,ds,0)
        def admissible(v):
            no=blocked(v)&bad
            return {i for i in indices(v) if not D[i]&no}
        A,B=admissible(a),admissible(b)
        for i in A:
            for j in B-{i}:
                AA={k for k in A if a&~P[j] or (P[k]&~T)&~P[j]}
                BB={k for k in B if b&~P[i] or (P[k]&~T)&~P[i]}
                if i in AA and j in BB and need<=AA|BB:return ('pair',)
    return ('blocked',)
A=[1<<i for i in range(20) if core>>i&1]
key=lambda x:sum(1<<i for i,a in enumerate(A) if a&x)
C=[key(x) for x in (129,4160)]; E=sorted({rows[r] for r in pos if not rows[r]&sum(Q)}); ee=list(map(key,E))
N=sorted({key(rows[r]) for r in neg})
def obs(s,x):
    return (x&s)|sum(1<<(16+j) for j,c in enumerate(C) if c&s==c and x&c)
def bits(x):
    while x:
        q=x&-x;yield q;x^=q
root,path=json.loads(gzip.decompress(Path('residual-prices.json.gz').read_bytes()));D={(s,k):(l,v,w) for s,k,l,v,w in path}
assert len(D)==len(path)
@functools.lru_cache(None)
def nn(s):
    # Maximal signatures suffice for grant tests; ordinary signed witnesses may use any negative.
    xs=set(obs(s,n) for n in N);out=[]
    for a in sorted(xs,key=int.bit_count,reverse=True):
        if not any(not a&~b for b in out):out.append(a)
    return out
cnt=collections.Counter()
for (s,k),(L,typ,w) in sorted(D.items()):
    es=[x for i,x in enumerate(ee) if k>>i&1];assert all(x&~s==0 for x in es)
    def child(q):
        assert q&s==q and q.bit_count()==1
        j=sum(1<<i for i,x in enumerate(ee) if k>>i&1 and not x&q)
        return D[s^q,j][0]
    if typ==-100:
        assert L==0;cnt['zero']+=1;continue
    if typ==-1:
        assert w and w&s==w and all(child(q)>=L-2 and any(not x&q for x in es) for q in bits(w))
        p=[obs(s,x) for x in es]
        assert held(p,nn(s),w)[0]=='blocked',(s,k,w)
        cnt['held']+=1;continue
    assert 0<=typ<32 and w==1<<(typ%16)
    assert L<=child(w)+(typ>=16)
    if typ>=16:
        assert any(not x&w for x in es)
        assert any(not(obs(s,p)&~w&~obs(s,n)) for p in es if p&w for n in N)
    cnt['marked' if typ>=16 else 'plain']+=1
choices=list(itertools.product((7,11,12),(7,8,10),(8,9,11),(9,10,12)))
a=json.loads(Path('residual-witness.json').read_text());counts=collections.Counter()
for i,k,L in root:
    role,skip,cl,hi=a[i]
    assert tuple(role)==choices[i]
    assert set(skip)=={(1<<r)|tags[q] for r,q in zip(role,Q)}
    rr=[e for e in E if e not in skip]
    assert k==sum(1<<j for j,e in enumerate(E) if e in rr) and D[65535,k][0]==L
    assert len(set(cl))>=33 and all(n in neg for n in cl)
    for x,y in itertools.combinations(cl,2):
        assert any(not sign(e,3)&~(sign(rows[x]&core,3)|sign(rows[y]&core,3)) for e in rr)
    counts[L]+=1
assert [r[0] for r in root]==list(range(81))
print('Signed proof nodes',len(D),dict(cnt),'root OR floors',dict(counts),'all 81 AND floors at least six.')
