import json
import re
from pathlib import Path

src = json.loads(Path(__file__).with_name('L-meta-18968.json').read_text())['formal_statement']
seeds = [int(''.join(v.zfill(19) for v in re.findall(r'\((\d+) : ℕ\)',block))) for block in re.findall(r'\[([^]]+)\]',src)]
fields = {int(i):int(v) for i,v in re.findall(r'x1 \((\d+) : ℕ\) = \((\d+) : ℕ\)',src)}
def rotate(i,seed,offset,length):
    return sum(((seed>>(i-i%13+(i-j-offset)%13))&1)<<j for j in range(length))
rows = [(rotate(i,seeds[0],0,13),rotate(i,seeds[1],6,7),1 if (fields[88]&~fields[54])>>i&1 else -1 if not fields[88]>>i&1 else 0) for i in range(676)]
edges = {(p,t) for p,t,y in rows if y==1}
