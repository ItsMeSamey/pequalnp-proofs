"""Original indexed witness replay and independent binary all-star/single-dirty control."""
import json
from itertools import combinations
from pathlib import Path
from collections import Counter
from native import edges,rows

SITES=(0,7,17,115)
BANK={0:(),7:(129,),17:(4160,),115:(129,4160)}
T=tuple(1<<i for i in range(7))
A=tuple(1<<i for i in range(20))
P=A[:13]
positive={p|t<<13 for p,t in edges}
assert Counter(y for p,t,y in rows)=={-1:624,0:24,1:28}
U={t:sum(p for p,v in edges if t==v) for t in T}
deg={p:sum(bool(s&p)for s in U.values()) for p in P}
owner={p:next(t for t in T if U[t]&p) for p in P if deg[p]==1}
ordinary=set(T)-set(owner.values())
def native_audit():
    expected={sum(c):3 for k in (1,2) for c in combinations(A,k) if sum(c) not in positive}
    assert len(expected)==182
    expected.update({p:(1<<(6-deg[p]))+3 for p in P})
    expected.update({p|t<<13:19 for t in ordinary for p in owner})
    triples={t<<13|a|b:(p,t,a,b) for p,t in owner.items()
             for a,b in combinations(sorted(set(owner)-{p}),2)}
    assert len(triples)==12
    expected.update(dict.fromkeys(triples,11))
    entries=json.loads(Path(__file__).with_name('indexed-cliques.json').read_text())
    assert len(entries)==len(expected)==194
    certs={}
    for pin,indices in entries:
        assert pin not in certs and len(indices)==len(set(indices))==expected[pin]
        masks=[]
        for i in indices:
            assert 0<=i<676
            p,t,sign=rows[i]
            assert sign==-1
            n=p|t<<13
            assert not pin&~n and not any(not e&~n for e in positive)
            masks.append(n)
        assert len(set(masks))==len(indices)
        forbidden=0
        for e in positive:
            if e&pin:forbidden|=e&~pin
        assert not forbidden&pin and all(not n&forbidden for n in masks)
        residual={e for e in positive if not e&(pin|forbidden)}
        for n,m in combinations(masks,2):
            assert any(not e&~(n|m) for e in residual)
        certs[pin]=indices
    assert certs.keys()==expected.keys()
    for p,t in owner.items():
        for extra in set(T)-{t}:
            # The three non-private indices name the other sites arbitrarily.
            other=next((a,b) for a,b in combinations(sorted(set(owner)-{p}),2)
                       if extra not in (owner[a],owner[b]))
            a,b=other;pin=t<<13|a|b
            assert len({t,extra,owner[a],owner[b]})==4 and len(certs[pin])==11
    print('194 obligations pass on residual incidences; 12 triples x 55 incompatible genuine-negative pairs')
    return triples,certs

def build(bank):
    m=20+len(BANK[bank]);net=[]
    def gate(op,a,b):
        net.append((op,a,b));return m+len(net)-1
    def disj(ws):
        start,*rest=ws
        for w in rest:start=gate('or',start,w)
        return start
    columns={}
    for t in T:
        petals=disj([p.bit_length()-1 for p in P if p&U[t]])
        columns[t]=gate('and',13+t.bit_length()-1,petals)
    x=disj(list(columns.values()))
    one_point=disj(range(13))
    one_tag=disj(range(13,20))
    y=gate('and',one_point,one_tag)
    out=gate('and',x,y)
    return net,columns,x,y,out

def physical(bank,triples,certs):
    m=20+len(BANK[bank]);net,columns,x,y,out=build(bank)
    assert len(net)==54 and Counter(op for op,a,b in net)=={'and':9,'or':45}
    def run(p,t):
        w=[bool(p&(1<<i)) for i in range(13)]+[bool(t&v) for v in T]
        w.extend(bool(p&v)for v in BANK[bank]);sockets={}
        for i,(op,a,b) in enumerate(net,m):
            assert a<i and b<i
            aa,bb=w[a],w[b]
            if op=='and':sockets[i]=(aa,bb)
            w.append(aa and bb if op=='and' else aa or bb)
        return w,sockets
    live={out}
    for i in reversed(range(len(net))):
        if i+m in live:live.update(w for w in net[i][1:] if w>=m)
    assert live==set(range(m,m+54))
    dirty=set();y_witness=[]
    for i,(p,t,sgn) in enumerate(rows):
        w,g=run(p,t)
        exact=any(p&U[v] and t&v for v in T)
        assert w[x]==w[out]==exact and w[y]==bool(p and t)
        if sgn:assert w[out]==(sgn>0)
        if sgn<0:
            dirty.update(k for k,pair in g.items() if all(pair))
            if w[y]:y_witness.append(i)
    assert dirty=={y} and y_witness
    # Check marks on both physical operands of each of the seven X gates.
    for u in T:
        w,g=run(0,u)
        assert {t for t,k in columns.items() if any(g[k])}=={u}
        assert all(g[k]==(u==t,False) for t,k in columns.items())
    for p in P:
        w,g=run(p,0)
        assert {t for t,k in columns.items() if any(g[k])}=={t for t in T if p&U[t]}
        assert all(g[k]==(False,bool(U[t]&p)) for t,k in columns.items())
    for pin,(p,t,a,b) in triples.items():
        w,g=run(pin&8191,pin>>13)
        assert {v for v,k in columns.items() if any(g[k])}=={t,owner[a],owner[b]}
        for idx in certs[pin]:
            w,g=run(*rows[idx][:2])
            assert w[y] and not w[x] and not w[out]
    print('bank',bank,'54 live sites (9 AND, 45 OR); 676 row outputs exact; sole dirty Y signed indices',len(y_witness),'first',y_witness[0],
          'matched column AND sites',[v-m for v in columns.values()],'Y',y-m,'root',out-m)
if __name__=='__main__':
    tr,cl=native_audit()
    for bank in SITES:physical(bank,tr,cl)
