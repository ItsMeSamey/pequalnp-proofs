"""Reverse private-head restrictions from the original 676 labelled rows."""
from pathlib import Path
from itertools import combinations, product
from functools import lru_cache
from collections import Counter
import hashlib, json, re, zipfile, sys
src=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/scratch/syn_quotients/native-all-four-or23-protected.zip')
assert hashlib.sha256(src.read_bytes()).hexdigest()=='c418ea0621b46c9cb58926680b55e0d9effeb060647cc3cce68f3d279de17db5'
with zipfile.ZipFile(src) as z:
    statement=json.loads(z.read('L-meta-18968.json'))['formal_statement']
    ledger=json.loads(z.read('partial-ledger.json'))
assert hashlib.sha256(statement.encode()).hexdigest()=='d5fbefe3ea85033034056aae8ed0b90ecfe428b8a69e3456176309d0c82b54c2'
blocks=re.findall(r'\[((?:\(\d+ : ℕ\)(?:, )?)+)\]',statement)
seed=[sum(v*10**(19*k) for k,v in enumerate(reversed([int(t) for t in re.findall(r'\((\d+) : ℕ\)',b)]))) for b in blocks]
rows=[sum((seed[j>=13]>>(13*(r//13)+(r%13-(j if j<13 else j-7))%13)&1)<<j for j in range(20)) for r in range(676)]
front,target=[int(re.search(r'x1 \('+str(i)+r' : ℕ\) = \((\d+) : ℕ\)',statement)[1]) for i in (54,88)]
pos=[i for i in range(676) if (target&~front)>>i&1];neg=[i for i in range(676) if not target>>i&1]
Q=[2,8,16,32];core=(1<<20)-1-sum(Q)
tags={q:next(rows[x] for x in pos if rows[x]&q)^q for q in Q}
assert [tags[q] for q in Q]==[262144,16384,32768,65536]
assert all(sum(bool(rows[x]&q) for x in pos)==1 for q in Q)
def sign(x,flags):
    return x|sum(1<<(20+j) for j,c in enumerate((129,4160)) if flags>>j&1 and x&c)
# All physical charts below use actual projected compounds or their exact aliases.
floors={v[0]:v[1] for v in ledger}
@lru_cache(None)
def subprice(ds):
    y=core&~ds
    return max((L,u) for u,L in floors.items() if u&~y==0)
@lru_cache(None)
def compare(flags,donor,qgroup):
    # Bare (p,incident tag) positive versus dirty negative with all marked heads high.
    a=1<<donor
    for x in pos:
        if not rows[x]&a:continue
        for n in neg:
            if rows[n]&a or rows[n]&qgroup!=qgroup:continue
            if sign(rows[x],flags)&~a&~sign(rows[n],flags)==0:return [x,n]
    return None
def best(heads,flags):
    score=(0,0,0,0,0); proof={}
    names=list(dict.fromkeys(heads))
    for size in range(1,len(names)+1):
        for group in combinations(names,size):
            ds=sum(1<<p for p in group)
            W=sum(j in group for j in heads)
            witnesses={p:compare(flags,p,sum(q for q,j in zip(Q,heads) if j==p)) for p in group}
            O,u=subprice(ds)
            E=sum(w is not None for w in witnesses.values())
            s=(4+W+E+O, W,E,O,u)
            if s>score:
                score=s
                proof={'D':list(group),'witnesses':witnesses,'child_support':u,'child_floor':O,'heads':W,'extra':E}
    return score[0],proof
all_results=[]
for flags in range(4):
    P=[sign(rows[i],flags) for i in pos];N=[sign(rows[i],flags) for i in neg]
    for q,t in tags.items():
        # The four private deletions after D have signed witnesses on any retained tags.
        assert any(not rows[n]&q and rows[n]&t for n in neg)
    assert any(not rows[p]&(sum(Q)|sum(1<<i for i in range(7,13))) for p in pos)
    # If B is raw, B must reject every q-low negative with the q-incident tag high.
    allowed=[]
    for q,t in tags.items():
        forbidden=[n for n in N if n&t and not n&q]
        possible=[a for a in range(22) if a<20 or flags>>(a-20)&1]
        allowed.append([a for a in possible if 1<<a!=q and all(not n>>a&1 for n in forbidden)])
    assert allowed==[[7,11,12],[7,8,10],[8,9,11],[9,10,12]]
    records=[]
    for heads in product(*allowed):
        score,proof=best(heads,flags)
        records.append([heads,score,proof])
    counts=Counter(row[1] for row in records)
    print('flags',flags,'scores',sorted(counts.items()),'excluded O23',sum(c for k,c in counts.items() if k>23),'O24',sum(c for k,c in counts.items() if k>24))
    all_results.append(records)
Path('reverse-ledger.json').write_text(json.dumps(all_results,separators=(',',':'))+'\n')
print('example ≥25:',next(x for x in all_results[3] if x[1]>=25))
