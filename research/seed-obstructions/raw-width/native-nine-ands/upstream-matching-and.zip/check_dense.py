"""Read fixed certificates. No clique search, DAG search or solver."""
import io,contextlib,json,itertools
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()):
    from reverse import rows,pos,neg,Q,tags,core,sign
a=json.loads(Path('dense-witness.json').read_text())
seen=set()
for h,n in enumerate(a['match']):
    r=sum(q if h>>i&1 else tags[q] for i,q in enumerate(Q))
    assert n in neg and not r&~rows[n] and n not in seen
    seen.add(n)
verts={1,4,64,*tags.values()};check=0
for flags in range(4):
    bank=lambda x:sign(x&core,flags)
    for z in a['roles']:
        E=z['positive_masks']; T=sum(tags[q] for q in z['heads'])
        assert len(E)==len(set(E)) and set(E)<={rows[r] for r in pos if not rows[r]&sum(Q)}
        for v,X in z['cliques'].items():
            v=int(v)
            assert len(set(X))>= (17 if z['upstream']==7 else 33)
            assert all(n in neg and rows[n]&T and (not v or rows[n]&v) for n in X)
            for n,m in itertools.combinations(X,2):
                assert any(not bank(p|v)&~(bank(rows[n])|bank(rows[m])) for p in E)
                check+=1
        if z['upstream']==7:
            assert {int(v) for v in z['cliques']}==verts
            assert {frozenset(c[:2]) for c in z['cross']}=={frozenset(c) for c in itertools.combinations(verts,2)}
        for x,y,b,c,D in z['cross']:
            assert b|x in E and c|y in E and b&x==c&y==0 and b!=y and c!=x
            for obs,n in zip([b|y,c|x,b|c,x,y,b,c],D,strict=True):
                assert n in neg and rows[n]&T and not bank(obs)&~bank(rows[n])
print('All 16 matching observations, 21 pivot conflicts, and',check,'high/global clique pair comparisons verified against the 676 original rows and four physical banks.')
