import contextlib,io,itertools,json
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()):
    from reverse import rows,pos,neg,sign,Q,tags,core
E=sorted(rows[i] for i in pos if not rows[i]&sum(Q))
assert len(E)==24
vertices=(1,4,64,*map(tags.get,Q))
bank=lambda x:sign(x&core,3)
def clique_generator(F,v):
    by={bank(rows[n]):n for n in F if not v or rows[n]&v}
    ns=sorted(w for w in by if all(w==x or w&~x for x in by))
    pp=[bank(e|v) for e in E]
    c=[[sum(1<<i for i,p in enumerate(pp) if not p&~(y|z)) for z in ns] for y in ns]
    def choose(mask,goal):
        a=[sum(1<<j for j,m in enumerate(row) if j!=i and m&mask) for i,row in enumerate(c)]
        u=(1<<len(a))-1; chosen=[]
        while u and len(chosen)<goal:
            i=max((j for j in range(len(a)) if u>>j&1),key=lambda j:(u&a[j]).bit_count())
            chosen.append(by[ns[i]]);u&=a[i]
        return chosen if len(chosen)>=goal else None
    return choose
def make(J,size):
    T=sum(tags[q] for q in J);F=[n for n in neg if rows[n]&T]
    V=vertices if size==7 else [0]
    tables={v:clique_generator(F,v) for v in V}
    def dom(k):return next((n for n in F if not bank(k)&~bank(rows[n])),None)
    def cross(mask,x,y):
        es=[p for i,p in enumerate(E) if mask>>i&1]
        hx=[p^x for p in es if p&x]; hy=[p^y for p in es if p&y]
        for a,b in itertools.product(hx,hy):
            if a==y or b==x:continue
            downs=[dom(k) for k in [a|y,b|x,a|b,x,y,a,b]]
            if None not in downs:return [a,b,downs]
    def cert(mask):
        cl={v:t(mask,17 if size==7 else 33) for v,t in tables.items()}
        if None in cl.values():return None
        pairs=[]
        if size==7:
            for x,y in itertools.combinations(vertices,2):
                z=cross(mask,x,y)
                if z is None:return None
                pairs.append([x,y,*z])
        return [cl,pairs]
    best=None
    for order in [range(24),reversed(range(24))]:
        m=2**24-1;c=cert(m)
        if c is None:return None
        for i in order:
            n=m^(1<<i);b=cert(n)
            if b is not None:m,c=n,b
        if best is None or m.bit_count()<best[0].bit_count():best=m,c
    m,c=best
    return {'heads':J,'upstream':size,'positive_masks':[e for i,e in enumerate(E) if m>>i&1],'cliques':c[0],'cross':c[1]}
def matching():
    ret=[]
    for i in range(16):
        x=sum(q if i>>j&1 else tags[q] for j,q in enumerate(Q))
        n=next(j for j in neg if not x&~rows[j])
        ret.append(n)
    return ret
if __name__=='__main__':
    out=[]
    for J in itertools.chain(itertools.combinations(Q,3),[Q]):
        e=make(J,6)
        if e:out.append(e)
    out.append(make(Q,7))
    print('16 original maximal matching rows',matching())
    for e in out:print('heads',e['heads'],'upstream',e['upstream'],'required incidences',len(e['positive_masks']),e['positive_masks'])
    Path('dense-witness.json').write_text(json.dumps({'match':matching(),'roles':out},separators=(',',':'))+'\n')
