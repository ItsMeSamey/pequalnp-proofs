"""Standalone original-row verifier for all witness obligations; no MIS or cover computation."""
from itertools import combinations
from pathlib import Path
import json
from nativecontrol import rows,edges

positive={p|(t<<13) for p,t in edges}
assert len(positive)==28
atoms=tuple(1<<i for i in range(20))
points=atoms[:13]
tags=atoms[13:]
degrees={p:sum(bool(e&p) for e in positive) for p in points}
private=[p for p in points if degrees[p]==1]
own={p:next(e^p for e in positive if e&p) for p in private}
ordinary=set(tags)-set(own.values())
assert len(private)==4 and len(ordinary)==3
expected={sum(c):3 for k in (1,2) for c in combinations(atoms,k) if sum(c) not in positive}
assert len(expected)==182
expected.update({p:(1<<(6-degrees[p]))+3 for p in points})
expected.update({p|t:19 for p in private for t in ordinary})
expected.update({own[p]|a|b:11 for p in private for a,b in combinations([x for x in private if x!=p],2)})
entries=json.loads(Path(__file__).with_name('indexed-cliques.json').read_text())
assert len(entries)==len(expected)==194 and {p for p,w in entries}==set(expected)
for pin,indices in entries:
    assert len(indices)==len(set(indices))==expected[pin] and all(0<=i<676 for i in indices)
    masks=[]
    for i in indices:
        p,t,y=rows[i]
        n=p|(t<<13)
        assert y==-1 and n&pin==pin
        masks.append(n)
    assert len(set(masks))==len(masks)
    for a,b in combinations(masks,2):assert any((a|b)&e==e for e in positive)
print('194 indexed clique obligations on the 676 original rows; signs, pins and every pair union verified')
print('182 bare singleton/nonedge pins, 13 degree caps, 12 ordinary/foreign rank-five pins and 12 private anchored triple pins')
print('private triples have 11 pairwise incompatible true negatives each; each retains at least 9 against two guard clauses')
