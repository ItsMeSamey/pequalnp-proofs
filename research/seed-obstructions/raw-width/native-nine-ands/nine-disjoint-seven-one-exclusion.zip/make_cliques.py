"""Development only: pick masks, then emit their original row indices."""
from itertools import combinations
from pathlib import Path
import json
from multi import MAX
from covers import E,classes,degree,owner,points,private,tags
from nativecontrol import rows

def make():
    idx={p|(t<<13):i for i,(p,t,y) in enumerate(rows) if y<0}
    atoms=points+tags;required={}
    for k in (1,2):
        for parts in combinations(atoms,k):
            n=sum(parts)
            if n not in E:required[n]=3
    for p,d in degree.items():required[p]=(1<<(6-d))+3
    for t in set(tags)-set(owner.values()):
        for p in private:required[p|t]=19
    for p in private:
        for a,b in combinations(set(private)-{p},2):required[owner[p]|a|b]=11
    result=[]
    for n,target in sorted(required.items()):
        w=classes(n,MAX)
        assert len(w)>=target
        witnesses=sorted(idx[MAX[(mask&-mask).bit_length()-1]] for mask in w.values())[:target]
        result.append([n,witnesses])
    Path('indexed-cliques.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
if __name__=='__main__':make()
