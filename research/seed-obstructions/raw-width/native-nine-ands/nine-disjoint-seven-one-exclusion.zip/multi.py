"""Native cofactor hot-site caps on independent sets of private inputs and ordinary tags."""
import itertools
import json
import sys
from functools import lru_cache
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'nine-disjoint-seven-covers'))
from covers import MAX,classes,private,owner,tags

ORD=tuple(t for t in tags if t not in set(owner.values()))
ALL_SITES=127
TUPLES=list(itertools.product(*[(None,*(g for g in range(7) if g!=i)) for i in range(4)]))
FULL=(1<<len(TUPLES))-1
ONE_ENTRY=[sum(1<<n for n,g in enumerate(TUPLES) if g[i] is None) for i in range(4)]
EXCLUSIVE_SAFE=sum(1<<n for n,g in enumerate(TUPLES)
                   if all(l is None or l>=4 or g[l] is not None for l in g))
ASSIGNED={0:[0]*len(TUPLES)}
for mask in range(1,16):
    bit=mask&-mask
    i=bit.bit_length()-1
    ASSIGNED[mask]=[(a|bit|(0 if g[i] is None else 1<<g[i]))
                    for a,g in zip(ASSIGNED[mask^bit],TUPLES)]

@lru_cache(maxsize=None)
def allowed(mask,anchors,cap):
    if (mask|anchors).bit_count()>cap:return 0
    if (mask|anchors).bit_count()+mask.bit_count()<=cap or cap==7:return FULL
    return sum(1<<n for n,a in enumerate(ASSIGNED[mask]) if (a|anchors).bit_count()<=cap)

def probes():
    pins=[]
    for choices in itertools.product((0,1,2),repeat=4):
        ts=sum(1<<i for i,x in enumerate(choices) if x==2)
        if ts==0:continue
        anchor=sum(1<<i for i,x in enumerate(choices) if x==1)
        q=sum(owner[private[i]] if x==2 else private[i] if x==1 else 0 for i,x in enumerate(choices))
        for ot in range(8):
            n=q|sum(t for i,t in enumerate(ORD) if ot>>i&1)
            floor=classes(n,MAX)
            pins.append((ts,anchor|(ot<<4),n,tuple(floor.values())))
    assert len(pins)==520 and sum(t.bit_count()==1 for t,a,n,ss in pins)==256
    return pins

def guaranteed(bits):
    return sum(1<<i for i in range(4) if bits and bits&~ONE_ENTRY[i]==0)

def prepare():
    base=Path(__file__).resolve().parent.parent/'nine-disjoint-seven-covers'
    data=json.loads((base/'cover-rows.json').read_text())
    rows={(r['i'],r['j']):r for r in data['rows']}
    hit=[sum(1<<i for i,n in enumerate(MAX) if n&c) for c in data['covers']]
    pins=probes()
    ret=[]
    for (i,j),size in data['orbits']:
        r=rows[i,j];eligible=hit[i]&hit[j]
        base_bits=FULL
        for k,p in enumerate(private):
            if r['bootstrap']&owner[p]:base_bits&=ONE_ENTRY[k]
        solo,joint=base_bits,base_bits
        for ts,anchor,n,witnesses in pins:
            c=sum(bool(s&eligible) for s in witnesses)
            cap=7-(max(c,1)-1).bit_length()
            valid=allowed(ts,anchor,cap)
            joint&=valid
            if ts.bit_count()==1:solo&=valid
        final=joint&EXCLUSIVE_SAFE
        out=dict(i=i,j=j,size=size,original=base_bits.bit_count(),
                 single_tag=solo.bit_count(),joint_raw=joint.bit_count(),joint_exclusive=final.bit_count(),
                 single_uniques=guaranteed(solo),joint_uniques=guaranteed(joint),final_uniques=guaranteed(final),
                 survivor_bits=hex(final),single_bits=hex(solo),joint_bits=hex(joint))
        ret.append(out)
    return ret

def main():
    output=prepare()
    Path('multipin-orbits.json').write_text(json.dumps(output,separators=(',',':'))+'\n')
    for field in ('original','single_tag','joint_raw','joint_exclusive'):
        hist=Counter()
        for row in output:
            val=row[field]
            hist['impossible' if val==0 else 'unique' if val==1 else 'multiple']+=row['size']
        # The all-own tuple has index zero; whenever live, it forces a clean cone.
        closed=sum(r['size'] for r in output if (int(r[{'single_tag':'single_bits','joint_raw':'joint_bits','joint_exclusive':'survivor_bits'}.get(field,'survivor_bits')],16) & ~1)==0) if field!='original' else 1029
        print(field,dict(hist),'all possible footprints force contradiction, labeled',closed)
    result=[r for r in output if int(r['survivor_bits'],16)&~1]
    print('remaining labeled pairs',sum(r['size'] for r in result),'signed orbits',len(result))

if __name__=='__main__':main()
