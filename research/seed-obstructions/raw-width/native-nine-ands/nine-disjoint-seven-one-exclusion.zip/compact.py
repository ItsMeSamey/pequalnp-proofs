"""Find a single pin per putative second site whenever the uniform two-clause loss suffices."""
from multi import MAX
from covers import E
from multi import probes
from itertools import combinations
import json
from pathlib import Path

def search():
    out=[]
    for i in range(4):
        for other in range(7):
            if other==i:continue
            candidates=[]
            for ts,anch,n,ws in slice_pins:
                if ts!=1<<i:continue
                hot=(anch|ts|(1<<other)).bit_count()
                need=(1<<(7-hot))+3 # after the loss of 2 still greater than 2^(7-hot)
                if len(ws)<need:continue
                ids=sorted((m&-m).bit_length()-1 for m in ws)[:need]
                residual=[e for e in E if not e&n and not any(e&f&~n for f in E if f&n)]
                for a,b in combinations(ids,2):assert any(e&(MAX[a]|MAX[b])==e for e in residual)
                candidates.append((need,n,anch,hot,ids))
            if candidates:
                k,n,anch,hot,ids=min(candidates,key=lambda r:(r[0],r[1].bit_count(),r[1]))
                out.append(dict(i=i,other=other,pin=n,anchors=anch,hot=hot,need=k,negatives=[MAX[a] for a in ids]))
    print(len(out),'of 24 private-owner/foreign-site possibilities have a cover-independent certificate')
    for r in out:print(r['i'],r['other'],r['pin'],r['hot'],r['need'])
    Path('compact.json').write_text(json.dumps(out,separators=(',',':'))+'\n')

if __name__=='__main__':
    slice_pins=probes()
    search()
