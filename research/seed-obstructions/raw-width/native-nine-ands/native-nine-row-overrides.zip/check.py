from nativecontrol import rows, edges

def check(circuit, mask, test_replacements=False):
    def evaluate(force=None, substitute=None):
        vals = [bool(mask & 1<<i) for i in range(20)]
        for g,(op,a,b) in enumerate(circuit,20):
            value = vals[a] and vals[b] if op=='and' else vals[a] or vals[b]
            if force and force[0]==g:
                value=force[1]
            if substitute and substitute[0]==g:
                value=vals[substitute[1]]
            vals.append(value)
        return vals
    vals=evaluate()
    bits=[0]*20
    for g,(op,a,b) in enumerate(circuit,20):
        active=[bits[w] for w in (a,b) if vals[w]==vals[g]]
        mask0=active[0]
        for other in active[1:]:
            if (op=='and')==vals[g]:
                mask0 |= other
            else:
                mask0 &= other
        if op=='and':
            mask0 |= 1<<g
        bits.append(mask0)
    for g,(op,a,b) in enumerate(circuit,20):
        if op!='and':
            continue
        actual=evaluate(force=(g,not vals[g]))
        assert all(bool(bits[w] & 1<<g)==(actual[w]!=vals[w]) for w in range(len(bits)))
        if test_replacements:
            for w in range(g):
                pred=bool(bits[-1] & 1<<g) and vals[w]!=vals[g]
                assert pred==(evaluate(substitute=(g,w))[-1]!=vals[-1])
    return vals[-1]

def stars():
    circuit=[]
    def new(op,a,b):
        circuit.append((op,a,b))
        return len(circuit)+19
    def union(wires):
        first,*rest=wires
        for w in rest:
            first=new('or',first,w)
        return first
    products=[]
    for j in range(7):
        petal=union(sorted(p.bit_length()-1 for p,t in edges if t==1<<j))
        products.append(new('and',13+j,petal))
    union(products)
    return circuit

if __name__=='__main__':
    circuit=stars()
    assert len(circuit)==34 and sum(op=='and' for op,_,_ in circuit)==7
    for p,t,sign in rows:
        ans=check(circuit,p|(t<<13))
        assert not sign or ans==(sign>0)
    fixture=[('and',0,1),('or',20,20),('and',21,2),('and',20,3),('or',22,4),('or',23,5),('and',24,25)]
    for mask in range(64):
        check(fixture,mask,True)
    print('676 native rows, 7 AND + 27 OR full separator; all single AND interventions at all wires.')
    print('64 assignments, all interventions and earlier-wire substitutions on double-read reconvergent fixture.')
