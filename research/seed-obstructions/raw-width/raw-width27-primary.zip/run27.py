from pathlib import Path
from zipfile import ZipFile
from tempfile import TemporaryDirectory
import subprocess
import sys
root=Path(__file__).resolve().parent
for filename in ('line28_profiles.py','verify28.py'):
    subprocess.run([sys.executable,filename],cwd=root,check=True)
with TemporaryDirectory() as td:
    with ZipFile(root/'raw28-two-pools.zip') as zipped:
        zipped.extractall(td)
    subprocess.run([sys.executable,'verify.py'],cwd=td,check=True)
