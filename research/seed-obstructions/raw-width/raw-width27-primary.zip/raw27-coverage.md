# Replay ledger

Run python run27.py here with Python 3 and python-sat including CaDiCaL 195. raw28.md is the 27-input theorem; its filename indicates the excluded count. raw28-trade.md proves the companion and merger budget. The predecessor raw-width28-primary.zip, 75c375a8d4bbd8dfe84677b2e2bd8fab3193f907c53b7feed2e8e8fffd66ff0b, excludes larger inputs and documents the referenced reconstruction and private-guard theorems. All decoders pin the same original 676-row statement.

All 7 single-ordinary, 21 two-companion/double-ordinary, 35 three-companion/triple-ordinary and 105 two-companion/two-of-three cases reject. Their original labeled logs are included. The additional 21 pooled-private-pair checks are controls. The nested raw28-two-pools.zip contains the complete 63+245 bipartitions, including exterior mergers, with their traces. SHA-256 d8762ca1829fc90add3ab0256ec4b01bec053373e570d07b9016b17a7e3a73fd. These SAT relaxations are independent of whether a merger originates in pure preprocessing or the mixed graph.

lines28.log gives the full physical catalog at each maximum paid price: 1, 99, 2069 and 8275 surviving multisets, with 24 missing-singleton exceptional profiles at width nine. line28_profiles.py checks their precise shapes and uses simple cardinality at width ten.
