from itertools import combinations
from forest_two_noforce import solve as one
from forest_multi import solve as two
from three_comp import solve as three
from two_of_three_two_comp import solve as two_of_three
from pool_all_private import solve as pooled_pair

for j in range(7):
    assert not one((j,),21)[0],j
print('7 single private guards, one companion: empty',flush=True)
for pair in combinations(range(7),2):
    assert not two(pair,21)[0],pair
    assert not pooled_pair(pair,21)[0],pair
print('21 disjoint pairs with two companions and 21 fully pooled guard pairs with one: empty',flush=True)
for triple in combinations(range(7),3):
    assert not three(triple,21)[0],triple
    for guards in combinations(triple,2):
        assert not two_of_three(triple,guards,21)[0],(triple,guards)
print('35 disjoint triples with three companions and 105 two-of-three guards with two: empty',flush=True)
