from pathlib import Path
from itertools import combinations
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
import sys
root=Path(__file__).resolve().parent
from inputs import P,N,stars
raw={1<<i for i in range(13)}
for j in range(6):
 a=(1<<j)|(1<<(j+1));b=(1<<(j+3))|(1<<((j+9)%13));raw.update((a,b,a|b))
raw=sorted(raw)
def solve(ordinary,limit=21):
    v=IDPool();cnf=[]
    role=[[v.id(('slot',r,i)) for i in range(31)]for r in range(2)]
    for i in range(31):
        for a,b in combinations(range(2),2):cnf.append([-role[a][i],-role[b][i]])
    cnf+=CardEnc.atmost(sum(role,[]),limit,vpool=v).clauses
    def distinguishing(r,p,n):return [role[r][i] for i,m in enumerate(raw) if m&p and not m&n]
    for unused,j in enumerate(ordinary):
        star=stars[j];outer=[1<<i for i in range(13) if not star>>i&1]
        for i in range(13):
            if star>>i&1:
                for a,b in combinations(outer,2):cnf.append(distinguishing(0,1<<i,a|b))
    for p in P:
        j=(p>>13).bit_length()-1
        if j in ordinary:continue
        pp=p&8191;opts=[]
        for i in ordinary:
            u=v.id(('comp',p,i));opts.append(u)
            negatives={n&8191 for n in N if n&(1<<(13+j)) and n&stars[i]}
            for n in negatives:cnf.append([-u,*distinguishing(1,pp,n)])
        cnf.append(opts)
    with Solver(name='cadical195',bootstrap_with=cnf) as s:
        answer=s.solve()
        if not answer:return False,[]
        model=set(s.get_model())
        return True,[[raw[i]for i,a in enumerate(rr)if a in model]for rr in role]
if __name__=='__main__':
    for o in combinations(range(7),2):
        ans,slots=solve(o);print(o,ans,slots,flush=True)
