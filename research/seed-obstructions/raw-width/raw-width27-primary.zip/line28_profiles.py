from lines_small import catalog,raw
for L,c in [(7,2),(8,3),(9,3),(10,3)]:
    if L==10:
        print('10 3: all seven raw flags necessarily selected',flush=True)
        continue
    families=catalog(L,c)
    missing=[]
    for family in families:
        gap=set(raw)-set(family)
        if not gap:continue
        assert (L,c)==(9,3) and len(gap)==1,(L,c,family)
        j=next(iter(gap))
        extra=[m for m in family if m not in raw]
        assert len(extra)==len(set(extra))==3 and all(m.bit_count()==2 and m&j for m in extra)
        missing.append(family)
    assert len(missing)==(24 if L==9 else 0)
    print(L,c,len(families),len(missing),flush=True)
