import ast,re,subprocess,sys
from pathlib import Path
from itertools import combinations
from census import raw,points,comps,point_obligations,src,stars
from omit import run as omissions,screen,witness
import dark
import anchored
import general
import automatic
import generic_x
import symmetry
import zero
from functools import reduce
home=Path(__file__).resolve().parent
def command(script):
 return subprocess.check_output([sys.executable,str(home/script)],cwd=home,text=True)
def control(names,name):
 out=''.join(command(script)for script in names)
 assert out==(home/name).read_text(),name
def run():
 _,ob=point_obligations(src)
 constraints=[frozenset(m for m in raw if m&p and not m&n)for p,n in ob]
 fixed={next(iter(x))for x in constraints if len(x)==1}
 assert fixed==set(points)-{2}
 residual={x for x in constraints if x.isdisjoint(fixed)}
 minima={x for x in residual if not any(y<x for y in residual)}
 assert minima==set(map(frozenset,[(2,3),(2,6),(2,258)]))
 eligible=[tuple(v) for v in combinations(sorted(set(raw)-fixed),3)if all(set(v)&x for x in minima)]
 allbanks={tuple(sorted(m for m in v if m!=2))for v in eligible if 2 in v}
 assert allbanks==set(combinations(comps,2)) and [v for v in eligible if 2 not in v]==[(3,6,258)]
 print('physical banks',len(allbanks),'plus one missing singleton',flush=True)
 control(('census.py','partition.py','dark.py','readmodes.py'),'strong.log')
 control(('two.py','missing.py'),'extra.log')
 rem=set(allbanks)
 one={ms for ms in rem if screen(ms)};rem-=one
 two={ms for ms in rem if witness(ms,0)};rem-=two
 three={ms for ms in rem if min(map(len,omissions(ms,0)))==3};rem-=three
 four={ms for ms in rem if min(map(len,omissions(ms,0)))==2};rem-=four
 assert list(map(len,(one,two,three,four)))==[102,4,21,15]
 rem-={(12,4160),(96,129)}
 for ms,U in [((129,520),92),((258,4160),23)]:
  g=anchored.projected(ms,ms,U);assert not anchored.feasible(tuple(sorted(g)),3,True)
  rem.remove(ms)
 answers={(129,258):[(512,)],(2080,4160):[(256,)],(129,1040):[(),(512,),(4096,),(512,4096)],(129,4160):[(),(256,),(512,)]}
 todo={ms:set(omissions(ms,0))-set(a) for ms,a in answers.items()}
 for line in (home/'anchor-witnesses.txt').read_text().splitlines():
  a,b,c,U=re.fullmatch(r'(\(.*?\)) (\(.*?\)) (\(.*?\)) (\d+)',line).groups()
  ms,z,high=map(ast.literal_eval,(a,b,c));U=int(U)
  assert set(high)<=set(ms) and 1<=U<=127
  g=anchored.projected(ms,high,U)
  assert not anchored.compatible(ms,z,high,U,g)
  todo[ms].remove(z)
 assert not any(todo.values())
 for ms in ((129,258),(2080,4160)):
  z,=answers[ms];opts=list(general.one_two(ms,z));assert opts
  assert all(general.target_ranks(ms,z,*a) is not None for a in opts)
  rem.remove(ms)
 print('initial and anchor stages closed',153-len(rem),'full banks',flush=True)
 for ms in ((129,4160),(129,1040)):
  for z in answers[ms]:
   if not z:
    assert not zero.zero(ms);continue
   if len(z)==1:
    opts=list(automatic.one_two(ms,z));assert opts
    assert all(automatic.target_ranks(ms,z,*a) is not None for a in opts)
   else:
    assert all(automatic.target_ranks(ms,z,(),(),False,() if u<0 else (u,),()) is not None for u in range(-1,7))
    assert not generic_x.build(ms,z)()
  rem.remove(ms)
 symmetry.checks()
 assert rem=={(129,2080),(520,4160),(1040,4160)}
 tail=command('missing-tail/verify.py')
 assert tail==(home/'missing-tail/verified.log').read_text()
 print('all 153 full banks and the unique missing-singleton bank excluded')
if __name__=='__main__':run()
