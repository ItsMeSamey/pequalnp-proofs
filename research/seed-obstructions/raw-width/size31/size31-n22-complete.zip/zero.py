from graph import *
from dag_rank import target_ranks
def zero(ms):
 good=[];count=0
 for ds,edges,tags,delta,fan in graphs(ms):
  count+=1;reach=[]
  for i,d in enumerate(ds):reach.append(d|reduce(int.__or__,(reach[j]for j in range(i)if edges[i]>>j&1),0))
  v=target_ranks(ms,(),tags,tuple(reach),False,delta,fan,edges)
  if v is None:good.append((ds,edges,tags,delta,fan))
 print('zero',ms,count,len(good),good[:1],flush=True)
 return good
if __name__=='__main__':
 for ms in ((129,1040),(129,4160)):
  Path('zero-%d-%d.txt'%ms).write_text('\n'.join(map(repr,zero(ms))))
