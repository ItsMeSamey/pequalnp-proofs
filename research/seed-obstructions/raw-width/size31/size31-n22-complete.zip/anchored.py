from labelproj import *
from dark import contain,bits
from collections import Counter
@lru_cache(None)
def force(ms):
 return {p:bits(lambda n:not n&p and (n>>13)&labels[p] and all(n&m for m in ms if m&p)) for p in points}
remain=[(129,258),(129,1040),(129,2080),(129,4160),(520,4160),(1040,4160),(2080,4160)]
def compatible(ms,z,high,U,g):
 f=force(ms);ns=bits(lambda n:all(n&m for m in high));on=[bits(lambda n:n>>(13+u)&1)for u in range(7)]
 eligible=reduce(int.__or__,(p for v in g.values()for p in v),0)
 for sel in product(*g.values()):
  dec=[((),3-len(z))]
  for p in z:
   new=[]
   line=not(p&eligible) and any(not(f[p]&ns&on[u]) for u in range(7)if U>>u&1)
   for d,k in dec:
    if p in sel:new.append(((*d,p),k));continue
    if line:new.append((d,k+1));continue
    new.append((d,k))
    for q in sel:
     if q not in d and not f[q]&contain[p]:new.append(((*d,q),k))
   dec=new
  if not any(feasible(tuple(sorted(x for x,p in zip(g,sel) if p not in d)),k,True)for d,k in dec):return False
 return True
def scan_anchors(ms):
 cand=run(ms,0)
 for high in [(),(ms[0],),(ms[1],),ms]:
  for U in [127,*sorted(range(1,127),key=int.bit_count,reverse=True)]:
   g=projected(ms,high,U)
   if len(g)<=5:continue
   cand=[z for z in cand if compatible(ms,z,high,U,g)]
   if not cand:return []
 return cand
if __name__=='__main__':
 for ms in remain:
  ds=scan_anchors(ms)
  print(ms,len(ds),Counter(map(len,ds)),ds[:2],flush=True)
