from dark import *
def build(ms,z):
 K=8191&~(reduce(int.__or__,ms,0)|sum(z));off=8191&~reduce(int.__or__,ms,0)
 on=[bits(lambda n,u=u:n>>(13+u)&1)for u in range(7)]
 m={(u,p):bits(lambda n:n>>(13+u)&1 and not n&p and all(n&x for x in ms if x&p))for u,s in enumerate(stars)for p in points if p&s}
 f={p:reduce(int.__or__,(n for (u,q),n in m.items()if p==q),0)for p in points}
 auto=[(s&K).bit_count()>=2 for s in stars]
 el={u:[q for q in points if q&s and all(m[u,q]&meet[v]for v in range(7)if v!=u)]for u,s in enumerate(stars)}
 y={}
 for u,g in el.items():
  for q in g:
   y[u,q]=contain[q]
   for p in z:
    if not(q&off or m[u,q]&f[p]):y[u,q]&=contain[p]
 available=[q for q in points if q not in z and f[q]]
 @lru_cache(None)
 def er(u,pts0,ys):
  Q=sum(pts0);y0=dict(zip(pts0,ys));dp={0:0}
  for h in range(8):
   if h==u:continue
   costs={0:0};sub=Q
   while sub:
    g=[q for q in pts0 if sub&q]
    if h==7 or not stars[h]&sub and not(auto[h] and any(on[h]&f[q]for q in g)):
     ng=meet[h]|reduce(int.__or__,(f[q]for q in g),0)
     costs[sub]=rank(tuple((y0[q]&ng,f[q]&ng)for q in g))
    sub=(sub-1)&Q
   nw={}
   for a,v in dp.items():
    for b,c in costs.items():
     if not a&b:nw[a|b]=min(nw.get(a|b,999),v+c)
   dp=nw
  return dp[Q]
 def possible(B,L,C):
  low=reduce(int.__or__,(f[p]for p in points if B&p),0)
  high=reduce(int.__or__,(on[u]for u in range(7)if L>>u&1),0)
  for u,s in enumerate(stars):
   inside=tuple(q for q in el[u]if q&B)
   local=rank(tuple((y[u,q]&low,f[q]&low)for q in inside))
   ext=[]
   for q in el[u]:
    if B&q or not all(f[q]&contain[p]for p in z):continue
    cross=labels[q].bit_count()>1 and all(any(m[v,q]&meet[h]for v in range(7)if v!=h and q&stars[v])for h in range(7)if q&stars[h])
    if auto[u] or cross:ext.append(q)
   ext=tuple(ext)
   necessary=er(u,ext,tuple(y[u,q]for q in ext))
   yd=tuple(y[u,q] if ((q&off and not L>>u&1) or m[u,q]&low) else y[u,q]&high for q in ext)
   restricted=er(u,ext,yd)
   minread=max(local,(s&K&B).bit_count(),int(bool(L>>u&1)))
   outside=max(0,(s&K&~B&~(C if L>>u&1 else 0)).bit_count() - int(not auto[u]))
   if not any(outside<=2-a and (necessary<=2 if a==0 else (necessary<=4-a and restricted<=2-a))for a in range(minread,3)):return False
  return True
 def scan():
  out=[]
  for h in range(1<<len(available)):
   B=sum(q for i,q in enumerate(available)if h>>i&1)
   low=reduce(int.__or__,(f[p]for p in available if B&p),0)
   pool=sum(1<<u for u in range(7)if not low&on[u]);L=pool
   while True:
    if L==0:
     if possible(B,L,0):out.append((B,0,0))
    elif not B&K:
     for rec in combinations([p for p in points if p&K],2):
      C=sum(rec)
      if possible(B,L,C):out.append((B,L,C))
    if not L:break
    L=(L-1)&pool
  print('generic',ms,z,len(out),out[:12],flush=True)
  return out
 return scan
if __name__=='__main__':
 r=build((129,1040),(512,4096))()
 Path('generic-left.txt').write_text('\n'.join(' '.join(map(str,x))for x in r))
