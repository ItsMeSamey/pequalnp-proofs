from census import *
from itertools import combinations
@lru_cache(None)
def feasible(groups,remaining,may_drop):
 n=[sum(bool(g>>u&1) for g in groups) for u in range(7)]
 if sum(max(i-2,0) for i in n)<=remaining:return True
 if remaining==0 or max(n)>2+remaining:return False
 for i,a in enumerate(groups):
  reduced=groups[:i]+groups[i+1:]
  if may_drop and feasible(reduced,remaining-1,True):return True
  for j in range(i):
   b=groups[j]
   if not a&b:continue
   nxt=tuple(sorted(groups[:j]+groups[j+1:i]+groups[i+1:]+(a|b,)))
   if feasible(nxt,remaining-1,False):return True
 return False
def witness(ms,missing):
 for hs in product((0,1),repeat=len(ms)):
  high=tuple(m for m,v in zip(ms,hs) if v);low=tuple(m for m,v in zip(ms,hs) if not v)
  for rep in [0]+([m for m in low if m&missing] if missing else []):
   S=allowed(high)
   for m in low:S&=~(m&~missing if m==rep else m)
   if not rep:S&=~missing
   if not all(S&s for s in stars):continue
   groups=tuple(sorted(labels[p] for p in points if p&S))
   if not feasible(groups,3,True):return high,rep,S
if __name__=='__main__':
 for missing,banks in ((0,combinations(comps,2)),(2,[(3,6,258)])):
  old=0;new=[];left=[]
  for ms in banks:
   if screen(ms,missing):old+=1
   elif witness(ms,missing):new.append(ms)
   else:left.append(ms)
  print(missing,old,len(new),len(left),left)
