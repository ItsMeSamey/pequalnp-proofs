from pathlib import Path
from itertools import combinations,product
from functools import lru_cache
from collections import Counter
from input import raw_samples,point_obligations
src=Path(__file__).with_name('L-meta-18968.json')
P,N,_=raw_samples(src);raw,_=point_obligations(src)
points=[1<<i for i in range(13)]
stars=[sum(w&8191 for w in P if w>>13==1<<u)for u in range(7)]
labels={p:sum(1<<u for u,s in enumerate(stars) if s&p) for p in points}
comps=sorted(m for m in raw if m.bit_count()>1)
@lru_cache(None)
def allowed(high):
 ns=tuple(n for n in N if all(n&m for m in high))
 if any(not any(n&stars[u] and n>>(13+v)&1 for n in ns)for u in range(7)for v in range(7)if u!=v):return 0
 good=0
 for p,l in labels.items():
  if not all(any(n>>(13+v)&1 and n>>13&l for n in ns)for v in range(7)):continue
  if not all(any(n&p and n>>(13+v)&1 for n in ns)for v in range(7)if not l>>v&1):continue
  if not all(any(n&p and n&s for n in ns) for s in stars):continue
  good|=p
 return good
def assess(kept):
 if any(not s&kept for s in stars):return False
 total=sum(l.bit_count() for p,l in labels.items()if p&kept)
 if total!=23:return total>23
 return not any(all((s&(kept^sum(d))).bit_count()==2 for s in stars)for d in combinations([p for p,l in labels.items()if p&kept and l.bit_count()==3],3))
def screen(ms,missing=0):
 options=[]
 for highs in product((False,True),repeat=len(ms)):
  high=tuple(m for m,b in zip(ms,highs)if b)
  low=tuple(m for m,b in zip(ms,highs)if not b)
  permitted=allowed(high)
  # An unpinned composite may represent the unique missing point, after dropping every other point in that composite.
  reps=[0]+([m for m in low if m&missing] if missing else [])
  for rep in reps:
   kept=permitted
   for m in low:kept&=~(m&~missing if m==rep else m)
   if not rep:kept&=~missing
   if assess(kept):return high,rep,kept
 return None
if __name__=='__main__':
 for missing,banks in [(0,combinations(comps,2)),(2,[(3,6,258)])]:
  out=[];left=[]
  for ms in banks:
   w=screen(ms,missing)
   if w:out.append((ms,w))
   else:left.append(ms)
  print('missing',missing,'closed',len(out),'open',len(left),left)
