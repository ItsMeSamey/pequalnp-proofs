from partition import *
from collections import Counter
def run(ms,missing,rep=0):
 S=8191
 for m in ms:S&=~(m&~missing if m==rep else m)
 if not rep:S&=~missing
 K=[p for p in points if p&S]
 poss=[]
 for n in range(4):
  for d in combinations(K,n):
   g=tuple(sorted(labels[p]for p in K if p not in d))
   if feasible(g,3-n,False):poss.append(d)
 return poss
if __name__=='__main__':
 h=Counter();ledger={}
 for ms in combinations(comps,2):
  if screen(ms) or witness(ms,0):continue
  opt=run(ms,0)
  m=min(map(len,opt))
  h[m]+=1;ledger[ms]=(m,len(opt))
 print(h)
 print('force3',[k for k,(m,n)in ledger.items()if m==3])
 for ms in ((3,12),(129,4160)):
  print(ms,run(ms,0)[:10])
