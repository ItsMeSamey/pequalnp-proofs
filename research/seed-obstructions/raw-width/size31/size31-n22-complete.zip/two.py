from triangle import *
import both
for ms in [(12,4160),(96,129)]:
 tested=0
 for z in run(ms,0):
  if len(z)==1:
   K=8191&~(reduce(int.__or__,ms,0)|sum(z))
   over=[u for u,s in enumerate(stars)if(s&K).bit_count()>2]
   assert len(over)==3 and all((stars[u]&K).bit_count()==3 for u in over)
   opts=list(tris(ms,z));assert opts
   for tag,reach,serial in opts:
    assert target_ranks(ms,z,tag,reach,serial) is not None;tested+=1
  elif len(z)==2:
   K=8191&~(sum(z)|ms[0]|ms[1]);ts=[u for u,s in enumerate(stars)if(s&K).bit_count()>2]
   assert len(ts)==1;t=ts[0]
   assert both.reject(ms,z,-1,t) is not None;tested+=1
   for rs in combinations([p for p in points if p&K&stars[t]],2):
    assert both.reject(ms,z,t,-1,rs) is not None;tested+=1
  else:
   assert reject(ms,z) is not None;tested+=1
 print(ms,'excluded',tested)
