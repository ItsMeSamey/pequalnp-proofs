from omit import *
from functools import reduce
from itertools import combinations_with_replacement
ns=tuple(N)
def bits(f):return sum(1<<i for i,n in enumerate(ns) if f(n))
contain={p:bits(lambda n:n&p) for p in points}
meet=[bits(lambda n:n&s) for s in stars]+[(1<<len(ns))-1]
@lru_cache(None)
def shapes(n,k):
 out=set()
 for masks in combinations_with_replacement(range(1<<n),k):
  sh={0}
  for x in masks:sh|={r|x for r in sh if not r&x}
  out.add(tuple(sorted(sh)))
 return out
@lru_cache(None)
def rank(rows):
 cols=set()
 for n in range(len(ns)):
  yes=sum(1<<i for i,(a,b) in enumerate(rows) if a>>n&1)
  if yes:cols.add((yes,sum(1<<i for i,(a,b) in enumerate(rows) if b>>n&1)))
 for k in range(len(rows)):
  if any(all(any(not(y&~x or f&x) for x in sh)for y,f in cols)for sh in shapes(len(rows),k)):return k
 return len(rows)
def rank_all(ms,z,tag=-1,tripled=-1,receivers=(),direct_mode=False):
 out=[0]*7
 m={(u,p):bits(lambda n:n>>(13+u)&1 and not n&p and all(n&x for x in ms if x&p)) for u,s in enumerate(stars)for p in points if s&p}
 f={p:reduce(int.__or__,(n for (u,q),n in m.items() if p==q),0)for p in points}
 tagrows=bits(lambda n: tag>=0 and n>>(13+tag)&1)
 outside=[q for q in points if all(f[q]&contain[p] for p in z) and (tag<0 or f[q]&tagrows)]
 for u,s in enumerate(stars):
  ready={}
  for q in outside:
   if not q&s:continue
   crossing=labels[q].bit_count()>1
   if not crossing and not any(q2&s and labels[q2].bit_count()>1 and f[q]&m[u,q2] for q2 in outside):continue
   if not all(m[u,q]&meet[h] for h in range(7)if h!=u):continue
   if not all(m[v,q] for v in range(7) if q&stars[v]):continue
   if crossing and not all(any(m[v,q]&meet[h] for v in range(7) if v!=h and stars[v]&q)for h in range(7) if q&stars[h]):continue
   y=contain[q]
   for p in z:
    if not m[u,q]&f[p]:y&=contain[p]
   routed=tag>=0 and (stars[u]&~(ms[0]|ms[1]|sum(z)|sum(receivers))).bit_count()<2
   if routed and direct_mode:y&=tagrows
   ready[q]=y
  if len(ready)<3:continue
  Q=sum(ready);dp={0:0}
  for h in range(8):
   if h==u:continue
   costs={0:0};sub=Q
   while sub:
    group=[q for q in ready if q&sub]
    if h==7 or not stars[h]&sub:
     neg=meet[h]|reduce(int.__or__,(f[q] for q in group),0)
     costs[sub]=rank(tuple((ready[q]&neg,f[q]&neg) for q in group))
    sub=(sub-1)&Q
   nw={}
   for a,n in dp.items():
    for b,c in costs.items():
     if not a&b:nw[a|b]=min(nw.get(a|b,999),n+c)
   dp=nw
  out[u]=dp[Q]
 return out
def reject(ms,z,tag=-1,tripled=-1,receivers=()):
 no=rank_all(ms,z,tag,tripled,receivers)
 yes=rank_all(ms,z,tag,tripled,receivers,True)
 for u in range(7):
  can=tag>=0 and (stars[u]&~(ms[0]|ms[1]|sum(z)|sum(receivers))).bit_count()<2
  if (u==tag or no[u]>2+int(u==tripled)) and (not can or yes[u]>1 or no[u]>3):return u
 return None
if __name__=='__main__':
 for ms in combinations(comps,2):
  if screen(ms) or witness(ms,0):continue
  zz=run(ms,0)
  if min(map(len,zz))!=2:continue
  failed=[]
  for z in zz:
   if len(z)==3:
    if reject(ms,z) is None:failed.append(('three',z))
   else:
    K=8191&~(ms[0]|ms[1]|sum(z))
    t=next(u for u,s in enumerate(stars) if (s&K).bit_count()>2)
    for tag,trip in [(t,-1),(-1,t)]:
     rec=[()] if tag<0 else combinations([p for p in points if K&p&stars[t]],2)
     for rs in rec:
      if reject(ms,z,tag,trip,rs) is None:failed.append((tag,trip,z,rs))
  print(ms,'failed',failed)
