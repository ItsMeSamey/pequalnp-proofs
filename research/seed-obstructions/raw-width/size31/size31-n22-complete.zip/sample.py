from itertools import permutations
from pathlib import Path
from input import raw_samples
base=Path(__file__).resolve().parent
pos,neg,_=raw_samples(base/"L-meta-18968.json")
def move(mask, permutation):
    return sum(1<<target for bit,target in enumerate(permutation) if mask>>bit&1)
raw = tuple(1<<j for j in range(7))
stars = [sum({p&8191 for p in pos if p&(l<<13)}) for l in raw]
incidence = [sum(1<<j for j,s in enumerate(stars) if s>>i&1) for i in range(13)]
def symmetries():
    group = []
    for perm in permutations(range(7)):
        images = [move(x,perm) for x in incidence]
        if set(images)!=set(incidence):
            continue
        pp = [incidence.index(y) for y in images]
        line = [move(x,perm) for x in range(128)]
        def transform(r):
            return move(r&8191,pp) | line[r>>13]<<13
        if all({transform(r) for r in rows}==rows for rows in (pos,neg)):
            group.append((pp,line))
    assert len(group)==24
    return group

def base_info(f):
 pp=sorted(pos);nn=sorted(neg)
 bank=[*[r<<13 for r in raw],*f]
 pv=[sum(1<<i for i,r in enumerate(pp) if m&r) for m in bank];nv=[sum(1<<j for j,r in enumerate(nn) if m&r) for m in bank]
 needp=[0]*len(bank);needn=[0]*len(bank)
 plist=[sum(1<<i for i,m in enumerate(bank) if m&r) for r in pp];nlist=[sum(1<<i for i,m in enumerate(bank) if m&r) for r in nn]
 private=[]
 for i,pm in enumerate(plist):
  for j,nm in enumerate(nlist):
   diff=pm&~nm
   if diff.bit_count()!=1:continue
   z=diff.bit_length()-1
   needp[z]|=1<<i;needn[z]|=1<<j
   if z<7:private.append((z,i,j))
 return pp,nn,pv,nv,needp,needn,private
