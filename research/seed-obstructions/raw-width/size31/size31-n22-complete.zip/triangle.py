from dark import *
def target_ranks(ms,z,tagsets,reach,serial):
 m={(u,p):bits(lambda n:n>>(13+u)&1 and not n&p and all(n&x for x in ms if x&p)) for u,s in enumerate(stars)for p in points if s&p}
 f={p:reduce(int.__or__,(n for (u,q),n in m.items()if p==q),0) for p in points}
 his=[bits(lambda n,t=t:(n>>13)&t) for t in tagsets]
 outside=[q for q in points if all(f[q]&contain[p]for p in z)and all(f[q]&v for v in his)]
 K=8191&~(reduce(int.__or__,ms,0)|sum(z))
 for u,s in enumerate(stars):
  cand=[]
  for q in outside:
   if not s&q or labels[q].bit_count()<2:continue
   if not all(m[u,q]&meet[h] for h in range(7)if h!=u):continue
   if not all(m[v,q]for v in range(7)if stars[v]&q):continue
   if not all(any(m[v,q]&meet[h] for v in range(7)if v!=h and stars[v]&q)for h in range(7)if stars[h]&q):continue
   y=contain[q]
   for p in z:
    if not m[u,q]&f[p]:y&=contain[p]
   cand.append((q,y))
  for rt in product((0,1),repeat=len(reach)):
   cap=2-sum(rt)
   serves=reduce(int.__or__,(v for v,b in zip(reach,rt) if b),0)
   if (K&s&~serves).bit_count() - int((K&s).bit_count()<=1)>cap:continue
   if len(cand)<=cap:break
   ys={}
   for q,y in cand:
    previous=(1<<len(ns))-1
    for i,(fed,high)in enumerate(zip(rt,his)):
     dominated=high if fed else (previous if serial and i else (1<<len(ns))-1)
     if not fed and serial and i:dominated|=high
     y&=dominated;previous=dominated
    ys[q]=y
   dp={0:0};Q=sum(ys)
   for h in range(8):
    if h==u:continue
    co={0:0};sub=Q
    while sub:
     gp=[q for q in ys if q&sub]
     if h==7 or not stars[h]&sub:
      neg=meet[h]|reduce(int.__or__,(f[q]for q in gp),0)
      co[sub]=rank(tuple((ys[q]&neg,f[q]&neg) for q in gp))
     sub=(sub-1)&Q
    new={}
    for a,n in dp.items():
     for b,c in co.items():
      if not a&b:new[a|b]=min(new.get(a|b,99),n+c)
    dp=new
   if dp[Q]<=cap:break
  else:return u
 return None
def tris(ms,z):
 K=8191&~(reduce(int.__or__,ms,0)|sum(z));T=sum(1<<u for u,s in enumerate(stars)if(s&K).bit_count()>2)
 for gp in combinations([p for p in points if K&p],3):
  if any(sum(bool(stars[u]&p)for p in gp)<2 for u in range(7)if T>>u&1):continue
  yield (T,), (sum(gp),), False
  for a in gp:
   b,c=[p for p in gp if p!=a]
   left=T&labels[a];right=T
   yield (left,right),(sum(gp),b|c),True
if __name__=='__main__':
 for ms in [(12,4160),(96,129)]:
  for z in run(ms,0):
   if len(z)!=1:continue
   for tag,reach,serial in tris(ms,z):
    print(ms,z,tag,reach,serial,target_ranks(ms,z,tag,reach,serial))
