from census import *
from sample import move,symmetries
def checks():
 pos=set(P);neg=set(N);group=symmetries()
 bank={*points,129,1040}
 dest=((129,1040),(129,2080),(520,4160),(1040,4160))
 for pair in dest:
  goal={*points,*pair}
  for pp,ll in group:
   if {move(x,pp) for x in bank}!=goal:continue
   rawflags={1<<u for u in range(7)}
   assert {ll[v] for v in rawflags}==rawflags
   for rows in (pos,neg):
    assert {move(r&8191,pp)|(ll[r>>13]<<13)for r in rows}==rows
   print('transport',pair,tuple(pp),tuple(ll[1<<j].bit_length()-1 for j in range(7)))
   break
  else:raise AssertionError(pair)
if __name__=='__main__':checks()
