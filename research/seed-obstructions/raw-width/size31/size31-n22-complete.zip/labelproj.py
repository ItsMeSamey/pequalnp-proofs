from omit import *
from functools import reduce
def projected(ms,high,us):
 ns=[n for n in N if all(n&m for m in high)];low=set(ms)-set(high)
 if any(not any(n&stars[h] and n>>(13+v)&1 for n in ns)for v in range(7)if us>>v&1 for h in range(7)if h!=v):return {}
 kept={}
 for p in points:
  l=labels[p]&us
  if not l or any(p&m for m in low):continue
  if not all(any(n>>(13+v)&1 and n>>13&l for n in ns)for v in range(7)if us>>v&1):continue
  if not all(any(n&p and n>>(13+v)&1 for n in ns)for v in range(7)if us>>v&1 and not l>>v&1):continue
  if not all(any(n&p and n&s for n in ns)for s in stars):continue
  kept.setdefault(l,[]).append(p)
 return kept
def scan(ms):
 for hs in product((0,1),repeat=len(ms)):
  high=tuple(m for m,v in zip(ms,hs)if v)
  for u in range(1,127):
   K=projected(ms,high,u)
   if len(K)>5 and not feasible(tuple(sorted(K)),3,True):return high,u,K
if __name__=='__main__':
 for ms in [(129,258),(129,520),(129,1040),(129,4160)]:
  print(ms,scan(ms),flush=True)
