from automatic import *
from itertools import combinations_with_replacement
def graphs(ms):
 K=8191&~reduce(int.__or__,ms,0);bs=[p for p in points if p&K];req=[s&K for s in stars]
 assert sum(max(0,q.bit_count()-2)for q in req)>=4
 for fees in ((2,),(3,),(1,1),(1,2),(2,1),(1,1,1)):
  h=len(fees);left=3-sum(fees)
  def gen(ds,inners):
   j=len(ds)
   if j<h:
    for raw in combinations(bs+[-i-1 for i in range(j)],fees[j]+1):
     yield from gen(ds+[sum(x for x in raw if x>0)],inners+[sum(1<<(-x-1)for x in raw if x<0)])
    return
   cover=[0]*(1<<h);source=[0]*(1<<h)
   for t in range(1,1<<h):
    a=t&-t;cover[t]=cover[t^a]|ds[a.bit_length()-1];low=t
    for i,adj in enumerate(inners):
     if t>>i&1:low&=~adj
    source[t]=low.bit_count()
   price=[[source[t]+(q&~cover[t]).bit_count()for t in range(1<<h)]for q in req]
   minimum=[max(0,min(c)-2)for c in price]
   if sum(minimum)>left:return
   for extra in combinations_with_replacement(range(7),left-sum(minimum)):
    delta=[minimum[u]+extra.count(u)for u in range(7)];opts=[]
    for u,cost in enumerate(price):
     valid=[t for t,c in enumerate(cost)if c<=2+delta[u]]
     opts.append([t for t in valid if not any(v!=t and not v&~t for v in valid)])
    for profile in product(*opts):
     hi=tuple(sum(1<<u for u,t in enumerate(profile)if t>>i&1)for i in range(h))
     assert all(hi),(fees,ds,inners,hi)
     yield tuple(ds),tuple(inners),hi,tuple(u for u,d in enumerate(delta)for _ in range(d)),tuple(x+1 for x in fees)
  yield from gen([],[])
if __name__=='__main__':
 from collections import Counter
 for ms in [(129,4160),(129,1040)]:
  result=Counter()
  for ds,edges,tags,delta,fan in graphs(ms):result[fan]+=1
  print(ms,result,flush=True)
