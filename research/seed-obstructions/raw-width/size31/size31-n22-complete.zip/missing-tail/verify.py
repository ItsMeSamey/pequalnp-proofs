"""Produce four mutually incompatible tag cells for every possible holder."""
from itertools import combinations
from functools import lru_cache
from pathlib import Path
from samples import raw_samples

P,N=map(sorted,raw_samples(Path(__file__).with_name('L-meta-18968.json')))
stars=[sum(r&8191 for r in P if r>>(13+u)&1) for u in range(7)]
raw=[1<<i for i in range(13) if i!=1]+[3,6,258]+[1<<(13+u) for u in range(7)]
assert len(raw)==22
@lru_cache(None)
def private(r,a):
    return {n for n in N if {b for b in raw if b&r and not b&n}=={a}}
@lru_cache(None)
def all_private(a):
    return {n for r in P if a&r for n in private(r,a)}
r1=(1<<18)|2
assert r1 in P
for a in (3,6,258,1<<18):
    witnesses=sorted(private(r1,a));assert witnesses
    print('p1 private',a,len(witnesses),witnesses[0])
origins=(3,1<<7,1<<11,1<<12)
rows=[(1<<18)|(2 if a==3 else a) for a in origins]
assert all(r in P for r in rows)
marked=[all_private(a) for a in origins]
baseline=(1<<9,1<<10)
for a,r in zip(origins,rows):
    s=private(r,a)
    assert all(any(n&bit for n in s) for bit in (*baseline,1<<18))
    assert all(any(n&stars[u] for n in s) for u in range(7) if u!=5)
for h in (0,1,2,3,4,6,7):
    options=[]
    for i,(a,r) in enumerate(zip(origins,rows)):
        s=private(r,a)
        by_shape={}
        for n in N:
            if not n&(r&8191) or (h!=7 and not n&stars[h]):continue
            if not all(n&p or s&all_private(p) for p in baseline):continue
            sh=tuple(j for j,cols in enumerate(marked) if n in cols)
            by_shape.setdefault(sh,n)
        options.append(by_shape)
    def search(cols):
        i=len(cols)
        if i==4:return cols
        for sh,n in options[i].items():
            if all(j in sh or old in marked[i] for j,old in enumerate(cols)):
                found=search(cols+[n])
                if found:return found
    result=search([])
    assert result is not None and all(result[i] in marked[j] or result[j] in marked[i] for i,j in combinations(range(4),2))
    print('holder',h,'forcing negatives',*result)
