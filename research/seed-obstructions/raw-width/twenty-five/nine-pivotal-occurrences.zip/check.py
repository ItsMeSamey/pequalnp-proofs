from collections import Counter
from itertools import combinations_with_replacement
def live(n,c):
    out=n+len(c)-1
    stack=[out];vs=set()
    while stack:
        x=stack.pop()
        if x in vs:continue
        vs.add(x)
        if x>=n:stack.extend(c[x-n][1:])
    return vs
def cycl(n,c):
    vs=live(n,c)
    g=sum(x>=n for x in vs)
    return g+1-(len(vs)-g)
def eval_gate(op,a,b):return a&b if op else a|b
def checked(n,c,pin,side,b):
    ones=(1<<(1<<n))-1
    raw=[sum(1<<a for a in range(1<<n) if a>>j&1) for j in range(n)]
    literal=object();columns=raw.copy();ref=list(range(n));fold=[]
    for i,(op,s,t) in enumerate(c):
        a,bb=columns[s],columns[t];x,y=ref[s],ref[t]
        if pin==i:
            if side==0:a=b*ones;x=(literal,b)
            else:bb=b*ones;y=(literal,b)
        columns.append(eval_gate(op,a,bb))
        if isinstance(x,tuple) and isinstance(y,tuple):z=(literal,eval_gate(op,x[1],y[1]))
        elif isinstance(x,tuple) or isinstance(y,tuple):
            const,other=(x,y) if isinstance(x,tuple) else (y,x)
            z=other if const[1]==op else const
        else:z=n+len(fold);fold.append((op,x,y))
        ref.append(z)
    z=ref[-1]
    if isinstance(z,tuple):
        assert columns[-1]==z[1]*ones;return
    values=raw.copy()
    for op,a,bb in fold:values.append(eval_gate(op,values[a],values[bb]))
    assert values[z]==columns[-1]
    if z>=n:assert cycl(n,fold[:z-n+1])<=cycl(n,c)-1
    else:assert cycl(n,c)>=1
def run(n,maxg):
    counts=[0,0,0]
    def extend(c):
        if c:
            vs=live(n,c)
            occ=Counter(x for v in vs if v>=n for x in c[v-n][1:])
            for i,g in enumerate(c):
                if i+n not in vs:continue
                for d,x in enumerate(g[1:]):
                    if occ[x]>1:
                        counts[1]+=1
                        for b in (0,1):checked(n,c,i,d,b);counts[2]+=1
            counts[0]+=1
        if len(c)<maxg:
            for a,b in combinations_with_replacement(range(n+len(c)),2):
                for op in (0,1):extend(c+[(op,a,b)])
    extend([]);return counts
if __name__=='__main__':
    for n,g in [(2,3),(3,2)]:print(n,g,run(n,g),flush=True)
