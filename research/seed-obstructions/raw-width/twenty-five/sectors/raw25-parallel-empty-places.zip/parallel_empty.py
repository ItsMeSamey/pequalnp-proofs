from nine_direct_thresholds import *
from eighth_routes import owneropts
from itertools import combinations_with_replacement
supports=[c for c in range(1,256) if c.bit_count()<=2]
configs=list(combinations_with_replacement(supports,2))
ALLC=(1<<len(configs))-1
def bmap(it):return sum(1<<j for j,x in enumerate(it) if x)
use=[]
for mode in (1,2,3):
    use.append([bmap((not((mode&1) and x>>u&1) and not ((mode&2) and y>>u&1) for x,y in configs)) for u in range(7)])
@lru_cache(None)
def cost(v,minimum,marked,mode):
    counts=[]
    for x,y in configs:
        xv=(3-x.bit_count()) if mode&1 and x>>v&1 else 0
        yv=(3-y.bit_count()) if mode&2 and y>>v&1 else 0
        counts.append(max(0,minimum-xv-yv,marked if xv+yv==0 else 0))
    return bmap(n>=1 for n in counts),bmap(n>=2 for n in counts)
def solve(F):
    opts=owneropts(0,0);owned=[0]*8;req=[0]*8
    def walk(k,cc):
        fs=[minima(h,q,F,0,0) for h,q in enumerate(owned)]
        if None in fs:return 0
        x1=x2=x3=0
        for h,(a,b,c,d) in enumerate(fs):
            a|=req[h];x3|=c|(x2&a)|(x1&b);x2|=b|(x1&a);x1|=a
        while x3:
            bit=x3&-x3;x3^=bit;u=bit.bit_length()-1;keep=0
            for mode in (1,2,3):
                o1=o2=0
                for h,pf in enumerate(fs):
                    m=sum(bool(g&bit) for g in pf)
                    p1,p2=cost(h,m,bool(req[h]&bit),mode)
                    o2|=p2|(o1&p1);o1|=p1
                keep|=use[mode-1][u]&~(o1 if mode==3 else o2)
            cc&=keep
            if not cc:return 0
        if k==len(opts):return cc
        p,hs=opts[k];out=0
        for h in hs:
            w=req[h];req[h]|=tagmask[p];owned[h]|=1<<p
            out|=walk(k+1,cc&~out);owned[h]^=1<<p;req[h]=w
            if out==cc:break
        return out
    c0=ALLC
    if F.bit_count()==2:
        c0&=bmap((F&~(x|y)==0) for x,y in configs)
    keep=walk(0,c0)
    return [pair for j,pair in enumerate(configs) if keep>>j&1]
if __name__=='__main__':
    import sys
    for f in map(int,sys.argv[1:]):
        a=solve(f);print(f,len(a),a[:8],flush=True)
