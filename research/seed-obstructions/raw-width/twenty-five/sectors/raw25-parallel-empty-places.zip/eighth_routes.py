from eighth_thresholds import *
from itertools import combinations
@lru_cache(None)
def owneropts(B,z):
    ds=domain(z)
    out=[(p,ds[p]) for p in ds if not B>>p&1]
    return sorted(out,key=lambda t:(len(t[1]),-tagmask[t[0]].bit_count()))
def solve(B,z,C,F):
    opts=owneropts(B,z)
    mandatory=0
    for p in range(13):
        if B>>p&1 and 1<<p!=z:mandatory|=tagmask[p]
    xm=minima(8,B,F,z,0)
    if xm is None or (xm[0]|mandatory)&C or xm[2]:return None
    xcounts=[sum(b>>u&1 for b in xm) for u in range(7)]
    owned=[0]*8;demands=[0]*8
    def walk(k):
        profiles=[]
        for v,q in enumerate(owned):
            m=minima(v,q,F,z,B if F>>v&1 else 0)
            if m is None:return None
            profiles.append(m)
        direct1=direct2=direct3=0
        via1=via2=0
        for v,(a,b,c) in enumerate(profiles):
            first=a|demands[v]
            direct3|=c|(direct2&first)|(direct1&b)
            direct2|=b|(direct1&first)
            direct1|=first
            if C>>v&1:
                first,second=(b,c) if C.bit_count()==2 else (c,0)
            else:second=b
            via2|=second|(via1&first)
            via1|=first
        if (mandatory|xm[0]|direct3)&(C|via2|(via1&xm[1])):return None
        if k==len(opts):return tuple(owned)
        p,hs=opts[k]
        for h in hs:
            old=demands[h]
            demands[h]|=tagmask[p];owned[h]|=1<<p
            ans=walk(k+1)
            owned[h]^=1<<p;demands[h]=old
            if ans:return ans
        return None
    return walk(0)
def run(B,z):
    kept=[];n=0
    for C in range(1,256):
        if C.bit_count()>2:continue
        fs=[0]+[1<<u for u in range(7)]
        for i,j in combinations(range(7),2):
            F=1<<i|1<<j
            if (F&C)==F or (z and F&C and any(tagmask[z.bit_length()-1]>>u&1 for u in (i,j) if C>>u&1)):fs.append(F)
        for F in fs:
            n+=1
            sol=solve(B,z,C,F)
            if sol:kept.append((C,F,sol))
    return n,kept
if __name__=='__main__':
    import sys
    for b in map(int,sys.argv[1:]):
        for z in [0]+[1<<p for p in range(13) if b>>p&1]:
            n,k=run(b,z);print(b,z,n,len(k),k[:1],flush=True)
