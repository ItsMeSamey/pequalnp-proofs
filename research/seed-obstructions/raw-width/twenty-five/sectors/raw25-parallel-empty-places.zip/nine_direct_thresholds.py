from optional_thresholds import choices,shape_bits
from filter_local import P,N,ALL,on,meeting,inc,unique,raw,tables,count
from functools import lru_cache
from itertools import combinations
compulsory=8191^2
protected={raw.index(1<<p) for p in range(13) if compulsory>>p&1}
tagmask={p:sum(1<<u for q,u in inc if p==q) for p in range(13)}
@lru_cache(None)
def filtered_lo(z):
    out=[0]*7
    for p,u in inc:
        if 1<<p!=z:out[u]|=unique[p,u]
    return out
@lru_cache(None)
def domain(z):
    dest={}
    for p in range(13):
        if not compulsory>>p&1 or 1<<p==z:continue
        bad=0
        for u in range(7):
            if tagmask[p]>>u&1:bad|=unique[p,u]
        possible=[7]
        for h in range(7):
            if tagmask[p]>>h&1:continue
            hit=bad&on[h]
            if all(not(hit&unique[q,h]) for q,v in inc if v==h and 1<<q!=z and compulsory>>q&1):
                possible.append(h)
        dest[p]=possible
    return dest
@lru_cache(maxsize=8192)
def minima(h,owned,F,z,skip,reject=0):
    own=h<7 and F>>h&1
    pos=[(p,u) for p,u in inc if owned>>p&1 or own and u==h and not(skip>>p&1)]
    neg=ALL if h==7 else 0 if h==8 else meeting[h]
    for p,u in pos:
        if owned>>p&1:neg|=unique[p,u]
    if own:neg|=1<<count
    if reject:pos=[(p,u)for p,u in pos if (owned>>p&1) and unique[p,u]&reject]
    req=[];pm={};nm={}
    for i,(p,u) in enumerate(pos):
        lb=on[u] if u==h or not F>>u&1 else filtered_lo(z)[u]
        if own and u==h:lb|=1<<count
        data=tables[p,bool(owned>>p&1)];zero=data.get(-1,0)&neg
        if zero&lb:return None
        req.append(zero)
        for coord,x in data.items():
            if coord in protected and (bits:=x&neg&lb):
                pm[coord]=pm.get(coord,0)|(1<<i);nm[coord]=nm.get(coord,0)|bits
    if any(pm[x]&pm[y] and nm[x]&nm[y] for x,y in combinations(pm,2)):return None
    masks=[0,0,0,0]
    for u in range(7):
        rows=[i for i,(_,v) in enumerate(pos) if u==v]
        active=0
        for i in rows:active|=req[i]
        if not active:continue
        forbid=[]
        for i in rows:
            b=0
            for x,r in pm.items():
                if r>>i&1:b|=nm[x]
            forbid.append(b)
        cols=set()
        while active:
            bit=active&-active;active^=bit
            cols.add((sum(1<<j for j,i in enumerate(rows) if req[i]&bit),sum(1<<j for j,b in enumerate(forbid) if b&bit)))
        for k in range(1,2 if h==u else 5):
            live=-1
            for yes,no in cols:
                live&=shape_bits(len(rows),k,yes,no)
                if not live:break
            if live:break
        else:return None
        if u!=h:
            for t in range(k):masks[t]|=1<<u
    return tuple(masks)
