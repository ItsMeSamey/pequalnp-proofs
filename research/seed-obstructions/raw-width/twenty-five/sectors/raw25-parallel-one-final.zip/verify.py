from pathlib import Path
from hashlib import sha256
from itertools import combinations_with_replacement
from zipfile import ZipFile
import json
from official import raw_samples
base=Path(__file__).resolve().parent
archive=base/'raw25-one-hall-results.zip'
assert sha256(archive.read_bytes()).hexdigest()=='4fbb87ecfbb5a96c41d8972c3c37082243c2914f0987aa9fb773ad549f411022'
P,N,idx=raw_samples(base/'L-meta-18968.json')
stars=[sum(1<<((6+j+d)%13)for d in (0,1,3,9))for j in range(7)]
raw={1<<p for p in range(13)}
for i in range(6):
 a=3<<i;b=1<<(i+3)|1<<((i+9)%13);raw.update((a,b,a|b))
def masking(n,p):return not n&p and all(m==p or not m&p or n&m for m in raw)
def own(p,n):return [u for u,t in enumerate(stars)if t&p and n>>(13+u)&1 and masking(n,p)]
def bits(s):return [1<<i for i in range(13)if s>>i&1]
def rank_three(qs):
 assert len(qs)==3
 pairs={(sum(1<<i for i,p in enumerate(qs)if n&p),sum(1<<i for i,p in enumerate(qs)if own(p,n)))for n in N}
 for a,b in combinations_with_replacement(range(8),2):
  shapes=[0,a,b]+([a|b]if not a&b else [])
  assert any(all(y&~v or v&no for v in shapes)for y,no in pairs)
seen={}
with ZipFile(archive)as z:
 for i in range(369):
  item=json.loads(z.read(f'checkpoints/{i:03}.json'))
  for h,m in item['survivors']:
   a=item['B'];assert h==[0]*7+[8189^a]
   assert item['z']==0 and item['C']==128 and item['D']==128
   seen.setdefault(a,[]).append((item['profile'],item['F']))
assert len(seen)==7 and sum(map(len,seen.values()))==56
for a,profile in sorted(seen.items()):
 assert sorted(f for _,f in profile)==[0,1,2,4,8,16,32,64] and len({k for k,f in profile})==1
 po=bits(stars[0]&a);assert len(po)==1
 qs=bits(stars[0]&~a);rank_three(qs)
 for q in qs:
  found=sorted((idx[n][0],n,p,j)for n in N if 0 in own(q,n)for p in bits(a)for j in own(p,n))
  i,n,p,j=found[0]
  print(profile[0][0],a,po[0].bit_length()-1,q.bit_length()-1,i,n,p.bit_length()-1,j)
print('369 prior checkpoints; 56 surviving maps in 7 groups; 21 official masking negatives; all excluded.')
