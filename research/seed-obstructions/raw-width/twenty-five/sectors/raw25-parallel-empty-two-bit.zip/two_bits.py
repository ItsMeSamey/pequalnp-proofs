from eighth_thresholds import *
from pysat.solvers import Solver
from pysat.card import CardEnc
from pysat.formula import IDPool
op=[m for m in raw if m.bit_count()>1 or m==2]
def sat(rows,aut,cap,limit=10000):
    ids=IDPool();v=ids.id
    with Solver(name='cadical195') as s:
        sel=[[v(('s',e,m))for m in op] for e in range(2)]
        s.append_formula(CardEnc.atmost(sel[0]+sel[1],cap,vpool=ids).clauses)
        for a,b in zip(*sel):s.add_clause([-a,-b])
        for i,(p,u) in enumerate(rows):
            pos=[v(('p',e,i)) for e in range(2)]
            for j,n in enumerate(N):
                neg=[v(('n',e,j)) for e in range(2)]
                if n>>(13+u)&1 and (aut>>u&1 or unique[p,u]>>j&1):
                    for e in range(2):
                        w=[a for m,a in zip(op,sel[e]) if m>>p&1 and not m&n]
                        s.add_clause([-pos[e],neg[e],*w])
                if n>>p&1:
                    for a in (pos[0],-neg[0]):
                        for b in (pos[1],-neg[1]):s.add_clause([a,b])
        s.conf_budget(limit);return s.solve_limited()
if __name__=='__main__':
    for f in (0,1,2,4,8,16,32,64):
        rows=[(p,u) for p,u in inc if p!=1 and u!=5 and not f>>u&1]
        print(f,sat(rows,127^f,2 if f else 6),flush=True)
