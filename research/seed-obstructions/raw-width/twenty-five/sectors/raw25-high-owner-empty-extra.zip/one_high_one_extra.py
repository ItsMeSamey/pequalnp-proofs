from eighth_routes import owneropts
from eighth_thresholds import *
from itertools import combinations
CS=[c for c in range(1,256) if c.bit_count()<=2]
ALLC=(1<<len(CS))-1
contains=[sum(1<<i for i,c in enumerate(CS) if c>>v&1) for v in range(8)]
def lower(v,d,r,k):
    return sum(1<<i for i,c in enumerate(CS) if (max(0,d-(3-c.bit_count())) if c>>v&1 else max(d,r))>=k)
table={(v,d,r):tuple(lower(v,d,r,j) for j in (1,2,3)) for v in range(8) for d in range(5) for r in range(2)}
def solve(B,z,F,T):
    xm=minima(8,B,F,z,0)
    if xm is None or xm[3] or xm[2]&~T:return []
    must=xm[0]
    for p in range(13):
        if B>>p&1 and 1<<p!=z:must|=tagmask[p]
    cand=ALLC
    for u in range(7):
        if must>>u&1:cand&=~contains[u]
    if F.bit_count()==2:
        cand &=sum(1<<i for i,c in enumerate(CS) if F&c==F)
    if not cand:return []
    owned=[0]*8;req=[0]*8;opts=owneropts(B,z)
    def walk(k,cand):
        profiles=[]
        for v,q in enumerate(owned):
            pf=minima(v,q,F,z,B if F>>v&1 else 0)
            if pf is None:return 0
            profiles.append(pf)
        s1=s2=s3=s4=0
        for v,(a,b,c,d) in enumerate(profiles):
            first=a|req[v]
            s4|=d|(s3&first)|(s2&b)|(s1&c)
            s3|=c|(s2&first)|(s1&b);s2|=b|(s1&first);s1|=first
        bad=((s3&~T)|(s4&T)|must)
        while bad:
            bit=bad&-bad;bad^=bit;u=bit.bit_length()-1
            v1=v2=v3=0
            for v,pf in enumerate(profiles):
                n=sum(bool(x&bit) for x in pf)
                m1,m2,m3=table[v,n,int(bool(req[v]&bit))]
                v3|=m3|(v2&m1)|(v1&m2);v2|=m2|(v1&m1);v1|=m1
            extra=max(1,sum(bool(x&bit) for x in xm))
            spare=2+bool(T&bit)-extra
            reject=(v1,v2,v3)[spare]
            cand &=~(contains[u]|reject)
            if not cand:return 0
        if k==len(opts):return cand
        p,hs=opts[k];found=0
        for h in hs:
            old=req[h];req[h]|=tagmask[p];owned[h]|=1<<p
            found|=walk(k+1,cand&~found)
            owned[h]^=1<<p;req[h]=old
            if found==cand:break
        return found
    result=walk(0,cand)
    return [c for i,c in enumerate(CS) if result>>i&1]
if __name__=='__main__':
    import sys
    for t in map(int,sys.argv[1:]):
        for k in range(3):
            surviving=[]
            for fs in combinations(range(7),k):
                f=sum(1<<j for j in fs);surviving.extend((f,c) for c in solve(0,0,f,1<<t))
            print(t,k,len(surviving),surviving[:4],flush=True)
