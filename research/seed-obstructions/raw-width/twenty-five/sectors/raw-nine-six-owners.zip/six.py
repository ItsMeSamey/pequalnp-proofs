from verify import *
from functools import lru_cache
root=7
def domain(t):
    owners=tuple(v for v in range(7) if v!=t)
    A={(j,p):set(n for n in ns if n&stars[t]) for (j,p),ns in masks.items() if j!=t}
    M={p:set.union(*(A[j,p] for j in owners if (j,p) in A)) for p in pts if any(A.get((j,p)) for j in owners)}
    dest={p:{root,*owners} for p in M}
    for p in M:
        for h in owners:
            if p&stars[h] and A[h,p] and any(v!=h and any(n&stars[h] for n in A.get((v,p),())) for v in owners):
                dest[p].remove(h)
    while True:
        removed=0
        for p in M:
            for h in list(dest[p]-{root}):
                if any(n>>(13+h)&1 and any(q&stars[h] and h not in dest[q] and masking(q,n) for q in M) for n in M[p]):
                    dest[p].remove(h);removed+=1
        if not removed:break
    return owners,A,M,dest
def cases(t):
    o,A,M,d=domain(t)
    order=sorted(M,key=lambda p:len(d[p]))
    inc={p:{j for j in o if A.get((j,p)) and all(v==j or any(n&stars[v] for n in masks[j,p]) for v in o)} for p in M}
    a=[0]*7;h={}
    def walk(k):
        if k==len(order):
            yield h.copy(),a.copy()
            return
        p=order[k]
        for v in d[p]:
            b=a[:]
            for j in inc[p]-{v}:a[j]|=1<<v
            reach=a[:]
            for i in o:
                for j in o:
                    if reach[j]>>i&1:reach[j]|=reach[i]
            if all(x.bit_count()<=2 for x in a) and not any(reach[j]>>j&1 for j in o):
                h[p]=v
                yield from walk(k+1)
                del h[p]
            a[:]=b
    yield from walk(0)
if __name__=='__main__':
    from collections import Counter
    for t in (1,2,3,5):
        o,A,M,d=domain(t)
        print(t,len(M),[(p.bit_length()-1,sorted(ds)) for p,ds in d.items()],Counter(len(set(h.values())-{7}) for h,a in cases(t)))
