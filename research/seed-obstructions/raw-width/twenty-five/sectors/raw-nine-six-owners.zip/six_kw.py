from six import *
from itertools import combinations_with_replacement
from collections import Counter
@lru_cache(None)
def shapes(n,c):
    result=set()
    for a in combinations_with_replacement(range(1,1<<n),c):
        us={0}
        for x in a:us|={v|x for v in us if not v&x}
        result.add(tuple(sorted(us)))
    return tuple(sorted(result))
@lru_cache(None)
def valid(n,c,need,avoid):
    return sum(1<<i for i,sh in enumerate(shapes(n,c)) if any(not(need&~v or avoid&v) for v in sh))
def sweep(t):
    o,A,M,d=domain(t)
    assert all(not(p&stars[v]) for p in M for v in d[p]-{7})
    ns=list(N)+[0]; k=len(ns)-1;synt=1<<k
    bits=lambda pred:sum(1<<i for i,n in enumerate(ns[:-1]) if pred(n))
    meet={v:bits(lambda n:n&stars[v]) for v in range(7)}
    on={v:bits(lambda n:n>>(13+v)&1) for v in o}
    restricted={key:bits(lambda n:n in vv) for key,vv in A.items()}
    filtered={v:bits(lambda n:any(n in masks[v,p] for p in M if p&stars[v])) for v in o}
    assert all(any(n&p and n&stars[t] for n in N) for p in pts)
    assert all(not masks[j,p] or A[j,p] for j,p in A if p in M)
    assert all(all(v==j or any(n&stars[v] for n in masks[j,p]) for v in o) for (j,p),ns0 in A.items() if ns0)
    assert len(M) in (11,12)
    points={}
    for p in pts:
        for own in (0,1):
            features=[x for x in raw if x&p and (own or x not in M)]
            z={}
            for i,n in enumerate(ns):
                ds=[x for x in features if not x&n]
                if len(ds)<=1:
                    j=ds[0] if ds else -1
                    z[j]=z.get(j,0)|(1<<i)
            points[p,own]=z
    @lru_cache(None)
    def check(H,owned,one,two,f):
        pos=[(v,p) for v in o for p in pts if p&stars[v] and ((owned&p and A[v,p]) or f==H==v)]
        neg=meet[t] if H==7 else meet[H]
        for v,p in pos:
            if p&owned:neg|=restricted[v,p]
        if f==H:neg|=synt
        marks={}; cols={};req=[]
        def mark(x,i,b):
            if b:
                marks[x]=marks.get(x,0)|1<<i
                cols[x]=cols.get(x,0)|b
        for i,(v,p) in enumerate(pos):
            # All previous foreign signals are zero on these positives. Own positives of filter carry raw flag only.
            lb=on[v] if v==H or v!=f else filtered[v]
            if H==f==v:lb|=synt
            m=1 if v==H else (one>>v&1)+(two>>v&1)
            data=points[p,int(bool(owned&p))]
            z=data.get(-1,0)&neg
            if z&lb or z and not m:return False
            req.append(z)
            if m==1:mark(-2-v,i,z)
            for x,zz in data.items():
                if x!=-1:mark(x,i,zz&neg&(lb if m else -1))
        if any(marks[x]&marks[y] and cols[x]&cols[y] for x,y in combinations(marks,2)):return False
        for v in o:
            if not (two>>v&1) or H==v:continue
            rows=[i for i,(j,p) in enumerate(pos) if j==v]
            active=0
            for i in rows:active|=req[i]
            if not active:continue
            avoid=[]
            for i in rows:
                a=0
                for x,s in marks.items():
                    if s>>i&1:a|=cols[x]
                avoid.append(a)
            vs=-1
            while active:
                b=active&-active;active^=b
                vs&=valid(len(rows),2,sum(1<<j for j,i in enumerate(rows) if req[i]&b),sum(1<<j for j,a in enumerate(avoid) if a&b))
                if not vs:return False
        return True
    survivors=[]
    total=0
    for h,a in cases(t):
        total+=1
        for f in (-1,*o):
            for v in (*o,7):
                owned=sum(p for p,x in h.items() if x==v)
                # direct arcs to other destinations reduce duplicate allowance
                one=sum(1<<u for u in o if (a[u]&~(1<<v)).bit_count()<2)
                two=sum(1<<u for u in o if not a[u]&~(1<<v))
                if not check(v,owned,one,two,f):break
            else:survivors.append((f,h,a))
    print('profile',t,'maps',total,'survivors',len(survivors),Counter((f,len(set(h.values())-{7})) for f,h,a in survivors),flush=True)
    assert total=={1:286,2:312,3:220,5:650}[t] and not survivors
    return survivors
if __name__=='__main__':
 for t in (1,2,3,5):sweep(t)
