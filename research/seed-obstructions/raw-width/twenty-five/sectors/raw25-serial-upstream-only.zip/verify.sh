#!/bin/sh
set -eu
cd "$(dirname "$0")"
python exterior_rank.py
python serial_upstream.py
