from functools import reduce
from operator import or_
from pathlib import Path
from zipfile import ZipFile
from nine_direct_thresholds import domain,unique,inc,N
from inputs import stars
def union(xs):return reduce(or_,xs,0)
data=Path(__file__).with_name('routed-sets.txt').read_bytes()
with ZipFile(Path(__file__).with_name('raw26-eighth-local.zip')) as f:assert data==f.read('routed-sets.txt')
Bs=list(map(int,data.split()));assert len(Bs)==len(set(Bs))==107
def local_neg(B):return union(unique[p,u] for p,u in inc if B>>p&1)
def cases():
 for B in Bs:
  neg=local_neg(B);bad=union(n&8191 for j,n in enumerate(N)if neg>>j&1)
  for z in [0,*[1<<p for p in range(13) if (B&~bad)>>p&1]]:yield B,z
def modes(B,z,u,chain):
 E=(8191^2)&stars[u]&~B
 mk=sum(bool(unique[p,u]&local_neg(B)) for p in range(13) if E>>p&1)
 required=int(bool(B&stars[u]&~z));kept=[]
 for a in range(required,3):
  for b in range(3-a):
   direct=2-a-b
   credits=int(a>0)+2*bool(a or b) if chain else 2*bool(a)+2*bool(b)
   if E.bit_count()<=direct+credits and mk<=direct+2*bool(b):kept.append((a,b))
 return kept
def receivers(B,z):
 dom=domain(z);forced=local_neg(B);untouched=[u for u in range(7) if u!=5 and not B&stars[u]]
 assert all((((8191^2)&s&~B).bit_count()>=3) for s in stars)
 out=[]
 for h in range(7):
  if h in untouched or B&stars[h]&~z:continue
  Q=allowed=union(1<<p for p,hs in dom.items() if h in hs and not B>>p&1)
  total=geometric=0
  while Q:
   for t in (1,2):
    if any((Q&stars[u]).bit_count()!=t for u in untouched):continue
    total+=1
    positives=[(p,u) for p,u in inc if u in untouched and Q>>p&1]
    assert all(any(n&stars[h] and n>>p&1 for n in N) for p,u in positives)
    low=forced|sum(1<<j for j,n in enumerate(N) if n&stars[h] and any(n>>p&1 for p,u in positives))
    if not any(unique[p,u]&low for p,u in positives):geometric+=1
   Q=(Q-1)&allowed
  out.append((h,total,geometric))
 return out
if __name__=='__main__':
 A=list(cases());assert len(A)==167
 for chain in (True,False):
  keep=[(B,z)for B,z in A if all(modes(B,z,u,chain)for u in range(7))]
  print('direct' if chain else 'separate',len(A),len(keep),sorted(keep))
  if chain:assert not keep
  else:
   assert set(keep)=={(40,8),(8,0),(8,8),(32,0),(32,32)}
   for B,z in keep:
    out=receivers(B,z);print(B,z,out);assert all(n==0 for h,m,n in out)
