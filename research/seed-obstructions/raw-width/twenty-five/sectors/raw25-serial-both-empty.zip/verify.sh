#!/bin/sh
set -eu
cd "$(dirname "$0")"
python singleton_bills.py
python bypass_one_row.py
python root_serial_holders.py
python root_terminal_four.py
