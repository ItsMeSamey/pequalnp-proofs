from collections import Counter
from inputs import stars
from nine_direct_thresholds import inc,N,unique
from singleton_bills import audit
assert sum(audit().values())==167
C=Counter();surv=[]
for Q in range(8192):
    if Q&2 or any((Q&stars[u]).bit_count()<3 for u in range(7) if u!=5):continue
    C['eligible']+=1
    high=[(p,u)for p,u in inc if u!=5 and Q>>p&1 and (Q&stars[u]).bit_count()==3]
    low=sum(1<<j for j,n in enumerate(N)if any(n>>p&1 for p,u in high))
    if any(unique[p,u]&low for p,u in high):continue
    C['high-consistent']+=1
    if any(sum(bool(unique[p,u]&low)for p,u in inc if u==v and Q>>p&1)>=2 for v in range(7)if v!=5):continue
    surv.append(Q)
assert C=={'eligible':75,'high-consistent':4} and surv==[8189]
print(C,surv)
