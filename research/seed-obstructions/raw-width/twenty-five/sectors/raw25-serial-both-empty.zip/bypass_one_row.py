from singleton_bills import audit
from nine_direct_thresholds import domain,raw,unique,N,inc
from inputs import stars
assert sum(audit().values())==167
for u,p in [(2,8),(3,5)]:
    assert [q for q,h in domain(0).items() if 5 in h and stars[u]>>q&1]==[p]
    assert (p,u) in inc
a=N.index(1283|(1<<13));b=N.index(4130|(23<<13))
assert 1283&stars[5] and 1283>>8&1
assert 4130&stars[5] and 4130>>5&1
assert unique[8,2]>>b&1
optional=[m for m in raw if m==2 or m.bit_count()>1]
assert len(optional)==19 and all(not (m>>8&1) or m&4130 for m in optional)
print('verified',a,b)
