# Four witnesses exclude the serial all-root terminal

Assume all twelve compulsory singletons are held at root, X has one physical read into root and one into Y, and Y is read twice at root. Regional singleton bills require all six four-point tags to feed X once and root directly once. None feeds Y directly. Y has only its X port, optional point primitives and possibly mandatory tag 5. On a compulsory positive before root every foreign mandatory owner is zero. The additional endpoint X has no local compulsory singleton. Whenever a masking negative in unique[p,u] is taken, the possibly filtered mandatory u is high there because the holder of p follows u, and every optional primitive active on p is dominated there.

The four local tagged rectangles required for tag 0 need the four distinct available root leaves: direct mandatory 0, X, Y, Y. In particular the X leaf is high on at least one positive (p,0). The star of tag 0 consists of points 7,9,2,6. For each possible p the following table provides two actual negatives A and B, in the form (point mask, line mask), and a point b.

| p | b | A | B |
|---|---|---|---|
| 7 | 10 | (1283,1) | (5123,5) |
| 9 | 3 | (6408,1) | (5130,5) |
| 2 | 3 | (2314,9) | (5130,5) |
| 6 | 3 | (6432,1) | (4138,21) |

Both A and B lie in unique[p,0]. The input comparison above forces X to be high on BOTH negatives. A contains point 8 and B contains b. Compare (8,1) against A and (b,1) against B. On each comparison root point inputs are dominated because the negative contains the positive point. X is already high on the negative. The optional inputs of Y are dominated, X cannot distinguish, and its only possible incoming mandatory, owner 5, is zero on these tag-1 positives. Thus Y cannot distinguish either. All other foreign mandatory root inputs vanish on the positive. Both comparisons must be assigned in the root's deterministic KW protocol to the unique physical direct tag-1 leaf.

Its rectangle then includes the crossed comparison (8,1) against B. The unique physical raw point-8 leaf must already own that cell. Indeed on (8,1) against a negative in unique[8,1] every root input except raw singleton 8 is dominated, including both extras with only owner 1 potentially active and itself dominated. This makes (8,1) a positive row of the point-8 leaf's rectangle. On (8,2) against B the same reasoning applies since B belongs to unique[8,2], putting B in that rectangle's negative columns. Distinct leaves' KW rectangles cannot both cover the crossed comparison. This contradiction works for all four possible high points, with any allowed filter and any optional point allocation.

Run python root_terminal_four.py. serial_rank.py also checks a broader 4^6 enumeration with the same obstruction. Neither test uses a SAT solver for search.
