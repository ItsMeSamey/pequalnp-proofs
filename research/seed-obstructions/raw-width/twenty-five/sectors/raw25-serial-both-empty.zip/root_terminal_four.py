from singleton_bills import audit
from nine_direct_thresholds import N,inc,unique
from inputs import stars
assert sum(audit().values())==167
cases=[(7,10,59,2),(9,3,172,14),(2,3,174,14),(6,3,188,42)]
assert {p for p,b,i,j in cases}=={p for p,u in inc if u==0}
assert (8,1) in inc and (8,2) in inc and unique[8,1]
for p,b,i,j in cases:
    assert (b,1) in inc
    A,B=N[i],N[j]
    assert unique[p,0]>>i&1 and unique[p,0]>>j&1
    assert A>>8&1 and B>>b&1 and unique[8,2]>>j&1
    print(p,b,(A&8191,A>>13),(B&8191,B>>13))
