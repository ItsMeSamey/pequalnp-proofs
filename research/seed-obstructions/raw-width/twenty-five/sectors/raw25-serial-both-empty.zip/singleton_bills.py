from collections import Counter
from nine_direct_thresholds import minima,domain
from inputs import stars
from itertools import product
def audit():
    cnt=Counter()
    for h in range(8):
        F=127 if h==7 else 127^(1<<h)
        for u,T in enumerate(stars):
            if h==u:continue
            T&=sum(1<<p for p,hs in domain(0).items() if h in hs)
            q=T
            while q:
                profile=minima(h,q,F,0,0)
                assert profile is not None
                value=sum(bool(x>>u&1) for x in profile)
                assert value==q.bit_count()
                cnt[h==7,value]+=1
                q=(q-1)&T
    return cnt
if __name__=='__main__':
    print(sorted(audit().items()))
