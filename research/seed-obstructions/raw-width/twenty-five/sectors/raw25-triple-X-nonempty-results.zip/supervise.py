from pathlib import Path
from subprocess import run
from time import monotonic
import sys
start=0
while start<167:
    if Path('hold-native').exists():
        print('HELD',start,flush=True)
        break
    count=min(12,167-start)
    path=Path(f'case-{start:03}.log')
    if not path.exists():
        with path.open('x') as out:
            now=monotonic()
            result=run(['flock','-F','/workspace/scratch/pnp-native-search.lock','timeout','60','nice','-n','15',sys.executable,'-u','search.py','--start',str(start),'--count',str(count)],stdout=out)
            print('STAGE',start,count,result.returncode,round(monotonic()-now,2),flush=True)
            if result.returncode not in (0,124):raise SystemExit(2)
    rows=[l.split(maxsplit=5) for l in path.read_text().splitlines() if l.startswith('CASE ')]
    assert [int(r[1]) for r in rows]==list(range(start,start+len(rows)))
    print('CURSOR',start,len(rows),sum(int(r[4]) for r in rows),flush=True)
    if not rows:raise SystemExit(2)
    start+=len(rows)
if start==167:print('ALL CASES FINISHED',flush=True)
