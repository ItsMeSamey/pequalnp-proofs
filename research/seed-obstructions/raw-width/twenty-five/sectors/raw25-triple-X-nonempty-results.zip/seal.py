from ast import literal_eval
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
from search import cases
from sys import argv
rows={}
for source in sorted(Path('.').glob('case-*.log')):
    for line in source.read_text().splitlines():
        if not line.startswith('CASE '):continue
        _,idx,b,z,total,items=line.split(maxsplit=5)
        key=int(idx)
        assert key not in rows
        results=literal_eval(items)
        assert len(results)==int(total)
        assert len(results)==len(set(results))
        rows[key]=(int(b),int(z),results)
domain=cases()
assert sorted(rows)==list(range(len(domain)))
assert all(rows[i][:2]==item for i,item in enumerate(domain))
remaining=sum(len(row[2]) for row in rows.values())
print('VERIFIED',len(domain),sum(bool(x[2]) for x in rows.values()),remaining)
stage=Path('n25-triple-X-nonempty-stage.zip')
if not stage.exists():
    stage=Path('/workspace/scratch/syn_bounds/p19') / stage
assert sha256(stage.read_bytes()).hexdigest()=='87c805cf1414ddfdbac57e632687ef038ffa7466844a51d21579d17dc487d52b'
with ZipFile(stage) as src:
    for name in src.namelist():
        assert Path(name).read_bytes()==src.read(name),name
if len(argv)>1:
    destination=Path(argv[1])
    with ZipFile(destination,'x',compression=ZIP_DEFLATED) as out:
        for p in [stage,Path('seal.py'),Path('supervise.py'),Path('supervisor.log'),*sorted(Path('.').glob('case-*.log'))]:
            out.write(p,p.name)
    print('SHA256',sha256(destination.read_bytes()).hexdigest())
