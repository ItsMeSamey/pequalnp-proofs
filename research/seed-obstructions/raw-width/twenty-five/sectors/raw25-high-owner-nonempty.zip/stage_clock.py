import sys,time,resource
import high_stage as s
start=time.monotonic()
cpu=time.process_time()
original=s.solve
prev=[None,start,cpu]
def stamp():
    if prev[0] is not None:
        print('CASE_TIME',*prev[0],round(time.monotonic()-prev[1],3),round(time.process_time()-prev[2],3),flush=True)
def timed(b,z,f,T):
    if (b,z)!=prev[0]:
        stamp()
        prev[:]=[(b,z),time.monotonic(),time.process_time()]
    return original(b,z,f,T)
s.solve=timed
s.main(*map(int,sys.argv[1:]))
stamp()
print('RUNTIME',round(time.monotonic()-start,3),round(time.process_time()-cpu,3),resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,flush=True)
