from high_local import run
from high_one_nonempty import solve
from eighth_thresholds import inc,unique,N,combinations
def zchoices(b):
    neg=0
    for p,u in inc:
        if b>>p&1:neg|=unique[p,u]
    return [0]+[1<<p for p in range(13) if b>>p&1 and not any(neg>>i&1 and n>>p&1 for i,n in enumerate(N))]
def main(t,start,count):
    masks=sorted(run(t),key=lambda b:(-b.bit_count(),b))
    cases=[(b,z) for b in masks for z in zchoices(b)]
    selected=cases[start:start+count]
    for b,z in selected:
        high=[]
        for nf in range(3):
            for fs in combinations(range(7),nf):
                f=sum(1<<u for u in fs)
                high.extend((f,c) for c in solve(b,z,f,1<<t))
        print('CASE',t,b,z,len(high),high,flush=True)
    print('CHECKPOINT',t,start,len(selected),len(cases),flush=True)
if __name__=='__main__':
    import sys
    main(*map(int,sys.argv[1:]))
