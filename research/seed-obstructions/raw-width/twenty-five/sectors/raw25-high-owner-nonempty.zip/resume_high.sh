#!/bin/bash
set -u
mkdir -p high-checkpoints
for t in 0 1 2 3 4 5 6; do
    offset=0
    if [ "$t" = 0 ]; then offset=13; fi
    while true; do
        if [ -e hold-native ]; then echo "HELD $t $offset"; exit 0; fi
        name="high-checkpoints/t$t-at$offset.log"
        if [ ! -s "$name" ]; then
            flock -F /workspace/scratch/pnp-native-search.lock timeout 60 nice -n 15 python -u stage_clock.py "$t" "$offset" 25 >"$name"
        fi
        read -r done total < <(python - "$name" <<'PY'
import sys
rows=open(sys.argv[1]).read().splitlines()
c=[r for r in rows if r.startswith('CASE ')]
e=[r for r in rows if r.startswith('CHECKPOINT ')]
print(len(c),int(e[-1].split()[-1]) if e else -1)
PY
)
        echo "CURSOR $t $offset $done $total"
        if [ "$done" = 0 ]; then
            if [ "$offset" = "$total" ]; then break; fi
            exit 2
        fi
        offset=$((offset+done))
        if [ "$offset" = "$total" ]; then break; fi
    done
done
echo 'ALL LABELS FINISHED'
