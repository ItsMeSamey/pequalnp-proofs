from eighth_routes import owneropts
from nine_direct_thresholds import *
from itertools import combinations
CS=[c for c in range(1,256) if c.bit_count()<=2]
ALLC=(1<<len(CS))-1
contains=[sum(1<<i for i,c in enumerate(CS) if c>>v&1) for v in range(8)]
@lru_cache(None)
def counts(v,d,r,direct):
    cst=[max(direct,d-(3-c.bit_count())) if c>>v&1 else max(d,r) for c in CS]
    return tuple(sum(1<<i for i,n in enumerate(cst) if n>=k) for k in (1,2,3))
@lru_cache(maxsize=16384)
def forced_tags(q,xn):
    return sum(1<<u for u in range(7) if any(q>>p&1 and j==u and xn&unique[p,u] for p,j in inc))
def solve(B,z,F,T):
    xn=0
    for p,u in inc:
        if B>>p&1:xn|=unique[p,u]
    xm=minima(8,B,F,z,0)
    if xm is None or xm[3] or xm[2]&~T:return []
    must=xm[0]
    for p in range(13):
        if B>>p&1 and 1<<p!=z:must|=tagmask[p]
    cand=ALLC
    for u in range(7):
        if must>>u&1:cand&=~contains[u]
    if F.bit_count()==2:
        cand &=sum(1<<i for i,c in enumerate(CS) if F&c==F)
    if not cand:return []
    owned=[0]*8;req=[0]*8;opts=owneropts(B,z)
    def walk(k,cand):
        profiles=[];partials=[];marks=[]
        for v,q in enumerate(owned):
            pf=minima(v,q,F,z,B if F>>v&1 else 0)
            if pf is None:return 0
            profiles.append(pf)
            dr=minima(v,q,F,z,B if F>>v&1 else 0,xn) if xn else (0,0,0,0)
            if dr is None:return 0
            partials.append(dr)
            marks.append(forced_tags(q,xn))
        s1=s2=s3=s4=0
        for v,(a,b,c,d) in enumerate(profiles):
            first=a|req[v]
            s4|=d|(s3&first)|(s2&b)|(s1&c)
            s3|=c|(s2&first)|(s1&b);s2|=b|(s1&first);s1|=first
        bad=((s3&~T)|(s4&T)|must)
        while bad:
            bit=bad&-bad;bad^=bit;u=bit.bit_length()-1
            v1=v2=v3=0
            for v,pf in enumerate(profiles):
                n=sum(bool(x&bit) for x in pf)
                direct=max(int(bool(marks[v]&bit)),sum(bool(m&bit) for m in partials[v]))
                m1,m2,m3=counts(v,n,int(bool(req[v]&bit)),direct)
                v3|=m3|(v2&m1)|(v1&m2);v2|=m2|(v1&m1);v1|=m1
            extra=max(1,sum(bool(x&bit) for x in xm))
            spare=2+bool(T&bit)-extra
            reject=(v1,v2,v3)[spare]
            cand &=~(contains[u]|reject)
            if not cand:return 0
        if k==len(opts):return cand
        p,hs=opts[k];found=0
        for h in hs:
            old=req[h];req[h]|=tagmask[p];owned[h]|=1<<p
            found|=walk(k+1,cand&~found)
            owned[h]^=1<<p;req[h]=old
            if found==cand:break
        return found
    result=walk(0,cand)
    return [c for i,c in enumerate(CS) if result>>i&1]
