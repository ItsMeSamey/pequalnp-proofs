"""Verify that archived case records cover the exact input domain for each label."""
from pathlib import Path
from high_local import run
from high_stage import zchoices
from ledger_high import paths, records
import sys

def verify(labels):
    table, totals = records(paths())
    for label in labels:
        masks = run(label)
        expected = {(label, mask, option) for mask in masks for option in zchoices(mask)}
        actual = {key for key in table if key[0] == label}
        if actual != expected or totals.get(label) != len(expected):
            raise ValueError((label, len(expected - actual), len(actual - expected), totals.get(label)))
        remaining = sum(len(table[key]) for key in actual)
        print('VERIFIED', label, len(masks), len(actual), remaining, flush=True)

if __name__ == '__main__':
    verify([int(value) for value in sys.argv[1:]] or range(7))
