from eighth_thresholds import *
pids=[p for p in range(13) if compulsory>>p&1]
@lru_cache(None)
def geom(B,neg):
    rows=[(p,u) for p,u in inc if B>>p&1];out=[0]*7
    for u in range(7):
        ps=[p for p,v in rows if u==v]
        if not ps:continue
        A=neg&~on[u];cols=set()
        while A:
            bit=A&-A;A^=bit;n=N[bit.bit_length()-1]
            yes=sum(1<<i for i,p in enumerate(ps) if n>>p&1)
            no=sum(1<<i for i,p in enumerate(ps) if not(n>>p&1) and tables[p,True].get(raw.index(1<<p),0)&bit and n>>13&tagmask[p])
            if yes:cols.add((yes,no))
        if not cols:continue
        for k in (1,2,3):
            live=-1
            for yes,no in cols:
                live&=shape_bits(len(ps),k,yes,no)
                if not live:break
            if live:break
        else:k=4
        out[u]=k
    return out
def fit(B,T):
    neg=0
    for p,u in inc:
        if B>>p&1:neg|=unique[p,u]
    while True:
        m=geom(B,neg)
        caps=[2+(1<<u==T) for u in range(7)]
        if any(a>b for a,b in zip(m,caps)):return None
        force=[u for u in range(7) if m[u]==caps[u]]
        more=neg
        for u in force:more|=meeting[u]
        if more==neg:break
        neg=more
    return not any(neg&unique[p,u] for p,u in inc if u in force and compulsory>>p&1 and not(B>>p&1))
def run(t):
    kept=set();hereditary={0}
    for k in range(1,13):
        for bs in combinations(pids,k):
            b=sum(1<<p for p in bs)
            if not all((b^(1<<p)) in hereditary for p in bs):continue
            z=fit(b,1<<t)
            if z is not None:hereditary.add(b)
            if z:kept.add(b)
    print(t,len(kept),[sum(b.bit_count()==k for b in kept) for k in range(1,8)],flush=True)
    return kept
if __name__=='__main__':
    import sys
    for t in map(int,sys.argv[1:]):run(t)
