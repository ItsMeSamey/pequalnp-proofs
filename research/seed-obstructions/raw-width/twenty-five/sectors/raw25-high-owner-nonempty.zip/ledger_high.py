import ast
from collections import defaultdict
from pathlib import Path
def records(paths):
    table={};ends={};amount={}
    for p in paths:
        for line in p.read_text().splitlines():
            w=line.split()
            if not w:continue
            if w[0]=='CHECKPOINT':
                t,offset,n,total=map(int,w[1:]);amount[t]=total
            elif w[0]=='CASE':
                a,t,b,z,k,pts=line.split(' ',5)
                key=tuple(map(int,(t,b,z)))
                val=ast.literal_eval(pts)
                assert len(val)==int(k) and len(set(val))==int(k)
                assert key not in table,(p,key)
                table[key]=val
    return table,amount
def paths():
    here=Path(__file__).parent
    return [here/'high-t0-case0.log',here/'high-t0-offset1-12.log',*sorted((here/'high-checkpoints').glob('*.log'))]
if __name__=='__main__':
    table,amount=records(paths())
    for t in sorted(set(k[0] for k in table)):
        q={k:v for k,v in table.items() if k[0]==t}
        print(t,len(q),amount.get(t),sum(map(len,q.values())),[k for k,v in q.items() if v][:8],flush=True)
