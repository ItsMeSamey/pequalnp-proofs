"""Seal a complete seven-label production record."""
from hashlib import sha256
from pathlib import Path
from sys import argv
from zipfile import ZipFile, ZIP_DEFLATED
from ledger_high import paths, records
from verify_high_coverage import verify

here = Path(__file__).resolve().parent
if __name__ == '__main__':
    table, sizes = records(paths())
    assert set(sizes) == set(range(7)) and not any(table.values())
    verify(range(7))
    manifest = here / 'high-stage-inputs.sha256'
    files = [manifest, *paths()]
    for line in manifest.read_text().splitlines():
        digest, name = line.split()
        item = here / name
        assert sha256(item.read_bytes()).hexdigest() == digest, name
        files.append(item)
    files.extend(here / name for name in ('ledger_high.py','verify_high_coverage.py','stage_clock.py','resume_high.sh','package_high.py','high-supervisor.log','high-nonempty.md'))
    dest = Path(argv[1])
    with ZipFile(dest, 'x', compression=ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(here))
    with ZipFile(dest) as archive:
        assert archive.testzip() is None
    print('SHA256',sha256(dest.read_bytes()).hexdigest(),dest)
