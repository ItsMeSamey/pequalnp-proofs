from nine_direct_thresholds import *
from eighth_routes import owneropts
@lru_cache(None)
def req(q):
    return sum(1<<u for u in range(7) if any(q>>p&1 and j==u for p,j in inc))
@lru_cache(None)
def npoints(p):
    return sum(1<<i for i,n in enumerate(N) if n>>p&1)
def feasible(pts,F):
    r=pts[-1];pf=[minima(h,q,F,0,0) for h,q in enumerate(pts)]
    if None in pf:return False
    out=[sum(max(int(bool(req(pts[h])>>u&1)),sum(m>>u&1 for m in pf[h])) for h in range(7)) for u in range(7)]
    qmin=[sum(m>>u&1 for m in pf[7]) for u in range(7)]
    must=0;no_root=0;neg=0
    while True:
        old=(must,no_root,neg)
        rm=minima(7,r,F,0,0,neg) if neg else (0,0,0,0)
        if rm is None:return False
        for u in range(7):
            bit=1<<u;low=sum(m>>u&1 for m in rm)
            if any(r>>p&1 and j==u and unique[p,u]&neg for p,j in inc):low=max(low,1)
            direct=max(qmin[u],bool(req(r)&bit));via=1+max(low,qmin[u]-3,0)
            if out[u]+min(direct,via)>2:return False
            if out[u]+direct>2:must|=bit
            if 2-out[u]-bool(must&bit)==0:no_root|=bit
        for p,u in inc:
            if r>>p&1 and no_root>>u&1:neg|=npoints(p)
        if old==(must,no_root,neg):return True
def solve(F):
    opts=owneropts(0,0);pts=[0]*8;out=[]
    def visit(k):
        if not feasible(pts,F):return
        if k==len(opts):out.append(tuple(pts));return
        p,hs=opts[k]
        for h in hs:
            pts[h]|=1<<p;visit(k+1);pts[h]^=1<<p
    visit(0);return out
if __name__=='__main__':
    import sys
    for f in map(int,sys.argv[1:]):
        out=solve(f);print(f,len(out),len({p[-1] for p in out}),out[:1],flush=True)
