from eighth_thresholds import *
from itertools import combinations
pts=[[p for p,j in inc if j==u and p!=1] for u in range(7)]
pm={p:0 for r in pts for p in r}
for p,u in inc:
    if p!=1:
        assert unique[p,u]
        pm[p]|=unique[p,u]
point_on=[sum(1<<i for i,n in enumerate(N) if n>>p&1) for p in range(13)]
def fails_one(points,cols):
    row=[point_on[p]&cols for p in points]
    needed=0
    for x in row:needed|=x
    return any(r and needed&pm[p] for p,r in zip(points,row))
allcols=(1<<len(N))-1
for u in range(7):
    assert all(fails_one(pair,allcols) for pair in combinations(pts[u],2))
for f in range(7):
    auto=[u for u in range(7) if u!=f and len(pts[u])>=4]
    cols=0
    for u in auto:cols|=on[u]
    bad=[u for u in range(7) if u!=f and fails_one(pts[u],cols)]
    assert bad
    print(f,auto,bad,flush=True)
