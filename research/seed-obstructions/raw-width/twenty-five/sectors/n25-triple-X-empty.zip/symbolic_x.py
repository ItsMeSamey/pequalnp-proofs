from eighth_thresholds import *
from pysat.formula import IDPool
from pysat.card import CardEnc
from pysat.solvers import Solver
opts=[m for m in raw if m.bit_count()>1 or m==2]
def check(root,counts,F,limit=2000):
    pp=[(p,u) for p,u in inc if root>>p&1 and not F>>u&1]
    ns=N
    fixed=[1<<p for p in range(13) if root>>p&1]+opts+[1<<(13+u) for u in range(7) if not F>>u&1 for _ in range(counts[u])]
    vs=IDPool();v=vs.id
    with Solver(name='cadical195') as sol:
        possible=[v(('xp',i)) for i in range(len(pp))]
        lows=[v(('xn',j)) for j in range(len(ns))]
        for i,(p,u) in enumerate(pp):
            for j,n in enumerate(ns):
                if n>>(13+u)&1 and all(not(m>>p&1) or m&n for m in opts):
                    sol.add_clause([-possible[i],lows[j]])
                positive=(1<<p)|(1<<(13+u));marks=[]
                for a in range(len(fixed)+3):
                    if a<len(fixed) and not (fixed[a]&positive and not fixed[a]&n):continue
                    r=v(('r',a,i));c=v(('c',a,j));z=v(('z',a,i,j))
                    if a>=len(fixed):
                        sol.add_clause([-r,possible[i]]);sol.add_clause([-c,-lows[j]])
                    sol.add_clause([-z,r]);sol.add_clause([-z,c]);sol.add_clause([-r,-c,z]);marks.append(z)
                sol.add_clause(marks)
                if len(marks)>1:sol.append_formula(CardEnc.atmost(marks,1,vpool=vs).clauses)
        sol.conf_budget(limit);return sol.solve_limited()
if __name__=='__main__':
    print(check(8189,[1]*7,0,5000),flush=True)
