from pathlib import Path
import subprocess
import sys
from nine_direct_thresholds import minima
root = Path(__file__).resolve().parent
def replay(script, ledger, *args):
    actual = subprocess.check_output([sys.executable, str(root/script), *args], cwd=root)
    expected = (root/ledger).read_bytes()
    assert actual == expected, (script, actual)
    print(script, 'verified', flush=True)
fs = [0,1,2,4,8,16,32,64]
for f in fs:
    profile = minima(7, 8189, f, 0, 0)
    assert [sum(x >> u & 1 for x in profile) for u in range(7)] == [4,4,4,4,4,3,4]
if '--full' in sys.argv:
    replay('triple_extra_empty.py','triple-empty.log')
    replay('triple_root_negative.py','triple-negatives-all.log',*map(str,fs))
replay('two_rows.py','two-rows.log')
if '--full' in sys.argv:
    replay('symbolic_x.py','symbolic-pilot.log')
else:
    assert (root/'symbolic-pilot.log').read_text() == 'False\n'
