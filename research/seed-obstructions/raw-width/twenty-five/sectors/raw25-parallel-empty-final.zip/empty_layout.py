from pathlib import Path
import sys
from nine_direct_thresholds import *
from eighth_routes import owneropts
opts=owneropts(0,0)
def solve(F,CY):
 owned=[0]*8;reqs=[0]*8
 count=[0,0];layouts=[]
 def walk(k):
  fs=[minima(h,q,F,0,0) for h,q in enumerate(owned)]
  if None in fs:return
  for u in range(7):
   bit=1<<u;valid=False
   for mode in range(4):
    if CY==160 and u==5 and mode:continue
    c=mode.bit_count()
    for h in range(8):
     ports=(2 if mode&1 and h==7 else 0)+((2 if CY==128 else 1)if mode&2 and CY>>h&1 else 0)
     cost=sum(bool(x&bit)for x in fs[h])
     c+=max(0,cost-ports,int(not ports and bool(reqs[h]&bit)))
    if c<=2:valid=True;break
   if not valid:return
  if k==len(opts):
   count[bool(any(owned[:7]))]+=1
   if len(layouts)<6:layouts.append(list(owned))
   return
  p,hs=opts[k]
  for h in hs:
   old=reqs[h];owned[h]|=1<<p;reqs[h]|=tagmask[p]
   walk(k+1)
   reqs[h]=old;owned[h]^=1<<p
 walk(0)
 print(F,CY,count,layouts,flush=True)
if __name__=='__main__':
 for f in map(int,sys.argv[2:]):solve(f,int(sys.argv[1]))
