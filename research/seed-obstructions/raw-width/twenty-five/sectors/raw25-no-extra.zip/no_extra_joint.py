from eighth_thresholds import *
from eighth_routes import owneropts
def run(F):
    opts=owneropts(0,0);owned=[0]*8;req=[0]*8;out=[]
    def go(k):
        s1=s2=s3=s4=0
        for h,points in enumerate(owned):
            ms=minima(h,points,F,0,0)
            if ms is None:return
            a,b,c,d=ms;first=a|req[h]
            s4|=d|(s3&first)|(s2&b)|(s1&c)
            s3|=c|(s2&first)|(s1&b)
            s2|=b|(s1&first);s1|=first
        if s3.bit_count()+s4.bit_count()>2:return
        if k==len(opts):out.append((tuple(owned),s3,s4));return
        p,hs=opts[k]
        for h in hs:
            old=req[h];req[h]|=tagmask[p];owned[h]|=1<<p
            go(k+1)
            owned[h]^=1<<p;req[h]=old
    go(0);return out
if __name__=='__main__':
    for f in (0,1,2,4,8,16,32,64):
        keep=run(f);print(f,len(keep),keep[:1],flush=True)
