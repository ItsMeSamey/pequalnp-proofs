from itertools import combinations
from pathlib import Path
from input import raw_samples, point_obligations
src=Path(__file__).with_name('L-meta-18968.json')
P,N,_=raw_samples(src)
raw,_=point_obligations(src)
stars=[sum(w&8191 for w in P if w>>13==1<<t) for t in range(7)]
pts=[1<<i for i in range(13)]
def masking(p,n):
    return not p&n and all(m==p or not m&p or m&n for m in raw)
masks={(t,p):[n for n in N if n>>(13+t)&1 and masking(p,n)] for t in range(7) for p in pts if p&stars[t]}
private=[{p for p in pts if stars[t]&p and any(masking(p,a|b) for a,b in combinations([q for q in pts if not q&stars[t]],2))} for t in range(7)]
keep=[]
for o in range(1,8):
    for O in combinations(range(7),o):
        ext={p for (t,p),ns in masks.items() if t not in O and any(all(n&stars[u] for u in O) for n in ns)}
        D={p for p in pts if sum(p in private[t] for t in O)+(p in ext)>=2}
        assert len(D)>=o+2
        if len(D)>o+2:continue
        def possible(q,p):
            return not any(n&p for (t,x),ns in masks.items() if x==q for n in ns)
        reject=False
        for p in sorted(D):
            dirs=[t for t in O if p in private[t]]
            if not any(q!=p and possible(q,p) for q in D):
                if len(dirs)>=3 or len(dirs)==2 and p in ext:
                    print('reject',O,'via',p.bit_length()-1,dirs,p in ext)
                    reject=True
                    break
        if not reject:
            print('retain',O,sorted(p.bit_length()-1 for p in D))
            keep.append(O)
            assert all(not possible(q,p) for p in D for q in D if p!=q)
assert keep==[(1,),(2,),(3,),(5,)]
