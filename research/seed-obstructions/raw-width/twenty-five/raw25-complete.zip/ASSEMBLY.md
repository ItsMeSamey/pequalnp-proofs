# Raw width of the normalized residual

In the live normalized seed-deleted problem the s binary gates and n distinct raw inputs form a connected DAG with one output. Counting physical operand occurrences, k=s+1−n is the sum of fanout minus one over raw inputs and nonoutput gates. The fixed original seed, discarded lines and upstream gates are outside these counts. All seven retained line inputs are compulsory. Raw26-complete.zip supplies the previous n≤26 bound for s≤33.

The source raw-eight-mandatory.zip excludes k≤7 and at k=8 requires seven distinct sole-resident mandatory line owners. If n=26 and s≤33 then k≤8. Seven mandatory repeated owners use seven units of k. The eighth unit either gives one mandatory owner three outgoing occurrences (A1), or gives a further line-free endpoint X two outgoing occurrences (A2). This accounts for repeated raw wires, repeated internal gates and multiple operand occurrences sharing a destination.

Raw26-A1-local.zip excludes the seven A1 choices. Raw26-empty-extra.zip excludes A2 with no compulsory singleton local to X, for all 1,696 possible source/destination patterns, including no mandatory sources. For nonempty local set B at X, raw26-eighth-holder.zip establishes the per-point holder and baseline restrictions, and raw26-eighth-local.zip reduces all 4,095 nonempty sets to 107. Raw26-nonempty-extra.zip checks 107 zero and 60 nonzero baseline choices on these sets. All 48 optimistic tagged placements are eliminated by the final direct-routing test. Its fresh end-to-end replay is python verify_eighth_nonempty.py --full.

Thus the normalized size-at-most-33 problem excludes n=26. The stronger uniform consequence n≤s−8 follows if the same point-count licensing is applied for arbitrary k=8: n=s−7≤26 and hence there are at most 19 point primitives, including the 12 compulsory singletons. The proofs grant all optional primitives or allow up to seven. No actual computation requires allocating a nonexistent optional input. This uniform transfer should be distinguished from the primary exact-n=26 coverage in reporting review status.

The architectural condition leaves the full separator question open.
