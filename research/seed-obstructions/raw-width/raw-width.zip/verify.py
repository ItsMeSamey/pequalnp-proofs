from itertools import combinations
from forest import solve
for ordinary in combinations(range(7), 3):
    possible, _ = solve(ordinary, limit=31)
    assert not possible, ordinary
print("All 35 labeled private triples excluded at raw point cap 31.")
