from pathlib import Path
from collections import Counter
import sys
root=Path(__file__).resolve().parent
from inputs import P,N
pt={1<<i for i in range(13)}
for j in range(6):
 a=(1<<j)|(1<<(j+1));b=(1<<(j+3))|(1<<((j+9)%13));pt.update((a,b,a|b))
features=sorted(pt)+[(1<<i)<<13 for i in range(7)]
enc=lambda r:sum(1<<i for i,m in enumerate(features) if r&m)
rawP=[enc(r)for r in P];rawN=[enc(r)for r in N]
diff=set(p&~n for p in rawP for n in rawN)
assert 0 not in diff
forced=sum(d for d in diff if d.bit_count()==1)
optional=[i for i in range(38)if not forced>>i&1]
clauses=set(sum(1<<j for j,m in enumerate(optional)if d>>m&1)for d in diff if not d&forced)
clauses={m for m in clauses if not any(x!=m and x&m==x for x in clauses)}
counts=Counter()
for m in range(1<<len(optional)):
 n=forced.bit_count()+m.bit_count()
 if n<=30 and all(m&c for c in clauses):counts[n]+=1
print('forced',forced.bit_count(),'indices',[i for i in range(38)if forced>>i&1])
print('optional clauses',sorted(clauses))
print('raw-input distinction subsets of width <=30',sorted(counts.items()),'total',sum(counts.values()))
