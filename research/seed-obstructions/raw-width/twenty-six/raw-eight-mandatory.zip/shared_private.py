from forest import *
def forced_raw(t):
    forced=set()
    for x in range(13):
        p=1<<x
        if not stars[t]&p:continue
        ext=[1<<j for j in range(13) if not stars[t]>>j&1]
        if any(all(m==p or not m&p or m&(a|b) for m in raw) for a,b in combinations(ext,2)):
            forced.add(p)
    return forced
def survives(O):
    forbidden=set.union(*(forced_raw(i) for i in O))
    ext=set(raw)-forbidden
    for p in P:
        j=(p>>13).bit_length()-1
        if j in O:continue
        for n in N:
            if not n>>(13+j)&1 or not all(n&stars[i] for i in O):continue
            if not any(m&p and not m&n for m in ext):return False
    return True
if __name__=='__main__':
    for r in (4,5,6):
        values=[O for O in combinations(range(7),7-r) if survives(O)]
        print(r,len(values),values)
