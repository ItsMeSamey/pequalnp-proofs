from socket_marks import *
from functools import lru_cache
single=lru_cache(None)(forced_raw)
markneg={p:[n for n in N if any((w&8191)==p and n&(w&~8191)for w in P)and all(m==p or not m&p or m&n for m in raw)]for p in [1<<i for i in range(13)]}
required={p for p,n in markneg.items() if n}
assert len(required)==12
for p,q in combinations(required,2):
 assert any(n&q for n in markneg[p])or any(n&p for n in markneg[q])
def roles(O):
 private,ext=rows(O)
 return {p for p in private if sum(p in single(t)for t in O)+(p in ext)>=2}
if __name__=='__main__':
 for o in range(1,8):
  histogram=Counter()
  for O in combinations(range(7),o):
   D=roles(O)
   assert D<=required and len(D)>o+1
   histogram[len(D)]+=1
  print(o,histogram)
