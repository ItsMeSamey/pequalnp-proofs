from shared_private import *
from collections import Counter
def marks(O):
    guard=set.union(*(forced_raw(t)for t in O));exterior=set()
    for row in P:
        j=(row>>13).bit_length()-1
        if j in O:continue
        for n in N:
            if not n>>(13+j)&1 or not all(n&stars[t]for t in O):continue
            if all(not m&row or m&n or m==(row&8191) for m in raw):
                exterior.add(row&8191)
    return guard & exterior
if __name__=='__main__':
    for r in (4,5,6):
        print(r,Counter(len(marks(o))for o in combinations(range(7),7-r)))
