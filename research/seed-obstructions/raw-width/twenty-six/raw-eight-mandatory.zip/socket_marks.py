from marks_private import *
def rows(O):
    a={};b={}
    allowed=lambda p,n:all(m==p or not m&p or m&n for m in raw)
    for t in O:
        outside=[1<<j for j in range(13) if not stars[t]>>j&1]
        for i in range(13):
            p=1<<i
            if stars[t]&p:
                for x,y in combinations(outside,2):
                    if allowed(p,x|y):a.setdefault(p,set()).add(x|y)
    for w in P:
        p=w&8191;j=(w>>13).bit_length()-1
        if j in O:continue
        for n in N:
            if n>>(13+j)&1 and all(n&stars[t] for t in O) and allowed(p,n):b.setdefault(p,set()).add(n&8191)
    return a,b
def match(C,a,b):
    if not C:return True
    p=min(C)
    for q in C-{p}:
        if any(all(not n&q for n in side[p])and all(not n&p for n in side[q])for side in [a,b]):
            if match(C-{p,q},a,b):return True
    return False
if __name__=='__main__':
    for r in (4,5,6):
        stats=Counter()
        for O in combinations(range(7),7-r):
            a,b=rows(O);C=a.keys()&b.keys()
            stats[len(C),match(C,a,b)if len(C)%2==0 else None]+=1
        print(r,stats)
