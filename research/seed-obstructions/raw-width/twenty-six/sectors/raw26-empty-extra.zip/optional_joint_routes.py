from optional_thresholds import minima
from nonfilter_roles import allowed
base=allowed()
ordered=sorted(base,key=lambda p:(len(base[p][1]),-len(base[p][0])))
def cases(size):
    for j in range(128):
        if j.bit_count()==size:
            for c in range(1,256):
                if c.bit_count()<=2 and not j&c:yield j,c
from functools import lru_cache
from itertools import combinations
@lru_cache(None)
def minimal(h,points,F):
    a=minima(h,points,F)
    if a is False:return None
    return tuple(sum(1<<u for u,k in enumerate(a) if k>=j and h!=u) for j in (1,2,3))
def solve(J,C):
    tags=(0,1,2,4,8,16,32,64)+((C,) if C<128 and C.bit_count()==2 else ())
    left=[2-(J>>u&1) for u in range(7)]
    pvec=[0]*8
    @lru_cache(None)
    def limits(edges):
        bm=[[0,0,0] for _ in range(8)]
        reach=[edges[u]|(C if J>>u&1 else 0) for u in range(7)]
        for t in range(7):
            for u in range(7):
                if reach[u]>>t&1:reach[u]|=reach[t]
        if any(m>>u&1 for u,m in enumerate(reach)):return None
        for u,b in enumerate(edges):
            free=left[u]-b.bit_count()
            if free<0:return None
            for h in range(8):
                k=free+(b>>h&1)
                if J>>u&1 and C>>h&1:k+=3-C.bit_count()
                for i in range(k):bm[h][i]|=1<<u
        return bm
    def walk(k,edges,tags):
        if k==len(ordered):return tuple(tags)
        p=ordered[k];js,hs=base[p]
        found=set()
        for h in hs:
            d=list(edges)
            for u in js:
                if not(J>>u&1 and C>>h&1):d[u]|=1<<h
            d=tuple(d);bs=limits(d)
            if bs is None:continue
            pvec[h]|=1<<p
            possible=[]
            for f in tags:
                if f in found:continue
                for v,q in enumerate(pvec):
                    if not q and not f>>v&1:continue
                    mins=minimal(v,q,f)
                    if mins is None or any(a&~b for a,b in zip(mins,bs[v])):break
                else:possible.append(f)
            if possible:found.update(walk(k+1,d,possible))
            pvec[h]^=1<<p
            if len(found)==len(tags):break
        return tuple(found)
    return walk(0,(0,)*7,tags)
def run(s):
    out=[];n=0
    for j,c in cases(s):
        z=solve(j,c);n+=1
        if z:out.append((j,c,z))
    print(s,n,len(out),out[:5],flush=True)
    assert n==[36,196,441,525,350,126,21,1][s] and not out
if __name__=='__main__':
    import sys
    for s in map(int,sys.argv[1:]):run(s)
