from nonfilter_roles import allowed
from filter_local import check
from local_columns import stronger
from collections import Counter
from itertools import combinations
import sys,json

def layouts(triple):
    point=allowed();order=sorted(point,key=lambda p:(len(point[p][1]),-len(point[p][0])))
    holds={}
    def visit(k,arc):
        if k==len(order):yield dict(holds),arc;return
        p=order[k];js,choices=point[p]
        for h in choices:
            direct=arc.copy()
            for j in js:direct[j]|=1<<h
            if any(direct[j].bit_count()>2+(j==triple) for j in js):continue
            reach=direct.copy()
            for a in range(7):
                for j in range(7):
                    if reach[j]>>a&1:reach[j]|=reach[a]
            if any(reach[j]>>j&1 for j in range(7)):continue
            holds[p]=h
            yield from visit(k+1,direct)
        holds.pop(p,None)
    yield from visit(0,[0]*7)

def study(triple):
    count=0;keep=[]
    for holds,direct in layouts(triple):
        count+=1;ports={}
        for region in set(holds.values()):
            owned=sum(1<<p for p,h in holds.items() if h==region)
            ones=sum(1<<j for j,a in enumerate(direct) if a>>region&1)
            twice=sum(1<<j for j,a in enumerate(direct) if a>>region&1 and a.bit_count()<2+(j==triple))
            ports[region]=(owned,ones,twice)
        for filt in [-1,*range(7)]:
            mask=0 if filt==-1 else 1<<filt
            regions=set(ports) | ({filt}if filt>=0 else set())
            if not all(check(h,*ports.get(h,(0,0,0)),mask) for h in regions):
                continue
            # With two different forced tag destinations, only one of them can receive two copies.
            destinations=[h for h in regions if direct[triple]>>h&1]
            if direct[triple].bit_count()==2 and len(destinations)==2:
                requires_extra=0
                for h in destinations:
                    pt,one,two=ports.get(h,(0,0,0))
                    if not check(h,pt,one,two&~(1<<triple),mask):requires_extra+=1
                if requires_extra>1:continue
            def advanced(h,two):
                pt,one,_=ports.get(h,(0,0,0))
                triplebit=(1<<triple) if direct[triple]==(1<<h) else 0
                return stronger(h,pt,one,two,two&triplebit,mask)
            if not all(advanced(h,ports.get(h,(0,0,0))[2]) for h in regions):continue
            if direct[triple].bit_count()==2 and len(destinations)==2:
                must=[h for h in destinations if not advanced(h,ports[h][2]&~(1<<triple)) or not check(h,*ports[h][:2],ports[h][2]&~(1<<triple),mask)]
                if len(must)>1:continue
            keep.append((filt,holds,direct))
    print(triple,count,len(keep),sum(set(h.values())!={7} for f,h,d in keep),flush=True)
    with open(f'kept-{triple}.json','w')as f:json.dump(keep,f)
if __name__=='__main__':
    for j in map(int,sys.argv[1:]):study(j)
