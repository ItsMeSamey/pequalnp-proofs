from nonfilter_roles import *
from functools import lru_cache
P=list(P);N=list(N);count=len(N);ALL=(1<<count)-1
on=[sum(1<<j for j,n in enumerate(N)if n>>(13+u)&1)for u in range(7)]
meeting=[sum(1<<j for j,n in enumerate(N)if n&stars[u])for u in range(7)]
inc=[((w&8191).bit_length()-1,(w>>13).bit_length()-1)for w in P]
unique={};tables={}
for i in range(13):
    p=1<<i
    for has in (False,True):
        feats=[(k,m)for k,m in enumerate(raw)if m&p and (has or m!=p or i==1)]
        data={}
        for j,n in enumerate(N+[0]):
            d=[k for k,m in feats if not m&n]
            key=-1 if not d else d[0] if len(d)==1 else -2
            data[key]=data.get(key,0)|(1<<j)
        tables[i,has]=data
    for u in range(7):unique[i,u]=on[u]&tables[i,True].get(raw.index(p),0)
filtered=[0]*7
for p,u in inc:filtered[u]|=unique[p,u]
@lru_cache(None)
def check(h,owned,ones,twos,F):
    own=h<7 and F>>h&1
    pos=[(p,u) for p,u in inc if owned>>p&1 or (own and u==h)]
    if not pos:return True
    neg=ALL if h==7 else meeting[h]
    for p,u in pos:
        if owned>>p&1:neg|=unique[p,u]
    if own:neg|=1<<count
    pm={};nm={}
    def mark(j,i,z):
        if z:pm[j]=pm.get(j,0)|(1<<i);nm[j]=nm.get(j,0)|z
    for i,(p,u) in enumerate(pos):
        lb=on[u] if h==u or not F>>u&1 else filtered[u]
        if own and h==u:lb|=1<<count
        mult=1 if h==u else (ones>>u&1)+(twos>>u&1)
        data=tables[p,bool(owned>>p&1)]
        zero=data.get(-1,0)&neg
        if zero&lb or (zero and not mult):return False
        if mult==1:mark(31+u,i,zero&~lb)
        for j,z in data.items():
            if j>=0:mark(j,i,z&neg&(lb if mult else -1))
    return not any(pm[x]&pm[y]and nm[x]&nm[y]for x,y in combinations(pm,2))
