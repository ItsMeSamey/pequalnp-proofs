from filter_local import P,N,ALL,on,meeting,inc,filtered,unique,raw,tables,count
from functools import lru_cache
from itertools import combinations_with_replacement

@lru_cache(None)
def choices(n,candidates):
    out=set()
    for sets in combinations_with_replacement(range(1,1<<n),candidates):
        shapes={0}
        for v in sets:shapes|={u|v for u in shapes if not u&v}
        out.add(tuple(sorted(shapes)))
    return tuple(out)

@lru_cache(None)
def shape_bits(n,copies,need,forbid):
    if need&forbid:return 0
    return sum(1<<i for i,sh in enumerate(choices(n,copies)) if any(not (need&~u or forbid&u)for u in sh))

@lru_cache(None)
def stronger(h,owned,ones,twos,threes,F):
    own=h<7 and bool(F>>h&1)
    pos=[(p,u) for p,u in inc if owned>>p&1 or (own and u==h)]
    if not pos:return True
    neg=ALL if h==7 else meeting[h]
    for p,u in pos:
        if owned>>p&1:neg|=unique[p,u]
    if own:neg|=1<<count
    pm={};nm={};required=[]
    def mark(j,i,z):
        if z:
            pm[j]=pm.get(j,0)|(1<<i);nm[j]=nm.get(j,0)|z
    for i,(p,u) in enumerate(pos):
        lb=on[u] if u==h or not F>>u&1 else filtered[u]
        if own and u==h:lb|=1<<count
        mult=1 if h==u else ((ones>>u&1)+(twos>>u&1)+(threes>>u&1))
        data=tables[p,bool(owned>>p&1)];zero=data.get(-1,0)&neg
        if zero&lb or zero and not mult:return False
        must=zero&~lb;required.append(must)
        if mult==1:mark(31+u,i,must)
        for coord,z in data.items():
            if coord>=0:mark(coord,i,z&neg&(lb if mult else -1))
    for u in range(7):
        rowids=[i for i,(_,j)in enumerate(pos)if j==u]
        mult=1 if h==u else ((ones>>u&1)+(twos>>u&1)+(threes>>u&1))
        if not rowids or mult<2:continue
        forbidden=[]
        for i in rowids:
            z=0
            for coord,flag in pm.items():
                if flag>>i&1 and coord!=31+u:z|=nm[coord]
            forbidden.append(z)
        cols=set();active=0
        for i in rowids:active|=required[i]
        while active:
            bit=active&-active;active^=bit
            need=sum(1<<j for j,i in enumerate(rowids)if required[i]&bit)
            no=sum(1<<j for j,z in enumerate(forbidden)if z&bit)
            cols.add((need,no))
        valid=-1
        for need,no in cols:
            valid&=shape_bits(len(rowids),mult,need,no)
            if not valid:return False
    return True
