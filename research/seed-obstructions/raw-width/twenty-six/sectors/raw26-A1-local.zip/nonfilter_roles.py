from forest import *
from collections import Counter
def allowed():
    pos={}
    for i in range(13):
        p=1<<i;js=[j for j,t in enumerate(stars) if p&t]
        ns=[n for n in N if any(n>>(13+j)&1 for j in js) and all(m==p or not m&p or m&n for m in raw)]
        if ns:pos[i]=js,[v for v in range(7) if not any(n>>(13+v)&1 for n in ns)]+[7]
    return pos
def layouts():
    point=allowed()
    order=sorted(point,key=lambda p:(len(point[p][1]),-len(point[p][0])))
    holders={}
    def rc(k,arc):
        if k==len(order):
            yield dict(holders),arc
            return
        p=order[k];js,options=point[p]
        for h in options:
            direct=arc.copy()
            for j in js:direct[j]|=1<<h
            if any(direct[j].bit_count()>2 for j in js):continue
            reach=direct.copy()
            for t in range(7):
                for j in range(7):
                    if reach[j]>>t&1:reach[j]|=reach[t]
            if any(reach[j]>>j&1 for j in range(7)):continue
            holders[p]=h
            yield from rc(k+1,direct)
        holders.pop(p,None)
    return rc(0,[0]*7)
if __name__=='__main__':
    print(Counter(len(set(h.values())-{7}) for h,a in layouts()))
