from pathlib import Path
from roles import study
import sys,json
expected=[1851,1847,1629,1690,2024,1470,1918]
if '--replay' in sys.argv:
 for tag in range(7):study(tag)
for row,n in zip(Path('roles.log').read_text().splitlines(),expected,strict=True):
 t,c,k,partial=map(int,row.split())
 assert c==n and k==partial==0 and json.load(open(f'kept-{t}.json'))==[]
print(sum(expected),'holder maps across seven tripled-label choices;',8*sum(expected),'filter selections')
