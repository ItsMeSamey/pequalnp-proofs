from forest import P,N,raw
from itertools import combinations_with_replacement
P=sorted(p for p in P if (p&8191)!=2);N=sorted(N)
def root_constraints(f):
 nlines=[[bool(w>>(13+j)&1)for w in N]for j in range(7)]
 if f>=0:
  pos=[p for p in P if p>>(13+f)&1]
  if f==5:pos.append(2|(1<<(13+f)))
  nlines[f]=[any(w>>(13+f)&1 and all(not((p&8191)&m) or m==(p&8191) or w&m for m in raw)for p in pos)for w in N]
 marks={};req={j:{} for j in range(7)}
 for a,p in enumerate(P):
  j=(p>>13).bit_length()-1
  for b,n in enumerate(N):
   d=[m for m in raw if m&p and not m&n]
   if not nlines[j][b] and not d:req[j].setdefault(b,set()).add(a)
   if nlines[j][b] and len(d)==1:
    A,B=marks.setdefault(d[0],(set(),set()));A.add(a);B.add(b)
 used={(a,b)for A,B in marks.values()for a in A for b in B}
 def okay(j,reps):
  rows=[a for a,p in enumerate(P)if p>>(13+j)&1]
  cols={(sum(1<<i for i,a in enumerate(rows)if a in must),sum(1<<i for i,a in enumerate(rows)if (a,b)in used))for b,must in req[j].items()}
  for family in combinations_with_replacement(range(1,1<<len(rows)),reps):
   opts={0}
   for x in family:opts.update([u|x for u in opts if not x&u])
   if all(any(not need&~u and not no&u for u in opts)for need,no in cols):return True
  return False
 return [(j,okay(j,2),okay(j,3))for j in range(7)]
if __name__=='__main__':
 import sys
 for f in map(int,sys.argv[1:]): print(f,root_constraints(f),flush=True)
