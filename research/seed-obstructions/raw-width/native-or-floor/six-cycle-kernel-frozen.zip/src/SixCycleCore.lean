import SixCycleTable

namespace TightRow.SixCycle

private theorem lowerAt {y : Mask} {n : Row} {lo cl : Mask}
    (w : Witness y n lo cl) : Lower (insert (sig y) bank) positive n 4 := by
  intro C cov
  obtain ⟨_,hk,_,hw,_⟩ := w
  obtain ⟨card,pos⟩ := fourPack lo hk
  rw [← card]
  apply packedLower (fun x hx => cov.2 (pos x hx))
  intro s hs x hx sx z hz sz
  obtain ⟨mem,low⟩ := cov.1 s hs
  have enc : ∃ a ∈ y :: raw, s = sig a := by
    rcases Set.mem_insert_iff.mp mem with rfl | mem
    · exact ⟨y,by simp,rfl⟩
    obtain ⟨a,ha,rfl⟩ := mem
    exact ⟨a,by simp [ha],rfl⟩
  obtain ⟨a,ha,rfl⟩ := enc
  have bit : a.getLsbD n.val = false := by
    change a.getLsbD n.val ≠ true at low
    simpa using low
  exact thinUnique (hw a ha bit) hx sx hz sz

private theorem cleanPack {y : Mask} {n : Row} {lo cl : Mask}
    (w : Witness y n lo cl) (D : Finset (Set Row))
    (terms : ∀ t ∈ D, Product (insert (sig y) bank) t)
    (acc : positive ⊆ rows D) (reject : ∀ x ∈ negative, x ∉ rows D) :
    5 ≤ D.card := by
  obtain ⟨_,_,hk,_,hcheck⟩ := w
  obtain ⟨card,pos⟩ := fivePack cl hk
  rw [← card]
  apply packedLower (fun x hx => acc (pos x hx))
  intro t ht x hx xt z hz zt
  have clean (r : Row) (hr : r ∈ negative) : r ∉ t := fun h => reject r hr ⟨t,ht,h⟩
  obtain ⟨a,ha,h | h⟩ := nextEncoded y (terms t ht)
  · subst t
    exact thinUnique ((hcheck a ha).1 (cleanBitsOf clean)) hx xt hz zt
  · subst t
    exact thinUnique ((hcheck a ha).2 (cleanBitsOf clean)) hx xt hz zt

private theorem noTail {a b : Mask} (ha : a ∈ products) (hb : b ∈ products)
    {q : Set Row} {k : Nat} (h : Net (insert (sig (a ||| b)) bank) q k)
    (cost : k ≤ 3) (accept : positive ⊆ q) (clean : ∀ x ∈ negative, x ∉ q) : False := by
  let y := a ||| b
  let n := (cert y).1
  have w : Witness y n (cert y).2.1 (cert y).2.2 := allFirst a ha b hb
  have lo : Lower (insert (sig y) bank) positive n (k+1) := by
    intro C hC
    have bound := lowerAt w C hC
    omega
  obtain ⟨D,terms,eqn,size⟩ := tightExact h accept (clean n w.1) lo
  have five := cleanPack w D terms (by simpa only [eqn] using accept)
    (by simpa only [eqn] using clean)
  omega

theorem noFour {q : Set Row} {k : Nat} (h : Physical bank q k) (cost : k ≤ 4)
    (accept : positive ⊆ q) (clean : ∀ x ∈ negative, x ∉ q) : False := by
  cases physical_iff_net.mp h with
  | stop p =>
    have z : (0 : Mask) ∈ products := by decide
    apply noTail z z (k := 0) _ (by decide) accept clean
    apply Net.stop
    exact p.map (fun _ hs => .atom (Or.inr hs))
  | step pl pr tail =>
    obtain ⟨a,ha,rfl⟩ := productEncoded pl
    obtain ⟨b,hb,rfl⟩ := productEncoded pr
    rw [← sig_or] at tail
    exact noTail ha hb tail (by omega) accept clean

end TightRow.SixCycle
