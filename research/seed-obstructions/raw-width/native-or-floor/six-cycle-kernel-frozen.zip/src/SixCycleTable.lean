import SixCyclePacking

namespace TightRow.SixCycle

/-- The first mask packs rows against individual low wires. The second packs rows
against any globally clean product, including products containing the new OR. -/
def Witness (y : Mask) (n : Row) (lo cl : Mask) : Prop :=
  6 ≤ n.val ∧ lo ∈ fourMasks ∧ cl ∈ fiveMasks ∧
  (∀ a ∈ y :: raw, a.getLsbD n.val = false → thin lo a) ∧
  (∀ a ∈ products, (cleanBits a = true → thin cl a) ∧
      (cleanBits (a &&& y) = true → thin cl (a &&& y)))

instance (y : Mask) (n : Row) (lo cl : Mask) : Decidable (Witness y n lo cl) := by
  unfold Witness
  infer_instance

def cert (y : Mask) : Row × Mask × Mask := match y.toNat with
  | 3 => (8, 29, 61)
  | 5 => (9, 58, 59)
  | 6 => (8, 29, 59)
  | 9 => (6, 39, 55)
  | 10 => (6, 39, 55)
  | 12 => (6, 39, 55)
  | 17 => (6, 39, 47)
  | 18 => (6, 39, 47)
  | 20 => (6, 39, 47)
  | 24 => (6, 39, 47)
  | 33 => (8, 29, 31)
  | 34 => (8, 29, 31)
  | 36 => (8, 29, 31)
  | 236 => (6, 39, 55)
  | 403 => (8, 29, 61)
  | 405 => (8, 29, 31)
  | 433 => (8, 29, 31)
  | 651 => (9, 58, 61)
  | 654 => (9, 58, 55)
  | 682 => (8, 29, 31)
  | 750 => (6, 39, 55)
  | 923 => (8, 29, 61)
  | 1099 => (6, 39, 55)
  | 1107 => (6, 39, 47)
  | 1293 => (8, 29, 31)
  | 1294 => (8, 29, 55)
  | 1324 => (8, 29, 31)
  | 1359 => (6, 39, 55)
  | 1437 => (8, 29, 31)
  | 1585 => (9, 58, 47)
  | 1586 => (8, 29, 31)
  | 1588 => (9, 58, 31)
  | 1651 => (6, 39, 47)
  | 1722 => (9, 58, 31)
  | 1852 => (8, 29, 31)
  | 1934 => (8, 29, 31)
  | 1969 => (8, 29, 31)
  | _ => (6, 39, 31)

def check (y : Mask) := Witness y (cert y).1 (cert y).2.1 (cert y).2.2
instance (y : Mask) : Decidable (check y) := inferInstanceAs (Decidable (Witness _ _ _ _))

/-- Boolean reflection keeps the checked search a finite list scan. -/
def valid (y : Mask) : Bool :=
  let c := cert y
  decide (6 ≤ c.1.val) && fourMasks.contains c.2.1 && fiveMasks.contains c.2.2 &&
  (y :: raw).all (fun a => a.getLsbD c.1.val || decide (thin c.2.1 a)) &&
  products.all (fun a =>
    (!cleanBits a || decide (thin c.2.2 a)) &&
    (!cleanBits (a &&& y) || decide (thin c.2.2 (a &&& y))))

private theorem validSound {y : Mask} (h : valid y = true) : check y := by
  simp only [valid,Bool.and_eq_true,decide_eq_true_eq,List.contains_iff_mem] at h
  obtain ⟨⟨⟨⟨hn,h4⟩,h5⟩,hlo⟩,hcl⟩ := h
  refine ⟨hn,h4,h5,?_,?_⟩
  · intro a ha low
    have t := List.all_eq_true.mp hlo a ha
    change (a.getLsbD (cert y).1.val || decide (thin (cert y).2.1 a)) = true at t
    rw [low] at t
    exact of_decide_eq_true t
  · intro a ha
    have t := List.all_eq_true.mp hcl a ha
    simp only [Bool.and_eq_true] at t
    exact ⟨fun h => by simpa [h] using t.1,fun h => by simpa [h] using t.2⟩

private theorem row0 : products.all (fun b => valid (0 ||| b)) = true := by decide
private theorem row1 : products.all (fun b => valid (1 ||| b)) = true := by decide
private theorem row2 : products.all (fun b => valid (2 ||| b)) = true := by decide
private theorem row4 : products.all (fun b => valid (4 ||| b)) = true := by decide
private theorem row8 : products.all (fun b => valid (8 ||| b)) = true := by decide
private theorem row16 : products.all (fun b => valid (16 ||| b)) = true := by decide
private theorem row32 : products.all (fun b => valid (32 ||| b)) = true := by decide
private theorem row64 : products.all (fun b => valid (64 ||| b)) = true := by decide
private theorem row128 : products.all (fun b => valid (128 ||| b)) = true := by decide
private theorem row228 : products.all (fun b => valid (228 ||| b)) = true := by decide
private theorem row256 : products.all (fun b => valid (256 ||| b)) = true := by decide
private theorem row401 : products.all (fun b => valid (401 ||| b)) = true := by decide
private theorem row512 : products.all (fun b => valid (512 ||| b)) = true := by decide
private theorem row650 : products.all (fun b => valid (650 ||| b)) = true := by decide
private theorem row1024 : products.all (fun b => valid (1024 ||| b)) = true := by decide
private theorem row1091 : products.all (fun b => valid (1091 ||| b)) = true := by decide
private theorem row1292 : products.all (fun b => valid (1292 ||| b)) = true := by decide
private theorem row1584 : products.all (fun b => valid (1584 ||| b)) = true := by decide
private theorem row2047 : products.all (fun b => valid (2047 ||| b)) = true := by decide

theorem allFirst : ∀ a ∈ products, ∀ b ∈ products, check (a ||| b) := by
  intro a ha
  simp only [products,List.mem_cons,List.not_mem_nil,or_false] at ha
  rcases ha with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact fun b hb => validSound (List.all_eq_true.mp row0 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row1 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row2 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row4 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row8 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row16 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row32 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row64 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row128 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row228 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row256 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row401 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row512 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row650 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row1024 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row1091 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row1292 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row1584 b hb)
  · exact fun b hb => validSound (List.all_eq_true.mp row2047 b hb)

end TightRow.SixCycle
