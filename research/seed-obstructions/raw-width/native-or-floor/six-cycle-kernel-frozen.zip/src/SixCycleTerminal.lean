import SixCycleCore
import SixCycleWitness
import TightRowIndexed

namespace TightRow.SixCycle

/-- Literal unsigned masks from core6.in, first the six positives, then its five
maximal negatives, on all 22 source positions including zero and duplicate columns. -/
def rowCodes : List Nat :=
  [8196,524292,1179649,1572865,2105408,2228288,131076,663552,1056769,2621504,3145797]

def literal (j : Fin 22) : Set Row :=
  {r | (rowCodes.getD r.val 0).testBit j.val = true}

def columns : List Mask :=
  [1292,0,1091,0,0,0,1584,0,0,0,0,0,0,401,0,0,0,228,0,650,1292,1584]

theorem agreement : ∀ j : Fin 22, ∀ r : Row,
    (rowCodes.getD r.val 0).testBit j.val = (columns.getD j.val 0).getLsbD r.val := by decide

private theorem literalSig (j : Fin 22) : literal j = sig (columns.getD j.val 0) := by
  ext r
  simp only [literal,sig,Set.mem_setOf_eq,agreement]

theorem literalBank : Set.range literal = bank := by
  have fwd : ∀ j : Fin 22, columns.getD j.val 0 ∈ raw := by decide
  have bwd : ∀ s ∈ raw, ∃ j : Fin 22, columns.getD j.val 0 = s := by decide
  ext s
  constructor
  · rintro ⟨j,rfl⟩
    exact ⟨_,fwd j,literalSig j⟩
  · rintro ⟨a,ha,rfl⟩
    obtain ⟨j,hj⟩ := bwd a ha
    exact ⟨j,(literalSig j).trans (congrArg sig hj)⟩

/-- Exact minimum on the literal signed terminal chart for arbitrary physically
indexed binary AND/OR DAGs. Only the OR gates contribute to k. -/
theorem terminal_five_minimum :
    (∀ k, ∀ t : Tape (Fin 22) k, positive ⊆ t.eval literal →
      (∀ x ∈ negative, x ∉ t.eval literal) → 5 ≤ k) ∧
    ∃ t : Tape (Fin 22) 5, positive ⊆ t.eval literal ∧
      ∀ x ∈ negative, x ∉ t.eval literal := by
  constructor
  · intro k t hp hn
    by_contra! h
    have hg : Physical (Set.range literal) (t.eval literal) k :=
      t.toPhysical literal (fun j => ⟨j,rfl⟩)
    rw [literalBank] at hg
    exact noFour hg (by omega) hp hn
  · obtain ⟨q,g,hp,hn⟩ := fiveWitness
    rw [← literalBank] at g
    obtain ⟨t,eqn⟩ := g.toTape literal (fun _ h => h)
    exact ⟨t,by rwa [eqn],by rwa [eqn]⟩

end TightRow.SixCycle
