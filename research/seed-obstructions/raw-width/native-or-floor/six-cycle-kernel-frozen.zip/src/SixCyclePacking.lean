import SixCycleEncoded
import Mathlib.Data.Fintype.Fin

namespace TightRow.SixCycle

/-- Covering a packed family requires a distinct member of the cover at each row. -/
theorem packedLower {K : Finset Row} {C : Finset (Set Row)}
    (cover : ∀ x ∈ K, x ∈ rows C)
    (one : ∀ s ∈ C, ∀ x ∈ K, x ∈ s → ∀ z ∈ K, z ∈ s → x = z) :
    K.card ≤ C.card := by
  classical
  have existsWire (x : K) : ∃ t : C, x.val ∈ t.val := by
    obtain ⟨t,ht,hx⟩ := cover x.val x.property
    exact ⟨⟨t,ht⟩,hx⟩
  let f : K → C := fun x => Classical.choose (existsWire x)
  have hit (x : K) : x.val ∈ (f x).val := Classical.choose_spec (existsWire x)
  apply Finset.card_le_card_of_injective (f := f)
  intro x z hz
  apply Subtype.ext
  exact one _ (f x).property _ x.property (hit x) _ z.property (hz ▸ hit z)

def pack (k : Mask) : Finset Row := Finset.univ.filter (fun r => k.getLsbD r.val = true)
def thin (k a : Mask) : Prop := k &&& a ∈ ([0,1,2,4,8,16,32] : List Mask)
instance (k a : Mask) : Decidable (thin k a) := inferInstanceAs (Decidable (k &&& a ∈ ([0,1,2,4,8,16,32] : List Mask)))

theorem smallCards : ∀ a ∈ ([0,1,2,4,8,16,32] : List Mask), (pack a).card ≤ 1 := by decide
theorem thinUnique {k a : Mask} (h : thin k a) {x z : Row}
    (kx : x ∈ pack k) (ax : x ∈ sig a) (kz : z ∈ pack k) (az : z ∈ sig a) : x = z := by
  apply Finset.card_le_one.mp (smallCards _ h)
  · simp_all [pack,sig]
  · simp_all [pack,sig]

def fourMasks : List Mask := [39,29,58]
def fiveMasks : List Mask := [31,55,47,61,59]
theorem fourPack : ∀ k ∈ fourMasks, (pack k).card = 4 ∧ ∀ x ∈ pack k, x.val < 6 := by decide
theorem fivePack : ∀ k ∈ fiveMasks, (pack k).card = 5 ∧ ∀ x ∈ pack k, x.val < 6 := by decide

def cleanBits (s : Mask) : Bool := !(s.getLsbD 6 || s.getLsbD 7 || s.getLsbD 8 ||
  s.getLsbD 9 || s.getLsbD 10)
theorem cleanBitsOf {m : Mask} (h : ∀ x ∈ negative, x ∉ sig m) : cleanBits m = true := by
  have h6 := h 6 (show 6 ≤ (6 : Row).val by decide)
  have h7 := h 7 (show 6 ≤ (7 : Row).val by decide)
  have h8 := h 8 (show 6 ≤ (8 : Row).val by decide)
  have h9 := h 9 (show 6 ≤ (9 : Row).val by decide)
  have h10 := h 10 (show 6 ≤ (10 : Row).val by decide)
  change m.getLsbD 6 ≠ true at h6
  change m.getLsbD 7 ≠ true at h7
  change m.getLsbD 8 ≠ true at h8
  change m.getLsbD 9 ≠ true at h9
  change m.getLsbD 10 ≠ true at h10
  simp_all [cleanBits]

end TightRow.SixCycle
