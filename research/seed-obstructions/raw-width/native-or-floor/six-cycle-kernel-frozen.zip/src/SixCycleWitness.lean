import SixCycleMasks
import Mathlib.Data.Fintype.Fin

namespace TightRow.SixCycle

/-- Five-gate circuit. The first three ORs collect point pairs under each tag.
The last two ORs collect the three resulting stars. -/
theorem fiveWitness : ∃ q, Physical bank q 5 ∧ positive ⊆ q ∧
    ∀ x ∈ negative, x ∉ q := by
  let p₁ : Mask := 1091
  let p₂ : Mask := 1292
  let p₃ : Mask := 1584
  let t₁ : Mask := 401
  let t₂ : Mask := 228
  let t₃ : Mask := 650
  let l := sig p₁ ∪ sig p₃
  let m := sig p₂ ∪ sig p₃
  let r := sig p₁ ∪ sig p₂
  let u := l ∩ sig t₁
  let v := m ∩ sig t₂
  let w := r ∩ sig t₃
  refine ⟨(u ∪ v) ∪ w,physical_iff_net.mpr ?_,?_,?_⟩
  · apply Net.step (.atom (show sig p₁ ∈ bank from ⟨_,by decide,rfl⟩))
      (.atom (show sig p₃ ∈ bank from ⟨_,by decide,rfl⟩))
    have in2 : sig p₂ ∈ insert l bank := Or.inr ⟨p₂,by decide,rfl⟩
    have in3 : sig p₃ ∈ insert l bank := Or.inr ⟨p₃,by decide,rfl⟩
    apply Net.step (.atom in2) (.atom in3)
    have in1' : sig p₁ ∈ insert m (insert l bank) := Or.inr (Or.inr ⟨p₁,by decide,rfl⟩)
    have in2' : sig p₂ ∈ insert m (insert l bank) := Or.inr in2
    apply Net.step (.atom in1') (.atom in2')
    let A := insert r (insert m (insert l bank))
    have ug : Product A u := .meet (.atom (Or.inr (Or.inr (Or.inl rfl))))
      (.atom (Or.inr (Or.inr (Or.inr ⟨t₁,by decide,rfl⟩))))
    have vg : Product A v := .meet (.atom (Or.inr (Or.inl rfl)))
      (.atom (Or.inr (Or.inr (Or.inr ⟨t₂,by decide,rfl⟩))))
    have wg : Product (insert (u ∪ v) A) w := .meet (.atom (Or.inr (Or.inl rfl)))
      (.atom (Or.inr (Or.inr (Or.inr (Or.inr ⟨t₃,by decide,rfl⟩)))))
    apply Net.step ug vg
    apply Net.step (.atom (Set.mem_insert _ _)) wg
    exact .stop (.atom (Set.mem_insert _ _))
  · change ∀ x : Row, x.val < 6 → _
    change ∀ x : Row, x.val < 6 →
      (((p₁.getLsbD x.val = true ∨ p₃.getLsbD x.val = true) ∧ t₁.getLsbD x.val = true) ∨
      ((p₂.getLsbD x.val = true ∨ p₃.getLsbD x.val = true) ∧ t₂.getLsbD x.val = true)) ∨
      ((p₁.getLsbD x.val = true ∨ p₂.getLsbD x.val = true) ∧ t₃.getLsbD x.val = true)
    decide
  · change ∀ x : Row, 6 ≤ x.val → ¬(
      (((p₁.getLsbD x.val = true ∨ p₃.getLsbD x.val = true) ∧ t₁.getLsbD x.val = true) ∨
      ((p₂.getLsbD x.val = true ∨ p₃.getLsbD x.val = true) ∧ t₂.getLsbD x.val = true)) ∨
      ((p₁.getLsbD x.val = true ∨ p₂.getLsbD x.val = true) ∧ t₃.getLsbD x.val = true))
    decide

end TightRow.SixCycle
