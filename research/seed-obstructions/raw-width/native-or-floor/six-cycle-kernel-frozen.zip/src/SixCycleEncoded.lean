import SixCycleMasks

namespace TightRow.SixCycle

theorem productEncoded {s : Set Row} (p : Product bank s) :
    ∃ a ∈ products, s = sig a := by
  induction p with
  | atom h =>
    obtain ⟨a,ha,rfl⟩ := h
    exact ⟨a,rawInProducts a ha,rfl⟩
  | meet _ _ ih jh =>
    obtain ⟨a,ha,rfl⟩ := ih
    obtain ⟨b,hb,rfl⟩ := jh
    exact ⟨a &&& b,productsClosed a ha b hb,(sig_and a b).symm⟩

theorem nextEncoded (y : Mask) {s : Set Row} (p : Product (insert (sig y) bank) s) :
    ∃ a ∈ products, s = sig a ∨ s = sig (a &&& y) := by
  induction p with
  | atom h =>
    rcases Set.mem_insert_iff.mp h with rfl | h
    · refine ⟨2047,by decide,Or.inr ?_⟩
      exact congrArg sig (BitVec.allOnes_and (x := y)).symm
    · obtain ⟨a,ha,rfl⟩ := h
      exact ⟨a,rawInProducts a ha,Or.inl rfl⟩
  | meet _ _ ih jh =>
    obtain ⟨a,ha,ea⟩ := ih
    obtain ⟨b,hb,eb⟩ := jh
    refine ⟨a &&& b,productsClosed a ha b hb,?_⟩
    rcases ea with rfl | rfl <;> rcases eb with rfl | rfl
    · exact Or.inl (sig_and _ _).symm
    all_goals
      right
      simp only [sig_and]
      ext r
      simp only [Set.mem_inter_iff]
      tauto

end TightRow.SixCycle
