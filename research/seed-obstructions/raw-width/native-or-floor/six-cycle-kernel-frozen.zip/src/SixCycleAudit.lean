import SixCycleTerminal
#print axioms TightRow.SixCycle.productsClosed
#print axioms TightRow.SixCycle.allFirst
#print axioms TightRow.SixCycle.noFour
#print axioms TightRow.SixCycle.fiveWitness
#print axioms TightRow.SixCycle.literalBank
#print axioms TightRow.SixCycle.terminal_five_minimum
