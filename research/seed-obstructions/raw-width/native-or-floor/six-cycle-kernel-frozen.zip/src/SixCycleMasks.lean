import TightRowPhysical

namespace TightRow.SixCycle

abbrev Row := Fin 11
abbrev Mask := BitVec 11

def sig (a : Mask) : Set Row := {r | a.getLsbD r.val = true}
def positive : Set Row := {r | r.val < 6}
def negative : Set Row := {r | 6 ≤ r.val}
def raw : List Mask := [0,1292,1091,1584,401,228,650]
def products : List Mask :=
  [0,1,2,4,8,16,32,64,128,228,256,401,512,650,1024,1091,1292,1584,2047]
def bank : Bank Row := {s | ∃ t ∈ raw, s = sig t}

theorem sig_and (a b : Mask) : sig (a &&& b) = sig a ∩ sig b := by
  ext r
  simp [sig]
theorem sig_or (a b : Mask) : sig (a ||| b) = sig a ∪ sig b := by
  ext r
  simp [sig]


private theorem oldOK : raw.all (fun x => products.contains x) = true := by decide
private theorem meetOK : products.all (fun a => products.all (fun b =>
    products.contains (a &&& b))) = true := by decide

theorem rawInProducts (a : Mask) (ha : a ∈ raw) : a ∈ products := by
  simpa using List.all_eq_true.mp oldOK a ha
theorem productsClosed (a : Mask) (ha : a ∈ products) (b : Mask) (hb : b ∈ products) :
    a &&& b ∈ products := by
  simpa using List.all_eq_true.mp (List.all_eq_true.mp meetOK a ha) b hb

end TightRow.SixCycle
