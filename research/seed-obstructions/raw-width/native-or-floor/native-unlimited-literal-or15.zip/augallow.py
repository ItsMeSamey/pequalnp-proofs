from pathlib import Path
from itertools import combinations_with_replacement
from sample import samples
rows,front,target=samples(Path('L-meta-18968.json'));P=sorted({r&1048575 for i,r in enumerate(rows)if ((target&~front)>>i)&1});N=sorted({r&1048575 for i,r in enumerate(rows)if not(target>>i)&1})
def vec(m):return tuple(sum(bool(r&m)<<i for i,r in enumerate(tab))for tab in (P,N))
for b,bank in enumerate(((),(129,),(4160,),(129,4160))):
 raw=[vec(x)for x in [1<<i for i in range(20)]+list(bank)];idx=0
 with open(f'augallow{b}.in','w')as f:
  for a,x in enumerate(raw):
   for z in raw[:a]:
    if not x[0]&~z[0]or not z[0]&~x[0]:continue
    h=(x[0]|z[0],x[1]|z[1]);vs=raw+[h];cl={p&q for (p,n),(q,m)in combinations_with_replacement(vs,2)if not n&m}
    choices={};mask=0
    for j,(p,n)in enumerate(raw):
     y=(h[0]&p,h[1]&n)
     if y[0].bit_count()<2 or not y[1] or y in vs or any(not y[0]&~d for d in cl):continue
     mask|=1<<j
    print(mask,file=f);idx+=1
