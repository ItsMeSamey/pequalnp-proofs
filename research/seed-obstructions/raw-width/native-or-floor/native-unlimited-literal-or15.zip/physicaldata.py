from pathlib import Path
exec(Path('trade13.py').read_text().rsplit('for bank in ((),',1)[0])
for bi,bank in enumerate(((),(129,),(4160,),(129,4160))):
 with Path(f'phys{bi}.in').open('w')as f:
  raw=bits(FULL)+list(bank);hard=[p|(t<<13)for p,t in sorted(neg)]
  print(len(raw),len(hard),file=f);print(*raw,file=f);print(*[p|t for p,t in edges],file=f);print(*hard,file=f);print(*[cheapest(r&8191,r>>13,bank)for r in hard],file=f)
