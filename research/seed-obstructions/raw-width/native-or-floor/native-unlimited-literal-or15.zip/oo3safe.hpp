vector<M> alln;
bool exactpay(vector<M> z,int budget){
 sort(z.begin(),z.end());z.erase(unique(z.begin(),z.end()),z.end());vector<M> opt;
 for(M m:z)if(popcount(m)>1&&none_of(z.begin(),z.end(),[&](M n){return m!=n&&!(m&~n);}))opt.push_back(m);
 M multi=0;vector<M> by[28];for(M m:opt){multi|=m;for(int k=0;k<28;k++)if(m>>k&1)by[k].push_back(m);}
 vector<int> order(28);for(int k=0;k<28;k++)order[k]=k;sort(order.begin(),order.end(),[&](int a,int b){return by[a].size()<by[b].size();});
 auto rec=[&](auto self,M m,int b)->bool{if(!m)return b>=0;if(b<=0)return false;int k=0;for(int j:order)if(m>>j&1){k=j;break;}for(M v:by[k])if(self(self,m&~v,b-1))return true;return false;};
 return rec(rec,multi,budget-popcount(F&~multi));
}
bool thirdreal(const vector<S>&base,S h,S j,R tight){
 if(alln.empty()){FILE*fp=fopen("allneg.txt","r");M n;while(fscanf(fp,"%u",&n)==1)alln.push_back(n);fclose(fp);if(alln.size()!=468)abort();}
 vector<S> pool;vector<M> clean;for(int e=0;e<28;e++)pool.push_back({1u<<e,0,0});
 for(int mask=0;mask<4;mask++)for(int q=-1;q<nr;q++){
  if(!mask&&q<0)continue;S a={F,U,~R(0)};if(mask&1)a=meet(a,h);if(mask&2)a=meet(a,j);if(q>=0)a=meet(a,base[q]);if(popcount(a.p)<2)continue;
  bool rawsite=popcount((unsigned)mask)+(q>=0)==1;
  bool dirty=a.hi.any();
  if(!dirty){clean.push_back(a.p);continue;}if((a.hi&tight).none())pool.push_back(a);
 }
 if(exactpay(clean,13))return true;
 
 for(size_t u=0;u<pool.size();u++)for(size_t v=0;v<u;v++){
  M z=pool[u].p|pool[v].p;if(z==pool[u].p||z==pool[v].p)continue;
  R support=savedrows(z,0)|(savedrows(z|h.p,1)&~h.hi)|(savedrows(z|j.p,1)&~j.hi)|(savedrows(z|j.p|h.p,2)&~(j.hi|h.hi));
  if((tight&~support).any())continue;
  S k=add(pool[u],pool[v]); R saved=savedrows(h.p,1)&~h.hi;
  saved|=savedrows(j.p,1)&~j.hi;saved|=savedrows(k.p,1)&~k.hi;
  saved|=savedrows(h.p|j.p,2)&~(h.hi|j.hi);saved|=savedrows(h.p|k.p,2)&~(h.hi|k.hi);saved|=savedrows(j.p|k.p,2)&~(j.hi|k.hi);
  saved|=savedrows(h.p|j.p|k.p,3)&~(h.hi|j.hi|k.hi);
  R tight3=universe&~saved&~base11;M have=0;for(int i=0;i<nn;i++)if(tight3.test(i))have|=neg[i];
  
  vector<M> covers;auto sources=base;sources.insert(sources.end(),{h,j,k});
  for(int a=0;a<8;a++)for(int r=-1;r<nr;r++){S e={F,U,~R(0)};if(a&1)e=meet(e,h);if(a&2)e=meet(e,j);if(a&4)e=meet(e,k);if(r>=0)e=meet(e,base[r]);
   if(popcount(e.p)<2)continue;R n=~R(0);for(S v:sources)if(!(e.p&~v.p))n&=v.hi;if((n&tight3).none())covers.push_back(e.p);}
  if(exactpay(covers,12))return true;
 }return false;
}
