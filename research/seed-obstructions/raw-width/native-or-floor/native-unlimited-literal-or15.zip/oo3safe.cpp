#include <algorithm>
#include <array>
#include <bit>
#include <bitset>
#include <string>
#include <tuple>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <set>
#include <vector>
using namespace std;
using M=uint32_t;using R=bitset<512>;
R universe,base12,base11;
constexpr M F=(1u<<28)-1,U=(1u<<20)-1;
int nr,nn;vector<M> raw,edge,neg,pcov;
struct S{M p,s;R hi;};
S add(S a,S b){return {a.p|b.p,a.s|b.s,a.hi|b.hi};}
S meet(S a,S b){return {a.p&b.p,a.s&b.s,a.hi&b.hi};}
vector<vector<M>> misses[4];map<M,R> saved[4];
R savedrows(M grant,int k){
 auto &lookup=saved[k];auto it=lookup.find(grant);if(it!=lookup.end())return it->second;R result=0;
 for(int i=0;i<nn;i++)for(M m:misses[k][i])if(!(m&~grant)){result|=R(1)<<i;break;}
 return lookup.emplace(grant,result).first->second;
}
void prepare(){
 for(auto &a:misses)a.resize(nn);
 for(int i=0;i<nn;i++){vector<M> avail;for(int j=0;j<nr;j++)if(!(raw[j]&neg[i]))avail.push_back(pcov[j]);
 vector<M> uni(1u<<avail.size());array<vector<M>,4> tmp;
 for(M v=1;v<uni.size();v++){M a=v&-v;uni[v]=uni[v^a]|avail[countr_zero(a)];int k=11-popcount(v);if(k>=0&&k<4)tmp[k].push_back(F&~uni[v]);}
 for(int k=0;k<4;k++){auto &t=tmp[k];sort(t.begin(),t.end());t.erase(unique(t.begin(),t.end()),t.end());sort(t.begin(),t.end(),[](M a,M b){return popcount(a)<popcount(b);});
 auto &q=misses[k][i];for(M z:t)if(none_of(q.begin(),q.end(),[&](M a){return !(a&~z);}))q.push_back(z);}
 }}
#include "commonwide.hpp"
#include "oo3safe.hpp"
int main(int ac,char**av){
 if(scanf("%d%d",&nr,&nn)!=2||nn>512)return 2;
 for(int i=0;i<nr;i++){M x;scanf("%u",&x);raw.push_back(x);}for(int i=0;i<28;i++){M x;scanf("%u",&x);edge.push_back(x);}for(int i=0;i<nn;i++){M x;scanf("%u",&x);neg.push_back(x);}
 for(int i=0;i<nn;i++){int v;scanf("%d",&v);universe.set(i);if(v<=12)base12.set(i);if(v<=11)base11.set(i);}
 vector<S> base;for(M x:raw){M p=0;R v=0;for(int i=0;i<28;i++)if(edge[i]&x)p|=1u<<i;for(int k=0;k<nn;k++)if(neg[k]&x)v|=R(1)<<k;base.push_back({p,x,v});pcov.push_back(p);}
 prepare();int lo=atoi(av[1]),hi=atoi(av[2]);int mode=atoi(av[3]),id=-1;
 for(int a=0;a<nr;a++)for(int b=0;b<a;b++){auto A=base[a],B=base[b];if(!(A.p&~B.p)||!(B.p&~A.p))continue;id++;M legal;scanf("%u",&legal);if(id<lo||id>=hi)continue;S h=add(A,B);vector<S> pre=base;pre.push_back(h);
 if(mode!=1){if(mode==0)for(int k=0;k<28;k++)pre.push_back({1u<<k,0,0});for(int k=0;k<nr;k++)if(legal>>k&1)pre.push_back(meet(h,base[k]));}
 R hs=savedrows(h.p,0)&~h.hi;int total=0,nok=0;set<tuple<M,M,string>> seen;
 for(size_t u=0;u<pre.size();u++)for(size_t v=0;v<u;v++){auto x=pre[u],y=pre[v];if(!(x.p&~y.p)||!(y.p&~x.p))continue;auto j=add(x,y);if(j.p==h.p&&j.s==h.s&&j.hi==h.hi)continue;if(!seen.insert({j.p,j.s,j.hi.to_string()}).second)continue;
 R allow=base12|hs|(savedrows(j.p,0)&~j.hi)|(savedrows(h.p|j.p,1)&~(h.hi|j.hi));M have=0;for(int k=0;k<nn;k++)if(!allow.test(k))have|=neg[k];
 bool ok=common(base,h,j,universe&~allow); if(ok)ok=thirdreal(base,h,j,universe&~allow); if(ok && ac>4) fprintf(stderr,"%d %zu %zu %u %u\n",id,u,v,j.p,j.s);total++;nok+=ok;}
 printf("%d %u %u %d %d\n",id,raw[a],raw[b],total,nok);fflush(stdout);
 }}
