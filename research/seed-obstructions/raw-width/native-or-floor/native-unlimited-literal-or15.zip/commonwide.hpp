bool common(const vector<S>&base,S h,S j,R tight){
 if(tight.none())return true;
 vector<S> offered=base;offered.push_back(h);offered.push_back(j);vector<M> ps;
 for(int mask=0;mask<4;mask++){S q={F,U,~R(0)};if(mask&1)q=meet(q,h);if(mask&2)q=meet(q,j);
 for(int i=-1;i<nr;i++){S z=i<0?q:meet(q,base[i]);if(popcount(z.p)<2)continue;R minimum=~R(0);for(S a:offered)if(!(z.p&~a.p))minimum&=a.hi;if((minimum&tight).none())ps.push_back(z.p);}}
 sort(ps.begin(),ps.end());ps.erase(unique(ps.begin(),ps.end()),ps.end());vector<M> keep;
 for(M a:ps)if(none_of(ps.begin(),ps.end(),[&](M b){return a!=b&&!(a&~b);}))keep.push_back(a);
 M shared=0;vector<M> solve[28];
 for(M a:keep){shared|=a;for(int i=0;i<28;i++)if(a>>i&1)solve[i].push_back(a);}
 vector<int>ord(28);for(int i=0;i<28;i++)ord[i]=i;sort(ord.begin(),ord.end(),[&](int i,int j){return solve[i].size()<solve[j].size();});
 auto dfs=[&](auto self,M m,int l)->bool{if(!m)return l>=0;if(l<=0)return false;int i=0;for(int b:ord)if(m>>b&1){i=b;break;}for(M v:solve[i])if(self(self,m&~v,l-1))return true;return false;};
 return dfs(dfs,shared,13-popcount(F&~shared));
}
