from actions import actions,hood,P,N
from pathlib import Path
H={int(r[0]):int(r[1])|int(r[2])for line in Path('oo3safe.log').read_text().splitlines()if (r:=line.split())}
records=[list(map(int,l.split()))for l in Path('oo3safe.rows').read_text().splitlines()]
keys={(H[a],s):(a,i,j)for a,i,j,p,s in records}; maps=[]
for pm,ns in actions():
 if set(ns)!=set(N):continue
 pm=dict(pm)
 for i in range(7):
  t=1<<(13+i);w={pm[p&8191] for p in P if p&t}
  pm[t]=next(1<<(13+j)for j in range(7)if {p&8191 for p in P if p&(1<<(13+j))}==w)
 maps.append(pm)
def tr(m,pm):return sum(y for x,y in pm.items()if x&m)
seen=set();reps=[]
for k,r in sorted(keys.items()):
 if k in seen:continue
 orb={(tr(k[0],pm),tr(k[1],pm))for pm in maps}
 assert orb<=keys.keys()
 seen|=orb;reps.append((r,k,len(orb)))
print('actions',len(maps),'pairs',len(keys),'orbits',len(reps))
for r,k,n in reps:print(*r,*k,n)
