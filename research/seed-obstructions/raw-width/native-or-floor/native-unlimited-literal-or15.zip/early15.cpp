#include <array>
#include <bit>
#include <bitset>
#include <cstdio>
#include <vector>
using namespace std;
using U=unsigned;using B=bitset<512>;
struct Signal{U p;B n;};
Signal join(Signal a,Signal b){return {a.p|b.p,a.n|b.n};}
Signal meet(Signal a,Signal b){return {a.p&b.p,a.n&b.n};}
int main(){
 int nr,nn;if(scanf("%d%d",&nr,&nn)!=2||nr!=20||nn!=468)return 1;
 vector<U> masks(nr),edges(28),neg(nn);for(auto& x:masks)scanf("%u",&x);
 for(auto& x:edges)scanf("%u",&x);for(auto& x:neg)scanf("%u",&x);
 vector<Signal> raws;
 for(auto m:masks){Signal s{};for(int i=0;i<28;i++)if(edges[i]&m)s.p|=1u<<i;
 for(int i=0;i<nn;i++)if(neg[i]&m)s.n.set(i);raws.push_back(s);}
 array<int,29> hist{};int cases=0;
 for(int a=0;a<nr;a++)for(int b=0;b<a;b++){
 Signal h=join(raws[a],raws[b]);auto bank=raws;bank.push_back(h);
 for(int c=0;c<=nr;c++)for(int d=0;d<c;d++){
 Signal j=join(bank[c],bank[d]);if(j.p==bank[c].p||j.p==bank[d].p)continue;
 U multi=0;for(int i=0;i<4;i++){
 Signal s{(1u<<28)-1,~B(0)};if(i&1)s=meet(s,h);if(i&2)s=meet(s,j);
 for(int r=-1;r<nr;r++){Signal v=r<0?s:meet(s,raws[r]);if(!v.n.any()&&popcount(v.p)>1)multi|=v.p;}}
 // Each uncovered positive requires a distinct singleton terminal. Grant one terminal for all remaining positives.
 int need=28-popcount(multi)+(multi!=0);hist[need]++;cases++;
 }}
 for(int i=0;i<=28;i++)if(hist[i])printf("%d %d\n",i,hist[i]);
 printf("cases %d\n",cases);
}
