import NumericEdgeCodes
import Branch380544
import Branch380800
import NumericGraph007
import NumericGraph008
import NumericGraph036
import NumericGraph040
import NumericGraph041
import NumericGraph043
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c552 : Chart := ⟨[16512, 17408, 33280, 66048, 66560, 262272],[640, 1664, 33920, 98432, 263680, 279040, 295936, 376832]⟩
def m552_488 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e552_488 : Edge c552 c488 m552_488 := by
  exact edgeByCodes c552 c488 m552_488 21542142208 30148920065 (by decide) (by decide) (by decide) (by decide)
theorem floor552 : Floor c552 5 := by
  have up := refundEdge e552_488 floor488 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c553 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 66048, 66560, 262272],[640, 896, 1664, 33920, 65920, 98432, 263936, 279040, 295936, 327936, 376832]⟩
def m553_94 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
theorem e553_94 : Edge c553 c94 m553_94 := by
  exact edgeByCodes c553 c94 m553_94 1694364648734976 721987726312079873 (by decide) (by decide) (by decide) (by decide)
theorem floor553 : Floor c553 7 := by
  have up := refundEdge e553_94 floor94 262272 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c554 : Chart := ⟨[16512, 33280, 34816, 66048, 262272, 264192],[640, 2688, 18944, 67712, 83968, 98432, 279040, 376832]⟩
def m554_520 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e554_520 : Edge c554 c520 m554_520 := by
  exact edgeByCodes c554 c520 m554_520 21542142465 30165762817 (by decide) (by decide) (by decide) (by decide)
theorem floor554 : Floor c554 5 := by
  have up := refundEdge e554_520 floor520 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c555 : Chart := ⟨[16512, 16640, 33024, 33280, 34816, 66048, 262272, 264192],[640, 896, 2688, 18944, 67968, 83968, 98432, 262912, 279040, 327936, 376832]⟩
def m555_436 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e555_436 : Edge c555 c436 m555_436 := by
  exact edgeByCodes c555 c436 m555_436 1976939137073408 722835462594626561 (by decide) (by decide) (by decide) (by decide)
theorem floor555 : Floor c555 7 := by
  have up := refundEdge e555_436 floor436 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c556 : Chart := ⟨[16512, 17408, 34816, 66560, 262272, 264192],[2176, 3200, 33920, 67712, 83968, 98432, 295936, 376832]⟩
def m556_489 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e556_489 : Edge c556 c489 m556_489 := by
  exact edgeByCodes c556 c489 m556_489 21542142208 7722452124417 (by decide) (by decide) (by decide) (by decide)
theorem floor556 : Floor c556 5 := by
  have up := refundEdge e556_489 floor489 34816 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c557 : Chart := ⟨[16640, 17408, 33024, 34816, 66560, 264192],[1024, 3328, 67840, 83968, 263424, 295936, 327936, 376832]⟩
def m557_438 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e557_438 : Edge c557 c438 m557_438 := by
  exact edgeByCodes c557 c438 m557_438 21525299456 30148920065 (by decide) (by decide) (by decide) (by decide)
theorem floor557 : Floor c557 5 := by
  have up := refundEdge e557_438 floor438 66560 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c558 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 66560, 262272, 264192],[1152, 3200, 3328, 33920, 67968, 83968, 98432, 263424, 295936, 327936, 376832]⟩
def m558_439 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e558_439 : Edge c558 c439 m558_439 := by
  exact edgeByCodes c558 c439 m558_439 1976939137073408 722835449743278340 (by decide) (by decide) (by decide) (by decide)
theorem floor558 : Floor c558 7 := by
  have up := refundEdge e558_439 floor439 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c559 : Chart := ⟨[17408, 33280, 34816, 66048, 66560, 264192],[1536, 3584, 18944, 83968, 263680, 279040, 295936, 376832]⟩
def m559_521 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e559_521 : Edge c559 c521 m559_521 := by
  exact edgeByCodes c559 c521 m559_521 21542142465 7722418504449 (by decide) (by decide) (by decide) (by decide)
theorem floor559 : Floor c559 5 := by
  have up := refundEdge e559_521 floor521 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c560 : Chart := ⟨[16512, 17408, 33280, 34816, 66048, 66560, 262272, 264192],[3712, 18944, 33920, 67712, 83968, 98432, 263680, 279040, 295936, 376832]⟩
def m560_559 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e560_559 : Edge c560 c559 m560_559 := by
  exact edgeByCodes c560 c559 m560_559 7718123536897 650777868573409280 (by decide) (by decide) (by decide) (by decide)
def m560_556 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e560_556 : Edge c560 c556 m560_556 := by
  exact edgeByCodes c560 c556 m560_556 7722435281152 650775660943507456 (by decide) (by decide) (by decide) (by decide)
def m560_554 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e560_554 : Edge c560 c554 m560_554 := by
  exact edgeByCodes c560 c554 m560_554 7722418504192 650494185966731264 (by decide) (by decide) (by decide) (by decide)
def m560_552 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e560_552 : Edge c560 c552 m560_552 := by
  exact edgeByCodes c560 c552 m560_552 6618611843328 650777868590252032 (by decide) (by decide) (by decide) (by decide)
def m560_522 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e560_522 : Edge c560 c522 m560_522 := by
  exact edgeByCodes c560 c522 m560_522 7722435347202 650776769078690304 (by decide) (by decide) (by decide) (by decide)
def m560_490 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e560_490 : Edge c560 c490 m560_490 := by
  exact edgeByCodes c560 c490 m560_490 7722435346688 650495285478490368 (by decide) (by decide) (by decide) (by decide)
def m560_440 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e560_440 : Edge c560 c440 m560_440 := by
  exact edgeByCodes c560 c440 m560_440 7722401661184 2542101048983808 (by decide) (by decide) (by decide) (by decide)
def m560_96 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, none, none, none, none]
theorem e560_96 : Edge c560 c96 m560_96 := by
  exact edgeByCodes c560 c96 m560_96 5514788471040 2538789578866944 (by decide) (by decide) (by decide) (by decide)
theorem floor560 : Floor c560 7 := by
  apply protectedBranch source c560.P c560.N (decode 380544) 7
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 380544, q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e560_559 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor559 k x net fit)
    · refine ⟨_,goodChild e560_556 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor556 k x net fit)
    · refine ⟨_,goodChild e560_554 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor554 k x net fit)
    · refine ⟨_,goodChild e560_552 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor552 k x net fit)
    · refine ⟨_,goodChild e560_522 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor522 k x net fit)
    · refine ⟨_,goodChild e560_490 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor490 k x net fit)
    · refine ⟨_,goodChild e560_440 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor440 k x net fit)
    · refine ⟨_,goodChild e560_96 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor96 k x net fit)
  · exact pairExcluded 380544 380544 [16512, 17408, 33280, 34816, 66048, 66560, 262272, 264192] [3712, 18944, 33920, 67712, 83968, 98432, 263680, 279040, 295936, 376832] validBranch380544 (by decide) (by decide) (by decide)
def c561 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560, 264192],[2304, 3328, 3584, 18944, 67840, 83968, 263936, 279040, 295936, 327936, 376832]⟩
def m561_97 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, none, none, none, none]
theorem e561_97 : Edge c561 c97 m561_97 := by
  exact edgeByCodes c561 c97 m561_97 1694364648734976 721987747719545094 (by decide) (by decide) (by decide) (by decide)
theorem floor561 : Floor c561 7 := by
  have up := refundEdge e561_97 floor97 264192 2304 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c562 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 262272, 264192],[896, 3328, 3712, 18944, 33920, 67968, 83968, 98432, 263936, 279040, 295936, 327936, 376832]⟩
def m562_561 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e562_561 : Edge c562 c561 m562_561 := by
  exact edgeByCodes c562 c561 m562_561 650495289790235137 14559240984904618039443713 (by decide) (by decide) (by decide) (by decide)
def m562_560 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e562_560 : Edge c562 c560 m562_560 := by
  exact edgeByCodes c562 c560 m562_560 650777868590383616 56853516013041428464386 (by decide) (by decide) (by decide) (by decide)
def m562_558 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e562_558 : Edge c562 c558 m562_558 := by
  exact edgeByCodes c562 c558 m562_558 650777864261730560 14559240912565549041517058 (by decide) (by decide) (by decide) (by decide)
def m562_555 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e562_555 : Edge c562 c555 m562_555 := by
  exact edgeByCodes c562 c555 m562_555 650776764766945536 14559222465821475315253248 (by decide) (by decide) (by decide) (by decide)
def m562_553 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e562_553 : Edge c562 c553 m562_553 := by
  exact edgeByCodes c562 c553 m562_553 578437691440496896 14559240984905717567848448 (by decide) (by decide) (by decide) (by decide)
def m562_441 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e562_441 : Edge c562 c441 m562_441 := by
  exact edgeByCodes c562 c441 m562_441 650775660943507712 56853516009729958151424 (by decide) (by decide) (by decide) (by decide)
def m562_98 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, none, none, none, none]
theorem e562_98 : Edge c562 c98 m562_98 := by
  exact edgeByCodes c562 c98 m562_98 506097522914230528 56797958760301785581568 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
