import NumericEdgeCodes
import NumericGraph076Code01
import Branch519872
import Branch520064
import NumericGraph029
import NumericGraph030
import NumericGraph049
import NumericGraph059
import NumericGraph060
import NumericGraph067
import NumericGraph070
import NumericGraph073
import NumericGraph075
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem floor920 : Floor c920 12 := by
  apply protectedBranch source c920.P c920.N (decode 520064) 12
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 520064, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e920_918 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor918 k x net fit)
    · refine ⟨_,goodChild e920_915 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor915 k x net fit)
    · refine ⟨_,goodChild e920_912 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor912 k x net fit)
    · refine ⟨_,goodChild e920_909 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor909 k x net fit)
    · refine ⟨_,goodChild e920_906 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor906 k x net fit)
    · refine ⟨_,goodChild e920_882 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor882 k x net fit)
    · refine ⟨_,goodChild e920_848 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor848 k x net fit)
    · refine ⟨_,goodChild e920_806 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor806 k x net fit)
    · refine ⟨_,goodChild e920_720 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor720 k x net fit)
    · refine ⟨_,goodChild e920_592 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor592 k x net fit)
    · refine ⟨_,goodChild e920_362 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor362 k x net fit)
  · exact pairExcluded 520064 520064 [8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192] [3712, 11520, 18944, 33920, 67968, 76032, 92160, 131968, 188416, 196992, 229504, 263936, 271616, 304128, 376832, 393984, 410112, 467200] validBranch520064 (by decide) (by decide) (by decide)
def c921 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[3712, 9472, 11520, 19008, 33984, 68032, 76032, 84032, 92160, 98496, 131968, 188416, 196992, 229504, 264000, 271616, 279104, 296000, 304128, 328000, 376896, 393984, 410112, 467200]⟩
def m921_920 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e921_920 : Edge c921 c920 m921_920 := by
  exact edgeByCodes c921 c920 m921_920 305349376189602533910017493631489 2011096806502871116864916701809643054367232 (by decide) (by decide) (by decide) (by decide)
theorem floor921 : Floor c921 13 := by
  have up := refundEdge e921_920 floor920 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c922 : Chart := ⟨[8196, 8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[3204, 3332, 3588, 3712, 9472, 11520, 18948, 19008, 33924, 33984, 67908, 67972, 68032, 76032, 84036, 92160, 98496, 131968, 180228, 188416, 196996, 229508, 263492, 263940, 264000, 271616, 279104, 296004, 304128, 328004, 376900, 393988, 410116, 459012, 467200]⟩
def m922_921 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e922_921 : Edge c922 c921 m922_921 := by
  exact edgeByCodes c922 c921 m922_921 21345817372864405881847059188222722561 836754207801005808768171531039523416044330025349214962691 (by decide) (by decide) (by decide) (by decide)
theorem floor922 : Floor c922 14 := by
  have up := refundEdge e922_921 floor921 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 14 ≤ 14).trans (up k x net fit)
def c923 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 33024, 33280, 66048, 2166784, 2228288, 262272, 2363392],[2101568, 2101696, 2102080, 2118208, 2134208, 2150464, 2163136, 90112, 2195648, 2233216, 2240768, 2249216, 2265216, 2289664, 196992, 229504, 2360128, 2376256, 303104, 2425152, 2474048, 393984, 410112, 467200]⟩
def m923_597 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, none, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 21]
theorem e923_597 : Edge c923 c597 m923_597 := by
  exact edgeByCodes c923 c597 m923_597 13345555760639729964548352 1750097562213720982854058394563605005140481 (by decide) (by decide) (by decide) (by decide)
theorem floor923 : Floor c923 11 := by
  have up := refundEdge e923_597 floor597 2228288 2101568 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)


end TightRow.Protected.Numeric
