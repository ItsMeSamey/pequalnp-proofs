import NumericEdgeCodes
import NumericGraph067Code00
import Branch488640
import NumericGraph024
import NumericGraph042
import NumericGraph055
import NumericGraph064
import NumericGraph065
import NumericGraph066
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem floor814 : Floor c814 10 := by
  have up := refundEdge e814_812 floor812 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c815 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 2166784, 2228288, 132096, 262272, 2363392],[1664, 2101696, 2102080, 2102464, 2102592, 2110464, 2110720, 2118208, 2163136, 90112, 2233216, 2240768, 2249216, 2256896, 196992, 2361152, 271616, 2376256, 2425152, 2441280, 393984, 410112, 467200]⟩
def m815_814 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 12]
theorem e815_814 : Edge c815 c814 m815_814 := by
  exact edgeByCodes c815 c814 m815_814 14559240912565549041648129 29352461299794501786755761029004002048 (by decide) (by decide) (by decide) (by decide)
theorem floor815 : Floor c815 11 := by
  have up := refundEdge e815_814 floor814 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)


end TightRow.Protected.Numeric
