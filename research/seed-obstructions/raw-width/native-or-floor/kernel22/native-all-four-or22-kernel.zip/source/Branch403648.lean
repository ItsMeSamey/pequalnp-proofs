import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short403648
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8320, 131136, 133120, 262272, 264192]
def n : List Nat := [2240, 10240, 131200, 262208, 401408]
def pp := p.map (canonical 403648)
def nn := n.map (canonical 403648)
def parts : List Nat := [0, 64, 128, 2048, 8192, 131072, 262144, 8256, 8320, 131136, 133120, 262272, 264192]
def g : ShortGrid := [(0,[(64,309489732259886631936327937), (128,79538861190790864407636279553), (2048,238307093840112706590972510721), (8192,1), (8256,256), (8320,0), (131072,158458742917061955551399903233), (131136,8590000128), (133120,8589935104), (262144,316917485834123911102799806465), (262272,17179934976), (264192,17180001024)]), (64,[(128,17230266368), (2048,21525233664), (8192,1099511627776), (8320,0), (131072,8590000128), (133120,8590000128), (262144,17179934720), (262272,17179934720), (264192,17179934720)]), (128,[(2048,12918522112), (8192,282574488338432), (8256,256), (131072,8590000384), (131136,65536), (133120,8590000384), (262144,17179934976), (264192,17179934976)]), (2048,[(8192,848822976643072), (8256,256), (8320,0), (131072,846623953388032), (131136,65536), (262144,17180001024), (262272,65792)]), (8192,[(131072,12901679104), (131136,16777216), (133120,12901679104), (262144,21491613696), (262272,4311744512), (264192,21491613696)]), (8256,[(131072,256), (133120,256), (262144,256), (262272,256), (264192,256)]), (8320,[(131072,0), (131136,0), (133120,0), (262144,0), (264192,0)]), (131072,[(262144,17213424128), (262272,65792), (264192,12918456832)]), (131136,[(262144,65536), (262272,65536), (264192,65536)]), (133120,[(262144,512), (262272,65792)])]
private theorem row0 : parts.all (shortPair g pp nn 403648 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 403648 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 403648 128) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 403648 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 403648 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 403648 131072) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 403648 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 403648 8256) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 403648 8320) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 403648 131136) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 403648 133120) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 403648 262272) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 403648 264192) = true := by decide
theorem full : checkArms 403648 403648 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 128, 2048, 8192, 131072, 262144, 8256, 8320, 131136, 133120, 262272, 264192] : List Nat).all (fun i => parts.all (shortPair g pp nn 403648 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short403648
theorem validBranch403648 : checkArms 403648 403648 [8256, 8320, 131136, 133120, 262272, 264192] [2240, 10240, 131200, 262208, 401408] = true := Short403648.full
end TightRow.Protected.Numeric
