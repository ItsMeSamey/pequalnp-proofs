import NumericEdgeCodes
import NumericGraph049Code00
import Branch388736
import Branch390016
import NumericGraph009
import NumericGraph037
import NumericGraph038
import NumericGraph042
import NumericGraph044
import NumericGraph045
import NumericGraph046
import NumericGraph047
import NumericGraph048
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m595_115 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, some 13, some 14, some 15, some 16, none, none, none, none, none]
theorem e595_115 : Edge c595 c115 m595_115 := by
  exact edgeByCodes c595 c115 m595_115 506097522914230528 56797960450255469281536 (by decide) (by decide) (by decide) (by decide)
theorem floor595 : Floor c595 9 := by
  apply protectedBranch source c595.P c595.N (decode 389376) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 389376, q = 8 ∨ q = 12 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e595_594 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor594 k x net fit)
    · refine ⟨_,goodChild e595_585 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor585 k x net fit)
    · refine ⟨_,goodChild e595_566 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor566 k x net fit)
    · refine ⟨_,goodChild e595_541 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor541 k x net fit)
    · refine ⟨_,goodChild e595_509 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor509 k x net fit)
    · refine ⟨_,goodChild e595_458 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor458 k x net fit)
    · refine ⟨_,goodChild e595_115 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor115 k x net fit)
  · exact pairExcluded 390016 389376 [8320, 8704, 16512, 16640, 33024, 33280, 66048, 69632, 262272, 266240] [4992, 12544, 20992, 36992, 61440, 65920, 90112, 98432, 262912, 279040, 303104, 336128, 376832] validBranch390016 (by decide) (by decide) (by decide)
def c596 : Chart := ⟨[8196, 8320, 8704, 16512, 16640, 33024, 33280, 66048, 69632, 262272, 266240],[4992, 8448, 12544, 20996, 36996, 53252, 61440, 65924, 90112, 98436, 262916, 279044, 303104, 327940, 336128, 376836]⟩
def m596_595 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e596_595 : Edge c596 c595 m596_595 := by
  exact edgeByCodes c596 c595 m596_595 47390263963055590408705 1192769787092448800587169071616 (by decide) (by decide) (by decide) (by decide)
theorem floor596 : Floor c596 10 := by
  have up := refundEdge e596_595 floor595 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c597 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 33024, 33280, 66048, 2166784, 262272, 2363392],[2101696, 2102080, 2102144, 2109440, 2109696, 2118208, 2134208, 2150464, 2158592, 2163136, 90112, 2195648, 2360128, 2376256, 303104, 2425152, 336128, 2474048]⟩
def m597_595 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 12]
theorem e597_595 : Edge c597 c595 m597_595 := by
  exact edgeByCodes c597 c595 m597_595 47390263963055590408705 1351847509474030529402441630722 (by decide) (by decide) (by decide) (by decide)
theorem floor597 : Floor c597 10 := by
  have up := refundEdge e597_595 floor595 2105408 2109440 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c598 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 66048, 66560, 69632, 262272, 266240],[640, 1664, 4736, 20992, 38016, 46080, 61440, 90112, 98432, 263680, 279040, 304128, 335872, 376832]⟩
def m598_513 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e598_513 : Edge c598 c513 m598_513 := by
  exact edgeByCodes c598 c513 m598_513 166599134359121428736 1033692074174047345630117102081 (by decide) (by decide) (by decide) (by decide)
theorem floor598 : Floor c598 9 := by
  have up := refundEdge e598_513 floor513 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c599 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632, 262272, 266240],[1664, 4992, 13568, 16896, 20992, 38016, 46080, 61440, 65920, 90112, 98432, 263936, 271616, 279040, 304128, 336128, 376832]⟩
def m599_598 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e599_598 : Edge c599 c598 m599_598 := by
  exact edgeByCodes c599 c598 m599_598 52131149530171766341888 325711324654444994915793580916736 (by decide) (by decide) (by decide) (by decide)
theorem floor599 : Floor c599 10 := by
  have up := refundEdge e599_598 floor598 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)


end TightRow.Protected.Numeric
