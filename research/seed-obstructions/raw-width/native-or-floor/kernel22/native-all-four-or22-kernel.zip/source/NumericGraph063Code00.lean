import NumericEdgeCodes
import Branch470656
import Branch470720
import NumericGraph022
import NumericGraph039
import NumericGraph052
import NumericGraph053
import NumericGraph061
import NumericGraph062
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c756 : Chart := ⟨[8256, 8704, 66048, 131136, 133120, 264192],[512, 2624, 67648, 75776, 262720, 327744, 393728, 466944]⟩
def m756_630 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e756_630 : Edge c756 c630 m756_630 := by
  exact edgeByCodes c756 c630 m756_630 21542142208 7722418504449 (by decide) (by decide) (by decide) (by decide)
theorem floor756 : Floor c756 5 := by
  have up := refundEdge e756_630 floor630 66048 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c757 : Chart := ⟨[8320, 8704, 66048, 133120, 262272, 264192],[640, 2688, 67712, 75776, 131712, 196736, 393728, 466944]⟩
def m757_631 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e757_631 : Edge c757 c631 m757_631 := by
  exact edgeByCodes c757 c631 m757_631 21542142208 7722418504449 (by decide) (by decide) (by decide) (by decide)
theorem floor757 : Floor c757 5 := by
  have up := refundEdge e757_631 floor631 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c758 : Chart := ⟨[8256, 8320, 8704, 66048, 131136, 133120, 262272, 264192],[640, 2624, 2688, 67776, 75776, 131712, 196736, 262720, 327744, 393728, 466944]⟩
def m758_632 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e758_632 : Edge c758 c632 m758_632 := by
  exact edgeByCodes c758 c632 m758_632 1976943448817920 185117934923079090435 (by decide) (by decide) (by decide) (by decide)
theorem floor758 : Floor c758 7 := by
  have up := refundEdge e758_632 floor632 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c759 : Chart := ⟨[8320, 66560, 132096, 133120, 262272, 264192],[128, 3200, 11264, 67712, 75776, 196736, 271360, 466944]⟩
def m759_736 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e759_736 : Edge c759 c736 m759_736 := by
  exact edgeByCodes c759 c736 m759_736 21542142465 7722452189953 (by decide) (by decide) (by decide) (by decide)
theorem floor759 : Floor c759 5 := by
  have up := refundEdge e759_736 floor736 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c760 : Chart := ⟨[8256, 8320, 66560, 131136, 132096, 133120, 262272, 264192],[1152, 1216, 3200, 11264, 67776, 75776, 196736, 263232, 271360, 327744, 466944]⟩
def m760_634 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e760_634 : Edge c760 c634 m760_634 := by
  exact edgeByCodes c760 c634 m760_634 1976943448883456 722835462594626561 (by decide) (by decide) (by decide) (by decide)
theorem floor760 : Floor c760 7 := by
  have up := refundEdge e760_634 floor634 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c761 : Chart := ⟨[8704, 66048, 66560, 132096, 133120, 264192],[512, 3584, 11264, 75776, 263680, 271360, 393728, 466944]⟩
def m761_737 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e761_737 : Edge c761 c737 m761_737 := by
  exact edgeByCodes c761 c737 m761_737 21542142465 7722418504449 (by decide) (by decide) (by decide) (by decide)
theorem floor761 : Floor c761 5 := by
  have up := refundEdge e761_737 floor737 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c762 : Chart := ⟨[8256, 8704, 66048, 66560, 131136, 132096, 133120, 264192],[2048, 2624, 3584, 11264, 67648, 75776, 263744, 271360, 327744, 393728, 466944]⟩
def m762_273 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, none, none, none, none]
theorem e762_273 : Edge c762 c273 m762_273 := by
  exact edgeByCodes c762 c273 m762_273 1694364648734976 185118497873015734534 (by decide) (by decide) (by decide) (by decide)
theorem floor762 : Floor c762 7 := by
  have up := refundEdge e762_273 floor273 264192 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c763 : Chart := ⟨[8320, 8704, 66048, 66560, 132096, 133120, 262272, 264192],[3712, 11264, 67712, 75776, 131712, 196736, 263680, 271360, 393728, 466944]⟩
def m763_761 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e763_761 : Edge c763 c761 m763_761 := by
  exact edgeByCodes c763 c761 m763_761 7718123536897 650777868556632064 (by decide) (by decide) (by decide) (by decide)
def m763_759 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e763_759 : Edge c763 c759 m763_759 := by
  exact edgeByCodes c763 c759 m763_759 7722435347200 650494181654986752 (by decide) (by decide) (by decide) (by decide)
def m763_757 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e763_757 : Edge c763 c757 m763_757 := by
  exact edgeByCodes c763 c757 m763_757 7722435215616 650775660943507456 (by decide) (by decide) (by decide) (by decide)
def m763_754 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e763_754 : Edge c763 c754 m763_754 := by
  exact edgeByCodes c763 c754 m763_754 6614300098816 2542101049181184 (by decide) (by decide) (by decide) (by decide)
def m763_738 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e763_738 : Edge c763 c738 m763_738 := by
  exact edgeByCodes c763 c738 m763_738 7722435347202 650776769078755840 (by decide) (by decide) (by decide) (by decide)
def m763_635 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e763_635 : Edge c763 c635 m763_635 := by
  exact edgeByCodes c763 c635 m763_635 7722435346688 650777868573409536 (by decide) (by decide) (by decide) (by decide)
def m763_474 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, none, some 16, none, some 18, none, none, none]
theorem e763_474 : Edge c763 c474 m763_474 := by
  exact edgeByCodes c763 c474 m763_474 7722401661184 650495281166680320 (by decide) (by decide) (by decide) (by decide)
def m763_274 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, none, none, none, none]
theorem e763_274 : Edge c763 c274 m763_274 := by
  exact edgeByCodes c763 c274 m763_274 5514788471040 649930132189937920 (by decide) (by decide) (by decide) (by decide)
theorem floor763 : Floor c763 7 := by
  apply protectedBranch source c763.P c763.N (decode 470656) 7
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 470656, q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e763_761 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor761 k x net fit)
    · refine ⟨_,goodChild e763_759 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor759 k x net fit)
    · refine ⟨_,goodChild e763_757 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor757 k x net fit)
    · refine ⟨_,goodChild e763_754 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor754 k x net fit)
    · refine ⟨_,goodChild e763_738 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor738 k x net fit)
    · refine ⟨_,goodChild e763_635 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor635 k x net fit)
    · refine ⟨_,goodChild e763_474 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor474 k x net fit)
    · refine ⟨_,goodChild e763_274 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor274 k x net fit)
  · exact pairExcluded 470656 470656 [8320, 8704, 66048, 66560, 132096, 133120, 262272, 264192] [3712, 11264, 67712, 75776, 131712, 196736, 263680, 271360, 393728, 466944] validBranch470656 (by decide) (by decide) (by decide)
def c764 : Chart := ⟨[8256, 8320, 8704, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[1216, 2624, 3712, 11264, 67776, 75776, 131712, 196736, 263744, 271360, 327744, 393728, 466944]⟩
def m764_763 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e764_763 : Edge c764 c763 m764_763 := by
  exact edgeByCodes c764 c763 m764_763 650777868573540865 56871962757115138016002 (by decide) (by decide) (by decide) (by decide)
def m764_762 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e764_762 : Edge c764 c762 m764_762 := by
  exact edgeByCodes c764 c762 m764_762 650495289790235136 14559240984903514232848641 (by decide) (by decide) (by decide) (by decide)
def m764_760 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e764_760 : Edge c764 c760 m764_760 := by
  exact edgeByCodes c764 c760 m764_760 650777868590383360 14554500099337501863444480 (by decide) (by decide) (by decide) (by decide)
def m764_758 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e764_758 : Edge c764 c758 m764_758 := by
  exact edgeByCodes c764 c758 m764_758 650777864261730560 14559240912565549041582338 (by decide) (by decide) (by decide) (by decide)
def m764_755 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e764_755 : Edge c764 c755 m764_755 := by
  exact edgeByCodes c764 c755 m764_755 578155116952158464 14559240984905721862815746 (by decide) (by decide) (by decide) (by decide)
def m764_636 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e764_636 : Edge c764 c636 m764_636 := by
  exact edgeByCodes c764 c636 m764_636 650777868590252288 14559222465536693196882944 (by decide) (by decide) (by decide) (by decide)
def m764_275 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, none, none, none, none]
theorem e764_275 : Edge c764 c275 m764_275 := by
  exact edgeByCodes c764 c275 m764_275 506097522914230528 14540277442637261420169216 (by decide) (by decide) (by decide) (by decide)
theorem floor764 : Floor c764 9 := by
  apply protectedBranch source c764.P c764.N (decode 331456) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 331456, q = 6 ∨ q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e764_763 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor763 k x net fit)
    · refine ⟨_,goodChild e764_762 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor762 k x net fit)
    · refine ⟨_,goodChild e764_760 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor760 k x net fit)
    · refine ⟨_,goodChild e764_758 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor758 k x net fit)
    · refine ⟨_,goodChild e764_755 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor755 k x net fit)
    · refine ⟨_,goodChild e764_636 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor636 k x net fit)
    · refine ⟨_,goodChild e764_275 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor275 k x net fit)
  · exact pairExcluded 470720 331456 [8256, 8320, 8704, 66048, 66560, 131136, 132096, 133120, 262272, 264192] [1216, 2624, 3712, 11264, 67776, 75776, 131712, 196736, 263744, 271360, 327744, 393728, 466944] validBranch470720 (by decide) (by decide) (by decide)
def c765 : Chart := ⟨[8196, 8256, 8320, 8704, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[1216, 2624, 3204, 3588, 3712, 9216, 11264, 67652, 67716, 67776, 75776, 131712, 196740, 263236, 263684, 263744, 271360, 327748, 393732, 458756, 466944]⟩

end TightRow.Protected.Numeric
