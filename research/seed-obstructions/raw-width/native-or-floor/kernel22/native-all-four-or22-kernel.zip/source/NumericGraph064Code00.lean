import NumericEdgeCodes
import Branch472256
import Branch473664
import NumericGraph023
import NumericGraph040
import NumericGraph053
import NumericGraph061
import NumericGraph062
import NumericGraph063
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c768 : Chart := ⟨[2105408, 66560, 2166784, 2228288, 132096, 2363392],[2101312, 2102336, 2110464, 2240512, 2360384, 271360, 2424896, 466944]⟩
def m768_740 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, some 12, none, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e768_740 : Edge c768 c740 m768_740 := by
  exact edgeByCodes c768 c740 m768_740 21542142465 30165697281 (by decide) (by decide) (by decide) (by decide)
theorem floor768 : Floor c768 5 := by
  have up := refundEdge e768_740 floor740 2105408 2101312 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c769 : Chart := ⟨[8320, 66560, 69632, 132096, 262272, 266240],[128, 5248, 13312, 135296, 143360, 196736, 271360, 466944]⟩
def m769_741 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e769_741 : Edge c769 c741 m769_741 := by
  exact edgeByCodes c769 c741 m769_741 21542142465 7722452189953 (by decide) (by decide) (by decide) (by decide)
theorem floor769 : Floor c769 5 := by
  have up := refundEdge e769_741 floor741 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c770 : Chart := ⟨[2105408, 8320, 66560, 2166784, 2228288, 132096, 262272, 2363392],[2102464, 2110464, 2162880, 2232448, 2240512, 196736, 2360384, 271360, 2424896, 466944]⟩
def m770_769 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 12]
theorem e770_769 : Edge c770 c769 m770_769 := by
  exact edgeByCodes c770 c769 m770_769 7722435281409 650494185966731264 (by decide) (by decide) (by decide) (by decide)
def m770_768 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e770_768 : Edge c770 c768 m770_768 := by
  exact edgeByCodes c770 c768 m770_768 7718123536896 650777868573409280 (by decide) (by decide) (by decide) (by decide)
def m770_766 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e770_766 : Edge c770 c766 m770_766 := by
  exact edgeByCodes c770 c766 m770_766 7722418503936 650775660943507456 (by decide) (by decide) (by decide) (by decide)
def m770_753 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, none, none, some 16, some 17, some 18, none, none, some 6]
theorem e770_753 : Edge c770 c753 m770_753 := by
  exact edgeByCodes c770 c753 m770_753 6618611843328 650777868590252032 (by decide) (by decide) (by decide) (by decide)
def m770_742 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, none, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e770_742 : Edge c770 c742 m770_742 := by
  exact edgeByCodes c770 c742 m770_742 7722435347202 2542096737305088 (by decide) (by decide) (by decide) (by decide)
def m770_638 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, none, none, none, some 17, some 18, none, none, some 21]
theorem e770_638 : Edge c770 c638 m770_638 := by
  exact edgeByCodes c770 c638 m770_638 7722435346688 650495285478490368 (by decide) (by decide) (by decide) (by decide)
def m770_481 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, none, none, some 16, none, some 18, none, none, some 21]
theorem e770_481 : Edge c770 c481 m770_481 := by
  exact edgeByCodes c770 c481 m770_481 7722401661184 2542101048983808 (by decide) (by decide) (by decide) (by decide)
def m770_279 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, none, none, some 16, some 17, none, none, none, some 21]
theorem e770_279 : Edge c770 c279 m770_279 := by
  exact edgeByCodes c770 c279 m770_279 5514788471040 649930132189937920 (by decide) (by decide) (by decide) (by decide)
theorem floor770 : Floor c770 7 := by
  apply protectedBranch source c770.P c770.N (decode 472256) 7
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 472256, q = 6 ∨ q = 7 ∨ q = 10 ∨ q = 12 ∨ q = 13 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e770_769 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor769 k x net fit)
    · refine ⟨_,goodChild e770_768 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor768 k x net fit)
    · refine ⟨_,goodChild e770_766 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor766 k x net fit)
    · refine ⟨_,goodChild e770_753 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor753 k x net fit)
    · refine ⟨_,goodChild e770_742 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor742 k x net fit)
    · refine ⟨_,goodChild e770_638 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor638 k x net fit)
    · refine ⟨_,goodChild e770_481 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor481 k x net fit)
    · refine ⟨_,goodChild e770_279 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor279 k x net fit)
  · exact pairExcluded 472256 472256 [8256, 8320, 66560, 69632, 131136, 132096, 262272, 266240] [5312, 13312, 65728, 135296, 143360, 196736, 263232, 271360, 327744, 466944] validBranch472256 (by decide) (by decide) (by decide)
def c771 : Chart := ⟨[8320, 8704, 66048, 66560, 69632, 132096, 262272, 266240],[1664, 5248, 13312, 135808, 143360, 196736, 263680, 271360, 393728, 466944]⟩
def m771_482 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
theorem e771_482 : Edge c771 c482 m771_482 := by
  exact edgeByCodes c771 c482 m771_482 1976939137073408 650495289756549888 (by decide) (by decide) (by decide) (by decide)
theorem floor771 : Floor c771 7 := by
  have up := refundEdge e771_482 floor482 132096 1664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c772 : Chart := ⟨[2105408, 2166784, 2228288, 133120, 264192, 2363392],[2101312, 2103360, 2111488, 2164800, 75776, 2240512, 2424896, 466944]⟩
def m772_744 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e772_744 : Edge c772 c744 m772_744 := by
  exact edgeByCodes c772 c744 m772_744 21542142465 30165762817 (by decide) (by decide) (by decide) (by decide)
theorem floor772 : Floor c772 5 := by
  have up := refundEdge e772_744 floor744 2105408 2101312 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c773 : Chart := ⟨[8704, 66048, 69632, 133120, 264192, 266240],[512, 6656, 14336, 75776, 135680, 143360, 393728, 466944]⟩
def m773_745 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e773_745 : Edge c773 c745 m773_745 := by
  exact edgeByCodes c773 c745 m773_745 21542142465 7722418504449 (by decide) (by decide) (by decide) (by decide)
theorem floor773 : Floor c773 5 := by
  have up := refundEdge e773_745 floor745 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c774 : Chart := ⟨[2105408, 8704, 66048, 2166784, 2228288, 133120, 264192, 2363392],[2103872, 2111488, 2164800, 75776, 2232832, 2240512, 2359872, 2424896, 393728, 466944]⟩
def m774_773 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 12]
theorem e774_773 : Edge c774 c773 m774_773 := by
  exact edgeByCodes c774 c773 m774_773 7722435281409 650775660943441920 (by decide) (by decide) (by decide) (by decide)
def m774_772 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e774_772 : Edge c774 c772 m774_772 := by
  exact edgeByCodes c774 c772 m774_772 7722435347200 650494181654986752 (by decide) (by decide) (by decide) (by decide)
def m774_767 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e774_767 : Edge c774 c767 m774_767 := by
  exact edgeByCodes c774 c767 m774_767 7713811726592 650777868590383104 (by decide) (by decide) (by decide) (by decide)
def m774_756 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, some 6]
theorem e774_756 : Edge c774 c756 m774_756 := by
  exact edgeByCodes c774 c756 m774_756 6618611843328 650777868556697600 (by decide) (by decide) (by decide) (by decide)
def m774_746 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e774_746 : Edge c774 c746 m774_746 := by
  exact edgeByCodes c774 c746 m774_746 7722435347202 650777868573606400 (by decide) (by decide) (by decide) (by decide)
def m774_644 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, some 13, none, none, none, some 17, some 18, none, none, some 21]
theorem e774_644 : Edge c774 c644 m774_644 := by
  exact edgeByCodes c774 c644 m774_644 7722435346688 650776764766814464 (by decide) (by decide) (by decide) (by decide)
def m774_484 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, some 13, none, none, some 16, none, some 18, none, none, some 21]
theorem e774_484 : Edge c774 c484 m774_484 := by
  exact edgeByCodes c774 c484 m774_484 7722401661184 650495281166614784 (by decide) (by decide) (by decide) (by decide)
def m774_280 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, some 13, none, none, some 16, some 17, none, none, none, some 21]
theorem e774_280 : Edge c774 c280 m774_280 := by
  exact edgeByCodes c774 c280 m774_280 5514788471040 649930136501747968 (by decide) (by decide) (by decide) (by decide)
theorem floor774 : Floor c774 7 := by
  apply protectedBranch source c774.P c774.N (decode 473664) 7
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 473664, q = 6 ∨ q = 9 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e774_773 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor773 k x net fit)
    · refine ⟨_,goodChild e774_772 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor772 k x net fit)
    · refine ⟨_,goodChild e774_767 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor767 k x net fit)
    · refine ⟨_,goodChild e774_756 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor756 k x net fit)
    · refine ⟨_,goodChild e774_746 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor746 k x net fit)
    · refine ⟨_,goodChild e774_644 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor644 k x net fit)
    · refine ⟨_,goodChild e774_484 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor484 k x net fit)
    · refine ⟨_,goodChild e774_280 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor280 k x net fit)
  · exact pairExcluded 473664 473664 [8256, 8704, 66048, 69632, 131136, 133120, 264192, 266240] [6720, 14336, 67648, 75776, 135680, 143360, 262720, 327744, 393728, 466944] validBranch473664 (by decide) (by decide) (by decide)
def c775 : Chart := ⟨[8196, 2105408, 8704, 66048, 2166784, 2228288, 133120, 264192, 2363392],[2103364, 2103812, 2103872, 8192, 2111488, 2164804, 75776, 2232836, 2240512, 2359872, 2424900, 393732, 458756, 466944]⟩
def m775_774 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e775_774 : Edge c775 c774 m775_774 := by
  exact edgeByCodes c775 c774 m775_774 578437695752307201 61594401580157621306370 (by decide) (by decide) (by decide) (by decide)
theorem floor775 : Floor c775 8 := by
  have up := refundEdge e775_774 floor774 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 8 ≤ 8).trans (up k x net fit)
def c776 : Chart := ⟨[8320, 8704, 66048, 69632, 133120, 262272, 264192, 266240],[2176, 2688, 6656, 14336, 67712, 75776, 135808, 143360, 196736, 393728, 466944]⟩
def m776_485 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
theorem e776_485 : Edge c776 c485 m776_485 := by
  exact edgeByCodes c776 c485 m776_485 1976943432040704 723114729958147585 (by decide) (by decide) (by decide) (by decide)
theorem floor776 : Floor c776 7 := by
  have up := refundEdge e776_485 floor485 133120 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c777 : Chart := ⟨[2105408, 66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[2101312, 2102336, 2103360, 2112512, 2164800, 75776, 2240512, 2360384, 271360, 2424896, 466944]⟩
def m777_749 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e777_749 : Edge c777 c749 m777_749 := by
  exact edgeByCodes c777 c749 m777_749 1976943448883713 723116937588179457 (by decide) (by decide) (by decide) (by decide)
theorem floor777 : Floor c777 7 := by
  have up := refundEdge e777_749 floor749 2105408 2101312 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c778 : Chart := ⟨[8196, 2105408, 66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[2102340, 2103364, 2104324, 9216, 2112512, 2164804, 75776, 2232324, 2240512, 2360388, 271360, 2424900, 458756, 466944]⟩

end TightRow.Protected.Numeric
