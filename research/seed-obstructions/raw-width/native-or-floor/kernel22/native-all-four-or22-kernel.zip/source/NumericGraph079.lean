import NumericEdgeCodes
import NumericGraph079Code02
import Branch524096
import Branch524224
import NumericGraph031
import NumericGraph050
import NumericGraph051
import NumericGraph060
import NumericGraph061
import NumericGraph068
import NumericGraph072
import NumericGraph075
import NumericGraph076
import NumericGraph077
import NumericGraph078
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m952_951 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, some 7, some 21]
theorem e952_951 : Edge c952 c951 m952_951 := by
  exact edgeByCodes c952 c951 m952_951 425287986064908473408241445795885577178054912 10970148714794563288028804671054452596036107789167747875644424748236915960499711341896452021421625190771703037625347 (by decide) (by decide) (by decide) (by decide)
theorem floor952 : Floor c952 17 := by
  have up := refundEdge e952_951 floor951 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 17 ≤ 17).trans (up k x net fit)
def c953 : Chart := ⟨[524289],[1, 524288]⟩
theorem floor953 : Floor c953 0 := fun _ _ _ _ => Nat.zero_le _
def c954 : Chart := ⟨[524292],[4, 524288]⟩
theorem floor954 : Floor c954 0 := fun _ _ _ _ => Nat.zero_le _
def c955 : Chart := ⟨[524544],[256, 524288]⟩
theorem floor955 : Floor c955 0 := fun _ _ _ _ => Nat.zero_le _
def c956 : Chart := ⟨[528384],[4096, 524288]⟩
theorem floor956 : Floor c956 0 := fun _ _ _ _ => Nat.zero_le _
def c957 : Chart := ⟨[8196, 524292],[4, 532480]⟩
def m957_954 : List (Option Addr) := [none, none, some 2, none, none, none, none, none, none, none, none, none, none, none, none, none, none, none, none, some 19, none, none]
theorem e957_954 : Edge c957 c954 m957_954 := by
  exact edgeByCodes c957 c954 m957_954 1 256 (by decide) (by decide) (by decide) (by decide)
theorem floor957 : Floor c957 1 := by
  have up := refundEdge e957_954 floor954 8196 4 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c958 : Chart := ⟨[8196, 8256, 524292],[68, 8192, 524352, 532480]⟩
def m958_957 : List (Option Addr) := [none, none, some 2, none, none, none, none, none, none, none, none, none, none, some 13, none, none, none, none, none, some 19, none, none]
theorem e958_957 : Edge c958 c957 m958_957 := by
  exact edgeByCodes c958 c957 m958_957 512 768 (by decide) (by decide) (by decide) (by decide)
theorem floor958 : Floor c958 2 := by
  have up := refundEdge e958_957 floor957 8256 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c959 : Chart := ⟨[8196, 8256, 524289, 524292],[69, 8193, 524288, 524352, 532480]⟩
def m959_958 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, none, none, none, none, none, none, some 13, none, none, none, none, none, some 19, none, none]
theorem e959_958 : Edge c959 c958 m959_958 := by
  exact edgeByCodes c959 c958 m959_958 196864 67305728 (by decide) (by decide) (by decide) (by decide)
theorem floor959 : Floor c959 3 := by
  have up := refundEdge e959_958 floor958 524289 524288 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)


end TightRow.Protected.Numeric
