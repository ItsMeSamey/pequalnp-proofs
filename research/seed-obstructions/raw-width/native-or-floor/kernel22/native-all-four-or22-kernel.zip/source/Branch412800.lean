import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short412800
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16512, 17408, 132096, 133120, 262272, 264192]
def n : List Nat := [3200, 18432, 131200, 263168, 409600]
def pp := p.map (canonical 412800)
def nn := n.map (canonical 412800)
def parts : List Nat := [0, 128, 1024, 2048, 16384, 131072, 262144, 16512, 17408, 132096, 133120, 262272, 264192]
def g : ShortGrid := [(0,[(128,309489732259886631936327937), (1024,79538861190790864407636279553), (2048,238307093840112706590972510721), (16384,1), (16512,256), (17408,0), (131072,158458742917061955551399903233), (132096,8590000384), (133120,8589935104), (262144,316917485834123911102799806465), (262272,17179934720), (264192,17180001024)]), (128,[(1024,8623554560), (2048,12918521856), (16384,1099511627776), (17408,0), (131072,8590000128), (132096,8590000128), (133120,8590000128), (262144,17179934720), (264192,17179934720)]), (1024,[(2048,21525233920), (16384,282574488338432), (16512,256), (131072,8590000384), (133120,8590000384), (262144,17179934976), (262272,65536), (264192,17179934976)]), (2048,[(16384,848822976643072), (16512,256), (17408,0), (131072,846623953388032), (132096,65792), (262144,17180001024), (262272,65536)]), (16384,[(131072,12901679104), (132096,4311744512), (133120,12901679104), (262144,21491613696), (262272,16777216), (264192,21491613696)]), (16512,[(131072,256), (132096,256), (133120,256), (262144,256), (264192,256)]), (17408,[(131072,0), (133120,0), (262144,0), (262272,0), (264192,0)]), (131072,[(262144,17213424128), (262272,65536), (264192,12918456832)]), (132096,[(262144,65792), (262272,65536), (264192,65792)]), (133120,[(262144,512), (262272,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 412800 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 412800 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 412800 1024) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 412800 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 412800 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 412800 131072) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 412800 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 412800 16512) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 412800 17408) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 412800 132096) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 412800 133120) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 412800 262272) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 412800 264192) = true := by decide
theorem full : checkArms 412800 412800 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 1024, 2048, 16384, 131072, 262144, 16512, 17408, 132096, 133120, 262272, 264192] : List Nat).all (fun i => parts.all (shortPair g pp nn 412800 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short412800
theorem validBranch412800 : checkArms 412800 412800 [16512, 17408, 132096, 133120, 262272, 264192] [3200, 18432, 131200, 263168, 409600] = true := Short412800.full
end TightRow.Protected.Numeric
