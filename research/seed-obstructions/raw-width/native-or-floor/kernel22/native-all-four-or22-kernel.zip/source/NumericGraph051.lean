import NumericEdgeCodes
import NumericGraph051Code00
import Branch393088
import NumericGraph009
import NumericGraph032
import NumericGraph038
import NumericGraph043
import NumericGraph045
import NumericGraph048
import NumericGraph049
import NumericGraph050
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem floor616 : Floor c616 2 := by
  have up := refundEdge e616_615 floor615 131136 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c617 : Chart := ⟨[133120, 262272, 264192],[2176, 131200, 262144, 393216]⟩
def m617_615 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
theorem e617_615 : Edge c617 c615 m617_615 := by
  exact edgeByCodes c617 c615 m617_615 512 768 (by decide) (by decide) (by decide) (by decide)
theorem floor617 : Floor c617 2 := by
  have up := refundEdge e617_615 floor615 262272 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c618 : Chart := ⟨[131136, 133120, 262272, 264192],[2240, 131200, 262208, 393216]⟩
def m618_617 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
theorem e618_617 : Edge c618 c617 m618_617 := by
  exact edgeByCodes c618 c617 m618_617 197121 50462976 (by decide) (by decide) (by decide) (by decide)
theorem floor618 : Floor c618 3 := by
  have up := refundEdge e618_617 floor617 131136 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c619 : Chart := ⟨[132096, 133120, 264192],[3072, 131072, 263168, 393216]⟩
def m619_615 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
theorem e619_615 : Edge c619 c615 m619_615 := by
  exact edgeByCodes c619 c615 m619_615 513 768 (by decide) (by decide) (by decide) (by decide)
theorem floor619 : Floor c619 2 := by
  have up := refundEdge e619_615 floor615 132096 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c620 : Chart := ⟨[132096, 133120, 262272, 264192],[3200, 131200, 262144, 263168, 393216]⟩
def m620_619 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
theorem e620_619 : Edge c620 c619 m620_619 := by
  exact edgeByCodes c620 c619 m620_619 196864 67305728 (by decide) (by decide) (by decide) (by decide)
theorem floor620 : Floor c620 3 := by
  have up := refundEdge e620_619 floor619 262272 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c621 : Chart := ⟨[133120, 264192, 266240],[6144, 135168, 262144, 393216]⟩
def m621_615 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
theorem e621_615 : Edge c621 c615 m621_615 := by
  exact edgeByCodes c621 c615 m621_615 256 768 (by decide) (by decide) (by decide) (by decide)
theorem floor621 : Floor c621 2 := by
  have up := refundEdge e621_615 floor615 266240 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c622 : Chart := ⟨[131073, 133120, 264192, 266240],[6145, 131072, 135168, 262145, 393216]⟩
def m622_621 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, none, none, some 17, some 18, none, none, none]
theorem e622_621 : Edge c622 c621 m622_621 := by
  exact edgeByCodes c622 c621 m622_621 197121 67305984 (by decide) (by decide) (by decide) (by decide)
theorem floor622 : Floor c622 3 := by
  have up := refundEdge e622_621 floor621 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c623 : Chart := ⟨[132096, 133120, 264192, 266240],[7168, 131072, 135168, 263168, 393216]⟩
def m623_621 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, none, none, some 17, some 18, none, none, none]
theorem e623_621 : Edge c623 c621 m623_621 := by
  exact edgeByCodes c623 c621 m623_621 197121 67305984 (by decide) (by decide) (by decide) (by decide)
theorem floor623 : Floor c623 3 := by
  have up := refundEdge e623_621 floor621 132096 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)


end TightRow.Protected.Numeric
