import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short436928
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8320, 8704, 33280, 34816, 131136, 133120, 262272, 264192]
def n : List Nat := [2240, 2624, 2688, 10240, 32960, 131712, 163968, 172032, 262720, 294976, 303104, 393728, 401408]
def pp := p.map (canonical 436928)
def nn := n.map (canonical 436928)
def parts : List Nat := [0, 64, 128, 512, 32768, 131072, 262144, 33280, 131136, 262272]
def g : ShortGrid := [(0,[(64,261340845540116251967642200860516390273793), (128,22562426331630036419873110007624581693637377), (512,44863511817719956587778577814388646997000961), (32768,89204341944359680671621871227059559798670081), (33280,8640463360), (131072,111505427430449600839527339034105104373777153), (131136,50528256), (262144,156107598402629441175338274647633234980504321), (262272,4345495808)]), (64,[(128,30199317760), (512,1412872441955072), (32768,1413971953386240), (33280,197120), (131072,1412893916529920), (262144,30065100032), (262272,196864)]), (128,[(512,1979120930259712), (32768,289171558171392), (33280,197120), (131072,289171558106368), (131136,196608), (262144,1979150994769664)]), (512,[(32768,848835878322944), (131072,21491876608), (131136,196608), (262144,34376778496), (262272,196864)]), (32768,[(131072,21542011648), (131136,196608), (262144,30131946240), (262272,196864)]), (33280,[(131072,197120), (131136,196608), (262144,197120), (262272,196864)]), (131072,[(262144,30148658432), (262272,196864)]), (131136,[(262144,196608), (262272,196608)])]
private theorem row0 : parts.all (shortPair g pp nn 426688 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 426688 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 426688 128) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 426688 512) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 426688 32768) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 426688 131072) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 426688 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 426688 33280) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 426688 131136) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 426688 262272) = true := by decide
theorem full : checkArms 436928 426688 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 128, 512, 32768, 131072, 262144, 33280, 131136, 262272] : List Nat).all (fun i => parts.all (shortPair g pp nn 426688 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short436928
theorem validBranch436928 : checkArms 436928 426688 [8256, 8320, 8704, 33280, 34816, 131136, 133120, 262272, 264192] [2240, 2624, 2688, 10240, 32960, 131712, 163968, 172032, 262720, 294976, 303104, 393728, 401408] = true := Short436928.full
end TightRow.Protected.Numeric
