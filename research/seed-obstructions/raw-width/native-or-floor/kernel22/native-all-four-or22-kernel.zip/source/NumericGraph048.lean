import NumericEdgeCodes
import NumericGraph048Code01
import Branch383872
import Branch384256
import Branch384384
import Branch384640
import Branch384768
import NumericGraph008
import NumericGraph009
import NumericGraph037
import NumericGraph041
import NumericGraph042
import NumericGraph044
import NumericGraph046
import NumericGraph047
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m584_583 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e584_583 : Edge c584 c583 m584_583 := by
  exact edgeByCodes c584 c583 m584_583 52131077189998945174017 1113232139568290777752079040768 (by decide) (by decide) (by decide) (by decide)
theorem floor584 : Floor c584 10 := by
  have up := refundEdge e584_583 floor583 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c585 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 66048, 262272],[640, 896, 57344, 65920, 90112, 98432, 262912, 279040, 303104, 336128, 376832]⟩
def m585_449 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
theorem e585_449 : Edge c585 c449 m585_449 := by
  exact edgeByCodes c585 c449 m585_449 1975839625445632 185045881735644250368 (by decide) (by decide) (by decide) (by decide)
theorem floor585 : Floor c585 7 := by
  have up := refundEdge e585_449 floor449 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c586 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 66048, 66560, 262272],[640, 1664, 33920, 57344, 90112, 98432, 263680, 279040, 304128, 335872, 376832]⟩
def m586_506 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e586_506 : Edge c586 c506 m586_506 := by
  exact edgeByCodes c586 c506 m586_506 1976943432040704 185117938230204104960 (by decide) (by decide) (by decide) (by decide)
theorem floor586 : Floor c586 7 := by
  have up := refundEdge e586_506 floor506 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c587 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 262272],[640, 896, 1664, 33920, 57344, 65920, 90112, 98432, 263936, 271616, 279040, 304128, 336128, 376832]⟩
def m587_111 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
theorem e587_111 : Edge c587 c111 m587_111 := by
  exact edgeByCodes c587 c111 m587_111 148080050112590643456 1032139818070026336719014986241 (by decide) (by decide) (by decide) (by decide)
theorem floor587 : Floor c587 9 := by
  have up := refundEdge e587_111 floor111 262272 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)


end TightRow.Protected.Numeric
