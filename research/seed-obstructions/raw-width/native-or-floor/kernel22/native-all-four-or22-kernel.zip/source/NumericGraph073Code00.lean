import NumericEdgeCodes
import Branch511616
import NumericGraph028
import NumericGraph046
import NumericGraph047
import NumericGraph048
import NumericGraph058
import NumericGraph065
import NumericGraph068
import NumericGraph069
import NumericGraph072
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c876 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 66560, 132096, 133120, 262272, 264192],[1152, 3200, 3328, 33920, 67968, 83968, 180224, 196992, 229504, 263424, 295936, 376832, 409600, 459008]⟩
def m876_697 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e876_697 : Edge c876 c697 m876_697 := by
  exact edgeByCodes c876 c697 m876_697 166599134354826461440 954774600872985428370300993796 (by decide) (by decide) (by decide) (by decide)
theorem floor876 : Floor c876 9 := by
  have up := refundEdge e876_697 floor697 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c877 : Chart := ⟨[17408, 33280, 34816, 66048, 66560, 132096, 133120, 264192],[1536, 3584, 18944, 83968, 180224, 229376, 263680, 295936, 376832, 410112, 458752]⟩
def m877_827 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e877_827 : Edge c877 c827 m877_827 := by
  exact edgeByCodes c877 c827 m877_827 1976943448883713 185118218605685833985 (by decide) (by decide) (by decide) (by decide)
theorem floor877 : Floor c877 7 := by
  have up := refundEdge e877_827 floor827 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c878 : Chart := ⟨[16512, 17408, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192],[3712, 18944, 33920, 67712, 83968, 131712, 180224, 229504, 263680, 295936, 376832, 410112, 458752]⟩
def m878_877 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e878_877 : Edge c878 c877 m878_877 := by
  exact edgeByCodes c878 c877 m878_877 650495289790235137 14559240984905721862750208 (by decide) (by decide) (by decide) (by decide)
def m878_874 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e878_874 : Edge c878 c874 m878_874 := by
  exact edgeByCodes c878 c874 m878_874 650777868590317824 14559240984623138767765504 (by decide) (by decide) (by decide) (by decide)
def m878_828 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e878_828 : Edge c878 c828 m878_828 := by
  exact edgeByCodes c878 c828 m878_828 650777868590383874 14559240984906825686254080 (by decide) (by decide) (by decide) (by decide)
def m878_786 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e878_786 : Edge c878 c786 m878_786 := by
  exact edgeByCodes c878 c786 m878_786 650777868590383360 14559240912564445218275584 (by decide) (by decide) (by decide) (by decide)
def m878_698 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e878_698 : Edge c878 c698 m878_698 := by
  exact edgeByCodes c878 c698 m878_698 650777868556697856 52131149529076566458624 (by decide) (by decide) (by decide) (by decide)
def m878_560 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e878_560 : Edge c878 c560 m878_560 := by
  exact edgeByCodes c878 c560 m878_560 650775660943507712 47390480418407880720640 (by decide) (by decide) (by decide) (by decide)
def m878_336 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
theorem e878_336 : Edge c878 c336 m878_336 := by
  exact edgeByCodes c878 c336 m878_336 506097522914230528 33168039896451421176064 (by decide) (by decide) (by decide) (by decide)
theorem floor878 : Floor c878 9 := by
  apply protectedBranch source c878.P c878.N (decode 508544) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 508544, q = 7 ∨ q = 9 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e878_877 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor877 k x net fit)
    · refine ⟨_,goodChild e878_874 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor874 k x net fit)
    · refine ⟨_,goodChild e878_828 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor828 k x net fit)
    · refine ⟨_,goodChild e878_786 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor786 k x net fit)
    · refine ⟨_,goodChild e878_698 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor698 k x net fit)
    · refine ⟨_,goodChild e878_560 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor560 k x net fit)
    · refine ⟨_,goodChild e878_336 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor336 k x net fit)
  · exact pairExcluded 511616 508544 [16512, 17408, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192] [3712, 18944, 33920, 67712, 83968, 131712, 180224, 229504, 263680, 295936, 376832, 410112, 458752] validBranch511616 (by decide) (by decide) (by decide)
def c879 : Chart := ⟨[1065088, 17408, 33280, 34816, 66048, 66560, 1179649, 132096, 133120, 1310848, 264192],[1050241, 1051265, 1052288, 1067521, 1082497, 1116289, 1132545, 1147009, 1179776, 1180288, 180224, 1278080, 1312257, 1327617, 1344513, 1425409, 410112, 458752]⟩
def m879_878 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, some 7, none]
theorem e879_878 : Edge c879 c878 m879_878 := by
  exact edgeByCodes c879 c878 m879_878 47390263961951766970624 1351848723122216626892654772994 (by decide) (by decide) (by decide) (by decide)
theorem floor879 : Floor c879 10 := by
  have up := refundEdge e879_878 floor878 1179649 1179776 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c880 : Chart := ⟨[16512, 17408, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[3712, 19008, 33984, 67776, 84032, 98496, 131200, 131712, 180224, 229504, 263744, 279104, 296000, 376896, 410112, 458752]⟩
def m880_878 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e880_878 : Edge c880 c878 m880_878 := by
  exact edgeByCodes c880 c878 m880_878 47390263961951766970624 1192771000740634898077382213888 (by decide) (by decide) (by decide) (by decide)
theorem floor880 : Floor c880 10 := by
  have up := refundEdge e880_878 floor878 131136 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c881 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120, 264192],[2304, 3328, 3584, 18944, 67840, 83968, 180224, 229376, 263936, 295936, 376832, 393984, 410112, 459008]⟩
def m881_337 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
theorem e881_337 : Edge c881 c337 m881_337 := by
  exact edgeByCodes c881 c337 m881_337 148080050112590643456 558627753154479503821840187656 (by decide) (by decide) (by decide) (by decide)
theorem floor881 : Floor c881 9 := by
  have up := refundEdge e881_337 floor337 264192 2304 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c882 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192],[3328, 3712, 18944, 33920, 67968, 83968, 131968, 180224, 196992, 229504, 263936, 295936, 376832, 393984, 410112, 459008]⟩
def m882_881 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e882_881 : Edge c882 c881 m882_881 := by
  exact edgeByCodes c882 c881 m882_881 52112630445925235622401 305349376194343419193451046043648 (by decide) (by decide) (by decide) (by decide)
theorem floor882 : Floor c882 10 := by
  have up := refundEdge e882_881 floor881 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c883 : Chart := ⟨[1065088, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 1179649, 132096, 133120, 1310848, 264192],[1049473, 1050241, 1051265, 3328, 1052288, 1067521, 1082497, 1116545, 1132545, 1147009, 1180032, 1180544, 180224, 1245568, 1278080, 1312513, 1327617, 1344513, 1376513, 1425409, 393984, 410112, 459008]⟩
def m883_882 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, some 7, none]
theorem e883_882 : Edge c883 c882 m883_882 := by
  exact edgeByCodes c883 c882 m883_882 3727165692063524628371472640 29352461300103986796577103890098750467 (by decide) (by decide) (by decide) (by decide)
theorem floor883 : Floor c883 11 := by
  have up := refundEdge e883_882 floor882 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c884 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632, 132096, 262272, 266240],[1664, 5376, 38016, 136064, 152064, 168064, 184320, 196992, 229504, 263936, 295936, 376832, 393984, 410112, 459008]⟩
def m884_571 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e884_571 : Edge c884 c571 m884_571 := by
  exact edgeByCodes c884 c571 m884_571 47390191622882752332032 875854728609966102434518467328 (by decide) (by decide) (by decide) (by decide)
theorem floor884 : Floor c884 10 := by
  have up := refundEdge e884_571 floor571 132096 1664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c885 : Chart := ⟨[1065088, 16640, 17408, 33024, 33280, 66048, 66560, 69632, 1179649, 132096, 1310848, 266240],[1049473, 1050241, 1053313, 5376, 1069569, 1086593, 1101825, 1114497, 1147009, 1180032, 1184640, 152064, 1216640, 184320, 1245568, 1278080, 1312513, 1327617, 1344513, 1376513, 1425409, 393984, 410112, 459008]⟩
def m885_884 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, some 17, some 18, none, some 7, none]
theorem e885_884 : Edge c885 c884 m885_884 := by
  exact edgeByCodes c885 c884 m885_884 13345574207383803674099968 119870710760530868513948171910841089 (by decide) (by decide) (by decide) (by decide)
theorem floor885 : Floor c885 11 := by
  have up := refundEdge e885_884 floor884 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c886 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 66048, 66560, 2166784, 2228288, 132096, 262272, 2363392],[1664, 2101696, 2102080, 2102592, 2118208, 2135232, 2150464, 2163136, 2195648, 2232448, 2233216, 2249216, 2265216, 2281472, 196992, 229504, 2361152, 2376256, 2393152, 2425152, 2474048, 393984, 410112, 459008]⟩
def m886_884 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e886_884 : Edge c886 c884 m886_884 := by
  exact edgeByCodes c886 c884 m886_884 13345574207383803674099968 119870710760530868513948171910841088 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
