import NumericGraph033
import NumericGraph051
import NumericGraph052
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c636 : Chart := ⟨[8256, 8320, 8704, 131136, 132096, 133120, 262272, 264192],[1216, 2240, 2624, 3712, 9216, 11264, 131712, 263744, 271360, 393728, 401408]⟩
def m636_634 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e636_634 : Edge c636 c634 m636_634 := by constructor <;> decide
theorem floor636 : Floor c636 7 := by
  have up := refundEdge e636_634 floor634 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c637 : Chart := ⟨[2105408, 8320, 2228288, 262272, 2363392],[2101440, 2232448, 2240512, 2359360, 401408]⟩
def m637_624 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, none, some 13, none, none, none, some 17, some 18, none, none, some 6]
private theorem e637_624 : Edge c637 c624 m637_624 := by constructor <;> decide
theorem floor637 : Floor c637 4 := by
  have up := refundEdge e637_624 floor624 2363392 2359360 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c638 : Chart := ⟨[2105408, 8320, 2228288, 132096, 262272, 2363392],[2102464, 2110464, 131200, 2232448, 2240512, 2360384, 271360, 401408]⟩
def m638_637 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, some 12, some 13, none, none, none, some 17, some 18, none, none, some 21]
private theorem e638_637 : Edge c638 c637 m638_637 := by constructor <;> decide
theorem floor638 : Floor c638 5 := by
  have up := refundEdge e638_637 floor637 132096 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c639 : Chart := ⟨[2105408, 2228288, 133120, 264192, 2363392],[2103360, 2111488, 2240512, 2359360, 401408]⟩
def m639_626 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, some 6]
private theorem e639_626 : Edge c639 c626 m639_626 := by constructor <;> decide
theorem floor639 : Floor c639 4 := by
  have up := refundEdge e639_626 floor626 2363392 2359360 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c640 : Chart := ⟨[8196, 2105408, 2228288, 133120, 264192, 2363392],[2103364, 8192, 2111488, 2232324, 2240512, 2359364, 393220, 401408]⟩
def m640_639 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, some 12, some 13, none, none, none, some 17, some 18, none, none, some 21]
private theorem e640_639 : Edge c640 c639 m640_639 := by constructor <;> decide
theorem floor640 : Floor c640 5 := by
  have up := refundEdge e640_639 floor639 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c641 : Chart := ⟨[2105408, 8320, 2228288, 133120, 262272, 264192, 2363392],[2099392, 2101440, 2103360, 2111488, 2232448, 2240512, 2359360, 401408]⟩
def m641_628 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, some 6]
private theorem e641_628 : Edge c641 c628 m641_628 := by constructor <;> decide
theorem floor641 : Floor c641 6 := by
  have up := refundEdge e641_628 floor628 2363392 2359360 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c642 : Chart := ⟨[8196, 2105408, 8320, 2228288, 133120, 262272, 264192, 2363392],[2180, 2099392, 2101440, 2103364, 8192, 2111488, 2232452, 2240512, 2359364, 393220, 401408]⟩
def m642_641 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, some 12, some 13, none, none, none, some 17, some 18, none, none, some 21]
private theorem e642_641 : Edge c642 c641 m642_641 := by constructor <;> decide
theorem floor642 : Floor c642 7 := by
  have up := refundEdge e642_641 floor641 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c643 : Chart := ⟨[8196, 2105408, 1056896, 1179649, 2228288, 133120, 1310848, 264192, 2363392],[1050757, 3147968, 3150017, 2103364, 3160065, 1179776, 3281028, 2240512, 3407941, 1318913, 393220, 401408]⟩
def m643_642 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, none, none, none, some 11, some 12, some 13, none, none, none, some 17, some 18, none, some 7, some 21]
private theorem e643_642 : Edge c643 c642 m643_642 := by constructor <;> decide
theorem floor643 : Floor c643 8 := by
  have up := refundEdge e643_642 floor642 1179649 1179776 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 8 ≤ 8).trans (up k x net fit)
def c644 : Chart := ⟨[2105408, 8704, 2228288, 133120, 264192, 2363392],[2103872, 8192, 2111488, 2232832, 2240512, 2359872, 393728, 401408]⟩
def m644_639 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, some 12, some 13, none, none, none, some 17, some 18, none, none, some 21]
private theorem e644_639 : Edge c644 c639 m644_639 := by constructor <;> decide
theorem floor644 : Floor c644 5 := by
  have up := refundEdge e644_639 floor639 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c645 : Chart := ⟨[16512, 17408, 132096, 262272],[1152, 131200, 263168, 409600]⟩
def m645_398 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e645_398 : Edge c645 c398 m645_398 := by constructor <;> decide
theorem floor645 : Floor c645 3 := by
  have up := refundEdge e645_398 floor398 132096 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c646 : Chart := ⟨[16512, 133120, 262272, 264192],[128, 2176, 18432, 131200, 409600]⟩
def m646_617 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
private theorem e646_617 : Edge c646 c617 m646_617 := by constructor <;> decide
theorem floor646 : Floor c646 3 := by
  have up := refundEdge e646_617 floor617 16512 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c647 : Chart := ⟨[16512, 16640, 133120, 262272, 264192],[2432, 18432, 131456, 393472, 409600]⟩
def m647_646 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e647_646 : Edge c647 c646 m647_646 := by constructor <;> decide
theorem floor647 : Floor c647 4 := by
  have up := refundEdge e647_646 floor646 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)

end TightRow.Protected.Numeric
