import NumericEdgeCodes
import Branch491200
import NumericGraph024
import NumericGraph025
import NumericGraph043
import NumericGraph056
import NumericGraph065
import NumericGraph066
import NumericGraph067
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c816 : Chart := ⟨[8320, 16512, 17408, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[128, 3200, 5248, 15360, 30720, 67712, 92160, 135296, 159744, 196736, 271360, 344064, 409600, 466944]⟩
def m816_791 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e816_791 : Edge c816 c791 m816_791 := by
  exact edgeByCodes c816 c791 m816_791 166599134359138271745 1033693278377572253517280903681 (by decide) (by decide) (by decide) (by decide)
theorem floor816 : Floor c816 9 := by
  have up := refundEdge e816_791 floor791 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c817 : Chart := ⟨[2105408, 8320, 16512, 17408, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3200, 2102464, 2110464, 2112512, 2119744, 2127872, 2164928, 2181184, 92160, 2232448, 2256896, 196736, 2360384, 271360, 2441280, 409600, 466944]⟩
def m817_816 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 12]
theorem e817_816 : Edge c817 c816 m817_816 := by
  exact edgeByCodes c817 c816 m817_816 52131149530167471440385 325711324654444995197268540850176 (by decide) (by decide) (by decide) (by decide)
theorem floor817 : Floor c817 10 := by
  have up := refundEdge e817_816 floor816 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c818 : Chart := ⟨[8320, 16512, 16640, 17408, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3200, 5248, 15616, 18432, 30720, 67968, 76032, 92160, 135552, 143616, 159744, 196992, 271616, 344064, 409600, 467200]⟩
def m818_816 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e818_816 : Edge c818 c816 m818_816 := by
  exact edgeByCodes c818 c816 m818_816 47390263963055590408448 305349376194343347135857008115712 (by decide) (by decide) (by decide) (by decide)
theorem floor818 : Floor c818 10 := by
  have up := refundEdge e818_816 floor816 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c819 : Chart := ⟨[8196, 8320, 16512, 16640, 17408, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3204, 3332, 5252, 7172, 9472, 15616, 22532, 30720, 67972, 76032, 83972, 92160, 135300, 135552, 143616, 151556, 159744, 196996, 263428, 271616, 344068, 409604, 459012, 467200]⟩
def m819_818 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e819_818 : Edge c819 c818 m819_818 := by
  exact edgeByCodes c819 c818 m819_818 13345574279723976512176641 30681689295890111595227905035562451456 (by decide) (by decide) (by decide) (by decide)
theorem floor819 : Floor c819 11 := by
  have up := refundEdge e819_818 floor818 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c820 : Chart := ⟨[2105408, 8320, 16512, 16640, 17408, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3200, 2101696, 2102464, 2102592, 2103616, 2110464, 2112768, 2119744, 2127872, 2165184, 76032, 2181184, 92160, 2232704, 2240768, 2256896, 196992, 2360640, 271616, 2425152, 2441280, 409600, 467200]⟩
def m820_818 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 12]
theorem e820_818 : Edge c820 c818 m820_818 := by
  exact edgeByCodes c820 c818 m820_818 14559240984904618056286721 29352461220566339272491140856676745728 (by decide) (by decide) (by decide) (by decide)
theorem floor820 : Floor c820 11 := by
  have up := refundEdge e820_818 floor818 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c821 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 5248, 9216, 15360, 23040, 30720, 67712, 92160, 135808, 152064, 159744, 196736, 263680, 271360, 344064, 410112, 466944]⟩
def m821_816 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e821_816 : Edge c821 c816 m821_816 := by
  exact edgeByCodes c821 c816 m821_816 52131149530171783184896 325711324654444922858199526211584 (by decide) (by decide) (by decide) (by decide)
theorem floor821 : Floor c821 10 := by
  have up := refundEdge e821_816 floor816 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c822 : Chart := ⟨[2105408, 8320, 8704, 16512, 17408, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2102464, 2112512, 2120256, 2127872, 2164928, 2181184, 92160, 2232960, 2249216, 2256896, 196736, 2360896, 271360, 2376256, 2441280, 410112, 466944]⟩
def m822_821 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 12]
theorem e822_821 : Edge c822 c821 m822_821 := by
  exact edgeByCodes c822 c821 m822_821 4037864368662109036501729793 5806146034666869819916753814594594668800 (by decide) (by decide) (by decide) (by decide)
def m822_817 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e822_817 : Edge c822 c817 m822_817 := by
  exact edgeByCodes c822 c817 m822_817 4037864368662391615285035264 5806146034666869815175868530057201975552 (by decide) (by decide) (by decide) (by decide)
def m822_813 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e822_813 : Edge c822 c813 m822_813 := by
  exact edgeByCodes c822 c813 m822_813 4036645961071642753741488384 22680258027456321424840685095391199488 (by decide) (by decide) (by decide) (by decide)
def m822_805 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, some 6]
theorem e822_805 : Edge c822 c805 m822_805 := by
  exact edgeByCodes c822 c805 m822_805 3727165692135582222409400576 5806146055028818284740696301277422944257 (by decide) (by decide) (by decide) (by decide)
def m822_796 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e822_796 : Edge c822 c796 m822_796 := by
  exact edgeByCodes c822 c796 m822_796 15772907690087467247272963 88594757918537570341799409215471872 (by decide) (by decide) (by decide) (by decide)
def m822_782 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e822_782 : Edge c822 c782 m822_782 := by
  exact edgeByCodes c822 c782 m822_782 4037864368662391615301746944 88594757609052578966915826810290432 (by decide) (by decide) (by decide) (by decide)
def m822_674 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, none, none, some 17, some 18, none, none, some 21]
theorem e822_674 : Edge c822 c674 m822_674 := by
  exact edgeByCodes c822 c674 m822_674 15772907690087454311842048 83422663931954147930398116880121861 (by decide) (by decide) (by decide) (by decide)
def m822_517 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, none, some 18, none, none, some 21]
theorem e822_517 : Edge c822 c517 m822_517 := by
  exact edgeByCodes c822 c517 m822_517 15772907473066948733042944 78230367073405097646014008372824064 (by decide) (by decide) (by decide) (by decide)
def m822_299 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, none, none, none, some 21]
theorem e822_299 : Edge c822 c299 m822_299 := by
  exact edgeByCodes c822 c299 m822_299 12131907574542231144628480 88492948177431784144909267925794828 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
