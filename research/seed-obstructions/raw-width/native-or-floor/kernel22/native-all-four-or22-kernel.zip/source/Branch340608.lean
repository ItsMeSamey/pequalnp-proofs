import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short340608
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 66048, 69632, 262272, 266240]
def n : List Nat := [4736, 12288, 65664, 262656, 335872]
def pp := p.map (canonical 340608)
def nn := n.map (canonical 340608)
def parts : List Nat := [0, 128, 512, 4096, 8192, 65536, 262144, 8320, 8704, 66048, 69632, 262272, 266240]
def g : ShortGrid := [(0,[(128,309489732259886631936327937), (512,79538861190790864407636279553), (4096,238307093840112706590972510721), (8192,1), (8320,256), (8704,0), (65536,158458742917061955551399903233), (66048,8590000384), (69632,8589935104), (262144,316917485834123911102799806465), (262272,17179934720), (266240,17180001024)]), (128,[(512,8623554560), (4096,12918521856), (8192,1099511627776), (8704,0), (65536,8590000128), (66048,8590000128), (69632,8590000128), (262144,17179934720), (266240,17179934720)]), (512,[(4096,21525233920), (8192,282574488338432), (8320,256), (65536,8590000384), (69632,8590000384), (262144,17179934976), (262272,65536), (266240,17179934976)]), (4096,[(8192,848822976643072), (8320,256), (8704,0), (65536,846623953388032), (66048,65792), (262144,17180001024), (262272,65536)]), (8192,[(65536,12901679104), (66048,4311744512), (69632,12901679104), (262144,21491613696), (262272,16777216), (266240,21491613696)]), (8320,[(65536,256), (66048,256), (69632,256), (262144,256), (266240,256)]), (8704,[(65536,0), (69632,0), (262144,0), (262272,0), (266240,0)]), (65536,[(262144,17213424128), (262272,65536), (266240,12918456832)]), (66048,[(262144,65792), (262272,65536), (266240,65792)]), (69632,[(262144,512), (262272,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 340608 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 340608 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 340608 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 340608 4096) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 340608 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 340608 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 340608 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 340608 8320) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 340608 8704) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 340608 66048) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 340608 69632) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 340608 262272) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 340608 266240) = true := by decide
theorem full : checkArms 340608 340608 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 512, 4096, 8192, 65536, 262144, 8320, 8704, 66048, 69632, 262272, 266240] : List Nat).all (fun i => parts.all (shortPair g pp nn 340608 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short340608
theorem validBranch340608 : checkArms 340608 340608 [8320, 8704, 66048, 69632, 262272, 266240] [4736, 12288, 65664, 262656, 335872] = true := Short340608.full
end TightRow.Protected.Numeric
