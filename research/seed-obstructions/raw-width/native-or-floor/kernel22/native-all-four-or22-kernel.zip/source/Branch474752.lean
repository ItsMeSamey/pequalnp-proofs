import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short474752
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240]
def n : List Nat := [3712, 5248, 6656, 15360, 67712, 75776, 135808, 143360, 196736, 263680, 271360, 393728, 466944]
def pp := p.map (canonical 474752)
def nn := n.map (canonical 474752)
def parts : List Nat := [0, 128, 512, 1024, 2048, 4096, 8192, 131072, 8320, 8704, 132096, 133120]
def g : ShortGrid := [(0,[(128,10282049269874637764604893470253591554254660698881), (512,1518614717260779061774658295748598798584589124353), (1024,7370419548810763729080876022004465335902079747073), (2048,11743573208291052795457343020020269811073605305857), (4096,13205097146707426185887493843133143365693988930561), (8192,1512905639376334809270147208159096052948246986753), (8320,256), (8704,0), (131072,7359001393041896034141647276125881336283080753153), (132096,12952273664), (133120,21474837760)]), (128,[(512,8657240064), (1024,12952207360), (2048,25870663680), (4096,17247174656), (8192,3298534883328), (8704,0), (131072,21475033088), (132096,21475033088), (133120,21475033088)]), (512,[(1024,21575696640), (2048,25870663936), (4096,38805897472), (8192,284773511593984), (8320,256), (131072,21475033344), (132096,21475033344), (133120,21475033344)]), (1024,[(2048,34511127808), (4096,38806095104), (8192,849922488270848), (8320,256), (8704,0), (131072,1413993428157696), (133120,21474837760)]), (2048,[(4096,17247372800), (8192,1696546441658368), (8320,256), (8704,0), (131072,1695446930031872), (132096,262912)]), (4096,[(8192,1131397464981504), (8320,256), (8704,0), (131072,1134695999866112), (132096,262912), (133120,1280)]), (8192,[(131072,21525168128), (132096,21525168128), (133120,21525168128)]), (8320,[(131072,256), (132096,256), (133120,256)]), (8704,[(131072,0), (132096,0), (133120,0)])]
private theorem row0 : parts.all (shortPair g pp nn 147072 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 147072 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 147072 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 147072 1024) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 147072 2048) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 147072 4096) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 147072 8192) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 147072 131072) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 147072 8320) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 147072 8704) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 147072 132096) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 147072 133120) = true := by decide
theorem full : checkArms 474752 147072 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 512, 1024, 2048, 4096, 8192, 131072, 8320, 8704, 132096, 133120] : List Nat).all (fun i => parts.all (shortPair g pp nn 147072 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short474752
theorem validBranch474752 : checkArms 474752 147072 [8320, 8704, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240] [3712, 5248, 6656, 15360, 67712, 75776, 135808, 143360, 196736, 263680, 271360, 393728, 466944] = true := Short474752.full
end TightRow.Protected.Numeric
