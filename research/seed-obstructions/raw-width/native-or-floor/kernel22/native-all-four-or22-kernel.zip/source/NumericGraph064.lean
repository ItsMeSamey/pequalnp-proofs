import NumericEdgeCodes
import NumericGraph064Code00
import Branch472256
import Branch473664
import NumericGraph023
import NumericGraph040
import NumericGraph053
import NumericGraph061
import NumericGraph062
import NumericGraph063
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m778_777 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e778_777 : Edge c778 c777 m778_777 := by
  exact edgeByCodes c778 c777 m778_777 578437695752307201 15768166804519247230861312 (by decide) (by decide) (by decide) (by decide)
theorem floor778 : Floor c778 8 := by
  have up := refundEdge e778_777 floor777 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 8 ≤ 8).trans (up k x net fit)
def c779 : Chart := ⟨[8320, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[128, 3200, 5248, 15360, 67712, 75776, 135296, 143360, 196736, 271360, 466944]⟩
def m779_750 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e779_750 : Edge c779 c750 m779_750 := by
  exact edgeByCodes c779 c750 m779_750 1976943448883713 185118501180157395457 (by decide) (by decide) (by decide) (by decide)
theorem floor779 : Floor c779 7 := by
  have up := refundEdge e779_750 floor750 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)


end TightRow.Protected.Numeric
