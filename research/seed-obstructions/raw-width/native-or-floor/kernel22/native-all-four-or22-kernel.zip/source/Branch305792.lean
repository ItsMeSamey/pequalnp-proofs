import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short305792
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 33280, 34816, 262272, 264192]
def n : List Nat := [2688, 10240, 32896, 262656, 303104]
def pp := p.map (canonical 305792)
def nn := n.map (canonical 305792)
def parts : List Nat := [0, 128, 512, 2048, 8192, 32768, 262144, 8320, 8704, 33280, 34816, 262272, 264192]
def g : ShortGrid := [(0,[(128,309489732259886631936327937), (512,79538861190790864407636279553), (2048,238307093840112706590972510721), (8192,1), (8320,256), (8704,0), (32768,158458742917061955551399903233), (33280,8590000384), (34816,8589935104), (262144,316917485834123911102799806465), (262272,17179934720), (264192,17180001024)]), (128,[(512,8623554560), (2048,12918521856), (8192,1099511627776), (8704,0), (32768,8590000128), (33280,8590000128), (34816,8590000128), (262144,17179934720), (264192,17179934720)]), (512,[(2048,21525233920), (8192,282574488338432), (8320,256), (32768,8590000384), (34816,8590000384), (262144,17179934976), (262272,65536), (264192,17179934976)]), (2048,[(8192,848822976643072), (8320,256), (8704,0), (32768,846623953388032), (33280,65792), (262144,17180001024), (262272,65536)]), (8192,[(32768,12901679104), (33280,4311744512), (34816,12901679104), (262144,21491613696), (262272,16777216), (264192,21491613696)]), (8320,[(32768,256), (33280,256), (34816,256), (262144,256), (264192,256)]), (8704,[(32768,0), (34816,0), (262144,0), (262272,0), (264192,0)]), (32768,[(262144,17213424128), (262272,65536), (264192,12918456832)]), (33280,[(262144,65792), (262272,65536), (264192,65792)]), (34816,[(262144,512), (262272,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 305792 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 305792 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 305792 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 305792 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 305792 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 305792 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 305792 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 305792 8320) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 305792 8704) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 305792 33280) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 305792 34816) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 305792 262272) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 305792 264192) = true := by decide
theorem full : checkArms 305792 305792 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 512, 2048, 8192, 32768, 262144, 8320, 8704, 33280, 34816, 262272, 264192] : List Nat).all (fun i => parts.all (shortPair g pp nn 305792 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short305792
theorem validBranch305792 : checkArms 305792 305792 [8320, 8704, 33280, 34816, 262272, 264192] [2688, 10240, 32896, 262656, 303104] = true := Short305792.full
end TightRow.Protected.Numeric
