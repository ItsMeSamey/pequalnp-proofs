import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short454272
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 16512, 17408, 33280, 34816, 132096, 133120, 262272, 264192]
def n : List Nat := [3712, 11264, 18944, 26624, 33920, 131712, 163968, 188416, 263680, 304128, 311296, 401408, 410112]
def pp := p.map (canonical 454272)
def nn := n.map (canonical 454272)
def parts : List Nat := [0, 512, 1024, 8192, 16384, 32768, 131072, 262144, 8704, 17408, 33280, 132096]
def g : ShortGrid := [(0,[(512,1467300179873281414837001084969138684844866536449), (1024,4396057134590498450647690361095849853004999427329), (8192,1), (8704,0), (16384,2923047876832778016247705476368179567442471813121), (17408,8589935104), (32768,5846095753665556032495410952736359134884943626241), (33280,17179934976), (131072,8769143630498334048743116429104538702327415439361), (132096,25769935616), (262144,11692191507331112064990821905472718269769887252481)]), (512,[(1024,12918522112), (8192,282574488338688), (16384,8590000384), (17408,8590000384), (32768,17179934976), (131072,25769869568), (132096,25769869568), (262144,34359804160)]), (1024,[(8192,847723465015552), (8704,0), (16384,846632543322880), (32768,17180001024), (33280,65792), (131072,25769935616), (262144,34359870208)]), (8192,[(16384,12901679360), (17408,12901679360), (32768,21491613952), (33280,4311744768), (131072,25786581248), (132096,25786581248), (262144,38671483136)]), (8704,[(16384,0), (17408,0), (32768,0), (131072,0), (132096,0), (262144,0)]), (16384,[(32768,17213424384), (33280,65792), (131072,30098326272), (132096,12918457088), (262144,38688260864)]), (17408,[(32768,512), (33280,65792), (131072,512), (262144,512)]), (32768,[(131072,25836913664), (132096,131840), (262144,34426848256)]), (33280,[(131072,65792), (132096,65792), (262144,65792)]), (131072,[(262144,34443625984)]), (132096,[(262144,131840)])]
private theorem row0 : parts.all (shortPair g pp nn 452096 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 452096 512) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 452096 1024) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 452096 8192) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 452096 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 452096 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 452096 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 452096 262144) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 452096 8704) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 452096 17408) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 452096 33280) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 452096 132096) = true := by decide
theorem full : checkArms 454272 452096 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 512, 1024, 8192, 16384, 32768, 131072, 262144, 8704, 17408, 33280, 132096] : List Nat).all (fun i => parts.all (shortPair g pp nn 452096 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short454272
theorem validBranch454272 : checkArms 454272 452096 [8320, 8704, 16512, 17408, 33280, 34816, 132096, 133120, 262272, 264192] [3712, 11264, 18944, 26624, 33920, 131712, 163968, 188416, 263680, 304128, 311296, 401408, 410112] = true := Short454272.full
end TightRow.Protected.Numeric
