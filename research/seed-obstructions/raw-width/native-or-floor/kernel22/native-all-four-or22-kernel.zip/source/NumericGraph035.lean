import NumericGraph033
import NumericGraph034
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c420 : Chart := ⟨[8196, 8320, 8704, 33280, 34816, 262272, 264192],[2180, 2564, 2688, 8192, 10240, 32900, 262660, 294916, 303104]⟩
def m420_419 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e420_419 : Edge c420 c419 m420_419 := by constructor <;> decide
theorem floor420 : Floor c420 6 := by
  have up := refundEdge e420_419 floor419 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c421 : Chart := ⟨[8256, 8320, 8704, 33280, 34816, 262272, 264192],[2240, 2624, 2688, 8192, 10240, 32960, 262720, 294976, 303104]⟩
def m421_419 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e421_419 : Edge c421 c419 m421_419 := by constructor <;> decide
theorem floor421 : Floor c421 6 := by
  have up := refundEdge e421_419 floor419 8256 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c422 : Chart := ⟨[8320, 8704, 33024, 33280, 34816, 262272, 264192],[896, 2432, 2688, 10496, 32896, 262912, 270592, 303104]⟩
def m422_419 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e422_419 : Edge c422 c419 m422_419 := by constructor <;> decide
theorem floor422 : Floor c422 6 := by
  have up := refundEdge e422_419 floor419 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c423 : Chart := ⟨[8196, 8320, 8704, 33024, 33280, 34816, 262272, 264192],[896, 2436, 2564, 2688, 8448, 10496, 32900, 262916, 270592, 294916, 303104]⟩
def m423_422 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e423_422 : Edge c423 c422 m423_422 := by constructor <;> decide
theorem floor423 : Floor c423 7 := by
  have up := refundEdge e423_422 floor422 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c424 : Chart := ⟨[8320, 8704, 33280, 262272, 266240],[4736, 36992, 45056, 262656, 303104]⟩
def m424_414 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e424_414 : Edge c424 c414 m424_414 := by constructor <;> decide
theorem floor424 : Floor c424 4 := by
  have up := refundEdge e424_414 floor414 266240 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c425 : Chart := ⟨[8320, 8704, 33024, 33280, 262272, 266240],[4992, 12544, 32896, 36992, 45056, 262912, 270592, 303104]⟩
def m425_424 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e425_424 : Edge c425 c424 m425_424 := by constructor <;> decide
theorem floor425 : Floor c425 5 := by
  have up := refundEdge e425_424 floor424 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c426 : Chart := ⟨[8704, 33280, 34816, 264192, 266240],[6656, 14336, 45056, 262656, 303104]⟩
def m426_418 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e426_418 : Edge c426 c418 m426_418 := by constructor <;> decide
theorem floor426 : Floor c426 4 := by
  have up := refundEdge e426_418 floor418 266240 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c427 : Chart := ⟨[8196, 8704, 33280, 34816, 264192, 266240],[6660, 8192, 14336, 36868, 45056, 262660, 294916, 303104]⟩
def m427_426 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e427_426 : Edge c427 c426 m427_426 := by constructor <;> decide
theorem floor427 : Floor c427 5 := by
  have up := refundEdge e427_426 floor426 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c428 : Chart := ⟨[8320, 8704, 33280, 34816, 262272, 264192, 266240],[2688, 4736, 6656, 14336, 36992, 45056, 262656, 303104]⟩
def m428_419 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e428_419 : Edge c428 c419 m428_419 := by constructor <;> decide
theorem floor428 : Floor c428 6 := by
  have up := refundEdge e428_419 floor419 266240 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c429 : Chart := ⟨[8196, 8320, 8704, 33280, 34816, 262272, 264192, 266240],[2180, 2688, 4736, 6660, 8192, 14336, 36996, 45056, 262660, 294916, 303104]⟩
def m429_428 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e429_428 : Edge c429 c428 m429_428 := by constructor <;> decide
theorem floor429 : Floor c429 7 := by
  have up := refundEdge e429_428 floor428 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c430 : Chart := ⟨[8320, 8704, 33024, 33280, 34816, 262272, 264192, 266240],[2432, 2688, 4992, 6656, 14592, 32896, 36992, 45056, 262912, 270592, 303104]⟩
def m430_428 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e430_428 : Edge c430 c428 m430_428 := by constructor <;> decide
theorem floor430 : Floor c430 7 := by
  have up := refundEdge e430_428 floor428 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c431 : Chart := ⟨[16512, 16640, 33024, 262272],[384, 32896, 262400, 311296]⟩
def m431_397 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e431_397 : Edge c431 c397 m431_397 := by constructor <;> decide
theorem floor431 : Floor c431 3 := by
  have up := refundEdge e431_397 floor397 33024 384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)

end TightRow.Protected.Numeric
