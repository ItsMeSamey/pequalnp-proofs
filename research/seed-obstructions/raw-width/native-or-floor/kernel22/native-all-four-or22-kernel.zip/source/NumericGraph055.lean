import NumericEdgeCodes
import Branch421056
import NumericGraph013
import NumericGraph052
import NumericGraph054
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c660 : Chart := ⟨[8256, 8320, 16512, 131136, 133120, 262272, 264192],[128, 2240, 18496, 26624, 131200, 155648, 278592, 401408, 409600]⟩
def m660_628 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e660_628 : Edge c660 c628 m660_628 := by
  exact edgeByCodes c660 c628 m660_628 6618611908864 30165697281 (by decide) (by decide) (by decide) (by decide)
theorem floor660 : Floor c660 6 := by
  have up := refundEdge e660_628 floor628 16512 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c661 : Chart := ⟨[8256, 8320, 16512, 16640, 131136, 133120, 262272, 264192],[2496, 10496, 18432, 18496, 26624, 131456, 155648, 262464, 278592, 401664, 409600]⟩
def m661_660 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e661_660 : Edge c661 c660 m661_660 := by
  exact edgeByCodes c661 c660 m661_660 1976943448817920 185118217501862461440 (by decide) (by decide) (by decide) (by decide)
theorem floor661 : Floor c661 7 := by
  have up := refundEdge e661_660 floor660 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c662 : Chart := ⟨[8320, 16512, 17408, 132096, 133120, 262272, 264192],[128, 3200, 11264, 26624, 131200, 155648, 271360, 401408, 409600]⟩
def m662_650 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
theorem e662_650 : Edge c662 c650 m662_650 := by
  exact edgeByCodes c662 c650 m662_650 6618611909121 34460664577 (by decide) (by decide) (by decide) (by decide)
theorem floor662 : Floor c662 6 := by
  have up := refundEdge e662_650 floor650 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c663 : Chart := ⟨[8256, 8320, 16512, 17408, 131136, 132096, 133120, 262272, 264192],[1216, 2240, 3200, 11264, 18496, 26624, 131200, 155648, 263232, 271360, 278592, 401408, 409600]⟩
def m663_662 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e663_662 : Edge c663 c662 m663_662 := by
  exact edgeByCodes c663 c662 m663_662 2259522248966657 222156103416157504000 (by decide) (by decide) (by decide) (by decide)
def m663_660 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e663_660 : Edge c663 c660 m663_660 := by
  exact edgeByCodes c663 c660 m663_660 2259522232123648 222156384891134279936 (by decide) (by decide) (by decide) (by decide)
def m663_659 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e663_659 : Edge c663 c659 m663_659 := by
  exact edgeByCodes c663 c659 m663_659 1975839625445632 222156387098781155328 (by decide) (by decide) (by decide) (by decide)
def m663_651 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
theorem e663_651 : Edge c663 c651 m663_651 := by
  exact edgeByCodes c663 c651 m663_651 2259522249032450 867514700152307968 (by decide) (by decide) (by decide) (by decide)
def m663_634 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e663_634 : Edge c663 c634 m663_634 := by
  exact edgeByCodes c663 c634 m663_634 2259522249031936 795175631120892160 (by decide) (by decide) (by decide) (by decide)
def m663_160 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
theorem e663_160 : Edge c663 c160 m663_160 := by
  exact edgeByCodes c663 c160 m663_160 1694364648734976 506097522914230528 (by decide) (by decide) (by decide) (by decide)
theorem floor663 : Floor c663 8 := by
  apply protectedBranch source c663.P c663.N (decode 289856) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 289856, q = 6 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e663_662 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor662 k x net fit)
    · refine ⟨_,goodChild e663_660 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor660 k x net fit)
    · refine ⟨_,goodChild e663_659 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor659 k x net fit)
    · refine ⟨_,goodChild e663_651 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor651 k x net fit)
    · refine ⟨_,goodChild e663_634 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor634 k x net fit)
    · refine ⟨_,goodChild e663_160 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor160 k x net fit)
  · exact pairExcluded 421056 289856 [8256, 8320, 16512, 17408, 131136, 132096, 133120, 262272, 264192] [1216, 2240, 3200, 11264, 18496, 26624, 131200, 155648, 263232, 271360, 278592, 401408, 409600] validBranch421056 (by decide) (by decide) (by decide)
def c664 : Chart := ⟨[8196, 8256, 8320, 16512, 17408, 131136, 132096, 133120, 262272, 264192],[1216, 2240, 3204, 9216, 11264, 18500, 26624, 131204, 155648, 263236, 271360, 278596, 401408, 409604]⟩
def m664_663 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e664_663 : Edge c664 c663 m664_663 := by
  exact edgeByCodes c664 c663 m664_663 166599134359138271745 1033693278377572253517280837888 (by decide) (by decide) (by decide) (by decide)
theorem floor664 : Floor c664 9 := by
  have up := refundEdge e664_663 floor663 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c665 : Chart := ⟨[8256, 8320, 16512, 16640, 17408, 131136, 132096, 133120, 262272, 264192],[1216, 2496, 3200, 11520, 18432, 18496, 26624, 131456, 155648, 263488, 271616, 278592, 401664, 409600]⟩
def m665_663 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e665_663 : Edge c665 c663 m665_663 := by
  exact edgeByCodes c665 c663 m665_663 166599134359138205952 1033693278377572253517264060672 (by decide) (by decide) (by decide) (by decide)
theorem floor665 : Floor c665 9 := by
  have up := refundEdge e665_663 floor663 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c666 : Chart := ⟨[8320, 8704, 16512, 17408, 132096, 133120, 262272, 264192],[3712, 9216, 11264, 18944, 26624, 131712, 155648, 263680, 271360, 401408, 410112]⟩
def m666_662 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e666_662 : Edge c666 c662 m666_662 := by
  exact edgeByCodes c666 c662 m666_662 1976943448883712 185118217501862395904 (by decide) (by decide) (by decide) (by decide)
theorem floor666 : Floor c666 7 := by
  have up := refundEdge e666_662 floor662 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c667 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 131136, 132096, 133120, 262272, 264192],[1216, 2240, 3712, 9216, 11264, 19008, 26624, 131712, 155648, 263744, 271360, 279104, 401408, 410112]⟩
def m667_663 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e667_663 : Edge c667 c663 m667_663 := by
  exact edgeByCodes c667 c663 m667_663 166599134359138271488 1033693278377572253517280837888 (by decide) (by decide) (by decide) (by decide)
theorem floor667 : Floor c667 9 := by
  have up := refundEdge e667_663 floor663 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c668 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 131136, 132096, 133120, 262272, 264192],[1216, 2496, 3712, 11520, 18944, 19008, 26624, 131968, 155648, 264000, 271616, 279104, 393984, 401664, 410112]⟩
def m668_667 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e668_667 : Edge c668 c667 m668_667 := by
  exact edgeByCodes c668 c667 m668_667 47390263963055573565696 284987117030824431661960411611392 (by decide) (by decide) (by decide) (by decide)
theorem floor668 : Floor c668 10 := by
  have up := refundEdge e668_667 floor667 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c669 : Chart := ⟨[2105408, 8320, 16512, 17408, 2228288, 132096, 262272, 2363392],[2102464, 2110464, 2117696, 2232448, 2256896, 2359360, 2360384, 271360, 2375744, 401408, 409600]⟩
def m669_659 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, some 18, none, none, some 6]
theorem e669_659 : Edge c669 c659 m669_659 := by
  exact edgeByCodes c669 c659 m669_659 1694364648734976 185118218605669056512 (by decide) (by decide) (by decide) (by decide)
theorem floor669 : Floor c669 7 := by
  have up := refundEdge e669_659 floor659 2363392 2359360 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c670 : Chart := ⟨[2105408, 8320, 16512, 17408, 2228288, 132096, 133120, 262272, 264192, 2363392],[2099392, 3200, 2102464, 2112512, 2119744, 2127872, 2232448, 2256896, 2359360, 2360384, 271360, 2375744, 401408, 409600]⟩
def m670_663 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, some 6]
theorem e670_663 : Edge c670 c663 m670_663 := by
  exact edgeByCodes c670 c663 m670_663 148080050112590643456 1033693278377499913344442761218 (by decide) (by decide) (by decide) (by decide)
theorem floor670 : Floor c670 9 := by
  have up := refundEdge e670_663 floor663 2363392 2359360 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c671 : Chart := ⟨[2105408, 8320, 16512, 16640, 17408, 2228288, 132096, 133120, 262272, 264192, 2363392],[2099648, 3200, 2101696, 2102464, 2102592, 2103616, 2112768, 18432, 2119744, 2127872, 2232704, 2240768, 2256896, 2360640, 271616, 2375744, 401664, 409600]⟩
def m671_670 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, some 12, some 13, some 14, none, none, some 17, some 18, none, none, some 21]
theorem e671_670 : Edge c671 c670 m671_670 := by
  exact edgeByCodes c671 c670 m671_670 47390263963055590342912 346073273124046860855511192109312 (by decide) (by decide) (by decide) (by decide)
theorem floor671 : Floor c671 10 := by
  have up := refundEdge e671_670 floor670 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)


end TightRow.Protected.Numeric
