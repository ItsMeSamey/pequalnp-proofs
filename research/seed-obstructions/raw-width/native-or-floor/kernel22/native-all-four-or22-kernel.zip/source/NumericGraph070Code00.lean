import NumericEdgeCodes
import Branch503424
import NumericGraph026
import NumericGraph027
import NumericGraph044
import NumericGraph056
import NumericGraph063
import NumericGraph068
import NumericGraph069
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c840 : Chart := ⟨[8256, 8704, 33280, 34816, 66048, 131136, 133120, 264192],[512, 2624, 67648, 75776, 172032, 229376, 262720, 303104, 360512, 393728, 466944]⟩
def m840_678 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e840_678 : Edge c840 c678 m840_678 := by
  exact edgeByCodes c840 c678 m840_678 1976943432040704 185117938230203973889 (by decide) (by decide) (by decide) (by decide)
theorem floor840 : Floor c840 7 := by
  have up := refundEdge e840_678 floor678 66048 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c841 : Chart := ⟨[8320, 8704, 33280, 34816, 66048, 133120, 262272, 264192],[640, 2688, 67712, 75776, 131712, 172032, 229504, 303104, 360448, 393728, 466944]⟩
def m841_679 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e841_679 : Edge c841 c679 m841_679 := by
  exact edgeByCodes c841 c679 m841_679 1976943432040704 185117934931669090561 (by decide) (by decide) (by decide) (by decide)
theorem floor841 : Floor c841 7 := by
  have up := refundEdge e841_679 floor679 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c842 : Chart := ⟨[8256, 8320, 8704, 33280, 34816, 66048, 131136, 133120, 262272, 264192],[640, 2624, 2688, 67776, 75776, 98496, 131712, 172032, 229504, 262720, 303104, 360512, 393728, 466944]⟩
def m842_680 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e842_680 : Edge c842 c680 m842_680 := by
  exact edgeByCodes c842 c680 m842_680 166599134354826461440 1033692074174047345638690128131 (by decide) (by decide) (by decide) (by decide)
theorem floor842 : Floor c842 9 := by
  have up := refundEdge e842_680 floor680 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c843 : Chart := ⟨[8704, 33280, 34816, 66048, 66560, 132096, 133120, 264192],[512, 3584, 11264, 75776, 172032, 229376, 263680, 304128, 360448, 393728, 466944]⟩
def m843_827 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e843_827 : Edge c843 c827 m843_827 := by
  exact edgeByCodes c843 c827 m843_827 1976943448883713 185118218605685833985 (by decide) (by decide) (by decide) (by decide)
theorem floor843 : Floor c843 7 := by
  have up := refundEdge e843_827 floor827 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c844 : Chart := ⟨[8256, 8704, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 264192],[2048, 2624, 3584, 11264, 67648, 75776, 172032, 229376, 263744, 296000, 304128, 360512, 393728, 466944]⟩
def m844_323 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
theorem e844_323 : Edge c844 c323 m844_323 := by
  exact edgeByCodes c844 c323 m844_323 148080050112590643456 558627753154118940973743603976 (by decide) (by decide) (by decide) (by decide)
theorem floor844 : Floor c844 9 := by
  have up := refundEdge e844_323 floor323 264192 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c845 : Chart := ⟨[8320, 8704, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192],[3712, 11264, 33920, 67712, 75776, 131712, 172032, 229504, 263680, 304128, 360448, 393728, 466944]⟩
def m845_843 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e845_843 : Edge c845 c843 m845_843 := by
  exact edgeByCodes c845 c843 m845_843 650495289790235137 14559240984905721862750208 (by decide) (by decide) (by decide) (by decide)
def m845_841 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e845_841 : Edge c845 c841 m845_841 := by
  exact edgeByCodes c845 c841 m845_841 650777859966763264 14559240984623143079575552 (by decide) (by decide) (by decide) (by decide)
def m845_828 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e845_828 : Edge c845 c828 m845_828 := by
  exact edgeByCodes c845 c828 m845_828 650777868590383874 14559240984906825686254080 (by decide) (by decide) (by decide) (by decide)
def m845_763 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e845_763 : Edge c845 c763 m845_763 := by
  exact edgeByCodes c845 c763 m845_763 650777868590383360 56871962757110826205440 (by decide) (by decide) (by decide) (by decide)
def m845_683 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e845_683 : Edge c845 c683 m845_683 := by
  exact edgeByCodes c845 c683 m845_683 650777868556697856 14559222465541099883725056 (by decide) (by decide) (by decide) (by decide)
def m845_539 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e845_539 : Edge c845 c539 m845_539 := by
  exact edgeByCodes c845 c539 m845_539 650775660943507712 12146093193072878997864704 (by decide) (by decide) (by decide) (by decide)
def m845_325 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
theorem e845_325 : Edge c845 c325 m845_325 := by
  exact edgeByCodes c845 c325 m845_325 506097522914230528 8519260176978489542508800 (by decide) (by decide) (by decide) (by decide)
theorem floor845 : Floor c845 9 := by
  apply protectedBranch source c845.P c845.N (decode 500864) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 500864, q = 7 ∨ q = 10 ∨ q = 13 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e845_843 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor843 k x net fit)
    · refine ⟨_,goodChild e845_841 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor841 k x net fit)
    · refine ⟨_,goodChild e845_828 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor828 k x net fit)
    · refine ⟨_,goodChild e845_763 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor763 k x net fit)
    · refine ⟨_,goodChild e845_683 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor683 k x net fit)
    · refine ⟨_,goodChild e845_539 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor539 k x net fit)
    · refine ⟨_,goodChild e845_325 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor325 k x net fit)
  · exact pairExcluded 503424 500864 [8320, 8704, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192] [3712, 11264, 33920, 67712, 75776, 131712, 172032, 229504, 263680, 304128, 360448, 393728, 466944] validBranch503424 (by decide) (by decide) (by decide)
def c846 : Chart := ⟨[8196, 8320, 8704, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192],[3204, 3588, 3712, 9216, 11264, 33924, 67716, 75776, 131712, 172032, 229508, 263684, 295940, 304128, 360452, 393732, 458756, 466944]⟩
def m846_845 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e846_845 : Edge c846 c845 m846_845 := by
  exact edgeByCodes c846 c845 m846_845 47390263963055590408705 1351538024445690100087186064386 (by decide) (by decide) (by decide) (by decide)
theorem floor846 : Floor c846 10 := by
  have up := refundEdge e846_845 floor845 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c847 : Chart := ⟨[8256, 8320, 8704, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[2624, 3712, 9216, 11264, 33984, 67776, 75776, 98496, 131712, 172032, 229504, 263744, 296000, 304128, 360512, 393728, 466944]⟩
def m847_845 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e847_845 : Edge c847 c845 m847_845 := by
  exact edgeByCodes c847 c845 m847_845 52131149529067959812609 1272309861931425762489330303745 (by decide) (by decide) (by decide) (by decide)
theorem floor847 : Floor c847 10 := by
  have up := refundEdge e847_845 floor845 8256 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c848 : Chart := ⟨[8320, 8704, 33024, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192],[3712, 11520, 33920, 67968, 76032, 131968, 172032, 196992, 229504, 263936, 271616, 304128, 360448, 393984, 467200]⟩
def m848_845 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e848_845 : Edge c848 c845 m848_845 := by
  exact edgeByCodes c848 c845 m848_845 47390263963055590408448 1113232139549843751099569406208 (by decide) (by decide) (by decide) (by decide)
theorem floor848 : Floor c848 10 := by
  have up := refundEdge e848_845 floor845 33024 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c849 : Chart := ⟨[8256, 8320, 8704, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[2624, 3712, 9472, 11520, 33984, 68032, 76032, 98496, 131968, 172032, 196992, 229504, 264000, 271616, 296000, 304128, 328000, 360512, 393984, 467200]⟩
def m849_848 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e849_848 : Edge c849 c848 m849_848 := by
  exact edgeByCodes c849 c848 m849_848 14559240984623143079576065 99020075221838252513713064832664321 (by decide) (by decide) (by decide) (by decide)
theorem floor849 : Floor c849 11 := by
  have up := refundEdge e849_848 floor848 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c850 : Chart := ⟨[8196, 8256, 8320, 8704, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[2624, 3204, 3332, 3588, 3712, 9472, 11520, 33924, 33984, 67908, 67972, 68032, 76032, 98496, 131968, 172032, 196996, 229508, 263492, 263940, 264000, 271616, 296004, 304128, 328004, 360516, 393988, 459012, 467200]⟩
def m850_849 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e850_849 : Edge c850 c849 m850_849 := by
  exact edgeByCodes c850 c849 m850_849 1033693278377572253517280903681 160433746962841304943283663301659841284891018240 (by decide) (by decide) (by decide) (by decide)
theorem floor850 : Floor c850 12 := by
  have up := refundEdge e850_849 floor849 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 12 ≤ 12).trans (up k x net fit)
def c851 : Chart := ⟨[8704, 33280, 34816, 66048, 69632, 133120, 264192, 266240],[512, 6656, 14336, 75776, 135680, 176128, 229376, 303104, 360448, 393728, 466944]⟩

end TightRow.Protected.Numeric
