import NumericEdgeCodes
import Branch381824
import Branch382848
import NumericGraph008
import NumericGraph036
import NumericGraph037
import NumericGraph041
import NumericGraph043
import NumericGraph044
import NumericGraph045
import NumericGraph046
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c564 : Chart := ⟨[16512, 33280, 66048, 69632, 262272, 266240],[640, 4736, 20992, 36992, 53248, 98432, 279040, 376832]⟩
def m564_524 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e564_524 : Edge c564 c524 m564_524 := by
  exact edgeByCodes c564 c524 m564_524 21542142465 30165762817 (by decide) (by decide) (by decide) (by decide)
theorem floor564 : Floor c564 5 := by
  have up := refundEdge e564_524 floor524 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c565 : Chart := ⟨[16640, 33024, 33280, 66048, 69632, 266240],[768, 4864, 20992, 53248, 262912, 279040, 327936, 376832]⟩
def m565_525 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e565_525 : Edge c565 c525 m565_525 := by
  exact edgeByCodes c565 c525 m565_525 21542142465 7722418504449 (by decide) (by decide) (by decide) (by decide)
theorem floor565 : Floor c565 5 := by
  have up := refundEdge e565_525 floor525 16640 768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c566 : Chart := ⟨[16512, 16640, 33024, 33280, 66048, 69632, 262272, 266240],[4992, 20992, 36992, 53248, 65920, 98432, 262912, 279040, 327936, 376832]⟩
def m566_565 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e566_565 : Edge c566 c565 m566_565 := by
  exact edgeByCodes c566 c565 m566_565 7718123536897 650777868556632064 (by decide) (by decide) (by decide) (by decide)
def m566_564 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e566_564 : Edge c566 c564 m566_564 := by
  exact edgeByCodes c566 c564 m566_564 7722435347200 650494181654986752 (by decide) (by decide) (by decide) (by decide)
def m566_563 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e566_563 : Edge c566 c563 m566_563 := by
  exact edgeByCodes c566 c563 m566_563 7722435215616 650775660943507456 (by decide) (by decide) (by decide) (by decide)
def m566_551 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e566_551 : Edge c566 c551 m566_551 := by
  exact edgeByCodes c566 c551 m566_551 6614300098816 650777868590383104 (by decide) (by decide) (by decide) (by decide)
def m566_526 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e566_526 : Edge c566 c526 m566_526 := by
  exact edgeByCodes c566 c526 m566_526 7722435347202 2542096737370624 (by decide) (by decide) (by decide) (by decide)
def m566_494 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e566_494 : Edge c566 c494 m566_494 := by
  exact edgeByCodes c566 c494 m566_494 7722435346688 650777868573409536 (by decide) (by decide) (by decide) (by decide)
def m566_443 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e566_443 : Edge c566 c443 m566_443 := by
  exact edgeByCodes c566 c443 m566_443 7722401661184 650495281166680320 (by decide) (by decide) (by decide) (by decide)
def m566_100 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, none, some 14, some 15, some 16, none, none, none, none, none]
theorem e566_100 : Edge c566 c100 m566_100 := by
  exact edgeByCodes c566 c100 m566_100 5514788471040 649930132189937920 (by decide) (by decide) (by decide) (by decide)
theorem floor566 : Floor c566 7 := by
  apply protectedBranch source c566.P c566.N (decode 381824) 7
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 381824, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 12 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e566_565 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor565 k x net fit)
    · refine ⟨_,goodChild e566_564 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor564 k x net fit)
    · refine ⟨_,goodChild e566_563 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor563 k x net fit)
    · refine ⟨_,goodChild e566_551 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor551 k x net fit)
    · refine ⟨_,goodChild e566_526 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor526 k x net fit)
    · refine ⟨_,goodChild e566_494 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor494 k x net fit)
    · refine ⟨_,goodChild e566_443 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor443 k x net fit)
    · refine ⟨_,goodChild e566_100 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor100 k x net fit)
  · exact pairExcluded 381824 381824 [16512, 16640, 33024, 33280, 66048, 69632, 262272, 266240] [4992, 20992, 36992, 53248, 65920, 98432, 262912, 279040, 327936, 376832] validBranch381824 (by decide) (by decide) (by decide)
def c567 : Chart := ⟨[16640, 17408, 33024, 66560, 69632, 266240],[256, 5376, 37888, 53248, 263424, 295936, 327936, 376832]⟩
def m567_497 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e567_497 : Edge c567 c497 m567_497 := by
  exact edgeByCodes c567 c497 m567_497 21542142208 7722418504449 (by decide) (by decide) (by decide) (by decide)
theorem floor567 : Floor c567 5 := by
  have up := refundEdge e567_497 floor497 33024 256 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c568 : Chart := ⟨[16512, 16640, 17408, 33024, 66560, 69632, 262272, 266240],[384, 4480, 5376, 38016, 53248, 65920, 98432, 263424, 295936, 327936, 376832]⟩
def m568_498 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e568_498 : Edge c568 c498 m568_498 := by
  exact edgeByCodes c568 c498 m568_498 1976943448817920 185117934923079090945 (by decide) (by decide) (by decide) (by decide)
theorem floor568 : Floor c568 7 := by
  have up := refundEdge e568_498 floor498 33024 384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c569 : Chart := ⟨[16512, 17408, 33280, 66048, 66560, 69632, 262272, 266240],[640, 1664, 4736, 20992, 38016, 53248, 98432, 263680, 279040, 295936, 376832]⟩
def m569_499 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e569_499 : Edge c569 c499 m569_499 := by
  exact edgeByCodes c569 c499 m569_499 1976943448883456 722835462594757121 (by decide) (by decide) (by decide) (by decide)
theorem floor569 : Floor c569 7 := by
  have up := refundEdge e569_499 floor499 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c570 : Chart := ⟨[16640, 17408, 33024, 33280, 66048, 66560, 69632, 266240],[4352, 4864, 5376, 20992, 37888, 53248, 263936, 279040, 295936, 327936, 376832]⟩
def m570_102 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, none, none, none, none, none]
theorem e570_102 : Edge c570 c102 m570_102 := by
  exact edgeByCodes c570 c102 m570_102 1694364648734976 723114729958146310 (by decide) (by decide) (by decide) (by decide)
theorem floor570 : Floor c570 7 := by
  have up := refundEdge e570_102 floor102 266240 4352 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c571 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632, 262272, 266240],[1664, 4992, 5376, 20992, 38016, 53248, 65920, 98432, 263936, 279040, 295936, 327936, 376832]⟩
def m571_570 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e571_570 : Edge c571 c570 m571_570 := by
  exact edgeByCodes c571 c570 m571_570 650495289790235137 14559240984903514232848641 (by decide) (by decide) (by decide) (by decide)
def m571_569 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e571_569 : Edge c571 c569 m571_569 := by
  exact edgeByCodes c571 c569 m571_569 650777868590383616 14554500099337501863378944 (by decide) (by decide) (by decide) (by decide)
def m571_568 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e571_568 : Edge c571 c568 m571_568 := by
  exact edgeByCodes c571 c568 m571_568 650777868556697856 14559240912565549041582337 (by decide) (by decide) (by decide) (by decide)
def m571_566 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e571_566 : Edge c571 c566 m571_566 := by
  exact edgeByCodes c571 c566 m571_566 650777864278573312 56871962757115138016001 (by decide) (by decide) (by decide) (by decide)
def m571_553 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e571_553 : Edge c571 c553 m571_553 := by
  exact edgeByCodes c571 c553 m571_553 578155116952158464 14559240984905721862684928 (by decide) (by decide) (by decide) (by decide)
def m571_500 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e571_500 : Edge c571 c500 m571_500 := by
  exact edgeByCodes c571 c500 m571_500 650777868590252288 14559222465536693197078784 (by decide) (by decide) (by decide) (by decide)
def m571_103 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, none, none, none, none, none]
theorem e571_103 : Edge c571 c103 m571_103 := by
  exact edgeByCodes c571 c103 m571_103 506097522914230528 14540277442637261420169216 (by decide) (by decide) (by decide) (by decide)
theorem floor571 : Floor c571 9 := by
  apply protectedBranch source c571.P c571.N (decode 300928) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 300928, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 12 ∨ q = 15 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e571_570 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor570 k x net fit)
    · refine ⟨_,goodChild e571_569 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor569 k x net fit)
    · refine ⟨_,goodChild e571_568 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor568 k x net fit)
    · refine ⟨_,goodChild e571_566 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor566 k x net fit)
    · refine ⟨_,goodChild e571_553 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor553 k x net fit)
    · refine ⟨_,goodChild e571_500 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor500 k x net fit)
    · refine ⟨_,goodChild e571_103 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor103 k x net fit)
  · exact pairExcluded 382848 300928 [16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632, 262272, 266240] [1664, 4992, 5376, 20992, 38016, 53248, 65920, 98432, 263936, 279040, 295936, 327936, 376832] validBranch382848 (by decide) (by decide) (by decide)
def c572 : Chart := ⟨[16640, 33024, 34816, 69632, 264192, 266240],[256, 6400, 22528, 53248, 67840, 83968, 327936, 376832]⟩
def m572_528 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e572_528 : Edge c572 c528 m572_528 := by
  exact edgeByCodes c572 c528 m572_528 21542142465 7722418504449 (by decide) (by decide) (by decide) (by decide)
theorem floor572 : Floor c572 5 := by
  have up := refundEdge e572_528 floor528 16640 256 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c573 : Chart := ⟨[16512, 16640, 33024, 34816, 69632, 262272, 264192, 266240],[4352, 4480, 6400, 22528, 36992, 53248, 67968, 83968, 98432, 327936, 376832]⟩

end TightRow.Protected.Numeric
