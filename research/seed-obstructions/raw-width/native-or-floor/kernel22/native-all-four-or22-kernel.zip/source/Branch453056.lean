import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short453056
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8320, 16512, 16640, 33024, 34816, 131136, 133120, 262272, 264192]
def n : List Nat := [2496, 10496, 18496, 26624, 32960, 131456, 163968, 188416, 262464, 303104, 311360, 401664, 409600]
def pp := p.map (canonical 453056)
def nn := n.map (canonical 453056)
def parts : List Nat := [0, 64, 256, 8192, 16384, 32768, 131072, 262144, 8256, 16640, 33024, 131136]
def g : ShortGrid := [(0,[(64,5843230804773930342819600563767194291089178881), (256,4396012445987815457641160643035404489704188609025), (8192,1), (8256,256), (16384,2923047876832778016247705476368179567442471813121), (16640,8589935104), (32768,5846095753665556032495410952736359134884943626241), (33024,17180001024), (131072,8769143630498334048743116429104538702327415439361), (131136,25769869312), (262144,11692191507331112064990821905472718269769887252481)]), (64,[(256,12918521856), (8192,1099511627776), (16384,8590000128), (16640,8590000128), (32768,17179934720), (33024,17179934720), (131072,25769869312), (262144,34359803904)]), (256,[(8192,847723465015296), (8256,256), (16384,846632543322880), (32768,17180001024), (131072,25769935616), (131136,65536), (262144,34359870208)]), (8192,[(16384,12901679104), (16640,12901679104), (32768,17196646400), (33024,17196646400), (131072,30081548288), (131136,16777216), (262144,38671482880)]), (8256,[(16384,256), (16640,256), (32768,256), (33024,256), (131072,256), (262144,256)]), (16384,[(32768,21508391680), (33024,12918457088), (131072,25803358976), (131136,65536), (262144,38688260864)]), (16640,[(32768,512), (131072,512), (131136,65536), (262144,512)]), (32768,[(131072,25836913664), (131136,65536), (262144,34426848256)]), (33024,[(131072,131840), (131136,65536), (262144,131840)]), (131072,[(262144,34443625984)]), (131136,[(262144,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 450880 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 450880 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 450880 256) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 450880 8192) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 450880 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 450880 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 450880 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 450880 262144) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 450880 8256) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 450880 16640) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 450880 33024) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 450880 131136) = true := by decide
theorem full : checkArms 453056 450880 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 256, 8192, 16384, 32768, 131072, 262144, 8256, 16640, 33024, 131136] : List Nat).all (fun i => parts.all (shortPair g pp nn 450880 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short453056
theorem validBranch453056 : checkArms 453056 450880 [8256, 8320, 16512, 16640, 33024, 34816, 131136, 133120, 262272, 264192] [2496, 10496, 18496, 26624, 32960, 131456, 163968, 188416, 262464, 303104, 311360, 401664, 409600] = true := Short453056.full
end TightRow.Protected.Numeric
