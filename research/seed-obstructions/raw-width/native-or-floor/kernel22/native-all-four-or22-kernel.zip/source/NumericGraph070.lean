import NumericEdgeCodes
import NumericGraph070Code00
import Branch503424
import NumericGraph026
import NumericGraph027
import NumericGraph044
import NumericGraph056
import NumericGraph063
import NumericGraph068
import NumericGraph069
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m851_829 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e851_829 : Edge c851 c829 m851_829 := by
  exact edgeByCodes c851 c829 m851_829 1976943448883713 185118217501862461697 (by decide) (by decide) (by decide) (by decide)
theorem floor851 : Floor c851 7 := by
  have up := refundEdge e851_829 floor829 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)


end TightRow.Protected.Numeric
