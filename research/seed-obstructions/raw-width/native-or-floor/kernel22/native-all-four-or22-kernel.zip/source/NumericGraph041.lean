import Branch349312
import NumericGraph005
import NumericGraph033
import NumericGraph038
import NumericGraph040
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c492 : Chart := ⟨[16512, 16640, 69632, 262272, 266240],[4480, 16384, 20480, 65920, 327936, 344064]⟩
def m492_491 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e492_491 : Edge c492 c491 m492_491 := by constructor <;> decide
theorem floor492 : Floor c492 4 := by
  have up := refundEdge e492_491 floor491 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c493 : Chart := ⟨[16512, 66048, 69632, 262272, 266240],[4736, 20992, 65664, 279040, 344064]⟩
def m493_491 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e493_491 : Edge c493 c491 m493_491 := by constructor <;> decide
theorem floor493 : Floor c493 4 := by
  have up := refundEdge e493_491 floor491 66048 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c494 : Chart := ⟨[16512, 16640, 66048, 69632, 262272, 266240],[4992, 16896, 20992, 65920, 262912, 279040, 327936, 344064]⟩
def m494_493 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e494_493 : Edge c494 c493 m494_493 := by constructor <;> decide
theorem floor494 : Floor c494 5 := by
  have up := refundEdge e494_493 floor493 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c495 : Chart := ⟨[17408, 66560, 69632, 266240],[1024, 5120, 20480, 263168, 344064]⟩
def m495_466 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e495_466 : Edge c495 c466 m495_466 := by constructor <;> decide
theorem floor495 : Floor c495 3 := by
  have up := refundEdge e495_466 floor466 17408 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c496 : Chart := ⟨[16512, 17408, 66560, 69632, 262272, 266240],[5248, 20480, 65664, 263168, 344064]⟩
def m496_495 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e496_495 : Edge c496 c495 m496_495 := by constructor <;> decide
def m496_491 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e496_491 : Edge c496 c491 m496_491 := by constructor <;> decide
def m496_487 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e496_487 : Edge c496 c487 m496_487 := by constructor <;> decide
def m496_467 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e496_467 : Edge c496 c467 m496_467 := by constructor <;> decide
def m496_404 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, none, none, some 18, none, none, none]
private theorem e496_404 : Edge c496 c404 m496_404 := by constructor <;> decide
def m496_62 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, none, none, none, none, none]
private theorem e496_62 : Edge c496 c62 m496_62 := by constructor <;> decide
theorem floor496 : Floor c496 5 := by
  apply protectedBranch source c496.P c496.N (decode 349312) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 349312, q = 7 ∨ q = 10 ∨ q = 12 ∨ q = 14 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e496_495 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor495 k x net fit)
    · refine ⟨_,goodChild e496_491 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor491 k x net fit)
    · refine ⟨_,goodChild e496_487 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor487 k x net fit)
    · refine ⟨_,goodChild e496_467 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor467 k x net fit)
    · refine ⟨_,goodChild e496_404 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor404 k x net fit)
    · refine ⟨_,goodChild e496_62 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor62 k x net fit)
  · exact pairExcluded 349312 349312 [16512, 17408, 66560, 69632, 262272, 266240] [5248, 20480, 65664, 263168, 344064] validBranch349312 (by decide) (by decide) (by decide)
def c497 : Chart := ⟨[16640, 17408, 66560, 69632, 266240],[5376, 16384, 20480, 263424, 327936, 344064]⟩
def m497_495 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e497_495 : Edge c497 c495 m497_495 := by constructor <;> decide
theorem floor497 : Floor c497 4 := by
  have up := refundEdge e497_495 floor495 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c498 : Chart := ⟨[16512, 16640, 17408, 66560, 69632, 262272, 266240],[4480, 5248, 5376, 16384, 20480, 65920, 263424, 327936, 344064]⟩
def m498_496 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e498_496 : Edge c498 c496 m498_496 := by constructor <;> decide
theorem floor498 : Floor c498 6 := by
  have up := refundEdge e498_496 floor496 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c499 : Chart := ⟨[16512, 17408, 66048, 66560, 69632, 262272, 266240],[1664, 4736, 5248, 20992, 65664, 263680, 279040, 344064]⟩
def m499_496 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e499_496 : Edge c499 c496 m499_496 := by constructor <;> decide
theorem floor499 : Floor c499 6 := by
  have up := refundEdge e499_496 floor496 66048 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c500 : Chart := ⟨[16512, 16640, 17408, 66048, 66560, 69632, 262272, 266240],[1664, 4992, 5248, 5376, 16896, 20992, 65920, 263936, 279040, 327936, 344064]⟩
def m500_499 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e500_499 : Edge c500 c499 m500_499 := by constructor <;> decide
theorem floor500 : Floor c500 7 := by
  have up := refundEdge e500_499 floor499 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c501 : Chart := ⟨[17408, 66560, 69632, 264192, 266240],[7168, 22528, 83968, 262144, 263168, 344064]⟩
def m501_495 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e501_495 : Edge c501 c495 m501_495 := by constructor <;> decide
theorem floor501 : Floor c501 4 := by
  have up := refundEdge e501_495 floor495 264192 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c502 : Chart := ⟨[16512, 17408, 66560, 69632, 262272, 264192, 266240],[3200, 5248, 7168, 22528, 67712, 83968, 262144, 263168, 344064]⟩
def m502_496 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e502_496 : Edge c502 c496 m502_496 := by constructor <;> decide
theorem floor502 : Floor c502 6 := by
  have up := refundEdge e502_496 floor496 264192 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c503 : Chart := ⟨[16640, 17408, 66560, 69632, 264192, 266240],[7424, 18432, 22528, 67840, 83968, 263424, 327936, 344064]⟩
def m503_501 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e503_501 : Edge c503 c501 m503_501 := by constructor <;> decide
theorem floor503 : Floor c503 5 := by
  have up := refundEdge e503_501 floor501 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)

end TightRow.Protected.Numeric
