import NumericEdgeCodes
import NumericGraph078Code01
import Branch523712
import Branch523904
import NumericGraph030
import NumericGraph031
import NumericGraph050
import NumericGraph060
import NumericGraph068
import NumericGraph072
import NumericGraph074
import NumericGraph076
import NumericGraph077
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m945_915 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e945_915 : Edge c945 c915 m945_915 := by
  exact edgeByCodes c945 c915 m945_915 3727165692063524628371472640 88594757919751255421103576165974016 (by decide) (by decide) (by decide) (by decide)
def m945_898 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e945_898 : Edge c945 c898 m945_898 := by
  exact edgeByCodes c945 c898 m945_898 4037864368662391615301878530 5806146055028818284759215385523953729792 (by decide) (by decide) (by decide) (by decide)
def m945_865 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e945_865 : Edge c945 c865 m945_865 := by
  exact edgeByCodes c945 c865 m945_865 4037864368662391615301878016 5806146055028818284740696301281701069312 (by decide) (by decide) (by decide) (by decide)
def m945_821 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e945_821 : Edge c945 c821 m945_821 := by
  exact edgeByCodes c945 c821 m945_821 4037864368662391615268192512 5806146055028818280018329816204442665984 (by decide) (by decide) (by decide) (by decide)
def m945_729 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e945_729 : Edge c945 c729 m945_729 := by
  exact edgeByCodes c945 c729 m945_729 15772907690084155776958720 21356222328531149305385020957296558336 (by decide) (by decide) (by decide) (by decide)
def m945_607 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e945_607 : Edge c945 c607 m945_607 := by
  exact edgeByCodes c945 c607 m945_607 4037864331624223122206621952 5126905397450682091625014372756841629696 (by decide) (by decide) (by decide) (by decide)
def m945_373 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
theorem e945_373 : Edge c945 c373 m945_373 := by
  exact edgeByCodes c945 c373 m945_373 12131907574542231144628480 16039228897596455315556256657606574336 (by decide) (by decide) (by decide) (by decide)
theorem floor945 : Floor c945 12 := by
  apply protectedBranch source c945.P c945.N (decode 523904) 12
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 523904, q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e945_943 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor943 k x net fit)
    · refine ⟨_,goodChild e945_938 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor938 k x net fit)
    · refine ⟨_,goodChild e945_931 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor931 k x net fit)
    · refine ⟨_,goodChild e945_925 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor925 k x net fit)
    · refine ⟨_,goodChild e945_915 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor915 k x net fit)
    · refine ⟨_,goodChild e945_898 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor898 k x net fit)
    · refine ⟨_,goodChild e945_865 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor865 k x net fit)
    · refine ⟨_,goodChild e945_821 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor821 k x net fit)
    · refine ⟨_,goodChild e945_729 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor729 k x net fit)
    · refine ⟨_,goodChild e945_607 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor607 k x net fit)
    · refine ⟨_,goodChild e945_373 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor373 k x net fit)
  · exact pairExcluded 523904 523904 [8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240] [3712, 15360, 23040, 30720, 38016, 46080, 67712, 92160, 135808, 152064, 168064, 192512, 229504, 263680, 304128, 376832, 410112, 466944] validBranch523904 (by decide) (by decide) (by decide)
def c946 : Chart := ⟨[2105408, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2110464, 2112512, 2120256, 2127872, 2135232, 2143232, 2150464, 2164928, 2181184, 92160, 2195648, 2232960, 2249216, 2265216, 2289664, 229504, 2360896, 2376256, 2393152, 304128, 2474048, 410112, 466944]⟩
def m946_945 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e946_945 : Edge c946 c945 m946_945 := by
  exact edgeByCodes c946 c945 m946_945 305349376194324900392887138845185 2011096806482668246122455749909930601284096 (by decide) (by decide) (by decide) (by decide)
theorem floor946 : Floor c946 13 := by
  have up := refundEdge e946_945 floor945 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c947 : Chart := ⟨[8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[3584, 15616, 18944, 23040, 30720, 46080, 76032, 92160, 135936, 143616, 152064, 192512, 229376, 263936, 271616, 304128, 376832, 393984, 410112, 467200]⟩
def m947_943 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e947_943 : Edge c947 c943 m947_943 := by
  exact edgeByCodes c947 c943 m947_943 14559240984905721879724544 99019995993675738248809214176722944 (by decide) (by decide) (by decide) (by decide)
theorem floor947 : Floor c947 11 := by
  have up := refundEdge e947_943 floor943 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)


end TightRow.Protected.Numeric
