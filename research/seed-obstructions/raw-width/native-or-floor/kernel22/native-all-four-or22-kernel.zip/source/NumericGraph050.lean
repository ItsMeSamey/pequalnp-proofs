import NumericEdgeCodes
import NumericGraph045
import NumericGraph048
import NumericGraph049
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c600 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 2166784, 262272, 2363392],[1664, 2101696, 2102080, 2102144, 2102592, 2110464, 2110720, 2118208, 2135232, 2143232, 2150464, 2158592, 2163136, 90112, 2195648, 2361152, 271616, 2376256, 2393152, 304128, 2425152, 336128, 2474048]⟩
def m600_599 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 12]
theorem e600_599 : Edge c600 c599 m600_599 := by
  exact edgeByCodes c600 c599 m600_599 3727165692135864801209549313 7514224859885714715278505162459721368320 (by decide) (by decide) (by decide) (by decide)
theorem floor600 : Floor c600 11 := by
  have up := refundEdge e600_599 floor599 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c601 : Chart := ⟨[8320, 8704, 16512, 33280, 34816, 66048, 69632, 262272, 264192, 266240],[640, 2688, 4736, 23040, 30720, 36992, 61440, 67712, 92160, 98432, 279040, 303104, 335872, 376832]⟩
def m601_545 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e601_545 : Edge c601 c545 m601_545 := by
  exact edgeByCodes c601 c545 m601_545 166599134359138271488 1033693278377572253517280903681 (by decide) (by decide) (by decide) (by decide)
theorem floor601 : Floor c601 9 := by
  have up := refundEdge e601_545 floor545 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c602 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 69632, 262272, 264192, 266240],[2688, 4992, 14592, 18944, 23040, 30720, 36992, 61440, 67968, 76032, 92160, 98432, 262912, 279040, 303104, 336128, 376832]⟩
def m602_601 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e602_601 : Edge c602 c601 m602_601 := by
  exact edgeByCodes c602 c601 m602_601 52131149530171783119104 325711324654444922858199542988800 (by decide) (by decide) (by decide) (by decide)
theorem floor602 : Floor c602 10 := by
  have up := refundEdge e602_601 floor601 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c603 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 2166784, 262272, 264192, 2363392],[2688, 2101696, 2102080, 2102144, 2103616, 2109440, 2111744, 2120256, 2127872, 2134208, 2150464, 2158592, 2165184, 76032, 2181184, 92160, 2195648, 2360128, 2376256, 303104, 2425152, 336128, 2474048]⟩
def m603_602 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 12]
theorem e603_602 : Edge c603 c602 m603_602 := by
  exact edgeByCodes c603 c602 m603_602 3727165692135864801209549313 7514224880247663175380080883698416091904 (by decide) (by decide) (by decide) (by decide)
theorem floor603 : Floor c603 11 := by
  have up := refundEdge e603_602 floor602 2105408 2109440 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c604 : Chart := ⟨[8320, 16512, 16640, 17408, 33024, 34816, 66560, 69632, 262272, 264192, 266240],[128, 3200, 4480, 15616, 30720, 38016, 46080, 61440, 67968, 76032, 92160, 98432, 271616, 304128, 336128, 376832]⟩
def m604_580 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e604_580 : Edge c604 c580 m604_580 := by
  exact edgeByCodes c604 c580 m604_580 47390263963055590408705 1192771000759153699749441503745 (by decide) (by decide) (by decide) (by decide)
theorem floor604 : Floor c604 10 := by
  have up := refundEdge e604_580 floor580 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c605 : Chart := ⟨[8196, 8320, 16512, 16640, 17408, 33024, 34816, 66560, 69632, 262272, 264192, 266240],[3204, 3332, 4480, 7172, 9472, 15616, 22532, 30720, 38020, 46080, 53252, 61440, 67972, 76032, 83972, 92160, 98436, 263428, 271616, 295940, 304128, 327940, 336128, 376836]⟩
def m605_604 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e605_604 : Edge c605 c604 m605_604 := by
  exact edgeByCodes c605 c604 m605_604 13345574279723976512176641 30686881513209785232137911297076494336 (by decide) (by decide) (by decide) (by decide)
theorem floor605 : Floor c605 11 := by
  have up := refundEdge e605_604 floor604 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c606 : Chart := ⟨[2105408, 8320, 16512, 16640, 17408, 33024, 34816, 66560, 2166784, 262272, 264192, 2363392],[3200, 2101696, 2102592, 2103616, 2110464, 2112768, 2119744, 2127872, 2135232, 2143232, 2150464, 2158592, 2165184, 76032, 2181184, 92160, 2195648, 2360640, 271616, 2393152, 304128, 2425152, 336128, 2474048]⟩
def m606_604 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 12]
theorem e606_604 : Edge c606 c604 m606_604 := by
  exact edgeByCodes c606 c604 m606_604 13345574279723976512176641 30686881513209785232137911297076428800 (by decide) (by decide) (by decide) (by decide)
theorem floor606 : Floor c606 11 := by
  have up := refundEdge e606_604 floor604 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c607 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4736, 15360, 18944, 23040, 30720, 38016, 46080, 61440, 67712, 92160, 98432, 263680, 279040, 304128, 335872, 376832]⟩
def m607_601 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e607_601 : Edge c607 c601 m607_601 := by
  exact edgeByCodes c607 c601 m607_601 52131149529067959746816 325711324654444995197268557627392 (by decide) (by decide) (by decide) (by decide)
theorem floor607 : Floor c607 10 := by
  have up := refundEdge e607_601 floor601 17408 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c608 : Chart := ⟨[8196, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240],[3204, 3588, 3712, 4736, 7172, 9216, 15360, 23044, 30720, 38020, 46080, 53252, 61440, 67716, 83972, 92160, 98436, 263684, 279044, 295940, 304128, 335872, 376836]⟩
def m608_607 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e608_607 : Edge c608 c607 m608_607 := by
  exact edgeByCodes c608 c607 m608_607 3727165692135864801209549313 7514230072544521710207637356600707384066 (by decide) (by decide) (by decide) (by decide)
theorem floor608 : Floor c608 11 := by
  have up := refundEdge e608_607 floor607 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c609 : Chart := ⟨[8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 264192, 266240],[512, 3584, 4864, 15616, 23040, 30720, 46080, 61440, 76032, 92160, 263936, 271616, 279040, 304128, 336128, 376832]⟩
def m609_583 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e609_583 : Edge c609 c583 m609_583 := by
  exact edgeByCodes c609 c583 m609_583 47390263963055590408705 1192771000740634898085988991489 (by decide) (by decide) (by decide) (by decide)
theorem floor609 : Floor c609 10 := by
  have up := refundEdge e609_583 floor583 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c610 : Chart := ⟨[8196, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 264192, 266240],[3332, 3588, 4864, 7172, 9472, 15616, 23044, 30720, 37892, 46080, 53252, 61440, 67844, 76032, 83972, 92160, 263940, 271616, 279044, 295940, 304128, 327940, 336128, 376836]⟩
def m610_609 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e610_609 : Edge c610 c609 m610_609 := by
  exact edgeByCodes c610 c609 m610_609 13345574279723976512176641 30686881513520488630958579704169365761 (by decide) (by decide) (by decide) (by decide)
theorem floor610 : Floor c610 11 := by
  have up := refundEdge e610_609 floor609 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c611 : Chart := ⟨[2105408, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 264192, 2363392],[3584, 2102080, 2102592, 2103616, 2110464, 2112768, 2120256, 2127872, 2135104, 2143232, 2150464, 2158592, 2165056, 76032, 2181184, 92160, 2361152, 271616, 2376256, 2393152, 304128, 2425152, 336128, 2474048]⟩
def m611_609 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 12]
theorem e611_609 : Edge c611 c609 m611_609 := by
  exact edgeByCodes c611 c609 m611_609 13345574279723976512176641 30686881513520488630958579704169299968 (by decide) (by decide) (by decide) (by decide)
theorem floor611 : Floor c611 11 := by
  have up := refundEdge e611_609 floor609 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)


end TightRow.Protected.Numeric
