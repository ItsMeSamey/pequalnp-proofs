import NumericEdgeCodes
import Branch506432
import NumericGraph027
import NumericGraph045
import NumericGraph057
import NumericGraph064
import NumericGraph069
import NumericGraph070
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c852 : Chart := ⟨[2105408, 8704, 33280, 34816, 66048, 2166784, 2228288, 133120, 264192, 2363392],[2103872, 2111488, 2134080, 2164800, 75776, 2232832, 2273280, 229376, 2359872, 303104, 2457664, 393728, 466944]⟩
def m852_851 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e852_851 : Edge c852 c851 m852_851 := by
  exact edgeByCodes c852 c851 m852_851 650777864278573569 14559240984623143079444480 (by decide) (by decide) (by decide) (by decide)
def m852_840 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, some 6]
theorem e852_840 : Edge c852 c840 m852_840 := by
  exact edgeByCodes c852 c840 m852_840 578437691440496896 14559240984905721862881280 (by decide) (by decide) (by decide) (by decide)
def m852_831 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e852_831 : Edge c852 c831 m852_831 := by
  exact edgeByCodes c852 c831 m852_831 650777868590383874 14559240912565549058425344 (by decide) (by decide) (by decide) (by decide)
def m852_774 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e852_774 : Edge c852 c774 m852_774 := by
  exact edgeByCodes c852 c774 m852_774 650777868590383360 56872034813605352505600 (by decide) (by decide) (by decide) (by decide)
def m852_686 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, some 13, none, some 15, none, some 17, some 18, none, none, some 21]
theorem e852_686 : Edge c852 c686 m852_686 := by
  exact edgeByCodes c852 c686 m852_686 650777868556697856 56871963321164602933504 (by decide) (by decide) (by decide) (by decide)
def m852_544 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, some 21]
theorem e852_544 : Edge c852 c544 m852_544 := by
  exact edgeByCodes c852 c544 m852_544 650775660943507712 12146093192227367424164096 (by decide) (by decide) (by decide) (by decide)
def m852_328 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, none, none, none, some 21]
theorem e852_328 : Edge c852 c328 m852_328 := by
  exact edgeByCodes c852 c328 m852_328 506097522914230528 8519260178668413161439488 (by decide) (by decide) (by decide) (by decide)
theorem floor852 : Floor c852 9 := by
  apply protectedBranch source c852.P c852.N (decode 503872) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 503872, q = 6 ∨ q = 12 ∨ q = 13 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e852_851 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor851 k x net fit)
    · refine ⟨_,goodChild e852_840 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor840 k x net fit)
    · refine ⟨_,goodChild e852_831 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor831 k x net fit)
    · refine ⟨_,goodChild e852_774 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor774 k x net fit)
    · refine ⟨_,goodChild e852_686 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor686 k x net fit)
    · refine ⟨_,goodChild e852_544 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor544 k x net fit)
    · refine ⟨_,goodChild e852_328 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor328 k x net fit)
  · exact pairExcluded 506432 503872 [8256, 8704, 33280, 34816, 66048, 69632, 131136, 133120, 264192, 266240] [6720, 14336, 36928, 67648, 75776, 135680, 176128, 229376, 262720, 303104, 360512, 393728, 466944] validBranch506432 (by decide) (by decide) (by decide)
def c853 : Chart := ⟨[8320, 8704, 33280, 34816, 66048, 69632, 133120, 262272, 264192, 266240],[2176, 2688, 6656, 14336, 67712, 75776, 135808, 168064, 176128, 229504, 303104, 360448, 393728, 466944]⟩
def m853_545 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e853_545 : Edge c853 c545 m853_545 := by
  exact edgeByCodes c853 c545 m853_545 166599133255314833664 875545238877561259509585937921 (by decide) (by decide) (by decide) (by decide)
theorem floor853 : Floor c853 9 := by
  have up := refundEdge e853_545 floor545 133120 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c854 : Chart := ⟨[8196, 8320, 8704, 33280, 34816, 66048, 69632, 133120, 262272, 264192, 266240],[2688, 6660, 8192, 14336, 67716, 75776, 135684, 135808, 168068, 176128, 229508, 303104, 360452, 393732, 458756, 466944]⟩
def m854_853 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e854_853 : Edge c854 c853 m854_853 := by
  exact edgeByCodes c854 c853 m854_853 47390263963055590408705 305269837333152628611622226690048 (by decide) (by decide) (by decide) (by decide)
theorem floor854 : Floor c854 10 := by
  have up := refundEdge e854_853 floor853 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c855 : Chart := ⟨[8196, 1056896, 8704, 33280, 34816, 66048, 69632, 1179649, 133120, 1310848, 264192, 266240],[1051141, 1051265, 1053313, 1055233, 6660, 1062913, 1085569, 1093633, 1116293, 1124353, 1147013, 1179776, 135684, 1184384, 1216644, 176128, 1278084, 1311237, 1351681, 1384449, 1409029, 393732, 458756, 466944]⟩
def m855_854 : List (Option Addr) := [none, none, some 2, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, some 7, none]
theorem e855_854 : Edge c855 c854 m855_854 := by
  exact edgeByCodes c855 c854 m855_854 13345574279441397712027904 30686901954695902339570729801562260481 (by decide) (by decide) (by decide) (by decide)
theorem floor855 : Floor c855 11 := by
  have up := refundEdge e855_854 floor854 1179649 1179776 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c856 : Chart := ⟨[2105408, 8320, 8704, 33280, 34816, 66048, 2166784, 2228288, 133120, 262272, 264192, 2363392],[2688, 2103872, 2109440, 2111488, 2134208, 2164928, 75776, 2195648, 2232960, 2265216, 2273280, 229504, 2359872, 303104, 2457664, 393728, 466944]⟩
def m856_853 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e856_853 : Edge c856 c853 m856_853 := by
  exact edgeByCodes c856 c853 m856_853 52131149529067959812609 325711324654444995197268540850176 (by decide) (by decide) (by decide) (by decide)
theorem floor856 : Floor c856 10 := by
  have up := refundEdge e856_853 floor853 2105408 2109440 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c857 : Chart := ⟨[2105408, 8704, 33024, 33280, 34816, 66048, 2166784, 2228288, 133120, 264192, 2363392],[2102080, 2103616, 2103872, 2111744, 32768, 2134080, 2165056, 76032, 2233088, 2240768, 2273280, 229376, 2360128, 303104, 2425152, 2457664, 393984, 467200]⟩
def m857_852 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e857_852 : Edge c857 c852 m857_852 := by
  exact edgeByCodes c857 c852 m857_852 47390263963055590408448 1351848718399850142927809741570 (by decide) (by decide) (by decide) (by decide)
theorem floor857 : Floor c857 10 := by
  have up := refundEdge e857_852 floor852 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c858 : Chart := ⟨[8196, 2105408, 8704, 33024, 33280, 34816, 66048, 2166784, 2228288, 133120, 264192, 2363392],[2102080, 2103364, 2103616, 2103812, 2103872, 8448, 2111744, 2134084, 2165060, 76032, 2232836, 2233088, 2240768, 2265092, 2273280, 229380, 2360128, 303104, 2425156, 2457668, 393988, 459012, 467200]⟩
def m858_857 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e858_857 : Edge c858 c857 m858_857 := by
  exact edgeByCodes c858 c857 m858_857 13345574279723976512176641 1923301286976480835642763151233991926088192 (by decide) (by decide) (by decide) (by decide)
theorem floor858 : Floor c858 11 := by
  have up := refundEdge e858_857 floor857 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c859 : Chart := ⟨[8320, 8704, 33024, 33280, 34816, 66048, 69632, 133120, 262272, 264192, 266240],[2688, 6656, 14592, 32896, 67968, 76032, 136064, 143616, 168064, 176128, 196992, 229504, 303104, 360448, 393984, 467200]⟩
def m859_853 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e859_853 : Edge c859 c853 m859_853 := by
  exact edgeByCodes c859 c853 m859_853 47390263963055590408448 305349376194324900110308321853440 (by decide) (by decide) (by decide) (by decide)
theorem floor859 : Floor c859 10 := by
  have up := refundEdge e859_853 floor853 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c860 : Chart := ⟨[2105408, 8320, 8704, 33024, 33280, 34816, 66048, 2166784, 2228288, 133120, 262272, 264192, 2363392],[2688, 2101696, 2102080, 2103616, 2103872, 2109440, 2111744, 2134208, 2165184, 76032, 2195648, 2233216, 2240768, 2265216, 2273280, 196992, 229504, 2360128, 303104, 2425152, 2457664, 393984, 467200]⟩
def m860_859 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e860_859 : Edge c860 c859 m860_859 := by
  exact edgeByCodes c860 c859 m860_859 14559240984623143079576065 29352461220566339272491422331653456896 (by decide) (by decide) (by decide) (by decide)
theorem floor860 : Floor c860 11 := by
  have up := refundEdge e860_859 floor859 2105408 2109440 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c861 : Chart := ⟨[8704, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[512, 3584, 6656, 15360, 46080, 75776, 135680, 176128, 229376, 263680, 304128, 360448, 393728, 466944]⟩
def m861_834 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e861_834 : Edge c861 c834 m861_834 := by
  exact edgeByCodes c861 c834 m861_834 166599134359138271745 1033693278377572253517280903681 (by decide) (by decide) (by decide) (by decide)
theorem floor861 : Floor c861 9 := by
  have up := refundEdge e861_834 floor834 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c862 : Chart := ⟨[8196, 8704, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[3588, 6660, 7172, 9216, 15360, 37892, 46080, 67588, 75776, 135684, 167940, 176128, 229380, 263684, 295940, 304128, 360452, 393732, 458756, 466944]⟩

end TightRow.Protected.Numeric
