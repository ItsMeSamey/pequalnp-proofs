import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short322432
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 16512, 16640, 33024, 33280, 34816, 262272, 264192]
def n : List Nat := [896, 2432, 2688, 10496, 18944, 26624, 32896, 57344, 262912, 270592, 279040, 303104, 311296]
def pp := p.map (canonical 322432)
def nn := n.map (canonical 322432)
def parts : List Nat := [0, 256, 512, 2048, 8192, 16384, 262144, 8704, 16640, 264192]
def g : ShortGrid := [(0,[(256,67252053865045769540728170966264601049826817), (512,22563791469612060037379804643291221104854529), (2048,134329194607619753511368091242305424600729089), (8192,121696314560303149511313727684609), (8704,0), (16384,44602170972301536650371238763039444334411777), (16640,8589935104), (262144,156107598402751137489898577796859770851229697), (264192,25870861824)]), (256,[(512,848822976839936), (2048,34494219008), (8192,849922488271104), (8704,0), (16384,848831566578432), (262144,30065033984), (264192,30065033984)]), (512,[(2048,34494152960), (8192,284773511594240), (16384,8590131456), (16640,8590131456), (262144,30064967936), (264192,30064967936)]), (2048,[(8192,1696546441658624), (8704,0), (16384,1696546441659136), (16640,512), (262144,2260625988257792)]), (8192,[(16384,12935233792), (16640,12935233792), (262144,34410070272), (264192,34410070272)]), (8704,[(16384,0), (16640,0), (262144,0), (264192,0)]), (16384,[(262144,34426848000), (264192,34426848000)]), (16640,[(262144,512), (264192,512)])]
private theorem row0 : parts.all (shortPair g pp nn 289536 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 289536 256) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 289536 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 289536 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 289536 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 289536 16384) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 289536 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 289536 8704) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 289536 16640) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 289536 264192) = true := by decide
theorem full : checkArms 322432 289536 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 256, 512, 2048, 8192, 16384, 262144, 8704, 16640, 264192] : List Nat).all (fun i => parts.all (shortPair g pp nn 289536 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short322432
theorem validBranch322432 : checkArms 322432 289536 [8320, 8704, 16512, 16640, 33024, 33280, 34816, 262272, 264192] [896, 2432, 2688, 10496, 18944, 26624, 32896, 57344, 262912, 270592, 279040, 303104, 311296] = true := Short322432.full
end TightRow.Protected.Numeric
