import NumericEdgeCodes
import NumericGraph072Code00
import Branch507584
import NumericGraph027
import NumericGraph045
import NumericGraph057
import NumericGraph058
import NumericGraph065
import NumericGraph069
import NumericGraph070
import NumericGraph071
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c870 : Chart := ⟨[8320, 8704, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 6656, 9472, 15616, 38016, 46080, 67968, 76032, 136064, 143616, 168064, 176128, 196992, 229504, 263936, 271616, 304128, 360448, 393984, 467200]⟩
def m870_867 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e870_867 : Edge c870 c867 m870_867 := by
  exact edgeByCodes c870 c867 m870_867 14559222465821475332096513 25349139336640152492236512499016597760 (by decide) (by decide) (by decide) (by decide)
theorem floor870 : Floor c870 11 := by
  have up := refundEdge e870_867 floor867 8320 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c871 : Chart := ⟨[2105408, 8320, 8704, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2101696, 2102080, 2102592, 2103616, 2103872, 2112768, 33920, 2135232, 2143232, 2165184, 76032, 2195648, 2233216, 2240768, 2265216, 2273280, 196992, 229504, 2361152, 271616, 2393152, 304128, 2425152, 2457664, 393984, 467200]⟩
def m871_866 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e871_866 : Edge c871 c866 m871_866 := by
  exact edgeByCodes c871 c866 m871_866 284987427729500958188778798842112 2273458509528661127054485443368872852194560 (by decide) (by decide) (by decide) (by decide)
theorem floor871 : Floor c871 13 := by
  have up := refundEdge e871_866 floor866 33024 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c872 : Chart := ⟨[8196, 2105408, 8320, 8704, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3204, 3332, 3588, 3712, 2101696, 2102080, 2102592, 2103364, 2103616, 2103812, 2103872, 2104324, 9472, 2112768, 2135108, 2135172, 2135232, 2143232, 2165060, 67972, 2165184, 76032, 2195648, 2232836, 2233216, 2240768, 2265220, 2273280, 196996, 229508, 2360644, 263940, 2361152, 271616, 2393156, 304128, 2425156, 2457668, 393988, 459012, 467200]⟩
def m872_871 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e872_871 : Edge c872 c871 m872_871 := by
  exact edgeByCodes c872 c871 m872_871 78169440305751915386146223737209345 16516342357740646216746897343594718105287880964517136406006793219 (by decide) (by decide) (by decide) (by decide)
theorem floor872 : Floor c872 14 := by
  have up := refundEdge e872_871 floor871 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 14 ≤ 14).trans (up k x net fit)
def c873 : Chart := ⟨[8196, 2105408, 1056896, 8704, 33024, 33280, 34816, 66048, 66560, 2166784, 1179649, 2228288, 132096, 133120, 1310848, 264192, 2363392],[1049473, 1050241, 1051141, 1051265, 1051780, 3332, 3588, 1052288, 3150272, 3150401, 3150465, 2102080, 2102592, 2103364, 2103616, 3152385, 2103812, 2103872, 2104324, 3160065, 2112768, 1082501, 3182785, 2135108, 3183745, 3183748, 3183808, 3191809, 3211713, 1116293, 2165060, 1116545, 1116548, 3213760, 1124609, 1147013, 3244225, 1180032, 2232836, 3281792, 2240768, 3313796, 2273280, 1245572, 1278084, 3408705, 2360644, 1312261, 1312513, 263940, 2361152, 1320193, 1344517, 2393156, 1352705, 3473729, 2425156, 1384705, 3506245, 393988, 459012, 467200]⟩
def m873_872 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, some 7, some 21]
theorem e873_872 : Edge c873 c872 m873_872 := by
  exact edgeByCodes c873 c872 m873_872 21345817372864401140961492072029880576 130797761526891961363925858816726591431341308555266668415506982888399470636189451670046900408943876 (by decide) (by decide) (by decide) (by decide)
theorem floor873 : Floor c873 15 := by
  have up := refundEdge e873_872 floor872 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 15 ≤ 15).trans (up k x net fit)
def c874 : Chart := ⟨[16512, 17408, 34816, 66560, 132096, 133120, 262272, 264192],[2176, 3200, 33920, 67712, 83968, 180224, 229504, 295936, 376832, 409600, 458752]⟩
def m874_785 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e874_785 : Edge c874 c785 m874_785 := by
  exact edgeByCodes c874 c785 m874_785 1976943448883456 185118218605669056769 (by decide) (by decide) (by decide) (by decide)
theorem floor874 : Floor c874 7 := by
  have up := refundEdge e874_785 floor785 34816 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c875 : Chart := ⟨[16640, 17408, 33024, 34816, 66560, 132096, 133120, 264192],[1024, 3328, 67840, 83968, 180224, 229376, 263424, 295936, 376832, 409600, 459008]⟩
def m875_696 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e875_696 : Edge c875 c696 m875_696 := by
  exact edgeByCodes c875 c696 m875_696 1976943432040704 166743532125997433089 (by decide) (by decide) (by decide) (by decide)
theorem floor875 : Floor c875 7 := by
  have up := refundEdge e875_696 floor696 66560 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)


end TightRow.Protected.Numeric
