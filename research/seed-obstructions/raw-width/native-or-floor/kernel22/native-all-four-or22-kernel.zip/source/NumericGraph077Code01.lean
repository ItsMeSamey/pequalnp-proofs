import NumericEdgeCodes
import NumericGraph077Code00
import Branch522176
import Branch523200
import NumericGraph030
import NumericGraph050
import NumericGraph060
import NumericGraph067
import NumericGraph071
import NumericGraph073
import NumericGraph074
import NumericGraph075
import NumericGraph076
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m929_815 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e929_815 : Edge c929 c815 m929_815 := by
  exact edgeByCodes c929 c815 m929_815 1113232139568363115717270307072 2692007238136930650930159506351016104642609592536269056 (by decide) (by decide) (by decide) (by decide)
def m929_722 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 21]
theorem e929_722 : Edge c929 c722 m929_722 := by
  exact edgeByCodes c929 c722 m929_722 4348563044971897910879977728 664729705274817540387651741266789151682653860178583224576 (by decide) (by decide) (by decide) (by decide)
def m929_600 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 21]
theorem e929_600 : Edge c929 c600 m929_600 := by
  exact edgeByCodes c929 c600 m929_600 1113229712234952754434182086912 2405035534177875507253177009132445533090312030227923200 (by decide) (by decide) (by decide) (by decide)
def m929_366 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 21]
theorem e929_366 : Edge c929 c366 m929_366 := by
  exact edgeByCodes c929 c366 m929_366 954154417186781389109644624128 1734558464417935026034407504038276041520927558674223872 (by decide) (by decide) (by decide) (by decide)
theorem floor929 : Floor c929 13 := by
  apply protectedBranch source c929.P c929.N (decode 505792) 13
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 505792, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 12 ∨ q = 13 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e929_928 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor928 k x net fit)
    · refine ⟨_,goodChild e929_927 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor927 k x net fit)
    · refine ⟨_,goodChild e929_926 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor926 k x net fit)
    · refine ⟨_,goodChild e929_924 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor924 k x net fit)
    · refine ⟨_,goodChild e929_923 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor923 k x net fit)
    · refine ⟨_,goodChild e929_907 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor907 k x net fit)
    · refine ⟨_,goodChild e929_886 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor886 k x net fit)
    · refine ⟨_,goodChild e929_815 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor815 k x net fit)
    · refine ⟨_,goodChild e929_722 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor722 k x net fit)
    · refine ⟨_,goodChild e929_600 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor600 k x net fit)
    · refine ⟨_,goodChild e929_366 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor366 k x net fit)
  · exact pairExcluded 522176 505792 [8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632, 131136, 132096, 262272, 266240] [1664, 4544, 4928, 5440, 13568, 21056, 38080, 46080, 53312, 65984, 90112, 98496, 136064, 143616, 152064, 168064, 192512, 196992, 229504, 264000, 271616, 279104, 296000, 304128, 328000, 376896, 393984, 410112, 467200] validBranch522176 (by decide) (by decide) (by decide)
def c930 : Chart := ⟨[2105408, 8320, 16512, 16640, 33024, 34816, 2166784, 2228288, 133120, 262272, 264192, 2363392],[2101568, 2101696, 2103616, 2111744, 2119744, 2127872, 2134208, 2150464, 2165184, 76032, 2181184, 92160, 2195648, 2232704, 2240768, 2265216, 2289664, 196992, 229504, 303104, 2425152, 2474048, 409600, 467200]⟩
def m930_723 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 21]
theorem e930_723 : Edge c930 c723 m930_723 := by
  exact edgeByCodes c930 c723 m930_723 13345574279722872688738560 7516893741353044172716133144370304123144 (by decide) (by decide) (by decide) (by decide)
theorem floor930 : Floor c930 11 := by
  have up := refundEdge e930_723 floor723 2166784 2101568 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c931 : Chart := ⟨[8320, 8704, 16512, 33280, 34816, 66048, 69632, 133120, 262272, 264192, 266240],[640, 2688, 23040, 30720, 67712, 92160, 135808, 152064, 168064, 192512, 229504, 303104, 376832, 410112, 466944]⟩
def m931_853 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e931_853 : Edge c931 c853 m931_853 := by
  exact edgeByCodes c931 c853 m931_853 47390263963055590408448 284987427729500957906199998759169 (by decide) (by decide) (by decide) (by decide)
theorem floor931 : Floor c931 10 := by
  have up := refundEdge e931_853 floor853 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c932 : Chart := ⟨[2105408, 8320, 8704, 16512, 33280, 34816, 66048, 2166784, 2228288, 133120, 262272, 264192, 2363392],[2688, 2109440, 2120256, 2127872, 2134208, 2150464, 2164928, 2181184, 92160, 2195648, 2232960, 2249216, 2265216, 2289664, 229504, 2376256, 303104, 2474048, 410112, 466944]⟩
def m932_931 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e932_931 : Edge c932 c931 m932_931 := by
  exact edgeByCodes c932 c931 m932_931 14559240984623143079576065 99020075532536929040238775067869184 (by decide) (by decide) (by decide) (by decide)
theorem floor932 : Floor c932 11 := by
  have up := refundEdge e932_931 floor931 2105408 2109440 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c933 : Chart := ⟨[2105408, 8704, 16640, 33024, 33280, 34816, 66048, 2166784, 2228288, 133120, 264192, 2363392],[768, 2102080, 2103616, 2111744, 2120256, 2127872, 2150464, 2165056, 76032, 2181184, 92160, 2233088, 2240768, 2249216, 2289664, 229376, 2360128, 2376256, 303104, 2425152, 2474048, 393984, 410112, 467200]⟩
def m933_857 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e933_857 : Edge c933 c857 m933_857 := by
  exact edgeByCodes c933 c857 m933_857 13345574279723976512176384 2010755189715737073807202555765287345717761 (by decide) (by decide) (by decide) (by decide)
theorem floor933 : Floor c933 11 := by
  have up := refundEdge e933_857 floor857 16640 768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c934 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 69632, 133120, 262272, 264192, 266240],[2688, 14592, 18944, 23040, 30720, 67968, 76032, 92160, 136064, 143616, 152064, 168064, 192512, 196992, 229504, 303104, 376832, 393984, 410112, 467200]⟩
def m934_931 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e934_931 : Edge c934 c931 m934_931 := by
  exact edgeByCodes c934 c931 m934_931 14559240984905721879593216 99019995994884664068707521663270912 (by decide) (by decide) (by decide) (by decide)
theorem floor934 : Floor c934 11 := by
  have up := refundEdge e934_931 floor931 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c935 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 2166784, 2228288, 133120, 262272, 264192, 2363392],[2688, 2101696, 2102080, 2103616, 2111744, 2120256, 2127872, 2134208, 2150464, 2165184, 76032, 2181184, 92160, 2195648, 2233216, 2240768, 2249216, 2265216, 2289664, 196992, 229504, 2360128, 2376256, 303104, 2425152, 2474048, 393984, 410112, 467200]⟩
def m935_934 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e935_934 : Edge c935 c934 m935_934 := by
  exact edgeByCodes c935 c934 m935_934 1113232139549844033678369554945 160456135160597708930617707120007392784957113344 (by decide) (by decide) (by decide) (by decide)
def m935_933 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e935_933 : Edge c935 c933 m935_933 := by
  exact edgeByCodes c935 c933 m935_933 4348558304303351313201365504 689153852963099023037652601539482161414049600264254718466 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
