import NumericEdgeCodes
import Branch436928
import NumericGraph015
import NumericGraph034
import NumericGraph035
import NumericGraph052
import NumericGraph055
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c672 : Chart := ⟨[8196, 2105408, 8320, 16512, 16640, 17408, 2228288, 132096, 133120, 262272, 264192, 2363392],[2099524, 2436, 2099648, 3204, 3332, 2101696, 2102340, 2102404, 2102464, 2102592, 2103616, 2104324, 9472, 2112768, 2119748, 2127872, 131460, 2232452, 2232704, 2240768, 2248708, 2256896, 2360644, 271616, 2375748, 393476, 401664, 409604]⟩
def m672_671 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, none, none, some 17, some 18, none, none, some 21]
theorem e672_671 : Edge c672 c671 m672_671 := by
  exact edgeByCodes c672 c671 m672_671 13345574279723976512176641 2360911083040080348530960597105006763901698 (by decide) (by decide) (by decide) (by decide)
theorem floor672 : Floor c672 11 := by
  have up := refundEdge e672_671 floor671 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c673 : Chart := ⟨[8196, 2105408, 1056896, 1065088, 16640, 17408, 1179649, 2228288, 132096, 133120, 1310848, 264192, 2363392],[3146177, 1049733, 1050757, 2099524, 1051009, 1051012, 3148224, 1051780, 3332, 3150017, 3150272, 2102340, 3150977, 3150980, 3151040, 2102592, 2103616, 2104324, 1059073, 3159041, 2112768, 1067013, 3166273, 2119748, 3176449, 1180032, 1180036, 3281028, 3281280, 2240768, 2248708, 2256896, 3408193, 1311749, 2360644, 1320193, 3424325, 393476, 401664, 409604]⟩
def m673_672 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, none, none, some 17, some 18, none, some 7, some 21]
theorem e673_672 : Edge c673 c672 m673_672 := by
  exact edgeByCodes c673 c672 m673_672 3727165692135863697386111232 4122871351913047493577446104191142985003177926132131589393364681987 (by decide) (by decide) (by decide) (by decide)
theorem floor673 : Floor c673 12 := by
  have up := refundEdge e673_672 floor672 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 12 ≤ 12).trans (up k x net fit)
def c674 : Chart := ⟨[2105408, 8320, 8704, 16512, 17408, 2228288, 132096, 133120, 262272, 264192, 2363392],[2099392, 3712, 2102464, 9216, 2112512, 2120256, 2127872, 2232960, 2249216, 2256896, 2360896, 271360, 2376256, 401408, 410112]⟩
def m674_670 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, some 12, some 13, some 14, none, none, some 17, some 18, none, none, some 21]
theorem e674_670 : Edge c674 c670 m674_670 := by
  exact edgeByCodes c674 c670 m674_670 47390263963055590408448 284987427729519476990446546321664 (by decide) (by decide) (by decide) (by decide)
theorem floor674 : Floor c674 10 := by
  have up := refundEdge e674_670 floor670 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c675 : Chart := ⟨[8256, 8320, 34816, 131136, 133120, 262272, 264192],[2176, 2240, 10240, 32960, 163968, 172032, 294976, 303104, 401408]⟩
def m675_628 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e675_628 : Edge c675 c628 m675_628 := by
  exact edgeByCodes c675 c628 m675_628 6618611908864 34460664321 (by decide) (by decide) (by decide) (by decide)
theorem floor675 : Floor c675 6 := by
  have up := refundEdge e675_628 floor628 34816 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c676 : Chart := ⟨[8256, 8320, 33024, 34816, 131136, 133120, 262272, 264192],[2496, 10496, 32896, 32960, 131456, 163968, 172032, 262464, 294976, 303104, 401664]⟩
def m676_675 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e676_675 : Edge c676 c675 m676_675 := by
  exact edgeByCodes c676 c675 m676_675 1976943448883456 185118217501845553152 (by decide) (by decide) (by decide) (by decide)
theorem floor676 : Floor c676 7 := by
  have up := refundEdge e676_675 floor675 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c677 : Chart := ⟨[8196, 8256, 8320, 33024, 34816, 131136, 133120, 262272, 264192],[2372, 2436, 2496, 8448, 10496, 32960, 131460, 163972, 172032, 262468, 294980, 303104, 393476, 401664]⟩
def m677_676 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e677_676 : Edge c677 c676 m677_676 := by
  exact edgeByCodes c677 c676 m677_676 578437695752307201 15768166804520351054496770 (by decide) (by decide) (by decide) (by decide)
theorem floor677 : Floor c677 8 := by
  have up := refundEdge e677_676 floor676 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 8 ≤ 8).trans (up k x net fit)
def c678 : Chart := ⟨[8256, 8704, 33280, 34816, 131136, 133120, 264192],[2048, 2624, 10240, 172032, 262720, 294976, 303104, 393728, 401408]⟩
def m678_185 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
theorem e678_185 : Edge c678 c185 m678_185 := by
  exact edgeByCodes c678 c185 m678_185 5514788471040 13002670593 (by decide) (by decide) (by decide) (by decide)
theorem floor678 : Floor c678 6 := by
  have up := refundEdge e678_185 floor185 264192 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c679 : Chart := ⟨[8320, 8704, 33280, 34816, 133120, 262272, 264192],[2176, 2688, 10240, 131712, 163968, 172032, 303104, 393728, 401408]⟩
def m679_419 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
theorem e679_419 : Edge c679 c419 m679_419 := by
  exact edgeByCodes c679 c419 m679_419 6618595066112 25887506945 (by decide) (by decide) (by decide) (by decide)
theorem floor679 : Floor c679 6 := by
  have up := refundEdge e679_419 floor419 133120 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c680 : Chart := ⟨[8256, 8320, 8704, 33280, 34816, 131136, 133120, 262272, 264192],[2240, 2624, 2688, 10240, 32960, 131712, 163968, 172032, 262720, 294976, 303104, 393728, 401408]⟩
def m680_679 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e680_679 : Edge c680 c679 m680_679 := by
  exact edgeByCodes c680 c679 m680_679 2259522232189441 222156384891134214656 (by decide) (by decide) (by decide) (by decide)
def m680_678 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e680_678 : Edge c680 c678 m680_678 := by
  exact edgeByCodes c680 c678 m680_678 2258418425594368 222156387098780958976 (by decide) (by decide) (by decide) (by decide)
def m680_675 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e680_675 : Edge c680 c675 m680_675 := by
  exact edgeByCodes c680 c675 m680_675 2259522249031936 222084045822102798336 (by decide) (by decide) (by decide) (by decide)
def m680_632 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
theorem e680_632 : Edge c680 c632 m680_632 := by
  exact edgeByCodes c680 c632 m680_632 2259522248900864 222155819729239015680 (by decide) (by decide) (by decide) (by decide)
def m680_421 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
theorem e680_421 : Edge c680 c421 m680_421 := by
  exact edgeByCodes c680 c421 m680_421 2259513625411840 185118215294232428800 (by decide) (by decide) (by decide) (by decide)
def m680_188 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
theorem e680_188 : Edge c680 c188 m680_188 := by
  exact edgeByCodes c680 c188 m680_188 1694364648734976 129560965866059858176 (by decide) (by decide) (by decide) (by decide)
theorem floor680 : Floor c680 8 := by
  apply protectedBranch source c680.P c680.N (decode 426688) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 426688, q = 6 ∨ q = 7 ∨ q = 9 ∨ q = 15 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e680_679 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor679 k x net fit)
    · refine ⟨_,goodChild e680_678 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor678 k x net fit)
    · refine ⟨_,goodChild e680_675 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor675 k x net fit)
    · refine ⟨_,goodChild e680_632 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor632 k x net fit)
    · refine ⟨_,goodChild e680_421 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor421 k x net fit)
    · refine ⟨_,goodChild e680_188 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor188 k x net fit)
  · exact pairExcluded 436928 426688 [8256, 8320, 8704, 33280, 34816, 131136, 133120, 262272, 264192] [2240, 2624, 2688, 10240, 32960, 131712, 163968, 172032, 262720, 294976, 303104, 393728, 401408] validBranch436928 (by decide) (by decide) (by decide)
def c681 : Chart := ⟨[8196, 8256, 8320, 8704, 33280, 34816, 131136, 133120, 262272, 264192],[2116, 2180, 2240, 2564, 2624, 2688, 8192, 10240, 32960, 131712, 163972, 172032, 262720, 294980, 303104, 393732, 401408]⟩
def m681_680 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e681_680 : Edge c681 c680 m681_680 := by
  exact edgeByCodes c681 c680 m681_680 166599134359138271745 1272309861949944846740189676546 (by decide) (by decide) (by decide) (by decide)
theorem floor681 : Floor c681 9 := by
  have up := refundEdge e681_680 floor680 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c682 : Chart := ⟨[8256, 8320, 8704, 33024, 33280, 34816, 131136, 133120, 262272, 264192],[2496, 2624, 2688, 10496, 32896, 32960, 131968, 163968, 172032, 262976, 294976, 303104, 393984, 401664]⟩
def m682_680 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e682_680 : Edge c682 c680 m682_680 := by
  exact edgeByCodes c682 c680 m682_680 166599134359138205952 1033693278377572253517264060672 (by decide) (by decide) (by decide) (by decide)
theorem floor682 : Floor c682 9 := by
  have up := refundEdge e682_680 floor680 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c683 : Chart := ⟨[8320, 8704, 33280, 34816, 132096, 133120, 262272, 264192],[3712, 11264, 33920, 131200, 131712, 163968, 172032, 263680, 304128, 393728, 401408]⟩
def m683_679 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e683_679 : Edge c683 c679 m683_679 := by
  exact edgeByCodes c683 c679 m683_679 1976943432040704 185118217501862330368 (by decide) (by decide) (by decide) (by decide)
theorem floor683 : Floor c683 7 := by
  have up := refundEdge e683_679 floor679 132096 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)


end TightRow.Protected.Numeric
