import Branch313728
import NumericGraph002
import NumericGraph033
import NumericGraph034
import NumericGraph035
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c432 : Chart := ⟨[16512, 16640, 33024, 33280, 262272],[896, 32896, 262912, 279040, 311296]⟩
def m432_431 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e432_431 : Edge c432 c431 m432_431 := by constructor <;> decide
theorem floor432 : Floor c432 4 := by
  have up := refundEdge e432_431 floor431 33280 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c433 : Chart := ⟨[16512, 34816, 262272, 264192],[128, 2176, 18432, 32896, 311296]⟩
def m433_406 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e433_406 : Edge c433 c406 m433_406 := by constructor <;> decide
theorem floor433 : Floor c433 3 := by
  have up := refundEdge e433_406 floor406 16512 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c434 : Chart := ⟨[16640, 33024, 34816, 264192],[256, 2304, 18432, 262400, 311296]⟩
def m434_407 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e434_407 : Edge c434 c407 m434_407 := by constructor <;> decide
theorem floor434 : Floor c434 3 := by
  have up := refundEdge e434_407 floor407 16640 256 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c435 : Chart := ⟨[16512, 16640, 33024, 34816, 262272, 264192],[2432, 18432, 32896, 262400, 311296]⟩
def m435_434 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e435_434 : Edge c435 c434 m435_434 := by constructor <;> decide
def m435_433 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e435_433 : Edge c435 c433 m435_433 := by constructor <;> decide
def m435_431 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e435_431 : Edge c435 c431 m435_431 := by constructor <;> decide
def m435_408 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e435_408 : Edge c435 c408 m435_408 := by constructor <;> decide
def m435_400 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e435_400 : Edge c435 c400 m435_400 := by constructor <;> decide
def m435_26 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e435_26 : Edge c435 c26 m435_26 := by constructor <;> decide
theorem floor435 : Floor c435 5 := by
  apply protectedBranch source c435.P c435.N (decode 313728) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 313728, q = 7 ∨ q = 8 ∨ q = 11 ∨ q = 14 ∨ q = 15 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e435_434 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor434 k x net fit)
    · refine ⟨_,goodChild e435_433 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor433 k x net fit)
    · refine ⟨_,goodChild e435_431 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor431 k x net fit)
    · refine ⟨_,goodChild e435_408 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor408 k x net fit)
    · refine ⟨_,goodChild e435_400 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor400 k x net fit)
    · refine ⟨_,goodChild e435_26 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor26 k x net fit)
  · exact pairExcluded 313728 313728 [16512, 16640, 33024, 34816, 262272, 264192] [2432, 18432, 32896, 262400, 311296] validBranch313728 (by decide) (by decide) (by decide)
def c436 : Chart := ⟨[16512, 16640, 33024, 33280, 34816, 262272, 264192],[896, 2432, 2688, 18944, 32896, 262912, 279040, 311296]⟩
def m436_435 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e436_435 : Edge c436 c435 m436_435 := by constructor <;> decide
theorem floor436 : Floor c436 6 := by
  have up := refundEdge e436_435 floor435 33280 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c437 : Chart := ⟨[16512, 17408, 34816, 262272, 264192],[3200, 18432, 33920, 295936, 311296]⟩
def m437_433 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e437_433 : Edge c437 c433 m437_433 := by constructor <;> decide
theorem floor437 : Floor c437 4 := by
  have up := refundEdge e437_433 floor433 17408 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c438 : Chart := ⟨[16640, 17408, 33024, 34816, 264192],[3328, 18432, 263424, 295936, 311296]⟩
def m438_434 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e438_434 : Edge c438 c434 m438_434 := by constructor <;> decide
theorem floor438 : Floor c438 4 := by
  have up := refundEdge e438_434 floor434 17408 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c439 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 262272, 264192],[2432, 3200, 3328, 18432, 33920, 263424, 295936, 311296]⟩
def m439_435 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e439_435 : Edge c439 c435 m439_435 := by constructor <;> decide
theorem floor439 : Floor c439 6 := by
  have up := refundEdge e439_435 floor435 17408 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c440 : Chart := ⟨[16512, 17408, 33280, 34816, 262272, 264192],[3712, 18944, 33920, 263680, 279040, 295936, 311296]⟩
def m440_437 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e440_437 : Edge c440 c437 m440_437 := by constructor <;> decide
theorem floor440 : Floor c440 5 := by
  have up := refundEdge e440_437 floor437 33280 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c441 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 262272, 264192],[896, 2432, 3328, 3712, 18944, 33920, 263936, 279040, 295936, 311296]⟩
def m441_439 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e441_439 : Edge c441 c439 m441_439 := by constructor <;> decide
theorem floor441 : Floor c441 7 := by
  have up := refundEdge e441_439 floor439 33280 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c442 : Chart := ⟨[16512, 16640, 33024, 262272, 266240],[4480, 36992, 53248, 262400, 311296]⟩
def m442_431 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e442_431 : Edge c442 c431 m442_431 := by constructor <;> decide
theorem floor442 : Floor c442 4 := by
  have up := refundEdge e442_431 floor431 266240 262400 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c443 : Chart := ⟨[16512, 16640, 33024, 33280, 262272, 266240],[4992, 20992, 32896, 36992, 53248, 262912, 279040, 311296]⟩
def m443_442 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, some 12, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e443_442 : Edge c443 c442 m443_442 := by constructor <;> decide
theorem floor443 : Floor c443 5 := by
  have up := refundEdge e443_442 floor442 33280 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)

end TightRow.Protected.Numeric
