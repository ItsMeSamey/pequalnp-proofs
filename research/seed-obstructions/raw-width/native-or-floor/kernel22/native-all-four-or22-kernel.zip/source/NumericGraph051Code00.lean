import NumericEdgeCodes
import Branch393088
import NumericGraph009
import NumericGraph032
import NumericGraph038
import NumericGraph043
import NumericGraph045
import NumericGraph048
import NumericGraph049
import NumericGraph050
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c612 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4992, 15616, 23040, 30720, 38016, 46080, 61440, 67968, 76032, 92160, 98432, 263936, 271616, 279040, 304128, 336128, 376832]⟩
def m612_609 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e612_609 : Edge c612 c609 m612_609 := by
  exact edgeByCodes c612 c609 m612_609 15772889171003220699644673 22680258027456316683882776706865496064 (by decide) (by decide) (by decide) (by decide)
def m612_607 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e612_607 : Edge c612 c607 m612_607 := by
  exact edgeByCodes c612 c607 m612_607 4037864368662391615284969728 5806146054949279418827538954004470038784 (by decide) (by decide) (by decide) (by decide)
def m612_604 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e612_604 : Edge c612 c604 m612_604 := by
  exact edgeByCodes c612 c604 m612_604 15772907690086359112024576 22680257947606761557523293877974401024 (by decide) (by decide) (by decide) (by decide)
def m612_602 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e612_602 : Edge c612 c602 m612_602 := by
  exact edgeByCodes c612 c602 m612_602 4037864368590051442446958848 5806146054949279423568424238541862732032 (by decide) (by decide) (by decide) (by decide)
def m612_599 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e612_599 : Edge c612 c599 m612_599 := by
  exact edgeByCodes c612 c599 m612_599 4036650701956927291134181632 5806146055028818284740696301277439721728 (by decide) (by decide) (by decide) (by decide)
def m612_592 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e612_592 : Edge c612 c592 m612_592 := by
  exact edgeByCodes c612 c592 m612_592 3727160951250297685016707328 22680258027456321424840685095391199233 (by decide) (by decide) (by decide) (by decide)
def m612_584 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e612_584 : Edge c612 c584 m612_584 := by
  exact edgeByCodes c612 c584 m612_584 4037864368662391615301878530 88594757918537588788260899846750464 (by decide) (by decide) (by decide) (by decide)
def m612_550 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e612_550 : Edge c612 c550 m612_550 := by
  exact edgeByCodes c612 c550 m612_550 15772907690087467247272192 88594757609052560519890291008930048 (by decide) (by decide) (by decide) (by decide)
def m612_518 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e612_518 : Edge c612 c518 m612_518 := by
  exact edgeByCodes c612 c518 m612_518 15772907690087454311842048 88594678380885323888504670253285632 (by decide) (by decide) (by decide) (by decide)
def m612_461 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, none, none, some 18, none, none, none]
theorem e612_461 : Edge c612 c461 m612_461 := by
  exact edgeByCodes c612 c461 m612_461 15772907473066948733042944 88574395971267449562227110823657480 (by decide) (by decide) (by decide) (by decide)
def m612_118 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, none, none, none, none]
theorem e612_118 : Edge c612 c118 m612_118 := by
  exact edgeByCodes c612 c118 m612_118 12131907574542231144628480 88492948177427043259624730533101580 (by decide) (by decide) (by decide) (by decide)
theorem floor612 : Floor c612 12 := by
  apply protectedBranch source c612.P c612.N (decode 393088) 12
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 393088, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e612_609 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor609 k x net fit)
    · refine ⟨_,goodChild e612_607 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor607 k x net fit)
    · refine ⟨_,goodChild e612_604 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor604 k x net fit)
    · refine ⟨_,goodChild e612_602 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor602 k x net fit)
    · refine ⟨_,goodChild e612_599 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor599 k x net fit)
    · refine ⟨_,goodChild e612_592 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor592 k x net fit)
    · refine ⟨_,goodChild e612_584 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor584 k x net fit)
    · refine ⟨_,goodChild e612_550 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor550 k x net fit)
    · refine ⟨_,goodChild e612_518 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor518 k x net fit)
    · refine ⟨_,goodChild e612_461 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor461 k x net fit)
    · refine ⟨_,goodChild e612_118 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor118 k x net fit)
  · exact pairExcluded 393088 393088 [8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240] [3712, 4992, 15616, 23040, 30720, 38016, 46080, 61440, 67968, 76032, 92160, 98432, 263936, 271616, 279040, 304128, 336128, 376832] validBranch393088 (by decide) (by decide) (by decide)
def c613 : Chart := ⟨[8196, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240],[3204, 3332, 3588, 3712, 4992, 7172, 9472, 15616, 23044, 30720, 38020, 46080, 53252, 61440, 67972, 76032, 83972, 92160, 98436, 263940, 271616, 279044, 295940, 304128, 327940, 336128, 376836]⟩
def m613_612 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e613_612 : Edge c613 c612 m613_612 := by
  exact edgeByCodes c613 c612 m613_612 284987427729500958188778798907905 2273457175088086075209077579023665913594883 (by decide) (by decide) (by decide) (by decide)
theorem floor613 : Floor c613 13 := by
  have up := refundEdge e613_612 floor612 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c614 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 262272, 264192, 2363392],[3712, 2101696, 2102080, 2102144, 2102592, 2103616, 2110464, 2112768, 2120256, 2127872, 2135232, 2143232, 2150464, 2158592, 2165184, 76032, 2181184, 92160, 2195648, 2361152, 271616, 2376256, 2393152, 304128, 2425152, 336128, 2474048]⟩
def m614_612 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 12]
theorem e614_612 : Edge c614 c612 m614_612 := by
  exact edgeByCodes c614 c612 m614_612 284987427729500958188778798907905 2273457175088086075209077579023665913594624 (by decide) (by decide) (by decide) (by decide)
theorem floor614 : Floor c614 13 := by
  have up := refundEdge e614_612 floor612 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c615 : Chart := ⟨[133120, 264192],[2048, 393216]⟩
def m615_385 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, none, none, none, some 18, none, none, none]
theorem e615_385 : Edge c615 c385 m615_385 := by
  exact edgeByCodes c615 c385 m615_385 1 256 (by decide) (by decide) (by decide) (by decide)
theorem floor615 : Floor c615 1 := by
  have up := refundEdge e615_385 floor385 133120 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c616 : Chart := ⟨[131136, 133120, 264192],[2112, 131072, 262208, 393216]⟩
def m616_615 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
theorem e616_615 : Edge c616 c615 m616_615 := by
  exact edgeByCodes c616 c615 m616_615 513 768 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
