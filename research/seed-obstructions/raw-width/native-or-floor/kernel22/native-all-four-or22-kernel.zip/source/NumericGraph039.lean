import Branch340608
import NumericGraph004
import NumericGraph032
import NumericGraph038
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c468 : Chart := ⟨[69632, 264192, 266240],[6144, 67584, 262144, 327680]⟩
def m468_462 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e468_462 : Edge c468 c462 m468_462 := by constructor <;> decide
theorem floor468 : Floor c468 2 := by
  have up := refundEdge e468_462 floor462 264192 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c469 : Chart := ⟨[66048, 69632, 264192, 266240],[6656, 65536, 67584, 262656, 327680]⟩
def m469_468 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e469_468 : Edge c469 c468 m469_468 := by constructor <;> decide
theorem floor469 : Floor c469 3 := by
  have up := refundEdge e469_468 floor468 66048 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c470 : Chart := ⟨[66560, 69632, 264192, 266240],[7168, 65536, 67584, 263168, 327680]⟩
def m470_468 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e470_468 : Edge c470 c468 m470_468 := by constructor <;> decide
theorem floor470 : Floor c470 3 := by
  have up := refundEdge e470_468 floor468 66560 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c471 : Chart := ⟨[8320, 8704, 66048, 262272],[640, 65664, 262656, 335872]⟩
def m471_389 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e471_389 : Edge c471 c389 m471_389 := by constructor <;> decide
theorem floor471 : Floor c471 3 := by
  have up := refundEdge e471_389 floor389 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c472 : Chart := ⟨[8320, 8704, 66048, 66560, 262272],[1664, 65664, 263680, 271360, 335872]⟩
def m472_471 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e472_471 : Edge c472 c471 m472_471 := by constructor <;> decide
theorem floor472 : Floor c472 4 := by
  have up := refundEdge e472_471 floor471 66560 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c473 : Chart := ⟨[8320, 8704, 66048, 262272, 264192],[2688, 67712, 75776, 262656, 335872]⟩
def m473_471 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e473_471 : Edge c473 c471 m473_471 := by constructor <;> decide
theorem floor473 : Floor c473 4 := by
  have up := refundEdge e473_471 floor471 264192 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c474 : Chart := ⟨[8320, 8704, 66048, 66560, 262272, 264192],[3712, 11264, 65664, 67712, 75776, 263680, 271360, 335872]⟩
def m474_473 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e474_473 : Edge c474 c473 m474_473 := by constructor <;> decide
theorem floor474 : Floor c474 5 := by
  have up := refundEdge e474_473 floor473 66560 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c475 : Chart := ⟨[8320, 69632, 262272, 266240],[128, 4224, 12288, 65664, 335872]⟩
def m475_463 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e475_463 : Edge c475 c463 m475_463 := by constructor <;> decide
theorem floor475 : Floor c475 3 := by
  have up := refundEdge e475_463 floor463 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c476 : Chart := ⟨[8704, 66048, 69632, 266240],[512, 4608, 12288, 262656, 335872]⟩
def m476_464 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e476_464 : Edge c476 c464 m476_464 := by constructor <;> decide
theorem floor476 : Floor c476 3 := by
  have up := refundEdge e476_464 floor464 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c477 : Chart := ⟨[2105408, 8704, 66048, 2166784, 2363392],[2101824, 2109440, 2359872, 2424896, 335872]⟩
def m477_476 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, some 12]
private theorem e477_476 : Edge c477 c476 m477_476 := by constructor <;> decide
theorem floor477 : Floor c477 4 := by
  have up := refundEdge e477_476 floor476 2105408 2109440 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c478 : Chart := ⟨[8320, 8704, 66048, 69632, 262272, 266240],[4736, 12288, 65664, 262656, 335872]⟩
def m478_476 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e478_476 : Edge c478 c476 m478_476 := by constructor <;> decide
def m478_475 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e478_475 : Edge c478 c475 m478_475 := by constructor <;> decide
def m478_471 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e478_471 : Edge c478 c471 m478_471 := by constructor <;> decide
def m478_465 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e478_465 : Edge c478 c465 m478_465 := by constructor <;> decide
def m478_395 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, none, none, none, some 18, none, none, none]
private theorem e478_395 : Edge c478 c395 m478_395 := by constructor <;> decide
def m478_54 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, none, some 16, none, none, none, none, none]
private theorem e478_54 : Edge c478 c54 m478_54 := by constructor <;> decide
theorem floor478 : Floor c478 5 := by
  apply protectedBranch source c478.P c478.N (decode 340608) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 340608, q = 7 ∨ q = 9 ∨ q = 12 ∨ q = 13 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e478_476 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor476 k x net fit)
    · refine ⟨_,goodChild e478_475 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor475 k x net fit)
    · refine ⟨_,goodChild e478_471 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor471 k x net fit)
    · refine ⟨_,goodChild e478_465 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor465 k x net fit)
    · refine ⟨_,goodChild e478_395 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor395 k x net fit)
    · refine ⟨_,goodChild e478_54 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor54 k x net fit)
  · exact pairExcluded 340608 340608 [8320, 8704, 66048, 69632, 262272, 266240] [4736, 12288, 65664, 262656, 335872] validBranch340608 (by decide) (by decide) (by decide)
def c479 : Chart := ⟨[8196, 8320, 8704, 66048, 69632, 262272, 266240],[4228, 4612, 4736, 8192, 12288, 65668, 262660, 327684, 335872]⟩
def m479_478 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e479_478 : Edge c479 c478 m479_478 := by constructor <;> decide
theorem floor479 : Floor c479 6 := by
  have up := refundEdge e479_478 floor478 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)

end TightRow.Protected.Numeric
