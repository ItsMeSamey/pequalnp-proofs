import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short421056
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8320, 16512, 17408, 131136, 132096, 133120, 262272, 264192]
def n : List Nat := [1216, 2240, 3200, 11264, 18496, 26624, 131200, 155648, 263232, 271360, 278592, 401408, 409600]
def pp := p.map (canonical 421056)
def nn := n.map (canonical 421056)
def parts : List Nat := [0, 64, 1024, 2048, 8192, 16384, 262144, 8256, 17408, 264192]
def g : ShortGrid := [(0,[(64,262705983522139869474336836527173031428865), (1024,67252394152605066567097902053636235466048513), (2048,134329194607619753511368091242305424600729089), (8192,5314072402466570861994032775561217), (8256,256), (16384,44602170972301536650371238763039444334411777), (17408,8589935104), (262144,156107598402751137489898577796859770851229697), (264192,25870861824)]), (64,[(1024,12952207360), (2048,34494152704), (8192,3298534883328), (16384,8590131200), (17408,8590131200), (262144,30064967680), (264192,30064967680)]), (1024,[(2048,34494219008), (8192,849922488270848), (8256,256), (16384,848831566578432), (262144,30065033984), (264192,30065033984)]), (2048,[(8192,1696546441658368), (8256,256), (16384,1696546441659136), (17408,512), (262144,2260625988257792)]), (8192,[(16384,12935233536), (17408,12935233536), (262144,34410070016), (264192,34410070016)]), (8256,[(16384,256), (17408,256), (262144,256), (264192,256)]), (16384,[(262144,34426848000), (264192,34426848000)]), (17408,[(262144,512), (264192,512)])]
private theorem row0 : parts.all (shortPair g pp nn 289856 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 289856 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 289856 1024) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 289856 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 289856 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 289856 16384) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 289856 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 289856 8256) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 289856 17408) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 289856 264192) = true := by decide
theorem full : checkArms 421056 289856 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 1024, 2048, 8192, 16384, 262144, 8256, 17408, 264192] : List Nat).all (fun i => parts.all (shortPair g pp nn 289856 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short421056
theorem validBranch421056 : checkArms 421056 289856 [8256, 8320, 16512, 17408, 131136, 132096, 133120, 262272, 264192] [1216, 2240, 3200, 11264, 18496, 26624, 131200, 155648, 263232, 271360, 278592, 401408, 409600] = true := Short421056.full
end TightRow.Protected.Numeric
