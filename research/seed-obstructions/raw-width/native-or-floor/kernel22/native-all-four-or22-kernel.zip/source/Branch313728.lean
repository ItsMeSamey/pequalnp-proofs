import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short313728
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16512, 16640, 33024, 34816, 262272, 264192]
def n : List Nat := [2432, 18432, 32896, 262400, 311296]
def pp := p.map (canonical 313728)
def nn := n.map (canonical 313728)
def parts : List Nat := [0, 128, 256, 2048, 16384, 32768, 262144, 16512, 16640, 33024, 34816, 262272, 264192]
def g : ShortGrid := [(0,[(128,309489732259886631936327937), (256,79538861190790864407636279553), (2048,238307093840112706590972510721), (16384,1), (16512,256), (16640,0), (32768,158458742917061955551399903233), (33024,8590000384), (34816,8589935104), (262144,316917485834123911102799806465), (262272,17179934720), (264192,17180001024)]), (128,[(256,8623554560), (2048,12918521856), (16384,1099511627776), (16640,0), (32768,8590000128), (33024,8590000128), (34816,8590000128), (262144,17179934720), (264192,17179934720)]), (256,[(2048,21525233920), (16384,282574488338432), (16512,256), (32768,8590000384), (34816,8590000384), (262144,17179934976), (262272,65536), (264192,17179934976)]), (2048,[(16384,848822976643072), (16512,256), (16640,0), (32768,846623953388032), (33024,65792), (262144,17180001024), (262272,65536)]), (16384,[(32768,12901679104), (33024,4311744512), (34816,12901679104), (262144,21491613696), (262272,16777216), (264192,21491613696)]), (16512,[(32768,256), (33024,256), (34816,256), (262144,256), (264192,256)]), (16640,[(32768,0), (34816,0), (262144,0), (262272,0), (264192,0)]), (32768,[(262144,17213424128), (262272,65536), (264192,12918456832)]), (33024,[(262144,65792), (262272,65536), (264192,65792)]), (34816,[(262144,512), (262272,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 313728 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 313728 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 313728 256) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 313728 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 313728 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 313728 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 313728 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 313728 16512) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 313728 16640) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 313728 33024) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 313728 34816) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 313728 262272) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 313728 264192) = true := by decide
theorem full : checkArms 313728 313728 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 256, 2048, 16384, 32768, 262144, 16512, 16640, 33024, 34816, 262272, 264192] : List Nat).all (fun i => parts.all (shortPair g pp nn 313728 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short313728
theorem validBranch313728 : checkArms 313728 313728 [16512, 16640, 33024, 34816, 262272, 264192] [2432, 18432, 32896, 262400, 311296] = true := Short313728.full
end TightRow.Protected.Numeric
