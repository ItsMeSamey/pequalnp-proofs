import NumericEdgeCodes
import NumericGraph077Code01
import Branch522176
import Branch523200
import NumericGraph030
import NumericGraph050
import NumericGraph060
import NumericGraph067
import NumericGraph071
import NumericGraph073
import NumericGraph074
import NumericGraph075
import NumericGraph076
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m935_932 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e935_932 : Edge c935 c932 m935_932 := by
  exact edgeByCodes c935 c932 m935_932 1113232139568363117924883497216 160456047366417794970759539187360738409684730880 (by decide) (by decide) (by decide) (by decide)
def m935_930 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e935_930 : Edge c935 c930 m935_930 := by
  exact edgeByCodes c935 c930 m935_930 4348563045188917321258959104 689153477351402073627474994153441003915060886635838374145 (by decide) (by decide) (by decide) (by decide)
def m935_923 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e935_923 : Edge c935 c923 m935_923 := by
  exact edgeByCodes c935 c923 m935_923 4347344637597886989033668864 689153852963099023037657834560238839593305325161932783873 (by decide) (by decide) (by decide) (by decide)
def m935_910 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 6]
theorem e935_910 : Edge c935 c910 m935_910 := by
  exact edgeByCodes c935 c910 m935_910 1033693278359053169270733275392 160456135161942574902823621947696026419506512896 (by decide) (by decide) (by decide) (by decide)
def m935_889 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e935_889 : Edge c935 c889 m935_889 := by
  exact edgeByCodes c935 c889 m935_889 4348563045188918429394207747 689153852963076634838556564601010793216352736589677461760 (by decide) (by decide) (by decide) (by decide)
def m935_860 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e935_860 : Edge c935 c860 m935_860 := by
  exact edgeByCodes c935 c860 m935_860 1113232139568363117924917051648 2691631626484845092863023670781323353184296042475159808 (by decide) (by decide) (by decide) (by decide)
def m935_726 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 21]
theorem e935_726 : Edge c935 c726 m935_726 := by
  exact edgeByCodes c935 c726 m935_726 1113232139568218437579241029888 2596600411229756014470363102262753243584668174213251081 (by decide) (by decide) (by decide) (by decide)
def m935_603 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 21]
theorem e935_603 : Edge c935 c603 m935_603 := by
  exact edgeByCodes c935 c603 m935_603 1113232130086591983692531499264 2405035534177873115972012592687760198784100723371147520 (by decide) (by decide) (by decide) (by decide)
def m935_367 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 21]
theorem e935_367 : Edge c935 c367 m935_367 := by
  exact edgeByCodes c935 c367 m935_367 3416467015609337987117220096 493087575422004156153567145571346160122383610062563311872 (by decide) (by decide) (by decide) (by decide)
theorem floor935 : Floor c935 13 := by
  apply protectedBranch source c935.P c935.N (decode 490432) 13
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 490432, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 14 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e935_934 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor934 k x net fit)
    · refine ⟨_,goodChild e935_933 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor933 k x net fit)
    · refine ⟨_,goodChild e935_932 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor932 k x net fit)
    · refine ⟨_,goodChild e935_930 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor930 k x net fit)
    · refine ⟨_,goodChild e935_923 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor923 k x net fit)
    · refine ⟨_,goodChild e935_910 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor910 k x net fit)
    · refine ⟨_,goodChild e935_889 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor889 k x net fit)
    · refine ⟨_,goodChild e935_860 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor860 k x net fit)
    · refine ⟨_,goodChild e935_726 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor726 k x net fit)
    · refine ⟨_,goodChild e935_603 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor603 k x net fit)
    · refine ⟨_,goodChild e935_367 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor367 k x net fit)
  · exact pairExcluded 523200 490432 [8256, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 69632, 131136, 133120, 262272, 264192, 266240] [2688, 4544, 4928, 6464, 14592, 23104, 30720, 37056, 53312, 68032, 76032, 84032, 92160, 98496, 136064, 143616, 152064, 168064, 192512, 196992, 229504, 262976, 279104, 303104, 328000, 376896, 393984, 410112, 467200] validBranch523200 (by decide) (by decide) (by decide)


end TightRow.Protected.Numeric
