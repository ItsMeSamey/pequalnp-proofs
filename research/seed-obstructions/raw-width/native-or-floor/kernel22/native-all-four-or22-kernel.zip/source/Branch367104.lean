import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short367104
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [33280, 34816, 66048, 69632, 264192, 266240]
def n : List Nat := [6656, 36864, 67584, 262656, 360448]
def pp := p.map (canonical 367104)
def nn := n.map (canonical 367104)
def parts : List Nat := [0, 512, 2048, 4096, 32768, 65536, 262144, 33280, 34816, 66048, 69632, 264192, 266240]
def g : ShortGrid := [(0,[(512,309489732259886631936327937), (2048,79538861190790864407636279553), (4096,238307093840112706590972510721), (32768,1), (33280,256), (34816,0), (65536,158458742917061955551399903233), (66048,8590000128), (69632,8589935104), (262144,316917485834123911102799806465), (264192,17179934976), (266240,17180001024)]), (512,[(2048,17230266368), (4096,21525233664), (32768,1099511627776), (34816,0), (65536,8590000128), (69632,8590000128), (262144,17179934720), (264192,17179934720), (266240,17179934720)]), (2048,[(4096,12918522112), (32768,282574488338432), (33280,256), (65536,8590000384), (66048,65536), (69632,8590000384), (262144,17179934976), (266240,17179934976)]), (4096,[(32768,848822976643072), (33280,256), (34816,0), (65536,846623953388032), (66048,65536), (262144,17180001024), (264192,65792)]), (32768,[(65536,12901679104), (66048,16777216), (69632,12901679104), (262144,21491613696), (264192,4311744512), (266240,21491613696)]), (33280,[(65536,256), (69632,256), (262144,256), (264192,256), (266240,256)]), (34816,[(65536,0), (66048,0), (69632,0), (262144,0), (266240,0)]), (65536,[(262144,17213424128), (264192,65792), (266240,12918456832)]), (66048,[(262144,65536), (264192,65536), (266240,65536)]), (69632,[(262144,512), (264192,65792)])]
private theorem row0 : parts.all (shortPair g pp nn 367104 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 367104 512) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 367104 2048) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 367104 4096) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 367104 32768) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 367104 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 367104 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 367104 33280) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 367104 34816) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 367104 66048) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 367104 69632) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 367104 264192) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 367104 266240) = true := by decide
theorem full : checkArms 367104 367104 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 512, 2048, 4096, 32768, 65536, 262144, 33280, 34816, 66048, 69632, 264192, 266240] : List Nat).all (fun i => parts.all (shortPair g pp nn 367104 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short367104
theorem validBranch367104 : checkArms 367104 367104 [33280, 34816, 66048, 69632, 264192, 266240] [6656, 36864, 67584, 262656, 360448] = true := Short367104.full
end TightRow.Protected.Numeric
