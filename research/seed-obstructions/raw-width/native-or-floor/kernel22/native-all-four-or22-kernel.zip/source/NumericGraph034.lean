import Branch305792
import NumericGraph001
import NumericGraph032
import NumericGraph033
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c408 : Chart := ⟨[33024, 34816, 262272, 264192],[2432, 32896, 262400, 294912]⟩
def m408_407 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e408_407 : Edge c408 c407 m408_407 := by constructor <;> decide
theorem floor408 : Floor c408 3 := by
  have up := refundEdge e408_407 floor407 262272 262400 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c409 : Chart := ⟨[33280, 34816, 264192],[2560, 32768, 262656, 294912]⟩
def m409_405 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e409_405 : Edge c409 c405 m409_405 := by constructor <;> decide
theorem floor409 : Floor c409 2 := by
  have up := refundEdge e409_405 floor405 33280 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c410 : Chart := ⟨[33280, 34816, 262272, 264192],[2688, 32896, 262656, 294912]⟩
def m410_409 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e410_409 : Edge c410 c409 m410_409 := by constructor <;> decide
theorem floor410 : Floor c410 3 := by
  have up := refundEdge e410_409 floor409 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c411 : Chart := ⟨[34816, 264192, 266240],[6144, 36864, 262144, 294912]⟩
def m411_405 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e411_405 : Edge c411 c405 m411_405 := by constructor <;> decide
theorem floor411 : Floor c411 2 := by
  have up := refundEdge e411_405 floor405 266240 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c412 : Chart := ⟨[33024, 34816, 264192, 266240],[6400, 32768, 36864, 262400, 294912]⟩
def m412_411 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, some 15, none, none, some 18, none, none, none]
private theorem e412_411 : Edge c412 c411 m412_411 := by constructor <;> decide
theorem floor412 : Floor c412 3 := by
  have up := refundEdge e412_411 floor411 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c413 : Chart := ⟨[33280, 34816, 264192, 266240],[6656, 32768, 36864, 262656, 294912]⟩
def m413_411 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, some 15, none, none, some 18, none, none, none]
private theorem e413_411 : Edge c413 c411 m413_411 := by constructor <;> decide
theorem floor413 : Floor c413 3 := by
  have up := refundEdge e413_411 floor411 33280 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c414 : Chart := ⟨[8320, 8704, 33280, 262272],[640, 32896, 262656, 303104]⟩
def m414_389 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e414_389 : Edge c414 c389 m414_389 := by constructor <;> decide
theorem floor414 : Floor c414 3 := by
  have up := refundEdge e414_389 floor389 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c415 : Chart := ⟨[8320, 34816, 262272, 264192],[128, 2176, 10240, 32896, 303104]⟩
def m415_406 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e415_406 : Edge c415 c406 m415_406 := by constructor <;> decide
theorem floor415 : Floor c415 3 := by
  have up := refundEdge e415_406 floor406 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c416 : Chart := ⟨[8320, 33024, 34816, 262272, 264192],[2432, 10496, 32896, 270592, 303104]⟩
def m416_415 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e416_415 : Edge c416 c415 m416_415 := by constructor <;> decide
theorem floor416 : Floor c416 4 := by
  have up := refundEdge e416_415 floor415 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c417 : Chart := ⟨[8196, 8320, 33024, 34816, 262272, 264192],[2436, 8448, 10496, 32900, 262404, 270592, 294916, 303104]⟩
def m417_416 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e417_416 : Edge c417 c416 m417_416 := by constructor <;> decide
theorem floor417 : Floor c417 5 := by
  have up := refundEdge e417_416 floor416 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c418 : Chart := ⟨[8704, 33280, 34816, 264192],[512, 2560, 10240, 262656, 303104]⟩
def m418_409 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e418_409 : Edge c418 c409 m418_409 := by constructor <;> decide
theorem floor418 : Floor c418 3 := by
  have up := refundEdge e418_409 floor409 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c419 : Chart := ⟨[8320, 8704, 33280, 34816, 262272, 264192],[2688, 10240, 32896, 262656, 303104]⟩
def m419_418 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e419_418 : Edge c419 c418 m419_418 := by constructor <;> decide
def m419_415 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e419_415 : Edge c419 c415 m419_415 := by constructor <;> decide
def m419_414 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e419_414 : Edge c419 c414 m419_414 := by constructor <;> decide
def m419_410 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e419_410 : Edge c419 c410 m419_410 := by constructor <;> decide
def m419_392 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e419_392 : Edge c419 c392 m419_392 := by constructor <;> decide
def m419_18 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e419_18 : Edge c419 c18 m419_18 := by constructor <;> decide
theorem floor419 : Floor c419 5 := by
  apply protectedBranch source c419.P c419.N (decode 305792) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 305792, q = 7 ∨ q = 9 ∨ q = 11 ∨ q = 13 ∨ q = 15 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e419_418 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor418 k x net fit)
    · refine ⟨_,goodChild e419_415 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor415 k x net fit)
    · refine ⟨_,goodChild e419_414 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor414 k x net fit)
    · refine ⟨_,goodChild e419_410 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor410 k x net fit)
    · refine ⟨_,goodChild e419_392 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor392 k x net fit)
    · refine ⟨_,goodChild e419_18 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor18 k x net fit)
  · exact pairExcluded 305792 305792 [8320, 8704, 33280, 34816, 262272, 264192] [2688, 10240, 32896, 262656, 303104] validBranch305792 (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
