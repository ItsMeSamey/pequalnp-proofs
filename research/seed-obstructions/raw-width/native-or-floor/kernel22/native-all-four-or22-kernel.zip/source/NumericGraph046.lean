import NumericEdgeCodes
import NumericGraph046Code00
import Branch380544
import Branch380800
import NumericGraph007
import NumericGraph008
import NumericGraph036
import NumericGraph040
import NumericGraph041
import NumericGraph043
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem floor562 : Floor c562 9 := by
  apply protectedBranch source c562.P c562.N (decode 331648) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 331648, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e562_561 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor561 k x net fit)
    · refine ⟨_,goodChild e562_560 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor560 k x net fit)
    · refine ⟨_,goodChild e562_558 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor558 k x net fit)
    · refine ⟨_,goodChild e562_555 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor555 k x net fit)
    · refine ⟨_,goodChild e562_553 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor553 k x net fit)
    · refine ⟨_,goodChild e562_441 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor441 k x net fit)
    · refine ⟨_,goodChild e562_98 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor98 k x net fit)
  · exact pairExcluded 380800 331648 [16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 262272, 264192] [896, 3328, 3712, 18944, 33920, 67968, 83968, 98432, 263936, 279040, 295936, 327936, 376832] validBranch380800 (by decide) (by decide) (by decide)
def c563 : Chart := ⟨[16512, 16640, 33024, 69632, 262272, 266240],[384, 4480, 36992, 53248, 65920, 98432, 327936, 376832]⟩
def m563_492 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e563_492 : Edge c563 c492 m563_492 := by
  exact edgeByCodes c563 c492 m563_492 21542142208 7722418504449 (by decide) (by decide) (by decide) (by decide)
theorem floor563 : Floor c563 5 := by
  have up := refundEdge e563_492 floor492 33024 384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)


end TightRow.Protected.Numeric
