import NumericEdgeCodes
import NumericGraph059Code00
import Branch453056
import Branch454272
import NumericGraph019
import NumericGraph020
import NumericGraph037
import NumericGraph055
import NumericGraph056
import NumericGraph057
import NumericGraph058
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m717_683 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e717_683 : Edge c717 c683 m717_683 := by
  exact edgeByCodes c717 c683 m717_683 650777868590383360 13355019012689715819446528 (by decide) (by decide) (by decide) (by decide)
def m717_666 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e717_666 : Edge c717 c666 m717_666 := by
  exact edgeByCodes c717 c666 m717_666 650777868556697856 14559222465820367196848384 (by decide) (by decide) (by decide) (by decide)
def m717_455 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
theorem e717_455 : Edge c717 c455 m717_455 := by
  exact edgeByCodes c717 c455 m717_455 650775660943507712 47390552476001918648576 (by decide) (by decide) (by decide) (by decide)
def m717_247 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
theorem e717_247 : Edge c717 c247 m717_247 := by
  exact edgeByCodes c717 c247 m717_247 506097522914230528 33168111952945947476224 (by decide) (by decide) (by decide) (by decide)
theorem floor717 : Floor c717 9 := by
  apply protectedBranch source c717.P c717.N (decode 452096) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 452096, q = 9 ∨ q = 10 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e717_713 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor713 k x net fit)
    · refine ⟨_,goodChild e717_709 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor709 k x net fit)
    · refine ⟨_,goodChild e717_698 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor698 k x net fit)
    · refine ⟨_,goodChild e717_683 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor683 k x net fit)
    · refine ⟨_,goodChild e717_666 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor666 k x net fit)
    · refine ⟨_,goodChild e717_455 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor455 k x net fit)
    · refine ⟨_,goodChild e717_247 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor247 k x net fit)
  · exact pairExcluded 454272 452096 [8320, 8704, 16512, 17408, 33280, 34816, 132096, 133120, 262272, 264192] [3712, 11264, 18944, 26624, 33920, 131712, 163968, 188416, 263680, 304128, 311296, 401408, 410112] validBranch454272 (by decide) (by decide) (by decide)
def c718 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 33280, 34816, 131136, 132096, 133120, 262272, 264192],[2240, 3712, 9216, 11264, 19008, 26624, 33984, 131712, 163968, 188416, 263744, 279104, 296000, 304128, 311360, 401408, 410112]⟩
def m718_717 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e718_717 : Edge c718 c717 m718_717 := by
  exact edgeByCodes c718 c717 m718_717 52131149529067959812609 1272309861912906678247094485761 (by decide) (by decide) (by decide) (by decide)
theorem floor718 : Floor c718 10 := by
  have up := refundEdge e718_717 floor717 8256 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c719 : Chart := ⟨[8256, 8704, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120, 264192],[2304, 2368, 3584, 11520, 19008, 26624, 188416, 264000, 271616, 279104, 296000, 304128, 311360, 393984, 401664, 410112]⟩
def m719_251 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
theorem e719_251 : Edge c719 c251 m719_251 := by
  exact edgeByCodes c719 c251 m719_251 42649378395939397566720 480028236807301466389456486663 (by decide) (by decide) (by decide) (by decide)
theorem floor719 : Floor c719 10 := by
  have up := refundEdge e719_251 floor251 264192 2304 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)


end TightRow.Protected.Numeric
