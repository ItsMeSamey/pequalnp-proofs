import NumericEdgeCodes
import NumericGraph079Code01
import Branch524096
import Branch524224
import NumericGraph031
import NumericGraph050
import NumericGraph051
import NumericGraph060
import NumericGraph061
import NumericGraph068
import NumericGraph072
import NumericGraph075
import NumericGraph076
import NumericGraph077
import NumericGraph078
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m950_904 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e950_904 : Edge c950 c904 m950_904 := by
  exact edgeByCodes c950 c904 m950_904 88594757919751255565783926170780675 13214040564763301218730453214117730228810711858048966531928424704 (by decide) (by decide) (by decide) (by decide)
def m950_871 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e950_871 : Edge c950 c871 m950_871 := by
  exact edgeByCodes c950 c871 m950_871 88594757919751255565783926170583296 13212427325001595755114170297946906154237519869917855652480418048 (by decide) (by decide) (by decide) (by decide)
def m950_824 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e950_824 : Edge c950 c824 m950_824 := by
  exact edgeByCodes c950 c824 m950_824 88594757919751255565780614700466432 13214040564762925612787270631349674267822106412692443406488699136 (by decide) (by decide) (by decide) (by decide)
def m950_732 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 21]
theorem e950_732 : Edge c950 c732 m950_732 := by
  exact edgeByCodes c950 c732 m950_732 88594757919751200008531186527895808 12804271363381477732894600567517591024695957291228978626139586571 (by decide) (by decide) (by decide) (by decide)
def m950_614 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 21]
theorem e950_614 : Edge c950 c614 m950_614 := by
  exact edgeByCodes c950 c614 m950_614 88594756987655225986203483893793024 11981506481381390047634049607192668976753449675665121981971431680 (by decide) (by decide) (by decide) (by decide)
def m950_381 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 21]
theorem e950_381 : Edge c950 c381 m950_381 := by
  exact edgeByCodes c950 c381 m950_381 72956781498752245296327372520423680 9101829394044535109892932372089939411172285792828331966452531223 (by decide) (by decide) (by decide) (by decide)
theorem floor950 : Floor c950 15 := by
  apply protectedBranch source c950.P c950.N (decode 524224) 15
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 524224, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e950_949 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor949 k x net fit)
    · refine ⟨_,goodChild e950_948 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor948 k x net fit)
    · refine ⟨_,goodChild e950_946 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor946 k x net fit)
    · refine ⟨_,goodChild e950_942 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor942 k x net fit)
    · refine ⟨_,goodChild e950_935 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor935 k x net fit)
    · refine ⟨_,goodChild e950_929 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor929 k x net fit)
    · refine ⟨_,goodChild e950_921 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor921 k x net fit)
    · refine ⟨_,goodChild e950_904 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor904 k x net fit)
    · refine ⟨_,goodChild e950_871 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor871 k x net fit)
    · refine ⟨_,goodChild e950_824 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor824 k x net fit)
    · refine ⟨_,goodChild e950_732 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor732 k x net fit)
    · refine ⟨_,goodChild e950_614 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor614 k x net fit)
    · refine ⟨_,goodChild e950_381 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 15-2 ≤ 13).trans (floor381 k x net fit)
  · exact pairExcluded 524224 524224 [8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 131136, 132096, 133120, 262272, 264192, 266240] [3712, 4544, 4928, 5440, 6464, 15616, 23104, 30720, 38080, 46080, 53312, 68032, 76032, 84032, 92160, 98496, 136064, 143616, 152064, 168064, 192512, 196992, 229504, 264000, 271616, 279104, 296000, 304128, 328000, 376896, 393984, 410112, 467200] validBranch524224 (by decide) (by decide) (by decide)
def c951 : Chart := ⟨[8196, 2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3204, 3332, 3588, 3712, 2101696, 2102080, 2102592, 2103616, 2104324, 9472, 2112768, 2119748, 2120196, 2120256, 2127872, 2135108, 2135172, 2135232, 2143232, 2150468, 2165060, 67972, 2165184, 76032, 2181188, 92160, 2195648, 2233216, 2240768, 2249220, 2265220, 2281476, 2289664, 196996, 229508, 2360644, 263940, 2361152, 271616, 2376256, 2393156, 304128, 2425156, 2474052, 393988, 410116, 459012, 467200]⟩
def m951_950 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e951_950 : Edge c951 c950 m951_950 := by
  exact edgeByCodes c951 c950 m951_950 1573827292826713257923989406431116200706561 5462660311522703415223715433844713044053905599465001568490355597483120020227075 (by decide) (by decide) (by decide) (by decide)
theorem floor951 : Floor c951 16 := by
  have up := refundEdge e951_950 floor950 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 16 ≤ 16).trans (up k x net fit)
def c952 : Chart := ⟨[8196, 2105408, 1056896, 8704, 1065088, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 1179649, 2228288, 132096, 133120, 1310848, 264192, 2363392],[1049473, 1050241, 1051265, 1051780, 3332, 3588, 1052288, 3150272, 3150465, 2102080, 2102592, 2103616, 2104324, 2112768, 1067525, 3166785, 2119748, 3168769, 2120196, 2120256, 3176449, 1082501, 3182785, 2135108, 3183745, 3183748, 3183808, 3191809, 3199041, 2150468, 3207169, 3211713, 1116293, 2165060, 1116545, 1116548, 3213760, 1124609, 1132549, 2181188, 1140737, 1147013, 3244225, 1180032, 3281792, 2240768, 2249220, 3313796, 2281476, 2289664, 1245572, 1278084, 3408705, 2360644, 1312261, 1312513, 263940, 2361152, 1320193, 1327621, 3424833, 1344517, 2393156, 1352705, 3473729, 2425156, 1384705, 3522629, 393988, 410116, 459012, 467200]⟩

end TightRow.Protected.Numeric
