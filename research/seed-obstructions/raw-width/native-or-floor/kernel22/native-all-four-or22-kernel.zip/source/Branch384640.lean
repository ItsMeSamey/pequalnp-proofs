import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short384640
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16512, 17408, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240]
def n : List Nat := [3712, 4736, 7168, 23040, 38016, 53248, 67712, 83968, 98432, 263680, 279040, 295936, 376832]
def pp := p.map (canonical 384640)
def nn := n.map (canonical 384640)
def parts : List Nat := [0, 128, 512, 1024, 2048, 4096, 16384, 32768, 16512, 17408, 33280, 34816]
def g : ShortGrid := [(0,[(128,10282049269874637845735769834344147478670756283137), (512,2985847733561617514779107619327656470491768685569), (1024,1518614717260799892127165987304318303376588735233), (2048,11743573208291037258894517478484486589515238147073), (4096,13205097146707436611205107842473323003396422501889), (16384,1512905639376334930966461749572491398009195593729), (16512,256), (17408,0), (32768,2974429577792734323842490300310453172721508548609), (33280,8589935360), (34816,8589935104)]), (128,[(512,8657240064), (1024,21575696384), (2048,12952207360), (4096,25870663680), (16384,3298534883328), (17408,0), (32768,8590131200), (33280,8590131200), (34816,8590131200)]), (512,[(1024,567348000129280), (2048,34510995968), (4096,38805963264), (16384,568447511560192), (16512,256), (17408,0), (32768,567356589867520), (34816,8589935104)]), (1024,[(2048,12952207616), (4096,38805897472), (16384,284773511593984), (16512,256), (32768,8590131456), (33280,8590131456), (34816,8590131456)]), (2048,[(4096,25870729984), (16384,849922488270848), (16512,256), (17408,0), (32768,848822976643584), (33280,8589935360)]), (4096,[(16384,1696546441658368), (16512,256), (17408,0), (32768,1697645953286656), (33280,768), (34816,512)]), (16384,[(32768,8640266240), (33280,8640266240), (34816,8640266240)]), (16512,[(32768,256), (33280,256), (34816,256)]), (17408,[(32768,0), (33280,0), (34816,0)])]
private theorem row0 : parts.all (shortPair g pp nn 56960 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 56960 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 56960 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 56960 1024) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 56960 2048) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 56960 4096) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 56960 16384) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 56960 32768) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 56960 16512) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 56960 17408) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 56960 33280) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 56960 34816) = true := by decide
theorem full : checkArms 384640 56960 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 512, 1024, 2048, 4096, 16384, 32768, 16512, 17408, 33280, 34816] : List Nat).all (fun i => parts.all (shortPair g pp nn 56960 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short384640
theorem validBranch384640 : checkArms 384640 56960 [16512, 17408, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240] [3712, 4736, 7168, 23040, 38016, 53248, 67712, 83968, 98432, 263680, 279040, 295936, 376832] = true := Short384640.full
end TightRow.Protected.Numeric
