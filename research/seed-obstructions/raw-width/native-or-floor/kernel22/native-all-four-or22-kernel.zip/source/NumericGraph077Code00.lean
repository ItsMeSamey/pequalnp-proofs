import NumericEdgeCodes
import Branch522176
import Branch523200
import NumericGraph030
import NumericGraph050
import NumericGraph060
import NumericGraph067
import NumericGraph071
import NumericGraph073
import NumericGraph074
import NumericGraph075
import NumericGraph076
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c924 : Chart := ⟨[2105408, 8320, 16512, 16640, 17408, 33024, 66560, 2166784, 2228288, 132096, 262272, 2363392],[384, 2101696, 2102592, 2110720, 2135232, 2143232, 2150464, 2163136, 90112, 2195648, 2232704, 2240768, 2265216, 2289664, 196992, 229504, 2360640, 271616, 2393152, 304128, 2425152, 2474048, 409600, 467200]⟩
def m924_811 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, none, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e924_811 : Edge c924 c811 m924_811 := by
  exact edgeByCodes c924 c811 m924_811 13345574279723972200366336 2011096806482667935419038338099687217824769 (by decide) (by decide) (by decide) (by decide)
theorem floor924 : Floor c924 11 := by
  have up := refundEdge e924_811 floor811 33024 384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c925 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 66048, 66560, 69632, 132096, 262272, 266240],[640, 1664, 38016, 46080, 90112, 135808, 152064, 168064, 192512, 229504, 263680, 304128, 376832, 410112, 466944]⟩
def m925_812 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e925_812 : Edge c925 c812 m925_812 := by
  exact edgeByCodes c925 c812 m925_812 47390263963055573565696 1113232139568363116821093745153 (by decide) (by decide) (by decide) (by decide)
theorem floor925 : Floor c925 10 := by
  have up := refundEdge e925_812 floor812 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c926 : Chart := ⟨[2105408, 8320, 8704, 16512, 17408, 33280, 66048, 66560, 2166784, 2228288, 132096, 262272, 2363392],[1664, 2110464, 2118208, 2135232, 2143232, 2150464, 90112, 2195648, 2232960, 2249216, 2265216, 2289664, 229504, 2360896, 2376256, 2393152, 304128, 2474048, 410112, 466944]⟩
def m926_925 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e926_925 : Edge c926 c925 m926_925 := by
  exact edgeByCodes c926 c925 m926_925 14559240912565549041648129 99020075531323262335058133540601856 (by decide) (by decide) (by decide) (by decide)
theorem floor926 : Floor c926 11 := by
  have up := refundEdge e926_925 floor925 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c927 : Chart := ⟨[2105408, 8704, 16640, 17408, 33024, 33280, 66048, 66560, 2166784, 2228288, 132096, 2363392],[2101568, 2102080, 2102592, 2110720, 2118208, 2135104, 2143232, 2150464, 90112, 2233088, 2240768, 2249216, 2289664, 229376, 2361152, 271616, 2376256, 2393152, 304128, 2425152, 2474048, 393984, 410112, 467200]⟩
def m927_364 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 21]
theorem e927_364 : Edge c927 c364 m927_364 := by
  exact edgeByCodes c927 c364 m927_364 12131907574542231144628480 4454305545339152355077928360393163538702 (by decide) (by decide) (by decide) (by decide)
theorem floor927 : Floor c927 11 := by
  have up := refundEdge e927_364 floor364 2363392 2101568 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c928 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632, 132096, 262272, 266240],[1664, 13568, 16896, 38016, 46080, 90112, 136064, 143616, 152064, 168064, 192512, 196992, 229504, 263936, 271616, 304128, 376832, 393984, 410112, 467200]⟩
def m928_925 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e928_925 : Edge c928 c925 m928_925 := by
  exact edgeByCodes c928 c925 m928_925 14559240984905721862816000 99019995993675719730290125229457408 (by decide) (by decide) (by decide) (by decide)
theorem floor928 : Floor c928 11 := by
  have up := refundEdge e928_925 floor925 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c929 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 2166784, 2228288, 132096, 262272, 2363392],[1664, 2101696, 2102080, 2102592, 2110720, 2118208, 2135232, 2143232, 2150464, 2163136, 90112, 2195648, 2233216, 2240768, 2249216, 2265216, 2289664, 196992, 229504, 2361152, 271616, 2376256, 2393152, 304128, 2425152, 2474048, 393984, 410112, 467200]⟩
def m929_928 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e929_928 : Edge c929 c928 m929_928 := by
  exact edgeByCodes c929 c928 m929_928 1113232134827477550808724341249 160456135160597708930617707120080014432771834880 (by decide) (by decide) (by decide) (by decide)
def m929_927 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e929_927 : Edge c929 c927 m929_927 := by
  exact edgeByCodes c929 c927 m929_927 4347349378483736684026659328 689153852963099023037657834480389279707397074678435742209 (by decide) (by decide) (by decide) (by decide)
def m929_926 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e929_926 : Edge c929 c926 m929_926 := by
  exact edgeByCodes c929 c926 m929_926 1113232139568363117920588529920 160456047366423007629257053829110409420605817856 (by decide) (by decide) (by decide) (by decide)
def m929_924 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e929_924 : Edge c929 c924 m929_924 := by
  exact edgeByCodes c929 c924 m929_924 4348563045188916221747331328 689153477351446762571780007393997401975437211271885422849 (by decide) (by decide) (by decide) (by decide)
def m929_923 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e929_923 : Edge c929 c923 m929_923 := by
  exact edgeByCodes c929 c923 m929_923 4348558304231011136051478784 689153852963098935242138287648931434956669921096045297921 (by decide) (by decide) (by decide) (by decide)
def m929_907 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 6]
theorem e929_907 : Edge c929 c907 m929_907 := by
  exact edgeByCodes c929 c907 m929_907 1033693273636686686401088061696 160456135161942574902823622003252431422749017088 (by decide) (by decide) (by decide) (by decide)
def m929_886 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e929_886 : Edge c929 c886 m929_886 := by
  exact edgeByCodes c929 c886 m929_886 4348563045188918429394207747 689153852963076634496939757025788690312505316832998195456 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
