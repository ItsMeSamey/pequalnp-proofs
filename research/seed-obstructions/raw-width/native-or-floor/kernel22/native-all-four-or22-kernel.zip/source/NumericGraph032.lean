import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c384 : Chart := ⟨[262272],[128, 262144]⟩
theorem floor384 : Floor c384 0 := fun _ _ _ _ => Nat.zero_le _
def c385 : Chart := ⟨[264192],[2048, 262144]⟩
theorem floor385 : Floor c385 0 := fun _ _ _ _ => Nat.zero_le _
def c386 : Chart := ⟨[266240],[4096, 262144]⟩
theorem floor386 : Floor c386 0 := fun _ _ _ _ => Nat.zero_le _
def c387 : Chart := ⟨[8320, 262272],[128, 270336]⟩
def m387_384 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, none, none, none, none, none, some 18, none, none, none]
private theorem e387_384 : Edge c387 c384 m387_384 := by constructor <;> decide
theorem floor387 : Floor c387 1 := by
  have up := refundEdge e387_384 floor384 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c388 : Chart := ⟨[8256, 8320, 262272],[192, 8192, 262208, 270336]⟩
def m388_387 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e388_387 : Edge c388 c387 m388_387 := by constructor <;> decide
theorem floor388 : Floor c388 2 := by
  have up := refundEdge e388_387 floor387 8256 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c389 : Chart := ⟨[8320, 8704, 262272],[640, 8192, 262656, 270336]⟩
def m389_387 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e389_387 : Edge c389 c387 m389_387 := by constructor <;> decide
theorem floor389 : Floor c389 2 := by
  have up := refundEdge e389_387 floor387 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c390 : Chart := ⟨[8320, 262272, 264192],[2176, 10240, 262144, 270336]⟩
def m390_387 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e390_387 : Edge c390 c387 m390_387 := by constructor <;> decide
theorem floor390 : Floor c390 2 := by
  have up := refundEdge e390_387 floor387 264192 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c391 : Chart := ⟨[8256, 8320, 262272, 264192],[2240, 8192, 10240, 262208, 270336]⟩
def m391_390 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e391_390 : Edge c391 c390 m391_390 := by constructor <;> decide
theorem floor391 : Floor c391 3 := by
  have up := refundEdge e391_390 floor390 8256 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c392 : Chart := ⟨[8320, 8704, 262272, 264192],[2688, 8192, 10240, 262656, 270336]⟩
def m392_390 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e392_390 : Edge c392 c390 m392_390 := by constructor <;> decide
theorem floor392 : Floor c392 3 := by
  have up := refundEdge e392_390 floor390 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c393 : Chart := ⟨[8320, 262272, 266240],[4224, 12288, 262144, 270336]⟩
def m393_387 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e393_387 : Edge c393 c387 m393_387 := by constructor <;> decide
theorem floor393 : Floor c393 2 := by
  have up := refundEdge e393_387 floor387 266240 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c394 : Chart := ⟨[8196, 8320, 262272, 266240],[4228, 8192, 12288, 262148, 270336]⟩
def m394_393 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, some 13, none, none, none, none, some 18, none, none, none]
private theorem e394_393 : Edge c394 c393 m394_393 := by constructor <;> decide
theorem floor394 : Floor c394 3 := by
  have up := refundEdge e394_393 floor393 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c395 : Chart := ⟨[8320, 8704, 262272, 266240],[4736, 8192, 12288, 262656, 270336]⟩
def m395_393 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, some 13, none, none, none, none, some 18, none, none, none]
private theorem e395_393 : Edge c395 c393 m395_393 := by constructor <;> decide
theorem floor395 : Floor c395 3 := by
  have up := refundEdge e395_393 floor393 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)

end TightRow.Protected.Numeric
