import Branch367104
import NumericGraph007
import NumericGraph034
import NumericGraph039
import NumericGraph043
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c528 : Chart := ⟨[33024, 34816, 69632, 264192, 266240],[6400, 32768, 36864, 67840, 327936, 360448]⟩
def m528_527 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e528_527 : Edge c528 c527 m528_527 := by constructor <;> decide
theorem floor528 : Floor c528 4 := by
  have up := refundEdge e528_527 floor527 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c529 : Chart := ⟨[33280, 34816, 66048, 69632, 264192, 266240],[6656, 36864, 67584, 262656, 360448]⟩
def m529_527 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e529_527 : Edge c529 c527 m529_527 := by constructor <;> decide
def m529_523 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e529_523 : Edge c529 c523 m529_523 := by constructor <;> decide
def m529_519 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e529_519 : Edge c529 c519 m529_519 := by constructor <;> decide
def m529_469 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e529_469 : Edge c529 c469 m529_469 := by constructor <;> decide
def m529_413 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, none, none, some 18, none, none, none]
private theorem e529_413 : Edge c529 c413 m529_413 := by constructor <;> decide
def m529_89 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, none, none, none, none, none]
private theorem e529_89 : Edge c529 c89 m529_89 := by constructor <;> decide
theorem floor529 : Floor c529 5 := by
  apply protectedBranch source c529.P c529.N (decode 367104) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 367104, q = 9 ∨ q = 11 ∨ q = 12 ∨ q = 15 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e529_527 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor527 k x net fit)
    · refine ⟨_,goodChild e529_523 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor523 k x net fit)
    · refine ⟨_,goodChild e529_519 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor519 k x net fit)
    · refine ⟨_,goodChild e529_469 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor469 k x net fit)
    · refine ⟨_,goodChild e529_413 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor413 k x net fit)
    · refine ⟨_,goodChild e529_89 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor89 k x net fit)
  · exact pairExcluded 367104 367104 [33280, 34816, 66048, 69632, 264192, 266240] [6656, 36864, 67584, 262656, 360448] validBranch367104 (by decide) (by decide) (by decide)
def c530 : Chart := ⟨[33280, 34816, 66048, 69632, 262272, 264192, 266240],[2688, 4736, 6656, 36992, 67712, 98432, 262656, 360448]⟩
def m530_529 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e530_529 : Edge c530 c529 m530_529 := by constructor <;> decide
theorem floor530 : Floor c530 6 := by
  have up := refundEdge e530_529 floor529 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c531 : Chart := ⟨[33024, 33280, 34816, 66048, 69632, 264192, 266240],[4864, 6400, 6656, 32768, 36864, 67840, 262912, 327936, 360448]⟩
def m531_529 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e531_529 : Edge c531 c529 m531_529 := by constructor <;> decide
theorem floor531 : Floor c531 6 := by
  have up := refundEdge e531_529 floor529 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c532 : Chart := ⟨[33024, 33280, 34816, 66048, 69632, 262272, 264192, 266240],[2688, 4992, 6400, 6656, 36992, 67968, 98432, 262912, 327936, 360448]⟩
def m532_531 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e532_531 : Edge c532 c531 m532_531 := by constructor <;> decide
theorem floor532 : Floor c532 7 := by
  have up := refundEdge e532_531 floor531 262272 262912 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c533 : Chart := ⟨[34816, 66560, 69632, 264192, 266240],[7168, 37888, 65536, 67584, 295936, 360448]⟩
def m533_527 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e533_527 : Edge c533 c527 m533_527 := by constructor <;> decide
theorem floor533 : Floor c533 4 := by
  have up := refundEdge e533_527 floor527 66560 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c534 : Chart := ⟨[33024, 34816, 66560, 69632, 264192, 266240],[7424, 33792, 37888, 67840, 263424, 295936, 327936, 360448]⟩
def m534_533 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e534_533 : Edge c534 c533 m534_533 := by constructor <;> decide
theorem floor534 : Floor c534 5 := by
  have up := refundEdge e534_533 floor533 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c535 : Chart := ⟨[33280, 34816, 66048, 66560, 69632, 264192, 266240],[3584, 6656, 7168, 37888, 65536, 67584, 263680, 295936, 360448]⟩
def m535_529 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e535_529 : Edge c535 c529 m535_529 := by constructor <;> decide
theorem floor535 : Floor c535 6 := by
  have up := refundEdge e535_529 floor529 66560 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c536 : Chart := ⟨[33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4736, 6656, 7168, 38016, 67712, 98432, 262656, 263680, 295936, 360448]⟩
def m536_535 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e536_535 : Edge c536 c535 m536_535 := by constructor <;> decide
theorem floor536 : Floor c536 7 := by
  have up := refundEdge e536_535 floor535 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c537 : Chart := ⟨[33024, 33280, 34816, 66048, 66560, 69632, 264192, 266240],[3584, 4864, 6656, 7424, 33792, 37888, 67840, 263936, 295936, 327936, 360448]⟩
def m537_535 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e537_535 : Edge c537 c535 m537_535 := by constructor <;> decide
theorem floor537 : Floor c537 7 := by
  have up := refundEdge e537_535 floor535 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c538 : Chart := ⟨[8320, 8704, 33280, 34816, 66048, 262272, 264192],[640, 2688, 67712, 75776, 98432, 262656, 303104, 335872, 360448]⟩
def m538_419 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e538_419 : Edge c538 c419 m538_419 := by constructor <;> decide
theorem floor538 : Floor c538 6 := by
  have up := refundEdge e538_419 floor419 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c539 : Chart := ⟨[8320, 8704, 33280, 34816, 66048, 66560, 262272, 264192],[3712, 11264, 33920, 65664, 67712, 75776, 98432, 263680, 304128, 335872, 360448]⟩
def m539_538 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, some 16, none, some 18, none, none, none]
private theorem e539_538 : Edge c539 c538 m539_538 := by constructor <;> decide
theorem floor539 : Floor c539 7 := by
  have up := refundEdge e539_538 floor538 66560 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)

end TightRow.Protected.Numeric
