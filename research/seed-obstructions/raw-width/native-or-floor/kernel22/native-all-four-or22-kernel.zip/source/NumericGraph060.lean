import NumericEdgeCodes
import NumericGraph060Code00
import Branch454592
import NumericGraph021
import NumericGraph038
import NumericGraph055
import NumericGraph057
import NumericGraph058
import NumericGraph059
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m724_723 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 21]
theorem e724_723 : Edge c724 c723 m724_723 := by
  exact edgeByCodes c724 c723 m724_723 13345574279723976512176641 7514224880247661966454189211475186549506 (by decide) (by decide) (by decide) (by decide)
theorem floor724 : Floor c724 11 := by
  have up := refundEdge e724_723 floor723 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c725 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 34816, 133120, 262272, 264192, 266240],[2432, 2688, 14592, 23040, 30720, 136064, 143616, 152064, 168064, 192512, 262912, 303104, 311296, 393984, 401664, 410112]⟩
def m725_710 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e725_710 : Edge c725 c710 m725_710 := by
  exact edgeByCodes c725 c710 m725_710 42649378395939397566720 1192771000759081639952068509952 (by decide) (by decide) (by decide) (by decide)
theorem floor725 : Floor c725 10 := by
  have up := refundEdge e725_710 floor710 266240 262912 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c726 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 2228288, 133120, 262272, 264192, 2363392],[2099648, 2688, 2101696, 2102080, 2103616, 2109440, 2111744, 2120256, 2127872, 2134208, 2150464, 2233216, 2240768, 2249216, 2265216, 2289664, 2360128, 2376256, 303104, 2408512, 393984, 401664, 410112]⟩
def m726_725 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 12]
theorem e726_725 : Edge c726 c725 m726_725 := by
  exact edgeByCodes c726 c725 m726_725 14559240984623143079576065 29352461300414685473103632903214334208 (by decide) (by decide) (by decide) (by decide)
theorem floor726 : Floor c726 11 := by
  have up := refundEdge e726_725 floor725 2105408 2109440 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c727 : Chart := ⟨[8320, 16512, 16640, 17408, 33024, 34816, 132096, 133120, 262272, 264192, 266240],[2432, 3200, 15616, 30720, 38016, 46080, 135552, 143616, 168064, 192512, 262400, 271616, 304128, 311296, 401664, 409600]⟩
def m727_714 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e727_714 : Edge c727 c714 m727_714 := by
  exact edgeByCodes c727 c714 m727_714 42649378395939397566720 305349376194324900109204515258368 (by decide) (by decide) (by decide) (by decide)
theorem floor727 : Floor c727 10 := by
  have up := refundEdge e727_714 floor714 266240 262400 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c728 : Chart := ⟨[2105408, 8320, 16512, 16640, 17408, 33024, 34816, 2228288, 132096, 133120, 262272, 264192, 2363392],[2099648, 3200, 2101696, 2102592, 2103616, 2110464, 2112768, 2119744, 2127872, 2135232, 2143232, 2150464, 2232704, 2240768, 2265216, 2289664, 2360640, 271616, 2393152, 304128, 2408512, 401664, 409600]⟩
def m728_727 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 12]
theorem e728_727 : Edge c728 c727 m728_727 := by
  exact edgeByCodes c728 c727 m728_727 14559240984904618056286721 29352461300105200463282286739289669888 (by decide) (by decide) (by decide) (by decide)
theorem floor728 : Floor c728 11 := by
  have up := refundEdge e728_727 floor727 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c729 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 132096, 133120, 262272, 264192, 266240],[3712, 15360, 23040, 30720, 38016, 46080, 135808, 152064, 168064, 192512, 262656, 263680, 304128, 311296, 401408, 410112]⟩
def m729_717 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e729_717 : Edge c729 c717 m729_717 := by
  exact edgeByCodes c729 c717 m729_717 42649378395939397566720 1192771000759081641051580137728 (by decide) (by decide) (by decide) (by decide)
theorem floor729 : Floor c729 10 := by
  have up := refundEdge e729_717 floor717 266240 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c730 : Chart := ⟨[2105408, 8704, 16640, 17408, 33024, 33280, 34816, 2228288, 132096, 133120, 264192, 2363392],[3584, 2102080, 2102592, 2103616, 2112768, 2120256, 2127872, 2135104, 2143232, 2150464, 2233088, 2240768, 2249216, 2289664, 2360128, 2361152, 271616, 2376256, 2393152, 304128, 2408512, 393984, 401664, 410112]⟩
def m730_719 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, some 6]
theorem e730_719 : Edge c730 c719 m730_719 := by
  exact edgeByCodes c730 c719 m730_719 12131907574542231144628480 30686901955007814682802151366961660675 (by decide) (by decide) (by decide) (by decide)
theorem floor730 : Floor c730 11 := by
  have up := refundEdge e730_719 floor719 2363392 2360128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c731 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 132096, 133120, 262272, 264192, 266240],[2432, 3712, 15616, 18944, 23040, 30720, 38016, 46080, 136064, 143616, 152064, 168064, 192512, 263936, 271616, 304128, 311296, 393984, 401664, 410112]⟩
def m731_729 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e731_729 : Edge c731 c729 m731_729 := by
  exact edgeByCodes c731 c729 m731_729 14559240984905721862816000 25349118974382202658545020920301617665 (by decide) (by decide) (by decide) (by decide)
theorem floor731 : Floor c731 11 := by
  have up := refundEdge e731_729 floor729 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)


end TightRow.Protected.Numeric
