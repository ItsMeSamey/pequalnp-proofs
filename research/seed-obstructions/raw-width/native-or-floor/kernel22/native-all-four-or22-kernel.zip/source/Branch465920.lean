import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short465920
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [66560, 69632, 132096, 133120, 264192, 266240]
def n : List Nat := [7168, 67584, 135168, 263168, 458752]
def pp := p.map (canonical 465920)
def nn := n.map (canonical 465920)
def parts : List Nat := [0, 1024, 2048, 4096, 65536, 131072, 262144, 66560, 69632, 132096, 133120, 264192, 266240]
def g : ShortGrid := [(0,[(1024,309489732259886631936327937), (2048,238307093840112706590972510721), (4096,79538861190790864407636279553), (65536,1), (66560,256), (69632,0), (131072,158458742917061955551399903233), (132096,8590000128), (133120,8589935104), (262144,316917485834123911102799806465), (264192,17180001024), (266240,17179934976)]), (1024,[(2048,17230266368), (4096,21525233664), (65536,1099511627776), (69632,0), (131072,8590000128), (133120,8590000128), (262144,17179934720), (264192,17179934720), (266240,17179934720)]), (2048,[(4096,846623953453312), (65536,848822976643072), (66560,256), (69632,0), (131072,846623953388032), (132096,65536), (262144,17180001024), (266240,65792)]), (4096,[(65536,282574488338432), (66560,256), (131072,8590000384), (132096,65536), (133120,8590000384), (262144,17179934976), (264192,17179934976)]), (65536,[(131072,12901679104), (132096,16777216), (133120,12901679104), (262144,17196646400), (264192,17196646400), (266240,4311744512)]), (66560,[(131072,256), (133120,256), (262144,256), (264192,256), (266240,256)]), (69632,[(131072,0), (132096,0), (133120,0), (262144,0), (264192,0)]), (131072,[(262144,21508391424), (264192,12918456832), (266240,65792)]), (132096,[(262144,65536), (264192,65536), (266240,65536)]), (133120,[(262144,512), (266240,65792)])]
private theorem row0 : parts.all (shortPair g pp nn 465920 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 465920 1024) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 465920 2048) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 465920 4096) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 465920 65536) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 465920 131072) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 465920 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 465920 66560) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 465920 69632) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 465920 132096) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 465920 133120) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 465920 264192) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 465920 266240) = true := by decide
theorem full : checkArms 465920 465920 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 1024, 2048, 4096, 65536, 131072, 262144, 66560, 69632, 132096, 133120, 264192, 266240] : List Nat).all (fun i => parts.all (shortPair g pp nn 465920 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short465920
theorem validBranch465920 : checkArms 465920 465920 [66560, 69632, 132096, 133120, 264192, 266240] [7168, 67584, 135168, 263168, 458752] = true := Short465920.full
end TightRow.Protected.Numeric
