import NumericEdgeCodes
import Branch445824
import NumericGraph017
import NumericGraph019
import NumericGraph036
import NumericGraph054
import NumericGraph056
import NumericGraph057
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c696 : Chart := ⟨[16640, 17408, 33024, 34816, 132096, 133120, 264192],[2304, 3328, 18432, 180224, 263424, 295936, 311296, 393472, 409600]⟩
def m696_207 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
theorem e696_207 : Edge c696 c207 m696_207 := by
  exact edgeByCodes c696 c207 m696_207 5514788471040 13002670593 (by decide) (by decide) (by decide) (by decide)
theorem floor696 : Floor c696 6 := by
  have up := refundEdge e696_207 floor207 264192 2304 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c697 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 132096, 133120, 262272, 264192],[2432, 3200, 3328, 18432, 33920, 131456, 163968, 180224, 263424, 295936, 311296, 393472, 409600]⟩
def m697_696 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e697_696 : Edge c697 c696 m697_696 := by
  exact edgeByCodes c697 c696 m697_696 2258418425594369 222156387098780959232 (by decide) (by decide) (by decide) (by decide)
def m697_695 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e697_695 : Edge c697 c695 m697_695 := by
  exact edgeByCodes c697 c695 m697_695 2259522249032192 222084045822102798592 (by decide) (by decide) (by decide) (by decide)
def m697_692 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e697_692 : Edge c697 c692 m697_692 := by
  exact edgeByCodes c697 c692 m697_692 2259522232189184 867798378480993024 (by decide) (by decide) (by decide) (by decide)
def m697_652 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
theorem e697_652 : Edge c697 c652 m697_652 := by
  exact edgeByCodes c697 c652 m697_652 2259522248900864 867796170817274112 (by decide) (by decide) (by decide) (by decide)
def m697_439 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e697_439 : Edge c697 c439 m697_439 := by
  exact edgeByCodes c697 c439 m697_439 2259513625411840 723118028493029632 (by decide) (by decide) (by decide) (by decide)
def m697_210 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
theorem e697_210 : Edge c697 c210 m697_210 := by
  exact edgeByCodes c697 c210 m697_210 1694364648734976 506097522914230528 (by decide) (by decide) (by decide) (by decide)
theorem floor697 : Floor c697 8 := by
  apply protectedBranch source c697.P c697.N (decode 427392) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 427392, q = 7 ∨ q = 8 ∨ q = 10 ∨ q = 15 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e697_696 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor696 k x net fit)
    · refine ⟨_,goodChild e697_695 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor695 k x net fit)
    · refine ⟨_,goodChild e697_692 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor692 k x net fit)
    · refine ⟨_,goodChild e697_652 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor652 k x net fit)
    · refine ⟨_,goodChild e697_439 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor439 k x net fit)
    · refine ⟨_,goodChild e697_210 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor210 k x net fit)
  · exact pairExcluded 445824 427392 [16512, 16640, 17408, 33024, 34816, 132096, 133120, 262272, 264192] [2432, 3200, 3328, 18432, 33920, 131456, 163968, 180224, 263424, 295936, 311296, 393472, 409600] validBranch445824 (by decide) (by decide) (by decide)
def c698 : Chart := ⟨[16512, 17408, 33280, 34816, 132096, 133120, 262272, 264192],[3712, 18944, 33920, 131712, 163968, 180224, 263680, 295936, 311296, 410112]⟩
def m698_695 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e698_695 : Edge c698 c695 m698_695 := by
  exact edgeByCodes c698 c695 m698_695 1976943448883456 166599133255297990656 (by decide) (by decide) (by decide) (by decide)
theorem floor698 : Floor c698 7 := by
  have up := refundEdge e698_695 floor695 33280 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c699 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 132096, 133120, 262272, 264192],[2432, 3328, 3712, 18944, 33920, 131968, 163968, 180224, 263936, 295936, 311296, 393984, 410112]⟩
def m699_697 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e699_697 : Edge c699 c697 m699_697 := by
  exact edgeByCodes c699 c697 m699_697 166599134359121428736 954154417186781389109644558848 (by decide) (by decide) (by decide) (by decide)
theorem floor699 : Floor c699 9 := by
  have up := refundEdge e699_697 floor697 33280 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c700 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120, 262272, 264192],[2496, 3328, 3712, 19008, 33984, 131456, 131968, 163968, 180224, 264000, 279104, 296000, 311360, 393984, 410112]⟩
def m700_699 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e700_699 : Edge c700 c699 m700_699 := by
  exact edgeByCodes c700 c699 m700_699 47390263961951766970624 1113232139549844033674057744640 (by decide) (by decide) (by decide) (by decide)
theorem floor700 : Floor c700 10 := by
  have up := refundEdge e700_699 floor699 131136 131456 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c701 : Chart := ⟨[16640, 17408, 33024, 34816, 132096, 133120, 264192, 266240],[7424, 22528, 37888, 135424, 184320, 262400, 263424, 295936, 311296, 393472, 409600]⟩
def m701_696 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e701_696 : Edge c701 c696 m701_696 := by
  exact edgeByCodes c701 c696 m701_696 1694364648734976 185118218605668925440 (by decide) (by decide) (by decide) (by decide)
theorem floor701 : Floor c701 7 := by
  have up := refundEdge e701_696 floor696 266240 262400 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c702 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 132096, 133120, 262272, 264192, 266240],[2432, 3200, 7424, 22528, 38016, 135552, 168064, 184320, 262400, 263424, 295936, 311296, 393472, 409600]⟩
def m702_697 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e702_697 : Edge c702 c697 m702_697 := by
  exact edgeByCodes c702 c697 m702_697 148080050112590643456 1033693278377499913344442827008 (by decide) (by decide) (by decide) (by decide)
theorem floor702 : Floor c702 9 := by
  have up := refundEdge e702_697 floor697 266240 262400 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c703 : Chart := ⟨[1065088, 16640, 17408, 33024, 34816, 1179649, 132096, 133120, 1310848, 264192, 266240],[1051009, 1051776, 7424, 1071105, 1086593, 1101825, 1180032, 1184128, 1216640, 184320, 1312001, 1344513, 1359873, 393472, 409600]⟩
def m703_702 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, none, some 14, some 15, none, some 17, some 18, none, some 7, none]
theorem e703_702 : Edge c703 c702 m703_702 := by
  exact edgeByCodes c703 c702 m703_702 47390263963051278598400 284987427729519477273016722915584 (by decide) (by decide) (by decide) (by decide)
theorem floor703 : Floor c703 10 := by
  have up := refundEdge e703_702 floor702 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c704 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 132096, 133120, 262272, 264192, 266240],[2432, 3712, 7424, 23040, 33920, 38016, 136064, 152064, 168064, 184320, 263936, 295936, 311296, 393984, 410112]⟩
def m704_702 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e704_702 : Edge c704 c702 m704_702 := by
  exact edgeByCodes c704 c702 m704_702 47390263963055573565696 284987427729519477271921506255104 (by decide) (by decide) (by decide) (by decide)
theorem floor704 : Floor c704 10 := by
  have up := refundEdge e704_702 floor702 33280 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c705 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 131136, 132096, 262272],[448, 640, 1664, 33984, 131968, 163968, 188416, 264000, 271616, 279104, 296000, 304128, 311360, 393984, 401664, 410112]⟩
def m705_228 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
theorem e705_228 : Edge c705 c228 m705_228 := by
  exact edgeByCodes c705 c228 m705_228 42649378395939397566720 476934600209772497502902616576 (by decide) (by decide) (by decide) (by decide)
theorem floor705 : Floor c705 10 := by
  have up := refundEdge e705_228 floor228 262272 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c706 : Chart := ⟨[8256, 8320, 16512, 34816, 131136, 133120, 262272, 264192],[128, 2240, 18496, 26624, 32960, 163968, 188416, 303104, 311360, 401408, 409600]⟩
def m706_675 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e706_675 : Edge c706 c675 m706_675 := by
  exact edgeByCodes c706 c675 m706_675 1976943448883456 166527358240077054209 (by decide) (by decide) (by decide) (by decide)
theorem floor706 : Floor c706 7 := by
  have up := refundEdge e706_675 floor675 16512 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c707 : Chart := ⟨[8320, 16512, 16640, 33024, 34816, 133120, 262272, 264192],[128, 2432, 10496, 26624, 131456, 163968, 188416, 303104, 311296, 401664, 409600]⟩
def m707_692 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e707_692 : Edge c707 c692 m707_692 := by
  exact edgeByCodes c707 c692 m707_692 1976943448883713 723118037116650241 (by decide) (by decide) (by decide) (by decide)
theorem floor707 : Floor c707 7 := by
  have up := refundEdge e707_692 floor692 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)


end TightRow.Protected.Numeric
