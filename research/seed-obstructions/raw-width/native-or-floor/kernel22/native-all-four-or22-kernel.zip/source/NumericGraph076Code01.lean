import NumericEdgeCodes
import NumericGraph076Code00
import Branch519872
import Branch520064
import NumericGraph029
import NumericGraph030
import NumericGraph049
import NumericGraph059
import NumericGraph060
import NumericGraph067
import NumericGraph070
import NumericGraph073
import NumericGraph075
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem floor916 : Floor c916 12 := by
  apply protectedBranch source c916.P c916.N (decode 519872) 12
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 519872, q = 6 ∨ q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e916_915 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor915 k x net fit)
    · refine ⟨_,goodChild e916_914 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor914 k x net fit)
    · refine ⟨_,goodChild e916_911 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor911 k x net fit)
    · refine ⟨_,goodChild e916_908 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor908 k x net fit)
    · refine ⟨_,goodChild e916_905 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor905 k x net fit)
    · refine ⟨_,goodChild e916_880 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor880 k x net fit)
    · refine ⟨_,goodChild e916_847 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor847 k x net fit)
    · refine ⟨_,goodChild e916_805 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor805 k x net fit)
    · refine ⟨_,goodChild e916_718 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor718 k x net fit)
    · refine ⟨_,goodChild e916_591 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor591 k x net fit)
    · refine ⟨_,goodChild e916_356 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor356 k x net fit)
  · exact pairExcluded 519872 519872 [8256, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 262272, 264192] [3712, 11264, 19008, 33984, 67776, 84032, 92160, 98496, 131712, 188416, 229504, 263744, 279104, 296000, 304128, 376896, 410112, 466944] validBranch519872 (by decide) (by decide) (by decide)
def c917 : Chart := ⟨[8196, 8256, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[3204, 3588, 3712, 9216, 11264, 18948, 19008, 33924, 33984, 67716, 67776, 84036, 92160, 98496, 131712, 180228, 188416, 229508, 263684, 263744, 279104, 296004, 304128, 376900, 410116, 458756, 466944]⟩
def m917_916 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e917_916 : Edge c917 c916 m917_916 := by
  exact edgeByCodes c917 c916 m917_916 284987427729500958188778798907905 2273116897933823942536339955818788423074818 (by decide) (by decide) (by decide) (by decide)
theorem floor917 : Floor c917 13 := by
  have up := refundEdge e917_916 floor916 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c918 : Chart := ⟨[8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120, 264192],[512, 3584, 11520, 18944, 76032, 92160, 188416, 229376, 263936, 271616, 304128, 376832, 393984, 410112, 467200]⟩
def m918_881 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e918_881 : Edge c918 c881 m918_881 := by
  exact edgeByCodes c918 c881 m918_881 47390263963055590408705 284987427729482439104532251214338 (by decide) (by decide) (by decide) (by decide)
theorem floor918 : Floor c918 10 := by
  have up := refundEdge e918_881 floor881 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c919 : Chart := ⟨[8256, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 264192],[3584, 9472, 11520, 19008, 67904, 76032, 84032, 92160, 188416, 229376, 264000, 271616, 279104, 296000, 304128, 328000, 376896, 393984, 410112, 467200]⟩
def m919_918 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e919_918 : Edge c919 c918 m919_918 := by
  exact edgeByCodes c919 c918 m919_918 14559240912565549041648129 99020075532527447269105646522466304 (by decide) (by decide) (by decide) (by decide)
theorem floor919 : Floor c919 11 := by
  have up := refundEdge e919_918 floor918 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c920 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192],[3712, 11520, 18944, 33920, 67968, 76032, 92160, 131968, 188416, 196992, 229504, 263936, 271616, 304128, 376832, 393984, 410112, 467200]⟩
def m920_918 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e920_918 : Edge c920 c918 m920_918 := by
  exact edgeByCodes c920 c918 m920_918 15768166804520351054430977 88594757919751255565500243513507840 (by decide) (by decide) (by decide) (by decide)
def m920_915 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e920_915 : Edge c920 c915 m920_915 := by
  exact edgeByCodes c920 c915 m920_915 4037864368662391615284969728 88594678379676379550652422795886592 (by decide) (by decide) (by decide) (by decide)
def m920_912 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e920_912 : Edge c920 c912 m920_912 := by
  exact edgeByCodes c920 c912 m920_912 15772907690086359112024576 88594678380885323889069823541444608 (by decide) (by decide) (by decide) (by decide)
def m920_909 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e920_909 : Edge c920 c909 m920_909 := by
  exact edgeByCodes c920 c909 m920_909 15772907545407121554276608 88594757919741773794649693785030656 (by decide) (by decide) (by decide) (by decide)
def m920_906 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e920_906 : Edge c920 c906 m920_906 := by
  exact edgeByCodes c920 c906 m920_906 14554500099056026886734080 346073273124028342053843461604096 (by decide) (by decide) (by decide) (by decide)
def m920_882 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e920_882 : Edge c920 c882 m920_882 := by
  exact edgeByCodes c920 c882 m920_882 4037864368662391615301878530 22680258027455107758135503350040494081 (by decide) (by decide) (by decide) (by decide)
def m920_848 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e920_848 : Edge c920 c848 m920_848 := by
  exact edgeByCodes c920 c848 m920_848 15772907690087467247272192 88574395971286413104495566971404544 (by decide) (by decide) (by decide) (by decide)
def m920_806 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e920_806 : Edge c920 c806 m920_806 := by
  exact edgeByCodes c920 c806 m920_806 15772907690087454311842048 88594757918537570341517934255538432 (by decide) (by decide) (by decide) (by decide)
def m920_720 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e920_720 : Edge c920 c720 m920_720 := by
  exact edgeByCodes c920 c720 m920_720 4037864368517711269625725184 21356222328529940342743692109313802244 (by decide) (by decide) (by decide) (by decide)
def m920_592 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e920_592 : Edge c920 c592 m920_592 := by
  exact edgeByCodes c920 c592 m920_592 4037854886891257382916194560 18697725930286527626861847655928102919 (by decide) (by decide) (by decide) (by decide)
def m920_362 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
theorem e920_362 : Edge c920 c362 m920_362 := by
  exact edgeByCodes c920 c362 m920_362 3416467015609337987117220096 3425467439338565795820308892618053451787 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
