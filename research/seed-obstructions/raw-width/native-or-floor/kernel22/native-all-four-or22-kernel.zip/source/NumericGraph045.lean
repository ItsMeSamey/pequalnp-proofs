import NumericEdgeCodes
import Branch375424
import NumericGraph035
import NumericGraph036
import NumericGraph039
import NumericGraph040
import NumericGraph044
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c540 : Chart := ⟨[8320, 8704, 33280, 66048, 69632, 262272, 266240],[640, 4736, 36992, 45056, 98432, 262656, 303104, 335872, 360448]⟩
def m540_478 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
theorem e540_478 : Edge c540 c478 m540_478 := by
  exact edgeByCodes c540 c478 m540_478 6618611908864 30148920065 (by decide) (by decide) (by decide) (by decide)
theorem floor540 : Floor c540 6 := by
  have up := refundEdge e540_478 floor478 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c541 : Chart := ⟨[8320, 8704, 33024, 33280, 66048, 69632, 262272, 266240],[4992, 12544, 32896, 36992, 45056, 65920, 98432, 262912, 303104, 336128, 360448]⟩
def m541_540 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e541_540 : Edge c541 c540 m541_540 := by
  exact edgeByCodes c541 c540 m541_540 1976943448883456 185118218605669056512 (by decide) (by decide) (by decide) (by decide)
theorem floor541 : Floor c541 7 := by
  have up := refundEdge e541_540 floor540 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c542 : Chart := ⟨[8704, 33280, 34816, 66048, 69632, 264192, 266240],[512, 6656, 14336, 45056, 75776, 262656, 303104, 335872, 360448]⟩
def m542_529 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e542_529 : Edge c542 c529 m542_529 := by
  exact edgeByCodes c542 c529 m542_529 6618611909121 34443887361 (by decide) (by decide) (by decide) (by decide)
theorem floor542 : Floor c542 6 := by
  have up := refundEdge e542_529 floor529 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c543 : Chart := ⟨[8196, 8704, 33280, 34816, 66048, 69632, 264192, 266240],[6660, 8192, 14336, 36868, 45056, 67588, 75776, 262660, 303104, 335872, 360452]⟩
def m543_542 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e543_542 : Edge c543 c542 m543_542 := by
  exact edgeByCodes c543 c542 m543_542 1976943448883713 185118218605668990976 (by decide) (by decide) (by decide) (by decide)
theorem floor543 : Floor c543 7 := by
  have up := refundEdge e543_542 floor542 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c544 : Chart := ⟨[2105408, 8704, 33280, 34816, 66048, 2166784, 264192, 2363392],[2103872, 2109440, 2111488, 2134080, 2142208, 2164800, 75776, 2359872, 303104, 335872, 2457664]⟩
def m544_542 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, some 12]
theorem e544_542 : Edge c544 c542 m544_542 := by
  exact edgeByCodes c544 c542 m544_542 1976943448883713 185118218605668990976 (by decide) (by decide) (by decide) (by decide)
theorem floor544 : Floor c544 7 := by
  have up := refundEdge e544_542 floor542 2105408 2109440 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c545 : Chart := ⟨[8320, 8704, 33280, 34816, 66048, 69632, 262272, 264192, 266240],[2688, 4736, 6656, 14336, 36992, 45056, 67712, 75776, 98432, 262656, 303104, 335872, 360448]⟩
def m545_542 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e545_542 : Edge c545 c542 m545_542 := by
  exact edgeByCodes c545 c542 m545_542 2259517937222145 222156387094452437504 (by decide) (by decide) (by decide) (by decide)
def m545_540 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e545_540 : Edge c545 c540 m545_540 := by
  exact edgeByCodes c545 c540 m545_540 2258418425528576 222156387098747470080 (by decide) (by decide) (by decide) (by decide)
def m545_538 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e545_538 : Edge c545 c538 m545_538 := by
  exact edgeByCodes c545 c538 m545_538 1976939137073408 222156387098781155328 (by decide) (by decide) (by decide) (by decide)
def m545_530 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e545_530 : Edge c545 c530 m545_530 := by
  exact edgeByCodes c545 c530 m545_530 2259522249032450 867233225175597312 (by decide) (by decide) (by decide) (by decide)
def m545_485 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
theorem e545_485 : Edge c545 c485 m545_485 := by
  exact edgeByCodes c545 c485 m545_485 2259522249031936 795174531609264384 (by decide) (by decide) (by decide) (by decide)
def m545_428 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, none, none, some 18, none, none, none]
theorem e545_428 : Edge c545 c428 m545_428 := by
  exact edgeByCodes c545 c428 m545_428 2259522215346432 723114729958146304 (by decide) (by decide) (by decide) (by decide)
theorem floor545 : Floor c545 8 := by
  apply protectedBranch source c545.P c545.N (decode 112768) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 112768, q = 7 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 15 ∨ q = 16 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e545_542 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor542 k x net fit)
    · refine ⟨_,goodChild e545_540 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor540 k x net fit)
    · refine ⟨_,goodChild e545_538 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor538 k x net fit)
    · refine ⟨_,goodChild e545_530 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor530 k x net fit)
    · refine ⟨_,goodChild e545_485 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor485 k x net fit)
    · refine ⟨_,goodChild e545_428 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor428 k x net fit)
  · exact pairExcluded 375424 112768 [8320, 8704, 33280, 34816, 66048, 69632, 262272, 264192, 266240] [2688, 4736, 6656, 14336, 36992, 45056, 67712, 75776, 98432, 262656, 303104, 335872, 360448] validBranch375424 (by decide) (by decide) (by decide)
def c546 : Chart := ⟨[8320, 8704, 33024, 33280, 34816, 66048, 69632, 262272, 264192, 266240],[2688, 4992, 6656, 14592, 32896, 36992, 45056, 67968, 76032, 98432, 262912, 303104, 336128, 360448]⟩
def m546_545 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e546_545 : Edge c546 c545 m546_545 := by
  exact edgeByCodes c546 c545 m546_545 166599134359138271488 1033693278377572253517264060672 (by decide) (by decide) (by decide) (by decide)
theorem floor546 : Floor c546 9 := by
  have up := refundEdge e546_545 floor545 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c547 : Chart := ⟨[8196, 8320, 8704, 33024, 33280, 34816, 66048, 69632, 262272, 264192, 266240],[2688, 4992, 6660, 8448, 14592, 36996, 45056, 67972, 76032, 98436, 262916, 303104, 327940, 336128, 360452]⟩
def m547_546 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e547_546 : Edge c547 c546 m547_546 := by
  exact edgeByCodes c547 c546 m547_546 47390263963055590408705 284987117030824431661969018323200 (by decide) (by decide) (by decide) (by decide)
theorem floor547 : Floor c547 10 := by
  have up := refundEdge e547_546 floor546 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c548 : Chart := ⟨[8320, 8704, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4736, 6656, 15360, 38016, 46080, 65664, 67712, 75776, 98432, 263680, 304128, 335872, 360448]⟩
def m548_545 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e548_545 : Edge c548 c545 m548_545 := by
  exact edgeByCodes c548 c545 m548_545 166599134354826461440 1033693278377572252413457465600 (by decide) (by decide) (by decide) (by decide)
theorem floor548 : Floor c548 9 := by
  have up := refundEdge e548_545 floor545 66560 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c549 : Chart := ⟨[2105408, 8320, 8704, 33280, 34816, 66048, 66560, 2166784, 262272, 264192, 2363392],[3712, 2101888, 2103872, 2110464, 2112512, 2135232, 2143232, 2164928, 75776, 2195648, 2360896, 2393152, 304128, 335872, 2457664]⟩
def m549_548 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, some 12]
theorem e549_548 : Edge c549 c548 m549_548 := by
  exact edgeByCodes c549 c548 m549_548 47390263963055590408705 284987426515834253289612231442688 (by decide) (by decide) (by decide) (by decide)
theorem floor549 : Floor c549 10 := by
  have up := refundEdge e549_548 floor548 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c550 : Chart := ⟨[8320, 8704, 33024, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4992, 6656, 15616, 33920, 38016, 46080, 67968, 76032, 98432, 263936, 271616, 304128, 336128, 360448]⟩
def m550_548 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e550_548 : Edge c550 c548 m550_548 := by
  exact edgeByCodes c550 c548 m550_548 47390263963055590408448 284987426515834253289612214665472 (by decide) (by decide) (by decide) (by decide)
theorem floor550 : Floor c550 10 := by
  have up := refundEdge e550_548 floor548 33024 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c551 : Chart := ⟨[16512, 16640, 33024, 33280, 66048, 262272],[640, 896, 65920, 98432, 262912, 279040, 327936, 376832]⟩
def m551_432 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e551_432 : Edge c551 c432 m551_432 := by
  exact edgeByCodes c551 c432 m551_432 21525299456 30148920065 (by decide) (by decide) (by decide) (by decide)
theorem floor551 : Floor c551 5 := by
  have up := refundEdge e551_432 floor432 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)


end TightRow.Protected.Numeric
