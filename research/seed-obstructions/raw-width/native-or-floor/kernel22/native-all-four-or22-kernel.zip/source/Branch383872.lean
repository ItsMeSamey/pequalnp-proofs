import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short383872
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16512, 16640, 33024, 33280, 34816, 66048, 69632, 262272, 264192, 266240]
def n : List Nat := [2688, 4992, 6400, 23040, 36992, 53248, 67968, 83968, 98432, 262912, 279040, 327936, 376832]
def pp := p.map (canonical 383872)
def nn := n.map (canonical 383872)
def parts : List Nat := [0, 128, 256, 512, 2048, 4096, 16384, 65536, 16512, 16640, 66048, 69632]
def g : ShortGrid := [(0,[(128,10282049269874637764604893470253591554254660698881), (256,1518614717260779061774658295748598798584589124353), (512,7370419548810763729080876022004465335902079747073), (2048,11743573208291042370139729011235213090244782195713), (4096,13205097146707436611205107851918200086522812040705), (16384,1512905639376334809270147208159096052948246986753), (16512,65792), (16640,0), (65536,7359001393041896034141647276125881336283080753153), (66048,12952273664), (69632,21474837760)]), (128,[(256,8657240064), (512,12952207360), (2048,17247174656), (4096,25870663680), (16384,3298534883328), (16640,0), (65536,21475033088), (66048,21475033088), (69632,21475033088)]), (256,[(512,21575696640), (2048,34510930176), (4096,25870663936), (16384,284773511593984), (16512,16777472), (65536,21491810560), (66048,21491810560), (69632,21491810560)]), (512,[(2048,34511127808), (4096,38806095104), (16384,849922488270848), (16512,65792), (16640,0), (65536,1413993428157696), (69632,21474837760)]), (2048,[(4096,1130297953748480), (16384,1131397464981504), (16512,65792), (16640,0), (65536,1134695999866112), (66048,262912), (69632,1280)]), (4096,[(16384,1696546441658368), (16512,65792), (16640,0), (65536,1695446930031872), (66048,262912)]), (16384,[(65536,21525168128), (66048,21525168128), (69632,21525168128)]), (16512,[(65536,65792), (66048,65792), (69632,65792)]), (16640,[(65536,0), (66048,0), (69632,0)])]
private theorem row0 : parts.all (shortPair g pp nn 88960 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 88960 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 88960 256) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 88960 512) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 88960 2048) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 88960 4096) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 88960 16384) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 88960 65536) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 88960 16512) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 88960 16640) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 88960 66048) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 88960 69632) = true := by decide
theorem full : checkArms 383872 88960 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 256, 512, 2048, 4096, 16384, 65536, 16512, 16640, 66048, 69632] : List Nat).all (fun i => parts.all (shortPair g pp nn 88960 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short383872
theorem validBranch383872 : checkArms 383872 88960 [16512, 16640, 33024, 33280, 34816, 66048, 69632, 262272, 264192, 266240] [2688, 4992, 6400, 23040, 36992, 53248, 67968, 83968, 98432, 262912, 279040, 327936, 376832] = true := Short383872.full
end TightRow.Protected.Numeric
