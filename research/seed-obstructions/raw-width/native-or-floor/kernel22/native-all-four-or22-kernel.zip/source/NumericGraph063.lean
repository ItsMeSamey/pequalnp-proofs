import NumericEdgeCodes
import NumericGraph063Code00
import Branch470656
import Branch470720
import NumericGraph022
import NumericGraph039
import NumericGraph052
import NumericGraph053
import NumericGraph061
import NumericGraph062
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m765_764 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e765_764 : Edge c765 c764 m765_764 := by
  exact edgeByCodes c765 c764 m765_764 47390263963055590408705 1590154608036437097210932625664 (by decide) (by decide) (by decide) (by decide)
theorem floor765 : Floor c765 10 := by
  have up := refundEdge e765_764 floor764 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c766 : Chart := ⟨[2105408, 8320, 2166784, 2228288, 262272, 2363392],[2101312, 2101440, 2162880, 2232448, 2240512, 196736, 2424896, 466944]⟩
def m766_637 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, some 12, some 13, none, none, none, some 17, some 18, none, none, some 21]
theorem e766_637 : Edge c766 c637 m766_637 := by
  exact edgeByCodes c766 c637 m766_637 21542142208 30165697281 (by decide) (by decide) (by decide) (by decide)
theorem floor766 : Floor c766 5 := by
  have up := refundEdge e766_637 floor637 2166784 2101312 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c767 : Chart := ⟨[2105408, 8704, 66048, 2166784, 2228288, 2363392],[2101312, 2101824, 2232832, 2240512, 2359872, 2424896, 393728, 466944]⟩
def m767_477 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, some 21]
theorem e767_477 : Edge c767 c477 m767_477 := by
  exact edgeByCodes c767 c477 m767_477 21525299456 30148920065 (by decide) (by decide) (by decide) (by decide)
theorem floor767 : Floor c767 5 := by
  have up := refundEdge e767_477 floor477 2228288 2101312 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)


end TightRow.Protected.Numeric
