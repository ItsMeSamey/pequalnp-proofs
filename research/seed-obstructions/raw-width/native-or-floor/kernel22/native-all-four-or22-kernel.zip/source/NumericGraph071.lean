import NumericEdgeCodes
import NumericGraph071Code00
import Branch506432
import NumericGraph027
import NumericGraph045
import NumericGraph057
import NumericGraph064
import NumericGraph069
import NumericGraph070
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m862_861 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e862_861 : Edge c862 c861 m862_861 := by
  exact edgeByCodes c862 c861 m862_861 47390263963055590408705 386717631187781587916446278680576 (by decide) (by decide) (by decide) (by decide)
theorem floor862 : Floor c862 10 := by
  have up := refundEdge e862_861 floor861 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c863 : Chart := ⟨[8196, 8704, 33280, 34816, 66048, 66560, 69632, 131073, 132096, 133120, 264192, 266240],[2565, 3588, 6657, 6660, 7172, 14337, 15360, 37892, 46081, 67589, 75777, 131072, 135684, 167940, 176128, 229380, 263685, 295941, 304129, 335873, 360453, 393732, 458756, 466944]⟩
def m863_862 : List (Option Addr) := [none, none, some 2, none, none, none, none, none, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e863_862 : Edge c863 c862 m863_862 := by
  exact edgeByCodes c863 c862 m863_862 13345574279441397712027904 131799240310982586832473180310048745086299407105 (by decide) (by decide) (by decide) (by decide)
theorem floor863 : Floor c863 11 := by
  have up := refundEdge e863_862 floor862 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)


end TightRow.Protected.Numeric
