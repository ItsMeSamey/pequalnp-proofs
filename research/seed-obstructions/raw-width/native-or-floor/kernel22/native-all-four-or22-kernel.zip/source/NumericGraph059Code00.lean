import NumericEdgeCodes
import Branch453056
import Branch454272
import NumericGraph019
import NumericGraph020
import NumericGraph037
import NumericGraph055
import NumericGraph056
import NumericGraph057
import NumericGraph058
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c708 : Chart := ⟨[8256, 8320, 16512, 16640, 33024, 34816, 131136, 133120, 262272, 264192],[2496, 10496, 18496, 26624, 32960, 131456, 163968, 188416, 262464, 303104, 311360, 401664, 409600]⟩
def m708_707 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e708_707 : Edge c708 c707 m708_707 := by
  exact edgeByCodes c708 c707 m708_707 650777864278573569 14559240984623143062667264 (by decide) (by decide) (by decide) (by decide)
def m708_706 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e708_706 : Edge c708 c706 m708_706 := by
  exact edgeByCodes c708 c706 m708_706 650777868590252288 14559240984623138767765504 (by decide) (by decide) (by decide) (by decide)
def m708_694 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e708_694 : Edge c708 c694 m708_694 := by
  exact edgeByCodes c708 c694 m708_694 650777868590383874 56872034814709175943680 (by decide) (by decide) (by decide) (by decide)
def m708_676 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e708_676 : Edge c708 c676 m708_676 := by
  exact edgeByCodes c708 c676 m708_676 650777868590383360 13340870359985180576579840 (by decide) (by decide) (by decide) (by decide)
def m708_661 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e708_661 : Edge c708 c661 m708_661 := by
  exact edgeByCodes c708 c661 m708_661 650777868556697856 14559240912564440906465536 (by decide) (by decide) (by decide) (by decide)
def m708_452 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
theorem e708_452 : Edge c708 c452 m708_452 := by
  exact edgeByCodes c708 c452 m708_452 650775660943507712 12131962987112417464484096 (by decide) (by decide) (by decide) (by decide)
def m708_232 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
theorem e708_232 : Edge c708 c232 m708_232 := by
  exact edgeByCodes c708 c232 m708_232 506097522914230528 33168039896451421176064 (by decide) (by decide) (by decide) (by decide)
theorem floor708 : Floor c708 9 := by
  apply protectedBranch source c708.P c708.N (decode 450880) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 450880, q = 6 ∨ q = 8 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e708_707 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor707 k x net fit)
    · refine ⟨_,goodChild e708_706 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor706 k x net fit)
    · refine ⟨_,goodChild e708_694 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor694 k x net fit)
    · refine ⟨_,goodChild e708_676 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor676 k x net fit)
    · refine ⟨_,goodChild e708_661 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor661 k x net fit)
    · refine ⟨_,goodChild e708_452 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor452 k x net fit)
    · refine ⟨_,goodChild e708_232 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor232 k x net fit)
  · exact pairExcluded 453056 450880 [8256, 8320, 16512, 16640, 33024, 34816, 131136, 133120, 262272, 264192] [2496, 10496, 18496, 26624, 32960, 131456, 163968, 188416, 262464, 303104, 311360, 401664, 409600] validBranch453056 (by decide) (by decide) (by decide)
def c709 : Chart := ⟨[8320, 8704, 16512, 33280, 34816, 133120, 262272, 264192],[640, 2688, 18944, 26624, 131712, 163968, 188416, 303104, 311296, 401408, 410112]⟩
def m709_679 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e709_679 : Edge c709 c679 m709_679 := by
  exact edgeByCodes c709 c679 m709_679 1976943448883456 166743249547214127361 (by decide) (by decide) (by decide) (by decide)
theorem floor709 : Floor c709 7 := by
  have up := refundEdge e709_679 floor679 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c710 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 34816, 133120, 262272, 264192],[2432, 2688, 10496, 18944, 26624, 131968, 163968, 188416, 303104, 311296, 393984, 401664, 410112]⟩
def m710_454 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
theorem e710_454 : Edge c710 c454 m710_454 := by
  exact edgeByCodes c710 c454 m710_454 166598851780338123008 715543901947790023164073934853 (by decide) (by decide) (by decide) (by decide)
theorem floor710 : Floor c710 9 := by
  have up := refundEdge e710_454 floor454 133120 2432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c711 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 131136, 133120, 262272, 264192],[2496, 2688, 8448, 10496, 19008, 26624, 32960, 131968, 163968, 188416, 262976, 279104, 303104, 311360, 393984, 401664, 410112]⟩
def m711_710 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e711_710 : Edge c711 c710 m711_710 := by
  exact edgeByCodes c711 c710 m711_710 52131149247592983101953 1272309861949800166390201778432 (by decide) (by decide) (by decide) (by decide)
theorem floor711 : Floor c711 10 := by
  have up := refundEdge e711_710 floor710 8256 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c712 : Chart := ⟨[8196, 8256, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 131136, 133120, 262272, 264192],[2372, 2436, 2496, 2688, 8448, 10496, 18500, 18948, 19008, 26624, 32960, 131460, 131968, 163972, 180228, 188416, 262468, 262976, 279104, 303104, 311364, 393988, 401664, 410116]⟩
def m712_711 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e712_711 : Edge c712 c711 m712_711 := by
  exact edgeByCodes c712 c711 m712_711 3727165692135864801209549313 7855846900482000554038019851646300062466 (by decide) (by decide) (by decide) (by decide)
theorem floor712 : Floor c712 11 := by
  have up := refundEdge e712_711 floor711 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c713 : Chart := ⟨[8320, 16512, 17408, 34816, 132096, 133120, 262272, 264192],[128, 3200, 11264, 26624, 33920, 163968, 188416, 304128, 311296, 401408, 409600]⟩
def m713_695 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e713_695 : Edge c713 c695 m713_695 := by
  exact edgeByCodes c713 c695 m713_695 1976943448883713 185045878432847823105 (by decide) (by decide) (by decide) (by decide)
theorem floor713 : Floor c713 7 := by
  have up := refundEdge e713_695 floor695 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c714 : Chart := ⟨[8320, 16512, 16640, 17408, 33024, 34816, 132096, 133120, 262272, 264192],[128, 2432, 3200, 11520, 26624, 33920, 131456, 163968, 188416, 271616, 304128, 311296, 401664, 409600]⟩
def m714_697 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e714_697 : Edge c714 c697 m714_697 := by
  exact edgeByCodes c714 c697 m714_697 166599134359138271745 1033693278377572253517280903681 (by decide) (by decide) (by decide) (by decide)
theorem floor714 : Floor c714 9 := by
  have up := refundEdge e714_697 floor697 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c715 : Chart := ⟨[8256, 8320, 16512, 16640, 17408, 33024, 34816, 131136, 132096, 133120, 262272, 264192],[2496, 3200, 9472, 11520, 18496, 26624, 33984, 131456, 163968, 188416, 263488, 271616, 296000, 304128, 311360, 401664, 409600]⟩
def m715_714 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e715_714 : Edge c715 c714 m715_714 := by
  exact edgeByCodes c715 c714 m715_714 52131149529067959812609 325711324654426476114125816659968 (by decide) (by decide) (by decide) (by decide)
theorem floor715 : Floor c715 10 := by
  have up := refundEdge e715_714 floor714 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c716 : Chart := ⟨[8196, 8256, 8320, 16512, 16640, 17408, 33024, 34816, 131136, 132096, 133120, 262272, 264192],[2372, 2436, 2496, 3204, 3332, 9472, 11520, 18500, 26624, 33924, 33984, 131460, 163972, 180228, 188416, 263492, 271616, 296004, 304128, 311364, 393476, 401664, 409604]⟩
def m716_715 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e716_715 : Edge c716 c715 m716_715 := by
  exact edgeByCodes c716 c715 m716_715 3727165692135864801209549313 7514224880247663180102447648043021173506 (by decide) (by decide) (by decide) (by decide)
theorem floor716 : Floor c716 11 := by
  have up := refundEdge e716_715 floor715 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c717 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 132096, 133120, 262272, 264192],[3712, 11264, 18944, 26624, 33920, 131712, 163968, 188416, 263680, 304128, 311296, 401408, 410112]⟩
def m717_713 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e717_713 : Edge c717 c713 m717_713 := by
  exact edgeByCodes c717 c713 m717_713 650777868590318080 14559240984623138767699968 (by decide) (by decide) (by decide) (by decide)
def m717_709 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e717_709 : Edge c717 c709 m717_709 := by
  exact edgeByCodes c717 c709 m717_709 650777864278507776 14559240984623143062732800 (by decide) (by decide) (by decide) (by decide)
def m717_698 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e717_698 : Edge c717 c698 m717_698 := by
  exact edgeByCodes c717 c698 m717_698 650777868590383874 56853516013041428464128 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
