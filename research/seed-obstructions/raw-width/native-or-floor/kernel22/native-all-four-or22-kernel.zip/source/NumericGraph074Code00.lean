import NumericEdgeCodes
import Branch515328
import NumericGraph028
import NumericGraph048
import NumericGraph058
import NumericGraph065
import NumericGraph066
import NumericGraph069
import NumericGraph072
import NumericGraph073
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c888 : Chart := ⟨[1065088, 16640, 33024, 33280, 34816, 66048, 69632, 1179649, 133120, 1310848, 264192, 266240],[1049473, 1051265, 1053313, 6400, 1071617, 1085569, 1101825, 1116545, 1132545, 1147009, 1180032, 1184640, 152064, 1216640, 184320, 1245568, 1278080, 1311489, 1327617, 1376513, 1425409, 393984, 410112, 459008]⟩
def m888_887 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, some 7, none]
theorem e888_887 : Edge c888 c887 m888_887 := by
  exact edgeByCodes c888 c887 m888_887 13345574279441397712027904 30686901954075718653222857918745084167 (by decide) (by decide) (by decide) (by decide)
theorem floor888 : Floor c888 11 := by
  have up := refundEdge e888_887 floor887 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c889 : Chart := ⟨[16512, 16640, 33024, 33280, 34816, 66048, 2166784, 2228288, 133120, 262272, 264192, 2363392],[2688, 2101696, 2102080, 2103616, 2120256, 2134208, 2150464, 2165184, 2181184, 2195648, 2232448, 2233216, 2249216, 2265216, 2281472, 196992, 229504, 2360128, 2376256, 2425152, 2474048, 393984, 410112, 459008]⟩
def m889_887 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e889_887 : Edge c889 c887 m889_887 := by
  exact edgeByCodes c889 c887 m889_887 13345574279441397712027904 30686901954075718653222857918745083911 (by decide) (by decide) (by decide) (by decide)
theorem floor889 : Floor c889 11 := by
  have up := refundEdge e889_887 floor887 2228288 2232448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c890 : Chart := ⟨[17408, 34816, 66560, 69632, 132096, 133120, 264192, 266240],[1024, 7168, 22528, 37888, 83968, 184320, 229376, 295936, 376832, 409600, 458752]⟩
def m890_832 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e890_832 : Edge c890 c832 m890_832 := by
  exact edgeByCodes c890 c832 m890_832 1976943448883713 185045878432847823105 (by decide) (by decide) (by decide) (by decide)
theorem floor890 : Floor c890 7 := by
  have up := refundEdge e890_832 floor832 17408 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c891 : Chart := ⟨[16512, 17408, 34816, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[2176, 3200, 7168, 22528, 38016, 67712, 83968, 168064, 184320, 229504, 295936, 376832, 409600, 458752]⟩
def m891_791 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e891_791 : Edge c891 c791 m891_791 := by
  exact edgeByCodes c891 c791 m891_791 166599134359138271488 1033693278377572253517264061441 (by decide) (by decide) (by decide) (by decide)
theorem floor891 : Floor c891 9 := by
  have up := refundEdge e891_791 floor791 34816 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c892 : Chart := ⟨[16640, 17408, 33024, 34816, 66560, 69632, 132096, 133120, 264192, 266240],[7424, 22528, 37888, 67840, 83968, 135424, 184320, 229376, 263424, 295936, 376832, 409600, 459008]⟩
def m892_890 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e892_890 : Edge c892 c890 m892_890 := by
  exact edgeByCodes c892 c890 m892_890 650777868590383873 14559240984623138750922752 (by decide) (by decide) (by decide) (by decide)
def m892_875 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e892_875 : Edge c892 c875 m892_875 := by
  exact edgeByCodes c892 c875 m892_875 578437691440496896 14559240984905721862881280 (by decide) (by decide) (by decide) (by decide)
def m892_833 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e892_833 : Edge c892 c833 m892_833 := by
  exact edgeByCodes c892 c833 m892_833 650777868590383874 14554500099338605670040064 (by decide) (by decide) (by decide) (by decide)
def m892_792 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e892_792 : Edge c892 c792 m892_792 := by
  exact edgeByCodes c892 c792 m892_792 650777868590383360 14559240912282970241433856 (by decide) (by decide) (by decide) (by decide)
def m892_701 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e892_701 : Edge c892 c701 m892_701 := by
  exact edgeByCodes c892 c701 m892_701 650777868556697856 13355037531775061861728512 (by decide) (by decide) (by decide) (by decide)
def m892_579 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e892_579 : Edge c892 c579 m892_579 := by
  exact edgeByCodes c892 c579 m892_579 650775660943507712 47445676532138154000640 (by decide) (by decide) (by decide) (by decide)
def m892_340 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, none, none, none, none]
theorem e892_340 : Edge c892 c340 m892_340 := by
  exact edgeByCodes c892 c340 m892_340 506097522914230528 8519260178668413161439488 (by decide) (by decide) (by decide) (by decide)
theorem floor892 : Floor c892 9 := by
  apply protectedBranch source c892.P c892.N (decode 512256) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 512256, q = 8 ∨ q = 12 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e892_890 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor890 k x net fit)
    · refine ⟨_,goodChild e892_875 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor875 k x net fit)
    · refine ⟨_,goodChild e892_833 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor833 k x net fit)
    · refine ⟨_,goodChild e892_792 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor792 k x net fit)
    · refine ⟨_,goodChild e892_701 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor701 k x net fit)
    · refine ⟨_,goodChild e892_579 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor579 k x net fit)
    · refine ⟨_,goodChild e892_340 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor340 k x net fit)
  · exact pairExcluded 515328 512256 [16640, 17408, 33024, 34816, 66560, 69632, 132096, 133120, 264192, 266240] [7424, 22528, 37888, 67840, 83968, 135424, 184320, 229376, 263424, 295936, 376832, 409600, 459008] validBranch515328 (by decide) (by decide) (by decide)
def c893 : Chart := ⟨[16640, 17408, 33024, 34816, 66560, 69632, 131073, 132096, 133120, 264192, 266240],[7424, 22529, 37889, 53249, 67841, 83969, 131328, 135424, 184320, 229376, 263425, 295937, 327937, 376833, 409600, 459008]⟩
def m893_892 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e893_892 : Edge c893 c892 m893_892 := by
  exact edgeByCodes c893 c892 m893_892 47390263961951766970624 1192770996018268415212048744704 (by decide) (by decide) (by decide) (by decide)
theorem floor893 : Floor c893 10 := by
  have up := refundEdge e893_892 floor892 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c894 : Chart := ⟨[16640, 17408, 33024, 34816, 66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[2102592, 2103616, 2104576, 2119744, 2135104, 2150464, 2165056, 2181184, 2232320, 2232576, 2281472, 229376, 2360640, 2393152, 2425152, 2474048, 409600, 459008]⟩
def m894_892 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e894_892 : Edge c894 c892 m894_892 := by
  exact edgeByCodes c894 c892 m894_892 47390263961951766970624 1351848718399850144027321303810 (by decide) (by decide) (by decide) (by decide)
theorem floor894 : Floor c894 10 := by
  have up := refundEdge e894_892 floor892 2228288 2232320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c895 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3200, 7424, 18432, 22528, 38016, 67968, 83968, 135552, 168064, 184320, 196992, 229504, 263424, 295936, 376832, 409600, 459008]⟩
def m895_892 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e895_892 : Edge c895 c892 m895_892 := by
  exact edgeByCodes c895 c892 m895_892 52131077189998945174017 1272309861949944563057566155521 (by decide) (by decide) (by decide) (by decide)
theorem floor895 : Floor c895 10 := by
  have up := refundEdge e895_892 floor892 16512 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c896 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3200, 2101696, 2102592, 2103616, 2104576, 2119744, 2135232, 2150464, 2165184, 2181184, 2195648, 2232448, 2232704, 2265216, 2281472, 196992, 229504, 2360640, 2393152, 2425152, 2474048, 409600, 459008]⟩
def m896_895 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e896_895 : Edge c896 c895 m896_895 := by
  exact edgeByCodes c896 c895 m896_895 3727165692135582222409400576 7514230072544521714948594698727809418240 (by decide) (by decide) (by decide) (by decide)
theorem floor896 : Floor c896 11 := by
  have up := refundEdge e896_895 floor895 2228288 2232448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c897 : Chart := ⟨[17408, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[1536, 3584, 7168, 23040, 37888, 83968, 152064, 184320, 229376, 263680, 295936, 376832, 410112, 458752]⟩
def m897_834 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e897_834 : Edge c897 c834 m897_834 := by
  exact edgeByCodes c897 c834 m897_834 166599134359138271745 1033693278377572253517280838401 (by decide) (by decide) (by decide) (by decide)
theorem floor897 : Floor c897 9 := by
  have up := refundEdge e897_834 floor834 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c898 : Chart := ⟨[16512, 17408, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 7168, 18944, 23040, 38016, 67712, 83968, 135808, 152064, 168064, 184320, 229504, 263680, 295936, 376832, 410112, 458752]⟩

end TightRow.Protected.Numeric
