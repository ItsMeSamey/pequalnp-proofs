import NumericEdgeCodes
import Branch519872
import Branch520064
import NumericGraph029
import NumericGraph030
import NumericGraph049
import NumericGraph059
import NumericGraph060
import NumericGraph067
import NumericGraph070
import NumericGraph073
import NumericGraph075
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c912 : Chart := ⟨[8320, 16512, 16640, 17408, 33024, 34816, 66560, 132096, 133120, 262272, 264192],[128, 3200, 11520, 33920, 67968, 76032, 92160, 188416, 196992, 229504, 271616, 304128, 376832, 409600, 467200]⟩
def m912_876 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e912_876 : Edge c912 c876 m912_876 := by
  exact edgeByCodes c912 c876 m912_876 47390263963055590408705 284987427729500958188774487097601 (by decide) (by decide) (by decide) (by decide)
theorem floor912 : Floor c912 10 := by
  have up := refundEdge e912_876 floor876 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c913 : Chart := ⟨[8256, 8320, 16512, 16640, 17408, 33024, 34816, 66560, 131136, 132096, 133120, 262272, 264192],[3200, 9472, 11520, 33984, 68032, 76032, 84032, 92160, 98496, 188416, 196992, 229504, 263488, 271616, 296000, 304128, 328000, 376896, 409600, 467200]⟩
def m913_912 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e913_912 : Edge c913 c912 m913_912 := by
  exact edgeByCodes c913 c912 m913_912 14559240984623143079576065 99020075221833511627862270328045568 (by decide) (by decide) (by decide) (by decide)
theorem floor913 : Floor c913 11 := by
  have up := refundEdge e913_912 floor912 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c914 : Chart := ⟨[8256, 8704, 17408, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 264192],[1536, 3584, 11264, 19008, 84032, 92160, 188416, 229376, 263744, 279104, 296000, 304128, 376896, 410112, 466944]⟩
def m914_844 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e914_844 : Edge c914 c844 m914_844 := by
  exact edgeByCodes c914 c844 m914_844 47390263963055590408448 284987427729482439104532234437377 (by decide) (by decide) (by decide) (by decide)
theorem floor914 : Floor c914 10 := by
  have up := refundEdge e914_844 floor844 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c915 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192],[640, 3712, 11264, 18944, 33920, 67712, 92160, 131712, 188416, 229504, 263680, 304128, 376832, 410112, 466944]⟩
def m915_878 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e915_878 : Edge c915 c878 m915_878 := by
  exact edgeByCodes c915 c878 m915_878 52131149530171783250690 1113232139568363117924917183233 (by decide) (by decide) (by decide) (by decide)
theorem floor915 : Floor c915 10 := by
  have up := refundEdge e915_878 floor878 8320 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c916 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[3712, 11264, 19008, 33984, 67776, 84032, 92160, 98496, 131712, 188416, 229504, 263744, 279104, 296000, 304128, 376896, 410112, 466944]⟩
def m916_915 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e916_915 : Edge c916 c915 m916_915 := by
  exact edgeByCodes c916 c915 m916_915 4037864368590051442463801857 88594757917323922155136752812097536 (by decide) (by decide) (by decide) (by decide)
def m916_914 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e916_914 : Edge c916 c914 m916_914 := by
  exact edgeByCodes c916 c914 m916_914 15768166804520351054430720 88594757919751255565781718490218496 (by decide) (by decide) (by decide) (by decide)
def m916_911 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e916_911 : Edge c916 c911 m916_911 := by
  exact edgeByCodes c916 c911 m916_911 15772907690087462918619392 88594757919741773722309520946954240 (by decide) (by decide) (by decide) (by decide)
def m916_908 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e916_908 : Edge c916 c908 m916_908 := by
  exact edgeByCodes c916 c908 m916_908 15772907617464715592204544 88594757918532847975035064610324480 (by decide) (by decide) (by decide) (by decide)
def m916_905 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e916_905 : Edge c916 c905 m916_905 := by
  exact edgeByCodes c916 c905 m916_905 14554500099337501863444736 88594757919751255565783926170648576 (by decide) (by decide) (by decide) (by decide)
def m916_880 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e916_880 : Edge c916 c880 m916_880 := by
  exact edgeByCodes c916 c880 m916_880 15772907690087467247272963 22680257947917460234050103266571911680 (by decide) (by decide) (by decide) (by decide)
def m916_847 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e916_847 : Edge c916 c847 m916_847 := by
  exact edgeByCodes c916 c847 m916_847 4037864368662391615301746944 5806146055028507586082688857610349772802 (by decide) (by decide) (by decide) (by decide)
def m916_805 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e916_805 : Edge c916 c805 m916_805 := by
  exact edgeByCodes c916 c805 m916_805 4037864368662391606678257920 5806146014542916541293540008236081545219 (by decide) (by decide) (by decide) (by decide)
def m916_718 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e916_718 : Edge c916 c718 m916_718 := by
  exact edgeByCodes c916 c718 m916_718 4037864368661826457701581056 5467192916103664732464823720448016580612 (by decide) (by decide) (by decide) (by decide)
def m916_591 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e916_591 : Edge c916 c591 m916_591 := by
  exact edgeByCodes c916 c591 m916_591 15772852132834727604388096 20026973970796545441543618373403869440 (by decide) (by decide) (by decide) (by decide)
def m916_356 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
theorem e916_356 : Edge c916 c356 m916_356 := by
  exact edgeByCodes c916 c356 m916_356 3416467015609337987117220096 3425467600966484742517391323068264153099 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
