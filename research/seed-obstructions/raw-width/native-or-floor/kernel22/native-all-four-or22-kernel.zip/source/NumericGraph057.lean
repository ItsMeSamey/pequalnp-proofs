import NumericEdgeCodes
import NumericGraph036
import NumericGraph054
import NumericGraph056
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c684 : Chart := ⟨[8256, 8320, 8704, 33280, 34816, 131136, 132096, 133120, 262272, 264192],[2240, 2624, 3712, 11264, 33984, 131200, 131712, 163968, 172032, 263744, 296000, 304128, 393728, 401408]⟩
def m684_680 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e684_680 : Edge c684 c680 m684_680 := by
  exact edgeByCodes c684 c680 m684_680 166599133255314833664 1033693278377572253512969093376 (by decide) (by decide) (by decide) (by decide)
theorem floor684 : Floor c684 9 := by
  have up := refundEdge e684_680 floor680 132096 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c685 : Chart := ⟨[8256, 8320, 8704, 33024, 33280, 34816, 131136, 132096, 133120, 262272, 264192],[2496, 2624, 3712, 11520, 33920, 33984, 131968, 163968, 172032, 264000, 271616, 296000, 304128, 393984, 401664]⟩
def m685_684 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e685_684 : Edge c685 c684 m685_684 := by
  exact edgeByCodes c685 c684 m685_684 47390263963055590342912 284987427724760072622766412660992 (by decide) (by decide) (by decide) (by decide)
theorem floor685 : Floor c685 10 := by
  have up := refundEdge e685_684 floor684 33024 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c686 : Chart := ⟨[2105408, 8704, 33280, 34816, 2228288, 133120, 264192, 2363392],[2103872, 2111488, 2134080, 2232832, 2273280, 2359872, 2392128, 303104, 393728, 401408]⟩
def m686_678 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, some 6]
theorem e686_678 : Edge c686 c678 m686_678 := by
  exact edgeByCodes c686 c678 m686_678 1694364648734976 166599134359138140160 (by decide) (by decide) (by decide) (by decide)
theorem floor686 : Floor c686 7 := by
  have up := refundEdge e686_678 floor678 2363392 2359872 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c687 : Chart := ⟨[2105408, 8320, 8704, 33280, 34816, 2228288, 133120, 262272, 264192, 2363392],[2099392, 2688, 2103872, 2111488, 2134208, 2232960, 2265216, 2273280, 2359872, 2392128, 303104, 393728, 401408]⟩
def m687_680 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, some 6]
theorem e687_680 : Edge c687 c680 m687_680 := by
  exact edgeByCodes c687 c680 m687_680 148080050112590643456 954154417186781389109644558848 (by decide) (by decide) (by decide) (by decide)
theorem floor687 : Floor c687 9 := by
  have up := refundEdge e687_680 floor680 2363392 2359872 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c688 : Chart := ⟨[2105408, 8320, 8704, 33024, 33280, 34816, 2228288, 133120, 262272, 264192, 2363392],[2099648, 2688, 2101696, 2102080, 2103616, 2103872, 2111744, 32896, 2134208, 2233216, 2240768, 2265216, 2273280, 2360128, 2392128, 303104, 393984, 401664]⟩
def m688_687 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, none, some 17, some 18, none, none, some 21]
theorem e688_687 : Edge c688 c687 m688_687 := by
  exact edgeByCodes c688 c687 m688_687 47390263963055590342912 1351848723140735710043985740032 (by decide) (by decide) (by decide) (by decide)
theorem floor688 : Floor c688 10 := by
  have up := refundEdge e688_687 floor687 33024 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c689 : Chart := ⟨[8196, 2105408, 8320, 8704, 33024, 33280, 34816, 2228288, 133120, 262272, 264192, 2363392],[2099524, 2436, 2099648, 2688, 2101696, 2102080, 2103364, 2103616, 2103812, 2103872, 8448, 2111744, 2134084, 2134208, 131460, 2232836, 2233216, 2240768, 2265220, 2273280, 2359620, 2360128, 2392132, 303104, 393988, 401664]⟩
def m689_688 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, none, some 15, none, some 17, some 18, none, none, some 21]
theorem e689_688 : Edge c689 c688 m689_688 := by
  exact edgeByCodes c689 c688 m689_688 13345574279723976512176641 2186004612001984158242173523605832847328002 (by decide) (by decide) (by decide) (by decide)
theorem floor689 : Floor c689 11 := by
  have up := refundEdge e689_688 floor688 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c690 : Chart := ⟨[8196, 2105408, 1056896, 8704, 33024, 33280, 34816, 1179649, 2228288, 133120, 1310848, 264192, 2363392],[3146177, 1049473, 1050757, 2099524, 1051009, 1051012, 3148224, 1051141, 1051265, 3150272, 3150401, 3150465, 2102080, 2103364, 2103616, 3152385, 2103812, 2103872, 1059073, 3160065, 2111744, 1081477, 2134084, 3182785, 3190785, 1180032, 1180036, 2232836, 3281792, 2240768, 3313796, 2273280, 2359620, 1311237, 3408705, 1319169, 3440709, 1351681, 393988, 401664]⟩
def m690_689 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, none, some 15, none, some 17, some 18, none, some 7, some 21]
theorem e690_689 : Edge c690 c689 m690_689 := by
  exact edgeByCodes c690 c689 m690_689 3727165692135582222409400576 62910024290288330123611200658398135661915274201604195535422723 (by decide) (by decide) (by decide) (by decide)
theorem floor690 : Floor c690 12 := by
  have up := refundEdge e690_689 floor689 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 12 ≤ 12).trans (up k x net fit)
def c691 : Chart := ⟨[2105408, 8320, 8704, 33280, 34816, 2228288, 132096, 133120, 262272, 264192, 2363392],[2099392, 3712, 2103872, 2112512, 2135232, 2143232, 131200, 2232960, 2265216, 2273280, 2360896, 2393152, 304128, 393728, 401408]⟩
def m691_687 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, none, some 17, some 18, none, none, some 21]
theorem e691_687 : Edge c691 c687 m691_687 := by
  exact edgeByCodes c691 c687 m691_687 47390263961951766970624 1113232139568363117916293562624 (by decide) (by decide) (by decide) (by decide)
theorem floor691 : Floor c691 10 := by
  have up := refundEdge e691_687 floor687 132096 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c692 : Chart := ⟨[16512, 16640, 33024, 34816, 133120, 262272, 264192],[2432, 18432, 131456, 163968, 180224, 311296, 393472, 409600]⟩
def m692_435 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e692_435 : Edge c692 c435 m692_435 := by
  exact edgeByCodes c692 c435 m692_435 6618595066112 21575696640 (by decide) (by decide) (by decide) (by decide)
theorem floor692 : Floor c692 6 := by
  have up := refundEdge e692_435 floor435 133120 2432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c693 : Chart := ⟨[1065088, 16640, 33024, 34816, 1179649, 133120, 1310848, 264192],[1051009, 1067009, 1081473, 1180032, 1212544, 180224, 1310977, 1359873, 393472, 409600]⟩
def m693_692 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, some 18, none, some 7, none]
theorem e693_692 : Edge c693 c692 m693_692 := by
  exact edgeByCodes c693 c692 m693_692 1976943432040704 650777864278573312 (by decide) (by decide) (by decide) (by decide)
theorem floor693 : Floor c693 7 := by
  have up := refundEdge e693_692 floor692 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c694 : Chart := ⟨[16512, 16640, 33024, 34816, 131136, 133120, 262272, 264192],[2496, 18496, 32960, 131456, 163968, 180224, 262464, 311360, 393472, 409600]⟩
def m694_692 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e694_692 : Edge c694 c692 m694_692 := by
  exact edgeByCodes c694 c692 m694_692 1976943432040704 650777864278573312 (by decide) (by decide) (by decide) (by decide)
theorem floor694 : Floor c694 7 := by
  have up := refundEdge e694_692 floor692 131136 131456 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c695 : Chart := ⟨[16512, 17408, 34816, 132096, 133120, 262272, 264192],[2176, 3200, 18432, 33920, 163968, 180224, 295936, 311296, 409600]⟩
def m695_650 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
theorem e695_650 : Edge c695 c650 m695_650 := by
  exact edgeByCodes c695 c650 m695_650 6618611908864 34460664321 (by decide) (by decide) (by decide) (by decide)
theorem floor695 : Floor c695 6 := by
  have up := refundEdge e695_650 floor650 34816 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)


end TightRow.Protected.Numeric
