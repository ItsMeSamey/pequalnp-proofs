import NumericEdgeCodes
import Branch507584
import NumericGraph027
import NumericGraph045
import NumericGraph057
import NumericGraph058
import NumericGraph065
import NumericGraph069
import NumericGraph070
import NumericGraph071
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c864 : Chart := ⟨[2105408, 8704, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[3584, 2103872, 2110464, 2112512, 2135104, 2143232, 2164800, 75776, 2232832, 2273280, 229376, 2360896, 2393152, 304128, 2457664, 393728, 466944]⟩
def m864_861 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e864_861 : Edge c864 c861 m864_861 := by
  exact edgeByCodes c864 c861 m864_861 52131149529067959812609 325711324654444995198368052477952 (by decide) (by decide) (by decide) (by decide)
theorem floor864 : Floor c864 10 := by
  have up := refundEdge e864_861 floor861 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c865 : Chart := ⟨[8320, 8704, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 6656, 9216, 15360, 38016, 46080, 67712, 75776, 135808, 168064, 176128, 229504, 263680, 304128, 360448, 393728, 466944]⟩
def m865_861 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e865_861 : Edge c865 c861 m865_861 := by
  exact edgeByCodes c865 c861 m865_861 52131077189998945174017 325711324659185880482905445171200 (by decide) (by decide) (by decide) (by decide)
theorem floor865 : Floor c865 10 := by
  have up := refundEdge e865_861 floor861 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c866 : Chart := ⟨[2105408, 8320, 8704, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2103872, 2112512, 2135232, 2143232, 2164928, 75776, 2195648, 2232960, 2265216, 2273280, 229504, 2360896, 2393152, 304128, 2457664, 393728, 466944]⟩
def m866_865 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e866_865 : Edge c866 c865 m866_865 := by
  exact edgeByCodes c866 c865 m866_865 4037864368662109036501729793 5806146054949279423568352180947808026880 (by decide) (by decide) (by decide) (by decide)
def m866_864 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e866_864 : Edge c866 c864 m866_864 := by
  exact edgeByCodes c866 c864 m866_864 4037859627776824499109036544 5806146055028818284740623961108896678144 (by decide) (by decide) (by decide) (by decide)
def m866_856 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e866_856 : Edge c866 c856 m866_856 := by
  exact edgeByCodes c866 c856 m866_856 4037864368590050338640363776 5806146054949279423568424521116334293248 (by decide) (by decide) (by decide) (by decide)
def m866_847 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, some 6]
theorem e866_847 : Edge c866 c847 m866_847 := by
  exact edgeByCodes c866 c847 m866_847 3727165692135582222409400576 5806146055028818284740696301277422944257 (by decide) (by decide) (by decide) (by decide)
def m866_836 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e866_836 : Edge c866 c836 m866_836 := by
  exact edgeByCodes c866 c836 m866_836 15772907690087467247272963 88594757609052560520455440002318592 (by decide) (by decide) (by decide) (by decide)
def m866_782 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e866_782 : Edge c866 c782 m866_782 := by
  exact edgeByCodes c866 c782 m866_782 4037864368662391615301746944 88594757918537588787979420558230272 (by decide) (by decide) (by decide) (by decide)
def m866_691 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, none, some 15, none, some 17, some 18, none, none, some 21]
theorem e866_691 : Edge c866 c691 m866_691 := by
  exact edgeByCodes c866 c691 m866_691 15772907690087454311842048 88594678380885323889631669671493637 (by decide) (by decide) (by decide) (by decide)
def m866_549 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, none, some 18, none, none, some 21]
theorem e866_549 : Edge c866 c549 m866_549 := by
  exact edgeByCodes c866 c549 m866_549 15772907473066948733042944 78230367073405097646014008372824064 (by decide) (by decide) (by decide) (by decide)
def m866_330 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, none, none, none, some 21]
theorem e866_330 : Edge c866 c330 m866_330 := by
  exact edgeByCodes c866 c330 m866_330 12131907574542231144628480 57460861483839987510702857282191372 (by decide) (by decide) (by decide) (by decide)
theorem floor866 : Floor c866 12 := by
  apply protectedBranch source c866.P c866.N (decode 505024) 12
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 505024, q = 6 ∨ q = 7 ∨ q = 10 ∨ q = 12 ∨ q = 13 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e866_865 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor865 k x net fit)
    · refine ⟨_,goodChild e866_864 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor864 k x net fit)
    · refine ⟨_,goodChild e866_856 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor856 k x net fit)
    · refine ⟨_,goodChild e866_847 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor847 k x net fit)
    · refine ⟨_,goodChild e866_836 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor836 k x net fit)
    · refine ⟨_,goodChild e866_782 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor782 k x net fit)
    · refine ⟨_,goodChild e866_691 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor691 k x net fit)
    · refine ⟨_,goodChild e866_549 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor549 k x net fit)
    · refine ⟨_,goodChild e866_330 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor330 k x net fit)
  · exact pairExcluded 507584 505024 [8256, 8320, 8704, 33280, 34816, 66048, 66560, 69632, 131136, 132096, 133120, 262272, 264192, 266240] [3712, 6720, 15360, 38080, 46080, 67776, 75776, 98496, 135808, 168064, 176128, 229504, 263744, 296000, 304128, 360512, 393728, 466944] validBranch507584 (by decide) (by decide) (by decide)
def c867 : Chart := ⟨[8704, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[3584, 6656, 15616, 33792, 46080, 76032, 135936, 143616, 176128, 229376, 263936, 271616, 304128, 360448, 393984, 467200]⟩
def m867_861 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e867_861 : Edge c867 c861 m867_861 := by
  exact edgeByCodes c867 c861 m867_861 47390263963055590408704 305349376189602533627438676639744 (by decide) (by decide) (by decide) (by decide)
theorem floor867 : Floor c867 10 := by
  have up := refundEdge e867_861 floor861 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c868 : Chart := ⟨[8196, 8704, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[3332, 3588, 6660, 7172, 9472, 15616, 37892, 46080, 67844, 76032, 135684, 135936, 143616, 167940, 176128, 229380, 263940, 271616, 295940, 304128, 360452, 393988, 459012, 467200]⟩
def m868_867 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e868_867 : Edge c868 c867 m868_867 := by
  exact edgeByCodes c868 c867 m868_867 13345574279723976512176641 30681689295890116336113753622420193793 (by decide) (by decide) (by decide) (by decide)
theorem floor868 : Floor c868 11 := by
  have up := refundEdge e868_867 floor867 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c869 : Chart := ⟨[2105408, 8704, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[3584, 2102080, 2102592, 2103616, 2103872, 2110464, 2112768, 2135104, 2143232, 2165056, 76032, 2233088, 2240768, 2273280, 229376, 2361152, 271616, 2393152, 304128, 2425152, 2457664, 393984, 467200]⟩
def m869_867 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e869_867 : Edge c869 c867 m869_867 := by
  exact edgeByCodes c869 c867 m869_867 14559240984623143079576065 29352461220566339272491423431165084672 (by decide) (by decide) (by decide) (by decide)
theorem floor869 : Floor c869 11 := by
  have up := refundEdge e869_867 floor867 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)

end TightRow.Protected.Numeric
