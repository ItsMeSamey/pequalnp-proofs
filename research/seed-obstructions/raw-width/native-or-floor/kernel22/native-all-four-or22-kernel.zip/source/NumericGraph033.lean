import NumericGraph032
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c396 : Chart := ⟨[16512, 262272],[128, 278528]⟩
def m396_384 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, none, none, none, none, none, some 18, none, none, none]
private theorem e396_384 : Edge c396 c384 m396_384 := by constructor <;> decide
theorem floor396 : Floor c396 1 := by
  have up := refundEdge e396_384 floor384 16512 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c397 : Chart := ⟨[16512, 16640, 262272],[384, 16384, 262400, 278528]⟩
def m397_396 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e397_396 : Edge c397 c396 m397_396 := by constructor <;> decide
theorem floor397 : Floor c397 2 := by
  have up := refundEdge e397_396 floor396 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c398 : Chart := ⟨[16512, 17408, 262272],[1152, 16384, 263168, 278528]⟩
def m398_396 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e398_396 : Edge c398 c396 m398_396 := by constructor <;> decide
theorem floor398 : Floor c398 2 := by
  have up := refundEdge e398_396 floor396 17408 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c399 : Chart := ⟨[16512, 262272, 264192],[2176, 18432, 262144, 278528]⟩
def m399_396 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e399_396 : Edge c399 c396 m399_396 := by constructor <;> decide
theorem floor399 : Floor c399 2 := by
  have up := refundEdge e399_396 floor396 264192 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c400 : Chart := ⟨[16512, 16640, 262272, 264192],[2432, 18432, 262400, 278528]⟩
def m400_399 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e400_399 : Edge c400 c399 m400_399 := by constructor <;> decide
theorem floor400 : Floor c400 3 := by
  have up := refundEdge e400_399 floor399 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c401 : Chart := ⟨[16512, 17408, 262272, 264192],[3200, 18432, 263168, 278528]⟩
def m401_399 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e401_399 : Edge c401 c399 m401_399 := by constructor <;> decide
theorem floor401 : Floor c401 3 := by
  have up := refundEdge e401_399 floor399 17408 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c402 : Chart := ⟨[16512, 262272, 266240],[4224, 20480, 262144, 278528]⟩
def m402_396 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e402_396 : Edge c402 c396 m402_396 := by constructor <;> decide
theorem floor402 : Floor c402 2 := by
  have up := refundEdge e402_396 floor396 266240 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c403 : Chart := ⟨[16512, 16640, 262272, 266240],[4480, 16384, 20480, 262400, 278528]⟩
def m403_402 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, none, some 14, none, none, none, some 18, none, none, none]
private theorem e403_402 : Edge c403 c402 m403_402 := by constructor <;> decide
theorem floor403 : Floor c403 3 := by
  have up := refundEdge e403_402 floor402 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c404 : Chart := ⟨[16512, 17408, 262272, 266240],[5248, 16384, 20480, 263168, 278528]⟩
def m404_402 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, none, some 14, none, none, none, some 18, none, none, none]
private theorem e404_402 : Edge c404 c402 m404_402 := by constructor <;> decide
theorem floor404 : Floor c404 3 := by
  have up := refundEdge e404_402 floor402 17408 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c405 : Chart := ⟨[34816, 264192],[2048, 294912]⟩
def m405_385 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, none, none, none, some 18, none, none, none]
private theorem e405_385 : Edge c405 c385 m405_385 := by constructor <;> decide
theorem floor405 : Floor c405 1 := by
  have up := refundEdge e405_385 floor385 34816 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c406 : Chart := ⟨[34816, 262272, 264192],[2176, 32896, 262144, 294912]⟩
def m406_405 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e406_405 : Edge c406 c405 m406_405 := by constructor <;> decide
theorem floor406 : Floor c406 2 := by
  have up := refundEdge e406_405 floor405 262272 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c407 : Chart := ⟨[33024, 34816, 264192],[2304, 32768, 262400, 294912]⟩
def m407_405 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e407_405 : Edge c407 c405 m407_405 := by constructor <;> decide
theorem floor407 : Floor c407 2 := by
  have up := refundEdge e407_405 floor405 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)

end TightRow.Protected.Numeric
