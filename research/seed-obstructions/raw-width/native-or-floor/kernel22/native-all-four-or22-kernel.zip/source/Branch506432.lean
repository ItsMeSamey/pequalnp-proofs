import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short506432
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8704, 33280, 34816, 66048, 69632, 131136, 133120, 264192, 266240]
def n : List Nat := [6720, 14336, 36928, 67648, 75776, 135680, 176128, 229376, 262720, 303104, 360512, 393728, 466944]
def pp := p.map (canonical 506432)
def nn := n.map (canonical 506432)
def parts : List Nat := [0, 64, 4096, 8192, 32768, 65536, 131072, 262144, 8256, 69632, 131136, 266240]
def g : ShortGrid := [(0,[(64,5709077884439019562991072202916913245033857281), (4096,7324746925735262099308219949511155725038816396033), (8192,1), (8256,256), (32768,2923047876832778016247705476368179567442471813121), (65536,5846095753665556032495410952736359134884943626241), (69632,17179870208), (131072,8769143630498334048743116429104538702327415439361), (131136,25769869312), (262144,11692191507331112064990821905472718269769887252481), (266240,34359936256)]), (64,[(4096,21525233664), (8192,1099511627776), (32768,8590000128), (65536,17179934720), (69632,17179934720), (131072,25769869312), (262144,34359803904), (266240,34359803904)]), (4096,[(8192,197888), (8256,256), (32768,8590132480), (65536,1410690598307072), (131072,25770001664), (131136,65536), (262144,34359936256)]), (8192,[(32768,12901679104), (65536,21491613696), (69632,21491613696), (131072,30081548288), (131136,16777216), (262144,34376515584), (266240,34376515584)]), (8256,[(32768,256), (65536,256), (69632,256), (131072,256), (262144,256), (266240,256)]), (32768,[(65536,847723465016576), (69632,1024), (131072,568447511561728), (131136,65536), (262144,571746046445824), (266240,197888)]), (65536,[(131072,25820136704), (131136,65536), (262144,34410071296), (266240,21525169408)]), (69632,[(131072,1024), (131136,65536), (262144,1024)]), (131072,[(262144,38738593280), (266240,197888)]), (131136,[(262144,65536), (266240,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 503872 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 503872 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 503872 4096) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 503872 8192) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 503872 32768) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 503872 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 503872 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 503872 262144) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 503872 8256) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 503872 69632) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 503872 131136) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 503872 266240) = true := by decide
theorem full : checkArms 506432 503872 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 4096, 8192, 32768, 65536, 131072, 262144, 8256, 69632, 131136, 266240] : List Nat).all (fun i => parts.all (shortPair g pp nn 503872 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short506432
theorem validBranch506432 : checkArms 506432 503872 [8256, 8704, 33280, 34816, 66048, 69632, 131136, 133120, 264192, 266240] [6720, 14336, 36928, 67648, 75776, 135680, 176128, 229376, 262720, 303104, 360512, 393728, 466944] = true := Short506432.full
end TightRow.Protected.Numeric
