import NumericEdgeCodes
import NumericGraph073Code00
import Branch511616
import NumericGraph028
import NumericGraph046
import NumericGraph047
import NumericGraph048
import NumericGraph058
import NumericGraph065
import NumericGraph068
import NumericGraph069
import NumericGraph072
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem floor886 : Floor c886 11 := by
  have up := refundEdge e886_884 floor884 2228288 2232448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c887 : Chart := ⟨[16512, 16640, 33024, 33280, 34816, 66048, 69632, 133120, 262272, 264192, 266240],[2432, 2688, 6400, 23040, 67968, 83968, 136064, 152064, 168064, 184320, 196992, 229504, 376832, 393984, 410112, 459008]⟩
def m887_576 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e887_576 : Edge c887 c576 m887_576 := by
  exact edgeByCodes c887 c576 m887_576 47390263680476790259968 955397211874006717878149187073 (by decide) (by decide) (by decide) (by decide)
theorem floor887 : Floor c887 10 := by
  have up := refundEdge e887_576 floor576 133120 2432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)


end TightRow.Protected.Numeric
