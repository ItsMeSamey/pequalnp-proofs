import NumericEdgeCodes
import Branch487040
import NumericGraph023
import NumericGraph024
import NumericGraph042
import NumericGraph054
import NumericGraph055
import NumericGraph063
import NumericGraph065
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c792 : Chart := ⟨[16640, 17408, 66560, 69632, 132096, 133120, 264192, 266240],[7424, 18432, 22528, 67840, 83968, 135424, 151552, 263424, 344064, 409600, 459008]⟩
def m792_790 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e792_790 : Edge c792 c790 m792_790 := by
  exact edgeByCodes c792 c790 m792_790 1976943448883713 185118218605668990976 (by decide) (by decide) (by decide) (by decide)
theorem floor792 : Floor c792 7 := by
  have up := refundEdge e792_790 floor790 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c793 : Chart := ⟨[16512, 16640, 17408, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3200, 5248, 7424, 18432, 22528, 67968, 83968, 135552, 151552, 196992, 263424, 344064, 409600, 459008]⟩
def m793_791 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e793_791 : Edge c793 c791 m793_791 := by
  exact edgeByCodes c793 c791 m793_791 166599134359138271744 1033693278377572253517280837888 (by decide) (by decide) (by decide) (by decide)
theorem floor793 : Floor c793 9 := by
  have up := refundEdge e793_791 floor791 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c794 : Chart := ⟨[1065088, 16640, 17408, 66560, 69632, 1179649, 132096, 133120, 1310848, 264192, 266240],[1051776, 1053825, 7424, 1071105, 1116545, 1132545, 1180032, 1184128, 151552, 1245568, 1312001, 1376513, 1392641, 409600, 459008]⟩
def m794_793 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, some 7, none]
theorem e794_793 : Edge c794 c793 m794_793 := by
  exact edgeByCodes c794 c793 m794_793 47390263963051278598400 284987426515834252724454648054016 (by decide) (by decide) (by decide) (by decide)
theorem floor794 : Floor c794 10 := by
  have up := refundEdge e794_793 floor793 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c795 : Chart := ⟨[16512, 17408, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 5248, 7168, 23040, 65664, 67712, 83968, 135808, 152064, 196736, 263680, 344064, 410112, 458752]⟩
def m795_791 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e795_791 : Edge c795 c791 m795_791 := by
  exact edgeByCodes c795 c791 m795_791 166599134359138271488 1033693278377572253517264060672 (by decide) (by decide) (by decide) (by decide)
theorem floor795 : Floor c795 9 := by
  have up := refundEdge e795_791 floor791 66048 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c796 : Chart := ⟨[16512, 17408, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2102464, 2104320, 2120256, 2164928, 2181184, 2232448, 2232960, 2249216, 196736, 2360896, 2376256, 2441280, 410112, 458752]⟩
def m796_795 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, some 12]
theorem e796_795 : Edge c796 c795 m796_795 := by
  exact edgeByCodes c796 c795 m796_795 47390263963051278598400 284987426515834252724458943021312 (by decide) (by decide) (by decide) (by decide)
theorem floor796 : Floor c796 10 := by
  have up := refundEdge e796_795 floor795 2228288 2232448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c797 : Chart := ⟨[16512, 16640, 17408, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 5248, 7424, 18944, 23040, 67968, 83968, 136064, 152064, 196992, 263936, 344064, 393984, 410112, 459008]⟩
def m797_795 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e797_795 : Edge c797 c795 m797_795 := by
  exact edgeByCodes c797 c795 m797_795 47390263963055590408704 284987117030824431661969018323200 (by decide) (by decide) (by decide) (by decide)
theorem floor797 : Floor c797 10 := by
  have up := refundEdge e797_795 floor795 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c798 : Chart := ⟨[8256, 8320, 16512, 17408, 66560, 131136, 132096, 262272],[1152, 1216, 65728, 90112, 155648, 196736, 263232, 271360, 344128, 409600, 466944]⟩
def m798_659 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e798_659 : Edge c798 c659 m798_659 := by
  exact edgeByCodes c798 c659 m798_659 1976943432040704 166743532125997564160 (by decide) (by decide) (by decide) (by decide)
theorem floor798 : Floor c798 7 := by
  have up := refundEdge e798_659 floor659 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c799 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 132096, 262272],[1664, 90112, 131712, 155648, 196736, 263680, 271360, 344064, 410112, 466944]⟩
def m799_506 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e799_506 : Edge c799 c506 m799_506 := by
  exact edgeByCodes c799 c506 m799_506 1975839625445632 129777985280683540480 (by decide) (by decide) (by decide) (by decide)
theorem floor799 : Floor c799 7 := by
  have up := refundEdge e799_506 floor506 132096 1664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c800 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 66048, 66560, 131136, 132096, 262272],[640, 1216, 1664, 65728, 90112, 131712, 155648, 196736, 263744, 271360, 279104, 344128, 410112, 466944]⟩
def m800_284 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
theorem e800_284 : Edge c800 c284 m800_284 := by
  exact edgeByCodes c800 c284 m800_284 148080050112590643456 1032139818070026336719014594561 (by decide) (by decide) (by decide) (by decide)
theorem floor800 : Floor c800 9 := by
  have up := refundEdge e800_284 floor284 262272 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c801 : Chart := ⟨[8320, 16512, 17408, 66560, 132096, 133120, 262272, 264192],[128, 3200, 11264, 67712, 92160, 155648, 196736, 271360, 344064, 409600, 466944]⟩
def m801_785 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e801_785 : Edge c801 c785 m801_785 := by
  exact edgeByCodes c801 c785 m801_785 1976943448883713 185118218605669056769 (by decide) (by decide) (by decide) (by decide)
theorem floor801 : Floor c801 7 := by
  have up := refundEdge e801_785 floor785 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c802 : Chart := ⟨[8256, 8320, 16512, 17408, 66560, 131136, 132096, 133120, 262272, 264192],[1152, 1216, 3200, 11264, 67776, 84032, 92160, 155648, 196736, 263232, 271360, 344128, 409600, 466944]⟩
def m802_663 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e802_663 : Edge c802 c663 m802_663 := by
  exact edgeByCodes c802 c663 m802_663 166599134359121428736 954774600873057484873383674881 (by decide) (by decide) (by decide) (by decide)
theorem floor802 : Floor c802 9 := by
  have up := refundEdge e802_663 floor663 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c803 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 132096, 133120, 262272, 264192],[3712, 11264, 18944, 67712, 92160, 131712, 155648, 196736, 263680, 271360, 344064, 410112, 466944]⟩
def m803_801 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e803_801 : Edge c803 c801 m803_801 := by
  exact edgeByCodes c803 c801 m803_801 650777868590318080 14559240984623138767699968 (by decide) (by decide) (by decide) (by decide)
def m803_799 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e803_799 : Edge c803 c799 m803_799 := by
  exact edgeByCodes c803 c799 m803_799 578155116952158464 56872035097287976092672 (by decide) (by decide) (by decide) (by decide)
def m803_786 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e803_786 : Edge c803 c786 m803_786 := by
  exact edgeByCodes c803 c786 m803_786 650777868590383874 14559240912564445218275840 (by decide) (by decide) (by decide) (by decide)
def m803_763 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e803_763 : Edge c803 c763 m803_763 := by
  exact edgeByCodes c803 c763 m803_763 650777868590383360 56871962757110826205440 (by decide) (by decide) (by decide) (by decide)
def m803_666 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e803_666 : Edge c803 c666 m803_666 := by
  exact edgeByCodes c803 c666 m803_666 650777868556697856 13355019012407136985612544 (by decide) (by decide) (by decide) (by decide)
def m803_507 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e803_507 : Edge c803 c507 m803_507 := by
  exact edgeByCodes c803 c507 m803_507 650775660943507712 12146130158904497773084928 (by decide) (by decide) (by decide) (by decide)
def m803_289 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
theorem e803_289 : Edge c803 c289 m803_289 := by
  exact edgeByCodes c803 c289 m803_289 506097522914230528 14540277875266503959511296 (by decide) (by decide) (by decide) (by decide)
theorem floor803 : Floor c803 9 := by
  apply protectedBranch source c803.P c803.N (decode 485888) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 485888, q = 9 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e803_801 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor801 k x net fit)
    · refine ⟨_,goodChild e803_799 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor799 k x net fit)
    · refine ⟨_,goodChild e803_786 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor786 k x net fit)
    · refine ⟨_,goodChild e803_763 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor763 k x net fit)
    · refine ⟨_,goodChild e803_666 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor666 k x net fit)
    · refine ⟨_,goodChild e803_507 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor507 k x net fit)
    · refine ⟨_,goodChild e803_289 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor289 k x net fit)
  · exact pairExcluded 487040 485888 [8320, 8704, 16512, 17408, 66048, 66560, 132096, 133120, 262272, 264192] [3712, 11264, 18944, 67712, 92160, 131712, 155648, 196736, 263680, 271360, 344064, 410112, 466944] validBranch487040 (by decide) (by decide) (by decide)


end TightRow.Protected.Numeric
