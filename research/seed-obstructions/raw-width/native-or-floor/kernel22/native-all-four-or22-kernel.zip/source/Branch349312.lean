import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short349312
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16512, 17408, 66560, 69632, 262272, 266240]
def n : List Nat := [5248, 20480, 65664, 263168, 344064]
def pp := p.map (canonical 349312)
def nn := n.map (canonical 349312)
def parts : List Nat := [0, 128, 1024, 4096, 16384, 65536, 262144, 16512, 17408, 66560, 69632, 262272, 266240]
def g : ShortGrid := [(0,[(128,309489732259886631936327937), (1024,79538861190790864407636279553), (4096,238307093840112706590972510721), (16384,1), (16512,256), (17408,0), (65536,158458742917061955551399903233), (66560,8590000384), (69632,8589935104), (262144,316917485834123911102799806465), (262272,17179934720), (266240,17180001024)]), (128,[(1024,8623554560), (4096,12918521856), (16384,1099511627776), (17408,0), (65536,8590000128), (66560,8590000128), (69632,8590000128), (262144,17179934720), (266240,17179934720)]), (1024,[(4096,21525233920), (16384,282574488338432), (16512,256), (65536,8590000384), (69632,8590000384), (262144,17179934976), (262272,65536), (266240,17179934976)]), (4096,[(16384,848822976643072), (16512,256), (17408,0), (65536,846623953388032), (66560,65792), (262144,17180001024), (262272,65536)]), (16384,[(65536,12901679104), (66560,4311744512), (69632,12901679104), (262144,21491613696), (262272,16777216), (266240,21491613696)]), (16512,[(65536,256), (66560,256), (69632,256), (262144,256), (266240,256)]), (17408,[(65536,0), (69632,0), (262144,0), (262272,0), (266240,0)]), (65536,[(262144,17213424128), (262272,65536), (266240,12918456832)]), (66560,[(262144,65792), (262272,65536), (266240,65792)]), (69632,[(262144,512), (262272,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 349312 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 349312 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 349312 1024) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 349312 4096) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 349312 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 349312 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 349312 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 349312 16512) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 349312 17408) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 349312 66560) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 349312 69632) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 349312 262272) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 349312 266240) = true := by decide
theorem full : checkArms 349312 349312 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 1024, 4096, 16384, 65536, 262144, 16512, 17408, 66560, 69632, 262272, 266240] : List Nat).all (fun i => parts.all (shortPair g pp nn 349312 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short349312
theorem validBranch349312 : checkArms 349312 349312 [16512, 17408, 66560, 69632, 262272, 266240] [5248, 20480, 65664, 263168, 344064] = true := Short349312.full
end TightRow.Protected.Numeric
