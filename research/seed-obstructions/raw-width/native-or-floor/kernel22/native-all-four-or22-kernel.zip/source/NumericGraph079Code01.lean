import NumericEdgeCodes
import NumericGraph079Code00
import Branch524096
import Branch524224
import NumericGraph031
import NumericGraph050
import NumericGraph051
import NumericGraph060
import NumericGraph061
import NumericGraph068
import NumericGraph072
import NumericGraph075
import NumericGraph076
import NumericGraph077
import NumericGraph078
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem floor948 : Floor c948 13 := by
  apply protectedBranch source c948.P c948.N (decode 491328) 13
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 491328, q = 6 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 14 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e948_947 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor947 k x net fit)
    · refine ⟨_,goodChild e948_944 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor944 k x net fit)
    · refine ⟨_,goodChild e948_940 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor940 k x net fit)
    · refine ⟨_,goodChild e948_933 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor933 k x net fit)
    · refine ⟨_,goodChild e948_927 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor927 k x net fit)
    · refine ⟨_,goodChild e948_919 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor919 k x net fit)
    · refine ⟨_,goodChild e948_901 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor901 k x net fit)
    · refine ⟨_,goodChild e948_869 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor869 k x net fit)
    · refine ⟨_,goodChild e948_730 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor730 k x net fit)
    · refine ⟨_,goodChild e948_611 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor611 k x net fit)
    · refine ⟨_,goodChild e948_379 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor379 k x net fit)
  · exact pairExcluded 524096 491328 [8256, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 131136, 132096, 133120, 264192, 266240] [3584, 4928, 5440, 6464, 15616, 23104, 30720, 37952, 46080, 53312, 67904, 76032, 84032, 92160, 135936, 143616, 152064, 192512, 229376, 264000, 271616, 279104, 296000, 304128, 328000, 376896, 393984, 410112, 467200] validBranch524096 (by decide) (by decide) (by decide)
def c949 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 15616, 18944, 23040, 30720, 38016, 46080, 67968, 76032, 92160, 136064, 143616, 152064, 168064, 192512, 196992, 229504, 263936, 271616, 304128, 376832, 393984, 410112, 467200]⟩
def m949_945 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e949_945 : Edge c949 c945 m949_945 := by
  exact edgeByCodes c949 c945 m949_945 305349376194343419477133669564672 2011095472062375291973060244302590013276416 (by decide) (by decide) (by decide) (by decide)
theorem floor949 : Floor c949 13 := by
  have up := refundEdge e949_945 floor945 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c950 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2101696, 2102080, 2102592, 2103616, 2112768, 2120256, 2127872, 2135232, 2143232, 2150464, 2165184, 76032, 2181184, 92160, 2195648, 2233216, 2240768, 2249216, 2265216, 2289664, 196992, 229504, 2361152, 271616, 2376256, 2393152, 304128, 2425152, 2474048, 393984, 410112, 467200]⟩
def m950_949 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e950_949 : Edge c950 c949 m950_949 := by
  exact edgeByCodes c950 c949 m950_949 22680258027455107758135503354352304641 787618193904564918866954332974272225202283477150986536192 (by decide) (by decide) (by decide) (by decide)
def m950_948 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e950_948 : Edge c950 c948 m950_948 := by
  exact edgeByCodes c950 c948 m950_948 88594678380890064774919518534500864 865995362452352325131567444438436709060925100208001624058397240525312 (by decide) (by decide) (by decide) (by decide)
def m950_946 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e950_946 : Edge c950 c946 m950_946 := by
  exact edgeByCodes c950 c946 m950_946 22680258027456321424840685095391199488 787617816831455797467041686788363004248840433112224957696 (by decide) (by decide) (by decide) (by decide)
def m950_942 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e950_942 : Edge c950 c942 m950_942 := by
  exact edgeByCodes c950 c942 m950_942 88594757919751255565500243547193600 865994949462973136593860182673932112197153204913994594459344882041088 (by decide) (by decide) (by decide) (by decide)
def m950_935 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e950_935 : Edge c950 c935 m950_935 := by
  exact edgeByCodes c950 c935 m950_935 88594757918537570341517929943793920 865995362452352228599372836062154631055848851756534523971888090317056 (by decide) (by decide) (by decide) (by decide)
def m950_929 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e950_929 : Edge c950 c929 m950_929 := by
  exact edgeByCodes c950 c929 m950_929 88574316432425222241290990808858880 865995362452352325131567444526232228628198356067998950180635094941952 (by decide) (by decide) (by decide) (by decide)
def m950_921 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 6]
theorem e950_921 : Edge c950 c921 m950_921 := by
  exact edgeByCodes c950 c921 m950_921 21345817372863192215141877442855174400 787618193910341074235081982375257416884991999105615332608 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
