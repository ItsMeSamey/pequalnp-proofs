import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short358016
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 16512, 17408, 66048, 66560, 69632, 262272, 266240]
def n : List Nat := [1664, 4736, 5248, 13312, 20992, 28672, 65664, 90112, 263680, 271360, 279040, 335872, 344064]
def pp := p.map (canonical 358016)
def nn := n.map (canonical 358016)
def parts : List Nat := [0, 512, 1024, 4096, 8192, 16384, 262144, 8704, 17408, 266240]
def g : ShortGrid := [(0,[(512,22563451182052763011010073555919595311990273), (1024,67252394152605066567097902053636226842691073), (4096,134329194607619753511368091242305424600729089), (8192,121696314560303149511313727684609), (8704,0), (16384,44602170972301536650371238763039444334411777), (17408,8589935104), (262144,156107598402751137489898577796859770851229697), (266240,25870861824)]), (512,[(1024,12952207616), (4096,34494152960), (8192,284773511594240), (16384,8590131456), (17408,8590131456), (262144,30064967936), (266240,30064967936)]), (1024,[(4096,34494219008), (8192,849922488271104), (8704,0), (16384,848831566578432), (262144,30065033984), (266240,30065033984)]), (4096,[(8192,1696546441658624), (8704,0), (16384,1696546441659136), (17408,512), (262144,2260625988257792)]), (8192,[(16384,12935233792), (17408,12935233792), (262144,34410070272), (266240,34410070272)]), (8704,[(16384,0), (17408,0), (262144,0), (266240,0)]), (16384,[(262144,34426848000), (266240,34426848000)]), (17408,[(262144,512), (266240,512)])]
private theorem row0 : parts.all (shortPair g pp nn 292352 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 292352 512) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 292352 1024) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 292352 4096) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 292352 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 292352 16384) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 292352 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 292352 8704) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 292352 17408) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 292352 266240) = true := by decide
theorem full : checkArms 358016 292352 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 512, 1024, 4096, 8192, 16384, 262144, 8704, 17408, 266240] : List Nat).all (fun i => parts.all (shortPair g pp nn 292352 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short358016
theorem validBranch358016 : checkArms 358016 292352 [8320, 8704, 16512, 17408, 66048, 66560, 69632, 262272, 266240] [1664, 4736, 5248, 13312, 20992, 28672, 65664, 90112, 263680, 271360, 279040, 335872, 344064] = true := Short358016.full
end TightRow.Protected.Numeric
