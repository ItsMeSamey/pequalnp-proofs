import NumericEdgeCodes
import NumericGraph074Code00
import Branch515328
import NumericGraph028
import NumericGraph048
import NumericGraph058
import NumericGraph065
import NumericGraph066
import NumericGraph069
import NumericGraph072
import NumericGraph073
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m898_897 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e898_897 : Edge c898 c897 m898_897 := by
  exact edgeByCodes c898 c897 m898_897 52131077189998945174017 325711324659185880481801638576128 (by decide) (by decide) (by decide) (by decide)
theorem floor898 : Floor c898 10 := by
  have up := refundEdge e898_897 floor897 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c899 : Chart := ⟨[1065088, 17408, 33280, 34816, 66048, 66560, 69632, 1179649, 132096, 133120, 1310848, 264192, 266240],[1050241, 1051265, 1052288, 1053313, 7168, 1071617, 1086593, 1101825, 1116289, 1132545, 1147009, 1179776, 1184384, 152064, 1216640, 184320, 1278080, 1312257, 1327617, 1344513, 1425409, 410112, 458752]⟩
def m899_898 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, some 7, none]
theorem e899_898 : Edge c899 c898 m899_898 := by
  exact edgeByCodes c899 c898 m899_898 3727165692135582222409400576 7514230092826931318600265122675060704258 (by decide) (by decide) (by decide) (by decide)
theorem floor899 : Floor c899 11 := by
  have up := refundEdge e899_898 floor898 1179649 1179776 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)


end TightRow.Protected.Numeric
