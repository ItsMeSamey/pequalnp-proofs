import NumericEdgeCodes
import Branch383872
import Branch384256
import Branch384384
import Branch384640
import Branch384768
import NumericGraph008
import NumericGraph009
import NumericGraph037
import NumericGraph041
import NumericGraph042
import NumericGraph044
import NumericGraph046
import NumericGraph047
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c576 : Chart := ⟨[16512, 16640, 33024, 33280, 34816, 66048, 69632, 262272, 264192, 266240],[2688, 4992, 6400, 23040, 36992, 53248, 67968, 83968, 98432, 262912, 279040, 327936, 376832]⟩
def m576_575 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e576_575 : Edge c576 c575 m576_575 := by
  exact edgeByCodes c576 c575 m576_575 650776764766945793 14559240984623143062733057 (by decide) (by decide) (by decide) (by decide)
def m576_574 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e576_574 : Edge c576 c574 m576_574 := by
  exact edgeByCodes c576 c574 m576_574 650777868590383872 14554481580254359139188736 (by decide) (by decide) (by decide) (by decide)
def m576_573 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e576_573 : Edge c576 c573 m576_573 := by
  exact edgeByCodes c576 c573 m576_573 650777868573475072 14559203946737228784468225 (by decide) (by decide) (by decide) (by decide)
def m576_566 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e576_566 : Edge c576 c566 m576_566 := by
  exact edgeByCodes c576 c566 m576_566 650495289773392128 56872035097283664282369 (by decide) (by decide) (by decide) (by decide)
def m576_555 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e576_555 : Edge c576 c555 m576_555 := by
  exact edgeByCodes c576 c555 m576_555 578436591928869120 14559240984905721845907712 (by decide) (by decide) (by decide) (by decide)
def m576_532 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e576_532 : Edge c576 c532 m576_532 := by
  exact edgeByCodes c576 c532 m576_532 650777868590383874 56871962756007002767616 (by decide) (by decide) (by decide) (by decide)
def m576_446 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e576_446 : Edge c576 c446 m576_446 := by
  exact edgeByCodes c576 c446 m576_446 650777859966763264 14554499882319190996090886 (by decide) (by decide) (by decide) (by decide)
theorem floor576 : Floor c576 9 := by
  apply protectedBranch source c576.P c576.N (decode 88960) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 88960, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 11 ∨ q = 12 ∨ q = 14 ∨ q = 16 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e576_575 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor575 k x net fit)
    · refine ⟨_,goodChild e576_574 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor574 k x net fit)
    · refine ⟨_,goodChild e576_573 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor573 k x net fit)
    · refine ⟨_,goodChild e576_566 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor566 k x net fit)
    · refine ⟨_,goodChild e576_555 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor555 k x net fit)
    · refine ⟨_,goodChild e576_532 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor532 k x net fit)
    · refine ⟨_,goodChild e576_446 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor446 k x net fit)
  · exact pairExcluded 383872 88960 [16512, 16640, 33024, 33280, 34816, 66048, 69632, 262272, 264192, 266240] [2688, 4992, 6400, 23040, 36992, 53248, 67968, 83968, 98432, 262912, 279040, 327936, 376832] validBranch383872 (by decide) (by decide) (by decide)
def c577 : Chart := ⟨[17408, 34816, 66560, 69632, 264192, 266240],[1024, 7168, 22528, 37888, 53248, 83968, 295936, 376832]⟩
def m577_533 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e577_533 : Edge c577 c533 m577_533 := by
  exact edgeByCodes c577 c533 m577_533 21542142465 7722435412737 (by decide) (by decide) (by decide) (by decide)
theorem floor577 : Floor c577 5 := by
  have up := refundEdge e577_533 floor533 17408 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c578 : Chart := ⟨[16512, 17408, 34816, 66560, 69632, 262272, 264192, 266240],[2176, 3200, 7168, 22528, 38016, 53248, 67712, 83968, 98432, 295936, 376832]⟩
def m578_502 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e578_502 : Edge c578 c502 m578_502 := by
  exact edgeByCodes c578 c502 m578_502 1976943448883456 185118500080628925441 (by decide) (by decide) (by decide) (by decide)
theorem floor578 : Floor c578 7 := by
  have up := refundEdge e578_502 floor502 34816 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c579 : Chart := ⟨[16640, 17408, 33024, 34816, 66560, 69632, 264192, 266240],[7424, 22528, 37888, 53248, 67840, 83968, 263424, 295936, 327936, 376832]⟩
def m579_577 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e579_577 : Edge c579 c577 m579_577 := by
  exact edgeByCodes c579 c577 m579_577 7722435347201 650494181654986752 (by decide) (by decide) (by decide) (by decide)
def m579_572 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e579_572 : Edge c579 c572 m579_572 := by
  exact edgeByCodes c579 c572 m579_572 7722435281408 650775660943441920 (by decide) (by decide) (by decide) (by decide)
def m579_567 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e579_567 : Edge c579 c567 m579_567 := by
  exact edgeByCodes c579 c567 m579_567 7718123471104 650777868556697600 (by decide) (by decide) (by decide) (by decide)
def m579_557 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e579_557 : Edge c579 c557 m579_557 := by
  exact edgeByCodes c579 c557 m579_557 6614300098816 650777868590383104 (by decide) (by decide) (by decide) (by decide)
def m579_534 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e579_534 : Edge c579 c534 m579_534 := by
  exact edgeByCodes c579 c534 m579_534 7722435347202 650777868573475328 (by decide) (by decide) (by decide) (by decide)
def m579_503 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e579_503 : Edge c579 c503 m579_503 := by
  exact edgeByCodes c579 c503 m579_503 7722435346688 650776764766814464 (by decide) (by decide) (by decide) (by decide)
def m579_447 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e579_447 : Edge c579 c447 m579_447 := by
  exact edgeByCodes c579 c447 m579_447 7722401661184 650495281166614784 (by decide) (by decide) (by decide) (by decide)
def m579_104 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, none, none, none, none, none]
theorem e579_104 : Edge c579 c104 m579_104 := by
  exact edgeByCodes c579 c104 m579_104 5514788471040 649930132190003456 (by decide) (by decide) (by decide) (by decide)
theorem floor579 : Floor c579 7 := by
  apply protectedBranch source c579.P c579.N (decode 384256) 7
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 384256, q = 8 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e579_577 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor577 k x net fit)
    · refine ⟨_,goodChild e579_572 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor572 k x net fit)
    · refine ⟨_,goodChild e579_567 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor567 k x net fit)
    · refine ⟨_,goodChild e579_557 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor557 k x net fit)
    · refine ⟨_,goodChild e579_534 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor534 k x net fit)
    · refine ⟨_,goodChild e579_503 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor503 k x net fit)
    · refine ⟨_,goodChild e579_447 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor447 k x net fit)
    · refine ⟨_,goodChild e579_104 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor104 k x net fit)
  · exact pairExcluded 384256 384256 [16640, 17408, 33024, 34816, 66560, 69632, 264192, 266240] [7424, 22528, 37888, 53248, 67840, 83968, 263424, 295936, 327936, 376832] validBranch384256 (by decide) (by decide) (by decide)
def c580 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 66560, 69632, 262272, 264192, 266240],[3200, 4480, 7424, 22528, 38016, 53248, 67968, 83968, 98432, 263424, 295936, 327936, 376832]⟩
def m580_579 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e580_579 : Edge c580 c579 m580_579 := by
  exact edgeByCodes c580 c579 m580_579 650776764766945793 56872035096184152654594 (by decide) (by decide) (by decide) (by decide)
def m580_578 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e580_578 : Edge c580 c578 m580_578 := by
  exact edgeByCodes c580 c578 m580_578 650777868590383616 14554481580254359139254272 (by decide) (by decide) (by decide) (by decide)
def m580_573 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e580_573 : Edge c580 c573 m580_573 := by
  exact edgeByCodes c580 c573 m580_573 650777868573540608 14559203946737228784468225 (by decide) (by decide) (by decide) (by decide)
def m580_568 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e580_568 : Edge c580 c568 m580_568 := by
  exact edgeByCodes c580 c568 m580_568 650495289773392128 14559240984904618056220929 (by decide) (by decide) (by decide) (by decide)
def m580_558 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e580_558 : Edge c580 c558 m580_558 := by
  exact edgeByCodes c580 c558 m580_558 578436591928869120 14559240984905721862815744 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
