import NumericEdgeCodes
import NumericGraph048Code00
import Branch383872
import Branch384256
import Branch384384
import Branch384640
import Branch384768
import NumericGraph008
import NumericGraph009
import NumericGraph037
import NumericGraph041
import NumericGraph042
import NumericGraph044
import NumericGraph046
import NumericGraph047
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m580_504 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e580_504 : Edge c580 c504 m580_504 := by
  exact edgeByCodes c580 c504 m580_504 650777868590252288 14559222393479099159150848 (by decide) (by decide) (by decide) (by decide)
def m580_448 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e580_448 : Edge c580 c448 m580_448 := by
  exact edgeByCodes c580 c448 m580_448 650777859966763264 14554499882318091484463110 (by decide) (by decide) (by decide) (by decide)
theorem floor580 : Floor c580 9 := by
  apply protectedBranch source c580.P c580.N (decode 105856) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 105856, q = 7 ∨ q = 8 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 15 ∨ q = 16 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e580_579 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor579 k x net fit)
    · refine ⟨_,goodChild e580_578 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor578 k x net fit)
    · refine ⟨_,goodChild e580_573 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor573 k x net fit)
    · refine ⟨_,goodChild e580_568 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor568 k x net fit)
    · refine ⟨_,goodChild e580_558 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor558 k x net fit)
    · refine ⟨_,goodChild e580_504 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor504 k x net fit)
    · refine ⟨_,goodChild e580_448 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor448 k x net fit)
  · exact pairExcluded 384384 105856 [16512, 16640, 17408, 33024, 34816, 66560, 69632, 262272, 264192, 266240] [3200, 4480, 7424, 22528, 38016, 53248, 67968, 83968, 98432, 263424, 295936, 327936, 376832] validBranch384384 (by decide) (by decide) (by decide)
def c581 : Chart := ⟨[17408, 33280, 34816, 66048, 66560, 69632, 264192, 266240],[1536, 3584, 7168, 23040, 37888, 53248, 83968, 263680, 279040, 295936, 376832]⟩
def m581_535 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e581_535 : Edge c581 c535 m581_535 := by
  exact edgeByCodes c581 c535 m581_535 1976943448883713 185117936031180653313 (by decide) (by decide) (by decide) (by decide)
theorem floor581 : Floor c581 7 := by
  have up := refundEdge e581_535 floor535 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c582 : Chart := ⟨[16512, 17408, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4736, 7168, 23040, 38016, 53248, 67712, 83968, 98432, 263680, 279040, 295936, 376832]⟩
def m582_581 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e582_581 : Edge c582 c581 m582_581 := by
  exact edgeByCodes c582 c581 m582_581 650776764766945793 14559240984622039256137728 (by decide) (by decide) (by decide) (by decide)
def m582_578 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e582_578 : Edge c582 c578 m582_578 := by
  exact edgeByCodes c582 c578 m582_578 650777868590317824 14559203946737228784467968 (by decide) (by decide) (by decide) (by decide)
def m582_574 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e582_574 : Edge c582 c574 m582_574 := by
  exact edgeByCodes c582 c574 m582_574 650777868573540864 14554481580254359139188736 (by decide) (by decide) (by decide) (by decide)
def m582_569 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e582_569 : Edge c582 c569 m582_569 := by
  exact edgeByCodes c582 c569 m582_569 650495289790169344 14559240984903514232782848 (by decide) (by decide) (by decide) (by decide)
def m582_560 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e582_560 : Edge c582 c560 m582_560 := by
  exact edgeByCodes c582 c560 m582_560 578436591928869120 56872035097287976026880 (by decide) (by decide) (by decide) (by decide)
def m582_536 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e582_536 : Edge c582 c536 m582_536 := by
  exact edgeByCodes c582 c536 m582_536 650777868590383874 14559222538160540018213120 (by decide) (by decide) (by decide) (by decide)
def m582_505 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e582_505 : Edge c582 c505 m582_505 := by
  exact edgeByCodes c582 c505 m582_505 650777868590383360 14554500026999528048820480 (by decide) (by decide) (by decide) (by decide)
theorem floor582 : Floor c582 9 := by
  apply protectedBranch source c582.P c582.N (decode 56960) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 56960, q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 14 ∨ q = 15 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e582_581 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor581 k x net fit)
    · refine ⟨_,goodChild e582_578 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor578 k x net fit)
    · refine ⟨_,goodChild e582_574 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor574 k x net fit)
    · refine ⟨_,goodChild e582_569 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor569 k x net fit)
    · refine ⟨_,goodChild e582_560 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor560 k x net fit)
    · refine ⟨_,goodChild e582_536 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor536 k x net fit)
    · refine ⟨_,goodChild e582_505 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor505 k x net fit)
  · exact pairExcluded 384640 56960 [16512, 17408, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240] [3712, 4736, 7168, 23040, 38016, 53248, 67712, 83968, 98432, 263680, 279040, 295936, 376832] validBranch384640 (by decide) (by decide) (by decide)
def c583 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 264192, 266240],[3584, 4864, 7424, 23040, 37888, 53248, 67840, 83968, 263936, 279040, 295936, 327936, 376832]⟩
def m583_581 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e583_581 : Edge c583 c581 m583_581 := by
  exact edgeByCodes c583 c581 m583_581 650777868590383873 14554500099337501863444480 (by decide) (by decide) (by decide) (by decide)
def m583_579 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e583_579 : Edge c583 c579 m583_579 := by
  exact edgeByCodes c583 c579 m583_579 650777868573475072 56872034814709175943938 (by decide) (by decide) (by decide) (by decide)
def m583_575 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e583_575 : Edge c583 c575 m583_575 := by
  exact edgeByCodes c583 c575 m583_575 650777864278573568 14559222465821475315253505 (by decide) (by decide) (by decide) (by decide)
def m583_570 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e583_570 : Edge c583 c570 m583_570 := by
  exact edgeByCodes c583 c570 m583_570 650495289773392128 14559240984903514232848641 (by decide) (by decide) (by decide) (by decide)
def m583_561 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e583_561 : Edge c583 c561 m583_561 := by
  exact edgeByCodes c583 c561 m583_561 578155116952158464 14559240984905721845907970 (by decide) (by decide) (by decide) (by decide)
def m583_537 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e583_537 : Edge c583 c537 m583_537 := by
  exact edgeByCodes c583 c537 m583_537 650777868590383874 14559240912281870713159936 (by decide) (by decide) (by decide) (by decide)
def m583_105 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, none, none, none, none, none]
theorem e583_105 : Edge c583 c105 m583_105 := by
  exact edgeByCodes c583 c105 m583_105 506097522914230528 14540277442638360931794952 (by decide) (by decide) (by decide) (by decide)
theorem floor583 : Floor c583 9 := by
  apply protectedBranch source c583.P c583.N (decode 286464) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 286464, q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 14 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e583_581 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor581 k x net fit)
    · refine ⟨_,goodChild e583_579 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor579 k x net fit)
    · refine ⟨_,goodChild e583_575 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor575 k x net fit)
    · refine ⟨_,goodChild e583_570 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor570 k x net fit)
    · refine ⟨_,goodChild e583_561 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor561 k x net fit)
    · refine ⟨_,goodChild e583_537 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor537 k x net fit)
    · refine ⟨_,goodChild e583_105 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor105 k x net fit)
  · exact pairExcluded 384768 286464 [16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 264192, 266240] [3584, 4864, 7424, 23040, 37888, 53248, 67840, 83968, 263936, 279040, 295936, 327936, 376832] validBranch384768 (by decide) (by decide) (by decide)
def c584 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4992, 7424, 18944, 23040, 38016, 53248, 67968, 83968, 98432, 263936, 279040, 295936, 327936, 376832]⟩

end TightRow.Protected.Numeric
