import NumericEdgeCodes
import Branch499200
import NumericGraph026
import NumericGraph044
import NumericGraph062
import NumericGraph068
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c828 : Chart := ⟨[33280, 34816, 66048, 66560, 132096, 133120, 262272, 264192],[3712, 33920, 67712, 131712, 229504, 262656, 263680, 295936, 360448, 393728, 458752]⟩
def m828_827 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e828_827 : Edge c828 c827 m828_827 := by
  exact edgeByCodes c828 c827 m828_827 1975839625445632 185118218605668990976 (by decide) (by decide) (by decide) (by decide)
theorem floor828 : Floor c828 7 := by
  have up := refundEdge e828_827 floor827 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c829 : Chart := ⟨[33280, 34816, 66048, 69632, 133120, 264192, 266240],[2048, 6656, 67584, 135680, 167936, 229376, 360448, 393728, 458752]⟩
def m829_529 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e829_529 : Edge c829 c529 m829_529 := by
  exact edgeByCodes c829 c529 m829_529 6618595066112 25887376385 (by decide) (by decide) (by decide) (by decide)
theorem floor829 : Floor c829 6 := by
  have up := refundEdge e829_529 floor529 133120 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c830 : Chart := ⟨[33280, 34816, 66048, 69632, 131073, 133120, 264192, 266240],[6657, 36865, 67585, 131072, 135680, 167936, 229376, 262657, 360449, 393728, 458752]⟩
def m830_829 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e830_829 : Edge c830 c829 m830_829 := by
  exact edgeByCodes c830 c829 m830_829 1976943432040704 185118217501862395904 (by decide) (by decide) (by decide) (by decide)
theorem floor830 : Floor c830 7 := by
  have up := refundEdge e830_829 floor829 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c831 : Chart := ⟨[33280, 34816, 66048, 2166784, 2228288, 133120, 264192, 2363392],[2103872, 2134080, 2164800, 2232320, 2232832, 2265088, 229376, 2359872, 2457664, 393728, 458752]⟩
def m831_829 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e831_829 : Edge c831 c829 m831_829 := by
  exact edgeByCodes c831 c829 m831_829 1976943432040704 185118217501862395904 (by decide) (by decide) (by decide) (by decide)
theorem floor831 : Floor c831 7 := by
  have up := refundEdge e831_829 floor829 2228288 2232320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c832 : Chart := ⟨[34816, 66560, 69632, 132096, 133120, 264192, 266240],[2048, 7168, 37888, 67584, 167936, 229376, 295936, 360448, 458752]⟩
def m832_747 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e832_747 : Edge c832 c747 m832_747 := by
  exact edgeByCodes c832 c747 m832_747 6618611909121 34460664577 (by decide) (by decide) (by decide) (by decide)
theorem floor832 : Floor c832 6 := by
  have up := refundEdge e832_747 floor747 34816 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c833 : Chart := ⟨[33024, 34816, 66560, 69632, 132096, 133120, 264192, 266240],[7424, 33792, 37888, 67840, 135424, 167936, 229376, 263424, 295936, 360448, 459008]⟩
def m833_832 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e833_832 : Edge c833 c832 m833_832 := by
  exact edgeByCodes c833 c832 m833_832 1976943448883713 185118217501845618688 (by decide) (by decide) (by decide) (by decide)
theorem floor833 : Floor c833 7 := by
  have up := refundEdge e833_832 floor832 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c834 : Chart := ⟨[33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[3584, 6656, 7168, 37888, 67584, 135680, 167936, 229376, 263680, 295936, 360448, 393728, 458752]⟩
def m834_832 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e834_832 : Edge c834 c832 m834_832 := by
  exact edgeByCodes c834 c832 m834_832 2259522249032449 222084045822102798848 (by decide) (by decide) (by decide) (by decide)
def m834_829 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e834_829 : Edge c834 c829 m834_829 := by
  exact edgeByCodes c834 c829 m834_829 2259522232123648 222156384891134279936 (by decide) (by decide) (by decide) (by decide)
def m834_827 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e834_827 : Edge c834 c827 m834_827 := by
  exact edgeByCodes c834 c827 m834_827 1976943432040704 222156387098781024256 (by decide) (by decide) (by decide) (by decide)
def m834_751 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e834_751 : Edge c834 c751 m834_751 := by
  exact edgeByCodes c834 c751 m834_751 2259522249032450 222155819733550760192 (by decide) (by decide) (by decide) (by decide)
def m834_535 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e834_535 : Edge c834 c535 m834_535 := by
  exact edgeByCodes c834 c535 m834_535 2259513625411840 185118215298527396096 (by decide) (by decide) (by decide) (by decide)
def m834_314 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, none, none, none, none]
theorem e834_314 : Edge c834 c314 m834_314 := by
  exact edgeByCodes c834 c314 m834_314 1694364648734976 129560965870354825472 (by decide) (by decide) (by decide) (by decide)
theorem floor834 : Floor c834 8 := by
  apply protectedBranch source c834.P c834.N (decode 431616) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 431616, q = 9 ∨ q = 10 ∨ q = 12 ∨ q = 15 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e834_832 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor832 k x net fit)
    · refine ⟨_,goodChild e834_829 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor829 k x net fit)
    · refine ⟨_,goodChild e834_827 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor827 k x net fit)
    · refine ⟨_,goodChild e834_751 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor751 k x net fit)
    · refine ⟨_,goodChild e834_535 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor535 k x net fit)
    · refine ⟨_,goodChild e834_314 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor314 k x net fit)
  · exact pairExcluded 499200 431616 [33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240] [3584, 6656, 7168, 37888, 67584, 135680, 167936, 229376, 263680, 295936, 360448, 393728, 458752] validBranch499200 (by decide) (by decide) (by decide)
def c835 : Chart := ⟨[33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 6656, 7168, 38016, 67712, 135808, 168064, 229504, 262656, 263680, 295936, 360448, 393728, 458752]⟩
def m835_834 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e835_834 : Edge c835 c834 m835_834 := by
  exact edgeByCodes c835 c834 m835_834 166598851780338123008 1033693278377499913344442827008 (by decide) (by decide) (by decide) (by decide)
theorem floor835 : Floor c835 9 := by
  have up := refundEdge e835_834 floor834 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c836 : Chart := ⟨[33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2103872, 2104320, 2135232, 2164928, 2195648, 2232448, 2232960, 2265216, 229504, 2360896, 2393152, 2457664, 393728, 458752]⟩
def m836_835 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e836_835 : Edge c836 c835 m836_835 := by
  exact edgeByCodes c836 c835 m836_835 47390263963051278598400 284987427729519477273016722915584 (by decide) (by decide) (by decide) (by decide)
theorem floor836 : Floor c836 10 := by
  have up := refundEdge e836_835 floor835 2228288 2232448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c837 : Chart := ⟨[33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[3584, 6656, 7424, 33792, 37888, 67840, 135936, 167936, 229376, 263936, 295936, 360448, 393984, 459008]⟩
def m837_834 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e837_834 : Edge c837 c834 m837_834 := by
  exact edgeByCodes c837 c834 m837_834 166599134359138271745 1033693278377572253517280837888 (by decide) (by decide) (by decide) (by decide)
theorem floor837 : Floor c837 9 := by
  have up := refundEdge e837_834 floor834 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c838 : Chart := ⟨[33024, 33280, 34816, 66048, 66560, 69632, 131073, 132096, 133120, 264192, 266240],[3584, 6657, 7424, 37889, 67841, 131328, 135936, 167936, 229376, 263937, 295937, 327937, 360449, 393984, 459008]⟩
def m838_837 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e838_837 : Edge c838 c837 m838_837 := by
  exact edgeByCodes c838 c837 m838_837 47390263961951766970624 284987426515834253005929624764672 (by decide) (by decide) (by decide) (by decide)
theorem floor838 : Floor c838 10 := by
  have up := refundEdge e838_837 floor837 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c839 : Chart := ⟨[33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 6656, 7424, 38016, 67968, 136064, 168064, 196992, 229504, 262912, 263936, 295936, 360448, 393984, 459008]⟩
def m839_837 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e839_837 : Edge c839 c837 m839_837 := by
  exact edgeByCodes c839 c837 m839_837 47390191622882752332032 284987427729482366764359430045952 (by decide) (by decide) (by decide) (by decide)
theorem floor839 : Floor c839 10 := by
  have up := refundEdge e839_837 floor837 262272 262912 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)


end TightRow.Protected.Numeric
