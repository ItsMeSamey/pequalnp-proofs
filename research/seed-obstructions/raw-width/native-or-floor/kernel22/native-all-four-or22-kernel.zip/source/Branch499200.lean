import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short499200
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240]
def n : List Nat := [3584, 6656, 7168, 37888, 67584, 135680, 167936, 229376, 263680, 295936, 360448, 393728, 458752]
def pp := p.map (canonical 499200)
def nn := n.map (canonical 499200)
def parts : List Nat := [0, 512, 1024, 4096, 32768, 131072, 262144, 33280, 132096, 266240]
def g : ShortGrid := [(0,[(512,262022749906830042906359753189307640185601), (1024,67251710918989915506339926354772884430455809), (4096,89552796405079835674245394161536949733819393), (32768,1227834020806430640046081), (33280,256), (131072,111505427430449600840755173054626757156864001), (132096,12952273664), (262144,156107598402629441175357164401514709902622721), (266240,17247241216)]), (512,[(1024,21558919168), (4096,34494152704), (32768,3298534883328), (131072,21475033088), (132096,21475033088), (262144,30064967680), (266240,30064967680)]), (1024,[(4096,34494285056), (32768,1413971953319936), (33280,256), (131072,1412893916529920), (262144,30065100032), (266240,263168)]), (4096,[(32768,1133596488237056), (33280,256), (131072,1133596488238336), (132096,262912), (262144,2260625988257792)]), (32768,[(131072,21525168128), (132096,21525168128), (262144,34410070016), (266240,34410070016)]), (33280,[(131072,256), (132096,256), (262144,256), (266240,256)]), (131072,[(262144,34443625728), (266240,263168)]), (132096,[(262144,262912), (266240,262912)])]
private theorem row0 : parts.all (shortPair g pp nn 431616 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 431616 512) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 431616 1024) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 431616 4096) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 431616 32768) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 431616 131072) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 431616 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 431616 33280) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 431616 132096) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 431616 266240) = true := by decide
theorem full : checkArms 499200 431616 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 512, 1024, 4096, 32768, 131072, 262144, 33280, 132096, 266240] : List Nat).all (fun i => parts.all (shortPair g pp nn 431616 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short499200
theorem validBranch499200 : checkArms 499200 431616 [33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240] [3584, 6656, 7168, 37888, 67584, 135680, 167936, 229376, 263680, 295936, 360448, 393728, 458752] = true := Short499200.full
end TightRow.Protected.Numeric
