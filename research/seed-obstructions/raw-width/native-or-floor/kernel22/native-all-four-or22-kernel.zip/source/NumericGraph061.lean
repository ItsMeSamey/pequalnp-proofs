import NumericEdgeCodes
import NumericGraph038
import NumericGraph051
import NumericGraph060
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c732 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 2228288, 132096, 133120, 262272, 264192, 2363392],[2099648, 3712, 2101696, 2102080, 2102592, 2103616, 2112768, 2120256, 2127872, 2135232, 2143232, 2150464, 2233216, 2240768, 2249216, 2265216, 2289664, 2360128, 2361152, 271616, 2376256, 2393152, 304128, 2408512, 393984, 401664, 410112]⟩
def m732_721 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, some 6]
theorem e732_721 : Edge c732 c721 m732_721 := by
  exact edgeByCodes c732 c721 m732_721 264625479264658496900423911342336 2273458514741399474129013028666511825699072 (by decide) (by decide) (by decide) (by decide)
theorem floor732 : Floor c732 13 := by
  have up := refundEdge e732_721 floor721 2363392 2360128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c733 : Chart := ⟨[8196, 2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 2228288, 132096, 133120, 262272, 264192, 2363392],[2099524, 2436, 2099648, 3204, 3332, 3588, 3712, 2101696, 2102080, 2102592, 2103616, 2104324, 9472, 2112768, 2119748, 2120196, 2120256, 2127872, 2135108, 2135172, 2135232, 2143232, 2150468, 131460, 2233216, 2240768, 2249220, 2265220, 2281476, 2289664, 2360644, 263940, 2361152, 271616, 2376256, 2393156, 304128, 2408516, 393988, 401664, 410116]⟩
def m733_732 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 21]
theorem e733_732 : Edge c733 c732 m733_732 := by
  exact edgeByCodes c733 c732 m733_732 78169440305751915386146223737209345 16517955597502725830558579108369742956502020573432209681708156418 (by decide) (by decide) (by decide) (by decide)
theorem floor733 : Floor c733 14 := by
  have up := refundEdge e733_732 floor732 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 14 ≤ 14).trans (up k x net fit)
def c734 : Chart := ⟨[8196, 2105408, 1056896, 8704, 1065088, 16640, 17408, 33024, 33280, 34816, 1179649, 2228288, 132096, 133120, 1310848, 264192, 2363392],[3146177, 1049473, 1050241, 1050757, 2099524, 1051009, 1051012, 3148224, 1051265, 1051780, 3332, 3588, 1052288, 3150272, 3150465, 2102080, 2102592, 2103616, 2104324, 1059073, 2112768, 1067525, 3166785, 2119748, 3168769, 2120196, 2120256, 3176449, 1082501, 3182785, 2135108, 3183745, 3183748, 3183808, 3191809, 3199041, 2150468, 3207169, 1180032, 1180036, 3281792, 2240768, 2249220, 3313796, 2281476, 2289664, 3408705, 2360644, 1312261, 1312513, 263940, 2361152, 1320193, 1327621, 3424833, 1344517, 2393156, 1352705, 3457093, 393988, 401664, 410116]⟩
def m734_733 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, some 7, some 21]
theorem e734_733 : Edge c734 c733 m734_733 := by
  exact edgeByCodes c734 c733 m734_733 21345817372864401140961492072029880576 130797761527393177556429478194392718169819057997882283844894659662945061051264706641999256927798788 (by decide) (by decide) (by decide) (by decide)
theorem floor734 : Floor c734 15 := by
  have up := refundEdge e734_733 floor733 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 15 ≤ 15).trans (up k x net fit)
def c735 : Chart := ⟨[66560, 132096, 133120, 264192],[1024, 3072, 67584, 263168, 458752]⟩
def m735_619 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
theorem e735_619 : Edge c735 c619 m735_619 := by
  exact edgeByCodes c735 c619 m735_619 197121 67306497 (by decide) (by decide) (by decide) (by decide)
theorem floor735 : Floor c735 3 := by
  have up := refundEdge e735_619 floor619 66560 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c736 : Chart := ⟨[66560, 132096, 133120, 262272, 264192],[3200, 67712, 196736, 262144, 263168, 458752]⟩
def m736_735 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e736_735 : Edge c736 c735 m736_735 := by
  exact edgeByCodes c736 c735 m736_735 67240192 21542010880 (by decide) (by decide) (by decide) (by decide)
theorem floor736 : Floor c736 4 := by
  have up := refundEdge e736_735 floor735 262272 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c737 : Chart := ⟨[66048, 66560, 132096, 133120, 264192],[3584, 65536, 67584, 263680, 393728, 458752]⟩
def m737_735 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e737_735 : Edge c737 c735 m737_735 := by
  exact edgeByCodes c737 c735 m737_735 67305985 21525299200 (by decide) (by decide) (by decide) (by decide)
theorem floor737 : Floor c737 4 := by
  have up := refundEdge e737_735 floor735 66048 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c738 : Chart := ⟨[66048, 66560, 132096, 133120, 262272, 264192],[3712, 67712, 131712, 196736, 262656, 263680, 393728, 458752]⟩
def m738_737 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e738_737 : Edge c738 c737 m738_737 := by
  exact edgeByCodes c738 c737 m738_737 21525299456 7722435150080 (by decide) (by decide) (by decide) (by decide)
theorem floor738 : Floor c738 5 := by
  have up := refundEdge e738_737 floor737 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c739 : Chart := ⟨[66560, 69632, 132096, 266240],[1024, 5120, 135168, 263168, 458752]⟩
def m739_466 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
theorem e739_466 : Edge c739 c466 m739_466 := by
  exact edgeByCodes c739 c466 m739_466 196864 67306497 (by decide) (by decide) (by decide) (by decide)
theorem floor739 : Floor c739 3 := by
  have up := refundEdge e739_466 floor466 132096 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c740 : Chart := ⟨[66560, 2166784, 2228288, 132096, 2363392],[2102336, 2232320, 2360384, 2424896, 458752]⟩
def m740_739 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, none, none, some 16, some 17, some 18, none, none, some 12]
theorem e740_739 : Edge c740 c739 m740_739 := by
  exact edgeByCodes c740 c739 m740_739 67305728 17213489152 (by decide) (by decide) (by decide) (by decide)
theorem floor740 : Floor c740 4 := by
  have up := refundEdge e740_739 floor739 2228288 2232320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c741 : Chart := ⟨[66560, 69632, 132096, 262272, 266240],[5248, 135296, 196736, 262144, 263168, 458752]⟩
def m741_739 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e741_739 : Edge c741 c739 m741_739 := by
  exact edgeByCodes c741 c739 m741_739 67240192 21542010880 (by decide) (by decide) (by decide) (by decide)
theorem floor741 : Floor c741 4 := by
  have up := refundEdge e741_739 floor739 262272 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c742 : Chart := ⟨[66560, 2166784, 2228288, 132096, 262272, 2363392],[2102464, 2162880, 2232448, 196736, 2360384, 2424896, 458752]⟩
def m742_741 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, none, none, some 16, some 17, some 18, none, none, some 12]
theorem e742_741 : Edge c742 c741 m742_741 := by
  exact edgeByCodes c742 c741 m742_741 21542142208 6614316941824 (by decide) (by decide) (by decide) (by decide)
theorem floor742 : Floor c742 5 := by
  have up := refundEdge e742_741 floor741 2228288 2232448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c743 : Chart := ⟨[69632, 133120, 264192, 266240],[4096, 6144, 67584, 135168, 458752]⟩
def m743_621 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, none, none, some 17, some 18, none, none, none]
theorem e743_621 : Edge c743 c621 m743_621 := by
  exact edgeByCodes c743 c621 m743_621 197121 67371777 (by decide) (by decide) (by decide) (by decide)
theorem floor743 : Floor c743 3 := by
  have up := refundEdge e743_621 floor621 69632 4096 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)


end TightRow.Protected.Numeric
