import NumericEdgeCodes
import Branch454592
import NumericGraph021
import NumericGraph038
import NumericGraph055
import NumericGraph057
import NumericGraph058
import NumericGraph059
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c720 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 132096, 133120, 262272, 264192],[2432, 3712, 11520, 18944, 26624, 33920, 131968, 163968, 188416, 263936, 271616, 304128, 311296, 393984, 401664, 410112]⟩
def m720_717 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e720_717 : Edge c720 c717 m720_717 := by
  exact edgeByCodes c720 c717 m720_717 52131149530171766341888 1192769787073929716340638286337 (by decide) (by decide) (by decide) (by decide)
theorem floor720 : Floor c720 10 := by
  have up := refundEdge e720_717 floor717 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c721 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120, 262272, 264192],[2496, 3712, 11520, 19008, 26624, 33984, 131968, 163968, 188416, 264000, 271616, 279104, 296000, 304128, 311360, 393984, 401664, 410112]⟩
def m721_720 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e721_720 : Edge c721 c720 m721_720 := by
  exact edgeByCodes c721 c720 m721_720 4037864368590051442463801857 22680258027453894091430321608984756480 (by decide) (by decide) (by decide) (by decide)
def m721_719 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e721_719 : Edge c721 c719 m721_719 := by
  exact edgeByCodes c721 c719 m721_719 15768166804520351054430720 22680258027456321424840681788249538560 (by decide) (by decide) (by decide) (by decide)
def m721_718 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e721_718 : Edge c721 c718 m721_718 := by
  exact edgeByCodes c721 c718 m721_718 4037864368662391610973225216 5806140842370010071422420384931698049280 (by decide) (by decide) (by decide) (by decide)
def m721_715 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e721_715 : Edge c721 c715 m721_715 := by
  exact edgeByCodes c721 c715 m721_715 4037864368662390511478440192 5806140842369700586412599039862973268224 (by decide) (by decide) (by decide) (by decide)
def m721_711 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e721_711 : Edge c721 c711 m721_711 := by
  exact edgeByCodes c721 c711 m721_711 4037864350143307364442439936 5806146055028506372415983676968822505728 (by decide) (by decide) (by decide) (by decide)
def m721_705 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e721_705 : Edge c721 c705 m721_705 := by
  exact edgeByCodes c721 c705 m721_705 14554500026998432848806144 22680258027456321424840685099719655680 (by decide) (by decide) (by decide) (by decide)
def m721_700 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e721_700 : Edge c721 c700 m721_700 := by
  exact edgeByCodes c721 c700 m721_700 15772907690087467247272963 88574395660582995692402744804573696 (by decide) (by decide) (by decide) (by decide)
def m721_685 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, some 18, none, none, none]
theorem e721_685 : Edge c721 c685 m721_685 := by
  exact edgeByCodes c721 c685 m721_685 15772907690087467247075584 83382019572676727979918926228292352 (by decide) (by decide) (by decide) (by decide)
def m721_668 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, none, none, some 17, some 18, none, none, none]
theorem e721_668 : Edge c721 c668 m721_668 := by
  exact edgeByCodes c721 c668 m721_668 15772907690084155776958720 88594756987655225913580736567377925 (by decide) (by decide) (by decide) (by decide)
def m721_457 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
theorem e721_457 : Edge c721 c457 m721_457 := by
  exact edgeByCodes c721 c457 m721_457 15772852132834727604388096 72956781498752245151647026861113350 (by decide) (by decide) (by decide) (by decide)
def m721_253 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
theorem e721_253 : Edge c721 c253 m721_253 := by
  exact edgeByCodes c721 c253 m721_253 3416467015609337987117220096 41681703573346990574009876796735497 (by decide) (by decide) (by decide) (by decide)
theorem floor721 : Floor c721 12 := by
  apply protectedBranch source c721.P c721.N (decode 454592) 12
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 454592, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e721_720 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor720 k x net fit)
    · refine ⟨_,goodChild e721_719 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor719 k x net fit)
    · refine ⟨_,goodChild e721_718 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor718 k x net fit)
    · refine ⟨_,goodChild e721_715 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor715 k x net fit)
    · refine ⟨_,goodChild e721_711 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor711 k x net fit)
    · refine ⟨_,goodChild e721_705 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor705 k x net fit)
    · refine ⟨_,goodChild e721_700 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor700 k x net fit)
    · refine ⟨_,goodChild e721_685 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor685 k x net fit)
    · refine ⟨_,goodChild e721_668 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor668 k x net fit)
    · refine ⟨_,goodChild e721_457 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor457 k x net fit)
    · refine ⟨_,goodChild e721_253 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor253 k x net fit)
  · exact pairExcluded 454592 454592 [8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120, 262272, 264192] [2496, 3712, 11520, 19008, 26624, 33984, 131968, 163968, 188416, 264000, 271616, 279104, 296000, 304128, 311360, 393984, 401664, 410112] validBranch454592 (by decide) (by decide) (by decide)
def c722 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 2228288, 132096, 262272, 2363392],[1664, 2101696, 2102080, 2102592, 2110720, 2118208, 2135232, 2143232, 2150464, 2233216, 2240768, 2249216, 2265216, 2289664, 2360128, 2361152, 271616, 2376256, 2393152, 304128, 2408512, 393984, 401664, 410112]⟩
def m722_705 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, some 18, none, none, some 6]
theorem e722_705 : Edge c722 c705 m722_705 := by
  exact edgeByCodes c722 c705 m722_705 12131907574542231144628480 30686901955007814682802157981244850177 (by decide) (by decide) (by decide) (by decide)
theorem floor722 : Floor c722 11 := by
  have up := refundEdge e722_705 floor705 2363392 2360128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c723 : Chart := ⟨[2105408, 8320, 16512, 16640, 33024, 34816, 2228288, 133120, 262272, 264192, 2363392],[2099648, 2101696, 2103616, 2111744, 2119744, 2127872, 2134208, 2150464, 2232704, 2240768, 2265216, 2289664, 2359616, 303104, 2408512, 401664, 409600]⟩
def m723_708 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, some 6]
theorem e723_708 : Edge c723 c708 m723_708 := by
  exact edgeByCodes c723 c708 m723_708 42649378395939397566720 1272309861949944845632054493952 (by decide) (by decide) (by decide) (by decide)
theorem floor723 : Floor c723 10 := by
  have up := refundEdge e723_708 floor708 2363392 2359616 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c724 : Chart := ⟨[8196, 2105408, 8320, 16512, 16640, 33024, 34816, 2228288, 133120, 262272, 264192, 2363392],[2099524, 2436, 2099648, 2101696, 2103616, 8448, 2111744, 2119748, 2127872, 2134208, 2150468, 131460, 2232704, 2240768, 2265220, 2281476, 2289664, 2359620, 303104, 2408516, 393476, 401664, 409604]⟩

end TightRow.Protected.Numeric
