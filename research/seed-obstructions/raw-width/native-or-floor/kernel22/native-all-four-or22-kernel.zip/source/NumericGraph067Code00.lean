import NumericEdgeCodes
import Branch488640
import NumericGraph024
import NumericGraph042
import NumericGraph055
import NumericGraph064
import NumericGraph065
import NumericGraph066
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c804 : Chart := ⟨[8196, 8320, 8704, 16512, 17408, 66048, 66560, 132096, 133120, 262272, 264192],[3204, 3588, 3712, 9216, 11264, 18948, 67716, 83972, 92160, 131712, 155648, 196740, 263684, 271360, 344068, 410116, 458756, 466944]⟩
def m804_803 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e804_803 : Edge c804 c803 m804_803 := by
  exact edgeByCodes c804 c803 m804_803 47390263963055590408705 1351538024464209184333716849666 (by decide) (by decide) (by decide) (by decide)
theorem floor804 : Floor c804 10 := by
  have up := refundEdge e804_803 floor803 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c805 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[1216, 3712, 9216, 11264, 19008, 67776, 84032, 92160, 131712, 155648, 196736, 263744, 271360, 279104, 344128, 410112, 466944]⟩
def m805_803 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e805_803 : Edge c805 c803 m805_803 := by
  exact edgeByCodes c805 c803 m805_803 52131149529067959812609 1272309857209059279623980057345 (by decide) (by decide) (by decide) (by decide)
theorem floor805 : Floor c805 10 := by
  have up := refundEdge e805_803 floor803 8256 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c806 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 66048, 66560, 132096, 133120, 262272, 264192],[3712, 11520, 18944, 67968, 76032, 92160, 131968, 155648, 196992, 263936, 271616, 344064, 393984, 410112, 467200]⟩
def m806_803 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e806_803 : Edge c806 c803 m806_803 := by
  exact edgeByCodes c806 c803 m806_803 47390263963055590342912 1113230925901657936179532792064 (by decide) (by decide) (by decide) (by decide)
theorem floor806 : Floor c806 10 := by
  have up := refundEdge e806_803 floor803 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c807 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[1216, 3712, 9472, 11520, 19008, 68032, 76032, 84032, 92160, 131968, 155648, 196992, 264000, 271616, 279104, 328000, 344128, 393984, 410112, 467200]⟩
def m807_806 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e807_806 : Edge c807 c806 m807_806 := by
  exact edgeByCodes c807 c806 m807_806 14559240984623143079576065 99020075531323262335058133557445377 (by decide) (by decide) (by decide) (by decide)
theorem floor807 : Floor c807 11 := by
  have up := refundEdge e807_806 floor806 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c808 : Chart := ⟨[8196, 8256, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 131136, 132096, 133120, 262272, 264192],[1216, 3204, 3332, 3588, 3712, 9472, 11520, 18948, 19008, 67908, 67972, 68032, 76032, 84036, 92160, 131968, 155648, 196996, 263492, 263940, 264000, 271616, 279104, 328004, 344132, 393988, 410116, 459012, 467200]⟩
def m808_807 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e808_807 : Edge c808 c807 m808_807 := by
  exact edgeByCodes c808 c807 m808_807 1033693278377572253517280903681 160433746962841304943283663301659841284891018240 (by decide) (by decide) (by decide) (by decide)
theorem floor808 : Floor c808 12 := by
  have up := refundEdge e808_807 floor807 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 12 ≤ 12).trans (up k x net fit)
def c809 : Chart := ⟨[8320, 16512, 17408, 66560, 69632, 132096, 262272, 266240],[128, 5248, 13312, 90112, 135296, 159744, 196736, 271360, 344064, 409600, 466944]⟩
def m809_787 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e809_787 : Edge c809 c787 m809_787 := by
  exact edgeByCodes c809 c787 m809_787 1976943448883713 185118218605685899521 (by decide) (by decide) (by decide) (by decide)
theorem floor809 : Floor c809 7 := by
  have up := refundEdge e809_787 floor787 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c810 : Chart := ⟨[2105408, 8320, 16512, 17408, 66560, 2166784, 2228288, 132096, 262272, 2363392],[2102464, 2110464, 2117696, 2162880, 90112, 2232448, 2256896, 196736, 2360384, 271360, 2441280, 409600, 466944]⟩
def m810_809 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 12]
theorem e810_809 : Edge c810 c809 m810_809 := by
  exact edgeByCodes c810 c809 m810_809 650777864278573569 14559240984623143079444480 (by decide) (by decide) (by decide) (by decide)
def m810_798 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, some 16, some 17, some 18, none, none, some 6]
theorem e810_798 : Edge c810 c798 m810_798 := by
  exact edgeByCodes c810 c798 m810_798 578437691440496896 14559240984905721862881280 (by decide) (by decide) (by decide) (by decide)
def m810_789 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e810_789 : Edge c810 c789 m810_789 := by
  exact edgeByCodes c810 c789 m810_789 650777868590383874 56872034814709175878144 (by decide) (by decide) (by decide) (by decide)
def m810_770 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e810_770 : Edge c810 c770 m810_770 := by
  exact edgeByCodes c810 c770 m810_770 650777868590383360 56853516013041428398336 (by decide) (by decide) (by decide) (by decide)
def m810_669 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, some 14, none, none, some 17, some 18, none, none, some 21]
theorem e810_669 : Edge c810 c669 m810_669 := by
  exact edgeByCodes c810 c669 m810_669 650777868556697856 13355037531775061861728512 (by decide) (by decide) (by decide) (by decide)
def m810_512 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, some 21]
theorem e810_512 : Edge c810 c512 m810_512 := by
  exact edgeByCodes c810 c512 m810_512 650775660943507712 47445676532138154000640 (by decide) (by decide) (by decide) (by decide)
def m810_292 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, some 17, none, none, none, some 21]
theorem e810_292 : Edge c810 c292 m810_292 := by
  exact edgeByCodes c810 c292 m810_292 506097522914230528 56797958760331867193600 (by decide) (by decide) (by decide) (by decide)
theorem floor810 : Floor c810 9 := by
  apply protectedBranch source c810.P c810.N (decode 487488) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 487488, q = 6 ∨ q = 12 ∨ q = 13 ∨ q = 14 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e810_809 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor809 k x net fit)
    · refine ⟨_,goodChild e810_798 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor798 k x net fit)
    · refine ⟨_,goodChild e810_789 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor789 k x net fit)
    · refine ⟨_,goodChild e810_770 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor770 k x net fit)
    · refine ⟨_,goodChild e810_669 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor669 k x net fit)
    · refine ⟨_,goodChild e810_512 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor512 k x net fit)
    · refine ⟨_,goodChild e810_292 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor292 k x net fit)
  · exact pairExcluded 488640 487488 [8256, 8320, 16512, 17408, 66560, 69632, 131136, 132096, 262272, 266240] [5312, 13312, 20544, 65728, 90112, 135296, 159744, 196736, 263232, 271360, 344128, 409600, 466944] validBranch488640 (by decide) (by decide) (by decide)
def c811 : Chart := ⟨[2105408, 8320, 16512, 16640, 17408, 66560, 2166784, 2228288, 132096, 262272, 2363392],[2101696, 2102464, 2102592, 2110720, 16384, 2117696, 2163136, 90112, 2232704, 2240768, 2256896, 196992, 2360640, 271616, 2425152, 2441280, 409600, 467200]⟩
def m811_810 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e811_810 : Edge c811 c810 m811_810 := by
  exact edgeByCodes c811 c810 m811_810 47390263963055590342912 1351848718399850142927809741569 (by decide) (by decide) (by decide) (by decide)
theorem floor811 : Floor c811 10 := by
  have up := refundEdge e811_810 floor810 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c812 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 69632, 132096, 262272, 266240],[1664, 5248, 13312, 90112, 135808, 152064, 159744, 196736, 263680, 271360, 344064, 410112, 466944]⟩
def m812_513 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e812_513 : Edge c812 c513 m812_513 := by
  exact edgeByCodes c812 c513 m812_513 166598851780338123008 796008786093605725823070962688 (by decide) (by decide) (by decide) (by decide)
theorem floor812 : Floor c812 9 := by
  have up := refundEdge e812_513 floor513 132096 1664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c813 : Chart := ⟨[2105408, 8320, 8704, 16512, 17408, 66048, 66560, 2166784, 2228288, 132096, 262272, 2363392],[1664, 2102464, 2110464, 2118208, 2162880, 90112, 2232960, 2249216, 2256896, 196736, 2360896, 271360, 2376256, 2441280, 410112, 466944]⟩
def m813_812 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 12]
theorem e813_812 : Edge c813 c812 m813_812 := by
  exact edgeByCodes c813 c812 m813_812 52131149247592983101953 1192770996018268415216360489216 (by decide) (by decide) (by decide) (by decide)
theorem floor813 : Floor c813 10 := by
  have up := refundEdge e813_812 floor812 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c814 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 66048, 66560, 69632, 132096, 262272, 266240],[1664, 5248, 13568, 16896, 90112, 136064, 143616, 152064, 159744, 196992, 263936, 271616, 344064, 393984, 410112, 467200]⟩
def m814_812 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e814_812 : Edge c814 c812 m814_812 := by
  exact edgeByCodes c814 c812 m814_812 47390263963055590342912 1192769787092448800582874038528 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
