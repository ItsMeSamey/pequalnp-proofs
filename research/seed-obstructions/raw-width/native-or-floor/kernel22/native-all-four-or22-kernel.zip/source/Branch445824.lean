import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short445824
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16512, 16640, 17408, 33024, 34816, 132096, 133120, 262272, 264192]
def n : List Nat := [2432, 3200, 3328, 18432, 33920, 131456, 163968, 180224, 263424, 295936, 311296, 393472, 409600]
def pp := p.map (canonical 445824)
def nn := n.map (canonical 445824)
def parts : List Nat := [0, 128, 256, 1024, 32768, 131072, 262144, 33024, 132096, 262272]
def g : ShortGrid := [(0,[(128,261340845540116251967642200860516390273793), (256,22562426331630036419873110007624581693637377), (1024,44863511817719956587778577814388646997000961), (32768,66903256458269760503716403420576973767049985), (33024,4345495808), (131072,133806512916539521007432806840587690405397249), (132096,8640463360), (262144,156107598402629441175338274647633234980504321), (262272,50528256)]), (128,[(256,1979120930259712), (1024,1979120930325760), (32768,7696581395200), (33024,196864), (131072,7696581461248), (132096,197120), (262144,1979150994769664)]), (256,[(1024,21558985472), (32768,848835861545728), (131072,25770066688), (132096,197120), (262144,30065033984), (262272,196608)]), (1024,[(32768,1413971953320704), (33024,196864), (131072,1412893933307136), (262144,30081877248), (262272,196608)]), (32768,[(131072,21541946112), (132096,197120), (262144,30131880704), (262272,196608)]), (33024,[(131072,196864), (132096,196864), (262144,196864), (262272,196608)]), (131072,[(262144,30148723968), (262272,196608)]), (132096,[(262144,197120), (262272,196608)])]
private theorem row0 : parts.all (shortPair g pp nn 427392 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 427392 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 427392 256) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 427392 1024) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 427392 32768) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 427392 131072) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 427392 262144) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 427392 33024) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 427392 132096) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 427392 262272) = true := by decide
theorem full : checkArms 445824 427392 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 256, 1024, 32768, 131072, 262144, 33024, 132096, 262272] : List Nat).all (fun i => parts.all (shortPair g pp nn 427392 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short445824
theorem validBranch445824 : checkArms 445824 427392 [16512, 16640, 17408, 33024, 34816, 132096, 133120, 262272, 264192] [2432, 3200, 3328, 18432, 33920, 131456, 163968, 180224, 263424, 295936, 311296, 393472, 409600] = true := Short445824.full
end TightRow.Protected.Numeric
