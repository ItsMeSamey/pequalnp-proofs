import NumericEdgeCodes
import NumericGraph078Code00
import Branch523712
import Branch523904
import NumericGraph030
import NumericGraph031
import NumericGraph050
import NumericGraph060
import NumericGraph068
import NumericGraph072
import NumericGraph074
import NumericGraph076
import NumericGraph077
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m942_913 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 6]
theorem e942_913 : Edge c942 c913 m942_913 := by
  exact edgeByCodes c942 c913 m942_913 1033693278377499913344442827008 160456135161942574902823621947696026419472892928 (by decide) (by decide) (by decide) (by decide)
def m942_896 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e942_896 : Edge c942 c896 m942_896 := by
  exact edgeByCodes c942 c896 m942_896 1113232139568363117924917183234 2692007238114629905736841542327178714683958381791805696 (by decide) (by decide) (by decide) (by decide)
def m942_820 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e942_820 : Edge c942 c820 m942_820 := by
  exact edgeByCodes c942 c820 m942_820 1113232139568363117916293562624 2692007238092328818916290684537570347274414421256372480 (by decide) (by decide) (by decide) (by decide)
def m942_728 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 21]
theorem e942_728 : Edge c942 c728 m942_728 := by
  exact edgeByCodes c942 c728 m942_728 1113232139568362552767316885760 2596600405520765243646523576482184316679962285058359306 (by decide) (by decide) (by decide) (by decide)
def m942_606 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 21]
theorem e942_606 : Edge c942 c606 m942_606 := by
  exact edgeByCodes c942 c606 m942_606 4348562989631665689751322880 640209401015042522562162193100076431447295880555793613056 (by decide) (by decide) (by decide) (by decide)
def m942_370 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 21]
theorem e942_370 : Edge c942 c370 m942_370 := by
  exact edgeByCodes c942 c370 m942_370 3416467015609337987117220096 493087575422004160222334040668974856006756636209872765184 (by decide) (by decide) (by decide) (by decide)
theorem floor942 : Floor c942 13 := by
  apply protectedBranch source c942.P c942.N (decode 507328) 13
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 507328, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e942_941 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor941 k x net fit)
    · refine ⟨_,goodChild e942_940 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor940 k x net fit)
    · refine ⟨_,goodChild e942_939 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor939 k x net fit)
    · refine ⟨_,goodChild e942_930 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor930 k x net fit)
    · refine ⟨_,goodChild e942_924 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor924 k x net fit)
    · refine ⟨_,goodChild e942_913 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor913 k x net fit)
    · refine ⟨_,goodChild e942_896 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor896 k x net fit)
    · refine ⟨_,goodChild e942_820 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor820 k x net fit)
    · refine ⟨_,goodChild e942_728 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor728 k x net fit)
    · refine ⟨_,goodChild e942_606 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor606 k x net fit)
    · refine ⟨_,goodChild e942_370 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 13-2 ≤ 11).trans (floor370 k x net fit)
  · exact pairExcluded 523712 507328 [8256, 8320, 16512, 16640, 17408, 33024, 34816, 66560, 69632, 131136, 132096, 133120, 262272, 264192, 266240] [3200, 4544, 5440, 6464, 15616, 22592, 30720, 38080, 46080, 53312, 68032, 76032, 84032, 92160, 98496, 135552, 143616, 168064, 192512, 196992, 229504, 263488, 271616, 296000, 304128, 328000, 376896, 409600, 467200] validBranch523712 (by decide) (by decide) (by decide)
def c943 : Chart := ⟨[8704, 17408, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[512, 3584, 15360, 23040, 30720, 46080, 92160, 152064, 192512, 229376, 263680, 304128, 376832, 410112, 466944]⟩
def m943_897 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e943_897 : Edge c943 c897 m943_897 := by
  exact edgeByCodes c943 c897 m943_897 47390263963055590408705 284987427729500958188778782064897 (by decide) (by decide) (by decide) (by decide)
theorem floor943 : Floor c943 10 := by
  have up := refundEdge e943_897 floor897 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c944 : Chart := ⟨[2105408, 8704, 17408, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[3584, 2110464, 2112512, 2120256, 2127872, 2135104, 2143232, 2150464, 2181184, 92160, 2249216, 2289664, 229376, 2360896, 2376256, 2393152, 304128, 2474048, 410112, 466944]⟩
def m944_943 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e944_943 : Edge c944 c943 m944_943 := by
  exact edgeByCodes c944 c943 m944_943 14559240984623143079576065 99020075531323262335055925910568960 (by decide) (by decide) (by decide) (by decide)
theorem floor944 : Floor c944 11 := by
  have up := refundEdge e944_943 floor943 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c945 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 15360, 23040, 30720, 38016, 46080, 67712, 92160, 135808, 152064, 168064, 192512, 229504, 263680, 304128, 376832, 410112, 466944]⟩
def m945_943 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e945_943 : Edge c945 c943 m945_943 := by
  exact edgeByCodes c945 c943 m945_943 15772889171003220699644673 88594757919751255493160066397306880 (by decide) (by decide) (by decide) (by decide)
def m945_938 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e945_938 : Edge c945 c938 m945_938 := by
  exact edgeByCodes c945 c938 m945_938 15772907690087467230364160 88594757918537588715921835127013376 (by decide) (by decide) (by decide) (by decide)
def m945_931 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e945_931 : Edge c945 c931 m945_931 := by
  exact edgeByCodes c945 c931 m945_931 15772907689803784623620352 88594757918537588860602180769546240 (by decide) (by decide) (by decide) (by decide)
def m945_925 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e945_925 : Edge c945 c925 m945_925 := by
  exact edgeByCodes c945 c925 m945_925 15768148285436100194992384 88594757919751255565783926153936896 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
