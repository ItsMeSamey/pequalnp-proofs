import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short482432
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16512, 17408, 66560, 69632, 132096, 133120, 262272, 264192, 266240]
def n : List Nat := [3200, 5248, 7168, 22528, 67712, 83968, 135296, 151552, 196736, 263168, 344064, 409600, 458752]
def pp := p.map (canonical 482432)
def nn := n.map (canonical 482432)
def parts : List Nat := [0, 128, 2048, 4096, 16384, 65536, 131072, 16512, 69632, 133120]
def g : ShortGrid := [(0,[(128,134590535453159392537450477816259960893342465), (2048,156891620939249630546461106147558683499103745), (4096,179192706425339312410908956034272421516346369), (16384,23085108022710186909029345539388151347281921), (16512,256), (65536,45386193508800186306306271877129992350597121), (69632,8589935104), (131072,89988364480980026642117207490658122957324289), (133120,17179870208)]), (128,[(2048,21575696384), (4096,12952207360), (16384,3298534883328), (65536,8590131200), (69632,8590131200), (131072,17180065792), (133120,17180065792)]), (2048,[(4096,1413971953582848), (16384,1415071464947712), (16512,256), (65536,1416170976641792), (69632,512), (131072,1413989133190400)]), (4096,[(16384,849922488270848), (16512,256), (65536,848831583355648), (131072,17196909312), (133120,17196909312)]), (16384,[(65536,12935233536), (69632,12935233536), (131072,21525168128), (133120,21525168128)]), (16512,[(65536,256), (69632,256), (131072,256), (133120,256)]), (65536,[(131072,21542011648), (133120,21542011648)]), (69632,[(131072,512), (133120,512)])]
private theorem row0 : parts.all (shortPair g pp nn 219264 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 219264 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 219264 2048) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 219264 4096) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 219264 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 219264 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 219264 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 219264 16512) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 219264 69632) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 219264 133120) = true := by decide
theorem full : checkArms 482432 219264 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 2048, 4096, 16384, 65536, 131072, 16512, 69632, 133120] : List Nat).all (fun i => parts.all (shortPair g pp nn 219264 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short482432
theorem validBranch482432 : checkArms 482432 219264 [16512, 17408, 66560, 69632, 132096, 133120, 262272, 264192, 266240] [3200, 5248, 7168, 22528, 67712, 83968, 135296, 151552, 196736, 263168, 344064, 409600, 458752] = true := Short482432.full
end TightRow.Protected.Numeric
