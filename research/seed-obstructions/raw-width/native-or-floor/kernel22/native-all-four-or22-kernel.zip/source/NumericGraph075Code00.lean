import NumericEdgeCodes
import Branch515968
import NumericGraph028
import NumericGraph048
import NumericGraph058
import NumericGraph059
import NumericGraph066
import NumericGraph069
import NumericGraph070
import NumericGraph073
import NumericGraph074
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c900 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[3584, 7424, 18944, 23040, 37888, 67840, 83968, 135936, 152064, 184320, 229376, 263936, 295936, 376832, 393984, 410112, 459008]⟩
def m900_897 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e900_897 : Edge c900 c897 m900_897 := by
  exact edgeByCodes c900 c897 m900_897 52131149530171783250689 325711013960509354237566346395648 (by decide) (by decide) (by decide) (by decide)
theorem floor900 : Floor c900 10 := by
  have up := refundEdge e900_897 floor897 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c901 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[3584, 2102080, 2102592, 2103616, 2104576, 2120256, 2135104, 2150464, 2165056, 2181184, 2232320, 2233088, 2249216, 2281472, 229376, 2361152, 2376256, 2393152, 2425152, 2474048, 393984, 410112, 459008]⟩
def m901_900 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e901_900 : Edge c901 c900 m901_900 := by
  exact edgeByCodes c901 c900 m901_900 3727165692063524628371472640 7514230092826620619923738878439768523776 (by decide) (by decide) (by decide) (by decide)
theorem floor901 : Floor c901 11 := by
  have up := refundEdge e901_900 floor900 2228288 2232320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c902 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 7424, 23040, 38016, 67968, 83968, 136064, 152064, 168064, 184320, 196992, 229504, 263936, 295936, 376832, 393984, 410112, 459008]⟩
def m902_900 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e902_900 : Edge c902 c900 m902_900 := by
  exact edgeByCodes c902 c900 m902_900 4037859627776824499109036545 5806146055028818279999810734165541912832 (by decide) (by decide) (by decide) (by decide)
def m902_898 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e902_898 : Edge c902 c898 m902_898 := by
  exact edgeByCodes c902 c898 m902_898 4037864368662391615301878272 5806140842370010071422420384931698049280 (by decide) (by decide) (by decide) (by decide)
def m902_895 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e902_895 : Edge c902 c895 m902_895 := by
  exact edgeByCodes c902 c895 m902_895 4037864368662391610973225216 5806140842370011285089053226504227520768 (by decide) (by decide) (by decide) (by decide)
def m902_887 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e902_887 : Edge c902 c887 m902_887 := by
  exact edgeByCodes c902 c887 m902_887 15772907689803784623685888 22680258026834924071787631471518351364 (by decide) (by decide) (by decide) (by decide)
def m902_884 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e902_884 : Edge c902 c884 m902_884 := by
  exact edgeByCodes c902 c884 m902_884 15768148285436100194992384 88594757919751255565783926170648832 (by decide) (by decide) (by decide) (by decide)
def m902_882 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e902_882 : Edge c902 c882 m902_882 := by
  exact edgeByCodes c902 c882 m902_882 3727165692063524628371472640 22680258027456321424840119942119555073 (by decide) (by decide) (by decide) (by decide)
def m902_839 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e902_839 : Edge c902 c839 m902_839 := by
  exact edgeByCodes c902 c839 m902_839 15772907690087467247272963 88574395971291153989779000540594688 (by decide) (by decide) (by decide) (by decide)
def m902_797 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e902_797 : Edge c902 c797 m902_797 := by
  exact edgeByCodes c902 c797 m902_797 15772907690087467247075584 88594757918532810936866567220167424 (by decide) (by decide) (by decide) (by decide)
def m902_704 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e902_704 : Edge c902 c704 m902_704 := by
  exact edgeByCodes c902 c704 m902_704 15772907690084155776958720 83382099112742103704828639233245188 (by decide) (by decide) (by decide) (by decide)
def m902_584 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e902_584 : Edge c902 c584 m902_584 := by
  exact edgeByCodes c902 c584 m902_584 4037864331624223122206621952 73037991915181656165718310390924800 (by decide) (by decide) (by decide) (by decide)
def m902_343 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, none, none, none, none]
theorem e902_343 : Edge c902 c343 m902_343 := by
  exact edgeByCodes c902 c343 m902_343 12131907574542231144628480 57318805077753401119907655110950924 (by decide) (by decide) (by decide) (by decide)
theorem floor902 : Floor c902 12 := by
  apply protectedBranch source c902.P c902.N (decode 515968) 12
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 515968, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e902_900 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor900 k x net fit)
    · refine ⟨_,goodChild e902_898 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor898 k x net fit)
    · refine ⟨_,goodChild e902_895 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor895 k x net fit)
    · refine ⟨_,goodChild e902_887 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor887 k x net fit)
    · refine ⟨_,goodChild e902_884 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor884 k x net fit)
    · refine ⟨_,goodChild e902_882 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor882 k x net fit)
    · refine ⟨_,goodChild e902_839 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor839 k x net fit)
    · refine ⟨_,goodChild e902_797 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor797 k x net fit)
    · refine ⟨_,goodChild e902_704 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor704 k x net fit)
    · refine ⟨_,goodChild e902_584 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor584 k x net fit)
    · refine ⟨_,goodChild e902_343 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor343 k x net fit)
  · exact pairExcluded 515968 515968 [16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240] [3712, 7424, 23040, 38016, 67968, 83968, 136064, 152064, 168064, 184320, 196992, 229504, 263936, 295936, 376832, 393984, 410112, 459008] validBranch515968 (by decide) (by decide) (by decide)
def c903 : Chart := ⟨[1065088, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 1179649, 132096, 133120, 1310848, 264192, 266240],[1049473, 1050241, 1051265, 1052288, 1053313, 7424, 1071617, 1086593, 1101825, 1116545, 1132545, 1147009, 1180032, 1184640, 152064, 1216640, 184320, 1245568, 1278080, 1312513, 1327617, 1344513, 1376513, 1425409, 393984, 410112, 459008]⟩

end TightRow.Protected.Numeric
