import NumericGraph079
import IncrementEdge2763
import IncrementEdge2762
import IncrementEdge2761
import IncrementEdge2760
import IncrementEdge2759

namespace TightRow.Protected.Numeric.Increment
open TightRow.Deletion TightRow.NativeSeeds
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem allFourNative22 (a b : Bool) {k : Nat} (t : Tape (NativeDeletion.Input a b) k)
    (h : Fits t (fun i => rich i.val) positives negatives) : 22 ≤ k := by
  exact transferRoot (lift2763 (lift2762 (lift2761 (lift2760 (lift2759 (TightRow.Protected.Numeric.floor952)))))) a b t h

#print axioms allFourNative22

end TightRow.Protected.Numeric.Increment
