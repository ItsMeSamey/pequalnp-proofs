import NumericEdgeCodes
import Branch523712
import Branch523904
import NumericGraph030
import NumericGraph031
import NumericGraph050
import NumericGraph060
import NumericGraph068
import NumericGraph072
import NumericGraph074
import NumericGraph076
import NumericGraph077
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c936 : Chart := ⟨[8196, 2105408, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 2166784, 2228288, 133120, 262272, 264192, 2363392],[2688, 2101696, 2102080, 2103616, 8448, 2111744, 2119748, 2120196, 2120256, 2127872, 2134208, 2150468, 2165060, 67972, 2165184, 76032, 2181188, 92160, 2195648, 2233216, 2240768, 2249220, 2265220, 2281476, 2289664, 196996, 229508, 2360128, 2376256, 303104, 2425156, 2474052, 393988, 410116, 459012, 467200]⟩
def m936_935 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e936_935 : Edge c936 c935 m936_935 := by
  exact edgeByCodes c936 c935 m936_935 78169440305751915386146223737209345 947086653015899543651212936876990313052312342863925647148873928540416 (by decide) (by decide) (by decide) (by decide)
theorem floor936 : Floor c936 14 := by
  have up := refundEdge e936_935 floor935 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 14 ≤ 14).trans (up k x net fit)
def c937 : Chart := ⟨[8196, 2105408, 1056896, 8704, 1065088, 16640, 33024, 33280, 34816, 66048, 2166784, 1179649, 2228288, 133120, 1310848, 264192, 2363392],[1049473, 1051265, 3150272, 3150465, 2102080, 2103616, 2111744, 1067525, 3166785, 2119748, 3168769, 2120196, 2120256, 3176449, 3182785, 3199041, 2150468, 3207169, 3211713, 1116293, 2165060, 1116545, 1116548, 3213760, 1124609, 1132549, 2181188, 1140737, 1147013, 3244225, 1180032, 3281792, 2240768, 2249220, 3313796, 2281476, 2289664, 1245572, 1278084, 3408705, 1327621, 3424833, 1351681, 3473729, 2425156, 1384705, 3522629, 393988, 410116, 459012, 467200]⟩
def m937_936 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, some 7, some 21]
theorem e937_936 : Edge c937 c936 m937_936 := by
  exact edgeByCodes c937 c936 m937_936 21345817372863192215141877442855174400 97506711895244200084732076029321895207864094256421959737890517541427294306730057662977 (by decide) (by decide) (by decide) (by decide)
theorem floor937 : Floor c937 15 := by
  have up := refundEdge e937_936 floor936 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 15 ≤ 15).trans (up k x net fit)
def c938 : Chart := ⟨[8320, 16512, 17408, 34816, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[128, 3200, 15360, 30720, 38016, 46080, 67712, 92160, 168064, 192512, 229504, 304128, 376832, 409600, 466944]⟩
def m938_891 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e938_891 : Edge c938 c891 m938_891 := by
  exact edgeByCodes c938 c891 m938_891 47390263963055590408705 284987427729500958188774487097601 (by decide) (by decide) (by decide) (by decide)
theorem floor938 : Floor c938 10 := by
  have up := refundEdge e938_891 floor891 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c939 : Chart := ⟨[2105408, 8320, 16512, 17408, 34816, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3200, 2110464, 2112512, 2119744, 2127872, 2135232, 2143232, 2150464, 2164928, 2181184, 92160, 2195648, 2265216, 2289664, 229504, 2393152, 304128, 2474048, 409600, 466944]⟩
def m939_938 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e939_938 : Edge c939 c938 m939_938 := by
  exact edgeByCodes c939 c938 m939_938 14559240984904618056286721 99020075532536928967616027775074304 (by decide) (by decide) (by decide) (by decide)
theorem floor939 : Floor c939 11 := by
  have up := refundEdge e939_938 floor938 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c940 : Chart := ⟨[2105408, 16640, 17408, 33024, 34816, 66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[2101568, 2102592, 2103616, 2112768, 2119744, 2127872, 2135104, 2143232, 2150464, 2165056, 76032, 2181184, 92160, 2240768, 2289664, 229376, 2360640, 271616, 2393152, 304128, 2425152, 2474048, 409600, 467200]⟩
def m940_894 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e940_894 : Edge c940 c894 m940_894 := by
  exact edgeByCodes c940 c894 m940_894 13345574279723976512176641 2011096806502950655726125939419223894983169 (by decide) (by decide) (by decide) (by decide)
theorem floor940 : Floor c940 11 := by
  have up := refundEdge e940_894 floor894 2105408 2101568 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c941 : Chart := ⟨[8320, 16512, 16640, 17408, 33024, 34816, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3200, 15616, 18432, 30720, 38016, 46080, 67968, 76032, 92160, 135552, 143616, 168064, 192512, 196992, 229504, 271616, 304128, 376832, 409600, 467200]⟩
def m941_938 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e941_938 : Edge c941 c938 m941_938 := by
  exact edgeByCodes c941 c938 m941_938 14559240984905721879658752 99020075532532188009709842567593984 (by decide) (by decide) (by decide) (by decide)
theorem floor941 : Floor c941 11 := by
  have up := refundEdge e941_938 floor938 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c942 : Chart := ⟨[2105408, 8320, 16512, 16640, 17408, 33024, 34816, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3200, 2101696, 2102592, 2103616, 2112768, 2119744, 2127872, 2135232, 2143232, 2150464, 2165184, 76032, 2181184, 92160, 2195648, 2232704, 2240768, 2265216, 2289664, 196992, 229504, 2360640, 271616, 2393152, 304128, 2425152, 2474048, 409600, 467200]⟩
def m942_941 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e942_941 : Edge c942 c941 m942_941 := by
  exact edgeByCodes c942 c941 m942_941 1113232139568290777752079106561 160456134818986114013894327765210175529961194496 (by decide) (by decide) (by decide) (by decide)
def m942_940 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e942_940 : Edge c942 c940 m942_940 := by
  exact edgeByCodes c942 c940 m942_940 4348558304303351313201365760 689153852963099023037652601380405652699173054298173145601 (by decide) (by decide) (by decide) (by decide)
def m942_939 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e942_939 : Edge c942 c939 m942_939 := by
  exact edgeByCodes c942 c939 m942_939 1113232139568363117924900274432 160456134820315321647109381442671981883830830080 (by decide) (by decide) (by decide) (by decide)
def m942_930 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e942_930 : Edge c942 c930 m942_930 := by
  exact edgeByCodes c942 c930 m942_930 4348563045116577152715849984 689153852963031858440354024683483155547684455028449542401 (by decide) (by decide) (by decide) (by decide)
def m942_924 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e942_924 : Edge c942 c924 m942_924 := by
  exact edgeByCodes c942 c924 m942_924 4347344637598168464010379520 689153852963099023037657834560238839593161209973840150785 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
