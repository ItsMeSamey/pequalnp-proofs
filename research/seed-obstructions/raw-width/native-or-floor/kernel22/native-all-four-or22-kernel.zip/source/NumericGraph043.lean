import NumericGraph034
import NumericGraph038
import NumericGraph039
import NumericGraph042
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c516 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4736, 5248, 15360, 23040, 30720, 67712, 92160, 262656, 263680, 271360, 279040, 335872, 344064]⟩
def m516_513 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
private theorem e516_513 : Edge c516 c513 m516_513 := by constructor <;> decide
theorem floor516 : Floor c516 9 := by
  have up := refundEdge e516_513 floor513 264192 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c517 : Chart := ⟨[2105408, 8320, 8704, 16512, 17408, 66048, 66560, 2166784, 262272, 264192, 2363392],[3712, 2101888, 2102464, 2110464, 2112512, 2120256, 2127872, 2164928, 2181184, 92160, 2360896, 271360, 2376256, 335872, 2441280]⟩
def m517_516 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, none, some 18, none, none, some 12]
private theorem e517_516 : Edge c517 c516 m517_516 := by constructor <;> decide
theorem floor517 : Floor c517 10 := by
  have up := refundEdge e517_516 floor516 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c518 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4992, 5248, 15616, 18944, 23040, 30720, 67968, 76032, 92160, 263936, 271616, 279040, 336128, 344064]⟩
def m518_516 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
private theorem e518_516 : Edge c518 c516 m518_516 := by constructor <;> decide
theorem floor518 : Floor c518 10 := by
  have up := refundEdge e518_516 floor516 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c519 : Chart := ⟨[33280, 34816, 66048, 264192],[512, 2560, 67584, 262656, 360448]⟩
def m519_409 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, none, none, some 18, none, none, none]
private theorem e519_409 : Edge c519 c409 m519_409 := by constructor <;> decide
theorem floor519 : Floor c519 3 := by
  have up := refundEdge e519_409 floor409 66048 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c520 : Chart := ⟨[33280, 34816, 66048, 262272, 264192],[2688, 67712, 98432, 262656, 360448]⟩
def m520_519 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e520_519 : Edge c520 c519 m520_519 := by constructor <;> decide
theorem floor520 : Floor c520 4 := by
  have up := refundEdge e520_519 floor519 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c521 : Chart := ⟨[33280, 34816, 66048, 66560, 264192],[3584, 65536, 67584, 263680, 295936, 360448]⟩
def m521_519 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e521_519 : Edge c521 c519 m521_519 := by constructor <;> decide
theorem floor521 : Floor c521 4 := by
  have up := refundEdge e521_519 floor519 66560 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c522 : Chart := ⟨[33280, 34816, 66048, 66560, 262272, 264192],[3712, 33920, 67712, 98432, 262656, 263680, 295936, 360448]⟩
def m522_521 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e522_521 : Edge c522 c521 m522_521 := by constructor <;> decide
theorem floor522 : Floor c522 5 := by
  have up := refundEdge e522_521 floor521 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c523 : Chart := ⟨[33280, 66048, 69632, 266240],[512, 4608, 36864, 262656, 360448]⟩
def m523_464 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e523_464 : Edge c523 c464 m523_464 := by constructor <;> decide
theorem floor523 : Floor c523 3 := by
  have up := refundEdge e523_464 floor464 33280 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c524 : Chart := ⟨[33280, 66048, 69632, 262272, 266240],[4736, 36992, 98432, 262656, 360448]⟩
def m524_523 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e524_523 : Edge c524 c523 m524_523 := by constructor <;> decide
theorem floor524 : Floor c524 4 := by
  have up := refundEdge e524_523 floor523 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c525 : Chart := ⟨[33024, 33280, 66048, 69632, 266240],[4864, 32768, 36864, 262912, 327936, 360448]⟩
def m525_523 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e525_523 : Edge c525 c523 m525_523 := by constructor <;> decide
theorem floor525 : Floor c525 4 := by
  have up := refundEdge e525_523 floor523 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c526 : Chart := ⟨[33024, 33280, 66048, 69632, 262272, 266240],[4992, 36992, 65920, 98432, 262912, 327936, 360448]⟩
def m526_525 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
private theorem e526_525 : Edge c526 c525 m526_525 := by constructor <;> decide
theorem floor526 : Floor c526 5 := by
  have up := refundEdge e526_525 floor525 262272 262912 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c527 : Chart := ⟨[34816, 69632, 264192, 266240],[2048, 6144, 36864, 67584, 360448]⟩
def m527_468 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e527_468 : Edge c527 c468 m527_468 := by constructor <;> decide
theorem floor527 : Floor c527 3 := by
  have up := refundEdge e527_468 floor468 34816 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)

end TightRow.Protected.Numeric
