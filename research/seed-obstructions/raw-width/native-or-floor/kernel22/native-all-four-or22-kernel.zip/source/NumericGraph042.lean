import NumericEdgeCodes
import Branch358016
import NumericGraph005
import NumericGraph006
import NumericGraph039
import NumericGraph040
import NumericGraph041
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c504 : Chart := ⟨[16512, 16640, 17408, 66560, 69632, 262272, 264192, 266240],[3200, 4480, 5248, 7424, 18432, 22528, 67968, 83968, 263424, 327936, 344064]⟩
def m504_502 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e504_502 : Edge c504 c502 m504_502 := by
  exact edgeByCodes c504 c502 m504_502 1976943448883712 185046161011647906304 (by decide) (by decide) (by decide) (by decide)
theorem floor504 : Floor c504 7 := by
  have up := refundEdge e504_502 floor502 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c505 : Chart := ⟨[16512, 17408, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4736, 5248, 7168, 23040, 65664, 67712, 83968, 263680, 279040, 344064]⟩
def m505_502 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e505_502 : Edge c505 c502 m505_502 := by
  exact edgeByCodes c505 c502 m505_502 1976943448883456 185046161011631129088 (by decide) (by decide) (by decide) (by decide)
theorem floor505 : Floor c505 7 := by
  have up := refundEdge e505_502 floor502 66048 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c506 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 262272],[640, 1664, 65664, 90112, 263680, 271360, 279040, 335872, 344064]⟩
def m506_67 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
theorem e506_67 : Edge c506 c67 m506_67 := by
  exact edgeByCodes c506 c67 m506_67 5514788471040 12918850817 (by decide) (by decide) (by decide) (by decide)
theorem floor506 : Floor c506 6 := by
  have up := refundEdge e506_67 floor67 262272 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c507 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 262272, 264192],[3712, 11264, 18944, 67712, 92160, 262656, 263680, 271360, 279040, 335872, 344064]⟩
def m507_506 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e507_506 : Edge c507 c506 m507_506 := by
  exact edgeByCodes c507 c506 m507_506 1694364648734976 185118218605669056512 (by decide) (by decide) (by decide) (by decide)
theorem floor507 : Floor c507 7 := by
  have up := refundEdge e507_506 floor506 264192 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c508 : Chart := ⟨[8320, 8704, 16512, 66048, 69632, 262272, 266240],[640, 4736, 20992, 28672, 65664, 90112, 279040, 335872, 344064]⟩
def m508_478 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
theorem e508_478 : Edge c508 c478 m508_478 := by
  exact edgeByCodes c508 c478 m508_478 6618611908864 30165697281 (by decide) (by decide) (by decide) (by decide)
theorem floor508 : Floor c508 6 := by
  have up := refundEdge e508_478 floor478 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c509 : Chart := ⟨[8320, 8704, 16512, 16640, 66048, 69632, 262272, 266240],[4992, 12544, 16896, 20992, 28672, 65920, 90112, 262912, 279040, 336128, 344064]⟩
def m509_508 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e509_508 : Edge c509 c508 m509_508 := by
  exact edgeByCodes c509 c508 m509_508 1976943448817920 185118217501862461440 (by decide) (by decide) (by decide) (by decide)
theorem floor509 : Floor c509 7 := by
  have up := refundEdge e509_508 floor508 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c510 : Chart := ⟨[8320, 16512, 17408, 66560, 69632, 262272, 266240],[128, 5248, 13312, 28672, 65664, 90112, 271360, 335872, 344064]⟩
def m510_496 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e510_496 : Edge c510 c496 m510_496 := by
  exact edgeByCodes c510 c496 m510_496 6618611909121 34460664577 (by decide) (by decide) (by decide) (by decide)
theorem floor510 : Floor c510 6 := by
  have up := refundEdge e510_496 floor496 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c511 : Chart := ⟨[8196, 8320, 16512, 17408, 66560, 69632, 262272, 266240],[5252, 9216, 13312, 20484, 28672, 65668, 90112, 263172, 271360, 335872, 344068]⟩
def m511_510 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e511_510 : Edge c511 c510 m511_510 := by
  exact edgeByCodes c511 c510 m511_510 1976943448883713 185118217501862395904 (by decide) (by decide) (by decide) (by decide)
theorem floor511 : Floor c511 7 := by
  have up := refundEdge e511_510 floor510 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c512 : Chart := ⟨[2105408, 8320, 16512, 17408, 66560, 2166784, 262272, 2363392],[2102464, 2110464, 2117696, 2125824, 2162880, 90112, 2360384, 271360, 335872, 2441280]⟩
def m512_510 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, some 12]
theorem e512_510 : Edge c512 c510 m512_510 := by
  exact edgeByCodes c512 c510 m512_510 1976943448883713 166599133255314767872 (by decide) (by decide) (by decide) (by decide)
theorem floor512 : Floor c512 7 := by
  have up := refundEdge e512_510 floor510 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c513 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 69632, 262272, 266240],[1664, 4736, 5248, 13312, 20992, 28672, 65664, 90112, 263680, 271360, 279040, 335872, 344064]⟩
def m513_510 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e513_510 : Edge c513 c510 m513_510 := by
  exact edgeByCodes c513 c510 m513_510 2259522248966656 222156103416157504000 (by decide) (by decide) (by decide) (by decide)
def m513_508 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e513_508 : Edge c513 c508 m513_508 := by
  exact edgeByCodes c513 c508 m513_508 2259522232123648 222156384891134279936 (by decide) (by decide) (by decide) (by decide)
def m513_506 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e513_506 : Edge c513 c506 m513_506 := by
  exact edgeByCodes c513 c506 m513_506 1975839625445632 222156387098781155328 (by decide) (by decide) (by decide) (by decide)
def m513_499 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e513_499 : Edge c513 c499 m513_499 := by
  exact edgeByCodes c513 c499 m513_499 2259522249032450 867514700152307968 (by decide) (by decide) (by decide) (by decide)
def m513_482 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
theorem e513_482 : Edge c513 c482 m513_482 := by
  exact edgeByCodes c513 c482 m513_482 2259522249031936 795175631120892160 (by decide) (by decide) (by decide) (by decide)
def m513_78 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, none, none, none, none, none]
theorem e513_78 : Edge c513 c78 m513_78 := by
  exact edgeByCodes c513 c78 m513_78 1694364648734976 506097522914230528 (by decide) (by decide) (by decide) (by decide)
theorem floor513 : Floor c513 8 := by
  apply protectedBranch source c513.P c513.N (decode 292352) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 292352, q = 9 ∨ q = 10 ∨ q = 12 ∨ q = 13 ∨ q = 14 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e513_510 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor510 k x net fit)
    · refine ⟨_,goodChild e513_508 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor508 k x net fit)
    · refine ⟨_,goodChild e513_506 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor506 k x net fit)
    · refine ⟨_,goodChild e513_499 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor499 k x net fit)
    · refine ⟨_,goodChild e513_482 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor482 k x net fit)
    · refine ⟨_,goodChild e513_78 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor78 k x net fit)
  · exact pairExcluded 358016 292352 [8320, 8704, 16512, 17408, 66048, 66560, 69632, 262272, 266240] [1664, 4736, 5248, 13312, 20992, 28672, 65664, 90112, 263680, 271360, 279040, 335872, 344064] validBranch358016 (by decide) (by decide) (by decide)
def c514 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 66048, 66560, 69632, 262272, 266240],[1664, 4992, 5248, 13568, 16896, 20992, 28672, 65920, 90112, 263936, 271616, 279040, 336128, 344064]⟩
def m514_513 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e514_513 : Edge c514 c513 m514_513 := by
  exact edgeByCodes c514 c513 m514_513 166599134359138205952 1033693278377572253517264060672 (by decide) (by decide) (by decide) (by decide)
theorem floor514 : Floor c514 9 := by
  have up := refundEdge e514_513 floor513 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c515 : Chart := ⟨[8196, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 69632, 262272, 266240],[1664, 4992, 5252, 9472, 13568, 20996, 28672, 65924, 90112, 263940, 271616, 279044, 327940, 336128, 344068]⟩
def m515_514 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e515_514 : Edge c515 c514 m515_514 := by
  exact edgeByCodes c515 c514 m515_514 47390263963055590408705 284987117030824431661969018323200 (by decide) (by decide) (by decide) (by decide)
theorem floor515 : Floor c515 10 := by
  have up := refundEdge e515_514 floor514 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)


end TightRow.Protected.Numeric
