import NumericEdgeCodes
import NumericGraph075Code00
import Branch515968
import NumericGraph028
import NumericGraph048
import NumericGraph058
import NumericGraph059
import NumericGraph066
import NumericGraph069
import NumericGraph070
import NumericGraph073
import NumericGraph074
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m903_902 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, some 7, none]
theorem e903_902 : Edge c903 c902 m903_902 := by
  exact edgeByCodes c903 c902 m903_902 284987427729482439104532251279616 2273458514720957986802998296163153432937731 (by decide) (by decide) (by decide) (by decide)
theorem floor903 : Floor c903 13 := by
  have up := refundEdge e903_902 floor902 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c904 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2101696, 2102080, 2102592, 2103616, 2104576, 2120256, 2135232, 2150464, 2165184, 2181184, 2195648, 2232448, 2233216, 2249216, 2265216, 2281472, 196992, 229504, 2361152, 2376256, 2393152, 2425152, 2474048, 393984, 410112, 459008]⟩
def m904_902 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e904_902 : Edge c904 c902 m904_902 := by
  exact edgeByCodes c904 c902 m904_902 284987427729482439104532251279616 2273458514720957986802998296163153432937728 (by decide) (by decide) (by decide) (by decide)
theorem floor904 : Floor c904 13 := by
  have up := refundEdge e904_902 floor902 2228288 2232448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c905 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 33280, 66048, 66560, 131136, 132096, 262272],[640, 1664, 33984, 90112, 98496, 131712, 188416, 229504, 263744, 279104, 296000, 304128, 376896, 410112, 466944]⟩
def m905_800 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e905_800 : Edge c905 c800 m905_800 := by
  exact edgeByCodes c905 c800 m905_800 47390263963051278598400 284987425316353166358139268825600 (by decide) (by decide) (by decide) (by decide)
theorem floor905 : Floor c905 10 := by
  have up := refundEdge e905_800 floor800 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c906 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 132096, 262272],[1664, 33920, 90112, 131968, 188416, 196992, 229504, 263936, 271616, 304128, 376832, 393984, 410112, 467200]⟩
def m906_587 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e906_587 : Edge c906 c587 m906_587 := by
  exact edgeByCodes c906 c587 m906_587 47371744878809042780416 203856862059308860094859268064000 (by decide) (by decide) (by decide) (by decide)
theorem floor906 : Floor c906 10 := by
  have up := refundEdge e906_587 floor587 132096 1664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c907 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 131136, 132096, 262272],[1664, 9472, 33984, 65984, 90112, 98496, 131968, 188416, 196992, 229504, 264000, 271616, 279104, 296000, 304128, 328000, 376896, 393984, 410112, 467200]⟩
def m907_906 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e907_906 : Edge c907 c906 m907_906 := by
  exact edgeByCodes c907 c906 m907_906 14559222465821475332096513 386797170048935340894943948571136 (by decide) (by decide) (by decide) (by decide)
theorem floor907 : Floor c907 11 := by
  have up := refundEdge e907_906 floor906 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c908 : Chart := ⟨[8256, 8320, 8704, 16512, 33280, 34816, 66048, 131136, 133120, 262272, 264192],[640, 2688, 19008, 67776, 84032, 92160, 98496, 131712, 188416, 229504, 279104, 303104, 376896, 410112, 466944]⟩
def m908_842 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, some 15, some 16, some 17, some 18, none, none, none]
theorem e908_842 : Edge c908 c842 m908_842 := by
  exact edgeByCodes c908 c842 m908_842 47390263963055590342912 284987427729500958188778781999616 (by decide) (by decide) (by decide) (by decide)
theorem floor908 : Floor c908 10 := by
  have up := refundEdge e908_842 floor842 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c909 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 133120, 262272, 264192],[640, 2688, 18944, 67968, 76032, 92160, 131968, 188416, 196992, 229504, 303104, 376832, 393984, 410112, 467200]⟩
def m909_710 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, some 18, none, none, none]
theorem e909_710 : Edge c909 c710 m909_710 := by
  exact edgeByCodes c909 c710 m909_710 47390263680476790259968 1034313462063776290583141941507 (by decide) (by decide) (by decide) (by decide)
theorem floor909 : Floor c909 10 := by
  have up := refundEdge e909_710 floor710 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c910 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 131136, 133120, 262272, 264192],[2688, 8448, 19008, 68032, 76032, 84032, 92160, 98496, 131968, 188416, 196992, 229504, 262976, 279104, 303104, 328000, 376896, 393984, 410112, 467200]⟩
def m910_909 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, none]
theorem e910_909 : Edge c910 c909 m910_909 := by
  exact edgeByCodes c910 c909 m910_909 14559240912565549041648129 99020075532527447269104542715871232 (by decide) (by decide) (by decide) (by decide)
theorem floor910 : Floor c910 11 := by
  have up := refundEdge e910_909 floor909 8256 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c911 : Chart := ⟨[8256, 8320, 16512, 17408, 34816, 66560, 131136, 132096, 133120, 262272, 264192],[2176, 3200, 11264, 33984, 67776, 84032, 92160, 98496, 188416, 229504, 296000, 304128, 376896, 409600, 466944]⟩
def m911_802 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e911_802 : Edge c911 c802 m911_802 := by
  exact edgeByCodes c911 c802 m911_802 47390263963055573565696 284987427729500957906199981916929 (by decide) (by decide) (by decide) (by decide)
theorem floor911 : Floor c911 10 := by
  have up := refundEdge e911_802 floor802 34816 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)


end TightRow.Protected.Numeric
