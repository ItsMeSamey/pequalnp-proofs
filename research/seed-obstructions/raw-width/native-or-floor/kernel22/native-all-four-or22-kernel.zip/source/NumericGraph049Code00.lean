import NumericEdgeCodes
import Branch388736
import Branch390016
import NumericGraph009
import NumericGraph037
import NumericGraph038
import NumericGraph042
import NumericGraph044
import NumericGraph045
import NumericGraph046
import NumericGraph047
import NumericGraph048
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c588 : Chart := ⟨[8320, 8704, 16512, 33280, 34816, 66048, 262272, 264192],[640, 2688, 18944, 57344, 67712, 92160, 98432, 279040, 303104, 335872, 376832]⟩
def m588_538 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e588_538 : Edge c588 c538 m588_538 := by
  exact edgeByCodes c588 c538 m588_538 1976943448883456 185118218605685899520 (by decide) (by decide) (by decide) (by decide)
theorem floor588 : Floor c588 7 := by
  have up := refundEdge e588_538 floor538 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c589 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 262272, 264192],[3712, 11264, 18944, 33920, 57344, 67712, 92160, 98432, 263680, 279040, 304128, 335872, 376832]⟩
def m589_588 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e589_588 : Edge c589 c588 m589_588 := by
  exact edgeByCodes c589 c588 m589_588 650776764766880000 14559240984623143079510016 (by decide) (by decide) (by decide) (by decide)
def m589_586 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e589_586 : Edge c589 c586 m589_586 := by
  exact edgeByCodes c589 c586 m589_586 578437691440496896 14559240984905721862881280 (by decide) (by decide) (by decide) (by decide)
def m589_560 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e589_560 : Edge c589 c560 m589_560 := by
  exact edgeByCodes c589 c560 m589_560 650777868590383874 56853516013041428398592 (by decide) (by decide) (by decide) (by decide)
def m589_539 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e589_539 : Edge c589 c539 m589_539 := by
  exact edgeByCodes c589 c539 m589_539 650777868590383360 14559240912565549058425088 (by decide) (by decide) (by decide) (by decide)
def m589_507 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e589_507 : Edge c589 c507 m589_507 := by
  exact edgeByCodes c589 c507 m589_507 650777868556697856 14559222610220341719597312 (by decide) (by decide) (by decide) (by decide)
def m589_455 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
theorem e589_455 : Edge c589 c455 m589_455 := by
  exact edgeByCodes c589 c455 m589_455 650775660943507712 56853516009730025324800 (by decide) (by decide) (by decide) (by decide)
def m589_112 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
theorem e589_112 : Edge c589 c112 m589_112 := by
  exact edgeByCodes c589 c112 m589_112 506097522914230528 56797958760331867193600 (by decide) (by decide) (by decide) (by decide)
theorem floor589 : Floor c589 9 := by
  apply protectedBranch source c589.P c589.N (decode 388096) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 388096, q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e589_588 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor588 k x net fit)
    · refine ⟨_,goodChild e589_586 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor586 k x net fit)
    · refine ⟨_,goodChild e589_560 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor560 k x net fit)
    · refine ⟨_,goodChild e589_539 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor539 k x net fit)
    · refine ⟨_,goodChild e589_507 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor507 k x net fit)
    · refine ⟨_,goodChild e589_455 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor455 k x net fit)
    · refine ⟨_,goodChild e589_112 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor112 k x net fit)
  · exact pairExcluded 388736 388096 [8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 262272, 264192] [3712, 11264, 18944, 33920, 57344, 67712, 92160, 98432, 263680, 279040, 304128, 335872, 376832] validBranch388736 (by decide) (by decide) (by decide)
def c590 : Chart := ⟨[8196, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 262272, 264192],[3204, 3588, 3712, 9216, 11264, 18948, 33924, 57344, 67716, 83972, 92160, 98436, 263684, 279044, 295940, 304128, 335872, 376836]⟩
def m590_589 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e590_589 : Edge c590 c589 m590_589 := by
  exact edgeByCodes c590 c589 m590_589 47390263963055590408705 1351848718399850142927809741826 (by decide) (by decide) (by decide) (by decide)
theorem floor590 : Floor c590 10 := by
  have up := refundEdge e590_589 floor589 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c591 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 262272, 264192],[3712, 9216, 11264, 19008, 33984, 57344, 67776, 84032, 92160, 98496, 263744, 279104, 296000, 304128, 335872, 376896]⟩
def m591_589 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e591_589 : Edge c591 c589 m591_589 := by
  exact edgeByCodes c591 c589 m591_589 47390263963055590408705 1192770996018268414112537182720 (by decide) (by decide) (by decide) (by decide)
theorem floor591 : Floor c591 10 := by
  have up := refundEdge e591_589 floor589 8256 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c592 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 262272, 264192],[896, 3712, 11520, 18944, 33920, 57344, 67968, 76032, 92160, 98432, 263936, 271616, 279040, 304128, 336128, 376832]⟩
def m592_589 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e592_589 : Edge c592 c589 m592_589 := by
  exact edgeByCodes c592 c589 m592_589 52131149530171766341888 1192771000740634896982182396417 (by decide) (by decide) (by decide) (by decide)
theorem floor592 : Floor c592 10 := by
  have up := refundEdge e592_589 floor589 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c593 : Chart := ⟨[8196, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 262272, 264192],[896, 3204, 3332, 3588, 3712, 9472, 11520, 18948, 33924, 57344, 67972, 76032, 83972, 92160, 98436, 263940, 271616, 279044, 295940, 304128, 327940, 336128, 376836]⟩
def m593_592 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e593_592 : Edge c593 c592 m593_592 := by
  exact edgeByCodes c593 c592 m593_592 3727165692135864801209549313 29352440858928573106484321721843581952 (by decide) (by decide) (by decide) (by decide)
theorem floor593 : Floor c593 11 := by
  have up := refundEdge e593_592 floor592 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c594 : Chart := ⟨[8320, 8704, 16512, 33280, 66048, 69632, 262272, 266240],[640, 4736, 20992, 36992, 61440, 90112, 98432, 279040, 303104, 335872, 376832]⟩
def m594_540 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e594_540 : Edge c594 c540 m594_540 := by
  exact edgeByCodes c594 c540 m594_540 1976943448883456 185118218605669056768 (by decide) (by decide) (by decide) (by decide)
theorem floor594 : Floor c594 7 := by
  have up := refundEdge e594_540 floor540 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c595 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 66048, 69632, 262272, 266240],[4992, 12544, 20992, 36992, 61440, 65920, 90112, 98432, 262912, 279040, 303104, 336128, 376832]⟩
def m595_594 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e595_594 : Edge c595 c594 m595_594 := by
  exact edgeByCodes c595 c594 m595_594 650777868590252288 14559240984623138767765504 (by decide) (by decide) (by decide) (by decide)
def m595_585 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e595_585 : Edge c595 c585 m595_585 := by
  exact edgeByCodes c595 c585 m595_585 578155116952158464 14559240984905721879724032 (by decide) (by decide) (by decide) (by decide)
def m595_566 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, none, some 14, some 15, some 16, none, some 18, none, none, none]
theorem e595_566 : Edge c595 c566 m595_566 := by
  exact edgeByCodes c595 c566 m595_566 650777868590383874 56871962757110826205696 (by decide) (by decide) (by decide) (by decide)
def m595_541 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, some 13, none, some 15, some 16, none, some 18, none, none, none]
theorem e595_541 : Edge c595 c541 m595_541 := by
  exact edgeByCodes c595 c541 m595_541 650777868590383360 14559240912564445218275584 (by decide) (by decide) (by decide) (by decide)
def m595_509 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, some 13, some 14, none, some 16, none, some 18, none, none, none]
theorem e595_509 : Edge c595 c509 m595_509 := by
  exact edgeByCodes c595 c509 m595_509 650777868556697856 14559222465538896515170560 (by decide) (by decide) (by decide) (by decide)
def m595_458 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, some 12, some 13, some 14, some 15, none, none, some 18, none, none, none]
theorem e595_458 : Edge c595 c458 m595_458 := by
  exact edgeByCodes c595 c458 m595_458 650775660943507712 56853516858557246603520 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
