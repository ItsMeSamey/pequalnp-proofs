import NumericEdgeCodes
import NumericGraph068Code00
import Branch491200
import NumericGraph024
import NumericGraph025
import NumericGraph043
import NumericGraph056
import NumericGraph065
import NumericGraph066
import NumericGraph067
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

theorem floor822 : Floor c822 12 := by
  apply protectedBranch source c822.P c822.N (decode 490048) 12
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 490048, q = 6 ∨ q = 9 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 14 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e822_821 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor821 k x net fit)
    · refine ⟨_,goodChild e822_817 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor817 k x net fit)
    · refine ⟨_,goodChild e822_813 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor813 k x net fit)
    · refine ⟨_,goodChild e822_805 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor805 k x net fit)
    · refine ⟨_,goodChild e822_796 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor796 k x net fit)
    · refine ⟨_,goodChild e822_782 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor782 k x net fit)
    · refine ⟨_,goodChild e822_674 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor674 k x net fit)
    · refine ⟨_,goodChild e822_517 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor517 k x net fit)
    · refine ⟨_,goodChild e822_299 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor299 k x net fit)
  · exact pairExcluded 491200 490048 [8256, 8320, 8704, 16512, 17408, 66048, 66560, 69632, 131136, 132096, 133120, 262272, 264192, 266240] [3712, 5312, 15360, 23104, 30720, 67776, 84032, 92160, 135808, 152064, 159744, 196736, 263744, 271360, 279104, 344128, 410112, 466944] validBranch491200 (by decide) (by decide) (by decide)
def c823 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 5248, 15616, 18944, 23040, 30720, 67968, 76032, 92160, 136064, 143616, 152064, 159744, 196992, 263936, 271616, 344064, 393984, 410112, 467200]⟩
def m823_821 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e823_821 : Edge c823 c821 m823_821 := by
  exact edgeByCodes c823 c821 m823_821 3727165692135864801209483520 6489374457521072043083342666538231660800 (by decide) (by decide) (by decide) (by decide)
theorem floor823 : Floor c823 11 := by
  have up := refundEdge e823_821 floor821 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c824 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2101696, 2102080, 2102464, 2102592, 2103616, 2112768, 18944, 2120256, 2127872, 2165184, 76032, 2181184, 92160, 2233216, 2240768, 2249216, 2256896, 196992, 2361152, 271616, 2376256, 2425152, 2441280, 393984, 410112, 467200]⟩
def m824_822 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e824_822 : Edge c824 c822 m824_822 := by
  exact edgeByCodes c824 c822 m824_822 284987427729500958188778782064896 2273457175088086075213799945788010535453440 (by decide) (by decide) (by decide) (by decide)
theorem floor824 : Floor c824 13 := by
  have up := refundEdge e824_822 floor822 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)
def c825 : Chart := ⟨[8196, 2105408, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3204, 3332, 3588, 3712, 2101696, 2102080, 2102340, 2102404, 2102464, 2102592, 2103616, 2104324, 9472, 2112768, 2119748, 2120196, 2120256, 2127872, 2165060, 67972, 2165184, 76032, 2181188, 92160, 2232452, 2233216, 2240768, 2249220, 2256896, 196996, 2360644, 263940, 2361152, 271616, 2376256, 2425156, 2441284, 393988, 410116, 459012, 467200]⟩
def m825_824 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, none, some 21]
theorem e825_824 : Edge c825 c824 m825_824 := by
  exact edgeByCodes c825 c824 m825_824 78169440305751915386146223737209345 16516342357740646216746897343594697822878277312846712463084028931 (by decide) (by decide) (by decide) (by decide)
theorem floor825 : Floor c825 14 := by
  have up := refundEdge e825_824 floor824 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 14 ≤ 14).trans (up k x net fit)
def c826 : Chart := ⟨[8196, 2105408, 1056896, 8704, 1065088, 16640, 17408, 66048, 66560, 2166784, 1179649, 2228288, 132096, 133120, 1310848, 264192, 2363392],[1049473, 1049733, 1050241, 1051265, 1051780, 3332, 3588, 1052288, 3150017, 3150272, 3150465, 2102080, 2102340, 3150977, 3150980, 3151040, 2102592, 2103616, 2104324, 3159041, 2112768, 1067525, 3166785, 2119748, 3168769, 2120196, 2120256, 3176449, 3211713, 1116293, 2165060, 1116545, 1116548, 3213760, 1124609, 1132549, 2181188, 1140737, 1180032, 3281028, 3281792, 2240768, 2249220, 2256896, 1245572, 3408705, 2360644, 1312261, 1312513, 263940, 2361152, 1320193, 1327621, 3424833, 3473729, 2425156, 1384705, 3489861, 393988, 410116, 459012, 467200]⟩
def m826_825 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, none, some 16, some 17, some 18, none, some 7, some 21]
theorem e826_825 : Edge c826 c825 m826_825 := by
  exact edgeByCodes c826 c825 m826_825 21345817372864401140961492072029880576 130797761527391227269227871187952893141394928394345113118921649011808752020545430690320356097787140 (by decide) (by decide) (by decide) (by decide)
theorem floor826 : Floor c826 15 := by
  have up := refundEdge e826_825 floor825 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 15 ≤ 15).trans (up k x net fit)
def c827 : Chart := ⟨[33280, 34816, 66048, 66560, 132096, 133120, 264192],[2048, 3584, 67584, 229376, 263680, 295936, 360448, 393728, 458752]⟩
def m827_305 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
theorem e827_305 : Edge c827 c305 m827_305 := by
  exact edgeByCodes c827 c305 m827_305 5514788471040 13002474753 (by decide) (by decide) (by decide) (by decide)
theorem floor827 : Floor c827 6 := by
  have up := refundEdge e827_305 floor305 264192 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)


end TightRow.Protected.Numeric
