import NumericGraph032
import NumericGraph037
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c456 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 262272, 264192],[896, 2432, 3712, 11520, 18944, 26624, 33920, 57344, 263936, 271616, 279040, 304128, 311296]⟩
def m456_454 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e456_454 : Edge c456 c454 m456_454 := by constructor <;> decide
theorem floor456 : Floor c456 9 := by
  have up := refundEdge e456_454 floor454 17408 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c457 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 262272, 264192],[896, 2496, 3712, 9472, 11520, 19008, 26624, 33984, 57344, 264000, 271616, 279104, 296000, 304128, 311360]⟩
def m457_456 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e457_456 : Edge c457 c456 m457_456 := by constructor <;> decide
theorem floor457 : Floor c457 10 := by
  have up := refundEdge e457_456 floor456 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c458 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 262272, 266240],[4992, 12544, 20992, 36992, 61440, 262912, 270592, 279040, 303104, 311296]⟩
def m458_449 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e458_449 : Edge c458 c449 m458_449 := by constructor <;> decide
theorem floor458 : Floor c458 7 := by
  have up := refundEdge e458_449 floor449 266240 262912 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c459 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 34816, 262272, 264192, 266240],[2432, 2688, 4992, 14592, 23040, 30720, 36992, 61440, 262912, 270592, 279040, 303104, 311296]⟩
def m459_454 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e459_454 : Edge c459 c454 m459_454 := by constructor <;> decide
theorem floor459 : Floor c459 9 := by
  have up := refundEdge e459_454 floor454 266240 262912 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c460 : Chart := ⟨[8196, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 262272, 264192, 266240],[2436, 2688, 4992, 8448, 14592, 23044, 30720, 36996, 53252, 61440, 262916, 270592, 279044, 303104, 311300]⟩
def m460_459 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e460_459 : Edge c460 c459 m460_459 := by constructor <;> decide
theorem floor460 : Floor c460 10 := by
  have up := refundEdge e460_459 floor459 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c461 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 262272, 264192, 266240],[2432, 3712, 4992, 15616, 18944, 23040, 30720, 38016, 46080, 61440, 263936, 271616, 279040, 304128, 311296]⟩
def m461_459 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e461_459 : Edge c461 c459 m461_459 := by constructor <;> decide
theorem floor461 : Floor c461 10 := by
  have up := refundEdge e461_459 floor459 17408 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c462 : Chart := ⟨[69632, 266240],[4096, 327680]⟩
def m462_386 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, none, some 12, none, none, none, none, none, some 18, none, none, none]
private theorem e462_386 : Edge c462 c386 m462_386 := by constructor <;> decide
theorem floor462 : Floor c462 1 := by
  have up := refundEdge e462_386 floor386 69632 4096 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c463 : Chart := ⟨[69632, 262272, 266240],[4224, 65664, 262144, 327680]⟩
def m463_462 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e463_462 : Edge c463 c462 m463_462 := by constructor <;> decide
theorem floor463 : Floor c463 2 := by
  have up := refundEdge e463_462 floor462 262272 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c464 : Chart := ⟨[66048, 69632, 266240],[4608, 65536, 262656, 327680]⟩
def m464_462 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e464_462 : Edge c464 c462 m464_462 := by constructor <;> decide
theorem floor464 : Floor c464 2 := by
  have up := refundEdge e464_462 floor462 66048 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c465 : Chart := ⟨[66048, 69632, 262272, 266240],[4736, 65664, 262656, 327680]⟩
def m465_464 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e465_464 : Edge c465 c464 m465_464 := by constructor <;> decide
theorem floor465 : Floor c465 3 := by
  have up := refundEdge e465_464 floor464 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c466 : Chart := ⟨[66560, 69632, 266240],[5120, 65536, 263168, 327680]⟩
def m466_462 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e466_462 : Edge c466 c462 m466_462 := by constructor <;> decide
theorem floor466 : Floor c466 2 := by
  have up := refundEdge e466_462 floor462 66560 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c467 : Chart := ⟨[66560, 69632, 262272, 266240],[5248, 65664, 262144, 263168, 327680]⟩
def m467_466 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e467_466 : Edge c467 c466 m467_466 := by constructor <;> decide
theorem floor467 : Floor c467 3 := by
  have up := refundEdge e467_466 floor466 262272 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)

end TightRow.Protected.Numeric
