import Branch465920
import NumericGraph021
import NumericGraph022
import NumericGraph039
import NumericGraph051
import NumericGraph052
import NumericGraph061
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c744 : Chart := ⟨[2166784, 2228288, 133120, 264192, 2363392],[2103360, 2164800, 2232320, 2424896, 458752]⟩
def m744_743 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, some 12]
private theorem e744_743 : Edge c744 c743 m744_743 := by constructor <;> decide
theorem floor744 : Floor c744 4 := by
  have up := refundEdge e744_743 floor743 2228288 2232320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c745 : Chart := ⟨[66048, 69632, 133120, 264192, 266240],[6656, 65536, 67584, 135680, 393728, 458752]⟩
def m745_743 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
private theorem e745_743 : Edge c745 c743 m745_743 := by constructor <;> decide
theorem floor745 : Floor c745 4 := by
  have up := refundEdge e745_743 floor743 66048 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c746 : Chart := ⟨[66048, 2166784, 2228288, 133120, 264192, 2363392],[2103872, 2164800, 2232320, 2232832, 2359872, 2424896, 393728, 458752]⟩
def m746_745 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, some 12]
private theorem e746_745 : Edge c746 c745 m746_745 := by constructor <;> decide
theorem floor746 : Floor c746 5 := by
  have up := refundEdge e746_745 floor745 2228288 2232320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c747 : Chart := ⟨[66560, 69632, 132096, 133120, 264192, 266240],[7168, 67584, 135168, 263168, 458752]⟩
def m747_743 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
private theorem e747_743 : Edge c747 c743 m747_743 := by constructor <;> decide
def m747_739 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
private theorem e747_739 : Edge c747 c739 m747_739 := by constructor <;> decide
def m747_735 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, none, some 16, some 17, some 18, none, none, none]
private theorem e747_735 : Edge c747 c735 m747_735 := by constructor <;> decide
def m747_623 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, none, none, some 17, some 18, none, none, none]
private theorem e747_623 : Edge c747 c623 m747_623 := by constructor <;> decide
def m747_470 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e747_470 : Edge c747 c470 m747_470 := by constructor <;> decide
def m747_263 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, none, none, none, none]
private theorem e747_263 : Edge c747 c263 m747_263 := by constructor <;> decide
theorem floor747 : Floor c747 5 := by
  apply protectedBranch source c747.P c747.N (decode 465920) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 465920, q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 16 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e747_743 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor743 k x net fit)
    · refine ⟨_,goodChild e747_739 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor739 k x net fit)
    · refine ⟨_,goodChild e747_735 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor735 k x net fit)
    · refine ⟨_,goodChild e747_623 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor623 k x net fit)
    · refine ⟨_,goodChild e747_470 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor470 k x net fit)
    · refine ⟨_,goodChild e747_263 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor263 k x net fit)
  · exact pairExcluded 465920 465920 [66560, 69632, 132096, 133120, 264192, 266240] [7168, 67584, 135168, 263168, 458752] validBranch465920 (by decide) (by decide) (by decide)
def c748 : Chart := ⟨[66560, 69632, 131073, 132096, 133120, 264192, 266240],[5121, 6145, 7168, 67585, 131072, 135168, 263169, 327681, 458752]⟩
def m748_747 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
private theorem e748_747 : Edge c748 c747 m748_747 := by constructor <;> decide
theorem floor748 : Floor c748 6 := by
  have up := refundEdge e748_747 floor747 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c749 : Chart := ⟨[66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[2102336, 2103360, 2104320, 2164800, 2232320, 2360384, 2424896, 458752]⟩
def m749_747 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, some 12]
private theorem e749_747 : Edge c749 c747 m749_747 := by constructor <;> decide
theorem floor749 : Floor c749 6 := by
  have up := refundEdge e749_747 floor747 2228288 2232320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c750 : Chart := ⟨[66560, 69632, 132096, 133120, 262272, 264192, 266240],[3200, 5248, 7168, 67712, 135296, 196736, 262144, 263168, 458752]⟩
def m750_747 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
private theorem e750_747 : Edge c750 c747 m750_747 := by constructor <;> decide
theorem floor750 : Floor c750 6 := by
  have up := refundEdge e750_747 floor747 262272 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c751 : Chart := ⟨[66048, 66560, 69632, 132096, 133120, 264192, 266240],[3584, 6656, 7168, 65536, 67584, 135680, 263680, 393728, 458752]⟩
def m751_747 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
private theorem e751_747 : Edge c751 c747 m751_747 := by constructor <;> decide
theorem floor751 : Floor c751 6 := by
  have up := refundEdge e751_747 floor747 66048 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c752 : Chart := ⟨[66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 5248, 6656, 7168, 67712, 135808, 196736, 262656, 263680, 393728, 458752]⟩
def m752_751 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
private theorem e752_751 : Edge c752 c751 m752_751 := by constructor <;> decide
theorem floor752 : Floor c752 7 := by
  have up := refundEdge e752_751 floor751 262272 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c753 : Chart := ⟨[8256, 8320, 66560, 131136, 132096, 262272],[1152, 1216, 65728, 196736, 263232, 271360, 327744, 466944]⟩
def m753_625 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e753_625 : Edge c753 c625 m753_625 := by constructor <;> decide
theorem floor753 : Floor c753 5 := by
  have up := refundEdge e753_625 floor625 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c754 : Chart := ⟨[8320, 8704, 66048, 66560, 132096, 262272],[1664, 131712, 196736, 263680, 271360, 393728, 466944]⟩
def m754_472 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e754_472 : Edge c754 c472 m754_472 := by constructor <;> decide
theorem floor754 : Floor c754 5 := by
  have up := refundEdge e754_472 floor472 132096 1664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c755 : Chart := ⟨[8256, 8320, 8704, 66048, 66560, 131136, 132096, 262272],[640, 1216, 1664, 65728, 131712, 196736, 263744, 271360, 327744, 393728, 466944]⟩
def m755_271 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e755_271 : Edge c755 c271 m755_271 := by constructor <;> decide
theorem floor755 : Floor c755 7 := by
  have up := refundEdge e755_271 floor271 262272 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)

end TightRow.Protected.Numeric
