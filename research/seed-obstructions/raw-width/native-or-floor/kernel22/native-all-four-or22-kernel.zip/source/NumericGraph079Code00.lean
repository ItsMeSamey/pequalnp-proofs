import NumericEdgeCodes
import Branch524096
import Branch524224
import NumericGraph031
import NumericGraph050
import NumericGraph051
import NumericGraph060
import NumericGraph061
import NumericGraph068
import NumericGraph072
import NumericGraph075
import NumericGraph076
import NumericGraph077
import NumericGraph078
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c948 : Chart := ⟨[2105408, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120, 264192, 2363392],[3584, 2102080, 2102592, 2103616, 2112768, 2120256, 2127872, 2135104, 2143232, 2150464, 2165056, 76032, 2181184, 92160, 2233088, 2240768, 2249216, 2289664, 229376, 2361152, 271616, 2376256, 2393152, 304128, 2425152, 2474048, 393984, 410112, 467200]⟩
def m948_947 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 12]
theorem e948_947 : Edge c948 c947 m948_947 := by
  exact edgeByCodes c948 c947 m948_947 1113232139549844033678369554945 160456135160597708930617707120079730754460124160 (by decide) (by decide) (by decide) (by decide)
def m948_944 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e948_944 : Edge c948 c944 m948_944 := by
  exact edgeByCodes c948 c944 m948_944 1113232139568363117924917117184 160456047366423007629567743042240207007007376384 (by decide) (by decide) (by decide) (by decide)
def m948_940 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e948_940 : Edge c948 c940 m948_940 := by
  exact edgeByCodes c948 c940 m948_940 4348563045188918425065554432 689153477351446762571779986952820774618711585323470750209 (by decide) (by decide) (by decide) (by decide)
def m948_933 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e948_933 : Edge c948 c933 m948_933 := by
  exact edgeByCodes c948 c933 m948_933 4348563026669551604046364928 689153852963098935242138287648931434956669918892710363393 (by decide) (by decide) (by decide) (by decide)
def m948_927 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e948_927 : Edge c948 c927 m948_927 := by
  exact edgeByCodes c948 c927 m948_927 4346135711778553834835673344 689153852963099023037657834560238839593088869796723949825 (by decide) (by decide) (by decide) (by decide)
def m948_919 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, some 18, none, none, some 6]
theorem e948_919 : Edge c948 c919 m948_919 := by
  exact edgeByCodes c948 c919 m948_919 1033693278359053169270733275392 160456135161942574902823622003036258640567993344 (by decide) (by decide) (by decide) (by decide)
def m948_901 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e948_901 : Edge c948 c901 m948_901 := by
  exact edgeByCodes c948 c901 m948_901 1113232139568363117924917183234 2692007238137018103503670925572502024673709232547299584 (by decide) (by decide) (by decide) (by decide)
def m948_869 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, some 18, none, none, some 21]
theorem e948_869 : Edge c948 c869 m948_869 := by
  exact edgeByCodes c948 c869 m948_869 1113232139568363117924917182720 2691631626484932205148955431025552106997825243078328576 (by decide) (by decide) (by decide) (by decide)
def m948_730 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, none, some 17, some 18, none, none, some 21]
theorem e948_730 : Edge c948 c730 m948_730 := by
  exact edgeByCodes c948 c730 m948_730 4348563045188070692993761536 664729705274817540387651761628737597617130132808342307072 (by decide) (by decide) (by decide) (by decide)
def m948_611 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, none, some 18, none, none, some 21]
theorem e948_611 : Edge c948 c611 m948_611 := by
  exact edgeByCodes c948 c611 m948_611 4348548822532217080815681792 615689096749536129859482195015430982511741563676609609984 (by decide) (by decide) (by decide) (by decide)
def m948_379 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 21]
theorem e948_379 : Edge c948 c379 m948_379 := by
  exact edgeByCodes c948 c379 m948_379 954154417186781389109644624128 1734558464417939110684538691923800715749127347893239827 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
