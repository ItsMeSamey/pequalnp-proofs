import NumericEdgeCodes
import Branch474752
import Branch482432
import NumericGraph040
import NumericGraph041
import NumericGraph054
import NumericGraph062
import NumericGraph063
import NumericGraph064
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c780 : Chart := ⟨[8704, 66048, 66560, 69632, 132096, 133120, 264192, 266240],[512, 3584, 6656, 15360, 75776, 135680, 143360, 263680, 271360, 393728, 466944]⟩
def m780_751 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e780_751 : Edge c780 c751 m780_751 := by
  exact edgeByCodes c780 c751 m780_751 1976943448883713 185117934923079156225 (by decide) (by decide) (by decide) (by decide)
theorem floor780 : Floor c780 7 := by
  have up := refundEdge e780_751 floor751 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c781 : Chart := ⟨[8320, 8704, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3712, 5248, 6656, 15360, 67712, 75776, 135808, 143360, 196736, 263680, 271360, 393728, 466944]⟩
def m781_780 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e781_780 : Edge c781 c780 m781_780 := by
  exact edgeByCodes c781 c780 m781_780 650776764766945793 14559240984623143062732800 (by decide) (by decide) (by decide) (by decide)
def m781_779 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e781_779 : Edge c781 c779 m781_779 := by
  exact edgeByCodes c781 c779 m781_779 650777868590383872 14554481580254359139188736 (by decide) (by decide) (by decide) (by decide)
def m781_776 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e781_776 : Edge c781 c776 m781_776 := by
  exact edgeByCodes c781 c776 m781_776 650777868573475072 14559203946737228784467968 (by decide) (by decide) (by decide) (by decide)
def m781_771 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e781_771 : Edge c781 c771 m781_771 := by
  exact edgeByCodes c781 c771 m781_771 650494185966797056 56872035097287975960832 (by decide) (by decide) (by decide) (by decide)
def m781_763 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, some 18, none, none, none]
theorem e781_763 : Edge c781 c763 m781_763 := by
  exact edgeByCodes c781 c763 m781_763 578437695735464192 56872035097283664282368 (by decide) (by decide) (by decide) (by decide)
def m781_752 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e781_752 : Edge c781 c752 m781_752 := by
  exact edgeByCodes c781 c752 m781_752 650777868590383874 14559222538160540034924800 (by decide) (by decide) (by decide) (by decide)
def m781_486 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
theorem e781_486 : Edge c781 c486 m781_486 := by
  exact edgeByCodes c781 c486 m781_486 650777859966763264 14554499882319190996092416 (by decide) (by decide) (by decide) (by decide)
theorem floor781 : Floor c781 9 := by
  apply protectedBranch source c781.P c781.N (decode 147072) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 147072, q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 12 ∨ q = 13 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e781_780 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor780 k x net fit)
    · refine ⟨_,goodChild e781_779 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor779 k x net fit)
    · refine ⟨_,goodChild e781_776 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor776 k x net fit)
    · refine ⟨_,goodChild e781_771 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor771 k x net fit)
    · refine ⟨_,goodChild e781_763 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor763 k x net fit)
    · refine ⟨_,goodChild e781_752 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor752 k x net fit)
    · refine ⟨_,goodChild e781_486 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor486 k x net fit)
  · exact pairExcluded 474752 147072 [8320, 8704, 66048, 66560, 69632, 132096, 133120, 262272, 264192, 266240] [3712, 5248, 6656, 15360, 67712, 75776, 135808, 143360, 196736, 263680, 271360, 393728, 466944] validBranch474752 (by decide) (by decide) (by decide)
def c782 : Chart := ⟨[2105408, 8320, 8704, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3712, 2102464, 2103872, 2110464, 2112512, 2164928, 75776, 2232960, 2240512, 196736, 2360896, 271360, 2424896, 393728, 466944]⟩
def m782_781 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 12]
theorem e782_781 : Edge c782 c781 m782_781 := by
  exact edgeByCodes c782 c781 m782_781 52131149530167471440385 1113230925901657936179549569280 (by decide) (by decide) (by decide) (by decide)
theorem floor782 : Floor c782 10 := by
  have up := refundEdge e782_781 floor781 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c783 : Chart := ⟨[8196, 2105408, 8320, 8704, 66048, 66560, 2166784, 2228288, 132096, 133120, 262272, 264192, 2363392],[3204, 3588, 3712, 2102340, 2102404, 2102464, 2103364, 2103812, 2103872, 2104324, 9216, 2112512, 2164804, 67716, 2164928, 75776, 2232452, 2232836, 2232960, 2240512, 196740, 2360388, 263684, 2360896, 271360, 2424900, 393732, 458756, 466944]⟩
def m783_782 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, none, some 21]
theorem e783_782 : Edge c783 c782 m783_782 := by
  exact edgeByCodes c783 c782 m783_782 3727165692135864801209549313 145913642848273302320803536074966274 (by decide) (by decide) (by decide) (by decide)
theorem floor783 : Floor c783 11 := by
  have up := refundEdge e783_782 floor782 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c784 : Chart := ⟨[8196, 2105408, 1056896, 8704, 66048, 66560, 2166784, 1179649, 2228288, 132096, 133120, 1310848, 264192, 2363392],[1049733, 1050241, 1051141, 1051265, 1051780, 3588, 1052288, 3150017, 3150401, 3150465, 2102340, 3150977, 3150980, 3151040, 2103364, 3152385, 2103812, 2103872, 2104324, 3159041, 3160065, 2112512, 3211457, 2164804, 1116293, 3213504, 1124353, 1179776, 3281028, 2232836, 3281536, 2240512, 1245316, 3408449, 2360388, 1312261, 2360896, 1319937, 3473477, 1384449, 393732, 458756, 466944]⟩
def m784_783 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, none, none, some 16, some 17, some 18, none, some 7, some 21]
theorem e784_783 : Edge c784 c783 m784_783 := by
  exact edgeByCodes c784 c783 m784_783 1033693278377571970938480754944 1136652080321095456675378831447294610807595688166631870954601380709636 (by decide) (by decide) (by decide) (by decide)
theorem floor784 : Floor c784 12 := by
  have up := refundEdge e784_783 floor783 1179649 1179776 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 12 ≤ 12).trans (up k x net fit)
def c785 : Chart := ⟨[16512, 17408, 66560, 132096, 133120, 262272, 264192],[1152, 3200, 67712, 83968, 196736, 263168, 344064, 409600, 458752]⟩
def m785_650 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
theorem e785_650 : Edge c785 c650 m785_650 := by
  exact edgeByCodes c785 c650 m785_650 6618611908864 30148920065 (by decide) (by decide) (by decide) (by decide)
theorem floor785 : Floor c785 6 := by
  have up := refundEdge e785_650 floor650 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c786 : Chart := ⟨[16512, 17408, 66048, 66560, 132096, 133120, 262272, 264192],[3712, 18944, 65664, 67712, 83968, 131712, 196736, 263680, 344064, 410112, 458752]⟩
def m786_785 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e786_785 : Edge c786 c785 m786_785 := by
  exact edgeByCodes c786 c785 m786_785 1976943448883456 185118218605669056512 (by decide) (by decide) (by decide) (by decide)
theorem floor786 : Floor c786 7 := by
  have up := refundEdge e786_785 floor785 66048 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c787 : Chart := ⟨[16512, 17408, 66560, 69632, 132096, 262272, 266240],[1152, 5248, 135296, 151552, 196736, 263168, 344064, 409600, 458752]⟩
def m787_496 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e787_496 : Edge c787 c496 m787_496 := by
  exact edgeByCodes c787 c496 m787_496 6618595066112 25853952769 (by decide) (by decide) (by decide) (by decide)
theorem floor787 : Floor c787 6 := by
  have up := refundEdge e787_496 floor496 132096 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c788 : Chart := ⟨[1065088, 17408, 66560, 69632, 1179649, 132096, 1310848, 266240],[1053825, 1069057, 1114241, 1179776, 1183872, 151552, 1245312, 1311745, 1392641, 409600, 458752]⟩
def m788_787 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, some 17, some 18, none, some 7, none]
theorem e788_787 : Edge c788 c787 m788_787 := by
  exact edgeByCodes c788 c787 m788_787 1976943432040704 185118218605685899264 (by decide) (by decide) (by decide) (by decide)
theorem floor788 : Floor c788 7 := by
  have up := refundEdge e788_787 floor787 1179649 1179776 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c789 : Chart := ⟨[16512, 17408, 66560, 2166784, 2228288, 132096, 262272, 2363392],[2102464, 2117696, 2162880, 2232448, 2248704, 196736, 2360384, 2441280, 409600, 458752]⟩
def m789_787 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, some 17, some 18, none, none, some 12]
theorem e789_787 : Edge c789 c787 m789_787 := by
  exact edgeByCodes c789 c787 m789_787 1976943432040704 166599134359138271232 (by decide) (by decide) (by decide) (by decide)
theorem floor789 : Floor c789 7 := by
  have up := refundEdge e789_787 floor787 2228288 2232448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c790 : Chart := ⟨[17408, 66560, 69632, 132096, 133120, 264192, 266240],[1024, 7168, 22528, 83968, 151552, 263168, 344064, 409600, 458752]⟩
def m790_747 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e790_747 : Edge c790 c747 m790_747 := by
  exact edgeByCodes c790 c747 m790_747 6618611909121 34443887361 (by decide) (by decide) (by decide) (by decide)
theorem floor790 : Floor c790 6 := by
  have up := refundEdge e790_747 floor747 17408 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c791 : Chart := ⟨[16512, 17408, 66560, 69632, 132096, 133120, 262272, 264192, 266240],[3200, 5248, 7168, 22528, 67712, 83968, 135296, 151552, 196736, 263168, 344064, 409600, 458752]⟩
def m791_790 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e791_790 : Edge c791 c790 m791_790 := by
  exact edgeByCodes c791 c790 m791_790 2259517937222145 222156387094452437504 (by decide) (by decide) (by decide) (by decide)
def m791_787 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e791_787 : Edge c791 c787 m791_787 := by
  exact edgeByCodes c791 c787 m791_787 2258414113784064 222156387098781155584 (by decide) (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
