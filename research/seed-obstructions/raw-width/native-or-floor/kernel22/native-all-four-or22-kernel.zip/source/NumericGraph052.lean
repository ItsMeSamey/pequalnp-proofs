import Branch403648
import NumericGraph010
import NumericGraph032
import NumericGraph051
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c624 : Chart := ⟨[8256, 8320, 131136, 262272],[64, 192, 131200, 262208, 401408]⟩
def m624_388 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e624_388 : Edge c624 c388 m624_388 := by constructor <;> decide
theorem floor624 : Floor c624 3 := by
  have up := refundEdge e624_388 floor388 131136 64 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c625 : Chart := ⟨[8256, 8320, 131136, 132096, 262272],[1216, 131200, 263232, 271360, 401408]⟩
def m625_624 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e625_624 : Edge c625 c624 m625_624 := by constructor <;> decide
theorem floor625 : Floor c625 4 := by
  have up := refundEdge e625_624 floor624 132096 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c626 : Chart := ⟨[8256, 131136, 133120, 264192],[64, 2112, 10240, 262208, 401408]⟩
def m626_616 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
private theorem e626_616 : Edge c626 c616 m626_616 := by constructor <;> decide
theorem floor626 : Floor c626 3 := by
  have up := refundEdge e626_616 floor616 8256 64 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c627 : Chart := ⟨[8320, 133120, 262272, 264192],[128, 2176, 10240, 131200, 401408]⟩
def m627_617 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
private theorem e627_617 : Edge c627 c617 m627_617 := by constructor <;> decide
theorem floor627 : Floor c627 3 := by
  have up := refundEdge e627_617 floor617 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c628 : Chart := ⟨[8256, 8320, 131136, 133120, 262272, 264192],[2240, 10240, 131200, 262208, 401408]⟩
def m628_627 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e628_627 : Edge c628 c627 m628_627 := by constructor <;> decide
def m628_626 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e628_626 : Edge c628 c626 m628_626 := by constructor <;> decide
def m628_624 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e628_624 : Edge c628 c624 m628_624 := by constructor <;> decide
def m628_618 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
private theorem e628_618 : Edge c628 c618 m628_618 := by constructor <;> decide
def m628_391 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, none, none, none, some 18, none, none, none]
private theorem e628_391 : Edge c628 c391 m628_391 := by constructor <;> decide
def m628_131 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e628_131 : Edge c628 c131 m628_131 := by constructor <;> decide
theorem floor628 : Floor c628 5 := by
  apply protectedBranch source c628.P c628.N (decode 403648) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 403648, q = 6 ∨ q = 7 ∨ q = 11 ∨ q = 13 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e628_627 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor627 k x net fit)
    · refine ⟨_,goodChild e628_626 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor626 k x net fit)
    · refine ⟨_,goodChild e628_624 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor624 k x net fit)
    · refine ⟨_,goodChild e628_618 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor618 k x net fit)
    · refine ⟨_,goodChild e628_391 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor391 k x net fit)
    · refine ⟨_,goodChild e628_131 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor131 k x net fit)
  · exact pairExcluded 403648 403648 [8256, 8320, 131136, 133120, 262272, 264192] [2240, 10240, 131200, 262208, 401408] validBranch403648 (by decide) (by decide) (by decide)
def c629 : Chart := ⟨[8196, 8256, 8320, 131136, 133120, 262272, 264192],[2116, 2180, 2240, 8192, 10240, 131204, 262212, 393220, 401408]⟩
def m629_628 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e629_628 : Edge c629 c628 m629_628 := by constructor <;> decide
theorem floor629 : Floor c629 6 := by
  have up := refundEdge e629_628 floor628 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c630 : Chart := ⟨[8256, 8704, 131136, 133120, 264192],[2624, 8192, 10240, 262720, 393728, 401408]⟩
def m630_626 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e630_626 : Edge c630 c626 m630_626 := by constructor <;> decide
theorem floor630 : Floor c630 4 := by
  have up := refundEdge e630_626 floor626 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c631 : Chart := ⟨[8320, 8704, 133120, 262272, 264192],[2688, 8192, 10240, 131712, 393728, 401408]⟩
def m631_627 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e631_627 : Edge c631 c627 m631_627 := by constructor <;> decide
theorem floor631 : Floor c631 4 := by
  have up := refundEdge e631_627 floor627 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c632 : Chart := ⟨[8256, 8320, 8704, 131136, 133120, 262272, 264192],[2240, 2624, 2688, 8192, 10240, 131712, 262720, 393728, 401408]⟩
def m632_628 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e632_628 : Edge c632 c628 m632_628 := by constructor <;> decide
theorem floor632 : Floor c632 6 := by
  have up := refundEdge e632_628 floor628 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c633 : Chart := ⟨[8320, 132096, 133120, 262272, 264192],[3200, 11264, 131200, 271360, 401408]⟩
def m633_627 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e633_627 : Edge c633 c627 m633_627 := by constructor <;> decide
theorem floor633 : Floor c633 4 := by
  have up := refundEdge e633_627 floor627 132096 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c634 : Chart := ⟨[8256, 8320, 131136, 132096, 133120, 262272, 264192],[1216, 2240, 3200, 11264, 131200, 263232, 271360, 401408]⟩
def m634_628 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e634_628 : Edge c634 c628 m634_628 := by constructor <;> decide
theorem floor634 : Floor c634 6 := by
  have up := refundEdge e634_628 floor628 132096 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c635 : Chart := ⟨[8320, 8704, 132096, 133120, 262272, 264192],[3712, 9216, 11264, 131712, 263680, 271360, 393728, 401408]⟩
def m635_633 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, some 13, none, none, none, some 17, some 18, none, none, none]
private theorem e635_633 : Edge c635 c633 m635_633 := by constructor <;> decide
theorem floor635 : Floor c635 5 := by
  have up := refundEdge e635_633 floor633 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)

end TightRow.Protected.Numeric
