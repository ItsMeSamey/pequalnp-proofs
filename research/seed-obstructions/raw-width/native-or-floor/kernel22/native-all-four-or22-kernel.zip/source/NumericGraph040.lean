import NumericGraph033
import NumericGraph038
import NumericGraph039
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c480 : Chart := ⟨[8320, 66560, 69632, 262272, 266240],[5248, 13312, 65664, 271360, 335872]⟩
def m480_475 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e480_475 : Edge c480 c475 m480_475 := by constructor <;> decide
theorem floor480 : Floor c480 4 := by
  have up := refundEdge e480_475 floor475 66560 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c481 : Chart := ⟨[2105408, 8320, 66560, 2166784, 262272, 2363392],[2102464, 2110464, 2162880, 2360384, 271360, 2424896, 335872]⟩
def m481_480 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, some 13, none, none, some 16, none, some 18, none, none, some 12]
private theorem e481_480 : Edge c481 c480 m481_480 := by constructor <;> decide
theorem floor481 : Floor c481 5 := by
  have up := refundEdge e481_480 floor480 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c482 : Chart := ⟨[8320, 8704, 66048, 66560, 69632, 262272, 266240],[1664, 4736, 5248, 13312, 65664, 263680, 271360, 335872]⟩
def m482_478 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e482_478 : Edge c482 c478 m482_478 := by constructor <;> decide
theorem floor482 : Floor c482 6 := by
  have up := refundEdge e482_478 floor478 66560 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c483 : Chart := ⟨[8704, 66048, 69632, 264192, 266240],[6656, 14336, 75776, 262656, 335872]⟩
def m483_476 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e483_476 : Edge c483 c476 m483_476 := by constructor <;> decide
theorem floor483 : Floor c483 4 := by
  have up := refundEdge e483_476 floor476 264192 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c484 : Chart := ⟨[2105408, 8704, 66048, 2166784, 264192, 2363392],[2103872, 2109440, 2111488, 2164800, 75776, 2359872, 2424896, 335872]⟩
def m484_483 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, some 13, none, none, some 16, none, some 18, none, none, some 12]
private theorem e484_483 : Edge c484 c483 m484_483 := by constructor <;> decide
theorem floor484 : Floor c484 5 := by
  have up := refundEdge e484_483 floor483 2105408 2109440 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c485 : Chart := ⟨[8320, 8704, 66048, 69632, 262272, 264192, 266240],[2688, 4736, 6656, 14336, 67712, 75776, 262656, 335872]⟩
def m485_478 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e485_478 : Edge c485 c478 m485_478 := by constructor <;> decide
theorem floor485 : Floor c485 6 := by
  have up := refundEdge e485_478 floor478 264192 262656 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c486 : Chart := ⟨[8320, 8704, 66048, 66560, 69632, 262272, 264192, 266240],[3712, 4736, 5248, 6656, 15360, 65664, 67712, 75776, 263680, 271360, 335872]⟩
def m486_485 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, some 13, none, none, some 16, none, some 18, none, none, none]
private theorem e486_485 : Edge c486 c485 m486_485 := by constructor <;> decide
theorem floor486 : Floor c486 7 := by
  have up := refundEdge e486_485 floor485 66560 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c487 : Chart := ⟨[16512, 17408, 66560, 262272],[1152, 65664, 263168, 344064]⟩
def m487_398 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e487_398 : Edge c487 c398 m487_398 := by constructor <;> decide
theorem floor487 : Floor c487 3 := by
  have up := refundEdge e487_398 floor398 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c488 : Chart := ⟨[16512, 17408, 66048, 66560, 262272],[1664, 65664, 263680, 279040, 344064]⟩
def m488_487 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e488_487 : Edge c488 c487 m488_487 := by constructor <;> decide
theorem floor488 : Floor c488 4 := by
  have up := refundEdge e488_487 floor487 66048 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c489 : Chart := ⟨[16512, 17408, 66560, 262272, 264192],[3200, 67712, 83968, 262144, 263168, 344064]⟩
def m489_487 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e489_487 : Edge c489 c487 m489_487 := by constructor <;> decide
theorem floor489 : Floor c489 4 := by
  have up := refundEdge e489_487 floor487 264192 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c490 : Chart := ⟨[16512, 17408, 66048, 66560, 262272, 264192],[3712, 18944, 65664, 67712, 83968, 263680, 279040, 344064]⟩
def m490_489 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, some 16, none, some 18, none, none, none]
private theorem e490_489 : Edge c490 c489 m490_489 := by constructor <;> decide
theorem floor490 : Floor c490 5 := by
  have up := refundEdge e490_489 floor489 66048 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c491 : Chart := ⟨[16512, 69632, 262272, 266240],[128, 4224, 20480, 65664, 344064]⟩
def m491_463 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, some 12, none, none, none, some 16, none, some 18, none, none, none]
private theorem e491_463 : Edge c491 c463 m491_463 := by constructor <;> decide
theorem floor491 : Floor c491 3 := by
  have up := refundEdge e491_463 floor463 16512 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)

end TightRow.Protected.Numeric
