import Branch322432
import NumericGraph002
import NumericGraph003
import NumericGraph034
import NumericGraph035
import NumericGraph036
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c444 : Chart := ⟨[16640, 33024, 34816, 264192, 266240],[6400, 22528, 53248, 262400, 311296]⟩
def m444_434 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e444_434 : Edge c444 c434 m444_434 := by constructor <;> decide
theorem floor444 : Floor c444 4 := by
  have up := refundEdge e444_434 floor434 266240 262400 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c445 : Chart := ⟨[16512, 16640, 33024, 34816, 262272, 264192, 266240],[2432, 4480, 6400, 22528, 36992, 53248, 262400, 311296]⟩
def m445_435 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e445_435 : Edge c445 c435 m445_435 := by constructor <;> decide
theorem floor445 : Floor c445 6 := by
  have up := refundEdge e445_435 floor435 266240 262400 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c446 : Chart := ⟨[16512, 16640, 33024, 33280, 34816, 262272, 264192, 266240],[2432, 2688, 4992, 6400, 23040, 32896, 36992, 53248, 262912, 279040, 311296]⟩
def m446_445 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, some 12, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e446_445 : Edge c446 c445 m446_445 := by constructor <;> decide
theorem floor446 : Floor c446 7 := by
  have up := refundEdge e446_445 floor445 33280 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c447 : Chart := ⟨[16640, 17408, 33024, 34816, 264192, 266240],[7424, 18432, 22528, 37888, 53248, 263424, 295936, 311296]⟩
def m447_444 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, some 12, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e447_444 : Edge c447 c444 m447_444 := by constructor <;> decide
theorem floor447 : Floor c447 5 := by
  have up := refundEdge e447_444 floor444 17408 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c448 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 262272, 264192, 266240],[2432, 3200, 4480, 7424, 18432, 22528, 38016, 53248, 263424, 295936, 311296]⟩
def m448_445 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, some 12, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e448_445 : Edge c448 c445 m448_445 := by constructor <;> decide
theorem floor448 : Floor c448 7 := by
  have up := refundEdge e448_445 floor445 17408 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c449 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 262272],[640, 896, 32896, 57344, 262912, 270592, 279040, 303104, 311296]⟩
def m449_31 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e449_31 : Edge c449 c31 m449_31 := by constructor <;> decide
theorem floor449 : Floor c449 6 := by
  have up := refundEdge e449_31 floor31 262272 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c450 : Chart := ⟨[8320, 16512, 16640, 33024, 34816, 262272, 264192],[128, 2432, 10496, 26624, 32896, 57344, 270592, 303104, 311296]⟩
def m450_435 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e450_435 : Edge c450 c435 m450_435 := by constructor <;> decide
theorem floor450 : Floor c450 6 := by
  have up := refundEdge e450_435 floor435 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c451 : Chart := ⟨[8196, 8320, 16512, 16640, 33024, 34816, 262272, 264192],[2436, 8448, 10496, 18436, 26624, 32900, 57344, 262404, 270592, 303104, 311300]⟩
def m451_450 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e451_450 : Edge c451 c450 m451_450 := by constructor <;> decide
theorem floor451 : Floor c451 7 := by
  have up := refundEdge e451_450 floor450 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c452 : Chart := ⟨[8256, 8320, 16512, 16640, 33024, 34816, 262272, 264192],[2496, 8448, 10496, 18496, 26624, 32960, 57344, 262464, 270592, 303104, 311360]⟩
def m452_450 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e452_450 : Edge c452 c450 m452_450 := by constructor <;> decide
theorem floor452 : Floor c452 7 := by
  have up := refundEdge e452_450 floor450 8256 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c453 : Chart := ⟨[8320, 8704, 16512, 33280, 34816, 262272, 264192],[640, 2688, 18944, 26624, 32896, 57344, 279040, 303104, 311296]⟩
def m453_419 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e453_419 : Edge c453 c419 m453_419 := by constructor <;> decide
theorem floor453 : Floor c453 6 := by
  have up := refundEdge e453_419 floor419 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c454 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 34816, 262272, 264192],[896, 2432, 2688, 10496, 18944, 26624, 32896, 57344, 262912, 270592, 279040, 303104, 311296]⟩
def m454_453 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e454_453 : Edge c454 c453 m454_453 := by constructor <;> decide
def m454_450 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e454_450 : Edge c454 c450 m454_450 := by constructor <;> decide
def m454_449 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e454_449 : Edge c454 c449 m454_449 := by constructor <;> decide
def m454_436 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, none, some 14, some 15, none, none, some 18, none, none, none]
private theorem e454_436 : Edge c454 c436 m454_436 := by constructor <;> decide
def m454_422 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, none, some 15, none, none, some 18, none, none, none]
private theorem e454_422 : Edge c454 c422 m454_422 := by constructor <;> decide
def m454_41 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e454_41 : Edge c454 c41 m454_41 := by constructor <;> decide
theorem floor454 : Floor c454 8 := by
  apply protectedBranch source c454.P c454.N (decode 289536) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 289536, q = 8 ∨ q = 9 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e454_453 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor453 k x net fit)
    · refine ⟨_,goodChild e454_450 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor450 k x net fit)
    · refine ⟨_,goodChild e454_449 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor449 k x net fit)
    · refine ⟨_,goodChild e454_436 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor436 k x net fit)
    · refine ⟨_,goodChild e454_422 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor422 k x net fit)
    · refine ⟨_,goodChild e454_41 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor41 k x net fit)
  · exact pairExcluded 322432 289536 [8320, 8704, 16512, 16640, 33024, 33280, 34816, 262272, 264192] [896, 2432, 2688, 10496, 18944, 26624, 32896, 57344, 262912, 270592, 279040, 303104, 311296] validBranch322432 (by decide) (by decide) (by decide)
def c455 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 262272, 264192],[3712, 11264, 18944, 26624, 33920, 57344, 263680, 279040, 304128, 311296]⟩
def m455_453 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, some 14, some 15, none, none, some 18, none, none, none]
private theorem e455_453 : Edge c455 c453 m455_453 := by constructor <;> decide
theorem floor455 : Floor c455 7 := by
  have up := refundEdge e455_453 floor453 17408 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)

end TightRow.Protected.Numeric
