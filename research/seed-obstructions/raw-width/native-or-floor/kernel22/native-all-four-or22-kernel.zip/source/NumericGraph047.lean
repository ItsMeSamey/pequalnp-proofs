import NumericEdgeCodes
import NumericGraph047Code00
import Branch381824
import Branch382848
import NumericGraph008
import NumericGraph036
import NumericGraph037
import NumericGraph041
import NumericGraph043
import NumericGraph044
import NumericGraph045
import NumericGraph046
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m573_445 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, some 12, none, some 14, some 15, none, none, some 18, none, none, none]
theorem e573_445 : Edge c573 c445 m573_445 := by
  exact edgeByCodes c573 c445 m573_445 1976943432040704 723114729958146310 (by decide) (by decide) (by decide) (by decide)
theorem floor573 : Floor c573 7 := by
  have up := refundEdge e573_445 floor445 69632 4352 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c574 : Chart := ⟨[16512, 33280, 34816, 66048, 69632, 262272, 264192, 266240],[640, 2688, 4736, 23040, 36992, 53248, 67712, 83968, 98432, 279040, 376832]⟩
def m574_530 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e574_530 : Edge c574 c530 m574_530 := by
  exact edgeByCodes c574 c530 m574_530 1976943448883713 723118037099807233 (by decide) (by decide) (by decide) (by decide)
theorem floor574 : Floor c574 7 := by
  have up := refundEdge e574_530 floor530 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c575 : Chart := ⟨[16640, 33024, 33280, 34816, 66048, 69632, 264192, 266240],[768, 4864, 6400, 23040, 53248, 67840, 83968, 262912, 279040, 327936, 376832]⟩
def m575_531 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, some 11, some 12, none, none, some 15, some 16, none, some 18, none, none, none]
theorem e575_531 : Edge c575 c531 m575_531 := by
  exact edgeByCodes c575 c531 m575_531 1976943448883713 185117934923079156225 (by decide) (by decide) (by decide) (by decide)
theorem floor575 : Floor c575 7 := by
  have up := refundEdge e575_531 floor531 16640 768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)


end TightRow.Protected.Numeric
