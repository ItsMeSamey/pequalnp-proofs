import NumericEdgeCodes
import NumericGraph065Code00
import Branch474752
import Branch482432
import NumericGraph040
import NumericGraph041
import NumericGraph054
import NumericGraph062
import NumericGraph063
import NumericGraph064
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def m791_785 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, some 16, some 17, some 18, none, none, none]
theorem e791_785 : Edge c791 c785 m791_785 := by
  exact edgeByCodes c791 c785 m791_785 1976943448817920 222156387098747469824 (by decide) (by decide) (by decide) (by decide)
def m791_750 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, none, none, some 16, some 17, some 18, none, none, none]
theorem e791_750 : Edge c791 c750 m791_750 := by
  exact edgeByCodes c791 c750 m791_750 2259522249032450 222011989327576432896 (by decide) (by decide) (by decide) (by decide)
def m791_656 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, none, some 17, some 18, none, none, none]
theorem e791_656 : Edge c791 c656 m791_656 := by
  exact edgeByCodes c791 c656 m791_656 2259522249031936 203565244154338476288 (by decide) (by decide) (by decide) (by decide)
def m791_502 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, some 16, none, some 18, none, none, none]
theorem e791_502 : Edge c791 c502 m791_502 := by
  exact edgeByCodes c791 c502 m791_502 2259522215346432 185118497873015734528 (by decide) (by decide) (by decide) (by decide)
theorem floor791 : Floor c791 8 := by
  apply protectedBranch source c791.P c791.N (decode 219264) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 219264, q = 7 ∨ q = 11 ∨ q = 12 ∨ q = 14 ∨ q = 16 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e791_790 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor790 k x net fit)
    · refine ⟨_,goodChild e791_787 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor787 k x net fit)
    · refine ⟨_,goodChild e791_785 12 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor785 k x net fit)
    · refine ⟨_,goodChild e791_750 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor750 k x net fit)
    · refine ⟨_,goodChild e791_656 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor656 k x net fit)
    · refine ⟨_,goodChild e791_502 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor502 k x net fit)
  · exact pairExcluded 482432 219264 [16512, 17408, 66560, 69632, 132096, 133120, 262272, 264192, 266240] [3200, 5248, 7168, 22528, 67712, 83968, 135296, 151552, 196736, 263168, 344064, 409600, 458752] validBranch482432 (by decide) (by decide) (by decide)


end TightRow.Protected.Numeric
