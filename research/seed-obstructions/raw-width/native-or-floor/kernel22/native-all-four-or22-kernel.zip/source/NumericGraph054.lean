import Branch412800
import NumericGraph011
import NumericGraph012
import NumericGraph033
import NumericGraph051
import NumericGraph053
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c648 : Chart := ⟨[1065088, 16640, 1179649, 133120, 1310848, 264192],[1051009, 1067009, 1180032, 1310977, 1327105, 393472, 409600]⟩
def m648_647 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, none, none, some 17, some 18, none, some 7, none]
private theorem e648_647 : Edge c648 c647 m648_647 := by constructor <;> decide
theorem floor648 : Floor c648 5 := by
  have up := refundEdge e648_647 floor647 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c649 : Chart := ⟨[17408, 132096, 133120, 264192],[1024, 3072, 18432, 263168, 409600]⟩
def m649_619 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
private theorem e649_619 : Edge c649 c619 m649_619 := by constructor <;> decide
theorem floor649 : Floor c649 3 := by
  have up := refundEdge e649_619 floor619 17408 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c650 : Chart := ⟨[16512, 17408, 132096, 133120, 262272, 264192],[3200, 18432, 131200, 263168, 409600]⟩
def m650_649 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e650_649 : Edge c650 c649 m650_649 := by constructor <;> decide
def m650_646 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e650_646 : Edge c650 c646 m650_646 := by constructor <;> decide
def m650_645 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e650_645 : Edge c650 c645 m650_645 := by constructor <;> decide
def m650_620 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, none, none, none, some 17, some 18, none, none, none]
private theorem e650_620 : Edge c650 c620 m650_620 := by constructor <;> decide
def m650_401 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, none, none, some 18, none, none, none]
private theorem e650_401 : Edge c650 c401 m650_401 := by constructor <;> decide
def m650_140 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e650_140 : Edge c650 c140 m650_140 := by constructor <;> decide
theorem floor650 : Floor c650 5 := by
  apply protectedBranch source c650.P c650.N (decode 412800) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 412800, q = 7 ∨ q = 10 ∨ q = 11 ∨ q = 14 ∨ q = 17 ∨ q = 18 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e650_649 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor649 k x net fit)
    · refine ⟨_,goodChild e650_646 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor646 k x net fit)
    · refine ⟨_,goodChild e650_645 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor645 k x net fit)
    · refine ⟨_,goodChild e650_620 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor620 k x net fit)
    · refine ⟨_,goodChild e650_401 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor401 k x net fit)
    · refine ⟨_,goodChild e650_140 18 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor140 k x net fit)
  · exact pairExcluded 412800 412800 [16512, 17408, 132096, 133120, 262272, 264192] [3200, 18432, 131200, 263168, 409600] validBranch412800 (by decide) (by decide) (by decide)
def c651 : Chart := ⟨[16512, 17408, 131136, 132096, 133120, 262272, 264192],[1216, 2240, 3200, 18496, 131200, 263232, 278592, 409600]⟩
def m651_650 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e651_650 : Edge c651 c650 m651_650 := by constructor <;> decide
theorem floor651 : Floor c651 6 := by
  have up := refundEdge e651_650 floor650 131136 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c652 : Chart := ⟨[16512, 16640, 17408, 132096, 133120, 262272, 264192],[2432, 3200, 3328, 18432, 131456, 263424, 393472, 409600]⟩
def m652_650 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e652_650 : Edge c652 c650 m652_650 := by constructor <;> decide
theorem floor652 : Floor c652 6 := by
  have up := refundEdge e652_650 floor650 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c653 : Chart := ⟨[16512, 17408, 132096, 262272, 266240],[5248, 135296, 151552, 262144, 263168, 409600]⟩
def m653_645 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e653_645 : Edge c653 c645 m653_645 := by constructor <;> decide
theorem floor653 : Floor c653 4 := by
  have up := refundEdge e653_645 floor645 266240 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c654 : Chart := ⟨[1065088, 17408, 1179649, 132096, 1310848, 266240],[1053825, 1069057, 1179776, 1183872, 151552, 1311745, 1327105, 409600]⟩
def m654_653 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, none, some 14, none, none, some 17, some 18, none, some 7, none]
private theorem e654_653 : Edge c654 c653 m654_653 := by constructor <;> decide
theorem floor654 : Floor c654 5 := by
  have up := refundEdge e654_653 floor653 1179649 1179776 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c655 : Chart := ⟨[17408, 132096, 133120, 264192, 266240],[7168, 22528, 151552, 262144, 263168, 409600]⟩
def m655_649 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e655_649 : Edge c655 c649 m655_649 := by constructor <;> decide
theorem floor655 : Floor c655 4 := by
  have up := refundEdge e655_649 floor649 266240 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c656 : Chart := ⟨[16512, 17408, 132096, 133120, 262272, 264192, 266240],[3200, 5248, 7168, 22528, 135296, 151552, 262144, 263168, 409600]⟩
def m656_650 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e656_650 : Edge c656 c650 m656_650 := by constructor <;> decide
theorem floor656 : Floor c656 6 := by
  have up := refundEdge e656_650 floor650 266240 262144 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c657 : Chart := ⟨[16640, 17408, 132096, 133120, 264192, 266240],[7424, 18432, 22528, 135424, 151552, 263424, 393472, 409600]⟩
def m657_655 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e657_655 : Edge c657 c655 m657_655 := by constructor <;> decide
theorem floor657 : Floor c657 5 := by
  have up := refundEdge e657_655 floor655 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c658 : Chart := ⟨[16512, 16640, 17408, 132096, 133120, 262272, 264192, 266240],[2432, 3200, 5248, 7424, 18432, 22528, 135552, 151552, 263424, 393472, 409600]⟩
def m658_656 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, some 12, none, some 14, none, none, some 17, some 18, none, none, none]
private theorem e658_656 : Edge c658 c656 m658_656 := by constructor <;> decide
theorem floor658 : Floor c658 7 := by
  have up := refundEdge e658_656 floor656 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c659 : Chart := ⟨[8256, 8320, 16512, 17408, 131136, 132096, 262272],[128, 1216, 131200, 155648, 263232, 271360, 278592, 401408, 409600]⟩
def m659_146 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e659_146 : Edge c659 c146 m659_146 := by constructor <;> decide
theorem floor659 : Floor c659 6 := by
  have up := refundEdge e659_146 floor146 262272 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)

end TightRow.Protected.Numeric
