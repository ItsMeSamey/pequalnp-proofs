import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short488640
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8320, 16512, 17408, 66560, 69632, 131136, 132096, 262272, 266240]
def n : List Nat := [5312, 13312, 20544, 65728, 90112, 135296, 159744, 196736, 263232, 271360, 344128, 409600, 466944]
def pp := p.map (canonical 488640)
def nn := n.map (canonical 488640)
def parts : List Nat := [0, 64, 4096, 8192, 16384, 65536, 131072, 262144, 8256, 69632, 131136, 266240]
def g : ShortGrid := [(0,[(64,5843230804773930342819600563767194291089178881), (4096,7324746927103037706970898382803319322917590074113), (8192,1), (8256,256), (16384,2923047876832778016247705476368179567442471813121), (65536,5846095753665556032495410952736359134884943626241), (69632,17179870208), (131072,8769143630498334048743116429104538702327415439361), (131136,25769869312), (262144,11692191507331112064990821905472718269769887252481), (266240,34359936256)]), (64,[(4096,21525233664), (8192,1099511627776), (16384,8590000128), (65536,17179934720), (69632,17179934720), (131072,25769869312), (262144,34359803904), (266240,34359803904)]), (4096,[(8192,197888), (8256,256), (16384,8590132480), (65536,1410690598307072), (131072,25770001664), (131136,65536), (262144,34359936256)]), (8192,[(16384,12901679104), (65536,17196646400), (69632,17196646400), (131072,30081548288), (131136,16777216), (262144,38671482880), (266240,38671482880)]), (8256,[(16384,256), (65536,256), (69632,256), (131072,256), (262144,256), (266240,256)]), (16384,[(65536,566248488305920), (69632,1024), (131072,568447511561728), (131136,65536), (262144,853221023156480), (266240,197888)]), (65536,[(131072,25820136704), (131136,65536), (262144,34410071296), (266240,21525169408)]), (69632,[(131072,1024), (131136,65536), (262144,1024)]), (131072,[(262144,34443625984), (266240,197888)]), (131136,[(262144,65536), (266240,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 487488 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 487488 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 487488 4096) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 487488 8192) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 487488 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 487488 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 487488 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 487488 262144) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 487488 8256) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 487488 69632) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 487488 131136) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 487488 266240) = true := by decide
theorem full : checkArms 488640 487488 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 4096, 8192, 16384, 65536, 131072, 262144, 8256, 69632, 131136, 266240] : List Nat).all (fun i => parts.all (shortPair g pp nn 487488 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short488640
theorem validBranch488640 : checkArms 488640 487488 [8256, 8320, 16512, 17408, 66560, 69632, 131136, 132096, 262272, 266240] [5312, 13312, 20544, 65728, 90112, 135296, 159744, 196736, 263232, 271360, 344128, 409600, 466944] = true := Short488640.full
end TightRow.Protected.Numeric
