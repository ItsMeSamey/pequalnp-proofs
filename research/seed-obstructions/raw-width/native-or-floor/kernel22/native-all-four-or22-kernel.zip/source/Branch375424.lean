import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short375424
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 33280, 34816, 66048, 69632, 262272, 264192, 266240]
def n : List Nat := [2688, 4736, 6656, 14336, 36992, 45056, 67712, 75776, 98432, 262656, 303104, 335872, 360448]
def pp := p.map (canonical 375424)
def nn := n.map (canonical 375424)
def parts : List Nat := [0, 128, 2048, 4096, 8192, 32768, 65536, 8320, 34816, 69632]
def g : ShortGrid := [(0,[(128,134590535453159392537450477816259960893342465), (2048,156891620939249471471166020938590023466550273), (4096,179192706425339471486204041243241081548899841), (8192,23085108022710186909029345539388151347281921), (8320,256), (32768,45386193508800186306306271877129992350597121), (34816,8589935104), (65536,89988364480980026642117207490658122957324289), (69632,17179870208)]), (128,[(2048,12952207360), (4096,21575696384), (8192,3298534883328), (32768,8590131200), (34816,8590131200), (65536,17180065792), (69632,17180065792)]), (2048,[(4096,21575762688), (8192,849922488270848), (8320,256), (32768,848831566578432), (65536,17180132096), (69632,17180132096)]), (4096,[(8192,1415071464947712), (8320,256), (32768,1416170976576256), (34816,512), (65536,1413989149967616)]), (8192,[(32768,12935233536), (34816,12935233536), (65536,21525168128), (69632,21525168128)]), (8320,[(32768,256), (34816,256), (65536,256), (69632,256)]), (32768,[(65536,21541946112), (69632,21541946112)]), (34816,[(65536,512), (69632,512)])]
private theorem row0 : parts.all (shortPair g pp nn 112768 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 112768 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 112768 2048) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 112768 4096) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 112768 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 112768 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 112768 65536) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 112768 8320) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 112768 34816) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 112768 69632) = true := by decide
theorem full : checkArms 375424 112768 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 2048, 4096, 8192, 32768, 65536, 8320, 34816, 69632] : List Nat).all (fun i => parts.all (shortPair g pp nn 112768 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short375424
theorem validBranch375424 : checkArms 375424 112768 [8320, 8704, 33280, 34816, 66048, 69632, 262272, 264192, 266240] [2688, 4736, 6656, 14336, 36992, 45056, 67712, 75776, 98432, 262656, 303104, 335872, 360448] = true := Short375424.full
end TightRow.Protected.Numeric
