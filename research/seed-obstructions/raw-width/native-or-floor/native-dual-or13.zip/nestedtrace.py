from functools import cache
from itertools import combinations_with_replacement
from pathlib import Path
from sample import samples

w,seed,target=samples(Path(__file__).with_name('L-meta-18968.json'))
edges=sorted({r&((1<<20)-1) for i,r in enumerate(w) if target>>i&1 and not seed>>i&1})
assert len(edges)==28 and all(e.bit_count()==2 for e in edges)
neg=sum(1<<i for i in range(len(w)) if not target>>i&1)
vertices=[1<<i for i in range(20)]
@cache
def col(x):
    return sum(1<<i for i,r in enumerate(w) if r&x)
@cache
def posrows(s):
    return sum(1<<i for i,r in enumerate(w) if target>>i&1 and not seed>>i&1 and (r&((1<<20)-1)) in s)
@cache
def covers(s):
    v={0}
    for e in s:
        v={k|a for k in v for a in vertices if e&a}
        v={k for k in v if not any(l!=k and l&k==l for l in v)}
    return tuple(sorted(v))
@cache
def tests(s):
    cs=covers(s)
    assert len(cs)<=4
    return tuple((a,b,col(a)&col(b)) for a,b in combinations_with_replacement(cs,2))
@cache
def term(s,extra,fixed=False):
    rr=posrows(s)
    keep=posrows(frozenset(edges))|neg
    for c in ([extra] if fixed else [c|extra for c in covers(s)]):
        for a,b,pair in tests(s):
            if pair&col(c)&keep==rr:
                return a,b,c
def joint(s,t):
    for q in covers(t):
        d=term(t,q,True)
        if d:
            h=term(s,q)
            if h:
                return h,d
    return None
if __name__=='__main__':
    pools={e:frozenset(r for r in edges if r&e) for e in edges}
    good=bad=0
    for s in pools.values():
        for t in pools.values():
            if joint(s,t):good+=1
            else:bad+=1
    assert good+bad==784
    print('all full adjacent-center unions, ordered pairs',good,bad)
