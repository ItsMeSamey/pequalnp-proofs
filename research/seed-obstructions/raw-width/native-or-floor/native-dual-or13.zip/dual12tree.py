from nestedtrace import *
from functools import lru_cache
def stage(slots):
 pos=sorted({r for i,r in enumerate(w) if (target&~seed)>>i&1})
 ns=sorted({r for i,r in enumerate(w) if neg>>i&1})
 allp=(1<<len(pos))-1
 bank=[(sum(1<<i for i,r in enumerate(pos) if r>>s&1),sum(1<<i for i,r in enumerate(ns) if r>>s&1)) for s in slots]
 def make(ms):
  opts=[[m for m in ms if m>>i&1] for i in range(len(pos))]
  @lru_cache(None)
  def tau(t):
   if not t:return 0
   op=min((x for i,x in enumerate(opts) if t>>i&1),key=len)
   return 1+min((tau(t&~m) for m in op),default=100)
  return tau
 roots=[make([p for p,n in bank if not n>>i&1]) for i in range(len(ns))]
 def candidates(b,ix,depth):
  extra=b[len(bank):]
  def price(i,t):
   v=roots[i](t);ls=[p for p,n in extra if not n>>i&1]
   if len(ls)==1:return min(v,1+roots[i](t&~ls[0]))
   c=[(0,0)]
   for p in ls:c+= [(a+1,m|p) for a,m in c]
   return min(a+roots[i](t&~m) for a,m in c)
  budget=12-depth
  vals={i:price(i,allp) for i in ix}
  if max(vals.values())>budget+1:return set(),[]
  ids=[i for i,f in vals.items() if f==budget+1]
  closed={allp}
  for p,n in b:closed.update([q&p for q in closed])
  ops=[]
  for s in sorted(closed-{0,allp}):
   nn=(1<<len(ns))-1
   for p,n in b:
    if s&~p==0:nn &=n
   ops.append((s,nn))
  live=set()
  for j,(p,n) in enumerate(ops):
   for q,m in ops[:j]:
    if p&q in (p,q):continue
    a=p|q;bneg=n|m
    if all(not (bneg>>i&1) and price(i,allp&~a)<=budget-1 for i in ids):live.add((a,bneg))
  return live,ids
 frontier={()}; ix=range(len(ns))
 for depth in range(6):
  nxt=set()
  for state in frontier:
   live,ids=candidates(bank+list(state),ix,depth)
   nxt.update(tuple(sorted((*state,x))) for x in live if x not in state)
  print(slots[20:],depth+1,len(nxt),flush=True)
  frontier=nxt
  if not frontier:break
if __name__=='__main__':
 for c in [[29,30]]:stage(list(range(20))+c)
