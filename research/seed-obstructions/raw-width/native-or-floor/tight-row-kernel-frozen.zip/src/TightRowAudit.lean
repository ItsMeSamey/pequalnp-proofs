import TightRowExample
import TightRowIndexed

#print axioms TightRow.Trace.upper
#print axioms TightRow.tightExact
#print axioms TightRow.physical_iff_net
#print axioms TightRow.chart_iff_clean_at_price
#print axioms TightRow.indexed_chart_iff_clean
#print axioms TightRow.Example.two_clean_terms
