import TightRowPhysical

namespace TightRow
universe u v
variable {R : Type v}

/-- A gate-level DAG with typed back-references. Immediately after allocation,
none refers to the newest gate and some w refers to the former wire w. -/
inductive Tape : Type u → Nat → Type (u+1) where
  | output {S} : S → Tape S 0
  | andGate {S k} : S → S → Tape (Option S) k → Tape S k
  | orGate {S k} : S → S → Tape (Option S) k → Tape S (k+1)

def extend {S : Type u} (v : S → Set R) (s : Set R) : Option S → Set R
  | none => s
  | some w => v w

def Tape.eval {S : Type u} {k} : Tape S k → (S → Set R) → Set R
  | .output w, v => v w
  | .andGate a b tail, v => tail.eval (extend v (v a ∩ v b))
  | .orGate a b tail, v => tail.eval (extend v (v a ∪ v b))

theorem Tape.toPhysical {S : Type u} {k} (t : Tape S k) (v : S → Set R)
    {A : Bank R} (src : ∀ w, v w ∈ A) : Physical A (t.eval v) k := by
  induction t generalizing A with
  | output w => exact .output (src w)
  | andGate a b tail ih =>
    apply Physical.andGate (src a) (src b)
    apply ih
    intro w
    cases w with
    | none => exact Set.mem_insert _ _
    | some w => exact Or.inr (src w)
  | orGate a b tail ih =>
    apply Physical.orGate (src a) (src b)
    apply ih
    intro w
    cases w with
    | none => exact Set.mem_insert _ _
    | some w => exact Or.inr (src w)

private theorem extendSupplies {S : Type u} {v : S → Set R} {A : Bank R}
    (supplies : ∀ s ∈ A, ∃ i, v i = s) (z : Set R) :
    ∀ s ∈ insert z A, ∃ i, extend v z i = s := by
  intro s hs
  rcases Set.mem_insert_iff.mp hs with rfl | hs
  · exact ⟨none,rfl⟩
  obtain ⟨i,hi⟩ := supplies s hs
  exact ⟨some i,hi⟩

theorem Physical.toTape {A : Bank R} {q k} (p : Physical A q k)
    {S : Type u} (v : S → Set R) (supplies : ∀ s ∈ A, ∃ i, v i = s) :
    ∃ t : Tape S k, t.eval v = q := by
  induction p generalizing S with
  | output h =>
    obtain ⟨w,hw⟩ := supplies _ h
    exact ⟨.output w,hw⟩
  | @andGate A a b q k ha hb tail ih =>
    obtain ⟨i,rfl⟩ := supplies _ ha
    obtain ⟨j,rfl⟩ := supplies _ hb
    obtain ⟨t,ht⟩ := ih _ (extendSupplies supplies (v i ∩ v j))
    exact ⟨.andGate i j t,ht⟩
  | @orGate A a b q k ha hb tail ih =>
    obtain ⟨i,rfl⟩ := supplies _ ha
    obtain ⟨j,rfl⟩ := supplies _ hb
    obtain ⟨t,ht⟩ := ih _ (extendSupplies supplies (v i ∪ v j))
    exact ⟨.orGate i j t,ht⟩

theorem indexed_chart_iff_clean {S : Type u} (v : S → Set R)
    {P N : Set R} {b : Nat} {n : R} (pos : P.Nonempty) (neg : n ∈ N)
    (price : Price (Set.range v) P n (b+1)) :
    (∃ k ≤ b, ∃ t : Tape S k, P ⊆ t.eval v ∧ ∀ x ∈ N, x ∉ t.eval v) ↔
    ∃ D : Finset (Set R), D.card ≤ b+1 ∧ P ⊆ rows D ∧
      ∀ s ∈ D, Product (Set.range v) s ∧ ∀ x ∈ N, x ∉ s := by
  rw [← chart_iff_clean_at_price pos neg price]
  constructor
  · rintro ⟨k,hk,t,acc,cl⟩
    exact ⟨_,k,hk,t.toPhysical v (fun w => ⟨w,rfl⟩),acc,cl⟩
  · rintro ⟨q,k,hk,p,acc,cl⟩
    obtain ⟨t,ht⟩ := p.toTape v (fun _ h => h)
    exact ⟨k,hk,t,ht ▸ acc,ht ▸ cl⟩

end TightRow
