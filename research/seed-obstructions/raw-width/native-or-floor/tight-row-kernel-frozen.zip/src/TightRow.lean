import TightRowBasics

namespace TightRow
variable {R : Type*}
attribute [local instance] Classical.propDecidable

private def Guard (A : Bank R) (g : Set R) := g = Set.univ ∨ Product A g

private theorem guardMeet {A : Bank R} {g h : Set R} (pg : Guard A g) (ph : Guard A h) :
    Guard A (g ∩ h) := by
  rcases pg with rfl | pg
  · simpa using ph
  rcases ph with rfl | ph
  · simpa [Guard] using (Or.inr pg : Guard A g)
  exact Or.inr (.meet pg ph)

private theorem productGuard {A : Bank R} {q g : Set R} (pq : Product A q)
    (pg : Guard A g) : Product A (q ∩ g) := by
  rcases pg with rfl | pg
  · simpa using pq
  exact .meet pq pg

/-- Repeated occurrences of the single new wire collapse by idempotence. -/
private theorem splitProduct {A : Bank R} {y s : Set R} (p : Product (insert y A) s) :
    Product A s ∨ ∃ g, Guard A g ∧ s = y ∩ g := by
  induction p with
  | atom hm =>
    rcases Set.mem_insert_iff.mp hm with rfl | hm
    · exact Or.inr ⟨Set.univ,Or.inl rfl,by simp⟩
    · exact Or.inl (.atom hm)
  | @meet s t ps pt ih jh =>
    rcases ih with hs | ⟨g,pg,rfl⟩ <;> rcases jh with ht | ⟨h,ph,rfl⟩
    · exact Or.inl (.meet hs ht)
    · exact Or.inr ⟨s ∩ h,guardMeet (Or.inr hs) ph,by ext x; exact and_left_comm⟩
    · exact Or.inr ⟨g ∩ t,guardMeet pg (Or.inr ht),by ext x; exact and_assoc⟩
    · refine Or.inr ⟨g ∩ h,guardMeet pg ph,?_⟩
      ext x
      change ((_ ∧ _) ∧ (_ ∧ _)) ↔ _ ∧ _ ∧ _
      constructor
      · rintro ⟨⟨hy,hg⟩,_,hh⟩
        exact ⟨hy,hg,hh⟩
      · rintro ⟨hy,hg,hh⟩
        exact ⟨⟨hy,hg⟩,hy,hh⟩

private theorem oldOrSplit {A : Bank R} {l r s : Set R}
    (pl : Product A l) (pr : Product A r) (p : Product (insert (l ∪ r) A) s)
    (bad : ¬Product A s) :
    s ⊆ l ∪ r ∧ ∃ a b, Product A a ∧ Product A b ∧ s = a ∪ b := by
  obtain ⟨g,pg,rfl⟩ := (splitProduct p).resolve_left bad
  refine ⟨fun _ h => h.1, l ∩ g,r ∩ g,productGuard pl pg,productGuard pr pg,?_⟩
  ext x
  change ((_ ∨ _) ∧ _) ↔ (_ ∧ _) ∨ (_ ∧ _)
  constructor
  · rintro ⟨h | h,hg⟩
    · exact Or.inl ⟨h,hg⟩
    · exact Or.inr ⟨h,hg⟩
  · rintro (⟨h,hg⟩ | ⟨h,hg⟩)
    · exact ⟨Or.inl h,hg⟩
    · exact ⟨Or.inr h,hg⟩

/-- Choose one covering old wire for each term, allowing several choices to coincide. -/
private theorem factorsCover (A : Bank R) (n : R) (E : Finset (Set R))
    (choices : ∀ t ∈ E, ∃ a ∈ A, n ∉ a ∧ t ⊆ a) :
    ∃ C, Cover A (rows E) n C ∧ C.card ≤ E.card := by
  classical
  induction E using Finset.induction_on with
  | empty => exact ⟨∅,⟨by simp,fun _ h => h⟩,by simp⟩
  | @insert s E fresh ih =>
    obtain ⟨a,ha,hna,hsa⟩ := choices s (by simp)
    obtain ⟨C,hC,hs⟩ := ih (fun t ht => choices t (Finset.mem_insert_of_mem ht))
    refine ⟨insert a C,⟨?_,?_⟩,?_⟩
    · intro t ht
      rcases Finset.mem_insert.mp ht with rfl | hm
      · exact ⟨ha,hna⟩
      · exact hC.1 _ hm
    · rw [rows_insert,rows_insert]
      intro x hx
      exact hx.elim (fun h => Or.inl (hsa h)) (fun h => Or.inr (hC.2 h))
    · rw [Finset.card_insert_of_notMem fresh]
      exact (Finset.card_insert_le _ _).trans (by omega)

/-- Two distinct exceptional products sharing y save one enriched-bank cover wire. -/
private theorem sharedCover {A : Bank R} {y : Set R} {n : R} (hy : n ∉ y)
    {D : Finset (Set R)} (prod : ∀ s ∈ D, Product A s) (low : n ∉ rows D)
    (mem : y ∈ A) {s t : Set R} (hs : s ∈ D) (ht : t ∈ D) (hne : t ≠ s)
    (sy : s ⊆ y) (ty : t ⊆ y) : ∃ C, Cover A (rows D) n C ∧ C.card < D.card := by
  classical
  let E := (D.erase s).erase t
  have hE : ∀ q ∈ E, q ∈ D := fun _ h => Finset.mem_of_mem_erase (Finset.mem_of_mem_erase h)
  obtain ⟨B,hB,size⟩ := factorsCover A n E (fun q hq =>
    (prod q (hE q hq)).low (fun hn => low ⟨q,hE q hq,hn⟩))
  refine ⟨insert y B,⟨?_,?_⟩,?_⟩
  · intro q hq
    rcases Finset.mem_insert.mp hq with rfl | hq
    · exact ⟨mem,hy⟩
    · exact hB.1 _ hq
  · rw [rows_insert]
    rintro x ⟨q,hq,hx⟩
    by_cases qs : q = s
    · exact Or.inl (sy (qs ▸ hx))
    by_cases qt : q = t
    · exact Or.inl (ty (qt ▸ hx))
    exact Or.inr (hB.2 ⟨q,Finset.mem_erase.mpr ⟨qt, Finset.mem_erase.mpr ⟨qs,hq⟩⟩,hx⟩)
  · have ht' := Finset.mem_erase.mpr ⟨hne,ht⟩
    have h₁ := Finset.card_erase_of_mem hs
    have h₂ : E.card = (D.erase s).card - 1 := Finset.card_erase_of_mem ht'
    have h₃ := Finset.card_pos.mpr (show (D.erase s).Nonempty from ⟨_,ht'⟩)
    have h₄ := Finset.card_insert_le y B
    omega

/-- Exact denotation on every row. P can be any subset of the accepted rows. -/
theorem tightExact {A : Bank R} {q : Set R} {k : Nat} (net : Net A q k)
    {P : Set R} {n : R} (accept : P ⊆ q) (reject : n ∉ q) (tight : Lower A P n (k+1)) :
    ∃ D : Finset (Set R), (∀ s ∈ D, Product A s) ∧ rows D = q ∧ D.card ≤ k+1 := by
  classical
  induction net with
  | stop pq => exact ⟨{_},by simpa using pq,rows_singleton _,by simp⟩
  | @step A l r q k pl pr tail ih =>
    let B := insert (l ∪ r) A
    have oldBound (C : Finset (Set R)) (cov : Cover B P n C) :
        k+2 ≤ C.card + (if n ∈ l ∪ r then 0 else 1) := by
      obtain ⟨T,hT,sz⟩ := liftCover pl pr cov
      exact (tight T hT).trans sz
    obtain ⟨C,hC,size⟩ := tail.upper reject
    have bound := oldBound C ⟨hC.1,accept.trans hC.2⟩
    have low : n ∉ l ∪ r := by
      intro hn
      rw [if_pos hn] at bound
      omega
    have enriched : Lower B P n (k+1) := by
      intro T hT
      have bd := oldBound T hT
      rw [if_neg low] at bd
      omega
    obtain ⟨D,prod,eqn,sz⟩ := ih accept reject enriched
    by_cases ok : ∀ s ∈ D, Product A s
    · exact ⟨D,ok,eqn,by omega⟩
    obtain ⟨s,fail⟩ := Classical.not_forall.mp ok
    by_cases hs : s ∈ D
    case neg => exact (fail (fun h => (hs h).elim)).elim
    have bad : ¬ Product A s := fun ps => fail (fun _ => ps)
    obtain ⟨sy,a,b,pa,pb,split⟩ := oldOrSplit pl pr (prod s hs) bad
    have rest : ∀ t ∈ D.erase s, Product A t := by
      intro t ht
      obtain ⟨hne,ht⟩ := Finset.mem_erase.mp ht
      by_contra bt
      have ty := (oldOrSplit pl pr (prod t ht) bt).1
      have hnD : n ∉ rows D := by rwa [eqn]
      obtain ⟨T,hT,lt⟩ := sharedCover low prod hnD (Set.mem_insert _ _) hs ht hne sy ty
      have small := enriched T ⟨hT.1,accept.trans (by simpa only [eqn] using hT.2)⟩
      omega
    refine ⟨insert a (insert b (D.erase s)),?_,?_,?_⟩
    · intro t ht
      rcases Finset.mem_insert.mp ht with rfl | ht
      · exact pa
      rcases Finset.mem_insert.mp ht with rfl | ht
      · exact pb
      · exact rest _ ht
    · rw [rows_insert,rows_insert,← Set.union_assoc,← split,← rows_insert,
        Finset.insert_erase hs,eqn]
    · have h₁ := Finset.card_insert_le a (insert b (D.erase s))
      have h₂ := Finset.card_insert_le b (D.erase s)
      have h₃ := Finset.card_erase_of_mem hs
      have h₄ := Finset.card_pos.mpr (show D.Nonempty from ⟨_,hs⟩)
      omega

end TightRow
