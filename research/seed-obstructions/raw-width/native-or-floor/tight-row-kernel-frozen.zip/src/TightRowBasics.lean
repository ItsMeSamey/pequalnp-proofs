import Mathlib.Data.Finset.Card
import Mathlib.Data.Set.Basic

namespace TightRow
variable {R : Type*}
attribute [local instance] Classical.propDecidable
abbrev Bank (R : Type*) := Set (Set R)

/-- The signatures obtainable by nonempty conjunctions of old physical wires. -/
inductive Product (A : Bank R) : Set R → Prop where
  | atom {q} : q ∈ A → Product A q
  | meet {s t} : Product A s → Product A t → Product A (s ∩ t)

theorem Product.map {A B : Bank R} (f : ∀ q ∈ A, Product B q)
    {q} (p : Product A q) : Product B q := by
  induction p with
  | atom h => exact f _ h
  | meet _ _ ih jh => exact .meet ih jh

theorem Product.low {A : Bank R} {q : Set R} (p : Product A q) {n : R}
    (lo : n ∉ q) : ∃ s ∈ A, n ∉ s ∧ q ⊆ s := by
  induction p with
  | atom h => exact ⟨_, h, lo, fun _ h => h⟩
  | @meet s t ps pt ih jh =>
    by_cases hn : n ∈ s
    · obtain ⟨a, ha, hna, hta⟩ := jh (fun ht => lo ⟨hn,ht⟩)
      exact ⟨a,ha,hna,fun _ h => hta h.2⟩
    · obtain ⟨a, ha, hna, hsa⟩ := ih hn
      exact ⟨a,ha,hna,fun _ h => hsa h.1⟩

/-- Topological OR tape. Each step appends a single physical output to the bank.
A later product may use any number of previously computed outputs. -/
inductive Net : Bank R → Set R → Nat → Prop where
  | stop {A q} : Product A q → Net A q 0
  | step {A l r q k} : Product A l → Product A r →
      Net (insert (l ∪ r) A) q k → Net A q (k+1)

def rows (D : Finset (Set R)) : Set R := {x | ∃ q ∈ D, x ∈ q}

/-- Cover by old wires low on row n. A set removes duplicate wire signatures. -/
def Cover (A : Bank R) (P : Set R) (n : R) (C : Finset (Set R)) : Prop :=
  (∀ t ∈ C, t ∈ A ∧ n ∉ t) ∧ P ⊆ rows C

def Lower (A : Bank R) (P : Set R) (n : R) (k : Nat) : Prop :=
  ∀ C, Cover A P n C → k ≤ C.card

theorem rows_insert (q : Set R) (D : Finset (Set R)) [DecidableEq (Set R)] :
    rows (insert q D) = q ∪ rows D := by
  ext x
  simp only [rows, Set.mem_setOf_eq, Finset.mem_insert, Set.mem_union]
  constructor
  · rintro ⟨s, hs | hs, hx⟩
    · exact Or.inl (hs ▸ hx)
    · exact Or.inr ⟨s,hs,hx⟩
  · rintro (hx | ⟨s,hs,hx⟩)
    · exact ⟨q,Or.inl rfl,hx⟩
    · exact ⟨s,Or.inr hs,hx⟩

theorem rows_singleton (q : Set R) : rows {q} = q := by
  ext x
  simp [rows]

theorem liftCover {A : Bank R} {P l r : Set R} {n : R}
    (pl : Product A l) (pr : Product A r) {C : Finset (Set R)}
    (cov : Cover (insert (l ∪ r) A) P n C) :
    ∃ T, Cover A P n T ∧ T.card ≤ C.card + (if n ∈ l ∪ r then 0 else 1) := by
  classical
  by_cases hy : l ∪ r ∈ C
  · have hlow := (cov.1 _ hy).2
    obtain ⟨a,ha,hna,hla⟩ := pl.low (fun h => hlow (Or.inl h))
    obtain ⟨b,hb,hnb,hrb⟩ := pr.low (fun h => hlow (Or.inr h))
    let E := C.erase (l ∪ r)
    refine ⟨insert a (insert b E), ⟨?_,?_⟩, ?_⟩
    · intro s hs
      rcases Finset.mem_insert.mp hs with h | hs
      · subst s
        exact ⟨ha,hna⟩
      rcases Finset.mem_insert.mp hs with h | hs
      · subst s
        exact ⟨hb,hnb⟩
      obtain ⟨hne,hm⟩ := Finset.mem_erase.mp hs
      exact ⟨(Set.mem_insert_iff.mp (cov.1 _ hm).1).resolve_left hne,
        (cov.1 _ hm).2⟩
    · intro x hx
      obtain ⟨s,hs,hxs⟩ := cov.2 hx
      by_cases he : s = l ∪ r
      · subst s
        rcases hxs with h | h
        · exact ⟨a,by simp,hla h⟩
        · exact ⟨b,by simp,hrb h⟩
      · exact ⟨s,Finset.mem_insert_of_mem (Finset.mem_insert_of_mem
          (Finset.mem_erase.mpr ⟨he,hs⟩)),hxs⟩
    · rw [if_neg hlow]
      have h₁ := Finset.card_insert_le a (insert b E)
      have h₂ := Finset.card_insert_le b E
      have h₃ : E.card = C.card - 1 := Finset.card_erase_of_mem hy
      have h₄ := Finset.card_pos.mpr (show C.Nonempty from ⟨_,hy⟩)
      omega
  · refine ⟨C, ⟨?_,cov.2⟩, Nat.le_add_right _ _⟩
    intro s hs
    have he : s ≠ l ∪ r := fun e => hy (e ▸ hs)
    exact ⟨(Set.mem_insert_iff.mp (cov.1 _ hs).1).resolve_left he,(cov.1 _ hs).2⟩

/-- Number of paid gates low on the selected row. The trace also certifies the
physical gate count; adding a gate high on n does not increase the row cost. -/
inductive Trace (n : R) : Bank R → Set R → Nat → Nat → Prop where
  | stop {A q} : Product A q → Trace n A q 0 0
  | step {A l r q k d} (pl : Product A l) (pr : Product A r)
      (tail : Trace n (insert (l ∪ r) A) q k d)
      [Decidable (n ∈ l ∪ r)] :
      Trace n A q (k+1) (d + (if n ∈ l ∪ r then 0 else 1))

theorem Net.trace {A : Bank R} {q k} (net : Net A q k) (n : R) :
    ∃ d ≤ k, Trace n A q k d := by
  classical
  induction net with
  | stop p => exact ⟨0,by omega,.stop p⟩
  | @step A l r q k pl pr tail ih =>
    obtain ⟨d,hd,tr⟩ := ih
    refine ⟨_,?_,.step pl pr tr⟩
    split <;> omega

theorem Trace.upper {A : Bank R} {q k d n} (tr : Trace n A q k d)
    (hn : n ∉ q) : ∃ C, Cover A q n C ∧ C.card ≤ d+1 := by
  classical
  induction tr with
  | stop p =>
    obtain ⟨a,ha,hna,hqa⟩ := p.low hn
    exact ⟨{a},⟨by simpa using And.intro ha hna,by rwa [rows_singleton]⟩,by simp⟩
  | @step A l r q k d pl pr tail dec ih =>
    obtain ⟨C,hC,sz⟩ := ih hn
    obtain ⟨T,hT,sz'⟩ := liftCover pl pr hC
    refine ⟨T,hT,?_⟩
    by_cases h : n ∈ l ∪ r <;> simp [h] at sz' ⊢ <;> omega

theorem Net.upper {A : Bank R} {q k n} (net : Net A q k) (hn : n ∉ q) :
    ∃ C, Cover A q n C ∧ C.card ≤ k+1 := by
  obtain ⟨d,hd,tr⟩ := net.trace n
  obtain ⟨C,hC,hs⟩ := tr.upper hn
  exact ⟨C,hC,by omega⟩

end TightRow
