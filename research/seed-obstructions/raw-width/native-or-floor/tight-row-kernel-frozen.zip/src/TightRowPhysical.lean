import TightRow

namespace TightRow
variable {R : Type*}

/-- A literal topological circuit construction on signal signatures. Each gate
chooses two available earlier signals (possibly the same) and adds its output.
All former inputs and gates stay available for fanout. -/
inductive Physical : Bank R → Set R → Nat → Prop where
  | output {A q} : q ∈ A → Physical A q 0
  | andGate {A a b q k} : a ∈ A → b ∈ A →
      Physical (insert (a ∩ b) A) q k → Physical A q k
  | orGate {A a b q k} : a ∈ A → b ∈ A →
      Physical (insert (a ∪ b) A) q k → Physical A q (k+1)

private theorem oldSub (A : Bank R) (s : Set R) : A ⊆ insert s A :=
  fun _ h => Or.inr h

private theorem Product.weaken {A B : Bank R} {q} (pq : Product A q) (h : A ⊆ B) :
    Product B q := pq.map (fun _ hm => .atom (h hm))

theorem Physical.flatten {A : Bank R} {q k} (p : Physical A q k)
    {B : Bank R} (available : ∀ s ∈ A, Product B s) : Net B q k := by
  induction p generalizing B with
  | output h => exact .stop (available _ h)
  | @andGate A a b q k ha hb tail ih =>
    apply ih
    intro s hs
    rcases Set.mem_insert_iff.mp hs with rfl | hs
    · exact .meet (available _ ha) (available _ hb)
    · exact available _ hs
  | @orGate A a b q k ha hb tail ih =>
    apply Net.step (available _ ha) (available _ hb)
    apply ih
    intro s hs
    rcases Set.mem_insert_iff.mp hs with rfl | hs
    · exact .atom (Set.mem_insert _ _)
    · exact (available _ hs).weaken (oldSub _ _)

/-- Allocate all ANDs in a nonempty old product, then continue with unrestricted
access to every former wire. -/
private theorem Product.allocate {A : Bank R} {s} (ps : Product A s)
    {B : Bank R} {q k} (haveA : A ⊆ B)
    (cont : ∀ E : Bank R, B ⊆ E → s ∈ E → Physical E q k) : Physical B q k := by
  induction ps generalizing B with
  | atom h => exact cont B (fun _ hm => hm) (haveA h)
  | @meet a b pa pb ia ib =>
    apply ia haveA
    intro C hc ha
    apply ib (haveA.trans hc)
    intro E he hb
    apply Physical.andGate (he ha) hb
    exact cont _ ((hc.trans he).trans (oldSub _ _)) (Set.mem_insert _ _)

private theorem Net.expandFrom {A : Bank R} {q k} (net : Net A q k)
    {B : Bank R} (incl : A ⊆ B) : Physical B q k := by
  induction net generalizing B with
  | stop p =>
    apply p.allocate incl
    exact fun _ _ h => .output h
  | @step A l r q k pl pr tail ih =>
    apply pl.allocate incl
    intro C hc hl
    apply pr.allocate (incl.trans hc)
    intro E he hr
    apply Physical.orGate (he hl) hr
    apply ih
    intro s hs
    rcases Set.mem_insert_iff.mp hs with rfl | hs
    · exact Set.mem_insert _ _
    · exact Or.inr (he (hc (incl hs)))

theorem physical_iff_net {A : Bank R} {q k} : Physical A q k ↔ Net A q k :=
  ⟨fun h => h.flatten (fun _ hs => .atom hs),fun h => h.expandFrom (fun _ hs => hs)⟩

private theorem compileTerms (D : Finset (Set R)) {A : Bank R} {a : Set R}
    (seed : Product A a) (terms : ∀ t ∈ D, Product A t) : Net A (a ∪ rows D) D.card := by
  classical
  induction D using Finset.induction_on generalizing A a with
  | empty =>
    have er : rows (∅ : Finset (Set R)) = ∅ := by ext x; simp [rows]
    simpa [er] using Net.stop seed
  | @insert t D fresh ih =>
    rw [rows_insert,← Set.union_assoc,Finset.card_insert_of_notMem fresh]
    apply Net.step seed (terms t (by simp))
    apply ih (.atom (Set.mem_insert _ _))
    intro s hs
    exact (terms s (Finset.mem_insert_of_mem hs)).weaken (oldSub _ _)

theorem compileNonempty {A : Bank R} {D : Finset (Set R)}
    (nonempty : D.Nonempty) (terms : ∀ t ∈ D, Product A t) :
    Physical A (rows D) (D.card-1) := by
  classical
  obtain ⟨a,ha⟩ := nonempty
  have net := compileTerms (D.erase a) (terms a ha)
    (fun t ht => terms t (Finset.mem_of_mem_erase ht))
  rw [← rows_insert,Finset.insert_erase ha, Finset.card_erase_of_mem ha] at net
  exact physical_iff_net.mpr net

/-- An old-wire cover at the tight row needs at least b+1 signals. A physical
completion using at most b ORs exists exactly when at most b+1 individually
clean old conjunctions cover the positive obligations. -/
theorem chart_iff_clean {A : Bank R} {P N : Set R} {b : Nat} {n : R}
    (pos : P.Nonempty) (neg : n ∈ N) (tight : Lower A P n (b+1)) :
    (∃ q k, k ≤ b ∧ Physical A q k ∧ P ⊆ q ∧ ∀ x ∈ N, x ∉ q) ↔
    ∃ D : Finset (Set R), D.card ≤ b+1 ∧ P ⊆ rows D ∧
      ∀ t ∈ D, Product A t ∧ ∀ x ∈ N, x ∉ t := by
  constructor
  · rintro ⟨q,k,hk,physical,accept,clean⟩
    have net := physical_iff_net.mp physical
    have lower : Lower A P n (k+1) := fun C h => (Nat.succ_le_succ hk).trans (tight C h)
    obtain ⟨D,terms,total,size⟩ := tightExact net accept (clean n neg) lower
    refine ⟨D,by omega,by rwa [total],?_⟩
    intro t ht
    refine ⟨terms t ht,?_⟩
    intro x hx hxt
    apply clean x hx
    rw [← total]
    exact ⟨t,ht,hxt⟩
  · rintro ⟨D,size,accept,clean⟩
    obtain ⟨x,hx⟩ := pos
    obtain ⟨t,ht,_⟩ := accept hx
    refine ⟨rows D,D.card-1,by omega,compileNonempty ⟨t,ht⟩
      (fun s hs => (clean s hs).1),accept,?_⟩
    rintro y hy ⟨s,hs,hys⟩
    exact (clean s hs).2 y hy hys

/-- The tight-row hypothesis in its usual minimum form. -/
def Price (A : Bank R) (P : Set R) (n : R) (d : Nat) : Prop :=
  Lower A P n d ∧ ∃ C, Cover A P n C ∧ C.card = d

theorem chart_iff_clean_at_price {A : Bank R} {P N : Set R} {b : Nat} {n : R}
    (pos : P.Nonempty) (neg : n ∈ N) (price : Price A P n (b+1)) :
    (∃ q k, k ≤ b ∧ Physical A q k ∧ P ⊆ q ∧ ∀ x ∈ N, x ∉ q) ↔
    ∃ D : Finset (Set R), D.card ≤ b+1 ∧ P ⊆ rows D ∧
      ∀ t ∈ D, Product A t ∧ ∀ x ∈ N, x ∉ t :=
  chart_iff_clean pos neg price.1

end TightRow
