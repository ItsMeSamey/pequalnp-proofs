import TightRowPhysical

namespace TightRow.Example

inductive Row where
  | left | right | tight | other
  deriving DecidableEq

open Row

def a : Set Row := {left,other}
def b : Set Row := {right,other}
def guard : Set Row := {left,right,tight}
def bank : TightRow.Bank Row := {a,b,guard}
def pos : Set Row := {left,right}
def neg : Set Row := {tight,other}

theorem exact_price : Price bank pos tight 2 := by
  classical
  have ne : a ≠ b := by
    intro h
    have mem : left ∈ a := by simp [a]
    rw [h] at mem
    simpa [b] using mem
  constructor
  · intro C cov
    have ha : a ∈ C := by
      obtain ⟨s,hs,hleft⟩ := cov.2 (show left ∈ pos by simp [pos])
      obtain ⟨ok,low⟩ := cov.1 s hs
      rcases (show s = a ∨ s = b ∨ s = guard by simpa [bank] using ok) with rfl | rfl | rfl
      · exact hs
      · simp [b] at hleft
      · exact (low (by simp [guard])).elim
    have hb : b ∈ C := by
      obtain ⟨s,hs,hright⟩ := cov.2 (show right ∈ pos by simp [pos])
      obtain ⟨ok,low⟩ := cov.1 s hs
      rcases (show s = a ∨ s = b ∨ s = guard by simpa [bank] using ok) with rfl | rfl | rfl
      · simp [a] at hright
      · exact hs
      · exact (low (by simp [guard])).elim
    have incl : ({a,b} : Finset (Set Row)) ⊆ C := by
      intro s hs
      rcases (show s = a ∨ s = b by simpa using hs) with rfl | rfl
      · exact ha
      · exact hb
    simpa [ne] using Finset.card_le_card incl
  · refine ⟨{a,b},⟨?_,?_⟩,by simp [ne]⟩
    · intro s hs
      rcases (show s = a ∨ s = b by simpa using hs) with rfl | rfl
      · simp [bank,a]
      · simp [bank,b]
    · intro x hx
      rcases (show x = left ∨ x = right by simpa [pos] using hx) with rfl | rfl
      · exact ⟨a,by simp,by simp [a]⟩
      · exact ⟨b,by simp,by simp [b]⟩

theorem completion : Physical bank ((a ∪ b) ∩ guard) 1 := by
  apply Physical.orGate (show a ∈ bank by simp [bank]) (show b ∈ bank by simp [bank])
  apply Physical.andGate (Set.mem_insert _ _) (Or.inr (show guard ∈ bank by simp [bank]))
  exact .output (Set.mem_insert _ _)

theorem two_clean_terms :
    ∃ D : Finset (Set Row), D.card ≤ 2 ∧ pos ⊆ rows D ∧
      ∀ t ∈ D, Product bank t ∧ ∀ x ∈ neg, x ∉ t := by
  apply (chart_iff_clean_at_price (b := 1) (n := tight)
    (show pos.Nonempty from ⟨left,by simp [pos]⟩) (show tight ∈ neg by simp [neg])
    exact_price).mp
  refine ⟨_,1,by decide,completion,?_,?_⟩
  · intro x hx
    cases x <;> simp_all [pos,a,b,guard]
  · intro x hx
    cases x <;> simp_all [neg,a,b,guard]

end TightRow.Example
