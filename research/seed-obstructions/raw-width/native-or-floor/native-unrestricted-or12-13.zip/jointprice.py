from sample import samples
from pathlib import Path
from itertools import combinations,product
from functools import cache
from operator import or_
from functools import reduce
rows,front,target=samples(Path('L-meta-18968.json'))
neg={(r&8191,r>>13&127)for i,r in enumerate(rows) if not target>>i&1}
hood=[reduce(or_,(r&8191 for i,r in enumerate(rows) if target>>i&1 and not front>>i&1 and (r>>13)&(1<<j)),0)for j in range(7)]
def bits(m):
 return [1<<k for k in range(m.bit_length())if m>>k&1]
@cache
def rank(groups,bank):
 opts=[{tuple(sorted(set(x)))for x in product(*[[p]+[b for b in bank if b&p]for p in bits(g)])}for g in groups if g]
 best=100
 for selected in product(*opts):
  cc=[]
  for group in selected:
   z=set(group);rem=[]
   for x in cc:
    if x&z:z|=x
    else:rem.append(x)
   cc=rem+[z]
  best=min(best,sum(len(x)-1 for x in cc))
 return best
def cheapest(p,t,bank):
 c=99
 for m in range(128):
  if t&m:continue
  rest=reduce(or_,(hood[j]for j in range(7)if not m>>j&1),0)
  if rest&p:continue
  for h in range(1<<len(bank)):
   b=reduce(or_,(v for i,v in enumerate(bank)if h>>i&1),0)
   if not b&p:c=min(c,m.bit_count()+h.bit_count()+(rest&~b).bit_count())
 return c
for bank in ((),(129,),(4160,),(129,4160)):
 cost={(p,t):cheapest(p,t,bank)-1 for p,t in neg}
 for c in range(1,4):
  vals=[]
  for C in combinations((0,4,6),c):
   for h in (1,2,3,5):
    groups=[hood[s]&~(hood[h] if s in C else 0)for s in (0,4,6)]
    tag=sum(1<<s for s in (*C,h));bb=[]
    for (p,t),low in cost.items():
     high=rank(tuple(sorted(p&x for x in groups)),bank)+max(0,(tag&t).bit_count()-1)
     bb.append(8+low+high)
    vals.append(max(bb))
  print(bank,c,min(vals),max(vals),flush=True)
