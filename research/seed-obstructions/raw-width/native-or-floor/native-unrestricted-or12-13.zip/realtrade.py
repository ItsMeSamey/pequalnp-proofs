from pathlib import Path
from sample import samples
rows,front,target=samples(Path('L-meta-18968.json'))
H=[sum(set(r&8191 for k,r in enumerate(rows)if ((target&~front)>>k)&1 and r&(1<<(13+j)))) for j in range(7)]
for h in range(2,6):
 gates=[]
 def gate(op,a,b):
  gates.append((op,a,b));return 19+len(gates)
 def merge(xs):
  a,*tail=xs
  for x in tail:a=gate(0,a,x)
  return a
 out=[]
 for j,v in enumerate(H):
  t=13+j
  tt=gate(0,t,13+((j+1)%7)) if j<h else t
  z=gate(1,tt,merge([i for i in range(13)if v>>i&1]))
  if j<h:z=gate(1,z,t)
  out.append(z)
 o=merge(out)
 for k,r in enumerate(rows):
  vs=[bool(r>>i&1)for i in range(20)]
  for a,x,y in gates:vs.append((vs[x]and vs[y])if a else(vs[x]or vs[y]))
  assert bool(vs[o]or front>>k&1)==bool(target>>k&1)
 print('actual',sum(z[0] for z in gates),len(gates)-sum(z[0]for z in gates),676)
