from pathlib import Path
exec(Path('jointprice.py').read_text().split('for bank in ((),')[0])
for bank in ((),(129,),(4160,),(129,4160)):
 hard=[p|(t<<13)for p,t in neg if cheapest(p,t,bank)==13]
 H=reduce(or_,hard)
 a=sum((H&h).bit_count()+int(bool(h&~H)) for h in hood)
 assert ((127^(H>>13)).bit_count()<=1)
 print(bank,len(hard),H&8191,H>>13,a)
