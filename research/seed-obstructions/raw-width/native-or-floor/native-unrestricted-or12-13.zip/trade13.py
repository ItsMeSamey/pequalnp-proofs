from pathlib import Path
exec(Path('jointprice.py').read_text().split('for bank in ((),')[0])
edges=[(p,1<<(13+j))for j,H in enumerate(hood)for p in bits(H)]
FULL=(1<<20)-1
def marked_cost(arms):
 arm=list(set(arms));groups=set()
 for i,x in enumerate(arm):
  for y in arm[i:]:
   m=sum(1<<k for k,(p,t) in enumerate(edges)if (p&x and t&y)or(t&x and p&y))
   if m:groups.add(m)
 groups=[m for m in groups if not any(m!=n and not m&~n for n in groups)]
 by=[[m for m in groups if m>>k&1]for k in range(28)]
 @cache
 def dp(rem):
  if not rem:return 0
  i=min((j for j in range(28) if rem>>j&1),key=lambda j:len(by[j]))
  return 1+min(dp(rem&~m)for m in by[i])
 return dp((1<<28)-1)
def maximal(possible,compat):
 def rec(c,p,x):
  if not p and not x:yield c;return
  u=max(p|x,key=lambda i:len(p&compat[i]))
  for a in sorted(p-compat[u]):
   yield from rec(c+[a],p&compat[a],x&compat[a])
   p.remove(a);x.add(a)
 yield from rec([],set(possible),set())
for bank in ((),(129,),(4160,),(129,4160)):
 hard=[p|(t<<13)for p,t in neg if cheapest(p,t,bank)==13]
 prot=reduce(or_,hard);U=FULL^prot
 raw=list(bits(FULL))+list(bank);orig=raw+[U]
 classes={}
 for i,x in enumerate(orig):
  for y in orig[i:]:
   mask=x|y;r=mask&prot
   if not r or any(not mask&~m for m in orig):continue
   classes[r]=classes.get(r,0)|mask
 rows={r:sum(1<<i for i,n in enumerate(hard)if n&r)for r in classes}
 adj={r:{s for s in classes if not rows[r]&rows[s]}for r in classes}
 cl=list(maximal(classes,adj));vals={}
 for c in cl:
  a=marked_cost(orig+[classes[x]for x in c]);vals[a]=vals.get(a,0)+1
 print(bank,len(hard),U,len(classes),len(cl),vals,flush=True)
