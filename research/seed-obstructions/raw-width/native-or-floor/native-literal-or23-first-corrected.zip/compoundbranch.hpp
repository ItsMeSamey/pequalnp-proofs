// First normalized OR on a cut with one live non-singleton compound.
bool firstImpossible(msk s, msk u, const vector<msk>& pos, const vector<msk>& negative) {
 using R=std::array<uint64_t,4>;
 struct Arm{msk raw;unsigned p;R n;};
 if(negative.size()>256)abort();
 std::vector<msk> pp; for(msk e:pos)if(!(e&~s))pp.push_back(e);
 std::vector<msk> subsets={0};for(msk t=s;t;t&=t-1)subsets.push_back(t&-t);
 subsets.insert(subsets.end(),pp.begin(),pp.end());
 struct Atom{msk e;std::array<R,4> n;};std::vector<Atom> obligations;
 for(msk e:pp){
   Atom g{e,{}};msk x=e&-e,y=e^x;
   for(int own=0;own<4;own++){msk need=e&~((own&1?x:0)|(own&2?y:0));
     for(int i=0;i<(int)negative.size();i++){msk n=negative[i];if(!(need&~n)&&(!(e&u)||(n&u)))g.n[own][i/64]|=uint64_t(1)<<(i%64);}
   }obligations.push_back(g);
 }
 std::vector<Arm> arms;
 // Try U and single raw sources first, as these give the most permissive holder arrangements.
 for(int andU=0;andU<2;andU++)for(msk x:subsets){
   if(!x&&!andU)continue;Arm a={x,0,{}};
   for(unsigned j=0;j<pp.size();j++)if(!(x&~pp[j])&&(!andU||(u&pp[j])))a.p|=1u<<j;
   if(!a.p)continue;
   for(unsigned j=0;j<negative.size();j++)if(!(x&~negative[j])&&(!andU||(u&negative[j])))a.n[j/64]|=uint64_t(1)<<(j%64);
   arms.push_back(a);
 }
 for(unsigned i=0;i<arms.size();i++)for(unsigned j=0;j<i;j++){auto &a=arms[i],&b=arms[j];
   if((a.raw&b.raw)||!(a.p&~b.p)||!(b.p&~a.p))continue;
   msk held=a.raw|b.raw;unsigned sp=a.p|b.p;bool safe=true;
   for(unsigned t=0;t<pp.size()&&safe;t++){msk e=pp[t];if(!(e&held))continue;
     msk x=e&-e;int own=int(bool(x&held))+2*int(bool((e^x)&held));
     auto &forbid=obligations[t].n[own];
     for(int k=0;k<4;k++)if(forbid[k] & ((sp>>t&1)?(a.n[k]|b.n[k]):~uint64_t(0))) {safe=false;break;}
   }
   if(safe)return false;
 }
 return true;
}
