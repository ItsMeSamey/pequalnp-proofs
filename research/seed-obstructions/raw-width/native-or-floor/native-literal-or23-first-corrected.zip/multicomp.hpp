using RV=std::array<uint64_t,4>;
using PV=unsigned;
struct Mark {msk held;PV p;RV n,forbid;};
bool intersects(const RV&a,const RV&b){return (a[0]&b[0])||(a[1]&b[1])||(a[2]&b[2])||(a[3]&b[3]);}
bool firstMulti(msk s,const vector<msk>&non,const vector<msk>&pos,const vector<msk>&neg){
  if(neg.size()>256)abort();vector<msk> pp;for(msk e:pos)if(!(e&~s))pp.push_back(e);
  auto code=[&](msk e){int m=0;for(unsigned j=0;j<non.size();j++)if(e&non[j])m|=1<<j;return m;};
  vector<int> pn,nn;for(auto e:pp)pn.push_back(code(e));for(auto n:neg)nn.push_back(code(n));
  vector<array<RV,4>> forb(pp.size());bool conflict=false;
  for(unsigned j=0;j<pp.size();j++){msk e=pp[j],x=e&-e,y=e^x;
    for(int held=1;held<4;held++){msk keep=e&~((held&1?x:0)|(held&2?y:0));
      for(unsigned k=0;k<neg.size();k++)if(!(pn[j]&~nn[k])&&!(keep&~neg[k])){
         forb[j][held][k/64]|=uint64_t(1)<<(k%64);if(held==3)conflict=true;}}
  }
  if(!conflict)return false;
  vector<msk> raw={0};for(msk w=s;w;w&=w-1)raw.push_back(w&-w);raw.insert(raw.end(),pp.begin(),pp.end());
  int bits=1<<non.size();vector<int> tables;
  for(int f=1;f<1<<bits;f++){bool ok=true;for(int c=0;c<bits;c++)if(f>>c&1)
    for(int v=0;v<bits;v++)if(!(c&~v)&&!(f>>v&1))ok=false;if(ok)tables.push_back(f);}
  vector<Mark> arms;
  for(msk r:raw){PV need=0;RV banned{};
    for(unsigned j=0;j<pp.size();j++){msk e=pp[j],x=e&-e,y=e^x;
      for(int u=1;u<=2;u++)if(r&(u==1?x:y)){
        const auto&g=forb[j][u];if(g[0]||g[1]||g[2]||g[3]){
          need|=1u<<j;for(int k=0;k<4;k++)banned[k]|=g[k];}}}
    for(int f:tables){Mark a{r,0,{},banned};
      for(unsigned j=0;j<pp.size();j++)if(!(r&~pp[j])&&(f>>pn[j]&1))a.p|=1u<<j;
      if(!a.p||(need&~a.p))continue;
      for(unsigned j=0;j<neg.size();j++)if(!(r&~neg[j])&&(f>>nn[j]&1))a.n[j/64]|=uint64_t(1)<<(j%64);
      if(!intersects(a.n,banned))arms.push_back(a);
    }
  }
  for(unsigned i=0;i<arms.size();i++)for(unsigned j=0;j<i;j++){const auto&a=arms[i];const auto&b=arms[j];
    msk held=a.held|b.held;
    if(!held||(a.held&b.held)||!(a.p&~b.p)||!(b.p&~a.p)||intersects(a.n,b.forbid)||intersects(b.n,a.forbid))continue;
    bool ok=true;for(unsigned t=0;t<pp.size()&&ok;t++){msk e=pp[t],x=e&-e,y=e^x;
      int own=int(bool(x&held))+2*int(bool(y&held));if(!own)continue;
      auto& nn=forb[t][own];for(int k=0;k<4;k++)if(nn[k]&(((a.p|b.p)>>t&1)?a.n[k]|b.n[k]:~uint64_t(0))){ok=false;break;}}
    if(ok)return false;
  }
  return true;
}
