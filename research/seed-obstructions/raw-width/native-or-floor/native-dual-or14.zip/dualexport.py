from nestedtrace import *
pos=sorted({r for i,r in enumerate(w) if (target&~seed)>>i&1})
ns=sorted({r for i,r in enumerate(w) if neg>>i&1})
print(len(pos),len(ns))
print(*pos);print(*ns)
