"""Independent scalar evaluator for original L-meta-18968 signed rows."""
import hashlib, json, re, sys
from pathlib import Path
s = json.loads(Path(sys.argv[1]).read_text())["formal_statement"]
assert hashlib.sha256(s.encode()).hexdigest() == "d5fbefe3ea85033034056aae8ed0b90ecfe428b8a69e3456176309d0c82b54c2"
seeds = [int("".join(f"{int(v):019d}" for v in re.findall(r"\((\d+) :", b))) for b in re.findall(r"\[([\d\s\(\):ℕ,]+)\]", s)]
assert len(seeds)==2
front, target = [int(re.search(rf"x1 \({i} : ℕ\) = \((\d+) : ℕ\)",s)[1]) for i in (54,88)]
g = [tuple(map(int,l.split())) for l in Path(sys.argv[2]).read_text().splitlines()]
live={37+len(g)}
for i in reversed(range(len(g))):
    op,a,b=g[i]
    assert op in (0,1) and 0<=min(a,b)<=max(a,b)<38+i
    assert 38+i in live
    live.update((a,b))
fp,fn,dirty=[],[],set()
for row in range(676):
    lane,col=divmod(row,13)
    wires=[seed>>(13*lane+(col-shift)%13)&1 for seed in seeds for shift in range(13)]
    wires += [wires[j]|wires[j+1] for j in range(6)]
    wires += [wires[j+3]|wires[(j+9)%13] for j in range(6)]
    wires += [wires[j+26]|wires[j+32] for j in range(6)]
    wires=wires[:13]+wires[19:44]
    y=target>>row&1
    for i,(op,a,b) in enumerate(g):
        bit=(wires[a]&wires[b]) if op else (wires[a]|wires[b])
        wires.append(bit)
        if op and bit and not y: dirty.add(i)
    got=wires[-1]|(front>>row&1)
    if got!=y: (fp if got else fn).append(row)
print(len(g),sum(op for op,_,_ in g),len(dirty),fp,fn)
