#include <bits/stdc++.h>
using namespace std;using U=uint32_t;using W=uint64_t;
constexpr int B=8;using Neg=array<W,B>;
struct Sig{U p;Neg n;auto operator<=>(const Sig&)const=default;};
using State=vector<Sig>;vector<Sig>raw;vector<unordered_map<U,uint8_t>> memo;
vector<vector<vector<U>>> opts;int nr,npos;U P;
int cover(int n,U p){
 if(!p)return 0;
 auto& t=memo[n];if(auto it=t.find(p);it!=t.end())return it->second;
 int bit=-1;size_t small=SIZE_MAX;for(U k=p;k;k&=k-1){int i=__builtin_ctz(k);if(opts[n][i].size()<small){small=opts[n][i].size();bit=i;}}
 int v=90;for(U m:opts[n][bit])v=min(v,1+cover(n,p&~m));
 t.emplace(p,v);return v;
}
vector<vector<pair<int,U>>> low;vector<int> tight;
bool advance(const State& s,int b,const vector<int>&order){
 low.assign(nr,{});tight.clear();
 for(int n:order){
 auto& ls=low[n];ls.emplace_back(0,0);
 for(auto &v:s)if(!(v.n[n/64]>>(n%64)&1)){
 int sz=ls.size();for(int i=0;i<sz;i++)ls.emplace_back(ls[i].first+1,ls[i].second|v.p);}
 int a=90;for(auto [cost,m]:ls)a=min(a,cost+cover(n,P&~m));
 if(a>b+1)return false;if(a==b+1)tight.push_back(n);
 }return true;
}
vector<Sig> nexts(const State&s,int b,const vector<int>&ord){
 if(!advance(s,b,ord))return {};
 vector<Sig> bank=raw;bank.insert(bank.end(),s.begin(),s.end());
 set<U>closed{P};for(auto&w:bank){vector<U>q(closed.begin(),closed.end());for(U p:q)closed.insert(p&w.p);}
 vector<Sig>ops;
 for(U p:closed)if(p&&p!=P){Sig v{p,{}};v.n.fill(~0ULL);for(auto&w:bank)if(!(p&~w.p))for(int k=0;k<B;k++)v.n[k]&=w.n[k];ops.push_back(v);}
 Neg req{};for(int n:tight)req[n/64]|=W(1)<<(n%64);
 vector<Sig> okops;
 for(auto &x:ops){bool good=true;for(int k=0;k<B;k++)if(x.n[k]&req[k])good=false;if(good)okops.push_back(x);}
 if(!tight.empty()){
 vector<U> maximal;for(auto&x:okops){bool dominated=false;for(auto&y:okops)if(x.p!=y.p && !(x.p&~y.p)){dominated=true;break;}if(!dominated)maximal.push_back(x.p);}
 array<vector<U>,28> opt;for(U v:maximal)for(U t=v;t;t&=t-1)opt[__builtin_ctz(t)].push_back(v);
 unordered_map<U,int> mm;
 function<int(U)> f=[&](U t){if(!t)return 0;if(auto i=mm.find(t);i!=mm.end())return i->second;int u=-1;size_t best=SIZE_MAX;for(U a=t;a;a&=a-1){int j=__builtin_ctz(a);if(opt[j].size()<best){best=opt[j].size();u=j;}}
 int ans=99;for(auto v:opt[u])ans=min(ans,1+f(t&~v));mm[t]=ans;return ans;};
 if(f(P)>b+1)return {};
 }
 ops=move(okops);
 set<Sig>out;
 for(size_t i=0;i<ops.size();i++){auto&x=ops[i];bool ok=true;for(int j=0;j<B;j++)if(x.n[j]&req[j])ok=false;if(!ok)continue;
 for(size_t j=0;j<i;j++){auto&y=ops[j];U p=x.p|y.p;if(p==x.p||p==y.p)continue;
 bool ok2=true;for(int k=0;k<B;k++)if(y.n[k]&req[k])ok2=false;if(!ok2)continue;
 for(int n:tight){bool hit=false;for(auto [cost,m]:low[n])if(cost+cover(n,P&~p&~m)<=b-1){hit=true;break;}if(!hit){ok2=false;break;}}
 if(ok2){Sig z{p,{}};for(int k=0;k<B;k++)z.n[k]=x.n[k]|y.n[k];if(!binary_search(s.begin(),s.end(),z))out.insert(z);}
 }}return {out.begin(),out.end()};
}
int main(int argc,char**argv){
 cin>>npos>>nr;P=(U(1)<<npos)-1;vector<W>ps(npos),ns(nr);for(auto&v:ps)cin>>v;for(auto&v:ns)cin>>v;
 int cap=atoi(argv[1]),depth=atoi(argv[2]),lo=argc>3?atoi(argv[3]):0,hi=argc>4?atoi(argv[4]):10000;
 for(int j=0;j<38;j++)if(j<20||j==29||j==30){Sig s{};for(int i=0;i<npos;i++)s.p|=U((ps[i]>>j)&1)<<i;for(int i=0;i<nr;i++)s.n[i/64]|=((ns[i]>>j)&1)<<(i%64);raw.push_back(s);}
 memo.resize(nr);opts.resize(nr,vector<vector<U>>(npos));vector<int>ord(nr);iota(ord.begin(),ord.end(),0);
 for(int n:ord)for(auto &v:raw)if(!(v.n[n/64]>>(n%64)&1))for(int i=0;i<npos;i++)if(v.p>>i&1)opts[n][i].push_back(v.p);
 stable_sort(ord.begin(),ord.end(),[](int a,int b){return cover(a,P)>cover(b,P);});
 set<State> f={{}};for(int d=0;d<depth;d++){set<State> nx;for(auto&s:f){int idx=0;for(auto&v:nexts(s,cap-d,ord)){if(d==0&&(idx++<lo||idx>hi))continue;State z=s;z.insert(lower_bound(z.begin(),z.end(),v),v);nx.insert(z);}}
 cout<<d+1<<" "<<nx.size()<<endl;f=move(nx);if(f.empty())break;}
}
