from pathlib import Path
from collections import Counter
import sys
def read(d,lo,hi,deep=False):
 p=Path(d)/str(lo)
 assert p.with_suffix('.status').read_text().strip()=='0',(d,lo)
 rows=[tuple(map(int,s.split())) for s in p.with_suffix('.log').read_text().splitlines()]
 assert (rows[0:2]==[(1,1),(2,hi-lo)] if deep else rows[0]==(1,hi-lo)) and rows[-1][1]==0 and [a for a,b in rows]==list(range(1,len(rows)+1))
 assert len(rows)<12
 return len(rows)
if __name__=='__main__':
 agg=Counter()
 for i in range(0,969,25):
  if i==750:
   for j in range(750,775):
    if j==762:
     assert Path('dual13sub/762.log').read_text().splitlines()[1]=='2 1006'
     levels=[read('dual13deep',a,min(a+25,1006),True) for a in range(0,1006,25)]
     agg[max(levels)]+=1
    else:agg[read('dual13sub',j,j+1)]+=1
  else:agg[read('dual13receipt',i,min(969,i+25))]+=min(25,969-i)
 assert agg.total()==969;print(dict(sorted(agg.items())))
