import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short58240
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 16512, 16640, 33024, 33280]
def n : List Nat := [896, 8448, 16896, 32896, 57344]
def pp := p.map (canonical 58240)
def nn := n.map (canonical 58240)
def parts : List Nat := [0, 128, 256, 512, 8192, 16384, 32768, 8320, 8704, 16512, 16640, 33024, 33280]
def g : ShortGrid := [(0,[(128,309489732259886631936327937), (256,238307093840112706590972510721), (512,79538861190790864407636279553), (8192,1), (8320,256), (8704,0), (16384,158458742917061955551399903233), (16512,8590000128), (16640,8589935104), (32768,316917485834123911102799806465), (33024,17180001024), (33280,17179934976)]), (128,[(256,17230266368), (512,21525233664), (8192,1099511627776), (8704,0), (16384,8590000128), (16640,8590000128), (32768,17179934720), (33024,17179934720), (33280,17179934720)]), (256,[(512,846623953453312), (8192,848822976643072), (8320,256), (8704,0), (16384,846623953388032), (16512,65536), (32768,17180001024), (33280,65792)]), (512,[(8192,282574488338432), (8320,256), (16384,8590000384), (16512,65536), (16640,8590000384), (32768,17179934976), (33024,17179934976)]), (8192,[(16384,12901679104), (16512,16777216), (16640,12901679104), (32768,17196646400), (33024,17196646400), (33280,4311744512)]), (8320,[(16384,256), (16640,256), (32768,256), (33024,256), (33280,256)]), (8704,[(16384,0), (16512,0), (16640,0), (32768,0), (33024,0)]), (16384,[(32768,21508391424), (33024,12918456832), (33280,65792)]), (16512,[(32768,65536), (33024,65536), (33280,65536)]), (16640,[(32768,512), (33280,65792)])]
private theorem row0 : parts.all (shortPair g pp nn 58240 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 58240 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 58240 256) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 58240 512) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 58240 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 58240 16384) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 58240 32768) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 58240 8320) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 58240 8704) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 58240 16512) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 58240 16640) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 58240 33024) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 58240 33280) = true := by decide
theorem full : checkArms 58240 58240 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 256, 512, 8192, 16384, 32768, 8320, 8704, 16512, 16640, 33024, 33280] : List Nat).all (fun i => parts.all (shortPair g pp nn 58240 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short58240
theorem validBranch58240 : checkArms 58240 58240 [8320, 8704, 16512, 16640, 33024, 33280] [896, 8448, 16896, 32896, 57344] = true := Short58240.full
end TightRow.Protected.Numeric
