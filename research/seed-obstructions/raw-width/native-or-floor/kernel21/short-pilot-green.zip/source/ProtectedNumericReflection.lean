import ProtectedNumericCheck
import ProtectedArm

namespace TightRow.Protected.Numeric
open TightRow.Protected

def listed (xs : List Nat) : Set Nat := {x | x ∈ xs}
def maskHits (l : Nat) : Set Nat := {x | subset l x = true}
def maskOrder (t : Nat) (x y : Nat) : Prop := outside t x y = true

theorem required_iff (ps ns : List Nat) (joint x : Nat) :
    x ∈ Required (listed ps) (listed ns) (maskOrder joint) ↔
      x ∈ ps.filter (fun p => ns.any (outside joint p)) := by
  simp [Required,listed,maskOrder,List.mem_filter,List.any_eq_true]

theorem denied_iff (ps ns : List Nat) (joint n : Nat) :
    n ∈ Denied (listed ps) (listed ns) (maskOrder joint) ↔
      n ∈ ns.filter (fun z => ps.any (fun x => outside joint x z)) := by
  simp [Denied,listed,maskOrder,List.mem_filter,List.any_eq_true]

theorem allowed_iff (ps ns : List Nat) (joint held factors x : Nat) :
    x ∈ Allowed (listed ps) (listed ns) (maskOrder joint) (maskOrder held) (maskHits factors) ↔
    x ∈ ps.filter (grants factors held (ns.filter (fun z => ps.any (fun p => outside joint p z)))) := by
  let denied := ns.filter (fun z => ps.any (fun p => outside joint p z))
  change _ ↔ x ∈ ps.filter (grants factors held denied)
  rw [List.mem_filter]
  constructor
  · rintro ⟨xp,xh,forbid⟩
    refine ⟨xp,Bool.and_eq_true_iff.mpr ⟨xh,?_⟩⟩
    have none : denied.any (fun n => subset factors n && outside held x n) = false := by
      apply List.any_eq_false.mpr
      intro n hn h
      obtain ⟨hit,order⟩ := Bool.and_eq_true_iff.mp h
      exact forbid n ((denied_iff ..).mpr hn) hit order
    simp [none]
  · rintro ⟨xp,grant⟩
    obtain ⟨hit,unblocked⟩ := Bool.and_eq_true_iff.mp grant
    refine ⟨xp,hit,?_⟩
    intro n hn raw order
    have bad : denied.any (fun z => subset factors z && outside held x z) = true :=
      List.any_eq_true.mpr ⟨n,(denied_iff ..).mp hn,Bool.and_eq_true_iff.mpr ⟨raw,order⟩⟩
    simp [bad] at unblocked

theorem reflectedReject {ps ns : List Nat} {held l h : Nat}
    (disj : l &&& h = 0) (nonzero : l ||| h ≠ 0)
    (blocked : armPairRejected ps ns held l h = true) :
    ¬ Feasible (listed ps) (listed ns) (maskOrder (l ||| h)) (maskOrder held)
      (maskHits l) (maskHits h) := by
  let req := ps.filter (fun p => ns.any (outside (l ||| h) p))
  let denied := ns.filter (fun n => ps.any (fun p => outside (l ||| h) p n))
  let a := ps.filter (grants l held denied)
  let b := ps.filter (grants h held denied)
  let ok := fun x y => x != y && trimmed l held y x && trimmed h held x y &&
    req.all (fun p => (a.contains p && trimmed l held y p) || (b.contains p && trimmed h held x p))
  have fail : ¬ a.any (fun x => b.any (ok x)) = true := by
    simpa [armPairRejected,disj,nonzero,a,b,req,denied,ok] using blocked
  rintro ⟨x,y,ne,hx,hy,cover⟩
  have trimEq (factor o p : Nat) :
      trimmed factor held o p = true ↔ ¬(o ∈ maskHits factor ∧ maskOrder held p o) := by
    cases h1 : subset factor o <;> cases h2 : outside held p o <;> simp [trimmed,maskHits,maskOrder,h1,h2]
  apply fail
  apply List.any_eq_true.mpr
  refine ⟨x,(allowed_iff ..).mp hx.1,List.any_eq_true.mpr ⟨y,(allowed_iff ..).mp hy.1,?_⟩⟩
  simp only [ok,Bool.and_eq_true,bne_iff_ne,trimEq,List.all_eq_true]
  refine ⟨⟨⟨ne,hx.2⟩,hy.2⟩,?_⟩
  intro p hp
  rcases cover ((required_iff ..).mpr hp) with left | right
  · exact Bool.or_eq_true_iff.mpr (Or.inl (Bool.and_eq_true_iff.mpr
      ⟨by simpa only [List.contains_eq_mem,decide_eq_true_eq] using (show p ∈ a from (allowed_iff ..).mp left.1),(trimEq ..).mpr left.2⟩))
  · exact Bool.or_eq_true_iff.mpr (Or.inr (Bool.and_eq_true_iff.mpr
      ⟨by simpa only [List.contains_eq_mem,decide_eq_true_eq] using (show p ∈ b from (allowed_iff ..).mp right.1),(trimEq ..).mpr right.2⟩))

end TightRow.Protected.Numeric
