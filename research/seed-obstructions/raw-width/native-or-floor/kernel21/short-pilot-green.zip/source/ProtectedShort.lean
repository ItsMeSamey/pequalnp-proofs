import ProtectedNumericReflection

namespace TightRow.Protected.Numeric
open TightRow.Protected

/-- A negative is denied by an externally dominated positive. -/
structure Denial where
  positive : Nat
  negative : Nat
deriving Inhabited

/-- A missing raw factor or a specific forced-low negative prevents admission. -/
def blockedAt (ps ns : List Nat) (joint held arm x : Nat) (w : Denial) : Bool :=
  !(subset arm x) ||
    (ps.contains w.positive && ns.contains w.negative &&
      outside joint w.positive w.negative && subset arm w.negative && outside held x w.negative)

theorem notAllowed {ps ns : List Nat} {joint held arm x : Nat} {w : Denial}
    (ok : blockedAt ps ns joint held arm x w = true) :
    x ∉ Allowed (listed ps) (listed ns) (maskOrder joint) (maskOrder held) (maskHits arm) := by
  rintro ⟨_,raw,grant⟩
  rcases Bool.or_eq_true_iff.mp ok with missing | denied
  · change (!subset arm x) = true at missing
    change subset arm x = true at raw
    simp [raw] at missing
  · simp only [Bool.and_eq_true,List.contains_eq_mem,decide_eq_true_eq] at denied
    obtain ⟨⟨⟨⟨p,n⟩,ext⟩,hit⟩,fr⟩ := denied
    exact grant w.negative ⟨n,w.positive,p,ext⟩ hit fr

inductive Cut where
  | uncovered (x negative : Nat) (left right : Denial)
  | emptyArm (second : Bool) (rows : List (Nat × Denial))

def lookup (rows : List (Nat × Denial)) (x : Nat) : Denial :=
  ((rows.find? (fun p => p.1 == x)).map Prod.snd).getD default

def cutOK (ps ns : List Nat) (t a b : Nat) : Cut → Bool
  | .uncovered x n l h =>
    ps.contains x && ns.contains n && outside (a ||| b) x n &&
      blockedAt ps ns (a ||| b) t a x l && blockedAt ps ns (a ||| b) t b x h
  | .emptyArm second rows =>
    ps.all (fun x => blockedAt ps ns (a ||| b) t (if second then b else a) x (lookup rows x))

theorem cutReject {ps ns : List Nat} {t a b : Nat} (c : Cut)
    (ok : cutOK ps ns t a b c = true) :
    ¬Feasible (listed ps) (listed ns) (maskOrder (a ||| b)) (maskOrder t) (maskHits a) (maskHits b) := by
  rintro ⟨x,y,_,lx,hy,cover⟩
  cases c with
  | uncovered p n l h =>
    simp only [cutOK,Bool.and_eq_true,List.contains_eq_mem,decide_eq_true_eq] at ok
    obtain ⟨⟨⟨⟨pp,nn⟩,ext⟩,lb⟩,rb⟩ := ok
    rcases cover (show p ∈ Required (listed ps) (listed ns) (maskOrder (a ||| b)) from
      ⟨pp,n,nn,ext⟩) with le | re
    · exact notAllowed lb le.1
    · exact notAllowed rb re.1
  | emptyArm second rows =>
    cases second with
    | false => exact notAllowed (List.all_eq_true.mp ok x lx.1.1) lx.1
    | true => exact notAllowed (List.all_eq_true.mp ok y hy.1.1) hy.1

theorem feasibleFlip {P N : Set Nat} {ext free : Nat → Nat → Prop} {A B : Set Nat}
    (ok : Feasible P N ext free A B) : Feasible P N ext free B A := by
  obtain ⟨x,y,ne,l,r,coverage⟩ := ok
  exact ⟨y,x,Ne.symm ne,r,l,fun p hp => (coverage hp).elim Or.inr Or.inl⟩

def octet (w i : Nat) : Nat := (w >>> (8*i)) % 256

def denialAt (ps ns : List Nat) (w i : Nat) : Denial :=
  ⟨ps.getD (octet w (i+1)) 0,ns.getD (octet w i) 0⟩

def decodeCut (ps ns : List Nat) (w : Nat) : Cut :=
  if octet w 0 = 0 then
    .uncovered (ps.getD (octet w 1) 0) (ns.getD (octet w 2) 0)
      (denialAt ps ns w 3) (denialAt ps ns w 5)
  else
    .emptyArm (octet w 0 == 2) (ps.zipIdx.map (fun ⟨x,i⟩ => (x,denialAt ps ns w (2*i+1))))

abbrev ShortGrid := List (Nat × List (Nat × Nat))
def codeAt (g : ShortGrid) (a b : Nat) : Nat :=
  let row := ((g.find? (fun z => z.1 == a)).map Prod.snd).getD []
  ((row.find? (fun z => z.1 == b)).map Prod.snd).getD 0

def directCheck (g : ShortGrid) (ps ns : List Nat) (t a b : Nat) : Bool :=
  cutOK ps ns t a b (decodeCut ps ns (codeAt g a b))

def shortPair (g : ShortGrid) (ps ns : List Nat) (t a b : Nat) : Bool :=
  if a &&& b != 0 || (a ||| b == 0) then true
  else if a ≤ b then directCheck g ps ns t a b
  else directCheck g ps ns t b a

theorem shortReject {g : ShortGrid} {ps ns : List Nat} {t a b : Nat}
    (disj : a &&& b = 0) (nz : a ||| b ≠ 0)
    (cert : shortPair g ps ns t a b = true) :
    ¬Feasible (listed ps) (listed ns) (maskOrder (a ||| b)) (maskOrder t) (maskHits a) (maskHits b) := by
  by_cases ord : a ≤ b
  · exact cutReject _ (by simpa [shortPair,disj,nz,ord,directCheck] using cert)
  · intro feas
    have ok : directCheck g ps ns t b a = true := by simpa [shortPair,disj,nz,ord] using cert
    apply cutReject _ ok
    simpa [Nat.or_comm] using feasibleFlip feas

/-- The local witnesses imply the original full ordered test including both asymmetric trims. -/
theorem recoverFullPair {g : ShortGrid} {ps ns : List Nat} {t l h : Nat}
    (cert : shortPair g ps ns t l h = true) : armPairRejected ps ns t l h = true := by
  by_cases disj : l &&& h = 0
  · by_cases nz : l ||| h = 0
    · simp [armPairRejected,nz]
    let req := ps.filter (fun p => ns.any (outside (l ||| h) p))
    let denied := ns.filter (fun n => ps.any (fun p => outside (l ||| h) p n))
    let a := ps.filter (grants l t denied)
    let b := ps.filter (grants h t denied)
    let ok := fun x y => x != y && trimmed l t y x && trimmed h t x y &&
      req.all (fun p => (a.contains p && trimmed l t y p) || (b.contains p && trimmed h t x p))
    have none : a.any (fun x => b.any (ok x)) = false := by
      apply List.any_eq_false.mpr
      intro x xa yes
      obtain ⟨y,yb,hi⟩ := List.any_eq_true.mp yes
      simp only [ok,Bool.and_eq_true,bne_iff_ne,List.all_eq_true] at hi
      obtain ⟨⟨⟨ne,lx⟩,hy⟩,cov⟩ := hi
      have trim (factor o p : Nat) :
          trimmed factor t o p = true ↔ ¬(o ∈ maskHits factor ∧ maskOrder t p o) := by
        cases h1 : subset factor o <;> cases h2 : outside t p o <;> simp [trimmed,maskHits,maskOrder,h1,h2]
      apply shortReject disj nz cert
      refine ⟨x,y,ne,⟨(allowed_iff ..).mpr xa,(trim ..).mp lx⟩,
        ⟨(allowed_iff ..).mpr yb,(trim ..).mp hy⟩,?_⟩
      intro p pr
      rcases Bool.or_eq_true_iff.mp (cov p ((required_iff ..).mp pr)) with left | right
      · obtain ⟨pa,tr⟩ := Bool.and_eq_true_iff.mp left
        exact Or.inl ⟨(allowed_iff ..).mpr (show p ∈ a by simpa only [List.contains_eq_mem,decide_eq_true_eq] using pa),(trim ..).mp tr⟩
      · obtain ⟨pb,tr⟩ := Bool.and_eq_true_iff.mp right
        exact Or.inr ⟨(allowed_iff ..).mpr (show p ∈ b by simpa only [List.contains_eq_mem,decide_eq_true_eq] using pb),(trim ..).mp tr⟩
    simpa [armPairRejected,disj,nz,a,b,req,denied,ok] using congrArg Bool.not none
  · simp [armPairRejected,disj]

theorem recoverFull {s t : Nat} {ps ns : List Nat} (g : ShortGrid)
    (dom : (ps.map (canonical s)).any
      (fun x => (ns.map (canonical s)).any (outside t x)) = true)
    (nonfinal : (singletons t).all (fun q => ps.any (fun x => x &&& q == 0)) = true)
    (checked : let parts := 0 :: (singletons t ++ ps.filter (fun p => subset p t))
      parts.all (fun a => parts.all (shortPair g (ps.map (canonical s)) (ns.map (canonical s)) t a)) = true) :
    checkArms s t ps ns = true := by
  apply Bool.and_eq_true_iff.mpr
  refine ⟨Bool.and_eq_true_iff.mpr ⟨dom,nonfinal⟩,List.all_eq_true.mpr ?_⟩
  intro a ha
  apply List.all_eq_true.mpr
  intro b hb
  exact recoverFullPair (List.all_eq_true.mp (List.all_eq_true.mp checked a ha) b hb)

end TightRow.Protected.Numeric
