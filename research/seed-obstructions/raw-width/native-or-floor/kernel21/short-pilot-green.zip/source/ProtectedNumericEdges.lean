import ProtectedDeleteRules

namespace TightRow.Protected.Numeric
open TightRow.Deletion TightRow.Protected

abbrev Addr := Fin 22
structure Chart where
  pos : List Nat
  neg : List Nat

def Chart.P (c : Chart) : Set Nat := {x | x ∈ c.pos}
def Chart.N (c : Chart) : Set Nat := {x | x ∈ c.neg}
def source (i : Addr) : Set Nat := {x | x.testBit i.val = true}
def Floor (c : Chart) (d : Nat) := MinCost (Set.range source) c.P c.N d

def reindex (m : List (Option Addr)) (i : Addr) : Option Addr := m.getD i.val none
def childOf (c : Chart) (m : List (Option Addr)) : Child Addr Nat :=
  ⟨rename (reindex m) source,Set.range source,c.P,c.N⟩

def rebits (m : List (Option Addr)) (x : Nat) (i : Addr) : Bool :=
  (reindex m i).elim false (fun j => x.testBit j.val)

theorem renameBits (m : List (Option Addr)) (x : Nat) (i : Addr) :
    x ∈ (childOf c m).raw i ↔ rebits m x i = true := by
  cases h : reindex m i <;> simp [childOf,rename,rebits,h,source]

theorem available (c : Chart) (m : List (Option Addr)) (i : Addr) :
    Avail (childOf c m).bank ((childOf c m).raw i) := by
  cases h : reindex m i with
  | none => exact Or.inl (by simp [childOf,rename,h])
  | some j => exact Or.inr ⟨j,by simp [childOf,rename,h]⟩

structure Edge (p c : Chart) (m : List (Option Addr)) : Prop where
  positive : ∃ x ∈ c.pos, True
  negative : ∃ x ∈ c.neg, True
  up : ∀ x ∈ c.pos, ∃ y ∈ p.pos, ∀ i : Addr,
    y.testBit i.val = true → rebits m x i = true
  down : ∀ x ∈ c.neg, ∃ y ∈ p.neg, ∀ i : Addr,
    rebits m x i = true → y.testBit i.val = true

theorem edgeUp (e : Edge p c m) {x : Nat} (hx : x ∈ c.P) :
    ∃ y ∈ p.P, Below source y (childOf c m).raw x := by
  obtain ⟨y,hy,le⟩ := e.up x hx
  exact ⟨y,hy,fun i hi => (renameBits ..).mpr (le i hi)⟩

theorem edgeDown (e : Edge p c m) {x : Nat} (hx : x ∈ c.N) :
    ∃ y ∈ p.N, Below (childOf c m).raw x source y := by
  obtain ⟨y,hy,le⟩ := e.down x hx
  exact ⟨y,hy,fun i hi => le i ((renameBits ..).mp hi)⟩

theorem goodChild (e : Edge p c m) (q : Addr) (off : reindex m q = none)
    (lower : Floor c d) : ChildOK source p.P p.N q d (childOf c m) := by
  obtain ⟨x,hx,_⟩ := e.positive
  obtain ⟨y,hy,_⟩ := e.negative
  refine ⟨by simp [childOf,rename,off],?_,⟨x,hx⟩,⟨y,hy⟩,fun _ => edgeUp e,
    fun _ => edgeDown e,lower⟩
  intro i
  rcases available c m i with z | h
  · exact Or.inl z
  · exact Or.inr (Or.inr (.atom h))

theorem refundEdge (e : Edge p c m) (lower : Floor c d)
    (a b : Nat) (yes : a ∈ p.pos) (no : b ∈ p.neg)
    (mark : ∀ i : Addr, reindex m i ≠ none → a.testBit i.val = true → b.testBit i.val = true) :
    Floor p (d+1) := by
  obtain ⟨x,hx,_⟩ := e.positive
  apply deletionRule (c := childOf c m) (mark := true) lower (available c m)
    ⟨x,hx⟩ (fun _ => edgeUp e) (fun _ => edgeDown e)
  intro _
  refine ⟨a,yes,b,no,?_⟩
  intro i
  cases h : reindex m i with
  | none => exact Or.inl (by simp [childOf,rename,h])
  | some j => exact Or.inr ⟨⟨j,by simp [childOf,rename,h]⟩,mark i (by simp [h])⟩

end TightRow.Protected.Numeric
