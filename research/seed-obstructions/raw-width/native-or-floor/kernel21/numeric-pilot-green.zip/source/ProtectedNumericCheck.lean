import ProtectedLedger

namespace TightRow.Protected.Numeric

def subset (a b : Nat) : Bool := a &&& b == a

def canonical (support word : Nat) : Nat := Id.run do
  let x := support &&& word
  let mut out := x
  for (c,slot) in [(129,1048576),(4160,2097152)] do
    if (support &&& c == c) && (x &&& c != 0) then out := out ||| slot
  return out

def singletons (w : Nat) : List Nat :=
  ((List.range 20).map (fun i => 2^i)).filter (fun q => subset q w)

def outside (held x y : Nat) : Bool := subset x (held ||| y)

def grants (factors held : Nat) (denied : List Nat) (x : Nat) : Bool :=
  subset factors x && !(denied.any (fun n => subset factors n && outside held x n))

def trimmed (factors held y x : Nat) : Bool :=
  !(subset factors y && outside held x y)

def armPairRejected (ps ns : List Nat) (held l h : Nat) : Bool := Id.run do
  if (l &&& h != 0) || (l ||| h == 0) then return true
  let joint := l ||| h
  let required := ps.filter (fun x => ns.any (outside joint x))
  let denied := ns.filter (fun n => ps.any (fun x => outside joint x n))
  let a := ps.filter (grants l held denied)
  let b := ps.filter (grants h held denied)
  return !(a.any (fun x => b.any (fun y =>
    x != y && trimmed l held y x && trimmed h held x y &&
    required.all (fun p =>
      (a.contains p && trimmed l held y p) || (b.contains p && trimmed h held x p)))))

def checkArms (s held : Nat) (ps ns : List Nat) : Bool :=
  let pp := ps.map (canonical s)
  let nn := ns.map (canonical s)
  let parts := 0 :: (singletons held ++ ps.filter (fun p => subset p held))
  pp.any (fun x => nn.any (outside held x)) &&
    (singletons held).all (fun q => ps.any (fun x => x &&& q == 0)) &&
    parts.all (fun l => parts.all (armPairRejected pp nn held l))

end TightRow.Protected.Numeric
