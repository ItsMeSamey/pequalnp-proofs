import ProtectedNumericCheck

namespace TightRow.Protected.Numeric

theorem pilot58240 : checkArms 58240 58240 [8320, 8704, 16512, 16640, 33024, 33280] [896, 8448, 16896, 32896, 57344] = true := by decide

end TightRow.Protected.Numeric
