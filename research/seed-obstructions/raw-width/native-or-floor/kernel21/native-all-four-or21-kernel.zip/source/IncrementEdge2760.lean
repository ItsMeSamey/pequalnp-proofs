import IncrementCharts

namespace TightRow.Protected.Numeric.Increment
open TightRow.Deletion TightRow.NativeSeeds
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def m2760_2759 : List (Option Addr) := [some 0, none, some 2, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, some 19, some 20, some 21]
theorem e2760_2759 : Edge c2760 c2759 m2760_2759 := by
  exact edgeByCodes c2760 c2759 m2760_2759 590689512015856971840233686745216616560618669172548829440 9209320874222452601215035921353043280122061800207036341423235238002226943796199986999615018039877659038159283864227317806995992494550185698796195707135974501194132576201252546483956316214449725774807150494342119680 (by decide) (by decide) (by decide) (by decide)
theorem lift2760 {d : Nat} (low : Floor c2759 d) : Floor c2760 (d+1) := by
  exact refundEdge e2760_2759 low 65568 1114497 (by decide) (by decide) (by decide)
end TightRow.Protected.Numeric.Increment
