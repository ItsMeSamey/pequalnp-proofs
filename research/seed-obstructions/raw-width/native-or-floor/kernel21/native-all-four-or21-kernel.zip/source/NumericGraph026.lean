import Branch241216
import NumericGraph015
import NumericGraph016
import NumericGraph022
import NumericGraph025
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c312 : Chart := ⟨[34816, 66560, 69632, 132096, 133120],[7168, 37888, 65536, 67584, 167936, 229376]⟩
def m312_304 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e312_304 : Edge c312 c304 m312_304 := by constructor <;> decide
theorem floor312 : Floor c312 4 := by
  have up := refundEdge e312_304 floor304 69632 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c313 : Chart := ⟨[33024, 34816, 66560, 69632, 132096, 133120],[7424, 33792, 37888, 67840, 135424, 167936, 196864, 229376]⟩
def m313_312 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, some 12, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e313_312 : Edge c313 c312 m313_312 := by constructor <;> decide
theorem floor313 : Floor c313 5 := by
  have up := refundEdge e313_312 floor312 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c314 : Chart := ⟨[33280, 34816, 66048, 66560, 69632, 132096, 133120],[3584, 6656, 7168, 37888, 65536, 67584, 135680, 167936, 229376]⟩
def m314_305 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e314_305 : Edge c314 c305 m314_305 := by constructor <;> decide
theorem floor314 : Floor c314 6 := by
  have up := refundEdge e314_305 floor305 69632 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c315 : Chart := ⟨[33280, 34816, 66048, 66560, 69632, 131073, 132096, 133120],[1537, 3584, 6657, 7168, 37889, 67585, 98305, 131072, 135680, 167936, 229376]⟩
def m315_314 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e315_314 : Edge c315 c314 m315_314 := by constructor <;> decide
theorem floor315 : Floor c315 7 := by
  have up := refundEdge e315_314 floor314 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c316 : Chart := ⟨[33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120],[1792, 3584, 6656, 7424, 33792, 37888, 67840, 135936, 167936, 196864, 229376]⟩
def m316_314 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, some 12, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e316_314 : Edge c316 c314 m316_314 := by constructor <;> decide
theorem floor316 : Floor c316 7 := by
  have up := refundEdge e316_314 floor314 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c317 : Chart := ⟨[8256, 8704, 33280, 66048, 66560, 131136, 132096],[512, 1600, 33856, 41984, 98368, 131584, 172032, 204800, 229376]⟩
def m317_269 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e317_269 : Edge c317 c269 m317_269 := by constructor <;> decide
theorem floor317 : Floor c317 6 := by
  have up := refundEdge e317_269 floor269 33280 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c318 : Chart := ⟨[8256, 8704, 33024, 33280, 66048, 66560, 131136, 132096],[1856, 9472, 33792, 33856, 41984, 65856, 98368, 131840, 172032, 205056, 229376]⟩
def m318_317 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e318_317 : Edge c318 c317 m318_317 := by constructor <;> decide
theorem floor318 : Floor c318 7 := by
  have up := refundEdge e318_317 floor317 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c319 : Chart := ⟨[8256, 8704, 33280, 34816, 66048, 131136, 133120],[512, 2624, 67648, 75776, 98368, 131584, 172032, 204800, 229376]⟩
def m319_185 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e319_185 : Edge c319 c185 m319_185 := by constructor <;> decide
theorem floor319 : Floor c319 6 := by
  have up := refundEdge e319_185 floor185 66048 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c320 : Chart := ⟨[8704, 33280, 34816, 66048, 66560, 132096, 133120],[512, 3584, 11264, 41984, 75776, 131584, 172032, 204800, 229376]⟩
def m320_305 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e320_305 : Edge c320 c305 m320_305 := by constructor <;> decide
theorem floor320 : Floor c320 6 := by
  have up := refundEdge e320_305 floor305 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c321 : Chart := ⟨[8196, 8704, 33280, 34816, 66048, 66560, 132096, 133120],[3588, 9216, 11264, 33796, 41984, 67588, 75776, 131588, 172032, 204800, 229380]⟩
def m321_320 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e321_320 : Edge c321 c320 m321_320 := by constructor <;> decide
theorem floor321 : Floor c321 7 := by
  have up := refundEdge e321_320 floor320 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c322 : Chart := ⟨[8196, 8704, 33280, 34816, 66048, 66560, 131073, 132096, 133120],[1541, 2565, 3588, 11264, 33797, 41985, 67589, 75777, 98309, 131072, 131588, 172032, 204800, 229380]⟩
def m322_321 : List (Option Addr) := [none, none, some 2, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e322_321 : Edge c322 c321 m322_321 := by constructor <;> decide
theorem floor322 : Floor c322 8 := by
  have up := refundEdge e322_321 floor321 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 8 ≤ 8).trans (up k x net fit)
def c323 : Chart := ⟨[8256, 8704, 33280, 34816, 66048, 66560, 131136, 132096, 133120],[1600, 2624, 3584, 11264, 33856, 41984, 67648, 75776, 98368, 131584, 172032, 204800, 229376]⟩
def m323_320 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e323_320 : Edge c323 c320 m323_320 := by constructor <;> decide
def m323_319 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e323_319 : Edge c323 c319 m323_319 := by constructor <;> decide
def m323_317 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e323_317 : Edge c323 c317 m323_317 := by constructor <;> decide
def m323_307 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e323_307 : Edge c323 c307 m323_307 := by constructor <;> decide
def m323_273 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e323_273 : Edge c323 c273 m323_273 := by constructor <;> decide
def m323_193 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e323_193 : Edge c323 c193 m323_193 := by constructor <;> decide
theorem floor323 : Floor c323 8 := by
  apply protectedBranch source c323.P c323.N (decode 109632) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 109632, q = 6 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 15 ∨ q = 16 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e323_320 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor320 k x net fit)
    · refine ⟨_,goodChild e323_319 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor319 k x net fit)
    · refine ⟨_,goodChild e323_317 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor317 k x net fit)
    · refine ⟨_,goodChild e323_307 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor307 k x net fit)
    · refine ⟨_,goodChild e323_273 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor273 k x net fit)
    · refine ⟨_,goodChild e323_193 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor193 k x net fit)
  · exact pairExcluded 241216 109632 [8256, 8704, 33280, 34816, 66048, 66560, 131136, 132096, 133120] [1600, 2624, 3584, 11264, 33856, 41984, 67648, 75776, 98368, 131584, 172032, 204800, 229376] validBranch241216 (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
