import Branch116480
import NumericGraph002
import NumericGraph004
import NumericGraph005
import NumericGraph006
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c84 : Chart := ⟨[33024, 33280, 66048, 66560],[1792, 33792, 65792, 98304]⟩
def m84_83 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e84_83 : Edge c84 c83 m84_83 := by constructor <;> decide
theorem floor84 : Floor c84 3 := by
  have up := refundEdge e84_83 floor83 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c85 : Chart := ⟨[33280, 34816, 66048],[2560, 32768, 67584, 98304]⟩
def m85_81 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e85_81 : Edge c85 c81 m85_81 := by constructor <;> decide
theorem floor85 : Floor c85 2 := by
  have up := refundEdge e85_81 floor81 34816 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c86 : Chart := ⟨[33280, 34816, 66048, 66560],[3584, 33792, 65536, 67584, 98304]⟩
def m86_85 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e86_85 : Edge c86 c85 m86_85 := by constructor <;> decide
theorem floor86 : Floor c86 3 := by
  have up := refundEdge e86_85 floor85 66560 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c87 : Chart := ⟨[33280, 66048, 69632],[4608, 36864, 65536, 98304]⟩
def m87_81 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e87_81 : Edge c87 c81 m87_81 := by constructor <;> decide
theorem floor87 : Floor c87 2 := by
  have up := refundEdge e87_81 floor81 69632 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c88 : Chart := ⟨[33024, 33280, 66048, 69632],[4864, 32768, 36864, 65792, 98304]⟩
def m88_87 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, none, none, some 15, some 16, none, none, none, none, none]
private theorem e88_87 : Edge c88 c87 m88_87 := by constructor <;> decide
theorem floor88 : Floor c88 3 := by
  have up := refundEdge e88_87 floor87 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c89 : Chart := ⟨[33280, 34816, 66048, 69632],[6656, 32768, 36864, 67584, 98304]⟩
def m89_87 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, none, none, some 15, some 16, none, none, none, none, none]
private theorem e89_87 : Edge c89 c87 m89_87 := by constructor <;> decide
theorem floor89 : Floor c89 3 := by
  have up := refundEdge e89_87 floor87 34816 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c90 : Chart := ⟨[16640, 33024, 33280, 66048],[768, 16896, 65792, 114688]⟩
def m90_82 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e90_82 : Edge c90 c82 m90_82 := by constructor <;> decide
theorem floor90 : Floor c90 3 := by
  have up := refundEdge e90_82 floor82 16640 768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c91 : Chart := ⟨[16640, 17408, 33024, 66560],[256, 1280, 33792, 65792, 114688]⟩
def m91_57 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e91_57 : Edge c91 c57 m91_57 := by constructor <;> decide
theorem floor91 : Floor c91 3 := by
  have up := refundEdge e91_57 floor57 33024 256 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c92 : Chart := ⟨[17408, 33280, 66048, 66560],[1536, 16896, 33792, 114688]⟩
def m92_83 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e92_83 : Edge c92 c83 m92_83 := by constructor <;> decide
theorem floor92 : Floor c92 3 := by
  have up := refundEdge e92_83 floor83 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c93 : Chart := ⟨[16640, 17408, 33024, 33280, 66048, 66560],[1792, 16896, 33792, 65792, 114688]⟩
def m93_92 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e93_92 : Edge c93 c92 m93_92 := by constructor <;> decide
def m93_91 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e93_91 : Edge c93 c91 m93_91 := by constructor <;> decide
def m93_90 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e93_90 : Edge c93 c90 m93_90 := by constructor <;> decide
def m93_84 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e93_84 : Edge c93 c84 m93_84 := by constructor <;> decide
def m93_60 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e93_60 : Edge c93 c60 m93_60 := by constructor <;> decide
def m93_24 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e93_24 : Edge c93 c24 m93_24 := by constructor <;> decide
theorem floor93 : Floor c93 5 := by
  apply protectedBranch source c93.P c93.N (decode 116480) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 116480, q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 14 ∨ q = 15 ∨ q = 16 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e93_92 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor92 k x net fit)
    · refine ⟨_,goodChild e93_91 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor91 k x net fit)
    · refine ⟨_,goodChild e93_90 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor90 k x net fit)
    · refine ⟨_,goodChild e93_84 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor84 k x net fit)
    · refine ⟨_,goodChild e93_60 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor60 k x net fit)
    · refine ⟨_,goodChild e93_24 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor24 k x net fit)
  · exact pairExcluded 116480 116480 [16640, 17408, 33024, 33280, 66048, 66560] [1792, 16896, 33792, 65792, 114688] validBranch116480 (by decide) (by decide) (by decide)
def c94 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 66048, 66560],[896, 1664, 1792, 16896, 33920, 65920, 98432, 114688]⟩
def m94_93 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e94_93 : Edge c94 c93 m94_93 := by constructor <;> decide
theorem floor94 : Floor c94 6 := by
  have up := refundEdge e94_93 floor93 16512 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c95 : Chart := ⟨[17408, 33280, 34816, 66048, 66560],[3584, 18944, 33792, 83968, 114688]⟩
def m95_92 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e95_92 : Edge c95 c92 m95_92 := by constructor <;> decide
theorem floor95 : Floor c95 4 := by
  have up := refundEdge e95_92 floor92 34816 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)

end TightRow.Protected.Numeric
