import NumericEdgeHints
import NumericGraph030Part00
import Branch257984
import NumericGraph009
import NumericGraph021
import NumericGraph024
import NumericGraph027
import NumericGraph028
import NumericGraph029
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c363 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120],[1856, 3712, 11520, 19008, 33984, 41984, 68032, 76032, 84032, 92160, 98496, 114752, 131968, 147968, 188416, 196992, 205056, 229504]⟩
def m363_362 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e363_362 : Edge c363 c362 m363_362 := by
  exact edgeByPairs c363 c362 m363_362 [(8320,8320), (8704,8704), (16512,16512), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (132096,132096), (133120,133120)] [(1792,1856), (3712,3712), (9472,11520), (11520,11520), (18944,19008), (33920,33984), (41984,41984), (67968,68032), (76032,76032), (92160,92160), (114688,114752), (131968,131968), (147968,147968), (188416,188416), (196992,196992), (205056,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_360 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e363_360 : Edge c363 c360 m363_360 := by
  exact edgeByPairs c363 c360 m363_360 [(8256,8256), (8704,8704), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (131136,131136), (132096,132096), (133120,133120)] [(1856,1856), (3584,3712), (9472,11520), (11520,11520), (19008,19008), (33856,33984), (41984,41984), (67904,68032), (76032,76032), (84032,84032), (92160,92160), (114752,114752), (131840,131968), (147968,147968), (188416,188416), (205056,205056), (229376,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_356 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e363_356 : Edge c363 c356 m363_356 := by
  exact edgeByPairs c363 c356 m363_356 [(8256,8256), (8320,8320), (8704,8704), (16512,16512), (17408,17408), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (131136,131136), (132096,132096), (133120,133120)] [(1600,1856), (3712,3712), (9216,11520), (11264,11520), (19008,19008), (33984,33984), (41984,41984), (67776,68032), (84032,84032), (92160,92160), (98496,98496), (114752,114752), (131712,131968), (147968,147968), (188416,188416), (204800,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_352 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e363_352 : Edge c363 c352 m363_352 := by
  exact edgeByPairs c363 c352 m363_352 [(8256,8256), (8320,8320), (16512,16512), (16640,16640), (17408,17408), (33024,33024), (34816,34816), (66560,66560), (131136,131136), (132096,132096), (133120,133120)] [(1152,3712), (1344,1856), (3200,3712), (11520,11520), (33984,33984), (41984,41984), (68032,68032), (76032,76032), (84032,84032), (92160,92160), (98496,98496), (114752,114752), (188416,188416), (196992,196992), (205056,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_351 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e363_351 : Edge c363 c351 m363_351 := by
  exact edgeByPairs c363 c351 m363_351 [(8256,8256), (8320,8320), (8704,8704), (16512,16512), (16640,16640), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (131136,131136), (133120,133120)] [(640,3712), (832,1856), (2688,3712), (19008,19008), (68032,68032), (76032,76032), (84032,84032), (92160,92160), (98496,98496), (114752,114752), (131968,131968), (147968,147968), (188416,188416), (196992,196992), (205056,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_349 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e363_349 : Edge c363 c349 m363_349 := by
  exact edgeByPairs c363 c349 m363_349 [(8256,8256), (8320,8320), (8704,8704), (16512,16512), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (66048,66048), (66560,66560), (131136,131136), (132096,132096)] [(1664,3712), (1856,1856), (9472,11520), (16960,19008), (33984,33984), (41984,41984), (65984,68032), (90112,92160), (98496,98496), (114752,114752), (131968,131968), (147968,147968), (188416,188416), (196992,196992), (205056,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_339 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e363_339 : Edge c363 c339 m363_339 := by
  exact edgeByPairs c363 c339 m363_339 [(16512,16512), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (131136,131136), (132096,132096), (133120,133120)] [(1856,1856), (3328,11520), (3712,3712), (19008,19008), (33984,33984), (68032,68032), (84032,84032), (98496,98496), (114752,114752), (131456,131968), (131968,131968), (147968,147968), (180224,188416), (196992,196992), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_327 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e363_327 : Edge c363 c327 m363_327 := by
  exact edgeByPairs c363 c327 m363_327 [(8256,8256), (8320,8320), (8704,8704), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (131136,131136), (132096,132096), (133120,133120)] [(1856,1856), (2624,19008), (3712,3712), (9472,11520), (11520,11520), (33984,33984), (41984,41984), (68032,68032), (76032,76032), (98496,98496), (131968,131968), (172032,188416), (196992,196992), (205056,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_291 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e363_291 : Edge c363 c291 m363_291 := by
  exact edgeByPairs c363 c291 m363_291 [(8256,8256), (8320,8320), (8704,8704), (16512,16512), (16640,16640), (17408,17408), (66048,66048), (66560,66560), (131136,131136), (132096,132096), (133120,133120)] [(1216,33984), (1856,1856), (3712,3712), (11520,11520), (18944,19008), (19008,19008), (68032,68032), (76032,76032), (84032,84032), (92160,92160), (131968,131968), (147968,147968), (155648,188416), (196992,196992), (205056,205056)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_253 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e363_253 : Edge c363 c253 m363_253 := by
  exact edgeByPairs c363 c253 m363_253 [(8256,8256), (8320,8320), (8704,8704), (16512,16512), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (34816,34816), (131136,131136), (132096,132096), (133120,133120)] [(1856,1856), (2496,68032), (3712,3712), (9472,11520), (11520,11520), (19008,19008), (26624,92160), (33984,33984), (41984,41984), (49216,114752), (131968,131968), (139520,205056), (147968,147968), (163968,229504), (188416,188416)] rfl rfl (by decide) (by decide) (by decide) (by decide)
def m363_114 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e363_114 : Edge c363 c114 m363_114 := by
  exact edgeByPairs c363 c114 m363_114 [(8256,8256), (8320,8320), (8704,8704), (16512,16512), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (66560,66560)] [(896,131968), (1856,1856), (3712,3712), (9472,11520), (11520,11520), (19008,19008), (33984,33984), (41984,41984), (57344,188416), (68032,68032), (76032,76032), (84032,84032), (92160,92160), (98496,98496), (114752,114752)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor363 : Floor c363 12 := by
  apply protectedBranch source c363.P c363.N (decode 257984) 12
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 257984, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e363_362 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor362 k x net fit)
    · refine ⟨_,goodChild e363_360 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor360 k x net fit)
    · refine ⟨_,goodChild e363_356 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor356 k x net fit)
    · refine ⟨_,goodChild e363_352 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor352 k x net fit)
    · refine ⟨_,goodChild e363_351 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor351 k x net fit)
    · refine ⟨_,goodChild e363_349 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor349 k x net fit)
    · refine ⟨_,goodChild e363_339 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor339 k x net fit)
    · refine ⟨_,goodChild e363_327 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor327 k x net fit)
    · refine ⟨_,goodChild e363_291 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor291 k x net fit)
    · refine ⟨_,goodChild e363_253 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor253 k x net fit)
    · refine ⟨_,goodChild e363_114 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 12-2 ≤ 10).trans (floor114 k x net fit)
  · exact pairExcluded 257984 257984 [8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120] [1856, 3712, 11520, 19008, 33984, 41984, 68032, 76032, 84032, 92160, 98496, 114752, 131968, 147968, 188416, 196992, 205056, 229504] validBranch257984 (by decide) (by decide) (by decide)
def c364 : Chart := ⟨[2105408, 8704, 16640, 17408, 33024, 33280, 66048, 66560, 2166784, 2228288, 132096],[2099008, 2102080, 2102592, 2110720, 2118208, 2135104, 2143232, 2150464, 2163008, 90112, 2211904, 2233088, 2240768, 2249216, 2289664, 205056, 229376]⟩
def m364_347 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, none, none, none, some 6]
private theorem e364_347 : Edge c364 c347 m364_347 := by
  exact edgeByPairs c364 c347 m364_347 [(8256,2105408), (8704,8704), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (66048,66048), (66560,66560), (131136,2228288), (132096,132096)] [(1856,2099008), (9472,2110720), (16960,2118208), (33856,2135104), (41984,2143232), (65856,2163008), (90112,90112), (114752,2211904), (131840,2233088), (147968,2249216), (188416,2289664), (205056,205056), (229376,229376)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor364 : Floor c364 10 := by
  have up := refundEdge e364_347 floor347 2166784 2163008 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c365 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632, 132096],[1664, 1792, 13568, 38016, 46080, 65920, 90112, 114688, 136064, 143616, 152064, 168064, 192512, 196992, 205056, 229504]⟩
def m365_348 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e365_348 : Edge c365 c348 m365_348 := by
  exact edgeByPairs c365 c348 m365_348 [(8320,8320), (8704,8704), (16512,16512), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (66048,66048), (66560,66560), (132096,132096)] [(1664,1664), (1792,1792), (9472,13568), (33920,38016), (41984,46080), (90112,90112), (114688,114688), (131968,136064), (147968,152064), (188416,192512), (196992,196992), (205056,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor365 : Floor c365 10 := by
  have up := refundEdge e365_348 floor348 69632 65920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)

end TightRow.Protected.Numeric
