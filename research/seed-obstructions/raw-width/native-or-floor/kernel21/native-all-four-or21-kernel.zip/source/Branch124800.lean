import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short124800
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560]
def n : List Nat := [896, 1664, 1792, 9472, 16896, 33920, 41984, 57344, 65920, 73984, 90112, 98432, 114688]
def pp := p.map (canonical 124800)
def nn := n.map (canonical 124800)
def parts : List Nat := [0, 128, 256, 1024, 8192, 32768, 65536, 8320, 33024, 66560]
def g : ShortGrid := [(0,[(128,262022749906830042906359753189307640185601), (256,67251710918989915506339926354772884430455809), (1024,89552796405079835674245394161536949733819393), (8192,1227834020806430640046081), (8320,256), (32768,111505427430449600840755173054626757156864001), (33024,12952273664), (65536,156107598402629441175357164401514709902622721), (66560,17247241216)]), (128,[(256,21558919168), (1024,34494152704), (8192,3298534883328), (32768,21475033088), (33024,21475033088), (65536,30064967680), (66560,30064967680)]), (256,[(1024,34494285056), (8192,1413971953319936), (8320,256), (32768,1412893916529920), (65536,30065100032), (66560,263168)]), (1024,[(8192,1133596488237056), (8320,256), (32768,1133596488238336), (33024,262912), (65536,2260625988257792)]), (8192,[(32768,21525168128), (33024,21525168128), (65536,34410070016), (66560,34410070016)]), (8320,[(32768,256), (33024,256), (65536,256), (66560,256)]), (32768,[(65536,34443625728), (66560,263168)]), (33024,[(65536,262912), (66560,262912)])]
private theorem row0 : parts.all (shortPair g pp nn 107904 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 107904 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 107904 256) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 107904 1024) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 107904 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 107904 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 107904 65536) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 107904 8320) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 107904 33024) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 107904 66560) = true := by decide
theorem full : checkArms 124800 107904 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 256, 1024, 8192, 32768, 65536, 8320, 33024, 66560] : List Nat).all (fun i => parts.all (shortPair g pp nn 107904 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short124800
theorem validBranch124800 : checkArms 124800 107904 [8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560] [896, 1664, 1792, 9472, 16896, 33920, 41984, 57344, 65920, 73984, 90112, 98432, 114688] = true := Short124800.full
end TightRow.Protected.Numeric
