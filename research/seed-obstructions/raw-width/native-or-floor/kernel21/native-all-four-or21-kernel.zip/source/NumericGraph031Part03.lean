import NumericEdgeHints
import NumericGraph031Part02
import NumericGraph029
import NumericGraph030
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c378 : Chart := ⟨[8196, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120],[1796, 3332, 3588, 7172, 9472, 15616, 23044, 30720, 37892, 46080, 67844, 76032, 83972, 92160, 114692, 131844, 135936, 143616, 152068, 184324, 192512, 196868, 205056, 229380]⟩
def m378_377 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e378_377 : Edge c378 c377 m378_377 := by
  exact edgeByPairs c378 c377 m378_377 [(8704,8704), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (69632,69632), (132096,132096), (133120,133120)] [(1792,1796), (3584,3588), (15616,15616), (23040,23044), (30720,30720), (46080,46080), (65792,67844), (76032,76032), (92160,92160), (114688,114692), (135936,135936), (143616,143616), (152064,152068), (192512,192512), (205056,205056), (229376,229380)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor378 : Floor c378 11 := by
  have up := refundEdge e378_377 floor377 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c379 : Chart := ⟨[2105408, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120],[2099008, 3584, 2102080, 2102592, 2103616, 2110464, 2112768, 2120256, 2127872, 2135104, 2143232, 2150464, 2165056, 76032, 2181184, 92160, 2211904, 2233088, 2240768, 2249216, 2289664, 205056, 229376]⟩
def m379_377 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 12]
private theorem e379_377 : Edge c379 c377 m379_377 := by
  exact edgeByPairs c379 c377 m379_377 [(8704,8704), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (69632,2166784), (132096,132096), (133120,133120)] [(1792,2099008), (3584,3584), (15616,2112768), (23040,2120256), (30720,2127872), (46080,2143232), (65792,2165056), (76032,76032), (92160,92160), (114688,2211904), (135936,2233088), (143616,2240768), (152064,2249216), (192512,2289664), (205056,205056), (229376,229376)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor379 : Floor c379 11 := by
  have up := refundEdge e379_377 floor377 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)

end TightRow.Protected.Numeric
