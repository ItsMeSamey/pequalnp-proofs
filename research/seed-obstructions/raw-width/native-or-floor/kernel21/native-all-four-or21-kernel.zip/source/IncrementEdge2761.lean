import IncrementCharts

namespace TightRow.Protected.Numeric.Increment
open TightRow.Deletion TightRow.NativeSeeds
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def m2761_2760 : List (Option Addr) := [some 0, none, some 2, none, none, some 5, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, some 19, some 20, some 21]
theorem e2761_2760 : Edge c2761 c2760 m2761_2760 := by
  exact edgeByCodes c2761 c2760 m2761_2760 157518232896682876067734969266936877023860390065310804345088 4457209397670908121009337458422911124467093816021462700320720581277525273645929527284300498126060304900450153971197690948365995064051639200085610446814724450095592027360959628772293301799035786811857796444713493175945447363699205371774476529782254272334742186754304 (by decide) (by decide) (by decide) (by decide)
theorem lift2761 {d : Nat} (low : Floor c2760 d) : Floor c2761 (d+1) := by
  exact refundEdge e2761_2760 low 32784 1082497 (by decide) (by decide) (by decide)
end TightRow.Protected.Numeric.Increment
