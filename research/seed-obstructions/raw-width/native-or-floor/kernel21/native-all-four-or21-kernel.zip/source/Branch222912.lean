import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short222912
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8320, 8704, 16512, 17408, 66048, 66560, 131136, 132096]
def n : List Nat := [1216, 1600, 1664, 9216, 16960, 65728, 81984, 90112, 131712, 147968, 155648, 196736, 204800]
def pp := p.map (canonical 222912)
def nn := n.map (canonical 222912)
def parts : List Nat := [0, 64, 128, 512, 16384, 65536, 131072, 16512, 66048, 131136]
def g : ShortGrid := [(0,[(64,261340845540116251967642200860516390273793), (128,22562426331630036419873110007624581693637377), (512,44863511817719956587778577814388646997000961), (16384,66903256458269760503716403420576973767049985), (16512,4345495808), (65536,133806512916539521007432806840587690405397249), (66048,8640463360), (131072,156107598402629441175338274647633234980504321), (131136,50528256)]), (64,[(128,1979120930259712), (512,1979120930325760), (16384,7696581395200), (16512,196864), (65536,7696581461248), (66048,197120), (131072,1979150994769664)]), (128,[(512,21558985472), (16384,848835861545728), (65536,25770066688), (66048,197120), (131072,30065033984), (131136,196608)]), (512,[(16384,1413971953320704), (16512,196864), (65536,1412893933307136), (131072,30081877248), (131136,196608)]), (16384,[(65536,21541946112), (66048,197120), (131072,30131880704), (131136,196608)]), (16512,[(65536,196864), (66048,196864), (131072,196864), (131136,196608)]), (65536,[(131072,30148723968), (131136,196608)]), (66048,[(131072,197120), (131136,196608)])]
private theorem row0 : parts.all (shortPair g pp nn 213696 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 213696 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 213696 128) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 213696 512) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 213696 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 213696 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 213696 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 213696 16512) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 213696 66048) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 213696 131136) = true := by decide
theorem full : checkArms 222912 213696 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 128, 512, 16384, 65536, 131072, 16512, 66048, 131136] : List Nat).all (fun i => parts.all (shortPair g pp nn 213696 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short222912
theorem validBranch222912 : checkArms 222912 213696 [8256, 8320, 8704, 16512, 17408, 66048, 66560, 131136, 132096] [1216, 1600, 1664, 9216, 16960, 65728, 81984, 90112, 131712, 147968, 155648, 196736, 204800] = true := Short222912.full
end TightRow.Protected.Numeric
