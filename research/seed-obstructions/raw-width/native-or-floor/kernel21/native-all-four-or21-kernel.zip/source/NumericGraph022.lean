import Branch206400
import NumericGraph004
import NumericGraph010
import NumericGraph021
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c264 : Chart := ⟨[8256, 8704, 66048, 131136],[512, 576, 65600, 131584, 204800]⟩
def m264_126 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e264_126 : Edge c264 c126 m264_126 := by constructor <;> decide
theorem floor264 : Floor c264 3 := by
  have up := refundEdge e264_126 floor126 66048 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c265 : Chart := ⟨[8256, 66560, 131136, 132096],[64, 1088, 9216, 65600, 204800]⟩
def m265_256 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e265_256 : Edge c265 c256 m265_256 := by constructor <;> decide
theorem floor265 : Floor c265 3 := by
  have up := refundEdge e265_256 floor256 8256 64 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c266 : Chart := ⟨[8704, 66048, 66560, 132096],[512, 1536, 9216, 131584, 204800]⟩
def m266_257 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e266_257 : Edge c266 c257 m266_257 := by constructor <;> decide
theorem floor266 : Floor c266 3 := by
  have up := refundEdge e266_257 floor257 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c267 : Chart := ⟨[8196, 8704, 66048, 66560, 132096],[1540, 9216, 131588, 196612, 204800]⟩
def m267_266 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e267_266 : Edge c267 c266 m267_266 := by constructor <;> decide
theorem floor267 : Floor c267 4 := by
  have up := refundEdge e267_266 floor266 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c268 : Chart := ⟨[8196, 8704, 66048, 66560, 131073, 132096],[1541, 9217, 65541, 73729, 131072, 131588, 196612, 204800]⟩
def m268_267 : List (Option Addr) := [none, none, some 2, none, none, none, none, none, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e268_267 : Edge c268 c267 m268_267 := by constructor <;> decide
theorem floor268 : Floor c268 5 := by
  have up := refundEdge e268_267 floor267 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c269 : Chart := ⟨[8256, 8704, 66048, 66560, 131136, 132096],[1600, 9216, 65600, 131584, 204800]⟩
def m269_266 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e269_266 : Edge c269 c266 m269_266 := by constructor <;> decide
def m269_265 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e269_265 : Edge c269 c265 m269_265 := by constructor <;> decide
def m269_264 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e269_264 : Edge c269 c264 m269_264 := by constructor <;> decide
def m269_258 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e269_258 : Edge c269 c258 m269_258 := by constructor <;> decide
def m269_129 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e269_129 : Edge c269 c129 m269_129 := by constructor <;> decide
def m269_50 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, none, some 16, none, none, none, none, none]
private theorem e269_50 : Edge c269 c50 m269_50 := by constructor <;> decide
theorem floor269 : Floor c269 5 := by
  apply protectedBranch source c269.P c269.N (decode 206400) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 206400, q = 6 ∨ q = 9 ∨ q = 10 ∨ q = 13 ∨ q = 16 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e269_266 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor266 k x net fit)
    · refine ⟨_,goodChild e269_265 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor265 k x net fit)
    · refine ⟨_,goodChild e269_264 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor264 k x net fit)
    · refine ⟨_,goodChild e269_258 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor258 k x net fit)
    · refine ⟨_,goodChild e269_129 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor129 k x net fit)
    · refine ⟨_,goodChild e269_50 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor50 k x net fit)
  · exact pairExcluded 206400 206400 [8256, 8704, 66048, 66560, 131136, 132096] [1600, 9216, 65600, 131584, 204800] validBranch206400 (by decide) (by decide) (by decide)
def c270 : Chart := ⟨[8196, 8256, 8704, 66048, 66560, 131136, 132096],[1092, 1540, 1600, 9216, 65604, 131588, 196612, 204800]⟩
def m270_269 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e270_269 : Edge c270 c269 m270_269 := by constructor <;> decide
theorem floor270 : Floor c270 6 := by
  have up := refundEdge e270_269 floor269 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c271 : Chart := ⟨[8256, 8320, 8704, 66048, 66560, 131136, 132096],[1216, 1600, 1664, 9216, 65728, 131712, 196736, 204800]⟩
def m271_269 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e271_269 : Edge c271 c269 m271_269 := by constructor <;> decide
theorem floor271 : Floor c271 6 := by
  have up := refundEdge e271_269 floor269 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c272 : Chart := ⟨[8704, 66048, 66560, 132096, 133120],[3584, 11264, 75776, 131072, 131584, 204800]⟩
def m272_266 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e272_266 : Edge c272 c266 m272_266 := by constructor <;> decide
theorem floor272 : Floor c272 4 := by
  have up := refundEdge e272_266 floor266 133120 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c273 : Chart := ⟨[8256, 8704, 66048, 66560, 131136, 132096, 133120],[1600, 2624, 3584, 11264, 67648, 75776, 131072, 131584, 204800]⟩
def m273_269 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e273_269 : Edge c273 c269 m273_269 := by constructor <;> decide
theorem floor273 : Floor c273 6 := by
  have up := refundEdge e273_269 floor269 133120 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c274 : Chart := ⟨[8320, 8704, 66048, 66560, 132096, 133120],[3712, 9216, 11264, 67712, 75776, 131712, 196736, 204800]⟩
def m274_272 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e274_272 : Edge c274 c272 m274_272 := by constructor <;> decide
theorem floor274 : Floor c274 5 := by
  have up := refundEdge e274_272 floor272 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c275 : Chart := ⟨[8256, 8320, 8704, 66048, 66560, 131136, 132096, 133120],[1216, 1600, 2624, 3712, 9216, 11264, 67776, 75776, 131712, 196736, 204800]⟩
def m275_273 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e275_273 : Edge c275 c273 m275_273 := by constructor <;> decide
theorem floor275 : Floor c275 7 := by
  have up := refundEdge e275_273 floor273 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)

end TightRow.Protected.Numeric
