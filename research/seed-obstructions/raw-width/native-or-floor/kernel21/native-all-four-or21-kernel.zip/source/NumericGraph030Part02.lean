import NumericEdgeHints
import NumericGraph030Part01
import Branch257984
import NumericGraph009
import NumericGraph021
import NumericGraph024
import NumericGraph027
import NumericGraph028
import NumericGraph029
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c366 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 2166784, 2228288, 132096],[1664, 2099008, 2101696, 2102080, 2102592, 2110464, 2110720, 2118208, 2135232, 2143232, 2150464, 2163136, 90112, 2195648, 2211904, 2233216, 2240768, 2249216, 2265216, 2289664, 196992, 205056, 229504]⟩
def m366_365 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 12]
private theorem e366_365 : Edge c366 c365 m366_365 := by
  exact edgeByPairs c366 c365 m366_365 [(8320,8320), (8704,8704), (16512,16512), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (66048,66048), (66560,66560), (69632,2166784), (132096,132096)] [(1664,1664), (1792,2099008), (13568,2110720), (38016,2135232), (46080,2143232), (65920,2163136), (90112,90112), (114688,2211904), (136064,2233216), (143616,2240768), (152064,2249216), (168064,2265216), (192512,2289664), (196992,196992), (205056,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor366 : Floor c366 11 := by
  have up := refundEdge e366_365 floor365 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c367 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 2166784, 2228288, 133120],[2688, 2101696, 2102080, 2103616, 2111744, 2120256, 2127872, 2134208, 2150464, 2163136, 2165184, 76032, 2181184, 92160, 2195648, 2211904, 2233216, 2240768, 2249216, 2265216, 2289664, 196992, 205056, 229504]⟩
def m367_351 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, some 6]
private theorem e367_351 : Edge c367 c351 m367_351 := by
  exact edgeByPairs c367 c351 m367_351 [(8256,2105408), (8320,8320), (8704,8704), (16512,16512), (16640,16640), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (131136,2228288), (133120,133120)] [(640,2688), (832,2102080), (2688,2688), (19008,2120256), (68032,2165184), (76032,76032), (84032,2181184), (92160,92160), (98496,2195648), (114752,2211904), (131968,2233216), (147968,2249216), (188416,2289664), (196992,196992), (205056,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor367 : Floor c367 11 := by
  have up := refundEdge e367_351 floor351 2166784 2163136 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c368 : Chart := ⟨[8196, 2105408, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 2166784, 2228288, 133120],[2688, 2101696, 2102080, 2103616, 8448, 2111744, 2119748, 2120196, 2120256, 2127872, 2134208, 2150468, 2165060, 67972, 2165184, 76032, 2181188, 92160, 2195648, 2211908, 131844, 2233216, 2240768, 2249220, 2265220, 2281476, 2289664, 196996, 205056, 229508]⟩
def m368_367 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 21]
private theorem e368_367 : Edge c368 c367 m368_367 := by
  exact edgeByPairs c368 c367 m368_367 [(2105408,2105408), (8320,8320), (8704,8704), (16512,16512), (16640,16640), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (2166784,2166784), (2228288,2228288), (133120,133120)] [(2688,2688), (2101696,2101696), (2102080,2102080), (2103616,2103616), (2111744,2111744), (2120256,2120256), (2127872,2127872), (2134208,2134208), (2150464,2150468), (2163136,2165184), (2165184,2165184), (76032,76032), (2181184,2181188), (92160,92160), (2195648,2195648), (2211904,2211908), (2233216,2233216), (2240768,2240768), (2249216,2249220), (2265216,2265220), (2289664,2289664), (196992,196996), (205056,205056), (229504,229508)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor368 : Floor c368 12 := by
  have up := refundEdge e368_367 floor367 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 12 ≤ 12).trans (up k x net fit)

end TightRow.Protected.Numeric
