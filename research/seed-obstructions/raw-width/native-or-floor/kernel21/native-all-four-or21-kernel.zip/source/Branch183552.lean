import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short183552
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16640, 17408, 33024, 34816, 132096, 133120]
def n : List Nat := [3328, 18432, 33792, 131328, 180224]
def pp := p.map (canonical 183552)
def nn := n.map (canonical 183552)
def parts : List Nat := [0, 256, 1024, 2048, 16384, 32768, 131072, 16640, 17408, 33024, 34816, 132096, 133120]
def g : ShortGrid := [(0,[(256,309489732259886631936327937), (1024,79538861190790864407636279553), (2048,238307093840112706590972510721), (16384,1), (16640,256), (17408,0), (32768,158458742917061955551399903233), (33024,8590000128), (34816,8589935104), (131072,316917485834123911102799806465), (132096,17179934976), (133120,17180001024)]), (256,[(1024,17230266368), (2048,21525233664), (16384,1099511627776), (17408,0), (32768,8590000128), (34816,8590000128), (131072,17179934720), (132096,17179934720), (133120,17179934720)]), (1024,[(2048,12918522112), (16384,282574488338432), (16640,256), (32768,8590000384), (33024,65536), (34816,8590000384), (131072,17179934976), (133120,17179934976)]), (2048,[(16384,848822976643072), (16640,256), (17408,0), (32768,846623953388032), (33024,65536), (131072,17180001024), (132096,65792)]), (16384,[(32768,12901679104), (33024,16777216), (34816,12901679104), (131072,21491613696), (132096,4311744512), (133120,21491613696)]), (16640,[(32768,256), (34816,256), (131072,256), (132096,256), (133120,256)]), (17408,[(32768,0), (33024,0), (34816,0), (131072,0), (133120,0)]), (32768,[(131072,17213424128), (132096,65792), (133120,12918456832)]), (33024,[(131072,65536), (132096,65536), (133120,65536)]), (34816,[(131072,512), (132096,65792)])]
private theorem row0 : parts.all (shortPair g pp nn 183552 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 183552 256) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 183552 1024) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 183552 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 183552 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 183552 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 183552 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 183552 16640) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 183552 17408) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 183552 33024) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 183552 34816) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 183552 132096) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 183552 133120) = true := by decide
theorem full : checkArms 183552 183552 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 256, 1024, 2048, 16384, 32768, 131072, 16640, 17408, 33024, 34816, 132096, 133120] : List Nat).all (fun i => parts.all (shortPair g pp nn 183552 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short183552
theorem validBranch183552 : checkArms 183552 183552 [16640, 17408, 33024, 34816, 132096, 133120] [3328, 18432, 33792, 131328, 180224] = true := Short183552.full
end TightRow.Protected.Numeric
