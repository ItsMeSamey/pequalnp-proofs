import Branch156864
import NumericGraph000
import NumericGraph010
import NumericGraph011
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c144 : Chart := ⟨[8256, 17408, 131136, 132096],[64, 1088, 9216, 16448, 155648]⟩
def m144_134 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e144_134 : Edge c144 c134 m144_134 := by constructor <;> decide
theorem floor144 : Floor c144 3 := by
  have up := refundEdge e144_134 floor134 8256 64 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c145 : Chart := ⟨[8320, 16512, 17408, 132096],[128, 1152, 9216, 131200, 155648]⟩
def m145_135 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e145_135 : Edge c145 c135 m145_135 := by constructor <;> decide
theorem floor145 : Floor c145 3 := by
  have up := refundEdge e145_135 floor135 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c146 : Chart := ⟨[8256, 8320, 16512, 17408, 131136, 132096],[1216, 9216, 16448, 131200, 155648]⟩
def m146_145 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e146_145 : Edge c146 c145 m146_145 := by constructor <;> decide
def m146_144 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e146_144 : Edge c146 c144 m146_144 := by constructor <;> decide
def m146_142 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e146_142 : Edge c146 c142 m146_142 := by constructor <;> decide
def m146_136 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e146_136 : Edge c146 c136 m146_136 := by constructor <;> decide
def m146_128 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e146_128 : Edge c146 c128 m146_128 := by constructor <;> decide
def m146_7 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e146_7 : Edge c146 c7 m146_7 := by constructor <;> decide
theorem floor146 : Floor c146 5 := by
  apply protectedBranch source c146.P c146.N (decode 156864) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 156864, q = 6 ∨ q = 7 ∨ q = 10 ∨ q = 13 ∨ q = 14 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e146_145 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor145 k x net fit)
    · refine ⟨_,goodChild e146_144 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor144 k x net fit)
    · refine ⟨_,goodChild e146_142 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor142 k x net fit)
    · refine ⟨_,goodChild e146_136 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor136 k x net fit)
    · refine ⟨_,goodChild e146_128 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor128 k x net fit)
    · refine ⟨_,goodChild e146_7 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor7 k x net fit)
  · exact pairExcluded 156864 156864 [8256, 8320, 16512, 17408, 131136, 132096] [1216, 9216, 16448, 131200, 155648] validBranch156864 (by decide) (by decide) (by decide)
def c147 : Chart := ⟨[8196, 8256, 8320, 16512, 17408, 131136, 132096],[1092, 1156, 1216, 9216, 16452, 131204, 147460, 155648]⟩
def m147_146 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e147_146 : Edge c147 c146 m147_146 := by constructor <;> decide
theorem floor147 : Floor c147 6 := by
  have up := refundEdge e147_146 floor146 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c148 : Chart := ⟨[8256, 16640, 17408, 131136, 132096],[1344, 9472, 16384, 16448, 139520, 155648]⟩
def m148_144 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e148_144 : Edge c148 c144 m148_144 := by constructor <;> decide
theorem floor148 : Floor c148 4 := by
  have up := refundEdge e148_144 floor144 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c149 : Chart := ⟨[8196, 8256, 16640, 17408, 131136, 132096],[1348, 9472, 16452, 131332, 139520, 147460, 155648]⟩
def m149_148 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e149_148 : Edge c149 c148 m149_148 := by constructor <;> decide
theorem floor149 : Floor c149 5 := by
  have up := refundEdge e149_148 floor148 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c150 : Chart := ⟨[8256, 8320, 16512, 16640, 17408, 131136, 132096],[448, 1216, 1344, 9472, 16384, 16448, 131456, 139520, 155648]⟩
def m150_146 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e150_146 : Edge c150 c146 m150_146 := by constructor <;> decide
theorem floor150 : Floor c150 6 := by
  have up := refundEdge e150_146 floor146 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c151 : Chart := ⟨[8196, 8256, 8320, 16512, 16640, 17408, 131136, 132096],[448, 1156, 1216, 1348, 9472, 16452, 131460, 139520, 147460, 155648]⟩
def m151_150 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e151_150 : Edge c151 c150 m151_150 := by constructor <;> decide
theorem floor151 : Floor c151 7 := by
  have up := refundEdge e151_150 floor150 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c152 : Chart := ⟨[8256, 8704, 17408, 131136, 132096],[1600, 9216, 16960, 147968, 155648]⟩
def m152_144 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e152_144 : Edge c152 c144 m152_144 := by constructor <;> decide
theorem floor152 : Floor c152 4 := by
  have up := refundEdge e152_144 floor144 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c153 : Chart := ⟨[8320, 8704, 16512, 17408, 132096],[1664, 9216, 131712, 147968, 155648]⟩
def m153_145 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e153_145 : Edge c153 c145 m153_145 := by constructor <;> decide
theorem floor153 : Floor c153 4 := by
  have up := refundEdge e153_145 floor145 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c154 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 131136, 132096],[1216, 1600, 1664, 9216, 16960, 131712, 147968, 155648]⟩
def m154_146 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e154_146 : Edge c154 c146 m154_146 := by constructor <;> decide
theorem floor154 : Floor c154 6 := by
  have up := refundEdge e154_146 floor146 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c155 : Chart := ⟨[8256, 8704, 16640, 17408, 131136, 132096],[1856, 9472, 16896, 16960, 131840, 139520, 147968, 155648]⟩
def m155_152 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e155_152 : Edge c155 c152 m155_152 := by constructor <;> decide
theorem floor155 : Floor c155 5 := by
  have up := refundEdge e155_152 floor152 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)

end TightRow.Protected.Numeric
