import NumericGraph009
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c120 : Chart := ⟨[132096],[1024, 131072]⟩
theorem floor120 : Floor c120 0 := fun _ _ _ _ => Nat.zero_le _
def c121 : Chart := ⟨[133120],[2048, 131072]⟩
theorem floor121 : Floor c121 0 := fun _ _ _ _ => Nat.zero_le _
def c122 : Chart := ⟨[8256, 131136],[64, 139264]⟩
def m122_119 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, none, none, none, none, none, none, some 17, none, none, none, none]
private theorem e122_119 : Edge c122 c119 m122_119 := by constructor <;> decide
theorem floor122 : Floor c122 1 := by
  have up := refundEdge e122_119 floor119 8256 64 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c123 : Chart := ⟨[8196, 8256, 131136],[68, 8192, 131076, 139264]⟩
def m123_122 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e123_122 : Edge c123 c122 m123_122 := by constructor <;> decide
theorem floor123 : Floor c123 2 := by
  have up := refundEdge e123_122 floor122 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c124 : Chart := ⟨[8196, 8256, 131073, 131136],[69, 8193, 131072, 131076, 139264]⟩
def m124_123 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, none, none, none, none, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e124_123 : Edge c124 c123 m124_123 := by constructor <;> decide
theorem floor124 : Floor c124 3 := by
  have up := refundEdge e124_123 floor123 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c125 : Chart := ⟨[8256, 8320, 131136],[192, 8192, 131200, 139264]⟩
def m125_122 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e125_122 : Edge c125 c122 m125_122 := by constructor <;> decide
theorem floor125 : Floor c125 2 := by
  have up := refundEdge e125_122 floor122 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c126 : Chart := ⟨[8256, 8704, 131136],[576, 8192, 131584, 139264]⟩
def m126_122 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e126_122 : Edge c126 c122 m126_122 := by constructor <;> decide
theorem floor126 : Floor c126 2 := by
  have up := refundEdge e126_122 floor122 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c127 : Chart := ⟨[8256, 131136, 132096],[1088, 9216, 131072, 139264]⟩
def m127_122 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e127_122 : Edge c127 c122 m127_122 := by constructor <;> decide
theorem floor127 : Floor c127 2 := by
  have up := refundEdge e127_122 floor122 132096 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c128 : Chart := ⟨[8256, 8320, 131136, 132096],[1216, 9216, 131200, 139264]⟩
def m128_127 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e128_127 : Edge c128 c127 m128_127 := by constructor <;> decide
theorem floor128 : Floor c128 3 := by
  have up := refundEdge e128_127 floor127 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c129 : Chart := ⟨[8256, 8704, 131136, 132096],[1600, 9216, 131584, 139264]⟩
def m129_127 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e129_127 : Edge c129 c127 m129_127 := by constructor <;> decide
theorem floor129 : Floor c129 3 := by
  have up := refundEdge e129_127 floor127 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c130 : Chart := ⟨[8256, 131136, 133120],[2112, 10240, 131072, 139264]⟩
def m130_122 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e130_122 : Edge c130 c122 m130_122 := by constructor <;> decide
theorem floor130 : Floor c130 2 := by
  have up := refundEdge e130_122 floor122 133120 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c131 : Chart := ⟨[8256, 8320, 131136, 133120],[2240, 8192, 10240, 131200, 139264]⟩
def m131_130 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e131_130 : Edge c131 c130 m131_130 := by constructor <;> decide
theorem floor131 : Floor c131 3 := by
  have up := refundEdge e131_130 floor130 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)

end TightRow.Protected.Numeric
