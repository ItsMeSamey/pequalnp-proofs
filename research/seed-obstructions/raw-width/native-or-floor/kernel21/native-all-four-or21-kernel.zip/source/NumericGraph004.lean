import NumericGraph003
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c48 : Chart := ⟨[8320, 8704, 66048],[640, 8192, 65664, 73728]⟩
def m48_47 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, some 13, none, none, some 16, none, none, none, none, none]
private theorem e48_47 : Edge c48 c47 m48_47 := by constructor <;> decide
theorem floor48 : Floor c48 2 := by
  have up := refundEdge e48_47 floor47 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c49 : Chart := ⟨[8704, 66048, 66560],[1536, 9216, 65536, 73728]⟩
def m49_47 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, some 13, none, none, some 16, none, none, none, none, none]
private theorem e49_47 : Edge c49 c47 m49_47 := by constructor <;> decide
theorem floor49 : Floor c49 2 := by
  have up := refundEdge e49_47 floor47 66560 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c50 : Chart := ⟨[8256, 8704, 66048, 66560],[1600, 9216, 65600, 73728]⟩
def m50_49 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, some 13, none, none, some 16, none, none, none, none, none]
private theorem e50_49 : Edge c50 c49 m50_49 := by constructor <;> decide
theorem floor50 : Floor c50 3 := by
  have up := refundEdge e50_49 floor49 8256 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c51 : Chart := ⟨[8320, 8704, 66048, 66560],[1664, 9216, 65664, 73728]⟩
def m51_49 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, some 13, none, none, some 16, none, none, none, none, none]
private theorem e51_49 : Edge c51 c49 m51_49 := by constructor <;> decide
theorem floor51 : Floor c51 3 := by
  have up := refundEdge e51_49 floor49 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c52 : Chart := ⟨[8704, 66048, 69632],[4608, 12288, 65536, 73728]⟩
def m52_47 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, some 13, none, none, some 16, none, none, none, none, none]
private theorem e52_47 : Edge c52 c47 m52_47 := by constructor <;> decide
theorem floor52 : Floor c52 2 := by
  have up := refundEdge e52_47 floor47 69632 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c53 : Chart := ⟨[8196, 8704, 66048, 69632],[4612, 8192, 12288, 65540, 73728]⟩
def m53_52 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, some 13, none, none, some 16, none, none, none, none, none]
private theorem e53_52 : Edge c53 c52 m53_52 := by constructor <;> decide
theorem floor53 : Floor c53 3 := by
  have up := refundEdge e53_52 floor52 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c54 : Chart := ⟨[8320, 8704, 66048, 69632],[4736, 8192, 12288, 65664, 73728]⟩
def m54_52 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, some 12, some 13, none, none, some 16, none, none, none, none, none]
private theorem e54_52 : Edge c54 c52 m54_52 := by constructor <;> decide
theorem floor54 : Floor c54 3 := by
  have up := refundEdge e54_52 floor52 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c55 : Chart := ⟨[17408, 66560],[1024, 81920]⟩
def m55_46 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, none, none, some 16, none, none, none, none, none]
private theorem e55_46 : Edge c55 c46 m55_46 := by constructor <;> decide
theorem floor55 : Floor c55 1 := by
  have up := refundEdge e55_46 floor46 17408 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c56 : Chart := ⟨[16512, 17408, 66560],[1152, 16384, 65664, 81920]⟩
def m56_55 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e56_55 : Edge c56 c55 m56_55 := by constructor <;> decide
theorem floor56 : Floor c56 2 := by
  have up := refundEdge e56_55 floor55 16512 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c57 : Chart := ⟨[16640, 17408, 66560],[1280, 16384, 65792, 81920]⟩
def m57_55 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e57_55 : Edge c57 c55 m57_55 := by constructor <;> decide
theorem floor57 : Floor c57 2 := by
  have up := refundEdge e57_55 floor55 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c58 : Chart := ⟨[17408, 66048, 66560],[1536, 16896, 65536, 81920]⟩
def m58_55 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e58_55 : Edge c58 c55 m58_55 := by constructor <;> decide
theorem floor58 : Floor c58 2 := by
  have up := refundEdge e58_55 floor55 66048 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c59 : Chart := ⟨[16512, 17408, 66048, 66560],[1664, 16896, 65664, 81920]⟩
def m59_58 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e59_58 : Edge c59 c58 m59_58 := by constructor <;> decide
theorem floor59 : Floor c59 3 := by
  have up := refundEdge e59_58 floor58 16512 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)

end TightRow.Protected.Numeric
