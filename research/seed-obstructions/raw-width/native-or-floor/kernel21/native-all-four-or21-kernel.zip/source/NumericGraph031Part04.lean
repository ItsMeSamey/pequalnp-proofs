import NumericEdgeHints
import NumericGraph031Part03
import NumericGraph029
import NumericGraph030
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c380 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120],[1792, 3712, 9472, 15616, 23040, 30720, 38016, 46080, 67968, 76032, 92160, 114688, 136064, 143616, 152064, 168064, 192512, 196992, 205056, 229504]⟩
def m380_377 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e380_377 : Edge c380 c377 m380_377 := by
  exact edgeByPairs c380 c377 m380_377 [(8704,8704), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (69632,69632), (132096,132096), (133120,133120)] [(1792,1792), (3584,3712), (15616,15616), (23040,23040), (30720,30720), (46080,46080), (65792,67968), (76032,76032), (92160,92160), (114688,114688), (135936,136064), (143616,143616), (152064,152064), (192512,192512), (205056,205056), (229376,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor380 : Floor c380 11 := by
  have up := refundEdge e380_377 floor377 8320 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c381 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120],[2099008, 3712, 2101696, 2102080, 2102592, 2103616, 2112768, 2120256, 2127872, 2135232, 2143232, 2150464, 2163136, 2165184, 76032, 2181184, 92160, 2195648, 2211904, 2233216, 2240768, 2249216, 2265216, 2289664, 196992, 205056, 229504]⟩
def m381_363 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, some 6]
private theorem e381_363 : Edge c381 c363 m381_363 := by
  exact edgeByPairs c381 c363 m381_363 [(8256,2105408), (8320,8320), (8704,8704), (16512,16512), (16640,16640), (17408,17408), (33024,33024), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (131136,2228288), (132096,132096), (133120,133120)] [(1856,2099008), (3712,3712), (11520,2112768), (19008,2120256), (33984,2135232), (41984,2143232), (68032,2165184), (76032,76032), (84032,2181184), (92160,92160), (98496,2195648), (114752,2211904), (131968,2233216), (147968,2249216), (188416,2289664), (196992,196992), (205056,205056), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor381 : Floor c381 13 := by
  have up := refundEdge e381_363 floor363 2166784 2163136 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 13 ≤ 13).trans (up k x net fit)

end TightRow.Protected.Numeric
