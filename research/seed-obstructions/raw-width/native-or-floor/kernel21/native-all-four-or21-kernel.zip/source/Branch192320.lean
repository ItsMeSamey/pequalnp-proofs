import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short192320
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8704, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120]
def n : List Nat := [1856, 2368, 3584, 11520, 19008, 26624, 33856, 41984, 49216, 131840, 139520, 147968, 188416]
def pp := p.map (canonical 192320)
def nn := n.map (canonical 192320)
def parts : List Nat := [0, 64, 256, 512, 1024, 2048, 8192, 16384, 8256, 8704, 16640, 17408]
def g : ShortGrid := [(0,[(64,10282049269874637845735769834344147478670756283137), (256,2985847733561617514779107619327656470491768685569), (512,1518614717260799892127165987304318303376588735233), (1024,11743573208291037258894517478484486589515238147073), (2048,13205097146707436611205107842473323003396422501889), (8192,1512905639376334930966461749572491398009195593729), (8256,256), (8704,0), (16384,2974429577792734323842490300310453172721508548609), (16640,8589935360), (17408,8589935104)]), (64,[(256,8657240064), (512,21575696384), (1024,12952207360), (2048,25870663680), (8192,3298534883328), (8704,0), (16384,8590131200), (16640,8590131200), (17408,8590131200)]), (256,[(512,567348000129280), (1024,34510995968), (2048,38805963264), (8192,568447511560192), (8256,256), (8704,0), (16384,567356589867520), (17408,8589935104)]), (512,[(1024,12952207616), (2048,38805897472), (8192,284773511593984), (8256,256), (16384,8590131456), (16640,8590131456), (17408,8590131456)]), (1024,[(2048,25870729984), (8192,849922488270848), (8256,256), (8704,0), (16384,848822976643584), (16640,8589935360)]), (2048,[(8192,1696546441658368), (8256,256), (8704,0), (16384,1697645953286656), (16640,768), (17408,512)]), (8192,[(16384,8640266240), (16640,8640266240), (17408,8640266240)]), (8256,[(16384,256), (16640,256), (17408,256)]), (8704,[(16384,0), (16640,0), (17408,0)])]
private theorem row0 : parts.all (shortPair g pp nn 28480 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 28480 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 28480 256) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 28480 512) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 28480 1024) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 28480 2048) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 28480 8192) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 28480 16384) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 28480 8256) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 28480 8704) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 28480 16640) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 28480 17408) = true := by decide
theorem full : checkArms 192320 28480 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 256, 512, 1024, 2048, 8192, 16384, 8256, 8704, 16640, 17408] : List Nat).all (fun i => parts.all (shortPair g pp nn 28480 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short192320
theorem validBranch192320 : checkArms 192320 28480 [8256, 8704, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120] [1856, 2368, 3584, 11520, 19008, 26624, 33856, 41984, 49216, 131840, 139520, 147968, 188416] = true := Short192320.full
end TightRow.Protected.Numeric
