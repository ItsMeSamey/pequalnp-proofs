import IncrementRootData

namespace TightRow.Protected.Numeric.Increment
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem rootDown5OK : ∀ z ∈ rootDown5, RootDown z := by decide
theorem rootDown6OK : ∀ z ∈ rootDown6, RootDown z := by decide
theorem rootDown7OK : ∀ z ∈ rootDown7, RootDown z := by decide
theorem rootDown8OK : ∀ z ∈ rootDown8, RootDown z := by decide
end TightRow.Protected.Numeric.Increment
