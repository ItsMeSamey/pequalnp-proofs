import NumericGraph023
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c288 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 131136, 132096],[1216, 1664, 1856, 9472, 16896, 16960, 65984, 81984, 90112, 131968, 147968, 155648, 196992, 205056]⟩
def m288_284 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e288_284 : Edge c288 c284 m288_284 := by constructor <;> decide
theorem floor288 : Floor c288 9 := by
  have up := refundEdge e288_284 floor284 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c289 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 132096, 133120],[3712, 11264, 18944, 67712, 92160, 131200, 131712, 147968, 155648, 196736, 204800]⟩
def m289_283 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e289_283 : Edge c289 c283 m289_283 := by constructor <;> decide
theorem floor289 : Floor c289 7 := by
  have up := refundEdge e289_283 floor283 133120 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c290 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 66048, 66560, 131136, 132096, 133120],[1216, 1600, 3712, 11264, 19008, 67776, 84032, 92160, 131200, 131712, 147968, 155648, 196736, 204800]⟩
def m290_284 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e290_284 : Edge c290 c284 m290_284 := by constructor <;> decide
theorem floor290 : Floor c290 9 := by
  have up := refundEdge e290_284 floor284 133120 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c291 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 131136, 132096, 133120],[1216, 1856, 3712, 11520, 18944, 19008, 68032, 76032, 84032, 92160, 131968, 147968, 155648, 196992, 205056]⟩
def m291_290 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e291_290 : Edge c291 c290 m291_290 := by constructor <;> decide
theorem floor291 : Floor c291 10 := by
  have up := refundEdge e291_290 floor290 16640 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c292 : Chart := ⟨[2105408, 8320, 16512, 17408, 66560, 2166784, 2228288, 132096],[2102464, 2110464, 2117696, 2162880, 2179136, 90112, 2232448, 2256896, 196736, 204800]⟩
def m292_281 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, some 6]
private theorem e292_281 : Edge c292 c281 m292_281 := by constructor <;> decide
theorem floor292 : Floor c292 7 := by
  have up := refundEdge e292_281 floor281 2166784 2162880 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c293 : Chart := ⟨[8196, 2105408, 8320, 16512, 17408, 66560, 2166784, 2228288, 132096],[2102340, 2102404, 2102464, 9216, 2110464, 2117700, 2162880, 2179140, 90112, 2232452, 2248708, 2256896, 196740, 204800]⟩
def m293_292 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, some 17, none, none, none, some 21]
private theorem e293_292 : Edge c293 c292 m293_292 := by constructor <;> decide
theorem floor293 : Floor c293 8 := by
  have up := refundEdge e293_292 floor292 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 8 ≤ 8).trans (up k x net fit)
def c294 : Chart := ⟨[8196, 2105408, 1056896, 1065088, 17408, 66560, 2166784, 1179649, 2228288, 132096],[1049733, 3150017, 2102340, 3150977, 3150980, 3151040, 3159041, 3166273, 2117700, 3174401, 1114245, 3211457, 3227717, 1138689, 1179776, 3281028, 2248708, 2256896, 1245316, 204800]⟩
def m294_293 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, some 17, none, none, some 7, some 21]
private theorem e294_293 : Edge c294 c293 m294_293 := by constructor <;> decide
theorem floor294 : Floor c294 9 := by
  have up := refundEdge e294_293 floor293 1179649 1179776 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c295 : Chart := ⟨[2105408, 8320, 8704, 16512, 17408, 66048, 66560, 2166784, 2228288, 132096],[2098752, 1664, 2102464, 2110464, 2118208, 2162880, 2179136, 90112, 2232960, 2249216, 2256896, 196736, 204800]⟩
def m295_284 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, some 6]
private theorem e295_284 : Edge c295 c284 m295_284 := by constructor <;> decide
theorem floor295 : Floor c295 9 := by
  have up := refundEdge e295_284 floor284 2166784 2162880 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c296 : Chart := ⟨[2105408, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 2166784, 2228288, 132096],[1664, 2099008, 2101696, 2102080, 2102464, 2102592, 2110720, 16896, 2118208, 2163136, 2179136, 90112, 2233216, 2240768, 2249216, 2256896, 196992, 205056]⟩
def m296_295 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, none, none, none, some 21]
private theorem e296_295 : Edge c296 c295 m296_295 := by constructor <;> decide
theorem floor296 : Floor c296 10 := by
  have up := refundEdge e296_295 floor295 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c297 : Chart := ⟨[8196, 2105408, 8320, 8704, 16512, 16640, 17408, 66048, 66560, 2166784, 2228288, 132096],[2098500, 1664, 1796, 2099008, 2101696, 2102080, 2102340, 2102404, 2102464, 2102592, 9472, 2110720, 2117700, 2118208, 2163012, 2163136, 2179140, 90112, 131844, 2232452, 2233216, 2240768, 2249220, 2256896, 196996, 205056]⟩
def m297_296 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, none, none, none, some 21]
private theorem e297_296 : Edge c297 c296 m297_296 := by constructor <;> decide
theorem floor297 : Floor c297 11 := by
  have up := refundEdge e297_296 floor296 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c298 : Chart := ⟨[8196, 2105408, 1056896, 8704, 1065088, 16640, 17408, 66048, 66560, 2166784, 1179649, 2228288, 132096],[3146561, 1049473, 1049733, 2098500, 1050117, 1050241, 1050369, 1796, 2099008, 3150017, 3150272, 3150465, 2102080, 2102340, 3150977, 3150980, 3151040, 2102592, 1058049, 3159041, 2110720, 1065477, 2117700, 3166785, 3174401, 1114245, 2163012, 3211713, 1122561, 3227717, 1138689, 1180032, 131844, 3281028, 3281792, 2240768, 2249220, 2256896, 1245572, 205056]⟩
def m298_297 : List (Option Addr) := [none, none, some 2, none, none, none, some 6, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, none, none, some 7, some 21]
private theorem e298_297 : Edge c298 c297 m298_297 := by constructor <;> decide
theorem floor298 : Floor c298 12 := by
  have up := refundEdge e298_297 floor297 1179649 1180032 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 12 ≤ 12).trans (up k x net fit)
def c299 : Chart := ⟨[2105408, 8320, 8704, 16512, 17408, 66048, 66560, 2166784, 2228288, 132096, 133120],[2098752, 3712, 2102464, 2112512, 2120256, 2127872, 2164928, 2181184, 92160, 131200, 2232960, 2249216, 2256896, 196736, 204800]⟩
def m299_295 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, some 17, none, none, none, some 21]
private theorem e299_295 : Edge c299 c295 m299_295 := by constructor <;> decide
theorem floor299 : Floor c299 10 := by
  have up := refundEdge e299_295 floor295 133120 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)

end TightRow.Protected.Numeric
