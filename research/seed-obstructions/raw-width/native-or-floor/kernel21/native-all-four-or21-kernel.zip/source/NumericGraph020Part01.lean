import NumericGraph020Part00
import Branch191936
import Branch192128
import Branch192192
import Branch192320
import NumericGraph003
import NumericGraph013
import NumericGraph016
import NumericGraph017
import NumericGraph018
import NumericGraph019
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c243 : Chart := ⟨[8320, 16512, 16640, 17408, 33024, 34816, 132096, 133120],[128, 2432, 3200, 11520, 26624, 33920, 41984, 131456, 139520, 163968, 188416]⟩
def m243_210 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e243_210 : Edge c243 c210 m243_210 := by constructor <;> decide
theorem floor243 : Floor c243 7 := by
  have up := refundEdge e243_210 floor210 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c244 : Chart := ⟨[8256, 8320, 16512, 16640, 17408, 33024, 34816, 131136, 132096, 133120],[1344, 2496, 3200, 11520, 18496, 26624, 33984, 41984, 49216, 131456, 139520, 163968, 188416]⟩
def m244_243 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e244_243 : Edge c244 c243 m244_243 := by constructor <;> decide
def m244_241 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e244_241 : Edge c244 c241 m244_241 := by constructor <;> decide
def m244_240 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e244_240 : Edge c244 c240 m244_240 := by constructor <;> decide
def m244_232 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e244_232 : Edge c244 c232 m244_232 := by constructor <;> decide
def m244_221 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e244_221 : Edge c244 c221 m244_221 := by constructor <;> decide
def m244_211 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e244_211 : Edge c244 c211 m244_211 := by constructor <;> decide
def m244_161 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e244_161 : Edge c244 c161 m244_161 := by constructor <;> decide
theorem floor244 : Floor c244 9 := by
  apply protectedBranch source c244.P c244.N (decode 44480) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 44480, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 15 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e244_243 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor243 k x net fit)
    · refine ⟨_,goodChild e244_241 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor241 k x net fit)
    · refine ⟨_,goodChild e244_240 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor240 k x net fit)
    · refine ⟨_,goodChild e244_232 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor232 k x net fit)
    · refine ⟨_,goodChild e244_221 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor221 k x net fit)
    · refine ⟨_,goodChild e244_211 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor211 k x net fit)
    · refine ⟨_,goodChild e244_161 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor161 k x net fit)
  · exact pairExcluded 191936 44480 [8256, 8320, 16512, 16640, 17408, 33024, 34816, 131136, 132096, 133120] [1344, 2496, 3200, 11520, 18496, 26624, 33984, 41984, 49216, 131456, 139520, 163968, 188416] validBranch191936 (by decide) (by decide) (by decide)
def c245 : Chart := ⟨[8704, 17408, 33280, 34816, 132096, 133120],[512, 3584, 11264, 18944, 26624, 41984, 147968, 188416]⟩
def m245_212 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e245_212 : Edge c245 c212 m245_212 := by constructor <;> decide
theorem floor245 : Floor c245 5 := by
  have up := refundEdge e245_212 floor212 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)

end TightRow.Protected.Numeric
