import NumericGraph007
import NumericGraph017
import NumericGraph025
import NumericGraph026
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c324 : Chart := ⟨[8196, 8256, 8704, 33280, 34816, 66048, 66560, 131136, 132096, 133120],[1600, 2624, 3588, 9216, 11264, 33860, 41984, 67652, 75776, 98372, 131588, 172032, 204800, 229380]⟩
def m324_323 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e324_323 : Edge c324 c323 m324_323 := by constructor <;> decide
theorem floor324 : Floor c324 9 := by
  have up := refundEdge e324_323 floor323 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c325 : Chart := ⟨[8320, 8704, 33280, 34816, 66048, 66560, 132096, 133120],[3712, 9216, 11264, 33920, 41984, 67712, 75776, 131712, 172032, 204800, 229504]⟩
def m325_320 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e325_320 : Edge c325 c320 m325_320 := by constructor <;> decide
theorem floor325 : Floor c325 7 := by
  have up := refundEdge e325_320 floor320 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c326 : Chart := ⟨[8256, 8704, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120],[1856, 2624, 3584, 11520, 33792, 33856, 41984, 67904, 76032, 98368, 131840, 172032, 205056, 229376]⟩
def m326_323 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e326_323 : Edge c326 c323 m326_323 := by constructor <;> decide
theorem floor326 : Floor c326 9 := by
  have up := refundEdge e326_323 floor323 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c327 : Chart := ⟨[8256, 8320, 8704, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120],[1856, 2624, 3712, 9472, 11520, 33984, 41984, 68032, 76032, 98496, 131968, 172032, 196992, 205056, 229504]⟩
def m327_326 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e327_326 : Edge c327 c326 m327_326 := by constructor <;> decide
theorem floor327 : Floor c327 10 := by
  have up := refundEdge e327_326 floor326 8320 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c328 : Chart := ⟨[2105408, 8704, 33280, 34816, 66048, 2166784, 2228288, 133120],[2103872, 2111488, 2134080, 2162752, 2164800, 75776, 2195520, 2232832, 2273280, 204800, 229376]⟩
def m328_319 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, some 6]
private theorem e328_319 : Edge c328 c319 m328_319 := by constructor <;> decide
theorem floor328 : Floor c328 7 := by
  have up := refundEdge e328_319 floor319 2166784 2162752 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c329 : Chart := ⟨[2105408, 8704, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120],[2098752, 3584, 2103872, 2112512, 2135104, 2143232, 2162752, 2164800, 75776, 2195520, 2232832, 2273280, 204800, 229376]⟩
def m329_323 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, some 6]
private theorem e329_323 : Edge c329 c323 m329_323 := by constructor <;> decide
theorem floor329 : Floor c329 9 := by
  have up := refundEdge e329_323 floor323 2166784 2162752 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c330 : Chart := ⟨[2105408, 8320, 8704, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120],[2098752, 3712, 2103872, 9216, 2112512, 2135232, 2143232, 2164928, 75776, 2195648, 2232960, 2265216, 2273280, 204800, 229504]⟩
def m330_329 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, some 12, some 13, none, some 15, some 16, some 17, none, none, none, some 21]
private theorem e330_329 : Edge c330 c329 m330_329 := by constructor <;> decide
theorem floor330 : Floor c330 10 := by
  have up := refundEdge e330_329 floor329 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c331 : Chart := ⟨[16640, 17408, 33024, 33280, 66048, 66560, 132096],[1536, 1792, 33792, 114688, 131840, 147968, 180224, 196864, 229376]⟩
def m331_93 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e331_93 : Edge c331 c93 m331_93 := by constructor <;> decide
theorem floor331 : Floor c331 6 := by
  have up := refundEdge e331_93 floor93 132096 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c332 : Chart := ⟨[16640, 17408, 33024, 33280, 66048, 66560, 131073, 132096],[1793, 16897, 33793, 65793, 114689, 131328, 131840, 147968, 180224, 196864, 229376]⟩
def m332_331 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e332_331 : Edge c332 c331 m332_331 := by constructor <;> decide
theorem floor332 : Floor c332 7 := by
  have up := refundEdge e332_331 floor331 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c333 : Chart := ⟨[16640, 17408, 33024, 33280, 66048, 66560, 131136, 132096],[1856, 16960, 33856, 65856, 114752, 131328, 131840, 147968, 180224, 196864, 229376]⟩
def m333_331 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e333_331 : Edge c333 c331 m333_331 := by constructor <;> decide
theorem floor333 : Floor c333 7 := by
  have up := refundEdge e333_331 floor331 131136 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c334 : Chart := ⟨[16640, 17408, 33024, 34816, 66560, 132096, 133120],[1024, 3328, 33792, 67840, 83968, 114688, 180224, 196864, 229376]⟩
def m334_207 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e334_207 : Edge c334 c207 m334_207 := by constructor <;> decide
theorem floor334 : Floor c334 6 := by
  have up := refundEdge e334_207 floor207 66560 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c335 : Chart := ⟨[17408, 33280, 34816, 66048, 66560, 132096, 133120],[1536, 3584, 18944, 33792, 83968, 114688, 147968, 180224, 229376]⟩
def m335_305 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e335_305 : Edge c335 c305 m335_305 := by constructor <;> decide
theorem floor335 : Floor c335 6 := by
  have up := refundEdge e335_305 floor305 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)

end TightRow.Protected.Numeric
