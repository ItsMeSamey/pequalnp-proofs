import NumericGraph020Part02
import Branch191936
import Branch192128
import Branch192192
import Branch192320
import NumericGraph003
import NumericGraph013
import NumericGraph016
import NumericGraph017
import NumericGraph018
import NumericGraph019
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c249 : Chart := ⟨[8196, 8256, 8320, 8704, 16512, 17408, 33280, 34816, 131136, 132096, 133120],[1600, 2240, 3204, 3588, 3712, 9216, 11264, 18500, 18948, 19008, 26624, 33860, 33924, 33984, 41984, 49220, 131712, 147972, 163972, 180228, 188416]⟩
def m249_248 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e249_248 : Edge c249 c248 m249_248 := by constructor <;> decide
theorem floor249 : Floor c249 10 := by
  have up := refundEdge e249_248 floor248 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c250 : Chart := ⟨[8704, 16640, 17408, 33024, 33280, 34816, 132096, 133120],[512, 1792, 3584, 11520, 18944, 26624, 41984, 131840, 139520, 147968, 188416]⟩
def m250_214 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e250_214 : Edge c250 c214 m250_214 := by constructor <;> decide
theorem floor250 : Floor c250 7 := by
  have up := refundEdge e250_214 floor214 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c251 : Chart := ⟨[8256, 8704, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120],[1856, 2368, 3584, 11520, 19008, 26624, 33856, 41984, 49216, 131840, 139520, 147968, 188416]⟩
def m251_250 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e251_250 : Edge c251 c250 m251_250 := by constructor <;> decide
def m251_246 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e251_246 : Edge c251 c246 m251_246 := by constructor <;> decide
def m251_241 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e251_241 : Edge c251 c241 m251_241 := by constructor <;> decide
def m251_236 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e251_236 : Edge c251 c236 m251_236 := by constructor <;> decide
def m251_226 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e251_226 : Edge c251 c226 m251_226 := by constructor <;> decide
def m251_215 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e251_215 : Edge c251 c215 m251_215 := by constructor <;> decide
def m251_196 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e251_196 : Edge c251 c196 m251_196 := by constructor <;> decide
theorem floor251 : Floor c251 9 := by
  apply protectedBranch source c251.P c251.N (decode 28480) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 28480, q = 6 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 14 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e251_250 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor250 k x net fit)
    · refine ⟨_,goodChild e251_246 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor246 k x net fit)
    · refine ⟨_,goodChild e251_241 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor241 k x net fit)
    · refine ⟨_,goodChild e251_236 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor236 k x net fit)
    · refine ⟨_,goodChild e251_226 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor226 k x net fit)
    · refine ⟨_,goodChild e251_215 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor215 k x net fit)
    · refine ⟨_,goodChild e251_196 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor196 k x net fit)
  · exact pairExcluded 192320 28480 [8256, 8704, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120] [1856, 2368, 3584, 11520, 19008, 26624, 33856, 41984, 49216, 131840, 139520, 147968, 188416] validBranch192320 (by decide) (by decide) (by decide)


end TightRow.Protected.Numeric
