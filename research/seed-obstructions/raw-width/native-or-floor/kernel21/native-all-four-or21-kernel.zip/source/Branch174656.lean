import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short174656
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8704, 33280, 34816, 131136, 133120]
def n : List Nat := [2624, 10240, 32832, 131584, 172032]
def pp := p.map (canonical 174656)
def nn := n.map (canonical 174656)
def parts : List Nat := [0, 64, 512, 2048, 8192, 32768, 131072, 8256, 8704, 33280, 34816, 131136, 133120]
def g : ShortGrid := [(0,[(64,309489732259886631936327937), (512,79538861190790864407636279553), (2048,238307093840112706590972510721), (8192,1), (8256,256), (8704,0), (32768,158458742917061955551399903233), (33280,8590000384), (34816,8589935104), (131072,316917485834123911102799806465), (131136,17179934720), (133120,17180001024)]), (64,[(512,8623554560), (2048,12918521856), (8192,1099511627776), (8704,0), (32768,8590000128), (33280,8590000128), (34816,8590000128), (131072,17179934720), (133120,17179934720)]), (512,[(2048,21525233920), (8192,282574488338432), (8256,256), (32768,8590000384), (34816,8590000384), (131072,17179934976), (131136,65536), (133120,17179934976)]), (2048,[(8192,848822976643072), (8256,256), (8704,0), (32768,846623953388032), (33280,65792), (131072,17180001024), (131136,65536)]), (8192,[(32768,12901679104), (33280,4311744512), (34816,12901679104), (131072,21491613696), (131136,16777216), (133120,21491613696)]), (8256,[(32768,256), (33280,256), (34816,256), (131072,256), (133120,256)]), (8704,[(32768,0), (34816,0), (131072,0), (131136,0), (133120,0)]), (32768,[(131072,17213424128), (131136,65536), (133120,12918456832)]), (33280,[(131072,65792), (131136,65536), (133120,65792)]), (34816,[(131072,512), (131136,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 174656 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 174656 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 174656 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 174656 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 174656 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 174656 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 174656 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 174656 8256) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 174656 8704) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 174656 33280) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 174656 34816) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 174656 131136) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 174656 133120) = true := by decide
theorem full : checkArms 174656 174656 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 512, 2048, 8192, 32768, 131072, 8256, 8704, 33280, 34816, 131136, 133120] : List Nat).all (fun i => parts.all (shortPair g pp nn 174656 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short174656
theorem validBranch174656 : checkArms 174656 174656 [8256, 8704, 33280, 34816, 131136, 133120] [2624, 10240, 32832, 131584, 172032] = true := Short174656.full
end TightRow.Protected.Numeric
