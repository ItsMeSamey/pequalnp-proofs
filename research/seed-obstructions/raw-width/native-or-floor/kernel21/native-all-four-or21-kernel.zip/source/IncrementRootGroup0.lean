import IncrementRootData

namespace TightRow.Protected.Numeric.Increment
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem rootUp0OK : ∀ z ∈ rootUp0, RootUp z := by decide
theorem rootUp1OK : ∀ z ∈ rootUp1, RootUp z := by decide
theorem rootUp2OK : ∀ z ∈ rootUp2, RootUp z := by decide
theorem rootDown0OK : ∀ z ∈ rootDown0, RootDown z := by decide
end TightRow.Protected.Numeric.Increment
