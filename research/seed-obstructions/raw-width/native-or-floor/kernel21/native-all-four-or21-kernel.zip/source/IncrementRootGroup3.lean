import IncrementRootData

namespace TightRow.Protected.Numeric.Increment
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem rootDown9OK : ∀ z ∈ rootDown9, RootDown z := by decide
theorem rootDown10OK : ∀ z ∈ rootDown10, RootDown z := by decide
theorem rootDown11OK : ∀ z ∈ rootDown11, RootDown z := by decide
theorem rootDown12OK : ∀ z ∈ rootDown12, RootDown z := by decide
end TightRow.Protected.Numeric.Increment
