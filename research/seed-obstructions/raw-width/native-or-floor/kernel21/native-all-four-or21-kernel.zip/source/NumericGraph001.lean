import NumericGraph000
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c12 : Chart := ⟨[8320, 8704, 33280],[640, 8192, 32896, 40960]⟩
def m12_11 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e12_11 : Edge c12 c11 m12_11 := by constructor <;> decide
theorem floor12 : Floor c12 2 := by
  have up := refundEdge e12_11 floor11 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c13 : Chart := ⟨[8704, 33024, 33280],[768, 8448, 32768, 40960]⟩
def m13_11 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e13_11 : Edge c13 c11 m13_11 := by constructor <;> decide
theorem floor13 : Floor c13 2 := by
  have up := refundEdge e13_11 floor11 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c14 : Chart := ⟨[8196, 8704, 33024, 33280],[772, 8448, 32772, 40960]⟩
def m14_13 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e14_13 : Edge c14 c13 m14_13 := by constructor <;> decide
theorem floor14 : Floor c14 3 := by
  have up := refundEdge e14_13 floor13 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c15 : Chart := ⟨[8320, 8704, 33024, 33280],[896, 8448, 32896, 40960]⟩
def m15_13 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e15_13 : Edge c15 c13 m15_13 := by constructor <;> decide
theorem floor15 : Floor c15 3 := by
  have up := refundEdge e15_13 floor13 8320 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c16 : Chart := ⟨[8704, 33280, 34816],[2560, 10240, 32768, 40960]⟩
def m16_11 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e16_11 : Edge c16 c11 m16_11 := by constructor <;> decide
theorem floor16 : Floor c16 2 := by
  have up := refundEdge e16_11 floor11 34816 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c17 : Chart := ⟨[8256, 8704, 33280, 34816],[2624, 8192, 10240, 32832, 40960]⟩
def m17_16 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e17_16 : Edge c17 c16 m17_16 := by constructor <;> decide
theorem floor17 : Floor c17 3 := by
  have up := refundEdge e17_16 floor16 8256 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c18 : Chart := ⟨[8320, 8704, 33280, 34816],[2688, 8192, 10240, 32896, 40960]⟩
def m18_16 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e18_16 : Edge c18 c16 m18_16 := by constructor <;> decide
theorem floor18 : Floor c18 3 := by
  have up := refundEdge e18_16 floor16 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c19 : Chart := ⟨[16640, 33024],[256, 49152]⟩
def m19_9 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, none, none, none, none, some 15, none, none, none, none, none, none]
private theorem e19_9 : Edge c19 c9 m19_9 := by constructor <;> decide
theorem floor19 : Floor c19 1 := by
  have up := refundEdge e19_9 floor9 16640 256 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c20 : Chart := ⟨[16512, 16640, 33024],[384, 16384, 32896, 49152]⟩
def m20_19 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e20_19 : Edge c20 c19 m20_19 := by constructor <;> decide
theorem floor20 : Floor c20 2 := by
  have up := refundEdge e20_19 floor19 16512 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c21 : Chart := ⟨[16640, 33024, 33280],[768, 16896, 32768, 49152]⟩
def m21_19 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e21_19 : Edge c21 c19 m21_19 := by constructor <;> decide
theorem floor21 : Floor c21 2 := by
  have up := refundEdge e21_19 floor19 33280 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c22 : Chart := ⟨[16512, 16640, 33024, 33280],[896, 16896, 32896, 49152]⟩
def m22_21 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e22_21 : Edge c22 c21 m22_21 := by constructor <;> decide
theorem floor22 : Floor c22 3 := by
  have up := refundEdge e22_21 floor21 16512 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c23 : Chart := ⟨[16640, 17408, 33024],[1280, 16384, 33792, 49152]⟩
def m23_19 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e23_19 : Edge c23 c19 m23_19 := by constructor <;> decide
theorem floor23 : Floor c23 2 := by
  have up := refundEdge e23_19 floor19 17408 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)

end TightRow.Protected.Numeric
