import ProtectedNumericEdges

namespace TightRow.Protected.Numeric

/-- The two lists give actual parent witnesses coupled to every signed child row. -/
theorem edgeByPairs (p c : Chart) (m : List (Option Addr))
    (up down : List (Nat × Nat))
    (upCover : c.pos = up.map Prod.fst) (downCover : c.neg = down.map Prod.fst)
    (liveP : ∃ x ∈ c.pos, True) (liveN : ∃ x ∈ c.neg, True)
    (upOK : ∀ z ∈ up, z.2 ∈ p.pos ∧ ∀ i : Addr, z.2.testBit i.val = true → rebits m z.1 i = true)
    (downOK : ∀ z ∈ down, z.2 ∈ p.neg ∧ ∀ i : Addr, rebits m z.1 i = true → z.2.testBit i.val = true) :
    Edge p c m := by
  refine ⟨liveP,liveN,?_,?_⟩
  · intro x hx
    rw [upCover] at hx
    obtain ⟨z,hz,rfl⟩ := List.mem_map.mp hx
    exact ⟨z.2,(upOK z hz).1,(upOK z hz).2⟩
  · intro x hx
    rw [downCover] at hx
    obtain ⟨z,hz,rfl⟩ := List.mem_map.mp hx
    exact ⟨z.2,(downOK z hz).1,(downOK z hz).2⟩

end TightRow.Protected.Numeric
