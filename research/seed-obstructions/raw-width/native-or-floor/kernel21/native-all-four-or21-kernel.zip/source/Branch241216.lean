import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short241216
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8704, 33280, 34816, 66048, 66560, 131136, 132096, 133120]
def n : List Nat := [1600, 2624, 3584, 11264, 33856, 41984, 67648, 75776, 98368, 131584, 172032, 204800, 229376]
def pp := p.map (canonical 241216)
def nn := n.map (canonical 241216)
def parts : List Nat := [0, 64, 1024, 2048, 8192, 32768, 65536, 8256, 34816, 66560]
def g : ShortGrid := [(0,[(64,134590535453159392537450477816259960893342465), (1024,156891620939249630546461106147558683499103745), (2048,179192706425339312410908956034272421516346369), (8192,23085108022710186909029345539388151347281921), (8256,256), (32768,45386193508800186306306271877129992350597121), (34816,8589935104), (65536,89988364480980026642117207490658122957324289), (66560,17179870208)]), (64,[(1024,21575696384), (2048,12952207360), (8192,3298534883328), (32768,8590131200), (34816,8590131200), (65536,17180065792), (66560,17180065792)]), (1024,[(2048,1413971953582848), (8192,1415071464947712), (8256,256), (32768,1416170976641792), (34816,512), (65536,1413989133190400)]), (2048,[(8192,849922488270848), (8256,256), (32768,848831583355648), (65536,17196909312), (66560,17196909312)]), (8192,[(32768,12935233536), (34816,12935233536), (65536,21525168128), (66560,21525168128)]), (8256,[(32768,256), (34816,256), (65536,256), (66560,256)]), (32768,[(65536,21542011648), (66560,21542011648)]), (34816,[(65536,512), (66560,512)])]
private theorem row0 : parts.all (shortPair g pp nn 109632 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 109632 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 109632 1024) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 109632 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 109632 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 109632 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 109632 65536) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 109632 8256) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 109632 34816) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 109632 66560) = true := by decide
theorem full : checkArms 241216 109632 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 1024, 2048, 8192, 32768, 65536, 8256, 34816, 66560] : List Nat).all (fun i => parts.all (shortPair g pp nn 109632 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short241216
theorem validBranch241216 : checkArms 241216 109632 [8256, 8704, 33280, 34816, 66048, 66560, 131136, 132096, 133120] [1600, 2624, 3584, 11264, 33856, 41984, 67648, 75776, 98368, 131584, 172032, 204800, 229376] = true := Short241216.full
end TightRow.Protected.Numeric
