import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short191936
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8320, 16512, 16640, 17408, 33024, 34816, 131136, 132096, 133120]
def n : List Nat := [1344, 2496, 3200, 11520, 18496, 26624, 33984, 41984, 49216, 131456, 139520, 163968, 188416]
def pp := p.map (canonical 191936)
def nn := n.map (canonical 191936)
def parts : List Nat := [0, 64, 128, 256, 1024, 2048, 8192, 32768, 8256, 8320, 33024, 34816]
def g : ShortGrid := [(0,[(64,10282049269874637764604893470253591554254660698881), (128,1518614717260779061774658295748598798584589124353), (256,7370419548810763729080876022004465335902079747073), (1024,11743573208291042370139729011235213090244782195713), (2048,13205097146707436611205107851918200086522812040705), (8192,1512905639376334809270147208159096052948246986753), (8256,65792), (8320,0), (32768,7359001393041896034141647276125881336283080753153), (33024,12952273664), (34816,21474837760)]), (64,[(128,8657240064), (256,12952207360), (1024,17247174656), (2048,25870663680), (8192,3298534883328), (8320,0), (32768,21475033088), (33024,21475033088), (34816,21475033088)]), (128,[(256,21575696640), (1024,34510930176), (2048,25870663936), (8192,284773511593984), (8256,16777472), (32768,21491810560), (33024,21491810560), (34816,21491810560)]), (256,[(1024,34511127808), (2048,38806095104), (8192,849922488270848), (8256,65792), (8320,0), (32768,1413993428157696), (34816,21474837760)]), (1024,[(2048,1130297953748480), (8192,1131397464981504), (8256,65792), (8320,0), (32768,1134695999866112), (33024,262912), (34816,1280)]), (2048,[(8192,1696546441658368), (8256,65792), (8320,0), (32768,1695446930031872), (33024,262912)]), (8192,[(32768,21525168128), (33024,21525168128), (34816,21525168128)]), (8256,[(32768,65792), (33024,65792), (34816,65792)]), (8320,[(32768,0), (33024,0), (34816,0)])]
private theorem row0 : parts.all (shortPair g pp nn 44480 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 44480 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 44480 128) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 44480 256) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 44480 1024) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 44480 2048) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 44480 8192) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 44480 32768) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 44480 8256) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 44480 8320) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 44480 33024) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 44480 34816) = true := by decide
theorem full : checkArms 191936 44480 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 128, 256, 1024, 2048, 8192, 32768, 8256, 8320, 33024, 34816] : List Nat).all (fun i => parts.all (shortPair g pp nn 44480 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short191936
theorem validBranch191936 : checkArms 191936 44480 [8256, 8320, 16512, 16640, 17408, 33024, 34816, 131136, 132096, 133120] [1344, 2496, 3200, 11520, 18496, 26624, 33984, 41984, 49216, 131456, 139520, 163968, 188416] = true := Short191936.full
end TightRow.Protected.Numeric
