import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short206400
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8704, 66048, 66560, 131136, 132096]
def n : List Nat := [1600, 9216, 65600, 131584, 204800]
def pp := p.map (canonical 206400)
def nn := n.map (canonical 206400)
def parts : List Nat := [0, 64, 512, 1024, 8192, 65536, 131072, 8256, 8704, 66048, 66560, 131136, 132096]
def g : ShortGrid := [(0,[(64,309489732259886631936327937), (512,79538861190790864407636279553), (1024,238307093840112706590972510721), (8192,1), (8256,256), (8704,0), (65536,158458742917061955551399903233), (66048,8590000384), (66560,8589935104), (131072,316917485834123911102799806465), (131136,17179934720), (132096,17180001024)]), (64,[(512,8623554560), (1024,12918521856), (8192,1099511627776), (8704,0), (65536,8590000128), (66048,8590000128), (66560,8590000128), (131072,17179934720), (132096,17179934720)]), (512,[(1024,21525233920), (8192,282574488338432), (8256,256), (65536,8590000384), (66560,8590000384), (131072,17179934976), (131136,65536), (132096,17179934976)]), (1024,[(8192,848822976643072), (8256,256), (8704,0), (65536,846623953388032), (66048,65792), (131072,17180001024), (131136,65536)]), (8192,[(65536,12901679104), (66048,4311744512), (66560,12901679104), (131072,21491613696), (131136,16777216), (132096,21491613696)]), (8256,[(65536,256), (66048,256), (66560,256), (131072,256), (132096,256)]), (8704,[(65536,0), (66560,0), (131072,0), (131136,0), (132096,0)]), (65536,[(131072,17213424128), (131136,65536), (132096,12918456832)]), (66048,[(131072,65792), (131136,65536), (132096,65792)]), (66560,[(131072,512), (131136,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 206400 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 206400 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 206400 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 206400 1024) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 206400 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 206400 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 206400 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 206400 8256) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 206400 8704) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 206400 66048) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 206400 66560) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 206400 131136) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 206400 132096) = true := by decide
theorem full : checkArms 206400 206400 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 512, 1024, 8192, 65536, 131072, 8256, 8704, 66048, 66560, 131136, 132096] : List Nat).all (fun i => parts.all (shortPair g pp nn 206400 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short206400
theorem validBranch206400 : checkArms 206400 206400 [8256, 8704, 66048, 66560, 131136, 132096] [1600, 9216, 65600, 131584, 204800] = true := Short206400.full
end TightRow.Protected.Numeric
