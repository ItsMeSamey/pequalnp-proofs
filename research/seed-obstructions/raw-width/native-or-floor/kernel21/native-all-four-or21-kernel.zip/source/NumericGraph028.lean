import Branch249600
import Branch255808
import NumericGraph008
import NumericGraph009
import NumericGraph017
import NumericGraph018
import NumericGraph023
import NumericGraph025
import NumericGraph026
import NumericGraph027
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c336 : Chart := ⟨[16512, 17408, 33280, 34816, 66048, 66560, 132096, 133120],[3712, 18944, 33920, 67712, 83968, 114688, 131712, 147968, 180224, 229504]⟩
def m336_335 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e336_335 : Edge c336 c335 m336_335 := by constructor <;> decide
theorem floor336 : Floor c336 7 := by
  have up := refundEdge e336_335 floor335 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c337 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120],[1792, 3328, 3584, 18944, 33792, 67840, 83968, 114688, 131840, 147968, 180224, 196864, 229376]⟩
def m337_335 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e337_335 : Edge c337 c335 m337_335 := by constructor <;> decide
def m337_334 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e337_334 : Edge c337 c334 m337_334 := by constructor <;> decide
def m337_331 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e337_331 : Edge c337 c331 m337_331 := by constructor <;> decide
def m337_308 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e337_308 : Edge c337 c308 m337_308 := by constructor <;> decide
def m337_214 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e337_214 : Edge c337 c214 m337_214 := by constructor <;> decide
def m337_97 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e337_97 : Edge c337 c97 m337_97 := by constructor <;> decide
theorem floor337 : Floor c337 8 := by
  apply protectedBranch source c337.P c337.N (decode 215808) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 215808, q = 8 ∨ q = 9 ∨ q = 11 ∨ q = 14 ∨ q = 16 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e337_335 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor335 k x net fit)
    · refine ⟨_,goodChild e337_334 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor334 k x net fit)
    · refine ⟨_,goodChild e337_331 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor331 k x net fit)
    · refine ⟨_,goodChild e337_308 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor308 k x net fit)
    · refine ⟨_,goodChild e337_214 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor214 k x net fit)
    · refine ⟨_,goodChild e337_97 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor97 k x net fit)
  · exact pairExcluded 249600 215808 [16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120] [1792, 3328, 3584, 18944, 33792, 67840, 83968, 114688, 131840, 147968, 180224, 196864, 229376] validBranch249600 (by decide) (by decide) (by decide)
def c338 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120],[1792, 3328, 3712, 18944, 33920, 67968, 83968, 114688, 131968, 147968, 180224, 196992, 229504]⟩
def m338_337 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e338_337 : Edge c338 c337 m338_337 := by constructor <;> decide
theorem floor338 : Floor c338 9 := by
  have up := refundEdge e338_337 floor337 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c339 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120],[1856, 3328, 3712, 19008, 33984, 68032, 84032, 98496, 114752, 131456, 131968, 147968, 180224, 196992, 229504]⟩
def m339_338 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e339_338 : Edge c339 c338 m339_338 := by constructor <;> decide
theorem floor339 : Floor c339 10 := by
  have up := refundEdge e339_338 floor338 131136 131456 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c340 : Chart := ⟨[16640, 17408, 33024, 34816, 66560, 69632, 132096, 133120],[7424, 22528, 37888, 65792, 67840, 83968, 114688, 135424, 184320, 196864, 229376]⟩
def m340_334 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e340_334 : Edge c340 c334 m340_334 := by constructor <;> decide
theorem floor340 : Floor c340 7 := by
  have up := refundEdge e340_334 floor334 69632 65792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c341 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120],[1792, 3584, 7424, 23040, 37888, 65792, 67840, 83968, 114688, 135936, 152064, 184320, 196864, 229376]⟩
def m341_337 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e341_337 : Edge c341 c337 m341_337 := by constructor <;> decide
theorem floor341 : Floor c341 9 := by
  have up := refundEdge e341_337 floor337 69632 65792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c342 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 131073, 132096, 133120],[1793, 3584, 7424, 23041, 37889, 53249, 67841, 83969, 114689, 131328, 135936, 152064, 184320, 196864, 229376]⟩
def m342_341 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e342_341 : Edge c342 c341 m342_341 := by constructor <;> decide
theorem floor342 : Floor c342 10 := by
  have up := refundEdge e342_341 floor341 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c343 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632, 132096, 133120],[1792, 3712, 7424, 18944, 23040, 38016, 67968, 83968, 114688, 136064, 152064, 168064, 184320, 196992, 229504]⟩
def m343_341 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, some 12, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e343_341 : Edge c343 c341 m343_341 := by constructor <;> decide
theorem floor343 : Floor c343 10 := by
  have up := refundEdge e343_341 floor341 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c344 : Chart := ⟨[8256, 8704, 17408, 33280, 66048, 66560, 131136, 132096],[1536, 1600, 16960, 33856, 41984, 90112, 114752, 147968, 188416, 204800, 229376]⟩
def m344_317 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e344_317 : Edge c344 c317 m344_317 := by constructor <;> decide
theorem floor344 : Floor c344 7 := by
  have up := refundEdge e344_317 floor317 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c345 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 66048, 66560, 132096],[640, 1664, 33920, 41984, 90112, 114688, 131712, 147968, 188416, 204800, 229504]⟩
def m345_283 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e345_283 : Edge c345 c283 m345_283 := by constructor <;> decide
theorem floor345 : Floor c345 7 := by
  have up := refundEdge e345_283 floor283 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c346 : Chart := ⟨[8704, 16640, 17408, 33024, 33280, 66048, 66560, 132096],[512, 1792, 9472, 41984, 90112, 114688, 131840, 147968, 188416, 205056, 229376]⟩
def m346_331 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e346_331 : Edge c346 c331 m346_331 := by constructor <;> decide
theorem floor346 : Floor c346 7 := by
  have up := refundEdge e346_331 floor331 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c347 : Chart := ⟨[8256, 8704, 16640, 17408, 33024, 33280, 66048, 66560, 131136, 132096],[1856, 9472, 16960, 33856, 41984, 65856, 90112, 114752, 131840, 147968, 188416, 205056, 229376]⟩
def m347_346 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e347_346 : Edge c347 c346 m347_346 := by constructor <;> decide
def m347_344 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e347_344 : Edge c347 c344 m347_344 := by constructor <;> decide
def m347_333 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e347_333 : Edge c347 c333 m347_333 := by constructor <;> decide
def m347_318 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e347_318 : Edge c347 c318 m347_318 := by constructor <;> decide
def m347_286 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e347_286 : Edge c347 c286 m347_286 := by constructor <;> decide
def m347_226 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e347_226 : Edge c347 c226 m347_226 := by constructor <;> decide
def m347_110 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e347_110 : Edge c347 c110 m347_110 := by constructor <;> decide
theorem floor347 : Floor c347 9 := by
  apply protectedBranch source c347.P c347.N (decode 254272) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 254272, q = 6 ∨ q = 8 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e347_346 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor346 k x net fit)
    · refine ⟨_,goodChild e347_344 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor344 k x net fit)
    · refine ⟨_,goodChild e347_333 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor333 k x net fit)
    · refine ⟨_,goodChild e347_318 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor318 k x net fit)
    · refine ⟨_,goodChild e347_286 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor286 k x net fit)
    · refine ⟨_,goodChild e347_226 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor226 k x net fit)
    · refine ⟨_,goodChild e347_110 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor110 k x net fit)
  · exact pairExcluded 255808 254272 [8256, 8704, 16640, 17408, 33024, 33280, 66048, 66560, 131136, 132096] [1856, 9472, 16960, 33856, 41984, 65856, 90112, 114752, 131840, 147968, 188416, 205056, 229376] validBranch255808 (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
