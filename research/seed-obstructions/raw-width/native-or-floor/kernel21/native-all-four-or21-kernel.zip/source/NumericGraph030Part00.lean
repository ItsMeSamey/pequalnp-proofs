import Branch257984
import NumericGraph009
import NumericGraph021
import NumericGraph024
import NumericGraph027
import NumericGraph028
import NumericGraph029
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c360 : Chart := ⟨[8256, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120],[1856, 3584, 9472, 11520, 19008, 33856, 41984, 67904, 76032, 84032, 92160, 114752, 131840, 147968, 188416, 205056, 229376]⟩
def m360_357 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e360_357 : Edge c360 c357 m360_357 := by constructor <;> decide
theorem floor360 : Floor c360 10 := by
  have up := refundEdge e360_357 floor357 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c361 : Chart := ⟨[8196, 8256, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 131136, 132096, 133120],[1348, 1796, 1856, 3332, 3588, 9472, 11520, 18948, 19008, 33860, 41984, 67908, 76032, 84036, 92160, 114756, 131844, 147972, 180228, 188416, 196868, 205056, 229380]⟩
def m361_360 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e361_360 : Edge c361 c360 m361_360 := by constructor <;> decide
theorem floor361 : Floor c361 11 := by
  have up := refundEdge e361_360 floor360 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c362 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120],[1792, 3712, 9472, 11520, 18944, 33920, 41984, 67968, 76032, 92160, 114688, 131968, 147968, 188416, 196992, 205056, 229504]⟩
def m362_357 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e362_357 : Edge c362 c357 m362_357 := by constructor <;> decide
theorem floor362 : Floor c362 10 := by
  have up := refundEdge e362_357 floor357 8320 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)

end TightRow.Protected.Numeric
