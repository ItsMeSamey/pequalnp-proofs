import Branch124800
import NumericGraph003
import NumericGraph006
import NumericGraph007
import NumericGraph008
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c108 : Chart := ⟨[8704, 16640, 17408, 33024, 33280, 66048, 66560],[512, 1792, 9472, 16896, 41984, 57344, 73984, 90112, 114688]⟩
def m108_93 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e108_93 : Edge c108 c93 m108_93 := by constructor <;> decide
theorem floor108 : Floor c108 6 := by
  have up := refundEdge e108_93 floor93 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c109 : Chart := ⟨[8196, 8704, 16640, 17408, 33024, 33280, 66048, 66560],[1796, 9472, 16900, 33796, 41984, 57344, 65796, 73984, 90112, 114692]⟩
def m109_108 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e109_108 : Edge c109 c108 m109_108 := by constructor <;> decide
theorem floor109 : Floor c109 7 := by
  have up := refundEdge e109_108 floor108 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c110 : Chart := ⟨[8256, 8704, 16640, 17408, 33024, 33280, 66048, 66560],[1856, 9472, 16960, 33856, 41984, 57344, 65856, 73984, 90112, 114752]⟩
def m110_108 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e110_108 : Edge c110 c108 m110_108 := by constructor <;> decide
theorem floor110 : Floor c110 7 := by
  have up := refundEdge e110_108 floor108 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c111 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560],[896, 1664, 1792, 9472, 16896, 33920, 41984, 57344, 65920, 73984, 90112, 98432, 114688]⟩
def m111_108 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e111_108 : Edge c111 c108 m111_108 := by constructor <;> decide
def m111_107 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e111_107 : Edge c111 c107 m111_107 := by constructor <;> decide
def m111_106 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e111_106 : Edge c111 c106 m111_106 := by constructor <;> decide
def m111_94 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e111_94 : Edge c111 c94 m111_94 := by constructor <;> decide
def m111_72 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e111_72 : Edge c111 c72 m111_72 := by constructor <;> decide
def m111_36 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e111_36 : Edge c111 c36 m111_36 := by constructor <;> decide
theorem floor111 : Floor c111 8 := by
  apply protectedBranch source c111.P c111.N (decode 107904) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 107904, q = 7 ∨ q = 8 ∨ q = 10 ∨ q = 13 ∨ q = 15 ∨ q = 16 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e111_108 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor108 k x net fit)
    · refine ⟨_,goodChild e111_107 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor107 k x net fit)
    · refine ⟨_,goodChild e111_106 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor106 k x net fit)
    · refine ⟨_,goodChild e111_94 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor94 k x net fit)
    · refine ⟨_,goodChild e111_72 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor72 k x net fit)
    · refine ⟨_,goodChild e111_36 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor36 k x net fit)
  · exact pairExcluded 124800 107904 [8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560] [896, 1664, 1792, 9472, 16896, 33920, 41984, 57344, 65920, 73984, 90112, 98432, 114688] validBranch124800 (by decide) (by decide) (by decide)
def c112 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560],[3712, 11264, 18944, 33920, 41984, 57344, 67712, 92160, 98432, 114688]⟩
def m112_107 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e112_107 : Edge c112 c107 m112_107 := by constructor <;> decide
theorem floor112 : Floor c112 7 := by
  have up := refundEdge e112_107 floor107 34816 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c113 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560],[896, 1792, 3712, 11520, 18944, 33920, 41984, 57344, 67968, 76032, 92160, 98432, 114688]⟩
def m113_111 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e113_111 : Edge c113 c111 m113_111 := by constructor <;> decide
theorem floor113 : Floor c113 9 := by
  have up := refundEdge e113_111 floor111 34816 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c114 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560],[896, 1856, 3712, 9472, 11520, 19008, 33984, 41984, 57344, 68032, 76032, 84032, 92160, 98496, 114752]⟩
def m114_113 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e114_113 : Edge c114 c113 m114_113 := by constructor <;> decide
theorem floor114 : Floor c114 10 := by
  have up := refundEdge e114_113 floor113 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c115 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 66048, 69632],[4992, 12544, 20992, 36992, 61440, 65920, 73984, 90112, 98432, 114688]⟩
def m115_106 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e115_106 : Edge c115 c106 m115_106 := by constructor <;> decide
theorem floor115 : Floor c115 7 := by
  have up := refundEdge e115_106 floor106 69632 65920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c116 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632],[1664, 1792, 4992, 13568, 20992, 38016, 46080, 61440, 65920, 73984, 90112, 98432, 114688]⟩
def m116_111 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e116_111 : Edge c116 c111 m116_111 := by constructor <;> decide
theorem floor116 : Floor c116 9 := by
  have up := refundEdge e116_111 floor111 69632 65920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c117 : Chart := ⟨[8196, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632],[1664, 1796, 4992, 9472, 13568, 20996, 38020, 46080, 53252, 61440, 65924, 73984, 90112, 98436, 114692]⟩
def m117_116 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e117_116 : Edge c117 c116 m117_116 := by constructor <;> decide
theorem floor117 : Floor c117 10 := by
  have up := refundEdge e117_116 floor116 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c118 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632],[1792, 3712, 4992, 15616, 23040, 30720, 33920, 38016, 46080, 61440, 67968, 76032, 92160, 98432, 114688]⟩
def m118_116 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, some 12, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e118_116 : Edge c118 c116 m118_116 := by constructor <;> decide
theorem floor118 : Floor c118 10 := by
  have up := refundEdge e118_116 floor116 34816 33920 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c119 : Chart := ⟨[131136],[64, 131072]⟩
theorem floor119 : Floor c119 0 := fun _ _ _ _ => Nat.zero_le _

end TightRow.Protected.Numeric
