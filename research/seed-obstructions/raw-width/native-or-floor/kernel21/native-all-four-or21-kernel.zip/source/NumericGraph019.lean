import Branch190400
import Branch190912
import Branch191424
import NumericGraph003
import NumericGraph013
import NumericGraph014
import NumericGraph015
import NumericGraph016
import NumericGraph017
import NumericGraph018
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c228 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 131136, 132096],[448, 1664, 1856, 9472, 16960, 33984, 41984, 49216, 131968, 139520, 147968, 163968, 188416]⟩
def m228_227 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e228_227 : Edge c228 c227 m228_227 := by constructor <;> decide
def m228_226 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e228_226 : Edge c228 c226 m228_226 := by constructor <;> decide
def m228_224 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e228_224 : Edge c228 c224 m228_224 := by constructor <;> decide
def m228_221 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e228_221 : Edge c228 c221 m228_221 := by constructor <;> decide
def m228_219 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e228_219 : Edge c228 c219 m228_219 := by constructor <;> decide
def m228_156 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e228_156 : Edge c228 c156 m228_156 := by constructor <;> decide
def m228_37 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e228_37 : Edge c228 c37 m228_37 := by constructor <;> decide
theorem floor228 : Floor c228 9 := by
  apply protectedBranch source c228.P c228.N (decode 165824) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 165824, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 15 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e228_227 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor227 k x net fit)
    · refine ⟨_,goodChild e228_226 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor226 k x net fit)
    · refine ⟨_,goodChild e228_224 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor224 k x net fit)
    · refine ⟨_,goodChild e228_221 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor221 k x net fit)
    · refine ⟨_,goodChild e228_219 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor219 k x net fit)
    · refine ⟨_,goodChild e228_156 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor156 k x net fit)
    · refine ⟨_,goodChild e228_37 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor37 k x net fit)
  · exact pairExcluded 190400 165824 [8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 131136, 132096] [448, 1664, 1856, 9472, 16960, 33984, 41984, 49216, 131968, 139520, 147968, 163968, 188416] validBranch190400 (by decide) (by decide) (by decide)
def c229 : Chart := ⟨[8256, 8320, 16512, 34816, 131136, 133120],[128, 2240, 18496, 26624, 32960, 49216, 163968, 188416]⟩
def m229_178 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e229_178 : Edge c229 c178 m229_178 := by constructor <;> decide
theorem floor229 : Floor c229 5 := by
  have up := refundEdge e229_178 floor178 16512 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c230 : Chart := ⟨[8256, 16640, 33024, 34816, 131136, 133120],[320, 2368, 10496, 18496, 26624, 49216, 139520, 188416]⟩
def m230_202 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e230_202 : Edge c230 c202 m230_202 := by constructor <;> decide
theorem floor230 : Floor c230 5 := by
  have up := refundEdge e230_202 floor202 8256 320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c231 : Chart := ⟨[8320, 16512, 16640, 33024, 34816, 133120],[128, 2432, 10496, 26624, 131456, 139520, 163968, 188416]⟩
def m231_203 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e231_203 : Edge c231 c203 m231_203 := by constructor <;> decide
theorem floor231 : Floor c231 5 := by
  have up := refundEdge e231_203 floor203 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c232 : Chart := ⟨[8256, 8320, 16512, 16640, 33024, 34816, 131136, 133120],[2496, 10496, 18496, 26624, 32960, 49216, 131456, 139520, 163968, 188416]⟩
def m232_231 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e232_231 : Edge c232 c231 m232_231 := by constructor <;> decide
def m232_230 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e232_230 : Edge c232 c230 m232_230 := by constructor <;> decide
def m232_229 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e232_229 : Edge c232 c229 m232_229 := by constructor <;> decide
def m232_217 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e232_217 : Edge c232 c217 m232_217 := by constructor <;> decide
def m232_204 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e232_204 : Edge c232 c204 m232_204 := by constructor <;> decide
def m232_181 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e232_181 : Edge c232 c181 m232_181 := by constructor <;> decide
def m232_158 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e232_158 : Edge c232 c158 m232_158 := by constructor <;> decide
def m232_39 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e232_39 : Edge c232 c39 m232_39 := by constructor <;> decide
theorem floor232 : Floor c232 7 := by
  apply protectedBranch source c232.P c232.N (decode 190912) 7
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 190912, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e232_231 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor231 k x net fit)
    · refine ⟨_,goodChild e232_230 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor230 k x net fit)
    · refine ⟨_,goodChild e232_229 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor229 k x net fit)
    · refine ⟨_,goodChild e232_217 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor217 k x net fit)
    · refine ⟨_,goodChild e232_204 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor204 k x net fit)
    · refine ⟨_,goodChild e232_181 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor181 k x net fit)
    · refine ⟨_,goodChild e232_158 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor158 k x net fit)
    · refine ⟨_,goodChild e232_39 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor39 k x net fit)
  · exact pairExcluded 190912 190912 [8256, 8320, 16512, 16640, 33024, 34816, 131136, 133120] [2496, 10496, 18496, 26624, 32960, 49216, 131456, 139520, 163968, 188416] validBranch190912 (by decide) (by decide) (by decide)
def c233 : Chart := ⟨[8196, 8256, 8320, 16512, 16640, 33024, 34816, 131136, 133120],[2372, 2436, 2496, 8448, 10496, 18500, 26624, 32960, 49220, 131460, 139520, 163972, 180228, 188416]⟩
def m233_232 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e233_232 : Edge c233 c232 m233_232 := by constructor <;> decide
theorem floor233 : Floor c233 8 := by
  have up := refundEdge e233_232 floor232 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 8 ≤ 8).trans (up k x net fit)
def c234 : Chart := ⟨[8320, 8704, 16512, 33280, 34816, 133120],[640, 2688, 18944, 26624, 131712, 147968, 163968, 188416]⟩
def m234_187 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e234_187 : Edge c234 c187 m234_187 := by constructor <;> decide
theorem floor234 : Floor c234 5 := by
  have up := refundEdge e234_187 floor187 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c235 : Chart := ⟨[8256, 8320, 8704, 16512, 33280, 34816, 131136, 133120],[640, 2240, 2688, 19008, 26624, 32960, 49216, 131712, 147968, 163968, 188416]⟩
def m235_188 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e235_188 : Edge c235 c188 m235_188 := by constructor <;> decide
theorem floor235 : Floor c235 7 := by
  have up := refundEdge e235_188 floor188 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c236 : Chart := ⟨[8256, 8704, 16640, 33024, 33280, 34816, 131136, 133120],[768, 832, 2368, 10496, 19008, 26624, 49216, 131840, 139520, 147968, 188416]⟩
def m236_189 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e236_189 : Edge c236 c189 m236_189 := by constructor <;> decide
theorem floor236 : Floor c236 7 := by
  have up := refundEdge e236_189 floor189 16640 768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c237 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 34816, 133120],[2432, 2688, 10496, 18944, 26624, 131968, 139520, 147968, 163968, 188416]⟩
def m237_41 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e237_41 : Edge c237 c41 m237_41 := by constructor <;> decide
theorem floor237 : Floor c237 7 := by
  have up := refundEdge e237_41 floor41 133120 2432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c238 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 131136, 133120],[832, 2496, 2688, 10496, 19008, 26624, 32960, 49216, 131968, 139520, 147968, 163968, 188416]⟩
def m238_237 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e238_237 : Edge c238 c237 m238_237 := by constructor <;> decide
def m238_236 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e238_236 : Edge c238 c236 m238_236 := by constructor <;> decide
def m238_235 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e238_235 : Edge c238 c235 m238_235 := by constructor <;> decide
def m238_232 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e238_232 : Edge c238 c232 m238_232 := by constructor <;> decide
def m238_219 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e238_219 : Edge c238 c219 m238_219 := by constructor <;> decide
def m238_191 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e238_191 : Edge c238 c191 m238_191 := by constructor <;> decide
def m238_42 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e238_42 : Edge c238 c42 m238_42 := by constructor <;> decide
theorem floor238 : Floor c238 9 := by
  apply protectedBranch source c238.P c238.N (decode 150464) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 150464, q = 6 ∨ q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 11 ∨ q = 14 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e238_237 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor237 k x net fit)
    · refine ⟨_,goodChild e238_236 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor236 k x net fit)
    · refine ⟨_,goodChild e238_235 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor235 k x net fit)
    · refine ⟨_,goodChild e238_232 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor232 k x net fit)
    · refine ⟨_,goodChild e238_219 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor219 k x net fit)
    · refine ⟨_,goodChild e238_191 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor191 k x net fit)
    · refine ⟨_,goodChild e238_42 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor42 k x net fit)
  · exact pairExcluded 191424 150464 [8256, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 131136, 133120] [832, 2496, 2688, 10496, 19008, 26624, 32960, 49216, 131968, 139520, 147968, 163968, 188416] validBranch191424 (by decide) (by decide) (by decide)
def c239 : Chart := ⟨[8320, 16512, 17408, 34816, 132096, 133120],[128, 3200, 11264, 26624, 33920, 41984, 163968, 188416]⟩
def m239_206 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e239_206 : Edge c239 c206 m239_206 := by constructor <;> decide
theorem floor239 : Floor c239 5 := by
  have up := refundEdge e239_206 floor206 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)

end TightRow.Protected.Numeric
