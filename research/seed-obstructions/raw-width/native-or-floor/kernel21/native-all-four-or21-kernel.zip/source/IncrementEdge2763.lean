import IncrementRootGroup0
import IncrementRootGroup1
import IncrementRootGroup2
import IncrementRootGroup3
import IncrementRootGroup4

namespace TightRow.Protected.Numeric.Increment
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def allRootUp := (rootUp0 ++ (rootUp1 ++ rootUp2))
private theorem allRootUpOK : ∀ z ∈ allRootUp, RootUp z := by
  intro z hz
  simp only [allRootUp,List.mem_append] at hz
  rcases hz with hz | hz | hz
  · exact rootUp0OK z hz
  · exact rootUp1OK z hz
  · exact rootUp2OK z hz
def allRootDown := (rootDown0 ++ (rootDown1 ++ (rootDown2 ++ (rootDown3 ++ (rootDown4 ++ (rootDown5 ++ (rootDown6 ++ (rootDown7 ++ (rootDown8 ++ (rootDown9 ++ (rootDown10 ++ (rootDown11 ++ (rootDown12 ++ (rootDown13 ++ (rootDown14 ++ rootDown15)))))))))))))))
private theorem allRootDownOK : ∀ z ∈ allRootDown, RootDown z := by
  intro z hz
  simp only [allRootDown,List.mem_append] at hz
  rcases hz with hz | hz | hz | hz | hz | hz | hz | hz | hz | hz | hz | hz | hz | hz | hz | hz
  · exact rootDown0OK z hz
  · exact rootDown1OK z hz
  · exact rootDown2OK z hz
  · exact rootDown3OK z hz
  · exact rootDown4OK z hz
  · exact rootDown5OK z hz
  · exact rootDown6OK z hz
  · exact rootDown7OK z hz
  · exact rootDown8OK z hz
  · exact rootDown9OK z hz
  · exact rootDown10OK z hz
  · exact rootDown11OK z hz
  · exact rootDown12OK z hz
  · exact rootDown13OK z hz
  · exact rootDown14OK z hz
  · exact rootDown15OK z hz
theorem e2763_2762 : Edge c2763 c2762 m2763_2762 := by
  change Edge flatRoot c2762 m2763_2762
  exact edgeByPairs flatRoot c2762 m2763_2762 allRootUp allRootDown rfl rfl (by decide) (by decide) allRootUpOK allRootDownOK
theorem lift2763 {d : Nat} (low : Floor c2762 d) : Floor c2763 (d+1) := by
  exact refundEdge e2763_2762 low 262146 1311489 (by decide) (by decide) (by decide)
end TightRow.Protected.Numeric.Increment
