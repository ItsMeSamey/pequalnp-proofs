import NumericGraph002
import NumericGraph005
import NumericGraph007
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c96 : Chart := ⟨[16512, 17408, 33280, 34816, 66048, 66560],[3712, 18944, 33920, 67712, 83968, 98432, 114688]⟩
def m96_95 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e96_95 : Edge c96 c95 m96_95 := by constructor <;> decide
theorem floor96 : Floor c96 5 := by
  have up := refundEdge e96_95 floor95 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c97 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560],[1792, 3328, 3584, 18944, 33792, 67840, 83968, 114688]⟩
def m97_93 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e97_93 : Edge c97 c93 m97_93 := by constructor <;> decide
theorem floor97 : Floor c97 6 := by
  have up := refundEdge e97_93 floor93 34816 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c98 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 66048, 66560],[896, 1792, 3328, 3712, 18944, 33920, 67968, 83968, 98432, 114688]⟩
def m98_97 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e98_97 : Edge c98 c97 m98_97 := by constructor <;> decide
theorem floor98 : Floor c98 7 := by
  have up := refundEdge e98_97 floor97 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c99 : Chart := ⟨[16640, 33024, 33280, 66048, 69632],[4864, 20992, 53248, 65792, 114688]⟩
def m99_90 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e99_90 : Edge c99 c90 m99_90 := by constructor <;> decide
theorem floor99 : Floor c99 4 := by
  have up := refundEdge e99_90 floor90 69632 65792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c100 : Chart := ⟨[16512, 16640, 33024, 33280, 66048, 69632],[4992, 16896, 20992, 36992, 53248, 65920, 98432, 114688]⟩
def m100_99 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, some 12, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e100_99 : Edge c100 c99 m100_99 := by constructor <;> decide
theorem floor100 : Floor c100 5 := by
  have up := refundEdge e100_99 floor99 16512 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c101 : Chart := ⟨[16640, 17408, 33024, 66560, 69632],[5376, 37888, 53248, 65792, 114688]⟩
def m101_91 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e101_91 : Edge c101 c91 m101_91 := by constructor <;> decide
theorem floor101 : Floor c101 4 := by
  have up := refundEdge e101_91 floor91 69632 65792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c102 : Chart := ⟨[16640, 17408, 33024, 33280, 66048, 66560, 69632],[1792, 4864, 5376, 20992, 37888, 53248, 65792, 114688]⟩
def m102_93 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e102_93 : Edge c102 c93 m102_93 := by constructor <;> decide
theorem floor102 : Floor c102 6 := by
  have up := refundEdge e102_93 floor93 69632 65792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c103 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 66048, 66560, 69632],[1664, 1792, 4992, 5376, 16896, 20992, 38016, 53248, 65920, 98432, 114688]⟩
def m103_102 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e103_102 : Edge c103 c102 m103_102 := by constructor <;> decide
theorem floor103 : Floor c103 7 := by
  have up := refundEdge e103_102 floor102 16512 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c104 : Chart := ⟨[16640, 17408, 33024, 34816, 66560, 69632],[7424, 22528, 33792, 37888, 53248, 67840, 83968, 114688]⟩
def m104_101 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, some 12, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e104_101 : Edge c104 c101 m104_101 := by constructor <;> decide
theorem floor104 : Floor c104 5 := by
  have up := refundEdge e104_101 floor101 34816 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c105 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 66048, 66560, 69632],[1792, 3584, 4864, 7424, 23040, 33792, 37888, 53248, 67840, 83968, 114688]⟩
def m105_102 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, some 12, none, some 14, some 15, some 16, none, none, none, none, none]
private theorem e105_102 : Edge c105 c102 m105_102 := by constructor <;> decide
theorem floor105 : Floor c105 7 := by
  have up := refundEdge e105_102 floor102 34816 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c106 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 66048],[640, 896, 16896, 57344, 65920, 73984, 90112, 98432, 114688]⟩
def m106_31 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e106_31 : Edge c106 c31 m106_31 := by constructor <;> decide
theorem floor106 : Floor c106 6 := by
  have up := refundEdge e106_31 floor31 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c107 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 66048, 66560],[640, 1664, 16896, 33920, 41984, 57344, 90112, 98432, 114688]⟩
def m107_67 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e107_67 : Edge c107 c67 m107_67 := by constructor <;> decide
theorem floor107 : Floor c107 6 := by
  have up := refundEdge e107_67 floor67 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)

end TightRow.Protected.Numeric
