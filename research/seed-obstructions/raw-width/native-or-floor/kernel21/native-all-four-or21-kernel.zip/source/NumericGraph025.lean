import Branch232960
import NumericGraph007
import NumericGraph014
import NumericGraph021
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c300 : Chart := ⟨[33280, 66048, 66560, 132096],[512, 1536, 33792, 131584, 229376]⟩
def m300_257 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e300_257 : Edge c300 c257 m300_257 := by constructor <;> decide
theorem floor300 : Floor c300 3 := by
  have up := refundEdge e300_257 floor257 33280 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c301 : Chart := ⟨[33024, 33280, 66048, 66560, 132096],[1792, 33792, 131840, 196864, 229376]⟩
def m301_300 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e301_300 : Edge c301 c300 m301_300 := by constructor <;> decide
theorem floor301 : Floor c301 4 := by
  have up := refundEdge e301_300 floor300 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c302 : Chart := ⟨[33024, 33280, 66048, 66560, 131073, 132096],[1793, 33793, 65793, 98305, 131328, 131840, 196864, 229376]⟩
def m302_301 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e302_301 : Edge c302 c301 m302_301 := by constructor <;> decide
theorem floor302 : Floor c302 5 := by
  have up := refundEdge e302_301 floor301 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c303 : Chart := ⟨[33280, 34816, 66048, 133120],[512, 2560, 67584, 131584, 229376]⟩
def m303_168 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e303_168 : Edge c303 c168 m303_168 := by constructor <;> decide
theorem floor303 : Floor c303 3 := by
  have up := refundEdge e303_168 floor168 66048 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c304 : Chart := ⟨[34816, 66560, 132096, 133120],[2048, 3072, 33792, 67584, 229376]⟩
def m304_259 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e304_259 : Edge c304 c259 m304_259 := by constructor <;> decide
theorem floor304 : Floor c304 3 := by
  have up := refundEdge e304_259 floor259 34816 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c305 : Chart := ⟨[33280, 34816, 66048, 66560, 132096, 133120],[3584, 33792, 67584, 131584, 229376]⟩
def m305_304 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e305_304 : Edge c305 c304 m305_304 := by constructor <;> decide
def m305_303 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e305_303 : Edge c305 c303 m305_303 := by constructor <;> decide
def m305_300 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e305_300 : Edge c305 c300 m305_300 := by constructor <;> decide
def m305_260 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e305_260 : Edge c305 c260 m305_260 := by constructor <;> decide
def m305_172 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e305_172 : Edge c305 c172 m305_172 := by constructor <;> decide
def m305_86 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e305_86 : Edge c305 c86 m305_86 := by constructor <;> decide
theorem floor305 : Floor c305 5 := by
  apply protectedBranch source c305.P c305.N (decode 232960) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 232960, q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 15 ∨ q = 16 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e305_304 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor304 k x net fit)
    · refine ⟨_,goodChild e305_303 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor303 k x net fit)
    · refine ⟨_,goodChild e305_300 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor300 k x net fit)
    · refine ⟨_,goodChild e305_260 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor260 k x net fit)
    · refine ⟨_,goodChild e305_172 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor172 k x net fit)
    · refine ⟨_,goodChild e305_86 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor86 k x net fit)
  · exact pairExcluded 232960 232960 [33280, 34816, 66048, 66560, 132096, 133120] [3584, 33792, 67584, 131584, 229376] validBranch232960 (by decide) (by decide) (by decide)
def c306 : Chart := ⟨[33280, 34816, 66048, 66560, 131073, 132096, 133120],[1537, 2561, 3584, 33793, 67585, 98305, 131072, 131584, 229376]⟩
def m306_305 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e306_305 : Edge c306 c305 m306_305 := by constructor <;> decide
theorem floor306 : Floor c306 6 := by
  have up := refundEdge e306_305 floor305 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c307 : Chart := ⟨[33280, 34816, 66048, 66560, 131136, 132096, 133120],[1600, 2624, 3584, 33856, 67648, 98368, 131072, 131584, 229376]⟩
def m307_305 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e307_305 : Edge c307 c305 m307_305 := by constructor <;> decide
theorem floor307 : Floor c307 6 := by
  have up := refundEdge e307_305 floor305 131136 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c308 : Chart := ⟨[33024, 33280, 34816, 66048, 66560, 132096, 133120],[1792, 3328, 3584, 33792, 67840, 131840, 196864, 229376]⟩
def m308_305 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e308_305 : Edge c308 c305 m308_305 := by constructor <;> decide
theorem floor308 : Floor c308 6 := by
  have up := refundEdge e308_305 floor305 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c309 : Chart := ⟨[33024, 33280, 34816, 66048, 66560, 131073, 132096, 133120],[1793, 2561, 3328, 3584, 33793, 67841, 98305, 131328, 131840, 196864, 229376]⟩
def m309_308 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e309_308 : Edge c309 c308 m309_308 := by constructor <;> decide
theorem floor309 : Floor c309 7 := by
  have up := refundEdge e309_308 floor308 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c310 : Chart := ⟨[33280, 34816, 66048, 69632, 133120],[6656, 65536, 67584, 135680, 167936, 229376]⟩
def m310_303 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e310_303 : Edge c310 c303 m310_303 := by constructor <;> decide
theorem floor310 : Floor c310 4 := by
  have up := refundEdge e310_303 floor303 69632 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c311 : Chart := ⟨[33280, 34816, 66048, 69632, 131073, 133120],[6657, 36865, 67585, 98305, 131072, 135680, 167936, 229376]⟩
def m311_310 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, some 12, none, none, some 15, some 16, some 17, none, none, none, none]
private theorem e311_310 : Edge c311 c310 m311_310 := by constructor <;> decide
theorem floor311 : Floor c311 5 := by
  have up := refundEdge e311_310 floor310 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)

end TightRow.Protected.Numeric
