import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short91776
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 16512, 17408, 66048, 66560]
def n : List Nat := [1664, 9216, 16896, 65664, 90112]
def pp := p.map (canonical 91776)
def nn := n.map (canonical 91776)
def parts : List Nat := [0, 128, 512, 1024, 8192, 16384, 65536, 8320, 8704, 16512, 17408, 66048, 66560]
def g : ShortGrid := [(0,[(128,309489732259886631936327937), (512,79538861190790864407636279553), (1024,238307093840112706590972510721), (8192,1), (8320,256), (8704,0), (16384,158458742917061955551399903233), (16512,8590000128), (17408,8589935104), (65536,316917485834123911102799806465), (66048,17179934976), (66560,17180001024)]), (128,[(512,17230266368), (1024,21525233664), (8192,1099511627776), (8704,0), (16384,8590000128), (17408,8590000128), (65536,17179934720), (66048,17179934720), (66560,17179934720)]), (512,[(1024,12918522112), (8192,282574488338432), (8320,256), (16384,8590000384), (16512,65536), (17408,8590000384), (65536,17179934976), (66560,17179934976)]), (1024,[(8192,848822976643072), (8320,256), (8704,0), (16384,846623953388032), (16512,65536), (65536,17180001024), (66048,65792)]), (8192,[(16384,12901679104), (16512,16777216), (17408,12901679104), (65536,21491613696), (66048,4311744512), (66560,21491613696)]), (8320,[(16384,256), (17408,256), (65536,256), (66048,256), (66560,256)]), (8704,[(16384,0), (16512,0), (17408,0), (65536,0), (66560,0)]), (16384,[(65536,17213424128), (66048,65792), (66560,12918456832)]), (16512,[(65536,65536), (66048,65536), (66560,65536)]), (17408,[(65536,512), (66048,65792)])]
private theorem row0 : parts.all (shortPair g pp nn 91776 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 91776 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 91776 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 91776 1024) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 91776 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 91776 16384) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 91776 65536) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 91776 8320) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 91776 8704) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 91776 16512) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 91776 17408) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 91776 66048) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 91776 66560) = true := by decide
theorem full : checkArms 91776 91776 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 512, 1024, 8192, 16384, 65536, 8320, 8704, 16512, 17408, 66048, 66560] : List Nat).all (fun i => parts.all (shortPair g pp nn 91776 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short91776
theorem validBranch91776 : checkArms 91776 91776 [8320, 8704, 16512, 17408, 66048, 66560] [1664, 9216, 16896, 65664, 90112] = true := Short91776.full
end TightRow.Protected.Numeric
