import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c0 : Chart := ⟨[16512],[128, 16384]⟩
theorem floor0 : Floor c0 0 := fun _ _ _ _ => Nat.zero_le _
def c1 : Chart := ⟨[8320, 16512],[128, 24576]⟩
def m1_0 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, none, some 14, none, none, none, none, none, none, none]
private theorem e1_0 : Edge c1 c0 m1_0 := by constructor <;> decide
theorem floor1 : Floor c1 1 := by
  have up := refundEdge e1_0 floor0 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c2 : Chart := ⟨[8320, 16512, 16640],[384, 8448, 16384, 24576]⟩
def m2_1 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e2_1 : Edge c2 c1 m2_1 := by constructor <;> decide
theorem floor2 : Floor c2 2 := by
  have up := refundEdge e2_1 floor1 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c3 : Chart := ⟨[8196, 8320, 16512, 16640],[388, 8448, 16388, 24576]⟩
def m3_2 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e3_2 : Edge c3 c2 m3_2 := by constructor <;> decide
theorem floor3 : Floor c3 3 := by
  have up := refundEdge e3_2 floor2 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c4 : Chart := ⟨[8320, 8704, 16512],[640, 8192, 16896, 24576]⟩
def m4_1 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e4_1 : Edge c4 c1 m4_1 := by constructor <;> decide
theorem floor4 : Floor c4 2 := by
  have up := refundEdge e4_1 floor1 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c5 : Chart := ⟨[8320, 8704, 16512, 16640],[896, 8448, 16896, 24576]⟩
def m5_4 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e5_4 : Edge c5 c4 m5_4 := by constructor <;> decide
theorem floor5 : Floor c5 3 := by
  have up := refundEdge e5_4 floor4 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c6 : Chart := ⟨[8320, 16512, 17408],[1152, 9216, 16384, 24576]⟩
def m6_1 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e6_1 : Edge c6 c1 m6_1 := by constructor <;> decide
theorem floor6 : Floor c6 2 := by
  have up := refundEdge e6_1 floor1 17408 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c7 : Chart := ⟨[8256, 8320, 16512, 17408],[1216, 9216, 16448, 24576]⟩
def m7_6 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e7_6 : Edge c7 c6 m7_6 := by constructor <;> decide
theorem floor7 : Floor c7 3 := by
  have up := refundEdge e7_6 floor6 8256 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c8 : Chart := ⟨[8320, 8704, 16512, 17408],[1664, 9216, 16896, 24576]⟩
def m8_6 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e8_6 : Edge c8 c6 m8_6 := by constructor <;> decide
theorem floor8 : Floor c8 3 := by
  have up := refundEdge e8_6 floor6 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c9 : Chart := ⟨[33024],[256, 32768]⟩
theorem floor9 : Floor c9 0 := fun _ _ _ _ => Nat.zero_le _
def c10 : Chart := ⟨[33280],[512, 32768]⟩
theorem floor10 : Floor c10 0 := fun _ _ _ _ => Nat.zero_le _
def c11 : Chart := ⟨[8704, 33280],[512, 40960]⟩
def m11_10 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, none, none, some 15, none, none, none, none, none, none]
private theorem e11_10 : Edge c11 c10 m11_10 := by constructor <;> decide
theorem floor11 : Floor c11 1 := by
  have up := refundEdge e11_10 floor10 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)

end TightRow.Protected.Numeric
