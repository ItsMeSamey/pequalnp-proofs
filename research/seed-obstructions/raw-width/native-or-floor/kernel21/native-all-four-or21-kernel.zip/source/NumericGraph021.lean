import Branch192384
import NumericGraph003
import NumericGraph010
import NumericGraph018
import NumericGraph019
import NumericGraph020
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c252 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 132096, 133120],[1792, 2432, 3712, 11520, 18944, 26624, 33920, 41984, 131968, 139520, 147968, 163968, 188416]⟩
def m252_250 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e252_250 : Edge c252 c250 m252_250 := by constructor <;> decide
def m252_247 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e252_247 : Edge c252 c247 m252_247 := by constructor <;> decide
def m252_243 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e252_243 : Edge c252 c243 m252_243 := by constructor <;> decide
def m252_237 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e252_237 : Edge c252 c237 m252_237 := by constructor <;> decide
def m252_227 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e252_227 : Edge c252 c227 m252_227 := by constructor <;> decide
def m252_216 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e252_216 : Edge c252 c216 m252_216 := by constructor <;> decide
def m252_44 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e252_44 : Edge c252 c44 m252_44 := by constructor <;> decide
theorem floor252 : Floor c252 9 := by
  apply protectedBranch source c252.P c252.N (decode 143232) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 143232, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e252_250 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor250 k x net fit)
    · refine ⟨_,goodChild e252_247 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor247 k x net fit)
    · refine ⟨_,goodChild e252_243 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor243 k x net fit)
    · refine ⟨_,goodChild e252_237 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor237 k x net fit)
    · refine ⟨_,goodChild e252_227 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor227 k x net fit)
    · refine ⟨_,goodChild e252_216 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor216 k x net fit)
    · refine ⟨_,goodChild e252_44 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor44 k x net fit)
  · exact pairExcluded 192384 143232 [8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 132096, 133120] [1792, 2432, 3712, 11520, 18944, 26624, 33920, 41984, 131968, 139520, 147968, 163968, 188416] validBranch192384 (by decide) (by decide) (by decide)
def c253 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120],[1856, 2496, 3712, 9472, 11520, 19008, 26624, 33984, 41984, 49216, 131968, 139520, 147968, 163968, 188416]⟩
def m253_252 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e253_252 : Edge c253 c252 m253_252 := by constructor <;> decide
theorem floor253 : Floor c253 10 := by
  have up := refundEdge e253_252 floor252 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c254 : Chart := ⟨[8196, 8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120],[1348, 1796, 1856, 2372, 2436, 2496, 3204, 3332, 3588, 3712, 9472, 11520, 18500, 18948, 19008, 26624, 33860, 33924, 33984, 41984, 49220, 131460, 131844, 131968, 139520, 147972, 163972, 180228, 188416]⟩
def m254_253 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e254_253 : Edge c254 c253 m254_253 := by constructor <;> decide
theorem floor254 : Floor c254 11 := by
  have up := refundEdge e254_253 floor253 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c255 : Chart := ⟨[66560, 132096],[1024, 196608]⟩
def m255_120 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, none, none, none, some 17, none, none, none, none]
private theorem e255_120 : Edge c255 c120 m255_120 := by constructor <;> decide
theorem floor255 : Floor c255 1 := by
  have up := refundEdge e255_120 floor120 66560 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c256 : Chart := ⟨[66560, 131136, 132096],[1088, 65600, 131072, 196608]⟩
def m256_255 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e256_255 : Edge c256 c255 m256_255 := by constructor <;> decide
theorem floor256 : Floor c256 2 := by
  have up := refundEdge e256_255 floor255 131136 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c257 : Chart := ⟨[66048, 66560, 132096],[1536, 65536, 131584, 196608]⟩
def m257_255 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e257_255 : Edge c257 c255 m257_255 := by constructor <;> decide
theorem floor257 : Floor c257 2 := by
  have up := refundEdge e257_255 floor255 66048 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c258 : Chart := ⟨[66048, 66560, 131136, 132096],[1600, 65600, 131072, 131584, 196608]⟩
def m258_257 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e258_257 : Edge c258 c257 m258_257 := by constructor <;> decide
theorem floor258 : Floor c258 3 := by
  have up := refundEdge e258_257 floor257 131136 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c259 : Chart := ⟨[66560, 132096, 133120],[3072, 67584, 131072, 196608]⟩
def m259_255 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e259_255 : Edge c259 c255 m259_255 := by constructor <;> decide
theorem floor259 : Floor c259 2 := by
  have up := refundEdge e259_255 floor255 133120 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c260 : Chart := ⟨[66048, 66560, 132096, 133120],[3584, 65536, 67584, 131584, 196608]⟩
def m260_259 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e260_259 : Edge c260 c259 m260_259 := by constructor <;> decide
theorem floor260 : Floor c260 3 := by
  have up := refundEdge e260_259 floor259 66048 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c261 : Chart := ⟨[66560, 69632, 132096],[5120, 65536, 135168, 196608]⟩
def m261_255 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, none, none, some 16, some 17, none, none, none, none]
private theorem e261_255 : Edge c261 c255 m261_255 := by constructor <;> decide
theorem floor261 : Floor c261 2 := by
  have up := refundEdge e261_255 floor255 69632 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c262 : Chart := ⟨[66560, 69632, 131073, 132096],[5121, 65537, 131072, 135168, 196608]⟩
def m262_261 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, none, none, some 16, some 17, none, none, none, none]
private theorem e262_261 : Edge c262 c261 m262_261 := by constructor <;> decide
theorem floor262 : Floor c262 3 := by
  have up := refundEdge e262_261 floor261 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c263 : Chart := ⟨[66560, 69632, 132096, 133120],[7168, 67584, 131072, 135168, 196608]⟩
def m263_261 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, none, none, some 16, some 17, none, none, none, none]
private theorem e263_261 : Edge c263 c261 m263_261 := by constructor <;> decide
theorem floor263 : Floor c263 3 := by
  have up := refundEdge e263_261 floor261 133120 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)

end TightRow.Protected.Numeric
