import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short249600
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120]
def n : List Nat := [1792, 3328, 3584, 18944, 33792, 67840, 83968, 114688, 131840, 147968, 180224, 196864, 229376]
def pp := p.map (canonical 249600)
def nn := n.map (canonical 249600)
def parts : List Nat := [0, 256, 512, 2048, 16384, 65536, 131072, 16640, 66048, 133120]
def g : ShortGrid := [(0,[(256,262022749906830042906359753189307640185601), (512,67251710918989915506339926354772884430455809), (2048,89552796405079835674245394161536949733819393), (16384,1227834020806430640046081), (16640,256), (65536,111505427430449600840755173054626757156864001), (66048,12952273664), (131072,156107598402629441175357164401514709902622721), (133120,17247241216)]), (256,[(512,21558919168), (2048,34494152704), (16384,3298534883328), (65536,21475033088), (66048,21475033088), (131072,30064967680), (133120,30064967680)]), (512,[(2048,34494285056), (16384,1413971953319936), (16640,256), (65536,1412893916529920), (131072,30065100032), (133120,263168)]), (2048,[(16384,1133596488237056), (16640,256), (65536,1133596488238336), (66048,262912), (131072,2260625988257792)]), (16384,[(65536,21525168128), (66048,21525168128), (131072,34410070016), (133120,34410070016)]), (16640,[(65536,256), (66048,256), (131072,256), (133120,256)]), (65536,[(131072,34443625728), (133120,263168)]), (66048,[(131072,262912), (133120,262912)])]
private theorem row0 : parts.all (shortPair g pp nn 215808 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 215808 256) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 215808 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 215808 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 215808 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 215808 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 215808 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 215808 16640) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 215808 66048) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 215808 133120) = true := by decide
theorem full : checkArms 249600 215808 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 256, 512, 2048, 16384, 65536, 131072, 16640, 66048, 133120] : List Nat).all (fun i => parts.all (shortPair g pp nn 215808 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9]
end Short249600
theorem validBranch249600 : checkArms 249600 215808 [16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120] [1792, 3328, 3584, 18944, 33792, 67840, 83968, 114688, 131840, 147968, 180224, 196864, 229376] = true := Short249600.full
end TightRow.Protected.Numeric
