import IncrementRootData

namespace TightRow.Protected.Numeric.Increment
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem rootDown13OK : ∀ z ∈ rootDown13, RootDown z := by decide
theorem rootDown14OK : ∀ z ∈ rootDown14, RootDown z := by decide
theorem rootDown15OK : ∀ z ∈ rootDown15, RootDown z := by decide
end TightRow.Protected.Numeric.Increment
