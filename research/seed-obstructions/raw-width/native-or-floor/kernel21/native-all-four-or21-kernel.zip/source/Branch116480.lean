import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short116480
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [16640, 17408, 33024, 33280, 66048, 66560]
def n : List Nat := [1792, 16896, 33792, 65792, 114688]
def pp := p.map (canonical 116480)
def nn := n.map (canonical 116480)
def parts : List Nat := [0, 256, 512, 1024, 16384, 32768, 65536, 16640, 17408, 33024, 33280, 66048, 66560]
def g : ShortGrid := [(0,[(256,309489732259886631936327937), (512,238307093840112706590972510721), (1024,79538861190790864407636279553), (16384,1), (16640,256), (17408,0), (32768,158458742917061955551399903233), (33024,8590000128), (33280,8589935104), (65536,316917485834123911102799806465), (66048,17180001024), (66560,17179934976)]), (256,[(512,17230266368), (1024,21525233664), (16384,1099511627776), (17408,0), (32768,8590000128), (33280,8590000128), (65536,17179934720), (66048,17179934720), (66560,17179934720)]), (512,[(1024,846623953453312), (16384,848822976643072), (16640,256), (17408,0), (32768,846623953388032), (33024,65536), (65536,17180001024), (66560,65792)]), (1024,[(16384,282574488338432), (16640,256), (32768,8590000384), (33024,65536), (33280,8590000384), (65536,17179934976), (66048,17179934976)]), (16384,[(32768,12901679104), (33024,16777216), (33280,12901679104), (65536,17196646400), (66048,17196646400), (66560,4311744512)]), (16640,[(32768,256), (33280,256), (65536,256), (66048,256), (66560,256)]), (17408,[(32768,0), (33024,0), (33280,0), (65536,0), (66048,0)]), (32768,[(65536,21508391424), (66048,12918456832), (66560,65792)]), (33024,[(65536,65536), (66048,65536), (66560,65536)]), (33280,[(65536,512), (66560,65792)])]
private theorem row0 : parts.all (shortPair g pp nn 116480 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 116480 256) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 116480 512) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 116480 1024) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 116480 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 116480 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 116480 65536) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 116480 16640) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 116480 17408) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 116480 33024) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 116480 33280) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 116480 66048) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 116480 66560) = true := by decide
theorem full : checkArms 116480 116480 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 256, 512, 1024, 16384, 32768, 65536, 16640, 17408, 33024, 33280, 66048, 66560] : List Nat).all (fun i => parts.all (shortPair g pp nn 116480 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short116480
theorem validBranch116480 : checkArms 116480 116480 [16640, 17408, 33024, 33280, 66048, 66560] [1792, 16896, 33792, 65792, 114688] = true := Short116480.full
end TightRow.Protected.Numeric
