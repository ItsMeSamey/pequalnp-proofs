import Branch183552
import NumericGraph002
import NumericGraph011
import NumericGraph014
import NumericGraph016
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c204 : Chart := ⟨[16512, 16640, 33024, 34816, 131136, 133120],[2496, 18496, 32960, 49216, 131456, 163968, 180224]⟩
def m204_203 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e204_203 : Edge c204 c203 m204_203 := by constructor <;> decide
theorem floor204 : Floor c204 5 := by
  have up := refundEdge e204_203 floor203 131136 131456 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c205 : Chart := ⟨[17408, 34816, 132096, 133120],[1024, 3072, 18432, 33792, 180224]⟩
def m205_170 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e205_170 : Edge c205 c170 m205_170 := by constructor <;> decide
theorem floor205 : Floor c205 3 := by
  have up := refundEdge e205_170 floor170 17408 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c206 : Chart := ⟨[16512, 17408, 34816, 132096, 133120],[3200, 18432, 33920, 163968, 180224]⟩
def m206_205 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e206_205 : Edge c206 c205 m206_205 := by constructor <;> decide
theorem floor206 : Floor c206 4 := by
  have up := refundEdge e206_205 floor205 16512 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c207 : Chart := ⟨[16640, 17408, 33024, 34816, 132096, 133120],[3328, 18432, 33792, 131328, 180224]⟩
def m207_205 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e207_205 : Edge c207 c205 m207_205 := by constructor <;> decide
def m207_201 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e207_201 : Edge c207 c201 m207_201 := by constructor <;> decide
def m207_197 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e207_197 : Edge c207 c197 m207_197 := by constructor <;> decide
def m207_171 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e207_171 : Edge c207 c171 m207_171 := by constructor <;> decide
def m207_141 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e207_141 : Edge c207 c141 m207_141 := by constructor <;> decide
def m207_27 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e207_27 : Edge c207 c27 m207_27 := by constructor <;> decide
theorem floor207 : Floor c207 5 := by
  apply protectedBranch source c207.P c207.N (decode 183552) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 183552, q = 8 ∨ q = 10 ∨ q = 11 ∨ q = 14 ∨ q = 15 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e207_205 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor205 k x net fit)
    · refine ⟨_,goodChild e207_201 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor201 k x net fit)
    · refine ⟨_,goodChild e207_197 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor197 k x net fit)
    · refine ⟨_,goodChild e207_171 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor171 k x net fit)
    · refine ⟨_,goodChild e207_141 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor141 k x net fit)
    · refine ⟨_,goodChild e207_27 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor27 k x net fit)
  · exact pairExcluded 183552 183552 [16640, 17408, 33024, 34816, 132096, 133120] [3328, 18432, 33792, 131328, 180224] validBranch183552 (by decide) (by decide) (by decide)
def c208 : Chart := ⟨[16640, 17408, 33024, 34816, 131073, 132096, 133120],[1281, 2305, 3328, 18433, 33793, 49153, 131328, 180224]⟩
def m208_207 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e208_207 : Edge c208 c207 m208_207 := by constructor <;> decide
theorem floor208 : Floor c208 6 := by
  have up := refundEdge e208_207 floor207 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c209 : Chart := ⟨[16640, 17408, 33024, 34816, 131136, 132096, 133120],[1344, 2368, 3328, 18496, 33856, 49216, 131328, 180224]⟩
def m209_207 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e209_207 : Edge c209 c207 m209_207 := by constructor <;> decide
theorem floor209 : Floor c209 6 := by
  have up := refundEdge e209_207 floor207 131136 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c210 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 132096, 133120],[2432, 3200, 3328, 18432, 33920, 131456, 163968, 180224]⟩
def m210_207 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e210_207 : Edge c210 c207 m210_207 := by constructor <;> decide
theorem floor210 : Floor c210 6 := by
  have up := refundEdge e210_207 floor207 16512 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c211 : Chart := ⟨[16512, 16640, 17408, 33024, 34816, 131136, 132096, 133120],[1344, 2496, 3200, 3328, 18496, 33984, 49216, 131456, 163968, 180224]⟩
def m211_210 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e211_210 : Edge c211 c210 m211_210 := by constructor <;> decide
theorem floor211 : Floor c211 7 := by
  have up := refundEdge e211_210 floor210 131136 131456 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c212 : Chart := ⟨[17408, 33280, 34816, 132096, 133120],[3584, 18944, 33792, 147968, 180224]⟩
def m212_205 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e212_205 : Edge c212 c205 m212_205 := by constructor <;> decide
theorem floor212 : Floor c212 4 := by
  have up := refundEdge e212_205 floor205 33280 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c213 : Chart := ⟨[16512, 17408, 33280, 34816, 132096, 133120],[3712, 18944, 33920, 131712, 147968, 163968, 180224]⟩
def m213_212 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e213_212 : Edge c213 c212 m213_212 := by constructor <;> decide
theorem floor213 : Floor c213 5 := by
  have up := refundEdge e213_212 floor212 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c214 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 132096, 133120],[1792, 3328, 3584, 18944, 33792, 131840, 147968, 180224]⟩
def m214_207 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e214_207 : Edge c214 c207 m214_207 := by constructor <;> decide
theorem floor214 : Floor c214 6 := by
  have up := refundEdge e214_207 floor207 33280 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c215 : Chart := ⟨[16640, 17408, 33024, 33280, 34816, 131136, 132096, 133120],[1856, 2368, 3328, 3584, 19008, 33856, 49216, 131328, 131840, 147968, 180224]⟩
def m215_214 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e215_214 : Edge c215 c214 m215_214 := by constructor <;> decide
theorem floor215 : Floor c215 7 := by
  have up := refundEdge e215_214 floor214 131136 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)

end TightRow.Protected.Numeric
