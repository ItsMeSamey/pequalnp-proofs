import Branch191936
import Branch192128
import Branch192192
import Branch192320
import NumericGraph003
import NumericGraph013
import NumericGraph016
import NumericGraph017
import NumericGraph018
import NumericGraph019
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c240 : Chart := ⟨[8256, 8320, 16512, 17408, 34816, 131136, 132096, 133120],[2176, 2240, 3200, 11264, 18496, 26624, 33984, 41984, 49216, 163968, 188416]⟩
def m240_160 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e240_160 : Edge c240 c160 m240_160 := by constructor <;> decide
theorem floor240 : Floor c240 7 := by
  have up := refundEdge e240_160 floor160 34816 2176 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c241 : Chart := ⟨[8256, 16640, 17408, 33024, 34816, 131136, 132096, 133120],[320, 1344, 2368, 11520, 18496, 26624, 33856, 41984, 49216, 139520, 188416]⟩
def m241_209 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e241_209 : Edge c241 c209 m241_209 := by constructor <;> decide
theorem floor241 : Floor c241 7 := by
  have up := refundEdge e241_209 floor209 8256 320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c242 : Chart := ⟨[8196, 8256, 16640, 17408, 33024, 34816, 131136, 132096, 133120],[1348, 2372, 3332, 9472, 11520, 18500, 26624, 33860, 41984, 49220, 131332, 139520, 180228, 188416]⟩
def m242_241 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e242_241 : Edge c242 c241 m242_241 := by constructor <;> decide
theorem floor242 : Floor c242 8 := by
  have up := refundEdge e242_241 floor241 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 8 ≤ 8).trans (up k x net fit)

end TightRow.Protected.Numeric
