import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short156864
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8320, 16512, 17408, 131136, 132096]
def n : List Nat := [1216, 9216, 16448, 131200, 155648]
def pp := p.map (canonical 156864)
def nn := n.map (canonical 156864)
def parts : List Nat := [0, 64, 128, 1024, 8192, 16384, 131072, 8256, 8320, 16512, 17408, 131136, 132096]
def g : ShortGrid := [(0,[(64,309489732259886631936327937), (128,79538861190790864407636279553), (1024,238307093840112706590972510721), (8192,1), (8256,256), (8320,0), (16384,158458742917061955551399903233), (16512,8590000384), (17408,8589935104), (131072,316917485834123911102799806465), (131136,17179934720), (132096,17180001024)]), (64,[(128,8623554560), (1024,12918521856), (8192,1099511627776), (8320,0), (16384,8590000128), (16512,8590000128), (17408,8590000128), (131072,17179934720), (132096,17179934720)]), (128,[(1024,21525233920), (8192,282574488338432), (8256,256), (16384,8590000384), (17408,8590000384), (131072,17179934976), (131136,65536), (132096,17179934976)]), (1024,[(8192,848822976643072), (8256,256), (8320,0), (16384,846623953388032), (16512,65792), (131072,17180001024), (131136,65536)]), (8192,[(16384,12901679104), (16512,4311744512), (17408,12901679104), (131072,21491613696), (131136,16777216), (132096,21491613696)]), (8256,[(16384,256), (16512,256), (17408,256), (131072,256), (132096,256)]), (8320,[(16384,0), (17408,0), (131072,0), (131136,0), (132096,0)]), (16384,[(131072,17213424128), (131136,65536), (132096,12918456832)]), (16512,[(131072,65792), (131136,65536), (132096,65792)]), (17408,[(131072,512), (131136,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 156864 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 156864 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 156864 128) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 156864 1024) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 156864 8192) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 156864 16384) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 156864 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 156864 8256) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 156864 8320) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 156864 16512) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 156864 17408) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 156864 131136) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 156864 132096) = true := by decide
theorem full : checkArms 156864 156864 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 128, 1024, 8192, 16384, 131072, 8256, 8320, 16512, 17408, 131136, 132096] : List Nat).all (fun i => parts.all (shortPair g pp nn 156864 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short156864
theorem validBranch156864 : checkArms 156864 156864 [8256, 8320, 16512, 17408, 131136, 132096] [1216, 9216, 16448, 131200, 155648] = true := Short156864.full
end TightRow.Protected.Numeric
