import NumericEdgeHints
import NumericGraph031Part00
import NumericGraph029
import NumericGraph030
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c374 : Chart := ⟨[2105408, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120],[2098752, 3712, 2110464, 2112512, 2120256, 2127872, 2135232, 2143232, 2150464, 2164928, 2181184, 92160, 2195648, 2211904, 2232960, 2249216, 2265216, 2289664, 204800, 229504]⟩
def m374_373 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 12]
private theorem e374_373 : Edge c374 c373 m374_373 := by
  exact edgeByPairs c374 c373 m374_373 [(8320,8320), (8704,8704), (16512,16512), (17408,17408), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (69632,2166784), (132096,132096), (133120,133120)] [(3712,3712), (15360,2112512), (23040,2120256), (30720,2127872), (38016,2135232), (46080,2143232), (65664,2164928), (67712,2164928), (92160,92160), (114688,2211904), (135808,2232960), (152064,2249216), (168064,2265216), (192512,2289664), (204800,204800), (229504,229504)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor374 : Floor c374 11 := by
  have up := refundEdge e374_373 floor373 2105408 2110464 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c375 : Chart := ⟨[8196, 2105408, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 2166784, 2228288, 132096, 133120],[2098752, 3204, 3588, 3712, 2104324, 9216, 2112512, 2119748, 2120196, 2120256, 2127872, 2135108, 2135172, 2135232, 2143232, 2150468, 67716, 2164928, 2181188, 92160, 2195648, 2211908, 2232960, 2249220, 2265220, 2281476, 2289664, 204800, 229508]⟩
def m375_374 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, none, some 21]
private theorem e375_374 : Edge c375 c374 m375_374 := by
  exact edgeByPairs c375 c374 m375_374 [(2105408,2105408), (8320,8320), (8704,8704), (16512,16512), (17408,17408), (33280,33280), (34816,34816), (66048,66048), (66560,66560), (2166784,2166784), (2228288,2228288), (132096,132096), (133120,133120)] [(2098752,2098752), (3712,3712), (2110464,2112512), (2112512,2112512), (2120256,2120256), (2127872,2127872), (2135232,2135232), (2143232,2143232), (2150464,2150468), (2164928,2164928), (2181184,2181188), (92160,92160), (2195648,2195648), (2211904,2211908), (2232960,2232960), (2249216,2249220), (2265216,2265220), (2289664,2289664), (204800,204800), (229504,229508)] rfl rfl (by decide) (by decide) (by decide) (by decide)
theorem floor375 : Floor c375 12 := by
  have up := refundEdge e375_374 floor374 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 12 ≤ 12).trans (up k x net fit)

end TightRow.Protected.Numeric
