import Branch257664
import NumericGraph009
import NumericGraph019
import NumericGraph020
import NumericGraph024
import NumericGraph027
import NumericGraph028
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c348 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 132096],[1664, 1792, 9472, 33920, 41984, 90112, 114688, 131968, 147968, 188416, 196992, 205056, 229504]⟩
def m348_111 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e348_111 : Edge c348 c111 m348_111 := by constructor <;> decide
theorem floor348 : Floor c348 9 := by
  have up := refundEdge e348_111 floor111 132096 1664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c349 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 131136, 132096],[1664, 1856, 9472, 16960, 33984, 41984, 65984, 90112, 98496, 114752, 131968, 147968, 188416, 196992, 205056, 229504]⟩
def m349_348 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e349_348 : Edge c349 c348 m349_348 := by constructor <;> decide
theorem floor349 : Floor c349 10 := by
  have up := refundEdge e349_348 floor348 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c350 : Chart := ⟨[8196, 8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280, 66048, 66560, 131136, 132096],[1348, 1664, 1796, 1856, 9472, 16960, 33860, 33924, 33984, 41984, 65860, 65984, 90112, 98496, 114756, 131844, 131968, 147972, 180228, 188416, 196996, 205056, 229508]⟩
def m350_349 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e350_349 : Edge c350 c349 m350_349 := by constructor <;> decide
theorem floor350 : Floor c350 11 := by
  have up := refundEdge e350_349 floor349 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)
def c351 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 33024, 33280, 34816, 66048, 131136, 133120],[640, 832, 2688, 19008, 68032, 76032, 84032, 92160, 98496, 114752, 131968, 147968, 188416, 196992, 205056, 229504]⟩
def m351_238 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e351_238 : Edge c351 c238 m351_238 := by constructor <;> decide
theorem floor351 : Floor c351 10 := by
  have up := refundEdge e351_238 floor238 66048 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c352 : Chart := ⟨[8256, 8320, 16512, 16640, 17408, 33024, 34816, 66560, 131136, 132096, 133120],[1152, 1344, 3200, 11520, 33984, 41984, 68032, 76032, 84032, 92160, 98496, 114752, 188416, 196992, 205056, 229504]⟩
def m352_244 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e352_244 : Edge c352 c244 m352_244 := by constructor <;> decide
theorem floor352 : Floor c352 10 := by
  have up := refundEdge e352_244 floor244 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c353 : Chart := ⟨[8704, 17408, 33280, 34816, 66048, 66560, 132096, 133120],[512, 3584, 11264, 18944, 41984, 92160, 114688, 147968, 188416, 204800, 229376]⟩
def m353_335 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e353_335 : Edge c353 c335 m353_335 := by constructor <;> decide
theorem floor353 : Floor c353 7 := by
  have up := refundEdge e353_335 floor335 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c354 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 132096, 133120],[3712, 11264, 18944, 33920, 41984, 67712, 92160, 114688, 131712, 147968, 188416, 204800, 229504]⟩
def m354_353 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e354_353 : Edge c354 c353 m354_353 := by constructor <;> decide
def m354_345 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e354_345 : Edge c354 c345 m354_345 := by constructor <;> decide
def m354_336 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e354_336 : Edge c354 c336 m354_336 := by constructor <;> decide
def m354_325 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, some 16, some 17, none, none, none, none]
private theorem e354_325 : Edge c354 c325 m354_325 := by constructor <;> decide
def m354_289 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e354_289 : Edge c354 c289 m354_289 := by constructor <;> decide
def m354_247 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e354_247 : Edge c354 c247 m354_247 := by constructor <;> decide
def m354_112 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, none, none, none, none, none]
private theorem e354_112 : Edge c354 c112 m354_112 := by constructor <;> decide
theorem floor354 : Floor c354 9 := by
  apply protectedBranch source c354.P c354.N (decode 256128) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 256128, q = 7 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 16 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e354_353 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor353 k x net fit)
    · refine ⟨_,goodChild e354_345 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor345 k x net fit)
    · refine ⟨_,goodChild e354_336 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor336 k x net fit)
    · refine ⟨_,goodChild e354_325 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor325 k x net fit)
    · refine ⟨_,goodChild e354_289 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor289 k x net fit)
    · refine ⟨_,goodChild e354_247 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor247 k x net fit)
    · refine ⟨_,goodChild e354_112 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor112 k x net fit)
  · exact pairExcluded 257664 256128 [8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 132096, 133120] [3712, 11264, 18944, 33920, 41984, 67712, 92160, 114688, 131712, 147968, 188416, 204800, 229504] validBranch257664 (by decide) (by decide) (by decide)
def c355 : Chart := ⟨[8196, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 132096, 133120],[3204, 3588, 3712, 9216, 11264, 18948, 33924, 41984, 67716, 83972, 92160, 114692, 131712, 147972, 180228, 188416, 204800, 229508]⟩
def m355_354 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e355_354 : Edge c355 c354 m355_354 := by constructor <;> decide
theorem floor355 : Floor c355 10 := by
  have up := refundEdge e355_354 floor354 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c356 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 131136, 132096, 133120],[1600, 3712, 9216, 11264, 19008, 33984, 41984, 67776, 84032, 92160, 98496, 114752, 131712, 147968, 188416, 204800, 229504]⟩
def m356_354 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e356_354 : Edge c356 c354 m356_354 := by constructor <;> decide
theorem floor356 : Floor c356 10 := by
  have up := refundEdge e356_354 floor354 8256 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c357 : Chart := ⟨[8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120],[512, 1792, 3584, 11520, 18944, 41984, 76032, 92160, 114688, 131840, 147968, 188416, 205056, 229376]⟩
def m357_337 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e357_337 : Edge c357 c337 m357_337 := by constructor <;> decide
theorem floor357 : Floor c357 9 := by
  have up := refundEdge e357_337 floor337 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c358 : Chart := ⟨[8196, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 132096, 133120],[1796, 3332, 3588, 9472, 11520, 18948, 33796, 41984, 67844, 76032, 83972, 92160, 114692, 131844, 147972, 180228, 188416, 196868, 205056, 229380]⟩
def m358_357 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e358_357 : Edge c358 c357 m358_357 := by constructor <;> decide
theorem floor358 : Floor c358 10 := by
  have up := refundEdge e358_357 floor357 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 10 ≤ 10).trans (up k x net fit)
def c359 : Chart := ⟨[8196, 8704, 16640, 17408, 33024, 33280, 34816, 66048, 66560, 131073, 132096, 133120],[1541, 1793, 1796, 3332, 3588, 9473, 11520, 18949, 33797, 41985, 57345, 67844, 76033, 83973, 92161, 114693, 131328, 131844, 147972, 180228, 188416, 196868, 205056, 229380]⟩
def m359_358 : List (Option Addr) := [none, none, some 2, none, none, none, none, none, some 8, some 9, some 10, some 11, none, some 13, some 14, some 15, some 16, some 17, none, none, none, none]
private theorem e359_358 : Edge c359 c358 m359_358 := by constructor <;> decide
theorem floor359 : Floor c359 11 := by
  have up := refundEdge e359_358 floor358 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 11 ≤ 11).trans (up k x net fit)

end TightRow.Protected.Numeric
