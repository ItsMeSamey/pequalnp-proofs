import NumericEdgeHints

namespace TightRow.Protected.Numeric
def hintedRows (xs ys : List Nat) (code : Nat) : List (Nat × Nat) :=
  xs.zipIdx.map (fun z => (z.1,ys.getD ((code >>> (8*z.2)) % 256) 0))

theorem hintCover (xs ys : List Nat) (code : Nat) :
    xs = (hintedRows xs ys code).map Prod.fst := by
  unfold hintedRows
  rw [List.map_map]
  exact (List.zipIdx_map_fst 0 xs).symm

theorem edgeByCodes (p c : Chart) (m : List (Option Addr)) (pos neg : Nat)
    (liveP : ∃ x ∈ c.pos, True) (liveN : ∃ x ∈ c.neg, True)
    (upOK : ∀ z ∈ hintedRows c.pos p.pos pos, z.2 ∈ p.pos ∧
      ∀ i : Addr, z.2.testBit i.val = true → rebits m z.1 i = true)
    (downOK : ∀ z ∈ hintedRows c.neg p.neg neg, z.2 ∈ p.neg ∧
      ∀ i : Addr, rebits m z.1 i = true → z.2.testBit i.val = true) :
    Edge p c m := edgeByPairs p c m _ _ (hintCover ..) (hintCover ..) liveP liveN upOK downOK

end TightRow.Protected.Numeric
