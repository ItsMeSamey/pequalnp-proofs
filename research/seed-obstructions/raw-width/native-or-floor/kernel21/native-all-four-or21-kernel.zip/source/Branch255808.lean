import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short255808
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8256, 8704, 16640, 17408, 33024, 33280, 66048, 66560, 131136, 132096]
def n : List Nat := [1856, 9472, 16960, 33856, 41984, 65856, 90112, 114752, 131840, 147968, 188416, 205056, 229376]
def pp := p.map (canonical 255808)
def nn := n.map (canonical 255808)
def parts : List Nat := [0, 64, 256, 8192, 16384, 32768, 65536, 131072, 8256, 16640, 33024, 131136]
def g : ShortGrid := [(0,[(64,5709077884480700550710999124116928582956089601), (256,5863178298716179693142937728032225356400463839745), (8192,1), (8256,256), (16384,2923047876832778016247705476368179567442471813121), (16640,8589935360), (32768,5846095753665556032495410952736359134884943626241), (33024,17180000768), (65536,8769143630498334048743116429104538702327415439361), (131072,11692191507331112064990821905472718269769887252481), (131136,34359803904)]), (64,[(256,8623554560), (8192,1099511627776), (16384,8590000128), (16640,8590000128), (32768,17179934720), (33024,17179934720), (65536,25769869312), (131072,34359803904)]), (256,[(8192,1130297953353728), (8256,256), (16384,565157566611968), (32768,17180000768), (65536,25769935360), (131072,34359869952), (131136,65536)]), (8192,[(16384,8606711808), (16640,8606711808), (32768,17196646400), (33024,17196646400), (65536,30081548288), (131072,38671482880), (131136,16777216)]), (8256,[(16384,256), (16640,256), (32768,256), (33024,256), (65536,256), (131072,256)]), (16384,[(32768,21508391424), (33024,8623489536), (65536,25803358720), (131072,34393293312), (131136,65536)]), (16640,[(32768,768), (65536,768), (131072,768), (131136,65536)]), (32768,[(65536,30115103744), (131072,34410071040), (131136,65536)]), (33024,[(65536,131584), (131072,131584), (131136,65536)]), (65536,[(131072,1697645953288192), (131136,65536)])]
private theorem row0 : parts.all (shortPair g pp nn 254272 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 254272 64) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 254272 256) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 254272 8192) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 254272 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 254272 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 254272 65536) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 254272 131072) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 254272 8256) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 254272 16640) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 254272 33024) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 254272 131136) = true := by decide
theorem full : checkArms 255808 254272 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 64, 256, 8192, 16384, 32768, 65536, 131072, 8256, 16640, 33024, 131136] : List Nat).all (fun i => parts.all (shortPair g pp nn 254272 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short255808
theorem validBranch255808 : checkArms 255808 254272 [8256, 8704, 16640, 17408, 33024, 33280, 66048, 66560, 131136, 132096] [1856, 9472, 16960, 33856, 41984, 65856, 90112, 114752, 131840, 147968, 188416, 205056, 229376] = true := Short255808.full
end TightRow.Protected.Numeric
