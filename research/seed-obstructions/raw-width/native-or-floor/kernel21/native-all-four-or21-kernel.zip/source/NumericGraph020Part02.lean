import NumericGraph020Part01
import Branch191936
import Branch192128
import Branch192192
import Branch192320
import NumericGraph003
import NumericGraph013
import NumericGraph016
import NumericGraph017
import NumericGraph018
import NumericGraph019
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c246 : Chart := ⟨[8256, 8704, 17408, 33280, 34816, 131136, 132096, 133120],[1536, 1600, 3584, 11264, 19008, 26624, 33856, 41984, 49216, 147968, 188416]⟩
def m246_193 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e246_193 : Edge c246 c193 m246_193 := by constructor <;> decide
theorem floor246 : Floor c246 7 := by
  have up := refundEdge e246_193 floor193 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c247 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816, 132096, 133120],[3712, 11264, 18944, 26624, 33920, 41984, 131712, 147968, 163968, 188416]⟩
def m247_245 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e247_245 : Edge c247 c245 m247_245 := by constructor <;> decide
def m247_239 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e247_239 : Edge c247 c239 m247_239 := by constructor <;> decide
def m247_234 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e247_234 : Edge c247 c234 m247_234 := by constructor <;> decide
def m247_223 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e247_223 : Edge c247 c223 m247_223 := by constructor <;> decide
def m247_213 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e247_213 : Edge c247 c213 m247_213 := by constructor <;> decide
def m247_194 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e247_194 : Edge c247 c194 m247_194 := by constructor <;> decide
def m247_162 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e247_162 : Edge c247 c162 m247_162 := by constructor <;> decide
def m247_43 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e247_43 : Edge c247 c43 m247_43 := by constructor <;> decide
theorem floor247 : Floor c247 7 := by
  apply protectedBranch source c247.P c247.N (decode 192128) 7
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 192128, q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e247_245 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor245 k x net fit)
    · refine ⟨_,goodChild e247_239 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor239 k x net fit)
    · refine ⟨_,goodChild e247_234 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor234 k x net fit)
    · refine ⟨_,goodChild e247_223 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor223 k x net fit)
    · refine ⟨_,goodChild e247_213 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor213 k x net fit)
    · refine ⟨_,goodChild e247_194 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor194 k x net fit)
    · refine ⟨_,goodChild e247_162 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor162 k x net fit)
    · refine ⟨_,goodChild e247_43 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor43 k x net fit)
  · exact pairExcluded 192128 192128 [8320, 8704, 16512, 17408, 33280, 34816, 132096, 133120] [3712, 11264, 18944, 26624, 33920, 41984, 131712, 147968, 163968, 188416] validBranch192128 (by decide) (by decide) (by decide)
def c248 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 33280, 34816, 131136, 132096, 133120],[1600, 2240, 3712, 11264, 19008, 26624, 33984, 41984, 49216, 131712, 147968, 163968, 188416]⟩
def m248_247 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e248_247 : Edge c248 c247 m248_247 := by constructor <;> decide
def m248_246 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e248_246 : Edge c248 c246 m248_246 := by constructor <;> decide
def m248_240 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e248_240 : Edge c248 c240 m248_240 := by constructor <;> decide
def m248_235 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, none, some 11, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e248_235 : Edge c248 c235 m248_235 := by constructor <;> decide
def m248_224 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e248_224 : Edge c248 c224 m248_224 := by constructor <;> decide
def m248_195 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e248_195 : Edge c248 c195 m248_195 := by constructor <;> decide
def m248_163 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e248_163 : Edge c248 c163 m248_163 := by constructor <;> decide
theorem floor248 : Floor c248 9 := by
  apply protectedBranch source c248.P c248.N (decode 52928) 9
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 52928, q = 6 ∨ q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 11 ∨ q = 14 ∨ q = 15 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e248_247 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor247 k x net fit)
    · refine ⟨_,goodChild e248_246 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor246 k x net fit)
    · refine ⟨_,goodChild e248_240 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor240 k x net fit)
    · refine ⟨_,goodChild e248_235 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor235 k x net fit)
    · refine ⟨_,goodChild e248_224 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor224 k x net fit)
    · refine ⟨_,goodChild e248_195 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor195 k x net fit)
    · refine ⟨_,goodChild e248_163 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 9-2 ≤ 7).trans (floor163 k x net fit)
  · exact pairExcluded 192192 52928 [8256, 8320, 8704, 16512, 17408, 33280, 34816, 131136, 132096, 133120] [1600, 2240, 3712, 11264, 19008, 26624, 33984, 41984, 49216, 131712, 147968, 163968, 188416] validBranch192192 (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric
