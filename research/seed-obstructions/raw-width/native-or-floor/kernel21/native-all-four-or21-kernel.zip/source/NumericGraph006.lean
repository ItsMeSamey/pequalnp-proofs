import NumericGraph003
import NumericGraph005
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c72 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 66048, 66560],[896, 1664, 1792, 9472, 16896, 65920, 73984, 90112]⟩
def m72_67 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e72_67 : Edge c72 c67 m72_67 := by constructor <;> decide
theorem floor72 : Floor c72 6 := by
  have up := refundEdge e72_67 floor67 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c73 : Chart := ⟨[8196, 8320, 8704, 16512, 16640, 17408, 66048, 66560],[896, 1156, 1664, 1796, 9472, 16900, 65924, 73984, 81924, 90112]⟩
def m73_72 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e73_72 : Edge c73 c72 m73_72 := by constructor <;> decide
theorem floor73 : Floor c73 7 := by
  have up := refundEdge e73_72 floor72 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c74 : Chart := ⟨[8320, 8704, 16512, 66048, 69632],[4736, 20992, 28672, 65664, 90112]⟩
def m74_64 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e74_64 : Edge c74 c64 m74_64 := by constructor <;> decide
theorem floor74 : Floor c74 4 := by
  have up := refundEdge e74_64 floor64 69632 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c75 : Chart := ⟨[8320, 8704, 16512, 16640, 66048, 69632],[4992, 12544, 16896, 20992, 28672, 65920, 73984, 90112]⟩
def m75_74 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, some 12, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e75_74 : Edge c75 c74 m75_74 := by constructor <;> decide
theorem floor75 : Floor c75 5 := by
  have up := refundEdge e75_74 floor74 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c76 : Chart := ⟨[8320, 16512, 17408, 66560, 69632],[5248, 13312, 28672, 65664, 90112]⟩
def m76_65 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e76_65 : Edge c76 c65 m76_65 := by constructor <;> decide
theorem floor76 : Floor c76 4 := by
  have up := refundEdge e76_65 floor65 69632 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c77 : Chart := ⟨[8196, 8320, 16512, 17408, 66560, 69632],[5252, 9216, 13312, 20484, 28672, 65668, 81924, 90112]⟩
def m77_76 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, some 12, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e77_76 : Edge c77 c76 m77_76 := by constructor <;> decide
theorem floor77 : Floor c77 5 := by
  have up := refundEdge e77_76 floor76 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c78 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 69632],[1664, 4736, 5248, 13312, 20992, 28672, 65664, 90112]⟩
def m78_67 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e78_67 : Edge c78 c67 m78_67 := by constructor <;> decide
theorem floor78 : Floor c78 6 := by
  have up := refundEdge e78_67 floor67 69632 65664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c79 : Chart := ⟨[8196, 8320, 8704, 16512, 17408, 66048, 66560, 69632],[1540, 1664, 4736, 5252, 9216, 13312, 20996, 28672, 65668, 81924, 90112]⟩
def m79_78 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e79_78 : Edge c79 c78 m79_78 := by constructor <;> decide
theorem floor79 : Floor c79 7 := by
  have up := refundEdge e79_78 floor78 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c80 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 66048, 66560, 69632],[1664, 1792, 4992, 5248, 13568, 16896, 20992, 28672, 65920, 73984, 90112]⟩
def m80_78 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, some 12, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e80_78 : Edge c80 c78 m80_78 := by constructor <;> decide
theorem floor80 : Floor c80 7 := by
  have up := refundEdge e80_78 floor78 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c81 : Chart := ⟨[33280, 66048],[512, 98304]⟩
def m81_45 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, none, none, none, some 16, none, none, none, none, none]
private theorem e81_45 : Edge c81 c45 m81_45 := by constructor <;> decide
theorem floor81 : Floor c81 1 := by
  have up := refundEdge e81_45 floor45 33280 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c82 : Chart := ⟨[33024, 33280, 66048],[768, 32768, 65792, 98304]⟩
def m82_81 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e82_81 : Edge c82 c81 m82_81 := by constructor <;> decide
theorem floor82 : Floor c82 2 := by
  have up := refundEdge e82_81 floor81 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c83 : Chart := ⟨[33280, 66048, 66560],[1536, 33792, 65536, 98304]⟩
def m83_81 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, none, none, some 15, some 16, none, none, none, none, none]
private theorem e83_81 : Edge c83 c81 m83_81 := by constructor <;> decide
theorem floor83 : Floor c83 2 := by
  have up := refundEdge e83_81 floor81 66560 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)

end TightRow.Protected.Numeric
