import IncrementCharts

namespace TightRow.Protected.Numeric.Increment
open TightRow.Deletion TightRow.NativeSeeds
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def m2759_952 : List (Option Addr) := [some 0, none, some 2, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, some 18, none, some 20, some 21]
theorem e2759_952 : Edge c2759 c952 m2759_952 := by
  exact edgeByCodes c2759 c952 m2759_952 108873724432616589554458274966207996112469623040 66920893249024239481130047748091851772058453765270605327920421513240078706542252685390059258882327438303130235534285385364000442202370710488313991655008686142848332594282752 (by decide) (by decide) (by decide) (by decide)
theorem lift2759 {d : Nat} (low : Floor c952 d) : Floor c2759 (d+1) := by
  exact refundEdge e2759_952 low 1572865 1049473 (by decide) (by decide) (by decide)
end TightRow.Protected.Numeric.Increment
