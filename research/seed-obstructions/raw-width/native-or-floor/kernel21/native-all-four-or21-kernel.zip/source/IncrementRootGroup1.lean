import IncrementRootData

namespace TightRow.Protected.Numeric.Increment
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem rootDown1OK : ∀ z ∈ rootDown1, RootDown z := by decide
theorem rootDown2OK : ∀ z ∈ rootDown2, RootDown z := by decide
theorem rootDown3OK : ∀ z ∈ rootDown3, RootDown z := by decide
theorem rootDown4OK : ∀ z ∈ rootDown4, RootDown z := by decide
end TightRow.Protected.Numeric.Increment
