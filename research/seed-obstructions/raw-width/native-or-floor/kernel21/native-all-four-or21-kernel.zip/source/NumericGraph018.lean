import Branch190272
import NumericGraph002
import NumericGraph003
import NumericGraph011
import NumericGraph012
import NumericGraph014
import NumericGraph016
import NumericGraph017
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c216 : Chart := ⟨[16512, 16640, 17408, 33024, 33280, 34816, 132096, 133120],[1792, 2432, 3328, 3712, 18944, 33920, 131968, 147968, 163968, 180224]⟩
def m216_214 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e216_214 : Edge c216 c214 m216_214 := by constructor <;> decide
theorem floor216 : Floor c216 7 := by
  have up := refundEdge e216_214 floor214 16512 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c217 : Chart := ⟨[8256, 8320, 16512, 16640, 33024, 131136],[384, 448, 32960, 49216, 131456, 139520, 163968, 188416]⟩
def m217_143 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, none, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e217_143 : Edge c217 c143 m217_143 := by constructor <;> decide
theorem floor217 : Floor c217 5 := by
  have up := refundEdge e217_143 floor143 33024 384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c218 : Chart := ⟨[8256, 8704, 16640, 33024, 33280, 131136],[768, 832, 16960, 49216, 131840, 139520, 147968, 188416]⟩
def m218_174 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, none, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e218_174 : Edge c218 c174 m218_174 := by constructor <;> decide
theorem floor218 : Floor c218 5 := by
  have up := refundEdge e218_174 floor174 16640 768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c219 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 33024, 33280, 131136],[320, 448, 832, 16960, 32960, 49216, 131968, 139520, 147968, 163968, 188416]⟩
def m219_33 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e219_33 : Edge c219 c33 m219_33 := by constructor <;> decide
theorem floor219 : Floor c219 7 := by
  have up := refundEdge e219_33 floor33 131136 320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c220 : Chart := ⟨[8256, 16640, 17408, 33024, 131136, 132096],[320, 1344, 9472, 33856, 41984, 49216, 139520, 188416]⟩
def m220_198 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, none, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e220_198 : Edge c220 c198 m220_198 := by constructor <;> decide
theorem floor220 : Floor c220 5 := by
  have up := refundEdge e220_198 floor198 8256 320 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c221 : Chart := ⟨[8256, 8320, 16512, 16640, 17408, 33024, 131136, 132096],[384, 448, 1344, 9472, 33984, 41984, 49216, 131456, 139520, 163968, 188416]⟩
def m221_150 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, some 8, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e221_150 : Edge c221 c150 m221_150 := by constructor <;> decide
theorem floor221 : Floor c221 7 := by
  have up := refundEdge e221_150 floor150 33024 384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c222 : Chart := ⟨[8256, 8704, 17408, 33280, 131136, 132096],[1536, 1600, 16960, 33856, 41984, 49216, 147968, 188416]⟩
def m222_175 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e222_175 : Edge c222 c175 m222_175 := by constructor <;> decide
theorem floor222 : Floor c222 5 := by
  have up := refundEdge e222_175 floor175 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c223 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 132096],[640, 1664, 33920, 41984, 131712, 147968, 163968, 188416]⟩
def m223_153 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e223_153 : Edge c223 c153 m223_153 := by constructor <;> decide
theorem floor223 : Floor c223 5 := by
  have up := refundEdge e223_153 floor153 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c224 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 33280, 131136, 132096],[640, 1600, 1664, 16960, 33984, 41984, 49216, 131712, 147968, 163968, 188416]⟩
def m224_154 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e224_154 : Edge c224 c154 m224_154 := by constructor <;> decide
theorem floor224 : Floor c224 7 := by
  have up := refundEdge e224_154 floor154 33280 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c225 : Chart := ⟨[8704, 16640, 17408, 33024, 33280, 132096],[512, 1792, 9472, 41984, 131840, 139520, 147968, 188416]⟩
def m225_199 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e225_199 : Edge c225 c199 m225_199 := by constructor <;> decide
theorem floor225 : Floor c225 5 := by
  have up := refundEdge e225_199 floor199 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c226 : Chart := ⟨[8256, 8704, 16640, 17408, 33024, 33280, 131136, 132096],[1856, 9472, 16960, 33856, 41984, 49216, 131840, 139520, 147968, 188416]⟩
def m226_225 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e226_225 : Edge c226 c225 m226_225 := by constructor <;> decide
def m226_222 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e226_222 : Edge c226 c222 m226_222 := by constructor <;> decide
def m226_220 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, some 10, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e226_220 : Edge c226 c220 m226_220 := by constructor <;> decide
def m226_218 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, none, none, some 13, some 14, some 15, none, some 17, none, none, none, none]
private theorem e226_218 : Edge c226 c218 m226_218 := by constructor <;> decide
def m226_200 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e226_200 : Edge c226 c200 m226_200 := by constructor <;> decide
def m226_176 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e226_176 : Edge c226 c176 m226_176 := by constructor <;> decide
def m226_155 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e226_155 : Edge c226 c155 m226_155 := by constructor <;> decide
def m226_35 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e226_35 : Edge c226 c35 m226_35 := by constructor <;> decide
theorem floor226 : Floor c226 7 := by
  apply protectedBranch source c226.P c226.N (decode 190272) 7
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 190272, q = 6 ∨ q = 8 ∨ q = 9 ∨ q = 10 ∨ q = 13 ∨ q = 14 ∨ q = 15 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e226_225 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor225 k x net fit)
    · refine ⟨_,goodChild e226_222 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor222 k x net fit)
    · refine ⟨_,goodChild e226_220 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor220 k x net fit)
    · refine ⟨_,goodChild e226_218 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor218 k x net fit)
    · refine ⟨_,goodChild e226_200 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor200 k x net fit)
    · refine ⟨_,goodChild e226_176 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor176 k x net fit)
    · refine ⟨_,goodChild e226_155 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor155 k x net fit)
    · refine ⟨_,goodChild e226_35 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 7-2 ≤ 5).trans (floor35 k x net fit)
  · exact pairExcluded 190272 190272 [8256, 8704, 16640, 17408, 33024, 33280, 131136, 132096] [1856, 9472, 16960, 33856, 41984, 49216, 131840, 139520, 147968, 188416] validBranch190272 (by decide) (by decide) (by decide)
def c227 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 132096],[1664, 1792, 9472, 33920, 41984, 131968, 139520, 147968, 163968, 188416]⟩
def m227_36 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e227_36 : Edge c227 c36 m227_36 := by constructor <;> decide
theorem floor227 : Floor c227 7 := by
  have up := refundEdge e227_36 floor36 132096 1664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)

end TightRow.Protected.Numeric
