import NumericGraph010
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c132 : Chart := ⟨[8256, 8704, 131136, 133120],[2624, 8192, 10240, 131584, 139264]⟩
def m132_130 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e132_130 : Edge c132 c130 m132_130 := by constructor <;> decide
theorem floor132 : Floor c132 3 := by
  have up := refundEdge e132_130 floor130 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c133 : Chart := ⟨[17408, 132096],[1024, 147456]⟩
def m133_120 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, none, none, none, some 17, none, none, none, none]
private theorem e133_120 : Edge c133 c120 m133_120 := by constructor <;> decide
theorem floor133 : Floor c133 1 := by
  have up := refundEdge e133_120 floor120 17408 1024 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c134 : Chart := ⟨[17408, 131136, 132096],[1088, 16448, 131072, 147456]⟩
def m134_133 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e134_133 : Edge c134 c133 m134_133 := by constructor <;> decide
theorem floor134 : Floor c134 2 := by
  have up := refundEdge e134_133 floor133 131136 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c135 : Chart := ⟨[16512, 17408, 132096],[1152, 16384, 131200, 147456]⟩
def m135_133 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e135_133 : Edge c135 c133 m135_133 := by constructor <;> decide
theorem floor135 : Floor c135 2 := by
  have up := refundEdge e135_133 floor133 16512 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c136 : Chart := ⟨[16512, 17408, 131136, 132096],[1216, 16448, 131200, 147456]⟩
def m136_135 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e136_135 : Edge c136 c135 m136_135 := by constructor <;> decide
theorem floor136 : Floor c136 3 := by
  have up := refundEdge e136_135 floor135 131136 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c137 : Chart := ⟨[16640, 17408, 132096],[1280, 16384, 131328, 147456]⟩
def m137_133 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e137_133 : Edge c137 c133 m137_133 := by constructor <;> decide
theorem floor137 : Floor c137 2 := by
  have up := refundEdge e137_133 floor133 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c138 : Chart := ⟨[16640, 17408, 131073, 132096],[1281, 16385, 131328, 147456]⟩
def m138_137 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e138_137 : Edge c138 c137 m138_137 := by constructor <;> decide
theorem floor138 : Floor c138 3 := by
  have up := refundEdge e138_137 floor137 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c139 : Chart := ⟨[17408, 132096, 133120],[3072, 18432, 131072, 147456]⟩
def m139_133 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e139_133 : Edge c139 c133 m139_133 := by constructor <;> decide
theorem floor139 : Floor c139 2 := by
  have up := refundEdge e139_133 floor133 133120 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c140 : Chart := ⟨[16512, 17408, 132096, 133120],[3200, 18432, 131200, 147456]⟩
def m140_139 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e140_139 : Edge c140 c139 m140_139 := by constructor <;> decide
theorem floor140 : Floor c140 3 := by
  have up := refundEdge e140_139 floor139 16512 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c141 : Chart := ⟨[16640, 17408, 132096, 133120],[3328, 18432, 131328, 147456]⟩
def m141_139 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e141_139 : Edge c141 c139 m141_139 := by constructor <;> decide
theorem floor141 : Floor c141 3 := by
  have up := refundEdge e141_139 floor139 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c142 : Chart := ⟨[8256, 8320, 16512, 131136],[128, 192, 16448, 131200, 155648]⟩
def m142_125 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e142_125 : Edge c142 c125 m142_125 := by constructor <;> decide
theorem floor142 : Floor c142 3 := by
  have up := refundEdge e142_125 floor125 16512 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c143 : Chart := ⟨[8256, 8320, 16512, 16640, 131136],[448, 16384, 16448, 131456, 139520, 155648]⟩
def m143_142 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e143_142 : Edge c143 c142 m143_142 := by constructor <;> decide
theorem floor143 : Floor c143 4 := by
  have up := refundEdge e143_142 floor142 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)

end TightRow.Protected.Numeric
