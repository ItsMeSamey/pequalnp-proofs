import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short232960
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [33280, 34816, 66048, 66560, 132096, 133120]
def n : List Nat := [3584, 33792, 67584, 131584, 229376]
def pp := p.map (canonical 232960)
def nn := n.map (canonical 232960)
def parts : List Nat := [0, 512, 1024, 2048, 32768, 65536, 131072, 33280, 34816, 66048, 66560, 132096, 133120]
def g : ShortGrid := [(0,[(512,309489732259886631936327937), (1024,238307093840112706590972510721), (2048,79538861190790864407636279553), (32768,1), (33280,256), (34816,0), (65536,158458742917061955551399903233), (66048,8590000128), (66560,8589935104), (131072,316917485834123911102799806465), (132096,17180001024), (133120,17179934976)]), (512,[(1024,17230266368), (2048,21525233664), (32768,1099511627776), (34816,0), (65536,8590000128), (66560,8590000128), (131072,17179934720), (132096,17179934720), (133120,17179934720)]), (1024,[(2048,846623953453312), (32768,848822976643072), (33280,256), (34816,0), (65536,846623953388032), (66048,65536), (131072,17180001024), (133120,65792)]), (2048,[(32768,282574488338432), (33280,256), (65536,8590000384), (66048,65536), (66560,8590000384), (131072,17179934976), (132096,17179934976)]), (32768,[(65536,12901679104), (66048,16777216), (66560,12901679104), (131072,17196646400), (132096,17196646400), (133120,4311744512)]), (33280,[(65536,256), (66560,256), (131072,256), (132096,256), (133120,256)]), (34816,[(65536,0), (66048,0), (66560,0), (131072,0), (132096,0)]), (65536,[(131072,21508391424), (132096,12918456832), (133120,65792)]), (66048,[(131072,65536), (132096,65536), (133120,65536)]), (66560,[(131072,512), (133120,65792)])]
private theorem row0 : parts.all (shortPair g pp nn 232960 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 232960 512) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 232960 1024) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 232960 2048) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 232960 32768) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 232960 65536) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 232960 131072) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 232960 33280) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 232960 34816) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 232960 66048) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 232960 66560) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 232960 132096) = true := by decide
private theorem row12 : parts.all (shortPair g pp nn 232960 133120) = true := by decide
theorem full : checkArms 232960 232960 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 512, 1024, 2048, 32768, 65536, 131072, 33280, 34816, 66048, 66560, 132096, 133120] : List Nat).all (fun i => parts.all (shortPair g pp nn 232960 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12]
end Short232960
theorem validBranch232960 : checkArms 232960 232960 [33280, 34816, 66048, 66560, 132096, 133120] [3584, 33792, 67584, 131584, 229376] = true := Short232960.full
end TightRow.Protected.Numeric
