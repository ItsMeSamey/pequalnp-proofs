import IncrementCharts

namespace TightRow.Protected.Numeric.Increment
open TightRow.Deletion TightRow.NativeSeeds
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def m952_383 : List (Option Addr) := [some 0, none, some 2, none, none, none, some 6, some 7, some 8, some 9, some 10, some 11, some 12, some 13, some 14, some 15, some 16, some 17, none, none, some 20, some 21]
theorem e952_383 : Edge c952 c383 m952_383 := by
  exact edgeByCodes c952 c383 m952_383 5464529247453287905752847152185016975616 40979805279548479519004558806078768872117684731998123209572485873721677152895316007007348958814606239548738980731622707125176220537888550621172531252 (by decide) (by decide) (by decide) (by decide)
theorem lift952 {d : Nat} (low : Floor c383 d) : Floor c952 (d+1) := by
  exact refundEdge e952_383 low 1310848 1049473 (by decide) (by decide) (by decide)
end TightRow.Protected.Numeric.Increment
