import NumericGraph002
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c36 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280],[896, 1664, 1792, 9472, 16896, 33920, 41984, 57344]⟩
def m36_31 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e36_31 : Edge c36 c31 m36_31 := by constructor <;> decide
theorem floor36 : Floor c36 6 := by
  have up := refundEdge e36_31 floor31 17408 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c37 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 33024, 33280],[448, 896, 1664, 1856, 9472, 16960, 33984, 41984, 49216, 57344]⟩
def m37_36 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e37_36 : Edge c37 c36 m37_36 := by constructor <;> decide
theorem floor37 : Floor c37 7 := by
  have up := refundEdge e37_36 floor36 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c38 : Chart := ⟨[8320, 16512, 16640, 33024, 34816],[2432, 10496, 26624, 32896, 57344]⟩
def m38_28 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e38_28 : Edge c38 c28 m38_28 := by constructor <;> decide
theorem floor38 : Floor c38 4 := by
  have up := refundEdge e38_28 floor28 34816 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c39 : Chart := ⟨[8256, 8320, 16512, 16640, 33024, 34816],[2496, 8448, 10496, 18496, 26624, 32960, 49216, 57344]⟩
def m39_38 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e39_38 : Edge c39 c38 m39_38 := by constructor <;> decide
theorem floor39 : Floor c39 5 := by
  have up := refundEdge e39_38 floor38 8256 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c40 : Chart := ⟨[8320, 8704, 16512, 33280, 34816],[2688, 18944, 26624, 32896, 57344]⟩
def m40_29 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e40_29 : Edge c40 c29 m40_29 := by constructor <;> decide
theorem floor40 : Floor c40 4 := by
  have up := refundEdge e40_29 floor29 34816 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c41 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280, 34816],[896, 2432, 2688, 10496, 18944, 26624, 32896, 57344]⟩
def m41_31 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e41_31 : Edge c41 c31 m41_31 := by constructor <;> decide
theorem floor41 : Floor c41 6 := by
  have up := refundEdge e41_31 floor31 34816 32896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c42 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 33024, 33280, 34816],[832, 896, 2496, 2688, 8448, 10496, 19008, 26624, 32960, 49216, 57344]⟩
def m42_41 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e42_41 : Edge c42 c41 m42_41 := by constructor <;> decide
theorem floor42 : Floor c42 7 := by
  have up := refundEdge e42_41 floor41 8256 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c43 : Chart := ⟨[8320, 8704, 16512, 17408, 33280, 34816],[3712, 11264, 18944, 26624, 33920, 41984, 57344]⟩
def m43_40 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e43_40 : Edge c43 c40 m43_40 := by constructor <;> decide
theorem floor43 : Floor c43 5 := by
  have up := refundEdge e43_40 floor40 17408 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c44 : Chart := ⟨[8320, 8704, 16512, 16640, 17408, 33024, 33280, 34816],[896, 1792, 2432, 3712, 11520, 18944, 26624, 33920, 41984, 57344]⟩
def m44_41 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, some 11, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e44_41 : Edge c44 c41 m44_41 := by constructor <;> decide
theorem floor44 : Floor c44 7 := by
  have up := refundEdge e44_41 floor41 17408 18944 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c45 : Chart := ⟨[66048],[512, 65536]⟩
theorem floor45 : Floor c45 0 := fun _ _ _ _ => Nat.zero_le _
def c46 : Chart := ⟨[66560],[1024, 65536]⟩
theorem floor46 : Floor c46 0 := fun _ _ _ _ => Nat.zero_le _
def c47 : Chart := ⟨[8704, 66048],[512, 73728]⟩
def m47_45 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, none, none, none, some 16, none, none, none, none, none]
private theorem e47_45 : Edge c47 c45 m47_45 := by constructor <;> decide
theorem floor47 : Floor c47 1 := by
  have up := refundEdge e47_45 floor45 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)

end TightRow.Protected.Numeric
