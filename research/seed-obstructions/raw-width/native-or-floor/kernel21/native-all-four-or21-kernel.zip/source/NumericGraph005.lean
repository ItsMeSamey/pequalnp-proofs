import Branch91776
import NumericGraph000
import NumericGraph004
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c60 : Chart := ⟨[16640, 17408, 66048, 66560],[1792, 16896, 65792, 81920]⟩
def m60_58 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e60_58 : Edge c60 c58 m60_58 := by constructor <;> decide
theorem floor60 : Floor c60 3 := by
  have up := refundEdge e60_58 floor58 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c61 : Chart := ⟨[17408, 66560, 69632],[5120, 20480, 65536, 81920]⟩
def m61_55 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e61_55 : Edge c61 c55 m61_55 := by constructor <;> decide
theorem floor61 : Floor c61 2 := by
  have up := refundEdge e61_55 floor55 69632 65536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c62 : Chart := ⟨[16512, 17408, 66560, 69632],[5248, 16384, 20480, 65664, 81920]⟩
def m62_61 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, some 14, none, some 16, none, none, none, none, none]
private theorem e62_61 : Edge c62 c61 m62_61 := by constructor <;> decide
theorem floor62 : Floor c62 3 := by
  have up := refundEdge e62_61 floor61 16512 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c63 : Chart := ⟨[16640, 17408, 66560, 69632],[5376, 16384, 20480, 65792, 81920]⟩
def m63_61 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, none, some 12, none, some 14, none, some 16, none, none, none, none, none]
private theorem e63_61 : Edge c63 c61 m63_61 := by constructor <;> decide
theorem floor63 : Floor c63 3 := by
  have up := refundEdge e63_61 floor61 16640 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c64 : Chart := ⟨[8320, 8704, 16512, 66048],[640, 16896, 65664, 90112]⟩
def m64_48 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, none, some 16, none, none, none, none, none]
private theorem e64_48 : Edge c64 c48 m64_48 := by constructor <;> decide
theorem floor64 : Floor c64 3 := by
  have up := refundEdge e64_48 floor48 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c65 : Chart := ⟨[8320, 16512, 17408, 66560],[128, 1152, 9216, 65664, 90112]⟩
def m65_56 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e65_56 : Edge c65 c56 m65_56 := by constructor <;> decide
theorem floor65 : Floor c65 3 := by
  have up := refundEdge e65_56 floor56 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c66 : Chart := ⟨[8704, 17408, 66048, 66560],[512, 1536, 9216, 16896, 90112]⟩
def m66_58 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e66_58 : Edge c66 c58 m66_58 := by constructor <;> decide
theorem floor66 : Floor c66 3 := by
  have up := refundEdge e66_58 floor58 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c67 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560],[1664, 9216, 16896, 65664, 90112]⟩
def m67_66 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e67_66 : Edge c67 c66 m67_66 := by constructor <;> decide
def m67_65 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e67_65 : Edge c67 c65 m67_65 := by constructor <;> decide
def m67_64 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e67_64 : Edge c67 c64 m67_64 := by constructor <;> decide
def m67_59 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, none, some 14, none, some 16, none, none, none, none, none]
private theorem e67_59 : Edge c67 c59 m67_59 := by constructor <;> decide
def m67_51 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, none, none, some 16, none, none, none, none, none]
private theorem e67_51 : Edge c67 c51 m67_51 := by constructor <;> decide
def m67_8 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e67_8 : Edge c67 c8 m67_8 := by constructor <;> decide
theorem floor67 : Floor c67 5 := by
  apply protectedBranch source c67.P c67.N (decode 91776) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 91776, q = 7 ∨ q = 9 ∨ q = 10 ∨ q = 13 ∨ q = 14 ∨ q = 16 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e67_66 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor66 k x net fit)
    · refine ⟨_,goodChild e67_65 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor65 k x net fit)
    · refine ⟨_,goodChild e67_64 10 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor64 k x net fit)
    · refine ⟨_,goodChild e67_59 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor59 k x net fit)
    · refine ⟨_,goodChild e67_51 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor51 k x net fit)
    · refine ⟨_,goodChild e67_8 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor8 k x net fit)
  · exact pairExcluded 91776 91776 [8320, 8704, 16512, 17408, 66048, 66560] [1664, 9216, 16896, 65664, 90112] validBranch91776 (by decide) (by decide) (by decide)
def c68 : Chart := ⟨[8196, 8320, 8704, 16512, 17408, 66048, 66560],[1156, 1540, 1664, 9216, 16900, 65668, 81924, 90112]⟩
def m68_67 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e68_67 : Edge c68 c67 m68_67 := by constructor <;> decide
theorem floor68 : Floor c68 6 := by
  have up := refundEdge e68_67 floor67 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c69 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 66048, 66560],[1216, 1600, 1664, 9216, 16960, 65728, 81984, 90112]⟩
def m69_67 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e69_67 : Edge c69 c67 m69_67 := by constructor <;> decide
theorem floor69 : Floor c69 6 := by
  have up := refundEdge e69_67 floor67 8256 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c70 : Chart := ⟨[8704, 16640, 17408, 66048, 66560],[1792, 9472, 16896, 73984, 90112]⟩
def m70_66 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e70_66 : Edge c70 c66 m70_66 := by constructor <;> decide
theorem floor70 : Floor c70 4 := by
  have up := refundEdge e70_66 floor66 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c71 : Chart := ⟨[8196, 8704, 16640, 17408, 66048, 66560],[1796, 9472, 16900, 65796, 73984, 81924, 90112]⟩
def m71_70 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e71_70 : Edge c71 c70 m71_70 := by constructor <;> decide
theorem floor71 : Floor c71 5 := by
  have up := refundEdge e71_70 floor70 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)

end TightRow.Protected.Numeric
