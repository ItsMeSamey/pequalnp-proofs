import NumericGraph011
import NumericGraph013
import NumericGraph015
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c192 : Chart := ⟨[8704, 33280, 34816, 132096, 133120],[3584, 11264, 41984, 131072, 131584, 172032]⟩
def m192_182 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e192_182 : Edge c192 c182 m192_182 := by constructor <;> decide
theorem floor192 : Floor c192 4 := by
  have up := refundEdge e192_182 floor182 132096 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c193 : Chart := ⟨[8256, 8704, 33280, 34816, 131136, 132096, 133120],[1600, 2624, 3584, 11264, 33856, 41984, 131072, 131584, 172032]⟩
def m193_185 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e193_185 : Edge c193 c185 m193_185 := by constructor <;> decide
theorem floor193 : Floor c193 6 := by
  have up := refundEdge e193_185 floor185 132096 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c194 : Chart := ⟨[8320, 8704, 33280, 34816, 132096, 133120],[3712, 9216, 11264, 33920, 41984, 131712, 163968, 172032]⟩
def m194_192 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e194_192 : Edge c194 c192 m194_192 := by constructor <;> decide
theorem floor194 : Floor c194 5 := by
  have up := refundEdge e194_192 floor192 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c195 : Chart := ⟨[8256, 8320, 8704, 33280, 34816, 131136, 132096, 133120],[1600, 2240, 2624, 3712, 9216, 11264, 33984, 41984, 131712, 163968, 172032]⟩
def m195_193 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e195_193 : Edge c195 c193 m195_193 := by constructor <;> decide
theorem floor195 : Floor c195 7 := by
  have up := refundEdge e195_193 floor193 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c196 : Chart := ⟨[8256, 8704, 33024, 33280, 34816, 131136, 132096, 133120],[1856, 2368, 2624, 3584, 11520, 33792, 33856, 41984, 131840, 139520, 172032]⟩
def m196_193 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e196_193 : Edge c196 c193 m196_193 := by constructor <;> decide
theorem floor196 : Floor c196 7 := by
  have up := refundEdge e196_193 floor193 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c197 : Chart := ⟨[16640, 17408, 33024, 132096],[256, 1280, 33792, 131328, 180224]⟩
def m197_137 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, none, none, some 14, none, none, some 17, none, none, none, none]
private theorem e197_137 : Edge c197 c137 m197_137 := by constructor <;> decide
theorem floor197 : Floor c197 3 := by
  have up := refundEdge e197_137 floor137 33024 256 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c198 : Chart := ⟨[16640, 17408, 33024, 131136, 132096],[1344, 33856, 49216, 131328, 180224]⟩
def m198_197 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e198_197 : Edge c198 c197 m198_197 := by constructor <;> decide
theorem floor198 : Floor c198 4 := by
  have up := refundEdge e198_197 floor197 131136 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c199 : Chart := ⟨[16640, 17408, 33024, 33280, 132096],[1792, 33792, 131840, 147968, 180224]⟩
def m199_197 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e199_197 : Edge c199 c197 m199_197 := by constructor <;> decide
theorem floor199 : Floor c199 4 := by
  have up := refundEdge e199_197 floor197 33280 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c200 : Chart := ⟨[16640, 17408, 33024, 33280, 131136, 132096],[1856, 16960, 33856, 49216, 131328, 131840, 147968, 180224]⟩
def m200_199 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e200_199 : Edge c200 c199 m200_199 := by constructor <;> decide
theorem floor200 : Floor c200 5 := by
  have up := refundEdge e200_199 floor199 131136 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c201 : Chart := ⟨[16640, 33024, 34816, 133120],[256, 2304, 18432, 131328, 180224]⟩
def m201_166 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e201_166 : Edge c201 c166 m201_166 := by constructor <;> decide
theorem floor201 : Floor c201 3 := by
  have up := refundEdge e201_166 floor166 16640 256 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c202 : Chart := ⟨[16640, 33024, 34816, 131136, 133120],[2368, 18496, 49216, 131328, 180224]⟩
def m202_201 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e202_201 : Edge c202 c201 m202_201 := by constructor <;> decide
theorem floor202 : Floor c202 4 := by
  have up := refundEdge e202_201 floor201 131136 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c203 : Chart := ⟨[16512, 16640, 33024, 34816, 133120],[2432, 18432, 131456, 163968, 180224]⟩
def m203_201 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, some 14, some 15, none, some 17, none, none, none, none]
private theorem e203_201 : Edge c203 c201 m203_201 := by constructor <;> decide
theorem floor203 : Floor c203 4 := by
  have up := refundEdge e203_201 floor201 16512 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)

end TightRow.Protected.Numeric
