import Branch58240
import NumericGraph000
import NumericGraph001
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c24 : Chart := ⟨[16640, 17408, 33024, 33280],[1792, 16896, 33792, 49152]⟩
def m24_23 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, some 10, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e24_23 : Edge c24 c23 m24_23 := by constructor <;> decide
theorem floor24 : Floor c24 3 := by
  have up := refundEdge e24_23 floor23 33280 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c25 : Chart := ⟨[16640, 33024, 34816],[2304, 18432, 32768, 49152]⟩
def m25_19 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e25_19 : Edge c25 c19 m25_19 := by constructor <;> decide
theorem floor25 : Floor c25 2 := by
  have up := refundEdge e25_19 floor19 34816 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c26 : Chart := ⟨[16512, 16640, 33024, 34816],[2432, 18432, 32896, 49152]⟩
def m26_25 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e26_25 : Edge c26 c25 m26_25 := by constructor <;> decide
theorem floor26 : Floor c26 3 := by
  have up := refundEdge e26_25 floor25 16512 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c27 : Chart := ⟨[16640, 17408, 33024, 34816],[3328, 18432, 33792, 49152]⟩
def m27_25 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e27_25 : Edge c27 c25 m27_25 := by constructor <;> decide
theorem floor27 : Floor c27 3 := by
  have up := refundEdge e27_25 floor25 17408 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c28 : Chart := ⟨[8320, 16512, 16640, 33024],[128, 384, 8448, 32896, 57344]⟩
def m28_20 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e28_20 : Edge c28 c20 m28_20 := by constructor <;> decide
theorem floor28 : Floor c28 3 := by
  have up := refundEdge e28_20 floor20 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c29 : Chart := ⟨[8320, 8704, 16512, 33280],[640, 16896, 32896, 57344]⟩
def m29_12 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e29_12 : Edge c29 c12 m29_12 := by constructor <;> decide
theorem floor29 : Floor c29 3 := by
  have up := refundEdge e29_12 floor12 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c30 : Chart := ⟨[8704, 16640, 33024, 33280],[512, 768, 8448, 16896, 57344]⟩
def m30_21 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e30_21 : Edge c30 c21 m30_21 := by constructor <;> decide
theorem floor30 : Floor c30 3 := by
  have up := refundEdge e30_21 floor21 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c31 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280],[896, 8448, 16896, 32896, 57344]⟩
def m31_30 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e31_30 : Edge c31 c30 m31_30 := by constructor <;> decide
def m31_29 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e31_29 : Edge c31 c29 m31_29 := by constructor <;> decide
def m31_28 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e31_28 : Edge c31 c28 m31_28 := by constructor <;> decide
def m31_22 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e31_22 : Edge c31 c22 m31_22 := by constructor <;> decide
def m31_15 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e31_15 : Edge c31 c15 m31_15 := by constructor <;> decide
def m31_5 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e31_5 : Edge c31 c5 m31_5 := by constructor <;> decide
theorem floor31 : Floor c31 5 := by
  apply protectedBranch source c31.P c31.N (decode 58240) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 58240, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 13 ∨ q = 14 ∨ q = 15 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e31_30 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor30 k x net fit)
    · refine ⟨_,goodChild e31_29 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor29 k x net fit)
    · refine ⟨_,goodChild e31_28 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor28 k x net fit)
    · refine ⟨_,goodChild e31_22 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor22 k x net fit)
    · refine ⟨_,goodChild e31_15 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor15 k x net fit)
    · refine ⟨_,goodChild e31_5 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor5 k x net fit)
  · exact pairExcluded 58240 58240 [8320, 8704, 16512, 16640, 33024, 33280] [896, 8448, 16896, 32896, 57344] validBranch58240 (by decide) (by decide) (by decide)
def c32 : Chart := ⟨[8196, 8320, 8704, 16512, 16640, 33024, 33280],[388, 772, 896, 8448, 16900, 32900, 49156, 57344]⟩
def m32_31 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e32_31 : Edge c32 c31 m32_31 := by constructor <;> decide
theorem floor32 : Floor c32 6 := by
  have up := refundEdge e32_31 floor31 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c33 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 33024, 33280],[448, 832, 896, 8448, 16960, 32960, 49216, 57344]⟩
def m33_31 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e33_31 : Edge c33 c31 m33_31 := by constructor <;> decide
theorem floor33 : Floor c33 6 := by
  have up := refundEdge e33_31 floor31 8256 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c34 : Chart := ⟨[8704, 16640, 17408, 33024, 33280],[1792, 9472, 16896, 41984, 57344]⟩
def m34_30 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e34_30 : Edge c34 c30 m34_30 := by constructor <;> decide
theorem floor34 : Floor c34 4 := by
  have up := refundEdge e34_30 floor30 17408 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c35 : Chart := ⟨[8256, 8704, 16640, 17408, 33024, 33280],[1856, 9472, 16960, 33856, 41984, 49216, 57344]⟩
def m35_34 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, some 10, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e35_34 : Edge c35 c34 m35_34 := by constructor <;> decide
theorem floor35 : Floor c35 5 := by
  have up := refundEdge e35_34 floor34 8256 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)

end TightRow.Protected.Numeric
