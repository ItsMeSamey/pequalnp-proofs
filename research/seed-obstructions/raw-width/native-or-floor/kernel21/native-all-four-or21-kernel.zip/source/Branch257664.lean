import ProtectedShort

namespace TightRow.Protected.Numeric
namespace Short257664
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def p : List Nat := [8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 132096, 133120]
def n : List Nat := [3712, 11264, 18944, 33920, 41984, 67712, 92160, 114688, 131712, 147968, 188416, 204800, 229504]
def pp := p.map (canonical 257664)
def nn := n.map (canonical 257664)
def parts : List Nat := [0, 128, 2048, 8192, 16384, 32768, 65536, 131072, 8320, 16512, 34816, 133120]
def g : ShortGrid := [(0,[(128,5709077884449424439112895639464797794172141825), (2048,7324746925735282969907702107080020835362924724993), (8192,1), (8320,256), (16384,2923047876832778016247705476368179567442471813121), (16512,8590000128), (32768,5846095753665556032495410952736359134884943626241), (34816,17179870208), (65536,8769143630498334048743116429104538702327415439361), (131072,11692191507331112064990821905472718269769887252481), (133120,34359936256)]), (128,[(2048,21525233664), (8192,1099511627776), (16384,8590000128), (32768,17179934720), (34816,17179934720), (65536,25769869312), (131072,34359803904), (133120,34359803904)]), (2048,[(8192,1411772930064384), (8320,256), (16384,1415071464948224), (16512,65536), (32768,1410690598307072), (65536,25770001664), (131072,34359936256)]), (8192,[(16384,12901679104), (16512,16777216), (32768,21491613696), (34816,21491613696), (65536,30081548288), (131072,34376515584), (133120,34376515584)]), (8320,[(16384,256), (32768,256), (34816,256), (65536,256), (131072,256), (133120,256)]), (16384,[(32768,17213424128), (34816,17213424128), (65536,25803358720), (131072,38688260608), (133120,38688260608)]), (16512,[(32768,65536), (34816,65536), (65536,65536), (131072,65536), (133120,65536)]), (32768,[(65536,30115104000), (131072,34410071296), (133120,21525169408)]), (34816,[(65536,1024), (131072,1024)]), (65536,[(131072,1697645953288448), (133120,197888)])]
private theorem row0 : parts.all (shortPair g pp nn 256128 0) = true := by decide
private theorem row1 : parts.all (shortPair g pp nn 256128 128) = true := by decide
private theorem row2 : parts.all (shortPair g pp nn 256128 2048) = true := by decide
private theorem row3 : parts.all (shortPair g pp nn 256128 8192) = true := by decide
private theorem row4 : parts.all (shortPair g pp nn 256128 16384) = true := by decide
private theorem row5 : parts.all (shortPair g pp nn 256128 32768) = true := by decide
private theorem row6 : parts.all (shortPair g pp nn 256128 65536) = true := by decide
private theorem row7 : parts.all (shortPair g pp nn 256128 131072) = true := by decide
private theorem row8 : parts.all (shortPair g pp nn 256128 8320) = true := by decide
private theorem row9 : parts.all (shortPair g pp nn 256128 16512) = true := by decide
private theorem row10 : parts.all (shortPair g pp nn 256128 34816) = true := by decide
private theorem row11 : parts.all (shortPair g pp nn 256128 133120) = true := by decide
theorem full : checkArms 257664 256128 p n = true := by
  apply recoverFull g (by decide) (by decide)
  change ([0, 128, 2048, 8192, 16384, 32768, 65536, 131072, 8320, 16512, 34816, 133120] : List Nat).all (fun i => parts.all (shortPair g pp nn 256128 i)) = true
  simp only [List.all_cons,List.all_nil,Bool.true_and,row0,row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11]
end Short257664
theorem validBranch257664 : checkArms 257664 256128 [8320, 8704, 16512, 17408, 33280, 34816, 66048, 66560, 132096, 133120] [3712, 11264, 18944, 33920, 41984, 67712, 92160, 114688, 131712, 147968, 188416, 204800, 229504] = true := Short257664.full
end TightRow.Protected.Numeric
