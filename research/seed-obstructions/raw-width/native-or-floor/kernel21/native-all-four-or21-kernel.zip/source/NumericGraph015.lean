import Branch174656
import NumericGraph001
import NumericGraph011
import NumericGraph014
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c180 : Chart := ⟨[8196, 8256, 33024, 34816, 131136, 133120],[2372, 8448, 10496, 32836, 131332, 139520, 163844, 172032]⟩
def m180_179 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e180_179 : Edge c180 c179 m180_179 := by constructor <;> decide
theorem floor180 : Floor c180 5 := by
  have up := refundEdge e180_179 floor179 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c181 : Chart := ⟨[8256, 8320, 33024, 34816, 131136, 133120],[2496, 8448, 10496, 32960, 131456, 139520, 163968, 172032]⟩
def m181_179 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, none, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e181_179 : Edge c181 c179 m181_179 := by constructor <;> decide
theorem floor181 : Floor c181 5 := by
  have up := refundEdge e181_179 floor179 8320 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c182 : Chart := ⟨[8704, 33280, 34816, 133120],[512, 2560, 10240, 131584, 172032]⟩
def m182_168 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e182_168 : Edge c182 c168 m182_168 := by constructor <;> decide
theorem floor182 : Floor c182 3 := by
  have up := refundEdge e182_168 floor168 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c183 : Chart := ⟨[8196, 8704, 33280, 34816, 133120],[2564, 8192, 10240, 131588, 163844, 172032]⟩
def m183_182 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e183_182 : Edge c183 c182 m183_182 := by constructor <;> decide
theorem floor183 : Floor c183 4 := by
  have up := refundEdge e183_182 floor182 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c184 : Chart := ⟨[8196, 8704, 33280, 34816, 131073, 133120],[2565, 10241, 32773, 40961, 131072, 131588, 163844, 172032]⟩
def m184_183 : List (Option Addr) := [none, none, some 2, none, none, none, none, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e184_183 : Edge c184 c183 m184_183 := by constructor <;> decide
theorem floor184 : Floor c184 5 := by
  have up := refundEdge e184_183 floor183 131073 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c185 : Chart := ⟨[8256, 8704, 33280, 34816, 131136, 133120],[2624, 10240, 32832, 131584, 172032]⟩
def m185_182 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e185_182 : Edge c185 c182 m185_182 := by constructor <;> decide
def m185_177 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e185_177 : Edge c185 c177 m185_177 := by constructor <;> decide
def m185_173 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e185_173 : Edge c185 c173 m185_173 := by constructor <;> decide
def m185_169 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e185_169 : Edge c185 c169 m185_169 := by constructor <;> decide
def m185_132 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e185_132 : Edge c185 c132 m185_132 := by constructor <;> decide
def m185_17 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e185_17 : Edge c185 c17 m185_17 := by constructor <;> decide
theorem floor185 : Floor c185 5 := by
  apply protectedBranch source c185.P c185.N (decode 174656) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 174656, q = 6 ∨ q = 9 ∨ q = 11 ∨ q = 13 ∨ q = 15 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e185_182 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor182 k x net fit)
    · refine ⟨_,goodChild e185_177 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor177 k x net fit)
    · refine ⟨_,goodChild e185_173 11 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor173 k x net fit)
    · refine ⟨_,goodChild e185_169 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor169 k x net fit)
    · refine ⟨_,goodChild e185_132 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor132 k x net fit)
    · refine ⟨_,goodChild e185_17 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor17 k x net fit)
  · exact pairExcluded 174656 174656 [8256, 8704, 33280, 34816, 131136, 133120] [2624, 10240, 32832, 131584, 172032] validBranch174656 (by decide) (by decide) (by decide)
def c186 : Chart := ⟨[8196, 8256, 8704, 33280, 34816, 131136, 133120],[2116, 2564, 2624, 8192, 10240, 32836, 131588, 163844, 172032]⟩
def m186_185 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e186_185 : Edge c186 c185 m186_185 := by constructor <;> decide
theorem floor186 : Floor c186 6 := by
  have up := refundEdge e186_185 floor185 8196 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c187 : Chart := ⟨[8320, 8704, 33280, 34816, 133120],[2688, 8192, 10240, 131712, 163968, 172032]⟩
def m187_182 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e187_182 : Edge c187 c182 m187_182 := by constructor <;> decide
theorem floor187 : Floor c187 4 := by
  have up := refundEdge e187_182 floor182 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c188 : Chart := ⟨[8256, 8320, 8704, 33280, 34816, 131136, 133120],[2240, 2624, 2688, 8192, 10240, 32960, 131712, 163968, 172032]⟩
def m188_185 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e188_185 : Edge c188 c185 m188_185 := by constructor <;> decide
theorem floor188 : Floor c188 6 := by
  have up := refundEdge e188_185 floor185 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c189 : Chart := ⟨[8256, 8704, 33024, 33280, 34816, 131136, 133120],[832, 2368, 2624, 10496, 32768, 32832, 131840, 139520, 172032]⟩
def m189_185 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e189_185 : Edge c189 c185 m189_185 := by constructor <;> decide
theorem floor189 : Floor c189 6 := by
  have up := refundEdge e189_185 floor185 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c190 : Chart := ⟨[8196, 8256, 8704, 33024, 33280, 34816, 131136, 133120],[832, 2372, 2564, 2624, 8448, 10496, 32836, 131844, 139520, 163844, 172032]⟩
def m190_189 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e190_189 : Edge c190 c189 m190_189 := by constructor <;> decide
theorem floor190 : Floor c190 7 := by
  have up := refundEdge e190_189 floor189 8196 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c191 : Chart := ⟨[8256, 8320, 8704, 33024, 33280, 34816, 131136, 133120],[832, 2496, 2624, 2688, 8448, 10496, 32960, 131968, 139520, 163968, 172032]⟩
def m191_189 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e191_189 : Edge c191 c189 m191_189 := by constructor <;> decide
theorem floor191 : Floor c191 7 := by
  have up := refundEdge e191_189 floor189 8320 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)

end TightRow.Protected.Numeric
