import NumericGraph010
import NumericGraph013
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c168 : Chart := ⟨[33280, 34816, 133120],[2560, 32768, 131584, 163840]⟩
def m168_164 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e168_164 : Edge c168 c164 m168_164 := by constructor <;> decide
theorem floor168 : Floor c168 2 := by
  have up := refundEdge e168_164 floor164 33280 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c169 : Chart := ⟨[33280, 34816, 131136, 133120],[2624, 32832, 131072, 131584, 163840]⟩
def m169_168 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e169_168 : Edge c169 c168 m169_168 := by constructor <;> decide
theorem floor169 : Floor c169 3 := by
  have up := refundEdge e169_168 floor168 131136 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c170 : Chart := ⟨[34816, 132096, 133120],[3072, 33792, 131072, 163840]⟩
def m170_164 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e170_164 : Edge c170 c164 m170_164 := by constructor <;> decide
theorem floor170 : Floor c170 2 := by
  have up := refundEdge e170_164 floor164 132096 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c171 : Chart := ⟨[33024, 34816, 132096, 133120],[3328, 33792, 131328, 163840]⟩
def m171_170 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e171_170 : Edge c171 c170 m171_170 := by constructor <;> decide
theorem floor171 : Floor c171 3 := by
  have up := refundEdge e171_170 floor170 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c172 : Chart := ⟨[33280, 34816, 132096, 133120],[3584, 33792, 131584, 163840]⟩
def m172_170 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, some 10, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e172_170 : Edge c172 c170 m172_170 := by constructor <;> decide
theorem floor172 : Floor c172 3 := by
  have up := refundEdge e172_170 floor170 33280 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c173 : Chart := ⟨[8256, 8704, 33280, 131136],[512, 576, 32832, 131584, 172032]⟩
def m173_126 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, none, some 13, none, none, none, some 17, none, none, none, none]
private theorem e173_126 : Edge c173 c126 m173_126 := by constructor <;> decide
theorem floor173 : Floor c173 3 := by
  have up := refundEdge e173_126 floor126 33280 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c174 : Chart := ⟨[8256, 8704, 33024, 33280, 131136],[832, 32768, 32832, 131840, 139520, 172032]⟩
def m174_173 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e174_173 : Edge c174 c173 m174_173 := by constructor <;> decide
theorem floor174 : Floor c174 4 := by
  have up := refundEdge e174_173 floor173 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c175 : Chart := ⟨[8256, 8704, 33280, 131136, 132096],[1600, 33856, 41984, 131072, 131584, 172032]⟩
def m175_173 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e175_173 : Edge c175 c173 m175_173 := by constructor <;> decide
theorem floor175 : Floor c175 4 := by
  have up := refundEdge e175_173 floor173 132096 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c176 : Chart := ⟨[8256, 8704, 33024, 33280, 131136, 132096],[1856, 9472, 33792, 33856, 41984, 131840, 139520, 172032]⟩
def m176_175 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e176_175 : Edge c176 c175 m176_175 := by constructor <;> decide
theorem floor176 : Floor c176 5 := by
  have up := refundEdge e176_175 floor175 33024 33792 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c177 : Chart := ⟨[8256, 34816, 131136, 133120],[64, 2112, 10240, 32832, 172032]⟩
def m177_165 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e177_165 : Edge c177 c165 m177_165 := by constructor <;> decide
theorem floor177 : Floor c177 3 := by
  have up := refundEdge e177_165 floor165 8256 64 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c178 : Chart := ⟨[8256, 8320, 34816, 131136, 133120],[2240, 8192, 10240, 32960, 163968, 172032]⟩
def m178_177 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e178_177 : Edge c178 c177 m178_177 := by constructor <;> decide
theorem floor178 : Floor c178 4 := by
  have up := refundEdge e178_177 floor177 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c179 : Chart := ⟨[8256, 33024, 34816, 131136, 133120],[2368, 10496, 32768, 32832, 139520, 172032]⟩
def m179_177 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, none, some 11, none, some 13, none, some 15, none, some 17, none, none, none, none]
private theorem e179_177 : Edge c179 c177 m179_177 := by constructor <;> decide
theorem floor179 : Floor c179 4 := by
  have up := refundEdge e179_177 floor177 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)

end TightRow.Protected.Numeric
