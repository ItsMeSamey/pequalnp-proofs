import Branch222912
import NumericGraph005
import NumericGraph012
import NumericGraph022
import ProtectedNumericBranch
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c276 : Chart := ⟨[2105408, 8704, 66048, 2166784, 2228288],[2101824, 2162752, 2232832, 2240512, 204800]⟩
def m276_264 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, none, some 13, none, none, some 16, some 17, none, none, none, some 6]
private theorem e276_264 : Edge c276 c264 m276_264 := by constructor <;> decide
theorem floor276 : Floor c276 4 := by
  have up := refundEdge e276_264 floor264 2166784 2162752 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c277 : Chart := ⟨[2105408, 66560, 2166784, 2228288, 132096],[2102336, 2110464, 2162752, 2240512, 204800]⟩
def m277_265 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, some 6]
private theorem e277_265 : Edge c277 c265 m277_265 := by constructor <;> decide
theorem floor277 : Floor c277 4 := by
  have up := refundEdge e277_265 floor265 2166784 2162752 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c278 : Chart := ⟨[8196, 2105408, 66560, 2166784, 2228288, 132096],[2102340, 9216, 2110464, 2162756, 2232324, 2240512, 196612, 204800]⟩
def m278_277 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, some 12, some 13, none, none, some 16, some 17, none, none, none, some 21]
private theorem e278_277 : Edge c278 c277 m278_277 := by constructor <;> decide
theorem floor278 : Floor c278 5 := by
  have up := refundEdge e278_277 floor277 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c279 : Chart := ⟨[2105408, 8320, 66560, 2166784, 2228288, 132096],[2102464, 9216, 2110464, 2162880, 2232448, 2240512, 196736, 204800]⟩
def m279_277 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, none, some 10, none, some 12, some 13, none, none, some 16, some 17, none, none, none, some 21]
private theorem e279_277 : Edge c279 c277 m279_277 := by constructor <;> decide
theorem floor279 : Floor c279 5 := by
  have up := refundEdge e279_277 floor277 8320 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c280 : Chart := ⟨[2105408, 8704, 66048, 2166784, 2228288, 133120],[2103872, 2111488, 2164800, 75776, 131072, 2232832, 2240512, 204800]⟩
def m280_276 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, none, none, some 12, some 13, none, none, some 16, some 17, none, none, none, some 21]
private theorem e280_276 : Edge c280 c276 m280_276 := by constructor <;> decide
theorem floor280 : Floor c280 5 := by
  have up := refundEdge e280_276 floor276 133120 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c281 : Chart := ⟨[8256, 8320, 16512, 17408, 66560, 131136, 132096],[1152, 1216, 9216, 65728, 81984, 90112, 155648, 196736, 204800]⟩
def m281_146 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e281_146 : Edge c281 c146 m281_146 := by constructor <;> decide
theorem floor281 : Floor c281 6 := by
  have up := refundEdge e281_146 floor146 66560 1152 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c282 : Chart := ⟨[8256, 8704, 17408, 66048, 66560, 131136, 132096],[1536, 1600, 9216, 16960, 81984, 90112, 147968, 155648, 204800]⟩
def m282_269 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e282_269 : Edge c282 c269 m282_269 := by constructor <;> decide
theorem floor282 : Floor c282 6 := by
  have up := refundEdge e282_269 floor269 17408 1536 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c283 : Chart := ⟨[8320, 8704, 16512, 17408, 66048, 66560, 132096],[1664, 9216, 90112, 131712, 147968, 155648, 196736, 204800]⟩
def m283_67 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e283_67 : Edge c283 c67 m283_67 := by constructor <;> decide
theorem floor283 : Floor c283 6 := by
  have up := refundEdge e283_67 floor67 132096 1664 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c284 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 66048, 66560, 131136, 132096],[1216, 1600, 1664, 9216, 16960, 65728, 81984, 90112, 131712, 147968, 155648, 196736, 204800]⟩
def m284_283 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e284_283 : Edge c284 c283 m284_283 := by constructor <;> decide
def m284_282 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e284_282 : Edge c284 c282 m284_282 := by constructor <;> decide
def m284_281 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e284_281 : Edge c284 c281 m284_281 := by constructor <;> decide
def m284_271 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, none, none, some 16, some 17, none, none, none, none]
private theorem e284_271 : Edge c284 c271 m284_271 := by constructor <;> decide
def m284_154 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e284_154 : Edge c284 c154 m284_154 := by constructor <;> decide
def m284_69 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, none, none, none, none, none]
private theorem e284_69 : Edge c284 c69 m284_69 := by constructor <;> decide
theorem floor284 : Floor c284 8 := by
  apply protectedBranch source c284.P c284.N (decode 213696) 8
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 213696, q = 6 ∨ q = 7 ∨ q = 9 ∨ q = 14 ∨ q = 16 ∨ q = 17 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e284_283 6 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor283 k x net fit)
    · refine ⟨_,goodChild e284_282 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor282 k x net fit)
    · refine ⟨_,goodChild e284_281 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor281 k x net fit)
    · refine ⟨_,goodChild e284_271 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor271 k x net fit)
    · refine ⟨_,goodChild e284_154 16 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor154 k x net fit)
    · refine ⟨_,goodChild e284_69 17 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 8-2 ≤ 6).trans (floor69 k x net fit)
  · exact pairExcluded 222912 213696 [8256, 8320, 8704, 16512, 17408, 66048, 66560, 131136, 132096] [1216, 1600, 1664, 9216, 16960, 65728, 81984, 90112, 131712, 147968, 155648, 196736, 204800] validBranch222912 (by decide) (by decide) (by decide)
def c285 : Chart := ⟨[8196, 8256, 8320, 8704, 16512, 17408, 66048, 66560, 131136, 132096],[1092, 1156, 1216, 1540, 1600, 1664, 9216, 16960, 65728, 81988, 90112, 131712, 147972, 155648, 196740, 204800]⟩
def m285_284 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e285_284 : Edge c285 c284 m285_284 := by constructor <;> decide
theorem floor285 : Floor c285 9 := by
  have up := refundEdge e285_284 floor284 8196 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 9 ≤ 9).trans (up k x net fit)
def c286 : Chart := ⟨[8256, 8704, 16640, 17408, 66048, 66560, 131136, 132096],[1856, 9472, 16896, 16960, 65856, 81984, 90112, 131840, 147968, 155648, 205056]⟩
def m286_282 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, none, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e286_282 : Edge c286 c282 m286_282 := by constructor <;> decide
theorem floor286 : Floor c286 7 := by
  have up := refundEdge e286_282 floor282 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c287 : Chart := ⟨[8196, 8256, 8704, 16640, 17408, 66048, 66560, 131136, 132096],[1348, 1796, 1856, 9472, 16960, 65860, 81988, 90112, 131844, 147972, 155648, 196868, 205056]⟩
def m287_286 : List (Option Addr) := [none, none, none, none, none, none, some 6, none, some 8, some 9, some 10, none, none, some 13, some 14, none, some 16, some 17, none, none, none, none]
private theorem e287_286 : Edge c287 c286 m287_286 := by constructor <;> decide
theorem floor287 : Floor c287 8 := by
  have up := refundEdge e287_286 floor286 8196 9472 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 8 ≤ 8).trans (up k x net fit)

end TightRow.Protected.Numeric
