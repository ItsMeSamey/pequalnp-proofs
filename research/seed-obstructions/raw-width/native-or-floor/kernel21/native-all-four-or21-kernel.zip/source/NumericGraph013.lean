import NumericGraph010
import NumericGraph011
import NumericGraph012
import ProtectedNumericEdges

namespace TightRow.Protected.Numeric
open TightRow.Protected
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def c156 : Chart := ⟨[8256, 8320, 8704, 16512, 16640, 17408, 131136, 132096],[448, 1216, 1664, 1856, 9472, 16896, 16960, 131968, 139520, 147968, 155648]⟩
def m156_154 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, some 9, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e156_154 : Edge c156 c154 m156_154 := by constructor <;> decide
theorem floor156 : Floor c156 7 := by
  have up := refundEdge e156_154 floor154 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c157 : Chart := ⟨[8256, 8320, 16512, 131136, 133120],[2240, 18496, 26624, 131200, 155648]⟩
def m157_142 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e157_142 : Edge c157 c142 m157_142 := by constructor <;> decide
theorem floor157 : Floor c157 4 := by
  have up := refundEdge e157_142 floor142 133120 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c158 : Chart := ⟨[8256, 8320, 16512, 16640, 131136, 133120],[2496, 10496, 18432, 18496, 26624, 131456, 139520, 155648]⟩
def m158_157 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, none, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e158_157 : Edge c158 c157 m158_157 := by constructor <;> decide
theorem floor158 : Floor c158 5 := by
  have up := refundEdge e158_157 floor157 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c159 : Chart := ⟨[8320, 16512, 17408, 132096, 133120],[3200, 11264, 26624, 131200, 155648]⟩
def m159_145 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e159_145 : Edge c159 c145 m159_145 := by constructor <;> decide
theorem floor159 : Floor c159 4 := by
  have up := refundEdge e159_145 floor145 133120 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 4 ≤ 4).trans (up k x net fit)
def c160 : Chart := ⟨[8256, 8320, 16512, 17408, 131136, 132096, 133120],[1216, 2240, 3200, 11264, 18496, 26624, 131200, 155648]⟩
def m160_146 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, none, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e160_146 : Edge c160 c146 m160_146 := by constructor <;> decide
theorem floor160 : Floor c160 6 := by
  have up := refundEdge e160_146 floor146 133120 131200 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 6 ≤ 6).trans (up k x net fit)
def c161 : Chart := ⟨[8256, 8320, 16512, 16640, 17408, 131136, 132096, 133120],[1216, 1344, 2496, 3200, 11520, 18432, 18496, 26624, 131456, 139520, 155648]⟩
def m161_160 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e161_160 : Edge c161 c160 m161_160 := by constructor <;> decide
theorem floor161 : Floor c161 7 := by
  have up := refundEdge e161_160 floor160 16640 18432 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c162 : Chart := ⟨[8320, 8704, 16512, 17408, 132096, 133120],[3712, 9216, 11264, 18944, 26624, 131712, 147968, 155648]⟩
def m162_159 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e162_159 : Edge c162 c159 m162_159 := by constructor <;> decide
theorem floor162 : Floor c162 5 := by
  have up := refundEdge e162_159 floor159 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 5 ≤ 5).trans (up k x net fit)
def c163 : Chart := ⟨[8256, 8320, 8704, 16512, 17408, 131136, 132096, 133120],[1216, 1600, 2240, 3712, 9216, 11264, 19008, 26624, 131712, 147968, 155648]⟩
def m163_160 : List (Option Addr) := [none, none, none, none, none, none, some 6, some 7, none, none, some 10, some 11, none, some 13, some 14, none, none, some 17, none, none, none, none]
private theorem e163_160 : Edge c163 c160 m163_160 := by constructor <;> decide
theorem floor163 : Floor c163 7 := by
  have up := refundEdge e163_160 floor160 8704 9216 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 7 ≤ 7).trans (up k x net fit)
def c164 : Chart := ⟨[34816, 133120],[2048, 163840]⟩
def m164_121 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, none, none, some 17, none, none, none, none]
private theorem e164_121 : Edge c164 c121 m164_121 := by constructor <;> decide
theorem floor164 : Floor c164 1 := by
  have up := refundEdge e164_121 floor121 34816 2048 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c165 : Chart := ⟨[34816, 131136, 133120],[2112, 32832, 131072, 163840]⟩
def m165_164 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e165_164 : Edge c165 c164 m165_164 := by constructor <;> decide
theorem floor165 : Floor c165 2 := by
  have up := refundEdge e165_164 floor164 131136 131072 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c166 : Chart := ⟨[33024, 34816, 133120],[2304, 32768, 131328, 163840]⟩
def m166_164 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, none, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e166_164 : Edge c166 c164 m166_164 := by constructor <;> decide
theorem floor166 : Floor c166 2 := by
  have up := refundEdge e166_164 floor164 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c167 : Chart := ⟨[33024, 34816, 131073, 133120],[2305, 32769, 131328, 163840]⟩
def m167_166 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, some 11, none, none, none, some 15, none, some 17, none, none, none, none]
private theorem e167_166 : Edge c167 c166 m167_166 := by constructor <;> decide
theorem floor167 : Floor c167 3 := by
  have up := refundEdge e167_166 floor166 131073 131328 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)

end TightRow.Protected.Numeric
