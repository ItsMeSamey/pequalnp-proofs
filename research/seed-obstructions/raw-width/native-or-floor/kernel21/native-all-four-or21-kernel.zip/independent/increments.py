import json,contextlib,io,hashlib
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()):
    from check import charts,idx,rows,signed,orig_label
fn=Path('/workspace/scratch/protected23-numeric/increment-chains.json')
data=json.loads(fn.read_bytes())
for target,path in data.items():
    cur=2763;counts=[0,0]
    for e in path:
        i,j,q,s,t,m,p,n=(e[k] for k in ['i','j','q','s','t','m','posID','negID'])
        assert i==cur and s==idx[i][0] and t==idx[j][0]==s^q and q&s==q
        cp,cn,_=charts[j]; pp,nn,_=charts[i]
        assert orig_label(True,p) and orig_label(False,n) and rows[p]&~s==0 and rows[p]&q
        assert m[:20]==[v if t>>v&1 else None for v in range(20)]
        for h,c in [(20,129),(21,4160)]:
            r=(c&t) if s&c==c else 0
            assert m[h]==(None if r==0 else h if r==c else r.bit_length()-1)
        assert e['a']==signed(rows[p],s)
        assert e['b']==signed(rows[n],s)
        assert e['a'] in [signed(v,s) for v in pp] and e['b'] in [signed(v,s) for v in nn]
        assert not((e['a']&~e['b'])&sum(1<<v for v,h in enumerate(m) if h is not None))
        lift=lambda r:sum((h is not None and bool(r>>h&1))<<v for v,h in enumerate(m))
        assert cp and cn
        for x,h in zip(cp,e['up'],strict=True):assert signed(pp[h],s)&~lift(signed(x,t))==0
        for x,h in zip(cn,e['down'],strict=True):assert lift(signed(x,t))&~signed(nn[h],s)==0
        counts[0]+=len(cp);counts[1]+=len(cn);cur=j
    assert cur==int(target)
    print(target,'child floor',idx[cur][1],'+ refunds',len(path),'=',idx[cur][1]+len(path),'positive/negative transfers',counts)
print('source',hashlib.sha256(fn.read_bytes()).hexdigest())
