import ProtectedArm
namespace TightRow.Protected
universe u v w
variable {I : Type u} {G : Type v} {R : Type w}

structure Factors (I : Type u) (G : Type v) where
  raw : Finset I
  gates : Finset G

def Factors.eval (f : Factors I G) (v : I → Set R) (g : G → Set R) : Set R :=
  {x | (∀ i ∈ f.raw, x ∈ v i) ∧ ∀ i ∈ f.gates, x ∈ g i}

def extendFn {A B : Type*} (f : A → B) (x : B) : Option A → B
  | none => x
  | some a => f a

inductive Program (I : Type u) : (G : Type v) → Nat → Type (max u (v+1)) where
  | output {G : Type v} (f : Factors I G) : Program I G 0
  | join {G : Type v} {k : Nat} (a b : Factors I G) (rest : Program I (Option G) k) : Program I G (k+1)

def Program.eval {G : Type v} {k} (p : Program I G k) (v : I → Set R) (g : G → Set R) : Set R :=
  match p with
  | .output f => f.eval v g
  | .join a b t => t.eval v (extendFn g (a.eval v g ∪ b.eval v g))

def Factors.meet [DecidableEq I] [DecidableEq G] (a b : Factors I G) : Factors I G :=
  ⟨a.raw ∪ b.raw,a.gates ∪ b.gates⟩
def Factors.old [DecidableEq (Option G)] (a : Factors I G) : Factors I (Option G) :=
  ⟨a.raw,a.gates.image some⟩
def Factors.strip [DecidableEq I] (a : Factors I G) (c : Finset I) : Factors I G :=
  ⟨a.raw \ c,a.gates⟩

theorem Factors.eval_meet [DecidableEq I] [DecidableEq G] (a b : Factors I G)
    (v : I → Set R) (g : G → Set R) :
    (a.meet b).eval v g = a.eval v g ∩ b.eval v g := by
  ext x
  simp only [Factors.eval,Factors.meet,Set.mem_setOf_eq,Set.mem_inter_iff,Finset.mem_union]
  constructor
  · rintro ⟨h,j⟩
    exact ⟨⟨fun i hi => h i (Or.inl hi),fun i hi => j i (Or.inl hi)⟩,
      fun i hi => h i (Or.inr hi),fun i hi => j i (Or.inr hi)⟩
  · rintro ⟨⟨ha,ga⟩,hb,gb⟩
    exact ⟨fun i hi => hi.elim (ha i) (hb i),fun i hi => hi.elim (ga i) (gb i)⟩

theorem Factors.eval_old [DecidableEq (Option G)] (a : Factors I G)
    (v : I → Set R) (g : G → Set R) (s : Set R) :
    a.old.eval v (extendFn g s) = a.eval v g := by
  ext x
  simp [Factors.eval,Factors.old,extendFn]

theorem Factors.eval_split [DecidableEq I] (a : Factors I G) (c : Finset I)
    (hc : c ⊆ a.raw) (v : I → Set R) (g : G → Set R) :
    a.eval v g = {x | ∀ i ∈ c, x ∈ v i} ∩ (a.strip c).eval v g := by
  classical
  ext x
  constructor
  · rintro ⟨h,j⟩
    exact ⟨fun i hi => h i (hc hi),fun i hi => h i (Finset.mem_sdiff.mp hi).1,j⟩
  · rintro ⟨h,j,t⟩
    refine ⟨?_,t⟩
    intro i hi
    by_cases hm : i ∈ c
    · exact h i hm
    · exact j i (Finset.mem_sdiff.mpr ⟨hi,hm⟩)

def common [DecidableEq I] (a b : Factors I G) := a.raw ∩ b.raw
def guarded (a : Finset I) : Factors I (Option G) := ⟨a,{none}⟩

noncomputable def flatten {G : Type v} {S : Type*} {k : Nat} (t : Tape S k)
    (e : S → Factors I G) : Program I G k := by
  classical
  exact match t with
  | .output i => .output (e i)
  | .andGate a b rest => flatten rest (extendFn e ((e a).meet (e b)))
  | .orGate a b rest =>
    let c := common (e a) (e b)
    .join ((e a).strip c) ((e b).strip c)
      (flatten rest (extendFn (fun i => (e i).old) (guarded c)))

def DisjointArms {G : Type v} {k} (p : Program I G k) : Prop :=
  match p with
  | .output _ => True
  | .join a b tail => (∀ i ∈ a.raw, i ∉ b.raw) ∧ DisjointArms tail

end TightRow.Protected
