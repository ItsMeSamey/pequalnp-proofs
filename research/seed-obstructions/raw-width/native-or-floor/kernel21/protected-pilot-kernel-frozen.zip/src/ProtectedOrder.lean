import ProtectedBuild
namespace TightRow.Protected
universe u v w
variable {I : Type u} {G : Type v} {R X : Type*}

def Outside (v : I → Set R) (held : Finset I) (x y : R) : Prop :=
  ∀ i, i ∉ held → x ∈ v i → y ∈ v i
def hitsRaw (v : I → Set R) (s : Finset I) : Set R := {x | ∀ i ∈ s, x ∈ v i}

theorem Factors.below (a : Factors I G) {v : I → Set R} {w : I → Set X}
    {g : G → Set R} {h : G → Set X} {x : R} {y : X}
    (vr : ∀ i ∈ a.raw, x ∈ v i → y ∈ w i)
    (gr : ∀ i, x ∈ g i → y ∈ h i) : x ∈ a.eval v g → y ∈ a.eval w h :=
  fun q => ⟨fun i hi => vr i (by exact hi) (q.1 i hi),fun i hi => gr i (q.2 i hi)⟩

theorem programBelow {k} (p : Program I G k) {v : I → Set R} {w : I → Set X}
    {g : G → Set R} {h : G → Set X} {x : R} {y : X}
    (vr : ∀ i, x ∈ v i → y ∈ w i) (gr : ∀ i, x ∈ g i → y ∈ h i) :
    x ∈ p.eval v g → y ∈ p.eval w h := by
  induction p with
  | output f => exact f.below (fun i _ => vr i) gr
  | join a b tail ih =>
    apply ih
    intro i hi
    cases i with
    | none =>
      exact hi.elim (fun t => Or.inl (a.below (fun i _ => vr i) gr t))
        (fun t => Or.inr (b.below (fun i _ => vr i) gr t))
    | some i => exact gr i hi

def finalRaw {G : Type v} {k} (p : Program I G k) : Finset I :=
  match p with
  | .output f => f.raw
  | .join _ _ t => finalRaw t

theorem final_lit {k} (p : Program I G k) (v : I → Set R) (g : G → Set R)
    {i : I} (hm : i ∈ finalRaw p) : p.eval v g ⊆ v i := by
  induction p with
  | output f => exact fun _ h => h.1 i hm
  | join _ _ t ih => exact ih _ hm

def oneLit (i : I) : I → Prop := fun j => j = i
theorem noHit {q : I} {a b : Factors I G} (h : ¬ Hit (oneLit q) a b) :
    q ∉ a.raw ∧ q ∉ b.raw :=
  ⟨fun ha => h ⟨q,Or.inl ha,rfl⟩,fun hb => h ⟨q,Or.inr hb,rfl⟩⟩

theorem avoidMono {k} (p : Program I G k) (v : I → Set R) (g : G → Set R)
    {held : Finset I} (avoid : ∀ i ∈ held, touches (oneLit i) p = 0)
    (last : ∀ i ∈ held, i ∉ finalRaw p) {x y : R} (le : Outside v held x y)
    (hist : ∀ i, x ∈ g i → y ∈ g i) : x ∈ p.eval v g → y ∈ p.eval v g := by
  classical
  induction p with
  | output f => exact f.below (fun i hi => le i (fun h => last i h hi)) hist
  | join a b tail ih =>
    have off (i : I) (hi : i ∈ held) : ¬ Hit (oneLit i) a b ∧ touches (oneLit i) tail = 0 := by
      have h := avoid i hi
      simp only [touches] at h
      split at h <;> rename_i cut
      · omega
      · exact ⟨cut,by omega⟩
    apply ih _ (fun i hi => (off i hi).2) last
    intro j hj
    cases j with
    | some j => exact hist j hj
    | none =>
      rcases hj with ha | hb
      · exact Or.inl (a.below (fun i hia => le i (fun hi => (noHit (off i hi).1).1 hia)) hist ha)
      · exact Or.inr (b.below (fun i hib => le i (fun hi => (noHit (off i hi).1).2 hib)) hist hb)

theorem Factors.asArm [DecidableEq I] (a : Factors I G) (held : Finset I)
    (v : I → Set R) (g : G → Set R) (hist : ∀ i, Up (Outside v held) (g i)) :
    IsArm (Outside v held) (hitsRaw v (a.raw ∩ held)) (a.eval v g) := by
  let f : Set R := {x | (∀ i ∈ a.raw, i ∉ held → x ∈ v i) ∧ ∀ j ∈ a.gates, x ∈ g j}
  refine ⟨f,?_,?_⟩
  · rintro x y le ⟨h,j⟩
    exact ⟨fun i hi off => le i off (h i hi off),fun i hi => hist i x y le (j i hi)⟩
  · ext x
    constructor
    · rintro ⟨r,j⟩
      exact ⟨fun i hi => r i (Finset.mem_inter.mp hi).1,fun i hi _ => r i hi,j⟩
    · rintro ⟨r,t,j⟩
      refine ⟨?_,j⟩
      intro i hi
      by_cases owns : i ∈ held
      · exact r i (Finset.mem_inter.mpr ⟨hi,owns⟩)
      · exact t i hi owns

end TightRow.Protected
