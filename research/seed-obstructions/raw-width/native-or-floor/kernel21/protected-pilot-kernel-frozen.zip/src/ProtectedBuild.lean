import ProtectedSyntax
namespace TightRow.Protected
universe u v w
variable {I : Type u} {G : Type v} {R : Type w}

def Easy (B : Bank R) (s : Set R) := s = ∅ ∨ s = Set.univ ∨ Product B s

theorem Easy.meet {B : Bank R} {a b : Set R} (ha : Easy B a) (hb : Easy B b) :
    Easy B (a ∩ b) := by
  rcases ha with rfl | rfl | pa
  · exact Or.inl (by simp)
  · simpa using hb
  rcases hb with rfl | rfl | pb
  · exact Or.inl (by simp)
  · simpa [Easy] using (Or.inr (Or.inr pa) : Easy B a)
  exact Or.inr (Or.inr (.meet pa pb))

theorem Easy.grow {B : Bank R} {a : Set R} (ha : Easy B a) (s : Set R) :
    Easy (insert s B) a := by
  rcases ha with h | h | p
  · exact Or.inl h
  · exact Or.inr (Or.inl h)
  exact Or.inr (Or.inr (p.map (fun _ hm => .atom (Or.inr hm))))

theorem easyAll {J : Type*} (B : Bank R) (s : Finset J) (val : J → Set R)
    (h : ∀ i ∈ s, Easy B (val i)) : Easy B {x | ∀ i ∈ s, x ∈ val i} := by
  classical
  induction s using Finset.induction_on with
  | empty =>
    right
    left
    ext x
    simp
  | @insert a s fresh ih =>
    have eqn : {x | ∀ i ∈ insert a s, x ∈ val i} =
        val a ∩ {x | ∀ i ∈ s, x ∈ val i} := by ext x; simp
    rw [eqn]
    exact (h a (by simp)).meet (ih (fun i hi => h i (Finset.mem_insert_of_mem hi)))

theorem Factors.easy (a : Factors I G) {B : Bank R} {v : I → Set R} {g : G → Set R}
    (vr : ∀ i, Easy B (v i)) (gr : ∀ i, Easy B (g i)) : Easy B (a.eval v g) :=
  (easyAll B a.raw v (fun i _ => vr i)).meet (easyAll B a.gates g (fun i _ => gr i))

def Hit (kill : I → Prop) (a b : Factors I G) :=
  ∃ i, (i ∈ a.raw ∨ i ∈ b.raw) ∧ kill i

noncomputable def touches {G : Type v} {k} (kill : I → Prop) (p : Program I G k) : Nat := by
  classical
  exact match p with
  | .output _ => 0
  | .join a b rest => (if Hit kill a b then 1 else 0) + touches kill rest

private theorem twoProducts {B : Bank R} {a b : Set R} (ha : Easy B a) (hb : Easy B b)
    (need : ¬Easy B (a ∪ b)) : Product B a ∧ Product B b := by
  rcases ha with rfl | rfl | pa
  · exact (need (by simpa using hb)).elim
  · exact (need (Or.inr (Or.inl (by simp)))).elim
  rcases hb with rfl | rfl | pb
  · exact (need (by simpa [Easy] using (Or.inr (Or.inr pa) : Easy B a))).elim
  · exact (need (Or.inr (Or.inl (by simp)))).elim
  exact ⟨pa,pb⟩

private theorem easyHit {B : Bank R} {a b : Factors I G} {v : I → Set R} {g : G → Set R}
    {kill : I → Prop} (off : ∀ i, kill i → v i = ∅)
    (pa : Easy B (a.eval v g)) (pb : Easy B (b.eval v g)) (hit : Hit kill a b) :
    Easy B (a.eval v g ∪ b.eval v g) := by
  obtain ⟨i,hi,ki⟩ := hit
  have zero (f : Factors I G) (mem : i ∈ f.raw) : f.eval v g = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    intro x hx
    have h := hx.1 i mem
    rw [off i ki] at h
    exact h
  rcases hi with ha | hb
  · simpa [zero a ha] using pb
  · simpa [zero b hb] using pa

/-- Every OR with a killed explicit raw factor is refunded. -/
theorem build {k} (p : Program I G k) {v : I → Set R} {g : G → Set R} (B : Bank R)
    (vr : ∀ i, Easy B (v i)) (gr : ∀ i, Easy B (g i))
    (kill : I → Prop) (off : ∀ i, kill i → v i = ∅)
    (yes : (p.eval v g).Nonempty) (no : ∃ x, x ∉ p.eval v g) :
    ∃ j, j + touches kill p ≤ k ∧ Net B (p.eval v g) j := by
  classical
  induction p generalizing B with
  | output f =>
    rcases f.easy vr gr with zero | top | pf
    · change (f.eval v g).Nonempty at yes
      simp [zero] at yes
    · change ∃ x, x ∉ f.eval v g at no
      simp [top] at no
    · exact ⟨0,by simp [touches],.stop pf⟩
  | @join G k a b rest ih =>
    let s := a.eval v g ∪ b.eval v g
    have ep := a.easy vr gr
    have eq := b.easy vr gr
    by_cases free : Easy B s
    · have gg : ∀ i, Easy B (extendFn g s i) := by
        intro i
        cases i with
        | none => exact free
        | some i => exact gr i
      obtain ⟨j,hj,pj⟩ := ih B vr gg yes no
      refine ⟨j,?_,pj⟩
      simp only [touches]
      split <;> omega
    · obtain ⟨pa,pb⟩ := twoProducts ep eq free
      have miss : ¬ Hit kill a b := fun h => free (easyHit off ep eq h)
      have gg : ∀ i, Easy (insert s B) (extendFn g s i) := by
        intro i
        cases i with
        | none => exact Or.inr (Or.inr (.atom (Set.mem_insert _ _)))
        | some i => exact (gr i).grow s
      obtain ⟨j,hj,pj⟩ := ih _ (fun i => (vr i).grow s) gg yes no
      refine ⟨j+1,?_,.step pa pb pj⟩
      simp only [touches,if_neg miss,Nat.zero_add]
      omega

end TightRow.Protected
