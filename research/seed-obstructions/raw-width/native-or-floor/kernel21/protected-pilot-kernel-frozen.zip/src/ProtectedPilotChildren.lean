import ProtectedPilotTest
import ProtectedMinimum
namespace TightRow.Protected.Pilot

def stripped (q : I) (x : Row) := (active x).erase q
def restricted (q i : I) : Set Row := {x | i ∈ stripped q x}
def kept (q : I) : Finset Row := positives.toFinset.filter (fun x => q ∉ active x)
def childP (q : I) : Set Row := {r | r ∈ kept q}

def packing (q : I) : Finset Row :=
  ([{2,3,4},{0,1,5},{0,1,3},{1,2,5},{0,3,4},{0,2,4}] : List (Finset Row)).getD q.val ∅
def low (q : I) : Row := ([6,6,6,8,7,7] : List Row).getD q.val 6

private theorem tests : ∀ q : I,
    (kept q).card = 4 ∧ (packing q).card = 3 ∧ packing q ⊆ kept q ∧ low q ∈ negatives ∧
    (∀ i : I, i ∉ stripped q (low q) →
      ∀ x ∈ packing q, i ∈ stripped q x → ∀ y ∈ packing q, i ∈ stripped q y → x = y) ∧
    ∀ x ∈ kept q, ∀ y ∈ kept q, x ≠ y →
      ∃ n ∈ negatives, stripped q x ∩ stripped q y ⊆ stripped q n := by
  have sizes : ∀ q : I, (kept q).card = 4 ∧ (packing q).card = 3 ∧
      packing q ⊆ kept q ∧ low q ∈ negatives := by decide
  have one : (List.finRange 6).all (fun q => (List.finRange 6).all (fun i =>
      positives.all (fun x => positives.all (fun y =>
        decide (i ∉ stripped q (low q) → x ∈ packing q → i ∈ stripped q x →
          y ∈ packing q → i ∈ stripped q y → x = y))))) = true := by decide
  have separated : (List.finRange 6).all (fun q => positives.all (fun x =>
      positives.all (fun y => !(decide (x ∈ kept q ∧ y ∈ kept q ∧ x ≠ y)) ||
        negatives.any (fun n => decide (stripped q x ∩ stripped q y ⊆ stripped q n))))) = true := by decide
  intro q
  obtain ⟨s4,s3,inc,neg⟩ := sizes q
  have pos {x : Row} (h : x ∈ kept q) : x ∈ positives :=
    List.mem_toFinset.mp (Finset.mem_filter.mp h).1
  refine ⟨s4,s3,inc,neg,?_,?_⟩
  · intro i lo x hx ax y hy ay
    have hq := List.all_eq_true.mp one q (by simp)
    have hi := List.all_eq_true.mp hq i (by simp)
    have hx' := List.all_eq_true.mp hi x (pos (inc hx))
    have hy' := List.all_eq_true.mp hx' y (pos (inc hy))
    exact (of_decide_eq_true hy') lo hx ax hy ay
  · intro x hx y hy ne
    have hq := List.all_eq_true.mp separated q (by simp)
    have hx' := List.all_eq_true.mp hq x (pos hx)
    have hy' := List.all_eq_true.mp hx' y (pos hy)
    have term : negatives.any (fun n => decide (stripped q x ∩ stripped q y ⊆ stripped q n)) = true := by
      simpa [hx,hy,ne] using hy'
    obtain ⟨n,hn,h⟩ := List.any_eq_true.mp term
    exact ⟨n,hn,of_decide_eq_true h⟩

private theorem forceProd {q : I} {x y n : Row} (le : stripped q x ∩ stripped q y ⊆ stripped q n)
    {s : Set Row} (prod : Product (Set.range (restricted q)) s) : x ∈ s → y ∈ s → n ∈ s := by
  induction prod with
  | atom h =>
    obtain ⟨i,rfl⟩ := h
    exact fun hx hy => le (Finset.mem_inter.mpr ⟨hx,hy⟩)
  | meet _ _ ih jh => exact fun hx hy => ⟨ih hx.1 hy.1,jh hx.2 hy.2⟩

theorem childFloor (q : I) : MinCost (Set.range (restricted q)) (childP q) N 3 := by
  classical
  intro k s net fit
  by_contra! hk
  obtain ⟨sz4,sz3,pk,hn,one,pair⟩ := tests q
  have bound : Lower (Set.range (restricted q)) (childP q) (low q) (k+1) := by
    intro C cov
    have sz := SixCycle.packedLower (K := packing q) (C := C)
      (fun x hm => cov.2 (pk hm)) (by
        intro z hz x hx zx y hy zy
        obtain ⟨hZ,hlo⟩ := cov.1 z hz
        obtain ⟨i,rfl⟩ := hZ
        exact one i hlo x hx zx y hy zy)
    omega
  obtain ⟨D,products,total,size⟩ := tightExact net fit.1 (fit.2 _ hn) bound
  have packs := SixCycle.packedLower (K := kept q) (C := D)
    (fun x hx => by rw [total]; exact fit.1 hx) (by
      intro z hz x hx zx y hy zy
      by_contra ne
      obtain ⟨n,hn,le⟩ := pair x hx y hy ne
      apply fit.2 n hn
      rw [← total]
      exact ⟨z,hz,forceProd le (products z hz) zx zy⟩)
  omega

end TightRow.Protected.Pilot
