import ProtectedSyntax
namespace TightRow.Protected
universe u v w
variable {I : Type u} {G : Type v} {R : Type w}

theorem flatten_eval {S : Type*} {k : Nat} (t : Tape S k) (e : S → Factors I G)
    (v : I → Set R) (g : G → Set R) :
    (flatten t e).eval v g = t.eval (fun i => (e i).eval v g) := by
  classical
  induction t generalizing G with
  | output i => rfl
  | andGate a b tail ih =>
    simp only [flatten,Program.eval,Tape.eval,ih]
    congr 1
    funext i
    cases i with
    | none => exact Factors.eval_meet _ _ _ _
    | some i => rfl
  | orGate a b tail ih =>
    simp only [flatten,Program.eval,Tape.eval,ih]
    congr 1
    funext i
    cases i with
    | some i => exact Factors.eval_old _ _ _ _
    | none =>
      let c := common (e a) (e b)
      have ha : c ⊆ (e a).raw := Finset.inter_subset_left
      have hb : c ⊆ (e b).raw := Finset.inter_subset_right
      change (guarded c).eval v (extendFn g (((e a).strip c).eval v g ∪
        ((e b).strip c).eval v g)) = (e a).eval v g ∪ (e b).eval v g
      rw [Factors.eval_split (e a) c ha v g,Factors.eval_split (e b) c hb v g]
      ext x
      simp [Factors.eval,guarded,extendFn,and_or_left]

theorem flatten_disjoint {S : Type*} {k : Nat} (t : Tape S k) (e : S → Factors I G) :
    DisjointArms (flatten t e) := by
  classical
  induction t generalizing G with
  | output => trivial
  | andGate a b tail ih => exact ih _
  | orGate a b tail ih =>
    refine ⟨?_,ih _⟩
    intro i ha hb
    exact (Finset.mem_sdiff.mp ha).2
      (Finset.mem_inter.mpr ⟨(Finset.mem_sdiff.mp ha).1,(Finset.mem_sdiff.mp hb).1⟩)

end TightRow.Protected
