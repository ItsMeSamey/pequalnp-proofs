import ProtectedBranch
namespace TightRow.Protected
open TightRow.Deletion
variable {I R : Type*}

/-- Regular ledger edges reuse exactly the same signed domination conditions as
the generic typed pinning theorem. The source in the restricted chart may alias
another retained source. -/
theorem deletionRule {v : I → Set R} {P N : Set R} (c : Child I R)
    {d : Nat} (child : MinCost c.bank c.pos c.neg d)
    (av : ∀ i, Avail c.bank (c.raw i)) (nonempty : c.pos.Nonempty)
    (up : ∀ r ∈ c.pos, ∃ x ∈ P, Below v x c.raw r)
    (down : ∀ r ∈ c.neg, ∃ x ∈ N, Below c.raw r v x)
    (mark : Bool) (gate : mark = true → ∃ p ∈ P, ∃ n ∈ N,
      ∀ i, Mark c.bank (c.raw i) (p ∈ v i → n ∈ v i)) :
    MinCost (Set.range v) P N (d + if mark then 1 else 0) := by
  intro k z net fit
  obtain ⟨t,eqn⟩ := (physical_iff_net.mpr net).toTape v (fun _ h => h)
  have orig : Signed P N (t.eval v) := by rwa [eqn]
  have acc : c.pos ⊆ t.eval c.raw := by
    intro r hr
    obtain ⟨p,hp,le⟩ := up r hr
    exact evaluateBelow t le (orig.1 hp)
  have rej : ∀ r ∈ c.neg, r ∉ t.eval c.raw := by
    intro r hr h
    obtain ⟨n,hn,le⟩ := down r hr
    exact orig.2 n hn (evaluateBelow t le h)
  cases mark with
  | false =>
    obtain ⟨j,hj,p⟩ := plain t c.raw c.bank av (nonempty.mono acc)
    have h := child j _ (physical_iff_net.mp p) ⟨acc,rej⟩
    simpa using h.trans hj
  | true =>
    obtain ⟨p,hp,n,hn,h⟩ := gate rfl
    obtain ⟨j,hj,g⟩ := refund t c.raw v c.bank h (nonempty.mono acc) (orig.1 hp) (orig.2 n hn)
    have h := child j _ (physical_iff_net.mp g) ⟨acc,rej⟩
    simpa using (show d+1 ≤ k by omega)

end TightRow.Protected
