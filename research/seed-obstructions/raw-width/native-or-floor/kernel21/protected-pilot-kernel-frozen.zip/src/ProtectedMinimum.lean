import ProtectedOrder
namespace TightRow.Protected
variable {R I G : Type*}
def Signed (P N out : Set R) := P ⊆ out ∧ ∀ n ∈ N, n ∉ out
def MinCost (B : Bank R) (P N : Set R) (k : Nat) :=
  ∀ m s, Net B s m → Signed P N s → k ≤ m

theorem lowerProgram {k} (p : Program I G k) {v : I → Set R} {g : G → Set R}
    {B : Bank R} (vr : ∀ i, Easy B (v i)) (gr : ∀ i, Easy B (g i))
    {P N : Set R} (pos : P.Nonempty) (neg : N.Nonempty)
    (fit : Signed P N (p.eval v g)) {d} (min : MinCost B P N d) : d ≤ k := by
  obtain ⟨n,hn⟩ := neg
  obtain ⟨j,sz,q⟩ := build p B vr gr (fun _ => False) (fun _ h => h.elim)
    (pos.mono fit.1) ⟨n,fit.2 n hn⟩
  have le := min j _ q fit
  omega

theorem changeJoin {k} (tail : Program I (Option G) k) {v : I → Set R} {g : G → Set R}
    {orig alt P N : Set R} (pos : ∀ x ∈ P, x ∈ orig → x ∈ alt)
    (neg : ∀ x ∈ N, x ∈ alt → x ∈ orig) (fit : Signed P N (tail.eval v (extendFn g orig))) :
    Signed P N (tail.eval v (extendFn g alt)) := by
  constructor
  · intro x hx
    apply programBelow tail (fun _ h => h) _ (fit.1 hx)
    intro j hi
    cases j with
    | none => exact pos x hx hi
    | some _ => exact hi
  · intro x hx high
    apply fit.2 x hx
    apply programBelow tail (fun _ h => h) _ high
    intro j hi
    cases j with
    | none => exact neg x hx hi
    | some _ => exact hi

theorem minJoin {k} (a b : Factors I G) (tail : Program I (Option G) k)
    {v : I → Set R} {g : G → Set R} {B : Bank R}
    (vr : ∀ i, Easy B (v i)) (gr : ∀ i, Easy B (g i))
    {P N : Set R} (pos : P.Nonempty) (neg : N.Nonempty)
    (fit : Signed P N ((Program.join a b tail).eval v g)) (min : MinCost B P N (k+1)) :
    (∃ x ∈ P, x ∈ a.eval v g ∧ x ∉ b.eval v g) ∧
    (∃ x ∈ P, x ∈ b.eval v g ∧ x ∉ a.eval v g) ∧
    MinCost (insert (a.eval v g ∪ b.eval v g) B) P N k := by
  classical
  let s := a.eval v g ∪ b.eval v g
  have impossible (alt : Set R) (easy : Easy B alt)
      (keep : ∀ x ∈ P, x ∈ s → x ∈ alt) (shrink : alt ⊆ s) : False := by
    have gg : ∀ i, Easy B (extendFn g alt i) := by
      intro i
      cases i with
      | none => exact easy
      | some i => exact gr i
    have altFit := changeJoin tail keep (fun _ _ hx => shrink hx) fit
    have bad := lowerProgram tail vr gg pos neg altFit min
    omega
  have ex (u w : Set R) (eqn : s = u ∪ w) (ew : Easy B w) :
      ∃ x ∈ P, x ∈ u ∧ x ∉ w := by
    by_contra! bad
    apply impossible w ew
    · intro x xp xs
      rw [eqn] at xs
      exact xs.elim (bad x xp) id
    · intro _ h
      rw [eqn]
      exact Or.inr h
  have ep := a.easy vr gr
  have eq := b.easy vr gr
  refine ⟨ex _ _ rfl eq,ex _ _ (Set.union_comm _ _) ep,?_⟩
  have need : ¬ Easy B s := fun h => impossible s h (fun _ _ u => u) (fun _ u => u)
  have pair : Product B (a.eval v g) ∧ Product B (b.eval v g) := by
    rcases ep with ha | ha | pa
    · exact (need (by simpa [s,ha] using eq)).elim
    · exact (need (Or.inr (Or.inl (by simp [s,ha])))).elim
    rcases eq with hb | hb | pb
    · exact (need (by simpa [s,hb,Easy] using (Or.inr (Or.inr pa) : Easy B (a.eval v g)))).elim
    · exact (need (Or.inr (Or.inl (by simp [s,hb])))).elim
    exact ⟨pa,pb⟩
  intro m z net hz
  have le := min (m+1) z (.step pair.1 pair.2 net) hz
  omega

end TightRow.Protected
