import ProtectedSelect
import ProtectedProgram
import Mathlib.Data.Nat.Find
namespace TightRow.Protected
open TightRow.Deletion
variable {I R : Type*}

def initial (i : I) : Factors I Empty := ⟨{i},∅⟩
def emptyG : Empty → Set R := Empty.elim

theorem initialEval (v : I → Set R) (i : I) : (initial i).eval v emptyG = v i := by
  ext x
  simp [initial,Factors.eval]

noncomputable def normal {k} (t : Tape I k) := flatten t initial

theorem normalEval {k} (t : Tape I k) (v : I → Set R) :
    (normal t).eval v emptyG = t.eval v := by
  rw [normal,flatten_eval]
  simp [initialEval]

/-- The reinterpreted raw columns of a child are kept distinct from its physical
bank. A recomputed compound may become zero or an exact alias. -/
structure Child (I R : Type*) where
  raw : I → Set R
  bank : Bank R
  pos : Set R
  neg : Set R

def ChildOK (v : I → Set R) (P N : Set R) (q : I) (floor : Nat) (c : Child I R) :=
  c.raw q = ∅ ∧ (∀ i, Easy c.bank (c.raw i)) ∧ c.pos.Nonempty ∧ c.neg.Nonempty ∧
  (∀ x ∈ c.pos, ∃ y ∈ P, Below v y c.raw x) ∧
  (∀ x ∈ c.neg, ∃ y ∈ N, Below c.raw x v y) ∧ MinCost c.bank c.pos c.neg floor

theorem childTouch {k} (p : Program I Empty k) (v : I → Set R) {P N : Set R}
    (fit : Signed P N (p.eval v emptyG)) (q : I) {floor : Nat}
    (c : Child I R) (ok : ChildOK v P N q floor c) :
    floor + touches (oneLit q) p ≤ k := by
  obtain ⟨off,avail,cp,cn,up,down,low⟩ := ok
  have acc : c.pos ⊆ p.eval c.raw emptyG := by
    intro x hx
    obtain ⟨y,hy,le⟩ := up x hx
    exact programBelow p le (fun i => i.elim) (fit.1 hy)
  have rej : ∀ x ∈ c.neg, x ∉ p.eval c.raw emptyG := by
    intro x hx high
    obtain ⟨y,hy,le⟩ := down x hx
    exact fit.2 _ hy (programBelow p le (fun i => i.elim) high)
  obtain ⟨z,hz⟩ := cn
  obtain ⟨j,sz,g⟩ := build p c.bank avail (fun i => i.elim) (oneLit q)
    (fun i eqn => by change i = q at eqn; rwa [eqn]) (cp.mono acc) ⟨z,rej z hz⟩
  have le := low j _ g ⟨acc,rej⟩
  omega

/-- A sound branch rule from actual typed gates, deletions and observable rows.
The numerical checker only has to exclude PairPossible. -/
theorem protectedBranch [DecidableEq I] (v : I → Set R) (P N : Set R) (T : Finset I)
    (L : Nat) (dom : ∃ x ∈ P, ∃ n ∈ N, Outside v T x n)
    (nonfinal : ∀ q ∈ T, ∃ x ∈ P, x ∉ v q)
    (children : ∀ q ∈ T, ∃ c : Child I R, ChildOK v P N q (L-2) c)
    (exclude : ¬ PairPossible v T P N) : MinCost (Set.range v) P N L := by
  classical
  intro k s net fit
  by_contra! small
  let existsNet := fun m => ∃ z, Net (Set.range v) z m ∧ Signed P N z
  have existsK : ∃ m, existsNet m := ⟨k,s,net,fit⟩
  let m := Nat.find existsK
  have bound : m ≤ k := Nat.find_min' existsK (show existsNet k from ⟨s,net,fit⟩)
  have min : MinCost (Set.range v) P N m := fun j z p ok =>
    Nat.find_min' existsK (show existsNet j from ⟨z,p,ok⟩)
  obtain ⟨z,p,ok⟩ := Nat.find_spec existsK
  obtain ⟨t,eqn⟩ := (physical_iff_net.mpr p).toTape v (fun _ h => h)
  have original : Signed P N ((normal t).eval v emptyG) := by rwa [normalEval,eqn]
  apply exclude
  apply selectFirst (normal t) v emptyG T (Set.range v) P N
    (fun i => Or.inr (Or.inr (.atom ⟨i,rfl⟩))) (fun i => i.elim) (fun i => i.elim)
    dom original min
  · intro q hq
    obtain ⟨c,hc⟩ := children q hq
    have sz := childTouch (normal t) v original q c hc
    change L-2 + touches (oneLit q) (normal t) ≤ m at sz
    omega
  · intro q hq read
    obtain ⟨x,hx,off⟩ := nonfinal q hq
    exact off (final_lit (normal t) v emptyG read (original.1 hx))
  · exact flatten_disjoint t initial

end TightRow.Protected
