import ProtectedBranch
import ProtectedPilotChildren
namespace TightRow.Protected.Pilot

theorem exclude : ¬ PairPossible v Finset.univ P N := by
  rintro ⟨l,h,_,_,disj,someHit,x,y,_,hx,hy,cover⟩
  have lx := hx.1.2.1
  have hy' := hy.1.2.1
  obtain ⟨p,pp,n,nn,ext,bad⟩ := obstruction (coveredPart hx.1.1 lx)
    (coveredPart hy.1.1 hy') disj someHit
  have outside : Outside v (l ∪ h) p n := by
    intro i off hp
    exact (Finset.mem_union.mp (ext hp)).resolve_left off
  have req : p ∈ Required P N (Outside v (l ∪ h)) := ⟨pp,n,nn,outside⟩
  have den : n ∈ Denied P N (Outside v (l ∪ h)) := ⟨nn,p,pp,outside⟩
  have allFree (a b : Row) : Outside v Finset.univ a b :=
    fun i off => (off (Finset.mem_univ i)).elim
  rcases bad with miss | ln | hn
  · rcases cover req with u | w
    · exact miss (Or.inl u.1.2.1)
    · exact miss (Or.inr w.1.2.1)
  · exact hx.1.2.2 n den ln (allFree x n)
  · exact hy.1.2.2 n den hn (allFree y n)

def child (q : I) : Child I Row :=
  ⟨restricted q,Set.range (restricted q),childP q,N⟩

private theorem childOK (q : I) : ChildOK v P N q 3 (child q) := by
  have pos : (kept q).Nonempty := by
    have all : ∀ i : I, (kept i).Nonempty := by decide
    exact all q
  refine ⟨?_,fun i => Or.inr (Or.inr (.atom ⟨i,rfl⟩)),pos,⟨6,show (6 : Row) ∈ negatives by decide⟩,?_,?_,childFloor q⟩
  · ext x
    simp [child,restricted,stripped]
  · intro x hx
    change x ∈ kept q at hx
    obtain ⟨xp,off⟩ := Finset.mem_filter.mp hx
    refine ⟨x,List.mem_toFinset.mp xp,?_⟩
    intro i hi
    apply Finset.mem_erase.mpr
    refine ⟨fun h => off (h ▸ hi),hi⟩
  · exact fun n hn => ⟨n,hn,fun _ hi => Finset.mem_of_mem_erase hi⟩

/-- Exact numerical branch pilot from protected node 58240 of the published ledger. -/
theorem pilotBranchFive : MinCost (Set.range v) P N 5 := by
  apply protectedBranch v P N Finset.univ 5
  · exact ⟨0,show (0 : Row) ∈ positives by decide,6,show (6 : Row) ∈ negatives by decide,fun i h => (h (Finset.mem_univ i)).elim⟩
  · intro q _
    have check : ∀ i : I, ∃ x ∈ positives, i ∉ active x := by decide
    exact check q
  · exact fun q _ => ⟨child q,childOK q⟩
  · exact exclude

end TightRow.Protected.Pilot
