import DeletionRefund

namespace TightRow.Protected
variable {R : Type*}

def Up (le : R → R → Prop) (g : Set R) := ∀ x y, le x y → x ∈ g → y ∈ g

/-- Explicit protected factors and a monotone function of all free observations. -/
def IsArm (le : R → R → Prop) (rawHits arm : Set R) :=
  ∃ g : Set R, Up le g ∧ arm = rawHits ∩ g

def Required (P N : Set R) (ext : R → R → Prop) := {x | x ∈ P ∧ ∃ n ∈ N, ext x n}
def Denied (P N : Set R) (ext : R → R → Prop) := {n | n ∈ N ∧ ∃ x ∈ P, ext x n}

def Allowed (P N : Set R) (ext free : R → R → Prop) (rawHits : Set R) :=
  {x | x ∈ P ∧ x ∈ rawHits ∧ ∀ n ∈ Denied P N ext, n ∈ rawHits → ¬free x n}
def Trim (grant rawHits : Set R) (free : R → R → Prop) (opposite : R) : Set R :=
  {x | x ∈ grant ∧ ¬(opposite ∈ rawHits ∧ free x opposite)}

def Feasible (P N : Set R) (ext free : R → R → Prop) (L H : Set R) : Prop :=
  ∃ x y, x ≠ y ∧
    let A := Trim (Allowed P N ext free L) L free y
    let B := Trim (Allowed P N ext free H) H free x
    x ∈ A ∧ y ∈ B ∧ Required P N ext ⊆ A ∪ B

private theorem armAllowed {P N raw a : Set R} {ext free : R → R → Prop}
    (arm : IsArm free raw a) (low : ∀ n ∈ Denied P N ext, n ∉ a)
    {x : R} (px : x ∈ P) (ax : x ∈ a) : x ∈ Allowed P N ext free raw := by
  obtain ⟨g,up,rfl⟩ := arm
  exact ⟨px,ax.1,fun n hn rn le => low n hn ⟨rn,up x n le ax.2⟩⟩

private theorem armTrim {P N raw a : Set R} {ext free : R → R → Prop}
    (arm : IsArm free raw a) (low : ∀ n ∈ Denied P N ext, n ∉ a)
    {x y : R} (px : x ∈ P) (ax : x ∈ a) (ay : y ∉ a) :
    x ∈ Trim (Allowed P N ext free raw) raw free y := by
  refine ⟨armAllowed arm low px ax,?_⟩
  obtain ⟨g,up,rfl⟩ := arm
  exact fun h => ay ⟨h.1,up x y h.2 ax.2⟩

theorem firstTest {P N L H a b out : Set R} {ext free : R → R → Prop}
    (la : IsArm free L a) (rb : IsArm free H b) (acc : P ⊆ out)
    (rej : ∀ n ∈ N, n ∉ out)
    (outMono : ∀ i n, ext i n → (i ∈ a ∪ b → n ∈ a ∪ b) → i ∈ out → n ∈ out)
    (exL : ∃ x ∈ P, x ∈ a ∧ x ∉ b) (exR : ∃ y ∈ P, y ∈ b ∧ y ∉ a) :
    Feasible P N ext free L H := by
  classical
  have force (i n : R) (pi : i ∈ P) (nn : n ∈ N) (le : ext i n) :
      i ∈ a ∪ b ∧ n ∉ a ∪ b := by
    constructor
    · by_contra h
      exact rej n nn (outMono i n le (fun u => (h u).elim) (acc pi))
    · intro hn
      exact rej n nn (outMono i n le (fun _ => hn) (acc pi))
  have off (n : R) (hn : n ∈ Denied P N ext) : n ∉ a ∪ b := by
    obtain ⟨nn,i,pi,le⟩ := hn
    exact (force i n pi nn le).2
  have lowL (n : R) (hn : n ∈ Denied P N ext) : n ∉ a :=
    fun h => off n hn (Or.inl h)
  have lowR (n : R) (hn : n ∈ Denied P N ext) : n ∉ b :=
    fun h => off n hn (Or.inr h)
  obtain ⟨x,px,ax,bx⟩ := exL
  obtain ⟨y,py,by',ay⟩ := exR
  refine ⟨x,y,fun h => ay (h ▸ ax),armTrim la lowL px ax ay,armTrim rb lowR py by' bx,?_⟩
  rintro i ⟨pi,n,nn,le⟩
  rcases (force i n pi nn le).1 with ia | ib
  · exact Or.inl (armTrim la lowL pi ia ay)
  · exact Or.inr (armTrim rb lowR pi ib bx)

end TightRow.Protected
