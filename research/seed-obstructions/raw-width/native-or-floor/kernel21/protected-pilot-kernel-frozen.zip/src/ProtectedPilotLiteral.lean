import ProtectedPilot
import NativeDeletionOriginal

namespace TightRow.Protected.Pilot
open TightRow.Deletion TightRow.NativeSeeds

def orig (x : Row) : Fin 676 := ([19,7,20,8,32,21,59,81,78,57,64] : List (Fin 676)).getD x.val 0
def addrMap (j : Fin 22) : Option I := match j.val with
  | 7 | 20 => some 0
  | 8 => some 1
  | 9 => some 2
  | 13 => some 3
  | 14 => some 4
  | 15 => some 5
  | _ => none

def parentBit (i : Nat) (x : Fin 676) := (columnWords.getD i 0).testBit x.val
def present (j : Nat) := (58240 : Nat).testBit j
def stageBit (j : Fin 22) (x : Fin 676) : Bool :=
  if j.val < 20 then present j.val && parentBit j.val x
  else if j.val = 20 then (present 0 && parentBit 0 x) || (present 7 && parentBit 7 x)
  else (present 6 && parentBit 6 x) || (present 12 && parentBit 12 x)
def physicalColumn (j : Fin 22) : Set (Fin 676) := {x | stageBit j x = true}
def stageP : Set (Fin 676) := {x | x ∈ TightRow.NativeSeeds.positives ∧
  ∀ i : Fin 20, parentBit i.val x = true → present i.val = true}

private theorem mapped : ∀ x : Row, ∀ j : Fin 22,
    stageBit j (orig x) = (addrMap j).elim false (fun i => decide (i ∈ active x)) := by decide
private theorem signs : (∀ x ∈ positives, target.testBit (orig x).val = true ∧
    front.testBit (orig x).val = false ∧
    ∀ i : Fin 20, parentBit i.val (orig x) = true → present i.val = true) ∧
    ∀ x ∈ negatives, target.testBit (orig x).val = false := by decide

/-- The pilot uses the physical pair value restricted to 58240, which is exactly
literal 7 for the first pair. The second pair becomes the false signal. -/
theorem physicalNode58240 {k} (t : Tape (Fin 22) k)
    (fit : Fits t physicalColumn stageP TightRow.NativeSeeds.negatives) : 5 ≤ k := by
  let f : Fin 22 → Set Row := fun j => {x | stageBit j (orig x) = true}
  have av (j : Fin 22) : Avail (Set.range v) (f j) := by
    cases eqn : addrMap j with
    | none =>
      left
      ext x
      change stageBit j (orig x) = true ↔ False
      simp [mapped,eqn]
    | some i =>
      right
      refine ⟨i,?_⟩
      ext x
      change i ∈ active x ↔ stageBit j (orig x) = true
      simp [mapped,eqn]
  have ok : Signed P N (t.eval f) := by
    constructor
    · intro x hx
      obtain ⟨tar,fr,keep⟩ := signs.1 x hx
      exact evaluateBelow t (x := orig x) (fun _ h => h) (fit.1 ⟨⟨tar,fr⟩,keep⟩)
    · intro x hx high
      exact fit.2 (orig x) (signs.2 x hx) (evaluateBelow t (x := x) (fun _ h => h) high)
  obtain ⟨j,size,p⟩ := plain t f _ av ⟨0,ok.1 (show (0 : Row) ∈ positives by decide)⟩
  exact (pilotBranchFive j _ (physical_iff_net.mp p) ok).trans size

theorem allBanksNode58240 (pair129 pair4160 : Bool) {k}
    (t : Tape (TightRow.NativeDeletion.Input pair129 pair4160) k)
    (fit : Fits t (fun i => physicalColumn i.val) stageP TightRow.NativeSeeds.negatives) : 5 ≤ k := by
  have phys := t.toPhysical (A := Set.range physicalColumn) (fun i => physicalColumn i.val)
    (fun i => ⟨i.val,rfl⟩)
  obtain ⟨w,eqn⟩ := phys.toTape physicalColumn (fun _ h => h)
  apply physicalNode58240 w
  simpa only [Fits,eqn] using fit

end TightRow.Protected.Pilot
