import ProtectedMinimum
namespace TightRow.Protected
variable {I G R : Type*}

def PairPossible [DecidableEq I] (v : I → Set R) (T : Finset I) (P N : Set R) : Prop :=
  ∃ l h : Finset I, l ⊆ T ∧ h ⊆ T ∧ (∀ i ∈ l, i ∉ h) ∧ (∃ i, i ∈ l ∨ i ∈ h) ∧
    Feasible P N (Outside v (l ∪ h)) (Outside v T) (hitsRaw v l) (hitsRaw v h)

theorem selectFirst [DecidableEq I] {k} (p : Program I G k) (v : I → Set R) (g : G → Set R)
    (T : Finset I) (B : Bank R) (P N : Set R)
    (raw : ∀ i, Easy B (v i)) (gates : ∀ i, Easy B (g i))
    (hist : ∀ i, Up (Outside v T) (g i))
    (dom : ∃ x ∈ P, ∃ n ∈ N, Outside v T x n)
    (fit : Signed P N (p.eval v g)) (min : MinCost B P N k)
    (once : ∀ i ∈ T, touches (oneLit i) p ≤ 1)
    (last : ∀ i ∈ T, i ∉ finalRaw p) (split : DisjointArms p) :
    PairPossible v T P N := by
  classical
  obtain ⟨x,hp,n,hn,hnx⟩ := dom
  induction p generalizing B with
  | output f =>
    exact (fit.2 n hn (f.below (fun i hi => hnx i (fun h => last i h hi))
       (fun i => hist i x n hnx) (fit.1 hp))).elim
  | @join G k a b tail ih =>
    obtain ⟨lex,rex,tailmin⟩ := minJoin a b tail raw gates ⟨x,hp⟩ ⟨n,hn⟩ fit min
    let l := a.raw ∩ T
    let h := b.raw ∩ T
    let H := l ∪ h
    let s := a.eval v g ∪ b.eval v g
    have lT : l ⊆ T := Finset.inter_subset_right
    have hT : h ⊆ T := Finset.inter_subset_right
    have HT : H ⊆ T := Finset.union_subset lT hT
    have inside (i : I) (hi : i ∈ H) : Hit (oneLit i) a b := by
      rcases Finset.mem_union.mp hi with ha | hb
      · exact ⟨i,Or.inl (Finset.mem_inter.mp ha).1,rfl⟩
      · exact ⟨i,Or.inr (Finset.mem_inter.mp hb).1,rfl⟩
    have tailOnce (i : I) (hi : i ∈ T) : touches (oneLit i) tail ≤ 1 := by
      have le := once i hi
      simp only [touches] at le
      split at le <;> omega
    by_cases someHit : ∃ i, i ∈ l ∨ i ∈ h
    · have tailOff (i : I) (hi : i ∈ H) : touches (oneLit i) tail = 0 := by
        have le := once i (HT hi)
        simp only [touches,if_pos (inside i hi)] at le
        omega
      refine ⟨l,h,lT,hT,fun i hl hh => split.1 i (Finset.mem_inter.mp hl).1
        (Finset.mem_inter.mp hh).1,someHit,?_⟩
      apply firstTest (a.asArm T v g hist) (b.asArm T v g hist) fit.1 fit.2 _ lex rex
      intro u w le sg
      apply avoidMono tail v (extendFn g s) tailOff (fun i hi => last i (HT hi)) le
      intro j
      cases j with
      | none => exact sg
      | some j =>
        exact hist j u w (fun i notT => le i (fun hi => notT (HT hi)))
    · have ordered (f : Factors I G) (no : ∀ i ∈ f.raw, i ∉ T) :
          Up (Outside v T) (f.eval v g) := by
        intro u w le
        exact f.below (fun i hi => le i (no i hi)) (fun j => hist j u w le)
      have aup := ordered a (fun i hi hiT => someHit ⟨i,Or.inl (Finset.mem_inter.mpr ⟨hi,hiT⟩)⟩)
      have bup := ordered b (fun i hi hiT => someHit ⟨i,Or.inr (Finset.mem_inter.mpr ⟨hi,hiT⟩)⟩)
      have ready (i : Option G) : Easy (insert s B) (extendFn g s i) := by
        cases i with
        | none => exact Or.inr (Or.inr (.atom (Set.mem_insert _ _)))
        | some i => exact (gates i).grow s
      have up (i : Option G) : Up (Outside v T) (extendFn g s i) := by
        cases i with
        | none =>
          intro u w le h
          exact h.elim (fun a => Or.inl (aup _ _ le a)) (fun b => Or.inr (bup _ _ le b))
        | some i => exact hist i
      exact ih (extendFn g s) (insert s B) (fun i => (raw i).grow s) ready up fit tailmin
        tailOnce last split.2

end TightRow.Protected
