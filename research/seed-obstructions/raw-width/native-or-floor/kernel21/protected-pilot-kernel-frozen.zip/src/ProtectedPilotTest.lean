import ProtectedArm
import SixCycleTerminal
import Mathlib.Data.Finset.Powerset

namespace TightRow.Protected.Pilot
abbrev I := Fin 6
abbrev Row := Fin 11

/-- The support 58240 has surviving physical positions 7,8,9,13,14,15.
The first six rows are its positive incidences, followed by its five maximal
negatives. The surviving half of physical pair 129 aliases position 7. -/
def rows : List (Finset I) :=
  [{0,3},{0,4},{1,4},{1,5},{2,3},{2,5},{0,1,2},{1,3},{2,4},{0,5},{3,4,5}]
def active (x : Row) : Finset I := rows.getD x.val ∅
def positives : List Row := [0,1,2,3,4,5]
def negatives : List Row := [6,7,8,9,10]
def P : Set Row := {r | r ∈ positives}
def N : Set Row := {r | r ∈ negatives}
def v (i : I) : Set Row := {r | i ∈ active r}

def parts : List (Finset I) :=
  [∅,{0},{1},{2},{3},{4},{5},{0,3},{0,4},{1,4},{1,5},{2,3},{2,5}]
def bad (l h : Finset I) (x n : Row) : Prop :=
  active x ⊆ (l ∪ h) ∪ active n ∧
  (¬ (l ⊆ active x ∨ h ⊆ active x) ∨ l ⊆ active n ∨ h ⊆ active n)
instance (l h : Finset I) (x n : Row) : Decidable (bad l h x n) := by unfold bad; infer_instance

def entry (l h : Finset I) : Bool :=
  !decide (Disjoint l h) || (l ∪ h == ∅) ||
    positives.any (fun x => negatives.any (fun n => decide (bad l h x n)))

private theorem valid : parts.all (fun l => parts.all (entry l)) = true := by decide

theorem obstruction {l h : Finset I} (hl : l ∈ parts) (hh : h ∈ parts)
    (disj : ∀ i ∈ l, i ∉ h) (someLit : ∃ i, i ∈ l ∨ i ∈ h) :
    ∃ x ∈ P, ∃ n ∈ N, bad l h x n := by
  have dj := Finset.disjoint_left.mpr disj
  have nz : l ∪ h ≠ ∅ := by
    obtain ⟨i,hi⟩ := someLit
    exact Finset.nonempty_iff_ne_empty.mp ⟨i,Finset.mem_union.mpr hi⟩
  have step : positives.any (fun x => negatives.any (fun n => decide (bad l h x n))) = true := by
    simpa [entry,dj,nz] using (List.all_eq_true.mp (List.all_eq_true.mp valid l hl) h hh)
  obtain ⟨x,hx,hs⟩ := List.any_eq_true.mp step
  obtain ⟨n,hn,nb⟩ := List.any_eq_true.mp hs
  exact ⟨x,hx,n,hn,of_decide_eq_true nb⟩

theorem coveredPart {l : Finset I} {x : Row} (xp : x ∈ P)
    (xs : ∀ i ∈ l, x ∈ v i) : l ∈ parts := by
  have complete : ∀ r ∈ positives, ∀ t ∈ (active r).powerset, t ∈ parts := by decide
  exact complete x xp l (Finset.mem_powerset.mpr xs)

end TightRow.Protected.Pilot
