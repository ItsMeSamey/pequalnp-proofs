import ProtectedNumericBranch
import ShortPilot58240

namespace TightRow.Protected.Numeric.PilotGraph
open TightRow.Protected
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def c0 : Chart := ⟨[16512],[128, 16384]⟩
theorem floor0 : Floor c0 0 := fun _ _ _ _ => Nat.zero_le _
def c1 : Chart := ⟨[8320, 16512],[128, 24576]⟩
def m1_0 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, none, some 14, none, none, none, none, none, none, none]
private theorem e1_0 : Edge c1 c0 m1_0 := by constructor <;> decide
theorem floor1 : Floor c1 1 := by
  have up := refundEdge e1_0 floor0 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c4 : Chart := ⟨[8320, 8704, 16512],[640, 8192, 16896, 24576]⟩
def m4_1 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, none, none, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e4_1 : Edge c4 c1 m4_1 := by constructor <;> decide
theorem floor4 : Floor c4 2 := by
  have up := refundEdge e4_1 floor1 8704 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c5 : Chart := ⟨[8320, 8704, 16512, 16640],[896, 8448, 16896, 24576]⟩
def m5_4 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e5_4 : Edge c5 c4 m5_4 := by constructor <;> decide
theorem floor5 : Floor c5 3 := by
  have up := refundEdge e5_4 floor4 16640 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c9 : Chart := ⟨[33024],[256, 32768]⟩
theorem floor9 : Floor c9 0 := fun _ _ _ _ => Nat.zero_le _
def c10 : Chart := ⟨[33280],[512, 32768]⟩
theorem floor10 : Floor c10 0 := fun _ _ _ _ => Nat.zero_le _
def c11 : Chart := ⟨[8704, 33280],[512, 40960]⟩
def m11_10 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, none, none, some 15, none, none, none, none, none, none]
private theorem e11_10 : Edge c11 c10 m11_10 := by constructor <;> decide
theorem floor11 : Floor c11 1 := by
  have up := refundEdge e11_10 floor10 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)

def c12 : Chart := ⟨[8320, 8704, 33280],[640, 8192, 32896, 40960]⟩
def m12_11 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e12_11 : Edge c12 c11 m12_11 := by constructor <;> decide
theorem floor12 : Floor c12 2 := by
  have up := refundEdge e12_11 floor11 8320 8192 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c13 : Chart := ⟨[8704, 33024, 33280],[768, 8448, 32768, 40960]⟩
def m13_11 : List (Option Addr) := [none, none, none, none, none, none, none, none, none, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e13_11 : Edge c13 c11 m13_11 := by constructor <;> decide
theorem floor13 : Floor c13 2 := by
  have up := refundEdge e13_11 floor11 33024 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c15 : Chart := ⟨[8320, 8704, 33024, 33280],[896, 8448, 32896, 40960]⟩
def m15_13 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e15_13 : Edge c15 c13 m15_13 := by constructor <;> decide
theorem floor15 : Floor c15 3 := by
  have up := refundEdge e15_13 floor13 8320 8448 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c19 : Chart := ⟨[16640, 33024],[256, 49152]⟩
def m19_9 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, none, none, none, none, some 15, none, none, none, none, none, none]
private theorem e19_9 : Edge c19 c9 m19_9 := by constructor <;> decide
theorem floor19 : Floor c19 1 := by
  have up := refundEdge e19_9 floor9 16640 256 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 1 ≤ 1).trans (up k x net fit)
def c20 : Chart := ⟨[16512, 16640, 33024],[384, 16384, 32896, 49152]⟩
def m20_19 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e20_19 : Edge c20 c19 m20_19 := by constructor <;> decide
theorem floor20 : Floor c20 2 := by
  have up := refundEdge e20_19 floor19 16512 16384 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c21 : Chart := ⟨[16640, 33024, 33280],[768, 16896, 32768, 49152]⟩
def m21_19 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, none, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e21_19 : Edge c21 c19 m21_19 := by constructor <;> decide
theorem floor21 : Floor c21 2 := by
  have up := refundEdge e21_19 floor19 33280 32768 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 2 ≤ 2).trans (up k x net fit)
def c22 : Chart := ⟨[16512, 16640, 33024, 33280],[896, 16896, 32896, 49152]⟩
def m22_21 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e22_21 : Edge c22 c21 m22_21 := by constructor <;> decide
theorem floor22 : Floor c22 3 := by
  have up := refundEdge e22_21 floor21 16512 16896 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c28 : Chart := ⟨[8320, 16512, 16640, 33024],[128, 384, 8448, 32896, 57344]⟩
def m28_20 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e28_20 : Edge c28 c20 m28_20 := by constructor <;> decide
theorem floor28 : Floor c28 3 := by
  have up := refundEdge e28_20 floor20 8320 128 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c29 : Chart := ⟨[8320, 8704, 16512, 33280],[640, 16896, 32896, 57344]⟩
def m29_12 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e29_12 : Edge c29 c12 m29_12 := by constructor <;> decide
theorem floor29 : Floor c29 3 := by
  have up := refundEdge e29_12 floor12 16512 640 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c30 : Chart := ⟨[8704, 16640, 33024, 33280],[512, 768, 8448, 16896, 57344]⟩
def m30_21 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e30_21 : Edge c30 c21 m30_21 := by constructor <;> decide
theorem floor30 : Floor c30 3 := by
  have up := refundEdge e30_21 floor21 8704 512 (by decide) (by decide) (by decide)
  exact fun k x net fit => (by decide : 3 ≤ 3).trans (up k x net fit)
def c31 : Chart := ⟨[8320, 8704, 16512, 16640, 33024, 33280],[896, 8448, 16896, 32896, 57344]⟩
def m31_30 : List (Option Addr) := [none, none, none, none, none, none, none, none, some 8, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e31_30 : Edge c31 c30 m31_30 := by constructor <;> decide
def m31_29 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, none, some 9, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e31_29 : Edge c31 c29 m31_29 := by constructor <;> decide
def m31_28 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, none, none, none, none, some 13, some 14, some 15, none, none, none, none, none, none]
private theorem e31_28 : Edge c31 c28 m31_28 := by constructor <;> decide
def m31_22 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, none, some 14, some 15, none, none, none, none, none, none]
private theorem e31_22 : Edge c31 c22 m31_22 := by constructor <;> decide
def m31_15 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, none, some 15, none, none, none, none, none, none]
private theorem e31_15 : Edge c31 c15 m31_15 := by constructor <;> decide
def m31_5 : List (Option Addr) := [none, none, none, none, none, none, none, some 7, some 8, some 9, none, none, none, some 13, some 14, none, none, none, none, none, none, none]
private theorem e31_5 : Edge c31 c5 m31_5 := by constructor <;> decide
theorem floor31 : Floor c31 5 := by
  apply protectedBranch source c31.P c31.N (decode 58240) 5
  · unfold Chart.P Chart.N Outside source
    decide
  · unfold Chart.P source
    decide
  · intro q hq
    have casesQ : ∀ q ∈ decode 58240, q = 7 ∨ q = 8 ∨ q = 9 ∨ q = 13 ∨ q = 14 ∨ q = 15 := by decide
    rcases casesQ q hq with rfl | rfl | rfl | rfl | rfl | rfl
    · refine ⟨_,goodChild e31_30 7 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor30 k x net fit)
    · refine ⟨_,goodChild e31_29 8 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor29 k x net fit)
    · refine ⟨_,goodChild e31_28 9 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor28 k x net fit)
    · refine ⟨_,goodChild e31_22 13 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor22 k x net fit)
    · refine ⟨_,goodChild e31_15 14 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor15 k x net fit)
    · refine ⟨_,goodChild e31_5 15 (by decide) ?_⟩
      exact fun k x net fit => (by decide : 5-2 ≤ 3).trans (floor5 k x net fit)
  · exact pairExcluded 58240 58240 [8320, 8704, 16512, 16640, 33024, 33280] [896, 8448, 16896, 32896, 57344] validBranch58240 (by decide) (by decide) (by decide)

end TightRow.Protected.Numeric.PilotGraph
