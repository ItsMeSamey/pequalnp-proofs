import ProtectedNumericReflection
import ProtectedNumericEdges
import Mathlib.Data.Finset.Powerset

namespace TightRow.Protected.Numeric
open TightRow.Protected

def decode (n : Nat) : Finset Addr := Finset.univ.filter (fun i => n.testBit i.val = true)
theorem memDecode (n : Nat) (i : Addr) : i ∈ decode n ↔ n.testBit i.val = true := by
  simp [decode]

theorem subsetBits (a b : Nat) :
    subset a b = true ↔ ∀ i, a.testBit i = true → b.testBit i = true := by
  simp only [subset,beq_iff_eq]
  constructor
  · intro eq i hi
    have h := congrArg (fun x : Nat => x.testBit i) eq
    simpa [Nat.testBit_and,hi] using h
  · intro all
    apply Nat.eq_of_testBit_eq
    intro i
    cases h : a.testBit i <;> simp [Nat.testBit_and,h,all]

private theorem highOff {x i : Nat} (hx : x < 2^22) (hi : ¬ i < 22) :
    x.testBit i = false :=
  Nat.testBit_lt_two_pow (hx.trans_le (Nat.pow_le_pow_right (by decide) (by omega)))

theorem hitBits {l : Nat} (hl : l < 2^22) (x : Nat) :
    x ∈ hitsRaw source (decode l) ↔ x ∈ maskHits l := by
  change (∀ i ∈ decode l, x.testBit i.val = true) ↔ subset l x = true
  rw [subsetBits]
  constructor
  · intro h i hi
    by_cases small : i < 22
    · exact h ⟨i,small⟩ ((memDecode ..).mpr hi)
    · simp [highOff hl small] at hi
  · exact fun h i hi => h i.val ((memDecode ..).mp hi)

theorem outsideBits {x : Nat} (hx : x < 2^22) (t y : Nat) :
    Outside source (decode t) x y ↔ maskOrder t x y := by
  change _ ↔ subset x (t ||| y) = true
  rw [subsetBits]
  constructor
  · intro h i hi
    by_cases small : i < 22
    · by_cases ht : t.testBit i = true
      · simp [Nat.testBit_or,ht]
      · have out := h ⟨i,small⟩ (fun z => ht ((memDecode ..).mp z)) hi
        simp [Nat.testBit_or,show y.testBit i = true from out]
    · simp [highOff hx small] at hi
  · intro h i off on'
    have h' := h i.val on'
    have ht : t.testBit i.val = false := by simpa [memDecode] using off
    change y.testBit i.val = true
    simpa [Nat.testBit_or,ht] using h'

theorem decodeUnion (a b : Nat) : decode (a ||| b) = decode a ∪ decode b := by
  ext i
  simp [memDecode,Nat.testBit_or]

theorem moveFeasible {P N L H : Set Nat} {ext free ext' free' : Nat → Nat → Prop}
    (ex : ∀ x ∈ P, ∀ n ∈ N, ext x n ↔ ext' x n)
    (fr : ∀ x ∈ P, ∀ n, free x n ↔ free' x n)
    (old : Feasible P N ext free L H) : Feasible P N ext' free' L H := by
  have de : Denied P N ext = Denied P N ext' := by
    ext n
    constructor <;> rintro ⟨hn,x,hx,le⟩
    · exact ⟨hn,x,hx,(ex x hx n hn).mp le⟩
    · exact ⟨hn,x,hx,(ex x hx n hn).mpr le⟩
  have req : Required P N ext = Required P N ext' := by
    ext x
    constructor <;> rintro ⟨hx,n,hn,le⟩
    · exact ⟨hx,n,hn,(ex x hx n hn).mp le⟩
    · exact ⟨hx,n,hn,(ex x hx n hn).mpr le⟩
  have keep (g : Set Nat) (y x : Nat)
      (h : x ∈ Trim (Allowed P N ext free g) g free y) :
      x ∈ Trim (Allowed P N ext' free' g) g free' y := by
    obtain ⟨⟨xp,xg,h⟩,tr⟩ := h
    exact ⟨⟨xp,xg,fun n hn hg le => h n (de.symm ▸ hn) hg ((fr x xp n).mpr le)⟩,
      fun ⟨yg,le⟩ => tr ⟨yg,(fr x xp y).mpr le⟩⟩
  obtain ⟨x,y,ne,hx,hy,c⟩ := old
  refine ⟨x,y,ne,keep _ _ _ hx,keep _ _ _ hy,?_⟩
  intro p hp
  exact (c (req.symm ▸ hp)).elim (fun z => Or.inl (keep _ _ _ z)) (fun z => Or.inr (keep _ _ _ z))

theorem andZero {a b : Nat} (ha : a < 2^22)
    (disj : ∀ i ∈ decode a, i ∉ decode b) : a &&& b = 0 := by
  apply Nat.eq_of_testBit_eq
  intro i
  rw [Nat.testBit_and]
  by_cases h : i < 22
  · cases ax : a.testBit i with
    | false => simp
    | true =>
      have bx := disj ⟨i,h⟩ ((memDecode ..).mpr ax)
      have hb : b.testBit i = false := by simpa [memDecode] using bx
      simp [hb]
  · simp [highOff ha h]

theorem pairExcluded (s t : Nat) (ps ns : List Nat)
    (checked : checkArms s t ps ns = true)
    (bound : ∀ x ∈ ps.map (canonical s), x < 2^22)
    (lows : ∀ l ∈ 0 :: (singletons t ++ ps.filter (fun p => subset p t)), l < 2^22)
    (covers : ∀ x ∈ ps.map (canonical s),
      ∀ a ∈ ((decode x) ∩ (decode t)).powerset,
      ∃ l ∈ 0 :: (singletons t ++ ps.filter (fun p => subset p t)), decode l = a) :
    ¬PairPossible source (decode t) (listed (ps.map (canonical s))) (listed (ns.map (canonical s))) := by
  let pp := ps.map (canonical s)
  let nn := ns.map (canonical s)
  let parts := 0 :: (singletons t ++ ps.filter (fun p => subset p t))
  have pairs : parts.all (fun a => parts.all (armPairRejected pp nn t a)) = true :=
    (Bool.and_eq_true_iff.mp checked).2
  rintro ⟨l,h,lt,ht,disj,live,x,y,ne,hx,hy,cover⟩
  have incl (a : Finset Addr) (r : Nat) (subT : a ⊆ decode t)
      (hit : r ∈ hitsRaw source a) : a ∈ ((decode r) ∩ (decode t)).powerset :=
    Finset.mem_powerset.mpr (fun i hi => Finset.mem_inter.mpr ⟨(memDecode ..).mpr (hit i hi),subT hi⟩)
  obtain ⟨a,ha,rfl⟩ := covers x hx.1.1 _ (incl l x lt hx.1.2.1)
  obtain ⟨b,hb,rfl⟩ := covers y hy.1.1 _ (incl h y ht hy.1.2.1)
  have nz : a ||| b ≠ 0 := by
    intro eq
    obtain ⟨i,hi⟩ := live
    have bit : i ∈ decode (a ||| b) := by
      rw [decodeUnion]
      exact Finset.mem_union.mpr hi
    simp [eq,memDecode] at bit
  apply reflectedReject (andZero (lows a ha) disj) nz
    (List.all_eq_true.mp (List.all_eq_true.mp pairs a ha) b hb)
  have old : Feasible (listed pp) (listed nn) (Outside source (decode (a ||| b)))
      (Outside source (decode t)) (hitsRaw source (decode a)) (hitsRaw source (decode b)) := by
    rw [decodeUnion]
    exact ⟨x,y,ne,hx,hy,cover⟩
  have ar : hitsRaw source (decode a) = maskHits a := Set.ext (hitBits (lows a ha))
  have br : hitsRaw source (decode b) = maskHits b := Set.ext (hitBits (lows b hb))
  rw [ar,br] at old
  exact moveFeasible (fun x px n _ => outsideBits (bound x px) _ n)
    (fun x px n => outsideBits (bound x px) _ n) old

end TightRow.Protected.Numeric
