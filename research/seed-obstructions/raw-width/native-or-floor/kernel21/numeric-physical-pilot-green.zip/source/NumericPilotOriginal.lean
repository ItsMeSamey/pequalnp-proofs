import NumericPilotGraph
import ProtectedPilotLiteral

namespace TightRow.Protected.Numeric.PilotGraph
open TightRow.Deletion TightRow.NativeSeeds TightRow.Protected

def nativePos : List (Nat × Fin 676) := [(8320, 19), (8704, 32), (16512, 7), (16640, 20), (33024, 8), (33280, 21)]
def nativeNeg : List (Nat × Fin 676) := [(896, 68), (8448, 502), (16896, 295), (32896, 111), (57344, 156)]
def actualMap : List (Option Addr) :=
  [none,none,none,none,none,none,none,some 7,some 8,some 9,none,none,none,
   some 13,some 14,some 15,none,none,none,none,some 7,none]
def trueBit (p : Nat × Fin 676) : Prop :=
  ∀ j : Addr, rebits actualMap p.1 j = Pilot.stageBit j p.2
instance (p : Nat × Fin 676) : Decidable (trueBit p) := by unfold trueBit; infer_instance
set_option maxRecDepth 20000 in
private theorem nativeLabels :
    (∀ a ∈ nativePos, trueBit a ∧ target.testBit a.2.val = true ∧
       front.testBit a.2.val = false ∧
       ∀ i : Fin 20, Pilot.parentBit i.val a.2 = true → Pilot.present i.val = true) ∧
    (∀ a ∈ nativeNeg, trueBit a ∧ target.testBit a.2.val = false) := by decide

theorem sourceMatched58240 {k : Nat} (t : Tape Addr k)
    (fit : Fits t Pilot.physicalColumn Pilot.stageP negatives) : 5 ≤ k := by
  let c := childOf c31 actualMap
  have cp : c31.P ⊆ t.eval c.raw := by
    intro p hp
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp (show p ∈ nativePos.map Prod.fst from hp)
    obtain ⟨rb,targetOn,frontOff,alive⟩ := nativeLabels.1 a ha
    apply evaluateBelow t _ (fit.1 (show a.2 ∈ Pilot.stageP from ⟨⟨targetOn,frontOff⟩,alive⟩))
    intro j hj
    apply (renameBits ..).mpr
    rw [rb j]
    exact hj
  have cn : ∀ n ∈ c31.N, n ∉ t.eval c.raw := by
    intro n hn high
    obtain ⟨a,ha,rfl⟩ := List.mem_map.mp (show n ∈ nativeNeg.map Prod.fst from hn)
    obtain ⟨rb,targetOff⟩ := nativeLabels.2 a ha
    apply fit.2 a.2 targetOff (evaluateBelow t _ high)
    intro j hj
    change Pilot.stageBit j a.2 = true
    rw [← rb j]
    exact (renameBits ..).mp hj
  have live : (t.eval c.raw).Nonempty := ⟨8320,cp (by decide : 8320 ∈ c31.pos)⟩
  obtain ⟨j,sz,g⟩ := plain t c.raw (Set.range source) (available c31 actualMap) live
  exact (floor31 j _ (physical_iff_net.mp g) ⟨cp,cn⟩).trans sz

theorem allBanksSourceMatched58240 (a b : Bool) {k : Nat}
    (t : Tape (NativeDeletion.Input a b) k)
    (fit : Fits t (fun i => Pilot.physicalColumn i.val) Pilot.stageP negatives) : 5 ≤ k := by
  have phys := t.toPhysical (A := Set.range Pilot.physicalColumn) (fun i => Pilot.physicalColumn i.val)
    (fun i => ⟨i.val,rfl⟩)
  obtain ⟨w,eqn⟩ := phys.toTape Pilot.physicalColumn (fun _ h => h)
  apply sourceMatched58240 w
  simpa only [Fits,eqn] using fit

#print axioms sourceMatched58240
#print axioms allBanksSourceMatched58240
end TightRow.Protected.Numeric.PilotGraph
