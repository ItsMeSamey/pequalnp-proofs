import ast
from pathlib import Path
from collections import Counter
for b,n in [(0,186),(3,223)]:
 tot=Counter(); seen=[]
 for f in Path('.').glob(f'b{b}-*.log'):
  i,lo,hi,c=f.read_text().split(maxsplit=3);seen+=list(range(int(lo),min(int(hi),n)));tot.update(ast.literal_eval(c))
 assert sorted(seen)==list(range(n)) and tot['first']==n and tot['direct one-positive']==4*tot['actualJ']; print(b,dict(tot))
old={tuple(map(int,l.split())) for l in Path('prior306.rows').read_text().splitlines()};new={tuple(map(int,l.split())) for l in Path('oo3safe.rows').read_text().splitlines()};assert len(old)==306 and old==new
a=[tuple(map(int,l.split())) for l in Path('added3-HJ.rows').read_text().splitlines()];assert len(a)==22 and not any(x[0] in [13,15,21,72,84,167] for x in a)
print('fixed literal 306 same; paired 22 additional signed H,J; none at previous four complete firsts')
