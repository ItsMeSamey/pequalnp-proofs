from pathlib import Path
from itertools import combinations
from collections import Counter
from functools import lru_cache
import sys
bank=int(sys.argv[1]);lo,hi=map(int,sys.argv[2:4])
v=list(map(int,Path('native.in').read_text().split()))[2:];vals=[p|t<<13 for p,t in zip(v[::2],v[1::2])]
P,N=vals[:28],vals[28:];S=[1<<i for i in range(20)]
rows=P+N+S
PS=(1<<28)-1;NS=((1<<468)-1)<<28;ALL=(1<<len(rows))-1
raw=[sum(1<<i for i,r in enumerate(rows) if r&m) for m in S+([129,4160] if bank else [])]
def p(w):return w&PS
def large(w):return p(w).bit_count()>=2
def dirty(w):return bool(w&NS)
def closure(collection):
 out={ALL}
 for z in collection:out.update(x&z for x in tuple(out) if p(x&z))
 return out
rc=closure(raw);direct=set(raw)
assert {w for w in rc if large(w)}=={ALL,*[w for w in raw if large(w)]}
assert all(dirty(w) for w in raw)
legal=list(map(int,Path('allow'+str(bank)).read_text().split()))
cnt=Counter();ix=-1
for a in range(len(raw)):
 for b in range(a):
  h=raw[a]|raw[b]
  if p(h) in [p(raw[a]),p(raw[b])]:continue
  ix+=1
  if not lo<=ix<hi:continue
  # Enumerate all nonzero raw conjunctions, with or without H; direct alternatives unconditional.
  src=set(raw+[h]);before=rc|{x&h for x in rc};keep=set(src)
  cleanpair=[x&y for x in src for y in src if not dirty(x&y)]
  for z in before-{ALL}:
   if z in src:continue
   if not large(z) or not dirty(z):continue
   if any(not p(z)&~p(t) for t in cleanpair):continue
   keep.add(z)
  wire=raw+[h]+[h&z for k,z in enumerate(raw) if legal[ix]>>k&1]
  # allow.py uses P,N equivalence, possibly ignoring bare points. Preserve any more expensive bare realization here.
  if not keep<=set(wire):
   for z in keep-set(wire):assert any(not ((w^z)&(NS|PS)) for w in src)
  assert src<=set(wire);cnt['first']+=1
  js={u|w for u,w in combinations(set(wire),2) if p(u|w) not in (p(u),p(w))}-{h}
  for j in js:
   cnt['actualJ']+=1
   # Full original fanin, not a tuple grammar: every conjunction of old raws and any subset of H,J.
   mon=before|{x&j for x in before}
   direct3=src|{j};assert large(h) and large(j) and dirty(h) and dirty(j)
   genuine=direct3|{q for q in mon if q!=ALL and large(q) and dirty(q)}
   # Form revised primitive-and-mask code and require full signed trace equality for every genuine operand.
   coded=set()
   for m in [ALL,h,j,h&j]:
    for r in [ALL,*raw]:
     t=m&r
     if m==r==ALL:continue
     if ((m==ALL and r!=ALL) or large(t)) and dirty(t):coded.add(t)
   assert genuine==coded
   cnt['K arms incl direct']+=len(genuine)
   cnt['direct one-positive']+=sum(not large(z) for z in direct3)
print(bank,lo,hi,dict(cnt),flush=True)
