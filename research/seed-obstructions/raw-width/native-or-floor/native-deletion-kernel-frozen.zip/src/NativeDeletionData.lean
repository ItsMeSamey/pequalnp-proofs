import SixCycleTerminal

namespace TightRow.NativeDeletion

abbrev Addr := Fin 22
abbrev Probe := Fin 35
abbrev Word := BitVec 22
def bits (a : Word) (j : Addr) : Bool := a.getLsbD j.val

def words : List (Word) :=
  [262146, 16392, 32784, 65568, 8320, 16640, 8704, 69632, 17408, 34816, 66560, 132096, 264192, 133120, 8196, 524292, 131073, 524289, 8256, 131136, 262913, 18945, 33921, 65921, 9475, 9474, 65984, 1665, 2464, 131488, 229390, 925752, 30721, 802928, 114759]
def probes : List (Fin 676) :=
  [37, 46, 47, 48, 19, 20, 32, 35, 33, 34, 22, 10, 11, 23, 45, 38, 36, 25, 6, 49, 164, 295, 111, 553, 431, 502, 58, 148, 146, 135, 53, 55, 63, 56, 74]
def active : List (Word) :=
  [1048575, 1048573, 1048565, 1048549, 1048517, 1048389, 1048133, 1047621, 1043525, 1027141, 994373, 928837, 927813, 665669, 663621]
def positiveWitness : List (Probe) :=
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
def negativeWitness : List (Probe) :=
  [20, 21, 22, 23, 24, 21, 25, 26, 27, 28, 27, 29, 28, 29]
def terminalRows : List (Probe) :=
  [14, 15, 16, 17, 18, 19, 30, 31, 32, 33, 34]
def doomed : List Word :=
  [2, 8, 16, 32, 128, 256, 512, 4096, 16384, 32768, 65536, 1024, 262144, 2048]

def word (r : Probe) : Word := words.getD r.val 0
def alive (k : Nat) : Word := active.getD k 0
def posW (k : Nat) : Probe := positiveWitness.getD k 0
def negW (k : Nat) : Probe := negativeWitness.getD k 0
def kill (k : Nat) : Word := doomed.getD k 0

def flags (x : Word) : Word := x ||| (if x &&& 129 = 0 then 0 else 1048576) |||
  (if x &&& 4160 = 0 then 0 else 2097152)
def row (k : Nat) (r : Probe) := flags (word r &&& alive k)
def source (k : Nat) (i : Addr) : Set Probe := {r | bits (row k r) i = true}
def posB (k : Nat) (r : Probe) := decide (r.val < 20) && (word r &&& alive k == word r)
def P (k : Nat) : Set Probe := {r | posB k r = true}
def N : Set Probe := {r | 20 ≤ r.val}

def sub (a b : Word) : Prop := a &&& b = a
instance (a b : Word) : Decidable (sub a b) := inferInstanceAs (Decidable (a &&& b = a))

theorem subAt {a b : Word} (hb : sub a b) (i : Addr) (ha : bits a i = true) :
    bits b i = true := by
  have he := congrArg (fun v : Word => v.getLsbD i.val) hb
  change a.getLsbD i.val = true at ha
  change b.getLsbD i.val = true
  simpa only [BitVec.getLsbD_and,ha,Bool.true_and] using he

theorem exceptAt {a b z : Word} (h : sub (a &&& ~~~z) b) {i : Addr}
    (off : bits z i = false) (on : bits a i = true) : bits b i = true := by
  apply subAt h
  change z.getLsbD i.val = false at off
  change a.getLsbD i.val = true at on
  change (a &&& ~~~z).getLsbD i.val = true
  simp only [BitVec.getLsbD_and,BitVec.getLsbD_not,i.isLt,decide_true,on,off] <;> rfl

theorem zeroAt {a z : Word} (h : a &&& z = 0) {i : Addr}
    (v : bits z i = true) : bits a i = false := by
  have he := congrArg (fun t : Word => t.getLsbD i.val) h
  change z.getLsbD i.val = true at v
  change a.getLsbD i.val = false
  have hz : (0 : Word).getLsbD i.val = false := BitVec.getLsbD_zero
  simpa only [BitVec.getLsbD_and,v,Bool.and_true,hz] using he

/-- Per-deletion data on actual witnesses. Row 14 is a positive retained through
the whole chain. The nonempty restricted output therefore needs no zero wire. -/
def Valid (k : Nat) : Prop :=
  posB k (posW k) = true ∧ 20 ≤ (negW k).val ∧ posB (k+1) 14 = true ∧
  sub (row k (posW k) &&& ~~~(kill k)) (row k (negW k)) ∧
  ∀ r : Probe, (row (k+1) r &&& kill k = 0) ∧
    (posB (k+1) r = true → posB k r = true ∧ sub (row k r) (row (k+1) r)) ∧
    (20 ≤ r.val → sub (row (k+1) r) (row k r))
instance (k : Nat) : Decidable (Valid k) := by unfold Valid; infer_instance

theorem step0 : Valid 0 := by decide
theorem step1 : Valid 1 := by decide
theorem step2 : Valid 2 := by decide
theorem step3 : Valid 3 := by decide
theorem step4 : Valid 4 := by decide
theorem step5 : Valid 5 := by decide
theorem step6 : Valid 6 := by decide
theorem step7 : Valid 7 := by decide
theorem step8 : Valid 8 := by decide
theorem step9 : Valid 9 := by decide
theorem step10 : Valid 10 := by decide
theorem step11 : Valid 11 := by decide
theorem step12 : Valid 12 := by decide
theorem step13 : Valid 13 := by decide

theorem valid (k : Nat) (hk : k < 14) : Valid k := by
  have cases : k = 0 ∨ k = 1 ∨ k = 2 ∨ k = 3 ∨ k = 4 ∨ k = 5 ∨ k = 6 ∨ k = 7 ∨ k = 8 ∨ k = 9 ∨ k = 10 ∨ k = 11 ∨ k = 12 ∨ k = 13 := by omega
  rcases cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact step0
  · exact step1
  · exact step2
  · exact step3
  · exact step4
  · exact step5
  · exact step6
  · exact step7
  · exact step8
  · exact step9
  · exact step10
  · exact step11
  · exact step12
  · exact step13

end TightRow.NativeDeletion
