import TightRowIndexed

namespace TightRow.Deletion
universe u v w
variable {S : Type u} {R : Type v} {X : Type w}

/-- Pointwise comparison across two rows, which may belong to different charts. -/
def Below (f : S → Set R) (x : R) (g : S → Set X) (y : X) : Prop :=
  ∀ i, x ∈ f i → y ∈ g i

theorem evaluateBelow {k : Nat} (t : Tape S k) {f : S → Set R} {g : S → Set X}
    {x : R} {y : X} (h : Below f x g y) : x ∈ t.eval f → y ∈ t.eval g := by
  induction t with
  | output i => exact h i
  | andGate a b tail ih =>
    apply ih
    intro i hv
    cases i with
    | none => exact ⟨h a hv.1,h b hv.2⟩
    | some i => exact h i hv
  | orGate a b tail ih =>
    apply ih
    intro i hv
    cases i with
    | none => exact hv.elim (fun v => Or.inl (h a v)) (fun v => Or.inr (h b v))
    | some i => exact h i hv

/-- A zero-valued reference may survive in the simulation even without a physical
constant input. The result is materialized whenever the output has a true row. -/
abbrev Avail (B : Bank R) (s : Set R) := s = ∅ ∨ s ∈ B

theorem extendAvail {f : S → Set R} {B : Bank R} (av : ∀ i, Avail B (f i))
    {s : Set R} (hs : Avail B s) : ∀ i, Avail B (extend f s i)
  | none => hs
  | some i => av i

theorem growAvail {f : S → Set R} {B : Bank R} (av : ∀ i, Avail B (f i)) (s : Set R) :
    ∀ i, Avail (insert s B) (extend f s i) := by
  apply extendAvail (fun i => (av i).imp id (fun h => Or.inr h))
  exact Or.inr (Set.mem_insert _ _)

theorem plain {k : Nat} (t : Tape S k) (f : S → Set R) (B : Bank R)
    (av : ∀ i, Avail B (f i)) (live : (t.eval f).Nonempty) :
    ∃ j ≤ k, Physical B (t.eval f) j := by
  induction t generalizing B with
  | output i =>
    rcases av i with z | v
    · change (f i).Nonempty at live
      simp [z] at live
    · exact ⟨0,by omega,.output v⟩
  | andGate a b tail ih =>
    rcases av a with za | va
    · exact ih _ B (extendAvail av (Or.inl (by simp [za]))) live
    rcases av b with zb | vb
    · exact ih _ B (extendAvail av (Or.inl (by simp [zb]))) live
    obtain ⟨j,size,p⟩ := ih _ _ (growAvail av _) live
    exact ⟨j,size,.andGate va vb p⟩
  | orGate a b tail ih =>
    rcases av a with za | va
    · obtain ⟨j,size,p⟩ := ih _ B (extendAvail av (by simpa [za] using av b)) live
      exact ⟨j,by omega,p⟩
    rcases av b with zb | vb
    · obtain ⟨j,size,p⟩ := ih _ B (extendAvail av (by simpa [zb] using Or.inr va)) live
      exact ⟨j,by omega,p⟩
    obtain ⟨j,size,p⟩ := ih _ _ (growAvail av _) live
    exact ⟨j+1,by omega,.orGate va vb p⟩

end TightRow.Deletion
