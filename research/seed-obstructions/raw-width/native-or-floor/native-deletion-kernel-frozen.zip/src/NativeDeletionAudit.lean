import NativeDeletionOriginal
#print axioms TightRow.Deletion.plain
#print axioms TightRow.Deletion.refund
#print axioms TightRow.Deletion.delete
#print axioms TightRow.NativeDeletion.valid
#print axioms TightRow.NativeDeletion.projectedNineteen
#print axioms TightRow.NativeDeletion.exactProbe
#print axioms TightRow.NativeDeletion.allFourNativeNineteen
