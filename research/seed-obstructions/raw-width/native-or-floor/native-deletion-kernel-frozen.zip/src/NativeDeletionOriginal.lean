import NativeDeletionChain
import NativeDeletionSeeds

namespace TightRow.NativeDeletion
open TightRow.Deletion
open TightRow.NativeSeeds

def origin (r : Probe) : Fin 676 := probes.getD r.val 0

private theorem probeBits : ∀ r : Probe, ∀ j : Addr, bits (row 0 r) j =
    (columnWords.getD j.val 0).testBit (origin r).val := by decide

theorem exactProbe (r : Probe) (i : Addr) :
    r ∈ source 0 i ↔ origin r ∈ rich i := by
  change bits (row 0 r) i = true ↔ (column i).testBit (origin r).val = true
  rw [probeBits,columnsChecked]

private theorem labelsChecked : ∀ r : Probe,
    (posB 0 r = true → target.testBit (origin r).val = true ∧
     front.testBit (origin r).val = false) ∧
    (20 ≤ r.val → target.testBit (origin r).val = false) := by decide

/-- Every fitting separator on the original 676 literal rows of the paired bank
uses at least 19 ORs. The source map includes the two actual optional point pair
values. The given front only selects residual positive obligations. -/
theorem richNineteen {k : Nat} (t : Tape Addr k) (h : Fits t rich positives negatives) : 19 ≤ k := by
  apply projectedNineteen t
  constructor
  · intro r hr
    exact evaluateBelow t (fun i v => (exactProbe r i).mpr v)
      (h.1 ((labelsChecked r).1 hr))
  · intro r hr high
    exact h.2 _ ((labelsChecked r).2 hr)
      (evaluateBelow t (fun i v => (exactProbe r i).mp v) high)

/-- Addresses present in one of the four optional physical banks. -/
abbrev Input (pair129 pair4160 : Bool) :=
  {i : Addr // i.val < 20 ∨ i.val = 20 ∧ pair129 = true ∨ i.val = 21 ∧ pair4160 = true}

theorem allFourNativeNineteen (pair129 pair4160 : Bool) {k : Nat}
    (t : Tape (Input pair129 pair4160) k)
    (h : Fits t (fun i => rich i.val) positives negatives) : 19 ≤ k := by
  have physical := t.toPhysical (A := Set.range rich) (fun i => rich i.val)
    (fun i => ⟨i.val,rfl⟩)
  obtain ⟨q,eqn⟩ := physical.toTape rich (fun _ h => h)
  apply richNineteen q
  simpa only [Fits,eqn] using h

end TightRow.NativeDeletion
