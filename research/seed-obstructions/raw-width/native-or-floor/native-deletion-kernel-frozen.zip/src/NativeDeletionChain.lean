import DeletionRefund
import NativeDeletionData

namespace TightRow.NativeDeletion
open TightRow.Deletion

theorem dropOne {k d : Nat} (t : Tape Addr k) (stage : d < 14)
    (h : Fits t (source d) (P d) N) :
    ∃ j < k, ∃ t' : Tape Addr j, Fits t' (source (d+1)) (P (d+1)) N := by
  obtain ⟨yes,no,alivePos,except,info⟩ := valid d stage
  have acc : P (d+1) ⊆ t.eval (source (d+1)) := by
    intro r hr
    obtain ⟨old,inc⟩ := (info r).2.1 hr
    exact evaluateBelow t (fun i hi => subAt inc i hi) (h.1 old)
  have neg : ∀ r ∈ N, r ∉ t.eval (source (d+1)) := by
    intro r hr high
    exact h.2 r hr (evaluateBelow t (fun i hi => subAt ((info r).2.2 hr) i hi) high)
  have mark (i : Addr) : Mark (Set.range (source (d+1))) (source (d+1) i)
      (posW d ∈ source d i → negW d ∈ source d i) := by
    cases eqn : bits (kill d) i with
    | false => exact Or.inr ⟨⟨i,rfl⟩,exceptAt except eqn⟩
    | true =>
      left
      apply Set.eq_empty_iff_forall_notMem.mpr
      intro r hr
      have off := zeroAt (info r).1 eqn
      change bits (row (d+1) r) i = true at hr
      rw [off] at hr
      contradiction
  obtain ⟨j,size,g⟩ := refund t (source (d+1)) (source d) _ mark
    ⟨14,acc alivePos⟩ (h.1 yes) (h.2 _ no)
  obtain ⟨t',eqn⟩ := g.toTape (source (d+1)) (fun _ hi => hi)
  exact ⟨j,size,t',by simpa only [Fits,eqn] using And.intro acc neg⟩

theorem reach {k : Nat} (t : Tape Addr k) (h : Fits t (source 0) (P 0) N)
    (d : Nat) (bound : d ≤ 14) :
    ∃ j, d+j ≤ k ∧ ∃ t' : Tape Addr j, Fits t' (source d) (P d) N := by
  induction d with
  | zero => exact ⟨k,by omega,t,h⟩
  | succ d ih =>
    obtain ⟨j,cost,u,hu⟩ := ih (by omega)
    obtain ⟨l,less,w,hw⟩ := dropOne u (by omega) hu
    exact ⟨l,by omega,w,hw⟩

def terminalRow (r : SixCycle.Row) : Probe := terminalRows.getD r.val 0

private theorem terminalBits : ∀ r : SixCycle.Row, ∀ i : Addr,
    bits (row 14 (terminalRow r)) i =
    (SixCycle.rowCodes.getD r.val 0).testBit i.val := by decide
private theorem terminalPos : ∀ r : SixCycle.Row, r.val < 6 →
    posB 14 (terminalRow r) = true := by decide
private theorem terminalNeg : ∀ r : SixCycle.Row, 6 ≤ r.val →
    20 ≤ (terminalRow r).val := by decide

theorem terminalBound {j : Nat} (t : Tape Addr j) (h : Fits t (source 14) (P 14) N) :
    5 ≤ j := by
  apply SixCycle.terminal_five_minimum.1 j t
  · intro r hr
    apply evaluateBelow t (x := terminalRow r) (f := source 14)
    · intro i hi
      change bits (row 14 (terminalRow r)) i = true at hi
      change (SixCycle.rowCodes.getD r.val 0).testBit i.val = true
      rwa [← terminalBits]
    · exact h.1 (terminalPos r hr)
  · intro r hr high
    apply h.2 (terminalRow r) (terminalNeg r hr)
    apply evaluateBelow t (x := r) (f := SixCycle.literal) _ high
    intro i hi
    change bits (row 14 (terminalRow r)) i = true
    rw [terminalBits]
    exact hi

theorem projectedNineteen {k : Nat} (t : Tape Addr k) (h : Fits t (source 0) (P 0) N) :
    19 ≤ k := by
  obtain ⟨j,size,u,hu⟩ := reach t h 14 (by decide)
  have floor := terminalBound u hu
  omega

end TightRow.NativeDeletion
