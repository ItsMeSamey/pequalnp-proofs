import DeletionPlain

namespace TightRow.Deletion
universe u v w
variable {S : Type u} {R : Type v} {X : Type w}

/-- A wire is either zero on the restricted chart, or physically available there
and unable to distinguish the original two witness rows in the specified order. -/
abbrev Mark (B : Bank R) (s : Set R) (e : Prop) := s = ∅ ∨ s ∈ B ∧ e

private theorem extendMark {f : S → Set R} {g : S → Set X} {p n : X} {B : Bank R}
    (av : ∀ i, Mark B (f i) (p ∈ g i → n ∈ g i)) {s : Set R} {old : Set X}
    (hs : Mark B s (p ∈ old → n ∈ old)) :
    ∀ i, Mark B (extend f s i) (p ∈ extend g old i → n ∈ extend g old i)
  | none => hs
  | some i => av i

private theorem growMark {f : S → Set R} {g : S → Set X} {p n : X} {B : Bank R}
    (av : ∀ i, Mark B (f i) (p ∈ g i → n ∈ g i)) (s : Set R) {old : Set X}
    (ok : p ∈ old → n ∈ old) :
    ∀ i, Mark (insert s B) (extend f s i) (p ∈ extend g old i → n ∈ extend g old i) := by
  apply extendMark (fun i => (av i).imp id (fun h => ⟨Or.inr h.1,h.2⟩))
  exact Or.inr ⟨Set.mem_insert _ _,ok⟩

/-- Eliminate at least one paid gate. Old and new chart signatures are independent;
only the stated availability, row order and nonempty output are used. -/
theorem refund {k : Nat} (t : Tape S k) (f : S → Set R) (g : S → Set X)
    (B : Bank R) {p n : X} (av : ∀ i, Mark B (f i) (p ∈ g i → n ∈ g i))
    (live : (t.eval f).Nonempty) (hp : p ∈ t.eval g) (hn : n ∉ t.eval g) :
    ∃ j < k, Physical B (t.eval f) j := by
  induction t generalizing B with
  | output i =>
    rcases av i with z | ⟨_,le⟩
    · change (f i).Nonempty at live
      simp [z] at live
    · exact (hn (le hp)).elim
  | andGate a b tail ih =>
    rcases av a with za | ⟨va,ia⟩
    · exact ih _ _ B (extendMark av (Or.inl (by simp [za]))) live hp hn
    rcases av b with zb | ⟨vb,ib⟩
    · exact ih _ _ B (extendMark av (Or.inl (by simp [zb]))) live hp hn
    have ok : p ∈ g a ∩ g b → n ∈ g a ∩ g b := fun h => ⟨ia h.1,ib h.2⟩
    obtain ⟨j,size,q⟩ := ih _ _ _ (growMark av _ ok) live hp hn
    exact ⟨j,size,.andGate va vb q⟩
  | orGate a b tail ih =>
    have avail (i : _) : Avail B (f i) := (av i).imp id And.left
    rcases av a with za | ⟨va,ia⟩
    · obtain ⟨j,size,q⟩ := plain tail _ B
        (extendAvail avail (by simpa [za] using avail b)) live
      exact ⟨j,by omega,q⟩
    rcases av b with zb | ⟨vb,ib⟩
    · obtain ⟨j,size,q⟩ := plain tail _ B
        (extendAvail avail (by simpa [zb] using avail a)) live
      exact ⟨j,by omega,q⟩
    have ok : p ∈ g a ∪ g b → n ∈ g a ∪ g b :=
      fun h => h.elim (fun h => Or.inl (ia h)) (fun h => Or.inr (ib h))
    obtain ⟨j,size,q⟩ := ih _ _ _ (growMark av _ ok) live hp hn
    exact ⟨j+1,by omega,.orGate va vb q⟩

/-- Chart transport through an arbitrary partial reference map; different old
references may name the same new source, while none is the false constant. -/
def rename {T : Type*} (ρ : S → Option T) (v : T → Set R) (i : S) : Set R :=
  (ρ i).elim ∅ v

def Fits {k : Nat} (t : Tape S k) (v : S → Set R) (P N : Set R) : Prop :=
  P ⊆ t.eval v ∧ ∀ x ∈ N, x ∉ t.eval v

theorem delete {T : Type*} {k : Nat} (t : Tape S k)
    {g : S → Set X} {v : T → Set R} (ρ : S → Option T)
    {P N : Set X} {P' N' : Set R} (fits : Fits t g P N) {p n : X}
    (yes : p ∈ P) (no : n ∈ N)
    (sep : ∀ i j, ρ i = some j → p ∈ g i → n ∈ g i) (live : P'.Nonempty)
    (up : ∀ x ∈ P', ∃ a ∈ P, Below g a (rename ρ v) x)
    (down : ∀ x ∈ N', ∃ b ∈ N, Below (rename ρ v) x g b) :
    ∃ j < k, ∃ q : Tape T j, Fits q v P' N' := by
  have pos : P' ⊆ t.eval (rename ρ v) := by
    intro x hx
    obtain ⟨a,ha,le⟩ := up x hx
    exact evaluateBelow t le (fits.1 ha)
  have neg : ∀ x ∈ N', x ∉ t.eval (rename ρ v) := by
    intro x hx high
    obtain ⟨b,hb,le⟩ := down x hx
    exact fits.2 b hb (evaluateBelow t le high)
  have marked (i : S) : Mark (Set.range v) (rename ρ v i) (p ∈ g i → n ∈ g i) := by
    cases h : ρ i with
    | none => exact Or.inl (by simp [rename,h])
    | some j => exact Or.inr ⟨⟨j,by simp [rename,h]⟩,sep i j h⟩
  obtain ⟨j,size,phys⟩ := refund t _ g _ marked (live.mono pos) (fits.1 yes) (fits.2 n no)
  obtain ⟨q,eqn⟩ := phys.toTape v (fun _ h => h)
  exact ⟨j,size,q,by simpa [Fits,eqn] using And.intro pos neg⟩

end TightRow.Deletion
