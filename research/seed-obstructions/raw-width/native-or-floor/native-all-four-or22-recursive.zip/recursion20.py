from vertexdelete import *
from array import array
def compute(b,cut):
    raw=bits(cut);n=len(raw);F=(1<<n)-1
    E=[0]*n;safe=[0]*n;partner=[0]*n;cert=[[0]*n for _ in raw]
    d={x:1<<i for i,x in enumerate(raw)}
    for p in P:
        if p&~cut:continue
        x,y=bits(p);E[d[x].bit_length()-1]|=d[y];E[d[y].bit_length()-1]|=d[x]
    for i,x in enumerate(raw):
        partner[i]=next((d.get(c^x,0)for c in b if c&x),0)
        for j,y in enumerate(raw):
            if E[i]>>j&1:
                if not partner[i] or any(v&y and v&raw[partner[i].bit_length()-1] for v in N):safe[i]|=1<<j
                for k,u in enumerate(raw):
                    if any(v&y and v&u for v in N):cert[i][k]|=1<<j
    nonlit=[sum(d.get(x,0)for x in bits(c))for c in b]
    lb=array('b',[0])*(F+1);why=array('b',[-2])*(F+1)
    for s in range(1,F+1):
        ids=[i for i in range(n)if s>>i&1]
        e=sum((E[i]&s).bit_count() for i in ids)//2
        if e<2:continue
        best=0;idx=-2;least=80;allgood=True
        for i in ids:
            u=s^(1<<i);v=lb[u];ne=E[i]&s
            ok=bool(ne and ne.bit_count()<e and (not partner[i]&s or safe[i]&s))
            if ok:v+=1;least=min(least,v)
            else:allgood=False
            if v>best:best=v;idx=i
        if allgood and least+1>best and all((m&s).bit_count()<=1 for m in nonlit):
            good=all((E[i]&s&~(1<<j) or E[j]&s&~(1<<i)) and ((cert[i][j]|cert[j][i])&s) for a,i in enumerate(ids)for j in ids[a+1:])
            if good:best=least+1;idx=-1
        lb[s]=best;why[s]=idx
    print(b,'literal coordinates',n,'OR floor',lb[F],flush=True)
    return lb,why
if __name__=='__main__':compute((129,4160),(1<<20)-1 ^ 58)
