from recursion20 import *
from json import dumps
bank=(129,4160);cut=(1<<20)-1^58;raw=bits(cut);L,mode=compute(bank,cut);memo={}
def physical(s):return sum(x for i,x in enumerate(raw) if s>>i&1)
def req(s):
    if s in memo:return
    i=mode[s];v=physical(s);children=[]
    if i==-2:kind='zero'
    else:
        kind='branch' if i==-1 else 'delete'
        for j in ([k for k in range(len(raw)) if s>>k&1] if i==-1 else [i]):
            q=raw[j];c=s^(1<<j);need=L[s]-L[c]-(1 if kind=='branch' else 0)
            w=next((z for z in nexts_ext(v) if z[0]==q),None) if need>0 else None
            assert need<=1 and (w or need<=0)
            children.append([q,c,*((w[1],w[2])if w else ())]);req(c)
    memo[s]=dict(S=v,L=L[s],kind=kind,child=children)
def nexts_ext(v):
    pp=[p for p in P if not p&~v]
    for q in bits(v):
        if not any(not p&q for p in pp):continue
        Z=q|sum(1<<(20+j)for j,c in enumerate(bank)if v&c==q)
        for p in pp:
            if not q&p:continue
            a=extend(p,v,bank)&~Z
            n=next((n for n in N if not a&~extend(n,v,bank)),None)
            if n is not None:yield q,p,n;break
req((1<<len(raw))-1)
print(len(memo),'states',sum(r['kind']=='branch'for r in memo.values()),'branch',sum(len(r['child'])for r in memo.values()),'arcs')
Path('subproof.json').write_text(dumps(memo,separators=(',',':'))+'\n')
