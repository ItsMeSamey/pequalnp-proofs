from vertexdelete import bits,P,N,extend
from pathlib import Path
import json
bank=(129,4160);ALL=(1<<20)-1;TOP=ALL^58
D={int(k):v for k,v in json.loads(Path('subproof.json').read_text()).items()}
by={v['S']:v for v in D.values()};assert len(by)==len(D) and by[TOP]['L']==18
assert len(P)==28 and len(N)==468
for s,r in by.items():
 ps=[p for p in P if not p&~s]
 if r['kind']=='zero':
    assert r['child']==[] and r['L']==0
    continue
 qs=bits(s)
 if r['kind']=='branch':
    assert all((s&c).bit_count()<=1 for c in bank)
    assert {c[0]for c in r['child']}==set(qs) and len(r['child'])==len(qs)
    for q in qs:
        assert any(p&q for p in ps) and any(not p&q for p in ps)
        assert any(n&q for n in N)
    for i,x in enumerate(qs):
        for y in qs[:i]:
            assert any(bool(p&x)!=bool(p&y) for p in ps)
            assert any(p&a and any(not ((p^a)|b)&~n for n in N) for a,b in ((x,y),(y,x))for p in ps)
 else:assert r['kind']=='delete' and len(r['child'])==1
 for q,k,*w in r['child']:
    assert q in qs and D[k]['S']==s^q
    if w:
        p,n=w;assert p in ps and q&p and n in N and any(not p0&q for p0 in ps)
        Z=q|sum(1<<(20+j)for j,c in enumerate(bank)if c&s==q)
        assert not (extend(p,s,bank)&~Z)&~extend(n,s,bank)
    gain=int(bool(w))+(r['kind']=='branch')
    assert r['L']<=D[k]['L']+gain
# Four actual outer refunds.
from vertexdelete import nexts
s=ALL
for q in (2,8,16,32):
    assert any(z[0]==q for z in nexts(s,bank))
    s^=q
assert s==TOP
print('Verified 4 outer refunds, '+str(len(D))+' subinstances and core OR lower bound '+str(by[TOP]['L'])+'; all four native banks require at least 22 ORs.')
