from pathlib import Path
from pysat.solvers import Solver
import sys
def test(p,n,m):
    ss=sorted({tuple(int(bool(r&bit))for r in p+n) for bit in (1<<j for j in range(max(p+n).bit_length()))})
    cc=0
    def var():
        nonlocal cc
        cc+=1
        return cc
    clauses=[]
    wires=[]
    for col in ss:
        w=[var()for _ in col]
        clauses.extend([[v if u else -v]for u,v in zip(col,w)]);wires.append(w)
    def arm():
        chosen=[var() for _ in wires];o=[]
        for i in range(len(p+n)):
            failed=[]
            for c,w in zip(chosen,wires):
                t=var();failed.append(t);clauses.extend([[-t,c],[-t,-w[i]],[-c,w[i],t]])
            v=var();o.append(v);clauses.extend([[-t,-v]for t in failed]);clauses.append([v,*failed])
        return o
    for _ in range(m):
        a,b=arm(),arm();w=[]
        for x,y in zip(a,b):
            z=var();w.append(z);clauses.extend([[-x,z],[-y,z],[x,y,-z]])
        wires.append(w)
    out=arm();clauses.extend([[v if i<len(p)else -v] for i,v in enumerate(out)])
    with Solver(name='glucose4',bootstrap_with=clauses)as sol:return sol.solve()
if __name__=='__main__':
 l=Path(sys.argv[1]).read_text().splitlines();p,n=[list(map(int,z.split())) for z in l[1:3]]
 for m in map(int,sys.argv[2:]):print(m,test(p,n,m),flush=True)
