from vertexdelete import *
from itertools import combinations
bank=(129,4160)
def tightforms(final):
    ps=sorted({extend(p,final,bank)for p in P if not p&~final})
    ns={extend(n,final,bank) for n in N}
    ns=sorted(n for n in ns if not any(n!=m and not n&~m for m in ns))
    return ps,ns
for points in combinations(bits(8191),3):
  for tags in combinations(bits(127<<13),3):
    ve=points+tags;s=sum(ve);edges=[p for p in P if not p&~s]
    if len(edges)!=6 or any(sum(bool(v&e)for e in edges)!=2 for v in ve):continue
    if any((s&c).bit_count()>1 for c in bank):continue
    path=find((1<<20)-1,bank,s)
    if path is None:continue
    p,n=tightforms(s)
    print('C6',s,len(path),len(p),len(n),ve,path)
    Path('core6.in').write_text(f'{len(p)} {len(n)}\n'+' '.join(map(str,p))+'\n'+' '.join(map(str,n))+'\n1\n')
    raise SystemExit
