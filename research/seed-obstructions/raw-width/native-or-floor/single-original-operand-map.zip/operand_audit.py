from sample import samples
from pathlib import Path
from itertools import combinations
from functools import reduce
from operator import and_,or_
from collections import Counter
import os,sys
rows,front,target=samples(Path('L-meta-18968.json'))
P=sorted({r&1048575 for i,r in enumerate(rows) if (target&~front)>>i&1})
N=sorted({r&1048575 for i,r in enumerate(rows) if not target>>i&1})
T=P+N+[1<<i for i in range(20)];allbits=(1<<len(T))-1
pos=(1<<len(P))-1;neg=((1<<len(N))-1)<<len(P)
assert (len(P),len(N),len(rows))==(28,468,676)
def sig(m):return sum(1<<i for i,e in enumerate(T) if e&m)
def audit(b):
 masks=[1<<i for i in range(20)]+[(129,4160)[b-1]];R=[sig(m) for m in masks]
 # Every raw-subset conjunction with any positive lies inside some positive row's set of active primitives.
 groups={()}
 for e in P:
  active=[i for i,m in enumerate(masks) if m&e]
  for k in range(1,len(active)+1):groups.update(combinations(active,k))
 subs=[(inds,reduce(and_,(R[i] for i in inds),allbits)) for inds in sorted(groups)]
 def mapping(old,key):
  oo=[(0,allbits)]
  for j,y in enumerate(old):oo += [(i|1<<j,x&y) for i,x in oo]
  small={x&r:mask*(len(R)+1)+i+1 for mask,x in oo for i,r in [(-1,allbits),*enumerate(R)] if mask or i>=0}
  codes={}
  for mask,x in oo:
   for i,r in [(-1,allbits),*enumerate(R)]:
    v=x&r
    if not(mask or i>=0) or not (v&pos and v&neg):continue
    if (v&pos).bit_count()<2 and (mask or i<0):continue
    codes.setdefault(v,mask*(len(R)+1)+i+1)
  ct=Counter()
  for mask,x in oo:
   for ix,meet in subs:
    if not(mask or ix):continue
    s=x&meet;n=(s&pos).bit_count()
    if n==0:cat='zero'
    elif not s&neg:cat='clean'
    elif s in codes:cat='exact'
    elif n==1:cat='paid-single'
    else:raise AssertionError((mask,ix,n))
    if os.environ.get('KEY')==key:print('map',key,mask,ix,cat,codes.get(s,'-'))
    ct[cat]+=1
  # Each direct primitive including all four degree-one points is genuinely available in code q+1.
  for i,r in enumerate(R):assert (r&pos) and small.get(r) is not None
  return ct
 first=[(i,j,R[i]|R[j]) for i in range(len(R)) for j in range(i) if (R[i]&~R[j]&pos) and (R[j]&~R[i]&pos)]
 aug=list(map(int,Path(f'augallow{b}.in').read_text().split()))
 hj=[[] for _ in first]
 for row in Path(f'single{b}-HJ.rows').read_text().splitlines():
  i,a,c,*_=map(int,row.split());hj[i].append((a,c))
 total=Counter(); prefixes=0
 for i,(_,_,h) in enumerate(first):
  bucket=mapping([h],f'B{b}H{i}'); chosen=[h&r for k,r in enumerate(R) if aug[i]>>k&1];bank=R+[h]+chosen
  # Audit the actual J-arm allow-mask in signed semantics, independently of its selection-code derivation.
  rawand=[h&r for r in R];source=R+[h]
  clean=[a&b for a in source for b in source if not ((a&b)&neg)]
  for r in rawand:
   if r in bank or not(r&pos) or not(r&neg) or (r&pos).bit_count()==1:continue
   assert any(not(r&pos&~v) for v in clean)
  for a,c in hj[i]:
   j=bank[a]|bank[c];counts=mapping([h,j],f'B{b}H{i}J{a}.{c}');total.update(counts);prefixes+=1
 print(b,len(first),prefixes,len(groups),sorted(total.items()),flush=True)
for b in map(int,sys.argv[1:] or [1,2]):audit(b)
