#include <cstdlib>
#include <array>
#include <bit>
#include <cstdint>
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;
const int M=65536;
using msk=unsigned;
vector<msk> readlist(){int n;scanf("%d",&n);vector<msk> z(n);for(auto& k:z)scanf("%u",&k);return z;}
struct Witness{msk one,two,three;};
#include "partialarm.hpp"
int main(int argc,char**argv){
 auto p=readlist(),n=readlist(),base=readlist(),cand=readlist();array<msk,16> ed{};array<array<msk,16>,16> dist{};
 for(int i=0;i<16;i++)for(auto x:p)if(x>>i&1)ed[i]|=x^(1u<<i);
 for(int i=0;i<16;i++)for(int j=0;j<16;j++)for(msk k=ed[i];k;k&=k-1){
   msk t=k&-k,m=t|(1u<<j); for(auto neg:n)if(!(m&~neg)){dist[i][j]|=t;break;}}
 array<uint8_t,M> edges{},simple{};
 for(msk s=1;s<M;s++){
   int i=countr_zero(s);edges[s]=edges[s&(s-1)]+popcount((s&(s-1))&ed[i]);simple[s]=1;
   for(msk w=s;w&&simple[s];w&=w-1){int a=countr_zero(w);for(msk z=w&(w-1);z;z&=z-1){
     int b=countr_zero(z);
     if(!((dist[a][b]|dist[b][a])&s)||(!(ed[a]&s&~(1u<<b))&&!(ed[b]&s&~(1u<<a)))){simple[s]=0;break;}
   }}
 }
 for(int h=atoi(argv[1]);h<min<int>(atoi(argv[2]),cand.size());h++){
   auto comps=base;if(cand[h])comps.push_back(cand[h]);
   array<uint8_t,M>lb{};array<int,M> wm{};wm.fill(-100);
   // Lookup by surviving neighbors of q in all overlapping compounds.
   array<msk,16> affect{};static array<array<msk,M>,16> good;
   for(int i=0;i<16;i++){msk q=1u<<i;for(auto c:comps)if(c&q)affect[i]|=c^q;
     msk w=affect[i];for(msk t=w;;t=(t-1)&w){msk yes=0;
       for(msk z=ed[i];z;z&=z-1){msk partner=z&-z;
         for(auto neg:n)if(neg&partner){bool ok=true;for(auto c:comps)if((q&c)&&(t&c)&&!(neg&t&c))ok=false;
          if(ok){yes|=partner;break;}}}
       good[i][t]=yes;if(!t)break;
     }
   }
   for(msk s=1;s<M;s++){int e=edges[s];if(e<2)continue;int best=0,least=80;vector<msk> active;msk eligible=0;
     for(auto c:comps)if(popcount(s&c)>1 && find(active.begin(),active.end(),s&c)==active.end())active.push_back(s&c);
     for(msk z=s;z;z&=z-1){int i=countr_zero(z);auto q=z&-z;int cost=lb[s^q];
       bool rebate=popcount(s&ed[i])<e&&(s&good[i][s&affect[i]]);
       if(rebate) cost++;if((s&ed[i])&&popcount(s&ed[i])<e)eligible|=q;
       if(cost>best){best=cost;wm[s]=i+(rebate?16:0);}
     }
     while(true){msk prot=0;for(msk zz=eligible;zz;zz&=zz-1){msk q=zz&-zz;if(lb[s^q]+1>=best)prot|=q;}if(!partialImpossible(s,prot,active,p,n))break;best++;wm[s]=-1;}lb[s]=best;
   }
   FILE* f=fopen("partial-table.bin","wb");fwrite(lb.data(),1,M,f);fwrite(wm.data(),sizeof(int),M,f);fclose(f);printf("%d %u %d\n",h,cand[h],(int)lb.back());fflush(stdout);
 }
}
