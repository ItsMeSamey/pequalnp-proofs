using NN=std::array<uint64_t,4>;
bool overlaps(const NN&a,const NN&b){return (a[0]&b[0])||(a[1]&b[1])||(a[2]&b[2])||(a[3]&b[3]);}
NN both(const NN&a,const NN&b){return {a[0]&b[0],a[1]&b[1],a[2]&b[2],a[3]&b[3]};}
void also(NN&a,const NN&b){for(int i=0;i<4;i++)a[i]|=b[i];}
bool nonempty(const NN&a){return a[0]||a[1]||a[2]||a[3];}
struct ArmSet {msk r,p;NN n;};
static array<NN,65536> NegDom;
static bool built=false;
bool partialImpossible(msk s,msk prot,const vector<msk>&aliases,const vector<msk>&pos,const vector<msk>&neg){
 if(!prot)return false;
 if(!built){if(neg.size()>256)abort();built=true;
   for(msk z=0;z<65536;z++)if(popcount(z)<=2)for(unsigned n=0;n<neg.size();n++)
     if(!(z&~neg[n]))NegDom[z][n/64]|=uint64_t(1)<<(n%64);}
 vector<msk> pp;for(msk z:pos)if(!(z&~s))pp.push_back(z);
 int np=pp.size();array<unsigned,24> cp{};array<NN,8> cu{};
 for(unsigned n=0;n<neg.size();n++){unsigned c=0;for(unsigned i=0;i<aliases.size();i++)if(neg[n]&aliases[i])c|=1u<<i;
   for(unsigned v=c;;v=(v-1)&c){cu[v][n/64]|=uint64_t(1)<<(n%64);if(!v)break;}
 }
 array<NN,24> fd;array<msk,24> dom{};bool forced=false;
 for(int e=0;e<np;e++){for(unsigned i=0;i<aliases.size();i++)if(aliases[i]&pp[e])cp[e]|=1u<<i;
   fd[e]=both(cu[cp[e]],NegDom[pp[e]&~prot]);if(nonempty(fd[e]))forced=true;}
 if(!forced)return false;
 for(int y=0;y<np;y++)for(int x=0;x<np;x++)if(!(cp[x]&~cp[y])&&!(pp[x]&~prot&~pp[y]))dom[y]|=1u<<x;
 vector<ArmSet> sets;
 auto add=[&](msk r){msk q=0;for(int j=0;j<np;j++)if(!(r&~pp[j]))q|=1u<<j;sets.push_back({r,q,NegDom[r]});};
 add(0);for(msk u=prot;u;u&=u-1)add(u&-u);
 for(auto e:pp)if(!(e&~prot))add(e);
 for(unsigned i=1;i<sets.size();i++)for(unsigned j=0;j<i;j++){
   const auto&a=sets[i];const auto&b=sets[j];if(a.r&b.r)continue;msk held=a.r|b.r,needed=0;NN off{};
   for(int e=0;e<np;e++)if(pp[e]&held){
     auto forbidden=both(cu[cp[e]],NegDom[pp[e]&~held]);if(nonempty(forbidden)){needed|=1u<<e;also(off,forbidden);}
   }
   auto eligible=[&](const ArmSet&r){msk allow=r.p;auto bad=both(off,r.n);
     for(msk z=r.p;z;z&=z-1){int e=countr_zero(z);if(overlaps(bad,fd[e]))allow^=1u<<e;}return allow;};
   msk aok=eligible(a),bok=eligible(b);if(needed&~(aok|bok))continue;
   for(msk u=aok;u;u&=u-1){int x=countr_zero(u);msk B=bok&~((b.p>>x&1)?dom[x]:0);
     for(msk v=B;v;v&=v-1){int y=countr_zero(v);if(x==y)continue;msk A=aok&~((a.p>>y&1)?dom[y]:0);
       if((A>>x&1)&&!(needed&~(A|B)))return false;}}
 }
 return true;
}
