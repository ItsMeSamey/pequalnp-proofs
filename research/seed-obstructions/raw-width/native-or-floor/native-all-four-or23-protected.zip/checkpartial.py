from vertexdelete import bits,P,N,extend
from itertools import combinations
from functools import cache
from pathlib import Path
import json
bank=(129,4160);rows=json.loads(Path('partial-ledger.json').read_text());idx={a[0]:a[1] for a in rows};assert len(idx)==len(rows)
def validate(s,owned):
    a=tuple(c&s for c in bank if (c&s).bit_count()>1);ps=sorted(p for p in P if not p&~s)
    ns=sorted({n&s for n in N})
    def extras(v):return sum(1<<(20+i)for i,c in enumerate(a)if c&v)
    PP=[p|extras(p)for p in ps];NN=[n|extras(n)for n in ns]
    assert all(any(not p&q for p in ps) for q in bits(owned))
    def coverneg(p,private):return sum(1<<j for j,n in enumerate(NN)if not (p&~private)&~n)
    @cache
    def obligation(held):
        bad=0;yes=0
        for i,p in enumerate(PP):
            neg=coverneg(p,held)
            if neg:yes|=1<<i;bad|=neg
        return yes,bad
    assert obligation(owned)[0]
    parts=[0,*bits(owned),*(p for p in ps if not p&~owned)]
    dom=[coverneg(p,owned)for p in PP]
    below=[sum(1<<i for i,p in enumerate(PP) if not (p&~owned)&~y)for y in PP]
    pos={r:sum(1<<i for i,p in enumerate(ps)if not r&~p) for r in parts}
    neg={r:sum(1<<i for i,n in enumerate(ns)if not r&~n) for r in parts}
    for r,t in combinations(parts,2):
        if r&t:continue
        req,denied=obligation(r|t)
        def grant(v):
            return sum(1<<i for i in range(len(ps))if (pos[v]>>i&1)and not (dom[i]&neg[v]&denied))
        A,B=grant(r),grant(t)
        if req&~(A|B):continue
        for x in bits(A):
            i=x.bit_length()-1
            BB=B&~(below[i]if pos[t]&x else 0)
            for y in bits(BB&~x):
                j=y.bit_length()-1
                AA=A&~(below[j]if pos[r]&y else 0)
                assert not (AA&x and not req&~(AA|BB)),(s,owned,r,t,i,j)
for s,L,k,*d in rows:
    if k=='z':assert L==0;continue
    if k=='d':
        q=d[0];assert q in bits(s)
        if len(d)==3:
            _,p,n=d;assert p in P and not p&~s and p&q and n in N and any(not v&~s and not v&q for v in P)
            z=q|sum(1<<(20+i)for i,c in enumerate(bank)if c&s==q)
            assert not (extend(p,s,bank)&~z)&~extend(n,s,bank)
        else:assert len(d)==1
        assert L<=idx[s^q]+(len(d)==3)
    else:
        assert k=='h' and len(d)==1;owned=d[0];assert owned and not owned&~s
        assert all(idx[s^q]>=L-2 for q in bits(owned))
        validate(s,owned)
assert idx[1048575^58]==19
from vertexdelete import nexts
s=1048575
for q in (2,8,16,32):
    assert any(row[0]==q for row in nexts(s,bank));s^=q
print(len(rows),'states,',sum(r[2]=='h'for r in rows),'protected-OR exclusions, 19 core plus four genuine refunds = 23.')
