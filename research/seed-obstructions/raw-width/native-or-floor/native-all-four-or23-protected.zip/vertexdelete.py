from pathlib import Path
from functools import cache
from sample import samples
R,front,target=samples(Path('L-meta-18968.json'))
P=tuple(sorted({v&1048575 for i,v in enumerate(R)if (target&~front)>>i&1}))
N=tuple(sorted({v&1048575 for i,v in enumerate(R)if not target>>i&1}))
def bits(mask):return [1<<i for i in range(mask.bit_length())if mask>>i&1]
def extend(x,alive,bank):
    return (x&alive)|sum(1<<(20+j) for j,c in enumerate(bank) if x&alive&c)
def nexts(alive,bank):
  pp=[p for p in P if not p&~alive]
  for q in bits(alive):
    keep=alive^q;rest=[p for p in pp if not p&q]
    if not rest or not any(p&q for p in pp):continue
    if (len(rest)>1 and sum(1 for v in bits(keep) if any(p&v for p in rest))!=keep.bit_count()):continue
    # The raw q and existing pure duplicates which vanish entirely are clamped.
    Z=q|sum(1<<(20+j)for j,c in enumerate(bank)if c&alive==q)
    for p in pp:
      if not p&q:continue
      pos=extend(p,alive,bank)
      n=next((v for v in N if not (pos&~Z)&~extend(v,alive,bank)),None)
      if n is not None:
        yield q,p,n,keep;break
def find(alive,bank,final=None):
  @cache
  def dfs(s):
    if final==s or (final is None and s.bit_count()==2 and s in P):return ()
    for q,p,n,k in nexts(s,bank):
      if final and q&final:continue
      path=dfs(k)
      if path is not None:return ((q,p,n),)+path
    return None
  return dfs(alive)
if __name__=='__main__':
 for bank in ((),(129,),(4160,),(129,4160)):
   alive=(1<<20)-1; path=find(alive,bank);assert len(path)==18
   print(bank,len(path),path)
   for q,p,n in path:alive ^= q
   print('final',alive)
