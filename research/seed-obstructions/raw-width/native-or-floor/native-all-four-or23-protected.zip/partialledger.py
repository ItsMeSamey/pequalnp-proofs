import struct,json
from pathlib import Path
from vertexdelete import P,N,bits,extend
table=Path('partial-table.bin').read_bytes();L=table[:65536];wm=struct.unpack('=65536i',table[65536:])
raw=bits(1048575^58);bank=(129,4160);memo={}
def physical(s):return sum(q for i,q in enumerate(raw)if s>>i&1)
def add(s):
 if s in memo:return
 v=physical(s);ps=sorted(p for p in P if not p&~v);typ=wm[s]
 if typ==-100:ent=['z']
 elif typ==-1:
    k=[i for i,q in enumerate(raw)if s>>i&1 and L[s^(1<<i)]+2>=L[s] and any(p&q for p in ps) and any(not p&q for p in ps)]
    ent=['h',sum(raw[i]for i in k)]
    for i in k:add(s^(1<<i))
 else:
    i=typ%16;q=raw[i];ent=['d',q];add(s^(1<<i))
    if typ>=16:
       z=q|sum(1<<(20+j)for j,c in enumerate(bank)if v&c==q)
       p,n=next((p,n)for p in ps if p&q for n in N if not (extend(p,v,bank)&~z)&~extend(n,v,bank));ent+= [p,n]
 memo[s]=[v,L[s],*ent]
add(65535)
Path('partial-ledger.json').write_text(json.dumps(sorted(memo.values()),separators=(',',':'))+'\n')
print(len(memo),sum(z[2]=='h'for z in memo.values()),'partial first-OR cuts')
