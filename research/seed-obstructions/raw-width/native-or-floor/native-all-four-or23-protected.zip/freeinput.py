from vertexdelete import *
from itertools import combinations
a=bits(((1<<20)-1)^58)
def convert(v):return sum(1<<i for i,r in enumerate(a)if v&r)
p=sorted({convert(r)for r in P if not r&58});n=sorted({convert(r)for r in N});native=[1<<i for i in range(len(a))]+list(map(convert,(129,4160)))
sig=lambda x:sum(1<<i for i,z in enumerate(p)if z&x)
hs=sorted({x|y for x,y in combinations(native,2)if sig(x)&~sig(y) and sig(y)&~sig(x) and (x|y)not in native})
with Path('freecore.in').open('w')as f:
 for z in (p,n,native[-2:],[0]+hs):print(len(z),*z,file=f)
print('H',len(hs),'real',len(p),len(n))
