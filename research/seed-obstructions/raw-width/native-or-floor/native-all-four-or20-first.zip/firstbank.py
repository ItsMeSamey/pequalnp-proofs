from vertexdelete import *
from itertools import combinations
bank=(129,4160);full=(1<<20)-1;nonprivate=full^58
def C6(S):
 for xx in combinations(bits(S&8191),3):
  for yy in combinations(bits(S&~8191),3):
   g=sum(xx+yy);es=[r for r in P if not r&~g]
   if len(es)!=6 or any(sum(bool(r&v)for r in es)!=2 for v in xx+yy):continue
   maxi={n&g for n in N};ns={n for n in maxi if not any(n!=m and not n&~m for m in maxi)}
   if len(ns)!=5:continue
   yield g
def census():
 for z in range(14,9,-1):
  for vs in combinations(bits(nonprivate),z):
   S=sum(vs)
   if any((S&c).bit_count()>1 for c in bank):continue
   ps=[p for p in P if not p&~S]
   if any(sum(bool(p&q)for p in ps)<2 for q in vs):continue
   neg={n&S for n in N}
   pair={}
   for i,x in enumerate(vs):
    for y in vs[:i]:
     for a,b in [(x,y),(y,x)]:
      for p in ps:
       if not p&a:continue
       t=p^a
       n=next((n for n in neg if not (b|t)&~n),None)
       if n is not None:pair[x,y]=[a,b,p,n];break
      if (x,y)in pair:break
   if len(pair)!=z*(z-1)//2:continue
   targets=list(C6(S));pivs={}
   n1={q:(p,n)for q,p,n,k in nexts(S,bank)}
   for q in vs:
    if q not in n1:break
    for t in targets:
     if t&q:continue
     path=find(S^q,bank,t)
     if path is not None:pivs[q]=[t,((q,*n1[q]),)+path];break
    else:break
   if len(pivs)!=z:continue
   outer=find(full,bank,S)
   if outer is None:continue
   from json import dumps
   print(z,S,len(ps),len(targets),outer,flush=True)
   Path('firstbank.json').write_text(dumps(dict(S=S,outer=outer,pivs=pivs,distinguish=list(pair.values())),indent=1)+'\n')
   return
 raise RuntimeError('no core')
if __name__=='__main__':census()
