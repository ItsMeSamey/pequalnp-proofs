from vertexdelete import *
from itertools import combinations
from json import loads
from coreorsat import test
data=loads(Path('firstbank.json').read_text());S=data['S'];allraw=(1<<20)-1;bank=(129,4160)
def pathcheck(s,path):
    for q,p,n in path:
        assert (q,p,n,s^q)in nexts(s,bank)
        s^=q
    return s
assert pathcheck(allraw,data['outer'])==S and S.bit_count()==14
vs=bits(S);ps=[p for p in P if not p&~S]
assert all(sum(bool(q&p)for p in ps)>=2 for q in vs)
assert all((S&k).bit_count()<=1 for k in bank)
assert all(any(n&q for n in N) for q in vs)
covered=set()
for a,b,p,n in data['distinguish']:
 assert a!=b and a in vs and b in vs and p in ps and p&a and n in {z&S for z in N}
 assert not (b|(p^a))&~n
 covered.add(tuple(sorted((a,b))))
assert covered==set(combinations(vs,2))
tested=set()
for q in vs:
 t,path=data['pivs'][str(q)];assert q==path[0][0] and pathcheck(S,path)==t and t.bit_count()==6
 if t in tested:continue
 tested.add(t)
 pos=[p for p in P if not p&~t];ng={n&t for n in N};neg=[n for n in ng if not any(n!=m and not n&~m for m in ng)]
 assert len(neg)==5 and len(pos)==6 and all(sum(bool(p&k) for p in pos)==2 for k in bits(t))
 # Check the actual projection includes every maximal independent set directly.
 ind={s for s in range(64) if not any(all(s>>bits(t).index(k)&1 for k in bits(p))for p in pos)}
 maxi={m for m in ind if not any(v!=m and not m&~v for v in ind)}
 assert {sum(q for j,q in enumerate(bits(t))if m>>j&1)for m in maxi}==set(neg)
 assert not test(pos,neg,4) and test(pos,neg,5)
print(len(ps),'edges,',len(covered),'distinguished pairs,',len(vs),'first deletion paths,',len(tested),'distinct complete C6 tests')
