from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from io import BytesIO
from hashlib import sha256
import json, subprocess, sys

base=Path(__file__).resolve().parent
for line in (base/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split()
    assert sha256((base/name).read_bytes()).hexdigest()==digest, name
def pkt(name): return ZipFile(base/name)
def nested(packet,name):return ZipFile(BytesIO(packet.read(name)))
def lines(packet,key):return packet.read(key).splitlines()
def records(packet,key):
    arr=lines(packet,key);result=set(arr);assert len(arr)==len(result);return result
def map_inputs(z,fn,mapname):
    inputs=lines(z,fn)
    group=json.loads(z.read(mapname))
    assert len(group)==int(inputs[3])==len(inputs)-4
    keys=set()
    for members in group:
        assert members
        for m in members:
            key=('K '+' '.join(map(str,m))).encode()
            assert key not in keys
            keys.add(key)
    return keys
def check(z,script):
    with TemporaryDirectory() as d:
        z.extractall(d, [n for n in z.namelist() if not (script=="check.py" and n=="receipt.log")])
        subprocess.run([sys.executable,script],cwd=d,check=True)

paired=pkt('native-unrestricted-paired-or14-frontier.zip')
p=nested(paired,'native-or14-raw-singleton-repair-bank3.zip')
low=pkt('native-or14-paired-low6500.zip');high=pkt('paired14-high2378.zip');add=pkt('native-or14-paired-repair48.zip')
assert low.read('pairedtriple.in')==high.read('pairedtriple.in')==add.read('pairedtriple.in')
assert p.read('final3-K.rows')==add.read('pairedrepairdep/final.rows')
assert p.read('added3-K.rows')==add.read('pairedrepairdep/added.rows')
old=map_inputs(low,'pairedtriple.in','pairedtriple.map')
new=map_inputs(add,'pairfullrepair.in','pairfullrepair.map')
assert old.isdisjoint(new) and old|new==records(p,'final3-K.rows') and (len(old),len(new))==(45059,7658)
original=set(lines(low,'pairedtriple.in')[4:])
supp=set(lines(add,'pairfullrepair.in')[4:])
assert len(original)==8878 and len(original|supp)==8926 and supp-original==set(lines(add,'pairfinalnovel.in')[4:])
check(low,'pairedlowverify.py');check(high,'check.py');check(add,'pairrepairverify.py')

single=pkt('native-unrestricted-single-or15.zip')
s=nested(single,'native-or14-raw-singleton-repair-bank1.zip')
a=nested(single,'native-or14-single7-17-suffix.zip');d=nested(single,'native-or14-single7-17-58.zip')
old1=map_inputs(a,'single7triple.in','single7triple.map');new1=map_inputs(d,'s7delta/snapfull.in','s7delta/snapfull.map')
assert old1.isdisjoint(new1) and old1|new1==records(s,'final1-K.rows') and (len(old1),len(new1))==(2218,58)
check(a,'single7suffixverify.py'); check(d,'s7deltaverify.py')
lit=pkt('native-unlimited-literal-or15.zip')
rows=[r.split() for r in lines(lit,'thirdorbit.log')[1:]]
from collections import Counter
assert len(rows)==16 and sum(int(r[-1]) for r in rows)==len(records(lit,'oo3safe.rows'))==306
assert Counter(int(r[-3]) for r in rows)=={384:8,640:3,16896:5}
print('Literal 306/16; single 2276/369+28; paired 52717/8926. All inventory joins checked.')
