# At least fifteen OR gates on four native banks

Every binary monotone AND/OR DAG separating the signed native residual chart with literals alone (bank 0), either optional transverse pair (banks 7 and 17), or both pairs (bank 115) uses at least fifteen OR gates. The number of AND gates, their fanout, and sharing are unrestricted. The certificate concerns this native chart and these four input banks. It gives no individual circuit of size 33 or 34.

Unzip this packet and run `python allfour_or15.py`. SHA256SUMS identifies every source packet. The dispatcher checks their integrity, equality of the prefix and suffix input sets, the three paired range receipts and both single-bank suffix receipts. The stored audit.log is the output of a clean dispatch replay. Each constituent packet contains its source and instructions for regenerating the computational stages.

| Native bank | Ordered prefix records | Signed unordered inventories | Suffix |
| --- | ---: | ---: | --- |
| 0 | 306 two-OR records | 16 ordered orbit representatives | 12 residual ORs; 8, 3, and 5 representative pairs in the three files |
| 7, 17 | 2,276 three-OR records on bank 7, transported to 17 | 369 initial and 28 supplemental inventories | 11 residual ORs |
| 115 | 52,717 three-OR records | 8,926 | 11 residual ORs. The initial 8,878 split at 6,500. The repair contributes 48 additional inventories. |

The paired unrestricted prefix reproduced every corrected physical record after removing both AND-budget tests. At the third OR, all four genuine native grade-one raw signals are eligible; their 468-negative signatures and the signed compound inputs are preserved. The single-bank unrestricted test also restores its four grade-one raw inputs. The literal prefix grants all 28 signed-clean singleton operands as an extra relaxation.

For early stopping with up to two noncollector ORs, the possible multi-incidence clean outputs are conjunctions of the available prefix ORs and at most one native raw. All other clean outputs can be granted as individual incidences. The early-stop tests grant a single terminal covering the union of all available multiedge clean terms, yet need at least 25 distinct terminals. Combining that many independent terminals would require at least 24 binary collector ORs. This uses no bound on the number of clean ANDs. The OR-preserving cleanup selecting the earliest live clean term is included in the prefix archives.

The free suffix kernels close the supplied raw/prefix wires under arbitrary conjunctions. They branch on future ORs, using negative-row cover and clean-term bounds to reject candidates. Solver depth measures further ORs. Frontier width ceilings cause an open result and a forwarded case whenever the frontier remains positive. The low and high range ledgers require a terminating exact zero for every case, including all forwarded cases. For partial-depth extinctions the independent unconditional fourteen-OR lower bound precludes a separator ending sooner; the represented prefix inputs are physically constructible using their recorded OR count and free ANDs. Both-pair inputs supply the two actual compound primitives throughout. The tight-row clean-DNF source and previous unconditional fourteen-OR certificate are included.

The high-range source archive includes a descriptive receipt.log whose name matches its checker's broad r*.log pattern. The dispatcher skips only that human-readable file when extracting into a temporary directory to run the unchanged checker. All actual numeric rNNNN.log inputs are preserved, and the immutable source archive itself is hash-verified.
