from itertools import combinations
from pathlib import Path
import sys
from zipfile import ZipFile
with ZipFile(sys.argv[1]) as z:
    m={};exec(compile(z.read('sample.py'),'sample.py','exec'),m)
rows,front,target=m['samples'](Path(sys.argv[2]))
P=sorted({r&1048575 for i,r in enumerate(rows) if (target&~front)>>i&1 and not r&58})
N=sorted({(r&1048575)&~58 for i,r in enumerate(rows) if not target>>i&1})
for comp in [(),(129,),(4160,),(129,4160)]:
    prim=[1<<i for i in range(20) if not (1<<i)&58]+list(comp)
    def vector(x):
        return sum(1<<i for i,s in enumerate(prim) if s&x)
    pos=list(map(vector,P));neg=list(map(vector,N))
    for a,b in combinations(pos,2):
        assert any((a&b)&~n==0 for n in neg)
    stars=[sum(e&8191 for e in P if e>>(13+t)&1) for t in range(7)]
    covers=[]
    for tags in range(128):
        req=0
        for t in range(7):
            if not tags>>t&1:req|=stars[t]
        for k in range(1<<len(comp)):
            used=0
            for j,x in enumerate(comp):
                if k>>j&1:used|=x
            covers.append((tags.bit_count()+k.bit_count()+(req&~used).bit_count(),tags<<13|used|(req&~used)))
    costs=[min(c for c,s in covers if not s&n) for n in N]
    tight=max(costs)
    critical=[n for n,c in zip(neg,costs) if c==tight]
    arms=set()
    for p in pos:
        a=p
        while a:
            if all(a&~n for n in critical):arms.add(a)
            a=(a-1)&p
    print(comp,tight,len(critical),len(arms), sorted({sum(1<<i for i,p in enumerate(pos) if a&~p==0) for a in arms}))
    if len(comp)!=2:continue
    from functools import lru_cache
    full=(1<<len(pos))-1
    signals=[sum(1<<i for i,p in enumerate(pos) if p>>j&1) for j in range(len(prim))]
    def trace(a):
        return sum(1<<i for i,p in enumerate(pos) if not a&~p)
    available=[tuple(s for j,s in enumerate(signals) if not n>>j&1) for n in critical]
    @lru_cache(None)
    def mincover(j,mask):
        if not mask:return 0
        bit=mask&-mask
        return 1+min(mincover(j,mask&~s) for s in available[j] if s&bit)
    retained=set()
    for a,b in combinations(arms,2):
        y=trace(a)|trace(b)
        if all(mincover(j,full&~y)<=9 for j in range(len(critical))):retained.add(y)
    print('paired distinct first traces paying all 18 critical rows',len(retained),sorted(retained))
