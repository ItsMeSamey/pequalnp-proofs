from pathlib import Path
from itertools import combinations
from collections import Counter
from zipfile import ZipFile
import sys
with ZipFile(sys.argv[1]) as z:
    M={};exec(compile(z.read('sample.py'),'sample.py','exec'),M)
rows,front,target=M['samples'](Path(sys.argv[2]))
P=sorted({r&1048575 for i,r in enumerate(rows) if (target&~front)>>i&1})
N=sorted({r&1048575 for i,r in enumerate(rows) if not target>>i&1})
priv=[p for p in range(13) if sum(bool(e>>p&1) for e in P)==1]
assert priv==[1,3,4,5]
for length in range(5):
 for subset in combinations(priv,length):
    mask=sum(1<<p for p in subset);pos=[e for e in P if not e&mask];neg=sorted({e&~mask for e in N})
    assert all(any(not ((next(e for e in P if e>>p&1)&~(1<<p))&~n) for n in neg) for p in priv)
    stars=[sum(e&8191 for e in pos if e>>(13+t)&1) for t in range(7)]
    costs=[]
    for pairs in [(),(129,),(4160,),(129,4160)]:
        hist=Counter()
        for n in neg:
            best=21
            for tags in range(128):
                if n&(tags<<13):continue
                req=0
                for t in range(7):
                    if not tags>>t&1:req|=stars[t]
                if n&req:continue
                for choice in range(1<<len(pairs)):
                    used=0
                    for j,x in enumerate(pairs):
                        if choice>>j&1:used|=x
                    if not used&n:best=min(best,tags.bit_count()+choice.bit_count()+(req&~used).bit_count())
            hist[best]+=1
        costs.append((max(hist),hist[max(hist)]))
    print(mask,len(pos),len(neg),costs)
