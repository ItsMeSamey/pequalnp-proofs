import json,re
from pathlib import Path
s=json.loads(Path('L-meta-18968.json').read_text())['formal_statement']
blocks=re.findall(r'\[((?:\(\d+ : ℕ\)(?:, )?)+)\]',s)
seeds=[int(''.join(w.zfill(19) for w in re.findall(r'\((\d+) : ℕ\)',b))) for b in blocks]
front,target=[int(re.search(r'x1 \('+str(j)+r' : ℕ\) = \((\d+) : ℕ\)',s)[1]) for j in (54,88)]
rows=[set(),set()]
for i in range(676):
 def source(k,shift):
  return seeds[k]>>(13*(i//13)+(i%13-shift)%13)&1
 p=sum(source(0,j)<<j for j in range(13))
 u=sum(source(1,j+6)<<j for j in range(7))
 if front>>i&1:
  assert target>>i&1
  continue
 rows[1-(target>>i&1)].add((p,u))
ref=list(map(int,Path('native.in').read_text().split())); assert ref[:2]==[28,468]
pairs=list(zip(ref[2::2],ref[3::2]))
assert rows==[set(pairs[:28]),set(pairs[28:])]
print('676 rows reconstructed, projected 28/468; native.in exact')
from sample import samples
ws,_,_=samples(Path('L-meta-18968.json'))
for i,r in enumerate(ws):
 p=r&8191
 assert (r>>29&1)==bool(p&4160) and (r>>30&1)==bool(p&129)
print('physical slots 29,30 match 4160,129 on all 676')
