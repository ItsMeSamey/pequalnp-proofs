set -eu
python dual13verify.py
python dualexport.py > fresh.rows
cmp fresh.rows dual.or.rows
for f in or-standard34.txt or-nine38.txt grid676-00.txt; do python oracle676.py L-meta-18968.json "$f"; done
/tmp/syn-verify-or14-sub 13 1 0 969 0 5000 <dual.or.rows
/tmp/syn-verify-or14-sub 13 8 762 763 1000 1006 <dual.or.rows > fresh762.log
cmp fresh762.log dual13deep/1000.log
/tmp/syn-verify-or14-sub 13 8 0 1 0 10000 <dual.or.rows
