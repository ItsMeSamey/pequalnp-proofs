set -eu
here=$PWD
cd /workspace/scratch/syn_dual/fourlow/slack
tail -n+2 "$here/thirdorbit.log" | while read ix x y h j mul;do
 if test "$(tail -n1 "$here/suffix-$h-$j.log" 2>/dev/null || true)" = "3 0";then continue;fi
 flock -w 60 -F /workspace/scratch/pnp-native-search.lock nice -n15 timeout 15s prlimit --as=209715200 --cpu=12 -- bash -c 'set -e -o pipefail; { cat dual.or.rows; python -c "from literalh640 import *;print(*encode($1),*encode($2))"; } | /tmp/syn_dual_h640 12 7' _ "$h" "$j" > "$here/suffix-$h-$j.log"
done
