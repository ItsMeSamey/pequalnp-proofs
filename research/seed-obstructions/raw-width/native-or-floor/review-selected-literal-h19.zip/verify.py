from itertools import permutations,combinations
from pathlib import Path
from collections import Counter
v=list(map(int,Path('native.in').read_text().split()))[2:]
rows=[p|t<<13 for p,t in zip(v[::2],v[1::2])]
E=set(rows[:28]); N=set(rows[28:]); tags=[1<<j for j in range(13,20)];pts=[1<<i for i in range(13)];raw=pts+tags
hood={p:frozenset(t for t in tags if p|t in E) for p in pts}
by={h:p for p,h in hood.items()};maps=[]
for tp in permutations(tags):
 m=dict(zip(tags,tp)); hh={p:frozenset(m[t] for t in h) for p,h in hood.items()}
 if not all(h in by for h in hh.values()):continue
 m.update({p:by[h] for p,h in hh.items()});tr=lambda r:sum(y for x,y in m.items() if x&r)
 if {tr(n) for n in N}==N:maps.append(m)
assert len(maps)==24
d=Path('.')
keep=Path('thirdwide0.keep')
h={int(r[0]):int(r[1])|int(r[2])for s in (d/'thirdwide0.log').read_text().splitlines()if(r:=s.split())}
pairs=set()
for s in keep.read_text().splitlines():
 ix,u,v,p,sm=map(int,s.split())
 assert u<20 and v<20 and sm==(1<<u|1<<v) and not(sm&h[ix])
 pairs.add((h[ix],sm))
orbits=Counter()
for a,b in pairs:
 sig=min((sum(y for x,y in m.items() if x&a),sum(y for x,y in m.items() if x&b))for m in maps)
 orbits[sig]+=1
assert sum(orbits.values())==306 and len(orbits)==16
ref={(int(x[3]),int(x[4])):int(x[5]) for line in (d/'thirdorbit.log').read_text().splitlines()[1:] if(x:=line.split())}
assert ref==orbits
print('signed transports on all 468 negative patterns: 24; 306/16',Counter(a for a,b in orbits))
# raw-only clean leaves are individual incidences; with H, any further AND with two distinct raw factors
# is still below the corresponding singleton incidence. Other possible multis are H AND one raw.
n=0;mini=28
for a,b in combinations(raw,2):
 A={e for e in E if e&a}; B={e for e in E if e&b}
 if A<=B or B<=A:continue
 n+=1;m=a|b
 multi=[{e for e in E if e&m and e&r} for r in raw if not any(x&m and x&r for x in N)]
 multis=[x for x in multi if len(x)>1]; assert len(multis)<=1
 mini=min(mini,28-sum(len(x)-1 for x in multis))
print('first count',n,'minimum collector leaves after one OR',mini);assert (n,mini)==(186,27)
