from pathlib import Path
from itertools import combinations
r=list(map(int,Path('native.in').read_text().split()))[2:]
P,N=([x|y<<13 for x,y in zip(r[i:j:2],r[i+1:j:2])] for i,j in [(0,56),(56,len(r))])
src=Path('/workspace/scratch/syn_quotients/native8parallel')
def op(x,y,both):return tuple(a&b if both else a|b for a,b in zip(x,y))
for b in range(4):
 v=list(map(int,(src/f'aug{b}.in').read_text().split()));nr,nn=v[:2]
 rs=v[2:2+nr]; hard=set(v[-nn:]); sel=sum(1<<i for i,n in enumerate(N) if n in hard)
 bases=[(sum(1<<i for i,e in enumerate(P) if e&m),sum(1<<i for i,n in enumerate(N) if n&m),m) for m in rs]
 legal=list(map(int,(src/f'augallow{b}.in').read_text().split()));idx=0
 for i,a in enumerate(bases):
  for c in bases[:i]:
   if a[0]&c[0] in (a[0],c[0]):continue
   h=op(a,c,0);srcs=bases+[h]+[op(h,z,1) for k,z in enumerate(bases) if legal[idx]>>k&1]
   for u,w in combinations(srcs,2):
    j=op(u,w,0)
    if j[0] not in (u[0],w[0]) and j[0]==h[0] and j[2]==h[2] and not((j[1]^h[1])&sel):assert j==h
   idx+=1
 for a,c in combinations(bases,2):
  z=op(a,c,1)
  if z[0].bit_count()>=2:assert z in bases
 print(b,idx,'true-H exclusion and multiedge raw meets exact')
