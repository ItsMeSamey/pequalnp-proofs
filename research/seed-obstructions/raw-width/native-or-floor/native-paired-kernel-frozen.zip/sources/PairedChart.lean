import PairedDelete

namespace TightRow.Paired
open TightRow.Deletion
universe u v w
variable {S : Type u} {R : Type v} {X : Type w}

/-- Apply physical paired rebates to positive and negative chart obligations.
Positive and negative transports may choose separate original witnesses. -/
theorem signedDelete {T : Type*} {k} (t : Tape S k) (g : S → Set X)
    (v : T → Set R) (ρ : S → Option T) {P N : Set X} {P' N' : Set R}
    (fits : Fits t g P N) {p n : X} (yes : p ∈ P) (no : n ∈ N)
    (order : ∀ i j, ρ i = some j → p ∈ g i → n ∈ g i) (live : P'.Nonempty)
    (up : ∀ x ∈ P', ∃ a ∈ P, Below g a (rename ρ v) x)
    (down : ∀ x ∈ N', ∃ b ∈ N, Below (rename ρ v) x g b) :
    0 < cuts false t (rename ρ v) ∧ ∃ j, ∃ u : Tape T j,
      Fits u v P' N' ∧ j + cuts false t (rename ρ v) = k ∧
      ands u + cuts true t (rename ρ v) = ands t := by
  have acc : P' ⊆ t.eval (rename ρ v) := by
    intro x hx
    obtain ⟨a,ha,le⟩ := up x hx
    exact evaluateBelow t le (fits.1 ha)
  have rej : ∀ x ∈ N', x ∉ t.eval (rename ρ v) := by
    intro x hx high
    obtain ⟨b,hb,le⟩ := down x hx
    exact fits.2 b hb (evaluateBelow t le high)
  obtain ⟨oc,j,u,hu,oo,aa⟩ := TightRow.Paired.delete t v ρ g order (live.mono acc) (fits.1 yes) (fits.2 n no)
  exact ⟨oc,j,u,by simpa only [Fits,hu] using And.intro acc rej,oo,aa⟩

#print axioms TightRow.Paired.signedDelete
end TightRow.Paired
