import PairedTally

namespace TightRow.Paired
open TightRow.Deletion
universe u v
variable {S : Type u} {R : Type v}

/-- Zero propagation at the original physical sites produces one simultaneous
realization with all the counted OR and AND rebates. -/
theorem trim {k} (t : Tape S k) (f : S → Set R) (B : Bank R)
    (av : ∀ i, Avail B (f i)) (live : (t.eval f).Nonempty) :
    ∃ o h, Paid B (t.eval f) o h ∧ o + cuts false t f = k ∧ h + cuts true t f = ands t := by
  induction t generalizing B with
  | output i =>
    obtain z | v := av i
    · change (f i).Nonempty at live
      simp [z] at live
    · exact ⟨0,0,.output v,rfl,rfl⟩
  | andGate a b t ih =>
    by_cases za : f a = ∅
    · obtain ⟨o,h,p,oo,aa⟩ := ih _ B (extendAvail av (Or.inl (by simp [za]))) live
      exact ⟨o,h,p,by simpa [cuts] using oo,by simp [cuts,hit,za,ands] at aa ⊢ <;> omega⟩
    by_cases zb : f b = ∅
    · obtain ⟨o,h,p,oo,aa⟩ := ih _ B (extendAvail av (Or.inl (by simp [zb]))) live
      exact ⟨o,h,p,by simpa [cuts] using oo,by simp [cuts,hit,zb,ands] at aa ⊢ <;> omega⟩
    obtain ⟨o,h,p,oo,aa⟩ := ih _ _ (growAvail av _) live
    refine ⟨o,h+1,.andGate ((av a).resolve_left za) ((av b).resolve_left zb) p,?_,?_⟩
    · simpa [cuts] using oo
    · simp [cuts,hit,za,zb,ands] <;> omega
  | orGate a b t ih =>
    by_cases za : f a = ∅
    · obtain ⟨o,h,p,oo,aa⟩ := ih _ B (extendAvail av (by simpa [za] using av b)) live
      exact ⟨o,h,p,by simp [cuts,hit,za] at oo ⊢ <;> omega,by simpa [cuts,ands] using aa⟩
    by_cases zb : f b = ∅
    · obtain ⟨o,h,p,oo,aa⟩ := ih _ B (extendAvail av (by simpa [zb] using av a)) live
      exact ⟨o,h,p,by simp [cuts,hit,zb] at oo ⊢ <;> omega,by simpa [cuts,ands] using aa⟩
    obtain ⟨o,h,p,oo,aa⟩ := ih _ _ (growAvail av _) live
    refine ⟨o+1,h,.orGate ((av a).resolve_left za) ((av b).resolve_left zb) p,?_,?_⟩
    · simp [cuts,hit,za,zb] <;> omega
    · simpa [cuts,ands] using aa

end TightRow.Paired
