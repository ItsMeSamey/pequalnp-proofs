import PairedTally

namespace TightRow.Paired
open TightRow.Deletion
universe u v w
variable {S : Type u} {R : Type v} {X : Type w}

/-- At any point in the restricted run, each saved wire either vanished or
preserves comparison on the original two rows. -/
private abbrev Ordered (f : S → Set R) (g : S → Set X) (p n : X) :=
  ∀ i, f i = ∅ ∨ (p ∈ g i → n ∈ g i)

private theorem grow {f : S → Set R} {g : S → Set X} {p n : X}
    (old : Ordered f g p n) {x : Set R} {y : Set X} (new : x = ∅ ∨ (p ∈ y → n ∈ y)) :
    Ordered (extend f x) (extend g y) p n
  | none => new
  | some i => old i

/-- A signed deletion witness forces one or more physical OR cuts counted
on the very same tape as the AND rebates. -/
theorem orCut {k} (t : Tape S k) (f : S → Set R) (g : S → Set X) {p n : X}
    (old : ∀ i, f i = ∅ ∨ (p ∈ g i → n ∈ g i)) (live : (t.eval f).Nonempty)
    (yes : p ∈ t.eval g) (no : n ∉ t.eval g) : 0 < cuts false t f := by
  induction t with
  | output i =>
    rcases old i with zi | order
    · change (f i).Nonempty at live
      simp [zi] at live
    · exact (no (order yes)).elim
  | andGate a b t ih =>
    have good : (f a ∩ f b) = ∅ ∨ (p ∈ g a ∩ g b → n ∈ g a ∩ g b) := by
      rcases old a with za | aa
      · exact Or.inl (by simp [za])
      rcases old b with zb | bb
      · exact Or.inl (by simp [zb])
      exact Or.inr (fun h => ⟨aa h.1,bb h.2⟩)
    simpa [cuts] using
      ih _ _ (grow old good) live yes no
  | orGate a b t ih =>
    by_cases z : f a = ∅ ∨ f b = ∅
    · simp [cuts,hit,z]
    have aa := (old a).resolve_left (fun e => z (Or.inl e))
    have bb := (old b).resolve_left (fun e => z (Or.inr e))
    have good : (f a ∪ f b) = ∅ ∨ (p ∈ g a ∪ g b → n ∈ g a ∪ g b) :=
      Or.inr (fun h => h.elim (fun ha => Or.inl (aa ha)) (fun hb => Or.inr (bb hb)))
    simpa [cuts,hit,z] using ih _ _ (grow old good) live yes no

end TightRow.Paired
