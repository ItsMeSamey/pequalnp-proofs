import PairedTrim
import PairedWitness

namespace TightRow.Paired
open TightRow.Deletion
universe u v w
variable {S : Type u} {R : Type v} {X : Type w}

/-- One restricted typed DAG realizes the exact denotation simultaneously with
both rebates, and the original signed deletion witness forces a positive OR
rebate. The raw reindexing may be noninjective. -/
theorem delete {T : Type*} {k} (t : Tape S k) (v : T → Set R) (ρ : S → Option T)
    (g : S → Set X) {p n : X}
    (order : ∀ i j, ρ i = some j → p ∈ g i → n ∈ g i)
    (live : (t.eval (rename ρ v)).Nonempty) (yes : p ∈ t.eval g) (no : n ∉ t.eval g) :
    0 < cuts false t (rename ρ v) ∧ ∃ j, ∃ u : Tape T j,
      u.eval v = t.eval (rename ρ v) ∧ j + cuts false t (rename ρ v) = k ∧
      ands u + cuts true t (rename ρ v) = ands t := by
  have av (i : S) : Mark (Set.range v) (rename ρ v i) (p ∈ g i → n ∈ g i) := by
    cases h : ρ i with
    | none => exact Or.inl (by simp [rename,h])
    | some j => exact Or.inr ⟨⟨j,by simp [rename,h]⟩,order i j h⟩
  refine ⟨orCut t _ g (fun i => (av i).imp id And.right) live yes no,?_⟩
  obtain ⟨j,h,net,oo,aa⟩ := trim t _ _ (fun i => (av i).imp id And.left) live
  obtain ⟨u,hu,ct⟩ := net.toTape v (fun _ h => h)
  exact ⟨j,u,hu,oo,by simpa only [ct] using aa⟩

#print axioms TightRow.Paired.delete
end TightRow.Paired
