import DeletionRefund

namespace TightRow.Paired
open TightRow.Deletion
universe u v
variable {S : Type u} {R : Type v}

/-- Counts the actual AND allocations in a typed tape. Its index already counts ORs. -/
def ands {S : Type u} {k} : Tape S k → Nat
  | .output _ => 0
  | .andGate _ _ tail => ands tail + 1
  | .orGate _ _ tail => ands tail

open Classical in
/-- A gate reads a zero column on the restricted chart. Even if it reads the
same zero address twice, this physical allocation contributes only one. -/
noncomputable def hit (a b : Set R) : Nat := if a = ∅ ∨ b = ∅ then 1 else 0

/-- Count the physical sites of one selected kind with a zero restricted
operand. The new column is propagated with its exact denotation. -/
noncomputable def cuts (countAnd : Bool) {S : Type u} {k} :
    (t : Tape S k) → (S → Set R) → Nat
  | .output _, _ => 0
  | .andGate a b t, f =>
    cuts countAnd t (extend f (f a ∩ f b)) + (if countAnd then hit (f a) (f b) else 0)
  | .orGate a b t, f =>
    cuts countAnd t (extend f (f a ∪ f b)) + (if countAnd then 0 else hit (f a) (f b))

/-- The same shared-bank allocation discipline as Physical, with separate exact
costs for ORs and ANDs, in that order. -/
inductive Paid : Bank R → Set R → Nat → Nat → Prop where
  | output {B z} : z ∈ B → Paid B z 0 0
  | andGate {B a b z o h} : a ∈ B → b ∈ B →
      Paid (insert (a ∩ b) B) z o h → Paid B z o (h+1)
  | orGate {B a b z o h} : a ∈ B → b ∈ B →
      Paid (insert (a ∪ b) B) z o h → Paid B z (o+1) h

private theorem liftSupply {v : S → Set R} {B : Bank R}
    (supply : ∀ s ∈ B, ∃ i, v i = s) (z : Set R) :
    ∀ s ∈ insert z B, ∃ i, extend v z i = s := by
  intro s hs
  rcases Set.mem_insert_iff.mp hs with rfl | h
  · exact ⟨none,rfl⟩
  obtain ⟨i,hi⟩ := supply _ h
  exact ⟨some i,hi⟩

theorem Paid.toTape {B : Bank R} {z o h} (p : Paid B z o h)
    (v : S → Set R) (supply : ∀ x ∈ B, ∃ i, v i = x) :
    ∃ t : Tape S o, t.eval v = z ∧ ands t = h := by
  induction p generalizing S with
  | output hv =>
    obtain ⟨i,hi⟩ := supply _ hv
    exact ⟨.output i,hi,rfl⟩
  | @andGate B a b z o h ha hb p ih =>
    obtain ⟨i,rfl⟩ := supply _ ha
    obtain ⟨j,rfl⟩ := supply _ hb
    obtain ⟨t,ht,ct⟩ := ih _ (liftSupply supply (v i ∩ v j))
    exact ⟨.andGate i j t,ht,congrArg (· + 1) ct⟩
  | @orGate B a b z o h ha hb p ih =>
    obtain ⟨i,rfl⟩ := supply _ ha
    obtain ⟨j,rfl⟩ := supply _ hb
    obtain ⟨t,ht,ct⟩ := ih _ (liftSupply supply (v i ∪ v j))
    exact ⟨.orGate i j t,ht,ct⟩

end TightRow.Paired
