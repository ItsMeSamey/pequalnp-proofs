# Simultaneous physical rebates under a zero restriction

The input is the original gate tape. Its type index counts OR allocations, and `ands` counts AND allocations. Each binary gate in this tape is one physical site for both purposes, including gates used by many later operands.

For a new interpretation of the physical inputs, `cuts true` counts AND gates with at least one input identically zero on the restricted chart. `cuts false` counts the corresponding OR gates. Intermediate values are evaluated on the new interpretation at their actual back-references. A repeated zero input contributes one at its gate.

`trim` uses each surviving reference in its original order. At a zero-input AND, the new reference denotes zero. At a zero-input OR, it aliases the other input. Both-nonzero gates can always be copied physically, even when their references coincide. A nonempty output ensures that a physical expression can materialize the final wire even if the new bank supplies no false constant. In particular this construction can leave additional redundant gates.

`orCut` uses a separated original pair of rows to force a positive OR rebate. The witnesses compare in the retained direction at every input with nonzero restricted interpretation. Through each AND, either a zero propagates or the comparison persists. Through each OR with two nonzero inputs the comparison persists as well. A nonempty restricted output and a separated original output therefore force an OR with a zero restricted input.

`delete` combines these facts. Given any partially defined raw index map (including aliases) and the signed witnesses, one actual child DAG has exactly the original OR and AND counts minus the respective rebate counts. This statement applies to any original tape and imposes no minimality. To obtain a specific positive AND rebate from it, one must prove that the indicated number of actual AND sites reads a zero in the restriction. The finite chart floor of 23 ORs and this local theorem do not establish the proposed joint tradeoff.
