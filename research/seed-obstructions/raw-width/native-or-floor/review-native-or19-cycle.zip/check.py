import ast
from pathlib import Path
v=list(map(int,Path('native.in').read_text().split()))[2:];rs=[a|b<<13 for a,b in zip(v[::2],v[1::2])];P,N=rs[:28],rs[28:]
chain=ast.literal_eval(Path('edgecore.log').read_text().split(') ',1)[1])
S=(1<<20)-1
def ex(r,S):
 x=r&S
 return x|int(bool(x&129))<<20|int(bool(x&4160))<<21
for j,(q,p,n) in enumerate(chain):
 assert not q&(q-1) and q&S and p in P and not p&~S and n in N and q&p
 doomed=q|(int(S&129==q)<<20)|(int(S&4160==q)<<21)
 assert not ex(p,S)&~ex(n,S)&~doomed
 assert any(not r&~(S&~q) for r in P)
 for r in N:assert not ex(r,S&~q)&~(ex(r,S)&~doomed)
 for r in P:
  if not r&~(S&~q):assert ex(r,S&~q)==ex(r,S)
 S&=~q
assert len(chain)==14 and S==663621
pos=sorted(ex(r,S) for r in P if not r&~S);ne={ex(r,S) for r in N};neg=sorted(n for n in ne if not any(n!=z and not n&~z for z in ne))
assert list(map(int,Path('core6.in').read_text().split()))==[6,5,*pos,*neg,1]
# Independent signed-state search. Cut at paid OR outputs. Canonically saturate each AND operand.
np=len(pos);F=(1<<np)-1;Nmask=(1<<len(neg))-1
raw=tuple(sorted({(sum(1<<i for i,r in enumerate(pos) if r>>j&1),sum(1<<i for i,r in enumerate(neg) if r>>j&1))for j in range(22)}))
def closure(extra):
 bank=raw+extra;s={F}
 for a,_ in bank:s|={m&a for m in s}
 out={}
 for a in s:
  nb=Nmask
  for c,d in bank:
   if not a&~c:nb&=d
  out[a]=nb
 return out
states={()}
for k in range(6):
 if any(closure(st).get(F)==0 for st in states):
  print(k,'SAT');assert k==5;break
 print(k,'no success',len(states),flush=True)
 assert k<5
 nxt=set()
 for st in states:
  ops=list(closure(st).items())
  # Final step: directly test every pair with one full-positive low conjunction after adding their union.
  for i,(a,n) in enumerate(ops):
   for b,m in ops[:i]:
    p=a|b
    if p in (a,b):continue
    w=(p,n|m)
    if k==4:
     if p!=F:continue
     if not ((n|m)&closure(st)[F]):
      print('5 SAT explicit',st,w);raise SystemExit
     continue
    if k==3 and p!=F:continue
    if k==3:
     if ((n|m)&closure(st)[F])==0:raise AssertionError('4 OR success')
     continue
    if w not in st and w not in raw:nxt.add(tuple(sorted((*st,w))))
 if k==3:
  # SAT-5 independently checked below via a clean physical construction.
  print('4 UNSAT exhaustive')
  break
 states=nxt
tags=[q for q in [1<<j for j in range(13,20)]if S&q]
stars=[sum({p&8191 for p in pos if p&t})for t in tags]
assert all(x.bit_count()==2 for x in stars) and all(any(r&t and r&m for t,m in zip(tags,stars)) for r in pos) and not any(r&t and r&m for t,m in zip(tags,stars) for r in neg)
print('5 SAT: three 2-point stars and two collection ORs')
