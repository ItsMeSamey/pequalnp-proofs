Fresh d727e86e full 186 and 306 byte-identical; early 38685 byte-identical.
