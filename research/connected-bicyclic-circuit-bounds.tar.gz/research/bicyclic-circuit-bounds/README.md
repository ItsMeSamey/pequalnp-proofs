# Monotone circuit bounds for connected bicyclic graphs

Let G be a finite, simple, bipartite graph without a four-cycle. Write m for its number of edges and ν for its maximum matching size. If G is connected and bicyclic, every binary monotone circuit computing its edge predicate on the full Boolean cube uses at least m−1 physical OR gates and at least ν physical AND gates. Thus its total size is at least m+ν−1. If G has a perfect matching of size n, this specializes to m+n−1. This is a mathematical research result. It has no Lean kernel receipt.

Both gate counts are sharp when minimized separately: disjoining all edge products uses m−1 OR gates, and grouping the edges into stars at a minimum bipartite vertex cover uses at most ν AND gates by König's theorem. These upper constructions need not be the same circuit.

* [Classification and attachments](classification-and-attachments.md) reduces the lower bounds to a cactus or a bare theta. It includes arbitrary attached trees, detached forests after a restriction, and isolates.
* [Cacti](cactus.md) proves both bounds by a terminal-cycle induction, including its bare even-cycle base for the theta argument.
* [Theta OR gates](theta-or.md) covers both path parities. It treats a direct pole edge, a length-two arm, and the single forbidden-pair restriction.
* [Theta AND gates](theta-and.md) handles three odd arms and three even arms separately. The lower bound for a bare even cycle used there follows from the cactus proof.

A circuit is a directed acyclic graph with unrestricted sharing. Each paid gate is counted once. Lower bounds for the two operations may use different restrictions because each applies to the same original circuit. This packet settles the connected bicyclic class; a graph with further independent cycles is outside that assertion.
