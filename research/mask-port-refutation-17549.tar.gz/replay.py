import json
from pathlib import Path
base=Path(__file__).resolve().parent
control=json.loads((base/'control.json').read_text())
inputs=[2147418115,663661903884,34144976944,728266375360,21653750532,103293914128,26322415680,344922804352,414195942664,581968119809,1065151898146,371245215936,582520731713,1066477318818,549755842560,728266404032]
baseline=28864
high=1099511562240
values=inputs.copy()
dirty=[]
for op,a,b in control['bank']:
    assert 0<=min(a,b) and max(a,b)<len(values)
    w=values[a]&values[b] if op else values[a]|values[b]
    if op: dirty.append([len(values),w,w&high])
    values.append(w)
taps=[]
answer=baseline
for a,b in control['taps']:
    assert 0<=min(a,b) and max(a,b)<len(values)
    w=values[a]&values[b]
    taps.append(w)
    assert w&high==0
    answer|=w
cost=len(control['bank'])+2*len(taps)
assert len(dirty)==1 and dirty[0][-1]!=0 and answer==65535 and cost==16
print(json.dumps(dict(cost=cost,baseline=baseline,bank=values[16:],dirty=dirty,taps=taps,output=answer)))
