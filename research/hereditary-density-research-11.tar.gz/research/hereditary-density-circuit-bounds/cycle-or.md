# OR complexity of unicyclic edge functions

Count physical OR gates in a trimmed monotone binary circuit, allowing arbitrary AND gates and sharing. For an essential input v, let its frontier consist of the first OR on each path from v to the output. If setting v to zero leaves a nonzero function, every path hits an OR: an AND-only path would force the output to zero. Restriction forces a zero at one operand of every frontier OR, so all these gates can be replaced by the other operand or by zero, in topological order. Constant folding adds no ORs. Thus deleting a leaf while any edge survives saves at least one OR. Removing endpoints down to one edge shows that a path on t vertices requires at least t−2 ORs.

## A cycle forces a double frontier

For a cycle of length h≥5 take an OR-minimal trimmed circuit. Suppose all frontiers are singletons. The earliest OR g has two AND-only monomial operands. Their combined support S has at least two vertices, since otherwise g is a redundant alias. For each vertex in S there is an AND-only prefix ending at g; since its frontier is a singleton, every path from that vertex to the output passes g. Cutting g and supplying a fresh bit there leaves no path from S inputs to the output. In any fixed outside context the output depends on S only through g.

If S is the entire cycle, the output is a nonconstant monotone unary function of g, hence equals g. This is impossible: g has at most two minimal positive assignments, whereas the cycle has h. Otherwise at least two elements a,b of S neighbor the outside. If there were only one, deleting it would disconnect the remaining elements of S from the outside, although deleting any one cycle vertex leaves a path. For each boundary vertex a, activate just an outside neighbor and compare the S assignments empty and singleton a. The output changes from false to true. Thus g accepts singleton a, so one of its two monomials is the singleton a. The same holds for b. Both operands are thereby determined, and S={a,b}. As g takes the same value on either singleton, a and b must have identical outside neighborhoods. If adjacent this would force a triangle; if nonadjacent it would force a four-cycle. Both are impossible in a cycle of length h≥5.

Therefore some vertex has at least two frontier ORs. Setting it to zero removes both and leaves a path on h−1 vertices, proving the lower bound 2+(h−3)=h−1 ORs.

## Extension to the issued family

Peeling any attached trees or disconnected forest components removes one pendant edge per step and charges one more OR, while the cycle survives. Forget isolated coordinates by setting them to zero. Hence a graph whose only cycle has length at least five needs at least |E|−1 ORs. For a partial corona with a direct leaf and a perfect matching, parity forces that matching to be unique. Combining with the separate triangular n-AND inequality for that same unrestricted circuit yields n+|E|−1 total gates.
