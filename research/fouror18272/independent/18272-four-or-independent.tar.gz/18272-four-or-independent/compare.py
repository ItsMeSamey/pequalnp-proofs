"""Compare directly computed per-shard statistics to the pinned producer index."""
from pathlib import Path
from hashlib import sha256
import json
import re
import tarfile

base = Path(__file__).resolve().parent
archive = Path('/dev/shm/18272-four-or-producer-only.tar.gz')
def need(test):
    if not test:
        raise ValueError("receipt mismatch")
need(sha256(archive.read_bytes()).hexdigest()=='c223da52e146b59de44f9d214ba8d30aa9216ea703dc343dbe699f352cb7c51a')
with tarfile.open(archive) as t:
    archived=t.extractfile('fouror18272-stage/producer-index.json').read()
expected=json.loads(archived)
issued=Path('/tmp/pnp-official-18272-issued.lean').read_bytes()
need(sha256(issued).hexdigest()=='9ec4bd7fce25977e79676fd87f567c30812b34f80a264e9df1a9aeb6d972f84b')
raw=list(map(int,re.findall(r'\((\d+) : ℕ\)',issued.decode().split('x5 ↑x7 = [')[1].split('].getD')[0])))
encoded=re.search(r'inputs\{([^}]+)',(base/'replay.cpp').read_text()).group(1)
need(raw==list(map(int,encoded.split(','))))
first=sorted({a|b for i,a in enumerate(raw) for b in raw[:i]})
rows={}
ends={}
for f in base.glob('S*.tsv'):
    for ln in f.read_text().splitlines():
        w=ln.split()
        if w[0]=='end':
            shard,lo,hi,n=map(int,w[1:])
            need(0<=shard<55 and 0<=lo<=hi and n>=0 and ends.setdefault(shard,n)==n)
        else:
            need(w[0]=='second')
            shard,i,n3,n4,hits=map(int,w[1:])
            need(0<=shard<55 and i>=0 and n3>=0 and n4>=0 and hits==0 and (shard,i) not in rows)
            rows[shard,i]=n3,n4
output=[]
for f,e in enumerate(expected):
    need(f==e['first'] and e['first_mask']==first[f])
    if f not in ends or not all((f,i) in rows for i in range(ends[f])):
        continue
    need({i for k,i in rows if k==f}==set(range(ends[f])))
    value=[rows[f,i] for i in range(ends[f])]
    n3=sum(v[0] for v in value); n4=sum(v[1] for v in value)
    need((ends[f],n3,n4,0)==(e['second_prefixes'],e['third_leaves'],e['fourth_states'],e['hits']))
    output.append(dict(first=f,first_mask=first[f],second_prefixes=ends[f],third_leaves=n3,
                       raw_fourths=n4,signed_adjustment=0,hits=0,reviewed=True,receipt_sha256_text=e['sha256_text']))
print(json.dumps(output,indent=1))
