#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
umask 077
ulimit -t 6
ulimit -v 32768
ulimit -f 512
lo=$1
hi=$2
exec nice -n 15 flock -n /workspace/scratch/pnp-native-search.lock /usr/bin/python3 -B timed.py "batch-$lo-$hi.time" timeout 8 /usr/bin/python3 -B batched.py "$lo" "$hi"
