import resource, subprocess, time, sys
from pathlib import Path
start=time.monotonic()
p=subprocess.run(sys.argv[2:])
r=resource.getrusage(resource.RUSAGE_CHILDREN)
Path(sys.argv[1]).write_text(f'elapsed_seconds={time.monotonic()-start:.6f} user_seconds={r.ru_utime:.6f} system_seconds={r.ru_stime:.6f} max_rss_kib={r.ru_maxrss} returncode={p.returncode}\n')
sys.exit(p.returncode)
