"""Enforce the aggregate per-tranche CPU limit even across separate shard processes."""
import math
from pathlib import Path
import resource
import subprocess
import sys

lo,hi=map(int,sys.argv[1:])
for shard in range(lo,hi):
    own=resource.getrusage(resource.RUSAGE_SELF)
    children=resource.getrusage(resource.RUSAGE_CHILDREN)
    used=sum(x.ru_utime+x.ru_stime for x in (own,children))
    capacity=math.floor(6.0-used-0.05)
    if capacity<1:
        sys.exit('CPU budget prevents another shard')
    def guard():
        resource.setrlimit(resource.RLIMIT_CPU,(capacity,capacity))
    with Path(f'S{shard}.tsv').open('x') as f:
        subprocess.run(['./replay',str(shard),'0','10000'],stdout=f,check=True,preexec_fn=guard)
