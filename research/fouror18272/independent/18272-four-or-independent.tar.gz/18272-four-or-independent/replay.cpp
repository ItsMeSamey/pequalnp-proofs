// Replay four free-AND ORs using full parent meet closure and an incremental leaf test.
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using W=std::uint64_t;
using V=std::vector<W>;
constexpr W low=65535;
constexpr std::array<W,11> inputs{2147418115,663661903884,34144976944,728266375360,
 21653750532,103293914128,26322415680,344922804352,414195942664,581968119809,1065151898146};
void check(bool p){if(!p) throw std::logic_error("check failed");}
void unique(V &s){std::sort(s.begin(),s.end());s.erase(std::unique(s.begin(),s.end()),s.end());}
V extend(const V& parent,W z){
 V s=parent;s.push_back(z);
 for(W x:parent)s.push_back(x&z);
 unique(s);return s;
}
bool mixed(W x){return (x&low)&&(x>>16);}
V choices(const V& bank){
 V mix,out;
 for(W x:bank)if(mixed(x))mix.push_back(x);
 for(size_t i=1;i<mix.size();++i)for(size_t j=0;j<i;++j)out.push_back(mix[i]|mix[j]);
 unique(out);
 V diff;std::set_difference(out.begin(),out.end(),bank.begin(),bank.end(),std::back_inserter(diff));return diff;
}
// Enumerate chosen nonsingleton masks in increasing index order, completing with singleton taps.
bool subset(const V& taps,const V& suffix,size_t start,W missing,int budget){
 if(std::popcount(missing)<=budget)return true;
 if(budget==0||start==taps.size()||std::popcount(missing&~suffix[start])>=budget)return false;
 for(size_t i=start;i<taps.size();++i)
   if(std::popcount(missing&taps[i])>=2 && subset(taps,suffix,i+1,missing&~taps[i],budget-1))return true;
 return false;
}
bool cover(V& taps,W universe=low,int budget=7){
 unique(taps);V suffix(taps.size()+1);
 for(size_t i=taps.size();i>0;--i)suffix[i-1]=suffix[i]|taps[i-1];
 return subset(taps,suffix,0,universe,budget);
}
struct Leaf {
 V old,maybe,scratch;
 W old_union=0;
 explicit Leaf(const V& bank){
  for(W w:bank){
    if(std::popcount(w&low)<2)continue;
    if(w>>16)maybe.push_back(w);
    else{old.push_back(w);old_union|=w;}
  }
 }
 bool accepts(W z){
   // New intersections with formerly clean masks are subsets of those masks.
   // Record all remaining new clean multirow taps; singleton taps always exist.
   W joined=old_union; scratch.clear();
   for(W w:maybe){
      W x=w&z;
      if((x>>16)==0 && (x&(x-1))){joined|=x;scratch.push_back(x);}
   }
   if(std::popcount(joined)<=9)return false; // eight or more compulsory singleton costs, or 7 + another tap
   scratch.insert(scratch.end(),old.begin(),old.end());return cover(scratch);
 }
};
bool allowed(W candidate,W prior,const V& before){
 return candidate>=prior || !std::binary_search(before.begin(),before.end(),candidate);
}
int main(int argc,char** argv){
 V base;for(W x:inputs)base=extend(base,x);
 for(int i=0;i<16;++i)check(std::binary_search(base.begin(),base.end(),W(1)<<i));
 V first=choices(base);check(first.size()==55);
 if(argc==2 && std::string(argv[1])=="--controls"){
   // Compare projected leaf bank against fully materialized closure on sample prefixes.
   for(W p:{first.front(),first.back()}){
    V bank=extend(base,p);
    for(W q:choices(bank)){
     V b=extend(bank,q); Leaf leaf(b);
     for(W z:choices(b)){
      V all=extend(b,z),t;
      for(W v:all)if(v<=low&&std::popcount(v)>1)t.push_back(v);
      check(leaf.accepts(z)==cover(t));
      break;
     }
    }
   }
   V positive; for(int i=0;i<14;i+=2)positive.push_back(W(3)<<i);
   positive.back()|=W(3)<<14;check(cover(positive));positive.pop_back();check(!cover(positive));
   std::cout<<"controls pass\n";return 0;
 }
 check(argc==4);
 int shard=std::stoi(argv[1]),lo=std::stoi(argv[2]),hi=std::stoi(argv[3]);
 check(0<=shard&&shard<55&&0<=lo&&lo<=hi);
 W p=first[shard];V bank1=extend(base,p),second=choices(bank1);
 int sec=0;
 for(W q:second){
   if(!allowed(q,p,first))continue;
   int idx=sec++;if(idx<lo||idx>=hi)continue;
   V bank2=extend(bank1,q),third=choices(bank2);
   unsigned long long n3=0,n4=0,hits=0;
   for(W r:third){
     if(!allowed(r,p,first)||!allowed(r,q,second))continue;
     ++n3;
     V bank3=extend(bank2,r),fourth=choices(bank3);
     Leaf leaf(bank3);
     for(W z:fourth){
       if(!allowed(z,p,first)||!allowed(z,q,second)||!allowed(z,r,third))continue;
       ++n4;
       if(leaf.accepts(z)){++hits;std::cout<<"hit "<<shard<<" "<<p<<" "<<q<<" "<<r<<" "<<z<<std::endl;}
     }
   }
   std::cout<<"second "<<shard<<" "<<idx<<" "<<n3<<" "<<n4<<" "<<hits<<std::endl;
 }
 std::cout<<"end "<<shard<<" "<<lo<<" "<<hi<<" "<<sec<<std::endl;
}
