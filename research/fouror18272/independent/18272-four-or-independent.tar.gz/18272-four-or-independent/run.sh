#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
umask 077
export TMPDIR="$PWD"
ulimit -f 512
if [[ "$1" == compile ]]; then
    ulimit -v 262144
    ulimit -t 10
    exec nice -n 15 flock -n /workspace/scratch/pnp-native-search.lock /usr/bin/python3 -B timed.py compile.time timeout 15 g++ -pipe -O3 -mpopcnt -std=c++20 replay.cpp -o replay
fi
ulimit -v 32768
ulimit -t 8
if [[ "$1" == pilot ]]; then
    exec nice -n 15 flock -n /workspace/scratch/pnp-native-search.lock /usr/bin/python3 -B timed.py S0.time timeout 12 bash -ec './replay --controls > controls.log && ./replay 0 0 10000 > S0.tsv'
fi
id="S$1-$2-$3"
[[ ! -e "$id.tsv" ]]
exec nice -n 15 flock -n /workspace/scratch/pnp-native-search.lock /usr/bin/python3 -B timed.py "$id.time" timeout 12 ./replay "$1" "$2" "$3" >"$id.tsv"
