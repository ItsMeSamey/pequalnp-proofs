import IncidenceGroupLabelGraph
import IncidenceGroupTopEndpoints
import IncidenceGroupStarLabels
import IncidenceGroupRestore

namespace IncidenceGroupPhysicalFiveSixths
open SparseIncidence IncidenceStartNormalization IncidenceRobust
open IncidenceGroupPlaneTests IncidencePhysicalOrGroups IncidenceGroupPhysicalDemand
variable {n : ℕ}

/-- The five-sixths count uses precisely the ordinary labels of R and actual
terminal OR rows. Incidence, all reader slots, and all mask tests use C itself. -/
theorem demand (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (R : Finset (Vertex n)) (pos : flags C I) (neg3 : negatives C I 3 3)
    (cg : ∀x y,x≠y→(adj I x∩adj I y).card≤1) (degree : ∀x∈R,2<(adj I x).card)
    (two : ∀x∈R,uses C (wireId x)=2)
    (ports : ∀x∈R,∀g b,Reads C g (wireId x) b→(C.code g).op=.join) :
    5*R.card≤6*(tops C).card := by
  classical
  obtain ⟨A,B,_,opposite,isol,inj⟩ := IncidenceGroupTopEndpoints.physical C I R pos neg3 cg degree two ports
  obtain ⟨G,ds,reps,edge_count,vertex_count⟩ := IncidenceGroupLabelGraph.count A B isol inj
  letI := ds
  let N (e : ↥R) := Finset.univ.filter (fun f : ↥R => f.val∈adj I e.val)
  have sy (e f : ↥R) (h : f∈N e) : e∈N f :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _,symm I _ _ (Finset.mem_filter.mp h).2⟩
  have cg' (e f : ↥R) (ne : e≠f) : (N e ∩ N f).card≤1 := by
    apply le_trans _ (cg e.val f.val (fun h=>ne (Subtype.ext h)))
    apply Finset.card_le_card_of_injOn Subtype.val
    · intro z hz
      obtain ⟨he,hf⟩ := Finset.mem_inter.mp hz
      exact Finset.mem_inter.mpr ⟨(Finset.mem_filter.mp he).2,(Finset.mem_filter.mp hf).2⟩
    · exact fun _ _ _ _ h=>Subtype.ext h
  have cross (x y z : ↥R) (xy : x≠y) (xz : x≠z)
      (a : A x=A y ∨ A x=B y) (b : B x=A z ∨ B x=B z) : z∈N y :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _,opposite x y z xy xz a b⟩
  let k : ↥(IncidenceGroupLabelGraph.kept A B) ↪ ↥(tops C) :=
    ⟨Subtype.val,Subtype.val_injective⟩
  have represented (u v : ↥(IncidenceGroupLabelGraph.kept A B)) (uv : G.Adj u v) :
      ∃e : ↥R,IncidenceGroupStarLabels.Spans k A B e u v := by
    obtain ⟨e,h⟩ := (reps u v).mp uv
    exact ⟨e.val,h⟩
  have bound := IncidenceGroupGraph.density_with_isolated_loops G (IncidenceGroupLabelGraph.loops A B).card
    (IncidenceGroupStarLabels.high G k A B represented N sy cross cg')
    (IncidenceGroupStarLabels.noHighEdge G k A B represented N sy cross cg')
  simpa only [Fintype.card_coe,edge_count,vertex_count] using bound
end IncidenceGroupPhysicalFiveSixths
#print axioms IncidenceGroupPhysicalFiveSixths.demand
