import IncidenceGroupCrossPhysical
namespace IncidenceGroupTopEndpoints
open SparseIncidence IncidenceStartNormalization IncidenceRobust IncidenceGroupCrossPhysical
open IncidenceGroupPlaneTests IncidencePhysicalOrGroups IncidenceGroupPhysicalDemand
variable {n : ℕ}

theorem physical (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (R : Finset (Vertex n)) (pos : flags C I) (neg3 : negatives C I 3 3)
    (cg : ∀x y,x≠y→(adj I x∩adj I y).card≤1) (degree : ∀x∈R,2<(adj I x).card)
    (two : ∀x∈R,uses C (wireId x)=2)
    (ports : ∀x∈R,∀g b,Reads C g (wireId x) b→(C.code g).op=.join) :
    ∃ A B : ↥R→↥(tops C),
      (∀(x : ↥R) g,Member C (wireId x.val) g ↔ g=(A x).val ∨ g=(B x).val) ∧
      (∀ x y z : ↥R,x≠y→x≠z→(A x=A y ∨ A x=B y)→(B x=A z ∨ B x=B z)→z.val∈adj I y.val) ∧
      (∀x y,A x=B x→(A x=A y ∨ A x=B y)→x=y) ∧
      Function.Injective (fun x=>Sym2.mk (A x) (B x)) := by
  classical
  obtain ⟨a,b,atRow⟩ := endpoints C R two ports
  have top {x : ↥R} {g} (m : Member C (wireId x.val) g) : g∈tops C := by
    obtain ⟨_,_,_,_,_,t⟩ := m
    simpa [tops] using t
  let A (x : ↥R) : ↥(tops C) := ⟨a x,top ((atRow x _).mpr (Or.inl rfl))⟩
  let B (x : ↥R) : ↥(tops C) := ⟨b x,top ((atRow x _).mpr (Or.inr rfl))⟩
  have physical (x y z : ↥R) (xy : x≠y) (xz : x≠z)
      (oa : A x=A y ∨ A x=B y) (ob : B x=A z ∨ B x=B z) : z.val∈adj I y.val := by
    exact cross C I pos neg3 cg x y z (fun h=>xy (Subtype.ext h)) (fun h=>xz (Subtype.ext h))
      (degree x x.property) (ports x x.property) (a x) (b x) (fun g m=>(atRow x g).mp m)
      ((atRow y _).mpr (oa.imp (congrArg Subtype.val) (congrArg Subtype.val)))
      ((atRow z _).mpr (ob.imp (congrArg Subtype.val) (congrArg Subtype.val)))
  have noPair (x y : ↥R) (ne : x≠y) (u : A x=A y ∨ A x=B y) (v : B x=A y ∨ B x=B y) :=
    loop I y.val (physical x y y ne ne u v)
  refine ⟨A,B,atRow,physical,?_,?_⟩
  · intro x y lp one
    by_contra ne
    exact noPair x y ne one (lp ▸ one)
  · intro x y eq
    by_contra ne
    rcases Sym2.eq_iff.mp eq with k|k
    · exact noPair x y ne (Or.inl k.1) (Or.inr k.2)
    · exact noPair x y ne (Or.inr k.1) (Or.inl k.2)
end IncidenceGroupTopEndpoints
