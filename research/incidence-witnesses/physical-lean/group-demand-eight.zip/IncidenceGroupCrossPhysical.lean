import IncidenceGroupPhysicalDemand
import Mathlib.Data.Sym.Sym2
namespace IncidenceGroupCrossPhysical
open SparseIncidence IncidenceStartNormalization IncidenceRobust IncidenceGroupDemand
open IncidenceGroupPlaneTests IncidencePhysicalOrGroups IncidenceGroupPhysicalDemand
variable {n : ℕ} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

theorem cross (pos : flags C I) (neg3 : negatives C I 3 3)
    (cg : ∀x y,x≠y→(adj I x∩adj I y).card≤1)
    (x y z : Vertex n) (xy : x≠y) (xz : x≠z) (degree : 2<(adj I x).card)
    (ports : ∀g b,Reads C g (wireId x) b→(C.code g).op=.join)
    (a b : Row C) (covers : ∀g,Member C (wireId x) g→g=a ∨ g=b)
    (left : Member C (wireId y) a) (right : Member C (wireId z) b) : z∈adj I y := by
  classical
  by_contra no
  have miss : ¬adj I x⊆(adj I x ∩ adj I y) ∪ (adj I x ∩ adj I z) := by
    intro h
    have t := (Finset.card_le_card h).trans (Finset.card_union_le ..)
    have l := cg x y xy
    have r := cg x z xz
    omega
  obtain ⟨t,tx,absent⟩ := Finset.not_subset.mp miss
  have ty : t∉adj I y := fun h=>absent (Finset.mem_union_left _ (Finset.mem_inter.mpr ⟨tx,h⟩))
  have tz : t∉adj I z := fun h=>absent (Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨tx,h⟩))
  let S : Finset (Vertex n) := {y,z,t}
  have small : S.card≤3 := by
    have h := Finset.card_insert_le y ({z,t} : Finset (Vertex n))
    have k := Finset.card_insert_le z ({t} : Finset (Vertex n))
    simp only [Finset.card_singleton] at k
    dsimp only [S]; omega
  have negS := neg I C neg3 S small (by
    intro u hu v hv
    simp only [S,Finset.mem_insert,Finset.mem_singleton] at hu hv
    rcases hu with rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl <;>
      first | exact loop I _ | assumption | exact fun h=>no (symm I _ _ h) |
        exact fun h=>ty (symm I _ _ h) | exact fun h=>tz (symm I _ _ h))
  have posS := up I C pos S x ⟨t,by simp [S],tx⟩
  have rawOut : wireId x≠C.output := by
    intro eq
    have hot := (raw C {x} x).mpr (Finset.mem_singleton_self x)
    rw [eq] at hot
    apply neg I C neg3 {x} (by simp) _ hot
    intro u hu v hv
    obtain rfl := Finset.mem_singleton.mp hu
    obtain rfl := Finset.mem_singleton.mp hv
    exact loop I _
  apply shield C (mask (insert x S)) (mask S) (wireId x) rawOut _ ports _ (fun h=>negS (h.mp posS))
  · intro i hi d
    obtain ⟨u,rfl⟩ := raw_split hi
    by_cases eq : u=x
    · rw [eq]
    exact (d (by simp [raw,Finset.mem_insert,eq])).elim
  · intro g mg d
    have stable {v : Vertex n} {w : Row C} (vs : v∈S) (mem : Member C (wireId v) w) :
        mask (insert x S)∈C.wire (wire C w) ↔ mask S∈C.wire (wire C w) :=
      iff_of_true (member_hot C mem ((raw C _ _).mpr (Finset.mem_insert_of_mem vs)))
        (member_hot C mem ((raw C _ _).mpr vs))
    rcases covers g mg with rfl|rfl
    · exact d (stable (by simp [S]) left)
    · exact d (stable (by simp [S]) right)

theorem endpoints (R : Finset (Vertex n)) (two : ∀x∈R,uses C (wireId x)=2)
    (ports : ∀x∈R,∀g b,Reads C g (wireId x) b→(C.code g).op=.join) :
    ∃A B : ↥R→Row C, ∀(x : ↥R) g,Member C (wireId x.val) g↔g=A x ∨ g=B x := by
  classical
  have H (x : ↥R) := route_all C (wireId x.val) (two x x.property) (ports x x.property)
  choose A B hA hB covers using H
  exact ⟨A,B,fun x g=>⟨covers x g,fun h=>h.elim (fun e=>e ▸ hA x) (fun e=>e ▸ hB x)⟩⟩

variable {C I} {R : Finset (Vertex n)} {A B : ↥R→Row C}

theorem isolated (distinct : ∀x y : ↥R,x≠y→
    (A x=A y ∨ A x=B y)→(B x=A y ∨ B x=B y)→False)
    {x y : ↥R} (same : A x=B x) (touch : A x=A y ∨ A x=B y) : x=y := by
  by_contra ne
  exact distinct x y ne touch (same ▸ touch)

theorem edge_injective (distinct : ∀x y : ↥R,x≠y→
    (A x=A y ∨ A x=B y)→(B x=A y ∨ B x=B y)→False) :
    Function.Injective (fun x : ↥R=>Sym2.mk (A x) (B x)) := by
  intro x y eq
  by_contra ne
  rcases Sym2.eq_iff.mp eq with h|h
  · exact distinct x y ne (Or.inl h.1) (Or.inr h.2)
  · exact distinct x y ne (Or.inr h.1) (Or.inl h.2)

theorem no_double (pos : flags C I) (neg3 : negatives C I 3 3)
    (cg : ∀x y,x≠y→(adj I x∩adj I y).card≤1)
    (degree : ∀x∈R,2<(adj I x).card)
    (ports : ∀x∈R,∀g b,Reads C g (wireId x) b→(C.code g).op=.join)
    (ends : ∀(x : ↥R) g,Member C (wireId x.val) g↔g=A x ∨ g=B x)
    (x y : ↥R) (ne : x≠y) (atA : A x=A y ∨ A x=B y) (atB : B x=A y ∨ B x=B y) : False := by
  have xy : x.val≠y.val := fun eq=>ne (Subtype.ext eq)
  exact loop I y.val (cross C I pos neg3 cg x y y xy xy (degree x x.property)
    (ports x x.property) (A x) (B x) (fun g h=>(ends x g).mp h)
    ((ends y _).mpr atA) ((ends y _).mpr atB))
end IncidenceGroupCrossPhysical
#print axioms IncidenceGroupCrossPhysical.cross
#print axioms IncidenceGroupCrossPhysical.edge_injective
