import IncidenceGroupCrossPhysical
import Mathlib.Combinatorics.SimpleGraph.Finite
namespace IncidenceGroupLabelGraph
variable {E V : Type*} [Fintype E] [Fintype V] [DecidableEq V]
variable (A B : E→V)

def loops : Finset E := Finset.univ.filter (fun x=>A x=B x)
def proper : Finset E := Finset.univ.filter (fun x=>A x≠B x)
def loopVertices : Finset V := (loops A B).image A
def kept : Finset V := Finset.univ \ loopVertices A B

theorem loop_card (isol : ∀x y,A x=B x→(A x=A y ∨ A x=B y)→x=y) :
    (loopVertices A B).card=(loops A B).card := by
  apply Finset.card_image_of_injOn
  intro x hx y hy eq
  exact isol _ _ (Finset.mem_filter.mp hx).2 (Or.inl eq)

theorem away (isol : ∀x y,A x=B x→(A x=A y ∨ A x=B y)→x=y)
    (x : ↥(proper A B)) : A x.val∈kept A B ∧ B x.val∈kept A B := by
  have aux {v} (atX : v=A x.val ∨ v=B x.val) : v∈kept A B := by
    apply Finset.mem_sdiff.mpr
    refine ⟨Finset.mem_univ _,?_⟩
    intro hit
    obtain ⟨y,hy,eq⟩ := Finset.mem_image.mp hit
    have lp := (Finset.mem_filter.mp hy).2
    have same := isol y x.val lp (by rw [eq]; exact atX)
    exact (Finset.mem_filter.mp x.property).2 (same ▸ lp)
  exact ⟨aux (Or.inl rfl),aux (Or.inr rfl)⟩

theorem count (isol : ∀x y,A x=B x→(A x=A y ∨ A x=B y)→x=y)
    (inj : Function.Injective (fun x=>Sym2.mk (A x) (B x))) :
    ∃G : SimpleGraph ↥(kept A B), ∃ ds : DecidableRel G.Adj,
      letI := ds
      (∀u v : ↥(kept A B),G.Adj u v ↔ ∃x : ↥(proper A B),
        (A x.val=u.val ∧ B x.val=v.val) ∨ (A x.val=v.val ∧ B x.val=u.val)) ∧
      G.edgeFinset.card+(loops A B).card=Fintype.card E ∧
      (kept A B).card+(loops A B).card=Fintype.card V := by
  classical
  let l (x : ↥(proper A B)) : ↥(kept A B) := ⟨A x.val,(away A B isol x).1⟩
  let r (x : ↥(proper A B)) : ↥(kept A B) := ⟨B x.val,(away A B isol x).2⟩
  let pair (x : ↥(proper A B)) := Sym2.mk (l x) (r x)
  have pinj : Function.Injective pair := by
    intro x y h
    apply Subtype.ext
    apply inj
    rcases Sym2.eq_iff.mp h with h|h
    · exact Sym2.eq_iff.mpr (Or.inl ⟨congrArg Subtype.val h.1,congrArg Subtype.val h.2⟩)
    · exact Sym2.eq_iff.mpr (Or.inr ⟨congrArg Subtype.val h.1,congrArg Subtype.val h.2⟩)
  let edges := Finset.univ.image pair
  let G : SimpleGraph ↥(kept A B) := SimpleGraph.fromEdgeSet {e | e∈edges}
  refine ⟨G,inferInstance,?_⟩
  have eq : G.edgeFinset=edges := by
    ext e
    rw [SimpleGraph.mem_edgeFinset,SimpleGraph.edgeSet_fromEdgeSet]
    constructor
    · exact And.left
    · intro he
      refine ⟨he,?_⟩
      obtain ⟨x,_,rfl⟩ := Finset.mem_image.mp he
      intro diag
      have h : l x=r x := Sym2.mk_isDiag_iff.mp diag
      exact (Finset.mem_filter.mp x.property).2 (congrArg Subtype.val h)
  have part : proper A B=Finset.univ \ loops A B := by ext x; simp [proper,loops]
  have ns : loops A B⊆Finset.univ := Finset.subset_univ _
  have vs : loopVertices A B⊆Finset.univ := Finset.subset_univ _
  refine ⟨?_,?_,?_⟩
  · intro u v
    rw [SimpleGraph.fromEdgeSet_adj]
    constructor
    · rintro ⟨h,_⟩
      obtain ⟨x,_,p⟩ := Finset.mem_image.mp h
      rcases Sym2.eq_iff.mp p with k|k
      · exact ⟨x,Or.inl ⟨congrArg Subtype.val k.1,congrArg Subtype.val k.2⟩⟩
      · exact ⟨x,Or.inr ⟨congrArg Subtype.val k.1,congrArg Subtype.val k.2⟩⟩
    · rintro ⟨x,p⟩
      constructor
      · apply Finset.mem_image.mpr
        refine ⟨x,Finset.mem_univ _,Sym2.eq_iff.mpr ?_⟩
        exact p.elim (fun h=>Or.inl ⟨Subtype.ext h.1,Subtype.ext h.2⟩)
          (fun h=>Or.inr ⟨Subtype.ext h.1,Subtype.ext h.2⟩)
      · intro same
        subst v
        exact (Finset.mem_filter.mp x.property).2 (p.elim (fun h=>h.1.trans h.2.symm)
          (fun h=>h.1.trans h.2.symm))
  · trans edges.card+(loops A B).card
    · apply congrArg (fun k : ℕ=>k+(loops A B).card)
      apply congrArg Finset.card
      apply Finset.ext
      intro e
      simpa only [SimpleGraph.mem_edgeFinset] using (Finset.ext_iff.mp eq e)
    · change (Finset.univ.image pair).card+(loops A B).card=Fintype.card E
      rw [Finset.card_image_of_injective _ pinj,Finset.card_univ,Fintype.card_coe,part]
      exact (Finset.card_sdiff_add_card_eq_card ns).trans Finset.card_univ
  · rw [←loop_card A B isol]
    exact (Finset.card_sdiff_add_card_eq_card vs).trans Finset.card_univ
end IncidenceGroupLabelGraph
