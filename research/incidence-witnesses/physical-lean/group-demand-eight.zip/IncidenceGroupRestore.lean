import IncidenceGroupStrip

namespace IncidenceGroupGraph
open scoped Classical
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Assign every erased edge to one of its erased endpoints. Such a vertex had original
degree at most one, so two distinct edges cannot be assigned to it. -/
theorem leaf_charge :
    (G.edgeFinset \ (kept G).toFinset.sym2).card ≤
      ((Finset.univ : Finset V) \ (kept G).toFinset).card := by
  classical
  let erased := G.edgeFinset \ (kept G).toFinset.sym2
  let leaves := (Finset.univ : Finset V) \ (kept G).toFinset
  have endpoint (e : ↥erased) : ∃ v : ↥leaves, v.val ∈ e.val := by
    by_contra h
    apply (Finset.mem_sdiff.mp e.property).2
    apply Finset.mem_sym2_iff.mpr
    intro v hv
    by_contra outside
    exact h ⟨⟨v, Finset.mem_sdiff.mpr ⟨Finset.mem_univ _, outside⟩⟩,hv⟩
  let charge (e : ↥erased) : ↥leaves := Classical.choose (endpoint e)
  have incident (e : ↥erased) :
      e.val ∈ G.incidenceFinset (charge e).val := by
    rw [G.incidenceFinset_eq_filter]
    exact Finset.mem_filter.mpr ⟨(Finset.mem_sdiff.mp e.property).1,
      Classical.choose_spec (endpoint e)⟩
  have injective : Function.Injective charge := by
    intro e f same
    have unavailable := (Finset.mem_sdiff.mp (charge e).property).2
    have low : ¬ 2 ≤ G.degree (charge e).val := fun h => unavailable (Set.mem_toFinset.mpr h)
    have one : (G.incidenceFinset (charge e).val).card ≤ 1 := by
      rw [G.card_incidenceFinset_eq_degree]
      omega
    apply Subtype.ext
    exact Finset.card_le_one.mp one _ (incident e) _ (same.symm ▸ incident f)
  simpa only [Fintype.card_coe] using Fintype.card_le_of_injective charge injective

/-- The original simple graph plus any number of disjoint single-loop components.
The only degree assumptions apply to the original simple graph. -/
theorem density_with_isolated_loops (loops : ℕ)
    (high : ∀ v, 4 ≤ G.degree v → (survivingNeighbors G v).card ≤ 2)
    (noHighEdge : ∀ x y, 3 ≤ G.degree x → 3 ≤ G.degree y → ¬ G.Adj x y) :
    5 * (G.edgeFinset.card + loops) ≤ 6 * (Fintype.card V + loops) := by
  classical
  have induced := congrArg Finset.card (SimpleGraph.map_edgeFinset_induce (G:=G) (s:=kept G))
  rw [Finset.card_map] at induced
  have ep := Finset.card_sdiff_add_card_inter G.edgeFinset (kept G).toFinset.sym2
  have vp := Finset.card_sdiff_add_card_inter (Finset.univ : Finset V) (kept G).toFinset
  simp only [Finset.univ_inter, Finset.card_univ, Set.toFinset_card] at vp
  have density := stripped_density G high noHighEdge
  have charged := leaf_charge G
  omega

#print axioms leaf_charge
#print axioms density_with_isolated_loops
end IncidenceGroupGraph
