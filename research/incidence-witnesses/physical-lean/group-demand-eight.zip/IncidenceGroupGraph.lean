import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import Mathlib.Combinatorics.Enumerative.DoubleCounting

namespace IncidenceGroupGraph
open scoped BigOperators

/-- A degree-three vertex sends one unit to each neighbor and receives none. -/
theorem core {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (subcubic : ∀ v, G.degree v ≤ 3)
    (independent : ∀ x y, G.degree x = 3 → G.degree y = 3 → ¬G.Adj x y) :
    5 * G.edgeFinset.card ≤ 6 * Fintype.card V := by
  classical
  let R : V → V → Prop := fun x y => G.degree x = 3 ∧ G.Adj x y
  let outflow := fun x : V => (Finset.univ.bipartiteAbove R x).card
  let inflow := fun y : V => (Finset.univ.bipartiteBelow R y).card
  have balance : (∑ x, outflow x) = ∑ y, inflow y :=
    Finset.sum_card_bipartiteAbove_eq_sum_card_bipartiteBelow R
  have budget (v : V) : 5 * G.degree v + inflow v ≤ 12 + outflow v := by
    by_cases h : G.degree v = 3
    · have emits : Finset.univ.bipartiteAbove R v = G.neighborFinset v := by
        ext w
        simp [R, h, Finset.mem_bipartiteAbove]
      have empty : Finset.univ.bipartiteBelow R v = ∅ := by
        apply Finset.eq_empty_iff_forall_notMem.mpr
        intro w hw
        have hw' : G.degree w = 3 ∧ G.Adj w v := (Finset.mem_filter.mp hw).2
        exact independent w v hw'.1 h hw'.2
      simp [inflow, outflow, emits, empty, h]
    · have sub : Finset.univ.bipartiteBelow R v ⊆ G.neighborFinset v := by
        intro w hw
        have hw' : G.degree w = 3 ∧ G.Adj w v := (Finset.mem_filter.mp hw).2
        exact (G.mem_neighborFinset v w).mpr hw'.2.symm
      have recv : inflow v ≤ G.degree v := by
        simpa [inflow] using Finset.card_le_card sub
      have cap := subcubic v
      omega
  have total := Finset.sum_le_sum (s := Finset.univ) (fun v _ => budget v)
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum, G.sum_degrees_eq_twice_card_edges,
    Finset.sum_const, Finset.card_univ, nsmul_eq_mul, Nat.cast_id, balance] at total
  omega

/-- Restore at most one edge per removed leaf vertex and one edge per isolated single loop. -/
theorem restore {coreEdges coreVertices leafEdges leafVertices isolatedLoops : ℕ}
    (density : 5 * coreEdges ≤ 6 * coreVertices) (leaves : leafEdges ≤ leafVertices) :
    5 * (coreEdges + leafEdges + isolatedLoops) ≤
      6 * (coreVertices + leafVertices + isolatedLoops) := by omega

#print axioms core
#print axioms restore
end IncidenceGroupGraph
