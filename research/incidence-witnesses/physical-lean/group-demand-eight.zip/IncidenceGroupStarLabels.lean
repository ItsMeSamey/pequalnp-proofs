import IncidenceGroupStrip
import IncidenceGroupCrossPhysical

namespace IncidenceGroupStarLabels
open IncidenceGroupGraph
variable {E V H : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj] (key : V ↪ H) (A B : E→H)
def Spans (e : E) (u v : V) : Prop :=
  (A e=key u ∧ B e=key v) ∨ (A e=key v ∧ B e=key u)
def Touch (e : E) (u : V) := A e=key u ∨ B e=key u
theorem touches {e : E} {u v : V} (h : Spans key A B e u v) :
    Touch key A B e u ∧ Touch key A B e v := by
  rcases h with h|h
  · exact ⟨Or.inl h.1,Or.inr h.2⟩
  · exact ⟨Or.inr h.2,Or.inl h.1⟩
theorem reverse {e : E} {u v : V} (h : Spans key A B e u v) : Spans key A B e v u :=
  h.elim Or.inr Or.inl
theorem fan_unique {e : E} {u v w : V} (h : Spans key A B e u v)
    (j : Spans key A B e u w) : v=w := by
  apply key.injective
  rcases h with h|h <;> rcases j with j|j <;> grind

variable (represented : ∀u v,G.Adj u v → ∃e,Spans key A B e u v)
include represented in
theorem star_map (u : V) (base : E) :
    ∃ f : V→E,(∀v∈G.neighborFinset u,Spans key A B (f v) u v) ∧
      Set.InjOn f (G.neighborFinset u) := by
  classical
  let f v := if h : G.Adj u v then (represented u v h).choose else base
  have spans v (h : v∈G.neighborFinset u) : Spans key A B (f v) u v := by
    have yes := (G.mem_neighborFinset u v).mp h
    simpa [f,yes] using (represented u v yes).choose_spec
  refine ⟨f,spans,?_⟩
  intro v hv w hw eq
  exact fan_unique key A B (spans _ hv) (eq.symm ▸ spans _ hw)

variable (N : E→Finset E) (symm : ∀x y,y∈N x→x∈N y)
variable (cross : ∀x y z : E,x≠y→x≠z→
  (A x=A y ∨ A x=B y)→(B x=A z ∨ B x=B z)→z∈N y)

include cross symm in
theorem opposite {x y z : E} {u v : V} (edge : Spans key A B x u v)
    (yAt : Touch key A B y u) (zAt : Touch key A B z v) (xy : x≠y) (xz : x≠z) :
    z∈N y := by
  have atU : key u=A y ∨ key u=B y := yAt.elim (fun h=>Or.inl h.symm) (fun h=>Or.inr h.symm)
  have atV : key v=A z ∨ key v=B z := zAt.elim (fun h=>Or.inl h.symm) (fun h=>Or.inr h.symm)
  rcases edge with h|h
  · exact cross x y z xy xz (h.1.symm ▸ atU) (h.2.symm ▸ atV)
  · exact symm z y (cross x z y xz xy (h.1.symm ▸ atV) (h.2.symm ▸ atU))
variable (cg : ∀a b,a≠b→(N a∩N b).card≤1)
include represented cross symm cg in
theorem noHighEdge (u v : V) (du : 3≤G.degree u) (dv : 3≤G.degree v) : ¬G.Adj u v := by
  classical
  intro uv
  obtain ⟨x,edge⟩ := represented u v uv
  obtain ⟨f,hf,fi⟩ := star_map G key A B represented u x
  obtain ⟨g,hg,gi⟩ := star_map G key A B represented v x
  let U := (G.neighborFinset u).erase v
  let W := (G.neighborFinset v).erase u
  have uc : 1<(U.image f).card := by
    rw [Finset.card_image_of_injOn (fi.mono (Finset.erase_subset ..))]
    have h := Finset.pred_card_le_card_erase (s:=G.neighborFinset u) (a:=v)
    change 1<((G.neighborFinset u).erase v).card
    rw [G.card_neighborFinset_eq_degree] at h
    omega
  have wc : 1<(W.image g).card := by
    rw [Finset.card_image_of_injOn (gi.mono (Finset.erase_subset ..))]
    have h := Finset.pred_card_le_card_erase (s:=G.neighborFinset v) (a:=u)
    change 1<((G.neighborFinset v).erase u).card
    rw [G.card_neighborFinset_eq_degree] at h
    omega
  obtain ⟨_,hy,_,hz,bad⟩ := IncidenceGroupDemand.compatible N cg _ _ uc wc
  obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hy
  obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hz
  obtain ⟨pv,pu⟩ := Finset.mem_erase.mp hp
  obtain ⟨qu,qv⟩ := Finset.mem_erase.mp hq
  have yp := hf p pu
  have zq := hg q qv
  exact bad (opposite key A B N symm cross edge (touches key A B yp).1 (touches key A B zq).1
    (fun eq=>pv (fan_unique key A B yp (eq ▸ edge)))
    (fun eq=>qu (fan_unique key A B zq (eq ▸ reverse key A B edge))))

include represented cross symm cg in
theorem high (u : V) (four : 4≤G.degree u) : (survivingNeighbors G u).card≤2 := by
  classical
  let S := G.neighborFinset u
  have fourS : 4≤S.card := by simpa [S] using four
  obtain ⟨v,hv⟩ := Finset.card_pos.mp (show 0<S.card by omega)
  obtain ⟨base,_⟩ := represented u v ((G.mem_neighborFinset ..).mp hv)
  obtain ⟨f,hf,fi⟩ := star_map G key A B represented u base
  let T := survivingNeighbors G u
  have pick (w : V) (hw : w∈T) : ∃a : E, Touch key A B a w ∧ a≠f w := by
    obtain ⟨sw,du⟩ := Finset.mem_filter.mp hw
    have ne : ((G.neighborFinset w).erase u).Nonempty := by
      apply Finset.card_pos.mp
      have h := Finset.pred_card_le_card_erase (s:=G.neighborFinset w) (a:=u)
      rw [G.card_neighborFinset_eq_degree] at h
      omega
    obtain ⟨p,hp⟩ := ne
    obtain ⟨pu,pw⟩ := Finset.mem_erase.mp hp
    obtain ⟨a,pa⟩ := represented w p ((G.mem_neighborFinset ..).mp pw)
    exact ⟨a,(touches key A B pa).1,fun eq=>pu (fan_unique key A B pa
      (eq.symm ▸ reverse key A B (hf w sw)))⟩
  let alt (w : V) := if h : w∈T then (pick w h).choose else base
  have altSpec w (h : w∈T) : Touch key A B (alt w) w ∧ alt w≠f w := by
    simpa [alt,h] using (pick w h).choose_spec
  let positions (e : E) := S.filter (fun w=>f w∈N e)
  let ends (e : E) := Finset.univ.filter (Touch key A B e)
  apply high_survivors S T fourS alt positions ends
  · intro w hw
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,(altSpec w hw).1⟩
  · intro e
    have sub : (ends e).image key⊆{A e,B e} := by
      intro b hb
      obtain ⟨w,hw,rfl⟩ := Finset.mem_image.mp hb
      rcases (Finset.mem_filter.mp hw).2 with h|h <;> simp [h]
    have le := Finset.card_le_card sub
    rw [Finset.card_image_of_injective _ key.injective] at le
    exact le.trans ((Finset.card_insert_le ..).trans (by simp))
  · intro w hw z hz zw
    have sw := (Finset.mem_filter.mp hw).1
    refine Finset.mem_filter.mpr ⟨hz,?_⟩
    exact symm (f z) (alt w) (opposite key A B N symm cross (hf w sw)
      (touches key A B (hf z hz)).1 (altSpec w hw).1
      (fun eq=>zw (fi hz sw eq.symm)) (altSpec w hw).2.symm)
  · intro a b ab
    apply le_trans _ (cg a b ab)
    apply Finset.card_le_card_of_injOn f
    · intro w hw
      obtain ⟨ha,hb⟩ := Finset.mem_inter.mp hw
      exact Finset.mem_inter.mpr ⟨(Finset.mem_filter.mp ha).2,(Finset.mem_filter.mp hb).2⟩
    · apply fi.mono
      intro w h
      exact (Finset.mem_filter.mp (Finset.mem_inter.mp h).1).1
end IncidenceGroupStarLabels
