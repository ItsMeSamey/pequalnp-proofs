import IncidenceGroupGraph

namespace IncidenceGroupGraph
open scoped Classical
variable {V E : Type*} [Fintype V] [DecidableEq V]

/-- At a center, star positions are indexed by neighboring vertices. An alternative edge
at w covers every position except possibly w. Distinct alternatives cover at most one
common position, and an alternative edge has at most two endpoints. -/
theorem high_survivors (star surviving : Finset V) (four : 4 ≤ star.card)
    (alt : V → E) (positions : E → Finset V) (ends : E → Finset V)
    (incident : ∀ w∈surviving, w∈ends (alt w)) (two : ∀ e, (ends e).card ≤ 2)
    (cover : ∀ w∈surviving, ∀ z∈star, z≠w → z∈positions (alt w))
    (codegree : ∀ a b, a≠b → ((positions a) ∩ (positions b)).card ≤ 1) :
    surviving.card ≤ 2 := by
  classical
  by_cases empty : surviving.Nonempty
  · obtain ⟨w,hw⟩ := empty
    refine (Finset.card_le_card (t := ends (alt w)) ?_).trans (two _)
    intro u hu
    have same : alt u = alt w := by
      by_contra ne
      let P : Finset V := {u,w}
      let Q := positions (alt u) ∩ positions (alt w)
      have sub : star ⊆ P ∪ Q := by
        intro z hz
        by_cases zu : z=u
        · exact Finset.mem_union_left _ (by simp [P,zu])
        by_cases zw : z=w
        · exact Finset.mem_union_left _ (by simp [P,zw])
        exact Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨cover u hu z hz zu,cover w hw z hz zw⟩)
      have hp : P.card ≤ 2 := (Finset.card_insert_le _ _).trans (by simp)
      have hq : Q.card ≤ 1 := codegree _ _ ne
      have bound := (Finset.card_le_card sub).trans (Finset.card_union_le P Q)
      omega
    rw [← same]
    exact incident u hu
  · simp [Finset.not_nonempty_iff_eq_empty.mp empty]

variable (G : SimpleGraph V) [DecidableRel G.Adj]
def kept : Set V := {v | 2 ≤ G.degree v}
def survivingNeighbors (v : V) := (G.neighborFinset v).filter (fun w => 2 ≤ G.degree w)

theorem stripped_degree (v : kept G) :
    (G.induce (kept G)).degree v ≤ (survivingNeighbors G v.val).card := by
  classical
  apply Finset.card_le_card_of_injOn Subtype.val
  · intro w hw
    have edge := ((G.induce (kept G)).mem_neighborFinset v w).mp hw
    exact Finset.mem_filter.mpr ⟨(G.mem_neighborFinset _ _).mpr edge, w.property⟩
  · exact fun _ _ _ _ eq => Subtype.ext eq

theorem stripped_density
    (high : ∀ v, 4 ≤ G.degree v → (survivingNeighbors G v).card ≤ 2)
    (noHighEdge : ∀ x y, 3 ≤ G.degree x → 3 ≤ G.degree y → ¬ G.Adj x y) :
    5 * (G.induce (kept G)).edgeFinset.card ≤ 6 * Fintype.card (kept G) := by
  classical
  have mono (v : kept G) : (G.induce (kept G)).degree v ≤ G.degree v.val :=
    (stripped_degree G v).trans (Finset.card_le_card (Finset.filter_subset _ _))
  apply core
  · intro v
    by_cases h : 4 ≤ G.degree v.val
    · have := (stripped_degree G v).trans (high _ h)
      omega
    · have := mono v
      omega
  · intro x y hx hy
    exact noHighEdge _ _ (hx ▸ mono x) (hy ▸ mono y)

#print axioms high_survivors
#print axioms stripped_degree
#print axioms stripped_density
end IncidenceGroupGraph
