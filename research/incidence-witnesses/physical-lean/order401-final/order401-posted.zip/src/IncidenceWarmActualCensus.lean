import IncidenceWarmActualPointCap
import IncidenceWarmSharedActual
import IncidencePointForkPositive
import IncidenceWarmUnedited
namespace IncidenceWarmActualPointCap
open SparseIncidence IncidenceStartNormalization IncidencePointFirstFork IncidencePointShield IncidenceRobust
open IncidencePointBooking IncidencePointWarmMasks IncidenceReciprocalChoice IncidenceChosenEnds IncidenceWarmDichotomy
variable {n : Nat}
private theorem edit_subset (C : Circuit n) (I : Fin n→Fin n→Prop) (k : Fin n→Nat)
    (O : Finset (Fin n)) (f : Fin n→Fin n) : edits C I k O f ⊆ O := by
  classical
  exact Finset.filter_subset _ _

theorem census (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I] (bin : binary C)
    (andP : soleAnd C 0) (pos : flags C I) (neg : negatives C I 401 400)
    (degree : ∀l,Fintype.card {p // I p l}=402) (plane : ∀a b,a≠b → ∃!l,I a l ∧ I b l)
    (hn : n=161203) (size : C.size≤646424) : (soleOwners C).card≤6461 := by
  classical
  obtain ⟨f,valid,_,editsPaid⟩ := paid C I andP pos neg degree plane hn size
  let O := soleOwners C
  let M := edits C I (c C) O f
  let S := O\M
  have subset : M⊆O := edit_subset C I (c C) O f
  have joins (x y : Fin n) : ∃l,I x l ∧ I y l := by
    by_cases eq : x=y
    · subst y
      have count := lines_card I degree plane (q:=401) (by decide) (by omega) x
      obtain ⟨l,h⟩ := Finset.card_pos.mp (show 0<(lines I x).card by omega)
      exact ⟨l,(Finset.mem_filter.mp h).2,(Finset.mem_filter.mp h).2⟩
    · exact (plane x y eq).exists
  obtain ⟨s,small,code,Y,out,inputs,top,laws,answers⟩ :=
    IncidenceWarmSharedActual.build C I bin pos neg andP (by omega) joins S
      (fun x hx=>(Finset.mem_filter.mp (Finset.mem_sdiff.mp hx).1).2)
  have kept (x : Fin n) (hx : x∈S) := retained C I (c C) O f valid
    (Finset.mem_sdiff.mp hx).1 (Finset.mem_sdiff.mp hx).2
  have ranks (x y : Fin n) (ne : x≠y) (fx : f x=y) (_ : f y=x) : c C x≠c C y := by
    have non : (D C I (c C) O x).Nonempty := by
      by_contra h
      have validx := valid x
      change (if (D C I (c C) O x).Nonempty then f x∈D C I (c C) O x else f x=x) at validx
      have self : f x=x := by simpa only [if_neg h] using validx
      exact ne (self.symm.trans fx)
    obtain ⟨v,hv⟩ := non
    obtain ⟨W,small,avoid,hit⟩ := ((mem_D C I (c C) O x v).mp hv).2.1
    exact IncidenceWarmForkSeparation.points_distinct I C pos neg degree plane hn x y ne W
      (by omega) (avoid x (by simp)) (by
        have eq : bits {x}=single x := by funext i; simp [bits,single]
        simpa only [mask,eq,c] using hit)
  apply sparse_census I degree plane (by omega) s code Y S (fun x=>{x,f x}) out
    (fun _ _=>(Finset.card_insert_le _ _).trans (by simp)) _ top
    (fun x hx=>(answers x hx).1) inputs laws _ _ (small.trans size) M.card O.card _ editsPaid
  · intro x hx y hy ne xy yx
    have fy : f y=x := (Finset.mem_singleton.mp ((Finset.mem_insert.mp xy).resolve_left ne)).symm
    have fx : f x=y := (Finset.mem_singleton.mp ((Finset.mem_insert.mp yx).resolve_left ne.symm)).symm
    exact no_shared f (c C) ranks (kept x hx).1 (kept y hy).1 ne fx fy
  · intro x hx l hl
    apply ((answers x hx).2 _).mpr
    exact fork_positive C I pos neg x l (Finset.mem_filter.mp hl).2 _
      (IncidenceWarmTraceShadow.fork_bound C (by have := x.isLt; omega : x.val<n+n+C.size))
      (IncidenceWarmTraceShadow.blocked C x.val)
  · intro x hx T dis on
    apply (kept x hx).2
    refine ⟨T.val,T.property,?_,((answers x hx).2 T).mp on⟩
    intro a ha l hl inc
    apply Finset.disjoint_left.mp dis hl
    exact Finset.mem_biUnion.mpr ⟨a,ha,Finset.mem_filter.mpr ⟨Finset.mem_univ _,inc⟩⟩
  · have h := Finset.card_sdiff_add_card_eq_card subset
    dsimp [S]; omega
#print axioms census
end IncidenceWarmActualPointCap

namespace IncidenceWarmActualPointCap
open IncidenceStartNormalization
variable {n : Nat}
theorem soleOwners_count (C : Circuit n) : (soleOwners C).card=soleCount C 0 := by
  unfold soleOwners soleCount
  apply Finset.card_bij (fun (p : Fin n) _=>p.val)
  · intro p h
    exact Finset.mem_filter.mpr ⟨Finset.mem_range.mpr p.isLt,by simpa using (Finset.mem_filter.mp h).2⟩
  · intro a _ b _ eq
    exact Fin.ext eq
  · intro i hi
    obtain ⟨inside,one⟩ := Finset.mem_filter.mp hi
    refine ⟨⟨i,Finset.mem_range.mp inside⟩,Finset.mem_filter.mpr ⟨Finset.mem_univ _,?_⟩,rfl⟩
    simpa using one

theorem point_bound (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I] (bin : binary C)
    (andP : soleAnd C 0) (pos : flags C I) (neg : negatives C I 401 400)
    (degree : ∀l,Fintype.card {p // I p l}=402) (plane : ∀a b,a≠b → ∃!l,I a l ∧ I b l)
    (hn : n=161203) (size : C.size≤646424) : soleCount C 0≤6461 := by
  rw [←soleOwners_count]
  exact census C I bin andP pos neg degree plane hn size
#print axioms point_bound
end IncidenceWarmActualPointCap
