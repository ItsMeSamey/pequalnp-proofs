import IncidenceWarmTrackedRows
import IncidenceWarmTraceFamily
import IncidencePointForeign
namespace IncidenceWarmTrackedStart
open IncidenceStartNormalization IncidencePointCorridor IncidencePointFirstFork IncidenceWarmTraceNative
open IncidenceWarmTraceChart IncidenceWarmTrackedRows IncidencePointShield SparseIncidence
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) (S : Finset (Fin n))
variable (paths : ∀x : Fin n,Path (n+n) C.code x.val (fork C x.val))

theorem starts_meet {a z x : Nat} (p : Path (n+n) C.code a z)
    (check : p.check C.output x C.size) (different : a≠z)
    (only : ∀g<C.size,∀b,inputPort (C.code g) b=a → (C.code g).op=.meet) : p.factors≠[] := by
  cases p with
  | nil w => exact False.elim (different rfl)
  | cons g b t =>
    have meet := only g check.1 b rfl
    simp [Path.factors,meet]

theorem start (pos : flags C I) (neg : negatives C I 401 400) (andP : soleAnd C 0)
    (joins : ∀x y : Fin n,∃l,I x l ∧ I y l)
    (checks : ∀x∈S,(paths x).check C.output x.val C.size)
    (native : ∀x∈S,Native C (paths x))
    (sole : ∀x∈S,uses C x.val=1) (x : Fin n) (hx : x∈S) :
    ∃ u : G C S paths, (rows C (G C S paths) x.val).head?=some u ∧
      IncidencePointCommon.factors (G C S paths) (sib C S paths)
        (successor C (G C S paths)) (later C (G C S paths)) u=(paths x).factors := by
  have no : negatives C I 2 2 := fun a b ha hb=>neg a b (by omega) (by omega)
  obtain ⟨_,_,_,e,_,_,_,eq⟩ := IncidenceWarmTraceBooking.raw_start C x.val (sole x hx)
    (IncidenceWarmTraceFamily.not_output C I no _ (by have := x.isLt; omega))
  have ne : x.val≠fork C x.val := by rw [eq]; have := x.isLt; omega
  have nonempty := starts_meet C (paths x) (checks x hx) ne (by
    intro g hg b edge
    apply andP x.val x.isLt (by simpa using sole x hx) g hg
    cases b
    · exact Or.inl (by simpa [inputPort] using edge)
    · exact Or.inr (by simpa [inputPort] using edge))
  have sel := member C S paths checks x hx
  have other := side_eq C S paths I pos neg joins checks x hx
  have mapped := IncidenceWarmTraceFactors.native_factors C _ _ (native x hx) sel other
  cases hs : rows C (G C S paths) x.val with
  | nil => simp [hs] at mapped; exact False.elim (nonempty mapped)
  | cons u t =>
    have h : (rows C (G C S paths) x.val).head?=some u := by simp [hs]
    exact ⟨u,rfl,IncidenceWarmTraceFactors.common_factors C _ _ (native x hx) sel other h⟩

theorem baseline (pos : flags C I) (neg : negatives C I 401 400)
    (incident : ∀x : Fin n,∃l,I x l) (checks : ∀x∈S,(paths x).check C.output x.val C.size)
    (g : Nat) (hg : g∈K C S paths) (T : Finset (Fin n)) (tiny : T.card≤399) :
    ((fun _=>false),bits T)∉C.wire (n+n+g) := by
  obtain ⟨x,hx,b,hit⟩ := (Finset.mem_filter.mp hg).2
  obtain ⟨j,inc⟩ := incident x
  obtain ⟨bound,_,cut⟩ := port_guards (paths x) _ _ _ _ _ (checks x hx) hit
  exact foreign_zero I C pos neg x j inc (n+n+g) (by omega) cut T tiny
#print axioms start
#print axioms baseline
end IncidenceWarmTrackedStart
