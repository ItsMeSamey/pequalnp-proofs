import IncidencePointNativeMerge
namespace IncidencePointWarmMasks
open IncidenceStartNormalization IncidencePointShield SparseIncidence
variable {n : Nat}
theorem fork_positive (C : Circuit n) (I : Fin n→Fin n→Prop) (pos : flags C I)
    (neg : negatives C I 401 400) (x l : Fin n) (inc : I x l) (cut : Nat)
    (bd : cut<n+n+C.size) (shielded : shadow (n+n) C.code x.val cut C.size C.output=false) :
    mask {x} {l}∈C.wire cut := by
  let u : Input n := ((fun _=>false),single l)
  let v : Input n := (single x,single l)
  have up : Extends u v := by
    constructor
    · intro i h; change false=true at h; cases h
    · exact fun i h=>h
  have rej : u∉C.wire C.output := by
    apply neg _ _ (by simp) _ (by intro _ _ h; cases h)
    have eq : single l=bits {l} := by funext i; simp [bits,single]
    rw [eq,bits_card]; simp
  have hit := hot_at_cut (n+n) C.size C.code C.wire C.earlier C.law x.val cut C.output
    u v (change_one C x _) (monotone C cut bd up) C.output_lt shielded rej (pos x l inc)
  have e (a : Fin n) : bits {a}=single a := by funext i; simp [bits,single]
  simpa only [mask,e] using hit
#print axioms fork_positive
end IncidencePointWarmMasks
