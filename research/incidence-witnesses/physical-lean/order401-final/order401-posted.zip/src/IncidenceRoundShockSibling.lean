import IncidenceRoundReservations
namespace IncidenceRoundReservations
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceHoistReaders
variable {n : ℕ}
theorem sibling_single (C : Circuit n) (I : Fin n→Fin n→Prop) (bin : binary C)
    (pos : flags C I) (neg : negatives C I 3 3) {x y : ℕ} (edge : adj I x y)
    (one : uses C x=1) (meet : (C.code (owner C x)).op=.meet)
    : small n {y}∈C.wire (sib C x) := by
  classical
  obtain ⟨p,l,inc,xy⟩ := edge
  have hx : x<n+n := by rcases xy with h|h <;> omega
  have hy : y<n+n := by rcases xy with h|h <;> omega
  have diff : x≠y := by rcases xy with h|h <;> omega
  have hit : small n {x,y}∈C.wire C.output := by
    rcases xy with ⟨rfl,rfl⟩|⟨rfl,rfl⟩
    · rw [pair_mask]; exact pos p l inc
    · rw [Finset.pair_comm,pair_mask]; exact pos p l inc
  obtain ⟨hj,port,only⟩ := read_unique C one
  have other : sib C x≠x := by
    intro eq
    have h := (only _ hj (!(reader C x).2) eq).2
    cases e : (reader C x).2 <;> simp [e] at h
  have out : C.output≠x := by
    intro e
    have no := singleton_off C I neg hx
    rw [e,raw_small C _ hx] at no
    simp at no
  let d := (reader C x).2
  have flip := IncidenceThetaSibling.physical (n+n) C.size x (owner C x) C.output C.code C.wire
    (fun k hk=>⟨(C.earlier k hk).1,(C.earlier k hk).2,bin k hk⟩) C.law hj meet (!d)
    (fun k hk ne=>⟨fun e=>ne (only k hk true e).1,fun e=>ne (only k hk false e).1⟩)
    other C.output_lt out (small n {x,y}) (small n {y})
    (fun i hi ne=>by rw [raw_small C _ hi,raw_small C _ hi]; simp [ne]) hit (singleton_off C I neg hy)
  exact flip
end IncidenceRoundReservations
