import IncidenceFirstForkWalk
import IncidencePointFirstFork
namespace IncidenceLineNativeFork
open IncidenceStartNormalization IncidenceLineColdSibling IncidenceFirstForkWalk
open IncidenceHoistReaders IncidencePointFirstFork IncidencePointDeterministicTail
variable {n : ℕ} (C : Circuit n)

theorem stopped {u : ℕ} (h : terminal C u) : next C u=none := by
  rcases h with out|notOne
  · simp [next,out]
  · have empty : reader? C u=none := by
      unfold reader?
      split
      next pair eq =>
        have one := occurrence_count C u
        rw [eq] at one
        exact (notOne (by simpa using one.symm)).elim
      next => rfl
    simp [next,empty]

theorem native (sz : 0<C.size) (x : Fin n) :
    Corridor C x (fork C (n+x.val)) := by
  classical
  obtain ⟨k,last,chain⟩ := first C sz x
  let W := walk C sz x
  have same : ∀i,fork C (W i)=fork C (n+x.val) := by
    intro i
    induction i with
    | zero => rfl
    | succ i ih =>
      by_cases h : terminal C (W i)
      · have eq : W (i+1)=W i := by simp only [W,walk,if_pos h]
        rw [eq]; exact ih
      · have no : W i≠C.output := fun eq=>h (Or.inl eq)
        have one : uses C (W i)=1 := by by_contra bad; exact h (Or.inr bad)
        have r : reader? C (W i)=some ((readerGate C sz (W i)).val,port C (W i)) := by
          simpa [readerGate,port,one] using (unique_reader C (W i) one).choose_spec.choose_spec.1
        have link : next C (W i)=some (W (i+1)) := by
          simp only [next,if_neg no,r,Option.map_some,W,walk,if_neg h]
        exact (after_read C link).symm.trans ih
  have eq : W k=fork C (n+x.val) := (unique (.stop (stopped C last)) (tail C (W k))).trans (same k)
  rw [←eq]; exact chain
end IncidenceLineNativeFork
