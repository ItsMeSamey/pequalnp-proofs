import IncidenceWarmTracePath
import IncidencePointCutSet
namespace IncidenceWarmTraceShadow
open IncidenceStartNormalization IncidencePointFirstFork IncidenceHoistReaders
open IncidencePointDeterministicTail IncidencePointShield

theorem fork_bound {n} (C : Circuit n) {w : Nat} (h : w<n+n+C.size) :
    fork C w<n+n+C.size := by
  have run {u e : Nat} (t : Tail (next C) u e) : u<n+n+C.size → e<n+n+C.size := by
    induction t with
    | stop => exact id
    | pass edge _ ih => exact fun _=>ih (next_bounds C edge).2
  exact run (tail C w) h

private theorem through_reader {n} (C : Circuit n) (u j : Nat) (b : Bool)
    (valid : j<C.size) (port : operand (C.code j) b=u)
    (before : u≠fork C u) : fork C u=fork C (n+n+j) := by
  cases h : next C u with
  | none => exact (before (unique (.stop h) (tail C u))).elim
  | some v =>
    obtain ⟨k,d,eq,_,_,pick⟩ := IncidenceWarmTracePath.read_step C h
    have one : occurrences C u=[(k,d)] := by
      unfold reader? at pick
      split at pick
      next _ only => cases pick; exact only
      next => contradiction
    have here := (occurrence_mem C u j b).2 ⟨valid,port⟩
    rw [one,List.mem_singleton] at here
    have jk := congrArg Prod.fst here
    have vv : v=n+n+j := by change j=k at jk; omega
    exact vv ▸ after_read C h

/-- A wire reached by the unblocked shadow has the same physical fork as the
raw and precedes its stop. This covers unused raws and an observed raw output. -/
theorem shadow_on {n} (C : Circuit n) (x : Nat) (i : Nat) (bound : i<n+n+C.size)
    (hit : shadow (n+n) C.code x (fork C x) C.size i=true) :
    fork C i=fork C x ∧ i≠fork C x := by
  induction i using Nat.strong_induction_on with
  | ind i ih =>
    by_cases low : i<n+n
    · rw [raw _ _ _ _ _ _ low] at hit
      obtain ⟨eq,ne⟩ := of_decide_eq_true hit
      exact ⟨congrArg (fork C) eq,ne⟩
    let j:=i-(n+n)
    have eq : i=n+n+j := by dsimp [j]; omega
    have js : j<C.size := by omega
    have ⟨l,r⟩ := C.earlier j js
    rw [eq,gate _ _ _ _ _ _ js l r] at hit
    have cond := Bool.and_eq_true_iff.mp hit
    have ne : i≠fork C x := by rw [eq]; exact of_decide_eq_true cond.1
    refine ⟨?_,ne⟩
    rcases Bool.or_eq_true_iff.mp cond.2 with left|right
    · obtain ⟨same,neq⟩ := ih (C.code j).left (by omega) (by omega) left
      have step := through_reader C _ j true js rfl (fun h=>neq (h.trans same))
      rw [eq]; exact step.symm.trans same
    · obtain ⟨same,neq⟩ := ih (C.code j).right (by omega) (by omega) right
      have step := through_reader C _ j false js rfl (fun h=>neq (h.trans same))
      rw [eq]; exact step.symm.trans same

theorem blocked {n} (C : Circuit n) (x : Nat) :
    shadow (n+n) C.code x (fork C x) C.size C.output=false := by
  cases h : shadow (n+n) C.code x (fork C x) C.size C.output with
  | false => rfl
  | true =>
    have ⟨same,ne⟩ := shadow_on C x _ C.output_lt h
    have stop : next C C.output=none := by simp [next]
    have id := unique (.stop stop) (tail C C.output)
    exact (ne (id.trans same)).elim

#print axioms blocked
#print axioms fork_bound
end IncidenceWarmTraceShadow
