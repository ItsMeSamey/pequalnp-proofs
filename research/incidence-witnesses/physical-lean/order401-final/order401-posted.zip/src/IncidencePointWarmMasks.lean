import IncidencePointWarmComparison
import IncidencePointForeign
namespace IncidencePointWarmMasks
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmCompiler IncidencePointWarmComparison
variable {n : Nat}
def mask (J T : Finset (Fin n)) : Input n := (bits J,bits T)
def drops (M : Finset (Fin n)) : Finset Nat := M.image Fin.val

theorem bitInputs (C : Circuit n) (M J T J' T' : Finset (Fin n)) (except : Finset (Fin n))
    (retained : ∀x∈J,x∉M → x∉except → x∈J') (payload : T⊆T') :
    ∀i<n+n,i∉drops M → (∀x∈except,i≠x.val) → mask J T∈C.wire i → mask J' T'∈C.wire i := by
  intro i hi keep good
  by_cases first : i<n
  · let x : Fin n:=⟨i,first⟩
    rw [(C.inputs x).1]
    change decide (x∈J)=true → decide (x∈J')=true
    simp only [decide_eq_true_eq]
    intro mem
    apply retained x mem
    · intro inside
      exact keep (Finset.mem_image.mpr ⟨x,inside,rfl⟩)
    · exact fun hx=>good x hx rfl
  · let l : Fin n:=⟨i-n,by omega⟩
    have idx : i=n+l.val := by dsimp [l]; omega
    rw [idx,(C.inputs l).2]
    change decide (l∈T)=true → decide (l∈T')=true
    simpa only [decide_eq_true_eq] using (show l∈T → l∈T' from fun h=>payload h)

theorem negative (C : Circuit n) (I : Fin n→Fin n→Prop) (neg : negatives C I 401 400)
    {J T : Finset (Fin n)} (pc : J.card≤401) (lc : T.card≤400)
    (ind : ∀p∈J,∀l∈T,¬I p l) : mask J T∉C.wire C.output := by
  apply neg (bits J) (bits T) ((bits_card J).le.trans pc) ((bits_card T).le.trans lc)
  intro p l hp hl
  exact ind p (by simpa [bits] using hp) l (by simpa [bits] using hl)

end IncidencePointWarmMasks
