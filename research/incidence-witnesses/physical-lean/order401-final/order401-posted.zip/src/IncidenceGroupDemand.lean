import IncidenceLineGateBooking
namespace IncidenceGroupDemand
open scoped BigOperators
variable {α β : Type*} [DecidableEq α] [DecidableEq β]

def Independent (N : α→Finset α) (V : Finset α) := ∀u∈V,∀v∈V,v∉N u

theorem compatible (N : α→Finset α) (overlap : ∀a b,a≠b→(N a∩N b).card≤1)
    (A B : Finset α) (a2 : 1<A.card) (b2 : 1<B.card) :
    ∃a∈A,∃b∈B,b∉N a := by
  classical
  by_contra! all
  obtain ⟨a,ha,b,hb,ne⟩ := Finset.one_lt_card.mp a2
  have sub : B⊆N a∩N b := by
    intro v hv
    exact Finset.mem_inter.mpr ⟨all a ha v hv,all b hb v hv⟩
  exact (not_lt_of_ge ((Finset.card_le_card sub).trans (overlap a b ne))) b2

theorem test (N : α→Finset α) (loop : ∀u,u∉N u)
    (symm : ∀u v,v∈N u→u∈N v)
    (overlap : ∀a b,a≠b→(N a∩N b).card≤1)
    (x : α) (deg : 2<(N x).card) (A B : Finset α)
    (bigA : 2<A.card) (bigB : 2<B.card) :
    ∃S : Finset α,S.card≤3 ∧ x∉S ∧ Independent N S ∧
      (∃a∈S,a∈A) ∧ (∃b∈S,b∈B) ∧ (∃y∈S,y∈N x) := by
  classical
  have a2 := Finset.pred_card_le_card_erase (s:=A) (a:=x)
  have b2 := Finset.pred_card_le_card_erase (s:=B) (a:=x)
  obtain ⟨a,ha,b,hb,no⟩ := compatible N overlap (A.erase x) (B.erase x) (by omega) (by omega)
  obtain ⟨ax,ain⟩ := Finset.mem_erase.mp ha
  obtain ⟨bx,bin⟩ := Finset.mem_erase.mp hb
  have ex : ¬N x⊆(N x∩N a)∪(N x∩N b) := by
    intro sub
    have lim := (Finset.card_le_card sub).trans (Finset.card_union_le ..)
    have qa := overlap x a ax.symm
    have qb := overlap x b bx.symm
    omega
  obtain ⟨y,yn,out⟩ := Finset.not_subset.mp ex
  have ya : y∉N a := fun h => out (Finset.mem_union_left _ (Finset.mem_inter.mpr ⟨yn,h⟩))
  have yb : y∉N b := fun h => out (Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨yn,h⟩))
  have nx : y≠x := fun eq => loop x (eq ▸ yn)
  refine ⟨{a,b,y},?_,by simp [Ne.symm ax,Ne.symm bx,Ne.symm nx],?_,⟨a,by simp,ain⟩,
    ⟨b,by simp,bin⟩,⟨y,by simp,yn⟩⟩
  · have t := Finset.card_insert_le a ({b,y} : Finset α)
    have r := Finset.card_insert_le b ({y} : Finset α)
    simp only [Finset.card_singleton] at r
    omega
  · intro u hu v hv
    simp only [Finset.mem_insert,Finset.mem_singleton] at hu hv
    rcases hu with rfl|rfl|rfl <;> rcases hv with rfl|rfl|rfl <;>
      first | exact loop _ | assumption | exact fun h=>no (symm _ _ h) |
        exact fun h=>ya (symm _ _ h) | exact fun h=>yb (symm _ _ h)

theorem count (R : Finset α) (G : Finset β) (labels : β→Finset α)
    (small : ∀x∈R,∃g∈G,x∈labels g ∧ (labels g).card≤2) :
    R.card≤2*G.card := by
  classical
  let H:=G.filter (fun g=>(labels g).card≤2)
  have sub : R⊆H.biUnion labels := by
    intro x hx
    obtain ⟨g,hg,mem,card⟩ := small x hx
    exact Finset.mem_biUnion.mpr ⟨g,Finset.mem_filter.mpr ⟨hg,card⟩,mem⟩
  calc
    _ ≤ (H.biUnion labels).card := Finset.card_le_card sub
    _ ≤ ∑g∈H,(labels g).card := Finset.card_biUnion_le
    _ ≤ ∑g∈H,2 := Finset.sum_le_sum fun g hg => (Finset.mem_filter.mp hg).2
    _ ≤ 2*G.card := by
      have lim := Finset.card_le_card (Finset.filter_subset (fun g=>(labels g).card≤2) G)
      simp [H,Nat.mul_comm] at *
      omega
/-- Only the two actual groups covering the two physical raw reads are used.
    The proof allows the two group identifiers to coincide. -/
theorem demand (N : α→Finset α) (loop : ∀u,u∉N u) (symm : ∀u v,v∈N u→u∈N v)
    (overlap : ∀a b,a≠b→(N a∩N b).card≤1) (R : Finset α)
    (G : Finset β) (labels : β→Finset α) (accept : Finset α→Prop)
    (neg : ∀S,S.card≤3→Independent N S→¬accept S)
    (flag : ∀S x,(∃y∈S,y∈N x)→accept (insert x S))
    (groups : ∀x∈R,∃a∈G,∃b∈G,x∈labels a ∧ x∈labels b ∧
      (∀S,(∃u∈S,u∈labels a)→(∃v∈S,v∈labels b)→(accept (insert x S) ↔ accept S)))
    (degree : ∀x∈R,2<(N x).card) : R.card≤2*G.card := by
  apply count R G labels
  intro x hx
  obtain ⟨a,ag,b,bg,xa,xb,block⟩ := groups x hx
  by_cases low : (labels a).card≤2
  · exact ⟨a,ag,xa,low⟩
  by_cases other : (labels b).card≤2
  · exact ⟨b,bg,xb,other⟩
  obtain ⟨S,k,_,ind,u,v,y⟩ := test N loop symm overlap x (degree x hx)
    (labels a) (labels b) (by omega) (by omega)
  exact (neg S k ind ((block S u v).mp (flag S x y))).elim
theorem all_sites (surv sole prot : Finset α) (G : Finset β)
    (cover : ((surv \ prot) \ sole).card≤2*G.card) :
    surv.card ≤ sole.card+prot.card+2*G.card := by
  have a := Finset.card_sdiff_add_card_inter surv prot
  have b := Finset.card_sdiff_add_card_inter (surv \ prot) sole
  have p : (surv∩prot).card≤prot.card := Finset.card_le_card Finset.inter_subset_right
  have q : ((surv\prot)∩sole).card≤sole.card := Finset.card_le_card Finset.inter_subset_right
  omega
end IncidenceGroupDemand
