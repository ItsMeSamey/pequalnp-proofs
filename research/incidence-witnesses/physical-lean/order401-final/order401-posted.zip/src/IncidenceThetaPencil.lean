import Mathlib.Data.Finset.Sort
import IncidencePlaneDual
namespace IncidenceThetaPencil
variable {q n : ℕ} (I : Fin n→Fin n→Prop) [DecidableRel I]

/-- Enumerate all points on Y and their joined lines through x. This full pencil
also dominates off-core vertices before any deletion. -/
theorem pencil (degree : ∀l,Fintype.card {u // I u l}=q+1)
    (join : ∀a b,a≠b → ∃! l,I a l ∧ I b l) (hq : 0<q) (hn : n=q^2+q+1)
    (x Y : Fin n) (xy : ¬I x Y) :
    ∃(p l : Fin (q+1) ↪ Fin n),
      (∀i,x≠p i) ∧ (∀i,l i≠Y) ∧ (∀i,I x (l i)) ∧
      (∀i,I (p i) (l i)) ∧ (∀i,I (p i) Y) ∧
      (∀u,u≠x → ∃i,I u (l i)) ∧ (∀v,v≠Y → ∃i,I (p i) v) := by
  classical
  let ps := IncidenceRobust.points I Y
  have pc : ps.card=q+1 := IncidenceRobust.points_card I degree Y
  let e := (ps.orderIsoOfFin pc).toEquiv
  let p : Fin (q+1) ↪ Fin n := e.toEmbedding.trans (Function.Embedding.subtype _)
  have py (i) : I (p i) Y := (Finset.mem_filter.mp (e i).property).2
  have xp (i) : x≠p i := fun eq=>xy (eq ▸ py i)
  let line (i) := Classical.choose (join x (p i) (xp i))
  have li (i) : I x (line i) ∧ I (p i) (line i) := (Classical.choose_spec (join x (p i) (xp i))).1
  have ly (i) : line i≠Y := fun eq=>xy (eq ▸ (li i).1)
  have eqLine (i) (v) (hx : I x v) (hp : I (p i) v) : v=line i :=
    (Classical.choose_spec (join x (p i) (xp i))).2 v ⟨hx,hp⟩
  have inj : Function.Injective line := by
    intro i j eq
    obtain ⟨u,_,only⟩ := ProtectedIncidence.dual_unique I degree join hq hn (line j) Y (ly j)
    apply p.injective
    exact (only (p i) ⟨eq ▸ (li i).2,py i⟩).trans (only (p j) ⟨(li j).2,py j⟩).symm
  refine ⟨p,⟨line,inj⟩,xp,ly,fun i=>(li i).1,fun i=>(li i).2,py,?_,?_⟩
  · intro u ne
    obtain ⟨v,hv,_⟩ := join x u ne.symm
    have vY : v≠Y := fun eq=>xy (eq ▸ hv.1)
    obtain ⟨a,ha,_⟩ := ProtectedIncidence.dual_unique I degree join hq hn v Y vY
    let i := e.symm ⟨a,Finset.mem_filter.mpr ⟨Finset.mem_univ _,ha.2⟩⟩
    have pi : p i=a := congrArg Subtype.val (e.apply_symm_apply ⟨a,Finset.mem_filter.mpr ⟨Finset.mem_univ _,ha.2⟩⟩)
    refine ⟨i,?_⟩
    change I u (line i)
    rw [←eqLine i v hv.1 (pi ▸ ha.1)]
    exact hv.2
  · intro v ne
    obtain ⟨a,ha,_⟩ := ProtectedIncidence.dual_unique I degree join hq hn v Y ne
    let i := e.symm ⟨a,Finset.mem_filter.mpr ⟨Finset.mem_univ _,ha.2⟩⟩
    have pi : p i=a := congrArg Subtype.val (e.apply_symm_apply ⟨a,Finset.mem_filter.mpr ⟨Finset.mem_univ _,ha.2⟩⟩)
    exact ⟨i,pi ▸ ha.1⟩
#print axioms pencil
end IncidenceThetaPencil
