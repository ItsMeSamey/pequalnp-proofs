import IncidenceWarmTraceNative
import IncidenceWarmTracePath
import IncidencePointCutSet
import IncidencePointCorridor
namespace IncidenceWarmTraceCorridor
open CircuitRewire IncidenceStartNormalization IncidencePointShield IncidenceHoistReaders
open IncidencePointFirstFork IncidenceWarmTracePath IncidencePointDeterministicTail
open IncidencePointCorridor

private structure Prefix {n} (C : Circuit n) (x u : Nat) (H : Finset Nat) : Prop where
  start : x∈H
  top : ∀ i∈H,i≤u
  obs : C.output∈H → C.output=u
  leaves : ∀ t<C.size,∀ b,operand (C.code t) b∈H →
    operand (C.code t) b=u ∨ n+n+t∈H

private theorem sole {n} (C : Circuit n) {u j : Nat} {b : Bool}
    (r : reader? C u=some (j,b)) (t : Nat) (ht : t<C.size) (d : Bool)
    (edge : operand (C.code t) d=u) : t=j ∧ d=b := by
  have list : occurrences C u=[(j,b)] := by
    unfold reader? at r
    split at r
    next _ eq => cases r; exact eq
    next => contradiction
  have atSlot := (occurrence_mem C u t d).2 ⟨ht,edge⟩
  simpa [list] using atSlot

private theorem build {n} (C : Circuit n) (x u : Nat) (H : Finset Nat) (P : Prefix C x u H) :
    ∃ p : IncidencePointCorridor.Path (n+n) C.code u (fork C u), p.check C.output x C.size ∧ IncidenceWarmTraceNative.Native C p := by
  cases link : next C u with
  | none =>
    have eq : u=fork C u := unique (.stop link) (tail C u)
    rw [←eq]
    exact ⟨.nil u,trivial,.nil u link⟩
  | some v =>
    obtain ⟨j,b,rfl,hj,port,pick⟩ := read_step C link
    have inc := (next_bounds C link).1
    have neOut : C.output≠u := by
      intro e
      simp [next,←e] at link
    have out : C.output∉H := fun h=>neOut (P.obs h)
    have escape (t : Nat) (ht : t<C.size) (d : Bool) (hit : operand (C.code t) d∈H)
        (outside : n+n+t∉H) : t=j ∧ d=b :=
      sole C pick t ht d ((P.leaves t ht d hit).resolve_right outside)
    have latest : n+n+j∉H := fun h=>Nat.not_lt_of_ge (P.top _ h) inc
    have sideOut : operand (C.code j) (!b)∉H := by
      intro h
      have bad := (escape j hj _ h latest).2
      cases b <;> contradiction
    have closed (t : Nat) (ht : t<C.size) (ne : t≠j)
        (hit : (C.code t).left∈H ∨ (C.code t).right∈H) : n+n+t∈H := by
      by_contra outside
      rcases hit with h|h
      · exact ne (escape t ht true h outside).1
      · exact ne (escape t ht false h outside).1
    have guard := confined (n+n) C.size x (n+n+j) C.code H P.start C.earlier
      (fun t ht neq h=>closed t ht (fun e=>neq (congrArg (fun k=>n+n+k) e)) h)
      C.output C.output_lt out
    have early : operand (C.code j) (!b)<n+n+j := by
      cases b <;> simp [operand] <;> have h := C.earlier j hj <;> omega
    have away := confined (n+n) j x (n+n+C.size) C.code H P.start
      (fun t ht=>C.earlier t (by omega)) (fun t ht _ h=>closed t (by omega) (by omega) h)
      _ early sideOut
    have late := old (n+n) C.code x (n+n+C.size) j C.size (operand (C.code j) (!b)) hj.le early
    have nextP : Prefix C x (n+n+j) (insert (n+n+j) H) := by
      refine ⟨Finset.mem_insert_of_mem P.start,?_,?_,?_⟩
      · intro i hi
        rcases Finset.mem_insert.mp hi with rfl|h
        · exact le_rfl
        · exact (P.top i h).trans inc.le
      · intro h; exact (Finset.mem_insert.mp h).resolve_right out
      · intro t ht d read
        rcases Finset.mem_insert.mp read with e|h
        · exact Or.inl e
        · by_cases inside : n+n+t∈H
          · exact Or.inr (Finset.mem_insert_of_mem inside)
          · have e := (escape t ht d h inside).1
            subst t
            exact Or.inr (Finset.mem_insert_self ..)
    obtain ⟨p,cert,native⟩ := build C x (n+n+j) _ nextP
    have side : inputPort (C.code j) (!b)=u := by cases b <;> exact port
    have other : inputPort (C.code j) (!(!b))=operand (C.code j) (!b) := by cases b <;> rfl
    rw [after_read C link,← side]
    refine ⟨.cons j (!b) p,⟨hj,?_,guard,cert⟩,.cons j (!b) ?_ native⟩
    · rw [other]; exact late.trans away
    · rw [side]; exact link
termination_by n+n+C.size-u
decreasing_by have h := next_bounds C link; omega

theorem checked_native {n} (C : Circuit n) (x : Nat) :
    ∃ p : IncidencePointCorridor.Path (n+n) C.code x (fork C x),p.check C.output x C.size ∧ IncidenceWarmTraceNative.Native C p := by
  apply build C x x {x}
  exact ⟨by simp,by simp,by simp,fun _ _ _ h=>Or.inl (Finset.mem_singleton.mp h)⟩

theorem checked {n} (C : Circuit n) (x : Nat) :
    ∃ p : IncidencePointCorridor.Path (n+n) C.code x (fork C x),p.check C.output x C.size := by
  obtain ⟨p,h,_⟩ := checked_native C x
  exact ⟨p,h⟩

#print axioms checked_native
#print axioms checked
end IncidenceWarmTraceCorridor
