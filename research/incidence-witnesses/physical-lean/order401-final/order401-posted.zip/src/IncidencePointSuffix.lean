import IncidencePointGuards
import Mathlib.Data.Finset.Sort
namespace IncidencePointSuffix
open IncidencePointGuards CircuitRewire
variable {Z : Type*}
def index (G : Finset Nat) (v : G) : Fin G.card := ((G.orderIsoOfFin rfl).symm v).rev
def key (G : Finset Nat) (j : Fin G.card) : G := G.orderIsoOfFin rfl j.rev
@[simp] theorem key_index (G : Finset Nat) (v : G) : key G (index G v)=v := by simp [key,index]
@[simp] theorem index_key (G : Finset Nat) (v : Fin G.card) : index G (key G v)=v := by simp [key,index]
theorem reverse_index (G : Finset Nat) (u v : G) (before : u.val<v.val) :
    index G v<index G u := Fin.rev_lt_rev.mpr ((G.orderIsoOfFin rfl).symm.strictMono before)

def makeStep (G : Finset Nat) (sibling : G→Option Nat) (next : G→Option G) (i : Nat) : Step :=
  if hi : i<G.card then
    let u := key G ⟨i,hi⟩
    ⟨sibling u,(next u).map (fun v=>(index G v).val)⟩
  else ⟨none,none⟩

def values (G : Finset Nat) (R : G→Set Z) (i : Nat) : Set Z :=
  if hi : i<G.card then R (key G ⟨i,hi⟩) else ∅

theorem packed (n b : Nat) (G : Finset Nat) (base : Nat→Gate) (Y : Nat→Set Z)
    (sibling : G→Option Nat) (next : G→Option G) (R : G→Set Z) (positive : 0<n+b)
    (ord : ∀ j<b,(base j).left<n+j ∧ (base j).right<n+j)
    (sem : ∀ j<b,Y (n+j)=(base j).eval Y)
    (bounded : ∀ u k,sibling u=some k → k<n+b)
    (later : ∀ u v,next u=some v → u.val<v.val)
    (factor : ∀ u,R u=CircuitRewire.read Y (sibling u) ∩ (next u).elim Set.univ R) :
    let steps := makeStep G sibling next
    let code := cat n b base steps
    let X := CatValues n b Y (values G R)
    (∀j<b+G.card,(code j).left<n+j ∧ (code j).right<n+j) ∧
    (∀j<b+G.card,X (n+j)=(code j).eval X) ∧ (∀j<n+b,X j=Y j) ∧
    ∀ u,X (n+b+(index G u).val)=R u := by
  have a := assemble n b G.card base (makeStep G sibling next) Y (values G R)
    positive ord sem
    (by intro i hi k hk; exact bounded _ _ (by simpa [makeStep,hi] using hk))
    (by
      intro i hi j eq
      let u := key G ⟨i,hi⟩
      change (makeStep G sibling next i).suffix=some j at eq
      simp only [makeStep,dif_pos hi,Option.map_eq_some_iff] at eq
      obtain ⟨v,ev,iv⟩ := eq
      have h := reverse_index G u v (later u v ev)
      change (index G v).val < (index G (key G ⟨i,hi⟩)).val at h
      simpa [iv] using h)
    (by
      intro i hi
      let u := key G ⟨i,hi⟩
      simp only [values,makeStep,dif_pos hi]
      change R u=CircuitRewire.read Y (sibling u) ∩
        suffixVal (values G R) ((next u).map (fun v=>(index G v).val))
      rw [factor u]
      cases eq : next u <;> simp [values,suffixVal])
  refine ⟨a.1,a.2.1,a.2.2.1,?_⟩
  intro u
  simpa [values] using a.2.2.2 (index G u).val (index G u).isLt
#print axioms packed
end IncidencePointSuffix
