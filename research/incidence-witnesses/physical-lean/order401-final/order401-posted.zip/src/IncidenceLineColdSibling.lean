import IncidenceLinePrivateCut
namespace IncidenceLineColdSibling
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidencePointShield
open IncidenceLineGateBooking IncidenceLinePrivateCut
variable {n : ℕ}

/-- Each edge in a unary private corridor is physical. The two shadow tests
are derived from its unique-reader prefix and protect opposite directions. -/
inductive Corridor (C : Circuit n) (x : Fin n) : ℕ→Prop where
  | raw : Corridor C x (n+x.val)
  | next {j sibling} (g : Fin C.size) (prev : Corridor C x j)
      (ports : ((C.code g).left=j ∧ (C.code g).right=sibling) ∨
        ((C.code g).right=j ∧ (C.code g).left=sibling))
      (side : shadow (n+n) C.code (n+x.val) (n+n+g.val) C.size sibling=false)
      (barrier : shadow (n+n) C.code (n+x.val) (n+n+g.val) C.size C.output=false) :
      Corridor C x (n+n+g.val)

theorem sibling (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (binary : IncidenceStartNormalization.binary C)
    (positive : flags C I) (negative : negatives C I n 401)
    (x w : Fin n) {j : ℕ} (chain : Corridor C x j)
    (cold : (avoid I x w,single x)∉C.wire j) :
    ∃ b<n+n+C.size, (avoid I x w,fun _=>false)∉C.wire b ∧
       ∀p,I p x → (single p,fun _=>false)∈C.wire b := by
  induction chain with
  | raw =>
    rw [(C.inputs x).2] at cold
    exact False.elim (cold (by simp [single]))
  | @next j b g prev ports side barrier ih =>
    by_cases old : (avoid I x w,single x)∈C.wire j
    · have bb : b<n+n+g.val := by
        obtain ⟨a,c⟩ := C.earlier g.val g.isLt
        rcases ports with h|h <;> omega
      have bound : n+n+g.val<n+n+C.size := by omega
      have stable (a : Fin n→Bool) :=
        pre_shield C (n+x.val) (n+n+g.val) (a,single x) (a,fun _=>false)
          (raw_other C x a) b bb (by omega) side
      have gl := C.law g.val g.isLt
      have both : (C.code g).op=.meet := by
        rcases binary g.val g.isLt with h|h
        · exfalso
          rw [Gate.eval,h,Op.eval] at gl
          apply cold
          rw [gl]
          rcases ports with h|h
          · exact Or.inl (h.1.symm ▸ old)
          · exact Or.inr (h.1.symm ▸ old)
        · exact h
      rw [Gate.eval,both,Op.eval] at gl
      have eq : C.wire (n+n+g.val)=C.wire j∩C.wire b := by
        rcases ports with h|h
        · simpa [h.1,h.2] using gl
        · simpa [h.1,h.2,Set.inter_comm] using gl
      refine ⟨b,by omega,?_,?_⟩
      · intro hb; apply cold; rw [eq]; exact ⟨old,(stable _).mpr hb⟩
      · intro p hp
        have hh := high_at_line_cut C I positive negative p x hp _ bound barrier
        rw [eq] at hh
        exact (stable _).mp hh.2
    · exact ih old
#print axioms sibling
end IncidenceLineColdSibling
