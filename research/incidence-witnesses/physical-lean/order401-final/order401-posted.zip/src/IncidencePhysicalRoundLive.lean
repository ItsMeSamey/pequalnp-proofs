import IncidenceDeadRowErase
import IncidenceRoundPhysicalMove
namespace IncidenceRoundPhysicalMove
open IncidenceHoistPrune IncidenceThetaRoundDriver
variable {n : Nat} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)} (a : Stage I P L)

theorem live_of_stop {E : Finset Nat} (stop : ¬Witness a E) : Live a.C := by
  by_contra dead
  obtain ⟨g,_,_,_,_,_,D,bin,out,size,code,_⟩ := IncidenceDeadRowErase.run a.C a.bin dead
  exact stop (.rowErase g (a.C.code g.val).left D bin out size code)
#print axioms live_of_stop
end IncidenceRoundPhysicalMove
