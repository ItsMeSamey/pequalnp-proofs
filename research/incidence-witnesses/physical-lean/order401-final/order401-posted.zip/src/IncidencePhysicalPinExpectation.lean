import IncidenceActualPinFamily
import IncidenceLinePinBooking
namespace IncidencePhysicalPinExpectation
open scoped BigOperators
open IncidenceRobust IncidenceStartNormalization IncidenceLineRoutedSlots IncidenceEligiblePin
open IncidenceActualPinFamily IncidenceLinePinBooking
variable {n q : ℕ}

noncomputable def forced (C : Circuit n) (P : Finset (Fin n)) : Finset (Fin C.size) := by
  classical
  exact Finset.univ.filter (fun g => (C.code g.val).op=.join ∧ pinMask P∈C.wire (n+n+g.val) ∧
    (∃a∉P,hit C (C.code g.val).left a) ∧ (∃b∉P,hit C (C.code g.val).right b))

theorem expected (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (degree : ∀l,Fintype.card {p // I p l}=q+1)
    (unique : ∀p r,p≠r→∃!l,I p l∧I r l) (hq : 0<q) (hn : n=q^2+q+1)
    (owner : Fin C.size→Fin n) (book : Fin C.size→Finset (Fin n))
    (ok : ∀g,∀p∈book g,eligible C I (owner g) g p) (j : ℕ) :
    (q*q.choose j)*(∑g,(book g).card) ≤ ∑run∈sample I j,(forced C run.2).card := by
  classical
  apply finite_book (sample I j) Finset.univ book (fun g p=>event I (owner g) p j)
    (fun run=>forced C run.2)
  · intro g _ p hp
    exact (event_card I degree unique hq hn (ok g p hp).2.1 j).ge
  · intro g _
    exact different_points I unique (owner g) (book g) (fun p h=>(ok g p h).2.1) j
  · intro g _ p hp run ev
    obtain ⟨diff,inc,inside,sub,sampled⟩ := event_spec I ev
    obtain ⟨high,⟨a,outA,_,ha⟩,⟨b,outB,_,hb⟩⟩ := pin_forces I unique C g
      (owner g) run.1 p diff run.2 (fun i hi=>(Finset.mem_filter.mp (sub hi)).2) inside (ok g p hp)
    exact ⟨sampled,Finset.mem_filter.mpr ⟨Finset.mem_univ _,
      (ok g p hp).1,high,⟨a,outA,ha⟩,⟨b,outB,hb⟩⟩⟩
#print axioms expected
end IncidencePhysicalPinExpectation
