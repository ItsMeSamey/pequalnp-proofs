import IncidencePhysicalPaidRound
import IncidenceMarkTransition
namespace IncidenceAllowedGeometry
open IncidenceThetaRoundDriver IncidencePhysicalPaidRound IncidenceThetaRestrict IncidenceThetaBatchHoist IncidenceMarkTransition
variable {n : ℕ} (I : Fin n→Fin n→Prop) [DecidableRel I]
def lineEmb (n : ℕ) : Fin n ↪ ℕ := ⟨fun l=>n+l.val,fun a b h=>Fin.ext (Nat.add_left_cancel h)⟩
def pointEmb (n : ℕ) : Fin n ↪ ℕ := ⟨Fin.val,Fin.val_injective⟩
def neighbors (x : ℕ) : Finset ℕ :=
  if low : x<n then (N I false ⟨x,low⟩).map (lineEmb n)
  else if hi : x<n+n then (N I true ⟨x-n,by omega⟩).map (pointEmb n) else ∅
def nextP (A : Finset (Fin n)) (D : Finset ℕ) := A.filter (fun p=>p.val∉D)
def nextL (B : Finset (Fin n)) (D : Finset ℕ) := B.filter (fun l=>n+l.val∉D)
theorem next_eq (A B : Finset (Fin n)) (D : Finset ℕ) :
    kept (nextP A D) (nextL B D)=kept A B \ D := by
  ext i
  by_cases lo : i<n
  · let p : Fin n := ⟨i,lo⟩
    change p.val∈_ ↔ p.val∈_
    simp [Finset.mem_sdiff,left,nextP]
  by_cases hi : i<n+n
  · let l : Fin n := ⟨i-n,by omega⟩
    have eq : i=n+l.val := by dsimp [l]; omega
    rw [eq]
    simp [Finset.mem_sdiff,right,nextL]
  · have absent (P L : Finset (Fin n)) : i∉kept P L := by
      rintro h
      rcases Finset.mem_union.mp h with h|h <;> obtain ⟨u,_,rfl⟩ := Finset.mem_image.mp h <;> have := u.isLt <;> omega
    simp [absent]
theorem p_neighbors (A B : Finset (Fin n)) (p : Fin n) (mem : p∈A) :
    kept A B ∩ neighbors I p.val = (N (rel I A B) false p).map (lineEmb n) := by
  classical
  have low := p.isLt
  ext i
  simp only [neighbors,dif_pos low,Finset.mem_inter,Finset.mem_map]
  constructor
  · rintro ⟨k,⟨l,hl,rfl⟩⟩
    exact ⟨l,Finset.mem_filter.mpr ⟨Finset.mem_univ _,mem,(right A B l).mp k,(Finset.mem_filter.mp hl).2⟩,rfl⟩
  · rintro ⟨l,hl,rfl⟩
    have e : rel I A B p l := (Finset.mem_filter.mp hl).2
    exact ⟨(right A B l).mpr e.2.1,l,Finset.mem_filter.mpr ⟨Finset.mem_univ _,e.2.2⟩,rfl⟩
theorem l_neighbors (A B : Finset (Fin n)) (l : Fin n) (mem : l∈B) :
    kept A B ∩ neighbors I (n+l.val) = (N (rel I A B) true l).map (pointEmb n) := by
  classical
  have lo : ¬ n+l.val<n := by omega
  have hi : n+l.val<n+n := by have := l.isLt; omega
  have eq : (⟨n+l.val-n,by omega⟩ : Fin n)=l := Fin.ext (by change n+l.val-n=l.val; omega)
  ext i
  simp only [neighbors,dif_neg lo,dif_pos hi,eq,Finset.mem_inter,Finset.mem_map]
  constructor
  · rintro ⟨k,⟨p,hp,rfl⟩⟩
    exact ⟨p,Finset.mem_filter.mpr ⟨Finset.mem_univ _,(left A B p).mp k,mem,(Finset.mem_filter.mp hp).2⟩,rfl⟩
  · rintro ⟨p,hp,rfl⟩
    have e : rel I A B p l := (Finset.mem_filter.mp hp).2
    exact ⟨(left A B p).mpr e.1,p,Finset.mem_filter.mpr ⟨Finset.mem_univ _,e.2.2⟩,rfl⟩
theorem kept_card (A B : Finset (Fin n)) : (kept A B).card=A.card+B.card := by
  classical
  unfold kept
  rw [Finset.card_union_of_disjoint,Finset.card_image_of_injective _ Fin.val_injective,
    Finset.card_image_of_injective _ (show Function.Injective (fun l : Fin n=>n+l.val) from
       fun _ _ e=>Fin.ext (Nat.add_left_cancel e))]
  apply Finset.disjoint_left.mpr
  rintro i h k
  obtain ⟨u,_,rfl⟩ := Finset.mem_image.mp h
  obtain ⟨v,_,eq⟩ := Finset.mem_image.mp k
  have := u.isLt
  omega

theorem deleted_card (A B : Finset (Fin n)) (D : Finset ℕ) (sub : D⊆kept A B) :
    (A\nextP A D).card+(B\nextL B D).card=D.card := by
  have h := congrArg Finset.card (next_eq A B D)
  rw [kept_card,Finset.card_sdiff_of_subset sub,kept_card] at h
  have pa : nextP A D⊆A := Finset.filter_subset _ _
  have lb : nextL B D⊆B := Finset.filter_subset _ _
  rw [Finset.card_sdiff_of_subset pa, Finset.card_sdiff_of_subset lb]
  have p := Finset.card_le_card pa
  have l := Finset.card_le_card lb
  have up := Finset.card_le_card sub
  rw [kept_card] at up
  omega

theorem new_ref (A B : Finset (Fin n)) (D : Finset ℕ) (sub : D⊆kept A B) {i : ℕ} (hi : i<n+n) :
    (ref (keep A (nextP A D)) (keep B (nextL B D)) i).isNone=true ↔ i∈D := by
  classical
  have lo (p : Fin n) (hd : p.val∈D) : p∈A := (left A B p).mp (sub hd)
  have up (l : Fin n) (hd : n+l.val∈D) : l∈B := (right A B l).mp (sub hd)
  by_cases h : i<n
  · let p : Fin n := ⟨i,h⟩
    change (ref _ _ p.val).isNone=true ↔ p.val∈D
    by_cases v : p.val∈D <;> simp [ref,left,keep,nextP,v,lo p]
  · let l : Fin n := ⟨i-n,by omega⟩
    have eq : i=n+l.val := by dsimp [l]; omega
    rw [eq]
    by_cases v : n+l.val∈D <;> simp [ref,right,keep,nextL,v,up l]
theorem safe_degree {V M : Finset ℕ} {G : ℕ→Finset ℕ}
    (safe : Safe (neighbors I) V M G) {x : ℕ} (hx : x∈V) :
    3≤(V ∩ neighbors I x).card := by
  by_cases h : x∈M
  · have floor := Finset.card_le_card (safe.saved x h)
    rw [safe.triple x h] at floor
    exact floor
  · have := safe.unmarked x hx h
    omega

theorem allowed {P L : Finset (Fin n)} (a : Stage I P L) (M : Finset ℕ) (G : ℕ→Finset ℕ)
    (safe : Safe (neighbors I) (kept a.A a.B) M G) (D prot : Finset ℕ)
    (core : kept P L ⊆ prot) (ret : reserve M G⊆prot)
    (sub : D⊆kept a.A a.B \ prot) (small : D.card≤24) :
    Allowed I a (nextP a.A D) (nextL a.B D) ∧
    ∀x∈kept a.A a.B \ prot,3≤((kept a.A a.B \ D) ∩ neighbors I x).card := by
  classical
  have avoid : Disjoint D prot := Finset.disjoint_left.mpr fun i hi=> (Finset.mem_sdiff.mp (sub hi)).2
  obtain ⟨G',_,post,_,survive⟩ := transition (neighbors I) (kept a.A a.B) M G safe D
    (avoid.mono_right ret) small
  constructor
  · refine ⟨Finset.filter_subset _ _,Finset.filter_subset _ _,?_,?_,?_,?_,?_⟩
    · intro p hp
      exact Finset.mem_filter.mpr ⟨a.pointCore hp,fun d=>Finset.disjoint_left.mp avoid d (core ((left P L p).mpr hp))⟩
    · intro l hl
      exact Finset.mem_filter.mpr ⟨a.lineCore hl,fun d=>Finset.disjoint_left.mp avoid d (core ((right P L l).mpr hl))⟩
    · rw [deleted_card _ _ _ (sub.trans Finset.sdiff_subset)]
      exact small
    · intro p hp
      have h := safe_degree I post (x:=p.val) (by rw [←next_eq]; exact (left _ _ p).mpr hp)
      rw [←next_eq,p_neighbors I _ _ p hp,Finset.card_map] at h
      exact h
    · intro l hl
      have h := safe_degree I post (x:=n+l.val) (by rw [←next_eq]; exact (right _ _ l).mpr hl)
      rw [←next_eq,l_neighbors I _ _ l hl,Finset.card_map] at h
      exact h
  · intro x hx
    obtain ⟨inV,free⟩ := Finset.mem_sdiff.mp hx
    exact survive x inV (fun marked=>free (ret (Finset.mem_union_left _ marked)))
theorem neighbor_after {A B : Finset (Fin n)} {D : Finset ℕ} {x : ℕ}
    (hx : x∈kept A B) (many : 3≤((kept A B\D)∩neighbors I x).card) :
    ∃y∉D,∃p l : Fin n,rel I A B p l ∧
      ((x=p.val ∧ y=n+l.val) ∨ (x=n+l.val ∧ y=p.val)) := by
  obtain ⟨y,hy⟩ := Finset.card_pos.mp (show 0<((kept A B\D)∩neighbors I x).card by omega)
  obtain ⟨yd,nb⟩ := Finset.mem_inter.mp hy
  obtain ⟨yv,notD⟩ := Finset.mem_sdiff.mp yd
  refine ⟨y,notD,?_⟩
  rcases Finset.mem_union.mp hx with point|line
  · obtain ⟨p,pa,rfl⟩ := Finset.mem_image.mp point
    have m := Finset.mem_inter.mpr ⟨yv,nb⟩
    rw [p_neighbors I A B p pa] at m
    obtain ⟨l,pl,e⟩ := Finset.mem_map.mp m
    exact ⟨p,l,(Finset.mem_filter.mp pl).2,Or.inl ⟨rfl,e.symm⟩⟩
  · obtain ⟨l,lb,rfl⟩ := Finset.mem_image.mp line
    have m := Finset.mem_inter.mpr ⟨yv,nb⟩
    rw [l_neighbors I A B l lb] at m
    obtain ⟨p,pl,e⟩ := Finset.mem_map.mp m
    exact ⟨p,l,(Finset.mem_filter.mp pl).2,Or.inr ⟨rfl,e.symm⟩⟩
end IncidenceAllowedGeometry
