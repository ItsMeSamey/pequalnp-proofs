import IncidenceReciprocalChoice
namespace IncidenceChosenEnds
open IncidenceReciprocalChoice
variable {α : Type*} [Fintype α] [DecidableEq α]

def removed (f : α→α) (rank : α→ℕ) (x : α) :=
  f x≠x ∧ f (f x)=x ∧ rank (f x)<rank x

theorem no_shared (f : α→α) (rank : α→ℕ)
    (forks : ∀ x y, x≠y → f x=y → f y=x → rank x≠rank y)
    {x y : α} (ex : ¬removed f rank x) (ey : ¬removed f rank y)
    (ne : x≠y) (xy : f x=y) : f y≠x := by
  intro yx
  have dif := forks x y ne xy yx
  by_cases h : rank x<rank y
  · exact ey ⟨by simpa [yx] using ne,by simp [yx,xy],by simpa [yx] using h⟩
  · have h' : rank y<rank x := by omega
    exact ex ⟨by simpa [xy] using (Ne.symm ne),by simp [xy,yx],by simpa [xy] using h'⟩

theorem bad_precedes (D : α→Finset α) (rank : α→ℕ) (self : ∀x,x∉D x)
    (forks : ∀x y, x≠y → (D x).Nonempty → (D y).Nonempty → rank x≠rank y) :
    ∃ f, Valid D f ∧ ∀ x, removed f rank x → ∀ y∈D x,
      f y=x ∧ rank y<rank x ∧ ¬removed f rank y := by
  obtain ⟨f,hf,localOpt⟩ := select_latest D rank self
  refine ⟨f,hf,?_⟩
  intro x hx y hy
  obtain ⟨xz,recip,late⟩ := hx
  have xy : x≠y := by rintro rfl; exact self _ hy
  obtain ⟨fy,le⟩ := localOpt x (f x) rfl recip (Ne.symm xz) late.le y hy
  have ny : (D y).Nonempty := by
    by_contra h
    have yy : f y=y := by simpa [h] using hf y
    exact xy (fy.symm.trans yy)
  have dif := forks x y xy ⟨y,hy⟩ ny
  have lt : rank y<rank x := by omega
  refine ⟨fy,lt,?_⟩
  intro h
  have l := h.2.2
  rw [fy] at l
  omega
#print axioms bad_precedes
end IncidenceChosenEnds
