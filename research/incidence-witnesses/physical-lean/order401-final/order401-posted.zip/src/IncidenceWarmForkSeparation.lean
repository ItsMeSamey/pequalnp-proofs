import IncidenceWarmTraceDistinct
import IncidenceWarmTraceLineDistinct
import IncidenceWarmTraceShadow
namespace IncidenceWarmForkSeparation
open SparseIncidence IncidenceStartNormalization IncidenceRobust IncidencePointShield
open IncidencePointFirstFork IncidenceWarmTraceShadow
variable {n : Nat} (I : Fin n→Fin n→Prop) [DecidableRel I] (C : Circuit n)

theorem points_distinct (pos : flags C I) (neg : negatives C I 401 400)
    (degree : ∀ l,Fintype.card {p // I p l}=402)
    (unique : ∀ a b,a≠b → ∃! l,I a l ∧ I b l) (hn : n=161203)
    (x y : Fin n) (ne : x≠y) (W : Finset (Fin n)) (small : W.card≤399)
    (clean : ∀l∈W,¬I x l) (warm : (single x,bits W)∈C.wire (fork C x.val)) :
    fork C x.val≠fork C y.val := by
  intro eq
  obtain ⟨l,no,hit⟩ := IncidenceWarmTraceDistinct.outsider I degree unique hn x y ne
  have cap := fork_bound C (by have := x.isLt; omega : x.val<n+n+C.size)
  exact IncidenceWarmTraceDistinct.separate I C pos neg x y l no hit W small clean _ cap warm
    (eq ▸ blocked C y.val)

theorem lines_distinct (pos : flags C I) (neg : negatives C I n 2)
    (degree : ∀ l,Fintype.card {p // I p l}=402)
    (unique : ∀ a b,a≠b → ∃! l,I a l ∧ I b l)
    (x y : Fin n) (ne : x≠y) (W : Finset (Fin n))
    (clean : ∀p∈W,¬I p x) (warm : (bits W,single x)∈C.wire (fork C (n+x.val))) :
    fork C (n+x.val)≠fork C (n+y.val) := by
  intro eq
  have existsOut : ∃p,¬I p x ∧ I p y := by
    by_contra! bad
    have incl : points I y ⊆ points I x := by
      intro p h
      have inc := (Finset.mem_filter.mp h).2
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,by_contra (fun h=>bad p h inc)⟩
    have cap := point_overlap I unique ne.symm
    rw [Finset.inter_eq_left.mpr incl,points_card I degree] at cap
    omega
  obtain ⟨p,no,hit⟩ := existsOut
  have cap := fork_bound C (by have := x.isLt; omega : n+x.val<n+n+C.size)
  exact IncidenceWarmTraceLineDistinct.separate I C pos neg x y p no hit W clean _ cap warm
    (eq ▸ blocked C (n+y.val))

#print axioms points_distinct
#print axioms lines_distinct
end IncidenceWarmForkSeparation
