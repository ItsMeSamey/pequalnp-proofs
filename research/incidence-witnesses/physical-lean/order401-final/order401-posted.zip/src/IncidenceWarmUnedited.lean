import IncidenceWarmDichotomy
namespace IncidenceWarmDichotomy
open SparseIncidence IncidenceStartNormalization IncidencePointWarmMasks
open IncidenceReciprocalChoice IncidenceChosenEnds

/-- Every retained owner's original fork is cold on sparse masks avoiding its two blockers. -/
theorem retained {n : ℕ} (C : Circuit n) (I : Fin n → Fin n → Prop) (c : Fin n → ℕ)
    (O : Finset (Fin n)) (f : Fin n → Fin n) (valid : Valid (D C I c O) f)
    {x : Fin n} (owner : x∈O) (keep : x∉edits C I c O f) :
    ¬removed f c x ∧ ¬Warm C I c x {x,f x} := by
  classical
  by_cases nonempty : (D C I c O x).Nonempty
  · have chosen : f x∈D C I c O x := by simpa [nonempty] using valid x
    obtain ⟨_,warm,_,cold⟩ := (mem_D C I c O x (f x)).mp chosen
    refine ⟨?_,cold⟩
    intro removedX
    exact keep (Finset.mem_filter.mpr ⟨owner,warm,Or.inr removedX⟩)
  · have fixed : f x=x := by simpa [nonempty] using valid x
    have empty : D C I c O x=∅ := Finset.not_nonempty_iff_eq_empty.mp nonempty
    refine ⟨fun rem => rem.1 fixed,?_⟩
    simpa [fixed] using
      (show ¬Warm C I c x {x} from fun warm =>
        keep (Finset.mem_filter.mpr ⟨owner,warm,Or.inl empty⟩))
/-- Injectivity on physical owners suffices to choose all exceptional endpoints at once. -/
theorem choices {n : ℕ} (C : Circuit n) (I : Fin n → Fin n → Prop) (c : Fin n → ℕ)
    (O : Finset (Fin n)) (inj : Set.InjOn c (O : Set (Fin n))) :
    ∃ f, Valid (D C I c O) f ∧ ∀ x, removed f c x → ∀ y∈D C I c O x,
      f y=x ∧ c y<c x ∧ ¬removed f c y := by
  apply bad_precedes
  · intro x hx
    exact ((mem_D C I c O x x).mp hx).2.2.1 rfl
  · rintro x y xy ⟨u,hu⟩ ⟨v,hv⟩ eq
    exact xy (inj ((mem_D C I c O x u).mp hu).1 ((mem_D C I c O y v).mp hv).1 eq)
#print axioms choices
#print axioms retained
end IncidenceWarmDichotomy
