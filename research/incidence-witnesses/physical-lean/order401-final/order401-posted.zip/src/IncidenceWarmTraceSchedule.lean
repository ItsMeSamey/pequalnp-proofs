import IncidenceWarmBooked
namespace IncidenceWarmTraceSchedule
noncomputable def schedule (owners : Finset Nat) (stop : Nat→Nat) (j : Nat) : Option Nat :=
  if e : ∃ x∈owners,stop x=j then some e.choose else none

theorem schedule_spec (owners : Finset Nat) (stop : Nat→Nat) (j x : Nat)
    (pin : schedule owners stop j=some x) : x∈owners ∧ stop x=j := by
  unfold schedule at pin
  split at pin
  next e => exact (Option.some.inj pin) ▸ e.choose_spec
  next => contradiction

theorem terminal (owners : Finset Nat) (stop : Nat→Nat) (x : Nat) (hx : x∈owners)
    (unique : ∀a∈owners,∀b∈owners,stop a=stop b → a=b) :
    schedule owners stop (stop x)=some x := by
  unfold schedule
  have e : ∃a∈owners,stop a=stop x := ⟨x,hx,rfl⟩
  rw [dif_pos e]
  exact congrArg some (unique _ e.choose_spec.1 _ hx e.choose_spec.2)

theorem absent (owners : Finset Nat) (stop : Nat→Nat) (j : Nat)
    (no : ∀x∈owners,stop x≠j) : schedule owners stop j=none := by
  have h : ¬ ∃x∈owners,stop x=j := by rintro ⟨x,hx,eq⟩; exact no x hx eq
  simp [schedule,h]

theorem covered (owners : List Nat) (stop : Nat→Nat) (path : Nat→List Nat)
    (mem : ∀x∈owners,stop x∈path x) (j : Nat) (outside : j∉owners.flatMap path) :
    schedule owners.toFinset stop j=none := by
  apply absent
  intro x hx eq
  apply outside
  rw [←eq]
  exact List.mem_flatMap.mpr ⟨x,List.mem_toFinset.mp hx,mem x (List.mem_toFinset.mp hx)⟩
end IncidenceWarmTraceSchedule
