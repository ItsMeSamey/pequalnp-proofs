import IncidenceActualLineSchedule
import IncidenceActualLineOutput
import IncidenceWarmLineCensus
namespace IncidenceActualLineChoice
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield IncidenceWarmCompiler
open IncidenceLineRoutedSlots
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

theorem sole_card : (O C).card=soleCount C n := by
  have eq : (O C).image Fin.val=(Finset.range n).filter (fun i=>uses C (n+i)=1) := by
    ext i
    constructor
    · intro h
      obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp h
      exact Finset.mem_filter.mpr ⟨Finset.mem_range.mpr x.isLt,(Finset.mem_filter.mp hx).2⟩
    · intro h
      obtain ⟨range,one⟩ := Finset.mem_filter.mp h
      exact Finset.mem_image.mpr ⟨⟨i,Finset.mem_range.mp range⟩,Finset.mem_filter.mpr ⟨Finset.mem_univ _,one⟩,rfl⟩
  unfold soleCount
  rw [←eq,Finset.card_image_of_injective _ Fin.val_injective]

theorem lines (degree : ∀l,Fintype.card {p // I p l}=402) (join : ∀p r,p≠r→∃!l,I p l∧I r l)
    (hn : n=161203) (bc : binary C) (pc : flags C I) (nc : negatives C I n 401)
    (andL : soleAnd C n) (upper : C.size≤646424) : soleCount C n≤3382 := by
  classical
  have neg2 : negatives C I n 2 := fun a b ha hb=>nc a b ha (by omega)
  obtain ⟨f,valid,order⟩ := choice C I pc neg2 degree join
  let E := M C I f
  have sub : E⊆O C := fun _ h=>(Finset.mem_filter.mp h).1
  obtain ⟨inject,w,paid⟩ := install C I pc nc andL degree join hn f
  have pos (p l : Fin n) (inc : I p l) :=
    IncidenceLineWarm.flag_mask C I E inject (rank C) w pc l p inc
      (fun _=>IncidenceWarmTraceShadow.blocked C (n+l.val))
  apply IncidenceWarmLineCensus.selected C I degree join hn bc pc nc upper (O C \ E) f
    (cold C I f valid) (fun x hx y hy=>separated C I pc neg2 degree join f valid x y hx hy) E.card
    _ (IncidenceLineWarm.drops E) inject w.pins _ _ paid pos (fun a b _ hb=>negative C I nc f valid order inject w a b hb)
  · rw [←sole_card,Finset.card_sdiff_of_subset sub]
    have h := Finset.card_le_card sub
    omega
  · intro p i _ mem
    obtain ⟨l,_,rfl⟩ := Finset.mem_image.mp mem
    unfold hit
    rw [(C.inputs l).2]
    simp
  · intro p j hj
    cases h : inject j with
    | none => simp [CircuitRewire.read,h]
    | some a =>
      obtain ⟨l,_,rfl,_⟩ := w.located j hj a h
      simp [CircuitRewire.read,(C.inputs l).2]
#print axioms lines
end IncidenceActualLineChoice
