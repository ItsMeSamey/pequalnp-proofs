import IncidenceWarmTraceFactors
namespace IncidenceWarmTrackedRows
open IncidenceStartNormalization IncidencePointCorridor
open IncidenceRobust IncidencePointFirstFork IncidencePointShield
variable {n : Nat} (C : Circuit n) (S : Finset (Fin n))
variable (paths : ∀ x : Fin n,Path (n+n) C.code x.val (fork C x.val))

noncomputable def K : Finset Nat := by
  classical exact (Finset.range C.size).filter fun g=>∃x∈S,∃ b : Bool,(g,b)∈(paths x).ports
noncomputable def G : Finset Nat := (K C S paths).filter fun g=>(C.code g).op=.meet
noncomputable def side (u : G C S paths) : Bool := by
  classical exact decide (∃x∈S,(u.val,true)∈(paths x).ports)
noncomputable def sib (u : G C S paths) : Nat := inputPort (C.code u.val) (!(side C S paths u))

theorem member (checks : ∀x∈S,(paths x).check C.output x.val C.size)
    (x : Fin n) (hx : x∈S) (g : Nat) (b : Bool) (occ : (g,b)∈(paths x).ports) :
    g∈G C S paths ↔ (C.code g).op=.meet := by
  have bound := (port_guards (paths x) _ _ _ _ _ (checks x hx) occ).1
  have hk : g∈K C S paths := Finset.mem_filter.mpr ⟨Finset.mem_range.mpr bound,⟨x,hx,b,occ⟩⟩
  exact ⟨fun h=>(Finset.mem_filter.mp h).2,fun op=>Finset.mem_filter.mpr ⟨hk,op⟩⟩

theorem side_eq (I : Fin n→Fin n→Prop) (pos : flags C I) (neg : negatives C I 401 400)
    (joins : ∀x y : Fin n,∃l,I x l ∧ I y l)
    (checks : ∀x∈S,(paths x).check C.output x.val C.size) (x : Fin n) (hx : x∈S)
    (g : Nat) (b : Bool) (occ : (g,b)∈(paths x).ports) (hg : g∈G C S paths) :
    sib C S paths ⟨g,hg⟩=inputPort (C.code g) (!b) := by
  have op := ((member C S paths checks x hx g b occ).mp hg)
  cases b with
  | true =>
    have seen : ∃ y∈S,(g,true)∈(paths y).ports := ⟨x,hx,occ⟩
    simp [sib,side,seen]
  | false =>
    have no : ¬ ∃ y∈S,(g,true)∈(paths y).ports := by
      rintro ⟨y,hy,h⟩
      obtain ⟨l,a,b⟩ := joins x y
      have eq := side_unique C I pos neg x y l a b (paths x) (paths y) (checks x hx) (checks y hy) g false true occ h op
      contradiction
    simp [sib,side,no]

theorem sub : G C S paths ⊆ Finset.range C.size ∩ K C S paths := by
  intro g h
  have hk := (Finset.mem_filter.mp h).1
  exact Finset.mem_inter.mpr ⟨(Finset.mem_filter.mp hk).1,hk⟩

theorem sib_bound (u : G C S paths) : sib C S paths u<n+n+C.size := by
  have bound := Finset.mem_range.mp (Finset.mem_inter.mp (sub C S paths u.property)).1
  obtain ⟨a,b⟩ := C.earlier _ bound
  unfold sib inputPort
  split <;> omega
#print axioms side_eq
end IncidenceWarmTrackedRows
