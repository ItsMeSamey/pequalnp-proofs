import IncidencePointShield
import Research.IncidenceRobust
namespace IncidencePointShield
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceRobust
def bits {n : Nat} (T : Finset (Fin n)) : Fin n→Bool := fun i=>decide (i∈T)
theorem bits_card {n : Nat} (T : Finset (Fin n)) :
    Fintype.card {i // bits T i=true}=T.card := by
  simp [bits,Fintype.card_subtype]
theorem monotone {n : Nat} (C : Circuit n) (i : Nat) (hi : i<n+n+C.size) :
    Upward (C.wire i) := by
  apply wire_upward C.wire C.inputs _ i hi
  intro j hj
  obtain ⟨a,b⟩ := C.earlier j hj
  refine ⟨_,a,_,b,?_⟩
  have law := C.law j hj
  cases e : (C.code j).op with
  | join => exact Or.inl (by simpa [Gate.eval,Op.eval,e] using law)
  | meet => exact Or.inr (Or.inr (Or.inr (by simpa [Gate.eval,Op.eval,e] using law)))
  | copy => exact Or.inr (Or.inl (by simpa [Gate.eval,Op.eval,e] using law))
  | zero => exact Or.inr (Or.inr (Or.inl (by simpa [Gate.eval,Op.eval,e] using law)))

theorem foreign_zero {n : Nat} (I : Fin n→Fin n→Prop) (C : Circuit n)
    (pos : flags C I) (neg : negatives C I 401 400) (x line : Fin n) (incident : I x line)
    (cut : Nat) (bound : cut<n+n+C.size)
    (paths : shadow (n+n) C.code x.val cut C.size C.output=false)
    (T : Finset (Fin n)) (small : T.card≤399) :
    ((fun _=>false),bits T)∉C.wire cut := by
  classical
  let S := insert line T
  let u : Input n := (fun _=>false,bits S)
  let v : Input n := (single x,bits S)
  have sc : S.card≤400 := (Finset.card_insert_le _ _).trans (by omega)
  have no : u∉C.wire C.output := neg _ _ (by simp [u,Fintype.card_subtype])
    ((bits_card S).le.trans sc) (by intro p l hp; simp at hp)
  have yes : v∈C.wire C.output := by
    apply monotone C C.output C.output_lt _ (pos x line incident)
    refine ⟨fun _ h=>h,?_⟩
    intro l hl
    have eq : l=line := by simpa [single] using hl
    simp [v,bits,S,eq]
  have ext : Extends u v := by
    constructor
    · intro i bad
      change false=true at bad
      cases bad
    · exact fun _ h=>h
  have same (i : Nat) (hi : i<n+n) (ne : i≠x.val) : u∈C.wire i ↔ v∈C.wire i := by
    by_cases low : i<n
    · let y : Fin n := ⟨i,low⟩
      have diff : y≠x := by intro e; exact ne (congrArg Fin.val e)
      rw [(C.inputs y).1]
      change (false=true ↔ decide (y=x)=true)
      simp [diff]
    · let l : Fin n := ⟨i-n,by omega⟩
      have ix : i=n+l.val := by dsimp [l]; omega
      rw [ix,(C.inputs l).2]
      rfl
  have reject := low_at_cut (n+n) C.size C.code C.wire C.earlier C.law x.val cut C.output
    u v same (monotone C cut bound ext) C.output_lt paths no yes
  apply mt (monotone C cut bound _) reject
  refine ⟨fun _ h=>h,?_⟩
  intro i h
  have mem : i∈T := by simpa [bits] using h
  simpa [u,bits,S] using (Finset.mem_insert_of_mem mem : i∈S)
#print axioms foreign_zero
end IncidencePointShield
