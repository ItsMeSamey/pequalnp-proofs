import IncidenceWarmCompiler
namespace IncidenceWarmCompiler
open CircuitRewire IncidenceZeroRestriction IncidenceStartNormalization
variable {Z : Type*}

/-- A concrete topologically ordered evaluation, including both virtual phases. -/
def vals (off : ℕ) (src : ℕ→Set Z) (rows : ℕ→Gate) : ℕ → ℕ→Set Z
  | 0 => src
  | k+1 =>
    let prev := vals off src rows k
    put prev (off+k) ((rows k).eval prev)

private theorem stable (off : ℕ) (src : ℕ→Set Z) (rows : ℕ→Gate)
    {i a b : ℕ} (hi : i<off+a) (hab : a≤b) :
    vals off src rows b i=vals off src rows a i := by
  induction b,hab using Nat.le_induction with
  | base => rfl
  | succ j hj ih =>
    simpa [vals,put,show i≠off+j by omega] using ih

theorem vals_inputs (off : ℕ) (src : ℕ→Set Z) (rows : ℕ→Gate)
    (k i : ℕ) (hi : i<off) : vals off src rows k i=src i := by
  exact stable off src rows (a:=0) (by omega) (Nat.zero_le k)

theorem vals_law (off : ℕ) (src : ℕ→Set Z) (rows : ℕ→Gate) {j s : ℕ}
    (hj : j<s) (ord : (rows j).left<off+j ∧ (rows j).right<off+j) :
    vals off src rows s (off+j)=(rows j).eval (vals off src rows s) := by
  rw [stable off src rows (a:=j+1) (i:=off+j) (by omega) (by omega : j+1≤s)]
  simp only [vals,put,ite_true,Gate.eval]
  rw [stable off src rows ord.1 (by omega : j≤s),stable off src rows ord.2 (by omega : j≤s)] <;> simp

def target (m : ℕ) (s : ℕ) (B : ℕ→Set Z) (code : ℕ→Gate)
    (drop : Finset ℕ) (fork : ℕ→Option ℕ) :=
  vals (2*m) (fun i => CircuitRewire.read B (init m drop i)) (stage m code fork) (2*s)

theorem orderedStage (m s : ℕ) (code : ℕ→Gate) (fork : ℕ→Option ℕ)
    (ord : ∀ j<s,(code j).left<m+j ∧ (code j).right<m+j)
    (pins : ∀ j<s,∀ x,fork j=some x→x<m) :
    ∀ k<2*s,(stage m code fork k).left<2*m+k ∧ (stage m code fork k).right<2*m+k := by
  intro k hk
  have hj : k/2<s := by omega
  have o := ord _ hj
  by_cases even : k%2=0
  · have bound (i : ℕ) (hi : i<m+k/2) : addr m i<2*m+k := by
      unfold addr
      split <;> omega
    simpa [stage,even] using And.intro (bound _ o.1) (bound _ o.2)
  · cases h : fork (k/2) with
    | none => simp [stage,even,h] <;> omega
    | some x =>
      have := pins _ hj x h
      simp [stage,even,h] <;> omega

theorem actual (m s : ℕ) (B : ℕ→Set Z) (code : ℕ→Gate) (drop : Finset ℕ)
    (fork : ℕ→Option ℕ) (ord : ∀ j<s,(code j).left<m+j ∧ (code j).right<m+j)
    (pins : ∀ j<s,∀ x,fork j=some x→x<m) :
    CorrectLiteral (2*m) m (2*s) (target m s B code drop fork) B
      (init m drop) (run m code drop fork s) := by
  apply compiled _ _ _ _ _ _ _ ord pins
  · exact fun i hi => vals_inputs _ _ _ _ _ hi
  · exact fun k hk => vals_law _ _ _ hk (orderedStage m s code fork ord pins k hk)

def editedWire (m s : ℕ) (B : ℕ→Set Z) (code : ℕ→Gate) (drop : Finset ℕ)
    (fork : ℕ→Option ℕ) (i : ℕ) := target m s B code drop fork (addr m i)

theorem editedInput (m s : ℕ) (B : ℕ→Set Z) (code : ℕ→Gate) (drop : Finset ℕ)
    (fork : ℕ→Option ℕ) (i : ℕ) (hi : i<m) :
    editedWire m s B code drop fork i=(if i∈drop then ∅ else B i) := by
  unfold editedWire target
  rw [show addr m i=i by simp [addr,hi],vals_inputs _ _ _ _ _ (by omega)]
  by_cases h : i∈drop <;> simp [init,hi,h,CircuitRewire.read]

theorem editedRow (m s : ℕ) (B : ℕ→Set Z) (code : ℕ→Gate) (drop : Finset ℕ)
    (fork : ℕ→Option ℕ) (ord : ∀ j<s,(code j).left<m+j ∧ (code j).right<m+j)
    (pins : ∀ j<s,∀ x,fork j=some x→x<m) (j : ℕ) (hj : j<s) :
    let E := editedWire m s B code drop fork
    E (m+j)=(code j).eval E ∪ CircuitRewire.read B (fork j) := by
  let X := target m s B code drop fork
  have law (k : ℕ) (hk : k<2*s) : X (2*m+k)=(stage m code fork k).eval X :=
    vals_law _ _ _ hk (orderedStage m s code fork ord pins k hk)
  have base := law (2*j) (by omega)
  have last := law (2*j+1) (by omega)
  have e : addr m (m+j)=2*m+(2*j+1) := by unfold addr; split <;> omega
  have orig : X (2*m+2*j)=(code j).eval (editedWire m s B code drop fork) := by
    simpa [stage,Gate.eval,editedWire,X] using base
  change X (addr m (m+j))=_
  rw [e]
  cases h : fork j with
  | none =>
    simpa [stage,show (2*j+1)/2=j by omega,h,Gate.eval,Op.eval,orig,CircuitRewire.read] using last
  | some x =>
    have hx := pins j hj x h
    have val : X (m+x)=B x := by
      change vals _ _ _ _ _=_
      rw [vals_inputs _ _ _ _ _ (by omega)]
      simp [init,show ¬m+x<m by omega,CircuitRewire.read]
    simpa [stage,show (2*j+1)/2=j by omega,h,Gate.eval,Op.eval,orig,CircuitRewire.read,val] using last

end IncidenceWarmCompiler
