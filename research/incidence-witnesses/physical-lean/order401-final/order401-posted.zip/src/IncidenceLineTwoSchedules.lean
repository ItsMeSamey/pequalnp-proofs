import IncidenceStartNormalization
namespace IncidenceLineTwoSchedules
open IncidenceStartNormalization
/-- Separate pruning receipts buy each missing OR's entire weighted contribution.
These caps concern genuinely different paid gates. -/
theorem census {H edited charged originalW leftW removed : ℕ}
    (classification : H=edited+charged)
    (physical : 3106*charged≤originalW)
    (survive : originalW≤leftW+402*removed)
    (s52 : 64803606*(edited+removed)+(52*401)*leftW≤3382*64803606)
    (s53 : 64803606*(edited+removed)+(53*401)*leftW≤3386*64803606) : H≤3382 := by
  apply line_census classification
  · have h := Nat.mul_le_mul_left (52*401) (physical.trans survive)
    omega
  · have h := Nat.mul_le_mul_left (53*401) (physical.trans survive)
    omega
#print axioms census
end IncidenceLineTwoSchedules
