import IncidenceEditedLineCensus
import IncidenceWarmLiveBookings
import IncidenceLineNativeFork
namespace IncidenceWarmLineCensus
open SparseIncidence CircuitRewire IncidenceWarmCompiler IncidenceStartNormalization
open IncidenceLineGateBooking IncidencePointFirstFork

theorem selected {n : ℕ} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (degree : ∀l,Fintype.card {p // I p l}=402)
    (join : ∀p r,p≠r→∃!l,I p l∧I r l) (hn : n=161203)
    (bc : binary C) (pc : flags C I) (nc : negatives C I n 401)
    (upper : C.size≤646424)
    (charged : Finset (Fin n)) (w : Fin n→Fin n)
    (cold : ∀x∈charged,(avoid I x (w x),single x)∉C.wire (fork C (n+x.val)))
    (sep : ∀x∈charged,∀y∈charged,x≠y→w x=y→w y≠x)
    (edited : ℕ) (split : soleCount C n=edited+charged.card)
    (drop : Finset ℕ) (inject : ℕ→Option ℕ)
    (pins : ∀j<C.size,∀x,inject j=some x→x<n+n)
    (dark : ∀p : Fin n,∀i<n+n,i∈drop→¬IncidenceLineRoutedSlots.hit C i p)
    (off : ∀p : Fin n,∀j<C.size,(single p,fun _=>false)∉read C.wire (inject j))
    (paid : (run (n+n) C.code drop inject C.size).size+edited≤C.size)
    (positive : ∀p l,I p l→(single p,single l)∈editedWire (n+n) C.size C.wire C.code drop inject C.output)
    (negative : ∀ a b,Fintype.card {i // a i=true}≤n → Fintype.card {i // b i=true}≤2 →
      (∀p l,a p=true→b l=true→¬I p l) →
      (a,b)∉editedWire (n+n) C.size C.wire C.code drop inject C.output) :
    soleCount C n ≤3382 := by
  by_cases sz : C.size=0
  · simp [soleCount,IncidenceStartNormalization.uses,sz]
  have nonzero : 0<C.size := Nat.pos_of_ne_zero sz
  let l : Fin n := ⟨0,by omega⟩
  obtain ⟨p⟩ := Fintype.card_pos_iff.mp (show 0<Fintype.card {p // I p l} by rw [degree] <;> norm_num)
  have alive : (editedWire (n+n) C.size C.wire C.code drop inject C.output).Nonempty :=
    ⟨(single p.val,single l),positive p.val l p.property⟩
  obtain ⟨D,bd,ld,out,lost,cost,transfer⟩ := IncidenceWarmLiveBookings.compile C (by omega)
    I degree drop inject pins dark off alive edited paid
  apply IncidenceEditedLineCensus.from_transfer C D I degree join hn bc pc nc bd ld
      (by intro p l h; rw [out]; exact positive p l h)
      (by intro a b ha hb hi; rw [out]; exact negative a b ha hb hi)
      charged w (fun x=>fork C (n+x.val))
      (fun x _=>IncidenceLineNativeFork.native C nonzero x) cold sep edited split
  intro own book ok
  obtain ⟨ownD,bkD,good,lim⟩ := transfer own book ok
  exact ⟨ownD,bkD,lost,good,lim,cost.trans upper⟩
end IncidenceWarmLineCensus
