import IncidenceWarmReadback
namespace IncidenceWarmCompiler
open CircuitRewire IncidenceZeroRestriction IncidenceStartNormalization

theorem physical {n : ℕ} (C : Circuit n) (drop : Finset ℕ) (fork : ℕ→Option ℕ)
    (pins : ∀ j<C.size,∀ x,fork j=some x→x<n+n)
    (live : (editedWire (n+n) C.size C.wire C.code drop fork C.output).Nonempty) :
    ∃ D : Circuit n, D.size=(run (n+n) C.code drop fork C.size).size ∧
      binary D ∧ D.wire D.output=editedWire (n+n) C.size C.wire C.code drop fork C.output := by
  let m := n+n
  let p := run m C.code drop fork C.size
  let X := target m C.size C.wire C.code drop fork
  obtain ⟨_,bound,norm,Y,inp,law,agree⟩ := actual m C.size C.wire C.code drop fork C.earlier pins
  have hi : addr m C.output<2*m+2*C.size := by
    have ho : C.output<m+C.size := C.output_lt
    unfold addr
    split <;> omega
  have ha : X (addr m C.output)=CircuitRewire.read Y (p.refs (addr m C.output)) :=
    agree _ hi
  obtain ⟨z,hz⟩ := live
  change z∈X (addr m C.output) at hz
  cases hr : p.refs (addr m C.output) with
  | none =>
    rw [ha,hr] at hz
    exact False.elim hz
  | some o =>
    have out : o<m+p.size := bound _ hi _ hr
    let D : Circuit n := {
      size := p.size, output := o, code := p.code, wire := Y, output_lt := out
      earlier := fun j hj => ⟨(norm j hj).1,(norm j hj).2.1⟩
      law := law
      inputs := by
        intro i
        exact ⟨(inp i.val (by dsimp [m]; omega)).trans (C.inputs i).1,
          (inp (n+i.val) (by dsimp [m]; omega)).trans (C.inputs i).2⟩ }
    refine ⟨D,rfl,fun j hj => (norm j hj).2.2,?_⟩
    change Y o=X (addr m C.output)
    simpa [hr,CircuitRewire.read] using ha.symm

end IncidenceWarmCompiler
