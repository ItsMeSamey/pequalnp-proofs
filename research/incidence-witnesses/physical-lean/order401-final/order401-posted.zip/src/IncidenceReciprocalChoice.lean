import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Finset.Max
import Mathlib.Data.Fintype.Basic
import Lean.Elab.Tactic.Omega
import Mathlib.Data.Fintype.Pi
namespace IncidenceReciprocalChoice
open scoped BigOperators
variable {α : Type*} [Fintype α] [DecidableEq α]

def Valid (D : α→Finset α) (f : α→α) := ∀ i,
  (if (D i).Nonempty then f i ∈ D i else f i=i)

def term (f : α→α) (price : α→α→ℕ) (i : α) :=
  if f i ≠ i ∧ f (f i)=i then price i (f i) else 0

def score (f : α→α) (price : α→α→ℕ) := ∑ i, term f price i

private theorem score_split (f : α→α) (price : α→α→ℕ) (x y z : α)
    (xy : x≠y) (xz : x≠z) (yz : y≠z) :
    score f price =
      (∑ i ∈ (((Finset.univ.erase x).erase y).erase z), term f price i) +
        term f price z + term f price y + term f price x := by
  unfold score
  rw [Finset.sum_erase_add _ _ (by simp [xz.symm,yz.symm] : z∈(Finset.univ.erase x).erase y),
    Finset.sum_erase_add _ _ (by simp [xy.symm] : y∈Finset.univ.erase x),
    Finset.sum_erase_add _ _ (Finset.mem_univ x)]

theorem exchange (f : α→α) (price : α→α→ℕ) {x y z : α}
    (xy : x≠y) (xz : x≠z) (yz : y≠z) (fx : f x=z) (fz : f z=x) :
    score (Function.update f x y) price + (price x z + price z x) =
      score f price + (if f y=x then price x y + price y x else 0) := by
  let g := Function.update f x y
  have elsewhere : ∀ i∈(((Finset.univ.erase x).erase y).erase z), term g price i = term f price i := by
    intro i hi
    simp only [Finset.mem_erase,Finset.mem_univ,and_true] at hi
    obtain ⟨iz,iy,ix⟩ := hi
    by_cases e : f i=x
    · simp [term,g,Function.update_of_ne ix,e,fx,Ne.symm iz,Ne.symm iy]
    · simp [term,g,Function.update_of_ne ix,Function.update_of_ne e]
  have H := Finset.sum_congr rfl elsewhere
  change score g price + _ = _
  rw [score_split g price x y z xy xz yz,score_split f price x y z xy xz yz,H]
  generalize (((Finset.univ.erase x).erase y).erase z).sum (term f price) = rest
  by_cases e : f y=x
  · simp [term,g,fx,fz,e,xy,xy.symm,xz,xz.symm,yz,yz.symm,add_assoc,add_comm,add_left_comm]
  · by_cases h : f (f y)=y
    · simp [term,g,fx,fz,e,h,Function.update_of_ne e,xy,xy.symm,xz,xz.symm,yz,yz.symm]
      omega
    · simp [term,g,fx,fz,e,h,Function.update_of_ne e,xy,xy.symm,xz,xz.symm,yz,yz.symm]
      omega
def pairs (f : α→α) := score f (fun _ _ => 1)
def later (rank : α→ℕ) (f : α→α) := score f (fun i j => max (rank i) (rank j))

/-- Both objectives count each reciprocal pair twice. -/
theorem optimal (D : α→Finset α) (rank : α→ℕ) :
    ∃ f, Valid D f ∧ (∀ g,Valid D g → pairs f≤pairs g) ∧
          ∀ g,Valid D g → pairs f=pairs g → later rank g≤later rank f := by
  classical
  let fs := Finset.univ.filter (Valid D)
  let init := fun i => if h : (D i).Nonempty then h.choose else i
  have vi : Valid D init := by
    intro i
    by_cases h : (D i).Nonempty
    · simpa [init,h] using h.choose_spec
    · simp [init,h]
  have base : init∈fs := by simpa [fs] using vi
  obtain ⟨a,ha,minA⟩ := fs.exists_min_image pairs ⟨init,base⟩
  let low := fs.filter (fun g => pairs g=pairs a)
  have al : a∈low := by simp [low,ha]
  obtain ⟨f,hf,maxF⟩ := low.exists_max_image (later rank) ⟨a,al⟩
  have both := Finset.mem_filter.mp hf
  have fv : Valid D f := (Finset.mem_filter.mp both.1).2
  refine ⟨f,fv,?_,?_⟩
  · intro g vg
    rw [both.2]
    exact minA g (by simpa [fs] using vg)
  · intro g vg eq
    apply maxF g
    exact Finset.mem_filter.mpr ⟨by simpa [fs] using vg,eq.symm.trans both.2⟩

theorem switch_valid {D : α→Finset α} {f : α→α} (valid : Valid D f)
    {x y : α} (hy : y∈D x) : Valid D (Function.update f x y) := by
  intro i
  by_cases e : i=x
  · subst i
    have hn : (D x).Nonempty := ⟨y,hy⟩
    rw [if_pos hn,Function.update_self]
    exact hy
  · simpa [Function.update_of_ne e] using valid i

theorem select_latest (D : α→Finset α) (rank : α→ℕ)
    (self : ∀x,x∉D x) :
    ∃ f, Valid D f ∧ ∀ x z, f x=z → f z=x → x≠z → rank z≤rank x →
      ∀ y∈D x, f y=x ∧ rank y≤rank x := by
  obtain ⟨f,valid,minF,maxF⟩ := optimal D rank
  refine ⟨f,valid,?_⟩
  intro x z fx fz xz hz y hy
  by_cases yz : y=z
  · subst y; exact ⟨fz,hz⟩
  have xy : x≠y := by rintro rfl; exact self _ hy
  let g := Function.update f x y
  have gv : Valid D g := switch_valid valid hy
  have ab := exchange f (fun _ _ => 1) xy xz yz fx fz
  change pairs g + (1+1)=pairs f + (if f y=x then 1+1 else 0) at ab
  have lo := minF g gv
  have fy : f y=x := by
    by_contra bad
    simp [bad] at ab
    omega
  simp only [fy,if_true] at ab
  have same : pairs f=pairs g := by omega
  have H := maxF g gv same
  have sw := exchange f (fun i j => max (rank i) (rank j)) xy xz yz fx fz
  change later rank g+_ = later rank f+_ at sw
  rw [if_pos fy,max_eq_left hz,max_eq_right hz] at sw
  refine ⟨fy,?_⟩
  by_contra! bad
  rw [max_eq_right bad.le,max_eq_left bad.le] at sw
  omega

#print axioms select_latest
end IncidenceReciprocalChoice
