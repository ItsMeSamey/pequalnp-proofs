import IncidenceWarmTraceFamily
import IncidenceWeightedEdits
namespace IncidenceWarmTraceEditCap
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceWarmCompiler IncidencePointFirstFork
open IncidenceWarmTraceFamily IncidenceWarmTraceSchedule
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

noncomputable def edited (owners : List Nat) :=
  editedWire (n+n) C.size C.wire C.code owners.toFinset (schedule owners.toFinset (stop C)) C.output

theorem bound (neg : negatives C I 2 2) (owners : List Nat) (distinct : owners.Nodup)
    (raw : ∀x∈owners,x<n+n) (one : ∀x∈owners,uses C x=1)
    (meet : ∀x∈owners,∀j<C.size,∀ b,port (C.code j) b=x → (C.code j).op=.meet)
    (unique : ∀x∈owners,∀y∈owners,IncidencePointFirstFork.fork C x=IncidencePointFirstFork.fork C y → x=y)
    (degree : ∀ l,Fintype.card {p // I p l}=402)
    (plane : ∀ a b,a≠b → ∃! l,I a l ∧ I b l) (hn : n=161203)
    (positive : ∀p l,I p l → (single p,single l)∈edited C owners)
    (negative : ∀a b : Fin n→Bool, Fintype.card {p // a p=true}≤2 →
      Fintype.card {l // b l=true}≤2 → (∀p l,a p=true → b l=true → ¬I p l) →
      (a,b)∉edited C owners) (size : C.size≤646424) : owners.length≤3213 := by
  obtain ⟨start,side,tail,legal,nd,bounded,covers⟩ := family C I neg owners distinct raw one meet unique
  apply IncidenceWeightedEdits.edit_cap C owners owners.toFinset (schedule owners.toFinset (stop C))
      start side tail _ _ nd bounded (fun j _=>covers j) I degree plane hn positive negative size
  · intro j _ x h
    exact raw x (List.mem_toFinset.mp (schedule_spec _ _ _ _ h).1)
  · intro x hx
    exact ⟨raw x hx,by simpa using hx,legal x hx⟩
#print axioms bound
end IncidenceWarmTraceEditCap
