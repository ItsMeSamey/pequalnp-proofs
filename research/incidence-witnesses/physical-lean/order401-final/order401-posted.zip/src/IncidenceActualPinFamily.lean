import IncidencePinMultiplicity
import IncidenceEligiblePin
namespace IncidenceActualPinFamily
open scoped BigOperators
open IncidenceRobust IncidencePinMultiplicity IncidenceStartNormalization IncidenceLineRoutedSlots IncidenceEligiblePin
variable {n q : ℕ} (I : Fin n→Fin n→Prop) [DecidableRel I]

def embed (l : Fin n) : Finset (Fin n) ↪ Fin n × Finset (Fin n) :=
  ⟨fun T=>(l,T),fun _ _ h=>congrArg Prod.snd h⟩

def sample (j : ℕ) := (Finset.univ : Finset (Fin n)).biUnion fun l =>
  ((points I l).powersetCard (j+1)).map (embed l)

def event (x p : Fin n) (j : ℕ) := ((lines I p).erase x).biUnion fun l =>
  (hitPins I p l j).map (embed l)

theorem disjoint_tags (D : Finset (Fin n)) (H : Fin n→Finset (Finset (Fin n))) :
    (D:Set (Fin n)).PairwiseDisjoint (fun l=>(H l).map (embed l)) := by
  intro l _ m _ ne
  apply Finset.disjoint_left.mpr
  intro t u v
  obtain ⟨a,_,rfl⟩ := Finset.mem_map.mp u
  obtain ⟨b,_,eq⟩ := Finset.mem_map.mp v
  exact ne (congrArg Prod.fst eq).symm

theorem sample_card (degree : ∀l,Fintype.card {p // I p l}=q+1) (j : ℕ) :
    (sample I j).card=n*(q+1).choose (j+1) := by
  rw [sample,Finset.card_biUnion (disjoint_tags _ _)]
  simp [Finset.card_powersetCard,points_card I degree]
theorem event_card (degree : ∀l,Fintype.card {p // I p l}=q+1)
    (unique : ∀p r,p≠r→∃!l,I p l∧I r l) (hq : 0<q) (hn : n=q^2+q+1)
    {p x : Fin n} (inc : I p x) (j : ℕ) :
    (event I x p j).card=q*q.choose j := by
  rw [event,Finset.card_biUnion (disjoint_tags _ _)]
  simpa using hits_total I degree unique hq hn inc j

theorem event_spec {x p : Fin n} {j : ℕ} {run : Fin n × Finset (Fin n)}
    (mem : run∈event I x p j) : x≠run.1 ∧ I p run.1 ∧ p∈run.2 ∧
      run.2⊆points I run.1 ∧ run∈sample I j := by
  obtain ⟨l,hl,hh⟩ := Finset.mem_biUnion.mp mem
  obtain ⟨T,ht,rfl⟩ := Finset.mem_map.mp hh
  obtain ⟨ne,line⟩ := Finset.mem_erase.mp hl
  have inc : I p l := (Finset.mem_filter.mp line).2
  obtain ⟨inside,sub,card⟩ := hitPins_real I inc ht
  exact ⟨Ne.symm ne,inc,inside,sub,Finset.mem_biUnion.mpr ⟨l,Finset.mem_univ _,
    Finset.mem_map.mpr ⟨T,Finset.mem_powersetCard.mpr ⟨sub,card⟩,rfl⟩⟩⟩

theorem different_points (unique : ∀p r,p≠r→∃!l,I p l∧I r l)
    (x : Fin n) (S : Finset (Fin n)) (on : ∀p∈S,I p x) (j : ℕ) :
    (S:Set (Fin n)).PairwiseDisjoint (fun p=>event I x p j) := by
  intro p hp r hr ne
  apply Finset.disjoint_left.mpr
  intro run left right
  have L := event_spec I left
  have R := event_spec I right
  obtain ⟨_,_,only⟩ := unique p r ne
  exact L.1 ((only x ⟨on p hp,on r hr⟩).trans (only run.1 ⟨L.2.1,R.2.1⟩).symm)

#print axioms event_card
end IncidenceActualPinFamily
