import IncidencePrunedEligible
import IncidenceLineRoutedSlots
namespace IncidencePrunedBookMass
open scoped BigOperators
theorem complement_bound {a b : ℕ} (f : Fin a ↪ Fin b) (w : Fin b→ℕ)
    (cap : ∀i,w i≤402) : (∑i,w i) ≤ (∑k,w (f k))+402*(b-a) := by
  classical
  let S := Finset.univ.map f
  have inside : ∑i∈S,w i = ∑k,w (f k) := by simp [S]
  have outside : ∑i∈Sᶜ,w i ≤ ∑_i∈Sᶜ,402 := Finset.sum_le_sum fun i _=>cap i
  have sc : (Sᶜ).card=b-a := by simp [Finset.card_compl,S]
  rw [← S.sum_add_sum_compl w,inside]
  exact Nat.add_le_add_left (by simpa [sc,Nat.mul_comm] using outside) _
open IncidenceStartNormalization IncidenceHoistPrune IncidenceLineRoutedSlots
theorem prune_books {n : ℕ} (C : Circuit n) (bin : binary C)
    (I : Fin n→Fin n→Prop) [DecidableRel I]
    (degree : ∀l,Fintype.card {p // I p l}=402) :
    ∃ D : Circuit n, D.size≤C.size ∧ binary D ∧ Live D ∧ D.wire D.output=C.wire C.output ∧
      ∀ (owner : Fin C.size→Fin n) (book : Fin C.size→Finset (Fin n)),
        (∀g,∀p∈book g,eligible C I (owner g) g p) →
        ∃ (own : Fin D.size→Fin n) (bk : Fin D.size→Finset (Fin n)),
          (∀g,∀p∈bk g,eligible D I (own g) g p) ∧
          (∑g,(book g).card) ≤ (∑g,(bk g).card)+402*(C.size-D.size) := by
  classical
  obtain ⟨D,sz,bd,ld,out,_,f,trans⟩ := IncidencePrunedEligible.prune_rows C bin
  refine ⟨D,sz,bd,ld,out,?_⟩
  intro owner book good
  refine ⟨owner ∘ f,book ∘ f,fun g p h=>trans g (owner (f g)) p I (good _ _ h),?_⟩
  apply complement_bound f (fun i=>(book i).card)
  intro i
  have sub : book i ⊆ Finset.univ.filter (fun p=>I p (owner i)) := by
    intro p hp
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,(good _ _ hp).2.1⟩
  have c := degree (owner i)
  simpa [Fintype.card_subtype] using (Finset.card_le_card sub).trans (show
    (Finset.univ.filter (fun p=>I p (owner i))).card ≤ 402 by simpa [Fintype.card_subtype] using c.le)
end IncidencePrunedBookMass
