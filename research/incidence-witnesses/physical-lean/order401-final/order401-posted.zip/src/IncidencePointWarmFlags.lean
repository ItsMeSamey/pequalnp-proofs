import IncidencePointWarmBad
namespace IncidencePointWarmMasks
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmCompiler IncidencePointWarmComparison
variable {n : Nat}
theorem shadow_raw_cut (m s : Nat) (code : Nat→Gate) (x j : Nat) :
    shadow m code x x s j=false := by
  induction s generalizing j with
  | zero => simp [shadow]
  | succ t ih => simp [shadow,put,ih]

theorem flag_mask (C : Circuit n) (I : Fin n→Fin n→Prop) (M : Finset (Fin n)) (f c)
    (wire : Wiring C M f c) (pos : flags C I) (x l : Fin n) (inc : I x l)
    (sh : x∈M → shadow (n+n) C.code x.val (c x) C.size C.output=false) :
    (single x,single l)∈editedWire (n+n) C.size C.wire C.code (drops M) f C.output := by
  let z : Input n := (single x,single l)
  let cut := if x∈M then c x else x.val
  apply flag C.code C.wire (drops M) f C.earlier wire.pins C.law z x.val cut C.output C.output_lt
    _ _ _ (pos x l inc)
  · intro i _ ne old drop
    obtain ⟨p,_,rfl⟩ := Finset.mem_image.mp drop
    rw [(C.inputs p).1] at old
    have eq : p=x := by simpa [z,single] using old
    exact ne (congrArg Fin.val eq)
  · by_cases hx : x∈M
    · obtain ⟨j,hj,install,idx⟩ := wire.installed x hx
      simp only [cut,if_pos hx,idx]
      rw [editedRow _ _ _ _ _ _ C.earlier wire.pins j hj]
      right
      simp [install,CircuitRewire.read,(C.inputs x).1,z,single]
    · simp only [cut,if_neg hx]
      rw [editedInput _ _ _ _ _ _ _ (by have := x.isLt; omega)]
      have keep : x.val∉drops M := by
        rintro mem
        obtain ⟨u,hu,eq⟩ := Finset.mem_image.mp mem
        exact hx ((Fin.ext eq) ▸ hu)
      simp [keep,(C.inputs x).1,z,single]
  · by_cases hx : x∈M
    · simpa [cut,hx] using sh hx
    · simpa [cut,hx] using shadow_raw_cut (n+n) C.size C.code x.val C.output
#print axioms flag_mask
end IncidencePointWarmMasks
