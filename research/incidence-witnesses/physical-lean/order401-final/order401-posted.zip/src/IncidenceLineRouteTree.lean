import IncidenceLineRoutedSlots
namespace IncidenceLineRouteTree
open IncidenceLineTrieWeight IncidenceLineRoutedSlots IncidenceStartNormalization

variable {n : ℕ}
def usable (S : Finset (Fin n)) := if S.card=1 then ∅ else S

theorem usable_count (t : Tree) (S : Finset (Fin n)) (card : S.card=count t) :
    (usable S).card=count t-loss t := by
  cases t with
  | single => simp [usable,card,count,loss]
  | pair => simp [usable,card,count,loss]
  | fork a b =>
    have ha := count_pos a
    have hb := count_pos b
    have h : S.card≠1 := by change S.card=count a+count b at card; omega
    rw [usable,if_neg h,card]; rfl

def slot {s : ℕ} (g : Fin s) (S : Finset (Fin n)) : Finset (Fin s × Fin n) :=
  S.map ⟨fun p=>(g,p),fun _ _ h=>congrArg Prod.snd h⟩

noncomputable def heavy (C : Circuit n) (I : Fin n→Fin n→Prop) (x : Fin n) (g : Fin C.size) : Prop := by
  classical
  exact 2 < (Finset.univ.filter (fun p => I p x ∧ hit C (n+n+g.val) p)).card

/-- A cold traversal, after unary contraction. Entries refer to physical OR
IDs of one baseline. The graph may be shared across branches. -/
inductive Routed (C : Circuit n) (I : Fin n→Fin n→Prop) (x : Fin n) (safe : Fin C.size→Prop) :
    ℕ → Finset (Fin n) → Tree → Finset (Fin C.size × Fin n) → Prop
  | one (k) (S) (c : S.card=1) : Routed C I x safe k S .single ∅
  | two (k) (S) (c : S.card=2) : Routed C I x safe k S .pair ∅
  | node {k S T a b u v} (g : Fin C.size) (before : g.val<k)
      (ok : safe g) (op : (C.code g).op=.join) (dis : Disjoint S T)
      (left : ∀p∈S,I p x ∧ hit C (C.code g).left p)
      (right : ∀p∈T,I p x ∧ hit C (C.code g).right p)
      (ga : Routed C I x safe g.val S a u) (gb : Routed C I x safe g.val T b v) :
      Routed C I x safe k (S∪T) (.fork a b) ((u∪v)∪slot g (usable S∪usable T))

theorem route_spec {C : Circuit n} {I : Fin n→Fin n→Prop} {x : Fin n} {safe : Fin C.size→Prop}
    {k S a book} (h : Routed C I x safe k S a book) :
    S.card=count a ∧ book.card=weight a ∧
      ∀ z∈book,z.1.val<k ∧ z.2∈S ∧ safe z.1 ∧ heavy C I x z.1 ∧ eligible C I x z.1 z.2 := by
  induction h with
  | one k S c => exact ⟨c,rfl,by simp⟩
  | two k S c => exact ⟨c,rfl,by simp⟩
  | @node k S T a b u v g before ok op dis left right ga gb A B =>
    obtain ⟨ca,wa,ha⟩ := A
    obtain ⟨cb,wb,hb⟩ := B
    have sub (Z : Finset (Fin n)) : usable Z⊆Z := by unfold usable; split <;> simp
    have uv : Disjoint u v := Finset.disjoint_left.mpr (by
      intro z l r; exact Finset.disjoint_left.mp dis (ha z l).2.1 (hb z r).2.1)
    have parts : Disjoint (usable S) (usable T) := dis.mono (sub S) (sub T)
    have current : Disjoint (u∪v) (slot g (usable S∪usable T)) := by
      apply Finset.disjoint_left.mpr
      intro z hz now
      obtain ⟨p,_,rfl⟩ := Finset.mem_map.mp now
      rcases Finset.mem_union.mp hz with h|h
      · exact (Nat.lt_irrefl _) (ha _ h).1
      · exact (Nat.lt_irrefl _) (hb _ h).1
    refine ⟨by rw [Finset.card_union_of_disjoint dis,ca,cb]; rfl,?_,?_⟩
    · rw [Finset.card_union_of_disjoint current,Finset.card_union_of_disjoint uv,
        slot,Finset.card_map,Finset.card_union_of_disjoint parts,usable_count a S ca,
        usable_count b T cb,wa,wb]
      simp [weight,Nat.add_assoc]
    · intro z hz
      rcases Finset.mem_union.mp hz with old|new
      · rcases Finset.mem_union.mp old with l|r
        · exact ⟨(ha _ l).1.trans before,Finset.mem_union_left _ (ha _ l).2.1,(ha _ l).2.2⟩
        · exact ⟨(hb _ r).1.trans before,Finset.mem_union_right _ (hb _ r).2.1,(hb _ r).2.2⟩
      · obtain ⟨p,hp,rfl⟩ := Finset.mem_map.mp new
        have lift (Z : Finset (Fin n)) (mem : p∈usable Z) : p∈Z ∧ 2≤Z.card := by
          by_cases e : Z.card=1
          · simp [usable,e] at mem
          · have inz := sub Z mem
            have pos := Finset.card_pos.mpr ((⟨p,inz⟩ : Z.Nonempty))
            exact ⟨inz,by omega⟩
        have pair := (Finset.mem_union.mp hp).imp (lift S) (lift T)
        have sn : S.Nonempty := Finset.card_pos.mp (ca.trans_gt (count_pos a))
        have tn : T.Nonempty := Finset.card_pos.mp (cb.trans_gt (count_pos b))
        have hg : heavy C I x g := by
          classical
          unfold heavy
          have law := C.law g.val g.isLt
          rw [CircuitRewire.Gate.eval,op,CircuitRewire.Op.eval] at law
          have sub' : S∪T ⊆ Finset.univ.filter (fun p => I p x ∧ hit C (n+n+g.val) p) := by
            intro i hi
            apply Finset.mem_filter.mpr
            refine ⟨Finset.mem_univ _,?_⟩
            unfold hit
            rw [law]
            rcases Finset.mem_union.mp hi with h|h
            · exact ⟨(left i h).1,Or.inl (left i h).2⟩
            · exact ⟨(right i h).1,Or.inr (right i h).2⟩
          have card := Finset.card_le_card sub'
          rw [Finset.card_union_of_disjoint dis] at card
          have aa := Finset.card_pos.mpr sn
          have bb := Finset.card_pos.mpr tn
          rcases pair with a|b <;> omega
        exact ⟨before,Finset.mem_union.mpr (pair.imp And.left And.left),
          ok,hg,physical_join C I x g op S T dis sn tn left right p pair⟩

theorem from_402 {C : Circuit n} {I : Fin n→Fin n→Prop} {x : Fin n} {safe : Fin C.size→Prop}
    {k S a book} (h : Routed C I x safe k S a book) (card : S.card=402) :
    3106≤book.card ∧ ∀ z∈book,safe z.1 ∧ heavy C I x z.1 ∧ eligible C I x z.1 z.2 := by
  obtain ⟨ca,wa,slots⟩ := route_spec h
  exact ⟨by rw [wa]; exact eligible_402 a (ca.symm.trans card),fun z hz=>(slots z hz).2.2⟩
#print axioms from_402
end IncidenceLineRouteTree
