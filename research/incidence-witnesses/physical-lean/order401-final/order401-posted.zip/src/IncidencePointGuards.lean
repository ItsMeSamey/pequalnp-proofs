import IncidencePointBaseline
namespace IncidencePointGuards
open CircuitRewire
/-- One indexed AND corridor step. Sibling is a literal output of the common baseline or
zero. The optional suffix is the ordinal of an earlier emitted guard; no suffix denotes true. -/
structure Step where
  sibling : Option Nat
  suffix : Option Nat

def guardGate (m : Nat) (s : Step) : Gate :=
  match s.sibling,s.suffix with
  | none,_ => ⟨.zero,0,0⟩
  | some k,none => ⟨.copy,k,k⟩
  | some k,some u => ⟨.meet,k,m+u⟩

def cat (n b : Nat) (base : Nat→Gate) (steps : Nat→Step) (j : Nat) : Gate :=
  if j<b then base j else guardGate (n+b) (steps (j-b))

def CatValues {Z : Type*} (n b : Nat) (Y R : Nat→Set Z) (j : Nat) : Set Z :=
  if j<n+b then Y j else R (j-(n+b))

def suffixVal {Z : Type*} (R : Nat→Set Z) : Option Nat→Set Z
  | none=>Set.univ
  | some j=>R j

theorem assemble {Z : Type*} (n b a : Nat) (base : Nat→Gate) (steps : Nat→Step)
    (Y R : Nat→Set Z) (positive : 0<n+b)
    (ord : ∀ j<b,(base j).left<n+j ∧ (base j).right<n+j)
    (sem : ∀ j<b,Y (n+j)=(base j).eval Y)
    (side : ∀ j<a,∀ k,(steps j).sibling=some k → k<n+b)
    (prev : ∀ j<a,∀ u,(steps j).suffix=some u → u<j)
    (factor : ∀ j<a,R j=CircuitRewire.read Y (steps j).sibling ∩ suffixVal R (steps j).suffix) :
    let G := cat n b base steps
    let X := CatValues n b Y R
    (∀ j<b+a,(G j).left<n+j ∧ (G j).right<n+j) ∧
    (∀ j<b+a,X (n+j)=(G j).eval X) ∧ (∀ j<n+b,X j=Y j) ∧
    (∀ j<a,X (n+b+j)=R j) := by
  have old (i : Nat) (hi : i<n+b) : CatValues n b Y R i=Y i := by simp [CatValues,hi]
  have new (j : Nat) : CatValues n b Y R (n+b+j)=R j := by simp [CatValues]
  refine ⟨?_,?_,old,fun j _=>new j⟩
  · intro j hj
    by_cases h : j<b
    · simpa [cat,h] using ord j h
    · let i := j-b
      have hi : i<a := by dsimp [i]; omega
      have eq : j=b+i := by dsimp [i]; omega
      change (cat n b base steps j).left<n+j ∧ _
      simp only [cat,if_neg h]
      change (guardGate (n+b) (steps i)).left<n+j ∧ (guardGate (n+b) (steps i)).right<n+j
      cases hv : (steps i).sibling with
      | none => simp [guardGate,hv]; omega
      | some k =>
        have klt := side i hi k hv
        cases hs : (steps i).suffix with
        | none => simp [guardGate,hv,hs]; omega
        | some u =>
          have ult := prev i hi u hs
          simp [guardGate,hv,hs]; omega
  · intro j hj
    by_cases h : j<b
    · have law := sem j h
      obtain ⟨l,r⟩ := ord j h
      simpa only [cat,if_pos h,Gate.eval,old _ (show n+j<n+b by omega),
        old _ (show (base j).left<n+b by omega),old _ (show (base j).right<n+b by omega)] using law
    · let i := j-b
      have hi : i<a := by dsimp [i]; omega
      have eq : n+j=n+b+i := by dsimp [i]; omega
      rw [eq,new]
      simp only [cat,if_neg h]
      change R i=(guardGate (n+b) (steps i)).eval _
      rw [factor i hi]
      cases hv : (steps i).sibling with
      | none => simp [guardGate,hv,CircuitRewire.read,Gate.eval,Op.eval]
      | some k =>
        have klt := side i hi k hv
        cases hs : (steps i).suffix <;>
          simp [guardGate,hv,hs,CircuitRewire.read,suffixVal,Gate.eval,Op.eval,old k klt,new]
#print axioms assemble
end IncidencePointGuards
