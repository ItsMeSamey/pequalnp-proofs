import IncidencePointMerge
namespace IncidencePointCorridor
open CircuitRewire IncidencePointShield
def inputPort (g : Gate) (b : Bool) := if b then g.right else g.left
inductive Path (m : Nat) (code : Nat→Gate) : Nat→Nat→Type where
  | nil (i : Nat) : Path m code i i
  | cons (g : Nat) (side : Bool) {out : Nat} (tail : Path m code (m+g) out) :
      Path m code (inputPort (code g) side) out
variable {m : Nat} {code : Nat→Gate} {src out : Nat}
def Path.check (terminal x s : Nat) : {a b : Nat}→Path m code a b→Prop
  | _,_,.nil _ => True
  | _,_,.cons g side tail => g<s ∧ shadow m code x (m+s) s (inputPort (code g) (!side))=false ∧
      shadow m code x (m+g) s terminal=false ∧ Path.check terminal x s tail
def Path.factors : {a b : Nat}→Path m code a b→List Nat
  | _,_,.nil _ => []
  | _,_,.cons g side tail =>
    if (code g).op=.meet then inputPort (code g) (!side)::tail.factors else tail.factors

theorem product {Z : Type*} (s : Nat) (X : Nat→Set Z)
    (ord : ∀ i<s,(code i).left<m+i ∧ (code i).right<m+i)
    (ops : ∀ i<s,(code i).op=.join ∨ (code i).op=.meet)
    (law : ∀ i<s,X (m+i)=(code i).eval X) (owner terminal : Nat) (u v : Z)
    (inputs : ∀ i<m,i≠owner → (u∈X i ↔ v∈X i))
    (path : Path m code src out)
    (guard : ∀ i<s,shadow m code owner (m+i) s terminal=false → u∉X (m+i))
    (ok : Path.check terminal owner s path) :
    (v∈X out ↔ v∈X src ∧ ∀ j∈path.factors,u∈X j) := by
  induction path with
  | nil i => simp [Path.factors]
  | @cons g side dst tail ih =>
    obtain ⟨inBounds,away,stops,rest⟩ := ok
    obtain ⟨lg,rg⟩ := ord g inBounds
    have sideBound : inputPort (code g) (!side)<m+s := by
      cases side <;> simp [inputPort] <;> omega
    have fixed := absent_path m s code X ord law owner u v inputs _ sideBound away
    have cold := guard g inBounds stops
    rw [ih rest]
    rcases ops g inBounds with a|a <;> cases side <;>
      simp [Path.factors,inputPort,law g inBounds,Gate.eval,Op.eval,a] at fixed cold ⊢ <;>
      tauto
#print axioms product
end IncidencePointCorridor
