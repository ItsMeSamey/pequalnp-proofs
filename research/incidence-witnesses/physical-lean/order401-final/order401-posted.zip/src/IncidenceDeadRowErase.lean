import IncidenceDeadPhysical
import IncidenceDeadSink
namespace IncidenceDeadRowErase
open IncidenceStartNormalization IncidenceCleanupGate IncidenceHoistPrune

theorem run {n : Nat} (C : Circuit n) (bin : binary C) (dead : ¬Live C) :
    ∃g : Fin C.size, let old := (C.code g.val).left
      ¬Anc C (n+n+g.val) ∧ C.output≠n+n+g.val ∧ uses C (n+n+g.val)=0 ∧
      (∀j<C.size,(C.code j).left≠n+n+g.val ∧ (C.code j).right≠n+n+g.val) ∧
      old<n+n+g.val ∧ ∃D : Circuit n, binary D ∧ D.wire D.output=C.wire C.output ∧
        D.size+1=C.size ∧ D.code=eraseGate (n+n) g.val old C.code ∧
        D.output=rewire (n+n) g.val old C.output := by
  obtain ⟨g,notAncestor,ignored,unread⟩ := IncidenceDeadSink.exists_sink C dead
  have earlier := (C.earlier g.val g.isLt).1
  exact ⟨g,notAncestor,ignored,IncidenceDeadSink.zero_uses C _ unread,unread,earlier,
    erase C bin g _ earlier ignored unread⟩
#print axioms run
end IncidenceDeadRowErase
