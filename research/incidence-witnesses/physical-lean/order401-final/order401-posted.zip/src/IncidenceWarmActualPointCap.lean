import IncidenceWarmPointSchedule
import IncidenceWeightedSelected
namespace IncidenceWarmActualPointCap
open SparseIncidence IncidenceStartNormalization IncidencePointFirstFork IncidencePointShield
open IncidenceWarmDomain IncidencePointWarmMasks IncidenceReciprocalChoice IncidenceChosenEnds
open IncidenceWarmDichotomy
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

def c (p : Fin n) := fork C p.val
def soleOwners := Finset.univ.filter (fun p : Fin n => uses C p.val=1)

theorem paid (andP : soleAnd C 0) (pos : flags C I) (original : negatives C I 401 400)
    (degree : ∀ l,Fintype.card {p // I p l}=402)
    (plane : ∀a b,a≠b → ∃!l,I a l ∧ I b l) (hn : n=161203) (size : C.size≤646424) :
    ∃ f,Valid (D C I (c C) (soleOwners C)) f ∧
      (∀x,removed f (c C) x → ∀y∈D C I (c C) (soleOwners C) x,
        f y=x ∧ c C y<c C x ∧ ¬removed f (c C) y) ∧
      (edits C I (c C) (soleOwners C) f).card≤3213 := by
  classical
  let O := soleOwners C
  let B := D C I (c C) O
  have witness (x : Fin n) (w : Warm C I (c C) x {x}) :
      ∃W : Finset (Fin n),W.card≤399 ∧ (∀l∈W,¬I x l) ∧
        (single x,bits W)∈C.wire (fork C x.val) := by
    obtain ⟨W,card,off,hit⟩ := w
    refine ⟨W,by omega,off x (by simp),?_⟩
    have eq : bits {x}=single x := by funext p; simp [bits,single]
    simpa [mask,eq,c] using hit
  have self (x) : x∉B x := fun h=>((mem_D C I (c C) O x x).mp h).2.2.1 rfl
  have diff (x y) (ne : x≠y) (non : (B x).Nonempty) (_ : (B y).Nonempty) : c C x≠c C y := by
    obtain ⟨v,hv⟩ := non
    obtain ⟨W,small,off,hit⟩ := witness x ((mem_D C I (c C) O x v).mp hv).2.1
    exact IncidenceWarmForkSeparation.points_distinct I C pos original degree plane hn x y ne W small off hit
  obtain ⟨f,valid,order⟩ := bad_precedes B (c C) self diff
  let M := edits C I (c C) O f
  have prop (x) (hx : x∈M) : x∈O ∧ Warm C I (c C) x {x} := by
    simp only [M,edits,Finset.mem_filter] at hx
    exact ⟨hx.1,hx.2.1⟩
  obtain ⟨A,drop,_,w⟩ := IncidenceWarmPointSchedule.construct C I pos original andP degree plane hn M
    (fun x hx=>(Finset.mem_filter.mp (prop x hx).1).2) (fun x hx=>witness x (prop x hx).2)
  exact ⟨f,valid,order,IncidenceWeightedSelected.cap C I (c C) O f valid order A w drop pos original
    (fun y _=>⟨IncidenceWarmTraceShadow.fork_bound C (by have := y.isLt; omega : y.val<n+n+C.size),
      IncidenceWarmTraceShadow.blocked C y.val⟩) degree plane hn size⟩

#print axioms paid
end IncidenceWarmActualPointCap
