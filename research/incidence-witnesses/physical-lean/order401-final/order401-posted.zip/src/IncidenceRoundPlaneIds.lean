import IncidenceAllowedGeometry

namespace IncidenceRoundPlaneIds
open IncidenceAllowedGeometry IncidenceRobust
variable {n : ℕ} (I : Fin n → Fin n → Prop) [DecidableRel I]

private theorem split_id {x : ℕ} (hx : x<n+n) :
    (∃p : Fin n,x=p.val) ∨ (∃l : Fin n,x=n+l.val) := by
  by_cases h : x<n
  · exact Or.inl ⟨⟨x,h⟩,rfl⟩
  · exact Or.inr ⟨⟨x-n,by omega⟩,by change x=n+(x-n); omega⟩

private theorem from_point (p : Fin n) :
    neighbors I p.val=(lines I p).map (lineEmb n) := by
  simp only [neighbors,dif_pos p.isLt] <;> rfl

private theorem from_line (l : Fin n) :
    neighbors I (n+l.val)=(points I l).map (pointEmb n) := by
  have lo : ¬n+l.val<n := by omega
  have hi : n+l.val<n+n := by have := l.isLt; omega
  have idx : (⟨n+l.val-n,by omega⟩ : Fin n)=l := Fin.ext (by change n+l.val-n=l.val; omega)
  simp only [neighbors,dif_neg lo,dif_pos hi,idx] <;> rfl

private theorem same_side (U V : Finset (Fin n)) (e : Fin n ↪ ℕ)
    (small : (U ∩ V).card≤1) : (U.map e ∩ V.map e).card≤1 := by
  apply Finset.card_le_one.mpr
  intro x hx y hy
  obtain ⟨p,pu,rfl⟩ := Finset.mem_map.mp (Finset.mem_inter.mp hx).1
  obtain ⟨r,ru,rfl⟩ := Finset.mem_map.mp (Finset.mem_inter.mp hy).1
  obtain ⟨q,qv,eqp⟩ := Finset.mem_map.mp (Finset.mem_inter.mp hx).2
  obtain ⟨k,kv,eqr⟩ := Finset.mem_map.mp (Finset.mem_inter.mp hy).2
  have pv : p∈V := e.injective eqp ▸ qv
  have rv : r∈V := e.injective eqr ▸ kv
  exact congrArg e ((Finset.card_le_one.mp small) p (Finset.mem_inter.mpr ⟨pu,pv⟩)
    r (Finset.mem_inter.mpr ⟨ru,rv⟩))

private theorem opposite (U V : Finset (Fin n)) :
    (U.map (lineEmb n) ∩ V.map (pointEmb n)).card≤1 := by
  apply Finset.card_le_one.mpr
  intro x hx y hy
  obtain ⟨l,_,rfl⟩ := Finset.mem_map.mp (Finset.mem_inter.mp hx).1
  obtain ⟨p,_,eq⟩ := Finset.mem_map.mp (Finset.mem_inter.mp hx).2
  change p.val=n+l.val at eq
  have := p.isLt
  omega

theorem geometry (hn : n=161203)
    (degree : ∀l,Fintype.card {p // I p l}=402)
    (join : ∀p q,p≠q → ∃!r,I p r ∧ I q r) :
    (∀x<n+n,neighbors I x⊆Finset.range (n+n)) ∧
    (∀x<n+n,(neighbors I x).card=402) ∧
    (∀x<n+n,∀y<n+n,x≠y → (neighbors I x∩neighbors I y).card≤1) := by
  refine ⟨?_,?_,?_⟩
  · intro x hx y hy
    apply Finset.mem_range.mpr
    rcases split_id hx with ⟨p,rfl⟩ | ⟨l,rfl⟩
    · rw [from_point] at hy
      obtain ⟨l,_,rfl⟩ := Finset.mem_map.mp hy
      change n+l.val<n+n
      have := l.isLt
      omega
    · rw [from_line] at hy
      obtain ⟨p,_,rfl⟩ := Finset.mem_map.mp hy
      change p.val<n+n
      have := p.isLt
      omega
  · intro x hx
    rcases split_id hx with ⟨p,rfl⟩ | ⟨l,rfl⟩
    · rw [from_point,Finset.card_map]
      exact lines_card (q:=401) I degree join (by decide) (by omega) p
    · rw [from_line,Finset.card_map]
      exact points_card (q:=401) I degree l
  · intro x hx y hy ne
    rcases split_id hx with ⟨p,rfl⟩ | ⟨l,rfl⟩ <;>
      rcases split_id hy with ⟨r,rfl⟩ | ⟨k,rfl⟩
    · rw [from_point,from_point]
      exact same_side _ _ _ (line_overlap I join (fun eq=>ne (eq ▸ rfl)))
    · rw [from_point,from_line]
      exact opposite _ _
    · rw [from_line,from_point,Finset.inter_comm]
      exact opposite _ _
    · rw [from_line,from_line]
      exact same_side _ _ _ (point_overlap I join (fun eq=>ne (eq ▸ rfl)))

#print axioms geometry
end IncidenceRoundPlaneIds
