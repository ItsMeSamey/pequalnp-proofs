import IncidencePointWarmComparison
namespace IncidenceWarmBarePersistence
open CircuitRewire IncidenceWarmCompiler IncidencePointWarmComparison IncidencePointShield IncidencePointEditedDomination
theorem wire_iff {Z : Type*} {m s : ℕ} (code : ℕ→Gate) (B : ℕ→Set Z)
    (drop : Finset ℕ) (fork : ℕ→Option ℕ) (z : Z)
    (ord : ∀j<s,(code j).left<m+j ∧ (code j).right<m+j)
    (pins : ∀j<s,∀x,fork j=some x → x<m) (law : ∀j<s,B (m+j)=(code j).eval B)
    (dropped : ∀i<m,i∈drop → z∉B i)
    (injected : ∀j<s,z∉CircuitRewire.read B (fork j))
    (i : ℕ) (hi : i<m+s) : z∈editedWire m s B code drop fork i ↔ z∈B i := by
  induction i using Nat.strong_induction_on with
  | ind i ih =>
    by_cases raw : i<m
    · rw [editedInput _ _ _ _ _ _ _ raw]
      by_cases h : i∈drop
      · simp [h,dropped i raw h]
      · simp [h]
    let j := i-m
    have eq : i=m+j := by dsimp [j]; omega
    have hj : j<s := by omega
    obtain ⟨l,r⟩ := ord j hj
    have hl := ih (code j).left (by omega) (by omega)
    have hr := ih (code j).right (by omega) (by omega)
    rw [eq,editedRow _ _ _ _ _ _ ord pins j hj,law j hj,Set.mem_union,eval_mem,eval_mem]
    have hj' := injected j hj
    cases op : (code j).op <;> simp [act,op] at * <;> tauto
end IncidenceWarmBarePersistence
