import IncidencePointSharedCircuit
import IncidenceWarmTrackedStart
import IncidenceWarmTraceCorridor
namespace IncidenceWarmSharedActual
open IncidenceStartNormalization IncidencePointShield IncidencePointFirstFork
open IncidencePointBooking IncidencePointWarmMasks IncidencePointCorridor IncidencePointPayload
open IncidenceWarmTrackedRows IncidenceWarmTraceChart IncidenceWarmTraceNative
variable {n : Nat}
theorem build (C : Circuit n) (I : Fin n→Fin n→Prop) (bin : binary C)
    (pos : flags C I) (neg : negatives C I 401 400) (andP : soleAnd C 0) (hn : 0<n)
    (joins : ∀x y,∃l,I x l ∧ I y l) (S : Finset (Fin n)) (sole : ∀x∈S,uses C x.val=1) :
    ∃sz≤C.size,∃code : Nat→CircuitRewire.Gate,∃Y : Nat→Set (Sparse n),∃out : Fin n→Nat,
      (∀i<n,Y i=B n i) ∧ (∀i<sz,(code i).left<n+i ∧ (code i).right<n+i) ∧
      (∀i<sz,Y (n+i)=(code i).eval Y) ∧
      ∀x∈S,out x<n+sz ∧ ∀T : Sparse n,T∈Y (out x) ↔ mask {x} T.val∈C.wire (fork C x.val) := by
  classical
  choose paths checks native using (fun x : Fin n=>IncidenceWarmTraceCorridor.checked_native C x.val)
  have line (x : Fin n) : ∃l,I x l := (joins x x).imp (fun _ h=>h.1)
  have ok := fun (x : Fin n) (_ : x∈S)=>checks x
  let GG := G C S paths
  apply shared C I bin pos neg hn line S (fun x=>fork C x.val) paths ok
    (K C S paths) GG (sub C S paths) _ (sib C S paths) (sib_bound C S paths)
    (successor C GG) (later C GG)
  · intro x hx
    obtain ⟨u,_,eq⟩ := IncidenceWarmTrackedStart.start C I S paths pos neg andP joins ok
      (fun x _=>native x) sole x hx
    exact ⟨u,eq⟩
  · intro g _ hk
    apply Set.eq_empty_iff_forall_notMem.mpr
    intro T
    exact IncidenceWarmTrackedStart.baseline C I S paths pos neg line ok g hk T.val (T.property.trans (by decide))
#print axioms build
end IncidenceWarmSharedActual
