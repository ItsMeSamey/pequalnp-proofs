import IncidenceThetaCompose
import IncidenceThetaCredits
namespace IncidenceThetaPaid
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceThetaRestrict IncidenceThetaBatchHoist
open IncidencePinLowLedger IncidencePinCompensation IncidenceHoistPrune IncidenceHoistWalk
open IncidenceHoistPrefix IncidenceHoistShield
variable {n : ℕ}
noncomputable def owners (P Q : Finset (Fin n)) : List (Raw n) :=
  (P.toList.map (fun x=>(false,x))) ++ (Q.toList.map (fun x=>(true,x)))
@[simp] theorem ownerP (P Q : Finset (Fin n)) (x : Fin n) :
    (false,x)∈owners P Q ↔ x∈P := by simp [owners]
@[simp] theorem ownerL (P Q : Finset (Fin n)) (x : Fin n) :
    (true,x)∈owners P Q ↔ x∈Q := by simp [owners]

theorem room (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I] (k : ℕ) (k1 : 1≤k)
    (P Q : Finset (Fin n)) (bin : binary C) (live : Live C) (pos : flags C I)
    (neg : negatives C I (k+1) (k+1))
    (degree : ∀d∈owners P Q,k<(N I d.1 d.2).card)
    (over : ∀d∈owners P Q,∀i≠d.2,(N I d.1 d.2∩N I d.1 i).card≤1)
    (pN : ∀x∈P,∃y∉Q,I x y) (qN : ∀x∈Q,∃y∉P,I y x)
    (edge : ∃p∉P,∃l∉Q,I p l) :
    ∃B : Circuit n,binary B ∧ Live B ∧ flags B (rel I Pᶜ Qᶜ) ∧ negatives B (rel I Pᶜ Qᶜ) k k ∧
      B.size+2*(P.card+Q.card)≤C.size := by
  classical
  let D:=owners P Q
  let E:=edited C D
  obtain ⟨_,pf,nf⟩ := stage C I k D pos neg degree over
  have eb : binary E := ops C D bin
  have el : Live E := IncidenceHoistLive.live C _ live
  have ec (side : Bool) (x : Fin n) : witness side x∉E.wire E.output := by
    have h := neg_view E I k nf side {x} ∅ (by simpa using k1) (by simp) (by simp)
    cases side <;> simpa [IncidencePinHoistSparse.view,IncidencePinHoistSparse.mask_single,witness] using h
  let Z := z E P Q
  have credits := budget E Z ∅ eb el
    (by obtain ⟨p,hp,l,hl,i⟩:=edge; exact free_pair E I pf P Q p l hp hl i)
    (zero_law E eb P Q)
  have liveRaw (w) (hw : w∈deadRaw E Z) : 0<uses E w := by
    rw [show deadRaw E Z=pinRaw P ∪ lineRaw Q from raw_set ..] at hw
    rcases Finset.mem_union.mp hw with hp|hl
    · obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hp
      obtain ⟨y,_,xy⟩:=pN x hx
      exact IncidenceThetaCredits.has_use E I ec pf false x y xy (initial E _ _ (owner_hot E false x))
    · obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hl
      obtain ⟨y,_,xy⟩:=qN x hx
      exact IncidenceThetaCredits.has_use E I ec pf true x y xy (initial E _ _ (owner_hot E true x))
  have debit := credits liveRaw (by
    intro w hw _ one
    rw [show deadRaw E Z=pinRaw P ∪ lineRaw Q from raw_set ..] at hw
    rcases Finset.mem_union.mp hw with hp|hl
    · obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hp
      obtain ⟨y,hy,xy⟩:=pN x hx
      exact IncidenceThetaCredits.point E I eb ec pf P Q x y hx hy xy one
        (private_after C I k D k1 pos neg degree over bin false x ((ownerP ..).2 hx) one)
    · obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hl
      obtain ⟨y,hy,xy⟩:=qN x hx
      exact IncidenceThetaCredits.line E I eb ec pf P Q x y hx hy xy one
        (private_after C I k D k1 pos neg degree over bin true x ((ownerL ..).2 hx) one))
  have hit : ∃p∈Pᶜ,∃l∈Qᶜ,I p l := by simpa using edge
  obtain ⟨B,bb,bl,pf',nf',size⟩ := IncidenceThetaRestrict.step C I k D Pᶜ Qᶜ bin pos neg degree over hit
  refine ⟨B,bb,bl,pf',nf',?_⟩
  have ini (w) (hw : w<n+n) : (ref Pᶜ Qᶜ w).isNone=Z w := by
    by_cases h : w<n
    · let x : Fin n := ⟨w,h⟩
      change (ref Pᶜ Qᶜ x.val).isNone=z E P Q x.val
      by_cases a : x∈P <;> simp [ref,left,a,z,freeMax,(E.inputs x).1]
    · let x : Fin n := ⟨w-n,by omega⟩
      have eq : n+x.val=w := by dsimp [x]; omega
      rw [←eq]; change _=z E P Q (n+x.val)
      by_cases a : x∈Q <;> simp [ref,right,a,z,freeMax,(E.inputs x).2]
  have gate (j) (hj : j<E.size) : Z (n+n+j)=IncidenceZeroRestriction.deadOut (E.code j).op (Z (E.code j).left) (Z (E.code j).right) := by
    have h:=zero_law E eb P Q j hj
    rcases eb j hj with op|op <;> simpa [IncidenceOperandLedger.zeroAt,IncidenceZeroRestriction.deadOut,op,Z] using h
  have eq := (IncidenceZeroRestriction.literal_counts (n+n) (n+n) E.size E.code (ref Pᶜ Qᶜ) Z ini
    (fun j hj=>⟨(E.earlier j hj).1,(E.earlier j hj).2,eb j hj⟩) gate).2
  have paid : 2*(P.card+Q.card)≤IncidenceZeroRestriction.charged E.code Z E.size := by
    simpa [Z,raw_card,IncidenceZeroRestriction.charged,IncidenceZeroRestriction.lost,IncidencePinLowLedger.charged] using debit
  have same : E.size=C.size := rfl
  rw [←same] at size ⊢
  exact (Nat.add_le_add size paid).trans_eq eq
#print axioms room
end IncidenceThetaPaid
