import IncidenceDenseRestriction
namespace IncidencePointBaseline
open CircuitRewire IncidenceZeroRestriction

def clamp (raw : Nat→Gate) (K : Finset Nat) (j : Nat) : Gate :=
  if j∈K then ⟨.zero,(raw j).left,(raw j).right⟩ else raw j

theorem clamp_budget (m n s : Nat) (g : Nat→Gate) (init : Nat→Option Nat) (K : Finset Nat) :
    (compileLiteral m n (clamp g K) init s).size + ((Finset.range s)∩K).card ≤ s := by
  induction s with
  | zero => simp [compileLiteral]
  | succ j ih =>
    let p := compileLiteral m n (clamp g K) init j
    change p.size + ((Finset.range j)∩K).card≤j at ih
    let gate := clamp g K j
    let a := literal gate.op (p.refs gate.left) (p.refs gate.right)
    change (advance p m n j a).size + _ ≤ j+1
    have one : (advance p m n j a).size≤p.size+1 := by cases a <;> simp [advance]
    by_cases h : j∈K
    · have eq : (Finset.range (j+1)∩K)=insert j (Finset.range j∩K) := by
        ext i
        simp [Finset.range_add_one]
        aesop
      have same : (advance p m n j a).size=p.size := by simp [a,gate,clamp,h,literal,advance]
      rw [same,eq,Finset.card_insert_of_notMem (by simp)]
      omega
    · have eq : (Finset.range (j+1)∩K)=Finset.range j∩K := by
        ext i
        simp [Finset.range_add_one]
        aesop
      rw [eq]
      omega

theorem baseline {Z : Type*} (m n s : Nat) (g : Nat→Gate) (init : Nat→Option Nat)
    (K : Finset Nat) (X B : Nat→Set Z)
    (bound : ∀ i<m,Below n (init i)) (src : ∀ i<m,X i=CircuitRewire.read B (init i))
    (ord : ∀ i<s,(g i).left<m+i ∧ (g i).right<m+i)
    (sem : ∀ i<s,X (m+i)=(g i).eval X)
    (zero : ∀ i<s,i∈K → X (m+i)=∅) :
    let p := compileLiteral m n (clamp g K) init s
    CorrectLiteral m n s X B init p ∧ p.size+((Finset.range s)∩K).card≤s := by
  refine ⟨literal_correct m n s _ init X B bound src ?_ ?_,clamp_budget ..⟩
  · intro i hi
    by_cases h : i∈K <;> simpa [clamp,h] using ord i hi
  · intro i hi
    by_cases h : i∈K
    · simpa [clamp,h,Gate.eval,Op.eval] using zero i hi h
    · simpa [clamp,h] using sem i hi
#print axioms baseline
end IncidencePointBaseline
