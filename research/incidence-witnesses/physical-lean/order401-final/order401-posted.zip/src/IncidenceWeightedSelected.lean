import IncidenceWeightedPlane
import IncidenceWarmSelectedOutput
namespace IncidenceWeightedSelected
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmDomain IncidencePointWarmMasks IncidenceReciprocalChoice IncidenceChosenEnds
open IncidenceWarmDichotomy
theorem cap {n : ℕ} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (c : Fin n→ℕ) (O : Finset (Fin n)) (f : Fin n→Fin n) (valid : Valid (D C I c O) f)
    (order : ∀x,removed f c x→∀y∈D C I c O x, f y=x ∧ c y<c x ∧ ¬removed f c y)
    (A : Schedule C) (w : Wiring C (edits C I c O f) A.fork c)
    (drop : A.drop=drops (edits C I c O f)) (pos : flags C I) (original : negatives C I 401 400)
    (guards : ∀y∈O,c y<n+n+C.size ∧ shadow (n+n) C.code y.val (c y) C.size C.output=false)
    (degree : ∀ l,Fintype.card {p // I p l}=402)
    (unique : ∀ a b,a≠b → ∃! l,I a l ∧ I b l) (hn : n=161203) (size : C.size≤646424) :
    (edits C I c O f).card≤3213 := by
  let l : Fin n := ⟨0,by omega⟩
  have positive : 0<Fintype.card {p // I p l} := by rw [degree]; decide
  obtain ⟨⟨p,hit⟩⟩ := Fintype.card_pos_iff.mp positive
  obtain ⟨B,cost,bin,_,yes,no,_⟩ :=
    IncidenceWarmSelectedOutput.selected C I c O f valid order A w drop ⟨p,l,hit⟩ pos original guards
  have lower := IncidenceWeightedPlane.bound I B bin yes no degree unique hn
  omega
#print axioms cap
end IncidenceWeightedSelected
