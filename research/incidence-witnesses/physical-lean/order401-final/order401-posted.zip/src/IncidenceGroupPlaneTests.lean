import IncidenceGroupDemand
import IncidencePointForeign
namespace IncidenceGroupPlaneTests
open SparseIncidence IncidenceStartNormalization IncidenceRobust IncidenceGroupDemand
variable {n : ℕ} (I : Fin n→Fin n→Prop) [DecidableRel I]
def adj : Vertex n→Finset (Vertex n)
  | .inl p => (lines I p).map Function.Embedding.inr
  | .inr l => (points I l).map Function.Embedding.inl

@[simp] theorem adj_edge (x y : Vertex n) : y∈adj I x ↔ Edge I x y := by
  cases x with
  | inl p =>
    cases y with
    | inl t =>
      constructor
      · intro h; obtain ⟨v,_,eq⟩ := Finset.mem_map.mp h; cases eq
      · exact False.elim
    | inr l =>
      constructor
      · intro h; obtain ⟨v,hv,eq⟩ := Finset.mem_map.mp h
        change (Sum.inr v : Vertex n)=Sum.inr l at eq
        cases Sum.inr.inj eq
        exact (Finset.mem_filter.mp hv).2
      · intro h
        exact Finset.mem_map.mpr ⟨l,Finset.mem_filter.mpr ⟨Finset.mem_univ _,h⟩,rfl⟩
  | inr l =>
    cases y with
    | inr k =>
      constructor
      · intro h; obtain ⟨v,_,eq⟩ := Finset.mem_map.mp h; cases eq
      · exact False.elim
    | inl p =>
      constructor
      · intro h; obtain ⟨v,hv,eq⟩ := Finset.mem_map.mp h
        change (Sum.inl v : Vertex n)=Sum.inl p at eq
        cases Sum.inl.inj eq
        exact (Finset.mem_filter.mp hv).2
      · intro h
        exact Finset.mem_map.mpr ⟨p,Finset.mem_filter.mpr ⟨Finset.mem_univ _,h⟩,rfl⟩

theorem loop (x : Vertex n) : x∉adj I x := by cases x <;> simp [Edge]
theorem symm (x y : Vertex n) : y∈adj I x→x∈adj I y := by cases x <;> cases y <;> simp [Edge]
theorem overlap (cp : ∀a b,a≠b→(lines I a∩lines I b).card≤1)
    (cl : ∀a b,a≠b→(points I a∩points I b).card≤1) (x y : Vertex n) (ne : x≠y) :
    (adj I x∩adj I y).card≤1 := by
  cases x with
  | inl a =>
    cases y with
    | inl b => simpa only [adj,←Finset.map_inter,Finset.card_map] using cp a b (fun e=>ne (e ▸ rfl))
    | inr b =>
      have emp : adj I (.inl a)∩adj I (.inr b)=∅ := by ext u; cases u <;> simp [Edge]
      simp [emp]
  | inr a =>
    cases y with
    | inr b => simpa only [adj,←Finset.map_inter,Finset.card_map] using cl a b (fun e=>ne (e ▸ rfl))
    | inl b =>
      have emp : adj I (.inr a)∩adj I (.inl b)=∅ := by ext u; cases u <;> simp [Edge]
      simp [emp]

def mask (S : Finset (Vertex n)) : Input n :=
  (fun p=>decide (Sum.inl p∈S),fun l=>decide (Sum.inr l∈S))
def wireId : Vertex n→ℕ
  | .inl p => p.val
  | .inr l => n+l.val

theorem raw (C : Circuit n) (S : Finset (Vertex n)) (x : Vertex n) :
    mask S∈C.wire (wireId x) ↔ x∈S := by
  cases x with
  | inl p => rw [wireId,(C.inputs p).1]; simp [mask]
  | inr l => rw [wireId,(C.inputs l).2]; simp [mask]

private theorem shore (S : Finset (Vertex n)) (f : Fin n ↪ Vertex n) :
    Fintype.card {i // decide (f i∈S)=true}≤S.card := by
  let e (i : {i // decide (f i∈S)=true}) : ↥S := ⟨f i.val,of_decide_eq_true i.property⟩
  simpa using Fintype.card_le_of_injective e (fun u v h=>Subtype.ext (f.injective (congrArg Subtype.val h)))

theorem neg (C : Circuit n) (valid : negatives C I 3 3) (S : Finset (Vertex n))
    (size : S.card≤3) (ind : Independent (adj I) S) : mask S∉C.wire C.output := by
  apply valid
  · exact (shore S Function.Embedding.inl).trans size
  · exact (shore S Function.Embedding.inr).trans size
  · intro p l hp hl
    exact fun flag=>ind (.inl p) (of_decide_eq_true hp) (.inr l) (of_decide_eq_true hl)
      ((adj_edge I _ _).mpr flag)

theorem up (C : Circuit n) (pos : flags C I) (S : Finset (Vertex n)) (x : Vertex n)
    (y : ∃y∈S,y∈adj I x) : mask (insert x S)∈C.wire C.output := by
  obtain ⟨y,ys,edge⟩ := y
  have e := (adj_edge I _ _).mp edge
  have flag {p l : Fin n} (i : I p l) (a : Sum.inl p∈insert x S) (b : Sum.inr l∈insert x S) :
      mask (insert x S)∈C.wire C.output := by
    apply IncidencePointShield.monotone C C.output C.output_lt _ (pos p l i)
    exact ⟨fun u h=>by have z : u=p := of_decide_eq_true h; subst u; exact decide_eq_true a,
      fun v h=>by have z : v=l := of_decide_eq_true h; subst v; exact decide_eq_true b⟩
  cases x with
  | inl p =>
    cases y with
    | inl p' => exact False.elim e
    | inr l => exact flag e (Finset.mem_insert_self ..) (Finset.mem_insert_of_mem ys)
  | inr l =>
    cases y with
    | inr l' => exact False.elim e
    | inl p => exact flag e (Finset.mem_insert_of_mem ys) (Finset.mem_insert_self ..)
end IncidenceGroupPlaneTests
#print axioms IncidenceGroupPlaneTests.up
#print axioms IncidenceGroupPlaneTests.neg
