import IncidencePhysicalCreditHistory

namespace IncidencePhysicalBudgetStop
open IncidenceThetaRoundDriver IncidenceReachableCensus
variable {n : ℕ} {I : Fin n → Fin n → Prop} [DecidableRel I] {P L : Finset (Fin n)}

def lost (a b : Stage I P L) : ℕ := (sites a.A a.B \ sites b.A b.B).card

theorem lost_triangle (s a b : Stage I P L) : lost s b ≤ lost s a + lost a b := by
  classical
  have incl : sites s.A s.B \ sites b.A b.B ⊆
      (sites s.A s.B \ sites a.A a.B) ∪ (sites a.A a.B \ sites b.A b.B) := by
    intro x hx
    obtain ⟨start,off⟩ := Finset.mem_sdiff.mp hx
    by_cases present : x ∈ sites a.A a.B
    · exact Finset.mem_union_right _ (Finset.mem_sdiff.mpr ⟨present,off⟩)
    · exact Finset.mem_union_left _ (Finset.mem_sdiff.mpr ⟨start,present⟩)
  exact (Finset.card_le_card incl).trans (Finset.card_union_le _ _)

theorem stopAt {s : Stage I P L} {nb : ℕ → Finset ℕ}
    (mark0 : Marks nb s) (goal : ℕ)
    (advance : ∀ (a : Stage I P L) (h : Finset ℕ) (v : ℕ),
      Walk s a h v → Marks nb a → v < goal → lost s a ≤ 24*v →
      a.C.size+2*((s.A.card+s.B.card)-(a.A.card+a.B.card))+v ≤ s.C.size →
      ∃ (b : Stage I P L) (h' : Finset ℕ) (v' : ℕ), Walk s b h' v' ∧
        Nonempty (Marks nb b) ∧ v < v' ∧ lost a b ≤ 24*(v'-v) ∧
        b.C.size+2*((s.A.card+s.B.card)-(b.A.card+b.B.card))+v' ≤ s.C.size) :
    ∃ (b : Stage I P L) (v : ℕ), goal ≤ v ∧
      b.C.size+2*((s.A.card+s.B.card)-(b.A.card+b.B.card))+v ≤ s.C.size := by
  let cash := fun (v : ℕ) (a : Stage I P L) =>
    a.C.size+2*((s.A.card+s.B.card)-(a.A.card+a.B.card))+v ≤ s.C.size
  suffices rec : ∀ d (a : Stage I P L) h v, goal-v=d → Walk s a h v →
      Marks nb a → lost s a ≤ 24*v → cash v a → ∃ b v, goal ≤ v ∧ cash v b by
    exact rec goal s _ 0 (by simp) Walk.start mark0 (by simp [lost]) (by simp [cash])
  intro d
  induction d using Nat.strong_induction_on with
  | ind d ih =>
    intro a h v eq walk marks loss ledger
    by_cases done : goal ≤ v
    · exact ⟨a,v,done,ledger⟩
    · obtain ⟨b,h',v',next,⟨marks'⟩,rise,stepLoss,ledger'⟩ :=
        advance a h v walk marks (by omega) loss ledger
      have triangle := lost_triangle s a b
      exact ih (goal-v') (by omega) b h' v' rfl next marks' (by omega) ledger'

#print axioms stopAt
end IncidencePhysicalBudgetStop
