import IncidenceThetaSquare
import IncidenceDenseRestriction
namespace IncidenceThetaRestrict
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceZeroRestriction
variable {n : ℕ}

def inject (P L : Finset (Fin n)) (v : Input n) : Input n :=
  (fun i=>if i∈P then v.1 i else false,fun i=>if i∈L then v.2 i else false)
def rel (I : Fin n→Fin n→Prop) (P L : Finset (Fin n)) (p l : Fin n) :=
  p∈P ∧ l∈L ∧ I p l
def kept (P L : Finset (Fin n)) : Finset ℕ :=
  P.image Fin.val ∪ L.image (fun l=>n+l.val)
def ref (P L : Finset (Fin n)) (i : ℕ) : Option ℕ :=
  if i∈kept P L then some i else none

theorem left (P L : Finset (Fin n)) (i : Fin n) :
    i.val∈kept P L ↔ i∈P := by
  simp only [kept,Finset.mem_union,Finset.mem_image]
  constructor
  · rintro (⟨p,h,e⟩|⟨l,_,e⟩)
    · exact (Fin.ext e) ▸ h
    · have := i.isLt; omega
  · intro h; exact Or.inl ⟨i,h,rfl⟩
theorem right (P L : Finset (Fin n)) (i : Fin n) :
    n+i.val∈kept P L ↔ i∈L := by
  simp only [kept,Finset.mem_union,Finset.mem_image]
  constructor
  · rintro (⟨p,_,e⟩|⟨l,h,e⟩)
    · have := p.isLt; omega
    · exact (Fin.ext (Nat.add_left_cancel e)) ▸ h
  · intro h; exact Or.inr ⟨i,h,rfl⟩

theorem inputs (C : Circuit n) (P L : Finset (Fin n)) (i : ℕ) (hi : i<n+n) :
    inject P L ⁻¹' C.wire i=read C.wire (ref P L i) := by
  by_cases lo : i<n
  · let x : Fin n := ⟨i,lo⟩
    change inject P L ⁻¹' C.wire x.val=read C.wire (ref P L x.val)
    by_cases h : x∈P <;> ext v <;> simp [ref,left,h,CircuitRewire.read,(C.inputs x).1,inject]
  · let x : Fin n := ⟨i-n,by omega⟩
    have eq : n+x.val=i := by dsimp [x]; omega
    rw [←eq]
    by_cases h : x∈L <;> ext v <;> simp [ref,right,h,CircuitRewire.read,(C.inputs x).2,inject]

def top (n : ℕ) : Input n := (fun _=>true,fun _=>true)

theorem restrict (C : Circuit n) (P L : Finset (Fin n)) (bin : binary C)
    (hit : ∃v,inject P L v∈C.wire C.output) :
    ∃B : Circuit n,binary B ∧ B.size=(compileLiteral (n+n) (n+n) C.code (ref P L) C.size).size ∧
      B.wire B.output=inject P L ⁻¹' C.wire C.output := by
  let X := fun i=>inject P L ⁻¹' C.wire i
  have bound (i) (hi : i<n+n) : Below (n+n) (ref P L i) := by
    intro w hw
    unfold ref at hw
    split at hw <;> simp_all
  have ones (w) (hw : w<n+n) : top n∈C.wire w := by
    by_cases h : w<n
    · exact ((C.inputs ⟨w,h⟩).1).symm ▸ (show (top n).1 ⟨w,h⟩=true from rfl)
    · let u : Fin n := ⟨w-n,by omega⟩
      have e : n+u.val=w := by dsimp [u]; omega
      rw [←e,(C.inputs u).2]
      rfl
  have ord (i) (hi : i<C.size) : OrderedBinary (C.code i) (n+n+i) :=
    ⟨(C.earlier i hi).1,(C.earlier i hi).2,bin i hi⟩
  have sem (i) (hi : i<C.size) : X (n+n+i)=(C.code i).eval X := by
    change _ ⁻¹' C.wire (n+n+i)=_
    rw [C.law i hi,preimage_gate]
  obtain ⟨_,order,o,oh,_,Y,base,ev,out⟩ := dense_minor (n+n) (n+n) C.size C.output C.code
    (ref P L) X C.wire (top n) bound (inputs C P L) ones ord sem C.output_lt hit
  let B : Circuit n := {
    size := (compileLiteral (n+n) (n+n) C.code (ref P L) C.size).size
    output := o
    code := (compileLiteral (n+n) (n+n) C.code (ref P L) C.size).code
    wire := Y
    output_lt := oh
    earlier := fun j hj=>⟨(order j hj).1,(order j hj).2.1⟩
    law := ev
    inputs := fun i=>⟨(base _ (by omega)).trans (C.inputs i).1,(base _ (by omega)).trans (C.inputs i).2⟩ }
  exact ⟨B,fun j hj=>(order j hj).2.2,rfl,out⟩

theorem inject_congr (P L : Finset (Fin n)) {p l : Fin n} (hp : p∈P) (hl : l∈L) :
    inject P L (single p,single l)=(single p,single l) := by
  apply Prod.ext <;> funext i
  · by_cases h : i∈P <;> by_cases e : i=p <;> simp_all [inject,single]
  · by_cases h : i∈L <;> by_cases e : i=l <;> simp_all [inject,single]

theorem tests (C B : Circuit n) (I : Fin n→Fin n→Prop) (P L : Finset (Fin n))
    (k : ℕ) (eq : B.wire B.output=inject P L ⁻¹' C.wire C.output)
    (flag : flags C I) (neg : negatives C I k k) :
    flags B (rel I P L) ∧ negatives B (rel I P L) k k := by
  constructor
  · intro p l h
    rw [eq,Set.mem_preimage,inject_congr P L h.1 h.2.1]
    exact flag p l h.2.2
  · intro a b ha hb ind h
    rw [eq,Set.mem_preimage] at h
    apply neg _ _ _ _ _ h
    · apply le_trans _ ha
      apply Fintype.card_le_of_injective (fun i=>⟨i.val,by have e:=i.property; simp [inject] at e; exact e.2⟩)
      intro i j e; exact Subtype.ext (congrArg (fun x : {p : Fin n // a p=true}=>x.val) e)
    · apply le_trans _ hb
      apply Fintype.card_le_of_injective (fun i=>⟨i.val,by have e:=i.property; simp [inject] at e; exact e.2⟩)
      intro i j e; exact Subtype.ext (congrArg (fun x : {l : Fin n // b l=true}=>x.val) e)
    · intro p l ap bl inc
      have hP : p∈P := by by_contra no; simp [inject,no] at ap
      have hL : l∈L := by by_contra no; simp [inject,no] at bl
      exact ind p l (by simpa [inject,hP] using ap) (by simpa [inject,hL] using bl) ⟨hP,hL,inc⟩
#print axioms restrict
#print axioms tests
end IncidenceThetaRestrict
