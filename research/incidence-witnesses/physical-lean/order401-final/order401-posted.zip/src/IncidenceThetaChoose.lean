import IncidenceThetaSquare
namespace IncidenceThetaBatchHoist
open SparseIncidence IncidenceStartNormalization IncidenceHoistWalk IncidenceHoistPrefix IncidenceHoistFlow
open IncidencePinHoistSparse (view mask mask_single safe)
variable {n : ℕ} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

private def same (a b : Bool) (x : Fin n) : Finset (Fin n) := if a=b then {x} else ∅
private def opp (a b : Bool) (x : Fin n) : Finset (Fin n) := if a=b then ∅ else {x}

/-- Every actual path occurrence chooses a unique input pin even across shores:
the other walk's hot singleton cannot occur on this path's shielded sibling. -/
theorem no_opposite (D : List (Raw n)) (k : ℕ) (k1 : 1≤k) (pos : flags C I)
    (neg : negatives C I (k+1) (k+1)) (degree : ∀d∈D,k<(N I d.1 d.2).card)
    (over : ∀d∈D,∀i≠d.2,(N I d.1 d.2∩N I d.1 i).card≤1)
    (j : ℕ) (a b : Bool) (pa : (j,a)∈pool C D) (pb : (j,b)∈pool C D) : a=b := by
  obtain ⟨d,hd,pd⟩ := List.mem_flatMap.mp pa
  obtain ⟨e,_,pe⟩ := List.mem_flatMap.mp pb
  have old := neg_view C I (k+1) neg
  have sing := old d.1 {d.2} ∅ (by simp) (by simp) (by simp)
  have rejected : witness d.1 d.2∉C.wire C.output := by
    cases d with | mk side x => cases side <;> simpa [view,mask_single,mask,witness] using sing
  obtain ⟨_,valid,shield⟩ := walk_shields C rejected _ _ _ (initial C _ _ (owner_hot C d.1 d.2)) (j,a) pd
  have hot := walk_hot C _ _ _ (initial C _ _ (owner_hot C e.1 e.2)) (j,b) pe
  obtain ⟨hl,hr⟩ := C.earlier j valid
  have bound : other (C.code j) a<n+n+C.size := by cases a <;> simp [other] <;> omega
  let s := same d.1 e.1 e.2
  let t := opp d.1 e.1 e.2
  have ss : s.card≤1 := by by_cases h : d.1=e.1 <;> simp [s,same,h]
  have ts : t.card≤1 := by by_cases h : d.1=e.1 <;> simp [t,opp,h]
  have vv : view d.1 s t=witness e.1 e.2 := by
    rcases d with ⟨side,x⟩; rcases e with ⟨side',y⟩
    cases side <;> cases side' <;> simp [s,t,same,opp,view,mask_single,mask,witness]
  have avoid : ∀i∈s,∀y∈t,y∉N I d.1 i := by by_cases h : d.1=e.1 <;> simp [s,t,same,opp,h]
  have blocked : view d.1 s t∉C.wire (other (C.code j) a) := by
    apply safe C d.1 d.2 _ bound shield (N I d.1) s t avoid (by have := degree d hd; omega)
      (over d hd) (adjacent C I pos d)
    intro y hy avoid'
    exact old _ _ _ ((Finset.card_le_card (Finset.erase_subset _ _)).trans (by omega))
      ((Finset.card_insert_le _ _).trans (by omega)) avoid'
  by_contra ne
  have eq : keep (C.code j) b=other (C.code j) a := by cases a <;> cases b <;> simp_all [keep,other]
  exact blocked (vv ▸ eq ▸ hot)

theorem chooses (D : List (Raw n)) (k : ℕ) (k1 : 1≤k) (pos : flags C I)
    (neg : negatives C I (k+1) (k+1)) (degree : ∀d∈D,k<(N I d.1 d.2).card)
    (over : ∀d∈D,∀i≠d.2,(N I d.1 d.2∩N I d.1 i).card≤1)
    (d : Raw n) (hd : d∈D) (e : ℕ×Bool)
    (path : e∈walk C C.size (IncidenceHoistShield.owner d.1 d.2)) : sel C D e.1=some e.2 := by
  obtain ⟨j,b⟩:=e
  have inside : (j,b)∈pool C D := List.mem_flatMap.mpr ⟨d,hd,path⟩
  have found : ((pool C D).find? (fun e=>decide (e.1=j))).isSome := by
    simpa only [List.isSome_find?,List.any_eq_true,decide_eq_true_eq] using
      (show ∃e∈pool C D,e.1=j from ⟨(j,b),inside,rfl⟩)
  cases eq : (pool C D).find? (fun e=>decide (e.1=j)) with
  | none => simp [eq] at found
  | some f =>
    obtain ⟨i,c⟩:=f
    have temp := List.find?_some eq
    have ij : i=j := of_decide_eq_true temp
    subst i
    have cb := no_opposite C I D k k1 pos neg degree over j c b (List.mem_of_find?_eq_some eq) inside
    simp [sel,eq,cb]

#print axioms no_opposite
end IncidenceThetaBatchHoist
