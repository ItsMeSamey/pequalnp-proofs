import IncidenceDenseRestriction
import IncidencePinLowLedger
import IncidenceThetaSibling
import IncidenceThetaBatch
import IncidencePointForeign
namespace IncidenceRoundReservations
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceHoistReaders
open IncidenceOperandLedger IncidenceZeroRestriction
variable {n : ℕ}

def reader (C : Circuit n) (x : ℕ) := (reader? C x).getD (0,false)
def owner (C : Circuit n) (x : ℕ) := (reader C x).1
def sib (C : Circuit n) (x : ℕ) := operand (C.code (owner C x)) (!(reader C x).2)
def sole (C : Circuit n) (E : Finset ℕ) := E.filter fun x=>uses C x=1
def designated (C : Circuit n) (E : Finset ℕ) := (sole C E).image (owner C)
def row (n : ℕ) (D : Finset ℕ) : Input n :=
  (fun p=>decide (p.val∉D),fun l=>decide (n+l.val∉D))
def small (n : ℕ) (H : Finset ℕ) : Input n :=
  (fun p=>decide (p.val∈H),fun l=>decide (n+l.val∈H))
def adj (I : Fin n→Fin n→Prop) (x y : ℕ) :=
  ∃ p l,I p l ∧ ((x=p.val ∧ y=n+l.val) ∨ (x=n+l.val ∧ y=p.val))
noncomputable def dead (C : Circuit n) (D : Finset ℕ) := IncidenceZeroRestriction.zeroAt C.wire (row n D)

theorem raw_small (C : Circuit n) (H : Finset ℕ) {i : ℕ} (hi : i<n+n) :
    small n H ∈ C.wire i ↔ i∈H := by
  by_cases ht : i<n
  · rw [(C.inputs ⟨i,ht⟩).1]
    simp [small]
  · let l : Fin n := ⟨i-n,by omega⟩
    have eq : n+l.val=i := by dsimp [l]; omega
    rw [←eq,(C.inputs l).2]
    simp [small]

theorem raw_dense (C : Circuit n) (D : Finset ℕ) {i : ℕ} (hi : i<n+n) :
    row n D ∈ C.wire i ↔ i∉D := by
  by_cases ht : i<n
  · rw [(C.inputs ⟨i,ht⟩).1]
    simp [row]
  · let l : Fin n := ⟨i-n,by omega⟩
    have eq : n+l.val=i := by dsimp [l]; omega
    rw [←eq,(C.inputs l).2]
    simp [row]

theorem pair_mask (p l : Fin n) :
    small n {p.val,n+l.val}=(single p,single l) := by
  apply Prod.ext <;> funext i
  · simp [small,single,show i.val≠n+l.val by omega,Fin.ext_iff]
  · simp [small,single,show n+i.val≠p.val by omega,Fin.ext_iff]

theorem one_mask_p (p : Fin n) : small n {p.val}=(single p,fun _=>false) := by
  apply Prod.ext <;> funext i
  · simp [small,single,Fin.ext_iff]
  · simp [small,show n+i.val≠p.val by omega]

theorem one_mask_l (l : Fin n) : small n {n+l.val}=(fun _=>false,single l) := by
  apply Prod.ext <;> funext i
  · simp [small,show i.val≠n+l.val by omega]
  · simp [small,single,Fin.ext_iff]

theorem singleton_off (C : Circuit n) (I : Fin n→Fin n→Prop) (neg : negatives C I 3 3)
    {i : ℕ} (hi : i<n+n) : small n {i}∉C.wire C.output := by
  by_cases ht : i<n
  · let p : Fin n:=⟨i,ht⟩
    change small n {p.val}∉_
    rw [one_mask_p]
    apply neg <;> simp [single,Fintype.card_subtype]
  · let l : Fin n:=⟨i-n,by omega⟩
    have eq : i=n+l.val := by dsimp [l]; omega
    rw [eq,one_mask_l]
    apply neg <;> simp [single,Fintype.card_subtype]

theorem read_unique (C : Circuit n) {x : ℕ} (one : uses C x=1) :
    owner C x<C.size ∧ operand (C.code (owner C x)) (reader C x).2=x ∧
      ∀ k<C.size,∀b,operand (C.code k) b=x→k=owner C x ∧ b=(reader C x).2 := by
  obtain ⟨j,d,e,hj,p,u⟩ := unique_reader C x one
  simpa [reader,owner,e] using And.intro hj (And.intro p u)

theorem sibling (C : Circuit n) (I : Fin n→Fin n→Prop) (bin : binary C)
    (pos : flags C I) (neg : negatives C I 3 3) {x y : ℕ} (edge : adj I x y)
    (one : uses C x=1) (meet : (C.code (owner C x)).op=.meet)
    (D : Finset ℕ) (free : y∉D) : dead C D (sib C x)=false := by
  classical
  obtain ⟨p,l,inc,xy⟩ := edge
  have hx : x<n+n := by rcases xy with h|h <;> omega
  have hy : y<n+n := by rcases xy with h|h <;> omega
  have diff : x≠y := by rcases xy with h|h <;> omega
  have hit : small n {x,y}∈C.wire C.output := by
    rcases xy with ⟨rfl,rfl⟩|⟨rfl,rfl⟩
    · rw [pair_mask]; exact pos p l inc
    · rw [Finset.pair_comm,pair_mask]; exact pos p l inc
  obtain ⟨hj,port,only⟩ := read_unique C one
  have other : sib C x≠x := by
    intro eq
    have h := (only _ hj (!(reader C x).2) eq).2
    cases e : (reader C x).2 <;> simp [e] at h
  have out : C.output≠x := by
    intro e
    have no := singleton_off C I neg hx
    rw [e,raw_small C _ hx] at no
    simp at no
  let d := (reader C x).2
  have flip := IncidenceThetaSibling.physical (n+n) C.size x (owner C x) C.output C.code C.wire
    (fun k hk=>⟨(C.earlier k hk).1,(C.earlier k hk).2,bin k hk⟩) C.law hj meet (!d)
    (fun k hk ne=>⟨fun e=>ne (only k hk true e).1,fun e=>ne (only k hk false e).1⟩)
    other C.output_lt out (small n {x,y}) (small n {y})
    (fun i hi ne=>by rw [raw_small C _ hi,raw_small C _ hi]; simp [ne]) hit (singleton_off C I neg hy)
  have sb : sib C x<n+n+C.size := by
    have o := C.earlier _ hj
    unfold sib operand
    split <;> omega
  have dense : row n D∈C.wire (sib C x) := by
    apply IncidencePointShield.monotone C _ sb _ flip
    constructor
    · intro i h
      have eq : i.val=y := by simpa [small] using h
      simp [row,eq,free]
    · intro i h
      have eq : n+i.val=y := by simpa [small] using h
      simp [row,eq,free]
  simp [dead,IncidenceZeroRestriction.zeroAt,dense]

theorem raw_flag (C : Circuit n) {i : ℕ} (hi : i<n+n) (D : Finset ℕ) :
    dead C D i=true ↔ i∈D := by
  classical
  simp [dead,IncidenceZeroRestriction.zeroAt,raw_dense C D hi]

theorem reserve (C : Circuit n) {E D : Finset ℕ} (eligible : E⊆Finset.range (n+n))
    (meet : ∀x∈sole C E,(C.code (owner C x)).op=.meet)
    (high : ∀x∈sole C E,dead C D (sib C x)=false) {x : ℕ} (hs : x∈sole C E) :
    owner C x<C.size ∧ (C.code (owner C x)).op=.meet ∧
      (((C.code (owner C x)).left=x ∧ dead C D (C.code (owner C x)).right=false) ∨
      ((C.code (owner C x)).right=x ∧ dead C D (C.code (owner C x)).left=false)) := by
  obtain ⟨hj,p,_⟩ := read_unique C (Finset.mem_filter.mp hs).2
  refine ⟨hj,meet x hs,?_⟩
  have hh := high x hs
  cases e : (reader C x).2 <;> simp [sib,operand,e] at p hh <;> tauto

theorem owner_inj (C : Circuit n) {E : Finset ℕ} (range : E⊆Finset.range (n+n))
    (meet : ∀x∈sole C E,(C.code (owner C x)).op=.meet)
    (high : ∀D⊆E,D.card≤24→∀x∈sole C E,dead C D (sib C x)=false) :
    Set.InjOn (owner C) (↑(sole C E) : Set ℕ) := by
  intro x hx y hy eq
  by_contra ne
  let D : Finset ℕ := {x,y}
  have sub : D⊆E := by
    intro i hi
    rcases Finset.mem_insert.mp hi with rfl|h
    · exact (Finset.mem_filter.mp hx).1
    · rw [Finset.mem_singleton.mp h]
      exact (Finset.mem_filter.mp hy).1
  have sz : D.card≤24 := by simp [D,ne]
  let gate := C.code (owner C x)
  have recov (u : ℕ) (h : u∈sole C E) (mem : u∈D) :
      (if dead C D (C.code (owner C u)).left then (C.code (owner C u)).left else (C.code (owner C u)).right)=u := by
    have low := (raw_flag C (Finset.mem_range.mp (range (Finset.mem_filter.mp h).1)) D).mpr mem
    rcases (reserve C range meet (high D sub sz) h).2.2 with ⟨a,b⟩|⟨a,b⟩ <;> simp [a,b,low]
  have one := recov x hx (by simp [D])
  have two := recov y hy (by simp [D])
  rw [eq] at one
  exact ne (one.symm.trans two)
end IncidenceRoundReservations
