import IncidencePointSuffix
namespace IncidencePointCommon
open CircuitRewire IncidenceZeroRestriction IncidencePointBaseline IncidencePointSuffix IncidencePointGuards
variable {Z : Type*}

/-- Unroll the common reverse-tail schedule, on original baseline wire IDs. -/
def factors (G : Finset Nat) (sibling : G→Nat) (next : G→Option G)
    (later : ∀ u v,next u=some v → u.val<v.val) (u : G) : List Nat :=
  sibling u :: match h : next u with
  | none=>[]
  | some v=>factors G sibling next later v
termination_by (index G u).val
decreasing_by exact reverse_index G u v (later u v h)

def active (X : Nat→Set Z) (xs : List Nat) : Set Z :=
  {z|∀ j∈xs,z∈X j}

theorem common (m n s : Nat) (raw : Nat→Gate) (init : Nat→Option Nat) (K G : Finset Nat)
    (X B : Nat→Set Z) (nonempty : 0<n)
    (bound : ∀i<m,Below n (init i)) (src : ∀i<m,X i=CircuitRewire.read B (init i))
    (ord : ∀i<s,(raw i).left<m+i ∧ (raw i).right<m+i)
    (sem : ∀i<s,X (m+i)=(raw i).eval X) (zero : ∀i<s,i∈K → X (m+i)=∅)
    (sub : G⊆Finset.range s∩K) (sibling : G→Nat) (sib : ∀u,sibling u<m+s)
    (next : G→Option G) (later : ∀u v,next u=some v → u.val<v.val) :
    ∃ sz≤s, ∃ code : Nat→Gate,∃ Y : Nat→Set Z,∃ ids : G→Nat,
      (∀i<n,Y i=B i) ∧ (∀i<sz,(code i).left<n+i ∧ (code i).right<n+i) ∧
      (∀i<sz,Y (n+i)=(code i).eval Y) ∧
      ∀u,ids u<n+sz ∧ Y (ids u)=active X (factors G sibling next later u) := by
  obtain ⟨correct,save⟩ := baseline m n s raw init K X B bound src ord sem zero
  let p := compileLiteral m n (clamp raw K) init s
  obtain ⟨_,refs,ops,Y,base,laws,rep⟩ := correct
  let R := fun u=>active X (factors G sibling next later u)
  let wire := fun u=>p.refs (sibling u)
  have form (u : G) : R u=CircuitRewire.read Y (wire u) ∩ (next u).elim Set.univ R := by
    have v := rep (sibling u) (sib u)
    change X (sibling u)=CircuitRewire.read Y (wire u) at v
    rw [←v]
    change active X (factors G sibling next later u)=_
    rw [factors]
    cases h : next u <;> simp [h,active,R,Set.ext_iff]
  have run := packed n p.size G p.code Y wire next R (by omega)
    (fun i hi=>⟨(ops i hi).1,(ops i hi).2.1⟩) laws
    (fun u k hk=>refs (sibling u) (sib u) k hk) later form
  let v := CatValues n p.size Y (values G R)
  have gc := Finset.card_le_card sub
  change p.size + ((Finset.range s)∩K).card ≤ s at save
  refine ⟨_,show p.size+G.card≤s by omega,_,v,(fun u=>n+p.size+(index G u).val),?_,
    run.1,run.2.1,?_⟩
  · intro i hi
    exact (run.2.2.1 i (by omega)).trans (base i hi)
  · intro u
    exact ⟨by dsimp only; have := (index G u).isLt; omega,run.2.2.2 u⟩
#print axioms common
end IncidencePointCommon
