import IncidenceLineColdSibling
import IncidenceLineBaselineView
namespace IncidenceActualLineCredit
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceLineGateBooking
open IncidenceLineRoutedSlots IncidenceLineRouteTree IncidenceLineTraceConstruction
open IncidenceLineBaselineView IncidenceLineColdSibling IncidenceRobust
theorem credit {n : ℕ} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (degree : ∀l,Fintype.card {p // I p l}=401+1)
    (ops : binary C) (pos : flags C I) (neg : negatives C I n 401)
    (x w : Fin n) {j : ℕ} (chain : Corridor C x j) (cold : (avoid I x w,single x)∉C.wire j) :
    ∃ book : Finset (Fin C.size×Fin n), 3106≤book.card ∧ ∀z∈book,
      (avoid I x w,fun _=>false) ∉ C.wire (n+n+z.1.val) ∧
      2<(points I x ∩ support C z.1).card ∧ eligible C I x z.1 z.2 := by
  classical
  obtain ⟨b,bb,reject,accept⟩ := sibling C I ops pos neg x w chain cold
  have all : labels C I x b=points I x := by
    ext p
    simp only [labels,points,Finset.mem_filter,Finset.mem_univ,true_and]
    exact ⟨And.left,fun h=>⟨h,accept p h⟩⟩
  have size : (points I x).card=402 := points_card I degree x
  have view := baseline C I x w b bb reject
  rw [all] at view
  obtain ⟨t,book,route⟩ := build view (points I x) (fun _ h=>h)
    (Finset.card_pos.mp (by omega))
  obtain ⟨many,each⟩ := from_402 route size
  refine ⟨book,many,?_⟩
  intro z hz
  obtain ⟨cz,hz',ez⟩ := each z hz
  refine ⟨cz,?_,ez⟩
  unfold heavy at hz'
  apply lt_of_lt_of_le hz' (Finset.card_le_card ?_)
  intro p hp
  simp only [Finset.mem_filter,Finset.mem_univ,true_and] at hp
  obtain ⟨hx,hp⟩ := hp
  exact Finset.mem_inter.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _,hx⟩,
    Finset.mem_filter.mpr ⟨Finset.mem_univ _,hp⟩⟩
#print axioms credit
end IncidenceActualLineCredit
