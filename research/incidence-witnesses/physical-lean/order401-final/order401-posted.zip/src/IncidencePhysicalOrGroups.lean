import IncidenceHoistReaders
import IncidenceHoistPrune
namespace IncidencePhysicalOrGroups
open CircuitRewire IncidenceStartNormalization IncidenceHoistReaders IncidenceHoistPrune
variable {n : ℕ} (C : Circuit n)
abbrev Row (C : Circuit n) := Fin C.size
def wire (g : Row C) := n+n+g.val
def Reads (g : Row C) (w : ℕ) (b : Bool) := operand (C.code g) b=w
def Next (g h : Row C) : Prop := wire C g≠C.output ∧ uses C (wire C g)=1 ∧
  (C.code h).op=.join ∧ ∃b,Reads C h (wire C g) b
def Top (g : Row C) := (C.code g).op=.join ∧ ¬∃h,Next C g h
inductive Path : Row C→Row C→Prop
  | refl (g) : Path g g
  | step {g h k} : Next C g h → Path h k → Path g k

theorem parent_lt {g h : Row C} (edge : Next C g h) : g.val<h.val := by
  obtain ⟨_,_,_,b,hb⟩ := edge
  have limits := C.earlier h h.isLt
  cases b <;> simp [Reads,operand,wire] at hb <;> omega

theorem next_unique {g h k : Row C} (a : Next C g h) (b : Next C g k) : h=k := by
  obtain ⟨_,one,_,u,hu⟩ := a
  obtain ⟨_,_,_,v,hv⟩ := b
  obtain ⟨r,side,_,_,_,unique⟩ := unique_reader C (wire C g) one
  exact Fin.ext ((unique h h.isLt u hu).1.trans (unique k k.isLt v hv).1.symm)
theorem terminate (g : Row C) (join : (C.code g).op=.join) :
    ∃t,Top C t ∧ Path C g t := by
  classical
  by_cases step : ∃h,Next C g h
  · obtain ⟨h,edge⟩ := step
    obtain ⟨t,top,path⟩ := terminate h edge.2.2.1
    exact ⟨t,top,.step edge path⟩
  · exact ⟨g,⟨join,step⟩,.refl _⟩
termination_by C.size-g.val
decreasing_by have := parent_lt C edge; have := h.isLt; omega

def Member (x : ℕ) (g : Row C) := ∃ r : Row C, ∃ b, (C.code r).op=.join ∧
    Reads C r x b ∧ Path C r g ∧ Top C g

theorem route {x : ℕ} (r : Row C) (b : Bool) (join : (C.code r).op=.join)
    (raw : Reads C r x b) : ∃g,Member C x g := by
  obtain ⟨g,top,path⟩ := terminate C r join
  exact ⟨g,r,b,join,raw,path,top⟩
theorem unique_top {r g h : Row C} (p : Path C r g) (q : Path C r h)
    (t : Top C g) (u : Top C h) : g=h := by
  induction p with
  | refl =>
    cases q with
    | refl => rfl
    | step edge _ => exact False.elim (t.2 ⟨_,edge⟩)
  | step edge tail ih =>
    cases q with
    | refl => exact False.elim (u.2 ⟨_,edge⟩)
    | step ed rest =>
      have e := next_unique C edge ed
      subst_vars
      exact ih rest t

theorem route_all (x : ℕ) (two : uses C x=2)
    (joins : ∀r b,Reads C r x b → (C.code r).op=.join) :
    ∃g h,Member C x g ∧ Member C x h ∧ ∀k, Member C x k → k=g ∨ k=h := by
  have len : (occurrences C x).length=2 := (occurrence_count C x).trans two
  obtain ⟨a,b,ab⟩ : ∃ a b,occurrences C x=[a,b] := by
    cases e : occurrences C x with
    | nil => simp [e] at len
    | cons a rest =>
      cases rest with
      | nil => simp [e] at len
      | cons b tail =>
        have z : tail=[] := List.length_eq_zero_iff.mp (by simpa [e] using len)
        subst tail
        exact ⟨a,b,rfl⟩
  have am : a∈occurrences C x := by simp [ab]
  have bm : b∈occurrences C x := by simp [ab]
  obtain ⟨ha,ra⟩ := (occurrence_mem C x a.1 a.2).mp am
  obtain ⟨hb,rb⟩ := (occurrence_mem C x b.1 b.2).mp bm
  let ar : Row C := ⟨a.1,ha⟩
  let br : Row C := ⟨b.1,hb⟩
  have ja := joins ar a.2 ra
  have jb := joins br b.2 rb
  obtain ⟨g,t,p⟩ := terminate C ar ja
  obtain ⟨h,u,q⟩ := terminate C br jb
  refine ⟨g,h,⟨ar,a.2,ja,ra,p,t⟩,⟨br,b.2,jb,rb,q,u⟩,?_⟩
  rintro k ⟨r,s,_,pin,walk,tk⟩
  have ent := (occurrence_mem C x r.val s).mpr ⟨r.isLt,pin⟩
  rw [ab] at ent
  simp only [List.mem_cons,List.not_mem_nil,or_false] at ent
  rcases ent with ea|eb
  · have eq : r=ar := Fin.ext (congrArg Prod.fst ea)
    subst r
    exact Or.inl (unique_top C walk p tk t)
  · have eq : r=br := Fin.ext (congrArg Prod.fst eb)
    subst r
    exact Or.inr (unique_top C walk q tk u)
end IncidencePhysicalOrGroups
