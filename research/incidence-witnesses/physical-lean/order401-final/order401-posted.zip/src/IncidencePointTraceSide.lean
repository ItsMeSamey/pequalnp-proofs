import IncidencePointNativeMerge
import IncidencePointCorridor
namespace IncidencePointCorridor
open CircuitRewire IncidencePointShield IncidenceStartNormalization IncidencePointWarmMasks
variable {m : Nat} {code : Nat→Gate}

def Path.ports : {a b : Nat}→Path m code a b→List (Nat×Bool)
  | _,_,.nil _ => []
  | _,_,.cons g side tail => (g,side)::tail.ports

theorem port_guards {a b : Nat} (P : Path m code a b) (x z s g : Nat) (side : Bool)
    (ok : P.check z x s) (occ : (g,side)∈P.ports) :
    g<s ∧ shadow m code x (m+s) s (inputPort (code g) (!side))=false ∧
    shadow m code x (m+g) s z=false := by
  induction P with
  | nil _ => simp [Path.ports] at occ
  | cons j bit tail ih =>
    obtain ⟨hj,away,dom,rest⟩ := ok
    rcases List.mem_cons.mp occ with eq|mem
    · cases eq; exact ⟨hj,away,dom⟩
    · exact ih rest mem

theorem side_unique {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) (pos : flags C I)
    (neg : negatives C I 401 400) (x y l : Fin n) (ix : I x l) (iy : I y l)
    {a b : Nat} (P : Path (n+n) C.code x.val a) (Q : Path (n+n) C.code y.val b)
    (pc : P.check C.output x.val C.size) (qc : Q.check C.output y.val C.size)
    (g : Nat) (s t : Bool) (occ : (g,s)∈P.ports) (occ' : (g,t)∈Q.ports)
    (meet : (C.code g).op=.meet) : s=t := by
  obtain ⟨hg,as,ds⟩ := port_guards P _ _ _ _ _ pc occ
  obtain ⟨_,at',dt⟩ := port_guards Q _ _ _ _ _ qc occ'
  cases s <;> cases t
  · rfl
  · exact False.elim (native_merge C I pos neg x y l ix iy g hg ds dt as at' meet)
  · exact False.elim (native_merge C I pos neg y x l iy ix g hg dt ds at' as meet)
  · rfl
#print axioms side_unique
end IncidencePointCorridor
