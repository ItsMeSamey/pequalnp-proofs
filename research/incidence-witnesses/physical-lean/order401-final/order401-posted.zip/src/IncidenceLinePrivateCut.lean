import IncidencePointForeign
import IncidenceLineGateBooking
namespace IncidenceLinePrivateCut
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidencePointShield
variable {n : ℕ}

theorem pre_shield (C : Circuit n) (x cut : ℕ) (u v : Input n)
    (same : ∀i<n+n,i≠x → (u∈C.wire i ↔ v∈C.wire i))
    (j : ℕ) (before : j<cut) (bound : j<n+n+C.size)
    (free : shadow (n+n) C.code x cut C.size j=false) :
    u∈C.wire j ↔ v∈C.wire j := by
  induction j using Nat.strong_induction_on with | ind j prev =>
  by_cases low : j<n+n
  · apply same j low
    intro eq
    have neq : j≠cut := Nat.ne_of_lt before
    rw [raw _ _ _ _ _ j low] at free
    simp [eq,eq ▸ neq] at free
  let g := j-(n+n)
  have id : j=n+n+g := by dsimp [g]; omega
  have lim : g<C.size := by omega
  obtain ⟨l,r⟩ := C.earlier g lim
  rw [id,gate _ _ _ _ _ g lim l r] at free
  have apart : n+n+g≠cut := by omega
  simp [apart] at free
  have L := prev _ (by omega : (C.code g).left < j) (by omega) (by omega) free.1
  have R := prev _ (by omega : (C.code g).right < j) (by omega) (by omega) free.2
  rw [id,C.law g lim]
  cases e : (C.code g).op <;> simp [Gate.eval,Op.eval,e,L,R]

theorem raw_other (C : Circuit n) (x : Fin n) (a : Fin n→Bool) :
    ∀ i<n+n,i≠n+x.val →
      ((a, single x)∈C.wire i ↔ (a,fun _=>false)∈C.wire i) := by
  intro i hi ne
  by_cases h : i<n
  · let p : Fin n := ⟨i,h⟩
    rw [(C.inputs p).1]
    rfl
  · let l : Fin n := ⟨i-n,by omega⟩
    have eq : i=n+l.val := by dsimp [l]; omega
    have diff : l≠x := by intro same; rw [eq,same] at ne; contradiction
    rw [eq,(C.inputs l).2]
    simp [single,diff]

theorem high_at_line_cut (C : Circuit n) (I : Fin n→Fin n→Prop)
    (yes : flags C I) (no : negatives C I n 401) (p x : Fin n) (inc : I p x)
    (cut : ℕ) (hc : cut<n+n+C.size) (blocked : shadow (n+n) C.code (n+x.val) cut C.size C.output=false) :
    (single p,single x)∈C.wire cut := by
  by_contra cutFalse
  have baseFalse : (single p,fun _=>false) ∉ C.wire cut := by
    intro h
    apply cutFalse
    apply monotone C cut hc _ h
    exact ⟨fun _ z=>z,by simp⟩
  have H := shield _ _ C.code C.wire C.earlier C.law (n+x.val) cut
    (single p,single x) (single p,fun _=>false) (raw_other C x (single p))
    (iff_of_false cutFalse baseFalse) C.output C.output_lt blocked
  have hit := H.mp (yes p x inc)
  apply no _ _ (by simpa using Fintype.card_subtype_le (fun i : Fin n=>single p i=true))
    (by simp [Fintype.card_subtype]) _ hit
  intro _ _ _ h; contradiction
end IncidenceLinePrivateCut
