import IncidencePhysical401Caller
import IncidenceRoundPlaneIds
import IncidenceRoundLiteralShock
namespace IncidencePhysical401Caller
open IncidenceReachableCensus IncidenceThetaRoundDriver IncidenceThetaRestrict
open IncidenceMarkTransition IncidenceLabelHistory IncidenceAllowedGeometry IncidencePhysicalCreditHistory
theorem scalar : IncidenceOfficialScalar.ScalarLower401 := by
  classical
  apply from_circuits
  intro n I _ hn deg join P L s pc lc fa fb upper cold one
  obtain ⟨inside,degree,codeg⟩ := IncidenceRoundPlaneIds.geometry I hn deg join
  apply rounds s hn pc lc join fa fb upper cold one inside degree codeg
  intro a h m guard A B b live legal _ free ea eb sz code
  have core : P.Nonempty := Finset.card_pos.mp (by omega)
  let prot := (sites P L ∪ reserve m.M m.G) ∪ h
  let D := kept a.A a.B \ kept A B
  have np : nextP a.A D=A := by
    ext p
    simp only [nextP,D,Finset.mem_filter,Finset.mem_sdiff,left]
    constructor
    · rintro ⟨pa,stay⟩
      by_contra off
      exact stay ⟨pa,off⟩
    · intro pa; exact ⟨legal.subP pa,fun k=>k.2 pa⟩
  have nl : nextL a.B D=B := by
    ext l
    simp only [nextL,D,Finset.mem_filter,Finset.mem_sdiff,right]
    constructor
    · rintro ⟨la,stay⟩
      by_contra off
      exact stay ⟨la,off⟩
    · intro la; exact ⟨legal.subL la,fun k=>k.2 la⟩
  have count := deleted_card a.A a.B D (show D⊆kept a.A a.B from Finset.sdiff_subset)
  rw [np,nl] at count
  have booked := IncidenceRoundLiteralShock.physical a m.M m.G prot live core m.safe
    (fun x hx=>Finset.mem_union_left _ (Finset.mem_union_left _ hx))
    (fun x hx=>Finset.mem_union_left _ (Finset.mem_union_right _ hx))
    (guard.trans Finset.subset_union_right) D free (count ▸ legal.small) b
    (ea.trans np.symm) (eb.trans nl.symm)
    (by simpa only [np,nl] using sz) (by simpa only [np,nl] using code)
  unfold credit
  rw [ea,eb]
  omega
#print axioms scalar
end IncidencePhysical401Caller
