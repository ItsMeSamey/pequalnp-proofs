import IncidenceThetaFour
import IncidenceThetaSquare
namespace IncidenceThetaPath
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceThetaFour
open IncidencePinHoistSparse (view mask)
variable {n : ℕ}

def sites (a b : Fin n) (i : Fin 8) (first second : Mask) : Finset (Fin n) :=
  (if first.getLsbD i then {a} else ∅) ∪ (if second.getLsbD i then {b} else ∅)
def rows (x p l Y : Fin n) (i : Fin 8) : Input n :=
  (IncidencePinHoistSparse.mask (sites x p i 137 38),IncidencePinHoistSparse.mask (sites l Y i 19 196))

private theorem record_sites (a b x : Fin n) (ab : a≠b) (f g : Mask)
    (r : Fin 8→Input n) (X : Set (Input n)) (h : ∀i,r i∈X ↔ x∈sites a b i f g) :
    record r X=(if x=a then f else if x=b then g else 0) := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  apply Bool.eq_iff_iff.mpr
  rw [record_get r X i hi,h]
  by_cases ha : x=a <;> by_cases hb : x=b <;> cases fa : f.getLsbD i <;> cases gb : g.getLsbD i <;>
    simp_all [sites]

theorem path (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I] (x p l Y : Fin n)
    (xp : x≠p) (ly : l≠Y) (xl : I x l) (pl : I p l) (py : I p Y) (xy : ¬I x Y)
    (pos : flags C I) (neg : negatives C I 1 1) : 4≤C.size := by
  let r := rows x p l Y
  have co (w) (hw : w<n+n) : record r (C.wire w)∈raws := by
    by_cases lo : w<n
    · let i : Fin n := ⟨w,lo⟩
      have h := record_sites x p i xp 137 38 r (C.wire w) (by
        intro j; rw [(C.inputs i).1]; simp [r,rows,IncidencePinHoistSparse.mask])
      rw [h]; split <;> first | decide | (split <;> decide)
    · let i : Fin n := ⟨w-n,by omega⟩
      have eq : n+i.val=w := by dsimp [i]; omega
      rw [←eq]
      have h := record_sites l Y i ly 19 196 r (C.wire (n+i.val)) (by
        intro j; rw [(C.inputs i).2]; simp [r,rows,IncidencePinHoistSparse.mask])
      rw [h]; split <;> first | decide | (split <;> decide)
  have tests : record r (C.wire C.output)=target := by
    apply BitVec.eq_of_getLsbD_eq
    intro i hi
    apply Bool.eq_iff_iff.mpr
    rw [record_get r _ i hi]
    have nr := IncidenceThetaBatchHoist.neg_view C I 1 neg false
    have simp0 : IncidencePinHoistSparse.mask (∅ : Finset (Fin n))=(fun _=>false) := IncidenceThetaBatchHoist.mask_empty
    have nilP := nr {x} ∅ (by simp) (by simp) (by simp)
    have nilL := nr ∅ {l} (by simp) (by simp) (by simp)
    have nilP' := nr {p} ∅ (by simp) (by simp) (by simp)
    have nilL' := nr ∅ {Y} (by simp) (by simp) (by simp)
    have far := nr {x} {Y} (by simp) (by simp) (by simpa [IncidenceThetaBatchHoist.N] using xy)
    rcases (show i=0 ∨ i=1 ∨ i=2 ∨ i=3 ∨ i=4 ∨ i=5 ∨ i=6 ∨ i=7 by omega) with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · simp only [show target.getLsbD 0=true from rfl, Bool.false_eq_true, not_false_eq_true, eq_self, iff_true, iff_false]
      convert pos x l xl using 1 <;> simp [r,rows,sites,view,IncidencePinHoistSparse.mask_single,show (137 : Mask).getLsbD 0=true from rfl, show (38 : Mask).getLsbD 0=false from rfl, show (19 : Mask).getLsbD 0=true from rfl, show (196 : Mask).getLsbD 0=false from rfl]
    · simp only [show target.getLsbD 1=true from rfl, Bool.false_eq_true, not_false_eq_true, eq_self, iff_true, iff_false]
      convert pos p l pl using 1 <;> simp [r,rows,sites,view,IncidencePinHoistSparse.mask_single,show (137 : Mask).getLsbD 1=false from rfl, show (38 : Mask).getLsbD 1=true from rfl, show (19 : Mask).getLsbD 1=true from rfl, show (196 : Mask).getLsbD 1=false from rfl]
    · simp only [show target.getLsbD 2=true from rfl, Bool.false_eq_true, not_false_eq_true, eq_self, iff_true, iff_false]
      convert pos p Y py using 1 <;> simp [r,rows,sites,view,IncidencePinHoistSparse.mask_single,show (137 : Mask).getLsbD 2=false from rfl, show (38 : Mask).getLsbD 2=true from rfl, show (19 : Mask).getLsbD 2=false from rfl, show (196 : Mask).getLsbD 2=true from rfl]
    · simp only [show target.getLsbD 3=false from rfl, Bool.false_eq_true, not_false_eq_true, eq_self, iff_true, iff_false]
      convert nilP using 1 <;> simp [r,rows,sites,view,IncidencePinHoistSparse.mask_single,show (137 : Mask).getLsbD 3=true from rfl, show (38 : Mask).getLsbD 3=false from rfl, show (19 : Mask).getLsbD 3=false from rfl, show (196 : Mask).getLsbD 3=false from rfl]
    · simp only [show target.getLsbD 4=false from rfl, Bool.false_eq_true, not_false_eq_true, eq_self, iff_true, iff_false]
      convert nilL using 1 <;> simp [r,rows,sites,view,IncidencePinHoistSparse.mask_single,show (137 : Mask).getLsbD 4=false from rfl, show (38 : Mask).getLsbD 4=false from rfl, show (19 : Mask).getLsbD 4=true from rfl, show (196 : Mask).getLsbD 4=false from rfl]
    · simp only [show target.getLsbD 5=false from rfl, Bool.false_eq_true, not_false_eq_true, eq_self, iff_true, iff_false]
      convert nilP' using 1 <;> simp [r,rows,sites,view,IncidencePinHoistSparse.mask_single,show (137 : Mask).getLsbD 5=false from rfl, show (38 : Mask).getLsbD 5=true from rfl, show (19 : Mask).getLsbD 5=false from rfl, show (196 : Mask).getLsbD 5=false from rfl]
    · simp only [show target.getLsbD 6=false from rfl, Bool.false_eq_true, not_false_eq_true, eq_self, iff_true, iff_false]
      convert nilL' using 1 <;> simp [r,rows,sites,view,IncidencePinHoistSparse.mask_single,show (137 : Mask).getLsbD 6=false from rfl, show (38 : Mask).getLsbD 6=false from rfl, show (19 : Mask).getLsbD 6=false from rfl, show (196 : Mask).getLsbD 6=true from rfl]
    · simp only [show target.getLsbD 7=false from rfl, Bool.false_eq_true, not_false_eq_true, eq_self, iff_true, iff_false]
      convert far using 1 <;> simp [r,rows,sites,view,IncidencePinHoistSparse.mask_single,show (137 : Mask).getLsbD 7=true from rfl, show (38 : Mask).getLsbD 7=false from rfl, show (19 : Mask).getLsbD 7=false from rfl, show (196 : Mask).getLsbD 7=true from rfl]
  exact physical (n+n) C.size C.output C.code C.wire r co C.earlier C.law C.output_lt tests
#print axioms path
end IncidenceThetaPath
