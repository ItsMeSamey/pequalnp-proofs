import IncidenceReachableCensus
namespace IncidenceReachableCensus
open IncidenceThetaRoundDriver IncidenceLabelHistory IncidenceMarkTransition
variable {n : ℕ} {I : Fin n → Fin n → Prop} [DecidableRel I] {P L : Finset (Fin n)}

/-- The progress target is paid credit; one edit can cross it by more than one.
    The caller only supplies progress on histories actually constructed. -/
theorem stopAt {s : Stage I P L} {nb : ℕ→Finset ℕ}
    (mark0 : Marks nb s) (goal : ℕ)
    (advance : ∀ (a : Stage I P L) (h : Finset ℕ) (paid : ℕ),
      Walk s a h paid → Marks nb a → paid<goal →
      a.C.size+2*((s.A.card+s.B.card)-(a.A.card+a.B.card))+paid≤s.C.size →
      ∃ (b : Stage I P L) (h' : Finset ℕ) (v : ℕ), Walk s b h' v ∧
        Nonempty (Marks nb b) ∧ paid<v ∧
        b.C.size+2*((s.A.card+s.B.card)-(b.A.card+b.B.card))+v≤s.C.size) :
    ∃ (b : Stage I P L) (v : ℕ), goal≤v ∧
      b.C.size+2*((s.A.card+s.B.card)-(b.A.card+b.B.card))+v≤s.C.size := by
  let stop := fun (v : ℕ) (a : Stage I P L) =>
    a.C.size+2*((s.A.card+s.B.card)-(a.A.card+a.B.card))+v≤s.C.size
  suffices rec : ∀ d (a : Stage I P L) h paid, goal-paid=d → Walk s a h paid →
      Marks nb a → stop paid a → ∃ b v,goal≤v ∧ stop v b by
    exact rec goal s _ 0 (by simp) (Walk.start) mark0 (by simp [stop])
  intro d
  induction d using Nat.strong_induction_on with
  | ind d ih =>
    intro a h v eq walk marks cash
    by_cases done : goal≤v
    · exact ⟨a,v,done,cash⟩
    · obtain ⟨b,h',v',next,⟨marks'⟩,rise,ledger⟩ := advance a h v walk marks (by omega) cash
      exact ih (goal-v') (by omega) b h' v' rfl next marks' ledger
end IncidenceReachableCensus
