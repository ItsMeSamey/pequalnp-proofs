import IncidenceWarmCompiler
namespace IncidenceWarmCompiler
open CircuitRewire IncidenceZeroRestriction
/-- The forwarded result is only inspected for presence, so the new row address is irrelevant. -/
def forwarded (fresh : ℕ) : Action → Option ℕ
  | .reuse r => r
  | .emit _ => some fresh

def bit (r : Option ℕ) := if r.isSome then 1 else 0

theorem local_credit (op : Op) (l r : Option ℕ) (fresh : ℕ) (side : Bool) :
    emitted (literal op l r) + bit (forwarded fresh (literal op l r)) ≤
      1 + bit (if side then r else l) := by
  cases op <;> cases l <;> cases r <;> cases side <;> simp [emitted,literal,bit,forwarded]

theorem first_credit (l r : Option ℕ) (side : Bool)
    (dead : (if side then r else l)=none) (fresh : ℕ) :
    emitted (literal .meet l r) + bit (forwarded fresh (literal .meet l r)) = 0 := by
  cases l <;> cases r <;> cases side <;> simp_all [literal,emitted,forwarded,bit]

/-- Each list entry records its actual base-row emission and its available output bit.
The terminal bit pays for the raw reinjection at the fork. -/
def Continuation (incoming : ℕ) : List (ℕ×ℕ) → Prop
  | [] => True
  | (cost,live)::rest => cost+live≤1+incoming ∧ Continuation live rest

def terminal (v : ℕ) : List (ℕ×ℕ) → ℕ
  | [] => v
  | (_,b)::xs => terminal b xs

theorem telescope (v : ℕ) (xs : List (ℕ×ℕ)) (h : Continuation v xs) :
    (xs.map Prod.fst).sum + terminal v xs ≤ xs.length+v := by
  induction xs generalizing v with
  | nil => simp [terminal]
  | cons a xs ih =>
    rcases a with ⟨c,b⟩
    obtain ⟨first,rest⟩ := h
    have tail := ih b rest
    simp only [List.map_cons,List.sum_cons,List.length_cons,terminal]
    omega

theorem injection_cost (interim : Option ℕ) (raw : ℕ) :
    emitted (literal .join interim (some raw))=bit interim := by
  cases interim <;> rfl

theorem private_credit (xs : List (ℕ×ℕ)) (ok : Continuation 0 xs) :
    ((0::xs.map Prod.fst).sum + terminal 0 xs)+1 ≤ xs.length+1 := by
  have := telescope 0 xs ok
  simp at this ⊢
  omega

end IncidenceWarmCompiler
