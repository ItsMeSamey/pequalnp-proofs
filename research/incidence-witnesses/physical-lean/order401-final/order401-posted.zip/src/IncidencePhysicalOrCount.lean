import IncidencePhysicalOrGroups
import IncidenceLineRoutedSlots
import Mathlib.Data.Finset.Prod
open scoped BigOperators
namespace IncidencePhysicalOrGroups
open CircuitRewire IncidenceStartNormalization IncidenceHoistReaders IncidenceHoistPrune
variable {n : ℕ} (C : Circuit n)
noncomputable def tops : Finset (Row C) := by classical exact Finset.univ.filter (Top C)
def branches := (Finset.univ : Finset (Row C)).filter (fun g=>2≤uses C (wire C g))
def meets := (Finset.univ : Finset (Row C)).filter (fun (g : Row C)=>(C.code g).op=.meet)
def slots := (meets C).product (Finset.univ : Finset Bool)
def internalSlots := (slots C).filter (fun s=>n+n≤operand (C.code s.1) s.2)

theorem read_exists {w : ℕ} (anc : Anc C w) (ne : w≠C.output) :
    ∃g : Row C, ∃b,Reads C g w b := by
  cases anc with
  | output => exact False.elim (ne rfl)
  | left j hj _ => exact ⟨⟨j,hj⟩,true,rfl⟩
  | right j hj _ => exact ⟨⟨j,hj⟩,false,rfl⟩

theorem top_class (bin : binary C) (live : Live C) {g : Row C} (top : Top C g) :
    wire C g=C.output ∨ g∈branches C ∨
      ∃s∈internalSlots C,operand (C.code s.1) s.2=wire C g := by
  classical
  by_cases eq : wire C g=C.output
  · exact Or.inl eq
  by_cases high : 2≤uses C (wire C g)
  · exact Or.inr (Or.inl (by simp [branches,high]))
  obtain ⟨h,b,pin⟩ := read_exists C (live g g.isLt) eq
  have entry := (occurrence_mem C (wire C g) h b).mpr ⟨h.isLt,pin⟩
  have nonzero := List.length_pos_of_mem entry
  rw [occurrence_count] at nonzero
  have one : uses C (wire C g)=1 := by omega
  rcases bin h h.isLt with jo|me
  · exact False.elim (top.2 ⟨h,eq,one,jo,b,pin⟩)
  · apply Or.inr ∘ Or.inr
    refine ⟨(h,b),?_,pin⟩
    have p : operand (C.code h) b=wire C g := pin
    simp [internalSlots,slots,meets,me,p,wire]
theorem count (bin : binary C) (live : Live C) (reserved : Finset (Row C × Bool))
    (mem : reserved ⊆ slots C)
    (raw : ∀s∈reserved,operand (C.code s.1) s.2<n+n) :
    (tops C).card + reserved.card ≤ 1+(branches C).card+2*(meets C).card := by
  classical
  let W : Row C ↪ ℕ := ⟨wire C,by intro a b e; apply Fin.ext; dsimp [wire] at e; omega⟩
  let rd (s : Row C × Bool) := operand (C.code s.1) s.2
  have cover : (tops C).map W ⊆ ({C.output} ∪ (branches C).map W) ∪ (internalSlots C).image rd := by
    intro i hi
    obtain ⟨g,ht,rfl⟩ := Finset.mem_map.mp hi
    rcases top_class C bin live (Finset.mem_filter.mp ht).2 with last|branch|⟨s,hs,e⟩
    · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_singleton.mpr last))
    · exact Finset.mem_union_left _ (Finset.mem_union_right _ (Finset.mem_map.mpr ⟨g,branch,rfl⟩))
    · exact Finset.mem_union_right _ (Finset.mem_image.mpr ⟨s,hs,e⟩)
  have size1 := Finset.card_le_card cover
  have size2 := Finset.card_union_le ({C.output} ∪ (branches C).map W) ((internalSlots C).image rd)
  have size3 := Finset.card_union_le {C.output} ((branches C).map W)
  have size4 := Finset.card_image_le (s:=internalSlots C) (f:=rd)
  have dis : Disjoint (internalSlots C) reserved := Finset.disjoint_left.mpr (by
    intro s hi hr
    exact (Nat.not_le_of_lt (raw s hr)) (Finset.mem_filter.mp hi).2)
  have sub : internalSlots C ∪ reserved ⊆ slots C :=
    Finset.union_subset (Finset.filter_subset _ _) mem
  have size5 := Finset.card_le_card sub
  rw [Finset.card_union_of_disjoint dis] at size5
  simp only [Finset.card_map,Finset.card_singleton] at size1 size2 size3
  have slotsize : (slots C).card=(meets C).card*2 := by simp [slots]
  omega
theorem anc_le {w : ℕ} (anc : Anc C w) : w≤C.output := by
  induction anc with
  | output => rfl
  | left j hj _ ih => have e := (C.earlier j hj).1; omega
  | right j hj _ ih => have e := (C.earlier j hj).2; omega
theorem output_unused (live : Live C) : uses C C.output=0 := by
  rw [←occurrence_count]
  by_contra nz
  obtain ⟨v,hv⟩ : ∃v,v∈occurrences C C.output := by
    cases h : occurrences C C.output with
    | nil => simp [h] at nz
    | cons x xs => exact ⟨x,by simp [h]⟩
  obtain ⟨hj,rd⟩ := (occurrence_mem C C.output v.1 v.2).mp hv
  have ord := C.earlier v.1 hj
  have bound := anc_le C (live v.1 hj)
  cases e : v.2 <;> simp [operand,e] at rd <;> omega

def excess := ∑ g : Row C,if wire C g=C.output then 0 else uses C (wire C g)-1
theorem branches_le (live : Live C) : (branches C).card≤excess C := by
  classical
  have out := output_unused C live
  unfold excess
  calc
    _ = ∑g∈branches C,1 := by simp
    _ ≤ ∑g∈branches C,(if wire C g=C.output then 0 else uses C (wire C g)-1) := by
      apply Finset.sum_le_sum
      intro g hg
      have up : 2≤uses C (wire C g) := (Finset.mem_filter.mp hg).2
      split
      next eq => rw [eq,out] at up; omega
      next => omega
    _ ≤ _ := Finset.sum_le_univ_sum_of_nonneg (fun _=>Nat.zero_le _)
theorem designated_count (bin : binary C) (live : Live C) (D : Finset (Row C))
    (side : Row C→Bool) (meet : ∀g∈D,(C.code g).op=.meet)
    (raw : ∀g∈D,operand (C.code g) (side g)<n+n) :
    (tops C).card+D.card≤1+excess C+2*(meets C).card := by
  let pin : Row C ↪ Row C × Bool := ⟨fun g=>(g,side g),fun _ _ e=>congrArg Prod.fst e⟩
  have mem : D.map pin ⊆ slots C := by
    intro s hs
    obtain ⟨g,hg,rfl⟩ := Finset.mem_map.mp hs
    exact Finset.mem_product.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _,meet g hg⟩,Finset.mem_univ _⟩
  have only : ∀s∈D.map pin,operand (C.code s.1) s.2<n+n := by
    rintro s hs
    obtain ⟨g,hg,rfl⟩ := Finset.mem_map.mp hs
    exact raw g hg
  have a := count C bin live _ mem only
  rw [Finset.card_map] at a
  have f := branches_le C live
  omega
end IncidencePhysicalOrGroups
