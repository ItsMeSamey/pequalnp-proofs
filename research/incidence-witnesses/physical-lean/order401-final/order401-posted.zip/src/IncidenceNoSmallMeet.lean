import IncidenceEarliestSmall
namespace IncidenceEarliestSmall
open CircuitRewire IncidenceDenseSignature IncidenceOperandLedger

theorem no_small_meet {Z : Type*} (m s t : ℕ) (g : ℕ→Gate) (X : ℕ→Set Z)
    (sig : ℕ→Sig ℕ) (des : ℕ→Bool) (owner : ℕ→ℕ) (sole : Finset ℕ)
    (ord : ∀ j<s,(g j).left<m+j ∧ (g j).right<m+j)
    (sem : ∀ j<s,X (m+j)=(g j).eval X)
    (noAlias : ∀ j<s, X (m+j)≠X (g j).left)
    (raw : ∀ i<m,∀ A,sig i=some A → A={i})
    (once : ∀ x∈sole, fan g s x≤1)
    (small : ∀ j<s,(sig (m+j)).isSome=true → fan g s (m+j)≤1)
    (bin : ∀ j<s,(g j).op=.meet ∨ (g j).op=.join)
    (join : ∀ j<s,(g j).op=.join → sig (m+j)=merge t (sig (g j).left) (sig (g j).right))
    (priv : ∀ j<s,(g j).op=.meet → des j=true →
       (owner j=(g j).left ∨ owner j=(g j).right) ∧ owner j∈sole ∧
       sig (owner j)=some {owner j} ∧ sig (m+j)=sig (owner j))
    (other : ∀ j<s,(g j).op=.meet → des j=false →
       sig (m+j)=sig (g j).left ∧ sig (g j).left=sig (g j).right) :
    ∀ j<s,(g j).op=.meet → des j=false → sig (g j).left=none ∧ sig (g j).right=none := by
  have modes (j : ℕ) (hj : j<s) :
      sig (m+j)=sig (g j).left ∨ sig (m+j)=sig (g j).right ∨
        sig (m+j)=merge t (sig (g j).left) (sig (g j).right) := by
    rcases bin j hj with a|b
    · cases e : des j with
      | false => exact Or.inl (other j hj a e).1
      | true =>
        obtain ⟨p,_,_,d⟩ := priv j hj a e
        rcases p with l|r
        · exact Or.inl (d.trans (congrArg sig l))
        · exact Or.inr (Or.inl (d.trans (congrArg sig r)))
    · exact Or.inr (Or.inr (join j hj b))
  intro j
  induction j using Nat.strong_induction_on with
  | ind j ih =>
    intro js hm dd
    obtain ⟨out,eq⟩ := other j js hm dd
    suffices h : sig (g j).left=none from ⟨h,eq.symm.trans h⟩
    cases l : sig (g j).left with
    | none => rfl
    | some T =>
      exfalso
      apply noAlias j js
      apply earliest m s j t g sig X sole T js ord sem raw once small
        (fun i hi=>modes i (hi.trans js)) _ hm l (eq.symm.trans l)
      intro i ij A hA
      have ijs := ij.trans js
      rcases bin i ijs with a|b
      · cases p : des i with
        | false =>
          have nn := (ih i ij ijs a p).1
          rw [(other i ijs a p).1,nn] at hA
          contradiction
        | true =>
          obtain ⟨_,memb,hh,copy⟩ := priv i ijs a p
          rw [copy,hh] at hA
          exact Or.inl ⟨_,memb,(Option.some.inj hA) ▸ Finset.mem_singleton_self _⟩
      · right
        refine ⟨b,?_⟩
        rw [join i ijs b] at hA
        cases L : sig (g i).left with
        | none => simp [L, merge] at hA
        | some U =>
          cases R : sig (g i).right with
          | none => simp [L,R,merge] at hA
          | some V =>
            by_cases ok : (U∪V).card≤t
            · have e : U∪V=A := by simpa [L,R,merge,ok] using hA
              exact ⟨U,V,rfl,rfl,e.symm⟩
            · simp [L,R,merge,ok] at hA
end IncidenceEarliestSmall
