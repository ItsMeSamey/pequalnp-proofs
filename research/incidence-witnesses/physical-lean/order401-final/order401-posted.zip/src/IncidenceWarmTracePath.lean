import IncidencePointFirstFork
namespace IncidenceWarmTracePath
open IncidenceStartNormalization IncidenceHoistReaders IncidencePointDeterministicTail IncidencePointFirstFork
variable {n : Nat} (C : Circuit n)

theorem read_step {u v} (h : next C u=some v) :
    ∃ k side, v=n+n+k ∧ k<C.size ∧ operand (C.code k) side=u ∧
      reader? C u=some (k,side) := by
  unfold next at h
  split at h
  · contradiction
  cases r : reader? C u with
  | none => simp [r] at h
  | some p =>
    obtain ⟨k,side⟩ := p
    have mem : (k,side)∈occurrences C u := by
      unfold reader? at r
      split at r
      next _ h => cases r; simp_all
      next => contradiction
    obtain ⟨hk,edge⟩ := (occurrence_mem C u k side).1 mem
    exact ⟨k,side,(by simpa [r] using h.symm),hk,edge,rfl⟩

inductive Path : Nat → List Nat → Nat → Prop where
  | finish {j} (stop : next C (n+n+j)=none) : Path j [] j
  | step {j k ks e} (side : Bool) (link : next C (n+n+j)=some (n+n+k))
      (bound : k<C.size) (edge : operand (C.code k) side=n+n+j)
      (rest : Path k ks e) : Path j (k::ks) e

theorem exists_path (j : Nat) (hj : j<C.size) :
    ∃ ks e, Path C j ks e ∧ fork C (n+n+j)=n+n+e := by
  cases link : next C (n+n+j) with
  | none => exact ⟨[],j,.finish link,unique (tail C _) (.stop link)⟩
  | some v =>
    obtain ⟨k,b,rfl,hk,port,_⟩ := read_step C link
    obtain ⟨ks,e,path,last⟩ := exists_path k hk
    exact ⟨k::ks,e,.step b link hk port path,(after_read C link).trans last⟩
termination_by C.size-j
decreasing_by have := (next_bounds C link).1; omega

theorem fork_on {j ks e} (path : Path C j ks e) :
    ∀ t∈j::ks, fork C (n+n+t)=n+n+e := by
  induction path with
  | finish stop => simpa using unique (tail C _) (.stop stop)
  | @step j k ks e b link hk port rest ih =>
    intro t h
    rcases List.mem_cons.mp h with rfl|mem
    · exact (after_read C link).trans (ih k (by simp))
    · exact ih _ mem

theorem bounded {j ks e} (hj : j<C.size) (path : Path C j ks e) :
    ∀ t∈j::ks,t<C.size := by
  induction path with
  | finish => simpa using hj
  | step b link hk port rest ih =>
    intro t h
    rcases List.mem_cons.mp h with rfl|mem
    · exact hj
    · exact ih hk _ mem

theorem ordered {j ks e} (path : Path C j ks e) : (j::ks).Pairwise (·<·) := by
  induction path with
  | finish => simp
  | @step j k ks e b link hk port rest ih =>
    have lt : j<k := by have := (next_bounds C link).1; omega
    apply List.pairwise_cons.mpr
    refine ⟨?_,ih⟩
    intro a ha
    rcases List.mem_cons.mp ha with rfl|mem
    · exact lt
    · exact lt.trans (List.pairwise_cons.mp ih |>.1 _ mem)

theorem from_raw {u v} (link : next C u=some v) :
    ∃ j b ks e, v=n+n+j ∧ j<C.size ∧ operand (C.code j) b=u ∧
      reader? C u=some (j,b) ∧ Path C j ks e ∧ fork C u=n+n+e := by
  obtain ⟨j,b,rfl,bound,port,pick⟩ := read_step C link
  obtain ⟨ks,e,path,last⟩ := exists_path C j bound
  exact ⟨j,b,ks,e,rfl,bound,port,pick,path,(after_read C link).trans last⟩

#print axioms from_raw
#print axioms fork_on
#print axioms ordered
end IncidenceWarmTracePath
