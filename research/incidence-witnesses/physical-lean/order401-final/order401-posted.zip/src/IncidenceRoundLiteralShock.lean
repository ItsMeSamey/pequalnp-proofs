import IncidenceAllowedGeometry
import IncidenceRoundShockBudget
import IncidenceRoundShockSibling
import IncidenceRoundLiteralInputs
import IncidenceTrackedLiteral
import IncidenceReachableCensus
namespace IncidenceRoundLiteralShock
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceHoistPrune
open IncidenceRoundReservations IncidenceAllowedGeometry IncidencePhysicalPaidRound
open IncidenceThetaRoundDriver IncidenceThetaRestrict IncidenceThetaBatchHoist IncidenceMarkTransition IncidenceZeroRestriction
variable {n : ℕ} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)}
variable (a : Stage I P L) (M : Finset ℕ) (G : ℕ→Finset ℕ) (prot : Finset ℕ)
local notation "E" => kept a.A a.B \ prot
local notation "J" => rel I a.A a.B

open IncidenceSurvivingReads IncidenceForwardPins IncidenceReachableCensus
open IncidenceLabelHistory IncidenceRoundLiteralInputs
theorem livePin (C : Circuit n) (live : Live C) (j : ℕ) (hj : j<C.size) (ne : j≠C.output-(n+n)) :
    ∃q : Pin,j<q.1 ∧ q.1<C.size ∧ readPin C.code q=n+n+j := by
  have ext {w} (h : Anc C w) (eq : w=n+n+j) :
      ∃q : Pin,j<q.1 ∧ q.1<C.size ∧ readPin C.code q=n+n+j := by
    cases h with
    | output => omega
    | left k hk _ => exact ⟨(k,false),by have := (C.earlier k hk).1; change j<k; omega,hk,eq⟩
    | right k hk _ => exact ⟨(k,true),by have := (C.earlier k hk).2; change j<k; omega,hk,eq⟩
  exact ext (live j hj) rfl
theorem output_kept (D : Finset ℕ) (core : P.Nonempty)
    (legal : Allowed I a (nextP a.A D) (nextL a.B D)) : dead a.C D a.C.output=false := by
  classical
  obtain ⟨p,hp⟩ := core
  have pa := legal.keepP hp
  have min := legal.minP _ pa
  obtain ⟨l,inc⟩ := Finset.card_pos.mp (show 0<(N (rel I (nextP a.A D) (nextL a.B D)) false p).card by omega)
  obtain ⟨_,lb,flag⟩ := (Finset.mem_filter.mp inc).2
  have on := a.flag p l ⟨legal.subP pa,legal.subL lb,flag⟩
  have high : row n D ∈ a.C.wire a.C.output := by
    apply IncidencePointShield.monotone a.C _ a.C.output_lt _ on
    constructor
    · intro i h
      have eq : i=p := of_decide_eq_true h
      subst i
      exact decide_eq_true (Finset.mem_filter.mp pa).2
    · intro i h
      have eq : i=l := of_decide_eq_true h
      subst i
      exact decide_eq_true (Finset.mem_filter.mp lb).2
  simp [dead,IncidenceZeroRestriction.zeroAt,high]

theorem edgeOf (I : Fin n→Fin n→Prop) [DecidableRel I] (A B : Finset (Fin n)) (x y : ℕ)
    (hx : x∈kept A B) (m : y∈kept A B ∩ neighbors I x) : adj (rel I A B) x y := by
  rcases Finset.mem_union.mp hx with point|line
  · obtain ⟨p,pa,rfl⟩ := Finset.mem_image.mp point
    rw [p_neighbors I A B p pa] at m
    obtain ⟨l,pl,e⟩ := Finset.mem_map.mp m
    exact ⟨p,l,(Finset.mem_filter.mp pl).2,Or.inl ⟨rfl,e.symm⟩⟩
  · obtain ⟨l,lb,rfl⟩ := Finset.mem_image.mp line
    rw [l_neighbors I A B l lb] at m
    obtain ⟨p,pl,e⟩ := Finset.mem_map.mp m
    exact ⟨p,l,(Finset.mem_filter.mp pl).2,Or.inr ⟨rfl,e.symm⟩⟩
theorem physical (live : Live a.C) (hasCore : P.Nonempty)
    (safe : Safe (neighbors I) (kept a.A a.B) M G)
    (core : kept P L⊆prot) (guards : IncidenceMarkTransition.reserve M G⊆prot)
    (protect : IncidenceLabelHistory.vulnerable (IncidenceCleanupLabels.snap a.C.size a.C.code (kept a.A a.B))⊆prot)
    (D : Finset ℕ) (de : D⊆E) (small : D.card≤24) (b : Stage I P L)
    (bp : b.A=nextP a.A D) (bl : b.B=nextL a.B D)
    (sz : b.C.size=minorSize I a (nextP a.A D) (nextL a.B D))
    (code : b.C.code=(compileLiteral (n+n) (n+n) a.C.code
      (ref (keep a.A (nextP a.A D)) (keep a.B (nextL a.B D))) a.C.size).code) :
    (drops (shot a) (shot b) ∪ andLost (shot a) (shot b)).card+2*D.card+b.C.size≤a.C.size := by
  classical
  let C := a.C
  have range : E⊆Finset.range (n+n) := Finset.sdiff_subset.trans (IncidenceRoundLiteralInputs.domain a.A a.B)
  have geom (D : Finset ℕ) (de : D⊆E) (sz : D.card≤24) := allowed I a M G safe D prot core guards de sz
  have nb (D : Finset ℕ) (de : D⊆E) (sz : D.card≤24) (x : ℕ) (hx : x∈E) :
      ∃y∉D,adj J x y := neighbor_after I (Finset.mem_sdiff.mp hx).1 ((geom D de sz).2 x hx)
  have used (x : ℕ) (hx : x∈E) : 0<uses a.C x := by
    obtain ⟨y,_,edge⟩ := nb ∅ (Finset.empty_subset _) (by simp) x hx
    exact used_of_edge a.C J a.flag a.neg edge
  have op {x : ℕ} (hx : x∈IncidenceRoundReservations.sole C E) := protected_meet a.C E _ prot Finset.Subset.rfl protect hx
  have highs (D : Finset ℕ) (de : D⊆E) (sz : D.card≤24) (x : ℕ) (hx : x∈IncidenceRoundReservations.sole a.C E) :
      dead a.C D (sib a.C x)=false := by
    obtain ⟨y,free,edge⟩ := nb D de sz x (Finset.mem_filter.mp hx).1
    exact sibling a.C J a.bin a.flag a.neg edge (Finset.mem_filter.mp hx).2 (op hx) D free
  let init D := ref (keep a.A (nextP a.A D)) (keep a.B (nextL a.B D))
  have inputs (D : Finset ℕ) (de : D⊆E) (i : ℕ) (hi : i<n+n) :
      (init D i).isNone=dead a.C D i := by
    have a1 := new_ref a.A a.B D (de.trans Finset.sdiff_subset) hi
    have a2 := raw_flag a.C hi D
    change (init D i).isNone=true ↔ i∈D at a1
    exact Bool.eq_iff_iff.mpr (a1.trans a2.symm)
  let A := nextP a.A D
  let B := nextL a.B D
  let U := keep a.A A
  let V := keep a.B B
  let O := (D∩IncidenceRoundReservations.sole C E).image (owner C)
  have price := surplus_price C E a.bin live range used (fun _ h=>op h) highs de small
    (output_kept a D hasCore (geom D de small).1) (init D) (inputs D de)
  have width (j : ℕ) (mem : j∈O) : ∃v w : ℕ,v≠w ∧
      v∈singleRow C U V (readPin C.code (j,dead C D (C.code j).left)) ∧
      w∈singleRow C U V (readPin C.code (j,dead C D (C.code j).left)) := by
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp mem
    obtain ⟨xd,xs⟩ := Finset.mem_inter.mp hx
    have xe := (Finset.mem_filter.mp xs).1
    have count := (geom D de small).2 x xe
    obtain ⟨v,hv,w,hw,ne⟩ := Finset.one_lt_card.mp (show 1<((kept a.A a.B\D)∩neighbors I x).card by omega)
    have same : readPin C.code (owner C x,dead C D (C.code (owner C x)).left)=sib C x := by
      obtain ⟨_,port,_⟩ := read_unique C (Finset.mem_filter.mp xs).2
      have z := (raw_flag C (Finset.mem_range.mp (range xe)) D).2 xd
      have high := highs D de small x xs
      change IncidenceHoistReaders.operand (C.code (owner C x)) (reader C x).2=x at port
      change (if dead C D (C.code (owner C x)).left then (C.code (owner C x)).right else (C.code (owner C x)).left)
        = IncidenceHoistReaders.operand (C.code (owner C x)) (!(reader C x).2)
      change dead C D (IncidenceHoistReaders.operand (C.code (owner C x)) (!(reader C x).2))=false at high
      cases side : (reader C x).2 <;> simp [side,IncidenceHoistReaders.operand] at port high ⊢ <;> simp_all
    rw [same]
    have yes (y : ℕ) (hy : y∈((kept a.A a.B\D)∩neighbors I x)) : y∈singleRow C U V (sib C x) := by
      obtain ⟨yd,yn⟩ := Finset.mem_inter.mp hy
      have edge := edgeOf I a.A a.B x y (Finset.mem_sdiff.mp xe).1 (Finset.mem_inter.mpr ⟨(Finset.mem_sdiff.mp yd).1,yn⟩)
      have ykeep : y∈kept A B := by
        simpa [A,B,next_eq] using yd
      exact (single_kept C U V y _ (tracked a.A a.B A B ykeep)).2
        (sibling_single C J a.bin a.flag a.neg edge (Finset.mem_filter.mp xs).2 (op xs))
    exact ⟨v,w,ne,yes v hv,yes w hw⟩
  have bounds := IncidenceTrackedLiteral.step (n+n) C.size C.output C.code (kept a.A a.B) (kept A B)
    (kept U V) (tracked a.A a.B A B) (domain A B) (X C U V) C.wire
    (fun j hj=>⟨(C.earlier j hj).1,(C.earlier j hj).2,a.bin j hj⟩)
    (sem C U V) (base C U V) C.output_lt (flips I a (geom D de small).1)
    (dead C D) (inputs D de) (dead_step C D) (livePin C live) (internal C J a.neg)
    (singleRow C U V) (input C U V) (gate C U V) (reject C J a.neg U V) O width
  unfold shot
  rw [bp,bl,sz,code]
  exact (Nat.add_le_add_right (Nat.add_le_add_right bounds _) _).trans price
#print axioms physical
end IncidenceRoundLiteralShock
