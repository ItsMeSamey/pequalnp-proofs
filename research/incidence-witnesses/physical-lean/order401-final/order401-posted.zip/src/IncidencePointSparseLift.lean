import IncidencePointNativeCensus
namespace IncidencePointBooking
open CircuitRewire IncidenceZeroRestriction IncidenceRobust
variable {n : Nat}
abbrev Sparse (n : Nat) := {T : Finset (Fin n) // T.card≤199}
theorem sparse_census (I : Fin n→Fin n→Prop) [DecidableRel I]
    (degree : ∀ l,Fintype.card {p // I p l}=402) (unique : ∀a b,a≠b → ∃! l,I a l ∧ I b l)
    (hn : n=401^2+401+1) (s : Nat) (raw : Nat→Gate) (Y : Nat→Set (Sparse n))
    (C : Finset (Fin n)) (W : Fin n→Finset (Fin n)) (o : Fin n→Nat)
    (few : ∀ x∈C,(W x).card≤2) (anti : ∀ x∈C,∀ y∈C,x≠y → x∈W y → y∉W x)
    (top : ∀ j<s,(raw j).left<n+j ∧ (raw j).right<n+j) (bound : ∀ x∈C,o x<n+s)
    (inputs : ∀ j<n,Y j=Subtype.val ⁻¹' lineInputs n j)
    (sem : ∀ j<s,Y (n+j)=(raw j).eval Y)
    (pos : ∀ x∈C,∀ l∈lines I x,(⟨{l},by simp⟩ : Sparse n)∈Y (o x))
    (neg : ∀ x∈C,∀ T : Sparse n,Disjoint T.val ((W x).biUnion (lines I)) → T∉Y (o x))
    (size : s≤646424) (edited total : Nat) (partition : total=edited+C.card) (paid : edited≤3213) :
    total≤6461 := by
  let X := execute n raw (lineInputs n) s
  let X' := fun j=>(Subtype.val : Sparse n→Finset (Fin n)) ⁻¹' X j
  have eq (j : Nat) (hj : j<n+s) : X' j=Y j := by
    let B := fun j=>(Subtype.val : Sparse n→Finset (Fin n)) ⁻¹' lineInputs n j
    have xbase (i : Nat) (hi : i<n) : X' i=B i := by
      change _ ⁻¹' execute n raw _ s i=_
      rw [run_inputs _ _ _ _ i hi]
    have xstep (i : Nat) (hi : i<s) : X' (n+i)=(raw i).eval X' := by
      change _ ⁻¹' execute n raw _ s (n+i)=_
      rw [run_gate n s raw _ i hi (top i hi).1 (top i hi).2,preimage_gate]
    exact (execute_unique n s raw B X' top xbase xstep j hj).symm.trans
      (execute_unique n s raw B Y top inputs sem j hj)
  apply native_census I degree unique hn s raw C W o few anti top bound _ _ size edited total partition paid
  · intro x hx l hl
    have inside := pos x hx l hl
    rw [←eq _ (bound x hx)] at inside
    exact inside
  · intro x hx T small dis hit
    apply neg x hx ⟨T,small⟩ dis
    rw [←eq _ (bound x hx)]
    exact hit
#print axioms sparse_census
end IncidencePointBooking
