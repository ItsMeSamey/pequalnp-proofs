import IncidenceWarmDomain
import IncidencePointWarmFlags
namespace IncidenceWarmPointOutput
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmDomain IncidencePointWarmMasks
variable {n : ℕ} {C : Circuit n}

theorem owners_nodup (A : Schedule C) : A.owners.Nodup := by
  have d := (List.nodup_flatMap.mp A.distinct).2
  apply d.imp
  intro x y dis eq
  subst y
  exact dis (List.mem_cons_self ..) (List.mem_cons_self ..)

theorem owner_card (A : Schedule C) (M : Finset (Fin n)) (c : Fin n→ℕ)
    (w : Wiring C M A.fork c) : A.owners.length=M.card := by
  have eq : A.owners.toFinset=drops M := by
    ext x
    constructor
    · intro h
      obtain ⟨j,⟨hj,fj⟩,_⟩ := (A.targets x).mp (List.mem_toFinset.mp h)
      obtain ⟨p,pm,e,_⟩ := w.located j hj x fj
      exact Finset.mem_image.mpr ⟨p,pm,e⟩
    · intro h
      obtain ⟨p,pm,rfl⟩ := Finset.mem_image.mp h
      obtain ⟨j,hj,fj,_⟩ := w.installed p pm
      by_contra bad
      have no : j∉A.owners.flatMap (fun x=>A.start x::A.tail x) := by
        intro hit
        obtain ⟨x,hx,hrow⟩ := List.mem_flatMap.mp hit
        obtain ⟨_,_,_,_,_,path⟩ := A.legal x hx
        obtain ⟨_,_,_,sol⟩ := placement path
        have e := (sol j hrow p.val fj).2
        exact bad (List.mem_toFinset.mpr (by simpa only [e] using hx))
      rw [A.covered j hj no] at fj
      cases fj
  rw [←List.toFinset_card_of_nodup (owners_nodup A),eq]
  exact Finset.card_image_of_injective _ Fin.val_injective

theorem physical (A : Schedule C) (I : Fin n→Fin n→Prop) (M : Finset (Fin n))
    (cut : Fin n→ℕ) (w : Wiring C M A.fork cut) (drop : A.drop=drops M)
    (nonempty : ∃ p l,I p l) (pos : flags C I)
    (shield : ∀p∈M,shadow (n+n) C.code p.val (cut p) C.size C.output=false)
    (neg : ∀ J T : Finset (Fin n),J.card≤2 → T.card≤2 →
      (∀x∈J,∀y∈T,¬I x y) →
      mask J T∉IncidenceWarmCompiler.editedWire (n+n) C.size C.wire C.code (drops M) A.fork C.output) :
    ∃ D : Circuit n,D.size+M.card≤C.size ∧ binary D ∧ D.wire D.output=A.output ∧
      flags D I ∧ negatives D I 2 2 ∧ ExactOn I 2 2 (D.wire D.output) := by
  rw [←owner_card A M cut w]
  apply domain C A I 2 2 nonempty
  · intro p l inc
    simpa [Schedule.output,drop] using flag_mask C I M A.fork cut w pos p l inc (shield p)
  · apply bool_negatives
    simpa [IncidencePointWarmMasks.mask,Schedule.output,drop] using neg
#print axioms physical
end IncidenceWarmPointOutput
