import IncidenceActualLineCensus
import IncidenceHoistBilateral
namespace IncidenceActualBilateralLine
open SparseIncidence IncidenceStartNormalization IncidenceHoistPrune
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

theorem retained (degree : ∀l,Fintype.card {p // I p l}=402) (join : ∀p r,p≠r→∃!l,I p l∧I r l)
    (hn : n=161203) (pos : flags C I) (neg : negatives C I n 401) (upper : C.size≤646424) :
    ∃ line both : Circuit n, LineStage I C line ∧ BilateralStage I line both ∧
      Live line ∧ Live both ∧ soleCount line n≤3382 ∧ soleCount both n≤3382 := by
  obtain ⟨line,both,L,B,liveL,liveB⟩ := IncidenceHoistBilateral.stages C I (by omega) degree join pos neg
  have count := IncidenceActualLineChoice.lines line I degree join hn L.ops L.one L.sparse L.and_first
    (L.budget.trans upper)
  exact ⟨line,both,L,B,liveL,liveB,count,(unchanged_line_count B) ▸ count⟩
#print axioms retained
end IncidenceActualBilateralLine
