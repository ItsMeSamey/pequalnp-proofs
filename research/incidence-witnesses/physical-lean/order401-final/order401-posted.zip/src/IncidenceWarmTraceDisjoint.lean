import IncidenceWarmTracePath
namespace IncidenceWarmTraceDisjoint
open IncidenceStartNormalization IncidencePointFirstFork IncidenceWarmTracePath

theorem common {n} (C : Circuit n) {j k a b e f t}
    (p : Path C j a e) (q : Path C k b f)
    (left : t∈j::a) (right : t∈k::b) : e=f := by
  have l := fork_on C p t left
  have r := fork_on C q t right
  omega

theorem disjoint {n} (C : Circuit n) {j k a b e f}
    (p : Path C j a e) (q : Path C k b f) (different : e≠f) :
    List.Disjoint (j::a) (k::b) := fun _ h k => different (common C p q h k)

theorem flat_nodup {n} (C : Circuit n) (owners : List Nat)
    (start : Nat→Nat) (tail : Nat→List Nat) (stop : Nat→Nat)
    (distinct : owners.Nodup)
    (path : ∀ x∈owners,Path C (start x) (tail x) (stop x))
    (unique : ∀ x∈owners,∀ y∈owners,stop x=stop y → x=y) :
    (owners.flatMap (fun x=>start x::tail x)).Nodup := by
  apply List.nodup_flatMap.mpr
  refine ⟨fun x hx=>(ordered C (path x hx)).imp Nat.ne_of_lt,distinct.imp_of_mem ?_⟩
  intro x y hx hy ne
  exact disjoint C (path x hx) (path y hy) (fun eq=>ne (unique x hx y hy eq))

#print axioms flat_nodup
end IncidenceWarmTraceDisjoint
