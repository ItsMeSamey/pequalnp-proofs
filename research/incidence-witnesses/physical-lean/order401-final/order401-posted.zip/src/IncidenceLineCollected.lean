import IncidenceActualLineCredit
namespace IncidenceLineCollected
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceLineGateBooking
open IncidenceLineRoutedSlots IncidenceLineColdSibling IncidenceActualLineCredit IncidenceRobust

theorem collect {n : ℕ} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (degree : ∀l,Fintype.card {p // I p l}=401+1)
    (unique : ∀p r,p≠r→∃!l,I p l∧I r l)
    (ops : binary C) (pos : flags C I) (neg : negatives C I n 401)
    (charged : Finset (Fin n)) (w : Fin n→Fin n) (stop : Fin n→ℕ)
    (path : ∀x∈charged,Corridor C x (stop x))
    (cold : ∀x∈charged,(avoid I x (w x),single x)∉C.wire (stop x))
    (no_pair : ∀x∈charged,∀y∈charged,x≠y→w x=y→w y≠x) :
    ∃ B : Fin n→Finset (Fin C.size×Fin n),
      (∀x∈charged,∀z∈B x,eligible C I x z.1 z.2) ∧
      (∀x∈charged,∀y∈charged,∀u∈B x,∀v∈B y,u.1=v.1 → x=y) ∧
      3106*charged.card ≤ (charged.biUnion B).card := by
  classical
  have each x (hx : x∈charged) := credit C I degree ops pos neg x (w x) (path x hx) (cold x hx)
  let B x := if hx : x∈charged then (each x hx).choose else ∅
  have spec x (hx : x∈charged) :
      3106≤(B x).card ∧ ∀z∈B x, (avoid I x (w x),fun _=>false) ∉ C.wire (n+n+z.1.val) ∧
      2<(points I x ∩ support C z.1).card ∧ eligible C I x z.1 z.2 := by
    simpa [B,hx] using (each x hx).choose_spec
  have coldSlot := fun x hx z hz => ((spec x hx).2 z hz).1
  have heavySlot := fun x hx z hz => ((spec x hx).2 z hz).2.1
  refine ⟨B,(fun x hx z hz => ((spec x hx).2 z hz).2.2),
    gate_single_owner I unique C charged w B coldSlot heavySlot no_pair,?_⟩
  exact actual_pair_bound C charged B (booked_disjoint I unique C charged w B coldSlot heavySlot no_pair)
    (fun x hx => (spec x hx).1)
#print axioms collect
end IncidenceLineCollected
