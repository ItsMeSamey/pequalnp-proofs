import IncidenceReachableStop
import IncidenceCensusStart
import IncidenceRoundNoExtraPhysical
import IncidenceRoundEssential
import IncidencePhysicalRoundLive
namespace IncidencePhysicalCreditHistory
open IncidenceThetaRoundDriver IncidenceReachableCensus IncidenceLabelHistory IncidenceMarkTransition
variable {n : ℕ} {I : Fin n → Fin n → Prop} [DecidableRel I] {P L : Finset (Fin n)}

def credit (a b : Stage I P L) :=
  a.C.size - (b.C.size + 2*((a.A \ b.A).card+(a.B \ b.B).card))

theorem nested {s a : Stage I P L} {h v} (w : Walk s a h v) :
    a.A ⊆ s.A ∧ a.B ⊆ s.B := by
  induction w with
  | start => exact ⟨Finset.Subset.rfl,Finset.Subset.rfl⟩
  | step _ pay _ _ _ ih => exact ⟨pay.1.trans ih.1,pay.2.1.trans ih.2⟩

theorem advance {s a b : Stage I P L} {h v} {nb : ℕ → Finset ℕ}
    (w : Walk s a h v) (old : Marks nb a) (pay : Paid I a b)
    (cash : a.C.size+2*((s.A.card+s.B.card)-(a.A.card+a.B.card))+v≤s.C.size)
    (D : Finset ℕ) (avoid : Disjoint D ((sites P L ∪ reserve old.M old.G) ∪ h))
    (small : D.card≤24) (actual : (shot b).live=(shot a).live \ D)
    (ess : ∀x∈(shot a).live,0<(shot a).uses x)
    (shock : (drops (shot a) (shot b) ∪ andLost (shot a) (shot b)).card ≤ 2*credit a b) :
    ∃ (h' : Finset ℕ) (next : Marks nb b), Walk s b h' (v+credit a b) ∧
      ((shot a).live \ (shot b).live).card ≤ 24 ∧
      reserve old.M old.G ⊆ reserve next.M next.G ∧ v<v+credit a b ∧
      b.C.size+2*((s.A.card+s.B.card)-(b.A.card+b.B.card))+(v+credit a b)≤s.C.size := by
  obtain ⟨next,keep⟩ := updateMarks old h D avoid small actual
  obtain ⟨subA,subB,debit⟩ := pay
  obtain ⟨sa,sb⟩ := nested w
  have ca := Finset.card_le_card sa
  have cb := Finset.card_le_card sb
  have da := Finset.card_sdiff_add_card_eq_card subA
  have db := Finset.card_sdiff_add_card_eq_card subB
  have sub : (shot b).live ⊆ (shot a).live := actual ▸ Finset.sdiff_subset
  have loss : (shot a).live \ (shot b).live ⊆ D := by
    intro x hx
    rw [actual] at hx
    obtain ⟨live,off⟩ := Finset.mem_sdiff.mp hx
    by_contra no
    exact off (Finset.mem_sdiff.mpr ⟨live,no⟩)
  have count := (Finset.card_le_card loss).trans small
  refine ⟨_,next,.step w ⟨subA,subB,debit⟩ sub ess shock,count,keep,?_,?_⟩ <;>
    unfold credit <;> omega

open IncidenceStartNormalization IncidenceThetaRestrict IncidencePhysicalPaidRound
open IncidenceRoundPhysicalMove IncidenceAllowedGeometry IncidenceCleanupLabels

theorem positive (a : Stage I P L) (x : ℕ) (hx : x∈(shot a).live) : 0<(shot a).uses x := by
  change 0<(snap a.C.size a.C.code (sites a.A a.B)).uses x
  rw [read_count]
  exact IncidenceRoundEssential.positive a x hx

def Ready (s a b : Stage I P L) (nb : ℕ→Finset ℕ) (old : Marks nb a) (v : ℕ) : Prop :=
  ∃ (h' : Finset ℕ) (next : Marks nb b), Walk s b h' (v+credit a b) ∧
    ((shot a).live \ (shot b).live).card ≤ 24 ∧
      reserve old.M old.G ⊆ reserve next.M next.G ∧ v<v+credit a b ∧
    b.C.size+2*((s.A.card+s.B.card)-(b.A.card+b.B.card))+(v+credit a b)≤s.C.size

theorem erase {s a b : Stage I P L} {h v} {nb : ℕ → Finset ℕ}
    (w : Walk s a h v) (old : Marks nb a)
    (cash : a.C.size+2*((s.A.card+s.B.card)-(a.A.card+a.B.card))+v≤s.C.size)
    (g : Fin a.C.size) (src : ℕ) (pay : Paid I a b)
    (ea : b.A=a.A) (eb : b.B=a.B) (sz : b.C.size+1=a.C.size)
    (code : b.C.code=IncidenceCleanupGate.eraseGate (n+n) g.val src a.C.code) :
    Ready s a b nb old v := by
  have shock := IncidenceCleanupGate.shock (n+n) a.C.size g.val src a.C.code (kept a.A a.B)
    g.isLt (IncidenceRoundNoExtraPhysical.kept_range a.A a.B)
  have dec : b.C.size=a.C.size-1 := by omega
  have one : credit a b=1 := by simp [credit,ea,eb] <;> omega
  apply advance w old pay cash ∅ (by simp) (by simp) (by simp [shot,snap,ea,eb])
    (positive a)
  rw [one]
  simpa only [shot,code,ea,eb,dec,sites,kept] using shock

theorem deletion {s a b : Stage I P L} {h v} {nb : ℕ → Finset ℕ}
    (w : Walk s a h v) (old : Marks nb a)
    (cash : a.C.size+2*((s.A.card+s.B.card)-(a.A.card+a.B.card))+v≤s.C.size)
    (pay : Paid I a b) (small : (a.A\b.A).card+(a.B\b.B).card≤24)
    (free : kept a.A a.B \ kept b.A b.B ⊆ kept a.A a.B \ ((sites P L ∪ reserve old.M old.G) ∪ h))
    (shock : (drops (shot a) (shot b) ∪ andLost (shot a) (shot b)).card≤2*credit a b) :
    Ready s a b nb old v := by
  let D := kept a.A a.B \ kept b.A b.B
  have sub : kept b.A b.B ⊆ kept a.A a.B := Finset.union_subset_union
    (Finset.image_subset_image pay.1) (Finset.image_subset_image pay.2.1)
  have dis : Disjoint D ((sites P L ∪ reserve old.M old.G) ∪ h) :=
    Finset.disjoint_left.mpr fun _ hx=> (Finset.mem_sdiff.mp (free hx)).2
  have count : D.card≤24 := by
    dsimp [D]
    rw [Finset.card_sdiff_of_subset sub,kept_card,kept_card]
    have da := Finset.card_sdiff_add_card_eq_card pay.1
    have db := Finset.card_sdiff_add_card_eq_card pay.2.1
    omega
  apply advance w old pay cash D dis count _ (positive a) shock
  change kept b.A b.B = kept a.A a.B \ (kept a.A a.B \ kept b.A b.B)
  ext x
  simp only [Finset.mem_sdiff]
  constructor
  · intro hx; exact ⟨sub hx,fun bad=>bad.2 hx⟩
  · rintro ⟨hx,keep⟩
    by_contra no
    exact keep ⟨hx,no⟩

theorem witness {s a : Stage I P L} {h v} {nb : ℕ → Finset ℕ}
    (w : Walk s a h v) (old : Marks nb a)
    (cash : a.C.size+2*((s.A.card+s.B.card)-(a.A.card+a.B.card))+v≤s.C.size)
    (core : P.Nonempty)
    (move : Witness a (kept a.A a.B \ ((sites P L ∪ reserve old.M old.G) ∪ h)))
    (literal : ∀(A B : Finset (Fin n)) (b : Stage I P L),
      IncidenceHoistPrune.Live a.C → Allowed I a A B → Paid I a b →
      kept a.A a.B \ kept A B ⊆ kept a.A a.B \ ((sites P L ∪ reserve old.M old.G) ∪ h) →
      b.A=A → b.B=B → b.C.size=minorSize I a A B →
      b.C.code=(IncidenceZeroRestriction.compileLiteral (n+n) (n+n) a.C.code
        (ref (keep a.A A) (keep a.B B)) a.C.size).code →
      (drops (shot a) (shot b) ∪ andLost (shot a) (shot b)).card≤2*credit a b) :
    ∃ b, Ready s a b nb old v := by
  classical
  have row (g : Fin a.C.size) (src : ℕ) (C : Circuit n) (bin : binary C)
      (out : C.wire C.output=a.C.wire a.C.output) (sz : C.size+1=a.C.size)
      (code : C.code=IncidenceCleanupGate.eraseGate (n+n) g.val src a.C.code) :
      ∃b, Ready s a b nb old v := by
    have f : flags C (rel I a.A a.B) := by
      intro p l h
      rw [out]
      exact a.flag p l h
    have ng : negatives C (rel I a.A a.B) 3 3 := by
      intro p l hp hl bad
      rw [out]
      exact a.neg p l hp hl bad
    let b : Stage I P L := ⟨a.A,a.B,a.pointCore,a.lineCore,a.pointMin,a.lineMin,C,bin,f,ng⟩
    have pay : Paid I a b := ⟨Finset.Subset.rfl,Finset.Subset.rfl,by simpa [b] using sz.le⟩
    exact ⟨b,erase w old cash g src pay rfl rfl sz code⟩
  cases move with
  | bypass g src earlier same =>
    obtain ⟨b,pay,ea,eb,sz,code⟩ := erase_one I a g src earlier same
    exact ⟨b,erase w old cash g src pay ea eb sz code⟩
  | rowErase g src C bin out sz code => exact row g src C bin out sz code
  | deletion A B legal free size =>
    by_cases live : IncidenceHoistPrune.Live a.C
    · obtain ⟨p,hp⟩ := core
      have pa := legal.keepP hp
      have deg := legal.minP p pa
      obtain ⟨l,hl⟩ := Finset.card_pos.mp (show 0<(IncidenceThetaBatchHoist.N (rel I A B) false p).card by omega)
      have edge : rel I A B p l := by simpa [IncidenceThetaBatchHoist.N] using (Finset.mem_filter.mp hl).2
      obtain ⟨b,pay,ea,eb,sz,code⟩ := erase_with_rows I a legal ⟨p,pa,l,edge.2.1,edge.2.2⟩ size
      exact ⟨b,deletion w old cash pay (by simpa [ea,eb] using legal.small)
        (by simpa [ea,eb] using free) (literal A B b live legal pay free ea eb sz code)⟩
    · obtain ⟨g,_,_,_,_,_,C,bin,out,sz,code,_⟩ := IncidenceDeadRowErase.run a.C a.bin live
      exact row g (a.C.code g.val).left C bin out sz code

end IncidencePhysicalCreditHistory
