import IncidencePinScheduleBound
import IncidencePinRunBound
import IncidenceTwoLineNormalize
import IncidencePostHoistPinExpectation
namespace IncidenceLinePinSchedules
open scoped BigOperators
open IncidenceStartNormalization IncidenceHoistPrune IncidenceActualPinFamily IncidenceLineRoutedSlots
open IncidencePhysicalPinExpectation IncidenceHoistStage IncidenceRobust
variable {n : ℕ} (C : Circuit n) (I : Fin n → Fin n → Prop) [DecidableRel I]

private theorem sample_spec (j : ℕ) (r : Fin n × Finset (Fin n)) (hr : r∈sample I j) :
    r.2.card=j+1 ∧ ∀p∈r.2,I p r.1 := by
  obtain ⟨l,_,mem⟩ := Finset.mem_biUnion.mp hr
  obtain ⟨P,hP,rfl⟩ := Finset.mem_map.mp mem
  obtain ⟨sub,card⟩ := Finset.mem_powersetCard.mp hP
  exact ⟨card,fun p hp=>(Finset.mem_filter.mp (sub hp)).2⟩

theorem schedules (degree : ∀l,Fintype.card {p // I p l}=402)
    (unique : ∀p r,p≠r → ∃!l,I p l ∧ I r l) (hn : n=161203)
    (bin : binary C) (live : Live C) (pos : flags C I) (neg : negatives C I n 2)
    (owner : Fin C.size→Fin n) (book : Fin C.size→Finset (Fin n))
    (ok : ∀g,∀p∈book g,eligible C I (owner g) g p)
    (paid : ℕ) (budget : C.size+paid≤646424) :
    let W := ∑g,(book g).card
    64803606*paid+(52*401)*W≤3382*64803606 ∧
    64803606*paid+(53*401)*W≤3386*64803606 := by
  classical
  let D := transform C true
  obtain ⟨sz,bd,pd,nd,ad,ld⟩ := IncidenceTwoLineNormalize.normalize C I degree unique pos neg bin live
  have run (j cap : ℕ) (sj : j+1≤400)
      (room : 646424≤(4*n-1-(2*(2*n-(402*(j+1)+1)))/(402-(j+1)+1)-(j+1))+cap) :
      (n*402)*paid+((j+1)*401)*(∑g,(book g).card) ≤ (n*402)*cap := by
    apply IncidencePinScheduleBound.bound (sample I j) (fun r=>(forced D r.2).card)
      (q:=401) (by omega) (sample_card I degree j)
      (IncidencePostHoistPinExpectation.expected C I degree unique (by omega) pos neg owner book ok j)
    intro r hr
    obtain ⟨card,on⟩ := sample_spec I j r hr
    have hb := IncidencePinRunBound.bound D I bd ld ad nd pd degree unique hn r.2 r.1
      (Finset.card_pos.mp (by omega)) on (by omega)
    change D.size=C.size at sz
    rw [card] at hb
    omega
  have h52 := run 51 3382 (by decide) (by rw [hn])
  have h53 := run 52 3386 (by decide) (by rw [hn])
  rw [show n*402=64803606 by omega] at h52 h53
  exact ⟨by dsimp; omega,by dsimp; omega⟩
end IncidenceLinePinSchedules
