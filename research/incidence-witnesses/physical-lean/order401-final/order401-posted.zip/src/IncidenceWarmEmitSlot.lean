import IncidenceWarmPhysical
import IncidenceLiteralPrefix
namespace IncidenceWarmCompiler
open CircuitRewire IncidenceZeroRestriction
theorem join_slot (m s : ℕ) (code : ℕ→Gate) (drop : Finset ℕ) (fork : ℕ→Option ℕ)
    {j a b : ℕ} (hj : j<s) (op : (code j).op=.join)
    (ord : (code j).left<m+j ∧ (code j).right<m+j)
    (hl : (run m code drop fork s).refs (addr m (code j).left)=some a)
    (hr : (run m code drop fork s).refs (addr m (code j).right)=some b) :
    let p := programAt m code drop fork (2*j)
    let R := run m code drop fork s
    p.size<R.size ∧ R.code p.size=⟨.join,a,b⟩ ∧ IncidenceLiteralPrefix.stage (2*m) m (stage m code fork) (init m drop) (2*j)=.emit ⟨.join,a,b⟩ := by
  let p := programAt m code drop fork (2*j)
  have bd (i : ℕ) (h : i<m+j) : addr m i<2*m+2*j := by unfold addr; split <;> omega
  have l : p.refs (addr m (code j).left)=some a :=
    (refsStable m code drop fork (bd _ ord.1) (by omega : 2*j≤2*s)).symm.trans hl
  have r : p.refs (addr m (code j).right)=some b :=
    (refsStable m code drop fork (bd _ ord.2) (by omega : 2*j≤2*s)).symm.trans hr
  have gate : stage m code fork (2*j)=⟨(code j).op,addr m (code j).left,addr m (code j).right⟩ := by simp [stage]
  have em : IncidenceLiteralPrefix.stage (2*m) m (stage m code fork) (init m drop) (2*j)=
      .emit ⟨.join,a,b⟩ := by
    unfold IncidenceLiteralPrefix.stage
    rw [gate]
    change literal (code j).op (p.refs _) (p.refs _)=_
    simp [op,l,r,literal]
  obtain ⟨lt,eqg,_⟩ := IncidenceLiteralPrefix.emitted _ _ _ _ (show 2*j<2*s by omega) em
  exact ⟨lt,eqg,em⟩
end IncidenceWarmCompiler
