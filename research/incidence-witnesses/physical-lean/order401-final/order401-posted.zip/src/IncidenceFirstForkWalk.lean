import IncidenceLineCorridor
import IncidenceHoistReaders
namespace IncidenceFirstForkWalk
open IncidenceStartNormalization IncidenceLineColdSibling IncidenceLineCorridor IncidenceHoistReaders
variable {n : ℕ}
def terminal (C : Circuit n) (w : ℕ) := w=C.output ∨ uses C w≠1
instance (C : Circuit n) (w : ℕ) : Decidable (terminal C w) := by unfold terminal; infer_instance

noncomputable def readerGate (C : Circuit n) (sz : 0<C.size) (w : ℕ) : Fin C.size :=
  if one : uses C w=1 then
    ⟨(unique_reader C w one).choose,(unique_reader C w one).choose_spec.choose_spec.2.1⟩
  else ⟨0,sz⟩
noncomputable def port (C : Circuit n) (w : ℕ) : Bool :=
  if one : uses C w=1 then (unique_reader C w one).choose_spec.choose else false

theorem input_port (C : Circuit n) (sz : 0<C.size) (w : ℕ) (one : uses C w=1) :
    operand (C.code (readerGate C sz w)) (port C w)=w ∧
    ∀g<C.size,∀b,operand (C.code g) b=w → g=(readerGate C sz w).val ∧ b=port C w := by
  simpa [readerGate,port,one] using (unique_reader C w one).choose_spec.choose_spec.2.2

noncomputable def walk (C : Circuit n) (sz : 0<C.size) (x : Fin n) : ℕ→ℕ
  | 0 => n+x.val
  | i+1 => let w := walk C sz x i
           if terminal C w then w else n+n+(readerGate C sz w).val

theorem first (C : Circuit n) (sz : 0<C.size) (x : Fin n) :
    ∃ k, terminal C (walk C sz x k) ∧ Corridor C x (walk C sz x k) := by
  classical
  let W := walk C sz x
  have step (i : ℕ) (go : ¬terminal C (W i)) :
      W i < W (i+1) ∧ W (i+1)=n+n+(readerGate C sz (W i)).val := by
    have one : uses C (W i)=1 := by by_contra bad; exact go (Or.inr bad)
    have z := (input_port C sz (W i) one).1
    have ord := C.earlier _ (readerGate C sz (W i)).isLt
    have eq : W (i+1)=n+n+(readerGate C sz (W i)).val := by simp only [W,walk,if_neg go]
    refine ⟨?_,eq⟩
    rw [eq]
    cases e : port C (W i) <;> simp [operand,e] at z <;> omega
  have bound : ∀i,W i<n+n+C.size := by
    intro i
    induction i with
    | zero => change n+x.val<n+n+C.size; omega
    | succ i ih =>
      by_cases stop : terminal C (W i)
      · simpa only [W,walk,if_pos stop] using ih
      · rw [(step i stop).2]; omega
  have ends : ∃i,terminal C (W i) := by
    by_contra! forever
    have grow : ∀i,i≤W i := by
      intro i; induction i with
      | zero => omega
      | succ i ih => have h := (step i (forever i)).1; omega
    have h1 := grow (n+n+C.size)
    have h2 := bound (n+n+C.size)
    omega
  let k := Nat.find ends
  have old : ∀i<k,¬terminal C (W i) := fun i hi => Nat.find_min ends hi
  let G i := readerGate C sz (W i)
  let S i := operand (C.code (G i)) (!(port C (W i)))
  have unique (i) (hi : i<k) := input_port C sz (W i)
    (show uses C (W i)=1 by by_contra bad; exact old i hi (Or.inr bad))
  refine ⟨k,Nat.find_spec ends,corridor C x W S G k rfl
    (fun i hi => (step i (old i hi)).2) ?_ ?_ ?_ ?_ ?_⟩
  · intro a ha b hb ab
    change b≤k at hb
    induction b with
    | zero => omega
    | succ b ih =>
      have rise := (step b (old b (by omega))).1
      by_cases eq : a=b
      · simpa [eq] using rise
      · exact (ih (by omega) (by omega)).trans rise
  · intro i hi
    have h := (unique i hi).1
    cases e : port C (W i) <;> simp_all [G,S,operand]
  · intro i hi a ha r
    rcases r with h|h
    · exact ((unique i hi).2 a ha true h).1
    · exact ((unique i hi).2 a ha false h).1
  · intro i hi eq
    have z := ((unique i hi).2 _ (G i).isLt (!(port C (W i))) eq).2
    cases e : port C (W i) <;> simp [e] at z
  · intro i hi same
    exact old i hi (Or.inl same)
#print axioms first
end IncidenceFirstForkWalk
