import IncidencePointCorridor
namespace IncidencePointDeterministicTail
/-- Walk to the first observed or non-singleton-use wire. The transition is
fixed globally; in particular terminal observations stop even on a sole use. -/
inductive Tail (next : Nat → Option Nat) : Nat → Nat → Prop where
  | stop {i} (h : next i=none) : Tail next i i
  | pass {i j z} (h : next i=some j) (rest : Tail next j z) : Tail next i z

theorem unique {f a b c} (p : Tail f a b) (q : Tail f a c) : b=c := by
  induction p with
  | stop h =>
    cases q with
    | stop _ => rfl
    | pass e _ => simp [h] at e
  | pass h _ ih =>
    cases q with
    | stop e => simp [e] at h
    | pass e rest =>
      rw [h] at e
      cases e
      exact ih rest

theorem no_shared {f : Nat→Option Nat} {b c : Nat} (different : b≠c) :
    ¬ ∃ u,Tail f u b ∧ Tail f u c := by
  rintro ⟨_,p,q⟩
  exact different (unique p q)
end IncidencePointDeterministicTail
