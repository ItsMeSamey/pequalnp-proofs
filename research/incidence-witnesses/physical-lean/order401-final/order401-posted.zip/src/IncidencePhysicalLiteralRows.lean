import IncidenceThetaRestrict
namespace IncidenceThetaRestrict
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceZeroRestriction
variable {n : ℕ}
theorem restrict_code (C : Circuit n) (P L : Finset (Fin n)) (bin : binary C)
    (hit : ∃v,inject P L v∈C.wire C.output) :
    ∃B : Circuit n,binary B ∧ B.size=(compileLiteral (n+n) (n+n) C.code (ref P L) C.size).size ∧
      B.wire B.output=inject P L ⁻¹' C.wire C.output ∧ B.code=(compileLiteral (n+n) (n+n) C.code (ref P L) C.size).code := by
  let X := fun i=>inject P L ⁻¹' C.wire i
  have bound (i) (hi : i<n+n) : Below (n+n) (ref P L i) := by
    intro w hw
    unfold ref at hw
    split at hw <;> simp_all
  have ones (w) (hw : w<n+n) : top n∈C.wire w := by
    by_cases h : w<n
    · exact ((C.inputs ⟨w,h⟩).1).symm ▸ (show (top n).1 ⟨w,h⟩=true from rfl)
    · let u : Fin n := ⟨w-n,by omega⟩
      have e : n+u.val=w := by dsimp [u]; omega
      rw [←e,(C.inputs u).2]
      rfl
  have ord (i) (hi : i<C.size) : OrderedBinary (C.code i) (n+n+i) :=
    ⟨(C.earlier i hi).1,(C.earlier i hi).2,bin i hi⟩
  have sem (i) (hi : i<C.size) : X (n+n+i)=(C.code i).eval X := by
    change _ ⁻¹' C.wire (n+n+i)=_
    rw [C.law i hi,preimage_gate]
  obtain ⟨_,order,o,oh,_,Y,base,ev,out⟩ := dense_minor (n+n) (n+n) C.size C.output C.code
    (ref P L) X C.wire (top n) bound (inputs C P L) ones ord sem C.output_lt hit
  let B : Circuit n := {
    size := (compileLiteral (n+n) (n+n) C.code (ref P L) C.size).size
    output := o
    code := (compileLiteral (n+n) (n+n) C.code (ref P L) C.size).code
    wire := Y
    output_lt := oh
    earlier := fun j hj=>⟨(order j hj).1,(order j hj).2.1⟩
    law := ev
    inputs := fun i=>⟨(base _ (by omega)).trans (C.inputs i).1,(base _ (by omega)).trans (C.inputs i).2⟩ }
  exact ⟨B,fun j hj=>(order j hj).2.2,rfl,out,rfl⟩

end IncidenceThetaRestrict
