import IncidenceRoundNoExtra
import IncidenceAllowedCap
namespace IncidenceRoundNoExtraPhysical
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceHoistPrune
open IncidenceRoundReservations IncidenceAllowedGeometry IncidencePhysicalPaidRound
open IncidenceThetaRoundDriver IncidenceThetaRestrict IncidenceThetaBatchHoist IncidenceMarkTransition IncidenceZeroRestriction
variable {n : ℕ} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)}
variable (a : Stage I P L) (M : Finset ℕ) (G : ℕ→Finset ℕ) (prot : Finset ℕ)
local notation "E" => kept a.A a.B \ prot
local notation "J" => rel I a.A a.B

theorem kept_range (A B : Finset (Fin n)) : kept A B⊆Finset.range (n+n) := by
  intro i h
  rcases Finset.mem_union.mp h with p|l
  · obtain ⟨p,_,rfl⟩ := Finset.mem_image.mp p
    exact Finset.mem_range.mpr (by omega)
  · obtain ⟨l,_,rfl⟩ := Finset.mem_image.mp l
    exact Finset.mem_range.mpr (by omega)

theorem output (D : Finset ℕ) (core : P.Nonempty)
    (legal : Allowed I a (nextP a.A D) (nextL a.B D)) : dead a.C D a.C.output=false := by
  classical
  obtain ⟨p,hp⟩ := core
  have pa := legal.keepP hp
  have min := legal.minP _ pa
  obtain ⟨l,inc⟩ := Finset.card_pos.mp (show 0<(N (rel I (nextP a.A D) (nextL a.B D)) false p).card by omega)
  obtain ⟨_,lb,flag⟩ := (Finset.mem_filter.mp inc).2
  have on := a.flag p l ⟨legal.subP pa,legal.subL lb,flag⟩
  have high : row n D ∈ a.C.wire a.C.output := by
    apply IncidencePointShield.monotone a.C _ a.C.output_lt _ on
    constructor
    · intro i h
      have eq : i=p := of_decide_eq_true h
      subst i
      exact decide_eq_true (Finset.mem_filter.mp pa).2
    · intro i h
      have eq : i=l := of_decide_eq_true h
      subst i
      exact decide_eq_true (Finset.mem_filter.mp lb).2
  simp [dead,IncidenceZeroRestriction.zeroAt,high]

noncomputable def des (C : Circuit n) (eligible : Finset ℕ) (j : ℕ) := decide (j∈designated C eligible)
theorem designated_owner (C : Circuit n) (eligible : Finset ℕ) {j : ℕ} (h : des C eligible j=true) :
    owned C eligible j∈eligible ∧ uses C (owned C eligible j)=1 ∧ owner C (owned C eligible j)=j := by
  obtain ⟨mem,eq⟩ := owned_spec C eligible (of_decide_eq_true h)
  exact ⟨(Finset.mem_filter.mp mem).1,(Finset.mem_filter.mp mem).2,eq⟩
theorem bundle (live : Live a.C) (hasCore : P.Nonempty)
    (safe : Safe (neighbors I) (kept a.A a.B) M G)
    (core : kept P L⊆prot) (guards : IncidenceMarkTransition.reserve M G⊆prot)
    (protect : IncidenceLabelHistory.vulnerable (IncidenceCleanupLabels.snap a.C.size a.C.code (kept a.A a.B))⊆prot)
    (stop : ¬IncidenceRoundPhysicalMove.Witness a E) :
    (∀ j<a.C.size,(a.C.code j).op=.meet → des a.C E j=true →
      (owned a.C E j=(a.C.code j).left ∨ owned a.C E j=(a.C.code j).right) ∧
      ∀D⊆E,D.card≤24→(row n D∈a.C.wire (n+n+j) ↔ row n D∈a.C.wire (owned a.C E j))) ∧
    (∀j<a.C.size,(a.C.code j).op=.meet → des a.C E j=false →
      ∀D⊆E,D.card≤24→(row n D∈a.C.wire (a.C.code j).left ↔ row n D∈a.C.wire (a.C.code j).right)) ∧
    (∀D⊆E,D.card≤24→∀j<a.C.size,2≤uses a.C (n+n+j)→dead a.C D (n+n+j)=false) ∧
    (∀x∈E,uses a.C x≤2) := by
  classical
  let C := a.C
  have range : E⊆Finset.range (n+n) := Finset.sdiff_subset.trans (kept_range a.A a.B)
  have geom (D : Finset ℕ) (de : D⊆E) (sz : D.card≤24) := allowed I a M G safe D prot core guards de sz
  have nb (D : Finset ℕ) (de : D⊆E) (sz : D.card≤24) (x : ℕ) (hx : x∈E) :
      ∃y∉D,adj J x y := neighbor_after I (Finset.mem_sdiff.mp hx).1 ((geom D de sz).2 x hx)
  have used (x : ℕ) (hx : x∈E) : 0<uses a.C x := by
    obtain ⟨y,_,edge⟩ := nb ∅ (Finset.empty_subset _) (by simp) x hx
    exact used_of_edge a.C J a.flag a.neg edge
  have op {x : ℕ} (hx : x∈sole a.C E) : (a.C.code (owner a.C x)).op=.meet :=
    protected_meet a.C E _ prot Finset.Subset.rfl protect hx
  have highs (D : Finset ℕ) (de : D⊆E) (sz : D.card≤24) (x : ℕ) (hx : x∈sole a.C E) :
      dead a.C D (sib a.C x)=false := by
    obtain ⟨y,free,edge⟩ := nb D de sz x (Finset.mem_filter.mp hx).1
    exact sibling a.C J a.bin a.flag a.neg edge (Finset.mem_filter.mp hx).2 (op hx) D free
  let init D := ref (keep a.A (nextP a.A D)) (keep a.B (nextL a.B D))
  have inputs (D : Finset ℕ) (de : D⊆E) (i : ℕ) (hi : i<n+n) :
      (init D i).isNone=dead a.C D i := by
    have a1 := new_ref a.A a.B D (de.trans Finset.sdiff_subset) hi
    have a2 := raw_flag a.C hi D
    change (init D i).isNone=true ↔ i∈D at a1
    exact Bool.eq_iff_iff.mpr (a1.trans a2.symm)
  have cost (D : Finset ℕ) (de : D⊆E) (sz : D.card≤24) :
      (a.C.size:ℤ)-(compileLiteral (n+n) (n+n) a.C.code (init D) a.C.size).size≤2*(D.card:ℤ) := by
    have cap := IncidenceAllowedCap.physical a M G prot safe core guards stop D de sz
    change a.C.size≤(compileLiteral (n+n) (n+n) a.C.code (init D) a.C.size).size+2*D.card at cap
    omega
  have none (D : Finset ℕ) (de : D⊆E) (sz : D.card≤24) := no_extra_mask a.C E a.bin live range used
    (fun _ hx=>op hx) highs de sz (output a D hasCore (geom D de sz).1) (init D) (inputs D de) (cost D de sz)
  refine ⟨?_,?_,?_,?_⟩
  · intro j _ _ yes
    exact private_copy a.C E (of_decide_eq_true yes) (fun _ hx=>op hx) highs
  · intro j hj meet no D de sz
    exact equal_dense a.C meet ((none D de sz).1 j hj (of_decide_eq_false no))
  · intro D de sz
    exact (none D de sz).2
  · intro x hx
    have de : ({x}:Finset ℕ)⊆E := Finset.singleton_subset_iff.mpr hx
    have sz : ({x}:Finset ℕ).card≤24 := by simp
    apply singleton_fan a.C a.bin live (Finset.mem_range.mp (range hx)) (output a {x} hasCore (geom {x} de sz).1)
      (init {x}) (inputs {x} de)
    simpa using cost {x} de sz
#print axioms bundle
end IncidenceRoundNoExtraPhysical
