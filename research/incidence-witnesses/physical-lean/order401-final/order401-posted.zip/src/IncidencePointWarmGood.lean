import IncidencePointWarmBad
import Mathlib.Algebra.Order.BigOperators.Group.Finset
namespace IncidencePointWarmMasks
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmCompiler IncidencePointWarmComparison
variable {n : Nat}
theorem good (C : Circuit n) (I : Fin n→Fin n→Prop) (M : Finset (Fin n)) (f c)
    (wire : Wiring C M f c) (neg : negatives C I 401 400) (J T : Finset (Fin n))
    (j2 : J.card≤2) (t2 : T.card≤2) (ind : ∀p∈J,∀l∈T,¬I p l)
    (find : ∀p∈J∩M,∃W : Finset (Fin n),W.card≤199 ∧
      (∀a∈J,∀l∈W,¬I a l) ∧ mask {p} W∈C.wire (c p)) :
    mask J T∉editedWire (n+n) C.size C.wire C.code (drops M) f C.output := by
  classical
  choose W wc safe live using find
  let P := (J∩M).attach
  let S := T∪P.biUnion (fun p=>W p.val p.property)
  have tsub : T⊆S := Finset.subset_union_left
  have many : P.card≤2 := by
    have := Finset.card_le_card (Finset.inter_subset_left : J∩M⊆J)
    simpa [P] using (show (J∩M).card≤2 by omega)
  have sub (p) (hp : p∈J∩M) : W p hp⊆S := by
    intro l hl
    exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨⟨p,hp⟩,Finset.mem_attach _ _,hl⟩)
  have small : S.card≤400 := by
    have h := Finset.card_biUnion_le_card_mul P (fun p=>W p.val p.property) 199 (fun p _=>wc p.val p.property)
    have t := Finset.card_union_le T (P.biUnion fun p=>W p.val p.property)
    change (T∪_).card≤400
    omega
  have reject : mask J S∉C.wire C.output := by
    apply negative C I neg (by omega) small
    intro p pj l hl
    rcases Finset.mem_union.mp hl with o|e
    · exact ind p pj l o
    · obtain ⟨q,_,inW⟩ := Finset.mem_biUnion.mp e
      exact safe q.val q.property p pj l inW
  apply mt _ reject
  apply ordinary C.code C.wire (drops M) f C.earlier wire.pins C.law _ _ C.output
    _ _ C.output C.output_lt le_rfl
  · intro i hi h
    exact bitInputs C M J T J S ∅ (fun _ hp _ _=>hp) tsub i hi h (by simp)
  · intro a ha _ inj
    obtain ⟨p,pj,pm,idx⟩ := wire.on_at J T a ha inj
    have pp := Finset.mem_inter.mpr ⟨pj,pm⟩
    rw [←idx]
    apply monotone C (c p) (by omega) _ (live p pp)
    constructor
    · intro q h
      have qp : q=p := by simpa [mask,bits] using h
      simpa [mask,bits,qp] using pj
    · intro l h
      simpa [mask,bits] using sub p pp (by simpa [mask,bits] using h)
#print axioms good
end IncidencePointWarmMasks
