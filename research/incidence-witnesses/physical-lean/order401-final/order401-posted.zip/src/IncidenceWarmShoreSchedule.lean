import IncidenceWarmForkSeparation
import IncidenceWarmTraceEditCap
namespace IncidenceWarmShoreSchedule
open SparseIncidence IncidenceStartNormalization IncidenceWarmCompiler IncidencePointFirstFork
open IncidencePointShield IncidenceWarmTraceEditCap
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

noncomputable def owners (offset : Nat) (S : Finset (Fin n)) : List Nat := S.toList.map fun x=>offset+x.val

theorem id_mem (offset : Nat) (S : Finset (Fin n)) (u : Nat) :
    u∈owners offset S ↔ ∃x∈S, offset+x.val=u := by simp [owners]

theorem ids_nodup (offset : Nat) (S : Finset (Fin n)) : (owners offset S).Nodup := by
  apply List.Nodup.map _ S.nodup_toList
  intro a b eq
  apply Fin.ext
  exact Nat.add_left_cancel eq

theorem shore_meet (offset : Nat) (S : Finset (Fin n)) (andOnly : soleAnd C offset)
    (sole : ∀x∈S,uses C (offset+x.val)=1) :
    ∀u∈owners offset S,∀ j<C.size,∀ b,port (C.code j) b=u → (C.code j).op=.meet := by
  intro u hu j hj b edge
  obtain ⟨x,hx,rfl⟩ := (id_mem _ _ _).mp hu
  apply andOnly x.val x.isLt (sole x hx) j hj
  cases b
  · exact Or.inl edge
  · exact Or.inr edge

theorem point_unique (pos : flags C I) (neg : negatives C I 401 400)
    (degree : ∀ l,Fintype.card {p // I p l}=402)
    (plane : ∀ a b,a≠b → ∃! l,I a l ∧ I b l) (hn : n=161203)
    (S : Finset (Fin n)) (warm : ∀x∈S,∃ W : Finset (Fin n),W.card≤399 ∧
      (∀l∈W,¬I x l) ∧ (single x,bits W)∈C.wire (fork C x.val)) :
    ∀u∈owners 0 S,∀v∈owners 0 S,fork C u=fork C v → u=v := by
  intro u hu v hv eq
  obtain ⟨x,hx,rfl⟩ := (id_mem _ _ _).mp hu
  obtain ⟨y,_,rfl⟩ := (id_mem _ _ _).mp hv
  by_contra diff
  obtain ⟨W,small,off,accept⟩ := warm x hx
  apply IncidenceWarmForkSeparation.points_distinct I C pos neg degree plane hn x y
    (fun h=>diff (h ▸ rfl)) W small off accept
  simpa using eq

theorem line_unique (pos : flags C I) (neg : negatives C I n 2)
    (degree : ∀ l,Fintype.card {p // I p l}=402)
    (plane : ∀ a b,a≠b → ∃! l,I a l ∧ I b l)
    (S : Finset (Fin n)) (warm : ∀x∈S,∃ W : Finset (Fin n),
      (∀p∈W,¬I p x) ∧ (bits W,single x)∈C.wire (fork C (n+x.val))) :
    ∀u∈owners n S,∀v∈owners n S,fork C u=fork C v → u=v := by
  intro u hu v hv eq
  obtain ⟨x,hx,rfl⟩ := (id_mem _ _ _).mp hu
  obtain ⟨y,_,rfl⟩ := (id_mem _ _ _).mp hv
  by_contra diff
  obtain ⟨W,off,accept⟩ := warm x hx
  exact IncidenceWarmForkSeparation.lines_distinct I C pos neg degree plane x y
    (fun h=>diff (h ▸ rfl)) W off accept eq
end IncidenceWarmShoreSchedule
