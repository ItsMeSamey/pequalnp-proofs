import IncidenceWarmBooked
import IncidenceWarmOutput
namespace IncidenceWarmCompiler
open CircuitRewire IncidenceZeroRestriction IncidenceStartNormalization

theorem compile_owners {n : ℕ} (C : Circuit n) (owners : List ℕ) (drop : Finset ℕ)
    (fork : ℕ→Option ℕ) (start : ℕ→ℕ) (side : ℕ→Bool) (tail : ℕ→List ℕ)
    (pins : ∀ j<C.size,∀ x,fork j=some x→x<n+n)
    (legal : ∀ x∈owners,x<n+n ∧ x∈drop ∧ start x<C.size ∧
      port (C.code (start x)) (side x)=x ∧ (C.code (start x)).op=.meet ∧
      Corridor (n+n) C.size C.code fork x (start x) (tail x))
    (distinct : (owners.flatMap fun x=>start x::tail x).Nodup)
    (bounded : ∀ j∈owners.flatMap (fun x=>start x::tail x),j<C.size)
    (covered : ∀ j<C.size,j∉owners.flatMap (fun x=>start x::tail x)→fork j=none)
    (live : (editedWire (n+n) C.size C.wire C.code drop fork C.output).Nonempty) :
    ∃ D : Circuit n,D.size+owners.length≤C.size ∧ binary D ∧
      D.wire D.output=editedWire (n+n) C.size C.wire C.code drop fork C.output := by
  obtain ⟨D,h,bin,out⟩ := physical C drop fork pins live
  refine ⟨D,?_,bin,out⟩
  rw [h]
  apply common_payment owners (fun x=>start x::tail x) _ distinct bounded covered
  intro x hx
  obtain ⟨bound,mem,first,edge,op,path⟩ := legal x hx
  exact owner_payment C.earlier bound mem first (side x) edge op path

theorem live_presence {Z : Type*} (m s : ℕ) (B : ℕ→Set Z) (code : ℕ→Gate)
    (drop : Finset ℕ) (fork : ℕ→Option ℕ) (ord : ∀ j<s,(code j).left<m+j ∧ (code j).right<m+j)
    (pins : ∀ j<s,∀ x,fork j=some x→x<m) (i : ℕ) (hi : i<m+s)
    (hit : (editedWire m s B code drop fork i).Nonempty) :
    presence m code drop fork s i=1 := by
  have addrBound : addr m i<2*m+2*s := by unfold addr; split <;> omega
  obtain ⟨_,_,_,Y,_,_,agree⟩ := actual m s B code drop fork ord pins
  have e := agree _ addrBound
  obtain ⟨z,hz⟩ := hit
  change z∈target m s B code drop fork (addr m i) at hz
  rw [e] at hz
  cases h : (run m code drop fork s).refs (addr m i) with
  | none => rw [h] at hz; exact False.elim hz
  | some v =>
    change bit ((run m code drop fork s).refs (addr m i))=1
    rw [h]
    rfl

theorem retained {Z : Type*} (m s : ℕ) (B : ℕ→Set Z) (code : ℕ→Gate)
    (drop : Finset ℕ) (fork : ℕ→Option ℕ) (ord : ∀ j<s,(code j).left<m+j ∧ (code j).right<m+j)
    (pins : ∀ j<s,∀ x,fork j=some x→x<m) (j : ℕ) (hj : j<s)
    (op : (code j).op=.join ∨ (code j).op=.meet)
    (l : (editedWire m s B code drop fork (code j).left).Nonempty)
    (r : (editedWire m s B code drop fork (code j).right).Nonempty) :
    cost m code drop fork (2*j)=1 := by
  have bounds := ord j hj
  have left := live_presence m s B code drop fork ord pins _ (by omega) l
  have right := live_presence m s B code drop fork ord pins _ (by omega) r
  obtain ⟨cc,_,ll,rr⟩ := row_form m code drop fork hj bounds
  rw [ll] at left
  rw [rr] at right
  rw [cc]
  rcases op with e|e <;> rw [e] <;>
    cases el : (programAt m code drop fork (2*j)).refs (addr m (code j).left) <;>
    cases er : (programAt m code drop fork (2*j)).refs (addr m (code j).right) <;>
    simp_all [bit,literal,emitted]

end IncidenceWarmCompiler
