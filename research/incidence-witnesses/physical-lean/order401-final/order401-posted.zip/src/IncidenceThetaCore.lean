import IncidenceThetaPaid
import IncidenceThetaPath
namespace IncidenceThetaCore
open SparseIncidence IncidenceStartNormalization IncidenceThetaBatchHoist IncidenceThetaRestrict
open IncidenceHoistPrune IncidenceThetaPaid
variable {n q : ℕ}

theorem core (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (x Y : Fin n) (p l : Fin q ↪ Fin n) (i₀ : Fin q)
    (xp : ∀i,x≠p i) (ly : ∀i,l i≠Y) (xy : ¬I x Y)
    (xl : ∀i,I x (l i)) (pl : ∀i,I (p i) (l i)) (py : ∀i,I (p i) Y)
    (co : ∀b x' y,x'≠y → (N I b x'∩N I b y).card≤1)
    (bin : binary C) (live : Live C) (pos : flags C I) (neg : negatives C I 2 2) :
    4*q≤C.size := by
  classical
  let T := Finset.univ.erase i₀
  let P := T.image p
  let Q := T.image l
  have xkeep : x∉P := by
    intro h; obtain ⟨i,_,hi⟩:=Finset.mem_image.mp h; exact xp i hi.symm
  have Ykeep : Y∉Q := by
    intro h; obtain ⟨i,_,hi⟩:=Finset.mem_image.mp h; exact ly i hi
  have pk : p i₀∉P := by
    intro h; obtain ⟨i,mem,hi⟩:=Finset.mem_image.mp h
    exact (Finset.mem_erase.mp mem).1 (p.injective hi)
  have lk : l i₀∉Q := by
    intro h; obtain ⟨i,mem,hi⟩:=Finset.mem_image.mp h
    exact (Finset.mem_erase.mp mem).1 (l.injective hi)
  have pN (v) (h : v∈P) : ∃w∉Q,I v w := by
    obtain ⟨i,_,rfl⟩:=Finset.mem_image.mp h; exact ⟨Y,Ykeep,py i⟩
  have qN (v) (h : v∈Q) : ∃w∉P,I w v := by
    obtain ⟨i,_,rfl⟩:=Finset.mem_image.mp h; exact ⟨x,xkeep,xl i⟩
  have degree (d) (hd : d∈owners P Q) : 1<(N I d.1 d.2).card := by
    obtain ⟨side,v⟩:=d; cases side
    · obtain ⟨i,_,rfl⟩:=Finset.mem_image.mp ((ownerP ..).1 hd)
      apply Finset.one_lt_card.mpr
      exact ⟨l i,by simp [N,pl],Y,by simp [N,py],ly i⟩
    · obtain ⟨i,_,rfl⟩:=Finset.mem_image.mp ((ownerL ..).1 hd)
      apply Finset.one_lt_card.mpr
      exact ⟨x,by simp [N,xl],p i,by simp [N,pl],xp i⟩
  obtain ⟨B,_,_,pf,nf,sz⟩ := room C I 1 (by decide) P Q bin live pos neg degree
    (fun d _ j ne=>co d.1 d.2 j ne.symm) pN qN ⟨x,xkeep,l i₀,lk,xl i₀⟩
  have four := IncidenceThetaPath.path B (rel I Pᶜ Qᶜ) x (p i₀) (l i₀) Y (xp i₀) (ly i₀)
    ⟨Finset.mem_compl.mpr xkeep,Finset.mem_compl.mpr lk,xl i₀⟩ ⟨Finset.mem_compl.mpr pk,Finset.mem_compl.mpr lk,pl i₀⟩ ⟨Finset.mem_compl.mpr pk,Finset.mem_compl.mpr Ykeep,py i₀⟩ (fun h=>xy h.2.2) pf nf
  have nP : P.card+1=q := by
    rw [Finset.card_image_of_injective _ p.injective]
    simpa [T] using Finset.card_erase_add_one (Finset.mem_univ i₀)
  have nQ : Q.card+1=q := by
    rw [Finset.card_image_of_injective _ l.injective]
    simpa [T] using Finset.card_erase_add_one (Finset.mem_univ i₀)
  omega
#print axioms core
end IncidenceThetaCore
