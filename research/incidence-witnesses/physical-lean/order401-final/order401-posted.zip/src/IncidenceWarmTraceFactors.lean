import IncidenceWarmTraceChart
import IncidenceWarmTraceNative
import IncidencePointTraceSide
namespace IncidenceWarmTraceFactors
open IncidenceStartNormalization IncidencePointCorridor IncidenceWarmTraceNative IncidenceWarmTraceChart
variable {n : Nat} (C : Circuit n) (G : Finset Nat) (sib : G→Nat)

theorem native_factors {a z : Nat} {p : Path (n+n) C.code a z} (native : Native C p)
    (selected : ∀ g b,(g,b)∈p.ports → (g∈G ↔ (C.code g).op=.meet))
    (aside : ∀ g b,(h : (g,b)∈p.ports) → ∀hg : g∈G,sib ⟨g,hg⟩=inputPort (C.code g) (!b)) :
    (rows C G a).map sib=p.factors := by
  induction native with
  | nil w terminal => simp [no_more C G w terminal,Path.factors]
  | @cons g b out tail edge rest ih =>
    have tailSelected (j d) (hj : (j,d)∈tail.ports) := selected j d (List.mem_cons_of_mem _ hj)
    have tailAside (j d) (hj : (j,d)∈tail.ports) := aside j d (List.mem_cons_of_mem _ hj)
    have nextFactors := ih tailSelected tailAside
    have m : (g,b)∈(Path.cons g b tail).ports := by simp [Path.ports]
    rw [after C G _ _ edge]
    simp only [Nat.add_sub_cancel_left]
    by_cases hg : g∈G
    · simp [hg,Path.factors,(selected g b m).mp hg,nextFactors,aside g b m hg]
    · have op : (C.code g).op≠.meet := fun h=>hg ((selected g b m).mpr h)
      simp [hg,op,Path.factors,nextFactors]

theorem common_factors {a z : Nat} {p : Path (n+n) C.code a z} (native : Native C p)
    (selected : ∀ g b,(g,b)∈p.ports → (g∈G ↔ (C.code g).op=.meet))
    (aside : ∀ g b,(h : (g,b)∈p.ports) → ∀hg : g∈G,sib ⟨g,hg⟩=inputPort (C.code g) (!b))
    {u : G} (first : (rows C G a).head?=some u) :
    IncidencePointCommon.factors G sib (successor C G) (later C G) u=p.factors := by
  have eq := native_factors C G sib native selected aside
  cases h : rows C G a with
  | nil => simp [h] at first
  | cons v t =>
    have same : v=u := by simpa [h] using first
    subst u
    have ts := (head_suffix C G _ v t h).2
    simpa [h,ts,IncidenceWarmTraceChart.factors] using eq
#print axioms common_factors
end IncidenceWarmTraceFactors
