import IncidenceLineRoutedSlots
namespace IncidenceEligiblePin
open IncidenceStartNormalization IncidenceLineRoutedSlots IncidenceLineGateBooking SparseIncidence
variable {n : ℕ}
def pinMask (P : Finset (Fin n)) : Input n := (fun i => decide (i∈P),fun _=>false)

theorem pin_forces (I : Fin n→Fin n→Prop) [DecidableRel I]
    (unique : ∀p r,p≠r → ∃! l,I p l ∧ I r l)
    (C : Circuit n) (g : Fin C.size) (x l p : Fin n) (ne : x≠l)
    (P : Finset (Fin n)) (inside : ∀i∈P,I i l) (chosen : p∈P)
    (h : eligible C I x g p) :
    pinMask P∈C.wire (n+n+g.val) ∧
      (∃a∉P,I a x ∧ hit C (C.code g).left a) ∧
      (∃b∉P,I b x ∧ hit C (C.code g).right b) := by
  obtain ⟨_,inc,active,⟨a,ia,ap,ha⟩,⟨b,ib,bp,hb⟩⟩ := h
  have outside (z : Fin n) (iz : I z x) (zp : z≠p) : z∉P := by
    intro here
    obtain ⟨_,_,only⟩ := unique z p zp
    exact ne ((only x ⟨iz,inc⟩).trans (only l ⟨inside z here,inside p chosen⟩).symm)
  refine ⟨?_,⟨a,outside a ia ap,ia,ha⟩,⟨b,outside b ib bp,ib,hb⟩⟩
  apply wire_mono C g (u:=(single p,fun _=>false)) _ active
  refine ⟨?_,fun _ h=>h⟩
  intro i hi
  have eq : i=p := of_decide_eq_true hi
  subst i
  exact decide_eq_true chosen
#print axioms pin_forces
end IncidenceEligiblePin
