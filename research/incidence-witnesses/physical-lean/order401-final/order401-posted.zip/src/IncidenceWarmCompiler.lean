import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import IncidenceZeroRestriction
import IncidenceStartNormalization
namespace IncidenceWarmCompiler
open CircuitRewire IncidenceZeroRestriction IncidenceStartNormalization

def init (m : ℕ) (drop : Finset ℕ) (i : ℕ) : Option ℕ :=
  if i<m then (if i∈drop then none else some i) else some (i-m)

def addr (m i : ℕ) : ℕ := if i<m then i else 2*m+2*(i-m)+1

def stage (m : ℕ) (code : ℕ→Gate) (fork : ℕ→Option ℕ) (k : ℕ) : Gate :=
  let j := k/2
  if k%2=0 then ⟨(code j).op,addr m (code j).left,addr m (code j).right⟩
  else match fork j with
    | none => ⟨.copy,2*m+2*j,2*m+2*j⟩
    | some x => ⟨.join,2*m+2*j,m+x⟩

def run (m : ℕ) (code : ℕ→Gate) (drop : Finset ℕ) (fork : ℕ→Option ℕ) (s : ℕ) :=
  compileLiteral (2*m) m (stage m code fork) (init m drop) (2*s)

private theorem addr_lt {m i j : ℕ} (h : i<m+j) : addr m i<2*m+2*j := by
  unfold addr
  split <;> omega

theorem compiled {Z : Type*} (m s : ℕ) (code : ℕ→Gate) (drop : Finset ℕ)
    (fork : ℕ→Option ℕ) (X B : ℕ→Set Z)
    (ord : ∀ j<s,(code j).left<m+j ∧ (code j).right<m+j)
    (pins : ∀ j<s,∀ x,fork j=some x→x<m)
    (input : ∀ i<2*m,X i=CircuitRewire.read B (init m drop i))
    (laws : ∀ k<2*s,X (2*m+k)=(stage m code fork k).eval X) :
    CorrectLiteral (2*m) m (2*s) X B (init m drop) (run m code drop fork s) := by
  apply literal_correct _ _ _ _ _ _ _ _ input _ laws
  · intro i hi
    unfold init
    split <;> rename_i h
    · split <;> simp_all [Below]
    · intro a ha
      simp at ha
      omega
  · intro k hk
    have hj : k/2<s := by omega
    have o := ord _ hj
    by_cases even : k%2=0
    · simpa [stage,even,show 2*(k/2)=k by omega] using
        And.intro (addr_lt o.1) (addr_lt o.2)
    · cases h : fork (k/2) with
      | none => simp [stage,even,h] <;> omega
      | some x =>
        have := pins _ hj x h
        simp [stage,even,h] <;> omega

def emitted : Action → ℕ
  | .reuse _ => 0
  | .emit _ => 1

def cost (m : ℕ) (code : ℕ→Gate) (drop : Finset ℕ) (fork : ℕ→Option ℕ) (k : ℕ) :=
  let p := compileLiteral (2*m) m (stage m code fork) (init m drop) k
  let g := stage m code fork k
  emitted (literal g.op (p.refs g.left) (p.refs g.right))

private theorem stepSize (p : Program) (m n k : ℕ) (a : Action) :
    (advance p m n k a).size=p.size+emitted a := by cases a <;> simp [advance,emitted]

theorem size_eq (m s : ℕ) (code : ℕ→Gate) (drop : Finset ℕ) (fork : ℕ→Option ℕ) :
    (run m code drop fork s).size =
      ∑ j∈Finset.range s,(cost m code drop fork (2*j)+cost m code drop fork (2*j+1)) := by
  induction s with
  | zero => simp [run,compileLiteral]
  | succ j ih =>
    rw [Finset.sum_range_succ,←ih]
    simp only [run,show 2*(j+1)=2*j+1+1 by omega,compileLiteral,stepSize,cost]
    omega

theorem cost_le_one (m : ℕ) (code : ℕ→Gate) (drop : Finset ℕ) (fork : ℕ→Option ℕ)
    (k : ℕ) : cost m code drop fork k ≤ 1 := by
  unfold cost
  dsimp only
  cases literal _ _ _ <;> simp [emitted]

theorem paid (m s : ℕ) (code : ℕ→Gate) (drop : Finset ℕ) (fork : ℕ→Option ℕ)
    (savings : ℕ)
    (pay : savings + (∑ j∈Finset.range s,cost m code drop fork (2*j+1)) ≤
      ∑ j∈Finset.range s,(1-cost m code drop fork (2*j))) :
    (run m code drop fork s).size+savings≤s := by
  let c := cost m code drop fork
  have sum : (∑ j∈Finset.range s,c (2*j)) + (∑ j∈Finset.range s,(1-c (2*j))) = s := by
    rw [←Finset.sum_add_distrib]
    have h : ∀ j∈Finset.range s,c (2*j)+(1-c (2*j))=1 := by
      intro j _
      have := cost_le_one m code drop fork (2*j)
      change c (2*j) ≤ 1 at this
      omega
    rw [Finset.sum_congr rfl h]
    simp
  rw [size_eq,Finset.sum_add_distrib]
  dsimp only [c] at sum
  omega
end IncidenceWarmCompiler
