import IncidenceLineTraceConstruction
namespace IncidenceLineBaselineView
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceLineTraceConstruction
open IncidenceLineGateBooking IncidenceLineRoutedSlots
variable {n : ℕ} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I] (x w : Fin n)

noncomputable def labels (j : ℕ) : Finset (Fin n) := by
  classical
  exact Finset.univ.filter (fun p => I p x ∧ hit C j p)

theorem mem_labels (j : ℕ) (p : Fin n) : p∈labels C I x j ↔ I p x ∧ hit C j p := by
  classical
  exact ⟨fun h=>(Finset.mem_filter.mp h).2,fun h=>Finset.mem_filter.mpr ⟨Finset.mem_univ _,h⟩⟩

theorem up_room {safe : Fin C.size→Prop} {k k' S} (h : View C I x safe k S) (le : k≤k') : View C I x safe k' S := by
  induction h with
  | thin small => exact .thin small
  | unary sub h ih => exact .unary sub (ih le)
  | join g before ok op left right va vb ia ib =>
    exact .join g (before.trans_le le) ok op left right va vb

abbrev coldSite (g : Fin C.size) := (avoid I x w,fun _=>false)∉C.wire (n+n+g.val)

theorem baseline (j : ℕ) (hj : j<n+n+C.size)
    (cold : (avoid I x w,fun _=>false)∉ C.wire j) :
    View C I x (coldSite C I x w) (j+1-(n+n)) (labels C I x j) := by
  classical
  induction j using Nat.strong_induction_on with | ind j prev =>
  by_cases raw : j<n+n
  · apply View.thin
    by_cases lo : j<n
    · let p : Fin n := ⟨j,lo⟩
      have sub : labels C I x j ⊆ {p} := by
        intro z hz
        have hitz := (Finset.mem_filter.mp hz).2.2
        change (single z,fun _=>false)∈C.wire p.val at hitz
        rw [(C.inputs p).1] at hitz
        have e : p=z := of_decide_eq_true hitz
        simp [e]
      have H := Finset.card_le_card sub
      simp at H
      omega
    · let l : Fin n := ⟨j-n,by omega⟩
      have e : j=n+l.val := by dsimp [l]; omega
      have sub : labels C I x j=∅ := by
        apply Finset.eq_empty_iff_forall_notMem.mpr
        intro p hp
        have hitp := (Finset.mem_filter.mp hp).2.2
        change (single p,fun _=>false)∈C.wire j at hitp
        rw [e,(C.inputs l).2] at hitp
        exact Bool.noConfusion hitp
      simp [sub]
  · let g : Fin C.size := ⟨j-(n+n),by omega⟩
    have e : n+n+g.val=j := by dsimp [g]; omega
    have ord := C.earlier g.val g.isLt
    let a := (C.code g.val).left
    let b := (C.code g.val).right
    have ja : a<j := e ▸ ord.1
    have jb : b<j := e ▸ ord.2
    have lvl : g.val<j+1-(n+n) := by dsimp [g]; omega
    have left (h : (avoid I x w,fun _=>false)∉C.wire a) :
        View C I x (coldSite C I x w) g.val (labels C I x a) :=
      up_room C I x (prev a ja (by omega) h) (by dsimp [g]; omega)
    have right (h : (avoid I x w,fun _=>false)∉C.wire b) :
        View C I x (coldSite C I x w) g.val (labels C I x b) :=
      up_room C I x (prev b jb (by omega) h) (by dsimp [g]; omega)
    have law := C.law g.val g.isLt
    rw [e] at law
    cases op : (C.code g.val).op with
    | join =>
      have h : C.wire j=C.wire a∪C.wire b := by simpa [Gate.eval,op,Op.eval,a,b] using law
      rw [h] at cold
      have eq : labels C I x j=labels C I x a∪labels C I x b := by
        ext p
        simp only [Finset.mem_union,mem_labels,hit,h,Set.mem_union]
        tauto
      rw [eq]
      have safe : coldSite C I x w g := by change _∉C.wire _; rw [e,h]; exact cold
      exact .join g lvl safe op (fun _ hp=>(Finset.mem_filter.mp hp).2)
        (fun _ hp=>(Finset.mem_filter.mp hp).2)
        (left (fun v=>cold (Or.inl v))) (right (fun v=>cold (Or.inr v)))
    | meet =>
      have h : C.wire j=C.wire a∩C.wire b := by simpa [Gate.eval,op,Op.eval,a,b] using law
      rw [h] at cold
      by_cases ea : (avoid I x w,fun _=>false)∈C.wire a
      · apply View.unary (T:=labels C I x b) _ (up_room C I x (right (fun eb=>cold ⟨ea,eb⟩)) lvl.le)
        intro p hp
        rw [mem_labels,hit,h,Set.mem_inter_iff] at hp
        exact (mem_labels ..).mpr ⟨hp.1,hp.2.2⟩
      · apply View.unary (T:=labels C I x a) _ (up_room C I x (left ea) lvl.le)
        intro p hp
        rw [mem_labels,hit,h,Set.mem_inter_iff] at hp
        exact (mem_labels ..).mpr ⟨hp.1,hp.2.1⟩
    | copy =>
      have h : C.wire j=C.wire a := by simpa [Gate.eval,op,Op.eval,a] using law
      rw [h] at cold
      have eq : labels C I x j=labels C I x a := by ext p; simp only [mem_labels,hit,h]
      rw [eq]
      exact up_room C I x (left cold) lvl.le
    | zero =>
      have h : C.wire j=∅ := by simpa [Gate.eval,op,Op.eval] using law
      apply View.thin
      simp [labels,hit,h]
#print axioms baseline
end IncidenceLineBaselineView
