import IncidenceRoundNoExtra
import IncidenceRoundShockPrice
namespace IncidenceRoundReservations
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceOperandLedger IncidenceZeroRestriction
open IncidenceHoistPrune
variable {n : ℕ} (C : Circuit n) (E : Finset ℕ)
theorem surplus_price (bin : binary C) (live : Live C)
    (eligible : E⊆Finset.range (n+n)) (positive : ∀x∈E,0<uses C x)
    (meet : ∀x∈sole C E,(C.code (owner C x)).op=.meet)
    (high : ∀D⊆E,D.card≤24→∀x∈sole C E,dead C D (sib C x)=false)
    {D : Finset ℕ} (de : D⊆E) (sz : D.card≤24) (out : dead C D C.output=false)
    (init : ℕ→Option ℕ) (input : ∀i<n+n,(init i).isNone=dead C D i)
    : (IncidenceSurvivingReads.surplus C.size C.code (dead C D) ((D∩sole C E).image (owner C))).card+
      2*D.card+(compileLiteral (n+n) (n+n) C.code init C.size).size ≤ C.size := by
  classical
  let S := D∩sole C E
  have hs {x} (h : x∈S) : x∈sole C E := (Finset.mem_inter.mp h).2
  have rq {x} (hx : x∈S) := reserve C eligible meet (high D de sz) (hs hx)
  have h := IncidenceRoundShockPrice.price (n+n) C.size C.code init (dead C D) D S (owner C) Finset.inter_subset_left (de.trans eligible) (fun i hi=>raw_flag C hi D)
    ((owner_inj C eligible meet high).mono (show (↑S:Set ℕ)⊆↑(sole C E) from fun _ h=>hs h))
    (fun x hx=>by rw [IncidencePinLowLedger.fan_uses,(Finset.mem_filter.mp (hs hx)).2]; decide)
    (fun x hx=>by
      obtain ⟨xd,ns⟩ := Finset.mem_sdiff.mp hx
      have xe := de xd
      have pos := positive x xe
      have ne : uses C x≠1 := fun eq=>ns (Finset.mem_inter.mpr ⟨xd,Finset.mem_filter.mpr ⟨xe,eq⟩⟩)
      rw [IncidencePinLowLedger.fan_uses]; omega)
    (fun j hj=>by obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hj; exact Finset.mem_range.mpr (rq hx).1)
    (fun j hj=>by
      obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hj
      have xd := (Finset.mem_inter.mp hx).1
      have low := (raw_flag C (Finset.mem_range.mp (eligible (de xd))) D).2 xd
      obtain ⟨_,op,z⟩ := rq hx
      rcases z with ⟨p,q⟩|⟨p,q⟩ <;> simp [oneAnd,op,p,q,low])
    (live_nonneg C live D out) input (fun j hj=>⟨(C.earlier j hj).1,(C.earlier j hj).2,bin j hj⟩) (dead_step C D)
  exact h
end IncidenceRoundReservations
