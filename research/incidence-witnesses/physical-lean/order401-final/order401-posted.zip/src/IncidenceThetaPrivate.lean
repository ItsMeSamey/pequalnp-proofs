import IncidenceThetaChoose
import IncidenceHoistNormalize
import IncidenceHoistEndpoint
import IncidenceHoistStage
import IncidenceHoistSensitive
import HoistPhysicalPorts
namespace IncidenceThetaBatchHoist
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceHoistFlow IncidenceHoistWalk
open IncidenceHoistEndpoint IncidenceHoistReaders IncidenceHoistPorts IncidenceHoistCompile
open IncidenceHoistPrefix IncidenceHoistStage HoistPhysicalPorts

open IncidenceHoistNormalize IncidenceHoistShield IncidenceHoistSparse
private theorem meet_hit {n} (C : Circuit n) (w j : ℕ) (b : Bool)
    (js : j<C.size) (read : operand (C.code j) b=w) (op : (C.code j).op=.meet) :
    0<count meetWeight w (circuitCode C) := by
  refine (circuit_count_pos C meetWeight w).mpr ⟨j,js,by simp [meetWeight,op],?_⟩
  cases b
  · exact Or.inr read
  · exact Or.inl read

private theorem private_meet {n} (C : Circuit n) (w : ℕ) (one : uses C w=1)
    (hit : 0<count meetWeight w (circuitCode C)) :
    ∀ j<C.size, (C.code j).left=w ∨ (C.code j).right=w → (C.code j).op=.meet := by
  obtain ⟨k,hk,weight,port⟩ := (circuit_count_pos C meetWeight w).mp hit
  have op : (C.code k).op=.meet := by by_contra bad; simp [meetWeight,bad] at weight
  obtain ⟨cut,b,_,_,_,uniq⟩ := unique_reader C w one
  have e : k=cut := port.elim (fun x => (uniq k hk true x).1) (fun x => (uniq k hk false x).1)
  intro j hj read
  have eq : j=cut := read.elim (fun x => (uniq j hj true x).1) (fun x => (uniq j hj false x).1)
  exact (e.trans eq.symm) ▸ op

variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
private theorem agree_raw (line : Bool) (x : Fin n) (u v : Input n) (agr : AgreeOff line x u v)
    (i : Nat) (hi : i<n+n) (ne : i ≠ owner line x) : u∈C.wire i ↔ v∈C.wire i := by
  by_cases lo : i<n
  · let j : Fin n := ⟨i,lo⟩
    rw [(C.inputs j).1]
    cases line
    · change u.1 j=true ↔ v.1 j=true
      rw [agr.2 j (fun eq => ne (congrArg Fin.val eq))]
    · change u.1 j=true ↔ v.1 j=true
      rw [agr.1]
  · let j : Fin n := ⟨i-n,by omega⟩
    have form : i=n+j.val := by dsimp [j]; omega
    rw [form,(C.inputs j).2]
    cases line
    · change u.2 j=true ↔ v.2 j=true
      rw [agr.1]
    · change u.2 j=true ↔ v.2 j=true
      rw [agr.2 j (by intro eq; apply ne; change i=n+x.val; rw [← eq]; exact form)]

private theorem no_escape (line : Bool) (x : Fin n) {w : Nat} {H : Finset Nat}
    (p : Prefix C (owner line x) w H (witness line x)) (dead : uses C w = 0)
    (u v : Input n) (agr : AgreeOff line x u v) :
    ∀ i<n+n+C.size, i∉H → (u∈C.wire i ↔ v∈C.wire i) := by
  have empty : occurrences C w = [] :=
    List.length_eq_zero_iff.mp ((occurrence_count C w).trans dead)
  have parent (j : Nat) (hj : j<C.size) (b : Bool) (outside : n+n+j∉H) :
      keep (C.code j) b ∉ H := by
    intro h
    have eq := (p.leaves j hj b h).resolve_right outside
    have mem := (occurrence_mem C w j b).mpr ⟨hj,eq⟩
    rw [empty] at mem
    exact List.not_mem_nil mem
  intro i
  induction i using Nat.strong_induction_on with
  | ind i ih =>
    intro good outside
    by_cases raw : i<n+n
    · exact agree_raw C line x u v agr i raw (fun eq => outside (eq ▸ p.ownerInside))
    let j := i-(n+n)
    have atGate : i=n+n+j := by dsimp [j]; omega
    have valid : j<C.size := by omega
    obtain ⟨hl,hr⟩ := C.earlier j valid
    have l := ih (C.code j).left (by omega) (by omega) (parent j valid true (atGate ▸ outside))
    have r := ih (C.code j).right (by omega) (by omega) (parent j valid false (atGate ▸ outside))
    rw [atGate,C.law j valid]
    cases op : (C.code j).op <;> simp only [Gate.eval,op,Op.eval,Set.mem_union,Set.mem_inter_iff] <;> tauto

private theorem has_use (cold : ∀ side x,witness side x ∉ C.wire C.output) (pos : flags C I) (line : Bool)
    (x y : Fin n) (inc : if line then I y x else I x y) {w : Nat} {H : Finset Nat}
    (p : Prefix C (owner line x) w H (witness line x)) : 0 < uses C w := by
  by_contra! dead
  have zero : uses C w=0 := by omega
  have out : C.output∉H := fun h => cold line x (p.hot _ h)
  cases line
  · let u : Input n := (single x,single y)
    have agree : AgreeOff false x u (witness true y) := by
      refine ⟨rfl,?_⟩
      intro i ne
      simp [u,witness,single,ne]
    have same := no_escape C false x p zero _ _ agree C.output C.output_lt out
    exact cold true y (same.mp (pos x y inc))
  · let u : Input n := (single y,single x)
    have agree : AgreeOff true x u (witness false y) := by
      refine ⟨rfl,?_⟩
      intro i ne
      simp [u,witness,single,ne]
    have same := no_escape C true x p zero _ _ agree C.output C.output_lt out
    exact cold false y (same.mp (pos y x inc))

theorem private_after (k : ℕ) (D : List (Raw n)) (k1 : 1≤k)
    (pos : flags C I) (neg : negatives C I (k+1) (k+1))
    (degree : ∀d∈D,k<(N I d.1 d.2).card)
    (over : ∀d∈D,∀i≠d.2,(N I d.1 d.2∩N I d.1 i).card≤1)
    (binC : binary C) (line : Bool) (x : Fin n) (hd : (line,x)∈D) :
    let r := IncidenceHoistShield.owner line x
    let E := edited C D
    IncidenceStartNormalization.uses E r=1 → ∀ j<E.size, (E.code j).left=r ∨ (E.code j).right=r → (E.code j).op=.meet := by
  let r := IncidenceHoistShield.owner line x
  let mode := sel C D
  let E := edited C D
  let v := endpoint C C.size r
  change IncidenceStartNormalization.uses E r=1 → ∀ j<E.size, (E.code j).left=r ∨ (E.code j).right=r → (E.code j).op=.meet
  intro one
  have rawBound : r<n+n := by cases line <;> simp [r,IncidenceHoistShield.owner] <;> omega
  obtain ⟨H,pre,stop⟩ := complete C C.size r {r} (initial C r _ (owner_hot C line x)) (by omega)
  obtain ⟨y,hy⟩ := Finset.card_pos.mp ((Nat.zero_le k).trans_lt (degree (line,x) hd))
  have nei : if line then I y x else I x y := by simpa [N] using hy
  have single (side : Bool) (z : Fin n) : witness side z∉C.wire C.output := by
    have hh := neg_view C I (k+1) neg side {z} ∅ (by simp) (by simp) (by simp)
    cases side <;> simpa [IncidencePinHoistSparse.view,IncidencePinHoistSparse.mask_single,
      IncidencePinHoistSparse.mask,witness] using hh
  have sourcePos := has_use C I single pos line x y nei pre
  have eq := ref_walk C mode C.size r (chooses C I D k k1 pos neg degree over (line,x) hd)
  have input : (buildPrefix (n+n) C.code mode C.size).ref r=r := by
    simpa [buildPrefix] using ref_stable (n+n) C.code mode 0 C.size r (by omega)
  have vr : (buildPrefix (n+n) C.code mode C.size).ref v=r := eq.trans input
  have preserve (w : Op → ℕ) : count w v (circuitCode C) ≤ count w r (circuitCode E) := by
    rw [show circuitCode E = codeList (n+n) C.size C.output C.code mode from circuit_code C mode]
    apply exit_count_le
    · intro t ht hit
      have ⟨l,h⟩ := C.earlier t ht
      have before : v<n+n+t := hit.elim (fun e => e ▸ l) (fun e => e ▸ h)
      have stable := ref_stable (n+n) C.code mode t (C.size-t) v before
      rw [show t+(C.size-t)=C.size by omega] at stable
      exact stable.symm.trans vr
    · intro t _ b h
      obtain ⟨d,_,path⟩ := source C h
      have on := walk_shields C (single d.1 d.2) _ _ _ (initial C _ _ (owner_hot C d.1 d.2)) (t,b) path
      refine ⟨on.1,?_⟩
      intro contrary
      have st := walk_reads C _ _ (t,b) path
      change step? C (keep (C.code t) b)=some (t,b) at st
      rw [contrary,stop] at st
      contradiction
  have oldOne : IncidenceStartNormalization.uses C v=1 := by
    have bound := preserve (fun _ => 1)
    rw [actual_uses,actual_uses] at bound
    change IncidenceStartNormalization.uses E r=1 at one
    change 0<IncidenceStartNormalization.uses C v at sourcePos
    omega
  obtain ⟨k,b,read,hk,atPort,_⟩ := unique_reader C v oldOne
  have gate : (C.code k).op=.meet := by
    rcases binC k hk with joined|met
    · have can : step? C v=some (k,b) := by simp [step?,read,oldOne,joined]
      change step? C v=none at stop
      rw [stop] at can
      contradiction
    · exact met
  exact private_meet E r one ((meet_hit C v k b hk atPort gate).trans_le (preserve meetWeight))

#print axioms private_after
end IncidenceThetaBatchHoist
