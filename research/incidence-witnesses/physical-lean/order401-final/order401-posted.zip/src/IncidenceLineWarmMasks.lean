import IncidencePointWarmComparison
import IncidencePointForeign
namespace IncidenceLineWarm
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmCompiler IncidencePointWarmComparison
variable {n : Nat}

def mask (J T : Finset (Fin n)) : Input n := (bits T,bits J)
def drops (M : Finset (Fin n)) : Finset Nat := M.image (fun l=>n+l.val)
noncomputable def avoid (I : Fin n→Fin n→Prop) (J : Finset (Fin n)) : Finset (Fin n) := by
  classical exact Finset.univ.filter fun p=>∀ l∈J,¬I p l
theorem avoids (I : Fin n→Fin n→Prop) (J : Finset (Fin n)) (p : Fin n) :
    p∈avoid I J ↔ ∀ l∈J,¬I p l := by classical simp [avoid]

structure Wiring (C : Circuit n) (M : Finset (Fin n)) (f : Nat→Option Nat) (c : Fin n→Nat) : Prop where
  located : ∀j<C.size,∀a,f j=some a → ∃l∈M,n+l.val=a ∧ c l=n+n+j
  installed : ∀l∈M,∃j<C.size,f j=some (n+l.val) ∧ c l=n+n+j

theorem Wiring.pins {C : Circuit n} {M f c} (w : Wiring C M f c) :
    ∀j<C.size,∀a,f j=some a → a<n+n := by
  intro j hj a e
  obtain ⟨l,_,rfl,_⟩ := w.located j hj a e
  have := l.isLt; omega

theorem Wiring.on_at {C : Circuit n} {M f c} (w : Wiring C M f c)
    (J T : Finset (Fin n)) (j : Nat) (hj : j<C.size)
    (on : mask J T∈CircuitRewire.read C.wire (f j)) :
    ∃l∈J,l∈M ∧ c l=n+n+j := by
  cases eq : f j with
  | none => simp [eq,CircuitRewire.read] at on
  | some a =>
    obtain ⟨l,hl,rfl,idx⟩ := w.located j hj a eq
    refine ⟨l,?_,hl,idx⟩
    simpa [eq,CircuitRewire.read,(C.inputs l).2,mask,bits] using on

theorem bitInputs (C : Circuit n) (M J T J' T' except : Finset (Fin n))
    (retained : ∀l∈J,l∉M → l∉except → l∈J') (payload : T⊆T') :
    ∀i<n+n,i∉drops M → (∀l∈except,i≠n+l.val) → mask J T∈C.wire i → mask J' T'∈C.wire i := by
  intro i hi keep good
  by_cases low : i<n
  · let p : Fin n:=⟨i,low⟩
    rw [(C.inputs p).1]
    change decide (p∈T)=true → decide (p∈T')=true
    simpa only [decide_eq_true_eq] using (show p∈T → p∈T' from fun h=>payload h)
  · let l : Fin n:=⟨i-n,by omega⟩
    have eq : i=n+l.val := by dsimp [l]; omega
    rw [eq,(C.inputs l).2]
    change decide (l∈J)=true → decide (l∈J')=true
    simp only [decide_eq_true_eq]
    exact fun h=>retained l h (fun h=>keep (Finset.mem_image.mpr ⟨l,h,eq.symm⟩)) (fun h=>good l h eq)

theorem negative (C : Circuit n) (I : Fin n→Fin n→Prop) (neg : negatives C I n 401)
    {J T : Finset (Fin n)} (jc : J.card≤401) (ind : ∀l∈J,∀p∈T,¬I p l) :
    mask J T∉C.wire C.output := by
  apply neg (bits T) (bits J) ((bits_card T).le.trans (by simpa using Finset.card_le_univ T))
    ((bits_card J).le.trans jc)
  intro p l hp hl
  exact ind l (by simpa [bits] using hl) p (by simpa [bits] using hp)

theorem good (C : Circuit n) (I : Fin n→Fin n→Prop) (M : Finset (Fin n)) (f c)
    (wire : Wiring C M f c) (neg : negatives C I n 401) (J T : Finset (Fin n))
    (jc : J.card≤2) (ind : ∀l∈J,∀p∈T,¬I p l)
    (hot : ∀l∈J∩M,mask {l} (avoid I J)∈C.wire (c l)) :
    mask J T∉editedWire (n+n) C.size C.wire C.code (drops M) f C.output := by
  have sub : T⊆avoid I J := fun p hp=>(avoids I J p).2 (fun l hl=>ind l hl p hp)
  have reject : mask J (avoid I J)∉C.wire C.output :=
    negative C I neg (by omega) (fun l hl p hp=>(avoids I J p).1 hp l hl)
  apply mt _ reject
  apply ordinary C.code C.wire (drops M) f C.earlier wire.pins C.law _ _ C.output
    _ _ C.output C.output_lt le_rfl
  · intro i hi keep
    exact bitInputs C M J T J _ ∅ (fun _ h _ _=>h) sub i hi keep (by simp)
  · intro j hj _ inj
    obtain ⟨l,hl,hm,e⟩ := wire.on_at J T j hj inj
    rw [←e]
    apply monotone C _ (by omega) _ (hot l (Finset.mem_inter.mpr ⟨hl,hm⟩))
    refine ⟨fun _ h=>h,?_⟩
    intro a ha
    have eq : a=l := by simpa [mask,bits] using ha
    simpa [mask,bits,eq] using hl
#print axioms good
end IncidenceLineWarm
