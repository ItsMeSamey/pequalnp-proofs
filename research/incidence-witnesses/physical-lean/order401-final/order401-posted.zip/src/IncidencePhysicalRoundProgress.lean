import IncidenceRoundPhysicalFunding
import IncidenceGroupNativeIds
import IncidenceRoundAndBound
import IncidenceRoundDesignatedPorts
import IncidenceRoundOrdinaryPorts
import IncidenceRoundEssential
import IncidencePhysicalRoundLive
namespace IncidencePhysicalRoundProgress
open CircuitRewire IncidenceStartNormalization IncidencePhysicalOrGroups IncidenceThetaRoundDriver
open IncidenceThetaRestrict IncidenceThetaBatchHoist IncidenceMarkTransition IncidenceAllowedGeometry
open IncidenceRoundReservations IncidenceRoundNoExtraPhysical IncidenceRoundPhysicalFunding IncidenceRobust
variable {n : ℕ} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)}
theorem progress (a : Stage I P L) (join : ∀p q,p≠q→∃! r,I p r∧I q r)
    (hn : n=161203) (coreP : P.Nonempty) (M : Finset ℕ) (G : ℕ→Finset ℕ) (prot : Finset ℕ)
    (safe : Safe (neighbors I) (kept a.A a.B) M G) (core : kept P L⊆prot)
    (guards : reserve M G⊆prot)
    (protect : IncidenceLabelHistory.vulnerable (IncidenceCleanupLabels.snap a.C.size a.C.code (kept a.A a.B))⊆prot)
    (remaining : 322406-38808≤(kept a.A a.B).card)
    (sbound : (singles a.C (kept a.A a.B)).card≤13075) (pbound : prot.card≤4602)
    (cap : a.C.size+4≤2*(kept a.A a.B).card+1616) :
    IncidenceRoundPhysicalMove.Witness a (kept a.A a.B\prot) := by
  classical
  let V := kept a.A a.B
  let E := V\prot
  let J := rel I a.A a.B
  by_contra stop
  have live := IncidenceRoundPhysicalMove.live_of_stop a stop
  obtain ⟨ands,sig,raw,large⟩ := IncidenceRoundAndBound.bound a M G prot live coreP safe core guards protect stop
  obtain ⟨_,_,_,maxTwo⟩ := bundle a M G prot live coreP safe core guards protect stop
  have vr := kept_range a.A a.B
  have er : E⊆Finset.range (n+n) := Finset.sdiff_subset.trans vr
  have op {x : ℕ} (hx : x∈sole a.C E) := protected_meet a.C E V prot Finset.Subset.rfl protect hx
  have hi (D : Finset ℕ) (de : D⊆E) (sz : D.card≤24) (x : ℕ) (hx : x∈sole a.C E) :
      dead a.C D (sib a.C x)=false := by
    have xE := (Finset.mem_filter.mp hx).1
    have after := (allowed I a M G safe D prot core guards de sz).2 x xE
    obtain ⟨y,off,edge⟩ := neighbor_after I (Finset.mem_sdiff.mp xE).1 after
    exact sibling a.C J a.bin a.flag a.neg edge (Finset.mem_filter.mp hx).2 (op hx) D off
  have used (x : ℕ) (hx : x∈V) := IncidenceRoundEssential.positive a x hx
  have two (x : ℕ) (hx : x∈E\singles a.C V) : uses a.C x=2 := by
    obtain ⟨e,non⟩ := Finset.mem_sdiff.mp hx
    have v := (Finset.mem_sdiff.mp e).1
    have nz := used x v
    have max := maxTwo x e
    have ne : uses a.C x≠1 := fun one=>non (Finset.mem_filter.mpr ⟨v,one⟩)
    omega
  have deg (x : Vertex n) (hx : IncidenceGroupPlaneTests.wireId x∈E\singles a.C V) :
      2<(IncidenceGroupPlaneTests.adj J x).card := by
    have v := (Finset.mem_sdiff.mp (Finset.mem_sdiff.mp hx).1).1
    cases x with
    | inl p =>
      have m := a.pointMin p ((left _ _ p).mp v)
      simpa [IncidenceGroupPlaneTests.adj,lines,N,J] using m
    | inr l =>
      have m := a.lineMin l ((right _ _ l).mp v)
      simpa [IncidenceGroupPlaneTests.adj,points,N,J] using m
  have lower := IncidenceGroupNativeIds.demand a.C I J join (fun _ _ h=>h.2.2) a.flag a.neg
    V prot (singles a.C V) (fun i h=>Finset.mem_range.mp (vr h)) deg
    (fun i h=>IncidenceRoundOrdinaryPorts.ports a.C E a.bin sig er raw large hi
      (Finset.mem_sdiff.mp h).1 (two i h)) two
  let U := IncidenceRoundDesignatedPorts.rows a.C E
  obtain ⟨mo,sl⟩ := IncidenceRoundDesignatedPorts.slots a.C E er (fun _ h=>op h)
  have upper := designated_count a.C a.bin live U (IncidenceRoundDesignatedPorts.side a.C E) mo sl
  have us := IncidenceRoundDesignatedPorts.bound a.C E
  have incl : sole a.C E ⊆ singles a.C V := by
    intro x hx
    obtain ⟨e,o⟩ := Finset.mem_filter.mp hx
    exact Finset.mem_filter.mpr ⟨(Finset.mem_sdiff.mp e).1,o⟩
  have bill := budget a.C V vr used live
  have ub : U.card≤(singles a.C V).card := us.trans (Finset.card_le_card incl)
  change V.card≤(singles a.C V).card+prot.card+2*(tops a.C).card at lower
  change 25*(meets a.C).card≤25*U.card+2*(n+n)+25*(excess a.C+extra a.C V+2*prot.card) at ands
  change 322406-38808≤V.card at remaining
  change (singles a.C V).card≤13075 at sbound
  change a.C.size+4≤2*V.card+1616 at cap
  omega
end IncidencePhysicalRoundProgress
