import IncidenceWarmShoreSchedule
import IncidenceWarmDomain
import IncidencePointWarmBad
namespace IncidenceWarmPointSchedule
open SparseIncidence IncidenceStartNormalization IncidenceWarmCompiler IncidencePointFirstFork
open IncidencePointShield IncidenceWarmShoreSchedule IncidenceWarmTraceFamily IncidenceWarmTraceSchedule
open IncidenceWarmDomain IncidencePointWarmMasks
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

theorem construct (pos : flags C I) (neg : negatives C I 401 400) (andP : soleAnd C 0)
    (degree : ∀ l,Fintype.card {p // I p l}=402)
    (plane : ∀a b,a≠b → ∃!l,I a l ∧ I b l) (hn : n=161203)
    (M : Finset (Fin n)) (sole : ∀x∈M,uses C x.val=1)
    (warm : ∀x∈M,∃W : Finset (Fin n), W.card≤399 ∧ (∀l∈W,¬I x l) ∧
      (single x,bits W)∈C.wire (fork C x.val)) :
    ∃ A : Schedule C, A.drop=drops M ∧ A.owners=owners 0 M ∧
      Wiring C M A.fork (fun x=>fork C x.val) := by
  let L := owners 0 M
  have ids {u : Nat} (h : u∈L) : ∃x∈M,x.val=u := by simpa using (id_mem 0 M u).mp h
  have raw (u) (hu : u∈L) : u<n+n := by obtain ⟨x,_,rfl⟩ := ids hu; have := x.isLt; omega
  have one (u) (hu : u∈L) : uses C u=1 := by obtain ⟨x,hx,rfl⟩ := ids hu; exact sole x hx
  have meet := shore_meet C 0 M andP (by simpa using sole)
  have unique := point_unique C I pos neg degree plane hn M warm
  have no : negatives C I 2 2 := fun a b pa pb => neg a b (by omega) (by omega)
  obtain ⟨start,side,tail,ok,nd,bd,covers⟩ := family C I no L (ids_nodup 0 M) raw one meet unique
  let f := schedule L.toFinset (stop C)
  have pins (j) (_ : j<C.size) (u) (h : f j=some u) : u<n+n :=
    raw u (List.mem_toFinset.mp (schedule_spec _ _ _ _ h).1)
  let A : Schedule C := ⟨L,L.toFinset,f,start,side,tail,pins,
    fun x hx=>⟨raw x hx,by simpa using hx,ok x hx⟩,nd,bd,fun j _=>covers j⟩
  refine ⟨A,?_,rfl,?_,?_⟩
  · change L.toFinset=drops M
    ext a
    simp [L,owners,drops]
  · intro j hj a h
    obtain ⟨mem,eq⟩ := (wiring C I no L raw one unique j a).mp h
    obtain ⟨p,hp,rfl⟩ := ids mem
    exact ⟨p,hp,rfl,eq.symm⟩
  · intro p hp
    have mem : p.val∈L := (id_mem 0 M _).mpr ⟨p,hp,by simp⟩
    obtain ⟨_,_,_,e,_,_,_,eq⟩ := IncidenceWarmTraceBooking.raw_start C p.val (sole p hp)
      (not_output C I no _ (raw _ mem))
    have b := IncidenceWarmTraceShadow.fork_bound C (by have := p.isLt; omega : p.val<n+n+C.size)
    exact ⟨e,by omega,(wiring C I no L raw one unique e _).mpr ⟨mem,eq.symm⟩,eq⟩
#print axioms construct
end IncidenceWarmPointSchedule
