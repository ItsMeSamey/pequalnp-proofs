import IncidenceLineColdSibling
import IncidencePointCutSet
namespace IncidenceLineCorridor
open IncidenceStartNormalization IncidencePointShield IncidenceLineColdSibling
variable {n : ℕ}

/-- Construct semantic shadow tests from actual ordered gate indices and unique
physical readers. No output/sibling independence oracle is required. -/
theorem corridor (C : Circuit n) (x : Fin n) (wire side : ℕ→ℕ) (gate : ℕ→Fin C.size)
    (k : ℕ) (start : wire 0=n+x.val)
    (number : ∀i<k,wire (i+1)=n+n+(gate i).val)
    (forward : StrictMonoOn wire (Set.Iic k))
    (ports : ∀i<k,((C.code (gate i)).left=wire i ∧ (C.code (gate i)).right=side i) ∨
      ((C.code (gate i)).right=wire i ∧ (C.code (gate i)).left=side i))
    (single : ∀i<k, ∀a<C.size,(C.code a).left=wire i ∨ (C.code a).right=wire i → a=(gate i).val)
    (distinct : ∀i<k,side i≠wire i) (no_out : ∀i<k,wire i≠C.output) :
    Corridor C x (wire k) := by
  have step (m : ℕ) (mk : m<k) (prev : Corridor C x (wire m)) : Corridor C x (wire (m+1)) := by
    let P := (Finset.range (m+1)).image wire
    have init : n+x.val∈P := Finset.mem_image.mpr ⟨0,Finset.mem_range.mpr (by omega),start⟩
    have nextid := number m mk
    have closure : ∀a<C.size,n+n+a≠n+n+(gate m).val →
        (C.code a).left∈P ∨ (C.code a).right∈P → n+n+a∈P := by
      intro a ha ne read
      have prevWire : ∃w∈P,(C.code a).left=w ∨ (C.code a).right=w := by
        rcases read with h|h
        · exact ⟨_,h,Or.inl rfl⟩
        · exact ⟨_,h,Or.inr rfl⟩
      obtain ⟨_,hi,r⟩ := prevWire
      obtain ⟨i,ii,rfl⟩ := Finset.mem_image.mp hi
      have im := Finset.mem_range.mp ii
      have idx := single i (by omega) a ha r
      have lt : i<m := by
        by_contra! ge
        have eq : i=m := by omega
        exact ne (by rw [idx,eq])
      exact Finset.mem_image.mpr ⟨i+1,Finset.mem_range.mpr (by omega),by rw [number i (by omega),idx]⟩
    have dom : C.output∉P := by
      intro h
      obtain ⟨i,ii,eq⟩ := Finset.mem_image.mp h
      exact no_out i (by have h := Finset.mem_range.mp ii; omega) eq
    have sibling : side m∉P := by
      intro h
      obtain ⟨i,ii,eq⟩ := Finset.mem_image.mp h
      have im := Finset.mem_range.mp ii
      by_cases same : i=m
      · exact distinct m mk (same ▸ eq.symm)
      have ik : i<k := by omega
      have sm := ports m mk
      have rr : (C.code (gate m)).left=wire i ∨ (C.code (gate m)).right=wire i := by
        rcases sm with s|s
        · exact Or.inr (s.2.trans eq.symm)
        · exact Or.inl (s.2.trans eq.symm)
      have ID := single i ik (gate m).val (gate m).isLt rr
      have lt := forward (a:=i+1) (b:=m+1) (by change i+1≤k; omega)
        (by change m+1≤k; omega) (by omega)
      rw [number i ik,nextid,ID] at lt
      omega
    have sb := C.earlier (gate m).val (gate m).isLt
    have sideBound : side m<n+n+C.size := by rcases ports m mk with s|s <;> omega
    rw [nextid]
    apply Corridor.next (gate m) prev (ports m mk)
    · exact confined _ _ _ _ C.code P init C.earlier closure _ sideBound sibling
    · exact confined _ _ _ _ C.code P init C.earlier closure _ C.output_lt dom
  have reach : ∀i,i≤k → Corridor C x (wire i) := by
    intro i; induction i with
    | zero => intro _; rw [start]; exact .raw
    | succ i ih => intro h; exact step i (by omega) (ih (by omega))
  exact reach k le_rfl
#print axioms corridor
end IncidenceLineCorridor
