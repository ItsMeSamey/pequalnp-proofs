import IncidenceCommonSignature
import IncidenceRoundReservations
namespace IncidenceRoundDenseSignature
open CircuitRewire IncidenceStartNormalization IncidenceDenseSignature
open IncidenceRoundReservations
variable {n : ℕ} (C : Circuit n) (E : Finset ℕ)
def val (i : ℕ) (D : Finset ℕ) := row n (D∩E) ∈ C.wire i
def inputSig (i : ℕ) : Sig ℕ := if i∈E then some {i} else none

/-- A fixed private slot carries its own raw on every dense test. The opposite
slot is physically high, also on tests omitting the owner. -/
theorem copy_on (j : ℕ) (hj : j<C.size) (meet : (C.code j).op=.meet)
    (x : ℕ) (b : Bool) (pin : IncidenceHoistReaders.operand (C.code j) b=x)
    (sib : ∀ D⊆E,D.card≤24 → row n D∈C.wire (IncidenceHoistReaders.operand (C.code j) (!b))) :
    (x=(C.code j).left ∨ x=(C.code j).right) ∧
       ∀ D⊆E,D.card≤24 → (row n D∈C.wire (n+n+j) ↔ row n D∈C.wire x) := by
  cases b <;> simp [IncidenceHoistReaders.operand] at pin sib
  · exact ⟨Or.inr pin.symm,fun D h hd=>by
      simp [C.law j hj,Gate.eval,meet,Op.eval,pin,sib D h hd]⟩
  · exact ⟨Or.inl pin.symm,fun D h hd=>by
      simp [C.law j hj,Gate.eval,meet,Op.eval,pin,sib D h hd]⟩

theorem physical (bin : binary C) (des : ℕ→Bool) (own : ℕ→ℕ)
    (priv : ∀ j<C.size,(C.code j).op=.meet → des j=true →
       (own j=(C.code j).left ∨ own j=(C.code j).right) ∧
       ∀ D⊆E,D.card≤24 → (row n D∈C.wire (n+n+j) ↔ row n D∈C.wire (own j)))
    (equal : ∀ j<C.size,(C.code j).op=.meet → des j=false →
       ∀ D⊆E,D.card≤24 → (row n D∈C.wire (C.code j).left ↔ row n D∈C.wire (C.code j).right)) :
    ∃ sig : ℕ→Sig ℕ,
      (∀ i<n+n+C.size, valid 24 (sig i) ∧ IncidenceCommonSignature.Agrees 24 (val C E i) (high (sig i))) ∧
      (∀ i<n+n,sig i=inputSig E i) ∧
      (∀ j<C.size,(C.code j).op=.join →sig (n+n+j)=merge 24 (sig (C.code j).left) (sig (C.code j).right)) ∧
      (∀ j<C.size,(C.code j).op=.meet → des j=true → sig (n+n+j)=sig (own j)) ∧
      (∀ j<C.size,(C.code j).op=.meet → des j=false →
        sig (n+n+j)=sig (C.code j).left ∧ sig (C.code j).left=sig (C.code j).right) := by
  refine IncidenceCommonSignature.common (n+n) C.size 24 C.code _ _ des own ?_ C.earlier
    (fun j hj=>(bin j hj).symm) ?_ ?_ ?_
  · intro i hi
    constructor
    · by_cases h : i∈E <;> simp [inputSig,h,valid]
    · intro D hd
      rw [val,raw_dense C _ hi]
      by_cases h : i∈E <;> simp [inputSig,h,high]
  · intro j hj op D hd
    simp [val,C.law j hj,Gate.eval,op,Op.eval]
  · intro j hj op de
    obtain ⟨slot,ag⟩ := priv j hj op de
    exact ⟨slot,fun D hd=>ag (D∩E) Finset.inter_subset_right
      ((Finset.card_le_card Finset.inter_subset_left).trans hd)⟩
  · intro j hj op de
    have h (D : Finset ℕ) (hd : D.card≤24) := equal j hj op de (D∩E) Finset.inter_subset_right
      ((Finset.card_le_card Finset.inter_subset_left).trans hd)
    exact ⟨fun D hd=>by simpa [val,C.law j hj,Gate.eval,op,Op.eval,←h D hd],h⟩
#print axioms physical
end IncidenceRoundDenseSignature
