import IncidenceHoistPrune
import IncidenceHoistReaders
namespace IncidenceDeadSink
open IncidenceStartNormalization IncidenceHoistPrune IncidenceHoistReaders

theorem exists_sink {n : ℕ} (C : Circuit n) (h : ¬Live C) :
    ∃ g : Fin C.size, ¬Anc C (n+n+g.val) ∧ C.output≠n+n+g.val ∧
      ∀ j<C.size,(C.code j).left≠n+n+g.val ∧ (C.code j).right≠n+n+g.val := by
  classical
  let D := (Finset.range C.size).filter fun i=>¬Anc C (n+n+i)
  have mem (i : ℕ) : i∈D ↔ i<C.size ∧ ¬Anc C (n+n+i) := by simp [D]
  have nonempty : D.Nonempty := by
    by_contra empty
    apply h
    intro i hi
    by_contra dead
    exact empty ⟨i,(mem i).2 ⟨hi,dead⟩⟩
  let last := D.max' nonempty
  have ⟨valid,dead⟩ := (mem last).1 (Finset.max'_mem D nonempty)
  refine ⟨⟨last,valid⟩,dead,fun eq=>dead (eq ▸ Anc.output),?_⟩
  intro j hj
  have after (later : last<j) : Anc C (n+n+j) := by
    by_contra unobserved
    exact (Nat.not_le_of_lt later) (Finset.le_max' D j ((mem j).2 ⟨hj,unobserved⟩))
  have ⟨l,r⟩ := C.earlier j hj
  constructor
  · intro e
    change (C.code j).left=n+n+last at e
    exact dead (e ▸ Anc.left j hj (after (by omega)))
  · intro e
    change (C.code j).right=n+n+last at e
    exact dead (e ▸ Anc.right j hj (after (by omega)))

theorem zero_uses {n : ℕ} (C : Circuit n) (w : ℕ)
    (unread : ∀ j<C.size,(C.code j).left≠w ∧ (C.code j).right≠w) : uses C w=0 := by
  rw [← occurrence_count]
  apply List.length_eq_zero_iff.mpr
  apply List.eq_nil_iff_forall_not_mem.mpr
  rintro ⟨j,b⟩ mem
  obtain ⟨hj,e⟩ := (occurrence_mem C w j b).1 mem
  cases b
  · exact (unread j hj).2 e
  · exact (unread j hj).1 e

#print axioms exists_sink
#print axioms zero_uses
end IncidenceDeadSink
