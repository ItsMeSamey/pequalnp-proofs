import IncidenceActualLineCases
import IncidenceLineWarmFlags
import IncidenceLineWarmBad
namespace IncidenceActualLineChoice
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmCompiler IncidenceReciprocalChoice IncidenceChosenEnds
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

theorem full_mask (x : Fin n) (J : Finset (Fin n)) :
    IncidenceLineWarm.mask {x} (IncidenceLineWarm.avoid I J)∈C.wire (rank C x) ↔ full C I x J := by
  have e : bits (IncidenceLineWarm.avoid I J)=(fun p=>decide (∀l∈J,¬I p l)) := by
    funext p; simp [bits,IncidenceLineWarm.avoids]
  have s : bits {x}=single x := by funext p; simp [bits,single]
  simp [IncidenceLineWarm.mask,e,s,full]

theorem negative (neg : negatives C I n 401) (f : Fin n→Fin n) (v : Valid (D C I) f)
    (order : ∀x,removed f (rank C) x → ∀y∈D C I x,f y=x ∧ rank C y<rank C x ∧ ¬removed f (rank C) y)
    (inject : Nat→Option Nat) (w : IncidenceLineWarm.Wiring C (M C I f) inject (rank C))
    (a b : Fin n→Bool) (lc : Fintype.card {l // b l=true}≤2)
    (ind : ∀p l,a p=true → b l=true → ¬I p l) :
    (a,b)∉editedWire (n+n) C.size C.wire C.code (IncidenceLineWarm.drops (M C I f)) inject C.output := by
  let J := Finset.univ.filter (fun l=>b l=true)
  let T := Finset.univ.filter (fun p=>a p=true)
  have ta : bits T=a := by funext p; simp [T,bits]
  have jb : bits J=b := by funext p; simp [J,bits]
  have eq : (a,b)=IncidenceLineWarm.mask J T := by simp [IncidenceLineWarm.mask,ta,jb]
  have small : J.card≤2 := by rw [←bits_card J,jb]; exact lc
  have independent (l) (hl : l∈J) (p) (hp : p∈T) : ¬I p l :=
    ind p l (Finset.mem_filter.mp hp).2 (Finset.mem_filter.mp hl).2
  rw [eq]
  rcases cases_for_mask C I f v order J small with good|bad
  · exact IncidenceLineWarm.good C I _ _ _ w neg J T small independent (fun x h=>(full_mask C I x J).mpr (good x h))
  · obtain ⟨x,y,pair,xM,yM,prior,cold,hotX⟩ := bad
    rw [pair]
    apply IncidenceLineWarm.bad_pair C I _ _ _ w neg x y xM yM prior
      (IncidenceWarmTraceShadow.fork_bound C (by have := y.isLt; omega : n+y.val<n+n+C.size))
      (IncidenceWarmTraceShadow.blocked C (n+y.val)) T (independent x (by simp [pair]))
    · intro yes
      apply cold
      apply IncidencePointShield.monotone C (rank C y)
        (IncidenceWarmTraceShadow.fork_bound C (by have := y.isLt; omega : n+y.val<n+n+C.size)) _ yes
      constructor
      · intro p hp
        change bits T p=true at hp
        have mem : p∈T := by simpa [bits] using hp
        exact decide_eq_true ⟨independent y (by simp [pair]) p mem,independent x (by simp [pair]) p mem⟩
      · intro l h; simpa [IncidenceLineWarm.mask,bits,single] using h
    · apply (full_mask C I x {x}).mpr
      simpa using (pair_full C I x x).mpr hotX
#print axioms negative
end IncidenceActualLineChoice
