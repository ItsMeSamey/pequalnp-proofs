import IncidenceThetaBatchHoist
namespace IncidenceThetaBatchHoist
open SparseIncidence IncidenceStartNormalization
open IncidencePinHoistSparse (view mask mask_single count_mask active mask_active count_active)
variable {n : ℕ} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

theorem neg_view (k : ℕ) (neg : negatives C I k k) (side : Bool)
    (s t : Finset (Fin n)) (hs : s.card≤k) (ht : t.card≤k)
    (ind : ∀i∈s,∀j∈t,j∉N I side i) : view side s t∉C.wire C.output := by
  cases side
  · apply neg (mask s) (mask t) (by simpa only [count_mask] using hs) (by simpa only [count_mask] using ht)
    intro i j hi hj
    have h := ind i (of_decide_eq_true hi) j (of_decide_eq_true hj)
    simpa [N] using h
  · apply neg (mask t) (mask s) (by simpa only [count_mask] using ht) (by simpa only [count_mask] using hs)
    intro i j hi hj
    have h := ind j (of_decide_eq_true hj) i (of_decide_eq_true hi)
    simpa [N] using h

theorem adjacent (flag : flags C I) (d : Raw n) (y : Fin n) (h : y∈N I d.1 d.2) :
    view d.1 {d.2} {y}∈C.wire C.output := by
  rcases d with ⟨side,x⟩
  cases side <;> simp [N] at h <;> simpa [view,mask_single] using flag _ _ h

theorem stage (k : ℕ) (D : List (Raw n)) (pos : flags C I) (neg : negatives C I (k+1) (k+1))
    (degree : ∀d∈D,k<(N I d.1 d.2).card)
    (over : ∀d∈D,∀i≠d.2,(N I d.1 d.2∩N I d.1 i).card≤1) :
    (edited C D).size=C.size ∧ flags (edited C D) I ∧ negatives (edited C D) I k k := by
  have old := neg_view C I (k+1) neg
  have single (d : Raw n) (_ : d∈D) : IncidenceHoistWalk.witness d.1 d.2∉C.wire C.output := by
    have h := old d.1 {d.2} ∅ (by simp) (by simp) (by simp)
    rcases d with ⟨side,x⟩
    cases side <;> simpa [view,mask_single,mask,IncidenceHoistWalk.witness] using h
  refine ⟨rfl,fun p l i=>(bounds C D single).1 (pos p l i),?_⟩
  intro a b pa lb ind
  have h := cold C I k D old (fun d _=>adjacent C I pos d) degree over (active a) (active b)
    (by simpa only [count_active] using pa) (by simpa only [count_active] using lb)
    (fun i hi j hj=> ind i j (Finset.mem_filter.mp hi).2 (Finset.mem_filter.mp hj).2)
  simpa only [mask_active] using h
#print axioms stage
end IncidenceThetaBatchHoist
