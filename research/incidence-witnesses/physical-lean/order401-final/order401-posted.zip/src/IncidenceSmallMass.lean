import IncidenceNoExtra
namespace IncidenceSmallMass
open CircuitRewire IncidenceOperandLedger
open scoped BigOperators

/-- Every occurrence on either physical pin is counted, including ties. -/
theorem flow (n s : ℕ) (g : ℕ→Gate) (a : ℕ→ℤ)
    (ord : ∀ j<s,(g j).left<n+s ∧ (g j).right<n+s) :
    (∑ j∈Finset.range s,(a (g j).left+a (g j).right)) =
      (∑ i∈Finset.range n,fan g s i*a i) +
      ∑ j∈Finset.range s,fan g s (n+j)*a (n+j) := by
  rw [← Finset.sum_range_add]
  simp only [fan,Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  obtain ⟨hl,hr⟩ := ord j (Finset.mem_range.mp hj)
  simp [occ,add_mul,Finset.sum_add_distrib,ite_mul,hl,hr,Finset.sum_ite_eq]

/-- Charge a large source to the masses on its two small input pins. Summing local
inequalities telescopes every small internal mass even if distinct labels overlap. -/
theorem source_bound (n s : ℕ) (g : ℕ→Gate) (a : ℕ→ℤ) (sources : Finset ℕ)
    (k : ℤ) (inside : sources ⊆ Finset.range s)
    (ord : ∀ j<s,(g j).left<n+s ∧ (g j).right<n+s)
    (raw : ∀ i<n,fan g s i*a i≤2)
    (small : ∀ j<s,fan g s (n+j)*a (n+j)≤a (n+j))
    (gate : ∀ j<s,a (n+j)+(if j∈sources then k else 0) ≤
      a (g j).left+a (g j).right) :
    (sources.card : ℤ)*k ≤ 2*n := by
  classical
  have hgate := Finset.sum_le_sum (fun j (hj : j∈Finset.range s)=>gate j (Finset.mem_range.mp hj))
  have hraw := Finset.sum_le_sum (fun i (hi : i∈Finset.range n)=>raw i (Finset.mem_range.mp hi))
  have hsmall := Finset.sum_le_sum (fun j (hj : j∈Finset.range s)=>small j (Finset.mem_range.mp hj))
  have total := flow n s g a ord
  rw [Finset.sum_add_distrib] at hgate
  have cnt : (∑ j∈Finset.range s,if j∈sources then k else 0)=(sources.card : ℤ)*k := by
    rw [←Finset.sum_filter]
    have eq : (Finset.range s).filter (·∈sources)=sources := by
      ext j
      simp only [Finset.mem_filter]
      exact ⟨And.right,fun h=>⟨inside h,h⟩⟩
    simp [eq]
  rw [cnt] at hgate
  simp at hraw
  omega

open IncidenceDenseSignature
variable {α : Type*} [DecidableEq α]

def mass : Sig α → ℤ
  | none => 0
  | some A => A.card

theorem mass_nonneg (v : Sig α) : 0≤mass v := by
  cases v <;> simp [mass]

def largeSource (l r out : Sig α) : Bool :=
  l.isSome && r.isSome && out.isNone

/-- Computing a copy incurs no label loss, and a promoting union consumes at
least t+1 labels counted with their original operand multiplicities. -/
theorem local_transfer (t : ℕ) (l r out : Sig α)
    (mode : out=l ∨ out=r ∨ out=merge t l r) :
    mass out+(if largeSource l r out then (t:ℤ)+1 else 0)≤mass l+mass r := by
  rcases mode with h|h|h <;> subst out
  · cases l <;> cases r <;> simp [largeSource,mass]
  · cases r <;> cases l <;> simp [largeSource,mass]
  · cases l with
    | none => cases r <;> simp [largeSource,merge,mass]
    | some A =>
      cases r with
      | none => simp [largeSource,merge,mass]
      | some B =>
        have h := Finset.card_union_le A B
        by_cases small : (A ∪ B).card≤t <;> simp [merge,small,largeSource,mass] <;> omega

/-- Same physical gate sequence on both sides: source set and charge are determined
by its operand and output signatures; local mode is an actual copy or OR. -/
theorem signature_sources (n s t : ℕ) (g : ℕ→Gate) (sig : ℕ→Sig α)
    (ord : ∀ j<s,(g j).left<n+s ∧ (g j).right<n+s)
    (ordinary : ∀ i<n,fan g s i * mass (sig i)≤2)
    (unbranched : ∀ j<s,(sig (n+j)).isSome=true → fan g s (n+j)≤1)
    (mode : ∀ j<s,sig (n+j)=sig (g j).left ∨ sig (n+j)=sig (g j).right ∨
      sig (n+j)=merge t (sig (g j).left) (sig (g j).right)) :
    let sources := (Finset.range s).filter (fun j=>largeSource (sig (g j).left) (sig (g j).right) (sig (n+j)))
    (sources.card : ℤ)*((t:ℤ)+1)≤2*n := by
  classical
  dsimp only
  apply source_bound n s g (fun i=>mass (sig i)) _ _ (Finset.filter_subset _ _) ord ordinary
  · intro j hj
    cases h : sig (n+j) with
    | none => simp [mass]
    | some A =>
      have hf := unbranched j hj (by simp [h])
      exact (Int.mul_le_mul_of_nonneg_right hf (mass_nonneg (some A))).trans_eq (one_mul _)
  · intro j hj
    simpa [Finset.mem_filter, Finset.mem_range.mpr hj] using
      local_transfer t (sig (g j).left) (sig (g j).right) (sig (n+j)) (mode j hj)

def big (v : Sig α) : ℤ := if v.isNone then 1 else 0

/-- Two large predecessors consume one more large occurrence than a row produces.
A source can cancel one such charge. A small output only strengthens the bound. -/
theorem big_local (l r o : Sig α) :
    big o + (if l.isNone && r.isNone then (1:ℤ) else 0) ≤
    big l+big r+(if largeSource l r o then 1 else 0) := by
  cases l <;> cases r <;> cases o <;> simp [big,largeSource]

private theorem filterCount (w : Finset ℕ) (P : ℕ→Bool) :
    (∑ j∈w, if P j then (1:ℤ) else 0) = ((w.filter (fun j=>P j)).card : ℤ) := by
  rw [←Finset.sum_filter]
  simp

theorem big_rows (n s : ℕ) (g : ℕ→Gate) (sig : ℕ→Sig α)
    (ord : ∀ j<s,(g j).left<n+s ∧ (g j).right<n+s) :
    let S := (Finset.range s).filter (fun j=>largeSource (sig (g j).left) (sig (g j).right) (sig (n+j)))
    let B := (Finset.range s).filter (fun j=>(sig (g j).left).isNone && (sig (g j).right).isNone)
    (B.card : ℤ) ≤ S.card + (∑ i∈Finset.range n,fan g s i*big (sig i)) +
      ∑ j∈Finset.range s,(fan g s (n+j)-1)*big (sig (n+j)) := by
  classical
  dsimp only
  have h := Finset.sum_le_sum (s:=Finset.range s) (fun j _=>
    big_local (sig (g j).left) (sig (g j).right) (sig (n+j)))
  rw [Finset.sum_add_distrib,Finset.sum_add_distrib,
    filterCount,filterCount,flow n s g (fun i=>big (sig i)) ord] at h
  simp only [sub_mul,one_mul,Finset.sum_sub_distrib]
  omega

end IncidenceSmallMass
