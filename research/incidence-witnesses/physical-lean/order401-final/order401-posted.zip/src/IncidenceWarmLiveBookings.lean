import IncidenceWarmBookAssembly
import IncidenceWarmPhysicalRows
import IncidenceWarmBarePersistence
import IncidencePrunedBookMass
namespace IncidenceWarmLiveBookings
open IncidenceWarmCompiler IncidenceStartNormalization IncidenceLineRoutedSlots IncidenceHoistPrune SparseIncidence CircuitRewire
open scoped BigOperators
theorem lineCold {n : ℕ} (C : Circuit n) (p : Fin n) {i : ℕ} (lo : n≤i) (hi : i<n+n) :
    ¬hit C i p := by
  let a : Fin n := ⟨i-n,by omega⟩
  have eq : i=n+a.val := by dsimp [a]; omega
  unfold hit
  rw [eq,(C.inputs a).2]
  simp
theorem edits_cold {n : ℕ} (C : Circuit n) (drop : Finset ℕ) (fork : ℕ→Option ℕ)
    (d : ∀i∈drop,n≤i) (f : ∀j<C.size,∀x,fork j=some x→n≤x ∧ x<n+n) :
    (∀p : Fin n,∀i<n+n,i∈drop→¬hit C i p) ∧
    (∀p : Fin n,∀j<C.size,(single p,fun _=>false)∉CircuitRewire.read C.wire (fork j)) := by
  refine ⟨fun p i hi hd=>lineCold C p (d i hd) hi,?_⟩
  intro p j hj
  cases h : fork j with
  | none => simp [CircuitRewire.read]
  | some i => exact lineCold C p (f j hj i h).1 (f j hj i h).2

theorem compile {n : ℕ} (C : Circuit n) (hn : 0<n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (degree : ∀l,Fintype.card {p // I p l}=402) (drop : Finset ℕ) (fork : ℕ→Option ℕ)
    (pins : ∀j<C.size,∀x,fork j=some x→x<n+n)
    (dark : ∀p : Fin n,∀i<n+n,i∈drop→¬hit C i p)
    (off : ∀p : Fin n,∀j<C.size,(single p,fun _=>false)∉CircuitRewire.read C.wire (fork j))
    (live : (editedWire (n+n) C.size C.wire C.code drop fork C.output).Nonempty)
    (edited : ℕ) (paid : (run (n+n) C.code drop fork C.size).size+edited≤C.size) :
    ∃ D : Circuit n,binary D ∧ Live D ∧
      D.wire D.output=editedWire (n+n) C.size C.wire C.code drop fork C.output ∧
      ∃ lost,D.size+(edited+lost)≤C.size ∧
        ∀ (owner : Fin C.size→Fin n) (book : Fin C.size→Finset (Fin n)),
        (∀g,∀p∈book g,eligible C I (owner g) g p) →
        ∃ (ow : Fin D.size→Fin n) (bk : Fin D.size→Finset (Fin n)),
          (∀g,∀p∈bk g,eligible D I (ow g) g p) ∧
          (∑g,(book g).card) ≤ (∑g,(bk g).card)+402*lost := by
  obtain ⟨W,sz,bin,eq,cg,rd⟩ := physical_rows C drop fork pins live
  obtain ⟨D,szD,bd,ld,out,prune⟩ := IncidencePrunedBookMass.prune_books W bin I degree
  refine ⟨D,bd,ld,out.trans eq,W.size-D.size,by omega,?_⟩
  intro owner book good
  obtain ⟨o,b,hb,hm⟩ := IncidenceWarmBookAssembly.transfer_to_warm C W hn I drop fork sz cg
    (by
      intro i hi t
      rw [←rd i hi]
      exact (IncidenceWarmBarePersistence.wire_iff C.code C.wire drop fork
        (single t,fun _=>false) C.earlier pins C.law (dark t) (off t) i hi).symm)
    owner book good
  obtain ⟨own,bk,ok,lim⟩ := prune o b hb
  exact ⟨own,bk,ok,hm.symm ▸ lim⟩
end IncidenceWarmLiveBookings
#print axioms IncidenceWarmLiveBookings.compile
