import IncidenceWarmForkSeparation
import IncidenceLineGateBooking
import IncidenceChosenEnds
namespace IncidenceActualLineChoice
open SparseIncidence IncidenceStartNormalization IncidencePointFirstFork IncidencePointShield
open IncidenceReciprocalChoice IncidenceChosenEnds IncidenceLineGateBooking
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
def rank (x : Fin n) := fork C (n+x.val)
def O := Finset.univ.filter (fun x : Fin n=>uses C (n+x.val)=1)
def hot (x y : Fin n) := (avoid I x y,single x)∈C.wire (rank C x)
noncomputable def D (x : Fin n) : Finset (Fin n) := by
  classical exact Finset.univ.filter fun y=> x∈O C ∧ hot C I x x ∧ y≠x ∧ ¬hot C I x y
noncomputable def M (f : Fin n→Fin n) : Finset (Fin n) := by
  classical exact (O C).filter fun x=>hot C I x x ∧ (D C I x=∅ ∨ removed f (rank C) x)

theorem memD (x y : Fin n) : y∈D C I x ↔ x∈O C ∧ hot C I x x ∧ y≠x ∧ ¬hot C I x y := by
  classical simp [D]

theorem hot_witness (x : Fin n) (h : hot C I x x) :
    ∃W : Finset (Fin n),(∀p∈W,¬I p x) ∧ (bits W,single x)∈C.wire (rank C x) := by
  let W := Finset.univ.filter (fun p=>¬I p x)
  have eq : bits W=avoid I x x := by funext p; simp [W,bits,avoid]
  exact ⟨W,fun p hp=>(Finset.mem_filter.mp hp).2,eq ▸ h⟩

theorem choice (pos : flags C I) (neg : negatives C I n 2)
    (degree : ∀l,Fintype.card {p // I p l}=402) (join : ∀p r,p≠r→∃!l,I p l∧I r l) :
    ∃ f,Valid (D C I) f ∧
      (∀x,removed f (rank C) x → ∀y∈D C I x,f y=x ∧ rank C y<rank C x ∧ ¬removed f (rank C) y) := by
  apply bad_precedes
  · intro x h
    exact ((memD C I x x).mp h).2.2.1 rfl
  · intro x y ne hx _
    obtain ⟨a,mem⟩ := hx
    obtain ⟨W,good,active⟩ := hot_witness C I x ((memD C I x a).mp mem).2.1
    exact IncidenceWarmForkSeparation.lines_distinct I C pos neg degree join x y ne W good active

theorem cold (f : Fin n→Fin n) (v : Valid (D C I) f) (x : Fin n) (hc : x∈O C \ M C I f) :
    ¬hot C I x (f x) := by
  classical
  obtain ⟨owner,unedited⟩ := Finset.mem_sdiff.mp hc
  by_cases has : (D C I x).Nonempty
  · have choose : f x∈D C I x := by simpa [has] using v x
    exact ((memD C I x (f x)).mp choose).2.2.2
  · have same : f x=x := by simpa [has] using v x
    rw [same]
    intro h
    exact unedited (Finset.mem_filter.mpr ⟨owner,h,Or.inl (Finset.not_nonempty_iff_eq_empty.mp has)⟩)

theorem separated (pos : flags C I) (neg : negatives C I n 2)
    (degree : ∀l,Fintype.card {p // I p l}=402) (join : ∀p r,p≠r→∃!l,I p l∧I r l)
    (f : Fin n→Fin n) (valid : Valid (D C I) f) (x y : Fin n)
    (hx : x∈O C \ M C I f) (hy : y∈O C \ M C I f) (ne : x≠y) (xy : f x=y) : f y≠x := by
  classical
  intro yx
  have has (a b : Fin n) (ab : a≠b) (fb : f a=b) : b∈D C I a := by
    by_cases h : (D C I a).Nonempty
    · simpa [h,fb] using valid a
    · have eq : f a=a := by simpa [h] using valid a
      exact False.elim (ab (eq.symm.trans fb))
  have h1 := (memD C I x y).mp (has x y ne xy)
  have h2 := (memD C I y x).mp (has y x ne.symm yx)
  obtain ⟨W,good,active⟩ := hot_witness C I x h1.2.1
  have diff := IncidenceWarmForkSeparation.lines_distinct I C pos neg degree join x y ne W good active
  have non (z : Fin n) (h : z∈O C \ M C I f) (active : hot C I z z) : ¬removed f (rank C) z := by
    intro r
    exact (Finset.mem_sdiff.mp h).2 (Finset.mem_filter.mpr ⟨(Finset.mem_sdiff.mp h).1,active,Or.inr r⟩)
  by_cases before : rank C y<rank C x
  · exact non x hx h1.2.1 ⟨by rw [xy]; exact ne.symm,by rw [xy,yx],by simpa [xy] using before⟩
  · have later : rank C x<rank C y := by change rank C x≠rank C y at diff; omega
    exact non y hy h2.2.1 ⟨by rw [yx]; exact ne,by rw [yx,xy],by simpa [yx] using later⟩
end IncidenceActualLineChoice
