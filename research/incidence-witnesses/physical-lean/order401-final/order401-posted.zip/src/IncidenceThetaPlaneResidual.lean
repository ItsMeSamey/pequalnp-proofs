import IncidenceThetaProtected
import IncidenceThetaPencil
namespace IncidenceThetaPlaneResidual
open SparseIncidence IncidenceStartNormalization IncidenceHoistPrune IncidenceThetaBatchHoist IncidenceThetaRestrict
open IncidenceThetaProtected
variable {n q : ℕ}
theorem plane (I : Fin n→Fin n→Prop) [DecidableRel I] (degree : ∀l,Fintype.card {u // I u l}=q+1)
    (join : ∀a b,a≠b → ∃! l,I a l ∧ I b l) (hq : 0<q) (hn : n=q^2+q+1)
    (x Y : Fin n) (xy : ¬I x Y) :
    ∃ P₀ L₀ : Finset (Fin n),P₀.card=q+2 ∧ L₀.card=q+2 ∧
      ∀ A B : Finset (Fin n),P₀⊆A → L₀⊆B →
      (∀u∈A,2<(N (rel I A B) false u).card) → (∀v∈B,2<(N (rel I A B) true v).card) →
      ∀C : Circuit n,binary C → flags C (rel I A B) → negatives C (rel I A B) 3 3 →
      2*(A.card+B.card)≤C.size+4 := by
  classical
  obtain ⟨p,l,xp,ly,xl,pl,py,pdom,ldom⟩ := IncidenceThetaPencil.pencil I degree join hq hn x Y xy
  refine ⟨coreSites x p,coreSites Y l,countSites x p xp,countSites Y l (fun i=>(ly i).symm),?_⟩
  intro A B pa lb dep del C bin flag neg
  have xA := pa (Finset.mem_insert_self ..)
  have YB := lb (Finset.mem_insert_self ..)
  have pi (i) : p i∈A := pa (Finset.mem_insert_of_mem (Finset.mem_image.mpr ⟨i,Finset.mem_univ _,rfl⟩))
  have li (i) : l i∈B := lb (Finset.mem_insert_of_mem (Finset.mem_image.mpr ⟨i,Finset.mem_univ _,rfl⟩))
  have co (side : Bool) (u v : Fin n) (ne : u≠v) : (N (rel I A B) side u∩N (rel I A B) side v).card≤1 := by
    have sub (w) : N (rel I A B) side w⊆N I side w := by
      cases side <;> intro j h <;> simp [N] at h ⊢ <;> exact h.2.2
    apply (Finset.card_le_card (Finset.inter_subset_inter (sub u) (sub v))).trans
    cases side
    · exact IncidenceRobust.line_overlap I join ne
    · exact IncidenceRobust.point_overlap I join ne
  obtain ⟨K,kle,kbin,live,eq,_⟩:=prune C bin
  have kflag : flags K (rel I A B) := fun a b h=>eq ▸ flag a b h
  have kneg : negatives K (rel I A B) 3 3 := by intro a b ha hb hh; rw [eq]; exact neg a b ha hb hh
  have z:=baseline K (rel I A B) A B x Y p l (0 : Fin (q+1)) kbin live kflag kneg pa lb xp ly
    (fun h=>xy h.2.2) (fun i=>⟨xA,li i,xl i⟩) (fun i=>⟨pi i,li i,pl i⟩)
    (fun i=>⟨pi i,YB,py i⟩)
    (fun u hu un=>by obtain ⟨i,h⟩:=pdom u un; exact ⟨i,hu,li i,h⟩)
    (fun v hv vn=>by obtain ⟨i,h⟩:=ldom v vn; exact ⟨i,pi i,hv,h⟩)
    dep del co
  omega
theorem order401 {n : ℕ} (I : Fin n→Fin n→Prop) [DecidableRel I]
    (degree : ∀l,Fintype.card {u // I u l}=402)
    (join : ∀a b,a≠b → ∃! l,I a l ∧ I b l) (hn : n=161203) :
    ∃ P₀ L₀ : Finset (Fin n),P₀.card=403 ∧ L₀.card=403 ∧
      ∀ A B : Finset (Fin n),P₀⊆A → L₀⊆B →
      (∀u∈A,2<(N (rel I A B) false u).card) → (∀v∈B,2<(N (rel I A B) true v).card) →
      ∀C : Circuit n,binary C → flags C (rel I A B) → negatives C (rel I A B) 3 3 →
      2*(A.card+B.card)≤C.size+4 := by
  classical
  let Y : Fin n := ⟨0,by omega⟩
  have existsx : ∃x,¬I x Y := by
    by_contra! all
    have setEq : IncidenceRobust.points I Y=Finset.univ := by
      ext u
      simp [IncidenceRobust.points,all]
    have nc := IncidenceRobust.points_card (q:=401) I degree Y
    rw [setEq,Finset.card_univ,Fintype.card_fin] at nc
    omega
  obtain ⟨x,xy⟩:=existsx
  exact plane (q:=401) I degree join (by decide) (by omega) x Y xy

#print axioms order401
#print axioms plane
end IncidenceThetaPlaneResidual
