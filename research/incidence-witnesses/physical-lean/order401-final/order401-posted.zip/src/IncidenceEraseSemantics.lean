import IncidenceCleanupGate
namespace IncidenceCleanupGate
open CircuitRewire

/-- If a physical row agrees with one earlier wire throughout the supplied
domain, erasing that single row preserves the same domain and a translated
observer, also when the observer is the erased row or either pin is tied. -/
theorem erase_semantics {Z : Type*} (m s k replacement o : ℕ) (g : ℕ→Gate)
    (X : ℕ→Set Z) (ks : k<s) (repl : replacement<m+k) (ob : o<m+s)
    (ord : ∀ j<s,(g j).left<m+j ∧ (g j).right<m+j)
    (sem : ∀ j<s,X (m+j)=(g j).eval X) (equal : X (m+k)=X replacement) :
    let h := eraseGate m k replacement g
    let obs := rewire m k replacement o
    obs<m+(s-1) ∧ ∃ Y : ℕ→Set Z,(∀ i<m,Y i=X i) ∧
      (∀ j<s-1,(h j).left<m+j ∧ (h j).right<m+j ∧ Y (m+j)=(h j).eval Y) ∧ Y obs=X o := by
  let Y := fun i=>if i<m+k then X i else X (i+1)
  have transport (i : ℕ) : Y (rewire m k replacement i)=X i := by
    by_cases lo : i<m+k
    · simp [Y,rewire,lo]
    · by_cases eq : i=m+k
      · subst i; simp [Y,rewire,repl,equal]
      · have high : ¬ i-1<m+k := by omega
        simp [Y,rewire,lo,eq,high,show i-1+1=i by omega]
  refine ⟨?_,Y,fun i hi=>if_pos (by omega),?_,transport o⟩
  · unfold rewire
    split <;> (try split) <;> omega
  · intro j hj
    let a := original k j
    have ja : a<s := by dsimp [a,original]; split <;> omega
    have idx : Y (m+j)=X (m+a) := by
      by_cases lo : j<k
      · simp [Y,a,original,lo,show m+j<m+k by omega]
      · simp [Y,a,original,lo,show ¬m+j<m+k by omega,Nat.add_assoc]
    have back (i : ℕ) (hi : i<m+a) : rewire m k replacement i<m+j := by
      dsimp [a,original] at hi
      unfold rewire
      split <;> (try split) <;> split_ifs at hi <;> omega
    refine ⟨back _ (ord a ja).1,back _ (ord a ja).2,?_⟩
    rw [idx,sem a ja]
    change (g a).op.eval (X (g a).left) (X (g a).right) =
      (g a).op.eval (Y (rewire m k replacement (g a).left)) (Y (rewire m k replacement (g a).right))
    rw [transport,transport]

end IncidenceCleanupGate
