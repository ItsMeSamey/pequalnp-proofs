import IncidencePointShield
namespace IncidencePointEditedDomination
open CircuitRewire IncidencePointShield
def act (g : Gate) (v : Nat→Prop) : Prop :=
  match g.op with
  | .zero => False
  | .copy => v g.left
  | .meet => v g.left ∧ v g.right
  | .join => v g.left ∨ v g.right

/-- Compare the edited run at T against the original at T enlarged by one
owner witness. The unmatched raw is the earlier reciprocal point. All paths
from that raw are blocked at its cold fork. Injection is permitted at any
later row whose value is already true in the enlarged original. -/
theorem dominated (m s : Nat) (code : Nat→Gate) (E B : Nat→Prop)
    (inject : Nat→Prop) (y cut : Nat)
    (ord : ∀a<s,(code a).left<m+a ∧ (code a).right<m+a)
    (raws : ∀j<m,j≠y → E j → B j)
    (atcut : E cut → B cut)
    (es : ∀a<s,E (m+a) → act (code a) E ∨ inject a)
    (bs : ∀a<s,act (code a) B → B (m+a))
    (witness : ∀a<s,inject a → B (m+a))
    (j : Nat) (bound : j<m+s) (blocked : shadow m code y cut s j=false) :
    E j → B j := by
  induction j using Nat.strong_induction_on with
  | ind j ih =>
    by_cases stop : j=cut
    · simpa [stop] using atcut
    by_cases rawj : j<m
    · apply raws j rawj
      intro eq
      rw [raw m s code y cut j rawj] at blocked
      simp [eq,show y≠cut from eq ▸ stop] at blocked
    let a := j-m
    have idx : j=m+a := by dsimp [a]; omega
    have aa : a<s := by omega
    obtain ⟨l,r⟩ := ord a aa
    rw [idx,gate m s code y cut a aa l r] at blocked
    have nc : m+a≠cut := idx ▸ stop
    simp [nc] at blocked
    have hl := ih (code a).left (by omega) (by omega) blocked.1
    have hr := ih (code a).right (by omega) (by omega) blocked.2
    rw [idx]
    intro on
    rcases es a aa on with old|extra
    · apply bs a aa
      cases op : (code a).op <;> simp [act,op] at old ⊢ <;> tauto
    · exact witness a aa extra
#print axioms dominated
end IncidencePointEditedDomination
