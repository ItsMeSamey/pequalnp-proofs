import IncidencePointDeterministicTail
import IncidenceHoistReaders
namespace IncidencePointFirstFork
open IncidenceStartNormalization IncidenceHoistReaders IncidencePointDeterministicTail
variable {n : Nat} (C : Circuit n)

def next (u : Nat) : Option Nat :=
  if u=C.output then none else (reader? C u).map (fun p=>n+n+p.1)

theorem next_bounds {u v : Nat} (h : next C u=some v) :
    u<v ∧ v<n+n+C.size := by
  unfold next at h
  split at h
  · contradiction
  · cases e : reader? C u with
    | none => simp [e] at h
    | some p =>
      rcases p with ⟨j,b⟩
      simp only [e,Option.map_some,Option.some.injEq] at h
      subst v
      have mem : (j,b)∈occurrences C u := by
        unfold reader? at e
        split at e
        next _ he =>
          cases e
          simp_all
        next => contradiction
      obtain ⟨bound,eq⟩ := (occurrence_mem C u j b).mp mem
      obtain ⟨l,r⟩ := C.earlier j bound
      cases b <;> simp [operand] at eq <;> omega

def fork (u : Nat) : Nat := match h : next C u with
  | none => u
  | some v => fork v
termination_by n+n+C.size-u
decreasing_by obtain ⟨a,b⟩ := next_bounds C h; omega

theorem tail (u : Nat) : Tail (next C) u (fork C u) := by
  rw [fork]
  split
  next h => exact .stop h
  next v h => exact .pass h (tail v)
termination_by n+n+C.size-u
decreasing_by rename_i h; obtain ⟨a,b⟩ := next_bounds C h; omega

theorem after_read {u v : Nat} (edge : next C u=some v) : fork C u=fork C v :=
  unique (tail C u) (.pass edge (tail C v))

end IncidencePointFirstFork
