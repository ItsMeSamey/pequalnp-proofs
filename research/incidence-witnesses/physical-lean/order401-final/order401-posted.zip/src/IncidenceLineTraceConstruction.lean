import IncidenceLineRouteTree
namespace IncidenceLineTraceConstruction
open IncidenceStartNormalization IncidenceLineRoutedSlots IncidenceLineRouteTree IncidenceLineTrieWeight
variable {n : ℕ} {C : Circuit n} {I : Fin n→Fin n→Prop} {x : Fin n} {safe : Fin C.size→Prop}
inductive View (C : Circuit n) (I : Fin n→Fin n→Prop) (x : Fin n) (safe : Fin C.size→Prop) :
    ℕ → Finset (Fin n) → Prop
  | thin {k S} (small : S.card≤2) : View C I x safe k S
  | unary {k S T} (sub : S⊆T) (v : View C I x safe k T) : View C I x safe k S
  | join {k A B} (g : Fin C.size) (before : g.val<k) (ok : safe g) (op : (C.code g).op=.join)
      (left : ∀p∈A,I p x ∧ hit C (C.code g).left p)
      (right : ∀p∈B,I p x ∧ hit C (C.code g).right p)
      (a : View C I x safe g.val A) (b : View C I x safe g.val B) : View C I x safe k (A∪B)
theorem room {k k' S t z} (h : Routed C I x safe k S t z) (le : k≤k') :
    Routed C I x safe k' S t z := by
  cases h with
  | one _ _ c => exact .one _ _ c
  | two _ _ c => exact .two _ _ c
  | node g before ok op dis left right a b =>
    exact .node g (before.trans_le le) ok op dis left right a b
theorem build {k S} (v : View C I x safe k S) :
    ∀ D : Finset (Fin n), D⊆S → D.Nonempty → ∃ t z, Routed C I x safe k D t z := by
  induction v with
  | thin small =>
    intro D ds hD
    have lo := Finset.card_pos.mpr hD
    have hi := (Finset.card_le_card ds).trans small
    by_cases e : D.card=1
    · exact ⟨_,_,.one _ _ e⟩
    · exact ⟨_,_,.two _ _ (by omega)⟩
  | unary sub _ ih => exact fun D ds ne=>ih D (ds.trans sub) ne
  | @join k A B g before ok op left right va vb ha hb =>
    intro D ds nD
    let U := D∩A
    let V := D\A
    have ua : U⊆A := Finset.inter_subset_right
    have vb : V⊆B := by
      intro i hi
      have om := Finset.mem_sdiff.mp hi
      exact (Finset.mem_union.mp (ds om.1)).resolve_left om.2
    have eq : U∪V=D := by ext i; simp [U,V]
    by_cases u : U.Nonempty
    · obtain ⟨a,z,zu⟩ := ha U ua u
      by_cases w : V.Nonempty
      · obtain ⟨b,t,tv⟩ := hb V vb w
        have d : Disjoint U V := Finset.disjoint_left.mpr (by
          intro i h j; exact (Finset.mem_sdiff.mp j).2 (ua h))
        exact eq ▸ ⟨_,_,Routed.node g before ok op d (fun i h=>left i (ua h))
          (fun i h=>right i (vb h)) zu tv⟩
      · have v0 := Finset.not_nonempty_iff_eq_empty.mp w
        rw [v0,Finset.union_empty] at eq
        exact eq ▸ ⟨_,_,room zu before.le⟩
    · have u0 := Finset.not_nonempty_iff_eq_empty.mp u
      rw [u0,Finset.empty_union] at eq
      obtain ⟨t,z,h⟩ := hb D (eq ▸ vb) nD
      exact ⟨t,z,room h before.le⟩
#print axioms build
end IncidenceLineTraceConstruction
