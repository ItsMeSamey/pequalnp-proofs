import IncidencePointShield
namespace IncidencePointShield
open CircuitRewire
/-- Before the stop, every physical reader of a corridor wire stays in the corridor.
The set may contain several old gates and may include the owner itself. -/
theorem confined (m s x cut : Nat) (code : Nat→Gate) (P : Finset Nat) (start : x∈P)
    (ord : ∀ i<s,(code i).left<m+i ∧ (code i).right<m+i)
    (only : ∀ i<s,m+i≠cut → ((code i).left∈P ∨ (code i).right∈P) → m+i∈P)
    (j : Nat) (bound : j<m+s) (outside : j∉P) :
    shadow m code x cut s j=false := by
  induction j using Nat.strong_induction_on with
  | ind j ih =>
    by_cases low : j<m
    · rw [raw m s code x cut j low]
      have ne : j≠x := fun e=>outside (e ▸ start)
      simp [ne]
    let i := j-m
    have eq : j=m+i := by dsimp [i]; omega
    have hi : i<s := by omega
    obtain ⟨l,r⟩ := ord i hi
    rw [eq,gate m s code x cut i hi l r]
    by_cases stop : m+i=cut
    · simp [stop]
    have ll : (code i).left∉P := fun h=>outside (eq ▸ only i hi stop (Or.inl h))
    have rr : (code i).right∉P := fun h=>outside (eq ▸ only i hi stop (Or.inr h))
    rw [ih _ (by omega) (by omega) ll,ih _ (by omega) (by omega) rr]
    simp

/-- A deterministic successor assigned to every member of a prefix gives the closure
premise directly, even on DAGs with arbitrary fanout outside the prefix. -/
theorem single_readers (m s x cut : Nat) (code : Nat→Gate) (P : Finset Nat) (start : x∈P)
    (ord : ∀ i<s,(code i).left<m+i ∧ (code i).right<m+i)
    (next : Nat→Nat)
    (reader : ∀ w∈P,∀ i<s,(code i).left=w ∨ (code i).right=w → next w=m+i)
    (chain : ∀ w∈P,next w∈P ∨ next w=cut)
    (j : Nat) (bound : j<m+s) (outside : j∉P) : shadow m code x cut s j=false := by
  apply confined m s x cut code P start ord _ j bound outside
  intro i hi stop member
  rcases member with l|r
  · have h := chain _ l
    rw [reader _ l i hi (Or.inl rfl)] at h
    exact h.resolve_right stop
  · have h := chain _ r
    rw [reader _ r i hi (Or.inr rfl)] at h
    exact h.resolve_right stop
#print axioms single_readers
end IncidencePointShield
