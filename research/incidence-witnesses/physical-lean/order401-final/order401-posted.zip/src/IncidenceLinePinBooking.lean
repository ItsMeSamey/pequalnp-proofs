import IncidencePinMultiplicity
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.BigOperators.Group.Finset
namespace IncidenceLinePinBooking
open scoped BigOperators
/-- Book at most one forced gate per experiment even when its owner has many
eligible points. The event sets for different points at one gate must be disjoint. -/
theorem finite_book {Run Gate Label : Type*} [DecidableEq Run] [DecidableEq Gate]
    [DecidableEq Label] (runs : Finset Run) (gates : Finset Gate)
    (labels : Gate→Finset Label) (event : Gate→Label→Finset Run)
    (forced : Run→Finset Gate) (unit : ℕ)
    (multiplicity : ∀g∈gates,∀p∈labels g,unit≤(event g p).card)
    (separate : ∀g∈gates,((labels g:Set Label)).PairwiseDisjoint (event g))
    (sound : ∀ g∈gates,∀p∈labels g,∀r∈event g p,r∈runs ∧ g∈forced r) :
    unit*(∑g∈gates,(labels g).card) ≤ ∑r∈runs,(forced r).card := by
  classical
  let B g := (labels g).biUnion (event g)
  have row (g) (hg : g∈gates) : unit*(labels g).card≤(B g).card := by
    change _≤((labels g).biUnion (event g)).card
    rw [Finset.card_biUnion (separate g hg)]
    calc
      unit*(labels g).card = ∑ _p∈labels g,unit := by simp [Nat.mul_comm]
      _ ≤ _ := Finset.sum_le_sum (multiplicity g hg)
  have inside g (hg : g∈gates) : B g ⊆ runs := by
    intro r hr
    obtain ⟨p,hp,hit⟩ := Finset.mem_biUnion.mp hr
    exact (sound g hg p hp r hit).1
  calc
    _ = ∑g∈gates,unit*(labels g).card := Finset.mul_sum ..
    _ ≤ ∑g∈gates,(B g).card := Finset.sum_le_sum row
    _ = ∑g∈gates,∑r∈runs,if r∈B g then 1 else 0 := by
      apply Finset.sum_congr rfl
      intro g hg
      simp [←Finset.sum_filter,Finset.filter_mem_eq_inter,Finset.inter_eq_right.mpr (inside g hg)]
    _ = ∑r∈runs,∑g∈gates,if r∈B g then 1 else 0 := Finset.sum_comm
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro r hr
      have sub : gates.filter (fun g=>r∈B g)⊆forced r := by
        intro g gh
        obtain ⟨hg,hit⟩ := Finset.mem_filter.mp gh
        obtain ⟨p,hp,hh⟩ := Finset.mem_biUnion.mp hit
        exact (sound g hg p hp r hh).2
      simpa [←Finset.sum_filter] using Finset.card_le_card sub
#print axioms finite_book
end IncidenceLinePinBooking
