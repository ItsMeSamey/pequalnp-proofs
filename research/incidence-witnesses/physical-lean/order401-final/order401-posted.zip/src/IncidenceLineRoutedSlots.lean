import IncidenceLineGateBooking
import IncidenceLineTrieWeight
namespace IncidenceLineRoutedSlots
open IncidenceStartNormalization IncidenceLineGateBooking IncidenceLineTrieWeight SparseIncidence
variable {n : ℕ}
def hit (C : Circuit n) (j : ℕ) (p : Fin n) :=
  (single p,fun _=>false)∈C.wire j

def eligible (C : Circuit n) (I : Fin n→Fin n→Prop) (x : Fin n)
    (g : Fin C.size) (p : Fin n) :=
  (C.code g).op=.join ∧ I p x ∧ hit C (n+n+g) p ∧
  (∃ a, I a x ∧ a≠p ∧ hit C (C.code g).left a) ∧
  (∃ b, I b x ∧ b≠p ∧ hit C (C.code g).right b)

theorem distinct_witness {S : Finset (Fin n)} (two : 2≤S.card) (p : Fin n) :
    ∃ a∈S,a≠p := by
  by_contra! h
  have sub : S⊆{p} := by intro i hi; simpa using h i hi
  have bound := Finset.card_le_card sub
  simp at bound
  omega

theorem physical_join (C : Circuit n) (I : Fin n→Fin n→Prop) (x : Fin n)
    (g : Fin C.size) (op : (C.code g).op=.join)
    (A B : Finset (Fin n)) (distinct : Disjoint A B) (an : A.Nonempty) (bn : B.Nonempty)
    (insideA : ∀ p∈A,I p x ∧ hit C (C.code g).left p)
    (insideB : ∀ p∈B,I p x ∧ hit C (C.code g).right p)
    (p : Fin n) (hp : (p∈A ∧ 2≤A.card) ∨ (p∈B ∧ 2≤B.card)) :
    eligible C I x g p := by
  have law := C.law g g.isLt
  rw [CircuitRewire.Gate.eval,op,CircuitRewire.Op.eval] at law
  rcases hp with ⟨pa,two⟩|⟨pb,two⟩
  · obtain ⟨a,ha,ne⟩ := distinct_witness two p
    obtain ⟨b,hb⟩ := bn
    have ab : b≠p := by rintro rfl; exact Finset.disjoint_left.mp distinct pa hb
    refine ⟨op,(insideA p pa).1,?_,⟨a,(insideA a ha).1,ne,(insideA a ha).2⟩,⟨b,(insideB b hb).1,ab,(insideB b hb).2⟩⟩
    change (single p,fun _=>false) ∈ C.wire _
    rw [law]
    exact Or.inl (insideA p pa).2
  · obtain ⟨b,hb,ne⟩ := distinct_witness two p
    obtain ⟨a,ha⟩ := an
    have ab : a≠p := by rintro rfl; exact Finset.disjoint_left.mp distinct ha pb
    refine ⟨op,(insideB p pb).1,?_,⟨a,(insideA a ha).1,ab,(insideA a ha).2⟩,⟨b,(insideB b hb).1,ne,(insideB b hb).2⟩⟩
    change (single p,fun _=>false) ∈ C.wire _
    rw [law]
    exact Or.inr (insideB p pb).2

#print axioms physical_join
end IncidenceLineRoutedSlots
