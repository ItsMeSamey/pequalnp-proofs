import IncidenceRoundReservations
import IncidenceCleanupLabels
import IncidenceThetaCredits
namespace IncidenceRoundReservations
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceHoistReaders IncidenceOperandLedger
open IncidenceZeroRestriction IncidenceHoistPrune
variable {n : ℕ} (C : Circuit n) (E : Finset ℕ)

theorem protected_meet (V prot : Finset ℕ) (sub : E⊆V\prot)
    (protect : IncidenceLabelHistory.vulnerable (IncidenceCleanupLabels.snap C.size C.code V)⊆prot)
    {x : ℕ} (hx : x∈sole C E) : (C.code (owner C x)).op=.meet := by
  obtain ⟨mem,one⟩ := Finset.mem_filter.mp hx
  obtain ⟨inV,free⟩ := Finset.mem_sdiff.mp (sub mem)
  let snap := IncidenceCleanupLabels.snap C.size C.code V
  have counted : snap.uses x=1 := by
    obtain ⟨hj,port,only⟩ := read_unique C one
    apply Finset.card_eq_one.mpr
    refine ⟨(owner C x,!(reader C x).2),?_⟩
    ext p
    rcases p with ⟨j,b⟩
    have read : IncidenceForwardPins.readPin C.code (j,b)=operand (C.code j) (!b) := by
      cases b <;> rfl
    simp only [Finset.mem_filter,IncidenceSurvivingReads.mem_pins,Finset.mem_singleton,Prod.mk.injEq,read]
    constructor
    · rintro ⟨js,e⟩
      have z := only j js (!b) e
      exact ⟨z.1,by rw [←z.2]; simp⟩
    · rintro ⟨rfl,rfl⟩
      exact ⟨hj,by simpa using port⟩
  have and_ : snap.hasAnd x=true := by
    cases h : snap.hasAnd x
    · exact False.elim (free (protect (Finset.mem_filter.mpr ⟨inV,counted,h⟩)))
    · rfl
  obtain ⟨p,hp⟩ := of_decide_eq_true and_
  obtain ⟨ok,read,kind⟩ := Finset.mem_filter.mp hp
  have jb := (IncidenceSurvivingReads.mem_pins p C.size).mp ok
  have only := (read_unique C one).2.2
  have id : p.1=owner C x := by
    cases b : p.2
    · exact (only _ jb _ (show operand _ true=x by simpa [IncidenceForwardPins.readPin,b,operand] using read)).1
    · exact (only _ jb _ (show operand _ false=x by simpa [IncidenceForwardPins.readPin,b,operand] using read)).1
  simpa only [id] using kind

theorem used_of_edge (I : Fin n→Fin n→Prop) (pos : flags C I) (neg : negatives C I 3 3)
    {x y : ℕ} (edge : adj I x y) : 0<uses C x := by
  have cold (b : Bool) (i : Fin n) : IncidenceHoistWalk.witness b i∉C.wire C.output := by
    cases b
    · have h := singleton_off C I neg (i:=i.val) (by omega)
      simpa [one_mask_p,IncidenceHoistWalk.witness] using h
    · have h := singleton_off C I neg (i:=n+i.val) (by omega)
      simpa [one_mask_l,IncidenceHoistWalk.witness] using h
  obtain ⟨p,l,inc,⟨rfl,_⟩|⟨rfl,_⟩⟩ := edge
  · exact IncidenceThetaCredits.has_use C I cold pos false p l inc
      (IncidenceHoistPrefix.initial C _ _ (IncidenceHoistWalk.owner_hot C false p))
  · exact IncidenceThetaCredits.has_use C I cold pos true l p inc
      (IncidenceHoistPrefix.initial C _ _ (IncidenceHoistWalk.owner_hot C true l))

noncomputable def owned (j : ℕ) : ℕ :=
  if h : ∃ x∈sole C E,owner C x=j then h.choose else 0

theorem owned_spec {j : ℕ} (h : j∈designated C E) :
    owned C E j∈sole C E ∧ owner C (owned C E j)=j := by
  classical
  have e := Finset.mem_image.mp h
  simpa [owned,dif_pos e] using e.choose_spec

theorem private_copy {j : ℕ} (h : j∈designated C E)
    (meet : ∀x∈sole C E,(C.code (owner C x)).op=.meet)
    (high : ∀D⊆E,D.card≤24→∀x∈sole C E,dead C D (sib C x)=false) :
    (owned C E j=(C.code j).left ∨ owned C E j=(C.code j).right) ∧
      ∀ D⊆E,D.card≤24 → (row n D∈C.wire (n+n+j) ↔ row n D∈C.wire (owned C E j)) := by
  classical
  obtain ⟨hx,eq⟩ := owned_spec C E h
  let x := owned C E j
  have ⟨hj,port,_⟩ := read_unique C (Finset.mem_filter.mp hx).2
  rw [eq] at hj port
  have op := meet x hx
  change (C.code (owner C (owned C E j))).op=.meet at op
  rw [eq] at op
  constructor
  · cases b : (reader C x).2 <;> simp [operand,show (reader C (owned C E j)).2=(reader C x).2 from rfl,b] at port <;> tauto
  · intro D hd small
    have v := high D hd small x hx
    change dead C D (sib C (owned C E j))=false at v
    simp [dead,IncidenceZeroRestriction.zeroAt,sib,eq] at v
    rw [C.law j hj]
    cases b : (reader C (owned C E j)).2 <;> simp [operand,b] at port v <;>
      simp [Gate.eval,op,Op.eval,port,v]

end IncidenceRoundReservations
