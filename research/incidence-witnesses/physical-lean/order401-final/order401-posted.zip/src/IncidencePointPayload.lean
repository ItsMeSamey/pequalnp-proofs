import IncidencePointCommon
import IncidencePointSparseLift
import IncidencePointNativeMerge
import IncidencePointCorridor
namespace IncidencePointPayload
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidencePointShield
open IncidencePointWarmMasks IncidencePointBooking IncidencePointCommon IncidencePointCorridor
variable {n : Nat}
def X (C : Circuit n) (j : Nat) : Set (Sparse n) :=
  {T| ((fun _=>false),bits T.val)∈C.wire j}
def B (n j : Nat) : Set (Sparse n) := Subtype.val ⁻¹' lineInputs n j
def pin (n j : Nat) : Option Nat := if j<n then none else some (j-n)

theorem src (C : Circuit n) (i : Nat) (hi : i<n+n) :
    X C i=CircuitRewire.read (B n) (pin n i) := by
  ext T
  by_cases h : i<n
  · let p : Fin n:=⟨i,h⟩
    have input : C.wire i = {z | z.1 p=true} := (C.inputs p).1
    simp [X,pin,h,CircuitRewire.read,input]
  · let l : Fin n:=⟨i-n,by omega⟩
    have idx : i=n+l.val := by dsimp [l]; omega
    change (((fun _=>false),bits T.val)∈C.wire i) ↔ _
    rw [idx,(C.inputs l).2]
    simp [pin,CircuitRewire.read,B,lineInputs,bits,l.isLt,show ¬n+l.val<n by omega]

theorem pin_bound (i : Nat) (hi : i<n+n) : Below n (pin n i) := by
  intro j e
  unfold pin at e
  split at e
  · contradiction
  · cases e; omega

theorem laws (C : Circuit n) (j : Nat) (hj : j<C.size) :
    X C (n+n+j)=(C.code j).eval (X C) := by
  ext T
  change (((fun _=>false),bits T.val)∈C.wire (n+n+j)) ↔ _
  rw [C.law j hj]
  cases op : (C.code j).op <;> simp [X,Gate.eval,Op.eval,op]

theorem guard (C : Circuit n) (I : Fin n→Fin n→Prop)
    (pos : flags C I) (neg : negatives C I 401 400) (x l : Fin n) (on : I x l)
    (j : Nat) (hj : j<C.size) (stop : shadow (n+n) C.code x.val (n+n+j) C.size C.output=false) :
    X C (n+n+j)=∅ := by
  apply Set.eq_empty_iff_forall_notMem.mpr
  intro T
  exact foreign_zero I C pos neg x l on _ (by omega) stop T.val (T.property.trans (by decide))

theorem fork_product (C : Circuit n) (I : Fin n→Fin n→Prop) (bin : binary C)
    (pos : flags C I) (neg : negatives C I 401 400) (x l : Fin n) (on : I x l) (cut : Nat)
    (p : Path (n+n) C.code x.val cut) (ok : p.check C.output x.val C.size) (T : Sparse n) :
    mask {x} T.val∈C.wire cut ↔ T∈active (X C) p.factors := by
  let u : Input n := ((fun _=>false),bits T.val)
  let v : Input n := (single x,bits T.val)
  have q := product C.size C.wire C.earlier bin C.law x.val C.output u v
    (change_one C x _) p
    (fun i hi h=>foreign_zero I C pos neg x l on (n+n+i) (by omega) h T.val (by have := T.property; omega)) ok
  have raw : v∈C.wire x.val := by simp [v,(C.inputs x).1,single]
  have one : bits {x}=single x := by funext i; simp [bits,single]
  simpa [IncidencePointWarmMasks.mask,one,u,v,active,X,raw] using q

#print axioms fork_product
end IncidencePointPayload
