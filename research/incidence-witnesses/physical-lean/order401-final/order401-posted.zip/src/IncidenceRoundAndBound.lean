import IncidenceRoundNoExtraPhysical
import IncidenceRoundBigMeets
import IncidenceRoundAndMass
import IncidenceRoundSigPayments
namespace IncidenceRoundAndBound
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceHoistPrune IncidenceDenseSignature
open IncidenceRoundReservations IncidenceAllowedGeometry IncidencePhysicalPaidRound IncidenceRoundDenseSignature
open IncidenceThetaRoundDriver IncidenceThetaRestrict IncidenceThetaBatchHoist IncidenceMarkTransition
open IncidencePhysicalOrGroups IncidenceRoundAndMass IncidenceRoundNoExtraPhysical
variable {n : ℕ} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)}
variable (a : Stage I P L) (M : Finset ℕ) (G : ℕ→Finset ℕ) (prot : Finset ℕ)
local notation "E" => kept a.A a.B \ prot
def rows (C : Circuit n) (e : Finset ℕ) := (Finset.univ : Finset (Row C)).filter (fun j=>j.val∈designated C e)

theorem bound (live : Live a.C) (hasCore : P.Nonempty)
    (safe : Safe (neighbors I) (kept a.A a.B) M G)
    (core : kept P L⊆prot) (guards : reserve M G⊆prot)
    (protect : IncidenceLabelHistory.vulnerable (IncidenceCleanupLabels.snap a.C.size a.C.code (kept a.A a.B))⊆prot)
    (stop : ¬IncidenceRoundPhysicalMove.Witness a E) :
    25*(meets a.C).card ≤25*(rows a.C E).card+2*(n+n)+25*(excess a.C+rawExtra a.C (kept a.A a.B)+2*prot.card) ∧
    ∃sig : ℕ→Sig ℕ,(∀i<n+n,sig i=inputSig E i) ∧
      ∀j<a.C.size,(a.C.code j).op=.meet → j∉designated a.C E →
        sig (a.C.code j).left=none ∧ sig (a.C.code j).right=none := by
  classical
  obtain ⟨pr,eq,shared,twice⟩ := bundle a M G prot live hasCore safe core guards protect stop
  obtain ⟨sig,spec,raw,join,privateEq,both⟩ :=
    IncidenceRoundDenseSignature.physical a.C E a.bin (des a.C E) (owned a.C E) pr eq
  have unbr := IncidenceRoundSigPayments.unbranched a.C E sig spec (fun j hj use D de sz=>by
    have h := shared D de sz j hj use
    simpa [dead,IncidenceZeroRestriction.zeroAt] using h)
  have info (j : ℕ) (hj : j<a.C.size) (meet : (a.C.code j).op=.meet) (d : des a.C E j=true) :
      (owned a.C E j=(a.C.code j).left ∨ owned a.C E j=(a.C.code j).right) ∧
        owned a.C E j∈sole a.C E ∧ owned a.C E j<n+n ∧ sig (n+n+j)=sig (owned a.C E j) := by
    have jj : j∈designated a.C E := of_decide_eq_true d
    have h := (owned_spec a.C E jj).1
    exact ⟨(pr j hj meet d).1,h,Finset.mem_range.mp (kept_range a.A a.B
      (Finset.mem_sdiff.mp (Finset.mem_filter.mp h).1).1),privateEq j hj meet d⟩
  have large := IncidenceRoundBigMeets.physical a E stop a.bin sig (des a.C E) (owned a.C E)
    raw unbr join info both
  have large' (j : ℕ) (hj : j<a.C.size) (meet : (a.C.code j).op=.meet) (d : j∉designated a.C E) :=
    large j hj meet (by simp [des,d])
  refine ⟨?_,sig,raw,large'⟩
  refine IncidenceRoundAndMass.physical a.C sig (kept a.A a.B) prot (rows a.C E) live
    (kept_range a.A a.B) ?_ (IncidenceRoundSigPayments.raw_mass a.C E sig raw twice) ?_ ?_ ?_
  · intro i hi hp
    rw [raw i (Finset.mem_range.mp (kept_range a.A a.B hi))]
    simp [inputSig,hi,hp]
  · intro j hj small
    rw [IncidencePinLowLedger.fan_uses]
    exact_mod_cast unbr j hj small
  · exact IncidenceRoundSigPayments.all_modes a.C sig _ _ a.bin join
      (fun j hj hm hd=>⟨(pr j hj hm hd).1,privateEq j hj hm hd⟩)
      (fun j hj hm hd=>(both j hj hm hd).1)
  · intro j hm hd
    apply large' j j.isLt (Finset.mem_filter.mp hm).2
    simpa [rows] using hd

#print axioms bound
end IncidenceRoundAndBound
