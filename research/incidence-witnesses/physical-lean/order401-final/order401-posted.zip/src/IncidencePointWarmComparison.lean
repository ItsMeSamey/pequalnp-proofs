import IncidencePointEditedDomination
import IncidenceWarmReadback
namespace IncidencePointWarmComparison
open CircuitRewire IncidencePointShield IncidencePointEditedDomination IncidenceWarmCompiler
variable {Z : Type*} {m s : Nat} (code : Nat→Gate) (B : Nat→Set Z) (drop : Finset Nat)
  (fork : Nat→Option Nat) (ord : ∀j<s,(code j).left<m+j ∧ (code j).right<m+j)
  (pins : ∀j<s,∀x,fork j=some x → x<m) (law : ∀j<s,B (m+j)=(code j).eval B)
local notation "E" => editedWire m s B code drop fork

theorem eval_mem (g : Gate) (Y : Nat→Set Z) (z : Z) :
    z∈g.eval Y ↔ act g (fun i=>z∈Y i) := by
  cases h : g.op <;> simp [Gate.eval,Op.eval,act,h]

include ord pins law
theorem ordinary (u v : Z) (limit : Nat)
    (inputs : ∀i<m,i∉drop → u∈B i → v∈B i)
    (hot : ∀a<s,m+a≤limit → u∈CircuitRewire.read B (fork a) → v∈B (m+a))
    (j : Nat) (bd : j<m+s) (early : j≤limit) : u∈E j → v∈B j := by
  induction j using Nat.strong_induction_on with
  | ind j ih =>
    by_cases raw : j<m
    · rw [editedInput _ _ _ _ _ _ _ raw]
      split
      next h => simp
      next h => exact inputs j raw h
    let a:=j-m
    have eq : j=m+a := by dsimp [a]; omega
    have ha : a<s := by omega
    obtain ⟨l,r⟩ := ord a ha
    have hl := ih (code a).left (by omega) (by omega) (by omega)
    have hr := ih (code a).right (by omega) (by omega) (by omega)
    rw [eq,editedRow _ _ _ _ _ _ ord pins a ha]
    rintro (old|inj)
    · rw [law a ha,eval_mem]
      rw [eval_mem] at old
      cases op : (code a).op <;> simp [act,op] at old ⊢ <;> tauto
    · exact hot a ha (by omega) inj

theorem reciprocal (u singleY enlargedX : Z) (y cut out : Nat) (bd : out<m+s)
    (cb : cut<m+s) (shielded : shadow m code y cut s out=false)
    (before : ∀i<m,i∉drop → u∈B i → singleY∈B i)
    (noEarly : ∀a<s,m+a≤cut → u∉CircuitRewire.read B (fork a))
    (cold : singleY∉B cut)
    (away : ∀i<m,i≠y → i∉drop → u∈B i → enlargedX∈B i)
    (hot : ∀a<s,u∈CircuitRewire.read B (fork a) → enlargedX∈B (m+a))
    (neg : enlargedX∉B out) : u∉E out := by
  apply mt _ neg
  apply dominated m s code (fun j=>u∈E j) (fun j=>enlargedX∈B j)
    (fun a=>u∈CircuitRewire.read B (fork a)) y cut ord _ _ _ _ hot out bd shielded
  · intro i hi ne
    rw [editedInput _ _ _ _ _ _ _ hi]
    split
    next => simp
    next h => exact away i hi ne h
  · intro fired
    exact False.elim (cold (ordinary code B drop fork ord pins law u singleY cut before
      (fun a ha h e=>False.elim (noEarly a ha h e)) cut cb le_rfl fired))
  · intro a ha
    rw [editedRow _ _ _ _ _ _ ord pins a ha]
    exact fun h=>h.imp (eval_mem _ _ _).mp id
  · intro a ha
    rw [law a ha,eval_mem]
    exact id

theorem flag (z : Z) (x cut out : Nat) (bd : out<m+s)
    (away : ∀i<m,i≠x → z∈B i → i∉drop)
    (on : z∈E cut) (shielded : shadow m code x cut s out=false) :
    z∈B out → z∈E out := by
  apply dominated m s code (fun j=>z∈B j) (fun j=>z∈E j) (fun _=>False)
    x cut ord _ (fun _=>on) _ _ (fun _ _ h=>False.elim h) out bd shielded
  · intro i hi ne old
    rw [editedInput _ _ _ _ _ _ _ hi,if_neg (away i hi ne old)]
    exact old
  · intro a ha h
    left
    apply (eval_mem _ _ _).mp
    rwa [←law a ha]
  · intro a ha h
    rw [editedRow _ _ _ _ _ _ ord pins a ha]
    exact Or.inl ((eval_mem _ _ _).mpr h)
#print axioms reciprocal
#print axioms flag
end IncidencePointWarmComparison
