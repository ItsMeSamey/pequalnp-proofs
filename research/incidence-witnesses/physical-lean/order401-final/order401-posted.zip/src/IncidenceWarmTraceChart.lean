import IncidenceWarmTracePath
import IncidencePointCommon
namespace IncidenceWarmTraceChart
open IncidenceStartNormalization IncidencePointFirstFork IncidenceWarmTracePath
variable {n : Nat} (C : Circuit n) (G : Finset Nat)

def rows (w : Nat) : List G :=
  match h : next C w with
  | none => []
  | some v =>
    if mem : v-(n+n)∈G then ⟨v-(n+n),mem⟩::rows v else rows v
termination_by n+n+C.size-w
decreasing_by all_goals obtain ⟨a,b⟩ := next_bounds C ‹next C _=some _›; omega

def successor (u : G) := (rows C G (n+n+u.val)).head?

theorem after (w v : Nat) (h : next C w=some v) :
    rows C G w=(if mem : v-(n+n)∈G then ⟨v-(n+n),mem⟩::rows C G v else rows C G v) := by
  rw [rows]
  split
  next q => rw [h] at q; contradiction
  next t q => rw [h] at q; cases q; rfl

theorem no_more (w : Nat) (h : next C w=none) : rows C G w=[] := by
  rw [rows]
  split
  next => rfl
  next t q => rw [h] at q; contradiction

theorem head_suffix (w : Nat) (u : G) (t : List G) (h : rows C G w=u::t) :
    w<n+n+u.val ∧ t=rows C G (n+n+u.val) := by
  cases step : next C w with
  | none => rw [no_more C G w step] at h; contradiction
  | some v =>
    obtain ⟨j,b,rfl,_,_,_⟩ := read_step C step
    rw [after C G _ _ step] at h
    simp only [Nat.add_sub_cancel_left] at h
    by_cases mem : j∈G
    · rw [dif_pos mem] at h
      cases h
      exact ⟨(next_bounds C step).1,rfl⟩
    · rw [dif_neg mem] at h
      obtain ⟨lt,eq⟩ := head_suffix (n+n+j) u t h
      exact ⟨(next_bounds C step).1.trans lt,eq⟩
termination_by n+n+C.size-w
decreasing_by obtain ⟨a,b⟩ := next_bounds C step; omega

theorem later (u v : G) (h : successor C G u=some v) : u.val<v.val := by
  unfold successor at h
  cases eq : rows C G (n+n+u.val) with
  | nil => simp [eq] at h
  | cons a t =>
    have same : a=v := by simpa [eq] using h
    subst v
    have lt := (head_suffix C G _ a t eq).1
    omega

theorem factors (sib : G→Nat) (u : G) :
    IncidencePointCommon.factors G sib (successor C G) (later C G) u =
      sib u::(rows C G (n+n+u.val)).map sib := by
  rw [IncidencePointCommon.factors]
  cases eq : rows C G (n+n+u.val) with
  | nil =>
    have stop : successor C G u=none := by simp [successor,eq]
    congr 1
    split
    next => rfl
    next z h => rw [stop] at h; contradiction
  | cons v t =>
    have move : successor C G u=some v := by simp [successor,eq]
    have tail := (head_suffix C G _ v t eq).2
    congr 1
    split
    next h => rw [move] at h; contradiction
    next z h =>
      rw [move] at h
      cases h
      simpa [tail] using factors sib v
termination_by (IncidencePointSuffix.index G u).val
decreasing_by exact IncidencePointSuffix.reverse_index G u v (later C G u v move)

#print axioms factors
end IncidenceWarmTraceChart
