import IncidenceRoundCompensation
namespace IncidenceRoundReservations
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceOperandLedger IncidenceZeroRestriction
open IncidenceHoistPrune
variable {n : ℕ} (C : Circuit n) (E : Finset ℕ)
theorem dead_step (D : Finset ℕ) (j : ℕ) (hj : j<C.size) :
    dead C D (n+n+j)=deadOut (C.code j).op (dead C D (C.code j).left) (dead C D (C.code j).right) :=
  zeroAt_step C.wire (row n D) _ _ (C.law j hj)

theorem live_nonneg (live : Live C) (D : Finset ℕ) (output : dead C D C.output=false)
    (j : ℕ) (hj : j<C.size) : 0≤(fan C.code C.size (n+n+j)-1)*bit (dead C D (n+n+j)) := by
  cases h : dead C D (n+n+j)
  · simp [bit]
  · have ne : n+n+j≠C.output := by intro e; simp [e,output] at h
    have used := IncidencePinLowLedger.ancestor_port (live j hj) ne
    simp only [bit,ite_true,mul_one,IncidencePinLowLedger.fan_uses]
    omega

theorem no_extra_mask (bin : binary C) (live : Live C)
    (eligible : E⊆Finset.range (n+n)) (positive : ∀x∈E,0<uses C x)
    (meet : ∀x∈sole C E,(C.code (owner C x)).op=.meet)
    (high : ∀D⊆E,D.card≤24→∀x∈sole C E,dead C D (sib C x)=false)
    {D : Finset ℕ} (de : D⊆E) (sz : D.card≤24) (out : dead C D C.output=false)
    (init : ℕ→Option ℕ) (input : ∀i<n+n,(init i).isNone=dead C D i)
    (stop : (C.size:ℤ)-(compileLiteral (n+n) (n+n) C.code init C.size).size≤2*(D.card:ℤ)) :
    (∀j<C.size,j∉designated C E → oneAnd (dead C D) (C.code j)=0) ∧
    (∀j<C.size,2≤uses C (n+n+j)→dead C D (n+n+j)=false) := by
  classical
  let S := D∩sole C E
  have hs {x} (h : x∈S) : x∈sole C E := (Finset.mem_inter.mp h).2
  have rq {x} (hx : x∈S) := reserve C eligible meet (high D de sz) (hs hx)
  have h := IncidenceNoExtra.literal (n+n) (n+n) C.size C.code init (dead C D) input
    (fun j hj=>⟨(C.earlier j hj).1,(C.earlier j hj).2,bin j hj⟩) (dead_step C D)
    D S (owner C) Finset.inter_subset_left (de.trans eligible) (fun i hi=>raw_flag C hi D)
    ((owner_inj C eligible meet high).mono (show (↑S:Set ℕ)⊆↑(sole C E) from fun _ h=>hs h))
    (fun x hx=>by rw [IncidencePinLowLedger.fan_uses,(Finset.mem_filter.mp (hs hx)).2]; decide)
    (fun x hx=>by
      obtain ⟨xd,ns⟩ := Finset.mem_sdiff.mp hx
      have xe := de xd
      have pos := positive x xe
      have ne : uses C x≠1 := fun eq=>ns (Finset.mem_inter.mpr ⟨xd,Finset.mem_filter.mpr ⟨xe,eq⟩⟩)
      rw [IncidencePinLowLedger.fan_uses]; omega)
    (fun j hj=>by obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hj; exact Finset.mem_range.mpr (rq hx).1)
    (fun j hj=>by
      obtain ⟨x,hx,rfl⟩:=Finset.mem_image.mp hj
      have xd := (Finset.mem_inter.mp hx).1
      have low := (raw_flag C (Finset.mem_range.mp (eligible (de xd))) D).2 xd
      obtain ⟨_,op,z⟩ := rq hx
      rcases z with ⟨p,q⟩|⟨p,q⟩ <;> simp [oneAnd,op,p,q,low])
    (live_nonneg C live D out) stop
  refine ⟨?_,?_⟩
  · intro j hj no
    apply h.1 j hj
    intro mem
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp mem
    exact no (Finset.mem_image.mpr ⟨x,hs hx,rfl⟩)
  · intro j hj many
    apply h.2 j hj
    rw [IncidencePinLowLedger.fan_uses]
    exact_mod_cast many

theorem singleton_fan (bin : binary C) (live : Live C) {x : ℕ} (hx : x<n+n)
    (out : dead C {x} C.output=false) (init : ℕ→Option ℕ)
    (input : ∀i<n+n,(init i).isNone=dead C {x} i)
    (cap : (C.size:ℤ)-(compileLiteral (n+n) (n+n) C.code init C.size).size≤2) : uses C x≤2 := by
  have ord (j : ℕ) (hj : j<C.size) : OrderedBinary (C.code j) (n+n+j) :=
    ⟨(C.earlier j hj).1,(C.earlier j hj).2,bin j hj⟩
  have total := savings (n+n) (n+n) C.size C.code init (dead C {x}) input ord (dead_step C {x})
  have sub : ({x}:Finset ℕ)⊆Finset.range (n+n) := by simpa using hx
  rw [IncidenceNoExtra.raw_sum {x} (n+n) _ _ sub (fun i hi=>raw_flag C hi {x})] at total
  simp only [Finset.sum_singleton,IncidencePinLowLedger.fan_uses] at total
  have inside := Finset.sum_nonneg (s:=Finset.range C.size)
    (fun j hj=>live_nonneg C live {x} out j (Finset.mem_range.mp hj))
  have extra : 0≤∑j∈Finset.range C.size,oneAnd (dead C {x}) (C.code j) := by
    apply Finset.sum_nonneg
    intro j _
    unfold oneAnd
    split <;> decide
  simp only [IncidencePinLowLedger.fan_uses] at inside
  omega

theorem equal_dense {D : Finset ℕ} {j : ℕ} (op : (C.code j).op=.meet)
    (one : oneAnd (dead C D) (C.code j)=0) :
    (row n D∈C.wire (C.code j).left ↔ row n D∈C.wire (C.code j).right) := by
  classical
  have h := IncidenceNoExtra.equal_flags _ _ op one
  have he := congrArg (fun b : Bool=>b=false) h
  simpa [dead,IncidenceZeroRestriction.zeroAt] using Iff.of_eq he
end IncidenceRoundReservations
