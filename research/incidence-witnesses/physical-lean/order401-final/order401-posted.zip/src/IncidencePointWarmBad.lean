import IncidencePointWarmMasks
namespace IncidencePointWarmMasks
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmCompiler IncidencePointWarmComparison
variable {n : Nat}
structure Wiring (C : Circuit n) (M : Finset (Fin n)) (f : Nat→Option Nat) (c : Fin n→Nat) : Prop where
  located : ∀j<C.size,∀a,f j=some a → ∃p∈M,p.val=a ∧ c p=n+n+j
  installed : ∀p∈M,∃j<C.size,f j=some p.val ∧ c p=n+n+j

theorem Wiring.pins {C : Circuit n} {M f c} (w : Wiring C M f c) :
    ∀j<C.size,∀a,f j=some a → a<n+n := by
  intro j hj a e
  obtain ⟨p,_,rfl,_⟩ := w.located j hj a e
  have := p.isLt
  omega

theorem Wiring.on_at {C : Circuit n} {M f c} (w : Wiring C M f c)
    (J T : Finset (Fin n)) (j : Nat) (hj : j<C.size)
    (on : mask J T ∈CircuitRewire.read C.wire (f j)) :
    ∃p∈J,p∈M ∧ c p=n+n+j := by
  cases eq : f j with
  | none => simp [eq,CircuitRewire.read] at on
  | some a =>
    obtain ⟨p,hp,rfl,idx⟩ := w.located j hj a eq
    refine ⟨p,?_,hp,idx⟩
    simpa [eq,CircuitRewire.read,(C.inputs p).1,mask,bits] using on

theorem bad_pair (C : Circuit n) (I : Fin n→Fin n→Prop) (M : Finset (Fin n)) (f c)
    (wire : Wiring C M f c) (neg : negatives C I 401 400) (x y : Fin n)
    (sel : x∈M) (keep : y∉M) (before : c y<c x) (bd : c y<n+n+C.size)
    (shielded : shadow (n+n) C.code y.val (c y) C.size C.output=false)
    (T W : Finset (Fin n)) (t2 : T.card≤2) (w199 : W.card≤199)
    (ind : ∀l∈T∪W,¬I x l)
    (cold : mask {y} T∉C.wire (c y)) (live : mask {x} W∈C.wire (c x)) :
    mask {x,y} T∉editedWire (n+n) C.size C.wire C.code (drops M) f C.output := by
  classical
  let J : Finset (Fin n) := {x,y}
  have only {p : Fin n} (pj : p∈J) (pm : p∈M) : p=x := by
    rcases Finset.mem_insert.mp pj with e|h
    · exact e
    · have e := Finset.mem_singleton.mp h
      subst p
      contradiction
  apply reciprocal C.code C.wire (drops M) f C.earlier wire.pins C.law
    (mask J T) (mask {y} T) (mask {x} (T∪W)) y.val (c y) C.output C.output_lt bd shielded
  · intro i hi h
    apply bitInputs C M J T {y} T ∅ _ (by simp) i hi h (by simp)
    intro p pj pm _
    rcases Finset.mem_insert.mp pj with e|h
    · subst p; contradiction
    · exact h
  · intro a aa early active
    obtain ⟨p,pj,pm,idx⟩ := wire.on_at J T a aa active
    rw [only pj pm] at idx
    omega
  · exact cold
  · intro i hi iy h
    apply bitInputs C M J T {x} (T∪W) {y} _ Finset.subset_union_left i hi h
    · simpa using iy
    · intro p pj _ noty
      rcases Finset.mem_insert.mp pj with e|h
      · simp [e]
      · contradiction
  · intro a aa active
    obtain ⟨p,pj,pm,idx⟩ := wire.on_at J T a aa active
    rw [only pj pm] at idx
    rw [←idx]
    apply monotone C (c x) (by omega) _ live
    refine ⟨fun _ h=>h,?_⟩
    intro l hl
    simp [mask,bits] at hl ⊢
    exact Or.inr hl
  · apply negative C I neg (by simp) ((Finset.card_union_le _ _).trans (by omega))
    simpa using ind
#print axioms bad_pair
end IncidencePointWarmMasks
