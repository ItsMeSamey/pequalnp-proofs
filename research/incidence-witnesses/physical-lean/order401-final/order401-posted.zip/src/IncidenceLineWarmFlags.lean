import IncidenceLineWarmMasks
import IncidencePointWarmFlags
namespace IncidenceLineWarm
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmCompiler IncidencePointWarmComparison
variable {n : Nat}

theorem flag_mask (C : Circuit n) (I : Fin n→Fin n→Prop) (M : Finset (Fin n)) (f c)
    (wire : Wiring C M f c) (pos : flags C I) (l p : Fin n) (inc : I p l)
    (sh : l∈M → shadow (n+n) C.code (n+l.val) (c l) C.size C.output=false) :
    (single p,single l)∈editedWire (n+n) C.size C.wire C.code (drops M) f C.output := by
  let z : Input n := (single p,single l)
  let cut := if l∈M then c l else n+l.val
  apply flag C.code C.wire (drops M) f C.earlier wire.pins C.law z (n+l.val) cut C.output C.output_lt
    _ _ _ (pos p l inc)
  · intro i _ ne old drop
    obtain ⟨a,_,rfl⟩ := Finset.mem_image.mp drop
    rw [(C.inputs a).2] at old
    have eq : a=l := by simpa [z,single] using old
    exact ne (congrArg (fun j : Fin n=>n+j.val) eq)
  · by_cases hl : l∈M
    · obtain ⟨j,hj,install,idx⟩ := wire.installed l hl
      simp only [cut,if_pos hl,idx]
      rw [editedRow _ _ _ _ _ _ C.earlier wire.pins j hj]
      right
      simp [install,CircuitRewire.read,(C.inputs l).2,z,single]
    · simp only [cut,if_neg hl]
      rw [editedInput _ _ _ _ _ _ _ (by have := l.isLt; omega)]
      have keep : n+l.val∉drops M := by
        rintro mem
        obtain ⟨a,ha,eq⟩ := Finset.mem_image.mp mem
        exact hl ((Fin.ext (Nat.add_left_cancel eq)) ▸ ha)
      simp [keep,(C.inputs l).2,z,single]
  · by_cases hl : l∈M
    · simpa [cut,hl] using sh hl
    · simpa [cut,hl] using IncidencePointWarmMasks.shadow_raw_cut (n+n) C.size C.code (n+l.val) C.output
#print axioms flag_mask
end IncidenceLineWarm
