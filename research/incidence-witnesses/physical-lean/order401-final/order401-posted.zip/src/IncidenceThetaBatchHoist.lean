import IncidencePinHoistSparse
import IncidenceHoistStage

namespace IncidenceThetaBatchHoist
open IncidenceStartNormalization SparseIncidence CircuitRewire IncidenceHoistWalk IncidenceHoistPrefix IncidenceHoistFlow
open IncidenceHoistCompile IncidenceHoistRealize
variable {n : ℕ} (C : Circuit n)
abbrev Raw (n : ℕ) := Bool × Fin n

/-- The pool physically searches only paths starting at a chosen raw.
Point and line paths are selected in a single edit. -/
def pool (D : List (Raw n)) := D.flatMap fun d=>walk C C.size (IncidenceHoistShield.owner d.1 d.2)
def sel (D : List (Raw n)) (j : ℕ) := ((pool C D).find? (fun e=>decide (e.1=j))).map Prod.snd

theorem source {D : List (Raw n)} {j : ℕ} {b : Bool} (h : sel C D j=some b) :
    ∃ d∈D,(j,b)∈walk C C.size (IncidenceHoistShield.owner d.1 d.2) := by
  unfold sel at h
  cases eq : (pool C D).find? (fun e=>decide (e.1=j)) with
  | none => simp [eq] at h
  | some e =>
    obtain ⟨k,c⟩:=e
    have temp := List.find?_some eq
    have hit := of_decide_eq_true temp
    have mem := List.mem_of_find?_eq_some eq
    simp [eq] at h
    change k=j at hit
    subst k
    subst c
    exact List.mem_flatMap.mp mem

def edited (D : List (Raw n)) := circuit C (sel C D)

theorem bounds (D : List (Raw n))
    (single : ∀d∈D,witness d.1 d.2∉C.wire C.output) :
    C.wire C.output ⊆ (edited C D).wire (edited C D).output ∧
    (edited C D).wire (edited C D).output ⊆ C.wire C.output ∪ lost C.size C.code (sel C D) C.wire := by
  let mode := sel C D
  have op (j : ℕ) (_ : j<C.size) (b : Bool) (h : mode j=some b) : (C.code j).op=.join := by
    obtain ⟨d,hd,path⟩ := source C h
    exact (walk_shields C (single d hd) _ _ _ (initial C _ _ (owner_hot C d.1 d.2)) (j,b) path).1
  have hs := sandwich (n+n) C.size C.wire C.code mode C.earlier C.law op
  rw [show (edited C D).wire (edited C D).output=_ from realize C mode]
  refine ⟨(hs _ C.output_lt).2,?_⟩
  rintro z (old|⟨j,hj,b,hb,hit⟩)
  · exact Or.inl ((hs _ C.output_lt).1 old)
  · obtain ⟨l,r⟩:=C.earlier j hj
    have bound : other (C.code j) b<n+n+C.size := by cases b <;> simp [other] <;> omega
    exact Or.inr ⟨j,hj,b,hb,(hs _ bound).1 hit⟩

def N (I : Fin n→Fin n→Prop) [DecidableRel I] (side : Bool) (x : Fin n) :=
  Finset.univ.filter fun y=>if side then I y x else I x y

@[simp] theorem mask_empty : IncidencePinHoistSparse.mask (∅ : Finset (Fin n))=(fun _=>false) := by
  funext i
  simp [IncidencePinHoistSparse.mask]

def onSide (side : Bool) (P L : Finset (Fin n)) := if side then L else P

/-- A uniform square negative promise on the original circuit supplies every
particular one-neighbor extension required by the physical shield. -/
theorem cold (I : Fin n→Fin n→Prop) [DecidableRel I] (k : ℕ) (D : List (Raw n))
    (neg : ∀ side (s t : Finset (Fin n)),s.card≤k+1 → t.card≤k+1 →
      (∀i∈s,∀y∈t,y∉N I side i) → IncidencePinHoistSparse.view side s t∉C.wire C.output)
    (flags : ∀d∈D,∀y∈N I d.1 d.2,IncidencePinHoistSparse.view d.1 {d.2} {y}∈C.wire C.output)
    (degree : ∀d∈D,k<(N I d.1 d.2).card)
    (over : ∀d∈D,∀i≠d.2,(N I d.1 d.2∩N I d.1 i).card≤1)
    (P L : Finset (Fin n)) (pc : P.card≤k) (lc : L.card≤k)
    (ind : ∀p∈P,∀l∈L,¬I p l) :
    (IncidencePinHoistSparse.mask P,IncidencePinHoistSparse.mask L)∉(edited C D).wire (edited C D).output := by
  have single (d : Raw n) (_ : d∈D) : witness d.1 d.2∉C.wire C.output := by
    have h := neg d.1 {d.2} ∅ (by simp) (by simp) (by simp)
    rcases d with ⟨side,x⟩
    cases side <;> simpa [IncidencePinHoistSparse.view,IncidencePinHoistSparse.mask_single,IncidencePinHoistSparse.mask,witness] using h
  have view (side : Bool) : IncidencePinHoistSparse.view side (onSide side P L) (onSide side L P)=(IncidencePinHoistSparse.mask P,IncidencePinHoistSparse.mask L) := by cases side <;> rfl
  have indep (side : Bool) : ∀i∈onSide side P L,∀y∈onSide side L P,y∉N I side i := by
    cases side <;> simp [onSide,N] <;> aesop
  have size (side : Bool) : (onSide side P L).card≤k ∧ (onSide side L P).card≤k := by cases side <;> simp_all [onSide]
  intro hit
  rcases (bounds C D single).2 hit with old|⟨j,hj,b,hb,high⟩
  · exact neg false P L (by omega) (by omega) (indep false) old
  · obtain ⟨d,hd,path⟩ := source C hb
    obtain ⟨_,_,shield⟩ := walk_shields C (single d hd) _ _ _ (initial C _ _ (owner_hot C d.1 d.2)) (j,b) path
    obtain ⟨l,r⟩:=C.earlier j hj
    have good : other (C.code j) b<n+n+C.size := by cases b <;> simp [other] <;> omega
    have cap := size d.1
    apply IncidencePinHoistSparse.safe C d.1 d.2 _ good shield (N I d.1) (onSide d.1 P L) (onSide d.1 L P)
      (indep d.1) (lt_of_le_of_lt cap.1 (degree d hd)) (over d hd) (flags d hd) _ ((view d.1).symm ▸ high)
    intro y hy h
    apply neg _ _ _ _ _ h
    · exact (Finset.card_le_card (Finset.erase_subset _ _)).trans (by omega)
    · exact (Finset.card_insert_le _ _).trans (by omega)

#print axioms cold
end IncidenceThetaBatchHoist
