import IncidenceEraseSemantics
import IncidenceStartNormalization
namespace IncidencePhysicalOneErase
open IncidenceStartNormalization IncidenceCleanupGate
theorem run {n : ℕ} (C : Circuit n) (bin : binary C) (g : Fin C.size) (old : ℕ)
    (earlier : old<n+n+g.val) (equal : C.wire (n+n+g.val)=C.wire old) :
    ∃ D : Circuit n,binary D ∧ D.wire D.output=C.wire C.output ∧ D.size+1=C.size ∧
      D.code=eraseGate (n+n) g.val old C.code := by
  obtain ⟨ob,Y,inp,rows,ans⟩ := erase_semantics (n+n) C.size g.val old C.output C.code
    C.wire g.isLt earlier C.output_lt C.earlier C.law equal
  let D : Circuit n := {
    size := C.size-1
    output := rewire (n+n) g.val old C.output
    code := eraseGate (n+n) g.val old C.code
    wire := Y
    output_lt := ob
    earlier := fun j hj=>⟨(rows j hj).1,(rows j hj).2.1⟩
    law := fun j hj=>(rows j hj).2.2
    inputs := fun i=>⟨(inp i.val (by omega)).trans (C.inputs i).1,
      (inp (n+i.val) (by omega)).trans (C.inputs i).2⟩ }
  refine ⟨D,?_,ans,?_,rfl⟩
  · intro j hj
    apply bin (original g.val j)
    change j<C.size-1 at hj
    unfold original
    split <;> omega
  · change C.size-1+1=C.size
    have := g.isLt
    omega
end IncidencePhysicalOneErase
