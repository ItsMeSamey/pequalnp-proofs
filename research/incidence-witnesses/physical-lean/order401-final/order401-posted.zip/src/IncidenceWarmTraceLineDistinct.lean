import IncidencePointForeign
namespace IncidenceWarmTraceLineDistinct
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield IncidenceRobust
variable {n : Nat} (I : Fin n→Fin n→Prop) [DecidableRel I] (C : Circuit n)

theorem separate (pos : flags C I) (neg : negatives C I n 2) (x y l : Fin n)
    (outsider : ¬I l x) (hit : I l y) (W : Finset (Fin n)) 
    (clean : ∀a∈W,¬I a x) (cut : Nat) (bound : cut<n+n+C.size)
    (warm : (bits W,single x)∈C.wire cut) :
    shadow (n+n) C.code (n+y.val) cut C.size C.output≠false := by
  intro blocked
  let S := insert l W
  let u : Input n := (bits S,bits {x})
  let v : Input n := (bits S,bits {x,y})
  have up : Extends (bits W,single x) u := by
    refine ⟨fun i h=>?_,fun i h=>?_⟩
    · simpa [u,bits,S] using (Finset.mem_insert_of_mem (by simpa [bits] using h : i∈W) : i∈insert l W)
    · simpa [u,bits,single] using h
  have grow : Extends u v := by
    refine ⟨fun _ h=>h,fun i h=>?_⟩
    have eq : i=x := by simpa [u,bits] using h
    simp [v,bits,eq]
  have first := monotone C cut bound up warm
  have second := monotone C cut bound grow first
  have raw (i : Nat) (hi : i<n+n) (ne : i≠n+y.val) : u∈C.wire i ↔ v∈C.wire i := by
    by_cases low : i<n
    · let p : Fin n := ⟨i,low⟩
      rw [(C.inputs p).1]
      rfl
    · let a : Fin n := ⟨i-n,by omega⟩
      have eq : i=n+a.val := by dsimp [a]; omega
      have diff : a≠y := fun h=>ne (eq.trans (congrArg (fun t : Fin n=>n+t.val) h))
      rw [eq,(C.inputs a).2]
      change bits {x} a=true ↔ bits {x,y} a=true
      simp [bits,diff]
  have same := shield (n+n) C.size C.code C.wire C.earlier C.law (n+y.val) cut u v raw
    ⟨fun _=>second,fun _=>first⟩ C.output C.output_lt blocked
  have no : u∉C.wire C.output := by
    apply neg
    · exact (Fintype.card_subtype_le _).trans_eq (Fintype.card_fin n)
    · change Fintype.card {a // bits {x} a=true}≤2
      rw [bits_card]; simp
    · intro a p ha hp
      have px : p=x := by simpa [u,bits] using hp
      subst p
      have mem : a=l ∨ a∈W := by simpa [u,bits,S] using ha
      rcases mem with rfl|old
      · exact outsider
      · exact clean a old
  apply no (same.mpr _)
  apply monotone C C.output C.output_lt _ (pos l y hit)
  refine ⟨fun i h=>?_,fun i h=>?_⟩
  · have eq : i=l := by simpa [single] using h
    simp [v,bits,S,eq]
  · have eq : i=y := by simpa [single] using h
    simp [v,bits,eq]

#print axioms separate
end IncidenceWarmTraceLineDistinct
