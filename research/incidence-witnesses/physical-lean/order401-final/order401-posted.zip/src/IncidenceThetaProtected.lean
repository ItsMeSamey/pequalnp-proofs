import IncidenceThetaCore
namespace IncidenceThetaProtected
open SparseIncidence IncidenceStartNormalization IncidenceHoistPrune IncidenceThetaBatchHoist IncidenceThetaRestrict IncidenceThetaPaid
variable {n q : ℕ}
def coreSites (x : Fin n) (p : Fin q ↪ Fin n) := insert x (Finset.univ.image p)
theorem countSites (x : Fin n) (p : Fin q ↪ Fin n) (xp : ∀i,x≠p i) : (coreSites x p).card=q+1 := by
  unfold coreSites
  have out : x∉Finset.univ.image p := by
    intro h
    obtain ⟨i,_,e⟩:=Finset.mem_image.mp h
    exact xp i e.symm
  rw [Finset.card_insert_of_notMem out,Finset.card_image_of_injective _ p.injective]
  simp
theorem baseline (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (A B : Finset (Fin n)) (x Y : Fin n) (p l : Fin q ↪ Fin n) (i₀ : Fin q)
    (bin : binary C) (live : Live C) (pos : flags C I) (neg : negatives C I 3 3)
    (hasP : coreSites x p⊆A) (hasL : coreSites Y l⊆B)
    (xp : ∀i,x≠p i) (ly : ∀i,l i≠Y) (xy : ¬I x Y)
    (xl : ∀i,I x (l i)) (pl : ∀i,I (p i) (l i)) (py : ∀i,I (p i) Y)
    (pdom : ∀u∈A,u≠x → ∃i,I u (l i)) (ldom : ∀v∈B,v≠Y → ∃i,I (p i) v)
    (degP : ∀u∈A,2<(N I false u).card) (degL : ∀v∈B,2<(N I true v).card)
    (co : ∀b u v,u≠v → (N I b u∩N I b v).card≤1) :
    2*(A.card+B.card)≤C.size+4 := by
  classical
  let P:=A\coreSites x p
  let Q:=B\coreSites Y l
  have outP (u) (hu : u∈coreSites x p) : u∉P := fun h=>(Finset.mem_sdiff.mp h).2 hu
  have outQ (v) (hv : v∈coreSites Y l) : v∉Q := fun h=>(Finset.mem_sdiff.mp h).2 hv
  have keepx := outP x (Finset.mem_insert_self ..)
  have keepY := outQ Y (Finset.mem_insert_self ..)
  have kp (i) : p i∉P := outP _ (Finset.mem_insert_of_mem (Finset.mem_image.mpr ⟨i,Finset.mem_univ _,rfl⟩))
  have kl (i) : l i∉Q := outQ _ (Finset.mem_insert_of_mem (Finset.mem_image.mpr ⟨i,Finset.mem_univ _,rfl⟩))
  have degree (d) (hd : d∈owners P Q) : 2<(N I d.1 d.2).card := by
    obtain ⟨side,u⟩:=d; cases side
    · exact degP u (Finset.mem_sdiff.mp ((ownerP ..).1 hd)).1
    · exact degL u (Finset.mem_sdiff.mp ((ownerL ..).1 hd)).1
  have pN (u) (hu : u∈P) : ∃v∉Q,I u v := by
    obtain ⟨i,h⟩:=pdom u (Finset.mem_sdiff.mp hu).1 (fun eq=>keepx (eq ▸ hu))
    exact ⟨l i,kl i,h⟩
  have qN (v) (hv : v∈Q) : ∃u∉P,I u v := by
    obtain ⟨i,h⟩:=ldom v (Finset.mem_sdiff.mp hv).1 (fun eq=>keepY (eq ▸ hv))
    exact ⟨p i,kp i,h⟩
  obtain ⟨R,rb,rl,pf,nf,sz⟩:=room C I 2 (by decide) P Q bin live pos neg degree
    (fun d _ j h=>co d.1 d.2 j h.symm) pN qN ⟨x,keepx,l i₀,kl i₀,xl i₀⟩
  have mono (b u) : N (rel I Pᶜ Qᶜ) b u⊆N I b u := by
    cases b <;> intro j h <;> simp only [N,Finset.mem_filter,Finset.mem_univ,true_and,
      Bool.false_eq_true,if_false,if_true] at h ⊢ <;> exact h.2.2
  have core:=IncidenceThetaCore.core R (rel I Pᶜ Qᶜ) x Y p l i₀ xp ly (fun h=>xy h.2.2)
    (fun i=>⟨Finset.mem_compl.mpr keepx,Finset.mem_compl.mpr (kl i),xl i⟩) (fun i=>⟨Finset.mem_compl.mpr (kp i),Finset.mem_compl.mpr (kl i),pl i⟩) (fun i=>⟨Finset.mem_compl.mpr (kp i),Finset.mem_compl.mpr keepY,py i⟩)
    (fun b u v h=>(Finset.card_le_card (Finset.inter_subset_inter (mono b u) (mono b v))).trans (co b u v h))
    rb rl pf nf
  have a := Finset.card_sdiff_add_card_eq_card hasP
  have b := Finset.card_sdiff_add_card_eq_card hasL
  change P.card+_=A.card at a
  change Q.card+_=B.card at b
  rw [countSites x p xp] at a
  rw [countSites Y l (fun i=>(ly i).symm)] at b
  omega
#print axioms baseline
end IncidenceThetaProtected
