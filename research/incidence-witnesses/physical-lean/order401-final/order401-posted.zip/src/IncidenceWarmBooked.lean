import Mathlib.Algebra.Order.BigOperators.Group.Finset
import IncidenceWarmRefs
namespace IncidenceWarmCompiler
open CircuitRewire IncidenceZeroRestriction
variable {m s : ℕ} {code : ℕ→Gate} {drop : Finset ℕ} {fork : ℕ→Option ℕ}

inductive Corridor (m s : ℕ) (code : ℕ→Gate) (fork : ℕ→Option ℕ) (owner : ℕ) :
    ℕ → List ℕ → Prop where
  | finish {j} (pin : fork j=some owner) : Corridor m s code fork owner j []
  | step {j k ks} (skip : fork j=none) (hk : k<s) (side : Bool)
      (edge : port (code k) side=m+j) (rest : Corridor m s code fork owner k ks) :
      Corridor m s code fork owner j (k::ks)

def lost (m : ℕ) (code : ℕ→Gate) (drop : Finset ℕ) (fork : ℕ→Option ℕ) (j : ℕ) :=
  1-cost m code drop fork (2*j)

theorem path_payment (ord : ∀ j<s,(code j).left<m+j ∧ (code j).right<m+j)
    {x j : ℕ} (hx : x<m) (hj : j<s) {ks : List ℕ}
    (path : Corridor m s code fork x j ks) :
    ((j::ks).map (fun k=>cost m code drop fork (2*k+1))).sum ≤
      interim m code drop fork j+(ks.map (lost m code drop fork)).sum := by
  induction path with
  | finish pin => simp [phase_cost m code drop fork hx pin]
  | @step j k ks skip hk side edge rest ih =>
    have one := continuation_bound m code drop fork hk side (ord k hk)
    rw [edge,unedited_presence m code drop fork hj skip] at one
    have cap := cost_le_one m code drop fork (2*k)
    have tail := ih hk
    simp only [List.map_cons,List.sum_cons] at tail ⊢
    rw [no_phase_cost m code drop fork skip]
    simp only [List.map_cons,List.sum_cons,lost]
    omega

theorem owner_payment (ord : ∀ j<s,(code j).left<m+j ∧ (code j).right<m+j)
    {x j : ℕ} (hx : x<m) (hd : x∈drop) (hj : j<s) (side : Bool)
    (edge : port (code j) side=x) (op : (code j).op=.meet) {ks : List ℕ}
    (path : Corridor m s code fork x j ks) :
    1+((j::ks).map (fun k=>cost m code drop fork (2*k+1))).sum ≤
      ((j::ks).map (lost m code drop fork)).sum := by
  have base := first_bound m code drop fork hj side hx hd edge op (ord j hj)
  have more := path_payment (drop:=drop) ord hx hj path
  simp only [List.map_cons,List.sum_cons,lost] at more ⊢
  omega

private theorem add_payments {O : Type*} (owners : List O) (rows : O→List ℕ)
    (charge credit : ℕ→ℕ)
    (per : ∀ o∈owners, 1+((rows o).map charge).sum ≤ ((rows o).map credit).sum) :
    owners.length+((owners.flatMap rows).map charge).sum ≤ ((owners.flatMap rows).map credit).sum := by
  induction owners with
  | nil => simp
  | cons o os ih =>
    have first := per o (by simp)
    have rest := ih (fun a ha=>per a (by simp [ha]))
    simp only [List.length_cons,List.flatMap_cons,List.map_append,List.sum_append]
    omega

theorem common_payment {O : Type*} (owners : List O) (rows : O→List ℕ)
    (per : ∀ o∈owners, 1+((rows o).map (fun k=>cost m code drop fork (2*k+1))).sum ≤
      ((rows o).map (lost m code drop fork)).sum)
    (distinct : (owners.flatMap rows).Nodup)
    (bounded : ∀ j∈owners.flatMap rows,j<s)
    (covered : ∀ j<s,j∉owners.flatMap rows→fork j=none) :
    (run m code drop fork s).size+owners.length≤s := by
  let paidRows := owners.flatMap rows
  let charge := fun k=>cost m code drop fork (2*k+1)
  let credit := lost m code drop fork
  have subtotal : owners.length+(paidRows.map charge).sum ≤ (paidRows.map credit).sum :=
    add_payments owners rows charge credit per
  have hs : paidRows.toFinset ⊆ Finset.range s := by
    intro j hj
    exact Finset.mem_range.mpr (bounded j (List.mem_toFinset.mp hj))
  have swap (f : ℕ→ℕ) : (paidRows.map f).sum=∑ j∈paidRows.toFinset,f j := by
    exact (List.sum_toFinset f distinct).symm
  rw [swap,swap] at subtotal
  have complete : (∑ j∈paidRows.toFinset,charge j)=∑ j∈Finset.range s,charge j := by
    apply Finset.sum_subset hs
    intro j hj miss
    exact no_phase_cost m code drop fork (covered j (Finset.mem_range.mp hj) (fun h => miss (List.mem_toFinset.mpr h)))
  rw [complete] at subtotal
  apply paid m s code drop fork owners.length
  exact subtotal.trans (Finset.sum_le_sum_of_subset_of_nonneg hs (fun _ _ _=>Nat.zero_le _))
end IncidenceWarmCompiler
