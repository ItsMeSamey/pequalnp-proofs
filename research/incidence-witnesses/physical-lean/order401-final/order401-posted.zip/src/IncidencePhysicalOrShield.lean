import IncidencePhysicalOrGroups
namespace IncidencePhysicalOrGroups
open CircuitRewire IncidenceStartNormalization IncidenceHoistReaders SparseIncidence
variable {n : ℕ} (C : Circuit n)
theorem climb {h g : Row C} (join : (C.code h).op=.join) (mid : ¬Top C h)
    {b : Bool} (pin : Reads C g (wire C h) b) : Next C h g := by
  classical
  by_contra bad
  apply mid
  refine ⟨join,?_⟩
  rintro ⟨v,e⟩
  obtain ⟨k,s,_,_,_,uniq⟩ := unique_reader C _ e.2.1
  obtain ⟨b',q⟩ := e.2.2.2
  have eq : g=v := Fin.ext ((uniq g g.isLt b pin).1.trans (uniq v v.isLt b' q).1.symm)
  exact bad (eq.symm ▸ e)
theorem heat {h : Row C} {w : ℕ} {b : Bool} (op : (C.code h).op=.join)
    (pin : Reads C h w b) {z : Input n} (hot : z∈C.wire w) : z∈C.wire (wire C h) := by
  change z∈C.wire (n+n+h.val)
  rw [C.law h h.isLt,Gate.eval,op,Op.eval]
  cases b <;> simp [Reads,operand] at pin
  · exact Or.inr (pin.symm ▸ hot)
  · exact Or.inl (pin.symm ▸ hot)
theorem member_hot {x : ℕ} {g : Row C} (mem : Member C x g) {z : Input n}
    (hot : z∈C.wire x) : z∈C.wire (wire C g) := by
  obtain ⟨r,b,join,pin,walk,top⟩ := mem
  have start := heat C join pin hot
  clear join pin top
  induction walk with
  | refl => exact start
  | step e tail ih =>
    obtain ⟨b,read⟩ := e.2.2.2
    exact ih (heat C e.2.2.1 read start)

theorem extend_path {r g h : Row C} (p : Path C r g) (e : Next C g h) : Path C r h := by
  induction p with
  | refl => exact .step e (.refl _)
  | step ed tail ih => exact .step ed (ih e)
def different (z z' : Input n) (w : ℕ) := ¬(z∈C.wire w ↔ z'∈C.wire w)
theorem changed_parent (z z' : Input n) (g : Row C) (d : different C z z' (wire C g)) :
    ∃ b,different C z z' (operand (C.code g) b) := by
  classical
  by_contra! no
  have l := no true
  have r := no false
  simp only [different,not_not,operand,if_true,if_false,Bool.false_eq_true] at l r
  apply d
  change z∈C.wire (n+n+g.val) ↔ z'∈C.wire (n+n+g.val)
  rw [C.law g g.isLt]
  cases op : (C.code g).op <;> simp [Gate.eval,Op.eval,op] <;> tauto

theorem shield (z z' : Input n) (x : ℕ) (xo : x≠C.output)
    (raw : ∀w<n+n,different C z z' w → w=x)
    (ports : ∀g b,Reads C g x b → (C.code g).op=.join)
    (covered : ∀g,Member C x g → ¬different C z z' (wire C g)) :
    ¬different C z z' C.output := by
  classical
  let Inside (g : Row C) := ∃ r : Row C, ∃ b,(C.code r).op=.join ∧ Reads C r x b ∧
    Path C r g ∧ (C.code g).op=.join ∧ ¬Top C g
  have prop (i : ℕ) (hi : i<n+n+C.size) (diff : different C z z' i) :
      i=x ∨ ∃g : Row C,i=wire C g ∧ Inside g := by
    induction i using Nat.strong_induction_on with
    | ind i ih =>
      by_cases small : i<n+n
      · exact Or.inl (raw i small diff)
      let g : Row C := ⟨i-(n+n),by omega⟩
      have eq : i=wire C g := by dsimp [wire,g]; omega
      have dg : different C z z' (wire C g) := eq ▸ diff
      obtain ⟨b,db⟩ := changed_parent C z z' g dg
      let w := operand (C.code g) b
      have before : w<i := by
        have bound := C.earlier g g.isLt
        change i=n+n+g.val at eq
        cases b <;> simp [w,operand] <;> omega
      have ender (r : Row C) (s : Bool) (jo : (C.code r).op=.join) (pin : Reads C r x s)
          (path : Path C r g) (joG : (C.code g).op=.join) : Inside g :=
        ⟨r,s,jo,pin,path,joG,fun top=>covered g ⟨r,s,jo,pin,path,top⟩ dg⟩
      apply Or.inr
      refine ⟨g,eq,?_⟩
      rcases ih w before (by omega) db with first|⟨h,par,r,s,jo,pin,path,join,mid⟩
      · exact ender g b (ports g b first) first (.refl _) (ports g b first)
      · have nxt := climb C join mid par
        exact ender r s jo pin (extend_path C path nxt) nxt.2.2.1
  intro d
  rcases prop _ C.output_lt d with e|⟨g,e,r,b,jo,pin,path,jg,mid⟩
  · exact xo e.symm
  · exact mid ⟨jg,fun ⟨_,step⟩=>step.1 e.symm⟩
end IncidencePhysicalOrGroups
