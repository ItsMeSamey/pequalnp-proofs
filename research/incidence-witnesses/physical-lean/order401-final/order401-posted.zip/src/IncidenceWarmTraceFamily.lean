import IncidenceWarmTraceDisjoint
import IncidenceWarmTraceBooking
import IncidenceHoistWalk
namespace IncidenceWarmTraceFamily
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceWarmTracePath IncidenceWarmCompiler
open IncidencePointFirstFork IncidenceWarmTraceSchedule IncidenceWarmTraceBooking
variable {n : Nat} (C : Circuit n)
def stop (x : Nat) := IncidencePointFirstFork.fork C x-(n+n)

theorem not_output (I : Fin n→Fin n→Prop) (neg : negatives C I 2 2) (u : Nat) (hu : u<n+n) :
    u≠C.output := by
  have no (b : Bool) (x : Fin n) : IncidenceHoistShield.owner b x≠C.output := by
    intro eq
    have h := IncidenceHoistWalk.owner_hot C b x
    rw [eq] at h
    have one : Fintype.card {j // single x j=true} ≤ 1 := by
      let f : {j // single x j=true} → Unit := fun _ => ()
      have inj : Function.Injective f := by
        intro a b _
        exact Subtype.ext ((of_decide_eq_true a.property).trans (of_decide_eq_true b.property).symm)
      simpa using Fintype.card_le_of_injective f inj
    cases b <;> apply neg _ _ _ _ _ h <;>
      first | exact one.trans (by decide) | simp [IncidenceHoistWalk.witness]
  by_cases p : u<n
  · exact no false ⟨u,p⟩
  · let l : Fin n := ⟨u-n,by omega⟩
    have eq : IncidenceHoistShield.owner true l=u := by change n+(u-n)=u; omega
    exact eq ▸ no true l

theorem family (I : Fin n→Fin n→Prop) (neg : negatives C I 2 2)
    (owners : List Nat) (distinct : owners.Nodup)
    (raw : ∀x∈owners,x<n+n) (one : ∀x∈owners,uses C x=1)
    (meet : ∀x∈owners,∀j<C.size,∀ b,port (C.code j) b=x → (C.code j).op=.meet)
    (unique : ∀x∈owners,∀y∈owners,IncidencePointFirstFork.fork C x=IncidencePointFirstFork.fork C y → x=y) :
    ∃ (start : Nat→Nat) (side : Nat→Bool) (tail : Nat→List Nat), (∀ x∈owners,start x<C.size ∧ port (C.code (start x)) (side x)=x ∧
      (C.code (start x)).op=.meet ∧
      Corridor (n+n) C.size C.code (schedule owners.toFinset (stop C)) x (start x) (tail x)) ∧
      (owners.flatMap fun x=>start x::tail x).Nodup ∧
      (∀ j∈owners.flatMap (fun x=>start x::tail x),j<C.size) ∧
      (∀ j, j∉owners.flatMap (fun x=>start x::tail x) → schedule owners.toFinset (stop C) j=none) := by
  classical
  have data (x : Nat) : ∃ j b ks, x∈owners →
      j<C.size ∧ port (C.code j) b=x ∧ Path C j ks (stop C x) ∧
      IncidencePointFirstFork.fork C x=n+n+stop C x := by
    by_cases hx : x∈owners
    · obtain ⟨j,b,ks,e,hj,edge,p,last⟩ := raw_start C x (one x hx) (not_output C I neg x (raw x hx))
      have eq : stop C x=e := by simp [stop,last]
      exact ⟨j,b,ks,fun _=>⟨hj,edge,eq ▸ p,eq ▸ last⟩⟩
    · exact ⟨0,false,[],fun h=>False.elim (hx h)⟩
  choose start side tail spec using data
  have inj : ∀x∈owners,∀y∈owners,stop C x=stop C y → x=y := by
    intro x hx y hy eq
    exact unique x hx y hy (by rw [(spec x hx).2.2.2,(spec y hy).2.2.2,eq])
  have finj : ∀x∈owners.toFinset,∀y∈owners.toFinset,stop C x=stop C y → x=y := by simpa using inj
  have finish : ∀x∈owners.toFinset,next C (n+n+stop C x)=none := by
    intro x hx
    exact (endpoint C (spec x (List.mem_toFinset.mp hx)).2.2.1).2
  refine ⟨start,side,tail,?_,IncidenceWarmTraceDisjoint.flat_nodup C owners start tail (stop C) distinct
    (fun x hx=>(spec x hx).2.2.1) inj,?_,?_⟩
  · intro x hx
    obtain ⟨hj,edge,path,_⟩ := spec x hx
    exact ⟨hj,edge,meet x hx _ hj _ edge,book C path _ _ finj finish x (by simpa using hx) rfl⟩
  · intro j hj
    obtain ⟨x,hx,h⟩ := List.mem_flatMap.mp hj
    exact bounded C (spec x hx).1 (spec x hx).2.2.1 j h
  · exact covered owners (stop C) (fun x=>start x::tail x)
      (fun x hx=>(endpoint C (spec x hx).2.2.1).1)
theorem wiring (I : Fin n→Fin n→Prop) (neg : negatives C I 2 2) (owners : List Nat)
    (raw : ∀x∈owners,x<n+n) (one : ∀x∈owners,uses C x=1)
    (unique : ∀x∈owners,∀y∈owners,IncidencePointFirstFork.fork C x=IncidencePointFirstFork.fork C y → x=y)
    (j x : Nat) : schedule owners.toFinset (stop C) j=some x ↔
      x∈owners ∧ n+n+j=IncidencePointFirstFork.fork C x := by
  have exactStop (a) (ha : a∈owners) : IncidencePointFirstFork.fork C a=n+n+stop C a := by
    obtain ⟨_,_,_,e,_,_,_,endEq⟩ := raw_start C a (one a ha) (not_output C I neg a (raw a ha))
    simp [stop,endEq]
  have inj : ∀a∈owners.toFinset,∀b∈owners.toFinset,stop C a=stop C b → a=b := by
    intro a ha b hb e
    have hA := List.mem_toFinset.mp ha
    have hB := List.mem_toFinset.mp hb
    exact unique a hA b hB (by rw [exactStop a hA,exactStop b hB,e])
  constructor
  · intro h
    obtain ⟨mem,e⟩ := schedule_spec _ _ _ _ h
    have hx := List.mem_toFinset.mp mem
    exact ⟨hx,by rw [exactStop x hx,e]⟩
  · rintro ⟨hx,h⟩
    rw [exactStop x hx] at h
    have eq : j=stop C x := by omega
    rw [eq]
    exact terminal _ _ x (by simpa using hx) inj

#print axioms family
#print axioms wiring
end IncidenceWarmTraceFamily
