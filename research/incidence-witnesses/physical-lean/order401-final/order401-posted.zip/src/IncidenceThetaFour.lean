import Research.CircuitRewire
import Init.Data.BitVec.Lemmas
set_option maxRecDepth 16000
set_option maxHeartbeats 8000000
namespace IncidenceThetaFour
open CircuitRewire
abbrev Mask := BitVec 8

/-- Rows 0,1,2 are the three edges x-l, l-p, p-Y. Rows 3,4,5,6
    are the four singleton negatives x,l,p,Y. Row 7 is x+Y. -/
def raws : List Mask := [0,137,19,38,196]
def target : Mask := 7

def stepMask (op : Op) (x y : Mask) : Mask :=
  match op with
  | .join => x ||| y
  | .meet => x &&& y
  | .copy => x
  | .zero => 0

def allowed (a : Mask) : Prop := a=0 ∨ a=137 ∨ a=19 ∨ a=38 ∨ a=196
def produced (a b v : Mask) : Prop := v=a ||| b ∨ v=a &&& b ∨ v=a ∨ v=0

def nextOK (bank outs : List Mask) : Bool :=
  bank.all fun a=>bank.all fun b=>outs.contains (a ||| b) && outs.contains (a &&& b) && outs.contains a && outs.contains 0

def lastOK (bank : List Mask) : Bool :=
  bank.all fun a=>bank.all fun b=>(a ||| b != 7) && (a &&& b != 7) && (a != 7) && ((0 : Mask) != 7)

private theorem closed {bank outs : List Mask} (h : nextOK bank outs=true) {a b v : Mask}
    (ha : a∈bank) (hb : b∈bank) (hv : produced a b v) : v∈outs := by
  have f := List.all_eq_true.mp (List.all_eq_true.mp h a ha) b hb
  simp only [Bool.and_eq_true,List.contains_iff_mem] at f
  rcases hv with rfl|rfl|rfl|rfl <;> tauto

private theorem last {bank : List Mask} (h : lastOK bank=true) {a b v : Mask}
    (ha : a∈bank) (hb : b∈bank) (hv : produced a b v) : v≠7 := by
  have f := List.all_eq_true.mp (List.all_eq_true.mp h a ha) b hb
  simp [bne_iff_ne] at f
  rcases hv with rfl|rfl|rfl|rfl <;> tauto

private theorem useful {w : Mask} (h : allowed w) : w∈raws := by simpa [allowed,raws] using h

private theorem finish0 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))
    (ht : allowed t ∨ t=0 ∨ t=b) (hw : allowed w ∨ w=0 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=0 ∨ v=b) : v∈b::0::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::0::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))) hb

private theorem finish1 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,39,55,128,137,155,175,196,197,205,215,230] : List Mask))
    (ht : allowed t ∨ t=1 ∨ t=b) (hw : allowed w ∨ w=1 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=1 ∨ v=b) : v∈b::1::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::1::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,39,55,128,137,155,175,196,197,205,215,230] : List Mask))) hb

private theorem finish2 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,139,155,175,196,198,205,215,230] : List Mask))
    (ht : allowed t ∨ t=2 ∨ t=b) (hw : allowed w ∨ w=2 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=2 ∨ v=b) : v∈b::2::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::2::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,139,155,175,196,198,205,215,230] : List Mask))) hb

private theorem finish4 (b t w c : Mask) (hb : b∈([0,1,2,4,19,23,38,55,128,137,141,155,175,196,205,215,230] : List Mask))
    (ht : allowed t ∨ t=4 ∨ t=b) (hw : allowed w ∨ w=4 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=4 ∨ v=b) : v∈b::4::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::4::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,23,38,55,128,137,141,155,175,196,205,215,230] : List Mask))) hb

private theorem finish19 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))
    (ht : allowed t ∨ t=19 ∨ t=b) (hw : allowed w ∨ w=19 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=19 ∨ v=b) : v∈b::19::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::19::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))) hb

private theorem finish38 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))
    (ht : allowed t ∨ t=38 ∨ t=b) (hw : allowed w ∨ w=38 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=38 ∨ v=b) : v∈b::38::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::38::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))) hb

private theorem finish55 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,155,175,191,196,205,215,230,247] : List Mask))
    (ht : allowed t ∨ t=55 ∨ t=b) (hw : allowed w ∨ w=55 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=55 ∨ v=b) : v∈b::55::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::55::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,155,175,191,196,205,215,230,247] : List Mask))) hb

private theorem finish128 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,147,155,166,175,196,205,215,230] : List Mask))
    (ht : allowed t ∨ t=128 ∨ t=b) (hw : allowed w ∨ w=128 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=128 ∨ v=b) : v∈b::128::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::128::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,147,155,166,175,196,205,215,230] : List Mask))) hb

private theorem finish137 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))
    (ht : allowed t ∨ t=137 ∨ t=b) (hw : allowed w ∨ w=137 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=137 ∨ v=b) : v∈b::137::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::137::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))) hb

private theorem finish155 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,155,175,191,196,205,215,223,230] : List Mask))
    (ht : allowed t ∨ t=155 ∨ t=b) (hw : allowed w ∨ w=155 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=155 ∨ v=b) : v∈b::155::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::155::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,155,175,191,196,205,215,223,230] : List Mask))) hb

private theorem finish175 (b t w c : Mask) (hb : b∈([0,1,2,3,4,19,38,55,128,132,137,155,175,191,196,205,215,230,239] : List Mask))
    (ht : allowed t ∨ t=175 ∨ t=b) (hw : allowed w ∨ w=175 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=175 ∨ v=b) : v∈b::175::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::175::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,3,4,19,38,55,128,132,137,155,175,191,196,205,215,230,239] : List Mask))) hb

private theorem finish196 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))
    (ht : allowed t ∨ t=196 ∨ t=b) (hw : allowed w ∨ w=196 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=196 ∨ v=b) : v∈b::196::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::196::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230] : List Mask))) hb

private theorem finish205 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,223,230,239] : List Mask))
    (ht : allowed t ∨ t=205 ∨ t=b) (hw : allowed w ∨ w=205 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=205 ∨ v=b) : v∈b::205::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::205::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,223,230,239] : List Mask))) hb

private theorem finish215 (b t w c : Mask) (hb : b∈([0,1,2,4,6,19,38,55,128,129,137,155,175,196,205,215,223,230,247] : List Mask))
    (ht : allowed t ∨ t=215 ∨ t=b) (hw : allowed w ∨ w=215 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=215 ∨ v=b) : v∈b::215::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::215::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,6,19,38,55,128,129,137,155,175,196,205,215,223,230,247] : List Mask))) hb

private theorem finish230 (b t w c : Mask) (hb : b∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230,239,247] : List Mask))
    (ht : allowed t ∨ t=230 ∨ t=b) (hw : allowed w ∨ w=230 ∨ w=b) (hc : produced t w c) : b≠7 ∧ c≠7 := by
  have keep (v : Mask) (h : allowed v ∨ v=230 ∨ v=b) : v∈b::230::raws := by
    rcases h with h|rfl|rfl
    · exact List.mem_cons_of_mem _ (List.mem_cons_of_mem _ (useful h))
    · simp
    · simp
  have terminal : lastOK (b::230::raws)=true := by
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hb
    rcases hb with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> decide +kernel
  refine ⟨?_,last terminal (keep _ ht) (keep _ hw) hc⟩
  intro bad
  subst b
  exact (by decide : ¬(7∈([0,1,2,4,19,38,55,128,137,155,175,196,205,215,230,239,247] : List Mask))) hb

theorem three (x y a u v b t w c : Mask)
    (hx : allowed x) (hy : allowed y) (ha : produced x y a)
    (hu : allowed u ∨ u=a) (hv : allowed v ∨ v=a) (hb : produced u v b)
    (ht : allowed t ∨ t=a ∨ t=b) (hw : allowed w ∨ w=a ∨ w=b)
    (hc : produced t w c) : a≠7 ∧ b≠7 ∧ c≠7 := by
  have mem := closed (bank:=raws) (outs:=[0,1,2,4,19,38,55,128,137,155,175,196,205,215,230]) (by decide +kernel) (useful hx) (useful hy) ha
  have keep (v : Mask) (h : allowed v ∨ v=a) : v∈a::raws := by
    rcases h with h|rfl
    · exact List.mem_cons_of_mem _ (useful h)
    · simp
  have h1:=keep u hu
  have h2:=keep v hv
  simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact ⟨by decide,finish0 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,155,175,196,205,215,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish1 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,39,55,128,137,155,175,196,197,205,215,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish2 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,139,155,175,196,198,205,215,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish4 _ _ _ _ (closed (outs:=[0,1,2,4,19,23,38,55,128,137,141,155,175,196,205,215,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish19 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,155,175,196,205,215,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish38 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,155,175,196,205,215,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish55 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,155,175,191,196,205,215,230,247]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish128 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,147,155,166,175,196,205,215,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish137 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,155,175,196,205,215,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish155 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,155,175,191,196,205,215,223,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish175 _ _ _ _ (closed (outs:=[0,1,2,3,4,19,38,55,128,132,137,155,175,191,196,205,215,230,239]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish196 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,155,175,196,205,215,230]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish205 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,155,175,196,205,215,223,230,239]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish215 _ _ _ _ (closed (outs:=[0,1,2,4,6,19,38,55,128,129,137,155,175,196,205,215,223,230,247]) (by decide +kernel) h1 h2 hb) ht hw hc⟩
  · exact ⟨by decide,finish230 _ _ _ _ (closed (outs:=[0,1,2,4,19,38,55,128,137,155,175,196,205,215,230,239,247]) (by decide +kernel) h1 h2 hb) ht hw hc⟩

private theorem produced_step (op : Op) (a b : Mask) : produced a b (stepMask op a b) := by
  cases op <;> simp [produced,stepMask]

theorem excludes {m s : ℕ} (g : ℕ→Gate) (value : ℕ→Mask)
    (initial : ∀w<m,allowed (value w))
    (order : ∀j<s,(g j).left<m+j ∧ (g j).right<m+j)
    (eval : ∀j<s,value (m+j)=stepMask (g j).op (value (g j).left) (value (g j).right))
    (small : s≤3) (out : ℕ) (bound : out<m+s) : value out≠7 := by
  let left := fun j=>if j<s then value (g j).left else 0
  let right := fun j=>if j<s then value (g j).right else 0
  let val := fun j=>if j<s then value (m+j) else 0
  have make (j) : produced (left j) (right j) (val j) := by
    by_cases h : j<s
    · simpa [left,right,val,h,eval j h] using produced_step (g j).op (value (g j).left) (value (g j).right)
    · simp [left,right,val,h,produced]
  have bank (j) (w) (hw : w<m+j) (hs : j≤s) : allowed (value w) ∨ ∃i<j,value w=val i := by
    by_cases r : w<m
    · exact Or.inl (initial _ r)
    · refine Or.inr ⟨w-m,by omega,?_⟩
      have hi : w-m<s := by omega
      simp [val,hi, Nat.add_sub_cancel' (Nat.le_of_not_gt r)]
  have pin (j) (a : Mask) (e : a=left j ∨ a=right j) :
      allowed a ∨ ∃i<j,a=val i := by
    by_cases h : j<s
    · rcases e with rfl|rfl
      · simpa [left,h] using bank j _ (order j h).1 h.le
      · simpa [right,h] using bank j _ (order j h).2 h.le
    · rcases e with rfl|rfl <;> simp [left,right,h,allowed]
  have zero (a) (e : a=left 0 ∨ a=right 0) : allowed a := by simpa using pin 0 a e
  have one (a) (e : a=left 1 ∨ a=right 1) : allowed a ∨ a=val 0 := by
    rcases pin 1 a e with v|⟨i,hi,rfl⟩
    · exact Or.inl v
    · exact Or.inr (congrArg val (by omega))
  have two (a) (e : a=left 2 ∨ a=right 2) : allowed a ∨ a=val 0 ∨ a=val 1 := by
    rcases pin 2 a e with v|⟨i,hi,rfl⟩
    · exact Or.inl v
    · rcases (show i=0 ∨ i=1 by omega) with rfl|rfl <;> simp
  have cert := three _ _ _ _ _ _ _ _ _ (zero _ (Or.inl rfl)) (zero _ (Or.inr rfl)) (make 0)
    (one _ (Or.inl rfl)) (one _ (Or.inr rfl)) (make 1)
    (two _ (Or.inl rfl)) (two _ (Or.inr rfl)) (make 2)
  rcases bank s out bound (Nat.le_refl s) with h|⟨i,hi,e⟩
  · unfold allowed at h
    rcases h with h|h|h|h|h <;> rw [h] <;> decide
  · rcases (show i=0 ∨ i=1 ∨ i=2 by omega) with rfl|rfl|rfl <;> rw [e] <;> tauto

noncomputable def record {Z : Type*} (rows : Fin 8→Z) (X : Set Z) : Mask := by
  classical
  exact (BitVec.ofBoolListLE (List.ofFn (fun i=>decide (rows i∈X)))).cast (by simp)

theorem record_get {Z : Type*} (rows : Fin 8→Z) (X : Set Z) (i : ℕ) (h : i<8) :
    (record rows X).getLsbD i=true ↔ rows ⟨i,h⟩∈X := by
  classical
  simp only [record,BitVec.getLsbD_cast,BitVec.getLsbD_ofBoolListLE,List.getD_eq_getElem?_getD]
  rw [List.getElem?_eq_getElem (by simpa only [List.length_ofFn] using h)]
  simp only [Option.getD_some,List.getElem_ofFn,decide_eq_true_eq]

theorem recorded_eval {Z : Type*} (rows : Fin 8→Z) (X : ℕ→Set Z) (G : Gate) :
    record rows (G.eval X)=stepMask G.op (record rows (X G.left)) (record rows (X G.right)) := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  apply Bool.eq_iff_iff.mpr
  cases e : G.op <;> simp [stepMask,e,Gate.eval,Op.eval,record_get rows _ i hi]

theorem physical {Z : Type*} (m s out : ℕ) (g : ℕ→Gate) (X : ℕ→Set Z) (rows : Fin 8→Z)
    (inputs : ∀w<m,record rows (X w)∈raws)
    (order : ∀j<s,(g j).left<m+j ∧ (g j).right<m+j)
    (eval : ∀j<s,X (m+j)=(g j).eval X) (output : out<m+s)
    (tests : record rows (X out)=target) : 4≤s := by
  by_contra small
  have init (w) (hw : w<m) : allowed (record rows (X w)) := by
    simpa [raws,allowed] using inputs w hw
  exact excludes g (fun w=>record rows (X w)) init order
    (fun j hj=> (congrArg (record rows) (eval j hj)).trans (recorded_eval _ _ _))
    (by omega) out output tests
#print axioms physical
end IncidenceThetaFour
