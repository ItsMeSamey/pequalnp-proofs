import IncidenceNoExtra
namespace IncidenceThetaBatch
open CircuitRewire IncidenceOperandLedger IncidenceZeroRestriction
open scoped BigOperators

/-- Each selected AND has precisely one dead input. Its wire address recovers
the reserved raw regardless of whether it was on the left or the right. -/
theorem payment (m n s : ℕ) (g : ℕ→Gate) (init : ℕ→Option ℕ) (z : ℕ→Bool)
    (input : ∀ i<m,(init i).isNone=z i)
    (ord : ∀ j<s,OrderedBinary (g j) (m+j))
    (step : ∀ j<s,z (m+j)=deadOut (g j).op (z (g j).left) (z (g j).right))
    (D S : Finset ℕ) (owner : ℕ→ℕ) (sub : S⊆D) (bound : D⊆Finset.range m)
    (flags : ∀ i<m,z i=true ↔ i∈D)
    (uses : ∀ i∈S,1≤fan g s i) (other : ∀ i∈D\S,2≤fan g s i)
    (reserve : ∀ i∈S, owner i<s ∧ (g (owner i)).op=.meet ∧
       (((g (owner i)).left=i ∧ z (g (owner i)).right=false) ∨
        ((g (owner i)).right=i ∧ z (g (owner i)).left=false)))
    (live : ∀ j<s,z (m+j)=true → 1≤fan g s (m+j)) :
    (compileLiteral m n g init s).size + 2*D.card ≤ s := by
  classical
  let deadPin := fun j => if z (g j).left then (g j).left else (g j).right
  have recov (i) (hi : i∈S) : deadPin (owner i)=i := by
    have zi := (flags i (Finset.mem_range.mp (bound (sub hi)))).2 (sub hi)
    rcases (reserve i hi).2.2 with ⟨a,b⟩|⟨a,b⟩ <;> simp [deadPin,a,b,zi]
  have inj : Set.InjOn owner (↑S : Set ℕ) := by
    intro i hi j hj e
    exact (recov i hi).symm.trans ((congrArg deadPin e).trans (recov j hj))
  have book (i) (hi : i∈S) : oneAnd z (g (owner i))=1 := by
    have zi := (flags i (Finset.mem_range.mp (bound (sub hi)))).2 (sub hi)
    have op := (reserve i hi).2.1
    rcases (reserve i hi).2.2 with ⟨a,b⟩|⟨a,b⟩ <;> simp [oneAnd,op,a,b,zi]
  let B := S.image owner
  have inside : B⊆Finset.range s := by
    intro j hj
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hj
    exact Finset.mem_range.mpr (reserve i hi).1
  have paid : (∑ j∈B,oneAnd z (g j))=(B.card : ℤ) := by
    calc
      _ = ∑ _j∈B,(1 : ℤ) := by
        apply Finset.sum_congr rfl
        intro j hj
        obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hj
        exact book i hi
      _ = _ := by simp
  have extra : 0 ≤ ∑ j∈Finset.range s \ B,oneAnd z (g j) := by
    apply Finset.sum_nonneg
    intro j _
    unfold oneAnd
    split <;> omega
  have part := Finset.sum_sdiff (f:=fun j=>oneAnd z (g j)) inside
  have inten : 0 ≤ ∑ j∈Finset.range s,(fan g s (m+j)-1)*bit (z (m+j)) := by
    apply Finset.sum_nonneg
    intro j hj
    cases h : z (m+j) with
    | false => simp [bit]
    | true => have p := live j (Finset.mem_range.mp hj) h; simp [bit]; omega
  have eqn := savings m n s g init z input ord step
  rw [IncidenceNoExtra.raw_sum D m z (fan g s) bound flags] at eqn
  have floor := IncidenceNoExtra.raw_floor D S owner (fan g s) sub inj uses other
  change 2*(D.card : ℤ)-(B.card : ℤ)≤_ at floor
  omega

#print axioms payment
end IncidenceThetaBatch
