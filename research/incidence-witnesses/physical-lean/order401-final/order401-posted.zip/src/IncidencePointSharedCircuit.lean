import IncidencePointPayload
namespace IncidencePointPayload
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidencePointShield
open IncidencePointWarmMasks IncidencePointBooking IncidencePointCommon IncidencePointCorridor
variable {n : Nat}
theorem shared (C : Circuit n) (I : Fin n→Fin n→Prop) (bin : binary C)
    (pos : flags C I) (neg : negatives C I 401 400) (hn : 0<n)
    (line : ∀x,∃l,I x l) (S : Finset (Fin n)) (cut : Fin n→Nat)
    (paths : ∀x : Fin n,Path (n+n) C.code x.val (cut x))
    (ok : ∀x∈S,(paths x).check C.output x.val C.size)
    (K G : Finset Nat) (sub : G⊆Finset.range C.size∩K)
    (zero : ∀g<C.size,g∈K → X C (n+n+g)=∅)
    (sib : G→Nat) (bounded : ∀u,sib u<n+n+C.size)
    (next : G→Option G) (later : ∀u v,next u=some v → u.val<v.val)
    (head : ∀x∈S,∃u : G,factors G sib next later u=(paths x).factors) :
    ∃sz≤C.size,∃code : Nat→Gate,∃Y : Nat→Set (Sparse n),∃out : Fin n→Nat,
      (∀i<n,Y i=B n i) ∧ (∀i<sz,(code i).left<n+i ∧ (code i).right<n+i) ∧
      (∀i<sz,Y (n+i)=(code i).eval Y) ∧
      ∀x∈S,out x<n+sz ∧ ∀T : Sparse n,T∈Y (out x) ↔ mask {x} T.val∈C.wire (cut x) := by
  classical
  obtain ⟨sz,small,code,Y,id,inputs,ord,sem,values⟩ :=
    common (n+n) n C.size C.code (pin n) K G (X C) (B n) hn pin_bound
      (src C) C.earlier (laws C) zero sub sib bounded next later
  let out := fun x=>if hx : x∈S then id ((head x hx).choose) else 0
  refine ⟨sz,small,code,Y,out,inputs,ord,sem,?_⟩
  intro x hx
  let u := (head x hx).choose
  obtain ⟨bd,eval⟩ := values u
  obtain ⟨l,on⟩ := line x
  have lengths := (head x hx).choose_spec
  change factors G sib next later u=(paths x).factors at lengths
  rw [lengths] at eval
  simp only [out,dif_pos hx]
  refine ⟨bd,fun T=>?_⟩
  rw [show Y (id ((head x hx).choose))=active (X C) (paths x).factors from eval]
  exact (fork_product C I bin pos neg x l on (cut x) (paths x) (ok x hx) T).symm
#print axioms shared
end IncidencePointPayload
