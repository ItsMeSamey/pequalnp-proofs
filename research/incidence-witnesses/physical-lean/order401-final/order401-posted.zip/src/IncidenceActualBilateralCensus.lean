import IncidenceActualBilateralLine
import IncidenceWarmActualCensus
namespace IncidenceActualBilateralCensus
open SparseIncidence IncidenceStartNormalization IncidenceHoistPrune
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

theorem retained (degree : ∀l,Fintype.card {p // I p l}=402) (join : ∀p r,p≠r→∃!l,I p l∧I r l)
    (hn : n=161203) (pos : flags C I) (neg : negatives C I n 401) (upper : C.size≤646424) :
    ∃ line both : Circuit n, LineStage I C line ∧ BilateralStage I line both ∧
      Live line ∧ Live both ∧ soleCount both n≤3382 ∧ soleCount both 0≤6461 ∧
      soleCount both 0+soleCount both n≤9843 := by
  obtain ⟨line,both,L,B,ll,lb,_,lines⟩ := IncidenceActualBilateralLine.retained C I degree join hn pos neg upper
  have points := IncidenceWarmActualPointCap.point_bound both I B.ops B.and_point B.one B.sparse degree join hn
    (B.budget.trans (L.budget.trans upper))
  exact ⟨line,both,L,B,ll,lb,lines,points,by omega⟩
#print axioms retained
end IncidenceActualBilateralCensus
