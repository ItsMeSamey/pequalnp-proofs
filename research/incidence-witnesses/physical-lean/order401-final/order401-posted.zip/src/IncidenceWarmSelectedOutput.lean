import IncidenceWarmPointOutput
import IncidenceWarmDichotomy
namespace IncidenceWarmSelectedOutput
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmDomain IncidencePointWarmMasks IncidenceReciprocalChoice IncidenceChosenEnds
open IncidenceWarmDichotomy

theorem selected {n : ℕ} (C : Circuit n) (I : Fin n→Fin n→Prop) (c : Fin n→ℕ)
    (O : Finset (Fin n)) (f : Fin n→Fin n) (valid : Valid (D C I c O) f)
    (order : ∀x,removed f c x→∀y∈D C I c O x, f y=x ∧ c y<c x ∧ ¬removed f c y)
    (A : Schedule C) (w : Wiring C (edits C I c O f) A.fork c)
    (drop : A.drop=drops (edits C I c O f)) (nonempty : ∃p l,I p l)
    (pos : flags C I) (original : negatives C I 401 400)
    (guards : ∀y∈O, c y<n+n+C.size ∧ shadow (n+n) C.code y.val (c y) C.size C.output=false) :
    ∃ B : Circuit n,B.size+(edits C I c O f).card≤C.size ∧ binary B ∧ B.wire B.output=A.output ∧
      flags B I ∧ negatives B I 2 2 ∧ ExactOn I 2 2 (B.wire B.output) := by
  classical
  apply IncidenceWarmPointOutput.physical A I _ c w drop nonempty pos
  · intro p hp
    exact (guards p (Finset.mem_filter.mp hp).1).2
  · intro J T hj ht safe
    rcases dichotomy C I c O f valid order J T hj ht safe with all|bad
    · exact good C I _ A.fork c w original J T hj ht safe all
    · obtain ⟨x,y,rfl,xM,yM,yO,earlier,W,size,avoid,cold,hot⟩ := bad
      exact bad_pair C I _ A.fork c w original x y xM yM earlier (guards y yO).1
        (guards y yO).2 T W ht size avoid cold hot
#print axioms selected
end IncidenceWarmSelectedOutput
