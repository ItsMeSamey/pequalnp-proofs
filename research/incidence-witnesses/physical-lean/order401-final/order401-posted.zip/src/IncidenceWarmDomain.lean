import IncidenceWarmPhysical
import IncidencePointForeign
namespace IncidenceWarmDomain
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceWarmCompiler
structure Schedule {n : ℕ} (C : Circuit n) where
  owners : List ℕ
  drop : Finset ℕ
  fork : ℕ→Option ℕ
  start : ℕ→ℕ
  side : ℕ→Bool
  tail : ℕ→List ℕ
  pins : ∀ j<C.size,∀ x,fork j=some x→x<n+n
  legal : ∀ x∈owners,x<n+n ∧ x∈drop ∧ start x<C.size ∧
      port (C.code (start x)) (side x)=x ∧ (C.code (start x)).op=.meet ∧
      Corridor (n+n) C.size C.code fork x (start x) (tail x)
  distinct : (owners.flatMap fun x=>start x::tail x).Nodup
  bounded : ∀ j∈owners.flatMap (fun x=>start x::tail x),j<C.size
  covered : ∀ j<C.size,j∉owners.flatMap (fun x=>start x::tail x)→fork j=none

/-- A private corridor contains exactly one reinjection, carrying its own raw owner. -/
theorem placement {m s x j : ℕ} {code : ℕ→Gate} {fork : ℕ→Option ℕ} {ks : List ℕ}
    (p : Corridor m s code fork x j ks) :
    ∃ t, t ∈ (j :: ks) ∧ fork t = some x ∧
      ∀ r ∈ (j :: ks), ∀ y, fork r = some y → r = t ∧ y = x := by
  induction p with
  | finish h =>
    refine ⟨_,by simp,h,?_⟩
    intro r hr y hy
    simp only [List.mem_singleton] at hr
    subst r
    exact ⟨rfl,Option.some.inj (hy.symm.trans h)⟩
  | @step j k ks h hk b edge rest ih =>
    obtain ⟨t,ht,tag,only⟩ := ih
    refine ⟨t,List.mem_cons_of_mem _ ht,tag,?_⟩
    intro r hr y hy
    rcases List.mem_cons.mp hr with rfl|inside
    · simp [h] at hy
    · exact only _ inside _ hy

theorem Schedule.targets {n : ℕ} {C : Circuit n} (A : Schedule C) (x : ℕ) :
    x∈A.owners ↔ ∃! j,j<C.size ∧ A.fork j=some x := by
  have identify {r y : ℕ} (hr : r<C.size) (hy : A.fork r=some y) :
      y∈A.owners ∧ r∈A.start y::A.tail y := by
    have mem : r∈A.owners.flatMap (fun z=>A.start z::A.tail z) := by
      by_contra no
      rw [A.covered r hr no] at hy
      cases hy
    obtain ⟨z,hz,inrow⟩ := List.mem_flatMap.mp mem
    obtain ⟨_,_,_,_,_,path⟩ := A.legal z hz
    obtain ⟨_,_,_,all⟩ := placement path
    obtain ⟨_,rfl⟩ := all _ inrow _ hy
    exact ⟨hz,inrow⟩
  constructor
  · intro hx
    obtain ⟨_,_,_,_,_,path⟩ := A.legal x hx
    obtain ⟨t,ht,tag,only⟩ := placement path
    exact ⟨t,⟨A.bounded t (List.mem_flatMap.mpr ⟨x,hx,ht⟩),tag⟩,
      fun r hr => (only r (identify hr.1 hr.2).2 x hr.2).1⟩
  · rintro ⟨r,hr,_⟩
    exact (identify hr.1 hr.2).1

def Schedule.output {n : ℕ} {C : Circuit n} (A : Schedule C) :=
  editedWire (n+n) C.size C.wire C.code A.drop A.fork C.output

def ExactOn {n : ℕ} (I : Fin n→Fin n→Prop) (pc lc : ℕ) (f : Set (Input n)) :=
  ∀ a b : Fin n→Bool,Fintype.card {p // a p=true}≤pc →
    Fintype.card {l // b l=true}≤lc →
    ((a,b)∈f ↔ ∃ p l,a p=true ∧ b l=true ∧ I p l)

theorem domain {n : ℕ} (C : Circuit n) (A : Schedule C) (I : Fin n→Fin n→Prop)
    (pc lc : ℕ) (inc : ∃ p l,I p l)
    (pos : ∀p l,I p l → (single p,single l)∈A.output)
    (neg : ∀ a b : Fin n→Bool,Fintype.card {p // a p=true}≤pc →
      Fintype.card {l // b l=true}≤lc → (∀ p l,a p=true→b l=true→¬I p l) →
      (a,b)∉A.output) :
    ∃ D : Circuit n,D.size+A.owners.length≤C.size ∧ binary D ∧
      D.wire D.output=A.output ∧ flags D I ∧ negatives D I pc lc ∧
      ExactOn I pc lc (D.wire D.output) := by
  classical
  obtain ⟨p,l,h⟩ := inc
  obtain ⟨D,sz,bin,out⟩ := compile_owners C A.owners A.drop A.fork A.start A.side A.tail
    A.pins A.legal A.distinct A.bounded A.covered ⟨_,pos p l h⟩
  change D.wire D.output=A.output at out
  have yes : flags D I := fun p l h => out ▸ pos p l h
  have no : negatives D I pc lc := fun a b ha hb dis => out ▸ neg a b ha hb dis
  refine ⟨D,sz,bin,out,yes,no,?_⟩
  intro a b ha hb
  constructor
  · intro on
    by_contra bad
    exact no a b ha hb (fun p l ap bl hit=>bad ⟨p,l,ap,bl,hit⟩) on
  · rintro ⟨u,v,au,bv,hit⟩
    apply IncidencePointShield.monotone D _ D.output_lt _ (yes u v hit)
    constructor
    · intro i on
      simp [single] at on
      simpa [on] using au
    · intro i on
      simp [single] at on
      simpa [on] using bv
/-- The mask semantics prove finite-set cases; the circuit API quantifies over Boolean vectors. -/
theorem bool_negatives {n pc lc : ℕ} {I : Fin n→Fin n→Prop} {out : Set (Input n)}
    (masks : ∀ J T : Finset (Fin n),J.card≤pc → T.card≤lc →
      (∀x∈J,∀y∈T,¬I x y) → (IncidencePointShield.bits J,IncidencePointShield.bits T)∉out) :
    ∀ a b : Fin n→Bool,Fintype.card {x // a x=true}≤pc →
      Fintype.card {y // b y=true}≤lc →
      (∀ x y,a x=true → b y=true → ¬I x y) → (a,b)∉out := by
  classical
  intro a b h₁ h₂ dis
  let supp (v : Fin n→Bool) := Finset.univ.filter fun x=>v x=true
  have decode (v : Fin n→Bool) : IncidencePointShield.bits (supp v)=v := by
    funext i
    cases e : v i <;> simp [supp,IncidencePointShield.bits,e]
  have count (v : Fin n→Bool) : (supp v).card=Fintype.card {i // v i=true} := by
    simpa only [decode] using (IncidencePointShield.bits_card (supp v)).symm
  have no := masks (supp a) (supp b) ((count a).le.trans h₁) ((count b).le.trans h₂)
    (fun x hx y hy=>dis x y (Finset.mem_filter.mp hx).2 (Finset.mem_filter.mp hy).2)
  simpa only [decode] using no
#print axioms domain
#print axioms bool_negatives
end IncidenceWarmDomain
