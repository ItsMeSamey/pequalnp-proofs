import IncidenceWarmPayment
namespace IncidenceWarmCompiler
open CircuitRewire IncidenceZeroRestriction
variable (m : ℕ) (code : ℕ→Gate) (drop : Finset ℕ) (fork : ℕ→Option ℕ)
def programAt (k : ℕ) := compileLiteral (2*m) m (stage m code fork) (init m drop) k

theorem refsStep (k : ℕ) :
    let p := programAt m code drop fork k
    let g := stage m code fork k
    (programAt m code drop fork (k+1)).refs =
      put p.refs (2*m+k)
        (forwarded (m+p.size) (literal g.op (p.refs g.left) (p.refs g.right))) := by
  dsimp only [programAt,compileLiteral]
  cases literal _ _ _ <;> rfl

theorem refsStable {a b i : ℕ} (hi : i<2*m+a) (hab : a≤b) :
    (programAt m code drop fork b).refs i=(programAt m code drop fork a).refs i := by
  induction b,hab using Nat.le_induction with
  | base => rfl
  | succ j hj ih =>
    rw [refsStep]
    simpa [put,show i≠2*m+j by omega] using ih

def presence (s i : ℕ) := bit ((programAt m code drop fork (2*s)).refs (addr m i))
def interim (j : ℕ) := bit ((programAt m code drop fork (2*j+1)).refs (2*m+2*j))

theorem raw_dead {s x : ℕ} (hx : x<m) (hd : x∈drop) :
    presence m code drop fork s x=0 := by
  unfold presence
  rw [show addr m x=x by simp [addr,hx],
    refsStable m code drop fork (a:=0) (by omega) (Nat.zero_le _)]
  simp [programAt,compileLiteral,init,hx,hd,bit]

theorem phase_cost {j x : ℕ} (hx : x<m) (pin : fork j=some x) :
    cost m code drop fork (2*j+1)=interim m code drop fork j := by
  let p := programAt m code drop fork (2*j+1)
  have raw : p.refs (m+x)=some x := by
    change (programAt m code drop fork (2*j+1)).refs (m+x)=some x
    rw [refsStable m code drop fork (a:=0) (by omega) (Nat.zero_le _)]
    simp [programAt,compileLiteral,init,show ¬m+x<m by omega]
  have gate : stage m code fork (2*j+1)=⟨.join,2*m+2*j,m+x⟩ := by simp [stage,show (2*j+1)/2=j by omega,pin]
  change emitted (literal (stage m code fork (2*j+1)).op
    (p.refs (stage m code fork (2*j+1)).left) (p.refs (stage m code fork (2*j+1)).right))=_
  rw [gate]
  change emitted (literal .join (p.refs (2*m+2*j)) (p.refs (m+x)))=_
  rw [raw]
  exact injection_cost _ _

theorem no_phase_cost {j : ℕ} (pin : fork j=none) :
    cost m code drop fork (2*j+1)=0 := by
  simp [cost,stage,show (2*j+1)/2=j by omega,pin,literal,emitted]

theorem row_form {j s : ℕ} (hj : j<s) (ord : (code j).left<m+j ∧ (code j).right<m+j) :
    let p := programAt m code drop fork (2*j)
    let l := p.refs (addr m (code j).left)
    let r := p.refs (addr m (code j).right)
    let a := literal (code j).op l r
    cost m code drop fork (2*j)=emitted a ∧
    interim m code drop fork j=bit (forwarded (m+p.size) a) ∧
    presence m code drop fork s (code j).left=bit l ∧
    presence m code drop fork s (code j).right=bit r := by
  let p := programAt m code drop fork (2*j)
  have gate : stage m code fork (2*j)=⟨(code j).op,addr m (code j).left,addr m (code j).right⟩ := by
    simp [stage]
  have bounded {w : ℕ} (hw : w<m+j) : addr m w<2*m+2*j := by
    unfold addr; split <;> omega
  refine ⟨?_,?_,?_,?_⟩
  · unfold cost
    simp only [gate] <;> rfl
  · unfold interim
    rw [refsStep,gate]
    simp [put]
  · exact congrArg bit (refsStable m code drop fork (bounded ord.1) (by omega : 2*j≤2*s))
  · exact congrArg bit (refsStable m code drop fork (bounded ord.2) (by omega : 2*j≤2*s))

def port (g : Gate) (side : Bool) := if side then g.right else g.left

theorem continuation_bound {j s : ℕ} (hj : j<s) (side : Bool)
    (ord : (code j).left<m+j ∧ (code j).right<m+j) :
    cost m code drop fork (2*j)+interim m code drop fork j ≤
      1+presence m code drop fork s (port (code j) side) := by
  obtain ⟨cc,oo,ll,rr⟩ := row_form m code drop fork hj ord
  cases side
  · simp only [port,Bool.false_eq_true,if_false]
    rw [cc,oo,ll]
    exact local_credit _ _ _ _ false
  · simp only [port,if_true]
    rw [cc,oo,rr]
    exact local_credit _ _ _ _ true

theorem first_bound {j s x : ℕ} (hj : j<s) (side : Bool) (hx : x<m) (hd : x∈drop)
    (used : port (code j) side=x) (op : (code j).op=.meet)
    (ord : (code j).left<m+j ∧ (code j).right<m+j) :
    cost m code drop fork (2*j)+interim m code drop fork j = 0 := by
  obtain ⟨cc,oo,ll,rr⟩ := row_form m code drop fork hj ord
  have absent := raw_dead m code drop fork (s:=s) hx hd
  rw [←used] at absent
  rw [cc,oo,op]
  cases side
  · simp only [port,Bool.false_eq_true,if_false,ll] at absent
    apply first_credit _ _ false
    cases e : (programAt m code drop fork (2*j)).refs (addr m (code j).left) <;>
      simp_all [bit]
  · simp only [port,if_true,rr] at absent
    apply first_credit _ _ true
    cases e : (programAt m code drop fork (2*j)).refs (addr m (code j).right) <;>
      simp_all [bit]

theorem unedited_presence {j s : ℕ} (hj : j<s) (pin : fork j=none) :
    presence m code drop fork s (m+j)=interim m code drop fork j := by
  have gate : stage m code fork (2*j+1)=⟨.copy,2*m+2*j,2*m+2*j⟩ := by simp [stage,show (2*j+1)/2=j by omega,pin]
  have ea : addr m (m+j)=2*m+(2*j+1) := by unfold addr; split <;> omega
  unfold presence interim
  rw [ea,refsStable m code drop fork (a:=2*j+1+1) (by omega) (by omega : 2*j+1+1≤2*s),refsStep,gate]
  simp [put,literal,forwarded]
end IncidenceWarmCompiler
