import IncidencePointWarmGood
import IncidenceChosenEnds

namespace IncidenceWarmDichotomy
open SparseIncidence IncidenceStartNormalization IncidencePointWarmMasks IncidenceReciprocalChoice IncidenceChosenEnds
variable {n : ℕ}
abbrev Warm (C : Circuit n) (I : Fin n → Fin n → Prop) (c : Fin n → ℕ)
    (x : Fin n) (J : Finset (Fin n)) : Prop :=
  ∃ W : Finset (Fin n), W.card ≤ 199 ∧ (∀ a ∈ J, ∀ l ∈ W, ¬ I a l) ∧
    mask {x} W ∈ C.wire (c x)

noncomputable def D (C : Circuit n) (I : Fin n → Fin n → Prop) (c : Fin n → ℕ)
    (owners : Finset (Fin n)) (x : Fin n) : Finset (Fin n) := by
  classical
  exact Finset.univ.filter fun y => x ∈ owners ∧ Warm C I c x {x} ∧ y ≠ x ∧
    ¬ Warm C I c x {x,y}

noncomputable def edits (C : Circuit n) (I : Fin n → Fin n → Prop) (c : Fin n → ℕ)
    (owners : Finset (Fin n)) (f : Fin n → Fin n) : Finset (Fin n) := by
  classical
  exact owners.filter fun x => Warm C I c x {x} ∧
    (D C I c owners x = ∅ ∨ removed f c x)

theorem mem_D (C : Circuit n) (I) (c : Fin n → ℕ) (O : Finset (Fin n)) (x y : Fin n) :
    y ∈ D C I c O x ↔ x ∈ O ∧ Warm C I c x {x} ∧ y ≠ x ∧ ¬ Warm C I c x {x,y} := by
  classical
  simp [D]

theorem dichotomy (C : Circuit n) (I : Fin n → Fin n → Prop) (c : Fin n → ℕ)
    (O : Finset (Fin n)) (f : Fin n → Fin n) (valid : Valid (D C I c O) f)
    (order : ∀ x, removed f c x → ∀ y ∈ D C I c O x,
      f y=x ∧ c y<c x ∧ ¬removed f c y)
    (J T : Finset (Fin n)) (j2 : J.card≤2) (t2 : T.card≤2)
    (ind : ∀ p ∈ J, ∀ l ∈ T, ¬I p l) :
    (∀ p ∈ J ∩ edits C I c O f, Warm C I c p J) ∨
    ∃ x y : Fin n, J={x,y} ∧ x∈edits C I c O f ∧ y∉edits C I c O f ∧ y∈O ∧ c y<c x ∧
      ∃ W : Finset (Fin n), W.card≤199 ∧ (∀ l ∈ T∪W, ¬I x l) ∧
        mask {y} T∉C.wire (c y) ∧ mask {x} W∈C.wire (c x) := by
  classical
  by_cases all : ∀ p ∈ J ∩ edits C I c O f, Warm C I c p J
  · exact Or.inl all
  obtain ⟨x,fail⟩ := Classical.not_forall.mp all
  have hxm : x ∈ J ∩ edits C I c O f := by
    by_contra no
    exact fail fun h => False.elim (no h)
  have bad : ¬Warm C I c x J := fun yes => fail fun _ => yes
  obtain ⟨xJ,xM⟩ := Finset.mem_inter.mp hxm
  obtain ⟨xO,warm,selected⟩ := Finset.mem_filter.mp (show x∈O.filter _ from xM)
  have other : ∃ y ∈ J, y≠x := by
    by_contra! no
    have eq : J={x} := Finset.ext fun z => by
      constructor
      · intro hz; exact Finset.mem_singleton.mpr (no z hz)
      · intro hz; simpa [Finset.mem_singleton.mp hz] using xJ
    apply bad
    rw [eq]
    exact warm
  obtain ⟨y,yJ,yx⟩ := other
  have sub : ({x,y} : Finset (Fin n)) ⊆ J := by
    intro z hz
    rcases Finset.mem_insert.mp hz with rfl|h
    · exact xJ
    · obtain rfl := Finset.mem_singleton.mp h
      exact yJ
  have pair : J={x,y} := (Finset.eq_of_subset_of_card_le sub (by simpa [yx.symm] using j2)).symm
  have yd := (mem_D C I c O x y).mpr ⟨xO,warm,yx,pair ▸ bad⟩
  have rx : removed f c x := selected.resolve_left fun e => by simpa [e] using yd
  obtain ⟨fy,earlier,ry⟩ := order x rx y yd
  have nd : (D C I c O y).Nonempty := by
    by_contra hn
    have eq : f y=y := by simpa [hn] using valid y
    exact yx (eq.symm.trans fy)
  have xd : x∈D C I c O y := by simpa [nd,fy] using valid y
  have noedit : y∉edits C I c O f := by
    intro hy
    rcases (Finset.mem_filter.mp (show y∈O.filter _ from hy)).2.2 with empty|removedY
    · simpa [empty] using xd
    · exact ry removedY
  have off : mask {y} T∉C.wire (c y) := by
    intro hot
    apply ((mem_D C I c O y x).mp xd).2.2.2
    refine ⟨T,by omega,?_,hot⟩
    intro z hz
    apply ind z
    rw [pair]
    simpa only [Finset.pair_comm y x] using hz
  obtain ⟨W,sz,safe,live⟩ := warm
  refine Or.inr ⟨x,y,pair,xM,noedit,((mem_D C I c O y x).mp xd).1,earlier,W,sz,?_,off,live⟩
  intro l hl
  rcases Finset.mem_union.mp hl with ht|hw
  · exact ind x xJ l ht
  · exact safe x (by simp) l hw
#print axioms dichotomy
end IncidenceWarmDichotomy
