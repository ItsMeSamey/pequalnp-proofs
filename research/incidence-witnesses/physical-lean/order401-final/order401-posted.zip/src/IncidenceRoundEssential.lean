import IncidenceRoundCompensation
import IncidenceThetaRoundDriver
namespace IncidenceRoundEssential
open SparseIncidence IncidenceStartNormalization IncidenceThetaRoundDriver IncidenceThetaRestrict
open IncidenceThetaBatchHoist IncidenceRoundReservations
variable {n : ℕ} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)}
theorem positive (a : Stage I P L) (x : ℕ) (hx : x∈kept a.A a.B) : 0<uses a.C x := by
  rcases Finset.mem_union.mp hx with hp|hl
  · obtain ⟨p,pa,rfl⟩ := Finset.mem_image.mp hp
    have neighbors := a.pointMin p pa
    obtain ⟨l,e⟩ := Finset.card_pos.mp (show 0<(N (rel I a.A a.B) false p).card by omega)
    exact used_of_edge a.C _ a.flag a.neg (y:=n+l.val) ⟨p,l,(Finset.mem_filter.mp e).2,Or.inl ⟨rfl,rfl⟩⟩
  · obtain ⟨l,lb,rfl⟩ := Finset.mem_image.mp hl
    have neighbors := a.lineMin l lb
    obtain ⟨p,e⟩ := Finset.card_pos.mp (show 0<(N (rel I a.A a.B) true l).card by omega)
    exact used_of_edge a.C _ a.flag a.neg (y:=p.val) ⟨p,l,(Finset.mem_filter.mp e).2,Or.inr ⟨rfl,rfl⟩⟩
end IncidenceRoundEssential
