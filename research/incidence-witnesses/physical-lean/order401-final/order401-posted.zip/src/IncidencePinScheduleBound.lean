import IncidencePhysicalPinExpectation

namespace IncidencePinScheduleBound
open scoped BigOperators

/-- Average a pointwise paid-plus-forced budget, cancelling the common sample multiplicity. -/
theorem bound {α : Type*} (S : Finset α) (f : α → ℕ) {q n j paid weight cap : ℕ}
    (hj : j ≤ q) (card : S.card=n*(q+1).choose (j+1))
    (expect : (q*q.choose j)*weight ≤ ∑i∈S,f i)
    (per : ∀i∈S, paid+f i ≤ cap) :
    (n*(q+1))*paid+((j+1)*q)*weight ≤ (n*(q+1))*cap := by
  let D := (q+1).choose (j+1)
  have pos : 0<D := Nat.choose_pos (Nat.succ_le_succ hj)
  have sum := Finset.sum_le_sum per
  simp only [Finset.sum_add_distrib, Finset.sum_const, nsmul_eq_mul,card] at sum
  have a := (Nat.add_le_add_left expect ((n*D)*paid)).trans sum
  have b := Nat.mul_le_mul_left (q+1) a
  have shift := Nat.add_one_mul_choose_eq q j
  change (q+1)*q.choose j=D*(j+1) at shift
  apply le_of_not_gt
  intro h
  have lt := Nat.mul_lt_mul_of_pos_left h pos
  have lhs : (q+1)*(n*D*paid+(q*q.choose j)*weight)=D*((n*(q+1))*paid+((j+1)*q)*weight) := by
    calc
      _ = D*((n*(q+1))*paid)+((q+1)*q.choose j)*(q*weight) := by ring
      _ = _ := by rw [shift]; ring
  rw [lhs] at b
  have rhs : (q+1)*(n*D*cap)=D*((n*(q+1))*cap) := by ring
  change _ ≤ (q+1)*(n*D*cap) at b
  rw [rhs] at b
  exact (not_lt_of_ge b) lt
end IncidencePinScheduleBound
