import IncidenceWarmTracePath
import IncidenceWarmTraceSchedule
namespace IncidenceWarmTraceBooking
open IncidenceStartNormalization IncidenceHoistReaders IncidencePointFirstFork IncidenceWarmTracePath
open IncidenceWarmCompiler IncidenceWarmTraceSchedule
variable {n : Nat} (C : Circuit n)

theorem flip (g : CircuitRewire.Gate) (b : Bool) :
    port g (!b)=operand g b := by cases b <;> rfl

theorem endpoint {j ks e} (p : Path C j ks e) : e∈j::ks ∧ next C (n+n+e)=none := by
  induction p with
  | finish h => exact ⟨by simp,h⟩
  | step _ _ _ _ _ ih => exact ⟨List.mem_cons_of_mem _ ih.1,ih.2⟩

theorem book {j ks e} (p : Path C j ks e) (owners : Finset Nat) (stop : Nat→Nat)
    (unique : ∀a∈owners,∀b∈owners,stop a=stop b → a=b)
    (last : ∀a∈owners,next C (n+n+stop a)=none) (x : Nat) (hx : x∈owners) (eq : stop x=e) :
    Corridor (n+n) C.size C.code (schedule owners stop) x j ks := by
  induction p with
  | finish h => exact .finish (eq ▸ terminal owners stop x hx unique)
  | @step j k ks e b link hk edge rest ih =>
    apply Corridor.step (absent owners stop j (by
      intro a ha same
      have h := last a ha
      rw [same,link] at h
      contradiction)) hk (!b) (by rw [flip]; exact edge)
    exact ih eq

theorem raw_start (u : Nat) (one : uses C u=1) (notOut : u≠C.output) :
    ∃ j b ks e, j<C.size ∧ port (C.code j) b=u ∧
      Path C j ks e ∧ IncidencePointFirstFork.fork C u=n+n+e := by
  obtain ⟨j,b,read,bound,edge,_⟩ := unique_reader C u one
  have link : next C u=some (n+n+j) := by simp [next,notOut,read]
  obtain ⟨ks,e,path,eq⟩ := exists_path C j bound
  exact ⟨j,!b,ks,e,bound,(flip _ b).trans edge,path,(after_read C link).trans eq⟩

#print axioms book
#print axioms raw_start
end IncidenceWarmTraceBooking
