import IncidenceThetaPlaneResidual
namespace IncidenceThetaRoundDriver
open SparseIncidence IncidenceStartNormalization IncidenceHoistPrune IncidenceThetaBatchHoist IncidenceThetaRestrict
variable {n : ℕ} (I : Fin n → Fin n → Prop) [DecidableRel I]

structure Stage (P L : Finset (Fin n)) where
  A : Finset (Fin n)
  B : Finset (Fin n)
  pointCore : P ⊆ A
  lineCore : L ⊆ B
  pointMin : ∀ u ∈ A, 2 < (N (rel I A B) false u).card
  lineMin : ∀ v ∈ B, 2 < (N (rel I A B) true v).card
  C : Circuit n
  bin : binary C
  flag : flags C (rel I A B)
  neg : negatives C (rel I A B) 3 3

def Paid {P L} (a b : Stage I P L) : Prop :=
  b.A ⊆ a.A ∧ b.B ⊆ a.B ∧
  b.C.size + 2*((a.A \ b.A).card + (a.B \ b.B).card) + 1 ≤ a.C.size

theorem iterate {P L} (s : Stage I P L) (rounds : ℕ)
    (progress : ∀ t < rounds, ∀ a : Stage I P L,
      a.C.size + 2*((s.A.card+s.B.card)-(a.A.card+a.B.card)) + t ≤ s.C.size →
      ∃ b, Paid I a b) :
    ∃ b : Stage I P L, b.C.size + 2*((s.A.card+s.B.card)-(b.A.card+b.B.card)) + rounds ≤ s.C.size ∧
      b.A ⊆ s.A ∧ b.B ⊆ s.B := by
  have run : ∀ t ≤ rounds, ∃ b : Stage I P L,
      b.C.size + 2*((s.A.card+s.B.card)-(b.A.card+b.B.card)) + t ≤ s.C.size ∧
      b.A ⊆ s.A ∧ b.B ⊆ s.B := by
    intro t
    induction t with
    | zero => exact fun _ => ⟨s,by simp,fun _ h => h,fun _ h => h⟩
    | succ t ih =>
      intro ht
      obtain ⟨a,paid,ha,hb⟩ := ih (by omega)
      obtain ⟨b,ba,bb,cost⟩ := progress t (by omega) a paid
      have h1 := Finset.card_sdiff_add_card_eq_card ba
      have h2 := Finset.card_sdiff_add_card_eq_card bb
      have h3 := Finset.card_le_card ha
      have h4 := Finset.card_le_card hb
      exact ⟨b,by omega,ba.trans ha,bb.trans hb⟩
  exact run rounds (by omega)
end IncidenceThetaRoundDriver
