import Research.IncidenceRobust
import Mathlib.Data.Finset.Powerset
namespace IncidencePinMultiplicity
open IncidenceRobust
open scoped BigOperators
variable {n q : ℕ} (I : Fin n→Fin n→Prop) [DecidableRel I]
def hitPins (p l : Fin n) (j : ℕ) :=
  (((points I l).erase p).powersetCard j).image (insert p)

theorem hitPins_card (degree : ∀l,Fintype.card {p // I p l}=q+1)
    {p l : Fin n} (inc : I p l) (j : ℕ) : (hitPins I p l j).card=q.choose j := by
  have pl : p∈points I l := by simpa [points] using inc
  have inj : Set.InjOn (insert p) (↑(((points I l).erase p).powersetCard j) : Set (Finset (Fin n))) := by
    intro a ha b hb eq
    have aa : p∉a := fun h => Finset.notMem_erase _ _ ((Finset.mem_powersetCard.mp ha).1 h)
    have bb : p∉b := fun h => Finset.notMem_erase _ _ ((Finset.mem_powersetCard.mp hb).1 h)
    simpa [Finset.erase_insert aa,Finset.erase_insert bb] using congrArg (fun s : Finset (Fin n) => s.erase p) eq
  rw [hitPins,Finset.card_image_of_injOn inj,Finset.card_powersetCard,
    Finset.card_erase_of_mem pl,points_card I degree]
  rfl

theorem hitPins_real {p l : Fin n} (inc : I p l) {j : ℕ} {T : Finset (Fin n)}
    (ht : T∈hitPins I p l j) : p∈T ∧ T⊆points I l ∧ T.card=j+1 := by
  obtain ⟨a,ha,rfl⟩ := Finset.mem_image.mp ht
  obtain ⟨ha,card⟩ := Finset.mem_powersetCard.mp ha
  have no : p∉a := fun h => Finset.notMem_erase _ _ (ha h)
  refine ⟨Finset.mem_insert_self _ _,Finset.insert_subset (by simpa [points] using inc)
    (ha.trans (Finset.erase_subset _ _)),?_⟩
  rw [Finset.card_insert_of_notMem no,card]

theorem hits_total (degree : ∀l,Fintype.card {p // I p l}=q+1)
    (unique : ∀ p r,p≠r → ∃! l,I p l ∧ I r l) (hq : 0<q) (hn : n=q^2+q+1)
    {p x : Fin n} (inc : I p x) (j : ℕ) :
    (∑ l∈(lines I p).erase x,(hitPins I p l j).card) = q*q.choose j := by
  have mem : x ∈ lines I p := by simpa [lines] using inc
  calc
    _ = ∑ _l∈(lines I p).erase x,q.choose j := by
      apply Finset.sum_congr rfl
      intro l hl
      exact hitPins_card I degree (by simpa [lines] using (Finset.mem_erase.mp hl).2) j
    _ = _ := by simp [Finset.card_erase_of_mem mem,lines_card I degree unique hq hn p]

/-- Fractions avoided: total samples n*choose(q+1,h) and per-site
multiplicity q*choose(q,h−1) give h*q/(n*(q+1)). -/
theorem marginal (n q j : ℕ) :
    (q*q.choose j)*(n*(q+1)) =
      (n*(q+1).choose (j+1))*(q*(j+1)) := by
  have e := Nat.add_one_mul_choose_eq q j
  calc
    _ = (n*q)*((q+1)*q.choose j) := by ac_rfl
    _ = _ := by rw [e]; ac_rfl

/-- At a fixed physical gate with a fixed owner line x, a pin experiment
cannot be attributed to two different eligible points. -/
theorem unique_hit (unique : ∀ p r,p≠r → ∃! l,I p l ∧ I r l)
    {x l p r : Fin n} (ne : x≠l) {j : ℕ} {T : Finset (Fin n)}
    (px : I p x) (rx : I r x) (pl : I p l) (rl : I r l)
    (_hp : T∈hitPins I p l j) (_hr : T∈hitPins I r l j) : p=r := by
  by_contra different
  obtain ⟨_,_,only⟩ := unique p r different
  exact ne ((only x ⟨px,rx⟩).trans (only l ⟨pl,rl⟩).symm)

#print axioms hits_total
end IncidencePinMultiplicity
