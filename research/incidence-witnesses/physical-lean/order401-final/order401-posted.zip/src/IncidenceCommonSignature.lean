import IncidenceNoExtra
namespace IncidenceCommonSignature
open IncidenceDenseSignature CircuitRewire
abbrev Masks := Finset ℕ
def Agrees (t : ℕ) (u v : Masks→Prop) := ∀ D,D.card≤t → (u D ↔ v D)

theorem common (n s t : ℕ) (g : ℕ→Gate) (v : ℕ→Masks→Prop)
    (inputs : ℕ→Sig ℕ) (des : ℕ→Bool) (owner : ℕ→ℕ)
    (raw : ∀ i<n,valid t (inputs i) ∧ Agrees t (v i) (high (inputs i)))
    (ord : ∀ j<s,(g j).left<n+j ∧ (g j).right<n+j)
    (bin : ∀ j<s,(g j).op=.meet ∨ (g j).op=.join)
    (join : ∀ j<s,(g j).op=.join → Agrees t (v (n+j)) (fun D=>v (g j).left D ∨ v (g j).right D))
    (priv : ∀ j<s,(g j).op=.meet → des j=true →
      (owner j=(g j).left ∨ owner j=(g j).right) ∧ Agrees t (v (n+j)) (v (owner j)))
    (other : ∀ j<s,(g j).op=.meet → des j=false →
      Agrees t (v (n+j)) (v (g j).left) ∧ Agrees t (v (g j).left) (v (g j).right)) :
    ∃ sig : ℕ→Sig ℕ,
      (∀ i<n+s, valid t (sig i) ∧ Agrees t (v i) (high (sig i))) ∧
      (∀ i<n,sig i=inputs i) ∧
      (∀ j<s,(g j).op=.join →sig (n+j)=merge t (sig (g j).left) (sig (g j).right)) ∧
      (∀ j<s,(g j).op=.meet → des j=true → sig (n+j)=sig (owner j)) ∧
      (∀ j<s,(g j).op=.meet → des j=false →
        sig (n+j)=sig (g j).left ∧ sig (g j).left=sig (g j).right) := by
  classical
  have rep : ∀ i<n+s,represented t (v i) := by
    intro i
    induction i using Nat.strong_induction_on with
    | ind i ih =>
      intro hi
      by_cases h : i<n
      · exact ⟨inputs i,raw i h⟩
      let j := i-n
      have e : n+j=i := by dsimp [j]; omega
      have js : j<s := by omega
      obtain ⟨l,r⟩ := ord j js
      rw [←e]
      rcases bin j js with hm|ho
      · suffices H : ∃ w,w<i ∧ Agrees t (v (n+j)) (v w) by
          obtain ⟨w,wi,ag⟩ := H
          obtain ⟨c,vc,hc⟩ := ih w wi (by omega)
          exact ⟨c,vc,fun D hd=>(ag D hd).trans (hc D hd)⟩
        cases p : des j with
        | false => exact ⟨(g j).left,by omega,(other j js hm p).1⟩
        | true =>
          obtain ⟨side,ag⟩ := priv j js hm p
          exact ⟨owner j,by rcases side with H|H <;> omega,ag⟩
      · obtain ⟨a,va,aa⟩ := ih _ (by omega : (g j).left<i) (by omega)
        obtain ⟨b,vb,bb⟩ := ih _ (by omega : (g j).right<i) (by omega)
        exact ⟨_,valid_merge t a b,fun D hd=>(join j js ho D hd).trans
          ((or_congr (aa D hd) (bb D hd)).trans (merge_high a b D hd).symm)⟩
  let sig := fun i=>if h : i<n+s then (rep i h).choose else none
  have spec (i : ℕ) (h : i<n+s) : valid t (sig i) ∧ Agrees t (v i) (high (sig i)) := by
    simpa [sig,h,Agrees] using (rep i h).choose_spec
  have transport (i j : ℕ) (hi : i<n+s) (hj : j<n+s) (ag : Agrees t (v i) (v j)) :
      sig i=sig j := eq_of_dense (spec i hi).1 (spec j hj).1 (fun D hd=>
        ((spec i hi).2 D hd).symm.trans ((ag D hd).trans ((spec j hj).2 D hd)))
  refine ⟨sig,spec,?_,?_,?_,?_⟩
  · intro i hi
    have a := spec i (by omega)
    exact eq_of_dense a.1 (raw i hi).1 (fun D hd=>(a.2 D hd).symm.trans ((raw i hi).2 D hd))
  · intro j hj ho
    obtain ⟨l,r⟩ := ord j hj
    have a := spec (n+j) (by omega)
    have b := spec (g j).left (by omega)
    have c := spec (g j).right (by omega)
    exact eq_of_dense a.1 (valid_merge t _ _) (fun D hd=>(a.2 D hd).symm.trans
      ((join j hj ho D hd).trans ((or_congr (b.2 D hd) (c.2 D hd)).trans (merge_high _ _ D hd).symm)))
  · intro j hj hm hp
    obtain ⟨side,ag⟩ := priv j hj hm hp
    obtain ⟨l,r⟩ := ord j hj
    exact transport _ _ (by omega) (by rcases side with H|H <;> omega) ag
  · intro j hj hm hp
    obtain ⟨a,b⟩ := other j hj hm hp
    obtain ⟨l,r⟩ := ord j hj
    exact ⟨transport _ _ (by omega) (by omega) a,transport _ _ (by omega) (by omega) b⟩
end IncidenceCommonSignature
