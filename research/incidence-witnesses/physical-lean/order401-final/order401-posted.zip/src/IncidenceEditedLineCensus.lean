import IncidenceLinePinSchedules
import IncidenceLineTwoSchedules
import IncidenceGateOwners
import IncidenceLineCollected
namespace IncidenceEditedLineCensus
open scoped BigOperators
open SparseIncidence IncidenceStartNormalization IncidenceLineColdSibling IncidenceLineGateBooking
open IncidenceLineRoutedSlots IncidenceGateOwners IncidenceHoistPrune
theorem from_transfer {n : ℕ} (C D : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (degree : ∀l,Fintype.card {p // I p l}=402)
    (unique : ∀p r,p≠r→∃!l,I p l∧I r l) (hn : n=161203)
    (bc : binary C) (pc : flags C I) (nc : negatives C I n 401)
    (bd : binary D) (ld : Live D) (pd : flags D I) (nd : negatives D I n 2)
    (charged : Finset (Fin n)) (w : Fin n→Fin n) (stop : Fin n→ℕ)
    (path : ∀x∈charged,Corridor C x (stop x))
    (cold : ∀x∈charged,(avoid I x (w x),single x)∉C.wire (stop x))
    (sep : ∀x∈charged,∀y∈charged,x≠y→w x=y→w y≠x)
    (edited : ℕ) (split : soleCount C n=edited+charged.card)
    (transfer : ∀ (owner : Fin C.size→Fin n) (book : Fin C.size→Finset (Fin n)),
      (∀g,∀p∈book g,eligible C I (owner g) g p) →
      ∃ (ownD : Fin D.size→Fin n) (bkD : Fin D.size→Finset (Fin n)) (removed : ℕ),
       (∀g,∀p∈bkD g,eligible D I (ownD g) g p) ∧
       (∑g,(book g).card)≤(∑g,(bkD g).card)+402*removed ∧ D.size+(edited+removed)≤646424) :
    soleCount C n ≤3382 := by
  classical
  obtain ⟨B,ok,distinct,mass⟩ := IncidenceLineCollected.collect C I degree unique bc pc nc charged w stop path cold sep
  obtain ⟨own,mem⟩ := reindex (by omega : 0<n) charged B distinct
  let U := charged.biUnion B
  obtain ⟨ownD,bk,removed,good,preserved,budget⟩ := transfer own (labels U) (by
    intro g p hp
    obtain ⟨memB,memC⟩ := mem g p hp
    exact ok (own g) memC (g,p) memB)
  obtain ⟨a,b⟩ := IncidenceLinePinSchedules.schedules D I degree unique hn bd ld pd nd ownD bk good
    (edited+removed) budget
  rw [cardinal] at preserved
  exact IncidenceLineTwoSchedules.census split mass preserved a b
end IncidenceEditedLineCensus
