import IncidencePointMerge
import IncidencePointWarmMasks
namespace IncidencePointWarmMasks
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
variable {n : Nat}

theorem change_one (C : Circuit n) (x : Fin n) (L : Fin n→Bool) (i : Nat)
    (hi : i<n+n) (ne : i≠x.val) :
    (((fun _=>false),L)∈C.wire i ↔ (single x,L)∈C.wire i) := by
  by_cases p : i<n
  · let q : Fin n:=⟨i,p⟩
    have diff : q≠x := by intro e; exact ne (congrArg Fin.val e)
    rw [(C.inputs q).1]
    change (false=true ↔ decide (q=x)=true)
    simp [diff]
  · let q : Fin n:=⟨i-n,by omega⟩
    rw [show i=n+q.val by dsimp [q]; omega,(C.inputs q).2]
    rfl

theorem native_merge (C : Circuit n) (I : Fin n→Fin n→Prop)
    (pos : flags C I) (neg : negatives C I 401 400) (x y l : Fin n)
    (ix : I x l) (iy : I y l) (g : Nat) (hg : g<C.size)
    (dx : shadow (n+n) C.code x.val (n+n+g) C.size C.output=false)
    (dy : shadow (n+n) C.code y.val (n+n+g) C.size C.output=false)
    (xr : shadow (n+n) C.code x.val (n+n+C.size) C.size (C.code g).right=false)
    (yl : shadow (n+n) C.code y.val (n+n+C.size) C.size (C.code g).left=false) :
    (C.code g).op≠.meet := by
  let L := single l
  let u : Input n := (fun _=>false,L)
  have up (a : Fin n) : Extends u (single a,L) := by
    constructor
    · intro i h; change false=true at h; cases h
    · exact fun i h=>h
  have reject : u∉C.wire C.output := by
    apply neg _ _ (by simp [u,Fintype.card_subtype]) _ (by intro p q h; cases h)
    have eq : L=bits {l} := by funext i; simp [L,single,bits]
    rw [eq,bits_card]
    simp
  exact merge_not_meet (n+n) C.size C.code C.wire C.earlier C.law x.val y.val g C.output
    u (single x,L) (single y,L) hg C.output_lt (change_one C x L) (change_one C y L)
    (monotone C _ (by omega) (up x)) (monotone C _ (by omega) (up y))
    dx dy xr yl reject (pos x l ix) (pos y l iy)
#print axioms native_merge
end IncidencePointWarmMasks
