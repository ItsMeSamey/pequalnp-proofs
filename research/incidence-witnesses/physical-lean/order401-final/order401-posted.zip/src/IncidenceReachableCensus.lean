import IncidenceThetaRoundDriver
import IncidenceRoundProtection
import IncidenceCleanupLabels
namespace IncidenceReachableCensus
open IncidenceThetaRoundDriver IncidenceLabelHistory IncidenceMarkTransition IncidenceCleanupLabels
variable {n : ℕ} {I : Fin n → Fin n → Prop} [DecidableRel I]
variable {P L : Finset (Fin n)}

def sites (A B : Finset (Fin n)) : Finset ℕ :=
  A.image Fin.val ∪ B.image (fun i => n+i.val)
def shot (s : Stage I P L) := snap s.C.size s.C.code (sites s.A s.B)

inductive Walk (s : Stage I P L) : Stage I P L → Finset ℕ → ℕ → Prop
  | start : Walk s s (vulnerable (shot s)) 0
  | step {a b hist spent debit} : Walk s a hist spent →
      Paid I a b → (shot b).live ⊆ (shot a).live →
      (∀x∈(shot a).live,0<(shot a).uses x) →
      (drops (shot a) (shot b) ∪ andLost (shot a) (shot b)).card ≤ 2*debit →
      Walk s b (hist ∪ (drops (shot a) (shot b) ∪ andLost (shot a) (shot b))) (spent+debit)

theorem census {s a : Stage I P L} {hist spent} (w : Walk s a hist spent)
    (cold : vulnerable (shot s)=∅) :
    (sole (shot a)).card ≤ (sole (shot s)).card+2*spent ∧
    hist.card≤2*spent ∧ vulnerable (shot a)⊆hist := by
  induction w with
  | start => simp [cold]
  | @step a b hist spent debit before paid sub pos shock ih =>
    obtain ⟨one,count,incl⟩ := ih
    have h := Finset.card_le_card (newly_sole (shot a) (shot b) sub pos)
    have un := Finset.card_union_le (sole (shot a)) (drops (shot a) (shot b))
    have ds := Finset.card_le_card (Finset.subset_union_left :
      drops (shot a) (shot b) ⊆ drops (shot a) (shot b) ∪ andLost (shot a) (shot b))
    have us := Finset.card_union_le hist (drops (shot a) (shot b) ∪ andLost (shot a) (shot b))
    refine ⟨by omega,by omega,?_⟩
    exact (newly_vulnerable _ _ sub pos).trans (Finset.union_subset_union incl (fun _ h=>h))

theorem caps {s a : Stage I P L} {hist spent} (w : Walk s a hist spent)
    (cold : vulnerable (shot s)=∅) (one : (sole (shot s)).card≤9843)
    (budget : spent≤1616) (pc : P.card=403) (lc : L.card=403)
    (M : Finset ℕ) (G : ℕ→Finset ℕ) (guard : (reserve M G).card≤564) :
    (sole (shot a)).card≤13075 ∧ ((sites P L ∪ reserve M G) ∪ hist).card≤4602 := by
  obtain ⟨sa,ha,_⟩ := census w cold
  have u := Finset.card_union_le (sites P L ∪ reserve M G) hist
  have v := Finset.card_union_le (sites P L) (reserve M G)
  have k := Finset.card_union_le (P.image Fin.val) (L.image (fun i=>n+i.val))
  have p := Finset.card_image_le (s:=P) (f:=Fin.val)
  have l := Finset.card_image_le (s:=L) (f:=fun i=>n+i.val)
  change (sites P L).card ≤ _ at k
  constructor <;> omega

structure Marks (nb : ℕ→Finset ℕ) (s : Stage I P L) where
  M : Finset ℕ
  G : ℕ→Finset ℕ
  safe : Safe nb (shot s).live M G
  low : ∀ x∈M,((shot s).live ∩ nb x).card≤26

theorem updateMarks {a b : Stage I P L} {nb : ℕ→Finset ℕ} (old : Marks nb a)
    (hist D : Finset ℕ) (avoid : Disjoint D ((sites P L ∪ reserve old.M old.G) ∪ hist))
    (small : D.card≤24) (actual : (shot b).live=(shot a).live \ D) :
    ∃ next : Marks nb b, reserve old.M old.G⊆reserve next.M next.G := by
  have dis : Disjoint D (reserve old.M old.G) := avoid.mono_right (fun _ hx =>
    Finset.mem_union_left _ (Finset.mem_union_right _ hx))
  obtain ⟨G',_,safe,keep,_⟩ := transition nb _ _ _ old.safe D dis small
  rw [← actual] at safe keep
  refine ⟨⟨_,G',safe,?_⟩,keep⟩
  intro x hx
  rcases Finset.mem_union.mp hx with oldx|fresh
  · apply (Finset.card_le_card _).trans (old.low x oldx)
    apply Finset.inter_subset_inter_right
    rw [actual]
    exact Finset.sdiff_subset
  · exact (Finset.mem_filter.mp fresh).2

theorem reserveBound {a : Stage I P L} {nb : ℕ→Finset ℕ} (marks : Marks nb a)
    (all gone : Finset ℕ) (live : all \ gone=(shot a).live)
    (inside : ∀x∈marks.M,nb x⊆all) (degree : ∀x∈marks.M,(nb x).card=402)
    (codeg : ∀x∈marks.M,∀y∈marks.M,x≠y→(nb x∩nb y).card≤1)
    (small : gone.card≤38808) : (reserve marks.M marks.G).card≤564 :=
  guard_count401 nb all gone marks.M marks.G inside degree
    (fun x hx=>live.symm ▸ marks.low x hx) codeg small marks.safe.triple
end IncidenceReachableCensus
