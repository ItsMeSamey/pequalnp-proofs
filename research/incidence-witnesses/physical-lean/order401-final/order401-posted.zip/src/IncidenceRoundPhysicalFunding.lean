import Mathlib.Algebra.BigOperators.Fin
import IncidencePhysicalOrCount
import IncidencePinLowLedger
namespace IncidenceRoundPhysicalFunding
open IncidenceStartNormalization IncidencePhysicalOrGroups IncidenceHoistPrune IncidenceOperandLedger
open scoped BigOperators
variable {n : ℕ} (C : Circuit n)
def above (S : Finset ℕ) := ∑ w ∈ S, (uses C w - 2)
def extra (S : Finset ℕ) := above C S + ∑ w∈Finset.range (n+n) \ S,uses C w
def singles (S : Finset ℕ) := S.filter (fun w=>uses C w=1)
theorem total : (∑i∈Finset.range (n+n),uses C i)+(∑g : Row C,uses C (wire C g))=2*C.size := by
  have ord (j) (hj : j<C.size) := C.earlier j hj
  have eq := IncidenceOperandLedger.flow C.code (fun _=>true) (n+n) C.size
    (fun j hj=>by have e := ord j hj; omega)
  simp only [zeros,bit,if_true,Int.reduceAdd,Finset.sum_const,Finset.card_range,
    IncidencePinLowLedger.fan_uses,mul_one] at eq
  change (∑i∈Finset.range (n+n),uses C i)+(∑j : Fin C.size,uses C (n+n+j.val))=2*C.size
  rw [← Finset.sum_range (f := fun j=>uses C (n+n+j))] 
  change (∑i∈Finset.range (n+n),uses C i)+(∑j∈Finset.range C.size,uses C (n+n+j))=2*C.size
  exact_mod_cast (by simpa [nsmul_eq_mul,mul_comm] using eq.symm :
    (∑i∈Finset.range (n+n),(uses C i : ℤ))+(∑j∈Finset.range C.size,(uses C (n+n+j):ℤ))=2*(C.size:ℤ))
theorem gate_floor (live : Live C) :
    C.size+excess C ≤ 1+∑g : Row C,uses C (wire C g) := by
  classical
  let W := fun g : Row C=>wire C g
  let O := (Finset.univ : Finset (Row C)).filter (fun g=>W g=C.output)
  have oc : O.card≤1 := Finset.card_le_one.mpr (by
    intro g hg h hh
    have e := (Finset.mem_filter.mp hg).2.trans (Finset.mem_filter.mp hh).2.symm
    apply Fin.ext
    dsimp [W,wire] at e
    omega)
  have term (g : Row C) :
      1+(if W g=C.output then 0 else uses C (W g)-1) ≤
        (if W g=C.output then 1 else 0)+uses C (W g) := by
    split
    next e => simp [e]
    next e =>
      have pos := IncidencePinLowLedger.ancestor_port (live g g.isLt) e
      change 0 < uses C (W g) at pos
      simp only [if_neg e, zero_add]; omega
  have t := Finset.sum_le_sum (s:=Finset.univ) (fun g _=>term g)
  rw [Finset.sum_add_distrib,Finset.sum_add_distrib] at t
  have card : ∑g : Row C, (if W g=C.output then 1 else 0)=O.card := by exact Finset.sum_boole _ _
  rw [card] at t
  simpa [excess,W] using t.trans (Nat.add_le_add_right oc _)

theorem budget (S : Finset ℕ) (range : S⊆Finset.range (n+n))
    (pos : ∀w∈S,0<uses C w) (live : Live C) :
    2*S.card + excess C + extra C S ≤ C.size+1+(singles C S).card := by
  classical
  have rawRow (w) (hw : w∈S) : 2+(uses C w-2) ≤ (if uses C w=1 then 1 else 0)+uses C w := by
    have := pos w hw
    split <;> omega
  have rs : (∑w∈S,(2+(uses C w-2) : ℕ))≤∑w∈S,((if uses C w=1 then 1 else 0)+uses C w) := Finset.sum_le_sum rawRow
  rw [Finset.sum_add_distrib,Finset.sum_add_distrib] at rs
  have singleCard : (∑w∈S,if uses C w=1 then 1 else 0)=(singles C S).card := by
    exact Finset.sum_boole _ _
  rw [singleCard] at rs
  have eq := total C
  have gb := gate_floor C live
  have ub := Finset.sum_sdiff (f := fun w=>uses C w) range
  simp only [Finset.sum_const,nsmul_eq_mul,Nat.cast_id] at rs
  unfold extra above
  omega
end IncidenceRoundPhysicalFunding
