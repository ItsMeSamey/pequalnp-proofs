import IncidenceReachableCensus
namespace IncidenceReachableCensus
open IncidenceStartNormalization IncidenceForwardPins IncidenceSurvivingReads IncidenceCleanupLabels IncidenceLabelHistory
theorem read_count {n} (C : Circuit n) (live : Finset ℕ) (x : ℕ) :
    (snap C.size C.code live).uses x=uses C x := by
  change ((pins C.size).filter _).card=_
  rw [Finset.card_filter]
  simp only [pins,Finset.sum_product]
  let f := fun j : ℕ => (if (C.code j).left=x then 1 else 0)+(if (C.code j).right=x then 1 else 0)
  have eq (j : ℕ) : (∑ b : Bool, if readPin C.code (j,b)=x then 1 else 0)=f j := by
    rw [show (Finset.univ : Finset Bool)={false,true} by decide, Finset.sum_insert (by decide : false∉({true} : Finset Bool)), Finset.sum_singleton]
    rfl
  simp only [eq]
  change ∑ j∈Finset.range C.size,f j=((List.range C.size).map f).sum
  generalize C.size=k
  induction k with
  | zero => simp
  | succ k ih => simp [Finset.sum_range_succ,List.range_succ,ih]

theorem initial_count {n} (C : Circuit n) (A B : Finset (Fin n)) :
    (sole (snap C.size C.code (sites A B))).card≤soleCount C 0+soleCount C n := by
  let V := (Finset.range n).filter (fun i=>uses C (0+i)=1)
  let W := (Finset.range n).filter (fun i=>uses C (n+i)=1)
  have sub : sole (snap C.size C.code (sites A B))⊆V ∪ W.image (fun i=>n+i) := by
    intro x hx
    obtain ⟨live,one⟩ := Finset.mem_filter.mp hx
    rw [read_count] at one
    change x∈sites A B at live
    rcases Finset.mem_union.mp live with a|b
    · obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp a
      exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨Finset.mem_range.mpr i.isLt,by simpa using one⟩)
    · obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp b
      exact Finset.mem_union_right _ (Finset.mem_image.mpr ⟨i.val,Finset.mem_filter.mpr ⟨Finset.mem_range.mpr i.isLt,one⟩,rfl⟩)
  exact (Finset.card_le_card sub).trans ((Finset.card_union_le ..).trans (Nat.add_le_add_left Finset.card_image_le _))
theorem initial_cold {n} (C : Circuit n) (hp : soleAnd C 0) (hl : soleAnd C n)
    (A B : Finset (Fin n)) :
    vulnerable (snap C.size C.code (sites A B))=∅ := by
  apply Finset.eq_empty_iff_forall_notMem.mpr
  intro x hx
  obtain ⟨mem,one,dark⟩ := Finset.mem_filter.mp hx
  have actual := read_count C (sites A B) x
  have pos : 0<((pins C.size).filter (fun p => readPin C.code p=x)).card := by
    change ((pins C.size).filter _).card=1 at one
    omega
  obtain ⟨p,pp⟩ := Finset.card_pos.mp pos
  obtain ⟨inp,reads⟩ := Finset.mem_filter.mp pp
  have j := (mem_pins p C.size).mp inp
  have atPin : (C.code p.1).left=x ∨ (C.code p.1).right=x := by
    cases b : p.2 <;> simp [readPin,b] at reads <;> tauto
  have meet : (C.code p.1).op=.meet := by
    change x ∈ sites A B at mem
    rcases Finset.mem_union.mp mem with a|b
    · obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp a
      exact hp _ i.isLt (by simpa using actual.symm.trans one) _ j (by simpa using atPin)
    · obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp b
      exact hl _ i.isLt (actual.symm.trans one) _ j atPin
  exact (of_decide_eq_false dark) ⟨p,Finset.mem_filter.mpr ⟨inp,reads,meet⟩⟩
end IncidenceReachableCensus
