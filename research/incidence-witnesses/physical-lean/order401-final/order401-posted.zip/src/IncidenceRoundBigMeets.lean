import IncidenceRoundDenseSignature
import IncidenceRoundPhysicalMove
import IncidenceNoSmallMeet
namespace IncidenceRoundBigMeets
open CircuitRewire IncidenceStartNormalization IncidenceDenseSignature IncidenceRoundReservations
open IncidenceThetaRoundDriver IncidenceRoundPhysicalMove IncidenceRoundDenseSignature
variable {n : ℕ} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)}
theorem physical (a : Stage I P L) (E : Finset ℕ) (stop : ¬Witness a E)
    (bin : binary a.C) (sig : ℕ→Sig ℕ) (des : ℕ→Bool) (own : ℕ→ℕ)
    (raw : ∀ i<n+n,sig i=inputSig E i)
    (small : ∀ j<a.C.size,(sig (n+n+j)).isSome=true → uses a.C (n+n+j)≤1)
    (join : ∀ j<a.C.size,(a.C.code j).op=.join →
      sig (n+n+j)=merge 24 (sig (a.C.code j).left) (sig (a.C.code j).right))
    (priv : ∀ j<a.C.size,(a.C.code j).op=.meet → des j=true →
       (own j=(a.C.code j).left ∨ own j=(a.C.code j).right) ∧
       own j∈sole a.C E ∧ own j<n+n ∧ sig (n+n+j)=sig (own j))
    (other : ∀ j<a.C.size,(a.C.code j).op=.meet → des j=false →
       sig (n+n+j)=sig (a.C.code j).left ∧ sig (a.C.code j).left=sig (a.C.code j).right) :
    ∀ j<a.C.size,(a.C.code j).op=.meet → des j=false →
       sig (a.C.code j).left=none ∧ sig (a.C.code j).right=none := by
  refine IncidenceEarliestSmall.no_small_meet (n+n) a.C.size 24 a.C.code a.C.wire
    sig des own (sole a.C E) a.C.earlier a.C.law ?_ ?_ ?_ ?_
    (fun j hj=>(bin j hj).symm) join ?_ other
  · intro j hj
    exact no_alias a stop ⟨j,hj⟩ _ (a.C.earlier j hj).1
  · intro i hi A hs
    rw [raw i hi] at hs
    by_cases h : i∈E <;> simp_all [inputSig]
  · intro x hx
    have one := (Finset.mem_filter.mp hx).2
    rw [IncidencePinLowLedger.fan_uses,one]
    decide
  · intro j hj sm
    rw [IncidencePinLowLedger.fan_uses]
    exact_mod_cast small j hj sm
  · intro j hj hm hd
    obtain ⟨side,mem,bound,eq⟩ := priv j hj hm hd
    exact ⟨side,mem,(raw _ bound).trans (if_pos (Finset.mem_filter.mp mem).1),eq⟩
#print axioms physical
end IncidenceRoundBigMeets
