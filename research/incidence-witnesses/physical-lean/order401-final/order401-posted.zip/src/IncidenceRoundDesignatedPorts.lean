import IncidenceRoundCompensation
import IncidencePhysicalOrCount
namespace IncidenceRoundDesignatedPorts
open CircuitRewire IncidenceStartNormalization IncidencePhysicalOrGroups
open IncidenceHoistReaders IncidenceRoundReservations
variable {n : ℕ} (C : Circuit n) (E : Finset ℕ)
def rows := (Finset.univ : Finset (Row C)).filter (fun g=>g.val∈designated C E)
noncomputable def side (g : Row C) := (reader C (owned C E g.val)).2
theorem bound : (rows C E).card≤(sole C E).card := by
  classical
  let id : Row C ↪ ℕ := ⟨Fin.val,Fin.val_injective⟩
  have sub : (rows C E).map id⊆designated C E := by
    intro j hj
    obtain ⟨g,hg,rfl⟩ := Finset.mem_map.mp hj
    exact (Finset.mem_filter.mp hg).2
  have h := Finset.card_le_card sub
  rw [Finset.card_map] at h
  exact h.trans Finset.card_image_le
theorem slots (range : E⊆Finset.range (n+n))
    (meet : ∀x∈sole C E,(C.code (owner C x)).op=.meet) :
    (∀g∈rows C E,(C.code g).op=.meet) ∧
    (∀g∈rows C E,operand (C.code g) (side C E g)<n+n) := by
  constructor <;> intro g hg
  · obtain ⟨hx,e⟩ := owned_spec C E (Finset.mem_filter.mp hg).2
    have m := meet _ hx
    rwa [e] at m
  · obtain ⟨hx,e⟩ := owned_spec C E (Finset.mem_filter.mp hg).2
    obtain ⟨_,slot,_⟩ := read_unique C (Finset.mem_filter.mp hx).2
    rw [e] at slot
    change operand (C.code g) (reader C (owned C E g.val)).2<n+n
    rw [slot]
    exact Finset.mem_range.mp (range (Finset.mem_filter.mp hx).1)
end IncidenceRoundDesignatedPorts
