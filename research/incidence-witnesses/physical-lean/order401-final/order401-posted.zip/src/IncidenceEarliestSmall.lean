import IncidenceSmallMass

namespace IncidenceEarliestSmall
open CircuitRewire IncidenceDenseSignature IncidenceOperandLedger IncidenceSmallMass
open scoped BigOperators

def carries {α : Type*} [DecidableEq α] (x : α) (v : Sig α) : ℤ :=
  match v with
  | none => 0
  | some A => if x∈A then 1 else 0

theorem carrying {α : Type*} [DecidableEq α] (x : α) (t : ℕ) (l r out : Sig α)
    (mode : out=l ∨ out=r ∨ out=merge t l r) :
    carries x out ≤ carries x l+carries x r := by
  rcases mode with e|e|e <;> subst out <;> cases l <;> cases r <;>
    simp [carries,merge] <;> split_ifs <;> simp_all <;> omega

/-- A label whose only raw source has at most one occurrence cannot arrive at both
pins of row k through small unbranched wires. Later rows may use arbitrary gates.
The truncation zeros the mass at the target output itself. -/
theorem not_both (n s k t x : ℕ) (g : ℕ→Gate) (sig : ℕ→Sig ℕ)
    (ks : k<s) (ord : ∀ j<s,(g j).left<n+j ∧ (g j).right<n+j)
    (raw : (∑ i∈Finset.range n,fan g s i*carries x (sig i))≤1)
    (unbranched : ∀ j<s,(sig (n+j)).isSome=true → fan g s (n+j)≤1)
    (mode : ∀ j<k,sig (n+j)=sig (g j).left ∨ sig (n+j)=sig (g j).right ∨
      sig (n+j)=merge t (sig (g j).left) (sig (g j).right)) :
    ¬(carries x (sig (g k).left)=1 ∧ carries x (sig (g k).right)=1) := by
  classical
  rintro ⟨left,right⟩
  let a := fun i => if i<n+k then carries x (sig i) else 0
  have nn (i : ℕ) : 0≤a i := by
    dsimp [a]
    cases h : sig i <;> simp [carries] <;> split_ifs <;> omega
  have gstep (j : ℕ) (hj : j<s) :
      a (n+j)+(if j=k then (2:ℤ) else 0) ≤ a (g j).left+a (g j).right := by
    obtain ⟨hl,hr⟩ := ord j hj
    rcases lt_trichotomy j k with lt|eq|gt
    · simpa [a,show n+j<n+k by omega,show (g j).left<n+k by omega,
        show (g j).right<n+k by omega,lt.ne] using
        carrying x t _ _ _ (mode j lt)
    · subst j
      simp [a,hl,hr,left,right]
    · have := nn (g j).left
      have := nn (g j).right
      have az : a (n+j)=0 := if_neg (by omega)
      rw [az,if_neg gt.ne']
      omega
  have internal (j : ℕ) (hj : j<s) : fan g s (n+j)*a (n+j)≤a (n+j) := by
    by_cases nz : a (n+j)=0
    · simp [nz]
    · have hs : (sig (n+j)).isSome=true := by
        cases h : sig (n+j) <;> simp_all [a,carries]
      exact (Int.mul_le_mul_of_nonneg_right (unbranched j hj hs) (nn _)).trans_eq (one_mul _)
  have rg : (∑ i∈Finset.range n,fan g s i*a i)≤1 := by
    convert raw using 1
    apply Finset.sum_congr rfl
    intro i hi
    simp [a,show i<n+k by have := Finset.mem_range.mp hi; omega]
  have total := flow n s g a (fun j hj=>by obtain ⟨l,r⟩ := ord j hj; exact ⟨by omega,by omega⟩)
  have iSum := Finset.sum_le_sum (fun j (hj : j∈Finset.range s)=>internal j (Finset.mem_range.mp hj))
  have gSum := Finset.sum_le_sum (fun j (hj : j∈Finset.range s)=>gstep j (Finset.mem_range.mp hj))
  rw [Finset.sum_add_distrib] at gSum
  simp [Finset.sum_ite_eq',Finset.mem_range.mpr ks] at gSum
  omega

/-- For a small target support T avoiding sole owners, every earlier small
subsignature contained in T is the full-domain OR of its raw coordinates. A
private token is disallowed by its actual sole label, without identifying its
full-domain function with that label. -/
theorem full_or {Z : Type*} (n k : ℕ) (g : ℕ→Gate) (sig : ℕ→Sig ℕ)
    (X : ℕ→Set Z) (T sole : Finset ℕ) (avoid : Disjoint T sole)
    (raw : ∀ i<n,∀ A,sig i=some A → A={i})
    (ord : ∀ j<k,(g j).left<n+j ∧ (g j).right<n+j)
    (sem : ∀ j<k,X (n+j)=(g j).eval X)
    (earlier : ∀ j<k,∀ A,sig (n+j)=some A →
        (∃ x∈sole,x∈A) ∨
        ((g j).op=.join ∧ ∃ L R,sig (g j).left=some L ∧ sig (g j).right=some R ∧ A=L∪R)) :
    ∀ i<n+k,∀ A,sig i=some A → A⊆T → ∀ z, z∈X i ↔ ∃ x∈A,z∈X x := by
  intro i
  induction i using Nat.strong_induction_on with
  | ind i ih =>
    intro hi A hs sub z
    by_cases old : i<n
    · rw [raw i old A hs]
      simp
    · let j := i-n
      have idx : n+j=i := by dsimp [j]; omega
      have jk : j<k := by omega
      rw [←idx] at hs ⊢
      rcases earlier j jk A hs with ⟨x,hx,ha⟩ | ⟨join,L,R,hl,hr,rfl⟩
      · exact False.elim (Finset.disjoint_left.mp avoid (sub ha) hx)
      · obtain ⟨ol,orr⟩ := ord j jk
        have le := ih _ (by omega : (g j).left<i) (by omega) L hl (Finset.subset_union_left.trans sub) z
        have re := ih _ (by omega : (g j).right<i) (by omega) R hr (Finset.subset_union_right.trans sub) z
        rw [sem j jk]
        simp only [Gate.eval,join,Op.eval,Set.mem_union,le,re,Finset.mem_union]
        aesop

theorem redundant {Z : Type*} (n k : ℕ) (g : ℕ→Gate) (X : ℕ→Set Z)
    (T : Finset ℕ) (meet : (g k).op=.meet) (sem : X (n+k)=(g k).eval X)
    (left : ∀ z,z∈X (g k).left ↔ ∃ x∈T,z∈X x)
    (right : ∀ z,z∈X (g k).right ↔ ∃ x∈T,z∈X x) :
    X (n+k)=X (g k).left := by
  have same : X (g k).left=X (g k).right := Set.ext (fun z=>(left z).trans (right z).symm)
  simp [sem,Gate.eval,meet,Op.eval,←same]

theorem single_raw (n s x : ℕ) (g : ℕ→Gate) (sig : ℕ→Sig ℕ)
    (raw : ∀ i<n,∀ A,sig i=some A → A={i}) (one : fan g s x≤1) :
    (∑ i∈Finset.range n,fan g s i*carries x (sig i))≤1 := by
  classical
  have bound := Finset.sum_le_sum (s:=Finset.range n)
    (g:=fun i=>if i=x then fan g s x else 0)
    (f:=fun i=>fan g s i*carries x (sig i)) (fun i hi=>by
      cases e : sig i with
      | none =>
        by_cases eq : i=x
        · subst i
          have nonneg : 0≤fan g s x := Finset.sum_nonneg (fun j _=>by
            unfold occ
            split_ifs <;> omega)
          simpa [carries] using nonneg
        · simp [carries,eq]
      | some A =>
        have ha := raw i (Finset.mem_range.mp hi) A e
        subst A
        by_cases eq : i=x
        · subst i; simp [carries]
        · simp [carries,eq,Ne.symm eq])
  by_cases present : x<n <;> simp [Finset.sum_ite_eq',present] at bound <;> omega

theorem earliest {Z : Type*} (n s k t : ℕ) (g : ℕ→Gate) (sig : ℕ→Sig ℕ)
    (X : ℕ→Set Z) (sole T : Finset ℕ) (ks : k<s)
    (ord : ∀ j<s,(g j).left<n+j ∧ (g j).right<n+j)
    (sem : ∀ j<s,X (n+j)=(g j).eval X)
    (raw : ∀ i<n,∀ A,sig i=some A → A={i})
    (once : ∀ x∈sole,fan g s x≤1)
    (unbranched : ∀ j<s,(sig (n+j)).isSome=true → fan g s (n+j)≤1)
    (mode : ∀ j<k,sig (n+j)=sig (g j).left ∨ sig (n+j)=sig (g j).right ∨
      sig (n+j)=merge t (sig (g j).left) (sig (g j).right))
    (earlier : ∀ j<k,∀ A,sig (n+j)=some A → (∃ x∈sole,x∈A) ∨
       ((g j).op=.join ∧ ∃ L R,sig (g j).left=some L ∧ sig (g j).right=some R ∧ A=L∪R))
    (meet : (g k).op=.meet) (ll : sig (g k).left=some T) (rr : sig (g k).right=some T) :
    X (n+k)=X (g k).left := by
  have avoid : Disjoint T sole := Finset.disjoint_left.mpr (fun x hx hxS=>
    not_both n s k t x g sig ks ord (single_raw n s x g sig raw (once x hxS)) unbranched mode
      ⟨by simp [ll,carries,hx],by simp [rr,carries,hx]⟩)
  have exp := full_or n k g sig X T sole avoid raw (fun j hj=>ord j (hj.trans ks))
    (fun j hj=>sem j (hj.trans ks)) earlier
  exact redundant n k g X T meet (sem k ks)
    (exp _ (ord k ks).1 T ll (fun _ h=>h))
    (exp _ (ord k ks).2 T rr (fun _ h=>h))

end IncidenceEarliestSmall
