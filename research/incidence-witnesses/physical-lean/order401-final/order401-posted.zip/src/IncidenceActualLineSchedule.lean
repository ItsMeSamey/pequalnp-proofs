import IncidenceActualLineChoice
import IncidenceLineWarmMasks
import IncidenceWarmShoreSchedule
namespace IncidenceActualLineChoice
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceWarmCompiler IncidenceWarmShoreSchedule
open IncidenceWarmTraceFamily IncidenceWarmTraceSchedule IncidencePointFirstFork
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]

theorem install (pos : flags C I) (neg : negatives C I n 401) (andL : soleAnd C n)
    (degree : ∀l,Fintype.card {p // I p l}=402) (join : ∀p r,p≠r→∃!l,I p l∧I r l)
    (hn : n=161203) (f : Fin n→Fin n) :
    ∃inject,IncidenceLineWarm.Wiring C (M C I f) inject (rank C) ∧
      (run (n+n) C.code (IncidenceLineWarm.drops (M C I f)) inject C.size).size+(M C I f).card≤C.size := by
  classical
  let S := M C I f
  let L := owners n S
  have ids {u : Nat} (h : u∈L) : ∃x∈S,n+x.val=u := (id_mem n S u).mp h
  have raw (u) (hu : u∈L) : u<n+n := by obtain ⟨x,_,rfl⟩ := ids hu; have := x.isLt; omega
  have sole (x) (hx : x∈S) : uses C (n+x.val)=1 := (Finset.mem_filter.mp (Finset.mem_filter.mp hx).1).2
  have one (u) (hu : u∈L) : uses C u=1 := by obtain ⟨x,hx,rfl⟩ := ids hu; exact sole x hx
  have no : negatives C I 2 2 := fun a b pa pb => neg a b (by omega) (by omega)
  have n2 : negatives C I n 2 := fun a b pa pb => neg a b pa (by omega)
  have unique := line_unique C I pos n2 degree join S (fun x hx=>hot_witness C I x (Finset.mem_filter.mp hx).2.1)
  obtain ⟨start,side,tail,ok,nd,bd,covers⟩ := family C I no L (ids_nodup n S) raw one
    (shore_meet C n S andL sole) unique
  let i := schedule L.toFinset (stop C)
  have drop : L.toFinset=IncidenceLineWarm.drops S := by ext a; simp [L,owners,IncidenceLineWarm.drops]
  refine ⟨i,⟨?_,?_⟩,?_⟩
  · intro j _ a h
    obtain ⟨mem,eq⟩ := (wiring C I no L raw one unique j a).mp h
    obtain ⟨p,hp,rfl⟩ := ids mem
    exact ⟨p,hp,rfl,eq.symm⟩
  · intro p hp
    have mem : n+p.val∈L := (id_mem n S _).mpr ⟨p,hp,rfl⟩
    obtain ⟨_,_,_,e,_,_,_,eq⟩ := IncidenceWarmTraceBooking.raw_start C _ (sole p hp)
      (not_output C I no _ (raw _ mem))
    have b := IncidenceWarmTraceShadow.fork_bound C (by have := p.isLt; omega : n+p.val<n+n+C.size)
    exact ⟨e,by omega,(wiring C I no L raw one unique e _).mpr ⟨mem,eq.symm⟩,eq⟩
  · have len : L.length=S.card := by simp [L,owners]
    change (run (n+n) C.code (IncidenceLineWarm.drops S) i C.size).size+S.card≤C.size
    rw [←len,←drop]
    apply common_payment L (fun x=>start x::tail x) _ nd bd (fun j _=>covers j)
    intro x hx
    obtain ⟨hj,port,op,path⟩ := ok x hx
    exact owner_payment C.earlier (raw x hx) (by simpa using hx) hj _ port op path
#print axioms install
end IncidenceActualLineChoice
