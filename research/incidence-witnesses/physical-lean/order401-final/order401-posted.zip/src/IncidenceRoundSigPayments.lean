import IncidenceRoundDenseSignature
import IncidenceSmallMass
namespace IncidenceRoundSigPayments
open CircuitRewire IncidenceStartNormalization IncidenceDenseSignature IncidenceSmallMass
open IncidenceRoundReservations IncidenceRoundDenseSignature IncidenceOperandLedger
variable {n : ℕ} (C : Circuit n) (E : Finset ℕ) (sig : ℕ→Sig ℕ)

theorem unbranched
    (spec : ∀ i<n+n+C.size,valid 24 (sig i) ∧ IncidenceCommonSignature.Agrees 24 (val C E i) (high (sig i)))
    (shared : ∀ j<C.size,2≤uses C (n+n+j) → ∀ D⊆E,D.card≤24 → row n D∈C.wire (n+n+j)) :
    ∀ j<C.size,(sig (n+n+j)).isSome=true → uses C (n+n+j)≤1 := by
  intro j js sm
  by_contra! h
  obtain ⟨v,ag⟩ := spec (n+n+j) (by omega)
  cases eq : sig (n+n+j) with
  | none => simp [eq] at sm
  | some A =>
    have sz : A.card≤24 := by simpa [eq,valid] using v
    have hot := shared j js (by omega) (A∩E) Finset.inter_subset_right
      ((Finset.card_le_card Finset.inter_subset_left).trans sz)
    have impossible := (ag A sz).mp hot
    rw [eq] at impossible
    exact impossible (fun _ mem=>mem)

theorem raw_mass (raw : ∀ i<n+n,sig i=inputSig E i)
    (reads : ∀ i∈E,uses C i≤2) :
    ∀i<n+n,fan C.code C.size i*mass (sig i)≤2 := by
  intro i hi
  rw [raw i hi,IncidencePinLowLedger.fan_uses]
  by_cases h : i∈E
  · simpa [inputSig,h,mass] using (show (uses C i:ℤ)≤2 by exact_mod_cast reads i h)
  · simp [inputSig,h,mass]

theorem all_modes (des : ℕ→Bool) (own : ℕ→ℕ) (bin : binary C)
    (join : ∀j<C.size,(C.code j).op=.join →sig (n+n+j)=merge 24 (sig (C.code j).left) (sig (C.code j).right))
    (priv : ∀j<C.size,(C.code j).op=.meet → des j=true →
      (own j=(C.code j).left ∨ own j=(C.code j).right) ∧ sig (n+n+j)=sig (own j))
    (other : ∀j<C.size,(C.code j).op=.meet → des j=false → sig (n+n+j)=sig (C.code j).left) :
    ∀ j<C.size,sig (n+n+j)=sig (C.code j).left ∨ sig (n+n+j)=sig (C.code j).right ∨
       sig (n+n+j)=merge 24 (sig (C.code j).left) (sig (C.code j).right) := by
  intro j hj
  rcases bin j hj with ho|hm
  · exact Or.inr (Or.inr (join j hj ho))
  · cases e : des j with
    | false => exact Or.inl (other j hj hm e)
    | true =>
      obtain ⟨side,h⟩ := priv j hj hm e
      rcases side with a|b
      · exact Or.inl (h.trans (congrArg sig a))
      · exact Or.inr (Or.inl (h.trans (congrArg sig b)))

#print axioms unbranched
end IncidenceRoundSigPayments
