import IncidenceRoundCompensation
import IncidenceRoundDenseSignature
import IncidencePhysicalOrGroups
namespace IncidenceRoundOrdinaryPorts
open CircuitRewire IncidenceStartNormalization IncidenceHoistReaders IncidenceDenseSignature
open IncidencePhysicalOrGroups IncidenceRoundReservations IncidenceRoundDenseSignature
variable {n : ℕ} (C : Circuit n) (E : Finset ℕ)
theorem ports (bin : binary C) (sig : ℕ→Sig ℕ)
    (range : E⊆Finset.range (n+n))
    (raw : ∀i<n+n,sig i=inputSig E i)
    (large : ∀j<C.size,(C.code j).op=.meet → j∉designated C E →
      sig (C.code j).left=none ∧ sig (C.code j).right=none)
    (high : ∀D⊆E,D.card≤24 → ∀o∈sole C E,dead C D (sib C o)=false)
    {x : ℕ} (hx : x∈E) (two : uses C x=2) (g : Row C) (b : Bool) (pin : Reads C g x b) :
    (C.code g).op=.join := by
  classical
  rcases bin g g.isLt with op|op
  · exact op
  exfalso
  have sx : sig x=some {x} := by rw [raw x (Finset.mem_range.mp (range hx))]; simp [inputSig,hx]
  by_cases tag : g.val∈designated C E
  · let o := owned C E g.val
    obtain ⟨ho,eq⟩ := owned_spec C E tag
    have one : uses C o=1 := (Finset.mem_filter.mp ho).2
    have neq : x≠o := by intro e; rw [e] at two; omega
    obtain ⟨_,port,_⟩ := read_unique C one
    change owner C o=g.val at eq
    rw [eq] at port
    have opposite : b≠(reader C o).2 := by
      intro same
      change operand (C.code g) b=x at pin
      rw [same,port] at pin
      exact neq pin.symm
    have same : sib C o=x := by
      simp only [sib,eq]
      cases z : (reader C o).2 <;> cases b <;> simp_all [Reads,operand]
    have cold := high {x} (by simpa) (by simp) o ho
    rw [same] at cold
    have hot := (raw_flag C (Finset.mem_range.mp (range hx)) {x}).mpr (Finset.mem_singleton_self x)
    simp_all
  · obtain ⟨l,r⟩ := large g g.isLt op tag
    cases b <;> simp [Reads,operand] at pin <;> simp_all
end IncidenceRoundOrdinaryPorts
