import IncidenceActualLineChoice
namespace IncidenceActualLineChoice
open SparseIncidence IncidenceStartNormalization IncidenceChosenEnds IncidenceReciprocalChoice
open IncidenceLineGateBooking
variable {n : Nat} (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
def full (x : Fin n) (J : Finset (Fin n)) : Prop :=
  ((fun p=>decide (∀ l∈J,¬I p l)),single x)∈C.wire (rank C x)

theorem pair_full (x y : Fin n) : full C I x {x,y} ↔ hot C I x y := by
  unfold full hot avoid
  have eq : (fun p=>decide (∀l∈({x,y} : Finset (Fin n)),¬I p l))=(fun p=>decide (¬I p x ∧ ¬I p y)) := by
    funext p; simp
  rw [eq]

theorem cases_for_mask (f : Fin n→Fin n) (valid : Valid (D C I) f)
    (order : ∀x,removed f (rank C) x → ∀y∈D C I x,f y=x ∧ rank C y<rank C x ∧ ¬removed f (rank C) y)
    (J : Finset (Fin n)) (j2 : J.card≤2) :
    (∀x∈J∩M C I f,full C I x J) ∨
      ∃x y,J={x,y} ∧ x∈M C I f ∧ y∉M C I f ∧ rank C y<rank C x ∧
        ¬hot C I y x ∧ hot C I x x := by
  classical
  by_cases all : ∀ p ∈ J ∩ M C I f, full C I p J
  · exact Or.inl all
  obtain ⟨x,fail⟩ := Classical.not_forall.mp all
  have hxm : x ∈ J ∩ M C I f := by
    by_contra no
    exact fail fun h => False.elim (no h)
  have bad : ¬full C I x J := fun yes => fail fun _ => yes
  obtain ⟨xJ,xM⟩ := Finset.mem_inter.mp hxm
  obtain ⟨xO,warm,selected⟩ := Finset.mem_filter.mp (show x∈(O C).filter _ from xM)
  have other : ∃ y ∈ J, y≠x := by
    by_contra! no
    have eq : J={x} := Finset.ext fun z => by
      constructor
      · intro hz; exact Finset.mem_singleton.mpr (no z hz)
      · intro hz; simpa [Finset.mem_singleton.mp hz] using xJ
    apply bad
    simpa [eq] using (pair_full C I x x).mpr warm
  obtain ⟨y,yJ,yx⟩ := other
  have sub : ({x,y} : Finset (Fin n)) ⊆ J := by
    intro z hz
    rcases Finset.mem_insert.mp hz with rfl|h
    · exact xJ
    · obtain rfl := Finset.mem_singleton.mp h
      exact yJ
  have pair : J={x,y} := (Finset.eq_of_subset_of_card_le sub (by simpa [yx.symm] using j2)).symm
  have yd := (memD C I x y).mpr ⟨xO,warm,yx,fun h=>bad (pair ▸ (pair_full C I x y).mpr h)⟩
  have rx : removed f (rank C) x := selected.resolve_left fun e => by simpa [e] using yd
  obtain ⟨fy,earlier,ry⟩ := order x rx y yd
  have nd : (D C I y).Nonempty := by
    by_contra hn
    have eq : f y=y := by simpa [hn] using valid y
    exact yx (eq.symm.trans fy)
  have xd : x∈D C I y := by simpa [nd,fy] using valid y
  have noedit : y∉M C I f := by
    intro hy
    rcases (Finset.mem_filter.mp (show y∈(O C).filter _ from hy)).2.2 with empty|removedY
    · simpa [empty] using xd
    · exact ry removedY
  exact Or.inr ⟨x,y,pair,xM,noedit,earlier,((memD C I y x).mp xd).2.2.2,warm⟩
#print axioms cases_for_mask
end IncidenceActualLineChoice
