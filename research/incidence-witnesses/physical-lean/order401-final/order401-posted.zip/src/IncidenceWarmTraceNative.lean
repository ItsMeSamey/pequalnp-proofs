import IncidenceWarmTracePath
namespace IncidenceWarmTraceNative
open IncidenceStartNormalization IncidencePointFirstFork IncidencePointCorridor
variable {n : Nat} (C : Circuit n)

inductive Native : {a b : Nat} → Path (n+n) C.code a b → Prop where
  | nil (w : Nat) (terminal : next C w=none) : Native (.nil w)
  | cons (g : Nat) (b : Bool) {out : Nat} {p : Path (n+n) C.code (n+n+g) out}
      (edge : next C (inputPort (C.code g) b)=some (n+n+g)) (rest : Native p) :
      Native (.cons g b p)
end IncidenceWarmTraceNative
