import IncidenceSoleAndRetention
namespace IncidenceThetaSibling
open IncidenceZeroRestriction CircuitRewire IncidenceSoleAndRetention

/-- The unique raw must change its reserved gate on the original pair/singleton
comparison. Either pin may carry it. The opposite operand is unchanged by that
raw, hence accepts the singleton that survives the restriction. -/
theorem physical {Z : Type*} (m s x j o : ℕ) (g : ℕ→Gate) (X : ℕ→Set Z)
    (ord : ∀k<s,OrderedBinary (g k) (m+k)) (sem : ∀k<s,X (m+k)=(g k).eval X)
    (js : j<s) (kind : (g j).op=.meet) (side : Bool)
    (only : ∀k<s,k≠j → (g k).left≠x ∧ (g k).right≠x)
    (other : (if side then (g j).left else (g j).right)≠x)
    (out : o<m+s) (diff : o≠x) (a b : Z)
    (agree : ∀i<m,i≠x → (a∈X i ↔ b∈X i)) (on : a∈X o) (off : b∉X o) :
    b∈X (if side then (g j).left else (g j).right) := by
  let A := test X b
  let B := test X a
  have init (i) (hi : i<m) (hx : i≠x) : A i=B i :=
    Set.ext fun _=>(agree i hi hx).symm
  have order (k) (hk : k<s) := (show (g k).left<m+k ∧ (g k).right<m+k from
    ⟨(ord k hk).1,(ord k hk).2.1⟩)
  have av (k) (hk : k<s) : A (m+k)=(g k).eval A := test_gate _ _ _ _ (sem k hk)
  have bv (k) (hk : k<s) : B (m+k)=(g k).eval B := test_gate _ _ _ _ (sem k hk)
  let w := if side then (g j).left else (g j).right
  have wb : w<m+j := by cases side <;> simp_all [w]
  have eqw : A w=B w := IncidenceSoleReservation.equal_except m j x j g A B init
    (fun k hk=>order k (hk.trans js)) (fun k hk=>only k (hk.trans js))
    (fun k hk=>av k (hk.trans js)) (fun k hk=>bv k (hk.trans js))
    (fun h=>False.elim ((Nat.lt_irrefl _) h)) w wb other
  by_contra lo
  have empty : A w=∅ := by ext u; cases u; simpa [A,test,w] using lo
  have empty' : B w=∅ := eqw ▸ empty
  have same : A (m+j)=B (m+j) := by
    rw [av j js,bv j js]
    cases side <;> simp_all [w,Gate.eval,kind,Op.eval]
  have outEq := IncidenceSoleReservation.equal_except m s x j g A B init order only av bv
    (fun _=>same) o out diff
  exact off ((Set.ext_iff.mp outEq ()).mpr on)

/-- Raising the surviving singleton to the dense retained row preserves every
positive gate value. This compares original rows before any literal rewiring. -/
theorem monotone_row {Z : Type*} (m s : ℕ) (g : ℕ→Gate) (X : ℕ→Set Z) (a b : Z)
    (raw : ∀i<m,a∈X i → b∈X i)
    (ord : ∀k<s,OrderedBinary (g k) (m+k)) (sem : ∀k<s,X (m+k)=(g k).eval X) :
    ∀w<m+s,a∈X w → b∈X w := by
  intro w
  induction w using Nat.strong_induction_on with
  | ind w ih =>
    intro bound
    by_cases h : w<m
    · exact raw _ h
    · let j := w-m
      have eq : m+j=w := by dsimp [j]; omega
      have js : j<s := by omega
      have lr := ord j js
      have ll : (g j).left<w := eq ▸ lr.1
      have rr : (g j).right<w := eq ▸ lr.2.1
      have left := ih (g j).left ll (ll.trans bound)
      have right := ih (g j).right rr (rr.trans bound)
      rw [←eq,sem j js]
      cases op : (g j).op <;> simp [Gate.eval,op,Op.eval] <;> tauto

#print axioms monotone_row
#print axioms physical
end IncidenceThetaSibling
