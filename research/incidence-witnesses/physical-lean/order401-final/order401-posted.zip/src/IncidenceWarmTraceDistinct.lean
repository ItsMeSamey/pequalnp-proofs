import IncidencePointForeign
namespace IncidenceWarmTraceDistinct
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield IncidenceRobust
variable {n : Nat} (I : Fin n→Fin n→Prop) [DecidableRel I] (C : Circuit n)

theorem separate (pos : flags C I) (neg : negatives C I 401 400) (x y l : Fin n)
    (outsider : ¬I x l) (hit : I y l) (W : Finset (Fin n)) (small : W.card≤399)
    (clean : ∀a∈W,¬I x a) (cut : Nat) (bound : cut<n+n+C.size)
    (warm : (single x,bits W)∈C.wire cut) :
    shadow (n+n) C.code y.val cut C.size C.output≠false := by
  intro blocked
  let S := insert l W
  let u : Input n := (bits {x},bits S)
  let v : Input n := (bits {x,y},bits S)
  have up : Extends (single x,bits W) u := by
    refine ⟨fun i h=>?_,fun i h=>?_⟩
    · simpa [u,bits,single] using h
    · simpa [u,bits,S] using (Finset.mem_insert_of_mem (by simpa [bits] using h : i∈W) : i∈insert l W)
  have grow : Extends u v := by
    refine ⟨fun i h=>?_,fun _ h=>h⟩
    have eq : i=x := by simpa [u,bits] using h
    simp [v,bits,eq]
  have first := monotone C cut bound up warm
  have second := monotone C cut bound grow first
  have raw (i : Nat) (hi : i<n+n) (ne : i≠y.val) : u∈C.wire i ↔ v∈C.wire i := by
    by_cases low : i<n
    · let p : Fin n := ⟨i,low⟩
      have diff : p≠y := fun e => ne (congrArg Fin.val e)
      rw [(C.inputs p).1]
      change bits {x} p=true ↔ bits {x,y} p=true
      simp [bits,diff]
    · let a : Fin n := ⟨i-n,by omega⟩
      have eq : i=n+a.val := by dsimp [a]; omega
      rw [eq,(C.inputs a).2]
      rfl
  have same := shield (n+n) C.size C.code C.wire C.earlier C.law y.val cut u v raw
    ⟨fun _=>second,fun _=>first⟩ C.output C.output_lt blocked
  have no : u∉C.wire C.output := by
    apply neg
    · change Fintype.card {p // bits {x} p=true}≤401
      rw [bits_card]; simp
    · change Fintype.card {a // bits S a=true}≤400
      rw [bits_card]
      exact (Finset.card_insert_le _ _).trans (by omega)
    · intro p a hp ha
      have px : p=x := by simpa [u,bits] using hp
      subst p
      have mem : a=l ∨ a∈W := by simpa [u,bits,S] using ha
      rcases mem with rfl|old
      · exact outsider
      · exact clean a old
  apply no (same.mpr _)
  apply monotone C C.output C.output_lt _ (pos y l hit)
  refine ⟨fun i h=>?_,fun i h=>?_⟩
  · have eq : i=y := by simpa [single] using h
    simp [v,bits,eq]
  · have eq : i=l := by simpa [single] using h
    simp [v,bits,S,eq]

theorem outsider (degree : ∀ l,Fintype.card {p // I p l}=402)
    (unique : ∀ a b,a≠b → ∃! l,I a l ∧ I b l) (hn : n=161203) (x y : Fin n) (ne : x≠y) :
    ∃l,¬I x l ∧ I y l := by
  by_contra! bad
  have incl : lines I y ⊆ lines I x := by
    intro l h
    have inc := (Finset.mem_filter.mp h).2
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,by_contra (fun h=>bad l h inc)⟩
  have cap := line_overlap I unique ne.symm
  rw [Finset.inter_eq_left.mpr incl,lines_card I degree unique (by decide : 0<401) (by omega)] at cap
  omega
#print axioms separate
end IncidenceWarmTraceDistinct
