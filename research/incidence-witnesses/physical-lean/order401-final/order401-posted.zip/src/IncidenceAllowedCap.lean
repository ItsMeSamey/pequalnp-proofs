import IncidenceAllowedGeometry
import IncidenceRoundPhysicalMove
namespace IncidenceAllowedCap
open IncidenceAllowedGeometry IncidenceThetaRestrict IncidencePhysicalPaidRound IncidenceThetaRoundDriver IncidenceMarkTransition
variable {n : ℕ} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)}
theorem physical (a : Stage I P L) (M : Finset ℕ) (G : ℕ→Finset ℕ)
    (prot : Finset ℕ) (safe : Safe (neighbors I) (kept a.A a.B) M G)
    (core : kept P L⊆prot) (guards : reserve M G⊆prot)
    (stop : ¬IncidenceRoundPhysicalMove.Witness a (kept a.A a.B\prot))
    (D : Finset ℕ) (inside : D⊆kept a.A a.B\prot) (small : D.card≤24) :
    a.C.size≤minorSize I a (nextP a.A D) (nextL a.B D)+2*D.card := by
  obtain ⟨legal,_⟩ := allowed I a M G safe D prot core guards inside small
  have free : kept a.A a.B \ kept (nextP a.A D) (nextL a.B D) ⊆ kept a.A a.B \ prot := by
    rw [next_eq]
    intro i h
    obtain ⟨live,remain⟩ := Finset.mem_sdiff.mp h
    exact inside (by
      by_contra off
      exact remain (Finset.mem_sdiff.mpr ⟨live,off⟩))
  have bound := IncidenceRoundPhysicalMove.no_extra a stop legal free
  rwa [deleted_card _ _ _ (inside.trans Finset.sdiff_subset)] at bound
end IncidenceAllowedCap
