import IncidenceGroupPhysicalDemand
namespace IncidenceGroupNativeIds
open IncidenceStartNormalization IncidenceRobust IncidenceGroupPlaneTests IncidencePhysicalOrGroups
variable {n : ℕ}

theorem injective : Function.Injective (@wireId n) := by
  intro a b
  cases a with
  | inl p =>
    cases b with
    | inl r => intro h; exact congrArg Sum.inl (Fin.ext h)
    | inr l => intro h; change p.val=n+l.val at h; have := p.isLt; omega
  | inr l =>
    cases b with
    | inl p => intro h; change n+l.val=p.val at h; have := p.isLt; omega
    | inr k =>
      intro h
      change n+l.val=n+k.val at h
      exact congrArg Sum.inr (Fin.ext (Nat.add_left_cancel h))

def sites (n : ℕ) (T : Finset ℕ) : Finset (Vertex n) :=
  (Finset.univ.disjSum (Finset.univ : Finset (Fin n))).filter (fun x=>wireId x∈T)
theorem card_le (T : Finset ℕ) : (sites n T).card≤T.card := by
  rw [←Finset.card_image_of_injective _ injective]
  apply Finset.card_le_card
  intro i hi
  obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hi
  exact (Finset.mem_filter.mp (show v∈(Finset.univ.disjSum (Finset.univ : Finset (Fin n))).filter (fun x=>wireId x∈T) from hv)).2
theorem card_eq (T : Finset ℕ) (bound : ∀i∈T,i<n+n) : (sites n T).card=T.card := by
  apply le_antisymm (card_le T)
  rw [←Finset.card_image_of_injective _ injective]
  apply Finset.card_le_card
  intro i hi
  obtain ⟨v,rfl⟩ := IncidenceGroupPhysicalDemand.raw_split (bound i hi)
  refine Finset.mem_image.mpr ⟨v,?_,rfl⟩
  apply Finset.mem_filter.mpr
  exact ⟨by cases v <;> simp,hi⟩

theorem demand (C : Circuit n) (I J : Fin n→Fin n→Prop) [DecidableRel I] [DecidableRel J]
    (join : ∀p r,p≠r→∃!l,I p l∧I r l) (sub : ∀p l,J p l→I p l)
    (pos : flags C J) (neg : negatives C J 3 3) (live prot sole : Finset ℕ)
    (bound : ∀i∈live,i<n+n)
    (degree : ∀x : Vertex n,wireId x∈(live\prot)\sole→2<(adj J x).card)
    (ports : ∀i∈(live\prot)\sole,∀g b,Reads C g i b→(C.code g).op=.join)
    (two : ∀i∈(live\prot)\sole,uses C i=2) :
    live.card≤sole.card+prot.card+2*(IncidenceGroupPhysicalDemand.tops C).card := by
  have mem (v : Vertex n) (h : v∈(sites n live\sites n prot)\sites n sole) :
      wireId v∈(live\prot)\sole := by cases v <;> simpa [sites] using h
  have h := IncidenceGroupPhysicalDemand.residual C I J join sub pos neg _ _ _
    (fun v hv=>degree v (mem v hv)) (fun v hv=>ports _ (mem v hv)) (fun v hv=>two _ (mem v hv))
  rw [card_eq live bound] at h
  have hs := card_le (n:=n) sole
  have hp := card_le (n:=n) prot
  omega
end IncidenceGroupNativeIds
#print axioms IncidenceGroupNativeIds.demand
