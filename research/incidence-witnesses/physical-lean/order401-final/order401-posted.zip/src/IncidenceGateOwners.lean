import IncidenceLineGateBooking
namespace IncidenceGateOwners
open scoped BigOperators
variable {n s : ℕ}
def labels (B : Finset (Fin s×Fin n)) (g : Fin s) :=
  Finset.univ.filter (fun p => (g,p)∈B)
theorem cardinal (B : Finset (Fin s×Fin n)) :
    (∑g,(labels B g).card)=B.card := by
  classical
  let part (g : Fin s) := B.filter (fun z=>z.1=g)
  have localEq (g : Fin s) : (labels B g).card=(part g).card := by
    let put : Fin n ↪ Fin s×Fin n := ⟨fun p=>(g,p),fun _ _ h=>congrArg Prod.snd h⟩
    have eq : (labels B g).map put=part g := by
      ext z
      rcases z with ⟨f,p⟩
      constructor
      · intro h
        obtain ⟨u,hu,eq⟩ := Finset.mem_map.mp h
        change (g,u)=(f,p) at eq
        cases eq
        exact Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp hu).2,rfl⟩
      · intro h
        obtain ⟨h,eq⟩ := Finset.mem_filter.mp h
        change f=g at eq
        subst f
        exact Finset.mem_map.mpr ⟨p,Finset.mem_filter.mpr ⟨Finset.mem_univ _,h⟩,rfl⟩
    rw [←eq,Finset.card_map]
  have sep : ((Finset.univ : Finset (Fin s)) : Set (Fin s)).PairwiseDisjoint part := by
    intro x _ y _ ne
    apply Finset.disjoint_left.mpr
    intro z l r
    exact ne ((Finset.mem_filter.mp l).2.symm.trans (Finset.mem_filter.mp r).2)
  have total : Finset.univ.biUnion part=B := by ext z; simp [part]
  calc
    _ = ∑g,(part g).card := Finset.sum_congr rfl (fun g _=>localEq g)
    _ = _ := (Finset.card_biUnion sep).symm.trans (congrArg Finset.card total)
theorem reindex (hN : 0<n) (charged : Finset (Fin n)) (B : Fin n→Finset (Fin s×Fin n))
    (unique : ∀x∈charged,∀y∈charged,∀u∈B x,∀v∈B y,u.1=v.1→x=y) :
    ∃owner : Fin s→Fin n,∀g,∀p∈labels (charged.biUnion B) g,(g,p)∈B (owner g) ∧ owner g∈charged := by
  classical
  let has (g : Fin s) := ∃ x∈charged, ∃ u∈B x,u.1=g
  let owner (g : Fin s) := if h : has g then h.choose else ⟨0,hN⟩
  refine ⟨owner,?_⟩
  intro g p hp
  obtain ⟨x,hx,z⟩ := Finset.mem_biUnion.mp (Finset.mem_filter.mp hp).2
  have h : has g := ⟨x,hx,(g,p),z,rfl⟩
  obtain ⟨hh,u,hu,same⟩ := h.choose_spec
  have eq := unique x hx h.choose hh (g,p) z u hu same.symm
  have ow : owner g=h.choose := dif_pos h
  rw [ow,←eq]
  exact ⟨z,hx⟩
#print axioms cardinal
end IncidenceGateOwners
