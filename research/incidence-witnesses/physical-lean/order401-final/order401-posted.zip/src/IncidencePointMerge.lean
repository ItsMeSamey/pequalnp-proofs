import IncidencePointShield
namespace IncidencePointShield
open CircuitRewire

theorem hot_at_cut {Z : Type*} (m s : Nat) (code : Nat→Gate) (X : Nat→Set Z)
    (ord : ∀ a<s,(code a).left<m+a ∧ (code a).right<m+a)
    (sem : ∀ a<s,X (m+a)=(code a).eval X) (x cut out : Nat) (u v : Z)
    (inputs : ∀ i<m,i≠x → (u∈X i ↔ v∈X i)) (mono : u∈X cut → v∈X cut)
    (endIndex : out<m+s) (paths : shadow m code x cut s out=false)
    (no : u∉X out) (yes : v∈X out) : v∈X cut := by
  by_contra off
  exact no ((shield m s code X ord sem x cut u v inputs
    ⟨mono,fun hv=>(off hv).elim⟩ out endIndex paths).mpr yes)

theorem absent_path {Z : Type*} (m s : Nat) (code : Nat→Gate) (X : Nat→Set Z)
    (ord : ∀ a<s,(code a).left<m+a ∧ (code a).right<m+a)
    (sem : ∀ a<s,X (m+a)=(code a).eval X) (x : Nat) (u v : Z)
    (inputs : ∀ i<m,i≠x → (u∈X i ↔ v∈X i)) (i : Nat) (hi : i<m+s)
    (mark : shadow m code x (m+s) s i=false) : u∈X i ↔ v∈X i := by
  let X' := put X (m+s) ∅
  have same (j : Nat) (hj : j<m+s) : X' j=X j := by simp [X',put,show j≠m+s by omega]
  have laws (j : Nat) (hj : j<s) : X' (m+j)=(code j).eval X' := by
    obtain ⟨a,b⟩ := ord j hj
    rw [same _ (by omega),sem j hj]
    simp only [Gate.eval,same _ (show (code j).left<m+s by omega),same _ (show (code j).right<m+s by omega)]
  have h := shield m s code X' ord laws x (m+s) u v
    (fun j hj ne=>by rw [same j (by omega)]; exact inputs j hj ne)
    (by simp [X',put]) i hi mark
  simpa only [same i hi] using h

theorem merge_not_meet {Z : Type*} (m s : Nat) (code : Nat→Gate) (X : Nat→Set Z)
    (ord : ∀ a<s,(code a).left<m+a ∧ (code a).right<m+a)
    (sem : ∀ a<s,X (m+a)=(code a).eval X) (x y g out : Nat) (u v w : Z)
    (hg : g<s) (endIndex : out<m+s)
    (xin : ∀ i<m,i≠x → (u∈X i ↔ v∈X i)) (yin : ∀ i<m,i≠y → (u∈X i ↔ w∈X i))
    (mx : u∈X (m+g) → v∈X (m+g)) (my : u∈X (m+g) → w∈X (m+g))
    (domx : shadow m code x (m+g) s out=false) (domy : shadow m code y (m+g) s out=false)
    (xAway : shadow m code x (m+s) s (code g).right=false)
    (yAway : shadow m code y (m+s) s (code g).left=false)
    (no : u∉X out) (xYes : v∈X out) (yYes : w∈X out) : (code g).op≠.meet := by
  intro op
  have f0 := low_at_cut m s code X ord sem x (m+g) out u v xin mx endIndex domx no xYes
  have fx := hot_at_cut m s code X ord sem x (m+g) out u v xin mx endIndex domx no xYes
  have fy := hot_at_cut m s code X ord sem y (m+g) out u w yin my endIndex domy no yYes
  have eq : X (m+g)=X (code g).left∩X (code g).right := by
    simpa [Gate.eval,Op.eval,op] using sem g hg
  rw [eq] at f0 fx fy
  obtain ⟨l,r⟩ := ord g hg
  exact f0 ⟨(absent_path m s code X ord sem y u w yin _ (by omega) yAway).mpr fy.1,
    (absent_path m s code X ord sem x u v xin _ (by omega) xAway).mpr fx.2⟩
#print axioms merge_not_meet
end IncidencePointShield
