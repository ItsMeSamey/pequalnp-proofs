import IncidenceLineRoutedSlots
open scoped BigOperators
namespace IncidenceWarmBookPush
theorem push {a b n : ℕ} (hn : 0<n) (owner : Fin a→Fin n) (book : Fin a→Finset (Fin n))
    (key : ℕ→ℕ) (valid : ∀g : Fin a,(book g).Nonempty→key g<b)
    (inj : ∀g h : Fin a,(book g).Nonempty→(book h).Nonempty→key g=key h→g=h)
    (P : Fin b→Fin n→Fin n→Prop)
    (works : ∀g : Fin a,∀p∈book g,∀bound : key g<b,P ⟨key g,bound⟩ (owner g) p) :
    ∃ (own : Fin b→Fin n) (bk : Fin b→Finset (Fin n)),
       (∀j,∀p∈bk j,P j (own j) p) ∧ (∑g,(book g).card)=(∑j,(bk j).card) := by
  classical
  let S := Finset.univ.filter (fun g : Fin a=>(book g).Nonempty)
  have ne (g : S) : (book g.val).Nonempty := (Finset.mem_filter.mp g.property).2
  let em : S ↪ Fin b := ⟨fun g=>⟨key g.val,valid g.val (ne g)⟩,by
    intro g h e
    exact Subtype.ext (inj g.val h.val (ne g) (ne h) (congrArg Fin.val e))⟩
  let pre (j : Fin b) := ∃g:S, em g=j
  let own (j : Fin b) := if h:pre j then owner h.choose.val else ⟨0,hn⟩
  let bk (j : Fin b) := if h:pre j then book h.choose.val else ∅
  have atEm (g : S) : own (em g)=owner g.val ∧ bk (em g)=book g.val := by
    have h : pre (em g) := ⟨g,rfl⟩
    have eq := em.injective h.choose_spec
    simp [own,bk,h,eq]
  refine ⟨own,bk,?_,?_⟩
  · intro j p hp
    by_cases h : pre j
    · rw [←h.choose_spec] at hp ⊢
      rw [(atEm _).2] at hp
      rw [(atEm _).1]
      exact works _ _ hp _
    · simp [bk,h] at hp
  · have src : (∑g,(book g).card)=∑g:S,(book g.val).card := by
      rw [Finset.sum_coe_sort S (fun g=>(book g).card)]
      symm
      apply Finset.sum_subset (Finset.subset_univ _)
      intro g _ hg
      have empty : book g=∅ := Finset.not_nonempty_iff_eq_empty.mp (by simpa [S] using hg)
      simp [empty]
    have dest : (∑j,(bk j).card)=∑g:S,(bk (em g)).card := by
      rw [←Finset.sum_map Finset.univ em (fun j=>(bk j).card)]
      symm
      apply Finset.sum_subset (Finset.subset_univ _)
      intro j _ hj
      have h : ¬pre j := by simpa [pre] using hj
      simp [bk,h]
    rw [src,dest]
    exact Finset.sum_congr rfl fun g _=>congrArg Finset.card (atEm g).2.symm
end IncidenceWarmBookPush
