import IncidenceThetaRoundDriver
import IncidencePhysicalOneErase
import IncidencePhysicalLiteralRows
namespace IncidencePhysicalPaidRound
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceThetaBatchHoist
open IncidenceThetaRestrict IncidenceThetaRoundDriver IncidenceZeroRestriction
variable {n : ℕ} (I : Fin n→Fin n→Prop) [DecidableRel I]
variable {P L : Finset (Fin n)} (a : Stage I P L)
structure Allowed (A B : Finset (Fin n)) : Prop where
  subP : A⊆a.A
  subL : B⊆a.B
  keepP : P⊆A
  keepL : L⊆B
  small : (a.A\A).card+(a.B\B).card≤24
  minP : ∀u∈A,2<(N (rel I A B) false u).card
  minL : ∀v∈B,2<(N (rel I A B) true v).card

def keep (old new : Finset (Fin n)) := Finset.univ \ (old \ new)

def minorSize (A B : Finset (Fin n)) := (compileLiteral (n+n) (n+n) a.C.code (ref (keep a.A A) (keep a.B B)) a.C.size).size

theorem simplify (C : Circuit n) (bin : binary C) (out : C.wire C.output=a.C.wire a.C.output)
    (less : C.size<a.C.size) : ∃b, Paid I a b := by
  have f : flags C (rel I a.A a.B) := by
    intro p l h
    rw [out]
    exact a.flag p l h
  have ng : negatives C (rel I a.A a.B) 3 3 := by
    intro p l hp hl bad
    rw [out]
    exact a.neg p l hp hl bad
  let b : Stage I P L := ⟨a.A,a.B,a.pointCore,a.lineCore,a.pointMin,a.lineMin,C,bin,f,ng⟩
  exact ⟨b,Finset.Subset.rfl,Finset.Subset.rfl,by simpa [b] using (show C.size+1≤a.C.size by omega)⟩

theorem erase_with_rows {A B : Finset (Fin n)} (legal : Allowed I a A B)
    (flag : ∃p∈A,∃l∈B,I p l)
    (debit : minorSize I a A B+2*((a.A\A).card+(a.B\B).card)+1≤a.C.size) :
    ∃b, Paid I a b ∧ b.A=A ∧ b.B=B ∧ b.C.size=minorSize I a A B ∧
      b.C.code=(compileLiteral (n+n) (n+n) a.C.code (ref (keep a.A A) (keep a.B B)) a.C.size).code := by
  classical
  obtain ⟨p,hp,l,hl,edge⟩ := flag
  let K := keep a.A A
  let M := keep a.B B
  have kp {u} (h : u∈A) : u∈K := by simp [K,keep,h]
  have ml {v} (h : v∈B) : v∈M := by simp [M,keep,h]
  have hit : ∃v,inject K M v∈a.C.wire a.C.output :=
    ⟨(single p,single l),by rw [inject_congr K M (kp hp) (ml hl)]; exact a.flag p l ⟨legal.subP hp,legal.subL hl,edge⟩⟩
  obtain ⟨C,bc,sz,eq,code⟩ := restrict_code a.C K M a.bin hit
  obtain ⟨f,ng⟩ := tests a.C C (rel I a.A a.B) K M 3 eq a.flag a.neg
  have same : rel (rel I a.A a.B) K M=rel I A B := by
    funext u v
    apply propext
    constructor
    · rintro ⟨hu,hv,ou,ov,e⟩
      exact ⟨by simpa [K,keep,ou] using hu,by simpa [M,keep,ov] using hv,e⟩
    · rintro ⟨hu,hv,e⟩; exact ⟨kp hu,ml hv,legal.subP hu,legal.subL hv,e⟩
  rw [same] at f ng
  let b : Stage I P L := ⟨A,B,legal.keepP,legal.keepL,legal.minP,legal.minL,C,bc,f,ng⟩
  exact ⟨b,⟨legal.subP,legal.subL,by simpa [b,sz,minorSize,K,M] using debit⟩,rfl,rfl,sz,code⟩
theorem no_surplus {A B : Finset (Fin n)} (none : ¬∃b,Paid I a b)
    (core : P.Nonempty) (legal : Allowed I a A B) :
    a.C.size ≤ minorSize I a A B + 2*((a.A\A).card+(a.B\B).card) := by
  classical
  obtain ⟨p,hp⟩ := core
  have pA := legal.keepP hp
  have deg := legal.minP p pA
  obtain ⟨l,hl⟩ := Finset.card_pos.mp (show 0<(N (rel I A B) false p).card by omega)
  have incidence : rel I A B p l := by simpa [N] using (Finset.mem_filter.mp hl).2
  by_contra! cheap
  obtain ⟨b,pay,_⟩ := erase_with_rows I a legal ⟨p,pA,l,incidence.2.1,incidence.2.2⟩ (by omega)
  exact none ⟨b,pay⟩

theorem no_simplification (none : ¬∃b,Paid I a b) (C : Circuit n) (bin : binary C)
    (out : C.wire C.output=a.C.wire a.C.output) : a.C.size≤C.size := by
  by_contra! less
  exact none (simplify I a C bin out less)

theorem erase_one (g : Fin a.C.size) (old : ℕ) (before : old<n+n+g.val)
    (same : a.C.wire (n+n+g.val)=a.C.wire old) :
    ∃ b, Paid I a b ∧ b.A=a.A ∧ b.B=a.B ∧ b.C.size+1=a.C.size ∧
      b.C.code=IncidenceCleanupGate.eraseGate (n+n) g.val old a.C.code := by
  obtain ⟨C,bin,out,sz,code⟩ := IncidencePhysicalOneErase.run a.C a.bin g old before same
  have f : flags C (rel I a.A a.B) := by
    intro p l h
    rw [out]
    exact a.flag p l h
  have ng : negatives C (rel I a.A a.B) 3 3 := by
    intro p l hp hl bad
    rw [out]
    exact a.neg p l hp hl bad
  let b : Stage I P L := ⟨a.A,a.B,a.pointCore,a.lineCore,a.pointMin,a.lineMin,C,bin,f,ng⟩
  refine ⟨b,⟨Finset.Subset.rfl,Finset.Subset.rfl,?_⟩,rfl,rfl,sz,code⟩
  simpa [b] using sz.le
end IncidencePhysicalPaidRound
