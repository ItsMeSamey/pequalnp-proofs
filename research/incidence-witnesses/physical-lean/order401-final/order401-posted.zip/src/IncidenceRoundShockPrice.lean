import IncidenceNoExtra
import IncidenceSurvivingReads
namespace IncidenceRoundShockPrice
open IncidenceOperandLedger IncidenceSurvivingReads CircuitRewire IncidenceZeroRestriction
open scoped BigOperators

theorem price (m s : ℕ) (g : ℕ→Gate) (init : ℕ→Option ℕ) (z : ℕ→Bool)
    (D S : Finset ℕ) (f : ℕ→ℕ)
    (sub : S ⊆ D) (range : D ⊆ Finset.range m)
    (flag : ∀i<m,z i=true ↔ i∈D) (inj : Set.InjOn f (↑S : Set ℕ))
    (single : ∀i∈S,1≤fan g s i) (other : ∀i∈D\S,2≤fan g s i)
    (inside : S.image f ⊆ Finset.range s) (book : ∀j∈S.image f,oneAnd z (g j)=1)
    (nn : ∀j<s,0≤(fan g s (m+j)-1)*bit (z (m+j)))
    (input : ∀i<m,(init i).isNone=z i) (order : ∀j<s,OrderedBinary (g j) (m+j))
    (ds : ∀j<s,z (m+j)=deadOut (g j).op (z (g j).left) (z (g j).right)) :
    (surplus s g z (S.image f)).card+2*D.card+(compileLiteral m m g init s).size≤s := by
  classical
  have total := savings m m s g init z input order ds
  rw [IncidenceNoExtra.raw_sum D m z _ range flag] at total
  have raw := IncidenceNoExtra.raw_floor D S f (fan g s) sub inj single other
  have intern := Finset.sum_nonneg (s:=Finset.range s) (fun j h=>nn j (Finset.mem_range.mp h))
  have portion := Finset.sum_sdiff (f:=fun j=>oneAnd z (g j)) inside
  have booked : (∑j∈S.image f,oneAnd z (g j))=((S.image f).card:ℤ) := by
    rw [Finset.sum_congr rfl book]; simp
  have rem : (∑j∈Finset.range s \ S.image f,oneAnd z (g j))=((surplus s g z (S.image f)).card:ℤ) := by
    let U := Finset.range s \ S.image f
    have es : surplus s g z (S.image f)=U.filter (fun j=>(g j).op=.meet ∧ z (g j).left≠z (g j).right) := by
      ext j
      simp [U,surplus,and_assoc,and_left_comm,and_comm]
    rw [es,Finset.card_filter]
    push_cast
    apply Finset.sum_congr rfl
    intro j hj
    by_cases e : (g j).op=.meet ∧ z (g j).left≠z (g j).right <;> simp [oneAnd,e]
  rw [booked,rem] at portion
  omega
#print axioms price
end IncidenceRoundShockPrice
