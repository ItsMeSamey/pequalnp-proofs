import IncidencePinCompensation
import IncidenceThetaPrivate
namespace IncidenceThetaCredits
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceHoistReaders IncidenceHoistWalk
open IncidenceHoistShield IncidenceHoistFlow
open IncidenceHoistPrefix IncidenceHoistSparse IncidenceHoistPrune IncidencePinLowLedger IncidencePinCompensation
variable {n : Nat} (C : Circuit n) (I : Fin n → Fin n → Prop)
private theorem agree_raw (line : Bool) (x : Fin n) (u v : Input n) (agr : AgreeOff line x u v)
    (i : Nat) (hi : i<n+n) (ne : i ≠ owner line x) : u∈C.wire i ↔ v∈C.wire i := by
  by_cases lo : i<n
  · let j : Fin n := ⟨i,lo⟩
    rw [(C.inputs j).1]
    cases line
    · change u.1 j=true ↔ v.1 j=true
      rw [agr.2 j (fun eq => ne (congrArg Fin.val eq))]
    · change u.1 j=true ↔ v.1 j=true
      rw [agr.1]
  · let j : Fin n := ⟨i-n,by omega⟩
    have form : i=n+j.val := by dsimp [j]; omega
    rw [form,(C.inputs j).2]
    cases line
    · change u.2 j=true ↔ v.2 j=true
      rw [agr.1]
    · change u.2 j=true ↔ v.2 j=true
      rw [agr.2 j (by intro eq; apply ne; change i=n+x.val; rw [← eq]; exact form)]

private theorem no_escape (line : Bool) (x : Fin n) {w : Nat} {H : Finset Nat}
    (p : Prefix C (owner line x) w H (witness line x)) (dead : uses C w = 0)
    (u v : Input n) (agr : AgreeOff line x u v) :
    ∀ i<n+n+C.size, i∉H → (u∈C.wire i ↔ v∈C.wire i) := by
  have empty : occurrences C w = [] :=
    List.length_eq_zero_iff.mp ((occurrence_count C w).trans dead)
  have parent (j : Nat) (hj : j<C.size) (b : Bool) (outside : n+n+j∉H) :
      keep (C.code j) b ∉ H := by
    intro h
    have eq := (p.leaves j hj b h).resolve_right outside
    have mem := (occurrence_mem C w j b).mpr ⟨hj,eq⟩
    rw [empty] at mem
    exact List.not_mem_nil mem
  intro i
  induction i using Nat.strong_induction_on with
  | ind i ih =>
    intro good outside
    by_cases raw : i<n+n
    · exact agree_raw C line x u v agr i raw (fun eq => outside (eq ▸ p.ownerInside))
    let j := i-(n+n)
    have atGate : i=n+n+j := by dsimp [j]; omega
    have valid : j<C.size := by omega
    obtain ⟨hl,hr⟩ := C.earlier j valid
    have l := ih (C.code j).left (by omega) (by omega) (parent j valid true (atGate ▸ outside))
    have r := ih (C.code j).right (by omega) (by omega) (parent j valid false (atGate ▸ outside))
    rw [atGate,C.law j valid]
    cases op : (C.code j).op <;> simp only [Gate.eval,op,Op.eval,Set.mem_union,Set.mem_inter_iff] <;> tauto

theorem has_use (cold : ∀ side x,witness side x ∉ C.wire C.output) (pos : flags C I) (line : Bool)
    (x y : Fin n) (inc : if line then I y x else I x y) {w : Nat} {H : Finset Nat}
    (p : Prefix C (owner line x) w H (witness line x)) : 0 < uses C w := by
  by_contra! dead
  have zero : uses C w=0 := by omega
  have out : C.output∉H := fun h => cold line x (p.hot _ h)
  cases line
  · let u : Input n := (single x,single y)
    have agree : AgreeOff false x u (witness true y) := by
      refine ⟨rfl,?_⟩
      intro i ne
      simp [u,witness,single,ne]
    have same := no_escape C false x p zero _ _ agree C.output C.output_lt out
    exact cold true y (same.mp (pos x y inc))
  · let u : Input n := (single y,single x)
    have agree : AgreeOff true x u (witness false y) := by
      refine ⟨rfl,?_⟩
      intro i ne
      simp [u,witness,single,ne]
    have same := no_escape C true x p zero _ _ agree C.output C.output_lt out
    exact cold false y (same.mp (pos y x inc))


theorem line (bin : binary C) (cold : ∀side x,witness side x∉C.wire C.output) (pos : flags C I) (P Q : Finset (Fin n)) (x p : Fin n)
    (dead : x∈Q) (free : p∉P) (inc : I p x) (one : IncidenceStartNormalization.uses C (n+x.val)=1)
    (privateAnd : ∀j<C.size,(C.code j).left=n+x.val ∨ (C.code j).right=n+x.val → (C.code j).op=.meet) :
    ∃ j<C.size,(C.code j).op=.meet ∧ z C P Q (C.code j).left≠z C P Q (C.code j).right ∧
        (if z C P Q (C.code j).left then (C.code j).left else (C.code j).right)=n+x.val := by
  classical
  obtain ⟨j,d,_,hj,hp,only⟩ := unique_reader C _ one
  have op := privateAnd j hj (by cases d; exact Or.inr hp; exact Or.inl hp)
  have otherNe : operand (C.code j) (!d)≠n+x.val := by
    intro h
    have bad := (only j hj (!d) h).2
    cases d <;> contradiction
  have outNe : C.output≠n+x.val := fun e =>
    cold true x (e.symm ▸ owner_hot C true x)
  let a : Input n := (single p,single x)
  let b := witness false p
  have same (i : Nat) (hi : i<n+n) (different : i≠n+x.val) : a∈C.wire i ↔ b∈C.wire i := by
    by_cases small : i<n
    · rw [(C.inputs ⟨i,small⟩).1]; rfl
    · let l : Fin n := ⟨i-n,by omega⟩
      have eq : n+l.val=i := by dsimp [l]; omega
      have ne : l≠x := by intro e; apply different; rw [← eq,e]
      rw [← eq,(C.inputs l).2]
      simp [a,b,witness,single,ne]
  have active := IncidenceThetaSibling.physical (n+n) C.size (n+x.val) j C.output C.code C.wire
    (fun k hk => ⟨(C.earlier k hk).1,(C.earlier k hk).2,bin k hk⟩) C.law hj op (!d)
    (fun k hk ne => ⟨fun e => ne (only k hk true e).1,fun e => ne (only k hk false e).1⟩)
    otherNe C.output_lt outNe a b same (pos p x inc) (cold false p)
  have sideBound : operand (C.code j) (!d)<n+n+C.size := by
    have ⟨l,r⟩ := C.earlier j hj
    cases d <;> simp [operand] <;> omega
  have up : freeMax P Q∈C.wire (operand (C.code j) (!d)) := by
    apply wire_up C _ sideBound _ active
    refine ⟨?_,?_⟩
    · intro k h
      have eq : k=p := of_decide_eq_true h
      subst k
      exact decide_eq_true free
    · simp [b,witness]
  have low : z C P Q (n+x.val)=true := by
    apply (marks C P Q _).mpr
    rw [(C.inputs x).2]
    simpa [freeMax] using dead
  have high : z C P Q (operand (C.code j) (!d))=false := by simp [z,up]
  refine ⟨j,hj,op,?_⟩
  cases d <;> simp only [operand,Bool.not_false,Bool.not_true,Bool.false_eq_true,if_true,if_false] at hp high <;>
    simp [hp,high,low]

theorem point (bin : binary C) (cold : ∀side x,witness side x∉C.wire C.output) (pos : flags C I) (P Q : Finset (Fin n)) (x p : Fin n)
    (dead : x∈P) (free : p∉Q) (inc : I x p) (one : IncidenceStartNormalization.uses C (x.val)=1)
    (privateAnd : ∀j<C.size,(C.code j).left=x.val ∨ (C.code j).right=x.val → (C.code j).op=.meet) :
    ∃ j<C.size,(C.code j).op=.meet ∧ z C P Q (C.code j).left≠z C P Q (C.code j).right ∧
        (if z C P Q (C.code j).left then (C.code j).left else (C.code j).right)=x.val := by
  classical
  obtain ⟨j,d,_,hj,hp,only⟩ := unique_reader C _ one
  have op := privateAnd j hj (by cases d; exact Or.inr hp; exact Or.inl hp)
  have otherNe : operand (C.code j) (!d)≠x.val := by
    intro h
    have bad := (only j hj (!d) h).2
    cases d <;> contradiction
  have outNe : C.output≠x.val := fun e =>
    cold false x (e.symm ▸ owner_hot C false x)
  let a : Input n := (single x,single p)
  let b := witness true p
  have same (i : Nat) (hi : i<n+n) (different : i≠x.val) : a∈C.wire i ↔ b∈C.wire i := by
    by_cases small : i<n
    · rw [(C.inputs ⟨i,small⟩).1]
      have ne : (⟨i,small⟩ : Fin n)≠x := fun e=>different (congrArg Fin.val e)
      simp [a,b,witness,single,ne]
    · let l : Fin n := ⟨i-n,by omega⟩
      have eq : n+l.val=i := by dsimp [l]; omega
      rw [← eq,(C.inputs l).2]
      rfl
  have active := IncidenceThetaSibling.physical (n+n) C.size (x.val) j C.output C.code C.wire
    (fun k hk => ⟨(C.earlier k hk).1,(C.earlier k hk).2,bin k hk⟩) C.law hj op (!d)
    (fun k hk ne => ⟨fun e => ne (only k hk true e).1,fun e => ne (only k hk false e).1⟩)
    otherNe C.output_lt outNe a b same (pos x p inc) (cold true p)
  have sideBound : operand (C.code j) (!d)<n+n+C.size := by
    have ⟨l,r⟩ := C.earlier j hj
    cases d <;> simp [operand] <;> omega
  have up : freeMax P Q∈C.wire (operand (C.code j) (!d)) := by
    apply wire_up C _ sideBound _ active
    refine ⟨?_,?_⟩
    · simp [b,witness]
    · intro k h
      have eq : k=p := of_decide_eq_true h
      subst k
      exact decide_eq_true free
  have low : z C P Q (x.val)=true := by
    apply (marks C P Q _).mpr
    rw [(C.inputs x).1]
    simpa [freeMax] using dead
  have high : z C P Q (operand (C.code j) (!d))=false := by simp [z,up]
  refine ⟨j,hj,op,?_⟩
  cases d <;> simp only [operand,Bool.not_false,Bool.not_true,Bool.false_eq_true,if_true,if_false] at hp high <;>
    simp [hp,high,low]

#print axioms line
#print axioms point
end IncidenceThetaCredits
