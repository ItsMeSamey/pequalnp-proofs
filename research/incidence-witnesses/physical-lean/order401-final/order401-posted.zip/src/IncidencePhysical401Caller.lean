import IncidencePhysicalBudgetStop
import IncidencePhysicalRoundProgress
import IncidenceActualBilateralCensus

namespace IncidencePhysical401Caller
open IncidenceThetaRoundDriver IncidenceThetaRestrict IncidenceThetaBatchHoist
open IncidenceReachableCensus IncidenceLabelHistory IncidenceMarkTransition IncidenceAllowedGeometry
open IncidencePhysicalCreditHistory IncidencePhysicalBudgetStop IncidenceRoundNoExtraPhysical
open IncidenceRoundPhysicalFunding IncidenceStartNormalization IncidenceCleanupLabels

variable {n : ℕ} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)}

theorem site_univ : kept (Finset.univ : Finset (Fin n)) Finset.univ=Finset.range (n+n) := by
  apply Finset.Subset.antisymm (kept_range _ _)
  intro i hi
  have bound := Finset.mem_range.mp hi
  by_cases lo : i<n
  · exact (left _ _ (⟨i,lo⟩ : Fin n)).mpr (Finset.mem_univ _)
  · let l : Fin n := ⟨i-n,by omega⟩
    have eq : n+l.val=i := by dsimp [l]; omega
    rw [←eq]
    exact (right _ _ l).mpr (Finset.mem_univ _)

theorem rounds (s : Stage I P L) (hn : n=161203) (pc : P.card=403) (lc : L.card=403)
    (join : ∀p q,p≠q→∃!r,I p r∧I q r)
    (fullA : s.A=Finset.univ) (fullB : s.B=Finset.univ)
    (size : s.C.size≤646424) (cold : vulnerable (shot s)=∅) (one : (sole (shot s)).card≤9843)
    (inside : ∀x<n+n,neighbors I x⊆Finset.range (n+n))
    (degree : ∀x<n+n,(neighbors I x).card=402)
    (codeg : ∀x<n+n,∀y<n+n,x≠y→(neighbors I x∩neighbors I y).card≤1)
    (literal : ∀ (a : Stage I P L) (h : Finset ℕ) (m : Marks (neighbors I) a),
      vulnerable (shot a)⊆h →
      ∀(A B : Finset (Fin n)) (b : Stage I P L),
      IncidenceHoistPrune.Live a.C → IncidencePhysicalPaidRound.Allowed I a A B → Paid I a b →
      kept a.A a.B \ kept A B ⊆ kept a.A a.B \ ((sites P L ∪ reserve m.M m.G) ∪ h) →
      b.A=A → b.B=B → b.C.size=IncidencePhysicalPaidRound.minorSize I a A B →
      b.C.code=(IncidenceZeroRestriction.compileLiteral (n+n) (n+n) a.C.code
        (ref (IncidencePhysicalPaidRound.keep a.A A) (IncidencePhysicalPaidRound.keep a.B B)) a.C.size).code →
      (drops (shot a) (shot b) ∪ andLost (shot a) (shot b)).card≤2*credit a b) :
    ∃ (b : Stage I P L) (v : ℕ),1617≤v ∧
      b.C.size+2*((s.A.card+s.B.card)-(b.A.card+b.B.card))+v≤s.C.size := by
  classical
  have full : (shot s).live=Finset.range (n+n) := by
    change kept s.A s.B=_
    rw [fullA,fullB,site_univ]
  have total : s.A.card+s.B.card=322406 := by simp [fullA,fullB,hn]
  let init : Marks (neighbors I) s := {
    M:=∅, G:=fun _=>∅, low:=by simp
    safe:={
      inside:=by simp, saved:=by simp, triple:=by simp
      unmarked:=by
        intro x hx _
        rw [full] at hx ⊢
        rw [Finset.inter_eq_right.mpr (inside x (Finset.mem_range.mp hx)),degree x (Finset.mem_range.mp hx)]
        decide }}
  apply IncidencePhysicalBudgetStop.stopAt init
  intro a h v w m below loss cash
  let V := kept a.A a.B
  let D := Finset.range (n+n) \ V
  have inRange : V⊆Finset.range (n+n) := kept_range _ _
  have lostEq : lost s a=D.card := by
    change ((shot s).live \ V).card=D.card
    rw [full]
  have gone : D.card≤38808 := by omega
  have exactLive : Finset.range (n+n) \ D=(shot a).live := by
    change Finset.range (n+n) \ (Finset.range (n+n) \ V)=V
    ext x
    simp only [Finset.mem_sdiff]
    constructor
    · rintro ⟨rx,out⟩
      by_contra off
      exact out ⟨rx,off⟩
    · intro vx; exact ⟨inRange vx,fun off=>off.2 vx⟩
  have marked (x) (hx : x∈m.M) : x<n+n :=
    Finset.mem_range.mp (inRange (m.safe.inside hx))
  have reserveCap := reserveBound m (Finset.range (n+n)) D exactLive
    (fun x hx=>inside x (marked x hx)) (fun x hx=>degree x (marked x hx))
    (fun x hx y hy=>codeg x (marked x hx) y (marked y hy)) gone
  have count := caps w cold one (by omega) pc lc m.M m.G reserveCap
  let prot := (sites P L ∪ reserve m.M m.G) ∪ h
  have fixed : kept P L⊆prot := fun x hx=>Finset.mem_union_left _ (Finset.mem_union_left _ hx)
  have guards : reserve m.M m.G⊆prot := fun x hx=>Finset.mem_union_left _ (Finset.mem_union_right _ hx)
  have protect : vulnerable (shot a)⊆prot := (census w cold).2.2.trans Finset.subset_union_right
  have censusEq : singles a.C V=sole (shot a) := by
    ext x
    simp only [singles,sole,Finset.mem_filter,shot,read_count] <;> rfl
  have cardD : D.card+V.card=n+n := by
    simpa [D] using Finset.card_sdiff_add_card_eq_card inRange
  have sumV : V.card=a.A.card+a.B.card := kept_card _ _
  have rem : 322406-38808≤V.card := by omega
  have cap : a.C.size+4≤2*V.card+1616 := by omega
  have core : P.Nonempty := Finset.card_pos.mp (by omega)
  have move := IncidencePhysicalRoundProgress.progress a join hn core m.M m.G prot m.safe
    fixed guards protect rem (by rw [censusEq]; exact count.1) count.2 cap
  obtain ⟨b,h',m',next,small,_,rise,paid⟩ :=
    IncidencePhysicalCreditHistory.witness w m cash core move (literal a h m (census w cold).2.2)
  exact ⟨b,h',_,next,⟨m'⟩,rise,by change ((shot a).live \ (shot b).live).card≤_; omega,paid⟩

theorem from_circuits
    (finish : ∀ (n : ℕ) (I : Fin n→Fin n→Prop) [DecidableRel I],
      n=161203 → (∀l,Fintype.card {u // I u l}=402) → (∀p q,p≠q→∃!r,I p r∧I q r) →
      ∀(P L : Finset (Fin n)) (s : Stage I P L),P.card=403 → L.card=403 →
      s.A=Finset.univ → s.B=Finset.univ → s.C.size≤646424 →
      vulnerable (shot s)=∅ → (sole (shot s)).card≤9843 →
      ∃ (b : Stage I P L) (v : ℕ),1617≤v ∧
        b.C.size+2*((s.A.card+s.B.card)-(b.A.card+b.B.card))+v≤s.C.size) :
    IncidenceOfficialScalar.ScalarLower401 := by
  intro n I _ hn deg join size o raw X out input before law flag neg
  by_contra! upper
  have hn' : n=161203 := by omega
  let C : Circuit n := ⟨size,o,raw,X,out,before,law,input⟩
  have cf : flags C I := flag
  have cn : negatives C I n 401 := fun a b _ hl avoid=>neg a b hl avoid
  obtain ⟨_,B,line,both,_,_,_,_,census⟩ := IncidenceActualBilateralCensus.retained
    C I deg join hn' cf cn (by change size≤_; omega)
  obtain ⟨P,L,pc,lc,baseline⟩ := IncidenceThetaPlaneResidual.order401 I deg join hn'
  let U : Finset (Fin n) := Finset.univ
  have same : rel I U U=I := by funext p l; simp [rel,U]
  have pm (p : Fin n) : 2<(N (rel I U U) false p).card := by
    have id : N (rel I U U) false p=IncidenceRobust.lines I p := by
      ext y
      simp [N,rel,U,IncidenceRobust.lines]
    rw [id]
    have d := IncidenceRobust.lines_card (q:=401) I deg join (by decide) hn p
    change 2<(IncidenceRobust.lines I p).card
    omega
  have lm (l : Fin n) : 2<(N (rel I U U) true l).card := by
    have id : N (rel I U U) true l=IncidenceRobust.points I l := by
      ext y
      simp [N,rel,U,IncidenceRobust.points]
    rw [id]
    have d := IncidenceRobust.points_card (q:=401) I deg l
    change 2<(IncidenceRobust.points I l).card
    omega
  let s : Stage I P L := {
    A:=U,B:=U,pointCore:=Finset.subset_univ _,lineCore:=Finset.subset_univ _,
    pointMin:=fun p _=>pm p,lineMin:=fun l _=>lm l,C:=B,bin:=both.ops,
    flag:=by rw [same]; exact both.one,
    neg:=by rw [same]; intro a b hp hl avoid; exact both.sparse a b (by omega) (by omega) avoid }
  have cap : s.C.size≤646424 := by
    have budget := both.budget.trans line.budget
    change B.size≤size at budget
    change B.size≤_
    omega
  have cold : vulnerable (shot s)=∅ := initial_cold B both.and_point both.and_line U U
  have one : (sole (shot s)).card≤9843 := (initial_count B U U).trans census
  obtain ⟨b,v,hit,cash⟩ := finish n I hn' deg join P L s pc lc rfl rfl cap cold one
  have base := baseline b.A b.B b.pointCore b.lineCore b.pointMin b.lineMin b.C b.bin b.flag b.neg
  have total : s.A.card+s.B.card=322406 := by simp [s,U,hn']
  omega

end IncidencePhysical401Caller
