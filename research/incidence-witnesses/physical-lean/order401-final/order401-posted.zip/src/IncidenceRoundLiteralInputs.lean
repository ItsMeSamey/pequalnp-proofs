import IncidencePhysicalPaidRound
import IncidenceRoundReservations
import IncidenceTrackedLiteral
namespace IncidenceRoundLiteralInputs
open CircuitRewire SparseIncidence IncidenceStartNormalization IncidenceZeroRestriction
open IncidenceThetaRestrict IncidenceRoundReservations IncidenceLiteralLabelStep
open IncidencePhysicalPaidRound IncidenceThetaRoundDriver IncidenceThetaBatchHoist
variable {n : Nat}

def X (C : Circuit n) (U V : Finset (Fin n)) (i : Nat) : Set (Input n) :=
  inject U V ⁻¹' C.wire i
def singleRow (C : Circuit n) (U V : Finset (Fin n)) (i : Nat) : Set Nat :=
  (fun x=>small n {x}) ⁻¹' X C U V i

theorem base (C : Circuit n) (U V : Finset (Fin n)) (i : Nat) (hi : i<n+n) :
    X C U V i=read C.wire (retain (kept U V) i) := IncidenceThetaRestrict.inputs C U V i hi

theorem sem (C : Circuit n) (U V : Finset (Fin n)) (j : Nat) (hj : j<C.size) :
    X C U V (n+n+j)=(C.code j).eval (X C U V) := by
  change inject U V ⁻¹' C.wire (n+n+j)=_
  rw [C.law j hj,preimage_gate]
  rfl
theorem gate (C : Circuit n) (U V : Finset (Fin n)) (j : Nat) (hj : j<C.size) :
    singleRow C U V (n+n+j)=(C.code j).eval (singleRow C U V) := by
  unfold singleRow
  rw [sem C U V j hj,preimage_gate]

theorem input (C : Circuit n) (U V : Finset (Fin n)) (i : Nat) (hi : i<n+n) :
    singleRow C U V i=read (fun x : Nat=>({x}:Set Nat)) (retain (kept U V) i) := by
  ext x
  change small n {x}∈X C U V i ↔ _
  rw [base C U V i hi]
  by_cases h : i∈kept U V
  · simp [retain,h,CircuitRewire.read,raw_small C _ hi,eq_comm]
  · simp [retain,h,CircuitRewire.read]

theorem small_inject (U V : Finset (Fin n)) (H : Finset Nat) :
    inject U V (small n H)=small n (H∩kept U V) := by
  apply Prod.ext <;> funext i
  · by_cases h : i∈U <;> simp [inject,small,IncidenceThetaRestrict.left,h]
  · by_cases h : i∈V <;> simp [inject,small,IncidenceThetaRestrict.right,h]

theorem single_kept (C : Circuit n) (U V : Finset (Fin n)) (x i : Nat) (hx : x∈kept U V) :
    x∈singleRow C U V i ↔ small n {x}∈C.wire i := by
  change inject U V (small n {x})∈C.wire i ↔ _
  rw [small_inject,Finset.inter_eq_left.mpr (Finset.singleton_subset_iff.mpr hx)]

theorem reject (C : Circuit n) (I : Fin n→Fin n→Prop) (neg : negatives C I 3 3)
    (U V : Finset (Fin n)) (x : Nat) (hx : x<n+n) : x∉singleRow C U V C.output := by
  change inject U V (small n {x})∉C.wire C.output
  rw [small_inject]
  by_cases h : x∈kept U V
  · rw [Finset.inter_eq_left.mpr (Finset.singleton_subset_iff.mpr h)]
    exact singleton_off C I neg hx
  · have eq : ({x}:Finset Nat)∩kept U V=∅ := by ext y; simp; grind
    rw [eq]
    apply neg <;> simp [small]

theorem internal (C : Circuit n) (I : Fin n→Fin n→Prop) (neg : negatives C I 3 3) :
    n+n≤C.output := by
  by_contra! raw
  have off := singleton_off C I neg raw
  exact off ((raw_small C _ raw).2 (Finset.mem_singleton_self _))

#print axioms reject

theorem domain (A B : Finset (Fin n)) : kept A B ⊆ Finset.range (n+n) := by
  intro x hx
  rcases Finset.mem_union.mp hx with h|h
  · obtain ⟨p,_,rfl⟩ := Finset.mem_image.mp h
    exact Finset.mem_range.mpr (by have := p.isLt; omega)
  · obtain ⟨l,_,rfl⟩ := Finset.mem_image.mp h
    exact Finset.mem_range.mpr (by have := l.isLt; omega)

theorem tracked (U V A B : Finset (Fin n)) : kept A B ⊆ kept (keep U A) (keep V B) := by
  intro x hx
  rcases Finset.mem_union.mp hx with h|h
  · obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp h
    exact (IncidenceThetaRestrict.left ..).2 (by simp [keep,hp])
  · obtain ⟨l,hl,rfl⟩ := Finset.mem_image.mp h
    exact (IncidenceThetaRestrict.right ..).2 (by simp [keep,hl])

theorem flips {P L : Finset (Fin n)} (I : Fin n→Fin n→Prop) [DecidableRel I]
    (a : Stage I P L) {A B : Finset (Fin n)} (legal : Allowed I a A B) (x : Nat) (hx : x∈kept A B) :
    let Y := X a.C (keep a.A A) (keep a.B B)
    a.C.output≠x ∧ ∃ u v : Input n,(∀ i<n+n,i≠x → (u∈Y i ↔ v∈Y i)) ∧
      u∈Y a.C.output ∧ v∉Y a.C.output := by
  let U := keep a.A A
  let V := keep a.B B
  have bounded := Finset.mem_range.mp (domain A B hx)
  refine ⟨by have := internal a.C _ a.neg; omega,?_⟩
  have make (y : Nat) (hy : y∈kept A B) (edge : small n {x,y}∈a.C.wire a.C.output) :
      ∃ u v : Input n,(∀ i<n+n,i≠x → (u∈X a.C U V i ↔ v∈X a.C U V i)) ∧
      u∈X a.C U V a.C.output ∧ v∉X a.C U V a.C.output := by
    refine ⟨small n {x,y},small n {y},?_,?_,?_⟩
    · intro i hi ne
      rw [base a.C U V i hi]
      by_cases keepI : i∈kept U V
      · simp [retain,keepI,CircuitRewire.read,raw_small a.C _ hi,ne]
      · simp [retain,keepI,CircuitRewire.read]
    · have sub : ({x,y}:Finset Nat)⊆kept U V := by
        intro i hi
        rcases Finset.mem_insert.mp hi with rfl|h
        · exact tracked a.A a.B A B hx
        · exact (Finset.mem_singleton.mp h).symm ▸ tracked a.A a.B A B hy
      change inject U V (small n {x,y})∈a.C.wire a.C.output
      rw [small_inject,Finset.inter_eq_left.mpr sub]; exact edge
    · exact reject a.C _ a.neg U V y (Finset.mem_range.mp (domain A B hy))
  rcases Finset.mem_union.mp hx with point|line
  · obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp point
    have degree := legal.minP p hp
    obtain ⟨l,hl⟩ := Finset.card_pos.mp (show 0<(N (rel I A B) false p).card by omega)
    have inc : rel I A B p l := by simpa [N] using (Finset.mem_filter.mp hl).2
    apply make (n+l.val) ((IncidenceThetaRestrict.right ..).2 inc.2.1)
    rw [pair_mask]; exact a.flag p l ⟨legal.subP hp,legal.subL inc.2.1,inc.2.2⟩
  · obtain ⟨l,hl,rfl⟩ := Finset.mem_image.mp line
    have degree := legal.minL l hl
    obtain ⟨p,hp⟩ := Finset.card_pos.mp (show 0<(N (rel I A B) true l).card by omega)
    have inc : rel I A B p l := by simpa [N] using (Finset.mem_filter.mp hp).2
    apply make p.val ((IncidenceThetaRestrict.left ..).2 inc.1)
    rw [Finset.pair_comm,pair_mask]; exact a.flag p l ⟨legal.subP inc.1,legal.subL hl,inc.2.2⟩

#print axioms flips
end IncidenceRoundLiteralInputs
