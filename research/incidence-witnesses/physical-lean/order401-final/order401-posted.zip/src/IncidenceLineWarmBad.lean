import IncidenceLineWarmMasks
namespace IncidenceLineWarm
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidencePointShield
open IncidenceWarmCompiler IncidencePointWarmComparison
variable {n : Nat}

theorem bad_pair (C : Circuit n) (I : Fin n→Fin n→Prop) (M : Finset (Fin n)) (f c)
    (wire : Wiring C M f c) (neg : negatives C I n 401) (x y : Fin n)
    (sel : x∈M) (keep : y∉M) (before : c y<c x) (bd : c y<n+n+C.size)
    (shielded : shadow (n+n) C.code (n+y.val) (c y) C.size C.output=false)
    (T : Finset (Fin n)) (ind : ∀p∈T,¬I p x)
    (cold : mask {y} T∉C.wire (c y)) (hot : mask {x} (avoid I {x})∈C.wire (c x)) :
    mask {x,y} T∉editedWire (n+n) C.size C.wire C.code (drops M) f C.output := by
  classical
  let J : Finset (Fin n) := {x,y}
  have only {l : Fin n} (h : l∈J) (hm : l∈M) : l=x := by
    rcases Finset.mem_insert.mp h with e|s
    · exact e
    · exact (keep ((Finset.mem_singleton.mp s) ▸ hm)).elim
  have sub : T⊆avoid I {x} := by
    intro p hp
    exact (avoids I {x} p).2 (by simpa using ind p hp)
  apply reciprocal C.code C.wire (drops M) f C.earlier wire.pins C.law
    (mask J T) (mask {y} T) (mask {x} (avoid I {x})) (n+y.val) (c y) C.output C.output_lt bd shielded
  · intro i hi h
    apply bitInputs C M J T {y} T ∅ _ (by simp) i hi h (by simp)
    intro l hl hm _
    rcases Finset.mem_insert.mp hl with e|s
    · subst l; contradiction
    · exact s
  · intro a ha early active
    obtain ⟨l,hl,hm,e⟩ := wire.on_at J T a ha active
    rw [only hl hm] at e
    omega
  · exact cold
  · intro i hi iy h
    apply bitInputs C M J T {x} _ {y} _ sub i hi h
    · simpa using iy
    · intro l hl _ noty
      rcases Finset.mem_insert.mp hl with e|s
      · simp [e]
      · contradiction
  · intro a ha active
    obtain ⟨l,hl,hm,e⟩ := wire.on_at J T a ha active
    rw [only hl hm] at e
    rw [←e]; exact hot
  · exact negative C I neg (by simp) (fun l hl p hp=>(avoids I {x} p).1 hp l hl)
#print axioms bad_pair
end IncidenceLineWarm
