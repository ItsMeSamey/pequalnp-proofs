import IncidenceWarmBookPush
import IncidenceWarmEligibleSlot
namespace IncidenceWarmBookAssembly
open IncidenceWarmCompiler IncidenceStartNormalization IncidenceLineRoutedSlots SparseIncidence CircuitRewire
open scoped BigOperators
theorem transfer_to_warm {n : ℕ} (C D : Circuit n) (hn : 0<n)
    (I : Fin n→Fin n→Prop) (drop : Finset ℕ) (fork : ℕ→Option ℕ)
    (sz : D.size=(run (n+n) C.code drop fork C.size).size)
    (cg : D.code=(run (n+n) C.code drop fork C.size).code)
    (rd : ∀i<n+n+C.size,∀t : Fin n,hit C i t ↔ (single t,fun _=>false)∈
      CircuitRewire.read D.wire ((run (n+n) C.code drop fork C.size).refs (addr (n+n) i)))
    (owner : Fin C.size→Fin n) (book : Fin C.size→Finset (Fin n))
    (good : ∀g,∀p∈book g,eligible C I (owner g) g p) :
    ∃ (ow : Fin D.size→Fin n) (bk : Fin D.size→Finset (Fin n)),
      (∀g,∀p∈bk g,eligible D I (ow g) g p) ∧
      (∑g,(book g).card)=(∑g,(bk g).card) := by
  let key (i : ℕ) := (programAt (n+n) C.code drop fork (2*i)).size
  have slot (g : Fin C.size) (p : Fin n) (hp : p∈book g) :=
    IncidenceWarmEligibleSlot.slot C D drop fork I (owner g) p g sz cg rd (good _ _ hp)
  refine IncidenceWarmBookPush.push (b:=D.size) hn owner book key ?_ ?_ (fun j x p=>eligible D I x j p) ?_
  · rintro g ⟨p,hp⟩
    exact (slot g p hp).choose
  · rintro g h ⟨p,hp⟩ ⟨q,hq⟩ same
    have e := IncidenceLiteralPrefix.emitted_injective _ _ _ _
      (slot g p hp).choose_spec.2 (slot h q hq).choose_spec.2 same
    exact Fin.ext (by omega)
  · intro g p hp bound
    exact (slot g p hp).choose_spec.1
end IncidenceWarmBookAssembly
