import IncidenceThetaRestrict
import IncidenceThetaPrivate
import IncidenceHoistLive
namespace IncidenceThetaRestrict
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceThetaBatchHoist IncidenceHoistPrune
open IncidenceHoistCompile IncidenceHoistFlow
variable {n : ℕ} (C : Circuit n)
instance (I : Fin n→Fin n→Prop) [DecidableRel I] (P L : Finset (Fin n)) :
    DecidableRel (rel I P L) := fun p l=>inferInstanceAs (Decidable (p∈P ∧ l∈L ∧ I p l))

private def bin (g : Gate) := g.op=.join ∨ g.op=.meet

private theorem kept_binary (sel : ℕ→Option Bool) (t : ℕ) (ht : t≤C.size) (old : binary C) :
    ∀ g∈(buildPrefix (n+n) C.code sel t).kept, bin g := by
  induction t with
  | zero => simp [buildPrefix]
  | succ t ih =>
    cases e : sel t with
    | some b => simpa only [buildPrefix,e] using ih (by omega)
    | none =>
      intro g hg
      simp only [buildPrefix,e,List.mem_append,List.mem_singleton] at hg
      rcases hg with prev|rfl
      · exact ih (by omega) g prev
      · exact old t (by omega)

private theorem joins_binary (k a : ℕ) (xs : List ℕ) : ∀ g∈appendJoins k a xs, bin g := by
  induction xs generalizing k a with
  | nil => simp [appendJoins]
  | cons x xs ih =>
    intro g hg
    rcases List.mem_cons.mp hg with rfl|tail
    · exact Or.inl rfl
    · exact ih _ _ g tail

theorem ops (D : List (Raw n)) (old : binary C) : binary (edited C D) := by
  let sel := IncidenceThetaBatchHoist.sel C D
  let gs := codeList (n+n) C.size C.output C.code sel
  intro j hj
  have jl : j<gs.length := by
    rw [show gs.length=C.size from physical_size ..]
    exact hj
  change bin (gs.getD j ⟨.zero,0,0⟩)
  simp only [List.getD_eq_getElem?_getD,List.getElem?_eq_getElem jl,Option.getD_some]
  have mem : gs[j]∈gs := List.getElem_mem ..
  rcases List.mem_append.mp mem with kept|extra
  · exact kept_binary C sel C.size le_rfl old _ kept
  · exact joins_binary _ _ _ _ extra


theorem inject_inter (P L P' L' : Finset (Fin n)) (v : Input n) :
    inject P L (inject P' L' v)=inject (P∩P') (L∩L') v := by
  apply Prod.ext <;> funext i
  · by_cases h : i∈P <;> by_cases h' : i∈P' <;> simp [inject,h,h']
  · by_cases h : i∈L <;> by_cases h' : i∈L' <;> simp [inject,h,h']

theorem step (I : Fin n→Fin n→Prop) [DecidableRel I] (k : ℕ)
    (D : List (Raw n)) (P L : Finset (Fin n)) (bin : binary C)
    (pos : flags C I) (neg : negatives C I (k+1) (k+1))
    (degree : ∀d∈D,k<(N I d.1 d.2).card)
    (over : ∀d∈D,∀i≠d.2,(N I d.1 d.2∩N I d.1 i).card≤1)
    (edge : ∃p∈P,∃l∈L,I p l) :
    ∃ B : Circuit n, binary B ∧ Live B ∧ flags B (rel I P L) ∧ negatives B (rel I P L) k k ∧
      B.size≤(IncidenceZeroRestriction.compileLiteral (n+n) (n+n) (edited C D).code (ref P L) C.size).size := by
  classical
  obtain ⟨sameSize,pf,nf⟩ := stage C I k D pos neg degree over
  obtain ⟨p,hp,l,hl,pl⟩ := edge
  have hit : ∃v,inject P L v∈(edited C D).wire (edited C D).output :=
    ⟨(single p,single l),by rw [inject_congr P L hp hl]; exact pf p l pl⟩
  obtain ⟨B,bb,sz,eq⟩ := restrict (edited C D) P L (ops C D bin) hit
  obtain ⟨bf,bn⟩ := tests _ _ I P L k eq pf nf
  obtain ⟨A,le,ab,alive,out,_⟩ := prune B bb
  refine ⟨A,ab,alive,fun p l inc=>out ▸ bf p l inc,?_,by simpa only [sz,sameSize] using le⟩
  intro a b ha hb ind
  rw [out]
  exact bn a b ha hb ind
#print axioms step
end IncidenceThetaRestrict
