import IncidencePhysicalPaidRound
namespace IncidenceRoundPhysicalMove
open SparseIncidence CircuitRewire IncidenceStartNormalization IncidenceThetaBatchHoist IncidenceThetaRestrict
open IncidenceThetaRoundDriver IncidencePhysicalPaidRound IncidenceZeroRestriction
variable {n : ℕ} {I : Fin n→Fin n→Prop} [DecidableRel I] {P L : Finset (Fin n)} (a : Stage I P L)
inductive Witness (E : Finset ℕ) : Prop
  | bypass (g : Fin a.C.size) (old : ℕ) (earlier : old<n+n+g.val)
      (same : a.C.wire (n+n+g.val)=a.C.wire old) : Witness E
  | rowErase (g : Fin a.C.size) (old : ℕ) (C : Circuit n) (bin : binary C)
      (out : C.wire C.output=a.C.wire a.C.output) (size : C.size+1=a.C.size)
      (code : C.code=IncidenceCleanupGate.eraseGate (n+n) g.val old a.C.code) : Witness E
  | deletion (A B : Finset (Fin n)) (legal : Allowed I a A B)
      (free : kept a.A a.B \ kept A B ⊆ E)
      (size : minorSize I a A B+2*((a.A\A).card+(a.B\B).card)+1≤a.C.size) : Witness E
theorem paid {E : Finset ℕ} (core : P.Nonempty) (w : Witness a E) : ∃b,Paid I a b := by
  cases w with
  | bypass g old before eq =>
    obtain ⟨b,h,_⟩ := erase_one I a g old before eq
    exact ⟨b,h⟩
  | rowErase g old C bin out sz code =>
    exact IncidencePhysicalPaidRound.simplify I a C bin out (by omega)
  | deletion A B legal _ size =>
    obtain ⟨p,pk⟩ := core
    have pa := legal.keepP pk
    have deg := legal.minP p pa
    obtain ⟨v,hv⟩ := Finset.card_pos.mp (show 0<(N (rel I A B) false p).card by omega)
    have edge : rel I A B p v := by simpa [N] using (Finset.mem_filter.mp hv).2
    obtain ⟨b,h,_⟩ := erase_with_rows I a legal ⟨p,pa,v,edge.2.1,edge.2.2⟩ size
    exact ⟨b,h⟩

theorem no_extra {E : Finset ℕ} (stop : ¬Witness a E) {A B : Finset (Fin n)} (legal : Allowed I a A B)
    (free : kept a.A a.B \ kept A B ⊆ E) :
    a.C.size≤minorSize I a A B+2*((a.A\A).card+(a.B\B).card) := by
  by_contra! less
  exact stop (.deletion A B legal free (by omega))

theorem no_alias {E : Finset ℕ} (stop : ¬Witness a E) (g : Fin a.C.size) (old : ℕ)
    (earlier : old<n+n+g.val) : a.C.wire (n+n+g.val)≠a.C.wire old :=
  fun e=>stop (.bypass g old earlier e)
end IncidenceRoundPhysicalMove
