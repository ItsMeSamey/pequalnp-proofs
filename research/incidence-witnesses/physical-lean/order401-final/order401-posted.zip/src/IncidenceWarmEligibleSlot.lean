import IncidenceWarmEmitSlot
import IncidenceLineRoutedSlots
namespace IncidenceWarmEligibleSlot
open IncidenceWarmCompiler IncidenceStartNormalization IncidenceLineRoutedSlots SparseIncidence CircuitRewire
theorem transport {n : ℕ} (C D : Circuit n) (I : Fin n→Fin n→Prop) (x p : Fin n)
    (g : Fin C.size) (k : Fin D.size) (u v : ℕ)
    (G : D.code k=⟨.join,u,v⟩)
    (L : ∀t,hit C (C.code g).left t ↔ hit D u t)
    (H : ∀t,hit C (C.code g).right t ↔ hit D v t)
    (el : eligible C I x g p) : eligible D I x k p := by
  obtain ⟨op,ip,hp,⟨a,ia,ap,ha⟩,⟨b,ib,bp,hb⟩⟩ := el
  refine ⟨congrArg Gate.op G,ip,?_,⟨a,ia,ap,?_⟩,⟨b,ib,bp,?_⟩⟩
  · change (single p,fun _=>false)∈D.wire (n+n+k.val)
    rw [D.law k k.isLt,G]
    have old := C.law g g.isLt
    rw [Gate.eval,op,Op.eval] at old
    change (single p,fun _=>false)∈C.wire (n+n+g.val) at hp
    rw [old] at hp
    exact hp.imp (L p).mp (H p).mp
  · rw [G]; exact (L a).mp ha
  · rw [G]; exact (H b).mp hb
theorem ref_hits {n : ℕ} (C D : Circuit n) (i : ℕ) (r : Option ℕ) (a : Fin n)
    (ha : hit C i a) (rd : ∀t : Fin n, hit C i t ↔ (single t,fun _=>false)∈CircuitRewire.read D.wire r) :
    ∃ u,r=some u ∧ ∀t,hit C i t ↔ hit D u t := by
  cases r with
  | none => exact False.elim ((rd a).mp ha)
  | some u => exact ⟨u,rfl,rd⟩

theorem slot {n : ℕ} (C D : Circuit n) (drop : Finset ℕ) (fork : ℕ→Option ℕ)
    (I : Fin n→Fin n→Prop) (x p : Fin n) (g : Fin C.size)
    (sz : D.size=(run (n+n) C.code drop fork C.size).size)
    (cg : D.code=(run (n+n) C.code drop fork C.size).code)
    (rd : ∀ i<n+n+C.size,∀ t : Fin n, hit C i t ↔
      (single t,fun _=>false)∈CircuitRewire.read D.wire
        ((run (n+n) C.code drop fork C.size).refs (addr (n+n) i)))
    (el : eligible C I x g p) :
    ∃ h : (programAt (n+n) C.code drop fork (2*g.val)).size<D.size,
      eligible D I x ⟨_,h⟩ p ∧ ∃ G, IncidenceLiteralPrefix.stage (2*(n+n)) (n+n) (stage (n+n) C.code fork) (init (n+n) drop) (2*g.val)=.emit G := by
  have original := el
  obtain ⟨op,_,_,⟨a,_,_,ha⟩,⟨b,_,_,hb⟩⟩ := el
  obtain ⟨bl,br⟩ := C.earlier g g.isLt
  have small := g.isLt
  obtain ⟨u,hu,L⟩ := ref_hits C D _ _ a ha (rd _ (by omega))
  obtain ⟨v,hv,H⟩ := ref_hits C D _ _ b hb (rd _ (by omega))
  obtain ⟨lt,eq,em⟩ := join_slot (n+n) C.size C.code drop fork g.isLt op ⟨bl,br⟩ hu hv
  have hk : (programAt (n+n) C.code drop fork (2*g.val)).size<D.size := by rw [sz]; exact lt
  refine ⟨hk,transport C D I x p g ⟨_,hk⟩ u v ?_ L H original,_,em⟩
  rw [cg]; exact eq
end IncidenceWarmEligibleSlot
