import IncidenceSmallMass
import IncidencePhysicalOrCount
import IncidencePinLowLedger
import Mathlib.Algebra.BigOperators.Fin
namespace IncidenceRoundAndMass
open CircuitRewire IncidenceStartNormalization IncidencePhysicalOrGroups IncidenceHoistPrune
open IncidenceDenseSignature IncidenceSmallMass IncidenceOperandLedger
open scoped BigOperators
variable {n : ℕ} (C : Circuit n)
abbrev rawExtra (active : Finset ℕ) :=
  (∑ i∈active,(uses C i-2))+(∑ i∈Finset.range (n+n) \ active,uses C i)

theorem gates (sig : ℕ→Sig ℕ) (live : Live C) :
    (∑ j∈Finset.range C.size,(fan C.code C.size (n+n+j)-1)*big (sig (n+n+j))) ≤ (excess C : ℤ) := by
  classical
  unfold excess
  push_cast
  rw [←Fin.sum_univ_eq_sum_range]
  apply Finset.sum_le_sum
  intro j _
  rw [IncidencePinLowLedger.fan_uses]
  by_cases out : wire C j=C.output
  · have z := output_unused C live
    change n+n+j.val=C.output at out
    simp [wire,out,z,big]
    split <;> omega
  · simp only [out,if_false]
    cases h : sig (n+n+j.val) <;> simp [big,wire] <;> omega

theorem rawCharge (sig : ℕ→Sig ℕ) (active prot : Finset ℕ)
    (ar : active⊆Finset.range (n+n))
    (small : ∀ i∈active,i∉prot → (sig i).isSome=true) :
    (∑ i∈Finset.range (n+n),fan C.code C.size i*big (sig i)) ≤
      ((rawExtra C active + 2*prot.card : ℕ) : ℤ) := by
  classical
  let w := fun i=>fan C.code C.size i*big (sig i)
  have split := Finset.sum_sdiff (f:=w) ar
  have dead := Finset.sum_le_sum (s:=Finset.range (n+n)\active) (fun i _=>
    show w i ≤ (uses C i:ℤ) by cases h : sig i <;> simp [w,big,IncidencePinLowLedger.fan_uses,h])
  have on := Finset.sum_le_sum (s:=active) (fun i hi=>
    show w i ≤ ((uses C i-2 : ℕ):ℤ)+(if i∈prot then 2 else 0) by
      by_cases p : i∈prot
      · cases h : sig i <;> simp [w,big,IncidencePinLowLedger.fan_uses,h,p] <;> omega
      · have hs := small i hi p
        cases h : sig i <;> simp_all [w,big])
  rw [Finset.sum_add_distrib,←Finset.sum_filter] at on
  have card : (active.filter (·∈prot)).card≤prot.card := Finset.card_le_card (fun _ h=>(Finset.mem_filter.mp h).2)
  simp only [Finset.sum_const,nsmul_eq_mul] at on
  change (∑i∈Finset.range (n+n),w i) ≤ _
  unfold rawExtra
  push_cast
  omega
theorem physical (sig : ℕ→Sig ℕ) (active prot : Finset ℕ) (D : Finset (Row C))
    (live : Live C) (ar : active⊆Finset.range (n+n))
    (unprotected : ∀ i∈active,i∉prot → (sig i).isSome=true)
    (raw : ∀ i<n+n,fan C.code C.size i*mass (sig i)≤2)
    (small : ∀ j<C.size,(sig (n+n+j)).isSome=true → fan C.code C.size (n+n+j)≤1)
    (mode : ∀ j<C.size,sig (n+n+j)=sig (C.code j).left ∨ sig (n+n+j)=sig (C.code j).right ∨
      sig (n+n+j)=merge 24 (sig (C.code j).left) (sig (C.code j).right))
    (large : ∀ j∈meets C,j∉D → sig (C.code j).left=none ∧ sig (C.code j).right=none) :
    25*(meets C).card ≤25*D.card+2*(n+n)+25*(excess C+rawExtra C active+2*prot.card) := by
  classical
  let B := (Finset.range C.size).filter (fun j=>(sig (C.code j).left).isNone && (sig (C.code j).right).isNone)
  have ord (j : ℕ) (hj : j<C.size) := C.earlier j hj
  have bd (j : ℕ) (hj : j<C.size) :
      (C.code j).left<n+n+C.size ∧ (C.code j).right<n+n+C.size := by
    obtain ⟨l,r⟩ := ord j hj
    omega
  have sub : ((meets C) \ D).image Fin.val ⊆ B := by
    intro i hi
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hi
    obtain ⟨a,b⟩ := large j (Finset.mem_sdiff.mp hj).1 (Finset.mem_sdiff.mp hj).2
    simp [B,j.isLt,a,b]
  have cnt := Finset.card_le_card sub
  rw [Finset.card_image_of_injective _ Fin.val_injective] at cnt
  have count := Finset.card_le_card (show meets C⊆((meets C) \ D)∪D by
    intro j hj
    by_cases d : j∈D <;> simp [hj,d])
  have combo := Finset.card_union_le ((meets C) \ D) D
  have sources := signature_sources (n+n) C.size 24 C.code sig bd raw small mode
  have both := big_rows (n+n) C.size C.code sig bd
  have gc := gates C sig live
  have rc := rawCharge C sig active prot ar unprotected
  dsimp only at sources both
  change (B.card : ℤ)≤_ at both
  omega

#print axioms physical
end IncidenceRoundAndMass
