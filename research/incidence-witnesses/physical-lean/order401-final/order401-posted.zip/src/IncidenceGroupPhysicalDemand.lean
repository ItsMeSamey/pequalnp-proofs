import IncidenceGroupPlaneTests
import IncidencePhysicalOrShield
namespace IncidenceGroupPhysicalDemand
open SparseIncidence IncidenceStartNormalization IncidenceRobust IncidenceGroupDemand
open IncidenceGroupPlaneTests IncidencePhysicalOrGroups
variable {n : ℕ}
theorem raw_split {i : ℕ} (h : i<n+n) : ∃x : Vertex n,wireId x=i := by
  by_cases low : i<n
  · exact ⟨.inl ⟨i,low⟩,rfl⟩
  · refine ⟨.inr ⟨i-n,by omega⟩,?_⟩
    change n+(i-n)=i
    omega
noncomputable def tops (C : Circuit n) : Finset (Row C) := by classical exact Finset.univ.filter (Top C)

theorem run (C : Circuit n) (I : Fin n→Fin n→Prop) [DecidableRel I]
    (cp : ∀a b,a≠b→(lines I a∩lines I b).card≤1)
    (cl : ∀a b,a≠b→(points I a∩points I b).card≤1)
    (pos : flags C I) (neg3 : negatives C I 3 3)
    (R : Finset (Vertex n)) (degree : ∀x∈R,2<(adj I x).card)
    (ports : ∀x∈R,∀g b,Reads C g (wireId x) b→(C.code g).op=.join)
    (two : ∀x∈R,uses C (wireId x)=2) : R.card≤2*(tops C).card := by
  classical
  let labels (g : Row C) := R.filter (fun x=>Member C (wireId x) g)
  let accept (S : Finset (Vertex n)) := mask S∈C.wire C.output
  apply demand (adj I) (loop I) (symm I) (overlap I cp cl) R (tops C) labels accept
    (neg I C neg3) (up I C pos) _ degree
  intro x hx
  obtain ⟨a,b,xa,xb,ends⟩ := route_all C (wireId x) (two x hx) (ports x hx)
  have top {g} (mem : Member C (wireId x) g) : g∈tops C := by
    obtain ⟨_,_,_,_,_,t⟩ := mem
    simpa [tops] using t
  refine ⟨a,top xa,b,top xb,Finset.mem_filter.mpr ⟨hx,xa⟩,Finset.mem_filter.mpr ⟨hx,xb⟩,?_⟩
  intro S ha hb
  have xo : wireId x≠C.output := by
    intro eq
    have hot := (raw C {x} x).mpr (Finset.mem_singleton_self x)
    rw [eq] at hot
    apply neg I C neg3 {x} (by simp) _ hot
    intro u hu v hv
    obtain rfl := Finset.mem_singleton.mp hu
    obtain rfl := Finset.mem_singleton.mp hv
    exact loop I _
  apply Classical.byContradiction
  intro diff
  apply shield C (mask (insert x S)) (mask S) (wireId x) xo _ (ports x hx) _ diff
  · intro i hi d
    obtain ⟨u,rfl⟩ := raw_split hi
    by_cases eq : u=x
    · rw [eq]
    exact (d (by simp [raw,Finset.mem_insert,eq])).elim
  · intro g mg d
    have hit (t : Row C) (h : ∃u∈S,u∈labels t) :
        mask (insert x S)∈C.wire (wire C t) ↔ mask S∈C.wire (wire C t) := by
      obtain ⟨u,us,ut⟩ := h
      have m := (Finset.mem_filter.mp ut).2
      exact iff_of_true (member_hot C m ((raw C _ _).mpr (Finset.mem_insert_of_mem us)))
        (member_hot C m ((raw C _ _).mpr us))
    rcases ends g mg with rfl|rfl
    · exact d (hit _ ha)
    · exact d (hit _ hb)
end IncidenceGroupPhysicalDemand

namespace IncidenceGroupPhysicalDemand
open IncidenceStartNormalization IncidenceGroupPlaneTests IncidencePhysicalOrGroups IncidenceRobust
variable {n : ℕ}

/-- Any subrelation of the original projective plane retains the required two codegree bounds. -/
theorem residual (C : Circuit n) (I J : Fin n→Fin n→Prop) [DecidableRel I] [DecidableRel J]
    (join : ∀p r,p≠r→∃!l,I p l∧I r l) (sub : ∀p l,J p l→I p l)
    (pos : flags C J) (neg : negatives C J 3 3) (live prot sole : Finset (Vertex n))
    (degree : ∀x∈(live\prot)\sole,2<(adj J x).card)
    (ports : ∀x∈(live\prot)\sole,∀g b,Reads C g (wireId x) b→(C.code g).op=.join)
    (two : ∀x∈(live\prot)\sole,uses C (wireId x)=2) :
    live.card≤sole.card+prot.card+2*(tops C).card := by
  apply IncidenceGroupDemand.all_sites
  apply run C J _ _ pos neg _ degree ports two
  · intro a b ne
    apply le_trans (Finset.card_le_card (Finset.inter_subset_inter ?_ ?_)) (line_overlap I join ne)
    all_goals intro u h; exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,sub _ _ (Finset.mem_filter.mp h).2⟩
  · intro a b ne
    apply le_trans (Finset.card_le_card (Finset.inter_subset_inter ?_ ?_)) (point_overlap I join ne)
    all_goals intro u h; exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,sub _ _ (Finset.mem_filter.mp h).2⟩
end IncidenceGroupPhysicalDemand
#print axioms IncidenceGroupPhysicalDemand.residual
