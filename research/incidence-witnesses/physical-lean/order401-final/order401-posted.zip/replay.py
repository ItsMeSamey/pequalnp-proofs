"""Verify the source snapshot and rebuild its Lean modules in dependency order."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def digest(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['verify', 'build'])
    parser.add_argument('--output', type=Path)
    parser.add_argument('--count', type=int)
    args = parser.parse_args()
    m = json.loads((ROOT/'manifest.json').read_text())
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        h, name = line.split('  ', 1)
        if digest(ROOT/name) != h:
            raise SystemExit(f'File differs from snapshot: {name}')
    for name, rec in m['modules'].items():
        if digest(ROOT/rec['source']) != rec['source_sha256']:
            raise SystemExit(f'Source mismatch: {name}')
    print(f"Verified {len(m['modules'])} Lean sources for {m['entry']}.", flush=True)
    if args.mode == 'verify':
        return
    if not args.output or (args.count is not None and args.count < 1):
        parser.error('supply --output and, if specified, a positive --count')
    out = args.output.resolve()
    if out == ROOT or ROOT in out.parents:
        parser.error('choose an output directory outside this release')
    lean = shutil.which('lean')
    if not lean:
        parser.error('lean is required')
    version = subprocess.check_output([lean,'--version'], text=True).strip()
    if version != m['compiler']:
        raise SystemExit(f'Expected {m["compiler"]}, found {version}')
    lib = Path(subprocess.check_output([lean,'--print-prefix'],text=True).strip())/'lib/lean'
    packages = [p for p in os.environ.get('LEAN_PATH','').split(os.pathsep)
                if p and '/.lake/packages/' in str(Path(p).resolve())]
    if not packages:
        parser.error('run with lake env so the pinned package libraries are available')
    for name, rec in m['external_first_matches'].items():
        rel = Path(*name.split('.')).with_suffix('.olean')
        selected = next((p/rel for p in [*map(Path,packages), lib] if (p/rel).is_file()),None)
        if selected is None or digest(selected) != rec['sha256']:
            raise SystemExit(f'External library differs from recorded build: {name}')
    obj, logs = out/'objects', out/'receipts'
    obj.mkdir(parents=True,exist_ok=True)
    logs.mkdir(parents=True,exist_ok=True)
    stamp = out/'snapshot.sha256'
    ident = digest(ROOT/'manifest.json')+'\n'
    if stamp.exists() and stamp.read_text() != ident:
        raise SystemExit('Choose a fresh directory for this snapshot.')
    if not stamp.exists() and any(obj.rglob('*.olean')):
        raise SystemExit('Output already contains untracked Lean objects.')
    stamp.write_text(ident)
    env = os.environ | {'LEAN_PATH':os.pathsep.join([str(obj),*packages])}
    rebuilt = 0
    for name, rec in m['modules'].items():
        rel = Path(*name.split('.')).with_suffix('.olean')
        target = obj/rel
        done = logs/(name+'.sha256')
        if target.exists() and done.exists() and done.read_text().strip() == digest(target):
            continue
        target.parent.mkdir(parents=True,exist_ok=True)
        temporary = target.with_suffix('.pending.olean')
        with (logs/(name+'.log')).open('w') as log:
            res = subprocess.run([lean,'-j1','--root='+str(ROOT/'src'),'-o',str(temporary),
                                  str(ROOT/rec['source'])], env=env,stdout=log,stderr=subprocess.STDOUT)
        if res.returncode:
            temporary.unlink(missing_ok=True)
            raise SystemExit(f'{name} failed. See {logs/(name+".log")}')
        temporary.replace(target)
        done.write_text(digest(target)+'\n')
        rebuilt += 1
        print(name,flush=True)
        if args.count == rebuilt:
            break
    terminal = logs/(m['entry']+'.sha256')
    if terminal.exists():
        print(f"Rebuilt {m['entry']}; terminal check is in {logs/(m['entry']+'.log')}.")
    else:
        print('Batch completed. Repeat the same command to continue.')

if __name__ == '__main__':
    main()
