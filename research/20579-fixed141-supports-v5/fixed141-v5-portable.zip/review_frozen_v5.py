"""Read-only metadata and row-identity checker for the portable 20579 v5 ZIP."""
import hashlib,json,re,sys,zipfile
from collections import Counter
from pathlib import PurePosixPath
def sha(b):return hashlib.sha256(b).hexdigest()
def require(ok,reason):
    if not ok:raise ValueError(reason)
with zipfile.ZipFile(sys.argv[1]) as z:
    info=z.infolist();index={e.filename:e for e in info};require(len(index)==len(info),'duplicate archive path')
    markers=[s for s in index if s.startswith('inventory/') and s.endswith('.json')]
    entries={};byname={}
    for manifest in sorted(markers):
        for row in json.loads(z.read(manifest)):
            name=row['path'];require(name not in entries,name);entries[name]=row
            require(sha(z.read(name))==row['sha256'],name)
            byname.setdefault(PurePosixPath(name).name,[]).append(name)
    require(set(index)==set(entries)|set(markers),'unindexed members')
    def member(key,expected=None):
        names=byname[PurePosixPath(key).name]
        choice=[n for n in names if expected is None or entries[n]['sha256']==expected]
        require(len(choice)==1,key);return z.read(choice[0])
    def J(key,expected=None):return json.loads(member(key,expected))
    d=J('fixed141-v5-support12-570.json','85cb92b02744d39b27fc590df025415655cc222ae03ec8d984f849635d50fb76')
    p=J(d['parent'],d['parent_sha256'])
    iface=J('fixed141-interface-audit-v1.json')
    for family in [d['receipts'],p['receipt_sha256'],iface['receipt_sha256']]:
        for name,digest in family.items():member(name,digest)
    official=J('pnp-official-20579-public.json','a875746e0199324bc110e968ec84b07ea551b573b44d3d11b5beec021bde0877')
    rows=re.findall(r'0x[0-9a-f]+',official['gap']['statement'])
    require(len(rows)==32 and official['gap']['id']=='L-meta-20579','posted graph')
    source=J(PurePosixPath(iface['source']).name,d['source_sha256'])
    require(source['gates'][69-64]=={'op':'not','inputs':[68]},'marker wire')
    inventory=J('marker32-inversion-lower.json');allsets={tuple(x['ports']):x for x in inventory['supports']}
    require(len(allsets)==len(inventory['supports'])==1166,'support identities')
    passive={s for s in allsets if 69 not in s};active=set(allsets)-passive
    bounds={tuple(x['ports']):x['verified_lower'] for x in p['rows']};require(len(p['rows'])==len(bounds)==len(passive)==583 and set(bounds)==passive,'passive coverage')
    old=tuple(d['updated_row']['ports']);require(bounds[old]==170 and p['rows'][d['updated_row']['baseline_index']]['ports']==list(old),'delta identity')
    final=J('support12-final.json');replay=J('support-12-unique.json')
    require(tuple(final['ports'])==old and final['case_digest']==replay['cases_sha256'] and replay['done'],'final replay')
    schedule=J('slack25-general-12-unique-candidates.json',replay['rows_sha256'])['rows']
    require(Counter(x[-1] for x in schedule)==final['unique_cases']==replay['counts'] and len({tuple(x) for x in schedule})==4642,'coverage')
    require(final['primary_two_minimal']==final['independent_two_minimal']=={'prefix':6} and final['open_unique_across_checkers']==final['parallel_partitions']==0,'terminal result')
    for top,n in replay['counts'].items():
        for which in ('primary','replay'):
            require(sum(v for k,v in replay['histogram'].items() if k.startswith(f'{top}:{which}:'))==n,'implementation count')
    require(not any(v and k.lower().endswith(':open') for k,v in replay['histogram'].items()),'open record')
    bounds[old]=171
    s26={tuple(r['ports']) for r in J('notation-active32-summary.json')['supports'] if r['lower']>=171}
    require(s26=={tuple(r['ports']) for r in J('notation-active32-group-replay.json') if r['lower']>=171 and not r['pinned_relaxation']},'26-port review')
    s27={tuple(r['ports']) for r in J('active96-fork-witnesses.json') if not r['unresolved'] and not r['remaining']}
    require(s26=={s for s in active if len(s)==26} and s27=={s for s in active if len(s)==27},'active groups')
    require(active==s26|s27|{s for s in active if allsets[s]['binate_lb']>=171},'active coverage')
    h=Counter(bounds.values());require(h=={170:13,171:570} and h[171]+len(active)==1153,'global counts')
    print('SHA-256 hashes and row identities verified. Fixed 141 gates. Strict 570/583; marker read 583/583; optional read 1153/1166. Thirteen supports have lower bound 170.')
    print('Metadata verification only. The original 960 schedules used two implementations in one noncanonical-lock pilot and were never rerun under the canonical lock.')
