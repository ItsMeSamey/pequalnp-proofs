import json,itertools,collections,pathlib
p=pathlib.Path('/dev/shm/site-team-01-abc-drafts/enc')
exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
old=json.load(open('/tmp/singleton-low20-phases.json'))
ledger=json.load(open(p/'alter246-bypass-consolidated.json'))
results=[]
for idx,rr in enumerate(z for z in ledger if len(z['ports'])==25 and z['lower']==169):
 ports=rr['ports'];q=next(z for z in old if z['ports']==ports)
 ids=[B.index(w) for w in ports];s=sum(1<<i for i in ids)
 care={a&s:y for a,y in L.items()};zero=set(q['first_gate_zero']);one=set(q['first_gate_one'])
 assert not any(not o&~z for o in one for z in zero)
 piv={};bi=[]
 for i in ids:
  t=1<<i;lo=[a for a,y in care.items() if not a&t and care.get(a|t,y)!=y];piv[i]=lo
  if len({care[a] for a in lo})==2:bi.append(i)
 common=s^sum(1<<b for b in bi)
 forbidden={};pair={}
 for i in bi:
  t=1<<i;v0=piv[i];v1=[a|t for a in v0]
  bad=next(((o,z) for o in one|set(v1) for z in zero|set(v0) if not o&~z),None)
  if bad:forbidden[B[i]]=bad
 for i,j in itertools.combinations(bi,2):
  if B[i] in forbidden or B[j] in forbidden:continue
  bad=next(((a|1<<i,b) for a in piv[i] for b in piv[j] if not (a|1<<i)&~b),None) or next(((b|1<<j,a) for a in piv[i] for b in piv[j] if not (b|1<<j)&~a),None)
  if bad:pair[f'{B[i]},{B[j]}']=bad
 mandatory=[]
 for o in one:
  for z in zero:
   d=o&~z
   if d&common:continue
   if not any(m&d==m for m in mandatory):
    mandatory=[m for m in mandatory if m&d!=d]+[d]
 viable=[i for i in bi if B[i] not in forbidden];vbits=sum(1<<i for i in viable)
 hits=not any(not d&vbits for d in mandatory)
 results.append(dict(ports=ports,binate=[B[i] for i in bi],forbidden=forbidden,forbidden_pairs=pair,required_hits=mandatory,viable=[B[i] for i in viable],hits=hits))
 print(idx,len(bi),len(forbidden),len(pair),len(mandatory),hits,flush=True)
(p/'notation-slack25-first-not-pivots.json').write_text(json.dumps(results))
