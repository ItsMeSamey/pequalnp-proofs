from pathlib import Path
from functools import lru_cache
import json,hashlib,re,collections
src=next(Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'));d=json.loads(src.read_bytes());g=d['gates'];y=d['output'];F=(1<<1024)-1;T=sum(int(x,16)<<(32*r) for r,x in enumerate(re.findall('0x[0-9a-f]+',json.load(open('/tmp/pnp-official-20579-public.json'))['gap']['statement'])))
raw=[sum(1<<i for i in range(1024) if j in (i//32,32+i%32)) for j in range(64)];v=raw.copy();mark=None
def ev(q,vs):
 a,b=vs[q['inputs'][0]],vs[q['inputs'][-1]];return a&b if q['op']=='and' else a|b if q['op']=='or' else F^a
for j,q in enumerate(g,64):
 v.append(ev(q,v))
 if q['op']=='not' and q['inputs'][0]>=64 and mark is None:mark=j
assert v[y]==T
@lru_cache(None)
def cone(i,stop=-1):
 if i<64 or i==stop:return 0
 return (1<<i)|combine(cone(j,stop) for j in g[i-64]['inputs'])
def combine(xs):
 r=0
 for x in xs:r|=x
 return r
def obs(k,z):
 w=v.copy();w[k]=z
 for i in range(k+1,y+1):w[i]=ev(g[i-64],w)
 return w[y]
reports=[];total=0
for root in range(179,y+1):
 fixed=cone(y,root)|cone(mark);reclaim=183-fixed.bit_count()
 if reclaim<13:continue
 care=obs(root,0)^obs(root,F);lab=v[root];cells=[c for c in range(1024) if care>>c&1]
 if not cells:continue
 cut={root};seen=set()
 for depth in range(1,12):
  cut={s for j in cut for s in (g[j-64]['inputs'] if j>=179 and not fixed>>j&1 else (j,))}
  key=tuple(sorted(cut))
  if key in seen:break
  seen.add(key);B=list(key)
  words={sum((v[w]>>c&1)<<j for j,w in enumerate(B)):(c,lab>>c&1) for c in cells}
  assert len({(sum((v[w]>>c&1)<<j for j,w in enumerate(B)),lab>>c&1) for c in cells})==len(words)
  must={}
  for z,(c,bit) in words.items():
   for j,w in enumerate(B):
    t=words.get(z^(1<<j))
    if t and bit!=t[1]:must[w]=[c,t[0]]
  opt=[w for w in B if w not in must];cm=combine(cone(w) for w in must)|fixed;lb=cm.bit_count()+max(0,len(must)-1)
  exact=False
  if len(opt)<=12:
   lbs=[]
   m=sum(1<<B.index(w) for w in must)
   for x in range(1<<len(opt)):
    S=[w for i,w in enumerate(opt) if x>>i&1];sel=m|sum(1<<B.index(w) for w in S);labs={};ok=True
    for word,(_,l) in words.items():
     if labs.setdefault(word&sel,l)!=l:ok=False;break
    if ok:lbs.append((cm|combine(cone(w) for w in S)).bit_count()+max(0,len(must)+len(S)-1))
   lb=min(lbs);exact=True
  descent=next(([c,e] for x,(c,l) in words.items() if l for z,(e,h) in words.items() if not h and x&z==x),None)
  if descent is not None:lb+=1
  reports.append(dict(required_decoder_not_witness=descent,root=root,depth=depth,cut=B,care_count=len(cells),reclaim_if_all_sources_dropped=reclaim,mandatory_witnesses=must,optional=opt,all_supports_considered=exact,lower=lb))
H=Path('/dev/shm/site-team-01-abc-drafts/enc');(H/'exact183-interface-lower.json').write_text(json.dumps(dict(source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),marker=mark,reports=reports)))
print('input',len(g),y,'nontrivial cuts',len(reports),'eliminated',sum(r['lower']>170 for r in reports),'depth1+',collections.Counter(r['depth'] for r in reports if r['lower']>170));print('unresolved',[(r['root'],r['depth'],r['lower']) for r in reports if r['lower']<=170][:30]);print('root totals',[(r['root'],r['depth'],r['lower'],len(r['mandatory_witnesses'])) for r in reports if r['root']==y]);print('excluded examples',[(r['root'],r['depth'],r['lower'],r['reclaim_if_all_sources_dropped']) for r in reports if r['depth']>=3 and r['lower']>170][:10])
