exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
from functools import lru_cache
import collections
okcorner={}
for pos in range(16):
 for neg in range(16):
  okcorner[pos,neg]=sum(1<<k for k in range(4) if any(not(pos&~a or neg&a) for a in (0,15,3,12,5,10,1<<k,15^(1<<k))))
cell={x:i for i,x in enumerate(W)};cap=170;out=[];hist=collections.Counter();best=999
def chromreject(q,colors):
 if colors<0:return True
 used={}
 def solve():
  if len(used)==len(q):return True
  i=max((j for j in q if j not in used),key=lambda t:(len({used[a] for a in q[t] if a in used}),len(q[t])))
  for c in range(min(colors,len(set(used.values()))+1)):
   if any(used.get(a)==c for a in q[i]):continue
   used[i]=c
   if solve():return True
   del used[i]
  return False
 return not solve()
for k in range(len(opt)+1):
 for sel in itertools.combinations(opt,k):
  I=sorted(mand+list(sel));s=sum(1<<j for j in I);pos={x&s for x in P};neg={x&s for x in N}
  if pos&neg:continue
  words={z&s:(i,(T>>i)&1) for i,z in enumerate(W)}
  dirs={i:(any(not(x>>i&1) and x^(1<<i) in neg for x in pos),any(x>>i&1 and x^(1<<i) in neg for x in pos)) for i in I};bi=[j for j,(lo,hi) in dirs.items() if lo and hi]
  negs=1 if any(lo for lo,hi in dirs.values()) else int(any(not x&~y for x in pos for y in neg))
  base=141+len(I)-1;assert base+negs+int(bool(bi))>=167
  chain=None
  if base+negs+int(bool(bi))<=170:
   down=[(x,y) for x in pos for y in neg if not x&~y]
   for x,y in down:
    z=next(((a,b) for a,b in down if not y&~a),None)
    if z:chain=[words[t][0] for t in (x,y,*z)];negs=2;break
  budget=170-base-negs;adj={i:set() for i in bi};edges=[];excluded=budget<int(bool(bi))
  if not excluded:
   # Build incompatibilities until graph already needs too many distinct forks.
   for i,j in itertools.combinations(bi,2):
    m=(1<<i)|(1<<j);gr={};valid=15
    for x,(c,l) in words.items():
     b=x&~m;z=1<<(((x>>i)&1)+2*((x>>j)&1));p,n=gr.get(b,(0,0))
     if l:p|=z
     else:n|=z
     gr[b]=p,n;valid&=okcorner[p,n]
     if not valid:break
    if valid:continue
    edges.append([B[i],B[j]]);adj[i].add(j);adj[j].add(i)
    if chromreject(adj,budget):excluded=True;break
  lower=171 if excluded else base+negs+max((c for c in range(1,budget+1) if chromreject(adj,c-1)),default=0)
  hist[lower]+=1;best=min(best,lower);out.append(dict(ports=[B[j] for j in I],lower=lower,drops=chain,binate=[B[j] for j in bi],edges=edges))
 if out:print(len(out),hist,flush=True)
(H/'alter246-fork-summary.json').write_text(json.dumps(dict(frozen=141,results=out)))
