from checkpoint import *
from collections import defaultdict,Counter,deque
from itertools import product
H=Path('.');doc=json.load(open('marker32-inversion-lower.json'));rows=[r for r in doc['supports'] if len(r['ports'])==27 and 69 in r['ports']]
n=normalize(json.load(open(next(Path('/dev/shm/04rank-s179-trajectory').glob('full183*')))));v,_,_,_=run(n);Y=sum(int(h,16)<<(32*i) for i,h in enumerate(re.findall('0x[0-9a-f]+',json.load(open(POST))['gap']['statement'])))
def runone(ports):
 xs={sum((v[w]>>c&1)<<j for j,w in enumerate(ports)):c for c in range(1024)}; cs=list(xs.values());N=len(cs); F=(1<<len(ports))-1;keys=list(xs);L=[Y>>c&1 for c in cs];ix={x:i for i,x in enumerate(keys)};M=flip=unknown=0;pivs=[]
 for j in range(len(ports)):
  bit=1<<j;pairs=[(i,ix[x^bit]) for i,x in enumerate(keys) if not x&bit and x^bit in ix and L[i]!=L[ix[x^bit]]];ds={L[i] for i,k in pairs}
  if len(ds)==2:M|=bit
  elif ds=={1}:flip|=bit
  elif not ds:unknown|=bit
  for i,k in pairs:pivs.extend([(i,N+j,0,bit),(k,N+j,1,bit)])
 E=F^M;bits=[1<<i for i in range(len(ports)) if E>>i&1]
 # Retain comparisons with the fewest conditional coordinates first; more are added if necessary.
 pos=[i for i,y in enumerate(L) if y];neg=[i for i,y in enumerate(L) if not y];edges=[]
 for i in pos:
  x=keys[i]
  for k in neg:
   y=keys[k];require=(((x^flip)&~(y^flip))|((x^y)&unknown))&E
   if require.bit_count()<=2:edges.append((require,i,k))
 edges.sort(key=lambda e:e[0].bit_count())
 def witness(G):
  parents={};par={};adj=defaultdict(list)
  def get(a):
   if a not in parents:parents[a]=a;par[a]=0
   if parents[a]!=a:
    b=parents[a];parents[a]=get(b);par[a]^=par[b]
   return parents[a]
  def add(a,b,p,on,off):
   x=get(a);y=get(b);z=par[a]^par[b]^p
   if x!=y:
    parents[x]=y;par[x]=z;adj[a].append((b,on,off));adj[b].append((a,on,off));return
   if not z:return
   q=[a];pred={a:None}
   for i in q:
    if i==b:break
    for j,lo,hi in adj[i]:
     if j not in pred:pred[j]=(i,lo,hi);q.append(j)
   while b!=a:b,lo,hi=pred[b];on|=lo;off|=hi
   return on,off
  groups={}
  for i,x in enumerate(keys):
   k=x&G
   if k in groups:
    a=groups[k];add(i,a,0,0,(keys[a]^x)&E)
   else:groups[k]=i
  for a,b,p,bit in pivs:
   if bit&G:
    ans=add(a,b,p,bit&E,0)
    if ans:return ans
  for need,a,b in edges:
   if not need&~G:
    ans=add(a,b,1,need,0)
    if ans:return ans
  return None
 total=1<<len(bits);full=(1<<total)-1;axes={}
 for i,bit in enumerate(bits):
  k=1<<i;axes[bit]=(full//((1<<(2*k))-1))*(((1<<k)-1)<<k)
 left=full;clauses=[];unresolved=[]
 while left:
  j=(left&-left).bit_length()-1;G=M|sum(bit for k,bit in enumerate(bits) if j>>k&1);w=witness(G)
  if w is None:unresolved.append(j);left^=1<<j
  else:
   lo,hi=w;cover=full
   for bit in bits:
    if lo&bit:cover&=axes[bit]
    if hi&bit:cover&=~axes[bit]
   assert cover>>j&1;left&=~cover;clauses.append(w)
  if len(unresolved)>=3:break
 return dict(ports=ports,binate=M,extras=bits,total=total,clauses=clauses,unresolved=unresolved,remaining=left.bit_count())
out=[]
for i,rec in enumerate(rows):
 result=runone(rec['ports']);out.append(result)
 if i%8==7: print(i+1,sum(not(r['unresolved'] or r['remaining']) for r in out),flush=True)
 Path('active96-fork-witnesses.json').write_text(json.dumps(out))
