from checkpoint import *
from itertools import combinations
H=Path(__file__).parent;ref=json.loads((H/'root218-tight-support.json').read_text())
src=next(Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'))
n=normalize(json.loads(src.read_text()));vs,base,marker,shard=run(n);g=n['gates'];out=n['output'];assert audit(n)['mismatches']==0
def cone(roots,stop=None):
 s=set();todo=list(roots)
 while todo:
  k=todo.pop()
  if k<64 or k==stop or k in s:continue
  s.add(k);todo.extend(g[k-64]['inputs'])
 return s
fixed=cone([out],218)|cone([marker]);care=run(n,(218,0))[1]^run(n,(218,FULL))[1]
cells=[i for i in range(1024) if care>>i&1]
cut={218};receipt=[]
for depth in range(1,10):
 cut=set.union(*(set(g[k-64]['inputs']) if k>=179 and k not in fixed else {k} for k in cut))
 if depth<8:continue
 B=sorted(cut);sig=lambda c:sum((vs[w]>>c&1)<<j for j,w in enumerate(B))
 p={sig(c) for c in cells if vs[218]>>c&1};q={sig(c) for c in cells if not vs[218]>>c&1};assert not p&q
 diffs={a^b for a in p for b in q};mand=sum((1<<i) for i in range(len(B)) if (1<<i) in diffs)
 residual=[e for e in diffs if not e&mand];opt=[i for i in range(len(B)) if not mand>>i&1];tight=[]
 for sz in range(len(opt)+1):
  for sub in combinations(opt,sz):
   m=mand|sum(1<<j for j in sub)
   if any(not e&m for e in residual):continue
   selected=[w for j,w in enumerate(B) if m>>j&1];closure=fixed|cone(selected);lower=len(closure)+len(selected)-1
   if lower<=170:tight.append((selected,len(closure),lower))
 item=next(r for r in ref if r['depth']==depth)['pools'];assert sorted(s for s,_,_ in tight)==sorted(r['support'] for r in item)
 for r,(sel,k,lb) in zip(item,tight):
  c,d=r['descent'];assert c in cells and d in cells and vs[218]>>c&1 and not vs[218]>>d&1 and all((vs[w]>>c&1)<=(vs[w]>>d&1) for w in sel)
  assert marker in fixed and marker not in sel and lb==170
  receipt.append(dict(depth=depth,boundary_count=len(B),observable=len(cells),unary_not_required=True,tight_supports=len(tight),inputs=len(sel),fixed_plus_support=k,marker=marker,marker_is_feature=marker in sel,descent=[c,d],bound=lb+1))
print(receipt);(H/'root218-independent.json').write_text(json.dumps(receipt))
