import json,itertools,collections,sys
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/site-team-09')
from fork_certificate import partitions
H=Path('/dev/shm/site-team-01-abc-drafts/enc');F=json.load(open(H/'low169last-manifest.json'));hist={tuple(x['ports']):x for x in json.load(open(H/'alter246-hyper-forks.json'))};cs={tuple(x['ports']):x for x in json.load(open(H/'alter246-one-prefix-inverter.json'))};allB=json.load(open('/tmp/singleton-alter246-depth5-lb.json'))['bank'];out=[]
for r in F:
 if tuple(r['ports']) not in {tuple(z['ports']) for z in json.load(open(H/'low169last-manifest.json'))}:continue
 ports=tuple(r['ports']);h=hist[ports];bits=[allB.index(w) for w in next(q['binate'] for q in json.load(open(H/'alter246-fork-summary.json'))['results'] if tuple(q['ports'])==ports)];memo={}
 def can(g,sg):
  if (g,sg) in memo:return memo[g,sg]
  return True
 groups=set()
 for f,n in [(2,2)]:
  for bf in range(1,f+1):
   sg=min(bf,n-1);flags=[0]*(bf-sg)+[1]*sg
   for pa in partitions(bits,h['positive'],h['general'],bf-sg,sg):
    if any(not g or not can(g,flag) for g,flag in zip(pa,flags)):continue
    for p in itertools.permutations(list(zip(pa,flags))+[(0,1)]*(f-bf)):groups.add(p)
 out.append(dict(ports=ports,patterns=sorted(groups)))
out.sort(key=lambda q:len(q['patterns']));print([(x['ports'][-3:],len(x['patterns'])) for x in out[:12]],flush=True)
(H/'low169last-rank.json').write_text(json.dumps(out))
