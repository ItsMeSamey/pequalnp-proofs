from pathlib import Path
import hashlib,json,collections
H=Path(__file__).parent
def get(p):return json.loads((H/p).read_bytes())
def hashfile(p):return hashlib.sha256((H/p).read_bytes()).hexdigest()
parent='fixed141-combined-v1-561.json';out=get(parent);rows=out['rows']
for r in rows:r['verified_lower']=171 if r['independent_status'] in ('receipt','inherited-baseline') else r['baseline_lower']
by={tuple(r['ports']):r for r in rows};assert len(by)==583
for i,r in enumerate(get('fixed141-low25-independent.json')):
 p=f'notation-slack25-2signed-{i}.json';q='fixed141-low25-independent.json';s=by[tuple(r['ports'])]
 assert get(p)['ports']==s['ports'] and r['open_cases']==[] and s['verified_lower']==169 and len(s['ports'])==25
 s.update(verified_lower=170,low20_index=i,lower170_receipts=[p,q])
 out['receipt_sha256'].update({p:hashfile(p),q:hashfile(q)})
for x in get('low169-last-three-summary.json'):
 i=x['index'];s=by[tuple(x['ports'])];p=f'low169-region-{i}.jsonl';q=f'low169-independent-{i}.jsonl'
 assert x['primary_sha256']==hashfile(p) and x['recheck_sha256']==hashfile(q) and x['lower']==171 and s['verified_lower']==170 and len(s['ports'])==26
 s.update(verified_lower=171,low20_index=i,primary_excluded=True,independent_status='receipt',additional_primary=p,additional_independent=q)
 out['receipt_sha256'].update({p:hashfile(p),q:hashfile(q)})
out['receipt_sha256']['low169-last-three-summary.json']=hashfile('low169-last-three-summary.json')
out['parent_ledger']=parent;out['parent_sha256']=hashfile(parent)
out['additional_low20_independent_ids']=[17,18,19]
counts=collections.Counter(x['verified_lower'] for x in rows)
out['verified_lower_histogram']=dict(counts);out['total_independent_including_inherited_baseline']=counts[171];out['total_primary']=sum(x['primary_excluded'] for x in rows)
assert counts=={170:19,171:564}
path=H/'fixed141-combined-v2-564.json';blob=json.dumps(out,separators=(',',':'));assert not path.exists() or path.read_text()==blob;path.write_text(blob)
print(counts,path)
