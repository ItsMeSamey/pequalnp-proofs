import pathlib,itertools,collections,json,sys
H=pathlib.Path('/dev/shm/site-team-01-abc-drafts/enc')
exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
rec=json.load(open(H/'notation-slack25-local-independent-4.json'));ports=rec['ports'];ids=[B.index(z) for z in ports];s=sum(1<<i for i in ids);care={x&s:y for x,y in L.items()}
piv={i:[x for x,y in care.items() if not x>>i&1 and care.get(x|1<<i,y)!=y] for i in ids}
bi=[i for i in ids if len({care[x] for x in piv[i]})==2];bits={i:1<<k for k,i in enumerate(bi)};common=s^sum(1<<i for i in bi);N=1<<len(bi);full=(1<<N)-1;U=N-1
cols={i:((full//((1<<(1<<k))+1))<<(1<<k)) for k,i in enumerate(bi)}
V={}
for negs in [[]]+rec['feasible_source_sets']:
 neg=sum(1<<B.index(w) for w in negs);D=sum(bits[B.index(w)] for w in negs);buckets={}
 for i in bi:
  for x in piv[i]:
   low,high=buckets.setdefault(x&common,([],[]));l=x^neg;h=(x|1<<i)^neg
   if neg>>i&1:l,h=h,l
   low.append((l,i));high.append((h,i))
 ctr={}
 for low,high in buckets.values():
  for x,i in high:
   for y,j in low:
    ante=(1<<i)|(1<<j);diff=x&~y&~common
    if not ante&diff:ctr.setdefault(ante,set()).add(diff)
 allow=full
 for i in bi:
  if neg>>i&1:allow&=cols[i]
 for a,ds in ctr.items():
  t=full
  for i in bi:
   if a>>i&1:t&=cols[i]
  mins=[]
  for d in sorted(ds,key=int.bit_count):
   if any(not(k&~d) for k in mins):continue
   mins.append(d);has=0
   for i in bi:
    if d>>i&1:has|=cols[i]
   allow&=~(t&~has)
 buf=allow.to_bytes((N+7)//8,'little');V[D]=[k for k in range(N) if buf[k>>3]>>(k%8)&1]
sys.path.insert(0,'/workspace/scratch/site-team-09');from fork_certificate import derive_edges,orientation_witnesses
gen,pos=derive_edges(care,bi,common,orientation_witnesses(care,bi,common))
cv=lambda m:sum(bits[i] for i in bi if m>>i&1)
G=[cv(j) for j in gen];P=[cv(j) for j in pos|gen]
allowed=lambda m,sg:not any(m&e==e for e in (G if sg else P))
V={d:[a for a in groups if allowed(a,bool(d))] for d,groups in V.items()}; aset=[(a,d) for d,groups in V.items() for a in groups];two=[];parallel=[]
for (a,d),(b,e) in itertools.combinations_with_replacement(aset,2):
 if a&b or (d and e):continue
 c=U^(a|b)
 if not allowed(c,not (d or e)):continue
 two.append((a,d,b,e,c))
 for neg,groups in V.items():
  if c in groups and sum(map(bool,(d,e,neg)))<=1:parallel.append([a,d,b,e,c,neg])
print('bi',len(bi), 'minimal',[(d,len(gs)) for d,gs in V.items()],'parallel',len(parallel),'two',len(two),flush=True)
(H/'coercions-threefork4-minimal.json').write_text(json.dumps(dict(ports=ports,binate=[B[i] for i in bi],minimal=V,two=two,parallel=parallel)))
