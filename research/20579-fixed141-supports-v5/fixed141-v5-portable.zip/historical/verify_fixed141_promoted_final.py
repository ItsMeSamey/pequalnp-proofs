from audit141later import *
from itertools import combinations
from collections import defaultdict
case=int(sys.argv[1]);src=json.load(open('/tmp/singleton-promoted-unique-%d.json'%case));ports=tuple(src[0]['ports']);I=[B.index(w) for w in ports]
lab,_=rebuilder(ports);mask=sum(1<<j for j in I);cells={x&mask:i for i,x in enumerate(W)}
dirs={};pairs={}
for i in I:
 pp=[(cells[x],cells[x^(1<<i)]) for x,y in lab.items() if not x>>i&1 and lab.get(x^(1<<i))==1-y]
 dirs[i]={t>>c&1 for c,e in pp};pairs[i]=pp
binate=sum(1<<i for i,z in dirs.items() if len(z)==2);non=mask^binate
flip=sum(1<<j for j,z in dirs.items() if z=={1});ign=sum(1<<j for j,z in dirs.items() if not z)

arch=next(r for r in json.load(open(H/'low26-promoted-singleton-functional.json')) if tuple(r['ports'])==ports)
@lru_cache(None)
def parallel_edges(visible):
 return [(a,b) for x,a in cells.items() if lab[x] for y,b in cells.items() if not lab[y] and not((x^y)&ign&visible or (x^flip)&~(y^flip)&visible)]
def test(gs,flags,topo,loc):
 allowed=[non,non,non]
 for pos,k in loc:
  assert not binate>>pos&1 # A port that is itself a fork belongs to its own fork region.
  for q in range(3):
   if q!=k:allowed[q]&=~(1<<pos)
 # Node 0 is Boolean zero, node 1 is a free signed bypass orientation.
 parent={};phase={}
 def root(x):
  if x not in parent:parent[x]=x;phase[x]=0
  if x!=parent[x]:
   y=parent[x];parent[x]=root(y);phase[x]^=phase[y]
  return parent[x]
 def rel(a,b):
  if root(a)!=root(b):return None
  return phase[a]^phase[b]
 def force(a,b,p):
  u,v=root(a),root(b);q=phase[a]^phase[b]^p
  if u==v:return not q
  parent[v]=u;phase[v]=q;return True
 # A clause is an OR of signed parity observations. Apply unit closure only.
 clauses=[]
 def clause(*obs):clauses.append(obs)
 def key(j,c):return 2+c+j*1024
 def orient(j,i):return 2050+j*len(B)+i
 for j,g in enumerate(gs):
  avail=(gs[j]|allowed[j]) if topo=='parallel' or j==0 else gs[0]|gs[1]|allowed[0]|allowed[1]
  proj={}
  for x,c in cells.items():clause((key(j,c),key(j,proj.setdefault(x&avail,c)),0))
  for i in I:
   if not g>>i&1:continue
   for a,b in pairs[i]:
    clause((key(j,a),orient(j,i),0));clause((key(j,b),orient(j,i),1))
   if not flags[j]:clause((orient(j,i),0,0))
 if topo=='parallel':
  for a,b in parallel_edges(allowed[2]):
   clause((key(1,a),key(1,b),1),(key(0,a),key(0,b),1))
 else:
  # Unateness at the first fork in its all-positive binate block.
  for x,a in cells.items():
   for y,b in cells.items():
    if a==b:continue
    diff=x^y
    if topo=='chain' and not flags[0] and not(diff&allowed[0]) and not(x&~y&gs[0]):
     clause((key(0,a),0,0),(key(0,b),0,1))
    if lab[x]==1 and lab[y]==0 and not(diff&ign&allowed[2] or (x^flip)&~(y^flip)&allowed[2]):
     if topo=='parallel':
      clause((key(1,a),key(1,b),1),(key(0,a),key(0,b),1))
      continue
     # Equal later state needs oriented bypass value high at positive, low at negative.
     clause((key(1,a),key(1,b),1),(key(0,a),1,1))
     clause((key(1,a),key(1,b),1),(key(0,b),1,0))
     clause((key(1,a),key(1,b),1),(key(0,a),key(0,b),1))
    if topo=='parallel':continue
    outer=diff&(gs[1]|allowed[1])
    if not outer:
     clause((key(0,a),key(0,b),1),(key(1,a),key(1,b),0))
    elif outer.bit_count()==1 and outer&gs[1] and not x&outer:
     j=outer.bit_length()-1
     clause((key(0,a),key(0,b),1),(key(1,a),orient(1,j),0),(key(1,b),orient(1,j),1))
     # Equivalent ternary clauses useful to parity-unit propagation.
     clause((key(0,a),key(0,b),1),(key(1,a),key(1,b),0),(key(1,a),orient(1,j),0))
     clause((key(0,a),key(0,b),1),(key(1,a),key(1,b),0),(key(1,b),orient(1,j),1))
    if topo=='chain' and not flags[0] and not(diff&allowed[0]) and not(x&~y&gs[0]):
     clause((key(0,a),key(0,b),0),(key(0,a),0,0))
 rounds=0
 while True:
  rounds+=1;rest=[];progress=False
  for cn in clauses:
   rem=[]
   for a,b,p in cn:
    r=rel(a,b)
    if r==p:break
    if r is None:rem.append((a,b,p))
   else:
    if not rem:return rounds
    if len(rem)==1:
     assert force(*rem[0]);progress=True
    else:rest.append(rem)
  if not progress:return None
  clauses=rest

out=[]
# Can start from the archived survivor list while the independent enumeration runs.
receipt=H/'fixed141-promoted14-16-initial.json'
initial=next((r for r in json.load(open(receipt)) if tuple(r['ports'])==ports),None) if receipt.exists() else None
if initial is None:initial={'open_cases':[(list(zip(gs,flags)),topo) for gs,flags,topo in arch['pinned_relaxation']]}
for grouped,topo in initial['open_cases']:
 gs,flags=map(list,zip(*grouped))
 r=next((r for r in src if r['groups']==gs and r['flags']==flags and r['topology']==topo),None)
 if r:
  assert r['resolved'] and not r['survivors'] and not r['pending']
  locs=[x for x,_ in r['visited']]
  def cover(paths):
   if [] in paths:return len(paths)==1
   assert paths
   i=paths[0][0][0]
   assert all(z[0][0]==i for z in paths)
   return all(cover([z[1:] for z in paths if z[0][1]==q]) for q in range(3))
  assert cover(locs) and all(len(set(i for i,_ in loc))==len(loc) for loc in locs)
 else:
  locs=[[]]
 for loc in locs:
  z=test(gs,flags,topo,loc);out.append([gs,flags,topo,loc,z]);assert z,(gs,flags,topo,loc)
(H/f'low20-{case}-independent-parity-clauses.json').write_text(json.dumps(out));print(case,len(out))
