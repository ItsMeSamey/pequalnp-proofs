import json,itertools,collections,pathlib
p=pathlib.Path('/dev/shm/site-team-01-abc-drafts/enc')
exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
old=json.load(open('/tmp/singleton-low20-phases.json'))
ledger=json.load(open(p/'alter246-bypass-consolidated.json'))
results=[]
for idx,rr in enumerate(z for z in ledger if len(z['ports'])==25 and z['lower']==169):
 if idx!=13:continue
 ports=rr['ports'];q=next(z for z in old if z['ports']==ports)
 ids=[B.index(w) for w in ports];s=sum(1<<i for i in ids)
 care={a&s:y for a,y in L.items()};zero=set(q['first_gate_zero']);one=set(q['first_gate_one'])
 assert not any(not o&~z for o in one for z in zero)
 piv={};bi=[]
 for i in ids:
  t=1<<i;lo=[a for a,y in care.items() if not a&t and care.get(a|t,y)!=y];piv[i]=lo
  if len({care[a] for a in lo})==2:bi.append(i)
 common=s^sum(1<<b for b in bi)
 forbidden={};pair={}
 for i in bi:
  t=1<<i;v0=piv[i];v1=[a|t for a in v0]
  bad=next(((o,z) for o in one|set(v1) for z in zero|set(v0) if not o&~z),None)
  if bad:forbidden[B[i]]=bad
 for i,j in itertools.combinations(bi,2):
  if B[i] in forbidden or B[j] in forbidden:continue
  bad=next(((a|1<<i,b) for a in piv[i] for b in piv[j] if not (a|1<<i)&~b),None) or next(((b|1<<j,a) for a in piv[i] for b in piv[j] if not (b|1<<j)&~a),None)
  if bad:pair[f'{B[i]},{B[j]}']=bad
 bits={i:1<<k for k,i in enumerate(bi)};N=1<<len(bi);full=(1<<N)-1
 columns={i:((full//((1<<(1<<k))+1))<<(1<<k)) for k,i in enumerate(bi)}
 buckets={}
 for i in bi:
  for l in piv[i]:
   low,high=buckets.setdefault(l&common,([],[]));low.append((l,i));high.append((l|1<<i,i))
 constraints={}
 for low,high in buckets.values():
  for x,i in high:
   for y,j in low:
    diff=(x&~y)&~common; antecedent=(1<<i)|(1<<j)
    if not diff&antecedent:constraints.setdefault(antecedent,set()).add(diff)
 allow=full
 for a,ds in constraints.items():
  t=full
  for i in bi:
   if a>>i&1:t&=columns[i]
  smaller=[]
  for d in sorted(ds,key=int.bit_count):
   if any((k&d)==k for k in smaller):continue
   smaller.append(d);covered=0
   for i in bi:
    if d>>i&1:covered|=columns[i]
   allow&=~(t&~covered)
 valid={j for j,b in enumerate(allow.to_bytes((N+7)//8,'little')) for j in []} if False else set()
 data=allow.to_bytes((N+7)//8,'little')
 for i in range(1,N):
  if data[i>>3]>>(i%8)&1:valid.add(i)
 universe=N-1;total=0;witness=[];by={}
 for a in valid:
  if not a&1:continue
  rem=universe^a
  b=rem
  while b:
   c=rem^b
   if c>b and b in valid and c in valid:
    total+=1
    if len(witness)<4:witness.append([a,b,c])
   b=(b-1)&rem
 pairs=sum((universe^a) in valid for a in valid)//2; print('one/two/three',int(universe in valid),pairs,total,flush=True)
 print('unsigned prefix group count',len(valid),'parallel partitions',total,'example',witness,flush=True)
 # If two forks are minimal, grant the third arbitrary use of either precursor.
 import sys;sys.path.insert(0,"/workspace/scratch/site-team-09");from fork_certificate import derive_edges,orientation_witnesses
 import sys
 G=sum(1<<j for j in bi)
 gen,positive=derive_edges(care,bi,common,orientation_witnesses(care,bi,common))
 cv=lambda d:sum(bits[j] for j in bi if d>>j&1)
 general=[cv(d) for d in gen];positive=[cv(d) for d in positive|gen]
 aset=sorted(valid|{0});cases=collections.Counter();examples={}
 for i,a in enumerate(aset):
  for b in aset[i:]:
   if a&b:continue
   c=universe^(a|b)
   if any(c&d==d for d in general):continue
   cat='requires signed downstream group' if any(c&d==d for d in positive) else 'unsigned or signed downstream'
   cases[cat]+=1;examples.setdefault(cat,[a,b,c])
 print('two minimal relaxation',cases,examples)
 (p/'notation-slack25-2minimal-13.json').write_text(json.dumps(dict(ports=ports,binate=[B[i] for i in bi],counts=cases,examples=examples)))
