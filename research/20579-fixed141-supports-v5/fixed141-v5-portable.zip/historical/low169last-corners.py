from pathlib import Path
import json,itertools,hashlib,re,sys,collections
sys.path.insert(0,'/workspace/scratch/site-team-09')
from fork_certificate import derive_edges,orientation_witnesses
h=Path('/dev/shm/site-team-01-abc-drafts/enc');cert=json.load(open(h/'low169last-manifest.json'))[int(sys.argv[1])];ports=cert['ports']
src=next(Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'));assert hashlib.sha256(src.read_bytes()).hexdigest()==src.stem.split('-')[1]
g=json.loads(src.read_bytes())['gates'];goal=[int(z,16) for z in re.findall('0x[0-9a-f]+',json.load(open('/tmp/pnp-official-20579-public.json'))['gap']['statement'])]
Z=[];Y=[];rep={}
for cell in range(1024):
 r,c=divmod(cell,32);v=[j in (r,c+32) for j in range(64)]
 for q in g:
  bits=[v[i] for i in q['inputs']];v.append(all(bits) if q['op']=='and' else any(bits) if q['op']=='or' else not bits[0])
 x=sum(int(v[w])<<i for i,w in enumerate(ports));y=(goal[r]>>c)&1;Z.append(x);Y.append(y);rep[x]=cell
A={x:Y[c] for x,c in rep.items()};assert all(A[x]==y for x,y in zip(Z,Y))
dire={};bi=[];non=0;ign=0;flip=0
for j in range(len(ports)):
 piv=[(c,rep[x^(1<<j)]) for x,c in rep.items() if not x>>j&1 and Y[c]!=A.get(x^(1<<j),Y[c])]
 ds={Y[a] for a,b in piv}
 if len(ds)==2:bi.append(j);dire[j]=piv
 elif ds:non|=1<<j;flip|=next(iter(ds))<<j
 else:ign|=1<<j
bm=sum(1<<j for j in bi);F=(1<<len(ports))-1
sig,pos=derive_edges(A,bi,F^bm,orientation_witnesses(A,bi,F^bm));pos|=sig
pair={}
for a,b in itertools.combinations(bi,2):
 m=1<<a|1<<b;fib={}
 for x,y in A.items():fib.setdefault(x&~m,[]).append(((x>>a&1)+2*(x>>b&1),y))
 pair[a,b]={c for c in range(4) if all(any(all((t>>k&1)==y for k,y in rs) for t in [0,15,3,12,5,10,1<<c,15^(1<<c)]) for rs in fib.values())}
from functools import lru_cache
@lru_cache(None)
def signable(mask,signed):
 block=[j for j in bi if mask>>j&1]
 if not block:return True
 if any(e&mask==e for e in (sig if signed else pos)):return False
 # Normalize the arbitrary common phase only for the pair corner test.
 def visit(i,ph):
  if i==len(block):return True
  j=block[i]
  for v in (range(2) if signed and i else [0]):
   if all(((z+2*v in pair[t,j]) or (3-z-2*v in pair[t,j])) for t,z in ph):
    if visit(i+1,ph+[(j,v)]):return True
  return False
 return visit(0,[])
scenarios=set()
if signable(bm,True):
 scenarios.add(((bm,1),))
 for e in (((bm,1),(0,1)),((0,1),(bm,1))):scenarios.add(e)
for m in range(1,(1<<len(bi))-1):
 a=sum(1<<j for i,j in enumerate(bi) if m>>i&1);b=bm^a
 if signable(a,False) and signable(b,True):
  scenarios.add(((a,0),(b,1)));scenarios.add(((b,1),(a,0)))
print('independent scenarios',len(scenarios),flush=True)

base=json.load(open('/tmp/singleton-alter246-depth5-lb.json'))['bank'];patterns=[]
for sc in sorted(scenarios):
 if len(sc)!=2:continue
 pat=[(sum(1<<base.index(ports[i]) for i in range(len(ports)) if mask>>i&1),flag) for mask,flag in sc];patterns.append(pat)
(h/f"low169last-signed-{sys.argv[1]}.json").write_text(json.dumps(dict(ports=ports,patterns=patterns)))
print(len(patterns),sum(any(not x[0] for x in p) for p in patterns))
