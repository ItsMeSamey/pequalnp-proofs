from pathlib import Path
H=Path('/dev/shm/site-team-01-abc-drafts/enc')
exec((H/'verify-exact183-interface-lower.py').read_text().split('reports=[]')[0])
import itertools
r=next(k for k in json.load(open(H/'exact183-interface-lower.json'))['reports'] if k['root']==246 and k['depth']==5);B=sorted(set(r['cut'])-{116,190}|{122})
W=[sum(((v[w]>>c)&1)<<i for i,w in enumerate(B)) for c in range(1024)];L={w:(T>>c)&1 for c,w in enumerate(W)};assert all(L[w]==(T>>c)&1 for c,w in enumerate(W));P={w for w,l in L.items() if l};N=set(L)-P
wits={i:next(((w,w^(1<<i)) for w in P if w^(1<<i) in N),None) for i in range(len(B))};mand=[i for i,w in wits.items() if w];opt=[i for i,w in wits.items() if not w];print('mandatory',len(mand),[B[i] for i in mand],'optional',len(opt),flush=True)
res=[];best=[999,999];arg=[None,None];allup=(combine(cone(w) for w in B)|cone(mark)).bit_count()
for k in range(len(opt)+1):
 for sel in itertools.combinations(opt,k):
  ids=mand+list(sel);S=sum(1<<i for i in ids);p={w&S for w in P};n={w&S for w in N}
  if p&n:continue
  plus={i for i in ids if any(w>>i&1 and (w^(1<<i)) in n for w in p)};minus={i for i in ids if any(not(w>>i&1) and (w^(1<<i)) in n for w in p)}
  neg=bool(minus) or any(a&~b==0 for a in p for b in n);both=bool(plus&minus)
  gates=len(ids)-1+int(neg)+int(both);up=(combine(cone(B[i]) for i in ids)|cone(mark)).bit_count()
  row=dict(ports=[B[i] for i in ids],up=up,gates_lb=gates,neg=neg,binate=[B[i] for i in plus&minus])
  for idx,score in enumerate([allup+gates,up+gates]):
   if score<best[idx]:best[idx]=score;arg[idx]=row
  res.append((len(ids),up,gates))
print('supports',len(res),'frozen/refund',best,'arg',arg,flush=True)
json.dump(dict(bank=B,mandatory=[B[i] for i in mand],witness_cells={B[i]:[W.index(x) for x in wits[i]] for i in mand},separating=len(res),frozen_and_refunded=best,minimizers=arg,histogram={str(t):res.count(t) for t in set(res)}),open('/tmp/singleton-alter246-depth5-lb.json','x'))
