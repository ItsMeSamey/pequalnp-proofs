from pathlib import Path
import sys,json,itertools,collections
sys.path.insert(0,'/workspace/scratch/site-team-09');from fork_certificate import partitions
exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
Q=json.load(open(H/'alter246-one-prefix-inverter.json'));RH={tuple(z['ports']):z for z in json.load(open(H/'alter246-hyper-forks.json'))};RR={tuple(z['ports']):z for z in json.load(open(H/'alter246-fork-summary.json'))['results']};notes=[]
class DS:
 def __init__(self,n):self.p=list(range(n));self.v=[0]*n;self.sz=[1]*n
 def get(self,a):
  if self.p[a]!=a:
   b,v=self.get(self.p[a]);self.v[a]^=v;self.p[a]=b
  return self.p[a],self.v[a]
 def eq(self,a,b,p):
  a,x=self.get(a);b,y=self.get(b);p^=x^y
  if a==b:return -1 if p else 0
  if self.sz[a]<self.sz[b]:a,b=b,a
  self.p[b]=a;self.v[b]=p;self.sz[a]+=self.sz[b];return 1
ranked=json.load(open(H/'low26-promoted-singleton-rank.json'))
for pp in ranked:
 rr={'ports':pp['ports']}
 ports=rr['ports'];s=sum(1<<B.index(w) for w in ports);I=[i for i in range(len(B)) if s>>i&1];A={x&s:(c,T>>c&1) for c,x in enumerate(W)};bi={};non=ign=flip=0
 for i in I:
  h=[(c,A[x^(1<<i)][0]) for x,(c,l) in A.items() if not x>>i&1 and x^(1<<i) in A and A[x^(1<<i)][1]!=l];ds={T>>a&1 for a,b in h}
  if len(ds)==2:bi[i]=h
  elif ds:non|=1<<i;flip|=next(iter(ds))<<i
  else:ign|=1<<i
 rows=[(x,c,l,(x^flip)&non,x&ign) for x,(c,l) in A.items()];pos=[(c,u,h) for x,c,l,u,h in rows if l];neg=[(c,u,h) for x,c,l,u,h in rows if not l]
 edge=[(a,b) for a,ua,ha in pos for b,ub,hb in neg if ha==hb and not ua&~ub];K=1060;bm=sum(1<<i for i in bi);hr=RH[tuple(ports)]
 def classify(groups,flags,topology):
  f=len(groups);ds=[DS(K) for _ in groups];prior=non|ign
  for j,(g,flag) in enumerate(zip(groups,flags)):
   p=(prior|g) if topology=='chain' else (non|ign|g)
   prior|=g;keys={}
   for x,c,_,_,_ in rows:
    z=x&p
    if z in keys:ds[j].eq(c,keys[z],0)
    else:keys[z]=c
   for i,piv in bi.items():
    if not g>>i&1:continue
    for a,b in piv:
     if ds[j].eq(a,1024+i,0)<0 or ds[j].eq(b,1024+i,1)<0:return 'prefix'
    if not flag and ds[j].eq(1024+i,1059,0)<0:return 'pinned'
  classes={}
  if f==2 and topology=='chain':
   for x,c,*_ in rows:classes.setdefault(x&(non|ign|groups[1]),[]).append(c)
  carry=[(a,b) for cs in classes.values() for a,b in itertools.combinations(cs,2)]
  rem=edge;changes=1
  while changes:
   changes=0;stay=[]
   for a,b in rem:
    vals=[(d.get(a),d.get(b)) for d in ds]
    if f==1:
     z=ds[0].eq(a,b,1)
     if z<0:return 'one-fork'
     continue
    ((u,x),(v,j)),((r,k),(s0,l))=vals;d0,d1=ds
    same0=(u==v and x==j);diff0=(u==v and x!=j)
    same1=(r==s0 and k==l);diff1=(r==s0 and k!=l)
    if diff1:continue
    if topology=='chain':
     # H0 has at most one outgoing path to output bypassing H1; polarity sigma is fixed.
     # If H1 agrees, the positive cell must have high oriented H0 and the negative cell low H0.
     sig,sk=d0.get(1058)
     if same0 or u==sig and x^sk==0 or v==sig and j^sk==1:
      z=d1.eq(a,b,1)
      if z<0:return 'terminal-order'
      changes+=z;continue
     if same1:
      for c,val in ((a,1),(b,0)):
       z=d0.eq(c,1058,val)
       if z<0:return 'bypass-polarity'
       changes+=z
      continue
     # An H0 disagreement alone is not sufficient until its orientation is known.
     if u==sig and x^sk==1 and v==sig and j^sk==0:continue
    else:
     if diff0:continue
     if same0 or same1:
      d=d1 if same0 else d0;z=d.eq(a,b,1)
      if z<0:return 'parallel-state'
      changes+=z;continue
    stay.append((a,b))
   rem=stay
   cs=[]
   for a,b in carry:
    x,y=ds[0].get(a),ds[0].get(b);k,l=ds[1].get(a),ds[1].get(b)
    if x==y:
     z=ds[1].eq(a,b,0)
    elif k[0]==l[0] and k[1]!=l[1]:
     z=ds[0].eq(a,b,1)
    else:
     cs.append((a,b));continue
    if z<0:return 'chain-cut'
    changes+=z
   carry=cs
  return None
 result={};witness=[]
 for pa in pp['patterns']:
  G0,flags=zip(*pa)
  if len(pa)==1:
   policy=('parallel',)
  else:policy=('parallel','chain')
  for topology in policy:

   z=classify(G0,flags,topology)
   if z is None:witness.append([G0,flags,topology]);continue
   result[z]=result.get(z,0)+1

 notes.append(dict(ports=ports,patterns=len(pp['patterns']),lower=171 if not witness else 170,ruled_out=result,pinned_relaxation=witness))
 print(len(notes),len(pp['patterns']),result, 'open' if witness else 'EXCLUDED',flush=True)
 (H/'low26-promoted-singleton-functional.json').write_text(json.dumps(notes))

