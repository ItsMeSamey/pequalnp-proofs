from checkpoint import *
from hashlib import sha256
H=Path(__file__).parent.resolve()
source=next(Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'))
n=normalize(json.loads(source.read_bytes()));v,original,marker,shard=run(n);g=n['gates'];assert audit(n)['mismatches']==0 and marker==69
def cone(ws):
 seen=set();todo=list(ws)
 while todo:
  k=todo.pop()
  if k<64 or k in seen:continue
  seen.add(k);todo.extend(g[k-64]['inputs'])
 return seen
def donor(d,B):
 vs,y,m,s=run(d); stop={v[w] for w in B};todo=[d['output']];seen=set();escaped=set();used=set()
 while todo:
  w=todo.pop()
  if w>=len(vs):continue
  if vs[w] in stop:used.add(vs[w]);continue
  if w<64:escaped.add(w);continue
  if w in seen:continue
  seen.add(w);todo.extend(d['gates'][w-64]['inputs'])
 physical=None
 if not escaped:
  order=sorted(cone(B)|cone([marker]));mp={w:64+i for i,w in enumerate(order)}
  fixed=[dict(op=g[w-64]['op'],inputs=[mp.get(a,a) for a in g[w-64]['inputs']]) for w in order]
  sy={v[w]:mp.get(w,w) for w in B}; idx={};zero=10000000
  def copy(w):
   if w>=len(vs):return zero
   if vs[w] in sy:return sy[vs[w]]
   if w in idx:return idx[w]
   q=d['gates'][w-64];aa=[copy(a) for a in q['inputs']]
   idx[w]=64+len(fixed);fixed.append(dict(op=q['op'],inputs=aa));return idx[w]
  o=copy(d['output']);z=dict(gates=fixed,output=o);a=audit(z);assert a['shard']==53 and not a['mismatches'];physical=a['size']
 return dict(fixed_graft_size=physical,interfaced=not escaped,used_ports=len(used),uncaptured_inputs=sorted(escaped),residual_gates=len(seen),correct=y==original,marker=m,shard=s)
files=[*Path('/workspace/scratch/site-team-04/leanbridge').glob('*.json'),*H.glob('*181*.json'),*H.glob('retained*.json'),*H.glob('decoder151-best.json'),*H.glob('root246-d6-decoder.json')]
donors={};meta={}
for f in files:
 try:d=normalize(json.loads(f.read_bytes()))
 except (ValueError,TypeError,KeyError,AttributeError):continue
 if len(d['gates'])!=181 and f.name not in ('decoder151-best.json','root246-d6-decoder.json'):continue
 a=audit(d)
 if a['mismatches']:continue
 donors[str(f)]=d;meta[str(f)]=dict(size=len(d['gates']),shard=a['shard'],sha256=sha256(f.read_bytes()).hexdigest())
cert=json.load(open(H/'exact183-interface-lower.json'));cut={246};res=[]
for dep in range(1,11):
 cut={w for k in cut for w in (g[k-64]['inputs'] if k>=179 else [k])}
 if dep<5:continue
 b=sorted(cut);assert b==next(q['cut'] for q in cert['reports'] if q['root']==246 and q['depth']==dep)
 for swap in ([False,True] if dep in (7,8) else [False]):
  B=sorted([142 if w==151 and swap else w for w in b]);labels={};bad=set()
  for u in range(1024):
   key=sum((v[w]>>u&1)<<i for i,w in enumerate(B));z=original>>u&1
   if labels.setdefault(key,z)!=z:bad.add(key)
  cl=cone(B);paid=cl|cone([marker]);rr={p:donor(d,B) for p,d in donors.items()}
  res.append(dict(depth=dep,swap=swap,ports=B,words=len(labels),collision_signatures=len(bad),port_closure=len(cl),marker_in_port_closure=marker in cl,marker_in_ports=marker in B,charged=len(paid),remaining=170-len(paid),donors=rr))
data=dict(source_sha256=sha256(source.read_bytes()).hexdigest(),donors=meta,reports=res)
(H/'root246-interface-audit.json').write_text(json.dumps(data,indent=2))
for q in res:print(q['depth'],q['swap'],len(q['ports']),q['words'],q['collision_signatures'],q['port_closure'],q['charged'],[Path(f).name for f,s in q['donors'].items() if s['interfaced']])
print([(Path(k).name,len(d['gates'])) for k,d in donors.items()])
