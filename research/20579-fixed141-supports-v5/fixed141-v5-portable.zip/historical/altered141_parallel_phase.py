from pathlib import Path
import json,collections
exec(Path('/tmp/singleton_246alterlb.py').read_text().split('res=[];')[0])
rows=json.loads((H/'alter246-hyper-forks.json').read_text());cache=[]
for row in rows:
 if row['lower']!=169:continue
 S=sum(1<<B.index(w) for w in row['ports'])
 pts={x&S:((T>>i)&1,i) for i,x in enumerate(W)}
 rank={};prev={}
 for x in sorted(pts,key=int.bit_count):
  vals=[(d+(pts[u][0]>pts[x][0]),u) for u,d in rank.items() if not u&~x]
  rank[x],prev[x]=max(vals,default=(0,None))
 d=max(rank.values());p=max(rank,key=rank.get);chain=[]
 while p is not None:chain+=[pts[p][1]];p=prev[p]
 # Generate monotone threshold functions A_j for rank>=j, on original feature poset.
 # Unary outputs NOT A_j become extra inputs of a monotone interpolator.
 terms=[]
 for j in range(1,d+1):
  lows=[]
  for x in sorted(rank,key=int.bit_count):
   if rank[x]>=j and all(a&~x for a in lows):lows.append(x)
  assert all(any(a&~x==0 for a in lows)==(rank[x]>=j) for x in pts)
  terms.append(lows)
 def lifted(x):return x | sum((rank[x]<k)<<(len(B)+k-1) for k in range(1,d+1))
 LP=[lifted(x) for x in pts if pts[x][0]];LN=[lifted(x) for x in pts if not pts[x][0]]
 assert all(p&~n for p in LP for n in LN)
 cache.append(dict(ports=row['ports'],descents=d,chain=chain[::-1],operand_minimal_positive_masks=terms))
print(collections.Counter(r['descents'] for r in cache),[(len(i['operand_minimal_positive_masks'][0]),len(i['operand_minimal_positive_masks'][1])) for i in cache])
(H/'alter246-parallel-phase.json').write_text(json.dumps(dict(bank=B,fixtures=cache)))
for r in cache:
 S=sum(1<<B.index(w) for w in r['ports']);ps={x&S for x in P};ns={x&S for x in N}
 E=[(p,n) for p in ps for n in ns if not p&~n]
 # For every ordered pair of descent edges, two parallel NOT operands must switch once each.
 # The bipartite direction (first or second on a two-drop chain) fixes relative colors.
 graph=[set() for e in E]
 for i,(p,n) in enumerate(E):
  for j,(q,t) in enumerate(E):
   if not n&~q:graph[i].add(j);graph[j].add(i)
 done=set();strong=[]
 for i in range(len(E)):
  if i in done or not graph[i]:continue
  C={i:0};stack=[i]
  while stack:
   a=stack.pop()
   for b in graph[a]:
    if b not in C:C[b]=1-C[a];stack.append(b)
    assert C[a]!=C[b]
  done|=C.keys();pairs=[]
  for k in [0,1]:
   L={E[v][0] for v in C if C[v]==k};Hh={E[v][1] for v in C if C[v]==k}
   pos={B[(h&~l).bit_length()-1] for h in Hh for l in L if (h&~l).bit_count()==1}
   pairs.append(sorted(pos))
  strong.append((len(C),pairs))
 r['parallel_forced_supports_mod_swap']=sorted(strong,reverse=True)
print('largest forced support lower pairs',[(len(r['parallel_forced_supports_mod_swap'][0][1][0]),len(r['parallel_forced_supports_mod_swap'][0][1][1])) for r in cache])
(H/'alter246-parallel-phase.json').write_text(json.dumps(dict(bank=B,fixtures=cache)))
