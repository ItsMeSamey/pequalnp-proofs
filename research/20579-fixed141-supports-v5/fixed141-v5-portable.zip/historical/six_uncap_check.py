from pathlib import Path
from collections import Counter
import sys,json
H=Path(__file__).parent;impl=(H/'uncap13-indep.py').read_text()
setup=impl[impl.index('src=next('):impl.index('sig,pos=derive_edges')]
checker=impl[impl.index('class Components:'):impl.index('hist=collections.Counter()')]
manifest={q['index']:q['ports'] for q in json.load(open(H/'uncapped-singleton-ports.json'))};patterns={tuple(q['ports']):q['patterns'] for q in json.load(open(H/'uncapped-singleton-rank.json'))};B=json.load(open('/tmp/singleton-alter246-depth5-lb.json'))['bank'];summary={q['id']:q for q in json.load(open('/tmp/singleton-uncapped-summary.json'))}
import hashlib,re,itertools
ans=[]
for sid in (1,3,4,19,21,22):
 ports=manifest[sid];ns=globals().copy();exec(setup+checker,ns);ptr=ns['check'];hist=Counter();orders=0;opened=[]
 def local(g):return sum(1<<i for i,w in enumerate(ports) if g>>B.index(w)&1)
 for p in patterns[tuple(ports)]:
  sc=tuple((local(g),flag) for g,flag in p)
  for parallel in ([True] if len(p)==1 else [True,False]):
   result=[ptr(sc,parallel,phase) for phase in ([0] if parallel else [0,1])]
   orders+=1;hist.update(result)
   if 'OPEN' in result:opened.append([sc,parallel,result])
 assert orders==summary[sid]['tested'];ans.append(dict(id=sid,orders=orders,oriented=sum(hist.values()),open=opened,hist=hist));print(sid,orders,sum(hist.values()),len(opened),flush=True)
 (H/'six-uncap-independent.json').write_text(json.dumps(ans))
