from pathlib import Path
import json,itertools,hashlib,re,sys,collections
sys.path.insert(0,'/workspace/scratch/site-team-09')
from fork_certificate import derive_edges,orientation_witnesses
h=Path('/dev/shm/site-team-01-abc-drafts/enc');records=[s for s in json.load(open(h/'marker32-inversion-lower.json'))['supports'] if 69 in s['ports'] and len(s['ports'])==26];assert len(records)==16
rec=records[int(sys.argv[1])];ports=rec['ports'];assert rec['tail_not']==2

src=next(Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'));assert hashlib.sha256(src.read_bytes()).hexdigest()==src.stem.split('-')[1]
g=json.loads(src.read_bytes())['gates'];goal=[int(z,16) for z in re.findall('0x[0-9a-f]+',json.load(open('/tmp/pnp-official-20579-public.json'))['gap']['statement'])]
Z=[];Y=[];rep={}
for cell in range(1024):
 r,c=divmod(cell,32);v=[j in (r,c+32) for j in range(64)]
 for q in g:
  bits=[v[i] for i in q['inputs']];v.append(all(bits) if q['op']=='and' else any(bits) if q['op']=='or' else not bits[0])
 x=sum(int(v[w])<<i for i,w in enumerate(ports));y=(goal[r]>>c)&1;Z.append(x);Y.append(y);rep[x]=cell
A={x:Y[c] for x,c in rep.items()};assert all(A[x]==y for x,y in zip(Z,Y))
ordered=sorted(rep,key=lambda x:(x.bit_count(),x));chains={}
for x in ordered:
 c=rep[x];path=[c]
 for y in chains:
  if y&~x:continue
  last=chains[y]
  if Y[last[-1]]!=Y[c] and len(last)+1>len(path):path=last+[c]
 chains[x]=path
desc=next(z[k:k+4] for z in chains.values() for k in range(len(z)-3) if [Y[c] for c in z[k:k+4]]==[1,0,1,0])
assert all(not Z[a]&~Z[b] for a,b in zip(desc,desc[1:]))
(h/('notation-active32-chain-'+sys.argv[1]+'.json')).write_text(json.dumps(dict(ports=ports,cells=desc,labels=[Y[c] for c in desc],patterns=[Z[c] for c in desc])))
