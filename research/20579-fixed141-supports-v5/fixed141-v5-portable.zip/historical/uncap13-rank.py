import json,itertools,collections,sys
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/site-team-09')
from fork_certificate import partitions
H=Path('/dev/shm/site-team-01-abc-drafts/enc');F=json.load(open(H/'alter246-downstream-ordered-tuples.json'));hist={tuple(x['ports']):x for x in json.load(open(H/'alter246-hyper-forks.json'))};cs={tuple(x['ports']):x for x in json.load(open(H/'alter246-one-prefix-inverter.json'))};allB=json.load(open('/tmp/singleton-alter246-depth5-lb.json'))['bank'];out=[]
for r in F:
 if tuple(r['ports']) not in {tuple(z['ports']) for z in json.load(open(H/'uncapped-coercions-ports.json'))}:continue
 ports=tuple(r['ports']);h=hist[ports];b=cs[ports];corn={tuple(map(int,k.split(','))):v for k,v in b['corners'].items()};bits=sorted({allB.index(i) for k in corn for i in k});memo={}
 def can(g,sg):
  if (g,sg) in memo:return memo[g,sg]
  ii=[j for j in bits if g>>j&1];fr=[{}]
  for i in ii:
   nf=[]
   for a in fr:
    for v in ((0,1) if sg and a else (0,)):
     if all(corn[allB[j],allB[i]]&(1<<(x+2*v)|1<<((1-x)+2*(1-v))) for j,x in a.items()):nf.append({**a,i:v})
   fr=nf
   if not fr:break
  ans=bool(fr);memo[g,sg]=ans;return ans
 groups=set()
 for f,n in [(1,3),(2,2)]:
  for bf in range(1,f+1):
   sg=min(bf,n-1);flags=[0]*(bf-sg)+[1]*sg
   for pa in partitions(bits,h['positive'],h['general'],bf-sg,sg):
    if any(not g or not can(g,flag) for g,flag in zip(pa,flags)):continue
    for p in itertools.permutations(list(zip(pa,flags))+[(0,1)]*(f-bf)):groups.add(p)
 out.append(dict(ports=ports,patterns=sorted(groups)))
out.sort(key=lambda q:len(q['patterns']));print([(x['ports'][-3:],len(x['patterns'])) for x in out[:12]],flush=True)
(H/'uncap13-rank.json').write_text(json.dumps(out))
