"""Check the weighted-pair support certificate using only integer arithmetic."""
from hashlib import sha256
import json
from pathlib import Path
import re

folder = Path(__file__).parent
statement = json.loads(Path('/tmp/pnp-official-20579-public.json').read_bytes())['gap']['statement']
rows = [int(value, 16) for value in re.findall('0x[0-9a-f]+', statement)]
assert len(rows) == 32
for record in json.loads((folder / 'wholecut156-full-support.json').read_bytes()):
    source = Path(record['source']).read_bytes()
    assert sha256(source).hexdigest() == record['source_sha256']
    network = json.loads(source)
    network = network.get('net', network)
    gates = network['gates'][:record['prefix_gates']]
    def values(cell):
        row, col = divmod(cell, 32)
        bits = [int(i in (row, 32 + col)) for i in range(64)]
        for gate in gates:
            pins = [bits[i] for i in gate['inputs']]
            if gate['op'] == 'not':
                value = not pins[0]
            elif gate['op'] == 'or':
                value = any(pins)
            else:
                assert gate['op'] == 'and'
                value = all(pins)
            bits.append(int(value))
        return bits, (rows[row] >> col) & 1
    charge = [0] * record['source_count']
    total = 0
    for left, right, weight in record['witnesses']:
        assert weight > 0 and 0 <= left < 1024 and 0 <= right < 1024
        a, target_a = values(left)
        b, target_b = values(right)
        assert target_a != target_b and len(a) == len(b) == len(charge)
        charge = [c + weight * (x != y) for c, x, y in zip(charge, a, b)]
        total += weight
    cap = record['denominator']
    assert max(charge) <= cap and total == record['numerator']
    support = (total + cap - 1) // cap
    assert support == record['minimum_sources']
    print(Path(record['source']).name, support, len(gates) + support - 1)
