"""Verify the equality-case obstruction for root 218 on two fixed cuts."""
import hashlib
import itertools
import json
import re
from functools import lru_cache
from pathlib import Path

here = Path(__file__).parent
ledger = json.loads((here / 'exact183-interface-lower.json').read_bytes())
raw = Path(ledger['source']).read_bytes()
assert hashlib.sha256(raw).hexdigest() == ledger['source_sha256']
network = json.loads(raw)
gates = network['gates']
root, output, marker = 218, network['output'], ledger['marker']
table = json.loads(Path('/tmp/pnp-official-20579-public.json').read_bytes())['gap']['statement']
rows = [int(x, 16) for x in re.findall('0x[0-9a-f]+', table)]
@lru_cache(None)
def ancestors(w, stop=None):
    if w < 64 or w == stop:
        return frozenset()
    return frozenset([w]).union(*(ancestors(a, stop) for a in gates[w-64]['inputs']))
def evaluate(cell, override=None):
    r,c = divmod(cell,32)
    vals = [int(i in (r,32+c)) for i in range(64)]
    for w,gate in enumerate(gates,64):
        pins = [vals[i] for i in gate['inputs']]
        vals.append(override if w == root and override is not None else
                    int(all(pins) if gate['op']=='and' else any(pins) if gate['op']=='or' else not pins[0]))
    return vals
observed = {}
for i in range(1024):
    v = evaluate(i)
    assert v[output] == (rows[i//32]>>(i%32)&1)
    if evaluate(i,0)[output] != evaluate(i,1)[output]:
        observed[i] = v
fixed = ancestors(output,root) | ancestors(marker)
for rec in ledger['reports']:
    if rec['root']!=root or rec['depth'] not in (8,9):
        continue
    ports = rec['cut']
    mandatory = sorted(map(int,rec['mandatory_witnesses']))
    for w in mandatory:
        a,b = rec['mandatory_witnesses'][str(w)]
        assert observed[a][root]!=observed[b][root]
        assert [j for j in ports if observed[a][j]!=observed[b][j]]==[w]
    optional = sorted(set(ports)-set(mandatory))
    viable = 0
    for n in range(len(optional)+1):
        for subset in itertools.combinations(optional,n):
            s = mandatory+list(subset)
            cost = len(fixed.union(*(ancestors(w) for w in s))) + len(s)-1
            if cost>170:
                continue
            labels = {}
            for v in observed.values():
                key = tuple(v[j] for j in s)
                if labels.setdefault(key,v[root])!=v[root]:
                    break
            else:
                viable+=1
                assert observed[716][root]==1 and observed[126][root]==0
                assert all(observed[716][j]<=observed[126][j] for j in s)
                assert cost==170
    assert viable==1
    print('depth',rec['depth'],'lower bound',171)
