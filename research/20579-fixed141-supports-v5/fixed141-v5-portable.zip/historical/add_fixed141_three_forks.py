from pathlib import Path
import json,hashlib,collections
H=Path(__file__).parent
def J(p):return json.loads((H/p).read_bytes())
def sha(p):return hashlib.sha256((H/p).read_bytes()).hexdigest()
parent='fixed141-combined-v3-567.json';d=J(parent);known={tuple(x['ports']):x for x in d['rows']}
assert len(known)==583
for i in [4,13]:
 a=f'notation-slack25-2signed-{i}.json';b=f'notation-slack25-wide-{i}.json';ports=J(a)['ports'];r=known[tuple(ports)]
 assert r['verified_lower']==170 and r['low20_index']==i
 assert J(b)['ports']==ports and not J(b)['one_signed_group'] and not J(b)['open_orders'] and not J(a)['open_orders']
 if i==4:
  p='coercions-threefork4-summary.json';q='coercions-threefork4-independent.json';ev=list(J(p)['sources'])
  assert all(sha(f)==hv for f,hv in J(p)['sources'].items()) and J(p)['open']==J(p)['three_parallel_partitions']==0
  assert not J(q)['open_two'] and sum(J(q)['two_minimal'].values())==J(p)['two_minimal_orderings']==1623
  assert J(q)['total']==J(p)['unique_minimal_chains']+J(p)['unique_minimal_splits']==8607
 else:
  p='notation-slack25-uniquemin-strong13.json';q='notation-slack25-unique-independent13.json'
  ev=[f'notation-slack25-{x}' for x in ['local-independent-13.json','parallel-13.json','2minimal-13.json','2minimal-states13.json','uniquemin-unate13.json','uniquemin-candidates13.json','uniquemin-prefix13.json']]
  assert not J(ev[0])['feasible_source_sets'] and J(ev[1])['parallel_partitions']==0
  assert not J(ev[3])['open'] and sum(J(ev[3])['hist'].values())==3*sum(J(ev[2])['counts'].values())==432
  assert not J(p)['open'] and J(q)['input_sha256']==sha(ev[4]) and sum(J(p)['hist'].values())==J(q)['total']==5275
 assert J(q)['ports']==ports and not J(q)['open'] and J(q)['total']==sum(J(q)['histogram'].values())
 for f in [a,b,p,q]+ev:d['receipt_sha256'][f]=sha(f)
 r.update(verified_lower=171,primary_excluded=True,independent_status='receipt',additional_primary=p,additional_independent=q,cap170_topology_receipts=[a,b]+ev,coverage='At least two new inversions. At most three units of total surplus fanout. One fork of degree up to four, two forks of degrees two and at most three, or three forks of degree two.')
d['parent_ledger']=parent;d['parent_sha256']=sha(parent)
counts=collections.Counter(x['verified_lower'] for x in known.values())
assert counts=={171:569,170:14}
d['additional_low25_three_fork_ids']=[4,13];d['verified_lower_histogram']=dict(counts);d['total_independent_including_inherited_baseline']=counts[171];d['total_primary']=sum(x['primary_excluded'] for x in known.values())
target=H/'fixed141-combined-v4-569.json';s=json.dumps(d,separators=(',',':'));assert not target.exists() or target.read_text()==s;target.write_text(s);print(sha(target),counts)
