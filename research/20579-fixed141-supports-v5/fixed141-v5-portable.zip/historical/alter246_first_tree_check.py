exec(open('/tmp/notation-altered.py').read().split('for k in range(len(opt)+1):')[0])
from functools import lru_cache
D=json.load(open(H/'alter246-hyper-forks.json'));R={tuple(r['ports']):r for r in json.load(open(H/'alter246-fork-summary.json'))['results']};out=[];hist=collections.Counter()
for r in D:
 if r['lower']!=170:continue
 rr=R[tuple(r['ports'])];I=[B.index(w) for w in r['ports']];s=sum(1<<i for i in I);A={x&s:l for x,l in L.items()};bi=[B.index(w) for w in rr['binate']];corn={}
 for i,j in itertools.combinations(bi,2):
  grp={};valid=15;m=(1<<i)|(1<<j)
  for x,l in A.items():
   key=x&~m;z=1<<(((x>>i)&1)+2*((x>>j)&1));p,n=grp.get(key,(0,0))
   if l:p|=z
   else:n|=z
   grp[key]=p,n;valid&=okcorner[p,n]
   if not valid:break
  corn[i,j]=valid
 @lru_cache(None)
 def feasible(g,sign):
  ids=[i for i in bi if g>>i&1]
  if len(ids)<=1:return True
  orientations=[{}]
  for i in ids:
   new=[]
   for o in orientations:
    for v0 in ((0,1) if sign and o else (0,)):
     if any(not any((corn[j,i]>>(a+2*b)&1) for a,b in [(v,v0),(1-v,1-v0)]) for j,v in o.items()):continue
     new.append({**o,i:v0})
   if not new:return False
   orientations=new
  for o in orientations:
   @lru_cache(None)
   def tree(t):
    if t.bit_count()<=1:return True
    vs=[i for i in ids if t>>i&1]
    for phase in [0,1]:
     stack=[{i} for i in vs]
     for i,j in itertools.combinations(vs,2):
      corner=(o[i]^phase)+2*(o[j]^phase)
      if corn[i,j]>>corner&1:continue
      ai=next(k for k,c in enumerate(stack) if i in c);aj=next(k for k,c in enumerate(stack) if j in c)
      if ai!=aj:
       stack[ai]|=stack[aj];stack.pop(aj)
     if len(stack)>1 and all(tree(sum(1<<i for i in c)) for c in stack):return True
    return False
   if tree(g):return True
  return False
 base=140+len(I);surv=None
 for n in range(2 if rr['drops'] else 1,170-base):
  f=170-base-n;sg=min(n-1,f);flags=[False]*(f-sg)+[True]*sg
  hs=[r['general'] if signed else r['positive'] for signed in flags]
  seq=sorted(bi,key=lambda j:-sum(1/e.bit_count() for h in hs for e in h if e>>j&1))
  def search(index,groups):
   if index==len(seq):return groups
   bit=1<<seq[index]
   for k,g in enumerate(groups):
    if g==0 and any(not groups[j] and flags[j]==flags[k] for j in range(k)):continue
    z=g|bit
    if any(z&e==e for e in hs[k]) or not feasible(z,flags[k]):continue
    new=search(index+1,groups[:k]+[z]+groups[k+1:])
    if new:return new
   return None
  q=search(0,[0]*f)
  if q:surv=[n,q];break
 lb=170 if surv else 171;hist[lb]+=1;out.append(dict(ports=r['ports'],lower=lb,survivor=surv,corners={f'{B[i]},{B[j]}':v for (i,j),v in corn.items()}))
 if len(out)%10==0 or len(out)==1:print(len(out),hist,flush=True);(H/'alter246-first-tree.json').write_text(json.dumps(out))
(H/'alter246-first-tree.json').write_text(json.dumps(out));print('done',hist)
