exec(open('/tmp/notation-altered.py').read().split('for k in range(len(opt)+1):')[0])
from functools import lru_cache
D=json.load(open(H/'alter246-hyper-forks.json'));R={tuple(r['ports']):r for r in json.load(open(H/'alter246-fork-summary.json'))['results']};out=[];hist=collections.Counter()
tables=[];ctypes={};signmask=[0]*8
for signs in range(8):
 for lone in range(3):
  for op1,op2 in itertools.product((0,1),repeat=2):
   vars=[sum(1<<x for x in range(8) if (x>>j&1)^(signs>>j&1)) for j in range(3)];u,vv=[vars[j] for j in range(3) if j!=lone];r=vars[lone]
   C=set()
   for a,b in itertools.product((0,255,u),(0,255,vv)):
    h=a&b if op1==0 else a|b
    for t,z in itertools.product((0,255,h),(0,255,r)):
     yy=t&z if op2==0 else t|z;C.update([yy,255^yy])
   signmask[signs]|=1<<len(tables);tables.append(C)
alltypes=(1<<len(tables))-1

todo={tuple(z['ports']) for z in json.load(open(H/'alter246-triple-tree.json')) if z['lower']==170}
for r in D:
 if r['lower']!=170 or tuple(r['ports']) not in todo:continue
 rr=R[tuple(r['ports'])];I=[B.index(w) for w in r['ports']];s=sum(1<<i for i in I);A={x&s:l for x,l in L.items()};bi=[B.index(w) for w in rr['binate']];corn={}
 for i,j in itertools.combinations(bi,2):
  grp={};valid=15;m=(1<<i)|(1<<j)
  for x,l in A.items():
   key=x&~m;z=1<<(((x>>i)&1)+2*((x>>j)&1));p,n=grp.get(key,(0,0))
   if l:p|=z
   else:n|=z
   grp[key]=p,n;valid&=okcorner[p,n]
   if not valid:break
  corn[i,j]=valid
 @lru_cache(None)
 def triple_allowed(i,j,k):
  keys=(i,j,k);m=sum(1<<a for a in keys);fib={}
  for x,l in A.items():
   q=x&~m;b=1<<(((x>>i)&1)+2*((x>>j)&1)+4*((x>>k)&1));u,vv=fib.get(q,(0,0))
   fib[q]=(u|b,vv) if l else (u,vv|b)
  allowed=alltypes
  for u,vv in set(fib.values()):
   if not u or not vv:continue
   c=(u,vv)
   if c not in ctypes:
    keep=0
    for ix,tt in enumerate(tables):
     if any(not (u&~yy or vv&yy) for yy in tt):keep|=1<<ix
    ctypes[c]=keep
   allowed &=ctypes[c]
   if not allowed:break
  return allowed
 @lru_cache(None)
 def feasible(g,sign):
  ids=[i for i in bi if g>>i&1]
  if len(ids)<=1:return True
  orientations=[{}]
  for i in ids:
   new=[]
   for o in orientations:
    for v0 in ((0,1) if sign and o else (0,)):
     if any(not any((corn[j,i]>>(a+2*b)&1) for a,b in [(v,v0),(1-v,1-v0)]) for j,v in o.items()):continue
     if any(not triple_allowed(a,b,i)&signmask[v1+2*v2+4*v0] for (a,v1),(b,v2) in itertools.combinations(o.items(),2)):continue
     new.append({**o,i:v0})
   if not new:return False
   orientations=new
  for o in orientations:
   @lru_cache(None)
   def tree(t):
    if t.bit_count()<=1:return True
    vs=[i for i in ids if t>>i&1]
    for phase in [0,1]:
     stack=[{i} for i in vs]
     for i,j in itertools.combinations(vs,2):
      corner=(o[i]^phase)+2*(o[j]^phase)
      if corn[i,j]>>corner&1:continue
      ai=next(k for k,c in enumerate(stack) if i in c);aj=next(k for k,c in enumerate(stack) if j in c)
      if ai!=aj:
       stack[ai]|=stack[aj];stack.pop(aj)
     if len(stack)>1 and all(tree(sum(1<<i for i in c)) for c in stack):return True
    return False
   @lru_cache(None)
   def coherent(t,forced):
    if t.bit_count()<=1:return True
    vs=[i for i in ids if t>>i&1];fm={(i,j):mask for i,j,mask in forced}
    for gateop in (0,1):
     # Crossing pairs must accept this signed AND/OR LCA.
     sets=[{i} for i in vs]
     for i,j in itertools.combinations(vs,2):
      a=o[i]^(1-gateop);b=o[j]^(1-gateop)
      if corn[i,j]>>(a+2*b)&1 and fm.get((i,j),3)>>gateop&1:continue
      si=next(k for k,x in enumerate(sets) if i in x);sj=next(k for k,x in enumerate(sets) if j in x)
      if si!=sj:sets[si]|=sets[sj];sets.pop(sj)
     if len(sets)<=1:continue
     cs=[sum(1<<i for i in vs) for vs in sets]
     for pick in range(1<<(len(cs)-1)):
      left=cs[0]|sum(c for j,c in enumerate(cs[1:]) if pick>>j&1);right=t^left
      if not right:continue
      extra=fm.copy();ok=True
      for tri in itertools.combinations(vs,3):
       sels=tuple(bool(left>>j&1) for j in tri)
       if all(sels) or not any(sels):continue
       lone=sels.index(sum(sels)==1);a,b=(v for k,v in enumerate(tri) if k!=lone);i,j,k=tri;sg=o[i]+2*o[j]+4*o[k]
       opts=(triple_allowed(*tri)>>(12*sg+4*lone+gateop))&5
       mask=(opts&1)|((opts>>1)&2)
       v0=extra.get((a,b),3)&mask
       if not v0:ok=False;break
       if v0!=3:extra[a,b]=v0
      if not ok:continue
      if all(coherent(branch,tuple(sorted((i,j,m) for (i,j),m in extra.items() if branch>>i&branch>>j&1))) for branch in (left,right)):return True
    return False
   if coherent(g,()):return True
  return False
 base=140+len(I);surv=None
 for n in range(2 if rr['drops'] else 1,170-base):
  f=170-base-n;sg=min(n-1,f);flags=[False]*(f-sg)+[True]*sg
  hs=[r['general'] if signed else r['positive'] for signed in flags]
  seq=sorted(bi,key=lambda j:-sum(1/e.bit_count() for h in hs for e in h if e>>j&1))
  def search(index,groups):
   if index==len(seq):return groups
   bit=1<<seq[index]
   for k,g in enumerate(groups):
    if g==0 and any(not groups[j] and flags[j]==flags[k] for j in range(k)):continue
    z=g|bit
    if any(z&e==e for e in hs[k]) or not feasible(z,flags[k]):continue
    new=search(index+1,groups[:k]+[z]+groups[k+1:])
    if new:return new
   return None
  q=search(0,[0]*f)
  if q:surv=[n,q];break
 lb=170 if surv else 171;hist[lb]+=1;out.append(dict(ports=r['ports'],lower=lb,survivor=surv,corners={f'{B[i]},{B[j]}':v for (i,j),v in corn.items()}))
 if len(out)%10==0 or len(out)==1:print(len(out),hist,flush=True);(H/'alter246-simultaneous-trees.json').write_text(json.dumps(out))
(H/'alter246-simultaneous-trees.json').write_text(json.dumps(out));print('done',hist)
