from audit141later import *
H=Path(__file__).parent
def by(name):return {tuple(x['ports']):x for x in json.load(open(H/('alter246-'+name+'.json')))}
simple=by('singlefork-terminal-colors');prior=by('singlefork-output-parity');ordered=by('downstream-ordered-tuples');hyper=by('hyper-forks')
one=[k for k,r in simple.items() if r['excluded'] and not prior[k]['excluded']]
two=[k for k,r in ordered.items() if r['lower']==171]
class Parity:
 def __init__(self):self.rep=list(range(1060));self.bit=[0]*1060
 def base(self,k):
  if k!=self.rep[k]:
   j=self.rep[k];self.rep[k]=self.base(j);self.bit[k]^=self.bit[j]
  return self.rep[k]
 def force(self,a,b,p):
  i=self.base(a);j=self.base(b);z=p^self.bit[a]^self.bit[b]
  if i==j:return not z
  self.rep[j]=i;self.bit[j]=z;return True
 def relation(self,a,b):
  if self.base(a)==self.base(b):return self.bit[a]^self.bit[b]
  return None
out=[]
ids=[17,18]
ps=[json.load(open('/tmp/singleton-parallel-unique-%d.json'%i))[0]['ports'] for i in ids]
allrec=[r for r in json.load(open(H/'uncapped-singleton-functional-results.json')) if r['ports'] in ps]
receipt=H/'ID17-18-initial-independent.json'
if receipt.exists():out=json.loads(receipt.read_text())
done={tuple(z['ports']) for z in out}
for rec in allrec:
 if tuple(rec['ports']) in done:continue
 ports=tuple(rec['ports'])
 lab,fiber=rebuilder(ports);I=[B.index(w) for w in ports];sel=sum(1<<i for i in I);mx=sum(1<<j for j in I)
 cell={w&mx:i for i,w in enumerate(W)}
 dirs={};piv={}
 for j in I:
  ps=[(cell[w],cell[w^(1<<j)]) for w,y in lab.items() if not w>>j&1 and lab.get(w^(1<<j))==1-y]
  dirs[j]={t>>a&1 for a,b in ps}
  if len(dirs[j])==2:piv[j]=ps
 bi=sum(1<<j for j in piv);un=sum(1<<j for j in I if len(dirs[j])==1);neg=sum(1<<j for j in I if dirs[j]=={1});ign=sel^bi^un
 P=[w for w,y in lab.items() if y];N=[w for w,y in lab.items() if not y];edges=[(cell[x],cell[y]) for x in P for y in N if not((x^y)&ign) and not((x^neg)&~(y^neg)&un)]
 drops=rank[ports]['drops'];assert [t>>i&1 for i in drops]==[1,0,1,0] and all(not(W[a]&~W[b]&sel) for a,b in zip(drops,drops[1:]))
 hr=hyper[ports];opt=set()
 def permitted(mask,sign):return not any(e&mask==e for e in hr['general' if sign else 'positive'])
 if permitted(bi,1):
  opt.add(((bi,1),))
  opt.add(((bi,1),(0,1)));opt.add(((0,1),(bi,1)))
 # Enumerate all ordered splits directly; either designated group can be the signed one.
 m=bi
 while m:
  rest=bi^m
  if rest:
   for a,b in [(0,1),(1,0)]:
    if permitted(m,a) and permitted(rest,b):opt.add(((m,a),(rest,b)))
  m=(m-1)&bi

 @lru_cache(None)
 def oriented(group,signed):
  bits=[j for j in piv if group>>j&1]
  def assign(k,values):
   if k==len(bits):return True
   j=bits[k]
   for b in (0,1) if signed and k else (0,):
    ok=True
    for i,a in values:
     z=a+2*b if i<j else b+2*a
     if not fiber(tuple(sorted((i,j)))) & ((1<<z)|(1<<(3-z))):ok=False;break
    if ok and assign(k+1,values+[(j,b)]):return True
   return False
  return assign(0,[])
 opt={g for g in opt if all(oriented(mask,sign) for mask,sign in g)}
 stated=next(r for r in json.load(open(H/'uncapped-singleton-rank.json')) if tuple(r['ports'])==ports)
 assert opt=={tuple(tuple(a) for a in g) for g in stated['patterns']}

 from collections import Counter
 total=Counter();open_cases=[]
 @lru_cache(None)
 def prefix_possible(group,signed,seenmask):
  # Only projected signatures at pivotal endpoints can contradict a required orientation.
  reps={};ds=Parity()
  for j,ps in piv.items():
   if not(group>>j&1):continue
   for a,b in ps:
    for k,parity in ((a,0),(b,1)):
     z=W[k]&seenmask
     if not ds.force(reps.setdefault(z,k),1024+j,parity):return False
   if not signed and not ds.force(1024+j,1059,0):return False
  return True
 for groups in opt:
  for topo in ['parallel','chain'] if len(groups)>1 else ['parallel']:
   passed=True;prev=0
   for gg,ss in groups:
    if not prefix_possible(gg,ss,un|ign|gg|(prev if topo=='chain' else 0)):passed=False;break
    prev|=gg
   if not passed:total['prefix']+=1;continue
   state=[];prior=0;failed=False
   for group,signed in groups:
    ds=Parity();state.append(ds);seen={};mask=un|ign|group|(prior if topo=='chain' else 0);prior|=group
    for x,k in cell.items():
     if not ds.force(k,seen.setdefault(x&mask,k),0):failed=True
    for j,ps in piv.items():
     if group>>j&1:
      for a,b in ps:
       if not ds.force(a,1024+j,0) or not ds.force(b,1024+j,1):failed=True;break
      if not signed and not ds.force(1024+j,1059,0):failed=True
   if failed:total['prefix']+=1;continue
   # Clause for each (positive a, negative b), hypothesizing equality on the later fork:
   # in chain topology require H0(a) matches high orientation, H0(b) low.
   if len(state)==1:
    if all(state[0].force(a,b,1) for a,b in edges):open_cases.append([groups,topo])
    else:total['single-terminal']+=1
    continue
   d0,d1=state
   while True:
    changed=False
    for a,b in edges:
     r0=d0.relation(a,b);r1=d1.relation(a,b)
     if r1==1:continue
     if topo=='chain':
      pa,pb=d0.relation(a,1058),d0.relation(b,1058)
      if pa==0 or pb==1 or r0==0:
       if not d1.force(a,b,1):failed=True;break
       changed|=r1 is None
      elif r1==0:
       if not d0.force(a,1058,1) or not d0.force(b,1058,0):failed=True;break
       changed|=pa is None or pb is None
     else:
      if r0==1:continue
      if r0==0:
       if not d1.force(a,b,1):failed=True;break
       changed|=r1 is None
      elif r1==0:
       if not d0.force(a,b,1):failed=True;break
       changed|=r0 is None
    if failed or not changed:break
   if failed:total[topo+'-terminal']+=1
   else:open_cases.append([groups,topo])
 assert (not open_cases)==(rec['lower']==171), (ports,total,open_cases)
 observed={tuple((tuple(a) for a in groups))+(topo,) for groups,topo in open_cases}
 expected={tuple(zip(gs,ss))+(tp,) for gs,ss,tp in rec['pinned_relaxation']}
 assert expected<=observed
 out.append(dict(ports=ports,patterns=len(opt),exclusions=total,open_cases=open_cases,terminal_edges=len(edges)))
 temp=receipt.with_suffix('.tmp');temp.write_text(json.dumps(out));temp.replace(receipt)
 print('verified row',len(out),'patterns',len(opt),'remaining configurations',len(open_cases),flush=True)
