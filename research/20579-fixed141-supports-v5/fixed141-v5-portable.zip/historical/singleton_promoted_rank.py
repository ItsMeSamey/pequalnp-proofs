exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
import sys
sys.path.insert(0,'/workspace/scratch/site-team-09');from fork_certificate import partitions
H=Path('/dev/shm/site-team-01-abc-drafts/enc');allB=B;out=[];hist={tuple(r['ports']):r for r in json.load(open(H/'alter246-hyper-forks.json'))};raw={tuple(r['ports']):r for r in json.load(open(H/'alter246-fork-summary.json'))['results']}
for ix in [14,15,16]:
 ports=tuple(json.load(open('/tmp/singleton-low20-allocations.json'))[ix]['ports']);s=sum(1<<B.index(w) for w in ports);A={x&s:y for x,y in L.items()};bits=sorted(B.index(w) for w in raw[ports]['binate']);corn={};h=hist[ports];memo={}
 for i,j in itertools.combinations(bits,2):
  m=1<<i|1<<j;fib={}
  for x,y in A.items():fib.setdefault(x&~m,[]).append(((x>>i&1)+2*(x>>j&1),y))
  corn[B[i],B[j]]=sum(1<<c for c in range(4) if all(any(all((t>>k&1)==y for k,y in rs) for t in [0,15,3,12,5,10,1<<c,15^(1<<c)]) for rs in fib.values()))

 def can(g,sg):
  if (g,sg) in memo:return memo[g,sg]
  ii=[j for j in bits if g>>j&1];fr=[{}]
  for i in ii:
   nf=[]
   for a in fr:
    for v in ((0,1) if sg and a else (0,)):
     if all(corn[allB[j],allB[i]]&(1<<(x+2*v)|1<<((1-x)+2*(1-v))) for j,x in a.items()):nf.append({**a,i:v})
   fr=nf
   if not fr:break
  ans=bool(fr);memo[g,sg]=ans;return ans
 groups=set()
 for f,n in [(2,2)]:
  for bf in range(1,f+1):
   sg=min(bf,n-1);flags=[0]*(bf-sg)+[1]*sg
   for pa in partitions(bits,h['positive'],h['general'],bf-sg,sg):
    if any(not g or not can(g,flag) for g,flag in zip(pa,flags)):continue
    for p in itertools.permutations(list(zip(pa,flags))+[(0,1)]*(f-bf)):groups.add(p)
 out.append(dict(ports=ports,patterns=sorted(groups)))
out.sort(key=lambda q:len(q['patterns']));print([(x['ports'][-3:],len(x['patterns'])) for x in out[:12]],flush=True)
(H/'low26-promoted-singleton-rank.json').write_text(json.dumps(out))
