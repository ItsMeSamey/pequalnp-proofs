import json,itertools,collections,pathlib
p=pathlib.Path('/dev/shm/site-team-01-abc-drafts/enc')
exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
old=json.load(open('/tmp/singleton-low20-phases.json'))
ledger=json.load(open(p/'alter246-bypass-consolidated.json'))
results=[]
for idx,rr in enumerate(z for z in ledger if len(z['ports'])==25 and z['lower']==169):
 if idx!=13:continue
 ports=rr['ports'];q=next(z for z in old if z['ports']==ports)
 ids=[B.index(w) for w in ports];s=sum(1<<i for i in ids)
 care={a&s:y for a,y in L.items()};zero=set(q['first_gate_zero']);one=set(q['first_gate_one'])
 assert not any(not o&~z for o in one for z in zero)
 piv={};bi=[]
 for i in ids:
  t=1<<i;lo=[a for a,y in care.items() if not a&t and care.get(a|t,y)!=y];piv[i]=lo
  if len({care[a] for a in lo})==2:bi.append(i)
 common=s^sum(1<<b for b in bi)
 forbidden={};pair={}
 for i in bi:
  t=1<<i;v0=piv[i];v1=[a|t for a in v0]
  bad=next(((o,z) for o in one|set(v1) for z in zero|set(v0) if not o&~z),None)
  if bad:forbidden[B[i]]=bad
 for i,j in itertools.combinations(bi,2):
  if B[i] in forbidden or B[j] in forbidden:continue
  bad=next(((a|1<<i,b) for a in piv[i] for b in piv[j] if not (a|1<<i)&~b),None) or next(((b|1<<j,a) for a in piv[i] for b in piv[j] if not (b|1<<j)&~a),None)
  if bad:pair[f'{B[i]},{B[j]}']=bad
 bits={i:1<<k for k,i in enumerate(bi)};N=1<<len(bi);full=(1<<N)-1
 columns={i:((full//((1<<(1<<k))+1))<<(1<<k)) for k,i in enumerate(bi)}
 buckets={}
 for i in bi:
  for l in piv[i]:
   low,high=buckets.setdefault(l&common,([],[]));low.append((l,i));high.append((l|1<<i,i))
 constraints={}
 for low,high in buckets.values():
  for x,i in high:
   for y,j in low:
    diff=(x&~y)&~common; antecedent=(1<<i)|(1<<j)
    if not diff&antecedent:constraints.setdefault(antecedent,set()).add(diff)
 allow=full
 for a,ds in constraints.items():
  t=full
  for i in bi:
   if a>>i&1:t&=columns[i]
  smaller=[]
  for d in sorted(ds,key=int.bit_count):
   if any((k&d)==k for k in smaller):continue
   smaller.append(d);covered=0
   for i in bi:
    if d>>i&1:covered|=columns[i]
   allow&=~(t&~covered)
 valid={j for j,b in enumerate(allow.to_bytes((N+7)//8,'little')) for j in []} if False else set()
 data=allow.to_bytes((N+7)//8,'little')
 for i in range(1,N):
  if data[i>>3]>>(i%8)&1:valid.add(i)
 universe=N-1;total=0;witness=[];by={}
 for a in valid:
  if not a&1:continue
  rem=universe^a
  b=rem
  while b:
   c=rem^b
   if c>b and b in valid and c in valid:
    total+=1
    if len(witness)<4:witness.append([a,b,c])
   b=(b-1)&rem
 pairs=sum((universe^a) in valid for a in valid)//2; print('one/two/three',int(universe in valid),pairs,total,flush=True)
 print('unsigned prefix group count',len(valid),'parallel partitions',total,'example',witness,flush=True)
 # If two forks are minimal, grant the third arbitrary use of either precursor.
 import sys;sys.path.insert(0,"/workspace/scratch/site-team-09");from fork_certificate import derive_edges,orientation_witnesses
 import sys
 G=sum(1<<j for j in bi)
 gen,positive=derive_edges(care,bi,common,orientation_witnesses(care,bi,common))
 cv=lambda d:sum(bits[j] for j in bi if d>>j&1)
 general=[cv(d) for d in gen];positive=[cv(d) for d in positive|gen]
 masks=[]
 for family in (general,positive):
  ok=full
  for edge in family:
   blocked=full
   for k,j in enumerate(bi):
    if edge>>k&1:blocked&=columns[j]
   ok&=~blocked
  masks.append(ok.to_bytes((N+7)//8,'little'))
 def allowed(a,k):return masks[k][a>>3]>>(a%8)&1

 from functools import lru_cache
 candidates=json.load(open(p/'notation-slack25-uniquemin-candidates13.json'))
 obs={}
 for i in bi:
  for x in piv[i]:
   obs.setdefault(x,set()).add((bits[i],0));obs.setdefault(x|1<<i,set()).add((bits[i],1))
 raw=lambda m:sum(1<<i for i in bi if m&bits[i])
 @lru_cache(None)
 def graph(omit):
  tag={};edges=set();mask=raw(omit)
  for x,entries in obs.items():tag.setdefault(x&~mask,set()).update(entries)
  for cluster in tag.values():
   for (i,a),(j,b) in itertools.combinations(cluster,2):
    i0,j0=sorted((i,j));edges.add((i0,j0,a^b))
  return tuple(edges)
 @lru_cache(None)
 def possible(group,omit,signed):
  ds={};ph={}
  def root(i):
   if i not in ds:ds[i]=i;ph[i]=0
   x=ds[i]
   if x!=i:
    f,h=root(x);ds[i]=f;ph[i]^=h
   return ds[i],ph[i]
  for i,j,t in graph(omit):
   if not (i&group and j&group):continue
   if not signed:
    if t:return False
    continue
   x,pg=root(i);y,qg=root(j)
   if x==y:
    if pg^qg!=t:return False
   else:ds[x]=y;ph[x]=t^pg^qg
  return True
 good=[];counts=collections.Counter()
 for a,b,c,sg in candidates:
  if not possible(b,c,sg==1):continue
  if possible(c,b,sg==2):good.append([a,b,c,sg,'split']);counts['split']+=1
  if possible(c,0,sg==2):good.append([a,b,c,sg,'chain']);counts['chain']+=1
 print('after prefix pivots',counts,flush=True)
 (p/'notation-slack25-uniquemin-prefix13.json').write_text(json.dumps(good))
