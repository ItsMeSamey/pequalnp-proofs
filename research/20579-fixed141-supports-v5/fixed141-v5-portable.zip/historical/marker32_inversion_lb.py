from checkpoint import *
from collections import Counter,defaultdict
from itertools import combinations
H=Path('.'); orig=json.load(open(next(Path('/dev/shm/04rank-s179-trajectory').glob('full183*'))));n=normalize(orig);v,_,marker,_=run(n);B=sorted(json.load(open('/tmp/singleton-alter246-depth5-lb.json'))['bank']+[69])
rows=[int(x,16) for x in re.findall('0x[0-9a-f]+',json.load(open(POST))['gap']['statement'])];labels=[rows[j//32]>>(j%32)&1 for j in range(1024)];Y=sum(y<<j for j,y in enumerate(labels))
W=[sum(((v[w]>>j)&1)<<i for i,w in enumerate(B)) for j in range(1024)]
P=[x for x,y in zip(W,labels) if y];N=[x for x,y in zip(W,labels) if not y];ds={p^q for p in P for q in N};assert 0 not in ds
mandatory=sum(d for d in ds if d.bit_count()==1);F=(1<<len(B))-1;optional=[1<<k for k in range(len(B)) if not mandatory>>k&1];cl=sorted((d for d in ds if not d&mandatory),key=int.bit_count);constraints=[]
for d in cl:
 if not any(c&d==c for c in constraints):constraints.append(d)
full=(1<<1024)-1;records=[];hist=defaultdict(Counter)
for q in range(1<<len(optional)):
 s=mandatory|sum(bit for idx,bit in enumerate(optional) if q>>idx&1)
 if any(not s&t for t in constraints):continue
 present=[B[i] for i in range(len(B)) if s>>i&1];idxs=[i for i in range(len(B)) if s>>i&1];proj={x&s:j for j,x in enumerate(W)}
 # bitsets of cells above each pattern, directly on projected coordinates
 above={}
 for x,j in proj.items():
  up=full;w=x
  while w:
   bit=w&-w;up &=v[B[bit.bit_length()-1]];w-=bit
  above[j]=up
 # Alternate upward closures of 1 and 0 cells; each 1-to-0 extension realizes one decrease.
 R=Y;D=0
 def close(z):
  u=0
  for j,up in above.items():
   if z>>j&1:u|=up
  return u
 while True:
  z=close(R)&~Y&full
  if not z:break
  D+=1;R=close(z)&Y
  if not R:break
 nots=D.bit_length()
 signs=[]
 for i in idxs:
  bit=1<<i;dirs={labels[j] for x,j in proj.items() if not x&bit and x^bit in proj and labels[j]!=labels[proj[x^bit]]}
  if len(dirs)==2:signs.append(B[i])
 binary=len(present)-1;lb=141+binary+nots
 key='active' if 69 in present else 'passive';hist[key][(len(present),D,nots,lb,lb+bool(signs))]+=1
 records.append(dict(ports=present,chain_drops=D,tail_not=nots,source_plus_not=lb,binate_ports=signs,binate_lb=lb+bool(signs)))
print({k:sorted(h.items()) for k,h in hist.items()},flush=True)
Path('marker32-inversion-lower.json').write_text(json.dumps(dict(bank=B,mandatory=[B[i] for i in range(len(B)) if mandatory>>i&1],fixed=141,supports=records)))
