from audit141later import *
simple={tuple(r['ports']):r for r in json.load(open(H/'alter246-singlefork-output-phase.json'))}
rows=json.load(open(H/'alter246-singlefork-output-parity.json'));logs=[]
for r in rows:
 ports=tuple(r['ports']);rr=rank[ports];drops=rr['drops']
 if len(ports)!=27 or not drops:continue
 m=sum(1<<B.index(w) for w in ports);s=[z&m for z in W];lab={}
 for c,z in enumerate(s):assert lab.setdefault(z,t>>c&1)==t>>c&1
 assert [t>>i&1 for i in drops]==[1,0,1,0] and all(s[x]&~s[y]==0 for x,y in zip(drops,drops[1:]))
 direct={};pivots={}
 for w in ports:
  i=B.index(w);b=1<<i;ds={z:y for z,y in lab.items() if not z&b and lab.get(z|b)==1-y};direct[i]=set(ds.values())
  if len(direct[i])==2:pivots[i]=ds
 ign=sum(1<<i for i,z in direct.items() if not z);neg=sum(1<<i for i,z in direct.items() if z=={1})
 uni=sum(1<<i for i,z in direct.items() if len(z)==1)
 def compare(x,y):
  if (x^y)&ign:return False
  a=(x^neg)&uni;b=(y^neg)&uni
  return a&~b==0 or b&~a==0
 old=simple[ports]; selfbad=False;edges=set()
 for i,j in itertools.combinations_with_replacement(sorted(pivots),2):
  for x,l in pivots[i].items():
   for y,k in pivots[j].items():
    if compare(x,y):edges.add((i,j,l^k));selfbad|=i==j and l!=k
 assert selfbad==old['excluded']
 for wire,a,b,c,d in old['incomparable_required']:
  i=B.index(wire);assert [t>>k&1 for k in (a,b,c,d)]==[0,1,1,0] and s[a]^(1<<i)==s[b] and s[c]^(1<<i)==s[d] and compare(s[a],s[c])
 observed=set()
 for i,j,k,(a,b,c,d) in r['phase_edges']:
  x=s[a];y=s[c];assert s[b]==x^(1<<i) and s[d]==y^(1<<j) and x in pivots[i] and y in pivots[j] and compare(x,y) and k==lab[x]^lab[y]
  observed.add((i,j,k))
 assert edges==observed
 # Signed graph consistency by GF(2) elimination of x_i XOR x_j = parity.
 basis={};contr=False
 for i,j,p in sorted(edges):
  vec=(1<<i)^(1<<j)
  while vec:
   lead=vec.bit_length()-1
   if lead not in basis:basis[lead]=(vec,p);break
   z,vv=basis[lead];vec^=z;p^=vv
  else:contr|=bool(p)
 assert contr==r['excluded']==(not r['phase_consistent'])
 logs.append(dict(ports=ports,self_conflict=selfbad,parity_conflict=contr,unique_equations=len(edges),no_observed_phase=ign.bit_count(),evidence_edges=len(r['phase_edges'])))
(H/'output-phase-parity-independent.json').write_text(json.dumps(logs))
print(len(logs),sum(x['self_conflict'] for x in logs),sum(x['parity_conflict'] for x in logs),sum(x['evidence_edges'] for x in logs))
