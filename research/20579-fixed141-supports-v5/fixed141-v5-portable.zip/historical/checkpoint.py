"""Normalize a physical AON checkpoint, verify all cells, and price one-wire aliases."""
import argparse
import json
import re
from pathlib import Path
from retained import FULL,RAW,Retained,ZERO

POST=Path('/tmp/pnp-official-20579-public.json')


def normalize(raw):
    raw=raw.get('net',raw)
    gs=raw.get('codes',raw.get('gates'))
    if not isinstance(gs,list):raise ValueError('missing physical gate list')
    result=[]
    for g in gs:
        if isinstance(g,dict):
            op,args=g['op'],g['inputs']
        else:
            op,*args=g
        if type(op) is int and 0<=op<=2:op=('and','or','not')[op]
        if op not in ('and','or','not') or len(args)>2 or any(type(a) is not int or a<0 for a in args):
            raise ValueError(f'invalid gate {g}')
        result.append({'op':op,'inputs':list(args[:1] if op=='not' else args)})
    out=raw['output']
    if type(out) is not int or out<0:raise ValueError('invalid output')
    return {'gates':result,'output':out}


def run(net,force=None):
    bits=RAW.copy(); first=None;shard=64
    for g in net['gates']:
        op=g['op'];args=g['inputs'];a=[bits[x] if x<len(bits) else 0 for x in args]
        if op=='not':v=FULL^(a[0] if a else 0)
        elif op=='or':v=(a[0] if a else 0)|(a[1] if len(a)==2 else 0)
        else:v=(a[0] if a else FULL)&(a[1] if len(a)==2 else FULL)
        if force and force[0]==len(bits):v=force[1]
        if first is None and op=='not' and args and 64<=args[0]<len(bits):
            first=len(bits);shard=sum((v>>(33*k)&1)<<k for k in range(6))
        bits.append(v)
    return bits,bits[net['output']] if net['output']<len(bits) else 0,first,shard


def coords(mask):
    return [list(divmod(i,32)) for i in range(1024) if mask>>i&1]


def audit(net):
    stmt=json.loads(POST.read_text())['gap']
    rows=re.findall(r'0x[0-9a-fA-F]+',stmt['statement'])
    assert stmt['id']=='L-meta-20579' and len(rows)==32
    target=sum(int(row,16)<<(32*i) for i,row in enumerate(rows))
    _,v,first,shard=run(net)
    errors=(target^v).bit_count()
    return dict(size=len(net['gates']),first_internal_not_wire=first,shard=shard,
                false_positives=coords(v&~target),false_negatives=coords(target&~v),
                mismatches=errors,witness=not errors and shard==53 and len(net['gates'])<=170)


def observability(net):
    """Exact output Boolean difference when the gate wire is clamped on each pair."""
    return {w:run(net,(w,0))[1]^run(net,(w,FULL))[1] for w in range(64,64+len(net['gates']))}


def trim(net,obs):
    bits,v,marker,_=run(net);best=net;move=None
    for w,sense in obs.items():
        if w==marker:continue
        for a in range(w):
            if (bits[a]^bits[w])&sense:continue
            patched={'gates':[],'output':a if net['output']==w else net['output']}
            for i,g in enumerate(net['gates'],64):
                patched['gates'].append({'op':g['op'],'inputs':[a if x==w and i>w else x for x in g['inputs']]})
            r=Retained(patched);cand=r.finish(r.retain(patched['output']))
            if cand['size']<len(best['gates']) and run(cand)[1]==v and run(cand)[3]==53:
                best=cand;move=[w,a]
    return best,move


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source',type=Path)
    ap.add_argument('--save-prefix',type=Path)
    a=ap.parse_args();n=normalize(json.loads(a.source.read_text()));receipt=audit(n)
    if a.save_prefix:
        base=str(a.save_prefix);obs=observability(n)
        best,move=trim(n,obs)
        for name,data in [('normalized',n),('observability',{w:hex(v) for w,v in obs.items()}),
                          ('best',best),('receipt',dict(original=receipt,best=audit(best),alias=move))]:
            Path(base+'-'+name+'.json').write_text(json.dumps(data)+'\n')
    print(json.dumps(receipt))
