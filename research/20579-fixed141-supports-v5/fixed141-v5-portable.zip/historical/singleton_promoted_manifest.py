import json,hashlib
from pathlib import Path
h=Path('/dev/shm/site-team-01-abc-drafts/enc');bank=json.load(open('/tmp/singleton-alter246-depth5-lb.json'))['bank'];ledger=json.load(open('/tmp/singleton-low20-allocations.json'));baseline=json.load(open(h/'low26-promoted-singleton-functional.json'));src=next(Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'))
def verify_tree(paths,prefix=()):
 if prefix in paths:return len(paths)==1
 if not paths:return False
 i=paths[0][len(prefix)][0]
 return all(len(p)>len(prefix) and p[len(prefix)][0]==i for p in paths) and all(verify_tree([p for p in paths if p[len(prefix)][1]==k],prefix+((i,k),)) for k in range(3))
items=[]
for idx in (14,15,16):
 p=Path(f'/tmp/singleton-promoted-unique-{idx}.json')
 if not p.exists():continue
 rec=json.load(open(p));ports=ledger[idx]['ports'];base=next(r for r in baseline if r['ports']==ports);assert len(rec)==len(base['pinned_relaxation'])
 models=[]
 for r in rec:
  assert r['ports']==ports
  if r['resolved']:assert verify_tree([tuple(tuple(a) for a in loc) for loc,why in r['visited']])
  models.append(dict(topology=r['topology'],groups=[[w for j,w in enumerate(bank) if g>>j&1] for g in r['groups']],signed=r['flags'],resolved=r['resolved'],exclusions=[dict(locations=[[bank[j],k] for j,k in loc],reason=why) for loc,why in r['visited']],pending=r['pending'],survivors=r['survivors']))
 items.append(dict(low20_index=idx,ports=ports,baseline_exclusions=base['ruled_out'],remaining_after_baseline=len(models),remaining_after_ownership=sum(not q['resolved'] for q in models),models=models))
print([(r['low20_index'],r['remaining_after_baseline'],r['remaining_after_ownership']) for r in items])
if len(items)==3:
 d=dict(bank=bank,prefix_gates=141,source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),supports=items)
 json.dump(d,open('/tmp/singleton-promoted-original31-models.json','x'))
