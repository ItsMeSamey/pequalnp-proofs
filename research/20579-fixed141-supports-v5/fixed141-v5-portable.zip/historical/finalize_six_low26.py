from pathlib import Path
import json,hashlib,collections
H=Path(__file__).parent
def read(p):return json.loads((H/p).read_bytes())
def digest(p):return hashlib.sha256((H/p).read_bytes()).hexdigest()
parent='fixed141-combined-v2-564.json';d=read(parent);rows={tuple(x['ports']):x for x in d['rows']}
initial={tuple(x['ports']):x for x in read('fixed141-promoted14-16-initial.json')}
alloc=read('/tmp/singleton-low20-allocations.json');new=[]
for i in [14,15,16]:
 p=f'/tmp/singleton-promoted-unique-{i}.json';q=f'low20-{i}-independent-parity-clauses.json'
 if not (H/q).exists():continue
 s=rows[tuple(alloc[i]['ports'])];z=initial[tuple(s['ports'])]
 ways={(tuple(zip(a,b)),t) for a,b,t,loc,proof in read(q) if proof}
 expected={(tuple(map(tuple,g)),t) for g,t in z['open_cases']}
 assert ways==expected and all(x[-1] for x in read(q)) and all(x['resolved'] for x in read(p))
 single=f'/tmp/singleton-low20-symbolic-fork-{i-14}.json';assert read(single)['ports']==s['ports']
 s.update(verified_lower=171,low20_index=i,primary_excluded=True,independent_status='receipt',additional_primary=p,additional_independent=q,one_fork_receipts=[single,'six-symbolic-negative-cycle-audit.json'])
 for f in [p,q,single,'six-symbolic-negative-cycle-audit.json','fixed141-promoted14-16-initial.json','low26-promoted-singleton-functional.json']:d['receipt_sha256'][f]=digest(f)
 new.append(i)
d['additional_low20_independent_ids']=sorted(d['additional_low20_independent_ids']+new)
d['parent_ledger']=parent;d['parent_sha256']=digest(parent)
counts=collections.Counter(x['verified_lower'] for x in rows.values());d['verified_lower_histogram']=dict(counts)
d['total_independent_including_inherited_baseline']=counts[171];d['total_primary']=sum(x['primary_excluded'] for x in rows.values())
path=H/f'fixed141-combined-v3-{counts[171]}.json';blob=json.dumps(d,separators=(',',':'));assert not path.exists() or path.read_text()==blob;path.write_text(blob);print(counts,path)
