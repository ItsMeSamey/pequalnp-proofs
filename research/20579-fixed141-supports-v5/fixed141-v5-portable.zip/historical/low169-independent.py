from pathlib import Path
import sys,json,itertools,collections
sys.path.insert(0,'/workspace/scratch/site-team-09');from fork_certificate import partitions
exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
Q=json.load(open(H/'alter246-one-prefix-inverter.json'));RH={tuple(z['ports']):z for z in json.load(open(H/'alter246-hyper-forks.json'))};RR={tuple(z['ports']):z for z in json.load(open(H/'alter246-fork-summary.json'))['results']};notes=[]
class DS:
 def __init__(self,n):self.p=list(range(n));self.v=[0]*n;self.sz=[1]*n
 def get(self,a):
  if self.p[a]!=a:
   b,v=self.get(self.p[a]);self.v[a]^=v;self.p[a]=b
  return self.p[a],self.v[a]
 def eq(self,a,b,p):
  a,x=self.get(a);b,y=self.get(b);p^=x^y
  if a==b:return -1 if p else 0
  if self.sz[a]<self.sz[b]:a,b=b,a
  self.p[b]=a;self.v[b]=p;self.sz[a]+=self.sz[b];return 1
ranked=json.load(open(H/'low169last-rank.json'))
rrindex=int(sys.argv[1])
pp=ranked[rrindex]
source=None
for pp in (pp,):
 rr={'ports':pp['ports']}
 ports=rr['ports'];s=sum(1<<B.index(w) for w in ports);I=[i for i in range(len(B)) if s>>i&1];A={x&s:(c,T>>c&1) for c,x in enumerate(W)};bi={};non=ign=flip=0
 for i in I:
  h=[(c,A[x^(1<<i)][0]) for x,(c,l) in A.items() if not x>>i&1 and x^(1<<i) in A and A[x^(1<<i)][1]!=l];ds={T>>a&1 for a,b in h}
  if len(ds)==2:bi[i]=h
  elif ds:non|=1<<i;flip|=next(iter(ds))<<i
  else:ign|=1<<i
 rows=[(x,c,l,(x^flip)&non,x&ign) for x,(c,l) in A.items()];pos=[(c,u,h) for x,c,l,u,h in rows if l];neg=[(c,u,h) for x,c,l,u,h in rows if not l]
 edge=[(a,b) for a,ua,ha in pos for b,ub,hb in neg if ha==hb and not ua&~ub];K=1060;bm=sum(1<<i for i in bi);hr=RH[tuple(ports)]
 edgegroups=collections.defaultdict(list)
 for a,ua,ha in pos:
  for b,ub,hb in neg:
   key=(ha^hb)|(ua&~ub)
   if key.bit_count()<=2:edgegroups[key].append((a,b))
 def classify(groups,flags,topology,places,phase,exception=None):
  f=len(groups);ds=[DS(K) for _ in groups];prior=non|ign
  if topology=='chain':ds[0].eq(1058,1059,phase)
  for j,(g,flag) in enumerate(zip(groups,flags)):
   p=(prior|g) if topology=='chain' else (non|ign|g)
   p&=~sum(1<<w for w,l in places if l!=j and (j==0 or topology=="parallel" or l==2))
   prior|=g;keys={}
   for x,c,_,_,_ in rows:
    z=x&p
    if z in keys:ds[j].eq(c,keys[z],0)
    else:keys[z]=c
   for i,piv in bi.items():
    if not g>>i&1:continue
    for a,b in piv:
     if ds[j].eq(a,1024+i,0)<0 or ds[j].eq(b,1024+i,1)<0:return 'prefix'
    if not flag and ds[j].eq(1024+i,1059,0)<0:return 'pinned'
  if exception is not None:
   j,w,orientation=exception
   for x,c,*_ in rows:
    if ds[j].eq(c,1059,((x>>w)&1)^orientation)<0:return 'raw-fork'
  classes={}
  if f==2 and topology=='chain':
   for x,c,*_ in rows:classes.setdefault(x&(non|ign|groups[1])&~sum(1<<w for w,l in places if l!=1),[]).append(c)
  carry=[(a,b) for cs in classes.values() for a,b in itertools.combinations(cs,2)]
  mask=~sum(1<<w for w,l in places if l!=2)
  rem=[pair for key,ps in edgegroups.items() if key&mask==0 for pair in ps];changes=1
  while changes:
   changes=0;stay=[]
   for a,b in rem:
    vals=[(d.get(a),d.get(b)) for d in ds]
    if f==1:
     z=ds[0].eq(a,b,1)
     if z<0:return 'one-fork'
     continue
    ((u,x),(v,j)),((r,k),(s0,l))=vals;d0,d1=ds
    same0=(u==v and x==j);diff0=(u==v and x!=j)
    same1=(r==s0 and k==l);diff1=(r==s0 and k!=l)
    if diff1:continue
    if topology=='chain':
     # H0 has at most one outgoing path to output bypassing H1; polarity sigma is fixed.
     # If H1 agrees, the positive cell must have high oriented H0 and the negative cell low H0.
     sig,sk=d0.get(1058)
     if same0 or u==sig and x^sk==0 or v==sig and j^sk==1:
      z=d1.eq(a,b,1)
      if z<0:return 'terminal-order'
      changes+=z;continue
     if same1:
      for c,val in ((a,1),(b,0)):
       z=d0.eq(c,1058,val)
       if z<0:return 'bypass-polarity'
       changes+=z
      continue
     # An H0 disagreement alone is not sufficient until its orientation is known.
     if u==sig and x^sk==1 and v==sig and j^sk==0:continue
    else:
     if diff0:continue
     if same0 or same1:
      d=d1 if same0 else d0;z=d.eq(a,b,1)
      if z<0:return 'parallel-state'
      changes+=z;continue
    stay.append((a,b))
   rem=stay
   cs=[]
   for a,b in carry:
    x,y=ds[0].get(a),ds[0].get(b);k,l=ds[1].get(a),ds[1].get(b)
    if x==y:
     z=ds[1].eq(a,b,0)
    elif k[0]==l[0] and k[1]!=l[1]:
     z=ds[0].eq(a,b,1)
    else:
     cs.append((a,b));continue
    if z<0:return 'chain-cut'
    changes+=z
   carry=cs
  return None



 num=17+rrindex;q=ranked[rrindex];P=H/f'low169-region-{num}.jsonl';out=H/f'low169-independent-{num}.jsonl';import time
 counts=collections.Counter()
 with out.open('w') as result:
  with P.open() as records:
   for i in range(3*len(q['patterns'])):
    while True:
     posn=records.tell();line=records.readline()
     if line.endswith('\n'):break
     records.seek(posn);time.sleep(.3)
    z=json.loads(line);assert z[0]==i
    gs,flags=zip(*q['patterns'][i//3]);top='parallel' if i%3==0 else 'chain';phase=int(i%3==2);checks=[]
    def check(places,exception=None):
     code=classify(gs,flags,top,[(B.index(w),l) for w,l in places],phase,exception);assert code,(num,i,places,exception,z);checks.append(code)
    if z[1]=='baseline':check([])
    elif z[1]=='single':
     w,rs=z[2]
     for l in range(3):check([(w,l)])
     if 0 in gs:
      assert len(rs)==5
      for orientation in (0,1):check([], (gs.index(0),B.index(w),orientation))
    elif z[1]=='pair':
     v,secondary=z[3]; singles=z[2]
     for l in range(3):
      if singles[str(v)][l]!='OPEN':check([(v,l)]);continue
      ww,_=secondary[str(l)]
      for u in range(3):
       if singles[str(ww)][u]=='OPEN':check([(v,l),(ww,u)])
       else:check([(ww,u)])
    else:assert z[1]=='OPEN'
    counts[z[1]]+=1;print(json.dumps([i,z[1],checks]),file=result,flush=True)
 print(num,counts)
