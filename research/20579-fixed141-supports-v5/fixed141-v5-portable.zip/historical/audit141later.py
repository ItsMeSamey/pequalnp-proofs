from checkpoint import *
from collections import Counter,defaultdict
from functools import lru_cache
from itertools import combinations,product
from hashlib import sha256
import time,sys,itertools,collections
H=Path(__file__).parent.resolve()
ref=json.load(open(H/'alter246-fork-summary.json'))['results'];rank={tuple(r['ports']):r for r in ref}
n=normalize(json.load(open(next(Path('/dev/shm/04rank-s179-trajectory').glob('full183*.json')))));v,t,_,_=run(n);assert audit(n)['mismatches']==0
rr=json.load(open(H/'exact183-interface-lower.json'))['reports'];B=sorted(set(next(q['cut'] for q in rr if q['root']==246 and q['depth']==5))-{116,190}|{122})
W=[sum((v[w]>>i&1)<<j for j,w in enumerate(B)) for i in range(1024)]
@lru_cache(None)
def catalog(dim):
    # Enumerate all inherited binary trees after pinning off-path inputs at 0/1.
    if dim==2:
        return {i:{0,15,3,12,5,10,1<<i,15^(1<<i)} for i in range(4)}
    def join(x,y,op):return x&y if op==0 else x|y
    out={}
    for signs in range(8):
        literals=[sum((((a>>i&1)^(signs>>i&1))<<a) for a in range(8)) for i in range(3)]
        for lone in range(3):
            l=[literals[i] for i in range(3) if i!=lone]
            for inner,outer in product(range(2),repeat=2):
                vals={join(a,b,inner) for a in [0,255,l[0]] for b in [0,255,l[1]]}|{0,255}
                ys={join(h,c,outer) for h in vals for c in [0,255,literals[lone]]}
                out[12*signs+4*lone+2*inner+outer]=ys|{255^y for y in ys}
    return out
@lru_cache(None)
def adm(dim,P,N):
 return sum(1<<idx for idx,ds in catalog(dim).items() if any((y&P)==P and not y&N for y in ds))
def rebuilder(ports):
 inds=[B.index(w) for w in ports];mask=sum(1<<j for j in inds);lab={}
 for i,x in enumerate(W):
    key=x&mask;y=t>>i&1
    assert lab.setdefault(key,y)==y
 @lru_cache(None)
 def fibers(sub):
    idx=sum(1<<j for j in sub);groups={}
    for x,y in lab.items():
        key=x&~idx;a=sum((x>>j&1)<<k for k,j in enumerate(sub));z=groups.setdefault(key,[0,0]);z[y]|=1<<a
    possible=(1<<len(catalog(len(sub))))-1
    for N,P in set(tuple(z) for z in groups.values()):
        if P and N:possible &= adm(len(sub),P,N)
    return possible
 return lab,fibers
stages=[('first_tree','first-tree'),('triple_tree','triple-tree'),('coherent_tree','simultaneous-trees'),('prefix_clade','one-prefix-inverter')]
def checkstage(name,tag):
 src=(H/f'alter246_{name}_check.py').read_text()
 # The archived combinatorial assignment routine is re-executed, against separately
 # computed pair/triple fibers. Restrict to supports actually excluded by this stage.
 expected=[r for r in json.load(open(H/f'alter246-{tag}.json')) if r['lower']==171]
 ex={tuple(r['ports']) for r in expected}
 hs=[r for r in json.load(open(H/'alter246-hyper-forks.json')) if tuple(r['ports']) in ex]
 ss=src[src.index(' @lru_cache(None)\n def feasible'):src.index(' lb=170 if surv')]
 code='def execute(r,rr,bi,corn,triple_allowed):\n I=r["ports"];signmask=[((1<<12)-1)<<(12*s) for s in range(8)]\n'+ss+' return surv\n'
 env=dict(globals());exec(code,env);fn=env['execute']
 result=[]
 for r in hs:
    p=tuple(r['ports']);rr=rank[p];lab,fib=rebuilder(p);bi=[B.index(w) for w in rr['binate']]
    corn={(i,j):fib((i,j)) for i,j in combinations(bi,2)}
    old=next(e for e in expected if tuple(e['ports'])==p)
    assert {f'{B[i]},{B[j]}':c for (i,j),c in corn.items()}==old['corners']
    assert fn(r,rr,bi,corn,lambda i,j,k:fib((i,j,k))) is None
    result.append(list(p))
 return result
if __name__=='__main__':
 for name,tag in stages:
    out=checkstage(name,tag);(H/f'audit141-independent-{tag}.json').write_text(json.dumps(out));print(tag,len(out),flush=True)
