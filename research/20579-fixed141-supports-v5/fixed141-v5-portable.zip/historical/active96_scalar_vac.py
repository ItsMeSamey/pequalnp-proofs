from pathlib import Path
import json,hashlib,re,collections,itertools
H=Path('/dev/shm/site-team-01-abc-drafts/enc');cert=H/'active96-fork-witnesses.json'
d=json.load(open(next(Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'))))
rows=[int(h,16) for h in re.findall(r'0x[0-9a-f]+',json.load(open('/tmp/pnp-official-20579-public.json'))['gap']['statement'])]
samples=[]
for r,c in itertools.product(range(32),repeat=2):
 x=[int(i in [r,c+32]) for i in range(64)]
 for g in d['gates']:
  args=[x[i] for i in g['inputs']];x.append(int(all(args) if g['op']=='and' else any(args) if g['op']=='or' else not args[0]))
 y=rows[r]>>c&1;assert x[d['output']]==y and x[69]==1-x[68];samples.append((x,y))
assert sum(samples[33*k][0][69]<<k for k in range(6))==53
rr=json.load(open(cert));assert len(set(tuple(q['ports']) for q in rr))==len(rr)==96
sup=json.load(open(H/'marker32-inversion-lower.json'))['supports']
assert {tuple(q['ports']) for q in rr}=={tuple(q['ports']) for q in sup if len(q['ports'])==27 and 69 in q['ports']}
counts=collections.Counter();stats=[]
for rid,q in enumerate(rr):
 B=q['ports'];marker=1<<B.index(69);D={};U=(1<<len(B))-1
 for x,y in samples:
  w=sum(x[b]<<i for i,b in enumerate(B));assert D.setdefault(w,y)==y
 piv=[];M=inv=unk=0;md=None
 for i,b in enumerate(B):
  bit=1<<i;edges=[(w,w+bit) for w in D if w&bit==0 and w+bit in D and D[w]!=D[w+bit]];ds={D[w] for w,_ in edges}
  if len(ds)==2:M|=bit
  elif ds=={1}:inv|=bit
  elif not ds:unk|=bit
  piv.extend((w,v,bit) for w,v in edges)
  if b==69:md=str(sorted(ds));counts[('piv',md)]+=1
 E=U^M;eb=[1<<i for i in range(len(B)) if E>>i&1];assert M==q['binate'] and eb==q['extras']
 # From scratch establish mandatory XOR requirements across every cube, via parity union-find on finest legal projection.
 comp=collections.defaultdict(list)
 for x in (w for w in D if D[w]):
  for y in (w for w in D if not D[w]):
   need=E&(((x^inv)&~(y^inv))|((x^y)&unk))
   if need.bit_count()<=2:comp[need].append((x,y))
 N=1<<len(eb);F=(1<<N)-1;ax={b:F//((1<<(2<<j))-1)*(((1<<(1<<j))-1)<<(1<<j)) for j,b in enumerate(eb)};cover=0
 for on,off in q['clauses']:
  assert not(on&off) and not((on|off)&~E)
  cc=F
  for b,v in ax.items():
   if b&on:cc&=v
   if b&off:cc&=~v
  cover|=cc
  parent={};parity={}
  def find(x):
   if x not in parent:parent[x]=x;parity[x]=0
   if parent[x]!=x:
    old=parent[x];parent[x]=find(old);parity[x]^=parity[old]
   return parent[x]
  def fail(a,b,s):
   aa=find(a);bb=find(b);v=parity[a]^parity[b]^s
   if aa==bb:return v==1
   parent[aa]=bb;parity[aa]=v;return False
  collapse=lambda a:a&~off
  forced=M|on
  ok=any(fail(collapse(x),-b,0) or fail(collapse(y),-b,1) for x,y,b in piv if forced&b)
  if not ok:ok=any(fail(collapse(x),collapse(y),1) for need,es in comp.items() if not need&~on for x,y in es)
  assert ok,(rid,on,off)
  counts['cycles']+=1
 assert cover==F and N==q['total'];counts['assignments']+=N
 if marker in ax:counts['marker_inside']+=(cover&ax[marker]).bit_count();counts['marker_outside']+=(cover&~ax[marker]).bit_count()
 stats.append([rid,md,len(q['clauses']),N])
print(counts,flush=True)
(H/'active96-scalar-vacuity-report.json').write_text(json.dumps(dict(sha256=hashlib.sha256(cert.read_bytes()).hexdigest(),per_support=stats,summary={str(k):v for k,v in counts.items()})))
