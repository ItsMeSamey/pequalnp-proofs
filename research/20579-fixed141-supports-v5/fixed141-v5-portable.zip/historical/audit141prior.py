from audit141later import *
sys.path.insert(0,'/workspace/scratch/site-team-09')
from fork_certificate import orientation_witnesses,derive_edges,partitions
hy={tuple(r['ports']):r for r in json.load(open(H/'alter246-hyper-forks.json'))}
res=Counter()
for ports,r in rank.items():
 if r['lower']<171 and ports not in hy:raise ValueError
 lab,fib=rebuilder(ports);I=[B.index(w) for w in ports];bi=[i for i in I if all(any(not (x>>i&1) and lab.get(x^(1<<i))==1-y and q==y for x,y in lab.items()) for q in (0,1))]
 assert [B[j] for j in bi]==r['binate']
 base=140+len(I);low=2 if r['drops'] else 1
 if r['drops']:
  cc=r['drops'];mask=sum(1<<j for j in I);zz=[W[i]&mask for i in cc]
  assert [t>>i&1 for i in cc]==[1,0,1,0] and all(x&y==x for x,y in zip(zz,zz[1:]))
 if r['lower']>=171:
  if base+low+bool(bi)<=170:
   edges=set()
   for x,y in r['edges']:
    i,j=B.index(x),B.index(y);assert fib((i,j))==0;edges.add((1<<i)|(1<<j))
   assert next(partitions(bi,edges,edges,170-base-low,0),None) is None
  res['fork']+=1
 else:
  hh=hy[ports]
  if hh['lower']<=170 and hh['lower']!=170:continue
  outside=sum(1<<i for i in I if i not in bi)
  witnesses=orientation_witnesses(lab,bi,outside);general,positive=derive_edges(lab,bi,outside,witnesses);positive|=general
  assert general==set(hh['general']) and positive==set(hh['positive'])
  if hh['lower']>170:
   for nn in range(low,170-base):
    nb=170-base-nn;ns=min(nb,nn-1)
    assert next(partitions(bi,positive,general,nb-ns,ns),None) is None
   res['hyper']+=1
  else:res['inherited_hyper_edges']+=1
print(dict(res),flush=True);(H/'audit141-independent-prior.json').write_text(json.dumps(dict(res)))
