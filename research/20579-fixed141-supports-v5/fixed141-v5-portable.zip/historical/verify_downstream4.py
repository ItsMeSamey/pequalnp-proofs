from audit141later import *
H=Path(__file__).parent
def by(name):return {tuple(x['ports']):x for x in json.load(open(H/('alter246-'+name+'.json')))}
simple=by('singlefork-terminal-colors');prior=by('singlefork-output-parity');ordered=by('downstream-ordered-tuples');hyper=by('hyper-forks')
one=[k for k,r in simple.items() if r['excluded'] and not prior[k]['excluded']]
two=[k for k,r in ordered.items() if r['lower']==171]
class Parity:
 def __init__(self):self.rep=list(range(1060));self.bit=[0]*1060
 def base(self,k):
  if k!=self.rep[k]:
   j=self.rep[k];self.rep[k]=self.base(j);self.bit[k]^=self.bit[j]
  return self.rep[k]
 def force(self,a,b,p):
  i=self.base(a);j=self.base(b);z=p^self.bit[a]^self.bit[b]
  if i==j:return not z
  self.rep[j]=i;self.bit[j]=z;return True
 def relation(self,a,b):
  if self.base(a)==self.base(b):return self.bit[a]^self.bit[b]
  return None
out=[]
for ports in one+two:
 lab,fiber=rebuilder(ports);I=[B.index(w) for w in ports];sel=sum(1<<i for i in I);mx=sum(1<<j for j in I)
 cell={w&mx:i for i,w in enumerate(W)}
 dirs={};piv={}
 for j in I:
  ps=[(cell[w],cell[w^(1<<j)]) for w,y in lab.items() if not w>>j&1 and lab.get(w^(1<<j))==1-y]
  dirs[j]={t>>a&1 for a,b in ps}
  if len(dirs[j])==2:piv[j]=ps
 bi=sum(1<<j for j in piv);un=sum(1<<j for j in I if len(dirs[j])==1);neg=sum(1<<j for j in I if dirs[j]=={1});ign=sel^bi^un
 P=[w for w,y in lab.items() if y];N=[w for w,y in lab.items() if not y];edges=[(cell[x],cell[y]) for x in P for y in N if not((x^y)&ign) and not((x^neg)&~(y^neg)&un)]
 drops=rank[ports]['drops'];assert [t>>i&1 for i in drops]==[1,0,1,0] and all(not(W[a]&~W[b]&sel) for a,b in zip(drops,drops[1:]))
 def reject(groups):
  ds=[];mask=sel^bi
  for grp,signed in groups:
   d=Parity();ds.append(d);mask|=grp;rep={}
   for w,k in cell.items():
    assert d.force(k,rep.setdefault(w&mask,k),0)
   for j,ps in piv.items():
    if not(grp>>j&1):continue
    for a,b in ps:
     if not d.force(a,1024+j,0) or not d.force(b,1024+j,1):return True
    if not signed and not d.force(1024+j,1059,0):return True
  todo=edges
  while True:
   remain=[];changed=False
   for a,b in todo:
    rs=[d.relation(a,b) for d in ds]
    if 1 in rs:continue
    if None not in rs:return True
    if rs.count(None)==1:
     if not ds[rs.index(None)].force(a,b,1):return True
     changed=True
    else:remain.append((a,b))
   if not changed:return False
   todo=remain
 if ports in one:
  assert reject([(bi,1)])
  out.append(dict(ports=ports,ordered_cases=1,terminal_pairs=len(edges)));continue
 hr=hyper[ports];opt=set()
 def permitted(mask,sign):return not any(e&mask==e for e in hr['general' if sign else 'positive'])
 if permitted(bi,1):
  opt.add(((bi,1),))
  opt.add(((bi,1),(0,1)));opt.add(((0,1),(bi,1)))
 # Enumerate all ordered splits directly; either designated group can be the signed one.
 m=bi
 while m:
  rest=bi^m
  if rest:
   for a,b in [(0,1),(1,0)]:
    if permitted(m,a) and permitted(rest,b):opt.add(((m,a),(rest,b)))
  m=(m-1)&bi
 assert len(opt)==ordered[ports]['orders_tested']
 assert all(reject(groups) for groups in opt)
 out.append(dict(ports=ports,ordered_cases=len(opt),terminal_pairs=len(edges)))
(H/'downstream4-independent.json').write_text(json.dumps(out));print([(len(x['ports']),x['ordered_cases'],x['terminal_pairs']) for x in out])
