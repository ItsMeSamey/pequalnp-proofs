from pathlib import Path
exec(Path('/tmp/singleton_246alterlb.py').read_text().split('res=[];')[0])
from functools import lru_cache
doc=json.load(open('/tmp/singleton-alter246-depth5-lb.json'));output=[]
for ex in doc['minimizers']:
 S=sum(1<<B.index(w) for w in ex['ports']);values={x&S:(i,(T>>i)&1) for i,x in enumerate(W)}
 bi=[B.index(w) for w in ex['binate']]
 piv={i:[] for i in bi}
 for i in bi:
  for x,(c,l) in values.items():
   if x>>i&1:continue
   t=values.get(x^(1<<i))
   if t and t[1]!=l:piv[i].append((x,l,c,t[0]))
 @lru_cache(None)
 def valid(G):
  # In each outside fiber each pivot sign is input polarity XOR fiber output polarity.
  # Solve row/column XOR equations by component propagation.
  graph={}
  for i in bi:
   if not G>>i&1:continue
   for x,l,c,e in piv[i]:
    b=(x&~G)+len(B);graph.setdefault(i,[]).append((b,l));graph.setdefault(b,[]).append((i,l))
  val={}
  for a in graph:
   if a in val:continue
   val[a]=0;todo=[a]
   while todo:
    j=todo.pop()
    for b,l in graph[j]:
     q=val[j]^l
     if b in val and val[b]!=q:return False
     if b not in val:val[b]=q;todo.append(b)
  return True
 order=sorted(bi,key=lambda i:-sum(not valid((1<<i)|(1<<j)) for j in bi))
 def decide(k):
  visits=0
  def rec(i,groups):
   nonlocal visits
   visits+=1
   if i==len(order):return groups
   bit=1<<order[i]
   for j in range(min(len(groups)+1,k)):
    old=groups[j] if j<len(groups) else 0
    if valid(old|bit):
     ans=rec(i+1,groups[:j]+[old|bit]+groups[j+1:])
     if ans:return ans
  return rec(0,[]),visits
 results=[]
 for k in range(1,5):
  ans,visits=decide(k);results.append([k,ans,visits])
  if ans:break
 print('ports',len(ex['ports']),'results',results,flush=True);output.append(dict(ports=ex['ports'],binate=ex['binate'],decisions=results))
Path(__file__).with_name('altered141-color-cert.json').write_text(json.dumps(output))
