import json,itertools,collections,pathlib
p=pathlib.Path('/dev/shm/site-team-01-abc-drafts/enc')
exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
old=json.load(open('/tmp/singleton-low20-phases.json'))
ledger=json.load(open(p/'alter246-bypass-consolidated.json'))
results=[]
for idx,rr in enumerate(z for z in ledger if len(z['ports'])==25 and z['lower']==169):
 ports=rr['ports'];q=next(z for z in old if z['ports']==ports)
 ids=[B.index(w) for w in ports];s=sum(1<<i for i in ids)
 care={a&s:y for a,y in L.items()};zero=set(q['first_gate_zero']);one=set(q['first_gate_one'])
 assert not any(not o&~z for o in one for z in zero)
 piv={};bi=[]
 for i in ids:
  t=1<<i;lo=[a for a,y in care.items() if not a&t and care.get(a|t,y)!=y];piv[i]=lo
  if len({care[a] for a in lo})==2:bi.append(i)
 common=s^sum(1<<b for b in bi)
 forbidden={};pair={}
 for i in bi:
  t=1<<i;v0=piv[i];v1=[a|t for a in v0]
  bad=next(((o,z) for o in one|set(v1) for z in zero|set(v0) if not o&~z),None)
  if bad:forbidden[B[i]]=bad
 for i,j in itertools.combinations(bi,2):
  if B[i] in forbidden or B[j] in forbidden:continue
  bad=next(((a|1<<i,b) for a in piv[i] for b in piv[j] if not (a|1<<i)&~b),None) or next(((b|1<<j,a) for a in piv[i] for b in piv[j] if not (b|1<<j)&~a),None)
  if bad:pair[f'{B[i]},{B[j]}']=bad
 bins={j:i for i,j in enumerate(bi)};N=1<<len(bi);full=(1<<N)-1;col=[(full//((1<<(1<<i))+1))<<(1<<i) for i in range(len(bi))]
 lo=[(z,0) for z in zero]+[(z,1<<i) for i in bi for z in piv[i]]
 hi=[(o,0) for o in one]+[(z|(1<<i),1<<i) for i in bi for z in piv[i]]
 hits={}
 for o,oi in hi:
  for z,zi in lo:
   d=o&~z;k=oi|zi
   if not d&(common|k):hits.setdefault(k,set()).add(d)
 def cmb(m):
  a=0
  for j in bi:
   if m>>j&1:a|=col[bins[j]]
  return a
 current=full;weak=full
 for k,D in hits.items():
  when=full
  for j in bi:
   if k>>j&1:when&=col[bins[j]]
  ds=[]
  for d in sorted(D,key=int.bit_count):
   if any(x&d==x for x in ds):continue
   ds.append(d);current&=~(when&~cmb(d))
   if not d:weak&=~when
  hits[k]=ds
 trial=(current&~1)&-(current&~1);trial=trial.bit_length()-1
 results.append(dict(ports=ports,binates=[B[i] for i in bi],unrestricted=(weak&~1).bit_count(),local=(current&~1).bit_count(),clauses=[[k,d] for k,ds in hits.items() for d in ds],example=None if trial<0 else [B[j] for k,j in enumerate(bi) if trial>>k&1]))
 print(idx,len(bi),(weak&~1).bit_count(),(current&~1).bit_count(),flush=True)
(p/'notation-slack25-local-inversion.json').write_text(json.dumps(results))
