from checkpoint import *
from collections import defaultdict
from itertools import product
H=Path('.');D=normalize(json.load(open(next(Path('/dev/shm/04rank-s179-trajectory').glob('full183*')))));v,T,_,_=run(D)
B=json.load(open('/tmp/singleton-alter246-depth5-lb.json'))['bank'];rows=[sum((v[w]>>j&1)<<i for i,w in enumerate(B)) for j in range(1024)];report=[]
for idx in range(6):
 cert=json.load(open(f'/tmp/singleton-low20-symbolic-fork-{idx}.json'));P=sum(1<<B.index(w) for w in cert['ports']);rs={x&P:T>>j&1 for j,x in enumerate(rows)}
 assert all(rs[x&P]==(T>>j&1) for j,x in enumerate(rows))
 E=sum(1<<B.index(w) for w in cert['extra']);M=P^E;flip=unknown=0;pivs=[]
 for w in cert['ports']:
  bit=1<<B.index(w);piv=[(x,x^bit) for x in rs if not x&bit and rs.get(x^bit,rs[x])!=rs[x]];dirs={rs[x] for x,_ in piv};assert (len(dirs)==2)==bool(M&bit)
  if not dirs:unknown|=bit
  if dirs=={1}:flip|=bit
  pivs.extend((x,y,bit) for x,y in piv)
 pos=[x for x,y in rs.items() if y];neg=[x for x,y in rs.items() if not y];by=defaultdict(list)
 for x in pos:
  for y in neg:
   req=(((x^flip)&~(y^flip))|((x^y)&unknown))&E
   by[req].append((x,y))
 N=cert['total'];cover=0;axis={1<<B.index(w):((1<<N)-1)//((1<<(2*(1<<j)))-1)*(((1<<(1<<j))-1)<<(1<<j)) for j,w in enumerate(cert['extra'])}
 for on,off in cert['clauses']:
  assert not on&off and (on|off)&~E==0
  cube=(1<<N)-1
  for k,c in axis.items():
   if on&k:cube&=c
   if off&k:cube&=~c
  cover|=cube
  # Group cells by finest projection common to all assignments to this cube.
  proj=P^off;forced=M|on;adj=defaultdict(list)
  def edge(a,b,parity):
   adj[a].append((b,parity));adj[b].append((a,parity))
  for x,y,bit in pivs:
   if not forced&bit:continue
   edge(x&proj,-bit,0);edge(y&proj,-bit,1)
  def contradiction():
   colors={}
   for a in adj:
    if a in colors:continue
    colors[a]=0;todo=[a]
    while todo:
     j=todo.pop()
     for k,sg in adj[j]:
      val=sg^colors[j]
      if k in colors:
       if colors[k]!=val:return True
      else:colors[k]=val;todo.append(k)
   return False
  if not contradiction():
   for req,edges in by.items():
    if req&~on:continue
    for x,y in edges:edge(x&proj,y&proj,1)
   assert contradiction(),(idx,on,off)
 assert cover.bit_count()==N and not cert['passed'] and cert['remaining']==0
 report.append([idx,len(rs),len(cert['clauses']),N]);print(report[-1],flush=True)
Path('six-symbolic-negative-cycle-audit.json').write_text(json.dumps(report))
