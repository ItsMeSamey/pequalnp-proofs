from pathlib import Path
import sys,json,itertools,collections
sys.path.insert(0,'/workspace/scratch/site-team-09');from fork_certificate import partitions
exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
Q=json.load(open(H/'alter246-one-prefix-inverter.json'));RH={tuple(z['ports']):z for z in json.load(open(H/'alter246-hyper-forks.json'))};RR={tuple(z['ports']):z for z in json.load(open(H/'alter246-fork-summary.json'))['results']};notes=[]
class DS:
 def __init__(self,n):self.p=list(range(n));self.v=[0]*n;self.sz=[1]*n
 def get(self,a):
  if self.p[a]!=a:
   b,v=self.get(self.p[a]);self.v[a]^=v;self.p[a]=b
  return self.p[a],self.v[a]
 def eq(self,a,b,p):
  a,x=self.get(a);b,y=self.get(b);p^=x^y
  if a==b:return -1 if p else 0
  if self.sz[a]<self.sz[b]:a,b=b,a
  self.p[b]=a;self.v[b]=p;self.sz[a]+=self.sz[b];return 1
ranked=json.load(open(H/'low26-promoted-singleton-rank.json'))
original={tuple(r['ports']):r for r in json.load(open(H/'low26-promoted-singleton-functional.json'))}
for pp in ranked:
 if pp['ports']!=json.load(open('/tmp/singleton-low20-allocations.json'))[int(sys.argv[1])]['ports']:continue
 rr={'ports':pp['ports']}
 ports=rr['ports'];s=sum(1<<B.index(w) for w in ports);I=[i for i in range(len(B)) if s>>i&1];A={x&s:(c,T>>c&1) for c,x in enumerate(W)};bi={};non=ign=flip=0
 for i in I:
  h=[(c,A[x^(1<<i)][0]) for x,(c,l) in A.items() if not x>>i&1 and x^(1<<i) in A and A[x^(1<<i)][1]!=l];ds={T>>a&1 for a,b in h}
  if len(ds)==2:bi[i]=h
  elif ds:non|=1<<i;flip|=next(iter(ds))<<i
  else:ign|=1<<i
 rows=[(x,c,l,(x^flip)&non,x&ign) for x,(c,l) in A.items()];pos=[(c,u,h) for x,c,l,u,h in rows if l];neg=[(c,u,h) for x,c,l,u,h in rows if not l]
 edge=[(a,b) for a,ua,ha in pos for b,ub,hb in neg if ha==hb and not ua&~ub];K=1060;bm=sum(1<<i for i in bi);hr=RH[tuple(ports)]
 def classify(groups,flags,topology,locations):
  allowed=[non|ign]*3
  for i,location in locations:
   for z in range(3):
    if z!=location:allowed[z]&=~(1<<i)
  edge=[(a,b) for a,ua,ha in pos for b,ub,hb in neg if not ((ha^hb)&allowed[2]) and not (ua&~ub&allowed[2])]
  f=len(groups);ds=[DS(K) for _ in groups];prior=allowed[0]
  for j,(g,flag) in enumerate(zip(groups,flags)):
   p=(prior|g) if topology=='chain' else (allowed[j]|g)
   prior|=g|allowed[1];keys={}
   for x,c,_,_,_ in rows:
    z=x&p
    if z in keys:ds[j].eq(c,keys[z],0)
    else:keys[z]=c
   for i,piv in bi.items():
    if not g>>i&1:continue
    for a,b in piv:
     if ds[j].eq(a,1024+i,0)<0 or ds[j].eq(b,1024+i,1)<0:return 'prefix'
    if not flag and ds[j].eq(1024+i,1059,0)<0:return 'pinned'
  classes={}
  if f==2 and topology=='chain':
   for x,c,*_ in rows:classes.setdefault(x&(allowed[1]|groups[1]),[]).append(c)
  orient=[]
  if f==2 and topology=='chain':
   mask=allowed[1]|groups[1]
   for i in bi:
    if not groups[1]>>i&1:continue
    keyed={}
    for x,c,*_ in rows:
     keyed.setdefault(x&mask&~(1<<i),[[],[]])[x>>i&1].append(c)
    for lo,hi in keyed.values():
     orient.extend((a,b,1024+i) for a in lo for b in hi)
  fixednon={}
  for x,c,*_ in rows:fixednon.setdefault(x&allowed[0],[]).append((x,c))
  prefix_order=list({(a,b) for grp in fixednon.values() for x,a in grp for y,b in grp if (x&groups[0])!=(y&groups[0]) and not ((x&~y)&groups[0])})
  carry=[(a,b) for cs in classes.values() for a,b in itertools.combinations(cs,2)]
  rem=edge;changes=1
  while changes:
   changes=0;stay=[]
   for a,b in rem:
    vals=[(d.get(a),d.get(b)) for d in ds]
    if f==1:
     z=ds[0].eq(a,b,1)
     if z<0:return 'one-fork'
     continue
    ((u,x),(v,j)),((r,k),(s0,l))=vals;d0,d1=ds
    same0=(u==v and x==j);diff0=(u==v and x!=j)
    same1=(r==s0 and k==l);diff1=(r==s0 and k!=l)
    if diff1:continue
    if topology=='chain':
     # H0 has at most one outgoing path to output bypassing H1; polarity sigma is fixed.
     # If H1 agrees, the positive cell must have high oriented H0 and the negative cell low H0.
     sig,sk=d0.get(1058)
     if same0 or u==sig and x^sk==0 or v==sig and j^sk==1:
      z=d1.eq(a,b,1)
      if z<0:return 'terminal-order'
      changes+=z;continue
     if same1:
      for c,val in ((a,1),(b,0)):
       z=d0.eq(c,1058,val)
       if z<0:return 'bypass-polarity'
       changes+=z
      continue
     # An H0 disagreement alone is not sufficient until its orientation is known.
     if u==sig and x^sk==1 and v==sig and j^sk==0:continue
    else:
     if diff0:continue
     if same0 or same1:
      d=d1 if same0 else d0;z=d.eq(a,b,1)
      if z<0:return 'parallel-state'
      changes+=z;continue
    stay.append((a,b))
   rem=stay
   cs=[]
   for a,b in carry:
    x,y=ds[0].get(a),ds[0].get(b);k,l=ds[1].get(a),ds[1].get(b)
    if x==y:
     z=ds[1].eq(a,b,0)
    elif k[0]==l[0] and k[1]!=l[1]:
     z=ds[0].eq(a,b,1)
    else:
     cs.append((a,b));continue
    if z<0:return 'chain-cut'
    changes+=z
   carry=cs
   rest=[]
   for a,b,sign in orient:
    d0,d1=ds;u,ua=d0.get(a);v0,vb=d0.get(b);x,xa=d1.get(a);y,yb=d1.get(b);t,sg=d1.get(sign)
    if u==v0 and ua!=vb or x==y and xa==yb:continue
    lo_high=x==t and xa!=sg;hi_low=y==t and yb==sg
    if lo_high and hi_low:
     z=d0.eq(a,b,1)
     if z<0:return 'conditional-unate'
     changes+=z;continue
    if u==v0 and ua==vb:
     if x==y and xa!=yb:
      z=d1.eq(a,sign,0)
      if z<0:return 'conditional-unate'
      changes+=z;continue
     if lo_high or hi_low:
      z=d1.eq(a,b,0)
      if z<0:return 'conditional-unate'
      changes+=z;continue
    rest.append((a,b,sign))
   orient=rest
   keep=[]
   for a,b in (prefix_order if topology=='chain' and not flags[0] else []):
    d0=ds[0];u,ua=d0.get(a);v0,vb=d0.get(b);t,sg=d0.get(1059)
    if u==v0:
     if ua==vb:continue
     z=d0.eq(a,1059,0)
     if z<0:return 'first-ordered'
     changes+=z;continue
    if u==t and ua!=sg or v0==t and vb==sg:
     z=d0.eq(a,b,0)
     if z<0:return 'first-ordered'
     changes+=z;continue
    keep.append((a,b))
   prefix_order=keep
  return None

 initial=original[tuple(ports)]["pinned_relaxation"]
 records=[]
 for gg,ff,topology in initial:
  if topology not in ('parallel','chain'):continue
  todo=[()]
  visited=[];opens=[];candidates=[i for i in I if i not in bi]
  while todo:
   loc=todo.pop();why=classify(gg,ff,topology,loc)
   if why:visited.append([loc,why]);continue
   rem=[i for i in candidates if i not in {x for x,_ in loc}]
   if not rem:opens.append(loc);break
   results=[]
   for i in rem:
    ss=[(loc+((i,j),),classify(gg,ff,topology,loc+((i,j),))) for j in range(3)]
    results.append(ss)
    if all(w for _,w in ss):break
   ss=min(results,key=lambda ss:sum(w is None for _,w in ss))
   visited +=[(ll,w) for ll,w in ss if w];todo.extend(ll for ll,w in ss if not w)
   if len(visited)>24:break
  print('chain',gg,'excluded branches',len(visited),'open',len(opens),'unprocessed',len(todo),flush=True)
  records.append(dict(topology=topology,groups=gg,flags=ff,resolved=not todo and not opens,visited=visited,survivors=opens,pending=todo,ports=ports))
 json.dump(records,open('/tmp/singleton-promoted-unique-'+sys.argv[1]+'.json','x'))
