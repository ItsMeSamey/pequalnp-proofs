from pathlib import Path
import sys,json,collections
sys.path.insert(0,'/workspace/scratch/site-team-09')
from fork_certificate import orientation_witnesses,derive_edges,partitions
exec(open('/tmp/singleton_246alterlb.py').read().split('res=[];')[0])
old=json.load(open(H/'alter246-fork-summary.json'))['results'];out=[];hist=collections.Counter()
for rr in sorted(old,key=lambda r:r['lower']):
 if rr['lower']>=171:continue
 I=[B.index(w) for w in rr['ports']];s=sum(1<<i for i in I);A={x&s:l for x,l in L.items()};bi=[B.index(w) for w in rr['binate']];u=s^sum(1<<j for j in bi)
 ev=orientation_witnesses(A,bi,u);signed,positive=derive_edges(A,bi,u,ev);positive=positive|signed
 base=141+len(I)-1;low=2 if rr['drops'] else 1
 for g in range(rr['lower']-base,170-base+1):
  ok=False
  for nn in range(low,g):
   f=g-nn;sg=min(f,nn-1)
   if next(partitions(bi,positive,signed,f-sg,sg),None) is not None:ok=True;break
  if ok:break
 else:g=171-base
 lb=base+g;hist[lb]+=1;out.append(dict(ports=rr['ports'],lower=lb,general=sorted(signed),positive=sorted(positive)))
 if len(out)%15==0 or len(out)==1:print(len(out),hist,flush=True);(H/'alter246-hyper-forks.json').write_text(json.dumps(out))
(H/'alter246-hyper-forks.json').write_text(json.dumps(out));print('done',hist)
