from pathlib import Path
import json,itertools,hashlib,re,sys,collections
sys.path.insert(0,'/workspace/scratch/site-team-09')
from fork_certificate import derive_edges,orientation_witnesses
h=Path('/dev/shm/site-team-01-abc-drafts/enc');cert=json.load(open(h/'uncap13-pin.json'))[int(sys.argv[1])];ports=cert['ports']
src=next(Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'));assert hashlib.sha256(src.read_bytes()).hexdigest()==src.stem.split('-')[1]
g=json.loads(src.read_bytes())['gates'];goal=[int(z,16) for z in re.findall('0x[0-9a-f]+',json.load(open('/tmp/pnp-official-20579-public.json'))['gap']['statement'])]
Z=[];Y=[];rep={}
for cell in range(1024):
 r,c=divmod(cell,32);v=[j in (r,c+32) for j in range(64)]
 for q in g:
  bits=[v[i] for i in q['inputs']];v.append(all(bits) if q['op']=='and' else any(bits) if q['op']=='or' else not bits[0])
 x=sum(int(v[w])<<i for i,w in enumerate(ports));y=(goal[r]>>c)&1;Z.append(x);Y.append(y);rep[x]=cell
A={x:Y[c] for x,c in rep.items()};assert all(A[x]==y for x,y in zip(Z,Y))
dire={};bi=[];non=0;ign=0;flip=0
for j in range(len(ports)):
 piv=[(c,rep[x^(1<<j)]) for x,c in rep.items() if not x>>j&1 and Y[c]!=A.get(x^(1<<j),Y[c])]
 ds={Y[a] for a,b in piv}
 if len(ds)==2:bi.append(j);dire[j]=piv
 elif ds:non|=1<<j;flip|=next(iter(ds))<<j
 else:ign|=1<<j
bm=sum(1<<j for j in bi);F=(1<<len(ports))-1
sig,pos=derive_edges(A,bi,F^bm,orientation_witnesses(A,bi,F^bm));pos|=sig
pair={}
for a,b in itertools.combinations(bi,2):
 m=1<<a|1<<b;fib={}
 for x,y in A.items():fib.setdefault(x&~m,[]).append(((x>>a&1)+2*(x>>b&1),y))
 pair[a,b]={c for c in range(4) if all(any(all((t>>k&1)==y for k,y in rs) for t in [0,15,3,12,5,10,1<<c,15^(1<<c)]) for rs in fib.values())}
from functools import lru_cache
@lru_cache(None)
def signable(mask,signed):
 block=[j for j in bi if mask>>j&1]
 if not block:return True
 if any(e&mask==e for e in (sig if signed else pos)):return False
 # Normalize the arbitrary common phase only for the pair corner test.
 def visit(i,ph):
  if i==len(block):return True
  j=block[i]
  for v in (range(2) if signed and i else [0]):
   if all(((z+2*v in pair[t,j]) or (3-z-2*v in pair[t,j])) for t,z in ph):
    if visit(i+1,ph+[(j,v)]):return True
  return False
 return visit(0,[])
scenarios=set()
if signable(bm,True):
 scenarios.add(((bm,1),))
 for e in (((bm,1),(0,1)),((0,1),(bm,1))):scenarios.add(e)
for m in range(1,(1<<len(bi))-1):
 a=sum(1<<j for i,j in enumerate(bi) if m>>i&1);b=bm^a
 if signable(a,False) and signable(b,True):
  scenarios.add(((a,0),(b,1)));scenarios.add(((b,1),(a,0)))
print('independent scenarios',len(scenarios),flush=True)
# Signed equivalences maintained as explicit components. Joining visits smaller component.
class Components:
 def __init__(self):self.cid={};self.phase={};self.members={}
 def add(self,x):
  if x not in self.cid:self.cid[x]=x;self.phase[x]=0;self.members[x]=[x]
 def relate(self,a,b,p):
  self.add(a);self.add(b);aa=self.cid[a];bb=self.cid[b];delta=self.phase[a]^self.phase[b]^p
  if aa==bb:return -1 if delta else 0
  if len(self.members[aa])<len(self.members[bb]):aa,bb=bb,aa
  for x in self.members[bb]:self.cid[x]=aa;self.phase[x]^=delta
  self.members[aa].extend(self.members.pop(bb));return 1
 def known(self,a,b):
  if self.cid.get(a) is None or self.cid.get(b) is None or self.cid[a]!=self.cid[b]:return None
  return self.phase[a]^self.phase[b]
pairs=[(a,b) for a in rep.values() if Y[a] for b in rep.values() if not Y[b] and not ((Z[a]^Z[b])&ign or ((Z[a]^flip)&~(Z[b]^flip)&non))]
def check(sc,parallel,phase):
 comps=Components();keys={};prior=non|ign
 for j,(m,flag) in enumerate(sc):
  mask=m|(non|ign if parallel else prior);prior|=m
  for c in rep.values():keys[j,c]=(j,Z[c]&mask);comps.add(keys[j,c])
  for b in bi:
   if not m>>b&1:continue
   sg=('sign',j,b)
   if not flag and comps.relate(sg,'zero',0)<0:return 'sign'
   for c,d in dire[b]:
    if comps.relate(keys[j,c],sg,0)<0 or comps.relate(keys[j,d],sg,1)<0:return 'prefix'
 feature_pairs=[]
 if len(sc)==2 and not parallel:
  classes={}
  for c in rep.values():classes.setdefault(Z[c]&(sc[1][0]|non|ign),[]).append(c)
  feature_pairs=[(c,d) for cells in classes.values() for c,d in itertools.combinations(cells,2)]
 live=pairs
 while True:
  kept=[];progress=0
  for a,b in live:
   e=comps.known(keys[0,a],keys[0,b])
   if len(sc)==1:
    changes=comps.relate(keys[0,a],keys[0,b],1)
    if changes<0:return 'single'
    progress+=changes;continue
   f=comps.known(keys[1,a],keys[1,b])
   if f==1:continue
   if parallel:
    if e==1:continue
    if e==0 or f==0:
     j=int(e==0);changes=comps.relate(keys[j,a],keys[j,b],1)
     if changes<0:return 'tuple'
     progress+=changes;continue
   else:
    if e==0 or comps.known(keys[0,a],'zero')==phase or comps.known(keys[0,b],'zero')==1-phase:
     changes=comps.relate(keys[1,a],keys[1,b],1)
     if changes<0:return 'order'
     progress+=changes;continue
    if f==0:
     for c,x in [(a,1-phase),(b,phase)]:
      changes=comps.relate(keys[0,c],'zero',x)
      if changes<0:return 'bypass'
      progress+=changes
     continue
   kept.append((a,b))
  keep=[]
  for c,d in feature_pairs:
   e=comps.known(keys[0,c],keys[0,d]);f=comps.known(keys[1,c],keys[1,d])
   if e==1 or f==0:continue
   if e==0 or f==1:
    j=int(e==0);z=comps.relate(keys[j,c],keys[j,d],int(f==1 and e!=0))
    if z<0:return 'cut-functional'
    progress+=z;continue
   keep.append((c,d))
  feature_pairs=keep
  if not progress:return 'OPEN'
  live=kept
hist=collections.Counter();outputs=[]
eligible={(tuple(map(tuple,sc)),t,phase) for sc,t,phase,r in json.load(open(h/('uncap13-replay-'+sys.argv[1]+'.json')))['results'] if r=='OPEN'}
for sc in sorted(scenarios):
 for topo,phase in ([('parallel',0)] if len(sc)==1 else [('parallel',0),('chain',0),('chain',1)]):
  if (sc,topo,phase) not in eligible:continue
  reason=check(sc,topo=='parallel',phase);hist[reason]+=1
  outputs.append([sc,topo,phase,reason])
print(hist,'cell pairs',len(pairs))
(h/('uncap13-replay-'+sys.argv[1]+'.json')).with_name('uncap13-indep-'+sys.argv[1]+'.json').write_text(json.dumps(dict(source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),ports=ports,scenarios=len(scenarios),terminal_pairs=len(pairs),results=outputs)))
