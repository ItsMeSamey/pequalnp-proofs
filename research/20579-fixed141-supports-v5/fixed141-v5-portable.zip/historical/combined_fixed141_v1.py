from pathlib import Path
import json,hashlib
H=Path(__file__).parent
def read(f):return json.loads((H/f).read_text())
def dig(f):return hashlib.sha256((H/f).read_bytes()).hexdigest()
base='fixed141-original546-reconstructed.json'
rows=read(base); assert len(rows)==583 and len({tuple(x['ports']) for x in rows})==583
ids={tuple(x['ports']):x['index'] for side in ['singleton','coercions'] for x in read('uncapped-'+side+'-ports.json')}
region=[33,39,41,43,44,48]
def evidence(i):
 if i in region:
  p=f'region-full-{i}.json';q=f'region-full-independent-{i}.json'
  expected={33:608,39:62,41:288,43:8,44:560,48:264}[i]
  assert len(read(p))==len(read(q))==expected and all(x['excluded'] for x in read(p)) and all(read(q))
 elif i==32:p='region-exclusive-32.json';q='region-independent-32.json';assert len(read(p))==len(read(q))==24 and all(x['excluded'] for x in read(p))
 elif i==2:p='/tmp/singleton-parallel-unique-2.json';q='notation-owner-ID2-independent.json';assert len(read(p))==len(read(q)['orders'])==4
 elif i in [0,5,7,8,9,17,18]:
  p='/tmp/singleton-ID7-exclusive-readonce.json' if i==7 else f'/tmp/singleton-parallel-unique-{i}.json'
  q=f'ID{i}-independent-parity-clauses.json'
  if i==0 and not (H/q).exists():q=None
  if q:assert all(x[-1] for x in read(q))
 else:return None,None
 return p,q
records=[];hashes={};new=[];verified=[]
for idx,x in enumerate(rows):
 ps=x['ports'];i=ids.get(tuple(ps));old=x['lower']>=171;p,q=(None,None) if old else evidence(i)
 if p:new.append(i)
 if q:verified.append(i)
 for f in [p,q]:
  if f:hashes[f]=dig(f)
 records.append(dict(baseline_index=idx,ports=ps,uncapped_id=i,baseline_lower=x['lower'],baseline_source=x['source'],primary_excluded=bool(old or p),independent_status='inherited-baseline' if old else 'receipt' if q else 'pending' if p else 'open',additional_primary=p,additional_independent=q))
assert len(new)==len(set(new))==15
out=dict(scope='Fixed141 support ledger, with the original frozen physical boundary and cap 170. Identity is the ordered port tuple.',original_live_file_sha256="381d68b0e3a2198af6ebfbc2400050f55ad1285e4302981af631a803832598e8",baseline_file=base,baseline_sha256=dig(base),baseline_excluded=sum(r['baseline_lower']>=171 for r in records),additional_primary_ids=sorted(new),additional_independent_ids=sorted(verified),total_primary=546+len(new),total_independent_including_inherited_baseline=546+len(verified),receipt_sha256=hashes,rows=records)
target=H/f'fixed141-combined-v1-{out["total_independent_including_inherited_baseline"]}.json'
s=json.dumps(out,separators=(',',':'));assert not target.exists() or target.read_text()==s
target.write_text(s)
print(target)
