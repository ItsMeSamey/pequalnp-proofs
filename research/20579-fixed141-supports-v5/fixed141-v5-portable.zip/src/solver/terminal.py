from settings import INDEX, HERE
from states import *
term_bits={}
for cc,dd in termbins[0]:term_bits[cc]=term_bits.get(cc,0)|(1<<dd)
@lru_cache(None)
def earliest(group,minus):
 g=raw(group)
 high={};low={}
 for i in bi:
  if not g>>i&1:continue
  for x in piv[i]:
   aa=x;bb=x|1<<i
   if minus&bits[i]:aa,bb=bb,aa
   low.setdefault(x&common,[]).append((aa^raw(minus))&g);high.setdefault(x&common,[]).append((bb^raw(minus))&g)
 tags={}
 for x,c in reps.items():
  t=x&common;z=(x^raw(minus))&g
  u=any(not k&~z for k in high.get(t,()));d=any(not z&~k for k in low.get(t,()))
  assert not(u and d)
  tags[c]=int(u) if u or d else (x&(g|common))+2
 return tags
@lru_cache(maxsize=128)
def partial(group,origin,minus,sg):
 g=raw(group);tags=earliest(origin,minus);d=DS(1100)
 seen={};allk={}
 for x,c in reps.items():
  key=(x&(g|common),tags[c])
  if key in seen:d.eq(c,seen[key],0)
  else:seen[key]=c
 for i in bi:
  if g>>i&1:
   for x in piv[i]:
    if d.eq(reps[x],1030+i,0)<0 or d.eq(reps[x|1<<i],1030+i,1)<0:return None
   if not sg and d.eq(1030+i,1099,0)<0:return None
 if not sg:
  low={};high={}
  for i in bi:
   if not g>>i&1:continue
   for x in piv[i]:
    for y,b,tab in ((x,0,low),(x|1<<i,1,high)):
     tab.setdefault((y&common,tags[reps[y]]),[]).append(y&g)
  for x,c in reps.items():
   key=(x&common,tags[c]);z=x&g
   u=any(not k&~z for k in high.get(key,()));l=any(not z&~k for k in low.get(key,()))
   if u and l:return None
   if u or l:
    if d.eq(c,1099,int(u))<0:return None
 return d
def trial(case):
 from copy import deepcopy
 a,minus,b,c,sg,top=case;groups=list(map(raw,(a,b,c)));origin=earliest(a,minus);d0=DS(1100);seen={}
 for cc,tag in origin.items():
  if tag<2:d0.eq(cc,1099,tag)
  elif tag in seen:d0.eq(cc,seen[tag],0)
  else:seen[tag]=cc
 d1=partial(b,a,minus,sg==1)
 if d1 is None:return 'second-prefix'
 if top=='split':
  d2=partial(c,a,minus,sg==2)
  if d2 is None:return 'third-prefix'
  pass
 else:
  d2=DS(1100);seen={}
  for x,cc in reps.items():
   key=(x&(common|groups[2]),d0.get(cc) if top=='triangle' else None,d1.get(cc))
   if key in seen:d2.eq(cc,seen[key],0)
   else:seen[key]=cc
  for i in bi:
   if not groups[2]>>i&1:continue
   for x in piv[i]:
    if d2.eq(reps[x],1030+i,0)<0 or d2.eq(reps[x|1<<i],1030+i,1)<0:return 'third-prefix'
   if sg!=2 and d2.eq(1030+i,1099,0)<0:return 'third-positive'
 ds=[d0,d1,d2]
 # Compress per-component phase classes into positive and negative membership bitsets.
 same=[]
 for d in ds:
  buckets={};keys={}
  for cc in reps.values():
   k=d.get(cc);keys[cc]=k;buckets[k]=buckets.get(k,0)|(1<<cc)
  same.append((keys,buckets))
 if any(term_bits[cc]&(same[0][1][same[0][0][cc]] if top=='chain' else -1)&same[1][1][same[1][0][cc]]&same[2][1][same[2][0][cc]] for cc in term_bits):return 'terminal'
 return 'open'

