from settings import INDEX, HERE
import pathlib,itertools,collections,json,sys
H=pathlib.Path('/dev/shm/site-team-01-abc-drafts/enc')
from pathlib import Path
import hashlib,re
H=Path('/dev/shm/site-team-01-abc-drafts/enc')
source=next(Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'))
assert source.stem.endswith(hashlib.sha256(source.read_bytes()).hexdigest())
net=json.loads(source.read_bytes());stat=json.load(open('/tmp/pnp-official-20579-public.json'))['gap']['statement']
T=sum(int(x,16)<<(32*r) for r,x in enumerate(re.findall('0x[0-9a-f]+',stat)))
full_care=(1<<1024)-1
values=[sum(1<<k for k in range(1024) if j in (k//32,32+k%32)) for j in range(64)]
for gate in net['gates']:
 src=gate['inputs'];p,q=values[src[0]],values[src[-1]]
 values.append(p&q if gate['op']=='and' else p|q if gate['op']=='or' else full_care^p)
assert values[net['output']]==T
B=sorted(set(w for r in json.load(open(H/'notation-slack25-local-inversion.json')) for w in r['ports']))
W=[sum(((values[w]>>k)&1)<<j for j,w in enumerate(B)) for k in range(1024)]
L={x:T>>k&1 for k,x in enumerate(W)}
assert all(L[x]==(T>>k&1) for k,x in enumerate(W))
rec=json.load(open(H/f'notation-slack25-local-independent-{INDEX}.json'));ports=rec['ports'];ids=[B.index(z) for z in ports];s=sum(1<<i for i in ids);care={x&s:y for x,y in L.items()}
piv={i:[x for x,y in care.items() if not x>>i&1 and care.get(x|1<<i,y)!=y] for i in ids}
bi=[i for i in ids if len({care[x] for x in piv[i]})==2];bits={i:1<<k for k,i in enumerate(bi)};common=s^sum(1<<i for i in bi);N=1<<len(bi);full=(1<<N)-1;U=N-1
cols={i:((full//((1<<(1<<k))+1))<<(1<<k)) for k,i in enumerate(bi)}
