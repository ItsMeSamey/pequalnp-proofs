from settings import INDEX, HERE
from states import *
from groups import V
uni=N-1;sys.path.insert(0,'/workspace/scratch/site-team-09');from fork_certificate import derive_edges,orientation_witnesses
gen,pos=derive_edges(care,bi,common,orientation_witnesses(care,bi,common));cv=lambda m:sum(bits[i] for i in bi if m>>i&1)
def allowed_memberships(edges):
 allowed=full
 for edge in edges:
  forbidden=full
  for i in bi:
   if edge>>i&1:forbidden &= cols[i]
  allowed &= ~forbidden
 data=allowed.to_bytes((N+7)//8,'little')
 return bytearray((data[k//8]>>(k%8))&1 for k in range(N))
ok=[allowed_memberships(gen|pos),allowed_memberships(gen)]
obs={}
for i in bi:
 for x in piv[i]:
  obs.setdefault(x,set()).add((bits[i],0));obs.setdefault(x|1<<i,set()).add((bits[i],1))
universe=U
@lru_cache(None)
def graph(omit):
 tag={};edges=set();mask=raw(omit)
 for x,entries in obs.items():tag.setdefault(x&~mask,set()).update(entries)
 for cluster in tag.values():
  for (i,a),(j,b) in itertools.combinations(cluster,2):
   i0,j0=sorted((i,j));edges.add((i0,j0,a^b))
 return tuple(edges)
@lru_cache(None)
def possible(group,omit,signed):
 ds={};ph={}
 def root(i):
  if i not in ds:ds[i]=i;ph[i]=0
  x=ds[i]
  if x!=i:
   f,h=root(x);ds[i]=f;ph[i]^=h
  return ds[i],ph[i]
 for i,j,t in graph(omit):
  if not (i&group and j&group):continue
  if not signed:
   if t:return False
   continue
  x,pg=root(i);y,qg=root(j)
  if x==y:
   if pg^qg!=t:return False
  else:ds[x]=y;ph[x]=t^pg^qg
 return True

incidence={}
for x,entries in obs.items():
 for j,pol in entries:incidence.setdefault((j,pol),[]).append(x)
@lru_cache(None)
def signed_unate(group,ancestor,signed):
 if not group:return True
 members=[bits[i] for i in bi if bits[i]&group]
 ex=common|raw(ancestor)
 pairs=graph(universe^(group|ancestor))
 bound={}; color={};comps=[]
 for j in members:bound[j]=[]
 for i,j,par in pairs:
  if not i&group or not j&group:continue
  bound[i].append((j,par));bound[j].append((i,par))
 for j in members:
  if j in color:continue
  todo=[j];color[j]=0;comp=[]
  while todo:
   k=todo.pop();comp.append(k)
   for t,v in bound[k]:
    if t not in color:color[t]=color[k]^v;todo.append(t)
    elif color[t]!=color[k]^v:return False
  comps.append(comp)
 options=range(1<<(len(comps)-1)) if signed else (0,)
 for opt in options:
  minus=0
  for k,comp in enumerate(comps):
   for j in comp:
    if color[j]^((opt>>k)&1):minus|=j
  if not signed and minus:continue
  flip=raw(minus);mask=raw(group);lo={};hi={}
  for j in members:
   b=int(bool(j&minus))
   for x in incidence[j,b]:lo.setdefault(x&ex,[]).append((x^flip)&mask)
   for x in incidence[j,1-b]:hi.setdefault(x&ex,[]).append((x^flip)&mask)
  if not any(not a&~b for t,zs in hi.items() for a in zs for b in lo.get(t,())):return True
 return False
def schedules():
 for d,states in V.items():
  for a in states:
   b=rem=U^a
   while True:
    c=rem^b
    for sg in ([0] if d else [1,2]):
     if not ok[sg==1][b] or not ok[sg==2][c]:continue
     if not possible(b,c,sg==1) or not signed_unate(b,a,sg==1):continue
     for t,eanc,dont in [('split',a,b),('chain',a|b,0),('triangle',a|b,0)]:
      if not possible(c,dont,sg==2) or not signed_unate(c,eanc,sg==2):continue
      yield (a,d,b,c,sg,t)
    if not b:break
    b=(b-1)&rem
