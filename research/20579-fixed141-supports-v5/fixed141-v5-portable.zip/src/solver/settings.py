import os
from pathlib import Path
INDEX=int(os.environ["SLACK25_SUPPORT"])
HERE=Path(__file__).resolve().parent
