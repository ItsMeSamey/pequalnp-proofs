from settings import INDEX, HERE
from common import *
from functools import lru_cache
raw=lambda g:sum(1<<i for i in bi if g&bits[i])
class DS:
 def __init__(self,n):self.p=list(range(n));self.v=[0]*n;self.sz=[1]*n
 def get(self,a):
  if self.p[a]!=a:
   b,v=self.get(self.p[a]);self.v[a]^=v;self.p[a]=b
  return self.p[a],self.v[a]
 def eq(self,a,b,p):
  a,x=self.get(a);b,y=self.get(b);p^=x^y
  if a==b:return -1 if p else 0
  if self.sz[a]<self.sz[b]:a,b=b,a
  self.p[b]=a;self.v[b]=p;self.sz[a]+=self.sz[b];return 1

reps={x&s:i for i,x in enumerate(W)};pospol=negpol=0
for i in ids:
 if i in bi:continue
 dirs={care[x] for x in piv[i]}
 if dirs:
  pospol|=1<<i
  if next(iter(dirs)):negpol|=1<<i
termbins=collections.defaultdict(list)
for x,c in reps.items():
 if not care[x]:continue
 for y,d in reps.items():
  if care[y]:continue
  obs=((x^y)&(common^pospol))|((x^negpol)&~(y^negpol)&pospol)
  if not obs or (not __import__("os").environ.get("SLACK25_UNIQUE") and obs.bit_count()<=2):termbins[obs].append((c,d))
def trial(group,flips,parents,place=None):
 groups=list(map(raw,group));ds=[DS(1100) for _ in groups];anc=[];clauses=[]
 for j,(g,d) in enumerate(zip(groups,ds)):
  pp=parents[j];ar=set(pp)
  for t in pp:ar.update(anc[t])
  anc.append(ar); retain=common|g
  for k in ar:retain|=groups[k]
  if place and place[1]!=j and place[1] not in ar:retain&=~(1<<place[0])
  seen={}
  for x,c in reps.items():
   key=x&retain
   if key in seen:d.eq(c,seen[key],0)
   else:seen[key]=c
  for i in bi:
   if not g>>i&1:continue
   for x in piv[i]:
    if d.eq(reps[x],1030+i,0)<0 or d.eq(reps[x|1<<i],1030+i,1)<0:return 'prefix'
   if flips[j] is not None and d.eq(1030+i,1099,int(bool(flips[j]&bits[i])))<0:return 'orientation'
  if pp:
   mask=common|g
   if place and place[1]!=j:mask&=~(1<<place[0])
   by={}
   for x,c in reps.items():by.setdefault(x&mask,[]).append(c)
   clause=tuple((t,1) for t in pp)+((j,0),);clauses.extend((a,b,clause) for cs in by.values() for a,b in itertools.combinations(cs,2))
 skip=(1<<place[0]) if place and place[1]!=3 else 0
 clauses.extend((a,b,((0,1),(1,1),(2,1))) for k,ls in termbins.items() if not k&~skip for a,b in ls)
 while True:
  keep=[];progress=0
  for a,b,lits in clauses:
   free=[];ok=False
   for j,w in lits:
    x,ph=ds[j].get(a);y,pv=ds[j].get(b)
    if x!=y:free.append((j,w))
    elif ph^pv==w:ok=True;break
   if ok:continue
   if not free:return 'terminal/cut'
   if len(free)==1:
    j,w=free[0];z=ds[j].eq(a,b,w)
    if z<0:return 'parity'
    progress+=z
   else:keep.append((a,b,lits))
  if not progress:return 'open'
  clauses=keep
def screen(group,flips,parents):
 z=trial(group,flips,parents)
 if z!='open' or not all(group):return z
 for i in sorted((i for i in ids if i not in bi),key=lambda i:-len(termbins[1<<i])):
  if all(trial(group,flips,parents,(i,l))!='open' for l in range(4)):return 'region-'+str(B[i])
 return 'open'
