from settings import INDEX, HERE
import json,itertools,pathlib,hashlib,re,sys
h=pathlib.Path('/dev/shm/site-team-01-abc-drafts/enc')
rs=json.load(open(h/'notation-slack25-local-inversion.json'));ports=rs[int(sys.argv[1])]['ports']
src=next(pathlib.Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'));assert src.stem.endswith(hashlib.sha256(src.read_bytes()).hexdigest())
gs=json.load(open(src))['gates']; yy=[int(v,16) for v in re.findall('0x[0-9a-f]+',json.load(open('/tmp/pnp-official-20579-public.json'))['gap']['statement'])]
table={}
for c in range(1024):
 r,col=divmod(c,32);v=[i==r or i==32+col for i in range(64)]
 for g in gs:
  vals=[v[i] for i in g['inputs']];v.append(not vals[0] if g['op']=='not' else all(vals) if g['op']=='and' else any(vals))
 x=sum(int(v[i])<<j for j,i in enumerate(ports));y=yy[r]>>col&1;assert table.get(x,y)==y;table[x]=y
words=sorted(table,key=int.bit_count);lo={};hi={}
for x in words:hi[x]=max([0]+[hi[z]+(table[z]>table[x]) for z in hi if not z&~x])
for x in reversed(words):lo[x]=max([0]+[lo[z]+(table[x]>table[z]) for z in lo if not x&~z])
bi=[];pivot={}
for i in range(len(ports)):
 d=1<<i;l=[z for z in table if not z&d and table.get(z^d)==1-table[z]]
 if len({table[z] for z in l})==2:bi.append(i);pivot[i]=l

import collections
from functools import lru_cache
cells=list(table);rep={x:i for i,x in enumerate(cells)};Y=list(table.values());common=((1<<len(ports))-1)^sum(1<<i for i in bi)
@lru_cache(None)
def raw(g):return sum(1<<i for k,i in enumerate(bi) if g>>k&1)
pospol=negpol=0
for i in range(len(ports)):
 if i in bi:continue
 signs={table[x] for x in words if not x>>i&1 and table.get(x^(1<<i))==1-table[x]}
 if signs:
  pospol|=1<<i
  if next(iter(signs)):negpol|=1<<i
terminal={i:sum(1<<k for k,x in enumerate(cells) if not Y[k] and not ((x^z)&(common^pospol) or (z^negpol)&~(x^negpol)&pospol)) for i,z in enumerate(cells) if Y[i]}
class Conflict(Exception):pass
def gate(group,parents,positive,hull,neg=0):
 g=raw(group);q=common
 keys=[];codes={};fib=[]
 for j,x in enumerate(cells):
  context=(x&q,*(c[j] for c in parents));fib.append(context)
  k=(x&g,context);keys.append(codes.setdefault(k,len(codes)))
 graph=collections.defaultdict(list)
 def edge(a,b,e):graph[a].append((b,e));graph[b].append((a,e))
 pins={}
 for i in bi:
  if not g>>i&1:continue
  if positive:edge(('s',i),'up',int(bool(raw(neg)>>i&1)))
  for x in pivot[i]:
   a,b=rep[x],rep[x|1<<i]
   edge(keys[a],('s',i),0);edge(keys[b],('s',i),1)
   if positive and hull:
    p=int(bool(raw(neg)>>i&1));pins.setdefault(fib[a],([],[]))[p].append((x^raw(neg))&g)
    pins.setdefault(fib[b],([],[]))[1-p].append(((x|1<<i)^raw(neg))&g)
 if positive and hull:
  for j,x in enumerate(cells):
   d=(x^raw(neg))&g;low,hi=pins.get(fib[j],([],[]))
   if any(not d&~y for y in low):edge(keys[j],'up',0)
   if any(not y&~d for y in hi):edge(keys[j],'up',1)
 phase={};components={}
 for j in range(len(codes)):
  if j in phase:continue
  phase[j]=0;todo=[j]
  while todo:
   n=todo.pop();components[n]=j
   for nxt,b in graph[n]:
    v=phase[n]^b
    if nxt not in phase:phase[nxt]=v;todo.append(nxt)
    elif phase[nxt]!=v:raise Conflict
 return tuple(2*components[k]+phase[k] for k in keys)
@lru_cache(maxsize=200)
def first(a,d):return gate(a,[],True,True,d)
@lru_cache(maxsize=256)
def second(a,d,b,sign):
 try:return gate(b,[first(a,d)],not sign,True)
 except Conflict:return None
def classify(a,d,b,c,sg,top):
 u=first(a,d);v=second(a,d,b,sg==1)
 if v is None:return 'second'
 if top=='split':
  w=second(a,d,c,sg==2)
  if w is None:return 'third'
 else:
  try:w=gate(c,[v] if top=='chain' else [u,v],sg!=2,False)
  except Conflict:return 'third'
 keys=list(zip(u,v,w) if top=='chain' else zip(v,w));neg={}
 for i,k in enumerate(keys):
  if not Y[i]:neg[k]=neg.get(k,0)|(1<<i)
 if any(terminal[i]&neg.get(keys[i],0) for i in terminal):return 'terminal'
 return 'OPEN'

def cut(u,v,w):
 keys=list(zip(u,v,w));neg={}
 for i,k in enumerate(keys):
  if not Y[i]:neg[k]=neg.get(k,0)|(1<<i)
 return any(terminal[i]&neg.get(keys[i],0) for i in terminal)
