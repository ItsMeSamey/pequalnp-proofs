import json,itertools,pathlib,hashlib,re,sys
h=pathlib.Path('/dev/shm/site-team-01-abc-drafts/enc')
rs=json.load(open(h/'notation-slack25-local-inversion.json'));ports=rs[int(sys.argv[1])]['ports']
src=next(pathlib.Path('/dev/shm/04rank-s179-trajectory').glob('full183-*.json'));assert src.stem.endswith(hashlib.sha256(src.read_bytes()).hexdigest())
gs=json.load(open(src))['gates']; yy=[int(v,16) for v in re.findall('0x[0-9a-f]+',json.load(open('/tmp/pnp-official-20579-public.json'))['gap']['statement'])]
table={}
for c in range(1024):
 r,col=divmod(c,32);v=[i==r or i==32+col for i in range(64)]
 for g in gs:
  vals=[v[i] for i in g['inputs']];v.append(not vals[0] if g['op']=='not' else all(vals) if g['op']=='and' else any(vals))
 x=sum(int(v[i])<<j for j,i in enumerate(ports));y=yy[r]>>col&1;assert table.get(x,y)==y;table[x]=y
words=sorted(table,key=int.bit_count);lo={};hi={}
for x in words:hi[x]=max([0]+[hi[z]+(table[z]>table[x]) for z in hi if not z&~x])
for x in reversed(words):lo[x]=max([0]+[lo[z]+(table[x]>table[z]) for z in lo if not x&~z])
bi=[];pivot={}
for i in range(len(ports)):
 d=1<<i;l=[z for z in table if not z&d and table.get(z^d)==1-table[z]]
 if len({table[z] for z in l})==2:bi.append(i);pivot[i]=l
F=(1<<len(ports))-1;common=F^sum(1<<i for i in bi)
low=[(z,0) for z in words if lo[z]>=2]+[(l,1<<i) for i in bi for l in pivot[i]]
high=[(z,0) for z in words if hi[z]>=2]+[(l|1<<i,1<<i) for i in bi for l in pivot[i]]
cl={(0,F^common)}
for x,ax in high:
 for y,ay in low:
  pos=x&~y;neg=ax|ay
  if pos&(neg|common):continue
  cl.add((neg,pos))
solutions=[]
def search(t,f):
 while True:
  old=t|f;res={}
  for neg,pos in cl:
   if neg&f or pos&t:continue
   unknown=(neg|pos)&~(t|f)
   if not unknown:return
   if not unknown&(unknown-1):
    if unknown&neg:f|=unknown
    else:t|=unknown
   else:
    for i in bi:
     if unknown>>i&1:res[i]=res.get(i,0)+1
  if t&f:return
  if old==t|f:break
 if (t|f|common)==F:solutions.append([ports[i] for i in bi if t>>i&1]);return
 bit=max((i for i in bi if not (t|f)>>i&1),key=lambda i:res.get(i,0));search(t|1<<bit,f);search(t,f|1<<bit)
search(0,0);expected=rs[int(sys.argv[1])]['local'];assert len(solutions)==expected
print(sys.argv[1],len(cl),len(solutions),solutions[:2])
(h/('notation-slack25-local-independent-'+sys.argv[1]+'.json')).write_text(json.dumps(dict(ports=ports,clauses=len(cl),feasible_source_sets=solutions)))
