"""Stream three-fork schedules through two support checkers, saving counts and digests only."""
import argparse
import collections
import hashlib
import itertools
import json
import os
from pathlib import Path
import sys
import time
import resource
import signal

sys.dont_write_bytecode = True
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('support',type=int)
parser.add_argument('--stage', choices=['all','unique','other'],default='all')
parser.add_argument('--existing',type=Path,help='reuse a completed small schedule receipt (at most 2 MiB)')
parser.add_argument('--slice-cpu',type=float,help='checkpoint after the specified process CPU time')
parser.add_argument('--max-cases',type=int)
args=parser.parse_args()
if (args.slice_cpu or args.max_cases) and (args.stage!='unique' or not args.existing):
    parser.error('resumable slices require --stage unique --existing FILE')
if args.stage=='unique':os.environ['SLACK25_UNIQUE']='1'
if args.slice_cpu is not None:
    if not 0<args.slice_cpu<=2.8:parser.error('slice target must be between zero and 2.8 CPU seconds')
    resource.setrlimit(resource.RLIMIT_CPU,(3,3))
    resource.setrlimit(resource.RLIMIT_AS,(64*1024**2,64*1024**2))
    signal.alarm(6)
os.environ['SLACK25_SUPPORT']=str(args.support)
directory=Path(__file__).resolve().parent
sys.path.insert(0,str(directory/'solver'))
import common, states, terminal, replay
if args.stage!="unique" or not args.existing:import groups

hist=collections.Counter()
totals=collections.Counter()
rolling=bytes(32)
committed=0
receipt_count=0
source=hashlib.sha256(replay.src.read_bytes()).hexdigest()
phase_digest=hashlib.sha256(json.dumps(common.rec['feasible_source_sets'],separators=(',',':')).encode()).hexdigest()
target=directory/f'support-{args.support}-{args.stage}.json'
last=0.
if args.existing and args.existing.stat().st_size>2*1024**2:parser.error('existing receipt exceeds 2 MiB')
source_rows=hashlib.sha256(args.existing.read_bytes()).hexdigest() if args.existing else None
if target.exists() and args.stage=='unique' and args.existing:
    prior=json.loads(target.read_bytes())
    if prior.get('rows_sha256')!=source_rows:raise ValueError('previous receipt belongs to another schedule')
    if prior.get('done'):
        print(target,'already complete');sys.exit(0)
    hist.update(prior['histogram']);totals.update(prior['counts'])
    committed=sum(totals.values());rolling=bytes.fromhex(prior['cases_sha256'])
def checkpoint(done=False,force=False):
    global last
    now=time.monotonic()
    if not done and not force and now-last<60:return
    last=now
    data=dict(support=args.support,ports=common.ports,source_sha256=source,phase_sets_sha256=phase_digest,
              done=done,counts=totals,histogram=hist,cases_sha256=rolling.hex(),rows_sha256=source_rows)
    payload=json.dumps(data,sort_keys=True,separators=(',',':'))
    assert len(payload.encode())<=2048
    temp=target.with_suffix('.partial')
    temp.write_text(payload)
    temp.replace(target)
def record(family,case,result1,result2):
    global rolling,receipt_count
    receipt_count+=1
    rolling=hashlib.sha256(rolling+(json.dumps([family,case,result1,result2],separators=(',',':'))+'\n').encode()).digest()
    totals[family]+=1
    hist[f'{family}:primary:{result1}']+=1
    hist[f'{family}:replay:{result2}']+=1
    if (args.slice_cpu and time.process_time()>=args.slice_cpu) or (args.max_cases and receipt_count>=args.max_cases):
        checkpoint(force=True);print(target,'checkpoint',dict(totals),flush=True);sys.exit(0)
    checkpoint()
if args.stage in ('all','other'):
    for case in groups.parallel_cases():
        a,d,b,e,c,f=case
        first=states.screen((a,b,c),(d,e,f),((),(),()))
        second='terminal' if replay.cut(replay.first(a,d),replay.first(b,e),replay.first(c,f)) else 'open'
        record('parallel',case,first,second)
    for a,d,b,e,c in groups.two_cases():
        u,v=replay.first(a,d),replay.first(b,e)
        for anc in ((0,),(1,),(0,1)):
            first=states.screen((a,b,c),(d,e,0 if d or e else None),((),(),anc))
            try:
                w=replay.gate(c,[[u,v][i] for i in anc],bool(d or e),True)
                second='terminal' if replay.cut(u,v,w) else 'open'
            except replay.Conflict:second='conflict'
            record('two-minimal',(a,d,b,e,c,anc),first,second)
if args.stage in ('all','unique'):
    if args.existing:
        if args.existing.stat().st_size>2*1024**2:parser.error('regenerate larger schedules by omitting --existing')
        cases=itertools.islice(json.loads(args.existing.read_bytes())['rows'],committed,None)
    else:
        from schedules import schedules
        cases=schedules()
    for case in cases:
        record(case[-1],case,terminal.trial(case),replay.classify(*case).lower())
checkpoint(True)
print(target,dict(totals),{k:v for k,v in hist.items() if k.endswith(':open')})
