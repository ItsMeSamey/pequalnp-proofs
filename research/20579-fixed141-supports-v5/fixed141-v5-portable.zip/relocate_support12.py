"""Collect immutable source inputs or replay support 12 using only the extracted bundle."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('bundle',type=Path,help='directory containing raw/, src/, history/ and the two portable JSON files')
parser.add_argument('--collect',action='store_true',help='collect from the original workspace, with no numerical replay')
parser.add_argument('--verify',action='store_true',help='regenerate phases, schedules and mathematical verdicts')
args=parser.parse_args()
home=Path(__file__).resolve().parent
root=args.bundle.resolve()
if args.collect:
    root.mkdir(parents=True,exist_ok=True)
    mf=home/'support12-portable-manifest.json'
    for name,entry in read(mf).items():
        src=Path(entry['workspace_source']);dest=root/name
        if digest(src)!=entry['sha256']:raise ValueError(f'upstream checksum changed: {name}')
        dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():shutil.copyfile(src,dest)
        if digest(dest)!=entry['sha256']:raise ValueError(f'conflicting destination: {name}')
    for src in (mf,Path(__file__).resolve()):
        dest=root/src.name
        if not dest.exists():shutil.copyfile(src,dest)
        if digest(src)!=digest(dest):raise ValueError(f'conflicting destination: {dest}')
manifest=read(root/'support12-portable-manifest.json')
for name,entry in manifest.items():
    if digest(root/name)!=entry['sha256']:raise ValueError(f'bundle SHA mismatch: {name}')
if not args.verify:
    print(f'Pinned {len(manifest)} original files and fixtures. No numerical replay requested.')
    sys.exit(0)
config=read(root/'support12-portable-inputs.json')
history=root/'history'
expected=read(history/'support12-final.json')
assert config['selector_rows'][12]['ports']==expected['ports']
with tempfile.TemporaryDirectory(prefix='support12-replay-') as temp:
    w=Path(temp)
    reloc={ '/dev/shm/site-team-01-abc-drafts/enc':str(w),
            '/dev/shm/04rank-s179-trajectory':str(root/'raw'),
            '/tmp/pnp-official-20579-public.json':str(root/'raw'/'pnp-official-20579-public.json'),
            '/workspace/scratch/site-team-09':str(w) }
    for f in (root/'src').rglob('*.py'):
        dest=w/f.relative_to(root/'src');dest.parent.mkdir(parents=True,exist_ok=True)
        text=f.read_text()
        for a,b in reloc.items():text=text.replace(repr(a),repr(b))
        if f.name in ('notation-slack25.py','notation-slack25-wide.py'):
            original="records=[s for s in json.load(open(h/'alter246-bypass-consolidated.json')) if s['lower']==169 and len(s['ports'])==25]"
            assert text.count(original)==1
            text=text.replace(original,"records=json.load(open(h/'notation-slack25-local-inversion.json'))")
        dest.write_text(text)
    (w/'notation-slack25-local-inversion.json').write_text(json.dumps(config['selector_rows']))
    (w/'fixture.json').write_text(json.dumps(config))
    env=dict(os.environ,SLACK25_SUPPORT='12',PYTHONDONTWRITEBYTECODE='1',
             PYTHONPATH=os.pathsep.join([str(w/'solver'),str(w)]))
    def run(*argv):
        subprocess.run([sys.executable,'-B',*argv],cwd=w,env=env,check=True)
    run('notation-slack25-independent.py','12')
    formed=read(w/'notation-slack25-local-independent-12.json')
    assert formed==read(history/'notation-slack25-local-independent-12.json')
    for script,name in [('notation-slack25.py','2signed'),('notation-slack25-wide.py','wide')]:
        run(script,'12')
        target=f'notation-slack25-{name}-12.json'
        new=read(w/target);old=read(history/target)
        assert {k:v for k,v in new.items() if k!='source'}=={k:v for k,v in old.items() if k!='source'}
        assert not new['open_orders'] and not new['one_signed_group']
    run('-c',"""import json,hashlib
from collections import Counter
from common import B,W,T,values,net,ports,source
from schedules import schedules
q=json.load(open('fixture.json'));bank=q['frozen_bank'];g=net['gates']
mark=next(i for i,p in enumerate(g,64) if p['op']=='not' and p['inputs'][0]>=64);assert mark==69
def closure(seeds):
 nodes=set();todo=list(seeds)
 while todo:
  u=todo.pop()
  if u<64 or u in nodes:continue
  nodes.add(u);todo.extend(g[u-64]['inputs'])
 return nodes
assert net['output']==246
fixed=closure([mark]);cut={246}
for _ in range(5):cut={s for j in cut for s in (g[j-64]['inputs'] if j>=179 and j not in fixed else [j])}
assert sorted((cut-{116,190})|{122})==bank and len(closure(bank+[mark]))==141
assert set(ports)<=set(bank) and mark not in ports and len(ports)==25
chain=q['ascending_two_drop_cells'];m=sum(1<<B.index(v) for v in ports)
assert [T>>i&1 for i in chain]==[1,0,1,0]
assert all(not ((W[a]&m)&~(W[b]&m)) for a,b in zip(chain,chain[1:]))
rows=list(schedules())
assert hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest()==q['schedule_rows_sha256']
assert Counter(r[-1] for r in rows)=={k:v for k,v in q['schedule_counts'].items() if k!='unoriented'}
open('cases.json','w').write(json.dumps({'counts':q['schedule_counts'],'rows':rows}))
""")
    assert digest(w/'cases.json')==config['schedule_sha256']
    run('run.py','12','--stage','other')
    other=read(w/'support-12-other.json')
    assert other['done'] and other['counts']=={'two-minimal':6}
    assert other['histogram']=={'two-minimal:primary:prefix':6,'two-minimal:replay:conflict':6}
    run('run.py','12','--stage','unique','--existing',str(w/'cases.json'))
    final=read(w/'support-12-unique.json')
    assert final==read(history/'support-12-unique.json')
    assert final['cases_sha256']==expected['case_digest'] and expected['lower']==171
    print('Reproduced the bound of 171 for support 12 of the fixed 141-gate interface.')
