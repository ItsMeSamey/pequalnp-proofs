"""Join existing signed-off support receipts and record the precise fixed-prefix model."""
from pathlib import Path
import collections
import hashlib
import json
import subprocess

H=Path('/dev/shm/site-team-01-abc-drafts/enc')
OUT=Path(__file__).parent
ARCHIVE='/workspace/scratch/pnp-site01-closed-2012.tar.gz'
hashes={}
def read(path):
    p=Path(path)
    if not p.is_absolute():p=H/p
    data=p.read_bytes() if p.exists() else subprocess.check_output(['tar','-xOzf',ARCHIVE,Path(path).name])
    hashes[Path(path).name]=hashlib.sha256(data).hexdigest()
    return json.loads(data)
meta=read('exact183-interface-lower.json')
source=read(meta['source'])
assert hashes[Path(meta['source']).name]==meta['source_sha256']
assert meta['marker']==69 and source['gates'][69-64]=={'op':'not','inputs':[68]}
cut=next(x['cut'] for x in meta['reports'] if x['root']==246 and x['depth']==5)
strict_bank=sorted(set(cut)-{116,190}|{122})
inventory=read('alter246-32-marker-support.json')
assert [69]+strict_bank==inventory['bank'] and inventory['full_closure']==141
original=read('fixed141-combined-v4-569.json');base_rows={tuple(r['ports']):r['verified_lower'] for r in original['rows']}
assert hashes['fixed141-combined-v4-569.json']=='cc9d5dda37344b98ae41975bdc8b0eee680827a7f391ae157a1d090938683384'
active=read('marker32-inversion-lower.json');assert active['fixed']==141 and active['bank']==inventory['bank']
passive={tuple(r['ports']) for r in active['supports'] if 69 not in r['ports']}
assert set(base_rows)==passive
all_active={tuple(r['ports']):r for r in active['supports'] if 69 in r['ports']}
assert len(all_active)==inventory['with_marker'] and len(passive)+len(all_active)==inventory['separating']
small=read('notation-active32-summary.json');repeat=read('notation-active32-group-replay.json')
assert small['fixed']==141 and small['marker']==69 and small['source_sha256']==meta['source_sha256']
low26={tuple(r['ports']) for r in small['supports'] if r['lower']>=171}
assert low26=={tuple(r['ports']) for r in repeat if r['lower']>=171 and not r['pinned_relaxation']}
single=read('active96-fork-witnesses.json');independent=read('active96-independent-cycle-audit.json');scalar=read('active96-scalar-vacuity-report.json')
assert scalar['sha256']==hashes['active96-fork-witnesses.json']
low27=set()
for i,r in enumerate(single):
    trace=independent[i];record=scalar['per_support'][i]
    assert trace[0]==record[0]==i and trace[-1]==record[-1]==r['total'] and record[1]=='[]'
    assert not r['unresolved'] and r['remaining']==0
    low27.add(tuple(r['ports']))
assert low26=={p for p in all_active if len(p)==26}
assert low27=={p for p in all_active if len(p)==27}
easy={p for p,r in all_active.items() if r['binate_lb']>=171}
assert low26|low27|easy==set(all_active)
combined=collections.Counter(base_rows.values())
combined[171]+=len(all_active)
receipt=dict(scope='L-meta-20579 shard 53, fixed altered root-246 depth-5 interface; all 1024 one-hot care cells.',source=meta['source'],source_sha256=meta['source_sha256'],physical_price='141 retained gates plus every binary AND/OR and unary NOT gate in the new decoder. The frozen closure includes the first marker NOT. No refund for unused prefix gates.',marker={'wire':69,'gate':'NOT(68)','first_not_shard':53,'decoder_read':'optional; reading the already-paid marker adds no physical gate'},strict_bank=strict_bank,marker_read_bank=inventory['bank'],strict={'separating_supports':len(passive),'certified_lower_histogram':dict(collections.Counter(base_rows.values()))},marker_read={'separating_supports':len(all_active),'certified_lower_at_least':171,'active26':len(low26),'active27':len(low27),'remaining_closed_by_binate_bound':len(set(all_active)-low26-low27)},optional_marker={'separating_supports':inventory['separating'],'certified_lower_histogram_capped_at_171':dict(combined),'certified_minimum_lower_bound':min(combined)},refund_model={'observed_upstream_range':inventory['upstream_range'],'same_141_price_required_for_this_result':True},excluded_extensions=['different cut or prefix','other existing internal taps','refunding unused prefix gates','unrestricted 64-primary circuits'],receipt_sha256=hashes)
name='fixed141-interface-audit-v1.json';p=OUT/name
s=json.dumps(receipt,separators=(',',':'));assert len(s.encode())<16384
if p.exists():assert p.read_text()==s
else:p.write_text(s)
print(p,dict(combined),hashlib.sha256(s.encode()).hexdigest())
