"""Commit a compact immutable delta after the owner confirms the pinned final replay."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).parent.resolve()
ENC=Path('/dev/shm/site-team-01-abc-drafts/enc')
PARENT='fixed141-combined-v4-569.json'
PARENT_HASH='cc9d5dda37344b98ae41975bdc8b0eee680827a7f391ae157a1d090938683384'
SCHEDULE_HASH='4aad32e9ce88d6879f8a4e85732830eaf491accdb7b3639b12060f2d3715e433'
SOURCE_HASH='a3aa72338067eed69023dfc26900f82752ea4cd22fc22b74368be8d9f870be18'
hashes={}
def read(p):
    blob=p.read_bytes();hashes[p.name]=sha256(blob).hexdigest();return json.loads(blob)
def merge(final_hash,other,other_hash):
    parent=read(ENC/PARENT)
    assert hashes[PARENT]==PARENT_HASH and parent['total_independent_including_inherited_baseline']==569
    final=HERE/'support-12-unique.json';rec=read(final)
    assert rec['done'] and rec['support']==12 and hashes[final.name]==final_hash
    signoff=read(other);assert other!=final and hashes[other.name]==other_hash
    assert signoff['source_sha256']==SOURCE_HASH and signoff['unique_rows_sha256']==SCHEDULE_HASH
    assert signoff['support']==12 and signoff['ports']==rec['ports'] and signoff['fixed_gates']==141 and signoff['lower']==171
    assert signoff['case_digest']==rec['cases_sha256'] and signoff['unique_cases']==rec['counts']
    assert signoff['open_unique_across_checkers']==signoff['parallel_partitions']==0
    assert signoff['primary_two_minimal']==signoff['independent_two_minimal']=={'prefix':6}

    ports=rec['ports'];rows=[r for r in parent['rows'] if r['ports']==ports]
    assert len(rows)==1
    old=rows[0];assert old['low20_index']==12 and old['verified_lower']==170 and 69 not in ports and len(ports)==25
    assert rec['source_sha256']==SOURCE_HASH and rec['rows_sha256']==SCHEDULE_HASH
    schedule=ENC/'slack25-general-12-unique-candidates.json';cases=read(schedule)['rows']
    assert hashes[schedule.name]==SCHEDULE_HASH and len(cases)==4642 and len({tuple(e) for e in cases})==4642
    assert Counter(r[-1] for r in cases)==rec['counts']
    hist=rec['histogram']
    for family,n in rec['counts'].items():
        for checker in ('primary','replay'):
            assert sum(v for k,v in hist.items() if k.startswith(f'{family}:{checker}:'))==n
    assert not any(k.lower().endswith(':open') and v for k,v in hist.items())
    pins=read(HERE/'support12-pins.json');assert pins['schedule']==SCHEDULE_HASH and pins['cases']==4642
    for name,expected in pins.items():
        if name not in ('schedule','cases'):assert sha256((HERE/name).read_bytes()).hexdigest()==expected,name
    phase=read(ENC/'notation-slack25-local-independent-12.json')
    assert phase['ports']==ports and sha256(json.dumps(phase['feasible_source_sets'],separators=(',',':')).encode()).hexdigest()==rec['phase_sets_sha256']
    groups=read(ENC/'slack25-general-12-minimal.json');two=read(ENC/'slack25-general-12-two.json')
    assert groups['ports']==ports and not groups['parallel'] and 3*len(groups['two'])==sum(two['hist'].values())==6 and not two['open']
    for family in ('2signed','wide'):
        lower=read(ENC/f'notation-slack25-{family}-12.json')
        assert lower['source_sha256']==SOURCE_HASH and lower['ports']==ports and not lower['one_signed_group'] and not lower['open_orders']
    interface=read(HERE/'fixed141-interface-audit-v1.json')
    assert interface['source_sha256']==SOURCE_HASH and interface['marker']['wire']==69
    disclosure=read(HERE/'support12-pilot-lock.json');assert disclosure['completed_rows']==960
    bounds=Counter(r['verified_lower'] for r in parent['rows']);bounds[170]-=1;bounds[171]+=1
    assert bounds=={170:13,171:570}
    result=dict(schema='fixed141-versioned-delta',version=5,parent=PARENT,parent_sha256=PARENT_HASH,updated_row={'baseline_index':old['baseline_index'],'original14_index':12,'ports':ports,'old_lower':170,'verified_lower':171},fixed_interface=interface['scope'],fixed_price=interface['physical_price'],source_sha256=SOURCE_HASH,marker=interface['marker'],strict_counts={'lower170':13,'lower_at_least171':570,'total':583},optional_marker_counts={'lower170':13,'lower_at_least171':1153,'total':1166},pilot_disclosure='Initial 960 schedules used the alternate lock documented in support12-pilot-lock.json. Historical lock overlap is unverified.',receipts=hashes)
    blob=json.dumps(result,separators=(',',':')).encode();assert len(blob)<=16384
    path=HERE/'fixed141-v5-support12-570.json'
    if path.exists():assert path.read_bytes()==blob
    else:
        with path.open('xb') as f:f.write(blob)
    return path,sha256(blob).hexdigest()
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('verified_final_sha256');p.add_argument('independent_two_receipt',type=Path);p.add_argument('verified_two_sha256');a=p.parse_args()
    print(*merge(a.verified_final_sha256,a.independent_two_receipt,a.verified_two_sha256))
