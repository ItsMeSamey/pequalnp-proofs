#!/bin/sh
set -eu
lock=/workspace/scratch/pnp-native-search.lock
check_path() { test "$(stat -Lc '%d:%i' "$lock")" = 27:193638; }
check_held() {
    check_path
    found=0
    for fd in /proc/"$PPID"/fd/*; do
        if test "$(stat -Lc '%d:%i' "$fd" 2>/dev/null || :)" = 27:193638; then found=1; fi
    done
    test "$found" = 1
    awk -v parent="$PPID" '$2=="FLOCK" && $5==parent && $6 ~ /:193638$/ {held=1} END {exit !held}' /proc/locks
}
check_path
if test "${1-}" != --held; then exec flock -n "$lock" "$0" --held; fi
check_held
rc=0
timeout -k 0.1 6s nice -n 15 prlimit --cpu=3:3 --as=67108864:67108864 -- python -B /workspace/scratch/site-team-01/slack25/final12.py 12 --stage unique --existing /dev/shm/site-team-01-abc-drafts/enc/slack25-general-12-unique-candidates.json --slice-cpu 2.4 || rc=$?
check_held
exit "$rc"
