"""Finish support 12 and independently verify its two-minimal cases."""
import collections,json,runpy,sys
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
runpy.run_path(str(root/'run.py'),run_name='__main__')
receipt=json.loads((root/'support-12-unique.json').read_bytes())
assert receipt['done'] and sum(receipt['counts'].values())==4642
h=Path('/dev/shm/site-team-01-abc-drafts/enc')
low=json.loads((h/'slack25-general-12-minimal.json').read_bytes())
primary=json.loads((h/'slack25-general-12-two.json').read_bytes())
assert len(low['two'])==2 and not low['parallel'] and primary['hist']=={'prefix':6} and not primary['open']
check=sys.modules['replay'];counts=collections.Counter()
for a,d,b,e,c in low['two']:
    u,v=check.first(a,d),check.first(b,e)
    for parents in ((u,),(v,),(u,v)):
        try:
            w=check.gate(c,parents,bool(d or e),True)
            verdict='terminal' if check.cut(u,v,w) else 'open'
        except check.Conflict:verdict='prefix'
        counts[verdict]+=1
opens=sum(v for k,v in receipt['histogram'].items() if k.endswith(':open'))
summary=dict(support=12,ports=receipt['ports'],fixed_gates=141,lower=170 if counts['open'] or opens else 171,
             unique_cases=receipt['counts'],open_unique_across_checkers=opens,
             independent_two_minimal=counts,primary_two_minimal=primary['hist'],
             parallel_partitions=len(low['parallel']),source_sha256=receipt['source_sha256'],
             unique_rows_sha256=receipt['rows_sha256'],case_digest=receipt['cases_sha256'],
             scheduling_disclosure='support12-pilot-lock.json')
out=json.dumps(summary,sort_keys=True,separators=(',',':'));assert len(out)<2048
(root/'support12-final.json').write_text(out);print(out)
