import M13175Table
namespace NumericM13175
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def proof48 : List Nat := [12,1,1,1,3683,1,1,1,10,1,1,1,1803,1,1,1,771,1,1,1,8,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1]
theorem row48 : checkRow table 48 proof48 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof49 : List Nat := [14,1,1,1,3683,1,1,1,3691,1,1,1,3603,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,1827,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,1899,1,1,1,787,1,1,1,1859,1,1,1,3603,1,1,1,803,1,1,1]
theorem row49 : checkRow table 49 proof49 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof50 : List Nat := [1803,1,1,1,773,1,1,1,3683,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,1803,1,1,1,8,1,1,1,787,1,1,1,3651,1,1,1,1843,1,1,1,3603,1,1,1,1803,1,1,1,3915,1,1,1,1859,1,1,1,779,1,1,1,779,1,1,1]
theorem row50 : checkRow table 50 proof50 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof51 : List Nat := [1843,1,1,1,3683,1,1,1,1859,1,1,1,3603,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,2595,1,1,1,787,1,1,1,771,1,1,1,2611,1,1,1,779,1,1,1,8,1,1,1,787,1,1,1,2627,1,1,1,1803,1,1,1,1803,1,1,1]
theorem row51 : checkRow table 51 proof51 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof52 : List Nat := [1843,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,2595,1,1,1,787,1,1,1,771,1,1,1,2611,1,1,1,779,1,1,1,10,1,1,1,787,1,1,1,2627,1,1,1,1803,1,1,1,1803,1,1,1]
theorem row52 : checkRow table 52 proof52 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof53 : List Nat := [1803,1,1,1,771,1,1,1,771,1,1,1,1843,1,1,1,3603,1,1,1,779,1,1,1,3683,1,1,1,1803,1,1,1,787,1,1,1,779,1,1,1,1859,1,1,1,2611,1,1,1,1803,1,1,1,2571,1,1,1,779,1,1,1,6,1,1,1,2627,1,1,1]
theorem row53 : checkRow table 53 proof53 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof54 : List Nat := [1803,1,1,1,771,1,1,1,3683,1,1,1,1803,1,1,1,787,1,1,1,2611,1,1,1,1803,1,1,1,2571,1,1,1,2627,1,1,1,771,1,1,1,1843,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,1859,1,1,1,779,1,1,1,6,1,1,1]
theorem row54 : checkRow table 54 proof54 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof55 : List Nat := [1803,1,1,1,771,1,1,1,3683,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,1859,1,1,1,2867,1,1,1,1803,1,1,1,2827,1,1,1,2883,1,1,1,779,1,1,1,6,1,1,1]
theorem row55 : checkRow table 55 proof55 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof56 : List Nat := [771,1,1,1,1843,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,1803,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,1803,1,1,1,787,1,1,1,2611,1,1,1,779,1,1,1,8,1,1,1,2627,1,1,1,1803,1,1,1,2571,1,1,1]
theorem row56 : checkRow table 56 proof56 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof57 : List Nat := [771,1,1,1,1843,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,1803,1,1,1,771,1,1,1,3947,1,1,1,779,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,3843,1,1,1,779,1,1,1,3851,1,1,1,787,1,1,1,3859,1,1,1,1803,1,1,1,3603,1,1,1]
theorem row57 : checkRow table 57 proof57 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof58 : List Nat := [771,1,1,1,1843,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,1803,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,1803,1,1,1,787,1,1,1,2611,1,1,1,779,1,1,1,10,1,1,1,2627,1,1,1,1803,1,1,1,2571,1,1,1]
theorem row58 : checkRow table 58 proof58 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof59 : List Nat := [771,1,1,1,1843,1,1,1,1803,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,2611,1,1,1,779,1,1,1,3651,1,1,1,1803,1,1,1,2571,1,1,1,771,1,1,1,3843,1,1,1,779,1,1,1,3851,1,1,1,1803,1,1,1,3603,1,1,1,803,1,1,1,3859,1,1,1]
theorem row59 : checkRow table 59 proof59 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof60 : List Nat := [771,1,1,1,1843,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,1803,1,1,1,771,1,1,1,3947,1,1,1,779,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,3843,1,1,1,779,1,1,1,3851,1,1,1,787,1,1,1,3859,1,1,1,1803,1,1,1,3603,1,1,1]
theorem row60 : checkRow table 60 proof60 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof61 : List Nat := [3683,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,2611,1,1,1,2627,1,1,1,1803,1,1,1,2571,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,8,1,1,1]
theorem row61 : checkRow table 61 proof61 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof62 : List Nat := [3683,1,1,1,4363,1,1,1,771,1,1,1,4363,1,1,1,787,1,1,1,771,1,1,1,2611,1,1,1,787,1,1,1,2627,1,1,1,1803,1,1,1,1803,1,1,1,1843,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,8,1,1,1]
theorem row62 : checkRow table 62 proof62 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof63 : List Nat := [3683,1,1,1,4107,1,1,1,771,1,1,1,4107,1,1,1,787,1,1,1,1843,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,2867,1,1,1,787,1,1,1,2883,1,1,1,1803,1,1,1,1803,1,1,1,779,1,1,1,8,1,1,1]
theorem row63 : checkRow table 63 proof63 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
end NumericM13175
