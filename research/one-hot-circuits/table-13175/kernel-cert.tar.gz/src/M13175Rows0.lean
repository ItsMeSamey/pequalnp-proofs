import M13175Table
namespace NumericM13175
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def proof0 : List Nat := [1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,3683,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1]
theorem row0 : checkRow table 0 proof0 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof1 : List Nat := [1803,1,1,1,771,1,1,1,2579,1,1,1,779,1,1,1,1843,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,2611,1,1,1,779,1,1,1,1899,1,1,1]
theorem row1 : checkRow table 1 proof1 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof2 : List Nat := [1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,3683,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1]
theorem row2 : checkRow table 2 proof2 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof3 : List Nat := [1803,1,1,1,771,1,1,1,3683,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,1859,1,1,1]
theorem row3 : checkRow table 3 proof3 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof4 : List Nat := [3683,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1]
theorem row4 : checkRow table 4 proof4 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof5 : List Nat := [3683,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1]
theorem row5 : checkRow table 5 proof5 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof6 : List Nat := [3683,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1]
theorem row6 : checkRow table 6 proof6 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof7 : List Nat := [3683,1,1,1,3603,1,1,1,771,1,1,1,1827,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,787,1,1,1,1859,1,1,1,3603,1,1,1,803,1,1,1]
theorem row7 : checkRow table 7 proof7 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof8 : List Nat := [843,1,1,1,1803,1,1,1,771,1,1,1,2,1,1,1,2579,1,1,1,779,1,1,1,1867,1,1,1,1843,1,1,1,1803,1,1,1,787,1,1,1,787,1,1,1,2627,1,1,1,771,1,1,1,2611,1,1,1,779,1,1,1,1899,1,1,1]
theorem row8 : checkRow table 8 proof8 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof9 : List Nat := [1803,1,1,1,771,1,1,1,6,1,1,1,4,1,1,1,1803,1,1,1,787,1,1,1,3683,1,1,1,0,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1]
theorem row9 : checkRow table 9 proof9 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof10 : List Nat := [1803,1,1,1,867,1,1,1,843,1,1,1,1803,1,1,1,3915,1,1,1,1843,1,1,1,1803,1,1,1,789,1,1,1,3683,1,1,1,3659,1,1,1,1859,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,771,1,1,1,779,1,1,1,779,1,1,1,787,1,1,1,787,1,1,1]
theorem row10 : checkRow table 10 proof10 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof11 : List Nat := [1803,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,1803,1,1,1,787,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,1803,1,1,1,2571,1,1,1,2611,1,1,1,779,1,1,1,0,1,1,1,2627,1,1,1]
theorem row11 : checkRow table 11 proof11 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof12 : List Nat := [1803,1,1,1,773,1,1,1,3603,1,1,1,1803,1,1,1,3651,1,1,1,1843,1,1,1,1803,1,1,1,3859,1,1,1,771,1,1,1,779,1,1,1,779,1,1,1,1803,1,1,1,3603,1,1,1,1843,1,1,1,3683,1,1,1,3915,1,1,1,1859,1,1,1,787,1,1,1,787,1,1,1]
theorem row12 : checkRow table 12 proof12 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof13 : List Nat := [1803,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,1803,1,1,1,2571,1,1,1,2611,1,1,1,779,1,1,1,4163,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,787,1,1,1,2627,1,1,1]
theorem row13 : checkRow table 13 proof13 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof14 : List Nat := [1803,1,1,1,867,1,1,1,3603,1,1,1,1803,1,1,1,3651,1,1,1,1843,1,1,1,1803,1,1,1,2571,1,1,1,2611,1,1,1,787,1,1,1,3651,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,771,1,1,1,779,1,1,1,779,1,1,1,803,1,1,1,787,1,1,1]
theorem row14 : checkRow table 14 proof14 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof15 : List Nat := [1803,1,1,1,773,1,1,1,3603,1,1,1,1803,1,1,1,3651,1,1,1,1843,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,771,1,1,1,779,1,1,1,779,1,1,1,1803,1,1,1,2571,1,1,1,787,1,1,1,2611,1,1,1,787,1,1,1,3651,1,1,1,803,1,1,1,787,1,1,1]
theorem row15 : checkRow table 15 proof15 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
end NumericM13175
