import M13175Table
namespace NumericM13175
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def proof32 : List Nat := [3603,1,1,1,779,1,1,1,1803,1,1,1,771,1,1,1,771,1,1,1,1843,1,1,1,1803,1,1,1,787,1,1,1,779,1,1,1,1859,1,1,1,3683,1,1,1,1803,1,1,1,2571,1,1,1,779,1,1,1,4,1,1,1,2611,1,1,1,2627,1,1,1]
theorem row32 : checkRow table 32 proof32 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof33 : List Nat := [2595,1,1,1,1803,1,1,1,1803,1,1,1,789,1,1,1,3659,1,1,1,2611,1,1,1,1803,1,1,1,2571,1,1,1,3915,1,1,1,4171,1,1,1,1859,1,1,1,2611,1,1,1,1803,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,787,1,1,1,787,1,1,1,803,1,1,1,803,1,1,1]
theorem row33 : checkRow table 33 proof33 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof34 : List Nat := [3603,1,1,1,1803,1,1,1,1803,1,1,1,3859,1,1,1,779,1,1,1,779,1,1,1,1803,1,1,1,771,1,1,1,771,1,1,1,4163,1,1,1,803,1,1,1,771,1,1,1,1803,1,1,1,3603,1,1,1,3915,1,1,1,1859,1,1,1,787,1,1,1,787,1,1,1,771,1,1,1,2627,1,1,1]
theorem row34 : checkRow table 34 proof34 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof35 : List Nat := [1803,1,1,1,773,1,1,1,1803,1,1,1,3603,1,1,1,3683,1,1,1,1803,1,1,1,12,1,1,1,771,1,1,1,787,1,1,1,3603,1,1,1,1803,1,1,1,3651,1,1,1,1843,1,1,1,3915,1,1,1,1859,1,1,1,779,1,1,1,779,1,1,1]
theorem row35 : checkRow table 35 proof35 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof36 : List Nat := [3603,1,1,1,773,1,1,1,1827,1,1,1,3603,1,1,1,3683,1,1,1,3603,1,1,1,14,1,1,1,771,1,1,1,787,1,1,1,3603,1,1,1,1827,1,1,1,3651,1,1,1,1843,1,1,1,3915,1,1,1,1859,1,1,1,803,1,1,1,803,1,1,1]
theorem row36 : checkRow table 36 proof36 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof37 : List Nat := [1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,3683,1,1,1,1803,1,1,1,2571,1,1,1,2611,1,1,1,2627,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,779,1,1,1,4,1,1,1]
theorem row37 : checkRow table 37 proof37 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof38 : List Nat := [1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,3683,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,1803,1,1,1,2827,1,1,1,2867,1,1,1,2883,1,1,1,779,1,1,1,4,1,1,1]
theorem row38 : checkRow table 38 proof38 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof39 : List Nat := [2595,1,1,1,771,1,1,1,1803,1,1,1,789,1,1,1,771,1,1,1,3635,1,1,1,1803,1,1,1,2571,1,1,1,771,1,1,1,4147,1,1,1,2627,1,1,1,1803,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,787,1,1,1,787,1,1,1,803,1,1,1,803,1,1,1]
theorem row39 : checkRow table 39 proof39 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof40 : List Nat := [2595,1,1,1,1803,1,1,1,1803,1,1,1,789,1,1,1,3659,1,1,1,1843,1,1,1,1803,1,1,1,2571,1,1,1,3915,1,1,1,4171,1,1,1,2611,1,1,1,1803,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,787,1,1,1,787,1,1,1,803,1,1,1,803,1,1,1]
theorem row40 : checkRow table 40 proof40 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof41 : List Nat := [3603,1,1,1,1803,1,1,1,1803,1,1,1,3859,1,1,1,779,1,1,1,779,1,1,1,1803,1,1,1,2571,1,1,1,3635,1,1,1,4147,1,1,1,803,1,1,1,1803,1,1,1,3603,1,1,1,3915,1,1,1,1843,1,1,1,787,1,1,1,787,1,1,1,1843,1,1,1,2611,1,1,1]
theorem row41 : checkRow table 41 proof41 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof42 : List Nat := [3603,1,1,1,771,1,1,1,1803,1,1,1,3859,1,1,1,779,1,1,1,771,1,1,1,1803,1,1,1,2571,1,1,1,771,1,1,1,4163,1,1,1,803,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,3891,1,1,1,787,1,1,1,787,1,1,1,1859,1,1,1,2627,1,1,1]
theorem row42 : checkRow table 42 proof42 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof43 : List Nat := [1803,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,1803,1,1,1,2571,1,1,1,2611,1,1,1,779,1,1,1,4163,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,787,1,1,1,2627,1,1,1]
theorem row43 : checkRow table 43 proof43 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof44 : List Nat := [771,1,1,1,1845,1,1,1,787,1,1,1,3651,1,1,1,3683,1,1,1,1803,1,1,1,1803,1,1,1,4107,1,1,1,771,1,1,1,4107,1,1,1,787,1,1,1,779,1,1,1,8,1,1,1,1843,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1]
theorem row44 : checkRow table 44 proof44 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof45 : List Nat := [771,1,1,1,1845,1,1,1,787,1,1,1,3651,1,1,1,3683,1,1,1,1803,1,1,1,1803,1,1,1,4107,1,1,1,771,1,1,1,4107,1,1,1,787,1,1,1,779,1,1,1,10,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1]
theorem row45 : checkRow table 45 proof45 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof46 : List Nat := [771,1,1,1,1899,1,1,1,787,1,1,1,3651,1,1,1,3683,1,1,1,1803,1,1,1,1803,1,1,1,4107,1,1,1,771,1,1,1,4107,1,1,1,787,1,1,1,779,1,1,1,12,1,1,1,771,1,1,1,1843,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1]
theorem row46 : checkRow table 46 proof46 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof47 : List Nat := [771,1,1,1,1843,1,1,1,787,1,1,1,1859,1,1,1,3683,1,1,1,3603,1,1,1,2595,1,1,1,3603,1,1,1,771,1,1,1,4131,1,1,1,787,1,1,1,803,1,1,1,14,1,1,1,2611,1,1,1,2627,1,1,1,3603,1,1,1,803,1,1,1]
theorem row47 : checkRow table 47 proof47 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
end NumericM13175
