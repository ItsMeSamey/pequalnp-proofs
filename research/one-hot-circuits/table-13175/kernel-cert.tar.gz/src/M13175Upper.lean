import ProbeM13175
namespace ProbeM13175
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Represents

def witness : Circuit := ⟨[
  ⟨.or,[4,5]⟩, ⟨.or,[7,8]⟩, ⟨.or,[9,10]⟩, ⟨.and,[0,11]⟩,
  ⟨.or,[5,6]⟩, ⟨.and,[1,13]⟩, ⟨.and,[2,4]⟩, ⟨.or,[12,14]⟩,
  ⟨.or,[16,15]⟩, ⟨.or,[17,3]⟩],18⟩

theorem upper : RepSizeAtMost matrix 10 := by
  refine ⟨witness, ?_, ?_, ?_⟩
  · simp [Monotone2,witness]
  · decide
  · decide +kernel
end ProbeM13175
