import M13175Table
namespace NumericM13175
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def proof80 : List Nat := [771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3683,1,1,1,3603,1,1,1,779,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,779,1,1,1,12,1,1,1,2611,1,1,1,2627,1,1,1,1803,1,1,1,2571,1,1,1]
theorem row80 : checkRow table 80 proof80 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof81 : List Nat := [779,1,1,1,1859,1,1,1,2563,1,1,1,2563,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,4203,1,1,1,2627,1,1,1,1803,1,1,1,771,1,1,1,779,1,1,1,3851,1,1,1,787,1,1,1,3859,1,1,1,4099,1,1,1,4099,1,1,1,771,1,1,1,3843,1,1,1]
theorem row81 : checkRow table 81 proof81 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof82 : List Nat := [779,1,1,1,2611,1,1,1,2595,1,1,1,779,1,1,1,1803,1,1,1,787,1,1,1,779,1,1,1,4203,1,1,1,787,1,1,1,2611,1,1,1,1803,1,1,1,2571,1,1,1,779,1,1,1,3851,1,1,1,787,1,1,1,3859,1,1,1,1803,1,1,1,3603,1,1,1,803,1,1,1,3875,1,1,1]
theorem row82 : checkRow table 82 proof82 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof83 : List Nat := [771,1,1,1,1859,1,1,1,2595,1,1,1,779,1,1,1,1803,1,1,1,771,1,1,1,779,1,1,1,4203,1,1,1,2627,1,1,1,1803,1,1,1,2571,1,1,1,779,1,1,1,3851,1,1,1,771,1,1,1,3843,1,1,1,3587,1,1,1,3587,1,1,1,803,1,1,1,3875,1,1,1]
theorem row83 : checkRow table 83 proof83 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof84 : List Nat := [3683,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,2611,1,1,1,2627,1,1,1,1803,1,1,1,2571,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,12,1,1,1]
theorem row84 : checkRow table 84 proof84 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof85 : List Nat := [3683,1,1,1,4363,1,1,1,771,1,1,1,4363,1,1,1,787,1,1,1,771,1,1,1,2611,1,1,1,787,1,1,1,2627,1,1,1,1803,1,1,1,1803,1,1,1,771,1,1,1,1843,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,12,1,1,1]
theorem row85 : checkRow table 85 proof85 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof86 : List Nat := [3683,1,1,1,4107,1,1,1,771,1,1,1,4107,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,2867,1,1,1,787,1,1,1,2883,1,1,1,1803,1,1,1,1803,1,1,1,779,1,1,1,12,1,1,1]
theorem row86 : checkRow table 86 proof86 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof87 : List Nat := [3683,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,2867,1,1,1,2883,1,1,1,1803,1,1,1,2827,1,1,1,779,1,1,1,12,1,1,1]
theorem row87 : checkRow table 87 proof87 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof88 : List Nat := [3683,1,1,1,3603,1,1,1,771,1,1,1,4131,1,1,1,787,1,1,1,2611,1,1,1,2627,1,1,1,3603,1,1,1,803,1,1,1,771,1,1,1,1843,1,1,1,787,1,1,1,1859,1,1,1,3603,1,1,1,2595,1,1,1,803,1,1,1,14,1,1,1]
theorem row88 : checkRow table 88 proof88 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof89 : List Nat := [3683,1,1,1,3603,1,1,1,771,1,1,1,1827,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,787,1,1,1,1859,1,1,1,3603,1,1,1,803,1,1,1,2867,1,1,1,2883,1,1,1,3603,1,1,1,2851,1,1,1,803,1,1,1,14,1,1,1]
theorem row89 : checkRow table 89 proof89 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof90 : List Nat := [1859,1,1,1,1827,1,1,1,3843,1,1,1,2595,1,1,1,787,1,1,1,3843,1,1,1,4147,1,1,1,787,1,1,1,2627,1,1,1,1803,1,1,1,1803,1,1,1,779,1,1,1,3843,1,1,1,787,1,1,1,3859,1,1,1,3603,1,1,1,3603,1,1,1,803,1,1,1,3875,1,1,1]
theorem row90 : checkRow table 90 proof90 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof91 : List Nat := [1859,1,1,1,1827,1,1,1,771,1,1,1,2595,1,1,1,787,1,1,1,771,1,1,1,4203,1,1,1,787,1,1,1,2627,1,1,1,1795,1,1,1,1795,1,1,1,771,1,1,1,3843,1,1,1,787,1,1,1,3859,1,1,1,3603,1,1,1,3603,1,1,1,803,1,1,1,3875,1,1,1]
theorem row91 : checkRow table 91 proof91 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof92 : List Nat := [779,1,1,1,1843,1,1,1,1827,1,1,1,779,1,1,1,2595,1,1,1,787,1,1,1,779,1,1,1,4203,1,1,1,787,1,1,1,1843,1,1,1,1803,1,1,1,1803,1,1,1,779,1,1,1,3851,1,1,1,787,1,1,1,3859,1,1,1,3603,1,1,1,3603,1,1,1,803,1,1,1,3875,1,1,1]
theorem row92 : checkRow table 92 proof92 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof93 : List Nat := [3843,1,1,1,3635,1,1,1,2595,1,1,1,3843,1,1,1,1803,1,1,1,787,1,1,1,3843,1,1,1,4147,1,1,1,2627,1,1,1,1803,1,1,1,2571,1,1,1,779,1,1,1,3843,1,1,1,787,1,1,1,3859,1,1,1,1803,1,1,1,3603,1,1,1,803,1,1,1,3875,1,1,1]
theorem row93 : checkRow table 93 proof93 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof94 : List Nat := [771,1,1,1,1859,1,1,1,2595,1,1,1,771,1,1,1,1795,1,1,1,787,1,1,1,771,1,1,1,4203,1,1,1,2627,1,1,1,1795,1,1,1,2563,1,1,1,771,1,1,1,3843,1,1,1,787,1,1,1,3859,1,1,1,1795,1,1,1,3603,1,1,1,803,1,1,1,3875,1,1,1]
theorem row94 : checkRow table 94 proof94 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof95 : List Nat := [779,1,1,1,1843,1,1,1,2595,1,1,1,779,1,1,1,1803,1,1,1,787,1,1,1,779,1,1,1,4203,1,1,1,2611,1,1,1,1803,1,1,1,2571,1,1,1,779,1,1,1,3851,1,1,1,787,1,1,1,3859,1,1,1,1803,1,1,1,3603,1,1,1,803,1,1,1,3875,1,1,1]
theorem row95 : checkRow table 95 proof95 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
end NumericM13175
