import NumericM13175Closure
import SliceNextM13175
import SliceBadWM13175

namespace ProbeM13175
open ProbeFrontier PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

private theorem checked_row {tab : Array NumericM13175.Key}
    (cov : NumericM13175.Covered tab tab.size) {S : Finset (Mask (Fin 18))}
    {b t B T w : ℕ} (sl : LiveSlice target b t S) (hb : b ≤ B) (ht : t ≤ T)
    (checked : NumericM13175.checkChild tab (B,T,codes S) w = true) :
    (codes S).contains NumericM13175.goal = false ∧
      ∀ k ∈ NumericM13175.next B T (codes S), ∃ w, NumericM13175.checkChild tab k w = true := by
  unfold NumericM13175.checkChild at checked
  split at checked
  · have hi : tab[w/2]? = some (B,T,codes S) := by simpa using checked
    have lt : w/2 < tab.size := by
      by_contra hn
      have nope : tab[w/2]? = none := Array.getElem?_eq_none (by omega)
      simp [nope] at hi
    obtain ⟨proof,hp⟩ := cov (w/2) lt
    exact NumericM13175.row_children_checked hi hp
  · exact (slice_not_badW sl hb ht _ checked).elim

theorem slice_not_checked {tab : Array NumericM13175.Key} (cov : NumericM13175.Covered tab tab.size)
    {S : Finset (Mask (Fin 18))} {b t : ℕ} (sl : LiveSlice target b t S) :
    ∀ B T, b ≤ B → t ≤ T → ∀ w,
      NumericM13175.checkChild tab (B,T,codes S) w ≠ true := by
  induction sl with
  | finish =>
    intro B T hb ht w hw
    have h := (checked_row cov LiveSlice.finish hb ht hw).1
    have mem : NumericM13175.goal ∈ codes ({target} : Finset _) :=
      mem_codes.mpr ⟨target,by simp,encode_target⟩
    simp [mem] at h
  | @step b t S P neg y op hy fresh rest ih =>
    intro B T hb ht w hw
    have children := (checked_row cov (LiveSlice.step op hy fresh rest) hb ht hw).2
    let cb := if neg then 0 else 1
    let ct := if neg then 1 else 0
    have bb : B-cb+cb=B := by change b+cb ≤ B at hb; omega
    have tt : T-ct+ct=T := by change t+ct ≤ T at ht; omega
    have member := exactOp_next (B-cb) (T-ct) op hy fresh
    change (_,_,_) ∈ NumericM13175.next (B-cb+cb) (T-ct+ct) _ at member
    rw [bb,tt] at member
    obtain ⟨code,ok⟩ := children _ member
    apply ih (B-cb) (T-ct) _ _ code ok
    · change b+cb ≤ B at hb; omega
    · change t+ct ≤ T at ht; omega


theorem refute_of_ledger {tab : Array NumericM13175.Key} (cov : NumericM13175.Covered tab tab.size)
    (root : ∃ w, NumericM13175.checkChild tab (9,0,NumericM13175.start) w = true) :
    ¬ PEqualNP.Represents.RepSizeAtMost matrix 9 := by
  rintro ⟨C,legal,size,rep⟩
  obtain ⟨B,budget,build⟩ := physical_to_build C legal size rep
  obtain ⟨S,sub,b,hb,t,ht,sl⟩ := build.slice
  have z : t=0 := by omega
  subst t
  have init := subset_essential S sub (sl.monotone rfl)
  subst S
  obtain ⟨w,hw⟩ := root
  apply slice_not_checked cov sl 9 0 (by omega) le_rfl w
  simpa only [codes_start,NumericM13175.start] using hw
end ProbeM13175
