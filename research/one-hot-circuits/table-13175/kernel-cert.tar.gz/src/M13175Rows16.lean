import M13175Table
namespace NumericM13175
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def proof16 : List Nat := [1803,1,1,1,867,1,1,1,843,1,1,1,1803,1,1,1,3915,1,1,1,1843,1,1,1,1803,1,1,1,789,1,1,1,3683,1,1,1,3659,1,1,1,1859,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,771,1,1,1,779,1,1,1,779,1,1,1,787,1,1,1,787,1,1,1]
theorem row16 : checkRow table 16 proof16 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof17 : List Nat := [1803,1,1,1,773,1,1,1,3603,1,1,1,1803,1,1,1,3651,1,1,1,1843,1,1,1,1803,1,1,1,3859,1,1,1,771,1,1,1,779,1,1,1,779,1,1,1,1803,1,1,1,3603,1,1,1,1843,1,1,1,3683,1,1,1,3915,1,1,1,1859,1,1,1,787,1,1,1,787,1,1,1]
theorem row17 : checkRow table 17 proof17 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof18 : List Nat := [1803,1,1,1,773,1,1,1,1803,1,1,1,3603,1,1,1,3683,1,1,1,1803,1,1,1,8,1,1,1,771,1,1,1,787,1,1,1,3603,1,1,1,1803,1,1,1,3651,1,1,1,1843,1,1,1,3915,1,1,1,1859,1,1,1,779,1,1,1,779,1,1,1]
theorem row18 : checkRow table 18 proof18 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof19 : List Nat := [1803,1,1,1,773,1,1,1,1803,1,1,1,3603,1,1,1,3683,1,1,1,1803,1,1,1,10,1,1,1,771,1,1,1,787,1,1,1,3603,1,1,1,1803,1,1,1,3651,1,1,1,1843,1,1,1,3915,1,1,1,1859,1,1,1,779,1,1,1,779,1,1,1]
theorem row19 : checkRow table 19 proof19 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof20 : List Nat := [1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,3683,1,1,1,1803,1,1,1,2571,1,1,1,2611,1,1,1,2627,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,779,1,1,1,0,1,1,1]
theorem row20 : checkRow table 20 proof20 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof21 : List Nat := [1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,3683,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,1803,1,1,1,2827,1,1,1,2867,1,1,1,2883,1,1,1,779,1,1,1,0,1,1,1]
theorem row21 : checkRow table 21 proof21 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof22 : List Nat := [1803,1,1,1,867,1,1,1,843,1,1,1,1803,1,1,1,3915,1,1,1,1843,1,1,1,1803,1,1,1,789,1,1,1,3683,1,1,1,3659,1,1,1,1859,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,771,1,1,1,779,1,1,1,779,1,1,1,787,1,1,1,787,1,1,1]
theorem row22 : checkRow table 22 proof22 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof23 : List Nat := [1803,1,1,1,773,1,1,1,3603,1,1,1,1803,1,1,1,3651,1,1,1,1843,1,1,1,1803,1,1,1,3859,1,1,1,771,1,1,1,779,1,1,1,779,1,1,1,1803,1,1,1,3603,1,1,1,1843,1,1,1,3683,1,1,1,3915,1,1,1,1859,1,1,1,787,1,1,1,787,1,1,1]
theorem row23 : checkRow table 23 proof23 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof24 : List Nat := [1803,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,1843,1,1,1,1803,1,1,1,2571,1,1,1,2611,1,1,1,779,1,1,1,4163,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,787,1,1,1,2627,1,1,1]
theorem row24 : checkRow table 24 proof24 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof25 : List Nat := [1803,1,1,1,771,1,1,1,2595,1,1,1,779,1,1,1,1843,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,3683,1,1,1,3691,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,2611,1,1,1,779,1,1,1,1899,1,1,1,787,1,1,1,2,1,1,1]
theorem row25 : checkRow table 25 proof25 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof26 : List Nat := [1803,1,1,1,771,1,1,1,2835,1,1,1,779,1,1,1,1843,1,1,1,1803,1,1,1,4115,1,1,1,2611,1,1,1,4203,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,2867,1,1,1,779,1,1,1,1899,1,1,1,787,1,1,1,2,1,1,1]
theorem row26 : checkRow table 26 proof26 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof27 : List Nat := [1803,1,1,1,771,1,1,1,2579,1,1,1,779,1,1,1,1843,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,2611,1,1,1,3691,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,2867,1,1,1,779,1,1,1,1899,1,1,1,787,1,1,1,2,1,1,1]
theorem row27 : checkRow table 27 proof27 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof28 : List Nat := [1803,1,1,1,771,1,1,1,2579,1,1,1,779,1,1,1,1843,1,1,1,1803,1,1,1,4371,1,1,1,2867,1,1,1,4459,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,2611,1,1,1,779,1,1,1,1899,1,1,1,787,1,1,1,2,1,1,1]
theorem row28 : checkRow table 28 proof28 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof29 : List Nat := [1803,1,1,1,771,1,1,1,2835,1,1,1,779,1,1,1,1843,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,2867,1,1,1,3691,1,1,1,1803,1,1,1,3603,1,1,1,771,1,1,1,2611,1,1,1,779,1,1,1,1899,1,1,1,787,1,1,1,2,1,1,1]
theorem row29 : checkRow table 29 proof29 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof30 : List Nat := [1803,1,1,1,771,1,1,1,3603,1,1,1,779,1,1,1,1843,1,1,1,1803,1,1,1,4115,1,1,1,2611,1,1,1,4203,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,3635,1,1,1,779,1,1,1,1899,1,1,1,787,1,1,1,2,1,1,1]
theorem row30 : checkRow table 30 proof30 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof31 : List Nat := [1803,1,1,1,771,1,1,1,2579,1,1,1,779,1,1,1,1843,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,2611,1,1,1,3691,1,1,1,3603,1,1,1,771,1,1,1,3891,1,1,1,779,1,1,1,1899,1,1,1,787,1,1,1,2,1,1,1]
theorem row31 : checkRow table 31 proof31 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
end NumericM13175
