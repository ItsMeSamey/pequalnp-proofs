import M13175Final
import M13175Upper

namespace ProbeM13175
open PEqualNP.Represents

theorem exact_size (b : ℕ) : RepSizeAtMost matrix b ↔ 10 ≤ b := by
  constructor
  · rintro ⟨C, legal, size, rep⟩
    by_contra h
    exact offered13175_refuted ⟨C, legal, by omega, rep⟩
  · intro h
    obtain ⟨C,legal,size,rep⟩ := upper
    exact ⟨C,legal,by omega,rep⟩

#print axioms exact_size
end ProbeM13175
