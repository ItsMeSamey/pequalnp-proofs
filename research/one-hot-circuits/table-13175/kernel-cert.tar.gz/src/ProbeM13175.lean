import MonoProbe
import FreshBuild
namespace ProbeM13175
open ProbeFrontier PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Represents
open PEqualNP.Research.MissingCell

def matrix (r : Fin 3) (c : Fin 6) : Bool := (13175 : ℕ).testBit (6*r.val+c.val)
def inputs (p : Fin 18) : List Bool := oneEach (⟨p.val/6,by omega⟩ : Fin 3) (⟨p.val%6,by omega⟩ : Fin 6)
def sig (v : ℕ) : Mask (Fin 18) := fun p => v.testBit p.val
def target := sig 13175
def rawCodes : Vector ℕ 9 := #v[63,4032,258048,4161,8322,16644,33288,66576,133152]
def raw (k : Fin 9) := sig rawCodes[k]
def start : Finset (Mask (Fin 18)) := Finset.univ.image raw

private theorem raw_correct : ∀ (k : Fin 9) (p : Fin 18), (inputs p).getD k.val false = raw k p := by decide +kernel

theorem physical_to_build (C : Circuit) (legal : Monotone2 C) (size : C.size ≤ 9) (rep : Represents matrix C) :
    ∃ b, b ≤ 9 ∧ Build target b 0 start := by
  obtain ⟨b,sz,run⟩ := simulateMono C.gates 9 C.output inputs (fun p => by simp [inputs,oneEach]) legal
  have vals : (fun p => C.eval (inputs p)) = target := by
    funext p
    have h := rep (⟨p.val/6,by omega⟩ : Fin 3) (⟨p.val%6,by omega⟩ : Fin 6)
    apply h.trans
    change (13175 : ℕ).testBit (6*(p.val/6)+p.val%6) = (13175 : ℕ).testBit p.val
    rw [Nat.div_add_mod]
  change Run (fun p => C.eval (inputs p)) b 0 _ at run
  rw [vals] at run
  have nh : target ≠ zero := by intro e; have h := congrFun e 0; revert h; decide +kernel
  have nf : target ≠ one := by intro e; have h := congrFun e 3; revert h; decide +kernel
  obtain ⟨b',t',hb,ht,build⟩ := run.toBuild nh nf start (fun x hx => by
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hx
    have lt := live_lt C.gates 9 C.output i hi
    left
    exact Finset.mem_image.mpr ⟨⟨i,lt⟩,Finset.mem_univ _,(funext (raw_correct ⟨i,lt⟩)).symm⟩)
  have zz : t'=0 := by omega
  subst t'
  change C.gates.length ≤ 9 at size
  exact ⟨b',by omega,build⟩

private theorem essential : ∀ k : Fin 9, ∃ p n : Fin 18, target p = true ∧ target n = false ∧
    ∀ l : Fin 9, l ≠ k → raw l p ≤ raw l n := by decide +kernel

theorem subset_essential (D : Finset (Mask (Fin 18))) (sub : D ⊆ start)
    (mono : ∀ p n : Fin 18, (∀ a ∈ D, a p ≤ a n) → target p ≤ target n) : D=start := by
  apply Finset.Subset.antisymm sub
  rintro a ha
  obtain ⟨k,_,rfl⟩ := Finset.mem_image.mp ha
  by_contra hk
  obtain ⟨p,n,hp,hn,hw⟩ := essential k
  have bad := mono p n (by
    intro a ha
    have distinct : a ≠ raw k := by
      intro e
      exact hk (e ▸ ha)
    obtain ⟨j,_,eq⟩ := Finset.mem_image.mp (sub ha)
    rw [←eq]
    apply hw j
    rintro rfl
    exact distinct eq.symm)
  rw [hp,hn] at bad
  exact (by decide : ¬ (true ≤ false)) bad
end ProbeM13175
