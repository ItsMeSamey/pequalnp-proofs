import M13175Table
namespace NumericM13175
set_option maxRecDepth 200000
set_option maxHeartbeats 0
def proof64 : List Nat := [3683,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,2867,1,1,1,2883,1,1,1,1803,1,1,1,2827,1,1,1,779,1,1,1,8,1,1,1]
theorem row64 : checkRow table 64 proof64 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof65 : List Nat := [3683,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,2611,1,1,1,2627,1,1,1,1803,1,1,1,2571,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,10,1,1,1]
theorem row65 : checkRow table 65 proof65 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof66 : List Nat := [3683,1,1,1,4363,1,1,1,771,1,1,1,4363,1,1,1,787,1,1,1,771,1,1,1,2611,1,1,1,787,1,1,1,2627,1,1,1,1803,1,1,1,1803,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,779,1,1,1,10,1,1,1]
theorem row66 : checkRow table 66 proof66 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof67 : List Nat := [3683,1,1,1,4107,1,1,1,771,1,1,1,4107,1,1,1,787,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,771,1,1,1,2867,1,1,1,787,1,1,1,2883,1,1,1,1803,1,1,1,1803,1,1,1,779,1,1,1,10,1,1,1]
theorem row67 : checkRow table 67 proof67 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof68 : List Nat := [3683,1,1,1,1803,1,1,1,771,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,1843,1,1,1,779,1,1,1,1859,1,1,1,3603,1,1,1,779,1,1,1,2867,1,1,1,2883,1,1,1,1803,1,1,1,2827,1,1,1,779,1,1,1,10,1,1,1]
theorem row68 : checkRow table 68 proof68 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof69 : List Nat := [771,1,1,1,1843,1,1,1,3683,1,1,1,779,1,1,1,1859,1,1,1,1803,1,1,1,771,1,1,1,3947,1,1,1,779,1,1,1,1803,1,1,1,787,1,1,1,771,1,1,1,3843,1,1,1,779,1,1,1,3851,1,1,1,787,1,1,1,3859,1,1,1,1803,1,1,1,3603,1,1,1]
theorem row69 : checkRow table 69 proof69 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof70 : List Nat := [2563,1,1,1,2563,1,1,1,1803,1,1,1,789,1,1,1,3659,1,1,1,1859,1,1,1,1803,1,1,1,2571,1,1,1,3915,1,1,1,4171,1,1,1,2627,1,1,1,4099,1,1,1,4099,1,1,1,779,1,1,1,779,1,1,1,787,1,1,1,787,1,1,1,771,1,1,1,771,1,1,1]
theorem row70 : checkRow table 70 proof70 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof71 : List Nat := [2595,1,1,1,1803,1,1,1,1803,1,1,1,867,1,1,1,3659,1,1,1,1859,1,1,1,1803,1,1,1,2571,1,1,1,3915,1,1,1,4171,1,1,1,2627,1,1,1,3587,1,1,1,3587,1,1,1,779,1,1,1,779,1,1,1,771,1,1,1,771,1,1,1,803,1,1,1,803,1,1,1]
theorem row71 : checkRow table 71 proof71 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof72 : List Nat := [3587,1,1,1,1803,1,1,1,3587,1,1,1,3843,1,1,1,779,1,1,1,779,1,1,1,3587,1,1,1,4099,1,1,1,3651,1,1,1,4163,1,1,1,803,1,1,1,1803,1,1,1,3587,1,1,1,3915,1,1,1,1859,1,1,1,771,1,1,1,771,1,1,1,1859,1,1,1,2627,1,1,1]
theorem row72 : checkRow table 72 proof72 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof73 : List Nat := [2563,1,1,1,2563,1,1,1,1803,1,1,1,3859,1,1,1,779,1,1,1,779,1,1,1,1803,1,1,1,2571,1,1,1,3651,1,1,1,4163,1,1,1,771,1,1,1,4099,1,1,1,4099,1,1,1,3915,1,1,1,1859,1,1,1,787,1,1,1,787,1,1,1,1859,1,1,1,2627,1,1,1]
theorem row73 : checkRow table 73 proof73 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof74 : List Nat := [2595,1,1,1,1795,1,1,1,1795,1,1,1,789,1,1,1,3659,1,1,1,1859,1,1,1,1795,1,1,1,2563,1,1,1,3915,1,1,1,4171,1,1,1,2627,1,1,1,1795,1,1,1,3603,1,1,1,771,1,1,1,771,1,1,1,787,1,1,1,787,1,1,1,803,1,1,1,803,1,1,1]
theorem row74 : checkRow table 74 proof74 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof75 : List Nat := [3603,1,1,1,1795,1,1,1,1795,1,1,1,3859,1,1,1,771,1,1,1,771,1,1,1,1795,1,1,1,2563,1,1,1,3651,1,1,1,4163,1,1,1,803,1,1,1,1795,1,1,1,3603,1,1,1,3915,1,1,1,1859,1,1,1,787,1,1,1,787,1,1,1,1859,1,1,1,2627,1,1,1]
theorem row75 : checkRow table 75 proof75 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof76 : List Nat := [771,1,1,1,1843,1,1,1,1859,1,1,1,3683,1,1,1,3603,1,1,1,779,1,1,1,3603,1,1,1,771,1,1,1,2595,1,1,1,787,1,1,1,779,1,1,1,12,1,1,1,771,1,1,1,2611,1,1,1,787,1,1,1,2627,1,1,1,1803,1,1,1,1803,1,1,1]
theorem row76 : checkRow table 76 proof76 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof77 : List Nat := [1859,1,1,1,1795,1,1,1,1795,1,1,1,2563,1,1,1,787,1,1,1,771,1,1,1,4203,1,1,1,771,1,1,1,2627,1,1,1,1803,1,1,1,771,1,1,1,779,1,1,1,3851,1,1,1,787,1,1,1,3859,1,1,1,2563,1,1,1,4099,1,1,1,771,1,1,1,3843,1,1,1]
theorem row77 : checkRow table 77 proof77 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof78 : List Nat := [1843,1,1,1,1827,1,1,1,779,1,1,1,2595,1,1,1,787,1,1,1,779,1,1,1,4203,1,1,1,787,1,1,1,2611,1,1,1,1803,1,1,1,1803,1,1,1,779,1,1,1,3851,1,1,1,787,1,1,1,3859,1,1,1,3603,1,1,1,3603,1,1,1,803,1,1,1,3875,1,1,1]
theorem row78 : checkRow table 78 proof78 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
def proof79 : List Nat := [1859,1,1,1,1827,1,1,1,779,1,1,1,2595,1,1,1,771,1,1,1,779,1,1,1,4203,1,1,1,771,1,1,1,2627,1,1,1,1803,1,1,1,1803,1,1,1,779,1,1,1,3851,1,1,1,771,1,1,1,3843,1,1,1,3587,1,1,1,3587,1,1,1,803,1,1,1,3875,1,1,1]
theorem row79 : checkRow table 79 proof79 = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel
end NumericM13175
