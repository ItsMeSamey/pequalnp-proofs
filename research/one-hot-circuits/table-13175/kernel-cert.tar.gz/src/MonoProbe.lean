import ProbeFrontier
namespace ProbeFrontier
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Research.MissingCell
variable {α : Type} [Fintype α] [DecidableEq α]
omit [Fintype α] [DecidableEq α] in
private theorem operation_of_mono_gate {g : Gate} {w : α → List Bool} {S : Finset (Mask α)}
    (ok : g.op = .and ∨ g.op = .or) (len : g.inputs.length ≤ 2)
    (readable : ∀ i ∈ g.inputs, available S (value w i)) :
    Operation S false (fun p => g.op.eval (g.inputs.map fun i => (w p).getD i false)) := by
  obtain ⟨op,ins⟩ := g
  change op = _ ∨ op = _ at ok
  change ins.length ≤ 2 at len
  change ∀ i ∈ ins, available S (value w i) at readable
  change Operation S false (fun p => op.eval (ins.map fun i => (w p).getD i false))
  have hz : available S zero := Or.inr (Or.inl rfl)
  have ht : available S one := Or.inr (Or.inr rfl)
  cases ins with
  | nil =>
    rcases ok with rfl|rfl
    · exact Operation.conj one one ht ht
    · exact Operation.disj zero zero hz hz
  | cons a tl =>
    have ha := readable a (by simp)
    cases tl with
    | nil =>
      rcases ok with rfl|rfl
      · exact Operation.conj (value w a) one ha ht
      · exact Operation.disj (value w a) zero ha hz
    | cons b tl =>
      have hb := readable b (by simp)
      cases tl with
      | nil =>
        rcases ok with rfl|rfl
        · exact by simpa [GateOp.eval,value] using Operation.conj (value w a) (value w b) ha hb
        · exact by simpa [GateOp.eval,value] using Operation.disj (value w a) (value w b) ha hb
      | cons d ds => simp at len

omit [DecidableEq α] in
theorem simulateMono (gs : List Gate) (n o : ℕ) (w : α → List Bool)
    (len : ∀ p, (w p).length = n) (legal : Monotone2 ⟨gs,o⟩) :
    ∃ b, b ≤ gs.length ∧ Run (fun p => (Circuit.mk gs o).eval (w p)) b 0
      (bank w (live gs n o)) := by
  induction gs generalizing n w with
  | nil =>
    refine ⟨0,by simp,Run.finish _ ?_⟩
    change available _ (value w o)
    by_cases h : o<n
    · exact Or.inl (Finset.mem_image.mpr ⟨o,by simp [live,h],rfl⟩)
    · right; left; funext p
      exact getD_missing (by rw [len p]; omega)
  | cons g gs ih =>
    let w' : α → List Bool := fun p => advance g (w p)
    let I := live gs (n+1) o
    let J := live (g::gs) n o
    let y : Mask α := fun p => g.op.eval (g.inputs.map fun i => (w p).getD i false)
    have L : ∀ p, (w' p).length=n+1 := fun p => by simp [w',advance,len p]
    obtain ⟨b,sz,run⟩ := ih (n+1) w' L (fun k hk => legal k (List.mem_cons_of_mem _ hk))
    have old (i : ℕ) (hi : i<n) : value w' i = value w i := by
      funext p; exact getD_advance_lt _ _ _ (by rw [len p]; exact hi)
    have newval : value w' n = y := by
      funext p; simpa only [w',y,value,len p] using getD_advance_eq g (w p)
    by_cases used : n ∈ I
    · have ins (i : ℕ) (hi : i ∈ g.inputs) : available (bank w J) (value w i) := by
        by_cases h : i<n
        · left
          apply Finset.mem_image.mpr
          refine ⟨i,?_,rfl⟩
          change i ∈ (if n ∈ I then (I.erase n) ∪ _ else I)
          rw [ite_eq_left used]
          exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨List.mem_toFinset.mpr hi,h⟩)
        · right; left; funext p; exact getD_missing (by rw [len p]; omega)
      have good := legal g (List.mem_cons_self ..)
      have hop : g.op = .and ∨ g.op = .or := good.1
      have op := operation_of_mono_gate hop good.2 ins
      have keep : bank w' I ⊆ insert y (bank w J) := by
        intro x hx
        obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hx
        by_cases eq : i=n
        · subst i; simp [newval]
        · have lt := live_lt gs (n+1) o i hi
          rw [old i (by omega)]
          apply Finset.mem_insert_of_mem
          refine Finset.mem_image.mpr ⟨i,?_,rfl⟩
          change i ∈ (if n ∈ I then (I.erase n) ∪ _ else I)
          rw [ite_eq_left used]; exact Finset.mem_union_left _ (Finset.mem_erase.mpr ⟨eq,hi⟩)
      exact ⟨b+1, by simp; omega, Run.step op keep run⟩
    · have eq : bank w' I = bank w J := by
        have same : J = I := by change (if n ∈ I then _ else I) = I; simp [used]
        rw [same]
        apply Finset.image_congr
        intro i hi
        have lt := live_lt gs (n+1) o i hi
        have ne : i ≠ n := fun e => used (e ▸ hi)
        exact old i (by omega)
      refine ⟨b,by simp; omega,?_⟩
      change Run _ b 0 (bank w J)
      rw [←eq]; exact run

end ProbeFrontier
