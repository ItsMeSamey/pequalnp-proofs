"""Replayable witness codes for the existing monotone LiveSlice kernel checker."""
from pathlib import Path
import json
from functools import lru_cache
target=13175
ones=(1<<18)-1
pairs=[(p,n) for p in range(18) if target>>p&1 for n in range(18) if not(target>>n&1)]
full=(1<<len(pairs))-1
where={}
@lru_cache(None)
def sig(x):
    pos=neg=0
    for i,(a,b) in enumerate(pairs):
        if (x>>a^x>>b)&1:
            if x>>a&1:pos|=1<<i
            else:neg|=1<<i
    return pos,neg
def point(q):
    return pairs[(q&-q).bit_length()-1]
def enc(pair):
    p,n=pair
    return p+32*n
@lru_cache(maxsize=150000)
def code(b,t,s):
    if (b,t,s) in where:return 2*where[b,t,s]
    if b+1<len(s):return 1
    arr=[sig(x) for x in s]
    pos=neg=0;dup=union=0
    for a,n in arr:
        pos|=a;neg|=n;diff=a|n
        dup|=union&diff;union|=diff
    if union!=full:return 2*(1+4*enc(point(full^union)))+1
    if t==0 and pos!=full:return 2*(2+4*enc(point(full^pos)))+1
    if b+1==len(s):
        for ix,(a,n) in enumerate(arr):
            if (a&~dup) and (n&~dup):
                pack=enc(point(a&~dup))+(enc(point(n&~dup))<<10)+(ix<<20)
                return 2*(3+4*pack)+1
    return None
def children(b,t,s):
    def make(nb,nt,a,j,y):
        if y in (0,ones) or y in s:return
        for keepA in (False,True):
            for keepJ in ((False,True) if j is not None else (True,)):
                w=tuple(sorted([x for x in s if (x!=a or keepA) and (x!=j or keepJ)]+[y]))
                yield (nb,nt,w)
    if t:
        for a in s:yield from make(b,t-1,a,None,ones^a)
    if b:
        for a in s:
            for j in s:
                if j<a:
                    for y in (a&j,a|j):yield from make(b-1,t,a,j,y)

raw=tuple(sorted(sum(1<<p for p in range(18) if i in (p//6,3+p%6)) for i in range(9)))
root=(9,0,raw);found=set()
def walk(k):
 if k in found or code(*k) is not None:return
 assert target not in k[2]
 found.add(k)
 if len(found)>3000:raise RuntimeError('bounded ledger pilot stopped')
 for c in children(*k):walk(c)
walk(root)
ordered=sorted(found,key=lambda k:(k[0],k));where.update({k:i for i,k in enumerate(ordered)})
code.cache_clear()
with open('ledger.jsonl','w') as f:
 for k in ordered:
  ws=[code(*c) for c in children(*k)];assert None not in ws
  print(json.dumps([k,ws],separators=(',',':')),file=f)
print('states',len(ordered),'root witness',code(*root),'bytes',Path('ledger.jsonl').stat().st_size)
