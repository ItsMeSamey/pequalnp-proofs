from pathlib import Path
import json
rows=[json.loads(s) for s in Path('ledger.jsonl').read_text().splitlines()]
fmt=lambda xs:'['+','.join(map(str,xs))+']'
def key(k):
 b,t,s=k
 return f'({b},{t},{fmt(s)})'
ns='namespace NumericM13175\nset_option maxRecDepth 200000\nset_option maxHeartbeats 0\n'
clusters=range(0,len(rows),16)
with open('M13175Table.lean','w') as f:
 f.write('import TableFastSupportM13175\nimport NumericM13175Closure\n'+ns)
 for t in clusters:
  f.write(f'def group{t} : Nat → Key\n')
  for j,(k,w) in enumerate(rows[t:t+16]):f.write(f'  | {j} => {key(k)}\n')
  f.write('  | _ => (0,0,[])\n')
 def bst(starts):
  if len(starts)==1:
   i=starts[0];return f'group{i} (n-{i})'
  ix=len(starts)//2
  return f'(if n < {starts[ix]} then {bst(starts[:ix])} else {bst(starts[ix:])})'
 f.write(f'def fastKey (n : Nat) := {bst(list(clusters))}\n')
 n=len(rows)
 f.write(f'def table : Array Key := Array.ofFn (fun i : Fin {n} => fastKey i.val)\ndef atKey (i : Nat) : Option Key := if i < {n} then some (fastKey i) else none\ntheorem table_at (i : Nat) : table[i]? = atKey i := by\n  by_cases hi : i < {n} <;> simp [table, atKey, hi]\nend NumericM13175\n')
for t in clusters:
 with open(f'M13175Rows{t}.lean','w') as f:
  f.write('import M13175Table\n'+ns)
  for j,(k,w) in enumerate(rows[t:t+16],t):
   f.write(f'def proof{j} : List Nat := {fmt(w)}\ntheorem row{j} : checkRow table {j} proof{j} = true := by rw [rowWith_eq table_at, rowWith_eval]; decide +kernel\n')
  f.write('end NumericM13175\n')
with open('M13175Final.lean','w') as f:
 f.write('import RootM13175\n'+''.join(f'import M13175Rows{i}\n' for i in clusters)+ns)
 for t in clusters:
  stop=min(len(rows),t+16)
  f.write(f'private theorem block{t} (p{t} : Covered table {t}) : Covered table {stop} := by\n')
  for j in range(t,stop):f.write(f'  have p{j+1} : Covered table {j+1} := covered_succ p{j} row{j}\n')
  f.write(f'  exact p{stop}\n')
 f.write(f'theorem coverage : Covered table table.size := by\n  have len : table.size = {len(rows)} := by simp [table]\n  rw [len]\n  have q0 := covered_zero table\n')
 for t in clusters:
  stop=min(len(rows),t+16)
  f.write(f'  have q{stop} := block{t} q{t}\n')
 f.write(f'  exact q{len(rows)}\n')
 f.write(f'theorem root : checkChild table (9,0,start) {2*(len(rows)-1)} = true := by rw [childWith_eq table_at]; decide +kernel\nend NumericM13175\n')
 f.write('theorem offered13175_refuted : ¬ PEqualNP.Represents.RepSizeAtMost ProbeM13175.matrix 9 := ProbeM13175.refute_of_ledger NumericM13175.coverage ⟨_,NumericM13175.root⟩\n')
