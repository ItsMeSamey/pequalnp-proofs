#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <unordered_map>
#include <vector>
using namespace std;using Row=array<int,5>;using Key=uint64_t;
struct Catalog{
 int d,c;unordered_map<Key,int> memo;
 explicit Catalog(int depth):d(depth),c(6-d){}
 Key pack(const Row&t){Key k=0;for(int i=0;i<d;i++)k=k*4096+t[i];return k;}
 Row unpack(Key k){Row t{};for(int i=d-1;i>=0;i--){t[i]=k%4096;k/=4096;}return t;}
 int cost(const Row&t){
  vector<int> req;for(int i=0;i<d;i++)if(popcount((unsigned)t[i])>1)req.push_back(t[i]);
  sort(req.begin(),req.end());req.erase(unique(req.begin(),req.end()),req.end());if(req.size()>4)return 5;
  Key shape=0;for(int i=0;i<12;i++){int m=0;for(int j=0;j<(int)req.size();j++)if(req[j]&(1<<i))m|=1<<j;if(m)shape+=Key(1)<<(4*(m-1));}
  auto it=memo.find(shape);if(it!=memo.end())return it->second;
  vector<int> extra;for(int h:req)for(int s=(h-1)&h;s;s=(s-1)&h)if(popcount((unsigned)s)>1&&!binary_search(req.begin(),req.end(),s))extra.push_back(s);
  sort(extra.begin(),extra.end());extra.erase(unique(extra.begin(),extra.end()),extra.end());
  vector<int> chosen;
  auto ok=[&](){
   vector<int> joins=req;joins.insert(joins.end(),chosen.begin(),chosen.end());sort(joins.begin(),joins.end(),[](int a,int b){return popcount((unsigned)a)<popcount((unsigned)b);});
   vector<int> bank;for(int i=0;i<12;i++)bank.push_back(1<<i);
   for(int m:joins){bool found=false;for(int a:bank)if(!(a&~m))for(int b:bank)if((a|b)==m){found=true;break;}if(!found)return false;bank.push_back(m);}return true;};
  auto dfs=[&](auto&&self,int i,int k)->bool{if(k==0)return ok();for(;i+k<=(int)extra.size();i++){chosen.push_back(extra[i]);if(self(self,i+1,k-1))return true;chosen.pop_back();}return false;};
  for(int n=req.size();n<=4;n++)if(dfs(dfs,0,n-req.size()))return memo[shape]=n;return memo[shape]=5;
 }
 Key swapped(const Row&t,int j){
  int perm[5]={0,1,2,3,4};swap(perm[j],perm[j+1]);int cols[6]{};
  for(int h=0;h<6;h++){int a=0,b=0,axis=h<c?h:c+perm[h-c];for(int i=0;i<d;i++){int n=(t[perm[i]]>>(2*axis))&3;a=4*a+n;b=4*b+(n==1?2:n==2?1:n);}cols[h]=min(a,b);}
  sort(cols,cols+c);Row r{};for(int h=0;h<6;h++)for(int i=0;i<d;i++)r[i]|=((cols[h]>>(2*(d-1-i)))&3)<<(2*h);return pack(r);
 }
 void main(){
  vector<Key> keys;Row t{};long long rejected=0;
  while(cin>>t[0]){for(int j=1;j<d;j++)cin>>t[j];if(cost(t)>4)rejected++;else keys.push_back(pack(t));}
  sort(keys.begin(),keys.end());if(adjacent_find(keys.begin(),keys.end())!=keys.end())abort();
  vector<int> par(keys.size());iota(par.begin(),par.end(),0);auto root=[&](int i){while(par[i]!=i){par[i]=par[par[i]];i=par[i];}return i;};
  for(int i=0;i<(int)keys.size();i++){t=unpack(keys[i]);for(int j=0;j<d-1;j++)if(!((t[j]>>(2*(c+j+1)))&3)){
   auto k=swapped(t,j);auto it=lower_bound(keys.begin(),keys.end(),k);if(it==keys.end()||*it!=k)abort();int a=root(i),b=root(it-keys.begin());if(a!=b)par[max(a,b)]=min(a,b);}}
  vector<int> cnt(keys.size());for(int i=0;i<(int)keys.size();i++)cnt[root(i)]++;
  array<int,6> categories{};for(int i=0;i<(int)keys.size();i++)if(cnt[i]){
   t=unpack(keys[i]);int n=cost(t);categories[n]++;for(int j=0;j<d;j++)cout<<t[j]<<' ';cout<<n<<' '<<cnt[i]<<'\n';}
  cerr<<"valid "<<keys.size()<<" excluded "<<rejected<<" orbits";for(int j:categories)cerr<<' '<<j;cerr<<'\n';
 }
};
int main(int argc,char**argv){ios::sync_with_stdio(false);cin.tie(nullptr);Catalog c(atoi(argv[1]));c.main();}
