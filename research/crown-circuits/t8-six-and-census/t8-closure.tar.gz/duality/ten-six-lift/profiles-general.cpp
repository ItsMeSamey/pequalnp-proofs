#include <algorithm>
#include <array>
#include <bit>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
struct Enumerate{
 int d,c;array<int,6> t{};vector<vector<vector<int>>> orbit;long long kept=0;
 explicit Enumerate(int depth):d(depth),c(6-d),orbit(6){
  for(int a=0;a<6;a++){
   int digits=a<c?d:a-c,base=a<c?3:4,n=1;for(int j=0;j<digits;j++)n*=base;
   for(int code=0;code<n;code++){
    vector<int>x(d);int v=code;for(int j=0;j<digits;j++){x[j]=v%base;v/=base;}
    auto y=x;for(int& a:y)if(a==1||a==2)a=3-a;
    if(x<=y)orbit[a].push_back(x);
   }sort(orbit[a].begin(),orbit[a].end());
  }
 }
 bool rank_ok()const{
  int groups[6]={},ng=0;
  for(int j=0;j<d;j++){
   int m=t[j];if(!m)continue;
   for(int k=0;k<ng;)if(m&groups[k]){m|=groups[k];groups[k]=groups[--ng];}else{k++;}
   groups[ng++]=m;
  }
  int rank=0;for(int k=0;k<ng;k++)rank+=popcount((unsigned)groups[k])-1;
  return rank<=4;
 }
 void run(int a,int lo){
  if(a==6){
   for(int j=0;j<d;j++){
    int v=t[j]; if(!v)return;
    for(int k=0;k<d;k++)if(((v>>(2*(k+c)))&3)==3)v|=t[k];
    if(v&(v>>1)&(((1<<(2*c))-1)/3))return;
   }
   for(int j=0;j<d;j++){if(j)cout<<' ';cout<<t[j];}cout<<'\n';kept++;return;
  }
  for(int h=lo;h<(int)orbit[a].size();h++){
   auto old=t;for(int j=0;j<d;j++)t[j]|=orbit[a][h][j]<<(2*a);
   if(rank_ok())run(a+1,a+1<c?h:0);
   t=old;
  }
 }
};
int main(int argc,char**argv){Enumerate e(atoi(argv[1]));e.run(0,0);cerr<<"rank-surviving "<<e.kept<<"\n";}
