from pathlib import Path
import sys
p=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve()
if out == p:
    raise SystemExit('Choose a separate output directory for the sharded sources.')
out.mkdir(parents=True,exist_ok=True)
s=(p/'t8-dirty-exact.cpp').read_text()
for a,b in [
 ('struct Search {','int root_modulus=1, root_residue=0;\nstruct Search {'),
 ('  banks++;','  if(!helpers.empty() || root_residue==0)banks++;'),
 ('  if(all_of(target.begin()', '  if((!helpers.empty() || root_residue==0) && all_of(target.begin()'),
 ('  set<array<int,6>> seen;', '  int rootOrdinal=0; set<array<int,6>> seen;'),
 ('   bank.push_back(m);helpers.push_back(m);if(run(key[m]))','   if(helpers.empty() && rootOrdinal++%root_modulus!=root_residue)continue;\n   bank.push_back(m);helpers.push_back(m);if(run(key[m]))')]:
 assert s.count(a)==1
 s=s.replace(a,b)
(out/'t8-dirty-exact.cpp').write_text(s)
s=(p/'t8-seeded.cpp').read_text().replace('int d=atoi(argv[1]);string l;','int d=atoi(argv[1]);root_modulus=atoi(argv[2]);root_residue=atoi(argv[3]);assert(root_modulus>0 && root_residue>=0 && root_residue<root_modulus);string l;').replace('assert(cost>=0&&cost<=4)','assert(cost==0)')
(out/'t8-seeded.cpp').write_text(s)
