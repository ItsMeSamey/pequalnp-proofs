from itertools import permutations
def canon(t):
 d=len(t);c=6-d;flip=(0,2,1,3);best=None
 for perm in permutations(range(d)):
  out=[0]*d
  cols=[tuple((t[i]>>(2*j))&3 for i in perm) for j in range(c)]
  cols=sorted(min(x,tuple(flip[b] for b in x)) for x in cols)
  for j,col in enumerate(cols):
   for k,b in enumerate(col):out[k]|=b<<(2*j)
  for new,old in enumerate(perm):
   col=tuple((t[i]>>(2*(c+old)))&3 for i in perm)
   if any(col[new:]):break
   for k,b in enumerate(min(col,tuple(flip[b] for b in col))):out[k]|=b<<(2*(c+new))
  else:
   a=tuple(out)
   if best is None or a<best:best=a
 return best
if __name__=='__main__':
 from pathlib import Path
 from collections import defaultdict
 p=Path(__file__).parent; groups=defaultdict(list)
 rows=[tuple(map(int,l.split()[:3])) for l in (p/'t8-three-mandatory.tsv').read_text().splitlines() if l.endswith(' 0')]
 for i,t in enumerate(rows):groups[canon(t)].append(i)
 print(list(groups.values()))
