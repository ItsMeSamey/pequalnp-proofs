from functools import lru_cache
from itertools import combinations,permutations
from pathlib import Path
from collections import Counter
root=Path(__file__).parent
def shape(ts):
 return min(tuple(sorted(sum(1<<i for i,m in enumerate(t) if m>>b&1) for b in range(12) if any(m>>b&1 for m in t))) for t in permutations(ts))
@lru_cache(None)
def mincost(s):
 ts={sum(1<<i for i,v in enumerate(s) if v>>j&1) for j in range(3)}
 req={t for t in ts if t.bit_count()>1}
 sub=set()
 for m in req:
  a=m
  while a:
   if a.bit_count()>1:sub.add(a)
   a=(a-1)&m
 extra=sorted(sub-req)
 for k in range(len(req),5):
  for extra_set in combinations(extra,k-len(req)):
   bank={1<<i for i in range(len(s))}
   for m in sorted(req|set(extra_set),key=lambda x:x.bit_count()):
    under=[x for x in bank if not x&~m]
    if not any(x|y==m for x,y in combinations(under,2)):break
    bank.add(m)
   else:return k
 return 5
def main():
 counts=Counter()
 with (root/'t8-three-mandatory.tsv').open('w') as out:
  for line in (root/'t8-three-rank.tsv').read_text().splitlines():
   c=mincost(shape(tuple(map(int,line.split()))));counts[c]+=1
   if c<=4:print(line,c,file=out)
 print('mandatory',sorted(counts.items()),'shapes',mincost.cache_info())
if __name__=='__main__':main()
