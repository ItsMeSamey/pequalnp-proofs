"""Check archived coverage, or reconstruct catalogs and replay one complete stratum."""
import argparse
from collections import Counter
import gzip
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile

P = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--replay", type=int, choices=range(1, 6))
args = parser.parse_args()
canon = runpy.run_path(str(P / "dirty-permute.py"))["canon"]

def rows(path):
    with (gzip.open(path, "rt") if path.suffix == ".gz" else path.open()) as f:
        return [r.split() for r in f if r.strip()]

def run(*argv, **kw):
    return subprocess.run(list(map(str, argv)), check=True, text=True, **kw)

def output(*argv):
    return run(*argv, capture_output=True).stdout.splitlines()

one = [line.strip() for name in ("one-dirty-width1.log", "one-dirty-width2-5.log")
       for line in (P/name).read_text().splitlines() if line.startswith("hit")]
assert len(one) == 5 and all(line.startswith("hit 0 ") for line in one)
two = rows(P/"t8-two-exact-ledger.tsv")[1:]
assert len(two) == len({tuple(r[:2]) for r in two}) == 156
assert {tuple(r[:2]) for r in two} == {tuple(r) for r in rows(P/"t8-two-profiles.tsv")}
three = rows(P/"t8-three-exact-ledger.tsv")[1:]
assert len(three) == len({tuple(r[:3]) for r in three}) == 4212
assert {tuple(r[:4]) for r in three} == {tuple(r) for r in rows(P/"t8-three-mandatory.tsv")}
direct = {tuple(r[:3]) for r in three if r[4] == "exact"}
assert len(direct) == 4201
for r in three:
    if r[4] == "exact":
        assert r[:3] == r[5:8]
    else:
        assert r[4] == "permutation" and tuple(r[5:8]) in direct
        assert canon(tuple(map(int, r[:3]))) == canon(tuple(map(int, r[5:8])))
high = {}
for d,counts,total,work in [(4,(34,294,1696,6777,19339),83927,(37981446,3193921)),
                            (5,(60,687,4861,24174,87038),510294,(98290268,1360672))]:
    tab = rows(P/f"t8-{d}-profile-ledger.tsv.gz")[1:]
    assert len({tuple(r[:d]) for r in tab}) == len(tab)
    assert tuple(Counter(int(r[d]) for r in tab)[k] for k in range(5)) == counts
    assert sum(int(r[d+1]) for r in tab) == total
    assert all(r[d+2] == "exact" for r in tab)
    assert tuple(sum(int(r[-i]) for r in tab) for i in (2,1)) == work
    high[d] = tab
print("Frozen ledgers and the eleven signed aliases check.", flush=True)
if args.replay is None:
    sys.exit(0)
d=args.replay
with tempfile.TemporaryDirectory(prefix="threshold-eight-") as name:
    temp=Path(name)
    def build(src):
        exe=temp/src
        run("c++","-std=c++20","-O3",P/(src+".cpp"),"-o",exe)
        return exe
    def regen(script,names):
        shutil.copy(P/script,temp/script)
        run(sys.executable,temp/script)
        for n in names:
            assert (temp/n).read_bytes() == (P/n).read_bytes(), n
    if d == 1:
        exe=build("t8-one-dirty")
        for w,line in enumerate(one,1):
            assert output(exe,w,6)==[line]
    elif d == 2:
        regen("t8-two-profiles.py",["t8-two-profiles.tsv"])
        exe=build("t8-two-exact")
        for w,q,b,f in two:
            assert output(exe,w,q)==[f"W {w} Q {q} valid 1 hit 0 banks {b} fronts {f}"]
    elif d == 3:
        regen("three-profiles.py",["t8-three-profiles.tsv","t8-three-rank.tsv"])
        regen("mandatory.py",["t8-three-mandatory.tsv"])
        exe=build("t8-dirty-exact")
        for r in three:
            if r[4]=="exact":
                expected=" ".join(r[:3]+["valid","1","hit","0","banks",r[-2],"fronts",r[-1]])
                assert output(exe,*r[:3])==[expected]
    else:
        profiles=build("profiles-general")
        partition=build("large-partition")
        with (temp/"rank").open("w") as f:
            run(profiles,d,stdout=f)
        with (temp/"rank").open() as f, (temp/"orbits").open("w") as g:
            run(partition,d,stdin=f,stdout=g)
        catalog=rows(temp/"orbits")
        assert catalog == [r[:d+2] for r in high[d]]
        for costs,src in [({4},"t8-fixed"),({0,1,2,3},"t8-seeded")]:
            exe=build(src)
            selected=[r for r in high[d] if int(r[d]) in costs]
            with (temp/"input").open("w") as f:
                for r in selected:
                    print(*r[:d+2],file=f)
            with (temp/"input").open() as f,(temp/"receipts").open("w") as g:
                run(exe,d,stdin=f,stdout=g)
            receipts=rows(temp/"receipts")
            assert len(receipts)==len(selected)
            for r,line in zip(selected,receipts):
                assert line==r[:d]+["valid","1","hit","0","banks",r[-2],"fronts",r[-1]]
print("Completed deterministic replay at hot count",d)
