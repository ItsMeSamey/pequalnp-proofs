# Ten-variable threshold two at 24 gates and six ANDs

In clean-terminal form, any such circuit must have at least two dirty ANDs. A dirty AND is true on some singleton input. The independent nine-variable minor with 21 gates and five ANDs has the same restriction.

These are profile exclusions. They do not give a six-AND circuit or settle its unrestricted existence. They use the existing proofs of minimum sizes 19, 21, and 24 on eight, nine, and ten inputs.

## Replaying the finite cases

The raw-to-pin transpose and its helper budget are explained in `../../algebra/tenseven/README.md` and `../../algebra/tenseven/one-dirty.md`. The same proofs apply at the lower AND counts. At ten inputs and size 24 there are at most five helper joins beyond the final receiver joins; at nine inputs and size 21 there are at most four. The total number of transposed joins is size minus inputs plus one. With a single dirty gate, its activation mask W must also be available from the bank. Widths of W range from one to the number of clean terminals.

A direct receiver is a terminal pin. It cannot be a dirty pin or a clean pin fed from W. Removing its label saves a clean terminal AND, a collector OR, and the maximum signal on the opposite arm. Tightness of the size bound preserves the other ANDs. At ten this reduces the problem to nine inputs and five ANDs with at most one dirty gate. At nine it produces a circuit with at most 18 gates on eight inputs, contrary to their minimum 19. Thus the two arities of nondirect receiver search suffice.

    c++ -std=c++20 -O2 six.cpp -o six
    ./six
    c++ -std=c++20 -O2 nineclean.cpp -o nineclean
    ./nineclean
    c++ -std=c++20 -O2 onedirty.cpp -o onedirty
    for d in 5 6; do for ((w=1; w<d; w++)); do ./onedirty "$w" "$d"; done; done

The all-clean runs visited 30,481 and 1,252 banks at ten and nine inputs, respectively. The one-dirty runs at ten visited 506,158, 73,977, 12,520, 2,152, and 885 banks by width. At nine they visited 18,246, 2,862, 443, and 93 banks. All returned zero candidates.

The separate `small-incidence.md` proves an unrestricted-tail OR bound for simple incidence hosts. The optional two-dirty random bank search in `twodirty.cpp` tested 36,207 five-helper libraries; it is a sample only.

## Physical construction searches

The four- and five-AND 24-gate controls were placed in 48 topological orders. Every replacement of two gates by fresh binary operations on earlier wires was tested subject to the six-AND target. Downstream Boolean cofactors ruled out incompatible positions, and 523,750,022 compatible second replacements were evaluated. No exact circuit appeared. The supplied `seeds` file is sufficient for direct replay with `twogate.cpp`.

A separate randomized scan of 19,200 proposed topologies kept 317 live candidates satisfying the known normalization of 20 raw pins all entering ORs. Each of these was tested with arbitrary pairing of the pins into ten labels, independent of control-label identities. Short certificates excluded 252, insufficient minimal certificates excluded 48, and exact pairing excluded the other 17. The input permutation domain was completely searched for each of these 317 topologies.

## Preservation at the absolute minimum

At the established absolute minimum of 24 gates, collection preserves the number of AND gates and the number of dirty ANDs. A gate ANDing a singleton-negative signal with anything else can be bypassed by keeping that negative signal. Every singleton wire value is unchanged, and all positives remain accepted by monotonicity, contradicting minimality. At a mixed OR H=C∨D whose C is singleton-negative and D is singleton-positive, redirect every use of H to D and append a terminal OR of C with the previous output. When C is false, the run is unchanged; when C is true, the input has at least two true bits and must be accepted. Singleton values remain unchanged at every retained gate. This trades one OR for one OR, and an additional dead gate would contradict minimality. Each step removes a mixed OR and introduces a clean output OR. Finally all clean AND outputs feed only the clean OR collector; compacting that collector cannot lose any AND or reduce the minimum size. Thus the two-dirty necessary condition also applies before collection.
