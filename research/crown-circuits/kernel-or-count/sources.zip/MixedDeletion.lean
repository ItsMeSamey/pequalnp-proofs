import ParentRestriction
namespace FreeAndNet
theorem sensitive_has_hit {α : Type} [DecidableEq α] (t : Net α) (b : α)
    (positive : ∃ w : α → Bool, w b = false ∧ t.eval w = true)
    (flip : ∃ x y : α → Bool, (∀ j, j ≠ b → x j = y j) ∧ t.eval x ≠ t.eval y) :
    0 < hits b t := by
  obtain ⟨w,off,yes⟩ := positive
  obtain ⟨x,y,agree,ne⟩ := flip
  by_contra! h
  apply ne
  apply eval_congr_used
  intro j used
  by_cases same : j=b
  · subst j
    rcases used with hit | out
    · omega
    · have zero := outZeros t b out w off
      simp_all
  · exact agree j same

theorem erase_two_saves_hits {α : Type} [DecidableEq α] (t : Net α) (a b : α)
    (positive : ∃ w : α → Bool, w a = false ∧ w b = false ∧ t.eval w = true)
    (flip : ∃ x y : α → Bool, x a = false ∧ y a = false ∧
      (∀ j, j ≠ b → x j = y j) ∧ t.eval x ≠ t.eval y) :
    ∃ u : Net α, u.cost + hits a t + 1 ≤ t.cost ∧
      ∀ v, v a = false → v b = false → u.eval v = t.eval v := by
  let s := specialize (eraseInput a) t
  have keep (v : α → Bool) (off : v a = false) : s.eval v = t.eval v :=
    eval_eraseInput t a v off
  have active : 0 < hits b s := by
    apply sensitive_has_hit
    · obtain ⟨w,offa,offb,yes⟩ := positive
      exact ⟨w,offb,(keep w offa).trans yes⟩
    · obtain ⟨x,y,offx,offy,eq,ne⟩ := flip
      exact ⟨x,y,eq,by rwa [keep x offx,keep y offy]⟩
  have first : s.cost + hits a t ≤ t.cost := specialize_saves a (eraseInput a) (by simp [eraseInput]) t
  have second := specialize_saves b (eraseInput b) (by simp [eraseInput]) s
  refine ⟨specialize (eraseInput b) s, by omega,?_⟩
  intro v va vb
  exact (eval_eraseInput s b v vb).trans (keep v va)
end FreeAndNet
