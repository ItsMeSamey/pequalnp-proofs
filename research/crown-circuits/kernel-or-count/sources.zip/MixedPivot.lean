import CrownMixed
namespace CrownMixed
open FreeAndNet
def IsName {I α : Type} (N : Naming I α) (i : I) (x : α) : Prop :=
  N.row i = x ∨ N.col i = x
theorem name_separate {I α : Type} (N : Naming I α) {i j : I} {x y : α}
    (hx : IsName N i x) (hy : IsName N j y) (hne : i ≠ j) : x ≠ y := by
  rintro rfl
  rcases hx with h|h <;> rcases hy with k|k
  · exact hne (N.row_inj (h.trans k.symm))
  · exact hne (N.same (h.trans k.symm))
  · exact hne (N.same (k.trans h.symm)).symm
  · exact hne (N.col_inj (h.trans k.symm))
theorem outside_two {I : Type} [Fintype I] [DecidableEq I]
    (size : 3 ≤ Fintype.card I) (i j : I) : ∃ k, k ≠ i ∧ k ≠ j := by
  classical
  by_contra! h
  have sub : (Finset.univ : Finset I) ⊆ {i,j} := by
    intro k _
    by_cases hi : k=i
    · simp [hi]
    · simp [h k hi]
  have ub := Finset.card_le_card sub
  have bound : ({i,j} : Finset I).card ≤ 2 := by
    simpa using Finset.card_insert_le i ({j} : Finset I)
  simp only [Finset.card_univ] at ub
  omega
private theorem all_mono {α : Type} (l : List α) (u v : α → Bool)
    (h : ∀ i, u i = true → v i = true) : l.all u = true → l.all v = true :=
  fun x => List.all_eq_true.mpr (fun i hi => h i (List.all_eq_true.mp x i hi))

private theorem net_mono {α : Type} (t : Net α) (u v : α → Bool)
    (h : ∀ i, u i = true → v i = true) : t.eval u = true → t.eval v = true := by
  induction t with
  | out p =>
    cases p with
    | none => simp [Net.eval,pval]
    | some l => exact all_mono l u v h
  | gate a b t ih =>
    apply ih
    intro z
    cases z with
    | some i => exact h i
    | none =>
      change a.all u || b.all u = true → a.all v || b.all v = true
      intro e
      rcases Bool.or_eq_true_iff.mp e with hh|hh
      · exact Bool.or_eq_true_iff.mpr (.inl (all_mono a _ _ h hh))
      · exact Bool.or_eq_true_iff.mpr (.inr (all_mono b _ _ h hh))

theorem singleton_cold {I α : Type} [DecidableEq I] [DecidableEq α]
    (N : Naming I α) (t : Net α) (rep : N.Rep t) {i : I} {x : α} (hx : IsName N i x) :
    t.eval (fun q => decide (q=x)) = false := by
  cases he : t.eval (fun q => decide (q=x)) with
  | false => rfl
  | true =>
    have hot := net_mono t _ (N.val i i) (fun j hj => by
      simp only [decide_eq_true_eq] at hj
      subst j
      rcases hx with h|h <;> simp [Naming.val,← h]) he
    simp [rep i i] at hot

theorem mixed_pivot {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]
    (N : Naming I α) (t : Net α) (rep : N.Rep t) (size : 3 ≤ Fintype.card I)
    {i j : I} {x y : α} (hx : IsName N i x) (hy : IsName N j y) :
    ∃ v w : α → Bool, v y = false ∧ (∀ q, q ≠ x → v q = w q) ∧ t.eval v ≠ t.eval w := by
  obtain ⟨k,ki,kj⟩ := outside_two size i j
  rcases hx with rfl|rfl
  · have off := name_separate N (.inr (rfl : N.col k = _)) hy kj
    refine ⟨fun q => decide (q=N.col k), N.val i k, by simp [Ne.symm off], ?_, ?_⟩
    · intro q hq; simp [Naming.val,hq]
    · rw [singleton_cold N t rep (.inr (rfl : N.col k = _)), rep]
      simp [Ne.symm ki]
  · have off := name_separate N (.inl (rfl : N.row k = _)) hy kj
    refine ⟨fun q => decide (q=N.row k), N.val k i, by simp [Ne.symm off], ?_, ?_⟩
    · intro q hq; simp [Naming.val,hq]
    · rw [singleton_cold N t rep (.inl (rfl : N.row k = _)), rep]
      simp [ki]
theorem named_no_output {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]
    (N : Naming I α) (t : Net α) (rep : N.Rep t) (size : 3 ≤ Fintype.card I)
    {i : I} {x : α} (hx : IsName N i x) : ¬outUses x t := by
  obtain ⟨j,ji,_⟩ := outside_two size i i
  obtain ⟨k,ki,kj⟩ := outside_two size i j
  intro used
  have off₁ := name_separate N hx (.inl (rfl : N.row j = _)) ji.symm
  have off₂ := name_separate N hx (.inr (rfl : N.col k = _)) ki.symm
  have cold := outZeros t x used (N.val j k) (by simp [Naming.val,off₁,off₂])
  simp [rep j k,kj.symm] at cold
end CrownMixed
