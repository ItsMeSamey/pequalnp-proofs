import ThreeCrownFour
import Research.FreeAndNet
import Mathlib.Data.List.Basic
import Mathlib.Tactic.FinCases
import Mathlib.Data.Fintype.Fin

namespace ParentCrown
open FreeAndNet

abbrev Word := BitVec 9
abbrev Sel := BitVec 10

def inputMask (i : Fin 6) : Word := ([7,56,448,73,146,292] : List Word).getD i.val 0

def meet : List Word → Word := List.foldr (· &&& ·) 511

def NetTable {α : Type} (v : α → Word) : Net α → Word
  | .out p => p.elim 0 (fun xs => meet (xs.map v))
  | .gate l r t => NetTable (fun i => i.elim (meet (l.map v) ||| meet (r.map v)) v) t

def pinAt (p : List Word) (s : Sel) : Word :=
  pin s (p.getD 0 0) (p.getD 1 0) (p.getD 2 0) (p.getD 3 0)

def Encoded (p : List Word) (v : Word) : Prop :=
  ∃ s : Sel, ∀ a b c d : Word, p <+: [a,b,c,d] → pin s a b c d = v

private theorem pin_zero (a b c d : Word) : pin 3 a b c d = 0 := by simp [pin]
private theorem pin_all (a b c d : Word) : pin 0 a b c d = 511 := by simp [pin]

private theorem mask_and (w : Word) : 511#9 &&& w = w := by
  apply BitVec.eq_of_getLsbD_eq
  intro i hi
  have one : (511#9).getLsbD i = true :=
    (BitVec.getLsbD_allOnes (v:=9) (i:=i)).trans (decide_eq_true hi)
  rw [BitVec.getLsbD_and,one,Bool.true_and]

private theorem and_mask (w : Word) : w &&& 511#9 = w :=
  (BitVec.and_comm w 511).trans (mask_and w)

private theorem enc_meet (s t : Sel) (a b c d : Word) :
    pin (s ||| t) a b c d = pin s a b c d &&& pin t a b c d := by
  have factor (i : Nat) (w : Word) :
      (if (s ||| t).getLsbD i then w else 511) =
      (if s.getLsbD i then w else 511) &&& (if t.getLsbD i then w else 511) := by
    rw [BitVec.getLsbD_or]
    cases s.getLsbD i <;> cases t.getLsbD i <;> simp
    · exact (mask_and w).symm
    · exact (and_mask w).symm
  unfold pin
  simp only [factor]
  ac_rfl

private theorem enc_list {α} {p : List Word} {v : α → Word} (all : ∀ i, Encoded p (v i))
    (xs : List α) : Encoded p (meet (xs.map v)) := by
  induction xs with
  | nil => exact ⟨0,by intros; exact pin_all ..⟩
  | cons x xs ih =>
    obtain ⟨l,hl⟩ := all x
    obtain ⟨r,hr⟩ := ih
    exact ⟨l ||| r,fun a b c d hp => by rw [enc_meet,hl _ _ _ _ hp,hr _ _ _ _ hp]; rfl⟩

theorem enc_mono {p q : List Word} {v : Word} (h : Encoded p v) (hp : p <+: q) :
    Encoded q v := by
  obtain ⟨s,hs⟩ := h
  exact ⟨s,fun _ _ _ _ e => hs _ _ _ _ (hp.trans e)⟩

theorem pin_raw (i : Fin 6) (a b c d : Word) :
    pin (BitVec.ofNat 10 (2^i.val)) a b c d = inputMask i := by
  fin_cases i <;> simp [pin,inputMask,List.getD_eq_getElem?_getD]

theorem enc_raw (i : Fin 6) : Encoded [] (inputMask i) :=
  ⟨_, fun _ _ _ _ _ => pin_raw i _ _ _ _⟩

private theorem pin_single (i : Fin 4) (a b c d : Word) :
    pin (BitVec.ofNat 10 (2^(6+i.val))) a b c d = [a,b,c,d].getD i.val 0 := by
  fin_cases i <;> simp [pin,List.getD_eq_getElem?_getD] <;> simp only [mask_and,and_mask]

private theorem emb_prefix {p q : List Word} (pre : p <+: q) (i : Nat) (lt : i < p.length) :
    q.getD i 0 = p.getD i 0 := by
  obtain ⟨s,rfl⟩ := pre
  simp only [List.getD_eq_getElem?_getD,List.getElem?_append_left lt]

theorem enc_new (p : List Word) (g : Word) (h : p.length < 4) :
    Encoded (p++[g]) g := by
  refine ⟨BitVec.ofNat 10 (2^(6+p.length)),fun a b c d hp => ?_⟩
  rw [pin_single ⟨p.length,h⟩ a b c d]
  rw [emb_prefix hp _ (by simp)]
  simp [List.getD_eq_getElem?_getD]

private theorem enc_eval {p : List Word} (h : p.length ≤ 4) {v : Word} (e : Encoded p v) :
    ∃ s, pinAt p s = v := by
  obtain ⟨s,hs⟩ := e
  refine ⟨s,hs _ _ _ _ ?_⟩
  rcases p with _ | ⟨a,p⟩ <;> simp
  rcases p with _ | ⟨b,p⟩ <;> simp
  rcases p with _ | ⟨c,p⟩ <;> simp
  rcases p with _ | ⟨d,p⟩ <;> simp
  cases p <;> simp_all

inductive Run : List Word → Prop
  | start : Run []
  | step {p} (h : Run p) (l r : Sel) : Run (p ++ [pinAt p l ||| pinAt p r])

theorem run_of_net {α} (t : Net α) (p : List Word) (v : α → Word)
    (run : Run p) (fits : ∀ i, Encoded p (v i)) (h : p.length + t.cost ≤ 4) :
    ∃ q, Run q ∧ q.length ≤ 4 ∧ ∃ s, pinAt q s = NetTable v t := by
  induction t generalizing p with
  | out xs =>
    refine ⟨p,run,h,enc_eval h ?_⟩
    cases xs with
    | none => exact ⟨3,by intros; exact pin_zero ..⟩
    | some l => exact enc_list fits l
  | gate l r t ih =>
    obtain ⟨ls,le⟩ := enc_eval (by omega : p.length ≤ 4) (enc_list fits l)
    obtain ⟨rs,re⟩ := enc_eval (by omega : p.length ≤ 4) (enc_list fits r)
    have room := h
    change p.length + (t.cost + 1) ≤ 4 at room
    let val := meet (l.map v) ||| meet (r.map v)
    apply ih (p ++ [val]) (fun i => i.elim val v)
    · simpa only [le,re,val] using Run.step run ls rs
    · intro i
      cases i with
      | none => exact enc_new p val (by omega)
      | some j => exact enc_mono (fits j) ⟨[val],rfl⟩
    · simp; omega

theorem run_not_crown {p : List Word} (r : Run p) (h : p.length ≤ 4) (s : Sel) :
    pinAt p s ≠ 238 := by
  cases r with
  | start =>
    have z := three_crown_four_or 3 3 3 3 3 3 3 3 s
    simp only [pin_zero, BitVec.or_self] at z
    simpa [pinAt,List.getD_eq_getElem?_getD] using z
  | step r a3 b3 =>
    cases r with
    | start =>
      have z := three_crown_four_or a3 b3 3 3 3 3 3 3 s
      simp only [pin_zero, BitVec.or_self] at z
      simpa [pinAt,List.getD_eq_getElem?_getD] using z
    | step r a2 b2 =>
      cases r with
      | start =>
        have z := three_crown_four_or a2 b2 a3 b3 3 3 3 3 s
        simp only [pin_zero, BitVec.or_self] at z
        simpa [pinAt,List.getD_eq_getElem?_getD] using z
      | step r a1 b1 =>
        cases r with
        | start =>
          have z := three_crown_four_or a1 b1 a2 b2 a3 b3 3 3 s
          simp only [pin_zero, BitVec.or_self] at z
          simpa [pinAt,List.getD_eq_getElem?_getD] using z
        | step r a0 b0 =>
          cases r with
          | start =>
            have z := three_crown_four_or a0 b0 a1 b1 a2 b2 a3 b3 s
            simpa [pinAt,List.getD_eq_getElem?_getD] using z
          | step => simp at h

theorem three_crown_five_general {α : Type} (t : Net α) (v : α → Word)
    (base : ∀ i, v i = 0 ∨ ∃ j : Fin 6, v i = inputMask j)
    (h : NetTable v t = 238) : 5 ≤ t.cost := by
  by_contra! small
  have fits (i : α) : Encoded [] (v i) := by
    rcases base i with e|⟨j,e⟩
    · rw [e]; exact ⟨3,by intros; exact pin_zero ..⟩
    · rw [e]; exact enc_raw j
  obtain ⟨_,run,len,s,val⟩ := run_of_net t [] v Run.start fits (by simp; omega)
  exact run_not_crown run len s (val.trans h)

theorem free_and_three_crown_five (t : Net (Fin 6)) (h : NetTable inputMask t = 238) :
    5 ≤ t.cost := by
  by_contra! small
  obtain ⟨p,run,len,s,val⟩ := run_of_net t [] inputMask Run.start enc_raw (by simp; omega)
  exact run_not_crown run len s (val.trans h)

end ParentCrown
