import ParentRestriction
import ThreeCrownNet

namespace ParentCrown
open FreeAndNet

theorem meet_bit (xs : List Word) (i : Fin 9) :
    (meet xs).getLsbD i.val = xs.all (fun w => w.getLsbD i.val) := by
  induction xs with
  | nil =>
    change (BitVec.allOnes 9).getLsbD i.val = true
    exact (BitVec.getLsbD_allOnes (v:=9) (i:=i.val)).trans (decide_eq_true i.isLt)
  | cons w xs ih =>
    change (w &&& meet xs).getLsbD i.val = (w.getLsbD i.val && xs.all (fun w => w.getLsbD i.val))
    rw [BitVec.getLsbD_and,ih]

theorem netTable_bit {α} (t : Net α) (v : α → Word) (i : Fin 9) :
    (NetTable v t).getLsbD i.val = t.eval (fun k => (v k).getLsbD i.val) := by
  induction t with
  | out p =>
    cases p with
    | none => simp [NetTable,Net.eval,pval]
    | some xs => simp only [NetTable,Net.eval,pval,Option.elim_some,meet_bit,List.all_map,Function.comp_def]
  | gate l r t ih =>
    rw [NetTable,ih,Net.eval]
    congr 1
    funext k
    cases k with
    | some z => rfl
    | none =>
      change (meet (l.map v) ||| meet (r.map v)).getLsbD i.val = ((l.all (fun k => (v k).getLsbD i.val)) || (r.all (fun k => (v k).getLsbD i.val)))
      simp only [BitVec.getLsbD_or,meet_bit,List.all_map,Function.comp_def]

theorem parent_cost {α : Type} [DecidableEq α] (t : Net α) (D : Finset α)
    (v : α → Word) (base : ∀ i, v i = 0 ∨ ∃ j : Fin 6, v i = inputMask j)
    (zero : ∀ j ∈ D, v j = 0) (represented : NetTable v t = 238)
    (positive : ∃ w, (∀ i ∈ D, w i = false) ∧ t.eval w = true)
    (flips : ∀ i ∈ D, ∃ x y, (∀ j, j ≠ i → x j = y j) ∧
      (∀ j ∈ D, j ≠ i → x j = false) ∧ t.eval x ≠ t.eval y) : D.card+5 ≤ t.cost := by
  obtain ⟨u,saved,keep⟩ := restrict_sensitive t D positive flips
  have h : NetTable v u = NetTable v t := by
    apply BitVec.eq_of_getLsbD_eq
    intro j h
    let i : Fin 9 := ⟨j,h⟩
    rw [netTable_bit u v i,netTable_bit t v i]
    exact keep _ (fun k hk => by rw [zero k hk]; simp)
  have bound := three_crown_five_general u v base (h.trans represented)
  omega

end ParentCrown
