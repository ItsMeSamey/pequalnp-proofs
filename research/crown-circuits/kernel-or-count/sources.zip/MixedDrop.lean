import Research.FreeAndRestrict
import Mathlib.Data.Finset.Card
namespace FreeAndNet

theorem specialize_cost {α β : Type} (s : α → Product β) (t : Net α) :
    (specialize s t).cost ≤ t.cost := by
  induction t generalizing β with
  | out => rfl
  | gate a b t ih =>
    unfold specialize
    generalize substProduct s a = pa
    generalize substProduct s b = pb
    cases pa <;> cases pb <;> simp only [Net.cost]
    all_goals first | exact Nat.succ_le_succ (ih _) | exact Nat.le_succ_of_le (ih _)

theorem delete_first_of_product {α : Type} (a b : List α) (tail : Net (Option α))
    (p : Product α) (hp : ∀ v, pval v p = (a.all v || b.all v)) :
    ∃ u : Net α, (∀ v, u.eval v = (Net.gate a b tail).eval v) ∧
      u.cost < (Net.gate a b tail).cost := by
  let s : Option α → Product α := fun x => x.elim p (fun i => some [i])
  refine ⟨specialize s tail, ?_, Nat.lt_succ_of_le (specialize_cost s tail)⟩
  intro v
  rw [eval_specialize]
  apply congrArg (fun f => tail.eval f)
  funext x
  cases x with
  | none => exact hp v
  | some i => simp [s,pval]

theorem delete_degenerate_first {α : Type} [DecidableEq α] (a b : List α) (tail : Net (Option α))
    (h : a = [] ∨ b = [] ∨ (a.toFinset ∪ b.toFinset).card ≤ 1) :
    ∃ u : Net α, (∀ v, u.eval v = (Net.gate a b tail).eval v) ∧
      u.cost < (Net.gate a b tail).cost := by
  rcases h with rfl|rfl|h
  · apply delete_first_of_product _ _ _ (some [])
    simp [pval]
  · apply delete_first_of_product _ _ _ (some [])
    simp [pval]
  cases a with
  | nil => apply delete_first_of_product _ _ _ (some []); simp [pval]
  | cons x xs =>
    cases b with
    | nil => apply delete_first_of_product _ _ _ (some []); simp [pval]
    | cons y ys =>
      have allsame := Finset.card_le_one.mp h
      have hx : x ∈ (x::xs).toFinset ∪ (y::ys).toFinset := by simp
      have eqx (i : α) (hi : i ∈ (x::xs) ∨ i ∈ (y::ys)) : i = x :=
        allsame i (by simpa only [Finset.mem_union,List.mem_toFinset] using hi) x hx
      apply delete_first_of_product _ _ _ (some [x])
      intro v
      have aa : (x::xs).all v = v x := by
        cases hv : v x with
        | false => simp [hv]
        | true => exact List.all_eq_true.mpr (fun i hi => (eqx i (.inl hi)) ▸ hv)
      have bb : (y::ys).all v = v x := by
        cases hv : v x with
        | false => simp [List.all_cons,eqx y (.inr (by simp)),hv]
        | true => exact List.all_eq_true.mpr (fun i hi => (eqx i (.inr hi)) ▸ hv)
      rw [aa,bb]
      simp [pval]
end FreeAndNet
