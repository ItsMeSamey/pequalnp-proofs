import CrownMixed
namespace CrownMixed.Naming
open FreeAndNet
private theorem all_mono {α : Type} (l : List α) (u v : α → Bool)
    (h : ∀ i, u i = true → v i = true) : l.all u = true → l.all v = true :=
  fun x => List.all_eq_true.mpr (fun i hi => h i (List.all_eq_true.mp x i hi))

private theorem net_mono {α : Type} (t : Net α) (u v : α → Bool)
    (h : ∀ i, u i = true → v i = true) : t.eval u = true → t.eval v = true := by
  induction t with
  | out p =>
    cases p with
    | none => simp [Net.eval,pval]
    | some l => exact all_mono l u v h
  | gate a b t ih =>
    apply ih
    intro z
    cases z with
    | some i => exact h i
    | none =>
      change a.all u || b.all u = true → a.all v || b.all v = true
      intro e
      rcases Bool.or_eq_true_iff.mp e with hh|hh
      · exact Bool.or_eq_true_iff.mpr (.inl (all_mono a _ _ h hh))
      · exact Bool.or_eq_true_iff.mpr (.inr (all_mono b _ _ h hh))


/-- If two distinct named atoms are seen only through their disjunction,
they must be the two endpoints of a single label. -/
theorem matched_of_external {I α : Type} [DecidableEq α] [DecidableEq I]
    (N : Naming I α) (t : Net α) (rep : N.Rep t) (x y : α) (ne : x ≠ y)
    (nx : ∃ i, x = N.row i ∨ x = N.col i) (ny : ∃ i, y = N.row i ∨ y = N.col i)
    (ext : ∀ v w : α → Bool, (∀ z, z ≠ x → z ≠ y → v z = w z) →
      (v x || v y) = (w x || w y) → t.eval v = t.eval w) :
    ∃ i, (x = N.row i ∧ y = N.col i) ∨ (x = N.col i ∧ y = N.row i) := by
  have conflict (i a b : I) (ab : a ≠ b) (hx : x = N.row i ∨ x = N.col i)
      (sub : ∀ z, z = N.row a ∨ z = N.col b →
        z = x ∨ z = y ∨ z = N.row i ∨ z = N.col i) : False := by
    let augmented : α → Bool := fun z => decide (z = x ∨ z = y ∨ z = N.row i ∨ z = N.col i)
    have agree := ext (N.val i i) augmented (by intro z zx zy; simp [augmented,val,zx,zy])
      (by simp [val,augmented,hx])
    have hot : t.eval augmented = true := net_mono t (N.val a b) augmented
      (fun z h => decide_eq_true (sub z (of_decide_eq_true h))) (by simp [rep a b,ab])
    rw [← agree,rep i i] at hot
    simp at hot
  obtain ⟨i,hx⟩ := nx
  obtain ⟨j,hy⟩ := ny
  by_cases ij : i = j
  · subst j
    exact ⟨i, by rcases hx with h|h <;> rcases hy with z|z <;> simp_all⟩
  · exfalso
    rcases hx with h|h <;> rcases hy with k|k
    · exact conflict i j i (Ne.symm ij) (Or.inl h) (by intro z hs; rw [h,k]; tauto)
    · exact conflict i i j ij (Or.inl h) (by intro z hs; rw [h,k]; tauto)
    · exact conflict i j i (Ne.symm ij) (Or.inr h) (by intro z hs; rw [h,k]; tauto)
    · exact conflict i i j ij (Or.inr h) (by intro z hs; rw [h,k]; tauto)
end CrownMixed.Naming
