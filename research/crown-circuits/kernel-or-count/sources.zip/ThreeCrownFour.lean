import CrownKernelUnsat
import CrownKernelLink
namespace ParentCrown
theorem three_crown_four_or (s0 t0 s1 t1 s2 t2 s3 t3 u : BitVec 10) :
    let a := pin s0 0 0 0 0 ||| pin t0 0 0 0 0
    let b := pin s1 a 0 0 0 ||| pin t1 a 0 0 0
    let c := pin s2 a b 0 0 ||| pin t2 a b 0 0
    let d := pin s3 a b c 0 ||| pin t3 a b c 0
    pin u a b c d ≠ 238 := by
  dsimp only
  intro h
  exact CrownKernelCert.unsat (CrownKernelLink.selectors_sat s0 t0 s1 t1 s2 t2 s3 t3 u h)
end ParentCrown
