import CrownMixed
import MixedDeletion
import Mathlib.Data.Finset.Card
namespace CrownMixed.Naming
open FreeAndNet
variable {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]

theorem pairs_remove (N : Naming I α) (i : I) :
    (N.remove i).pairs + (if N.row i = N.col i then 1 else 0) = N.pairs := by
  classical
  let P := Finset.univ.filter (fun j : I => N.row j = N.col j)
  let T := Finset.univ.filter (fun j : {j : I // j ≠ i} => N.row j.val = N.col j.val)
  let e : {j : I // j ≠ i} ↪ I := Function.Embedding.subtype _
  have eq : T.map e = P.erase i := by
    ext a
    constructor
    · intro h
      obtain ⟨q,hq,rfl⟩ := Finset.mem_map.mp h
      exact Finset.mem_erase.mpr ⟨q.property,by simpa [T,P,e] using hq⟩
    · intro h
      obtain ⟨ne,ok⟩ := Finset.mem_erase.mp h
      exact Finset.mem_map.mpr ⟨⟨a,ne⟩,by simpa [T,P] using ok,rfl⟩
  have card : T.card = (P.erase i).card := by simpa using congrArg Finset.card eq
  change T.card + _ = P.card
  rw [card]
  by_cases ok : N.row i = N.col i
  · rw [ite_eq_left ok]
    exact Finset.card_erase_add_one (by simp [P,ok])
  · simp [ite_eq_right ok,Finset.erase_eq_of_notMem (show i ∉ P by simp [P,ok])]

omit [Fintype I] [DecidableEq I] in
private theorem row_off (N : Naming I α) {i j k : I} (hij : i ≠ j) (hik : i ≠ k) :
    N.val j k (N.row i) = false := by
  have a : N.row i ≠ N.row j := fun e => hij (N.row_inj e)
  have b : N.row i ≠ N.col k := fun e => hik (N.same e)
  simp [Naming.val,a,b]

omit [Fintype I] [DecidableEq I] in
private theorem col_off (N : Naming I α) {i j k : I} (hij : i ≠ j) (hik : i ≠ k) :
    N.val j k (N.col i) = false := by
  have a : N.col i ≠ N.row j := fun e => hij (N.same e.symm).symm
  have b : N.col i ≠ N.col k := fun e => hik (N.col_inj e)
  simp [Naming.val,a,b]

private theorem others (i : I) (hn : 4 ≤ Fintype.card I) : ∃ j k : I, i ≠ j ∧ i ≠ k ∧ j ≠ k := by
  classical
  have ex : ∃ j : I, i ≠ j := by
    by_contra! no
    have sub : (Finset.univ : Finset I) ⊆ {i} := fun x _ => by simp [(no x).symm]
    have bound := Finset.card_le_card sub
    simp at bound
    omega
  obtain ⟨j,ij⟩ := ex
  by_contra! no
  have sub : (Finset.univ : Finset I) ⊆ {i,j} := by
    intro x _
    by_cases hx : i=x
    · simp [hx]
    · simp [no j x ij hx]
  have bound := Finset.card_le_card sub
  simp [ij] at bound
  omega

omit [Fintype I] in
private theorem retained (N : Naming I α) (t u : Net α) (i : I) (rep : N.Rep t)
    (keep : ∀ v, v (N.row i) = false → v (N.col i) = false → u.eval v = t.eval v) :
    (N.remove i).Rep u := by
  intro j k
  change u.eval (N.val j.val k.val) = _
  have a := row_off N j.property.symm k.property.symm
  have b := col_off N j.property.symm k.property.symm
  rw [keep _ a b,rep]
  simp only [ne_eq,Subtype.ext_iff]
private theorem all_mono {α : Type} (l : List α) (u v : α → Bool)
    (h : ∀ i, u i = true → v i = true) : l.all u = true → l.all v = true :=
  fun x => List.all_eq_true.mpr (fun i hi => h i (List.all_eq_true.mp x i hi))

private theorem net_mono {α : Type} (t : Net α) (u v : α → Bool)
    (h : ∀ i, u i = true → v i = true) : t.eval u = true → t.eval v = true := by
  induction t with
  | out p =>
    cases p with
    | none => simp [Net.eval,pval]
    | some l => exact all_mono l u v h
  | gate a b t ih =>
    apply ih
    intro z
    cases z with
    | some i => exact h i
    | none =>
      change a.all u || b.all u = true → a.all v || b.all v = true
      intro e
      rcases Bool.or_eq_true_iff.mp e with hh|hh
      · exact Bool.or_eq_true_iff.mpr (.inl (all_mono a _ _ h hh))
      · exact Bool.or_eq_true_iff.mpr (.inr (all_mono b _ _ h hh))


omit [Fintype I] in
private theorem singleton_no (N : Naming I α) (t : Net α) (rep : N.Rep t)
    (j : I) (wire : α) (atj : wire = N.row j ∨ wire = N.col j) :
    t.eval (fun z => decide (z=wire)) = false := by
  have no : t.eval (N.val j j) = false := by simpa using rep j j
  cases v : t.eval (fun z => decide (z=wire)) with
  | false => rfl
  | true =>
    have a := net_mono t (fun z => decide (z=wire)) (N.val j j) (by
      intro z h
      have eq : z=wire := of_decide_eq_true h
      subst z
      simpa [Naming.val] using atj) v
    simp_all

theorem oneHit (N : Naming I α) (t : Net α) (rep : N.Rep t)
    (hn : 4 ≤ Fintype.card I) (cheap : t.cost + N.pairs + 4 < 3 * Fintype.card I)
    (ih : ∀ i (u : Net α), (N.remove i).Rep u →
      3 * (Fintype.card I - 1) ≤ u.cost + (N.remove i).pairs + 4) :
    ∀ i, hits (N.row i) t ≤ 1 ∧ hits (N.col i) t ≤ 1 := by
  intro i
  have pp := N.pairs_remove i
  by_cases pair : N.row i = N.col i
  · let u := specialize (eraseInput (N.row i)) t
    have save : u.cost + hits (N.row i) t ≤ t.cost :=
      specialize_saves _ (eraseInput (N.row i)) (by simp [eraseInput]) t
    have ur : (N.remove i).Rep u := retained N t u i rep (fun v va _ =>
      eval_eraseInput t _ v va)
    have low := ih i u ur
    rw [ite_eq_left pair] at pp
    have hit : hits (N.row i) t ≤ 1 := by omega
    exact ⟨hit,pair ▸ hit⟩
  · rw [ite_eq_right pair] at pp
    obtain ⟨j,k,ij,ik,jk⟩ := others i hn
    have good : t.eval (N.val j k) = true := by simpa [jk] using rep j k
    have rowj : N.row i ≠ N.row j := fun e => ij (N.row_inj e)
    have colj : N.col i ≠ N.col j := fun e => ij (N.col_inj e)
    have rjfalse := singleton_no N t rep j (N.row j) (Or.inl rfl)
    have cjfalse := singleton_no N t rep j (N.col j) (Or.inr rfl)
    have cjtrue : t.eval (N.val i j) = true := by simpa [ij] using rep i j
    have rjtrue : t.eval (N.val j i) = true := by simpa [ij.symm] using rep j i
    constructor
    · obtain ⟨u,save,keep⟩ := erase_two_saves_hits t (N.row i) (N.col i)
        ⟨N.val j k,row_off N ij ik,col_off N ij ik,good⟩
        ⟨(fun z => decide (z=N.row j)),N.val j i,by simp [rowj],
          by simp [Naming.val,rowj,pair],
          (fun z ne => by simp [Naming.val,ne]),
          by rw [rjfalse,rjtrue]; decide⟩
      have low := ih i u (retained N t u i rep keep)
      omega
    · obtain ⟨u,save,keep⟩ := erase_two_saves_hits t (N.col i) (N.row i)
        ⟨N.val j k,col_off N ij ik,row_off N ij ik,good⟩
        ⟨(fun z => decide (z=N.col j)),N.val i j,by simp [colj],
          by simp [Naming.val,colj,Ne.symm pair],
          (fun z ne => by simp [Naming.val,ne]),
          by rw [cjfalse,cjtrue]; decide⟩
      have low := ih i u (retained N t u i rep (fun v a b => keep v b a))
      omega

end CrownMixed.Naming
