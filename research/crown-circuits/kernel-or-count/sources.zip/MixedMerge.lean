import CrownMixed
import Mathlib.Data.Finset.Card

namespace CrownMixed.Naming
open FreeAndNet
variable {I α : Type}

private def merged [DecidableEq I] (f : I → α) (i j : I) : Option α :=
  if j=i then none else some (f j)

private theorem merged_eq [DecidableEq I] {f g : I → α} {i j k : I} :
    merged f i j = merged g i k ↔ (j=i ∧ k=i) ∨ (j≠i ∧ k≠i ∧ f j = g k) := by
  by_cases hj : j=i <;> by_cases hk : k=i <;> simp [merged,hj,hk]

def merge [DecidableEq I] (N : Naming I α) (i : I) : Naming I (Option α) where
  row := merged N.row i
  col := merged N.col i
  row_inj := fun _ _ h => (merged_eq.mp h).elim (fun e => e.1.trans e.2.symm) (fun e => N.row_inj e.2.2)
  col_inj := fun _ _ h => (merged_eq.mp h).elim (fun e => e.1.trans e.2.symm) (fun e => N.col_inj e.2.2)
  same := fun h => (merged_eq.mp h).elim (fun e => e.1.trans e.2.symm) (fun e => N.same e.2.2)

theorem merge_pairs [Fintype I] [DecidableEq I] [DecidableEq α] (N : Naming I α) (i : I)
    (h : N.row i ≠ N.col i) : (N.merge i).pairs = N.pairs+1 := by
  let P := Finset.univ.filter (fun j => N.row j = N.col j)
  have e : (Finset.univ.filter (fun j => (N.merge i).row j = (N.merge i).col j)) = insert i P := by
    ext j
    simp only [Finset.mem_filter,Finset.mem_univ,true_and,Finset.mem_insert,P,merge,merged_eq]
    by_cases hj : j=i <;> simp [hj]
  have off : i ∉ P := by simp [P,h]
  exact (congrArg Finset.card e).trans (Finset.card_insert_of_notMem off)

theorem followMerge [Fintype I] [DecidableEq I] [DecidableEq α] (N : Naming I α) (i : I)
    {a b : List α} {t : Net (Option α)} (rep : N.Rep (.gate a b t))
    (unpaired : N.row i ≠ N.col i)
    (gate : ∀ v, (a.all v || b.all v) = (v (N.row i) || v (N.col i)))
    (rowFresh : hits (some (N.row i)) t = 0 ∧ ¬outUses (some (N.row i)) t)
    (colFresh : hits (some (N.col i)) t = 0 ∧ ¬outUses (some (N.col i)) t) :
    ∃ M : Naming I (Option α), M.Rep t ∧ M.pairs = N.pairs+1 := by
  refine ⟨N.merge i,?_,merge_pairs N i unpaired⟩
  intro p q
  refine Eq.trans ?_ (rep p q)
  change t.eval _ = t.eval _
  apply eval_congr_used
  intro j used
  cases j with
  | none =>
    change (N.merge i).val p q none = (a.all (N.val p q) || b.all (N.val p q))
    rw [gate]
    apply Bool.eq_iff_iff.mpr
    simp only [val,merge,merged,Bool.or_eq_true_iff,decide_eq_true_eq]
    by_cases hp : p=i <;> by_cases hq : q=i <;> simp [hp,hq];
      first | tauto | grind [N.row_inj.eq_iff,N.col_inj.eq_iff,N.same]
  | some j =>
    have neR : j ≠ N.row i := by
      rintro rfl
      rcases used with h|h
      · omega
      · exact rowFresh.2 h
    have neC : j ≠ N.col i := by
      rintro rfl
      rcases used with h|h
      · omega
      · exact colFresh.2 h
    change (N.merge i).val p q (some j) = N.val p q j
    by_cases hp : p=i <;> by_cases hq : q=i <;> simp [val,merge,merged,hp,hq,neR,neC]

end CrownMixed.Naming
