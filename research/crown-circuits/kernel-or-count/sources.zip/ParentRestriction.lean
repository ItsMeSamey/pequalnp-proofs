import Research.FreeAndSupport
import Mathlib.Data.Finset.Card

namespace FreeAndNet

def eraseInput {α : Type} [DecidableEq α] (i j : α) : Product α :=
  if i=j then none else some [j]

theorem eval_eraseInput {α : Type} [DecidableEq α] (t : Net α) (i : α)
    (v : α → Bool) (off : v i = false) :
    (specialize (eraseInput i) t).eval v = t.eval v := by
  rw [eval_specialize]
  congr 1
  funext j
  by_cases h : i=j
  · subst j
    simp [eraseInput,pval,off]
  · simp [eraseInput,pval,h]

/-- Delete all variables in D. Each deletion saves an OR when one surviving
positive input avoids the variable and a surviving pair distinguishes it. -/
theorem restrict_sensitive {α : Type} [DecidableEq α] (t : Net α) (D : Finset α)
    (positive : ∃ w, (∀ i ∈ D, w i = false) ∧ t.eval w = true)
    (flips : ∀ i ∈ D, ∃ x y, (∀ j, j ≠ i → x j = y j) ∧
      (∀ j ∈ D, j ≠ i → x j = false) ∧ t.eval x ≠ t.eval y) :
    ∃ u : Net α, u.cost + D.card ≤ t.cost ∧
      ∀ v, (∀ j ∈ D, v j = false) → u.eval v = t.eval v := by
  classical
  induction D using Finset.induction_on with
  | empty => exact ⟨t,by simp,fun _ _ => rfl⟩
  | @insert i D hi ih =>
    obtain ⟨w,wo,wy⟩ := positive
    have mem (j : α) (hj : j ∈ D) : j ∈ insert i D := Finset.mem_insert_of_mem hj
    obtain ⟨u,lower,keep⟩ := ih ⟨w,fun j hj => wo j (mem j hj),wy⟩ (by
      intro j hj
      obtain ⟨x,y,hxy,hzero,ne⟩ := flips j (mem j hj)
      exact ⟨x,y,hxy,fun k hk => hzero k (mem k hk),ne⟩)
    obtain ⟨x,y,hxy,hzero,ne⟩ := flips i (Finset.mem_insert_self ..)
    have offx (j : α) (hj : j ∈ D) := hzero j (mem j hj) (fun h => hi (h ▸ hj))
    have offy (j : α) (hj : j ∈ D) : y j = false := by
      rw [← hxy j (fun h => hi (h ▸ hj))]
      exact offx j hj
    have used : 0 < hits i u := by
      by_contra! h
      have noOut : ¬outUses i u := by
        intro ou
        have e := outZeros u i ou w (wo i (Finset.mem_insert_self ..))
        rw [keep w (fun j hj => wo j (mem j hj)),wy] at e
        contradiction
      apply ne
      rw [←keep x offx,←keep y offy]
      apply eval_congr_used
      intro j used
      by_cases eq : j=i
      · subst j
        rcases used with us | us
        · omega
        · exact (noOut us).elim
      · exact hxy j eq
    have save := specialize_saves i (eraseInput i) (by simp [eraseInput]) u
    refine ⟨specialize (eraseInput i) u,?_,?_⟩
    · rw [Finset.card_insert_of_notMem hi]
      omega
    · intro v hv
      rw [eval_eraseInput u i v (hv _ (Finset.mem_insert_self ..))]
      exact keep v (fun j hj => hv j (mem j hj))

end FreeAndNet
