import CrownSeg0
import CrownSeg1
import CrownSeg2
import CrownSeg3
import CrownSeg4
import CrownSeg5
import CrownSeg6
import CrownSeg7
import CrownSeg8
import CrownSeg9
import CrownSeg10
import CrownSeg11
import CrownSeg12
import CrownSeg13
import CrownSeg14
import CrownSeg15
import CrownSeg16
import CrownSeg17
import CrownSeg18
import CrownSeg19
import CrownSeg20
import CrownSeg21
import CrownSeg22
import CrownSeg23
import CrownSeg24
import CrownSeg25
import CrownSeg26
import CrownSeg27
import CrownSeg28
import CrownSeg29
import CrownSeg30
import CrownSeg31
import CrownSeg32
import CrownSeg33
import CrownSeg34
import CrownSeg35
import CrownSeg36
import CrownSeg37
import CrownSeg38
import CrownSeg39
import CrownSeg40
import CrownSeg41
import CrownSeg42
import CrownSeg43
import CrownSeg44
import CrownSeg45
import CrownSeg46
import CrownSeg47

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace CrownKernelCert
open PEqualNP.Library.LRAT CrownKernelFormula
theorem unsat : ¬ FormulaSat F := fun ⟨a,h⟩ => step47 a (step46 a (step45 a (step44 a (step43 a (step42 a (step41 a (step40 a (step39 a (step38 a (step37 a (step36 a (step35 a (step34 a (step33 a (step32 a (step31 a (step30 a (step29 a (step28 a (step27 a (step26 a (step25 a (step24 a (step23 a (step22 a (step21 a (step20 a (step19 a (step18 a (step17 a (step16 a (step15 a (step14 a (step13 a (step12 a (step11 a (step10 a (step9 a (step8 a (step7 a (step6 a (step5 a (step4 a (step3 a (step2 a (step1 a (step0 a h)))))))))))))))))))))))))))))))))))))))))))))))
end CrownKernelCert
