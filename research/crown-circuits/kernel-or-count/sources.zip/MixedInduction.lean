import MixedPrune
import Mathlib.Data.Fintype.Card
namespace CrownMixed
open FreeAndNet

abbrev BaseCase := ∀ {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]
  (N : Naming I α) (t : Net α), Fintype.card I = 3 → N.Rep t →
  3 * Fintype.card I ≤ t.cost + N.pairs + 4

abbrev GateHitCase := ∀ {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]
    (N : Naming I α) (t : Net α), N.Rep t → 4 ≤ Fintype.card I →
    t.cost + N.pairs + 4 < 3 * Fintype.card I →
    (∀ i (u : Net α), (N.remove i).Rep u →
      3 * (Fintype.card I - 1) ≤ u.cost + (N.remove i).pairs + 4) →
    ∀ i, hits (N.row i) t ≤ 1 ∧ hits (N.col i) t ≤ 1

abbrev PairStepCase := ∀ {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]
    (N : Naming I α) (a b : List α) (t : Net (Option α)), 4 ≤ Fintype.card I →
    N.Rep (.gate a b t) → 2 ≤ (a.toFinset ∪ b.toFinset).card → a ≠ [] → b ≠ [] →
    (∀ x ∈ a++b, ∃ i, N.row i=x ∨ N.col i=x) →
    (∀ i, hits (N.row i) (.gate a b t) ≤ 1 ∧ hits (N.col i) (.gate a b t) ≤ 1) →
    ∃ M : Naming I (Option α), M.Rep t ∧ M.pairs = N.pairs + 1

private def Case (n k : Nat) := ∀ (I α : Type) [Fintype I] [DecidableEq I] [DecidableEq α]
    (N : Naming I α) (t : Net α), Fintype.card I=n → t.cost=k → 3 ≤ n →
      N.Rep t → 3*n ≤ k+N.pairs+4

theorem induct_crown (base : BaseCase) (one : GateHitCase) (pairStep : PairStepCase)
    {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]
    (N : Naming I α) (t : Net α) (hn : 3 ≤ Fintype.card I) (rep : N.Rep t) :
    3 * Fintype.card I ≤ t.cost + N.pairs + 4 := by
  have main (n : Nat) : ∀ k, Case n k := by
    induction n using Nat.strong_induction_on with
    | ind n outer =>
      intro k
      induction k using Nat.strong_induction_on with
      | ind k inner =>
        intro I α _ _ _ N t nc kc hn rep
        by_cases three : n=3
        · simpa only [nc,kc] using base N t (nc.trans three) rep
        have large : 4 ≤ Fintype.card I := by omega
        by_contra! bad
        have sameSize (u : Net α) (r : N.Rep u) (small : u.cost < t.cost) : False := by
          have lower := inner u.cost (by omega) I α N u nc rfl hn r
          omega
        cases t with
        | out p => exact (N.no_terminal (by omega) p) rep
        | gate a b t =>
          by_cases deg : a=[] ∨ b=[] ∨ (a.toFinset ∪ b.toFinset).card ≤ 1
          · obtain ⟨u,keep,save⟩ := delete_degenerate_first a b t deg
            exact sameSize u (fun i j => (keep _).trans (rep i j)) save
          by_cases live : ∀ x ∈ a++b, ∃ i, N.row i=x ∨ N.col i=x
          · have hc : (Net.gate a b t).cost + N.pairs + 4 < 3 * Fintype.card I := by omega
            have oneHit := one N (.gate a b t) rep large hc (by
              intro i u ru
              have card : Fintype.card {j : I // j≠i} = n-1 := by
                rw [Fintype.card_subtype_compl (p:=fun j => j=i),Fintype.card_subtype_eq,nc]
              have h := outer (n-1) (by omega) u.cost _ α (N.remove i) u card rfl (by omega) ru
              simpa only [nc] using h)
            obtain ⟨M,mr,mp⟩ := pairStep N a b t large rep (by omega) (fun e=>deg (.inl e))
              (fun e=>deg (.inr (.inl e))) live oneHit
            change t.cost+1=k at kc
            have h := inner t.cost (by omega) I (Option α) M t nc rfl hn mr
            omega
          · push Not at live
            obtain ⟨x,hx,absent⟩ := live
            have inactive : ¬∃ i, N.row i=x ∨ N.col i=x := by
              rintro ⟨i,hi⟩
              rcases hi with h|h <;> simp_all
            obtain ⟨u,ur,sm⟩ := N.remove_inactive a b t rep x hx inactive
            exact sameSize u ur sm
  exact main _ _ I α N t rfl rfl hn rep

end CrownMixed
