import ParentRestriction

namespace ParentCrown
open FreeAndNet

private theorem pin_congr {α : Type} (l : List α) {v w : α → Bool}
    (h : ∀ j ∈ l, v j = w j) : l.all v = l.all w := by
  induction l with
  | nil => rfl
  | cons x l ih =>
    simp only [List.all_cons, h x (by simp), ih (fun j hj => h j (by simp [hj]))]

private theorem pin_off {α : Type} {l : List α} {v : α → Bool} {j : α}
    (mem : j ∈ l) (off : v j = false) : l.all v = false := by
  cases he : l.all v with
  | false => rfl
  | true => have hh := List.all_eq_true.mp he j mem; simp_all

/-- A change to one atom read only at this gate cannot affect the output
if the output of the gate stays the same. -/
theorem first_gate_externality {α : Type} [DecidableEq α] {a b : List α}
    {t : Net (Option α)} {x : α} (fresh : hits (some x) t = 0 ∧ ¬outUses (some x) t)
    {v w : α → Bool} (eqOther : ∀ j, j ≠ x → v j = w j)
    (gateEq : (a.all v || b.all v) = (a.all w || b.all w)) :
    (Net.gate a b t).eval v = (Net.gate a b t).eval w := by
  simp only [Net.eval]
  apply eval_congr_used
  intro j hj
  cases j with
  | none => exact gateEq
  | some i =>
    by_cases hi : i = x
    · subst i
      rcases hj with h | h
      · omega
      · exact (fresh.2 h).elim
    · exact eqOther i hi

/-- On each pin every occurrence names the same atom. Repeated factors are
permitted. A pivot for x can be exhibited with any other y fixed false. -/
theorem first_gate_pin_unique {α : Type} [DecidableEq α] (a b : List α)
    (t : Net (Option α))
    (fresh : ∀ x, x ∈ a ∨ x ∈ b → hits (some x) t = 0 ∧ ¬outUses (some x) t)
    (pivot : ∀ x y : α, (x ∈ a ∨ x ∈ b) → (y ∈ a ∨ y ∈ b) → x ≠ y → ∃ v w : α → Bool,
      v y = false ∧ (∀ j, j ≠ x → v j = w j) ∧
      (Net.gate a b t).eval v ≠ (Net.gate a b t).eval w) :
    (∀ x ∈ a, ∀ y ∈ a, x = y) ∧ (∀ x ∈ b, ∀ y ∈ b, x = y) := by
  have force (l m : List α) (x y : α) (xy : x ≠ y) (xl : x ∈ l) (yl : y ∈ l)
      (freshX : hits (some x) t = 0 ∧ ¬outUses (some x) t)
      (freshY : hits (some y) t = 0 ∧ ¬outUses (some y) t)
      (xpin : x ∈ a ∨ x ∈ b) (ypin : y ∈ a ∨ y ∈ b)
      (equiv : ∀ v : α → Bool, (a.all v || b.all v) = (l.all v || m.all v)) : False := by
    by_cases xm : x ∈ m
    · obtain ⟨v,w,off,eqo,dist⟩ := pivot y x ypin xpin xy.symm
      have off' : w x = false := (eqo x xy).symm.trans off
      apply dist
      apply first_gate_externality freshY eqo
      rw [equiv v, equiv w, pin_off xl off, pin_off xl off', pin_off xm off, pin_off xm off']
    · obtain ⟨v,w,off,eqo,dist⟩ := pivot x y xpin ypin xy
      have off' : w y = false := (eqo y xy.symm).symm.trans off
      apply dist
      apply first_gate_externality freshX eqo
      rw [equiv v, equiv w, pin_off yl off, pin_off yl off']
      exact congrArg (fun q => false || q) (pin_congr m (fun j hj => eqo j (fun h => xm (h ▸ hj))))
  constructor
  · intro x hx y hy
    by_contra xy
    exact force a b x y xy hx hy (fresh x (.inl hx)) (fresh y (.inl hy)) (.inl hx) (.inl hy) (fun _ => rfl)
  · intro x hx y hy
    by_contra xy
    exact force b a x y xy hx hy (fresh x (.inr hx)) (fresh y (.inr hy)) (.inr hx) (.inr hy) (fun _ => Bool.or_comm ..)

end ParentCrown
