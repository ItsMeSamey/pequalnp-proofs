import CrownMixed
import MixedDrop
import ParentRestriction
import Mathlib.Data.Fintype.Card

namespace CrownMixed.Naming
open FreeAndNet
variable {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]

private theorem outside_small (A : Finset I) (h : A.card < Fintype.card I) : ∃ i, i ∉ A := by
  by_contra! no
  have eq : A = Finset.univ := Finset.eq_univ_of_forall no
  rw [eq, Finset.card_univ] at h
  omega

theorem positive_avoiding (N : Naming I α) (n : 3 ≤ Fintype.card I) (x : α) :
    ∃ i j, i≠j ∧ N.val i j x = false := by
  let badR := Finset.univ.filter (fun i => x = N.row i)
  let badC := Finset.univ.filter (fun i => x = N.col i)
  have smallR : badR.card ≤ 1 := Finset.card_le_one.mpr (fun _ h _ k =>
    N.row_inj ((Finset.mem_filter.mp h).2.symm.trans (Finset.mem_filter.mp k).2))
  have smallC : badC.card ≤ 1 := Finset.card_le_one.mpr (fun _ h _ k =>
    N.col_inj ((Finset.mem_filter.mp h).2.symm.trans (Finset.mem_filter.mp k).2))
  obtain ⟨i,hi⟩ := outside_small badR (by omega)
  have cap := Finset.card_insert_le i badC
  obtain ⟨j,hj⟩ := outside_small (insert i badC) (by omega)
  have nri : x ≠ N.row i := fun e => hi (Finset.mem_filter.mpr ⟨Finset.mem_univ _,e⟩)
  have ncj : x ≠ N.col j := fun e => hj (Finset.mem_insert_of_mem (Finset.mem_filter.mpr ⟨Finset.mem_univ _,e⟩))
  exact ⟨i,j,fun e => hj (by simp [e]),by simp [val,nri,ncj]⟩

theorem no_terminal (N : Naming I α) (n : 3 ≤ Fintype.card I) (p : Product α) :
    ¬ N.Rep (.out p) := by
  intro rep
  have ih : Nonempty I := Fintype.card_pos_iff.mp (by omega)
  let i : I := Classical.choice ih
  cases p with
  | none =>
    obtain ⟨j,hj⟩ := outside_small ({i} : Finset I) (by simp; omega)
    have ne : i ≠ j := fun e => hj (by simp [e])
    have h := rep i j
    simp [Net.eval,pval,ne] at h
  | some l =>
    cases l with
    | nil =>
      have h := rep i i
      simp [Net.eval,pval] at h
    | cons x xs =>
      obtain ⟨u,v,ne,off⟩ := positive_avoiding N n x
      have h := rep u v
      simp [Net.eval,pval,off,ne] at h

omit [Fintype I] in
theorem remove_inactive (N : Naming I α) (a b : List α) (tail : Net (Option α))
    (rep : N.Rep (.gate a b tail)) (x : α) (hx : x ∈ a++b)
    (inactive : ¬ ∃ i, N.row i=x ∨ N.col i=x) :
    ∃ u : Net α, N.Rep u ∧ u.cost < (Net.gate a b tail).cost := by
  let t := Net.gate a b tail
  have hit : 0 < hits x t := by
    have mem := List.mem_append.mp hx
    simp [t,hits,mem]
  have save := specialize_saves x (eraseInput x) (by simp [eraseInput]) t
  refine ⟨specialize (eraseInput x) t,?_,by change (specialize (eraseInput x) t).cost < t.cost; omega⟩
  intro i j
  rw [eval_eraseInput]
  · exact rep i j
  · have hr : x ≠ N.row i := fun e => inactive ⟨i,Or.inl e.symm⟩
    have hc : x ≠ N.col j := fun e => inactive ⟨j,Or.inr e.symm⟩
    simp [val,hr,hc]

end CrownMixed.Naming
