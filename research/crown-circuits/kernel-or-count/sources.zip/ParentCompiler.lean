import Research.FreeAndNet
import PEqualNP.Defs.MetaComplexityLgpMono
import Mathlib.Data.List.GetD

namespace FreeAndNet.CircuitCompiler
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

def orFlag (g : Gate) : Bool :=
  match g.op with | .or => true | _ => false

def orStep {α : Type} (w : List (Product α)) (p q : Product α)
    (k : ∀ {β : Type}, List (Product β) → Net β) : Net α :=
  match p,q with
  | none,t | t,none => k (w ++ [t])
  | some a,some b => .gate a b (k (w.map liftP ++ [some [none]]))

def run (out : ℕ) : (gs : List Gate) → {α : Type} → List (Product α) → Net α
  | [], _, w => .out (w.getD out none)
  | g :: gs, _, w =>
    if orFlag g then
      orStep w (w.getD (g.inputs.getD 0 w.length) none)
        (w.getD (g.inputs.getD 1 w.length) none) (run out gs)
    else run out gs (w ++ [substProduct (fun i => w.getD i none) g.inputs])

def concreteStep (w : List Bool) (g : Gate) : List Bool :=
  w ++ [g.op.eval (g.inputs.map (fun i => w.getD i false))]

private theorem read_eq {α : Type} (w : List (Product α)) (v : α → Bool) (i : ℕ) :
    pval v (w.getD i none) = (w.map (pval v)).getD i false :=
  (List.getD_map (d := (none : Product α)) (l := w) (n := i) (pval v)).symm

private theorem eval_lift {α : Type} (v : α → Bool) (b : Bool) (p : Product α) :
    pval (fun z : Option α => z.elim b v) (liftP p) = pval v p := by
  cases p <;> simp [pval,liftP,Function.comp_def]

private theorem getD_end {α : Type} (w : List α) (z : α) : w.getD w.length z = z := by
  simp [List.getD_eq_getElem?_getD]

private theorem evalOrInputs (ins : List ℕ) (w : List Bool) (len : ins.length ≤ 2) :
    (w.getD (ins.getD 0 w.length) false || w.getD (ins.getD 1 w.length) false) =
      GateOp.or.eval (ins.map (fun i => w.getD i false)) := by
  cases ins with
  | nil => simp [GateOp.eval]
  | cons a as =>
    cases as with
    | nil => simp [GateOp.eval,List.getD]
    | cons b bs =>
      cases bs with
      | nil => simp [GateOp.eval,List.getD]
      | cons c cs => simp at len

private theorem eval_orStep {α : Type} (w : List (Product α)) (p q : Product α)
    (k : ∀ {β : Type}, List (Product β) → Net β) (v : α → Bool)
    (f : List Bool → Bool)
    (hk : ∀ {β : Type} (w' : List (Product β)) (v' : β → Bool),
      (k w').eval v' = f (w'.map (pval v'))) :
    (orStep w p q k).eval v =
      f (w.map (pval v) ++ [pval v p || pval v q]) := by
  cases p with
  | none => simp [orStep,hk,pval]
  | some a =>
    cases q with
    | none => simp [orStep,hk,pval]
    | some b =>
      simp only [orStep,Net.eval,hk,List.map_append,List.map_cons,List.map_nil,List.map_map]
      congr 2
      · exact List.map_congr_left fun x _ => eval_lift v _ x
      · simp [pval]

private theorem run_eval (out : ℕ) (gs : List Gate)
    (hg : ∀ g ∈ gs, (g.op = .and ∨ g.op = .or) ∧ g.inputs.length ≤ 2)
    {α : Type} (w : List (Product α)) (v : α → Bool) :
    (run out gs w).eval v = (gs.foldl concreteStep (w.map (pval v))).getD out false := by
  induction gs generalizing α with
  | nil => exact read_eq w v out
  | cons g gs ih =>
    have ht := fun g' (h : g' ∈ gs) => hg g' (List.mem_cons_of_mem _ h)
    obtain ⟨hop, hlen⟩ := hg g List.mem_cons_self
    rcases hop with ha | ho
    · simp only [run,orFlag,ha,Bool.false_eq_true,ite_false,ih ht,List.foldl_cons,
        concreteStep,List.map_append,List.map_cons,List.map_nil,pval_subst]
      congr 3
      simp only [GateOp.eval, List.all_map,Function.comp_def,id_eq, read_eq]
    · simp only [run,orFlag,ho,ite_true,List.foldl_cons]
      rw [eval_orStep _ _ _ _ _ (fun z => (gs.foldl concreteStep z).getD out false)
        (fun w' v' => ih ht w' v')]
      simp only [concreteStep,ho,read_eq]
      have hbit := evalOrInputs g.inputs (w.map (pval v)) hlen
      simp only [List.length_map] at hbit
      rw [hbit]

private theorem cost_orStep {α : Type} (w : List (Product α)) (p q : Product α)
    (k : ∀ {β : Type}, List (Product β) → Net β) (n : ℕ)
    (hk : ∀ {β : Type} (w' : List (Product β)), (k w').cost ≤ n) :
    (orStep w p q k).cost ≤ n + 1 := by
  cases p <;> cases q <;> simp only [orStep,Net.cost]
  all_goals first | exact Nat.le.step (hk _) | exact Nat.succ_le_succ (hk _)

theorem run_cost (out : ℕ) (gs : List Gate) {α : Type} (w : List (Product α)) :
    (run out gs w).cost ≤ (gs.filter orFlag).length := by
  induction gs generalizing α with
  | nil => simp [run,Net.cost]
  | cons g gs ih =>
    cases hg : orFlag g
    · simpa [run,hg] using ih (w ++ [substProduct (fun i => w.getD i none) g.inputs])
    · simpa [run,hg] using cost_orStep w (w.getD (g.inputs.getD 0 w.length) none)
        (w.getD (g.inputs.getD 1 w.length) none) (run out gs) (gs.filter orFlag).length ih

def compile (n : ℕ) (C : Circuit) : Net (Fin n) :=
  run C.output C.gates (List.ofFn fun i : Fin n => some [i])

theorem compile_eval (n : ℕ) (C : Circuit) (hm : Monotone2 C) (v : Fin n → Bool) :
    (compile n C).eval v = C.eval (List.ofFn v) := by
  unfold compile
  rw [run_eval _ _ (fun g hg => ⟨(hm g hg).1,(hm g hg).2⟩)]
  change _ = (C.gates.foldl concreteStep (List.ofFn v)).getD C.output false
  congr 2
  simp [pval,List.map_ofFn,Function.comp_def]

theorem compile_cost (n : ℕ) (C : Circuit) :
    (compile n C).cost ≤ (C.gates.filter orFlag).length :=
  run_cost _ _ _

end FreeAndNet.CircuitCompiler
