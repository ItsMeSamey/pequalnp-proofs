import Research.FreeAndNet
namespace FreeAndNet

theorem pval_lift {α} (v : α → Bool) (h : Bool) (p : Product α) :
    pval (fun z => z.elim h v) (liftP p) = pval v p := by
  cases p <;> simp [liftP,pval,List.all_map,Function.comp_def]

theorem eval_specialize {α β : Type} (s : α → Product β) (t : Net α) (v : β → Bool) :
    (specialize s t).eval v = t.eval (fun i => pval v (s i)) := by
  induction t generalizing β with
  | out p => cases p with
    | none => rfl
    | some a => exact pval_subst s a v
  | gate a b t ih =>
    simp only [specialize, Net.eval]
    rw [← pval_subst s a v, ← pval_subst s b v]
    cases ha : substProduct s a <;> cases hb : substProduct s b <;>
      simp only [Net.eval,ih] <;> congr 1 <;> funext z <;> cases z <;>
        first | apply pval_lift | simp [pval]

noncomputable section
open Classical in
def hits {α : Type} (i : α) : Net α → Nat
  | .out _ => 0
  | .gate a b t => hits (some i) t + if i ∈ a ∨ i ∈ b then 1 else 0

theorem subst_none {α β : Type} {s : α → Product β} {i : α} (h : s i = none)
    (a : List α) (m : i ∈ a) : substProduct s a = none := by
  induction a with
  | nil => simp at m
  | cons x xs ih =>
    simp only [List.mem_cons] at m
    rcases m with rfl|m
    · simp [substProduct,h]
    · simp [substProduct,ih m]

/-- Every OR mentioning a killed atom in either operand can be removed, even
if different retained ORs reuse old subexpressions. -/
theorem specialize_saves {α β : Type} (i : α) (s : α → Product β)
    (hs : s i = none) (t : Net α) : (specialize s t).cost + hits i t ≤ t.cost := by
  classical
  induction t generalizing β with
  | out => simp [specialize,hits,Net.cost]
  | gate a b t ih =>
    simp only [specialize,hits,Net.cost]
    generalize ha : substProduct s a = pa
    generalize hb : substProduct s b = pb
    cases pa <;> cases pb
    all_goals simp only [Net.cost]
    have simple (p : Product β) : (specialize (fun z => z.elim p s) t).cost +
        (hits (some i) t + (if i ∈ a ∨ i ∈ b then 1 else 0)) ≤ t.cost + 1 := by
      have h := ih (some i) (fun z => z.elim p s) hs
      split <;> omega
    exact simple none
    next vs =>
      have h := ih (some i) (fun z => z.elim (some vs) s) hs
      split <;> omega
    next us =>
      have h := ih (some i) (fun z => z.elim (some us) s) hs
      split <;> omega
    next us vs =>
      have h := ih (some i) (fun z => z.elim (some [none]) (fun j => liftP (s j)))
        (by simp [hs,liftP] : liftP (s i) = none)
      have hn : ¬ (i ∈ a ∨ i ∈ b) := by
        rintro (h|h)
        · rw [subst_none hs a h] at ha; contradiction
        · rw [subst_none hs b h] at hb; contradiction
      simp only [hn,reduceIte,Nat.add_zero]; omega
end
end FreeAndNet
