import Mathlib.Data.List.Basic

namespace FreeAndNet
abbrev Product (α : Type) := Option (List α)
def pval {α : Type} (v : α → Bool) (p : Product α) := p.elim false (fun a => a.all v)

/-- The atom "none" in a tail denotes the newly computed OR. -/
inductive Net : Type → Type 1 where
  | out {α : Type} (value : Product α) : Net α
  | gate {α : Type} (left right : List α) (tail : Net (Option α)) : Net α

def Net.eval {α} (v : α → Bool) : Net α → Bool
  | .out p => pval v p
  | .gate a b tail => tail.eval (fun z => z.elim (a.all v || b.all v) v)

def Net.cost {α} : Net α → Nat
  | .out _ => 0
  | .gate _ _ tail => tail.cost + 1

def substProduct {α β : Type} (s : α → Product β) : List α → Product β
  | [] => some []
  | i :: xs => match s i, substProduct s xs with
    | some a, some b => some (a ++ b)
    | _,_ => none

theorem pval_subst {α β : Type} (s : α → Product β) (a : List α) (v : β → Bool) :
    pval v (substProduct s a) = a.all (fun i => pval v (s i)) := by
  induction a with
  | nil => rfl
  | cons x xs ih =>
    rw [List.all_cons,← ih, substProduct]
    cases s x <;> cases substProduct s xs <;> simp [pval]

def liftP {α : Type} : Product α → Product (Option α) := Option.map (List.map some)

def specialize {α β : Type} (s : α → Product β) : Net α → Net β
  | .out p => .out (p.bind (substProduct s))
  | .gate a b t =>
    match substProduct s a, substProduct s b with
    | none,p | p,none => specialize (fun z => z.elim p s) t
    | some u,some v => .gate u v (specialize (fun z => z.elim (some [none]) (fun i => liftP (s i))) t)

end FreeAndNet
