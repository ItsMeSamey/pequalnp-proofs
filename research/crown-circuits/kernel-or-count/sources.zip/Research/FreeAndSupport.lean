import Research.FreeAndRestrict
namespace FreeAndNet

def outUses {α} (i : α) : Net α → Prop
  | .out p => ∃ xs, p = some xs ∧ i ∈ xs
  | .gate _ _ t => outUses (some i) t

theorem outZeros {α} (t : Net α) (i : α) (h : outUses i t) (v : α → Bool)
    (hv : v i = false) : t.eval v = false := by
  induction t with
  | out p =>
    obtain ⟨xs,rfl,hm⟩ := h
    simp only [Net.eval,pval,Option.elim_some]
    by_contra! he
    have htt : xs.all v = true := by cases hh : xs.all v <;> simp_all
    have z := List.all_eq_true.mp htt i hm
    simp_all
  | gate a b t ih => exact ih (some i) h _ hv

private theorem all_eq {α : Type} {xs : List α} {v w : α → Bool} (h : ∀ i ∈ xs, v i = w i) : xs.all v = xs.all w := by
  induction xs with
  | nil => rfl
  | cons i xs ih =>
    simp only [List.all_cons, h i (by simp), ih (fun j hj => h j (by simp [hj]))]

theorem eval_congr_used {α} (t : Net α) (v w : α → Bool)
    (agree : ∀ i, 0 < hits i t ∨ outUses i t → v i = w i) : t.eval v = t.eval w := by
  induction t with
  | out p =>
    cases p with
    | none => rfl
    | some xs =>
      apply all_eq
      intro i h; exact agree _ (Or.inr ⟨_,rfl,h⟩)
  | gate a b t ih =>
    have used (i) (h : i ∈ a ∨ i ∈ b) : v i = w i :=
      agree _ (Or.inl (by simp [hits,h]))
    have ea : a.all v = a.all w := all_eq (fun i hi => used i (Or.inl hi))
    have eb : b.all v = b.all w := all_eq (fun i hi => used i (Or.inr hi))
    apply ih
    intro i h
    cases i with
    | none => simp [ea,eb]
    | some i =>
      apply agree
      rcases h with h|h
      · left; simp only [hits]; omega
      · exact Or.inr h
end FreeAndNet
