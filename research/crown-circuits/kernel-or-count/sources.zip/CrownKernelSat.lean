import CrownKernelBits
namespace CrownKernelLink
open PEqualNP.Library.LRAT
private theorem aux_sat (s : Sels) (o : Words) (p : P) (c : C) (j : J) :
    ∀ q ∈ auxiliaries p c j, ClauseSat (assign (values s o)) q := by
  unfold auxiliaries
  split
  · rename_i h
    let g : G := Fin.ofNat 4 (j.val-6)
    have jfix : 6+g.val=j.val := by
      dsimp [g,Fin.val_ofNat]
      rw [Nat.mod_eq_of_lt (by have := j.isLt; omega)]
      omega
    intro q hq
    simp only [List.mem_cons,List.not_mem_nil,or_false] at hq
    rcases hq with rfl|rfl|rfl <;>
      simp [ClauseSat,values] <;> grind
  · simp
private theorem cell_sat (s : Sels) (o : Words) (p : P) (c : C) :
    ∀ q ∈ cell p c, ClauseSat (assign (values s o)) q := by
  intro q hq
  rcases List.mem_append.mp hq with h|h
  · obtain ⟨j,_,hj⟩ := List.mem_flatMap.mp h
    exact aux_sat s o p c j q hj
  rcases List.mem_append.mp h with h|h
  · obtain ⟨z,hz,rfl⟩ := List.mem_map.mp h
    by_cases hot : values s o z = true
    · have hit : (blockers p c).any (values s o) = true :=
        List.any_eq_true.mpr ⟨z,hz,hot⟩
      exact ⟨_,List.mem_cons_self,by simp [pin_correct,hit]⟩
    · exact ⟨neg z,by simp,by simpa using hot⟩
  · obtain rfl := List.mem_singleton.mp h
    by_cases hit : (blockers p c).any (values s o) = true
    · obtain ⟨z,hz,hot⟩ := List.any_eq_true.mp hit
      exact ⟨pos z,List.mem_cons_of_mem _ (List.mem_map.mpr ⟨z,hz,rfl⟩),by simpa using hot⟩
    · exact ⟨_,List.mem_cons_self,by simp [pin_correct,hit]⟩

private theorem gate_sat (s : Sels) (o : Words) (g : G)
    (sem : o g = pinWord s o (leftPin g) ||| pinWord s o (rightPin g)) (c : C) :
    ∀ q ∈ gate g c, ClauseSat (assign (values s o)) q := by
  have eq : values s o (.out g c) =
      (values s o (.pin (leftPin g) c) || values s o (.pin (rightPin g) c)) := by
    change (o g).getLsbD c.val = _
    rw [sem,BitVec.getLsbD_or]
    rfl
  intro q h
  simp only [gate,List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl <;> simp [ClauseSat,eq] <;> grind

theorem sat_of_semantics (s : Sels) (o : Words)
    (steps : ∀ g, o g = pinWord s o (leftPin g) ||| pinWord s o (rightPin g))
    (h : pinWord s o 8 = 238) : FormulaSat CrownKernelFormula.F := by
  rw [←schema_eq]
  refine ⟨assign (values s o),fun q hq => ?_⟩
  rcases List.mem_append.mp hq with hc|he
  · obtain ⟨p,_,hh⟩ := List.mem_flatMap.mp hc
    obtain ⟨c,_,hc⟩ := List.mem_flatMap.mp hh
    exact cell_sat s o p c q hc
  rcases List.mem_append.mp he with hg|ht
  · obtain ⟨g,_,hh⟩ := List.mem_flatMap.mp hg
    obtain ⟨c,_,hc⟩ := List.mem_flatMap.mp hh
    exact gate_sat s o g (steps g) c q hc
  obtain ⟨c,_,rfl⟩ := List.mem_map.mp ht
  unfold target
  split <;> rename_i out <;> simp [ClauseSat,values,h,-BitVec.getLsbD_eq_getElem]
  · exact out
  · cases e : (238 : BitVec 9).getLsbD c.val with
    | false => rfl
    | true => exact (out e).elim
end CrownKernelLink
