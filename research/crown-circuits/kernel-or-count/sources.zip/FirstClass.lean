import FirstShape
import MixedClassification
namespace CrownMixed.Naming
open FreeAndNet
variable {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]

theorem forcedPair (N : Naming I α) (hn : 4 ≤ Fintype.card I) (a b : List α)
    (t : Net (Option α)) (rep : N.Rep (.gate a b t))
    (live : ∀ x ∈ a++b, ∃ i, N.row i=x ∨ N.col i=x)
    (one : ∀ i, hits (N.row i) (.gate a b t) ≤ 1 ∧ hits (N.col i) (.gate a b t) ≤ 1)
    (distinct : ∃ x ∈ a++b, ∃ y ∈ a++b, x≠y) :
    ∃ i, N.row i≠N.col i ∧
      (∀ v, (a.all v || b.all v) = (v (N.row i) || v (N.col i))) ∧
      (hits (some (N.row i)) t=0 ∧ ¬outUses (some (N.row i)) t) ∧
      (hits (some (N.col i)) t=0 ∧ ¬outUses (some (N.col i)) t) := by
  obtain ⟨pa,pb,fresh⟩ := firstShape N hn a b t rep live one
  obtain ⟨q,hq,r,hr,qr⟩ := distinct
  have exa : ∃ x, x ∈ a := by
    by_contra! ha
    exact qr (pb q ((List.mem_append.mp hq).resolve_left (ha q)) r
      ((List.mem_append.mp hr).resolve_left (ha r)))
  have exb : ∃ y, y ∈ b := by
    by_contra! hb
    exact qr (pa q ((List.mem_append.mp hq).resolve_right (hb q)) r
      ((List.mem_append.mp hr).resolve_right (hb r)))
  obtain ⟨x,hx⟩ := exa
  obtain ⟨y,hy⟩ := exb
  have xy : x≠y := by
    intro eq
    have allx (u : α) (hu : u ∈ a++b) : u=x :=
      (List.mem_append.mp hu).elim (fun h => pa u h x hx)
        (fun h => (pb u h y hy).trans eq.symm)
    exact qr ((allx q hq).trans (allx r hr).symm)
  have gate (v : α → Bool) : (a.all v || b.all v)=(v x || v y) := by
    rw [pin_all_eq hx (fun u hu => pa u hu x hx),pin_all_eq hy (fun u hu => pb u hu y hy)]
  have hx' : x ∈ a++b := List.mem_append.mpr (.inl hx)
  have hy' : y ∈ a++b := List.mem_append.mpr (.inr hy)
  have name (z : α) (hz : z ∈ a++b) : ∃ i, z=N.row i ∨ z=N.col i := by
    obtain ⟨i,hi⟩ := live z hz
    exact ⟨i,hi.imp Eq.symm Eq.symm⟩
  obtain ⟨i,e|e⟩ := matched_of_external N _ rep x y xy (name x hx') (name y hy')
    (pair_externality a b t x y gate (fresh x hx') (fresh y hy'))
  · obtain ⟨rfl,rfl⟩ := e
    exact ⟨i,xy,gate,fresh _ hx',fresh _ hy'⟩
  · obtain ⟨rfl,rfl⟩ := e
    exact ⟨i,xy.symm,fun v => (gate v).trans (Bool.or_comm ..),fresh _ hy',fresh _ hx'⟩
end CrownMixed.Naming
