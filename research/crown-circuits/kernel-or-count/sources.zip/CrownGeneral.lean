import CrownExact

namespace CrownMixed
open FreeAndNet FreeAndNet.CircuitCompiler PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Represents

def standardNaming (n : Nat) : Naming (Fin n) (Fin (n+n)) where
  row := Fin.castAdd n
  col := Fin.natAdd n
  row_inj := fun _ _ h => Fin.ext (congrArg (fun a : Fin (n+n) => a.val) h)
  col_inj := by
    intro i j h
    apply Fin.ext
    have e := congrArg Fin.val h
    change n+i.val=n+j.val at e
    omega
  same := by
    intro i j h
    have e := congrArg Fin.val h
    change i.val=n+j.val at e
    omega

theorem standard_separate {n : Nat} (i j : Fin n) :
    (standardNaming n).row i ≠ (standardNaming n).col j := by
  intro h
  have e := congrArg Fin.val h
  change i.val=n+j.val at e
  omega

theorem standard_pair {n : Nat} (i j : Fin n) :
    List.ofFn ((standardNaming n).val i j) = oneEach i j := by
  rw [List.ofFn_add]
  unfold oneEach
  congr 1
  · congr 1
    funext k
    change decide ((standardNaming n).row k = (standardNaming n).row i ∨
      (standardNaming n).row k = (standardNaming n).col j) = decide (k=i)
    simp [standard_separate,(standardNaming n).row_inj.eq_iff]
  · congr 1
    funext k
    change decide ((standardNaming n).col k = (standardNaming n).row i ∨
      (standardNaming n).col k = (standardNaming n).col j) = decide (k=j)
    simp [Ne.symm (standard_separate i k),(standardNaming n).col_inj.eq_iff]

theorem crown_requires_three_n_minus_four_ors {n : Nat} (hn : 3 ≤ n) (C : Circuit)
    (hm : Monotone2 C) (rep : Represents (fun i j : Fin n => decide (i≠j)) C) :
    3*n ≤ (C.gates.filter orFlag).length + 4 := by
  have r : (standardNaming n).Rep (compile (n+n) C) := by
    intro i j
    rw [compile_eval _ _ hm,standard_pair]
    exact rep i j
  have lo := mixed_or_lower _ _ (by simpa using hn) r
  have zero : (standardNaming n).pairs=0 := by simp [Naming.pairs,standard_separate]
  have cap := compile_cost (n+n) C
  simp only [Fintype.card_fin,zero] at lo
  omega
end CrownMixed
