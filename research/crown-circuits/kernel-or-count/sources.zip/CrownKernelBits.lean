import CrownKernelSchemas
namespace CrownKernelLink
def previous (o : Words) (p : P) (g : G) : BitVec 9 := if g.val < p.val/2 then o g else 0

def pinWord (s : Sels) (o : Words) (p : P) :=
  ParentCrown.pin (s p) (previous o p 0) (previous o p 1) (previous o p 2) (previous o p 3)

def values (s : Sels) (o : Words) : Wire → Bool
  | .sel p j => (s p).getLsbD j.val
  | .out g c => (o g).getLsbD c.val
  | .pin p c => (pinWord s o p).getLsbD c.val
  | .block p c g => (s p).getLsbD (6+g.val) && !(o g).getLsbD c.val

def source (o : Words) (p : P) (j : J) : BitVec 9 :=
  if j.val<6 then mask j else previous o p (Fin.ofNat 4 (j.val-6))

private theorem selected_bit (b : Bool) (v : BitVec 9) (c : C) :
    (if b then v else (511 : BitVec 9)).getLsbD c.val = !(b && !v.getLsbD c.val) := by
  have top := (by decide +kernel : ∀ k : C, (511 : BitVec 9).getLsbD k.val = true) c
  cases b with
  | false => exact top
  | true => simp

private theorem all_sources (s : Sels) (o : Words) (p : P) (c : C) :
  (pinWord s o p).getLsbD c.val =
    (List.finRange 10).all (fun j => !((s p).getLsbD j.val && !(source o p j).getLsbD c.val)) := by
  simp only [pinWord,ParentCrown.pin,BitVec.getLsbD_and,selected_bit]
  change _ = (_ && (_ && (_ && (_ && (_ && (_ && (_ && (_ && (_ && (_ && true))))))))))
  simp only [Bool.and_true,Bool.and_assoc]
  rfl

theorem block_bit (s : Sels) (o : Words) (p : P) (c : C) (j : J) :
    ((blockWire p c j).elim false (values s o)) =
      ((s p).getLsbD j.val && !(source o p j).getLsbD c.val) := by
  by_cases raw : j.val<6
  · cases h : (mask j).getLsbD c.val <;>
      simp [blockWire,raw,h,source,values,-BitVec.getLsbD_eq_getElem]
  · have jlarge : 6≤j.val := by omega
    have hmod : (j.val-6)%4 = j.val-6 := Nat.mod_eq_of_lt (by have := j.isLt; omega)
    have he : 6+(j.val-6)=j.val := by omega
    by_cases old : j.val-6<p.val/2 <;>
      simp [blockWire,raw,source,previous,old, values,hmod,he,
        show (j.val-6 ≥ p.val/2) ↔ ¬j.val-6<p.val/2 by omega]

theorem pin_correct (s : Sels) (o : Words) (p : P) (c : C) :
    values s o (.pin p c) = !((blockers p c).any (values s o)) := by
  rw [values,all_sources]
  simp only [blockers,List.any_filterMap]
  simp only [List.not_any_eq_all_not]
  apply List.all_congr rfl
  intro j
  rw [← block_bit]
  cases blockWire p c j <;> rfl
end CrownKernelLink
