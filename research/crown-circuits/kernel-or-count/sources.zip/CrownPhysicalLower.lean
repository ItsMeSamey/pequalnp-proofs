import CrownMixed
import ParentCompiler
import PEqualNP.Defs.Represents

namespace CrownMixed
open FreeAndNet FreeAndNet.CircuitCompiler PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Represents

def physicalNaming : Naming (Fin 12) (Fin 24) where
  row i := Fin.castAdd 12 i
  col j := Fin.natAdd 12 j
  row_inj := fun _ _ h => Fin.ext (congrArg (fun x : Fin 24 => x.val) h)
  col_inj := by
    intro i j h
    apply Fin.ext
    have e := congrArg (fun x : Fin 24 => x.val) h
    change 12+i.val=12+j.val at e
    omega
  same := by
    intro i j h
    have e := congrArg (fun x : Fin 24 => x.val) h
    change i.val = 12 + j.val at e
    omega

theorem physicalPair : ∀ i j, List.ofFn (physicalNaming.val i j) = oneEach i j := by decide

theorem from_mixed_lower (M : ∀ {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]
    (N : Naming I α) (t : Net α), 3 ≤ Fintype.card I → N.Rep t →
    3*Fintype.card I ≤ t.cost+N.pairs+4)
    (C : Circuit) (hm : Monotone2 C)
    (rep : Represents (fun i j : Fin 12 => decide (i≠j)) C) :
    32 ≤ (C.gates.filter orFlag).length := by
  have hr : physicalNaming.Rep (compile 24 C) := by
    intro i j
    rw [compile_eval _ _ hm,physicalPair]
    exact rep i j
  have lo := M physicalNaming (compile 24 C) (by decide) hr
  have zero : physicalNaming.pairs=0 := by decide
  have cap := compile_cost 24 C
  simp only [Fintype.card_fin,zero] at lo
  omega

end CrownMixed
