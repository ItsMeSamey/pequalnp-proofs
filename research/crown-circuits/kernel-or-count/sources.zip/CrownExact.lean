import MixedInduction
import MixedOneHit
import MixedBase
import FirstClass
import MixedMerge
import CrownPhysicalLower

namespace CrownMixed
open FreeAndNet PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Represents

theorem mixed_or_lower {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]
    (N : Naming I α) (t : Net α) (hn : 3 ≤ Fintype.card I) (rep : N.Rep t) :
    3*Fintype.card I ≤ t.cost+N.pairs+4 := by
  apply induct_crown (fun N t => N.base3 t) (fun N t => N.oneHit t) _ N t hn rep
  intro I α _ _ _ N a b t large rep card _ _ live one
  have distinct : ∃ x ∈ a++b, ∃ y ∈ a++b, x≠y := by
    simpa only [Finset.mem_union,List.mem_toFinset,List.mem_append] using
      Finset.one_lt_card.mp card
  obtain ⟨i,unpaired,gate,rowFresh,colFresh⟩ := N.forcedPair large a b t rep live one distinct
  exact N.followMerge i rep unpaired gate rowFresh colFresh

theorem crown_twelve_requires_thirty_two_ors (C : Circuit) (hm : Monotone2 C)
    (rep : Represents (fun i j : Fin 12 => decide (i≠j)) C) :
    32 ≤ (C.gates.filter CircuitCompiler.orFlag).length :=
  from_mixed_lower (fun N t => mixed_or_lower N t) C hm rep

end CrownMixed
