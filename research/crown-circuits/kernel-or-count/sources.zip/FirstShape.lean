import MixedPivot
import ParentFirstGate
namespace CrownMixed.Naming
open FreeAndNet
variable {I α : Type} [Fintype I] [DecidableEq I] [DecidableEq α]
theorem firstShape (N : Naming I α) (hn : 4 ≤ Fintype.card I) (a b : List α)
    (t : Net (Option α)) (rep : N.Rep (.gate a b t))
    (live : ∀ x ∈ a++b, ∃ i, N.row i=x ∨ N.col i=x)
    (one : ∀ i, hits (N.row i) (.gate a b t) ≤ 1 ∧ hits (N.col i) (.gate a b t) ≤ 1) :
    (∀ x ∈ a, ∀ y ∈ a, x=y) ∧ (∀ x ∈ b, ∀ y ∈ b, x=y) ∧
    ∀ x ∈ a++b, hits (some x) t=0 ∧ ¬outUses (some x) t := by
  have fresh (x : α) (mem : x ∈ a ∨ x ∈ b) :
      hits (some x) t=0 ∧ ¬outUses (some x) t := by
    obtain ⟨i,hi⟩ := live x (List.mem_append.mpr mem)
    have ub : hits x (.gate a b t) ≤ 1 := by
      rcases hi with rfl|rfl
      · exact (one i).1
      · exact (one i).2
    simp [hits,mem] at ub
    exact ⟨by omega, named_no_output N (.gate a b t) rep (by omega) hi⟩
  obtain ⟨pa,pb⟩ := ParentCrown.first_gate_pin_unique a b t fresh (by
    intro x y hx hy _
    obtain ⟨i,hi⟩ := live x (List.mem_append.mpr hx)
    obtain ⟨j,hj⟩ := live y (List.mem_append.mpr hy)
    exact mixed_pivot N _ rep (by omega) hi hj)
  exact ⟨pa,pb,fun x hx => fresh x (List.mem_append.mp hx)⟩

omit [DecidableEq α] in
theorem pin_all_eq {l : List α} {x : α} (hx : x ∈ l)
    (unique : ∀ j ∈ l, j=x) (v : α → Bool) : l.all v = v x := by
  apply Bool.eq_iff_iff.mpr
  exact ⟨fun h => List.all_eq_true.mp h x hx,
    fun h => List.all_eq_true.mpr (fun j hj => (unique j hj).symm ▸ h)⟩
theorem pair_externality (a b : List α) (t : Net (Option α)) (x y : α)
    (gate : ∀ v, (a.all v || b.all v) = (v x || v y))
    (fx : hits (some x) t=0 ∧ ¬outUses (some x) t)
    (fy : hits (some y) t=0 ∧ ¬outUses (some y) t)
    (v w : α → Bool) (agree : ∀ j, j≠x → j≠y → v j=w j)
    (same : (v x || v y)=(w x || w y)) :
    (Net.gate a b t).eval v = (Net.gate a b t).eval w := by
  simp only [Net.eval]
  apply eval_congr_used
  intro j used
  cases j with
  | none => exact (gate v).trans (same.trans (gate w).symm)
  | some j =>
    by_cases jx : j=x
    · subst j
      rcases used with h|h
      · omega
      · exact (fx.2 h).elim
    by_cases jy : j=y
    · subst j
      rcases used with h|h
      · omega
      · exact (fy.2 h).elim
    exact agree j jx jy
end CrownMixed.Naming
