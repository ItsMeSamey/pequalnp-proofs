import CrownExact

namespace CrownMixed
open FreeAndNet FreeAndNet.CircuitCompiler PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Represents

def andFlag (g : Gate) : Bool :=
  match g.op with | .and => true | _ => false

private theorem gate_budget (gs : List Gate) :
    (gs.filter orFlag).length + (gs.filter andFlag).length ≤ gs.length := by
  induction gs with
  | nil => simp
  | cons g gs ih =>
    cases h : g.op <;> simp [orFlag,andFlag,h] <;> omega

theorem crown_twelve_size_at_least_or_lower_plus_ands (C : Circuit) (hm : Monotone2 C)
    (rep : Represents (fun i j : Fin 12 => decide (i≠j)) C) :
    32 + (C.gates.filter andFlag).length ≤ C.size := by
  have lo := crown_twelve_requires_thirty_two_ors C hm rep
  have bound := gate_budget C.gates
  change _ ≤ C.gates.length
  omega

theorem crown_twelve_size_forty_has_at_most_eight_ands (C : Circuit) (hm : Monotone2 C)
    (rep : Represents (fun i j : Fin 12 => decide (i≠j)) C) (small : C.size ≤ 40) :
    (C.gates.filter andFlag).length ≤ 8 := by
  have := crown_twelve_size_at_least_or_lower_plus_ands C hm rep
  omega
end CrownMixed
