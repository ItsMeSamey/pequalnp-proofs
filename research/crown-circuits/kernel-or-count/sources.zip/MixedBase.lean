import ParentCost
import CrownMixed
import Mathlib.Data.Fintype.EquivFin

namespace CrownMixed.Naming
open FreeAndNet ParentCrown
private def rowRaw (i : Fin 3) : Fin 6 := ⟨i.val,by omega⟩
private def colRaw (i : Fin 3) : Fin 6 := ⟨3+i.val,by omega⟩
private def rowOf (k : Fin 9) : Fin 3 := ⟨k.val/3,by omega⟩
private def colOf (k : Fin 9) : Fin 3 := ⟨k.val%3,by omega⟩
private theorem row_bit : ∀ (i : Fin 3) (k : Fin 9), (inputMask (rowRaw i)).getLsbD k.val = decide (i=rowOf k) := by decide
private theorem col_bit : ∀ (i : Fin 3) (k : Fin 9), (inputMask (colRaw i)).getLsbD k.val = decide (i=colOf k) := by decide
private theorem crown_bit : ∀ (k : Fin 9), (238 : Word).getLsbD k.val = decide (rowOf k≠colOf k) := by decide

private noncomputable def gather {I α : Type} (f : I → α) (shape : I → Word) (a : α) : Word := by
  classical
  exact if h : ∃ i, f i=a then shape h.choose else 0

private theorem gather_bit {I α : Type} [DecidableEq α] [DecidableEq I] (f : I → α)
    (inj : Function.Injective f) (shape : I → Word) (a : α) (k : Fin 9) (r : I)
    (bits : ∀ i, (shape i).getLsbD k.val = decide (i=r)) :
    (gather f shape a).getLsbD k.val = decide (a=f r) := by
  classical
  unfold gather
  split
  next h =>
    rw [bits]
    apply decide_eq_decide.mpr
    constructor
    · intro same; exact h.choose_spec.symm.trans (congrArg f same)
    · intro same; exact inj (h.choose_spec.trans same)
  next h =>
    have e : a ≠ f r := fun q => h ⟨r,q.symm⟩
    simp [e]

private theorem table_correct {I α : Type} [DecidableEq α] [DecidableEq I]
    (N : Naming I α) (t : Net α) (rep : N.Rep t) (e : I ≃ Fin 3) :
    NetTable (fun a => gather N.row (fun i => inputMask (rowRaw (e i))) a |||
      gather N.col (fun i => inputMask (colRaw (e i))) a) t = 238 := by
  classical
  apply BitVec.eq_of_getLsbD_eq
  intro j hj
  let k : Fin 9 := ⟨j,hj⟩
  rw [netTable_bit _ _ k,crown_bit k]
  have sem (a : α) :
      ((gather N.row (fun i => inputMask (rowRaw (e i))) a |||
        gather N.col (fun i => inputMask (colRaw (e i))) a).getLsbD k.val) =
        N.val (e.symm (rowOf k)) (e.symm (colOf k)) a := by
    rw [BitVec.getLsbD_or,
      gather_bit N.row N.row_inj _ a k (e.symm (rowOf k))
        (fun i => by rw [row_bit]; simp [Equiv.eq_symm_apply]),
      gather_bit N.col N.col_inj _ a k (e.symm (colOf k))
        (fun i => by rw [col_bit]; simp [Equiv.eq_symm_apply])]
    simp [val]
  rw [funext sem,rep]
  simp

private theorem prep {I : Type} (e : I → Fin 3) (xs : List I) (small : xs.length ≤ 4) :
    ∃ p : List Word, Run p ∧ p.length=xs.length ∧
      ∀ i∈xs, Encoded p (inputMask (rowRaw (e i)) ||| inputMask (colRaw (e i))) := by
  induction xs with
  | nil => exact ⟨[],Run.start,rfl,by simp⟩
  | cons i xs ih =>
    obtain ⟨p,r,sz,enc⟩ := ih (by simp at small;omega)
    let w := inputMask (rowRaw (e i)) ||| inputMask (colRaw (e i))
    let l : Sel := BitVec.ofNat 10 (2^(rowRaw (e i)).val)
    let s : Sel := BitVec.ofNat 10 (2^(colRaw (e i)).val)
    have lr : pinAt p l=inputMask (rowRaw (e i)) := pin_raw .. 
    have sr : pinAt p s=inputMask (colRaw (e i)) := pin_raw ..
    refine ⟨p++[w],by simpa only [lr,sr,w] using Run.step r l s,by simp [sz],?_⟩
    intro j hj
    rcases List.mem_cons.mp hj with ij | old
    · subst j; exact enc_new p w (by simp at small;omega)
    · exact enc_mono (enc j old) ⟨[w],rfl⟩

theorem base3 {I α : Type} [Fintype I] [DecidableEq α] [DecidableEq I]
    (N : Naming I α) (t : Net α) (three : Fintype.card I=3) (rep : N.Rep t) :
    3 * Fintype.card I ≤ t.cost + N.pairs + 4 := by
  classical
  by_contra! bad
  let e := Fintype.equivFinOfCardEq three
  let D := Finset.univ.filter (fun i => N.row i=N.col i)
  have len : D.toList.length = N.pairs := by simp [D,pairs]
  obtain ⟨p,run,sz,enc⟩ := prep e D.toList (by omega)
  let v := fun a => gather N.row (fun i => inputMask (rowRaw (e i))) a |||
      gather N.col (fun i => inputMask (colRaw (e i))) a
  have raw (k : Fin 6) : Encoded p (inputMask k) := enc_mono (enc_raw k) (by simp)
  have fits (a : α) : Encoded p (v a) := by
    unfold v gather
    split
    next r =>
      split
      next c =>
        have eq := N.same (r.choose_spec.trans c.choose_spec.symm)
        have mem : r.choose ∈ D.toList := by
          simp only [Finset.mem_toList,D,Finset.mem_filter,Finset.mem_univ,true_and]
          rw [r.choose_spec,eq,c.choose_spec]
        simpa only [←eq] using enc r.choose mem
      next => simpa using raw (rowRaw (e r.choose))
    next =>
      split
      next c => simpa using raw (colRaw (e c.choose))
      next => exact ⟨3,by intros; simp [pin]⟩
  obtain ⟨q,r,ql,s,h⟩ := run_of_net t p v run fits (by omega)
  exact run_not_crown r ql s (h.trans (table_correct N t rep e))

end CrownMixed.Naming
