import Research.FreeAndSupport
import Mathlib.Data.Fintype.Card

namespace CrownMixed
open FreeAndNet

structure Naming (I α : Type) where
  row : I → α
  col : I → α
  row_inj : Function.Injective row
  col_inj : Function.Injective col
  same : ∀ {i j}, row i = col j → i=j

namespace Naming
variable {I α : Type}

def val [DecidableEq α] (N : Naming I α) (i j : I) (a : α) : Bool :=
  decide (a=N.row i ∨ a=N.col j)

def Rep [DecidableEq α] [DecidableEq I] (N : Naming I α) (t : Net α) : Prop :=
  ∀ i j, t.eval (N.val i j) = decide (i≠j)

def pairs [Fintype I] [DecidableEq α] (N : Naming I α) : Nat :=
  (Finset.univ.filter (fun i => N.row i = N.col i)).card

def remove (N : Naming I α) (i : I) : Naming {j : I // j≠i} α where
  row j := N.row j.val
  col j := N.col j.val
  row_inj := fun _ _ h => Subtype.ext (N.row_inj h)
  col_inj := fun _ _ h => Subtype.ext (N.col_inj h)
  same := fun h => Subtype.ext (N.same h)

end Naming
end CrownMixed
