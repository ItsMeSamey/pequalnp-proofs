import CrownKernelSat
import Mathlib.Tactic.FinCases
namespace CrownKernelLink
open PEqualNP.Library.LRAT ParentCrown
theorem selectors_sat (s0 t0 s1 t1 s2 t2 s3 t3 u : BitVec 10) :
    let a := pin s0 0 0 0 0 ||| pin t0 0 0 0 0
    let b := pin s1 a 0 0 0 ||| pin t1 a 0 0 0
    let c := pin s2 a b 0 0 ||| pin t2 a b 0 0
    let d := pin s3 a b c 0 ||| pin t3 a b c 0
    pin u a b c d = 238 → FormulaSat CrownKernelFormula.F := by
  dsimp only
  intro yes
  let a := pin s0 0 0 0 0 ||| pin t0 0 0 0 0
  let b := pin s1 a 0 0 0 ||| pin t1 a 0 0 0
  let c := pin s2 a b 0 0 ||| pin t2 a b 0 0
  let d := pin s3 a b c 0 ||| pin t3 a b c 0
  let s : Sels := fun p => [s0,t0,s1,t1,s2,t2,s3,t3,u].getD p.val 0
  let o : Words := fun g => [a,b,c,d].getD g.val 0
  apply sat_of_semantics s o _ yes
  intro g
  fin_cases g <;> rfl
end CrownKernelLink
