import Std.Tactic.BVDecide

namespace ParentCrown

def pin (sel : BitVec 10) (a b c d : BitVec 9) : BitVec 9 :=
  (if sel.getLsbD 0 then 7 else 511) &&&
  (if sel.getLsbD 1 then 56 else 511) &&&
  (if sel.getLsbD 2 then 448 else 511) &&&
  (if sel.getLsbD 3 then 73 else 511) &&&
  (if sel.getLsbD 4 then 146 else 511) &&&
  (if sel.getLsbD 5 then 292 else 511) &&&
  (if sel.getLsbD 6 then a else 511) &&&
  (if sel.getLsbD 7 then b else 511) &&&
  (if sel.getLsbD 8 then c else 511) &&&
  (if sel.getLsbD 9 then d else 511)

end ParentCrown
