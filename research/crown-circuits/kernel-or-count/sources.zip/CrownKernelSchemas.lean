import CrownKernelFormula
import ThreeCrownPin
import Mathlib.Data.Fintype.Basic
namespace CrownKernelLink
open PEqualNP.Library.LRAT
abbrev P := Fin 9
abbrev C := Fin 9
abbrev J := Fin 10
abbrev G := Fin 4
abbrev Sels := P → BitVec 10
abbrev Words := G → BitVec 9
inductive Wire where
  | sel (p : P) (j : J)
  | pin (p : P) (c : C)
  | out (g : G) (c : C)
  | block (p : P) (c : C) (g : G)
  deriving DecidableEq

def code : Wire → Nat
  | .sel p j => 1+10*p.val+j.val
  | .pin p c => 101+9*p.val+c.val
  | .out g c => 201+9*g.val+c.val
  | .block p c g => 251+36*p.val+4*c.val+g.val

def decode (n : Nat) : Wire :=
  if n < 101 then .sel (Fin.ofNat 9 ((n-1)/10)) (Fin.ofNat 10 (n-1))
  else if n < 201 then .pin (Fin.ofNat 9 ((n-101)/9)) (Fin.ofNat 9 (n-101))
  else if n < 251 then .out (Fin.ofNat 4 ((n-201)/9)) (Fin.ofNat 9 (n-201))
  else .block (Fin.ofNat 9 ((n-251)/36)) (Fin.ofNat 9 ((n-251)/4)) (Fin.ofNat 4 (n-251))

theorem decode_code (w : Wire) : decode (code w) = w := by
  cases w with
  | sel p j => exact (by decide +kernel : ∀ (p : P) (j : J), decode (code (.sel p j)) = .sel p j) p j
  | pin p c => exact (by decide +kernel : ∀ (p : P) (c : C), decode (code (.pin p c)) = .pin p c) p c
  | out g c => exact (by decide +kernel : ∀ (g : G) (c : C), decode (code (.out g c)) = .out g c) g c
  | block p c g => exact (by decide +kernel : ∀ (p : P) (c : C) (g : G),
      decode (code (.block p c g)) = .block p c g) p c g

def pos (w : Wire) := 2*code w
def neg (w : Wire) := 2*code w+1
def assign (v : Wire → Bool) (n : Nat) := v (decode n)
@[simp] theorem lit_pos (v : Wire → Bool) (w : Wire) :
    litVal (assign v) (pos w) = v w := by simp [litVal,pos,assign,decode_code]
@[simp] theorem lit_neg (v : Wire → Bool) (w : Wire) :
    litVal (assign v) (neg w) = !v w := by
  have quo : (2*code w+1)/2=code w := by omega
  have remd : (2*code w+1)%2=1 := by omega
  simp [litVal,neg,assign,quo,remd,decode_code]

def mask (j : J) : BitVec 9 := [7,56,448,73,146,292][j.val]?.getD 0

def blockWire (p : P) (c : C) (j : J) : Option Wire :=
  if j.val<6 ∧ (mask j).getLsbD c.val then none
  else if j.val<6 ∨ j.val-6≥p.val/2 then some (.sel p j)
  else some (.block p c (Fin.ofNat 4 (j.val-6)))

def blockers (p : P) (c : C) := (List.finRange 10).filterMap (blockWire p c)
def auxiliaries (p : P) (c : C) (j : J) : List (List Nat) :=
  if j.val≥6 ∧ j.val-6<p.val/2 then
    let g := Fin.ofNat 4 (j.val-6)
    let b := Wire.block p c g
    let s := Wire.sel p j
    let w := Wire.out g c
    [[neg b,pos s],[neg b,neg w],[pos b,neg s,pos w]]
  else []
def cell (p : P) (c : C) :=
  (List.finRange 10).flatMap (auxiliaries p c) ++
  ((blockers p c).map (fun w => [neg (.pin p c),neg w]) ++
   [pos (.pin p c) :: (blockers p c).map pos])
def leftPin (g : G) : P := Fin.ofNat 9 (2*g.val)
def rightPin (g : G) : P := Fin.ofNat 9 (2*g.val+1)
def gate (g : G) (c : C) :=
  let a := Wire.pin (leftPin g) c
  let b := Wire.pin (rightPin g) c
  let z := Wire.out g c
  [[neg a,pos z],[neg b,pos z],[pos a,pos b,neg z]]
def target (c : C) := [if (238 : BitVec 9).getLsbD c.val then pos (.pin 8 c) else neg (.pin 8 c)]
def schema := (List.finRange 9).flatMap (fun p => (List.finRange 9).flatMap (cell p)) ++
    ((List.finRange 4).flatMap (fun g => (List.finRange 9).flatMap (gate g)) ++
    (List.finRange 9).map target)
set_option maxRecDepth 100000 in
set_option maxHeartbeats 3000000 in
theorem schema_eq : schema = CrownKernelFormula.F := by decide +kernel
end CrownKernelLink
