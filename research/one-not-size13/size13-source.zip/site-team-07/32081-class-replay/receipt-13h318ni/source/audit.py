import json
import re
from pathlib import Path
from functools import cache
from collections import Counter

graph_lists = re.findall(r'\(\[([0-9, ]+)\] : List ℕ\)', Path('L_meta_32081.lean').read_text())
assert len(graph_lists) == 6 and len(set(graph_lists)) == 1
entries = list(map(int, graph_lists[0].split(',')))
edges = list(zip(entries[::2], entries[1::2], strict=True))

@cache
def subs(mask):
    return tuple(i for i in range(256) if i & mask == i)

def census(active):
    truth = [any((s >> a) & (s >> b) & 1 for a,b in edges) for s in range(256)]
    conflict = []
    for a,b in edges:
        pair = (1<<a)|(1<<b)
        if active & pair != pair:
            continue
        restrictions = {tuple(truth[z|i] for i in subs(pair)) for z in subs(active^pair)}
        if {(False,False,False,True),(False,True,True,True)} <= restrictions:
            conflict.append(pair)
    ways = {0: Counter({0:1})}
    for used in subs(active):
        for group in subs(active^used):
            if not group or any(group & p == p for p in conflict):
                continue
            later = active ^ used ^ group
            for z in subs(used):
                profiles = {tuple(truth[z|u|v] for v in subs(later)) for u in subs(group)}
                if len(profiles)>2:
                    break
            else:
                dest = ways.setdefault(used|group,Counter())
                for d,n in ways[used].items():
                    dest[d+1] += n
    return ways[active]

full, deletion = census(255), census(253)
assert min(full)==6 and full[6]==1528 and min(deletion)==5
print(json.dumps(dict(edges=edges,full=full,deletion=deletion)))
