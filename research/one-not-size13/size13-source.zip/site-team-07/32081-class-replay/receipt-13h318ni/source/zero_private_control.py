"""Minimum class count satisfying fixed-context row and pair-conflict obstructions."""
from functools import lru_cache
from itertools import combinations
from five_branch09 import TABLE, FULL, words, rows

def bound(fixed, value, raw_fork=0):
    active = FULL ^ fixed
    for i in range(8):
        bit = 1 << i
        if active & bit and all(TABLE[value|x] == TABLE[value|x|bit] for x in words(active^bit)):
            active ^= bit
    bad=[]
    for i,j in combinations((i for i in range(8) if active>>i&1),2):
        p=(1<<i)|(1<<j)
        t=set(rows(active^p,p,value))
        if {8,14} <= t:
            bad.append(p)
    @lru_cache(None)
    def count(e):
        remaining=active^e
        if not remaining:
            return 0
        return 1+min(count(e|g) for g in words(remaining) if g and
                     not any(g&m==m for m in bad) and
                     all(len(set(rows(g,remaining^g,value|z)))<=2 for z in words(e)))
    return count(raw_fork & active) if raw_fork else max(0,count(0)-1)

if __name__=='__main__':
    print([(bound(1<<i,0),bound(1<<i,1<<i)) for i in range(8)])
