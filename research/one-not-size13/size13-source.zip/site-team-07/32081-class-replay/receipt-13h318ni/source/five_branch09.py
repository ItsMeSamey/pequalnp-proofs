"""Verify the ordered first-branch partition bound on the eight-input edge function."""
from functools import lru_cache
from itertools import combinations

EDGES = [(0,3),(1,4),(0,5),(2,5),(1,6),(2,6),(3,6),(0,7),(1,7),(2,7),(4,7),(5,7)]
FULL = 255
TABLE = tuple(int(any(x & (1<<i) and x & (1<<j) for i,j in EDGES)) for x in range(256))

@lru_cache(None)
def words(mask):
    return tuple(w for w in range(256) if w & mask == w)

@lru_cache(None)
def rows(inside, outside, context=0):
    return tuple(sum(TABLE[context|x|y]<<j for j,y in enumerate(words(outside))) for x in words(inside))

def conflict(i,j):
    pair=1<<i|1<<j
    tables=set(rows(FULL^pair,pair))
    return 8 in tables and 14 in tables

CONFLICTS = [1<<i|1<<j for i,j in combinations(range(8),2) if conflict(i,j)]

@lru_cache(None)
def choices(earlier):
    remaining=FULL^earlier
    return tuple(g for g in words(remaining) if g and not any(g&c==c for c in CONFLICTS)
                 and all(len(set(rows(g,remaining^g,e)))<=2 for e in words(earlier)))

def partitions(prefix=(), earlier=0, limit=6):
    if earlier==FULL:
        yield prefix
    elif len(prefix)<limit:
        for g in choices(earlier):
            yield from partitions(prefix+(g,),earlier|g,limit)

if __name__=='__main__':
    cases=list(partitions())
    if len(cases)!=1528 or any(len(p)!=6 for p in cases):
        raise ValueError('unexpected ordered partitions')
    print('0 partitions with at most 5 classes; 1528 with 6 classes')
