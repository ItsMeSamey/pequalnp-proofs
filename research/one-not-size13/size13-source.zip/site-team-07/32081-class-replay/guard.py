"""Prepare is source-only. Execution requires the explicit run argument."""
import fcntl,hashlib,json,os,resource,signal,subprocess,sys,tempfile,time
from pathlib import Path
D=Path(__file__).resolve().parent
S=Path('/workspace/scratch/site-team-07/32081-class-replay/source')
L=Path('/workspace/scratch/pnp-native-search.lock')
entry='audit.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
def require(cond,msg):
    if not cond:raise RuntimeError(msg)
raw=(D/'pins.json').read_bytes()
require(sha(raw)=='036713037f587510071029b3506982d123ceb5938bbae2291a2a99b8a072e642','pin manifest')
p=json.loads(raw)
key=(p['lock_dev'],p['lock_ino'])
def inode(st):return (st.st_dev,st.st_ino)
def check_lock(fd=None):
    require(inode(os.lstat(L))==key and (fd is None or inode(os.fstat(fd))==key),'canonical lock inode changed')
def check_kernel_lock():
    for line in Path('/proc/locks').read_text().splitlines():
        cols=line.split()
        if len(cols)<8 or cols[1:5]!=['FLOCK','ADVISORY','WRITE',str(os.getpid())]:continue
        major,minor,ino=cols[5].split(':')
        if (os.makedev(int(major,16),int(minor,16)),int(ino))==key:return line
    raise RuntimeError('canonical kernel lock entry missing')
def read_inputs():
    data={n:(S/n).read_bytes() for n in p['pins']}
    for n,b in data.items():require(sha(b)==p['pins'][n],n)
    return data
def main():
    check_lock();data=read_inputs()
    if sys.argv[1:]==['prepare']:
        print(json.dumps(dict(status='prepared',source_files=len(data),lock_dev_inode=key,pin_sha256=sha(raw))));return
    require(sys.argv[1:]==['run'],'use prepare or run')
    job=Path(tempfile.mkdtemp(prefix='receipt-',dir=D));rec={'pin_sha256':sha(raw),'limits':[3,5,96],'canonical':key,'status':'preflight'}
    proc=None
    try:
        fd=os.open(L,os.O_RDONLY|os.O_NOFOLLOW);check_lock(fd);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);check_lock(fd)
        rec['kernel_before']=check_kernel_lock();snapshot=job/'source';snapshot.mkdir()
        for n,b in read_inputs().items():(snapshot/n).write_bytes(b)
        # Isolate imports from user/site paths and from any previous bytecode.
        loader="import sys,runpy;sys.path.insert(0,sys.argv[1]);runpy.run_path(sys.argv[1]+'/'+sys.argv[2],run_name='__main__')"
        def limit():
            os.setpriority(os.PRIO_PROCESS,0,15)
            require(os.getpriority(os.PRIO_PROCESS,0)==15,'child niceness')
            # This single-process checker uses no external workers. Forbid fork/threads
            # for uid 1000 so the hard CPU/AS ceilings apply to the entire group.
            resource.setrlimit(resource.RLIMIT_NPROC,(0,0))
            resource.setrlimit(resource.RLIMIT_CPU,(3,3))
            resource.setrlimit(resource.RLIMIT_AS,(96<<20,96<<20))
        require(os.geteuid()!=0,'unprivileged uid required')
        start=time.monotonic();peak=0;peakcpu=0
        with (job/'stdout.txt').open('wb') as log:
            proc=subprocess.Popen(['/usr/bin/python3','-I','-S','-B','-c',loader,str(snapshot),entry],cwd=snapshot,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limit)
            while True:
                check_lock(fd)
                if time.monotonic()-start>=5:raise RuntimeError('wall limit')
                if proc.poll() is not None:break
                try:
                    cols=Path(f'/proc/{proc.pid}/stat').read_text().rsplit(')',1)[1].split()
                    require(int(cols[2])==proc.pid,'unexpected process group')
                    rss=int(cols[21])*os.sysconf('SC_PAGE_SIZE');cpu=sum(map(int,cols[11:15]))/os.sysconf('SC_CLK_TCK')
                    peak=max(peak,rss);peakcpu=max(peakcpu,cpu)
                    require(cpu<3 and rss<=96<<20,'CPU/RSS limit')
                except FileNotFoundError:pass
                time.sleep(.01)
        check_lock(fd);rec['kernel_after']=check_kernel_lock();usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        rec.update(wall=time.monotonic()-start,cpu=usage.ru_utime+usage.ru_stime,peak_rss_kib=usage.ru_maxrss,observed_peak_bytes=peak,returncode=proc.returncode)
        require(rec['cpu']<=3 and rec['wall']<=5 and rec['peak_rss_kib']<=98304,'final resource check')
        require(proc.returncode==0,'checker failed')
        out=(job/'stdout.txt').read_bytes()
        witness=json.loads(out);rec.update(witness_sha256=sha(out),results=witness)
        rec['status']='passed'
    except BaseException as e:
        rec.update(status='failed',reason=str(e))
        if proc is not None and proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        if proc is not None:
            usage=resource.getrusage(resource.RUSAGE_CHILDREN)
            rec.update(wall=time.monotonic()-start,cpu=usage.ru_utime+usage.ru_stime,peak_rss_kib=usage.ru_maxrss,observed_peak_bytes=peak,returncode=proc.returncode)
        raise
    finally:
        (job/'receipt.json').write_text(json.dumps(rec,indent=2));print(job/'receipt.json',flush=True)
if __name__=='__main__':main()
