# The separate suffix fork at size 14

Assume singleton private y, four distinct raw bypass taps used once in the prefix, earliest internal fork H with two outlets, and one further double fork K in the suffix (a duplicated suffix raw use is allowed). With 13 binary gates the one excess beyond the five required outlets is exhausted. Cutting H gives the ordinary two-sibling uncanalized classification; that part uses pivotality, not independence of the untouched triple C. Write the two shapes as (y∨Q)∧¬R and (y∧¬R)∨Q. If R=00 its pair is the full neighborhood of y, forcing disjoint Q to be positive. In every other case ¬R requires an inverter in its own side subtree, so Q is positive. Thus either Q is an edge and the existing gate-for-gate extraction applies, or Q is one of four independent pairs.

For an independent Q=uv fix y=0 and one of u,v to zero. Both merge orders now give H=0 for all remaining raw values. Each case leaves an induced triangle:

| y | Q | additional zero pin | triangle |
|---|---|---|---|
| 2 | 01 | 0 | 147 |
| 3 | 15 | 1 | 057 |
| 4 | 06 | 0 | 257 |
| 4 | 56 | 6 | 057 |

Set every other raw outside the triangle to zero. Replace both cut pins by zero and discard the prefix. In this restricted suffix all three essential raws occur once except for any surplus attributable to K. Classify a triangle raw as inside if it reaches K in the cut suffix, counting K itself if raw. All its paths then pass through K because there is no earlier fork on its path. If K is raw there is no other inside raw. The outside raws have unique paths to the output. Pigeonhole gives a pair on the same side.

For an outside pair, whenever the restricted output depends on both, their unique paths to their binary least common ancestor transmit fixed literals: a gate with its other input fixed is either absorbing or transmits its input, and every inverter has fixed sign. The LCA has one fixed binary connective. Downstream gates can only select a unary postprocessing of its result after the other raws are fixed. The same argument holds for an inside pair in the tree feeding K; even when K has two uses afterwards the entire further circuit sees their dependence through one Boolean bit, so the transfer on a genuinely bivariate face can only be identity or complement. Both same-side face functions therefore belong to a single complement pair of truth tables. On a triangle, fixing the third raw to zero yields positive AND on the other two; fixing it to one yields positive OR. These functions are neither equal nor complements. This is impossible on either side, including when K disappears under specialization.

Thus all independent-Q cases in this size-14 suffix-fork layout are literally excluded. Edge-Q still admits an equal-size physical replacement, as in physical-bridge.md. No assumptions about C being independent or x2 and x6 having unique suffix paths are needed. The proof does not handle an extra occurrence entering the prefix, where the local read-once shape can change.
