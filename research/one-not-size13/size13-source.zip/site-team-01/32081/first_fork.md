# The earliest internal fork in the eight-input graph target

Work with a trimmed strict circuit as in normalization.md. Assume its unique NOT is live; when there is no NOT, the antecedent circuit itself is an admissible monotone witness. Let $H$ be its first gate in evaluation order that has fanout at least two. Primary inputs may already branch. Classify the primary inputs relative to $H$:

* $B$ contains exactly those primaries that reach $H$ and for which every path to the output passes through $H$.
* $A$ contains the other primaries that reach $H$. Each also has a path to the output avoiding $H$.
* $C$ contains the remaining primaries.

The exact, maximal choice of $B$ matters to the outlet count. For each fixed assignment on $A$, the downstream function sees $B$ through the single bit $H$. A necessary condition is that the assignments on $B$ yield at most two different Boolean functions on $C$. This argument applies even if downstream gates read additional functions of $A$ and $C$.

## Exact cofactor calculation at independent assignments

Write $N_C(U)$ for the vertices in $C$ adjacent to any vertex of $U$. Let $S\subseteq A$ and $T\subseteq B$ be the true inputs on the two blocks. If $S\cup T$ contains an edge, the residual function on $C$ is constant true. Otherwise, on the set $Y$ of true variables in $C$, it is

$$
  [Y\text{ contains an edge}]\ \lor\ [Y\cap (N_C(S)\cup N_C(T))\ne\varnothing].
$$

Distinct masks $N_C(S)\cup N_C(T)$ yield distinct rows, witnessed by singleton $Y$. The zero assignment on $C$ distinguishes every such row from constant true. A nonindependent $S$ produces only the constant row.

**For the row-count test, checking the empty $S$ and each singleton $S$ suffices.** At the empty setting, if $B$ contains an edge, the constant row is present. Its coexistence with the baseline leaves no room for a nonempty $B$-to-$C$ neighborhood. If all these neighborhoods are empty, every later setting has at most two rows. If $B$ is independent, the empty-setting test means that all $N_C(b)$ are either empty or a single common set $U$. At any later independent $S$, the ordinary rows are then the baseline and possibly its augmentation by $U\setminus N_C(S)$. A violation requires an internal constant row (some $b$ is joined to $a\in S$), a surviving $b'$ outside $N(S)$ with neighborhood $U$, and a $c\in U\setminus N_C(S)$. The same $b,b',c$ witness a violation already at $S=\{a\}$. This sufficiency concerns cardinality; proving phase and outlet constraints below also uses larger independent settings.

For example $B=\{0,2\}$, $A=\{1,3,4,6\}$, $C=\{5,7\}$ passes the empty-setting test. At $S=\{3\}$, the three private states $\varnothing,\{0\},\{2\}$ give baseline, constant true and augmented baseline, respectively.

## Fixed phase and outlet accounting

In any two-row context, the row at the all-zero private input is the lower row by target monotonicity. It is encoded by H=0, the strictly higher row by H=1. If the only NOT is outside the gate cone of H, the prefix is monotone in the private inputs. If the NOT is upstream or at H, the suffix is monotone in the cut H bit. Fix the shared inputs and a distinguishing assignment on untouched inputs. Every wire entering the suffix without passing H is independent of private bits, by domination; even a negated ancillary signal on a bypass is fixed. Hence the suffix cannot encode the two rows in reverse order. Single-row contexts remain unconstrained.

If raw p and q each have a single path to H, their paths first merge at a fixed binary AND/OR. Every genuinely bivariate restriction on p,q has the same two literal signs and output sign, since each nonconstant unary gate chain has the sign prescribed by the fixed NOT parity. The binary merge type is fixed. Thus all such restrictions must be identical. Both positive AND and positive OR cannot occur. Each incompatible pair forces at least one of its raw variables to have two paths to H; such raw variables cover the incompatibility graph.

Since H is the earliest internal fork, multiple paths into H require different raw outgoing edges. Every member of A also needs a separate initial edge to bypass H (sharing it would require an earlier internal fork). These costs add even for the same raw variable. In a trimmed circuit on eight essential inputs with b binary gates and one unary gate, excess over one outgoing edge per nonsink equals b−7 by edge counting. Size 14 permits six excess edges. Every member of A, each multiply routed raw variable, and H itself each cost one.

## Exact maximal private block {0,2}

Let X and Y denote inputs 0 and 2. Their common neighbors are 5 and 7 and their respective exclusive neighbors are 3 and 6. If C contains a common neighbor, the empty-setting row test forces both 3 and 6 into A (the two private neighborhoods into C are nonempty and must be equal). Turning on 3 then gives three rows: empty private set produces the baseline, X produces constant true, Y augments the baseline by the common neighbor not adjacent to 3. Neither common neighbor can therefore be in C. Nor can C contain both 3 and 6: the empty setting already yields three rows.

If 6 is in C, A contains 3,5,7. At the empty visible setting the fork bit is Y and at setting {3} it is X. Indeed 3 masks the residual edge from Y to 6, and X closes the edge 0–3. If 3 is in C, interchange 0 with 2 and 3 with 6. In either case the exclusive selector in A switches between literals on distinct free variables, so it is binate and needs two paths into H. Even allowing arbitrary context phases cannot make literals on distinct coordinates pointwise ordered. If neither 3 nor 6 is in C, all of 3,5,6,7 are in A. Here the settings {3} and {6} give X and Y.

For either p=5 or p=7, turning p on changes the fork bit to X OR Y at both of the chosen visible settings: the visible set is still independent and either private vertex now closes an edge. At the setting giving X before p is turned on, set X=0; the cofactor on (p,Y) is AND. At the setting giving Y before p is turned on, set X=1; that cofactor on (p,Y) is OR. Exchanging X and Y gives the same conflict on (p,X). The conflict graph therefore contains all four edges between {5,7} and {0,2}. Two disjoint edges require at least two distinct raw inputs to be multiply routed into H.

If C contains 3 or 6 the cost is at least three bypasses, two conflict-cover vertices, the additional binate selector, and H itself: seven. Otherwise it is four bypasses, two conflict-cover vertices and H: again seven. This excludes all size-14 circuits whose earliest internal fork has **exact maximal dominated raw block {0,2}**, including cases where one or both private primaries fork before H. Other private blocks and circuits with no internal fork remain outside this elimination.
