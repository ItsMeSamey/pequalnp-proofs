# Two more raw-2 donor rectangles require at least 15 gates

Work with the normalized live eight-input circuit for L_meta_32081, one NOT on raw 2, and b binary AND/OR gates. Fanout counts operand slots. Excess E, the sum of outgoing degree minus one over nonsinks, is b−7. Keep forwarding nodes during constant restriction and trimming, so the surviving graph uses subsets of the original slots and vertices. Suppressing unary nodes after this count cannot increase total excess.

## A signed five-cycle lower bound

A DAG computing the edge function of a five-cycle needs at least three units of excess even if all binary AND/OR gates have arbitrary signed inputs and the output may be complemented. Folding unary NOTs into signed edges preserves excess: suppressing a unary wire with d outgoing slots transfers its contribution d−1 to its predecessor. Gates reading the same source twice reduce to aliases or constants and can be simplified without increasing excess.

Every cycle variable u remains pivotal when any other variable v is fixed to either value. At v=0 activate a neighbor of u other than v. At v=1 use v alone if uv is an edge, otherwise add a neighbor of u outside the neighborhood of v. Such a vertex exists because nonadjacent five-cycle vertices have unequal neighborhoods of equal size.

The first binary gate reads two distinct raw variables u,v. Holding either operand at its signed absorbing value leaves the other pivotal despite the gate being constant. Therefore u and v both have another reader. Under E≤2 they account for all excess, occur twice each, and every gate output has fanout one. Both root branches must be internal since fixing a raw child at its absorbing value would make the output constant. Each root branch contains a bottom gate with two raw inputs. The same pivotality argument requires each such gate to use the two duplicated raws u,v. Together the two bottom gates consume all four occurrences.

The four assignments of u,v give four distinct residual functions on the other raws. Each vertex has an exclusive outside neighbor. The singleton row for that vertex accepts its exclusive neighbor that the empty and other singleton row reject. For adjacent u,v the doubleton row is constant true and the others reject the empty outside assignment. For nonadjacent u,v the doubleton row accepts both exclusive neighbors. Thus the bits emitted by the two bottom gates must form an injective, hence bijective, encoding of four assignments. Each bit of such an encoding must take value one twice. A signed AND/OR of two distinct raw variables takes value one once or three times, a contradiction.

## Product L=(0 OR 4), R=(1 OR 7), A=L AND R

Each of the four raw donors has a reader outside its OR. For 0 and 4 the respective independent supports {4,3} and {0,1} already make L true, and adding the indicated variable creates 03 and 14 respectively. For either endpoint of 17 use the singleton of the other endpoint. Raw 2 needs a reader beside its NOT because the function increases in 2 on {5}. Thus these five raw inputs are distinct forks.

Set 1,4,7 to zero, retaining the five-cycle 0–3–6–2–5–0. The three fixed raw forks disappear. R=0 kills A, so if L survives it loses the pin into A, reducing its excess. If L disappears, raw 0 remains essential and loses its L outlet. Either way the loss totals at least four. The signed five-cycle needs at least three, giving E≥7.

## Product L=(0 OR 7), R=(1 OR 5), A=L AND R

The adjacent donors 0,7 require bypasses of L by their singleton tests. For R, the independent support {4,5} makes 1 pivotal and {0,1} makes 5 pivotal. Again raw 2 also forks, giving five raw fork units.

Suppose E≤6. Then L has only its reader A. Otherwise the fifth raw fork and L exhaust all six units with the other four raw forks. Raw 3 and raw 6 reach none of these forks because L only reads 0 and 7 and raw sources have no predecessors. Each would have a unique path to the output. At the first meeting of their two paths the binary operator and the two path signs are fixed. On a genuinely bivariate restriction all on-path side inputs are neutral, so the exceptional corner of the binary truth table is fixed even if its common suffix complements it. But the empty outside context gives AND(3,6) with exceptional corner 11, and the independent outside context {0,1} gives OR(3,6) with exceptional corner 00.

Set 1,4,5 to zero, retaining the five-cycle 0–3–6–2–7–0. Raw forks 1 and 5 disappear. R=0 kills A and its sole-use donor L. Raw 0 and raw 7 both stay essential and each loses its L pin. These four losses leave at most two units for a signed five-cycle, which is impossible.

Both products therefore require at least fourteen binary gates and the additional NOT. This covers the specified three physical gates in each case with arbitrary suffix sharing. The third rectangle is handled in [the triangle restriction](raw2-fixed-donor-lower.md). These arguments concern the indicated circuit patterns. They do not give an unrestricted monotone size lower bound.
