# Uncanalized four-tap prefixes

Consider an earliest internal fork H with singleton private input y, four bypass taps A, and excess budget five. H is binary-fanout and read-once on the five prefix inputs. The suffix is a formula with one leaf for each of the seven other raws and two H leaves. The untouched triple C must be independent. The conclusions below either contradict this route, eliminate the NOT, or give a same-size representative with only two taps at H.

The open neighborhoods, in vertex order, are 357,467,567,06,17,027,123,01245. No nonneighbor a of y contains N(y) in N(a). A full raw assignment distinguishes the two values of y with any prescribed single tap a pinned to either value: if a=0 activate a different neighbor of y; if a=1 use a alone when adjacent to y, otherwise activate a neighbor of y outside N(a) as well. Both assignments are independent before adding y. Therefore no single tap can be a sibling on the private path to H: it would block dependence on y at its absorbing value. Positive phase is forced wherever y is distinguished, so there is no NOT on this path.

At three taps there can be only one sibling block. H is then canalized by fixing y. At four taps, if H is uncanalized in y, its private path has two sibling blocks of size two. One joins by OR, the other by AND, because identical joins would give a canalizing setting of y. A two-leaf read-once side function blocks one or three corners of its two raw inputs. Three corners would block an entire singleton literal and is impossible. Consequently H has one of the two forms

    (y OR Q) AND (NOT R)
    (y AND (NOT R)) OR Q

where Q and R are cubes on disjoint tap pairs. Each cube hides y on its entire satisfying subcube. For a cube pinning positive taps P and negative taps Z, this happens exactly when P contains an edge, or P is independent, avoids N(y), and N(y) is contained in N(P) union Z. Indeed, when P contains a neighbor of y an independent P already witnesses sensitivity; otherwise an uncovered, unfixed neighbor of y can be added to P. Conversely an independent completion cannot activate any neighbor of y under the displayed coverage condition.

A positive pair hiding y is either an edge or one of the following independent pairs (inspect the eight neighborhoods above): 06 or 56 for y=4, 15 for y=3, 01 for y=2. A 00 cube requires the two variables to be all of N(y), so y=3 or 4. A mixed cube with positive tap a and negative tap b requires a nonneighbor of y covering all N(y) except b, with b a neighbor. These lists give the following cases.

1. If R is 00, its two variables are all of N(y). The disjoint cube Q must be positive since each other type needs a neighbor of y as a negative pin. If Q is independent, y=3,Q=15 leaves C=247, and y=4,Q=06 or 56 leaves C=235 or 023. All three triples contain an edge.
2. In every other case NOT R is nonmonotone in its two tap inputs (that is, it is not monotone increasing). The unique physical NOT is in this block, so Q is a positive product and the suffix is positive. Whenever Q is a graph edge, regardless of where the NOT lies, remove Q from its OR merge in H and append OR Q to the output. Q=0 rows are unchanged; Q=1 rows must be true. The product gate stays available and its former merge pays for the new output merge. In a trimmed result H has the remaining two taps, or the original fork disappears. This extraction applies also to the edge-Q case of item 1.
3. With Q a nonedge and R positive, R must be an edge: the listed independent forced pairs for a common y are never disjoint. Set NOT R to one. This only raises H, on rows where R=1 and the target is already true. A positive suffix preserves the result and the sole NOT disappears.
4. With Q a nonedge and R mixed, the possibilities below list the ordered taps (positive a, negative b) and the resulting untouched triples. The preceding neighborhood test gives every entry.

| y | Q | admissible (a,b) | corresponding C |
|---|---|---|---|
| 4 | 06 | (2,1), (5,1) | 357, 237 |
| 4 | 56 | (0,1), (2,1) | 237, 037 |
| 3 | 15 | (2,0), (7,6) | 467, 024 |
| 2 | 01 | none | |

Only 024 is independent. Here Q=x1 AND x5, R=x7 AND NOT x6. Test the two outside raw leaves x2,x6. At zero background H=0 regardless of this pair and their output table is AND by edge 26. With background x3=x5=1 and all other outside-pair raws zero, H=1 throughout this face for both possible merge orders, and the table is OR by edges 25 and 36 and nonedge 35. Their unique suffix occurrences have a fixed binary least common ancestor; a genuinely bivariate positive AND and positive OR cannot both arise. This excludes the remaining two signatures.
