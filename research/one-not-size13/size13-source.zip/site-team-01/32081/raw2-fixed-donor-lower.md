# The specified raw-2 donor requires at least 15 gates

Consider a strict, output-live circuit for the issued twelve-edge target. Its only NOT reads raw input 2. Assume it contains the three physical gates L = x0 OR x6, R = x1 OR x3, and A = L AND R. Each wire may feed other gates. Write d(w) for the number of outgoing operand slots. The sum of d(w)−1 over nonsinks equals b−7 for eight essential inputs and b binary gates, by counting slots and nonsinks. Unary gates cancel in this identity.

Each raw input to L and R needs a second outgoing slot. In the table the named OR is already true on the independent support. Adding the input changes the target while preserving the OR.

| Raw input | OR | Independent support | New edge |
|---|---|---|---|
| 0 | L | {5,6} | 05 |
| 6 | L | {0,1} | 16 |
| 1 | R | {3,4} | 14 |
| 3 | R | {0,1} | 03 |

Raw input 2 also needs a second reader. If its only reader were its NOT, the positive downstream circuit would be nonincreasing in 2. On the support {5}, adding 2 changes the target from false to true.

Fix 0, 2, 3, 5 and 6 to zero. The remaining function is the triangle on 1, 4 and 7, equivalently their majority. Propagate constants and trim to the designated output. For accounting, retain a unary identity at each gate that must forward one surviving pin. The resulting DAG uses subsets of the original slots and vertices. Excess cannot increase at any surviving nonsink. Each deleted nonsink loses its nonnegative original contribution. The four fixed raw inputs 0, 2, 3 and 6 therefore lose at least four units.

A fifth unit disappears. L is zero, so A is zero and its incoming slot from R disappears. If R survives, it retains another consumer and losing the slot into A lowers its excess by at least one. Otherwise raw 1 loses its slot into R. Raw 1 remains essential and originally had at least two outgoing slots. In either case this loss is separate from the four fixed-source losses.

Suppressing a forwarding node preserves excess when its outgoing slots transfer to its remaining predecessor. Replacing a forwarding output by its predecessor also preserves excess after trimming. A binary gate on repeated aliases can be replaced by a forwarding node, losing its redundant slot. Thus strict simplification cannot raise excess.

Every strict positive DAG for three-input majority has at least two units of excess. The first binary gate reads two distinct raw inputs. For an AND, hold either operand at zero and the third raw input at one. The other operand is pivotal while the gate is constant. For an OR, hold either operand at one and the third input at zero. The other operand is again pivotal. Both operands therefore have a second outgoing slot.

It follows that b−7−5 ≥ 2. The original circuit uses at least fourteen binary gates and the additional NOT. This excludes the three specified gates jointly at sizes 13 and 14, with arbitrary suffix sharing. The [larger private-cone example](raw2-private-correction.md) uses exactly this donor. A donor computed by different physical gates requires its own proof. No lower bound on unrestricted monotone size follows.

The issued statement is L_meta_32081.lean, SHA-256 785f5e8bb0014fce3b6675fd4ac2605bceabb97e6c3aa7fae027afb9970b5b32. The evaluator is Defs/CircuitLowerBounds.lean, SHA-256 695e454d3e424e2cae4fa4677741681eac11de0462d0d9bc087a0e6a6ba03f69.
