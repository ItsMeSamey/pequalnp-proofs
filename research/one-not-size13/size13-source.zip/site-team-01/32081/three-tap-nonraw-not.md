# Singleton private input, three taps, NOT on a computed tap expression

Assume binary excess at most five and three bypass taps A before the earliest internal fork H with unique private raw y. A three-tap circuit has exactly one excess use after the H fork and bypass charges; it is in the suffix by singleton-three-taps.md, since the four untouched vertices C contain an edge. In particular G[C] must be a single nonempty complete bipartite component with possible isolated vertices. By four-tap-uncanalized.md no single tap blocks y at either of its two values, so all three taps form one read-once subtree. The fixed-zero cofactor exclusion and fixed-one cofactor exclusions in singleton-canalization.md force H=y OR Q and y in {0,1,2,5,7}.

Assume the NOT is in Q with a computed binary or ternary-input operand. Whenever Q=1, the cut bit conceals any change to y. The two-literal and general cube test from four-tap-uncanalized.md applies: an independent positive set P with negative pins Z hides y precisely when P avoids N(y) and N(y) is contained in N(P) union Z.

If Q=NOT P with a positive formula on all three taps, Q is true at their zero assignment. Hence every neighbor of y is among the taps. The allowed y all have degree at least three; 7 has degree five. Thus y is 0,1,2 or 5 and A=N(y). Each neighbor alone distinguishes y, forcing P to be true there, hence P is the OR of the three neighbors. In the four respective cases C induces the paths 4–1–6–2, 3–0–5–2, the matching 03+14, and the path 4–1–6–3. None passes the required biclique test.

Otherwise the NOT negates a two-tap gate and the remaining raw tap t joins it at the root of Q. An OR join lets the single pin t=1 hide y, impossible. At an AND join, Q=t AND NOT(uv) would allow both t=1,u=0 and t=1,v=0 to hide y. This forces t to be a nonneighbor covering all N(y), contrary to the eight open neighborhoods in four-tap-uncanalized.md.

It remains to test Q=t AND NOT(u OR v). The cube test forces t nonadjacent to y and N(y) minus N(t) contained in {u,v}. Set t=y=0. H becomes constant zero; after propagation the suffix computes G minus {t,y} with at most one spare use. No triangle can remain (three-variable majority requires two extra uses, even with unary signs; see pair_rules.md). Thus {t,y} hits the three triangles 147,057,257. If y=7, the only possible t are 3,6, and each leaves at least three of its five neighbors uncovered. Every other allowed y is adjacent to 7, excluding t=7. A hitting pair avoiding 7 must contain 5, since otherwise it needs 0,2 and at least one of 1,4. Its second vertex must be 1 or 4. All remaining possibilities are as follows.

| y | t | forced u,v | C | induced obstruction |
|---|---|---|---|---|
| 1 | 5 | 4,6 | 0,2,3,7 | path 3–0–7–2 |
| 5 | 1 | 0,2 | 3,4,6,7 | edges 36 and 47 |
| 5 | 4 | 0,2 | 1,3,6,7 | path 3–6–1–7 |

Each violates the biclique test. This exhausts computed operands of the unique NOT. A NOT applied to a single raw tap is a separate route.
