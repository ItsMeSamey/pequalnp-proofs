"""Validate a single supplied 14-gate/one-NOT occurrence forest. No import-time search.

Nodes are JSON arrays ["raw",i], ["fork",j], ["not",child], or
["and"|"or"|"bin",left,right]. Each "bin" is an unfixed operation, not a
per-input choice. Name every physical fork, including multiply used raw wires.
"""
from collections import Counter


def compile_forest(trees):
    """Compile a strict forest, rejecting inconsistent pins, counts or topology."""
    f = len(trees) - 1
    if f not in (5, 6):
        raise ValueError("expected five or six named fork blocks plus output")
    roots, gates, fresh, incoming = [], [], [], []
    for block, tree in enumerate(trees):
        raw_slots, parent_slots = [], []

        def visit(node):
            if not isinstance(node, (tuple, list)) or not node:
                raise ValueError("expected occurrence-tree node")
            op, *args = node
            if op in ("raw", "fork"):
                if len(args) != 1 or type(args[0]) is not int:
                    raise ValueError("invalid leaf index")
                w = args[0]
                if op == "raw" and 0 <= w < 8:
                    raw_slots.append(w)
                    return w
                if op == "fork" and 0 <= w < block:
                    parent_slots.append(w)
                    return roots[w]
                raise ValueError("invalid primary or non-earlier fork")
            if op not in ("bin", "and", "or", "not") or len(args) != (1 if op == "not" else 2):
                raise ValueError("invalid gate or arity")
            pins = tuple(visit(a) for a in args)
            if len(pins) == 2 and pins[0] == pins[1]:
                raise ValueError("strict normalization forbids equal sibling wires")
            gates.append((op, pins))
            return 7 + len(gates)

        if not isinstance(tree, (tuple, list)) or not tree:
            raise ValueError("expected nonempty block tree")
        if tree[0] == "fork":
            raise ValueError("bare old-fork alias is not a new physical vertex")
        roots.append(visit(tree))
        fresh.append(tuple(raw_slots))
        incoming.append(tuple(parent_slots))

    if sorted(w for slots in fresh for w in slots) != list(range(8)):
        raise ValueError("each raw label must have precisely one origin")
    if len(gates) != 14 or sum(op == "not" for op, _ in gates) != 1:
        raise ValueError("expected thirteen binary gates and one unary NOT")
    fanout = Counter(w for _, pins in gates for w in pins)
    named_degrees = sorted(fanout[w] for w in roots[:-1])
    actual_forks = {w for w, count in fanout.items() if count > 1}
    if actual_forks != set(roots[:-1]) or len(actual_forks) != f:
        raise ValueError("declared forks differ from physical forks")
    if named_degrees != ([2]*6 if f == 6 else [2]*4+[3]):
        raise ValueError("wrong fork-degree profile")
    return dict(gates=gates, output=roots[-1], roots=roots, fresh=fresh, incoming=incoming)


def evaluate_labeling(compiled, choices, row):
    """Evaluate one global operation assignment on one input, bit i = raw i."""
    if type(row) is not int or not 0 <= row < 256:
        raise ValueError("expected eight-bit assignment")
    if len(choices) != sum(op == "bin" for op, _ in compiled["gates"]):
        raise ValueError("one connective required per unresolved binary node")
    if any(op not in ("and", "or") for op in choices):
        raise ValueError("unknown binary connective")
    labels = iter(choices)
    values = [(row >> i) & 1 for i in range(8)]
    for op, pins in compiled["gates"]:
        if op == "bin":
            op = next(labels)
        a = values[pins[0]]
        if op == "not":
            values.append(1-a)
        elif op == "and":
            values.append(a & values[pins[1]])
        else:
            values.append(a | values[pins[1]])
    return values[compiled["output"]]
