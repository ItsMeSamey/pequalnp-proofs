# A private correction after a safe raw-2 OR push needs an extra gate

Write `ij` for the conjunction of raw inputs `i` and `j`. The following is a normalized one-inverter circuit for the twelve edges in `L_meta_32081.lean`. Each displayed OR or AND is binary, with the iterated ORs associated in any fixed order.

```
A  = (0 OR 6) AND (1 OR 3)
r  = 05
P0 = 2 OR r
P  = P0 OR A
g  = 5 OR 6 OR 7 OR 03
Q  = (NOT 2) AND 47
R  = 14 OR 07 OR 17 OR 57
F  = R OR Q OR (P AND g)
```

The only direct uses of raw 2 are `P0` and its NOT. The inverter has one consumer. When 2 is zero, `P AND g` accepts each of 05, 03, 16 and 36. Expanding `A` gives 01, 03, 16 and 36. At 01 the extra term is harmless under the guard `g`: adding 5, 6 or 7 creates an edge and 03 itself is an edge. Thus `R`, `Q` and this term recover exactly the induced deletion graph. When 2 is one, `P` is one and `Q` is zero. The target cofactor is the OR of 5, 6, 7, 03 and 14, which equals `R OR g`.

The first positive-reader surgery replaces `P0` by 2 and appends `OR r` at the output. It is sound since `r` implies the target. The added `r` is needed by the modified circuit at the input with just 0 and 5 true. The surviving positive reader is `P = 2 OR A`. Now replace `P` by 2. Suppose the repair appends one OR with a corrected term whose only raw donors are 0, 1, 3 and 6 and charges that term only the original three gates of `A`. On the face where 2, 4, 5 and 7 are zero, every other surviving summand is zero. Hence the corrected term must compute the three-edge path `0–3–6–1` on every assignment of its four donors. Appending unmodified `A` already fails on 01.

Four essential inputs and at most three binary gates force a read-once binary tree. An OR root on disjoint nonempty variable sets cannot generate the connected path. At an AND root every union of a minimal true set from each factor is minimal true. Since all minimal true sets of the path have size two, both factors must have only singleton minimal true sets. Essentiality makes them the ORs of their respective variable sets, yielding a complete bipartite graph. The path is not complete bipartite. Thus the private correction needs at least four gates. Four suffice for `03 OR (6 AND (1 OR 3))`.

The restriction here concerns which previously computed wires the correction may reuse. For example, this circuit's guard already computes 03, so its downstream wiring offers another way to pay for a repair. The example places no lower bound on unrestricted implementations of the full target and supplies no separation at size 13 or 14.

The original Lean statement has SHA-256 `785f5e8bb0014fce3b6675fd4ac2605bceabb97e6c3aa7fae027afb9970b5b32`. The official evaluator has SHA-256 `695e454d3e424e2cae4fa4677741681eac11de0462d0d9bc087a0e6a6ba03f69`. This proof uses Boolean identities and a four-input structural argument.
