"""Bounded, source-auditable necessary tests for exactly two dominated raw inputs."""
import argparse
import itertools
import json
from pathlib import Path

EDGES=((0,3),(1,4),(0,5),(2,5),(1,6),(2,6),(3,6),(0,7),(1,7),(2,7),(4,7),(5,7))
NEIGH=[sum(1<<y for edge in EDGES if x in edge for y in edge if x!=y) for x in range(8)]
N={}
E={}
for mask in range(256):
    N[mask]=0
    for i in range(8):
        if mask>>i&1:N[mask]|=NEIGH[i]
    E[mask]=bool(mask&N[mask])

def subsets(m):
    u=m
    while True:
        yield u
        if not u:return
        u=(u-1)&m

# In coordinate order 00,10,01,11, a single path for each of the two
# variables permits one fixed genuinely bivariate table across all fibres.
SIMPLE=(0,15,3,12,5,10)
GENUINE=(1,2,4,8,14,13,11,7)
ALL=(1<<len(GENUINE))-1
CORNER={}
for pos in range(16):
    for neg in range(16):
        if pos&neg:continue
        def fits(f):return f&pos==pos and not f&neg
        CORNER[pos,neg]=ALL if any(map(fits,SIMPLE)) else sum(1<<i for i,f in enumerate(GENUINE) if fits(f))

def conflicts(pins, bits):
    binate=0; edges=[]
    for i in bits:
        b=1<<i;seen=0
        for x,v in pins.items():
            if x&b or x|b not in pins:continue
            if pins[x|b]!=v:seen|=1<<v
        if seen==3:binate|=b
    for i,j in itertools.combinations(bits,2):
        bi,bj=1<<i,1<<j;pair=bi|bj;fibres={}
        for x,v in pins.items():
            corner=((x>>i)&1)+2*((x>>j)&1);entry=fibres.setdefault(x&~pair,[0,0])
            entry[v]|=1<<corner
        choices=ALL
        for neg,pos in fibres.values():
            choices &= CORNER[pos,neg]
            if not choices:break
        if not choices:edges.append(pair)
    return binate,edges

def mincover(available,must,edges):
    es=[e for e in edges if not e&must]
    vals=[i for i in range(8) if available>>i&1 and not must>>i&1]
    for k in range(len(vals)+1):
        for ss in itertools.combinations(vals,k):
            m=must|sum(1<<i for i in ss)
            if all(m&e for e in es):return m
    raise AssertionError

def analyse(B,A):
    C=255^(B|A);xs=sorted(subsets(B));first={};settings=[]
    for s in subsets(A):
        if E[s]:continue
        rows=[-1 if E[s|t] else N[s|t]&C for t in xs]
        if len(set(rows))>2:return dict(test='row',s=s,rows=rows)
        if len(set(rows))==2:
            low=rows[0]
            for t,v in zip(xs,rows):first[s|t]=int(v!=low)
            # Both values of the cut bit are independently realizable at this s.
            high=next(r for r in rows if r!=low)
            settings.append((s,low,high))
    pre_bits=[i for i in range(8) if (A|B)>>i&1]
    must,edges=conflicts(first,pre_bits)
    cover=mincover(A|B,must,edges)
    # One baseline excess for each shared input, and the fork H itself.
    cost=1+A.bit_count()+cover.bit_count()
    detail=dict(test='prefix' if cost>6 else 'open',cost=cost,must=must,edges=edges,cover=cover)
    if cost>6:return detail
    # Extra outlet after H, distinct from already charged H fanout. Binary faces
    # involving only raw bypasses can use the cut bit as a fixed context.
    post={}
    for s,lo,hi in settings:
        for h,row in enumerate((lo,hi)):
            for y in subsets(C):
                post[s|y|(h<<8)]=int(row<0 or E[y] or bool(y&row))
    postbits=[i for i in range(8) if (A|C)>>i&1]
    pm,pe=conflicts(post,postbits)
    if pm or pe:
        detail.update(post_must=pm,post_edges=pe,lower_excess=cost+1)
        if cost+1>6:detail['test']='post'
    return detail

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pair',nargs=2,type=int);ap.add_argument('--out',type=Path);a=ap.parse_args()
    pairs=[tuple(a.pair)] if a.pair else itertools.combinations(range(8),2)
    rows={}
    for i,j in pairs:
        b=(1<<i)|(1<<j);r={s:analyse(b,s) for s in subsets(255^b)}
        rows[f'{i},{j}']=r
        print(i,j,sum(z['test']=='open' for z in r.values()),flush=True)
    if a.out:a.out.write_text(json.dumps(rows,separators=(',',':')))
if __name__=='__main__':main()
