# The first singleton fork that mixes raw inputs on 32081

Let a fork introduce precisely one new raw variable y, occurring once in its local tree. Suppose all preceding fork signals are signed raw coordinates. All influence of y on the output passes through this fork. Let P be the distinct other raw labels that its pins actually read; unused earlier raw coordinates remain free.

For A a subset of P, fix its coordinates to 1 and P minus A to 0. The restricted graph function depends on y exactly when A is independent and either y has a neighbor in A or some neighbor r of y outside P has no neighbor in A. For a witness in the latter case activate r alone among the still free inputs other than y. Conversely, any new edge formed by switching on y must involve an active neighbor; an edge already within A or between A and that neighbor prevents it from witnessing dependence. This tests a reachable raw fiber; signed aliases must be decoded into raw coordinate values first.

On each required fiber the local output must equal y or its complement. The orientation is fixed across all required fibers because y occurs once. With one distinct earlier label u both values of u have an essential extension: every vertex has degree at least two, and no two nonadjacent vertices have one open neighborhood contained in the other. Hence even repeated pins from that same raw label can only give a signed alias of y if all other inputs to the fork are also from that label.

With exactly two distinct predecessor pin occurrences u,v, neither can be a one-leaf sibling on the path from y to the root. Such a sibling would mask y throughout a full row of the u,v table. Hence u and v are siblings of each other. Their combined subtree feeds the final gate with y, and after normalizing the output orientation and input signs, a genuine mixture is y on three raw corners and is constant on the fourth. The alternative local tree masking three corners is impossible because it masks an entire row.

Permissible masked corners, before charging sign availability, are:

- With u=v=0 in value, the unordered previous-coordinate pair must be exactly N(y); these are y=3 with pair 06 and y=4 with pair 17.
- With h=1 and v=0, hy must be a nonedge and N(y) minus N(h) must equal {v}. In order of y=0,...,7 the possible ordered pairs (h,v) are [(2,3)], [(2,4)], [(0,6),(1,5)], [(1,0),(2,0),(5,6),(7,6)], [(0,1),(2,1),(5,1),(6,7)], [], [(7,3)], [].
- With both coordinates 1 any uv edge suffices. For uv a nonedge, y must miss both endpoints and N(y) must be contained in N(u) union N(v). The unordered pairs and y are (06,4), (56,4), (15,3), (01,2).

This condition grants all signed corner tests. Only local functions obtainable with the actual raw incoming phases and the remaining one-NOT budget can be used. A raw fiber on which y is irrelevant allows either a constant or transmission of y; it does not require masking. Other-valuation row separation, fanout pricing, and downstream usability remain additional tests. The earlier 11-only corner claim is superseded by the table above.
