import Mathlib

namespace RawOrPush

/-- u is the raw vertex, a is the other input to its unique positive reader,
and h is the cut circuit with the output of that reader supplied externally. -/
theorem push (u a : Bool) (h : Bool → Bool) (f : Bool)
    (correct : h (u || a) = f) (safe : a = true → f = true) :
    (h u || a) = f := by
  cases a <;> simp_all

def edges : List (Fin 8 × Fin 8) :=
  [(0,3),(1,4),(0,5),(2,5),(1,6),(2,6),(3,6),(0,7),(1,7),(2,7),(4,7),(5,7)]

def independent (s : Finset (Fin 8)) : Bool :=
  !edges.any (fun e => decide (e.1 ∈ s ∧ e.2 ∈ s))

def neighbors (v : Fin 8) : Finset (Fin 8) :=
  Finset.univ.filter fun w => (v,w) ∈ edges ∨ (w,v) ∈ edges

/-- A single neighbor suffices to extend any independent set in the deletion. -/
def sheds (v : Fin 8) : Prop :=
  ∀ s : Finset (Fin 8), v ∉ s → independent s = true →
    ∃ w ∈ neighbors v, independent (insert w s) = true

instance (v : Fin 8) : Decidable (sheds v) := by unfold sheds; infer_instance

example : sheds 0 ∧ sheds 1 ∧ sheds 5 ∧ sheds 6 := by decide

/-- Constructive witnesses, returned in increasing vertex order. -/
def witness (v : Fin 8) (s : Finset (Fin 8)) : Option (Fin 8) :=
  (List.finRange 8).find? fun w =>
    decide (w ∈ neighbors v) && independent (insert w s)

end RawOrPush

namespace RawOrPush.Indexed

inductive Row where
  | conj (a b : Nat)
  | disj (a b : Nat)
  | neg (a : Nat)
deriving DecidableEq

def Row.rewire (r : Nat → Nat) : Row → Row
  | .conj a b => .conj (r a) (r b)
  | .disj a b => .disj (r a) (r b)
  | .neg a => .neg (r a)

def renumber (k v j : Nat) : Nat :=
  if j < k then j else if j = k then v else j - 1

/-- pre ++ [disj v a] ++ post is the input list.  Its distinguished row
is necessarily live and earlier addresses are valid under normalization. -/
def splice (pre post : List Row) (v a out : Nat) : List Row × Nat :=
  let r := renumber (8 + pre.length) v
  (pre ++ post.map (Row.rewire r) ++ [.disj (r out) (r a)],
   8 + pre.length + post.length)

theorem splice_size (pre post : List Row) (v a out : Nat) :
    (splice pre post v a out).1.length =
    (pre ++ [.disj v a] ++ post).length := by
  simp [splice] <;> omega

/-- An original row is removed and the row added at the output is fresh. -/
theorem original_measure (left right : List Row) (v a : Nat) :
    left.length + right.length < (left ++ [.disj v a] ++ right).length := by
  simp <;> omega

end RawOrPush.Indexed
