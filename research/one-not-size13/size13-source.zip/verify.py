"""Verify the unpacked manuscript packet; optionally replay the original census."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
for line in (base / 'MANIFEST.sha256').read_text().splitlines():
    digest, name = line.split('  ', 1)
    if hashlib.sha256((base / name).read_bytes()).hexdigest() != digest:
        raise SystemExit(f'Checksum mismatch for {name}')
print('All manifested files match.')
if sys.argv[1:] == ['--census']:
    root = base / 'site-team-07/32081-class-replay'
    result = subprocess.run([sys.executable, '-B', 'audit.py'], cwd=root/'source',
                            capture_output=True, text=True, check=True)
    expected = json.loads((root/'receipt-13h318ni/receipt.json').read_text())['results']
    if json.loads(result.stdout) != expected:
        raise SystemExit('Census differs from signed-off receipt.')
    print('Full graph and deletion census results match the original receipt.')
elif sys.argv[1:]:
    raise SystemExit('Usage: python verify.py [--census]')
