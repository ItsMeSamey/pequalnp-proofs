from five_branch09 import *
from itertools import combinations_with_replacement,product
from collections import Counter

def rank(mat,n):
    a=[[(v>>j)&1 for j in range(n)] for v in set(mat)]
    i=0
    for j in range(n):
        k=next((k for k in range(i,len(a)) if a[k][j]),None)
        if k is None:continue
        a[i],a[k]=a[k],a[i]
        for k in range(i+1,len(a)):
            if a[k][j]:
                c=a[k][j]*pow(a[i][j],-1,101)%101
                a[k]=[(u-c*v)%101 for u,v in zip(a[k],a[i])]
        i+=1
    return i

@lru_cache(None)
def bounds(s):
    tab=rows(s,FULL^s)
    n=len(words(FULL^s))
    # In each protocol transcript Bob outputs a vector, Alice only a row indicator.
    return ((len(set(tab))-1).bit_length(),max(rank(tab,n),rank([v^((1<<n)-1) for v in tab],n)))

def main():
    graphs=list(product(*(tuple(combinations_with_replacement(range(i+1,6),2)) for i in range(5))))
    full=(1<<len(graphs))-1
    @lru_cache(None)
    def legal(mask,lgr,rankmin):
        ret=0
        for i,gr in enumerate(graphs):
            a=b=info=0
            for j,edges in enumerate(gr):
                inside=mask>>j&1
                if any((mask>>k&1)!=inside for k in edges):
                    if inside:
                        a+=1
                        info+=1<<b
                    else:b+=1
            if info>=lgr and (1<<(a+b))>=rankmin:ret|=1<<i
        return ret
    hits=Counter(); sample=None
    for p in partitions():
        avail=full
        for m in range(1,32):
            s=sum(p[j] for j in range(5) if m>>j&1)
            avail &=legal(m,*bounds(s))
            if not avail:break
        if avail:
            hits['partitions']+=1;hits['topologies with multiplicity']+=avail.bit_count()
            if sample is None:sample=p,graphs[(avail&-avail).bit_length()-1]
    print(hits,sample)
if __name__=='__main__':main()
