import PEqualNP.Defs

namespace PEqualNP.Outside.L_meta_32081_Witness

open PEqualNP.CircuitLowerBounds

def gates15 : List Gate :=
  [⟨.or, [0, 6]⟩, ⟨.and, [8, 3]⟩, ⟨.or, [1, 2]⟩,
   ⟨.or, [6, 7]⟩, ⟨.and, [10, 11]⟩, ⟨.or, [0, 2]⟩,
   ⟨.or, [13, 7]⟩, ⟨.and, [14, 5]⟩, ⟨.or, [1, 7]⟩,
   ⟨.and, [16, 4]⟩, ⟨.and, [0, 7]⟩, ⟨.or, [9, 12]⟩,
   ⟨.or, [15, 17]⟩, ⟨.or, [19, 20]⟩, ⟨.or, [21, 18]⟩]

def edgeIndices : List ℕ :=
  [0, 3, 1, 4, 0, 5, 2, 5, 1, 6, 2, 6, 3, 6, 0, 7, 1, 7, 2, 7, 4, 7, 5, 7]

def detects (x : Fin 8 → Bool) : Bool :=
  decide (∃ i < edgeIndices.length / 2,
    (List.ofFn x).getD (edgeIndices.getD (2 * i) 0) false = true ∧
    (List.ofFn x).getD (edgeIndices.getD (2 * i + 1) 0) false = true)

theorem gates15_basis : ∀ g ∈ gates15,
    (g.op = .and ∨ g.op = .or) ∧ g.inputs.length ≤ 2 := by
  simp [gates15]

theorem gates15_length : gates15.length = 15 := rfl

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
private theorem table15 : ∀ a b c d e f g h : Bool,
    (Circuit.mk gates15 22).eval (List.ofFn ![a,b,c,d,e,f,g,h]) =
      detects ![a,b,c,d,e,f,g,h] := by
  decide

theorem gates15_correct (x : Fin 8 → Bool) :
    (Circuit.mk gates15 22).eval (List.ofFn x) = detects x := by
  have hx : x = ![x 0,x 1,x 2,x 3,x 4,x 5,x 6,x 7] := by
    funext i
    fin_cases i <;> rfl
  calc
    _ = (Circuit.mk gates15 22).eval (List.ofFn ![x 0,x 1,x 2,x 3,x 4,x 5,x 6,x 7]) :=
      congrArg (fun y : Fin 8 → Bool => (Circuit.mk gates15 22).eval (List.ofFn y)) hx
    _ = detects ![x 0,x 1,x 2,x 3,x 4,x 5,x 6,x 7] :=
      table15 (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) (x 6) (x 7)
    _ = detects x := congrArg detects hx.symm

theorem witness_of_length_ge {n : ℕ} (hn : 15 ≤ n) :
    ∃ (gates' : List Gate) (o' : ℕ),
      (∀ g ∈ gates', (g.op = .and ∨ g.op = .or) ∧ g.inputs.length ≤ 2) ∧
      gates'.length ≤ n ∧ ∀ x : Fin 8 → Bool,
        (Circuit.mk gates' o').eval (List.ofFn x) = detects x :=
  ⟨gates15, 22, gates15_basis, (by simpa only [gates15_length] using hn), gates15_correct⟩

end PEqualNP.Outside.L_meta_32081_Witness
