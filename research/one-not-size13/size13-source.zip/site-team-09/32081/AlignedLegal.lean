import Mathlib
import PEqualNP.Defs.CircuitLowerBounds

namespace AlignedLegal32081
open PEqualNP.CircuitLowerBounds

/-- Preserve the original gate number. An unavailable input reads false. -/
def clean (n : Nat) (g : Gate) : Gate :=
  match g.op with
  | .and => if ∀ k ∈ g.inputs, k < n then g else ⟨.or, []⟩
  | .or => ⟨.or, g.inputs.filter (fun k => decide (k < n))⟩
  | .not =>
    match g.inputs with
    | [] => ⟨.and, []⟩
    | k :: _ => if k < n then ⟨.not, [k]⟩ else ⟨.and, []⟩
  | _ => g

def val (w : List Bool) (g : Gate) : Bool :=
  g.op.eval (g.inputs.map fun k => w.getD k false)

private theorem any_valid (w : List Bool) (ks : List Nat) :
    ((ks.filter (fun k => decide (k < w.length))).map (fun k => w.getD k false)).any id =
      (ks.map (fun k => w.getD k false)).any id := by
  induction ks with
  | nil => rfl
  | cons k ks ih =>
    by_cases h : k < w.length
    · simp [h, ih]
    · have hz := List.getD_eq_default w false (Nat.le_of_not_gt h)
      simp [h, hz, ih]

private theorem all_invalid (w : List Bool) (ks : List Nat) (h : ¬ ∀ k ∈ ks, k < w.length) :
    (ks.map (fun k => w.getD k false)).all id = false := by
  induction ks with
  | nil => simp at h
  | cons k ks ih =>
    by_cases hk : k < w.length
    · have ht : ¬ ∀ j ∈ ks, j < w.length := by
        intro hh
        apply h
        simpa [hk] using hh
      simp [ih ht]
    · have hz := List.getD_eq_default w false (Nat.le_of_not_gt hk)
      simp [hz]

theorem val_clean (w : List Bool) (g : Gate) : val w (clean w.length g) = val w g := by
  obtain ⟨op, xs⟩ := g
  cases op with
  | and =>
    by_cases h : ∀ k ∈ xs, k < w.length
    · simp [clean, h]
    · simpa [clean, h, val, GateOp.eval] using (all_invalid w xs h).symm
  | or => exact any_valid w xs
  | not =>
    cases xs with
    | nil => rfl
    | cons k ks =>
      by_cases h : k < w.length
      · simp [clean, h, val, GateOp.eval]
      · have hz := List.getD_eq_default w false (Nat.le_of_not_gt h)
        simp [clean, h, val, GateOp.eval, hz]
  | mod _ => rfl
  | maj => rfl

def gates : Nat → List Gate → List Gate
  | _, [] => []
  | n, g :: gs => clean n g :: gates (n+1) gs

@[simp] theorem length_gates (n : Nat) (gs : List Gate) :
    (gates n gs).length = gs.length := by
  induction gs generalizing n with
  | nil => rfl
  | cons g gs ih => simp [gates, ih]

def step (w : List Bool) (g : Gate) := w ++ [val w g]

theorem fold_gates (w : List Bool) (gs : List Gate) :
    (gates w.length gs).foldl step w = gs.foldl step w := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih =>
    have hs : step w (clean w.length g) = step w g := by simp [step, val_clean]
    have hl : (step w g).length = w.length+1 := by simp [step]
    simp only [gates, List.foldl_cons, hs]
    rw [← hl]
    exact ih (step w g)

/-- The same program works on every assignment of the fixed input width n. -/
theorem eval_gates (n : Nat) (gs : List Gate) (out : Nat) (w : List Bool) (hw : w.length = n) :
    Circuit.eval ⟨gates n gs,out⟩ w = Circuit.eval ⟨gs,out⟩ w := by
  subst n
  change ((gates w.length gs).foldl step w).getD out false =
    (gs.foldl step w).getD out false
  rw [fold_gates]

def good (g : Gate) : Prop := (g.op = .and ∨ g.op = .or ∨ g.op = .not) ∧ g.inputs.length ≤ 2

def legal (w : Nat) (g : Gate) : Prop :=
  good g ∧ (∀ k ∈ g.inputs, k < w) ∧ (g.op = .not → g.inputs.length = 1)

theorem clean_legal (n : Nat) (g : Gate) (h : good g) : legal n (clean n g) := by
  obtain ⟨o, xs⟩ := g
  rcases h with ⟨ho,hlen⟩
  change o = .and ∨ o = .or ∨ o = .not at ho
  change xs.length ≤ 2 at hlen
  rcases ho with rfl | rfl | rfl
  · by_cases hv : ∀ k ∈ xs, k < n <;> simp [clean, legal, good, hv, hlen]
  · simp only [clean, legal, good]
    refine ⟨⟨Or.inr (Or.inl rfl), (List.length_filter_le _ _).trans hlen⟩, ?_, by simp⟩
    intro k hk
    simpa using (List.mem_filter.mp hk).2
  · cases xs with
    | nil => simp [clean, legal, good]
    | cons k ks => by_cases hk : k < n <;> simp [clean, legal, good, hk]

theorem clean_not_source (n : Nat) (g : Gate) (h : (clean n g).op = .not) : g.op = .not := by
  obtain ⟨o,xs⟩ := g
  cases o <;> simp_all [clean] <;> split at h <;> simp_all

def LegalFrom : Nat → List Gate → Prop
  | _, [] => True
  | n, g :: gs => legal n g ∧ LegalFrom (n+1) gs

theorem gates_legal (n : Nat) (gs : List Gate) (h : ∀ g ∈ gs, good g) :
    LegalFrom n (gates n gs) := by
  induction gs generalizing n with
  | nil => trivial
  | cons g gs ih =>
    exact ⟨clean_legal n g (h _ (by simp)), ih _ (fun j hj => h j (by simp [hj]))⟩

/-- Indexed NOT inclusion, so a single original NOT cannot acquire a second index. -/
theorem not_at (n : Nat) (gs : List Gate) (i : Nat) (hi : i < gs.length)
    (h : ((gates n gs)[i]'(by simpa using hi)).op = .not) : (gs[i]).op = .not := by
  induction gs generalizing n i with
  | nil => simp at hi
  | cons g gs ih =>
    cases i with
    | zero => exact clean_not_source n g h
    | succ i => exact ih (n+1) i (by simpa using hi) h

theorem gates_one_not (n : Nat) (gs : List Gate)
    (h : ∀ i j : Fin gs.length, (gs.get i).op = .not → (gs.get j).op = .not → i = j) :
    ∀ i j : Fin (gates n gs).length,
      ((gates n gs).get i).op = .not → ((gates n gs).get j).op = .not → i = j := by
  intro i j hi hj
  have hi' : i.val < gs.length := by simpa using i.isLt
  have hj' : j.val < gs.length := by simpa using j.isLt
  have he := h ⟨i.val, hi'⟩ ⟨j.val, hj'⟩ (not_at n gs i.val hi' hi) (not_at n gs j.val hj' hj)
  exact Fin.ext (congrArg Fin.val he)

end AlignedLegal32081
