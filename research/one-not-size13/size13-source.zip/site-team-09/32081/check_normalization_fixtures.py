import json
from pathlib import Path

def evaluate(net, x):
    gates, out = net
    v = [bool(x>>i & 1) for i in range(8)]
    for op, pins in gates:
        args = [v[p] if p<len(v) else False for p in pins]
        if op=='and': v.append(all(args))
        elif op=='or': v.append(any(args))
        else: v.append(not (args[0] if args else False))
    return v[out] if out<len(v) else False

F=([],8)
T=([('and',[])],8)
cases=[('nullary_and',T,T),('nullary_or',([('or',[])],8),F),('nullary_not',([('not',[])],8),T),
 ('single_and',([('and',[0])],8),([],0)),('single_or',([('or',[1])],8),([],1)),
 ('bad_and_pin',([('and',[0,40])],8),F),('bad_not',([('not',[999,0])],8),T),
 ('ignored_pin',([('not',[0,999])],8),([('not',[0])],8)),
 ('forward',([('or',[9]),('and',[])],8),F),('self',([('and',[8,1])],8),F),
 ('bad_output',([('and',[])],99),F),('empty_circuit',F,F),
 ('intern',([('or',[0,0]),('and',[1,8]),('and',[8,1]),('or',[9,10])],11),([('and',[0,1])],8))]
for name,src,dst in cases:
    assert len(dst[0])<=len(src[0])
    assert sum(o=='not' for o,p in dst[0])<=sum(o=='not' for o,p in src[0])
    assert all(evaluate(src,x)==evaluate(dst,x) for x in range(256)),name
Path(__file__).with_name('normalization-fixtures.json').write_text(json.dumps(cases,indent=2)+'\n')
print(len(cases),'fixture pairs verified on all 256 inputs')
