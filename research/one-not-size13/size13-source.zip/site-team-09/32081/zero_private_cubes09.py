"""Zero-private 14-gate H filtering by forced constant restrictions of size at most three."""
from collections import Counter
from functools import lru_cache
from itertools import combinations
import argparse
import json
from zero_private_control import bound


@lru_cache(None)
def formula_pool(k):
    """Full-support read-once AND/OR functions with at most one physical NOT."""
    full=(1<<(1<<k))-1
    variables=[sum(((x>>i)&1)<<x for x in range(1<<k)) for i in range(k)]
    @lru_cache(None)
    def tables(mask):
        if mask.bit_count()==1:
            v=variables[mask.bit_length()-1]
            return {v},{v^full}
        pos=set()
        inv=set()
        l=(mask-1)&mask
        while l:
            r=mask^l
            if l<r:
                p,q=tables(l); u,v=tables(r)
                for dest,left,right in ((pos,p,u),(inv,q,u),(inv,p,v)):
                    for x in left:
                        for y in right:
                            dest.add(x&y)
                            dest.add(x|y)
            l=(l-1)&mask
        inv.update(x^full for x in pos)
        return pos,inv
    positive,signed=tables((1<<k)-1)
    return tuple(sorted({min(t,t^full) for t in positive|signed}))


@lru_cache(None)
def class_floor(fixed,value):
    return bound(fixed,value)


def analyze(donors):
    k=len(donors)
    local=list(range(1<<k))
    embed=[sum((x>>j&1)<<v for j,v in enumerate(donors)) for x in local]
    bad=[]
    for m in local:
        if not 1<=m.bit_count()<=3:continue
        for v in local:
            if v&m!=v:continue
            lb=class_floor(embed[m],embed[v])
            if lb>5-k:
                face=sum(1<<i for i in local if i&m==v)
                bad.append((m.bit_count(),face,embed[m],embed[v],lb))
    bad.sort()
    pool=formula_pool(k)
    remaining=list(pool)
    counts={}
    for size in (1,2,3):
        for _,face,*_ in (item for item in bad if item[0]==size):
            remaining=[t for t in remaining if t&face not in (0,face)]
        counts[size]=len(remaining)
    return dict(donors=donors,excess_limit=5-k,pool=len(pool),
                survivors_by_max_cube=counts,sample=min(remaining,default=None),
                forbidden=[(m,v,lb) for _,face,m,v,lb in bad])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sizes',type=int,nargs='+',choices=(2,3,4,5),default=(2,3,4,5))
    p.add_argument('--jsonl')
    args=p.parse_args()
    out=[]
    for k in args.sizes:
        total=Counter()
        for donors in combinations(range(8),k):
            item=analyze(donors)
            out.append(item)
            total.update(item['survivors_by_max_cube'])
            total['original']+=item['pool']
            total['support_sets_left']+=int(item['sample'] is not None)
        print(json.dumps(dict(k=k,counts=total)),flush=True)
    if args.jsonl:
        with open(args.jsonl,'w') as f:
            for item in out:print(json.dumps(item),file=f)
if __name__=='__main__':main()
