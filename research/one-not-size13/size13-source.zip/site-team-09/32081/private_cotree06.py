"""Common signed cotree feasibility on forced single-bit edges of a partial H."""
from functools import lru_cache
from itertools import combinations
import argparse
import json
from five_branch09 import words,rows

def pins_from_record(record):
    a,b,c=(record[k] for k in ('A','B','C'))
    pins={}
    for e in words(a):
        classes=rows(b,c,e)
        if len(set(classes))>2:raise ValueError('invalid private separator')
        if len(set(classes))==2:
            pins.update({e|x:int(v!=classes[0]) for x,v in zip(words(b),classes)})
    return pins

def check(s,pins,budget,extra_conflicts=()):
    if any(x&~s or y not in (0,1) for x,y in pins.items()):
        raise ValueError('pins outside domain')
    edges=[{},{}]; signs=[{},{}]
    for x,y in pins.items():
        sensitive=[]
        for i in range(8):
            q=1<<i
            if not s&q or pins.get(x^q,y)==y:continue
            sensitive.append(q)
            signs[int(bool(x&q)==bool(y))].setdefault(q,x)
        for q,t in combinations(sensitive,2):
            edges[y].setdefault(q|t,x)
    binate=sum(set(signs[0])&set(signs[1]))
    ands=set(edges[1]);ors=set(edges[0]);conflicts=set(extra_conflicts)
    @lru_cache(None)
    def tree(m):
        if m.bit_count()<=1:return True
        for l in words(m):
            if not l or l==m or not l&(m&-m):continue
            r=m^l
            for contrary in (ands,ors):
                if any(e&l and e&r for e in contrary):continue
                if tree(l) and tree(r):return True
        return False
    valid=[]
    for d in words(s):
        if d.bit_count()>budget or binate&~d or any(not d&q for q in conflicts):continue
        if tree(s^d):valid.append(d)
    return dict(binate=binate,sign_witnesses=signs,pair_witnesses_OR_AND=edges,feasible_duplicate_masks=valid)

def analyze(record):
    a,b=record['A'],record['B']
    return check(a|b,pins_from_record(record),5-a.bit_count(),[e for e,_ in record.get('witnesses',[])])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('output');args=p.parse_args()
    with open(args.input) as fin, open(args.output,'x') as fout:
        for line in fin:
            rec=json.loads(line)
            fout.write(json.dumps(dict(A=rec['A'],B=rec['B'],C=rec['C'],**analyze(rec)))+'\n')
