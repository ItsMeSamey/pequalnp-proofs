"""Check the frozen Lean gates against the official graph on every Boolean input."""
import hashlib
import json
import re
from pathlib import Path
here = Path(__file__).resolve().parent
lean = (here / 'Witness15.lean').read_text()
issue = Path('/workspace/pequalnp-proofs/.pnp/L-meta-32081.json')
statement = json.loads(issue.read_text())['gap']['statement']
edgelists = re.findall(r'\(\[([0-9, ]+)\] : List ℕ\)', statement)
assert len(set(edgelists)) == 1
indices = list(map(int, edgelists[0].split(',')))
literal = re.search(r'def edgeIndices : List ℕ :=\s*\[([0-9, ]+)\]',lean)[1]
assert list(map(int, literal.split(','))) == indices
edges = list(zip(indices[::2], indices[1::2], strict=True))
gates = [(op,int(a),int(b)) for op,a,b in re.findall(r'⟨\.(and|or), \[(\d+), (\d+)\]⟩',lean)]
assert len(gates)==15
labels=[]
for assignment in range(256):
    inputs=[(assignment>>i)&1 for i in range(8)]
    wires=inputs.copy()
    for op,a,b in gates:
        assert 0<=a<len(wires) and 0<=b<len(wires)
        wires.append(wires[a]&wires[b] if op=='and' else wires[a]|wires[b])
    expected=any(inputs[a] and inputs[b] for a,b in edges)
    assert wires[22]==expected,(assignment,wires[22],expected)
    labels.append(wires[22])
receipt=dict(gates=gates,output=22,edges=edges,assignments=len(labels),ones=sum(labels),
             mismatches=0,truth_sha256=hashlib.sha256(bytes(labels)).hexdigest(),
             lean_sha256=hashlib.sha256(lean.encode()).hexdigest())
(here/'witness15-replay.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(labels),sum(labels),receipt['truth_sha256'])
