"""Necessary excess bounds for a specified singleton-private prefix formula. No suffix gate search."""
import argparse
import json
from functools import lru_cache
from five_branch09 import TABLE, FULL, words
from private_cotree06 import check as cotree

def prefix(expr):
    if type(expr)==int:
        if not 0<=expr<8:raise ValueError('raw')
        return [expr],0,sum(bool(x&(1<<expr))<<x for x in range(256))
    op,*args=expr
    if op=='not' and len(args)==1:
        leaves,k,v=prefix(args[0]);return leaves,k+1,((1<<256)-1)^v
    if op not in ('and','or') or len(args)!=2:raise ValueError('gate')
    l,k,x=prefix(args[0]);r,j,y=prefix(args[1])
    return l+r,k+j,x&y if op=='and' else x|y

def boundary(a,b,h):
    pins={}
    for x,y in enumerate(TABLE):
        k=(x&~b)|(b if h>>x&1 else 0)
        if pins.setdefault(k,y)!=y:return None
    return pins

def bipartite(rows):
    # A conflict edge joins two partial rows disagreeing in a common column.
    color={}
    for i in range(len(rows)):
        if i in color:continue
        color[i]=0;todo=[i]
        while todo:
            u=todo.pop();z,o=rows[u]
            for j,(zz,oo) in enumerate(rows):
                if not ((z&oo)|(o&zz)):continue
                if j in color:
                    if color[j]==color[u]:return False
                else:color[j]=1-color[u];todo.append(j)
    return True

def class_floor(pins,b,done=None,checkpoint=None):
    universe=FULL^b
    # Two singly routed inputs to a first fork have one exceptional corner
    # whenever their joint cofactor is genuinely binary, up to output phase.
    unary=(0,15,3,12,5,10)
    bad=[]
    for i in range(8):
        for j in range(i):
            pair=1<<i|1<<j
            if pair&b:continue
            candidates=set(range(4))
            for ctx in words(FULL^pair):
                known=val=0
                for k,x in enumerate(words(pair)):
                    if ctx|x in pins:
                        known|=1<<k
                        val|=pins[ctx|x]<<k
                if any(not ((v^val)&known) for v in unary):continue
                candidates={k for k in candidates if any(not ((v^val)&known)
                           for v in (1<<k,15^(1<<k)))}
            if not candidates:bad.append(pair)
    @lru_cache(None)
    def allowed(prev,g):
        if any(g&p==p for p in bad):return False
        after=universe^prev^g
        for e in words(prev):
            for hv in (0,b):
                row=[]
                for x in words(g):
                    sides=[0,0]
                    for k,y in enumerate(words(after)):
                        val=pins.get(e|hv|x|y)
                        if val is not None:sides[val]|=1<<k
                    row.append(sides)
                if not bipartite(row):return False
        return True
    if done is None:done={}
    done[universe]=0
    for prev in sorted(words(universe),key=int.bit_count,reverse=True):
        if prev in done:continue
        rem=universe^prev
        done[prev]=min(1+done[prev|g] for g in words(rem) if g and allowed(prev,g))
        if checkpoint is not None:checkpoint(prev,done)
    return done[0]

def audit(a,raw,expr,budget=6):
    b=1<<raw;ls,nnot,h=prefix(expr)
    if b&a or set(ls)!={i for i in range(8) if (a|b)>>i&1} or nnot>1:
        raise ValueError('prefix support or NOT count')
    charge=len(ls)-1
    if charge+1>budget:return dict(status='prefix excess',prefix=charge)
    pins=boundary(a,b,h)
    if pins is None:return dict(status='inconsistent boundary',prefix=charge)
    if nnot and any(y==1 and not k&(1<<i) and pins.get(k|1<<i)==0
                    for k,y in pins.items() for i in range(8)):
        return dict(status='positive suffix contradicted',prefix=charge)
    q=class_floor(pins,b)
    # q nonempty other-raw classes imply q−1 non-H forks in addition to H.
    # If only the H fork is affordable, all other leaves occur once in K.
    cert=cotree(FULL,pins,1)
    if b not in cert['feasible_duplicate_masks']:q=max(q,2)
    return dict(status='excluded' if charge+q>budget else 'open',prefix=charge,
                duplicate_prefix_leaves=len(ls)-a.bit_count()-1,bypass=a.bit_count(),
                suffix_floor=q,pins=len(pins),cofactor0=sum(not(k&b) for k in pins),
                cofactor1=sum(bool(k&b) for k in pins),cotree_h_only=b in cert['feasible_duplicate_masks'])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('cases');p.add_argument('out')
    args=p.parse_args()
    with open(args.cases) as f,open(args.out,'x') as out:
        for line in f:
            d=json.loads(line);print(json.dumps(dict(case=d,receipt=audit(d['A'],d['private_index'],d['prefix'],d.get('excess',6)))),file=out)
