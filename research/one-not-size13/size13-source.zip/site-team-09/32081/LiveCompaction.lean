import PEqualNP.Defs.CircuitLowerBounds
import Mathlib.Data.List.GetD

namespace LiveCompaction32081
open PEqualNP.CircuitLowerBounds

def step (v : List Bool) (g : Gate) : List Bool :=
  v ++ [g.op.eval (g.inputs.map fun i => v.getD i false)]

def values (x : List Bool) (gs : List Gate) := gs.foldl step x

theorem values_length (gs : List Gate) (x : List Bool) :
    (values x gs).length = x.length + gs.length := by
  induction gs generalizing x with
  | nil => simp [values]
  | cons g tail ih =>
      change (values (step x g) tail).length = _
      rw [ih]
      simp [step,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm]

private theorem old_read (x : List Bool) (gs : List Gate) (g : Gate) (i : Nat)
    (hi : i < x.length+gs.length) :
    (values x (gs++[g])).getD i false = (values x gs).getD i false := by
  change ((gs++[g]).foldl step x).getD i false = _
  rw [List.foldl_append]
  exact List.getD_append _ _ _ _ (by simpa [values_length] using hi)

private theorem born_read (x : List Bool) (gs : List Gate) (g : Gate) :
    (values x (gs++[g])).getD (x.length+gs.length) false =
    g.op.eval (g.inputs.map fun i => (values x gs).getD i false) := by
  have h := values_length gs x
  change ((gs++[g]).foldl step x).getD _ false = _
  rw [List.foldl_append]
  change ((values x gs) ++ [_]).getD _ _ = _
  rw [←h,List.getD_append_right _ _ _ _ (Nat.le_refl _)]
  simp

abbrev Map := Nat → Option Nat
def put (f : Map) (k : Nat) (v : Option Nat) : Map :=
  fun i => if i=k then v else f i
def rename (g : Gate) (f : Nat → Nat) : Gate := ⟨g.op,g.inputs.map f⟩

structure Sound (n : Nat) (src dst : List Gate) (f : Map) : Prop where
  budget : dst.length ≤ src.length
  valid : ∀ i j, f i = some j → i < n+src.length ∧ j < n+dst.length
  read : ∀ x : List Bool, x.length=n → ∀ i j, f i = some j →
    (values x src).getD i false = (values x dst).getD j false

theorem start (n : Nat) : Sound n [] [] (fun i => if i<n then some i else none) := by
  constructor
  · exact le_rfl
  · intro i j h; by_cases hi : i<n <;> simp_all
  · intro x hx i j h; by_cases hi : i<n <;> simp_all

variable {n : Nat} {src dst : List Gate} {f : Map}

/-- Dead source gate; old output need only be requested when its alias survives. -/
theorem drop (s : Sound n src dst f) (g : Gate) :
    Sound n (src++[g]) dst f := by
  constructor
  · have h := s.budget; simp <;> omega
  · intro i j h
    obtain ⟨a,b⟩ := s.valid i j h
    exact ⟨by simp <;> omega,b⟩
  · intro x hx i j h
    rw [old_read x src g i (by simpa [hx] using (s.valid i j h).1)]
    exact s.read x hx i j h

/-- Record the new source slot as a previously represented (valid) target wire. -/
theorem alias (s : Sound n src dst f) (g : Gate) (u v : Nat) (hu : f u = some v)
    (eqv : ∀ x : List Bool, x.length=n →
      g.op.eval (g.inputs.map fun i => (values x src).getD i false) =
      (values x src).getD u false) :
    Sound n (src++[g]) dst (put f (n+src.length) (some v)) := by
  have d := drop s g
  constructor
  · exact d.budget
  · intro i j h
    by_cases e : i=n+src.length
    · subst i; simp only [put,if_pos rfl,Option.some.injEq] at h
      subst j; exact ⟨by simp <;> omega,(s.valid u v hu).2⟩
    · exact d.valid i j (by simpa [put,e] using h)
  · intro x hx i j h
    by_cases e : i=n+src.length
    · subst i; simp only [put,if_pos rfl,Option.some.injEq] at h
      subst j
      rw [←hx,born_read]
      exact (eqv x hx).trans (s.read x hx u v hu)
    · exact d.read x hx i j (by simpa [put,e] using h)

/-- Keep a gate after relabeling every listed pin, including repeated pins. -/
theorem keep (s : Sound n src dst f) (g : Gate) (r : Nat → Nat)
    (pins : ∀ i ∈ g.inputs, f i = some (r i)) :
    Sound n (src++[g]) (dst++[rename g r])
      (put f (n+src.length) (some (n+dst.length))) := by
  constructor
  · have h := s.budget; simp <;> omega
  · intro i j h
    by_cases e : i=n+src.length
    · subst i; simp only [put,if_pos rfl,Option.some.injEq] at h
      subst j; simp <;> omega
    · obtain ⟨a,b⟩ := s.valid i j (by simpa [put,e] using h)
      simp <;> omega
  · intro x hx i j h
    by_cases e : i=n+src.length
    · subst i; simp only [put,if_pos rfl,Option.some.injEq] at h
      subst j
      rw [←hx,born_read,born_read]
      change g.op.eval _ = g.op.eval _
      apply congrArg g.op.eval
      simp only [rename,List.map_map,Function.comp_def]
      apply List.map_congr_left
      exact fun i hi => s.read x hx i _ (pins i hi)
    · have m : f i = some j := by simpa [put,e] using h
      obtain ⟨a,b⟩ := s.valid i j m
      rw [old_read x src g i (by simpa [hx] using a),
          old_read x dst (rename g r) j (by simpa [hx] using b)]
      exact s.read x hx i j m

theorem output_transport (s : Sound n src dst f) {o q : Nat} (h : f o=some q) :
    q < n+dst.length ∧ dst.length ≤ src.length ∧
      ∀ x : List Bool, x.length=n → (Circuit.mk src o).eval x = (Circuit.mk dst q).eval x :=
  ⟨(s.valid o q h).2,s.budget,fun x hx => s.read x hx o q h⟩
end LiveCompaction32081
