"""Enumerate prefix truth tables by leaf multiplicity and exact unary count; no suffix programs."""
from functools import lru_cache
import itertools,json,argparse
from singleton_boundary06 import audit,boundary
from five_branch09 import words,FULL,rows

def candidates(a,raw,budget):
    b=1<<raw
    support=a|b;indices=[i for i in range(8) if support>>i&1]
    local=words(support);full=(1<<len(local))-1
    literals={i:sum(bool(x&(1<<i))<<k for k,x in enumerate(local)) for i in indices}
    required0=required1=0
    for k,x in enumerate(local):
        rc=rows(b,FULL^support,x&a)
        if rc[0]!=rc[1]:
            if x&b:required1|=1<<k
            else:required0|=1<<k
    @lru_cache(None)
    def trees(ls,n):
        tab={}
        if n:
            for v,e in trees(ls,0).items():tab.setdefault(full^v,['not',e])
        elif len(ls)==1:tab[literals[ls[0]]]=ls[0]
        for mask in range(1,(1<<len(ls))-1,2):
            left=tuple(x for i,x in enumerate(ls) if mask>>i&1)
            right=tuple(x for i,x in enumerate(ls) if not(mask>>i&1))
            for k in range(n+1):
                for v,e in trees(left,k).items():
                    for w,f in trees(right,n-k).items():
                        tab.setdefault(v&w,['and',e,f]);tab.setdefault(v|w,['or',e,f])
        return tab
    seen=set()
    for m in range(len(indices),budget+1):
        for extra in itertools.combinations_with_replacement(indices,m-len(indices)):
            ls=tuple(sorted((*indices,*extra)))
            for n in (0,1):
                for v,e in trees(ls,n).items():
                    if not n and len(ls)==1:continue
                    if v&required0 or required1&~v or (n,v) in seen:continue
                    seen.add((n,v));yield e

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--A',type=int,required=True);p.add_argument('--private-index',type=int,required=True)
    p.add_argument('--excess',type=int,default=6);p.add_argument('out');args=p.parse_args()
    if not 0<=args.A<=255 or not 0<=args.private_index<8 or args.A>>args.private_index&1:p.error('invalid support')
    with open(args.out,'x') as f:
        for e in candidates(args.A,args.private_index,args.excess):
            print(json.dumps(dict(prefix=e,**audit(args.A,args.private_index,e,args.excess))),file=f)
