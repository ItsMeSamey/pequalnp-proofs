# Size-14 master dispatch for the issued eight-input circuit theorem

**Status:** all normalized profiles have manuscript routes. An integrated independent dependency review is in progress. The hashes below pin immediate interfaces, not a portable recursive package or Lean proof.

For any issued AND/OR/single-NOT list and arbitrary output computing the specified graph on all 256 assignments, the goal is an AND/OR witness whose physical length does not exceed the input length. Length at least 15 uses the fixed monotone witness. Otherwise normalize default references, malformed arities allowed by the statement, forward reads, invalid output, dead gates and aliases using the original evaluator. A monotone realization returns directly. Length at most 13 uses the frozen smaller module. A remaining live 14-row program has thirteen binary gates, a unique NOT and outlet excess six.

The no-computed-fork branch treats double raw uses and a single triple. For an earliest computed fork use the maximal set of primary inputs all of whose output paths cross it. A private edge admits surgery; an independent dominated set uses the pair or triple proofs. A single dominated raw uses the physical singleton ledger and its signed and repeated-occurrence bridges. With no dominated raw the unique empty class forces six double forks. One donor uses the singleton-input result; five use positive-root or inverted-prefix proofs. At two donors, use the uniform positive AND star refund, NAND clamp, mixed literal reduction, or complete OR/NOR tables. At three/four donors separate positive prefixes from those containing the one inverter.

Each leaf returns an AO witness, contradiction, shorter realization, or a proved terminating equal-cost move. Structural rank is size, computed fork count, then sum of binary-ancestor counts of computed forks. A fixed-raw positive-reader splice has a separate local potential. Merely renaming the raw operand or changing the chosen schedule supplies no descent; use the destination-specific lemma or an earlier decreasing coordinate. Distinguish proof of equal price from proof that every output pin and every row of the truth table remains correct.

The last OR67 proof uses the corrected joint P,T membership argument even if T is upstream of P. Teams 01/types and 01/quantifiers passed its corrected unit proof conditional on the named high optimum and direct four-graft normalization. Reviews of individual components and the routing partition do not certify every transitive premise.

| Role | Relative source | SHA-256 |
|---|---|---|
| Issued original | [L_meta_32081.lean](../../../pequalnp-proofs/lean/PEqualNP/Outside/L_meta_32081.lean) | `785f5e8bb0014fce3b6675fd4ac2605bceabb97e6c3aa7fae027afb9970b5b32` |
| Semantics/witness | [normalization.md](normalization.md) | `580327da8fe33adcaab2136eb527593054046338c01507b33ec25fe7fd88b754` |
| Semantics/witness | [witness15-replay.json](../../site-team-09/32081/witness15-replay.json) | `284741c2b6be89059bc4d7760b1928b224a93ef5ebb8c15d764fd6bad9f8710c` |
| Frozen smaller proof/census | [L-meta-32081-size13-source.zip](../L-meta-32081-size13-source.zip) | `5b5edc2ba3385c50fef4b11a49d6da5cd9821df21be77fdd028fb73ce64a071e` |
| Frozen smaller proof/census | [receipt.json](../../site-team-07/32081-class-replay/receipt-13h318ni/receipt.json) | `e9e586b9a7be40ea037ce9c380126766d7f4a987b6fa0b438d03dbae1f12c9f6` |
| Integrated rank | [size14-well-founded-rank.md](size14-well-founded-rank.md) | `08fcbb8e1806fa39d21bbdca1cf44d1c13ed10118566138dc338f669a218c17b` |
| Hierarchy/rank | [fork14-hierarchy.md](fork14-hierarchy.md) | `7c4f46a43cc319083dcf410755b506b7185a8488f5fb258eeab5b4fbe14b6518` |
| Hierarchy/rank | [raw-tie-audit.md](raw-tie-audit.md) | `dbbc91c6d901c09d99a0f81c55942079a082623e4d31a417ab6b8b922059ec5b` |
| Hierarchy/rank | [signed-rank-interface-audit.md](signed-rank-interface-audit.md) | `fe454e32bc5c53436caa04c9e879d773adc4e338a88c4a991e5f7236e070b7dd` |
| Hierarchy/rank | [size14-singleton-rank-receipts.md](size14-singleton-rank-receipts.md) | `4cc79590c9a2edd34ce64a0f803317bd1c748fa3c93788d157806fe2cdb68646` |
| Raw-only/multiple private | [read-two-and-auxiliary.md](read-two-and-auxiliary.md) | `c7e51e0637c1ec2df59cc629eae002c37413894261fa70955b168a17e578ce5f` |
| Raw-only/multiple private | [no-fork-ternary14.md](no-fork-ternary14.md) | `aeeb86b22a437d02e8f27475398611b01e068f69db24d5f51ac1b498aa6a4505` |
| Raw-only/multiple private | [private-edge-surgery.md](../../site-team-09/32081/private-edge-surgery.md) | `5ae6cce8447a0d22b7d6aca9084d18e6d7ec0e86052e8d2a1c4cbf1b1b53f386` |
| Raw-only/multiple private | [pair_rules.md](pair_rules.md) | `a6524e9375f49d72ed14e2eeda534ca54d2f7b29567689c9522b1c44b2e4b1eb` |
| Raw-only/multiple private | [nonadjacent_pairs.md](nonadjacent_pairs.md) | `092a20a6c4aa65eb4f88e8c593c162e636e2f6dffbb4053de16fb9c43eb77cb7` |
| Raw-only/multiple private | [independent-triples.md](../../site-team-09/32081/independent-triples.md) | `f09b9ce5e14a99b5d2ace2844037e00d2c5b3669a416b691657da760e0e1399e` |
| Single private | [size14-singleton-ledger.md](size14-singleton-ledger.md) | `2ae98de2808901f24784f92c5bc3b534e108972d0ae0a701067162468916a0bc` |
| Zero-private one/five | [zero-private-equality09.md](../../site-team-09/32081/zero-private-equality09.md) | `b9afa92f38556fdca324718151ea3656076f79cecde76f51bd67556668f47031` |
| Zero-private one/five | [zero-private-cubes09.md](../../site-team-09/32081/zero-private-cubes09.md) | `209fda8ac0e5c4b10b65c367bbfbf255c47b280e4eb6c007e4e38d5089aa47cc` |
| Zero-private one/five | [zero-private-positive-five.md](../../site-team-09/32081/zero-private-positive-five.md) | `d68b37898808164b0fdba9fcd7e58d5d87dfc948770699d02b83b2f6c7d9ec90` |
| Zero-private one/five | [zero-private-h5-signed-strict.md](zero-private-h5-signed-strict.md) | `49a763a79647f7e95af393cbb2f8b0260dac9530195f0926794370e2fe7bc839` |
| Zero-private two | [size14-all-index.md](size14-all-index.md) | `97fb29155807fa917c33a14ceabf1bca60467430ddc5a8f9e4d372238456bad3` |
| Zero-private two | [zero-private-signed-two.md](../../site-team-09/32081/zero-private-signed-two.md) | `32cd0b4322e6d1842aff9c4effc48d90cadc33b4c60733e2c12ea992998e52bf` |
| Zero-private two | [zero-private-or-pair-index.md](zero-private-or-pair-index.md) | `6c43d90540965e9b767d7204aee3d7395d4f00556717653f34ee85a15ed62814` |
| Zero-private two | [zero-private-nor-pair-index.md](zero-private-nor-pair-index.md) | `88f63578f88ea61e2cdccae6c8a29eafdcc666dbe0d8bd822b4830cd4a07c8df` |
| Zero-private three/four | [positive-three-four-donor-index.md](positive-three-four-donor-index.md) | `b298fad4ca290167d362f9b47a3dfd3851d9d678b0dee653131426b7b6bdde7c` |
| Zero-private three/four | [three-donor-signed-index.md](../edge32081/three-donor-signed-index.md) | `3730bdcf93a277f30a02a9604617607c5f7d13c5bf9f944e08dc332ef8d3bd2a` |
| Zero-private three/four | [zero-private-k4-audited-index.md](zero-private-k4-audited-index.md) | `4fefdd93e531c346143062b630476641786796f59f08b33082c3ee6ec8ba3094` |
| Final positive OR branches | [or07-two-fork-high-cut.md](or07-two-fork-high-cut.md) | `021bdb4ffe5ce2c4d95fd86e7a1581e23e9fc16844bc28330c800e9c5d6d9b7c` |
| Final positive OR branches | [or57-routing.md](or57-routing.md) | `12c4cdfd0234a5c3ffd7ea51642e76fd425e35f565f9d775ad56762817243ddd` |
| Final positive OR branches | [or57-neighbor-guard-close.md](or57-neighbor-guard-close.md) | `61925995e3604ba44cb052fdf1bdb5afb23305c3c5ddd4108f6418531486d3ff` |
| Final positive OR branches | [or57-routing-independent-review.md](or57-routing-independent-review.md) | `d8f6aab8e6307d5b200d3e18cd5a399c1d3f3842d6ed5db53829541b294ef2d0` |
| Final positive OR branches | [or67-pure-normalization.md](or67-pure-normalization.md) | `b1ff5fac4aa4ff5d4ad8f33dda67373f6c504ab166073e1ce5fd76be86f164d9` |
| Final positive OR branches | [positive-or67-high-six.md](positive-or67-high-six.md) | `cf9fa8a9ab5773c040821125938ad0958ad96bc36a4099a472bdfe1f71bfaa57` |

The frozen smaller result and approved census are previously checked resources. Other hashes identify manuscript interfaces and stated component reviews. Independent backup searches or overlapping root proofs are supplementary. No packaging, numerical execution, or official source edit was performed.

At the indexed family times, 07/r01 accepted exhaustion as a routing map, 09/w07 accepted singleton integration, 09/w02 accepted the three/four-donor routing interfaces, and 09/w10 accepted the three constituent rank receipts. These are scoped reviews conditional on the component results. The integrated rank source above is separately frozen.
