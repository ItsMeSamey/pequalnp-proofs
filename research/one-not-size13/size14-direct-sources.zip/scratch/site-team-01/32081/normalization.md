# Exact gate semantics and finite search for 32081

The issued theorem quantifies over arbitrary natural-number indices and does not require topological references. Its operation and fan-in premises restrict every gate to AND, OR or NOT and at most two input indices. At most one gate has operation NOT. In the issued definitions, GateOp.eval uses all, any and the negation of headD false, respectively. Circuit.wires is a left fold that appends one Boolean after evaluating all indices in the current prefix with getD false. Circuit.eval reads its output with the same default. See lean/PEqualNP/Defs/CircuitLowerBounds.lean, lines 35–64, and lean/PEqualNP/Outside/L_meta_32081.lean in the issued repository.

## Exact, length-preserving finite representative

At zero-based gate position $j$, the fold prefix has length $m=8+j$. Replace every incoming index $r$ by $\min(r,m)$. If $r<m$, the value is unchanged. If $r\ge m$, both the original index and the replacement index $m$ return false on this prefix. Crucially, index $m$ names the gate about to be appended and does not refer to its eventual value. An index invalid at this step may become valid at some later step; only its use at this step is being replaced. Induction on the fold therefore gives literally identical lists of Boolean wire values on each input. At the end replace $o$ by $\min(o,8+n)$ for $n$ gates. Operations, gate count and number of NOTs are unchanged.

| Gate | Zero inputs | One input $a$ | Two inputs $a,b$ |
|---|---|---|---|
| AND | true | $a$ | $a\land b$ |
| OR | false | $a$ | $a\lor b$ |
| NOT | true | $\neg a$ | $\neg a$ |

Here $a$ and $b$ already include invalid-index defaults. In particular, NOT on a forward first input is true even when its second input is valid. NOT with no inputs can be represented by NOT on the singleton sentinel $m$. AND and OR inputs may be sorted. At this position each of these two operations then has $1+(m+1)+\binom{m+2}{2}$ possible lists, counting multisets of sizes zero, one and two from $m+1$ indices. NOT has $m+1$ choices after reduction to one input. Output has $8+n+1$ choices. This representation alone suffices for a finite bounded-length search.

## Strict representative for a nonconstant target

For each old input or gate wire, retain an alias: literal constant false, literal constant true, or an index in the new list of primary inputs and previously emitted gates. These constants are bookkeeping tags, never uncharged circuit wires. Initialize primary aliases to their matching indices. At every old step translate old input references by the alias table, translating a reference past the current table to false. Apply the truth table above as follows.

1. Fold empty gates to constants. Alias unary AND/OR and repeated equal operands. Apply $0\land a=0$, $1\land a=a$, $0\lor a=a$, and $1\lor a=1$. If both remaining operands are genuine distinct earlier wires, emit one binary gate on those wires in ascending order.
2. For NOT, discard any second operand. Negate a constant tag immediately; otherwise emit one unary NOT on the translated first operand.
3. Append the resulting alias to the old-wire table. Reindex each newly emitted wire as eight plus the count of previously emitted gates, regardless of how many old gates were omitted.

The invariant is simultaneous over all 256 inputs: every old prefix wire equals its alias interpreted on the new prefix. Appending an emitted gate preserves every earlier new wire. The new gate count grows by at most one per old step and only grows the NOT count while processing an old NOT. The output lookup uses false for an invalid old index. If it gives a genuine wire, that wire therefore computes the original output. If it gives a constant tag, the extension to a general constant-output theorem would need an explicit constant realization; the target here rules out both tags.

Indeed, the target is false on the zero input and every singleton and true on the input with exactly bits 0 and 3 set. The zero input rules out constant true; that edge rules out constant false; the singleton of each input rules out that projection. Consequently, the output of the strict representative is an emitted gate. Keep its ancestor gates, delete all others, and remap surviving indices in order. Every retained input reference is a primary or a retained predecessor; their truth values persist by induction. The output gate is now last. As all retained gates feed it, no dead-gate assumption is needed on the original list.

Thus the bounded search may use exactly eight primary inputs, AND/OR on two distinct earlier wires and at most one NOT on one earlier wire. It may assume the output is last and all gates reach it when it enumerates all lengths up to the bound. For a single exactly-$k$ SAT encoding, allowing dead gates permits padding a shorter strict witness *before* all original gates with copies of an arbitrary primary-input binary operation, shifting gate indices and retaining its last output. Do not combine this padding claim with an all-gates-reach-output, no-duplicate, or other irredundancy restriction without a separate proof. Distinct operand indices are also different from semantically different operands: only the former restriction was used above.

## A direct finite cutoff

The following 15-gate monotone upper bound is obtained directly from the twelve pairs in the statement. Number its outputs consecutively from 8 to 22.

| Wire | Operation | Operands |
|---:|---|---|
| 8 | OR | 1,2 |
| 9 | OR | 3,8 |
| 10 | AND | 6,9 |
| 11 | OR | 0,2 |
| 12 | AND | 5,11 |
| 13 | OR | 0,8 |
| 14 | OR | 4,5 |
| 15 | OR | 13,14 |
| 16 | AND | 7,15 |
| 17 | AND | 0,3 |
| 18 | AND | 1,4 |
| 19 | OR | 10,12 |
| 20 | OR | 16,17 |
| 21 | OR | 18,19 |
| 22 | OR | 20,21 |

Wire 22 ORs the five groups $x_6(x_1\lor x_2\lor x_3)$, $x_5(x_0\lor x_2)$, $x_7(x_0\lor x_1\lor x_2\lor x_4\lor x_5)$, $x_0x_3$, and $x_1x_4$. Distributing recovers precisely the stated edges, so any antecedent circuit with at least 15 gates is covered by this witness. A shorter monotone construction could reduce this cutoff. No optimality claim is needed for the cutoff itself.
