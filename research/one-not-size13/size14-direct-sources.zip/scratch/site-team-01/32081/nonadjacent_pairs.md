# Nonadjacent two-input blocks at the earliest internal fork

Use the notation and excess accounting of first_fork.md and pair_rules.md. All visible inputs not named in a setting are zero. For a pair of private bits $u,v$ write $P$ for their common external neighbors and $U,V$ for the two exclusive sets. An untouched external neighbor $c$ in $P$ must be adjacent to all $U\cup V$; one in $U$ must be adjacent to all $V$; one in $V$ must be adjacent to all $U$. Untouched common neighbors and untouched exclusive neighbors cannot coexist, and untouched exclusive neighbors from both sides cannot coexist. These facts are the empty- and singleton-setting row tests. Neutral vertices, adjacent to neither private vertex, can be in either $A$ or $C$.

The following short arguments specify all the charges used in the table. Each excess unit mentioned is in addition to $1+|A|$ for $H$ and the visible bypasses.

* **Switch.** When only exclusive neighbors of one side are retained in $C$, each exclusive vertex on the other side switches the fork bit from one private literal at the empty setting to the other private literal at its singleton setting. Each such selector is binate and costs a separate duplication.
* **Two arms.** Suppose two contexts give fork bits $u$ and $v$ and adding a common selector $p$ changes both to $u\lor v$. For each of $(p,u),(p,v)$ there are then AND and OR cofactors, as in first_fork.md. One such $p$ requires a duplication among $\{p,u,v\}$; two different such selectors require at least two duplications. An exclusive switch selector is disjoint from this charge. The contexts used below are empty and a switch singleton, or one singleton from each exclusive side. In the latter case $p$ is chosen nonadjacent to both singletons.
* **Five distinct inputs.** Suppose $a\in U$, $b\in V$ are nonadjacent and $p\in P$ is visible. The contexts $\{a\},\{b\},\{a,b\},\{p\}$ give $u,v,u\lor v,u\lor v$. At least one of $u,v,a,b,p$ has multiple paths into $H$. Otherwise the private variables meet at a unique binary node with two private arms. Comparing $\{b\}$ to $\{a,b\}$, $a$ must enter the $u$ arm; comparing $\{a\}$ to $\{a,b\}$, $b$ must enter the $v$ arm. Indeed in both contexts the merge passes private dependence, and presence/absence of each private variable then exactly reflects whether its arm is nonconstant. Now compare $\{b\}$ with $\{p\}$: $b$ cannot affect the $u$ arm, so $p$ must enter it. Comparing $\{a\}$ with $\{p\}$ similarly puts $p$ in the $v$ arm. This contradicts its assumed unique path. No independence between $p$ and $a$ or $b$ was assumed.
* **Suffix faces.** At any fixed $A,B$ assignment, $H$ is fixed independently of every variable of $C$, whether or not its value is known. Thus an edge entirely in $C$ gives an AND cofactor at the all-zero background. If an independent background hits both endpoints it gives an OR cofactor on the same pair, forcing a further suffix outlet as long as the pair remains in $C$. The two cofactors may use different fixed values of $H$. Faces involving a visible variable require a common attainable cut value across the varying visible assignments. The applications below ensure this by showing that the canonical low bit 0 is available. A full majority triangle in the suffix costs at least two outlets, by the majority proof in pair_rules.md.

## Neighborhood table

The first three columns identify the entire exterior neighborhood. The column “possible retained” gives groups of neighbors that may be left in $C$; any subset of one listed group is permitted by this preliminary test, including the empty subset. All neighbors outside the chosen subset must belong to $A$.

| Pair $(u,v)$ | $P$ | $U$ | $V$ | Possible retained neighbors |
|---|---|---|---|---|
| 0,1 | 7 | 3,5 | 4,6 | none |
| 0,2 | 5,7 | 3 | 6 | {3} or {6} |
| 0,4 | 7 | 3,5 | 1 | none |
| 0,6 | 3 | 5,7 | 1,2 | {7} or {2} |
| 1,2 | 6,7 | 4 | 5 | {7} |
| 1,3 | 6 | 4,7 | 0 | {7} |
| 1,5 | 7 | 4,6 | 0,2 | none |
| 2,3 | 6 | 5,7 | 0 | {5,7} or {0} |
| 2,4 | 7 | 5,6 | 1 | {6} |
| 3,4 | none | 0,6 | 1,7 | none |
| 3,5 | 0 | 6 | 2,7 | {2} |
| 3,7 | 0 | 6 | 1,2,4,5 | {1,2} |
| 4,5 | 7 | 1 | 0,2 | {7} |
| 4,6 | 1 | 7 | 2,3 | {2} |
| 5,6 | 2 | 0,7 | 1,3 | none |
| 6,7 | 1,2 | 3 | 0,4,5 | {0} |

Each line below requires at least seven excess outlets. The size-14 budget is six.

1. **0,1.** Five mandatory visible neighbors. Apply two arms with exclusive contexts 3 and 6 and common 7.
2. **0,2.** The three cases are proved in first_fork.md.
3. **0,4.** Four mandatory neighbors. Use five distinct inputs with $a=3,b=1,p=7$. If a neutral vertex is visible the budget is already exceeded. Otherwise $C=\{2,6\}$, and this suffix edge gives OR at the background {1,5}, requiring another outlet.
4. **0,6.** If 7 is retained, the four mandatory neighbors and the two switches 1,2 suffice. If 2 is retained, use the four mandatory neighbors and switches 5,7. If none is retained, use five mandatory neighbors and two arms on exclusive contexts 5,1 and common 3.
5. **1,2.** If 7 is retained, the empty bit is $u\lor v$ and the singleton selectors 4 and 5 reduce it to $u$ and $v$, respectively. Turning either selector on in the presence of the other gives $u\lor v$ again since 4,5 are independent. Each selector therefore has both derivative signs. The common 6 is independent of both and gives another duplication by two arms. Alongside at least three bypasses these charges suffice. If 7 is not retained, there are four mandatory bypasses and the same two-arms charge. If there are only four bypasses, $C=\{0,3\}$, a suffix conflict at {5,6}.
6. **1,3.** If 7 is retained, switch 0 and the separate two-arms charge using common 6 (nonadjacent to 0) supplement the three mandatory bypasses. If there is no extra bypass, the outside triangle **0,5,7** is available: it has only its vertex 0 visible. At $S=\varnothing$ and $\{0\}$ both private row classes occur, hence its full majority is exposed at $H=0$. If no neighbor is retained, use four mandatory bypasses and two arms on 4,0 with common 6. If no extra bypass exists the suffix edge 2,5 gives OR at {7}.
7. **1,5.** Five mandatory visible neighbors. Apply five distinct inputs with $a=4,b=0,p=7$.
8. **2,3.** If both 5 and 7 are retained, switch 0 and the two-arms charge using 6 supplement two mandatory bypasses. A full triangle 0,5,7 is exposed at $H=0$: 0 is its only visible vertex and both settings have two rows. If exactly one of 5,7 is retained there are at least three bypasses and the same charges. With no extra bypass, the suffix edge 1,4 gives OR at {7}; if 7 is retained this is a fixed untouched background and if 5 is retained it is a fixed visible background. If 0 is retained, use the three mandatory bypasses, switches 5 and 7, and the additional two-arms charge from common 6 using either switch. If none is retained, use four bypasses and two arms on 5,0 using 6; at exactly four bypasses $C=\{1,4\}$ has the conflict at {7}.
9. **2,4.** See the additional cases below.
10. **3,4.** See the additional cases below.
11. **3,5.** If 2 is retained, use at least three bypasses, switch 6 and an additional two-arms charge using common 0. At exactly three bypasses the untouched edge 1,4 gives OR at {7}. With no retained neighbor use four bypasses and two arms on 6,2 using 0; at exactly four the same edge 1,4 gives the same conflict.
12. **3,7.** If one or both of 1,2 are retained, use at least four mandatory bypasses and switch 6. At exactly four bypasses apply two arms with common 0, which is nonadjacent to 6. If neither is retained six bypasses alone, together with $H$, suffice.
13. **4,5.** If 7 is retained the empty bit is $u\lor v$; singleton selectors 1 and 0 or 2 yield $u$ and $v$, respectively. Each of 0,1,2 has both derivative signs, by toggling it at the empty setting and in the presence of a nonadjacent opposing exclusive selector. Each costs a duplication, besides three bypasses. With no retained neighbor use four bypasses and five distinct inputs with $a=1,b=0,p=7$; at exactly four bypasses the untouched edge 3,6 gives OR at {0,1}.
14. **4,6.** If 2 is retained, switch 7 supplements three mandatory bypasses. With no extra bypass the outside triangle 0,5,7 has only its vertex 7 visible; both relevant settings have two rows, exposing majority. With extra bypass 0 the untouched edge 2,5 conflicts at {7}. With extra bypass 5 the edge 0,5 gives AND at the empty background and OR at {2,3}: 5 and 3 are visible but nonadjacent, the empty setting has two rows, and each of {3},{5},{3,5} admits $H=0$. In particular, 5 is a *neutral extra input*, and at setting {5} alone vertex 5 masks retained neighbor 2, leaving only one row. The value $H=0$ at this singleton requires the argument below. With both extras the switch and bypasses already suffice. With no retained neighbor use four bypasses and five distinct inputs $a=7,b=3,p=1$; at exactly four, the untouched edge 0,5 conflicts at {7}.
15. **5,6.** Five mandatory bypasses and five distinct inputs with $a=0,b=1,p=2$.
16. **6,7.** If 0 is retained, five bypasses and switch 3 suffice. Otherwise all six exterior vertices are visible.

## Single-row neutral context in case 4,6

In the extra-5 case of line 14, the prefix and $H$ have already spent six excess outlets (four bypasses, the binate selector 7 and $H$). Any additional duplicate immediately excludes the layout. Otherwise raw selector 3 has a unique path into $H$ and has an observed positive derivative: the bit changes from $u$ at $\{7\}$ to $u\lor v$ at $\{7,3\}$. Its single-path sign is fixed, so it is nondecreasing everywhere. The set $\{5,3\}$ is independent and hits a private neighbor, thus $H(00,\{5,3\})=0$. Consequently $H(00,\{5\})=0$. This fills the required neutral corner of the AND/OR suffix conflict. No assumption on bits at an arbitrary single-row setting is needed.

## Case 2,4

With no retained private neighbor, the mandatory visible set is $\{1,5,6,7\}$. Five distinct inputs with exclusive vertices 5 and 1 and common vertex 7 cost a duplicate. At exactly four bypasses $C=\{0,3\}$, whose edge gives OR at independent background $\{5,6\}$.

If 6 is retained, the mandatory visible set is $\{1,5,7\}$. Selector 1 is binate: the empty bit is $u=x_2$ and the bit at $\{1\}$ is $v=x_4$. With both neutral vertices 0,3 also visible, five bypasses, selector 1 and $H$ suffice. With extra 0 only, $C=\{3,6\}$ has the edge conflict at $\{0,1\}$. With extra 3 only, consider pair (0,3), which gives AND at the empty background and OR at $\{5,6\}$. Here 3 is visible. Only its singleton $\{3\}$ may lack two rows. Unless there is already an additional duplication, selector 5 has a unique path to $H$ and is positive, as witnessed by the switch from $v$ at $\{1\}$ to $u\lor v$ at $\{1,5\}$. Since $\{3,5\}$ is independent and hits a private neighbor, $H(00,\{3,5\})=0$, forcing $H(00,\{3\})=0$. This gives the common cut value 0 for the cofactor comparison.

With precisely the three mandatory bypasses, $C=\{0,3,6\}$. The untouched edge 0,3 gives a suffix conflict at $\{5,6\}$, hence any additional prefix duplication beyond selector 1 suffices. Otherwise $u,v,5,7$ all have a unique path into $H$. At contexts $\{1\}$ and $\{1,5\}$ the bit changes $v\to u\lor v$, so 5 must reach the $u$ arm below the unique private merge. At the empty and $\{7\}$ contexts it changes $u\to u\lor v$, so 7 must reach the $v$ arm. The merge in negation-normal form is OR, since a genuinely bivariate cofactor on the private inputs is positive OR. Fix selector 1 and both private bits to zero. At the empty, $\{5\}$ and $\{7\}$ settings the bit is zero. As 5 and 7 enter distinct OR arms and neither reaches the post-merge tail, both arms must still be zero at $\{5,7\}$: each sees the input of its corresponding singleton setting. More explicitly, the post-merge unary map passes the merge for these fixed post-merge inputs, since the private variables are active at $\{7\}$. Thus $H=0$ for all four assignments to visible 5,7. The suffix at cut value zero now realizes majority on the outside triangle 0,5,7. Its two additional outlets together with $H$, three bypasses and selector 1 give seven.

## Case 3,4

All four exterior neighbors are visible, with $U=\{0,6\}$ for $u=x_3$ and $V=\{1,7\}$ for $v=x_4$. At a singleton in $U$ the bit is $u$, at one in $V$ it is $v$, and at an independent cross pair it is $u\lor v$. Each exclusive vertex has at least one independent opposite partner (0 pairs with 1, and 6 pairs with 7). Toggling any such vertex from the opposite singleton to their pair gives it a positive derivative. If there are two extra neutral bypasses, the six bypasses plus $H$ suffice.

First suppose there is no extra bypass, so $C=\{2,5\}$. The untouched edge 2,5 has a suffix conflict at $\{7\}$. Therefore if there is any prefix duplication the total is already seven. Otherwise each visible input has a unique positive path into $H$. At $B=00$ the bit is zero on $\{7\}$, so it is also zero at the empty visible setting. This gives the whole outside triangle 2,5,7 at $H=0$, hence *two* additional suffix outlets and seven total.

If exactly one neutral input (2 or 5) is additionally visible, the five bypasses plus $H$ already cost six. Suppose there is no further prefix duplication. Fix this neutral variable and the other neutral variable to zero. Every one of the four core selectors is positive, as just shown, and the two private variables are positive by their unique paths and witnessed positive derivatives. The resulting $H$ is monotone in all six remaining raw inputs. Every member of $U$ enters the $u$ arm and every member of $V$ enters the $v$ arm: comparing its independent opposite singleton with the corresponding cross pair turns its private variable from inessential to essential. Both arms survive to the merge, an OR in negation-normal form, and no core selector can modify the post-merge tail.

At the empty core setting the bit is bounded above pointwise by both $u$ and $v$ using monotonicity and the two singleton types. If it were true on private 11, this restriction would be AND, whereas an independent cross pair gives OR on these same two single-path private inputs. Thus the empty setting gives the constant zero function on the private bits. At $B=00$, neither arm can become true when both of its own core selectors are activated: suppose it did, with the other arm's selectors and other private bit held zero. On its private bit and its two core selectors the function would be majority3. At selector 00 the output is zero even for private 1; each singleton gives precisely the private bit; at selector 11 the output is true even for private 0, hence for private 1 by monotonicity. This contradicts the fixed single-path pair test. Consequently at $B=00$ each arm is zero for all assignments of its two core selectors. Their OR passes zero on the entire four-dimensional core face.

At the common cut value zero the induced graph on $0,7,1,6$ is exactly the path $0$–$7$–$1$–$6$. Its middle edge (7,1) is AND at the empty background and OR at background $\{0,6\}$. These two raw variables cannot both have single paths in the suffix, yielding the seventh excess. This also covers either choice of the sole neutral extra.

Together with the adjacent-pair table this argument addresses only **exactly two maximally dominated raw inputs at the first internal fork**. Other block sizes and circuits without such a fork still require separate treatment.
