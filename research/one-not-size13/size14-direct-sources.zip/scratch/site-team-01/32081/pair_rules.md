# Pair rules for a maximal dominated block of size two

Use the definitions, canonical-phase lemma and outlet budget in first_fork.md. For a private pair $u,v$, classify its external neighbors as common ($P$), exclusive to $u$ ($U$), or exclusive to $v$ ($V$). For any class $D$, let $D_C=D\cap C$. Every external neighbor omitted from $C$ belongs to the visible bypass set $A$.

## Adjacent pair

The empty context already produces a constant-true row on the private assignment 11 and a baseline row at 00 that is false on the empty external assignment. A single private vertex adding any external singleton would give a third row. Therefore $P\cup U\cup V\subseteq A$.

For any $p\in P$, with other visible inputs zero, the exact canonical bit on $u,v,p$ is majority on three inputs: at $p=0$ it is AND; at $p=1$ it is OR. Each pair among the three has both positive AND and positive OR as cofactors, giving an incompatibility triangle. At least two of these three raw variables have multiple paths into the first gate fork, in addition to the $|A|$ bypass charges.

| Private pair | Mandatory external neighbors | Common-neighbor witness | Required excess, including $H$ |
|---|---|---|---:|
| 0,7 | 1,2,3,4,5 | 5 | 8 |
| 1,7 | 0,2,4,5,6 | 4 | 8 |
| 2,7 | 0,1,4,5,6 | 5 | 8 |
| 4,7 | 0,1,2,5 | 1 | 7 |
| 5,7 | 0,1,2,4 | 0 | 7 |

Thus none of these five pairs is the exact maximal private pair at the first internal fork in a trimmed size-14 one-NOT circuit.

## Nonadjacent pair

There are only four possibilities after the zero-row and single-visible-input row tests.

1. If $P_C$ is nonempty, both $U_C$ and $V_C$ must be empty. Furthermore every $p\in P_C$ must be adjacent to every vertex of $U\cup V$. Otherwise a visible exclusive vertex creates a constant row through its own private neighbor and allows the other private vertex to augment the baseline with $p$.
2. If $U_C$ is nonempty and $P_C$ is empty, then $V_C$ must be empty, and every vertex of $U_C$ must be adjacent to every vertex of $V$. The empty setting forces the bit to equal $u$; each singleton visible input in $V$ forces it to equal $v$. In particular, every variable in $V$ is separately binate as an input to $H$ and needs multiple paths into it.
3. The case $V_C$ nonempty and $P_C$ empty is the preceding rule with $u,v$ interchanged.
4. If all three intersections with $C$ are empty, the entire private neighborhood is visible. A singleton in $U$ gives the bit $u$, a singleton in $V$ gives $v$, and a singleton in $P$ gives $u\lor v$.

The first three statements follow by evaluating the four private assignments at an empty or singleton visible setting. In the fourth case, these singleton settings are independent and both the baseline and constant-true rows occur. The row-cardinality tests alone do not charge the support changes; fixed phase and physical single-path incompatibility are needed for those charges.

## Bounded checker source

earliest_pairs.py uses the twelve edges in the issued statement. For each specified pair it examines exactly the 64 partitions of the six other vertices. It first separates distinct rows by the exact graph formula, then pins $H$ at every two-row context, then detects both derivative signs and incompatible bivariate truth tables on the pinned data. A pair of single-path variables can yield constants, functions of one variable, and one fixed genuinely bivariate AND/OR truth table with fixed literal/output phases. A minimum vertex cover of incompatible pairs, incorporating forced binate variables, lower-bounds the number of duplicated prefix inputs. Finally, a conflict between two raw suffix inputs after cutting $H$ costs at least one excess in addition to the charged prefix and the one excess for $H$ itself. The post-cut test uses only contexts where both cut-bit values are physically attainable. A surviving layout is a relaxation, not a circuit.

## The remaining seven adjacent pairs

For an adjacent private pair, its private assignment 00 forces the low row and 11 forces the high row at every independent visible setting. Thus, after cutting $H$ and fixing it to zero, the remaining raw target on every such setting is the edge function induced on vertices outside the private pair. The downstream calculation may have extra freedom when the visible set already contains an edge. All restrictions below use independent visible sets; one explicitly identified truth-table corner can stay unknown.

We count excess in the suffix after pinning $H=0$, separately from the charge for $H$'s outgoing edges. A raw bypass's one ordinary suffix outlet has already been paid for in the visible-input charge and is free in the restricted suffix. Any excess relative to one outlet per surviving suffix vertex is additional: specialize variables to constants, remove dead gates and contract identity gates. These operations cannot increase fanout excess. Equivalently, contracting a unary pass-through with $d$ outputs transfers at most its $d-1$ excess to its predecessor.

For a pair $i,j$ labeled **conflict**, the empty background gives AND (they form an edge). In the displayed background the pair gives OR: there is no background edge, but each endpoint closes an edge. Such a pair costs at least one additional suffix outlet. For **triangle**, set all raw inputs outside that triangle to zero. At most one of its vertices is visible; all eight assignments are therefore known with $H=0$. The resulting majority of three needs at least two additional outlets, even with arbitrary unary negations. With one or zero forks, a raw fork can duplicate only one variable and the remaining pair cannot exhibit both AND and OR. If the sole fork is an internal vertex, all its precursor inputs are private. If there are at most one such input, the other two again have single paths. If there are exactly two, majority has three cofactor rows on the untouched third input. If there are three, the output is a unary function of the fork, whose upstream cone is read-once, again violating the pair test.

Write $A_0$ for the mandatory external neighbors of the adjacent pair. If $P$ is nonempty, the majority argument above gives prefix cost at least $1+|A|+2$. Otherwise, the empty setting gives the private AND and an independent visible pair hitting both private vertices gives the private OR, so the prefix cost is at least $1+|A|+1$. For private pairs 1,6 and 2,6 one can take visible settings {4,2} and {5,1}, respectively; for 0,3 and 3,6 take {5,6} and {0,1}, respectively. These settings remain available if additional raw vertices join $A$.

| Private pair | $A_0$ | Visible-set cases still within budget | Suffix witness |
|---|---|---|---|
| 0,5 | 2,3,7 | exactly $A_0$ | conflict (1,6) at background {2,4} |
| 2,5 | 0,6,7 | exactly $A_0$ | conflict (1,4) at {7} |
| 1,6 | 2,3,4,7 | exactly $A_0$ | conflict (0,5) at {7} |
| 2,6 | 1,3,5,7 | exactly $A_0$ | conflict (0,7) at {3,4} |
| 1,4 | 6,7 | exactly $A_0$, or one extra | with no extra or extra 2 or 3: triangle (0,5,7); with extra 0: triangle (2,5,7); with extra 5: conflict (0,3) at {5,6} |
| 0,3 | 5,6,7 | exactly $A_0$, or one extra | no extra or extra 2: triangle (1,4,7); extra 1: conflict (2,7) at {4,6}; extra 4: conflict (1,6) at {2,4} |
| 3,6 | 0,1,2 | exactly $A_0$, or one extra | no extra or extra 4: triangle (0,5,7); extra 5: triangle (1,4,7); extra 7: alternating LCA constraints below |

In the final case, $A=\{0,1,2,7\}$, $C=\{4,5\}$. If all four remaining raw inputs $1,4,7,5$ had single paths in the suffix, their AND/OR tree after pushing inversions to leaves would assign a fixed label to the meeting gate of each pair. The pairs (1,4), (4,7), (7,5) all require an AND meeting gate at the empty background. The pair (4,5) requires OR at background {7}, and (1,5) requires OR at background {4,0}. For (1,7), set vertex 4 to one. The corners 00,10,01 then give 0,1,1. The 11 corner may be unspecified because 1 and 7 are adjacent and both visible. Of the single-path candidate tables (a literal, constant, or a possibly signed AND/OR on the pair), only the positive OR fits these three entries. The AND-labeled graph on the four raw leaves is the path 1–4–7–5 and its OR-labeled complement is also connected. At their top binary split, all crossing pairs must have the same LCA label. Every nontrivial split crosses both connected graphs, a contradiction. Thus this suffix also costs an additional outlet.

Combining these seven cases with the five incident-on-7 cases eliminates **all twelve adjacent private pairs** at the earliest internal fork of a trimmed eight-essential-input circuit of size at most 14 with one live NOT. This does not yet classify all the nonadjacent pairs.
