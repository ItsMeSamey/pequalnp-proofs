# Positive earliest shared tree with three or four distinct bypass donors

Model: a normalized live scalar size-14 circuit with at most one NOT; H is the earliest shared internal gate, its prefix is positive, and each of its k distinct raw donors has a separate bypass. Charge its l raw occurrences, including repeats, and at least one excess outlet of H. Since the overall budget is six surplus outlets, k≤l≤5 and the suffix after exposing H has at most 5−l other surplus outlets. This index is restricted to k=3,4.

| Leaves | Possible k | Classification |
|---|---|---|
| 3 | 3 | A positive AND root has a singleton zero certificate and is impossible by the one-vertex deletion bound. A positive OR root is either pure OR of all three or a singleton OR a two-raw product. Every pure OR is excluded. For a mixed root, every nonedge product is excluded; a true edge product is globally hoisted at equal cost, leaving only the singleton raw at the old readers. |
| 4 | 3,4 | Every positive AND or OR shape is excluded or has an equal-or-smaller physical rewrite. The four-leaf ledger distinguishes safe hoists and reduced donor prefixes from direct signed lower bounds. A repeated 7 at the two sides of an AND-of-OR reduces strictly. |
| 5 | 3,4 | The AND-root zero certificate on at most two raws leaves an impossible read-once residual. For an OR root the single remaining shared signal is H itself. The cited five-tap argument excludes accepted singletons and independent pairs. An accepted independent triple has a true exterior edge that would need two further distinct donors, impossible at k≤4. Thus H implies F and hoists globally. |

Primary hand sources:

- zero-private-three-four-roots.md for accounting, deletion bounds, AND roots and five leaves, together with /workspace/scratch/site-team-09/32081/zero-private-positive-five.md for the five-leaf care tests. An independent triple cannot contain 7, since its two nonneighbors 3 and 6 are adjacent, so the degree-three count used in the exterior-edge argument applies.
- accepted-seven-six.md, accepted-seven-donor-triangles.md, accepted-seven-nontriangle-triples.md, accepted-seven-two-singletons.md and three-or-without-seven.md for three-leaf pure OR.
- three-mixed-positive-ledger.md for three-leaf mixed OR, including the entire low-mask case table.
- four-leaf-positive-ledger.md for all four-leaf roots and every count of accepting singletons. Its x=2 and x=7 sections passed the requested independent review.

The reductions preserve the computed function and count every physical added gate. Some lead to independently studied smaller-prefix or later-fork cases; this index itself does not give a global circuit-size lower bound. Only the mixed x7/02 row has the additional complete 6561-partition machine receipt. Other entries rely on the linked analytic arguments.
