# Size-14 zero-private positive raw OR pairs

Scope: H=x_i OR x_j with both raw operands bypassing the earliest computed fork, 13 binary gates, and one NOT. A dot means no whole-pair exclusion recorded here. It does not certify realizability.

| i against higher j | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|
| 0 | A | Z | B/P | M | M | B | U |
| 1 | | A | H | P | G | H | J |
| 2 | | | B | E | E | B | K |
| 3 | | | | V | V | B/P | V |
| 4 | | | | | T | V | P |
| 5 | | | | | | Y | R |
| 6 | | | | | | | N |

**Current coverage:** All 28 pairs have whole-pair source arguments. Independent reviews are component-specific. The chronological counts below describe earlier snapshots.

* A identifies [OR01](or01-two-high-anchors.md) and [OR12](or12-one-high-anchor.md), independently reviewed at source hashes a2dcf0f7 and 7e5c0c9b.
* M identifies [OR04 and OR05](zero-private-or04-or05.md), independently reviewed at 2726da7c.
* Y identifies the [OR56 variable-donor high-six proof](../edge32081/positive-or56-or04.md). OR56 is recorded on its source argument; an independent review receipt is not attached here.

* B: [bowtie clamp](../../site-team-09/32081/bowtie-clamp-family.md), relying on the physical one-NOT seven-binary bowtie bound.
* P: [common tight faces](zero-private-paired-faces.md).
* G: [OR15 graft conversion](../../site-team-09/32081/or15-computed-negative.md) and [its interface](zero-private-or15-interface.md).
* E: [triangle ear](../../site-team-09/32081/triangle-ear-bound.md).
* T: [OR45 twin-cycle transfer](zero-private-or45.md).

Before T the 18 remaining entries were 01,02,04,05,07,12,13,16,17,27,34,35,37,45,46,56,57,67. T removes 45. The [192-row checker](../../site-team-09/32081/two_donor_modal09.py) describes an additional necessary test at H=1. Team 04 reports no known supervised receipt for that particular sweep. Neither the full-graph class census nor the separately approved 15-gate witness supplies any pair-specific modal count. No exclusion in this table is inferred from the missing modal receipt.

The OR45 twin-cycle transfer passed independent source review by team 09/w03. The proof accounts explicitly for the omitted twin as a possible pure control before concluding that both H-graft continuations are unique.

Team 09 confirmed that its all-pair modal checker is staged only and that the ten before the OR45 transfer agree with its source ledger. OR02 is assigned to team 09. Thus 11 closed physical OR pairs and 17 outstanding are recorded here, with no numerical modal exclusions added.

* J: [OR17 pendant-channel transfer](zero-private-or17.md), independently passed by 09/w03 at cb137992cc3e57856e60236798b3579bb937fba168d0dce5cdc47335f1de4279. The updated count is **12 source-closed, 16 outstanding**: 01,02,04,05,07,12,13,16,27,34,35,37,46,56,57,67. The earlier counts above record the pre-transfer stages.

The [endpoint-7 donor restrictions](zero-private-seven-edge-strata.md) give a computed-fork descent when no additional fork is raw for 07,27,57. At the opposite extreme, with all additional forks raw, two disjoint grafts that each erase an outside occurrence are excluded when both absorb at high H for 07,27, or at low H for 27. All three whole-pair entries remain open.

[OR27 computed-fork interfaces](or27-first-computed.md) give descent with no preceding outside raw, and with one preceding outside raw for all 30 monotone prefix layouts or 21 layouts without a prefix sign assumption. The note specifies the remaining signed layouts and constraints with two preceding raws. OR27 remains open.

The [completed one-preceding-raw OR27 proof](or27-first-computed.md) also handles the nine signed layouts, including the final all-neighbor mask, by using donor bypass placement. Remaining whole-pair cases have two preceding outside raw inputs to the sole later computed fork, or no later computed fork. This is a source candidate pending independent review.

* H refers to the independently reviewed [OR13 and OR16 high-chain proof](or13-or16-high-chain.md).
* V refers to the [OR34,35,37 high-3 bowtie and OR46 unit-cycle proof](zero-private-or34-35-37-46.md). These four manuscript cases are recorded on the author report, pending an explicit independent review receipt here.

The table now has 18 source-covered pairs and ten without a complete proof recorded here: **01,02,04,05,07,12,27,56,57,67**. The [OR27 terminal routing results](or27-terminal.md) settle all-raw and both-bypasses-in-K placements.

* K refers to the [OR27 terminal proof](or27-terminal.md) and the [first-computed fork analysis](or27-first-computed.md). These complete the author-level source candidate, with independent component review pending.

The current table records **19 source-covered pairs** and nine open pairs: **01,02,04,05,07,12,56,57,67**.

* Z is the independently checked [OR02 one-anchor proof](../../site-team-09/32081/or02-one-anchor.md), frozen at cf1ef44d, using the [OR12 transfer](or12-one-high-anchor.md) and the [OR02 low triangle-tail interface](../../site-team-09/32081/or02-pendant-interface.md). The low p=0 triangle-tail needs seven binaries and a live p folds one more. Pinning donor 0 high leaves units 3,5,7 and P4 4–1–6–2. Singleton 6 distinguishes donor 10 from 11, and singleton 3 distinguishes 01 from 11. The shedding conversion uses donor 0, and donor 2 retains the OR12-specific counting. The resulting global rewire decreases the number of computed forks on a price tie. The current open positive ORs are **07,57,67**.

* N refers to the [positive OR67 high-six proof](positive-or67-high-six.md), SHA cf9fa8a9, with the [four-graft normalization](or67-pure-normalization.md), SHA b1ff5fac. Types independently reviewed the one-absorber and corrected zero-absorber arguments. Current open entries: **07 and 57**.

* U refers to the [OR07 high-cut proof](or07-two-fork-high-cut.md), independently reviewed by types and 09/w02. R refers to the [OR57 routing proof](or57-routing.md) with its [final guard case](or57-neighbor-guard-close.md) and [independent review](or57-routing-independent-review.md). All 28 physical positive donor-OR entries now have source coverage.
