# Signed four-donor prefix with one later fork

The model is the normalized 14-gate zero-private earliest fork H with four distinct donor raws and exactly one later fork J. The only physical inverter is inside H. In the table m counts raw leaves of the single subtree fed to it. A cell records a structural conversion to a monotone circuit of at most 14 gates or an exclusion under the stated model.

| m | One H pin enters J | Both H pins enter J | Neither H pin enters J |
|---|---|---|---|
| 1 | A | B | C |
| 2 | D | E | F |
| 3 | G | E | F |
| 4 | G | E | F |

| Key | Source | SHA-256 | Independent source review received at indexing |
|---|---|---|---|
| A | zero-private-m1-split-complete.md | 7fa5193d118a1e22326a6c9c90062f6799bc541b2d8fb64853ca7d46c54dd382 | 09/w02 and 07/r10 |
| B | zero-private-m1-both-enter-j.md | 515b41b3aff334857d2dfca83b4b0b70a94f17bd6c317e83c4fbf346f9a2463b | 09/w02 |
| C | zero-private-m1-neither-enters-j.md | 0d435c38acfee3d56433c49c69f7b076395bb70fd70fabef4ec16c1317690502 | 07/r10 |
| D | zero-private-m2-frontier-final.md and its companion proofs | 7b06f10afbaac48f42dfeb232fddc7f6cc22bc92920f491e989dac51cf1e0817 | 09/w02 and 07/r10 for final 48-role frontier; the split/all-interior and equal-bit argument is in zero-private-one-j-split-inside.md |
| E | zero-private-both-in-multiple-donors.md | add9ba6fe6cd740972b0e4e0977c0841742703aa96ce723d91eadd35a0fc7b07 | requested 09/w02 |
| F | zero-private-neither-multiple-donors.md | 10b4efb40dbcb89491e9180c046ede7794fdc7263ffc7a9f8ce7fb3130f714c9 | requested 07/r10 |
| G | zero-private-split-three-four-repairs.md | 66ddd813fe4596dba2d3368bdea9af2cec0eb4a0ebb7267be9ba3d9f43c22937 | requested 09/w02 |

The source reviews address the indicated mathematical arguments. The model presupposes the occupied-class bound and identified small-graph lower bounds; the table does not give a formal verification of the entire issued theorem.

## No later computed fork

Thirteen binary gates on eight essential raws have six excess outlet pins. An empty H class and at least six occupied classes including the terminal require six distinct forks, hence all forks have exactly two physical outlet pins. Each of the four donor raws has a use inside H and a bypass, exhausting both slots. The sixth fork besides those four raws and H is either the computed J above, or a fifth raw outside H with both occurrences in the suffix. In particular the doubled raw cannot add a second positive bypass of an inverted donor. Trim to the designated output before counting. H cannot be that output because both of its consumers are live.

With no later computed fork the suffix cut at H is a positive output formula with two H leaves. Each inverted donor has one positive bypass leaf in this formula. In the logical NNF expansion of both H copies, clamp each of that donor's two negative leaves separately by its LCA with the single positive leaf (one for OR, zero for AND), using zero-private-signed-pin-guards.md. The fifth raw only appears positively; its two physical suffix occurrences remain wired to it. Repeat for all m donors. The one inverted subtree now evaluates to a constant independently at each H pin.

Retain positive side subtrees once. The post-inverter path has t≤4−m binary gates. Both constant endpoints cost zero gates at t≤1, at most one at t=2 and at most three at t=3: stage one produces a constant and an alias, stage two requires at most one binary gate, stage three at most two more. The former inverted subtree and NOT cost m gates, so this construction saves at least one against m+t for every m. Propagate constants and aliases without gates. Produce the surviving side subtrees and endpoints before their suffix consumers, preserve the suffix once and use its resulting output wire. Thus the no-J case has a monotone realization of at most thirteen gates for m=1,2,3,4.

Independent update: 09/w02 reviewed E and G, including the 67 argument, single inverted subtree and fresh-biclique price.

09/w02 independently checked the no-J five-raw outlet account. For D also include the split case with both inverted bypasses exterior. After logical expansion each negative donor has a unique exterior positive leaf; clamp every negative occurrence independently. Both H endpoints together cost at most one positive gate, including any retained side subtree since m=2. On the positive path from the interior H pin to J at most two side twigs can contain donor bypasses (the other two donors); any fresh-only twig is a singleton by two-sided pivotality, and two such singletons on the path would mask each other at the controlling value of the higher one. Thus the path has at most three gates. Duplicate that path to supply both J versions, sharing all its side twigs. The exterior H pin uses one endpoint already built. These at most four gates are paid by deletion of the four original H-prefix gates. This covers unequal interior bits when neither inverted donor bypass enters J.
