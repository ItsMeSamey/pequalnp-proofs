# Zero-private two-donor NOR at fourteen gates

Scope: strict, output-live earliest computed H=NOT(a OR b) on two distinct raw donors, each with a bypass. The table records whole-pair mathematical source claims rather than favorable routing subclasses. A claimed reduction to the existing size-13 or fewer-computed-fork induction is conditional on that induction and does not certify the full theorem. A positive OR pair is a different physical class.

| smaller donor | higher donors with a whole-pair source | higher donors still open |
|---|---|---|
| 0 | 1 Q, 2 Q, 3 V, 4 V, 5 Q, 6 B, 7 E | |
| 1 | 2 Q, 3 V, 4 V, 5 Q, 6 Q, 7 T | |
| 2 | 3 V, 4 V, 5 A, 6 B, 7 E | |
| 3 | 4 V, 5 V, 6 V, 7 V | |
| 4 | 5 V, 6 V, 7 V | |
| 5 | 6 Q, 7 E | |
| 6 | 7 U | |

* V: high3 bowtie and high4 optimum unit-path cuts in zero-private-two-nor-clamps.md; 13 pairs in their union.
* B: the separately recorded bowtie clamps 06,26 in team 09's bowtie-clamp-family.md. A: pair 25 uses the same two-donor-zero cut and the nine-binary C5 triangular-ear lower bound. With V this gives the original 16-pair count.
* Q: quantifiers' nor-01-12-05-15-low.md, nor-four-pair-upper.md and nor-02-16-56.md. Seven distinct pairs. Pure reader overlap uses a separate strict substitution and the graph monotonicity sandwich.
* T: zero-private-nor17.md transfers a tight-cycle graft to the independently solved physically positive OR17 at equal price, or saves a gate. A transfer that merely exposes a new positive fork is not used as an unproved rank.
* E: zero-private-nor27.md and its companion zero-private-nor07-57.md. NOR27 received notation's independent source pass conditional on the cited common-cut/guard proofs. Notation independently reviewed the frozen 07/57 companion (d41be7bf) and passed the 57 LCA switch, exceptional mask, and residual fourth-gate accounting conditional on the cited ordering and guard reductions; the separate 07/r01 review is pending. Their partial earlier r=0,3 results alone do not count as whole pairs.

* U: quantifiers' nor67-two-sided.md gives a candidate whole-pair 67 proof via the tight high-6 unit face and low P4 plus edge (SHA-256 217472351a18ae02e9defa7d46b93ca4ffdb27da5d8577d4fa59a3168af5ae3c). Independent review is pending.

Total: 28 durable whole-pair source claims, including candidates under review. This is not a count of 28 independently verified or kernel-checked exclusions. The review status of the separate Q, T and V dependencies is tracked by their respective owners.
