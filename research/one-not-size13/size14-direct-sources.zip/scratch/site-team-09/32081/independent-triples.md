# Independent private blocks of size at least three

Assume the earliest internal fork H and its maximal private B, visible A, untouched C as in first_fork.md. The eight-essential-input size-14 circuit with one live NOT has six excess outlets. H and A cost 1+|A|. Binate variables of H or a pair with both positive AND and positive OR cofactors require additional initial outlets into H.

Every independent B of size at least three occurs in the table. A block containing 7 can add only 3 or 6, which are adjacent. Without 7, the cycle 0–3–6–2–5–0 contributes at most two, and the edge 1–4 at most one. Vertex 1 cannot coexist with 6.

Write M(c)=N(c)∩B. At the empty visible setting the rows on C for private singleton b have neighborhoods N(b)∩C, all either empty or the same nonempty set, or else at least three rows occur including the empty row. Equivalently the bipartite cut between B and C is complete on its nonisolated vertices. In each table row all exterior vertices have nonempty, mutually distinct M(c), so |C|≤1. For a possible single c in C, a blocker is another exterior vertex a nonadjacent to c such that M(c) is not contained in M(a). Indeed at visible setting {a} the private empty assignment gives the baseline, a member of M(a) gives constant true, and a member of M(c) outside M(a) augments the baseline by c. These three rows disagree on empty C or singleton c.

In the table, digits in a mask are vertex names. The blockers align with the indicated exterior order. A dash denotes a candidate requiring a different argument.

| B | Exterior order | M in that order | Blockers | Selector; two contexts when C is empty | Private pair |
|---|---|---|---|---|---|
| 012 | 3,4,5,6,7 | 0;1;02;12;012 | 4,3,3,4,3 | 7;3,6 | 0,1 |
| 123 | 0,4,5,6,7 | 3;1;2;123;12 | 4,0,4,0,— | 6;4,5 | 1,2 |
| 135 | 0,2,4,6,7 | 35;5;1;13;15 | 2,4,0,0,6 | 0;6,2 | 3,5 |
| 046 | 1,2,3,5,7 | 46;6;06;0;04 | 2,—,1,1,3 | 3;5,1 | 0,6 |
| 024 | 1,3,5,6,7 | 4;0;02;2;024 | 3,1,1,—,3 | 5;3,6 | 0,2 |
| 234 | 0,1,5,6,7 | 3;4;2;23;24 | 1,0,1,0,6 | 6;0,5 | 3,2 |
| 345 | 0,1,2,6,7 | 35;4;5;3;45 | 1,0,1,7,6 | 0;2,6 | 5,3 |
| 456 | 0,1,2,3,7 | 5;46;56;6;45 | 1,0,1,7,3 | 2;0,3 | 5,6 |

With C empty, all five exterior vertices bypass H. Set the third private vertex zero and use each named singleton context. The canonical bit is respectively x or y on the private pair; adding the selector p (nonadjacent to both contexts) produces x OR y in both cases. For (p,x), fix y=1 in the first context to obtain OR, or y=0 in the second context to obtain AND. This extra duplication brings the charge to seven.

With nonempty C, the four bypasses and H cost five. Each of the following supplies two further duplications.

* B=123, C={7}. Empty A gives x1 OR x2, whereas {0} gives x3; raw 0 is binate. Both {6} and {0,6} give x1 OR x2 OR x3. For (6,x1), with x2=0, the empty background at x3=1 gives OR; the {0} background at x3=0 gives AND. One of 6 and 1 must be duplicated independently of raw 0.
* B=046, C={2}. Empty A gives x6 and {5} gives x0, forcing a binate raw 5. At {3} and {3,5} the bit is x0 OR x6. For (3,x0), empty background with x6=0 gives AND; {5} background with x6=1 gives OR. This forces a second duplication.
* B=024, C={6}. Empty A gives x2; {1} gives x4 and {3} gives x0. Each transition between two different private literals exhibits both directions, so raw 1 and raw 3 must both be duplicated.

Thus every independence case requires at least seven excess outlets.
