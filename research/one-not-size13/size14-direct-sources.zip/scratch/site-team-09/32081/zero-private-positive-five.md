# Five bypass donors and a positive OR at the earliest internal fork

Use the strict size-14, no-private equality profile in zero-private-equality09.md.
The five raw donors of H use all five raw forks. The sole remaining fork
is H; each original raw therefore occurs exactly once in the suffix formula
after separating the read-once positive five-leaf prefix H. The cut bit h
may occur twice. We treat formulas with a positive AND/OR prefix and OR root.

**Pair test.** On a rectangle of assignments on which h is fixed, two raw
variables each occur at most once in the signed suffix. Their LCA has fixed
operation and fixed input path signs whenever both variables remain pivotal.
Side inputs can kill a path, but cannot change its phase. A unary decoder
above the LCA can complement its output without changing the location of
its exceptional corner. Thus full positive AND (exceptional 11) and full
positive OR (exceptional 00) on the same pair are incompatible even at
different h and backgrounds. If uv is an edge and H({u,v})=0, positivity
of H keeps h=0 throughout the isolated pair cube, and F there is AND.
Consequently, whenever a controlling cube of H on disjoint variables gives
an OR restriction on u,v, the isolated pair must satisfy H({u,v})=1.

**Singletons.** If H({v})=1 then fixing v=1 makes the target read-once.
The induced graph outside N[v] has a P4 for v=0,1,5 and a triangle for
v=3,6; v=4 leaves an induced C5 and hence a P4. Delete the unit neighbors to see the obstruction. The remaining
choices are 2,7. At v=2 the entire target is 03∨14∨5∨6∨7. Each of
05,16,36,07,17,47,57 can produce OR by activating the mate of any tested
endpoint in a product term. Those edges cover all seven remaining vertices.
If 2 is the only accepted singleton, H must therefore use all seven further
vertices: any accepted pair with neither singleton accepted requires both
variables. At v=7 the target is 36∨0∨1∨2∨4∨5, and the analogous cross
edges 03,14,05,25,16,26 again cover all seven remaining vertices. If both
singletons are accepted, 03 gives AND with background {2} and OR with
background {6,7}. Both backgrounds force h=1. This eliminates all singletons.

**Independent pairs.** Suppose H accepts the independent pair S and rejects
all singletons. Fix S=1. The target becomes the OR of the units N(S) and
the induced graph outside N[S]. At most two vertices lie outside N[S] in
these sixteen cases. The table gives two disjoint remaining edges, each
admitting a high-face OR. If one vertex of a listed edge is outside N[S],
its cofactor is made a unit by raising its mate in the exterior edge.

| S | Cross edges | S | Cross edges |
|---|---|---|---|
| 01 | 36,47 | 02 | 36,57 |
| 04 | 36,17 | 06 | 17,25 |
| 12 | 36,47 | 13 | 26,07 |
| 15 | 07,26 | 23 | 16,05 |
| 24 | 16,57 | 34 | 07,16 |
| 35 | 07,26 | 37 | 05,14 |
| 45 | 16,07 | 46 | 03,17 |
| 56 | 03,17 | 67 | 03,14 |

The pair test forces H to accept both cross edges in isolation. All four
endpoints must be donors, in addition to both members of S. This exceeds five.

**Larger independent sets.** With no singleton, the two root children must
have support sizes two and three. The two-leaf child is ab, and its two
inputs form an edge. The other child either has only two-element minimal
true sets, or is the product cde. The former case is safe because all true
pairs are edges. In the latter case an unsafe minterm would be the independent
triple S={c,d,e}. The complete list of independent triples is 012,024,046,123,
135,234,345,456: no triple contains 7 (its two nonneighbors 3,6 are adjacent);
the five-cycle 0–3–6–2–5–0 permits at most two vertices, and 1,4 are adjacent.
Choosing one of 1,4 and two nonadjacent cycle vertices, excluding neighbors,
gives the displayed list. Each listed triple dominates all other vertices.
Thus on S=1 all five remaining vertices are units. Since all vertices of S
have degree at most three, at least three of the twelve original edges
survive outside S. Each must be accepted in isolation by H, but precisely
one exterior pair, ab, is accepted. This excludes the last unsafe form.

**Safe replacement.** If H implies F, there is a monotone replacement within
the size budget. In the suffix, any raw read under the sole NOT occurs just
once and is antitone when h is held fixed. At any actual assignment lower
such a raw to zero when H=0, or raise it to one when H=1. Monotonicity of H
preserves its value under this operation; monotonicity of F and opposing
antitonicity in the suffix force the output to remain equal. Repeat for all
negative raw reads. Hence one may reroute those bypass pins to H, keeping
the H producer intact. The inverted subtree now contains only reads of H
and possible constants, so after setting all suffix reads of h to zero
the subtree folds to a constant. The resulting monotone circuit B computes
the original target whenever H=0. Output H∨B: it is exact also when H=1
because H implies F. Folding deletes at least the original NOT, paying for
the added OR, and physical wire IDs can be compacted in topological order.
This proves replacement or exclusion for the stated class. It does not
classify general signed prefixes.
