# Two bypass donors and a mixed literal first fork at size 14

Let a≠b be ordered raw vertices of the eight-vertex graph of 32081. Work
in a normalized live circuit with at most 14 gates, one NOT, and an empty
first-internal-fork class H. Assume H is the two-gate prefix
(¬a) AND b or (¬a) OR b. Its input inverter is unshared. H has at least
two distinct binary readers. Both donors have a physical bypass; in
particular the raw chosen below has a direct reader outside the prefix.
Normalization excludes repeated-source readers such as H AND H, which would
otherwise give two pin occurrences but only one reader. All suffix gates
are AND/OR.

Clamp v=b to zero in the AND case, and v=a to zero in the OR case.
In either case H is constant. The inverter is either constant or its sole
consumer H is removed. The resulting function is the exact edge predicate
of G−v and is nonconstant.

**At least five physical deletions.** Remove the inverter and H. Every
distinct direct reader of H folds to a wire or a constant. Three or more
such readers already give five deletions. With exactly two readers, choose
a direct bypass reader K of raw v. If K is neither H reader, its input v=0
provides the fifth deletion. If K is an H reader, its two inputs are H and v,
so its output is constant. Follow any original live path from K to the
designated output. Any remaining H reader encountered before leaving the
set also emits a constant, since it sees H and a constant from the path.
The nonconstant output precludes that path ending inside the set. Its first
reader outside the set also folds, supplying a fifth distinct deletion.
The prefix gates precede K and cannot be on this forward path. Folding
a constant or alias and removing a dead gate preserves the physical DAG
semantics by remapping consumers and the designated output in order.

The monotone result has size at most nine. When v≠7 its degree is at most
three. Add an OR of its neighbors, AND it with raw v, and OR into the
restricted output. This uses degree(v)+1 ≤ 4 gates and computes the full
graph predicate. More generally this construction uses at most input size
minus one, since five deletions paid for at most four additions.

For v=7 the known monotone lower bound for G−7 is ten gates. Its graph
is the five-cycle 0–3–6–2–5–0 with the path 6–1–4 appended. The
five-cycle needs seven monotone gates, and pinning 1=0 plus a controlling
value of 4 in a normalized circuit removes at least three further gates
(see /workspace/scratch/site-team-01/32081/raw7-tight.md, “Deletion costs ten”).
Thus a size-at-most-fourteen original in this case is impossible.

This covers each of 56 ordered pairs for each connective. Independently,
if ab is an edge, a monotone suffix with H=(¬a) AND b also admits the simple
substitution H:=b: the sole enlarged corner is a=b=1, where the graph is
already true. The five-deletion argument does not require adjacency.
