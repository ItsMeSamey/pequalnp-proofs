import Mathlib

namespace PrivateEar8577

/-- A singleton distinguished variable can be moved above the paid AND.
The two exterior operands are shared wires supplied by the caller. -/
theorem expose_singleton (u p q : Bool) :
    ((u || p) && (u || q)) = (u || (p && q)) := by
  cases u <;> rfl

/-- Accepting exactly the conjunction on the all-exterior-zero face
forces opposite nonempty singleton supports, up to exchanging the pins. -/
theorem zero_face_orientation (iu iv ju jv : Bool)
    (hu : (iu && ju) = false) (hv : (iv && jv) = false)
    (huv : ((iu || iv) && (ju || jv)) = true) :
    (iu = true ∧ iv = false ∧ ju = false ∧ jv = true) ∨
    (iu = false ∧ iv = true ∧ ju = true ∧ jv = false) := by
  cases iu <;> cases iv <;> cases ju <;> cases jv <;> simp_all

/-- For the sealed wire (u OR p) AND (v OR q), two pairs of
different graph outputs force different wire values by domination.
The coefficient subscripts denote exterior {a}, {b} and {a,b}. -/
theorem double_capture_impossible
    (pB qB pAB qAB : Bool)
    (hp : pB = true → pAB = true)
    (atB : (pB && qB) ≠ (pB && true))
    (atAB : (pAB && qAB) ≠ (true && qAB)) : False := by
  have hpb : pB = true := by
    cases pB <;> simp_all
  exact atAB (by rw [hp hpb])

end PrivateEar8577
