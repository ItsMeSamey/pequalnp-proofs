"""Direct native parity checks on four genuine remote-chord ladder walks."""


def check():
    # Rungs 0..19. Initial temporary rung is absent; 40,41 are final cap leaves.
    edges = {(2*i, 2*i+1) for i in range(1, 20)}
    edges.update((j, j+2) for j in range(38))
    edges.update([(38,40), (39,41)])
    i = 1
    s, t = 2*i, 2*i+1
    X, U = 40, 38
    cases = [
        ([s, t], [s,t,X,U]),
        ([s], [s,t,X,t+2]),
        ([s,t+2], [s,t,X,t+2,U,t+4]),
        ([s,t+2,t+4], [s,t,X,t+2,t+4,t+6]),
    ]
    for contacts, local in cases:
        actual = edges | {(v,X) for v in contacts}
        selected = {0,1} | set(local)
        assert max(sum(v in e for e in actual) for v in range(42)) <= 4
        for v in selected:
            degree = sum(v in e and all(z in selected for z in e) for e in actual)
            assert degree % 2 == 1, (contacts, v, degree)
    print("Verified four original-witness first-conflict repairs.")


if __name__ == "__main__":
    check()
