# Polynomial witness search for two prescribed vertices in a graph of maximum degree four

Given a finite simple undirected graph and two named vertices, find an induced vertex set containing both names in which every selected vertex has odd degree. A witness can be disconnected. The polynomial reference implementation is quartic_window_solver.py. It uses only the Python standard library.

## Run the solver

From the extracted directory, enter:

```sh
echo '{"rows":[4,4,11,4],"pins":[0,1]}' | python solve.py
```

Bit j of rows[i] indicates adjacency to vertex j; vertices are numbered from zero. The example returns YES and the four original vertices. NO certifies infeasibility. For maximum degree four the dispatcher always invokes the polynomial solver. For larger degrees it invokes the earlier two-square solver, which decides all inputs with at most two ordinary four-cycles per edge and can return UNKNOWN on other inputs. Malformed input produces a diagnostic and exit code 2.

For direct Python use, quartic_window_solver.solve(rows,p,q) returns a status and an original-label mask or None.

## Why the search terminates

The original root is tested for small supports before trying the two exact first-step reductions: a paired relay or a triangle relay. The residual search extends ordered rungs with a twelve-rung window and tests both possible endings, two disjoint edges and a claw. A nonlocal chord on an accepting walk triggers one of four repairs giving an original witness. [Minimal witness shapes](quartic-minimal-odd-strip.md) · [First-conflict proof and reconstruction](quartic-ladder-first-conflict.md)

On indexed adjacency lists of maximum degree four, a separate algorithmic analysis gives deterministic O(n) time and O(n) space with bounded port numbers, direct-address states, a bounded-radius initial test, and an indexed reconstruction scan. The bundled Python reference uses adjacency masks, dictionaries, direct subset enumeration at the original root and explicit prefix comparisons. The linear bound applies to the adjacency-list algorithm. [Machine model and proof](quartic-window-linear-clock.md)

## Integrity and offline replay

```sh
sha256sum -c SHA256SUMS
python -I -S replay.py
```

Replay was validated with Python 3.12.14. The bundled NetworkX 3.7 wheel requires Python 3.12 or later and excludes 3.14.1. It supplies the atlas used by the tests and contains the upstream license. The replay extracts the wheel into a temporary directory, without installation or network access. Leave assertions enabled.

The two new replay programs check all eligible atlas pin pairs, seeded graphs, an original triangle relay, both cap types, globally conflicting walks and a repeated-label walk. The independent four-case fixture checks the raw induced degree of every vertex of each repaired witness. The other six programs replay the previous two-square walk, subcubic fold, measured quartic relay, overlap threshold, and history counterexample. These are correctness checks.

## Earlier bounds and comparison

The proof chain includes [the original two-square walk](two-square-odd-pair-walk.md), [subcubic folding](subcubic-two-odd-pins.md), [the measured quartic relay algorithm](quartic-two-odd-pins.md), and [the degree-four-site bound](quartic-exceptional-sites.md). Their original source files remain available here for independent replay.

Berman, Wang and Wargo's sharp 2n/5 theorem is for unmarked induced-subgraph cardinality in subcubic graphs without isolated vertices. The October fixed-width SAT manuscript, if its claim holds, gives a subexponential baseline on the width-five selector encoding; no SAT oracle is used by this solver. [Berman, Wang and Wargo](https://ajc.maths.uq.edu.au/pdf/15/ocr-ajc-v15-p81.pdf) · [Pinned October manuscript](https://github.com/openai/math/tree/92b516ef8e/preprints/The-Exponential-Time-Hypothesis-is-False-October-25-2026)
