"""Read a graph from stdin as JSON with rows (adjacency masks) and pins (two indices)."""
import json
import sys

import quartic_window_solver
import odd_pair_two_square_solver


def main():
    if hasattr(sys, 'set_int_max_str_digits'):
        sys.set_int_max_str_digits(0)
    try:
        data = json.load(sys.stdin)
        rows, pins = data['rows'], data['pins']
        if not isinstance(rows,list) or not isinstance(pins,list) or len(pins)!=2:
            raise ValueError('expected rows array and two pin indices')
        n = len(rows)
        if any(type(r) is not int or r < 0 or r.bit_length()>n or r>>i&1 for i,r in enumerate(rows)):
            raise ValueError('invalid simple adjacency row')
        if any(type(i) is not int or not 0<=i<n for i in pins) or pins[0]==pins[1]:
            raise ValueError('invalid pins')
        if any((r>>j ^ rows[j]>>i)&1 for i,r in enumerate(rows) for j in range(i)):
            raise ValueError('asymmetric adjacency')
        degree = max(r.bit_count() for r in rows)
        solver = quartic_window_solver if degree<=4 else odd_pair_two_square_solver
        status, result = solver.solve(rows,*pins)
        witness = None if result is None else [i for i in range(n) if result>>i&1]
        print(json.dumps(dict(status=status,witness=witness,solver=solver.__name__)))
    except (ValueError,KeyError,TypeError) as exc:
        print(str(exc),file=sys.stderr)
        return 2
    return 0


if __name__=='__main__':
    sys.exit(main())
