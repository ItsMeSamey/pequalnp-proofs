"""Polynomial native all-odd two-pin solver for simple graphs of degree at most four.

solve(rows,p,q) returns ('YES', original mask), ('NO',None), or ('UNKNOWN',None)
on unsupported inputs. The breadth-first search keeps at most twelve rung pairs.
"""
from collections import deque
from itertools import combinations

WINDOW = 12


def sites(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length()-1
        mask ^= bit


def word_mask(word):
    return sum(1<<i for i in word)


def valid(rows,word):
    selected=word_mask(word)
    return len(set(word))==len(word) and all((rows[i]&selected).bit_count()%2 for i in word)


def compatible(rows, recent, new, required):
    """Check the next vertex against the complete local induced pattern."""
    return new not in recent and all(bool(rows[new]>>j&1)==(j in required) for j in recent)


def extract(rows, pairs, cap, kind):
    """Decode an accepting walk in the actual reduced graph (head rung absent)."""
    sequence=[]
    for k,(s,t) in enumerate(pairs):
        sequence.append((s, () if k==0 else (pairs[k-1][0],)))
        sequence.append((t, () if k==0 else (pairs[k-1][1],s)))
    s,t=pairs[-1]
    c,d=cap
    if kind=='edges':
        sequence.extend(((c,(s,)),(d,(t,))))
    else:
        sequence.extend(((c,(s,t)),(d,(c,))))
    prefix=[]
    for x,needed in sequence:
        if compatible(rows,prefix,x,needed):
            prefix.append(x)
            continue
        # A repeated label forces an earlier chord at the introduction of its late neighbor.
        assert x not in prefix and needed
        u=needed[0]
        bad=[j for j in prefix if j not in needed and rows[x]>>j&1]
        i=next(k for k,pair in enumerate(pairs) if any(v in bad for v in pair))
        s,t=pairs[i]
        rail=1
        if s not in bad:
            s,t=t,s
            rail=0
        near=[pairs[i+j][rail] for j in (1,2,3)]
        base=[v for pair in pairs[:i] for v in pair]+[s,t,x]
        if rows[x]>>t&1:
            suffix=[u]
            case='two contacts'
        elif not rows[x]>>near[0]&1:
            suffix=near[:1]
            case='disjoint edges'
        elif not rows[x]>>near[1]&1:
            suffix=[near[0],u,near[1]]
            case='child disjoint edges'
        else:
            suffix=near
            case='child claw'
        selected=base+suffix
        assert valid(rows,selected)
        return word_mask(selected),case
    assert valid(rows,prefix)
    return word_mask(prefix),'clean '+kind


def strip(rows,p,q):
    """The input already includes the first relay's exact deletions and rung erasure."""
    initial=((p,q),)
    previous={initial:None}
    queue=deque([initial])
    while queue:
        state=queue.popleft()
        s,t=state[-1]
        recent=[v for pair in state for v in pair]
        for c in sites(rows[s]):
            for kind,req,partners in (('edges',(s,),rows[t]),('claw',(s,t),rows[c])):
                if not compatible(rows,recent,c,req):
                    continue
                for d in sites(partners):
                    if compatible(rows,recent+[c],d,(t,) if kind=='edges' else (c,)):
                        # Reconstruct terminal cap and one predecessor per suffix.
                        path=[]
                        key=state
                        while key is not None:
                            path.append(key[-1])
                            key=previous[key]
                        return extract(rows,path[::-1],(c,d),kind)[0]
            if not compatible(rows,recent,c,(s,)):
                continue
            for d in sites(rows[t]&rows[c]):
                if compatible(rows,recent+[c],d,(t,c)):
                    child=(*state[-(WINDOW-1):],(c,d))
                    if child not in previous:
                        previous[child]=state
                        queue.append(child)
    return None


def solve(rows,p,q):
    rows=tuple(rows)
    n=len(rows)
    full=(1<<n)-1
    if any(type(i) is not int or not 0<=i<n for i in (p,q)) or p==q:
        raise ValueError('two distinct valid pin indices required')
    if any(type(r) is not int or not 0<=r<=full or r>>i&1 for i,r in enumerate(rows)):
        raise ValueError('invalid simple adjacency row')
    if any(not rows[j]>>i&1 for i,r in enumerate(rows) for j in sites(r)):
        raise ValueError('asymmetric adjacency')
    pair=(1<<p)|(1<<q)
    other=list(sites(full^pair))
    for count in (0,2,4):
        for extra in combinations(other,count):
            word=(p,q)+extra
            if valid(rows,word):
                return 'YES',word_mask(word)
    if any(r.bit_count()>4 for r in rows):
        return 'UNKNOWN',None
    def branch(i,j,dead,exclude):
        active=full&~(dead|exclude)
        reduced=[r&active if active>>k&1 else 0 for k,r in enumerate(rows)]
        assert reduced[i]>>j&1
        reduced[i]^=1<<j
        reduced[j]^=1<<i
        result=strip(reduced,i,j)
        if result is not None:
            lifted=dead|result
            assert lifted&pair==pair and valid(rows,list(sites(lifted)))
            return lifted
        return None
    pr,qr=rows[p],rows[q]
    for u in sites(pr&~qr):
        for v in sites(rows[u]&qr&~pr):
            answer=branch(u,v,pair,(pr&~(1<<u))|(qr&~(1<<v)))
            if answer is not None:
                return 'YES',answer
    for x,y in ((p,q),(q,p)):
        for c in sites(pr&qr):
            for u in sites(rows[c]&rows[y]&~rows[x]&~pair):
                answer=branch(y,u,(1<<x)|(1<<c),
                              (rows[x]&~(1<<c))|(rows[c]&~(pair|(1<<u))))
                if answer is not None:
                    return 'YES',answer
    return 'NO',None
