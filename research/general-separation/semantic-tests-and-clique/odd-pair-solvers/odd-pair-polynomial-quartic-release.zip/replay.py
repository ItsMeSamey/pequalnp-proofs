"""Replay frozen tests using the bundled NetworkX wheel without installation."""
from pathlib import Path
import runpy
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

base = Path(__file__).resolve().parent
with TemporaryDirectory() as dependencies:
    with ZipFile(base/'wheels'/'networkx-3.7-py3-none-any.whl') as wheel:
        wheel.extractall(dependencies)
    sys.path[:0] = [str(base),dependencies]
    for name in ('odd_pair_c4_free','odd_pair_square_multiplicity_check',
                 'odd_pair_two_square_solver','odd_pair_subcubic','odd_pair_degree_four',
                 'two_square_history_check','quartic_window_check','quartic_ladder_conflict_fixtures'):
        print(name, flush=True)
        runpy.run_path(str(base/(name+'.py')),run_name='__main__')
