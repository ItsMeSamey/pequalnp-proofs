"""Direct original-graph census plus adversarial accepting walks for quartic_window_solver."""
from collections import Counter
from itertools import combinations
from random import Random
from quartic_window_solver import WINDOW,compatible,extract,solve,strip,sites
from odd_pair_square_multiplicity_check import graph,supports


def physical_walk(pairs,cap,kind,chords):
    edges=[]
    for i,(s,t) in enumerate(pairs):
        if i:
            edges.extend(((s,t),(s,pairs[i-1][0]),(t,pairs[i-1][1])))
    s,t=pairs[-1]
    c,d=cap
    edges.extend(((s,c),(t,d)) if kind=='edges' else ((s,c),(t,c),(c,d)))
    edges+=chords
    return graph(1+max(max(pair) for pair in edges),edges)


def certify_walk(rows,pairs,cap,kind):
    assert max(r.bit_count() for r in rows)<=4
    assert pairs[0][0]!=pairs[0][1] and not rows[pairs[0][0]]>>pairs[0][1]&1
    for i in range(1,len(pairs)):
        recent=[v for pair in pairs[max(0,i-WINDOW):i] for v in pair]
        s,t=pairs[i-1]
        c,d=pairs[i]
        assert compatible(rows,recent,c,(s,)) and compatible(rows,recent+[c],d,(t,c))
    recent=[v for pair in pairs[-WINDOW:] for v in pair]
    s,t=pairs[-1]
    c,d=cap
    assert compatible(rows,recent,c,(s,) if kind=='edges' else (s,t))
    assert compatible(rows,recent+[c],d,(t,) if kind=='edges' else (c,))
    selected,case=extract(rows,pairs,cap,kind)
    assert selected & 3 == 3 and all((rows[i]&selected).bit_count()%2 for i in sites(selected))
    return case


def main():
    import networkx as nx
    tally=Counter()
    def check(rows,pairs):
        feasible=list(supports(rows))
        for p,q in pairs:
            ws=[w for w in feasible if w>>p&w>>q&1]
            status,w=solve(rows,p,q)
            assert status==('YES' if ws else 'NO'),(rows,p,q)
            assert w is None or w in ws
            tally[status]+=1
    for g in nx.graph_atlas_g():
        if max(dict(g.degree()).values(),default=0)<=4:
            check(graph(len(g),g.edges()),combinations(range(len(g)),2))
    rng=Random(733901)
    for _ in range(140):
        n=rng.randrange(8,14)
        choices=list(combinations(range(n),2))
        rng.shuffle(choices)
        rows=[0]*n
        for p,q in choices[:rng.randrange(n,3*n)]:
            if max(rows[p].bit_count(),rows[q].bit_count())<4:
                rows[p]|=1<<q
                rows[q]|=1<<p
        check(rows,[rng.sample(range(n),2) for _ in range(3)])
    triangle=[22,41,1,2,97,146,400,352,704,256]
    assert solve(triangle,6,9)==('YES',1023)
    cases=Counter()
    pairs=[(2*i,2*i+1) for i in range(18)]
    cap=(36,37)
    for kind in ('edges','claw'):
        rows=physical_walk(pairs,cap,kind,[])
        cases[certify_walk(rows,pairs,cap,kind)]+=1
        assert strip(rows,0,1)==(1<<38)-1
    for layer in (0,2):
        for rail in (0,1):
            s,t=pairs[layer][rail],pairs[layer][1-rail]
            t1,t2=pairs[layer+1][1-rail],pairs[layer+2][1-rail]
            for targets,label in (((s,t),'two contacts'),((s,),'disjoint edges'),
                                  ((s,t1),'child disjoint edges'),((s,t1,t2),'child claw')):
                rows=physical_walk(pairs,cap,'edges',[(36,z) for z in targets])
                case=certify_walk(rows,pairs,cap,'edges')
                assert case==label
                cases[case]+=1
    # Physically identify both rails of a late rung with rung 1, then reuse rung 2.
    winding=pairs+[pairs[1],pairs[2]]
    rows=physical_walk(winding,cap,'edges',[])
    cases[certify_walk(rows,winding,cap,'edges')]+=1
    assert len({v for pair in winding for v in pair})<2*len(winding)
    for invalid,p,q in [([1,0],0,1),([2,0],0,1),([2,1],0,0),([2,1],0,2)]:
        try:
            solve(invalid,p,q)
        except ValueError:
            continue
        raise AssertionError('invalid input accepted')
    print('native corpus',dict(tally),'adversarial walks',dict(cases),'one repeated-rung walk')


if __name__=='__main__':
    main()
