# Two prescribed vertices in an induced all-odd subgraph

Find a set containing two specified vertices such that each selected vertex has odd degree within the selected set. The selected subgraph may be disconnected. Use Python 3.12 or later (excluding 3.14.1, per the bundled wheel metadata) for the included replay suite. The solver itself uses the standard library.

## Run a graph

From the extracted directory, run:

```sh
echo '{"rows":[4,4,11,4],"pins":[0,1]}' | python solve.py
```

Vertices have indices from zero. Bit j of rows[i] marks edge ij. Supply a symmetric simple graph and two distinct pins. The example returns YES with vertices 0,1,2,3. A YES witness always uses the supplied labels. NO certifies infeasibility. UNKNOWN means the graph falls outside the chosen solver's complete class.

| Input class | Guarantee |
|---|---|
| Each edge on at most two ordinary four-cycles | Deterministic O(n⁴) time and O(n²) space in the adjacency-matrix RAM model |
| Maximum degree three | Deterministic polynomial time via twin folding and the two-square walk |
| Maximum degree four with k degree-four sites | Deterministic 2^min(k,n/3) poly(n) time and polynomial space |

The dispatcher prioritizes subcubic inputs, then uses the two-square walk where applicable. Four-cycles may have chords. The original graph is never mutated. Each solver also exposes solve(rows,p,q), returning a status and an integer witness mask or None.

## Verify and replay

```sh
sha256sum -c SHA256SUMS
python -I -S replay.py
```

The bundled NetworkX 3.7 wheel provides the graph atlas for the replays and includes its license. Replay requires no network access or installation. Each module executes its own checks with assertions enabled. The history trace compares the residual truth for two visits with the same ordered pins and different remaining vertices.

## Proofs

Read [the two-square walk](two-square-odd-pair-walk.md), [the sharp witness-size threshold](odd-pair-square-overlap-threshold.md), [the subcubic reduction](subcubic-two-odd-pins.md), [the quartic search](quartic-two-odd-pins.md), and [the degree-four-site bound](quartic-exceptional-sites.md). The proofs give the machine model; Python mask operations scale with their number of limbs.

Berman, Wang and Wargo prove that a simple subcubic graph without isolated vertices has an induced all-odd subgraph on at least 2n/5 vertices, sharply. Their theorem optimizes cardinality without requiring either of two specified vertices. [Original paper, pp. 81–82](https://ajc.maths.uq.edu.au/pdf/15/ocr-ajc-v15-p81.pdf)

For degree four, the direct selector encoding has n variables, clause width at most five and at most 8n+2 clauses. Assuming the fixed-width SAT algorithm claimed in the October manuscript, this gives a subexponential SAT-based baseline; repeated pinning recovers a witness. The structural solvers and their proofs above are independent of this conditional comparison. [Pinned October manuscript](https://github.com/openai/math/tree/92b516ef8e/preprints/The-Exponential-Time-Hypothesis-is-False-October-25-2026)
