"""Observe actual DFS states of the native two-square solver, without altering its traversal."""
from inspect import getsourcelines
import sys
from odd_pair_two_square_solver import solve
from odd_pair_square_multiplicity_check import multiplicities, supports


def main():
    rows=[326,637,11,150,42,82,35,8,1,2]
    assert max(multiplicities(rows).values())==2
    lines,offset=getsourcelines(solve)
    visit_line=offset+next(i for i,line in enumerate(lines) if line.strip().startswith('remaining=list('))
    visits=[]
    def trace(frame,event,arg):
        if frame.f_code is solve.__code__ and event=='line' and frame.f_lineno==visit_line:
            values=frame.f_locals
            visits.append(tuple(values[name] for name in ('p','q','active','forced','depth')))
        return trace
    prev=sys.gettrace()
    try:
        sys.settrace(trace)
        status,w=solve(rows,8,9)
    finally:
        sys.settrace(prev)
    assert status=='YES' and list(supports(rows,768))==[w]
    classes=[]
    for p,q,active,forced,depth in visits:
        local=rows.copy()
        if depth:
            local[p]^=1<<q
            local[q]^=1<<p
        ws=[s for s in supports(local,(1<<p)|(1<<q)) if s&active==s]
        print((p,q),active,forced,depth,ws)
        if (p,q)==(1,3):
            classes.append((active,ws))
    assert classes==[(138,[]),(186,[170])]
    print('root witness',w)


if __name__=='__main__':
    main()
