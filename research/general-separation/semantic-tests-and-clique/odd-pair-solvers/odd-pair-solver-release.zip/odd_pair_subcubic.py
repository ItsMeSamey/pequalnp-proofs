"""Original-label all-odd witness search through two pins on subcubic graphs."""
from itertools import combinations
from odd_pair_two_square_solver import solve as square_solve


def folds(rows,p,q):
    """Return original labels of (erased,representative), in folding order."""
    active=(1<<len(rows))-1
    events=[]
    while True:
        rep={}
        for i,row in enumerate(rows):
            if i in (p,q) or not active>>i&1:
                continue
            neighborhood=row&active
            if neighborhood in rep:
                events.append((i,rep[neighborhood]))
                active ^= 1<<i
                break
            rep[neighborhood]=i
        else:
            return events,active


def solve(rows,p,q):
    rows=tuple(rows)
    n=len(rows)
    full=(1<<n)-1
    if any(type(i) is not int or not 0<=i<n for i in (p,q)) or p==q:
        raise ValueError('two distinct valid pins required')
    if any(type(r) is not int or not 0<=r<=full or r>>i&1 for i,r in enumerate(rows)):
        raise ValueError('invalid simple adjacency row')
    if any((rows[i]>>j ^ rows[j]>>i)&1 for i,j in combinations(range(n),2)):
        raise ValueError('asymmetric adjacency')
    if rows[p]>>q&1:
        return 'YES',(1<<p)|(1<<q)
    _,active=folds(rows,p,q)
    ids=[i for i in range(n) if active>>i&1]
    reduced=[sum(((rows[i]>>old)&1)<<new for new,old in enumerate(ids)) for i in ids]
    status,w=square_solve(reduced,ids.index(p),ids.index(q))
    if max((r.bit_count() for r in rows),default=0)<=3:
        assert status!='UNKNOWN'
    if w is None:
        return status,None
    witness=sum(1<<i for k,i in enumerate(ids) if w>>k&1)
    assert all((row&witness).bit_count()%2 for i,row in enumerate(rows) if witness>>i&1)
    return status,witness


def self_test():
    import networkx as nx
    from odd_pair_square_multiplicity_check import graph,supports
    counts=[0,0]
    def compare(rows,all_words=False):
        words=list(supports(rows))
        for p,q in combinations(range(len(rows)),2):
            both=(1<<p)|(1<<q)
            originals=[w for w in words if w&both==both]
            status,result=solve(rows,p,q)
            assert status==('YES' if originals else 'NO')
            assert result is None or result in originals
            counts[0]+=1
            if all_words:
                events,active=folds(rows,p,q)
                for w in originals:
                    for erased,rep in events:
                        if w>>erased&1:
                            counts[1]+=bool(w>>rep&1)
                            w ^= (1<<erased)|(1<<rep)
                    assert w in originals and w&active==w
    for g in nx.graph_atlas_g():
        if max(dict(g.degree()).values(),default=0)<=3:
            compare(graph(len(g),g.edges()),True)
    k33=[(a,b) for a in range(3) for b in range(3,6)]
    compare(graph(6,k33),True)
    # Missing edge 2--5. Their spare ports can be unused, distinct, or share a neighbor.
    for attachments in ([],[(2,6)],[(2,6),(5,7)],[(2,6),(5,6)],
                        [(2,6),(6,7),(7,5)],[(2,6),(5,7),(6,8),(7,8)]):
        edges=[e for e in k33 if e!=(2,5)]+attachments
        compare(graph(1+max(max(e) for e in edges),edges),True)
    assert counts[1]>0
    print('pin pairs',counts[0],'both-selected fold events',counts[1])


if __name__=='__main__':
    self_test()
