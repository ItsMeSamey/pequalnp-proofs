"""Witness-returning all-odd pair search for simple graphs of maximum degree four.

solve(rows,p,q,stats=None) returns ('YES',original mask), ('NO',None), or
('UNKNOWN',None) outside the recognized class. State histories stay separate.
"""
from itertools import combinations
from odd_pair_two_square_solver import sites


def solve(rows,p,q,stats=None):
    rows=tuple(rows)
    n=len(rows)
    full=(1<<n)-1
    if any(type(i) is not int or not 0<=i<n for i in (p,q)) or p==q:
        raise ValueError('two distinct valid pins required')
    if any(type(r) is not int or not 0<=r<=full or r>>i&1 for i,r in enumerate(rows)):
        raise ValueError('invalid simple adjacency row')
    if any(not (rows[j]>>i&1) for i,r in enumerate(rows) for j in sites(r)):
        raise ValueError('asymmetric adjacency')
    if stats is None:
        stats={}
    stats.update(states=0,initial_children=0,later_max_children=0,max_depth=0)
    pins=(1<<p)|(1<<q)
    eligible=max(r.bit_count() for r in rows)<=4
    adj=[]
    for r in rows:
        data=r.to_bytes((n+7)//8,'little')
        adj.append(bytes((data[i//8]>>(i%8))&1 for i in range(n)))
    stack=[(p,q,full,0,0)]
    while stack:
        p,q,active,forced,depth=stack.pop()
        stats['states']+=1
        stats['max_depth']=max(stats['max_depth'],depth)
        pair=(1<<p)|(1<<q)
        optional=list(sites(active^pair))
        for size in ((0,2) if depth else (0,2,4)):
            for free in combinations(optional,size):
                word=(p,q)+free
                if all((sum(adj[i][j] for j in word)-int(bool(depth) and i in (p,q)))%2
                       for i in word):
                    result=forced|sum(1<<i for i in word)
                    assert result&pins==pins
                    assert all((rows[i]&result).bit_count()%2 for i in sites(result))
                    return 'YES',result
        if not eligible:
            return 'UNKNOWN',None
        pr=rows[p]&active&~pair
        qr=rows[q]&active&~pair
        if depth:
            assert max(pr.bit_count(),qr.bit_count())<=2
        # Under a paired relay, only exclusive neighbors survive at the two pins.
        left,right=pr&~qr,qr&~pr
        children=[]
        for u in sites(left):
            for v in sites(rows[u]&right):
                keep=active&~(pair|(pr&~(1<<u))|(qr&~(1<<v)))
                children.append((u,v,keep,forced|pair,depth+1))
        if not depth:
            # x is a leaf at common neighbor c, which has selected neighbors x,y,u.
            for x,y,xr,yr in ((p,q,pr,qr),(q,p,qr,pr)):
                for c in sites(xr&yr):
                    for u in sites(rows[c]&yr&~xr):
                        removed=(1<<x)|(1<<c)
                        forbidden=(xr&~(1<<c))|(rows[c]&~(pair|(1<<u)))
                        keep=active&~(removed|forbidden)
                        children.append((y,u,keep,forced|removed,1))
            stats['initial_children']=len(children)
        else:
            stats['later_max_children']=max(stats['later_max_children'],len(children))
        stack.extend(children)
    return 'NO',None


def self_test():
    from random import Random
    import networkx as nx
    from odd_pair_square_multiplicity_check import graph,supports
    rng=Random(430581)
    tally={'YES':0,'NO':0}
    def check(rows,pairs):
        words=list(supports(rows))
        for p,q in pairs:
            expected=[w for w in words if w>>p & w>>q & 1]
            status,w=solve(rows,p,q)
            assert status==('YES' if expected else 'NO'),(rows,p,q)
            assert w is None or w in expected
            tally[status]+=1
    for g in nx.graph_atlas_g():
        if max(dict(g.degree()).values(),default=0)<=4:
            check(graph(len(g),g.edges()),combinations(range(len(g)),2))
    for _ in range(160):
        n=rng.randrange(8,15)
        edges=list(combinations(range(n),2))
        rng.shuffle(edges)
        r=[0]*n
        for i,j in edges[:rng.randrange(n,4*n)]:
            if max(r[i].bit_count(),r[j].bit_count())<4:
                r[i]|=1<<j
                r[j]|=1<<i
        check(r,[rng.sample(range(n),2) for _ in range(3)])
    check(graph(8,[(i,j) for i in range(4) for j in range(4,8)]),combinations(range(8),2))
    check(graph(5,combinations(range(5),2)),combinations(range(5),2))
    foil=[28,28,19,19,15]
    assert solve(foil,0,1)==('NO',None)
    assert solve([326,637,11,150,42,82,35,8,1,2],8,9)==('UNKNOWN',None)
    # A triangle relay followed by paired relays.
    r=[22,41,1,2,97,146,400,352,704,256]
    assert solve(r,6,9)==('YES',1023)
    print('exactly compared pin pairs',tally)


if __name__=='__main__':
    self_test()
