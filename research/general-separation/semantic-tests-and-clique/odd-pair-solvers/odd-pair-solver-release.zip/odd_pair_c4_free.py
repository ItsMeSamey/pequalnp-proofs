"""All-odd induced support through two compulsory vertices of a simple graph.

solve(rows,p,q) returns ('YES', original mask), ('NO',None), or ('UNKNOWN',None).
It decides all graphs without a four-cycle as a subgraph, and can decide others.
Rows use bit i for vertex i. No recognition of the promised graph class is needed.
"""
from itertools import combinations


def bits(value):
    while value:
        bit = value & -value
        yield bit.bit_length()-1
        value ^= bit


def valid(rows, selected):
    return all((rows[i] & selected).bit_count()%2 for i in bits(selected))


def solve(rows, p, q):
    original = list(rows)
    n = len(original)
    active = (1 << n)-1
    if any(type(i) is not int or not 0 <= i < n for i in (p,q)) or p == q:
        raise ValueError('two distinct valid pin indices required')
    if any(type(r) is not int or not 0 <= r <= active or r >> i & 1
           for i,r in enumerate(original)):
        raise ValueError('invalid simple adjacency row')
    if any(not (original[j] >> i & 1) for i,r in enumerate(original) for j in bits(r)):
        raise ValueError('asymmetric adjacency')
    rows = original.copy()
    pins = (1 << p) | (1 << q)
    restore = 0
    def yes(selected):
        witness = selected | restore
        assert witness & pins == pins and valid(original,witness)
        return 'YES',witness
    while True:
        pair = (1 << p) | (1 << q)
        pr,qr = rows[p]&active,rows[q]&active
        if pr & (1 << q):
            return yes(pair)
        if not pr or not qr:
            return 'NO',None
        for i,j in combinations(bits(active ^ pair),2):
            w = pair | (1 << i) | (1 << j)
            if valid(rows,w):
                return yes(w)
        redundant = sum(1<<i for i in bits(pr&qr) if rows[i]&active == pair)
        if redundant:
            active ^= redundant
            continue
        if pr.bit_count()==qr.bit_count()==1 and not pr&qr:
            a,b = pr.bit_length()-1,qr.bit_length()-1
            if not rows[a] & qr:
                raise AssertionError('missed independent-edge witness')
            rows[a] ^= qr
            rows[b] ^= pr
            restore |= pair
            active ^= pair
            p,q = a,b
            continue
        reduced = False
        for leaf,other,neighbors in ((p,q,pr),(q,p,qr)):
            if neighbors.bit_count()!=1:
                continue
            c = neighbors.bit_length()-1
            if not rows[other] & neighbors:
                continue
            remainder = rows[c]&active&~pair
            if remainder.bit_count()!=1:
                continue
            b = remainder.bit_length()-1
            if not rows[other] & remainder:
                continue
            removed = (1<<leaf) | neighbors
            restore |= removed
            active ^= removed
            rows[other] ^= remainder
            rows[b] ^= 1 << other
            p,q = other,b
            reduced = True
            break
        if not reduced:
            return 'UNKNOWN',None


def c4free(rows):
    return all((r&s).bit_count()<2 for r,s in combinations(rows,2))


def self_test():
    import networkx as nx
    tally = {'YES':0,'NO':0,'UNKNOWN':0}
    complete = 0
    for graph in nx.graph_atlas_g():
        n=len(graph)
        rows=[sum(1 << j for j in graph[i]) for i in range(n)]
        promise=c4free(rows)
        truths=[w for w in range(1 << n) if valid(rows,w)]
        for p,q in combinations(range(n),2):
            status,w=solve(rows,p,q)
            exists=any(s >> p & s >> q & 1 for s in truths)
            assert status=='UNKNOWN' or (status=='YES')==exists
            if status=='YES':
                assert w in truths and w >> p & w >> q & 1
            assert not promise or status!='UNKNOWN'
            tally[status]+=1
            complete+=promise
    # Three private leaves on a triangle; these pins require all six sites.
    triangle = [16,32,8,52,41,26]
    assert c4free(triangle) and solve(triangle,0,1) == ('YES',63)
    assert [w for w in range(3,64,4) if valid(triangle,w)] == [63]
    # Two private leaves on a triangle give a NO case through the same pins.
    bull = [4,8,25,22,12]
    assert c4free(bull) and solve(bull,0,1) == ('NO',None)
    # One subdivision of all K_10 edges has no C4 and K_10 as a minor.
    g = nx.complete_graph(10)
    rows = [0]*(len(g)+g.number_of_edges())
    for v,(i,j) in enumerate(g.edges(),len(g)):
        rows[i] |= 1<<v
        rows[j] |= 1<<v
        rows[v] = (1<<i)|(1<<j)
    assert c4free(rows) and solve(rows,0,1)[0]!='UNKNOWN'
    print('1253 atlas graphs',tally,'C4-free pairs',complete,'subdivision vertices',len(rows))


if __name__=='__main__':
    self_test()
