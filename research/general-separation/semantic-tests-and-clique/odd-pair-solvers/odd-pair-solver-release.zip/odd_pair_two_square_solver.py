"""All-odd support through p,q in simple graphs with at most two C4 per edge.

Ordinary cycles include those with chords. solve returns (status, original mask);
outside the class only immediate YES answers are supplied. Optional stats collects
the number of expanded states, generated paths and deepest reduced state.

On the promised class there are O(n) states. Only the initial state tries six sites.
The adjacency-matrix RAM bound is O(n^4) time and O(n^2) space. The initial
quartic loop uses byte-indexed adjacency; row-mask operations elsewhere operate
on arbitrary-precision integers, with cost proportional to the row's limb count.
"""
from itertools import combinations
from odd_pair_square_multiplicity_check import multiplicities


def sites(s):
    while s:
        bit = s & -s
        yield bit.bit_length()-1
        s ^= bit


def solve(rows,p,q,stats=None):
    rows=tuple(rows)
    n=len(rows)
    full=(1<<n)-1
    if any(type(i) is not int or not 0<=i<n for i in (p,q)) or p==q:
        raise ValueError('two distinct valid pins required')
    if any(type(r) is not int or not 0<=r<=full or r>>i&1 for i,r in enumerate(rows)):
        raise ValueError('invalid adjacency row')
    if any(not rows[j]>>i&1 for i,r in enumerate(rows) for j in sites(r)):
        raise ValueError('asymmetric adjacency')
    # Byte-indexed adjacency keeps each lookup in the quartic initial loop constant-time.
    # A single Python-int shift/AND/popcount on an entire row can cost O(n) bit work.
    adjacency = []
    for value in rows:
        packed = value.to_bytes((n+7)//8, 'little')
        adjacency.append(bytes((packed[j//8] >> (j%8)) & 1 for j in range(n)))
    eligible = max(multiplicities(rows).values(),default=0) <= 2
    original_pins=(1<<p)|(1<<q)
    if stats is None:
        stats={}
    stats.update(states=0,paths=0,maxdepth=0,maxchildren=0)
    stack=[(full,p,q,0,0)]
    while stack:
        active,p,q,forced,depth=stack.pop()
        stats['states']+=1
        stats['maxdepth']=max(stats['maxdepth'],depth)
        pair=(1<<p)|(1<<q)
        # Every previously erased edge except the current pin edge has a dead endpoint.
        def row(i):
            value=rows[i]&active
            if depth and i in (p,q):
                value &= ~(pair^(1<<i))
            return value
        remaining=list(sites(active^pair))
        sizes = (0,2) if depth else (0,2,4)
        for size in sizes:
            for chosen in combinations(remaining,size):
                word = (p,q) + chosen
                # At positive depth pq is an original edge, now temporarily absent.
                if all((sum(adjacency[i][j] for j in word) - int(bool(depth) and i in (p,q))) % 2
                       for i in word):
                    result = forced | sum(1<<i for i in word)
                    assert result&original_pins==original_pins
                    assert all((rows[i]&result).bit_count()%2 for i in sites(result))
                    return 'YES',result
        if not eligible:
            return 'UNKNOWN',None
        pr,qr=row(p),row(q)
        children=[]
        for u in sites(pr & ~pair):
            for v in sites(row(u)&qr&~pair):
                if (pr>>v&1) and (qr>>u&1):
                    continue
                if pr>>v&1:
                    # q is a selected leaf and v has exactly three selected neighbors.
                    keep=active & ~( (1<<q)|(1<<v)|(qr&~(1<<v))|(row(v)&~(pair|(1<<u))) )
                    keep |= (1<<u)|(1<<p)
                    children.append((keep,p,u,forced|(1<<q)|(1<<v),depth+1))
                elif qr>>u&1:
                    keep=active & ~( (1<<p)|(1<<u)|(pr&~(1<<u))|(row(u)&~(pair|(1<<v))) )
                    keep |= (1<<v)|(1<<q)
                    children.append((keep,q,v,forced|(1<<p)|(1<<u),depth+1))
                else:
                    keep=active & ~(pair|(pr&~(1<<u))|(qr&~(1<<v)))
                    children.append((keep,u,v,forced|pair,depth+1))
        stats['paths']+=len(children)
        stats['maxchildren']=max(stats['maxchildren'],len(children))
        stack.extend(children)
    return 'NO',None


def self_test():
    from random import Random
    import networkx as nx
    from odd_pair_square_multiplicity_check import graph,supports
    tally={}
    def check(r,p,q,truth,eligible):
        stats={}
        status,w=solve(r,p,q,stats)
        assert status=='UNKNOWN' or (status=='YES')==bool(truth), (r,p,q,truth,status)
        assert not eligible or status!='UNKNOWN'
        tally[status]=tally.get(status,0)+1
        return stats
    for g in nx.graph_atlas_g():
        r=graph(len(g),g.edges())
        ws=list(supports(r))
        ok=max(multiplicities(r).values(),default=0)<=2
        for p,q in combinations(range(len(r)),2):
            check(r,p,q,any(w>>p&w>>q&1 for w in ws),ok)
    rng=Random(873352)
    for _ in range(220):
        n=rng.randint(8,13)
        pairs=list(combinations(range(n),2))
        rng.shuffle(pairs)
        edges=[]
        for edge in pairs[:rng.randrange(n,3*n)]:
            if max(multiplicities(graph(n,edges+[edge])).values())<=2:
                edges.append(edge)
        r=graph(n,edges)
        p,q=rng.sample(range(n),2)
        check(r,p,q,next(supports(r,(1<<p)|(1<<q)),None),True)
    r=graph(4,[(0,2),(1,3)])
    p,q=0,1
    for _ in range(9):
        n=len(r)
        r[p]|=1<<q|1<<n
        r[q]|=1<<p|1<<(n+1)
        r.extend((1<<p,1<<q))
        p,q=n,n+1
    stats={}
    assert solve(r,p,q,stats)==('YES',(1<<len(r))-1)
    assert stats['maxdepth']==9
    branch={}
    assert solve([12,16,17,17,14],0,1,branch)==('NO',None)
    assert branch['maxchildren']==2 and branch['states']==3
    triangle=[22,41,1,2,97,146,400,352,704,256]
    assert max(multiplicities(triangle).values())==2
    assert list(supports(triangle,(1<<6)|(1<<9)))==[1023]
    for p,q in ((6,9),(9,6)):
        history={}
        assert solve(triangle,p,q,history)==('YES',1023)
        assert history['maxdepth']==3
    print(tally,'relay',stats,'two-path NO',branch,'triangle relay YES',history)


if __name__=='__main__':
    self_test()
